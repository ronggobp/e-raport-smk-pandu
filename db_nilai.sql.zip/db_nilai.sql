-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 17, 2022 at 09:21 AM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 5.6.36

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_nilai`
--

-- --------------------------------------------------------

--
-- Table structure for table `m_admin`
--

CREATE TABLE `m_admin` (
  `id` int(4) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `level` enum('admin','guru','siswa') NOT NULL,
  `konid` varchar(10) NOT NULL,
  `aktif` enum('Y','N') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `m_admin`
--

INSERT INTO `m_admin` (`id`, `username`, `password`, `level`, `konid`, `aktif`) VALUES
(1, 'admin', '1b8b0fdaaecfa0cee0d70693a0cf8a192c4edb26', 'admin', '0', 'Y'),
(52, 'mahsun', 'fefdd621d35d14c299aef2fcae34d3dfe9b2f12b', 'guru', '7', 'Y'),
(53, 'adi', 'fefdd621d35d14c299aef2fcae34d3dfe9b2f12b', 'guru', '9', 'Y'),
(54, 'masteng', 'fefdd621d35d14c299aef2fcae34d3dfe9b2f12b', 'guru', '10', 'Y'),
(55, 'ali', 'fefdd621d35d14c299aef2fcae34d3dfe9b2f12b', 'guru', '11', 'Y'),
(56, 'amin', 'fefdd621d35d14c299aef2fcae34d3dfe9b2f12b', 'guru', '12', 'Y'),
(57, 'angga', 'fefdd621d35d14c299aef2fcae34d3dfe9b2f12b', 'guru', '13', 'Y'),
(58, 'asdan', 'fefdd621d35d14c299aef2fcae34d3dfe9b2f12b', 'guru', '14', 'Y'),
(59, 'parker', 'fefdd621d35d14c299aef2fcae34d3dfe9b2f12b', 'guru', '15', 'Y'),
(60, 'asep', 'fefdd621d35d14c299aef2fcae34d3dfe9b2f12b', 'guru', '16', 'Y'),
(61, 'ayu', 'fefdd621d35d14c299aef2fcae34d3dfe9b2f12b', 'guru', '35', 'Y'),
(62, 'banon', 'fefdd621d35d14c299aef2fcae34d3dfe9b2f12b', 'guru', '17', 'Y'),
(63, 'beti', 'fefdd621d35d14c299aef2fcae34d3dfe9b2f12b', 'guru', '33', 'Y'),
(64, 'bunari', 'fefdd621d35d14c299aef2fcae34d3dfe9b2f12b', 'guru', '18', 'Y'),
(65, 'yoga', 'fefdd621d35d14c299aef2fcae34d3dfe9b2f12b', 'guru', '19', 'Y'),
(66, 'endis', 'fefdd621d35d14c299aef2fcae34d3dfe9b2f12b', 'guru', '20', 'Y'),
(67, 'enjay', 'fefdd621d35d14c299aef2fcae34d3dfe9b2f12b', 'guru', '21', 'Y'),
(68, 'eni', 'fefdd621d35d14c299aef2fcae34d3dfe9b2f12b', 'guru', '22', 'Y'),
(69, 'ima', 'fefdd621d35d14c299aef2fcae34d3dfe9b2f12b', 'guru', '34', 'Y'),
(70, 'jenal', 'fefdd621d35d14c299aef2fcae34d3dfe9b2f12b', 'guru', '23', 'Y'),
(71, 'miftah', 'fefdd621d35d14c299aef2fcae34d3dfe9b2f12b', 'guru', '24', 'Y'),
(72, 'ridlo', 'fefdd621d35d14c299aef2fcae34d3dfe9b2f12b', 'guru', '25', 'Y'),
(73, 'dudin', 'fefdd621d35d14c299aef2fcae34d3dfe9b2f12b', 'guru', '37', 'Y'),
(74, 'nanda', 'fefdd621d35d14c299aef2fcae34d3dfe9b2f12b', 'guru', '26', 'Y'),
(75, 'ranika', 'fefdd621d35d14c299aef2fcae34d3dfe9b2f12b', 'guru', '27', 'Y'),
(76, 'yaandip', 'daa0bcc439b3c4a6bbad49f5df6e369ac6075565', 'guru', '36', 'Y'),
(77, 'saeful', 'fefdd621d35d14c299aef2fcae34d3dfe9b2f12b', 'guru', '28', 'Y'),
(78, 'sanan', 'fefdd621d35d14c299aef2fcae34d3dfe9b2f12b', 'guru', '29', 'Y'),
(79, 'taupik', 'fefdd621d35d14c299aef2fcae34d3dfe9b2f12b', 'guru', '30', 'Y'),
(80, 'ujang', 'fefdd621d35d14c299aef2fcae34d3dfe9b2f12b', 'guru', '31', 'Y'),
(82, 'yeni', 'fefdd621d35d14c299aef2fcae34d3dfe9b2f12b', 'guru', '32', 'Y'),
(83, 'sarah', 'fefdd621d35d14c299aef2fcae34d3dfe9b2f12b', 'guru', '38', 'Y'),
(84, '1', '9c1c01dc3ac1445a500251fc34a15d3e75a849df', 'siswa', '1419', 'Y'),
(85, 'taupik_1', 'fefdd621d35d14c299aef2fcae34d3dfe9b2f12b', 'guru', '39', 'Y'),
(86, 'parker_1', 'fefdd621d35d14c299aef2fcae34d3dfe9b2f12b', 'guru', '40', 'Y'),
(87, 'sanan_1', 'fefdd621d35d14c299aef2fcae34d3dfe9b2f12b', 'guru', '41', 'Y'),
(89, 'ranika_1', 'fefdd621d35d14c299aef2fcae34d3dfe9b2f12b', 'guru', '42', 'Y'),
(90, 'asep_1', 'fefdd621d35d14c299aef2fcae34d3dfe9b2f12b', 'guru', '43', 'Y'),
(91, 'angga_1', 'fefdd621d35d14c299aef2fcae34d3dfe9b2f12b', 'guru', '45', 'Y'),
(92, 'fajri', 'fefdd621d35d14c299aef2fcae34d3dfe9b2f12b', 'guru', '48', 'Y'),
(93, 'selvi', 'fefdd621d35d14c299aef2fcae34d3dfe9b2f12b', 'guru', '47', 'Y'),
(94, 'fikriya', 'fefdd621d35d14c299aef2fcae34d3dfe9b2f12b', 'guru', '44', 'Y'),
(95, 'fatur', 'fefdd621d35d14c299aef2fcae34d3dfe9b2f12b', 'guru', '46', 'Y'),
(96, 'lastri', 'fefdd621d35d14c299aef2fcae34d3dfe9b2f12b', 'guru', '50', 'Y'),
(97, 'geru', 'fefdd621d35d14c299aef2fcae34d3dfe9b2f12b', 'guru', '51', 'Y'),
(98, 'lillah', 'fefdd621d35d14c299aef2fcae34d3dfe9b2f12b', 'guru', '49', 'Y');

-- --------------------------------------------------------

--
-- Table structure for table `m_ekstra`
--

CREATE TABLE `m_ekstra` (
  `id` int(2) NOT NULL,
  `nama` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `m_ekstra`
--

INSERT INTO `m_ekstra` (`id`, `nama`) VALUES
(1, 'Pramuka');

-- --------------------------------------------------------

--
-- Table structure for table `m_guru`
--

CREATE TABLE `m_guru` (
  `id` int(3) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `nip` varchar(20) DEFAULT NULL,
  `jk` enum('L','P') DEFAULT NULL,
  `is_bk` enum('2','1') DEFAULT NULL,
  `stat_data` enum('A','P','M') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `m_guru`
--

INSERT INTO `m_guru` (`id`, `nama`, `nip`, `jk`, `is_bk`, `stat_data`) VALUES
(7, 'Mahsun Yunani, M.Pd.', '001', NULL, '2', 'A'),
(9, 'Adi Setiyo, S.M.', '003', NULL, '2', 'A'),
(10, 'Ahmad Mustangin, S.E.', '004', NULL, '2', 'A'),
(11, 'Ali Mustofa, S.E.', '005', NULL, '2', 'A'),
(12, 'Amin Fahudin', '006', NULL, '2', 'A'),
(13, 'Angga Minggayanto, S.E.', '007', NULL, '2', 'A'),
(14, 'Asdan, M.Pd.', '008', NULL, '2', 'A'),
(15, 'Asep Riki Ramdani, S.Pd.', '009', NULL, '2', 'A'),
(16, 'Asep Sopian, S.T.', '010', NULL, '2', 'A'),
(17, 'Banon Yuliatmojo, S.Pd.', '011', NULL, '2', 'A'),
(18, 'Bunari, M.Si.', '012', NULL, '2', 'A'),
(19, 'Duanda Saputra Yoga', '013', NULL, '2', 'A'),
(20, 'Endis Sopiandi, M.E.I.', '014', NULL, '2', 'A'),
(21, 'Enjay Nurjaya, S.M.', '015', NULL, '2', 'A'),
(22, 'Fitri Eni Marliza, S.Pd.', '016', NULL, '2', 'A'),
(23, 'Jenal Abidin, A.Md.', '017', NULL, '2', 'A'),
(24, 'Miftahudin, S.T.', '018', NULL, '2', 'A'),
(25, 'Moh. Ali Ridlo', '019', NULL, '2', 'A'),
(26, 'Nanda Pramana Putra, S.Pd.', '020', NULL, '2', 'A'),
(27, 'Ranika Kasyiah Dzariyah, S.Pd.', '021', NULL, '1', 'A'),
(28, 'Saeful Imam, M.Si.', '022', NULL, '2', 'A'),
(29, 'Sanan, S.E.', '023', NULL, '2', 'A'),
(30, 'Taupik Surahman', '024', NULL, '2', 'A'),
(31, 'Ujang Sasmita, S.E.', '025', NULL, '2', 'A'),
(32, 'Yeni Elindawati, S.Pd.', '026', NULL, '2', 'A'),
(33, 'Beti Renitawati, M. Ak.', '027', NULL, '2', 'A'),
(34, 'Ima Hermawati, S., S.Pd.', '028', NULL, '2', 'A'),
(35, 'Ayu Triagarini, S.Or.', '029', NULL, '2', 'A'),
(36, 'Ronggo Bintang Pangestu, S.Kom.', '030', NULL, '2', 'A'),
(37, 'Muhamad Faridudin, S.Kom.', '031', NULL, '2', 'A'),
(38, 'Sarah Alya Salsabila, S.Pd.', '032', NULL, '2', 'A'),
(39, 'Taupik Surahman', '033', NULL, '2', 'A'),
(40, 'Asep Riki Ramdani, S.Pd.', '034', NULL, '2', 'A'),
(41, 'Sanan, S.E.', '035', NULL, '2', 'A'),
(42, 'Ranika Kasyiah Dzariyah, S.Pd.', '036', NULL, '2', 'A'),
(43, 'Asep Sopian, S.T.', '-', NULL, '2', 'A'),
(44, 'Fikriya Yunita, S.Pd.', '-', NULL, '2', 'A'),
(45, 'Angga Minggayanto, S.E.', '-', NULL, '2', 'A'),
(46, 'Fatur Baehakim, S.Pd.', '-', NULL, '2', 'A'),
(47, 'Selviani, S.E.', '-', NULL, '2', 'A'),
(48, 'Abdullah Fajri, S.T.', '-', NULL, '2', 'A'),
(49, 'Neng Lillah, S.Pd.', '037', NULL, '2', 'A'),
(50, 'Sulastri, S.Pd.I.', '038', NULL, '2', 'A'),
(51, 'Geru Sukarno Putra, S.Kom.', '039', NULL, '2', 'A');

-- --------------------------------------------------------

--
-- Table structure for table `m_kelas`
--

CREATE TABLE `m_kelas` (
  `id` int(3) NOT NULL,
  `tingkat` varchar(3) DEFAULT NULL,
  `nama` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `m_kelas`
--

INSERT INTO `m_kelas` (`id`, `tingkat`, `nama`) VALUES
(1, '10', 'X - TBSM A'),
(2, '10', 'X - TBSM B'),
(3, '10', 'X - TBSM C'),
(4, '10', 'X - TKRO A'),
(5, '10', 'X - TKRO B'),
(6, '10', 'X - OTR'),
(7, '10', 'X - MM'),
(8, '10', 'X - TKJ'),
(9, '11', 'XI - TBSM A'),
(10, '11', 'XI - TBSM B'),
(11, '11', 'XI - TKRO A'),
(12, '11', 'XI - TKRO B'),
(13, '11', 'XI - OTR'),
(14, '11', 'XI - TKJ'),
(16, '11', 'XI - MM'),
(17, '12', 'XII - TBSM A'),
(18, '12', 'XII - TBSM B'),
(19, '12', 'XII - TKRO A'),
(20, '12', 'XII - TKRO B'),
(21, '12', 'XII - OTR'),
(22, '12', 'XII - TKJ'),
(23, '12', 'XII - MM');

-- --------------------------------------------------------

--
-- Table structure for table `m_mapel`
--

CREATE TABLE `m_mapel` (
  `id` int(3) NOT NULL,
  `kelompok` enum('A','A1','A2','A3','B','C','D','E','E1','F','G','H','I','J','K','L','M','N','O','P','Q') NOT NULL,
  `tambahan_sub` enum('NASIONAL','WILAYAH','BIDANG','PROGRAM','KOMPETENSI') NOT NULL,
  `kd_singkat` varchar(10) NOT NULL,
  `nama` varchar(150) NOT NULL,
  `is_sikap` enum('0','1') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `m_mapel`
--

INSERT INTO `m_mapel` (`id`, `kelompok`, `tambahan_sub`, `kd_singkat`, `nama`, `is_sikap`) VALUES
(94, 'A', 'NASIONAL', 'PAI', 'Pendidikan Agama dan Budi Pekerti', '0'),
(95, 'A', 'NASIONAL', 'PPKN', 'Pendidikan Pancasila dan Kewarganegaraan', '0'),
(96, 'A', 'NASIONAL', 'B.IND', 'Bahasa Indonesia', '0'),
(97, 'A2', 'NASIONAL', 'MTK', 'Matematika', '0'),
(98, 'A3', 'NASIONAL', 'B.ING', 'Bahasa Inggris dan Bahasa Asing Lainnya', '0'),
(99, 'B', 'NASIONAL', 'SI', 'Sejarah Indonesia', '0'),
(100, 'C', 'WILAYAH', 'SB', 'Seni Budaya', '0'),
(101, 'C', 'WILAYAH', 'B.SUN', 'Bahasa Sunda', '0'),
(102, 'D', 'WILAYAH', 'PENJASKES', 'Pendidikan Jasmani, Olahraga, dan Kesehatan', '0'),
(103, 'E', 'BIDANG', 'SIMDIG', 'Simulasi dan Komunikasi Digital', '0'),
(104, 'E1', 'BIDANG', 'FSK', 'Fisika', '0'),
(105, 'E1', 'BIDANG', 'KMA', 'Kimia', '0'),
(106, 'F', 'PROGRAM', 'GTO', 'Gambar Teknik Otomotif', '0'),
(107, 'F', 'PROGRAM', 'TDO', 'Teknologi Dasar Otomotif', '0'),
(108, 'F', 'PROGRAM', 'PDO', 'Pekerjaan Dasar Otomotif', '0'),
(109, 'G', 'KOMPETENSI', 'PKK', 'Produk Kreatif dan Kewirausahaan', '0'),
(110, 'H', 'KOMPETENSI', 'PMKR', 'Pemeliharaan Mesin Kendaraan Ringan', '0'),
(111, 'H', 'KOMPETENSI', 'PSPTKR', 'Pemeliharaan Sasis dan Pemindahan Tenaga Kendaraan Ringan', '0'),
(112, 'H', 'KOMPETENSI', 'PKKR', 'Pemeliharaan Kelistrikan Kendaraan Ringan', '0'),
(113, 'I', 'KOMPETENSI', 'PMSM', 'Pemeliharaan Mesin Sepeda Motor', '0'),
(114, 'I', 'KOMPETENSI', 'PSSM', 'Pemeliharaan Sasis Sepeda Motor', '0'),
(115, 'I', 'KOMPETENSI', 'PKSM', 'Pemeliharaan Kelistrikan Sepeda Motor', '0'),
(116, 'J', 'KOMPETENSI', 'PBSM', 'Pengelolaan Bengkel Sepeda Motor', '0'),
(117, 'K', 'KOMPETENSI', 'PPEMS&ML', 'Perawatan dan Perbaikan Engine Management System dan Motor Listrik', '0'),
(118, 'K', 'KOMPETENSI', 'PPCMS', 'Perawatan dan Perbaikan Chasis Management System', '0'),
(119, 'L', 'KOMPETENSI', 'PPCS&IT', 'Perawatan dan Perbaikan Comfort Safety & IT', '0'),
(120, 'L', 'KOMPETENSI', 'PSKK', 'Perancangan Sistem Kontrol Kendaraan', '0'),
(121, 'M', 'PROGRAM', 'SK', 'Sistem Komputer', '0'),
(122, 'M', 'PROGRAM', 'KJD', 'Komputer dan Jaringan Dasar', '0'),
(123, 'M', 'PROGRAM', 'PD', 'Pemrograman Dasar', '0'),
(124, 'M', 'PROGRAM', 'DDG', 'Dasar Desain Grafis', '0'),
(125, 'N', 'KOMPETENSI', 'TJBL', 'Teknologi Jaringan Berbasis Luas (WAN)', '0'),
(126, 'O', 'KOMPETENSI', 'AIJ', 'Administrasi Infrastruktur Jaringan', '0'),
(127, 'O', 'KOMPETENSI', 'ASJ', 'Administrasi Sistem Jaringan', '0'),
(128, 'O', 'KOMPETENSI', 'TLJ', 'Teknologi Layanan Jaringan', '0'),
(129, 'P', 'KOMPETENSI', 'DGP', 'Desain Grafis Percetakan', '0'),
(130, 'P', 'KOMPETENSI', 'AD', 'Animasi 2D & 3D', '0'),
(131, 'Q', 'KOMPETENSI', 'DMI', 'Desain Media Interaktif', '0'),
(132, 'Q', 'KOMPETENSI', 'TPAV', 'Teknik Pengolahan Audio dan Video', '0');

-- --------------------------------------------------------

--
-- Table structure for table `m_siswa`
--

CREATE TABLE `m_siswa` (
  `id` int(6) NOT NULL,
  `nis` varchar(10) NOT NULL DEFAULT '0',
  `nisn` varchar(10) NOT NULL DEFAULT '0',
  `nama` varchar(50) NOT NULL,
  `jk` enum('L','P') NOT NULL,
  `tmp_lahir` varchar(50) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `agama` varchar(10) NOT NULL,
  `status` varchar(2) NOT NULL,
  `anakke` varchar(2) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `notelp` varchar(13) NOT NULL,
  `email` varchar(30) NOT NULL,
  `sek_asal` varchar(30) NOT NULL,
  `sek_asal_alamat` varchar(100) NOT NULL,
  `diterima_kelas` varchar(5) NOT NULL,
  `diterima_tgl` date NOT NULL,
  `diterima_smt` int(2) NOT NULL,
  `prog_keahlian` varchar(30) NOT NULL,
  `komp_keahlian` varchar(40) NOT NULL,
  `ijazah_no` varchar(50) NOT NULL,
  `ijazah_thn` varchar(4) NOT NULL,
  `skhun_no` varchar(50) NOT NULL,
  `skhun_thn` varchar(4) NOT NULL,
  `ortu_ayah` varchar(50) NOT NULL,
  `ortu_ibu` varchar(50) NOT NULL,
  `ortu_alamat` varchar(100) NOT NULL,
  `ortu_notelp` varchar(13) NOT NULL,
  `ortu_email` varchar(30) NOT NULL,
  `ortu_ayah_pkj` varchar(30) NOT NULL,
  `ortu_ibu_pkj` varchar(30) NOT NULL,
  `wali` varchar(30) NOT NULL,
  `wali_alamat` varchar(100) NOT NULL,
  `notelp_rumah` varchar(13) NOT NULL,
  `wali_email` varchar(30) NOT NULL,
  `wali_pkj` varchar(30) NOT NULL,
  `inputID` int(2) NOT NULL,
  `tgl_input` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `tgl_update` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `stat_data` enum('A','K','M','L') NOT NULL,
  `foto` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `m_siswa`
--

INSERT INTO `m_siswa` (`id`, `nis`, `nisn`, `nama`, `jk`, `tmp_lahir`, `tgl_lahir`, `agama`, `status`, `anakke`, `alamat`, `notelp`, `email`, `sek_asal`, `sek_asal_alamat`, `diterima_kelas`, `diterima_tgl`, `diterima_smt`, `prog_keahlian`, `komp_keahlian`, `ijazah_no`, `ijazah_thn`, `skhun_no`, `skhun_thn`, `ortu_ayah`, `ortu_ibu`, `ortu_alamat`, `ortu_notelp`, `ortu_email`, `ortu_ayah_pkj`, `ortu_ibu_pkj`, `wali`, `wali_alamat`, `notelp_rumah`, `wali_email`, `wali_pkj`, `inputID`, `tgl_input`, `tgl_update`, `stat_data`, `foto`) VALUES
(1, '10219057', '-', 'ABDUL MUKSIT', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(2, '10219058', '0069220241', 'ACHRIZAN AKBAR', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(3, '10219029', '0065284667', 'AHMAD NUR ZAKY', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(4, '10219185', '0056665026', 'ALPAN ICHWAN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(5, '10219187', '3040065359', 'AZMAN AL NAHYA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(6, '10219161', '0040519469', 'DARWIN CANDRA SAPUTRA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(7, '10219172', '0037825210', 'DEA ROYANA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(8, '10219200', '0062505712', 'DERI ZAKKI ANDRIYAN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(9, '10219129', '0064176507', 'EDI JULIAN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(10, '10219163', '0053126047', 'IBNU DHIYA ABDILLAH', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(11, '10219201', '0052726053', 'IRWAN DUTAWAN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(12, '10219165', '0065716351', 'IRWAN MAULANA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(13, '10219182', '0058437977', 'KAKAN SAPUTRA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(14, '10219191', '0057882639', 'M. GALANG PRATAMA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(15, '10219198', '0068302965', 'M. JUAN RIANTO', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(16, '10219183', '3061807070', 'M. RIDO SUWARTO', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(17, '10219167', '3068024121', 'MUHAMAD NAFIZ NAZMUDIN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(18, '10219197', '0069194168', 'MUHAMAD RAIHAN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(19, '10219174', '0063674727', 'MUHAMAD RASYA PRATAMA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(20, '10219169', '0054570532', 'MUHAMAD RIDWAN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(21, '10219028', '0043521558', 'MUHAMAD RIFQI NOVANSYAH', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(22, '10219181', '0055251397', 'MUHAMAD SYAHRIL', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(23, '10219184', '3068445913', 'MUHAMAD SYAMSUL FALAH', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(24, '10219166', '0056388440', 'MUHAMMAD FAJRI FAUZAN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(25, '10219199', '3146768487', 'RAFLY ZAHRAN RABBANI', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(26, '10219206', '0066079343', 'RAGIL SETIADI', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(27, '10219164', '0061998957', 'RAMA ANGGARA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(28, '10219056', '63970582', 'RIDWAN SAWALLUDIN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(29, '10219168', '0063942562', 'RIFKI', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(30, '10219054', '0065664647', 'SOPIAN PERMANA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(31, '10219245', '0065448827', 'WIGUNA FADILAH', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(32, '10219202', '0067312977', 'ZAKILA NURFAZIA', 'P', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(33, '10219243', '0043583674', 'AKBIL KHOLIS', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(34, '10219188', '0067790095', 'ALDI PRAMANA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(35, '10219178', '0046829275', 'ALWI SIHAB', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(36, '10219147', '0057790760', 'CINDI AMELIA', 'P', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(37, '10219192', '3065992291', 'DAVIN PASCA AZZIKRI', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(38, '10219190', '0072742033', 'EGI MAULANA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(39, '10219193', '0041479945', 'GINANJAR RAMADHAN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(40, '10219246', '0062125400', 'HANOTO NEGORO', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(41, '10219194', '0066134238', 'IBNU RIZQULLAH', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(42, '10219204', '0057744442', 'M. NAZRIL AZKIA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(43, '10219107', '0046936731', 'MAMAN SULAEMAN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(44, '10219203', '0053378457', 'MUHAMAD FAHMI ILHAM', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(45, '10219180', '0061121104', 'MUHAMAD FAZRI', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(46, '10219116', '0064843873', 'MUHAMAD HANIF', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(47, '10219055', '0065610504', 'MUHAMMAD IKHSAN ADITYA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(48, '10219254', '3056729663', 'NOVI AMELIA PUTRI', 'P', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(49, '10219018', '0064422966', 'RAIHAN FADILLAH', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(50, '10219170', '3064003744', 'RIDHO SETIADI', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(51, '10219156', '0056256964', 'RIO SAPUTRA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(52, '10219162', '0055084338', 'RIPANDI NASUTION', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(53, '10219255', '0062851226', 'ROSA DEWANTI', 'P', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(54, '10219189', '0067678699', 'YOGA RIANTO', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(55, '-', '-', 'AA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(56, '-', '-', 'BB', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(57, '10219034', '0055783799', 'AHMAD FARHAN HUSAINI', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Ototronik', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(58, '10219205', '0054755470', 'ALDI SETIAWAN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Ototronik', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(59, '10219026', '0068804431', 'M. HAZWAFI', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Ototronik', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(60, '10219033', '0052461160', 'M. RAMDAN AL FIKRI', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Ototronik', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(61, '10219091', '0066389596', 'MUHAMAD RIZKI FIRDAUS', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Ototronik', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(62, '10219176', '0065193046', 'MUHAMAD SOLEH SUBAGAS', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Ototronik', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(63, '10219035', '0064550891', 'MUHAMAD TIPAN TRI SAPUTRA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Ototronik', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(64, '10219032', '0068115289', 'OGI PERMANA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Ototronik', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(65, '10219036', '3066386494', 'RIYAN BAYU SAPUTRA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Ototronik', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(66, '10219031', '0041683268', 'SUNARDI', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Ototronik', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(67, '-', '-', 'CC', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Ototronik', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(68, '-', '-', 'DD', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik Ototronik', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(69, '10219081', '0046838173', 'ADE SURYANA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(70, '10219094', '0061394668', 'ADITTIA RAMADAN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(71, '10219104', '0058553471', 'ADRIAN MAULANA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(72, '10219258', '0056211640', 'AGUNG GUMELAR', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(73, '10219084', '0065373115', 'ALFATHUR JANWAR', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(74, '10219047', '0066048769', 'ALIF NUR FAJRIN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(75, '10219049', '0058694355', 'ANGGI PRAYOGA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(76, '10219095', '0066407431', 'ARDIYANSAH PERMANA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(77, '10219061', '0042289439', 'ARMED', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(78, '10219247', '0059699709', 'DEVI', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(79, '10219249', '0044701273', 'DIKA PRATAMA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(80, '10219044', '0053878176', 'FIKRY ZULFIKAR', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(81, '10219099', '0053253579', 'KRIS HERDIANSYAH', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(82, '10219043', '0034937344', 'M. ZAELANI', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(83, '10219117', '0044959355', 'MAULANA AGUSTIN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(84, '10219100', '0046703222', 'MOH NICHOLAS GLAND FREDLY', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(85, '10219059', '0067394462', 'MUHAMAD AKLA ELIYEN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(86, '10219077', '0064995199', 'MUHAMAD BALDIN ROKIB', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(87, '10219076', '0063766559', 'MUHAMAD FAOZIL KHOLAS', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(88, '10219070', '0056396610', 'MUHAMAD FIKRI RAMDANI', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(89, '10219250', '0045118750', 'MUHAMAD IPANG APANDI', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(90, '10219114', '0052353613', 'MUHAMAD LUTFI FADILA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(91, '10219048', '0031642360', 'MUHAMAD NURDIANSYAH', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(92, '10219069', '0056867601', 'MUHAMAD RAMDANI', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(93, '10219195', '0059056196', 'MUHAMAD RIZAL KAHFI', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(94, '10219083', '0054888212', 'MUHAMAD ROYIHAN NURHAKIKI', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(95, '10219090', '0042772935', 'MUHAMAD SABILAH HIDAYAT', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(96, '10219051', '0068751220', 'MUHAMMAD CANDRA WINATA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(97, '10219098', '0059539622', 'MUHAMMAD YUSUP', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(98, '10219075', '0054595090', 'PIRDAUS KUSMIAJI', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(99, '10219041', '0045067554', 'PIRMAN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(100, '10219074', '0069819453', 'PUYOL ABADI SINUHAJI', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(101, '10219067', '0062787666', 'RADITIYA LESMANA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(102, '10219038', '0054412477', 'RAIHAN FAUZI', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(103, '10219108', '0069237340', 'RAZWA NABIL SAPUTRA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(104, '10219046', '0045888767', 'RISKI RAMDANI', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(105, '10219133', '0068144201', 'ULAN SARI', 'P', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(106, '10219120', '0062120752', 'YUDANA FAUZI', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(107, '10219053', '0058860324', 'YUDHA EKA PRADANA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(108, '10219037', '0055558487', 'ABDAL ABDILAH', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(109, '10219086', '0043249710', 'AGISNA ALFARIZI', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(110, '10219092', '3050081672', 'AGUNG', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(111, '10219025', '0046543418', 'AKAS FIRMANSYAH', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(112, '10219121', '0058411397', 'ALFIRA SANJAYA', 'P', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(113, '10219103', '3048291713', 'ANDI SEPTIAWAN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(114, '10219065', '0055382891', 'ANDREAN DWI PUTRA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(115, '10219073', '0078684599', 'APRI INHARJU SIHOMBING', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(116, '10219089', '0056612202', 'DIMAS NUGROHO SASMITA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(117, '10219027', '0062296460', 'FAHRI HAIKAL', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(118, '10219072', '0055799543', 'FAQIH AL BANNA MARSUDI ', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(119, '10219115', '3039319621', 'M. ARIPIN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(120, '10219071', '0062256629', 'M.PADLAN HAIKAL', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(121, '10219252', '0066134070', 'MEITA NURHALIZAH', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(122, '10219042', '0052223956', 'MOCHAMMAD FERDIANSYAH', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(123, '10219062', '0053541464', 'MUHAMAD ARYA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(124, '10219088', '0067795591', 'MUHAMAD DWI ARIYANTO', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(125, '10219106', '0061675278', 'MUHAMAD FAISAL RANDIKA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(126, '10219105', '3051831982', 'MUHAMAD FATAH YASIN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(127, '10219066', '0054195819', 'MUHAMAD FIKRI ISLAMI', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(128, '10219045', '0058515224', 'MUHAMAD ILHAM', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(129, '10219113', '0068229544', 'MUHAMAD JENAL HIDAYAT', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(130, '10219078', '0064337919', 'MUHAMAD NURZIKRI', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(131, '10219179', '3066054519', 'MUHAMAD RIDHO SAPUTRA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(132, '10219102', '0034365886', 'MUHAMAD YUSUP', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(133, '10219068', '0061038807', 'MUHAMMAD ARYA AKBAR', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(134, '10219173', '3062775421', 'MUHAMMAD HILMAN AWALUDIN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(135, '10219085', '0045056132', 'MUHAMMAD RIZKI', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(136, '10219087', '0057188149', 'PANDU ARISTIAWAN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(137, '10219082', '0069531857', 'RADEN ACHMAD BENTAR MANDALA POETRA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(138, '10219080', '0055659048', 'RAFID NURJAMAN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(139, '10219039', '0056717253', 'RAZMA RANGGA SOLEH', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(140, '10219079', '0062228327', 'RIZKI MAULANA ARTA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(141, '10219112', '3044156089', 'SULAEMAN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(142, '10219171', '0044780821', 'SULTAN MAULANA HAKIM', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(143, '-', '0035095137', 'SUPRIATNA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(144, '10219101', '0058858114', 'WAHYU', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(145, '10219063', '0036598170', 'YUSUP ALAWI', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(146, '-', '-', 'EE', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(147, '-', '-', 'FF', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(148, '10219251', '3052470044', 'ALDI', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(149, '10219146', '0054689612', 'ANISA NASUTION', 'P', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', '');
INSERT INTO `m_siswa` (`id`, `nis`, `nisn`, `nama`, `jk`, `tmp_lahir`, `tgl_lahir`, `agama`, `status`, `anakke`, `alamat`, `notelp`, `email`, `sek_asal`, `sek_asal_alamat`, `diterima_kelas`, `diterima_tgl`, `diterima_smt`, `prog_keahlian`, `komp_keahlian`, `ijazah_no`, `ijazah_thn`, `skhun_no`, `skhun_thn`, `ortu_ayah`, `ortu_ibu`, `ortu_alamat`, `ortu_notelp`, `ortu_email`, `ortu_ayah_pkj`, `ortu_ibu_pkj`, `wali`, `wali_alamat`, `notelp_rumah`, `wali_email`, `wali_pkj`, `inputID`, `tgl_input`, `tgl_update`, `stat_data`, `foto`) VALUES
(150, '10219125', '0065543735', 'APRIANI', 'P', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(151, '10219149', '0062091260', 'ASEP SUDRAJAT', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(152, '10219157', '3036838716', 'BAYU SAPUTRA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(153, '10219135', '0064686445', 'DAMAR AGUSTIAN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(154, '10219021', '0061058114', 'DEDE NAZAROH SEPTIANA', 'P', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(155, '10219139', '0057621357', 'DIMAS ARDIANSYA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(156, '10219145', '0067146108', 'EGIE HERDIANSYAH', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(157, '10219138', '0062624569', 'FIRMANSYAH', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(158, '10219154', '0063391824', 'GILANG NURHAKIM', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(159, '10219127', '0054177503', 'IBNU SYARIEF HIDAYATULLOH', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(160, '10219136', '0066013132', 'LUSI YANAH', 'P', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(161, '10219140', '3066823067', 'M. MISBAHUDIN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(162, '10219152', '0040954229', 'MUHAMAD FIKRI', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(163, '10219151', '0053610833', 'MUHAMAD ILHAM FIRDAUS', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(164, '10219137', '0066490254', 'MUHAMAD MAULANA FAZRIN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(165, '10219134', '0051225741', 'MUHAMAD WILJI JULIANSYAH', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(166, '10219143', '0051755307', 'MUHAMAD YUDISTIA AL GHIFARI', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(167, '10219158', '3040959142', 'MUHAMMAD ABDURAHMAN ASSABIL', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(168, '10219141', '0056818827', 'MUHAMMAD SAADUDIN AZIZI', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(169, '10219124', '3055781204', 'MUHAMMAD SAPRUDINI', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(170, '10219131', '0069269539', 'NABIL NIBRAS FADLI', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(171, '10219130', '0061519139', 'NESHA MEIVITA', 'P', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(172, '10219150', '0062876311', 'PAJRI SETIAWAN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(173, '10219144', '0066815722', 'RAFKA ADITYA WARDANA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(174, '10219123', '0051019595', 'RAHMAWATI ', 'P', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(175, '10219159', '0068804749', 'RISMA NUR MAULIDA', 'P', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(176, '10219013', '0052917845', 'ROBI APRIAN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(177, '10219155', '0068500983', 'ROSITA MULYANI', 'P', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(178, '10219126', '0069308660', 'SARI NURUL AZZAHRA', 'P', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(179, '10219122', '0063655105', 'SUCI RAHMA WATI', 'P', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(180, '10219142', '0065230403', 'SUMARIA APRILIAN', 'P', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(181, ' ', '0044672173', 'MUHAMAD RIKI ALPIANSYAH ', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(182, '-', '-', 'GG', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(183, '-', '-', 'HH', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(184, '10219009', '0069081537', 'AGIS GINASTIAR', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Komputer & Informatika', 'Multimedia', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(185, '10219006', '0066181252', 'AHMAD ZAIM ADIL', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Komputer & Informatika', 'Multimedia', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(186, '10219008', '0065951439', 'ALDIRO IQBAL PRATAMA PUTRA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Komputer & Informatika', 'Multimedia', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(187, '10219020', '0064822040', 'DEA NABILATUL KHOLIFAH', 'P', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Komputer & Informatika', 'Multimedia', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(188, '10219050', '0061408883', 'DENIS RIZKY NOOR ABDILAH', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Komputer & Informatika', 'Multimedia', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(189, '10219016', '0066760420', 'DICKY ARIFIANTO', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Komputer & Informatika', 'Multimedia', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(190, '10219025', '3041415793', 'M. YUDISTIRA RAMADHAN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Komputer & Informatika', 'Multimedia', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(191, '10219128', '0059853932', 'MARSELINA', 'P', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Komputer & Informatika', 'Multimedia', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(192, '10219004', '0056509395', 'RAIHAN PUTRA IRAWAN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Komputer & Informatika', 'Multimedia', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(193, '10219011', '0067921490', 'RAIHAN YAJID', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Komputer & Informatika', 'Multimedia', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(194, '10219010', '0067159091', 'RAMDANI', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Komputer & Informatika', 'Multimedia', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(195, '10219023', '0058426296', 'RATNA SARI PUTRI', 'P', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Komputer & Informatika', 'Multimedia', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(196, '10219012', '0062972194', 'REFALINA', 'P', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Komputer & Informatika', 'Multimedia', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(197, '10219014', '0045111667', 'REZA SAPUTRA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Komputer & Informatika', 'Multimedia', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(198, '10219019', '0053852702', 'SITI NOOR HASHANAH LASMANA', 'P', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Komputer & Informatika', 'Multimedia', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(199, '10219005', '0066150635', 'SITI NURHALIMAH', 'P', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Komputer & Informatika', 'Multimedia', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(200, '10219002', '0053158910', 'SUGIH SUGESTI', 'P', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Komputer & Informatika', 'Multimedia', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(201, '10219024', '0061898879', 'WISNU PERMANA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Komputer & Informatika', 'Multimedia', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(202, '-', '-', 'II', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Komputer & Informatika', 'Multimedia', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(203, '-', '-', 'JJ', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2021-07-19', 1, 'Teknik Komputer & Informatika', 'Multimedia', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(204, '10208770', '0046942628', 'ACHMAD FADILLAH', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(205, '10208786', '0040933190', 'AGUNG GUNAWAN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(206, '10208766', '0044917757', 'AL BANI', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(207, '10208765', '0054074136', 'ALFIN MAULANA HASAN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(208, '11219002', '3059314227', 'DIMAS AGUNG PRATAMA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(209, '10208775', '0048744179', 'FAUZAN RAMADHAN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(210, '10208773', '0046314836', 'FAUZI ALWI YASIN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(211, '10208764', '0056038383', 'HILMAN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(212, '10208797', '0043161352', 'JAENUDIN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(213, '10208777', '0047459062', 'MASROOR AHMAD RAUP', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(214, '10208817', '0044591032', 'MUHAMAD ARIO ALFARIZKI', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(215, '10218988', '3177060084', 'MUHAMAD BAYU PUTRA PERSADA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(216, '10208776', '0047630170', 'MUHAMAD HAIKAL KHALIL GIBRAN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(217, '10208802', '3047985904', 'MUHAMAD RIDWAN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(218, '10208779', '3042231162', 'MUHAMAD TOFIK KUROHMAN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(219, '10208781', '0055734281', 'MUHAMMAD AMARTIA PUTRA RAMADHAN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(220, '10208772', '0051042415', 'MUHAMMAD IKQBAL CHOERUDIN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(221, '10208771', '3048742636', 'NUR PAHMI IDRIS', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(222, '10208780', '0051358808', 'PERDI AHMAD', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(223, '10208785', '0043361941', 'RAMDANI YUDIYANSAH', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(224, '10208784', '0044917763', 'RANGGA JULIAN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(225, '10208783', '3041208549', 'ROPIK AMIRUDIN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(226, '10208798', '0051575771', 'AHMAD HABIBI', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(227, '10208805', '0056432657', 'AHMAD WAFIYUDIN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(228, '10208792', '0031212521', 'ALDIANSYAH', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(229, '10208787', '0029963520', 'APRI MAULANA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(230, '10208794', '3050410914', 'AZIZ RAMADANI', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(231, '10208795', '0051278433', 'DIKA NAZRIL', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(232, '10208808', '0045911629', 'DIMAS WAHYUDI', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(233, '10208803', '0053652569', 'FAISAL RACHMAWAN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(234, '10208800', '0063127838', 'FARHAN ABAS GUMELAR', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(235, '10208788', '0058466046', 'M. GIFAREL PRASETIA HIDAYAT', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(236, '10208806', '3072343034', 'M. PADLI RAIHAN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(237, '10208774', '0057983404', 'MOCHAMMAD ALIEF NUR MAULANA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(238, '10208790', '3054530813', 'MOHAMAD MI\'RAJ FIRDAUS', 'L', '-', '0000-00-00', 'Islam', 'AK', '', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:32:07', '0000-00-00 00:00:00', 'A', ''),
(239, '10208801', '0045825415', 'MUCHAMMAD AHID AWALUDIN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(240, '10208799', '0024370208', 'MUHAMAD FIKRI FIRDAUS', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(241, '10208987', '0056695975', 'MUHAMAD IHSAN FADILAH', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(242, '10208784', '0044917763', 'RANGGA JULIAN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(243, '10208767', '0045178934', 'RIZKI NUR RAMADHAN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(244, '10208796', '0051700964', 'TEGAR BUDIMAN REGA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(245, '10208793', '0059106688', 'YUSAL APRIANSYAH', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(246, '-', '-', 'KK', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(247, '-', '-', 'LL', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik Kendaraan Ringan Otomotif', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(248, '10208963', '0046334198', 'ACHMAD PRASETYO HADI', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik Ototronik', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(249, '10208964', '3057962555', 'ADAM MAULANA ZAGHI AL FATH', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik Ototronik', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(250, '10208966', '0045311508', 'ALANSAH', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik Ototronik', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(251, '10208812', '0054775539', 'ANGGA SAPUTRA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik Ototronik', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(252, '10208809', '0068052942', 'CANDRA SUGIANTO', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik Ototronik', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(253, '10208967', '0052008354', 'FARHAN HAEKAL AMRI', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik Ototronik', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(254, '10209000', '3046120351', 'KASYA  AFIF HALIM', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik Ototronik', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(255, '10208811', '0040419231', 'PIRJA PAHREJI', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik Ototronik', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(256, '10208810', '3037080297', 'RAHMAT DARMAWAN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik Ototronik', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(257, '10208970', '0049555958', 'RASYIQ SURYA RAMADHAN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik Ototronik', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(258, '10208982', '0046761860', 'ZHAIRAN AHMAD UKASYAH', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik Ototronik', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(259, '-', '-', 'MM', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik Ototronik', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(260, '-', '-', 'NN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik Ototronik', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(261, '10208827', '0043802496', 'ADE IRPAN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(262, '10208839', '0048145788', 'ADE MAULANA YUSUP', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(263, '10208825', '0056825000', 'ADITIA SETIAWAN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(264, '10208824', '3058959938', 'ARIL BAYU SAPUTRA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(265, '10208834', '0051272343', 'ARIPIN ILHAM', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(266, '10208829', '0042838616', 'ARYATHINO AL ANSHORI', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(267, '10208971', '3034386201', 'DIMAS AJI ZULKARNAIN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(268, '10208882', '0051318425', 'EZA SETIAWAN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(269, '10208869', '0048415829', 'KOSASIH EFENDI', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(270, '10208832', '0050771574', 'KHAIRUL SEPTA KUSUMA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(271, '10208826', '0053000227', 'LUMANSAH', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(272, '10208822', '0044284159', 'M. DEDEN JUNAEDI', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(273, '10208813', '0036598176', 'MUHAMAD ABIDIN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(274, '10208881', '0057568843', 'MUHAMAD ARDI YANSAH', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(275, '10208867', '0047857740', 'MUHAMAD RAPI PAHRIJAL', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(276, '10208815', '0056093937', 'MUHAMAD TIRTAYASA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(277, '10208837', '0051174456', 'MUHAMMAD ADITIA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(278, '10208831', '0058854863', 'MUHAMMAD ILHAM KHATIBI', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(279, '10208888', '0051019598', 'MUHAMMAD RIZAL AL IKSAN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(280, '10208823', '0035726715', 'MUHAMMAD TOPAN NUR AKBAR', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(281, '10208873', '0055962922', 'MUHAMAD ZAKI', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(282, '10208836', '0048468964', 'MUHAMMAD ZULFHAN MAULANA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(283, '11219257', '0033987182', 'NANDA MAULANA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(284, '10208816', '0058480473', 'PAHRUDIN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(285, '10208830', '0059035866', 'PUTRA AHMAD MAULANA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(286, '10208835', '0055494277', 'REGI FIRMANSYAH', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(287, '10208819', '3059231588', 'RIZKY APRIJA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(288, '10208886', '0046134312', 'RAMA RAMDANI', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(289, '10208833', '0044917774', 'SYAHWAL ARYA FITRAN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(290, '10208820', '0060052296', 'WAHYU PIRMANSYAH', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(291, '10208838', '0048504519', 'WILDAN KAHFI', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(292, '10208844', '0044875762', 'ADIT RIZKY', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(293, '10208843', '0048568173', 'AKMALUDIN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(294, '10208856', '0059309961', 'ALFIANSYAH', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(295, '10208874', '0046838541', 'ALPI HIDAYAT', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(296, '10208860', '0055259313', 'ALVIN SOFYAN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(297, '10208851', '0057345416', 'ANDIKA YUDA PRATAMA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', '');
INSERT INTO `m_siswa` (`id`, `nis`, `nisn`, `nama`, `jk`, `tmp_lahir`, `tgl_lahir`, `agama`, `status`, `anakke`, `alamat`, `notelp`, `email`, `sek_asal`, `sek_asal_alamat`, `diterima_kelas`, `diterima_tgl`, `diterima_smt`, `prog_keahlian`, `komp_keahlian`, `ijazah_no`, `ijazah_thn`, `skhun_no`, `skhun_thn`, `ortu_ayah`, `ortu_ibu`, `ortu_alamat`, `ortu_notelp`, `ortu_email`, `ortu_ayah_pkj`, `ortu_ibu_pkj`, `wali`, `wali_alamat`, `notelp_rumah`, `wali_email`, `wali_pkj`, `inputID`, `tgl_input`, `tgl_update`, `stat_data`, `foto`) VALUES
(298, '10208861', '0045800555', 'ARI FEBRIANSYAH', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(299, '10208858', '0049340929', 'EGA RAMDONA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(300, '10208868', '0043225900', 'FAJAR SEPTIAN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(301, '10208871', '0045916036', 'FAJRI WAHYU NUGROHO', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(302, '10208853', '0052012827', 'FARIEL ADRIAN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(303, '10208857', '0056132691', 'GESTA MULYA PRATAMA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(304, '10208842', '0044732839', 'HELMI JAMIL MUBAROK', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(305, '10208849', '0045118751', 'IMAM MAHDI', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(306, '10208850', '0046378178', 'INDRA JUANDANA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(307, '10208864', '0050917654', 'LUKI LUKMAN NUL HAKIM', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(308, '10218989', '0045250005', 'MUHAMMAD ADIT IRWANSYAH', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(309, '10208855', '0055356266', 'MUHAMAD IKHSAN KURNIAWAN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(310, '10208887', '0040793130', 'MUHAMAD RIVALDI', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(311, '10208845', '0054731788', 'MUHAMAD RIZKI RIFANDI', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(312, '10208863', '0043944497', 'MUHAMMAD MAULANA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(313, '10208862', '3041891812', 'MUHAMAD ZETA AL FARIL', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(314, '10208859', '0056643183', 'PERDI RIYANDI', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(315, '10208847', '0048944250', 'PUPUT AGUSTINA', 'P', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(316, '10208846', '3068896065', 'PUTRA OTI PRATAMA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(317, '10208879', '0044040665', 'RAMA SAPUTRA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(318, '10208865', '0051019582', 'REZA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(319, '10208889', '0035097265', 'RIVAL', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(320, '10208854', '0045497201', 'SURYA KURNIAWAN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(321, '10208840', '0057422318', 'TEGUH IMANUDIN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(322, '10208876', '0040792137', 'VITO ANDRA TITAN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(323, '10208883', '0045314649', 'YUSRIL IRSANDI', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(324, '-', '-', 'OO', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(325, '-', '-', 'PP', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Otomotif', 'Teknik dan Bisnis Sepeda Motor', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(326, '10208899', '0049456938', 'ADINDA DEVITA SILVI', 'P', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(327, '10208905', '0052416760', 'AHMAD RIVALDI', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(328, '10208915', '0051019597', 'ALIPIA PUTRI SALSABILA', 'P', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(329, '10208917', '3042418865', 'ALVIN HIDAYAT', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(330, '10208986', '0051493935', 'AMANDA', 'P', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(331, '10208893', '0056880560', 'AMANDA PUTRI', 'P', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(332, '10208909', '0056454644', 'ANDIKA SAPUTRA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(333, '10208896', '0059303290', 'ANITA ANNASTASYA', 'P', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(334, '10208913', '0047859249', 'ARIEL ADRIAN SAPUTRA ', 'P', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(335, '10208922', '0041543130', 'DIMAS ANDRAYAN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(336, '10208906', '0048134797', 'EKA PRASETYA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(337, '10208818', '0046775800', 'EVRILIANI', 'P', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(338, '10208918', '0035333298', 'FARREL DEFIMA NUSKA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(339, '10208928', '3049635575', 'HERLINA SARI', 'P', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(340, '10208912', '0045314637', 'HILDA LESTARI', 'P', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(341, '10208916', '0051413384', 'ILHAM DICKY PRATAMA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(342, '10208921', '0037046026', 'IMELDA', 'P', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(343, '10208895', '0040832672', 'INDRI AMELIA LESTARI', 'P', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(344, '10208924', '3059552434', 'INKA SALSABILA SAHWA', 'P', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(345, '10208910', '0056430136', 'KAMAL ARDABILA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(346, '10208908', '0050771575', 'KHAIRIL SEPTA WIJAYA', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(347, '10208892', '0035358124', 'MIA DESTIA', 'P', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(348, '10208904', '0053447424', 'MUHAMAD AL-FATIH DARUSSALAM', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(349, '10208903', '0035864530', 'MUHAMAD ASTARUKUS', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(350, '10208900', '0067223583', 'MUHAMAD IRDAN ARDIANSYAH', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(351, '10208907', '0045610926', 'MULPIANSYAH ALKAHPI', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(352, '10208919', '0060018313', 'PASYA RAMDANIA', 'P', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(353, '10208894', '3047413145', 'RIFAL ALFARIZI', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(354, '10208898', '0044959358', 'RIKA AMELIA', 'P', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(355, '10208940', '0035723601', 'RIPALDO', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(356, '10208911', '0054448927', 'SITI ROGHIBATUL JANNAH', 'P', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(357, '10208897', '0026102584', 'SRI WINENGSIH', 'P', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(358, '10208902', '0045340204', 'SUSAN SANTOSO', 'P', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(359, '10208901', '0045911654', 'WAHYU RAMADHAN MUKTI', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(360, '10208875', '0042477451', 'ZAHWA NURSABILA', 'P', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(361, '-', '-', 'QQ', 'P', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(362, '-', '-', 'RR', 'P', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Komputer & Informatika', 'Teknik Komputer & Jaringan', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(363, '10208926', '0030738199', 'ASMA PADILAH', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Komputer & Informatika', 'Multimedia', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(364, '10208914', '0052182034', 'AULIA BILQIS EDWINA CHANIAGO', 'P', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Komputer & Informatika', 'Multimedia', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(365, '10208932', '0047136645', 'FASYA JULIA MAULANA', 'P', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Komputer & Informatika', 'Multimedia', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(366, '10208934', '3046045662', 'INTAN AMELIA', 'P', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Komputer & Informatika', 'Multimedia', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(367, '10208930', '3042726637', 'MOCHAMAD CHAERAHMAN FADLI', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Komputer & Informatika', 'Multimedia', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(368, '10208935', '0053798026', 'MUHAMAD FURKON RAMADAN', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Komputer & Informatika', 'Multimedia', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(369, '-', '-', 'SS', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Komputer & Informatika', 'Multimedia', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', ''),
(370, '-', '-', 'TT', 'L', '-', '0000-00-00', 'Islam', 'AK', '-', '-', '-', '-', '-', '-', 'X', '2020-07-13', 1, 'Teknik Komputer & Informatika', 'Multimedia', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 0, '2022-12-16 04:22:41', '0000-00-00 00:00:00', 'A', '');

-- --------------------------------------------------------

--
-- Table structure for table `tahun`
--

CREATE TABLE `tahun` (
  `id` int(3) NOT NULL,
  `tahun` varchar(5) NOT NULL,
  `aktif` enum('Y','N') NOT NULL,
  `nama_kepsek` varchar(50) NOT NULL,
  `nip_kepsek` varchar(30) NOT NULL,
  `tgl_raport` date NOT NULL,
  `tgl_raport_kelas3` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tahun`
--

INSERT INTO `tahun` (`id`, `tahun`, `aktif`, `nama_kepsek`, `nip_kepsek`, `tgl_raport`, `tgl_raport_kelas3`) VALUES
(1, '20212', 'N', 'Mahsun Yunani, M.Pd.', '-', '2022-06-24', '2022-06-02'),
(2, '20211', 'N', 'Mahsun Yunani, M.Pd.', '-', '2021-12-23', '2021-12-23'),
(3, '20221', 'Y', 'Mahsun Yunani, M.Pd.', '-', '2022-12-23', '2022-12-23');

-- --------------------------------------------------------

--
-- Table structure for table `t_c_akademik`
--

CREATE TABLE `t_c_akademik` (
  `id` int(6) NOT NULL,
  `id_siswa` int(6) NOT NULL,
  `ta` char(5) NOT NULL,
  `catatan_akademik` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `t_guru_mapel`
--

CREATE TABLE `t_guru_mapel` (
  `id` int(6) NOT NULL,
  `tasm` varchar(5) DEFAULT NULL,
  `id_guru` int(3) NOT NULL,
  `id_kelas` int(3) NOT NULL,
  `id_mapel` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t_guru_mapel`
--

INSERT INTO `t_guru_mapel` (`id`, `tasm`, `id_guru`, `id_kelas`, `id_mapel`) VALUES
(1, '20221', 9, 9, 113),
(2, '20221', 9, 17, 113),
(3, '20221', 9, 18, 113),
(4, '20221', 9, 17, 116),
(5, '20221', 9, 10, 109),
(6, '20221', 12, 12, 109),
(7, '20221', 12, 9, 109),
(8, '20221', 12, 19, 109),
(9, '20221', 10, 9, 114),
(10, '20221', 10, 10, 114),
(11, '20221', 10, 17, 114),
(12, '20221', 10, 18, 114),
(13, '20221', 10, 18, 116),
(14, '20221', 11, 17, 109),
(15, '20221', 13, 23, 131),
(16, '20221', 13, 14, 126),
(17, '20221', 13, 22, 126),
(18, '20221', 12, 20, 109),
(19, '20221', 14, 23, 97),
(20, '20221', 14, 21, 97),
(21, '20221', 14, 17, 97),
(22, '20221', 14, 18, 97),
(23, '20221', 14, 22, 97),
(24, '20221', 14, 19, 97),
(25, '20221', 14, 20, 97),
(26, '20221', 15, 16, 95),
(27, '20221', 15, 13, 95),
(28, '20221', 15, 9, 95),
(29, '20221', 15, 10, 95),
(30, '20221', 15, 14, 95),
(32, '20221', 15, 11, 95),
(33, '20221', 15, 12, 95),
(34, '20221', 15, 23, 95),
(35, '20221', 15, 21, 95),
(36, '20221', 15, 17, 95),
(37, '20221', 15, 18, 95),
(38, '20221', 15, 22, 95),
(39, '20221', 15, 19, 95),
(40, '20221', 15, 20, 95),
(41, '20221', 31, 18, 109),
(42, '20221', 31, 11, 102),
(43, '20221', 31, 16, 102),
(44, '20221', 31, 13, 102),
(45, '20221', 31, 9, 102),
(46, '20221', 31, 10, 102),
(47, '20221', 31, 14, 102),
(48, '20221', 31, 12, 102),
(49, '20221', 17, 16, 97),
(50, '20221', 17, 13, 97),
(51, '20221', 17, 9, 97),
(52, '20221', 17, 10, 97),
(53, '20221', 17, 14, 97),
(54, '20221', 17, 11, 97),
(55, '20221', 17, 12, 97),
(56, '20221', 21, 9, 115),
(57, '20221', 21, 10, 115),
(58, '20221', 21, 17, 115),
(59, '20221', 21, 18, 115),
(60, '20221', 37, 16, 130),
(61, '20221', 37, 16, 129),
(62, '20221', 24, 23, 132),
(64, '20221', 25, 11, 110),
(65, '20221', 25, 12, 110),
(66, '20221', 25, 19, 110),
(67, '20221', 25, 20, 110),
(68, '20221', 26, 16, 98),
(69, '20221', 26, 13, 98),
(70, '20221', 26, 9, 98),
(71, '20221', 26, 10, 98),
(72, '20221', 26, 14, 98),
(73, '20221', 26, 11, 98),
(74, '20221', 26, 12, 98),
(75, '20221', 26, 23, 98),
(76, '20221', 26, 21, 98),
(77, '20221', 26, 17, 98),
(78, '20221', 26, 18, 98),
(79, '20221', 26, 22, 98),
(80, '20221', 26, 19, 98),
(81, '20221', 26, 20, 98),
(82, '20221', 36, 22, 128),
(83, '20221', 36, 14, 127),
(84, '20221', 36, 22, 127),
(85, '20221', 36, 23, 109),
(86, '20221', 29, 11, 112),
(87, '20221', 29, 12, 112),
(88, '20221', 29, 19, 112),
(89, '20221', 29, 20, 112),
(90, '20221', 29, 11, 109),
(91, '20221', 30, 11, 111),
(92, '20221', 30, 12, 111),
(93, '20221', 30, 19, 111),
(94, '20221', 30, 20, 111),
(95, '20221', 32, 16, 96),
(96, '20221', 32, 13, 96),
(97, '20221', 32, 9, 96),
(98, '20221', 32, 10, 96),
(99, '20221', 32, 14, 96),
(100, '20221', 32, 11, 96),
(101, '20221', 32, 12, 96),
(102, '20221', 32, 23, 96),
(103, '20221', 32, 21, 96),
(104, '20221', 32, 17, 96),
(105, '20221', 32, 18, 96),
(106, '20221', 32, 22, 96),
(107, '20221', 32, 19, 96),
(108, '20221', 32, 20, 96),
(109, '20221', 49, 16, 94),
(110, '20221', 49, 13, 94),
(111, '20221', 49, 9, 94),
(112, '20221', 49, 10, 94),
(113, '20221', 49, 14, 94),
(114, '20221', 49, 11, 94),
(115, '20221', 49, 12, 94),
(116, '20221', 50, 23, 94),
(117, '20221', 50, 21, 94),
(118, '20221', 50, 17, 94),
(119, '20221', 50, 18, 94),
(120, '20221', 50, 22, 94),
(121, '20221', 50, 19, 94),
(122, '20221', 50, 20, 94),
(123, '20221', 51, 14, 128),
(124, '20221', 51, 14, 109),
(125, '20221', 13, 14, 125),
(126, '20221', 37, 16, 109),
(128, '20221', 30, 21, 120),
(129, '20221', 30, 21, 119),
(130, '20221', 24, 22, 109),
(131, '20221', 21, 10, 113),
(132, '20221', 30, 21, 109),
(133, '20221', 30, 13, 109),
(134, '20221', 30, 13, 117),
(135, '20221', 30, 13, 118);

-- --------------------------------------------------------

--
-- Table structure for table `t_karakter`
--

CREATE TABLE `t_karakter` (
  `id` int(6) NOT NULL,
  `ta` varchar(5) DEFAULT NULL,
  `id_guru_mapel` int(6) DEFAULT NULL,
  `id_siswa` int(6) DEFAULT NULL,
  `is_wali` enum('Y','N') DEFAULT NULL,
  `integritas` longtext,
  `religius` longtext,
  `nasionalis` longtext,
  `mandiri` longtext,
  `gotong` longtext,
  `catatan` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `t_kelas_siswa`
--

CREATE TABLE `t_kelas_siswa` (
  `id` int(5) NOT NULL,
  `id_kelas` int(5) NOT NULL,
  `id_siswa` int(5) NOT NULL,
  `ta` year(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t_kelas_siswa`
--

INSERT INTO `t_kelas_siswa` (`id`, `id_kelas`, `id_siswa`, `ta`) VALUES
(65, 9, 69, 2022),
(66, 9, 70, 2022),
(67, 9, 71, 2022),
(68, 9, 72, 2022),
(69, 9, 73, 2022),
(70, 9, 74, 2022),
(71, 9, 75, 2022),
(72, 9, 76, 2022),
(73, 9, 77, 2022),
(74, 9, 78, 2022),
(75, 9, 79, 2022),
(76, 9, 80, 2022),
(77, 9, 81, 2022),
(78, 9, 82, 2022),
(79, 9, 83, 2022),
(80, 9, 84, 2022),
(81, 9, 85, 2022),
(82, 9, 86, 2022),
(83, 9, 87, 2022),
(84, 9, 88, 2022),
(85, 9, 89, 2022),
(86, 9, 90, 2022),
(87, 9, 91, 2022),
(88, 9, 92, 2022),
(89, 9, 93, 2022),
(90, 9, 94, 2022),
(91, 9, 95, 2022),
(92, 9, 96, 2022),
(93, 9, 97, 2022),
(94, 9, 98, 2022),
(95, 9, 99, 2022),
(96, 9, 100, 2022),
(97, 9, 101, 2022),
(98, 9, 102, 2022),
(99, 9, 103, 2022),
(100, 9, 104, 2022),
(101, 9, 105, 2022),
(102, 9, 106, 2022),
(103, 9, 107, 2022),
(104, 10, 108, 2022),
(105, 10, 109, 2022),
(106, 10, 110, 2022),
(107, 10, 111, 2022),
(108, 10, 112, 2022),
(109, 10, 113, 2022),
(110, 10, 114, 2022),
(111, 10, 115, 2022),
(112, 10, 116, 2022),
(113, 10, 117, 2022),
(114, 10, 118, 2022),
(115, 10, 119, 2022),
(116, 10, 120, 2022),
(117, 10, 121, 2022),
(118, 10, 122, 2022),
(119, 10, 123, 2022),
(120, 10, 124, 2022),
(121, 10, 125, 2022),
(122, 10, 126, 2022),
(123, 10, 127, 2022),
(124, 10, 128, 2022),
(125, 10, 129, 2022),
(126, 10, 130, 2022),
(127, 10, 131, 2022),
(128, 10, 132, 2022),
(129, 10, 133, 2022),
(130, 10, 134, 2022),
(131, 10, 135, 2022),
(132, 10, 136, 2022),
(133, 10, 137, 2022),
(134, 10, 138, 2022),
(135, 10, 139, 2022),
(136, 10, 140, 2022),
(137, 10, 141, 2022),
(138, 10, 142, 2022),
(139, 10, 143, 2022),
(140, 10, 144, 2022),
(141, 10, 145, 2022),
(1, 11, 1, 2022),
(2, 11, 2, 2022),
(3, 11, 3, 2022),
(4, 11, 4, 2022),
(5, 11, 5, 2022),
(6, 11, 6, 2022),
(7, 11, 7, 2022),
(8, 11, 8, 2022),
(9, 11, 9, 2022),
(10, 11, 10, 2022),
(11, 11, 11, 2022),
(12, 11, 12, 2022),
(13, 11, 13, 2022),
(14, 11, 14, 2022),
(15, 11, 15, 2022),
(16, 11, 16, 2022),
(17, 11, 17, 2022),
(18, 11, 18, 2022),
(19, 11, 19, 2022),
(20, 11, 20, 2022),
(21, 11, 21, 2022),
(22, 11, 22, 2022),
(23, 11, 23, 2022),
(24, 11, 24, 2022),
(25, 11, 25, 2022),
(26, 11, 26, 2022),
(27, 11, 27, 2022),
(28, 11, 28, 2022),
(29, 11, 29, 2022),
(30, 11, 30, 2022),
(31, 11, 31, 2022),
(32, 11, 32, 2022),
(33, 12, 33, 2022),
(34, 12, 34, 2022),
(35, 12, 35, 2022),
(36, 12, 36, 2022),
(37, 12, 37, 2022),
(38, 12, 38, 2022),
(39, 12, 39, 2022),
(40, 12, 40, 2022),
(41, 12, 41, 2022),
(42, 12, 42, 2022),
(43, 12, 43, 2022),
(44, 12, 44, 2022),
(45, 12, 45, 2022),
(46, 12, 46, 2022),
(47, 12, 47, 2022),
(48, 12, 48, 2022),
(49, 12, 49, 2022),
(50, 12, 50, 2022),
(51, 12, 51, 2022),
(52, 12, 52, 2022),
(53, 12, 53, 2022),
(54, 12, 54, 2022),
(55, 13, 57, 2022),
(56, 13, 58, 2022),
(57, 13, 59, 2022),
(58, 13, 60, 2022),
(59, 13, 61, 2022),
(60, 13, 62, 2022),
(61, 13, 63, 2022),
(62, 13, 64, 2022),
(63, 13, 65, 2022),
(64, 13, 66, 2022),
(142, 14, 148, 2022),
(143, 14, 149, 2022),
(144, 14, 150, 2022),
(145, 14, 151, 2022),
(146, 14, 152, 2022),
(147, 14, 153, 2022),
(148, 14, 154, 2022),
(149, 14, 155, 2022),
(150, 14, 156, 2022),
(151, 14, 157, 2022),
(152, 14, 158, 2022),
(153, 14, 159, 2022),
(154, 14, 160, 2022),
(155, 14, 161, 2022),
(156, 14, 162, 2022),
(157, 14, 163, 2022),
(158, 14, 164, 2022),
(159, 14, 165, 2022),
(160, 14, 166, 2022),
(161, 14, 167, 2022),
(162, 14, 168, 2022),
(163, 14, 169, 2022),
(164, 14, 170, 2022),
(165, 14, 171, 2022),
(166, 14, 172, 2022),
(167, 14, 173, 2022),
(168, 14, 174, 2022),
(169, 14, 175, 2022),
(170, 14, 176, 2022),
(171, 14, 177, 2022),
(172, 14, 178, 2022),
(173, 14, 179, 2022),
(174, 14, 180, 2022),
(175, 14, 181, 2022),
(176, 16, 184, 2022),
(177, 16, 185, 2022),
(178, 16, 186, 2022),
(179, 16, 187, 2022),
(180, 16, 188, 2022),
(181, 16, 189, 2022),
(182, 16, 190, 2022),
(183, 16, 191, 2022),
(184, 16, 192, 2022),
(185, 16, 193, 2022),
(186, 16, 194, 2022),
(187, 16, 195, 2022),
(188, 16, 196, 2022),
(189, 16, 197, 2022),
(190, 16, 198, 2022),
(191, 16, 199, 2022),
(192, 16, 200, 2022),
(193, 16, 201, 2022),
(247, 17, 261, 2022),
(248, 17, 262, 2022),
(249, 17, 263, 2022),
(250, 17, 264, 2022),
(251, 17, 265, 2022),
(252, 17, 266, 2022),
(253, 17, 267, 2022),
(254, 17, 268, 2022),
(255, 17, 269, 2022),
(256, 17, 270, 2022),
(257, 17, 271, 2022),
(258, 17, 272, 2022),
(259, 17, 273, 2022),
(260, 17, 274, 2022),
(261, 17, 275, 2022),
(262, 17, 276, 2022),
(263, 17, 277, 2022),
(264, 17, 278, 2022),
(265, 17, 279, 2022),
(266, 17, 280, 2022),
(267, 17, 281, 2022),
(268, 17, 282, 2022),
(269, 17, 283, 2022),
(270, 17, 284, 2022),
(271, 17, 285, 2022),
(272, 17, 286, 2022),
(273, 17, 287, 2022),
(274, 17, 288, 2022),
(275, 17, 289, 2022),
(276, 17, 290, 2022),
(277, 17, 291, 2022),
(278, 18, 292, 2022),
(279, 18, 293, 2022),
(280, 18, 294, 2022),
(281, 18, 295, 2022),
(282, 18, 296, 2022),
(283, 18, 297, 2022),
(284, 18, 298, 2022),
(285, 18, 299, 2022),
(286, 18, 300, 2022),
(287, 18, 301, 2022),
(288, 18, 302, 2022),
(289, 18, 303, 2022),
(290, 18, 304, 2022),
(291, 18, 305, 2022),
(292, 18, 306, 2022),
(293, 18, 307, 2022),
(294, 18, 308, 2022),
(295, 18, 309, 2022),
(296, 18, 310, 2022),
(297, 18, 311, 2022),
(298, 18, 312, 2022),
(299, 18, 313, 2022),
(300, 18, 314, 2022),
(301, 18, 315, 2022),
(302, 18, 316, 2022),
(303, 18, 317, 2022),
(304, 18, 318, 2022),
(305, 18, 319, 2022),
(306, 18, 320, 2022),
(307, 18, 321, 2022),
(308, 18, 322, 2022),
(309, 18, 323, 2022),
(194, 19, 204, 2022),
(195, 19, 205, 2022),
(196, 19, 206, 2022),
(197, 19, 207, 2022),
(198, 19, 208, 2022),
(199, 19, 209, 2022),
(200, 19, 210, 2022),
(201, 19, 211, 2022),
(202, 19, 212, 2022),
(203, 19, 213, 2022),
(204, 19, 214, 2022),
(205, 19, 215, 2022),
(206, 19, 216, 2022),
(207, 19, 217, 2022),
(208, 19, 218, 2022),
(209, 19, 219, 2022),
(210, 19, 220, 2022),
(211, 19, 221, 2022),
(212, 19, 222, 2022),
(213, 19, 223, 2022),
(214, 19, 224, 2022),
(215, 19, 225, 2022),
(216, 20, 226, 2022),
(217, 20, 227, 2022),
(218, 20, 228, 2022),
(219, 20, 229, 2022),
(220, 20, 230, 2022),
(221, 20, 231, 2022),
(222, 20, 232, 2022),
(223, 20, 233, 2022),
(224, 20, 234, 2022),
(225, 20, 235, 2022),
(226, 20, 236, 2022),
(227, 20, 237, 2022),
(228, 20, 238, 2022),
(229, 20, 239, 2022),
(230, 20, 240, 2022),
(231, 20, 241, 2022),
(233, 20, 243, 2022),
(234, 20, 244, 2022),
(235, 20, 245, 2022),
(236, 21, 248, 2022),
(237, 21, 249, 2022),
(238, 21, 250, 2022),
(239, 21, 251, 2022),
(240, 21, 252, 2022),
(241, 21, 253, 2022),
(242, 21, 254, 2022),
(243, 21, 255, 2022),
(244, 21, 256, 2022),
(245, 21, 257, 2022),
(246, 21, 258, 2022),
(310, 22, 326, 2022),
(311, 22, 327, 2022),
(312, 22, 328, 2022),
(313, 22, 329, 2022),
(314, 22, 330, 2022),
(315, 22, 331, 2022),
(316, 22, 332, 2022),
(317, 22, 333, 2022),
(318, 22, 334, 2022),
(319, 22, 335, 2022),
(320, 22, 336, 2022),
(321, 22, 337, 2022),
(322, 22, 338, 2022),
(323, 22, 339, 2022),
(324, 22, 340, 2022),
(325, 22, 341, 2022),
(326, 22, 342, 2022),
(327, 22, 343, 2022),
(328, 22, 344, 2022),
(329, 22, 345, 2022),
(330, 22, 346, 2022),
(331, 22, 347, 2022),
(332, 22, 348, 2022),
(333, 22, 349, 2022),
(334, 22, 350, 2022),
(335, 22, 351, 2022),
(336, 22, 352, 2022),
(337, 22, 353, 2022),
(338, 22, 354, 2022),
(339, 22, 355, 2022),
(340, 22, 356, 2022),
(341, 22, 357, 2022),
(342, 22, 358, 2022),
(343, 22, 359, 2022),
(344, 22, 360, 2022),
(345, 23, 363, 2022),
(346, 23, 364, 2022),
(347, 23, 365, 2022),
(348, 23, 366, 2022),
(349, 23, 367, 2022),
(350, 23, 368, 2022);

-- --------------------------------------------------------

--
-- Table structure for table `t_kkm`
--

CREATE TABLE `t_kkm` (
  `id` int(5) NOT NULL,
  `ta` int(4) NOT NULL,
  `jenis` enum('np','nk') NOT NULL,
  `kelas` int(2) NOT NULL,
  `kkm` int(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `t_mapel_kd`
--

CREATE TABLE `t_mapel_kd` (
  `id` int(6) UNSIGNED NOT NULL,
  `id_guru` int(6) UNSIGNED NOT NULL DEFAULT '0',
  `id_mapel` int(6) NOT NULL,
  `tingkat` int(2) NOT NULL,
  `semester` enum('0','1','2') NOT NULL,
  `no_kd` varchar(5) NOT NULL,
  `jenis` enum('P','K','SSp','SSo') NOT NULL,
  `bobot` int(2) NOT NULL,
  `nama_kd` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t_mapel_kd`
--

INSERT INTO `t_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES
(1, 9, 113, 12, '1', '1', 'P', 0, '1'),
(2, 9, 113, 12, '1', '1', 'K', 0, '1'),
(3, 9, 113, 11, '1', '1', 'P', 0, '1'),
(4, 9, 113, 11, '1', '1', 'K', 0, '1'),
(5, 9, 116, 12, '1', '1', 'P', 0, '1'),
(6, 9, 116, 12, '1', '1', 'K', 0, '1'),
(7, 9, 109, 11, '1', '1', 'P', 0, '1'),
(8, 9, 109, 11, '1', '1', 'K', 0, '1'),
(9, 49, 94, 11, '1', '1', 'P', 0, '1'),
(10, 49, 94, 11, '1', '1', 'K', 0, '1'),
(11, 50, 94, 12, '1', '1', 'P', 0, '1'),
(12, 50, 94, 12, '1', '1', 'K', 0, '1'),
(13, 32, 96, 12, '1', '1', 'P', 0, '1'),
(14, 32, 96, 12, '1', '1', 'K', 0, '1'),
(15, 32, 96, 11, '1', '1', 'P', 0, '1'),
(16, 32, 96, 11, '1', '1', 'K', 0, '1'),
(17, 10, 114, 11, '1', '1', 'P', 0, '1'),
(18, 10, 114, 11, '1', '1', 'K', 0, '1'),
(19, 10, 114, 12, '1', '1', 'P', 0, '1'),
(20, 10, 114, 12, '1', '1', 'K', 0, '1'),
(21, 10, 116, 12, '1', '1', 'P', 0, '1'),
(22, 10, 116, 12, '1', '1', 'K', 0, '1'),
(23, 11, 109, 12, '1', '1', 'P', 0, '1'),
(24, 11, 109, 12, '1', '1', 'K', 0, '1'),
(25, 12, 109, 11, '1', '1', 'P', 0, '1'),
(26, 12, 109, 11, '1', '1', 'K', 0, '1'),
(27, 12, 109, 12, '1', '1', 'P', 0, '1'),
(28, 12, 109, 12, '1', '1', 'K', 0, '1'),
(29, 13, 126, 11, '1', '1', 'P', 0, '1'),
(30, 13, 126, 11, '1', '1', 'K', 0, '1'),
(31, 13, 126, 12, '1', '1', 'P', 0, '1'),
(32, 13, 126, 12, '1', '1', 'K', 0, '1'),
(33, 13, 131, 12, '1', '1', 'P', 0, '1'),
(34, 13, 131, 12, '1', '1', 'K', 0, '1'),
(35, 13, 125, 11, '1', '1', 'P', 0, '1'),
(36, 13, 125, 11, '1', '1', 'K', 0, '1'),
(37, 14, 97, 12, '1', '1', 'P', 0, '1'),
(38, 14, 97, 12, '1', '1', 'K', 0, '1'),
(39, 15, 95, 12, '1', '1', 'P', 0, '1'),
(40, 15, 95, 12, '1', '1', 'K', 0, '1'),
(41, 15, 95, 11, '1', '1', 'P', 0, '1'),
(42, 15, 95, 11, '1', '1', 'K', 0, '1'),
(43, 17, 97, 11, '1', '1', 'P', 0, '1'),
(44, 17, 97, 11, '1', '1', 'K', 0, '1'),
(45, 21, 115, 11, '1', '1', 'P', 0, '1'),
(46, 21, 115, 11, '1', '1', 'K', 0, '1'),
(47, 21, 115, 12, '1', '1', 'P', 0, '1'),
(48, 21, 115, 12, '1', '1', 'K', 0, '1'),
(49, 21, 113, 11, '1', '1', 'P', 0, '1'),
(50, 21, 113, 11, '1', '1', 'K', 0, '1'),
(51, 51, 109, 11, '1', '1', 'P', 0, '1'),
(52, 51, 109, 11, '1', '1', 'K', 0, '1'),
(53, 51, 128, 11, '1', '1', 'P', 0, '1'),
(54, 51, 128, 11, '1', '1', 'K', 0, '1'),
(55, 37, 130, 11, '1', '1', 'P', 0, '1'),
(56, 37, 130, 11, '1', '1', 'K', 0, '1'),
(57, 37, 129, 11, '1', '1', 'P', 0, '1'),
(58, 37, 129, 11, '1', '1', 'K', 0, '1'),
(59, 37, 109, 11, '1', '1', 'P', 0, '1'),
(60, 37, 109, 11, '1', '1', 'K', 0, '1'),
(61, 24, 109, 12, '1', '1', 'P', 0, '1'),
(62, 24, 109, 12, '1', '1', 'K', 0, '1'),
(63, 24, 132, 12, '1', '1', 'P', 0, '1'),
(64, 24, 132, 12, '1', '1', 'K', 0, '1'),
(65, 25, 110, 11, '1', '1', 'P', 0, '1'),
(66, 25, 110, 11, '1', '1', 'K', 0, '1'),
(67, 25, 110, 12, '1', '1', 'P', 0, '1'),
(68, 25, 110, 12, '1', '1', 'K', 0, '1'),
(69, 26, 98, 11, '1', '1', 'P', 0, '1'),
(70, 26, 98, 11, '1', '1', 'K', 0, '1'),
(71, 26, 98, 12, '1', '1', 'P', 0, '1'),
(72, 26, 98, 12, '1', '1', 'K', 0, '1'),
(73, 36, 127, 11, '1', '1', 'P', 0, '1'),
(74, 36, 127, 11, '1', '1', 'K', 0, '1'),
(75, 36, 127, 12, '1', '1', 'P', 0, '1'),
(76, 36, 127, 12, '1', '1', 'K', 0, '1'),
(77, 36, 109, 12, '1', '1', 'P', 0, '1'),
(78, 36, 109, 12, '1', '1', 'K', 0, '1'),
(79, 36, 128, 12, '1', '1', 'P', 0, '1'),
(80, 36, 128, 12, '1', '1', 'K', 0, '1'),
(81, 29, 112, 11, '1', '1', 'P', 0, '1'),
(82, 29, 112, 11, '1', '1', 'K', 0, '1'),
(83, 29, 112, 12, '1', '1', 'P', 0, '1'),
(84, 29, 112, 12, '1', '1', 'K', 0, '1'),
(85, 29, 109, 11, '1', '1', 'P', 0, '1'),
(86, 29, 109, 11, '1', '1', 'K', 0, '1'),
(87, 30, 111, 11, '1', '1', 'P', 0, '1'),
(88, 30, 111, 11, '1', '1', 'K', 0, '1'),
(89, 30, 111, 12, '1', '1', 'P', 0, '1'),
(90, 30, 111, 12, '1', '1', 'K', 0, '1'),
(91, 30, 120, 12, '1', '1', 'P', 0, '1'),
(92, 30, 120, 12, '1', '1', 'K', 0, '1'),
(93, 30, 118, 11, '1', '1', 'P', 0, '1'),
(94, 30, 118, 11, '1', '1', 'K', 0, '1'),
(95, 30, 119, 12, '1', '1', 'P', 0, '1'),
(96, 30, 119, 12, '1', '1', 'K', 0, '1'),
(97, 30, 117, 11, '1', '1', 'P', 0, '1'),
(98, 30, 117, 11, '1', '1', 'K', 0, '1'),
(99, 30, 109, 12, '1', '1', 'P', 0, '1'),
(100, 30, 109, 12, '1', '1', 'K', 0, '1'),
(101, 30, 109, 11, '1', '1', 'P', 0, '1'),
(102, 30, 109, 11, '1', '1', 'K', 0, '1'),
(103, 31, 102, 11, '1', '1', 'P', 0, '1'),
(104, 31, 102, 11, '1', '1', 'K', 0, '1'),
(105, 31, 109, 12, '1', '1', 'P', 0, '1'),
(106, 31, 109, 12, '1', '1', 'K', 0, '1');

-- --------------------------------------------------------

--
-- Table structure for table `t_naikkelas`
--

CREATE TABLE `t_naikkelas` (
  `id` int(6) NOT NULL,
  `id_siswa` int(6) NOT NULL,
  `ta` char(5) NOT NULL,
  `naik` enum('Y','N') NOT NULL,
  `catatan_wali` longtext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `t_nilai`
--

CREATE TABLE `t_nilai` (
  `id` int(6) NOT NULL,
  `tasm` varchar(5) NOT NULL DEFAULT '0',
  `jenis` enum('h','t','a') NOT NULL,
  `id_guru_mapel` int(6) NOT NULL,
  `id_mapel_kd` int(6) NOT NULL,
  `id_siswa` int(6) NOT NULL,
  `nilai` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t_nilai`
--

INSERT INTO `t_nilai` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`) VALUES
(228, '20221', 'h', 82, 79, 326, 80),
(231, '20221', 'h', 82, 79, 327, 75),
(234, '20221', 'h', 82, 79, 328, 92),
(237, '20221', 'h', 82, 79, 329, 92),
(240, '20221', 'h', 82, 79, 330, 82),
(243, '20221', 'h', 82, 79, 331, 89),
(246, '20221', 'h', 82, 79, 332, 85),
(249, '20221', 'h', 82, 79, 333, 98),
(252, '20221', 'h', 82, 79, 334, 94),
(255, '20221', 'h', 82, 79, 335, 88),
(258, '20221', 'h', 82, 79, 336, 98),
(261, '20221', 'h', 82, 79, 337, 95),
(264, '20221', 'h', 82, 79, 338, 89),
(267, '20221', 'h', 82, 79, 339, 75),
(270, '20221', 'h', 82, 79, 340, 92),
(273, '20221', 'h', 82, 79, 341, 60),
(276, '20221', 'h', 82, 79, 342, 88),
(279, '20221', 'h', 82, 79, 343, 75),
(282, '20221', 'h', 82, 79, 344, 92),
(285, '20221', 'h', 82, 79, 345, 98),
(288, '20221', 'h', 82, 79, 346, 95),
(291, '20221', 'h', 82, 79, 347, 93),
(294, '20221', 'h', 82, 79, 348, 88),
(297, '20221', 'h', 82, 79, 349, 90),
(300, '20221', 'h', 82, 79, 350, 95),
(303, '20221', 'h', 82, 79, 351, 95),
(306, '20221', 'h', 82, 79, 352, 75),
(309, '20221', 'h', 82, 79, 353, 98),
(312, '20221', 'h', 82, 79, 354, 80),
(315, '20221', 'h', 82, 79, 355, 60),
(318, '20221', 'h', 82, 79, 356, 92),
(321, '20221', 'h', 82, 79, 357, 77),
(324, '20221', 'h', 82, 79, 358, 98),
(327, '20221', 'h', 82, 79, 359, 90),
(330, '20221', 'h', 82, 79, 360, 75),
(126, '20221', 'h', 83, 73, 148, 60),
(129, '20221', 'h', 83, 73, 149, 95),
(132, '20221', 'h', 83, 73, 150, 95),
(135, '20221', 'h', 83, 73, 151, 88),
(138, '20221', 'h', 83, 73, 152, 60),
(141, '20221', 'h', 83, 73, 153, 62),
(144, '20221', 'h', 83, 73, 154, 93),
(147, '20221', 'h', 83, 73, 155, 60),
(150, '20221', 'h', 83, 73, 156, 93),
(153, '20221', 'h', 83, 73, 157, 87),
(156, '20221', 'h', 83, 73, 158, 93),
(159, '20221', 'h', 83, 73, 159, 81),
(162, '20221', 'h', 83, 73, 160, 95),
(165, '20221', 'h', 83, 73, 161, 82),
(168, '20221', 'h', 83, 73, 162, 60),
(171, '20221', 'h', 83, 73, 163, 88),
(174, '20221', 'h', 83, 73, 164, 90),
(180, '20221', 'h', 83, 73, 165, 86),
(183, '20221', 'h', 83, 73, 166, 95),
(186, '20221', 'h', 83, 73, 167, 86),
(189, '20221', 'h', 83, 73, 168, 95),
(192, '20221', 'h', 83, 73, 169, 95),
(195, '20221', 'h', 83, 73, 170, 88),
(198, '20221', 'h', 83, 73, 171, 95),
(201, '20221', 'h', 83, 73, 172, 98),
(204, '20221', 'h', 83, 73, 173, 92),
(207, '20221', 'h', 83, 73, 174, 98),
(210, '20221', 'h', 83, 73, 175, 98),
(213, '20221', 'h', 83, 73, 176, 60),
(216, '20221', 'h', 83, 73, 177, 93),
(219, '20221', 'h', 83, 73, 178, 90),
(222, '20221', 'h', 83, 73, 179, 95),
(225, '20221', 'h', 83, 73, 180, 95),
(177, '20221', 'h', 83, 73, 181, 60),
(21, '20221', 'h', 84, 75, 326, 80),
(24, '20221', 'h', 84, 75, 327, 75),
(27, '20221', 'h', 84, 75, 328, 88),
(30, '20221', 'h', 84, 75, 329, 85),
(33, '20221', 'h', 84, 75, 330, 85),
(36, '20221', 'h', 84, 75, 331, 88),
(39, '20221', 'h', 84, 75, 332, 85),
(42, '20221', 'h', 84, 75, 333, 95),
(45, '20221', 'h', 84, 75, 334, 95),
(48, '20221', 'h', 84, 75, 335, 88),
(51, '20221', 'h', 84, 75, 336, 95),
(54, '20221', 'h', 84, 75, 337, 85),
(57, '20221', 'h', 84, 75, 338, 88),
(60, '20221', 'h', 84, 75, 339, 75),
(63, '20221', 'h', 84, 75, 340, 85),
(66, '20221', 'h', 84, 75, 341, 60),
(69, '20221', 'h', 84, 75, 342, 85),
(72, '20221', 'h', 84, 75, 343, 60),
(75, '20221', 'h', 84, 75, 344, 85),
(78, '20221', 'h', 84, 75, 345, 90),
(81, '20221', 'h', 84, 75, 346, 88),
(84, '20221', 'h', 84, 75, 347, 88),
(87, '20221', 'h', 84, 75, 348, 85),
(90, '20221', 'h', 84, 75, 349, 85),
(93, '20221', 'h', 84, 75, 350, 98),
(96, '20221', 'h', 84, 75, 351, 88),
(99, '20221', 'h', 84, 75, 352, 75),
(102, '20221', 'h', 84, 75, 353, 95),
(105, '20221', 'h', 84, 75, 354, 75),
(108, '20221', 'h', 84, 75, 355, 60),
(111, '20221', 'h', 84, 75, 356, 88),
(114, '20221', 'h', 84, 75, 357, 75),
(117, '20221', 'h', 84, 75, 358, 90),
(120, '20221', 'h', 84, 75, 359, 85),
(123, '20221', 'h', 84, 75, 360, 75),
(3, '20221', 'h', 85, 77, 363, 75),
(6, '20221', 'h', 85, 77, 364, 98),
(9, '20221', 'h', 85, 77, 365, 98),
(12, '20221', 'h', 85, 77, 366, 98),
(15, '20221', 'h', 85, 77, 367, 75),
(18, '20221', 'h', 85, 77, 368, 85),
(226, '20221', 't', 82, 128, 326, 80),
(229, '20221', 't', 82, 128, 327, 75),
(232, '20221', 't', 82, 128, 328, 92),
(235, '20221', 't', 82, 128, 329, 92),
(238, '20221', 't', 82, 128, 330, 82),
(241, '20221', 't', 82, 128, 331, 89),
(244, '20221', 't', 82, 128, 332, 85),
(247, '20221', 't', 82, 128, 333, 98),
(250, '20221', 't', 82, 128, 334, 94),
(253, '20221', 't', 82, 128, 335, 88),
(256, '20221', 't', 82, 128, 336, 98),
(259, '20221', 't', 82, 128, 337, 95),
(262, '20221', 't', 82, 128, 338, 89),
(265, '20221', 't', 82, 128, 339, 75),
(268, '20221', 't', 82, 128, 340, 92),
(271, '20221', 't', 82, 128, 341, 60),
(274, '20221', 't', 82, 128, 342, 88),
(277, '20221', 't', 82, 128, 343, 75),
(280, '20221', 't', 82, 128, 344, 92),
(283, '20221', 't', 82, 128, 345, 98),
(286, '20221', 't', 82, 128, 346, 95),
(289, '20221', 't', 82, 128, 347, 93),
(292, '20221', 't', 82, 128, 348, 88),
(295, '20221', 't', 82, 128, 349, 90),
(298, '20221', 't', 82, 128, 350, 95),
(301, '20221', 't', 82, 128, 351, 95),
(304, '20221', 't', 82, 128, 352, 75),
(307, '20221', 't', 82, 128, 353, 98),
(310, '20221', 't', 82, 128, 354, 80),
(313, '20221', 't', 82, 128, 355, 60),
(316, '20221', 't', 82, 128, 356, 92),
(319, '20221', 't', 82, 128, 357, 77),
(322, '20221', 't', 82, 128, 358, 98),
(325, '20221', 't', 82, 128, 359, 90),
(328, '20221', 't', 82, 128, 360, 75),
(124, '20221', 't', 83, 127, 148, 60),
(127, '20221', 't', 83, 127, 149, 95),
(130, '20221', 't', 83, 127, 150, 95),
(133, '20221', 't', 83, 127, 151, 88),
(136, '20221', 't', 83, 127, 152, 60),
(139, '20221', 't', 83, 127, 153, 62),
(142, '20221', 't', 83, 127, 154, 93),
(145, '20221', 't', 83, 127, 155, 60),
(148, '20221', 't', 83, 127, 156, 93),
(151, '20221', 't', 83, 127, 157, 87),
(154, '20221', 't', 83, 127, 158, 93),
(157, '20221', 't', 83, 127, 159, 81),
(160, '20221', 't', 83, 127, 160, 95),
(163, '20221', 't', 83, 127, 161, 82),
(166, '20221', 't', 83, 127, 162, 60),
(169, '20221', 't', 83, 127, 163, 88),
(172, '20221', 't', 83, 127, 164, 90),
(178, '20221', 't', 83, 127, 165, 86),
(181, '20221', 't', 83, 127, 166, 95),
(184, '20221', 't', 83, 127, 167, 86),
(187, '20221', 't', 83, 127, 168, 95),
(190, '20221', 't', 83, 127, 169, 95),
(193, '20221', 't', 83, 127, 170, 88),
(196, '20221', 't', 83, 127, 171, 95),
(199, '20221', 't', 83, 127, 172, 98),
(202, '20221', 't', 83, 127, 173, 92),
(205, '20221', 't', 83, 127, 174, 98),
(208, '20221', 't', 83, 127, 175, 98),
(211, '20221', 't', 83, 127, 176, 60),
(214, '20221', 't', 83, 127, 177, 93),
(217, '20221', 't', 83, 127, 178, 90),
(220, '20221', 't', 83, 127, 179, 95),
(223, '20221', 't', 83, 127, 180, 95),
(175, '20221', 't', 83, 127, 181, 60),
(19, '20221', 't', 84, 127, 326, 80),
(22, '20221', 't', 84, 127, 327, 75),
(25, '20221', 't', 84, 127, 328, 88),
(28, '20221', 't', 84, 127, 329, 85),
(31, '20221', 't', 84, 127, 330, 85),
(34, '20221', 't', 84, 127, 331, 88),
(37, '20221', 't', 84, 127, 332, 85),
(40, '20221', 't', 84, 127, 333, 95),
(43, '20221', 't', 84, 127, 334, 95),
(46, '20221', 't', 84, 127, 335, 88),
(49, '20221', 't', 84, 127, 336, 95),
(52, '20221', 't', 84, 127, 337, 85),
(55, '20221', 't', 84, 127, 338, 88),
(58, '20221', 't', 84, 127, 339, 75),
(61, '20221', 't', 84, 127, 340, 85),
(64, '20221', 't', 84, 127, 341, 60),
(67, '20221', 't', 84, 127, 342, 85),
(70, '20221', 't', 84, 127, 343, 60),
(73, '20221', 't', 84, 127, 344, 85),
(76, '20221', 't', 84, 127, 345, 90),
(79, '20221', 't', 84, 127, 346, 88),
(82, '20221', 't', 84, 127, 347, 88),
(85, '20221', 't', 84, 127, 348, 85),
(88, '20221', 't', 84, 127, 349, 85),
(91, '20221', 't', 84, 127, 350, 98),
(94, '20221', 't', 84, 127, 351, 88),
(97, '20221', 't', 84, 127, 352, 75),
(100, '20221', 't', 84, 127, 353, 95),
(103, '20221', 't', 84, 127, 354, 75),
(106, '20221', 't', 84, 127, 355, 60),
(109, '20221', 't', 84, 127, 356, 88),
(112, '20221', 't', 84, 127, 357, 75),
(115, '20221', 't', 84, 127, 358, 90),
(118, '20221', 't', 84, 127, 359, 85),
(121, '20221', 't', 84, 127, 360, 75),
(1, '20221', 't', 85, 109, 363, 75),
(4, '20221', 't', 85, 109, 364, 98),
(7, '20221', 't', 85, 109, 365, 98),
(10, '20221', 't', 85, 109, 366, 98),
(13, '20221', 't', 85, 109, 367, 75),
(16, '20221', 't', 85, 109, 368, 85),
(227, '20221', 'a', 82, 128, 326, 80),
(230, '20221', 'a', 82, 128, 327, 75),
(233, '20221', 'a', 82, 128, 328, 92),
(236, '20221', 'a', 82, 128, 329, 92),
(239, '20221', 'a', 82, 128, 330, 82),
(242, '20221', 'a', 82, 128, 331, 89),
(245, '20221', 'a', 82, 128, 332, 85),
(248, '20221', 'a', 82, 128, 333, 98),
(251, '20221', 'a', 82, 128, 334, 94),
(254, '20221', 'a', 82, 128, 335, 88),
(257, '20221', 'a', 82, 128, 336, 98),
(260, '20221', 'a', 82, 128, 337, 95),
(263, '20221', 'a', 82, 128, 338, 89),
(266, '20221', 'a', 82, 128, 339, 75),
(269, '20221', 'a', 82, 128, 340, 92),
(272, '20221', 'a', 82, 128, 341, 60),
(275, '20221', 'a', 82, 128, 342, 88),
(278, '20221', 'a', 82, 128, 343, 75),
(281, '20221', 'a', 82, 128, 344, 92),
(284, '20221', 'a', 82, 128, 345, 98),
(287, '20221', 'a', 82, 128, 346, 95),
(290, '20221', 'a', 82, 128, 347, 93),
(293, '20221', 'a', 82, 128, 348, 88),
(296, '20221', 'a', 82, 128, 349, 90),
(299, '20221', 'a', 82, 128, 350, 95),
(302, '20221', 'a', 82, 128, 351, 95),
(305, '20221', 'a', 82, 128, 352, 75),
(308, '20221', 'a', 82, 128, 353, 98),
(311, '20221', 'a', 82, 128, 354, 80),
(314, '20221', 'a', 82, 128, 355, 60),
(317, '20221', 'a', 82, 128, 356, 92),
(320, '20221', 'a', 82, 128, 357, 77),
(323, '20221', 'a', 82, 128, 358, 98),
(326, '20221', 'a', 82, 128, 359, 90),
(329, '20221', 'a', 82, 128, 360, 75),
(125, '20221', 'a', 83, 127, 148, 60),
(128, '20221', 'a', 83, 127, 149, 95),
(131, '20221', 'a', 83, 127, 150, 95),
(134, '20221', 'a', 83, 127, 151, 88),
(137, '20221', 'a', 83, 127, 152, 60),
(140, '20221', 'a', 83, 127, 153, 62),
(143, '20221', 'a', 83, 127, 154, 93),
(146, '20221', 'a', 83, 127, 155, 60),
(149, '20221', 'a', 83, 127, 156, 93),
(152, '20221', 'a', 83, 127, 157, 87),
(155, '20221', 'a', 83, 127, 158, 93),
(158, '20221', 'a', 83, 127, 159, 81),
(161, '20221', 'a', 83, 127, 160, 95),
(164, '20221', 'a', 83, 127, 161, 82),
(167, '20221', 'a', 83, 127, 162, 60),
(170, '20221', 'a', 83, 127, 163, 88),
(173, '20221', 'a', 83, 127, 164, 90),
(179, '20221', 'a', 83, 127, 165, 86),
(182, '20221', 'a', 83, 127, 166, 95),
(185, '20221', 'a', 83, 127, 167, 86),
(188, '20221', 'a', 83, 127, 168, 95),
(191, '20221', 'a', 83, 127, 169, 95),
(194, '20221', 'a', 83, 127, 170, 88),
(197, '20221', 'a', 83, 127, 171, 95),
(200, '20221', 'a', 83, 127, 172, 98),
(203, '20221', 'a', 83, 127, 173, 92),
(206, '20221', 'a', 83, 127, 174, 98),
(209, '20221', 'a', 83, 127, 175, 98),
(212, '20221', 'a', 83, 127, 176, 60),
(215, '20221', 'a', 83, 127, 177, 93),
(218, '20221', 'a', 83, 127, 178, 90),
(221, '20221', 'a', 83, 127, 179, 95),
(224, '20221', 'a', 83, 127, 180, 95),
(176, '20221', 'a', 83, 127, 181, 60),
(20, '20221', 'a', 84, 127, 326, 80),
(23, '20221', 'a', 84, 127, 327, 75),
(26, '20221', 'a', 84, 127, 328, 88),
(29, '20221', 'a', 84, 127, 329, 85),
(32, '20221', 'a', 84, 127, 330, 85),
(35, '20221', 'a', 84, 127, 331, 88),
(38, '20221', 'a', 84, 127, 332, 85),
(41, '20221', 'a', 84, 127, 333, 95),
(44, '20221', 'a', 84, 127, 334, 95),
(47, '20221', 'a', 84, 127, 335, 88),
(50, '20221', 'a', 84, 127, 336, 95),
(53, '20221', 'a', 84, 127, 337, 85),
(56, '20221', 'a', 84, 127, 338, 88),
(59, '20221', 'a', 84, 127, 339, 75),
(62, '20221', 'a', 84, 127, 340, 85),
(65, '20221', 'a', 84, 127, 341, 60),
(68, '20221', 'a', 84, 127, 342, 85),
(71, '20221', 'a', 84, 127, 343, 60),
(74, '20221', 'a', 84, 127, 344, 85),
(77, '20221', 'a', 84, 127, 345, 90),
(80, '20221', 'a', 84, 127, 346, 88),
(83, '20221', 'a', 84, 127, 347, 88),
(86, '20221', 'a', 84, 127, 348, 85),
(89, '20221', 'a', 84, 127, 349, 85),
(92, '20221', 'a', 84, 127, 350, 98),
(95, '20221', 'a', 84, 127, 351, 88),
(98, '20221', 'a', 84, 127, 352, 75),
(101, '20221', 'a', 84, 127, 353, 95),
(104, '20221', 'a', 84, 127, 354, 75),
(107, '20221', 'a', 84, 127, 355, 60),
(110, '20221', 'a', 84, 127, 356, 88),
(113, '20221', 'a', 84, 127, 357, 75),
(116, '20221', 'a', 84, 127, 358, 90),
(119, '20221', 'a', 84, 127, 359, 85),
(122, '20221', 'a', 84, 127, 360, 75),
(2, '20221', 'a', 85, 109, 363, 75),
(5, '20221', 'a', 85, 109, 364, 98),
(8, '20221', 'a', 85, 109, 365, 98),
(11, '20221', 'a', 85, 109, 366, 98),
(14, '20221', 'a', 85, 109, 367, 75),
(17, '20221', 'a', 85, 109, 368, 85);

-- --------------------------------------------------------

--
-- Table structure for table `t_nilai_absensi`
--

CREATE TABLE `t_nilai_absensi` (
  `id` int(6) NOT NULL,
  `tasm` varchar(5) NOT NULL,
  `id_siswa` int(6) NOT NULL,
  `s` int(3) NOT NULL,
  `i` int(3) NOT NULL,
  `a` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `t_nilai_ekstra`
--

CREATE TABLE `t_nilai_ekstra` (
  `id` int(6) NOT NULL,
  `tasm` varchar(5) NOT NULL,
  `id_ekstra` int(3) NOT NULL,
  `id_siswa` int(6) DEFAULT NULL,
  `nilai` varchar(2) NOT NULL,
  `desk` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `t_nilai_ket`
--

CREATE TABLE `t_nilai_ket` (
  `id` int(6) NOT NULL,
  `tasm` varchar(5) NOT NULL,
  `id_guru_mapel` int(6) NOT NULL,
  `id_mapel_kd` int(6) NOT NULL,
  `id_siswa` int(6) NOT NULL,
  `nilai` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t_nilai_ket`
--

INSERT INTO `t_nilai_ket` (`id`, `tasm`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`) VALUES
(76, '20221', 82, 80, 326, 80),
(77, '20221', 82, 80, 327, 75),
(78, '20221', 82, 80, 328, 92),
(79, '20221', 82, 80, 329, 92),
(80, '20221', 82, 80, 330, 82),
(81, '20221', 82, 80, 331, 89),
(82, '20221', 82, 80, 332, 85),
(83, '20221', 82, 80, 333, 98),
(84, '20221', 82, 80, 334, 94),
(85, '20221', 82, 80, 335, 88),
(86, '20221', 82, 80, 336, 98),
(87, '20221', 82, 80, 337, 95),
(88, '20221', 82, 80, 338, 89),
(89, '20221', 82, 80, 339, 75),
(90, '20221', 82, 80, 340, 92),
(91, '20221', 82, 80, 341, 60),
(92, '20221', 82, 80, 342, 88),
(93, '20221', 82, 80, 343, 75),
(94, '20221', 82, 80, 344, 92),
(95, '20221', 82, 80, 345, 98),
(96, '20221', 82, 80, 346, 95),
(97, '20221', 82, 80, 347, 93),
(98, '20221', 82, 80, 348, 88),
(99, '20221', 82, 80, 349, 90),
(100, '20221', 82, 80, 350, 95),
(101, '20221', 82, 80, 351, 95),
(102, '20221', 82, 80, 352, 75),
(103, '20221', 82, 80, 353, 98),
(104, '20221', 82, 80, 354, 80),
(105, '20221', 82, 80, 355, 60),
(106, '20221', 82, 80, 356, 92),
(107, '20221', 82, 80, 357, 77),
(108, '20221', 82, 80, 358, 98),
(109, '20221', 82, 80, 359, 90),
(110, '20221', 82, 80, 360, 75),
(42, '20221', 83, 74, 148, 60),
(43, '20221', 83, 74, 149, 95),
(44, '20221', 83, 74, 150, 95),
(45, '20221', 83, 74, 151, 88),
(46, '20221', 83, 74, 152, 60),
(47, '20221', 83, 74, 153, 62),
(48, '20221', 83, 74, 154, 93),
(49, '20221', 83, 74, 155, 60),
(50, '20221', 83, 74, 156, 93),
(51, '20221', 83, 74, 157, 87),
(52, '20221', 83, 74, 158, 93),
(53, '20221', 83, 74, 159, 81),
(54, '20221', 83, 74, 160, 95),
(55, '20221', 83, 74, 161, 82),
(56, '20221', 83, 74, 162, 60),
(57, '20221', 83, 74, 163, 88),
(58, '20221', 83, 74, 164, 90),
(60, '20221', 83, 74, 165, 86),
(61, '20221', 83, 74, 166, 95),
(62, '20221', 83, 74, 167, 86),
(63, '20221', 83, 74, 168, 95),
(64, '20221', 83, 74, 169, 95),
(65, '20221', 83, 74, 170, 88),
(66, '20221', 83, 74, 171, 95),
(67, '20221', 83, 74, 172, 98),
(68, '20221', 83, 74, 173, 92),
(69, '20221', 83, 74, 174, 98),
(70, '20221', 83, 74, 175, 98),
(71, '20221', 83, 74, 176, 60),
(72, '20221', 83, 74, 177, 93),
(73, '20221', 83, 74, 178, 90),
(74, '20221', 83, 74, 179, 95),
(75, '20221', 83, 74, 180, 95),
(59, '20221', 83, 74, 181, 60),
(7, '20221', 84, 76, 326, 80),
(8, '20221', 84, 76, 327, 75),
(9, '20221', 84, 76, 328, 88),
(10, '20221', 84, 76, 329, 85),
(11, '20221', 84, 76, 330, 85),
(12, '20221', 84, 76, 331, 88),
(13, '20221', 84, 76, 332, 85),
(14, '20221', 84, 76, 333, 95),
(15, '20221', 84, 76, 334, 95),
(16, '20221', 84, 76, 335, 88),
(17, '20221', 84, 76, 336, 95),
(18, '20221', 84, 76, 337, 85),
(19, '20221', 84, 76, 338, 88),
(20, '20221', 84, 76, 339, 75),
(21, '20221', 84, 76, 340, 85),
(22, '20221', 84, 76, 341, 60),
(23, '20221', 84, 76, 342, 85),
(24, '20221', 84, 76, 343, 60),
(25, '20221', 84, 76, 344, 85),
(26, '20221', 84, 76, 345, 90),
(27, '20221', 84, 76, 346, 88),
(28, '20221', 84, 76, 347, 88),
(29, '20221', 84, 76, 348, 85),
(30, '20221', 84, 76, 349, 85),
(31, '20221', 84, 76, 350, 98),
(32, '20221', 84, 76, 351, 88),
(33, '20221', 84, 76, 352, 75),
(34, '20221', 84, 76, 353, 95),
(35, '20221', 84, 76, 354, 75),
(36, '20221', 84, 76, 355, 60),
(37, '20221', 84, 76, 356, 88),
(38, '20221', 84, 76, 357, 75),
(39, '20221', 84, 76, 358, 90),
(40, '20221', 84, 76, 359, 85),
(41, '20221', 84, 76, 360, 75),
(1, '20221', 85, 78, 363, 75),
(2, '20221', 85, 78, 364, 98),
(3, '20221', 85, 78, 365, 98),
(4, '20221', 85, 78, 366, 98),
(5, '20221', 85, 78, 367, 75),
(6, '20221', 85, 78, 368, 85);

-- --------------------------------------------------------

--
-- Table structure for table `t_pkl`
--

CREATE TABLE `t_pkl` (
  `id` int(6) NOT NULL,
  `id_siswa` int(6) NOT NULL,
  `ta` char(5) NOT NULL,
  `mitra` varchar(30) NOT NULL,
  `lokasi` varchar(30) NOT NULL,
  `lama` varchar(10) NOT NULL,
  `keterangan` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `t_prestasi`
--

CREATE TABLE `t_prestasi` (
  `id` int(6) NOT NULL,
  `id_siswa` int(6) NOT NULL,
  `ta` char(5) NOT NULL,
  `jenis` varchar(100) NOT NULL,
  `keterangan` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `t_walikelas`
--

CREATE TABLE `t_walikelas` (
  `id` int(3) NOT NULL,
  `tasm` varchar(5) DEFAULT NULL,
  `id_guru` int(2) DEFAULT NULL,
  `id_kelas` int(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t_walikelas`
--

INSERT INTO `t_walikelas` (`id`, `tasm`, `id_guru`, `id_kelas`) VALUES
(1, '2022', 10, 9),
(2, '2022', 9, 10),
(3, '2022', 25, 11),
(4, '2022', 29, 12),
(5, '2022', 41, 13),
(6, '2022', 26, 14),
(7, '2022', 24, 16),
(8, '2022', 11, 17),
(9, '2022', 31, 18),
(10, '2022', 12, 19),
(11, '2022', 30, 20),
(12, '2022', 39, 21),
(13, '2022', 44, 22),
(14, '2022', 13, 23);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `m_admin`
--
ALTER TABLE `m_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `m_ekstra`
--
ALTER TABLE `m_ekstra`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `m_guru`
--
ALTER TABLE `m_guru`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `m_kelas`
--
ALTER TABLE `m_kelas`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `m_mapel`
--
ALTER TABLE `m_mapel`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `m_siswa`
--
ALTER TABLE `m_siswa`
  ADD UNIQUE KEY `id` (`id`) USING BTREE;

--
-- Indexes for table `tahun`
--
ALTER TABLE `tahun`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `t_c_akademik`
--
ALTER TABLE `t_c_akademik`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `id_siswa` (`id_siswa`) USING BTREE;

--
-- Indexes for table `t_guru_mapel`
--
ALTER TABLE `t_guru_mapel`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_guru` (`id_guru`),
  ADD KEY `id_kelas` (`id_kelas`),
  ADD KEY `id_mapel` (`id_mapel`);

--
-- Indexes for table `t_karakter`
--
ALTER TABLE `t_karakter`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `t_kelas_siswa`
--
ALTER TABLE `t_kelas_siswa`
  ADD PRIMARY KEY (`id_kelas`,`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `id_siswa` (`id_siswa`);

--
-- Indexes for table `t_kkm`
--
ALTER TABLE `t_kkm`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `t_mapel_kd`
--
ALTER TABLE `t_mapel_kd`
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `id_mapel` (`id_mapel`),
  ADD KEY `id_guru` (`id_guru`);

--
-- Indexes for table `t_naikkelas`
--
ALTER TABLE `t_naikkelas`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `t_nilai`
--
ALTER TABLE `t_nilai`
  ADD PRIMARY KEY (`tasm`,`jenis`,`id_guru_mapel`,`id_mapel_kd`,`id_siswa`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `t_nilai_absensi`
--
ALTER TABLE `t_nilai_absensi`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_siswa` (`id_siswa`);

--
-- Indexes for table `t_nilai_ekstra`
--
ALTER TABLE `t_nilai_ekstra`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_t_nilai_ekstra_m_siswa` (`id_ekstra`),
  ADD KEY `t_nilai_ekstra_ibfk_1` (`id_siswa`);

--
-- Indexes for table `t_nilai_ket`
--
ALTER TABLE `t_nilai_ket`
  ADD PRIMARY KEY (`tasm`,`id_guru_mapel`,`id_mapel_kd`,`id_siswa`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `t_pkl`
--
ALTER TABLE `t_pkl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `t_prestasi`
--
ALTER TABLE `t_prestasi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `t_walikelas`
--
ALTER TABLE `t_walikelas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_guru` (`id_guru`),
  ADD KEY `id_kelas` (`id_kelas`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `m_admin`
--
ALTER TABLE `m_admin`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=99;

--
-- AUTO_INCREMENT for table `m_ekstra`
--
ALTER TABLE `m_ekstra`
  MODIFY `id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `m_guru`
--
ALTER TABLE `m_guru`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `m_kelas`
--
ALTER TABLE `m_kelas`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `m_mapel`
--
ALTER TABLE `m_mapel`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=133;

--
-- AUTO_INCREMENT for table `m_siswa`
--
ALTER TABLE `m_siswa`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=371;

--
-- AUTO_INCREMENT for table `tahun`
--
ALTER TABLE `tahun`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `t_c_akademik`
--
ALTER TABLE `t_c_akademik`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `t_guru_mapel`
--
ALTER TABLE `t_guru_mapel`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=136;

--
-- AUTO_INCREMENT for table `t_karakter`
--
ALTER TABLE `t_karakter`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `t_kelas_siswa`
--
ALTER TABLE `t_kelas_siswa`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=351;

--
-- AUTO_INCREMENT for table `t_kkm`
--
ALTER TABLE `t_kkm`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `t_mapel_kd`
--
ALTER TABLE `t_mapel_kd`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=107;

--
-- AUTO_INCREMENT for table `t_naikkelas`
--
ALTER TABLE `t_naikkelas`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `t_nilai`
--
ALTER TABLE `t_nilai`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=331;

--
-- AUTO_INCREMENT for table `t_nilai_absensi`
--
ALTER TABLE `t_nilai_absensi`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `t_nilai_ekstra`
--
ALTER TABLE `t_nilai_ekstra`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `t_nilai_ket`
--
ALTER TABLE `t_nilai_ket`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=111;

--
-- AUTO_INCREMENT for table `t_pkl`
--
ALTER TABLE `t_pkl`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `t_prestasi`
--
ALTER TABLE `t_prestasi`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `t_walikelas`
--
ALTER TABLE `t_walikelas`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `t_c_akademik`
--
ALTER TABLE `t_c_akademik`
  ADD CONSTRAINT `FK_t_c_akademik_m_siswa` FOREIGN KEY (`id_siswa`) REFERENCES `m_siswa` (`id`);

--
-- Constraints for table `t_guru_mapel`
--
ALTER TABLE `t_guru_mapel`
  ADD CONSTRAINT `FK_t_guru_mapel_m_guru` FOREIGN KEY (`id_guru`) REFERENCES `m_guru` (`id`),
  ADD CONSTRAINT `FK_t_guru_mapel_m_kelas` FOREIGN KEY (`id_kelas`) REFERENCES `m_kelas` (`id`),
  ADD CONSTRAINT `FK_t_guru_mapel_m_mapel` FOREIGN KEY (`id_mapel`) REFERENCES `m_mapel` (`id`);

--
-- Constraints for table `t_kelas_siswa`
--
ALTER TABLE `t_kelas_siswa`
  ADD CONSTRAINT `t_kelas_siswa_ibfk_1` FOREIGN KEY (`id_kelas`) REFERENCES `m_kelas` (`id`),
  ADD CONSTRAINT `t_kelas_siswa_ibfk_2` FOREIGN KEY (`id_siswa`) REFERENCES `m_siswa` (`id`);

--
-- Constraints for table `t_walikelas`
--
ALTER TABLE `t_walikelas`
  ADD CONSTRAINT `FK_t_walikelas_m_guru` FOREIGN KEY (`id_guru`) REFERENCES `m_guru` (`id`),
  ADD CONSTRAINT `FK_t_walikelas_m_kelas` FOREIGN KEY (`id_kelas`) REFERENCES `m_kelas` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
