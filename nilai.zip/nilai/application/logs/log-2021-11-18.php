<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-11-18 08:45:11 --> Config Class Initialized
INFO - 2021-11-18 08:45:11 --> Hooks Class Initialized
DEBUG - 2021-11-18 08:45:12 --> UTF-8 Support Enabled
INFO - 2021-11-18 08:45:12 --> Utf8 Class Initialized
INFO - 2021-11-18 08:45:12 --> URI Class Initialized
DEBUG - 2021-11-18 08:45:12 --> No URI present. Default controller set.
INFO - 2021-11-18 08:45:12 --> Router Class Initialized
INFO - 2021-11-18 08:45:12 --> Output Class Initialized
INFO - 2021-11-18 08:45:12 --> Security Class Initialized
DEBUG - 2021-11-18 08:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 08:45:12 --> Input Class Initialized
INFO - 2021-11-18 08:45:12 --> Language Class Initialized
INFO - 2021-11-18 08:45:13 --> Language Class Initialized
INFO - 2021-11-18 08:45:13 --> Config Class Initialized
INFO - 2021-11-18 08:45:13 --> Loader Class Initialized
INFO - 2021-11-18 08:45:13 --> Helper loaded: url_helper
INFO - 2021-11-18 08:45:13 --> Helper loaded: file_helper
INFO - 2021-11-18 08:45:13 --> Helper loaded: form_helper
INFO - 2021-11-18 08:45:13 --> Helper loaded: my_helper
INFO - 2021-11-18 08:45:13 --> Database Driver Class Initialized
DEBUG - 2021-11-18 08:45:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 08:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 08:45:13 --> Controller Class Initialized
INFO - 2021-11-18 08:45:14 --> Config Class Initialized
INFO - 2021-11-18 08:45:14 --> Hooks Class Initialized
DEBUG - 2021-11-18 08:45:14 --> UTF-8 Support Enabled
INFO - 2021-11-18 08:45:14 --> Utf8 Class Initialized
INFO - 2021-11-18 08:45:14 --> URI Class Initialized
INFO - 2021-11-18 08:45:14 --> Router Class Initialized
INFO - 2021-11-18 08:45:14 --> Output Class Initialized
INFO - 2021-11-18 08:45:14 --> Security Class Initialized
DEBUG - 2021-11-18 08:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 08:45:14 --> Input Class Initialized
INFO - 2021-11-18 08:45:14 --> Language Class Initialized
INFO - 2021-11-18 08:45:14 --> Language Class Initialized
INFO - 2021-11-18 08:45:14 --> Config Class Initialized
INFO - 2021-11-18 08:45:14 --> Loader Class Initialized
INFO - 2021-11-18 08:45:14 --> Helper loaded: url_helper
INFO - 2021-11-18 08:45:14 --> Helper loaded: file_helper
INFO - 2021-11-18 08:45:14 --> Helper loaded: form_helper
INFO - 2021-11-18 08:45:14 --> Helper loaded: my_helper
INFO - 2021-11-18 08:45:14 --> Database Driver Class Initialized
DEBUG - 2021-11-18 08:45:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 08:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 08:45:14 --> Controller Class Initialized
DEBUG - 2021-11-18 08:45:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-11-18 08:45:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-18 08:45:14 --> Final output sent to browser
DEBUG - 2021-11-18 08:45:14 --> Total execution time: 0.2107
INFO - 2021-11-18 08:47:49 --> Config Class Initialized
INFO - 2021-11-18 08:47:49 --> Hooks Class Initialized
DEBUG - 2021-11-18 08:47:49 --> UTF-8 Support Enabled
INFO - 2021-11-18 08:47:49 --> Utf8 Class Initialized
INFO - 2021-11-18 08:47:49 --> URI Class Initialized
INFO - 2021-11-18 08:47:49 --> Router Class Initialized
INFO - 2021-11-18 08:47:49 --> Output Class Initialized
INFO - 2021-11-18 08:47:49 --> Security Class Initialized
DEBUG - 2021-11-18 08:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 08:47:49 --> Input Class Initialized
INFO - 2021-11-18 08:47:49 --> Language Class Initialized
INFO - 2021-11-18 08:47:49 --> Language Class Initialized
INFO - 2021-11-18 08:47:49 --> Config Class Initialized
INFO - 2021-11-18 08:47:49 --> Loader Class Initialized
INFO - 2021-11-18 08:47:49 --> Helper loaded: url_helper
INFO - 2021-11-18 08:47:49 --> Helper loaded: file_helper
INFO - 2021-11-18 08:47:49 --> Helper loaded: form_helper
INFO - 2021-11-18 08:47:49 --> Helper loaded: my_helper
INFO - 2021-11-18 08:47:49 --> Database Driver Class Initialized
DEBUG - 2021-11-18 08:47:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 08:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 08:47:49 --> Controller Class Initialized
INFO - 2021-11-18 08:47:49 --> Helper loaded: cookie_helper
INFO - 2021-11-18 08:47:49 --> Final output sent to browser
DEBUG - 2021-11-18 08:47:49 --> Total execution time: 0.1602
INFO - 2021-11-18 08:47:50 --> Config Class Initialized
INFO - 2021-11-18 08:47:50 --> Hooks Class Initialized
DEBUG - 2021-11-18 08:47:50 --> UTF-8 Support Enabled
INFO - 2021-11-18 08:47:50 --> Utf8 Class Initialized
INFO - 2021-11-18 08:47:50 --> URI Class Initialized
INFO - 2021-11-18 08:47:50 --> Router Class Initialized
INFO - 2021-11-18 08:47:50 --> Output Class Initialized
INFO - 2021-11-18 08:47:50 --> Security Class Initialized
DEBUG - 2021-11-18 08:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 08:47:50 --> Input Class Initialized
INFO - 2021-11-18 08:47:50 --> Language Class Initialized
INFO - 2021-11-18 08:47:50 --> Language Class Initialized
INFO - 2021-11-18 08:47:50 --> Config Class Initialized
INFO - 2021-11-18 08:47:50 --> Loader Class Initialized
INFO - 2021-11-18 08:47:50 --> Helper loaded: url_helper
INFO - 2021-11-18 08:47:50 --> Helper loaded: file_helper
INFO - 2021-11-18 08:47:50 --> Helper loaded: form_helper
INFO - 2021-11-18 08:47:50 --> Helper loaded: my_helper
INFO - 2021-11-18 08:47:50 --> Database Driver Class Initialized
DEBUG - 2021-11-18 08:47:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 08:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 08:47:50 --> Controller Class Initialized
DEBUG - 2021-11-18 08:47:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-11-18 08:47:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-18 08:47:53 --> Final output sent to browser
DEBUG - 2021-11-18 08:47:53 --> Total execution time: 2.6803
INFO - 2021-11-18 08:48:01 --> Config Class Initialized
INFO - 2021-11-18 08:48:01 --> Hooks Class Initialized
DEBUG - 2021-11-18 08:48:01 --> UTF-8 Support Enabled
INFO - 2021-11-18 08:48:01 --> Utf8 Class Initialized
INFO - 2021-11-18 08:48:01 --> URI Class Initialized
INFO - 2021-11-18 08:48:01 --> Router Class Initialized
INFO - 2021-11-18 08:48:01 --> Output Class Initialized
INFO - 2021-11-18 08:48:01 --> Security Class Initialized
DEBUG - 2021-11-18 08:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 08:48:01 --> Input Class Initialized
INFO - 2021-11-18 08:48:01 --> Language Class Initialized
INFO - 2021-11-18 08:48:01 --> Language Class Initialized
INFO - 2021-11-18 08:48:01 --> Config Class Initialized
INFO - 2021-11-18 08:48:01 --> Loader Class Initialized
INFO - 2021-11-18 08:48:01 --> Helper loaded: url_helper
INFO - 2021-11-18 08:48:01 --> Helper loaded: file_helper
INFO - 2021-11-18 08:48:01 --> Helper loaded: form_helper
INFO - 2021-11-18 08:48:01 --> Helper loaded: my_helper
INFO - 2021-11-18 08:48:01 --> Database Driver Class Initialized
DEBUG - 2021-11-18 08:48:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 08:48:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 08:48:01 --> Controller Class Initialized
DEBUG - 2021-11-18 08:48:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-11-18 08:48:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-18 08:48:01 --> Final output sent to browser
DEBUG - 2021-11-18 08:48:01 --> Total execution time: 0.2017
INFO - 2021-11-18 08:48:02 --> Config Class Initialized
INFO - 2021-11-18 08:48:02 --> Hooks Class Initialized
DEBUG - 2021-11-18 08:48:02 --> UTF-8 Support Enabled
INFO - 2021-11-18 08:48:02 --> Utf8 Class Initialized
INFO - 2021-11-18 08:48:02 --> URI Class Initialized
INFO - 2021-11-18 08:48:02 --> Router Class Initialized
INFO - 2021-11-18 08:48:02 --> Output Class Initialized
INFO - 2021-11-18 08:48:02 --> Security Class Initialized
DEBUG - 2021-11-18 08:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 08:48:02 --> Input Class Initialized
INFO - 2021-11-18 08:48:02 --> Language Class Initialized
INFO - 2021-11-18 08:48:02 --> Language Class Initialized
INFO - 2021-11-18 08:48:02 --> Config Class Initialized
INFO - 2021-11-18 08:48:02 --> Loader Class Initialized
INFO - 2021-11-18 08:48:02 --> Helper loaded: url_helper
INFO - 2021-11-18 08:48:02 --> Helper loaded: file_helper
INFO - 2021-11-18 08:48:02 --> Helper loaded: form_helper
INFO - 2021-11-18 08:48:02 --> Helper loaded: my_helper
INFO - 2021-11-18 08:48:02 --> Database Driver Class Initialized
DEBUG - 2021-11-18 08:48:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 08:48:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 08:48:02 --> Controller Class Initialized
INFO - 2021-11-18 08:48:06 --> Config Class Initialized
INFO - 2021-11-18 08:48:06 --> Hooks Class Initialized
DEBUG - 2021-11-18 08:48:06 --> UTF-8 Support Enabled
INFO - 2021-11-18 08:48:06 --> Utf8 Class Initialized
INFO - 2021-11-18 08:48:06 --> URI Class Initialized
INFO - 2021-11-18 08:48:06 --> Router Class Initialized
INFO - 2021-11-18 08:48:06 --> Output Class Initialized
INFO - 2021-11-18 08:48:06 --> Security Class Initialized
DEBUG - 2021-11-18 08:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 08:48:06 --> Input Class Initialized
INFO - 2021-11-18 08:48:06 --> Language Class Initialized
INFO - 2021-11-18 08:48:06 --> Language Class Initialized
INFO - 2021-11-18 08:48:06 --> Config Class Initialized
INFO - 2021-11-18 08:48:06 --> Loader Class Initialized
INFO - 2021-11-18 08:48:06 --> Helper loaded: url_helper
INFO - 2021-11-18 08:48:06 --> Helper loaded: file_helper
INFO - 2021-11-18 08:48:06 --> Helper loaded: form_helper
INFO - 2021-11-18 08:48:06 --> Helper loaded: my_helper
INFO - 2021-11-18 08:48:06 --> Database Driver Class Initialized
DEBUG - 2021-11-18 08:48:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 08:48:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 08:48:06 --> Controller Class Initialized
INFO - 2021-11-18 08:48:06 --> Helper loaded: cookie_helper
INFO - 2021-11-18 08:48:06 --> Config Class Initialized
INFO - 2021-11-18 08:48:06 --> Hooks Class Initialized
DEBUG - 2021-11-18 08:48:06 --> UTF-8 Support Enabled
INFO - 2021-11-18 08:48:06 --> Utf8 Class Initialized
INFO - 2021-11-18 08:48:06 --> URI Class Initialized
INFO - 2021-11-18 08:48:07 --> Router Class Initialized
INFO - 2021-11-18 08:48:07 --> Output Class Initialized
INFO - 2021-11-18 08:48:07 --> Security Class Initialized
DEBUG - 2021-11-18 08:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 08:48:07 --> Input Class Initialized
INFO - 2021-11-18 08:48:07 --> Language Class Initialized
INFO - 2021-11-18 08:48:07 --> Language Class Initialized
INFO - 2021-11-18 08:48:07 --> Config Class Initialized
INFO - 2021-11-18 08:48:07 --> Loader Class Initialized
INFO - 2021-11-18 08:48:07 --> Helper loaded: url_helper
INFO - 2021-11-18 08:48:07 --> Helper loaded: file_helper
INFO - 2021-11-18 08:48:07 --> Helper loaded: form_helper
INFO - 2021-11-18 08:48:07 --> Helper loaded: my_helper
INFO - 2021-11-18 08:48:07 --> Database Driver Class Initialized
DEBUG - 2021-11-18 08:48:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 08:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 08:48:07 --> Controller Class Initialized
DEBUG - 2021-11-18 08:48:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-11-18 08:48:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-18 08:48:07 --> Final output sent to browser
DEBUG - 2021-11-18 08:48:07 --> Total execution time: 0.1550
INFO - 2021-11-18 08:48:16 --> Config Class Initialized
INFO - 2021-11-18 08:48:16 --> Hooks Class Initialized
DEBUG - 2021-11-18 08:48:16 --> UTF-8 Support Enabled
INFO - 2021-11-18 08:48:16 --> Utf8 Class Initialized
INFO - 2021-11-18 08:48:16 --> URI Class Initialized
INFO - 2021-11-18 08:48:16 --> Router Class Initialized
INFO - 2021-11-18 08:48:16 --> Output Class Initialized
INFO - 2021-11-18 08:48:16 --> Security Class Initialized
DEBUG - 2021-11-18 08:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 08:48:16 --> Input Class Initialized
INFO - 2021-11-18 08:48:16 --> Language Class Initialized
INFO - 2021-11-18 08:48:16 --> Language Class Initialized
INFO - 2021-11-18 08:48:16 --> Config Class Initialized
INFO - 2021-11-18 08:48:16 --> Loader Class Initialized
INFO - 2021-11-18 08:48:16 --> Helper loaded: url_helper
INFO - 2021-11-18 08:48:16 --> Helper loaded: file_helper
INFO - 2021-11-18 08:48:16 --> Helper loaded: form_helper
INFO - 2021-11-18 08:48:16 --> Helper loaded: my_helper
INFO - 2021-11-18 08:48:16 --> Database Driver Class Initialized
DEBUG - 2021-11-18 08:48:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 08:48:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 08:48:16 --> Controller Class Initialized
INFO - 2021-11-18 08:48:16 --> Helper loaded: cookie_helper
INFO - 2021-11-18 08:48:16 --> Final output sent to browser
DEBUG - 2021-11-18 08:48:16 --> Total execution time: 0.1727
INFO - 2021-11-18 08:48:17 --> Config Class Initialized
INFO - 2021-11-18 08:48:17 --> Hooks Class Initialized
DEBUG - 2021-11-18 08:48:17 --> UTF-8 Support Enabled
INFO - 2021-11-18 08:48:17 --> Utf8 Class Initialized
INFO - 2021-11-18 08:48:17 --> URI Class Initialized
INFO - 2021-11-18 08:48:17 --> Router Class Initialized
INFO - 2021-11-18 08:48:17 --> Output Class Initialized
INFO - 2021-11-18 08:48:17 --> Security Class Initialized
DEBUG - 2021-11-18 08:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 08:48:17 --> Input Class Initialized
INFO - 2021-11-18 08:48:17 --> Language Class Initialized
INFO - 2021-11-18 08:48:17 --> Language Class Initialized
INFO - 2021-11-18 08:48:17 --> Config Class Initialized
INFO - 2021-11-18 08:48:17 --> Loader Class Initialized
INFO - 2021-11-18 08:48:17 --> Helper loaded: url_helper
INFO - 2021-11-18 08:48:17 --> Helper loaded: file_helper
INFO - 2021-11-18 08:48:17 --> Helper loaded: form_helper
INFO - 2021-11-18 08:48:17 --> Helper loaded: my_helper
INFO - 2021-11-18 08:48:17 --> Database Driver Class Initialized
DEBUG - 2021-11-18 08:48:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 08:48:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 08:48:17 --> Controller Class Initialized
DEBUG - 2021-11-18 08:48:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-11-18 08:48:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-18 08:48:20 --> Final output sent to browser
DEBUG - 2021-11-18 08:48:20 --> Total execution time: 2.9097
INFO - 2021-11-18 08:48:34 --> Config Class Initialized
INFO - 2021-11-18 08:48:34 --> Hooks Class Initialized
DEBUG - 2021-11-18 08:48:34 --> UTF-8 Support Enabled
INFO - 2021-11-18 08:48:34 --> Utf8 Class Initialized
INFO - 2021-11-18 08:48:34 --> URI Class Initialized
INFO - 2021-11-18 08:48:34 --> Router Class Initialized
INFO - 2021-11-18 08:48:34 --> Output Class Initialized
INFO - 2021-11-18 08:48:34 --> Security Class Initialized
DEBUG - 2021-11-18 08:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 08:48:34 --> Input Class Initialized
INFO - 2021-11-18 08:48:34 --> Language Class Initialized
INFO - 2021-11-18 08:48:34 --> Language Class Initialized
INFO - 2021-11-18 08:48:34 --> Config Class Initialized
INFO - 2021-11-18 08:48:34 --> Loader Class Initialized
INFO - 2021-11-18 08:48:34 --> Helper loaded: url_helper
INFO - 2021-11-18 08:48:34 --> Helper loaded: file_helper
INFO - 2021-11-18 08:48:34 --> Helper loaded: form_helper
INFO - 2021-11-18 08:48:34 --> Helper loaded: my_helper
INFO - 2021-11-18 08:48:34 --> Database Driver Class Initialized
DEBUG - 2021-11-18 08:48:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 08:48:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 08:48:34 --> Controller Class Initialized
DEBUG - 2021-11-18 08:48:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-11-18 08:48:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-18 08:48:35 --> Final output sent to browser
DEBUG - 2021-11-18 08:48:35 --> Total execution time: 0.2833
INFO - 2021-11-18 08:48:38 --> Config Class Initialized
INFO - 2021-11-18 08:48:38 --> Hooks Class Initialized
DEBUG - 2021-11-18 08:48:38 --> UTF-8 Support Enabled
INFO - 2021-11-18 08:48:38 --> Utf8 Class Initialized
INFO - 2021-11-18 08:48:38 --> URI Class Initialized
INFO - 2021-11-18 08:48:38 --> Router Class Initialized
INFO - 2021-11-18 08:48:38 --> Output Class Initialized
INFO - 2021-11-18 08:48:38 --> Security Class Initialized
DEBUG - 2021-11-18 08:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 08:48:38 --> Input Class Initialized
INFO - 2021-11-18 08:48:38 --> Language Class Initialized
INFO - 2021-11-18 08:48:38 --> Language Class Initialized
INFO - 2021-11-18 08:48:38 --> Config Class Initialized
INFO - 2021-11-18 08:48:38 --> Loader Class Initialized
INFO - 2021-11-18 08:48:38 --> Helper loaded: url_helper
INFO - 2021-11-18 08:48:38 --> Helper loaded: file_helper
INFO - 2021-11-18 08:48:38 --> Helper loaded: form_helper
INFO - 2021-11-18 08:48:38 --> Helper loaded: my_helper
INFO - 2021-11-18 08:48:38 --> Database Driver Class Initialized
DEBUG - 2021-11-18 08:48:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 08:48:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 08:48:38 --> Controller Class Initialized
DEBUG - 2021-11-18 08:48:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-18 08:48:39 --> Final output sent to browser
DEBUG - 2021-11-18 08:48:39 --> Total execution time: 0.6493
INFO - 2021-11-18 08:48:48 --> Config Class Initialized
INFO - 2021-11-18 08:48:48 --> Hooks Class Initialized
DEBUG - 2021-11-18 08:48:48 --> UTF-8 Support Enabled
INFO - 2021-11-18 08:48:48 --> Utf8 Class Initialized
INFO - 2021-11-18 08:48:48 --> URI Class Initialized
DEBUG - 2021-11-18 08:48:48 --> No URI present. Default controller set.
INFO - 2021-11-18 08:48:48 --> Router Class Initialized
INFO - 2021-11-18 08:48:48 --> Output Class Initialized
INFO - 2021-11-18 08:48:48 --> Security Class Initialized
DEBUG - 2021-11-18 08:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 08:48:48 --> Input Class Initialized
INFO - 2021-11-18 08:48:48 --> Language Class Initialized
INFO - 2021-11-18 08:48:48 --> Language Class Initialized
INFO - 2021-11-18 08:48:48 --> Config Class Initialized
INFO - 2021-11-18 08:48:48 --> Loader Class Initialized
INFO - 2021-11-18 08:48:48 --> Helper loaded: url_helper
INFO - 2021-11-18 08:48:48 --> Helper loaded: file_helper
INFO - 2021-11-18 08:48:48 --> Helper loaded: form_helper
INFO - 2021-11-18 08:48:48 --> Helper loaded: my_helper
INFO - 2021-11-18 08:48:48 --> Database Driver Class Initialized
DEBUG - 2021-11-18 08:48:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 08:48:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 08:48:48 --> Controller Class Initialized
DEBUG - 2021-11-18 08:48:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-11-18 08:48:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-18 08:48:50 --> Final output sent to browser
DEBUG - 2021-11-18 08:48:50 --> Total execution time: 2.0617
INFO - 2021-11-18 08:48:54 --> Config Class Initialized
INFO - 2021-11-18 08:48:54 --> Hooks Class Initialized
DEBUG - 2021-11-18 08:48:54 --> UTF-8 Support Enabled
INFO - 2021-11-18 08:48:54 --> Utf8 Class Initialized
INFO - 2021-11-18 08:48:54 --> URI Class Initialized
INFO - 2021-11-18 08:48:54 --> Router Class Initialized
INFO - 2021-11-18 08:48:54 --> Output Class Initialized
INFO - 2021-11-18 08:48:54 --> Security Class Initialized
DEBUG - 2021-11-18 08:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 08:48:54 --> Input Class Initialized
INFO - 2021-11-18 08:48:54 --> Language Class Initialized
INFO - 2021-11-18 08:48:54 --> Language Class Initialized
INFO - 2021-11-18 08:48:54 --> Config Class Initialized
INFO - 2021-11-18 08:48:54 --> Loader Class Initialized
INFO - 2021-11-18 08:48:54 --> Helper loaded: url_helper
INFO - 2021-11-18 08:48:54 --> Helper loaded: file_helper
INFO - 2021-11-18 08:48:54 --> Helper loaded: form_helper
INFO - 2021-11-18 08:48:54 --> Helper loaded: my_helper
INFO - 2021-11-18 08:48:54 --> Database Driver Class Initialized
DEBUG - 2021-11-18 08:48:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 08:48:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 08:48:54 --> Controller Class Initialized
DEBUG - 2021-11-18 08:48:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-11-18 08:48:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-18 08:48:54 --> Final output sent to browser
DEBUG - 2021-11-18 08:48:54 --> Total execution time: 0.1655
INFO - 2021-11-18 08:49:02 --> Config Class Initialized
INFO - 2021-11-18 08:49:02 --> Hooks Class Initialized
DEBUG - 2021-11-18 08:49:02 --> UTF-8 Support Enabled
INFO - 2021-11-18 08:49:02 --> Utf8 Class Initialized
INFO - 2021-11-18 08:49:02 --> URI Class Initialized
INFO - 2021-11-18 08:49:02 --> Router Class Initialized
INFO - 2021-11-18 08:49:02 --> Output Class Initialized
INFO - 2021-11-18 08:49:02 --> Security Class Initialized
DEBUG - 2021-11-18 08:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 08:49:02 --> Input Class Initialized
INFO - 2021-11-18 08:49:02 --> Language Class Initialized
INFO - 2021-11-18 08:49:02 --> Language Class Initialized
INFO - 2021-11-18 08:49:02 --> Config Class Initialized
INFO - 2021-11-18 08:49:02 --> Loader Class Initialized
INFO - 2021-11-18 08:49:02 --> Helper loaded: url_helper
INFO - 2021-11-18 08:49:02 --> Helper loaded: file_helper
INFO - 2021-11-18 08:49:02 --> Helper loaded: form_helper
INFO - 2021-11-18 08:49:02 --> Helper loaded: my_helper
INFO - 2021-11-18 08:49:02 --> Database Driver Class Initialized
DEBUG - 2021-11-18 08:49:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 08:49:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 08:49:02 --> Controller Class Initialized
DEBUG - 2021-11-18 08:49:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-18 08:49:03 --> Final output sent to browser
DEBUG - 2021-11-18 08:49:03 --> Total execution time: 0.4773
INFO - 2021-11-18 08:50:13 --> Config Class Initialized
INFO - 2021-11-18 08:50:13 --> Hooks Class Initialized
DEBUG - 2021-11-18 08:50:13 --> UTF-8 Support Enabled
INFO - 2021-11-18 08:50:13 --> Utf8 Class Initialized
INFO - 2021-11-18 08:50:13 --> URI Class Initialized
INFO - 2021-11-18 08:50:13 --> Router Class Initialized
INFO - 2021-11-18 08:50:13 --> Output Class Initialized
INFO - 2021-11-18 08:50:13 --> Security Class Initialized
DEBUG - 2021-11-18 08:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 08:50:13 --> Input Class Initialized
INFO - 2021-11-18 08:50:13 --> Language Class Initialized
INFO - 2021-11-18 08:50:13 --> Language Class Initialized
INFO - 2021-11-18 08:50:13 --> Config Class Initialized
INFO - 2021-11-18 08:50:13 --> Loader Class Initialized
INFO - 2021-11-18 08:50:13 --> Helper loaded: url_helper
INFO - 2021-11-18 08:50:13 --> Helper loaded: file_helper
INFO - 2021-11-18 08:50:13 --> Helper loaded: form_helper
INFO - 2021-11-18 08:50:13 --> Helper loaded: my_helper
INFO - 2021-11-18 08:50:13 --> Database Driver Class Initialized
DEBUG - 2021-11-18 08:50:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 08:50:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 08:50:13 --> Controller Class Initialized
DEBUG - 2021-11-18 08:50:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-18 08:50:13 --> Final output sent to browser
DEBUG - 2021-11-18 08:50:13 --> Total execution time: 0.4059
INFO - 2021-11-18 08:50:45 --> Config Class Initialized
INFO - 2021-11-18 08:50:45 --> Hooks Class Initialized
DEBUG - 2021-11-18 08:50:45 --> UTF-8 Support Enabled
INFO - 2021-11-18 08:50:45 --> Utf8 Class Initialized
INFO - 2021-11-18 08:50:45 --> URI Class Initialized
INFO - 2021-11-18 08:50:45 --> Router Class Initialized
INFO - 2021-11-18 08:50:45 --> Output Class Initialized
INFO - 2021-11-18 08:50:45 --> Security Class Initialized
DEBUG - 2021-11-18 08:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 08:50:45 --> Input Class Initialized
INFO - 2021-11-18 08:50:45 --> Language Class Initialized
INFO - 2021-11-18 08:50:45 --> Language Class Initialized
INFO - 2021-11-18 08:50:45 --> Config Class Initialized
INFO - 2021-11-18 08:50:45 --> Loader Class Initialized
INFO - 2021-11-18 08:50:45 --> Helper loaded: url_helper
INFO - 2021-11-18 08:50:45 --> Helper loaded: file_helper
INFO - 2021-11-18 08:50:45 --> Helper loaded: form_helper
INFO - 2021-11-18 08:50:45 --> Helper loaded: my_helper
INFO - 2021-11-18 08:50:45 --> Database Driver Class Initialized
DEBUG - 2021-11-18 08:50:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 08:50:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 08:50:45 --> Controller Class Initialized
DEBUG - 2021-11-18 08:50:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-18 08:50:45 --> Final output sent to browser
DEBUG - 2021-11-18 08:50:45 --> Total execution time: 0.4299
INFO - 2021-11-18 08:51:46 --> Config Class Initialized
INFO - 2021-11-18 08:51:46 --> Hooks Class Initialized
DEBUG - 2021-11-18 08:51:46 --> UTF-8 Support Enabled
INFO - 2021-11-18 08:51:46 --> Utf8 Class Initialized
INFO - 2021-11-18 08:51:46 --> URI Class Initialized
INFO - 2021-11-18 08:51:46 --> Router Class Initialized
INFO - 2021-11-18 08:51:46 --> Output Class Initialized
INFO - 2021-11-18 08:51:46 --> Security Class Initialized
DEBUG - 2021-11-18 08:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 08:51:46 --> Input Class Initialized
INFO - 2021-11-18 08:51:46 --> Language Class Initialized
INFO - 2021-11-18 08:51:46 --> Language Class Initialized
INFO - 2021-11-18 08:51:46 --> Config Class Initialized
INFO - 2021-11-18 08:51:46 --> Loader Class Initialized
INFO - 2021-11-18 08:51:46 --> Helper loaded: url_helper
INFO - 2021-11-18 08:51:46 --> Helper loaded: file_helper
INFO - 2021-11-18 08:51:46 --> Helper loaded: form_helper
INFO - 2021-11-18 08:51:46 --> Helper loaded: my_helper
INFO - 2021-11-18 08:51:46 --> Database Driver Class Initialized
DEBUG - 2021-11-18 08:51:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 08:51:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 08:51:46 --> Controller Class Initialized
DEBUG - 2021-11-18 08:51:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-18 08:51:46 --> Final output sent to browser
DEBUG - 2021-11-18 08:51:46 --> Total execution time: 0.3679
INFO - 2021-11-18 08:52:17 --> Config Class Initialized
INFO - 2021-11-18 08:52:17 --> Hooks Class Initialized
DEBUG - 2021-11-18 08:52:17 --> UTF-8 Support Enabled
INFO - 2021-11-18 08:52:17 --> Utf8 Class Initialized
INFO - 2021-11-18 08:52:17 --> URI Class Initialized
INFO - 2021-11-18 08:52:17 --> Router Class Initialized
INFO - 2021-11-18 08:52:17 --> Output Class Initialized
INFO - 2021-11-18 08:52:17 --> Security Class Initialized
DEBUG - 2021-11-18 08:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 08:52:17 --> Input Class Initialized
INFO - 2021-11-18 08:52:17 --> Language Class Initialized
INFO - 2021-11-18 08:52:17 --> Language Class Initialized
INFO - 2021-11-18 08:52:17 --> Config Class Initialized
INFO - 2021-11-18 08:52:17 --> Loader Class Initialized
INFO - 2021-11-18 08:52:17 --> Helper loaded: url_helper
INFO - 2021-11-18 08:52:17 --> Helper loaded: file_helper
INFO - 2021-11-18 08:52:17 --> Helper loaded: form_helper
INFO - 2021-11-18 08:52:17 --> Helper loaded: my_helper
INFO - 2021-11-18 08:52:17 --> Database Driver Class Initialized
DEBUG - 2021-11-18 08:52:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 08:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 08:52:17 --> Controller Class Initialized
DEBUG - 2021-11-18 08:52:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-18 08:52:17 --> Final output sent to browser
DEBUG - 2021-11-18 08:52:17 --> Total execution time: 0.3652
INFO - 2021-11-18 08:52:42 --> Config Class Initialized
INFO - 2021-11-18 08:52:42 --> Hooks Class Initialized
DEBUG - 2021-11-18 08:52:42 --> UTF-8 Support Enabled
INFO - 2021-11-18 08:52:42 --> Utf8 Class Initialized
INFO - 2021-11-18 08:52:42 --> URI Class Initialized
INFO - 2021-11-18 08:52:42 --> Router Class Initialized
INFO - 2021-11-18 08:52:42 --> Output Class Initialized
INFO - 2021-11-18 08:52:42 --> Security Class Initialized
DEBUG - 2021-11-18 08:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 08:52:42 --> Input Class Initialized
INFO - 2021-11-18 08:52:42 --> Language Class Initialized
INFO - 2021-11-18 08:52:42 --> Language Class Initialized
INFO - 2021-11-18 08:52:42 --> Config Class Initialized
INFO - 2021-11-18 08:52:42 --> Loader Class Initialized
INFO - 2021-11-18 08:52:42 --> Helper loaded: url_helper
INFO - 2021-11-18 08:52:42 --> Helper loaded: file_helper
INFO - 2021-11-18 08:52:42 --> Helper loaded: form_helper
INFO - 2021-11-18 08:52:42 --> Helper loaded: my_helper
INFO - 2021-11-18 08:52:42 --> Database Driver Class Initialized
DEBUG - 2021-11-18 08:52:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 08:52:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 08:52:42 --> Controller Class Initialized
DEBUG - 2021-11-18 08:52:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-18 08:52:43 --> Final output sent to browser
DEBUG - 2021-11-18 08:52:43 --> Total execution time: 0.4884
INFO - 2021-11-18 08:53:04 --> Config Class Initialized
INFO - 2021-11-18 08:53:04 --> Hooks Class Initialized
DEBUG - 2021-11-18 08:53:04 --> UTF-8 Support Enabled
INFO - 2021-11-18 08:53:04 --> Utf8 Class Initialized
INFO - 2021-11-18 08:53:04 --> URI Class Initialized
INFO - 2021-11-18 08:53:04 --> Router Class Initialized
INFO - 2021-11-18 08:53:04 --> Output Class Initialized
INFO - 2021-11-18 08:53:04 --> Security Class Initialized
DEBUG - 2021-11-18 08:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 08:53:04 --> Input Class Initialized
INFO - 2021-11-18 08:53:04 --> Language Class Initialized
INFO - 2021-11-18 08:53:04 --> Language Class Initialized
INFO - 2021-11-18 08:53:04 --> Config Class Initialized
INFO - 2021-11-18 08:53:04 --> Loader Class Initialized
INFO - 2021-11-18 08:53:04 --> Helper loaded: url_helper
INFO - 2021-11-18 08:53:04 --> Helper loaded: file_helper
INFO - 2021-11-18 08:53:04 --> Helper loaded: form_helper
INFO - 2021-11-18 08:53:04 --> Helper loaded: my_helper
INFO - 2021-11-18 08:53:04 --> Database Driver Class Initialized
DEBUG - 2021-11-18 08:53:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 08:53:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 08:53:04 --> Controller Class Initialized
DEBUG - 2021-11-18 08:53:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-18 08:53:04 --> Final output sent to browser
DEBUG - 2021-11-18 08:53:04 --> Total execution time: 0.4048
INFO - 2021-11-18 08:53:58 --> Config Class Initialized
INFO - 2021-11-18 08:53:58 --> Hooks Class Initialized
DEBUG - 2021-11-18 08:53:58 --> UTF-8 Support Enabled
INFO - 2021-11-18 08:53:58 --> Utf8 Class Initialized
INFO - 2021-11-18 08:53:58 --> URI Class Initialized
INFO - 2021-11-18 08:53:58 --> Router Class Initialized
INFO - 2021-11-18 08:53:58 --> Output Class Initialized
INFO - 2021-11-18 08:53:58 --> Security Class Initialized
DEBUG - 2021-11-18 08:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 08:53:58 --> Input Class Initialized
INFO - 2021-11-18 08:53:58 --> Language Class Initialized
INFO - 2021-11-18 08:53:58 --> Language Class Initialized
INFO - 2021-11-18 08:53:58 --> Config Class Initialized
INFO - 2021-11-18 08:53:58 --> Loader Class Initialized
INFO - 2021-11-18 08:53:58 --> Helper loaded: url_helper
INFO - 2021-11-18 08:53:58 --> Helper loaded: file_helper
INFO - 2021-11-18 08:53:58 --> Helper loaded: form_helper
INFO - 2021-11-18 08:53:58 --> Helper loaded: my_helper
INFO - 2021-11-18 08:53:58 --> Database Driver Class Initialized
DEBUG - 2021-11-18 08:53:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 08:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 08:53:58 --> Controller Class Initialized
DEBUG - 2021-11-18 08:53:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-18 08:53:58 --> Final output sent to browser
DEBUG - 2021-11-18 08:53:58 --> Total execution time: 0.4349
INFO - 2021-11-18 08:54:28 --> Config Class Initialized
INFO - 2021-11-18 08:54:28 --> Hooks Class Initialized
DEBUG - 2021-11-18 08:54:28 --> UTF-8 Support Enabled
INFO - 2021-11-18 08:54:28 --> Utf8 Class Initialized
INFO - 2021-11-18 08:54:28 --> URI Class Initialized
INFO - 2021-11-18 08:54:28 --> Router Class Initialized
INFO - 2021-11-18 08:54:28 --> Output Class Initialized
INFO - 2021-11-18 08:54:28 --> Security Class Initialized
DEBUG - 2021-11-18 08:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 08:54:28 --> Input Class Initialized
INFO - 2021-11-18 08:54:28 --> Language Class Initialized
INFO - 2021-11-18 08:54:28 --> Language Class Initialized
INFO - 2021-11-18 08:54:28 --> Config Class Initialized
INFO - 2021-11-18 08:54:28 --> Loader Class Initialized
INFO - 2021-11-18 08:54:28 --> Helper loaded: url_helper
INFO - 2021-11-18 08:54:28 --> Helper loaded: file_helper
INFO - 2021-11-18 08:54:28 --> Helper loaded: form_helper
INFO - 2021-11-18 08:54:28 --> Helper loaded: my_helper
INFO - 2021-11-18 08:54:28 --> Database Driver Class Initialized
DEBUG - 2021-11-18 08:54:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 08:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 08:54:28 --> Controller Class Initialized
DEBUG - 2021-11-18 08:54:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-18 08:54:29 --> Final output sent to browser
DEBUG - 2021-11-18 08:54:29 --> Total execution time: 0.2604
INFO - 2021-11-18 09:00:40 --> Config Class Initialized
INFO - 2021-11-18 09:00:40 --> Hooks Class Initialized
DEBUG - 2021-11-18 09:00:40 --> UTF-8 Support Enabled
INFO - 2021-11-18 09:00:40 --> Utf8 Class Initialized
INFO - 2021-11-18 09:00:40 --> URI Class Initialized
INFO - 2021-11-18 09:00:40 --> Router Class Initialized
INFO - 2021-11-18 09:00:40 --> Output Class Initialized
INFO - 2021-11-18 09:00:40 --> Security Class Initialized
DEBUG - 2021-11-18 09:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 09:00:40 --> Input Class Initialized
INFO - 2021-11-18 09:00:40 --> Language Class Initialized
INFO - 2021-11-18 09:00:40 --> Language Class Initialized
INFO - 2021-11-18 09:00:40 --> Config Class Initialized
INFO - 2021-11-18 09:00:40 --> Loader Class Initialized
INFO - 2021-11-18 09:00:40 --> Helper loaded: url_helper
INFO - 2021-11-18 09:00:40 --> Helper loaded: file_helper
INFO - 2021-11-18 09:00:40 --> Helper loaded: form_helper
INFO - 2021-11-18 09:00:40 --> Helper loaded: my_helper
INFO - 2021-11-18 09:00:40 --> Database Driver Class Initialized
DEBUG - 2021-11-18 09:00:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 09:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 09:00:41 --> Controller Class Initialized
DEBUG - 2021-11-18 09:00:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-18 09:00:41 --> Final output sent to browser
DEBUG - 2021-11-18 09:00:41 --> Total execution time: 0.3730
INFO - 2021-11-18 09:01:05 --> Config Class Initialized
INFO - 2021-11-18 09:01:05 --> Hooks Class Initialized
DEBUG - 2021-11-18 09:01:05 --> UTF-8 Support Enabled
INFO - 2021-11-18 09:01:05 --> Utf8 Class Initialized
INFO - 2021-11-18 09:01:05 --> URI Class Initialized
INFO - 2021-11-18 09:01:05 --> Router Class Initialized
INFO - 2021-11-18 09:01:05 --> Output Class Initialized
INFO - 2021-11-18 09:01:05 --> Security Class Initialized
DEBUG - 2021-11-18 09:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 09:01:05 --> Input Class Initialized
INFO - 2021-11-18 09:01:05 --> Language Class Initialized
INFO - 2021-11-18 09:01:05 --> Language Class Initialized
INFO - 2021-11-18 09:01:05 --> Config Class Initialized
INFO - 2021-11-18 09:01:05 --> Loader Class Initialized
INFO - 2021-11-18 09:01:05 --> Helper loaded: url_helper
INFO - 2021-11-18 09:01:05 --> Helper loaded: file_helper
INFO - 2021-11-18 09:01:05 --> Helper loaded: form_helper
INFO - 2021-11-18 09:01:05 --> Helper loaded: my_helper
INFO - 2021-11-18 09:01:05 --> Database Driver Class Initialized
DEBUG - 2021-11-18 09:01:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 09:01:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 09:01:05 --> Controller Class Initialized
DEBUG - 2021-11-18 09:01:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-18 09:01:06 --> Final output sent to browser
DEBUG - 2021-11-18 09:01:06 --> Total execution time: 0.4562
INFO - 2021-11-18 09:01:12 --> Config Class Initialized
INFO - 2021-11-18 09:01:12 --> Hooks Class Initialized
DEBUG - 2021-11-18 09:01:12 --> UTF-8 Support Enabled
INFO - 2021-11-18 09:01:12 --> Utf8 Class Initialized
INFO - 2021-11-18 09:01:12 --> URI Class Initialized
INFO - 2021-11-18 09:01:12 --> Router Class Initialized
INFO - 2021-11-18 09:01:12 --> Output Class Initialized
INFO - 2021-11-18 09:01:12 --> Security Class Initialized
DEBUG - 2021-11-18 09:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 09:01:12 --> Input Class Initialized
INFO - 2021-11-18 09:01:12 --> Language Class Initialized
INFO - 2021-11-18 09:01:12 --> Language Class Initialized
INFO - 2021-11-18 09:01:12 --> Config Class Initialized
INFO - 2021-11-18 09:01:12 --> Loader Class Initialized
INFO - 2021-11-18 09:01:12 --> Helper loaded: url_helper
INFO - 2021-11-18 09:01:12 --> Helper loaded: file_helper
INFO - 2021-11-18 09:01:12 --> Helper loaded: form_helper
INFO - 2021-11-18 09:01:12 --> Helper loaded: my_helper
INFO - 2021-11-18 09:01:12 --> Database Driver Class Initialized
DEBUG - 2021-11-18 09:01:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 09:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 09:01:12 --> Controller Class Initialized
DEBUG - 2021-11-18 09:01:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-18 09:01:13 --> Final output sent to browser
DEBUG - 2021-11-18 09:01:13 --> Total execution time: 0.3813
INFO - 2021-11-18 09:01:26 --> Config Class Initialized
INFO - 2021-11-18 09:01:26 --> Hooks Class Initialized
DEBUG - 2021-11-18 09:01:26 --> UTF-8 Support Enabled
INFO - 2021-11-18 09:01:26 --> Utf8 Class Initialized
INFO - 2021-11-18 09:01:26 --> URI Class Initialized
INFO - 2021-11-18 09:01:26 --> Router Class Initialized
INFO - 2021-11-18 09:01:26 --> Output Class Initialized
INFO - 2021-11-18 09:01:26 --> Security Class Initialized
DEBUG - 2021-11-18 09:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 09:01:26 --> Input Class Initialized
INFO - 2021-11-18 09:01:26 --> Language Class Initialized
INFO - 2021-11-18 09:01:26 --> Language Class Initialized
INFO - 2021-11-18 09:01:26 --> Config Class Initialized
INFO - 2021-11-18 09:01:26 --> Loader Class Initialized
INFO - 2021-11-18 09:01:26 --> Helper loaded: url_helper
INFO - 2021-11-18 09:01:26 --> Helper loaded: file_helper
INFO - 2021-11-18 09:01:26 --> Helper loaded: form_helper
INFO - 2021-11-18 09:01:26 --> Helper loaded: my_helper
INFO - 2021-11-18 09:01:26 --> Database Driver Class Initialized
DEBUG - 2021-11-18 09:01:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 09:01:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 09:01:26 --> Controller Class Initialized
DEBUG - 2021-11-18 09:01:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-18 09:01:26 --> Final output sent to browser
DEBUG - 2021-11-18 09:01:26 --> Total execution time: 0.3911
INFO - 2021-11-18 09:01:36 --> Config Class Initialized
INFO - 2021-11-18 09:01:36 --> Hooks Class Initialized
DEBUG - 2021-11-18 09:01:36 --> UTF-8 Support Enabled
INFO - 2021-11-18 09:01:36 --> Utf8 Class Initialized
INFO - 2021-11-18 09:01:36 --> URI Class Initialized
INFO - 2021-11-18 09:01:36 --> Router Class Initialized
INFO - 2021-11-18 09:01:36 --> Output Class Initialized
INFO - 2021-11-18 09:01:36 --> Security Class Initialized
DEBUG - 2021-11-18 09:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 09:01:36 --> Input Class Initialized
INFO - 2021-11-18 09:01:36 --> Language Class Initialized
INFO - 2021-11-18 09:01:36 --> Language Class Initialized
INFO - 2021-11-18 09:01:36 --> Config Class Initialized
INFO - 2021-11-18 09:01:36 --> Loader Class Initialized
INFO - 2021-11-18 09:01:36 --> Helper loaded: url_helper
INFO - 2021-11-18 09:01:36 --> Helper loaded: file_helper
INFO - 2021-11-18 09:01:36 --> Helper loaded: form_helper
INFO - 2021-11-18 09:01:36 --> Helper loaded: my_helper
INFO - 2021-11-18 09:01:36 --> Database Driver Class Initialized
DEBUG - 2021-11-18 09:01:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 09:01:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 09:01:36 --> Controller Class Initialized
DEBUG - 2021-11-18 09:01:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-18 09:01:37 --> Final output sent to browser
DEBUG - 2021-11-18 09:01:37 --> Total execution time: 0.3983
INFO - 2021-11-18 09:01:59 --> Config Class Initialized
INFO - 2021-11-18 09:01:59 --> Hooks Class Initialized
DEBUG - 2021-11-18 09:01:59 --> UTF-8 Support Enabled
INFO - 2021-11-18 09:01:59 --> Utf8 Class Initialized
INFO - 2021-11-18 09:01:59 --> URI Class Initialized
INFO - 2021-11-18 09:01:59 --> Router Class Initialized
INFO - 2021-11-18 09:01:59 --> Output Class Initialized
INFO - 2021-11-18 09:01:59 --> Security Class Initialized
DEBUG - 2021-11-18 09:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 09:01:59 --> Input Class Initialized
INFO - 2021-11-18 09:01:59 --> Language Class Initialized
INFO - 2021-11-18 09:01:59 --> Language Class Initialized
INFO - 2021-11-18 09:01:59 --> Config Class Initialized
INFO - 2021-11-18 09:01:59 --> Loader Class Initialized
INFO - 2021-11-18 09:01:59 --> Helper loaded: url_helper
INFO - 2021-11-18 09:01:59 --> Helper loaded: file_helper
INFO - 2021-11-18 09:01:59 --> Helper loaded: form_helper
INFO - 2021-11-18 09:01:59 --> Helper loaded: my_helper
INFO - 2021-11-18 09:01:59 --> Database Driver Class Initialized
DEBUG - 2021-11-18 09:01:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 09:01:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 09:01:59 --> Controller Class Initialized
DEBUG - 2021-11-18 09:01:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-18 09:01:59 --> Final output sent to browser
DEBUG - 2021-11-18 09:01:59 --> Total execution time: 0.4168
INFO - 2021-11-18 09:02:38 --> Config Class Initialized
INFO - 2021-11-18 09:02:38 --> Hooks Class Initialized
DEBUG - 2021-11-18 09:02:38 --> UTF-8 Support Enabled
INFO - 2021-11-18 09:02:38 --> Utf8 Class Initialized
INFO - 2021-11-18 09:02:38 --> URI Class Initialized
INFO - 2021-11-18 09:02:38 --> Router Class Initialized
INFO - 2021-11-18 09:02:38 --> Output Class Initialized
INFO - 2021-11-18 09:02:38 --> Security Class Initialized
DEBUG - 2021-11-18 09:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 09:02:38 --> Input Class Initialized
INFO - 2021-11-18 09:02:38 --> Language Class Initialized
INFO - 2021-11-18 09:02:38 --> Language Class Initialized
INFO - 2021-11-18 09:02:38 --> Config Class Initialized
INFO - 2021-11-18 09:02:38 --> Loader Class Initialized
INFO - 2021-11-18 09:02:38 --> Helper loaded: url_helper
INFO - 2021-11-18 09:02:38 --> Helper loaded: file_helper
INFO - 2021-11-18 09:02:38 --> Helper loaded: form_helper
INFO - 2021-11-18 09:02:38 --> Helper loaded: my_helper
INFO - 2021-11-18 09:02:38 --> Database Driver Class Initialized
DEBUG - 2021-11-18 09:02:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 09:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 09:02:38 --> Controller Class Initialized
DEBUG - 2021-11-18 09:02:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-18 09:02:39 --> Final output sent to browser
DEBUG - 2021-11-18 09:02:39 --> Total execution time: 0.4105
INFO - 2021-11-18 09:04:41 --> Config Class Initialized
INFO - 2021-11-18 09:04:41 --> Hooks Class Initialized
DEBUG - 2021-11-18 09:04:41 --> UTF-8 Support Enabled
INFO - 2021-11-18 09:04:41 --> Utf8 Class Initialized
INFO - 2021-11-18 09:04:41 --> URI Class Initialized
INFO - 2021-11-18 09:04:41 --> Router Class Initialized
INFO - 2021-11-18 09:04:41 --> Output Class Initialized
INFO - 2021-11-18 09:04:41 --> Security Class Initialized
DEBUG - 2021-11-18 09:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 09:04:41 --> Input Class Initialized
INFO - 2021-11-18 09:04:41 --> Language Class Initialized
INFO - 2021-11-18 09:04:41 --> Language Class Initialized
INFO - 2021-11-18 09:04:41 --> Config Class Initialized
INFO - 2021-11-18 09:04:41 --> Loader Class Initialized
INFO - 2021-11-18 09:04:41 --> Helper loaded: url_helper
INFO - 2021-11-18 09:04:41 --> Helper loaded: file_helper
INFO - 2021-11-18 09:04:41 --> Helper loaded: form_helper
INFO - 2021-11-18 09:04:41 --> Helper loaded: my_helper
INFO - 2021-11-18 09:04:41 --> Database Driver Class Initialized
DEBUG - 2021-11-18 09:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 09:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 09:04:41 --> Controller Class Initialized
DEBUG - 2021-11-18 09:04:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-18 09:04:41 --> Final output sent to browser
DEBUG - 2021-11-18 09:04:41 --> Total execution time: 0.1355
INFO - 2021-11-18 09:04:53 --> Config Class Initialized
INFO - 2021-11-18 09:04:53 --> Hooks Class Initialized
DEBUG - 2021-11-18 09:04:53 --> UTF-8 Support Enabled
INFO - 2021-11-18 09:04:53 --> Utf8 Class Initialized
INFO - 2021-11-18 09:04:53 --> URI Class Initialized
INFO - 2021-11-18 09:04:53 --> Router Class Initialized
INFO - 2021-11-18 09:04:53 --> Output Class Initialized
INFO - 2021-11-18 09:04:53 --> Security Class Initialized
DEBUG - 2021-11-18 09:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 09:04:53 --> Input Class Initialized
INFO - 2021-11-18 09:04:53 --> Language Class Initialized
INFO - 2021-11-18 09:04:53 --> Language Class Initialized
INFO - 2021-11-18 09:04:53 --> Config Class Initialized
INFO - 2021-11-18 09:04:53 --> Loader Class Initialized
INFO - 2021-11-18 09:04:53 --> Helper loaded: url_helper
INFO - 2021-11-18 09:04:53 --> Helper loaded: file_helper
INFO - 2021-11-18 09:04:53 --> Helper loaded: form_helper
INFO - 2021-11-18 09:04:53 --> Helper loaded: my_helper
INFO - 2021-11-18 09:04:53 --> Database Driver Class Initialized
DEBUG - 2021-11-18 09:04:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 09:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 09:04:53 --> Controller Class Initialized
DEBUG - 2021-11-18 09:04:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-18 09:04:53 --> Final output sent to browser
DEBUG - 2021-11-18 09:04:53 --> Total execution time: 0.1509
INFO - 2021-11-18 09:05:57 --> Config Class Initialized
INFO - 2021-11-18 09:05:57 --> Hooks Class Initialized
DEBUG - 2021-11-18 09:05:57 --> UTF-8 Support Enabled
INFO - 2021-11-18 09:05:57 --> Utf8 Class Initialized
INFO - 2021-11-18 09:05:57 --> URI Class Initialized
INFO - 2021-11-18 09:05:57 --> Router Class Initialized
INFO - 2021-11-18 09:05:57 --> Output Class Initialized
INFO - 2021-11-18 09:05:57 --> Security Class Initialized
DEBUG - 2021-11-18 09:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 09:05:57 --> Input Class Initialized
INFO - 2021-11-18 09:05:57 --> Language Class Initialized
INFO - 2021-11-18 09:05:57 --> Language Class Initialized
INFO - 2021-11-18 09:05:57 --> Config Class Initialized
INFO - 2021-11-18 09:05:57 --> Loader Class Initialized
INFO - 2021-11-18 09:05:57 --> Helper loaded: url_helper
INFO - 2021-11-18 09:05:57 --> Helper loaded: file_helper
INFO - 2021-11-18 09:05:57 --> Helper loaded: form_helper
INFO - 2021-11-18 09:05:57 --> Helper loaded: my_helper
INFO - 2021-11-18 09:05:57 --> Database Driver Class Initialized
DEBUG - 2021-11-18 09:05:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 09:05:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 09:05:57 --> Controller Class Initialized
DEBUG - 2021-11-18 09:05:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-18 09:05:57 --> Final output sent to browser
DEBUG - 2021-11-18 09:05:57 --> Total execution time: 0.1373
INFO - 2021-11-18 09:06:10 --> Config Class Initialized
INFO - 2021-11-18 09:06:10 --> Hooks Class Initialized
DEBUG - 2021-11-18 09:06:10 --> UTF-8 Support Enabled
INFO - 2021-11-18 09:06:10 --> Utf8 Class Initialized
INFO - 2021-11-18 09:06:10 --> URI Class Initialized
INFO - 2021-11-18 09:06:10 --> Router Class Initialized
INFO - 2021-11-18 09:06:10 --> Output Class Initialized
INFO - 2021-11-18 09:06:10 --> Security Class Initialized
DEBUG - 2021-11-18 09:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 09:06:10 --> Input Class Initialized
INFO - 2021-11-18 09:06:10 --> Language Class Initialized
INFO - 2021-11-18 09:06:10 --> Language Class Initialized
INFO - 2021-11-18 09:06:10 --> Config Class Initialized
INFO - 2021-11-18 09:06:10 --> Loader Class Initialized
INFO - 2021-11-18 09:06:10 --> Helper loaded: url_helper
INFO - 2021-11-18 09:06:10 --> Helper loaded: file_helper
INFO - 2021-11-18 09:06:10 --> Helper loaded: form_helper
INFO - 2021-11-18 09:06:10 --> Helper loaded: my_helper
INFO - 2021-11-18 09:06:10 --> Database Driver Class Initialized
DEBUG - 2021-11-18 09:06:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 09:06:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 09:06:10 --> Controller Class Initialized
DEBUG - 2021-11-18 09:06:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-18 09:06:10 --> Final output sent to browser
DEBUG - 2021-11-18 09:06:10 --> Total execution time: 0.1568
INFO - 2021-11-18 09:06:41 --> Config Class Initialized
INFO - 2021-11-18 09:06:41 --> Hooks Class Initialized
DEBUG - 2021-11-18 09:06:41 --> UTF-8 Support Enabled
INFO - 2021-11-18 09:06:41 --> Utf8 Class Initialized
INFO - 2021-11-18 09:06:41 --> URI Class Initialized
INFO - 2021-11-18 09:06:41 --> Router Class Initialized
INFO - 2021-11-18 09:06:41 --> Output Class Initialized
INFO - 2021-11-18 09:06:41 --> Security Class Initialized
DEBUG - 2021-11-18 09:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 09:06:41 --> Input Class Initialized
INFO - 2021-11-18 09:06:41 --> Language Class Initialized
INFO - 2021-11-18 09:06:41 --> Language Class Initialized
INFO - 2021-11-18 09:06:41 --> Config Class Initialized
INFO - 2021-11-18 09:06:41 --> Loader Class Initialized
INFO - 2021-11-18 09:06:41 --> Helper loaded: url_helper
INFO - 2021-11-18 09:06:41 --> Helper loaded: file_helper
INFO - 2021-11-18 09:06:41 --> Helper loaded: form_helper
INFO - 2021-11-18 09:06:41 --> Helper loaded: my_helper
INFO - 2021-11-18 09:06:41 --> Database Driver Class Initialized
DEBUG - 2021-11-18 09:06:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 09:06:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 09:06:41 --> Controller Class Initialized
DEBUG - 2021-11-18 09:06:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-18 09:06:41 --> Final output sent to browser
DEBUG - 2021-11-18 09:06:41 --> Total execution time: 0.1238
INFO - 2021-11-18 09:09:20 --> Config Class Initialized
INFO - 2021-11-18 09:09:20 --> Hooks Class Initialized
DEBUG - 2021-11-18 09:09:20 --> UTF-8 Support Enabled
INFO - 2021-11-18 09:09:20 --> Utf8 Class Initialized
INFO - 2021-11-18 09:09:20 --> URI Class Initialized
INFO - 2021-11-18 09:09:20 --> Router Class Initialized
INFO - 2021-11-18 09:09:20 --> Output Class Initialized
INFO - 2021-11-18 09:09:20 --> Security Class Initialized
DEBUG - 2021-11-18 09:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 09:09:20 --> Input Class Initialized
INFO - 2021-11-18 09:09:20 --> Language Class Initialized
INFO - 2021-11-18 09:09:20 --> Language Class Initialized
INFO - 2021-11-18 09:09:20 --> Config Class Initialized
INFO - 2021-11-18 09:09:20 --> Loader Class Initialized
INFO - 2021-11-18 09:09:20 --> Helper loaded: url_helper
INFO - 2021-11-18 09:09:20 --> Helper loaded: file_helper
INFO - 2021-11-18 09:09:20 --> Helper loaded: form_helper
INFO - 2021-11-18 09:09:20 --> Helper loaded: my_helper
INFO - 2021-11-18 09:09:20 --> Database Driver Class Initialized
DEBUG - 2021-11-18 09:09:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 09:09:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 09:09:20 --> Controller Class Initialized
DEBUG - 2021-11-18 09:09:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-18 09:09:20 --> Final output sent to browser
DEBUG - 2021-11-18 09:09:20 --> Total execution time: 0.1357
INFO - 2021-11-18 09:09:33 --> Config Class Initialized
INFO - 2021-11-18 09:09:33 --> Hooks Class Initialized
DEBUG - 2021-11-18 09:09:33 --> UTF-8 Support Enabled
INFO - 2021-11-18 09:09:33 --> Utf8 Class Initialized
INFO - 2021-11-18 09:09:33 --> URI Class Initialized
INFO - 2021-11-18 09:09:33 --> Router Class Initialized
INFO - 2021-11-18 09:09:33 --> Output Class Initialized
INFO - 2021-11-18 09:09:33 --> Security Class Initialized
DEBUG - 2021-11-18 09:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 09:09:33 --> Input Class Initialized
INFO - 2021-11-18 09:09:33 --> Language Class Initialized
INFO - 2021-11-18 09:09:33 --> Language Class Initialized
INFO - 2021-11-18 09:09:33 --> Config Class Initialized
INFO - 2021-11-18 09:09:33 --> Loader Class Initialized
INFO - 2021-11-18 09:09:33 --> Helper loaded: url_helper
INFO - 2021-11-18 09:09:33 --> Helper loaded: file_helper
INFO - 2021-11-18 09:09:33 --> Helper loaded: form_helper
INFO - 2021-11-18 09:09:33 --> Helper loaded: my_helper
INFO - 2021-11-18 09:09:33 --> Database Driver Class Initialized
DEBUG - 2021-11-18 09:09:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 09:09:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 09:09:33 --> Controller Class Initialized
DEBUG - 2021-11-18 09:09:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-18 09:09:33 --> Final output sent to browser
DEBUG - 2021-11-18 09:09:33 --> Total execution time: 0.1597
INFO - 2021-11-18 09:09:42 --> Config Class Initialized
INFO - 2021-11-18 09:09:42 --> Hooks Class Initialized
DEBUG - 2021-11-18 09:09:42 --> UTF-8 Support Enabled
INFO - 2021-11-18 09:09:42 --> Utf8 Class Initialized
INFO - 2021-11-18 09:09:42 --> URI Class Initialized
INFO - 2021-11-18 09:09:42 --> Router Class Initialized
INFO - 2021-11-18 09:09:42 --> Output Class Initialized
INFO - 2021-11-18 09:09:42 --> Security Class Initialized
DEBUG - 2021-11-18 09:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 09:09:42 --> Input Class Initialized
INFO - 2021-11-18 09:09:42 --> Language Class Initialized
INFO - 2021-11-18 09:09:42 --> Language Class Initialized
INFO - 2021-11-18 09:09:42 --> Config Class Initialized
INFO - 2021-11-18 09:09:42 --> Loader Class Initialized
INFO - 2021-11-18 09:09:42 --> Helper loaded: url_helper
INFO - 2021-11-18 09:09:42 --> Helper loaded: file_helper
INFO - 2021-11-18 09:09:42 --> Helper loaded: form_helper
INFO - 2021-11-18 09:09:42 --> Helper loaded: my_helper
INFO - 2021-11-18 09:09:42 --> Database Driver Class Initialized
DEBUG - 2021-11-18 09:09:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 09:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 09:09:42 --> Controller Class Initialized
DEBUG - 2021-11-18 09:09:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-18 09:09:42 --> Final output sent to browser
DEBUG - 2021-11-18 09:09:42 --> Total execution time: 0.1343
INFO - 2021-11-18 09:10:25 --> Config Class Initialized
INFO - 2021-11-18 09:10:25 --> Hooks Class Initialized
DEBUG - 2021-11-18 09:10:25 --> UTF-8 Support Enabled
INFO - 2021-11-18 09:10:25 --> Utf8 Class Initialized
INFO - 2021-11-18 09:10:25 --> URI Class Initialized
INFO - 2021-11-18 09:10:25 --> Router Class Initialized
INFO - 2021-11-18 09:10:25 --> Output Class Initialized
INFO - 2021-11-18 09:10:25 --> Security Class Initialized
DEBUG - 2021-11-18 09:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 09:10:25 --> Input Class Initialized
INFO - 2021-11-18 09:10:25 --> Language Class Initialized
INFO - 2021-11-18 09:10:25 --> Language Class Initialized
INFO - 2021-11-18 09:10:25 --> Config Class Initialized
INFO - 2021-11-18 09:10:25 --> Loader Class Initialized
INFO - 2021-11-18 09:10:25 --> Helper loaded: url_helper
INFO - 2021-11-18 09:10:25 --> Helper loaded: file_helper
INFO - 2021-11-18 09:10:25 --> Helper loaded: form_helper
INFO - 2021-11-18 09:10:25 --> Helper loaded: my_helper
INFO - 2021-11-18 09:10:25 --> Database Driver Class Initialized
DEBUG - 2021-11-18 09:10:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 09:10:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 09:10:25 --> Controller Class Initialized
DEBUG - 2021-11-18 09:10:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-18 09:10:25 --> Final output sent to browser
DEBUG - 2021-11-18 09:10:25 --> Total execution time: 0.1724
INFO - 2021-11-18 09:11:19 --> Config Class Initialized
INFO - 2021-11-18 09:11:19 --> Hooks Class Initialized
DEBUG - 2021-11-18 09:11:19 --> UTF-8 Support Enabled
INFO - 2021-11-18 09:11:19 --> Utf8 Class Initialized
INFO - 2021-11-18 09:11:19 --> URI Class Initialized
INFO - 2021-11-18 09:11:19 --> Router Class Initialized
INFO - 2021-11-18 09:11:19 --> Output Class Initialized
INFO - 2021-11-18 09:11:19 --> Security Class Initialized
DEBUG - 2021-11-18 09:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 09:11:19 --> Input Class Initialized
INFO - 2021-11-18 09:11:19 --> Language Class Initialized
INFO - 2021-11-18 09:11:19 --> Language Class Initialized
INFO - 2021-11-18 09:11:19 --> Config Class Initialized
INFO - 2021-11-18 09:11:19 --> Loader Class Initialized
INFO - 2021-11-18 09:11:19 --> Helper loaded: url_helper
INFO - 2021-11-18 09:11:19 --> Helper loaded: file_helper
INFO - 2021-11-18 09:11:19 --> Helper loaded: form_helper
INFO - 2021-11-18 09:11:19 --> Helper loaded: my_helper
INFO - 2021-11-18 09:11:19 --> Database Driver Class Initialized
DEBUG - 2021-11-18 09:11:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 09:11:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 09:11:19 --> Controller Class Initialized
DEBUG - 2021-11-18 09:11:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-18 09:11:20 --> Final output sent to browser
DEBUG - 2021-11-18 09:11:20 --> Total execution time: 0.1593
INFO - 2021-11-18 09:32:40 --> Config Class Initialized
INFO - 2021-11-18 09:32:40 --> Hooks Class Initialized
DEBUG - 2021-11-18 09:32:40 --> UTF-8 Support Enabled
INFO - 2021-11-18 09:32:40 --> Utf8 Class Initialized
INFO - 2021-11-18 09:32:40 --> URI Class Initialized
INFO - 2021-11-18 09:32:40 --> Router Class Initialized
INFO - 2021-11-18 09:32:40 --> Output Class Initialized
INFO - 2021-11-18 09:32:40 --> Security Class Initialized
DEBUG - 2021-11-18 09:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 09:32:40 --> Input Class Initialized
INFO - 2021-11-18 09:32:40 --> Language Class Initialized
INFO - 2021-11-18 09:32:40 --> Language Class Initialized
INFO - 2021-11-18 09:32:40 --> Config Class Initialized
INFO - 2021-11-18 09:32:40 --> Loader Class Initialized
INFO - 2021-11-18 09:32:40 --> Helper loaded: url_helper
INFO - 2021-11-18 09:32:40 --> Helper loaded: file_helper
INFO - 2021-11-18 09:32:40 --> Helper loaded: form_helper
INFO - 2021-11-18 09:32:40 --> Helper loaded: my_helper
INFO - 2021-11-18 09:32:40 --> Database Driver Class Initialized
DEBUG - 2021-11-18 09:32:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 09:32:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 09:32:40 --> Controller Class Initialized
DEBUG - 2021-11-18 09:32:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-18 09:32:40 --> Final output sent to browser
DEBUG - 2021-11-18 09:32:40 --> Total execution time: 0.2233
INFO - 2021-11-18 09:33:31 --> Config Class Initialized
INFO - 2021-11-18 09:33:31 --> Hooks Class Initialized
DEBUG - 2021-11-18 09:33:31 --> UTF-8 Support Enabled
INFO - 2021-11-18 09:33:31 --> Utf8 Class Initialized
INFO - 2021-11-18 09:33:31 --> URI Class Initialized
INFO - 2021-11-18 09:33:31 --> Router Class Initialized
INFO - 2021-11-18 09:33:31 --> Output Class Initialized
INFO - 2021-11-18 09:33:31 --> Security Class Initialized
DEBUG - 2021-11-18 09:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 09:33:31 --> Input Class Initialized
INFO - 2021-11-18 09:33:31 --> Language Class Initialized
INFO - 2021-11-18 09:33:31 --> Language Class Initialized
INFO - 2021-11-18 09:33:31 --> Config Class Initialized
INFO - 2021-11-18 09:33:31 --> Loader Class Initialized
INFO - 2021-11-18 09:33:31 --> Helper loaded: url_helper
INFO - 2021-11-18 09:33:31 --> Helper loaded: file_helper
INFO - 2021-11-18 09:33:31 --> Helper loaded: form_helper
INFO - 2021-11-18 09:33:31 --> Helper loaded: my_helper
INFO - 2021-11-18 09:33:31 --> Database Driver Class Initialized
DEBUG - 2021-11-18 09:33:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 09:33:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 09:33:31 --> Controller Class Initialized
DEBUG - 2021-11-18 09:33:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-18 09:33:31 --> Final output sent to browser
DEBUG - 2021-11-18 09:33:31 --> Total execution time: 0.1360
INFO - 2021-11-18 09:38:09 --> Config Class Initialized
INFO - 2021-11-18 09:38:09 --> Hooks Class Initialized
DEBUG - 2021-11-18 09:38:09 --> UTF-8 Support Enabled
INFO - 2021-11-18 09:38:09 --> Utf8 Class Initialized
INFO - 2021-11-18 09:38:09 --> URI Class Initialized
INFO - 2021-11-18 09:38:09 --> Router Class Initialized
INFO - 2021-11-18 09:38:09 --> Output Class Initialized
INFO - 2021-11-18 09:38:09 --> Security Class Initialized
DEBUG - 2021-11-18 09:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 09:38:09 --> Input Class Initialized
INFO - 2021-11-18 09:38:09 --> Language Class Initialized
INFO - 2021-11-18 09:38:09 --> Language Class Initialized
INFO - 2021-11-18 09:38:09 --> Config Class Initialized
INFO - 2021-11-18 09:38:09 --> Loader Class Initialized
INFO - 2021-11-18 09:38:09 --> Helper loaded: url_helper
INFO - 2021-11-18 09:38:09 --> Helper loaded: file_helper
INFO - 2021-11-18 09:38:09 --> Helper loaded: form_helper
INFO - 2021-11-18 09:38:09 --> Helper loaded: my_helper
INFO - 2021-11-18 09:38:09 --> Database Driver Class Initialized
DEBUG - 2021-11-18 09:38:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 09:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 09:38:09 --> Controller Class Initialized
DEBUG - 2021-11-18 09:38:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-18 09:38:09 --> Final output sent to browser
DEBUG - 2021-11-18 09:38:09 --> Total execution time: 0.1515
INFO - 2021-11-18 09:40:38 --> Config Class Initialized
INFO - 2021-11-18 09:40:38 --> Hooks Class Initialized
DEBUG - 2021-11-18 09:40:38 --> UTF-8 Support Enabled
INFO - 2021-11-18 09:40:38 --> Utf8 Class Initialized
INFO - 2021-11-18 09:40:38 --> URI Class Initialized
INFO - 2021-11-18 09:40:38 --> Router Class Initialized
INFO - 2021-11-18 09:40:38 --> Output Class Initialized
INFO - 2021-11-18 09:40:38 --> Security Class Initialized
DEBUG - 2021-11-18 09:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 09:40:38 --> Input Class Initialized
INFO - 2021-11-18 09:40:38 --> Language Class Initialized
INFO - 2021-11-18 09:40:38 --> Language Class Initialized
INFO - 2021-11-18 09:40:38 --> Config Class Initialized
INFO - 2021-11-18 09:40:38 --> Loader Class Initialized
INFO - 2021-11-18 09:40:38 --> Helper loaded: url_helper
INFO - 2021-11-18 09:40:38 --> Helper loaded: file_helper
INFO - 2021-11-18 09:40:38 --> Helper loaded: form_helper
INFO - 2021-11-18 09:40:38 --> Helper loaded: my_helper
INFO - 2021-11-18 09:40:38 --> Database Driver Class Initialized
DEBUG - 2021-11-18 09:40:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 09:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 09:40:38 --> Controller Class Initialized
DEBUG - 2021-11-18 09:40:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-18 09:40:38 --> Final output sent to browser
DEBUG - 2021-11-18 09:40:38 --> Total execution time: 0.1415
INFO - 2021-11-18 09:44:43 --> Config Class Initialized
INFO - 2021-11-18 09:44:43 --> Hooks Class Initialized
DEBUG - 2021-11-18 09:44:43 --> UTF-8 Support Enabled
INFO - 2021-11-18 09:44:43 --> Utf8 Class Initialized
INFO - 2021-11-18 09:44:43 --> URI Class Initialized
INFO - 2021-11-18 09:44:43 --> Router Class Initialized
INFO - 2021-11-18 09:44:43 --> Output Class Initialized
INFO - 2021-11-18 09:44:43 --> Security Class Initialized
DEBUG - 2021-11-18 09:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 09:44:43 --> Input Class Initialized
INFO - 2021-11-18 09:44:43 --> Language Class Initialized
INFO - 2021-11-18 09:44:43 --> Language Class Initialized
INFO - 2021-11-18 09:44:43 --> Config Class Initialized
INFO - 2021-11-18 09:44:43 --> Loader Class Initialized
INFO - 2021-11-18 09:44:43 --> Helper loaded: url_helper
INFO - 2021-11-18 09:44:43 --> Helper loaded: file_helper
INFO - 2021-11-18 09:44:43 --> Helper loaded: form_helper
INFO - 2021-11-18 09:44:43 --> Helper loaded: my_helper
INFO - 2021-11-18 09:44:43 --> Database Driver Class Initialized
DEBUG - 2021-11-18 09:44:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 09:44:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 09:44:43 --> Controller Class Initialized
DEBUG - 2021-11-18 09:44:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-18 09:44:43 --> Final output sent to browser
DEBUG - 2021-11-18 09:44:43 --> Total execution time: 0.1720
INFO - 2021-11-18 09:45:11 --> Config Class Initialized
INFO - 2021-11-18 09:45:11 --> Hooks Class Initialized
DEBUG - 2021-11-18 09:45:11 --> UTF-8 Support Enabled
INFO - 2021-11-18 09:45:11 --> Utf8 Class Initialized
INFO - 2021-11-18 09:45:11 --> URI Class Initialized
INFO - 2021-11-18 09:45:11 --> Router Class Initialized
INFO - 2021-11-18 09:45:11 --> Output Class Initialized
INFO - 2021-11-18 09:45:11 --> Security Class Initialized
DEBUG - 2021-11-18 09:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 09:45:11 --> Input Class Initialized
INFO - 2021-11-18 09:45:11 --> Language Class Initialized
INFO - 2021-11-18 09:45:11 --> Language Class Initialized
INFO - 2021-11-18 09:45:11 --> Config Class Initialized
INFO - 2021-11-18 09:45:11 --> Loader Class Initialized
INFO - 2021-11-18 09:45:11 --> Helper loaded: url_helper
INFO - 2021-11-18 09:45:11 --> Helper loaded: file_helper
INFO - 2021-11-18 09:45:11 --> Helper loaded: form_helper
INFO - 2021-11-18 09:45:11 --> Helper loaded: my_helper
INFO - 2021-11-18 09:45:11 --> Database Driver Class Initialized
DEBUG - 2021-11-18 09:45:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 09:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 09:45:11 --> Controller Class Initialized
DEBUG - 2021-11-18 09:45:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-18 09:45:11 --> Final output sent to browser
DEBUG - 2021-11-18 09:45:11 --> Total execution time: 0.1337
INFO - 2021-11-18 09:45:15 --> Config Class Initialized
INFO - 2021-11-18 09:45:15 --> Hooks Class Initialized
DEBUG - 2021-11-18 09:45:15 --> UTF-8 Support Enabled
INFO - 2021-11-18 09:45:15 --> Utf8 Class Initialized
INFO - 2021-11-18 09:45:15 --> URI Class Initialized
INFO - 2021-11-18 09:45:15 --> Router Class Initialized
INFO - 2021-11-18 09:45:15 --> Output Class Initialized
INFO - 2021-11-18 09:45:15 --> Security Class Initialized
DEBUG - 2021-11-18 09:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 09:45:15 --> Input Class Initialized
INFO - 2021-11-18 09:45:15 --> Language Class Initialized
INFO - 2021-11-18 09:45:15 --> Language Class Initialized
INFO - 2021-11-18 09:45:15 --> Config Class Initialized
INFO - 2021-11-18 09:45:15 --> Loader Class Initialized
INFO - 2021-11-18 09:45:15 --> Helper loaded: url_helper
INFO - 2021-11-18 09:45:15 --> Helper loaded: file_helper
INFO - 2021-11-18 09:45:15 --> Helper loaded: form_helper
INFO - 2021-11-18 09:45:15 --> Helper loaded: my_helper
INFO - 2021-11-18 09:45:15 --> Database Driver Class Initialized
DEBUG - 2021-11-18 09:45:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 09:45:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 09:45:15 --> Controller Class Initialized
DEBUG - 2021-11-18 09:45:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-18 09:45:15 --> Final output sent to browser
DEBUG - 2021-11-18 09:45:15 --> Total execution time: 0.1801
INFO - 2021-11-18 09:46:03 --> Config Class Initialized
INFO - 2021-11-18 09:46:03 --> Hooks Class Initialized
DEBUG - 2021-11-18 09:46:03 --> UTF-8 Support Enabled
INFO - 2021-11-18 09:46:03 --> Utf8 Class Initialized
INFO - 2021-11-18 09:46:03 --> URI Class Initialized
INFO - 2021-11-18 09:46:03 --> Router Class Initialized
INFO - 2021-11-18 09:46:03 --> Output Class Initialized
INFO - 2021-11-18 09:46:03 --> Security Class Initialized
DEBUG - 2021-11-18 09:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 09:46:03 --> Input Class Initialized
INFO - 2021-11-18 09:46:03 --> Language Class Initialized
INFO - 2021-11-18 09:46:03 --> Language Class Initialized
INFO - 2021-11-18 09:46:03 --> Config Class Initialized
INFO - 2021-11-18 09:46:03 --> Loader Class Initialized
INFO - 2021-11-18 09:46:03 --> Helper loaded: url_helper
INFO - 2021-11-18 09:46:03 --> Helper loaded: file_helper
INFO - 2021-11-18 09:46:03 --> Helper loaded: form_helper
INFO - 2021-11-18 09:46:03 --> Helper loaded: my_helper
INFO - 2021-11-18 09:46:03 --> Database Driver Class Initialized
DEBUG - 2021-11-18 09:46:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 09:46:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 09:46:03 --> Controller Class Initialized
DEBUG - 2021-11-18 09:46:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-18 09:46:03 --> Final output sent to browser
DEBUG - 2021-11-18 09:46:03 --> Total execution time: 0.1336
INFO - 2021-11-18 09:46:14 --> Config Class Initialized
INFO - 2021-11-18 09:46:14 --> Hooks Class Initialized
DEBUG - 2021-11-18 09:46:14 --> UTF-8 Support Enabled
INFO - 2021-11-18 09:46:14 --> Utf8 Class Initialized
INFO - 2021-11-18 09:46:14 --> URI Class Initialized
INFO - 2021-11-18 09:46:14 --> Router Class Initialized
INFO - 2021-11-18 09:46:14 --> Output Class Initialized
INFO - 2021-11-18 09:46:14 --> Security Class Initialized
DEBUG - 2021-11-18 09:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 09:46:14 --> Input Class Initialized
INFO - 2021-11-18 09:46:14 --> Language Class Initialized
INFO - 2021-11-18 09:46:14 --> Language Class Initialized
INFO - 2021-11-18 09:46:14 --> Config Class Initialized
INFO - 2021-11-18 09:46:14 --> Loader Class Initialized
INFO - 2021-11-18 09:46:14 --> Helper loaded: url_helper
INFO - 2021-11-18 09:46:14 --> Helper loaded: file_helper
INFO - 2021-11-18 09:46:14 --> Helper loaded: form_helper
INFO - 2021-11-18 09:46:14 --> Helper loaded: my_helper
INFO - 2021-11-18 09:46:14 --> Database Driver Class Initialized
DEBUG - 2021-11-18 09:46:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 09:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 09:46:14 --> Controller Class Initialized
DEBUG - 2021-11-18 09:46:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-18 09:46:14 --> Final output sent to browser
DEBUG - 2021-11-18 09:46:14 --> Total execution time: 0.1931
INFO - 2021-11-18 09:46:24 --> Config Class Initialized
INFO - 2021-11-18 09:46:24 --> Hooks Class Initialized
DEBUG - 2021-11-18 09:46:24 --> UTF-8 Support Enabled
INFO - 2021-11-18 09:46:24 --> Utf8 Class Initialized
INFO - 2021-11-18 09:46:24 --> URI Class Initialized
INFO - 2021-11-18 09:46:24 --> Router Class Initialized
INFO - 2021-11-18 09:46:24 --> Output Class Initialized
INFO - 2021-11-18 09:46:24 --> Security Class Initialized
DEBUG - 2021-11-18 09:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 09:46:24 --> Input Class Initialized
INFO - 2021-11-18 09:46:24 --> Language Class Initialized
INFO - 2021-11-18 09:46:24 --> Language Class Initialized
INFO - 2021-11-18 09:46:24 --> Config Class Initialized
INFO - 2021-11-18 09:46:24 --> Loader Class Initialized
INFO - 2021-11-18 09:46:24 --> Helper loaded: url_helper
INFO - 2021-11-18 09:46:24 --> Helper loaded: file_helper
INFO - 2021-11-18 09:46:24 --> Helper loaded: form_helper
INFO - 2021-11-18 09:46:24 --> Helper loaded: my_helper
INFO - 2021-11-18 09:46:24 --> Database Driver Class Initialized
DEBUG - 2021-11-18 09:46:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 09:46:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 09:46:24 --> Controller Class Initialized
DEBUG - 2021-11-18 09:46:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-18 09:46:24 --> Final output sent to browser
DEBUG - 2021-11-18 09:46:24 --> Total execution time: 0.1725
INFO - 2021-11-18 09:49:01 --> Config Class Initialized
INFO - 2021-11-18 09:49:01 --> Hooks Class Initialized
DEBUG - 2021-11-18 09:49:01 --> UTF-8 Support Enabled
INFO - 2021-11-18 09:49:01 --> Utf8 Class Initialized
INFO - 2021-11-18 09:49:01 --> URI Class Initialized
INFO - 2021-11-18 09:49:01 --> Router Class Initialized
INFO - 2021-11-18 09:49:01 --> Output Class Initialized
INFO - 2021-11-18 09:49:01 --> Security Class Initialized
DEBUG - 2021-11-18 09:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 09:49:01 --> Input Class Initialized
INFO - 2021-11-18 09:49:01 --> Language Class Initialized
INFO - 2021-11-18 09:49:01 --> Language Class Initialized
INFO - 2021-11-18 09:49:01 --> Config Class Initialized
INFO - 2021-11-18 09:49:01 --> Loader Class Initialized
INFO - 2021-11-18 09:49:01 --> Helper loaded: url_helper
INFO - 2021-11-18 09:49:01 --> Helper loaded: file_helper
INFO - 2021-11-18 09:49:01 --> Helper loaded: form_helper
INFO - 2021-11-18 09:49:01 --> Helper loaded: my_helper
INFO - 2021-11-18 09:49:01 --> Database Driver Class Initialized
DEBUG - 2021-11-18 09:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 09:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 09:49:01 --> Controller Class Initialized
DEBUG - 2021-11-18 09:49:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-18 09:49:01 --> Final output sent to browser
DEBUG - 2021-11-18 09:49:01 --> Total execution time: 0.1722
INFO - 2021-11-18 09:49:25 --> Config Class Initialized
INFO - 2021-11-18 09:49:25 --> Hooks Class Initialized
DEBUG - 2021-11-18 09:49:25 --> UTF-8 Support Enabled
INFO - 2021-11-18 09:49:25 --> Utf8 Class Initialized
INFO - 2021-11-18 09:49:25 --> URI Class Initialized
INFO - 2021-11-18 09:49:25 --> Router Class Initialized
INFO - 2021-11-18 09:49:25 --> Output Class Initialized
INFO - 2021-11-18 09:49:25 --> Security Class Initialized
DEBUG - 2021-11-18 09:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 09:49:25 --> Input Class Initialized
INFO - 2021-11-18 09:49:25 --> Language Class Initialized
INFO - 2021-11-18 09:49:25 --> Language Class Initialized
INFO - 2021-11-18 09:49:25 --> Config Class Initialized
INFO - 2021-11-18 09:49:25 --> Loader Class Initialized
INFO - 2021-11-18 09:49:25 --> Helper loaded: url_helper
INFO - 2021-11-18 09:49:25 --> Helper loaded: file_helper
INFO - 2021-11-18 09:49:25 --> Helper loaded: form_helper
INFO - 2021-11-18 09:49:25 --> Helper loaded: my_helper
INFO - 2021-11-18 09:49:25 --> Database Driver Class Initialized
DEBUG - 2021-11-18 09:49:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 09:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 09:49:25 --> Controller Class Initialized
DEBUG - 2021-11-18 09:49:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-18 09:49:26 --> Final output sent to browser
DEBUG - 2021-11-18 09:49:26 --> Total execution time: 0.1568
INFO - 2021-11-18 09:50:41 --> Config Class Initialized
INFO - 2021-11-18 09:50:41 --> Hooks Class Initialized
DEBUG - 2021-11-18 09:50:41 --> UTF-8 Support Enabled
INFO - 2021-11-18 09:50:41 --> Utf8 Class Initialized
INFO - 2021-11-18 09:50:41 --> URI Class Initialized
INFO - 2021-11-18 09:50:41 --> Router Class Initialized
INFO - 2021-11-18 09:50:41 --> Output Class Initialized
INFO - 2021-11-18 09:50:41 --> Security Class Initialized
DEBUG - 2021-11-18 09:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 09:50:41 --> Input Class Initialized
INFO - 2021-11-18 09:50:41 --> Language Class Initialized
INFO - 2021-11-18 09:50:41 --> Language Class Initialized
INFO - 2021-11-18 09:50:41 --> Config Class Initialized
INFO - 2021-11-18 09:50:41 --> Loader Class Initialized
INFO - 2021-11-18 09:50:41 --> Helper loaded: url_helper
INFO - 2021-11-18 09:50:41 --> Helper loaded: file_helper
INFO - 2021-11-18 09:50:41 --> Helper loaded: form_helper
INFO - 2021-11-18 09:50:41 --> Helper loaded: my_helper
INFO - 2021-11-18 09:50:41 --> Database Driver Class Initialized
DEBUG - 2021-11-18 09:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 09:50:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 09:50:41 --> Controller Class Initialized
DEBUG - 2021-11-18 09:50:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-18 09:50:41 --> Final output sent to browser
DEBUG - 2021-11-18 09:50:41 --> Total execution time: 0.1534
INFO - 2021-11-18 09:50:57 --> Config Class Initialized
INFO - 2021-11-18 09:50:57 --> Hooks Class Initialized
DEBUG - 2021-11-18 09:50:57 --> UTF-8 Support Enabled
INFO - 2021-11-18 09:50:57 --> Utf8 Class Initialized
INFO - 2021-11-18 09:50:57 --> URI Class Initialized
INFO - 2021-11-18 09:50:57 --> Router Class Initialized
INFO - 2021-11-18 09:50:57 --> Output Class Initialized
INFO - 2021-11-18 09:50:57 --> Security Class Initialized
DEBUG - 2021-11-18 09:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 09:50:57 --> Input Class Initialized
INFO - 2021-11-18 09:50:57 --> Language Class Initialized
INFO - 2021-11-18 09:50:57 --> Language Class Initialized
INFO - 2021-11-18 09:50:57 --> Config Class Initialized
INFO - 2021-11-18 09:50:57 --> Loader Class Initialized
INFO - 2021-11-18 09:50:57 --> Helper loaded: url_helper
INFO - 2021-11-18 09:50:57 --> Helper loaded: file_helper
INFO - 2021-11-18 09:50:57 --> Helper loaded: form_helper
INFO - 2021-11-18 09:50:57 --> Helper loaded: my_helper
INFO - 2021-11-18 09:50:57 --> Database Driver Class Initialized
DEBUG - 2021-11-18 09:50:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 09:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 09:50:57 --> Controller Class Initialized
DEBUG - 2021-11-18 09:50:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-18 09:50:57 --> Final output sent to browser
DEBUG - 2021-11-18 09:50:57 --> Total execution time: 0.1444
INFO - 2021-11-18 09:51:35 --> Config Class Initialized
INFO - 2021-11-18 09:51:35 --> Hooks Class Initialized
DEBUG - 2021-11-18 09:51:35 --> UTF-8 Support Enabled
INFO - 2021-11-18 09:51:35 --> Utf8 Class Initialized
INFO - 2021-11-18 09:51:35 --> URI Class Initialized
INFO - 2021-11-18 09:51:35 --> Router Class Initialized
INFO - 2021-11-18 09:51:35 --> Output Class Initialized
INFO - 2021-11-18 09:51:35 --> Security Class Initialized
DEBUG - 2021-11-18 09:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 09:51:35 --> Input Class Initialized
INFO - 2021-11-18 09:51:35 --> Language Class Initialized
INFO - 2021-11-18 09:51:35 --> Language Class Initialized
INFO - 2021-11-18 09:51:35 --> Config Class Initialized
INFO - 2021-11-18 09:51:35 --> Loader Class Initialized
INFO - 2021-11-18 09:51:35 --> Helper loaded: url_helper
INFO - 2021-11-18 09:51:35 --> Helper loaded: file_helper
INFO - 2021-11-18 09:51:35 --> Helper loaded: form_helper
INFO - 2021-11-18 09:51:35 --> Helper loaded: my_helper
INFO - 2021-11-18 09:51:35 --> Database Driver Class Initialized
DEBUG - 2021-11-18 09:51:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 09:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 09:51:35 --> Controller Class Initialized
DEBUG - 2021-11-18 09:51:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-18 09:51:35 --> Final output sent to browser
DEBUG - 2021-11-18 09:51:35 --> Total execution time: 0.1699
INFO - 2021-11-18 09:51:47 --> Config Class Initialized
INFO - 2021-11-18 09:51:47 --> Hooks Class Initialized
DEBUG - 2021-11-18 09:51:47 --> UTF-8 Support Enabled
INFO - 2021-11-18 09:51:47 --> Utf8 Class Initialized
INFO - 2021-11-18 09:51:47 --> URI Class Initialized
INFO - 2021-11-18 09:51:47 --> Router Class Initialized
INFO - 2021-11-18 09:51:47 --> Output Class Initialized
INFO - 2021-11-18 09:51:47 --> Security Class Initialized
DEBUG - 2021-11-18 09:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 09:51:47 --> Input Class Initialized
INFO - 2021-11-18 09:51:47 --> Language Class Initialized
INFO - 2021-11-18 09:51:47 --> Language Class Initialized
INFO - 2021-11-18 09:51:47 --> Config Class Initialized
INFO - 2021-11-18 09:51:47 --> Loader Class Initialized
INFO - 2021-11-18 09:51:47 --> Helper loaded: url_helper
INFO - 2021-11-18 09:51:47 --> Helper loaded: file_helper
INFO - 2021-11-18 09:51:47 --> Helper loaded: form_helper
INFO - 2021-11-18 09:51:47 --> Helper loaded: my_helper
INFO - 2021-11-18 09:51:47 --> Database Driver Class Initialized
DEBUG - 2021-11-18 09:51:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 09:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 09:51:47 --> Controller Class Initialized
DEBUG - 2021-11-18 09:51:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-18 09:51:47 --> Final output sent to browser
DEBUG - 2021-11-18 09:51:47 --> Total execution time: 0.1506
INFO - 2021-11-18 09:52:05 --> Config Class Initialized
INFO - 2021-11-18 09:52:05 --> Hooks Class Initialized
DEBUG - 2021-11-18 09:52:05 --> UTF-8 Support Enabled
INFO - 2021-11-18 09:52:05 --> Utf8 Class Initialized
INFO - 2021-11-18 09:52:05 --> URI Class Initialized
INFO - 2021-11-18 09:52:05 --> Router Class Initialized
INFO - 2021-11-18 09:52:05 --> Output Class Initialized
INFO - 2021-11-18 09:52:05 --> Security Class Initialized
DEBUG - 2021-11-18 09:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 09:52:05 --> Input Class Initialized
INFO - 2021-11-18 09:52:05 --> Language Class Initialized
INFO - 2021-11-18 09:52:05 --> Language Class Initialized
INFO - 2021-11-18 09:52:05 --> Config Class Initialized
INFO - 2021-11-18 09:52:05 --> Loader Class Initialized
INFO - 2021-11-18 09:52:05 --> Helper loaded: url_helper
INFO - 2021-11-18 09:52:05 --> Helper loaded: file_helper
INFO - 2021-11-18 09:52:05 --> Helper loaded: form_helper
INFO - 2021-11-18 09:52:05 --> Helper loaded: my_helper
INFO - 2021-11-18 09:52:05 --> Database Driver Class Initialized
DEBUG - 2021-11-18 09:52:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 09:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 09:52:05 --> Controller Class Initialized
DEBUG - 2021-11-18 09:52:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-18 09:52:05 --> Final output sent to browser
DEBUG - 2021-11-18 09:52:05 --> Total execution time: 0.1401
INFO - 2021-11-18 09:58:58 --> Config Class Initialized
INFO - 2021-11-18 09:58:58 --> Hooks Class Initialized
DEBUG - 2021-11-18 09:58:58 --> UTF-8 Support Enabled
INFO - 2021-11-18 09:58:58 --> Utf8 Class Initialized
INFO - 2021-11-18 09:58:58 --> URI Class Initialized
INFO - 2021-11-18 09:58:58 --> Router Class Initialized
INFO - 2021-11-18 09:58:58 --> Output Class Initialized
INFO - 2021-11-18 09:58:58 --> Security Class Initialized
DEBUG - 2021-11-18 09:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 09:58:58 --> Input Class Initialized
INFO - 2021-11-18 09:58:58 --> Language Class Initialized
INFO - 2021-11-18 09:58:58 --> Language Class Initialized
INFO - 2021-11-18 09:58:58 --> Config Class Initialized
INFO - 2021-11-18 09:58:58 --> Loader Class Initialized
INFO - 2021-11-18 09:58:58 --> Helper loaded: url_helper
INFO - 2021-11-18 09:58:58 --> Helper loaded: file_helper
INFO - 2021-11-18 09:58:58 --> Helper loaded: form_helper
INFO - 2021-11-18 09:58:58 --> Helper loaded: my_helper
INFO - 2021-11-18 09:58:58 --> Database Driver Class Initialized
DEBUG - 2021-11-18 09:58:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 09:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 09:58:58 --> Controller Class Initialized
DEBUG - 2021-11-18 09:58:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-18 09:58:58 --> Final output sent to browser
DEBUG - 2021-11-18 09:58:58 --> Total execution time: 0.1349
INFO - 2021-11-18 09:59:18 --> Config Class Initialized
INFO - 2021-11-18 09:59:18 --> Hooks Class Initialized
DEBUG - 2021-11-18 09:59:18 --> UTF-8 Support Enabled
INFO - 2021-11-18 09:59:18 --> Utf8 Class Initialized
INFO - 2021-11-18 09:59:18 --> URI Class Initialized
INFO - 2021-11-18 09:59:18 --> Router Class Initialized
INFO - 2021-11-18 09:59:18 --> Output Class Initialized
INFO - 2021-11-18 09:59:18 --> Security Class Initialized
DEBUG - 2021-11-18 09:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 09:59:18 --> Input Class Initialized
INFO - 2021-11-18 09:59:18 --> Language Class Initialized
INFO - 2021-11-18 09:59:18 --> Language Class Initialized
INFO - 2021-11-18 09:59:18 --> Config Class Initialized
INFO - 2021-11-18 09:59:18 --> Loader Class Initialized
INFO - 2021-11-18 09:59:18 --> Helper loaded: url_helper
INFO - 2021-11-18 09:59:18 --> Helper loaded: file_helper
INFO - 2021-11-18 09:59:18 --> Helper loaded: form_helper
INFO - 2021-11-18 09:59:18 --> Helper loaded: my_helper
INFO - 2021-11-18 09:59:18 --> Database Driver Class Initialized
DEBUG - 2021-11-18 09:59:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 09:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 09:59:18 --> Controller Class Initialized
DEBUG - 2021-11-18 09:59:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-18 09:59:18 --> Final output sent to browser
DEBUG - 2021-11-18 09:59:18 --> Total execution time: 0.1399
INFO - 2021-11-18 10:00:26 --> Config Class Initialized
INFO - 2021-11-18 10:00:26 --> Hooks Class Initialized
DEBUG - 2021-11-18 10:00:26 --> UTF-8 Support Enabled
INFO - 2021-11-18 10:00:26 --> Utf8 Class Initialized
INFO - 2021-11-18 10:00:26 --> URI Class Initialized
INFO - 2021-11-18 10:00:26 --> Router Class Initialized
INFO - 2021-11-18 10:00:26 --> Output Class Initialized
INFO - 2021-11-18 10:00:26 --> Security Class Initialized
DEBUG - 2021-11-18 10:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 10:00:26 --> Input Class Initialized
INFO - 2021-11-18 10:00:26 --> Language Class Initialized
INFO - 2021-11-18 10:00:26 --> Language Class Initialized
INFO - 2021-11-18 10:00:26 --> Config Class Initialized
INFO - 2021-11-18 10:00:26 --> Loader Class Initialized
INFO - 2021-11-18 10:00:26 --> Helper loaded: url_helper
INFO - 2021-11-18 10:00:26 --> Helper loaded: file_helper
INFO - 2021-11-18 10:00:26 --> Helper loaded: form_helper
INFO - 2021-11-18 10:00:26 --> Helper loaded: my_helper
INFO - 2021-11-18 10:00:26 --> Database Driver Class Initialized
DEBUG - 2021-11-18 10:00:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 10:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 10:00:26 --> Controller Class Initialized
DEBUG - 2021-11-18 10:00:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-18 10:00:27 --> Final output sent to browser
DEBUG - 2021-11-18 10:00:27 --> Total execution time: 0.1719
INFO - 2021-11-18 10:00:50 --> Config Class Initialized
INFO - 2021-11-18 10:00:50 --> Hooks Class Initialized
DEBUG - 2021-11-18 10:00:50 --> UTF-8 Support Enabled
INFO - 2021-11-18 10:00:50 --> Utf8 Class Initialized
INFO - 2021-11-18 10:00:50 --> URI Class Initialized
INFO - 2021-11-18 10:00:50 --> Router Class Initialized
INFO - 2021-11-18 10:00:50 --> Output Class Initialized
INFO - 2021-11-18 10:00:50 --> Security Class Initialized
DEBUG - 2021-11-18 10:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 10:00:50 --> Input Class Initialized
INFO - 2021-11-18 10:00:50 --> Language Class Initialized
INFO - 2021-11-18 10:00:50 --> Language Class Initialized
INFO - 2021-11-18 10:00:50 --> Config Class Initialized
INFO - 2021-11-18 10:00:50 --> Loader Class Initialized
INFO - 2021-11-18 10:00:50 --> Helper loaded: url_helper
INFO - 2021-11-18 10:00:50 --> Helper loaded: file_helper
INFO - 2021-11-18 10:00:50 --> Helper loaded: form_helper
INFO - 2021-11-18 10:00:50 --> Helper loaded: my_helper
INFO - 2021-11-18 10:00:50 --> Database Driver Class Initialized
DEBUG - 2021-11-18 10:00:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 10:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 10:00:50 --> Controller Class Initialized
DEBUG - 2021-11-18 10:00:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-18 10:00:50 --> Final output sent to browser
DEBUG - 2021-11-18 10:00:50 --> Total execution time: 0.1346
INFO - 2021-11-18 10:01:06 --> Config Class Initialized
INFO - 2021-11-18 10:01:06 --> Hooks Class Initialized
DEBUG - 2021-11-18 10:01:06 --> UTF-8 Support Enabled
INFO - 2021-11-18 10:01:06 --> Utf8 Class Initialized
INFO - 2021-11-18 10:01:06 --> URI Class Initialized
INFO - 2021-11-18 10:01:06 --> Router Class Initialized
INFO - 2021-11-18 10:01:06 --> Output Class Initialized
INFO - 2021-11-18 10:01:06 --> Security Class Initialized
DEBUG - 2021-11-18 10:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 10:01:06 --> Input Class Initialized
INFO - 2021-11-18 10:01:06 --> Language Class Initialized
INFO - 2021-11-18 10:01:06 --> Language Class Initialized
INFO - 2021-11-18 10:01:06 --> Config Class Initialized
INFO - 2021-11-18 10:01:06 --> Loader Class Initialized
INFO - 2021-11-18 10:01:06 --> Helper loaded: url_helper
INFO - 2021-11-18 10:01:06 --> Helper loaded: file_helper
INFO - 2021-11-18 10:01:06 --> Helper loaded: form_helper
INFO - 2021-11-18 10:01:06 --> Helper loaded: my_helper
INFO - 2021-11-18 10:01:06 --> Database Driver Class Initialized
DEBUG - 2021-11-18 10:01:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 10:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 10:01:06 --> Controller Class Initialized
DEBUG - 2021-11-18 10:01:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-18 10:01:06 --> Final output sent to browser
DEBUG - 2021-11-18 10:01:06 --> Total execution time: 0.1334
INFO - 2021-11-18 10:01:17 --> Config Class Initialized
INFO - 2021-11-18 10:01:17 --> Hooks Class Initialized
DEBUG - 2021-11-18 10:01:17 --> UTF-8 Support Enabled
INFO - 2021-11-18 10:01:17 --> Utf8 Class Initialized
INFO - 2021-11-18 10:01:17 --> URI Class Initialized
INFO - 2021-11-18 10:01:17 --> Router Class Initialized
INFO - 2021-11-18 10:01:17 --> Output Class Initialized
INFO - 2021-11-18 10:01:17 --> Security Class Initialized
DEBUG - 2021-11-18 10:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 10:01:17 --> Input Class Initialized
INFO - 2021-11-18 10:01:17 --> Language Class Initialized
INFO - 2021-11-18 10:01:17 --> Language Class Initialized
INFO - 2021-11-18 10:01:17 --> Config Class Initialized
INFO - 2021-11-18 10:01:17 --> Loader Class Initialized
INFO - 2021-11-18 10:01:17 --> Helper loaded: url_helper
INFO - 2021-11-18 10:01:17 --> Helper loaded: file_helper
INFO - 2021-11-18 10:01:17 --> Helper loaded: form_helper
INFO - 2021-11-18 10:01:17 --> Helper loaded: my_helper
INFO - 2021-11-18 10:01:17 --> Database Driver Class Initialized
DEBUG - 2021-11-18 10:01:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 10:01:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 10:01:17 --> Controller Class Initialized
DEBUG - 2021-11-18 10:01:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-18 10:01:17 --> Final output sent to browser
DEBUG - 2021-11-18 10:01:17 --> Total execution time: 0.1663
INFO - 2021-11-18 10:01:31 --> Config Class Initialized
INFO - 2021-11-18 10:01:31 --> Hooks Class Initialized
DEBUG - 2021-11-18 10:01:31 --> UTF-8 Support Enabled
INFO - 2021-11-18 10:01:31 --> Utf8 Class Initialized
INFO - 2021-11-18 10:01:31 --> URI Class Initialized
INFO - 2021-11-18 10:01:31 --> Router Class Initialized
INFO - 2021-11-18 10:01:31 --> Output Class Initialized
INFO - 2021-11-18 10:01:31 --> Security Class Initialized
DEBUG - 2021-11-18 10:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 10:01:31 --> Input Class Initialized
INFO - 2021-11-18 10:01:31 --> Language Class Initialized
INFO - 2021-11-18 10:01:31 --> Language Class Initialized
INFO - 2021-11-18 10:01:31 --> Config Class Initialized
INFO - 2021-11-18 10:01:31 --> Loader Class Initialized
INFO - 2021-11-18 10:01:31 --> Helper loaded: url_helper
INFO - 2021-11-18 10:01:31 --> Helper loaded: file_helper
INFO - 2021-11-18 10:01:31 --> Helper loaded: form_helper
INFO - 2021-11-18 10:01:31 --> Helper loaded: my_helper
INFO - 2021-11-18 10:01:31 --> Database Driver Class Initialized
DEBUG - 2021-11-18 10:01:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 10:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 10:01:31 --> Controller Class Initialized
DEBUG - 2021-11-18 10:01:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-18 10:01:31 --> Final output sent to browser
DEBUG - 2021-11-18 10:01:31 --> Total execution time: 0.1549
INFO - 2021-11-18 10:02:06 --> Config Class Initialized
INFO - 2021-11-18 10:02:06 --> Hooks Class Initialized
DEBUG - 2021-11-18 10:02:06 --> UTF-8 Support Enabled
INFO - 2021-11-18 10:02:06 --> Utf8 Class Initialized
INFO - 2021-11-18 10:02:06 --> URI Class Initialized
INFO - 2021-11-18 10:02:06 --> Router Class Initialized
INFO - 2021-11-18 10:02:06 --> Output Class Initialized
INFO - 2021-11-18 10:02:06 --> Security Class Initialized
DEBUG - 2021-11-18 10:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 10:02:06 --> Input Class Initialized
INFO - 2021-11-18 10:02:06 --> Language Class Initialized
INFO - 2021-11-18 10:02:06 --> Language Class Initialized
INFO - 2021-11-18 10:02:06 --> Config Class Initialized
INFO - 2021-11-18 10:02:06 --> Loader Class Initialized
INFO - 2021-11-18 10:02:06 --> Helper loaded: url_helper
INFO - 2021-11-18 10:02:06 --> Helper loaded: file_helper
INFO - 2021-11-18 10:02:06 --> Helper loaded: form_helper
INFO - 2021-11-18 10:02:06 --> Helper loaded: my_helper
INFO - 2021-11-18 10:02:06 --> Database Driver Class Initialized
DEBUG - 2021-11-18 10:02:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 10:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 10:02:06 --> Controller Class Initialized
DEBUG - 2021-11-18 10:02:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-18 10:02:06 --> Final output sent to browser
DEBUG - 2021-11-18 10:02:06 --> Total execution time: 0.1310
INFO - 2021-11-18 10:03:08 --> Config Class Initialized
INFO - 2021-11-18 10:03:08 --> Hooks Class Initialized
DEBUG - 2021-11-18 10:03:08 --> UTF-8 Support Enabled
INFO - 2021-11-18 10:03:08 --> Utf8 Class Initialized
INFO - 2021-11-18 10:03:08 --> URI Class Initialized
INFO - 2021-11-18 10:03:08 --> Router Class Initialized
INFO - 2021-11-18 10:03:08 --> Output Class Initialized
INFO - 2021-11-18 10:03:08 --> Security Class Initialized
DEBUG - 2021-11-18 10:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 10:03:08 --> Input Class Initialized
INFO - 2021-11-18 10:03:08 --> Language Class Initialized
INFO - 2021-11-18 10:03:08 --> Language Class Initialized
INFO - 2021-11-18 10:03:08 --> Config Class Initialized
INFO - 2021-11-18 10:03:08 --> Loader Class Initialized
INFO - 2021-11-18 10:03:08 --> Helper loaded: url_helper
INFO - 2021-11-18 10:03:08 --> Helper loaded: file_helper
INFO - 2021-11-18 10:03:08 --> Helper loaded: form_helper
INFO - 2021-11-18 10:03:08 --> Helper loaded: my_helper
INFO - 2021-11-18 10:03:08 --> Database Driver Class Initialized
DEBUG - 2021-11-18 10:03:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 10:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 10:03:08 --> Controller Class Initialized
DEBUG - 2021-11-18 10:03:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-18 10:03:08 --> Final output sent to browser
DEBUG - 2021-11-18 10:03:08 --> Total execution time: 0.1700
INFO - 2021-11-18 10:03:27 --> Config Class Initialized
INFO - 2021-11-18 10:03:27 --> Hooks Class Initialized
DEBUG - 2021-11-18 10:03:27 --> UTF-8 Support Enabled
INFO - 2021-11-18 10:03:27 --> Utf8 Class Initialized
INFO - 2021-11-18 10:03:27 --> URI Class Initialized
INFO - 2021-11-18 10:03:27 --> Router Class Initialized
INFO - 2021-11-18 10:03:27 --> Output Class Initialized
INFO - 2021-11-18 10:03:27 --> Security Class Initialized
DEBUG - 2021-11-18 10:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 10:03:27 --> Input Class Initialized
INFO - 2021-11-18 10:03:27 --> Language Class Initialized
INFO - 2021-11-18 10:03:27 --> Language Class Initialized
INFO - 2021-11-18 10:03:27 --> Config Class Initialized
INFO - 2021-11-18 10:03:27 --> Loader Class Initialized
INFO - 2021-11-18 10:03:27 --> Helper loaded: url_helper
INFO - 2021-11-18 10:03:27 --> Helper loaded: file_helper
INFO - 2021-11-18 10:03:27 --> Helper loaded: form_helper
INFO - 2021-11-18 10:03:27 --> Helper loaded: my_helper
INFO - 2021-11-18 10:03:27 --> Database Driver Class Initialized
DEBUG - 2021-11-18 10:03:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 10:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 10:03:27 --> Controller Class Initialized
DEBUG - 2021-11-18 10:03:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-18 10:03:27 --> Final output sent to browser
DEBUG - 2021-11-18 10:03:27 --> Total execution time: 0.1550
INFO - 2021-11-18 10:03:45 --> Config Class Initialized
INFO - 2021-11-18 10:03:45 --> Hooks Class Initialized
DEBUG - 2021-11-18 10:03:45 --> UTF-8 Support Enabled
INFO - 2021-11-18 10:03:45 --> Utf8 Class Initialized
INFO - 2021-11-18 10:03:45 --> URI Class Initialized
INFO - 2021-11-18 10:03:45 --> Router Class Initialized
INFO - 2021-11-18 10:03:45 --> Output Class Initialized
INFO - 2021-11-18 10:03:45 --> Security Class Initialized
DEBUG - 2021-11-18 10:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 10:03:45 --> Input Class Initialized
INFO - 2021-11-18 10:03:45 --> Language Class Initialized
INFO - 2021-11-18 10:03:45 --> Language Class Initialized
INFO - 2021-11-18 10:03:45 --> Config Class Initialized
INFO - 2021-11-18 10:03:45 --> Loader Class Initialized
INFO - 2021-11-18 10:03:45 --> Helper loaded: url_helper
INFO - 2021-11-18 10:03:45 --> Helper loaded: file_helper
INFO - 2021-11-18 10:03:45 --> Helper loaded: form_helper
INFO - 2021-11-18 10:03:45 --> Helper loaded: my_helper
INFO - 2021-11-18 10:03:45 --> Database Driver Class Initialized
DEBUG - 2021-11-18 10:03:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 10:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 10:03:45 --> Controller Class Initialized
DEBUG - 2021-11-18 10:03:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-18 10:03:45 --> Final output sent to browser
DEBUG - 2021-11-18 10:03:45 --> Total execution time: 0.1411
INFO - 2021-11-18 10:04:09 --> Config Class Initialized
INFO - 2021-11-18 10:04:09 --> Hooks Class Initialized
DEBUG - 2021-11-18 10:04:09 --> UTF-8 Support Enabled
INFO - 2021-11-18 10:04:09 --> Utf8 Class Initialized
INFO - 2021-11-18 10:04:09 --> URI Class Initialized
INFO - 2021-11-18 10:04:09 --> Router Class Initialized
INFO - 2021-11-18 10:04:09 --> Output Class Initialized
INFO - 2021-11-18 10:04:09 --> Security Class Initialized
DEBUG - 2021-11-18 10:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 10:04:09 --> Input Class Initialized
INFO - 2021-11-18 10:04:09 --> Language Class Initialized
INFO - 2021-11-18 10:04:09 --> Language Class Initialized
INFO - 2021-11-18 10:04:09 --> Config Class Initialized
INFO - 2021-11-18 10:04:09 --> Loader Class Initialized
INFO - 2021-11-18 10:04:09 --> Helper loaded: url_helper
INFO - 2021-11-18 10:04:09 --> Helper loaded: file_helper
INFO - 2021-11-18 10:04:09 --> Helper loaded: form_helper
INFO - 2021-11-18 10:04:09 --> Helper loaded: my_helper
INFO - 2021-11-18 10:04:09 --> Database Driver Class Initialized
DEBUG - 2021-11-18 10:04:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 10:04:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 10:04:09 --> Controller Class Initialized
DEBUG - 2021-11-18 10:04:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-18 10:04:09 --> Final output sent to browser
DEBUG - 2021-11-18 10:04:09 --> Total execution time: 0.1671
INFO - 2021-11-18 10:04:26 --> Config Class Initialized
INFO - 2021-11-18 10:04:26 --> Hooks Class Initialized
DEBUG - 2021-11-18 10:04:26 --> UTF-8 Support Enabled
INFO - 2021-11-18 10:04:26 --> Utf8 Class Initialized
INFO - 2021-11-18 10:04:26 --> URI Class Initialized
INFO - 2021-11-18 10:04:26 --> Router Class Initialized
INFO - 2021-11-18 10:04:26 --> Output Class Initialized
INFO - 2021-11-18 10:04:26 --> Security Class Initialized
DEBUG - 2021-11-18 10:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 10:04:26 --> Input Class Initialized
INFO - 2021-11-18 10:04:26 --> Language Class Initialized
INFO - 2021-11-18 10:04:26 --> Language Class Initialized
INFO - 2021-11-18 10:04:26 --> Config Class Initialized
INFO - 2021-11-18 10:04:26 --> Loader Class Initialized
INFO - 2021-11-18 10:04:26 --> Helper loaded: url_helper
INFO - 2021-11-18 10:04:26 --> Helper loaded: file_helper
INFO - 2021-11-18 10:04:26 --> Helper loaded: form_helper
INFO - 2021-11-18 10:04:26 --> Helper loaded: my_helper
INFO - 2021-11-18 10:04:26 --> Database Driver Class Initialized
DEBUG - 2021-11-18 10:04:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 10:04:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 10:04:26 --> Controller Class Initialized
DEBUG - 2021-11-18 10:04:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-18 10:04:26 --> Final output sent to browser
DEBUG - 2021-11-18 10:04:26 --> Total execution time: 0.1497
INFO - 2021-11-18 10:04:36 --> Config Class Initialized
INFO - 2021-11-18 10:04:36 --> Hooks Class Initialized
DEBUG - 2021-11-18 10:04:36 --> UTF-8 Support Enabled
INFO - 2021-11-18 10:04:36 --> Utf8 Class Initialized
INFO - 2021-11-18 10:04:36 --> URI Class Initialized
INFO - 2021-11-18 10:04:36 --> Router Class Initialized
INFO - 2021-11-18 10:04:36 --> Output Class Initialized
INFO - 2021-11-18 10:04:36 --> Security Class Initialized
DEBUG - 2021-11-18 10:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 10:04:36 --> Input Class Initialized
INFO - 2021-11-18 10:04:36 --> Language Class Initialized
INFO - 2021-11-18 10:04:36 --> Language Class Initialized
INFO - 2021-11-18 10:04:36 --> Config Class Initialized
INFO - 2021-11-18 10:04:36 --> Loader Class Initialized
INFO - 2021-11-18 10:04:36 --> Helper loaded: url_helper
INFO - 2021-11-18 10:04:36 --> Helper loaded: file_helper
INFO - 2021-11-18 10:04:36 --> Helper loaded: form_helper
INFO - 2021-11-18 10:04:36 --> Helper loaded: my_helper
INFO - 2021-11-18 10:04:36 --> Database Driver Class Initialized
DEBUG - 2021-11-18 10:04:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 10:04:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 10:04:36 --> Controller Class Initialized
DEBUG - 2021-11-18 10:04:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-18 10:04:36 --> Final output sent to browser
DEBUG - 2021-11-18 10:04:36 --> Total execution time: 0.1505
INFO - 2021-11-18 10:04:58 --> Config Class Initialized
INFO - 2021-11-18 10:04:58 --> Hooks Class Initialized
DEBUG - 2021-11-18 10:04:58 --> UTF-8 Support Enabled
INFO - 2021-11-18 10:04:58 --> Utf8 Class Initialized
INFO - 2021-11-18 10:04:58 --> URI Class Initialized
INFO - 2021-11-18 10:04:58 --> Router Class Initialized
INFO - 2021-11-18 10:04:58 --> Output Class Initialized
INFO - 2021-11-18 10:04:58 --> Security Class Initialized
DEBUG - 2021-11-18 10:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 10:04:58 --> Input Class Initialized
INFO - 2021-11-18 10:04:58 --> Language Class Initialized
INFO - 2021-11-18 10:04:58 --> Language Class Initialized
INFO - 2021-11-18 10:04:58 --> Config Class Initialized
INFO - 2021-11-18 10:04:58 --> Loader Class Initialized
INFO - 2021-11-18 10:04:58 --> Helper loaded: url_helper
INFO - 2021-11-18 10:04:58 --> Helper loaded: file_helper
INFO - 2021-11-18 10:04:58 --> Helper loaded: form_helper
INFO - 2021-11-18 10:04:58 --> Helper loaded: my_helper
INFO - 2021-11-18 10:04:58 --> Database Driver Class Initialized
DEBUG - 2021-11-18 10:04:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 10:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 10:04:58 --> Controller Class Initialized
DEBUG - 2021-11-18 10:04:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-18 10:04:58 --> Final output sent to browser
DEBUG - 2021-11-18 10:04:58 --> Total execution time: 0.1623
INFO - 2021-11-18 10:05:12 --> Config Class Initialized
INFO - 2021-11-18 10:05:12 --> Hooks Class Initialized
DEBUG - 2021-11-18 10:05:12 --> UTF-8 Support Enabled
INFO - 2021-11-18 10:05:12 --> Utf8 Class Initialized
INFO - 2021-11-18 10:05:12 --> URI Class Initialized
INFO - 2021-11-18 10:05:12 --> Router Class Initialized
INFO - 2021-11-18 10:05:12 --> Output Class Initialized
INFO - 2021-11-18 10:05:12 --> Security Class Initialized
DEBUG - 2021-11-18 10:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-18 10:05:12 --> Input Class Initialized
INFO - 2021-11-18 10:05:12 --> Language Class Initialized
INFO - 2021-11-18 10:05:12 --> Language Class Initialized
INFO - 2021-11-18 10:05:12 --> Config Class Initialized
INFO - 2021-11-18 10:05:12 --> Loader Class Initialized
INFO - 2021-11-18 10:05:12 --> Helper loaded: url_helper
INFO - 2021-11-18 10:05:12 --> Helper loaded: file_helper
INFO - 2021-11-18 10:05:12 --> Helper loaded: form_helper
INFO - 2021-11-18 10:05:12 --> Helper loaded: my_helper
INFO - 2021-11-18 10:05:12 --> Database Driver Class Initialized
DEBUG - 2021-11-18 10:05:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-18 10:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-18 10:05:12 --> Controller Class Initialized
DEBUG - 2021-11-18 10:05:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-18 10:05:12 --> Final output sent to browser
DEBUG - 2021-11-18 10:05:12 --> Total execution time: 0.1454
