<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-10-21 08:10:02 --> Config Class Initialized
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-10-21 08:10:02 --> Config Class Initialized
INFO - 2022-10-21 08:10:02 --> Hooks Class Initialized
INFO - 2022-10-21 08:10:02 --> Hooks Class Initialized
DEBUG - 2022-10-21 08:10:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:10:02 --> UTF-8 Support Enabled
INFO - 2022-10-21 08:10:02 --> Utf8 Class Initialized
INFO - 2022-10-21 08:10:02 --> Utf8 Class Initialized
INFO - 2022-10-21 08:10:02 --> URI Class Initialized
INFO - 2022-10-21 08:10:02 --> URI Class Initialized
INFO - 2022-10-21 08:10:02 --> Router Class Initialized
INFO - 2022-10-21 08:10:02 --> Router Class Initialized
INFO - 2022-10-21 08:10:02 --> Output Class Initialized
INFO - 2022-10-21 08:10:02 --> Output Class Initialized
INFO - 2022-10-21 08:10:02 --> Security Class Initialized
INFO - 2022-10-21 08:10:02 --> Security Class Initialized
DEBUG - 2022-10-21 08:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-21 08:10:02 --> Input Class Initialized
INFO - 2022-10-21 08:10:02 --> Input Class Initialized
INFO - 2022-10-21 08:10:02 --> Language Class Initialized
INFO - 2022-10-21 08:10:02 --> Language Class Initialized
INFO - 2022-10-21 08:10:03 --> Language Class Initialized
INFO - 2022-10-21 08:10:03 --> Language Class Initialized
INFO - 2022-10-21 08:10:03 --> Config Class Initialized
INFO - 2022-10-21 08:10:03 --> Config Class Initialized
INFO - 2022-10-21 08:10:03 --> Loader Class Initialized
INFO - 2022-10-21 08:10:03 --> Loader Class Initialized
INFO - 2022-10-21 08:10:03 --> Helper loaded: url_helper
INFO - 2022-10-21 08:10:03 --> Helper loaded: url_helper
INFO - 2022-10-21 08:10:03 --> Helper loaded: file_helper
INFO - 2022-10-21 08:10:03 --> Helper loaded: file_helper
INFO - 2022-10-21 08:10:03 --> Helper loaded: form_helper
INFO - 2022-10-21 08:10:03 --> Helper loaded: form_helper
INFO - 2022-10-21 08:10:03 --> Helper loaded: my_helper
INFO - 2022-10-21 08:10:03 --> Helper loaded: my_helper
INFO - 2022-10-21 08:10:03 --> Database Driver Class Initialized
INFO - 2022-10-21 08:10:03 --> Database Driver Class Initialized
DEBUG - 2022-10-21 08:10:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-21 08:10:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-10-21 08:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-10-21 08:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-10-21 08:10:03 --> Controller Class Initialized
INFO - 2022-10-21 08:10:03 --> Controller Class Initialized
DEBUG - 2022-10-21 08:10:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-10-21 08:10:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-10-21 08:10:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
DEBUG - 2022-10-21 08:10:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-10-21 08:10:03 --> Final output sent to browser
DEBUG - 2022-10-21 08:10:03 --> Total execution time: 0.6807
INFO - 2022-10-21 08:10:03 --> Final output sent to browser
DEBUG - 2022-10-21 08:10:03 --> Total execution time: 0.6807
INFO - 2022-10-21 08:10:16 --> Config Class Initialized
INFO - 2022-10-21 08:10:16 --> Hooks Class Initialized
DEBUG - 2022-10-21 08:10:16 --> UTF-8 Support Enabled
INFO - 2022-10-21 08:10:16 --> Utf8 Class Initialized
INFO - 2022-10-21 08:10:16 --> URI Class Initialized
INFO - 2022-10-21 08:10:16 --> Router Class Initialized
INFO - 2022-10-21 08:10:16 --> Output Class Initialized
INFO - 2022-10-21 08:10:16 --> Security Class Initialized
DEBUG - 2022-10-21 08:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-21 08:10:16 --> Input Class Initialized
INFO - 2022-10-21 08:10:16 --> Language Class Initialized
INFO - 2022-10-21 08:10:16 --> Language Class Initialized
INFO - 2022-10-21 08:10:16 --> Config Class Initialized
INFO - 2022-10-21 08:10:16 --> Loader Class Initialized
INFO - 2022-10-21 08:10:16 --> Helper loaded: url_helper
INFO - 2022-10-21 08:10:16 --> Helper loaded: file_helper
INFO - 2022-10-21 08:10:16 --> Helper loaded: form_helper
INFO - 2022-10-21 08:10:16 --> Helper loaded: my_helper
INFO - 2022-10-21 08:10:16 --> Database Driver Class Initialized
DEBUG - 2022-10-21 08:10:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-10-21 08:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-10-21 08:10:16 --> Controller Class Initialized
INFO - 2022-10-21 08:10:16 --> Helper loaded: cookie_helper
INFO - 2022-10-21 08:10:16 --> Final output sent to browser
DEBUG - 2022-10-21 08:10:16 --> Total execution time: 0.0898
INFO - 2022-10-21 08:10:17 --> Config Class Initialized
INFO - 2022-10-21 08:10:17 --> Hooks Class Initialized
DEBUG - 2022-10-21 08:10:17 --> UTF-8 Support Enabled
INFO - 2022-10-21 08:10:17 --> Utf8 Class Initialized
INFO - 2022-10-21 08:10:17 --> URI Class Initialized
INFO - 2022-10-21 08:10:17 --> Router Class Initialized
INFO - 2022-10-21 08:10:17 --> Output Class Initialized
INFO - 2022-10-21 08:10:17 --> Security Class Initialized
DEBUG - 2022-10-21 08:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-21 08:10:17 --> Input Class Initialized
INFO - 2022-10-21 08:10:17 --> Language Class Initialized
INFO - 2022-10-21 08:10:17 --> Language Class Initialized
INFO - 2022-10-21 08:10:17 --> Config Class Initialized
INFO - 2022-10-21 08:10:17 --> Loader Class Initialized
INFO - 2022-10-21 08:10:17 --> Helper loaded: url_helper
INFO - 2022-10-21 08:10:17 --> Helper loaded: file_helper
INFO - 2022-10-21 08:10:17 --> Helper loaded: form_helper
INFO - 2022-10-21 08:10:17 --> Helper loaded: my_helper
INFO - 2022-10-21 08:10:17 --> Database Driver Class Initialized
DEBUG - 2022-10-21 08:10:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-10-21 08:10:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-10-21 08:10:17 --> Controller Class Initialized
DEBUG - 2022-10-21 08:10:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-10-21 08:10:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-10-21 08:10:17 --> Final output sent to browser
DEBUG - 2022-10-21 08:10:17 --> Total execution time: 0.5920
INFO - 2022-10-21 08:10:20 --> Config Class Initialized
INFO - 2022-10-21 08:10:20 --> Hooks Class Initialized
DEBUG - 2022-10-21 08:10:20 --> UTF-8 Support Enabled
INFO - 2022-10-21 08:10:20 --> Utf8 Class Initialized
INFO - 2022-10-21 08:10:20 --> URI Class Initialized
INFO - 2022-10-21 08:10:20 --> Router Class Initialized
INFO - 2022-10-21 08:10:20 --> Output Class Initialized
INFO - 2022-10-21 08:10:20 --> Security Class Initialized
DEBUG - 2022-10-21 08:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-21 08:10:20 --> Input Class Initialized
INFO - 2022-10-21 08:10:20 --> Language Class Initialized
INFO - 2022-10-21 08:10:20 --> Language Class Initialized
INFO - 2022-10-21 08:10:20 --> Config Class Initialized
INFO - 2022-10-21 08:10:20 --> Loader Class Initialized
INFO - 2022-10-21 08:10:20 --> Helper loaded: url_helper
INFO - 2022-10-21 08:10:20 --> Helper loaded: file_helper
INFO - 2022-10-21 08:10:20 --> Helper loaded: form_helper
INFO - 2022-10-21 08:10:20 --> Helper loaded: my_helper
INFO - 2022-10-21 08:10:20 --> Database Driver Class Initialized
DEBUG - 2022-10-21 08:10:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-10-21 08:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-10-21 08:10:20 --> Controller Class Initialized
DEBUG - 2022-10-21 08:10:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-10-21 08:10:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-10-21 08:10:20 --> Final output sent to browser
DEBUG - 2022-10-21 08:10:20 --> Total execution time: 0.1390
INFO - 2022-10-21 08:11:44 --> Config Class Initialized
INFO - 2022-10-21 08:11:44 --> Hooks Class Initialized
DEBUG - 2022-10-21 08:11:44 --> UTF-8 Support Enabled
INFO - 2022-10-21 08:11:44 --> Utf8 Class Initialized
INFO - 2022-10-21 08:11:44 --> URI Class Initialized
DEBUG - 2022-10-21 08:11:44 --> No URI present. Default controller set.
INFO - 2022-10-21 08:11:44 --> Router Class Initialized
INFO - 2022-10-21 08:11:44 --> Output Class Initialized
INFO - 2022-10-21 08:11:44 --> Security Class Initialized
DEBUG - 2022-10-21 08:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-21 08:11:44 --> Input Class Initialized
INFO - 2022-10-21 08:11:44 --> Language Class Initialized
INFO - 2022-10-21 08:11:44 --> Language Class Initialized
INFO - 2022-10-21 08:11:44 --> Config Class Initialized
INFO - 2022-10-21 08:11:44 --> Loader Class Initialized
INFO - 2022-10-21 08:11:44 --> Helper loaded: url_helper
INFO - 2022-10-21 08:11:44 --> Helper loaded: file_helper
INFO - 2022-10-21 08:11:44 --> Helper loaded: form_helper
INFO - 2022-10-21 08:11:44 --> Helper loaded: my_helper
INFO - 2022-10-21 08:11:44 --> Database Driver Class Initialized
DEBUG - 2022-10-21 08:11:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-10-21 08:11:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-10-21 08:11:44 --> Controller Class Initialized
DEBUG - 2022-10-21 08:11:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-10-21 08:11:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-10-21 08:11:45 --> Final output sent to browser
DEBUG - 2022-10-21 08:11:45 --> Total execution time: 0.4882
INFO - 2022-10-21 08:11:46 --> Config Class Initialized
INFO - 2022-10-21 08:11:46 --> Hooks Class Initialized
DEBUG - 2022-10-21 08:11:46 --> UTF-8 Support Enabled
INFO - 2022-10-21 08:11:46 --> Utf8 Class Initialized
INFO - 2022-10-21 08:11:46 --> URI Class Initialized
INFO - 2022-10-21 08:11:46 --> Router Class Initialized
INFO - 2022-10-21 08:11:46 --> Output Class Initialized
INFO - 2022-10-21 08:11:46 --> Security Class Initialized
DEBUG - 2022-10-21 08:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-21 08:11:46 --> Input Class Initialized
INFO - 2022-10-21 08:11:46 --> Language Class Initialized
INFO - 2022-10-21 08:11:46 --> Language Class Initialized
INFO - 2022-10-21 08:11:46 --> Config Class Initialized
INFO - 2022-10-21 08:11:46 --> Loader Class Initialized
INFO - 2022-10-21 08:11:46 --> Helper loaded: url_helper
INFO - 2022-10-21 08:11:46 --> Helper loaded: file_helper
INFO - 2022-10-21 08:11:46 --> Helper loaded: form_helper
INFO - 2022-10-21 08:11:46 --> Helper loaded: my_helper
INFO - 2022-10-21 08:11:46 --> Database Driver Class Initialized
DEBUG - 2022-10-21 08:11:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-10-21 08:11:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-10-21 08:11:46 --> Controller Class Initialized
INFO - 2022-10-21 08:11:46 --> Helper loaded: cookie_helper
INFO - 2022-10-21 08:11:46 --> Config Class Initialized
INFO - 2022-10-21 08:11:46 --> Hooks Class Initialized
DEBUG - 2022-10-21 08:11:46 --> UTF-8 Support Enabled
INFO - 2022-10-21 08:11:46 --> Utf8 Class Initialized
INFO - 2022-10-21 08:11:46 --> URI Class Initialized
INFO - 2022-10-21 08:11:46 --> Router Class Initialized
INFO - 2022-10-21 08:11:46 --> Output Class Initialized
INFO - 2022-10-21 08:11:46 --> Security Class Initialized
DEBUG - 2022-10-21 08:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-21 08:11:46 --> Input Class Initialized
INFO - 2022-10-21 08:11:46 --> Language Class Initialized
INFO - 2022-10-21 08:11:46 --> Language Class Initialized
INFO - 2022-10-21 08:11:46 --> Config Class Initialized
INFO - 2022-10-21 08:11:46 --> Loader Class Initialized
INFO - 2022-10-21 08:11:46 --> Helper loaded: url_helper
INFO - 2022-10-21 08:11:46 --> Helper loaded: file_helper
INFO - 2022-10-21 08:11:46 --> Helper loaded: form_helper
INFO - 2022-10-21 08:11:46 --> Helper loaded: my_helper
INFO - 2022-10-21 08:11:46 --> Database Driver Class Initialized
DEBUG - 2022-10-21 08:11:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-10-21 08:11:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-10-21 08:11:46 --> Controller Class Initialized
DEBUG - 2022-10-21 08:11:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-10-21 08:11:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-10-21 08:11:46 --> Final output sent to browser
DEBUG - 2022-10-21 08:11:46 --> Total execution time: 0.0545
INFO - 2022-10-21 08:11:51 --> Config Class Initialized
INFO - 2022-10-21 08:11:51 --> Hooks Class Initialized
DEBUG - 2022-10-21 08:11:51 --> UTF-8 Support Enabled
INFO - 2022-10-21 08:11:51 --> Utf8 Class Initialized
INFO - 2022-10-21 08:11:51 --> URI Class Initialized
INFO - 2022-10-21 08:11:51 --> Router Class Initialized
INFO - 2022-10-21 08:11:51 --> Output Class Initialized
INFO - 2022-10-21 08:11:51 --> Security Class Initialized
DEBUG - 2022-10-21 08:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-21 08:11:51 --> Input Class Initialized
INFO - 2022-10-21 08:11:51 --> Language Class Initialized
INFO - 2022-10-21 08:11:51 --> Language Class Initialized
INFO - 2022-10-21 08:11:51 --> Config Class Initialized
INFO - 2022-10-21 08:11:51 --> Loader Class Initialized
INFO - 2022-10-21 08:11:51 --> Helper loaded: url_helper
INFO - 2022-10-21 08:11:51 --> Helper loaded: file_helper
INFO - 2022-10-21 08:11:51 --> Helper loaded: form_helper
INFO - 2022-10-21 08:11:51 --> Helper loaded: my_helper
INFO - 2022-10-21 08:11:51 --> Database Driver Class Initialized
DEBUG - 2022-10-21 08:11:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-10-21 08:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-10-21 08:11:51 --> Controller Class Initialized
INFO - 2022-10-21 08:11:51 --> Helper loaded: cookie_helper
INFO - 2022-10-21 08:11:51 --> Final output sent to browser
DEBUG - 2022-10-21 08:11:51 --> Total execution time: 0.0602
INFO - 2022-10-21 08:11:51 --> Config Class Initialized
INFO - 2022-10-21 08:11:51 --> Hooks Class Initialized
DEBUG - 2022-10-21 08:11:51 --> UTF-8 Support Enabled
INFO - 2022-10-21 08:11:51 --> Utf8 Class Initialized
INFO - 2022-10-21 08:11:51 --> URI Class Initialized
INFO - 2022-10-21 08:11:51 --> Router Class Initialized
INFO - 2022-10-21 08:11:51 --> Output Class Initialized
INFO - 2022-10-21 08:11:51 --> Security Class Initialized
DEBUG - 2022-10-21 08:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-21 08:11:51 --> Input Class Initialized
INFO - 2022-10-21 08:11:51 --> Language Class Initialized
INFO - 2022-10-21 08:11:51 --> Language Class Initialized
INFO - 2022-10-21 08:11:51 --> Config Class Initialized
INFO - 2022-10-21 08:11:51 --> Loader Class Initialized
INFO - 2022-10-21 08:11:51 --> Helper loaded: url_helper
INFO - 2022-10-21 08:11:51 --> Helper loaded: file_helper
INFO - 2022-10-21 08:11:51 --> Helper loaded: form_helper
INFO - 2022-10-21 08:11:51 --> Helper loaded: my_helper
INFO - 2022-10-21 08:11:51 --> Database Driver Class Initialized
DEBUG - 2022-10-21 08:11:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-10-21 08:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-10-21 08:11:51 --> Controller Class Initialized
DEBUG - 2022-10-21 08:11:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-10-21 08:11:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-10-21 08:11:52 --> Final output sent to browser
DEBUG - 2022-10-21 08:11:52 --> Total execution time: 0.4900
INFO - 2022-10-21 08:11:58 --> Config Class Initialized
INFO - 2022-10-21 08:11:58 --> Hooks Class Initialized
DEBUG - 2022-10-21 08:11:58 --> UTF-8 Support Enabled
INFO - 2022-10-21 08:11:58 --> Utf8 Class Initialized
INFO - 2022-10-21 08:11:58 --> URI Class Initialized
INFO - 2022-10-21 08:11:58 --> Router Class Initialized
INFO - 2022-10-21 08:11:58 --> Output Class Initialized
INFO - 2022-10-21 08:11:58 --> Security Class Initialized
DEBUG - 2022-10-21 08:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-21 08:11:58 --> Input Class Initialized
INFO - 2022-10-21 08:11:58 --> Language Class Initialized
INFO - 2022-10-21 08:11:58 --> Language Class Initialized
INFO - 2022-10-21 08:11:58 --> Config Class Initialized
INFO - 2022-10-21 08:11:58 --> Loader Class Initialized
INFO - 2022-10-21 08:11:58 --> Helper loaded: url_helper
INFO - 2022-10-21 08:11:58 --> Helper loaded: file_helper
INFO - 2022-10-21 08:11:58 --> Helper loaded: form_helper
INFO - 2022-10-21 08:11:58 --> Helper loaded: my_helper
INFO - 2022-10-21 08:11:58 --> Database Driver Class Initialized
DEBUG - 2022-10-21 08:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-10-21 08:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-10-21 08:11:58 --> Controller Class Initialized
DEBUG - 2022-10-21 08:11:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2022-10-21 08:11:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-10-21 08:11:58 --> Final output sent to browser
DEBUG - 2022-10-21 08:11:58 --> Total execution time: 0.1160
INFO - 2022-10-21 08:12:03 --> Config Class Initialized
INFO - 2022-10-21 08:12:03 --> Hooks Class Initialized
DEBUG - 2022-10-21 08:12:03 --> UTF-8 Support Enabled
INFO - 2022-10-21 08:12:03 --> Utf8 Class Initialized
INFO - 2022-10-21 08:12:03 --> URI Class Initialized
INFO - 2022-10-21 08:12:03 --> Router Class Initialized
INFO - 2022-10-21 08:12:03 --> Output Class Initialized
INFO - 2022-10-21 08:12:03 --> Security Class Initialized
DEBUG - 2022-10-21 08:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-21 08:12:03 --> Input Class Initialized
INFO - 2022-10-21 08:12:03 --> Language Class Initialized
INFO - 2022-10-21 08:12:03 --> Language Class Initialized
INFO - 2022-10-21 08:12:03 --> Config Class Initialized
INFO - 2022-10-21 08:12:03 --> Loader Class Initialized
INFO - 2022-10-21 08:12:03 --> Helper loaded: url_helper
INFO - 2022-10-21 08:12:03 --> Helper loaded: file_helper
INFO - 2022-10-21 08:12:03 --> Helper loaded: form_helper
INFO - 2022-10-21 08:12:03 --> Helper loaded: my_helper
INFO - 2022-10-21 08:12:03 --> Database Driver Class Initialized
DEBUG - 2022-10-21 08:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-10-21 08:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-10-21 08:12:03 --> Controller Class Initialized
DEBUG - 2022-10-21 08:12:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-10-21 08:12:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-10-21 08:12:03 --> Final output sent to browser
DEBUG - 2022-10-21 08:12:03 --> Total execution time: 0.0511
INFO - 2022-10-21 08:12:10 --> Config Class Initialized
INFO - 2022-10-21 08:12:10 --> Hooks Class Initialized
DEBUG - 2022-10-21 08:12:10 --> UTF-8 Support Enabled
INFO - 2022-10-21 08:12:10 --> Utf8 Class Initialized
INFO - 2022-10-21 08:12:10 --> URI Class Initialized
INFO - 2022-10-21 08:12:10 --> Router Class Initialized
INFO - 2022-10-21 08:12:10 --> Output Class Initialized
INFO - 2022-10-21 08:12:10 --> Security Class Initialized
DEBUG - 2022-10-21 08:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-21 08:12:10 --> Input Class Initialized
INFO - 2022-10-21 08:12:10 --> Language Class Initialized
INFO - 2022-10-21 08:12:10 --> Language Class Initialized
INFO - 2022-10-21 08:12:10 --> Config Class Initialized
INFO - 2022-10-21 08:12:10 --> Loader Class Initialized
INFO - 2022-10-21 08:12:10 --> Helper loaded: url_helper
INFO - 2022-10-21 08:12:10 --> Helper loaded: file_helper
INFO - 2022-10-21 08:12:10 --> Helper loaded: form_helper
INFO - 2022-10-21 08:12:10 --> Helper loaded: my_helper
INFO - 2022-10-21 08:12:10 --> Database Driver Class Initialized
DEBUG - 2022-10-21 08:12:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-10-21 08:12:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-10-21 08:12:10 --> Controller Class Initialized
DEBUG - 2022-10-21 08:12:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-10-21 08:12:11 --> Final output sent to browser
DEBUG - 2022-10-21 08:12:11 --> Total execution time: 0.2987
INFO - 2022-10-21 08:12:24 --> Config Class Initialized
INFO - 2022-10-21 08:12:24 --> Hooks Class Initialized
DEBUG - 2022-10-21 08:12:24 --> UTF-8 Support Enabled
INFO - 2022-10-21 08:12:24 --> Utf8 Class Initialized
INFO - 2022-10-21 08:12:24 --> URI Class Initialized
INFO - 2022-10-21 08:12:24 --> Router Class Initialized
INFO - 2022-10-21 08:12:24 --> Output Class Initialized
INFO - 2022-10-21 08:12:24 --> Security Class Initialized
DEBUG - 2022-10-21 08:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-21 08:12:24 --> Input Class Initialized
INFO - 2022-10-21 08:12:24 --> Language Class Initialized
INFO - 2022-10-21 08:12:24 --> Language Class Initialized
INFO - 2022-10-21 08:12:24 --> Config Class Initialized
INFO - 2022-10-21 08:12:24 --> Loader Class Initialized
INFO - 2022-10-21 08:12:24 --> Helper loaded: url_helper
INFO - 2022-10-21 08:12:24 --> Helper loaded: file_helper
INFO - 2022-10-21 08:12:24 --> Helper loaded: form_helper
INFO - 2022-10-21 08:12:24 --> Helper loaded: my_helper
INFO - 2022-10-21 08:12:24 --> Database Driver Class Initialized
DEBUG - 2022-10-21 08:12:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-10-21 08:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-10-21 08:12:24 --> Controller Class Initialized
DEBUG - 2022-10-21 08:12:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2022-10-21 08:12:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-10-21 08:12:24 --> Final output sent to browser
DEBUG - 2022-10-21 08:12:24 --> Total execution time: 0.2269
INFO - 2022-10-21 08:12:38 --> Config Class Initialized
INFO - 2022-10-21 08:12:38 --> Hooks Class Initialized
DEBUG - 2022-10-21 08:12:38 --> UTF-8 Support Enabled
INFO - 2022-10-21 08:12:38 --> Utf8 Class Initialized
INFO - 2022-10-21 08:12:38 --> URI Class Initialized
INFO - 2022-10-21 08:12:38 --> Router Class Initialized
INFO - 2022-10-21 08:12:38 --> Output Class Initialized
INFO - 2022-10-21 08:12:38 --> Security Class Initialized
DEBUG - 2022-10-21 08:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-21 08:12:38 --> Input Class Initialized
INFO - 2022-10-21 08:12:38 --> Language Class Initialized
INFO - 2022-10-21 08:12:38 --> Language Class Initialized
INFO - 2022-10-21 08:12:38 --> Config Class Initialized
INFO - 2022-10-21 08:12:38 --> Loader Class Initialized
INFO - 2022-10-21 08:12:38 --> Helper loaded: url_helper
INFO - 2022-10-21 08:12:38 --> Helper loaded: file_helper
INFO - 2022-10-21 08:12:38 --> Helper loaded: form_helper
INFO - 2022-10-21 08:12:38 --> Helper loaded: my_helper
INFO - 2022-10-21 08:12:38 --> Database Driver Class Initialized
DEBUG - 2022-10-21 08:12:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-10-21 08:12:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-10-21 08:12:38 --> Controller Class Initialized
INFO - 2022-10-21 08:12:39 --> Final output sent to browser
DEBUG - 2022-10-21 08:12:39 --> Total execution time: 0.2529
INFO - 2022-10-21 08:12:40 --> Config Class Initialized
INFO - 2022-10-21 08:12:40 --> Hooks Class Initialized
DEBUG - 2022-10-21 08:12:40 --> UTF-8 Support Enabled
INFO - 2022-10-21 08:12:40 --> Utf8 Class Initialized
INFO - 2022-10-21 08:12:40 --> URI Class Initialized
DEBUG - 2022-10-21 08:12:40 --> No URI present. Default controller set.
INFO - 2022-10-21 08:12:40 --> Router Class Initialized
INFO - 2022-10-21 08:12:40 --> Output Class Initialized
INFO - 2022-10-21 08:12:40 --> Security Class Initialized
DEBUG - 2022-10-21 08:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-21 08:12:40 --> Input Class Initialized
INFO - 2022-10-21 08:12:40 --> Language Class Initialized
INFO - 2022-10-21 08:12:40 --> Language Class Initialized
INFO - 2022-10-21 08:12:40 --> Config Class Initialized
INFO - 2022-10-21 08:12:40 --> Loader Class Initialized
INFO - 2022-10-21 08:12:40 --> Helper loaded: url_helper
INFO - 2022-10-21 08:12:40 --> Helper loaded: file_helper
INFO - 2022-10-21 08:12:40 --> Helper loaded: form_helper
INFO - 2022-10-21 08:12:40 --> Helper loaded: my_helper
INFO - 2022-10-21 08:12:40 --> Database Driver Class Initialized
DEBUG - 2022-10-21 08:12:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-10-21 08:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-10-21 08:12:40 --> Controller Class Initialized
DEBUG - 2022-10-21 08:12:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-10-21 08:12:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-10-21 08:12:41 --> Final output sent to browser
DEBUG - 2022-10-21 08:12:41 --> Total execution time: 0.5283
INFO - 2022-10-21 08:12:42 --> Config Class Initialized
INFO - 2022-10-21 08:12:42 --> Hooks Class Initialized
DEBUG - 2022-10-21 08:12:42 --> UTF-8 Support Enabled
INFO - 2022-10-21 08:12:42 --> Utf8 Class Initialized
INFO - 2022-10-21 08:12:42 --> URI Class Initialized
INFO - 2022-10-21 08:12:42 --> Router Class Initialized
INFO - 2022-10-21 08:12:42 --> Output Class Initialized
INFO - 2022-10-21 08:12:42 --> Security Class Initialized
DEBUG - 2022-10-21 08:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-21 08:12:42 --> Input Class Initialized
INFO - 2022-10-21 08:12:42 --> Language Class Initialized
INFO - 2022-10-21 08:12:42 --> Language Class Initialized
INFO - 2022-10-21 08:12:42 --> Config Class Initialized
INFO - 2022-10-21 08:12:42 --> Loader Class Initialized
INFO - 2022-10-21 08:12:42 --> Helper loaded: url_helper
INFO - 2022-10-21 08:12:42 --> Helper loaded: file_helper
INFO - 2022-10-21 08:12:42 --> Helper loaded: form_helper
INFO - 2022-10-21 08:12:42 --> Helper loaded: my_helper
INFO - 2022-10-21 08:12:42 --> Database Driver Class Initialized
DEBUG - 2022-10-21 08:12:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-10-21 08:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-10-21 08:12:42 --> Controller Class Initialized
DEBUG - 2022-10-21 08:12:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-10-21 08:12:42 --> Final output sent to browser
DEBUG - 2022-10-21 08:12:42 --> Total execution time: 0.2447
