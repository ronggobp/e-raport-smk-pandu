<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-01-18 01:51:03 --> Config Class Initialized
INFO - 2022-01-18 01:51:03 --> Hooks Class Initialized
DEBUG - 2022-01-18 01:51:03 --> UTF-8 Support Enabled
INFO - 2022-01-18 01:51:03 --> Utf8 Class Initialized
INFO - 2022-01-18 01:51:03 --> URI Class Initialized
DEBUG - 2022-01-18 01:51:03 --> No URI present. Default controller set.
INFO - 2022-01-18 01:51:03 --> Router Class Initialized
INFO - 2022-01-18 01:51:03 --> Output Class Initialized
INFO - 2022-01-18 01:51:03 --> Security Class Initialized
DEBUG - 2022-01-18 01:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 01:51:03 --> Input Class Initialized
INFO - 2022-01-18 01:51:03 --> Language Class Initialized
INFO - 2022-01-18 01:51:03 --> Language Class Initialized
INFO - 2022-01-18 01:51:03 --> Config Class Initialized
INFO - 2022-01-18 01:51:03 --> Loader Class Initialized
INFO - 2022-01-18 01:51:03 --> Helper loaded: url_helper
INFO - 2022-01-18 01:51:03 --> Helper loaded: file_helper
INFO - 2022-01-18 01:51:03 --> Helper loaded: form_helper
INFO - 2022-01-18 01:51:03 --> Helper loaded: my_helper
INFO - 2022-01-18 01:51:03 --> Database Driver Class Initialized
DEBUG - 2022-01-18 01:51:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 01:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 01:51:04 --> Controller Class Initialized
INFO - 2022-01-18 01:51:04 --> Config Class Initialized
INFO - 2022-01-18 01:51:04 --> Hooks Class Initialized
DEBUG - 2022-01-18 01:51:04 --> UTF-8 Support Enabled
INFO - 2022-01-18 01:51:04 --> Utf8 Class Initialized
INFO - 2022-01-18 01:51:04 --> URI Class Initialized
INFO - 2022-01-18 01:51:04 --> Router Class Initialized
INFO - 2022-01-18 01:51:04 --> Output Class Initialized
INFO - 2022-01-18 01:51:04 --> Security Class Initialized
DEBUG - 2022-01-18 01:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 01:51:04 --> Input Class Initialized
INFO - 2022-01-18 01:51:04 --> Language Class Initialized
INFO - 2022-01-18 01:51:04 --> Language Class Initialized
INFO - 2022-01-18 01:51:04 --> Config Class Initialized
INFO - 2022-01-18 01:51:04 --> Loader Class Initialized
INFO - 2022-01-18 01:51:04 --> Helper loaded: url_helper
INFO - 2022-01-18 01:51:04 --> Helper loaded: file_helper
INFO - 2022-01-18 01:51:04 --> Helper loaded: form_helper
INFO - 2022-01-18 01:51:04 --> Helper loaded: my_helper
INFO - 2022-01-18 01:51:04 --> Database Driver Class Initialized
DEBUG - 2022-01-18 01:51:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 01:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 01:51:04 --> Controller Class Initialized
DEBUG - 2022-01-18 01:51:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-01-18 01:51:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 01:51:04 --> Final output sent to browser
DEBUG - 2022-01-18 01:51:04 --> Total execution time: 0.0410
INFO - 2022-01-18 06:01:27 --> Config Class Initialized
INFO - 2022-01-18 06:01:27 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:01:27 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:01:27 --> Utf8 Class Initialized
INFO - 2022-01-18 06:01:27 --> URI Class Initialized
INFO - 2022-01-18 06:01:27 --> Router Class Initialized
INFO - 2022-01-18 06:01:27 --> Output Class Initialized
INFO - 2022-01-18 06:01:27 --> Security Class Initialized
DEBUG - 2022-01-18 06:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:01:27 --> Input Class Initialized
INFO - 2022-01-18 06:01:27 --> Language Class Initialized
INFO - 2022-01-18 06:01:27 --> Language Class Initialized
INFO - 2022-01-18 06:01:27 --> Config Class Initialized
INFO - 2022-01-18 06:01:27 --> Loader Class Initialized
INFO - 2022-01-18 06:01:27 --> Helper loaded: url_helper
INFO - 2022-01-18 06:01:27 --> Helper loaded: file_helper
INFO - 2022-01-18 06:01:27 --> Helper loaded: form_helper
INFO - 2022-01-18 06:01:27 --> Helper loaded: my_helper
INFO - 2022-01-18 06:01:27 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:01:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:01:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:01:27 --> Controller Class Initialized
INFO - 2022-01-18 06:01:27 --> Helper loaded: cookie_helper
INFO - 2022-01-18 06:01:27 --> Final output sent to browser
DEBUG - 2022-01-18 06:01:27 --> Total execution time: 0.0476
INFO - 2022-01-18 06:01:30 --> Config Class Initialized
INFO - 2022-01-18 06:01:30 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:01:30 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:01:30 --> Utf8 Class Initialized
INFO - 2022-01-18 06:01:30 --> URI Class Initialized
INFO - 2022-01-18 06:01:30 --> Router Class Initialized
INFO - 2022-01-18 06:01:30 --> Output Class Initialized
INFO - 2022-01-18 06:01:30 --> Security Class Initialized
DEBUG - 2022-01-18 06:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:01:30 --> Input Class Initialized
INFO - 2022-01-18 06:01:30 --> Language Class Initialized
INFO - 2022-01-18 06:01:30 --> Language Class Initialized
INFO - 2022-01-18 06:01:30 --> Config Class Initialized
INFO - 2022-01-18 06:01:30 --> Loader Class Initialized
INFO - 2022-01-18 06:01:30 --> Helper loaded: url_helper
INFO - 2022-01-18 06:01:30 --> Helper loaded: file_helper
INFO - 2022-01-18 06:01:30 --> Helper loaded: form_helper
INFO - 2022-01-18 06:01:30 --> Helper loaded: my_helper
INFO - 2022-01-18 06:01:30 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:01:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:01:30 --> Controller Class Initialized
DEBUG - 2022-01-18 06:01:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-01-18 06:01:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 06:01:31 --> Final output sent to browser
DEBUG - 2022-01-18 06:01:31 --> Total execution time: 0.8771
INFO - 2022-01-18 06:01:34 --> Config Class Initialized
INFO - 2022-01-18 06:01:34 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:01:34 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:01:34 --> Utf8 Class Initialized
INFO - 2022-01-18 06:01:34 --> URI Class Initialized
INFO - 2022-01-18 06:01:34 --> Router Class Initialized
INFO - 2022-01-18 06:01:34 --> Output Class Initialized
INFO - 2022-01-18 06:01:34 --> Security Class Initialized
DEBUG - 2022-01-18 06:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:01:34 --> Input Class Initialized
INFO - 2022-01-18 06:01:34 --> Language Class Initialized
INFO - 2022-01-18 06:01:34 --> Language Class Initialized
INFO - 2022-01-18 06:01:34 --> Config Class Initialized
INFO - 2022-01-18 06:01:34 --> Loader Class Initialized
INFO - 2022-01-18 06:01:34 --> Helper loaded: url_helper
INFO - 2022-01-18 06:01:34 --> Helper loaded: file_helper
INFO - 2022-01-18 06:01:34 --> Helper loaded: form_helper
INFO - 2022-01-18 06:01:34 --> Helper loaded: my_helper
INFO - 2022-01-18 06:01:34 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:01:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:01:34 --> Controller Class Initialized
DEBUG - 2022-01-18 06:01:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2022-01-18 06:01:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 06:01:34 --> Final output sent to browser
DEBUG - 2022-01-18 06:01:34 --> Total execution time: 0.0520
INFO - 2022-01-18 06:01:34 --> Config Class Initialized
INFO - 2022-01-18 06:01:34 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:01:34 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:01:34 --> Utf8 Class Initialized
INFO - 2022-01-18 06:01:34 --> URI Class Initialized
INFO - 2022-01-18 06:01:34 --> Router Class Initialized
INFO - 2022-01-18 06:01:34 --> Output Class Initialized
INFO - 2022-01-18 06:01:34 --> Security Class Initialized
DEBUG - 2022-01-18 06:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:01:34 --> Input Class Initialized
INFO - 2022-01-18 06:01:34 --> Language Class Initialized
INFO - 2022-01-18 06:01:34 --> Language Class Initialized
INFO - 2022-01-18 06:01:34 --> Config Class Initialized
INFO - 2022-01-18 06:01:34 --> Loader Class Initialized
INFO - 2022-01-18 06:01:34 --> Helper loaded: url_helper
INFO - 2022-01-18 06:01:34 --> Helper loaded: file_helper
INFO - 2022-01-18 06:01:34 --> Helper loaded: form_helper
INFO - 2022-01-18 06:01:34 --> Helper loaded: my_helper
INFO - 2022-01-18 06:01:34 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:01:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:01:34 --> Controller Class Initialized
INFO - 2022-01-18 06:01:43 --> Config Class Initialized
INFO - 2022-01-18 06:01:43 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:01:43 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:01:43 --> Utf8 Class Initialized
INFO - 2022-01-18 06:01:43 --> URI Class Initialized
INFO - 2022-01-18 06:01:43 --> Router Class Initialized
INFO - 2022-01-18 06:01:43 --> Output Class Initialized
INFO - 2022-01-18 06:01:43 --> Security Class Initialized
DEBUG - 2022-01-18 06:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:01:43 --> Input Class Initialized
INFO - 2022-01-18 06:01:43 --> Language Class Initialized
INFO - 2022-01-18 06:01:43 --> Language Class Initialized
INFO - 2022-01-18 06:01:43 --> Config Class Initialized
INFO - 2022-01-18 06:01:43 --> Loader Class Initialized
INFO - 2022-01-18 06:01:43 --> Helper loaded: url_helper
INFO - 2022-01-18 06:01:43 --> Helper loaded: file_helper
INFO - 2022-01-18 06:01:43 --> Helper loaded: form_helper
INFO - 2022-01-18 06:01:43 --> Helper loaded: my_helper
INFO - 2022-01-18 06:01:43 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:01:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:01:43 --> Controller Class Initialized
INFO - 2022-01-18 06:01:43 --> Final output sent to browser
DEBUG - 2022-01-18 06:01:43 --> Total execution time: 0.0526
INFO - 2022-01-18 06:01:43 --> Config Class Initialized
INFO - 2022-01-18 06:01:43 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:01:43 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:01:43 --> Utf8 Class Initialized
INFO - 2022-01-18 06:01:43 --> URI Class Initialized
INFO - 2022-01-18 06:01:43 --> Router Class Initialized
INFO - 2022-01-18 06:01:43 --> Output Class Initialized
INFO - 2022-01-18 06:01:43 --> Security Class Initialized
DEBUG - 2022-01-18 06:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:01:43 --> Input Class Initialized
INFO - 2022-01-18 06:01:43 --> Language Class Initialized
INFO - 2022-01-18 06:01:43 --> Language Class Initialized
INFO - 2022-01-18 06:01:43 --> Config Class Initialized
INFO - 2022-01-18 06:01:43 --> Loader Class Initialized
INFO - 2022-01-18 06:01:43 --> Helper loaded: url_helper
INFO - 2022-01-18 06:01:43 --> Helper loaded: file_helper
INFO - 2022-01-18 06:01:43 --> Helper loaded: form_helper
INFO - 2022-01-18 06:01:43 --> Helper loaded: my_helper
INFO - 2022-01-18 06:01:43 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:01:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:01:43 --> Controller Class Initialized
INFO - 2022-01-18 06:01:46 --> Config Class Initialized
INFO - 2022-01-18 06:01:46 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:01:46 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:01:46 --> Utf8 Class Initialized
INFO - 2022-01-18 06:01:46 --> URI Class Initialized
INFO - 2022-01-18 06:01:46 --> Router Class Initialized
INFO - 2022-01-18 06:01:46 --> Output Class Initialized
INFO - 2022-01-18 06:01:46 --> Security Class Initialized
DEBUG - 2022-01-18 06:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:01:46 --> Input Class Initialized
INFO - 2022-01-18 06:01:46 --> Language Class Initialized
INFO - 2022-01-18 06:01:46 --> Language Class Initialized
INFO - 2022-01-18 06:01:46 --> Config Class Initialized
INFO - 2022-01-18 06:01:46 --> Loader Class Initialized
INFO - 2022-01-18 06:01:46 --> Helper loaded: url_helper
INFO - 2022-01-18 06:01:46 --> Helper loaded: file_helper
INFO - 2022-01-18 06:01:46 --> Helper loaded: form_helper
INFO - 2022-01-18 06:01:46 --> Helper loaded: my_helper
INFO - 2022-01-18 06:01:46 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:01:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:01:46 --> Controller Class Initialized
INFO - 2022-01-18 06:01:46 --> Final output sent to browser
DEBUG - 2022-01-18 06:01:46 --> Total execution time: 0.0722
INFO - 2022-01-18 06:01:46 --> Config Class Initialized
INFO - 2022-01-18 06:01:46 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:01:46 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:01:46 --> Utf8 Class Initialized
INFO - 2022-01-18 06:01:46 --> URI Class Initialized
INFO - 2022-01-18 06:01:46 --> Router Class Initialized
INFO - 2022-01-18 06:01:46 --> Output Class Initialized
INFO - 2022-01-18 06:01:46 --> Security Class Initialized
DEBUG - 2022-01-18 06:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:01:46 --> Input Class Initialized
INFO - 2022-01-18 06:01:46 --> Language Class Initialized
INFO - 2022-01-18 06:01:46 --> Language Class Initialized
INFO - 2022-01-18 06:01:46 --> Config Class Initialized
INFO - 2022-01-18 06:01:46 --> Loader Class Initialized
INFO - 2022-01-18 06:01:46 --> Helper loaded: url_helper
INFO - 2022-01-18 06:01:46 --> Helper loaded: file_helper
INFO - 2022-01-18 06:01:46 --> Helper loaded: form_helper
INFO - 2022-01-18 06:01:46 --> Helper loaded: my_helper
INFO - 2022-01-18 06:01:46 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:01:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:01:46 --> Controller Class Initialized
INFO - 2022-01-18 06:01:48 --> Config Class Initialized
INFO - 2022-01-18 06:01:48 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:01:48 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:01:48 --> Utf8 Class Initialized
INFO - 2022-01-18 06:01:48 --> URI Class Initialized
INFO - 2022-01-18 06:01:48 --> Router Class Initialized
INFO - 2022-01-18 06:01:48 --> Output Class Initialized
INFO - 2022-01-18 06:01:48 --> Security Class Initialized
DEBUG - 2022-01-18 06:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:01:48 --> Input Class Initialized
INFO - 2022-01-18 06:01:48 --> Language Class Initialized
INFO - 2022-01-18 06:01:48 --> Language Class Initialized
INFO - 2022-01-18 06:01:48 --> Config Class Initialized
INFO - 2022-01-18 06:01:48 --> Loader Class Initialized
INFO - 2022-01-18 06:01:48 --> Helper loaded: url_helper
INFO - 2022-01-18 06:01:48 --> Helper loaded: file_helper
INFO - 2022-01-18 06:01:48 --> Helper loaded: form_helper
INFO - 2022-01-18 06:01:48 --> Helper loaded: my_helper
INFO - 2022-01-18 06:01:48 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:01:48 --> Controller Class Initialized
INFO - 2022-01-18 06:01:48 --> Final output sent to browser
DEBUG - 2022-01-18 06:01:48 --> Total execution time: 0.0580
INFO - 2022-01-18 06:01:48 --> Config Class Initialized
INFO - 2022-01-18 06:01:48 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:01:48 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:01:48 --> Utf8 Class Initialized
INFO - 2022-01-18 06:01:48 --> URI Class Initialized
INFO - 2022-01-18 06:01:48 --> Router Class Initialized
INFO - 2022-01-18 06:01:48 --> Output Class Initialized
INFO - 2022-01-18 06:01:48 --> Security Class Initialized
DEBUG - 2022-01-18 06:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:01:48 --> Input Class Initialized
INFO - 2022-01-18 06:01:48 --> Language Class Initialized
INFO - 2022-01-18 06:01:48 --> Language Class Initialized
INFO - 2022-01-18 06:01:48 --> Config Class Initialized
INFO - 2022-01-18 06:01:48 --> Loader Class Initialized
INFO - 2022-01-18 06:01:48 --> Helper loaded: url_helper
INFO - 2022-01-18 06:01:48 --> Helper loaded: file_helper
INFO - 2022-01-18 06:01:48 --> Helper loaded: form_helper
INFO - 2022-01-18 06:01:48 --> Helper loaded: my_helper
INFO - 2022-01-18 06:01:48 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:01:48 --> Controller Class Initialized
INFO - 2022-01-18 06:01:48 --> Final output sent to browser
DEBUG - 2022-01-18 06:01:48 --> Total execution time: 0.0410
INFO - 2022-01-18 06:01:48 --> Config Class Initialized
INFO - 2022-01-18 06:01:48 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:01:48 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:01:48 --> Utf8 Class Initialized
INFO - 2022-01-18 06:01:48 --> URI Class Initialized
INFO - 2022-01-18 06:01:48 --> Router Class Initialized
INFO - 2022-01-18 06:01:48 --> Output Class Initialized
INFO - 2022-01-18 06:01:48 --> Security Class Initialized
DEBUG - 2022-01-18 06:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:01:48 --> Input Class Initialized
INFO - 2022-01-18 06:01:48 --> Language Class Initialized
INFO - 2022-01-18 06:01:48 --> Language Class Initialized
INFO - 2022-01-18 06:01:48 --> Config Class Initialized
INFO - 2022-01-18 06:01:48 --> Loader Class Initialized
INFO - 2022-01-18 06:01:48 --> Helper loaded: url_helper
INFO - 2022-01-18 06:01:48 --> Helper loaded: file_helper
INFO - 2022-01-18 06:01:48 --> Helper loaded: form_helper
INFO - 2022-01-18 06:01:48 --> Helper loaded: my_helper
INFO - 2022-01-18 06:01:48 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:01:48 --> Controller Class Initialized
INFO - 2022-01-18 06:01:48 --> Config Class Initialized
INFO - 2022-01-18 06:01:48 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:01:48 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:01:48 --> Utf8 Class Initialized
INFO - 2022-01-18 06:01:48 --> URI Class Initialized
INFO - 2022-01-18 06:01:48 --> Router Class Initialized
INFO - 2022-01-18 06:01:48 --> Output Class Initialized
INFO - 2022-01-18 06:01:48 --> Security Class Initialized
DEBUG - 2022-01-18 06:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:01:48 --> Input Class Initialized
INFO - 2022-01-18 06:01:48 --> Language Class Initialized
INFO - 2022-01-18 06:01:48 --> Language Class Initialized
INFO - 2022-01-18 06:01:48 --> Config Class Initialized
INFO - 2022-01-18 06:01:48 --> Loader Class Initialized
INFO - 2022-01-18 06:01:48 --> Helper loaded: url_helper
INFO - 2022-01-18 06:01:48 --> Helper loaded: file_helper
INFO - 2022-01-18 06:01:48 --> Helper loaded: form_helper
INFO - 2022-01-18 06:01:48 --> Helper loaded: my_helper
INFO - 2022-01-18 06:01:48 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:01:48 --> Controller Class Initialized
INFO - 2022-01-18 06:01:55 --> Config Class Initialized
INFO - 2022-01-18 06:01:55 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:01:55 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:01:55 --> Utf8 Class Initialized
INFO - 2022-01-18 06:01:55 --> URI Class Initialized
INFO - 2022-01-18 06:01:55 --> Router Class Initialized
INFO - 2022-01-18 06:01:55 --> Output Class Initialized
INFO - 2022-01-18 06:01:55 --> Security Class Initialized
DEBUG - 2022-01-18 06:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:01:55 --> Input Class Initialized
INFO - 2022-01-18 06:01:55 --> Language Class Initialized
INFO - 2022-01-18 06:01:55 --> Language Class Initialized
INFO - 2022-01-18 06:01:55 --> Config Class Initialized
INFO - 2022-01-18 06:01:55 --> Loader Class Initialized
INFO - 2022-01-18 06:01:55 --> Helper loaded: url_helper
INFO - 2022-01-18 06:01:55 --> Helper loaded: file_helper
INFO - 2022-01-18 06:01:55 --> Helper loaded: form_helper
INFO - 2022-01-18 06:01:55 --> Helper loaded: my_helper
INFO - 2022-01-18 06:01:55 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:01:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:01:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:01:55 --> Controller Class Initialized
INFO - 2022-01-18 06:01:55 --> Helper loaded: cookie_helper
INFO - 2022-01-18 06:01:55 --> Config Class Initialized
INFO - 2022-01-18 06:01:55 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:01:55 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:01:55 --> Utf8 Class Initialized
INFO - 2022-01-18 06:01:55 --> URI Class Initialized
INFO - 2022-01-18 06:01:55 --> Router Class Initialized
INFO - 2022-01-18 06:01:55 --> Output Class Initialized
INFO - 2022-01-18 06:01:55 --> Security Class Initialized
DEBUG - 2022-01-18 06:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:01:55 --> Input Class Initialized
INFO - 2022-01-18 06:01:55 --> Language Class Initialized
INFO - 2022-01-18 06:01:56 --> Language Class Initialized
INFO - 2022-01-18 06:01:56 --> Config Class Initialized
INFO - 2022-01-18 06:01:56 --> Loader Class Initialized
INFO - 2022-01-18 06:01:56 --> Helper loaded: url_helper
INFO - 2022-01-18 06:01:56 --> Helper loaded: file_helper
INFO - 2022-01-18 06:01:56 --> Helper loaded: form_helper
INFO - 2022-01-18 06:01:56 --> Helper loaded: my_helper
INFO - 2022-01-18 06:01:56 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:01:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:01:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:01:56 --> Controller Class Initialized
DEBUG - 2022-01-18 06:01:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-01-18 06:01:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 06:01:56 --> Final output sent to browser
DEBUG - 2022-01-18 06:01:56 --> Total execution time: 0.0350
INFO - 2022-01-18 06:02:03 --> Config Class Initialized
INFO - 2022-01-18 06:02:03 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:02:03 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:02:03 --> Utf8 Class Initialized
INFO - 2022-01-18 06:02:03 --> URI Class Initialized
INFO - 2022-01-18 06:02:03 --> Router Class Initialized
INFO - 2022-01-18 06:02:03 --> Output Class Initialized
INFO - 2022-01-18 06:02:03 --> Security Class Initialized
DEBUG - 2022-01-18 06:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:02:03 --> Input Class Initialized
INFO - 2022-01-18 06:02:03 --> Language Class Initialized
INFO - 2022-01-18 06:02:03 --> Language Class Initialized
INFO - 2022-01-18 06:02:03 --> Config Class Initialized
INFO - 2022-01-18 06:02:03 --> Loader Class Initialized
INFO - 2022-01-18 06:02:03 --> Helper loaded: url_helper
INFO - 2022-01-18 06:02:03 --> Helper loaded: file_helper
INFO - 2022-01-18 06:02:03 --> Helper loaded: form_helper
INFO - 2022-01-18 06:02:03 --> Helper loaded: my_helper
INFO - 2022-01-18 06:02:03 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:02:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:02:03 --> Controller Class Initialized
INFO - 2022-01-18 06:02:03 --> Helper loaded: cookie_helper
INFO - 2022-01-18 06:02:03 --> Final output sent to browser
DEBUG - 2022-01-18 06:02:03 --> Total execution time: 0.0576
INFO - 2022-01-18 06:02:04 --> Config Class Initialized
INFO - 2022-01-18 06:02:04 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:02:04 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:02:04 --> Utf8 Class Initialized
INFO - 2022-01-18 06:02:04 --> URI Class Initialized
INFO - 2022-01-18 06:02:04 --> Router Class Initialized
INFO - 2022-01-18 06:02:04 --> Output Class Initialized
INFO - 2022-01-18 06:02:04 --> Security Class Initialized
DEBUG - 2022-01-18 06:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:02:04 --> Input Class Initialized
INFO - 2022-01-18 06:02:04 --> Language Class Initialized
INFO - 2022-01-18 06:02:04 --> Language Class Initialized
INFO - 2022-01-18 06:02:04 --> Config Class Initialized
INFO - 2022-01-18 06:02:04 --> Loader Class Initialized
INFO - 2022-01-18 06:02:04 --> Helper loaded: url_helper
INFO - 2022-01-18 06:02:04 --> Helper loaded: file_helper
INFO - 2022-01-18 06:02:04 --> Helper loaded: form_helper
INFO - 2022-01-18 06:02:04 --> Helper loaded: my_helper
INFO - 2022-01-18 06:02:04 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:02:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:02:04 --> Controller Class Initialized
DEBUG - 2022-01-18 06:02:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-01-18 06:02:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 06:02:04 --> Final output sent to browser
DEBUG - 2022-01-18 06:02:04 --> Total execution time: 0.2790
INFO - 2022-01-18 06:02:18 --> Config Class Initialized
INFO - 2022-01-18 06:02:18 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:02:18 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:02:18 --> Utf8 Class Initialized
INFO - 2022-01-18 06:02:18 --> URI Class Initialized
INFO - 2022-01-18 06:02:18 --> Router Class Initialized
INFO - 2022-01-18 06:02:18 --> Output Class Initialized
INFO - 2022-01-18 06:02:18 --> Security Class Initialized
DEBUG - 2022-01-18 06:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:02:18 --> Input Class Initialized
INFO - 2022-01-18 06:02:18 --> Language Class Initialized
INFO - 2022-01-18 06:02:18 --> Language Class Initialized
INFO - 2022-01-18 06:02:18 --> Config Class Initialized
INFO - 2022-01-18 06:02:18 --> Loader Class Initialized
INFO - 2022-01-18 06:02:18 --> Helper loaded: url_helper
INFO - 2022-01-18 06:02:18 --> Helper loaded: file_helper
INFO - 2022-01-18 06:02:18 --> Helper loaded: form_helper
INFO - 2022-01-18 06:02:18 --> Helper loaded: my_helper
INFO - 2022-01-18 06:02:18 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:02:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:02:18 --> Controller Class Initialized
DEBUG - 2022-01-18 06:02:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2022-01-18 06:02:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 06:02:18 --> Final output sent to browser
DEBUG - 2022-01-18 06:02:18 --> Total execution time: 0.0760
INFO - 2022-01-18 06:37:46 --> Config Class Initialized
INFO - 2022-01-18 06:37:46 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:37:46 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:37:46 --> Utf8 Class Initialized
INFO - 2022-01-18 06:37:46 --> URI Class Initialized
INFO - 2022-01-18 06:37:46 --> Router Class Initialized
INFO - 2022-01-18 06:37:46 --> Output Class Initialized
INFO - 2022-01-18 06:37:46 --> Security Class Initialized
DEBUG - 2022-01-18 06:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:37:46 --> Input Class Initialized
INFO - 2022-01-18 06:37:46 --> Language Class Initialized
INFO - 2022-01-18 06:37:46 --> Language Class Initialized
INFO - 2022-01-18 06:37:46 --> Config Class Initialized
INFO - 2022-01-18 06:37:46 --> Loader Class Initialized
INFO - 2022-01-18 06:37:46 --> Helper loaded: url_helper
INFO - 2022-01-18 06:37:46 --> Helper loaded: file_helper
INFO - 2022-01-18 06:37:46 --> Helper loaded: form_helper
INFO - 2022-01-18 06:37:46 --> Helper loaded: my_helper
INFO - 2022-01-18 06:37:46 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:37:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:37:46 --> Controller Class Initialized
DEBUG - 2022-01-18 06:37:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-01-18 06:37:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 06:37:46 --> Final output sent to browser
DEBUG - 2022-01-18 06:37:46 --> Total execution time: 0.2740
INFO - 2022-01-18 06:37:51 --> Config Class Initialized
INFO - 2022-01-18 06:37:51 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:37:51 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:37:51 --> Utf8 Class Initialized
INFO - 2022-01-18 06:37:51 --> URI Class Initialized
INFO - 2022-01-18 06:37:51 --> Router Class Initialized
INFO - 2022-01-18 06:37:51 --> Output Class Initialized
INFO - 2022-01-18 06:37:51 --> Security Class Initialized
DEBUG - 2022-01-18 06:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:37:51 --> Input Class Initialized
INFO - 2022-01-18 06:37:51 --> Language Class Initialized
INFO - 2022-01-18 06:37:51 --> Language Class Initialized
INFO - 2022-01-18 06:37:51 --> Config Class Initialized
INFO - 2022-01-18 06:37:51 --> Loader Class Initialized
INFO - 2022-01-18 06:37:51 --> Helper loaded: url_helper
INFO - 2022-01-18 06:37:51 --> Helper loaded: file_helper
INFO - 2022-01-18 06:37:51 --> Helper loaded: form_helper
INFO - 2022-01-18 06:37:51 --> Helper loaded: my_helper
INFO - 2022-01-18 06:37:51 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:37:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:37:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:37:51 --> Controller Class Initialized
DEBUG - 2022-01-18 06:37:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-01-18 06:37:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 06:37:51 --> Final output sent to browser
DEBUG - 2022-01-18 06:37:51 --> Total execution time: 0.0690
INFO - 2022-01-18 06:37:58 --> Config Class Initialized
INFO - 2022-01-18 06:37:58 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:37:58 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:37:58 --> Utf8 Class Initialized
INFO - 2022-01-18 06:37:58 --> URI Class Initialized
INFO - 2022-01-18 06:37:58 --> Router Class Initialized
INFO - 2022-01-18 06:37:58 --> Output Class Initialized
INFO - 2022-01-18 06:37:58 --> Security Class Initialized
DEBUG - 2022-01-18 06:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:37:58 --> Input Class Initialized
INFO - 2022-01-18 06:37:58 --> Language Class Initialized
INFO - 2022-01-18 06:37:58 --> Language Class Initialized
INFO - 2022-01-18 06:37:58 --> Config Class Initialized
INFO - 2022-01-18 06:37:58 --> Loader Class Initialized
INFO - 2022-01-18 06:37:58 --> Helper loaded: url_helper
INFO - 2022-01-18 06:37:58 --> Helper loaded: file_helper
INFO - 2022-01-18 06:37:58 --> Helper loaded: form_helper
INFO - 2022-01-18 06:37:58 --> Helper loaded: my_helper
INFO - 2022-01-18 06:37:58 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:37:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:37:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:37:58 --> Controller Class Initialized
DEBUG - 2022-01-18 06:37:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2022-01-18 06:37:59 --> Final output sent to browser
DEBUG - 2022-01-18 06:37:59 --> Total execution time: 0.1300
INFO - 2022-01-18 06:38:32 --> Config Class Initialized
INFO - 2022-01-18 06:38:32 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:38:32 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:38:32 --> Utf8 Class Initialized
INFO - 2022-01-18 06:38:32 --> URI Class Initialized
INFO - 2022-01-18 06:38:32 --> Router Class Initialized
INFO - 2022-01-18 06:38:32 --> Output Class Initialized
INFO - 2022-01-18 06:38:32 --> Security Class Initialized
DEBUG - 2022-01-18 06:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:38:32 --> Input Class Initialized
INFO - 2022-01-18 06:38:32 --> Language Class Initialized
INFO - 2022-01-18 06:38:32 --> Language Class Initialized
INFO - 2022-01-18 06:38:32 --> Config Class Initialized
INFO - 2022-01-18 06:38:32 --> Loader Class Initialized
INFO - 2022-01-18 06:38:32 --> Helper loaded: url_helper
INFO - 2022-01-18 06:38:32 --> Helper loaded: file_helper
INFO - 2022-01-18 06:38:32 --> Helper loaded: form_helper
INFO - 2022-01-18 06:38:32 --> Helper loaded: my_helper
INFO - 2022-01-18 06:38:32 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:38:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:38:32 --> Controller Class Initialized
INFO - 2022-01-18 06:38:32 --> Helper loaded: cookie_helper
INFO - 2022-01-18 06:38:32 --> Config Class Initialized
INFO - 2022-01-18 06:38:32 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:38:32 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:38:32 --> Utf8 Class Initialized
INFO - 2022-01-18 06:38:32 --> URI Class Initialized
INFO - 2022-01-18 06:38:32 --> Router Class Initialized
INFO - 2022-01-18 06:38:32 --> Output Class Initialized
INFO - 2022-01-18 06:38:32 --> Security Class Initialized
DEBUG - 2022-01-18 06:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:38:32 --> Input Class Initialized
INFO - 2022-01-18 06:38:32 --> Language Class Initialized
INFO - 2022-01-18 06:38:32 --> Language Class Initialized
INFO - 2022-01-18 06:38:32 --> Config Class Initialized
INFO - 2022-01-18 06:38:32 --> Loader Class Initialized
INFO - 2022-01-18 06:38:32 --> Helper loaded: url_helper
INFO - 2022-01-18 06:38:32 --> Helper loaded: file_helper
INFO - 2022-01-18 06:38:32 --> Helper loaded: form_helper
INFO - 2022-01-18 06:38:32 --> Helper loaded: my_helper
INFO - 2022-01-18 06:38:32 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:38:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:38:32 --> Controller Class Initialized
DEBUG - 2022-01-18 06:38:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-01-18 06:38:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 06:38:32 --> Final output sent to browser
DEBUG - 2022-01-18 06:38:32 --> Total execution time: 0.0350
INFO - 2022-01-18 06:38:43 --> Config Class Initialized
INFO - 2022-01-18 06:38:43 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:38:43 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:38:43 --> Utf8 Class Initialized
INFO - 2022-01-18 06:38:43 --> URI Class Initialized
INFO - 2022-01-18 06:38:43 --> Router Class Initialized
INFO - 2022-01-18 06:38:43 --> Output Class Initialized
INFO - 2022-01-18 06:38:43 --> Security Class Initialized
DEBUG - 2022-01-18 06:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:38:43 --> Input Class Initialized
INFO - 2022-01-18 06:38:43 --> Language Class Initialized
INFO - 2022-01-18 06:38:43 --> Language Class Initialized
INFO - 2022-01-18 06:38:43 --> Config Class Initialized
INFO - 2022-01-18 06:38:43 --> Loader Class Initialized
INFO - 2022-01-18 06:38:43 --> Helper loaded: url_helper
INFO - 2022-01-18 06:38:43 --> Helper loaded: file_helper
INFO - 2022-01-18 06:38:43 --> Helper loaded: form_helper
INFO - 2022-01-18 06:38:43 --> Helper loaded: my_helper
INFO - 2022-01-18 06:38:43 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:38:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:38:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:38:44 --> Controller Class Initialized
INFO - 2022-01-18 06:38:44 --> Helper loaded: cookie_helper
INFO - 2022-01-18 06:38:44 --> Final output sent to browser
DEBUG - 2022-01-18 06:38:44 --> Total execution time: 0.0622
INFO - 2022-01-18 06:38:44 --> Config Class Initialized
INFO - 2022-01-18 06:38:44 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:38:44 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:38:44 --> Utf8 Class Initialized
INFO - 2022-01-18 06:38:44 --> URI Class Initialized
INFO - 2022-01-18 06:38:44 --> Router Class Initialized
INFO - 2022-01-18 06:38:44 --> Output Class Initialized
INFO - 2022-01-18 06:38:44 --> Security Class Initialized
DEBUG - 2022-01-18 06:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:38:44 --> Input Class Initialized
INFO - 2022-01-18 06:38:44 --> Language Class Initialized
INFO - 2022-01-18 06:38:44 --> Language Class Initialized
INFO - 2022-01-18 06:38:44 --> Config Class Initialized
INFO - 2022-01-18 06:38:44 --> Loader Class Initialized
INFO - 2022-01-18 06:38:44 --> Helper loaded: url_helper
INFO - 2022-01-18 06:38:44 --> Helper loaded: file_helper
INFO - 2022-01-18 06:38:44 --> Helper loaded: form_helper
INFO - 2022-01-18 06:38:44 --> Helper loaded: my_helper
INFO - 2022-01-18 06:38:44 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:38:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:38:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:38:44 --> Controller Class Initialized
DEBUG - 2022-01-18 06:38:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-01-18 06:38:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 06:38:44 --> Final output sent to browser
DEBUG - 2022-01-18 06:38:44 --> Total execution time: 0.3590
INFO - 2022-01-18 06:38:49 --> Config Class Initialized
INFO - 2022-01-18 06:38:49 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:38:49 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:38:49 --> Utf8 Class Initialized
INFO - 2022-01-18 06:38:49 --> URI Class Initialized
INFO - 2022-01-18 06:38:49 --> Router Class Initialized
INFO - 2022-01-18 06:38:49 --> Output Class Initialized
INFO - 2022-01-18 06:38:49 --> Security Class Initialized
DEBUG - 2022-01-18 06:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:38:49 --> Input Class Initialized
INFO - 2022-01-18 06:38:49 --> Language Class Initialized
INFO - 2022-01-18 06:38:49 --> Language Class Initialized
INFO - 2022-01-18 06:38:49 --> Config Class Initialized
INFO - 2022-01-18 06:38:49 --> Loader Class Initialized
INFO - 2022-01-18 06:38:49 --> Helper loaded: url_helper
INFO - 2022-01-18 06:38:49 --> Helper loaded: file_helper
INFO - 2022-01-18 06:38:49 --> Helper loaded: form_helper
INFO - 2022-01-18 06:38:49 --> Helper loaded: my_helper
INFO - 2022-01-18 06:38:49 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:38:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:38:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:38:49 --> Controller Class Initialized
DEBUG - 2022-01-18 06:38:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2022-01-18 06:38:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 06:38:49 --> Final output sent to browser
DEBUG - 2022-01-18 06:38:49 --> Total execution time: 0.0520
INFO - 2022-01-18 06:38:49 --> Config Class Initialized
INFO - 2022-01-18 06:38:49 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:38:49 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:38:49 --> Utf8 Class Initialized
INFO - 2022-01-18 06:38:49 --> URI Class Initialized
INFO - 2022-01-18 06:38:49 --> Router Class Initialized
INFO - 2022-01-18 06:38:49 --> Output Class Initialized
INFO - 2022-01-18 06:38:49 --> Security Class Initialized
DEBUG - 2022-01-18 06:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:38:49 --> Input Class Initialized
INFO - 2022-01-18 06:38:49 --> Language Class Initialized
INFO - 2022-01-18 06:38:49 --> Language Class Initialized
INFO - 2022-01-18 06:38:49 --> Config Class Initialized
INFO - 2022-01-18 06:38:49 --> Loader Class Initialized
INFO - 2022-01-18 06:38:49 --> Helper loaded: url_helper
INFO - 2022-01-18 06:38:49 --> Helper loaded: file_helper
INFO - 2022-01-18 06:38:49 --> Helper loaded: form_helper
INFO - 2022-01-18 06:38:49 --> Helper loaded: my_helper
INFO - 2022-01-18 06:38:49 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:38:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:38:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:38:49 --> Controller Class Initialized
INFO - 2022-01-18 06:38:54 --> Config Class Initialized
INFO - 2022-01-18 06:38:54 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:38:54 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:38:54 --> Utf8 Class Initialized
INFO - 2022-01-18 06:38:54 --> URI Class Initialized
INFO - 2022-01-18 06:38:54 --> Router Class Initialized
INFO - 2022-01-18 06:38:54 --> Output Class Initialized
INFO - 2022-01-18 06:38:54 --> Security Class Initialized
DEBUG - 2022-01-18 06:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:38:54 --> Input Class Initialized
INFO - 2022-01-18 06:38:54 --> Language Class Initialized
INFO - 2022-01-18 06:38:54 --> Language Class Initialized
INFO - 2022-01-18 06:38:54 --> Config Class Initialized
INFO - 2022-01-18 06:38:54 --> Loader Class Initialized
INFO - 2022-01-18 06:38:54 --> Helper loaded: url_helper
INFO - 2022-01-18 06:38:54 --> Helper loaded: file_helper
INFO - 2022-01-18 06:38:54 --> Helper loaded: form_helper
INFO - 2022-01-18 06:38:54 --> Helper loaded: my_helper
INFO - 2022-01-18 06:38:54 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:38:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:38:54 --> Controller Class Initialized
INFO - 2022-01-18 06:38:54 --> Final output sent to browser
DEBUG - 2022-01-18 06:38:54 --> Total execution time: 0.0530
INFO - 2022-01-18 06:38:54 --> Config Class Initialized
INFO - 2022-01-18 06:38:54 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:38:54 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:38:54 --> Utf8 Class Initialized
INFO - 2022-01-18 06:38:54 --> URI Class Initialized
INFO - 2022-01-18 06:38:54 --> Router Class Initialized
INFO - 2022-01-18 06:38:54 --> Output Class Initialized
INFO - 2022-01-18 06:38:54 --> Security Class Initialized
DEBUG - 2022-01-18 06:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:38:54 --> Input Class Initialized
INFO - 2022-01-18 06:38:54 --> Language Class Initialized
INFO - 2022-01-18 06:38:54 --> Language Class Initialized
INFO - 2022-01-18 06:38:54 --> Config Class Initialized
INFO - 2022-01-18 06:38:54 --> Loader Class Initialized
INFO - 2022-01-18 06:38:54 --> Helper loaded: url_helper
INFO - 2022-01-18 06:38:54 --> Helper loaded: file_helper
INFO - 2022-01-18 06:38:54 --> Helper loaded: form_helper
INFO - 2022-01-18 06:38:54 --> Helper loaded: my_helper
INFO - 2022-01-18 06:38:54 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:38:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:38:54 --> Controller Class Initialized
INFO - 2022-01-18 06:39:06 --> Config Class Initialized
INFO - 2022-01-18 06:39:06 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:39:06 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:39:06 --> Utf8 Class Initialized
INFO - 2022-01-18 06:39:06 --> URI Class Initialized
INFO - 2022-01-18 06:39:06 --> Router Class Initialized
INFO - 2022-01-18 06:39:06 --> Output Class Initialized
INFO - 2022-01-18 06:39:06 --> Security Class Initialized
DEBUG - 2022-01-18 06:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:39:06 --> Input Class Initialized
INFO - 2022-01-18 06:39:06 --> Language Class Initialized
INFO - 2022-01-18 06:39:06 --> Language Class Initialized
INFO - 2022-01-18 06:39:06 --> Config Class Initialized
INFO - 2022-01-18 06:39:06 --> Loader Class Initialized
INFO - 2022-01-18 06:39:06 --> Helper loaded: url_helper
INFO - 2022-01-18 06:39:06 --> Helper loaded: file_helper
INFO - 2022-01-18 06:39:06 --> Helper loaded: form_helper
INFO - 2022-01-18 06:39:06 --> Helper loaded: my_helper
INFO - 2022-01-18 06:39:06 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:39:06 --> Controller Class Initialized
INFO - 2022-01-18 06:39:06 --> Helper loaded: cookie_helper
INFO - 2022-01-18 06:39:06 --> Config Class Initialized
INFO - 2022-01-18 06:39:06 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:39:06 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:39:06 --> Utf8 Class Initialized
INFO - 2022-01-18 06:39:06 --> URI Class Initialized
INFO - 2022-01-18 06:39:06 --> Router Class Initialized
INFO - 2022-01-18 06:39:06 --> Output Class Initialized
INFO - 2022-01-18 06:39:06 --> Security Class Initialized
DEBUG - 2022-01-18 06:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:39:06 --> Input Class Initialized
INFO - 2022-01-18 06:39:06 --> Language Class Initialized
INFO - 2022-01-18 06:39:06 --> Language Class Initialized
INFO - 2022-01-18 06:39:06 --> Config Class Initialized
INFO - 2022-01-18 06:39:06 --> Loader Class Initialized
INFO - 2022-01-18 06:39:06 --> Helper loaded: url_helper
INFO - 2022-01-18 06:39:06 --> Helper loaded: file_helper
INFO - 2022-01-18 06:39:06 --> Helper loaded: form_helper
INFO - 2022-01-18 06:39:06 --> Helper loaded: my_helper
INFO - 2022-01-18 06:39:06 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:39:06 --> Controller Class Initialized
DEBUG - 2022-01-18 06:39:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-01-18 06:39:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 06:39:06 --> Final output sent to browser
DEBUG - 2022-01-18 06:39:06 --> Total execution time: 0.0370
INFO - 2022-01-18 06:39:14 --> Config Class Initialized
INFO - 2022-01-18 06:39:14 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:39:14 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:39:14 --> Utf8 Class Initialized
INFO - 2022-01-18 06:39:14 --> URI Class Initialized
INFO - 2022-01-18 06:39:14 --> Router Class Initialized
INFO - 2022-01-18 06:39:14 --> Output Class Initialized
INFO - 2022-01-18 06:39:14 --> Security Class Initialized
DEBUG - 2022-01-18 06:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:39:14 --> Input Class Initialized
INFO - 2022-01-18 06:39:14 --> Language Class Initialized
INFO - 2022-01-18 06:39:14 --> Language Class Initialized
INFO - 2022-01-18 06:39:14 --> Config Class Initialized
INFO - 2022-01-18 06:39:14 --> Loader Class Initialized
INFO - 2022-01-18 06:39:14 --> Helper loaded: url_helper
INFO - 2022-01-18 06:39:14 --> Helper loaded: file_helper
INFO - 2022-01-18 06:39:14 --> Helper loaded: form_helper
INFO - 2022-01-18 06:39:14 --> Helper loaded: my_helper
INFO - 2022-01-18 06:39:14 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:39:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:39:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:39:14 --> Controller Class Initialized
INFO - 2022-01-18 06:39:14 --> Helper loaded: cookie_helper
INFO - 2022-01-18 06:39:14 --> Final output sent to browser
DEBUG - 2022-01-18 06:39:14 --> Total execution time: 0.0670
INFO - 2022-01-18 06:39:15 --> Config Class Initialized
INFO - 2022-01-18 06:39:15 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:39:15 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:39:15 --> Utf8 Class Initialized
INFO - 2022-01-18 06:39:15 --> URI Class Initialized
INFO - 2022-01-18 06:39:15 --> Router Class Initialized
INFO - 2022-01-18 06:39:15 --> Output Class Initialized
INFO - 2022-01-18 06:39:15 --> Security Class Initialized
DEBUG - 2022-01-18 06:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:39:15 --> Input Class Initialized
INFO - 2022-01-18 06:39:15 --> Language Class Initialized
INFO - 2022-01-18 06:39:15 --> Language Class Initialized
INFO - 2022-01-18 06:39:15 --> Config Class Initialized
INFO - 2022-01-18 06:39:15 --> Loader Class Initialized
INFO - 2022-01-18 06:39:15 --> Helper loaded: url_helper
INFO - 2022-01-18 06:39:15 --> Helper loaded: file_helper
INFO - 2022-01-18 06:39:15 --> Helper loaded: form_helper
INFO - 2022-01-18 06:39:15 --> Helper loaded: my_helper
INFO - 2022-01-18 06:39:15 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:39:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:39:15 --> Controller Class Initialized
DEBUG - 2022-01-18 06:39:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-01-18 06:39:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 06:39:16 --> Final output sent to browser
DEBUG - 2022-01-18 06:39:16 --> Total execution time: 0.2900
INFO - 2022-01-18 06:39:17 --> Config Class Initialized
INFO - 2022-01-18 06:39:17 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:39:17 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:39:17 --> Utf8 Class Initialized
INFO - 2022-01-18 06:39:17 --> URI Class Initialized
INFO - 2022-01-18 06:39:17 --> Router Class Initialized
INFO - 2022-01-18 06:39:17 --> Output Class Initialized
INFO - 2022-01-18 06:39:17 --> Security Class Initialized
DEBUG - 2022-01-18 06:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:39:17 --> Input Class Initialized
INFO - 2022-01-18 06:39:17 --> Language Class Initialized
INFO - 2022-01-18 06:39:17 --> Language Class Initialized
INFO - 2022-01-18 06:39:17 --> Config Class Initialized
INFO - 2022-01-18 06:39:17 --> Loader Class Initialized
INFO - 2022-01-18 06:39:17 --> Helper loaded: url_helper
INFO - 2022-01-18 06:39:17 --> Helper loaded: file_helper
INFO - 2022-01-18 06:39:17 --> Helper loaded: form_helper
INFO - 2022-01-18 06:39:17 --> Helper loaded: my_helper
INFO - 2022-01-18 06:39:17 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:39:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:39:17 --> Controller Class Initialized
DEBUG - 2022-01-18 06:39:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2022-01-18 06:39:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 06:39:17 --> Final output sent to browser
DEBUG - 2022-01-18 06:39:17 --> Total execution time: 0.0570
INFO - 2022-01-18 06:44:05 --> Config Class Initialized
INFO - 2022-01-18 06:44:05 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:44:05 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:44:05 --> Utf8 Class Initialized
INFO - 2022-01-18 06:44:05 --> URI Class Initialized
INFO - 2022-01-18 06:44:05 --> Router Class Initialized
INFO - 2022-01-18 06:44:05 --> Output Class Initialized
INFO - 2022-01-18 06:44:05 --> Security Class Initialized
DEBUG - 2022-01-18 06:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:44:05 --> Input Class Initialized
INFO - 2022-01-18 06:44:05 --> Language Class Initialized
INFO - 2022-01-18 06:44:05 --> Language Class Initialized
INFO - 2022-01-18 06:44:05 --> Config Class Initialized
INFO - 2022-01-18 06:44:05 --> Loader Class Initialized
INFO - 2022-01-18 06:44:05 --> Helper loaded: url_helper
INFO - 2022-01-18 06:44:05 --> Helper loaded: file_helper
INFO - 2022-01-18 06:44:05 --> Helper loaded: form_helper
INFO - 2022-01-18 06:44:05 --> Helper loaded: my_helper
INFO - 2022-01-18 06:44:05 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:44:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:44:05 --> Controller Class Initialized
INFO - 2022-01-18 06:44:05 --> Final output sent to browser
DEBUG - 2022-01-18 06:44:05 --> Total execution time: 0.0810
INFO - 2022-01-18 06:44:11 --> Config Class Initialized
INFO - 2022-01-18 06:44:11 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:44:11 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:44:11 --> Utf8 Class Initialized
INFO - 2022-01-18 06:44:11 --> URI Class Initialized
INFO - 2022-01-18 06:44:11 --> Router Class Initialized
INFO - 2022-01-18 06:44:11 --> Output Class Initialized
INFO - 2022-01-18 06:44:11 --> Security Class Initialized
DEBUG - 2022-01-18 06:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:44:11 --> Input Class Initialized
INFO - 2022-01-18 06:44:11 --> Language Class Initialized
INFO - 2022-01-18 06:44:11 --> Language Class Initialized
INFO - 2022-01-18 06:44:11 --> Config Class Initialized
INFO - 2022-01-18 06:44:11 --> Loader Class Initialized
INFO - 2022-01-18 06:44:11 --> Helper loaded: url_helper
INFO - 2022-01-18 06:44:11 --> Helper loaded: file_helper
INFO - 2022-01-18 06:44:11 --> Helper loaded: form_helper
INFO - 2022-01-18 06:44:11 --> Helper loaded: my_helper
INFO - 2022-01-18 06:44:11 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:44:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:44:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:44:11 --> Controller Class Initialized
INFO - 2022-01-18 06:44:11 --> Helper loaded: cookie_helper
INFO - 2022-01-18 06:44:11 --> Config Class Initialized
INFO - 2022-01-18 06:44:11 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:44:11 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:44:11 --> Utf8 Class Initialized
INFO - 2022-01-18 06:44:11 --> URI Class Initialized
INFO - 2022-01-18 06:44:11 --> Router Class Initialized
INFO - 2022-01-18 06:44:11 --> Output Class Initialized
INFO - 2022-01-18 06:44:11 --> Security Class Initialized
DEBUG - 2022-01-18 06:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:44:11 --> Input Class Initialized
INFO - 2022-01-18 06:44:11 --> Language Class Initialized
INFO - 2022-01-18 06:44:11 --> Language Class Initialized
INFO - 2022-01-18 06:44:11 --> Config Class Initialized
INFO - 2022-01-18 06:44:11 --> Loader Class Initialized
INFO - 2022-01-18 06:44:11 --> Helper loaded: url_helper
INFO - 2022-01-18 06:44:11 --> Helper loaded: file_helper
INFO - 2022-01-18 06:44:11 --> Helper loaded: form_helper
INFO - 2022-01-18 06:44:11 --> Helper loaded: my_helper
INFO - 2022-01-18 06:44:11 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:44:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:44:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:44:11 --> Controller Class Initialized
DEBUG - 2022-01-18 06:44:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-01-18 06:44:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 06:44:11 --> Final output sent to browser
DEBUG - 2022-01-18 06:44:11 --> Total execution time: 0.0420
INFO - 2022-01-18 06:44:19 --> Config Class Initialized
INFO - 2022-01-18 06:44:19 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:44:19 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:44:19 --> Utf8 Class Initialized
INFO - 2022-01-18 06:44:19 --> URI Class Initialized
INFO - 2022-01-18 06:44:19 --> Router Class Initialized
INFO - 2022-01-18 06:44:19 --> Output Class Initialized
INFO - 2022-01-18 06:44:19 --> Security Class Initialized
DEBUG - 2022-01-18 06:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:44:19 --> Input Class Initialized
INFO - 2022-01-18 06:44:19 --> Language Class Initialized
INFO - 2022-01-18 06:44:19 --> Language Class Initialized
INFO - 2022-01-18 06:44:19 --> Config Class Initialized
INFO - 2022-01-18 06:44:19 --> Loader Class Initialized
INFO - 2022-01-18 06:44:19 --> Helper loaded: url_helper
INFO - 2022-01-18 06:44:19 --> Helper loaded: file_helper
INFO - 2022-01-18 06:44:19 --> Helper loaded: form_helper
INFO - 2022-01-18 06:44:19 --> Helper loaded: my_helper
INFO - 2022-01-18 06:44:19 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:44:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:44:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:44:19 --> Controller Class Initialized
INFO - 2022-01-18 06:44:19 --> Helper loaded: cookie_helper
INFO - 2022-01-18 06:44:19 --> Final output sent to browser
DEBUG - 2022-01-18 06:44:19 --> Total execution time: 0.0536
INFO - 2022-01-18 06:44:19 --> Config Class Initialized
INFO - 2022-01-18 06:44:19 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:44:19 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:44:19 --> Utf8 Class Initialized
INFO - 2022-01-18 06:44:19 --> URI Class Initialized
INFO - 2022-01-18 06:44:19 --> Router Class Initialized
INFO - 2022-01-18 06:44:19 --> Output Class Initialized
INFO - 2022-01-18 06:44:19 --> Security Class Initialized
DEBUG - 2022-01-18 06:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:44:19 --> Input Class Initialized
INFO - 2022-01-18 06:44:19 --> Language Class Initialized
INFO - 2022-01-18 06:44:19 --> Language Class Initialized
INFO - 2022-01-18 06:44:19 --> Config Class Initialized
INFO - 2022-01-18 06:44:19 --> Loader Class Initialized
INFO - 2022-01-18 06:44:19 --> Helper loaded: url_helper
INFO - 2022-01-18 06:44:19 --> Helper loaded: file_helper
INFO - 2022-01-18 06:44:19 --> Helper loaded: form_helper
INFO - 2022-01-18 06:44:19 --> Helper loaded: my_helper
INFO - 2022-01-18 06:44:19 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:44:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:44:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:44:19 --> Controller Class Initialized
DEBUG - 2022-01-18 06:44:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-01-18 06:44:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 06:44:20 --> Final output sent to browser
DEBUG - 2022-01-18 06:44:20 --> Total execution time: 0.2830
INFO - 2022-01-18 06:44:22 --> Config Class Initialized
INFO - 2022-01-18 06:44:22 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:44:22 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:44:22 --> Utf8 Class Initialized
INFO - 2022-01-18 06:44:22 --> URI Class Initialized
INFO - 2022-01-18 06:44:22 --> Router Class Initialized
INFO - 2022-01-18 06:44:22 --> Output Class Initialized
INFO - 2022-01-18 06:44:22 --> Security Class Initialized
DEBUG - 2022-01-18 06:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:44:22 --> Input Class Initialized
INFO - 2022-01-18 06:44:22 --> Language Class Initialized
INFO - 2022-01-18 06:44:22 --> Language Class Initialized
INFO - 2022-01-18 06:44:22 --> Config Class Initialized
INFO - 2022-01-18 06:44:22 --> Loader Class Initialized
INFO - 2022-01-18 06:44:22 --> Helper loaded: url_helper
INFO - 2022-01-18 06:44:22 --> Helper loaded: file_helper
INFO - 2022-01-18 06:44:22 --> Helper loaded: form_helper
INFO - 2022-01-18 06:44:22 --> Helper loaded: my_helper
INFO - 2022-01-18 06:44:22 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:44:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:44:22 --> Controller Class Initialized
DEBUG - 2022-01-18 06:44:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2022-01-18 06:44:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 06:44:22 --> Final output sent to browser
DEBUG - 2022-01-18 06:44:22 --> Total execution time: 0.0590
INFO - 2022-01-18 06:44:22 --> Config Class Initialized
INFO - 2022-01-18 06:44:22 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:44:22 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:44:22 --> Utf8 Class Initialized
INFO - 2022-01-18 06:44:22 --> URI Class Initialized
INFO - 2022-01-18 06:44:22 --> Router Class Initialized
INFO - 2022-01-18 06:44:22 --> Output Class Initialized
INFO - 2022-01-18 06:44:22 --> Security Class Initialized
DEBUG - 2022-01-18 06:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:44:22 --> Input Class Initialized
INFO - 2022-01-18 06:44:22 --> Language Class Initialized
INFO - 2022-01-18 06:44:22 --> Language Class Initialized
INFO - 2022-01-18 06:44:22 --> Config Class Initialized
INFO - 2022-01-18 06:44:22 --> Loader Class Initialized
INFO - 2022-01-18 06:44:22 --> Helper loaded: url_helper
INFO - 2022-01-18 06:44:22 --> Helper loaded: file_helper
INFO - 2022-01-18 06:44:22 --> Helper loaded: form_helper
INFO - 2022-01-18 06:44:22 --> Helper loaded: my_helper
INFO - 2022-01-18 06:44:22 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:44:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:44:22 --> Controller Class Initialized
INFO - 2022-01-18 06:44:25 --> Config Class Initialized
INFO - 2022-01-18 06:44:25 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:44:25 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:44:25 --> Utf8 Class Initialized
INFO - 2022-01-18 06:44:25 --> URI Class Initialized
INFO - 2022-01-18 06:44:25 --> Router Class Initialized
INFO - 2022-01-18 06:44:25 --> Output Class Initialized
INFO - 2022-01-18 06:44:25 --> Security Class Initialized
DEBUG - 2022-01-18 06:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:44:25 --> Input Class Initialized
INFO - 2022-01-18 06:44:25 --> Language Class Initialized
INFO - 2022-01-18 06:44:25 --> Language Class Initialized
INFO - 2022-01-18 06:44:25 --> Config Class Initialized
INFO - 2022-01-18 06:44:25 --> Loader Class Initialized
INFO - 2022-01-18 06:44:25 --> Helper loaded: url_helper
INFO - 2022-01-18 06:44:25 --> Helper loaded: file_helper
INFO - 2022-01-18 06:44:25 --> Helper loaded: form_helper
INFO - 2022-01-18 06:44:25 --> Helper loaded: my_helper
INFO - 2022-01-18 06:44:25 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:44:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:44:25 --> Controller Class Initialized
INFO - 2022-01-18 06:44:25 --> Final output sent to browser
DEBUG - 2022-01-18 06:44:25 --> Total execution time: 0.0616
INFO - 2022-01-18 06:44:25 --> Config Class Initialized
INFO - 2022-01-18 06:44:25 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:44:25 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:44:25 --> Utf8 Class Initialized
INFO - 2022-01-18 06:44:25 --> URI Class Initialized
INFO - 2022-01-18 06:44:25 --> Router Class Initialized
INFO - 2022-01-18 06:44:25 --> Output Class Initialized
INFO - 2022-01-18 06:44:25 --> Security Class Initialized
DEBUG - 2022-01-18 06:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:44:25 --> Input Class Initialized
INFO - 2022-01-18 06:44:25 --> Language Class Initialized
INFO - 2022-01-18 06:44:25 --> Language Class Initialized
INFO - 2022-01-18 06:44:25 --> Config Class Initialized
INFO - 2022-01-18 06:44:25 --> Loader Class Initialized
INFO - 2022-01-18 06:44:25 --> Helper loaded: url_helper
INFO - 2022-01-18 06:44:25 --> Helper loaded: file_helper
INFO - 2022-01-18 06:44:25 --> Helper loaded: form_helper
INFO - 2022-01-18 06:44:25 --> Helper loaded: my_helper
INFO - 2022-01-18 06:44:25 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:44:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:44:25 --> Controller Class Initialized
INFO - 2022-01-18 06:44:28 --> Config Class Initialized
INFO - 2022-01-18 06:44:28 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:44:28 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:44:28 --> Utf8 Class Initialized
INFO - 2022-01-18 06:44:28 --> URI Class Initialized
INFO - 2022-01-18 06:44:28 --> Router Class Initialized
INFO - 2022-01-18 06:44:28 --> Output Class Initialized
INFO - 2022-01-18 06:44:28 --> Security Class Initialized
DEBUG - 2022-01-18 06:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:44:28 --> Input Class Initialized
INFO - 2022-01-18 06:44:28 --> Language Class Initialized
INFO - 2022-01-18 06:44:28 --> Language Class Initialized
INFO - 2022-01-18 06:44:28 --> Config Class Initialized
INFO - 2022-01-18 06:44:28 --> Loader Class Initialized
INFO - 2022-01-18 06:44:28 --> Helper loaded: url_helper
INFO - 2022-01-18 06:44:28 --> Helper loaded: file_helper
INFO - 2022-01-18 06:44:28 --> Helper loaded: form_helper
INFO - 2022-01-18 06:44:28 --> Helper loaded: my_helper
INFO - 2022-01-18 06:44:28 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:44:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:44:28 --> Controller Class Initialized
INFO - 2022-01-18 06:44:28 --> Helper loaded: cookie_helper
INFO - 2022-01-18 06:44:28 --> Config Class Initialized
INFO - 2022-01-18 06:44:28 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:44:28 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:44:28 --> Utf8 Class Initialized
INFO - 2022-01-18 06:44:28 --> URI Class Initialized
INFO - 2022-01-18 06:44:28 --> Router Class Initialized
INFO - 2022-01-18 06:44:28 --> Output Class Initialized
INFO - 2022-01-18 06:44:28 --> Security Class Initialized
DEBUG - 2022-01-18 06:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:44:28 --> Input Class Initialized
INFO - 2022-01-18 06:44:28 --> Language Class Initialized
INFO - 2022-01-18 06:44:28 --> Language Class Initialized
INFO - 2022-01-18 06:44:28 --> Config Class Initialized
INFO - 2022-01-18 06:44:28 --> Loader Class Initialized
INFO - 2022-01-18 06:44:28 --> Helper loaded: url_helper
INFO - 2022-01-18 06:44:28 --> Helper loaded: file_helper
INFO - 2022-01-18 06:44:28 --> Helper loaded: form_helper
INFO - 2022-01-18 06:44:28 --> Helper loaded: my_helper
INFO - 2022-01-18 06:44:28 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:44:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:44:28 --> Controller Class Initialized
DEBUG - 2022-01-18 06:44:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-01-18 06:44:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 06:44:28 --> Final output sent to browser
DEBUG - 2022-01-18 06:44:28 --> Total execution time: 0.0380
INFO - 2022-01-18 06:44:41 --> Config Class Initialized
INFO - 2022-01-18 06:44:41 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:44:41 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:44:41 --> Utf8 Class Initialized
INFO - 2022-01-18 06:44:41 --> URI Class Initialized
INFO - 2022-01-18 06:44:41 --> Router Class Initialized
INFO - 2022-01-18 06:44:41 --> Output Class Initialized
INFO - 2022-01-18 06:44:41 --> Security Class Initialized
DEBUG - 2022-01-18 06:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:44:41 --> Input Class Initialized
INFO - 2022-01-18 06:44:41 --> Language Class Initialized
INFO - 2022-01-18 06:44:41 --> Language Class Initialized
INFO - 2022-01-18 06:44:41 --> Config Class Initialized
INFO - 2022-01-18 06:44:41 --> Loader Class Initialized
INFO - 2022-01-18 06:44:41 --> Helper loaded: url_helper
INFO - 2022-01-18 06:44:41 --> Helper loaded: file_helper
INFO - 2022-01-18 06:44:41 --> Helper loaded: form_helper
INFO - 2022-01-18 06:44:41 --> Helper loaded: my_helper
INFO - 2022-01-18 06:44:41 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:44:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:44:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:44:41 --> Controller Class Initialized
INFO - 2022-01-18 06:44:41 --> Helper loaded: cookie_helper
INFO - 2022-01-18 06:44:41 --> Final output sent to browser
DEBUG - 2022-01-18 06:44:41 --> Total execution time: 0.0682
INFO - 2022-01-18 06:44:42 --> Config Class Initialized
INFO - 2022-01-18 06:44:42 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:44:42 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:44:42 --> Utf8 Class Initialized
INFO - 2022-01-18 06:44:42 --> URI Class Initialized
INFO - 2022-01-18 06:44:42 --> Router Class Initialized
INFO - 2022-01-18 06:44:42 --> Output Class Initialized
INFO - 2022-01-18 06:44:42 --> Security Class Initialized
DEBUG - 2022-01-18 06:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:44:42 --> Input Class Initialized
INFO - 2022-01-18 06:44:42 --> Language Class Initialized
INFO - 2022-01-18 06:44:42 --> Language Class Initialized
INFO - 2022-01-18 06:44:42 --> Config Class Initialized
INFO - 2022-01-18 06:44:42 --> Loader Class Initialized
INFO - 2022-01-18 06:44:42 --> Helper loaded: url_helper
INFO - 2022-01-18 06:44:42 --> Helper loaded: file_helper
INFO - 2022-01-18 06:44:42 --> Helper loaded: form_helper
INFO - 2022-01-18 06:44:42 --> Helper loaded: my_helper
INFO - 2022-01-18 06:44:42 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:44:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:44:42 --> Controller Class Initialized
DEBUG - 2022-01-18 06:44:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-01-18 06:44:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 06:44:42 --> Final output sent to browser
DEBUG - 2022-01-18 06:44:42 --> Total execution time: 0.2700
INFO - 2022-01-18 06:44:44 --> Config Class Initialized
INFO - 2022-01-18 06:44:44 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:44:44 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:44:44 --> Utf8 Class Initialized
INFO - 2022-01-18 06:44:44 --> URI Class Initialized
INFO - 2022-01-18 06:44:44 --> Router Class Initialized
INFO - 2022-01-18 06:44:44 --> Output Class Initialized
INFO - 2022-01-18 06:44:44 --> Security Class Initialized
DEBUG - 2022-01-18 06:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:44:44 --> Input Class Initialized
INFO - 2022-01-18 06:44:44 --> Language Class Initialized
INFO - 2022-01-18 06:44:44 --> Language Class Initialized
INFO - 2022-01-18 06:44:44 --> Config Class Initialized
INFO - 2022-01-18 06:44:44 --> Loader Class Initialized
INFO - 2022-01-18 06:44:44 --> Helper loaded: url_helper
INFO - 2022-01-18 06:44:44 --> Helper loaded: file_helper
INFO - 2022-01-18 06:44:44 --> Helper loaded: form_helper
INFO - 2022-01-18 06:44:44 --> Helper loaded: my_helper
INFO - 2022-01-18 06:44:44 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:44:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:44:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:44:44 --> Controller Class Initialized
DEBUG - 2022-01-18 06:44:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2022-01-18 06:44:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 06:44:44 --> Final output sent to browser
DEBUG - 2022-01-18 06:44:44 --> Total execution time: 0.0660
INFO - 2022-01-18 06:45:09 --> Config Class Initialized
INFO - 2022-01-18 06:45:09 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:45:09 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:45:09 --> Utf8 Class Initialized
INFO - 2022-01-18 06:45:09 --> URI Class Initialized
INFO - 2022-01-18 06:45:09 --> Router Class Initialized
INFO - 2022-01-18 06:45:09 --> Output Class Initialized
INFO - 2022-01-18 06:45:09 --> Security Class Initialized
DEBUG - 2022-01-18 06:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:45:09 --> Input Class Initialized
INFO - 2022-01-18 06:45:09 --> Language Class Initialized
INFO - 2022-01-18 06:45:09 --> Language Class Initialized
INFO - 2022-01-18 06:45:09 --> Config Class Initialized
INFO - 2022-01-18 06:45:09 --> Loader Class Initialized
INFO - 2022-01-18 06:45:09 --> Helper loaded: url_helper
INFO - 2022-01-18 06:45:09 --> Helper loaded: file_helper
INFO - 2022-01-18 06:45:09 --> Helper loaded: form_helper
INFO - 2022-01-18 06:45:09 --> Helper loaded: my_helper
INFO - 2022-01-18 06:45:09 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:45:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:45:09 --> Controller Class Initialized
DEBUG - 2022-01-18 06:45:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-01-18 06:45:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 06:45:09 --> Final output sent to browser
DEBUG - 2022-01-18 06:45:09 --> Total execution time: 0.0490
INFO - 2022-01-18 06:45:11 --> Config Class Initialized
INFO - 2022-01-18 06:45:11 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:45:11 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:45:11 --> Utf8 Class Initialized
INFO - 2022-01-18 06:45:11 --> URI Class Initialized
INFO - 2022-01-18 06:45:11 --> Router Class Initialized
INFO - 2022-01-18 06:45:11 --> Output Class Initialized
INFO - 2022-01-18 06:45:11 --> Security Class Initialized
DEBUG - 2022-01-18 06:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:45:11 --> Input Class Initialized
INFO - 2022-01-18 06:45:11 --> Language Class Initialized
INFO - 2022-01-18 06:45:11 --> Language Class Initialized
INFO - 2022-01-18 06:45:11 --> Config Class Initialized
INFO - 2022-01-18 06:45:11 --> Loader Class Initialized
INFO - 2022-01-18 06:45:11 --> Helper loaded: url_helper
INFO - 2022-01-18 06:45:11 --> Helper loaded: file_helper
INFO - 2022-01-18 06:45:11 --> Helper loaded: form_helper
INFO - 2022-01-18 06:45:11 --> Helper loaded: my_helper
INFO - 2022-01-18 06:45:11 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:45:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:45:11 --> Controller Class Initialized
INFO - 2022-01-18 06:45:11 --> Final output sent to browser
DEBUG - 2022-01-18 06:45:11 --> Total execution time: 0.0576
INFO - 2022-01-18 06:45:17 --> Config Class Initialized
INFO - 2022-01-18 06:45:17 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:45:17 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:45:17 --> Utf8 Class Initialized
INFO - 2022-01-18 06:45:17 --> URI Class Initialized
INFO - 2022-01-18 06:45:17 --> Router Class Initialized
INFO - 2022-01-18 06:45:17 --> Output Class Initialized
INFO - 2022-01-18 06:45:17 --> Security Class Initialized
DEBUG - 2022-01-18 06:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:45:17 --> Input Class Initialized
INFO - 2022-01-18 06:45:17 --> Language Class Initialized
INFO - 2022-01-18 06:45:17 --> Language Class Initialized
INFO - 2022-01-18 06:45:17 --> Config Class Initialized
INFO - 2022-01-18 06:45:17 --> Loader Class Initialized
INFO - 2022-01-18 06:45:17 --> Helper loaded: url_helper
INFO - 2022-01-18 06:45:17 --> Helper loaded: file_helper
INFO - 2022-01-18 06:45:17 --> Helper loaded: form_helper
INFO - 2022-01-18 06:45:17 --> Helper loaded: my_helper
INFO - 2022-01-18 06:45:17 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:45:17 --> Controller Class Initialized
DEBUG - 2022-01-18 06:45:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-01-18 06:45:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 06:45:17 --> Final output sent to browser
DEBUG - 2022-01-18 06:45:17 --> Total execution time: 0.0420
INFO - 2022-01-18 06:45:18 --> Config Class Initialized
INFO - 2022-01-18 06:45:18 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:45:18 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:45:18 --> Utf8 Class Initialized
INFO - 2022-01-18 06:45:18 --> URI Class Initialized
INFO - 2022-01-18 06:45:18 --> Router Class Initialized
INFO - 2022-01-18 06:45:18 --> Output Class Initialized
INFO - 2022-01-18 06:45:18 --> Security Class Initialized
DEBUG - 2022-01-18 06:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:45:18 --> Input Class Initialized
INFO - 2022-01-18 06:45:18 --> Language Class Initialized
INFO - 2022-01-18 06:45:18 --> Language Class Initialized
INFO - 2022-01-18 06:45:18 --> Config Class Initialized
INFO - 2022-01-18 06:45:18 --> Loader Class Initialized
INFO - 2022-01-18 06:45:18 --> Helper loaded: url_helper
INFO - 2022-01-18 06:45:18 --> Helper loaded: file_helper
INFO - 2022-01-18 06:45:18 --> Helper loaded: form_helper
INFO - 2022-01-18 06:45:18 --> Helper loaded: my_helper
INFO - 2022-01-18 06:45:18 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:45:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:45:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:45:18 --> Controller Class Initialized
DEBUG - 2022-01-18 06:45:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2022-01-18 06:45:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 06:45:18 --> Final output sent to browser
DEBUG - 2022-01-18 06:45:18 --> Total execution time: 0.0500
INFO - 2022-01-18 06:47:37 --> Config Class Initialized
INFO - 2022-01-18 06:47:37 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:47:37 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:47:37 --> Utf8 Class Initialized
INFO - 2022-01-18 06:47:37 --> URI Class Initialized
INFO - 2022-01-18 06:47:37 --> Router Class Initialized
INFO - 2022-01-18 06:47:37 --> Output Class Initialized
INFO - 2022-01-18 06:47:37 --> Security Class Initialized
DEBUG - 2022-01-18 06:47:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:47:37 --> Input Class Initialized
INFO - 2022-01-18 06:47:37 --> Language Class Initialized
INFO - 2022-01-18 06:47:37 --> Language Class Initialized
INFO - 2022-01-18 06:47:37 --> Config Class Initialized
INFO - 2022-01-18 06:47:37 --> Loader Class Initialized
INFO - 2022-01-18 06:47:37 --> Helper loaded: url_helper
INFO - 2022-01-18 06:47:37 --> Helper loaded: file_helper
INFO - 2022-01-18 06:47:37 --> Helper loaded: form_helper
INFO - 2022-01-18 06:47:37 --> Helper loaded: my_helper
INFO - 2022-01-18 06:47:37 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:47:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:47:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:47:37 --> Controller Class Initialized
INFO - 2022-01-18 06:47:37 --> Final output sent to browser
DEBUG - 2022-01-18 06:47:37 --> Total execution time: 0.0790
INFO - 2022-01-18 06:48:08 --> Config Class Initialized
INFO - 2022-01-18 06:48:08 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:48:08 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:48:08 --> Utf8 Class Initialized
INFO - 2022-01-18 06:48:08 --> URI Class Initialized
INFO - 2022-01-18 06:48:08 --> Router Class Initialized
INFO - 2022-01-18 06:48:08 --> Output Class Initialized
INFO - 2022-01-18 06:48:08 --> Security Class Initialized
DEBUG - 2022-01-18 06:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:48:08 --> Input Class Initialized
INFO - 2022-01-18 06:48:08 --> Language Class Initialized
INFO - 2022-01-18 06:48:08 --> Language Class Initialized
INFO - 2022-01-18 06:48:08 --> Config Class Initialized
INFO - 2022-01-18 06:48:08 --> Loader Class Initialized
INFO - 2022-01-18 06:48:08 --> Helper loaded: url_helper
INFO - 2022-01-18 06:48:08 --> Helper loaded: file_helper
INFO - 2022-01-18 06:48:08 --> Helper loaded: form_helper
INFO - 2022-01-18 06:48:08 --> Helper loaded: my_helper
INFO - 2022-01-18 06:48:08 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:48:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:48:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:48:08 --> Controller Class Initialized
INFO - 2022-01-18 06:48:08 --> Helper loaded: cookie_helper
INFO - 2022-01-18 06:48:08 --> Config Class Initialized
INFO - 2022-01-18 06:48:08 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:48:08 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:48:08 --> Utf8 Class Initialized
INFO - 2022-01-18 06:48:08 --> URI Class Initialized
INFO - 2022-01-18 06:48:08 --> Router Class Initialized
INFO - 2022-01-18 06:48:08 --> Output Class Initialized
INFO - 2022-01-18 06:48:08 --> Security Class Initialized
DEBUG - 2022-01-18 06:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:48:08 --> Input Class Initialized
INFO - 2022-01-18 06:48:08 --> Language Class Initialized
INFO - 2022-01-18 06:48:08 --> Language Class Initialized
INFO - 2022-01-18 06:48:08 --> Config Class Initialized
INFO - 2022-01-18 06:48:08 --> Loader Class Initialized
INFO - 2022-01-18 06:48:08 --> Helper loaded: url_helper
INFO - 2022-01-18 06:48:08 --> Helper loaded: file_helper
INFO - 2022-01-18 06:48:08 --> Helper loaded: form_helper
INFO - 2022-01-18 06:48:08 --> Helper loaded: my_helper
INFO - 2022-01-18 06:48:08 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:48:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:48:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:48:08 --> Controller Class Initialized
DEBUG - 2022-01-18 06:48:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-01-18 06:48:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 06:48:08 --> Final output sent to browser
DEBUG - 2022-01-18 06:48:08 --> Total execution time: 0.0350
INFO - 2022-01-18 06:48:17 --> Config Class Initialized
INFO - 2022-01-18 06:48:17 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:48:17 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:48:17 --> Utf8 Class Initialized
INFO - 2022-01-18 06:48:17 --> URI Class Initialized
INFO - 2022-01-18 06:48:18 --> Router Class Initialized
INFO - 2022-01-18 06:48:18 --> Output Class Initialized
INFO - 2022-01-18 06:48:18 --> Security Class Initialized
DEBUG - 2022-01-18 06:48:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:48:18 --> Input Class Initialized
INFO - 2022-01-18 06:48:18 --> Language Class Initialized
INFO - 2022-01-18 06:48:18 --> Language Class Initialized
INFO - 2022-01-18 06:48:18 --> Config Class Initialized
INFO - 2022-01-18 06:48:18 --> Loader Class Initialized
INFO - 2022-01-18 06:48:18 --> Helper loaded: url_helper
INFO - 2022-01-18 06:48:18 --> Helper loaded: file_helper
INFO - 2022-01-18 06:48:18 --> Helper loaded: form_helper
INFO - 2022-01-18 06:48:18 --> Helper loaded: my_helper
INFO - 2022-01-18 06:48:18 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:48:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:48:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:48:18 --> Controller Class Initialized
INFO - 2022-01-18 06:48:18 --> Helper loaded: cookie_helper
INFO - 2022-01-18 06:48:18 --> Final output sent to browser
DEBUG - 2022-01-18 06:48:18 --> Total execution time: 0.0486
INFO - 2022-01-18 06:48:19 --> Config Class Initialized
INFO - 2022-01-18 06:48:19 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:48:19 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:48:19 --> Utf8 Class Initialized
INFO - 2022-01-18 06:48:19 --> URI Class Initialized
INFO - 2022-01-18 06:48:19 --> Router Class Initialized
INFO - 2022-01-18 06:48:19 --> Output Class Initialized
INFO - 2022-01-18 06:48:19 --> Security Class Initialized
DEBUG - 2022-01-18 06:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:48:19 --> Input Class Initialized
INFO - 2022-01-18 06:48:19 --> Language Class Initialized
INFO - 2022-01-18 06:48:19 --> Language Class Initialized
INFO - 2022-01-18 06:48:19 --> Config Class Initialized
INFO - 2022-01-18 06:48:19 --> Loader Class Initialized
INFO - 2022-01-18 06:48:19 --> Helper loaded: url_helper
INFO - 2022-01-18 06:48:19 --> Helper loaded: file_helper
INFO - 2022-01-18 06:48:19 --> Helper loaded: form_helper
INFO - 2022-01-18 06:48:19 --> Helper loaded: my_helper
INFO - 2022-01-18 06:48:19 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:48:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:48:19 --> Controller Class Initialized
DEBUG - 2022-01-18 06:48:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-01-18 06:48:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 06:48:19 --> Final output sent to browser
DEBUG - 2022-01-18 06:48:19 --> Total execution time: 0.2860
INFO - 2022-01-18 06:48:29 --> Config Class Initialized
INFO - 2022-01-18 06:48:29 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:48:29 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:48:29 --> Utf8 Class Initialized
INFO - 2022-01-18 06:48:29 --> URI Class Initialized
INFO - 2022-01-18 06:48:29 --> Router Class Initialized
INFO - 2022-01-18 06:48:29 --> Output Class Initialized
INFO - 2022-01-18 06:48:29 --> Security Class Initialized
DEBUG - 2022-01-18 06:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:48:29 --> Input Class Initialized
INFO - 2022-01-18 06:48:29 --> Language Class Initialized
INFO - 2022-01-18 06:48:29 --> Language Class Initialized
INFO - 2022-01-18 06:48:29 --> Config Class Initialized
INFO - 2022-01-18 06:48:29 --> Loader Class Initialized
INFO - 2022-01-18 06:48:29 --> Helper loaded: url_helper
INFO - 2022-01-18 06:48:29 --> Helper loaded: file_helper
INFO - 2022-01-18 06:48:29 --> Helper loaded: form_helper
INFO - 2022-01-18 06:48:29 --> Helper loaded: my_helper
INFO - 2022-01-18 06:48:29 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:48:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:48:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:48:29 --> Controller Class Initialized
DEBUG - 2022-01-18 06:48:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2022-01-18 06:48:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 06:48:29 --> Final output sent to browser
DEBUG - 2022-01-18 06:48:29 --> Total execution time: 0.0430
INFO - 2022-01-18 06:48:29 --> Config Class Initialized
INFO - 2022-01-18 06:48:29 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:48:29 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:48:29 --> Utf8 Class Initialized
INFO - 2022-01-18 06:48:29 --> URI Class Initialized
INFO - 2022-01-18 06:48:29 --> Router Class Initialized
INFO - 2022-01-18 06:48:29 --> Output Class Initialized
INFO - 2022-01-18 06:48:29 --> Security Class Initialized
DEBUG - 2022-01-18 06:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:48:29 --> Input Class Initialized
INFO - 2022-01-18 06:48:29 --> Language Class Initialized
INFO - 2022-01-18 06:48:29 --> Language Class Initialized
INFO - 2022-01-18 06:48:29 --> Config Class Initialized
INFO - 2022-01-18 06:48:29 --> Loader Class Initialized
INFO - 2022-01-18 06:48:29 --> Helper loaded: url_helper
INFO - 2022-01-18 06:48:29 --> Helper loaded: file_helper
INFO - 2022-01-18 06:48:29 --> Helper loaded: form_helper
INFO - 2022-01-18 06:48:29 --> Helper loaded: my_helper
INFO - 2022-01-18 06:48:29 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:48:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:48:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:48:29 --> Controller Class Initialized
INFO - 2022-01-18 06:48:37 --> Config Class Initialized
INFO - 2022-01-18 06:48:37 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:48:37 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:48:37 --> Utf8 Class Initialized
INFO - 2022-01-18 06:48:37 --> URI Class Initialized
INFO - 2022-01-18 06:48:37 --> Router Class Initialized
INFO - 2022-01-18 06:48:37 --> Output Class Initialized
INFO - 2022-01-18 06:48:37 --> Security Class Initialized
DEBUG - 2022-01-18 06:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:48:37 --> Input Class Initialized
INFO - 2022-01-18 06:48:37 --> Language Class Initialized
INFO - 2022-01-18 06:48:37 --> Language Class Initialized
INFO - 2022-01-18 06:48:37 --> Config Class Initialized
INFO - 2022-01-18 06:48:37 --> Loader Class Initialized
INFO - 2022-01-18 06:48:37 --> Helper loaded: url_helper
INFO - 2022-01-18 06:48:37 --> Helper loaded: file_helper
INFO - 2022-01-18 06:48:37 --> Helper loaded: form_helper
INFO - 2022-01-18 06:48:37 --> Helper loaded: my_helper
INFO - 2022-01-18 06:48:37 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:48:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:48:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:48:37 --> Controller Class Initialized
INFO - 2022-01-18 06:48:37 --> Final output sent to browser
DEBUG - 2022-01-18 06:48:37 --> Total execution time: 0.0600
INFO - 2022-01-18 06:48:37 --> Config Class Initialized
INFO - 2022-01-18 06:48:37 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:48:37 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:48:37 --> Utf8 Class Initialized
INFO - 2022-01-18 06:48:37 --> URI Class Initialized
INFO - 2022-01-18 06:48:37 --> Router Class Initialized
INFO - 2022-01-18 06:48:37 --> Output Class Initialized
INFO - 2022-01-18 06:48:37 --> Security Class Initialized
DEBUG - 2022-01-18 06:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:48:37 --> Input Class Initialized
INFO - 2022-01-18 06:48:37 --> Language Class Initialized
INFO - 2022-01-18 06:48:37 --> Language Class Initialized
INFO - 2022-01-18 06:48:37 --> Config Class Initialized
INFO - 2022-01-18 06:48:37 --> Loader Class Initialized
INFO - 2022-01-18 06:48:37 --> Helper loaded: url_helper
INFO - 2022-01-18 06:48:37 --> Helper loaded: file_helper
INFO - 2022-01-18 06:48:37 --> Helper loaded: form_helper
INFO - 2022-01-18 06:48:37 --> Helper loaded: my_helper
INFO - 2022-01-18 06:48:37 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:48:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:48:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:48:37 --> Controller Class Initialized
INFO - 2022-01-18 06:48:40 --> Config Class Initialized
INFO - 2022-01-18 06:48:40 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:48:40 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:48:40 --> Utf8 Class Initialized
INFO - 2022-01-18 06:48:40 --> URI Class Initialized
INFO - 2022-01-18 06:48:40 --> Router Class Initialized
INFO - 2022-01-18 06:48:40 --> Output Class Initialized
INFO - 2022-01-18 06:48:40 --> Security Class Initialized
DEBUG - 2022-01-18 06:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:48:40 --> Input Class Initialized
INFO - 2022-01-18 06:48:40 --> Language Class Initialized
INFO - 2022-01-18 06:48:40 --> Language Class Initialized
INFO - 2022-01-18 06:48:40 --> Config Class Initialized
INFO - 2022-01-18 06:48:40 --> Loader Class Initialized
INFO - 2022-01-18 06:48:40 --> Helper loaded: url_helper
INFO - 2022-01-18 06:48:40 --> Helper loaded: file_helper
INFO - 2022-01-18 06:48:40 --> Helper loaded: form_helper
INFO - 2022-01-18 06:48:40 --> Helper loaded: my_helper
INFO - 2022-01-18 06:48:40 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:48:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:48:40 --> Controller Class Initialized
INFO - 2022-01-18 06:48:40 --> Helper loaded: cookie_helper
INFO - 2022-01-18 06:48:40 --> Config Class Initialized
INFO - 2022-01-18 06:48:40 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:48:40 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:48:40 --> Utf8 Class Initialized
INFO - 2022-01-18 06:48:40 --> URI Class Initialized
INFO - 2022-01-18 06:48:40 --> Router Class Initialized
INFO - 2022-01-18 06:48:40 --> Output Class Initialized
INFO - 2022-01-18 06:48:40 --> Security Class Initialized
DEBUG - 2022-01-18 06:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:48:40 --> Input Class Initialized
INFO - 2022-01-18 06:48:40 --> Language Class Initialized
INFO - 2022-01-18 06:48:40 --> Language Class Initialized
INFO - 2022-01-18 06:48:40 --> Config Class Initialized
INFO - 2022-01-18 06:48:40 --> Loader Class Initialized
INFO - 2022-01-18 06:48:40 --> Helper loaded: url_helper
INFO - 2022-01-18 06:48:40 --> Helper loaded: file_helper
INFO - 2022-01-18 06:48:40 --> Helper loaded: form_helper
INFO - 2022-01-18 06:48:40 --> Helper loaded: my_helper
INFO - 2022-01-18 06:48:40 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:48:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:48:40 --> Controller Class Initialized
DEBUG - 2022-01-18 06:48:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-01-18 06:48:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 06:48:40 --> Final output sent to browser
DEBUG - 2022-01-18 06:48:40 --> Total execution time: 0.0350
INFO - 2022-01-18 06:48:49 --> Config Class Initialized
INFO - 2022-01-18 06:48:49 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:48:49 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:48:49 --> Utf8 Class Initialized
INFO - 2022-01-18 06:48:49 --> URI Class Initialized
INFO - 2022-01-18 06:48:49 --> Router Class Initialized
INFO - 2022-01-18 06:48:49 --> Output Class Initialized
INFO - 2022-01-18 06:48:49 --> Security Class Initialized
DEBUG - 2022-01-18 06:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:48:49 --> Input Class Initialized
INFO - 2022-01-18 06:48:49 --> Language Class Initialized
INFO - 2022-01-18 06:48:49 --> Language Class Initialized
INFO - 2022-01-18 06:48:49 --> Config Class Initialized
INFO - 2022-01-18 06:48:49 --> Loader Class Initialized
INFO - 2022-01-18 06:48:49 --> Helper loaded: url_helper
INFO - 2022-01-18 06:48:49 --> Helper loaded: file_helper
INFO - 2022-01-18 06:48:49 --> Helper loaded: form_helper
INFO - 2022-01-18 06:48:49 --> Helper loaded: my_helper
INFO - 2022-01-18 06:48:49 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:48:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:48:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:48:49 --> Controller Class Initialized
INFO - 2022-01-18 06:48:49 --> Helper loaded: cookie_helper
INFO - 2022-01-18 06:48:49 --> Final output sent to browser
DEBUG - 2022-01-18 06:48:49 --> Total execution time: 0.0566
INFO - 2022-01-18 06:48:50 --> Config Class Initialized
INFO - 2022-01-18 06:48:50 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:48:50 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:48:50 --> Utf8 Class Initialized
INFO - 2022-01-18 06:48:50 --> URI Class Initialized
INFO - 2022-01-18 06:48:50 --> Router Class Initialized
INFO - 2022-01-18 06:48:50 --> Output Class Initialized
INFO - 2022-01-18 06:48:50 --> Security Class Initialized
DEBUG - 2022-01-18 06:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:48:50 --> Input Class Initialized
INFO - 2022-01-18 06:48:50 --> Language Class Initialized
INFO - 2022-01-18 06:48:50 --> Language Class Initialized
INFO - 2022-01-18 06:48:50 --> Config Class Initialized
INFO - 2022-01-18 06:48:50 --> Loader Class Initialized
INFO - 2022-01-18 06:48:50 --> Helper loaded: url_helper
INFO - 2022-01-18 06:48:50 --> Helper loaded: file_helper
INFO - 2022-01-18 06:48:50 --> Helper loaded: form_helper
INFO - 2022-01-18 06:48:50 --> Helper loaded: my_helper
INFO - 2022-01-18 06:48:50 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:48:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:48:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:48:50 --> Controller Class Initialized
DEBUG - 2022-01-18 06:48:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-01-18 06:48:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 06:48:50 --> Final output sent to browser
DEBUG - 2022-01-18 06:48:50 --> Total execution time: 0.2510
INFO - 2022-01-18 06:48:54 --> Config Class Initialized
INFO - 2022-01-18 06:48:54 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:48:54 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:48:54 --> Utf8 Class Initialized
INFO - 2022-01-18 06:48:54 --> URI Class Initialized
INFO - 2022-01-18 06:48:54 --> Router Class Initialized
INFO - 2022-01-18 06:48:54 --> Output Class Initialized
INFO - 2022-01-18 06:48:54 --> Security Class Initialized
DEBUG - 2022-01-18 06:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:48:54 --> Input Class Initialized
INFO - 2022-01-18 06:48:54 --> Language Class Initialized
INFO - 2022-01-18 06:48:54 --> Language Class Initialized
INFO - 2022-01-18 06:48:54 --> Config Class Initialized
INFO - 2022-01-18 06:48:54 --> Loader Class Initialized
INFO - 2022-01-18 06:48:54 --> Helper loaded: url_helper
INFO - 2022-01-18 06:48:54 --> Helper loaded: file_helper
INFO - 2022-01-18 06:48:54 --> Helper loaded: form_helper
INFO - 2022-01-18 06:48:54 --> Helper loaded: my_helper
INFO - 2022-01-18 06:48:54 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:48:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:48:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:48:54 --> Controller Class Initialized
DEBUG - 2022-01-18 06:48:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2022-01-18 06:48:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 06:48:54 --> Final output sent to browser
DEBUG - 2022-01-18 06:48:54 --> Total execution time: 0.1130
INFO - 2022-01-18 06:48:56 --> Config Class Initialized
INFO - 2022-01-18 06:48:56 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:48:56 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:48:56 --> Utf8 Class Initialized
INFO - 2022-01-18 06:48:56 --> URI Class Initialized
INFO - 2022-01-18 06:48:56 --> Router Class Initialized
INFO - 2022-01-18 06:48:56 --> Output Class Initialized
INFO - 2022-01-18 06:48:56 --> Security Class Initialized
DEBUG - 2022-01-18 06:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:48:56 --> Input Class Initialized
INFO - 2022-01-18 06:48:56 --> Language Class Initialized
INFO - 2022-01-18 06:48:56 --> Language Class Initialized
INFO - 2022-01-18 06:48:56 --> Config Class Initialized
INFO - 2022-01-18 06:48:56 --> Loader Class Initialized
INFO - 2022-01-18 06:48:56 --> Helper loaded: url_helper
INFO - 2022-01-18 06:48:56 --> Helper loaded: file_helper
INFO - 2022-01-18 06:48:56 --> Helper loaded: form_helper
INFO - 2022-01-18 06:48:56 --> Helper loaded: my_helper
INFO - 2022-01-18 06:48:56 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:48:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:48:56 --> Controller Class Initialized
DEBUG - 2022-01-18 06:48:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2022-01-18 06:48:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 06:48:56 --> Final output sent to browser
DEBUG - 2022-01-18 06:48:56 --> Total execution time: 0.0480
INFO - 2022-01-18 06:48:59 --> Config Class Initialized
INFO - 2022-01-18 06:48:59 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:48:59 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:48:59 --> Utf8 Class Initialized
INFO - 2022-01-18 06:48:59 --> URI Class Initialized
INFO - 2022-01-18 06:48:59 --> Router Class Initialized
INFO - 2022-01-18 06:48:59 --> Output Class Initialized
INFO - 2022-01-18 06:48:59 --> Security Class Initialized
DEBUG - 2022-01-18 06:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:48:59 --> Input Class Initialized
INFO - 2022-01-18 06:48:59 --> Language Class Initialized
INFO - 2022-01-18 06:48:59 --> Language Class Initialized
INFO - 2022-01-18 06:48:59 --> Config Class Initialized
INFO - 2022-01-18 06:48:59 --> Loader Class Initialized
INFO - 2022-01-18 06:48:59 --> Helper loaded: url_helper
INFO - 2022-01-18 06:48:59 --> Helper loaded: file_helper
INFO - 2022-01-18 06:48:59 --> Helper loaded: form_helper
INFO - 2022-01-18 06:48:59 --> Helper loaded: my_helper
INFO - 2022-01-18 06:48:59 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:48:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:48:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:48:59 --> Controller Class Initialized
DEBUG - 2022-01-18 06:48:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2022-01-18 06:48:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 06:48:59 --> Final output sent to browser
DEBUG - 2022-01-18 06:48:59 --> Total execution time: 0.0700
INFO - 2022-01-18 06:49:01 --> Config Class Initialized
INFO - 2022-01-18 06:49:01 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:49:01 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:49:01 --> Utf8 Class Initialized
INFO - 2022-01-18 06:49:01 --> URI Class Initialized
INFO - 2022-01-18 06:49:01 --> Router Class Initialized
INFO - 2022-01-18 06:49:01 --> Output Class Initialized
INFO - 2022-01-18 06:49:01 --> Security Class Initialized
DEBUG - 2022-01-18 06:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:49:01 --> Input Class Initialized
INFO - 2022-01-18 06:49:01 --> Language Class Initialized
INFO - 2022-01-18 06:49:01 --> Language Class Initialized
INFO - 2022-01-18 06:49:01 --> Config Class Initialized
INFO - 2022-01-18 06:49:01 --> Loader Class Initialized
INFO - 2022-01-18 06:49:01 --> Helper loaded: url_helper
INFO - 2022-01-18 06:49:01 --> Helper loaded: file_helper
INFO - 2022-01-18 06:49:01 --> Helper loaded: form_helper
INFO - 2022-01-18 06:49:01 --> Helper loaded: my_helper
INFO - 2022-01-18 06:49:01 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:49:01 --> Controller Class Initialized
DEBUG - 2022-01-18 06:49:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2022-01-18 06:49:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 06:49:01 --> Final output sent to browser
DEBUG - 2022-01-18 06:49:01 --> Total execution time: 0.0710
INFO - 2022-01-18 06:49:06 --> Config Class Initialized
INFO - 2022-01-18 06:49:06 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:49:06 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:49:06 --> Utf8 Class Initialized
INFO - 2022-01-18 06:49:06 --> URI Class Initialized
INFO - 2022-01-18 06:49:06 --> Router Class Initialized
INFO - 2022-01-18 06:49:06 --> Output Class Initialized
INFO - 2022-01-18 06:49:06 --> Security Class Initialized
DEBUG - 2022-01-18 06:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:49:06 --> Input Class Initialized
INFO - 2022-01-18 06:49:06 --> Language Class Initialized
INFO - 2022-01-18 06:49:06 --> Language Class Initialized
INFO - 2022-01-18 06:49:06 --> Config Class Initialized
INFO - 2022-01-18 06:49:06 --> Loader Class Initialized
INFO - 2022-01-18 06:49:06 --> Helper loaded: url_helper
INFO - 2022-01-18 06:49:06 --> Helper loaded: file_helper
INFO - 2022-01-18 06:49:06 --> Helper loaded: form_helper
INFO - 2022-01-18 06:49:06 --> Helper loaded: my_helper
INFO - 2022-01-18 06:49:06 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:49:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:49:06 --> Controller Class Initialized
DEBUG - 2022-01-18 06:49:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2022-01-18 06:49:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 06:49:06 --> Final output sent to browser
DEBUG - 2022-01-18 06:49:06 --> Total execution time: 0.0560
INFO - 2022-01-18 06:52:39 --> Config Class Initialized
INFO - 2022-01-18 06:52:39 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:52:39 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:52:39 --> Utf8 Class Initialized
INFO - 2022-01-18 06:52:39 --> URI Class Initialized
INFO - 2022-01-18 06:52:39 --> Router Class Initialized
INFO - 2022-01-18 06:52:39 --> Output Class Initialized
INFO - 2022-01-18 06:52:39 --> Security Class Initialized
DEBUG - 2022-01-18 06:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:52:39 --> Input Class Initialized
INFO - 2022-01-18 06:52:39 --> Language Class Initialized
INFO - 2022-01-18 06:52:39 --> Language Class Initialized
INFO - 2022-01-18 06:52:39 --> Config Class Initialized
INFO - 2022-01-18 06:52:39 --> Loader Class Initialized
INFO - 2022-01-18 06:52:39 --> Helper loaded: url_helper
INFO - 2022-01-18 06:52:39 --> Helper loaded: file_helper
INFO - 2022-01-18 06:52:39 --> Helper loaded: form_helper
INFO - 2022-01-18 06:52:39 --> Helper loaded: my_helper
INFO - 2022-01-18 06:52:39 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:52:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:52:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:52:39 --> Controller Class Initialized
INFO - 2022-01-18 06:52:39 --> Final output sent to browser
DEBUG - 2022-01-18 06:52:39 --> Total execution time: 0.0800
INFO - 2022-01-18 06:52:48 --> Config Class Initialized
INFO - 2022-01-18 06:52:48 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:52:48 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:52:48 --> Utf8 Class Initialized
INFO - 2022-01-18 06:52:48 --> URI Class Initialized
INFO - 2022-01-18 06:52:48 --> Router Class Initialized
INFO - 2022-01-18 06:52:48 --> Output Class Initialized
INFO - 2022-01-18 06:52:48 --> Security Class Initialized
DEBUG - 2022-01-18 06:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:52:48 --> Input Class Initialized
INFO - 2022-01-18 06:52:48 --> Language Class Initialized
INFO - 2022-01-18 06:52:48 --> Language Class Initialized
INFO - 2022-01-18 06:52:48 --> Config Class Initialized
INFO - 2022-01-18 06:52:48 --> Loader Class Initialized
INFO - 2022-01-18 06:52:48 --> Helper loaded: url_helper
INFO - 2022-01-18 06:52:48 --> Helper loaded: file_helper
INFO - 2022-01-18 06:52:48 --> Helper loaded: form_helper
INFO - 2022-01-18 06:52:48 --> Helper loaded: my_helper
INFO - 2022-01-18 06:52:48 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:52:48 --> Controller Class Initialized
INFO - 2022-01-18 06:52:48 --> Helper loaded: cookie_helper
INFO - 2022-01-18 06:52:48 --> Config Class Initialized
INFO - 2022-01-18 06:52:48 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:52:48 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:52:48 --> Utf8 Class Initialized
INFO - 2022-01-18 06:52:48 --> URI Class Initialized
INFO - 2022-01-18 06:52:48 --> Router Class Initialized
INFO - 2022-01-18 06:52:48 --> Output Class Initialized
INFO - 2022-01-18 06:52:48 --> Security Class Initialized
DEBUG - 2022-01-18 06:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:52:48 --> Input Class Initialized
INFO - 2022-01-18 06:52:48 --> Language Class Initialized
INFO - 2022-01-18 06:52:48 --> Language Class Initialized
INFO - 2022-01-18 06:52:48 --> Config Class Initialized
INFO - 2022-01-18 06:52:48 --> Loader Class Initialized
INFO - 2022-01-18 06:52:48 --> Helper loaded: url_helper
INFO - 2022-01-18 06:52:48 --> Helper loaded: file_helper
INFO - 2022-01-18 06:52:48 --> Helper loaded: form_helper
INFO - 2022-01-18 06:52:48 --> Helper loaded: my_helper
INFO - 2022-01-18 06:52:48 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:52:48 --> Controller Class Initialized
DEBUG - 2022-01-18 06:52:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-01-18 06:52:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 06:52:48 --> Final output sent to browser
DEBUG - 2022-01-18 06:52:48 --> Total execution time: 0.0380
INFO - 2022-01-18 06:52:59 --> Config Class Initialized
INFO - 2022-01-18 06:52:59 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:52:59 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:52:59 --> Utf8 Class Initialized
INFO - 2022-01-18 06:52:59 --> URI Class Initialized
INFO - 2022-01-18 06:52:59 --> Router Class Initialized
INFO - 2022-01-18 06:52:59 --> Output Class Initialized
INFO - 2022-01-18 06:52:59 --> Security Class Initialized
DEBUG - 2022-01-18 06:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:52:59 --> Input Class Initialized
INFO - 2022-01-18 06:52:59 --> Language Class Initialized
INFO - 2022-01-18 06:52:59 --> Language Class Initialized
INFO - 2022-01-18 06:52:59 --> Config Class Initialized
INFO - 2022-01-18 06:52:59 --> Loader Class Initialized
INFO - 2022-01-18 06:52:59 --> Helper loaded: url_helper
INFO - 2022-01-18 06:52:59 --> Helper loaded: file_helper
INFO - 2022-01-18 06:52:59 --> Helper loaded: form_helper
INFO - 2022-01-18 06:52:59 --> Helper loaded: my_helper
INFO - 2022-01-18 06:52:59 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:52:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:52:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:52:59 --> Controller Class Initialized
INFO - 2022-01-18 06:52:59 --> Helper loaded: cookie_helper
INFO - 2022-01-18 06:52:59 --> Final output sent to browser
DEBUG - 2022-01-18 06:52:59 --> Total execution time: 0.0470
INFO - 2022-01-18 06:53:02 --> Config Class Initialized
INFO - 2022-01-18 06:53:02 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:53:02 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:53:02 --> Utf8 Class Initialized
INFO - 2022-01-18 06:53:02 --> URI Class Initialized
INFO - 2022-01-18 06:53:02 --> Router Class Initialized
INFO - 2022-01-18 06:53:02 --> Output Class Initialized
INFO - 2022-01-18 06:53:02 --> Security Class Initialized
DEBUG - 2022-01-18 06:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:53:02 --> Input Class Initialized
INFO - 2022-01-18 06:53:02 --> Language Class Initialized
INFO - 2022-01-18 06:53:02 --> Language Class Initialized
INFO - 2022-01-18 06:53:02 --> Config Class Initialized
INFO - 2022-01-18 06:53:02 --> Loader Class Initialized
INFO - 2022-01-18 06:53:02 --> Helper loaded: url_helper
INFO - 2022-01-18 06:53:02 --> Helper loaded: file_helper
INFO - 2022-01-18 06:53:02 --> Helper loaded: form_helper
INFO - 2022-01-18 06:53:02 --> Helper loaded: my_helper
INFO - 2022-01-18 06:53:02 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:53:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:53:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:53:02 --> Controller Class Initialized
DEBUG - 2022-01-18 06:53:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-01-18 06:53:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 06:53:02 --> Final output sent to browser
DEBUG - 2022-01-18 06:53:02 --> Total execution time: 0.3670
INFO - 2022-01-18 06:53:04 --> Config Class Initialized
INFO - 2022-01-18 06:53:04 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:53:04 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:53:04 --> Utf8 Class Initialized
INFO - 2022-01-18 06:53:04 --> URI Class Initialized
INFO - 2022-01-18 06:53:04 --> Router Class Initialized
INFO - 2022-01-18 06:53:04 --> Output Class Initialized
INFO - 2022-01-18 06:53:04 --> Security Class Initialized
DEBUG - 2022-01-18 06:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:53:04 --> Input Class Initialized
INFO - 2022-01-18 06:53:04 --> Language Class Initialized
INFO - 2022-01-18 06:53:04 --> Language Class Initialized
INFO - 2022-01-18 06:53:04 --> Config Class Initialized
INFO - 2022-01-18 06:53:04 --> Loader Class Initialized
INFO - 2022-01-18 06:53:04 --> Helper loaded: url_helper
INFO - 2022-01-18 06:53:04 --> Helper loaded: file_helper
INFO - 2022-01-18 06:53:04 --> Helper loaded: form_helper
INFO - 2022-01-18 06:53:04 --> Helper loaded: my_helper
INFO - 2022-01-18 06:53:04 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:53:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:53:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:53:04 --> Controller Class Initialized
DEBUG - 2022-01-18 06:53:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2022-01-18 06:53:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 06:53:04 --> Final output sent to browser
DEBUG - 2022-01-18 06:53:04 --> Total execution time: 0.0450
INFO - 2022-01-18 06:53:04 --> Config Class Initialized
INFO - 2022-01-18 06:53:04 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:53:04 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:53:04 --> Utf8 Class Initialized
INFO - 2022-01-18 06:53:04 --> URI Class Initialized
INFO - 2022-01-18 06:53:04 --> Router Class Initialized
INFO - 2022-01-18 06:53:04 --> Output Class Initialized
INFO - 2022-01-18 06:53:04 --> Security Class Initialized
DEBUG - 2022-01-18 06:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:53:04 --> Input Class Initialized
INFO - 2022-01-18 06:53:04 --> Language Class Initialized
INFO - 2022-01-18 06:53:04 --> Language Class Initialized
INFO - 2022-01-18 06:53:04 --> Config Class Initialized
INFO - 2022-01-18 06:53:04 --> Loader Class Initialized
INFO - 2022-01-18 06:53:04 --> Helper loaded: url_helper
INFO - 2022-01-18 06:53:04 --> Helper loaded: file_helper
INFO - 2022-01-18 06:53:04 --> Helper loaded: form_helper
INFO - 2022-01-18 06:53:04 --> Helper loaded: my_helper
INFO - 2022-01-18 06:53:04 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:53:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:53:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:53:04 --> Controller Class Initialized
INFO - 2022-01-18 06:53:06 --> Config Class Initialized
INFO - 2022-01-18 06:53:06 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:53:06 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:53:06 --> Utf8 Class Initialized
INFO - 2022-01-18 06:53:06 --> URI Class Initialized
INFO - 2022-01-18 06:53:06 --> Router Class Initialized
INFO - 2022-01-18 06:53:06 --> Output Class Initialized
INFO - 2022-01-18 06:53:06 --> Security Class Initialized
DEBUG - 2022-01-18 06:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:53:06 --> Input Class Initialized
INFO - 2022-01-18 06:53:06 --> Language Class Initialized
INFO - 2022-01-18 06:53:06 --> Language Class Initialized
INFO - 2022-01-18 06:53:06 --> Config Class Initialized
INFO - 2022-01-18 06:53:06 --> Loader Class Initialized
INFO - 2022-01-18 06:53:06 --> Helper loaded: url_helper
INFO - 2022-01-18 06:53:06 --> Helper loaded: file_helper
INFO - 2022-01-18 06:53:06 --> Helper loaded: form_helper
INFO - 2022-01-18 06:53:06 --> Helper loaded: my_helper
INFO - 2022-01-18 06:53:06 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:53:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:53:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:53:06 --> Controller Class Initialized
INFO - 2022-01-18 06:53:06 --> Final output sent to browser
DEBUG - 2022-01-18 06:53:06 --> Total execution time: 0.0570
INFO - 2022-01-18 06:53:06 --> Config Class Initialized
INFO - 2022-01-18 06:53:06 --> Hooks Class Initialized
DEBUG - 2022-01-18 06:53:06 --> UTF-8 Support Enabled
INFO - 2022-01-18 06:53:06 --> Utf8 Class Initialized
INFO - 2022-01-18 06:53:06 --> URI Class Initialized
INFO - 2022-01-18 06:53:06 --> Router Class Initialized
INFO - 2022-01-18 06:53:06 --> Output Class Initialized
INFO - 2022-01-18 06:53:06 --> Security Class Initialized
DEBUG - 2022-01-18 06:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 06:53:06 --> Input Class Initialized
INFO - 2022-01-18 06:53:06 --> Language Class Initialized
INFO - 2022-01-18 06:53:06 --> Language Class Initialized
INFO - 2022-01-18 06:53:06 --> Config Class Initialized
INFO - 2022-01-18 06:53:06 --> Loader Class Initialized
INFO - 2022-01-18 06:53:06 --> Helper loaded: url_helper
INFO - 2022-01-18 06:53:06 --> Helper loaded: file_helper
INFO - 2022-01-18 06:53:06 --> Helper loaded: form_helper
INFO - 2022-01-18 06:53:06 --> Helper loaded: my_helper
INFO - 2022-01-18 06:53:06 --> Database Driver Class Initialized
DEBUG - 2022-01-18 06:53:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 06:53:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 06:53:06 --> Controller Class Initialized
INFO - 2022-01-18 09:38:53 --> Config Class Initialized
INFO - 2022-01-18 09:38:53 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:38:53 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:38:53 --> Utf8 Class Initialized
INFO - 2022-01-18 09:38:53 --> URI Class Initialized
INFO - 2022-01-18 09:38:53 --> Router Class Initialized
INFO - 2022-01-18 09:38:53 --> Output Class Initialized
INFO - 2022-01-18 09:38:53 --> Security Class Initialized
DEBUG - 2022-01-18 09:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:38:53 --> Input Class Initialized
INFO - 2022-01-18 09:38:53 --> Language Class Initialized
INFO - 2022-01-18 09:38:53 --> Language Class Initialized
INFO - 2022-01-18 09:38:53 --> Config Class Initialized
INFO - 2022-01-18 09:38:53 --> Loader Class Initialized
INFO - 2022-01-18 09:38:53 --> Helper loaded: url_helper
INFO - 2022-01-18 09:38:53 --> Helper loaded: file_helper
INFO - 2022-01-18 09:38:53 --> Helper loaded: form_helper
INFO - 2022-01-18 09:38:53 --> Helper loaded: my_helper
INFO - 2022-01-18 09:38:53 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:38:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:38:53 --> Controller Class Initialized
INFO - 2022-01-18 09:38:53 --> Final output sent to browser
DEBUG - 2022-01-18 09:38:53 --> Total execution time: 0.0470
INFO - 2022-01-18 09:38:53 --> Config Class Initialized
INFO - 2022-01-18 09:38:53 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:38:53 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:38:53 --> Utf8 Class Initialized
INFO - 2022-01-18 09:38:53 --> URI Class Initialized
INFO - 2022-01-18 09:38:53 --> Router Class Initialized
INFO - 2022-01-18 09:38:53 --> Output Class Initialized
INFO - 2022-01-18 09:38:53 --> Security Class Initialized
DEBUG - 2022-01-18 09:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:38:53 --> Input Class Initialized
INFO - 2022-01-18 09:38:53 --> Language Class Initialized
INFO - 2022-01-18 09:38:53 --> Language Class Initialized
INFO - 2022-01-18 09:38:53 --> Config Class Initialized
INFO - 2022-01-18 09:38:53 --> Loader Class Initialized
INFO - 2022-01-18 09:38:53 --> Helper loaded: url_helper
INFO - 2022-01-18 09:38:53 --> Helper loaded: file_helper
INFO - 2022-01-18 09:38:53 --> Helper loaded: form_helper
INFO - 2022-01-18 09:38:53 --> Helper loaded: my_helper
INFO - 2022-01-18 09:38:53 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:38:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:38:53 --> Controller Class Initialized
INFO - 2022-01-18 09:38:59 --> Config Class Initialized
INFO - 2022-01-18 09:38:59 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:38:59 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:38:59 --> Utf8 Class Initialized
INFO - 2022-01-18 09:38:59 --> URI Class Initialized
INFO - 2022-01-18 09:38:59 --> Router Class Initialized
INFO - 2022-01-18 09:38:59 --> Output Class Initialized
INFO - 2022-01-18 09:38:59 --> Security Class Initialized
DEBUG - 2022-01-18 09:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:38:59 --> Input Class Initialized
INFO - 2022-01-18 09:38:59 --> Language Class Initialized
INFO - 2022-01-18 09:38:59 --> Language Class Initialized
INFO - 2022-01-18 09:38:59 --> Config Class Initialized
INFO - 2022-01-18 09:38:59 --> Loader Class Initialized
INFO - 2022-01-18 09:38:59 --> Helper loaded: url_helper
INFO - 2022-01-18 09:38:59 --> Helper loaded: file_helper
INFO - 2022-01-18 09:38:59 --> Helper loaded: form_helper
INFO - 2022-01-18 09:38:59 --> Helper loaded: my_helper
INFO - 2022-01-18 09:38:59 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:38:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:38:59 --> Controller Class Initialized
INFO - 2022-01-18 09:38:59 --> Helper loaded: cookie_helper
INFO - 2022-01-18 09:38:59 --> Config Class Initialized
INFO - 2022-01-18 09:38:59 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:38:59 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:38:59 --> Utf8 Class Initialized
INFO - 2022-01-18 09:38:59 --> URI Class Initialized
INFO - 2022-01-18 09:38:59 --> Router Class Initialized
INFO - 2022-01-18 09:38:59 --> Output Class Initialized
INFO - 2022-01-18 09:38:59 --> Security Class Initialized
DEBUG - 2022-01-18 09:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:38:59 --> Input Class Initialized
INFO - 2022-01-18 09:38:59 --> Language Class Initialized
INFO - 2022-01-18 09:38:59 --> Language Class Initialized
INFO - 2022-01-18 09:38:59 --> Config Class Initialized
INFO - 2022-01-18 09:38:59 --> Loader Class Initialized
INFO - 2022-01-18 09:38:59 --> Helper loaded: url_helper
INFO - 2022-01-18 09:38:59 --> Helper loaded: file_helper
INFO - 2022-01-18 09:38:59 --> Helper loaded: form_helper
INFO - 2022-01-18 09:38:59 --> Helper loaded: my_helper
INFO - 2022-01-18 09:38:59 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:38:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:38:59 --> Controller Class Initialized
DEBUG - 2022-01-18 09:38:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-01-18 09:38:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:38:59 --> Final output sent to browser
DEBUG - 2022-01-18 09:38:59 --> Total execution time: 0.0370
INFO - 2022-01-18 09:39:07 --> Config Class Initialized
INFO - 2022-01-18 09:39:07 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:39:07 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:39:07 --> Utf8 Class Initialized
INFO - 2022-01-18 09:39:07 --> URI Class Initialized
INFO - 2022-01-18 09:39:07 --> Router Class Initialized
INFO - 2022-01-18 09:39:07 --> Output Class Initialized
INFO - 2022-01-18 09:39:07 --> Security Class Initialized
DEBUG - 2022-01-18 09:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:39:07 --> Input Class Initialized
INFO - 2022-01-18 09:39:07 --> Language Class Initialized
INFO - 2022-01-18 09:39:07 --> Language Class Initialized
INFO - 2022-01-18 09:39:07 --> Config Class Initialized
INFO - 2022-01-18 09:39:07 --> Loader Class Initialized
INFO - 2022-01-18 09:39:07 --> Helper loaded: url_helper
INFO - 2022-01-18 09:39:07 --> Helper loaded: file_helper
INFO - 2022-01-18 09:39:07 --> Helper loaded: form_helper
INFO - 2022-01-18 09:39:07 --> Helper loaded: my_helper
INFO - 2022-01-18 09:39:07 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:39:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:39:07 --> Controller Class Initialized
INFO - 2022-01-18 09:39:07 --> Helper loaded: cookie_helper
INFO - 2022-01-18 09:39:07 --> Final output sent to browser
DEBUG - 2022-01-18 09:39:07 --> Total execution time: 0.0602
INFO - 2022-01-18 09:39:07 --> Config Class Initialized
INFO - 2022-01-18 09:39:07 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:39:07 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:39:07 --> Utf8 Class Initialized
INFO - 2022-01-18 09:39:07 --> URI Class Initialized
INFO - 2022-01-18 09:39:07 --> Router Class Initialized
INFO - 2022-01-18 09:39:07 --> Output Class Initialized
INFO - 2022-01-18 09:39:07 --> Security Class Initialized
DEBUG - 2022-01-18 09:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:39:07 --> Input Class Initialized
INFO - 2022-01-18 09:39:07 --> Language Class Initialized
INFO - 2022-01-18 09:39:07 --> Language Class Initialized
INFO - 2022-01-18 09:39:07 --> Config Class Initialized
INFO - 2022-01-18 09:39:07 --> Loader Class Initialized
INFO - 2022-01-18 09:39:07 --> Helper loaded: url_helper
INFO - 2022-01-18 09:39:07 --> Helper loaded: file_helper
INFO - 2022-01-18 09:39:07 --> Helper loaded: form_helper
INFO - 2022-01-18 09:39:07 --> Helper loaded: my_helper
INFO - 2022-01-18 09:39:07 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:39:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:39:07 --> Controller Class Initialized
DEBUG - 2022-01-18 09:39:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-01-18 09:39:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:39:08 --> Final output sent to browser
DEBUG - 2022-01-18 09:39:08 --> Total execution time: 0.7570
INFO - 2022-01-18 09:39:11 --> Config Class Initialized
INFO - 2022-01-18 09:39:11 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:39:11 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:39:11 --> Utf8 Class Initialized
INFO - 2022-01-18 09:39:11 --> URI Class Initialized
INFO - 2022-01-18 09:39:11 --> Router Class Initialized
INFO - 2022-01-18 09:39:11 --> Output Class Initialized
INFO - 2022-01-18 09:39:11 --> Security Class Initialized
DEBUG - 2022-01-18 09:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:39:11 --> Input Class Initialized
INFO - 2022-01-18 09:39:11 --> Language Class Initialized
INFO - 2022-01-18 09:39:11 --> Language Class Initialized
INFO - 2022-01-18 09:39:11 --> Config Class Initialized
INFO - 2022-01-18 09:39:11 --> Loader Class Initialized
INFO - 2022-01-18 09:39:11 --> Helper loaded: url_helper
INFO - 2022-01-18 09:39:11 --> Helper loaded: file_helper
INFO - 2022-01-18 09:39:11 --> Helper loaded: form_helper
INFO - 2022-01-18 09:39:11 --> Helper loaded: my_helper
INFO - 2022-01-18 09:39:11 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:39:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:39:11 --> Controller Class Initialized
DEBUG - 2022-01-18 09:39:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2022-01-18 09:39:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:39:11 --> Final output sent to browser
DEBUG - 2022-01-18 09:39:11 --> Total execution time: 0.0810
INFO - 2022-01-18 09:43:18 --> Config Class Initialized
INFO - 2022-01-18 09:43:18 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:43:18 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:43:18 --> Utf8 Class Initialized
INFO - 2022-01-18 09:43:18 --> URI Class Initialized
INFO - 2022-01-18 09:43:18 --> Router Class Initialized
INFO - 2022-01-18 09:43:18 --> Output Class Initialized
INFO - 2022-01-18 09:43:18 --> Security Class Initialized
DEBUG - 2022-01-18 09:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:43:18 --> Input Class Initialized
INFO - 2022-01-18 09:43:18 --> Language Class Initialized
INFO - 2022-01-18 09:43:18 --> Language Class Initialized
INFO - 2022-01-18 09:43:18 --> Config Class Initialized
INFO - 2022-01-18 09:43:18 --> Loader Class Initialized
INFO - 2022-01-18 09:43:18 --> Helper loaded: url_helper
INFO - 2022-01-18 09:43:18 --> Helper loaded: file_helper
INFO - 2022-01-18 09:43:18 --> Helper loaded: form_helper
INFO - 2022-01-18 09:43:18 --> Helper loaded: my_helper
INFO - 2022-01-18 09:43:18 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:43:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:43:18 --> Controller Class Initialized
DEBUG - 2022-01-18 09:43:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-01-18 09:43:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:43:18 --> Final output sent to browser
DEBUG - 2022-01-18 09:43:18 --> Total execution time: 0.0420
INFO - 2022-01-18 09:43:20 --> Config Class Initialized
INFO - 2022-01-18 09:43:20 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:43:20 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:43:20 --> Utf8 Class Initialized
INFO - 2022-01-18 09:43:20 --> URI Class Initialized
INFO - 2022-01-18 09:43:20 --> Router Class Initialized
INFO - 2022-01-18 09:43:20 --> Output Class Initialized
INFO - 2022-01-18 09:43:20 --> Security Class Initialized
DEBUG - 2022-01-18 09:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:43:20 --> Input Class Initialized
INFO - 2022-01-18 09:43:20 --> Language Class Initialized
INFO - 2022-01-18 09:43:20 --> Language Class Initialized
INFO - 2022-01-18 09:43:20 --> Config Class Initialized
INFO - 2022-01-18 09:43:20 --> Loader Class Initialized
INFO - 2022-01-18 09:43:20 --> Helper loaded: url_helper
INFO - 2022-01-18 09:43:20 --> Helper loaded: file_helper
INFO - 2022-01-18 09:43:20 --> Helper loaded: form_helper
INFO - 2022-01-18 09:43:20 --> Helper loaded: my_helper
INFO - 2022-01-18 09:43:20 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:43:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:43:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:43:20 --> Controller Class Initialized
INFO - 2022-01-18 09:43:20 --> Final output sent to browser
DEBUG - 2022-01-18 09:43:20 --> Total execution time: 0.0572
INFO - 2022-01-18 09:43:51 --> Config Class Initialized
INFO - 2022-01-18 09:43:51 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:43:51 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:43:51 --> Utf8 Class Initialized
INFO - 2022-01-18 09:43:51 --> URI Class Initialized
INFO - 2022-01-18 09:43:51 --> Router Class Initialized
INFO - 2022-01-18 09:43:51 --> Output Class Initialized
INFO - 2022-01-18 09:43:51 --> Security Class Initialized
DEBUG - 2022-01-18 09:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:43:51 --> Input Class Initialized
INFO - 2022-01-18 09:43:51 --> Language Class Initialized
INFO - 2022-01-18 09:43:51 --> Language Class Initialized
INFO - 2022-01-18 09:43:51 --> Config Class Initialized
INFO - 2022-01-18 09:43:51 --> Loader Class Initialized
INFO - 2022-01-18 09:43:51 --> Helper loaded: url_helper
INFO - 2022-01-18 09:43:51 --> Helper loaded: file_helper
INFO - 2022-01-18 09:43:51 --> Helper loaded: form_helper
INFO - 2022-01-18 09:43:51 --> Helper loaded: my_helper
INFO - 2022-01-18 09:43:51 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:43:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:43:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:43:51 --> Controller Class Initialized
INFO - 2022-01-18 09:43:51 --> Final output sent to browser
DEBUG - 2022-01-18 09:43:51 --> Total execution time: 0.1050
INFO - 2022-01-18 09:43:54 --> Config Class Initialized
INFO - 2022-01-18 09:43:54 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:43:54 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:43:54 --> Utf8 Class Initialized
INFO - 2022-01-18 09:43:54 --> URI Class Initialized
INFO - 2022-01-18 09:43:54 --> Router Class Initialized
INFO - 2022-01-18 09:43:54 --> Output Class Initialized
INFO - 2022-01-18 09:43:54 --> Security Class Initialized
DEBUG - 2022-01-18 09:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:43:54 --> Input Class Initialized
INFO - 2022-01-18 09:43:54 --> Language Class Initialized
INFO - 2022-01-18 09:43:54 --> Language Class Initialized
INFO - 2022-01-18 09:43:54 --> Config Class Initialized
INFO - 2022-01-18 09:43:54 --> Loader Class Initialized
INFO - 2022-01-18 09:43:54 --> Helper loaded: url_helper
INFO - 2022-01-18 09:43:54 --> Helper loaded: file_helper
INFO - 2022-01-18 09:43:54 --> Helper loaded: form_helper
INFO - 2022-01-18 09:43:54 --> Helper loaded: my_helper
INFO - 2022-01-18 09:43:54 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:43:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:43:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:43:54 --> Controller Class Initialized
DEBUG - 2022-01-18 09:43:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2022-01-18 09:43:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:43:54 --> Final output sent to browser
DEBUG - 2022-01-18 09:43:54 --> Total execution time: 0.0690
INFO - 2022-01-18 09:43:56 --> Config Class Initialized
INFO - 2022-01-18 09:43:56 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:43:56 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:43:56 --> Utf8 Class Initialized
INFO - 2022-01-18 09:43:56 --> URI Class Initialized
INFO - 2022-01-18 09:43:56 --> Router Class Initialized
INFO - 2022-01-18 09:43:56 --> Output Class Initialized
INFO - 2022-01-18 09:43:56 --> Security Class Initialized
DEBUG - 2022-01-18 09:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:43:56 --> Input Class Initialized
INFO - 2022-01-18 09:43:56 --> Language Class Initialized
INFO - 2022-01-18 09:43:56 --> Language Class Initialized
INFO - 2022-01-18 09:43:56 --> Config Class Initialized
INFO - 2022-01-18 09:43:56 --> Loader Class Initialized
INFO - 2022-01-18 09:43:56 --> Helper loaded: url_helper
INFO - 2022-01-18 09:43:56 --> Helper loaded: file_helper
INFO - 2022-01-18 09:43:56 --> Helper loaded: form_helper
INFO - 2022-01-18 09:43:56 --> Helper loaded: my_helper
INFO - 2022-01-18 09:43:56 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:43:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:43:56 --> Controller Class Initialized
DEBUG - 2022-01-18 09:43:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2022-01-18 09:43:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:43:56 --> Final output sent to browser
DEBUG - 2022-01-18 09:43:56 --> Total execution time: 0.0960
INFO - 2022-01-18 09:43:58 --> Config Class Initialized
INFO - 2022-01-18 09:43:58 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:43:58 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:43:58 --> Utf8 Class Initialized
INFO - 2022-01-18 09:43:58 --> URI Class Initialized
INFO - 2022-01-18 09:43:58 --> Router Class Initialized
INFO - 2022-01-18 09:43:58 --> Output Class Initialized
INFO - 2022-01-18 09:43:58 --> Security Class Initialized
DEBUG - 2022-01-18 09:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:43:58 --> Input Class Initialized
INFO - 2022-01-18 09:43:58 --> Language Class Initialized
INFO - 2022-01-18 09:43:58 --> Language Class Initialized
INFO - 2022-01-18 09:43:58 --> Config Class Initialized
INFO - 2022-01-18 09:43:58 --> Loader Class Initialized
INFO - 2022-01-18 09:43:58 --> Helper loaded: url_helper
INFO - 2022-01-18 09:43:58 --> Helper loaded: file_helper
INFO - 2022-01-18 09:43:58 --> Helper loaded: form_helper
INFO - 2022-01-18 09:43:58 --> Helper loaded: my_helper
INFO - 2022-01-18 09:43:58 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:43:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:43:58 --> Controller Class Initialized
DEBUG - 2022-01-18 09:43:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2022-01-18 09:43:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:43:58 --> Final output sent to browser
DEBUG - 2022-01-18 09:43:58 --> Total execution time: 0.0880
INFO - 2022-01-18 09:44:00 --> Config Class Initialized
INFO - 2022-01-18 09:44:00 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:44:00 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:44:00 --> Utf8 Class Initialized
INFO - 2022-01-18 09:44:00 --> URI Class Initialized
INFO - 2022-01-18 09:44:00 --> Router Class Initialized
INFO - 2022-01-18 09:44:00 --> Output Class Initialized
INFO - 2022-01-18 09:44:00 --> Security Class Initialized
DEBUG - 2022-01-18 09:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:44:00 --> Input Class Initialized
INFO - 2022-01-18 09:44:00 --> Language Class Initialized
INFO - 2022-01-18 09:44:00 --> Language Class Initialized
INFO - 2022-01-18 09:44:00 --> Config Class Initialized
INFO - 2022-01-18 09:44:00 --> Loader Class Initialized
INFO - 2022-01-18 09:44:00 --> Helper loaded: url_helper
INFO - 2022-01-18 09:44:00 --> Helper loaded: file_helper
INFO - 2022-01-18 09:44:00 --> Helper loaded: form_helper
INFO - 2022-01-18 09:44:00 --> Helper loaded: my_helper
INFO - 2022-01-18 09:44:00 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:44:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:44:00 --> Controller Class Initialized
DEBUG - 2022-01-18 09:44:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2022-01-18 09:44:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:44:00 --> Final output sent to browser
DEBUG - 2022-01-18 09:44:00 --> Total execution time: 0.0620
INFO - 2022-01-18 09:44:08 --> Config Class Initialized
INFO - 2022-01-18 09:44:08 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:44:08 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:44:08 --> Utf8 Class Initialized
INFO - 2022-01-18 09:44:08 --> URI Class Initialized
INFO - 2022-01-18 09:44:08 --> Router Class Initialized
INFO - 2022-01-18 09:44:08 --> Output Class Initialized
INFO - 2022-01-18 09:44:08 --> Security Class Initialized
DEBUG - 2022-01-18 09:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:44:08 --> Input Class Initialized
INFO - 2022-01-18 09:44:08 --> Language Class Initialized
INFO - 2022-01-18 09:44:08 --> Language Class Initialized
INFO - 2022-01-18 09:44:08 --> Config Class Initialized
INFO - 2022-01-18 09:44:08 --> Loader Class Initialized
INFO - 2022-01-18 09:44:08 --> Helper loaded: url_helper
INFO - 2022-01-18 09:44:08 --> Helper loaded: file_helper
INFO - 2022-01-18 09:44:08 --> Helper loaded: form_helper
INFO - 2022-01-18 09:44:08 --> Helper loaded: my_helper
INFO - 2022-01-18 09:44:08 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:44:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:44:08 --> Controller Class Initialized
INFO - 2022-01-18 09:44:08 --> Helper loaded: cookie_helper
INFO - 2022-01-18 09:44:08 --> Config Class Initialized
INFO - 2022-01-18 09:44:08 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:44:08 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:44:08 --> Utf8 Class Initialized
INFO - 2022-01-18 09:44:08 --> URI Class Initialized
INFO - 2022-01-18 09:44:08 --> Router Class Initialized
INFO - 2022-01-18 09:44:08 --> Output Class Initialized
INFO - 2022-01-18 09:44:08 --> Security Class Initialized
DEBUG - 2022-01-18 09:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:44:08 --> Input Class Initialized
INFO - 2022-01-18 09:44:08 --> Language Class Initialized
INFO - 2022-01-18 09:44:08 --> Language Class Initialized
INFO - 2022-01-18 09:44:08 --> Config Class Initialized
INFO - 2022-01-18 09:44:08 --> Loader Class Initialized
INFO - 2022-01-18 09:44:08 --> Helper loaded: url_helper
INFO - 2022-01-18 09:44:08 --> Helper loaded: file_helper
INFO - 2022-01-18 09:44:08 --> Helper loaded: form_helper
INFO - 2022-01-18 09:44:08 --> Helper loaded: my_helper
INFO - 2022-01-18 09:44:08 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:44:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:44:08 --> Controller Class Initialized
DEBUG - 2022-01-18 09:44:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-01-18 09:44:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:44:08 --> Final output sent to browser
DEBUG - 2022-01-18 09:44:08 --> Total execution time: 0.0350
INFO - 2022-01-18 09:44:15 --> Config Class Initialized
INFO - 2022-01-18 09:44:15 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:44:15 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:44:15 --> Utf8 Class Initialized
INFO - 2022-01-18 09:44:15 --> URI Class Initialized
INFO - 2022-01-18 09:44:15 --> Router Class Initialized
INFO - 2022-01-18 09:44:15 --> Output Class Initialized
INFO - 2022-01-18 09:44:15 --> Security Class Initialized
DEBUG - 2022-01-18 09:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:44:15 --> Input Class Initialized
INFO - 2022-01-18 09:44:15 --> Language Class Initialized
INFO - 2022-01-18 09:44:15 --> Language Class Initialized
INFO - 2022-01-18 09:44:15 --> Config Class Initialized
INFO - 2022-01-18 09:44:15 --> Loader Class Initialized
INFO - 2022-01-18 09:44:15 --> Helper loaded: url_helper
INFO - 2022-01-18 09:44:15 --> Helper loaded: file_helper
INFO - 2022-01-18 09:44:15 --> Helper loaded: form_helper
INFO - 2022-01-18 09:44:15 --> Helper loaded: my_helper
INFO - 2022-01-18 09:44:15 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:44:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:44:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:44:15 --> Controller Class Initialized
INFO - 2022-01-18 09:44:15 --> Helper loaded: cookie_helper
INFO - 2022-01-18 09:44:15 --> Final output sent to browser
DEBUG - 2022-01-18 09:44:15 --> Total execution time: 0.0516
INFO - 2022-01-18 09:44:16 --> Config Class Initialized
INFO - 2022-01-18 09:44:16 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:44:16 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:44:16 --> Utf8 Class Initialized
INFO - 2022-01-18 09:44:16 --> URI Class Initialized
INFO - 2022-01-18 09:44:16 --> Router Class Initialized
INFO - 2022-01-18 09:44:16 --> Output Class Initialized
INFO - 2022-01-18 09:44:16 --> Security Class Initialized
DEBUG - 2022-01-18 09:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:44:16 --> Input Class Initialized
INFO - 2022-01-18 09:44:16 --> Language Class Initialized
INFO - 2022-01-18 09:44:16 --> Language Class Initialized
INFO - 2022-01-18 09:44:16 --> Config Class Initialized
INFO - 2022-01-18 09:44:16 --> Loader Class Initialized
INFO - 2022-01-18 09:44:16 --> Helper loaded: url_helper
INFO - 2022-01-18 09:44:16 --> Helper loaded: file_helper
INFO - 2022-01-18 09:44:16 --> Helper loaded: form_helper
INFO - 2022-01-18 09:44:16 --> Helper loaded: my_helper
INFO - 2022-01-18 09:44:16 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:44:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:44:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:44:16 --> Controller Class Initialized
DEBUG - 2022-01-18 09:44:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-01-18 09:44:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:44:16 --> Final output sent to browser
DEBUG - 2022-01-18 09:44:16 --> Total execution time: 0.8540
INFO - 2022-01-18 09:44:19 --> Config Class Initialized
INFO - 2022-01-18 09:44:19 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:44:19 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:44:19 --> Utf8 Class Initialized
INFO - 2022-01-18 09:44:19 --> URI Class Initialized
INFO - 2022-01-18 09:44:19 --> Router Class Initialized
INFO - 2022-01-18 09:44:19 --> Output Class Initialized
INFO - 2022-01-18 09:44:19 --> Security Class Initialized
DEBUG - 2022-01-18 09:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:44:19 --> Input Class Initialized
INFO - 2022-01-18 09:44:19 --> Language Class Initialized
INFO - 2022-01-18 09:44:19 --> Language Class Initialized
INFO - 2022-01-18 09:44:19 --> Config Class Initialized
INFO - 2022-01-18 09:44:19 --> Loader Class Initialized
INFO - 2022-01-18 09:44:19 --> Helper loaded: url_helper
INFO - 2022-01-18 09:44:19 --> Helper loaded: file_helper
INFO - 2022-01-18 09:44:19 --> Helper loaded: form_helper
INFO - 2022-01-18 09:44:19 --> Helper loaded: my_helper
INFO - 2022-01-18 09:44:19 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:44:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:44:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:44:19 --> Controller Class Initialized
DEBUG - 2022-01-18 09:44:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2022-01-18 09:44:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:44:19 --> Final output sent to browser
DEBUG - 2022-01-18 09:44:19 --> Total execution time: 0.0470
INFO - 2022-01-18 09:44:19 --> Config Class Initialized
INFO - 2022-01-18 09:44:19 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:44:19 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:44:19 --> Utf8 Class Initialized
INFO - 2022-01-18 09:44:19 --> URI Class Initialized
INFO - 2022-01-18 09:44:19 --> Router Class Initialized
INFO - 2022-01-18 09:44:19 --> Output Class Initialized
INFO - 2022-01-18 09:44:19 --> Security Class Initialized
DEBUG - 2022-01-18 09:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:44:19 --> Input Class Initialized
INFO - 2022-01-18 09:44:19 --> Language Class Initialized
INFO - 2022-01-18 09:44:19 --> Language Class Initialized
INFO - 2022-01-18 09:44:19 --> Config Class Initialized
INFO - 2022-01-18 09:44:19 --> Loader Class Initialized
INFO - 2022-01-18 09:44:19 --> Helper loaded: url_helper
INFO - 2022-01-18 09:44:19 --> Helper loaded: file_helper
INFO - 2022-01-18 09:44:19 --> Helper loaded: form_helper
INFO - 2022-01-18 09:44:19 --> Helper loaded: my_helper
INFO - 2022-01-18 09:44:19 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:44:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:44:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:44:19 --> Controller Class Initialized
INFO - 2022-01-18 09:44:20 --> Config Class Initialized
INFO - 2022-01-18 09:44:20 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:44:20 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:44:20 --> Utf8 Class Initialized
INFO - 2022-01-18 09:44:20 --> URI Class Initialized
INFO - 2022-01-18 09:44:20 --> Router Class Initialized
INFO - 2022-01-18 09:44:20 --> Output Class Initialized
INFO - 2022-01-18 09:44:20 --> Security Class Initialized
DEBUG - 2022-01-18 09:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:44:20 --> Input Class Initialized
INFO - 2022-01-18 09:44:20 --> Language Class Initialized
INFO - 2022-01-18 09:44:20 --> Language Class Initialized
INFO - 2022-01-18 09:44:20 --> Config Class Initialized
INFO - 2022-01-18 09:44:20 --> Loader Class Initialized
INFO - 2022-01-18 09:44:20 --> Helper loaded: url_helper
INFO - 2022-01-18 09:44:20 --> Helper loaded: file_helper
INFO - 2022-01-18 09:44:20 --> Helper loaded: form_helper
INFO - 2022-01-18 09:44:20 --> Helper loaded: my_helper
INFO - 2022-01-18 09:44:20 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:44:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:44:20 --> Controller Class Initialized
INFO - 2022-01-18 09:44:20 --> Final output sent to browser
DEBUG - 2022-01-18 09:44:20 --> Total execution time: 0.0690
INFO - 2022-01-18 09:44:20 --> Config Class Initialized
INFO - 2022-01-18 09:44:20 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:44:20 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:44:20 --> Utf8 Class Initialized
INFO - 2022-01-18 09:44:20 --> URI Class Initialized
INFO - 2022-01-18 09:44:20 --> Router Class Initialized
INFO - 2022-01-18 09:44:20 --> Output Class Initialized
INFO - 2022-01-18 09:44:20 --> Security Class Initialized
DEBUG - 2022-01-18 09:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:44:20 --> Input Class Initialized
INFO - 2022-01-18 09:44:20 --> Language Class Initialized
INFO - 2022-01-18 09:44:20 --> Language Class Initialized
INFO - 2022-01-18 09:44:20 --> Config Class Initialized
INFO - 2022-01-18 09:44:20 --> Loader Class Initialized
INFO - 2022-01-18 09:44:20 --> Helper loaded: url_helper
INFO - 2022-01-18 09:44:20 --> Helper loaded: file_helper
INFO - 2022-01-18 09:44:20 --> Helper loaded: form_helper
INFO - 2022-01-18 09:44:20 --> Helper loaded: my_helper
INFO - 2022-01-18 09:44:20 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:44:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:44:20 --> Controller Class Initialized
INFO - 2022-01-18 09:44:23 --> Config Class Initialized
INFO - 2022-01-18 09:44:23 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:44:23 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:44:23 --> Utf8 Class Initialized
INFO - 2022-01-18 09:44:23 --> URI Class Initialized
INFO - 2022-01-18 09:44:23 --> Router Class Initialized
INFO - 2022-01-18 09:44:23 --> Output Class Initialized
INFO - 2022-01-18 09:44:23 --> Security Class Initialized
DEBUG - 2022-01-18 09:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:44:23 --> Input Class Initialized
INFO - 2022-01-18 09:44:23 --> Language Class Initialized
INFO - 2022-01-18 09:44:23 --> Language Class Initialized
INFO - 2022-01-18 09:44:23 --> Config Class Initialized
INFO - 2022-01-18 09:44:23 --> Loader Class Initialized
INFO - 2022-01-18 09:44:23 --> Helper loaded: url_helper
INFO - 2022-01-18 09:44:23 --> Helper loaded: file_helper
INFO - 2022-01-18 09:44:23 --> Helper loaded: form_helper
INFO - 2022-01-18 09:44:23 --> Helper loaded: my_helper
INFO - 2022-01-18 09:44:23 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:44:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:44:23 --> Controller Class Initialized
INFO - 2022-01-18 09:44:23 --> Helper loaded: cookie_helper
INFO - 2022-01-18 09:44:23 --> Config Class Initialized
INFO - 2022-01-18 09:44:23 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:44:23 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:44:23 --> Utf8 Class Initialized
INFO - 2022-01-18 09:44:23 --> URI Class Initialized
INFO - 2022-01-18 09:44:23 --> Router Class Initialized
INFO - 2022-01-18 09:44:23 --> Output Class Initialized
INFO - 2022-01-18 09:44:23 --> Security Class Initialized
DEBUG - 2022-01-18 09:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:44:23 --> Input Class Initialized
INFO - 2022-01-18 09:44:23 --> Language Class Initialized
INFO - 2022-01-18 09:44:23 --> Language Class Initialized
INFO - 2022-01-18 09:44:23 --> Config Class Initialized
INFO - 2022-01-18 09:44:23 --> Loader Class Initialized
INFO - 2022-01-18 09:44:23 --> Helper loaded: url_helper
INFO - 2022-01-18 09:44:23 --> Helper loaded: file_helper
INFO - 2022-01-18 09:44:23 --> Helper loaded: form_helper
INFO - 2022-01-18 09:44:23 --> Helper loaded: my_helper
INFO - 2022-01-18 09:44:23 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:44:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:44:23 --> Controller Class Initialized
DEBUG - 2022-01-18 09:44:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-01-18 09:44:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:44:23 --> Final output sent to browser
DEBUG - 2022-01-18 09:44:23 --> Total execution time: 0.0350
INFO - 2022-01-18 09:44:30 --> Config Class Initialized
INFO - 2022-01-18 09:44:30 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:44:30 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:44:30 --> Utf8 Class Initialized
INFO - 2022-01-18 09:44:30 --> URI Class Initialized
INFO - 2022-01-18 09:44:30 --> Router Class Initialized
INFO - 2022-01-18 09:44:30 --> Output Class Initialized
INFO - 2022-01-18 09:44:30 --> Security Class Initialized
DEBUG - 2022-01-18 09:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:44:30 --> Input Class Initialized
INFO - 2022-01-18 09:44:30 --> Language Class Initialized
INFO - 2022-01-18 09:44:30 --> Language Class Initialized
INFO - 2022-01-18 09:44:30 --> Config Class Initialized
INFO - 2022-01-18 09:44:30 --> Loader Class Initialized
INFO - 2022-01-18 09:44:30 --> Helper loaded: url_helper
INFO - 2022-01-18 09:44:30 --> Helper loaded: file_helper
INFO - 2022-01-18 09:44:30 --> Helper loaded: form_helper
INFO - 2022-01-18 09:44:30 --> Helper loaded: my_helper
INFO - 2022-01-18 09:44:30 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:44:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:44:30 --> Controller Class Initialized
INFO - 2022-01-18 09:44:30 --> Helper loaded: cookie_helper
INFO - 2022-01-18 09:44:30 --> Final output sent to browser
DEBUG - 2022-01-18 09:44:30 --> Total execution time: 0.0540
INFO - 2022-01-18 09:44:32 --> Config Class Initialized
INFO - 2022-01-18 09:44:32 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:44:32 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:44:32 --> Utf8 Class Initialized
INFO - 2022-01-18 09:44:32 --> URI Class Initialized
INFO - 2022-01-18 09:44:32 --> Router Class Initialized
INFO - 2022-01-18 09:44:32 --> Output Class Initialized
INFO - 2022-01-18 09:44:32 --> Security Class Initialized
DEBUG - 2022-01-18 09:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:44:32 --> Input Class Initialized
INFO - 2022-01-18 09:44:32 --> Language Class Initialized
INFO - 2022-01-18 09:44:32 --> Language Class Initialized
INFO - 2022-01-18 09:44:32 --> Config Class Initialized
INFO - 2022-01-18 09:44:32 --> Loader Class Initialized
INFO - 2022-01-18 09:44:32 --> Helper loaded: url_helper
INFO - 2022-01-18 09:44:32 --> Helper loaded: file_helper
INFO - 2022-01-18 09:44:32 --> Helper loaded: form_helper
INFO - 2022-01-18 09:44:32 --> Helper loaded: my_helper
INFO - 2022-01-18 09:44:32 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:44:32 --> Controller Class Initialized
DEBUG - 2022-01-18 09:44:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-01-18 09:44:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:44:32 --> Final output sent to browser
DEBUG - 2022-01-18 09:44:32 --> Total execution time: 0.2760
INFO - 2022-01-18 09:44:34 --> Config Class Initialized
INFO - 2022-01-18 09:44:34 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:44:34 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:44:34 --> Utf8 Class Initialized
INFO - 2022-01-18 09:44:34 --> URI Class Initialized
INFO - 2022-01-18 09:44:34 --> Router Class Initialized
INFO - 2022-01-18 09:44:34 --> Output Class Initialized
INFO - 2022-01-18 09:44:34 --> Security Class Initialized
DEBUG - 2022-01-18 09:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:44:34 --> Input Class Initialized
INFO - 2022-01-18 09:44:34 --> Language Class Initialized
INFO - 2022-01-18 09:44:34 --> Language Class Initialized
INFO - 2022-01-18 09:44:34 --> Config Class Initialized
INFO - 2022-01-18 09:44:34 --> Loader Class Initialized
INFO - 2022-01-18 09:44:34 --> Helper loaded: url_helper
INFO - 2022-01-18 09:44:34 --> Helper loaded: file_helper
INFO - 2022-01-18 09:44:34 --> Helper loaded: form_helper
INFO - 2022-01-18 09:44:34 --> Helper loaded: my_helper
INFO - 2022-01-18 09:44:34 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:44:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:44:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:44:34 --> Controller Class Initialized
DEBUG - 2022-01-18 09:44:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2022-01-18 09:44:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:44:34 --> Final output sent to browser
DEBUG - 2022-01-18 09:44:34 --> Total execution time: 0.1130
INFO - 2022-01-18 09:44:37 --> Config Class Initialized
INFO - 2022-01-18 09:44:37 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:44:37 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:44:37 --> Utf8 Class Initialized
INFO - 2022-01-18 09:44:37 --> URI Class Initialized
INFO - 2022-01-18 09:44:37 --> Router Class Initialized
INFO - 2022-01-18 09:44:37 --> Output Class Initialized
INFO - 2022-01-18 09:44:37 --> Security Class Initialized
DEBUG - 2022-01-18 09:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:44:37 --> Input Class Initialized
INFO - 2022-01-18 09:44:37 --> Language Class Initialized
INFO - 2022-01-18 09:44:37 --> Language Class Initialized
INFO - 2022-01-18 09:44:37 --> Config Class Initialized
INFO - 2022-01-18 09:44:37 --> Loader Class Initialized
INFO - 2022-01-18 09:44:37 --> Helper loaded: url_helper
INFO - 2022-01-18 09:44:37 --> Helper loaded: file_helper
INFO - 2022-01-18 09:44:37 --> Helper loaded: form_helper
INFO - 2022-01-18 09:44:37 --> Helper loaded: my_helper
INFO - 2022-01-18 09:44:37 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:44:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:44:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:44:37 --> Controller Class Initialized
DEBUG - 2022-01-18 09:44:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2022-01-18 09:44:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:44:37 --> Final output sent to browser
DEBUG - 2022-01-18 09:44:37 --> Total execution time: 0.0540
INFO - 2022-01-18 09:44:39 --> Config Class Initialized
INFO - 2022-01-18 09:44:39 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:44:39 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:44:39 --> Utf8 Class Initialized
INFO - 2022-01-18 09:44:39 --> URI Class Initialized
INFO - 2022-01-18 09:44:39 --> Router Class Initialized
INFO - 2022-01-18 09:44:39 --> Output Class Initialized
INFO - 2022-01-18 09:44:39 --> Security Class Initialized
DEBUG - 2022-01-18 09:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:44:39 --> Input Class Initialized
INFO - 2022-01-18 09:44:39 --> Language Class Initialized
INFO - 2022-01-18 09:44:39 --> Language Class Initialized
INFO - 2022-01-18 09:44:39 --> Config Class Initialized
INFO - 2022-01-18 09:44:39 --> Loader Class Initialized
INFO - 2022-01-18 09:44:39 --> Helper loaded: url_helper
INFO - 2022-01-18 09:44:39 --> Helper loaded: file_helper
INFO - 2022-01-18 09:44:39 --> Helper loaded: form_helper
INFO - 2022-01-18 09:44:39 --> Helper loaded: my_helper
INFO - 2022-01-18 09:44:39 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:44:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:44:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:44:39 --> Controller Class Initialized
DEBUG - 2022-01-18 09:44:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-01-18 09:44:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:44:39 --> Final output sent to browser
DEBUG - 2022-01-18 09:44:39 --> Total execution time: 0.0520
INFO - 2022-01-18 09:44:41 --> Config Class Initialized
INFO - 2022-01-18 09:44:41 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:44:41 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:44:41 --> Utf8 Class Initialized
INFO - 2022-01-18 09:44:41 --> URI Class Initialized
INFO - 2022-01-18 09:44:41 --> Router Class Initialized
INFO - 2022-01-18 09:44:41 --> Output Class Initialized
INFO - 2022-01-18 09:44:41 --> Security Class Initialized
DEBUG - 2022-01-18 09:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:44:41 --> Input Class Initialized
INFO - 2022-01-18 09:44:41 --> Language Class Initialized
INFO - 2022-01-18 09:44:41 --> Language Class Initialized
INFO - 2022-01-18 09:44:41 --> Config Class Initialized
INFO - 2022-01-18 09:44:41 --> Loader Class Initialized
INFO - 2022-01-18 09:44:41 --> Helper loaded: url_helper
INFO - 2022-01-18 09:44:41 --> Helper loaded: file_helper
INFO - 2022-01-18 09:44:41 --> Helper loaded: form_helper
INFO - 2022-01-18 09:44:41 --> Helper loaded: my_helper
INFO - 2022-01-18 09:44:41 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:44:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:44:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:44:41 --> Controller Class Initialized
INFO - 2022-01-18 09:44:41 --> Final output sent to browser
DEBUG - 2022-01-18 09:44:41 --> Total execution time: 0.0386
INFO - 2022-01-18 09:45:14 --> Config Class Initialized
INFO - 2022-01-18 09:45:14 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:45:14 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:45:14 --> Utf8 Class Initialized
INFO - 2022-01-18 09:45:14 --> URI Class Initialized
INFO - 2022-01-18 09:45:14 --> Router Class Initialized
INFO - 2022-01-18 09:45:14 --> Output Class Initialized
INFO - 2022-01-18 09:45:14 --> Security Class Initialized
DEBUG - 2022-01-18 09:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:45:14 --> Input Class Initialized
INFO - 2022-01-18 09:45:14 --> Language Class Initialized
INFO - 2022-01-18 09:45:14 --> Language Class Initialized
INFO - 2022-01-18 09:45:14 --> Config Class Initialized
INFO - 2022-01-18 09:45:14 --> Loader Class Initialized
INFO - 2022-01-18 09:45:14 --> Helper loaded: url_helper
INFO - 2022-01-18 09:45:14 --> Helper loaded: file_helper
INFO - 2022-01-18 09:45:14 --> Helper loaded: form_helper
INFO - 2022-01-18 09:45:14 --> Helper loaded: my_helper
INFO - 2022-01-18 09:45:14 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:45:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:45:14 --> Controller Class Initialized
INFO - 2022-01-18 09:45:14 --> Final output sent to browser
DEBUG - 2022-01-18 09:45:14 --> Total execution time: 0.0790
INFO - 2022-01-18 09:45:19 --> Config Class Initialized
INFO - 2022-01-18 09:45:19 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:45:19 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:45:19 --> Utf8 Class Initialized
INFO - 2022-01-18 09:45:19 --> URI Class Initialized
INFO - 2022-01-18 09:45:19 --> Router Class Initialized
INFO - 2022-01-18 09:45:19 --> Output Class Initialized
INFO - 2022-01-18 09:45:19 --> Security Class Initialized
DEBUG - 2022-01-18 09:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:45:19 --> Input Class Initialized
INFO - 2022-01-18 09:45:19 --> Language Class Initialized
INFO - 2022-01-18 09:45:19 --> Language Class Initialized
INFO - 2022-01-18 09:45:19 --> Config Class Initialized
INFO - 2022-01-18 09:45:19 --> Loader Class Initialized
INFO - 2022-01-18 09:45:19 --> Helper loaded: url_helper
INFO - 2022-01-18 09:45:19 --> Helper loaded: file_helper
INFO - 2022-01-18 09:45:19 --> Helper loaded: form_helper
INFO - 2022-01-18 09:45:19 --> Helper loaded: my_helper
INFO - 2022-01-18 09:45:19 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:45:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:45:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:45:19 --> Controller Class Initialized
DEBUG - 2022-01-18 09:45:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2022-01-18 09:45:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:45:19 --> Final output sent to browser
DEBUG - 2022-01-18 09:45:19 --> Total execution time: 0.0500
INFO - 2022-01-18 09:45:20 --> Config Class Initialized
INFO - 2022-01-18 09:45:20 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:45:20 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:45:20 --> Utf8 Class Initialized
INFO - 2022-01-18 09:45:20 --> URI Class Initialized
INFO - 2022-01-18 09:45:20 --> Router Class Initialized
INFO - 2022-01-18 09:45:20 --> Output Class Initialized
INFO - 2022-01-18 09:45:20 --> Security Class Initialized
DEBUG - 2022-01-18 09:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:45:20 --> Input Class Initialized
INFO - 2022-01-18 09:45:20 --> Language Class Initialized
INFO - 2022-01-18 09:45:20 --> Language Class Initialized
INFO - 2022-01-18 09:45:20 --> Config Class Initialized
INFO - 2022-01-18 09:45:20 --> Loader Class Initialized
INFO - 2022-01-18 09:45:20 --> Helper loaded: url_helper
INFO - 2022-01-18 09:45:20 --> Helper loaded: file_helper
INFO - 2022-01-18 09:45:20 --> Helper loaded: form_helper
INFO - 2022-01-18 09:45:20 --> Helper loaded: my_helper
INFO - 2022-01-18 09:45:20 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:45:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:45:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:45:20 --> Controller Class Initialized
DEBUG - 2022-01-18 09:45:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-01-18 09:45:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:45:20 --> Final output sent to browser
DEBUG - 2022-01-18 09:45:20 --> Total execution time: 0.0610
INFO - 2022-01-18 09:45:22 --> Config Class Initialized
INFO - 2022-01-18 09:45:22 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:45:22 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:45:22 --> Utf8 Class Initialized
INFO - 2022-01-18 09:45:22 --> URI Class Initialized
INFO - 2022-01-18 09:45:22 --> Router Class Initialized
INFO - 2022-01-18 09:45:22 --> Output Class Initialized
INFO - 2022-01-18 09:45:22 --> Security Class Initialized
DEBUG - 2022-01-18 09:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:45:22 --> Input Class Initialized
INFO - 2022-01-18 09:45:22 --> Language Class Initialized
INFO - 2022-01-18 09:45:22 --> Language Class Initialized
INFO - 2022-01-18 09:45:22 --> Config Class Initialized
INFO - 2022-01-18 09:45:22 --> Loader Class Initialized
INFO - 2022-01-18 09:45:22 --> Helper loaded: url_helper
INFO - 2022-01-18 09:45:22 --> Helper loaded: file_helper
INFO - 2022-01-18 09:45:22 --> Helper loaded: form_helper
INFO - 2022-01-18 09:45:22 --> Helper loaded: my_helper
INFO - 2022-01-18 09:45:22 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:45:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:45:22 --> Controller Class Initialized
INFO - 2022-01-18 09:45:22 --> Final output sent to browser
DEBUG - 2022-01-18 09:45:22 --> Total execution time: 0.0466
INFO - 2022-01-18 09:45:24 --> Config Class Initialized
INFO - 2022-01-18 09:45:24 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:45:24 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:45:24 --> Utf8 Class Initialized
INFO - 2022-01-18 09:45:24 --> URI Class Initialized
INFO - 2022-01-18 09:45:24 --> Router Class Initialized
INFO - 2022-01-18 09:45:24 --> Output Class Initialized
INFO - 2022-01-18 09:45:24 --> Security Class Initialized
DEBUG - 2022-01-18 09:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:45:24 --> Input Class Initialized
INFO - 2022-01-18 09:45:24 --> Language Class Initialized
INFO - 2022-01-18 09:45:24 --> Language Class Initialized
INFO - 2022-01-18 09:45:24 --> Config Class Initialized
INFO - 2022-01-18 09:45:24 --> Loader Class Initialized
INFO - 2022-01-18 09:45:24 --> Helper loaded: url_helper
INFO - 2022-01-18 09:45:24 --> Helper loaded: file_helper
INFO - 2022-01-18 09:45:24 --> Helper loaded: form_helper
INFO - 2022-01-18 09:45:24 --> Helper loaded: my_helper
INFO - 2022-01-18 09:45:24 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:45:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:45:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:45:24 --> Controller Class Initialized
DEBUG - 2022-01-18 09:45:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2022-01-18 09:45:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:45:24 --> Final output sent to browser
DEBUG - 2022-01-18 09:45:24 --> Total execution time: 0.0680
INFO - 2022-01-18 09:45:27 --> Config Class Initialized
INFO - 2022-01-18 09:45:27 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:45:27 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:45:27 --> Utf8 Class Initialized
INFO - 2022-01-18 09:45:27 --> URI Class Initialized
INFO - 2022-01-18 09:45:27 --> Router Class Initialized
INFO - 2022-01-18 09:45:27 --> Output Class Initialized
INFO - 2022-01-18 09:45:27 --> Security Class Initialized
DEBUG - 2022-01-18 09:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:45:27 --> Input Class Initialized
INFO - 2022-01-18 09:45:27 --> Language Class Initialized
INFO - 2022-01-18 09:45:27 --> Language Class Initialized
INFO - 2022-01-18 09:45:27 --> Config Class Initialized
INFO - 2022-01-18 09:45:27 --> Loader Class Initialized
INFO - 2022-01-18 09:45:27 --> Helper loaded: url_helper
INFO - 2022-01-18 09:45:27 --> Helper loaded: file_helper
INFO - 2022-01-18 09:45:27 --> Helper loaded: form_helper
INFO - 2022-01-18 09:45:27 --> Helper loaded: my_helper
INFO - 2022-01-18 09:45:27 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:45:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:45:27 --> Controller Class Initialized
DEBUG - 2022-01-18 09:45:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-01-18 09:45:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:45:27 --> Final output sent to browser
DEBUG - 2022-01-18 09:45:27 --> Total execution time: 0.0590
INFO - 2022-01-18 09:45:31 --> Config Class Initialized
INFO - 2022-01-18 09:45:31 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:45:31 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:45:31 --> Utf8 Class Initialized
INFO - 2022-01-18 09:45:31 --> URI Class Initialized
INFO - 2022-01-18 09:45:31 --> Router Class Initialized
INFO - 2022-01-18 09:45:31 --> Output Class Initialized
INFO - 2022-01-18 09:45:31 --> Security Class Initialized
DEBUG - 2022-01-18 09:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:45:31 --> Input Class Initialized
INFO - 2022-01-18 09:45:31 --> Language Class Initialized
INFO - 2022-01-18 09:45:31 --> Language Class Initialized
INFO - 2022-01-18 09:45:31 --> Config Class Initialized
INFO - 2022-01-18 09:45:31 --> Loader Class Initialized
INFO - 2022-01-18 09:45:31 --> Helper loaded: url_helper
INFO - 2022-01-18 09:45:31 --> Helper loaded: file_helper
INFO - 2022-01-18 09:45:31 --> Helper loaded: form_helper
INFO - 2022-01-18 09:45:31 --> Helper loaded: my_helper
INFO - 2022-01-18 09:45:31 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:45:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:45:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:45:31 --> Controller Class Initialized
DEBUG - 2022-01-18 09:45:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2022-01-18 09:45:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:45:31 --> Final output sent to browser
DEBUG - 2022-01-18 09:45:31 --> Total execution time: 0.0800
INFO - 2022-01-18 09:45:33 --> Config Class Initialized
INFO - 2022-01-18 09:45:33 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:45:33 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:45:33 --> Utf8 Class Initialized
INFO - 2022-01-18 09:45:33 --> URI Class Initialized
INFO - 2022-01-18 09:45:33 --> Router Class Initialized
INFO - 2022-01-18 09:45:33 --> Output Class Initialized
INFO - 2022-01-18 09:45:33 --> Security Class Initialized
DEBUG - 2022-01-18 09:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:45:33 --> Input Class Initialized
INFO - 2022-01-18 09:45:33 --> Language Class Initialized
INFO - 2022-01-18 09:45:33 --> Language Class Initialized
INFO - 2022-01-18 09:45:33 --> Config Class Initialized
INFO - 2022-01-18 09:45:33 --> Loader Class Initialized
INFO - 2022-01-18 09:45:33 --> Helper loaded: url_helper
INFO - 2022-01-18 09:45:33 --> Helper loaded: file_helper
INFO - 2022-01-18 09:45:33 --> Helper loaded: form_helper
INFO - 2022-01-18 09:45:33 --> Helper loaded: my_helper
INFO - 2022-01-18 09:45:33 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:45:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:45:33 --> Controller Class Initialized
INFO - 2022-01-18 09:45:33 --> Helper loaded: cookie_helper
INFO - 2022-01-18 09:45:33 --> Config Class Initialized
INFO - 2022-01-18 09:45:33 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:45:33 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:45:33 --> Utf8 Class Initialized
INFO - 2022-01-18 09:45:33 --> URI Class Initialized
INFO - 2022-01-18 09:45:33 --> Router Class Initialized
INFO - 2022-01-18 09:45:33 --> Output Class Initialized
INFO - 2022-01-18 09:45:33 --> Security Class Initialized
DEBUG - 2022-01-18 09:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:45:33 --> Input Class Initialized
INFO - 2022-01-18 09:45:33 --> Language Class Initialized
INFO - 2022-01-18 09:45:33 --> Language Class Initialized
INFO - 2022-01-18 09:45:33 --> Config Class Initialized
INFO - 2022-01-18 09:45:33 --> Loader Class Initialized
INFO - 2022-01-18 09:45:33 --> Helper loaded: url_helper
INFO - 2022-01-18 09:45:33 --> Helper loaded: file_helper
INFO - 2022-01-18 09:45:33 --> Helper loaded: form_helper
INFO - 2022-01-18 09:45:33 --> Helper loaded: my_helper
INFO - 2022-01-18 09:45:33 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:45:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:45:33 --> Controller Class Initialized
DEBUG - 2022-01-18 09:45:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-01-18 09:45:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:45:33 --> Final output sent to browser
DEBUG - 2022-01-18 09:45:33 --> Total execution time: 0.0390
INFO - 2022-01-18 09:45:40 --> Config Class Initialized
INFO - 2022-01-18 09:45:40 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:45:40 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:45:40 --> Utf8 Class Initialized
INFO - 2022-01-18 09:45:40 --> URI Class Initialized
INFO - 2022-01-18 09:45:40 --> Router Class Initialized
INFO - 2022-01-18 09:45:40 --> Output Class Initialized
INFO - 2022-01-18 09:45:40 --> Security Class Initialized
DEBUG - 2022-01-18 09:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:45:40 --> Input Class Initialized
INFO - 2022-01-18 09:45:40 --> Language Class Initialized
INFO - 2022-01-18 09:45:40 --> Language Class Initialized
INFO - 2022-01-18 09:45:40 --> Config Class Initialized
INFO - 2022-01-18 09:45:40 --> Loader Class Initialized
INFO - 2022-01-18 09:45:40 --> Helper loaded: url_helper
INFO - 2022-01-18 09:45:40 --> Helper loaded: file_helper
INFO - 2022-01-18 09:45:40 --> Helper loaded: form_helper
INFO - 2022-01-18 09:45:40 --> Helper loaded: my_helper
INFO - 2022-01-18 09:45:40 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:45:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:45:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:45:40 --> Controller Class Initialized
INFO - 2022-01-18 09:45:40 --> Helper loaded: cookie_helper
INFO - 2022-01-18 09:45:40 --> Final output sent to browser
DEBUG - 2022-01-18 09:45:40 --> Total execution time: 0.0516
INFO - 2022-01-18 09:45:40 --> Config Class Initialized
INFO - 2022-01-18 09:45:40 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:45:40 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:45:40 --> Utf8 Class Initialized
INFO - 2022-01-18 09:45:40 --> URI Class Initialized
INFO - 2022-01-18 09:45:40 --> Router Class Initialized
INFO - 2022-01-18 09:45:40 --> Output Class Initialized
INFO - 2022-01-18 09:45:40 --> Security Class Initialized
DEBUG - 2022-01-18 09:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:45:40 --> Input Class Initialized
INFO - 2022-01-18 09:45:40 --> Language Class Initialized
INFO - 2022-01-18 09:45:40 --> Language Class Initialized
INFO - 2022-01-18 09:45:40 --> Config Class Initialized
INFO - 2022-01-18 09:45:40 --> Loader Class Initialized
INFO - 2022-01-18 09:45:40 --> Helper loaded: url_helper
INFO - 2022-01-18 09:45:40 --> Helper loaded: file_helper
INFO - 2022-01-18 09:45:40 --> Helper loaded: form_helper
INFO - 2022-01-18 09:45:40 --> Helper loaded: my_helper
INFO - 2022-01-18 09:45:40 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:45:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:45:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:45:40 --> Controller Class Initialized
DEBUG - 2022-01-18 09:45:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-01-18 09:45:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:45:41 --> Final output sent to browser
DEBUG - 2022-01-18 09:45:41 --> Total execution time: 0.3580
INFO - 2022-01-18 09:45:43 --> Config Class Initialized
INFO - 2022-01-18 09:45:43 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:45:43 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:45:43 --> Utf8 Class Initialized
INFO - 2022-01-18 09:45:43 --> URI Class Initialized
INFO - 2022-01-18 09:45:43 --> Router Class Initialized
INFO - 2022-01-18 09:45:43 --> Output Class Initialized
INFO - 2022-01-18 09:45:43 --> Security Class Initialized
DEBUG - 2022-01-18 09:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:45:43 --> Input Class Initialized
INFO - 2022-01-18 09:45:43 --> Language Class Initialized
INFO - 2022-01-18 09:45:43 --> Language Class Initialized
INFO - 2022-01-18 09:45:43 --> Config Class Initialized
INFO - 2022-01-18 09:45:43 --> Loader Class Initialized
INFO - 2022-01-18 09:45:43 --> Helper loaded: url_helper
INFO - 2022-01-18 09:45:43 --> Helper loaded: file_helper
INFO - 2022-01-18 09:45:43 --> Helper loaded: form_helper
INFO - 2022-01-18 09:45:43 --> Helper loaded: my_helper
INFO - 2022-01-18 09:45:43 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:45:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:45:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:45:43 --> Controller Class Initialized
DEBUG - 2022-01-18 09:45:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2022-01-18 09:45:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:45:43 --> Final output sent to browser
DEBUG - 2022-01-18 09:45:43 --> Total execution time: 0.0500
INFO - 2022-01-18 09:45:43 --> Config Class Initialized
INFO - 2022-01-18 09:45:43 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:45:43 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:45:43 --> Utf8 Class Initialized
INFO - 2022-01-18 09:45:43 --> URI Class Initialized
INFO - 2022-01-18 09:45:43 --> Router Class Initialized
INFO - 2022-01-18 09:45:43 --> Output Class Initialized
INFO - 2022-01-18 09:45:43 --> Security Class Initialized
DEBUG - 2022-01-18 09:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:45:43 --> Input Class Initialized
INFO - 2022-01-18 09:45:43 --> Language Class Initialized
INFO - 2022-01-18 09:45:43 --> Language Class Initialized
INFO - 2022-01-18 09:45:43 --> Config Class Initialized
INFO - 2022-01-18 09:45:43 --> Loader Class Initialized
INFO - 2022-01-18 09:45:43 --> Helper loaded: url_helper
INFO - 2022-01-18 09:45:43 --> Helper loaded: file_helper
INFO - 2022-01-18 09:45:43 --> Helper loaded: form_helper
INFO - 2022-01-18 09:45:43 --> Helper loaded: my_helper
INFO - 2022-01-18 09:45:43 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:45:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:45:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:45:43 --> Controller Class Initialized
INFO - 2022-01-18 09:45:45 --> Config Class Initialized
INFO - 2022-01-18 09:45:45 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:45:45 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:45:45 --> Utf8 Class Initialized
INFO - 2022-01-18 09:45:45 --> URI Class Initialized
INFO - 2022-01-18 09:45:45 --> Router Class Initialized
INFO - 2022-01-18 09:45:45 --> Output Class Initialized
INFO - 2022-01-18 09:45:45 --> Security Class Initialized
DEBUG - 2022-01-18 09:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:45:45 --> Input Class Initialized
INFO - 2022-01-18 09:45:45 --> Language Class Initialized
INFO - 2022-01-18 09:45:45 --> Language Class Initialized
INFO - 2022-01-18 09:45:45 --> Config Class Initialized
INFO - 2022-01-18 09:45:45 --> Loader Class Initialized
INFO - 2022-01-18 09:45:45 --> Helper loaded: url_helper
INFO - 2022-01-18 09:45:45 --> Helper loaded: file_helper
INFO - 2022-01-18 09:45:45 --> Helper loaded: form_helper
INFO - 2022-01-18 09:45:45 --> Helper loaded: my_helper
INFO - 2022-01-18 09:45:45 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:45:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:45:45 --> Controller Class Initialized
INFO - 2022-01-18 09:45:45 --> Final output sent to browser
DEBUG - 2022-01-18 09:45:45 --> Total execution time: 0.0580
INFO - 2022-01-18 09:45:45 --> Config Class Initialized
INFO - 2022-01-18 09:45:45 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:45:45 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:45:45 --> Utf8 Class Initialized
INFO - 2022-01-18 09:45:45 --> URI Class Initialized
INFO - 2022-01-18 09:45:45 --> Router Class Initialized
INFO - 2022-01-18 09:45:45 --> Output Class Initialized
INFO - 2022-01-18 09:45:45 --> Security Class Initialized
DEBUG - 2022-01-18 09:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:45:45 --> Input Class Initialized
INFO - 2022-01-18 09:45:45 --> Language Class Initialized
INFO - 2022-01-18 09:45:45 --> Language Class Initialized
INFO - 2022-01-18 09:45:45 --> Config Class Initialized
INFO - 2022-01-18 09:45:45 --> Loader Class Initialized
INFO - 2022-01-18 09:45:45 --> Helper loaded: url_helper
INFO - 2022-01-18 09:45:45 --> Helper loaded: file_helper
INFO - 2022-01-18 09:45:45 --> Helper loaded: form_helper
INFO - 2022-01-18 09:45:45 --> Helper loaded: my_helper
INFO - 2022-01-18 09:45:45 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:45:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:45:45 --> Controller Class Initialized
INFO - 2022-01-18 09:45:48 --> Config Class Initialized
INFO - 2022-01-18 09:45:48 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:45:48 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:45:48 --> Utf8 Class Initialized
INFO - 2022-01-18 09:45:48 --> URI Class Initialized
INFO - 2022-01-18 09:45:48 --> Router Class Initialized
INFO - 2022-01-18 09:45:48 --> Output Class Initialized
INFO - 2022-01-18 09:45:48 --> Security Class Initialized
DEBUG - 2022-01-18 09:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:45:48 --> Input Class Initialized
INFO - 2022-01-18 09:45:48 --> Language Class Initialized
INFO - 2022-01-18 09:45:48 --> Language Class Initialized
INFO - 2022-01-18 09:45:48 --> Config Class Initialized
INFO - 2022-01-18 09:45:48 --> Loader Class Initialized
INFO - 2022-01-18 09:45:48 --> Helper loaded: url_helper
INFO - 2022-01-18 09:45:48 --> Helper loaded: file_helper
INFO - 2022-01-18 09:45:48 --> Helper loaded: form_helper
INFO - 2022-01-18 09:45:48 --> Helper loaded: my_helper
INFO - 2022-01-18 09:45:48 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:45:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:45:48 --> Controller Class Initialized
INFO - 2022-01-18 09:45:48 --> Helper loaded: cookie_helper
INFO - 2022-01-18 09:45:48 --> Config Class Initialized
INFO - 2022-01-18 09:45:48 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:45:48 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:45:48 --> Utf8 Class Initialized
INFO - 2022-01-18 09:45:48 --> URI Class Initialized
INFO - 2022-01-18 09:45:48 --> Router Class Initialized
INFO - 2022-01-18 09:45:48 --> Output Class Initialized
INFO - 2022-01-18 09:45:48 --> Security Class Initialized
DEBUG - 2022-01-18 09:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:45:48 --> Input Class Initialized
INFO - 2022-01-18 09:45:48 --> Language Class Initialized
INFO - 2022-01-18 09:45:48 --> Language Class Initialized
INFO - 2022-01-18 09:45:48 --> Config Class Initialized
INFO - 2022-01-18 09:45:48 --> Loader Class Initialized
INFO - 2022-01-18 09:45:48 --> Helper loaded: url_helper
INFO - 2022-01-18 09:45:48 --> Helper loaded: file_helper
INFO - 2022-01-18 09:45:48 --> Helper loaded: form_helper
INFO - 2022-01-18 09:45:48 --> Helper loaded: my_helper
INFO - 2022-01-18 09:45:48 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:45:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:45:48 --> Controller Class Initialized
DEBUG - 2022-01-18 09:45:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-01-18 09:45:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:45:48 --> Final output sent to browser
DEBUG - 2022-01-18 09:45:48 --> Total execution time: 0.0350
INFO - 2022-01-18 09:45:57 --> Config Class Initialized
INFO - 2022-01-18 09:45:57 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:45:57 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:45:57 --> Utf8 Class Initialized
INFO - 2022-01-18 09:45:57 --> URI Class Initialized
INFO - 2022-01-18 09:45:57 --> Router Class Initialized
INFO - 2022-01-18 09:45:57 --> Output Class Initialized
INFO - 2022-01-18 09:45:57 --> Security Class Initialized
DEBUG - 2022-01-18 09:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:45:57 --> Input Class Initialized
INFO - 2022-01-18 09:45:57 --> Language Class Initialized
INFO - 2022-01-18 09:45:57 --> Language Class Initialized
INFO - 2022-01-18 09:45:57 --> Config Class Initialized
INFO - 2022-01-18 09:45:57 --> Loader Class Initialized
INFO - 2022-01-18 09:45:57 --> Helper loaded: url_helper
INFO - 2022-01-18 09:45:57 --> Helper loaded: file_helper
INFO - 2022-01-18 09:45:57 --> Helper loaded: form_helper
INFO - 2022-01-18 09:45:57 --> Helper loaded: my_helper
INFO - 2022-01-18 09:45:57 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:45:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:45:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:45:57 --> Controller Class Initialized
INFO - 2022-01-18 09:45:57 --> Helper loaded: cookie_helper
INFO - 2022-01-18 09:45:57 --> Final output sent to browser
DEBUG - 2022-01-18 09:45:57 --> Total execution time: 0.0650
INFO - 2022-01-18 09:45:58 --> Config Class Initialized
INFO - 2022-01-18 09:45:58 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:45:58 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:45:58 --> Utf8 Class Initialized
INFO - 2022-01-18 09:45:58 --> URI Class Initialized
INFO - 2022-01-18 09:45:58 --> Router Class Initialized
INFO - 2022-01-18 09:45:58 --> Output Class Initialized
INFO - 2022-01-18 09:45:58 --> Security Class Initialized
DEBUG - 2022-01-18 09:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:45:58 --> Input Class Initialized
INFO - 2022-01-18 09:45:58 --> Language Class Initialized
INFO - 2022-01-18 09:45:58 --> Language Class Initialized
INFO - 2022-01-18 09:45:58 --> Config Class Initialized
INFO - 2022-01-18 09:45:58 --> Loader Class Initialized
INFO - 2022-01-18 09:45:58 --> Helper loaded: url_helper
INFO - 2022-01-18 09:45:58 --> Helper loaded: file_helper
INFO - 2022-01-18 09:45:58 --> Helper loaded: form_helper
INFO - 2022-01-18 09:45:58 --> Helper loaded: my_helper
INFO - 2022-01-18 09:45:58 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:45:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:45:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:45:58 --> Controller Class Initialized
DEBUG - 2022-01-18 09:45:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-01-18 09:45:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:45:58 --> Final output sent to browser
DEBUG - 2022-01-18 09:45:58 --> Total execution time: 0.2730
INFO - 2022-01-18 09:46:01 --> Config Class Initialized
INFO - 2022-01-18 09:46:01 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:46:01 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:46:01 --> Utf8 Class Initialized
INFO - 2022-01-18 09:46:01 --> URI Class Initialized
INFO - 2022-01-18 09:46:01 --> Router Class Initialized
INFO - 2022-01-18 09:46:01 --> Output Class Initialized
INFO - 2022-01-18 09:46:01 --> Security Class Initialized
DEBUG - 2022-01-18 09:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:46:01 --> Input Class Initialized
INFO - 2022-01-18 09:46:01 --> Language Class Initialized
INFO - 2022-01-18 09:46:01 --> Language Class Initialized
INFO - 2022-01-18 09:46:01 --> Config Class Initialized
INFO - 2022-01-18 09:46:01 --> Loader Class Initialized
INFO - 2022-01-18 09:46:01 --> Helper loaded: url_helper
INFO - 2022-01-18 09:46:01 --> Helper loaded: file_helper
INFO - 2022-01-18 09:46:01 --> Helper loaded: form_helper
INFO - 2022-01-18 09:46:01 --> Helper loaded: my_helper
INFO - 2022-01-18 09:46:01 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:46:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:46:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:46:01 --> Controller Class Initialized
DEBUG - 2022-01-18 09:46:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2022-01-18 09:46:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:46:01 --> Final output sent to browser
DEBUG - 2022-01-18 09:46:01 --> Total execution time: 0.1020
INFO - 2022-01-18 09:46:04 --> Config Class Initialized
INFO - 2022-01-18 09:46:04 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:46:04 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:46:04 --> Utf8 Class Initialized
INFO - 2022-01-18 09:46:04 --> URI Class Initialized
INFO - 2022-01-18 09:46:04 --> Router Class Initialized
INFO - 2022-01-18 09:46:04 --> Output Class Initialized
INFO - 2022-01-18 09:46:04 --> Security Class Initialized
DEBUG - 2022-01-18 09:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:46:04 --> Input Class Initialized
INFO - 2022-01-18 09:46:04 --> Language Class Initialized
INFO - 2022-01-18 09:46:04 --> Language Class Initialized
INFO - 2022-01-18 09:46:04 --> Config Class Initialized
INFO - 2022-01-18 09:46:04 --> Loader Class Initialized
INFO - 2022-01-18 09:46:04 --> Helper loaded: url_helper
INFO - 2022-01-18 09:46:04 --> Helper loaded: file_helper
INFO - 2022-01-18 09:46:04 --> Helper loaded: form_helper
INFO - 2022-01-18 09:46:04 --> Helper loaded: my_helper
INFO - 2022-01-18 09:46:04 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:46:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:46:04 --> Controller Class Initialized
DEBUG - 2022-01-18 09:46:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2022-01-18 09:46:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:46:04 --> Final output sent to browser
DEBUG - 2022-01-18 09:46:04 --> Total execution time: 0.0580
INFO - 2022-01-18 09:46:06 --> Config Class Initialized
INFO - 2022-01-18 09:46:06 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:46:06 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:46:06 --> Utf8 Class Initialized
INFO - 2022-01-18 09:46:06 --> URI Class Initialized
INFO - 2022-01-18 09:46:06 --> Router Class Initialized
INFO - 2022-01-18 09:46:06 --> Output Class Initialized
INFO - 2022-01-18 09:46:06 --> Security Class Initialized
DEBUG - 2022-01-18 09:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:46:06 --> Input Class Initialized
INFO - 2022-01-18 09:46:06 --> Language Class Initialized
INFO - 2022-01-18 09:46:06 --> Language Class Initialized
INFO - 2022-01-18 09:46:06 --> Config Class Initialized
INFO - 2022-01-18 09:46:06 --> Loader Class Initialized
INFO - 2022-01-18 09:46:06 --> Helper loaded: url_helper
INFO - 2022-01-18 09:46:06 --> Helper loaded: file_helper
INFO - 2022-01-18 09:46:06 --> Helper loaded: form_helper
INFO - 2022-01-18 09:46:06 --> Helper loaded: my_helper
INFO - 2022-01-18 09:46:06 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:46:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:46:06 --> Controller Class Initialized
DEBUG - 2022-01-18 09:46:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-01-18 09:46:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:46:06 --> Final output sent to browser
DEBUG - 2022-01-18 09:46:06 --> Total execution time: 0.0490
INFO - 2022-01-18 09:46:07 --> Config Class Initialized
INFO - 2022-01-18 09:46:07 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:46:07 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:46:07 --> Utf8 Class Initialized
INFO - 2022-01-18 09:46:07 --> URI Class Initialized
INFO - 2022-01-18 09:46:07 --> Router Class Initialized
INFO - 2022-01-18 09:46:07 --> Output Class Initialized
INFO - 2022-01-18 09:46:07 --> Security Class Initialized
DEBUG - 2022-01-18 09:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:46:07 --> Input Class Initialized
INFO - 2022-01-18 09:46:07 --> Language Class Initialized
INFO - 2022-01-18 09:46:07 --> Language Class Initialized
INFO - 2022-01-18 09:46:07 --> Config Class Initialized
INFO - 2022-01-18 09:46:07 --> Loader Class Initialized
INFO - 2022-01-18 09:46:07 --> Helper loaded: url_helper
INFO - 2022-01-18 09:46:07 --> Helper loaded: file_helper
INFO - 2022-01-18 09:46:07 --> Helper loaded: form_helper
INFO - 2022-01-18 09:46:07 --> Helper loaded: my_helper
INFO - 2022-01-18 09:46:07 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:46:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:46:07 --> Controller Class Initialized
INFO - 2022-01-18 09:46:07 --> Final output sent to browser
DEBUG - 2022-01-18 09:46:07 --> Total execution time: 0.0496
INFO - 2022-01-18 09:47:40 --> Config Class Initialized
INFO - 2022-01-18 09:47:40 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:47:40 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:47:40 --> Utf8 Class Initialized
INFO - 2022-01-18 09:47:40 --> URI Class Initialized
INFO - 2022-01-18 09:47:40 --> Router Class Initialized
INFO - 2022-01-18 09:47:40 --> Output Class Initialized
INFO - 2022-01-18 09:47:40 --> Security Class Initialized
DEBUG - 2022-01-18 09:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:47:40 --> Input Class Initialized
INFO - 2022-01-18 09:47:40 --> Language Class Initialized
INFO - 2022-01-18 09:47:40 --> Language Class Initialized
INFO - 2022-01-18 09:47:40 --> Config Class Initialized
INFO - 2022-01-18 09:47:40 --> Loader Class Initialized
INFO - 2022-01-18 09:47:40 --> Helper loaded: url_helper
INFO - 2022-01-18 09:47:40 --> Helper loaded: file_helper
INFO - 2022-01-18 09:47:40 --> Helper loaded: form_helper
INFO - 2022-01-18 09:47:40 --> Helper loaded: my_helper
INFO - 2022-01-18 09:47:40 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:47:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:47:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:47:40 --> Controller Class Initialized
INFO - 2022-01-18 09:47:40 --> Final output sent to browser
DEBUG - 2022-01-18 09:47:40 --> Total execution time: 0.0860
INFO - 2022-01-18 09:47:43 --> Config Class Initialized
INFO - 2022-01-18 09:47:43 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:47:43 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:47:43 --> Utf8 Class Initialized
INFO - 2022-01-18 09:47:43 --> URI Class Initialized
INFO - 2022-01-18 09:47:43 --> Router Class Initialized
INFO - 2022-01-18 09:47:43 --> Output Class Initialized
INFO - 2022-01-18 09:47:43 --> Security Class Initialized
DEBUG - 2022-01-18 09:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:47:43 --> Input Class Initialized
INFO - 2022-01-18 09:47:43 --> Language Class Initialized
INFO - 2022-01-18 09:47:43 --> Language Class Initialized
INFO - 2022-01-18 09:47:43 --> Config Class Initialized
INFO - 2022-01-18 09:47:43 --> Loader Class Initialized
INFO - 2022-01-18 09:47:43 --> Helper loaded: url_helper
INFO - 2022-01-18 09:47:43 --> Helper loaded: file_helper
INFO - 2022-01-18 09:47:43 --> Helper loaded: form_helper
INFO - 2022-01-18 09:47:43 --> Helper loaded: my_helper
INFO - 2022-01-18 09:47:43 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:47:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:47:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:47:43 --> Controller Class Initialized
DEBUG - 2022-01-18 09:47:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-01-18 09:47:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:47:43 --> Final output sent to browser
DEBUG - 2022-01-18 09:47:43 --> Total execution time: 0.0410
INFO - 2022-01-18 09:47:45 --> Config Class Initialized
INFO - 2022-01-18 09:47:45 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:47:45 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:47:45 --> Utf8 Class Initialized
INFO - 2022-01-18 09:47:45 --> URI Class Initialized
INFO - 2022-01-18 09:47:45 --> Router Class Initialized
INFO - 2022-01-18 09:47:45 --> Output Class Initialized
INFO - 2022-01-18 09:47:45 --> Security Class Initialized
DEBUG - 2022-01-18 09:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:47:45 --> Input Class Initialized
INFO - 2022-01-18 09:47:45 --> Language Class Initialized
INFO - 2022-01-18 09:47:45 --> Language Class Initialized
INFO - 2022-01-18 09:47:45 --> Config Class Initialized
INFO - 2022-01-18 09:47:45 --> Loader Class Initialized
INFO - 2022-01-18 09:47:45 --> Helper loaded: url_helper
INFO - 2022-01-18 09:47:45 --> Helper loaded: file_helper
INFO - 2022-01-18 09:47:45 --> Helper loaded: form_helper
INFO - 2022-01-18 09:47:45 --> Helper loaded: my_helper
INFO - 2022-01-18 09:47:45 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:47:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:47:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:47:45 --> Controller Class Initialized
INFO - 2022-01-18 09:47:45 --> Final output sent to browser
DEBUG - 2022-01-18 09:47:45 --> Total execution time: 0.0476
INFO - 2022-01-18 09:47:48 --> Config Class Initialized
INFO - 2022-01-18 09:47:48 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:47:48 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:47:48 --> Utf8 Class Initialized
INFO - 2022-01-18 09:47:48 --> URI Class Initialized
INFO - 2022-01-18 09:47:48 --> Router Class Initialized
INFO - 2022-01-18 09:47:48 --> Output Class Initialized
INFO - 2022-01-18 09:47:48 --> Security Class Initialized
DEBUG - 2022-01-18 09:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:47:48 --> Input Class Initialized
INFO - 2022-01-18 09:47:48 --> Language Class Initialized
INFO - 2022-01-18 09:47:48 --> Language Class Initialized
INFO - 2022-01-18 09:47:48 --> Config Class Initialized
INFO - 2022-01-18 09:47:48 --> Loader Class Initialized
INFO - 2022-01-18 09:47:48 --> Helper loaded: url_helper
INFO - 2022-01-18 09:47:48 --> Helper loaded: file_helper
INFO - 2022-01-18 09:47:48 --> Helper loaded: form_helper
INFO - 2022-01-18 09:47:48 --> Helper loaded: my_helper
INFO - 2022-01-18 09:47:48 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:47:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:47:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:47:48 --> Controller Class Initialized
INFO - 2022-01-18 09:47:48 --> Final output sent to browser
DEBUG - 2022-01-18 09:47:48 --> Total execution time: 0.0860
INFO - 2022-01-18 09:47:50 --> Config Class Initialized
INFO - 2022-01-18 09:47:50 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:47:50 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:47:50 --> Utf8 Class Initialized
INFO - 2022-01-18 09:47:50 --> URI Class Initialized
INFO - 2022-01-18 09:47:50 --> Router Class Initialized
INFO - 2022-01-18 09:47:50 --> Output Class Initialized
INFO - 2022-01-18 09:47:50 --> Security Class Initialized
DEBUG - 2022-01-18 09:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:47:50 --> Input Class Initialized
INFO - 2022-01-18 09:47:50 --> Language Class Initialized
INFO - 2022-01-18 09:47:50 --> Language Class Initialized
INFO - 2022-01-18 09:47:50 --> Config Class Initialized
INFO - 2022-01-18 09:47:50 --> Loader Class Initialized
INFO - 2022-01-18 09:47:50 --> Helper loaded: url_helper
INFO - 2022-01-18 09:47:50 --> Helper loaded: file_helper
INFO - 2022-01-18 09:47:50 --> Helper loaded: form_helper
INFO - 2022-01-18 09:47:50 --> Helper loaded: my_helper
INFO - 2022-01-18 09:47:50 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:47:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:47:50 --> Controller Class Initialized
DEBUG - 2022-01-18 09:47:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2022-01-18 09:47:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:47:50 --> Final output sent to browser
DEBUG - 2022-01-18 09:47:50 --> Total execution time: 0.0710
INFO - 2022-01-18 09:47:52 --> Config Class Initialized
INFO - 2022-01-18 09:47:52 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:47:52 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:47:52 --> Utf8 Class Initialized
INFO - 2022-01-18 09:47:52 --> URI Class Initialized
INFO - 2022-01-18 09:47:52 --> Router Class Initialized
INFO - 2022-01-18 09:47:52 --> Output Class Initialized
INFO - 2022-01-18 09:47:52 --> Security Class Initialized
DEBUG - 2022-01-18 09:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:47:52 --> Input Class Initialized
INFO - 2022-01-18 09:47:52 --> Language Class Initialized
INFO - 2022-01-18 09:47:52 --> Language Class Initialized
INFO - 2022-01-18 09:47:52 --> Config Class Initialized
INFO - 2022-01-18 09:47:52 --> Loader Class Initialized
INFO - 2022-01-18 09:47:52 --> Helper loaded: url_helper
INFO - 2022-01-18 09:47:52 --> Helper loaded: file_helper
INFO - 2022-01-18 09:47:52 --> Helper loaded: form_helper
INFO - 2022-01-18 09:47:52 --> Helper loaded: my_helper
INFO - 2022-01-18 09:47:52 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:47:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:47:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:47:52 --> Controller Class Initialized
DEBUG - 2022-01-18 09:47:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2022-01-18 09:47:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:47:52 --> Final output sent to browser
DEBUG - 2022-01-18 09:47:52 --> Total execution time: 0.0970
INFO - 2022-01-18 09:47:54 --> Config Class Initialized
INFO - 2022-01-18 09:47:54 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:47:54 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:47:54 --> Utf8 Class Initialized
INFO - 2022-01-18 09:47:54 --> URI Class Initialized
INFO - 2022-01-18 09:47:54 --> Router Class Initialized
INFO - 2022-01-18 09:47:54 --> Output Class Initialized
INFO - 2022-01-18 09:47:54 --> Security Class Initialized
DEBUG - 2022-01-18 09:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:47:54 --> Input Class Initialized
INFO - 2022-01-18 09:47:54 --> Language Class Initialized
INFO - 2022-01-18 09:47:54 --> Language Class Initialized
INFO - 2022-01-18 09:47:54 --> Config Class Initialized
INFO - 2022-01-18 09:47:54 --> Loader Class Initialized
INFO - 2022-01-18 09:47:54 --> Helper loaded: url_helper
INFO - 2022-01-18 09:47:54 --> Helper loaded: file_helper
INFO - 2022-01-18 09:47:54 --> Helper loaded: form_helper
INFO - 2022-01-18 09:47:54 --> Helper loaded: my_helper
INFO - 2022-01-18 09:47:54 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:47:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:47:54 --> Controller Class Initialized
DEBUG - 2022-01-18 09:47:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2022-01-18 09:47:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:47:54 --> Final output sent to browser
DEBUG - 2022-01-18 09:47:54 --> Total execution time: 0.0530
INFO - 2022-01-18 09:48:06 --> Config Class Initialized
INFO - 2022-01-18 09:48:06 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:48:06 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:48:06 --> Utf8 Class Initialized
INFO - 2022-01-18 09:48:06 --> URI Class Initialized
INFO - 2022-01-18 09:48:06 --> Router Class Initialized
INFO - 2022-01-18 09:48:06 --> Output Class Initialized
INFO - 2022-01-18 09:48:06 --> Security Class Initialized
DEBUG - 2022-01-18 09:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:48:06 --> Input Class Initialized
INFO - 2022-01-18 09:48:06 --> Language Class Initialized
INFO - 2022-01-18 09:48:06 --> Language Class Initialized
INFO - 2022-01-18 09:48:06 --> Config Class Initialized
INFO - 2022-01-18 09:48:06 --> Loader Class Initialized
INFO - 2022-01-18 09:48:06 --> Helper loaded: url_helper
INFO - 2022-01-18 09:48:06 --> Helper loaded: file_helper
INFO - 2022-01-18 09:48:06 --> Helper loaded: form_helper
INFO - 2022-01-18 09:48:06 --> Helper loaded: my_helper
INFO - 2022-01-18 09:48:06 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:48:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:48:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:48:06 --> Controller Class Initialized
INFO - 2022-01-18 09:48:06 --> Helper loaded: cookie_helper
INFO - 2022-01-18 09:48:06 --> Config Class Initialized
INFO - 2022-01-18 09:48:06 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:48:06 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:48:06 --> Utf8 Class Initialized
INFO - 2022-01-18 09:48:06 --> URI Class Initialized
INFO - 2022-01-18 09:48:06 --> Router Class Initialized
INFO - 2022-01-18 09:48:06 --> Output Class Initialized
INFO - 2022-01-18 09:48:06 --> Security Class Initialized
DEBUG - 2022-01-18 09:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:48:06 --> Input Class Initialized
INFO - 2022-01-18 09:48:06 --> Language Class Initialized
INFO - 2022-01-18 09:48:06 --> Language Class Initialized
INFO - 2022-01-18 09:48:06 --> Config Class Initialized
INFO - 2022-01-18 09:48:06 --> Loader Class Initialized
INFO - 2022-01-18 09:48:06 --> Helper loaded: url_helper
INFO - 2022-01-18 09:48:06 --> Helper loaded: file_helper
INFO - 2022-01-18 09:48:06 --> Helper loaded: form_helper
INFO - 2022-01-18 09:48:06 --> Helper loaded: my_helper
INFO - 2022-01-18 09:48:06 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:48:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:48:07 --> Controller Class Initialized
DEBUG - 2022-01-18 09:48:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-01-18 09:48:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:48:07 --> Final output sent to browser
DEBUG - 2022-01-18 09:48:07 --> Total execution time: 0.0400
INFO - 2022-01-18 09:48:15 --> Config Class Initialized
INFO - 2022-01-18 09:48:15 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:48:15 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:48:15 --> Utf8 Class Initialized
INFO - 2022-01-18 09:48:15 --> URI Class Initialized
INFO - 2022-01-18 09:48:15 --> Router Class Initialized
INFO - 2022-01-18 09:48:15 --> Output Class Initialized
INFO - 2022-01-18 09:48:15 --> Security Class Initialized
DEBUG - 2022-01-18 09:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:48:15 --> Input Class Initialized
INFO - 2022-01-18 09:48:15 --> Language Class Initialized
INFO - 2022-01-18 09:48:15 --> Language Class Initialized
INFO - 2022-01-18 09:48:15 --> Config Class Initialized
INFO - 2022-01-18 09:48:15 --> Loader Class Initialized
INFO - 2022-01-18 09:48:15 --> Helper loaded: url_helper
INFO - 2022-01-18 09:48:15 --> Helper loaded: file_helper
INFO - 2022-01-18 09:48:15 --> Helper loaded: form_helper
INFO - 2022-01-18 09:48:15 --> Helper loaded: my_helper
INFO - 2022-01-18 09:48:15 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:48:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:48:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:48:15 --> Controller Class Initialized
INFO - 2022-01-18 09:48:15 --> Final output sent to browser
DEBUG - 2022-01-18 09:48:15 --> Total execution time: 0.0652
INFO - 2022-01-18 09:48:25 --> Config Class Initialized
INFO - 2022-01-18 09:48:25 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:48:25 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:48:25 --> Utf8 Class Initialized
INFO - 2022-01-18 09:48:25 --> URI Class Initialized
INFO - 2022-01-18 09:48:25 --> Router Class Initialized
INFO - 2022-01-18 09:48:25 --> Output Class Initialized
INFO - 2022-01-18 09:48:25 --> Security Class Initialized
DEBUG - 2022-01-18 09:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:48:25 --> Input Class Initialized
INFO - 2022-01-18 09:48:25 --> Language Class Initialized
INFO - 2022-01-18 09:48:25 --> Language Class Initialized
INFO - 2022-01-18 09:48:25 --> Config Class Initialized
INFO - 2022-01-18 09:48:25 --> Loader Class Initialized
INFO - 2022-01-18 09:48:25 --> Helper loaded: url_helper
INFO - 2022-01-18 09:48:25 --> Helper loaded: file_helper
INFO - 2022-01-18 09:48:25 --> Helper loaded: form_helper
INFO - 2022-01-18 09:48:25 --> Helper loaded: my_helper
INFO - 2022-01-18 09:48:25 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:48:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:48:25 --> Controller Class Initialized
INFO - 2022-01-18 09:48:25 --> Final output sent to browser
DEBUG - 2022-01-18 09:48:25 --> Total execution time: 0.0632
INFO - 2022-01-18 09:48:32 --> Config Class Initialized
INFO - 2022-01-18 09:48:32 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:48:32 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:48:32 --> Utf8 Class Initialized
INFO - 2022-01-18 09:48:32 --> URI Class Initialized
INFO - 2022-01-18 09:48:32 --> Router Class Initialized
INFO - 2022-01-18 09:48:32 --> Output Class Initialized
INFO - 2022-01-18 09:48:32 --> Security Class Initialized
DEBUG - 2022-01-18 09:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:48:32 --> Input Class Initialized
INFO - 2022-01-18 09:48:32 --> Language Class Initialized
INFO - 2022-01-18 09:48:32 --> Language Class Initialized
INFO - 2022-01-18 09:48:32 --> Config Class Initialized
INFO - 2022-01-18 09:48:32 --> Loader Class Initialized
INFO - 2022-01-18 09:48:32 --> Helper loaded: url_helper
INFO - 2022-01-18 09:48:32 --> Helper loaded: file_helper
INFO - 2022-01-18 09:48:32 --> Helper loaded: form_helper
INFO - 2022-01-18 09:48:32 --> Helper loaded: my_helper
INFO - 2022-01-18 09:48:32 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:48:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:48:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:48:32 --> Controller Class Initialized
INFO - 2022-01-18 09:48:32 --> Helper loaded: cookie_helper
INFO - 2022-01-18 09:48:32 --> Final output sent to browser
DEBUG - 2022-01-18 09:48:32 --> Total execution time: 0.0572
INFO - 2022-01-18 09:48:33 --> Config Class Initialized
INFO - 2022-01-18 09:48:33 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:48:33 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:48:33 --> Utf8 Class Initialized
INFO - 2022-01-18 09:48:33 --> URI Class Initialized
INFO - 2022-01-18 09:48:33 --> Router Class Initialized
INFO - 2022-01-18 09:48:33 --> Output Class Initialized
INFO - 2022-01-18 09:48:33 --> Security Class Initialized
DEBUG - 2022-01-18 09:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:48:33 --> Input Class Initialized
INFO - 2022-01-18 09:48:33 --> Language Class Initialized
INFO - 2022-01-18 09:48:33 --> Language Class Initialized
INFO - 2022-01-18 09:48:33 --> Config Class Initialized
INFO - 2022-01-18 09:48:33 --> Loader Class Initialized
INFO - 2022-01-18 09:48:33 --> Helper loaded: url_helper
INFO - 2022-01-18 09:48:33 --> Helper loaded: file_helper
INFO - 2022-01-18 09:48:33 --> Helper loaded: form_helper
INFO - 2022-01-18 09:48:33 --> Helper loaded: my_helper
INFO - 2022-01-18 09:48:33 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:48:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:48:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:48:33 --> Controller Class Initialized
DEBUG - 2022-01-18 09:48:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-01-18 09:48:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:48:33 --> Final output sent to browser
DEBUG - 2022-01-18 09:48:33 --> Total execution time: 0.3810
INFO - 2022-01-18 09:48:35 --> Config Class Initialized
INFO - 2022-01-18 09:48:35 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:48:35 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:48:35 --> Utf8 Class Initialized
INFO - 2022-01-18 09:48:35 --> URI Class Initialized
INFO - 2022-01-18 09:48:35 --> Router Class Initialized
INFO - 2022-01-18 09:48:35 --> Output Class Initialized
INFO - 2022-01-18 09:48:35 --> Security Class Initialized
DEBUG - 2022-01-18 09:48:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:48:35 --> Input Class Initialized
INFO - 2022-01-18 09:48:35 --> Language Class Initialized
INFO - 2022-01-18 09:48:35 --> Language Class Initialized
INFO - 2022-01-18 09:48:35 --> Config Class Initialized
INFO - 2022-01-18 09:48:35 --> Loader Class Initialized
INFO - 2022-01-18 09:48:35 --> Helper loaded: url_helper
INFO - 2022-01-18 09:48:35 --> Helper loaded: file_helper
INFO - 2022-01-18 09:48:35 --> Helper loaded: form_helper
INFO - 2022-01-18 09:48:35 --> Helper loaded: my_helper
INFO - 2022-01-18 09:48:35 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:48:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:48:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:48:35 --> Controller Class Initialized
DEBUG - 2022-01-18 09:48:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2022-01-18 09:48:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:48:35 --> Final output sent to browser
DEBUG - 2022-01-18 09:48:35 --> Total execution time: 0.0520
INFO - 2022-01-18 09:48:35 --> Config Class Initialized
INFO - 2022-01-18 09:48:35 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:48:35 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:48:35 --> Utf8 Class Initialized
INFO - 2022-01-18 09:48:35 --> URI Class Initialized
INFO - 2022-01-18 09:48:35 --> Router Class Initialized
INFO - 2022-01-18 09:48:35 --> Output Class Initialized
INFO - 2022-01-18 09:48:35 --> Security Class Initialized
DEBUG - 2022-01-18 09:48:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:48:35 --> Input Class Initialized
INFO - 2022-01-18 09:48:35 --> Language Class Initialized
INFO - 2022-01-18 09:48:35 --> Language Class Initialized
INFO - 2022-01-18 09:48:35 --> Config Class Initialized
INFO - 2022-01-18 09:48:35 --> Loader Class Initialized
INFO - 2022-01-18 09:48:35 --> Helper loaded: url_helper
INFO - 2022-01-18 09:48:35 --> Helper loaded: file_helper
INFO - 2022-01-18 09:48:35 --> Helper loaded: form_helper
INFO - 2022-01-18 09:48:35 --> Helper loaded: my_helper
INFO - 2022-01-18 09:48:35 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:48:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:48:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:48:35 --> Controller Class Initialized
INFO - 2022-01-18 09:48:36 --> Config Class Initialized
INFO - 2022-01-18 09:48:36 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:48:36 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:48:36 --> Utf8 Class Initialized
INFO - 2022-01-18 09:48:36 --> URI Class Initialized
INFO - 2022-01-18 09:48:36 --> Router Class Initialized
INFO - 2022-01-18 09:48:36 --> Output Class Initialized
INFO - 2022-01-18 09:48:36 --> Security Class Initialized
DEBUG - 2022-01-18 09:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:48:36 --> Input Class Initialized
INFO - 2022-01-18 09:48:36 --> Language Class Initialized
INFO - 2022-01-18 09:48:36 --> Language Class Initialized
INFO - 2022-01-18 09:48:36 --> Config Class Initialized
INFO - 2022-01-18 09:48:36 --> Loader Class Initialized
INFO - 2022-01-18 09:48:36 --> Helper loaded: url_helper
INFO - 2022-01-18 09:48:36 --> Helper loaded: file_helper
INFO - 2022-01-18 09:48:36 --> Helper loaded: form_helper
INFO - 2022-01-18 09:48:36 --> Helper loaded: my_helper
INFO - 2022-01-18 09:48:36 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:48:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:48:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:48:36 --> Controller Class Initialized
INFO - 2022-01-18 09:48:36 --> Final output sent to browser
DEBUG - 2022-01-18 09:48:36 --> Total execution time: 0.0530
INFO - 2022-01-18 09:48:36 --> Config Class Initialized
INFO - 2022-01-18 09:48:36 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:48:36 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:48:36 --> Utf8 Class Initialized
INFO - 2022-01-18 09:48:36 --> URI Class Initialized
INFO - 2022-01-18 09:48:36 --> Router Class Initialized
INFO - 2022-01-18 09:48:36 --> Output Class Initialized
INFO - 2022-01-18 09:48:36 --> Security Class Initialized
DEBUG - 2022-01-18 09:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:48:36 --> Input Class Initialized
INFO - 2022-01-18 09:48:36 --> Language Class Initialized
INFO - 2022-01-18 09:48:36 --> Language Class Initialized
INFO - 2022-01-18 09:48:36 --> Config Class Initialized
INFO - 2022-01-18 09:48:36 --> Loader Class Initialized
INFO - 2022-01-18 09:48:36 --> Helper loaded: url_helper
INFO - 2022-01-18 09:48:36 --> Helper loaded: file_helper
INFO - 2022-01-18 09:48:36 --> Helper loaded: form_helper
INFO - 2022-01-18 09:48:36 --> Helper loaded: my_helper
INFO - 2022-01-18 09:48:36 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:48:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:48:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:48:36 --> Controller Class Initialized
INFO - 2022-01-18 09:48:43 --> Config Class Initialized
INFO - 2022-01-18 09:48:43 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:48:43 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:48:43 --> Utf8 Class Initialized
INFO - 2022-01-18 09:48:43 --> URI Class Initialized
INFO - 2022-01-18 09:48:43 --> Router Class Initialized
INFO - 2022-01-18 09:48:43 --> Output Class Initialized
INFO - 2022-01-18 09:48:43 --> Security Class Initialized
DEBUG - 2022-01-18 09:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:48:43 --> Input Class Initialized
INFO - 2022-01-18 09:48:43 --> Language Class Initialized
INFO - 2022-01-18 09:48:43 --> Language Class Initialized
INFO - 2022-01-18 09:48:43 --> Config Class Initialized
INFO - 2022-01-18 09:48:43 --> Loader Class Initialized
INFO - 2022-01-18 09:48:43 --> Helper loaded: url_helper
INFO - 2022-01-18 09:48:43 --> Helper loaded: file_helper
INFO - 2022-01-18 09:48:43 --> Helper loaded: form_helper
INFO - 2022-01-18 09:48:43 --> Helper loaded: my_helper
INFO - 2022-01-18 09:48:43 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:48:43 --> Controller Class Initialized
INFO - 2022-01-18 09:48:43 --> Helper loaded: cookie_helper
INFO - 2022-01-18 09:48:43 --> Config Class Initialized
INFO - 2022-01-18 09:48:43 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:48:43 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:48:43 --> Utf8 Class Initialized
INFO - 2022-01-18 09:48:43 --> URI Class Initialized
INFO - 2022-01-18 09:48:43 --> Router Class Initialized
INFO - 2022-01-18 09:48:43 --> Output Class Initialized
INFO - 2022-01-18 09:48:43 --> Security Class Initialized
DEBUG - 2022-01-18 09:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:48:43 --> Input Class Initialized
INFO - 2022-01-18 09:48:43 --> Language Class Initialized
INFO - 2022-01-18 09:48:43 --> Language Class Initialized
INFO - 2022-01-18 09:48:43 --> Config Class Initialized
INFO - 2022-01-18 09:48:43 --> Loader Class Initialized
INFO - 2022-01-18 09:48:43 --> Helper loaded: url_helper
INFO - 2022-01-18 09:48:43 --> Helper loaded: file_helper
INFO - 2022-01-18 09:48:43 --> Helper loaded: form_helper
INFO - 2022-01-18 09:48:43 --> Helper loaded: my_helper
INFO - 2022-01-18 09:48:43 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:48:43 --> Controller Class Initialized
DEBUG - 2022-01-18 09:48:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-01-18 09:48:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:48:43 --> Final output sent to browser
DEBUG - 2022-01-18 09:48:43 --> Total execution time: 0.0380
INFO - 2022-01-18 09:48:51 --> Config Class Initialized
INFO - 2022-01-18 09:48:51 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:48:51 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:48:51 --> Utf8 Class Initialized
INFO - 2022-01-18 09:48:51 --> URI Class Initialized
INFO - 2022-01-18 09:48:51 --> Router Class Initialized
INFO - 2022-01-18 09:48:51 --> Output Class Initialized
INFO - 2022-01-18 09:48:51 --> Security Class Initialized
DEBUG - 2022-01-18 09:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:48:51 --> Input Class Initialized
INFO - 2022-01-18 09:48:51 --> Language Class Initialized
INFO - 2022-01-18 09:48:51 --> Language Class Initialized
INFO - 2022-01-18 09:48:51 --> Config Class Initialized
INFO - 2022-01-18 09:48:51 --> Loader Class Initialized
INFO - 2022-01-18 09:48:51 --> Helper loaded: url_helper
INFO - 2022-01-18 09:48:51 --> Helper loaded: file_helper
INFO - 2022-01-18 09:48:51 --> Helper loaded: form_helper
INFO - 2022-01-18 09:48:51 --> Helper loaded: my_helper
INFO - 2022-01-18 09:48:51 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:48:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:48:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:48:51 --> Controller Class Initialized
INFO - 2022-01-18 09:48:51 --> Helper loaded: cookie_helper
INFO - 2022-01-18 09:48:51 --> Final output sent to browser
DEBUG - 2022-01-18 09:48:51 --> Total execution time: 0.0490
INFO - 2022-01-18 09:48:52 --> Config Class Initialized
INFO - 2022-01-18 09:48:52 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:48:52 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:48:52 --> Utf8 Class Initialized
INFO - 2022-01-18 09:48:52 --> URI Class Initialized
INFO - 2022-01-18 09:48:52 --> Router Class Initialized
INFO - 2022-01-18 09:48:52 --> Output Class Initialized
INFO - 2022-01-18 09:48:52 --> Security Class Initialized
DEBUG - 2022-01-18 09:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:48:52 --> Input Class Initialized
INFO - 2022-01-18 09:48:52 --> Language Class Initialized
INFO - 2022-01-18 09:48:52 --> Language Class Initialized
INFO - 2022-01-18 09:48:52 --> Config Class Initialized
INFO - 2022-01-18 09:48:52 --> Loader Class Initialized
INFO - 2022-01-18 09:48:52 --> Helper loaded: url_helper
INFO - 2022-01-18 09:48:52 --> Helper loaded: file_helper
INFO - 2022-01-18 09:48:52 --> Helper loaded: form_helper
INFO - 2022-01-18 09:48:52 --> Helper loaded: my_helper
INFO - 2022-01-18 09:48:52 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:48:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:48:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:48:52 --> Controller Class Initialized
DEBUG - 2022-01-18 09:48:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-01-18 09:48:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:48:53 --> Final output sent to browser
DEBUG - 2022-01-18 09:48:53 --> Total execution time: 0.2570
INFO - 2022-01-18 09:49:00 --> Config Class Initialized
INFO - 2022-01-18 09:49:00 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:49:00 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:49:00 --> Utf8 Class Initialized
INFO - 2022-01-18 09:49:00 --> URI Class Initialized
INFO - 2022-01-18 09:49:00 --> Router Class Initialized
INFO - 2022-01-18 09:49:00 --> Output Class Initialized
INFO - 2022-01-18 09:49:00 --> Security Class Initialized
DEBUG - 2022-01-18 09:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:49:00 --> Input Class Initialized
INFO - 2022-01-18 09:49:00 --> Language Class Initialized
INFO - 2022-01-18 09:49:00 --> Language Class Initialized
INFO - 2022-01-18 09:49:00 --> Config Class Initialized
INFO - 2022-01-18 09:49:00 --> Loader Class Initialized
INFO - 2022-01-18 09:49:00 --> Helper loaded: url_helper
INFO - 2022-01-18 09:49:00 --> Helper loaded: file_helper
INFO - 2022-01-18 09:49:00 --> Helper loaded: form_helper
INFO - 2022-01-18 09:49:00 --> Helper loaded: my_helper
INFO - 2022-01-18 09:49:00 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:49:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:49:00 --> Controller Class Initialized
DEBUG - 2022-01-18 09:49:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2022-01-18 09:49:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:49:00 --> Final output sent to browser
DEBUG - 2022-01-18 09:49:00 --> Total execution time: 0.1010
INFO - 2022-01-18 09:49:02 --> Config Class Initialized
INFO - 2022-01-18 09:49:02 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:49:02 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:49:02 --> Utf8 Class Initialized
INFO - 2022-01-18 09:49:02 --> URI Class Initialized
INFO - 2022-01-18 09:49:02 --> Router Class Initialized
INFO - 2022-01-18 09:49:02 --> Output Class Initialized
INFO - 2022-01-18 09:49:02 --> Security Class Initialized
DEBUG - 2022-01-18 09:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:49:02 --> Input Class Initialized
INFO - 2022-01-18 09:49:02 --> Language Class Initialized
INFO - 2022-01-18 09:49:02 --> Language Class Initialized
INFO - 2022-01-18 09:49:02 --> Config Class Initialized
INFO - 2022-01-18 09:49:02 --> Loader Class Initialized
INFO - 2022-01-18 09:49:02 --> Helper loaded: url_helper
INFO - 2022-01-18 09:49:02 --> Helper loaded: file_helper
INFO - 2022-01-18 09:49:02 --> Helper loaded: form_helper
INFO - 2022-01-18 09:49:02 --> Helper loaded: my_helper
INFO - 2022-01-18 09:49:02 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:49:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:49:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:49:02 --> Controller Class Initialized
DEBUG - 2022-01-18 09:49:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2022-01-18 09:49:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:49:02 --> Final output sent to browser
DEBUG - 2022-01-18 09:49:02 --> Total execution time: 0.0550
INFO - 2022-01-18 09:49:20 --> Config Class Initialized
INFO - 2022-01-18 09:49:20 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:49:20 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:49:20 --> Utf8 Class Initialized
INFO - 2022-01-18 09:49:20 --> URI Class Initialized
INFO - 2022-01-18 09:49:20 --> Router Class Initialized
INFO - 2022-01-18 09:49:20 --> Output Class Initialized
INFO - 2022-01-18 09:49:20 --> Security Class Initialized
DEBUG - 2022-01-18 09:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:49:20 --> Input Class Initialized
INFO - 2022-01-18 09:49:20 --> Language Class Initialized
INFO - 2022-01-18 09:49:20 --> Language Class Initialized
INFO - 2022-01-18 09:49:20 --> Config Class Initialized
INFO - 2022-01-18 09:49:20 --> Loader Class Initialized
INFO - 2022-01-18 09:49:20 --> Helper loaded: url_helper
INFO - 2022-01-18 09:49:20 --> Helper loaded: file_helper
INFO - 2022-01-18 09:49:20 --> Helper loaded: form_helper
INFO - 2022-01-18 09:49:20 --> Helper loaded: my_helper
INFO - 2022-01-18 09:49:20 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:49:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:49:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:49:20 --> Controller Class Initialized
DEBUG - 2022-01-18 09:49:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-01-18 09:49:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:49:20 --> Final output sent to browser
DEBUG - 2022-01-18 09:49:20 --> Total execution time: 0.0500
INFO - 2022-01-18 09:49:21 --> Config Class Initialized
INFO - 2022-01-18 09:49:21 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:49:21 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:49:21 --> Utf8 Class Initialized
INFO - 2022-01-18 09:49:21 --> URI Class Initialized
INFO - 2022-01-18 09:49:21 --> Router Class Initialized
INFO - 2022-01-18 09:49:21 --> Output Class Initialized
INFO - 2022-01-18 09:49:21 --> Security Class Initialized
DEBUG - 2022-01-18 09:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:49:21 --> Input Class Initialized
INFO - 2022-01-18 09:49:21 --> Language Class Initialized
INFO - 2022-01-18 09:49:21 --> Language Class Initialized
INFO - 2022-01-18 09:49:21 --> Config Class Initialized
INFO - 2022-01-18 09:49:21 --> Loader Class Initialized
INFO - 2022-01-18 09:49:21 --> Helper loaded: url_helper
INFO - 2022-01-18 09:49:21 --> Helper loaded: file_helper
INFO - 2022-01-18 09:49:21 --> Helper loaded: form_helper
INFO - 2022-01-18 09:49:21 --> Helper loaded: my_helper
INFO - 2022-01-18 09:49:21 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:49:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:49:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:49:21 --> Controller Class Initialized
DEBUG - 2022-01-18 09:49:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2022-01-18 09:49:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:49:21 --> Final output sent to browser
DEBUG - 2022-01-18 09:49:21 --> Total execution time: 0.0560
INFO - 2022-01-18 09:49:22 --> Config Class Initialized
INFO - 2022-01-18 09:49:22 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:49:22 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:49:22 --> Utf8 Class Initialized
INFO - 2022-01-18 09:49:22 --> URI Class Initialized
INFO - 2022-01-18 09:49:22 --> Router Class Initialized
INFO - 2022-01-18 09:49:22 --> Output Class Initialized
INFO - 2022-01-18 09:49:23 --> Security Class Initialized
DEBUG - 2022-01-18 09:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:49:23 --> Input Class Initialized
INFO - 2022-01-18 09:49:23 --> Language Class Initialized
INFO - 2022-01-18 09:49:23 --> Language Class Initialized
INFO - 2022-01-18 09:49:23 --> Config Class Initialized
INFO - 2022-01-18 09:49:23 --> Loader Class Initialized
INFO - 2022-01-18 09:49:23 --> Helper loaded: url_helper
INFO - 2022-01-18 09:49:23 --> Helper loaded: file_helper
INFO - 2022-01-18 09:49:23 --> Helper loaded: form_helper
INFO - 2022-01-18 09:49:23 --> Helper loaded: my_helper
INFO - 2022-01-18 09:49:23 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:49:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:49:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:49:23 --> Controller Class Initialized
DEBUG - 2022-01-18 09:49:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-01-18 09:49:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:49:23 --> Final output sent to browser
DEBUG - 2022-01-18 09:49:23 --> Total execution time: 0.0520
INFO - 2022-01-18 09:49:24 --> Config Class Initialized
INFO - 2022-01-18 09:49:24 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:49:24 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:49:24 --> Utf8 Class Initialized
INFO - 2022-01-18 09:49:24 --> URI Class Initialized
INFO - 2022-01-18 09:49:24 --> Router Class Initialized
INFO - 2022-01-18 09:49:24 --> Output Class Initialized
INFO - 2022-01-18 09:49:24 --> Security Class Initialized
DEBUG - 2022-01-18 09:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:49:24 --> Input Class Initialized
INFO - 2022-01-18 09:49:24 --> Language Class Initialized
INFO - 2022-01-18 09:49:24 --> Language Class Initialized
INFO - 2022-01-18 09:49:24 --> Config Class Initialized
INFO - 2022-01-18 09:49:24 --> Loader Class Initialized
INFO - 2022-01-18 09:49:24 --> Helper loaded: url_helper
INFO - 2022-01-18 09:49:24 --> Helper loaded: file_helper
INFO - 2022-01-18 09:49:24 --> Helper loaded: form_helper
INFO - 2022-01-18 09:49:24 --> Helper loaded: my_helper
INFO - 2022-01-18 09:49:24 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:49:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:49:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:49:24 --> Controller Class Initialized
INFO - 2022-01-18 09:49:24 --> Final output sent to browser
DEBUG - 2022-01-18 09:49:24 --> Total execution time: 0.0526
INFO - 2022-01-18 09:49:59 --> Config Class Initialized
INFO - 2022-01-18 09:49:59 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:49:59 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:49:59 --> Utf8 Class Initialized
INFO - 2022-01-18 09:49:59 --> URI Class Initialized
INFO - 2022-01-18 09:49:59 --> Router Class Initialized
INFO - 2022-01-18 09:49:59 --> Output Class Initialized
INFO - 2022-01-18 09:49:59 --> Security Class Initialized
DEBUG - 2022-01-18 09:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:49:59 --> Input Class Initialized
INFO - 2022-01-18 09:49:59 --> Language Class Initialized
INFO - 2022-01-18 09:49:59 --> Language Class Initialized
INFO - 2022-01-18 09:49:59 --> Config Class Initialized
INFO - 2022-01-18 09:49:59 --> Loader Class Initialized
INFO - 2022-01-18 09:49:59 --> Helper loaded: url_helper
INFO - 2022-01-18 09:49:59 --> Helper loaded: file_helper
INFO - 2022-01-18 09:49:59 --> Helper loaded: form_helper
INFO - 2022-01-18 09:49:59 --> Helper loaded: my_helper
INFO - 2022-01-18 09:49:59 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:49:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:49:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:49:59 --> Controller Class Initialized
INFO - 2022-01-18 09:49:59 --> Final output sent to browser
DEBUG - 2022-01-18 09:49:59 --> Total execution time: 0.0680
INFO - 2022-01-18 09:50:02 --> Config Class Initialized
INFO - 2022-01-18 09:50:02 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:50:02 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:50:02 --> Utf8 Class Initialized
INFO - 2022-01-18 09:50:02 --> URI Class Initialized
INFO - 2022-01-18 09:50:02 --> Router Class Initialized
INFO - 2022-01-18 09:50:02 --> Output Class Initialized
INFO - 2022-01-18 09:50:02 --> Security Class Initialized
DEBUG - 2022-01-18 09:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:50:02 --> Input Class Initialized
INFO - 2022-01-18 09:50:02 --> Language Class Initialized
INFO - 2022-01-18 09:50:02 --> Language Class Initialized
INFO - 2022-01-18 09:50:02 --> Config Class Initialized
INFO - 2022-01-18 09:50:02 --> Loader Class Initialized
INFO - 2022-01-18 09:50:02 --> Helper loaded: url_helper
INFO - 2022-01-18 09:50:02 --> Helper loaded: file_helper
INFO - 2022-01-18 09:50:02 --> Helper loaded: form_helper
INFO - 2022-01-18 09:50:02 --> Helper loaded: my_helper
INFO - 2022-01-18 09:50:02 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:50:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:50:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:50:02 --> Controller Class Initialized
DEBUG - 2022-01-18 09:50:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2022-01-18 09:50:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:50:02 --> Final output sent to browser
DEBUG - 2022-01-18 09:50:02 --> Total execution time: 0.0490
INFO - 2022-01-18 09:50:06 --> Config Class Initialized
INFO - 2022-01-18 09:50:06 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:50:06 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:50:06 --> Utf8 Class Initialized
INFO - 2022-01-18 09:50:06 --> URI Class Initialized
INFO - 2022-01-18 09:50:06 --> Router Class Initialized
INFO - 2022-01-18 09:50:06 --> Output Class Initialized
INFO - 2022-01-18 09:50:06 --> Security Class Initialized
DEBUG - 2022-01-18 09:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:50:06 --> Input Class Initialized
INFO - 2022-01-18 09:50:06 --> Language Class Initialized
INFO - 2022-01-18 09:50:06 --> Language Class Initialized
INFO - 2022-01-18 09:50:06 --> Config Class Initialized
INFO - 2022-01-18 09:50:06 --> Loader Class Initialized
INFO - 2022-01-18 09:50:06 --> Helper loaded: url_helper
INFO - 2022-01-18 09:50:06 --> Helper loaded: file_helper
INFO - 2022-01-18 09:50:06 --> Helper loaded: form_helper
INFO - 2022-01-18 09:50:06 --> Helper loaded: my_helper
INFO - 2022-01-18 09:50:06 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:50:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:50:06 --> Controller Class Initialized
DEBUG - 2022-01-18 09:50:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-01-18 09:50:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:50:06 --> Final output sent to browser
DEBUG - 2022-01-18 09:50:06 --> Total execution time: 0.0460
INFO - 2022-01-18 09:50:07 --> Config Class Initialized
INFO - 2022-01-18 09:50:07 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:50:07 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:50:07 --> Utf8 Class Initialized
INFO - 2022-01-18 09:50:07 --> URI Class Initialized
INFO - 2022-01-18 09:50:07 --> Router Class Initialized
INFO - 2022-01-18 09:50:07 --> Output Class Initialized
INFO - 2022-01-18 09:50:07 --> Security Class Initialized
DEBUG - 2022-01-18 09:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:50:07 --> Input Class Initialized
INFO - 2022-01-18 09:50:07 --> Language Class Initialized
INFO - 2022-01-18 09:50:07 --> Language Class Initialized
INFO - 2022-01-18 09:50:07 --> Config Class Initialized
INFO - 2022-01-18 09:50:07 --> Loader Class Initialized
INFO - 2022-01-18 09:50:07 --> Helper loaded: url_helper
INFO - 2022-01-18 09:50:07 --> Helper loaded: file_helper
INFO - 2022-01-18 09:50:07 --> Helper loaded: form_helper
INFO - 2022-01-18 09:50:07 --> Helper loaded: my_helper
INFO - 2022-01-18 09:50:07 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:50:07 --> Controller Class Initialized
INFO - 2022-01-18 09:50:07 --> Final output sent to browser
DEBUG - 2022-01-18 09:50:07 --> Total execution time: 0.0632
INFO - 2022-01-18 09:50:11 --> Config Class Initialized
INFO - 2022-01-18 09:50:11 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:50:11 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:50:11 --> Utf8 Class Initialized
INFO - 2022-01-18 09:50:11 --> URI Class Initialized
INFO - 2022-01-18 09:50:11 --> Router Class Initialized
INFO - 2022-01-18 09:50:11 --> Output Class Initialized
INFO - 2022-01-18 09:50:11 --> Security Class Initialized
DEBUG - 2022-01-18 09:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:50:11 --> Input Class Initialized
INFO - 2022-01-18 09:50:11 --> Language Class Initialized
INFO - 2022-01-18 09:50:11 --> Language Class Initialized
INFO - 2022-01-18 09:50:11 --> Config Class Initialized
INFO - 2022-01-18 09:50:11 --> Loader Class Initialized
INFO - 2022-01-18 09:50:12 --> Helper loaded: url_helper
INFO - 2022-01-18 09:50:12 --> Helper loaded: file_helper
INFO - 2022-01-18 09:50:12 --> Helper loaded: form_helper
INFO - 2022-01-18 09:50:12 --> Helper loaded: my_helper
INFO - 2022-01-18 09:50:12 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:50:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:50:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:50:12 --> Controller Class Initialized
DEBUG - 2022-01-18 09:50:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2022-01-18 09:50:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:50:12 --> Final output sent to browser
DEBUG - 2022-01-18 09:50:12 --> Total execution time: 0.0730
INFO - 2022-01-18 09:50:23 --> Config Class Initialized
INFO - 2022-01-18 09:50:23 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:50:23 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:50:23 --> Utf8 Class Initialized
INFO - 2022-01-18 09:50:23 --> URI Class Initialized
INFO - 2022-01-18 09:50:23 --> Router Class Initialized
INFO - 2022-01-18 09:50:23 --> Output Class Initialized
INFO - 2022-01-18 09:50:23 --> Security Class Initialized
DEBUG - 2022-01-18 09:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:50:23 --> Input Class Initialized
INFO - 2022-01-18 09:50:23 --> Language Class Initialized
INFO - 2022-01-18 09:50:23 --> Language Class Initialized
INFO - 2022-01-18 09:50:23 --> Config Class Initialized
INFO - 2022-01-18 09:50:23 --> Loader Class Initialized
INFO - 2022-01-18 09:50:23 --> Helper loaded: url_helper
INFO - 2022-01-18 09:50:23 --> Helper loaded: file_helper
INFO - 2022-01-18 09:50:23 --> Helper loaded: form_helper
INFO - 2022-01-18 09:50:23 --> Helper loaded: my_helper
INFO - 2022-01-18 09:50:23 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:50:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:50:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:50:23 --> Controller Class Initialized
INFO - 2022-01-18 09:50:23 --> Helper loaded: cookie_helper
INFO - 2022-01-18 09:50:23 --> Config Class Initialized
INFO - 2022-01-18 09:50:23 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:50:23 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:50:23 --> Utf8 Class Initialized
INFO - 2022-01-18 09:50:23 --> URI Class Initialized
INFO - 2022-01-18 09:50:23 --> Router Class Initialized
INFO - 2022-01-18 09:50:23 --> Output Class Initialized
INFO - 2022-01-18 09:50:23 --> Security Class Initialized
DEBUG - 2022-01-18 09:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:50:23 --> Input Class Initialized
INFO - 2022-01-18 09:50:23 --> Language Class Initialized
INFO - 2022-01-18 09:50:23 --> Language Class Initialized
INFO - 2022-01-18 09:50:23 --> Config Class Initialized
INFO - 2022-01-18 09:50:23 --> Loader Class Initialized
INFO - 2022-01-18 09:50:23 --> Helper loaded: url_helper
INFO - 2022-01-18 09:50:23 --> Helper loaded: file_helper
INFO - 2022-01-18 09:50:23 --> Helper loaded: form_helper
INFO - 2022-01-18 09:50:23 --> Helper loaded: my_helper
INFO - 2022-01-18 09:50:23 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:50:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:50:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:50:23 --> Controller Class Initialized
DEBUG - 2022-01-18 09:50:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-01-18 09:50:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:50:23 --> Final output sent to browser
DEBUG - 2022-01-18 09:50:23 --> Total execution time: 0.0360
INFO - 2022-01-18 09:50:38 --> Config Class Initialized
INFO - 2022-01-18 09:50:38 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:50:38 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:50:38 --> Utf8 Class Initialized
INFO - 2022-01-18 09:50:38 --> URI Class Initialized
INFO - 2022-01-18 09:50:38 --> Router Class Initialized
INFO - 2022-01-18 09:50:38 --> Output Class Initialized
INFO - 2022-01-18 09:50:38 --> Security Class Initialized
DEBUG - 2022-01-18 09:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:50:38 --> Input Class Initialized
INFO - 2022-01-18 09:50:38 --> Language Class Initialized
INFO - 2022-01-18 09:50:38 --> Language Class Initialized
INFO - 2022-01-18 09:50:38 --> Config Class Initialized
INFO - 2022-01-18 09:50:38 --> Loader Class Initialized
INFO - 2022-01-18 09:50:38 --> Helper loaded: url_helper
INFO - 2022-01-18 09:50:38 --> Helper loaded: file_helper
INFO - 2022-01-18 09:50:38 --> Helper loaded: form_helper
INFO - 2022-01-18 09:50:38 --> Helper loaded: my_helper
INFO - 2022-01-18 09:50:38 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:50:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:50:38 --> Controller Class Initialized
INFO - 2022-01-18 09:50:38 --> Helper loaded: cookie_helper
INFO - 2022-01-18 09:50:38 --> Final output sent to browser
DEBUG - 2022-01-18 09:50:38 --> Total execution time: 0.0466
INFO - 2022-01-18 09:50:38 --> Config Class Initialized
INFO - 2022-01-18 09:50:38 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:50:38 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:50:38 --> Utf8 Class Initialized
INFO - 2022-01-18 09:50:38 --> URI Class Initialized
INFO - 2022-01-18 09:50:38 --> Router Class Initialized
INFO - 2022-01-18 09:50:38 --> Output Class Initialized
INFO - 2022-01-18 09:50:38 --> Security Class Initialized
DEBUG - 2022-01-18 09:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:50:38 --> Input Class Initialized
INFO - 2022-01-18 09:50:38 --> Language Class Initialized
INFO - 2022-01-18 09:50:38 --> Language Class Initialized
INFO - 2022-01-18 09:50:38 --> Config Class Initialized
INFO - 2022-01-18 09:50:38 --> Loader Class Initialized
INFO - 2022-01-18 09:50:38 --> Helper loaded: url_helper
INFO - 2022-01-18 09:50:38 --> Helper loaded: file_helper
INFO - 2022-01-18 09:50:38 --> Helper loaded: form_helper
INFO - 2022-01-18 09:50:38 --> Helper loaded: my_helper
INFO - 2022-01-18 09:50:38 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:50:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:50:38 --> Controller Class Initialized
DEBUG - 2022-01-18 09:50:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-01-18 09:50:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:50:39 --> Final output sent to browser
DEBUG - 2022-01-18 09:50:39 --> Total execution time: 0.3630
INFO - 2022-01-18 09:50:44 --> Config Class Initialized
INFO - 2022-01-18 09:50:44 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:50:44 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:50:44 --> Utf8 Class Initialized
INFO - 2022-01-18 09:50:44 --> URI Class Initialized
INFO - 2022-01-18 09:50:44 --> Router Class Initialized
INFO - 2022-01-18 09:50:44 --> Output Class Initialized
INFO - 2022-01-18 09:50:44 --> Security Class Initialized
DEBUG - 2022-01-18 09:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:50:44 --> Input Class Initialized
INFO - 2022-01-18 09:50:44 --> Language Class Initialized
INFO - 2022-01-18 09:50:44 --> Language Class Initialized
INFO - 2022-01-18 09:50:44 --> Config Class Initialized
INFO - 2022-01-18 09:50:44 --> Loader Class Initialized
INFO - 2022-01-18 09:50:44 --> Helper loaded: url_helper
INFO - 2022-01-18 09:50:44 --> Helper loaded: file_helper
INFO - 2022-01-18 09:50:44 --> Helper loaded: form_helper
INFO - 2022-01-18 09:50:44 --> Helper loaded: my_helper
INFO - 2022-01-18 09:50:44 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:50:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:50:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:50:44 --> Controller Class Initialized
DEBUG - 2022-01-18 09:50:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2022-01-18 09:50:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:50:44 --> Final output sent to browser
DEBUG - 2022-01-18 09:50:44 --> Total execution time: 0.0410
INFO - 2022-01-18 09:50:45 --> Config Class Initialized
INFO - 2022-01-18 09:50:45 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:50:45 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:50:45 --> Utf8 Class Initialized
INFO - 2022-01-18 09:50:45 --> URI Class Initialized
INFO - 2022-01-18 09:50:45 --> Router Class Initialized
INFO - 2022-01-18 09:50:45 --> Output Class Initialized
INFO - 2022-01-18 09:50:45 --> Security Class Initialized
DEBUG - 2022-01-18 09:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:50:45 --> Input Class Initialized
INFO - 2022-01-18 09:50:45 --> Language Class Initialized
INFO - 2022-01-18 09:50:45 --> Language Class Initialized
INFO - 2022-01-18 09:50:45 --> Config Class Initialized
INFO - 2022-01-18 09:50:45 --> Loader Class Initialized
INFO - 2022-01-18 09:50:45 --> Helper loaded: url_helper
INFO - 2022-01-18 09:50:45 --> Helper loaded: file_helper
INFO - 2022-01-18 09:50:45 --> Helper loaded: form_helper
INFO - 2022-01-18 09:50:45 --> Helper loaded: my_helper
INFO - 2022-01-18 09:50:45 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:50:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:50:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:50:45 --> Controller Class Initialized
INFO - 2022-01-18 09:50:46 --> Config Class Initialized
INFO - 2022-01-18 09:50:46 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:50:46 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:50:46 --> Utf8 Class Initialized
INFO - 2022-01-18 09:50:46 --> URI Class Initialized
INFO - 2022-01-18 09:50:46 --> Router Class Initialized
INFO - 2022-01-18 09:50:46 --> Output Class Initialized
INFO - 2022-01-18 09:50:46 --> Security Class Initialized
DEBUG - 2022-01-18 09:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:50:46 --> Input Class Initialized
INFO - 2022-01-18 09:50:46 --> Language Class Initialized
INFO - 2022-01-18 09:50:46 --> Language Class Initialized
INFO - 2022-01-18 09:50:46 --> Config Class Initialized
INFO - 2022-01-18 09:50:46 --> Loader Class Initialized
INFO - 2022-01-18 09:50:46 --> Helper loaded: url_helper
INFO - 2022-01-18 09:50:46 --> Helper loaded: file_helper
INFO - 2022-01-18 09:50:46 --> Helper loaded: form_helper
INFO - 2022-01-18 09:50:46 --> Helper loaded: my_helper
INFO - 2022-01-18 09:50:46 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:50:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:50:46 --> Controller Class Initialized
INFO - 2022-01-18 09:50:46 --> Final output sent to browser
DEBUG - 2022-01-18 09:50:46 --> Total execution time: 0.0530
INFO - 2022-01-18 09:50:46 --> Config Class Initialized
INFO - 2022-01-18 09:50:46 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:50:46 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:50:46 --> Utf8 Class Initialized
INFO - 2022-01-18 09:50:46 --> URI Class Initialized
INFO - 2022-01-18 09:50:46 --> Router Class Initialized
INFO - 2022-01-18 09:50:46 --> Output Class Initialized
INFO - 2022-01-18 09:50:46 --> Security Class Initialized
DEBUG - 2022-01-18 09:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:50:46 --> Input Class Initialized
INFO - 2022-01-18 09:50:46 --> Language Class Initialized
INFO - 2022-01-18 09:50:46 --> Language Class Initialized
INFO - 2022-01-18 09:50:46 --> Config Class Initialized
INFO - 2022-01-18 09:50:46 --> Loader Class Initialized
INFO - 2022-01-18 09:50:46 --> Helper loaded: url_helper
INFO - 2022-01-18 09:50:46 --> Helper loaded: file_helper
INFO - 2022-01-18 09:50:46 --> Helper loaded: form_helper
INFO - 2022-01-18 09:50:46 --> Helper loaded: my_helper
INFO - 2022-01-18 09:50:46 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:50:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:50:46 --> Controller Class Initialized
INFO - 2022-01-18 09:50:56 --> Config Class Initialized
INFO - 2022-01-18 09:50:56 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:50:56 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:50:56 --> Utf8 Class Initialized
INFO - 2022-01-18 09:50:56 --> URI Class Initialized
INFO - 2022-01-18 09:50:56 --> Router Class Initialized
INFO - 2022-01-18 09:50:56 --> Output Class Initialized
INFO - 2022-01-18 09:50:56 --> Security Class Initialized
DEBUG - 2022-01-18 09:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:50:56 --> Input Class Initialized
INFO - 2022-01-18 09:50:56 --> Language Class Initialized
INFO - 2022-01-18 09:50:56 --> Language Class Initialized
INFO - 2022-01-18 09:50:56 --> Config Class Initialized
INFO - 2022-01-18 09:50:56 --> Loader Class Initialized
INFO - 2022-01-18 09:50:56 --> Helper loaded: url_helper
INFO - 2022-01-18 09:50:56 --> Helper loaded: file_helper
INFO - 2022-01-18 09:50:56 --> Helper loaded: form_helper
INFO - 2022-01-18 09:50:56 --> Helper loaded: my_helper
INFO - 2022-01-18 09:50:56 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:50:56 --> Controller Class Initialized
INFO - 2022-01-18 09:50:56 --> Helper loaded: cookie_helper
INFO - 2022-01-18 09:50:56 --> Config Class Initialized
INFO - 2022-01-18 09:50:56 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:50:56 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:50:56 --> Utf8 Class Initialized
INFO - 2022-01-18 09:50:56 --> URI Class Initialized
INFO - 2022-01-18 09:50:56 --> Router Class Initialized
INFO - 2022-01-18 09:50:56 --> Output Class Initialized
INFO - 2022-01-18 09:50:56 --> Security Class Initialized
DEBUG - 2022-01-18 09:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:50:56 --> Input Class Initialized
INFO - 2022-01-18 09:50:56 --> Language Class Initialized
INFO - 2022-01-18 09:50:56 --> Language Class Initialized
INFO - 2022-01-18 09:50:56 --> Config Class Initialized
INFO - 2022-01-18 09:50:56 --> Loader Class Initialized
INFO - 2022-01-18 09:50:56 --> Helper loaded: url_helper
INFO - 2022-01-18 09:50:56 --> Helper loaded: file_helper
INFO - 2022-01-18 09:50:56 --> Helper loaded: form_helper
INFO - 2022-01-18 09:50:56 --> Helper loaded: my_helper
INFO - 2022-01-18 09:50:56 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:50:56 --> Controller Class Initialized
DEBUG - 2022-01-18 09:50:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-01-18 09:50:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:50:56 --> Final output sent to browser
DEBUG - 2022-01-18 09:50:56 --> Total execution time: 0.0350
INFO - 2022-01-18 09:51:05 --> Config Class Initialized
INFO - 2022-01-18 09:51:05 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:51:05 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:51:05 --> Utf8 Class Initialized
INFO - 2022-01-18 09:51:05 --> URI Class Initialized
INFO - 2022-01-18 09:51:05 --> Router Class Initialized
INFO - 2022-01-18 09:51:05 --> Output Class Initialized
INFO - 2022-01-18 09:51:05 --> Security Class Initialized
DEBUG - 2022-01-18 09:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:51:05 --> Input Class Initialized
INFO - 2022-01-18 09:51:05 --> Language Class Initialized
INFO - 2022-01-18 09:51:05 --> Language Class Initialized
INFO - 2022-01-18 09:51:05 --> Config Class Initialized
INFO - 2022-01-18 09:51:05 --> Loader Class Initialized
INFO - 2022-01-18 09:51:05 --> Helper loaded: url_helper
INFO - 2022-01-18 09:51:05 --> Helper loaded: file_helper
INFO - 2022-01-18 09:51:05 --> Helper loaded: form_helper
INFO - 2022-01-18 09:51:05 --> Helper loaded: my_helper
INFO - 2022-01-18 09:51:05 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:51:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:51:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:51:05 --> Controller Class Initialized
INFO - 2022-01-18 09:51:05 --> Helper loaded: cookie_helper
INFO - 2022-01-18 09:51:05 --> Final output sent to browser
DEBUG - 2022-01-18 09:51:05 --> Total execution time: 0.0496
INFO - 2022-01-18 09:51:06 --> Config Class Initialized
INFO - 2022-01-18 09:51:06 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:51:06 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:51:06 --> Utf8 Class Initialized
INFO - 2022-01-18 09:51:06 --> URI Class Initialized
INFO - 2022-01-18 09:51:06 --> Router Class Initialized
INFO - 2022-01-18 09:51:06 --> Output Class Initialized
INFO - 2022-01-18 09:51:06 --> Security Class Initialized
DEBUG - 2022-01-18 09:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:51:06 --> Input Class Initialized
INFO - 2022-01-18 09:51:06 --> Language Class Initialized
INFO - 2022-01-18 09:51:06 --> Language Class Initialized
INFO - 2022-01-18 09:51:06 --> Config Class Initialized
INFO - 2022-01-18 09:51:06 --> Loader Class Initialized
INFO - 2022-01-18 09:51:06 --> Helper loaded: url_helper
INFO - 2022-01-18 09:51:06 --> Helper loaded: file_helper
INFO - 2022-01-18 09:51:06 --> Helper loaded: form_helper
INFO - 2022-01-18 09:51:06 --> Helper loaded: my_helper
INFO - 2022-01-18 09:51:06 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:51:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:51:06 --> Controller Class Initialized
DEBUG - 2022-01-18 09:51:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-01-18 09:51:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:51:06 --> Final output sent to browser
DEBUG - 2022-01-18 09:51:06 --> Total execution time: 0.7780
INFO - 2022-01-18 09:51:12 --> Config Class Initialized
INFO - 2022-01-18 09:51:12 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:51:12 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:51:12 --> Utf8 Class Initialized
INFO - 2022-01-18 09:51:12 --> URI Class Initialized
INFO - 2022-01-18 09:51:12 --> Router Class Initialized
INFO - 2022-01-18 09:51:12 --> Output Class Initialized
INFO - 2022-01-18 09:51:12 --> Security Class Initialized
DEBUG - 2022-01-18 09:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:51:12 --> Input Class Initialized
INFO - 2022-01-18 09:51:12 --> Language Class Initialized
INFO - 2022-01-18 09:51:12 --> Language Class Initialized
INFO - 2022-01-18 09:51:12 --> Config Class Initialized
INFO - 2022-01-18 09:51:12 --> Loader Class Initialized
INFO - 2022-01-18 09:51:12 --> Helper loaded: url_helper
INFO - 2022-01-18 09:51:12 --> Helper loaded: file_helper
INFO - 2022-01-18 09:51:12 --> Helper loaded: form_helper
INFO - 2022-01-18 09:51:12 --> Helper loaded: my_helper
INFO - 2022-01-18 09:51:12 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:51:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:51:12 --> Controller Class Initialized
DEBUG - 2022-01-18 09:51:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2022-01-18 09:51:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:51:12 --> Final output sent to browser
DEBUG - 2022-01-18 09:51:12 --> Total execution time: 0.1070
INFO - 2022-01-18 09:51:14 --> Config Class Initialized
INFO - 2022-01-18 09:51:14 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:51:14 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:51:14 --> Utf8 Class Initialized
INFO - 2022-01-18 09:51:14 --> URI Class Initialized
INFO - 2022-01-18 09:51:14 --> Router Class Initialized
INFO - 2022-01-18 09:51:14 --> Output Class Initialized
INFO - 2022-01-18 09:51:14 --> Security Class Initialized
DEBUG - 2022-01-18 09:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:51:14 --> Input Class Initialized
INFO - 2022-01-18 09:51:14 --> Language Class Initialized
INFO - 2022-01-18 09:51:14 --> Language Class Initialized
INFO - 2022-01-18 09:51:14 --> Config Class Initialized
INFO - 2022-01-18 09:51:14 --> Loader Class Initialized
INFO - 2022-01-18 09:51:14 --> Helper loaded: url_helper
INFO - 2022-01-18 09:51:14 --> Helper loaded: file_helper
INFO - 2022-01-18 09:51:14 --> Helper loaded: form_helper
INFO - 2022-01-18 09:51:14 --> Helper loaded: my_helper
INFO - 2022-01-18 09:51:14 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:51:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:51:14 --> Controller Class Initialized
DEBUG - 2022-01-18 09:51:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2022-01-18 09:51:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:51:14 --> Final output sent to browser
DEBUG - 2022-01-18 09:51:14 --> Total execution time: 0.0650
INFO - 2022-01-18 09:51:16 --> Config Class Initialized
INFO - 2022-01-18 09:51:16 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:51:16 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:51:16 --> Utf8 Class Initialized
INFO - 2022-01-18 09:51:16 --> URI Class Initialized
INFO - 2022-01-18 09:51:16 --> Router Class Initialized
INFO - 2022-01-18 09:51:16 --> Output Class Initialized
INFO - 2022-01-18 09:51:16 --> Security Class Initialized
DEBUG - 2022-01-18 09:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:51:16 --> Input Class Initialized
INFO - 2022-01-18 09:51:16 --> Language Class Initialized
INFO - 2022-01-18 09:51:16 --> Language Class Initialized
INFO - 2022-01-18 09:51:16 --> Config Class Initialized
INFO - 2022-01-18 09:51:16 --> Loader Class Initialized
INFO - 2022-01-18 09:51:16 --> Helper loaded: url_helper
INFO - 2022-01-18 09:51:16 --> Helper loaded: file_helper
INFO - 2022-01-18 09:51:16 --> Helper loaded: form_helper
INFO - 2022-01-18 09:51:16 --> Helper loaded: my_helper
INFO - 2022-01-18 09:51:16 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:51:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:51:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:51:16 --> Controller Class Initialized
DEBUG - 2022-01-18 09:51:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-01-18 09:51:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:51:16 --> Final output sent to browser
DEBUG - 2022-01-18 09:51:16 --> Total execution time: 0.0420
INFO - 2022-01-18 09:51:17 --> Config Class Initialized
INFO - 2022-01-18 09:51:17 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:51:17 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:51:17 --> Utf8 Class Initialized
INFO - 2022-01-18 09:51:17 --> URI Class Initialized
INFO - 2022-01-18 09:51:17 --> Router Class Initialized
INFO - 2022-01-18 09:51:17 --> Output Class Initialized
INFO - 2022-01-18 09:51:17 --> Security Class Initialized
DEBUG - 2022-01-18 09:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:51:17 --> Input Class Initialized
INFO - 2022-01-18 09:51:17 --> Language Class Initialized
INFO - 2022-01-18 09:51:17 --> Language Class Initialized
INFO - 2022-01-18 09:51:17 --> Config Class Initialized
INFO - 2022-01-18 09:51:17 --> Loader Class Initialized
INFO - 2022-01-18 09:51:17 --> Helper loaded: url_helper
INFO - 2022-01-18 09:51:17 --> Helper loaded: file_helper
INFO - 2022-01-18 09:51:17 --> Helper loaded: form_helper
INFO - 2022-01-18 09:51:17 --> Helper loaded: my_helper
INFO - 2022-01-18 09:51:17 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:51:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:51:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:51:17 --> Controller Class Initialized
INFO - 2022-01-18 09:51:17 --> Final output sent to browser
DEBUG - 2022-01-18 09:51:17 --> Total execution time: 0.0562
INFO - 2022-01-18 09:51:20 --> Config Class Initialized
INFO - 2022-01-18 09:51:20 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:51:20 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:51:20 --> Utf8 Class Initialized
INFO - 2022-01-18 09:51:20 --> URI Class Initialized
INFO - 2022-01-18 09:51:20 --> Router Class Initialized
INFO - 2022-01-18 09:51:20 --> Output Class Initialized
INFO - 2022-01-18 09:51:20 --> Security Class Initialized
DEBUG - 2022-01-18 09:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:51:20 --> Input Class Initialized
INFO - 2022-01-18 09:51:20 --> Language Class Initialized
INFO - 2022-01-18 09:51:20 --> Language Class Initialized
INFO - 2022-01-18 09:51:20 --> Config Class Initialized
INFO - 2022-01-18 09:51:20 --> Loader Class Initialized
INFO - 2022-01-18 09:51:20 --> Helper loaded: url_helper
INFO - 2022-01-18 09:51:20 --> Helper loaded: file_helper
INFO - 2022-01-18 09:51:20 --> Helper loaded: form_helper
INFO - 2022-01-18 09:51:20 --> Helper loaded: my_helper
INFO - 2022-01-18 09:51:20 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:51:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:51:20 --> Controller Class Initialized
DEBUG - 2022-01-18 09:51:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2022-01-18 09:51:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:51:20 --> Final output sent to browser
DEBUG - 2022-01-18 09:51:20 --> Total execution time: 0.0640
INFO - 2022-01-18 09:51:21 --> Config Class Initialized
INFO - 2022-01-18 09:51:21 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:51:21 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:51:21 --> Utf8 Class Initialized
INFO - 2022-01-18 09:51:21 --> URI Class Initialized
INFO - 2022-01-18 09:51:21 --> Router Class Initialized
INFO - 2022-01-18 09:51:21 --> Output Class Initialized
INFO - 2022-01-18 09:51:21 --> Security Class Initialized
DEBUG - 2022-01-18 09:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:51:21 --> Input Class Initialized
INFO - 2022-01-18 09:51:21 --> Language Class Initialized
INFO - 2022-01-18 09:51:21 --> Language Class Initialized
INFO - 2022-01-18 09:51:21 --> Config Class Initialized
INFO - 2022-01-18 09:51:21 --> Loader Class Initialized
INFO - 2022-01-18 09:51:21 --> Helper loaded: url_helper
INFO - 2022-01-18 09:51:21 --> Helper loaded: file_helper
INFO - 2022-01-18 09:51:21 --> Helper loaded: form_helper
INFO - 2022-01-18 09:51:21 --> Helper loaded: my_helper
INFO - 2022-01-18 09:51:21 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:51:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:51:21 --> Controller Class Initialized
DEBUG - 2022-01-18 09:51:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2022-01-18 09:51:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:51:21 --> Final output sent to browser
DEBUG - 2022-01-18 09:51:21 --> Total execution time: 0.0940
INFO - 2022-01-18 09:51:26 --> Config Class Initialized
INFO - 2022-01-18 09:51:26 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:51:26 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:51:26 --> Utf8 Class Initialized
INFO - 2022-01-18 09:51:26 --> URI Class Initialized
INFO - 2022-01-18 09:51:26 --> Router Class Initialized
INFO - 2022-01-18 09:51:26 --> Output Class Initialized
INFO - 2022-01-18 09:51:26 --> Security Class Initialized
DEBUG - 2022-01-18 09:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:51:26 --> Input Class Initialized
INFO - 2022-01-18 09:51:26 --> Language Class Initialized
INFO - 2022-01-18 09:51:26 --> Language Class Initialized
INFO - 2022-01-18 09:51:26 --> Config Class Initialized
INFO - 2022-01-18 09:51:26 --> Loader Class Initialized
INFO - 2022-01-18 09:51:26 --> Helper loaded: url_helper
INFO - 2022-01-18 09:51:26 --> Helper loaded: file_helper
INFO - 2022-01-18 09:51:26 --> Helper loaded: form_helper
INFO - 2022-01-18 09:51:26 --> Helper loaded: my_helper
INFO - 2022-01-18 09:51:26 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:51:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:51:26 --> Controller Class Initialized
INFO - 2022-01-18 09:51:26 --> Helper loaded: cookie_helper
INFO - 2022-01-18 09:51:26 --> Config Class Initialized
INFO - 2022-01-18 09:51:26 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:51:26 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:51:26 --> Utf8 Class Initialized
INFO - 2022-01-18 09:51:26 --> URI Class Initialized
INFO - 2022-01-18 09:51:26 --> Router Class Initialized
INFO - 2022-01-18 09:51:26 --> Output Class Initialized
INFO - 2022-01-18 09:51:26 --> Security Class Initialized
DEBUG - 2022-01-18 09:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:51:26 --> Input Class Initialized
INFO - 2022-01-18 09:51:26 --> Language Class Initialized
INFO - 2022-01-18 09:51:26 --> Language Class Initialized
INFO - 2022-01-18 09:51:26 --> Config Class Initialized
INFO - 2022-01-18 09:51:26 --> Loader Class Initialized
INFO - 2022-01-18 09:51:26 --> Helper loaded: url_helper
INFO - 2022-01-18 09:51:26 --> Helper loaded: file_helper
INFO - 2022-01-18 09:51:26 --> Helper loaded: form_helper
INFO - 2022-01-18 09:51:26 --> Helper loaded: my_helper
INFO - 2022-01-18 09:51:26 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:51:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:51:26 --> Controller Class Initialized
DEBUG - 2022-01-18 09:51:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-01-18 09:51:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:51:26 --> Final output sent to browser
DEBUG - 2022-01-18 09:51:26 --> Total execution time: 0.0350
INFO - 2022-01-18 09:51:35 --> Config Class Initialized
INFO - 2022-01-18 09:51:35 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:51:36 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:51:36 --> Utf8 Class Initialized
INFO - 2022-01-18 09:51:36 --> URI Class Initialized
INFO - 2022-01-18 09:51:36 --> Router Class Initialized
INFO - 2022-01-18 09:51:36 --> Output Class Initialized
INFO - 2022-01-18 09:51:36 --> Security Class Initialized
DEBUG - 2022-01-18 09:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:51:36 --> Input Class Initialized
INFO - 2022-01-18 09:51:36 --> Language Class Initialized
INFO - 2022-01-18 09:51:36 --> Language Class Initialized
INFO - 2022-01-18 09:51:36 --> Config Class Initialized
INFO - 2022-01-18 09:51:36 --> Loader Class Initialized
INFO - 2022-01-18 09:51:36 --> Helper loaded: url_helper
INFO - 2022-01-18 09:51:36 --> Helper loaded: file_helper
INFO - 2022-01-18 09:51:36 --> Helper loaded: form_helper
INFO - 2022-01-18 09:51:36 --> Helper loaded: my_helper
INFO - 2022-01-18 09:51:36 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:51:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:51:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:51:36 --> Controller Class Initialized
INFO - 2022-01-18 09:51:36 --> Helper loaded: cookie_helper
INFO - 2022-01-18 09:51:36 --> Final output sent to browser
DEBUG - 2022-01-18 09:51:36 --> Total execution time: 0.0546
INFO - 2022-01-18 09:51:37 --> Config Class Initialized
INFO - 2022-01-18 09:51:37 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:51:37 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:51:37 --> Utf8 Class Initialized
INFO - 2022-01-18 09:51:37 --> URI Class Initialized
INFO - 2022-01-18 09:51:37 --> Router Class Initialized
INFO - 2022-01-18 09:51:37 --> Output Class Initialized
INFO - 2022-01-18 09:51:37 --> Security Class Initialized
DEBUG - 2022-01-18 09:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:51:37 --> Input Class Initialized
INFO - 2022-01-18 09:51:37 --> Language Class Initialized
INFO - 2022-01-18 09:51:37 --> Language Class Initialized
INFO - 2022-01-18 09:51:37 --> Config Class Initialized
INFO - 2022-01-18 09:51:37 --> Loader Class Initialized
INFO - 2022-01-18 09:51:37 --> Helper loaded: url_helper
INFO - 2022-01-18 09:51:37 --> Helper loaded: file_helper
INFO - 2022-01-18 09:51:37 --> Helper loaded: form_helper
INFO - 2022-01-18 09:51:37 --> Helper loaded: my_helper
INFO - 2022-01-18 09:51:37 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:51:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:51:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:51:37 --> Controller Class Initialized
DEBUG - 2022-01-18 09:51:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-01-18 09:51:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:51:38 --> Final output sent to browser
DEBUG - 2022-01-18 09:51:38 --> Total execution time: 0.8350
INFO - 2022-01-18 09:51:40 --> Config Class Initialized
INFO - 2022-01-18 09:51:40 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:51:40 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:51:40 --> Utf8 Class Initialized
INFO - 2022-01-18 09:51:40 --> URI Class Initialized
INFO - 2022-01-18 09:51:40 --> Router Class Initialized
INFO - 2022-01-18 09:51:40 --> Output Class Initialized
INFO - 2022-01-18 09:51:40 --> Security Class Initialized
DEBUG - 2022-01-18 09:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:51:40 --> Input Class Initialized
INFO - 2022-01-18 09:51:40 --> Language Class Initialized
INFO - 2022-01-18 09:51:40 --> Language Class Initialized
INFO - 2022-01-18 09:51:40 --> Config Class Initialized
INFO - 2022-01-18 09:51:40 --> Loader Class Initialized
INFO - 2022-01-18 09:51:40 --> Helper loaded: url_helper
INFO - 2022-01-18 09:51:40 --> Helper loaded: file_helper
INFO - 2022-01-18 09:51:40 --> Helper loaded: form_helper
INFO - 2022-01-18 09:51:40 --> Helper loaded: my_helper
INFO - 2022-01-18 09:51:40 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:51:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:51:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:51:40 --> Controller Class Initialized
DEBUG - 2022-01-18 09:51:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2022-01-18 09:51:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:51:40 --> Final output sent to browser
DEBUG - 2022-01-18 09:51:40 --> Total execution time: 0.0400
INFO - 2022-01-18 09:51:40 --> Config Class Initialized
INFO - 2022-01-18 09:51:40 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:51:40 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:51:40 --> Utf8 Class Initialized
INFO - 2022-01-18 09:51:40 --> URI Class Initialized
INFO - 2022-01-18 09:51:40 --> Router Class Initialized
INFO - 2022-01-18 09:51:40 --> Output Class Initialized
INFO - 2022-01-18 09:51:40 --> Security Class Initialized
DEBUG - 2022-01-18 09:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:51:40 --> Input Class Initialized
INFO - 2022-01-18 09:51:40 --> Language Class Initialized
INFO - 2022-01-18 09:51:40 --> Language Class Initialized
INFO - 2022-01-18 09:51:40 --> Config Class Initialized
INFO - 2022-01-18 09:51:40 --> Loader Class Initialized
INFO - 2022-01-18 09:51:40 --> Helper loaded: url_helper
INFO - 2022-01-18 09:51:40 --> Helper loaded: file_helper
INFO - 2022-01-18 09:51:40 --> Helper loaded: form_helper
INFO - 2022-01-18 09:51:40 --> Helper loaded: my_helper
INFO - 2022-01-18 09:51:40 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:51:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:51:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:51:40 --> Controller Class Initialized
INFO - 2022-01-18 09:51:41 --> Config Class Initialized
INFO - 2022-01-18 09:51:41 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:51:41 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:51:41 --> Utf8 Class Initialized
INFO - 2022-01-18 09:51:41 --> URI Class Initialized
INFO - 2022-01-18 09:51:41 --> Router Class Initialized
INFO - 2022-01-18 09:51:41 --> Output Class Initialized
INFO - 2022-01-18 09:51:41 --> Security Class Initialized
DEBUG - 2022-01-18 09:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:51:41 --> Input Class Initialized
INFO - 2022-01-18 09:51:41 --> Language Class Initialized
INFO - 2022-01-18 09:51:41 --> Language Class Initialized
INFO - 2022-01-18 09:51:41 --> Config Class Initialized
INFO - 2022-01-18 09:51:41 --> Loader Class Initialized
INFO - 2022-01-18 09:51:41 --> Helper loaded: url_helper
INFO - 2022-01-18 09:51:41 --> Helper loaded: file_helper
INFO - 2022-01-18 09:51:41 --> Helper loaded: form_helper
INFO - 2022-01-18 09:51:41 --> Helper loaded: my_helper
INFO - 2022-01-18 09:51:41 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:51:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:51:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:51:41 --> Controller Class Initialized
INFO - 2022-01-18 09:51:41 --> Final output sent to browser
DEBUG - 2022-01-18 09:51:41 --> Total execution time: 0.0520
INFO - 2022-01-18 09:51:41 --> Config Class Initialized
INFO - 2022-01-18 09:51:41 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:51:41 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:51:41 --> Utf8 Class Initialized
INFO - 2022-01-18 09:51:41 --> URI Class Initialized
INFO - 2022-01-18 09:51:41 --> Router Class Initialized
INFO - 2022-01-18 09:51:41 --> Output Class Initialized
INFO - 2022-01-18 09:51:41 --> Security Class Initialized
DEBUG - 2022-01-18 09:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:51:41 --> Input Class Initialized
INFO - 2022-01-18 09:51:41 --> Language Class Initialized
INFO - 2022-01-18 09:51:41 --> Language Class Initialized
INFO - 2022-01-18 09:51:41 --> Config Class Initialized
INFO - 2022-01-18 09:51:41 --> Loader Class Initialized
INFO - 2022-01-18 09:51:41 --> Helper loaded: url_helper
INFO - 2022-01-18 09:51:41 --> Helper loaded: file_helper
INFO - 2022-01-18 09:51:41 --> Helper loaded: form_helper
INFO - 2022-01-18 09:51:41 --> Helper loaded: my_helper
INFO - 2022-01-18 09:51:41 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:51:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:51:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:51:41 --> Controller Class Initialized
INFO - 2022-01-18 09:51:44 --> Config Class Initialized
INFO - 2022-01-18 09:51:44 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:51:44 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:51:44 --> Utf8 Class Initialized
INFO - 2022-01-18 09:51:44 --> URI Class Initialized
INFO - 2022-01-18 09:51:44 --> Router Class Initialized
INFO - 2022-01-18 09:51:44 --> Output Class Initialized
INFO - 2022-01-18 09:51:44 --> Security Class Initialized
DEBUG - 2022-01-18 09:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:51:44 --> Input Class Initialized
INFO - 2022-01-18 09:51:44 --> Language Class Initialized
INFO - 2022-01-18 09:51:44 --> Language Class Initialized
INFO - 2022-01-18 09:51:44 --> Config Class Initialized
INFO - 2022-01-18 09:51:44 --> Loader Class Initialized
INFO - 2022-01-18 09:51:44 --> Helper loaded: url_helper
INFO - 2022-01-18 09:51:44 --> Helper loaded: file_helper
INFO - 2022-01-18 09:51:44 --> Helper loaded: form_helper
INFO - 2022-01-18 09:51:44 --> Helper loaded: my_helper
INFO - 2022-01-18 09:51:44 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:51:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:51:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:51:44 --> Controller Class Initialized
INFO - 2022-01-18 09:51:44 --> Helper loaded: cookie_helper
INFO - 2022-01-18 09:51:44 --> Config Class Initialized
INFO - 2022-01-18 09:51:44 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:51:44 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:51:44 --> Utf8 Class Initialized
INFO - 2022-01-18 09:51:44 --> URI Class Initialized
INFO - 2022-01-18 09:51:44 --> Router Class Initialized
INFO - 2022-01-18 09:51:44 --> Output Class Initialized
INFO - 2022-01-18 09:51:44 --> Security Class Initialized
DEBUG - 2022-01-18 09:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:51:44 --> Input Class Initialized
INFO - 2022-01-18 09:51:44 --> Language Class Initialized
INFO - 2022-01-18 09:51:44 --> Language Class Initialized
INFO - 2022-01-18 09:51:44 --> Config Class Initialized
INFO - 2022-01-18 09:51:44 --> Loader Class Initialized
INFO - 2022-01-18 09:51:44 --> Helper loaded: url_helper
INFO - 2022-01-18 09:51:44 --> Helper loaded: file_helper
INFO - 2022-01-18 09:51:44 --> Helper loaded: form_helper
INFO - 2022-01-18 09:51:44 --> Helper loaded: my_helper
INFO - 2022-01-18 09:51:44 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:51:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:51:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:51:44 --> Controller Class Initialized
DEBUG - 2022-01-18 09:51:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-01-18 09:51:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:51:44 --> Final output sent to browser
DEBUG - 2022-01-18 09:51:44 --> Total execution time: 0.0350
INFO - 2022-01-18 09:52:01 --> Config Class Initialized
INFO - 2022-01-18 09:52:01 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:52:01 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:52:01 --> Utf8 Class Initialized
INFO - 2022-01-18 09:52:01 --> URI Class Initialized
INFO - 2022-01-18 09:52:01 --> Router Class Initialized
INFO - 2022-01-18 09:52:01 --> Output Class Initialized
INFO - 2022-01-18 09:52:01 --> Security Class Initialized
DEBUG - 2022-01-18 09:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:52:01 --> Input Class Initialized
INFO - 2022-01-18 09:52:01 --> Language Class Initialized
INFO - 2022-01-18 09:52:01 --> Language Class Initialized
INFO - 2022-01-18 09:52:01 --> Config Class Initialized
INFO - 2022-01-18 09:52:01 --> Loader Class Initialized
INFO - 2022-01-18 09:52:01 --> Helper loaded: url_helper
INFO - 2022-01-18 09:52:01 --> Helper loaded: file_helper
INFO - 2022-01-18 09:52:01 --> Helper loaded: form_helper
INFO - 2022-01-18 09:52:01 --> Helper loaded: my_helper
INFO - 2022-01-18 09:52:01 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:52:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:52:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:52:01 --> Controller Class Initialized
INFO - 2022-01-18 09:52:01 --> Helper loaded: cookie_helper
INFO - 2022-01-18 09:52:01 --> Final output sent to browser
DEBUG - 2022-01-18 09:52:01 --> Total execution time: 0.0536
INFO - 2022-01-18 09:52:03 --> Config Class Initialized
INFO - 2022-01-18 09:52:03 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:52:03 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:52:03 --> Utf8 Class Initialized
INFO - 2022-01-18 09:52:03 --> URI Class Initialized
INFO - 2022-01-18 09:52:03 --> Router Class Initialized
INFO - 2022-01-18 09:52:03 --> Output Class Initialized
INFO - 2022-01-18 09:52:03 --> Security Class Initialized
DEBUG - 2022-01-18 09:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:52:03 --> Input Class Initialized
INFO - 2022-01-18 09:52:03 --> Language Class Initialized
INFO - 2022-01-18 09:52:03 --> Language Class Initialized
INFO - 2022-01-18 09:52:03 --> Config Class Initialized
INFO - 2022-01-18 09:52:03 --> Loader Class Initialized
INFO - 2022-01-18 09:52:03 --> Helper loaded: url_helper
INFO - 2022-01-18 09:52:03 --> Helper loaded: file_helper
INFO - 2022-01-18 09:52:03 --> Helper loaded: form_helper
INFO - 2022-01-18 09:52:03 --> Helper loaded: my_helper
INFO - 2022-01-18 09:52:03 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:52:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:52:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:52:03 --> Controller Class Initialized
DEBUG - 2022-01-18 09:52:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-01-18 09:52:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:52:04 --> Final output sent to browser
DEBUG - 2022-01-18 09:52:04 --> Total execution time: 0.6690
INFO - 2022-01-18 09:52:06 --> Config Class Initialized
INFO - 2022-01-18 09:52:06 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:52:06 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:52:06 --> Utf8 Class Initialized
INFO - 2022-01-18 09:52:06 --> URI Class Initialized
INFO - 2022-01-18 09:52:06 --> Router Class Initialized
INFO - 2022-01-18 09:52:06 --> Output Class Initialized
INFO - 2022-01-18 09:52:06 --> Security Class Initialized
DEBUG - 2022-01-18 09:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:52:06 --> Input Class Initialized
INFO - 2022-01-18 09:52:06 --> Language Class Initialized
INFO - 2022-01-18 09:52:06 --> Language Class Initialized
INFO - 2022-01-18 09:52:06 --> Config Class Initialized
INFO - 2022-01-18 09:52:06 --> Loader Class Initialized
INFO - 2022-01-18 09:52:06 --> Helper loaded: url_helper
INFO - 2022-01-18 09:52:06 --> Helper loaded: file_helper
INFO - 2022-01-18 09:52:06 --> Helper loaded: form_helper
INFO - 2022-01-18 09:52:06 --> Helper loaded: my_helper
INFO - 2022-01-18 09:52:06 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:52:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:52:06 --> Controller Class Initialized
DEBUG - 2022-01-18 09:52:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2022-01-18 09:52:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:52:06 --> Final output sent to browser
DEBUG - 2022-01-18 09:52:06 --> Total execution time: 0.1140
INFO - 2022-01-18 09:52:08 --> Config Class Initialized
INFO - 2022-01-18 09:52:08 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:52:08 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:52:08 --> Utf8 Class Initialized
INFO - 2022-01-18 09:52:08 --> URI Class Initialized
INFO - 2022-01-18 09:52:08 --> Router Class Initialized
INFO - 2022-01-18 09:52:08 --> Output Class Initialized
INFO - 2022-01-18 09:52:08 --> Security Class Initialized
DEBUG - 2022-01-18 09:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:52:08 --> Input Class Initialized
INFO - 2022-01-18 09:52:08 --> Language Class Initialized
INFO - 2022-01-18 09:52:08 --> Language Class Initialized
INFO - 2022-01-18 09:52:08 --> Config Class Initialized
INFO - 2022-01-18 09:52:08 --> Loader Class Initialized
INFO - 2022-01-18 09:52:08 --> Helper loaded: url_helper
INFO - 2022-01-18 09:52:08 --> Helper loaded: file_helper
INFO - 2022-01-18 09:52:08 --> Helper loaded: form_helper
INFO - 2022-01-18 09:52:08 --> Helper loaded: my_helper
INFO - 2022-01-18 09:52:08 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:52:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:52:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:52:08 --> Controller Class Initialized
DEBUG - 2022-01-18 09:52:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2022-01-18 09:52:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:52:08 --> Final output sent to browser
DEBUG - 2022-01-18 09:52:08 --> Total execution time: 0.0470
INFO - 2022-01-18 09:52:10 --> Config Class Initialized
INFO - 2022-01-18 09:52:10 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:52:10 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:52:10 --> Utf8 Class Initialized
INFO - 2022-01-18 09:52:10 --> URI Class Initialized
INFO - 2022-01-18 09:52:10 --> Router Class Initialized
INFO - 2022-01-18 09:52:10 --> Output Class Initialized
INFO - 2022-01-18 09:52:10 --> Security Class Initialized
DEBUG - 2022-01-18 09:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:52:10 --> Input Class Initialized
INFO - 2022-01-18 09:52:10 --> Language Class Initialized
INFO - 2022-01-18 09:52:10 --> Language Class Initialized
INFO - 2022-01-18 09:52:10 --> Config Class Initialized
INFO - 2022-01-18 09:52:10 --> Loader Class Initialized
INFO - 2022-01-18 09:52:10 --> Helper loaded: url_helper
INFO - 2022-01-18 09:52:10 --> Helper loaded: file_helper
INFO - 2022-01-18 09:52:10 --> Helper loaded: form_helper
INFO - 2022-01-18 09:52:10 --> Helper loaded: my_helper
INFO - 2022-01-18 09:52:10 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:52:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:52:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:52:10 --> Controller Class Initialized
DEBUG - 2022-01-18 09:52:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-01-18 09:52:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:52:10 --> Final output sent to browser
DEBUG - 2022-01-18 09:52:10 --> Total execution time: 0.0400
INFO - 2022-01-18 09:52:12 --> Config Class Initialized
INFO - 2022-01-18 09:52:12 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:52:12 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:52:12 --> Utf8 Class Initialized
INFO - 2022-01-18 09:52:12 --> URI Class Initialized
INFO - 2022-01-18 09:52:12 --> Router Class Initialized
INFO - 2022-01-18 09:52:12 --> Output Class Initialized
INFO - 2022-01-18 09:52:12 --> Security Class Initialized
DEBUG - 2022-01-18 09:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:52:12 --> Input Class Initialized
INFO - 2022-01-18 09:52:12 --> Language Class Initialized
INFO - 2022-01-18 09:52:12 --> Language Class Initialized
INFO - 2022-01-18 09:52:12 --> Config Class Initialized
INFO - 2022-01-18 09:52:12 --> Loader Class Initialized
INFO - 2022-01-18 09:52:12 --> Helper loaded: url_helper
INFO - 2022-01-18 09:52:12 --> Helper loaded: file_helper
INFO - 2022-01-18 09:52:12 --> Helper loaded: form_helper
INFO - 2022-01-18 09:52:12 --> Helper loaded: my_helper
INFO - 2022-01-18 09:52:12 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:52:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:52:12 --> Controller Class Initialized
INFO - 2022-01-18 09:52:12 --> Final output sent to browser
DEBUG - 2022-01-18 09:52:12 --> Total execution time: 0.0526
INFO - 2022-01-18 09:52:19 --> Config Class Initialized
INFO - 2022-01-18 09:52:19 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:52:19 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:52:19 --> Utf8 Class Initialized
INFO - 2022-01-18 09:52:19 --> URI Class Initialized
INFO - 2022-01-18 09:52:19 --> Router Class Initialized
INFO - 2022-01-18 09:52:19 --> Output Class Initialized
INFO - 2022-01-18 09:52:19 --> Security Class Initialized
DEBUG - 2022-01-18 09:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:52:19 --> Input Class Initialized
INFO - 2022-01-18 09:52:19 --> Language Class Initialized
INFO - 2022-01-18 09:52:19 --> Language Class Initialized
INFO - 2022-01-18 09:52:19 --> Config Class Initialized
INFO - 2022-01-18 09:52:19 --> Loader Class Initialized
INFO - 2022-01-18 09:52:19 --> Helper loaded: url_helper
INFO - 2022-01-18 09:52:19 --> Helper loaded: file_helper
INFO - 2022-01-18 09:52:19 --> Helper loaded: form_helper
INFO - 2022-01-18 09:52:19 --> Helper loaded: my_helper
INFO - 2022-01-18 09:52:19 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:52:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:52:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:52:19 --> Controller Class Initialized
DEBUG - 2022-01-18 09:52:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-01-18 09:52:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:52:19 --> Final output sent to browser
DEBUG - 2022-01-18 09:52:19 --> Total execution time: 0.0440
INFO - 2022-01-18 09:52:20 --> Config Class Initialized
INFO - 2022-01-18 09:52:20 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:52:20 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:52:20 --> Utf8 Class Initialized
INFO - 2022-01-18 09:52:20 --> URI Class Initialized
INFO - 2022-01-18 09:52:20 --> Router Class Initialized
INFO - 2022-01-18 09:52:20 --> Output Class Initialized
INFO - 2022-01-18 09:52:20 --> Security Class Initialized
DEBUG - 2022-01-18 09:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:52:20 --> Input Class Initialized
INFO - 2022-01-18 09:52:20 --> Language Class Initialized
INFO - 2022-01-18 09:52:20 --> Language Class Initialized
INFO - 2022-01-18 09:52:20 --> Config Class Initialized
INFO - 2022-01-18 09:52:20 --> Loader Class Initialized
INFO - 2022-01-18 09:52:20 --> Helper loaded: url_helper
INFO - 2022-01-18 09:52:20 --> Helper loaded: file_helper
INFO - 2022-01-18 09:52:20 --> Helper loaded: form_helper
INFO - 2022-01-18 09:52:20 --> Helper loaded: my_helper
INFO - 2022-01-18 09:52:20 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:52:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:52:20 --> Controller Class Initialized
INFO - 2022-01-18 09:52:20 --> Final output sent to browser
DEBUG - 2022-01-18 09:52:20 --> Total execution time: 0.0602
INFO - 2022-01-18 09:52:21 --> Config Class Initialized
INFO - 2022-01-18 09:52:21 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:52:21 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:52:21 --> Utf8 Class Initialized
INFO - 2022-01-18 09:52:21 --> URI Class Initialized
INFO - 2022-01-18 09:52:21 --> Router Class Initialized
INFO - 2022-01-18 09:52:21 --> Output Class Initialized
INFO - 2022-01-18 09:52:21 --> Security Class Initialized
DEBUG - 2022-01-18 09:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:52:21 --> Input Class Initialized
INFO - 2022-01-18 09:52:21 --> Language Class Initialized
INFO - 2022-01-18 09:52:21 --> Language Class Initialized
INFO - 2022-01-18 09:52:21 --> Config Class Initialized
INFO - 2022-01-18 09:52:21 --> Loader Class Initialized
INFO - 2022-01-18 09:52:21 --> Helper loaded: url_helper
INFO - 2022-01-18 09:52:21 --> Helper loaded: file_helper
INFO - 2022-01-18 09:52:21 --> Helper loaded: form_helper
INFO - 2022-01-18 09:52:21 --> Helper loaded: my_helper
INFO - 2022-01-18 09:52:21 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:52:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:52:21 --> Controller Class Initialized
DEBUG - 2022-01-18 09:52:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2022-01-18 09:52:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:52:21 --> Final output sent to browser
DEBUG - 2022-01-18 09:52:21 --> Total execution time: 0.0580
INFO - 2022-01-18 09:52:23 --> Config Class Initialized
INFO - 2022-01-18 09:52:23 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:52:23 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:52:23 --> Utf8 Class Initialized
INFO - 2022-01-18 09:52:23 --> URI Class Initialized
INFO - 2022-01-18 09:52:23 --> Router Class Initialized
INFO - 2022-01-18 09:52:23 --> Output Class Initialized
INFO - 2022-01-18 09:52:23 --> Security Class Initialized
DEBUG - 2022-01-18 09:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:52:23 --> Input Class Initialized
INFO - 2022-01-18 09:52:23 --> Language Class Initialized
INFO - 2022-01-18 09:52:23 --> Language Class Initialized
INFO - 2022-01-18 09:52:23 --> Config Class Initialized
INFO - 2022-01-18 09:52:23 --> Loader Class Initialized
INFO - 2022-01-18 09:52:23 --> Helper loaded: url_helper
INFO - 2022-01-18 09:52:23 --> Helper loaded: file_helper
INFO - 2022-01-18 09:52:23 --> Helper loaded: form_helper
INFO - 2022-01-18 09:52:23 --> Helper loaded: my_helper
INFO - 2022-01-18 09:52:23 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:52:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:52:23 --> Controller Class Initialized
DEBUG - 2022-01-18 09:52:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2022-01-18 09:52:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:52:23 --> Final output sent to browser
DEBUG - 2022-01-18 09:52:23 --> Total execution time: 0.0720
INFO - 2022-01-18 09:52:25 --> Config Class Initialized
INFO - 2022-01-18 09:52:25 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:52:25 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:52:25 --> Utf8 Class Initialized
INFO - 2022-01-18 09:52:25 --> URI Class Initialized
INFO - 2022-01-18 09:52:25 --> Router Class Initialized
INFO - 2022-01-18 09:52:25 --> Output Class Initialized
INFO - 2022-01-18 09:52:25 --> Security Class Initialized
DEBUG - 2022-01-18 09:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:52:25 --> Input Class Initialized
INFO - 2022-01-18 09:52:25 --> Language Class Initialized
INFO - 2022-01-18 09:52:25 --> Language Class Initialized
INFO - 2022-01-18 09:52:25 --> Config Class Initialized
INFO - 2022-01-18 09:52:25 --> Loader Class Initialized
INFO - 2022-01-18 09:52:25 --> Helper loaded: url_helper
INFO - 2022-01-18 09:52:25 --> Helper loaded: file_helper
INFO - 2022-01-18 09:52:25 --> Helper loaded: form_helper
INFO - 2022-01-18 09:52:25 --> Helper loaded: my_helper
INFO - 2022-01-18 09:52:25 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:52:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:52:25 --> Controller Class Initialized
DEBUG - 2022-01-18 09:52:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2022-01-18 09:52:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:52:25 --> Final output sent to browser
DEBUG - 2022-01-18 09:52:25 --> Total execution time: 0.0490
INFO - 2022-01-18 09:58:08 --> Config Class Initialized
INFO - 2022-01-18 09:58:08 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:58:08 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:58:08 --> Utf8 Class Initialized
INFO - 2022-01-18 09:58:08 --> URI Class Initialized
INFO - 2022-01-18 09:58:08 --> Router Class Initialized
INFO - 2022-01-18 09:58:08 --> Output Class Initialized
INFO - 2022-01-18 09:58:08 --> Security Class Initialized
DEBUG - 2022-01-18 09:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:58:08 --> Input Class Initialized
INFO - 2022-01-18 09:58:08 --> Language Class Initialized
INFO - 2022-01-18 09:58:08 --> Language Class Initialized
INFO - 2022-01-18 09:58:08 --> Config Class Initialized
INFO - 2022-01-18 09:58:08 --> Loader Class Initialized
INFO - 2022-01-18 09:58:08 --> Helper loaded: url_helper
INFO - 2022-01-18 09:58:08 --> Helper loaded: file_helper
INFO - 2022-01-18 09:58:08 --> Helper loaded: form_helper
INFO - 2022-01-18 09:58:08 --> Helper loaded: my_helper
INFO - 2022-01-18 09:58:08 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:58:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:58:08 --> Controller Class Initialized
INFO - 2022-01-18 09:58:08 --> Final output sent to browser
DEBUG - 2022-01-18 09:58:08 --> Total execution time: 0.0600
INFO - 2022-01-18 09:58:12 --> Config Class Initialized
INFO - 2022-01-18 09:58:12 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:58:12 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:58:12 --> Utf8 Class Initialized
INFO - 2022-01-18 09:58:12 --> URI Class Initialized
INFO - 2022-01-18 09:58:12 --> Router Class Initialized
INFO - 2022-01-18 09:58:12 --> Output Class Initialized
INFO - 2022-01-18 09:58:12 --> Security Class Initialized
DEBUG - 2022-01-18 09:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:58:12 --> Input Class Initialized
INFO - 2022-01-18 09:58:12 --> Language Class Initialized
INFO - 2022-01-18 09:58:12 --> Language Class Initialized
INFO - 2022-01-18 09:58:12 --> Config Class Initialized
INFO - 2022-01-18 09:58:12 --> Loader Class Initialized
INFO - 2022-01-18 09:58:12 --> Helper loaded: url_helper
INFO - 2022-01-18 09:58:12 --> Helper loaded: file_helper
INFO - 2022-01-18 09:58:12 --> Helper loaded: form_helper
INFO - 2022-01-18 09:58:12 --> Helper loaded: my_helper
INFO - 2022-01-18 09:58:12 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:58:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:58:12 --> Controller Class Initialized
DEBUG - 2022-01-18 09:58:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2022-01-18 09:58:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:58:12 --> Final output sent to browser
DEBUG - 2022-01-18 09:58:12 --> Total execution time: 0.0770
INFO - 2022-01-18 09:58:14 --> Config Class Initialized
INFO - 2022-01-18 09:58:14 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:58:14 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:58:14 --> Utf8 Class Initialized
INFO - 2022-01-18 09:58:14 --> URI Class Initialized
INFO - 2022-01-18 09:58:14 --> Router Class Initialized
INFO - 2022-01-18 09:58:14 --> Output Class Initialized
INFO - 2022-01-18 09:58:14 --> Security Class Initialized
DEBUG - 2022-01-18 09:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:58:14 --> Input Class Initialized
INFO - 2022-01-18 09:58:14 --> Language Class Initialized
INFO - 2022-01-18 09:58:14 --> Language Class Initialized
INFO - 2022-01-18 09:58:14 --> Config Class Initialized
INFO - 2022-01-18 09:58:14 --> Loader Class Initialized
INFO - 2022-01-18 09:58:14 --> Helper loaded: url_helper
INFO - 2022-01-18 09:58:14 --> Helper loaded: file_helper
INFO - 2022-01-18 09:58:14 --> Helper loaded: form_helper
INFO - 2022-01-18 09:58:14 --> Helper loaded: my_helper
INFO - 2022-01-18 09:58:15 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:58:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:58:15 --> Controller Class Initialized
INFO - 2022-01-18 09:58:15 --> Helper loaded: cookie_helper
INFO - 2022-01-18 09:58:15 --> Config Class Initialized
INFO - 2022-01-18 09:58:15 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:58:15 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:58:15 --> Utf8 Class Initialized
INFO - 2022-01-18 09:58:15 --> URI Class Initialized
INFO - 2022-01-18 09:58:15 --> Router Class Initialized
INFO - 2022-01-18 09:58:15 --> Output Class Initialized
INFO - 2022-01-18 09:58:15 --> Security Class Initialized
DEBUG - 2022-01-18 09:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:58:15 --> Input Class Initialized
INFO - 2022-01-18 09:58:15 --> Language Class Initialized
INFO - 2022-01-18 09:58:15 --> Language Class Initialized
INFO - 2022-01-18 09:58:15 --> Config Class Initialized
INFO - 2022-01-18 09:58:15 --> Loader Class Initialized
INFO - 2022-01-18 09:58:15 --> Helper loaded: url_helper
INFO - 2022-01-18 09:58:15 --> Helper loaded: file_helper
INFO - 2022-01-18 09:58:15 --> Helper loaded: form_helper
INFO - 2022-01-18 09:58:15 --> Helper loaded: my_helper
INFO - 2022-01-18 09:58:15 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:58:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:58:15 --> Controller Class Initialized
DEBUG - 2022-01-18 09:58:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-01-18 09:58:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-18 09:58:15 --> Final output sent to browser
DEBUG - 2022-01-18 09:58:15 --> Total execution time: 0.0340
