<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-11-19 01:02:39 --> Config Class Initialized
INFO - 2020-11-19 01:02:39 --> Hooks Class Initialized
DEBUG - 2020-11-19 01:02:40 --> UTF-8 Support Enabled
INFO - 2020-11-19 01:02:40 --> Utf8 Class Initialized
INFO - 2020-11-19 01:02:40 --> URI Class Initialized
DEBUG - 2020-11-19 01:02:40 --> No URI present. Default controller set.
INFO - 2020-11-19 01:02:40 --> Router Class Initialized
INFO - 2020-11-19 01:02:40 --> Output Class Initialized
INFO - 2020-11-19 01:02:40 --> Security Class Initialized
DEBUG - 2020-11-19 01:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-19 01:02:40 --> Input Class Initialized
INFO - 2020-11-19 01:02:40 --> Language Class Initialized
INFO - 2020-11-19 01:02:40 --> Language Class Initialized
INFO - 2020-11-19 01:02:40 --> Config Class Initialized
INFO - 2020-11-19 01:02:40 --> Loader Class Initialized
INFO - 2020-11-19 01:02:40 --> Helper loaded: url_helper
INFO - 2020-11-19 01:02:40 --> Helper loaded: file_helper
INFO - 2020-11-19 01:02:40 --> Helper loaded: form_helper
INFO - 2020-11-19 01:02:40 --> Helper loaded: my_helper
INFO - 2020-11-19 01:02:40 --> Database Driver Class Initialized
DEBUG - 2020-11-19 01:02:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-19 01:02:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-19 01:02:40 --> Controller Class Initialized
INFO - 2020-11-19 01:02:40 --> Config Class Initialized
INFO - 2020-11-19 01:02:40 --> Hooks Class Initialized
DEBUG - 2020-11-19 01:02:40 --> UTF-8 Support Enabled
INFO - 2020-11-19 01:02:40 --> Utf8 Class Initialized
INFO - 2020-11-19 01:02:40 --> URI Class Initialized
INFO - 2020-11-19 01:02:40 --> Router Class Initialized
INFO - 2020-11-19 01:02:40 --> Output Class Initialized
INFO - 2020-11-19 01:02:40 --> Security Class Initialized
DEBUG - 2020-11-19 01:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-19 01:02:41 --> Input Class Initialized
INFO - 2020-11-19 01:02:41 --> Language Class Initialized
INFO - 2020-11-19 01:02:41 --> Language Class Initialized
INFO - 2020-11-19 01:02:41 --> Config Class Initialized
INFO - 2020-11-19 01:02:41 --> Loader Class Initialized
INFO - 2020-11-19 01:02:41 --> Helper loaded: url_helper
INFO - 2020-11-19 01:02:41 --> Helper loaded: file_helper
INFO - 2020-11-19 01:02:41 --> Helper loaded: form_helper
INFO - 2020-11-19 01:02:41 --> Helper loaded: my_helper
INFO - 2020-11-19 01:02:41 --> Database Driver Class Initialized
DEBUG - 2020-11-19 01:02:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-19 01:02:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-19 01:02:41 --> Controller Class Initialized
DEBUG - 2020-11-19 01:02:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-19 01:02:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-19 01:02:41 --> Final output sent to browser
DEBUG - 2020-11-19 01:02:41 --> Total execution time: 0.2495
INFO - 2020-11-19 01:02:54 --> Config Class Initialized
INFO - 2020-11-19 01:02:54 --> Hooks Class Initialized
DEBUG - 2020-11-19 01:02:54 --> UTF-8 Support Enabled
INFO - 2020-11-19 01:02:54 --> Utf8 Class Initialized
INFO - 2020-11-19 01:02:54 --> URI Class Initialized
INFO - 2020-11-19 01:02:54 --> Router Class Initialized
INFO - 2020-11-19 01:02:54 --> Output Class Initialized
INFO - 2020-11-19 01:02:54 --> Security Class Initialized
DEBUG - 2020-11-19 01:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-19 01:02:54 --> Input Class Initialized
INFO - 2020-11-19 01:02:54 --> Language Class Initialized
INFO - 2020-11-19 01:02:54 --> Language Class Initialized
INFO - 2020-11-19 01:02:54 --> Config Class Initialized
INFO - 2020-11-19 01:02:54 --> Loader Class Initialized
INFO - 2020-11-19 01:02:54 --> Helper loaded: url_helper
INFO - 2020-11-19 01:02:54 --> Helper loaded: file_helper
INFO - 2020-11-19 01:02:54 --> Helper loaded: form_helper
INFO - 2020-11-19 01:02:54 --> Helper loaded: my_helper
INFO - 2020-11-19 01:02:55 --> Database Driver Class Initialized
DEBUG - 2020-11-19 01:02:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-19 01:02:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-19 01:02:55 --> Controller Class Initialized
INFO - 2020-11-19 01:02:55 --> Helper loaded: cookie_helper
INFO - 2020-11-19 01:02:55 --> Final output sent to browser
DEBUG - 2020-11-19 01:02:55 --> Total execution time: 0.2872
INFO - 2020-11-19 01:02:55 --> Config Class Initialized
INFO - 2020-11-19 01:02:55 --> Hooks Class Initialized
DEBUG - 2020-11-19 01:02:55 --> UTF-8 Support Enabled
INFO - 2020-11-19 01:02:55 --> Utf8 Class Initialized
INFO - 2020-11-19 01:02:55 --> URI Class Initialized
INFO - 2020-11-19 01:02:55 --> Router Class Initialized
INFO - 2020-11-19 01:02:55 --> Output Class Initialized
INFO - 2020-11-19 01:02:55 --> Security Class Initialized
DEBUG - 2020-11-19 01:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-19 01:02:55 --> Input Class Initialized
INFO - 2020-11-19 01:02:55 --> Language Class Initialized
INFO - 2020-11-19 01:02:55 --> Language Class Initialized
INFO - 2020-11-19 01:02:55 --> Config Class Initialized
INFO - 2020-11-19 01:02:55 --> Loader Class Initialized
INFO - 2020-11-19 01:02:55 --> Helper loaded: url_helper
INFO - 2020-11-19 01:02:55 --> Helper loaded: file_helper
INFO - 2020-11-19 01:02:55 --> Helper loaded: form_helper
INFO - 2020-11-19 01:02:55 --> Helper loaded: my_helper
INFO - 2020-11-19 01:02:55 --> Database Driver Class Initialized
DEBUG - 2020-11-19 01:02:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-19 01:02:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-19 01:02:55 --> Controller Class Initialized
DEBUG - 2020-11-19 01:02:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-19 01:02:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-19 01:02:56 --> Final output sent to browser
DEBUG - 2020-11-19 01:02:56 --> Total execution time: 0.3736
INFO - 2020-11-19 08:54:51 --> Config Class Initialized
INFO - 2020-11-19 08:54:52 --> Hooks Class Initialized
DEBUG - 2020-11-19 08:54:52 --> UTF-8 Support Enabled
INFO - 2020-11-19 08:54:52 --> Utf8 Class Initialized
INFO - 2020-11-19 08:54:52 --> URI Class Initialized
DEBUG - 2020-11-19 08:54:52 --> No URI present. Default controller set.
INFO - 2020-11-19 08:54:52 --> Router Class Initialized
INFO - 2020-11-19 08:54:52 --> Output Class Initialized
INFO - 2020-11-19 08:54:52 --> Security Class Initialized
DEBUG - 2020-11-19 08:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-19 08:54:52 --> Input Class Initialized
INFO - 2020-11-19 08:54:52 --> Language Class Initialized
INFO - 2020-11-19 08:54:52 --> Language Class Initialized
INFO - 2020-11-19 08:54:52 --> Config Class Initialized
INFO - 2020-11-19 08:54:52 --> Loader Class Initialized
INFO - 2020-11-19 08:54:52 --> Helper loaded: url_helper
INFO - 2020-11-19 08:54:52 --> Helper loaded: file_helper
INFO - 2020-11-19 08:54:52 --> Helper loaded: form_helper
INFO - 2020-11-19 08:54:52 --> Helper loaded: my_helper
INFO - 2020-11-19 08:54:52 --> Database Driver Class Initialized
DEBUG - 2020-11-19 08:54:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-19 08:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-19 08:54:52 --> Controller Class Initialized
INFO - 2020-11-19 08:54:52 --> Config Class Initialized
INFO - 2020-11-19 08:54:52 --> Hooks Class Initialized
DEBUG - 2020-11-19 08:54:52 --> UTF-8 Support Enabled
INFO - 2020-11-19 08:54:52 --> Utf8 Class Initialized
INFO - 2020-11-19 08:54:52 --> URI Class Initialized
INFO - 2020-11-19 08:54:52 --> Router Class Initialized
INFO - 2020-11-19 08:54:52 --> Output Class Initialized
INFO - 2020-11-19 08:54:52 --> Security Class Initialized
DEBUG - 2020-11-19 08:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-19 08:54:52 --> Input Class Initialized
INFO - 2020-11-19 08:54:52 --> Language Class Initialized
INFO - 2020-11-19 08:54:52 --> Language Class Initialized
INFO - 2020-11-19 08:54:52 --> Config Class Initialized
INFO - 2020-11-19 08:54:52 --> Loader Class Initialized
INFO - 2020-11-19 08:54:52 --> Helper loaded: url_helper
INFO - 2020-11-19 08:54:52 --> Helper loaded: file_helper
INFO - 2020-11-19 08:54:52 --> Helper loaded: form_helper
INFO - 2020-11-19 08:54:52 --> Helper loaded: my_helper
INFO - 2020-11-19 08:54:52 --> Database Driver Class Initialized
DEBUG - 2020-11-19 08:54:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-19 08:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-19 08:54:52 --> Controller Class Initialized
DEBUG - 2020-11-19 08:54:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-19 08:54:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-19 08:54:52 --> Final output sent to browser
DEBUG - 2020-11-19 08:54:52 --> Total execution time: 0.2180
