<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-01-05 03:01:39 --> Config Class Initialized
INFO - 2021-01-05 03:01:39 --> Hooks Class Initialized
DEBUG - 2021-01-05 03:01:39 --> UTF-8 Support Enabled
INFO - 2021-01-05 03:01:39 --> Utf8 Class Initialized
INFO - 2021-01-05 03:01:39 --> URI Class Initialized
DEBUG - 2021-01-05 03:01:39 --> No URI present. Default controller set.
INFO - 2021-01-05 03:01:39 --> Router Class Initialized
INFO - 2021-01-05 03:01:39 --> Output Class Initialized
INFO - 2021-01-05 03:01:39 --> Security Class Initialized
DEBUG - 2021-01-05 03:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 03:01:39 --> Input Class Initialized
INFO - 2021-01-05 03:01:39 --> Language Class Initialized
INFO - 2021-01-05 03:01:39 --> Language Class Initialized
INFO - 2021-01-05 03:01:39 --> Config Class Initialized
INFO - 2021-01-05 03:01:39 --> Loader Class Initialized
INFO - 2021-01-05 03:01:39 --> Helper loaded: url_helper
INFO - 2021-01-05 03:01:39 --> Helper loaded: file_helper
INFO - 2021-01-05 03:01:39 --> Helper loaded: form_helper
INFO - 2021-01-05 03:01:39 --> Helper loaded: my_helper
INFO - 2021-01-05 03:01:39 --> Database Driver Class Initialized
DEBUG - 2021-01-05 03:01:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 03:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 03:01:39 --> Controller Class Initialized
INFO - 2021-01-05 03:01:39 --> Config Class Initialized
INFO - 2021-01-05 03:01:39 --> Hooks Class Initialized
DEBUG - 2021-01-05 03:01:39 --> UTF-8 Support Enabled
INFO - 2021-01-05 03:01:39 --> Utf8 Class Initialized
INFO - 2021-01-05 03:01:40 --> URI Class Initialized
INFO - 2021-01-05 03:01:40 --> Router Class Initialized
INFO - 2021-01-05 03:01:40 --> Output Class Initialized
INFO - 2021-01-05 03:01:40 --> Security Class Initialized
DEBUG - 2021-01-05 03:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 03:01:40 --> Input Class Initialized
INFO - 2021-01-05 03:01:40 --> Language Class Initialized
INFO - 2021-01-05 03:01:40 --> Language Class Initialized
INFO - 2021-01-05 03:01:40 --> Config Class Initialized
INFO - 2021-01-05 03:01:40 --> Loader Class Initialized
INFO - 2021-01-05 03:01:40 --> Helper loaded: url_helper
INFO - 2021-01-05 03:01:40 --> Helper loaded: file_helper
INFO - 2021-01-05 03:01:40 --> Helper loaded: form_helper
INFO - 2021-01-05 03:01:40 --> Helper loaded: my_helper
INFO - 2021-01-05 03:01:40 --> Database Driver Class Initialized
DEBUG - 2021-01-05 03:01:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 03:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 03:01:40 --> Controller Class Initialized
DEBUG - 2021-01-05 03:01:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-05 03:01:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-05 03:01:40 --> Final output sent to browser
DEBUG - 2021-01-05 03:01:40 --> Total execution time: 0.5559
INFO - 2021-01-05 03:06:16 --> Config Class Initialized
INFO - 2021-01-05 03:06:16 --> Hooks Class Initialized
DEBUG - 2021-01-05 03:06:16 --> UTF-8 Support Enabled
INFO - 2021-01-05 03:06:16 --> Utf8 Class Initialized
INFO - 2021-01-05 03:06:16 --> URI Class Initialized
DEBUG - 2021-01-05 03:06:16 --> No URI present. Default controller set.
INFO - 2021-01-05 03:06:16 --> Router Class Initialized
INFO - 2021-01-05 03:06:16 --> Output Class Initialized
INFO - 2021-01-05 03:06:16 --> Security Class Initialized
DEBUG - 2021-01-05 03:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 03:06:17 --> Input Class Initialized
INFO - 2021-01-05 03:06:17 --> Language Class Initialized
INFO - 2021-01-05 03:06:17 --> Language Class Initialized
INFO - 2021-01-05 03:06:17 --> Config Class Initialized
INFO - 2021-01-05 03:06:17 --> Loader Class Initialized
INFO - 2021-01-05 03:06:17 --> Helper loaded: url_helper
INFO - 2021-01-05 03:06:17 --> Helper loaded: file_helper
INFO - 2021-01-05 03:06:17 --> Helper loaded: form_helper
INFO - 2021-01-05 03:06:17 --> Helper loaded: my_helper
INFO - 2021-01-05 03:06:17 --> Database Driver Class Initialized
DEBUG - 2021-01-05 03:06:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 03:06:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 03:06:17 --> Controller Class Initialized
INFO - 2021-01-05 03:06:17 --> Config Class Initialized
INFO - 2021-01-05 03:06:17 --> Hooks Class Initialized
DEBUG - 2021-01-05 03:06:17 --> UTF-8 Support Enabled
INFO - 2021-01-05 03:06:17 --> Utf8 Class Initialized
INFO - 2021-01-05 03:06:17 --> URI Class Initialized
INFO - 2021-01-05 03:06:17 --> Router Class Initialized
INFO - 2021-01-05 03:06:17 --> Output Class Initialized
INFO - 2021-01-05 03:06:17 --> Security Class Initialized
DEBUG - 2021-01-05 03:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 03:06:17 --> Input Class Initialized
INFO - 2021-01-05 03:06:17 --> Language Class Initialized
INFO - 2021-01-05 03:06:17 --> Language Class Initialized
INFO - 2021-01-05 03:06:17 --> Config Class Initialized
INFO - 2021-01-05 03:06:17 --> Loader Class Initialized
INFO - 2021-01-05 03:06:17 --> Helper loaded: url_helper
INFO - 2021-01-05 03:06:17 --> Helper loaded: file_helper
INFO - 2021-01-05 03:06:17 --> Helper loaded: form_helper
INFO - 2021-01-05 03:06:17 --> Helper loaded: my_helper
INFO - 2021-01-05 03:06:17 --> Database Driver Class Initialized
DEBUG - 2021-01-05 03:06:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 03:06:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 03:06:17 --> Controller Class Initialized
DEBUG - 2021-01-05 03:06:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-05 03:06:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-05 03:06:17 --> Final output sent to browser
DEBUG - 2021-01-05 03:06:17 --> Total execution time: 0.2723
INFO - 2021-01-05 03:06:24 --> Config Class Initialized
INFO - 2021-01-05 03:06:24 --> Hooks Class Initialized
DEBUG - 2021-01-05 03:06:24 --> UTF-8 Support Enabled
INFO - 2021-01-05 03:06:24 --> Utf8 Class Initialized
INFO - 2021-01-05 03:06:24 --> URI Class Initialized
INFO - 2021-01-05 03:06:24 --> Router Class Initialized
INFO - 2021-01-05 03:06:25 --> Output Class Initialized
INFO - 2021-01-05 03:06:25 --> Security Class Initialized
DEBUG - 2021-01-05 03:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 03:06:25 --> Input Class Initialized
INFO - 2021-01-05 03:06:25 --> Language Class Initialized
INFO - 2021-01-05 03:06:25 --> Language Class Initialized
INFO - 2021-01-05 03:06:25 --> Config Class Initialized
INFO - 2021-01-05 03:06:25 --> Loader Class Initialized
INFO - 2021-01-05 03:06:25 --> Helper loaded: url_helper
INFO - 2021-01-05 03:06:25 --> Helper loaded: file_helper
INFO - 2021-01-05 03:06:25 --> Helper loaded: form_helper
INFO - 2021-01-05 03:06:25 --> Helper loaded: my_helper
INFO - 2021-01-05 03:06:25 --> Database Driver Class Initialized
DEBUG - 2021-01-05 03:06:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 03:06:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 03:06:25 --> Controller Class Initialized
INFO - 2021-01-05 03:06:25 --> Helper loaded: cookie_helper
INFO - 2021-01-05 03:06:25 --> Final output sent to browser
DEBUG - 2021-01-05 03:06:25 --> Total execution time: 0.3944
INFO - 2021-01-05 03:06:26 --> Config Class Initialized
INFO - 2021-01-05 03:06:26 --> Hooks Class Initialized
DEBUG - 2021-01-05 03:06:26 --> UTF-8 Support Enabled
INFO - 2021-01-05 03:06:26 --> Utf8 Class Initialized
INFO - 2021-01-05 03:06:26 --> URI Class Initialized
INFO - 2021-01-05 03:06:26 --> Router Class Initialized
INFO - 2021-01-05 03:06:26 --> Output Class Initialized
INFO - 2021-01-05 03:06:26 --> Security Class Initialized
DEBUG - 2021-01-05 03:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 03:06:26 --> Input Class Initialized
INFO - 2021-01-05 03:06:26 --> Language Class Initialized
INFO - 2021-01-05 03:06:26 --> Language Class Initialized
INFO - 2021-01-05 03:06:26 --> Config Class Initialized
INFO - 2021-01-05 03:06:26 --> Loader Class Initialized
INFO - 2021-01-05 03:06:26 --> Helper loaded: url_helper
INFO - 2021-01-05 03:06:26 --> Helper loaded: file_helper
INFO - 2021-01-05 03:06:26 --> Helper loaded: form_helper
INFO - 2021-01-05 03:06:26 --> Helper loaded: my_helper
INFO - 2021-01-05 03:06:26 --> Database Driver Class Initialized
DEBUG - 2021-01-05 03:06:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 03:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 03:06:26 --> Controller Class Initialized
DEBUG - 2021-01-05 03:06:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-05 03:06:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-05 03:06:26 --> Final output sent to browser
DEBUG - 2021-01-05 03:06:26 --> Total execution time: 0.4367
INFO - 2021-01-05 03:06:29 --> Config Class Initialized
INFO - 2021-01-05 03:06:29 --> Hooks Class Initialized
DEBUG - 2021-01-05 03:06:29 --> UTF-8 Support Enabled
INFO - 2021-01-05 03:06:29 --> Utf8 Class Initialized
INFO - 2021-01-05 03:06:29 --> URI Class Initialized
INFO - 2021-01-05 03:06:29 --> Router Class Initialized
INFO - 2021-01-05 03:06:29 --> Output Class Initialized
INFO - 2021-01-05 03:06:29 --> Security Class Initialized
DEBUG - 2021-01-05 03:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 03:06:29 --> Input Class Initialized
INFO - 2021-01-05 03:06:29 --> Language Class Initialized
INFO - 2021-01-05 03:06:29 --> Language Class Initialized
INFO - 2021-01-05 03:06:29 --> Config Class Initialized
INFO - 2021-01-05 03:06:29 --> Loader Class Initialized
INFO - 2021-01-05 03:06:29 --> Helper loaded: url_helper
INFO - 2021-01-05 03:06:29 --> Helper loaded: file_helper
INFO - 2021-01-05 03:06:29 --> Helper loaded: form_helper
INFO - 2021-01-05 03:06:29 --> Helper loaded: my_helper
INFO - 2021-01-05 03:06:29 --> Database Driver Class Initialized
DEBUG - 2021-01-05 03:06:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 03:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 03:06:29 --> Controller Class Initialized
DEBUG - 2021-01-05 03:06:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-05 03:06:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-05 03:06:29 --> Final output sent to browser
DEBUG - 2021-01-05 03:06:29 --> Total execution time: 0.3855
INFO - 2021-01-05 03:06:31 --> Config Class Initialized
INFO - 2021-01-05 03:06:31 --> Hooks Class Initialized
DEBUG - 2021-01-05 03:06:31 --> UTF-8 Support Enabled
INFO - 2021-01-05 03:06:31 --> Utf8 Class Initialized
INFO - 2021-01-05 03:06:31 --> URI Class Initialized
INFO - 2021-01-05 03:06:31 --> Router Class Initialized
INFO - 2021-01-05 03:06:31 --> Output Class Initialized
INFO - 2021-01-05 03:06:31 --> Security Class Initialized
DEBUG - 2021-01-05 03:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 03:06:31 --> Input Class Initialized
INFO - 2021-01-05 03:06:31 --> Language Class Initialized
INFO - 2021-01-05 03:06:31 --> Language Class Initialized
INFO - 2021-01-05 03:06:31 --> Config Class Initialized
INFO - 2021-01-05 03:06:31 --> Loader Class Initialized
INFO - 2021-01-05 03:06:31 --> Helper loaded: url_helper
INFO - 2021-01-05 03:06:31 --> Helper loaded: file_helper
INFO - 2021-01-05 03:06:31 --> Helper loaded: form_helper
INFO - 2021-01-05 03:06:31 --> Helper loaded: my_helper
INFO - 2021-01-05 03:06:31 --> Database Driver Class Initialized
DEBUG - 2021-01-05 03:06:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 03:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 03:06:31 --> Controller Class Initialized
DEBUG - 2021-01-05 03:06:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 03:06:31 --> Final output sent to browser
DEBUG - 2021-01-05 03:06:31 --> Total execution time: 0.3251
INFO - 2021-01-05 03:17:34 --> Config Class Initialized
INFO - 2021-01-05 03:17:34 --> Hooks Class Initialized
DEBUG - 2021-01-05 03:17:34 --> UTF-8 Support Enabled
INFO - 2021-01-05 03:17:34 --> Utf8 Class Initialized
INFO - 2021-01-05 03:17:34 --> URI Class Initialized
INFO - 2021-01-05 03:17:34 --> Router Class Initialized
INFO - 2021-01-05 03:17:34 --> Output Class Initialized
INFO - 2021-01-05 03:17:34 --> Security Class Initialized
DEBUG - 2021-01-05 03:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 03:17:34 --> Input Class Initialized
INFO - 2021-01-05 03:17:34 --> Language Class Initialized
INFO - 2021-01-05 03:17:34 --> Language Class Initialized
INFO - 2021-01-05 03:17:34 --> Config Class Initialized
INFO - 2021-01-05 03:17:34 --> Loader Class Initialized
INFO - 2021-01-05 03:17:34 --> Helper loaded: url_helper
INFO - 2021-01-05 03:17:34 --> Helper loaded: file_helper
INFO - 2021-01-05 03:17:34 --> Helper loaded: form_helper
INFO - 2021-01-05 03:17:34 --> Helper loaded: my_helper
INFO - 2021-01-05 03:17:34 --> Database Driver Class Initialized
DEBUG - 2021-01-05 03:17:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 03:17:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 03:17:34 --> Controller Class Initialized
DEBUG - 2021-01-05 03:17:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 03:17:34 --> Final output sent to browser
DEBUG - 2021-01-05 03:17:34 --> Total execution time: 0.2892
INFO - 2021-01-05 03:18:22 --> Config Class Initialized
INFO - 2021-01-05 03:18:22 --> Hooks Class Initialized
DEBUG - 2021-01-05 03:18:22 --> UTF-8 Support Enabled
INFO - 2021-01-05 03:18:22 --> Utf8 Class Initialized
INFO - 2021-01-05 03:18:22 --> URI Class Initialized
INFO - 2021-01-05 03:18:22 --> Router Class Initialized
INFO - 2021-01-05 03:18:22 --> Output Class Initialized
INFO - 2021-01-05 03:18:22 --> Security Class Initialized
DEBUG - 2021-01-05 03:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 03:18:22 --> Input Class Initialized
INFO - 2021-01-05 03:18:22 --> Language Class Initialized
INFO - 2021-01-05 03:18:23 --> Language Class Initialized
INFO - 2021-01-05 03:18:23 --> Config Class Initialized
INFO - 2021-01-05 03:18:23 --> Loader Class Initialized
INFO - 2021-01-05 03:18:23 --> Helper loaded: url_helper
INFO - 2021-01-05 03:18:23 --> Helper loaded: file_helper
INFO - 2021-01-05 03:18:23 --> Helper loaded: form_helper
INFO - 2021-01-05 03:18:23 --> Helper loaded: my_helper
INFO - 2021-01-05 03:18:23 --> Database Driver Class Initialized
DEBUG - 2021-01-05 03:18:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 03:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 03:18:23 --> Controller Class Initialized
DEBUG - 2021-01-05 03:18:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 03:18:23 --> Final output sent to browser
DEBUG - 2021-01-05 03:18:23 --> Total execution time: 0.3778
INFO - 2021-01-05 03:18:38 --> Config Class Initialized
INFO - 2021-01-05 03:18:38 --> Hooks Class Initialized
DEBUG - 2021-01-05 03:18:38 --> UTF-8 Support Enabled
INFO - 2021-01-05 03:18:39 --> Utf8 Class Initialized
INFO - 2021-01-05 03:18:39 --> URI Class Initialized
INFO - 2021-01-05 03:18:39 --> Router Class Initialized
INFO - 2021-01-05 03:18:39 --> Output Class Initialized
INFO - 2021-01-05 03:18:39 --> Security Class Initialized
DEBUG - 2021-01-05 03:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 03:18:39 --> Input Class Initialized
INFO - 2021-01-05 03:18:39 --> Language Class Initialized
INFO - 2021-01-05 03:18:39 --> Language Class Initialized
INFO - 2021-01-05 03:18:39 --> Config Class Initialized
INFO - 2021-01-05 03:18:39 --> Loader Class Initialized
INFO - 2021-01-05 03:18:39 --> Helper loaded: url_helper
INFO - 2021-01-05 03:18:39 --> Helper loaded: file_helper
INFO - 2021-01-05 03:18:39 --> Helper loaded: form_helper
INFO - 2021-01-05 03:18:39 --> Helper loaded: my_helper
INFO - 2021-01-05 03:18:39 --> Database Driver Class Initialized
DEBUG - 2021-01-05 03:18:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 03:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 03:18:39 --> Controller Class Initialized
DEBUG - 2021-01-05 03:18:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 03:18:39 --> Final output sent to browser
DEBUG - 2021-01-05 03:18:39 --> Total execution time: 0.2779
INFO - 2021-01-05 03:19:00 --> Config Class Initialized
INFO - 2021-01-05 03:19:00 --> Hooks Class Initialized
DEBUG - 2021-01-05 03:19:00 --> UTF-8 Support Enabled
INFO - 2021-01-05 03:19:00 --> Utf8 Class Initialized
INFO - 2021-01-05 03:19:00 --> URI Class Initialized
INFO - 2021-01-05 03:19:00 --> Router Class Initialized
INFO - 2021-01-05 03:19:00 --> Output Class Initialized
INFO - 2021-01-05 03:19:00 --> Security Class Initialized
DEBUG - 2021-01-05 03:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 03:19:00 --> Input Class Initialized
INFO - 2021-01-05 03:19:00 --> Language Class Initialized
INFO - 2021-01-05 03:19:00 --> Language Class Initialized
INFO - 2021-01-05 03:19:00 --> Config Class Initialized
INFO - 2021-01-05 03:19:00 --> Loader Class Initialized
INFO - 2021-01-05 03:19:00 --> Helper loaded: url_helper
INFO - 2021-01-05 03:19:00 --> Helper loaded: file_helper
INFO - 2021-01-05 03:19:00 --> Helper loaded: form_helper
INFO - 2021-01-05 03:19:00 --> Helper loaded: my_helper
INFO - 2021-01-05 03:19:00 --> Database Driver Class Initialized
DEBUG - 2021-01-05 03:19:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 03:19:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 03:19:00 --> Controller Class Initialized
DEBUG - 2021-01-05 03:19:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 03:19:00 --> Final output sent to browser
DEBUG - 2021-01-05 03:19:00 --> Total execution time: 0.3497
INFO - 2021-01-05 03:22:02 --> Config Class Initialized
INFO - 2021-01-05 03:22:02 --> Hooks Class Initialized
DEBUG - 2021-01-05 03:22:02 --> UTF-8 Support Enabled
INFO - 2021-01-05 03:22:02 --> Utf8 Class Initialized
INFO - 2021-01-05 03:22:02 --> URI Class Initialized
INFO - 2021-01-05 03:22:02 --> Router Class Initialized
INFO - 2021-01-05 03:22:02 --> Output Class Initialized
INFO - 2021-01-05 03:22:02 --> Security Class Initialized
DEBUG - 2021-01-05 03:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 03:22:02 --> Input Class Initialized
INFO - 2021-01-05 03:22:02 --> Language Class Initialized
INFO - 2021-01-05 03:22:02 --> Language Class Initialized
INFO - 2021-01-05 03:22:02 --> Config Class Initialized
INFO - 2021-01-05 03:22:02 --> Loader Class Initialized
INFO - 2021-01-05 03:22:02 --> Helper loaded: url_helper
INFO - 2021-01-05 03:22:02 --> Helper loaded: file_helper
INFO - 2021-01-05 03:22:02 --> Helper loaded: form_helper
INFO - 2021-01-05 03:22:02 --> Helper loaded: my_helper
INFO - 2021-01-05 03:22:02 --> Database Driver Class Initialized
DEBUG - 2021-01-05 03:22:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 03:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 03:22:02 --> Controller Class Initialized
DEBUG - 2021-01-05 03:22:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 03:22:02 --> Final output sent to browser
DEBUG - 2021-01-05 03:22:02 --> Total execution time: 0.3027
INFO - 2021-01-05 03:24:08 --> Config Class Initialized
INFO - 2021-01-05 03:24:08 --> Hooks Class Initialized
DEBUG - 2021-01-05 03:24:08 --> UTF-8 Support Enabled
INFO - 2021-01-05 03:24:08 --> Utf8 Class Initialized
INFO - 2021-01-05 03:24:08 --> URI Class Initialized
INFO - 2021-01-05 03:24:08 --> Router Class Initialized
INFO - 2021-01-05 03:24:08 --> Output Class Initialized
INFO - 2021-01-05 03:24:08 --> Security Class Initialized
DEBUG - 2021-01-05 03:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 03:24:08 --> Input Class Initialized
INFO - 2021-01-05 03:24:08 --> Language Class Initialized
INFO - 2021-01-05 03:24:08 --> Language Class Initialized
INFO - 2021-01-05 03:24:08 --> Config Class Initialized
INFO - 2021-01-05 03:24:08 --> Loader Class Initialized
INFO - 2021-01-05 03:24:08 --> Helper loaded: url_helper
INFO - 2021-01-05 03:24:08 --> Helper loaded: file_helper
INFO - 2021-01-05 03:24:08 --> Helper loaded: form_helper
INFO - 2021-01-05 03:24:08 --> Helper loaded: my_helper
INFO - 2021-01-05 03:24:08 --> Database Driver Class Initialized
DEBUG - 2021-01-05 03:24:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 03:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 03:24:08 --> Controller Class Initialized
ERROR - 2021-01-05 03:24:08 --> Severity: Notice --> Undefined variable: catatan_akademik C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_rapot.php 92
DEBUG - 2021-01-05 03:24:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 03:24:08 --> Final output sent to browser
DEBUG - 2021-01-05 03:24:08 --> Total execution time: 0.3217
INFO - 2021-01-05 03:27:39 --> Config Class Initialized
INFO - 2021-01-05 03:27:39 --> Hooks Class Initialized
DEBUG - 2021-01-05 03:27:39 --> UTF-8 Support Enabled
INFO - 2021-01-05 03:27:39 --> Utf8 Class Initialized
INFO - 2021-01-05 03:27:39 --> URI Class Initialized
INFO - 2021-01-05 03:27:39 --> Router Class Initialized
INFO - 2021-01-05 03:27:39 --> Output Class Initialized
INFO - 2021-01-05 03:27:39 --> Security Class Initialized
DEBUG - 2021-01-05 03:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 03:27:39 --> Input Class Initialized
INFO - 2021-01-05 03:27:39 --> Language Class Initialized
INFO - 2021-01-05 03:27:39 --> Language Class Initialized
INFO - 2021-01-05 03:27:39 --> Config Class Initialized
INFO - 2021-01-05 03:27:39 --> Loader Class Initialized
INFO - 2021-01-05 03:27:39 --> Helper loaded: url_helper
INFO - 2021-01-05 03:27:39 --> Helper loaded: file_helper
INFO - 2021-01-05 03:27:39 --> Helper loaded: form_helper
INFO - 2021-01-05 03:27:39 --> Helper loaded: my_helper
INFO - 2021-01-05 03:27:39 --> Database Driver Class Initialized
DEBUG - 2021-01-05 03:27:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 03:27:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 03:27:39 --> Controller Class Initialized
ERROR - 2021-01-05 03:27:39 --> Severity: Notice --> Undefined variable: catatan_akademik C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 363
ERROR - 2021-01-05 03:27:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND a.tasm = '20201'' at line 4 - Invalid query: SELECT 
                                            b.nama, a.nilai, a.desk
                                            FROM t_c_akademik
                                            WHERE a.id_siswa = 1418 AND a.catatan_akademik =  AND a.tasm = '20201'
INFO - 2021-01-05 03:27:39 --> Language file loaded: language/english/db_lang.php
INFO - 2021-01-05 03:28:07 --> Config Class Initialized
INFO - 2021-01-05 03:28:07 --> Hooks Class Initialized
DEBUG - 2021-01-05 03:28:07 --> UTF-8 Support Enabled
INFO - 2021-01-05 03:28:07 --> Utf8 Class Initialized
INFO - 2021-01-05 03:28:07 --> URI Class Initialized
INFO - 2021-01-05 03:28:07 --> Router Class Initialized
INFO - 2021-01-05 03:28:07 --> Output Class Initialized
INFO - 2021-01-05 03:28:07 --> Security Class Initialized
DEBUG - 2021-01-05 03:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 03:28:07 --> Input Class Initialized
INFO - 2021-01-05 03:28:07 --> Language Class Initialized
INFO - 2021-01-05 03:28:07 --> Language Class Initialized
INFO - 2021-01-05 03:28:07 --> Config Class Initialized
INFO - 2021-01-05 03:28:07 --> Loader Class Initialized
INFO - 2021-01-05 03:28:07 --> Helper loaded: url_helper
INFO - 2021-01-05 03:28:07 --> Helper loaded: file_helper
INFO - 2021-01-05 03:28:07 --> Helper loaded: form_helper
INFO - 2021-01-05 03:28:07 --> Helper loaded: my_helper
INFO - 2021-01-05 03:28:07 --> Database Driver Class Initialized
DEBUG - 2021-01-05 03:28:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 03:28:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 03:28:07 --> Controller Class Initialized
ERROR - 2021-01-05 03:28:07 --> Severity: Notice --> Undefined variable: catatan_akademik C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 363
ERROR - 2021-01-05 03:28:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND tasm = '20201'' at line 4 - Invalid query: SELECT 
                                            b.nama, a.nilai, a.desk
                                            FROM t_c_akademik
                                            WHERE a.id_siswa = 1418 AND catatan_akademik =  AND tasm = '20201'
INFO - 2021-01-05 03:28:07 --> Language file loaded: language/english/db_lang.php
INFO - 2021-01-05 03:32:40 --> Config Class Initialized
INFO - 2021-01-05 03:32:40 --> Hooks Class Initialized
DEBUG - 2021-01-05 03:32:40 --> UTF-8 Support Enabled
INFO - 2021-01-05 03:32:40 --> Utf8 Class Initialized
INFO - 2021-01-05 03:32:40 --> URI Class Initialized
INFO - 2021-01-05 03:32:40 --> Router Class Initialized
INFO - 2021-01-05 03:32:40 --> Output Class Initialized
INFO - 2021-01-05 03:32:40 --> Security Class Initialized
DEBUG - 2021-01-05 03:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 03:32:40 --> Input Class Initialized
INFO - 2021-01-05 03:32:40 --> Language Class Initialized
INFO - 2021-01-05 03:32:40 --> Language Class Initialized
INFO - 2021-01-05 03:32:40 --> Config Class Initialized
INFO - 2021-01-05 03:32:40 --> Loader Class Initialized
INFO - 2021-01-05 03:32:40 --> Helper loaded: url_helper
INFO - 2021-01-05 03:32:40 --> Helper loaded: file_helper
INFO - 2021-01-05 03:32:40 --> Helper loaded: form_helper
INFO - 2021-01-05 03:32:40 --> Helper loaded: my_helper
INFO - 2021-01-05 03:32:40 --> Database Driver Class Initialized
DEBUG - 2021-01-05 03:32:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 03:32:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 03:32:40 --> Controller Class Initialized
ERROR - 2021-01-05 03:32:40 --> Severity: Notice --> Undefined variable: catatan_akademik C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 363
ERROR - 2021-01-05 03:32:40 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND ta = '20201'' at line 4 - Invalid query: SELECT 
                                            b.nama, a.nilai, a.desk
                                            FROM t_c_akademik
                                            WHERE a.id_siswa = 1418 AND catatan_akademik =  AND ta = '20201'
INFO - 2021-01-05 03:32:40 --> Language file loaded: language/english/db_lang.php
INFO - 2021-01-05 03:32:52 --> Config Class Initialized
INFO - 2021-01-05 03:32:52 --> Hooks Class Initialized
DEBUG - 2021-01-05 03:32:52 --> UTF-8 Support Enabled
INFO - 2021-01-05 03:32:53 --> Utf8 Class Initialized
INFO - 2021-01-05 03:32:53 --> URI Class Initialized
INFO - 2021-01-05 03:32:53 --> Router Class Initialized
INFO - 2021-01-05 03:32:53 --> Output Class Initialized
INFO - 2021-01-05 03:32:53 --> Security Class Initialized
DEBUG - 2021-01-05 03:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 03:32:53 --> Input Class Initialized
INFO - 2021-01-05 03:32:53 --> Language Class Initialized
INFO - 2021-01-05 03:32:53 --> Language Class Initialized
INFO - 2021-01-05 03:32:53 --> Config Class Initialized
INFO - 2021-01-05 03:32:53 --> Loader Class Initialized
INFO - 2021-01-05 03:32:53 --> Helper loaded: url_helper
INFO - 2021-01-05 03:32:53 --> Helper loaded: file_helper
INFO - 2021-01-05 03:32:53 --> Helper loaded: form_helper
INFO - 2021-01-05 03:32:53 --> Helper loaded: my_helper
INFO - 2021-01-05 03:32:53 --> Database Driver Class Initialized
DEBUG - 2021-01-05 03:32:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 03:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 03:32:53 --> Controller Class Initialized
ERROR - 2021-01-05 03:32:53 --> Severity: Notice --> Undefined variable: catatan_akademik C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 363
ERROR - 2021-01-05 03:32:53 --> Severity: Notice --> Undefined variable: ta C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 363
ERROR - 2021-01-05 03:32:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND tasm = ''' at line 4 - Invalid query: SELECT 
                                            b.nama, a.nilai, a.desk
                                            FROM t_c_akademik
                                            WHERE a.id_siswa = 1418 AND catatan_akademik =  AND tasm = ''
INFO - 2021-01-05 03:32:53 --> Language file loaded: language/english/db_lang.php
INFO - 2021-01-05 03:33:40 --> Config Class Initialized
INFO - 2021-01-05 03:33:40 --> Hooks Class Initialized
DEBUG - 2021-01-05 03:33:40 --> UTF-8 Support Enabled
INFO - 2021-01-05 03:33:40 --> Utf8 Class Initialized
INFO - 2021-01-05 03:33:40 --> URI Class Initialized
INFO - 2021-01-05 03:33:40 --> Router Class Initialized
INFO - 2021-01-05 03:33:40 --> Output Class Initialized
INFO - 2021-01-05 03:33:40 --> Security Class Initialized
DEBUG - 2021-01-05 03:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 03:33:40 --> Input Class Initialized
INFO - 2021-01-05 03:33:40 --> Language Class Initialized
INFO - 2021-01-05 03:33:40 --> Language Class Initialized
INFO - 2021-01-05 03:33:40 --> Config Class Initialized
INFO - 2021-01-05 03:33:40 --> Loader Class Initialized
INFO - 2021-01-05 03:33:40 --> Helper loaded: url_helper
INFO - 2021-01-05 03:33:40 --> Helper loaded: file_helper
INFO - 2021-01-05 03:33:40 --> Helper loaded: form_helper
INFO - 2021-01-05 03:33:40 --> Helper loaded: my_helper
INFO - 2021-01-05 03:33:40 --> Database Driver Class Initialized
DEBUG - 2021-01-05 03:33:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 03:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 03:33:40 --> Controller Class Initialized
ERROR - 2021-01-05 03:33:40 --> Severity: Notice --> Undefined variable: catatan_akademik C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 363
ERROR - 2021-01-05 03:33:40 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND tasm = '20201'' at line 4 - Invalid query: SELECT 
                                            b.nama, a.catatan_akademik
                                            FROM t_c_akademik
                                            WHERE a.id_siswa = 1418 AND catatan_akademik =  AND tasm = '20201'
INFO - 2021-01-05 03:33:40 --> Language file loaded: language/english/db_lang.php
INFO - 2021-01-05 03:35:21 --> Config Class Initialized
INFO - 2021-01-05 03:35:21 --> Hooks Class Initialized
DEBUG - 2021-01-05 03:35:21 --> UTF-8 Support Enabled
INFO - 2021-01-05 03:35:21 --> Utf8 Class Initialized
INFO - 2021-01-05 03:35:21 --> URI Class Initialized
INFO - 2021-01-05 03:35:21 --> Router Class Initialized
INFO - 2021-01-05 03:35:21 --> Output Class Initialized
INFO - 2021-01-05 03:35:21 --> Security Class Initialized
DEBUG - 2021-01-05 03:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 03:35:21 --> Input Class Initialized
INFO - 2021-01-05 03:35:21 --> Language Class Initialized
INFO - 2021-01-05 03:35:21 --> Language Class Initialized
INFO - 2021-01-05 03:35:21 --> Config Class Initialized
INFO - 2021-01-05 03:35:21 --> Loader Class Initialized
INFO - 2021-01-05 03:35:21 --> Helper loaded: url_helper
INFO - 2021-01-05 03:35:21 --> Helper loaded: file_helper
INFO - 2021-01-05 03:35:21 --> Helper loaded: form_helper
INFO - 2021-01-05 03:35:21 --> Helper loaded: my_helper
INFO - 2021-01-05 03:35:21 --> Database Driver Class Initialized
DEBUG - 2021-01-05 03:35:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 03:35:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 03:35:21 --> Controller Class Initialized
ERROR - 2021-01-05 03:35:21 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: SELECT 
                                            catatan_akademik
                                            FROM t_c_akademik
                                            WHERE id_siswa = 1418 AND tasm = '20201'
INFO - 2021-01-05 03:35:21 --> Language file loaded: language/english/db_lang.php
INFO - 2021-01-05 03:35:33 --> Config Class Initialized
INFO - 2021-01-05 03:35:33 --> Hooks Class Initialized
DEBUG - 2021-01-05 03:35:33 --> UTF-8 Support Enabled
INFO - 2021-01-05 03:35:33 --> Utf8 Class Initialized
INFO - 2021-01-05 03:35:33 --> URI Class Initialized
INFO - 2021-01-05 03:35:33 --> Router Class Initialized
INFO - 2021-01-05 03:35:33 --> Output Class Initialized
INFO - 2021-01-05 03:35:33 --> Security Class Initialized
DEBUG - 2021-01-05 03:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 03:35:34 --> Input Class Initialized
INFO - 2021-01-05 03:35:34 --> Language Class Initialized
INFO - 2021-01-05 03:35:34 --> Language Class Initialized
INFO - 2021-01-05 03:35:34 --> Config Class Initialized
INFO - 2021-01-05 03:35:34 --> Loader Class Initialized
INFO - 2021-01-05 03:35:34 --> Helper loaded: url_helper
INFO - 2021-01-05 03:35:34 --> Helper loaded: file_helper
INFO - 2021-01-05 03:35:34 --> Helper loaded: form_helper
INFO - 2021-01-05 03:35:34 --> Helper loaded: my_helper
INFO - 2021-01-05 03:35:34 --> Database Driver Class Initialized
DEBUG - 2021-01-05 03:35:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 03:35:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 03:35:34 --> Controller Class Initialized
ERROR - 2021-01-05 03:35:34 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_rapot.php 92
DEBUG - 2021-01-05 03:35:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 03:35:34 --> Final output sent to browser
DEBUG - 2021-01-05 03:35:34 --> Total execution time: 0.2973
INFO - 2021-01-05 03:36:36 --> Config Class Initialized
INFO - 2021-01-05 03:36:36 --> Hooks Class Initialized
DEBUG - 2021-01-05 03:36:36 --> UTF-8 Support Enabled
INFO - 2021-01-05 03:36:36 --> Utf8 Class Initialized
INFO - 2021-01-05 03:36:36 --> URI Class Initialized
INFO - 2021-01-05 03:36:36 --> Router Class Initialized
INFO - 2021-01-05 03:36:36 --> Output Class Initialized
INFO - 2021-01-05 03:36:36 --> Security Class Initialized
DEBUG - 2021-01-05 03:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 03:36:36 --> Input Class Initialized
INFO - 2021-01-05 03:36:36 --> Language Class Initialized
INFO - 2021-01-05 03:36:36 --> Language Class Initialized
INFO - 2021-01-05 03:36:36 --> Config Class Initialized
INFO - 2021-01-05 03:36:36 --> Loader Class Initialized
INFO - 2021-01-05 03:36:36 --> Helper loaded: url_helper
INFO - 2021-01-05 03:36:36 --> Helper loaded: file_helper
INFO - 2021-01-05 03:36:36 --> Helper loaded: form_helper
INFO - 2021-01-05 03:36:36 --> Helper loaded: my_helper
INFO - 2021-01-05 03:36:36 --> Database Driver Class Initialized
DEBUG - 2021-01-05 03:36:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 03:36:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 03:36:36 --> Controller Class Initialized
ERROR - 2021-01-05 03:36:36 --> Severity: Notice --> Undefined variable: q_catatan_akademik C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_rapot.php 92
DEBUG - 2021-01-05 03:36:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 03:36:36 --> Final output sent to browser
DEBUG - 2021-01-05 03:36:36 --> Total execution time: 0.3150
INFO - 2021-01-05 03:37:44 --> Config Class Initialized
INFO - 2021-01-05 03:37:44 --> Hooks Class Initialized
DEBUG - 2021-01-05 03:37:44 --> UTF-8 Support Enabled
INFO - 2021-01-05 03:37:44 --> Utf8 Class Initialized
INFO - 2021-01-05 03:37:44 --> URI Class Initialized
INFO - 2021-01-05 03:37:44 --> Router Class Initialized
INFO - 2021-01-05 03:37:44 --> Output Class Initialized
INFO - 2021-01-05 03:37:44 --> Security Class Initialized
DEBUG - 2021-01-05 03:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 03:37:44 --> Input Class Initialized
INFO - 2021-01-05 03:37:44 --> Language Class Initialized
INFO - 2021-01-05 03:37:44 --> Language Class Initialized
INFO - 2021-01-05 03:37:44 --> Config Class Initialized
INFO - 2021-01-05 03:37:44 --> Loader Class Initialized
INFO - 2021-01-05 03:37:44 --> Helper loaded: url_helper
INFO - 2021-01-05 03:37:45 --> Helper loaded: file_helper
INFO - 2021-01-05 03:37:45 --> Helper loaded: form_helper
INFO - 2021-01-05 03:37:45 --> Helper loaded: my_helper
INFO - 2021-01-05 03:37:45 --> Database Driver Class Initialized
DEBUG - 2021-01-05 03:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 03:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 03:37:45 --> Controller Class Initialized
ERROR - 2021-01-05 03:37:45 --> Severity: Notice --> Undefined index: catatan_akademik C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_rapot.php 92
DEBUG - 2021-01-05 03:37:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 03:37:45 --> Final output sent to browser
DEBUG - 2021-01-05 03:37:45 --> Total execution time: 0.3283
INFO - 2021-01-05 03:38:00 --> Config Class Initialized
INFO - 2021-01-05 03:38:00 --> Hooks Class Initialized
DEBUG - 2021-01-05 03:38:00 --> UTF-8 Support Enabled
INFO - 2021-01-05 03:38:00 --> Utf8 Class Initialized
INFO - 2021-01-05 03:38:01 --> URI Class Initialized
INFO - 2021-01-05 03:38:01 --> Router Class Initialized
INFO - 2021-01-05 03:38:01 --> Output Class Initialized
INFO - 2021-01-05 03:38:01 --> Security Class Initialized
DEBUG - 2021-01-05 03:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 03:38:01 --> Input Class Initialized
INFO - 2021-01-05 03:38:01 --> Language Class Initialized
INFO - 2021-01-05 03:38:01 --> Language Class Initialized
INFO - 2021-01-05 03:38:01 --> Config Class Initialized
INFO - 2021-01-05 03:38:01 --> Loader Class Initialized
INFO - 2021-01-05 03:38:01 --> Helper loaded: url_helper
INFO - 2021-01-05 03:38:01 --> Helper loaded: file_helper
INFO - 2021-01-05 03:38:01 --> Helper loaded: form_helper
INFO - 2021-01-05 03:38:01 --> Helper loaded: my_helper
INFO - 2021-01-05 03:38:01 --> Database Driver Class Initialized
DEBUG - 2021-01-05 03:38:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 03:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 03:38:01 --> Controller Class Initialized
ERROR - 2021-01-05 03:38:01 --> Severity: Notice --> Undefined variable: q_catatan_akademik C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_rapot.php 92
DEBUG - 2021-01-05 03:38:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 03:38:01 --> Final output sent to browser
DEBUG - 2021-01-05 03:38:01 --> Total execution time: 0.3146
INFO - 2021-01-05 03:38:58 --> Config Class Initialized
INFO - 2021-01-05 03:38:58 --> Hooks Class Initialized
DEBUG - 2021-01-05 03:38:58 --> UTF-8 Support Enabled
INFO - 2021-01-05 03:38:58 --> Utf8 Class Initialized
INFO - 2021-01-05 03:38:58 --> URI Class Initialized
INFO - 2021-01-05 03:38:58 --> Router Class Initialized
INFO - 2021-01-05 03:38:58 --> Output Class Initialized
INFO - 2021-01-05 03:38:58 --> Security Class Initialized
DEBUG - 2021-01-05 03:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 03:38:58 --> Input Class Initialized
INFO - 2021-01-05 03:38:58 --> Language Class Initialized
INFO - 2021-01-05 03:38:58 --> Language Class Initialized
INFO - 2021-01-05 03:38:58 --> Config Class Initialized
INFO - 2021-01-05 03:38:58 --> Loader Class Initialized
INFO - 2021-01-05 03:38:58 --> Helper loaded: url_helper
INFO - 2021-01-05 03:38:58 --> Helper loaded: file_helper
INFO - 2021-01-05 03:38:58 --> Helper loaded: form_helper
INFO - 2021-01-05 03:38:58 --> Helper loaded: my_helper
INFO - 2021-01-05 03:38:58 --> Database Driver Class Initialized
DEBUG - 2021-01-05 03:38:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 03:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 03:38:58 --> Controller Class Initialized
ERROR - 2021-01-05 03:38:58 --> Query error: Unknown column 'c_akademik' in 'field list' - Invalid query: SELECT 
                                            c_akademik
                                            FROM t_c_akademik
                                            WHERE id_siswa = 1418 AND ta = '20201'
INFO - 2021-01-05 03:38:58 --> Language file loaded: language/english/db_lang.php
INFO - 2021-01-05 03:39:19 --> Config Class Initialized
INFO - 2021-01-05 03:39:19 --> Hooks Class Initialized
DEBUG - 2021-01-05 03:39:19 --> UTF-8 Support Enabled
INFO - 2021-01-05 03:39:19 --> Utf8 Class Initialized
INFO - 2021-01-05 03:39:19 --> URI Class Initialized
INFO - 2021-01-05 03:39:19 --> Router Class Initialized
INFO - 2021-01-05 03:39:19 --> Output Class Initialized
INFO - 2021-01-05 03:39:19 --> Security Class Initialized
DEBUG - 2021-01-05 03:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 03:39:19 --> Input Class Initialized
INFO - 2021-01-05 03:39:19 --> Language Class Initialized
INFO - 2021-01-05 03:39:19 --> Language Class Initialized
INFO - 2021-01-05 03:39:19 --> Config Class Initialized
INFO - 2021-01-05 03:39:19 --> Loader Class Initialized
INFO - 2021-01-05 03:39:19 --> Helper loaded: url_helper
INFO - 2021-01-05 03:39:19 --> Helper loaded: file_helper
INFO - 2021-01-05 03:39:19 --> Helper loaded: form_helper
INFO - 2021-01-05 03:39:19 --> Helper loaded: my_helper
INFO - 2021-01-05 03:39:19 --> Database Driver Class Initialized
DEBUG - 2021-01-05 03:39:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 03:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 03:39:19 --> Controller Class Initialized
ERROR - 2021-01-05 03:39:19 --> Query error: Unknown column 'a.catatan_akademik' in 'field list' - Invalid query: SELECT 
                                            a.catatan_akademik
                                            FROM t_c_akademik
                                            WHERE id_siswa = 1418 AND ta = '20201'
INFO - 2021-01-05 03:39:19 --> Language file loaded: language/english/db_lang.php
INFO - 2021-01-05 03:39:31 --> Config Class Initialized
INFO - 2021-01-05 03:39:31 --> Hooks Class Initialized
DEBUG - 2021-01-05 03:39:31 --> UTF-8 Support Enabled
INFO - 2021-01-05 03:39:31 --> Utf8 Class Initialized
INFO - 2021-01-05 03:39:31 --> URI Class Initialized
INFO - 2021-01-05 03:39:31 --> Router Class Initialized
INFO - 2021-01-05 03:39:31 --> Output Class Initialized
INFO - 2021-01-05 03:39:31 --> Security Class Initialized
DEBUG - 2021-01-05 03:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 03:39:31 --> Input Class Initialized
INFO - 2021-01-05 03:39:31 --> Language Class Initialized
INFO - 2021-01-05 03:39:31 --> Language Class Initialized
INFO - 2021-01-05 03:39:31 --> Config Class Initialized
INFO - 2021-01-05 03:39:31 --> Loader Class Initialized
INFO - 2021-01-05 03:39:31 --> Helper loaded: url_helper
INFO - 2021-01-05 03:39:31 --> Helper loaded: file_helper
INFO - 2021-01-05 03:39:31 --> Helper loaded: form_helper
INFO - 2021-01-05 03:39:31 --> Helper loaded: my_helper
INFO - 2021-01-05 03:39:31 --> Database Driver Class Initialized
DEBUG - 2021-01-05 03:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 03:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 03:39:31 --> Controller Class Initialized
ERROR - 2021-01-05 03:39:31 --> Severity: Notice --> Undefined variable: q_catatan_akademik C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_rapot.php 92
DEBUG - 2021-01-05 03:39:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 03:39:31 --> Final output sent to browser
DEBUG - 2021-01-05 03:39:31 --> Total execution time: 0.2647
INFO - 2021-01-05 03:39:52 --> Config Class Initialized
INFO - 2021-01-05 03:39:52 --> Hooks Class Initialized
DEBUG - 2021-01-05 03:39:52 --> UTF-8 Support Enabled
INFO - 2021-01-05 03:39:52 --> Utf8 Class Initialized
INFO - 2021-01-05 03:39:52 --> URI Class Initialized
INFO - 2021-01-05 03:39:52 --> Router Class Initialized
INFO - 2021-01-05 03:39:52 --> Output Class Initialized
INFO - 2021-01-05 03:39:52 --> Security Class Initialized
DEBUG - 2021-01-05 03:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 03:39:52 --> Input Class Initialized
INFO - 2021-01-05 03:39:52 --> Language Class Initialized
INFO - 2021-01-05 03:39:52 --> Language Class Initialized
INFO - 2021-01-05 03:39:52 --> Config Class Initialized
INFO - 2021-01-05 03:39:52 --> Loader Class Initialized
INFO - 2021-01-05 03:39:52 --> Helper loaded: url_helper
INFO - 2021-01-05 03:39:52 --> Helper loaded: file_helper
INFO - 2021-01-05 03:39:52 --> Helper loaded: form_helper
INFO - 2021-01-05 03:39:52 --> Helper loaded: my_helper
INFO - 2021-01-05 03:39:52 --> Database Driver Class Initialized
DEBUG - 2021-01-05 03:39:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 03:39:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 03:39:52 --> Controller Class Initialized
ERROR - 2021-01-05 03:39:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_rapot.php 92
DEBUG - 2021-01-05 03:39:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 03:39:52 --> Final output sent to browser
DEBUG - 2021-01-05 03:39:52 --> Total execution time: 0.3311
INFO - 2021-01-05 03:40:36 --> Config Class Initialized
INFO - 2021-01-05 03:40:36 --> Hooks Class Initialized
DEBUG - 2021-01-05 03:40:36 --> UTF-8 Support Enabled
INFO - 2021-01-05 03:40:36 --> Utf8 Class Initialized
INFO - 2021-01-05 03:40:36 --> URI Class Initialized
INFO - 2021-01-05 03:40:36 --> Router Class Initialized
INFO - 2021-01-05 03:40:36 --> Output Class Initialized
INFO - 2021-01-05 03:40:36 --> Security Class Initialized
DEBUG - 2021-01-05 03:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 03:40:36 --> Input Class Initialized
INFO - 2021-01-05 03:40:36 --> Language Class Initialized
INFO - 2021-01-05 03:40:36 --> Language Class Initialized
INFO - 2021-01-05 03:40:36 --> Config Class Initialized
INFO - 2021-01-05 03:40:36 --> Loader Class Initialized
INFO - 2021-01-05 03:40:36 --> Helper loaded: url_helper
INFO - 2021-01-05 03:40:36 --> Helper loaded: file_helper
INFO - 2021-01-05 03:40:36 --> Helper loaded: form_helper
INFO - 2021-01-05 03:40:36 --> Helper loaded: my_helper
INFO - 2021-01-05 03:40:36 --> Database Driver Class Initialized
DEBUG - 2021-01-05 03:40:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 03:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 03:40:36 --> Controller Class Initialized
ERROR - 2021-01-05 03:40:36 --> Severity: Notice --> Undefined index: catatan_akademik C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_rapot.php 92
DEBUG - 2021-01-05 03:40:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 03:40:36 --> Final output sent to browser
DEBUG - 2021-01-05 03:40:36 --> Total execution time: 0.3115
INFO - 2021-01-05 03:42:38 --> Config Class Initialized
INFO - 2021-01-05 03:42:38 --> Hooks Class Initialized
DEBUG - 2021-01-05 03:42:38 --> UTF-8 Support Enabled
INFO - 2021-01-05 03:42:38 --> Utf8 Class Initialized
INFO - 2021-01-05 03:42:38 --> URI Class Initialized
INFO - 2021-01-05 03:42:38 --> Router Class Initialized
INFO - 2021-01-05 03:42:38 --> Output Class Initialized
INFO - 2021-01-05 03:42:38 --> Security Class Initialized
DEBUG - 2021-01-05 03:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 03:42:38 --> Input Class Initialized
INFO - 2021-01-05 03:42:38 --> Language Class Initialized
INFO - 2021-01-05 03:42:38 --> Language Class Initialized
INFO - 2021-01-05 03:42:38 --> Config Class Initialized
INFO - 2021-01-05 03:42:38 --> Loader Class Initialized
INFO - 2021-01-05 03:42:38 --> Helper loaded: url_helper
INFO - 2021-01-05 03:42:38 --> Helper loaded: file_helper
INFO - 2021-01-05 03:42:38 --> Helper loaded: form_helper
INFO - 2021-01-05 03:42:38 --> Helper loaded: my_helper
INFO - 2021-01-05 03:42:38 --> Database Driver Class Initialized
DEBUG - 2021-01-05 03:42:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 03:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 03:42:38 --> Controller Class Initialized
ERROR - 2021-01-05 03:42:38 --> Severity: Notice --> Undefined index: catatan_akademik C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_rapot.php 92
DEBUG - 2021-01-05 03:42:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 03:42:38 --> Final output sent to browser
DEBUG - 2021-01-05 03:42:38 --> Total execution time: 0.3339
INFO - 2021-01-05 03:47:17 --> Config Class Initialized
INFO - 2021-01-05 03:47:17 --> Hooks Class Initialized
DEBUG - 2021-01-05 03:47:17 --> UTF-8 Support Enabled
INFO - 2021-01-05 03:47:17 --> Utf8 Class Initialized
INFO - 2021-01-05 03:47:17 --> URI Class Initialized
INFO - 2021-01-05 03:47:17 --> Router Class Initialized
INFO - 2021-01-05 03:47:17 --> Output Class Initialized
INFO - 2021-01-05 03:47:17 --> Security Class Initialized
DEBUG - 2021-01-05 03:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 03:47:17 --> Input Class Initialized
INFO - 2021-01-05 03:47:17 --> Language Class Initialized
INFO - 2021-01-05 03:47:17 --> Language Class Initialized
INFO - 2021-01-05 03:47:17 --> Config Class Initialized
INFO - 2021-01-05 03:47:17 --> Loader Class Initialized
INFO - 2021-01-05 03:47:17 --> Helper loaded: url_helper
INFO - 2021-01-05 03:47:17 --> Helper loaded: file_helper
INFO - 2021-01-05 03:47:17 --> Helper loaded: form_helper
INFO - 2021-01-05 03:47:17 --> Helper loaded: my_helper
INFO - 2021-01-05 03:47:17 --> Database Driver Class Initialized
DEBUG - 2021-01-05 03:47:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 03:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 03:47:17 --> Controller Class Initialized
ERROR - 2021-01-05 03:47:17 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_rapot.php 92
DEBUG - 2021-01-05 03:47:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 03:47:17 --> Final output sent to browser
DEBUG - 2021-01-05 03:47:17 --> Total execution time: 0.3057
INFO - 2021-01-05 03:51:16 --> Config Class Initialized
INFO - 2021-01-05 03:51:16 --> Hooks Class Initialized
DEBUG - 2021-01-05 03:51:16 --> UTF-8 Support Enabled
INFO - 2021-01-05 03:51:16 --> Utf8 Class Initialized
INFO - 2021-01-05 03:51:16 --> URI Class Initialized
INFO - 2021-01-05 03:51:16 --> Router Class Initialized
INFO - 2021-01-05 03:51:16 --> Output Class Initialized
INFO - 2021-01-05 03:51:16 --> Security Class Initialized
DEBUG - 2021-01-05 03:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 03:51:16 --> Input Class Initialized
INFO - 2021-01-05 03:51:16 --> Language Class Initialized
INFO - 2021-01-05 03:51:16 --> Language Class Initialized
INFO - 2021-01-05 03:51:16 --> Config Class Initialized
INFO - 2021-01-05 03:51:16 --> Loader Class Initialized
INFO - 2021-01-05 03:51:16 --> Helper loaded: url_helper
INFO - 2021-01-05 03:51:16 --> Helper loaded: file_helper
INFO - 2021-01-05 03:51:16 --> Helper loaded: form_helper
INFO - 2021-01-05 03:51:16 --> Helper loaded: my_helper
INFO - 2021-01-05 03:51:16 --> Database Driver Class Initialized
DEBUG - 2021-01-05 03:51:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 03:51:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 03:51:16 --> Controller Class Initialized
ERROR - 2021-01-05 03:51:16 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_rapot.php 92
DEBUG - 2021-01-05 03:51:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 03:51:16 --> Final output sent to browser
DEBUG - 2021-01-05 03:51:16 --> Total execution time: 0.2505
INFO - 2021-01-05 03:51:57 --> Config Class Initialized
INFO - 2021-01-05 03:51:57 --> Hooks Class Initialized
DEBUG - 2021-01-05 03:51:57 --> UTF-8 Support Enabled
INFO - 2021-01-05 03:51:57 --> Utf8 Class Initialized
INFO - 2021-01-05 03:51:57 --> URI Class Initialized
INFO - 2021-01-05 03:51:57 --> Router Class Initialized
INFO - 2021-01-05 03:51:57 --> Output Class Initialized
INFO - 2021-01-05 03:51:57 --> Security Class Initialized
DEBUG - 2021-01-05 03:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 03:51:57 --> Input Class Initialized
INFO - 2021-01-05 03:51:57 --> Language Class Initialized
INFO - 2021-01-05 03:51:57 --> Language Class Initialized
INFO - 2021-01-05 03:51:57 --> Config Class Initialized
INFO - 2021-01-05 03:51:57 --> Loader Class Initialized
INFO - 2021-01-05 03:51:57 --> Helper loaded: url_helper
INFO - 2021-01-05 03:51:57 --> Helper loaded: file_helper
INFO - 2021-01-05 03:51:57 --> Helper loaded: form_helper
INFO - 2021-01-05 03:51:57 --> Helper loaded: my_helper
INFO - 2021-01-05 03:51:57 --> Database Driver Class Initialized
DEBUG - 2021-01-05 03:51:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 03:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 03:51:57 --> Controller Class Initialized
DEBUG - 2021-01-05 03:51:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-01-05 03:51:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-05 03:51:57 --> Final output sent to browser
DEBUG - 2021-01-05 03:51:57 --> Total execution time: 0.3136
INFO - 2021-01-05 03:53:17 --> Config Class Initialized
INFO - 2021-01-05 03:53:17 --> Hooks Class Initialized
DEBUG - 2021-01-05 03:53:17 --> UTF-8 Support Enabled
INFO - 2021-01-05 03:53:17 --> Utf8 Class Initialized
INFO - 2021-01-05 03:53:17 --> URI Class Initialized
INFO - 2021-01-05 03:53:17 --> Router Class Initialized
INFO - 2021-01-05 03:53:17 --> Output Class Initialized
INFO - 2021-01-05 03:53:17 --> Security Class Initialized
DEBUG - 2021-01-05 03:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 03:53:17 --> Input Class Initialized
INFO - 2021-01-05 03:53:17 --> Language Class Initialized
INFO - 2021-01-05 03:53:17 --> Language Class Initialized
INFO - 2021-01-05 03:53:17 --> Config Class Initialized
INFO - 2021-01-05 03:53:17 --> Loader Class Initialized
INFO - 2021-01-05 03:53:17 --> Helper loaded: url_helper
INFO - 2021-01-05 03:53:17 --> Helper loaded: file_helper
INFO - 2021-01-05 03:53:17 --> Helper loaded: form_helper
INFO - 2021-01-05 03:53:17 --> Helper loaded: my_helper
INFO - 2021-01-05 03:53:17 --> Database Driver Class Initialized
DEBUG - 2021-01-05 03:53:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 03:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 03:53:17 --> Controller Class Initialized
INFO - 2021-01-05 03:53:17 --> Final output sent to browser
DEBUG - 2021-01-05 03:53:17 --> Total execution time: 0.3852
INFO - 2021-01-05 03:53:24 --> Config Class Initialized
INFO - 2021-01-05 03:53:24 --> Hooks Class Initialized
DEBUG - 2021-01-05 03:53:24 --> UTF-8 Support Enabled
INFO - 2021-01-05 03:53:24 --> Utf8 Class Initialized
INFO - 2021-01-05 03:53:24 --> URI Class Initialized
INFO - 2021-01-05 03:53:24 --> Router Class Initialized
INFO - 2021-01-05 03:53:24 --> Output Class Initialized
INFO - 2021-01-05 03:53:24 --> Security Class Initialized
DEBUG - 2021-01-05 03:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 03:53:24 --> Input Class Initialized
INFO - 2021-01-05 03:53:24 --> Language Class Initialized
INFO - 2021-01-05 03:53:25 --> Language Class Initialized
INFO - 2021-01-05 03:53:25 --> Config Class Initialized
INFO - 2021-01-05 03:53:25 --> Loader Class Initialized
INFO - 2021-01-05 03:53:25 --> Helper loaded: url_helper
INFO - 2021-01-05 03:53:25 --> Helper loaded: file_helper
INFO - 2021-01-05 03:53:25 --> Helper loaded: form_helper
INFO - 2021-01-05 03:53:25 --> Helper loaded: my_helper
INFO - 2021-01-05 03:53:25 --> Database Driver Class Initialized
DEBUG - 2021-01-05 03:53:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 03:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 03:53:25 --> Controller Class Initialized
ERROR - 2021-01-05 03:53:25 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_rapot.php 92
DEBUG - 2021-01-05 03:53:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 03:53:25 --> Final output sent to browser
DEBUG - 2021-01-05 03:53:25 --> Total execution time: 0.2904
INFO - 2021-01-05 03:55:50 --> Config Class Initialized
INFO - 2021-01-05 03:55:50 --> Hooks Class Initialized
DEBUG - 2021-01-05 03:55:50 --> UTF-8 Support Enabled
INFO - 2021-01-05 03:55:50 --> Utf8 Class Initialized
INFO - 2021-01-05 03:55:50 --> URI Class Initialized
INFO - 2021-01-05 03:55:50 --> Router Class Initialized
INFO - 2021-01-05 03:55:50 --> Output Class Initialized
INFO - 2021-01-05 03:55:50 --> Security Class Initialized
DEBUG - 2021-01-05 03:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 03:55:50 --> Input Class Initialized
INFO - 2021-01-05 03:55:50 --> Language Class Initialized
INFO - 2021-01-05 03:55:50 --> Language Class Initialized
INFO - 2021-01-05 03:55:50 --> Config Class Initialized
INFO - 2021-01-05 03:55:50 --> Loader Class Initialized
INFO - 2021-01-05 03:55:50 --> Helper loaded: url_helper
INFO - 2021-01-05 03:55:50 --> Helper loaded: file_helper
INFO - 2021-01-05 03:55:50 --> Helper loaded: form_helper
INFO - 2021-01-05 03:55:50 --> Helper loaded: my_helper
INFO - 2021-01-05 03:55:50 --> Database Driver Class Initialized
DEBUG - 2021-01-05 03:55:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 03:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 03:55:50 --> Controller Class Initialized
ERROR - 2021-01-05 03:55:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_rapot.php 96
DEBUG - 2021-01-05 03:55:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 03:55:50 --> Final output sent to browser
DEBUG - 2021-01-05 03:55:50 --> Total execution time: 0.3942
INFO - 2021-01-05 03:56:50 --> Config Class Initialized
INFO - 2021-01-05 03:56:50 --> Hooks Class Initialized
DEBUG - 2021-01-05 03:56:50 --> UTF-8 Support Enabled
INFO - 2021-01-05 03:56:50 --> Utf8 Class Initialized
INFO - 2021-01-05 03:56:50 --> URI Class Initialized
INFO - 2021-01-05 03:56:50 --> Router Class Initialized
INFO - 2021-01-05 03:56:50 --> Output Class Initialized
INFO - 2021-01-05 03:56:50 --> Security Class Initialized
DEBUG - 2021-01-05 03:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 03:56:50 --> Input Class Initialized
INFO - 2021-01-05 03:56:50 --> Language Class Initialized
INFO - 2021-01-05 03:56:50 --> Language Class Initialized
INFO - 2021-01-05 03:56:50 --> Config Class Initialized
INFO - 2021-01-05 03:56:50 --> Loader Class Initialized
INFO - 2021-01-05 03:56:50 --> Helper loaded: url_helper
INFO - 2021-01-05 03:56:50 --> Helper loaded: file_helper
INFO - 2021-01-05 03:56:50 --> Helper loaded: form_helper
INFO - 2021-01-05 03:56:50 --> Helper loaded: my_helper
INFO - 2021-01-05 03:56:50 --> Database Driver Class Initialized
DEBUG - 2021-01-05 03:56:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 03:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 03:56:50 --> Controller Class Initialized
ERROR - 2021-01-05 03:56:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_rapot.php 92
DEBUG - 2021-01-05 03:56:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 03:56:51 --> Final output sent to browser
DEBUG - 2021-01-05 03:56:51 --> Total execution time: 0.3246
INFO - 2021-01-05 04:00:01 --> Config Class Initialized
INFO - 2021-01-05 04:00:01 --> Hooks Class Initialized
DEBUG - 2021-01-05 04:00:01 --> UTF-8 Support Enabled
INFO - 2021-01-05 04:00:01 --> Utf8 Class Initialized
INFO - 2021-01-05 04:00:01 --> URI Class Initialized
INFO - 2021-01-05 04:00:01 --> Router Class Initialized
INFO - 2021-01-05 04:00:01 --> Output Class Initialized
INFO - 2021-01-05 04:00:01 --> Security Class Initialized
DEBUG - 2021-01-05 04:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 04:00:01 --> Input Class Initialized
INFO - 2021-01-05 04:00:01 --> Language Class Initialized
INFO - 2021-01-05 04:00:01 --> Language Class Initialized
INFO - 2021-01-05 04:00:01 --> Config Class Initialized
INFO - 2021-01-05 04:00:01 --> Loader Class Initialized
INFO - 2021-01-05 04:00:01 --> Helper loaded: url_helper
INFO - 2021-01-05 04:00:01 --> Helper loaded: file_helper
INFO - 2021-01-05 04:00:01 --> Helper loaded: form_helper
INFO - 2021-01-05 04:00:01 --> Helper loaded: my_helper
INFO - 2021-01-05 04:00:01 --> Database Driver Class Initialized
DEBUG - 2021-01-05 04:00:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 04:00:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 04:00:01 --> Controller Class Initialized
ERROR - 2021-01-05 04:00:01 --> Query error: Unknown table 'db_nilai.a' - Invalid query: SELECT 
                                            a.*
                                            FROM t_c_akademik
                                            WHERE id_siswa = 1418 AND ta = '20201'
INFO - 2021-01-05 04:00:01 --> Language file loaded: language/english/db_lang.php
INFO - 2021-01-05 04:00:42 --> Config Class Initialized
INFO - 2021-01-05 04:00:42 --> Hooks Class Initialized
DEBUG - 2021-01-05 04:00:42 --> UTF-8 Support Enabled
INFO - 2021-01-05 04:00:42 --> Utf8 Class Initialized
INFO - 2021-01-05 04:00:42 --> URI Class Initialized
INFO - 2021-01-05 04:00:42 --> Router Class Initialized
INFO - 2021-01-05 04:00:42 --> Output Class Initialized
INFO - 2021-01-05 04:00:42 --> Security Class Initialized
DEBUG - 2021-01-05 04:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 04:00:42 --> Input Class Initialized
INFO - 2021-01-05 04:00:42 --> Language Class Initialized
INFO - 2021-01-05 04:00:42 --> Language Class Initialized
INFO - 2021-01-05 04:00:42 --> Config Class Initialized
INFO - 2021-01-05 04:00:42 --> Loader Class Initialized
INFO - 2021-01-05 04:00:42 --> Helper loaded: url_helper
INFO - 2021-01-05 04:00:42 --> Helper loaded: file_helper
INFO - 2021-01-05 04:00:42 --> Helper loaded: form_helper
INFO - 2021-01-05 04:00:42 --> Helper loaded: my_helper
INFO - 2021-01-05 04:00:42 --> Database Driver Class Initialized
DEBUG - 2021-01-05 04:00:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 04:00:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 04:00:42 --> Controller Class Initialized
DEBUG - 2021-01-05 04:00:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-05 04:00:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-05 04:00:42 --> Final output sent to browser
DEBUG - 2021-01-05 04:00:42 --> Total execution time: 0.3472
INFO - 2021-01-05 04:00:43 --> Config Class Initialized
INFO - 2021-01-05 04:00:43 --> Hooks Class Initialized
DEBUG - 2021-01-05 04:00:43 --> UTF-8 Support Enabled
INFO - 2021-01-05 04:00:43 --> Utf8 Class Initialized
INFO - 2021-01-05 04:00:43 --> URI Class Initialized
INFO - 2021-01-05 04:00:43 --> Router Class Initialized
INFO - 2021-01-05 04:00:43 --> Output Class Initialized
INFO - 2021-01-05 04:00:43 --> Security Class Initialized
DEBUG - 2021-01-05 04:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 04:00:43 --> Input Class Initialized
INFO - 2021-01-05 04:00:43 --> Language Class Initialized
INFO - 2021-01-05 04:00:43 --> Language Class Initialized
INFO - 2021-01-05 04:00:43 --> Config Class Initialized
INFO - 2021-01-05 04:00:43 --> Loader Class Initialized
INFO - 2021-01-05 04:00:43 --> Helper loaded: url_helper
INFO - 2021-01-05 04:00:43 --> Helper loaded: file_helper
INFO - 2021-01-05 04:00:43 --> Helper loaded: form_helper
INFO - 2021-01-05 04:00:43 --> Helper loaded: my_helper
INFO - 2021-01-05 04:00:43 --> Database Driver Class Initialized
DEBUG - 2021-01-05 04:00:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 04:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 04:00:43 --> Controller Class Initialized
DEBUG - 2021-01-05 04:00:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_prestasi.php
INFO - 2021-01-05 04:00:43 --> Final output sent to browser
DEBUG - 2021-01-05 04:00:43 --> Total execution time: 0.3174
INFO - 2021-01-05 04:02:42 --> Config Class Initialized
INFO - 2021-01-05 04:02:42 --> Hooks Class Initialized
DEBUG - 2021-01-05 04:02:42 --> UTF-8 Support Enabled
INFO - 2021-01-05 04:02:42 --> Utf8 Class Initialized
INFO - 2021-01-05 04:02:42 --> URI Class Initialized
INFO - 2021-01-05 04:02:42 --> Router Class Initialized
INFO - 2021-01-05 04:02:42 --> Output Class Initialized
INFO - 2021-01-05 04:02:42 --> Security Class Initialized
DEBUG - 2021-01-05 04:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 04:02:42 --> Input Class Initialized
INFO - 2021-01-05 04:02:42 --> Language Class Initialized
INFO - 2021-01-05 04:02:42 --> Language Class Initialized
INFO - 2021-01-05 04:02:42 --> Config Class Initialized
INFO - 2021-01-05 04:02:42 --> Loader Class Initialized
INFO - 2021-01-05 04:02:42 --> Helper loaded: url_helper
INFO - 2021-01-05 04:02:42 --> Helper loaded: file_helper
INFO - 2021-01-05 04:02:42 --> Helper loaded: form_helper
INFO - 2021-01-05 04:02:42 --> Helper loaded: my_helper
INFO - 2021-01-05 04:02:42 --> Database Driver Class Initialized
DEBUG - 2021-01-05 04:02:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 04:02:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 04:02:42 --> Controller Class Initialized
ERROR - 2021-01-05 04:02:42 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_rapot.php 92
DEBUG - 2021-01-05 04:02:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 04:02:42 --> Final output sent to browser
DEBUG - 2021-01-05 04:02:42 --> Total execution time: 0.3020
INFO - 2021-01-05 04:02:57 --> Config Class Initialized
INFO - 2021-01-05 04:02:57 --> Hooks Class Initialized
DEBUG - 2021-01-05 04:02:57 --> UTF-8 Support Enabled
INFO - 2021-01-05 04:02:57 --> Utf8 Class Initialized
INFO - 2021-01-05 04:02:57 --> URI Class Initialized
INFO - 2021-01-05 04:02:57 --> Router Class Initialized
INFO - 2021-01-05 04:02:57 --> Output Class Initialized
INFO - 2021-01-05 04:02:57 --> Security Class Initialized
DEBUG - 2021-01-05 04:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 04:02:57 --> Input Class Initialized
INFO - 2021-01-05 04:02:57 --> Language Class Initialized
INFO - 2021-01-05 04:02:57 --> Language Class Initialized
INFO - 2021-01-05 04:02:57 --> Config Class Initialized
INFO - 2021-01-05 04:02:57 --> Loader Class Initialized
INFO - 2021-01-05 04:02:57 --> Helper loaded: url_helper
INFO - 2021-01-05 04:02:57 --> Helper loaded: file_helper
INFO - 2021-01-05 04:02:57 --> Helper loaded: form_helper
INFO - 2021-01-05 04:02:57 --> Helper loaded: my_helper
INFO - 2021-01-05 04:02:57 --> Database Driver Class Initialized
DEBUG - 2021-01-05 04:02:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 04:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 04:02:57 --> Controller Class Initialized
ERROR - 2021-01-05 04:02:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_rapot.php 92
DEBUG - 2021-01-05 04:02:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 04:02:57 --> Final output sent to browser
DEBUG - 2021-01-05 04:02:57 --> Total execution time: 0.2808
INFO - 2021-01-05 04:03:05 --> Config Class Initialized
INFO - 2021-01-05 04:03:05 --> Hooks Class Initialized
DEBUG - 2021-01-05 04:03:05 --> UTF-8 Support Enabled
INFO - 2021-01-05 04:03:05 --> Utf8 Class Initialized
INFO - 2021-01-05 04:03:05 --> URI Class Initialized
INFO - 2021-01-05 04:03:05 --> Router Class Initialized
INFO - 2021-01-05 04:03:05 --> Output Class Initialized
INFO - 2021-01-05 04:03:05 --> Security Class Initialized
DEBUG - 2021-01-05 04:03:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 04:03:05 --> Input Class Initialized
INFO - 2021-01-05 04:03:05 --> Language Class Initialized
INFO - 2021-01-05 04:03:05 --> Language Class Initialized
INFO - 2021-01-05 04:03:06 --> Config Class Initialized
INFO - 2021-01-05 04:03:06 --> Loader Class Initialized
INFO - 2021-01-05 04:03:06 --> Helper loaded: url_helper
INFO - 2021-01-05 04:03:06 --> Helper loaded: file_helper
INFO - 2021-01-05 04:03:06 --> Helper loaded: form_helper
INFO - 2021-01-05 04:03:06 --> Helper loaded: my_helper
INFO - 2021-01-05 04:03:06 --> Database Driver Class Initialized
DEBUG - 2021-01-05 04:03:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 04:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 04:03:06 --> Controller Class Initialized
ERROR - 2021-01-05 04:03:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_rapot.php 92
DEBUG - 2021-01-05 04:03:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 04:03:06 --> Final output sent to browser
DEBUG - 2021-01-05 04:03:06 --> Total execution time: 0.2740
INFO - 2021-01-05 04:04:10 --> Config Class Initialized
INFO - 2021-01-05 04:04:10 --> Hooks Class Initialized
DEBUG - 2021-01-05 04:04:10 --> UTF-8 Support Enabled
INFO - 2021-01-05 04:04:10 --> Utf8 Class Initialized
INFO - 2021-01-05 04:04:10 --> URI Class Initialized
INFO - 2021-01-05 04:04:10 --> Router Class Initialized
INFO - 2021-01-05 04:04:10 --> Output Class Initialized
INFO - 2021-01-05 04:04:10 --> Security Class Initialized
DEBUG - 2021-01-05 04:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 04:04:10 --> Input Class Initialized
INFO - 2021-01-05 04:04:10 --> Language Class Initialized
INFO - 2021-01-05 04:04:10 --> Language Class Initialized
INFO - 2021-01-05 04:04:10 --> Config Class Initialized
INFO - 2021-01-05 04:04:10 --> Loader Class Initialized
INFO - 2021-01-05 04:04:10 --> Helper loaded: url_helper
INFO - 2021-01-05 04:04:10 --> Helper loaded: file_helper
INFO - 2021-01-05 04:04:10 --> Helper loaded: form_helper
INFO - 2021-01-05 04:04:10 --> Helper loaded: my_helper
INFO - 2021-01-05 04:04:10 --> Database Driver Class Initialized
DEBUG - 2021-01-05 04:04:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 04:04:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 04:04:10 --> Controller Class Initialized
DEBUG - 2021-01-05 04:04:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_prestasi.php
INFO - 2021-01-05 04:04:10 --> Final output sent to browser
DEBUG - 2021-01-05 04:04:10 --> Total execution time: 0.2913
INFO - 2021-01-05 04:04:33 --> Config Class Initialized
INFO - 2021-01-05 04:04:33 --> Hooks Class Initialized
DEBUG - 2021-01-05 04:04:33 --> UTF-8 Support Enabled
INFO - 2021-01-05 04:04:33 --> Utf8 Class Initialized
INFO - 2021-01-05 04:04:33 --> URI Class Initialized
INFO - 2021-01-05 04:04:34 --> Router Class Initialized
INFO - 2021-01-05 04:04:34 --> Output Class Initialized
INFO - 2021-01-05 04:04:34 --> Security Class Initialized
DEBUG - 2021-01-05 04:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 04:04:34 --> Input Class Initialized
INFO - 2021-01-05 04:04:34 --> Language Class Initialized
INFO - 2021-01-05 04:04:34 --> Language Class Initialized
INFO - 2021-01-05 04:04:34 --> Config Class Initialized
INFO - 2021-01-05 04:04:34 --> Loader Class Initialized
INFO - 2021-01-05 04:04:34 --> Helper loaded: url_helper
INFO - 2021-01-05 04:04:34 --> Helper loaded: file_helper
INFO - 2021-01-05 04:04:34 --> Helper loaded: form_helper
INFO - 2021-01-05 04:04:34 --> Helper loaded: my_helper
INFO - 2021-01-05 04:04:34 --> Database Driver Class Initialized
DEBUG - 2021-01-05 04:04:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 04:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 04:04:34 --> Controller Class Initialized
INFO - 2021-01-05 04:04:34 --> Final output sent to browser
DEBUG - 2021-01-05 04:04:34 --> Total execution time: 0.3033
INFO - 2021-01-05 04:13:17 --> Config Class Initialized
INFO - 2021-01-05 04:13:17 --> Hooks Class Initialized
DEBUG - 2021-01-05 04:13:17 --> UTF-8 Support Enabled
INFO - 2021-01-05 04:13:17 --> Utf8 Class Initialized
INFO - 2021-01-05 04:13:17 --> URI Class Initialized
INFO - 2021-01-05 04:13:17 --> Router Class Initialized
INFO - 2021-01-05 04:13:17 --> Output Class Initialized
INFO - 2021-01-05 04:13:17 --> Security Class Initialized
DEBUG - 2021-01-05 04:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 04:13:17 --> Input Class Initialized
INFO - 2021-01-05 04:13:17 --> Language Class Initialized
INFO - 2021-01-05 04:13:17 --> Language Class Initialized
INFO - 2021-01-05 04:13:17 --> Config Class Initialized
INFO - 2021-01-05 04:13:17 --> Loader Class Initialized
INFO - 2021-01-05 04:13:17 --> Helper loaded: url_helper
INFO - 2021-01-05 04:13:17 --> Helper loaded: file_helper
INFO - 2021-01-05 04:13:17 --> Helper loaded: form_helper
INFO - 2021-01-05 04:13:17 --> Helper loaded: my_helper
INFO - 2021-01-05 04:13:17 --> Database Driver Class Initialized
DEBUG - 2021-01-05 04:13:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 04:13:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 04:13:17 --> Controller Class Initialized
ERROR - 2021-01-05 04:13:17 --> Severity: Notice --> Undefined variable: catatan_akademik C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_rapot.php 92
DEBUG - 2021-01-05 04:13:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 04:13:17 --> Final output sent to browser
DEBUG - 2021-01-05 04:13:17 --> Total execution time: 0.2528
INFO - 2021-01-05 04:13:43 --> Config Class Initialized
INFO - 2021-01-05 04:13:43 --> Hooks Class Initialized
DEBUG - 2021-01-05 04:13:43 --> UTF-8 Support Enabled
INFO - 2021-01-05 04:13:43 --> Utf8 Class Initialized
INFO - 2021-01-05 04:13:43 --> URI Class Initialized
INFO - 2021-01-05 04:13:43 --> Router Class Initialized
INFO - 2021-01-05 04:13:43 --> Output Class Initialized
INFO - 2021-01-05 04:13:43 --> Security Class Initialized
DEBUG - 2021-01-05 04:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 04:13:43 --> Input Class Initialized
INFO - 2021-01-05 04:13:44 --> Language Class Initialized
INFO - 2021-01-05 04:13:44 --> Language Class Initialized
INFO - 2021-01-05 04:13:44 --> Config Class Initialized
INFO - 2021-01-05 04:13:44 --> Loader Class Initialized
INFO - 2021-01-05 04:13:44 --> Helper loaded: url_helper
INFO - 2021-01-05 04:13:44 --> Helper loaded: file_helper
INFO - 2021-01-05 04:13:44 --> Helper loaded: form_helper
INFO - 2021-01-05 04:13:44 --> Helper loaded: my_helper
INFO - 2021-01-05 04:13:44 --> Database Driver Class Initialized
DEBUG - 2021-01-05 04:13:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 04:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 04:13:44 --> Controller Class Initialized
ERROR - 2021-01-05 04:13:44 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_rapot.php 92
DEBUG - 2021-01-05 04:13:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 04:13:44 --> Final output sent to browser
DEBUG - 2021-01-05 04:13:44 --> Total execution time: 0.3136
INFO - 2021-01-05 04:13:57 --> Config Class Initialized
INFO - 2021-01-05 04:13:57 --> Hooks Class Initialized
DEBUG - 2021-01-05 04:13:57 --> UTF-8 Support Enabled
INFO - 2021-01-05 04:13:57 --> Utf8 Class Initialized
INFO - 2021-01-05 04:13:57 --> URI Class Initialized
INFO - 2021-01-05 04:13:57 --> Router Class Initialized
INFO - 2021-01-05 04:13:57 --> Output Class Initialized
INFO - 2021-01-05 04:13:57 --> Security Class Initialized
DEBUG - 2021-01-05 04:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 04:13:57 --> Input Class Initialized
INFO - 2021-01-05 04:13:57 --> Language Class Initialized
INFO - 2021-01-05 04:13:57 --> Language Class Initialized
INFO - 2021-01-05 04:13:57 --> Config Class Initialized
INFO - 2021-01-05 04:13:57 --> Loader Class Initialized
INFO - 2021-01-05 04:13:57 --> Helper loaded: url_helper
INFO - 2021-01-05 04:13:57 --> Helper loaded: file_helper
INFO - 2021-01-05 04:13:57 --> Helper loaded: form_helper
INFO - 2021-01-05 04:13:57 --> Helper loaded: my_helper
INFO - 2021-01-05 04:13:57 --> Database Driver Class Initialized
DEBUG - 2021-01-05 04:13:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 04:13:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 04:13:57 --> Controller Class Initialized
ERROR - 2021-01-05 04:13:57 --> Severity: Notice --> Undefined variable: catatan_akademik C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_rapot.php 92
DEBUG - 2021-01-05 04:13:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 04:13:57 --> Final output sent to browser
DEBUG - 2021-01-05 04:13:57 --> Total execution time: 0.3270
INFO - 2021-01-05 04:14:03 --> Config Class Initialized
INFO - 2021-01-05 04:14:03 --> Hooks Class Initialized
DEBUG - 2021-01-05 04:14:03 --> UTF-8 Support Enabled
INFO - 2021-01-05 04:14:03 --> Utf8 Class Initialized
INFO - 2021-01-05 04:14:03 --> URI Class Initialized
INFO - 2021-01-05 04:14:03 --> Router Class Initialized
INFO - 2021-01-05 04:14:03 --> Output Class Initialized
INFO - 2021-01-05 04:14:03 --> Security Class Initialized
DEBUG - 2021-01-05 04:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 04:14:03 --> Input Class Initialized
INFO - 2021-01-05 04:14:03 --> Language Class Initialized
INFO - 2021-01-05 04:14:03 --> Language Class Initialized
INFO - 2021-01-05 04:14:03 --> Config Class Initialized
INFO - 2021-01-05 04:14:03 --> Loader Class Initialized
INFO - 2021-01-05 04:14:03 --> Helper loaded: url_helper
INFO - 2021-01-05 04:14:04 --> Helper loaded: file_helper
INFO - 2021-01-05 04:14:04 --> Helper loaded: form_helper
INFO - 2021-01-05 04:14:04 --> Helper loaded: my_helper
INFO - 2021-01-05 04:14:04 --> Database Driver Class Initialized
DEBUG - 2021-01-05 04:14:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 04:14:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 04:14:04 --> Controller Class Initialized
ERROR - 2021-01-05 04:14:04 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_rapot.php 92
DEBUG - 2021-01-05 04:14:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 04:14:04 --> Final output sent to browser
DEBUG - 2021-01-05 04:14:04 --> Total execution time: 0.2942
INFO - 2021-01-05 04:15:30 --> Config Class Initialized
INFO - 2021-01-05 04:15:30 --> Hooks Class Initialized
DEBUG - 2021-01-05 04:15:30 --> UTF-8 Support Enabled
INFO - 2021-01-05 04:15:30 --> Utf8 Class Initialized
INFO - 2021-01-05 04:15:30 --> URI Class Initialized
INFO - 2021-01-05 04:15:30 --> Router Class Initialized
INFO - 2021-01-05 04:15:30 --> Output Class Initialized
INFO - 2021-01-05 04:15:30 --> Security Class Initialized
DEBUG - 2021-01-05 04:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 04:15:30 --> Input Class Initialized
INFO - 2021-01-05 04:15:30 --> Language Class Initialized
INFO - 2021-01-05 04:15:30 --> Language Class Initialized
INFO - 2021-01-05 04:15:30 --> Config Class Initialized
INFO - 2021-01-05 04:15:30 --> Loader Class Initialized
INFO - 2021-01-05 04:15:30 --> Helper loaded: url_helper
INFO - 2021-01-05 04:15:30 --> Helper loaded: file_helper
INFO - 2021-01-05 04:15:30 --> Helper loaded: form_helper
INFO - 2021-01-05 04:15:30 --> Helper loaded: my_helper
INFO - 2021-01-05 04:15:30 --> Database Driver Class Initialized
DEBUG - 2021-01-05 04:15:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 04:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 04:15:30 --> Controller Class Initialized
ERROR - 2021-01-05 04:15:30 --> Severity: Notice --> Undefined variable: catatan_akademik C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_rapot.php 92
DEBUG - 2021-01-05 04:15:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 04:15:30 --> Final output sent to browser
DEBUG - 2021-01-05 04:15:30 --> Total execution time: 0.3375
INFO - 2021-01-05 04:16:05 --> Config Class Initialized
INFO - 2021-01-05 04:16:05 --> Hooks Class Initialized
DEBUG - 2021-01-05 04:16:05 --> UTF-8 Support Enabled
INFO - 2021-01-05 04:16:05 --> Utf8 Class Initialized
INFO - 2021-01-05 04:16:05 --> URI Class Initialized
INFO - 2021-01-05 04:16:05 --> Router Class Initialized
INFO - 2021-01-05 04:16:05 --> Output Class Initialized
INFO - 2021-01-05 04:16:05 --> Security Class Initialized
DEBUG - 2021-01-05 04:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 04:16:05 --> Input Class Initialized
INFO - 2021-01-05 04:16:05 --> Language Class Initialized
INFO - 2021-01-05 04:16:05 --> Language Class Initialized
INFO - 2021-01-05 04:16:05 --> Config Class Initialized
INFO - 2021-01-05 04:16:05 --> Loader Class Initialized
INFO - 2021-01-05 04:16:05 --> Helper loaded: url_helper
INFO - 2021-01-05 04:16:05 --> Helper loaded: file_helper
INFO - 2021-01-05 04:16:05 --> Helper loaded: form_helper
INFO - 2021-01-05 04:16:05 --> Helper loaded: my_helper
INFO - 2021-01-05 04:16:05 --> Database Driver Class Initialized
DEBUG - 2021-01-05 04:16:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 04:16:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 04:16:05 --> Controller Class Initialized
ERROR - 2021-01-05 04:16:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_rapot.php 92
DEBUG - 2021-01-05 04:16:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 04:16:05 --> Final output sent to browser
DEBUG - 2021-01-05 04:16:05 --> Total execution time: 0.2695
INFO - 2021-01-05 04:16:48 --> Config Class Initialized
INFO - 2021-01-05 04:16:48 --> Hooks Class Initialized
DEBUG - 2021-01-05 04:16:48 --> UTF-8 Support Enabled
INFO - 2021-01-05 04:16:48 --> Utf8 Class Initialized
INFO - 2021-01-05 04:16:48 --> URI Class Initialized
INFO - 2021-01-05 04:16:48 --> Router Class Initialized
INFO - 2021-01-05 04:16:48 --> Output Class Initialized
INFO - 2021-01-05 04:16:48 --> Security Class Initialized
DEBUG - 2021-01-05 04:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 04:16:48 --> Input Class Initialized
INFO - 2021-01-05 04:16:48 --> Language Class Initialized
INFO - 2021-01-05 04:16:48 --> Language Class Initialized
INFO - 2021-01-05 04:16:48 --> Config Class Initialized
INFO - 2021-01-05 04:16:48 --> Loader Class Initialized
INFO - 2021-01-05 04:16:48 --> Helper loaded: url_helper
INFO - 2021-01-05 04:16:48 --> Helper loaded: file_helper
INFO - 2021-01-05 04:16:48 --> Helper loaded: form_helper
INFO - 2021-01-05 04:16:48 --> Helper loaded: my_helper
INFO - 2021-01-05 04:16:48 --> Database Driver Class Initialized
DEBUG - 2021-01-05 04:16:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 04:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 04:16:49 --> Controller Class Initialized
ERROR - 2021-01-05 04:16:49 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_rapot.php 92
DEBUG - 2021-01-05 04:16:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 04:16:49 --> Final output sent to browser
DEBUG - 2021-01-05 04:16:49 --> Total execution time: 0.2710
INFO - 2021-01-05 04:17:12 --> Config Class Initialized
INFO - 2021-01-05 04:17:12 --> Hooks Class Initialized
DEBUG - 2021-01-05 04:17:12 --> UTF-8 Support Enabled
INFO - 2021-01-05 04:17:12 --> Utf8 Class Initialized
INFO - 2021-01-05 04:17:12 --> URI Class Initialized
INFO - 2021-01-05 04:17:12 --> Router Class Initialized
INFO - 2021-01-05 04:17:12 --> Output Class Initialized
INFO - 2021-01-05 04:17:12 --> Security Class Initialized
DEBUG - 2021-01-05 04:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 04:17:12 --> Input Class Initialized
INFO - 2021-01-05 04:17:12 --> Language Class Initialized
INFO - 2021-01-05 04:17:12 --> Language Class Initialized
INFO - 2021-01-05 04:17:12 --> Config Class Initialized
INFO - 2021-01-05 04:17:12 --> Loader Class Initialized
INFO - 2021-01-05 04:17:12 --> Helper loaded: url_helper
INFO - 2021-01-05 04:17:12 --> Helper loaded: file_helper
INFO - 2021-01-05 04:17:12 --> Helper loaded: form_helper
INFO - 2021-01-05 04:17:12 --> Helper loaded: my_helper
INFO - 2021-01-05 04:17:12 --> Database Driver Class Initialized
DEBUG - 2021-01-05 04:17:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 04:17:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 04:17:12 --> Controller Class Initialized
ERROR - 2021-01-05 04:17:12 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_rapot.php 92
DEBUG - 2021-01-05 04:17:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 04:17:12 --> Final output sent to browser
DEBUG - 2021-01-05 04:17:12 --> Total execution time: 0.3105
INFO - 2021-01-05 04:17:22 --> Config Class Initialized
INFO - 2021-01-05 04:17:22 --> Hooks Class Initialized
DEBUG - 2021-01-05 04:17:22 --> UTF-8 Support Enabled
INFO - 2021-01-05 04:17:22 --> Utf8 Class Initialized
INFO - 2021-01-05 04:17:22 --> URI Class Initialized
INFO - 2021-01-05 04:17:22 --> Router Class Initialized
INFO - 2021-01-05 04:17:22 --> Output Class Initialized
INFO - 2021-01-05 04:17:22 --> Security Class Initialized
DEBUG - 2021-01-05 04:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 04:17:22 --> Input Class Initialized
INFO - 2021-01-05 04:17:22 --> Language Class Initialized
INFO - 2021-01-05 04:17:22 --> Language Class Initialized
INFO - 2021-01-05 04:17:22 --> Config Class Initialized
INFO - 2021-01-05 04:17:22 --> Loader Class Initialized
INFO - 2021-01-05 04:17:22 --> Helper loaded: url_helper
INFO - 2021-01-05 04:17:22 --> Helper loaded: file_helper
INFO - 2021-01-05 04:17:22 --> Helper loaded: form_helper
INFO - 2021-01-05 04:17:22 --> Helper loaded: my_helper
INFO - 2021-01-05 04:17:22 --> Database Driver Class Initialized
DEBUG - 2021-01-05 04:17:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 04:17:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 04:17:22 --> Controller Class Initialized
ERROR - 2021-01-05 04:17:22 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_rapot.php 92
DEBUG - 2021-01-05 04:17:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 04:17:22 --> Final output sent to browser
DEBUG - 2021-01-05 04:17:22 --> Total execution time: 0.2918
INFO - 2021-01-05 04:18:56 --> Config Class Initialized
INFO - 2021-01-05 04:18:56 --> Hooks Class Initialized
DEBUG - 2021-01-05 04:18:56 --> UTF-8 Support Enabled
INFO - 2021-01-05 04:18:56 --> Utf8 Class Initialized
INFO - 2021-01-05 04:18:56 --> URI Class Initialized
INFO - 2021-01-05 04:18:56 --> Router Class Initialized
INFO - 2021-01-05 04:18:56 --> Output Class Initialized
INFO - 2021-01-05 04:18:56 --> Security Class Initialized
DEBUG - 2021-01-05 04:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 04:18:56 --> Input Class Initialized
INFO - 2021-01-05 04:18:56 --> Language Class Initialized
INFO - 2021-01-05 04:18:56 --> Language Class Initialized
INFO - 2021-01-05 04:18:56 --> Config Class Initialized
INFO - 2021-01-05 04:18:56 --> Loader Class Initialized
INFO - 2021-01-05 04:18:56 --> Helper loaded: url_helper
INFO - 2021-01-05 04:18:56 --> Helper loaded: file_helper
INFO - 2021-01-05 04:18:56 --> Helper loaded: form_helper
INFO - 2021-01-05 04:18:56 --> Helper loaded: my_helper
INFO - 2021-01-05 04:18:56 --> Database Driver Class Initialized
DEBUG - 2021-01-05 04:18:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 04:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 04:18:57 --> Controller Class Initialized
ERROR - 2021-01-05 04:18:57 --> Query error: Unknown table 'db_nilai.a' - Invalid query: SELECT 
                                    a.*
                                    FROM t_c_akademik  
                                    WHERE a.id_siswa = 1418 AND a.ta = '20201'
INFO - 2021-01-05 04:18:57 --> Language file loaded: language/english/db_lang.php
INFO - 2021-01-05 04:21:53 --> Config Class Initialized
INFO - 2021-01-05 04:21:53 --> Hooks Class Initialized
DEBUG - 2021-01-05 04:21:53 --> UTF-8 Support Enabled
INFO - 2021-01-05 04:21:53 --> Utf8 Class Initialized
INFO - 2021-01-05 04:21:53 --> URI Class Initialized
INFO - 2021-01-05 04:21:53 --> Router Class Initialized
INFO - 2021-01-05 04:21:53 --> Output Class Initialized
INFO - 2021-01-05 04:21:53 --> Security Class Initialized
DEBUG - 2021-01-05 04:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 04:21:53 --> Input Class Initialized
INFO - 2021-01-05 04:21:53 --> Language Class Initialized
INFO - 2021-01-05 04:21:54 --> Language Class Initialized
INFO - 2021-01-05 04:21:54 --> Config Class Initialized
INFO - 2021-01-05 04:21:54 --> Loader Class Initialized
INFO - 2021-01-05 04:21:54 --> Helper loaded: url_helper
INFO - 2021-01-05 04:21:54 --> Helper loaded: file_helper
INFO - 2021-01-05 04:21:54 --> Helper loaded: form_helper
INFO - 2021-01-05 04:21:54 --> Helper loaded: my_helper
INFO - 2021-01-05 04:21:54 --> Database Driver Class Initialized
DEBUG - 2021-01-05 04:21:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 04:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 04:21:54 --> Controller Class Initialized
ERROR - 2021-01-05 04:21:54 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_rapot.php 92
DEBUG - 2021-01-05 04:21:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 04:21:54 --> Final output sent to browser
DEBUG - 2021-01-05 04:21:54 --> Total execution time: 0.2850
INFO - 2021-01-05 04:21:59 --> Config Class Initialized
INFO - 2021-01-05 04:21:59 --> Hooks Class Initialized
DEBUG - 2021-01-05 04:21:59 --> UTF-8 Support Enabled
INFO - 2021-01-05 04:21:59 --> Utf8 Class Initialized
INFO - 2021-01-05 04:21:59 --> URI Class Initialized
INFO - 2021-01-05 04:21:59 --> Router Class Initialized
INFO - 2021-01-05 04:21:59 --> Output Class Initialized
INFO - 2021-01-05 04:21:59 --> Security Class Initialized
DEBUG - 2021-01-05 04:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 04:21:59 --> Input Class Initialized
INFO - 2021-01-05 04:21:59 --> Language Class Initialized
INFO - 2021-01-05 04:21:59 --> Language Class Initialized
INFO - 2021-01-05 04:21:59 --> Config Class Initialized
INFO - 2021-01-05 04:21:59 --> Loader Class Initialized
INFO - 2021-01-05 04:21:59 --> Helper loaded: url_helper
INFO - 2021-01-05 04:21:59 --> Helper loaded: file_helper
INFO - 2021-01-05 04:21:59 --> Helper loaded: form_helper
INFO - 2021-01-05 04:21:59 --> Helper loaded: my_helper
INFO - 2021-01-05 04:21:59 --> Database Driver Class Initialized
DEBUG - 2021-01-05 04:21:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 04:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 04:21:59 --> Controller Class Initialized
ERROR - 2021-01-05 04:21:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_rapot.php 92
DEBUG - 2021-01-05 04:21:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 04:21:59 --> Final output sent to browser
DEBUG - 2021-01-05 04:21:59 --> Total execution time: 0.2679
INFO - 2021-01-05 04:29:39 --> Config Class Initialized
INFO - 2021-01-05 04:29:39 --> Hooks Class Initialized
DEBUG - 2021-01-05 04:29:39 --> UTF-8 Support Enabled
INFO - 2021-01-05 04:29:39 --> Utf8 Class Initialized
INFO - 2021-01-05 04:29:39 --> URI Class Initialized
INFO - 2021-01-05 04:29:39 --> Router Class Initialized
INFO - 2021-01-05 04:29:39 --> Output Class Initialized
INFO - 2021-01-05 04:29:39 --> Security Class Initialized
DEBUG - 2021-01-05 04:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 04:29:39 --> Input Class Initialized
INFO - 2021-01-05 04:29:39 --> Language Class Initialized
INFO - 2021-01-05 04:29:39 --> Language Class Initialized
INFO - 2021-01-05 04:29:39 --> Config Class Initialized
INFO - 2021-01-05 04:29:39 --> Loader Class Initialized
INFO - 2021-01-05 04:29:39 --> Helper loaded: url_helper
INFO - 2021-01-05 04:29:39 --> Helper loaded: file_helper
INFO - 2021-01-05 04:29:39 --> Helper loaded: form_helper
INFO - 2021-01-05 04:29:39 --> Helper loaded: my_helper
INFO - 2021-01-05 04:29:39 --> Database Driver Class Initialized
DEBUG - 2021-01-05 04:29:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 04:29:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 04:29:39 --> Controller Class Initialized
ERROR - 2021-01-05 04:29:39 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_rapot.php 92
DEBUG - 2021-01-05 04:29:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 04:29:39 --> Final output sent to browser
DEBUG - 2021-01-05 04:29:39 --> Total execution time: 0.2589
INFO - 2021-01-05 04:30:16 --> Config Class Initialized
INFO - 2021-01-05 04:30:16 --> Hooks Class Initialized
DEBUG - 2021-01-05 04:30:17 --> UTF-8 Support Enabled
INFO - 2021-01-05 04:30:17 --> Utf8 Class Initialized
INFO - 2021-01-05 04:30:17 --> URI Class Initialized
INFO - 2021-01-05 04:30:17 --> Router Class Initialized
INFO - 2021-01-05 04:30:17 --> Output Class Initialized
INFO - 2021-01-05 04:30:17 --> Security Class Initialized
DEBUG - 2021-01-05 04:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 04:30:17 --> Input Class Initialized
INFO - 2021-01-05 04:30:17 --> Language Class Initialized
INFO - 2021-01-05 04:30:17 --> Language Class Initialized
INFO - 2021-01-05 04:30:17 --> Config Class Initialized
INFO - 2021-01-05 04:30:17 --> Loader Class Initialized
INFO - 2021-01-05 04:30:17 --> Helper loaded: url_helper
INFO - 2021-01-05 04:30:17 --> Helper loaded: file_helper
INFO - 2021-01-05 04:30:17 --> Helper loaded: form_helper
INFO - 2021-01-05 04:30:17 --> Helper loaded: my_helper
INFO - 2021-01-05 04:30:17 --> Database Driver Class Initialized
DEBUG - 2021-01-05 04:30:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 04:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 04:30:17 --> Controller Class Initialized
ERROR - 2021-01-05 04:30:17 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_rapot.php 92
DEBUG - 2021-01-05 04:30:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 04:30:17 --> Final output sent to browser
DEBUG - 2021-01-05 04:30:17 --> Total execution time: 0.2945
INFO - 2021-01-05 04:32:10 --> Config Class Initialized
INFO - 2021-01-05 04:32:10 --> Hooks Class Initialized
DEBUG - 2021-01-05 04:32:10 --> UTF-8 Support Enabled
INFO - 2021-01-05 04:32:10 --> Utf8 Class Initialized
INFO - 2021-01-05 04:32:10 --> URI Class Initialized
INFO - 2021-01-05 04:32:10 --> Router Class Initialized
INFO - 2021-01-05 04:32:10 --> Output Class Initialized
INFO - 2021-01-05 04:32:10 --> Security Class Initialized
DEBUG - 2021-01-05 04:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 04:32:10 --> Input Class Initialized
INFO - 2021-01-05 04:32:10 --> Language Class Initialized
INFO - 2021-01-05 04:32:10 --> Language Class Initialized
INFO - 2021-01-05 04:32:10 --> Config Class Initialized
INFO - 2021-01-05 04:32:10 --> Loader Class Initialized
INFO - 2021-01-05 04:32:10 --> Helper loaded: url_helper
INFO - 2021-01-05 04:32:10 --> Helper loaded: file_helper
INFO - 2021-01-05 04:32:10 --> Helper loaded: form_helper
INFO - 2021-01-05 04:32:10 --> Helper loaded: my_helper
INFO - 2021-01-05 04:32:10 --> Database Driver Class Initialized
DEBUG - 2021-01-05 04:32:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 04:32:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 04:32:10 --> Controller Class Initialized
ERROR - 2021-01-05 04:32:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_rapot.php 92
DEBUG - 2021-01-05 04:32:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 04:32:10 --> Final output sent to browser
DEBUG - 2021-01-05 04:32:10 --> Total execution time: 0.2613
INFO - 2021-01-05 04:38:18 --> Config Class Initialized
INFO - 2021-01-05 04:38:18 --> Hooks Class Initialized
DEBUG - 2021-01-05 04:38:18 --> UTF-8 Support Enabled
INFO - 2021-01-05 04:38:18 --> Utf8 Class Initialized
INFO - 2021-01-05 04:38:18 --> URI Class Initialized
INFO - 2021-01-05 04:38:18 --> Router Class Initialized
INFO - 2021-01-05 04:38:18 --> Output Class Initialized
INFO - 2021-01-05 04:38:18 --> Security Class Initialized
DEBUG - 2021-01-05 04:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 04:38:18 --> Input Class Initialized
INFO - 2021-01-05 04:38:18 --> Language Class Initialized
INFO - 2021-01-05 04:38:18 --> Language Class Initialized
INFO - 2021-01-05 04:38:18 --> Config Class Initialized
INFO - 2021-01-05 04:38:18 --> Loader Class Initialized
INFO - 2021-01-05 04:38:18 --> Helper loaded: url_helper
INFO - 2021-01-05 04:38:18 --> Helper loaded: file_helper
INFO - 2021-01-05 04:38:18 --> Helper loaded: form_helper
INFO - 2021-01-05 04:38:18 --> Helper loaded: my_helper
INFO - 2021-01-05 04:38:18 --> Database Driver Class Initialized
DEBUG - 2021-01-05 04:38:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 04:38:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 04:38:18 --> Controller Class Initialized
DEBUG - 2021-01-05 04:38:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 04:38:18 --> Final output sent to browser
DEBUG - 2021-01-05 04:38:18 --> Total execution time: 0.3047
INFO - 2021-01-05 04:39:03 --> Config Class Initialized
INFO - 2021-01-05 04:39:03 --> Hooks Class Initialized
DEBUG - 2021-01-05 04:39:03 --> UTF-8 Support Enabled
INFO - 2021-01-05 04:39:03 --> Utf8 Class Initialized
INFO - 2021-01-05 04:39:03 --> URI Class Initialized
INFO - 2021-01-05 04:39:03 --> Router Class Initialized
INFO - 2021-01-05 04:39:03 --> Output Class Initialized
INFO - 2021-01-05 04:39:03 --> Security Class Initialized
DEBUG - 2021-01-05 04:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 04:39:03 --> Input Class Initialized
INFO - 2021-01-05 04:39:03 --> Language Class Initialized
INFO - 2021-01-05 04:39:03 --> Language Class Initialized
INFO - 2021-01-05 04:39:03 --> Config Class Initialized
INFO - 2021-01-05 04:39:03 --> Loader Class Initialized
INFO - 2021-01-05 04:39:03 --> Helper loaded: url_helper
INFO - 2021-01-05 04:39:03 --> Helper loaded: file_helper
INFO - 2021-01-05 04:39:03 --> Helper loaded: form_helper
INFO - 2021-01-05 04:39:03 --> Helper loaded: my_helper
INFO - 2021-01-05 04:39:03 --> Database Driver Class Initialized
DEBUG - 2021-01-05 04:39:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 04:39:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 04:39:03 --> Controller Class Initialized
DEBUG - 2021-01-05 04:39:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 04:39:03 --> Final output sent to browser
DEBUG - 2021-01-05 04:39:03 --> Total execution time: 0.3213
INFO - 2021-01-05 04:40:07 --> Config Class Initialized
INFO - 2021-01-05 04:40:07 --> Hooks Class Initialized
DEBUG - 2021-01-05 04:40:07 --> UTF-8 Support Enabled
INFO - 2021-01-05 04:40:07 --> Utf8 Class Initialized
INFO - 2021-01-05 04:40:07 --> URI Class Initialized
INFO - 2021-01-05 04:40:07 --> Router Class Initialized
INFO - 2021-01-05 04:40:07 --> Output Class Initialized
INFO - 2021-01-05 04:40:07 --> Security Class Initialized
DEBUG - 2021-01-05 04:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 04:40:07 --> Input Class Initialized
INFO - 2021-01-05 04:40:07 --> Language Class Initialized
INFO - 2021-01-05 04:40:07 --> Language Class Initialized
INFO - 2021-01-05 04:40:07 --> Config Class Initialized
INFO - 2021-01-05 04:40:07 --> Loader Class Initialized
INFO - 2021-01-05 04:40:07 --> Helper loaded: url_helper
INFO - 2021-01-05 04:40:07 --> Helper loaded: file_helper
INFO - 2021-01-05 04:40:07 --> Helper loaded: form_helper
INFO - 2021-01-05 04:40:07 --> Helper loaded: my_helper
INFO - 2021-01-05 04:40:07 --> Database Driver Class Initialized
DEBUG - 2021-01-05 04:40:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 04:40:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 04:40:07 --> Controller Class Initialized
DEBUG - 2021-01-05 04:40:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 04:40:07 --> Final output sent to browser
DEBUG - 2021-01-05 04:40:07 --> Total execution time: 0.3051
INFO - 2021-01-05 04:40:08 --> Config Class Initialized
INFO - 2021-01-05 04:40:08 --> Hooks Class Initialized
DEBUG - 2021-01-05 04:40:08 --> UTF-8 Support Enabled
INFO - 2021-01-05 04:40:08 --> Utf8 Class Initialized
INFO - 2021-01-05 04:40:08 --> URI Class Initialized
INFO - 2021-01-05 04:40:08 --> Router Class Initialized
INFO - 2021-01-05 04:40:08 --> Output Class Initialized
INFO - 2021-01-05 04:40:08 --> Security Class Initialized
DEBUG - 2021-01-05 04:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 04:40:08 --> Input Class Initialized
INFO - 2021-01-05 04:40:08 --> Language Class Initialized
INFO - 2021-01-05 04:40:08 --> Language Class Initialized
INFO - 2021-01-05 04:40:08 --> Config Class Initialized
INFO - 2021-01-05 04:40:08 --> Loader Class Initialized
INFO - 2021-01-05 04:40:08 --> Helper loaded: url_helper
INFO - 2021-01-05 04:40:08 --> Helper loaded: file_helper
INFO - 2021-01-05 04:40:08 --> Helper loaded: form_helper
INFO - 2021-01-05 04:40:08 --> Helper loaded: my_helper
INFO - 2021-01-05 04:40:08 --> Database Driver Class Initialized
DEBUG - 2021-01-05 04:40:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 04:40:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 04:40:08 --> Controller Class Initialized
DEBUG - 2021-01-05 04:40:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 04:40:08 --> Final output sent to browser
DEBUG - 2021-01-05 04:40:08 --> Total execution time: 0.2495
INFO - 2021-01-05 04:41:24 --> Config Class Initialized
INFO - 2021-01-05 04:41:24 --> Hooks Class Initialized
DEBUG - 2021-01-05 04:41:24 --> UTF-8 Support Enabled
INFO - 2021-01-05 04:41:24 --> Utf8 Class Initialized
INFO - 2021-01-05 04:41:24 --> URI Class Initialized
INFO - 2021-01-05 04:41:24 --> Router Class Initialized
INFO - 2021-01-05 04:41:24 --> Output Class Initialized
INFO - 2021-01-05 04:41:24 --> Security Class Initialized
DEBUG - 2021-01-05 04:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 04:41:24 --> Input Class Initialized
INFO - 2021-01-05 04:41:24 --> Language Class Initialized
INFO - 2021-01-05 04:41:24 --> Language Class Initialized
INFO - 2021-01-05 04:41:24 --> Config Class Initialized
INFO - 2021-01-05 04:41:24 --> Loader Class Initialized
INFO - 2021-01-05 04:41:24 --> Helper loaded: url_helper
INFO - 2021-01-05 04:41:24 --> Helper loaded: file_helper
INFO - 2021-01-05 04:41:24 --> Helper loaded: form_helper
INFO - 2021-01-05 04:41:24 --> Helper loaded: my_helper
INFO - 2021-01-05 04:41:24 --> Database Driver Class Initialized
DEBUG - 2021-01-05 04:41:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 04:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 04:41:24 --> Controller Class Initialized
DEBUG - 2021-01-05 04:41:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 04:41:24 --> Final output sent to browser
DEBUG - 2021-01-05 04:41:24 --> Total execution time: 0.3020
INFO - 2021-01-05 04:42:40 --> Config Class Initialized
INFO - 2021-01-05 04:42:40 --> Hooks Class Initialized
DEBUG - 2021-01-05 04:42:40 --> UTF-8 Support Enabled
INFO - 2021-01-05 04:42:40 --> Utf8 Class Initialized
INFO - 2021-01-05 04:42:41 --> URI Class Initialized
INFO - 2021-01-05 04:42:41 --> Router Class Initialized
INFO - 2021-01-05 04:42:41 --> Output Class Initialized
INFO - 2021-01-05 04:42:41 --> Security Class Initialized
DEBUG - 2021-01-05 04:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 04:42:41 --> Input Class Initialized
INFO - 2021-01-05 04:42:41 --> Language Class Initialized
INFO - 2021-01-05 04:42:41 --> Language Class Initialized
INFO - 2021-01-05 04:42:41 --> Config Class Initialized
INFO - 2021-01-05 04:42:41 --> Loader Class Initialized
INFO - 2021-01-05 04:42:41 --> Helper loaded: url_helper
INFO - 2021-01-05 04:42:41 --> Helper loaded: file_helper
INFO - 2021-01-05 04:42:41 --> Helper loaded: form_helper
INFO - 2021-01-05 04:42:41 --> Helper loaded: my_helper
INFO - 2021-01-05 04:42:41 --> Database Driver Class Initialized
DEBUG - 2021-01-05 04:42:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 04:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 04:42:41 --> Controller Class Initialized
DEBUG - 2021-01-05 04:42:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 04:42:41 --> Final output sent to browser
DEBUG - 2021-01-05 04:42:41 --> Total execution time: 0.3739
INFO - 2021-01-05 04:42:58 --> Config Class Initialized
INFO - 2021-01-05 04:42:58 --> Hooks Class Initialized
DEBUG - 2021-01-05 04:42:58 --> UTF-8 Support Enabled
INFO - 2021-01-05 04:42:58 --> Utf8 Class Initialized
INFO - 2021-01-05 04:42:58 --> URI Class Initialized
INFO - 2021-01-05 04:42:58 --> Router Class Initialized
INFO - 2021-01-05 04:42:58 --> Output Class Initialized
INFO - 2021-01-05 04:42:58 --> Security Class Initialized
DEBUG - 2021-01-05 04:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 04:42:58 --> Input Class Initialized
INFO - 2021-01-05 04:42:58 --> Language Class Initialized
INFO - 2021-01-05 04:42:58 --> Language Class Initialized
INFO - 2021-01-05 04:42:58 --> Config Class Initialized
INFO - 2021-01-05 04:42:58 --> Loader Class Initialized
INFO - 2021-01-05 04:42:58 --> Helper loaded: url_helper
INFO - 2021-01-05 04:42:58 --> Helper loaded: file_helper
INFO - 2021-01-05 04:42:58 --> Helper loaded: form_helper
INFO - 2021-01-05 04:42:58 --> Helper loaded: my_helper
INFO - 2021-01-05 04:42:58 --> Database Driver Class Initialized
DEBUG - 2021-01-05 04:42:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 04:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 04:42:58 --> Controller Class Initialized
DEBUG - 2021-01-05 04:42:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 04:42:58 --> Final output sent to browser
DEBUG - 2021-01-05 04:42:58 --> Total execution time: 0.3227
INFO - 2021-01-05 04:43:12 --> Config Class Initialized
INFO - 2021-01-05 04:43:12 --> Hooks Class Initialized
DEBUG - 2021-01-05 04:43:12 --> UTF-8 Support Enabled
INFO - 2021-01-05 04:43:12 --> Utf8 Class Initialized
INFO - 2021-01-05 04:43:12 --> URI Class Initialized
INFO - 2021-01-05 04:43:12 --> Router Class Initialized
INFO - 2021-01-05 04:43:12 --> Output Class Initialized
INFO - 2021-01-05 04:43:12 --> Security Class Initialized
DEBUG - 2021-01-05 04:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 04:43:12 --> Input Class Initialized
INFO - 2021-01-05 04:43:12 --> Language Class Initialized
INFO - 2021-01-05 04:43:12 --> Language Class Initialized
INFO - 2021-01-05 04:43:12 --> Config Class Initialized
INFO - 2021-01-05 04:43:12 --> Loader Class Initialized
INFO - 2021-01-05 04:43:12 --> Helper loaded: url_helper
INFO - 2021-01-05 04:43:12 --> Helper loaded: file_helper
INFO - 2021-01-05 04:43:12 --> Helper loaded: form_helper
INFO - 2021-01-05 04:43:12 --> Helper loaded: my_helper
INFO - 2021-01-05 04:43:12 --> Database Driver Class Initialized
DEBUG - 2021-01-05 04:43:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 04:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 04:43:12 --> Controller Class Initialized
DEBUG - 2021-01-05 04:43:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 04:43:12 --> Final output sent to browser
DEBUG - 2021-01-05 04:43:12 --> Total execution time: 0.3042
INFO - 2021-01-05 04:43:28 --> Config Class Initialized
INFO - 2021-01-05 04:43:28 --> Hooks Class Initialized
DEBUG - 2021-01-05 04:43:28 --> UTF-8 Support Enabled
INFO - 2021-01-05 04:43:28 --> Utf8 Class Initialized
INFO - 2021-01-05 04:43:28 --> URI Class Initialized
INFO - 2021-01-05 04:43:28 --> Router Class Initialized
INFO - 2021-01-05 04:43:28 --> Output Class Initialized
INFO - 2021-01-05 04:43:28 --> Security Class Initialized
DEBUG - 2021-01-05 04:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 04:43:28 --> Input Class Initialized
INFO - 2021-01-05 04:43:28 --> Language Class Initialized
INFO - 2021-01-05 04:43:28 --> Language Class Initialized
INFO - 2021-01-05 04:43:28 --> Config Class Initialized
INFO - 2021-01-05 04:43:28 --> Loader Class Initialized
INFO - 2021-01-05 04:43:28 --> Helper loaded: url_helper
INFO - 2021-01-05 04:43:28 --> Helper loaded: file_helper
INFO - 2021-01-05 04:43:28 --> Helper loaded: form_helper
INFO - 2021-01-05 04:43:28 --> Helper loaded: my_helper
INFO - 2021-01-05 04:43:28 --> Database Driver Class Initialized
DEBUG - 2021-01-05 04:43:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 04:43:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 04:43:28 --> Controller Class Initialized
DEBUG - 2021-01-05 04:43:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 04:43:28 --> Final output sent to browser
DEBUG - 2021-01-05 04:43:28 --> Total execution time: 0.3004
INFO - 2021-01-05 04:43:39 --> Config Class Initialized
INFO - 2021-01-05 04:43:39 --> Hooks Class Initialized
DEBUG - 2021-01-05 04:43:39 --> UTF-8 Support Enabled
INFO - 2021-01-05 04:43:39 --> Utf8 Class Initialized
INFO - 2021-01-05 04:43:39 --> URI Class Initialized
INFO - 2021-01-05 04:43:39 --> Router Class Initialized
INFO - 2021-01-05 04:43:39 --> Output Class Initialized
INFO - 2021-01-05 04:43:39 --> Security Class Initialized
DEBUG - 2021-01-05 04:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 04:43:39 --> Input Class Initialized
INFO - 2021-01-05 04:43:39 --> Language Class Initialized
INFO - 2021-01-05 04:43:39 --> Language Class Initialized
INFO - 2021-01-05 04:43:39 --> Config Class Initialized
INFO - 2021-01-05 04:43:39 --> Loader Class Initialized
INFO - 2021-01-05 04:43:39 --> Helper loaded: url_helper
INFO - 2021-01-05 04:43:39 --> Helper loaded: file_helper
INFO - 2021-01-05 04:43:39 --> Helper loaded: form_helper
INFO - 2021-01-05 04:43:39 --> Helper loaded: my_helper
INFO - 2021-01-05 04:43:39 --> Database Driver Class Initialized
DEBUG - 2021-01-05 04:43:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 04:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 04:43:39 --> Controller Class Initialized
DEBUG - 2021-01-05 04:43:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 04:43:39 --> Final output sent to browser
DEBUG - 2021-01-05 04:43:39 --> Total execution time: 0.3192
INFO - 2021-01-05 04:44:07 --> Config Class Initialized
INFO - 2021-01-05 04:44:07 --> Hooks Class Initialized
DEBUG - 2021-01-05 04:44:07 --> UTF-8 Support Enabled
INFO - 2021-01-05 04:44:07 --> Utf8 Class Initialized
INFO - 2021-01-05 04:44:08 --> URI Class Initialized
INFO - 2021-01-05 04:44:08 --> Router Class Initialized
INFO - 2021-01-05 04:44:08 --> Output Class Initialized
INFO - 2021-01-05 04:44:08 --> Security Class Initialized
DEBUG - 2021-01-05 04:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 04:44:08 --> Input Class Initialized
INFO - 2021-01-05 04:44:08 --> Language Class Initialized
INFO - 2021-01-05 04:44:08 --> Language Class Initialized
INFO - 2021-01-05 04:44:08 --> Config Class Initialized
INFO - 2021-01-05 04:44:08 --> Loader Class Initialized
INFO - 2021-01-05 04:44:08 --> Helper loaded: url_helper
INFO - 2021-01-05 04:44:08 --> Helper loaded: file_helper
INFO - 2021-01-05 04:44:08 --> Helper loaded: form_helper
INFO - 2021-01-05 04:44:08 --> Helper loaded: my_helper
INFO - 2021-01-05 04:44:08 --> Database Driver Class Initialized
DEBUG - 2021-01-05 04:44:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 04:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 04:44:08 --> Controller Class Initialized
DEBUG - 2021-01-05 04:44:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 04:44:08 --> Final output sent to browser
DEBUG - 2021-01-05 04:44:08 --> Total execution time: 0.3066
INFO - 2021-01-05 04:48:04 --> Config Class Initialized
INFO - 2021-01-05 04:48:04 --> Hooks Class Initialized
DEBUG - 2021-01-05 04:48:04 --> UTF-8 Support Enabled
INFO - 2021-01-05 04:48:04 --> Utf8 Class Initialized
INFO - 2021-01-05 04:48:04 --> URI Class Initialized
INFO - 2021-01-05 04:48:04 --> Router Class Initialized
INFO - 2021-01-05 04:48:04 --> Output Class Initialized
INFO - 2021-01-05 04:48:05 --> Security Class Initialized
DEBUG - 2021-01-05 04:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 04:48:05 --> Input Class Initialized
INFO - 2021-01-05 04:48:05 --> Language Class Initialized
INFO - 2021-01-05 04:48:05 --> Language Class Initialized
INFO - 2021-01-05 04:48:05 --> Config Class Initialized
INFO - 2021-01-05 04:48:05 --> Loader Class Initialized
INFO - 2021-01-05 04:48:05 --> Helper loaded: url_helper
INFO - 2021-01-05 04:48:05 --> Helper loaded: file_helper
INFO - 2021-01-05 04:48:05 --> Helper loaded: form_helper
INFO - 2021-01-05 04:48:05 --> Helper loaded: my_helper
INFO - 2021-01-05 04:48:05 --> Database Driver Class Initialized
DEBUG - 2021-01-05 04:48:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 04:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 04:48:05 --> Controller Class Initialized
DEBUG - 2021-01-05 04:48:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2021-01-05 04:48:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-05 04:48:05 --> Final output sent to browser
DEBUG - 2021-01-05 04:48:05 --> Total execution time: 0.3950
INFO - 2021-01-05 05:15:16 --> Config Class Initialized
INFO - 2021-01-05 05:15:16 --> Hooks Class Initialized
DEBUG - 2021-01-05 05:15:16 --> UTF-8 Support Enabled
INFO - 2021-01-05 05:15:16 --> Utf8 Class Initialized
INFO - 2021-01-05 05:15:16 --> URI Class Initialized
INFO - 2021-01-05 05:15:16 --> Router Class Initialized
INFO - 2021-01-05 05:15:16 --> Output Class Initialized
INFO - 2021-01-05 05:15:16 --> Security Class Initialized
DEBUG - 2021-01-05 05:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 05:15:16 --> Input Class Initialized
INFO - 2021-01-05 05:15:16 --> Language Class Initialized
INFO - 2021-01-05 05:15:16 --> Language Class Initialized
INFO - 2021-01-05 05:15:16 --> Config Class Initialized
INFO - 2021-01-05 05:15:16 --> Loader Class Initialized
INFO - 2021-01-05 05:15:16 --> Helper loaded: url_helper
INFO - 2021-01-05 05:15:16 --> Helper loaded: file_helper
INFO - 2021-01-05 05:15:16 --> Helper loaded: form_helper
INFO - 2021-01-05 05:15:16 --> Helper loaded: my_helper
INFO - 2021-01-05 05:15:16 --> Database Driver Class Initialized
DEBUG - 2021-01-05 05:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 05:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 05:15:16 --> Controller Class Initialized
ERROR - 2021-01-05 05:15:16 --> Severity: Notice --> Undefined variable: no C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_rapot.php 140
DEBUG - 2021-01-05 05:15:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 05:15:16 --> Final output sent to browser
DEBUG - 2021-01-05 05:15:16 --> Total execution time: 0.3675
INFO - 2021-01-05 05:18:10 --> Config Class Initialized
INFO - 2021-01-05 05:18:10 --> Hooks Class Initialized
DEBUG - 2021-01-05 05:18:10 --> UTF-8 Support Enabled
INFO - 2021-01-05 05:18:10 --> Utf8 Class Initialized
INFO - 2021-01-05 05:18:10 --> URI Class Initialized
INFO - 2021-01-05 05:18:10 --> Router Class Initialized
INFO - 2021-01-05 05:18:10 --> Output Class Initialized
INFO - 2021-01-05 05:18:10 --> Security Class Initialized
DEBUG - 2021-01-05 05:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 05:18:10 --> Input Class Initialized
INFO - 2021-01-05 05:18:10 --> Language Class Initialized
INFO - 2021-01-05 05:18:10 --> Language Class Initialized
INFO - 2021-01-05 05:18:10 --> Config Class Initialized
INFO - 2021-01-05 05:18:10 --> Loader Class Initialized
INFO - 2021-01-05 05:18:10 --> Helper loaded: url_helper
INFO - 2021-01-05 05:18:10 --> Helper loaded: file_helper
INFO - 2021-01-05 05:18:10 --> Helper loaded: form_helper
INFO - 2021-01-05 05:18:10 --> Helper loaded: my_helper
INFO - 2021-01-05 05:18:10 --> Database Driver Class Initialized
DEBUG - 2021-01-05 05:18:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 05:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 05:18:10 --> Controller Class Initialized
DEBUG - 2021-01-05 05:18:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 05:18:10 --> Final output sent to browser
DEBUG - 2021-01-05 05:18:10 --> Total execution time: 0.3348
INFO - 2021-01-05 05:20:33 --> Config Class Initialized
INFO - 2021-01-05 05:20:33 --> Hooks Class Initialized
DEBUG - 2021-01-05 05:20:33 --> UTF-8 Support Enabled
INFO - 2021-01-05 05:20:33 --> Utf8 Class Initialized
INFO - 2021-01-05 05:20:33 --> URI Class Initialized
INFO - 2021-01-05 05:20:33 --> Router Class Initialized
INFO - 2021-01-05 05:20:33 --> Output Class Initialized
INFO - 2021-01-05 05:20:33 --> Security Class Initialized
DEBUG - 2021-01-05 05:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 05:20:33 --> Input Class Initialized
INFO - 2021-01-05 05:20:33 --> Language Class Initialized
INFO - 2021-01-05 05:20:33 --> Language Class Initialized
INFO - 2021-01-05 05:20:33 --> Config Class Initialized
INFO - 2021-01-05 05:20:33 --> Loader Class Initialized
INFO - 2021-01-05 05:20:33 --> Helper loaded: url_helper
INFO - 2021-01-05 05:20:33 --> Helper loaded: file_helper
INFO - 2021-01-05 05:20:33 --> Helper loaded: form_helper
INFO - 2021-01-05 05:20:33 --> Helper loaded: my_helper
INFO - 2021-01-05 05:20:33 --> Database Driver Class Initialized
DEBUG - 2021-01-05 05:20:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 05:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 05:20:33 --> Controller Class Initialized
DEBUG - 2021-01-05 05:20:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 05:20:33 --> Final output sent to browser
DEBUG - 2021-01-05 05:20:33 --> Total execution time: 0.3941
INFO - 2021-01-05 05:23:20 --> Config Class Initialized
INFO - 2021-01-05 05:23:20 --> Hooks Class Initialized
DEBUG - 2021-01-05 05:23:20 --> UTF-8 Support Enabled
INFO - 2021-01-05 05:23:20 --> Utf8 Class Initialized
INFO - 2021-01-05 05:23:20 --> URI Class Initialized
INFO - 2021-01-05 05:23:20 --> Router Class Initialized
INFO - 2021-01-05 05:23:20 --> Output Class Initialized
INFO - 2021-01-05 05:23:20 --> Security Class Initialized
DEBUG - 2021-01-05 05:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 05:23:20 --> Input Class Initialized
INFO - 2021-01-05 05:23:20 --> Language Class Initialized
INFO - 2021-01-05 05:23:20 --> Language Class Initialized
INFO - 2021-01-05 05:23:20 --> Config Class Initialized
INFO - 2021-01-05 05:23:20 --> Loader Class Initialized
INFO - 2021-01-05 05:23:20 --> Helper loaded: url_helper
INFO - 2021-01-05 05:23:20 --> Helper loaded: file_helper
INFO - 2021-01-05 05:23:20 --> Helper loaded: form_helper
INFO - 2021-01-05 05:23:20 --> Helper loaded: my_helper
INFO - 2021-01-05 05:23:20 --> Database Driver Class Initialized
DEBUG - 2021-01-05 05:23:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 05:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 05:23:20 --> Controller Class Initialized
DEBUG - 2021-01-05 05:23:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 05:23:20 --> Final output sent to browser
DEBUG - 2021-01-05 05:23:20 --> Total execution time: 0.3112
INFO - 2021-01-05 05:23:48 --> Config Class Initialized
INFO - 2021-01-05 05:23:48 --> Hooks Class Initialized
DEBUG - 2021-01-05 05:23:48 --> UTF-8 Support Enabled
INFO - 2021-01-05 05:23:48 --> Utf8 Class Initialized
INFO - 2021-01-05 05:23:48 --> URI Class Initialized
INFO - 2021-01-05 05:23:48 --> Router Class Initialized
INFO - 2021-01-05 05:23:48 --> Output Class Initialized
INFO - 2021-01-05 05:23:48 --> Security Class Initialized
DEBUG - 2021-01-05 05:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 05:23:48 --> Input Class Initialized
INFO - 2021-01-05 05:23:48 --> Language Class Initialized
INFO - 2021-01-05 05:23:48 --> Language Class Initialized
INFO - 2021-01-05 05:23:48 --> Config Class Initialized
INFO - 2021-01-05 05:23:48 --> Loader Class Initialized
INFO - 2021-01-05 05:23:48 --> Helper loaded: url_helper
INFO - 2021-01-05 05:23:48 --> Helper loaded: file_helper
INFO - 2021-01-05 05:23:48 --> Helper loaded: form_helper
INFO - 2021-01-05 05:23:48 --> Helper loaded: my_helper
INFO - 2021-01-05 05:23:48 --> Database Driver Class Initialized
DEBUG - 2021-01-05 05:23:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 05:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 05:23:48 --> Controller Class Initialized
DEBUG - 2021-01-05 05:23:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 05:23:48 --> Final output sent to browser
DEBUG - 2021-01-05 05:23:48 --> Total execution time: 0.3400
INFO - 2021-01-05 05:23:59 --> Config Class Initialized
INFO - 2021-01-05 05:23:59 --> Hooks Class Initialized
DEBUG - 2021-01-05 05:23:59 --> UTF-8 Support Enabled
INFO - 2021-01-05 05:23:59 --> Utf8 Class Initialized
INFO - 2021-01-05 05:23:59 --> URI Class Initialized
INFO - 2021-01-05 05:23:59 --> Router Class Initialized
INFO - 2021-01-05 05:23:59 --> Output Class Initialized
INFO - 2021-01-05 05:23:59 --> Security Class Initialized
DEBUG - 2021-01-05 05:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 05:23:59 --> Input Class Initialized
INFO - 2021-01-05 05:23:59 --> Language Class Initialized
INFO - 2021-01-05 05:23:59 --> Language Class Initialized
INFO - 2021-01-05 05:23:59 --> Config Class Initialized
INFO - 2021-01-05 05:23:59 --> Loader Class Initialized
INFO - 2021-01-05 05:23:59 --> Helper loaded: url_helper
INFO - 2021-01-05 05:23:59 --> Helper loaded: file_helper
INFO - 2021-01-05 05:23:59 --> Helper loaded: form_helper
INFO - 2021-01-05 05:23:59 --> Helper loaded: my_helper
INFO - 2021-01-05 05:23:59 --> Database Driver Class Initialized
DEBUG - 2021-01-05 05:23:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 05:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 05:23:59 --> Controller Class Initialized
DEBUG - 2021-01-05 05:23:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 05:23:59 --> Final output sent to browser
DEBUG - 2021-01-05 05:23:59 --> Total execution time: 0.3253
INFO - 2021-01-05 05:24:07 --> Config Class Initialized
INFO - 2021-01-05 05:24:07 --> Hooks Class Initialized
DEBUG - 2021-01-05 05:24:07 --> UTF-8 Support Enabled
INFO - 2021-01-05 05:24:07 --> Utf8 Class Initialized
INFO - 2021-01-05 05:24:07 --> URI Class Initialized
INFO - 2021-01-05 05:24:07 --> Router Class Initialized
INFO - 2021-01-05 05:24:07 --> Output Class Initialized
INFO - 2021-01-05 05:24:07 --> Security Class Initialized
DEBUG - 2021-01-05 05:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 05:24:07 --> Input Class Initialized
INFO - 2021-01-05 05:24:07 --> Language Class Initialized
INFO - 2021-01-05 05:24:07 --> Language Class Initialized
INFO - 2021-01-05 05:24:07 --> Config Class Initialized
INFO - 2021-01-05 05:24:07 --> Loader Class Initialized
INFO - 2021-01-05 05:24:07 --> Helper loaded: url_helper
INFO - 2021-01-05 05:24:07 --> Helper loaded: file_helper
INFO - 2021-01-05 05:24:07 --> Helper loaded: form_helper
INFO - 2021-01-05 05:24:07 --> Helper loaded: my_helper
INFO - 2021-01-05 05:24:07 --> Database Driver Class Initialized
DEBUG - 2021-01-05 05:24:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 05:24:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 05:24:07 --> Controller Class Initialized
DEBUG - 2021-01-05 05:24:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 05:24:07 --> Final output sent to browser
DEBUG - 2021-01-05 05:24:07 --> Total execution time: 0.3327
INFO - 2021-01-05 05:24:50 --> Config Class Initialized
INFO - 2021-01-05 05:24:50 --> Hooks Class Initialized
DEBUG - 2021-01-05 05:24:50 --> UTF-8 Support Enabled
INFO - 2021-01-05 05:24:50 --> Utf8 Class Initialized
INFO - 2021-01-05 05:24:50 --> URI Class Initialized
INFO - 2021-01-05 05:24:50 --> Router Class Initialized
INFO - 2021-01-05 05:24:50 --> Output Class Initialized
INFO - 2021-01-05 05:24:50 --> Security Class Initialized
DEBUG - 2021-01-05 05:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 05:24:50 --> Input Class Initialized
INFO - 2021-01-05 05:24:50 --> Language Class Initialized
INFO - 2021-01-05 05:24:50 --> Language Class Initialized
INFO - 2021-01-05 05:24:50 --> Config Class Initialized
INFO - 2021-01-05 05:24:50 --> Loader Class Initialized
INFO - 2021-01-05 05:24:50 --> Helper loaded: url_helper
INFO - 2021-01-05 05:24:50 --> Helper loaded: file_helper
INFO - 2021-01-05 05:24:50 --> Helper loaded: form_helper
INFO - 2021-01-05 05:24:50 --> Helper loaded: my_helper
INFO - 2021-01-05 05:24:50 --> Database Driver Class Initialized
DEBUG - 2021-01-05 05:24:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 05:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 05:24:50 --> Controller Class Initialized
DEBUG - 2021-01-05 05:24:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 05:24:51 --> Final output sent to browser
DEBUG - 2021-01-05 05:24:51 --> Total execution time: 0.3350
INFO - 2021-01-05 05:26:40 --> Config Class Initialized
INFO - 2021-01-05 05:26:40 --> Hooks Class Initialized
DEBUG - 2021-01-05 05:26:40 --> UTF-8 Support Enabled
INFO - 2021-01-05 05:26:40 --> Utf8 Class Initialized
INFO - 2021-01-05 05:26:40 --> URI Class Initialized
INFO - 2021-01-05 05:26:40 --> Router Class Initialized
INFO - 2021-01-05 05:26:40 --> Output Class Initialized
INFO - 2021-01-05 05:26:40 --> Security Class Initialized
DEBUG - 2021-01-05 05:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 05:26:40 --> Input Class Initialized
INFO - 2021-01-05 05:26:40 --> Language Class Initialized
INFO - 2021-01-05 05:26:40 --> Language Class Initialized
INFO - 2021-01-05 05:26:40 --> Config Class Initialized
INFO - 2021-01-05 05:26:40 --> Loader Class Initialized
INFO - 2021-01-05 05:26:40 --> Helper loaded: url_helper
INFO - 2021-01-05 05:26:40 --> Helper loaded: file_helper
INFO - 2021-01-05 05:26:40 --> Helper loaded: form_helper
INFO - 2021-01-05 05:26:40 --> Helper loaded: my_helper
INFO - 2021-01-05 05:26:40 --> Database Driver Class Initialized
DEBUG - 2021-01-05 05:26:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 05:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 05:26:40 --> Controller Class Initialized
DEBUG - 2021-01-05 05:26:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 05:26:40 --> Final output sent to browser
DEBUG - 2021-01-05 05:26:40 --> Total execution time: 0.2670
INFO - 2021-01-05 05:26:43 --> Config Class Initialized
INFO - 2021-01-05 05:26:43 --> Hooks Class Initialized
DEBUG - 2021-01-05 05:26:43 --> UTF-8 Support Enabled
INFO - 2021-01-05 05:26:43 --> Utf8 Class Initialized
INFO - 2021-01-05 05:26:43 --> URI Class Initialized
INFO - 2021-01-05 05:26:43 --> Router Class Initialized
INFO - 2021-01-05 05:26:43 --> Output Class Initialized
INFO - 2021-01-05 05:26:43 --> Security Class Initialized
DEBUG - 2021-01-05 05:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 05:26:43 --> Input Class Initialized
INFO - 2021-01-05 05:26:43 --> Language Class Initialized
INFO - 2021-01-05 05:26:43 --> Language Class Initialized
INFO - 2021-01-05 05:26:43 --> Config Class Initialized
INFO - 2021-01-05 05:26:43 --> Loader Class Initialized
INFO - 2021-01-05 05:26:43 --> Helper loaded: url_helper
INFO - 2021-01-05 05:26:43 --> Helper loaded: file_helper
INFO - 2021-01-05 05:26:43 --> Helper loaded: form_helper
INFO - 2021-01-05 05:26:43 --> Helper loaded: my_helper
INFO - 2021-01-05 05:26:43 --> Database Driver Class Initialized
DEBUG - 2021-01-05 05:26:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 05:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 05:26:43 --> Controller Class Initialized
DEBUG - 2021-01-05 05:26:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2021-01-05 05:26:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-05 05:26:43 --> Final output sent to browser
DEBUG - 2021-01-05 05:26:43 --> Total execution time: 0.3857
INFO - 2021-01-05 05:26:51 --> Config Class Initialized
INFO - 2021-01-05 05:26:51 --> Hooks Class Initialized
DEBUG - 2021-01-05 05:26:51 --> UTF-8 Support Enabled
INFO - 2021-01-05 05:26:51 --> Utf8 Class Initialized
INFO - 2021-01-05 05:26:51 --> URI Class Initialized
INFO - 2021-01-05 05:26:52 --> Router Class Initialized
INFO - 2021-01-05 05:26:52 --> Output Class Initialized
INFO - 2021-01-05 05:26:52 --> Security Class Initialized
DEBUG - 2021-01-05 05:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 05:26:52 --> Input Class Initialized
INFO - 2021-01-05 05:26:52 --> Language Class Initialized
INFO - 2021-01-05 05:26:52 --> Language Class Initialized
INFO - 2021-01-05 05:26:52 --> Config Class Initialized
INFO - 2021-01-05 05:26:52 --> Loader Class Initialized
INFO - 2021-01-05 05:26:52 --> Helper loaded: url_helper
INFO - 2021-01-05 05:26:52 --> Helper loaded: file_helper
INFO - 2021-01-05 05:26:52 --> Helper loaded: form_helper
INFO - 2021-01-05 05:26:52 --> Helper loaded: my_helper
INFO - 2021-01-05 05:26:52 --> Database Driver Class Initialized
DEBUG - 2021-01-05 05:26:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 05:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 05:26:52 --> Controller Class Initialized
INFO - 2021-01-05 05:26:52 --> Final output sent to browser
DEBUG - 2021-01-05 05:26:52 --> Total execution time: 0.3598
INFO - 2021-01-05 05:26:56 --> Config Class Initialized
INFO - 2021-01-05 05:26:56 --> Hooks Class Initialized
DEBUG - 2021-01-05 05:26:56 --> UTF-8 Support Enabled
INFO - 2021-01-05 05:26:56 --> Utf8 Class Initialized
INFO - 2021-01-05 05:26:56 --> URI Class Initialized
INFO - 2021-01-05 05:26:56 --> Router Class Initialized
INFO - 2021-01-05 05:26:56 --> Output Class Initialized
INFO - 2021-01-05 05:26:56 --> Security Class Initialized
DEBUG - 2021-01-05 05:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 05:26:56 --> Input Class Initialized
INFO - 2021-01-05 05:26:56 --> Language Class Initialized
INFO - 2021-01-05 05:26:56 --> Language Class Initialized
INFO - 2021-01-05 05:26:56 --> Config Class Initialized
INFO - 2021-01-05 05:26:56 --> Loader Class Initialized
INFO - 2021-01-05 05:26:56 --> Helper loaded: url_helper
INFO - 2021-01-05 05:26:56 --> Helper loaded: file_helper
INFO - 2021-01-05 05:26:56 --> Helper loaded: form_helper
INFO - 2021-01-05 05:26:56 --> Helper loaded: my_helper
INFO - 2021-01-05 05:26:56 --> Database Driver Class Initialized
DEBUG - 2021-01-05 05:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 05:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 05:26:56 --> Controller Class Initialized
DEBUG - 2021-01-05 05:26:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 05:26:56 --> Final output sent to browser
DEBUG - 2021-01-05 05:26:56 --> Total execution time: 0.3082
INFO - 2021-01-05 05:30:46 --> Config Class Initialized
INFO - 2021-01-05 05:30:46 --> Hooks Class Initialized
DEBUG - 2021-01-05 05:30:46 --> UTF-8 Support Enabled
INFO - 2021-01-05 05:30:46 --> Utf8 Class Initialized
INFO - 2021-01-05 05:30:46 --> URI Class Initialized
INFO - 2021-01-05 05:30:46 --> Router Class Initialized
INFO - 2021-01-05 05:30:46 --> Output Class Initialized
INFO - 2021-01-05 05:30:46 --> Security Class Initialized
DEBUG - 2021-01-05 05:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 05:30:46 --> Input Class Initialized
INFO - 2021-01-05 05:30:46 --> Language Class Initialized
INFO - 2021-01-05 05:30:46 --> Language Class Initialized
INFO - 2021-01-05 05:30:46 --> Config Class Initialized
INFO - 2021-01-05 05:30:46 --> Loader Class Initialized
INFO - 2021-01-05 05:30:46 --> Helper loaded: url_helper
INFO - 2021-01-05 05:30:46 --> Helper loaded: file_helper
INFO - 2021-01-05 05:30:46 --> Helper loaded: form_helper
INFO - 2021-01-05 05:30:46 --> Helper loaded: my_helper
INFO - 2021-01-05 05:30:46 --> Database Driver Class Initialized
DEBUG - 2021-01-05 05:30:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 05:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 05:30:46 --> Controller Class Initialized
DEBUG - 2021-01-05 05:30:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 05:30:46 --> Final output sent to browser
DEBUG - 2021-01-05 05:30:46 --> Total execution time: 0.3529
INFO - 2021-01-05 05:32:57 --> Config Class Initialized
INFO - 2021-01-05 05:32:57 --> Hooks Class Initialized
DEBUG - 2021-01-05 05:32:57 --> UTF-8 Support Enabled
INFO - 2021-01-05 05:32:57 --> Utf8 Class Initialized
INFO - 2021-01-05 05:32:57 --> URI Class Initialized
INFO - 2021-01-05 05:32:57 --> Router Class Initialized
INFO - 2021-01-05 05:32:57 --> Output Class Initialized
INFO - 2021-01-05 05:32:57 --> Security Class Initialized
DEBUG - 2021-01-05 05:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 05:32:57 --> Input Class Initialized
INFO - 2021-01-05 05:32:57 --> Language Class Initialized
INFO - 2021-01-05 05:32:57 --> Language Class Initialized
INFO - 2021-01-05 05:32:57 --> Config Class Initialized
INFO - 2021-01-05 05:32:57 --> Loader Class Initialized
INFO - 2021-01-05 05:32:57 --> Helper loaded: url_helper
INFO - 2021-01-05 05:32:57 --> Helper loaded: file_helper
INFO - 2021-01-05 05:32:57 --> Helper loaded: form_helper
INFO - 2021-01-05 05:32:57 --> Helper loaded: my_helper
INFO - 2021-01-05 05:32:57 --> Database Driver Class Initialized
DEBUG - 2021-01-05 05:32:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 05:32:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 05:32:57 --> Controller Class Initialized
DEBUG - 2021-01-05 05:32:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 05:32:57 --> Final output sent to browser
DEBUG - 2021-01-05 05:32:57 --> Total execution time: 0.3967
INFO - 2021-01-05 05:33:23 --> Config Class Initialized
INFO - 2021-01-05 05:33:23 --> Hooks Class Initialized
DEBUG - 2021-01-05 05:33:23 --> UTF-8 Support Enabled
INFO - 2021-01-05 05:33:23 --> Utf8 Class Initialized
INFO - 2021-01-05 05:33:23 --> URI Class Initialized
INFO - 2021-01-05 05:33:23 --> Router Class Initialized
INFO - 2021-01-05 05:33:23 --> Output Class Initialized
INFO - 2021-01-05 05:33:23 --> Security Class Initialized
DEBUG - 2021-01-05 05:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 05:33:23 --> Input Class Initialized
INFO - 2021-01-05 05:33:23 --> Language Class Initialized
INFO - 2021-01-05 05:33:23 --> Language Class Initialized
INFO - 2021-01-05 05:33:23 --> Config Class Initialized
INFO - 2021-01-05 05:33:23 --> Loader Class Initialized
INFO - 2021-01-05 05:33:23 --> Helper loaded: url_helper
INFO - 2021-01-05 05:33:23 --> Helper loaded: file_helper
INFO - 2021-01-05 05:33:23 --> Helper loaded: form_helper
INFO - 2021-01-05 05:33:23 --> Helper loaded: my_helper
INFO - 2021-01-05 05:33:23 --> Database Driver Class Initialized
DEBUG - 2021-01-05 05:33:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 05:33:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 05:33:23 --> Controller Class Initialized
DEBUG - 2021-01-05 05:33:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 05:33:23 --> Final output sent to browser
DEBUG - 2021-01-05 05:33:23 --> Total execution time: 0.3550
INFO - 2021-01-05 05:33:31 --> Config Class Initialized
INFO - 2021-01-05 05:33:31 --> Hooks Class Initialized
DEBUG - 2021-01-05 05:33:31 --> UTF-8 Support Enabled
INFO - 2021-01-05 05:33:31 --> Utf8 Class Initialized
INFO - 2021-01-05 05:33:31 --> URI Class Initialized
INFO - 2021-01-05 05:33:31 --> Router Class Initialized
INFO - 2021-01-05 05:33:31 --> Output Class Initialized
INFO - 2021-01-05 05:33:31 --> Security Class Initialized
DEBUG - 2021-01-05 05:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 05:33:31 --> Input Class Initialized
INFO - 2021-01-05 05:33:31 --> Language Class Initialized
INFO - 2021-01-05 05:33:31 --> Language Class Initialized
INFO - 2021-01-05 05:33:31 --> Config Class Initialized
INFO - 2021-01-05 05:33:31 --> Loader Class Initialized
INFO - 2021-01-05 05:33:31 --> Helper loaded: url_helper
INFO - 2021-01-05 05:33:31 --> Helper loaded: file_helper
INFO - 2021-01-05 05:33:31 --> Helper loaded: form_helper
INFO - 2021-01-05 05:33:31 --> Helper loaded: my_helper
INFO - 2021-01-05 05:33:31 --> Database Driver Class Initialized
DEBUG - 2021-01-05 05:33:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 05:33:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 05:33:31 --> Controller Class Initialized
DEBUG - 2021-01-05 05:33:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 05:33:31 --> Final output sent to browser
DEBUG - 2021-01-05 05:33:31 --> Total execution time: 0.2809
INFO - 2021-01-05 05:33:35 --> Config Class Initialized
INFO - 2021-01-05 05:33:35 --> Hooks Class Initialized
DEBUG - 2021-01-05 05:33:35 --> UTF-8 Support Enabled
INFO - 2021-01-05 05:33:35 --> Utf8 Class Initialized
INFO - 2021-01-05 05:33:35 --> URI Class Initialized
INFO - 2021-01-05 05:33:35 --> Router Class Initialized
INFO - 2021-01-05 05:33:35 --> Output Class Initialized
INFO - 2021-01-05 05:33:35 --> Security Class Initialized
DEBUG - 2021-01-05 05:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 05:33:35 --> Input Class Initialized
INFO - 2021-01-05 05:33:35 --> Language Class Initialized
INFO - 2021-01-05 05:33:35 --> Language Class Initialized
INFO - 2021-01-05 05:33:35 --> Config Class Initialized
INFO - 2021-01-05 05:33:35 --> Loader Class Initialized
INFO - 2021-01-05 05:33:35 --> Helper loaded: url_helper
INFO - 2021-01-05 05:33:35 --> Helper loaded: file_helper
INFO - 2021-01-05 05:33:35 --> Helper loaded: form_helper
INFO - 2021-01-05 05:33:35 --> Helper loaded: my_helper
INFO - 2021-01-05 05:33:35 --> Database Driver Class Initialized
DEBUG - 2021-01-05 05:33:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 05:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 05:33:35 --> Controller Class Initialized
DEBUG - 2021-01-05 05:33:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 05:33:35 --> Final output sent to browser
DEBUG - 2021-01-05 05:33:35 --> Total execution time: 0.3565
INFO - 2021-01-05 05:33:45 --> Config Class Initialized
INFO - 2021-01-05 05:33:45 --> Hooks Class Initialized
DEBUG - 2021-01-05 05:33:45 --> UTF-8 Support Enabled
INFO - 2021-01-05 05:33:45 --> Utf8 Class Initialized
INFO - 2021-01-05 05:33:45 --> URI Class Initialized
INFO - 2021-01-05 05:33:45 --> Router Class Initialized
INFO - 2021-01-05 05:33:45 --> Output Class Initialized
INFO - 2021-01-05 05:33:45 --> Security Class Initialized
DEBUG - 2021-01-05 05:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 05:33:45 --> Input Class Initialized
INFO - 2021-01-05 05:33:45 --> Language Class Initialized
INFO - 2021-01-05 05:33:45 --> Language Class Initialized
INFO - 2021-01-05 05:33:45 --> Config Class Initialized
INFO - 2021-01-05 05:33:45 --> Loader Class Initialized
INFO - 2021-01-05 05:33:45 --> Helper loaded: url_helper
INFO - 2021-01-05 05:33:45 --> Helper loaded: file_helper
INFO - 2021-01-05 05:33:45 --> Helper loaded: form_helper
INFO - 2021-01-05 05:33:45 --> Helper loaded: my_helper
INFO - 2021-01-05 05:33:45 --> Database Driver Class Initialized
DEBUG - 2021-01-05 05:33:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 05:33:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 05:33:45 --> Controller Class Initialized
DEBUG - 2021-01-05 05:33:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 05:33:45 --> Final output sent to browser
DEBUG - 2021-01-05 05:33:45 --> Total execution time: 0.3608
INFO - 2021-01-05 05:33:58 --> Config Class Initialized
INFO - 2021-01-05 05:33:58 --> Hooks Class Initialized
DEBUG - 2021-01-05 05:33:58 --> UTF-8 Support Enabled
INFO - 2021-01-05 05:33:58 --> Utf8 Class Initialized
INFO - 2021-01-05 05:33:58 --> URI Class Initialized
INFO - 2021-01-05 05:33:58 --> Router Class Initialized
INFO - 2021-01-05 05:33:58 --> Output Class Initialized
INFO - 2021-01-05 05:33:58 --> Security Class Initialized
DEBUG - 2021-01-05 05:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 05:33:59 --> Input Class Initialized
INFO - 2021-01-05 05:33:59 --> Language Class Initialized
INFO - 2021-01-05 05:33:59 --> Language Class Initialized
INFO - 2021-01-05 05:33:59 --> Config Class Initialized
INFO - 2021-01-05 05:33:59 --> Loader Class Initialized
INFO - 2021-01-05 05:33:59 --> Helper loaded: url_helper
INFO - 2021-01-05 05:33:59 --> Helper loaded: file_helper
INFO - 2021-01-05 05:33:59 --> Helper loaded: form_helper
INFO - 2021-01-05 05:33:59 --> Helper loaded: my_helper
INFO - 2021-01-05 05:33:59 --> Database Driver Class Initialized
DEBUG - 2021-01-05 05:33:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 05:33:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 05:33:59 --> Controller Class Initialized
DEBUG - 2021-01-05 05:33:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 05:33:59 --> Final output sent to browser
DEBUG - 2021-01-05 05:33:59 --> Total execution time: 0.3628
INFO - 2021-01-05 05:34:08 --> Config Class Initialized
INFO - 2021-01-05 05:34:08 --> Hooks Class Initialized
DEBUG - 2021-01-05 05:34:08 --> UTF-8 Support Enabled
INFO - 2021-01-05 05:34:08 --> Utf8 Class Initialized
INFO - 2021-01-05 05:34:08 --> URI Class Initialized
INFO - 2021-01-05 05:34:08 --> Router Class Initialized
INFO - 2021-01-05 05:34:08 --> Output Class Initialized
INFO - 2021-01-05 05:34:08 --> Security Class Initialized
DEBUG - 2021-01-05 05:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 05:34:08 --> Input Class Initialized
INFO - 2021-01-05 05:34:08 --> Language Class Initialized
INFO - 2021-01-05 05:34:08 --> Language Class Initialized
INFO - 2021-01-05 05:34:08 --> Config Class Initialized
INFO - 2021-01-05 05:34:08 --> Loader Class Initialized
INFO - 2021-01-05 05:34:08 --> Helper loaded: url_helper
INFO - 2021-01-05 05:34:08 --> Helper loaded: file_helper
INFO - 2021-01-05 05:34:08 --> Helper loaded: form_helper
INFO - 2021-01-05 05:34:08 --> Helper loaded: my_helper
INFO - 2021-01-05 05:34:08 --> Database Driver Class Initialized
DEBUG - 2021-01-05 05:34:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 05:34:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 05:34:08 --> Controller Class Initialized
DEBUG - 2021-01-05 05:34:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 05:34:08 --> Final output sent to browser
DEBUG - 2021-01-05 05:34:08 --> Total execution time: 0.3481
INFO - 2021-01-05 05:34:30 --> Config Class Initialized
INFO - 2021-01-05 05:34:30 --> Hooks Class Initialized
DEBUG - 2021-01-05 05:34:30 --> UTF-8 Support Enabled
INFO - 2021-01-05 05:34:30 --> Utf8 Class Initialized
INFO - 2021-01-05 05:34:30 --> URI Class Initialized
INFO - 2021-01-05 05:34:30 --> Router Class Initialized
INFO - 2021-01-05 05:34:30 --> Output Class Initialized
INFO - 2021-01-05 05:34:30 --> Security Class Initialized
DEBUG - 2021-01-05 05:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 05:34:30 --> Input Class Initialized
INFO - 2021-01-05 05:34:30 --> Language Class Initialized
INFO - 2021-01-05 05:34:30 --> Language Class Initialized
INFO - 2021-01-05 05:34:30 --> Config Class Initialized
INFO - 2021-01-05 05:34:30 --> Loader Class Initialized
INFO - 2021-01-05 05:34:30 --> Helper loaded: url_helper
INFO - 2021-01-05 05:34:30 --> Helper loaded: file_helper
INFO - 2021-01-05 05:34:30 --> Helper loaded: form_helper
INFO - 2021-01-05 05:34:30 --> Helper loaded: my_helper
INFO - 2021-01-05 05:34:30 --> Database Driver Class Initialized
DEBUG - 2021-01-05 05:34:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 05:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 05:34:30 --> Controller Class Initialized
DEBUG - 2021-01-05 05:34:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 05:34:30 --> Final output sent to browser
DEBUG - 2021-01-05 05:34:30 --> Total execution time: 0.3866
INFO - 2021-01-05 05:45:51 --> Config Class Initialized
INFO - 2021-01-05 05:45:51 --> Hooks Class Initialized
DEBUG - 2021-01-05 05:45:51 --> UTF-8 Support Enabled
INFO - 2021-01-05 05:45:51 --> Utf8 Class Initialized
INFO - 2021-01-05 05:45:51 --> URI Class Initialized
INFO - 2021-01-05 05:45:51 --> Router Class Initialized
INFO - 2021-01-05 05:45:51 --> Output Class Initialized
INFO - 2021-01-05 05:45:51 --> Security Class Initialized
DEBUG - 2021-01-05 05:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 05:45:51 --> Input Class Initialized
INFO - 2021-01-05 05:45:51 --> Language Class Initialized
INFO - 2021-01-05 05:45:51 --> Language Class Initialized
INFO - 2021-01-05 05:45:51 --> Config Class Initialized
INFO - 2021-01-05 05:45:51 --> Loader Class Initialized
INFO - 2021-01-05 05:45:51 --> Helper loaded: url_helper
INFO - 2021-01-05 05:45:51 --> Helper loaded: file_helper
INFO - 2021-01-05 05:45:51 --> Helper loaded: form_helper
INFO - 2021-01-05 05:45:51 --> Helper loaded: my_helper
INFO - 2021-01-05 05:45:51 --> Database Driver Class Initialized
DEBUG - 2021-01-05 05:45:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 05:45:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 05:45:51 --> Controller Class Initialized
DEBUG - 2021-01-05 05:45:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 05:45:51 --> Final output sent to browser
DEBUG - 2021-01-05 05:45:51 --> Total execution time: 0.3524
INFO - 2021-01-05 05:47:19 --> Config Class Initialized
INFO - 2021-01-05 05:47:19 --> Hooks Class Initialized
DEBUG - 2021-01-05 05:47:19 --> UTF-8 Support Enabled
INFO - 2021-01-05 05:47:19 --> Utf8 Class Initialized
INFO - 2021-01-05 05:47:19 --> URI Class Initialized
INFO - 2021-01-05 05:47:19 --> Router Class Initialized
INFO - 2021-01-05 05:47:19 --> Output Class Initialized
INFO - 2021-01-05 05:47:19 --> Security Class Initialized
DEBUG - 2021-01-05 05:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 05:47:19 --> Input Class Initialized
INFO - 2021-01-05 05:47:19 --> Language Class Initialized
INFO - 2021-01-05 05:47:19 --> Language Class Initialized
INFO - 2021-01-05 05:47:19 --> Config Class Initialized
INFO - 2021-01-05 05:47:19 --> Loader Class Initialized
INFO - 2021-01-05 05:47:19 --> Helper loaded: url_helper
INFO - 2021-01-05 05:47:19 --> Helper loaded: file_helper
INFO - 2021-01-05 05:47:19 --> Helper loaded: form_helper
INFO - 2021-01-05 05:47:19 --> Helper loaded: my_helper
INFO - 2021-01-05 05:47:19 --> Database Driver Class Initialized
DEBUG - 2021-01-05 05:47:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 05:47:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 05:47:19 --> Controller Class Initialized
DEBUG - 2021-01-05 05:47:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 05:47:19 --> Final output sent to browser
DEBUG - 2021-01-05 05:47:19 --> Total execution time: 0.3607
INFO - 2021-01-05 05:47:48 --> Config Class Initialized
INFO - 2021-01-05 05:47:48 --> Hooks Class Initialized
DEBUG - 2021-01-05 05:47:48 --> UTF-8 Support Enabled
INFO - 2021-01-05 05:47:48 --> Utf8 Class Initialized
INFO - 2021-01-05 05:47:48 --> URI Class Initialized
INFO - 2021-01-05 05:47:48 --> Router Class Initialized
INFO - 2021-01-05 05:47:48 --> Output Class Initialized
INFO - 2021-01-05 05:47:48 --> Security Class Initialized
DEBUG - 2021-01-05 05:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 05:47:48 --> Input Class Initialized
INFO - 2021-01-05 05:47:48 --> Language Class Initialized
INFO - 2021-01-05 05:47:48 --> Language Class Initialized
INFO - 2021-01-05 05:47:48 --> Config Class Initialized
INFO - 2021-01-05 05:47:48 --> Loader Class Initialized
INFO - 2021-01-05 05:47:48 --> Helper loaded: url_helper
INFO - 2021-01-05 05:47:48 --> Helper loaded: file_helper
INFO - 2021-01-05 05:47:48 --> Helper loaded: form_helper
INFO - 2021-01-05 05:47:48 --> Helper loaded: my_helper
INFO - 2021-01-05 05:47:48 --> Database Driver Class Initialized
DEBUG - 2021-01-05 05:47:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 05:47:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 05:47:48 --> Controller Class Initialized
DEBUG - 2021-01-05 05:47:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 05:47:48 --> Final output sent to browser
DEBUG - 2021-01-05 05:47:48 --> Total execution time: 0.3516
INFO - 2021-01-05 05:48:12 --> Config Class Initialized
INFO - 2021-01-05 05:48:12 --> Hooks Class Initialized
DEBUG - 2021-01-05 05:48:12 --> UTF-8 Support Enabled
INFO - 2021-01-05 05:48:12 --> Utf8 Class Initialized
INFO - 2021-01-05 05:48:12 --> URI Class Initialized
INFO - 2021-01-05 05:48:12 --> Router Class Initialized
INFO - 2021-01-05 05:48:12 --> Output Class Initialized
INFO - 2021-01-05 05:48:12 --> Security Class Initialized
DEBUG - 2021-01-05 05:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 05:48:12 --> Input Class Initialized
INFO - 2021-01-05 05:48:12 --> Language Class Initialized
INFO - 2021-01-05 05:48:12 --> Language Class Initialized
INFO - 2021-01-05 05:48:12 --> Config Class Initialized
INFO - 2021-01-05 05:48:12 --> Loader Class Initialized
INFO - 2021-01-05 05:48:12 --> Helper loaded: url_helper
INFO - 2021-01-05 05:48:12 --> Helper loaded: file_helper
INFO - 2021-01-05 05:48:12 --> Helper loaded: form_helper
INFO - 2021-01-05 05:48:12 --> Helper loaded: my_helper
INFO - 2021-01-05 05:48:12 --> Database Driver Class Initialized
DEBUG - 2021-01-05 05:48:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 05:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 05:48:12 --> Controller Class Initialized
DEBUG - 2021-01-05 05:48:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 05:48:12 --> Final output sent to browser
DEBUG - 2021-01-05 05:48:12 --> Total execution time: 0.3346
INFO - 2021-01-05 05:48:25 --> Config Class Initialized
INFO - 2021-01-05 05:48:25 --> Hooks Class Initialized
DEBUG - 2021-01-05 05:48:25 --> UTF-8 Support Enabled
INFO - 2021-01-05 05:48:25 --> Utf8 Class Initialized
INFO - 2021-01-05 05:48:25 --> URI Class Initialized
INFO - 2021-01-05 05:48:25 --> Router Class Initialized
INFO - 2021-01-05 05:48:25 --> Output Class Initialized
INFO - 2021-01-05 05:48:25 --> Security Class Initialized
DEBUG - 2021-01-05 05:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 05:48:26 --> Input Class Initialized
INFO - 2021-01-05 05:48:26 --> Language Class Initialized
INFO - 2021-01-05 05:48:26 --> Language Class Initialized
INFO - 2021-01-05 05:48:26 --> Config Class Initialized
INFO - 2021-01-05 05:48:26 --> Loader Class Initialized
INFO - 2021-01-05 05:48:26 --> Helper loaded: url_helper
INFO - 2021-01-05 05:48:26 --> Helper loaded: file_helper
INFO - 2021-01-05 05:48:26 --> Helper loaded: form_helper
INFO - 2021-01-05 05:48:26 --> Helper loaded: my_helper
INFO - 2021-01-05 05:48:26 --> Database Driver Class Initialized
DEBUG - 2021-01-05 05:48:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 05:48:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 05:48:26 --> Controller Class Initialized
DEBUG - 2021-01-05 05:48:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 05:48:26 --> Final output sent to browser
DEBUG - 2021-01-05 05:48:26 --> Total execution time: 0.2785
INFO - 2021-01-05 05:48:36 --> Config Class Initialized
INFO - 2021-01-05 05:48:36 --> Hooks Class Initialized
DEBUG - 2021-01-05 05:48:36 --> UTF-8 Support Enabled
INFO - 2021-01-05 05:48:36 --> Utf8 Class Initialized
INFO - 2021-01-05 05:48:36 --> URI Class Initialized
INFO - 2021-01-05 05:48:36 --> Router Class Initialized
INFO - 2021-01-05 05:48:36 --> Output Class Initialized
INFO - 2021-01-05 05:48:36 --> Security Class Initialized
DEBUG - 2021-01-05 05:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 05:48:36 --> Input Class Initialized
INFO - 2021-01-05 05:48:36 --> Language Class Initialized
INFO - 2021-01-05 05:48:36 --> Language Class Initialized
INFO - 2021-01-05 05:48:36 --> Config Class Initialized
INFO - 2021-01-05 05:48:36 --> Loader Class Initialized
INFO - 2021-01-05 05:48:36 --> Helper loaded: url_helper
INFO - 2021-01-05 05:48:36 --> Helper loaded: file_helper
INFO - 2021-01-05 05:48:36 --> Helper loaded: form_helper
INFO - 2021-01-05 05:48:36 --> Helper loaded: my_helper
INFO - 2021-01-05 05:48:36 --> Database Driver Class Initialized
DEBUG - 2021-01-05 05:48:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 05:48:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 05:48:36 --> Controller Class Initialized
DEBUG - 2021-01-05 05:48:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 05:48:36 --> Final output sent to browser
DEBUG - 2021-01-05 05:48:36 --> Total execution time: 0.3813
INFO - 2021-01-05 05:48:45 --> Config Class Initialized
INFO - 2021-01-05 05:48:45 --> Hooks Class Initialized
DEBUG - 2021-01-05 05:48:45 --> UTF-8 Support Enabled
INFO - 2021-01-05 05:48:45 --> Utf8 Class Initialized
INFO - 2021-01-05 05:48:45 --> URI Class Initialized
INFO - 2021-01-05 05:48:45 --> Router Class Initialized
INFO - 2021-01-05 05:48:45 --> Output Class Initialized
INFO - 2021-01-05 05:48:45 --> Security Class Initialized
DEBUG - 2021-01-05 05:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 05:48:45 --> Input Class Initialized
INFO - 2021-01-05 05:48:45 --> Language Class Initialized
INFO - 2021-01-05 05:48:45 --> Language Class Initialized
INFO - 2021-01-05 05:48:45 --> Config Class Initialized
INFO - 2021-01-05 05:48:45 --> Loader Class Initialized
INFO - 2021-01-05 05:48:45 --> Helper loaded: url_helper
INFO - 2021-01-05 05:48:45 --> Helper loaded: file_helper
INFO - 2021-01-05 05:48:45 --> Helper loaded: form_helper
INFO - 2021-01-05 05:48:45 --> Helper loaded: my_helper
INFO - 2021-01-05 05:48:45 --> Database Driver Class Initialized
DEBUG - 2021-01-05 05:48:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 05:48:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 05:48:45 --> Controller Class Initialized
DEBUG - 2021-01-05 05:48:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 05:48:45 --> Final output sent to browser
DEBUG - 2021-01-05 05:48:45 --> Total execution time: 0.3483
INFO - 2021-01-05 05:48:52 --> Config Class Initialized
INFO - 2021-01-05 05:48:52 --> Hooks Class Initialized
DEBUG - 2021-01-05 05:48:52 --> UTF-8 Support Enabled
INFO - 2021-01-05 05:48:52 --> Utf8 Class Initialized
INFO - 2021-01-05 05:48:52 --> URI Class Initialized
INFO - 2021-01-05 05:48:52 --> Router Class Initialized
INFO - 2021-01-05 05:48:52 --> Output Class Initialized
INFO - 2021-01-05 05:48:52 --> Security Class Initialized
DEBUG - 2021-01-05 05:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 05:48:52 --> Input Class Initialized
INFO - 2021-01-05 05:48:52 --> Language Class Initialized
INFO - 2021-01-05 05:48:52 --> Language Class Initialized
INFO - 2021-01-05 05:48:52 --> Config Class Initialized
INFO - 2021-01-05 05:48:52 --> Loader Class Initialized
INFO - 2021-01-05 05:48:52 --> Helper loaded: url_helper
INFO - 2021-01-05 05:48:52 --> Helper loaded: file_helper
INFO - 2021-01-05 05:48:52 --> Helper loaded: form_helper
INFO - 2021-01-05 05:48:52 --> Helper loaded: my_helper
INFO - 2021-01-05 05:48:52 --> Database Driver Class Initialized
DEBUG - 2021-01-05 05:48:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 05:48:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 05:48:52 --> Controller Class Initialized
DEBUG - 2021-01-05 05:48:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 05:48:52 --> Final output sent to browser
DEBUG - 2021-01-05 05:48:52 --> Total execution time: 0.3360
INFO - 2021-01-05 05:49:07 --> Config Class Initialized
INFO - 2021-01-05 05:49:07 --> Hooks Class Initialized
DEBUG - 2021-01-05 05:49:07 --> UTF-8 Support Enabled
INFO - 2021-01-05 05:49:07 --> Utf8 Class Initialized
INFO - 2021-01-05 05:49:07 --> URI Class Initialized
INFO - 2021-01-05 05:49:07 --> Router Class Initialized
INFO - 2021-01-05 05:49:07 --> Output Class Initialized
INFO - 2021-01-05 05:49:07 --> Security Class Initialized
DEBUG - 2021-01-05 05:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 05:49:07 --> Input Class Initialized
INFO - 2021-01-05 05:49:07 --> Language Class Initialized
INFO - 2021-01-05 05:49:07 --> Language Class Initialized
INFO - 2021-01-05 05:49:07 --> Config Class Initialized
INFO - 2021-01-05 05:49:07 --> Loader Class Initialized
INFO - 2021-01-05 05:49:07 --> Helper loaded: url_helper
INFO - 2021-01-05 05:49:07 --> Helper loaded: file_helper
INFO - 2021-01-05 05:49:07 --> Helper loaded: form_helper
INFO - 2021-01-05 05:49:07 --> Helper loaded: my_helper
INFO - 2021-01-05 05:49:07 --> Database Driver Class Initialized
DEBUG - 2021-01-05 05:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 05:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 05:49:07 --> Controller Class Initialized
DEBUG - 2021-01-05 05:49:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 05:49:07 --> Final output sent to browser
DEBUG - 2021-01-05 05:49:07 --> Total execution time: 0.3508
INFO - 2021-01-05 05:49:15 --> Config Class Initialized
INFO - 2021-01-05 05:49:15 --> Hooks Class Initialized
DEBUG - 2021-01-05 05:49:15 --> UTF-8 Support Enabled
INFO - 2021-01-05 05:49:15 --> Utf8 Class Initialized
INFO - 2021-01-05 05:49:15 --> URI Class Initialized
INFO - 2021-01-05 05:49:15 --> Router Class Initialized
INFO - 2021-01-05 05:49:15 --> Output Class Initialized
INFO - 2021-01-05 05:49:15 --> Security Class Initialized
DEBUG - 2021-01-05 05:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 05:49:15 --> Input Class Initialized
INFO - 2021-01-05 05:49:15 --> Language Class Initialized
INFO - 2021-01-05 05:49:15 --> Language Class Initialized
INFO - 2021-01-05 05:49:15 --> Config Class Initialized
INFO - 2021-01-05 05:49:15 --> Loader Class Initialized
INFO - 2021-01-05 05:49:15 --> Helper loaded: url_helper
INFO - 2021-01-05 05:49:15 --> Helper loaded: file_helper
INFO - 2021-01-05 05:49:15 --> Helper loaded: form_helper
INFO - 2021-01-05 05:49:15 --> Helper loaded: my_helper
INFO - 2021-01-05 05:49:15 --> Database Driver Class Initialized
DEBUG - 2021-01-05 05:49:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 05:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 05:49:15 --> Controller Class Initialized
DEBUG - 2021-01-05 05:49:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 05:49:15 --> Final output sent to browser
DEBUG - 2021-01-05 05:49:15 --> Total execution time: 0.3473
INFO - 2021-01-05 05:49:34 --> Config Class Initialized
INFO - 2021-01-05 05:49:34 --> Hooks Class Initialized
DEBUG - 2021-01-05 05:49:34 --> UTF-8 Support Enabled
INFO - 2021-01-05 05:49:34 --> Utf8 Class Initialized
INFO - 2021-01-05 05:49:34 --> URI Class Initialized
INFO - 2021-01-05 05:49:34 --> Router Class Initialized
INFO - 2021-01-05 05:49:34 --> Output Class Initialized
INFO - 2021-01-05 05:49:34 --> Security Class Initialized
DEBUG - 2021-01-05 05:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 05:49:34 --> Input Class Initialized
INFO - 2021-01-05 05:49:34 --> Language Class Initialized
INFO - 2021-01-05 05:49:34 --> Language Class Initialized
INFO - 2021-01-05 05:49:34 --> Config Class Initialized
INFO - 2021-01-05 05:49:34 --> Loader Class Initialized
INFO - 2021-01-05 05:49:34 --> Helper loaded: url_helper
INFO - 2021-01-05 05:49:34 --> Helper loaded: file_helper
INFO - 2021-01-05 05:49:34 --> Helper loaded: form_helper
INFO - 2021-01-05 05:49:34 --> Helper loaded: my_helper
INFO - 2021-01-05 05:49:34 --> Database Driver Class Initialized
DEBUG - 2021-01-05 05:49:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 05:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 05:49:34 --> Controller Class Initialized
DEBUG - 2021-01-05 05:49:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 05:49:34 --> Final output sent to browser
DEBUG - 2021-01-05 05:49:34 --> Total execution time: 0.3680
INFO - 2021-01-05 05:50:14 --> Config Class Initialized
INFO - 2021-01-05 05:50:14 --> Hooks Class Initialized
DEBUG - 2021-01-05 05:50:14 --> UTF-8 Support Enabled
INFO - 2021-01-05 05:50:14 --> Utf8 Class Initialized
INFO - 2021-01-05 05:50:14 --> URI Class Initialized
INFO - 2021-01-05 05:50:14 --> Router Class Initialized
INFO - 2021-01-05 05:50:14 --> Output Class Initialized
INFO - 2021-01-05 05:50:14 --> Security Class Initialized
DEBUG - 2021-01-05 05:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 05:50:14 --> Input Class Initialized
INFO - 2021-01-05 05:50:14 --> Language Class Initialized
INFO - 2021-01-05 05:50:14 --> Language Class Initialized
INFO - 2021-01-05 05:50:14 --> Config Class Initialized
INFO - 2021-01-05 05:50:14 --> Loader Class Initialized
INFO - 2021-01-05 05:50:14 --> Helper loaded: url_helper
INFO - 2021-01-05 05:50:14 --> Helper loaded: file_helper
INFO - 2021-01-05 05:50:14 --> Helper loaded: form_helper
INFO - 2021-01-05 05:50:14 --> Helper loaded: my_helper
INFO - 2021-01-05 05:50:14 --> Database Driver Class Initialized
DEBUG - 2021-01-05 05:50:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 05:50:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 05:50:14 --> Controller Class Initialized
DEBUG - 2021-01-05 05:50:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 05:50:15 --> Final output sent to browser
DEBUG - 2021-01-05 05:50:15 --> Total execution time: 0.3377
INFO - 2021-01-05 05:50:23 --> Config Class Initialized
INFO - 2021-01-05 05:50:23 --> Hooks Class Initialized
DEBUG - 2021-01-05 05:50:23 --> UTF-8 Support Enabled
INFO - 2021-01-05 05:50:23 --> Utf8 Class Initialized
INFO - 2021-01-05 05:50:23 --> URI Class Initialized
INFO - 2021-01-05 05:50:23 --> Router Class Initialized
INFO - 2021-01-05 05:50:23 --> Output Class Initialized
INFO - 2021-01-05 05:50:23 --> Security Class Initialized
DEBUG - 2021-01-05 05:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 05:50:23 --> Input Class Initialized
INFO - 2021-01-05 05:50:23 --> Language Class Initialized
INFO - 2021-01-05 05:50:23 --> Language Class Initialized
INFO - 2021-01-05 05:50:23 --> Config Class Initialized
INFO - 2021-01-05 05:50:23 --> Loader Class Initialized
INFO - 2021-01-05 05:50:23 --> Helper loaded: url_helper
INFO - 2021-01-05 05:50:23 --> Helper loaded: file_helper
INFO - 2021-01-05 05:50:23 --> Helper loaded: form_helper
INFO - 2021-01-05 05:50:23 --> Helper loaded: my_helper
INFO - 2021-01-05 05:50:23 --> Database Driver Class Initialized
DEBUG - 2021-01-05 05:50:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 05:50:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 05:50:23 --> Controller Class Initialized
DEBUG - 2021-01-05 05:50:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 05:50:23 --> Final output sent to browser
DEBUG - 2021-01-05 05:50:23 --> Total execution time: 0.3461
INFO - 2021-01-05 05:50:47 --> Config Class Initialized
INFO - 2021-01-05 05:50:47 --> Hooks Class Initialized
DEBUG - 2021-01-05 05:50:47 --> UTF-8 Support Enabled
INFO - 2021-01-05 05:50:47 --> Utf8 Class Initialized
INFO - 2021-01-05 05:50:47 --> URI Class Initialized
INFO - 2021-01-05 05:50:47 --> Router Class Initialized
INFO - 2021-01-05 05:50:47 --> Output Class Initialized
INFO - 2021-01-05 05:50:47 --> Security Class Initialized
DEBUG - 2021-01-05 05:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 05:50:47 --> Input Class Initialized
INFO - 2021-01-05 05:50:47 --> Language Class Initialized
INFO - 2021-01-05 05:50:47 --> Language Class Initialized
INFO - 2021-01-05 05:50:47 --> Config Class Initialized
INFO - 2021-01-05 05:50:47 --> Loader Class Initialized
INFO - 2021-01-05 05:50:47 --> Helper loaded: url_helper
INFO - 2021-01-05 05:50:47 --> Helper loaded: file_helper
INFO - 2021-01-05 05:50:47 --> Helper loaded: form_helper
INFO - 2021-01-05 05:50:47 --> Helper loaded: my_helper
INFO - 2021-01-05 05:50:47 --> Database Driver Class Initialized
DEBUG - 2021-01-05 05:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 05:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 05:50:48 --> Controller Class Initialized
DEBUG - 2021-01-05 05:50:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 05:50:48 --> Final output sent to browser
DEBUG - 2021-01-05 05:50:48 --> Total execution time: 0.4435
INFO - 2021-01-05 05:51:06 --> Config Class Initialized
INFO - 2021-01-05 05:51:06 --> Hooks Class Initialized
DEBUG - 2021-01-05 05:51:06 --> UTF-8 Support Enabled
INFO - 2021-01-05 05:51:06 --> Utf8 Class Initialized
INFO - 2021-01-05 05:51:06 --> URI Class Initialized
INFO - 2021-01-05 05:51:06 --> Router Class Initialized
INFO - 2021-01-05 05:51:06 --> Output Class Initialized
INFO - 2021-01-05 05:51:06 --> Security Class Initialized
DEBUG - 2021-01-05 05:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 05:51:06 --> Input Class Initialized
INFO - 2021-01-05 05:51:06 --> Language Class Initialized
INFO - 2021-01-05 05:51:06 --> Language Class Initialized
INFO - 2021-01-05 05:51:06 --> Config Class Initialized
INFO - 2021-01-05 05:51:06 --> Loader Class Initialized
INFO - 2021-01-05 05:51:06 --> Helper loaded: url_helper
INFO - 2021-01-05 05:51:06 --> Helper loaded: file_helper
INFO - 2021-01-05 05:51:06 --> Helper loaded: form_helper
INFO - 2021-01-05 05:51:06 --> Helper loaded: my_helper
INFO - 2021-01-05 05:51:06 --> Database Driver Class Initialized
DEBUG - 2021-01-05 05:51:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 05:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 05:51:06 --> Controller Class Initialized
DEBUG - 2021-01-05 05:51:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 05:51:07 --> Final output sent to browser
DEBUG - 2021-01-05 05:51:07 --> Total execution time: 0.3696
INFO - 2021-01-05 05:51:21 --> Config Class Initialized
INFO - 2021-01-05 05:51:21 --> Hooks Class Initialized
DEBUG - 2021-01-05 05:51:21 --> UTF-8 Support Enabled
INFO - 2021-01-05 05:51:21 --> Utf8 Class Initialized
INFO - 2021-01-05 05:51:21 --> URI Class Initialized
INFO - 2021-01-05 05:51:21 --> Router Class Initialized
INFO - 2021-01-05 05:51:21 --> Output Class Initialized
INFO - 2021-01-05 05:51:21 --> Security Class Initialized
DEBUG - 2021-01-05 05:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 05:51:21 --> Input Class Initialized
INFO - 2021-01-05 05:51:21 --> Language Class Initialized
INFO - 2021-01-05 05:51:21 --> Language Class Initialized
INFO - 2021-01-05 05:51:21 --> Config Class Initialized
INFO - 2021-01-05 05:51:21 --> Loader Class Initialized
INFO - 2021-01-05 05:51:21 --> Helper loaded: url_helper
INFO - 2021-01-05 05:51:21 --> Helper loaded: file_helper
INFO - 2021-01-05 05:51:21 --> Helper loaded: form_helper
INFO - 2021-01-05 05:51:21 --> Helper loaded: my_helper
INFO - 2021-01-05 05:51:21 --> Database Driver Class Initialized
DEBUG - 2021-01-05 05:51:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 05:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 05:51:21 --> Controller Class Initialized
DEBUG - 2021-01-05 05:51:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 05:51:21 --> Final output sent to browser
DEBUG - 2021-01-05 05:51:21 --> Total execution time: 0.3680
INFO - 2021-01-05 05:51:41 --> Config Class Initialized
INFO - 2021-01-05 05:51:41 --> Hooks Class Initialized
DEBUG - 2021-01-05 05:51:41 --> UTF-8 Support Enabled
INFO - 2021-01-05 05:51:41 --> Utf8 Class Initialized
INFO - 2021-01-05 05:51:41 --> URI Class Initialized
INFO - 2021-01-05 05:51:41 --> Router Class Initialized
INFO - 2021-01-05 05:51:41 --> Output Class Initialized
INFO - 2021-01-05 05:51:41 --> Security Class Initialized
DEBUG - 2021-01-05 05:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 05:51:41 --> Input Class Initialized
INFO - 2021-01-05 05:51:41 --> Language Class Initialized
INFO - 2021-01-05 05:51:41 --> Language Class Initialized
INFO - 2021-01-05 05:51:41 --> Config Class Initialized
INFO - 2021-01-05 05:51:41 --> Loader Class Initialized
INFO - 2021-01-05 05:51:41 --> Helper loaded: url_helper
INFO - 2021-01-05 05:51:41 --> Helper loaded: file_helper
INFO - 2021-01-05 05:51:41 --> Helper loaded: form_helper
INFO - 2021-01-05 05:51:41 --> Helper loaded: my_helper
INFO - 2021-01-05 05:51:41 --> Database Driver Class Initialized
DEBUG - 2021-01-05 05:51:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 05:51:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 05:51:41 --> Controller Class Initialized
DEBUG - 2021-01-05 05:51:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 05:51:41 --> Final output sent to browser
DEBUG - 2021-01-05 05:51:41 --> Total execution time: 0.3461
INFO - 2021-01-05 05:52:19 --> Config Class Initialized
INFO - 2021-01-05 05:52:19 --> Hooks Class Initialized
DEBUG - 2021-01-05 05:52:19 --> UTF-8 Support Enabled
INFO - 2021-01-05 05:52:19 --> Utf8 Class Initialized
INFO - 2021-01-05 05:52:19 --> URI Class Initialized
INFO - 2021-01-05 05:52:19 --> Router Class Initialized
INFO - 2021-01-05 05:52:19 --> Output Class Initialized
INFO - 2021-01-05 05:52:19 --> Security Class Initialized
DEBUG - 2021-01-05 05:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 05:52:19 --> Input Class Initialized
INFO - 2021-01-05 05:52:19 --> Language Class Initialized
INFO - 2021-01-05 05:52:19 --> Language Class Initialized
INFO - 2021-01-05 05:52:19 --> Config Class Initialized
INFO - 2021-01-05 05:52:19 --> Loader Class Initialized
INFO - 2021-01-05 05:52:19 --> Helper loaded: url_helper
INFO - 2021-01-05 05:52:19 --> Helper loaded: file_helper
INFO - 2021-01-05 05:52:19 --> Helper loaded: form_helper
INFO - 2021-01-05 05:52:19 --> Helper loaded: my_helper
INFO - 2021-01-05 05:52:19 --> Database Driver Class Initialized
DEBUG - 2021-01-05 05:52:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 05:52:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 05:52:19 --> Controller Class Initialized
DEBUG - 2021-01-05 05:52:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 05:52:20 --> Final output sent to browser
DEBUG - 2021-01-05 05:52:20 --> Total execution time: 0.3781
INFO - 2021-01-05 05:52:44 --> Config Class Initialized
INFO - 2021-01-05 05:52:44 --> Hooks Class Initialized
DEBUG - 2021-01-05 05:52:44 --> UTF-8 Support Enabled
INFO - 2021-01-05 05:52:44 --> Utf8 Class Initialized
INFO - 2021-01-05 05:52:44 --> URI Class Initialized
INFO - 2021-01-05 05:52:44 --> Router Class Initialized
INFO - 2021-01-05 05:52:44 --> Output Class Initialized
INFO - 2021-01-05 05:52:44 --> Security Class Initialized
DEBUG - 2021-01-05 05:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 05:52:44 --> Input Class Initialized
INFO - 2021-01-05 05:52:44 --> Language Class Initialized
INFO - 2021-01-05 05:52:44 --> Language Class Initialized
INFO - 2021-01-05 05:52:44 --> Config Class Initialized
INFO - 2021-01-05 05:52:44 --> Loader Class Initialized
INFO - 2021-01-05 05:52:44 --> Helper loaded: url_helper
INFO - 2021-01-05 05:52:44 --> Helper loaded: file_helper
INFO - 2021-01-05 05:52:44 --> Helper loaded: form_helper
INFO - 2021-01-05 05:52:44 --> Helper loaded: my_helper
INFO - 2021-01-05 05:52:44 --> Database Driver Class Initialized
DEBUG - 2021-01-05 05:52:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 05:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 05:52:44 --> Controller Class Initialized
DEBUG - 2021-01-05 05:52:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 05:52:44 --> Final output sent to browser
DEBUG - 2021-01-05 05:52:44 --> Total execution time: 0.3606
INFO - 2021-01-05 05:53:24 --> Config Class Initialized
INFO - 2021-01-05 05:53:24 --> Hooks Class Initialized
DEBUG - 2021-01-05 05:53:24 --> UTF-8 Support Enabled
INFO - 2021-01-05 05:53:24 --> Utf8 Class Initialized
INFO - 2021-01-05 05:53:24 --> URI Class Initialized
INFO - 2021-01-05 05:53:24 --> Router Class Initialized
INFO - 2021-01-05 05:53:24 --> Output Class Initialized
INFO - 2021-01-05 05:53:24 --> Security Class Initialized
DEBUG - 2021-01-05 05:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 05:53:24 --> Input Class Initialized
INFO - 2021-01-05 05:53:24 --> Language Class Initialized
INFO - 2021-01-05 05:53:24 --> Language Class Initialized
INFO - 2021-01-05 05:53:24 --> Config Class Initialized
INFO - 2021-01-05 05:53:24 --> Loader Class Initialized
INFO - 2021-01-05 05:53:24 --> Helper loaded: url_helper
INFO - 2021-01-05 05:53:24 --> Helper loaded: file_helper
INFO - 2021-01-05 05:53:24 --> Helper loaded: form_helper
INFO - 2021-01-05 05:53:24 --> Helper loaded: my_helper
INFO - 2021-01-05 05:53:24 --> Database Driver Class Initialized
DEBUG - 2021-01-05 05:53:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 05:53:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 05:53:24 --> Controller Class Initialized
DEBUG - 2021-01-05 05:53:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 05:53:24 --> Final output sent to browser
DEBUG - 2021-01-05 05:53:24 --> Total execution time: 0.3784
INFO - 2021-01-05 05:55:56 --> Config Class Initialized
INFO - 2021-01-05 05:55:56 --> Hooks Class Initialized
DEBUG - 2021-01-05 05:55:56 --> UTF-8 Support Enabled
INFO - 2021-01-05 05:55:56 --> Utf8 Class Initialized
INFO - 2021-01-05 05:55:56 --> URI Class Initialized
INFO - 2021-01-05 05:55:56 --> Router Class Initialized
INFO - 2021-01-05 05:55:56 --> Output Class Initialized
INFO - 2021-01-05 05:55:56 --> Security Class Initialized
DEBUG - 2021-01-05 05:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 05:55:56 --> Input Class Initialized
INFO - 2021-01-05 05:55:56 --> Language Class Initialized
INFO - 2021-01-05 05:55:56 --> Language Class Initialized
INFO - 2021-01-05 05:55:56 --> Config Class Initialized
INFO - 2021-01-05 05:55:56 --> Loader Class Initialized
INFO - 2021-01-05 05:55:56 --> Helper loaded: url_helper
INFO - 2021-01-05 05:55:56 --> Helper loaded: file_helper
INFO - 2021-01-05 05:55:56 --> Helper loaded: form_helper
INFO - 2021-01-05 05:55:56 --> Helper loaded: my_helper
INFO - 2021-01-05 05:55:56 --> Database Driver Class Initialized
DEBUG - 2021-01-05 05:55:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 05:55:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 05:55:56 --> Controller Class Initialized
DEBUG - 2021-01-05 05:55:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 05:55:56 --> Final output sent to browser
DEBUG - 2021-01-05 05:55:56 --> Total execution time: 0.3582
INFO - 2021-01-05 05:57:20 --> Config Class Initialized
INFO - 2021-01-05 05:57:20 --> Hooks Class Initialized
DEBUG - 2021-01-05 05:57:20 --> UTF-8 Support Enabled
INFO - 2021-01-05 05:57:20 --> Utf8 Class Initialized
INFO - 2021-01-05 05:57:20 --> URI Class Initialized
INFO - 2021-01-05 05:57:20 --> Router Class Initialized
INFO - 2021-01-05 05:57:20 --> Output Class Initialized
INFO - 2021-01-05 05:57:20 --> Security Class Initialized
DEBUG - 2021-01-05 05:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 05:57:20 --> Input Class Initialized
INFO - 2021-01-05 05:57:20 --> Language Class Initialized
INFO - 2021-01-05 05:57:20 --> Language Class Initialized
INFO - 2021-01-05 05:57:20 --> Config Class Initialized
INFO - 2021-01-05 05:57:20 --> Loader Class Initialized
INFO - 2021-01-05 05:57:20 --> Helper loaded: url_helper
INFO - 2021-01-05 05:57:20 --> Helper loaded: file_helper
INFO - 2021-01-05 05:57:20 --> Helper loaded: form_helper
INFO - 2021-01-05 05:57:20 --> Helper loaded: my_helper
INFO - 2021-01-05 05:57:20 --> Database Driver Class Initialized
DEBUG - 2021-01-05 05:57:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 05:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 05:57:20 --> Controller Class Initialized
DEBUG - 2021-01-05 05:57:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 05:57:20 --> Final output sent to browser
DEBUG - 2021-01-05 05:57:20 --> Total execution time: 0.4296
INFO - 2021-01-05 05:57:42 --> Config Class Initialized
INFO - 2021-01-05 05:57:42 --> Hooks Class Initialized
DEBUG - 2021-01-05 05:57:42 --> UTF-8 Support Enabled
INFO - 2021-01-05 05:57:42 --> Utf8 Class Initialized
INFO - 2021-01-05 05:57:42 --> URI Class Initialized
INFO - 2021-01-05 05:57:42 --> Router Class Initialized
INFO - 2021-01-05 05:57:42 --> Output Class Initialized
INFO - 2021-01-05 05:57:42 --> Security Class Initialized
DEBUG - 2021-01-05 05:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 05:57:42 --> Input Class Initialized
INFO - 2021-01-05 05:57:42 --> Language Class Initialized
INFO - 2021-01-05 05:57:42 --> Language Class Initialized
INFO - 2021-01-05 05:57:42 --> Config Class Initialized
INFO - 2021-01-05 05:57:42 --> Loader Class Initialized
INFO - 2021-01-05 05:57:42 --> Helper loaded: url_helper
INFO - 2021-01-05 05:57:42 --> Helper loaded: file_helper
INFO - 2021-01-05 05:57:42 --> Helper loaded: form_helper
INFO - 2021-01-05 05:57:42 --> Helper loaded: my_helper
INFO - 2021-01-05 05:57:42 --> Database Driver Class Initialized
DEBUG - 2021-01-05 05:57:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 05:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 05:57:42 --> Controller Class Initialized
DEBUG - 2021-01-05 05:57:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 05:57:42 --> Final output sent to browser
DEBUG - 2021-01-05 05:57:42 --> Total execution time: 0.4370
INFO - 2021-01-05 05:57:54 --> Config Class Initialized
INFO - 2021-01-05 05:57:54 --> Hooks Class Initialized
DEBUG - 2021-01-05 05:57:54 --> UTF-8 Support Enabled
INFO - 2021-01-05 05:57:54 --> Utf8 Class Initialized
INFO - 2021-01-05 05:57:54 --> URI Class Initialized
INFO - 2021-01-05 05:57:54 --> Router Class Initialized
INFO - 2021-01-05 05:57:54 --> Output Class Initialized
INFO - 2021-01-05 05:57:54 --> Security Class Initialized
DEBUG - 2021-01-05 05:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 05:57:54 --> Input Class Initialized
INFO - 2021-01-05 05:57:54 --> Language Class Initialized
INFO - 2021-01-05 05:57:54 --> Language Class Initialized
INFO - 2021-01-05 05:57:54 --> Config Class Initialized
INFO - 2021-01-05 05:57:54 --> Loader Class Initialized
INFO - 2021-01-05 05:57:54 --> Helper loaded: url_helper
INFO - 2021-01-05 05:57:54 --> Helper loaded: file_helper
INFO - 2021-01-05 05:57:54 --> Helper loaded: form_helper
INFO - 2021-01-05 05:57:54 --> Helper loaded: my_helper
INFO - 2021-01-05 05:57:54 --> Database Driver Class Initialized
DEBUG - 2021-01-05 05:57:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 05:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 05:57:54 --> Controller Class Initialized
DEBUG - 2021-01-05 05:57:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 05:57:54 --> Final output sent to browser
DEBUG - 2021-01-05 05:57:54 --> Total execution time: 0.3858
INFO - 2021-01-05 05:58:09 --> Config Class Initialized
INFO - 2021-01-05 05:58:09 --> Hooks Class Initialized
DEBUG - 2021-01-05 05:58:09 --> UTF-8 Support Enabled
INFO - 2021-01-05 05:58:09 --> Utf8 Class Initialized
INFO - 2021-01-05 05:58:09 --> URI Class Initialized
INFO - 2021-01-05 05:58:09 --> Router Class Initialized
INFO - 2021-01-05 05:58:09 --> Output Class Initialized
INFO - 2021-01-05 05:58:09 --> Security Class Initialized
DEBUG - 2021-01-05 05:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 05:58:09 --> Input Class Initialized
INFO - 2021-01-05 05:58:09 --> Language Class Initialized
INFO - 2021-01-05 05:58:09 --> Language Class Initialized
INFO - 2021-01-05 05:58:09 --> Config Class Initialized
INFO - 2021-01-05 05:58:09 --> Loader Class Initialized
INFO - 2021-01-05 05:58:09 --> Helper loaded: url_helper
INFO - 2021-01-05 05:58:09 --> Helper loaded: file_helper
INFO - 2021-01-05 05:58:09 --> Helper loaded: form_helper
INFO - 2021-01-05 05:58:09 --> Helper loaded: my_helper
INFO - 2021-01-05 05:58:09 --> Database Driver Class Initialized
DEBUG - 2021-01-05 05:58:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 05:58:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 05:58:09 --> Controller Class Initialized
DEBUG - 2021-01-05 05:58:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 05:58:09 --> Final output sent to browser
DEBUG - 2021-01-05 05:58:09 --> Total execution time: 0.3575
INFO - 2021-01-05 05:58:21 --> Config Class Initialized
INFO - 2021-01-05 05:58:21 --> Hooks Class Initialized
DEBUG - 2021-01-05 05:58:21 --> UTF-8 Support Enabled
INFO - 2021-01-05 05:58:21 --> Utf8 Class Initialized
INFO - 2021-01-05 05:58:21 --> URI Class Initialized
INFO - 2021-01-05 05:58:21 --> Router Class Initialized
INFO - 2021-01-05 05:58:21 --> Output Class Initialized
INFO - 2021-01-05 05:58:21 --> Security Class Initialized
DEBUG - 2021-01-05 05:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 05:58:21 --> Input Class Initialized
INFO - 2021-01-05 05:58:21 --> Language Class Initialized
INFO - 2021-01-05 05:58:21 --> Language Class Initialized
INFO - 2021-01-05 05:58:21 --> Config Class Initialized
INFO - 2021-01-05 05:58:21 --> Loader Class Initialized
INFO - 2021-01-05 05:58:21 --> Helper loaded: url_helper
INFO - 2021-01-05 05:58:21 --> Helper loaded: file_helper
INFO - 2021-01-05 05:58:21 --> Helper loaded: form_helper
INFO - 2021-01-05 05:58:21 --> Helper loaded: my_helper
INFO - 2021-01-05 05:58:21 --> Database Driver Class Initialized
DEBUG - 2021-01-05 05:58:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 05:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 05:58:21 --> Controller Class Initialized
DEBUG - 2021-01-05 05:58:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 05:58:21 --> Final output sent to browser
DEBUG - 2021-01-05 05:58:21 --> Total execution time: 0.3760
INFO - 2021-01-05 05:58:35 --> Config Class Initialized
INFO - 2021-01-05 05:58:35 --> Hooks Class Initialized
DEBUG - 2021-01-05 05:58:35 --> UTF-8 Support Enabled
INFO - 2021-01-05 05:58:35 --> Utf8 Class Initialized
INFO - 2021-01-05 05:58:35 --> URI Class Initialized
INFO - 2021-01-05 05:58:35 --> Router Class Initialized
INFO - 2021-01-05 05:58:35 --> Output Class Initialized
INFO - 2021-01-05 05:58:35 --> Security Class Initialized
DEBUG - 2021-01-05 05:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 05:58:35 --> Input Class Initialized
INFO - 2021-01-05 05:58:35 --> Language Class Initialized
INFO - 2021-01-05 05:58:35 --> Language Class Initialized
INFO - 2021-01-05 05:58:35 --> Config Class Initialized
INFO - 2021-01-05 05:58:35 --> Loader Class Initialized
INFO - 2021-01-05 05:58:35 --> Helper loaded: url_helper
INFO - 2021-01-05 05:58:35 --> Helper loaded: file_helper
INFO - 2021-01-05 05:58:35 --> Helper loaded: form_helper
INFO - 2021-01-05 05:58:35 --> Helper loaded: my_helper
INFO - 2021-01-05 05:58:35 --> Database Driver Class Initialized
DEBUG - 2021-01-05 05:58:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 05:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 05:58:35 --> Controller Class Initialized
DEBUG - 2021-01-05 05:58:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 05:58:35 --> Final output sent to browser
DEBUG - 2021-01-05 05:58:35 --> Total execution time: 0.3606
INFO - 2021-01-05 05:58:47 --> Config Class Initialized
INFO - 2021-01-05 05:58:47 --> Hooks Class Initialized
DEBUG - 2021-01-05 05:58:47 --> UTF-8 Support Enabled
INFO - 2021-01-05 05:58:47 --> Utf8 Class Initialized
INFO - 2021-01-05 05:58:47 --> URI Class Initialized
INFO - 2021-01-05 05:58:47 --> Router Class Initialized
INFO - 2021-01-05 05:58:47 --> Output Class Initialized
INFO - 2021-01-05 05:58:47 --> Security Class Initialized
DEBUG - 2021-01-05 05:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 05:58:47 --> Input Class Initialized
INFO - 2021-01-05 05:58:48 --> Language Class Initialized
INFO - 2021-01-05 05:58:48 --> Language Class Initialized
INFO - 2021-01-05 05:58:48 --> Config Class Initialized
INFO - 2021-01-05 05:58:48 --> Loader Class Initialized
INFO - 2021-01-05 05:58:48 --> Helper loaded: url_helper
INFO - 2021-01-05 05:58:48 --> Helper loaded: file_helper
INFO - 2021-01-05 05:58:48 --> Helper loaded: form_helper
INFO - 2021-01-05 05:58:48 --> Helper loaded: my_helper
INFO - 2021-01-05 05:58:48 --> Database Driver Class Initialized
DEBUG - 2021-01-05 05:58:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 05:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 05:58:48 --> Controller Class Initialized
DEBUG - 2021-01-05 05:58:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 05:58:48 --> Final output sent to browser
DEBUG - 2021-01-05 05:58:48 --> Total execution time: 0.3692
INFO - 2021-01-05 05:58:59 --> Config Class Initialized
INFO - 2021-01-05 05:58:59 --> Hooks Class Initialized
DEBUG - 2021-01-05 05:58:59 --> UTF-8 Support Enabled
INFO - 2021-01-05 05:58:59 --> Utf8 Class Initialized
INFO - 2021-01-05 05:58:59 --> URI Class Initialized
INFO - 2021-01-05 05:58:59 --> Router Class Initialized
INFO - 2021-01-05 05:58:59 --> Output Class Initialized
INFO - 2021-01-05 05:58:59 --> Security Class Initialized
DEBUG - 2021-01-05 05:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 05:59:00 --> Input Class Initialized
INFO - 2021-01-05 05:59:00 --> Language Class Initialized
INFO - 2021-01-05 05:59:00 --> Language Class Initialized
INFO - 2021-01-05 05:59:00 --> Config Class Initialized
INFO - 2021-01-05 05:59:00 --> Loader Class Initialized
INFO - 2021-01-05 05:59:00 --> Helper loaded: url_helper
INFO - 2021-01-05 05:59:00 --> Helper loaded: file_helper
INFO - 2021-01-05 05:59:00 --> Helper loaded: form_helper
INFO - 2021-01-05 05:59:00 --> Helper loaded: my_helper
INFO - 2021-01-05 05:59:00 --> Database Driver Class Initialized
DEBUG - 2021-01-05 05:59:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 05:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 05:59:00 --> Controller Class Initialized
DEBUG - 2021-01-05 05:59:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 05:59:00 --> Final output sent to browser
DEBUG - 2021-01-05 05:59:00 --> Total execution time: 0.3581
INFO - 2021-01-05 06:00:34 --> Config Class Initialized
INFO - 2021-01-05 06:00:34 --> Hooks Class Initialized
DEBUG - 2021-01-05 06:00:34 --> UTF-8 Support Enabled
INFO - 2021-01-05 06:00:34 --> Utf8 Class Initialized
INFO - 2021-01-05 06:00:34 --> URI Class Initialized
INFO - 2021-01-05 06:00:34 --> Router Class Initialized
INFO - 2021-01-05 06:00:34 --> Output Class Initialized
INFO - 2021-01-05 06:00:34 --> Security Class Initialized
DEBUG - 2021-01-05 06:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 06:00:34 --> Input Class Initialized
INFO - 2021-01-05 06:00:34 --> Language Class Initialized
INFO - 2021-01-05 06:00:34 --> Language Class Initialized
INFO - 2021-01-05 06:00:34 --> Config Class Initialized
INFO - 2021-01-05 06:00:34 --> Loader Class Initialized
INFO - 2021-01-05 06:00:34 --> Helper loaded: url_helper
INFO - 2021-01-05 06:00:34 --> Helper loaded: file_helper
INFO - 2021-01-05 06:00:34 --> Helper loaded: form_helper
INFO - 2021-01-05 06:00:34 --> Helper loaded: my_helper
INFO - 2021-01-05 06:00:34 --> Database Driver Class Initialized
DEBUG - 2021-01-05 06:00:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 06:00:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 06:00:35 --> Controller Class Initialized
DEBUG - 2021-01-05 06:00:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 06:00:35 --> Final output sent to browser
DEBUG - 2021-01-05 06:00:35 --> Total execution time: 0.3427
INFO - 2021-01-05 07:35:43 --> Config Class Initialized
INFO - 2021-01-05 07:35:43 --> Hooks Class Initialized
DEBUG - 2021-01-05 07:35:43 --> UTF-8 Support Enabled
INFO - 2021-01-05 07:35:43 --> Utf8 Class Initialized
INFO - 2021-01-05 07:35:43 --> URI Class Initialized
INFO - 2021-01-05 07:35:43 --> Router Class Initialized
INFO - 2021-01-05 07:35:43 --> Output Class Initialized
INFO - 2021-01-05 07:35:43 --> Security Class Initialized
DEBUG - 2021-01-05 07:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 07:35:43 --> Input Class Initialized
INFO - 2021-01-05 07:35:43 --> Language Class Initialized
INFO - 2021-01-05 07:35:43 --> Language Class Initialized
INFO - 2021-01-05 07:35:43 --> Config Class Initialized
INFO - 2021-01-05 07:35:43 --> Loader Class Initialized
INFO - 2021-01-05 07:35:43 --> Helper loaded: url_helper
INFO - 2021-01-05 07:35:43 --> Helper loaded: file_helper
INFO - 2021-01-05 07:35:43 --> Helper loaded: form_helper
INFO - 2021-01-05 07:35:44 --> Helper loaded: my_helper
INFO - 2021-01-05 07:35:44 --> Database Driver Class Initialized
DEBUG - 2021-01-05 07:35:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 07:35:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 07:35:44 --> Controller Class Initialized
DEBUG - 2021-01-05 07:35:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 07:35:44 --> Final output sent to browser
DEBUG - 2021-01-05 07:35:44 --> Total execution time: 0.4157
INFO - 2021-01-05 09:12:02 --> Config Class Initialized
INFO - 2021-01-05 09:12:03 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:12:03 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:12:03 --> Utf8 Class Initialized
INFO - 2021-01-05 09:12:03 --> URI Class Initialized
INFO - 2021-01-05 09:12:03 --> Router Class Initialized
INFO - 2021-01-05 09:12:03 --> Output Class Initialized
INFO - 2021-01-05 09:12:03 --> Security Class Initialized
DEBUG - 2021-01-05 09:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:12:03 --> Input Class Initialized
INFO - 2021-01-05 09:12:03 --> Language Class Initialized
INFO - 2021-01-05 09:12:03 --> Language Class Initialized
INFO - 2021-01-05 09:12:03 --> Config Class Initialized
INFO - 2021-01-05 09:12:03 --> Loader Class Initialized
INFO - 2021-01-05 09:12:03 --> Helper loaded: url_helper
INFO - 2021-01-05 09:12:03 --> Helper loaded: file_helper
INFO - 2021-01-05 09:12:03 --> Helper loaded: form_helper
INFO - 2021-01-05 09:12:03 --> Helper loaded: my_helper
INFO - 2021-01-05 09:12:03 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:12:03 --> Controller Class Initialized
INFO - 2021-01-05 09:12:03 --> Helper loaded: cookie_helper
INFO - 2021-01-05 09:12:03 --> Config Class Initialized
INFO - 2021-01-05 09:12:03 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:12:03 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:12:03 --> Utf8 Class Initialized
INFO - 2021-01-05 09:12:03 --> URI Class Initialized
INFO - 2021-01-05 09:12:03 --> Router Class Initialized
INFO - 2021-01-05 09:12:03 --> Output Class Initialized
INFO - 2021-01-05 09:12:03 --> Security Class Initialized
DEBUG - 2021-01-05 09:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:12:03 --> Input Class Initialized
INFO - 2021-01-05 09:12:03 --> Language Class Initialized
INFO - 2021-01-05 09:12:03 --> Language Class Initialized
INFO - 2021-01-05 09:12:03 --> Config Class Initialized
INFO - 2021-01-05 09:12:03 --> Loader Class Initialized
INFO - 2021-01-05 09:12:03 --> Helper loaded: url_helper
INFO - 2021-01-05 09:12:03 --> Helper loaded: file_helper
INFO - 2021-01-05 09:12:03 --> Helper loaded: form_helper
INFO - 2021-01-05 09:12:03 --> Helper loaded: my_helper
INFO - 2021-01-05 09:12:03 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:12:03 --> Controller Class Initialized
DEBUG - 2021-01-05 09:12:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-05 09:12:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-05 09:12:03 --> Final output sent to browser
DEBUG - 2021-01-05 09:12:03 --> Total execution time: 0.3634
INFO - 2021-01-05 09:12:17 --> Config Class Initialized
INFO - 2021-01-05 09:12:17 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:12:17 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:12:17 --> Utf8 Class Initialized
INFO - 2021-01-05 09:12:17 --> URI Class Initialized
INFO - 2021-01-05 09:12:17 --> Router Class Initialized
INFO - 2021-01-05 09:12:17 --> Output Class Initialized
INFO - 2021-01-05 09:12:17 --> Security Class Initialized
DEBUG - 2021-01-05 09:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:12:17 --> Input Class Initialized
INFO - 2021-01-05 09:12:17 --> Language Class Initialized
INFO - 2021-01-05 09:12:17 --> Language Class Initialized
INFO - 2021-01-05 09:12:17 --> Config Class Initialized
INFO - 2021-01-05 09:12:17 --> Loader Class Initialized
INFO - 2021-01-05 09:12:17 --> Helper loaded: url_helper
INFO - 2021-01-05 09:12:17 --> Helper loaded: file_helper
INFO - 2021-01-05 09:12:17 --> Helper loaded: form_helper
INFO - 2021-01-05 09:12:17 --> Helper loaded: my_helper
INFO - 2021-01-05 09:12:17 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:12:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:12:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:12:17 --> Controller Class Initialized
INFO - 2021-01-05 09:12:17 --> Helper loaded: cookie_helper
INFO - 2021-01-05 09:12:17 --> Final output sent to browser
DEBUG - 2021-01-05 09:12:17 --> Total execution time: 0.4377
INFO - 2021-01-05 09:12:18 --> Config Class Initialized
INFO - 2021-01-05 09:12:18 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:12:18 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:12:18 --> Utf8 Class Initialized
INFO - 2021-01-05 09:12:18 --> URI Class Initialized
INFO - 2021-01-05 09:12:18 --> Router Class Initialized
INFO - 2021-01-05 09:12:18 --> Output Class Initialized
INFO - 2021-01-05 09:12:18 --> Security Class Initialized
DEBUG - 2021-01-05 09:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:12:18 --> Input Class Initialized
INFO - 2021-01-05 09:12:18 --> Language Class Initialized
INFO - 2021-01-05 09:12:18 --> Language Class Initialized
INFO - 2021-01-05 09:12:18 --> Config Class Initialized
INFO - 2021-01-05 09:12:18 --> Loader Class Initialized
INFO - 2021-01-05 09:12:18 --> Helper loaded: url_helper
INFO - 2021-01-05 09:12:18 --> Helper loaded: file_helper
INFO - 2021-01-05 09:12:18 --> Helper loaded: form_helper
INFO - 2021-01-05 09:12:18 --> Helper loaded: my_helper
INFO - 2021-01-05 09:12:18 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:12:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:12:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:12:18 --> Controller Class Initialized
DEBUG - 2021-01-05 09:12:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-05 09:12:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-05 09:12:18 --> Final output sent to browser
DEBUG - 2021-01-05 09:12:18 --> Total execution time: 0.5219
INFO - 2021-01-05 09:12:24 --> Config Class Initialized
INFO - 2021-01-05 09:12:24 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:12:24 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:12:24 --> Utf8 Class Initialized
INFO - 2021-01-05 09:12:24 --> URI Class Initialized
INFO - 2021-01-05 09:12:24 --> Router Class Initialized
INFO - 2021-01-05 09:12:24 --> Output Class Initialized
INFO - 2021-01-05 09:12:24 --> Security Class Initialized
DEBUG - 2021-01-05 09:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:12:24 --> Input Class Initialized
INFO - 2021-01-05 09:12:24 --> Language Class Initialized
INFO - 2021-01-05 09:12:24 --> Language Class Initialized
INFO - 2021-01-05 09:12:24 --> Config Class Initialized
INFO - 2021-01-05 09:12:24 --> Loader Class Initialized
INFO - 2021-01-05 09:12:24 --> Helper loaded: url_helper
INFO - 2021-01-05 09:12:24 --> Helper loaded: file_helper
INFO - 2021-01-05 09:12:25 --> Helper loaded: form_helper
INFO - 2021-01-05 09:12:25 --> Helper loaded: my_helper
INFO - 2021-01-05 09:12:25 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:12:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:12:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:12:25 --> Controller Class Initialized
DEBUG - 2021-01-05 09:12:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-01-05 09:12:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-05 09:12:25 --> Final output sent to browser
DEBUG - 2021-01-05 09:12:25 --> Total execution time: 0.3584
INFO - 2021-01-05 09:12:25 --> Config Class Initialized
INFO - 2021-01-05 09:12:25 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:12:25 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:12:25 --> Utf8 Class Initialized
INFO - 2021-01-05 09:12:25 --> URI Class Initialized
INFO - 2021-01-05 09:12:25 --> Router Class Initialized
INFO - 2021-01-05 09:12:25 --> Output Class Initialized
INFO - 2021-01-05 09:12:25 --> Security Class Initialized
DEBUG - 2021-01-05 09:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:12:25 --> Input Class Initialized
INFO - 2021-01-05 09:12:25 --> Language Class Initialized
INFO - 2021-01-05 09:12:25 --> Language Class Initialized
INFO - 2021-01-05 09:12:25 --> Config Class Initialized
INFO - 2021-01-05 09:12:25 --> Loader Class Initialized
INFO - 2021-01-05 09:12:25 --> Helper loaded: url_helper
INFO - 2021-01-05 09:12:25 --> Helper loaded: file_helper
INFO - 2021-01-05 09:12:25 --> Helper loaded: form_helper
INFO - 2021-01-05 09:12:25 --> Helper loaded: my_helper
INFO - 2021-01-05 09:12:25 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:12:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:12:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:12:25 --> Controller Class Initialized
INFO - 2021-01-05 09:12:27 --> Config Class Initialized
INFO - 2021-01-05 09:12:27 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:12:27 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:12:27 --> Utf8 Class Initialized
INFO - 2021-01-05 09:12:27 --> URI Class Initialized
INFO - 2021-01-05 09:12:27 --> Router Class Initialized
INFO - 2021-01-05 09:12:27 --> Output Class Initialized
INFO - 2021-01-05 09:12:27 --> Security Class Initialized
DEBUG - 2021-01-05 09:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:12:27 --> Input Class Initialized
INFO - 2021-01-05 09:12:27 --> Language Class Initialized
INFO - 2021-01-05 09:12:27 --> Language Class Initialized
INFO - 2021-01-05 09:12:27 --> Config Class Initialized
INFO - 2021-01-05 09:12:27 --> Loader Class Initialized
INFO - 2021-01-05 09:12:27 --> Helper loaded: url_helper
INFO - 2021-01-05 09:12:27 --> Helper loaded: file_helper
INFO - 2021-01-05 09:12:27 --> Helper loaded: form_helper
INFO - 2021-01-05 09:12:27 --> Helper loaded: my_helper
INFO - 2021-01-05 09:12:27 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:12:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:12:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:12:27 --> Controller Class Initialized
DEBUG - 2021-01-05 09:12:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-01-05 09:12:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-05 09:12:27 --> Final output sent to browser
DEBUG - 2021-01-05 09:12:27 --> Total execution time: 0.4191
INFO - 2021-01-05 09:12:39 --> Config Class Initialized
INFO - 2021-01-05 09:12:39 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:12:39 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:12:39 --> Utf8 Class Initialized
INFO - 2021-01-05 09:12:40 --> URI Class Initialized
INFO - 2021-01-05 09:12:40 --> Router Class Initialized
INFO - 2021-01-05 09:12:40 --> Output Class Initialized
INFO - 2021-01-05 09:12:40 --> Security Class Initialized
DEBUG - 2021-01-05 09:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:12:40 --> Input Class Initialized
INFO - 2021-01-05 09:12:40 --> Language Class Initialized
INFO - 2021-01-05 09:12:40 --> Language Class Initialized
INFO - 2021-01-05 09:12:40 --> Config Class Initialized
INFO - 2021-01-05 09:12:40 --> Loader Class Initialized
INFO - 2021-01-05 09:12:40 --> Helper loaded: url_helper
INFO - 2021-01-05 09:12:40 --> Helper loaded: file_helper
INFO - 2021-01-05 09:12:40 --> Helper loaded: form_helper
INFO - 2021-01-05 09:12:40 --> Helper loaded: my_helper
INFO - 2021-01-05 09:12:40 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:12:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:12:40 --> Controller Class Initialized
INFO - 2021-01-05 09:12:40 --> Config Class Initialized
INFO - 2021-01-05 09:12:40 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:12:40 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:12:40 --> Utf8 Class Initialized
INFO - 2021-01-05 09:12:40 --> URI Class Initialized
INFO - 2021-01-05 09:12:40 --> Router Class Initialized
INFO - 2021-01-05 09:12:40 --> Output Class Initialized
INFO - 2021-01-05 09:12:40 --> Security Class Initialized
DEBUG - 2021-01-05 09:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:12:40 --> Input Class Initialized
INFO - 2021-01-05 09:12:40 --> Language Class Initialized
INFO - 2021-01-05 09:12:40 --> Language Class Initialized
INFO - 2021-01-05 09:12:40 --> Config Class Initialized
INFO - 2021-01-05 09:12:40 --> Loader Class Initialized
INFO - 2021-01-05 09:12:40 --> Helper loaded: url_helper
INFO - 2021-01-05 09:12:40 --> Helper loaded: file_helper
INFO - 2021-01-05 09:12:40 --> Helper loaded: form_helper
INFO - 2021-01-05 09:12:40 --> Helper loaded: my_helper
INFO - 2021-01-05 09:12:40 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:12:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:12:40 --> Controller Class Initialized
DEBUG - 2021-01-05 09:12:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-01-05 09:12:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-05 09:12:40 --> Final output sent to browser
DEBUG - 2021-01-05 09:12:40 --> Total execution time: 0.3672
INFO - 2021-01-05 09:12:40 --> Config Class Initialized
INFO - 2021-01-05 09:12:40 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:12:40 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:12:40 --> Utf8 Class Initialized
INFO - 2021-01-05 09:12:40 --> URI Class Initialized
INFO - 2021-01-05 09:12:40 --> Router Class Initialized
INFO - 2021-01-05 09:12:40 --> Output Class Initialized
INFO - 2021-01-05 09:12:40 --> Security Class Initialized
DEBUG - 2021-01-05 09:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:12:40 --> Input Class Initialized
INFO - 2021-01-05 09:12:40 --> Language Class Initialized
INFO - 2021-01-05 09:12:40 --> Language Class Initialized
INFO - 2021-01-05 09:12:40 --> Config Class Initialized
INFO - 2021-01-05 09:12:40 --> Loader Class Initialized
INFO - 2021-01-05 09:12:40 --> Helper loaded: url_helper
INFO - 2021-01-05 09:12:40 --> Helper loaded: file_helper
INFO - 2021-01-05 09:12:40 --> Helper loaded: form_helper
INFO - 2021-01-05 09:12:41 --> Helper loaded: my_helper
INFO - 2021-01-05 09:12:41 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:12:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:12:41 --> Controller Class Initialized
INFO - 2021-01-05 09:12:43 --> Config Class Initialized
INFO - 2021-01-05 09:12:43 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:12:43 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:12:43 --> Utf8 Class Initialized
INFO - 2021-01-05 09:12:43 --> URI Class Initialized
INFO - 2021-01-05 09:12:43 --> Router Class Initialized
INFO - 2021-01-05 09:12:43 --> Output Class Initialized
INFO - 2021-01-05 09:12:43 --> Security Class Initialized
DEBUG - 2021-01-05 09:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:12:43 --> Input Class Initialized
INFO - 2021-01-05 09:12:43 --> Language Class Initialized
INFO - 2021-01-05 09:12:43 --> Language Class Initialized
INFO - 2021-01-05 09:12:43 --> Config Class Initialized
INFO - 2021-01-05 09:12:43 --> Loader Class Initialized
INFO - 2021-01-05 09:12:43 --> Helper loaded: url_helper
INFO - 2021-01-05 09:12:43 --> Helper loaded: file_helper
INFO - 2021-01-05 09:12:43 --> Helper loaded: form_helper
INFO - 2021-01-05 09:12:43 --> Helper loaded: my_helper
INFO - 2021-01-05 09:12:43 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:12:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:12:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:12:43 --> Controller Class Initialized
INFO - 2021-01-05 09:12:43 --> Helper loaded: cookie_helper
INFO - 2021-01-05 09:12:44 --> Config Class Initialized
INFO - 2021-01-05 09:12:44 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:12:44 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:12:44 --> Utf8 Class Initialized
INFO - 2021-01-05 09:12:44 --> URI Class Initialized
INFO - 2021-01-05 09:12:44 --> Router Class Initialized
INFO - 2021-01-05 09:12:44 --> Output Class Initialized
INFO - 2021-01-05 09:12:44 --> Security Class Initialized
DEBUG - 2021-01-05 09:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:12:44 --> Input Class Initialized
INFO - 2021-01-05 09:12:44 --> Language Class Initialized
INFO - 2021-01-05 09:12:44 --> Language Class Initialized
INFO - 2021-01-05 09:12:44 --> Config Class Initialized
INFO - 2021-01-05 09:12:44 --> Loader Class Initialized
INFO - 2021-01-05 09:12:44 --> Helper loaded: url_helper
INFO - 2021-01-05 09:12:44 --> Helper loaded: file_helper
INFO - 2021-01-05 09:12:44 --> Helper loaded: form_helper
INFO - 2021-01-05 09:12:44 --> Helper loaded: my_helper
INFO - 2021-01-05 09:12:44 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:12:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:12:44 --> Controller Class Initialized
DEBUG - 2021-01-05 09:12:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-05 09:12:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-05 09:12:44 --> Final output sent to browser
DEBUG - 2021-01-05 09:12:44 --> Total execution time: 0.3382
INFO - 2021-01-05 09:12:50 --> Config Class Initialized
INFO - 2021-01-05 09:12:50 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:12:50 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:12:50 --> Utf8 Class Initialized
INFO - 2021-01-05 09:12:50 --> URI Class Initialized
INFO - 2021-01-05 09:12:50 --> Router Class Initialized
INFO - 2021-01-05 09:12:50 --> Output Class Initialized
INFO - 2021-01-05 09:12:50 --> Security Class Initialized
DEBUG - 2021-01-05 09:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:12:50 --> Input Class Initialized
INFO - 2021-01-05 09:12:50 --> Language Class Initialized
INFO - 2021-01-05 09:12:50 --> Language Class Initialized
INFO - 2021-01-05 09:12:50 --> Config Class Initialized
INFO - 2021-01-05 09:12:50 --> Loader Class Initialized
INFO - 2021-01-05 09:12:50 --> Helper loaded: url_helper
INFO - 2021-01-05 09:12:50 --> Helper loaded: file_helper
INFO - 2021-01-05 09:12:50 --> Helper loaded: form_helper
INFO - 2021-01-05 09:12:50 --> Helper loaded: my_helper
INFO - 2021-01-05 09:12:50 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:12:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:12:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:12:50 --> Controller Class Initialized
INFO - 2021-01-05 09:12:50 --> Final output sent to browser
DEBUG - 2021-01-05 09:12:50 --> Total execution time: 0.4044
INFO - 2021-01-05 09:13:07 --> Config Class Initialized
INFO - 2021-01-05 09:13:07 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:13:07 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:13:07 --> Utf8 Class Initialized
INFO - 2021-01-05 09:13:07 --> URI Class Initialized
INFO - 2021-01-05 09:13:07 --> Router Class Initialized
INFO - 2021-01-05 09:13:07 --> Output Class Initialized
INFO - 2021-01-05 09:13:07 --> Security Class Initialized
DEBUG - 2021-01-05 09:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:13:07 --> Input Class Initialized
INFO - 2021-01-05 09:13:08 --> Language Class Initialized
INFO - 2021-01-05 09:13:08 --> Language Class Initialized
INFO - 2021-01-05 09:13:08 --> Config Class Initialized
INFO - 2021-01-05 09:13:08 --> Loader Class Initialized
INFO - 2021-01-05 09:13:08 --> Helper loaded: url_helper
INFO - 2021-01-05 09:13:08 --> Helper loaded: file_helper
INFO - 2021-01-05 09:13:08 --> Helper loaded: form_helper
INFO - 2021-01-05 09:13:08 --> Helper loaded: my_helper
INFO - 2021-01-05 09:13:08 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:13:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:13:08 --> Controller Class Initialized
INFO - 2021-01-05 09:13:08 --> Helper loaded: cookie_helper
INFO - 2021-01-05 09:13:08 --> Final output sent to browser
DEBUG - 2021-01-05 09:13:08 --> Total execution time: 0.4462
INFO - 2021-01-05 09:13:08 --> Config Class Initialized
INFO - 2021-01-05 09:13:08 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:13:08 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:13:08 --> Utf8 Class Initialized
INFO - 2021-01-05 09:13:08 --> URI Class Initialized
INFO - 2021-01-05 09:13:08 --> Router Class Initialized
INFO - 2021-01-05 09:13:08 --> Output Class Initialized
INFO - 2021-01-05 09:13:08 --> Security Class Initialized
DEBUG - 2021-01-05 09:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:13:08 --> Input Class Initialized
INFO - 2021-01-05 09:13:08 --> Language Class Initialized
INFO - 2021-01-05 09:13:08 --> Language Class Initialized
INFO - 2021-01-05 09:13:08 --> Config Class Initialized
INFO - 2021-01-05 09:13:09 --> Loader Class Initialized
INFO - 2021-01-05 09:13:09 --> Helper loaded: url_helper
INFO - 2021-01-05 09:13:09 --> Helper loaded: file_helper
INFO - 2021-01-05 09:13:09 --> Helper loaded: form_helper
INFO - 2021-01-05 09:13:09 --> Helper loaded: my_helper
INFO - 2021-01-05 09:13:09 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:13:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:13:09 --> Controller Class Initialized
DEBUG - 2021-01-05 09:13:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-05 09:13:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-05 09:13:09 --> Final output sent to browser
DEBUG - 2021-01-05 09:13:09 --> Total execution time: 0.5246
INFO - 2021-01-05 09:13:15 --> Config Class Initialized
INFO - 2021-01-05 09:13:15 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:13:15 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:13:15 --> Utf8 Class Initialized
INFO - 2021-01-05 09:13:15 --> URI Class Initialized
INFO - 2021-01-05 09:13:15 --> Router Class Initialized
INFO - 2021-01-05 09:13:15 --> Output Class Initialized
INFO - 2021-01-05 09:13:15 --> Security Class Initialized
DEBUG - 2021-01-05 09:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:13:15 --> Input Class Initialized
INFO - 2021-01-05 09:13:15 --> Language Class Initialized
INFO - 2021-01-05 09:13:15 --> Language Class Initialized
INFO - 2021-01-05 09:13:15 --> Config Class Initialized
INFO - 2021-01-05 09:13:15 --> Loader Class Initialized
INFO - 2021-01-05 09:13:15 --> Helper loaded: url_helper
INFO - 2021-01-05 09:13:15 --> Helper loaded: file_helper
INFO - 2021-01-05 09:13:15 --> Helper loaded: form_helper
INFO - 2021-01-05 09:13:15 --> Helper loaded: my_helper
INFO - 2021-01-05 09:13:15 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:13:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:13:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:13:15 --> Controller Class Initialized
INFO - 2021-01-05 09:13:15 --> Helper loaded: cookie_helper
INFO - 2021-01-05 09:13:15 --> Config Class Initialized
INFO - 2021-01-05 09:13:15 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:13:15 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:13:15 --> Utf8 Class Initialized
INFO - 2021-01-05 09:13:15 --> URI Class Initialized
INFO - 2021-01-05 09:13:15 --> Router Class Initialized
INFO - 2021-01-05 09:13:15 --> Output Class Initialized
INFO - 2021-01-05 09:13:15 --> Security Class Initialized
DEBUG - 2021-01-05 09:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:13:15 --> Input Class Initialized
INFO - 2021-01-05 09:13:15 --> Language Class Initialized
INFO - 2021-01-05 09:13:15 --> Language Class Initialized
INFO - 2021-01-05 09:13:15 --> Config Class Initialized
INFO - 2021-01-05 09:13:15 --> Loader Class Initialized
INFO - 2021-01-05 09:13:16 --> Helper loaded: url_helper
INFO - 2021-01-05 09:13:16 --> Helper loaded: file_helper
INFO - 2021-01-05 09:13:16 --> Helper loaded: form_helper
INFO - 2021-01-05 09:13:16 --> Helper loaded: my_helper
INFO - 2021-01-05 09:13:16 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:13:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:13:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:13:16 --> Controller Class Initialized
DEBUG - 2021-01-05 09:13:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-05 09:13:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-05 09:13:16 --> Final output sent to browser
DEBUG - 2021-01-05 09:13:16 --> Total execution time: 0.3286
INFO - 2021-01-05 09:13:20 --> Config Class Initialized
INFO - 2021-01-05 09:13:20 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:13:20 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:13:20 --> Utf8 Class Initialized
INFO - 2021-01-05 09:13:21 --> URI Class Initialized
INFO - 2021-01-05 09:13:21 --> Router Class Initialized
INFO - 2021-01-05 09:13:21 --> Output Class Initialized
INFO - 2021-01-05 09:13:21 --> Security Class Initialized
DEBUG - 2021-01-05 09:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:13:21 --> Input Class Initialized
INFO - 2021-01-05 09:13:21 --> Language Class Initialized
INFO - 2021-01-05 09:13:21 --> Language Class Initialized
INFO - 2021-01-05 09:13:21 --> Config Class Initialized
INFO - 2021-01-05 09:13:21 --> Loader Class Initialized
INFO - 2021-01-05 09:13:21 --> Helper loaded: url_helper
INFO - 2021-01-05 09:13:21 --> Helper loaded: file_helper
INFO - 2021-01-05 09:13:21 --> Helper loaded: form_helper
INFO - 2021-01-05 09:13:21 --> Helper loaded: my_helper
INFO - 2021-01-05 09:13:21 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:13:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:13:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:13:21 --> Controller Class Initialized
INFO - 2021-01-05 09:13:21 --> Helper loaded: cookie_helper
INFO - 2021-01-05 09:13:21 --> Final output sent to browser
DEBUG - 2021-01-05 09:13:21 --> Total execution time: 0.4163
INFO - 2021-01-05 09:13:21 --> Config Class Initialized
INFO - 2021-01-05 09:13:21 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:13:21 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:13:21 --> Utf8 Class Initialized
INFO - 2021-01-05 09:13:21 --> URI Class Initialized
INFO - 2021-01-05 09:13:21 --> Router Class Initialized
INFO - 2021-01-05 09:13:21 --> Output Class Initialized
INFO - 2021-01-05 09:13:21 --> Security Class Initialized
DEBUG - 2021-01-05 09:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:13:21 --> Input Class Initialized
INFO - 2021-01-05 09:13:21 --> Language Class Initialized
INFO - 2021-01-05 09:13:22 --> Language Class Initialized
INFO - 2021-01-05 09:13:22 --> Config Class Initialized
INFO - 2021-01-05 09:13:22 --> Loader Class Initialized
INFO - 2021-01-05 09:13:22 --> Helper loaded: url_helper
INFO - 2021-01-05 09:13:22 --> Helper loaded: file_helper
INFO - 2021-01-05 09:13:22 --> Helper loaded: form_helper
INFO - 2021-01-05 09:13:22 --> Helper loaded: my_helper
INFO - 2021-01-05 09:13:22 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:13:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:13:22 --> Controller Class Initialized
DEBUG - 2021-01-05 09:13:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-05 09:13:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-05 09:13:22 --> Final output sent to browser
DEBUG - 2021-01-05 09:13:22 --> Total execution time: 0.5041
INFO - 2021-01-05 09:13:24 --> Config Class Initialized
INFO - 2021-01-05 09:13:24 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:13:24 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:13:24 --> Utf8 Class Initialized
INFO - 2021-01-05 09:13:24 --> URI Class Initialized
INFO - 2021-01-05 09:13:24 --> Router Class Initialized
INFO - 2021-01-05 09:13:24 --> Output Class Initialized
INFO - 2021-01-05 09:13:24 --> Security Class Initialized
DEBUG - 2021-01-05 09:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:13:24 --> Input Class Initialized
INFO - 2021-01-05 09:13:24 --> Language Class Initialized
INFO - 2021-01-05 09:13:24 --> Language Class Initialized
INFO - 2021-01-05 09:13:24 --> Config Class Initialized
INFO - 2021-01-05 09:13:24 --> Loader Class Initialized
INFO - 2021-01-05 09:13:24 --> Helper loaded: url_helper
INFO - 2021-01-05 09:13:24 --> Helper loaded: file_helper
INFO - 2021-01-05 09:13:24 --> Helper loaded: form_helper
INFO - 2021-01-05 09:13:24 --> Helper loaded: my_helper
INFO - 2021-01-05 09:13:24 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:13:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:13:24 --> Controller Class Initialized
DEBUG - 2021-01-05 09:13:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-01-05 09:13:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-05 09:13:24 --> Final output sent to browser
DEBUG - 2021-01-05 09:13:24 --> Total execution time: 0.3457
INFO - 2021-01-05 09:13:24 --> Config Class Initialized
INFO - 2021-01-05 09:13:24 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:13:24 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:13:24 --> Utf8 Class Initialized
INFO - 2021-01-05 09:13:25 --> URI Class Initialized
INFO - 2021-01-05 09:13:25 --> Router Class Initialized
INFO - 2021-01-05 09:13:25 --> Output Class Initialized
INFO - 2021-01-05 09:13:25 --> Security Class Initialized
DEBUG - 2021-01-05 09:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:13:25 --> Input Class Initialized
INFO - 2021-01-05 09:13:25 --> Language Class Initialized
INFO - 2021-01-05 09:13:25 --> Language Class Initialized
INFO - 2021-01-05 09:13:25 --> Config Class Initialized
INFO - 2021-01-05 09:13:25 --> Loader Class Initialized
INFO - 2021-01-05 09:13:25 --> Helper loaded: url_helper
INFO - 2021-01-05 09:13:25 --> Helper loaded: file_helper
INFO - 2021-01-05 09:13:25 --> Helper loaded: form_helper
INFO - 2021-01-05 09:13:25 --> Helper loaded: my_helper
INFO - 2021-01-05 09:13:25 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:13:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:13:25 --> Controller Class Initialized
INFO - 2021-01-05 09:13:27 --> Config Class Initialized
INFO - 2021-01-05 09:13:27 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:13:27 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:13:27 --> Utf8 Class Initialized
INFO - 2021-01-05 09:13:27 --> URI Class Initialized
INFO - 2021-01-05 09:13:27 --> Router Class Initialized
INFO - 2021-01-05 09:13:27 --> Output Class Initialized
INFO - 2021-01-05 09:13:27 --> Security Class Initialized
DEBUG - 2021-01-05 09:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:13:27 --> Input Class Initialized
INFO - 2021-01-05 09:13:27 --> Language Class Initialized
INFO - 2021-01-05 09:13:27 --> Language Class Initialized
INFO - 2021-01-05 09:13:27 --> Config Class Initialized
INFO - 2021-01-05 09:13:27 --> Loader Class Initialized
INFO - 2021-01-05 09:13:27 --> Helper loaded: url_helper
INFO - 2021-01-05 09:13:27 --> Helper loaded: file_helper
INFO - 2021-01-05 09:13:27 --> Helper loaded: form_helper
INFO - 2021-01-05 09:13:27 --> Helper loaded: my_helper
INFO - 2021-01-05 09:13:27 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:13:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:13:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:13:27 --> Controller Class Initialized
DEBUG - 2021-01-05 09:13:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2021-01-05 09:13:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-05 09:13:27 --> Final output sent to browser
DEBUG - 2021-01-05 09:13:27 --> Total execution time: 0.3588
INFO - 2021-01-05 09:13:27 --> Config Class Initialized
INFO - 2021-01-05 09:13:27 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:13:28 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:13:28 --> Utf8 Class Initialized
INFO - 2021-01-05 09:13:28 --> URI Class Initialized
INFO - 2021-01-05 09:13:28 --> Router Class Initialized
INFO - 2021-01-05 09:13:28 --> Output Class Initialized
INFO - 2021-01-05 09:13:28 --> Security Class Initialized
DEBUG - 2021-01-05 09:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:13:28 --> Input Class Initialized
INFO - 2021-01-05 09:13:28 --> Language Class Initialized
INFO - 2021-01-05 09:13:28 --> Language Class Initialized
INFO - 2021-01-05 09:13:28 --> Config Class Initialized
INFO - 2021-01-05 09:13:28 --> Loader Class Initialized
INFO - 2021-01-05 09:13:28 --> Helper loaded: url_helper
INFO - 2021-01-05 09:13:28 --> Helper loaded: file_helper
INFO - 2021-01-05 09:13:28 --> Helper loaded: form_helper
INFO - 2021-01-05 09:13:28 --> Helper loaded: my_helper
INFO - 2021-01-05 09:13:28 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:13:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:13:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:13:28 --> Controller Class Initialized
INFO - 2021-01-05 09:13:37 --> Config Class Initialized
INFO - 2021-01-05 09:13:37 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:13:37 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:13:37 --> Utf8 Class Initialized
INFO - 2021-01-05 09:13:37 --> URI Class Initialized
INFO - 2021-01-05 09:13:37 --> Router Class Initialized
INFO - 2021-01-05 09:13:37 --> Output Class Initialized
INFO - 2021-01-05 09:13:37 --> Security Class Initialized
DEBUG - 2021-01-05 09:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:13:37 --> Input Class Initialized
INFO - 2021-01-05 09:13:37 --> Language Class Initialized
INFO - 2021-01-05 09:13:37 --> Language Class Initialized
INFO - 2021-01-05 09:13:38 --> Config Class Initialized
INFO - 2021-01-05 09:13:38 --> Loader Class Initialized
INFO - 2021-01-05 09:13:38 --> Helper loaded: url_helper
INFO - 2021-01-05 09:13:38 --> Helper loaded: file_helper
INFO - 2021-01-05 09:13:38 --> Helper loaded: form_helper
INFO - 2021-01-05 09:13:38 --> Helper loaded: my_helper
INFO - 2021-01-05 09:13:38 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:13:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:13:38 --> Controller Class Initialized
INFO - 2021-01-05 09:13:38 --> Helper loaded: cookie_helper
INFO - 2021-01-05 09:13:38 --> Config Class Initialized
INFO - 2021-01-05 09:13:38 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:13:38 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:13:38 --> Utf8 Class Initialized
INFO - 2021-01-05 09:13:38 --> URI Class Initialized
INFO - 2021-01-05 09:13:38 --> Router Class Initialized
INFO - 2021-01-05 09:13:38 --> Output Class Initialized
INFO - 2021-01-05 09:13:38 --> Security Class Initialized
DEBUG - 2021-01-05 09:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:13:38 --> Input Class Initialized
INFO - 2021-01-05 09:13:38 --> Language Class Initialized
INFO - 2021-01-05 09:13:38 --> Language Class Initialized
INFO - 2021-01-05 09:13:38 --> Config Class Initialized
INFO - 2021-01-05 09:13:38 --> Loader Class Initialized
INFO - 2021-01-05 09:13:38 --> Helper loaded: url_helper
INFO - 2021-01-05 09:13:38 --> Helper loaded: file_helper
INFO - 2021-01-05 09:13:38 --> Helper loaded: form_helper
INFO - 2021-01-05 09:13:38 --> Helper loaded: my_helper
INFO - 2021-01-05 09:13:38 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:13:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:13:38 --> Controller Class Initialized
DEBUG - 2021-01-05 09:13:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-05 09:13:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-05 09:13:38 --> Final output sent to browser
DEBUG - 2021-01-05 09:13:38 --> Total execution time: 0.3671
INFO - 2021-01-05 09:13:43 --> Config Class Initialized
INFO - 2021-01-05 09:13:43 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:13:43 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:13:43 --> Utf8 Class Initialized
INFO - 2021-01-05 09:13:43 --> URI Class Initialized
INFO - 2021-01-05 09:13:43 --> Router Class Initialized
INFO - 2021-01-05 09:13:43 --> Output Class Initialized
INFO - 2021-01-05 09:13:43 --> Security Class Initialized
DEBUG - 2021-01-05 09:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:13:43 --> Input Class Initialized
INFO - 2021-01-05 09:13:43 --> Language Class Initialized
INFO - 2021-01-05 09:13:44 --> Language Class Initialized
INFO - 2021-01-05 09:13:44 --> Config Class Initialized
INFO - 2021-01-05 09:13:44 --> Loader Class Initialized
INFO - 2021-01-05 09:13:44 --> Helper loaded: url_helper
INFO - 2021-01-05 09:13:44 --> Helper loaded: file_helper
INFO - 2021-01-05 09:13:44 --> Helper loaded: form_helper
INFO - 2021-01-05 09:13:44 --> Helper loaded: my_helper
INFO - 2021-01-05 09:13:44 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:13:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:13:44 --> Controller Class Initialized
INFO - 2021-01-05 09:13:44 --> Helper loaded: cookie_helper
INFO - 2021-01-05 09:13:44 --> Final output sent to browser
DEBUG - 2021-01-05 09:13:44 --> Total execution time: 0.3906
INFO - 2021-01-05 09:13:44 --> Config Class Initialized
INFO - 2021-01-05 09:13:44 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:13:44 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:13:44 --> Utf8 Class Initialized
INFO - 2021-01-05 09:13:44 --> URI Class Initialized
INFO - 2021-01-05 09:13:44 --> Router Class Initialized
INFO - 2021-01-05 09:13:44 --> Output Class Initialized
INFO - 2021-01-05 09:13:44 --> Security Class Initialized
DEBUG - 2021-01-05 09:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:13:44 --> Input Class Initialized
INFO - 2021-01-05 09:13:44 --> Language Class Initialized
INFO - 2021-01-05 09:13:44 --> Language Class Initialized
INFO - 2021-01-05 09:13:44 --> Config Class Initialized
INFO - 2021-01-05 09:13:44 --> Loader Class Initialized
INFO - 2021-01-05 09:13:44 --> Helper loaded: url_helper
INFO - 2021-01-05 09:13:44 --> Helper loaded: file_helper
INFO - 2021-01-05 09:13:44 --> Helper loaded: form_helper
INFO - 2021-01-05 09:13:45 --> Helper loaded: my_helper
INFO - 2021-01-05 09:13:45 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:13:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:13:45 --> Controller Class Initialized
DEBUG - 2021-01-05 09:13:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-05 09:13:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-05 09:13:45 --> Final output sent to browser
DEBUG - 2021-01-05 09:13:45 --> Total execution time: 0.4941
INFO - 2021-01-05 09:13:47 --> Config Class Initialized
INFO - 2021-01-05 09:13:47 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:13:47 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:13:47 --> Utf8 Class Initialized
INFO - 2021-01-05 09:13:47 --> URI Class Initialized
INFO - 2021-01-05 09:13:47 --> Router Class Initialized
INFO - 2021-01-05 09:13:47 --> Output Class Initialized
INFO - 2021-01-05 09:13:47 --> Security Class Initialized
DEBUG - 2021-01-05 09:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:13:47 --> Input Class Initialized
INFO - 2021-01-05 09:13:47 --> Language Class Initialized
INFO - 2021-01-05 09:13:47 --> Language Class Initialized
INFO - 2021-01-05 09:13:47 --> Config Class Initialized
INFO - 2021-01-05 09:13:47 --> Loader Class Initialized
INFO - 2021-01-05 09:13:47 --> Helper loaded: url_helper
INFO - 2021-01-05 09:13:47 --> Helper loaded: file_helper
INFO - 2021-01-05 09:13:47 --> Helper loaded: form_helper
INFO - 2021-01-05 09:13:47 --> Helper loaded: my_helper
INFO - 2021-01-05 09:13:47 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:13:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:13:47 --> Controller Class Initialized
DEBUG - 2021-01-05 09:13:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-05 09:13:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-05 09:13:48 --> Final output sent to browser
DEBUG - 2021-01-05 09:13:48 --> Total execution time: 0.4274
INFO - 2021-01-05 09:13:48 --> Config Class Initialized
INFO - 2021-01-05 09:13:48 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:13:48 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:13:48 --> Utf8 Class Initialized
INFO - 2021-01-05 09:13:48 --> URI Class Initialized
INFO - 2021-01-05 09:13:48 --> Router Class Initialized
INFO - 2021-01-05 09:13:49 --> Output Class Initialized
INFO - 2021-01-05 09:13:49 --> Security Class Initialized
DEBUG - 2021-01-05 09:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:13:49 --> Input Class Initialized
INFO - 2021-01-05 09:13:49 --> Language Class Initialized
INFO - 2021-01-05 09:13:49 --> Language Class Initialized
INFO - 2021-01-05 09:13:49 --> Config Class Initialized
INFO - 2021-01-05 09:13:49 --> Loader Class Initialized
INFO - 2021-01-05 09:13:49 --> Helper loaded: url_helper
INFO - 2021-01-05 09:13:49 --> Helper loaded: file_helper
INFO - 2021-01-05 09:13:49 --> Helper loaded: form_helper
INFO - 2021-01-05 09:13:49 --> Helper loaded: my_helper
INFO - 2021-01-05 09:13:49 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:13:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:13:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:13:49 --> Controller Class Initialized
DEBUG - 2021-01-05 09:13:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-05 09:13:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-05 09:13:49 --> Final output sent to browser
DEBUG - 2021-01-05 09:13:49 --> Total execution time: 0.3325
INFO - 2021-01-05 09:13:49 --> Config Class Initialized
INFO - 2021-01-05 09:13:49 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:13:49 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:13:49 --> Utf8 Class Initialized
INFO - 2021-01-05 09:13:49 --> URI Class Initialized
INFO - 2021-01-05 09:13:49 --> Router Class Initialized
INFO - 2021-01-05 09:13:49 --> Output Class Initialized
INFO - 2021-01-05 09:13:49 --> Security Class Initialized
DEBUG - 2021-01-05 09:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:13:49 --> Input Class Initialized
INFO - 2021-01-05 09:13:49 --> Language Class Initialized
INFO - 2021-01-05 09:13:49 --> Language Class Initialized
INFO - 2021-01-05 09:13:49 --> Config Class Initialized
INFO - 2021-01-05 09:13:49 --> Loader Class Initialized
INFO - 2021-01-05 09:13:49 --> Helper loaded: url_helper
INFO - 2021-01-05 09:13:49 --> Helper loaded: file_helper
INFO - 2021-01-05 09:13:49 --> Helper loaded: form_helper
INFO - 2021-01-05 09:13:49 --> Helper loaded: my_helper
INFO - 2021-01-05 09:13:49 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:13:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:13:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:13:49 --> Controller Class Initialized
INFO - 2021-01-05 09:13:50 --> Config Class Initialized
INFO - 2021-01-05 09:13:50 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:13:50 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:13:50 --> Utf8 Class Initialized
INFO - 2021-01-05 09:13:51 --> URI Class Initialized
INFO - 2021-01-05 09:13:51 --> Router Class Initialized
INFO - 2021-01-05 09:13:51 --> Output Class Initialized
INFO - 2021-01-05 09:13:51 --> Security Class Initialized
DEBUG - 2021-01-05 09:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:13:51 --> Input Class Initialized
INFO - 2021-01-05 09:13:51 --> Language Class Initialized
INFO - 2021-01-05 09:13:51 --> Language Class Initialized
INFO - 2021-01-05 09:13:51 --> Config Class Initialized
INFO - 2021-01-05 09:13:51 --> Loader Class Initialized
INFO - 2021-01-05 09:13:51 --> Helper loaded: url_helper
INFO - 2021-01-05 09:13:51 --> Helper loaded: file_helper
INFO - 2021-01-05 09:13:51 --> Helper loaded: form_helper
INFO - 2021-01-05 09:13:51 --> Helper loaded: my_helper
INFO - 2021-01-05 09:13:51 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:13:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:13:51 --> Controller Class Initialized
INFO - 2021-01-05 09:13:51 --> Final output sent to browser
DEBUG - 2021-01-05 09:13:51 --> Total execution time: 0.3438
INFO - 2021-01-05 09:13:59 --> Config Class Initialized
INFO - 2021-01-05 09:13:59 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:13:59 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:13:59 --> Utf8 Class Initialized
INFO - 2021-01-05 09:13:59 --> URI Class Initialized
INFO - 2021-01-05 09:13:59 --> Router Class Initialized
INFO - 2021-01-05 09:13:59 --> Output Class Initialized
INFO - 2021-01-05 09:13:59 --> Security Class Initialized
DEBUG - 2021-01-05 09:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:13:59 --> Input Class Initialized
INFO - 2021-01-05 09:13:59 --> Language Class Initialized
INFO - 2021-01-05 09:13:59 --> Language Class Initialized
INFO - 2021-01-05 09:13:59 --> Config Class Initialized
INFO - 2021-01-05 09:13:59 --> Loader Class Initialized
INFO - 2021-01-05 09:13:59 --> Helper loaded: url_helper
INFO - 2021-01-05 09:13:59 --> Helper loaded: file_helper
INFO - 2021-01-05 09:13:59 --> Helper loaded: form_helper
INFO - 2021-01-05 09:13:59 --> Helper loaded: my_helper
INFO - 2021-01-05 09:13:59 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:13:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:13:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:13:59 --> Controller Class Initialized
INFO - 2021-01-05 09:13:59 --> Final output sent to browser
DEBUG - 2021-01-05 09:13:59 --> Total execution time: 0.3663
INFO - 2021-01-05 09:13:59 --> Config Class Initialized
INFO - 2021-01-05 09:13:59 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:13:59 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:13:59 --> Utf8 Class Initialized
INFO - 2021-01-05 09:13:59 --> URI Class Initialized
INFO - 2021-01-05 09:13:59 --> Router Class Initialized
INFO - 2021-01-05 09:13:59 --> Output Class Initialized
INFO - 2021-01-05 09:13:59 --> Security Class Initialized
DEBUG - 2021-01-05 09:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:13:59 --> Input Class Initialized
INFO - 2021-01-05 09:13:59 --> Language Class Initialized
INFO - 2021-01-05 09:13:59 --> Language Class Initialized
INFO - 2021-01-05 09:13:59 --> Config Class Initialized
INFO - 2021-01-05 09:13:59 --> Loader Class Initialized
INFO - 2021-01-05 09:13:59 --> Helper loaded: url_helper
INFO - 2021-01-05 09:13:59 --> Helper loaded: file_helper
INFO - 2021-01-05 09:13:59 --> Helper loaded: form_helper
INFO - 2021-01-05 09:13:59 --> Helper loaded: my_helper
INFO - 2021-01-05 09:13:59 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:13:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:13:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:13:59 --> Controller Class Initialized
INFO - 2021-01-05 09:14:02 --> Config Class Initialized
INFO - 2021-01-05 09:14:02 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:14:02 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:14:02 --> Utf8 Class Initialized
INFO - 2021-01-05 09:14:02 --> URI Class Initialized
INFO - 2021-01-05 09:14:02 --> Router Class Initialized
INFO - 2021-01-05 09:14:02 --> Output Class Initialized
INFO - 2021-01-05 09:14:02 --> Security Class Initialized
DEBUG - 2021-01-05 09:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:14:02 --> Input Class Initialized
INFO - 2021-01-05 09:14:02 --> Language Class Initialized
INFO - 2021-01-05 09:14:02 --> Language Class Initialized
INFO - 2021-01-05 09:14:02 --> Config Class Initialized
INFO - 2021-01-05 09:14:02 --> Loader Class Initialized
INFO - 2021-01-05 09:14:02 --> Helper loaded: url_helper
INFO - 2021-01-05 09:14:02 --> Helper loaded: file_helper
INFO - 2021-01-05 09:14:02 --> Helper loaded: form_helper
INFO - 2021-01-05 09:14:02 --> Helper loaded: my_helper
INFO - 2021-01-05 09:14:02 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:14:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:14:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:14:02 --> Controller Class Initialized
INFO - 2021-01-05 09:14:02 --> Final output sent to browser
DEBUG - 2021-01-05 09:14:02 --> Total execution time: 0.2820
INFO - 2021-01-05 09:14:07 --> Config Class Initialized
INFO - 2021-01-05 09:14:07 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:14:07 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:14:07 --> Utf8 Class Initialized
INFO - 2021-01-05 09:14:07 --> URI Class Initialized
INFO - 2021-01-05 09:14:07 --> Router Class Initialized
INFO - 2021-01-05 09:14:07 --> Output Class Initialized
INFO - 2021-01-05 09:14:07 --> Security Class Initialized
DEBUG - 2021-01-05 09:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:14:07 --> Input Class Initialized
INFO - 2021-01-05 09:14:07 --> Language Class Initialized
INFO - 2021-01-05 09:14:07 --> Language Class Initialized
INFO - 2021-01-05 09:14:07 --> Config Class Initialized
INFO - 2021-01-05 09:14:07 --> Loader Class Initialized
INFO - 2021-01-05 09:14:07 --> Helper loaded: url_helper
INFO - 2021-01-05 09:14:07 --> Helper loaded: file_helper
INFO - 2021-01-05 09:14:07 --> Helper loaded: form_helper
INFO - 2021-01-05 09:14:07 --> Helper loaded: my_helper
INFO - 2021-01-05 09:14:07 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:14:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:14:07 --> Controller Class Initialized
INFO - 2021-01-05 09:14:07 --> Final output sent to browser
DEBUG - 2021-01-05 09:14:08 --> Total execution time: 0.2790
INFO - 2021-01-05 09:14:09 --> Config Class Initialized
INFO - 2021-01-05 09:14:09 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:14:09 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:14:09 --> Utf8 Class Initialized
INFO - 2021-01-05 09:14:09 --> URI Class Initialized
INFO - 2021-01-05 09:14:09 --> Router Class Initialized
INFO - 2021-01-05 09:14:09 --> Output Class Initialized
INFO - 2021-01-05 09:14:09 --> Security Class Initialized
DEBUG - 2021-01-05 09:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:14:09 --> Input Class Initialized
INFO - 2021-01-05 09:14:09 --> Language Class Initialized
INFO - 2021-01-05 09:14:09 --> Language Class Initialized
INFO - 2021-01-05 09:14:09 --> Config Class Initialized
INFO - 2021-01-05 09:14:09 --> Loader Class Initialized
INFO - 2021-01-05 09:14:09 --> Helper loaded: url_helper
INFO - 2021-01-05 09:14:09 --> Helper loaded: file_helper
INFO - 2021-01-05 09:14:09 --> Helper loaded: form_helper
INFO - 2021-01-05 09:14:09 --> Helper loaded: my_helper
INFO - 2021-01-05 09:14:09 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:14:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:14:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:14:09 --> Controller Class Initialized
INFO - 2021-01-05 09:14:09 --> Final output sent to browser
DEBUG - 2021-01-05 09:14:09 --> Total execution time: 0.2854
INFO - 2021-01-05 09:14:18 --> Config Class Initialized
INFO - 2021-01-05 09:14:18 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:14:18 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:14:18 --> Utf8 Class Initialized
INFO - 2021-01-05 09:14:18 --> URI Class Initialized
INFO - 2021-01-05 09:14:18 --> Router Class Initialized
INFO - 2021-01-05 09:14:18 --> Output Class Initialized
INFO - 2021-01-05 09:14:18 --> Security Class Initialized
DEBUG - 2021-01-05 09:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:14:18 --> Input Class Initialized
INFO - 2021-01-05 09:14:18 --> Language Class Initialized
INFO - 2021-01-05 09:14:18 --> Language Class Initialized
INFO - 2021-01-05 09:14:18 --> Config Class Initialized
INFO - 2021-01-05 09:14:18 --> Loader Class Initialized
INFO - 2021-01-05 09:14:18 --> Helper loaded: url_helper
INFO - 2021-01-05 09:14:18 --> Helper loaded: file_helper
INFO - 2021-01-05 09:14:18 --> Helper loaded: form_helper
INFO - 2021-01-05 09:14:18 --> Helper loaded: my_helper
INFO - 2021-01-05 09:14:18 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:14:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:14:18 --> Controller Class Initialized
INFO - 2021-01-05 09:14:18 --> Final output sent to browser
DEBUG - 2021-01-05 09:14:18 --> Total execution time: 0.4180
INFO - 2021-01-05 09:14:23 --> Config Class Initialized
INFO - 2021-01-05 09:14:23 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:14:23 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:14:23 --> Utf8 Class Initialized
INFO - 2021-01-05 09:14:23 --> URI Class Initialized
INFO - 2021-01-05 09:14:23 --> Router Class Initialized
INFO - 2021-01-05 09:14:23 --> Output Class Initialized
INFO - 2021-01-05 09:14:23 --> Security Class Initialized
DEBUG - 2021-01-05 09:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:14:23 --> Input Class Initialized
INFO - 2021-01-05 09:14:23 --> Language Class Initialized
INFO - 2021-01-05 09:14:23 --> Language Class Initialized
INFO - 2021-01-05 09:14:23 --> Config Class Initialized
INFO - 2021-01-05 09:14:23 --> Loader Class Initialized
INFO - 2021-01-05 09:14:23 --> Helper loaded: url_helper
INFO - 2021-01-05 09:14:23 --> Helper loaded: file_helper
INFO - 2021-01-05 09:14:23 --> Helper loaded: form_helper
INFO - 2021-01-05 09:14:23 --> Helper loaded: my_helper
INFO - 2021-01-05 09:14:23 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:14:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:14:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:14:23 --> Controller Class Initialized
DEBUG - 2021-01-05 09:14:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-05 09:14:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-05 09:14:23 --> Final output sent to browser
DEBUG - 2021-01-05 09:14:23 --> Total execution time: 0.3444
INFO - 2021-01-05 09:14:24 --> Config Class Initialized
INFO - 2021-01-05 09:14:24 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:14:24 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:14:24 --> Utf8 Class Initialized
INFO - 2021-01-05 09:14:24 --> URI Class Initialized
INFO - 2021-01-05 09:14:24 --> Router Class Initialized
INFO - 2021-01-05 09:14:24 --> Output Class Initialized
INFO - 2021-01-05 09:14:24 --> Security Class Initialized
DEBUG - 2021-01-05 09:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:14:24 --> Input Class Initialized
INFO - 2021-01-05 09:14:24 --> Language Class Initialized
INFO - 2021-01-05 09:14:24 --> Language Class Initialized
INFO - 2021-01-05 09:14:24 --> Config Class Initialized
INFO - 2021-01-05 09:14:24 --> Loader Class Initialized
INFO - 2021-01-05 09:14:24 --> Helper loaded: url_helper
INFO - 2021-01-05 09:14:24 --> Helper loaded: file_helper
INFO - 2021-01-05 09:14:24 --> Helper loaded: form_helper
INFO - 2021-01-05 09:14:24 --> Helper loaded: my_helper
INFO - 2021-01-05 09:14:24 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:14:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:14:24 --> Controller Class Initialized
INFO - 2021-01-05 09:14:26 --> Config Class Initialized
INFO - 2021-01-05 09:14:26 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:14:26 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:14:26 --> Utf8 Class Initialized
INFO - 2021-01-05 09:14:26 --> URI Class Initialized
INFO - 2021-01-05 09:14:26 --> Router Class Initialized
INFO - 2021-01-05 09:14:26 --> Output Class Initialized
INFO - 2021-01-05 09:14:26 --> Security Class Initialized
DEBUG - 2021-01-05 09:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:14:26 --> Input Class Initialized
INFO - 2021-01-05 09:14:26 --> Language Class Initialized
INFO - 2021-01-05 09:14:26 --> Language Class Initialized
INFO - 2021-01-05 09:14:26 --> Config Class Initialized
INFO - 2021-01-05 09:14:26 --> Loader Class Initialized
INFO - 2021-01-05 09:14:26 --> Helper loaded: url_helper
INFO - 2021-01-05 09:14:26 --> Helper loaded: file_helper
INFO - 2021-01-05 09:14:26 --> Helper loaded: form_helper
INFO - 2021-01-05 09:14:26 --> Helper loaded: my_helper
INFO - 2021-01-05 09:14:26 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:14:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:14:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:14:26 --> Controller Class Initialized
INFO - 2021-01-05 09:14:26 --> Final output sent to browser
DEBUG - 2021-01-05 09:14:26 --> Total execution time: 0.2909
INFO - 2021-01-05 09:14:27 --> Config Class Initialized
INFO - 2021-01-05 09:14:27 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:14:27 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:14:27 --> Utf8 Class Initialized
INFO - 2021-01-05 09:14:27 --> URI Class Initialized
INFO - 2021-01-05 09:14:27 --> Router Class Initialized
INFO - 2021-01-05 09:14:27 --> Output Class Initialized
INFO - 2021-01-05 09:14:27 --> Security Class Initialized
DEBUG - 2021-01-05 09:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:14:27 --> Input Class Initialized
INFO - 2021-01-05 09:14:27 --> Language Class Initialized
INFO - 2021-01-05 09:14:27 --> Language Class Initialized
INFO - 2021-01-05 09:14:27 --> Config Class Initialized
INFO - 2021-01-05 09:14:27 --> Loader Class Initialized
INFO - 2021-01-05 09:14:27 --> Helper loaded: url_helper
INFO - 2021-01-05 09:14:27 --> Helper loaded: file_helper
INFO - 2021-01-05 09:14:27 --> Helper loaded: form_helper
INFO - 2021-01-05 09:14:27 --> Helper loaded: my_helper
INFO - 2021-01-05 09:14:27 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:14:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:14:28 --> Controller Class Initialized
INFO - 2021-01-05 09:14:28 --> Final output sent to browser
DEBUG - 2021-01-05 09:14:28 --> Total execution time: 0.3032
INFO - 2021-01-05 09:14:30 --> Config Class Initialized
INFO - 2021-01-05 09:14:30 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:14:30 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:14:30 --> Utf8 Class Initialized
INFO - 2021-01-05 09:14:30 --> URI Class Initialized
INFO - 2021-01-05 09:14:30 --> Router Class Initialized
INFO - 2021-01-05 09:14:30 --> Output Class Initialized
INFO - 2021-01-05 09:14:30 --> Security Class Initialized
DEBUG - 2021-01-05 09:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:14:30 --> Input Class Initialized
INFO - 2021-01-05 09:14:30 --> Language Class Initialized
INFO - 2021-01-05 09:14:30 --> Language Class Initialized
INFO - 2021-01-05 09:14:30 --> Config Class Initialized
INFO - 2021-01-05 09:14:30 --> Loader Class Initialized
INFO - 2021-01-05 09:14:30 --> Helper loaded: url_helper
INFO - 2021-01-05 09:14:30 --> Helper loaded: file_helper
INFO - 2021-01-05 09:14:30 --> Helper loaded: form_helper
INFO - 2021-01-05 09:14:30 --> Helper loaded: my_helper
INFO - 2021-01-05 09:14:30 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:14:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:14:30 --> Controller Class Initialized
INFO - 2021-01-05 09:14:30 --> Final output sent to browser
DEBUG - 2021-01-05 09:14:30 --> Total execution time: 0.2834
INFO - 2021-01-05 09:14:41 --> Config Class Initialized
INFO - 2021-01-05 09:14:41 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:14:41 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:14:41 --> Utf8 Class Initialized
INFO - 2021-01-05 09:14:41 --> URI Class Initialized
INFO - 2021-01-05 09:14:41 --> Router Class Initialized
INFO - 2021-01-05 09:14:41 --> Output Class Initialized
INFO - 2021-01-05 09:14:41 --> Security Class Initialized
DEBUG - 2021-01-05 09:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:14:41 --> Input Class Initialized
INFO - 2021-01-05 09:14:41 --> Language Class Initialized
INFO - 2021-01-05 09:14:41 --> Language Class Initialized
INFO - 2021-01-05 09:14:41 --> Config Class Initialized
INFO - 2021-01-05 09:14:41 --> Loader Class Initialized
INFO - 2021-01-05 09:14:41 --> Helper loaded: url_helper
INFO - 2021-01-05 09:14:41 --> Helper loaded: file_helper
INFO - 2021-01-05 09:14:41 --> Helper loaded: form_helper
INFO - 2021-01-05 09:14:41 --> Helper loaded: my_helper
INFO - 2021-01-05 09:14:41 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:14:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:14:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:14:41 --> Controller Class Initialized
DEBUG - 2021-01-05 09:14:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-05 09:14:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-05 09:14:42 --> Final output sent to browser
DEBUG - 2021-01-05 09:14:42 --> Total execution time: 0.3610
INFO - 2021-01-05 09:14:43 --> Config Class Initialized
INFO - 2021-01-05 09:14:43 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:14:43 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:14:43 --> Utf8 Class Initialized
INFO - 2021-01-05 09:14:43 --> URI Class Initialized
INFO - 2021-01-05 09:14:43 --> Router Class Initialized
INFO - 2021-01-05 09:14:43 --> Output Class Initialized
INFO - 2021-01-05 09:14:43 --> Security Class Initialized
DEBUG - 2021-01-05 09:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:14:43 --> Input Class Initialized
INFO - 2021-01-05 09:14:43 --> Language Class Initialized
INFO - 2021-01-05 09:14:43 --> Language Class Initialized
INFO - 2021-01-05 09:14:43 --> Config Class Initialized
INFO - 2021-01-05 09:14:43 --> Loader Class Initialized
INFO - 2021-01-05 09:14:43 --> Helper loaded: url_helper
INFO - 2021-01-05 09:14:43 --> Helper loaded: file_helper
INFO - 2021-01-05 09:14:43 --> Helper loaded: form_helper
INFO - 2021-01-05 09:14:43 --> Helper loaded: my_helper
INFO - 2021-01-05 09:14:43 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:14:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:14:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:14:43 --> Controller Class Initialized
DEBUG - 2021-01-05 09:14:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-05 09:14:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-05 09:14:43 --> Final output sent to browser
DEBUG - 2021-01-05 09:14:43 --> Total execution time: 0.4246
INFO - 2021-01-05 09:14:45 --> Config Class Initialized
INFO - 2021-01-05 09:14:45 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:14:45 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:14:45 --> Utf8 Class Initialized
INFO - 2021-01-05 09:14:45 --> URI Class Initialized
INFO - 2021-01-05 09:14:45 --> Router Class Initialized
INFO - 2021-01-05 09:14:45 --> Output Class Initialized
INFO - 2021-01-05 09:14:45 --> Security Class Initialized
DEBUG - 2021-01-05 09:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:14:45 --> Input Class Initialized
INFO - 2021-01-05 09:14:45 --> Language Class Initialized
INFO - 2021-01-05 09:14:45 --> Language Class Initialized
INFO - 2021-01-05 09:14:45 --> Config Class Initialized
INFO - 2021-01-05 09:14:45 --> Loader Class Initialized
INFO - 2021-01-05 09:14:45 --> Helper loaded: url_helper
INFO - 2021-01-05 09:14:45 --> Helper loaded: file_helper
INFO - 2021-01-05 09:14:45 --> Helper loaded: form_helper
INFO - 2021-01-05 09:14:45 --> Helper loaded: my_helper
INFO - 2021-01-05 09:14:45 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:14:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:14:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:14:45 --> Controller Class Initialized
INFO - 2021-01-05 09:14:45 --> Final output sent to browser
DEBUG - 2021-01-05 09:14:45 --> Total execution time: 0.3082
INFO - 2021-01-05 09:14:50 --> Config Class Initialized
INFO - 2021-01-05 09:14:50 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:14:50 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:14:50 --> Utf8 Class Initialized
INFO - 2021-01-05 09:14:50 --> URI Class Initialized
INFO - 2021-01-05 09:14:50 --> Router Class Initialized
INFO - 2021-01-05 09:14:50 --> Output Class Initialized
INFO - 2021-01-05 09:14:50 --> Security Class Initialized
DEBUG - 2021-01-05 09:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:14:50 --> Input Class Initialized
INFO - 2021-01-05 09:14:50 --> Language Class Initialized
INFO - 2021-01-05 09:14:50 --> Language Class Initialized
INFO - 2021-01-05 09:14:50 --> Config Class Initialized
INFO - 2021-01-05 09:14:50 --> Loader Class Initialized
INFO - 2021-01-05 09:14:50 --> Helper loaded: url_helper
INFO - 2021-01-05 09:14:50 --> Helper loaded: file_helper
INFO - 2021-01-05 09:14:50 --> Helper loaded: form_helper
INFO - 2021-01-05 09:14:50 --> Helper loaded: my_helper
INFO - 2021-01-05 09:14:50 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:14:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:14:50 --> Controller Class Initialized
INFO - 2021-01-05 09:14:50 --> Final output sent to browser
DEBUG - 2021-01-05 09:14:50 --> Total execution time: 0.3961
INFO - 2021-01-05 09:14:50 --> Config Class Initialized
INFO - 2021-01-05 09:14:50 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:14:50 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:14:51 --> Utf8 Class Initialized
INFO - 2021-01-05 09:14:51 --> URI Class Initialized
INFO - 2021-01-05 09:14:51 --> Router Class Initialized
INFO - 2021-01-05 09:14:51 --> Output Class Initialized
INFO - 2021-01-05 09:14:51 --> Security Class Initialized
DEBUG - 2021-01-05 09:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:14:51 --> Input Class Initialized
INFO - 2021-01-05 09:14:51 --> Language Class Initialized
INFO - 2021-01-05 09:14:51 --> Language Class Initialized
INFO - 2021-01-05 09:14:51 --> Config Class Initialized
INFO - 2021-01-05 09:14:51 --> Loader Class Initialized
INFO - 2021-01-05 09:14:51 --> Helper loaded: url_helper
INFO - 2021-01-05 09:14:51 --> Helper loaded: file_helper
INFO - 2021-01-05 09:14:51 --> Helper loaded: form_helper
INFO - 2021-01-05 09:14:51 --> Helper loaded: my_helper
INFO - 2021-01-05 09:14:51 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:14:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:14:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:14:51 --> Controller Class Initialized
DEBUG - 2021-01-05 09:14:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-05 09:14:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-05 09:14:51 --> Final output sent to browser
DEBUG - 2021-01-05 09:14:51 --> Total execution time: 0.4741
INFO - 2021-01-05 09:14:53 --> Config Class Initialized
INFO - 2021-01-05 09:14:53 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:14:53 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:14:53 --> Utf8 Class Initialized
INFO - 2021-01-05 09:14:53 --> URI Class Initialized
INFO - 2021-01-05 09:14:53 --> Router Class Initialized
INFO - 2021-01-05 09:14:53 --> Output Class Initialized
INFO - 2021-01-05 09:14:53 --> Security Class Initialized
DEBUG - 2021-01-05 09:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:14:53 --> Input Class Initialized
INFO - 2021-01-05 09:14:53 --> Language Class Initialized
INFO - 2021-01-05 09:14:53 --> Language Class Initialized
INFO - 2021-01-05 09:14:53 --> Config Class Initialized
INFO - 2021-01-05 09:14:53 --> Loader Class Initialized
INFO - 2021-01-05 09:14:53 --> Helper loaded: url_helper
INFO - 2021-01-05 09:14:53 --> Helper loaded: file_helper
INFO - 2021-01-05 09:14:53 --> Helper loaded: form_helper
INFO - 2021-01-05 09:14:53 --> Helper loaded: my_helper
INFO - 2021-01-05 09:14:53 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:14:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:14:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:14:53 --> Controller Class Initialized
INFO - 2021-01-05 09:14:53 --> Final output sent to browser
DEBUG - 2021-01-05 09:14:53 --> Total execution time: 0.3216
INFO - 2021-01-05 09:14:57 --> Config Class Initialized
INFO - 2021-01-05 09:14:57 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:14:57 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:14:57 --> Utf8 Class Initialized
INFO - 2021-01-05 09:14:57 --> URI Class Initialized
INFO - 2021-01-05 09:14:57 --> Router Class Initialized
INFO - 2021-01-05 09:14:57 --> Output Class Initialized
INFO - 2021-01-05 09:14:57 --> Security Class Initialized
DEBUG - 2021-01-05 09:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:14:57 --> Input Class Initialized
INFO - 2021-01-05 09:14:57 --> Language Class Initialized
INFO - 2021-01-05 09:14:58 --> Language Class Initialized
INFO - 2021-01-05 09:14:58 --> Config Class Initialized
INFO - 2021-01-05 09:14:58 --> Loader Class Initialized
INFO - 2021-01-05 09:14:58 --> Helper loaded: url_helper
INFO - 2021-01-05 09:14:58 --> Helper loaded: file_helper
INFO - 2021-01-05 09:14:58 --> Helper loaded: form_helper
INFO - 2021-01-05 09:14:58 --> Helper loaded: my_helper
INFO - 2021-01-05 09:14:58 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:14:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:14:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:14:58 --> Controller Class Initialized
INFO - 2021-01-05 09:14:58 --> Final output sent to browser
DEBUG - 2021-01-05 09:14:58 --> Total execution time: 0.3600
INFO - 2021-01-05 09:15:02 --> Config Class Initialized
INFO - 2021-01-05 09:15:02 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:15:02 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:15:02 --> Utf8 Class Initialized
INFO - 2021-01-05 09:15:02 --> URI Class Initialized
INFO - 2021-01-05 09:15:02 --> Router Class Initialized
INFO - 2021-01-05 09:15:02 --> Output Class Initialized
INFO - 2021-01-05 09:15:02 --> Security Class Initialized
DEBUG - 2021-01-05 09:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:15:02 --> Input Class Initialized
INFO - 2021-01-05 09:15:02 --> Language Class Initialized
INFO - 2021-01-05 09:15:02 --> Language Class Initialized
INFO - 2021-01-05 09:15:02 --> Config Class Initialized
INFO - 2021-01-05 09:15:02 --> Loader Class Initialized
INFO - 2021-01-05 09:15:02 --> Helper loaded: url_helper
INFO - 2021-01-05 09:15:02 --> Helper loaded: file_helper
INFO - 2021-01-05 09:15:02 --> Helper loaded: form_helper
INFO - 2021-01-05 09:15:02 --> Helper loaded: my_helper
INFO - 2021-01-05 09:15:02 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:15:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:15:02 --> Controller Class Initialized
DEBUG - 2021-01-05 09:15:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-05 09:15:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-05 09:15:02 --> Final output sent to browser
DEBUG - 2021-01-05 09:15:02 --> Total execution time: 0.3449
INFO - 2021-01-05 09:15:03 --> Config Class Initialized
INFO - 2021-01-05 09:15:03 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:15:03 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:15:03 --> Utf8 Class Initialized
INFO - 2021-01-05 09:15:03 --> URI Class Initialized
INFO - 2021-01-05 09:15:03 --> Router Class Initialized
INFO - 2021-01-05 09:15:03 --> Output Class Initialized
INFO - 2021-01-05 09:15:03 --> Security Class Initialized
DEBUG - 2021-01-05 09:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:15:03 --> Input Class Initialized
INFO - 2021-01-05 09:15:03 --> Language Class Initialized
INFO - 2021-01-05 09:15:03 --> Language Class Initialized
INFO - 2021-01-05 09:15:03 --> Config Class Initialized
INFO - 2021-01-05 09:15:03 --> Loader Class Initialized
INFO - 2021-01-05 09:15:03 --> Helper loaded: url_helper
INFO - 2021-01-05 09:15:03 --> Helper loaded: file_helper
INFO - 2021-01-05 09:15:03 --> Helper loaded: form_helper
INFO - 2021-01-05 09:15:03 --> Helper loaded: my_helper
INFO - 2021-01-05 09:15:04 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:15:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:15:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:15:04 --> Controller Class Initialized
INFO - 2021-01-05 09:15:04 --> Final output sent to browser
DEBUG - 2021-01-05 09:15:04 --> Total execution time: 0.2875
INFO - 2021-01-05 09:15:10 --> Config Class Initialized
INFO - 2021-01-05 09:15:10 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:15:10 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:15:10 --> Utf8 Class Initialized
INFO - 2021-01-05 09:15:10 --> URI Class Initialized
INFO - 2021-01-05 09:15:10 --> Router Class Initialized
INFO - 2021-01-05 09:15:10 --> Output Class Initialized
INFO - 2021-01-05 09:15:10 --> Security Class Initialized
DEBUG - 2021-01-05 09:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:15:11 --> Input Class Initialized
INFO - 2021-01-05 09:15:11 --> Language Class Initialized
INFO - 2021-01-05 09:15:11 --> Language Class Initialized
INFO - 2021-01-05 09:15:11 --> Config Class Initialized
INFO - 2021-01-05 09:15:11 --> Loader Class Initialized
INFO - 2021-01-05 09:15:11 --> Helper loaded: url_helper
INFO - 2021-01-05 09:15:11 --> Helper loaded: file_helper
INFO - 2021-01-05 09:15:11 --> Helper loaded: form_helper
INFO - 2021-01-05 09:15:11 --> Helper loaded: my_helper
INFO - 2021-01-05 09:15:11 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:15:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:15:11 --> Controller Class Initialized
DEBUG - 2021-01-05 09:15:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 09:15:11 --> Final output sent to browser
DEBUG - 2021-01-05 09:15:11 --> Total execution time: 0.3354
INFO - 2021-01-05 09:15:19 --> Config Class Initialized
INFO - 2021-01-05 09:15:19 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:15:19 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:15:19 --> Utf8 Class Initialized
INFO - 2021-01-05 09:15:19 --> URI Class Initialized
INFO - 2021-01-05 09:15:19 --> Router Class Initialized
INFO - 2021-01-05 09:15:19 --> Output Class Initialized
INFO - 2021-01-05 09:15:19 --> Security Class Initialized
DEBUG - 2021-01-05 09:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:15:19 --> Input Class Initialized
INFO - 2021-01-05 09:15:19 --> Language Class Initialized
INFO - 2021-01-05 09:15:19 --> Language Class Initialized
INFO - 2021-01-05 09:15:19 --> Config Class Initialized
INFO - 2021-01-05 09:15:19 --> Loader Class Initialized
INFO - 2021-01-05 09:15:19 --> Helper loaded: url_helper
INFO - 2021-01-05 09:15:19 --> Helper loaded: file_helper
INFO - 2021-01-05 09:15:19 --> Helper loaded: form_helper
INFO - 2021-01-05 09:15:19 --> Helper loaded: my_helper
INFO - 2021-01-05 09:15:19 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:15:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:15:19 --> Controller Class Initialized
DEBUG - 2021-01-05 09:15:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-05 09:15:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-05 09:15:19 --> Final output sent to browser
DEBUG - 2021-01-05 09:15:19 --> Total execution time: 0.4082
INFO - 2021-01-05 09:15:21 --> Config Class Initialized
INFO - 2021-01-05 09:15:21 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:15:21 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:15:21 --> Utf8 Class Initialized
INFO - 2021-01-05 09:15:21 --> URI Class Initialized
INFO - 2021-01-05 09:15:21 --> Router Class Initialized
INFO - 2021-01-05 09:15:21 --> Output Class Initialized
INFO - 2021-01-05 09:15:21 --> Security Class Initialized
DEBUG - 2021-01-05 09:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:15:21 --> Input Class Initialized
INFO - 2021-01-05 09:15:21 --> Language Class Initialized
INFO - 2021-01-05 09:15:21 --> Language Class Initialized
INFO - 2021-01-05 09:15:21 --> Config Class Initialized
INFO - 2021-01-05 09:15:21 --> Loader Class Initialized
INFO - 2021-01-05 09:15:21 --> Helper loaded: url_helper
INFO - 2021-01-05 09:15:21 --> Helper loaded: file_helper
INFO - 2021-01-05 09:15:21 --> Helper loaded: form_helper
INFO - 2021-01-05 09:15:21 --> Helper loaded: my_helper
INFO - 2021-01-05 09:15:21 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:15:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:15:21 --> Controller Class Initialized
DEBUG - 2021-01-05 09:15:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-05 09:15:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-05 09:15:21 --> Final output sent to browser
DEBUG - 2021-01-05 09:15:21 --> Total execution time: 0.3771
INFO - 2021-01-05 09:15:21 --> Config Class Initialized
INFO - 2021-01-05 09:15:21 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:15:21 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:15:21 --> Utf8 Class Initialized
INFO - 2021-01-05 09:15:21 --> URI Class Initialized
INFO - 2021-01-05 09:15:21 --> Router Class Initialized
INFO - 2021-01-05 09:15:21 --> Output Class Initialized
INFO - 2021-01-05 09:15:21 --> Security Class Initialized
DEBUG - 2021-01-05 09:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:15:21 --> Input Class Initialized
INFO - 2021-01-05 09:15:21 --> Language Class Initialized
INFO - 2021-01-05 09:15:21 --> Language Class Initialized
INFO - 2021-01-05 09:15:21 --> Config Class Initialized
INFO - 2021-01-05 09:15:21 --> Loader Class Initialized
INFO - 2021-01-05 09:15:21 --> Helper loaded: url_helper
INFO - 2021-01-05 09:15:21 --> Helper loaded: file_helper
INFO - 2021-01-05 09:15:21 --> Helper loaded: form_helper
INFO - 2021-01-05 09:15:21 --> Helper loaded: my_helper
INFO - 2021-01-05 09:15:21 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:15:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:15:22 --> Controller Class Initialized
INFO - 2021-01-05 09:15:22 --> Config Class Initialized
INFO - 2021-01-05 09:15:22 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:15:22 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:15:22 --> Utf8 Class Initialized
INFO - 2021-01-05 09:15:22 --> URI Class Initialized
INFO - 2021-01-05 09:15:22 --> Router Class Initialized
INFO - 2021-01-05 09:15:22 --> Output Class Initialized
INFO - 2021-01-05 09:15:22 --> Security Class Initialized
DEBUG - 2021-01-05 09:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:15:22 --> Input Class Initialized
INFO - 2021-01-05 09:15:22 --> Language Class Initialized
INFO - 2021-01-05 09:15:22 --> Language Class Initialized
INFO - 2021-01-05 09:15:22 --> Config Class Initialized
INFO - 2021-01-05 09:15:22 --> Loader Class Initialized
INFO - 2021-01-05 09:15:22 --> Helper loaded: url_helper
INFO - 2021-01-05 09:15:22 --> Helper loaded: file_helper
INFO - 2021-01-05 09:15:22 --> Helper loaded: form_helper
INFO - 2021-01-05 09:15:22 --> Helper loaded: my_helper
INFO - 2021-01-05 09:15:22 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:15:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:15:23 --> Controller Class Initialized
INFO - 2021-01-05 09:15:23 --> Final output sent to browser
DEBUG - 2021-01-05 09:15:23 --> Total execution time: 0.2844
INFO - 2021-01-05 09:15:28 --> Config Class Initialized
INFO - 2021-01-05 09:15:29 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:15:29 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:15:29 --> Utf8 Class Initialized
INFO - 2021-01-05 09:15:29 --> URI Class Initialized
INFO - 2021-01-05 09:15:29 --> Router Class Initialized
INFO - 2021-01-05 09:15:29 --> Output Class Initialized
INFO - 2021-01-05 09:15:29 --> Security Class Initialized
DEBUG - 2021-01-05 09:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:15:29 --> Input Class Initialized
INFO - 2021-01-05 09:15:29 --> Language Class Initialized
INFO - 2021-01-05 09:15:29 --> Language Class Initialized
INFO - 2021-01-05 09:15:29 --> Config Class Initialized
INFO - 2021-01-05 09:15:29 --> Loader Class Initialized
INFO - 2021-01-05 09:15:29 --> Helper loaded: url_helper
INFO - 2021-01-05 09:15:29 --> Helper loaded: file_helper
INFO - 2021-01-05 09:15:29 --> Helper loaded: form_helper
INFO - 2021-01-05 09:15:29 --> Helper loaded: my_helper
INFO - 2021-01-05 09:15:29 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:15:29 --> Controller Class Initialized
INFO - 2021-01-05 09:15:29 --> Final output sent to browser
DEBUG - 2021-01-05 09:15:29 --> Total execution time: 0.3295
INFO - 2021-01-05 09:15:31 --> Config Class Initialized
INFO - 2021-01-05 09:15:31 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:15:31 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:15:31 --> Utf8 Class Initialized
INFO - 2021-01-05 09:15:31 --> URI Class Initialized
INFO - 2021-01-05 09:15:31 --> Router Class Initialized
INFO - 2021-01-05 09:15:31 --> Output Class Initialized
INFO - 2021-01-05 09:15:31 --> Security Class Initialized
DEBUG - 2021-01-05 09:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:15:31 --> Input Class Initialized
INFO - 2021-01-05 09:15:31 --> Language Class Initialized
INFO - 2021-01-05 09:15:31 --> Language Class Initialized
INFO - 2021-01-05 09:15:31 --> Config Class Initialized
INFO - 2021-01-05 09:15:31 --> Loader Class Initialized
INFO - 2021-01-05 09:15:31 --> Helper loaded: url_helper
INFO - 2021-01-05 09:15:31 --> Helper loaded: file_helper
INFO - 2021-01-05 09:15:31 --> Helper loaded: form_helper
INFO - 2021-01-05 09:15:31 --> Helper loaded: my_helper
INFO - 2021-01-05 09:15:31 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:15:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:15:31 --> Controller Class Initialized
INFO - 2021-01-05 09:15:31 --> Final output sent to browser
DEBUG - 2021-01-05 09:15:31 --> Total execution time: 0.2957
INFO - 2021-01-05 09:15:35 --> Config Class Initialized
INFO - 2021-01-05 09:15:35 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:15:35 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:15:35 --> Utf8 Class Initialized
INFO - 2021-01-05 09:15:35 --> URI Class Initialized
INFO - 2021-01-05 09:15:36 --> Router Class Initialized
INFO - 2021-01-05 09:15:36 --> Output Class Initialized
INFO - 2021-01-05 09:15:36 --> Security Class Initialized
DEBUG - 2021-01-05 09:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:15:36 --> Input Class Initialized
INFO - 2021-01-05 09:15:36 --> Language Class Initialized
INFO - 2021-01-05 09:15:36 --> Language Class Initialized
INFO - 2021-01-05 09:15:36 --> Config Class Initialized
INFO - 2021-01-05 09:15:36 --> Loader Class Initialized
INFO - 2021-01-05 09:15:36 --> Helper loaded: url_helper
INFO - 2021-01-05 09:15:36 --> Helper loaded: file_helper
INFO - 2021-01-05 09:15:36 --> Helper loaded: form_helper
INFO - 2021-01-05 09:15:36 --> Helper loaded: my_helper
INFO - 2021-01-05 09:15:36 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:15:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:15:36 --> Controller Class Initialized
INFO - 2021-01-05 09:15:36 --> Final output sent to browser
DEBUG - 2021-01-05 09:15:36 --> Total execution time: 0.4398
INFO - 2021-01-05 09:15:40 --> Config Class Initialized
INFO - 2021-01-05 09:15:40 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:15:40 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:15:40 --> Utf8 Class Initialized
INFO - 2021-01-05 09:15:40 --> URI Class Initialized
INFO - 2021-01-05 09:15:40 --> Router Class Initialized
INFO - 2021-01-05 09:15:40 --> Output Class Initialized
INFO - 2021-01-05 09:15:40 --> Security Class Initialized
DEBUG - 2021-01-05 09:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:15:40 --> Input Class Initialized
INFO - 2021-01-05 09:15:40 --> Language Class Initialized
INFO - 2021-01-05 09:15:40 --> Language Class Initialized
INFO - 2021-01-05 09:15:40 --> Config Class Initialized
INFO - 2021-01-05 09:15:40 --> Loader Class Initialized
INFO - 2021-01-05 09:15:40 --> Helper loaded: url_helper
INFO - 2021-01-05 09:15:40 --> Helper loaded: file_helper
INFO - 2021-01-05 09:15:40 --> Helper loaded: form_helper
INFO - 2021-01-05 09:15:40 --> Helper loaded: my_helper
INFO - 2021-01-05 09:15:40 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:15:40 --> Controller Class Initialized
DEBUG - 2021-01-05 09:15:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 09:15:40 --> Final output sent to browser
DEBUG - 2021-01-05 09:15:40 --> Total execution time: 0.3436
INFO - 2021-01-05 09:15:42 --> Config Class Initialized
INFO - 2021-01-05 09:15:42 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:15:42 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:15:42 --> Utf8 Class Initialized
INFO - 2021-01-05 09:15:42 --> URI Class Initialized
INFO - 2021-01-05 09:15:42 --> Router Class Initialized
INFO - 2021-01-05 09:15:42 --> Output Class Initialized
INFO - 2021-01-05 09:15:42 --> Security Class Initialized
DEBUG - 2021-01-05 09:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:15:42 --> Input Class Initialized
INFO - 2021-01-05 09:15:42 --> Language Class Initialized
INFO - 2021-01-05 09:15:42 --> Language Class Initialized
INFO - 2021-01-05 09:15:42 --> Config Class Initialized
INFO - 2021-01-05 09:15:42 --> Loader Class Initialized
INFO - 2021-01-05 09:15:42 --> Helper loaded: url_helper
INFO - 2021-01-05 09:15:42 --> Helper loaded: file_helper
INFO - 2021-01-05 09:15:42 --> Helper loaded: form_helper
INFO - 2021-01-05 09:15:42 --> Helper loaded: my_helper
INFO - 2021-01-05 09:15:42 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:15:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:15:42 --> Controller Class Initialized
DEBUG - 2021-01-05 09:15:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-05 09:15:42 --> Final output sent to browser
DEBUG - 2021-01-05 09:15:42 --> Total execution time: 0.3998
INFO - 2021-01-05 09:15:49 --> Config Class Initialized
INFO - 2021-01-05 09:15:49 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:15:49 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:15:49 --> Utf8 Class Initialized
INFO - 2021-01-05 09:15:49 --> URI Class Initialized
INFO - 2021-01-05 09:15:49 --> Router Class Initialized
INFO - 2021-01-05 09:15:49 --> Output Class Initialized
INFO - 2021-01-05 09:15:49 --> Security Class Initialized
DEBUG - 2021-01-05 09:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:15:49 --> Input Class Initialized
INFO - 2021-01-05 09:15:49 --> Language Class Initialized
INFO - 2021-01-05 09:15:49 --> Language Class Initialized
INFO - 2021-01-05 09:15:49 --> Config Class Initialized
INFO - 2021-01-05 09:15:49 --> Loader Class Initialized
INFO - 2021-01-05 09:15:49 --> Helper loaded: url_helper
INFO - 2021-01-05 09:15:49 --> Helper loaded: file_helper
INFO - 2021-01-05 09:15:49 --> Helper loaded: form_helper
INFO - 2021-01-05 09:15:49 --> Helper loaded: my_helper
INFO - 2021-01-05 09:15:49 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:15:49 --> Controller Class Initialized
INFO - 2021-01-05 09:16:11 --> Config Class Initialized
INFO - 2021-01-05 09:16:11 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:16:11 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:16:11 --> Utf8 Class Initialized
INFO - 2021-01-05 09:16:11 --> URI Class Initialized
INFO - 2021-01-05 09:16:11 --> Router Class Initialized
INFO - 2021-01-05 09:16:11 --> Output Class Initialized
INFO - 2021-01-05 09:16:11 --> Security Class Initialized
DEBUG - 2021-01-05 09:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:16:11 --> Input Class Initialized
INFO - 2021-01-05 09:16:11 --> Language Class Initialized
INFO - 2021-01-05 09:16:11 --> Language Class Initialized
INFO - 2021-01-05 09:16:11 --> Config Class Initialized
INFO - 2021-01-05 09:16:11 --> Loader Class Initialized
INFO - 2021-01-05 09:16:11 --> Helper loaded: url_helper
INFO - 2021-01-05 09:16:11 --> Helper loaded: file_helper
INFO - 2021-01-05 09:16:11 --> Helper loaded: form_helper
INFO - 2021-01-05 09:16:11 --> Helper loaded: my_helper
INFO - 2021-01-05 09:16:11 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:16:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:16:11 --> Controller Class Initialized
DEBUG - 2021-01-05 09:16:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-05 09:16:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-05 09:16:11 --> Final output sent to browser
DEBUG - 2021-01-05 09:16:11 --> Total execution time: 0.3965
INFO - 2021-01-05 09:16:12 --> Config Class Initialized
INFO - 2021-01-05 09:16:12 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:16:12 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:16:12 --> Utf8 Class Initialized
INFO - 2021-01-05 09:16:12 --> URI Class Initialized
INFO - 2021-01-05 09:16:12 --> Router Class Initialized
INFO - 2021-01-05 09:16:12 --> Output Class Initialized
INFO - 2021-01-05 09:16:12 --> Security Class Initialized
DEBUG - 2021-01-05 09:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:16:12 --> Input Class Initialized
INFO - 2021-01-05 09:16:12 --> Language Class Initialized
INFO - 2021-01-05 09:16:12 --> Language Class Initialized
INFO - 2021-01-05 09:16:12 --> Config Class Initialized
INFO - 2021-01-05 09:16:12 --> Loader Class Initialized
INFO - 2021-01-05 09:16:12 --> Helper loaded: url_helper
INFO - 2021-01-05 09:16:12 --> Helper loaded: file_helper
INFO - 2021-01-05 09:16:12 --> Helper loaded: form_helper
INFO - 2021-01-05 09:16:12 --> Helper loaded: my_helper
INFO - 2021-01-05 09:16:12 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:16:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:16:12 --> Controller Class Initialized
DEBUG - 2021-01-05 09:16:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-05 09:16:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-05 09:16:12 --> Final output sent to browser
DEBUG - 2021-01-05 09:16:12 --> Total execution time: 0.3567
INFO - 2021-01-05 09:16:13 --> Config Class Initialized
INFO - 2021-01-05 09:16:13 --> Hooks Class Initialized
DEBUG - 2021-01-05 09:16:13 --> UTF-8 Support Enabled
INFO - 2021-01-05 09:16:13 --> Utf8 Class Initialized
INFO - 2021-01-05 09:16:13 --> URI Class Initialized
INFO - 2021-01-05 09:16:14 --> Router Class Initialized
INFO - 2021-01-05 09:16:14 --> Output Class Initialized
INFO - 2021-01-05 09:16:14 --> Security Class Initialized
DEBUG - 2021-01-05 09:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-05 09:16:14 --> Input Class Initialized
INFO - 2021-01-05 09:16:14 --> Language Class Initialized
INFO - 2021-01-05 09:16:14 --> Language Class Initialized
INFO - 2021-01-05 09:16:14 --> Config Class Initialized
INFO - 2021-01-05 09:16:14 --> Loader Class Initialized
INFO - 2021-01-05 09:16:14 --> Helper loaded: url_helper
INFO - 2021-01-05 09:16:14 --> Helper loaded: file_helper
INFO - 2021-01-05 09:16:14 --> Helper loaded: form_helper
INFO - 2021-01-05 09:16:14 --> Helper loaded: my_helper
INFO - 2021-01-05 09:16:14 --> Database Driver Class Initialized
DEBUG - 2021-01-05 09:16:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-05 09:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-05 09:16:14 --> Controller Class Initialized
