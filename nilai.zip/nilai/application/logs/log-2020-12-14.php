<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-12-14 01:38:32 --> Config Class Initialized
INFO - 2020-12-14 01:38:32 --> Hooks Class Initialized
DEBUG - 2020-12-14 01:38:32 --> UTF-8 Support Enabled
INFO - 2020-12-14 01:38:32 --> Utf8 Class Initialized
INFO - 2020-12-14 01:38:32 --> URI Class Initialized
DEBUG - 2020-12-14 01:38:32 --> No URI present. Default controller set.
INFO - 2020-12-14 01:38:33 --> Router Class Initialized
INFO - 2020-12-14 01:38:33 --> Output Class Initialized
INFO - 2020-12-14 01:38:33 --> Security Class Initialized
DEBUG - 2020-12-14 01:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-14 01:38:33 --> Input Class Initialized
INFO - 2020-12-14 01:38:33 --> Language Class Initialized
INFO - 2020-12-14 01:38:33 --> Language Class Initialized
INFO - 2020-12-14 01:38:33 --> Config Class Initialized
INFO - 2020-12-14 01:38:33 --> Loader Class Initialized
INFO - 2020-12-14 01:38:33 --> Helper loaded: url_helper
INFO - 2020-12-14 01:38:33 --> Helper loaded: file_helper
INFO - 2020-12-14 01:38:33 --> Helper loaded: form_helper
INFO - 2020-12-14 01:38:33 --> Helper loaded: my_helper
INFO - 2020-12-14 01:38:33 --> Database Driver Class Initialized
DEBUG - 2020-12-14 01:38:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-14 01:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-14 01:38:33 --> Controller Class Initialized
INFO - 2020-12-14 01:38:33 --> Config Class Initialized
INFO - 2020-12-14 01:38:33 --> Hooks Class Initialized
DEBUG - 2020-12-14 01:38:33 --> UTF-8 Support Enabled
INFO - 2020-12-14 01:38:33 --> Utf8 Class Initialized
INFO - 2020-12-14 01:38:33 --> URI Class Initialized
INFO - 2020-12-14 01:38:33 --> Router Class Initialized
INFO - 2020-12-14 01:38:33 --> Output Class Initialized
INFO - 2020-12-14 01:38:33 --> Security Class Initialized
DEBUG - 2020-12-14 01:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-14 01:38:33 --> Input Class Initialized
INFO - 2020-12-14 01:38:33 --> Language Class Initialized
INFO - 2020-12-14 01:38:33 --> Language Class Initialized
INFO - 2020-12-14 01:38:33 --> Config Class Initialized
INFO - 2020-12-14 01:38:33 --> Loader Class Initialized
INFO - 2020-12-14 01:38:33 --> Helper loaded: url_helper
INFO - 2020-12-14 01:38:33 --> Helper loaded: file_helper
INFO - 2020-12-14 01:38:33 --> Helper loaded: form_helper
INFO - 2020-12-14 01:38:33 --> Helper loaded: my_helper
INFO - 2020-12-14 01:38:33 --> Database Driver Class Initialized
DEBUG - 2020-12-14 01:38:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-14 01:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-14 01:38:33 --> Controller Class Initialized
DEBUG - 2020-12-14 01:38:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-14 01:38:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-14 01:38:33 --> Final output sent to browser
DEBUG - 2020-12-14 01:38:33 --> Total execution time: 0.2682
INFO - 2020-12-14 01:40:16 --> Config Class Initialized
INFO - 2020-12-14 01:40:16 --> Hooks Class Initialized
DEBUG - 2020-12-14 01:40:16 --> UTF-8 Support Enabled
INFO - 2020-12-14 01:40:16 --> Utf8 Class Initialized
INFO - 2020-12-14 01:40:16 --> URI Class Initialized
INFO - 2020-12-14 01:40:16 --> Router Class Initialized
INFO - 2020-12-14 01:40:16 --> Output Class Initialized
INFO - 2020-12-14 01:40:16 --> Security Class Initialized
DEBUG - 2020-12-14 01:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-14 01:40:16 --> Input Class Initialized
INFO - 2020-12-14 01:40:16 --> Language Class Initialized
INFO - 2020-12-14 01:40:16 --> Language Class Initialized
INFO - 2020-12-14 01:40:16 --> Config Class Initialized
INFO - 2020-12-14 01:40:16 --> Loader Class Initialized
INFO - 2020-12-14 01:40:16 --> Helper loaded: url_helper
INFO - 2020-12-14 01:40:16 --> Helper loaded: file_helper
INFO - 2020-12-14 01:40:16 --> Helper loaded: form_helper
INFO - 2020-12-14 01:40:16 --> Helper loaded: my_helper
INFO - 2020-12-14 01:40:16 --> Database Driver Class Initialized
DEBUG - 2020-12-14 01:40:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-14 01:40:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-14 01:40:16 --> Controller Class Initialized
INFO - 2020-12-14 01:40:16 --> Helper loaded: cookie_helper
INFO - 2020-12-14 01:40:16 --> Final output sent to browser
DEBUG - 2020-12-14 01:40:16 --> Total execution time: 0.2878
INFO - 2020-12-14 01:40:17 --> Config Class Initialized
INFO - 2020-12-14 01:40:17 --> Hooks Class Initialized
DEBUG - 2020-12-14 01:40:17 --> UTF-8 Support Enabled
INFO - 2020-12-14 01:40:17 --> Utf8 Class Initialized
INFO - 2020-12-14 01:40:17 --> URI Class Initialized
INFO - 2020-12-14 01:40:17 --> Router Class Initialized
INFO - 2020-12-14 01:40:17 --> Output Class Initialized
INFO - 2020-12-14 01:40:17 --> Security Class Initialized
DEBUG - 2020-12-14 01:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-14 01:40:17 --> Input Class Initialized
INFO - 2020-12-14 01:40:17 --> Language Class Initialized
INFO - 2020-12-14 01:40:17 --> Language Class Initialized
INFO - 2020-12-14 01:40:17 --> Config Class Initialized
INFO - 2020-12-14 01:40:17 --> Loader Class Initialized
INFO - 2020-12-14 01:40:17 --> Helper loaded: url_helper
INFO - 2020-12-14 01:40:17 --> Helper loaded: file_helper
INFO - 2020-12-14 01:40:17 --> Helper loaded: form_helper
INFO - 2020-12-14 01:40:17 --> Helper loaded: my_helper
INFO - 2020-12-14 01:40:17 --> Database Driver Class Initialized
DEBUG - 2020-12-14 01:40:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-14 01:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-14 01:40:17 --> Controller Class Initialized
DEBUG - 2020-12-14 01:40:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-14 01:40:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-14 01:40:17 --> Final output sent to browser
DEBUG - 2020-12-14 01:40:17 --> Total execution time: 0.3647
INFO - 2020-12-14 05:11:11 --> Config Class Initialized
INFO - 2020-12-14 05:11:11 --> Hooks Class Initialized
DEBUG - 2020-12-14 05:11:11 --> UTF-8 Support Enabled
INFO - 2020-12-14 05:11:11 --> Utf8 Class Initialized
INFO - 2020-12-14 05:11:11 --> URI Class Initialized
INFO - 2020-12-14 05:11:11 --> Router Class Initialized
INFO - 2020-12-14 05:11:11 --> Output Class Initialized
INFO - 2020-12-14 05:11:11 --> Security Class Initialized
DEBUG - 2020-12-14 05:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-14 05:11:11 --> Input Class Initialized
INFO - 2020-12-14 05:11:11 --> Language Class Initialized
INFO - 2020-12-14 05:11:11 --> Language Class Initialized
INFO - 2020-12-14 05:11:11 --> Config Class Initialized
INFO - 2020-12-14 05:11:11 --> Loader Class Initialized
INFO - 2020-12-14 05:11:11 --> Helper loaded: url_helper
INFO - 2020-12-14 05:11:11 --> Helper loaded: file_helper
INFO - 2020-12-14 05:11:11 --> Helper loaded: form_helper
INFO - 2020-12-14 05:11:11 --> Helper loaded: my_helper
INFO - 2020-12-14 05:11:11 --> Database Driver Class Initialized
DEBUG - 2020-12-14 05:11:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-14 05:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-14 05:11:11 --> Controller Class Initialized
DEBUG - 2020-12-14 05:11:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_catatan/views/list.php
DEBUG - 2020-12-14 05:11:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-14 05:11:11 --> Final output sent to browser
DEBUG - 2020-12-14 05:11:11 --> Total execution time: 0.2205
INFO - 2020-12-14 05:44:22 --> Config Class Initialized
INFO - 2020-12-14 05:44:22 --> Hooks Class Initialized
DEBUG - 2020-12-14 05:44:22 --> UTF-8 Support Enabled
INFO - 2020-12-14 05:44:22 --> Utf8 Class Initialized
INFO - 2020-12-14 05:44:22 --> URI Class Initialized
INFO - 2020-12-14 05:44:22 --> Router Class Initialized
INFO - 2020-12-14 05:44:22 --> Output Class Initialized
INFO - 2020-12-14 05:44:22 --> Security Class Initialized
DEBUG - 2020-12-14 05:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-14 05:44:22 --> Input Class Initialized
INFO - 2020-12-14 05:44:22 --> Language Class Initialized
INFO - 2020-12-14 05:44:22 --> Language Class Initialized
INFO - 2020-12-14 05:44:22 --> Config Class Initialized
INFO - 2020-12-14 05:44:22 --> Loader Class Initialized
INFO - 2020-12-14 05:44:22 --> Helper loaded: url_helper
INFO - 2020-12-14 05:44:22 --> Helper loaded: file_helper
INFO - 2020-12-14 05:44:22 --> Helper loaded: form_helper
INFO - 2020-12-14 05:44:22 --> Helper loaded: my_helper
INFO - 2020-12-14 05:44:22 --> Database Driver Class Initialized
DEBUG - 2020-12-14 05:44:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-14 05:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-14 05:44:22 --> Controller Class Initialized
DEBUG - 2020-12-14 05:44:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_prestasi/views/list.php
DEBUG - 2020-12-14 05:44:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-14 05:44:22 --> Final output sent to browser
DEBUG - 2020-12-14 05:44:22 --> Total execution time: 0.2171
INFO - 2020-12-14 05:44:22 --> Config Class Initialized
INFO - 2020-12-14 05:44:22 --> Hooks Class Initialized
DEBUG - 2020-12-14 05:44:22 --> UTF-8 Support Enabled
INFO - 2020-12-14 05:44:22 --> Utf8 Class Initialized
INFO - 2020-12-14 05:44:22 --> URI Class Initialized
INFO - 2020-12-14 05:44:22 --> Router Class Initialized
INFO - 2020-12-14 05:44:22 --> Output Class Initialized
INFO - 2020-12-14 05:44:22 --> Security Class Initialized
DEBUG - 2020-12-14 05:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-14 05:44:22 --> Input Class Initialized
INFO - 2020-12-14 05:44:22 --> Language Class Initialized
INFO - 2020-12-14 05:44:22 --> Language Class Initialized
INFO - 2020-12-14 05:44:22 --> Config Class Initialized
INFO - 2020-12-14 05:44:22 --> Loader Class Initialized
INFO - 2020-12-14 05:44:22 --> Helper loaded: url_helper
INFO - 2020-12-14 05:44:22 --> Helper loaded: file_helper
INFO - 2020-12-14 05:44:22 --> Helper loaded: form_helper
INFO - 2020-12-14 05:44:22 --> Helper loaded: my_helper
INFO - 2020-12-14 05:44:22 --> Database Driver Class Initialized
DEBUG - 2020-12-14 05:44:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-14 05:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-14 05:44:22 --> Controller Class Initialized
INFO - 2020-12-14 05:44:51 --> Config Class Initialized
INFO - 2020-12-14 05:44:51 --> Hooks Class Initialized
DEBUG - 2020-12-14 05:44:51 --> UTF-8 Support Enabled
INFO - 2020-12-14 05:44:51 --> Utf8 Class Initialized
INFO - 2020-12-14 05:44:51 --> URI Class Initialized
DEBUG - 2020-12-14 05:44:51 --> No URI present. Default controller set.
INFO - 2020-12-14 05:44:51 --> Router Class Initialized
INFO - 2020-12-14 05:44:51 --> Output Class Initialized
INFO - 2020-12-14 05:44:51 --> Security Class Initialized
DEBUG - 2020-12-14 05:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-14 05:44:51 --> Input Class Initialized
INFO - 2020-12-14 05:44:51 --> Language Class Initialized
INFO - 2020-12-14 05:44:51 --> Language Class Initialized
INFO - 2020-12-14 05:44:51 --> Config Class Initialized
INFO - 2020-12-14 05:44:51 --> Loader Class Initialized
INFO - 2020-12-14 05:44:51 --> Helper loaded: url_helper
INFO - 2020-12-14 05:44:51 --> Helper loaded: file_helper
INFO - 2020-12-14 05:44:51 --> Helper loaded: form_helper
INFO - 2020-12-14 05:44:51 --> Helper loaded: my_helper
INFO - 2020-12-14 05:44:51 --> Database Driver Class Initialized
DEBUG - 2020-12-14 05:44:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-14 05:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-14 05:44:51 --> Controller Class Initialized
DEBUG - 2020-12-14 05:44:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-14 05:44:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-14 05:44:51 --> Final output sent to browser
DEBUG - 2020-12-14 05:44:51 --> Total execution time: 0.1830
INFO - 2020-12-14 05:44:54 --> Config Class Initialized
INFO - 2020-12-14 05:44:54 --> Hooks Class Initialized
DEBUG - 2020-12-14 05:44:54 --> UTF-8 Support Enabled
INFO - 2020-12-14 05:44:54 --> Utf8 Class Initialized
INFO - 2020-12-14 05:44:54 --> URI Class Initialized
DEBUG - 2020-12-14 05:44:54 --> No URI present. Default controller set.
INFO - 2020-12-14 05:44:54 --> Router Class Initialized
INFO - 2020-12-14 05:44:54 --> Output Class Initialized
INFO - 2020-12-14 05:44:54 --> Security Class Initialized
DEBUG - 2020-12-14 05:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-14 05:44:54 --> Input Class Initialized
INFO - 2020-12-14 05:44:54 --> Language Class Initialized
INFO - 2020-12-14 05:44:54 --> Language Class Initialized
INFO - 2020-12-14 05:44:54 --> Config Class Initialized
INFO - 2020-12-14 05:44:54 --> Loader Class Initialized
INFO - 2020-12-14 05:44:54 --> Helper loaded: url_helper
INFO - 2020-12-14 05:44:54 --> Helper loaded: file_helper
INFO - 2020-12-14 05:44:54 --> Helper loaded: form_helper
INFO - 2020-12-14 05:44:54 --> Helper loaded: my_helper
INFO - 2020-12-14 05:44:54 --> Database Driver Class Initialized
DEBUG - 2020-12-14 05:44:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-14 05:44:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-14 05:44:54 --> Controller Class Initialized
DEBUG - 2020-12-14 05:44:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-14 05:44:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-14 05:44:54 --> Final output sent to browser
DEBUG - 2020-12-14 05:44:54 --> Total execution time: 0.1983
INFO - 2020-12-14 05:44:55 --> Config Class Initialized
INFO - 2020-12-14 05:44:55 --> Hooks Class Initialized
DEBUG - 2020-12-14 05:44:55 --> UTF-8 Support Enabled
INFO - 2020-12-14 05:44:55 --> Utf8 Class Initialized
INFO - 2020-12-14 05:44:55 --> URI Class Initialized
INFO - 2020-12-14 05:44:55 --> Router Class Initialized
INFO - 2020-12-14 05:44:55 --> Output Class Initialized
INFO - 2020-12-14 05:44:55 --> Security Class Initialized
DEBUG - 2020-12-14 05:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-14 05:44:55 --> Input Class Initialized
INFO - 2020-12-14 05:44:55 --> Language Class Initialized
INFO - 2020-12-14 05:44:55 --> Language Class Initialized
INFO - 2020-12-14 05:44:55 --> Config Class Initialized
INFO - 2020-12-14 05:44:55 --> Loader Class Initialized
INFO - 2020-12-14 05:44:55 --> Helper loaded: url_helper
INFO - 2020-12-14 05:44:55 --> Helper loaded: file_helper
INFO - 2020-12-14 05:44:55 --> Helper loaded: form_helper
INFO - 2020-12-14 05:44:55 --> Helper loaded: my_helper
INFO - 2020-12-14 05:44:55 --> Database Driver Class Initialized
DEBUG - 2020-12-14 05:44:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-14 05:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-14 05:44:55 --> Controller Class Initialized
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 05:44:55 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 05:44:56 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 05:44:56 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 05:44:56 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 05:44:56 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 05:44:56 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 05:44:56 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 05:44:56 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 05:44:56 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 05:44:56 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 05:44:56 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 05:44:56 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 05:44:56 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 05:44:56 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 05:44:56 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 05:44:56 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 05:44:56 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 05:44:56 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 05:44:56 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 05:44:56 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 05:44:56 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 05:44:56 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 05:44:56 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 05:44:56 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 05:44:56 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 05:44:56 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 05:44:56 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 05:44:56 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 05:44:56 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 05:44:56 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
DEBUG - 2020-12-14 05:44:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2020-12-14 05:44:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-14 05:44:56 --> Final output sent to browser
DEBUG - 2020-12-14 05:44:56 --> Total execution time: 0.8570
INFO - 2020-12-14 07:04:06 --> Config Class Initialized
INFO - 2020-12-14 07:04:06 --> Hooks Class Initialized
DEBUG - 2020-12-14 07:04:06 --> UTF-8 Support Enabled
INFO - 2020-12-14 07:04:06 --> Utf8 Class Initialized
INFO - 2020-12-14 07:04:06 --> URI Class Initialized
INFO - 2020-12-14 07:04:06 --> Router Class Initialized
INFO - 2020-12-14 07:04:06 --> Output Class Initialized
INFO - 2020-12-14 07:04:06 --> Security Class Initialized
DEBUG - 2020-12-14 07:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-14 07:04:06 --> Input Class Initialized
INFO - 2020-12-14 07:04:06 --> Language Class Initialized
INFO - 2020-12-14 07:04:06 --> Language Class Initialized
INFO - 2020-12-14 07:04:06 --> Config Class Initialized
INFO - 2020-12-14 07:04:06 --> Loader Class Initialized
INFO - 2020-12-14 07:04:06 --> Helper loaded: url_helper
INFO - 2020-12-14 07:04:06 --> Helper loaded: file_helper
INFO - 2020-12-14 07:04:06 --> Helper loaded: form_helper
INFO - 2020-12-14 07:04:06 --> Helper loaded: my_helper
INFO - 2020-12-14 07:04:06 --> Database Driver Class Initialized
DEBUG - 2020-12-14 07:04:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-14 07:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-14 07:04:06 --> Controller Class Initialized
ERROR - 2020-12-14 07:04:06 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:04:06 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:04:06 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:04:06 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:04:06 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:04:06 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:04:06 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:04:06 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:04:06 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:04:06 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:04:06 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:04:06 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:04:06 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:04:06 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:04:06 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:04:06 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:04:06 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:04:06 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:04:06 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:04:06 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:04:06 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:04:06 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:04:06 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:04:06 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:04:06 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:04:06 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:04:06 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:04:06 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:04:06 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:04:06 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:04:06 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:04:06 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:04:07 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
DEBUG - 2020-12-14 07:04:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2020-12-14 07:04:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-14 07:04:07 --> Final output sent to browser
DEBUG - 2020-12-14 07:04:07 --> Total execution time: 0.8840
INFO - 2020-12-14 07:05:03 --> Config Class Initialized
INFO - 2020-12-14 07:05:03 --> Hooks Class Initialized
DEBUG - 2020-12-14 07:05:03 --> UTF-8 Support Enabled
INFO - 2020-12-14 07:05:03 --> Utf8 Class Initialized
INFO - 2020-12-14 07:05:03 --> URI Class Initialized
INFO - 2020-12-14 07:05:03 --> Router Class Initialized
INFO - 2020-12-14 07:05:03 --> Output Class Initialized
INFO - 2020-12-14 07:05:03 --> Security Class Initialized
DEBUG - 2020-12-14 07:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-14 07:05:03 --> Input Class Initialized
INFO - 2020-12-14 07:05:03 --> Language Class Initialized
INFO - 2020-12-14 07:05:03 --> Language Class Initialized
INFO - 2020-12-14 07:05:03 --> Config Class Initialized
INFO - 2020-12-14 07:05:03 --> Loader Class Initialized
INFO - 2020-12-14 07:05:03 --> Helper loaded: url_helper
INFO - 2020-12-14 07:05:03 --> Helper loaded: file_helper
INFO - 2020-12-14 07:05:03 --> Helper loaded: form_helper
INFO - 2020-12-14 07:05:03 --> Helper loaded: my_helper
INFO - 2020-12-14 07:05:03 --> Database Driver Class Initialized
DEBUG - 2020-12-14 07:05:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-14 07:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-14 07:05:03 --> Controller Class Initialized
ERROR - 2020-12-14 07:05:03 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:03 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:03 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:03 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:03 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:03 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:03 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:03 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:03 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:03 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:03 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:03 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:03 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:03 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:03 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:03 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:03 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:03 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:03 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:03 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:03 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:03 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:03 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:03 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:03 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:03 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:03 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:03 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:03 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:03 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:03 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:03 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:03 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:03 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:03 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:03 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:03 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:03 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:03 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:03 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:03 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:04 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
DEBUG - 2020-12-14 07:05:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2020-12-14 07:05:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-14 07:05:04 --> Final output sent to browser
DEBUG - 2020-12-14 07:05:04 --> Total execution time: 0.9136
INFO - 2020-12-14 07:05:31 --> Config Class Initialized
INFO - 2020-12-14 07:05:31 --> Hooks Class Initialized
DEBUG - 2020-12-14 07:05:31 --> UTF-8 Support Enabled
INFO - 2020-12-14 07:05:31 --> Utf8 Class Initialized
INFO - 2020-12-14 07:05:31 --> URI Class Initialized
INFO - 2020-12-14 07:05:31 --> Router Class Initialized
INFO - 2020-12-14 07:05:31 --> Output Class Initialized
INFO - 2020-12-14 07:05:31 --> Security Class Initialized
DEBUG - 2020-12-14 07:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-14 07:05:31 --> Input Class Initialized
INFO - 2020-12-14 07:05:31 --> Language Class Initialized
INFO - 2020-12-14 07:05:31 --> Language Class Initialized
INFO - 2020-12-14 07:05:31 --> Config Class Initialized
INFO - 2020-12-14 07:05:31 --> Loader Class Initialized
INFO - 2020-12-14 07:05:31 --> Helper loaded: url_helper
INFO - 2020-12-14 07:05:31 --> Helper loaded: file_helper
INFO - 2020-12-14 07:05:31 --> Helper loaded: form_helper
INFO - 2020-12-14 07:05:31 --> Helper loaded: my_helper
INFO - 2020-12-14 07:05:31 --> Database Driver Class Initialized
DEBUG - 2020-12-14 07:05:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-14 07:05:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-14 07:05:31 --> Controller Class Initialized
ERROR - 2020-12-14 07:05:31 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:31 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:31 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:31 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:31 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:31 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:31 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:31 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:31 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:31 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:31 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:31 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:31 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:31 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:31 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:31 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:31 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:31 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:31 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:31 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:31 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:31 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:31 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:31 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:31 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:31 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:31 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:31 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:31 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:31 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:31 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:31 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:31 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:31 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:31 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:31 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:31 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:31 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:31 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:31 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:31 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:31 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:31 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:31 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:31 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:31 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:31 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:31 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:32 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:32 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:32 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:32 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:32 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:32 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:32 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:32 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:32 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:32 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:32 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:32 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:32 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:32 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:32 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:32 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:32 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:32 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:32 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:32 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:32 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:32 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:32 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:32 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:32 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:32 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:32 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:32 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:32 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:32 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:32 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:32 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:32 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:32 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:32 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:32 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:32 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:32 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:32 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:32 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:32 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:32 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:32 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:32 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:32 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:32 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:32 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:32 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:32 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:32 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:32 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:32 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:32 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:32 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:32 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:32 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:32 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:32 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:32 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:32 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:05:32 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:05:32 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:05:32 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
DEBUG - 2020-12-14 07:05:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2020-12-14 07:05:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-14 07:05:32 --> Final output sent to browser
DEBUG - 2020-12-14 07:05:32 --> Total execution time: 0.9424
INFO - 2020-12-14 07:06:05 --> Config Class Initialized
INFO - 2020-12-14 07:06:05 --> Hooks Class Initialized
DEBUG - 2020-12-14 07:06:05 --> UTF-8 Support Enabled
INFO - 2020-12-14 07:06:05 --> Utf8 Class Initialized
INFO - 2020-12-14 07:06:05 --> URI Class Initialized
INFO - 2020-12-14 07:06:05 --> Router Class Initialized
INFO - 2020-12-14 07:06:05 --> Output Class Initialized
INFO - 2020-12-14 07:06:05 --> Security Class Initialized
DEBUG - 2020-12-14 07:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-14 07:06:05 --> Input Class Initialized
INFO - 2020-12-14 07:06:05 --> Language Class Initialized
INFO - 2020-12-14 07:06:05 --> Language Class Initialized
INFO - 2020-12-14 07:06:05 --> Config Class Initialized
INFO - 2020-12-14 07:06:05 --> Loader Class Initialized
INFO - 2020-12-14 07:06:05 --> Helper loaded: url_helper
INFO - 2020-12-14 07:06:05 --> Helper loaded: file_helper
INFO - 2020-12-14 07:06:05 --> Helper loaded: form_helper
INFO - 2020-12-14 07:06:05 --> Helper loaded: my_helper
INFO - 2020-12-14 07:06:05 --> Database Driver Class Initialized
DEBUG - 2020-12-14 07:06:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-14 07:06:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-14 07:06:05 --> Controller Class Initialized
DEBUG - 2020-12-14 07:06:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_catatan/views/list.php
DEBUG - 2020-12-14 07:06:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-14 07:06:05 --> Final output sent to browser
DEBUG - 2020-12-14 07:06:05 --> Total execution time: 0.1997
INFO - 2020-12-14 07:07:35 --> Config Class Initialized
INFO - 2020-12-14 07:07:35 --> Hooks Class Initialized
DEBUG - 2020-12-14 07:07:35 --> UTF-8 Support Enabled
INFO - 2020-12-14 07:07:35 --> Utf8 Class Initialized
INFO - 2020-12-14 07:07:35 --> URI Class Initialized
INFO - 2020-12-14 07:07:35 --> Router Class Initialized
INFO - 2020-12-14 07:07:35 --> Output Class Initialized
INFO - 2020-12-14 07:07:35 --> Security Class Initialized
DEBUG - 2020-12-14 07:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-14 07:07:35 --> Input Class Initialized
INFO - 2020-12-14 07:07:35 --> Language Class Initialized
INFO - 2020-12-14 07:07:35 --> Language Class Initialized
INFO - 2020-12-14 07:07:35 --> Config Class Initialized
INFO - 2020-12-14 07:07:35 --> Loader Class Initialized
INFO - 2020-12-14 07:07:35 --> Helper loaded: url_helper
INFO - 2020-12-14 07:07:35 --> Helper loaded: file_helper
INFO - 2020-12-14 07:07:35 --> Helper loaded: form_helper
INFO - 2020-12-14 07:07:35 --> Helper loaded: my_helper
INFO - 2020-12-14 07:07:35 --> Database Driver Class Initialized
DEBUG - 2020-12-14 07:07:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-14 07:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-14 07:07:35 --> Controller Class Initialized
ERROR - 2020-12-14 07:07:35 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:07:35 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:07:35 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:07:35 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:07:35 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:07:35 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:07:35 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:07:35 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:07:35 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:07:35 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:07:35 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:07:35 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:07:35 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:07:35 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:07:35 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:07:35 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:07:35 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:07:35 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:07:35 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:07:35 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:07:35 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:07:35 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:07:35 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:07:35 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:07:35 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:07:35 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:07:35 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:07:35 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:07:35 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:07:35 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:07:35 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:07:35 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:07:35 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:07:35 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:07:35 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:07:35 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:07:35 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:07:35 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:07:35 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:07:35 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:07:35 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:07:35 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:07:35 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:07:35 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:07:35 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:07:35 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:07:35 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:07:35 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:07:35 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:07:35 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:07:35 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:07:35 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:07:35 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:07:35 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:07:35 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:07:35 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:07:35 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:07:35 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:07:35 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:07:35 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:07:36 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:07:36 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:07:36 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:07:36 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:07:36 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:07:36 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:07:36 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:07:36 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:07:36 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:07:36 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:07:36 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:07:36 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:07:36 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:07:36 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:07:36 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:07:36 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:07:36 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:07:36 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:07:36 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:07:36 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:07:36 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:07:36 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:07:36 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:07:36 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:07:36 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:07:36 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:07:36 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:07:36 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:07:36 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:07:36 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:07:36 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:07:36 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:07:36 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:07:36 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:07:36 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:07:36 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:07:36 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:07:36 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:07:36 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:07:36 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:07:36 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:07:36 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:07:36 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:07:36 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:07:36 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:07:36 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:07:36 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:07:36 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:07:36 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:07:36 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:07:36 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
DEBUG - 2020-12-14 07:07:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2020-12-14 07:07:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-14 07:07:36 --> Final output sent to browser
DEBUG - 2020-12-14 07:07:36 --> Total execution time: 0.9760
INFO - 2020-12-14 07:09:01 --> Config Class Initialized
INFO - 2020-12-14 07:09:01 --> Hooks Class Initialized
DEBUG - 2020-12-14 07:09:01 --> UTF-8 Support Enabled
INFO - 2020-12-14 07:09:01 --> Utf8 Class Initialized
INFO - 2020-12-14 07:09:01 --> URI Class Initialized
INFO - 2020-12-14 07:09:01 --> Router Class Initialized
INFO - 2020-12-14 07:09:01 --> Output Class Initialized
INFO - 2020-12-14 07:09:01 --> Security Class Initialized
DEBUG - 2020-12-14 07:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-14 07:09:01 --> Input Class Initialized
INFO - 2020-12-14 07:09:01 --> Language Class Initialized
INFO - 2020-12-14 07:09:01 --> Language Class Initialized
INFO - 2020-12-14 07:09:01 --> Config Class Initialized
INFO - 2020-12-14 07:09:01 --> Loader Class Initialized
INFO - 2020-12-14 07:09:01 --> Helper loaded: url_helper
INFO - 2020-12-14 07:09:01 --> Helper loaded: file_helper
INFO - 2020-12-14 07:09:01 --> Helper loaded: form_helper
INFO - 2020-12-14 07:09:01 --> Helper loaded: my_helper
INFO - 2020-12-14 07:09:01 --> Database Driver Class Initialized
DEBUG - 2020-12-14 07:09:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-14 07:09:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-14 07:09:01 --> Controller Class Initialized
ERROR - 2020-12-14 07:09:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ' a.mitra, a.lokasi, a.lama, a.keterangan
                                      ' at line 2 - Invalid query: SELECT 
                                                    a.*, b.nama,, a.mitra, a.lokasi, a.lama, a.keterangan
                                                    FROM t_pkl a
                                                    INNER JOIN m_siswa b ON a.id_siswa = b.id
                                                    INNER JOIN t_kelas_siswa c ON CONCAT(c.ta,c.id_kelas,c.id_siswa) = CONCAT('2020','41',b.id)
                                                    WHERE c.id_kelas = '41' AND a.ta = '20201'
INFO - 2020-12-14 07:09:01 --> Language file loaded: language/english/db_lang.php
INFO - 2020-12-14 07:09:38 --> Config Class Initialized
INFO - 2020-12-14 07:09:38 --> Hooks Class Initialized
DEBUG - 2020-12-14 07:09:38 --> UTF-8 Support Enabled
INFO - 2020-12-14 07:09:38 --> Utf8 Class Initialized
INFO - 2020-12-14 07:09:38 --> URI Class Initialized
INFO - 2020-12-14 07:09:38 --> Router Class Initialized
INFO - 2020-12-14 07:09:38 --> Output Class Initialized
INFO - 2020-12-14 07:09:38 --> Security Class Initialized
DEBUG - 2020-12-14 07:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-14 07:09:38 --> Input Class Initialized
INFO - 2020-12-14 07:09:38 --> Language Class Initialized
INFO - 2020-12-14 07:09:38 --> Language Class Initialized
INFO - 2020-12-14 07:09:38 --> Config Class Initialized
INFO - 2020-12-14 07:09:38 --> Loader Class Initialized
INFO - 2020-12-14 07:09:38 --> Helper loaded: url_helper
INFO - 2020-12-14 07:09:38 --> Helper loaded: file_helper
INFO - 2020-12-14 07:09:38 --> Helper loaded: form_helper
INFO - 2020-12-14 07:09:38 --> Helper loaded: my_helper
INFO - 2020-12-14 07:09:39 --> Database Driver Class Initialized
DEBUG - 2020-12-14 07:09:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-14 07:09:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-14 07:09:39 --> Controller Class Initialized
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:09:39 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
DEBUG - 2020-12-14 07:09:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2020-12-14 07:09:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-14 07:09:40 --> Final output sent to browser
DEBUG - 2020-12-14 07:09:40 --> Total execution time: 1.3373
INFO - 2020-12-14 07:09:41 --> Config Class Initialized
INFO - 2020-12-14 07:09:41 --> Hooks Class Initialized
DEBUG - 2020-12-14 07:09:41 --> UTF-8 Support Enabled
INFO - 2020-12-14 07:09:42 --> Utf8 Class Initialized
INFO - 2020-12-14 07:09:42 --> URI Class Initialized
INFO - 2020-12-14 07:09:42 --> Router Class Initialized
INFO - 2020-12-14 07:09:42 --> Output Class Initialized
INFO - 2020-12-14 07:09:42 --> Security Class Initialized
DEBUG - 2020-12-14 07:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-14 07:09:42 --> Input Class Initialized
INFO - 2020-12-14 07:09:42 --> Language Class Initialized
INFO - 2020-12-14 07:09:42 --> Language Class Initialized
INFO - 2020-12-14 07:09:42 --> Config Class Initialized
INFO - 2020-12-14 07:09:42 --> Loader Class Initialized
INFO - 2020-12-14 07:09:42 --> Helper loaded: url_helper
INFO - 2020-12-14 07:09:42 --> Helper loaded: file_helper
INFO - 2020-12-14 07:09:42 --> Helper loaded: form_helper
INFO - 2020-12-14 07:09:42 --> Helper loaded: my_helper
INFO - 2020-12-14 07:09:42 --> Database Driver Class Initialized
DEBUG - 2020-12-14 07:09:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-14 07:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-14 07:09:42 --> Controller Class Initialized
ERROR - 2020-12-14 07:09:42 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
INFO - 2020-12-14 07:09:43 --> Config Class Initialized
INFO - 2020-12-14 07:09:43 --> Hooks Class Initialized
DEBUG - 2020-12-14 07:09:43 --> UTF-8 Support Enabled
INFO - 2020-12-14 07:09:43 --> Utf8 Class Initialized
INFO - 2020-12-14 07:09:43 --> URI Class Initialized
INFO - 2020-12-14 07:09:43 --> Router Class Initialized
INFO - 2020-12-14 07:09:43 --> Output Class Initialized
INFO - 2020-12-14 07:09:43 --> Security Class Initialized
DEBUG - 2020-12-14 07:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-14 07:09:43 --> Input Class Initialized
INFO - 2020-12-14 07:09:43 --> Language Class Initialized
INFO - 2020-12-14 07:09:43 --> Language Class Initialized
INFO - 2020-12-14 07:09:43 --> Config Class Initialized
INFO - 2020-12-14 07:09:43 --> Loader Class Initialized
INFO - 2020-12-14 07:09:43 --> Helper loaded: url_helper
INFO - 2020-12-14 07:09:43 --> Helper loaded: file_helper
INFO - 2020-12-14 07:09:43 --> Helper loaded: form_helper
INFO - 2020-12-14 07:09:43 --> Helper loaded: my_helper
INFO - 2020-12-14 07:09:43 --> Database Driver Class Initialized
DEBUG - 2020-12-14 07:09:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-14 07:09:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-14 07:09:43 --> Controller Class Initialized
DEBUG - 2020-12-14 07:09:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2020-12-14 07:09:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-14 07:09:43 --> Final output sent to browser
DEBUG - 2020-12-14 07:09:43 --> Total execution time: 0.2655
INFO - 2020-12-14 07:15:29 --> Config Class Initialized
INFO - 2020-12-14 07:15:29 --> Hooks Class Initialized
DEBUG - 2020-12-14 07:15:29 --> UTF-8 Support Enabled
INFO - 2020-12-14 07:15:29 --> Utf8 Class Initialized
INFO - 2020-12-14 07:15:29 --> URI Class Initialized
INFO - 2020-12-14 07:15:29 --> Router Class Initialized
INFO - 2020-12-14 07:15:29 --> Output Class Initialized
INFO - 2020-12-14 07:15:29 --> Security Class Initialized
DEBUG - 2020-12-14 07:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-14 07:15:29 --> Input Class Initialized
INFO - 2020-12-14 07:15:29 --> Language Class Initialized
INFO - 2020-12-14 07:15:29 --> Language Class Initialized
INFO - 2020-12-14 07:15:29 --> Config Class Initialized
INFO - 2020-12-14 07:15:29 --> Loader Class Initialized
INFO - 2020-12-14 07:15:29 --> Helper loaded: url_helper
INFO - 2020-12-14 07:15:29 --> Helper loaded: file_helper
INFO - 2020-12-14 07:15:29 --> Helper loaded: form_helper
INFO - 2020-12-14 07:15:29 --> Helper loaded: my_helper
INFO - 2020-12-14 07:15:29 --> Database Driver Class Initialized
DEBUG - 2020-12-14 07:15:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-14 07:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-14 07:15:30 --> Controller Class Initialized
DEBUG - 2020-12-14 07:15:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2020-12-14 07:15:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-14 07:15:30 --> Final output sent to browser
DEBUG - 2020-12-14 07:15:30 --> Total execution time: 0.2203
INFO - 2020-12-14 07:15:33 --> Config Class Initialized
INFO - 2020-12-14 07:15:33 --> Hooks Class Initialized
DEBUG - 2020-12-14 07:15:33 --> UTF-8 Support Enabled
INFO - 2020-12-14 07:15:33 --> Utf8 Class Initialized
INFO - 2020-12-14 07:15:33 --> URI Class Initialized
INFO - 2020-12-14 07:15:33 --> Router Class Initialized
INFO - 2020-12-14 07:15:33 --> Output Class Initialized
INFO - 2020-12-14 07:15:33 --> Security Class Initialized
DEBUG - 2020-12-14 07:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-14 07:15:33 --> Input Class Initialized
INFO - 2020-12-14 07:15:33 --> Language Class Initialized
INFO - 2020-12-14 07:15:33 --> Language Class Initialized
INFO - 2020-12-14 07:15:33 --> Config Class Initialized
INFO - 2020-12-14 07:15:33 --> Loader Class Initialized
INFO - 2020-12-14 07:15:33 --> Helper loaded: url_helper
INFO - 2020-12-14 07:15:33 --> Helper loaded: file_helper
INFO - 2020-12-14 07:15:33 --> Helper loaded: form_helper
INFO - 2020-12-14 07:15:33 --> Helper loaded: my_helper
INFO - 2020-12-14 07:15:33 --> Database Driver Class Initialized
DEBUG - 2020-12-14 07:15:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-14 07:15:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-14 07:15:33 --> Controller Class Initialized
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:15:33 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:15:34 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:15:34 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:15:34 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:15:34 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:15:34 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:15:34 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:15:34 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:15:34 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:15:34 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:15:34 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:15:34 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:15:34 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:15:34 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:15:34 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:15:34 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:15:34 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:15:34 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
DEBUG - 2020-12-14 07:15:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2020-12-14 07:15:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-14 07:15:34 --> Final output sent to browser
DEBUG - 2020-12-14 07:15:34 --> Total execution time: 1.0477
INFO - 2020-12-14 07:18:49 --> Config Class Initialized
INFO - 2020-12-14 07:18:49 --> Hooks Class Initialized
DEBUG - 2020-12-14 07:18:49 --> UTF-8 Support Enabled
INFO - 2020-12-14 07:18:49 --> Utf8 Class Initialized
INFO - 2020-12-14 07:18:49 --> URI Class Initialized
INFO - 2020-12-14 07:18:49 --> Router Class Initialized
INFO - 2020-12-14 07:18:49 --> Output Class Initialized
INFO - 2020-12-14 07:18:49 --> Security Class Initialized
DEBUG - 2020-12-14 07:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-14 07:18:49 --> Input Class Initialized
INFO - 2020-12-14 07:18:49 --> Language Class Initialized
INFO - 2020-12-14 07:18:49 --> Language Class Initialized
INFO - 2020-12-14 07:18:49 --> Config Class Initialized
INFO - 2020-12-14 07:18:49 --> Loader Class Initialized
INFO - 2020-12-14 07:18:49 --> Helper loaded: url_helper
INFO - 2020-12-14 07:18:49 --> Helper loaded: file_helper
INFO - 2020-12-14 07:18:49 --> Helper loaded: form_helper
INFO - 2020-12-14 07:18:50 --> Helper loaded: my_helper
INFO - 2020-12-14 07:18:50 --> Database Driver Class Initialized
DEBUG - 2020-12-14 07:18:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-14 07:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-14 07:18:50 --> Controller Class Initialized
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:50 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
DEBUG - 2020-12-14 07:18:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2020-12-14 07:18:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-14 07:18:50 --> Final output sent to browser
DEBUG - 2020-12-14 07:18:50 --> Total execution time: 1.0652
INFO - 2020-12-14 07:18:55 --> Config Class Initialized
INFO - 2020-12-14 07:18:55 --> Hooks Class Initialized
DEBUG - 2020-12-14 07:18:55 --> UTF-8 Support Enabled
INFO - 2020-12-14 07:18:55 --> Utf8 Class Initialized
INFO - 2020-12-14 07:18:55 --> URI Class Initialized
INFO - 2020-12-14 07:18:55 --> Router Class Initialized
INFO - 2020-12-14 07:18:55 --> Output Class Initialized
INFO - 2020-12-14 07:18:55 --> Security Class Initialized
DEBUG - 2020-12-14 07:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-14 07:18:55 --> Input Class Initialized
INFO - 2020-12-14 07:18:55 --> Language Class Initialized
INFO - 2020-12-14 07:18:55 --> Language Class Initialized
INFO - 2020-12-14 07:18:55 --> Config Class Initialized
INFO - 2020-12-14 07:18:55 --> Loader Class Initialized
INFO - 2020-12-14 07:18:55 --> Helper loaded: url_helper
INFO - 2020-12-14 07:18:55 --> Helper loaded: file_helper
INFO - 2020-12-14 07:18:55 --> Helper loaded: form_helper
INFO - 2020-12-14 07:18:55 --> Helper loaded: my_helper
INFO - 2020-12-14 07:18:55 --> Database Driver Class Initialized
DEBUG - 2020-12-14 07:18:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-14 07:18:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-14 07:18:55 --> Controller Class Initialized
DEBUG - 2020-12-14 07:18:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2020-12-14 07:18:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-14 07:18:55 --> Final output sent to browser
DEBUG - 2020-12-14 07:18:55 --> Total execution time: 0.2779
INFO - 2020-12-14 07:18:56 --> Config Class Initialized
INFO - 2020-12-14 07:18:56 --> Hooks Class Initialized
DEBUG - 2020-12-14 07:18:56 --> UTF-8 Support Enabled
INFO - 2020-12-14 07:18:56 --> Utf8 Class Initialized
INFO - 2020-12-14 07:18:56 --> URI Class Initialized
INFO - 2020-12-14 07:18:56 --> Router Class Initialized
INFO - 2020-12-14 07:18:56 --> Output Class Initialized
INFO - 2020-12-14 07:18:56 --> Security Class Initialized
DEBUG - 2020-12-14 07:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-14 07:18:56 --> Input Class Initialized
INFO - 2020-12-14 07:18:56 --> Language Class Initialized
INFO - 2020-12-14 07:18:56 --> Language Class Initialized
INFO - 2020-12-14 07:18:56 --> Config Class Initialized
INFO - 2020-12-14 07:18:56 --> Loader Class Initialized
INFO - 2020-12-14 07:18:56 --> Helper loaded: url_helper
INFO - 2020-12-14 07:18:56 --> Helper loaded: file_helper
INFO - 2020-12-14 07:18:56 --> Helper loaded: form_helper
INFO - 2020-12-14 07:18:56 --> Helper loaded: my_helper
INFO - 2020-12-14 07:18:56 --> Database Driver Class Initialized
DEBUG - 2020-12-14 07:18:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-14 07:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-14 07:18:56 --> Controller Class Initialized
ERROR - 2020-12-14 07:18:56 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:56 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:56 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:56 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:56 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:56 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:56 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:56 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: mitra_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 38
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lokasi_ C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 41
ERROR - 2020-12-14 07:18:57 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_pkl\views\list.php 45
DEBUG - 2020-12-14 07:18:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2020-12-14 07:18:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-14 07:18:57 --> Final output sent to browser
DEBUG - 2020-12-14 07:18:57 --> Total execution time: 1.2601
INFO - 2020-12-14 07:21:50 --> Config Class Initialized
INFO - 2020-12-14 07:21:50 --> Hooks Class Initialized
DEBUG - 2020-12-14 07:21:50 --> UTF-8 Support Enabled
INFO - 2020-12-14 07:21:50 --> Utf8 Class Initialized
INFO - 2020-12-14 07:21:50 --> URI Class Initialized
INFO - 2020-12-14 07:21:50 --> Router Class Initialized
INFO - 2020-12-14 07:21:50 --> Output Class Initialized
INFO - 2020-12-14 07:21:50 --> Security Class Initialized
DEBUG - 2020-12-14 07:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-14 07:21:50 --> Input Class Initialized
INFO - 2020-12-14 07:21:50 --> Language Class Initialized
INFO - 2020-12-14 07:21:50 --> Language Class Initialized
INFO - 2020-12-14 07:21:50 --> Config Class Initialized
INFO - 2020-12-14 07:21:50 --> Loader Class Initialized
INFO - 2020-12-14 07:21:50 --> Helper loaded: url_helper
INFO - 2020-12-14 07:21:50 --> Helper loaded: file_helper
INFO - 2020-12-14 07:21:50 --> Helper loaded: form_helper
INFO - 2020-12-14 07:21:50 --> Helper loaded: my_helper
INFO - 2020-12-14 07:21:50 --> Database Driver Class Initialized
DEBUG - 2020-12-14 07:21:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-14 07:21:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-14 07:21:50 --> Controller Class Initialized
ERROR - 2020-12-14 07:21:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '''
                                                    FROM t_kelas_siswa a
  ' at line 2 - Invalid query: SELECT 
                                                    a.id_siswa, b.nama, '' mitra, '' lokasi, '' lama, '' keterangan ''
                                                    FROM t_kelas_siswa a
                                                    INNER JOIN m_siswa b ON a.id_siswa = b.id
                                                    WHERE a.id_kelas = '41' AND a.ta = '2020'
INFO - 2020-12-14 07:21:50 --> Language file loaded: language/english/db_lang.php
INFO - 2020-12-14 07:22:34 --> Config Class Initialized
INFO - 2020-12-14 07:22:34 --> Hooks Class Initialized
DEBUG - 2020-12-14 07:22:34 --> UTF-8 Support Enabled
INFO - 2020-12-14 07:22:34 --> Utf8 Class Initialized
INFO - 2020-12-14 07:22:34 --> URI Class Initialized
INFO - 2020-12-14 07:22:34 --> Router Class Initialized
INFO - 2020-12-14 07:22:34 --> Output Class Initialized
INFO - 2020-12-14 07:22:34 --> Security Class Initialized
DEBUG - 2020-12-14 07:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-14 07:22:34 --> Input Class Initialized
INFO - 2020-12-14 07:22:34 --> Language Class Initialized
INFO - 2020-12-14 07:22:34 --> Language Class Initialized
INFO - 2020-12-14 07:22:34 --> Config Class Initialized
INFO - 2020-12-14 07:22:34 --> Loader Class Initialized
INFO - 2020-12-14 07:22:34 --> Helper loaded: url_helper
INFO - 2020-12-14 07:22:34 --> Helper loaded: file_helper
INFO - 2020-12-14 07:22:34 --> Helper loaded: form_helper
INFO - 2020-12-14 07:22:34 --> Helper loaded: my_helper
INFO - 2020-12-14 07:22:34 --> Database Driver Class Initialized
DEBUG - 2020-12-14 07:22:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-14 07:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-14 07:22:34 --> Controller Class Initialized
DEBUG - 2020-12-14 07:22:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2020-12-14 07:22:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-14 07:22:34 --> Final output sent to browser
DEBUG - 2020-12-14 07:22:34 --> Total execution time: 0.6193
INFO - 2020-12-14 07:23:30 --> Config Class Initialized
INFO - 2020-12-14 07:23:30 --> Hooks Class Initialized
DEBUG - 2020-12-14 07:23:30 --> UTF-8 Support Enabled
INFO - 2020-12-14 07:23:30 --> Utf8 Class Initialized
INFO - 2020-12-14 07:23:30 --> URI Class Initialized
INFO - 2020-12-14 07:23:30 --> Router Class Initialized
INFO - 2020-12-14 07:23:30 --> Output Class Initialized
INFO - 2020-12-14 07:23:30 --> Security Class Initialized
DEBUG - 2020-12-14 07:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-14 07:23:30 --> Input Class Initialized
INFO - 2020-12-14 07:23:30 --> Language Class Initialized
INFO - 2020-12-14 07:23:30 --> Language Class Initialized
INFO - 2020-12-14 07:23:30 --> Config Class Initialized
INFO - 2020-12-14 07:23:31 --> Loader Class Initialized
INFO - 2020-12-14 07:23:31 --> Helper loaded: url_helper
INFO - 2020-12-14 07:23:31 --> Helper loaded: file_helper
INFO - 2020-12-14 07:23:31 --> Helper loaded: form_helper
INFO - 2020-12-14 07:23:31 --> Helper loaded: my_helper
INFO - 2020-12-14 07:23:31 --> Database Driver Class Initialized
DEBUG - 2020-12-14 07:23:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-14 07:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-14 07:23:31 --> Controller Class Initialized
DEBUG - 2020-12-14 07:23:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2020-12-14 07:23:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-14 07:23:31 --> Final output sent to browser
DEBUG - 2020-12-14 07:23:31 --> Total execution time: 0.6179
INFO - 2020-12-14 07:42:17 --> Config Class Initialized
INFO - 2020-12-14 07:42:17 --> Hooks Class Initialized
DEBUG - 2020-12-14 07:42:17 --> UTF-8 Support Enabled
INFO - 2020-12-14 07:42:17 --> Utf8 Class Initialized
INFO - 2020-12-14 07:42:17 --> URI Class Initialized
INFO - 2020-12-14 07:42:17 --> Router Class Initialized
INFO - 2020-12-14 07:42:17 --> Output Class Initialized
INFO - 2020-12-14 07:42:17 --> Security Class Initialized
DEBUG - 2020-12-14 07:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-14 07:42:17 --> Input Class Initialized
INFO - 2020-12-14 07:42:17 --> Language Class Initialized
INFO - 2020-12-14 07:42:17 --> Language Class Initialized
INFO - 2020-12-14 07:42:17 --> Config Class Initialized
INFO - 2020-12-14 07:42:17 --> Loader Class Initialized
INFO - 2020-12-14 07:42:17 --> Helper loaded: url_helper
INFO - 2020-12-14 07:42:17 --> Helper loaded: file_helper
INFO - 2020-12-14 07:42:17 --> Helper loaded: form_helper
INFO - 2020-12-14 07:42:17 --> Helper loaded: my_helper
INFO - 2020-12-14 07:42:17 --> Database Driver Class Initialized
DEBUG - 2020-12-14 07:42:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-14 07:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-14 07:42:17 --> Controller Class Initialized
INFO - 2020-12-14 07:42:18 --> Final output sent to browser
DEBUG - 2020-12-14 07:42:18 --> Total execution time: 1.5202
INFO - 2020-12-14 07:43:52 --> Config Class Initialized
INFO - 2020-12-14 07:43:52 --> Hooks Class Initialized
DEBUG - 2020-12-14 07:43:52 --> UTF-8 Support Enabled
INFO - 2020-12-14 07:43:52 --> Utf8 Class Initialized
INFO - 2020-12-14 07:43:52 --> URI Class Initialized
INFO - 2020-12-14 07:43:52 --> Router Class Initialized
INFO - 2020-12-14 07:43:52 --> Output Class Initialized
INFO - 2020-12-14 07:43:52 --> Security Class Initialized
DEBUG - 2020-12-14 07:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-14 07:43:52 --> Input Class Initialized
INFO - 2020-12-14 07:43:52 --> Language Class Initialized
INFO - 2020-12-14 07:43:52 --> Language Class Initialized
INFO - 2020-12-14 07:43:52 --> Config Class Initialized
INFO - 2020-12-14 07:43:52 --> Loader Class Initialized
INFO - 2020-12-14 07:43:52 --> Helper loaded: url_helper
INFO - 2020-12-14 07:43:52 --> Helper loaded: file_helper
INFO - 2020-12-14 07:43:52 --> Helper loaded: form_helper
INFO - 2020-12-14 07:43:52 --> Helper loaded: my_helper
INFO - 2020-12-14 07:43:52 --> Database Driver Class Initialized
DEBUG - 2020-12-14 07:43:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-14 07:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-14 07:43:52 --> Controller Class Initialized
DEBUG - 2020-12-14 07:43:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2020-12-14 07:43:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-14 07:43:52 --> Final output sent to browser
DEBUG - 2020-12-14 07:43:52 --> Total execution time: 0.2459
INFO - 2020-12-14 07:44:00 --> Config Class Initialized
INFO - 2020-12-14 07:44:00 --> Hooks Class Initialized
DEBUG - 2020-12-14 07:44:01 --> UTF-8 Support Enabled
INFO - 2020-12-14 07:44:01 --> Utf8 Class Initialized
INFO - 2020-12-14 07:44:01 --> URI Class Initialized
INFO - 2020-12-14 07:44:01 --> Router Class Initialized
INFO - 2020-12-14 07:44:01 --> Output Class Initialized
INFO - 2020-12-14 07:44:01 --> Security Class Initialized
DEBUG - 2020-12-14 07:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-14 07:44:01 --> Input Class Initialized
INFO - 2020-12-14 07:44:01 --> Language Class Initialized
INFO - 2020-12-14 07:44:01 --> Language Class Initialized
INFO - 2020-12-14 07:44:01 --> Config Class Initialized
INFO - 2020-12-14 07:44:01 --> Loader Class Initialized
INFO - 2020-12-14 07:44:01 --> Helper loaded: url_helper
INFO - 2020-12-14 07:44:01 --> Helper loaded: file_helper
INFO - 2020-12-14 07:44:01 --> Helper loaded: form_helper
INFO - 2020-12-14 07:44:01 --> Helper loaded: my_helper
INFO - 2020-12-14 07:44:01 --> Database Driver Class Initialized
DEBUG - 2020-12-14 07:44:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-14 07:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-14 07:44:01 --> Controller Class Initialized
DEBUG - 2020-12-14 07:44:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2020-12-14 07:44:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-14 07:44:01 --> Final output sent to browser
DEBUG - 2020-12-14 07:44:01 --> Total execution time: 0.2361
INFO - 2020-12-14 07:44:32 --> Config Class Initialized
INFO - 2020-12-14 07:44:32 --> Hooks Class Initialized
DEBUG - 2020-12-14 07:44:32 --> UTF-8 Support Enabled
INFO - 2020-12-14 07:44:32 --> Utf8 Class Initialized
INFO - 2020-12-14 07:44:32 --> URI Class Initialized
INFO - 2020-12-14 07:44:32 --> Router Class Initialized
INFO - 2020-12-14 07:44:32 --> Output Class Initialized
INFO - 2020-12-14 07:44:32 --> Security Class Initialized
DEBUG - 2020-12-14 07:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-14 07:44:32 --> Input Class Initialized
INFO - 2020-12-14 07:44:32 --> Language Class Initialized
INFO - 2020-12-14 07:44:32 --> Language Class Initialized
INFO - 2020-12-14 07:44:32 --> Config Class Initialized
INFO - 2020-12-14 07:44:32 --> Loader Class Initialized
INFO - 2020-12-14 07:44:32 --> Helper loaded: url_helper
INFO - 2020-12-14 07:44:32 --> Helper loaded: file_helper
INFO - 2020-12-14 07:44:32 --> Helper loaded: form_helper
INFO - 2020-12-14 07:44:32 --> Helper loaded: my_helper
INFO - 2020-12-14 07:44:32 --> Database Driver Class Initialized
DEBUG - 2020-12-14 07:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-14 07:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-14 07:44:32 --> Controller Class Initialized
INFO - 2020-12-14 07:44:33 --> Final output sent to browser
DEBUG - 2020-12-14 07:44:33 --> Total execution time: 1.5173
INFO - 2020-12-14 07:46:06 --> Config Class Initialized
INFO - 2020-12-14 07:46:06 --> Hooks Class Initialized
DEBUG - 2020-12-14 07:46:06 --> UTF-8 Support Enabled
INFO - 2020-12-14 07:46:06 --> Utf8 Class Initialized
INFO - 2020-12-14 07:46:06 --> URI Class Initialized
INFO - 2020-12-14 07:46:06 --> Router Class Initialized
INFO - 2020-12-14 07:46:06 --> Output Class Initialized
INFO - 2020-12-14 07:46:06 --> Security Class Initialized
DEBUG - 2020-12-14 07:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-14 07:46:06 --> Input Class Initialized
INFO - 2020-12-14 07:46:06 --> Language Class Initialized
INFO - 2020-12-14 07:46:06 --> Language Class Initialized
INFO - 2020-12-14 07:46:06 --> Config Class Initialized
INFO - 2020-12-14 07:46:06 --> Loader Class Initialized
INFO - 2020-12-14 07:46:06 --> Helper loaded: url_helper
INFO - 2020-12-14 07:46:06 --> Helper loaded: file_helper
INFO - 2020-12-14 07:46:06 --> Helper loaded: form_helper
INFO - 2020-12-14 07:46:06 --> Helper loaded: my_helper
INFO - 2020-12-14 07:46:06 --> Database Driver Class Initialized
DEBUG - 2020-12-14 07:46:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-14 07:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-14 07:46:06 --> Controller Class Initialized
DEBUG - 2020-12-14 07:46:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2020-12-14 07:46:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-14 07:46:06 --> Final output sent to browser
DEBUG - 2020-12-14 07:46:06 --> Total execution time: 0.2577
INFO - 2020-12-14 07:46:12 --> Config Class Initialized
INFO - 2020-12-14 07:46:12 --> Hooks Class Initialized
DEBUG - 2020-12-14 07:46:12 --> UTF-8 Support Enabled
INFO - 2020-12-14 07:46:12 --> Utf8 Class Initialized
INFO - 2020-12-14 07:46:12 --> URI Class Initialized
INFO - 2020-12-14 07:46:12 --> Router Class Initialized
INFO - 2020-12-14 07:46:12 --> Output Class Initialized
INFO - 2020-12-14 07:46:12 --> Security Class Initialized
DEBUG - 2020-12-14 07:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-14 07:46:12 --> Input Class Initialized
INFO - 2020-12-14 07:46:12 --> Language Class Initialized
INFO - 2020-12-14 07:46:12 --> Language Class Initialized
INFO - 2020-12-14 07:46:12 --> Config Class Initialized
INFO - 2020-12-14 07:46:12 --> Loader Class Initialized
INFO - 2020-12-14 07:46:12 --> Helper loaded: url_helper
INFO - 2020-12-14 07:46:12 --> Helper loaded: file_helper
INFO - 2020-12-14 07:46:12 --> Helper loaded: form_helper
INFO - 2020-12-14 07:46:12 --> Helper loaded: my_helper
INFO - 2020-12-14 07:46:12 --> Database Driver Class Initialized
DEBUG - 2020-12-14 07:46:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-14 07:46:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-14 07:46:12 --> Controller Class Initialized
INFO - 2020-12-14 07:46:13 --> Final output sent to browser
DEBUG - 2020-12-14 07:46:13 --> Total execution time: 1.3934
INFO - 2020-12-14 07:46:37 --> Config Class Initialized
INFO - 2020-12-14 07:46:37 --> Hooks Class Initialized
DEBUG - 2020-12-14 07:46:37 --> UTF-8 Support Enabled
INFO - 2020-12-14 07:46:37 --> Utf8 Class Initialized
INFO - 2020-12-14 07:46:37 --> URI Class Initialized
INFO - 2020-12-14 07:46:37 --> Router Class Initialized
INFO - 2020-12-14 07:46:37 --> Output Class Initialized
INFO - 2020-12-14 07:46:37 --> Security Class Initialized
DEBUG - 2020-12-14 07:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-14 07:46:37 --> Input Class Initialized
INFO - 2020-12-14 07:46:37 --> Language Class Initialized
INFO - 2020-12-14 07:46:37 --> Language Class Initialized
INFO - 2020-12-14 07:46:37 --> Config Class Initialized
INFO - 2020-12-14 07:46:37 --> Loader Class Initialized
INFO - 2020-12-14 07:46:37 --> Helper loaded: url_helper
INFO - 2020-12-14 07:46:37 --> Helper loaded: file_helper
INFO - 2020-12-14 07:46:37 --> Helper loaded: form_helper
INFO - 2020-12-14 07:46:37 --> Helper loaded: my_helper
INFO - 2020-12-14 07:46:37 --> Database Driver Class Initialized
DEBUG - 2020-12-14 07:46:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-14 07:46:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-14 07:46:37 --> Controller Class Initialized
DEBUG - 2020-12-14 07:46:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2020-12-14 07:46:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-14 07:46:37 --> Final output sent to browser
DEBUG - 2020-12-14 07:46:37 --> Total execution time: 0.2649
INFO - 2020-12-14 07:46:40 --> Config Class Initialized
INFO - 2020-12-14 07:46:40 --> Hooks Class Initialized
DEBUG - 2020-12-14 07:46:40 --> UTF-8 Support Enabled
INFO - 2020-12-14 07:46:40 --> Utf8 Class Initialized
INFO - 2020-12-14 07:46:40 --> URI Class Initialized
INFO - 2020-12-14 07:46:40 --> Router Class Initialized
INFO - 2020-12-14 07:46:40 --> Output Class Initialized
INFO - 2020-12-14 07:46:40 --> Security Class Initialized
DEBUG - 2020-12-14 07:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-14 07:46:40 --> Input Class Initialized
INFO - 2020-12-14 07:46:40 --> Language Class Initialized
INFO - 2020-12-14 07:46:40 --> Language Class Initialized
INFO - 2020-12-14 07:46:40 --> Config Class Initialized
INFO - 2020-12-14 07:46:40 --> Loader Class Initialized
INFO - 2020-12-14 07:46:40 --> Helper loaded: url_helper
INFO - 2020-12-14 07:46:40 --> Helper loaded: file_helper
INFO - 2020-12-14 07:46:40 --> Helper loaded: form_helper
INFO - 2020-12-14 07:46:40 --> Helper loaded: my_helper
INFO - 2020-12-14 07:46:40 --> Database Driver Class Initialized
DEBUG - 2020-12-14 07:46:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-14 07:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-14 07:46:40 --> Controller Class Initialized
DEBUG - 2020-12-14 07:46:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-12-14 07:46:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-14 07:46:41 --> Final output sent to browser
DEBUG - 2020-12-14 07:46:41 --> Total execution time: 0.3218
INFO - 2020-12-14 07:46:42 --> Config Class Initialized
INFO - 2020-12-14 07:46:42 --> Hooks Class Initialized
DEBUG - 2020-12-14 07:46:42 --> UTF-8 Support Enabled
INFO - 2020-12-14 07:46:42 --> Utf8 Class Initialized
INFO - 2020-12-14 07:46:42 --> URI Class Initialized
INFO - 2020-12-14 07:46:42 --> Router Class Initialized
INFO - 2020-12-14 07:46:42 --> Output Class Initialized
INFO - 2020-12-14 07:46:42 --> Security Class Initialized
DEBUG - 2020-12-14 07:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-14 07:46:42 --> Input Class Initialized
INFO - 2020-12-14 07:46:42 --> Language Class Initialized
INFO - 2020-12-14 07:46:42 --> Language Class Initialized
INFO - 2020-12-14 07:46:42 --> Config Class Initialized
INFO - 2020-12-14 07:46:42 --> Loader Class Initialized
INFO - 2020-12-14 07:46:42 --> Helper loaded: url_helper
INFO - 2020-12-14 07:46:42 --> Helper loaded: file_helper
INFO - 2020-12-14 07:46:42 --> Helper loaded: form_helper
INFO - 2020-12-14 07:46:42 --> Helper loaded: my_helper
INFO - 2020-12-14 07:46:42 --> Database Driver Class Initialized
DEBUG - 2020-12-14 07:46:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-14 07:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-14 07:46:42 --> Controller Class Initialized
DEBUG - 2020-12-14 07:46:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2020-12-14 07:46:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-14 07:46:42 --> Final output sent to browser
DEBUG - 2020-12-14 07:46:42 --> Total execution time: 0.2272
INFO - 2020-12-14 07:47:14 --> Config Class Initialized
INFO - 2020-12-14 07:47:14 --> Hooks Class Initialized
DEBUG - 2020-12-14 07:47:14 --> UTF-8 Support Enabled
INFO - 2020-12-14 07:47:14 --> Utf8 Class Initialized
INFO - 2020-12-14 07:47:14 --> URI Class Initialized
INFO - 2020-12-14 07:47:14 --> Router Class Initialized
INFO - 2020-12-14 07:47:14 --> Output Class Initialized
INFO - 2020-12-14 07:47:14 --> Security Class Initialized
DEBUG - 2020-12-14 07:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-14 07:47:14 --> Input Class Initialized
INFO - 2020-12-14 07:47:14 --> Language Class Initialized
INFO - 2020-12-14 07:47:14 --> Language Class Initialized
INFO - 2020-12-14 07:47:14 --> Config Class Initialized
INFO - 2020-12-14 07:47:14 --> Loader Class Initialized
INFO - 2020-12-14 07:47:14 --> Helper loaded: url_helper
INFO - 2020-12-14 07:47:14 --> Helper loaded: file_helper
INFO - 2020-12-14 07:47:14 --> Helper loaded: form_helper
INFO - 2020-12-14 07:47:14 --> Helper loaded: my_helper
INFO - 2020-12-14 07:47:14 --> Database Driver Class Initialized
DEBUG - 2020-12-14 07:47:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-14 07:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-14 07:47:14 --> Controller Class Initialized
DEBUG - 2020-12-14 07:47:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2020-12-14 07:47:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-14 07:47:14 --> Final output sent to browser
DEBUG - 2020-12-14 07:47:14 --> Total execution time: 0.2322
