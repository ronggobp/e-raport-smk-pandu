<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-10-19 02:25:43 --> Config Class Initialized
INFO - 2020-10-19 02:25:43 --> Hooks Class Initialized
DEBUG - 2020-10-19 02:25:43 --> UTF-8 Support Enabled
INFO - 2020-10-19 02:25:44 --> Utf8 Class Initialized
INFO - 2020-10-19 02:25:44 --> URI Class Initialized
DEBUG - 2020-10-19 02:25:44 --> No URI present. Default controller set.
INFO - 2020-10-19 02:25:44 --> Router Class Initialized
INFO - 2020-10-19 02:25:44 --> Output Class Initialized
INFO - 2020-10-19 02:25:44 --> Security Class Initialized
DEBUG - 2020-10-19 02:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 02:25:44 --> Input Class Initialized
INFO - 2020-10-19 02:25:44 --> Language Class Initialized
INFO - 2020-10-19 02:25:44 --> Language Class Initialized
INFO - 2020-10-19 02:25:44 --> Config Class Initialized
INFO - 2020-10-19 02:25:44 --> Loader Class Initialized
INFO - 2020-10-19 02:25:44 --> Helper loaded: url_helper
INFO - 2020-10-19 02:25:44 --> Helper loaded: file_helper
INFO - 2020-10-19 02:25:44 --> Helper loaded: form_helper
INFO - 2020-10-19 02:25:44 --> Helper loaded: my_helper
INFO - 2020-10-19 02:25:44 --> Database Driver Class Initialized
DEBUG - 2020-10-19 02:25:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 02:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 02:25:44 --> Controller Class Initialized
INFO - 2020-10-19 02:25:44 --> Config Class Initialized
INFO - 2020-10-19 02:25:44 --> Hooks Class Initialized
DEBUG - 2020-10-19 02:25:44 --> UTF-8 Support Enabled
INFO - 2020-10-19 02:25:44 --> Utf8 Class Initialized
INFO - 2020-10-19 02:25:44 --> URI Class Initialized
INFO - 2020-10-19 02:25:44 --> Router Class Initialized
INFO - 2020-10-19 02:25:44 --> Output Class Initialized
INFO - 2020-10-19 02:25:44 --> Security Class Initialized
DEBUG - 2020-10-19 02:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 02:25:44 --> Input Class Initialized
INFO - 2020-10-19 02:25:44 --> Language Class Initialized
INFO - 2020-10-19 02:25:44 --> Language Class Initialized
INFO - 2020-10-19 02:25:44 --> Config Class Initialized
INFO - 2020-10-19 02:25:44 --> Loader Class Initialized
INFO - 2020-10-19 02:25:44 --> Helper loaded: url_helper
INFO - 2020-10-19 02:25:44 --> Helper loaded: file_helper
INFO - 2020-10-19 02:25:44 --> Helper loaded: form_helper
INFO - 2020-10-19 02:25:44 --> Helper loaded: my_helper
INFO - 2020-10-19 02:25:44 --> Database Driver Class Initialized
DEBUG - 2020-10-19 02:25:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 02:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 02:25:44 --> Controller Class Initialized
DEBUG - 2020-10-19 02:25:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-19 02:25:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-19 02:25:44 --> Final output sent to browser
DEBUG - 2020-10-19 02:25:44 --> Total execution time: 0.3271
INFO - 2020-10-19 02:40:50 --> Config Class Initialized
INFO - 2020-10-19 02:40:50 --> Hooks Class Initialized
DEBUG - 2020-10-19 02:40:50 --> UTF-8 Support Enabled
INFO - 2020-10-19 02:40:50 --> Utf8 Class Initialized
INFO - 2020-10-19 02:40:50 --> URI Class Initialized
INFO - 2020-10-19 02:40:50 --> Router Class Initialized
INFO - 2020-10-19 02:40:51 --> Output Class Initialized
INFO - 2020-10-19 02:40:51 --> Security Class Initialized
DEBUG - 2020-10-19 02:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 02:40:51 --> Input Class Initialized
INFO - 2020-10-19 02:40:51 --> Language Class Initialized
INFO - 2020-10-19 02:40:51 --> Language Class Initialized
INFO - 2020-10-19 02:40:51 --> Config Class Initialized
INFO - 2020-10-19 02:40:51 --> Loader Class Initialized
INFO - 2020-10-19 02:40:51 --> Helper loaded: url_helper
INFO - 2020-10-19 02:40:51 --> Helper loaded: file_helper
INFO - 2020-10-19 02:40:51 --> Helper loaded: form_helper
INFO - 2020-10-19 02:40:51 --> Helper loaded: my_helper
INFO - 2020-10-19 02:40:51 --> Database Driver Class Initialized
DEBUG - 2020-10-19 02:40:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 02:40:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 02:40:51 --> Controller Class Initialized
INFO - 2020-10-19 02:40:51 --> Helper loaded: cookie_helper
INFO - 2020-10-19 02:40:51 --> Final output sent to browser
DEBUG - 2020-10-19 02:40:51 --> Total execution time: 0.8753
INFO - 2020-10-19 02:40:56 --> Config Class Initialized
INFO - 2020-10-19 02:40:56 --> Hooks Class Initialized
DEBUG - 2020-10-19 02:40:56 --> UTF-8 Support Enabled
INFO - 2020-10-19 02:40:56 --> Utf8 Class Initialized
INFO - 2020-10-19 02:40:56 --> URI Class Initialized
INFO - 2020-10-19 02:40:56 --> Router Class Initialized
INFO - 2020-10-19 02:40:56 --> Output Class Initialized
INFO - 2020-10-19 02:40:56 --> Security Class Initialized
DEBUG - 2020-10-19 02:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 02:40:56 --> Input Class Initialized
INFO - 2020-10-19 02:40:56 --> Language Class Initialized
INFO - 2020-10-19 02:40:56 --> Language Class Initialized
INFO - 2020-10-19 02:40:56 --> Config Class Initialized
INFO - 2020-10-19 02:40:56 --> Loader Class Initialized
INFO - 2020-10-19 02:40:56 --> Helper loaded: url_helper
INFO - 2020-10-19 02:40:56 --> Helper loaded: file_helper
INFO - 2020-10-19 02:40:56 --> Helper loaded: form_helper
INFO - 2020-10-19 02:40:56 --> Helper loaded: my_helper
INFO - 2020-10-19 02:40:56 --> Database Driver Class Initialized
DEBUG - 2020-10-19 02:40:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 02:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 02:40:56 --> Controller Class Initialized
DEBUG - 2020-10-19 02:40:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-19 02:40:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-19 02:40:56 --> Final output sent to browser
DEBUG - 2020-10-19 02:40:56 --> Total execution time: 0.4514
INFO - 2020-10-19 02:40:59 --> Config Class Initialized
INFO - 2020-10-19 02:40:59 --> Hooks Class Initialized
DEBUG - 2020-10-19 02:40:59 --> UTF-8 Support Enabled
INFO - 2020-10-19 02:40:59 --> Utf8 Class Initialized
INFO - 2020-10-19 02:40:59 --> URI Class Initialized
INFO - 2020-10-19 02:40:59 --> Router Class Initialized
INFO - 2020-10-19 02:40:59 --> Output Class Initialized
INFO - 2020-10-19 02:40:59 --> Security Class Initialized
DEBUG - 2020-10-19 02:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 02:40:59 --> Input Class Initialized
INFO - 2020-10-19 02:40:59 --> Language Class Initialized
INFO - 2020-10-19 02:40:59 --> Language Class Initialized
INFO - 2020-10-19 02:40:59 --> Config Class Initialized
INFO - 2020-10-19 02:40:59 --> Loader Class Initialized
INFO - 2020-10-19 02:40:59 --> Helper loaded: url_helper
INFO - 2020-10-19 02:40:59 --> Helper loaded: file_helper
INFO - 2020-10-19 02:40:59 --> Helper loaded: form_helper
INFO - 2020-10-19 02:40:59 --> Helper loaded: my_helper
INFO - 2020-10-19 02:40:59 --> Database Driver Class Initialized
DEBUG - 2020-10-19 02:40:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 02:40:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 02:40:59 --> Controller Class Initialized
DEBUG - 2020-10-19 02:40:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2020-10-19 02:40:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-19 02:40:59 --> Final output sent to browser
DEBUG - 2020-10-19 02:40:59 --> Total execution time: 0.2373
INFO - 2020-10-19 02:40:59 --> Config Class Initialized
INFO - 2020-10-19 02:40:59 --> Hooks Class Initialized
DEBUG - 2020-10-19 02:40:59 --> UTF-8 Support Enabled
INFO - 2020-10-19 02:40:59 --> Utf8 Class Initialized
INFO - 2020-10-19 02:40:59 --> URI Class Initialized
INFO - 2020-10-19 02:40:59 --> Router Class Initialized
INFO - 2020-10-19 02:40:59 --> Output Class Initialized
INFO - 2020-10-19 02:40:59 --> Security Class Initialized
DEBUG - 2020-10-19 02:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 02:40:59 --> Input Class Initialized
INFO - 2020-10-19 02:40:59 --> Language Class Initialized
INFO - 2020-10-19 02:40:59 --> Language Class Initialized
INFO - 2020-10-19 02:40:59 --> Config Class Initialized
INFO - 2020-10-19 02:40:59 --> Loader Class Initialized
INFO - 2020-10-19 02:40:59 --> Helper loaded: url_helper
INFO - 2020-10-19 02:40:59 --> Helper loaded: file_helper
INFO - 2020-10-19 02:41:00 --> Helper loaded: form_helper
INFO - 2020-10-19 02:41:00 --> Helper loaded: my_helper
INFO - 2020-10-19 02:41:00 --> Database Driver Class Initialized
DEBUG - 2020-10-19 02:41:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 02:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 02:41:00 --> Controller Class Initialized
INFO - 2020-10-19 02:41:00 --> Config Class Initialized
INFO - 2020-10-19 02:41:00 --> Hooks Class Initialized
DEBUG - 2020-10-19 02:41:00 --> UTF-8 Support Enabled
INFO - 2020-10-19 02:41:00 --> Utf8 Class Initialized
INFO - 2020-10-19 02:41:00 --> URI Class Initialized
INFO - 2020-10-19 02:41:00 --> Router Class Initialized
INFO - 2020-10-19 02:41:00 --> Output Class Initialized
INFO - 2020-10-19 02:41:00 --> Security Class Initialized
DEBUG - 2020-10-19 02:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 02:41:00 --> Input Class Initialized
INFO - 2020-10-19 02:41:00 --> Language Class Initialized
INFO - 2020-10-19 02:41:00 --> Language Class Initialized
INFO - 2020-10-19 02:41:00 --> Config Class Initialized
INFO - 2020-10-19 02:41:00 --> Loader Class Initialized
INFO - 2020-10-19 02:41:00 --> Helper loaded: url_helper
INFO - 2020-10-19 02:41:00 --> Helper loaded: file_helper
INFO - 2020-10-19 02:41:00 --> Helper loaded: form_helper
INFO - 2020-10-19 02:41:00 --> Helper loaded: my_helper
INFO - 2020-10-19 02:41:00 --> Database Driver Class Initialized
DEBUG - 2020-10-19 02:41:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 02:41:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 02:41:01 --> Controller Class Initialized
DEBUG - 2020-10-19 02:41:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-10-19 02:41:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-19 02:41:01 --> Final output sent to browser
DEBUG - 2020-10-19 02:41:01 --> Total execution time: 0.2270
INFO - 2020-10-19 02:41:01 --> Config Class Initialized
INFO - 2020-10-19 02:41:01 --> Hooks Class Initialized
DEBUG - 2020-10-19 02:41:01 --> UTF-8 Support Enabled
INFO - 2020-10-19 02:41:01 --> Utf8 Class Initialized
INFO - 2020-10-19 02:41:01 --> URI Class Initialized
INFO - 2020-10-19 02:41:01 --> Router Class Initialized
INFO - 2020-10-19 02:41:01 --> Output Class Initialized
INFO - 2020-10-19 02:41:01 --> Security Class Initialized
DEBUG - 2020-10-19 02:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 02:41:01 --> Input Class Initialized
INFO - 2020-10-19 02:41:01 --> Language Class Initialized
INFO - 2020-10-19 02:41:01 --> Language Class Initialized
INFO - 2020-10-19 02:41:01 --> Config Class Initialized
INFO - 2020-10-19 02:41:01 --> Loader Class Initialized
INFO - 2020-10-19 02:41:01 --> Helper loaded: url_helper
INFO - 2020-10-19 02:41:01 --> Helper loaded: file_helper
INFO - 2020-10-19 02:41:01 --> Helper loaded: form_helper
INFO - 2020-10-19 02:41:01 --> Helper loaded: my_helper
INFO - 2020-10-19 02:41:01 --> Database Driver Class Initialized
DEBUG - 2020-10-19 02:41:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 02:41:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 02:41:01 --> Controller Class Initialized
INFO - 2020-10-19 02:41:09 --> Config Class Initialized
INFO - 2020-10-19 02:41:09 --> Hooks Class Initialized
DEBUG - 2020-10-19 02:41:09 --> UTF-8 Support Enabled
INFO - 2020-10-19 02:41:09 --> Utf8 Class Initialized
INFO - 2020-10-19 02:41:09 --> URI Class Initialized
INFO - 2020-10-19 02:41:09 --> Router Class Initialized
INFO - 2020-10-19 02:41:09 --> Output Class Initialized
INFO - 2020-10-19 02:41:09 --> Security Class Initialized
DEBUG - 2020-10-19 02:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 02:41:09 --> Input Class Initialized
INFO - 2020-10-19 02:41:09 --> Language Class Initialized
INFO - 2020-10-19 02:41:09 --> Language Class Initialized
INFO - 2020-10-19 02:41:09 --> Config Class Initialized
INFO - 2020-10-19 02:41:09 --> Loader Class Initialized
INFO - 2020-10-19 02:41:09 --> Helper loaded: url_helper
INFO - 2020-10-19 02:41:09 --> Helper loaded: file_helper
INFO - 2020-10-19 02:41:09 --> Helper loaded: form_helper
INFO - 2020-10-19 02:41:09 --> Helper loaded: my_helper
INFO - 2020-10-19 02:41:09 --> Database Driver Class Initialized
DEBUG - 2020-10-19 02:41:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 02:41:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 02:41:09 --> Controller Class Initialized
ERROR - 2020-10-19 02:41:09 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilai`.`t_nilai_ekstra`, CONSTRAINT `FK_t_nilai_ekstra_m_siswa` FOREIGN KEY (`id_siswa`) REFERENCES `m_siswa` (`id`)) - Invalid query: DELETE FROM m_siswa WHERE id = '338'
INFO - 2020-10-19 02:41:09 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-19 02:41:15 --> Config Class Initialized
INFO - 2020-10-19 02:41:15 --> Hooks Class Initialized
DEBUG - 2020-10-19 02:41:15 --> UTF-8 Support Enabled
INFO - 2020-10-19 02:41:15 --> Utf8 Class Initialized
INFO - 2020-10-19 02:41:15 --> URI Class Initialized
INFO - 2020-10-19 02:41:15 --> Router Class Initialized
INFO - 2020-10-19 02:41:15 --> Output Class Initialized
INFO - 2020-10-19 02:41:15 --> Security Class Initialized
DEBUG - 2020-10-19 02:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 02:41:15 --> Input Class Initialized
INFO - 2020-10-19 02:41:15 --> Language Class Initialized
INFO - 2020-10-19 02:41:15 --> Language Class Initialized
INFO - 2020-10-19 02:41:15 --> Config Class Initialized
INFO - 2020-10-19 02:41:15 --> Loader Class Initialized
INFO - 2020-10-19 02:41:15 --> Helper loaded: url_helper
INFO - 2020-10-19 02:41:15 --> Helper loaded: file_helper
INFO - 2020-10-19 02:41:15 --> Helper loaded: form_helper
INFO - 2020-10-19 02:41:15 --> Helper loaded: my_helper
INFO - 2020-10-19 02:41:15 --> Database Driver Class Initialized
DEBUG - 2020-10-19 02:41:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 02:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 02:41:15 --> Controller Class Initialized
DEBUG - 2020-10-19 02:41:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-10-19 02:41:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-19 02:41:15 --> Final output sent to browser
DEBUG - 2020-10-19 02:41:15 --> Total execution time: 0.2728
INFO - 2020-10-19 02:41:15 --> Config Class Initialized
INFO - 2020-10-19 02:41:15 --> Hooks Class Initialized
DEBUG - 2020-10-19 02:41:15 --> UTF-8 Support Enabled
INFO - 2020-10-19 02:41:15 --> Utf8 Class Initialized
INFO - 2020-10-19 02:41:15 --> URI Class Initialized
INFO - 2020-10-19 02:41:15 --> Router Class Initialized
INFO - 2020-10-19 02:41:15 --> Output Class Initialized
INFO - 2020-10-19 02:41:15 --> Security Class Initialized
DEBUG - 2020-10-19 02:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 02:41:15 --> Input Class Initialized
INFO - 2020-10-19 02:41:15 --> Language Class Initialized
INFO - 2020-10-19 02:41:15 --> Language Class Initialized
INFO - 2020-10-19 02:41:15 --> Config Class Initialized
INFO - 2020-10-19 02:41:15 --> Loader Class Initialized
INFO - 2020-10-19 02:41:15 --> Helper loaded: url_helper
INFO - 2020-10-19 02:41:15 --> Helper loaded: file_helper
INFO - 2020-10-19 02:41:15 --> Helper loaded: form_helper
INFO - 2020-10-19 02:41:15 --> Helper loaded: my_helper
INFO - 2020-10-19 02:41:15 --> Database Driver Class Initialized
DEBUG - 2020-10-19 02:41:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 02:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 02:41:15 --> Controller Class Initialized
INFO - 2020-10-19 02:41:17 --> Config Class Initialized
INFO - 2020-10-19 02:41:17 --> Hooks Class Initialized
DEBUG - 2020-10-19 02:41:17 --> UTF-8 Support Enabled
INFO - 2020-10-19 02:41:17 --> Utf8 Class Initialized
INFO - 2020-10-19 02:41:17 --> URI Class Initialized
INFO - 2020-10-19 02:41:17 --> Router Class Initialized
INFO - 2020-10-19 02:41:17 --> Output Class Initialized
INFO - 2020-10-19 02:41:17 --> Security Class Initialized
DEBUG - 2020-10-19 02:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 02:41:17 --> Input Class Initialized
INFO - 2020-10-19 02:41:17 --> Language Class Initialized
INFO - 2020-10-19 02:41:17 --> Language Class Initialized
INFO - 2020-10-19 02:41:17 --> Config Class Initialized
INFO - 2020-10-19 02:41:17 --> Loader Class Initialized
INFO - 2020-10-19 02:41:17 --> Helper loaded: url_helper
INFO - 2020-10-19 02:41:17 --> Helper loaded: file_helper
INFO - 2020-10-19 02:41:17 --> Helper loaded: form_helper
INFO - 2020-10-19 02:41:17 --> Helper loaded: my_helper
INFO - 2020-10-19 02:41:17 --> Database Driver Class Initialized
DEBUG - 2020-10-19 02:41:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 02:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 02:41:17 --> Controller Class Initialized
DEBUG - 2020-10-19 02:41:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-19 02:41:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-19 02:41:17 --> Final output sent to browser
DEBUG - 2020-10-19 02:41:17 --> Total execution time: 0.2505
INFO - 2020-10-19 02:41:17 --> Config Class Initialized
INFO - 2020-10-19 02:41:17 --> Hooks Class Initialized
DEBUG - 2020-10-19 02:41:17 --> UTF-8 Support Enabled
INFO - 2020-10-19 02:41:17 --> Utf8 Class Initialized
INFO - 2020-10-19 02:41:17 --> URI Class Initialized
INFO - 2020-10-19 02:41:17 --> Router Class Initialized
INFO - 2020-10-19 02:41:17 --> Output Class Initialized
INFO - 2020-10-19 02:41:17 --> Security Class Initialized
DEBUG - 2020-10-19 02:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 02:41:17 --> Input Class Initialized
INFO - 2020-10-19 02:41:17 --> Language Class Initialized
INFO - 2020-10-19 02:41:17 --> Language Class Initialized
INFO - 2020-10-19 02:41:17 --> Config Class Initialized
INFO - 2020-10-19 02:41:17 --> Loader Class Initialized
INFO - 2020-10-19 02:41:18 --> Helper loaded: url_helper
INFO - 2020-10-19 02:41:18 --> Helper loaded: file_helper
INFO - 2020-10-19 02:41:18 --> Helper loaded: form_helper
INFO - 2020-10-19 02:41:18 --> Helper loaded: my_helper
INFO - 2020-10-19 02:41:18 --> Database Driver Class Initialized
DEBUG - 2020-10-19 02:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 02:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 02:41:18 --> Controller Class Initialized
INFO - 2020-10-19 02:41:19 --> Config Class Initialized
INFO - 2020-10-19 02:41:19 --> Hooks Class Initialized
DEBUG - 2020-10-19 02:41:19 --> UTF-8 Support Enabled
INFO - 2020-10-19 02:41:19 --> Utf8 Class Initialized
INFO - 2020-10-19 02:41:19 --> URI Class Initialized
INFO - 2020-10-19 02:41:19 --> Router Class Initialized
INFO - 2020-10-19 02:41:19 --> Output Class Initialized
INFO - 2020-10-19 02:41:19 --> Security Class Initialized
DEBUG - 2020-10-19 02:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 02:41:19 --> Input Class Initialized
INFO - 2020-10-19 02:41:19 --> Language Class Initialized
INFO - 2020-10-19 02:41:19 --> Language Class Initialized
INFO - 2020-10-19 02:41:19 --> Config Class Initialized
INFO - 2020-10-19 02:41:19 --> Loader Class Initialized
INFO - 2020-10-19 02:41:19 --> Helper loaded: url_helper
INFO - 2020-10-19 02:41:19 --> Helper loaded: file_helper
INFO - 2020-10-19 02:41:19 --> Helper loaded: form_helper
INFO - 2020-10-19 02:41:19 --> Helper loaded: my_helper
INFO - 2020-10-19 02:41:19 --> Database Driver Class Initialized
DEBUG - 2020-10-19 02:41:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 02:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 02:41:19 --> Controller Class Initialized
DEBUG - 2020-10-19 02:41:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_ekstra/views/list.php
DEBUG - 2020-10-19 02:41:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-19 02:41:19 --> Final output sent to browser
DEBUG - 2020-10-19 02:41:19 --> Total execution time: 0.2479
INFO - 2020-10-19 02:41:19 --> Config Class Initialized
INFO - 2020-10-19 02:41:19 --> Hooks Class Initialized
DEBUG - 2020-10-19 02:41:19 --> UTF-8 Support Enabled
INFO - 2020-10-19 02:41:19 --> Utf8 Class Initialized
INFO - 2020-10-19 02:41:19 --> URI Class Initialized
INFO - 2020-10-19 02:41:19 --> Router Class Initialized
INFO - 2020-10-19 02:41:19 --> Output Class Initialized
INFO - 2020-10-19 02:41:19 --> Security Class Initialized
DEBUG - 2020-10-19 02:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 02:41:19 --> Input Class Initialized
INFO - 2020-10-19 02:41:19 --> Language Class Initialized
INFO - 2020-10-19 02:41:19 --> Language Class Initialized
INFO - 2020-10-19 02:41:19 --> Config Class Initialized
INFO - 2020-10-19 02:41:19 --> Loader Class Initialized
INFO - 2020-10-19 02:41:19 --> Helper loaded: url_helper
INFO - 2020-10-19 02:41:19 --> Helper loaded: file_helper
INFO - 2020-10-19 02:41:19 --> Helper loaded: form_helper
INFO - 2020-10-19 02:41:19 --> Helper loaded: my_helper
INFO - 2020-10-19 02:41:19 --> Database Driver Class Initialized
DEBUG - 2020-10-19 02:41:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 02:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 02:41:19 --> Controller Class Initialized
INFO - 2020-10-19 02:41:23 --> Config Class Initialized
INFO - 2020-10-19 02:41:23 --> Hooks Class Initialized
DEBUG - 2020-10-19 02:41:23 --> UTF-8 Support Enabled
INFO - 2020-10-19 02:41:23 --> Utf8 Class Initialized
INFO - 2020-10-19 02:41:23 --> URI Class Initialized
INFO - 2020-10-19 02:41:23 --> Router Class Initialized
INFO - 2020-10-19 02:41:23 --> Output Class Initialized
INFO - 2020-10-19 02:41:23 --> Security Class Initialized
DEBUG - 2020-10-19 02:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 02:41:23 --> Input Class Initialized
INFO - 2020-10-19 02:41:23 --> Language Class Initialized
INFO - 2020-10-19 02:41:23 --> Language Class Initialized
INFO - 2020-10-19 02:41:23 --> Config Class Initialized
INFO - 2020-10-19 02:41:23 --> Loader Class Initialized
INFO - 2020-10-19 02:41:23 --> Helper loaded: url_helper
INFO - 2020-10-19 02:41:23 --> Helper loaded: file_helper
INFO - 2020-10-19 02:41:23 --> Helper loaded: form_helper
INFO - 2020-10-19 02:41:23 --> Helper loaded: my_helper
INFO - 2020-10-19 02:41:23 --> Database Driver Class Initialized
DEBUG - 2020-10-19 02:41:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 02:41:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 02:41:23 --> Controller Class Initialized
DEBUG - 2020-10-19 02:41:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2020-10-19 02:41:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-19 02:41:23 --> Final output sent to browser
DEBUG - 2020-10-19 02:41:23 --> Total execution time: 0.2663
INFO - 2020-10-19 02:41:23 --> Config Class Initialized
INFO - 2020-10-19 02:41:23 --> Hooks Class Initialized
DEBUG - 2020-10-19 02:41:23 --> UTF-8 Support Enabled
INFO - 2020-10-19 02:41:23 --> Utf8 Class Initialized
INFO - 2020-10-19 02:41:23 --> URI Class Initialized
INFO - 2020-10-19 02:41:23 --> Router Class Initialized
INFO - 2020-10-19 02:41:23 --> Output Class Initialized
INFO - 2020-10-19 02:41:23 --> Security Class Initialized
DEBUG - 2020-10-19 02:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 02:41:23 --> Input Class Initialized
INFO - 2020-10-19 02:41:23 --> Language Class Initialized
INFO - 2020-10-19 02:41:23 --> Language Class Initialized
INFO - 2020-10-19 02:41:24 --> Config Class Initialized
INFO - 2020-10-19 02:41:24 --> Loader Class Initialized
INFO - 2020-10-19 02:41:24 --> Helper loaded: url_helper
INFO - 2020-10-19 02:41:24 --> Helper loaded: file_helper
INFO - 2020-10-19 02:41:24 --> Helper loaded: form_helper
INFO - 2020-10-19 02:41:24 --> Helper loaded: my_helper
INFO - 2020-10-19 02:41:24 --> Database Driver Class Initialized
DEBUG - 2020-10-19 02:41:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 02:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 02:41:24 --> Controller Class Initialized
INFO - 2020-10-19 02:41:25 --> Config Class Initialized
INFO - 2020-10-19 02:41:25 --> Hooks Class Initialized
DEBUG - 2020-10-19 02:41:25 --> UTF-8 Support Enabled
INFO - 2020-10-19 02:41:25 --> Utf8 Class Initialized
INFO - 2020-10-19 02:41:25 --> URI Class Initialized
INFO - 2020-10-19 02:41:25 --> Router Class Initialized
INFO - 2020-10-19 02:41:25 --> Output Class Initialized
INFO - 2020-10-19 02:41:25 --> Security Class Initialized
DEBUG - 2020-10-19 02:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 02:41:25 --> Input Class Initialized
INFO - 2020-10-19 02:41:25 --> Language Class Initialized
INFO - 2020-10-19 02:41:25 --> Language Class Initialized
INFO - 2020-10-19 02:41:25 --> Config Class Initialized
INFO - 2020-10-19 02:41:25 --> Loader Class Initialized
INFO - 2020-10-19 02:41:25 --> Helper loaded: url_helper
INFO - 2020-10-19 02:41:25 --> Helper loaded: file_helper
INFO - 2020-10-19 02:41:25 --> Helper loaded: form_helper
INFO - 2020-10-19 02:41:25 --> Helper loaded: my_helper
INFO - 2020-10-19 02:41:25 --> Database Driver Class Initialized
DEBUG - 2020-10-19 02:41:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 02:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 02:41:25 --> Controller Class Initialized
DEBUG - 2020-10-19 02:41:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-10-19 02:41:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-19 02:41:25 --> Final output sent to browser
DEBUG - 2020-10-19 02:41:25 --> Total execution time: 0.2776
INFO - 2020-10-19 02:41:28 --> Config Class Initialized
INFO - 2020-10-19 02:41:28 --> Hooks Class Initialized
DEBUG - 2020-10-19 02:41:28 --> UTF-8 Support Enabled
INFO - 2020-10-19 02:41:28 --> Utf8 Class Initialized
INFO - 2020-10-19 02:41:28 --> URI Class Initialized
INFO - 2020-10-19 02:41:28 --> Router Class Initialized
INFO - 2020-10-19 02:41:28 --> Output Class Initialized
INFO - 2020-10-19 02:41:28 --> Security Class Initialized
DEBUG - 2020-10-19 02:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 02:41:28 --> Input Class Initialized
INFO - 2020-10-19 02:41:28 --> Language Class Initialized
INFO - 2020-10-19 02:41:28 --> Language Class Initialized
INFO - 2020-10-19 02:41:28 --> Config Class Initialized
INFO - 2020-10-19 02:41:28 --> Loader Class Initialized
INFO - 2020-10-19 02:41:28 --> Helper loaded: url_helper
INFO - 2020-10-19 02:41:28 --> Helper loaded: file_helper
INFO - 2020-10-19 02:41:28 --> Helper loaded: form_helper
INFO - 2020-10-19 02:41:28 --> Helper loaded: my_helper
INFO - 2020-10-19 02:41:28 --> Database Driver Class Initialized
DEBUG - 2020-10-19 02:41:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 02:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 02:41:28 --> Controller Class Initialized
DEBUG - 2020-10-19 02:41:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-10-19 02:41:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-19 02:41:28 --> Final output sent to browser
DEBUG - 2020-10-19 02:41:28 --> Total execution time: 0.2659
INFO - 2020-10-19 02:41:28 --> Config Class Initialized
INFO - 2020-10-19 02:41:28 --> Hooks Class Initialized
DEBUG - 2020-10-19 02:41:28 --> UTF-8 Support Enabled
INFO - 2020-10-19 02:41:28 --> Utf8 Class Initialized
INFO - 2020-10-19 02:41:28 --> URI Class Initialized
INFO - 2020-10-19 02:41:28 --> Router Class Initialized
INFO - 2020-10-19 02:41:28 --> Output Class Initialized
INFO - 2020-10-19 02:41:28 --> Security Class Initialized
DEBUG - 2020-10-19 02:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 02:41:28 --> Input Class Initialized
INFO - 2020-10-19 02:41:28 --> Language Class Initialized
INFO - 2020-10-19 02:41:28 --> Language Class Initialized
INFO - 2020-10-19 02:41:28 --> Config Class Initialized
INFO - 2020-10-19 02:41:28 --> Loader Class Initialized
INFO - 2020-10-19 02:41:28 --> Helper loaded: url_helper
INFO - 2020-10-19 02:41:28 --> Helper loaded: file_helper
INFO - 2020-10-19 02:41:28 --> Helper loaded: form_helper
INFO - 2020-10-19 02:41:28 --> Helper loaded: my_helper
INFO - 2020-10-19 02:41:28 --> Database Driver Class Initialized
DEBUG - 2020-10-19 02:41:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 02:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 02:41:28 --> Controller Class Initialized
INFO - 2020-10-19 02:41:29 --> Config Class Initialized
INFO - 2020-10-19 02:41:29 --> Hooks Class Initialized
DEBUG - 2020-10-19 02:41:29 --> UTF-8 Support Enabled
INFO - 2020-10-19 02:41:29 --> Utf8 Class Initialized
INFO - 2020-10-19 02:41:29 --> URI Class Initialized
INFO - 2020-10-19 02:41:29 --> Router Class Initialized
INFO - 2020-10-19 02:41:29 --> Output Class Initialized
INFO - 2020-10-19 02:41:29 --> Security Class Initialized
DEBUG - 2020-10-19 02:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 02:41:29 --> Input Class Initialized
INFO - 2020-10-19 02:41:29 --> Language Class Initialized
INFO - 2020-10-19 02:41:29 --> Language Class Initialized
INFO - 2020-10-19 02:41:29 --> Config Class Initialized
INFO - 2020-10-19 02:41:29 --> Loader Class Initialized
INFO - 2020-10-19 02:41:29 --> Helper loaded: url_helper
INFO - 2020-10-19 02:41:29 --> Helper loaded: file_helper
INFO - 2020-10-19 02:41:29 --> Helper loaded: form_helper
INFO - 2020-10-19 02:41:29 --> Helper loaded: my_helper
INFO - 2020-10-19 02:41:29 --> Database Driver Class Initialized
DEBUG - 2020-10-19 02:41:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 02:41:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 02:41:29 --> Controller Class Initialized
DEBUG - 2020-10-19 02:41:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2020-10-19 02:41:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-19 02:41:29 --> Final output sent to browser
DEBUG - 2020-10-19 02:41:29 --> Total execution time: 0.2391
INFO - 2020-10-19 02:41:29 --> Config Class Initialized
INFO - 2020-10-19 02:41:29 --> Hooks Class Initialized
DEBUG - 2020-10-19 02:41:29 --> UTF-8 Support Enabled
INFO - 2020-10-19 02:41:29 --> Utf8 Class Initialized
INFO - 2020-10-19 02:41:29 --> URI Class Initialized
INFO - 2020-10-19 02:41:29 --> Router Class Initialized
INFO - 2020-10-19 02:41:29 --> Output Class Initialized
INFO - 2020-10-19 02:41:29 --> Security Class Initialized
DEBUG - 2020-10-19 02:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 02:41:29 --> Input Class Initialized
INFO - 2020-10-19 02:41:29 --> Language Class Initialized
INFO - 2020-10-19 02:41:29 --> Language Class Initialized
INFO - 2020-10-19 02:41:29 --> Config Class Initialized
INFO - 2020-10-19 02:41:29 --> Loader Class Initialized
INFO - 2020-10-19 02:41:29 --> Helper loaded: url_helper
INFO - 2020-10-19 02:41:29 --> Helper loaded: file_helper
INFO - 2020-10-19 02:41:29 --> Helper loaded: form_helper
INFO - 2020-10-19 02:41:29 --> Helper loaded: my_helper
INFO - 2020-10-19 02:41:29 --> Database Driver Class Initialized
DEBUG - 2020-10-19 02:41:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 02:41:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 02:41:29 --> Controller Class Initialized
INFO - 2020-10-19 02:41:30 --> Config Class Initialized
INFO - 2020-10-19 02:41:30 --> Hooks Class Initialized
DEBUG - 2020-10-19 02:41:30 --> UTF-8 Support Enabled
INFO - 2020-10-19 02:41:30 --> Utf8 Class Initialized
INFO - 2020-10-19 02:41:30 --> URI Class Initialized
INFO - 2020-10-19 02:41:30 --> Router Class Initialized
INFO - 2020-10-19 02:41:30 --> Output Class Initialized
INFO - 2020-10-19 02:41:30 --> Security Class Initialized
DEBUG - 2020-10-19 02:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 02:41:30 --> Input Class Initialized
INFO - 2020-10-19 02:41:30 --> Language Class Initialized
INFO - 2020-10-19 02:41:30 --> Language Class Initialized
INFO - 2020-10-19 02:41:30 --> Config Class Initialized
INFO - 2020-10-19 02:41:30 --> Loader Class Initialized
INFO - 2020-10-19 02:41:30 --> Helper loaded: url_helper
INFO - 2020-10-19 02:41:30 --> Helper loaded: file_helper
INFO - 2020-10-19 02:41:30 --> Helper loaded: form_helper
INFO - 2020-10-19 02:41:30 --> Helper loaded: my_helper
INFO - 2020-10-19 02:41:30 --> Database Driver Class Initialized
DEBUG - 2020-10-19 02:41:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 02:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 02:41:30 --> Controller Class Initialized
DEBUG - 2020-10-19 02:41:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_ubah_password.php
DEBUG - 2020-10-19 02:41:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-19 02:41:30 --> Final output sent to browser
DEBUG - 2020-10-19 02:41:30 --> Total execution time: 0.2553
INFO - 2020-10-19 02:41:35 --> Config Class Initialized
INFO - 2020-10-19 02:41:35 --> Hooks Class Initialized
DEBUG - 2020-10-19 02:41:35 --> UTF-8 Support Enabled
INFO - 2020-10-19 02:41:35 --> Utf8 Class Initialized
INFO - 2020-10-19 02:41:35 --> URI Class Initialized
INFO - 2020-10-19 02:41:35 --> Router Class Initialized
INFO - 2020-10-19 02:41:35 --> Output Class Initialized
INFO - 2020-10-19 02:41:35 --> Security Class Initialized
DEBUG - 2020-10-19 02:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 02:41:35 --> Input Class Initialized
INFO - 2020-10-19 02:41:35 --> Language Class Initialized
INFO - 2020-10-19 02:41:35 --> Language Class Initialized
INFO - 2020-10-19 02:41:35 --> Config Class Initialized
INFO - 2020-10-19 02:41:35 --> Loader Class Initialized
INFO - 2020-10-19 02:41:35 --> Helper loaded: url_helper
INFO - 2020-10-19 02:41:35 --> Helper loaded: file_helper
INFO - 2020-10-19 02:41:35 --> Helper loaded: form_helper
INFO - 2020-10-19 02:41:35 --> Helper loaded: my_helper
INFO - 2020-10-19 02:41:35 --> Database Driver Class Initialized
DEBUG - 2020-10-19 02:41:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 02:41:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 02:41:35 --> Controller Class Initialized
DEBUG - 2020-10-19 02:41:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_ekstra/views/list.php
DEBUG - 2020-10-19 02:41:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-19 02:41:35 --> Final output sent to browser
DEBUG - 2020-10-19 02:41:35 --> Total execution time: 0.2201
INFO - 2020-10-19 02:41:35 --> Config Class Initialized
INFO - 2020-10-19 02:41:35 --> Hooks Class Initialized
DEBUG - 2020-10-19 02:41:35 --> UTF-8 Support Enabled
INFO - 2020-10-19 02:41:35 --> Utf8 Class Initialized
INFO - 2020-10-19 02:41:35 --> URI Class Initialized
INFO - 2020-10-19 02:41:35 --> Router Class Initialized
INFO - 2020-10-19 02:41:35 --> Output Class Initialized
INFO - 2020-10-19 02:41:35 --> Security Class Initialized
DEBUG - 2020-10-19 02:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 02:41:35 --> Input Class Initialized
INFO - 2020-10-19 02:41:35 --> Language Class Initialized
INFO - 2020-10-19 02:41:35 --> Language Class Initialized
INFO - 2020-10-19 02:41:35 --> Config Class Initialized
INFO - 2020-10-19 02:41:35 --> Loader Class Initialized
INFO - 2020-10-19 02:41:35 --> Helper loaded: url_helper
INFO - 2020-10-19 02:41:35 --> Helper loaded: file_helper
INFO - 2020-10-19 02:41:35 --> Helper loaded: form_helper
INFO - 2020-10-19 02:41:35 --> Helper loaded: my_helper
INFO - 2020-10-19 02:41:35 --> Database Driver Class Initialized
DEBUG - 2020-10-19 02:41:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 02:41:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 02:41:35 --> Controller Class Initialized
INFO - 2020-10-19 02:52:24 --> Config Class Initialized
INFO - 2020-10-19 02:52:24 --> Hooks Class Initialized
DEBUG - 2020-10-19 02:52:24 --> UTF-8 Support Enabled
INFO - 2020-10-19 02:52:24 --> Utf8 Class Initialized
INFO - 2020-10-19 02:52:24 --> URI Class Initialized
INFO - 2020-10-19 02:52:24 --> Router Class Initialized
INFO - 2020-10-19 02:52:24 --> Output Class Initialized
INFO - 2020-10-19 02:52:24 --> Security Class Initialized
DEBUG - 2020-10-19 02:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 02:52:24 --> Input Class Initialized
INFO - 2020-10-19 02:52:24 --> Language Class Initialized
INFO - 2020-10-19 02:52:24 --> Language Class Initialized
INFO - 2020-10-19 02:52:24 --> Config Class Initialized
INFO - 2020-10-19 02:52:24 --> Loader Class Initialized
INFO - 2020-10-19 02:52:24 --> Helper loaded: url_helper
INFO - 2020-10-19 02:52:24 --> Helper loaded: file_helper
INFO - 2020-10-19 02:52:24 --> Helper loaded: form_helper
INFO - 2020-10-19 02:52:24 --> Helper loaded: my_helper
INFO - 2020-10-19 02:52:24 --> Database Driver Class Initialized
DEBUG - 2020-10-19 02:52:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 02:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 02:52:24 --> Controller Class Initialized
DEBUG - 2020-10-19 02:52:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-10-19 02:52:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-19 02:52:24 --> Final output sent to browser
DEBUG - 2020-10-19 02:52:24 --> Total execution time: 0.2616
INFO - 2020-10-19 02:52:24 --> Config Class Initialized
INFO - 2020-10-19 02:52:24 --> Hooks Class Initialized
DEBUG - 2020-10-19 02:52:24 --> UTF-8 Support Enabled
INFO - 2020-10-19 02:52:24 --> Utf8 Class Initialized
INFO - 2020-10-19 02:52:24 --> URI Class Initialized
INFO - 2020-10-19 02:52:24 --> Router Class Initialized
INFO - 2020-10-19 02:52:24 --> Output Class Initialized
INFO - 2020-10-19 02:52:25 --> Security Class Initialized
DEBUG - 2020-10-19 02:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 02:52:25 --> Input Class Initialized
INFO - 2020-10-19 02:52:25 --> Language Class Initialized
INFO - 2020-10-19 02:52:25 --> Language Class Initialized
INFO - 2020-10-19 02:52:25 --> Config Class Initialized
INFO - 2020-10-19 02:52:25 --> Loader Class Initialized
INFO - 2020-10-19 02:52:25 --> Helper loaded: url_helper
INFO - 2020-10-19 02:52:25 --> Helper loaded: file_helper
INFO - 2020-10-19 02:52:25 --> Helper loaded: form_helper
INFO - 2020-10-19 02:52:25 --> Helper loaded: my_helper
INFO - 2020-10-19 02:52:25 --> Database Driver Class Initialized
DEBUG - 2020-10-19 02:52:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 02:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 02:52:25 --> Controller Class Initialized
INFO - 2020-10-19 02:52:27 --> Config Class Initialized
INFO - 2020-10-19 02:52:27 --> Hooks Class Initialized
DEBUG - 2020-10-19 02:52:27 --> UTF-8 Support Enabled
INFO - 2020-10-19 02:52:27 --> Utf8 Class Initialized
INFO - 2020-10-19 02:52:28 --> URI Class Initialized
INFO - 2020-10-19 02:52:28 --> Router Class Initialized
INFO - 2020-10-19 02:52:28 --> Output Class Initialized
INFO - 2020-10-19 02:52:28 --> Security Class Initialized
DEBUG - 2020-10-19 02:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 02:52:28 --> Input Class Initialized
INFO - 2020-10-19 02:52:28 --> Language Class Initialized
INFO - 2020-10-19 02:52:28 --> Language Class Initialized
INFO - 2020-10-19 02:52:28 --> Config Class Initialized
INFO - 2020-10-19 02:52:28 --> Loader Class Initialized
INFO - 2020-10-19 02:52:28 --> Helper loaded: url_helper
INFO - 2020-10-19 02:52:28 --> Helper loaded: file_helper
INFO - 2020-10-19 02:52:28 --> Helper loaded: form_helper
INFO - 2020-10-19 02:52:28 --> Helper loaded: my_helper
INFO - 2020-10-19 02:52:28 --> Database Driver Class Initialized
DEBUG - 2020-10-19 02:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 02:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 02:52:28 --> Controller Class Initialized
ERROR - 2020-10-19 02:52:28 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 223
DEBUG - 2020-10-19 02:52:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2020-10-19 02:52:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-19 02:52:28 --> Final output sent to browser
DEBUG - 2020-10-19 02:52:28 --> Total execution time: 0.3147
INFO - 2020-10-19 02:52:32 --> Config Class Initialized
INFO - 2020-10-19 02:52:32 --> Hooks Class Initialized
DEBUG - 2020-10-19 02:52:32 --> UTF-8 Support Enabled
INFO - 2020-10-19 02:52:32 --> Utf8 Class Initialized
INFO - 2020-10-19 02:52:32 --> URI Class Initialized
INFO - 2020-10-19 02:52:32 --> Router Class Initialized
INFO - 2020-10-19 02:52:32 --> Output Class Initialized
INFO - 2020-10-19 02:52:32 --> Security Class Initialized
DEBUG - 2020-10-19 02:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 02:52:32 --> Input Class Initialized
INFO - 2020-10-19 02:52:32 --> Language Class Initialized
INFO - 2020-10-19 02:52:32 --> Language Class Initialized
INFO - 2020-10-19 02:52:32 --> Config Class Initialized
INFO - 2020-10-19 02:52:32 --> Loader Class Initialized
INFO - 2020-10-19 02:52:32 --> Helper loaded: url_helper
INFO - 2020-10-19 02:52:32 --> Helper loaded: file_helper
INFO - 2020-10-19 02:52:32 --> Helper loaded: form_helper
INFO - 2020-10-19 02:52:32 --> Helper loaded: my_helper
INFO - 2020-10-19 02:52:32 --> Database Driver Class Initialized
DEBUG - 2020-10-19 02:52:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 02:52:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 02:52:32 --> Controller Class Initialized
DEBUG - 2020-10-19 02:52:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-10-19 02:52:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-19 02:52:32 --> Final output sent to browser
DEBUG - 2020-10-19 02:52:32 --> Total execution time: 0.2528
INFO - 2020-10-19 02:52:32 --> Config Class Initialized
INFO - 2020-10-19 02:52:32 --> Hooks Class Initialized
DEBUG - 2020-10-19 02:52:32 --> UTF-8 Support Enabled
INFO - 2020-10-19 02:52:32 --> Utf8 Class Initialized
INFO - 2020-10-19 02:52:33 --> URI Class Initialized
INFO - 2020-10-19 02:52:33 --> Router Class Initialized
INFO - 2020-10-19 02:52:33 --> Output Class Initialized
INFO - 2020-10-19 02:52:33 --> Security Class Initialized
DEBUG - 2020-10-19 02:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 02:52:33 --> Input Class Initialized
INFO - 2020-10-19 02:52:33 --> Language Class Initialized
INFO - 2020-10-19 02:52:33 --> Language Class Initialized
INFO - 2020-10-19 02:52:33 --> Config Class Initialized
INFO - 2020-10-19 02:52:33 --> Loader Class Initialized
INFO - 2020-10-19 02:52:33 --> Helper loaded: url_helper
INFO - 2020-10-19 02:52:33 --> Helper loaded: file_helper
INFO - 2020-10-19 02:52:33 --> Helper loaded: form_helper
INFO - 2020-10-19 02:52:33 --> Helper loaded: my_helper
INFO - 2020-10-19 02:52:33 --> Database Driver Class Initialized
DEBUG - 2020-10-19 02:52:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 02:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 02:52:33 --> Controller Class Initialized
INFO - 2020-10-19 02:55:26 --> Config Class Initialized
INFO - 2020-10-19 02:55:26 --> Hooks Class Initialized
DEBUG - 2020-10-19 02:55:26 --> UTF-8 Support Enabled
INFO - 2020-10-19 02:55:26 --> Utf8 Class Initialized
INFO - 2020-10-19 02:55:26 --> URI Class Initialized
INFO - 2020-10-19 02:55:26 --> Router Class Initialized
INFO - 2020-10-19 02:55:26 --> Output Class Initialized
INFO - 2020-10-19 02:55:26 --> Security Class Initialized
DEBUG - 2020-10-19 02:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 02:55:26 --> Input Class Initialized
INFO - 2020-10-19 02:55:26 --> Language Class Initialized
INFO - 2020-10-19 02:55:26 --> Language Class Initialized
INFO - 2020-10-19 02:55:26 --> Config Class Initialized
INFO - 2020-10-19 02:55:26 --> Loader Class Initialized
INFO - 2020-10-19 02:55:26 --> Helper loaded: url_helper
INFO - 2020-10-19 02:55:26 --> Helper loaded: file_helper
INFO - 2020-10-19 02:55:26 --> Helper loaded: form_helper
INFO - 2020-10-19 02:55:26 --> Helper loaded: my_helper
INFO - 2020-10-19 02:55:26 --> Database Driver Class Initialized
DEBUG - 2020-10-19 02:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 02:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 02:55:26 --> Controller Class Initialized
DEBUG - 2020-10-19 02:55:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-10-19 02:55:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-19 02:55:26 --> Final output sent to browser
DEBUG - 2020-10-19 02:55:26 --> Total execution time: 0.2316
INFO - 2020-10-19 02:55:27 --> Config Class Initialized
INFO - 2020-10-19 02:55:27 --> Hooks Class Initialized
DEBUG - 2020-10-19 02:55:27 --> UTF-8 Support Enabled
INFO - 2020-10-19 02:55:27 --> Utf8 Class Initialized
INFO - 2020-10-19 02:55:27 --> URI Class Initialized
INFO - 2020-10-19 02:55:27 --> Router Class Initialized
INFO - 2020-10-19 02:55:27 --> Output Class Initialized
INFO - 2020-10-19 02:55:27 --> Security Class Initialized
DEBUG - 2020-10-19 02:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 02:55:27 --> Input Class Initialized
INFO - 2020-10-19 02:55:27 --> Language Class Initialized
INFO - 2020-10-19 02:55:27 --> Language Class Initialized
INFO - 2020-10-19 02:55:27 --> Config Class Initialized
INFO - 2020-10-19 02:55:27 --> Loader Class Initialized
INFO - 2020-10-19 02:55:27 --> Helper loaded: url_helper
INFO - 2020-10-19 02:55:27 --> Helper loaded: file_helper
INFO - 2020-10-19 02:55:27 --> Helper loaded: form_helper
INFO - 2020-10-19 02:55:27 --> Helper loaded: my_helper
INFO - 2020-10-19 02:55:27 --> Database Driver Class Initialized
DEBUG - 2020-10-19 02:55:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 02:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 02:55:27 --> Controller Class Initialized
INFO - 2020-10-19 02:55:37 --> Config Class Initialized
INFO - 2020-10-19 02:55:37 --> Hooks Class Initialized
DEBUG - 2020-10-19 02:55:37 --> UTF-8 Support Enabled
INFO - 2020-10-19 02:55:37 --> Utf8 Class Initialized
INFO - 2020-10-19 02:55:37 --> URI Class Initialized
INFO - 2020-10-19 02:55:37 --> Router Class Initialized
INFO - 2020-10-19 02:55:37 --> Output Class Initialized
INFO - 2020-10-19 02:55:37 --> Security Class Initialized
DEBUG - 2020-10-19 02:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 02:55:37 --> Input Class Initialized
INFO - 2020-10-19 02:55:37 --> Language Class Initialized
INFO - 2020-10-19 02:55:37 --> Language Class Initialized
INFO - 2020-10-19 02:55:37 --> Config Class Initialized
INFO - 2020-10-19 02:55:37 --> Loader Class Initialized
INFO - 2020-10-19 02:55:37 --> Helper loaded: url_helper
INFO - 2020-10-19 02:55:37 --> Helper loaded: file_helper
INFO - 2020-10-19 02:55:37 --> Helper loaded: form_helper
INFO - 2020-10-19 02:55:37 --> Helper loaded: my_helper
INFO - 2020-10-19 02:55:37 --> Database Driver Class Initialized
DEBUG - 2020-10-19 02:55:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 02:55:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 02:55:37 --> Controller Class Initialized
ERROR - 2020-10-19 02:55:37 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 223
DEBUG - 2020-10-19 02:55:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2020-10-19 02:55:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-19 02:55:37 --> Final output sent to browser
DEBUG - 2020-10-19 02:55:37 --> Total execution time: 0.2782
INFO - 2020-10-19 02:57:24 --> Config Class Initialized
INFO - 2020-10-19 02:57:24 --> Hooks Class Initialized
DEBUG - 2020-10-19 02:57:24 --> UTF-8 Support Enabled
INFO - 2020-10-19 02:57:24 --> Utf8 Class Initialized
INFO - 2020-10-19 02:57:24 --> URI Class Initialized
INFO - 2020-10-19 02:57:24 --> Router Class Initialized
INFO - 2020-10-19 02:57:24 --> Output Class Initialized
INFO - 2020-10-19 02:57:24 --> Security Class Initialized
DEBUG - 2020-10-19 02:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 02:57:24 --> Input Class Initialized
INFO - 2020-10-19 02:57:24 --> Language Class Initialized
INFO - 2020-10-19 02:57:24 --> Language Class Initialized
INFO - 2020-10-19 02:57:24 --> Config Class Initialized
INFO - 2020-10-19 02:57:24 --> Loader Class Initialized
INFO - 2020-10-19 02:57:24 --> Helper loaded: url_helper
INFO - 2020-10-19 02:57:24 --> Helper loaded: file_helper
INFO - 2020-10-19 02:57:24 --> Helper loaded: form_helper
INFO - 2020-10-19 02:57:24 --> Helper loaded: my_helper
INFO - 2020-10-19 02:57:24 --> Database Driver Class Initialized
DEBUG - 2020-10-19 02:57:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 02:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 02:57:24 --> Controller Class Initialized
INFO - 2020-10-19 02:57:26 --> Upload Class Initialized
INFO - 2020-10-19 02:57:26 --> Language file loaded: language/english/upload_lang.php
ERROR - 2020-10-19 02:57:26 --> The upload path does not appear to be valid.
INFO - 2020-10-19 02:57:26 --> Config Class Initialized
INFO - 2020-10-19 02:57:26 --> Hooks Class Initialized
DEBUG - 2020-10-19 02:57:26 --> UTF-8 Support Enabled
INFO - 2020-10-19 02:57:26 --> Utf8 Class Initialized
INFO - 2020-10-19 02:57:26 --> URI Class Initialized
INFO - 2020-10-19 02:57:26 --> Router Class Initialized
INFO - 2020-10-19 02:57:26 --> Output Class Initialized
INFO - 2020-10-19 02:57:26 --> Security Class Initialized
DEBUG - 2020-10-19 02:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 02:57:26 --> Input Class Initialized
INFO - 2020-10-19 02:57:26 --> Language Class Initialized
INFO - 2020-10-19 02:57:26 --> Language Class Initialized
INFO - 2020-10-19 02:57:26 --> Config Class Initialized
INFO - 2020-10-19 02:57:26 --> Loader Class Initialized
INFO - 2020-10-19 02:57:26 --> Helper loaded: url_helper
INFO - 2020-10-19 02:57:26 --> Helper loaded: file_helper
INFO - 2020-10-19 02:57:26 --> Helper loaded: form_helper
INFO - 2020-10-19 02:57:26 --> Helper loaded: my_helper
INFO - 2020-10-19 02:57:26 --> Database Driver Class Initialized
DEBUG - 2020-10-19 02:57:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 02:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 02:57:26 --> Controller Class Initialized
DEBUG - 2020-10-19 02:57:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-10-19 02:57:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-19 02:57:26 --> Final output sent to browser
DEBUG - 2020-10-19 02:57:26 --> Total execution time: 0.3154
INFO - 2020-10-19 02:57:26 --> Config Class Initialized
INFO - 2020-10-19 02:57:26 --> Hooks Class Initialized
DEBUG - 2020-10-19 02:57:26 --> UTF-8 Support Enabled
INFO - 2020-10-19 02:57:26 --> Utf8 Class Initialized
INFO - 2020-10-19 02:57:26 --> URI Class Initialized
INFO - 2020-10-19 02:57:26 --> Router Class Initialized
INFO - 2020-10-19 02:57:26 --> Output Class Initialized
INFO - 2020-10-19 02:57:26 --> Security Class Initialized
DEBUG - 2020-10-19 02:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 02:57:26 --> Input Class Initialized
INFO - 2020-10-19 02:57:26 --> Language Class Initialized
INFO - 2020-10-19 02:57:26 --> Language Class Initialized
INFO - 2020-10-19 02:57:26 --> Config Class Initialized
INFO - 2020-10-19 02:57:26 --> Loader Class Initialized
INFO - 2020-10-19 02:57:26 --> Helper loaded: url_helper
INFO - 2020-10-19 02:57:26 --> Helper loaded: file_helper
INFO - 2020-10-19 02:57:26 --> Helper loaded: form_helper
INFO - 2020-10-19 02:57:26 --> Helper loaded: my_helper
INFO - 2020-10-19 02:57:26 --> Database Driver Class Initialized
DEBUG - 2020-10-19 02:57:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 02:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 02:57:26 --> Controller Class Initialized
INFO - 2020-10-19 02:57:33 --> Config Class Initialized
INFO - 2020-10-19 02:57:33 --> Hooks Class Initialized
DEBUG - 2020-10-19 02:57:33 --> UTF-8 Support Enabled
INFO - 2020-10-19 02:57:33 --> Utf8 Class Initialized
INFO - 2020-10-19 02:57:33 --> URI Class Initialized
INFO - 2020-10-19 02:57:33 --> Router Class Initialized
INFO - 2020-10-19 02:57:33 --> Output Class Initialized
INFO - 2020-10-19 02:57:33 --> Security Class Initialized
DEBUG - 2020-10-19 02:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 02:57:33 --> Input Class Initialized
INFO - 2020-10-19 02:57:33 --> Language Class Initialized
INFO - 2020-10-19 02:57:33 --> Language Class Initialized
INFO - 2020-10-19 02:57:33 --> Config Class Initialized
INFO - 2020-10-19 02:57:33 --> Loader Class Initialized
INFO - 2020-10-19 02:57:33 --> Helper loaded: url_helper
INFO - 2020-10-19 02:57:33 --> Helper loaded: file_helper
INFO - 2020-10-19 02:57:33 --> Helper loaded: form_helper
INFO - 2020-10-19 02:57:33 --> Helper loaded: my_helper
INFO - 2020-10-19 02:57:33 --> Database Driver Class Initialized
DEBUG - 2020-10-19 02:57:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 02:57:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 02:57:33 --> Controller Class Initialized
DEBUG - 2020-10-19 02:57:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-10-19 02:57:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-19 02:57:33 --> Final output sent to browser
DEBUG - 2020-10-19 02:57:33 --> Total execution time: 0.2480
INFO - 2020-10-19 02:57:33 --> Config Class Initialized
INFO - 2020-10-19 02:57:33 --> Hooks Class Initialized
DEBUG - 2020-10-19 02:57:33 --> UTF-8 Support Enabled
INFO - 2020-10-19 02:57:33 --> Utf8 Class Initialized
INFO - 2020-10-19 02:57:34 --> URI Class Initialized
INFO - 2020-10-19 02:57:34 --> Router Class Initialized
INFO - 2020-10-19 02:57:34 --> Output Class Initialized
INFO - 2020-10-19 02:57:34 --> Security Class Initialized
DEBUG - 2020-10-19 02:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 02:57:34 --> Input Class Initialized
INFO - 2020-10-19 02:57:34 --> Language Class Initialized
INFO - 2020-10-19 02:57:34 --> Language Class Initialized
INFO - 2020-10-19 02:57:34 --> Config Class Initialized
INFO - 2020-10-19 02:57:34 --> Loader Class Initialized
INFO - 2020-10-19 02:57:34 --> Helper loaded: url_helper
INFO - 2020-10-19 02:57:34 --> Helper loaded: file_helper
INFO - 2020-10-19 02:57:34 --> Helper loaded: form_helper
INFO - 2020-10-19 02:57:34 --> Helper loaded: my_helper
INFO - 2020-10-19 02:57:34 --> Database Driver Class Initialized
DEBUG - 2020-10-19 02:57:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 02:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 02:57:34 --> Controller Class Initialized
INFO - 2020-10-19 02:57:36 --> Config Class Initialized
INFO - 2020-10-19 02:57:36 --> Hooks Class Initialized
DEBUG - 2020-10-19 02:57:36 --> UTF-8 Support Enabled
INFO - 2020-10-19 02:57:36 --> Utf8 Class Initialized
INFO - 2020-10-19 02:57:36 --> URI Class Initialized
INFO - 2020-10-19 02:57:36 --> Router Class Initialized
INFO - 2020-10-19 02:57:36 --> Output Class Initialized
INFO - 2020-10-19 02:57:36 --> Security Class Initialized
DEBUG - 2020-10-19 02:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 02:57:36 --> Input Class Initialized
INFO - 2020-10-19 02:57:36 --> Language Class Initialized
INFO - 2020-10-19 02:57:36 --> Language Class Initialized
INFO - 2020-10-19 02:57:36 --> Config Class Initialized
INFO - 2020-10-19 02:57:36 --> Loader Class Initialized
INFO - 2020-10-19 02:57:36 --> Helper loaded: url_helper
INFO - 2020-10-19 02:57:36 --> Helper loaded: file_helper
INFO - 2020-10-19 02:57:36 --> Helper loaded: form_helper
INFO - 2020-10-19 02:57:36 --> Helper loaded: my_helper
INFO - 2020-10-19 02:57:36 --> Database Driver Class Initialized
DEBUG - 2020-10-19 02:57:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 02:57:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 02:57:36 --> Controller Class Initialized
DEBUG - 2020-10-19 02:57:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-10-19 02:57:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-19 02:57:36 --> Final output sent to browser
DEBUG - 2020-10-19 02:57:36 --> Total execution time: 0.2582
INFO - 2020-10-19 02:57:36 --> Config Class Initialized
INFO - 2020-10-19 02:57:36 --> Hooks Class Initialized
DEBUG - 2020-10-19 02:57:36 --> UTF-8 Support Enabled
INFO - 2020-10-19 02:57:36 --> Utf8 Class Initialized
INFO - 2020-10-19 02:57:36 --> URI Class Initialized
INFO - 2020-10-19 02:57:36 --> Router Class Initialized
INFO - 2020-10-19 02:57:36 --> Output Class Initialized
INFO - 2020-10-19 02:57:36 --> Security Class Initialized
DEBUG - 2020-10-19 02:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 02:57:36 --> Input Class Initialized
INFO - 2020-10-19 02:57:36 --> Language Class Initialized
INFO - 2020-10-19 02:57:36 --> Language Class Initialized
INFO - 2020-10-19 02:57:36 --> Config Class Initialized
INFO - 2020-10-19 02:57:36 --> Loader Class Initialized
INFO - 2020-10-19 02:57:36 --> Helper loaded: url_helper
INFO - 2020-10-19 02:57:36 --> Helper loaded: file_helper
INFO - 2020-10-19 02:57:36 --> Helper loaded: form_helper
INFO - 2020-10-19 02:57:36 --> Helper loaded: my_helper
INFO - 2020-10-19 02:57:36 --> Database Driver Class Initialized
DEBUG - 2020-10-19 02:57:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 02:57:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 02:57:36 --> Controller Class Initialized
INFO - 2020-10-19 02:57:37 --> Config Class Initialized
INFO - 2020-10-19 02:57:37 --> Hooks Class Initialized
DEBUG - 2020-10-19 02:57:37 --> UTF-8 Support Enabled
INFO - 2020-10-19 02:57:37 --> Utf8 Class Initialized
INFO - 2020-10-19 02:57:37 --> URI Class Initialized
INFO - 2020-10-19 02:57:37 --> Router Class Initialized
INFO - 2020-10-19 02:57:37 --> Output Class Initialized
INFO - 2020-10-19 02:57:37 --> Security Class Initialized
DEBUG - 2020-10-19 02:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 02:57:37 --> Input Class Initialized
INFO - 2020-10-19 02:57:37 --> Language Class Initialized
INFO - 2020-10-19 02:57:37 --> Language Class Initialized
INFO - 2020-10-19 02:57:37 --> Config Class Initialized
INFO - 2020-10-19 02:57:37 --> Loader Class Initialized
INFO - 2020-10-19 02:57:37 --> Helper loaded: url_helper
INFO - 2020-10-19 02:57:37 --> Helper loaded: file_helper
INFO - 2020-10-19 02:57:37 --> Helper loaded: form_helper
INFO - 2020-10-19 02:57:37 --> Helper loaded: my_helper
INFO - 2020-10-19 02:57:37 --> Database Driver Class Initialized
DEBUG - 2020-10-19 02:57:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 02:57:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 02:57:37 --> Controller Class Initialized
DEBUG - 2020-10-19 02:57:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-19 02:57:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-19 02:57:37 --> Final output sent to browser
DEBUG - 2020-10-19 02:57:37 --> Total execution time: 0.2594
INFO - 2020-10-19 02:57:37 --> Config Class Initialized
INFO - 2020-10-19 02:57:37 --> Hooks Class Initialized
DEBUG - 2020-10-19 02:57:37 --> UTF-8 Support Enabled
INFO - 2020-10-19 02:57:37 --> Utf8 Class Initialized
INFO - 2020-10-19 02:57:37 --> URI Class Initialized
INFO - 2020-10-19 02:57:37 --> Router Class Initialized
INFO - 2020-10-19 02:57:37 --> Output Class Initialized
INFO - 2020-10-19 02:57:37 --> Security Class Initialized
DEBUG - 2020-10-19 02:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 02:57:37 --> Input Class Initialized
INFO - 2020-10-19 02:57:37 --> Language Class Initialized
INFO - 2020-10-19 02:57:37 --> Language Class Initialized
INFO - 2020-10-19 02:57:37 --> Config Class Initialized
INFO - 2020-10-19 02:57:37 --> Loader Class Initialized
INFO - 2020-10-19 02:57:37 --> Helper loaded: url_helper
INFO - 2020-10-19 02:57:37 --> Helper loaded: file_helper
INFO - 2020-10-19 02:57:37 --> Helper loaded: form_helper
INFO - 2020-10-19 02:57:37 --> Helper loaded: my_helper
INFO - 2020-10-19 02:57:37 --> Database Driver Class Initialized
DEBUG - 2020-10-19 02:57:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 02:57:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 02:57:37 --> Controller Class Initialized
INFO - 2020-10-19 03:28:26 --> Config Class Initialized
INFO - 2020-10-19 03:28:26 --> Hooks Class Initialized
DEBUG - 2020-10-19 03:28:26 --> UTF-8 Support Enabled
INFO - 2020-10-19 03:28:26 --> Utf8 Class Initialized
INFO - 2020-10-19 03:28:26 --> URI Class Initialized
INFO - 2020-10-19 03:28:26 --> Router Class Initialized
INFO - 2020-10-19 03:28:26 --> Output Class Initialized
INFO - 2020-10-19 03:28:26 --> Security Class Initialized
DEBUG - 2020-10-19 03:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 03:28:26 --> Input Class Initialized
INFO - 2020-10-19 03:28:26 --> Language Class Initialized
INFO - 2020-10-19 03:28:26 --> Language Class Initialized
INFO - 2020-10-19 03:28:26 --> Config Class Initialized
INFO - 2020-10-19 03:28:26 --> Loader Class Initialized
INFO - 2020-10-19 03:28:26 --> Helper loaded: url_helper
INFO - 2020-10-19 03:28:26 --> Helper loaded: file_helper
INFO - 2020-10-19 03:28:26 --> Helper loaded: form_helper
INFO - 2020-10-19 03:28:26 --> Helper loaded: my_helper
INFO - 2020-10-19 03:28:26 --> Database Driver Class Initialized
DEBUG - 2020-10-19 03:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 03:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 03:28:26 --> Controller Class Initialized
DEBUG - 2020-10-19 03:28:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-10-19 03:28:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-19 03:28:26 --> Final output sent to browser
DEBUG - 2020-10-19 03:28:26 --> Total execution time: 0.2425
INFO - 2020-10-19 03:28:26 --> Config Class Initialized
INFO - 2020-10-19 03:28:26 --> Hooks Class Initialized
DEBUG - 2020-10-19 03:28:26 --> UTF-8 Support Enabled
INFO - 2020-10-19 03:28:26 --> Utf8 Class Initialized
INFO - 2020-10-19 03:28:26 --> URI Class Initialized
INFO - 2020-10-19 03:28:26 --> Router Class Initialized
INFO - 2020-10-19 03:28:26 --> Output Class Initialized
INFO - 2020-10-19 03:28:26 --> Security Class Initialized
DEBUG - 2020-10-19 03:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 03:28:26 --> Input Class Initialized
INFO - 2020-10-19 03:28:26 --> Language Class Initialized
INFO - 2020-10-19 03:28:26 --> Language Class Initialized
INFO - 2020-10-19 03:28:26 --> Config Class Initialized
INFO - 2020-10-19 03:28:26 --> Loader Class Initialized
INFO - 2020-10-19 03:28:26 --> Helper loaded: url_helper
INFO - 2020-10-19 03:28:26 --> Helper loaded: file_helper
INFO - 2020-10-19 03:28:26 --> Helper loaded: form_helper
INFO - 2020-10-19 03:28:26 --> Helper loaded: my_helper
INFO - 2020-10-19 03:28:26 --> Database Driver Class Initialized
DEBUG - 2020-10-19 03:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 03:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 03:28:26 --> Controller Class Initialized
INFO - 2020-10-19 03:28:29 --> Config Class Initialized
INFO - 2020-10-19 03:28:29 --> Hooks Class Initialized
DEBUG - 2020-10-19 03:28:29 --> UTF-8 Support Enabled
INFO - 2020-10-19 03:28:29 --> Utf8 Class Initialized
INFO - 2020-10-19 03:28:29 --> URI Class Initialized
INFO - 2020-10-19 03:28:29 --> Router Class Initialized
INFO - 2020-10-19 03:28:29 --> Output Class Initialized
INFO - 2020-10-19 03:28:29 --> Security Class Initialized
DEBUG - 2020-10-19 03:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 03:28:29 --> Input Class Initialized
INFO - 2020-10-19 03:28:29 --> Language Class Initialized
INFO - 2020-10-19 03:28:29 --> Language Class Initialized
INFO - 2020-10-19 03:28:29 --> Config Class Initialized
INFO - 2020-10-19 03:28:29 --> Loader Class Initialized
INFO - 2020-10-19 03:28:29 --> Helper loaded: url_helper
INFO - 2020-10-19 03:28:29 --> Helper loaded: file_helper
INFO - 2020-10-19 03:28:29 --> Helper loaded: form_helper
INFO - 2020-10-19 03:28:29 --> Helper loaded: my_helper
INFO - 2020-10-19 03:28:29 --> Database Driver Class Initialized
DEBUG - 2020-10-19 03:28:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 03:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 03:28:29 --> Controller Class Initialized
DEBUG - 2020-10-19 03:28:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2020-10-19 03:28:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-19 03:28:29 --> Final output sent to browser
DEBUG - 2020-10-19 03:28:29 --> Total execution time: 0.2444
INFO - 2020-10-19 03:28:29 --> Config Class Initialized
INFO - 2020-10-19 03:28:29 --> Hooks Class Initialized
DEBUG - 2020-10-19 03:28:29 --> UTF-8 Support Enabled
INFO - 2020-10-19 03:28:29 --> Utf8 Class Initialized
INFO - 2020-10-19 03:28:29 --> URI Class Initialized
INFO - 2020-10-19 03:28:29 --> Router Class Initialized
INFO - 2020-10-19 03:28:29 --> Output Class Initialized
INFO - 2020-10-19 03:28:29 --> Security Class Initialized
DEBUG - 2020-10-19 03:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 03:28:29 --> Input Class Initialized
INFO - 2020-10-19 03:28:29 --> Language Class Initialized
INFO - 2020-10-19 03:28:29 --> Language Class Initialized
INFO - 2020-10-19 03:28:29 --> Config Class Initialized
INFO - 2020-10-19 03:28:29 --> Loader Class Initialized
INFO - 2020-10-19 03:28:29 --> Helper loaded: url_helper
INFO - 2020-10-19 03:28:29 --> Helper loaded: file_helper
INFO - 2020-10-19 03:28:29 --> Helper loaded: form_helper
INFO - 2020-10-19 03:28:29 --> Helper loaded: my_helper
INFO - 2020-10-19 03:28:29 --> Database Driver Class Initialized
DEBUG - 2020-10-19 03:28:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 03:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 03:28:29 --> Controller Class Initialized
INFO - 2020-10-19 03:28:31 --> Config Class Initialized
INFO - 2020-10-19 03:28:31 --> Hooks Class Initialized
DEBUG - 2020-10-19 03:28:31 --> UTF-8 Support Enabled
INFO - 2020-10-19 03:28:31 --> Utf8 Class Initialized
INFO - 2020-10-19 03:28:31 --> URI Class Initialized
INFO - 2020-10-19 03:28:31 --> Router Class Initialized
INFO - 2020-10-19 03:28:31 --> Output Class Initialized
INFO - 2020-10-19 03:28:31 --> Security Class Initialized
DEBUG - 2020-10-19 03:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 03:28:31 --> Input Class Initialized
INFO - 2020-10-19 03:28:31 --> Language Class Initialized
INFO - 2020-10-19 03:28:31 --> Language Class Initialized
INFO - 2020-10-19 03:28:31 --> Config Class Initialized
INFO - 2020-10-19 03:28:31 --> Loader Class Initialized
INFO - 2020-10-19 03:28:31 --> Helper loaded: url_helper
INFO - 2020-10-19 03:28:31 --> Helper loaded: file_helper
INFO - 2020-10-19 03:28:31 --> Helper loaded: form_helper
INFO - 2020-10-19 03:28:31 --> Helper loaded: my_helper
INFO - 2020-10-19 03:28:31 --> Database Driver Class Initialized
DEBUG - 2020-10-19 03:28:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 03:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 03:28:31 --> Controller Class Initialized
DEBUG - 2020-10-19 03:28:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-10-19 03:28:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-19 03:28:31 --> Final output sent to browser
DEBUG - 2020-10-19 03:28:31 --> Total execution time: 0.2382
INFO - 2020-10-19 03:28:31 --> Config Class Initialized
INFO - 2020-10-19 03:28:31 --> Hooks Class Initialized
DEBUG - 2020-10-19 03:28:31 --> UTF-8 Support Enabled
INFO - 2020-10-19 03:28:31 --> Utf8 Class Initialized
INFO - 2020-10-19 03:28:31 --> URI Class Initialized
INFO - 2020-10-19 03:28:31 --> Router Class Initialized
INFO - 2020-10-19 03:28:31 --> Output Class Initialized
INFO - 2020-10-19 03:28:32 --> Security Class Initialized
DEBUG - 2020-10-19 03:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 03:28:32 --> Input Class Initialized
INFO - 2020-10-19 03:28:32 --> Language Class Initialized
INFO - 2020-10-19 03:28:32 --> Language Class Initialized
INFO - 2020-10-19 03:28:32 --> Config Class Initialized
INFO - 2020-10-19 03:28:32 --> Loader Class Initialized
INFO - 2020-10-19 03:28:32 --> Helper loaded: url_helper
INFO - 2020-10-19 03:28:32 --> Helper loaded: file_helper
INFO - 2020-10-19 03:28:32 --> Helper loaded: form_helper
INFO - 2020-10-19 03:28:32 --> Helper loaded: my_helper
INFO - 2020-10-19 03:28:32 --> Database Driver Class Initialized
DEBUG - 2020-10-19 03:28:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 03:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 03:28:32 --> Controller Class Initialized
INFO - 2020-10-19 03:28:33 --> Config Class Initialized
INFO - 2020-10-19 03:28:33 --> Hooks Class Initialized
DEBUG - 2020-10-19 03:28:33 --> UTF-8 Support Enabled
INFO - 2020-10-19 03:28:33 --> Utf8 Class Initialized
INFO - 2020-10-19 03:28:33 --> URI Class Initialized
INFO - 2020-10-19 03:28:33 --> Router Class Initialized
INFO - 2020-10-19 03:28:33 --> Output Class Initialized
INFO - 2020-10-19 03:28:33 --> Security Class Initialized
DEBUG - 2020-10-19 03:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 03:28:33 --> Input Class Initialized
INFO - 2020-10-19 03:28:33 --> Language Class Initialized
INFO - 2020-10-19 03:28:33 --> Language Class Initialized
INFO - 2020-10-19 03:28:33 --> Config Class Initialized
INFO - 2020-10-19 03:28:33 --> Loader Class Initialized
INFO - 2020-10-19 03:28:33 --> Helper loaded: url_helper
INFO - 2020-10-19 03:28:33 --> Helper loaded: file_helper
INFO - 2020-10-19 03:28:33 --> Helper loaded: form_helper
INFO - 2020-10-19 03:28:33 --> Helper loaded: my_helper
INFO - 2020-10-19 03:28:33 --> Database Driver Class Initialized
DEBUG - 2020-10-19 03:28:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 03:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 03:28:33 --> Controller Class Initialized
DEBUG - 2020-10-19 03:28:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-19 03:28:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-19 03:28:34 --> Final output sent to browser
DEBUG - 2020-10-19 03:28:34 --> Total execution time: 0.2330
INFO - 2020-10-19 03:28:34 --> Config Class Initialized
INFO - 2020-10-19 03:28:34 --> Hooks Class Initialized
DEBUG - 2020-10-19 03:28:34 --> UTF-8 Support Enabled
INFO - 2020-10-19 03:28:34 --> Utf8 Class Initialized
INFO - 2020-10-19 03:28:34 --> URI Class Initialized
INFO - 2020-10-19 03:28:34 --> Router Class Initialized
INFO - 2020-10-19 03:28:34 --> Output Class Initialized
INFO - 2020-10-19 03:28:34 --> Security Class Initialized
DEBUG - 2020-10-19 03:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 03:28:34 --> Input Class Initialized
INFO - 2020-10-19 03:28:34 --> Language Class Initialized
INFO - 2020-10-19 03:28:34 --> Language Class Initialized
INFO - 2020-10-19 03:28:34 --> Config Class Initialized
INFO - 2020-10-19 03:28:34 --> Loader Class Initialized
INFO - 2020-10-19 03:28:34 --> Helper loaded: url_helper
INFO - 2020-10-19 03:28:34 --> Helper loaded: file_helper
INFO - 2020-10-19 03:28:34 --> Helper loaded: form_helper
INFO - 2020-10-19 03:28:34 --> Helper loaded: my_helper
INFO - 2020-10-19 03:28:34 --> Database Driver Class Initialized
DEBUG - 2020-10-19 03:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 03:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 03:28:34 --> Controller Class Initialized
INFO - 2020-10-19 03:29:20 --> Config Class Initialized
INFO - 2020-10-19 03:29:20 --> Hooks Class Initialized
DEBUG - 2020-10-19 03:29:20 --> UTF-8 Support Enabled
INFO - 2020-10-19 03:29:20 --> Utf8 Class Initialized
INFO - 2020-10-19 03:29:20 --> URI Class Initialized
INFO - 2020-10-19 03:29:20 --> Router Class Initialized
INFO - 2020-10-19 03:29:20 --> Output Class Initialized
INFO - 2020-10-19 03:29:20 --> Security Class Initialized
DEBUG - 2020-10-19 03:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 03:29:20 --> Input Class Initialized
INFO - 2020-10-19 03:29:20 --> Language Class Initialized
INFO - 2020-10-19 03:29:20 --> Language Class Initialized
INFO - 2020-10-19 03:29:20 --> Config Class Initialized
INFO - 2020-10-19 03:29:20 --> Loader Class Initialized
INFO - 2020-10-19 03:29:20 --> Helper loaded: url_helper
INFO - 2020-10-19 03:29:20 --> Helper loaded: file_helper
INFO - 2020-10-19 03:29:20 --> Helper loaded: form_helper
INFO - 2020-10-19 03:29:20 --> Helper loaded: my_helper
INFO - 2020-10-19 03:29:20 --> Database Driver Class Initialized
DEBUG - 2020-10-19 03:29:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 03:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 03:29:20 --> Controller Class Initialized
DEBUG - 2020-10-19 03:29:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-10-19 03:29:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-19 03:29:20 --> Final output sent to browser
DEBUG - 2020-10-19 03:29:20 --> Total execution time: 0.2440
INFO - 2020-10-19 03:29:20 --> Config Class Initialized
INFO - 2020-10-19 03:29:20 --> Hooks Class Initialized
DEBUG - 2020-10-19 03:29:20 --> UTF-8 Support Enabled
INFO - 2020-10-19 03:29:20 --> Utf8 Class Initialized
INFO - 2020-10-19 03:29:20 --> URI Class Initialized
INFO - 2020-10-19 03:29:20 --> Router Class Initialized
INFO - 2020-10-19 03:29:20 --> Output Class Initialized
INFO - 2020-10-19 03:29:20 --> Security Class Initialized
DEBUG - 2020-10-19 03:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 03:29:20 --> Input Class Initialized
INFO - 2020-10-19 03:29:20 --> Language Class Initialized
INFO - 2020-10-19 03:29:20 --> Language Class Initialized
INFO - 2020-10-19 03:29:20 --> Config Class Initialized
INFO - 2020-10-19 03:29:20 --> Loader Class Initialized
INFO - 2020-10-19 03:29:20 --> Helper loaded: url_helper
INFO - 2020-10-19 03:29:20 --> Helper loaded: file_helper
INFO - 2020-10-19 03:29:20 --> Helper loaded: form_helper
INFO - 2020-10-19 03:29:20 --> Helper loaded: my_helper
INFO - 2020-10-19 03:29:20 --> Database Driver Class Initialized
DEBUG - 2020-10-19 03:29:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 03:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 03:29:20 --> Controller Class Initialized
INFO - 2020-10-19 03:29:21 --> Config Class Initialized
INFO - 2020-10-19 03:29:21 --> Hooks Class Initialized
DEBUG - 2020-10-19 03:29:21 --> UTF-8 Support Enabled
INFO - 2020-10-19 03:29:21 --> Utf8 Class Initialized
INFO - 2020-10-19 03:29:21 --> URI Class Initialized
INFO - 2020-10-19 03:29:21 --> Router Class Initialized
INFO - 2020-10-19 03:29:21 --> Output Class Initialized
INFO - 2020-10-19 03:29:21 --> Security Class Initialized
DEBUG - 2020-10-19 03:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 03:29:21 --> Input Class Initialized
INFO - 2020-10-19 03:29:21 --> Language Class Initialized
INFO - 2020-10-19 03:29:21 --> Language Class Initialized
INFO - 2020-10-19 03:29:21 --> Config Class Initialized
INFO - 2020-10-19 03:29:21 --> Loader Class Initialized
INFO - 2020-10-19 03:29:21 --> Helper loaded: url_helper
INFO - 2020-10-19 03:29:21 --> Helper loaded: file_helper
INFO - 2020-10-19 03:29:21 --> Helper loaded: form_helper
INFO - 2020-10-19 03:29:21 --> Helper loaded: my_helper
INFO - 2020-10-19 03:29:21 --> Database Driver Class Initialized
DEBUG - 2020-10-19 03:29:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 03:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 03:29:21 --> Controller Class Initialized
DEBUG - 2020-10-19 03:29:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-19 03:29:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-19 03:29:21 --> Final output sent to browser
DEBUG - 2020-10-19 03:29:21 --> Total execution time: 0.2480
INFO - 2020-10-19 03:29:21 --> Config Class Initialized
INFO - 2020-10-19 03:29:21 --> Hooks Class Initialized
DEBUG - 2020-10-19 03:29:21 --> UTF-8 Support Enabled
INFO - 2020-10-19 03:29:21 --> Utf8 Class Initialized
INFO - 2020-10-19 03:29:22 --> URI Class Initialized
INFO - 2020-10-19 03:29:22 --> Router Class Initialized
INFO - 2020-10-19 03:29:22 --> Output Class Initialized
INFO - 2020-10-19 03:29:22 --> Security Class Initialized
DEBUG - 2020-10-19 03:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 03:29:22 --> Input Class Initialized
INFO - 2020-10-19 03:29:22 --> Language Class Initialized
INFO - 2020-10-19 03:29:22 --> Language Class Initialized
INFO - 2020-10-19 03:29:22 --> Config Class Initialized
INFO - 2020-10-19 03:29:22 --> Loader Class Initialized
INFO - 2020-10-19 03:29:22 --> Helper loaded: url_helper
INFO - 2020-10-19 03:29:22 --> Helper loaded: file_helper
INFO - 2020-10-19 03:29:22 --> Helper loaded: form_helper
INFO - 2020-10-19 03:29:22 --> Helper loaded: my_helper
INFO - 2020-10-19 03:29:22 --> Database Driver Class Initialized
DEBUG - 2020-10-19 03:29:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 03:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 03:29:22 --> Controller Class Initialized
INFO - 2020-10-19 03:29:37 --> Config Class Initialized
INFO - 2020-10-19 03:29:37 --> Hooks Class Initialized
DEBUG - 2020-10-19 03:29:38 --> UTF-8 Support Enabled
INFO - 2020-10-19 03:29:38 --> Utf8 Class Initialized
INFO - 2020-10-19 03:29:38 --> URI Class Initialized
INFO - 2020-10-19 03:29:38 --> Router Class Initialized
INFO - 2020-10-19 03:29:38 --> Output Class Initialized
INFO - 2020-10-19 03:29:38 --> Security Class Initialized
DEBUG - 2020-10-19 03:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 03:29:38 --> Input Class Initialized
INFO - 2020-10-19 03:29:38 --> Language Class Initialized
INFO - 2020-10-19 03:29:38 --> Language Class Initialized
INFO - 2020-10-19 03:29:38 --> Config Class Initialized
INFO - 2020-10-19 03:29:38 --> Loader Class Initialized
INFO - 2020-10-19 03:29:38 --> Helper loaded: url_helper
INFO - 2020-10-19 03:29:38 --> Helper loaded: file_helper
INFO - 2020-10-19 03:29:38 --> Helper loaded: form_helper
INFO - 2020-10-19 03:29:38 --> Helper loaded: my_helper
INFO - 2020-10-19 03:29:38 --> Database Driver Class Initialized
DEBUG - 2020-10-19 03:29:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 03:29:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 03:29:38 --> Controller Class Initialized
DEBUG - 2020-10-19 03:29:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-10-19 03:29:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-19 03:29:38 --> Final output sent to browser
DEBUG - 2020-10-19 03:29:38 --> Total execution time: 0.2472
INFO - 2020-10-19 03:29:38 --> Config Class Initialized
INFO - 2020-10-19 03:29:38 --> Hooks Class Initialized
DEBUG - 2020-10-19 03:29:38 --> UTF-8 Support Enabled
INFO - 2020-10-19 03:29:38 --> Utf8 Class Initialized
INFO - 2020-10-19 03:29:38 --> URI Class Initialized
INFO - 2020-10-19 03:29:38 --> Router Class Initialized
INFO - 2020-10-19 03:29:38 --> Output Class Initialized
INFO - 2020-10-19 03:29:38 --> Security Class Initialized
DEBUG - 2020-10-19 03:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 03:29:38 --> Input Class Initialized
INFO - 2020-10-19 03:29:38 --> Language Class Initialized
INFO - 2020-10-19 03:29:38 --> Language Class Initialized
INFO - 2020-10-19 03:29:38 --> Config Class Initialized
INFO - 2020-10-19 03:29:38 --> Loader Class Initialized
INFO - 2020-10-19 03:29:38 --> Helper loaded: url_helper
INFO - 2020-10-19 03:29:38 --> Helper loaded: file_helper
INFO - 2020-10-19 03:29:38 --> Helper loaded: form_helper
INFO - 2020-10-19 03:29:38 --> Helper loaded: my_helper
INFO - 2020-10-19 03:29:38 --> Database Driver Class Initialized
DEBUG - 2020-10-19 03:29:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 03:29:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 03:29:38 --> Controller Class Initialized
INFO - 2020-10-19 03:29:42 --> Config Class Initialized
INFO - 2020-10-19 03:29:42 --> Hooks Class Initialized
DEBUG - 2020-10-19 03:29:42 --> UTF-8 Support Enabled
INFO - 2020-10-19 03:29:42 --> Utf8 Class Initialized
INFO - 2020-10-19 03:29:42 --> URI Class Initialized
INFO - 2020-10-19 03:29:42 --> Router Class Initialized
INFO - 2020-10-19 03:29:42 --> Output Class Initialized
INFO - 2020-10-19 03:29:42 --> Security Class Initialized
DEBUG - 2020-10-19 03:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 03:29:42 --> Input Class Initialized
INFO - 2020-10-19 03:29:42 --> Language Class Initialized
INFO - 2020-10-19 03:29:42 --> Language Class Initialized
INFO - 2020-10-19 03:29:42 --> Config Class Initialized
INFO - 2020-10-19 03:29:42 --> Loader Class Initialized
INFO - 2020-10-19 03:29:42 --> Helper loaded: url_helper
INFO - 2020-10-19 03:29:42 --> Helper loaded: file_helper
INFO - 2020-10-19 03:29:42 --> Helper loaded: form_helper
INFO - 2020-10-19 03:29:42 --> Helper loaded: my_helper
INFO - 2020-10-19 03:29:42 --> Database Driver Class Initialized
DEBUG - 2020-10-19 03:29:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 03:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 03:29:42 --> Controller Class Initialized
INFO - 2020-10-19 03:29:42 --> Final output sent to browser
DEBUG - 2020-10-19 03:29:42 --> Total execution time: 0.2360
INFO - 2020-10-19 03:29:53 --> Config Class Initialized
INFO - 2020-10-19 03:29:53 --> Hooks Class Initialized
DEBUG - 2020-10-19 03:29:53 --> UTF-8 Support Enabled
INFO - 2020-10-19 03:29:53 --> Utf8 Class Initialized
INFO - 2020-10-19 03:29:53 --> URI Class Initialized
INFO - 2020-10-19 03:29:53 --> Router Class Initialized
INFO - 2020-10-19 03:29:53 --> Output Class Initialized
INFO - 2020-10-19 03:29:53 --> Security Class Initialized
DEBUG - 2020-10-19 03:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 03:29:53 --> Input Class Initialized
INFO - 2020-10-19 03:29:53 --> Language Class Initialized
INFO - 2020-10-19 03:29:53 --> Language Class Initialized
INFO - 2020-10-19 03:29:53 --> Config Class Initialized
INFO - 2020-10-19 03:29:53 --> Loader Class Initialized
INFO - 2020-10-19 03:29:53 --> Helper loaded: url_helper
INFO - 2020-10-19 03:29:53 --> Helper loaded: file_helper
INFO - 2020-10-19 03:29:53 --> Helper loaded: form_helper
INFO - 2020-10-19 03:29:53 --> Helper loaded: my_helper
INFO - 2020-10-19 03:29:53 --> Database Driver Class Initialized
DEBUG - 2020-10-19 03:29:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 03:29:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 03:29:53 --> Controller Class Initialized
INFO - 2020-10-19 03:29:53 --> Final output sent to browser
DEBUG - 2020-10-19 03:29:53 --> Total execution time: 0.2953
INFO - 2020-10-19 03:29:53 --> Config Class Initialized
INFO - 2020-10-19 03:29:53 --> Hooks Class Initialized
DEBUG - 2020-10-19 03:29:53 --> UTF-8 Support Enabled
INFO - 2020-10-19 03:29:53 --> Utf8 Class Initialized
INFO - 2020-10-19 03:29:53 --> URI Class Initialized
INFO - 2020-10-19 03:29:53 --> Router Class Initialized
INFO - 2020-10-19 03:29:53 --> Output Class Initialized
INFO - 2020-10-19 03:29:53 --> Security Class Initialized
DEBUG - 2020-10-19 03:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 03:29:53 --> Input Class Initialized
INFO - 2020-10-19 03:29:53 --> Language Class Initialized
INFO - 2020-10-19 03:29:53 --> Language Class Initialized
INFO - 2020-10-19 03:29:53 --> Config Class Initialized
INFO - 2020-10-19 03:29:53 --> Loader Class Initialized
INFO - 2020-10-19 03:29:53 --> Helper loaded: url_helper
INFO - 2020-10-19 03:29:53 --> Helper loaded: file_helper
INFO - 2020-10-19 03:29:53 --> Helper loaded: form_helper
INFO - 2020-10-19 03:29:53 --> Helper loaded: my_helper
INFO - 2020-10-19 03:29:53 --> Database Driver Class Initialized
DEBUG - 2020-10-19 03:29:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 03:29:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 03:29:53 --> Controller Class Initialized
INFO - 2020-10-19 03:30:14 --> Config Class Initialized
INFO - 2020-10-19 03:30:14 --> Hooks Class Initialized
DEBUG - 2020-10-19 03:30:14 --> UTF-8 Support Enabled
INFO - 2020-10-19 03:30:14 --> Utf8 Class Initialized
INFO - 2020-10-19 03:30:14 --> URI Class Initialized
INFO - 2020-10-19 03:30:14 --> Router Class Initialized
INFO - 2020-10-19 03:30:14 --> Output Class Initialized
INFO - 2020-10-19 03:30:14 --> Security Class Initialized
DEBUG - 2020-10-19 03:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 03:30:14 --> Input Class Initialized
INFO - 2020-10-19 03:30:14 --> Language Class Initialized
INFO - 2020-10-19 03:30:14 --> Language Class Initialized
INFO - 2020-10-19 03:30:14 --> Config Class Initialized
INFO - 2020-10-19 03:30:14 --> Loader Class Initialized
INFO - 2020-10-19 03:30:14 --> Helper loaded: url_helper
INFO - 2020-10-19 03:30:14 --> Helper loaded: file_helper
INFO - 2020-10-19 03:30:14 --> Helper loaded: form_helper
INFO - 2020-10-19 03:30:14 --> Helper loaded: my_helper
INFO - 2020-10-19 03:30:14 --> Database Driver Class Initialized
DEBUG - 2020-10-19 03:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 03:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 03:30:14 --> Controller Class Initialized
DEBUG - 2020-10-19 03:30:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-19 03:30:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-19 03:30:14 --> Final output sent to browser
DEBUG - 2020-10-19 03:30:15 --> Total execution time: 0.2995
INFO - 2020-10-19 03:30:15 --> Config Class Initialized
INFO - 2020-10-19 03:30:15 --> Hooks Class Initialized
DEBUG - 2020-10-19 03:30:15 --> UTF-8 Support Enabled
INFO - 2020-10-19 03:30:15 --> Utf8 Class Initialized
INFO - 2020-10-19 03:30:15 --> URI Class Initialized
INFO - 2020-10-19 03:30:15 --> Router Class Initialized
INFO - 2020-10-19 03:30:15 --> Output Class Initialized
INFO - 2020-10-19 03:30:15 --> Security Class Initialized
DEBUG - 2020-10-19 03:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 03:30:15 --> Input Class Initialized
INFO - 2020-10-19 03:30:15 --> Language Class Initialized
INFO - 2020-10-19 03:30:15 --> Language Class Initialized
INFO - 2020-10-19 03:30:15 --> Config Class Initialized
INFO - 2020-10-19 03:30:15 --> Loader Class Initialized
INFO - 2020-10-19 03:30:15 --> Helper loaded: url_helper
INFO - 2020-10-19 03:30:15 --> Helper loaded: file_helper
INFO - 2020-10-19 03:30:15 --> Helper loaded: form_helper
INFO - 2020-10-19 03:30:15 --> Helper loaded: my_helper
INFO - 2020-10-19 03:30:15 --> Database Driver Class Initialized
DEBUG - 2020-10-19 03:30:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 03:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 03:30:15 --> Controller Class Initialized
INFO - 2020-10-19 03:30:16 --> Config Class Initialized
INFO - 2020-10-19 03:30:16 --> Hooks Class Initialized
DEBUG - 2020-10-19 03:30:16 --> UTF-8 Support Enabled
INFO - 2020-10-19 03:30:16 --> Utf8 Class Initialized
INFO - 2020-10-19 03:30:16 --> URI Class Initialized
INFO - 2020-10-19 03:30:16 --> Router Class Initialized
INFO - 2020-10-19 03:30:16 --> Output Class Initialized
INFO - 2020-10-19 03:30:16 --> Security Class Initialized
DEBUG - 2020-10-19 03:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 03:30:16 --> Input Class Initialized
INFO - 2020-10-19 03:30:16 --> Language Class Initialized
INFO - 2020-10-19 03:30:16 --> Language Class Initialized
INFO - 2020-10-19 03:30:17 --> Config Class Initialized
INFO - 2020-10-19 03:30:17 --> Loader Class Initialized
INFO - 2020-10-19 03:30:17 --> Helper loaded: url_helper
INFO - 2020-10-19 03:30:17 --> Helper loaded: file_helper
INFO - 2020-10-19 03:30:17 --> Helper loaded: form_helper
INFO - 2020-10-19 03:30:17 --> Helper loaded: my_helper
INFO - 2020-10-19 03:30:17 --> Database Driver Class Initialized
DEBUG - 2020-10-19 03:30:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 03:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 03:30:17 --> Controller Class Initialized
INFO - 2020-10-19 03:30:17 --> Final output sent to browser
DEBUG - 2020-10-19 03:30:17 --> Total execution time: 0.2864
INFO - 2020-10-19 03:30:25 --> Config Class Initialized
INFO - 2020-10-19 03:30:25 --> Hooks Class Initialized
DEBUG - 2020-10-19 03:30:25 --> UTF-8 Support Enabled
INFO - 2020-10-19 03:30:25 --> Utf8 Class Initialized
INFO - 2020-10-19 03:30:25 --> URI Class Initialized
INFO - 2020-10-19 03:30:25 --> Router Class Initialized
INFO - 2020-10-19 03:30:25 --> Output Class Initialized
INFO - 2020-10-19 03:30:25 --> Security Class Initialized
DEBUG - 2020-10-19 03:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 03:30:25 --> Input Class Initialized
INFO - 2020-10-19 03:30:25 --> Language Class Initialized
INFO - 2020-10-19 03:30:25 --> Language Class Initialized
INFO - 2020-10-19 03:30:25 --> Config Class Initialized
INFO - 2020-10-19 03:30:25 --> Loader Class Initialized
INFO - 2020-10-19 03:30:25 --> Helper loaded: url_helper
INFO - 2020-10-19 03:30:25 --> Helper loaded: file_helper
INFO - 2020-10-19 03:30:25 --> Helper loaded: form_helper
INFO - 2020-10-19 03:30:25 --> Helper loaded: my_helper
INFO - 2020-10-19 03:30:25 --> Database Driver Class Initialized
DEBUG - 2020-10-19 03:30:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 03:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 03:30:25 --> Controller Class Initialized
INFO - 2020-10-19 03:30:25 --> Final output sent to browser
DEBUG - 2020-10-19 03:30:25 --> Total execution time: 0.2311
INFO - 2020-10-19 03:32:04 --> Config Class Initialized
INFO - 2020-10-19 03:32:04 --> Hooks Class Initialized
DEBUG - 2020-10-19 03:32:04 --> UTF-8 Support Enabled
INFO - 2020-10-19 03:32:04 --> Utf8 Class Initialized
INFO - 2020-10-19 03:32:04 --> URI Class Initialized
INFO - 2020-10-19 03:32:04 --> Router Class Initialized
INFO - 2020-10-19 03:32:04 --> Output Class Initialized
INFO - 2020-10-19 03:32:04 --> Security Class Initialized
DEBUG - 2020-10-19 03:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 03:32:04 --> Input Class Initialized
INFO - 2020-10-19 03:32:04 --> Language Class Initialized
INFO - 2020-10-19 03:32:04 --> Language Class Initialized
INFO - 2020-10-19 03:32:04 --> Config Class Initialized
INFO - 2020-10-19 03:32:04 --> Loader Class Initialized
INFO - 2020-10-19 03:32:04 --> Helper loaded: url_helper
INFO - 2020-10-19 03:32:04 --> Helper loaded: file_helper
INFO - 2020-10-19 03:32:04 --> Helper loaded: form_helper
INFO - 2020-10-19 03:32:04 --> Helper loaded: my_helper
INFO - 2020-10-19 03:32:04 --> Database Driver Class Initialized
DEBUG - 2020-10-19 03:32:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 03:32:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 03:32:05 --> Controller Class Initialized
INFO - 2020-10-19 03:32:05 --> Final output sent to browser
DEBUG - 2020-10-19 03:32:05 --> Total execution time: 0.2504
INFO - 2020-10-19 03:42:29 --> Config Class Initialized
INFO - 2020-10-19 03:42:29 --> Hooks Class Initialized
DEBUG - 2020-10-19 03:42:29 --> UTF-8 Support Enabled
INFO - 2020-10-19 03:42:29 --> Utf8 Class Initialized
INFO - 2020-10-19 03:42:29 --> URI Class Initialized
INFO - 2020-10-19 03:42:29 --> Router Class Initialized
INFO - 2020-10-19 03:42:29 --> Output Class Initialized
INFO - 2020-10-19 03:42:29 --> Security Class Initialized
DEBUG - 2020-10-19 03:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 03:42:29 --> Input Class Initialized
INFO - 2020-10-19 03:42:29 --> Language Class Initialized
INFO - 2020-10-19 03:42:29 --> Language Class Initialized
INFO - 2020-10-19 03:42:29 --> Config Class Initialized
INFO - 2020-10-19 03:42:29 --> Loader Class Initialized
INFO - 2020-10-19 03:42:29 --> Helper loaded: url_helper
INFO - 2020-10-19 03:42:29 --> Helper loaded: file_helper
INFO - 2020-10-19 03:42:29 --> Helper loaded: form_helper
INFO - 2020-10-19 03:42:29 --> Helper loaded: my_helper
INFO - 2020-10-19 03:42:29 --> Database Driver Class Initialized
DEBUG - 2020-10-19 03:42:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 03:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 03:42:29 --> Controller Class Initialized
INFO - 2020-10-19 03:42:29 --> Final output sent to browser
DEBUG - 2020-10-19 03:42:29 --> Total execution time: 0.2515
INFO - 2020-10-19 03:46:47 --> Config Class Initialized
INFO - 2020-10-19 03:46:47 --> Hooks Class Initialized
DEBUG - 2020-10-19 03:46:47 --> UTF-8 Support Enabled
INFO - 2020-10-19 03:46:47 --> Utf8 Class Initialized
INFO - 2020-10-19 03:46:47 --> URI Class Initialized
INFO - 2020-10-19 03:46:47 --> Router Class Initialized
INFO - 2020-10-19 03:46:47 --> Output Class Initialized
INFO - 2020-10-19 03:46:47 --> Security Class Initialized
DEBUG - 2020-10-19 03:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 03:46:47 --> Input Class Initialized
INFO - 2020-10-19 03:46:47 --> Language Class Initialized
INFO - 2020-10-19 03:46:47 --> Language Class Initialized
INFO - 2020-10-19 03:46:47 --> Config Class Initialized
INFO - 2020-10-19 03:46:47 --> Loader Class Initialized
INFO - 2020-10-19 03:46:47 --> Helper loaded: url_helper
INFO - 2020-10-19 03:46:47 --> Helper loaded: file_helper
INFO - 2020-10-19 03:46:47 --> Helper loaded: form_helper
INFO - 2020-10-19 03:46:47 --> Helper loaded: my_helper
INFO - 2020-10-19 03:46:47 --> Database Driver Class Initialized
DEBUG - 2020-10-19 03:46:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 03:46:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 03:46:47 --> Controller Class Initialized
DEBUG - 2020-10-19 03:46:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-19 03:46:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-19 03:46:47 --> Final output sent to browser
DEBUG - 2020-10-19 03:46:47 --> Total execution time: 0.2853
INFO - 2020-10-19 03:46:47 --> Config Class Initialized
INFO - 2020-10-19 03:46:47 --> Hooks Class Initialized
DEBUG - 2020-10-19 03:46:47 --> UTF-8 Support Enabled
INFO - 2020-10-19 03:46:47 --> Utf8 Class Initialized
INFO - 2020-10-19 03:46:47 --> URI Class Initialized
INFO - 2020-10-19 03:46:47 --> Router Class Initialized
INFO - 2020-10-19 03:46:47 --> Output Class Initialized
INFO - 2020-10-19 03:46:47 --> Security Class Initialized
DEBUG - 2020-10-19 03:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 03:46:47 --> Input Class Initialized
INFO - 2020-10-19 03:46:47 --> Language Class Initialized
INFO - 2020-10-19 03:46:47 --> Language Class Initialized
INFO - 2020-10-19 03:46:47 --> Config Class Initialized
INFO - 2020-10-19 03:46:47 --> Loader Class Initialized
INFO - 2020-10-19 03:46:47 --> Helper loaded: url_helper
INFO - 2020-10-19 03:46:47 --> Helper loaded: file_helper
INFO - 2020-10-19 03:46:47 --> Helper loaded: form_helper
INFO - 2020-10-19 03:46:47 --> Helper loaded: my_helper
INFO - 2020-10-19 03:46:47 --> Database Driver Class Initialized
DEBUG - 2020-10-19 03:46:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 03:46:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 03:46:47 --> Controller Class Initialized
INFO - 2020-10-19 03:46:49 --> Config Class Initialized
INFO - 2020-10-19 03:46:49 --> Hooks Class Initialized
DEBUG - 2020-10-19 03:46:49 --> UTF-8 Support Enabled
INFO - 2020-10-19 03:46:49 --> Utf8 Class Initialized
INFO - 2020-10-19 03:46:49 --> URI Class Initialized
INFO - 2020-10-19 03:46:49 --> Router Class Initialized
INFO - 2020-10-19 03:46:49 --> Output Class Initialized
INFO - 2020-10-19 03:46:49 --> Security Class Initialized
DEBUG - 2020-10-19 03:46:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 03:46:49 --> Input Class Initialized
INFO - 2020-10-19 03:46:49 --> Language Class Initialized
INFO - 2020-10-19 03:46:49 --> Language Class Initialized
INFO - 2020-10-19 03:46:49 --> Config Class Initialized
INFO - 2020-10-19 03:46:49 --> Loader Class Initialized
INFO - 2020-10-19 03:46:49 --> Helper loaded: url_helper
INFO - 2020-10-19 03:46:49 --> Helper loaded: file_helper
INFO - 2020-10-19 03:46:49 --> Helper loaded: form_helper
INFO - 2020-10-19 03:46:49 --> Helper loaded: my_helper
INFO - 2020-10-19 03:46:49 --> Database Driver Class Initialized
DEBUG - 2020-10-19 03:46:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 03:46:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 03:46:49 --> Controller Class Initialized
INFO - 2020-10-19 03:46:49 --> Final output sent to browser
DEBUG - 2020-10-19 03:46:49 --> Total execution time: 0.2499
INFO - 2020-10-19 03:47:00 --> Config Class Initialized
INFO - 2020-10-19 03:47:00 --> Hooks Class Initialized
DEBUG - 2020-10-19 03:47:00 --> UTF-8 Support Enabled
INFO - 2020-10-19 03:47:00 --> Utf8 Class Initialized
INFO - 2020-10-19 03:47:00 --> URI Class Initialized
INFO - 2020-10-19 03:47:00 --> Router Class Initialized
INFO - 2020-10-19 03:47:00 --> Output Class Initialized
INFO - 2020-10-19 03:47:00 --> Security Class Initialized
DEBUG - 2020-10-19 03:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 03:47:00 --> Input Class Initialized
INFO - 2020-10-19 03:47:00 --> Language Class Initialized
INFO - 2020-10-19 03:47:00 --> Language Class Initialized
INFO - 2020-10-19 03:47:00 --> Config Class Initialized
INFO - 2020-10-19 03:47:00 --> Loader Class Initialized
INFO - 2020-10-19 03:47:00 --> Helper loaded: url_helper
INFO - 2020-10-19 03:47:00 --> Helper loaded: file_helper
INFO - 2020-10-19 03:47:00 --> Helper loaded: form_helper
INFO - 2020-10-19 03:47:00 --> Helper loaded: my_helper
INFO - 2020-10-19 03:47:00 --> Database Driver Class Initialized
DEBUG - 2020-10-19 03:47:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 03:47:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 03:47:00 --> Controller Class Initialized
DEBUG - 2020-10-19 03:47:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-19 03:47:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-19 03:47:00 --> Final output sent to browser
DEBUG - 2020-10-19 03:47:00 --> Total execution time: 0.2607
INFO - 2020-10-19 03:47:00 --> Config Class Initialized
INFO - 2020-10-19 03:47:00 --> Hooks Class Initialized
DEBUG - 2020-10-19 03:47:00 --> UTF-8 Support Enabled
INFO - 2020-10-19 03:47:00 --> Utf8 Class Initialized
INFO - 2020-10-19 03:47:00 --> URI Class Initialized
INFO - 2020-10-19 03:47:00 --> Router Class Initialized
INFO - 2020-10-19 03:47:00 --> Output Class Initialized
INFO - 2020-10-19 03:47:00 --> Security Class Initialized
DEBUG - 2020-10-19 03:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 03:47:00 --> Input Class Initialized
INFO - 2020-10-19 03:47:00 --> Language Class Initialized
INFO - 2020-10-19 03:47:00 --> Language Class Initialized
INFO - 2020-10-19 03:47:00 --> Config Class Initialized
INFO - 2020-10-19 03:47:00 --> Loader Class Initialized
INFO - 2020-10-19 03:47:00 --> Helper loaded: url_helper
INFO - 2020-10-19 03:47:00 --> Helper loaded: file_helper
INFO - 2020-10-19 03:47:00 --> Helper loaded: form_helper
INFO - 2020-10-19 03:47:00 --> Helper loaded: my_helper
INFO - 2020-10-19 03:47:00 --> Database Driver Class Initialized
DEBUG - 2020-10-19 03:47:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 03:47:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 03:47:00 --> Controller Class Initialized
INFO - 2020-10-19 03:47:01 --> Config Class Initialized
INFO - 2020-10-19 03:47:01 --> Hooks Class Initialized
DEBUG - 2020-10-19 03:47:01 --> UTF-8 Support Enabled
INFO - 2020-10-19 03:47:01 --> Utf8 Class Initialized
INFO - 2020-10-19 03:47:01 --> URI Class Initialized
INFO - 2020-10-19 03:47:01 --> Router Class Initialized
INFO - 2020-10-19 03:47:01 --> Output Class Initialized
INFO - 2020-10-19 03:47:01 --> Security Class Initialized
DEBUG - 2020-10-19 03:47:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 03:47:01 --> Input Class Initialized
INFO - 2020-10-19 03:47:01 --> Language Class Initialized
INFO - 2020-10-19 03:47:01 --> Language Class Initialized
INFO - 2020-10-19 03:47:01 --> Config Class Initialized
INFO - 2020-10-19 03:47:01 --> Loader Class Initialized
INFO - 2020-10-19 03:47:01 --> Helper loaded: url_helper
INFO - 2020-10-19 03:47:01 --> Helper loaded: file_helper
INFO - 2020-10-19 03:47:01 --> Helper loaded: form_helper
INFO - 2020-10-19 03:47:01 --> Helper loaded: my_helper
INFO - 2020-10-19 03:47:01 --> Database Driver Class Initialized
DEBUG - 2020-10-19 03:47:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 03:47:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 03:47:01 --> Controller Class Initialized
INFO - 2020-10-19 03:47:01 --> Final output sent to browser
DEBUG - 2020-10-19 03:47:01 --> Total execution time: 0.2813
INFO - 2020-10-19 03:47:35 --> Config Class Initialized
INFO - 2020-10-19 03:47:35 --> Hooks Class Initialized
DEBUG - 2020-10-19 03:47:35 --> UTF-8 Support Enabled
INFO - 2020-10-19 03:47:35 --> Utf8 Class Initialized
INFO - 2020-10-19 03:47:35 --> URI Class Initialized
INFO - 2020-10-19 03:47:35 --> Router Class Initialized
INFO - 2020-10-19 03:47:35 --> Output Class Initialized
INFO - 2020-10-19 03:47:35 --> Security Class Initialized
DEBUG - 2020-10-19 03:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 03:47:35 --> Input Class Initialized
INFO - 2020-10-19 03:47:35 --> Language Class Initialized
INFO - 2020-10-19 03:47:35 --> Language Class Initialized
INFO - 2020-10-19 03:47:35 --> Config Class Initialized
INFO - 2020-10-19 03:47:35 --> Loader Class Initialized
INFO - 2020-10-19 03:47:35 --> Helper loaded: url_helper
INFO - 2020-10-19 03:47:35 --> Helper loaded: file_helper
INFO - 2020-10-19 03:47:35 --> Helper loaded: form_helper
INFO - 2020-10-19 03:47:35 --> Helper loaded: my_helper
INFO - 2020-10-19 03:47:35 --> Database Driver Class Initialized
DEBUG - 2020-10-19 03:47:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 03:47:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 03:47:35 --> Controller Class Initialized
ERROR - 2020-10-19 03:47:35 --> Severity: Notice --> Undefined index: kode_singkat C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
ERROR - 2020-10-19 03:47:35 --> Query error: Column count doesn't match value count at row 1 - Invalid query: INSERT INTO m_mapel (kelompok, nama, kd_singkat) VALUES ('Pendidikan Agama Islam', '')
INFO - 2020-10-19 03:47:35 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-19 03:47:38 --> Config Class Initialized
INFO - 2020-10-19 03:47:38 --> Hooks Class Initialized
DEBUG - 2020-10-19 03:47:38 --> UTF-8 Support Enabled
INFO - 2020-10-19 03:47:38 --> Utf8 Class Initialized
INFO - 2020-10-19 03:47:38 --> URI Class Initialized
INFO - 2020-10-19 03:47:38 --> Router Class Initialized
INFO - 2020-10-19 03:47:38 --> Output Class Initialized
INFO - 2020-10-19 03:47:38 --> Security Class Initialized
DEBUG - 2020-10-19 03:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 03:47:38 --> Input Class Initialized
INFO - 2020-10-19 03:47:38 --> Language Class Initialized
INFO - 2020-10-19 03:47:38 --> Language Class Initialized
INFO - 2020-10-19 03:47:38 --> Config Class Initialized
INFO - 2020-10-19 03:47:38 --> Loader Class Initialized
INFO - 2020-10-19 03:47:38 --> Helper loaded: url_helper
INFO - 2020-10-19 03:47:38 --> Helper loaded: file_helper
INFO - 2020-10-19 03:47:38 --> Helper loaded: form_helper
INFO - 2020-10-19 03:47:38 --> Helper loaded: my_helper
INFO - 2020-10-19 03:47:38 --> Database Driver Class Initialized
DEBUG - 2020-10-19 03:47:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 03:47:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 03:47:38 --> Controller Class Initialized
ERROR - 2020-10-19 03:47:38 --> Severity: Notice --> Undefined index: kode_singkat C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
ERROR - 2020-10-19 03:47:38 --> Query error: Column count doesn't match value count at row 1 - Invalid query: INSERT INTO m_mapel (kelompok, nama, kd_singkat) VALUES ('Pendidikan Agama Islam', '')
INFO - 2020-10-19 03:47:38 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-19 03:47:39 --> Config Class Initialized
INFO - 2020-10-19 03:47:39 --> Hooks Class Initialized
DEBUG - 2020-10-19 03:47:39 --> UTF-8 Support Enabled
INFO - 2020-10-19 03:47:39 --> Utf8 Class Initialized
INFO - 2020-10-19 03:47:39 --> URI Class Initialized
INFO - 2020-10-19 03:47:39 --> Router Class Initialized
INFO - 2020-10-19 03:47:39 --> Output Class Initialized
INFO - 2020-10-19 03:47:39 --> Security Class Initialized
DEBUG - 2020-10-19 03:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 03:47:39 --> Input Class Initialized
INFO - 2020-10-19 03:47:39 --> Language Class Initialized
INFO - 2020-10-19 03:47:39 --> Language Class Initialized
INFO - 2020-10-19 03:47:39 --> Config Class Initialized
INFO - 2020-10-19 03:47:39 --> Loader Class Initialized
INFO - 2020-10-19 03:47:39 --> Helper loaded: url_helper
INFO - 2020-10-19 03:47:39 --> Helper loaded: file_helper
INFO - 2020-10-19 03:47:39 --> Helper loaded: form_helper
INFO - 2020-10-19 03:47:39 --> Helper loaded: my_helper
INFO - 2020-10-19 03:47:39 --> Database Driver Class Initialized
DEBUG - 2020-10-19 03:47:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 03:47:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 03:47:39 --> Controller Class Initialized
ERROR - 2020-10-19 03:47:39 --> Severity: Notice --> Undefined index: kode_singkat C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
ERROR - 2020-10-19 03:47:39 --> Query error: Column count doesn't match value count at row 1 - Invalid query: INSERT INTO m_mapel (kelompok, nama, kd_singkat) VALUES ('Pendidikan Agama Islam', '')
INFO - 2020-10-19 03:47:39 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-19 03:50:41 --> Config Class Initialized
INFO - 2020-10-19 03:50:41 --> Hooks Class Initialized
DEBUG - 2020-10-19 03:50:41 --> UTF-8 Support Enabled
INFO - 2020-10-19 03:50:41 --> Utf8 Class Initialized
INFO - 2020-10-19 03:50:41 --> URI Class Initialized
INFO - 2020-10-19 03:50:41 --> Router Class Initialized
INFO - 2020-10-19 03:50:41 --> Output Class Initialized
INFO - 2020-10-19 03:50:41 --> Security Class Initialized
DEBUG - 2020-10-19 03:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 03:50:41 --> Input Class Initialized
INFO - 2020-10-19 03:50:41 --> Language Class Initialized
INFO - 2020-10-19 03:50:41 --> Language Class Initialized
INFO - 2020-10-19 03:50:41 --> Config Class Initialized
INFO - 2020-10-19 03:50:41 --> Loader Class Initialized
INFO - 2020-10-19 03:50:41 --> Helper loaded: url_helper
INFO - 2020-10-19 03:50:41 --> Helper loaded: file_helper
INFO - 2020-10-19 03:50:41 --> Helper loaded: form_helper
INFO - 2020-10-19 03:50:41 --> Helper loaded: my_helper
INFO - 2020-10-19 03:50:42 --> Database Driver Class Initialized
DEBUG - 2020-10-19 03:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 03:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 03:50:42 --> Controller Class Initialized
DEBUG - 2020-10-19 03:50:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-19 03:50:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-19 03:50:42 --> Final output sent to browser
DEBUG - 2020-10-19 03:50:42 --> Total execution time: 0.2732
INFO - 2020-10-19 03:50:42 --> Config Class Initialized
INFO - 2020-10-19 03:50:42 --> Hooks Class Initialized
DEBUG - 2020-10-19 03:50:42 --> UTF-8 Support Enabled
INFO - 2020-10-19 03:50:42 --> Utf8 Class Initialized
INFO - 2020-10-19 03:50:42 --> URI Class Initialized
INFO - 2020-10-19 03:50:42 --> Router Class Initialized
INFO - 2020-10-19 03:50:42 --> Output Class Initialized
INFO - 2020-10-19 03:50:42 --> Security Class Initialized
DEBUG - 2020-10-19 03:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 03:50:42 --> Input Class Initialized
INFO - 2020-10-19 03:50:42 --> Language Class Initialized
INFO - 2020-10-19 03:50:42 --> Language Class Initialized
INFO - 2020-10-19 03:50:42 --> Config Class Initialized
INFO - 2020-10-19 03:50:42 --> Loader Class Initialized
INFO - 2020-10-19 03:50:42 --> Helper loaded: url_helper
INFO - 2020-10-19 03:50:42 --> Helper loaded: file_helper
INFO - 2020-10-19 03:50:42 --> Helper loaded: form_helper
INFO - 2020-10-19 03:50:42 --> Helper loaded: my_helper
INFO - 2020-10-19 03:50:42 --> Database Driver Class Initialized
DEBUG - 2020-10-19 03:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 03:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 03:50:42 --> Controller Class Initialized
INFO - 2020-10-19 03:50:43 --> Config Class Initialized
INFO - 2020-10-19 03:50:43 --> Hooks Class Initialized
DEBUG - 2020-10-19 03:50:43 --> UTF-8 Support Enabled
INFO - 2020-10-19 03:50:43 --> Utf8 Class Initialized
INFO - 2020-10-19 03:50:43 --> URI Class Initialized
INFO - 2020-10-19 03:50:43 --> Router Class Initialized
INFO - 2020-10-19 03:50:43 --> Output Class Initialized
INFO - 2020-10-19 03:50:43 --> Security Class Initialized
DEBUG - 2020-10-19 03:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 03:50:43 --> Input Class Initialized
INFO - 2020-10-19 03:50:43 --> Language Class Initialized
INFO - 2020-10-19 03:50:43 --> Language Class Initialized
INFO - 2020-10-19 03:50:43 --> Config Class Initialized
INFO - 2020-10-19 03:50:43 --> Loader Class Initialized
INFO - 2020-10-19 03:50:43 --> Helper loaded: url_helper
INFO - 2020-10-19 03:50:43 --> Helper loaded: file_helper
INFO - 2020-10-19 03:50:43 --> Helper loaded: form_helper
INFO - 2020-10-19 03:50:43 --> Helper loaded: my_helper
INFO - 2020-10-19 03:50:43 --> Database Driver Class Initialized
DEBUG - 2020-10-19 03:50:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 03:50:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 03:50:43 --> Controller Class Initialized
INFO - 2020-10-19 03:50:43 --> Final output sent to browser
DEBUG - 2020-10-19 03:50:43 --> Total execution time: 0.2657
INFO - 2020-10-19 03:50:57 --> Config Class Initialized
INFO - 2020-10-19 03:50:57 --> Hooks Class Initialized
DEBUG - 2020-10-19 03:50:57 --> UTF-8 Support Enabled
INFO - 2020-10-19 03:50:57 --> Utf8 Class Initialized
INFO - 2020-10-19 03:50:57 --> URI Class Initialized
INFO - 2020-10-19 03:50:57 --> Router Class Initialized
INFO - 2020-10-19 03:50:57 --> Output Class Initialized
INFO - 2020-10-19 03:50:57 --> Security Class Initialized
DEBUG - 2020-10-19 03:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 03:50:57 --> Input Class Initialized
INFO - 2020-10-19 03:50:57 --> Language Class Initialized
INFO - 2020-10-19 03:50:57 --> Language Class Initialized
INFO - 2020-10-19 03:50:57 --> Config Class Initialized
INFO - 2020-10-19 03:50:57 --> Loader Class Initialized
INFO - 2020-10-19 03:50:58 --> Helper loaded: url_helper
INFO - 2020-10-19 03:50:58 --> Helper loaded: file_helper
INFO - 2020-10-19 03:50:58 --> Helper loaded: form_helper
INFO - 2020-10-19 03:50:58 --> Helper loaded: my_helper
INFO - 2020-10-19 03:50:58 --> Database Driver Class Initialized
DEBUG - 2020-10-19 03:50:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 03:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 03:50:58 --> Controller Class Initialized
ERROR - 2020-10-19 03:50:58 --> Severity: Notice --> Undefined index: kode_singkat C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
ERROR - 2020-10-19 03:50:58 --> Query error: Column count doesn't match value count at row 1 - Invalid query: INSERT INTO m_mapel (kelompok, nama, kd_singkat) VALUES ('Pendidikan Agama Islam', '')
INFO - 2020-10-19 03:50:58 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-19 03:50:59 --> Config Class Initialized
INFO - 2020-10-19 03:50:59 --> Hooks Class Initialized
DEBUG - 2020-10-19 03:50:59 --> UTF-8 Support Enabled
INFO - 2020-10-19 03:50:59 --> Utf8 Class Initialized
INFO - 2020-10-19 03:50:59 --> URI Class Initialized
INFO - 2020-10-19 03:50:59 --> Router Class Initialized
INFO - 2020-10-19 03:50:59 --> Output Class Initialized
INFO - 2020-10-19 03:50:59 --> Security Class Initialized
DEBUG - 2020-10-19 03:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 03:50:59 --> Input Class Initialized
INFO - 2020-10-19 03:50:59 --> Language Class Initialized
INFO - 2020-10-19 03:50:59 --> Language Class Initialized
INFO - 2020-10-19 03:50:59 --> Config Class Initialized
INFO - 2020-10-19 03:50:59 --> Loader Class Initialized
INFO - 2020-10-19 03:50:59 --> Helper loaded: url_helper
INFO - 2020-10-19 03:50:59 --> Helper loaded: file_helper
INFO - 2020-10-19 03:50:59 --> Helper loaded: form_helper
INFO - 2020-10-19 03:50:59 --> Helper loaded: my_helper
INFO - 2020-10-19 03:50:59 --> Database Driver Class Initialized
DEBUG - 2020-10-19 03:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 03:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 03:50:59 --> Controller Class Initialized
ERROR - 2020-10-19 03:50:59 --> Severity: Notice --> Undefined index: kode_singkat C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
ERROR - 2020-10-19 03:50:59 --> Query error: Column count doesn't match value count at row 1 - Invalid query: INSERT INTO m_mapel (kelompok, nama, kd_singkat) VALUES ('Pendidikan Agama Islam', '')
INFO - 2020-10-19 03:50:59 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-19 03:51:25 --> Config Class Initialized
INFO - 2020-10-19 03:51:25 --> Hooks Class Initialized
DEBUG - 2020-10-19 03:51:25 --> UTF-8 Support Enabled
INFO - 2020-10-19 03:51:25 --> Utf8 Class Initialized
INFO - 2020-10-19 03:51:25 --> URI Class Initialized
INFO - 2020-10-19 03:51:25 --> Router Class Initialized
INFO - 2020-10-19 03:51:25 --> Output Class Initialized
INFO - 2020-10-19 03:51:25 --> Security Class Initialized
DEBUG - 2020-10-19 03:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 03:51:25 --> Input Class Initialized
INFO - 2020-10-19 03:51:25 --> Language Class Initialized
INFO - 2020-10-19 03:51:25 --> Language Class Initialized
INFO - 2020-10-19 03:51:25 --> Config Class Initialized
INFO - 2020-10-19 03:51:25 --> Loader Class Initialized
INFO - 2020-10-19 03:51:25 --> Helper loaded: url_helper
INFO - 2020-10-19 03:51:25 --> Helper loaded: file_helper
INFO - 2020-10-19 03:51:25 --> Helper loaded: form_helper
INFO - 2020-10-19 03:51:25 --> Helper loaded: my_helper
INFO - 2020-10-19 03:51:25 --> Database Driver Class Initialized
DEBUG - 2020-10-19 03:51:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 03:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 03:51:25 --> Controller Class Initialized
ERROR - 2020-10-19 03:51:25 --> Severity: Notice --> Undefined index: kode_singkat C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
ERROR - 2020-10-19 03:51:25 --> Query error: Column count doesn't match value count at row 1 - Invalid query: INSERT INTO m_mapel (kelompok, nama, kd_singkat) VALUES ('Pendidikan Agama Islam', '')
INFO - 2020-10-19 03:51:25 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-19 03:55:36 --> Config Class Initialized
INFO - 2020-10-19 03:55:36 --> Hooks Class Initialized
DEBUG - 2020-10-19 03:55:36 --> UTF-8 Support Enabled
INFO - 2020-10-19 03:55:36 --> Utf8 Class Initialized
INFO - 2020-10-19 03:55:36 --> URI Class Initialized
INFO - 2020-10-19 03:55:36 --> Router Class Initialized
INFO - 2020-10-19 03:55:36 --> Output Class Initialized
INFO - 2020-10-19 03:55:36 --> Security Class Initialized
DEBUG - 2020-10-19 03:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 03:55:36 --> Input Class Initialized
INFO - 2020-10-19 03:55:36 --> Language Class Initialized
INFO - 2020-10-19 03:55:36 --> Language Class Initialized
INFO - 2020-10-19 03:55:36 --> Config Class Initialized
INFO - 2020-10-19 03:55:36 --> Loader Class Initialized
INFO - 2020-10-19 03:55:36 --> Helper loaded: url_helper
INFO - 2020-10-19 03:55:36 --> Helper loaded: file_helper
INFO - 2020-10-19 03:55:36 --> Helper loaded: form_helper
INFO - 2020-10-19 03:55:36 --> Helper loaded: my_helper
INFO - 2020-10-19 03:55:36 --> Database Driver Class Initialized
DEBUG - 2020-10-19 03:55:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 03:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 03:55:36 --> Controller Class Initialized
INFO - 2020-10-19 03:55:36 --> Final output sent to browser
DEBUG - 2020-10-19 03:55:36 --> Total execution time: 0.2902
INFO - 2020-10-19 03:57:11 --> Config Class Initialized
INFO - 2020-10-19 03:57:11 --> Hooks Class Initialized
DEBUG - 2020-10-19 03:57:11 --> UTF-8 Support Enabled
INFO - 2020-10-19 03:57:11 --> Utf8 Class Initialized
INFO - 2020-10-19 03:57:11 --> URI Class Initialized
INFO - 2020-10-19 03:57:11 --> Router Class Initialized
INFO - 2020-10-19 03:57:11 --> Output Class Initialized
INFO - 2020-10-19 03:57:11 --> Security Class Initialized
DEBUG - 2020-10-19 03:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 03:57:11 --> Input Class Initialized
INFO - 2020-10-19 03:57:11 --> Language Class Initialized
INFO - 2020-10-19 03:57:11 --> Language Class Initialized
INFO - 2020-10-19 03:57:11 --> Config Class Initialized
INFO - 2020-10-19 03:57:11 --> Loader Class Initialized
INFO - 2020-10-19 03:57:11 --> Helper loaded: url_helper
INFO - 2020-10-19 03:57:11 --> Helper loaded: file_helper
INFO - 2020-10-19 03:57:11 --> Helper loaded: form_helper
INFO - 2020-10-19 03:57:11 --> Helper loaded: my_helper
INFO - 2020-10-19 03:57:11 --> Database Driver Class Initialized
DEBUG - 2020-10-19 03:57:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 03:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 03:57:11 --> Controller Class Initialized
DEBUG - 2020-10-19 03:57:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-19 03:57:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-19 03:57:11 --> Final output sent to browser
DEBUG - 2020-10-19 03:57:11 --> Total execution time: 0.2969
INFO - 2020-10-19 03:57:11 --> Config Class Initialized
INFO - 2020-10-19 03:57:11 --> Hooks Class Initialized
DEBUG - 2020-10-19 03:57:11 --> UTF-8 Support Enabled
INFO - 2020-10-19 03:57:11 --> Utf8 Class Initialized
INFO - 2020-10-19 03:57:11 --> URI Class Initialized
INFO - 2020-10-19 03:57:11 --> Router Class Initialized
INFO - 2020-10-19 03:57:11 --> Output Class Initialized
INFO - 2020-10-19 03:57:11 --> Security Class Initialized
DEBUG - 2020-10-19 03:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 03:57:11 --> Input Class Initialized
INFO - 2020-10-19 03:57:11 --> Language Class Initialized
INFO - 2020-10-19 03:57:11 --> Language Class Initialized
INFO - 2020-10-19 03:57:11 --> Config Class Initialized
INFO - 2020-10-19 03:57:11 --> Loader Class Initialized
INFO - 2020-10-19 03:57:11 --> Helper loaded: url_helper
INFO - 2020-10-19 03:57:11 --> Helper loaded: file_helper
INFO - 2020-10-19 03:57:11 --> Helper loaded: form_helper
INFO - 2020-10-19 03:57:11 --> Helper loaded: my_helper
INFO - 2020-10-19 03:57:11 --> Database Driver Class Initialized
DEBUG - 2020-10-19 03:57:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 03:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 03:57:11 --> Controller Class Initialized
INFO - 2020-10-19 03:57:12 --> Config Class Initialized
INFO - 2020-10-19 03:57:12 --> Hooks Class Initialized
DEBUG - 2020-10-19 03:57:12 --> UTF-8 Support Enabled
INFO - 2020-10-19 03:57:12 --> Utf8 Class Initialized
INFO - 2020-10-19 03:57:13 --> URI Class Initialized
INFO - 2020-10-19 03:57:13 --> Router Class Initialized
INFO - 2020-10-19 03:57:13 --> Output Class Initialized
INFO - 2020-10-19 03:57:13 --> Security Class Initialized
DEBUG - 2020-10-19 03:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 03:57:13 --> Input Class Initialized
INFO - 2020-10-19 03:57:13 --> Language Class Initialized
INFO - 2020-10-19 03:57:13 --> Language Class Initialized
INFO - 2020-10-19 03:57:13 --> Config Class Initialized
INFO - 2020-10-19 03:57:13 --> Loader Class Initialized
INFO - 2020-10-19 03:57:13 --> Helper loaded: url_helper
INFO - 2020-10-19 03:57:13 --> Helper loaded: file_helper
INFO - 2020-10-19 03:57:13 --> Helper loaded: form_helper
INFO - 2020-10-19 03:57:13 --> Helper loaded: my_helper
INFO - 2020-10-19 03:57:13 --> Database Driver Class Initialized
DEBUG - 2020-10-19 03:57:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 03:57:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 03:57:13 --> Controller Class Initialized
INFO - 2020-10-19 03:57:13 --> Final output sent to browser
DEBUG - 2020-10-19 03:57:13 --> Total execution time: 0.2600
INFO - 2020-10-19 03:57:21 --> Config Class Initialized
INFO - 2020-10-19 03:57:21 --> Hooks Class Initialized
DEBUG - 2020-10-19 03:57:21 --> UTF-8 Support Enabled
INFO - 2020-10-19 03:57:21 --> Utf8 Class Initialized
INFO - 2020-10-19 03:57:21 --> URI Class Initialized
INFO - 2020-10-19 03:57:21 --> Router Class Initialized
INFO - 2020-10-19 03:57:21 --> Output Class Initialized
INFO - 2020-10-19 03:57:21 --> Security Class Initialized
DEBUG - 2020-10-19 03:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 03:57:21 --> Input Class Initialized
INFO - 2020-10-19 03:57:21 --> Language Class Initialized
INFO - 2020-10-19 03:57:21 --> Language Class Initialized
INFO - 2020-10-19 03:57:21 --> Config Class Initialized
INFO - 2020-10-19 03:57:21 --> Loader Class Initialized
INFO - 2020-10-19 03:57:21 --> Helper loaded: url_helper
INFO - 2020-10-19 03:57:21 --> Helper loaded: file_helper
INFO - 2020-10-19 03:57:21 --> Helper loaded: form_helper
INFO - 2020-10-19 03:57:21 --> Helper loaded: my_helper
INFO - 2020-10-19 03:57:21 --> Database Driver Class Initialized
DEBUG - 2020-10-19 03:57:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 03:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 03:57:21 --> Controller Class Initialized
ERROR - 2020-10-19 03:57:21 --> Severity: Notice --> Undefined index: kode_singkat C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
ERROR - 2020-10-19 03:57:21 --> Query error: Column count doesn't match value count at row 1 - Invalid query: INSERT INTO m_mapel (kelompok, nama, kd_singkat) VALUES ('Pendidikan Agama Islam', '')
INFO - 2020-10-19 03:57:21 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-19 03:57:23 --> Config Class Initialized
INFO - 2020-10-19 03:57:23 --> Hooks Class Initialized
DEBUG - 2020-10-19 03:57:23 --> UTF-8 Support Enabled
INFO - 2020-10-19 03:57:23 --> Utf8 Class Initialized
INFO - 2020-10-19 03:57:23 --> URI Class Initialized
INFO - 2020-10-19 03:57:23 --> Router Class Initialized
INFO - 2020-10-19 03:57:23 --> Output Class Initialized
INFO - 2020-10-19 03:57:23 --> Security Class Initialized
DEBUG - 2020-10-19 03:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 03:57:23 --> Input Class Initialized
INFO - 2020-10-19 03:57:23 --> Language Class Initialized
INFO - 2020-10-19 03:57:23 --> Language Class Initialized
INFO - 2020-10-19 03:57:23 --> Config Class Initialized
INFO - 2020-10-19 03:57:23 --> Loader Class Initialized
INFO - 2020-10-19 03:57:23 --> Helper loaded: url_helper
INFO - 2020-10-19 03:57:23 --> Helper loaded: file_helper
INFO - 2020-10-19 03:57:23 --> Helper loaded: form_helper
INFO - 2020-10-19 03:57:23 --> Helper loaded: my_helper
INFO - 2020-10-19 03:57:23 --> Database Driver Class Initialized
DEBUG - 2020-10-19 03:57:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 03:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 03:57:23 --> Controller Class Initialized
ERROR - 2020-10-19 03:57:24 --> Severity: Notice --> Undefined index: kode_singkat C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
ERROR - 2020-10-19 03:57:24 --> Query error: Column count doesn't match value count at row 1 - Invalid query: INSERT INTO m_mapel (kelompok, nama, kd_singkat) VALUES ('Pendidikan Agama Islam', '')
INFO - 2020-10-19 03:57:24 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-19 04:03:02 --> Config Class Initialized
INFO - 2020-10-19 04:03:02 --> Hooks Class Initialized
DEBUG - 2020-10-19 04:03:02 --> UTF-8 Support Enabled
INFO - 2020-10-19 04:03:02 --> Utf8 Class Initialized
INFO - 2020-10-19 04:03:02 --> URI Class Initialized
INFO - 2020-10-19 04:03:02 --> Router Class Initialized
INFO - 2020-10-19 04:03:02 --> Output Class Initialized
INFO - 2020-10-19 04:03:02 --> Security Class Initialized
DEBUG - 2020-10-19 04:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 04:03:02 --> Input Class Initialized
INFO - 2020-10-19 04:03:02 --> Language Class Initialized
INFO - 2020-10-19 04:03:02 --> Language Class Initialized
INFO - 2020-10-19 04:03:02 --> Config Class Initialized
INFO - 2020-10-19 04:03:02 --> Loader Class Initialized
INFO - 2020-10-19 04:03:02 --> Helper loaded: url_helper
INFO - 2020-10-19 04:03:02 --> Helper loaded: file_helper
INFO - 2020-10-19 04:03:02 --> Helper loaded: form_helper
INFO - 2020-10-19 04:03:02 --> Helper loaded: my_helper
INFO - 2020-10-19 04:03:02 --> Database Driver Class Initialized
DEBUG - 2020-10-19 04:03:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 04:03:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 04:03:02 --> Controller Class Initialized
ERROR - 2020-10-19 04:03:02 --> Severity: Notice --> Undefined index: kode_singkat C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
ERROR - 2020-10-19 04:03:02 --> Query error: Column count doesn't match value count at row 1 - Invalid query: INSERT INTO m_mapel (kelompok, nama, kd_singkat) VALUES ('Pendidikan Agama Islam', '')
INFO - 2020-10-19 04:03:02 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-19 04:05:55 --> Config Class Initialized
INFO - 2020-10-19 04:05:55 --> Hooks Class Initialized
DEBUG - 2020-10-19 04:05:55 --> UTF-8 Support Enabled
INFO - 2020-10-19 04:05:55 --> Utf8 Class Initialized
INFO - 2020-10-19 04:05:55 --> URI Class Initialized
INFO - 2020-10-19 04:05:55 --> Router Class Initialized
INFO - 2020-10-19 04:05:55 --> Output Class Initialized
INFO - 2020-10-19 04:05:55 --> Security Class Initialized
DEBUG - 2020-10-19 04:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 04:05:55 --> Input Class Initialized
INFO - 2020-10-19 04:05:55 --> Language Class Initialized
INFO - 2020-10-19 04:05:55 --> Language Class Initialized
INFO - 2020-10-19 04:05:55 --> Config Class Initialized
INFO - 2020-10-19 04:05:55 --> Loader Class Initialized
INFO - 2020-10-19 04:05:55 --> Helper loaded: url_helper
INFO - 2020-10-19 04:05:55 --> Helper loaded: file_helper
INFO - 2020-10-19 04:05:55 --> Helper loaded: form_helper
INFO - 2020-10-19 04:05:55 --> Helper loaded: my_helper
INFO - 2020-10-19 04:05:55 --> Database Driver Class Initialized
DEBUG - 2020-10-19 04:05:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 04:05:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 04:05:55 --> Controller Class Initialized
DEBUG - 2020-10-19 04:05:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-19 04:05:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-19 04:05:55 --> Final output sent to browser
DEBUG - 2020-10-19 04:05:55 --> Total execution time: 0.2563
INFO - 2020-10-19 04:05:55 --> Config Class Initialized
INFO - 2020-10-19 04:05:55 --> Hooks Class Initialized
DEBUG - 2020-10-19 04:05:55 --> UTF-8 Support Enabled
INFO - 2020-10-19 04:05:55 --> Utf8 Class Initialized
INFO - 2020-10-19 04:05:55 --> URI Class Initialized
INFO - 2020-10-19 04:05:55 --> Router Class Initialized
INFO - 2020-10-19 04:05:55 --> Output Class Initialized
INFO - 2020-10-19 04:05:55 --> Security Class Initialized
DEBUG - 2020-10-19 04:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 04:05:55 --> Input Class Initialized
INFO - 2020-10-19 04:05:55 --> Language Class Initialized
INFO - 2020-10-19 04:05:55 --> Language Class Initialized
INFO - 2020-10-19 04:05:56 --> Config Class Initialized
INFO - 2020-10-19 04:05:56 --> Loader Class Initialized
INFO - 2020-10-19 04:05:56 --> Helper loaded: url_helper
INFO - 2020-10-19 04:05:56 --> Helper loaded: file_helper
INFO - 2020-10-19 04:05:56 --> Helper loaded: form_helper
INFO - 2020-10-19 04:05:56 --> Helper loaded: my_helper
INFO - 2020-10-19 04:05:56 --> Database Driver Class Initialized
DEBUG - 2020-10-19 04:05:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 04:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 04:05:56 --> Controller Class Initialized
INFO - 2020-10-19 04:05:56 --> Config Class Initialized
INFO - 2020-10-19 04:05:56 --> Hooks Class Initialized
DEBUG - 2020-10-19 04:05:56 --> UTF-8 Support Enabled
INFO - 2020-10-19 04:05:56 --> Utf8 Class Initialized
INFO - 2020-10-19 04:05:56 --> URI Class Initialized
INFO - 2020-10-19 04:05:56 --> Router Class Initialized
INFO - 2020-10-19 04:05:56 --> Output Class Initialized
INFO - 2020-10-19 04:05:56 --> Security Class Initialized
DEBUG - 2020-10-19 04:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 04:05:56 --> Input Class Initialized
INFO - 2020-10-19 04:05:56 --> Language Class Initialized
INFO - 2020-10-19 04:05:56 --> Language Class Initialized
INFO - 2020-10-19 04:05:56 --> Config Class Initialized
INFO - 2020-10-19 04:05:56 --> Loader Class Initialized
INFO - 2020-10-19 04:05:56 --> Helper loaded: url_helper
INFO - 2020-10-19 04:05:56 --> Helper loaded: file_helper
INFO - 2020-10-19 04:05:56 --> Helper loaded: form_helper
INFO - 2020-10-19 04:05:56 --> Helper loaded: my_helper
INFO - 2020-10-19 04:05:56 --> Database Driver Class Initialized
DEBUG - 2020-10-19 04:05:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 04:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 04:05:56 --> Controller Class Initialized
INFO - 2020-10-19 04:05:56 --> Final output sent to browser
DEBUG - 2020-10-19 04:05:56 --> Total execution time: 0.2691
INFO - 2020-10-19 04:06:01 --> Config Class Initialized
INFO - 2020-10-19 04:06:01 --> Hooks Class Initialized
DEBUG - 2020-10-19 04:06:01 --> UTF-8 Support Enabled
INFO - 2020-10-19 04:06:01 --> Utf8 Class Initialized
INFO - 2020-10-19 04:06:01 --> URI Class Initialized
INFO - 2020-10-19 04:06:02 --> Router Class Initialized
INFO - 2020-10-19 04:06:02 --> Output Class Initialized
INFO - 2020-10-19 04:06:02 --> Security Class Initialized
DEBUG - 2020-10-19 04:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 04:06:02 --> Input Class Initialized
INFO - 2020-10-19 04:06:02 --> Language Class Initialized
INFO - 2020-10-19 04:06:02 --> Language Class Initialized
INFO - 2020-10-19 04:06:02 --> Config Class Initialized
INFO - 2020-10-19 04:06:02 --> Loader Class Initialized
INFO - 2020-10-19 04:06:02 --> Helper loaded: url_helper
INFO - 2020-10-19 04:06:02 --> Helper loaded: file_helper
INFO - 2020-10-19 04:06:02 --> Helper loaded: form_helper
INFO - 2020-10-19 04:06:02 --> Helper loaded: my_helper
INFO - 2020-10-19 04:06:02 --> Database Driver Class Initialized
DEBUG - 2020-10-19 04:06:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 04:06:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 04:06:02 --> Controller Class Initialized
ERROR - 2020-10-19 04:06:02 --> Severity: Notice --> Undefined index: Kelompok C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
ERROR - 2020-10-19 04:06:02 --> Severity: Notice --> Undefined index: kode_singkat C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
INFO - 2020-10-19 04:06:02 --> Final output sent to browser
DEBUG - 2020-10-19 04:06:02 --> Total execution time: 0.3037
INFO - 2020-10-19 04:06:04 --> Config Class Initialized
INFO - 2020-10-19 04:06:04 --> Hooks Class Initialized
DEBUG - 2020-10-19 04:06:04 --> UTF-8 Support Enabled
INFO - 2020-10-19 04:06:04 --> Utf8 Class Initialized
INFO - 2020-10-19 04:06:04 --> URI Class Initialized
INFO - 2020-10-19 04:06:04 --> Router Class Initialized
INFO - 2020-10-19 04:06:04 --> Output Class Initialized
INFO - 2020-10-19 04:06:04 --> Security Class Initialized
DEBUG - 2020-10-19 04:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 04:06:04 --> Input Class Initialized
INFO - 2020-10-19 04:06:04 --> Language Class Initialized
INFO - 2020-10-19 04:06:04 --> Language Class Initialized
INFO - 2020-10-19 04:06:04 --> Config Class Initialized
INFO - 2020-10-19 04:06:04 --> Loader Class Initialized
INFO - 2020-10-19 04:06:04 --> Helper loaded: url_helper
INFO - 2020-10-19 04:06:04 --> Helper loaded: file_helper
INFO - 2020-10-19 04:06:04 --> Helper loaded: form_helper
INFO - 2020-10-19 04:06:04 --> Helper loaded: my_helper
INFO - 2020-10-19 04:06:04 --> Database Driver Class Initialized
DEBUG - 2020-10-19 04:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 04:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 04:06:04 --> Controller Class Initialized
ERROR - 2020-10-19 04:06:04 --> Severity: Notice --> Undefined index: Kelompok C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
ERROR - 2020-10-19 04:06:04 --> Severity: Notice --> Undefined index: kode_singkat C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
INFO - 2020-10-19 04:06:04 --> Final output sent to browser
DEBUG - 2020-10-19 04:06:04 --> Total execution time: 0.2672
INFO - 2020-10-19 04:07:13 --> Config Class Initialized
INFO - 2020-10-19 04:07:13 --> Hooks Class Initialized
DEBUG - 2020-10-19 04:07:13 --> UTF-8 Support Enabled
INFO - 2020-10-19 04:07:13 --> Utf8 Class Initialized
INFO - 2020-10-19 04:07:13 --> URI Class Initialized
INFO - 2020-10-19 04:07:13 --> Router Class Initialized
INFO - 2020-10-19 04:07:13 --> Output Class Initialized
INFO - 2020-10-19 04:07:13 --> Security Class Initialized
DEBUG - 2020-10-19 04:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 04:07:13 --> Input Class Initialized
INFO - 2020-10-19 04:07:13 --> Language Class Initialized
INFO - 2020-10-19 04:07:13 --> Language Class Initialized
INFO - 2020-10-19 04:07:13 --> Config Class Initialized
INFO - 2020-10-19 04:07:13 --> Loader Class Initialized
INFO - 2020-10-19 04:07:13 --> Helper loaded: url_helper
INFO - 2020-10-19 04:07:13 --> Helper loaded: file_helper
INFO - 2020-10-19 04:07:13 --> Helper loaded: form_helper
INFO - 2020-10-19 04:07:13 --> Helper loaded: my_helper
INFO - 2020-10-19 04:07:13 --> Database Driver Class Initialized
DEBUG - 2020-10-19 04:07:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 04:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 04:07:13 --> Controller Class Initialized
DEBUG - 2020-10-19 04:07:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-19 04:07:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-19 04:07:14 --> Final output sent to browser
DEBUG - 2020-10-19 04:07:14 --> Total execution time: 0.3500
INFO - 2020-10-19 04:07:14 --> Config Class Initialized
INFO - 2020-10-19 04:07:14 --> Hooks Class Initialized
DEBUG - 2020-10-19 04:07:14 --> UTF-8 Support Enabled
INFO - 2020-10-19 04:07:14 --> Utf8 Class Initialized
INFO - 2020-10-19 04:07:14 --> URI Class Initialized
INFO - 2020-10-19 04:07:14 --> Router Class Initialized
INFO - 2020-10-19 04:07:14 --> Output Class Initialized
INFO - 2020-10-19 04:07:14 --> Security Class Initialized
DEBUG - 2020-10-19 04:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 04:07:14 --> Input Class Initialized
INFO - 2020-10-19 04:07:14 --> Language Class Initialized
INFO - 2020-10-19 04:07:14 --> Language Class Initialized
INFO - 2020-10-19 04:07:14 --> Config Class Initialized
INFO - 2020-10-19 04:07:14 --> Loader Class Initialized
INFO - 2020-10-19 04:07:14 --> Helper loaded: url_helper
INFO - 2020-10-19 04:07:14 --> Helper loaded: file_helper
INFO - 2020-10-19 04:07:14 --> Helper loaded: form_helper
INFO - 2020-10-19 04:07:14 --> Helper loaded: my_helper
INFO - 2020-10-19 04:07:14 --> Database Driver Class Initialized
DEBUG - 2020-10-19 04:07:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 04:07:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 04:07:14 --> Controller Class Initialized
INFO - 2020-10-19 04:07:14 --> Config Class Initialized
INFO - 2020-10-19 04:07:14 --> Hooks Class Initialized
DEBUG - 2020-10-19 04:07:14 --> UTF-8 Support Enabled
INFO - 2020-10-19 04:07:14 --> Utf8 Class Initialized
INFO - 2020-10-19 04:07:14 --> URI Class Initialized
INFO - 2020-10-19 04:07:14 --> Router Class Initialized
INFO - 2020-10-19 04:07:14 --> Output Class Initialized
INFO - 2020-10-19 04:07:14 --> Security Class Initialized
DEBUG - 2020-10-19 04:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 04:07:14 --> Input Class Initialized
INFO - 2020-10-19 04:07:14 --> Language Class Initialized
INFO - 2020-10-19 04:07:14 --> Language Class Initialized
INFO - 2020-10-19 04:07:14 --> Config Class Initialized
INFO - 2020-10-19 04:07:14 --> Loader Class Initialized
INFO - 2020-10-19 04:07:14 --> Helper loaded: url_helper
INFO - 2020-10-19 04:07:14 --> Helper loaded: file_helper
INFO - 2020-10-19 04:07:14 --> Helper loaded: form_helper
INFO - 2020-10-19 04:07:14 --> Helper loaded: my_helper
INFO - 2020-10-19 04:07:14 --> Database Driver Class Initialized
DEBUG - 2020-10-19 04:07:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 04:07:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 04:07:14 --> Controller Class Initialized
INFO - 2020-10-19 04:07:14 --> Final output sent to browser
DEBUG - 2020-10-19 04:07:14 --> Total execution time: 0.2575
INFO - 2020-10-19 04:07:19 --> Config Class Initialized
INFO - 2020-10-19 04:07:19 --> Hooks Class Initialized
DEBUG - 2020-10-19 04:07:19 --> UTF-8 Support Enabled
INFO - 2020-10-19 04:07:19 --> Utf8 Class Initialized
INFO - 2020-10-19 04:07:19 --> URI Class Initialized
INFO - 2020-10-19 04:07:19 --> Router Class Initialized
INFO - 2020-10-19 04:07:19 --> Output Class Initialized
INFO - 2020-10-19 04:07:19 --> Security Class Initialized
DEBUG - 2020-10-19 04:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 04:07:19 --> Input Class Initialized
INFO - 2020-10-19 04:07:19 --> Language Class Initialized
INFO - 2020-10-19 04:07:19 --> Language Class Initialized
INFO - 2020-10-19 04:07:19 --> Config Class Initialized
INFO - 2020-10-19 04:07:19 --> Loader Class Initialized
INFO - 2020-10-19 04:07:19 --> Helper loaded: url_helper
INFO - 2020-10-19 04:07:19 --> Helper loaded: file_helper
INFO - 2020-10-19 04:07:19 --> Helper loaded: form_helper
INFO - 2020-10-19 04:07:19 --> Helper loaded: my_helper
INFO - 2020-10-19 04:07:19 --> Database Driver Class Initialized
DEBUG - 2020-10-19 04:07:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 04:07:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 04:07:19 --> Controller Class Initialized
INFO - 2020-10-19 04:07:19 --> Final output sent to browser
DEBUG - 2020-10-19 04:07:19 --> Total execution time: 0.2915
INFO - 2020-10-19 04:07:19 --> Config Class Initialized
INFO - 2020-10-19 04:07:19 --> Hooks Class Initialized
DEBUG - 2020-10-19 04:07:19 --> UTF-8 Support Enabled
INFO - 2020-10-19 04:07:19 --> Utf8 Class Initialized
INFO - 2020-10-19 04:07:19 --> URI Class Initialized
INFO - 2020-10-19 04:07:19 --> Router Class Initialized
INFO - 2020-10-19 04:07:19 --> Output Class Initialized
INFO - 2020-10-19 04:07:19 --> Security Class Initialized
DEBUG - 2020-10-19 04:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 04:07:19 --> Input Class Initialized
INFO - 2020-10-19 04:07:19 --> Language Class Initialized
INFO - 2020-10-19 04:07:19 --> Language Class Initialized
INFO - 2020-10-19 04:07:19 --> Config Class Initialized
INFO - 2020-10-19 04:07:19 --> Loader Class Initialized
INFO - 2020-10-19 04:07:19 --> Helper loaded: url_helper
INFO - 2020-10-19 04:07:19 --> Helper loaded: file_helper
INFO - 2020-10-19 04:07:19 --> Helper loaded: form_helper
INFO - 2020-10-19 04:07:19 --> Helper loaded: my_helper
INFO - 2020-10-19 04:07:19 --> Database Driver Class Initialized
DEBUG - 2020-10-19 04:07:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 04:07:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 04:07:19 --> Controller Class Initialized
INFO - 2020-10-19 04:07:21 --> Config Class Initialized
INFO - 2020-10-19 04:07:21 --> Hooks Class Initialized
DEBUG - 2020-10-19 04:07:21 --> UTF-8 Support Enabled
INFO - 2020-10-19 04:07:21 --> Utf8 Class Initialized
INFO - 2020-10-19 04:07:21 --> URI Class Initialized
INFO - 2020-10-19 04:07:21 --> Router Class Initialized
INFO - 2020-10-19 04:07:21 --> Output Class Initialized
INFO - 2020-10-19 04:07:22 --> Security Class Initialized
DEBUG - 2020-10-19 04:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 04:07:22 --> Input Class Initialized
INFO - 2020-10-19 04:07:22 --> Language Class Initialized
INFO - 2020-10-19 04:07:22 --> Language Class Initialized
INFO - 2020-10-19 04:07:22 --> Config Class Initialized
INFO - 2020-10-19 04:07:22 --> Loader Class Initialized
INFO - 2020-10-19 04:07:22 --> Helper loaded: url_helper
INFO - 2020-10-19 04:07:22 --> Helper loaded: file_helper
INFO - 2020-10-19 04:07:22 --> Helper loaded: form_helper
INFO - 2020-10-19 04:07:22 --> Helper loaded: my_helper
INFO - 2020-10-19 04:07:22 --> Database Driver Class Initialized
DEBUG - 2020-10-19 04:07:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 04:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 04:07:22 --> Controller Class Initialized
INFO - 2020-10-19 04:07:22 --> Final output sent to browser
DEBUG - 2020-10-19 04:07:22 --> Total execution time: 0.2924
INFO - 2020-10-19 04:07:22 --> Config Class Initialized
INFO - 2020-10-19 04:07:22 --> Hooks Class Initialized
DEBUG - 2020-10-19 04:07:22 --> UTF-8 Support Enabled
INFO - 2020-10-19 04:07:22 --> Utf8 Class Initialized
INFO - 2020-10-19 04:07:22 --> URI Class Initialized
INFO - 2020-10-19 04:07:22 --> Router Class Initialized
INFO - 2020-10-19 04:07:22 --> Output Class Initialized
INFO - 2020-10-19 04:07:22 --> Security Class Initialized
DEBUG - 2020-10-19 04:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 04:07:22 --> Input Class Initialized
INFO - 2020-10-19 04:07:22 --> Language Class Initialized
INFO - 2020-10-19 04:07:22 --> Language Class Initialized
INFO - 2020-10-19 04:07:22 --> Config Class Initialized
INFO - 2020-10-19 04:07:22 --> Loader Class Initialized
INFO - 2020-10-19 04:07:22 --> Helper loaded: url_helper
INFO - 2020-10-19 04:07:22 --> Helper loaded: file_helper
INFO - 2020-10-19 04:07:22 --> Helper loaded: form_helper
INFO - 2020-10-19 04:07:22 --> Helper loaded: my_helper
INFO - 2020-10-19 04:07:22 --> Database Driver Class Initialized
DEBUG - 2020-10-19 04:07:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 04:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 04:07:22 --> Controller Class Initialized
INFO - 2020-10-19 04:07:22 --> Config Class Initialized
INFO - 2020-10-19 04:07:22 --> Hooks Class Initialized
DEBUG - 2020-10-19 04:07:23 --> UTF-8 Support Enabled
INFO - 2020-10-19 04:07:23 --> Utf8 Class Initialized
INFO - 2020-10-19 04:07:23 --> URI Class Initialized
INFO - 2020-10-19 04:07:23 --> Router Class Initialized
INFO - 2020-10-19 04:07:23 --> Output Class Initialized
INFO - 2020-10-19 04:07:23 --> Security Class Initialized
DEBUG - 2020-10-19 04:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 04:07:23 --> Input Class Initialized
INFO - 2020-10-19 04:07:23 --> Language Class Initialized
INFO - 2020-10-19 04:07:23 --> Language Class Initialized
INFO - 2020-10-19 04:07:23 --> Config Class Initialized
INFO - 2020-10-19 04:07:23 --> Loader Class Initialized
INFO - 2020-10-19 04:07:23 --> Helper loaded: url_helper
INFO - 2020-10-19 04:07:23 --> Helper loaded: file_helper
INFO - 2020-10-19 04:07:23 --> Helper loaded: form_helper
INFO - 2020-10-19 04:07:23 --> Helper loaded: my_helper
INFO - 2020-10-19 04:07:23 --> Database Driver Class Initialized
DEBUG - 2020-10-19 04:07:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 04:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 04:07:23 --> Controller Class Initialized
INFO - 2020-10-19 04:07:23 --> Final output sent to browser
DEBUG - 2020-10-19 04:07:23 --> Total execution time: 0.3474
INFO - 2020-10-19 04:07:29 --> Config Class Initialized
INFO - 2020-10-19 04:07:29 --> Hooks Class Initialized
DEBUG - 2020-10-19 04:07:29 --> UTF-8 Support Enabled
INFO - 2020-10-19 04:07:29 --> Utf8 Class Initialized
INFO - 2020-10-19 04:07:29 --> URI Class Initialized
INFO - 2020-10-19 04:07:29 --> Router Class Initialized
INFO - 2020-10-19 04:07:29 --> Output Class Initialized
INFO - 2020-10-19 04:07:29 --> Security Class Initialized
DEBUG - 2020-10-19 04:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 04:07:29 --> Input Class Initialized
INFO - 2020-10-19 04:07:29 --> Language Class Initialized
INFO - 2020-10-19 04:07:29 --> Language Class Initialized
INFO - 2020-10-19 04:07:29 --> Config Class Initialized
INFO - 2020-10-19 04:07:29 --> Loader Class Initialized
INFO - 2020-10-19 04:07:29 --> Helper loaded: url_helper
INFO - 2020-10-19 04:07:29 --> Helper loaded: file_helper
INFO - 2020-10-19 04:07:29 --> Helper loaded: form_helper
INFO - 2020-10-19 04:07:29 --> Helper loaded: my_helper
INFO - 2020-10-19 04:07:29 --> Database Driver Class Initialized
DEBUG - 2020-10-19 04:07:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 04:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 04:07:29 --> Controller Class Initialized
ERROR - 2020-10-19 04:07:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'WHERE id = ''' at line 1 - Invalid query: INSERT m_mapel SET kelompok = 'TO', kd_singkat = 'TKRO', nama = 'Pendidikan Agama Islam' WHERE id = ''
INFO - 2020-10-19 04:07:29 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-19 04:07:31 --> Config Class Initialized
INFO - 2020-10-19 04:07:31 --> Hooks Class Initialized
DEBUG - 2020-10-19 04:07:31 --> UTF-8 Support Enabled
INFO - 2020-10-19 04:07:31 --> Utf8 Class Initialized
INFO - 2020-10-19 04:07:31 --> URI Class Initialized
INFO - 2020-10-19 04:07:31 --> Router Class Initialized
INFO - 2020-10-19 04:07:31 --> Output Class Initialized
INFO - 2020-10-19 04:07:31 --> Security Class Initialized
DEBUG - 2020-10-19 04:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 04:07:31 --> Input Class Initialized
INFO - 2020-10-19 04:07:31 --> Language Class Initialized
INFO - 2020-10-19 04:07:31 --> Language Class Initialized
INFO - 2020-10-19 04:07:31 --> Config Class Initialized
INFO - 2020-10-19 04:07:31 --> Loader Class Initialized
INFO - 2020-10-19 04:07:31 --> Helper loaded: url_helper
INFO - 2020-10-19 04:07:31 --> Helper loaded: file_helper
INFO - 2020-10-19 04:07:31 --> Helper loaded: form_helper
INFO - 2020-10-19 04:07:31 --> Helper loaded: my_helper
INFO - 2020-10-19 04:07:31 --> Database Driver Class Initialized
DEBUG - 2020-10-19 04:07:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 04:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 04:07:31 --> Controller Class Initialized
ERROR - 2020-10-19 04:07:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'WHERE id = ''' at line 1 - Invalid query: INSERT m_mapel SET kelompok = 'TO', kd_singkat = 'TKRO', nama = 'Pendidikan Agama Islam' WHERE id = ''
INFO - 2020-10-19 04:07:31 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-19 04:07:32 --> Config Class Initialized
INFO - 2020-10-19 04:07:32 --> Hooks Class Initialized
DEBUG - 2020-10-19 04:07:32 --> UTF-8 Support Enabled
INFO - 2020-10-19 04:07:33 --> Utf8 Class Initialized
INFO - 2020-10-19 04:07:33 --> URI Class Initialized
INFO - 2020-10-19 04:07:33 --> Router Class Initialized
INFO - 2020-10-19 04:07:33 --> Output Class Initialized
INFO - 2020-10-19 04:07:33 --> Security Class Initialized
DEBUG - 2020-10-19 04:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 04:07:33 --> Input Class Initialized
INFO - 2020-10-19 04:07:33 --> Language Class Initialized
INFO - 2020-10-19 04:07:33 --> Language Class Initialized
INFO - 2020-10-19 04:07:33 --> Config Class Initialized
INFO - 2020-10-19 04:07:33 --> Loader Class Initialized
INFO - 2020-10-19 04:07:33 --> Helper loaded: url_helper
INFO - 2020-10-19 04:07:33 --> Helper loaded: file_helper
INFO - 2020-10-19 04:07:33 --> Helper loaded: form_helper
INFO - 2020-10-19 04:07:33 --> Helper loaded: my_helper
INFO - 2020-10-19 04:07:33 --> Database Driver Class Initialized
DEBUG - 2020-10-19 04:07:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 04:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 04:07:33 --> Controller Class Initialized
DEBUG - 2020-10-19 04:07:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-19 04:07:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-19 04:07:33 --> Final output sent to browser
DEBUG - 2020-10-19 04:07:33 --> Total execution time: 0.3542
INFO - 2020-10-19 04:07:33 --> Config Class Initialized
INFO - 2020-10-19 04:07:33 --> Hooks Class Initialized
DEBUG - 2020-10-19 04:07:33 --> UTF-8 Support Enabled
INFO - 2020-10-19 04:07:33 --> Utf8 Class Initialized
INFO - 2020-10-19 04:07:33 --> URI Class Initialized
INFO - 2020-10-19 04:07:33 --> Router Class Initialized
INFO - 2020-10-19 04:07:33 --> Output Class Initialized
INFO - 2020-10-19 04:07:33 --> Security Class Initialized
DEBUG - 2020-10-19 04:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 04:07:33 --> Input Class Initialized
INFO - 2020-10-19 04:07:33 --> Language Class Initialized
INFO - 2020-10-19 04:07:33 --> Language Class Initialized
INFO - 2020-10-19 04:07:33 --> Config Class Initialized
INFO - 2020-10-19 04:07:33 --> Loader Class Initialized
INFO - 2020-10-19 04:07:33 --> Helper loaded: url_helper
INFO - 2020-10-19 04:07:33 --> Helper loaded: file_helper
INFO - 2020-10-19 04:07:33 --> Helper loaded: form_helper
INFO - 2020-10-19 04:07:33 --> Helper loaded: my_helper
INFO - 2020-10-19 04:07:33 --> Database Driver Class Initialized
DEBUG - 2020-10-19 04:07:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 04:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 04:07:33 --> Controller Class Initialized
INFO - 2020-10-19 04:07:36 --> Config Class Initialized
INFO - 2020-10-19 04:07:36 --> Hooks Class Initialized
DEBUG - 2020-10-19 04:07:36 --> UTF-8 Support Enabled
INFO - 2020-10-19 04:07:36 --> Utf8 Class Initialized
INFO - 2020-10-19 04:07:36 --> URI Class Initialized
INFO - 2020-10-19 04:07:36 --> Router Class Initialized
INFO - 2020-10-19 04:07:36 --> Output Class Initialized
INFO - 2020-10-19 04:07:36 --> Security Class Initialized
DEBUG - 2020-10-19 04:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 04:07:36 --> Input Class Initialized
INFO - 2020-10-19 04:07:36 --> Language Class Initialized
INFO - 2020-10-19 04:07:36 --> Language Class Initialized
INFO - 2020-10-19 04:07:36 --> Config Class Initialized
INFO - 2020-10-19 04:07:36 --> Loader Class Initialized
INFO - 2020-10-19 04:07:36 --> Helper loaded: url_helper
INFO - 2020-10-19 04:07:36 --> Helper loaded: file_helper
INFO - 2020-10-19 04:07:36 --> Helper loaded: form_helper
INFO - 2020-10-19 04:07:36 --> Helper loaded: my_helper
INFO - 2020-10-19 04:07:36 --> Database Driver Class Initialized
DEBUG - 2020-10-19 04:07:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 04:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 04:07:36 --> Controller Class Initialized
DEBUG - 2020-10-19 04:07:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-19 04:07:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-19 04:07:36 --> Final output sent to browser
DEBUG - 2020-10-19 04:07:36 --> Total execution time: 0.3496
INFO - 2020-10-19 04:07:36 --> Config Class Initialized
INFO - 2020-10-19 04:07:36 --> Hooks Class Initialized
DEBUG - 2020-10-19 04:07:36 --> UTF-8 Support Enabled
INFO - 2020-10-19 04:07:36 --> Utf8 Class Initialized
INFO - 2020-10-19 04:07:36 --> URI Class Initialized
INFO - 2020-10-19 04:07:36 --> Router Class Initialized
INFO - 2020-10-19 04:07:36 --> Output Class Initialized
INFO - 2020-10-19 04:07:37 --> Security Class Initialized
DEBUG - 2020-10-19 04:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 04:07:37 --> Input Class Initialized
INFO - 2020-10-19 04:07:37 --> Language Class Initialized
INFO - 2020-10-19 04:07:37 --> Language Class Initialized
INFO - 2020-10-19 04:07:37 --> Config Class Initialized
INFO - 2020-10-19 04:07:37 --> Loader Class Initialized
INFO - 2020-10-19 04:07:37 --> Helper loaded: url_helper
INFO - 2020-10-19 04:07:37 --> Helper loaded: file_helper
INFO - 2020-10-19 04:07:37 --> Helper loaded: form_helper
INFO - 2020-10-19 04:07:37 --> Helper loaded: my_helper
INFO - 2020-10-19 04:07:37 --> Database Driver Class Initialized
DEBUG - 2020-10-19 04:07:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 04:07:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 04:07:37 --> Controller Class Initialized
INFO - 2020-10-19 04:07:37 --> Config Class Initialized
INFO - 2020-10-19 04:07:37 --> Hooks Class Initialized
DEBUG - 2020-10-19 04:07:37 --> UTF-8 Support Enabled
INFO - 2020-10-19 04:07:37 --> Utf8 Class Initialized
INFO - 2020-10-19 04:07:37 --> URI Class Initialized
INFO - 2020-10-19 04:07:37 --> Router Class Initialized
INFO - 2020-10-19 04:07:37 --> Output Class Initialized
INFO - 2020-10-19 04:07:37 --> Security Class Initialized
DEBUG - 2020-10-19 04:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 04:07:37 --> Input Class Initialized
INFO - 2020-10-19 04:07:37 --> Language Class Initialized
INFO - 2020-10-19 04:07:37 --> Language Class Initialized
INFO - 2020-10-19 04:07:37 --> Config Class Initialized
INFO - 2020-10-19 04:07:37 --> Loader Class Initialized
INFO - 2020-10-19 04:07:37 --> Helper loaded: url_helper
INFO - 2020-10-19 04:07:37 --> Helper loaded: file_helper
INFO - 2020-10-19 04:07:37 --> Helper loaded: form_helper
INFO - 2020-10-19 04:07:37 --> Helper loaded: my_helper
INFO - 2020-10-19 04:07:37 --> Database Driver Class Initialized
DEBUG - 2020-10-19 04:07:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 04:07:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 04:07:37 --> Controller Class Initialized
INFO - 2020-10-19 04:07:37 --> Final output sent to browser
DEBUG - 2020-10-19 04:07:37 --> Total execution time: 0.2578
INFO - 2020-10-19 04:08:27 --> Config Class Initialized
INFO - 2020-10-19 04:08:27 --> Hooks Class Initialized
DEBUG - 2020-10-19 04:08:27 --> UTF-8 Support Enabled
INFO - 2020-10-19 04:08:27 --> Utf8 Class Initialized
INFO - 2020-10-19 04:08:27 --> URI Class Initialized
INFO - 2020-10-19 04:08:27 --> Router Class Initialized
INFO - 2020-10-19 04:08:27 --> Output Class Initialized
INFO - 2020-10-19 04:08:27 --> Security Class Initialized
DEBUG - 2020-10-19 04:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 04:08:27 --> Input Class Initialized
INFO - 2020-10-19 04:08:27 --> Language Class Initialized
INFO - 2020-10-19 04:08:27 --> Language Class Initialized
INFO - 2020-10-19 04:08:27 --> Config Class Initialized
INFO - 2020-10-19 04:08:27 --> Loader Class Initialized
INFO - 2020-10-19 04:08:27 --> Helper loaded: url_helper
INFO - 2020-10-19 04:08:27 --> Helper loaded: file_helper
INFO - 2020-10-19 04:08:27 --> Helper loaded: form_helper
INFO - 2020-10-19 04:08:27 --> Helper loaded: my_helper
INFO - 2020-10-19 04:08:27 --> Database Driver Class Initialized
DEBUG - 2020-10-19 04:08:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 04:08:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 04:08:27 --> Controller Class Initialized
ERROR - 2020-10-19 04:08:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'WHERE id = ''' at line 1 - Invalid query: INSERT m_mapel SET kelompok = 'TO', kd_singkat = 'TKRO', nama = 'Pendidikan Agama Islam' WHERE id = ''
INFO - 2020-10-19 04:08:27 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-19 04:08:30 --> Config Class Initialized
INFO - 2020-10-19 04:08:30 --> Hooks Class Initialized
DEBUG - 2020-10-19 04:08:30 --> UTF-8 Support Enabled
INFO - 2020-10-19 04:08:30 --> Utf8 Class Initialized
INFO - 2020-10-19 04:08:30 --> URI Class Initialized
INFO - 2020-10-19 04:08:30 --> Router Class Initialized
INFO - 2020-10-19 04:08:30 --> Output Class Initialized
INFO - 2020-10-19 04:08:30 --> Security Class Initialized
DEBUG - 2020-10-19 04:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 04:08:30 --> Input Class Initialized
INFO - 2020-10-19 04:08:30 --> Language Class Initialized
INFO - 2020-10-19 04:08:30 --> Language Class Initialized
INFO - 2020-10-19 04:08:30 --> Config Class Initialized
INFO - 2020-10-19 04:08:30 --> Loader Class Initialized
INFO - 2020-10-19 04:08:30 --> Helper loaded: url_helper
INFO - 2020-10-19 04:08:30 --> Helper loaded: file_helper
INFO - 2020-10-19 04:08:30 --> Helper loaded: form_helper
INFO - 2020-10-19 04:08:30 --> Helper loaded: my_helper
INFO - 2020-10-19 04:08:30 --> Database Driver Class Initialized
DEBUG - 2020-10-19 04:08:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 04:08:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 04:08:30 --> Controller Class Initialized
DEBUG - 2020-10-19 04:08:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-19 04:08:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-19 04:08:30 --> Final output sent to browser
DEBUG - 2020-10-19 04:08:30 --> Total execution time: 0.3209
INFO - 2020-10-19 04:08:30 --> Config Class Initialized
INFO - 2020-10-19 04:08:30 --> Hooks Class Initialized
DEBUG - 2020-10-19 04:08:30 --> UTF-8 Support Enabled
INFO - 2020-10-19 04:08:30 --> Utf8 Class Initialized
INFO - 2020-10-19 04:08:30 --> URI Class Initialized
INFO - 2020-10-19 04:08:30 --> Router Class Initialized
INFO - 2020-10-19 04:08:30 --> Output Class Initialized
INFO - 2020-10-19 04:08:30 --> Security Class Initialized
DEBUG - 2020-10-19 04:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 04:08:30 --> Input Class Initialized
INFO - 2020-10-19 04:08:30 --> Language Class Initialized
INFO - 2020-10-19 04:08:30 --> Language Class Initialized
INFO - 2020-10-19 04:08:30 --> Config Class Initialized
INFO - 2020-10-19 04:08:30 --> Loader Class Initialized
INFO - 2020-10-19 04:08:30 --> Helper loaded: url_helper
INFO - 2020-10-19 04:08:30 --> Helper loaded: file_helper
INFO - 2020-10-19 04:08:30 --> Helper loaded: form_helper
INFO - 2020-10-19 04:08:30 --> Helper loaded: my_helper
INFO - 2020-10-19 04:08:30 --> Database Driver Class Initialized
DEBUG - 2020-10-19 04:08:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 04:08:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 04:08:30 --> Controller Class Initialized
INFO - 2020-10-19 04:08:32 --> Config Class Initialized
INFO - 2020-10-19 04:08:32 --> Hooks Class Initialized
DEBUG - 2020-10-19 04:08:32 --> UTF-8 Support Enabled
INFO - 2020-10-19 04:08:32 --> Utf8 Class Initialized
INFO - 2020-10-19 04:08:32 --> URI Class Initialized
INFO - 2020-10-19 04:08:32 --> Router Class Initialized
INFO - 2020-10-19 04:08:32 --> Output Class Initialized
INFO - 2020-10-19 04:08:32 --> Security Class Initialized
DEBUG - 2020-10-19 04:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 04:08:32 --> Input Class Initialized
INFO - 2020-10-19 04:08:32 --> Language Class Initialized
INFO - 2020-10-19 04:08:33 --> Language Class Initialized
INFO - 2020-10-19 04:08:33 --> Config Class Initialized
INFO - 2020-10-19 04:08:33 --> Loader Class Initialized
INFO - 2020-10-19 04:08:33 --> Helper loaded: url_helper
INFO - 2020-10-19 04:08:33 --> Helper loaded: file_helper
INFO - 2020-10-19 04:08:33 --> Helper loaded: form_helper
INFO - 2020-10-19 04:08:33 --> Helper loaded: my_helper
INFO - 2020-10-19 04:08:33 --> Database Driver Class Initialized
DEBUG - 2020-10-19 04:08:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-19 04:08:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 04:08:33 --> Controller Class Initialized
INFO - 2020-10-19 04:08:33 --> Final output sent to browser
DEBUG - 2020-10-19 04:08:33 --> Total execution time: 0.2826
