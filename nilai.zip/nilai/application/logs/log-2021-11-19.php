<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-11-19 07:11:22 --> Config Class Initialized
INFO - 2021-11-19 07:11:22 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:11:22 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:11:22 --> Utf8 Class Initialized
INFO - 2021-11-19 07:11:22 --> URI Class Initialized
DEBUG - 2021-11-19 07:11:22 --> No URI present. Default controller set.
INFO - 2021-11-19 07:11:22 --> Router Class Initialized
INFO - 2021-11-19 07:11:22 --> Output Class Initialized
INFO - 2021-11-19 07:11:22 --> Security Class Initialized
DEBUG - 2021-11-19 07:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:11:22 --> Input Class Initialized
INFO - 2021-11-19 07:11:22 --> Language Class Initialized
INFO - 2021-11-19 07:11:23 --> Language Class Initialized
INFO - 2021-11-19 07:11:23 --> Config Class Initialized
INFO - 2021-11-19 07:11:23 --> Loader Class Initialized
INFO - 2021-11-19 07:11:23 --> Helper loaded: url_helper
INFO - 2021-11-19 07:11:23 --> Helper loaded: file_helper
INFO - 2021-11-19 07:11:23 --> Helper loaded: form_helper
INFO - 2021-11-19 07:11:23 --> Helper loaded: my_helper
INFO - 2021-11-19 07:11:23 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:11:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:11:24 --> Controller Class Initialized
INFO - 2021-11-19 07:11:24 --> Config Class Initialized
INFO - 2021-11-19 07:11:24 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:11:24 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:11:24 --> Utf8 Class Initialized
INFO - 2021-11-19 07:11:24 --> URI Class Initialized
INFO - 2021-11-19 07:11:24 --> Router Class Initialized
INFO - 2021-11-19 07:11:24 --> Output Class Initialized
INFO - 2021-11-19 07:11:24 --> Security Class Initialized
DEBUG - 2021-11-19 07:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:11:24 --> Input Class Initialized
INFO - 2021-11-19 07:11:24 --> Language Class Initialized
INFO - 2021-11-19 07:11:24 --> Language Class Initialized
INFO - 2021-11-19 07:11:24 --> Config Class Initialized
INFO - 2021-11-19 07:11:24 --> Loader Class Initialized
INFO - 2021-11-19 07:11:24 --> Helper loaded: url_helper
INFO - 2021-11-19 07:11:24 --> Helper loaded: file_helper
INFO - 2021-11-19 07:11:24 --> Helper loaded: form_helper
INFO - 2021-11-19 07:11:24 --> Helper loaded: my_helper
INFO - 2021-11-19 07:11:24 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:11:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:11:24 --> Controller Class Initialized
DEBUG - 2021-11-19 07:11:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-11-19 07:11:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 07:11:24 --> Final output sent to browser
DEBUG - 2021-11-19 07:11:24 --> Total execution time: 0.2493
INFO - 2021-11-19 07:11:42 --> Config Class Initialized
INFO - 2021-11-19 07:11:42 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:11:42 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:11:42 --> Utf8 Class Initialized
INFO - 2021-11-19 07:11:42 --> URI Class Initialized
INFO - 2021-11-19 07:11:42 --> Router Class Initialized
INFO - 2021-11-19 07:11:42 --> Output Class Initialized
INFO - 2021-11-19 07:11:42 --> Security Class Initialized
DEBUG - 2021-11-19 07:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:11:42 --> Input Class Initialized
INFO - 2021-11-19 07:11:42 --> Language Class Initialized
INFO - 2021-11-19 07:11:42 --> Language Class Initialized
INFO - 2021-11-19 07:11:42 --> Config Class Initialized
INFO - 2021-11-19 07:11:42 --> Loader Class Initialized
INFO - 2021-11-19 07:11:42 --> Helper loaded: url_helper
INFO - 2021-11-19 07:11:42 --> Helper loaded: file_helper
INFO - 2021-11-19 07:11:42 --> Helper loaded: form_helper
INFO - 2021-11-19 07:11:42 --> Helper loaded: my_helper
INFO - 2021-11-19 07:11:42 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:11:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:11:42 --> Controller Class Initialized
INFO - 2021-11-19 07:11:42 --> Helper loaded: cookie_helper
INFO - 2021-11-19 07:11:42 --> Final output sent to browser
DEBUG - 2021-11-19 07:11:42 --> Total execution time: 0.2095
INFO - 2021-11-19 07:11:43 --> Config Class Initialized
INFO - 2021-11-19 07:11:43 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:11:43 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:11:43 --> Utf8 Class Initialized
INFO - 2021-11-19 07:11:43 --> URI Class Initialized
INFO - 2021-11-19 07:11:43 --> Router Class Initialized
INFO - 2021-11-19 07:11:43 --> Output Class Initialized
INFO - 2021-11-19 07:11:43 --> Security Class Initialized
DEBUG - 2021-11-19 07:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:11:43 --> Input Class Initialized
INFO - 2021-11-19 07:11:43 --> Language Class Initialized
INFO - 2021-11-19 07:11:43 --> Language Class Initialized
INFO - 2021-11-19 07:11:43 --> Config Class Initialized
INFO - 2021-11-19 07:11:43 --> Loader Class Initialized
INFO - 2021-11-19 07:11:43 --> Helper loaded: url_helper
INFO - 2021-11-19 07:11:43 --> Helper loaded: file_helper
INFO - 2021-11-19 07:11:43 --> Helper loaded: form_helper
INFO - 2021-11-19 07:11:43 --> Helper loaded: my_helper
INFO - 2021-11-19 07:11:43 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:11:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:11:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:11:43 --> Controller Class Initialized
DEBUG - 2021-11-19 07:11:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-11-19 07:11:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 07:11:45 --> Final output sent to browser
DEBUG - 2021-11-19 07:11:45 --> Total execution time: 2.3115
INFO - 2021-11-19 07:11:47 --> Config Class Initialized
INFO - 2021-11-19 07:11:47 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:11:47 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:11:47 --> Utf8 Class Initialized
INFO - 2021-11-19 07:11:47 --> URI Class Initialized
INFO - 2021-11-19 07:11:47 --> Router Class Initialized
INFO - 2021-11-19 07:11:47 --> Output Class Initialized
INFO - 2021-11-19 07:11:47 --> Security Class Initialized
DEBUG - 2021-11-19 07:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:11:47 --> Input Class Initialized
INFO - 2021-11-19 07:11:47 --> Language Class Initialized
INFO - 2021-11-19 07:11:47 --> Language Class Initialized
INFO - 2021-11-19 07:11:47 --> Config Class Initialized
INFO - 2021-11-19 07:11:47 --> Loader Class Initialized
INFO - 2021-11-19 07:11:47 --> Helper loaded: url_helper
INFO - 2021-11-19 07:11:47 --> Helper loaded: file_helper
INFO - 2021-11-19 07:11:47 --> Helper loaded: form_helper
INFO - 2021-11-19 07:11:47 --> Helper loaded: my_helper
INFO - 2021-11-19 07:11:47 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:11:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:11:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:11:47 --> Controller Class Initialized
DEBUG - 2021-11-19 07:11:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-11-19 07:11:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 07:11:47 --> Final output sent to browser
DEBUG - 2021-11-19 07:11:47 --> Total execution time: 0.4189
INFO - 2021-11-19 07:11:50 --> Config Class Initialized
INFO - 2021-11-19 07:11:50 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:11:50 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:11:50 --> Utf8 Class Initialized
INFO - 2021-11-19 07:11:50 --> URI Class Initialized
INFO - 2021-11-19 07:11:50 --> Router Class Initialized
INFO - 2021-11-19 07:11:50 --> Output Class Initialized
INFO - 2021-11-19 07:11:50 --> Security Class Initialized
DEBUG - 2021-11-19 07:11:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:11:50 --> Input Class Initialized
INFO - 2021-11-19 07:11:50 --> Language Class Initialized
INFO - 2021-11-19 07:11:50 --> Language Class Initialized
INFO - 2021-11-19 07:11:50 --> Config Class Initialized
INFO - 2021-11-19 07:11:50 --> Loader Class Initialized
INFO - 2021-11-19 07:11:50 --> Helper loaded: url_helper
INFO - 2021-11-19 07:11:50 --> Helper loaded: file_helper
INFO - 2021-11-19 07:11:51 --> Helper loaded: form_helper
INFO - 2021-11-19 07:11:51 --> Helper loaded: my_helper
INFO - 2021-11-19 07:11:51 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:11:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:11:51 --> Controller Class Initialized
DEBUG - 2021-11-19 07:11:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-19 07:11:51 --> Final output sent to browser
DEBUG - 2021-11-19 07:11:51 --> Total execution time: 0.5693
INFO - 2021-11-19 07:21:39 --> Config Class Initialized
INFO - 2021-11-19 07:21:39 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:21:39 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:21:39 --> Utf8 Class Initialized
INFO - 2021-11-19 07:21:39 --> URI Class Initialized
INFO - 2021-11-19 07:21:39 --> Router Class Initialized
INFO - 2021-11-19 07:21:39 --> Output Class Initialized
INFO - 2021-11-19 07:21:39 --> Security Class Initialized
DEBUG - 2021-11-19 07:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:21:39 --> Input Class Initialized
INFO - 2021-11-19 07:21:39 --> Language Class Initialized
INFO - 2021-11-19 07:21:39 --> Language Class Initialized
INFO - 2021-11-19 07:21:39 --> Config Class Initialized
INFO - 2021-11-19 07:21:39 --> Loader Class Initialized
INFO - 2021-11-19 07:21:39 --> Helper loaded: url_helper
INFO - 2021-11-19 07:21:39 --> Helper loaded: file_helper
INFO - 2021-11-19 07:21:39 --> Helper loaded: form_helper
INFO - 2021-11-19 07:21:39 --> Helper loaded: my_helper
INFO - 2021-11-19 07:21:39 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:21:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:21:39 --> Controller Class Initialized
DEBUG - 2021-11-19 07:21:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-19 07:21:39 --> Final output sent to browser
DEBUG - 2021-11-19 07:21:39 --> Total execution time: 0.1412
INFO - 2021-11-19 07:21:52 --> Config Class Initialized
INFO - 2021-11-19 07:21:52 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:21:52 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:21:52 --> Utf8 Class Initialized
INFO - 2021-11-19 07:21:52 --> URI Class Initialized
INFO - 2021-11-19 07:21:52 --> Router Class Initialized
INFO - 2021-11-19 07:21:52 --> Output Class Initialized
INFO - 2021-11-19 07:21:52 --> Security Class Initialized
DEBUG - 2021-11-19 07:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:21:52 --> Input Class Initialized
INFO - 2021-11-19 07:21:52 --> Language Class Initialized
INFO - 2021-11-19 07:21:52 --> Language Class Initialized
INFO - 2021-11-19 07:21:52 --> Config Class Initialized
INFO - 2021-11-19 07:21:52 --> Loader Class Initialized
INFO - 2021-11-19 07:21:52 --> Helper loaded: url_helper
INFO - 2021-11-19 07:21:52 --> Helper loaded: file_helper
INFO - 2021-11-19 07:21:52 --> Helper loaded: form_helper
INFO - 2021-11-19 07:21:52 --> Helper loaded: my_helper
INFO - 2021-11-19 07:21:52 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:21:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:21:52 --> Controller Class Initialized
DEBUG - 2021-11-19 07:21:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-19 07:21:52 --> Final output sent to browser
DEBUG - 2021-11-19 07:21:52 --> Total execution time: 0.1564
INFO - 2021-11-19 07:22:14 --> Config Class Initialized
INFO - 2021-11-19 07:22:14 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:22:14 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:22:14 --> Utf8 Class Initialized
INFO - 2021-11-19 07:22:14 --> URI Class Initialized
INFO - 2021-11-19 07:22:14 --> Router Class Initialized
INFO - 2021-11-19 07:22:14 --> Output Class Initialized
INFO - 2021-11-19 07:22:14 --> Security Class Initialized
DEBUG - 2021-11-19 07:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:22:14 --> Input Class Initialized
INFO - 2021-11-19 07:22:14 --> Language Class Initialized
INFO - 2021-11-19 07:22:14 --> Language Class Initialized
INFO - 2021-11-19 07:22:14 --> Config Class Initialized
INFO - 2021-11-19 07:22:14 --> Loader Class Initialized
INFO - 2021-11-19 07:22:14 --> Helper loaded: url_helper
INFO - 2021-11-19 07:22:14 --> Helper loaded: file_helper
INFO - 2021-11-19 07:22:14 --> Helper loaded: form_helper
INFO - 2021-11-19 07:22:14 --> Helper loaded: my_helper
INFO - 2021-11-19 07:22:14 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:22:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:22:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:22:14 --> Controller Class Initialized
DEBUG - 2021-11-19 07:22:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-19 07:22:14 --> Final output sent to browser
DEBUG - 2021-11-19 07:22:14 --> Total execution time: 0.1430
INFO - 2021-11-19 07:22:24 --> Config Class Initialized
INFO - 2021-11-19 07:22:24 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:22:24 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:22:24 --> Utf8 Class Initialized
INFO - 2021-11-19 07:22:24 --> URI Class Initialized
INFO - 2021-11-19 07:22:24 --> Router Class Initialized
INFO - 2021-11-19 07:22:24 --> Output Class Initialized
INFO - 2021-11-19 07:22:24 --> Security Class Initialized
DEBUG - 2021-11-19 07:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:22:24 --> Input Class Initialized
INFO - 2021-11-19 07:22:24 --> Language Class Initialized
INFO - 2021-11-19 07:22:24 --> Language Class Initialized
INFO - 2021-11-19 07:22:24 --> Config Class Initialized
INFO - 2021-11-19 07:22:24 --> Loader Class Initialized
INFO - 2021-11-19 07:22:24 --> Helper loaded: url_helper
INFO - 2021-11-19 07:22:24 --> Helper loaded: file_helper
INFO - 2021-11-19 07:22:24 --> Helper loaded: form_helper
INFO - 2021-11-19 07:22:24 --> Helper loaded: my_helper
INFO - 2021-11-19 07:22:24 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:22:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:22:24 --> Controller Class Initialized
DEBUG - 2021-11-19 07:22:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-19 07:22:24 --> Final output sent to browser
DEBUG - 2021-11-19 07:22:24 --> Total execution time: 0.1364
INFO - 2021-11-19 07:22:32 --> Config Class Initialized
INFO - 2021-11-19 07:22:32 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:22:32 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:22:32 --> Utf8 Class Initialized
INFO - 2021-11-19 07:22:32 --> URI Class Initialized
INFO - 2021-11-19 07:22:32 --> Router Class Initialized
INFO - 2021-11-19 07:22:32 --> Output Class Initialized
INFO - 2021-11-19 07:22:32 --> Security Class Initialized
DEBUG - 2021-11-19 07:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:22:32 --> Input Class Initialized
INFO - 2021-11-19 07:22:32 --> Language Class Initialized
INFO - 2021-11-19 07:22:32 --> Language Class Initialized
INFO - 2021-11-19 07:22:32 --> Config Class Initialized
INFO - 2021-11-19 07:22:32 --> Loader Class Initialized
INFO - 2021-11-19 07:22:32 --> Helper loaded: url_helper
INFO - 2021-11-19 07:22:32 --> Helper loaded: file_helper
INFO - 2021-11-19 07:22:32 --> Helper loaded: form_helper
INFO - 2021-11-19 07:22:32 --> Helper loaded: my_helper
INFO - 2021-11-19 07:22:32 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:22:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:22:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:22:32 --> Controller Class Initialized
DEBUG - 2021-11-19 07:22:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-19 07:22:32 --> Final output sent to browser
DEBUG - 2021-11-19 07:22:32 --> Total execution time: 0.1258
INFO - 2021-11-19 07:22:40 --> Config Class Initialized
INFO - 2021-11-19 07:22:40 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:22:40 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:22:40 --> Utf8 Class Initialized
INFO - 2021-11-19 07:22:40 --> URI Class Initialized
INFO - 2021-11-19 07:22:40 --> Router Class Initialized
INFO - 2021-11-19 07:22:40 --> Output Class Initialized
INFO - 2021-11-19 07:22:40 --> Security Class Initialized
DEBUG - 2021-11-19 07:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:22:40 --> Input Class Initialized
INFO - 2021-11-19 07:22:40 --> Language Class Initialized
INFO - 2021-11-19 07:22:40 --> Language Class Initialized
INFO - 2021-11-19 07:22:40 --> Config Class Initialized
INFO - 2021-11-19 07:22:40 --> Loader Class Initialized
INFO - 2021-11-19 07:22:40 --> Helper loaded: url_helper
INFO - 2021-11-19 07:22:40 --> Helper loaded: file_helper
INFO - 2021-11-19 07:22:40 --> Helper loaded: form_helper
INFO - 2021-11-19 07:22:40 --> Helper loaded: my_helper
INFO - 2021-11-19 07:22:40 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:22:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:22:40 --> Controller Class Initialized
DEBUG - 2021-11-19 07:22:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-19 07:22:40 --> Final output sent to browser
DEBUG - 2021-11-19 07:22:40 --> Total execution time: 0.1524
INFO - 2021-11-19 07:23:39 --> Config Class Initialized
INFO - 2021-11-19 07:23:39 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:23:39 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:23:39 --> Utf8 Class Initialized
INFO - 2021-11-19 07:23:39 --> URI Class Initialized
INFO - 2021-11-19 07:23:39 --> Router Class Initialized
INFO - 2021-11-19 07:23:39 --> Output Class Initialized
INFO - 2021-11-19 07:23:39 --> Security Class Initialized
DEBUG - 2021-11-19 07:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:23:39 --> Input Class Initialized
INFO - 2021-11-19 07:23:39 --> Language Class Initialized
INFO - 2021-11-19 07:23:39 --> Language Class Initialized
INFO - 2021-11-19 07:23:39 --> Config Class Initialized
INFO - 2021-11-19 07:23:39 --> Loader Class Initialized
INFO - 2021-11-19 07:23:39 --> Helper loaded: url_helper
INFO - 2021-11-19 07:23:39 --> Helper loaded: file_helper
INFO - 2021-11-19 07:23:39 --> Helper loaded: form_helper
INFO - 2021-11-19 07:23:39 --> Helper loaded: my_helper
INFO - 2021-11-19 07:23:39 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:23:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:23:39 --> Controller Class Initialized
INFO - 2021-11-19 07:23:39 --> Helper loaded: cookie_helper
INFO - 2021-11-19 07:23:39 --> Config Class Initialized
INFO - 2021-11-19 07:23:39 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:23:39 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:23:39 --> Utf8 Class Initialized
INFO - 2021-11-19 07:23:39 --> URI Class Initialized
INFO - 2021-11-19 07:23:39 --> Router Class Initialized
INFO - 2021-11-19 07:23:39 --> Output Class Initialized
INFO - 2021-11-19 07:23:39 --> Security Class Initialized
DEBUG - 2021-11-19 07:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:23:39 --> Input Class Initialized
INFO - 2021-11-19 07:23:39 --> Language Class Initialized
INFO - 2021-11-19 07:23:39 --> Language Class Initialized
INFO - 2021-11-19 07:23:39 --> Config Class Initialized
INFO - 2021-11-19 07:23:39 --> Loader Class Initialized
INFO - 2021-11-19 07:23:39 --> Helper loaded: url_helper
INFO - 2021-11-19 07:23:39 --> Helper loaded: file_helper
INFO - 2021-11-19 07:23:39 --> Helper loaded: form_helper
INFO - 2021-11-19 07:23:39 --> Helper loaded: my_helper
INFO - 2021-11-19 07:23:39 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:23:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:23:39 --> Controller Class Initialized
DEBUG - 2021-11-19 07:23:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-11-19 07:23:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 07:23:39 --> Final output sent to browser
DEBUG - 2021-11-19 07:23:39 --> Total execution time: 0.0836
INFO - 2021-11-19 07:23:44 --> Config Class Initialized
INFO - 2021-11-19 07:23:44 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:23:44 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:23:44 --> Utf8 Class Initialized
INFO - 2021-11-19 07:23:44 --> URI Class Initialized
INFO - 2021-11-19 07:23:44 --> Router Class Initialized
INFO - 2021-11-19 07:23:44 --> Output Class Initialized
INFO - 2021-11-19 07:23:44 --> Security Class Initialized
DEBUG - 2021-11-19 07:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:23:44 --> Input Class Initialized
INFO - 2021-11-19 07:23:44 --> Language Class Initialized
INFO - 2021-11-19 07:23:44 --> Language Class Initialized
INFO - 2021-11-19 07:23:44 --> Config Class Initialized
INFO - 2021-11-19 07:23:44 --> Loader Class Initialized
INFO - 2021-11-19 07:23:44 --> Helper loaded: url_helper
INFO - 2021-11-19 07:23:44 --> Helper loaded: file_helper
INFO - 2021-11-19 07:23:44 --> Helper loaded: form_helper
INFO - 2021-11-19 07:23:44 --> Helper loaded: my_helper
INFO - 2021-11-19 07:23:44 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:23:44 --> Controller Class Initialized
INFO - 2021-11-19 07:23:44 --> Helper loaded: cookie_helper
INFO - 2021-11-19 07:23:44 --> Final output sent to browser
DEBUG - 2021-11-19 07:23:44 --> Total execution time: 0.1232
INFO - 2021-11-19 07:23:44 --> Config Class Initialized
INFO - 2021-11-19 07:23:44 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:23:44 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:23:44 --> Utf8 Class Initialized
INFO - 2021-11-19 07:23:44 --> URI Class Initialized
INFO - 2021-11-19 07:23:44 --> Router Class Initialized
INFO - 2021-11-19 07:23:44 --> Output Class Initialized
INFO - 2021-11-19 07:23:44 --> Security Class Initialized
DEBUG - 2021-11-19 07:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:23:44 --> Input Class Initialized
INFO - 2021-11-19 07:23:44 --> Language Class Initialized
INFO - 2021-11-19 07:23:44 --> Language Class Initialized
INFO - 2021-11-19 07:23:44 --> Config Class Initialized
INFO - 2021-11-19 07:23:44 --> Loader Class Initialized
INFO - 2021-11-19 07:23:44 --> Helper loaded: url_helper
INFO - 2021-11-19 07:23:44 --> Helper loaded: file_helper
INFO - 2021-11-19 07:23:44 --> Helper loaded: form_helper
INFO - 2021-11-19 07:23:44 --> Helper loaded: my_helper
INFO - 2021-11-19 07:23:45 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:23:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:23:45 --> Controller Class Initialized
DEBUG - 2021-11-19 07:23:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-11-19 07:23:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 07:23:46 --> Final output sent to browser
DEBUG - 2021-11-19 07:23:46 --> Total execution time: 1.2972
INFO - 2021-11-19 07:23:49 --> Config Class Initialized
INFO - 2021-11-19 07:23:49 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:23:49 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:23:49 --> Utf8 Class Initialized
INFO - 2021-11-19 07:23:49 --> URI Class Initialized
INFO - 2021-11-19 07:23:49 --> Router Class Initialized
INFO - 2021-11-19 07:23:49 --> Output Class Initialized
INFO - 2021-11-19 07:23:49 --> Security Class Initialized
DEBUG - 2021-11-19 07:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:23:49 --> Input Class Initialized
INFO - 2021-11-19 07:23:49 --> Language Class Initialized
INFO - 2021-11-19 07:23:49 --> Language Class Initialized
INFO - 2021-11-19 07:23:49 --> Config Class Initialized
INFO - 2021-11-19 07:23:49 --> Loader Class Initialized
INFO - 2021-11-19 07:23:49 --> Helper loaded: url_helper
INFO - 2021-11-19 07:23:49 --> Helper loaded: file_helper
INFO - 2021-11-19 07:23:49 --> Helper loaded: form_helper
INFO - 2021-11-19 07:23:49 --> Helper loaded: my_helper
INFO - 2021-11-19 07:23:49 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:23:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:23:49 --> Controller Class Initialized
DEBUG - 2021-11-19 07:23:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-11-19 07:23:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 07:23:49 --> Final output sent to browser
DEBUG - 2021-11-19 07:23:49 --> Total execution time: 0.0912
INFO - 2021-11-19 07:23:52 --> Config Class Initialized
INFO - 2021-11-19 07:23:52 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:23:52 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:23:52 --> Utf8 Class Initialized
INFO - 2021-11-19 07:23:52 --> URI Class Initialized
INFO - 2021-11-19 07:23:52 --> Router Class Initialized
INFO - 2021-11-19 07:23:52 --> Output Class Initialized
INFO - 2021-11-19 07:23:52 --> Security Class Initialized
DEBUG - 2021-11-19 07:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:23:52 --> Input Class Initialized
INFO - 2021-11-19 07:23:52 --> Language Class Initialized
INFO - 2021-11-19 07:23:52 --> Language Class Initialized
INFO - 2021-11-19 07:23:52 --> Config Class Initialized
INFO - 2021-11-19 07:23:52 --> Loader Class Initialized
INFO - 2021-11-19 07:23:52 --> Helper loaded: url_helper
INFO - 2021-11-19 07:23:52 --> Helper loaded: file_helper
INFO - 2021-11-19 07:23:52 --> Helper loaded: form_helper
INFO - 2021-11-19 07:23:52 --> Helper loaded: my_helper
INFO - 2021-11-19 07:23:52 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:23:52 --> Controller Class Initialized
DEBUG - 2021-11-19 07:23:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-11-19 07:23:52 --> Final output sent to browser
DEBUG - 2021-11-19 07:23:52 --> Total execution time: 0.2970
INFO - 2021-11-19 07:25:19 --> Config Class Initialized
INFO - 2021-11-19 07:25:19 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:25:19 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:25:19 --> Utf8 Class Initialized
INFO - 2021-11-19 07:25:19 --> URI Class Initialized
INFO - 2021-11-19 07:25:19 --> Router Class Initialized
INFO - 2021-11-19 07:25:19 --> Output Class Initialized
INFO - 2021-11-19 07:25:19 --> Security Class Initialized
DEBUG - 2021-11-19 07:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:25:19 --> Input Class Initialized
INFO - 2021-11-19 07:25:19 --> Language Class Initialized
INFO - 2021-11-19 07:25:19 --> Language Class Initialized
INFO - 2021-11-19 07:25:19 --> Config Class Initialized
INFO - 2021-11-19 07:25:19 --> Loader Class Initialized
INFO - 2021-11-19 07:25:19 --> Helper loaded: url_helper
INFO - 2021-11-19 07:25:19 --> Helper loaded: file_helper
INFO - 2021-11-19 07:25:19 --> Helper loaded: form_helper
INFO - 2021-11-19 07:25:19 --> Helper loaded: my_helper
INFO - 2021-11-19 07:25:19 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:25:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:25:19 --> Controller Class Initialized
DEBUG - 2021-11-19 07:25:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-11-19 07:25:19 --> Final output sent to browser
DEBUG - 2021-11-19 07:25:19 --> Total execution time: 0.1620
INFO - 2021-11-19 07:25:40 --> Config Class Initialized
INFO - 2021-11-19 07:25:40 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:25:40 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:25:40 --> Utf8 Class Initialized
INFO - 2021-11-19 07:25:40 --> URI Class Initialized
INFO - 2021-11-19 07:25:40 --> Router Class Initialized
INFO - 2021-11-19 07:25:40 --> Output Class Initialized
INFO - 2021-11-19 07:25:40 --> Security Class Initialized
DEBUG - 2021-11-19 07:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:25:40 --> Input Class Initialized
INFO - 2021-11-19 07:25:40 --> Language Class Initialized
INFO - 2021-11-19 07:25:40 --> Language Class Initialized
INFO - 2021-11-19 07:25:40 --> Config Class Initialized
INFO - 2021-11-19 07:25:40 --> Loader Class Initialized
INFO - 2021-11-19 07:25:40 --> Helper loaded: url_helper
INFO - 2021-11-19 07:25:40 --> Helper loaded: file_helper
INFO - 2021-11-19 07:25:40 --> Helper loaded: form_helper
INFO - 2021-11-19 07:25:40 --> Helper loaded: my_helper
INFO - 2021-11-19 07:25:40 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:25:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:25:40 --> Controller Class Initialized
DEBUG - 2021-11-19 07:25:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-11-19 07:25:40 --> Final output sent to browser
DEBUG - 2021-11-19 07:25:40 --> Total execution time: 0.1513
INFO - 2021-11-19 07:26:34 --> Config Class Initialized
INFO - 2021-11-19 07:26:34 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:26:34 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:26:34 --> Utf8 Class Initialized
INFO - 2021-11-19 07:26:34 --> URI Class Initialized
INFO - 2021-11-19 07:26:34 --> Router Class Initialized
INFO - 2021-11-19 07:26:34 --> Output Class Initialized
INFO - 2021-11-19 07:26:34 --> Security Class Initialized
DEBUG - 2021-11-19 07:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:26:34 --> Input Class Initialized
INFO - 2021-11-19 07:26:34 --> Language Class Initialized
INFO - 2021-11-19 07:26:34 --> Language Class Initialized
INFO - 2021-11-19 07:26:34 --> Config Class Initialized
INFO - 2021-11-19 07:26:34 --> Loader Class Initialized
INFO - 2021-11-19 07:26:34 --> Helper loaded: url_helper
INFO - 2021-11-19 07:26:34 --> Helper loaded: file_helper
INFO - 2021-11-19 07:26:34 --> Helper loaded: form_helper
INFO - 2021-11-19 07:26:34 --> Helper loaded: my_helper
INFO - 2021-11-19 07:26:34 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:26:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:26:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:26:34 --> Controller Class Initialized
DEBUG - 2021-11-19 07:26:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-11-19 07:26:34 --> Final output sent to browser
DEBUG - 2021-11-19 07:26:34 --> Total execution time: 0.1161
INFO - 2021-11-19 07:26:44 --> Config Class Initialized
INFO - 2021-11-19 07:26:44 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:26:44 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:26:44 --> Utf8 Class Initialized
INFO - 2021-11-19 07:26:44 --> URI Class Initialized
INFO - 2021-11-19 07:26:44 --> Router Class Initialized
INFO - 2021-11-19 07:26:44 --> Output Class Initialized
INFO - 2021-11-19 07:26:44 --> Security Class Initialized
DEBUG - 2021-11-19 07:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:26:44 --> Input Class Initialized
INFO - 2021-11-19 07:26:44 --> Language Class Initialized
INFO - 2021-11-19 07:26:44 --> Language Class Initialized
INFO - 2021-11-19 07:26:44 --> Config Class Initialized
INFO - 2021-11-19 07:26:44 --> Loader Class Initialized
INFO - 2021-11-19 07:26:44 --> Helper loaded: url_helper
INFO - 2021-11-19 07:26:44 --> Helper loaded: file_helper
INFO - 2021-11-19 07:26:44 --> Helper loaded: form_helper
INFO - 2021-11-19 07:26:44 --> Helper loaded: my_helper
INFO - 2021-11-19 07:26:44 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:26:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:26:44 --> Controller Class Initialized
DEBUG - 2021-11-19 07:26:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-11-19 07:26:44 --> Final output sent to browser
DEBUG - 2021-11-19 07:26:44 --> Total execution time: 0.1480
INFO - 2021-11-19 07:27:20 --> Config Class Initialized
INFO - 2021-11-19 07:27:20 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:27:21 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:27:21 --> Utf8 Class Initialized
INFO - 2021-11-19 07:27:21 --> URI Class Initialized
INFO - 2021-11-19 07:27:21 --> Router Class Initialized
INFO - 2021-11-19 07:27:21 --> Output Class Initialized
INFO - 2021-11-19 07:27:21 --> Security Class Initialized
DEBUG - 2021-11-19 07:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:27:21 --> Input Class Initialized
INFO - 2021-11-19 07:27:21 --> Language Class Initialized
INFO - 2021-11-19 07:27:21 --> Language Class Initialized
INFO - 2021-11-19 07:27:21 --> Config Class Initialized
INFO - 2021-11-19 07:27:21 --> Loader Class Initialized
INFO - 2021-11-19 07:27:21 --> Helper loaded: url_helper
INFO - 2021-11-19 07:27:21 --> Helper loaded: file_helper
INFO - 2021-11-19 07:27:21 --> Helper loaded: form_helper
INFO - 2021-11-19 07:27:21 --> Helper loaded: my_helper
INFO - 2021-11-19 07:27:21 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:27:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:27:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:27:21 --> Controller Class Initialized
DEBUG - 2021-11-19 07:27:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-11-19 07:27:21 --> Final output sent to browser
DEBUG - 2021-11-19 07:27:21 --> Total execution time: 0.1589
INFO - 2021-11-19 07:28:33 --> Config Class Initialized
INFO - 2021-11-19 07:28:33 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:28:33 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:28:33 --> Utf8 Class Initialized
INFO - 2021-11-19 07:28:33 --> URI Class Initialized
INFO - 2021-11-19 07:28:33 --> Router Class Initialized
INFO - 2021-11-19 07:28:33 --> Output Class Initialized
INFO - 2021-11-19 07:28:33 --> Security Class Initialized
DEBUG - 2021-11-19 07:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:28:33 --> Input Class Initialized
INFO - 2021-11-19 07:28:33 --> Language Class Initialized
INFO - 2021-11-19 07:28:33 --> Language Class Initialized
INFO - 2021-11-19 07:28:33 --> Config Class Initialized
INFO - 2021-11-19 07:28:33 --> Loader Class Initialized
INFO - 2021-11-19 07:28:33 --> Helper loaded: url_helper
INFO - 2021-11-19 07:28:33 --> Helper loaded: file_helper
INFO - 2021-11-19 07:28:33 --> Helper loaded: form_helper
INFO - 2021-11-19 07:28:33 --> Helper loaded: my_helper
INFO - 2021-11-19 07:28:33 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:28:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:28:33 --> Controller Class Initialized
DEBUG - 2021-11-19 07:28:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-11-19 07:28:33 --> Final output sent to browser
DEBUG - 2021-11-19 07:28:33 --> Total execution time: 0.1475
INFO - 2021-11-19 07:28:53 --> Config Class Initialized
INFO - 2021-11-19 07:28:53 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:28:53 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:28:53 --> Utf8 Class Initialized
INFO - 2021-11-19 07:28:53 --> URI Class Initialized
INFO - 2021-11-19 07:28:53 --> Router Class Initialized
INFO - 2021-11-19 07:28:53 --> Output Class Initialized
INFO - 2021-11-19 07:28:53 --> Security Class Initialized
DEBUG - 2021-11-19 07:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:28:53 --> Input Class Initialized
INFO - 2021-11-19 07:28:53 --> Language Class Initialized
INFO - 2021-11-19 07:28:53 --> Language Class Initialized
INFO - 2021-11-19 07:28:53 --> Config Class Initialized
INFO - 2021-11-19 07:28:53 --> Loader Class Initialized
INFO - 2021-11-19 07:28:53 --> Helper loaded: url_helper
INFO - 2021-11-19 07:28:53 --> Helper loaded: file_helper
INFO - 2021-11-19 07:28:53 --> Helper loaded: form_helper
INFO - 2021-11-19 07:28:53 --> Helper loaded: my_helper
INFO - 2021-11-19 07:28:53 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:28:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:28:53 --> Controller Class Initialized
DEBUG - 2021-11-19 07:28:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-11-19 07:28:53 --> Final output sent to browser
DEBUG - 2021-11-19 07:28:53 --> Total execution time: 0.1545
INFO - 2021-11-19 07:29:10 --> Config Class Initialized
INFO - 2021-11-19 07:29:10 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:29:10 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:29:10 --> Utf8 Class Initialized
INFO - 2021-11-19 07:29:10 --> URI Class Initialized
INFO - 2021-11-19 07:29:10 --> Router Class Initialized
INFO - 2021-11-19 07:29:10 --> Output Class Initialized
INFO - 2021-11-19 07:29:10 --> Security Class Initialized
DEBUG - 2021-11-19 07:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:29:10 --> Input Class Initialized
INFO - 2021-11-19 07:29:10 --> Language Class Initialized
INFO - 2021-11-19 07:29:10 --> Language Class Initialized
INFO - 2021-11-19 07:29:10 --> Config Class Initialized
INFO - 2021-11-19 07:29:10 --> Loader Class Initialized
INFO - 2021-11-19 07:29:10 --> Helper loaded: url_helper
INFO - 2021-11-19 07:29:10 --> Helper loaded: file_helper
INFO - 2021-11-19 07:29:10 --> Helper loaded: form_helper
INFO - 2021-11-19 07:29:10 --> Helper loaded: my_helper
INFO - 2021-11-19 07:29:10 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:29:10 --> Controller Class Initialized
DEBUG - 2021-11-19 07:29:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-11-19 07:29:10 --> Final output sent to browser
DEBUG - 2021-11-19 07:29:10 --> Total execution time: 0.1414
INFO - 2021-11-19 07:29:21 --> Config Class Initialized
INFO - 2021-11-19 07:29:21 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:29:21 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:29:21 --> Utf8 Class Initialized
INFO - 2021-11-19 07:29:21 --> URI Class Initialized
INFO - 2021-11-19 07:29:21 --> Router Class Initialized
INFO - 2021-11-19 07:29:21 --> Output Class Initialized
INFO - 2021-11-19 07:29:21 --> Security Class Initialized
DEBUG - 2021-11-19 07:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:29:21 --> Input Class Initialized
INFO - 2021-11-19 07:29:21 --> Language Class Initialized
INFO - 2021-11-19 07:29:21 --> Language Class Initialized
INFO - 2021-11-19 07:29:21 --> Config Class Initialized
INFO - 2021-11-19 07:29:21 --> Loader Class Initialized
INFO - 2021-11-19 07:29:21 --> Helper loaded: url_helper
INFO - 2021-11-19 07:29:21 --> Helper loaded: file_helper
INFO - 2021-11-19 07:29:21 --> Helper loaded: form_helper
INFO - 2021-11-19 07:29:21 --> Helper loaded: my_helper
INFO - 2021-11-19 07:29:21 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:29:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:29:21 --> Controller Class Initialized
DEBUG - 2021-11-19 07:29:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-11-19 07:29:21 --> Final output sent to browser
DEBUG - 2021-11-19 07:29:21 --> Total execution time: 0.1551
INFO - 2021-11-19 07:29:29 --> Config Class Initialized
INFO - 2021-11-19 07:29:29 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:29:29 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:29:29 --> Utf8 Class Initialized
INFO - 2021-11-19 07:29:29 --> URI Class Initialized
INFO - 2021-11-19 07:29:30 --> Router Class Initialized
INFO - 2021-11-19 07:29:30 --> Output Class Initialized
INFO - 2021-11-19 07:29:30 --> Security Class Initialized
DEBUG - 2021-11-19 07:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:29:30 --> Input Class Initialized
INFO - 2021-11-19 07:29:30 --> Language Class Initialized
INFO - 2021-11-19 07:29:30 --> Language Class Initialized
INFO - 2021-11-19 07:29:30 --> Config Class Initialized
INFO - 2021-11-19 07:29:30 --> Loader Class Initialized
INFO - 2021-11-19 07:29:30 --> Helper loaded: url_helper
INFO - 2021-11-19 07:29:30 --> Helper loaded: file_helper
INFO - 2021-11-19 07:29:30 --> Helper loaded: form_helper
INFO - 2021-11-19 07:29:30 --> Helper loaded: my_helper
INFO - 2021-11-19 07:29:30 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:29:30 --> Controller Class Initialized
DEBUG - 2021-11-19 07:29:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-11-19 07:29:30 --> Final output sent to browser
DEBUG - 2021-11-19 07:29:30 --> Total execution time: 0.1543
INFO - 2021-11-19 07:29:37 --> Config Class Initialized
INFO - 2021-11-19 07:29:37 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:29:37 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:29:37 --> Utf8 Class Initialized
INFO - 2021-11-19 07:29:37 --> URI Class Initialized
INFO - 2021-11-19 07:29:37 --> Router Class Initialized
INFO - 2021-11-19 07:29:37 --> Output Class Initialized
INFO - 2021-11-19 07:29:37 --> Security Class Initialized
DEBUG - 2021-11-19 07:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:29:37 --> Input Class Initialized
INFO - 2021-11-19 07:29:37 --> Language Class Initialized
INFO - 2021-11-19 07:29:37 --> Language Class Initialized
INFO - 2021-11-19 07:29:37 --> Config Class Initialized
INFO - 2021-11-19 07:29:37 --> Loader Class Initialized
INFO - 2021-11-19 07:29:37 --> Helper loaded: url_helper
INFO - 2021-11-19 07:29:37 --> Helper loaded: file_helper
INFO - 2021-11-19 07:29:37 --> Helper loaded: form_helper
INFO - 2021-11-19 07:29:37 --> Helper loaded: my_helper
INFO - 2021-11-19 07:29:37 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:29:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:29:37 --> Controller Class Initialized
INFO - 2021-11-19 07:29:37 --> Helper loaded: cookie_helper
INFO - 2021-11-19 07:29:37 --> Config Class Initialized
INFO - 2021-11-19 07:29:37 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:29:37 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:29:37 --> Utf8 Class Initialized
INFO - 2021-11-19 07:29:37 --> URI Class Initialized
INFO - 2021-11-19 07:29:37 --> Router Class Initialized
INFO - 2021-11-19 07:29:37 --> Output Class Initialized
INFO - 2021-11-19 07:29:37 --> Security Class Initialized
DEBUG - 2021-11-19 07:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:29:37 --> Input Class Initialized
INFO - 2021-11-19 07:29:37 --> Language Class Initialized
INFO - 2021-11-19 07:29:37 --> Language Class Initialized
INFO - 2021-11-19 07:29:37 --> Config Class Initialized
INFO - 2021-11-19 07:29:37 --> Loader Class Initialized
INFO - 2021-11-19 07:29:37 --> Helper loaded: url_helper
INFO - 2021-11-19 07:29:37 --> Helper loaded: file_helper
INFO - 2021-11-19 07:29:37 --> Helper loaded: form_helper
INFO - 2021-11-19 07:29:37 --> Helper loaded: my_helper
INFO - 2021-11-19 07:29:37 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:29:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:29:37 --> Controller Class Initialized
DEBUG - 2021-11-19 07:29:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-11-19 07:29:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 07:29:37 --> Final output sent to browser
DEBUG - 2021-11-19 07:29:37 --> Total execution time: 0.0484
INFO - 2021-11-19 07:29:44 --> Config Class Initialized
INFO - 2021-11-19 07:29:44 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:29:44 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:29:44 --> Utf8 Class Initialized
INFO - 2021-11-19 07:29:44 --> URI Class Initialized
INFO - 2021-11-19 07:29:44 --> Router Class Initialized
INFO - 2021-11-19 07:29:44 --> Output Class Initialized
INFO - 2021-11-19 07:29:44 --> Security Class Initialized
DEBUG - 2021-11-19 07:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:29:44 --> Input Class Initialized
INFO - 2021-11-19 07:29:44 --> Language Class Initialized
INFO - 2021-11-19 07:29:44 --> Language Class Initialized
INFO - 2021-11-19 07:29:44 --> Config Class Initialized
INFO - 2021-11-19 07:29:44 --> Loader Class Initialized
INFO - 2021-11-19 07:29:44 --> Helper loaded: url_helper
INFO - 2021-11-19 07:29:44 --> Helper loaded: file_helper
INFO - 2021-11-19 07:29:44 --> Helper loaded: form_helper
INFO - 2021-11-19 07:29:44 --> Helper loaded: my_helper
INFO - 2021-11-19 07:29:44 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:29:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:29:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:29:44 --> Controller Class Initialized
INFO - 2021-11-19 07:29:44 --> Helper loaded: cookie_helper
INFO - 2021-11-19 07:29:44 --> Final output sent to browser
DEBUG - 2021-11-19 07:29:44 --> Total execution time: 0.0909
INFO - 2021-11-19 07:29:44 --> Config Class Initialized
INFO - 2021-11-19 07:29:44 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:29:44 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:29:44 --> Utf8 Class Initialized
INFO - 2021-11-19 07:29:44 --> URI Class Initialized
INFO - 2021-11-19 07:29:44 --> Router Class Initialized
INFO - 2021-11-19 07:29:44 --> Output Class Initialized
INFO - 2021-11-19 07:29:44 --> Security Class Initialized
DEBUG - 2021-11-19 07:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:29:44 --> Input Class Initialized
INFO - 2021-11-19 07:29:44 --> Language Class Initialized
INFO - 2021-11-19 07:29:44 --> Language Class Initialized
INFO - 2021-11-19 07:29:44 --> Config Class Initialized
INFO - 2021-11-19 07:29:44 --> Loader Class Initialized
INFO - 2021-11-19 07:29:44 --> Helper loaded: url_helper
INFO - 2021-11-19 07:29:44 --> Helper loaded: file_helper
INFO - 2021-11-19 07:29:44 --> Helper loaded: form_helper
INFO - 2021-11-19 07:29:44 --> Helper loaded: my_helper
INFO - 2021-11-19 07:29:44 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:29:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:29:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:29:44 --> Controller Class Initialized
DEBUG - 2021-11-19 07:29:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-11-19 07:29:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 07:29:45 --> Final output sent to browser
DEBUG - 2021-11-19 07:29:45 --> Total execution time: 0.9831
INFO - 2021-11-19 07:29:48 --> Config Class Initialized
INFO - 2021-11-19 07:29:48 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:29:48 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:29:48 --> Utf8 Class Initialized
INFO - 2021-11-19 07:29:48 --> URI Class Initialized
INFO - 2021-11-19 07:29:48 --> Router Class Initialized
INFO - 2021-11-19 07:29:48 --> Output Class Initialized
INFO - 2021-11-19 07:29:48 --> Security Class Initialized
DEBUG - 2021-11-19 07:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:29:48 --> Input Class Initialized
INFO - 2021-11-19 07:29:48 --> Language Class Initialized
INFO - 2021-11-19 07:29:48 --> Language Class Initialized
INFO - 2021-11-19 07:29:48 --> Config Class Initialized
INFO - 2021-11-19 07:29:48 --> Loader Class Initialized
INFO - 2021-11-19 07:29:48 --> Helper loaded: url_helper
INFO - 2021-11-19 07:29:48 --> Helper loaded: file_helper
INFO - 2021-11-19 07:29:48 --> Helper loaded: form_helper
INFO - 2021-11-19 07:29:48 --> Helper loaded: my_helper
INFO - 2021-11-19 07:29:48 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:29:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:29:48 --> Controller Class Initialized
DEBUG - 2021-11-19 07:29:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-11-19 07:29:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 07:29:48 --> Final output sent to browser
DEBUG - 2021-11-19 07:29:48 --> Total execution time: 0.1179
INFO - 2021-11-19 07:29:49 --> Config Class Initialized
INFO - 2021-11-19 07:29:49 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:29:49 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:29:49 --> Utf8 Class Initialized
INFO - 2021-11-19 07:29:49 --> URI Class Initialized
INFO - 2021-11-19 07:29:49 --> Router Class Initialized
INFO - 2021-11-19 07:29:49 --> Output Class Initialized
INFO - 2021-11-19 07:29:49 --> Security Class Initialized
DEBUG - 2021-11-19 07:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:29:49 --> Input Class Initialized
INFO - 2021-11-19 07:29:49 --> Language Class Initialized
INFO - 2021-11-19 07:29:49 --> Language Class Initialized
INFO - 2021-11-19 07:29:49 --> Config Class Initialized
INFO - 2021-11-19 07:29:49 --> Loader Class Initialized
INFO - 2021-11-19 07:29:49 --> Helper loaded: url_helper
INFO - 2021-11-19 07:29:49 --> Helper loaded: file_helper
INFO - 2021-11-19 07:29:49 --> Helper loaded: form_helper
INFO - 2021-11-19 07:29:49 --> Helper loaded: my_helper
INFO - 2021-11-19 07:29:49 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:29:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:29:49 --> Controller Class Initialized
INFO - 2021-11-19 07:29:50 --> Config Class Initialized
INFO - 2021-11-19 07:29:50 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:29:50 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:29:50 --> Utf8 Class Initialized
INFO - 2021-11-19 07:29:50 --> URI Class Initialized
INFO - 2021-11-19 07:29:50 --> Router Class Initialized
INFO - 2021-11-19 07:29:50 --> Output Class Initialized
INFO - 2021-11-19 07:29:50 --> Security Class Initialized
DEBUG - 2021-11-19 07:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:29:50 --> Input Class Initialized
INFO - 2021-11-19 07:29:50 --> Language Class Initialized
INFO - 2021-11-19 07:29:50 --> Language Class Initialized
INFO - 2021-11-19 07:29:50 --> Config Class Initialized
INFO - 2021-11-19 07:29:50 --> Loader Class Initialized
INFO - 2021-11-19 07:29:50 --> Helper loaded: url_helper
INFO - 2021-11-19 07:29:50 --> Helper loaded: file_helper
INFO - 2021-11-19 07:29:50 --> Helper loaded: form_helper
INFO - 2021-11-19 07:29:50 --> Helper loaded: my_helper
INFO - 2021-11-19 07:29:50 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:29:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:29:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:29:50 --> Controller Class Initialized
INFO - 2021-11-19 07:29:50 --> Final output sent to browser
DEBUG - 2021-11-19 07:29:50 --> Total execution time: 0.0791
INFO - 2021-11-19 07:29:50 --> Config Class Initialized
INFO - 2021-11-19 07:29:50 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:29:50 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:29:50 --> Utf8 Class Initialized
INFO - 2021-11-19 07:29:50 --> URI Class Initialized
INFO - 2021-11-19 07:29:50 --> Router Class Initialized
INFO - 2021-11-19 07:29:50 --> Output Class Initialized
INFO - 2021-11-19 07:29:50 --> Security Class Initialized
DEBUG - 2021-11-19 07:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:29:50 --> Input Class Initialized
INFO - 2021-11-19 07:29:50 --> Language Class Initialized
INFO - 2021-11-19 07:29:50 --> Language Class Initialized
INFO - 2021-11-19 07:29:50 --> Config Class Initialized
INFO - 2021-11-19 07:29:50 --> Loader Class Initialized
INFO - 2021-11-19 07:29:50 --> Helper loaded: url_helper
INFO - 2021-11-19 07:29:50 --> Helper loaded: file_helper
INFO - 2021-11-19 07:29:50 --> Helper loaded: form_helper
INFO - 2021-11-19 07:29:50 --> Helper loaded: my_helper
INFO - 2021-11-19 07:29:50 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:29:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:29:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:29:50 --> Controller Class Initialized
INFO - 2021-11-19 07:29:53 --> Config Class Initialized
INFO - 2021-11-19 07:29:53 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:29:53 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:29:53 --> Utf8 Class Initialized
INFO - 2021-11-19 07:29:53 --> URI Class Initialized
INFO - 2021-11-19 07:29:53 --> Router Class Initialized
INFO - 2021-11-19 07:29:53 --> Output Class Initialized
INFO - 2021-11-19 07:29:53 --> Security Class Initialized
DEBUG - 2021-11-19 07:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:29:53 --> Input Class Initialized
INFO - 2021-11-19 07:29:53 --> Language Class Initialized
INFO - 2021-11-19 07:29:53 --> Language Class Initialized
INFO - 2021-11-19 07:29:53 --> Config Class Initialized
INFO - 2021-11-19 07:29:53 --> Loader Class Initialized
INFO - 2021-11-19 07:29:53 --> Helper loaded: url_helper
INFO - 2021-11-19 07:29:53 --> Helper loaded: file_helper
INFO - 2021-11-19 07:29:53 --> Helper loaded: form_helper
INFO - 2021-11-19 07:29:53 --> Helper loaded: my_helper
INFO - 2021-11-19 07:29:53 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:29:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:29:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:29:53 --> Controller Class Initialized
INFO - 2021-11-19 07:29:53 --> Helper loaded: cookie_helper
INFO - 2021-11-19 07:29:53 --> Config Class Initialized
INFO - 2021-11-19 07:29:53 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:29:53 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:29:53 --> Utf8 Class Initialized
INFO - 2021-11-19 07:29:53 --> URI Class Initialized
INFO - 2021-11-19 07:29:53 --> Router Class Initialized
INFO - 2021-11-19 07:29:53 --> Output Class Initialized
INFO - 2021-11-19 07:29:53 --> Security Class Initialized
DEBUG - 2021-11-19 07:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:29:53 --> Input Class Initialized
INFO - 2021-11-19 07:29:53 --> Language Class Initialized
INFO - 2021-11-19 07:29:53 --> Language Class Initialized
INFO - 2021-11-19 07:29:53 --> Config Class Initialized
INFO - 2021-11-19 07:29:53 --> Loader Class Initialized
INFO - 2021-11-19 07:29:53 --> Helper loaded: url_helper
INFO - 2021-11-19 07:29:53 --> Helper loaded: file_helper
INFO - 2021-11-19 07:29:53 --> Helper loaded: form_helper
INFO - 2021-11-19 07:29:53 --> Helper loaded: my_helper
INFO - 2021-11-19 07:29:53 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:29:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:29:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:29:53 --> Controller Class Initialized
DEBUG - 2021-11-19 07:29:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-11-19 07:29:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 07:29:53 --> Final output sent to browser
DEBUG - 2021-11-19 07:29:53 --> Total execution time: 0.0520
INFO - 2021-11-19 07:29:56 --> Config Class Initialized
INFO - 2021-11-19 07:29:56 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:29:56 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:29:56 --> Utf8 Class Initialized
INFO - 2021-11-19 07:29:56 --> URI Class Initialized
INFO - 2021-11-19 07:29:56 --> Router Class Initialized
INFO - 2021-11-19 07:29:56 --> Output Class Initialized
INFO - 2021-11-19 07:29:56 --> Security Class Initialized
DEBUG - 2021-11-19 07:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:29:56 --> Input Class Initialized
INFO - 2021-11-19 07:29:56 --> Language Class Initialized
INFO - 2021-11-19 07:29:56 --> Language Class Initialized
INFO - 2021-11-19 07:29:56 --> Config Class Initialized
INFO - 2021-11-19 07:29:56 --> Loader Class Initialized
INFO - 2021-11-19 07:29:56 --> Helper loaded: url_helper
INFO - 2021-11-19 07:29:56 --> Helper loaded: file_helper
INFO - 2021-11-19 07:29:56 --> Helper loaded: form_helper
INFO - 2021-11-19 07:29:56 --> Helper loaded: my_helper
INFO - 2021-11-19 07:29:56 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:29:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:29:56 --> Controller Class Initialized
INFO - 2021-11-19 07:29:56 --> Helper loaded: cookie_helper
INFO - 2021-11-19 07:29:56 --> Final output sent to browser
DEBUG - 2021-11-19 07:29:56 --> Total execution time: 0.0885
INFO - 2021-11-19 07:29:56 --> Config Class Initialized
INFO - 2021-11-19 07:29:56 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:29:56 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:29:56 --> Utf8 Class Initialized
INFO - 2021-11-19 07:29:56 --> URI Class Initialized
INFO - 2021-11-19 07:29:56 --> Router Class Initialized
INFO - 2021-11-19 07:29:56 --> Output Class Initialized
INFO - 2021-11-19 07:29:56 --> Security Class Initialized
DEBUG - 2021-11-19 07:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:29:56 --> Input Class Initialized
INFO - 2021-11-19 07:29:56 --> Language Class Initialized
INFO - 2021-11-19 07:29:56 --> Language Class Initialized
INFO - 2021-11-19 07:29:56 --> Config Class Initialized
INFO - 2021-11-19 07:29:56 --> Loader Class Initialized
INFO - 2021-11-19 07:29:56 --> Helper loaded: url_helper
INFO - 2021-11-19 07:29:56 --> Helper loaded: file_helper
INFO - 2021-11-19 07:29:56 --> Helper loaded: form_helper
INFO - 2021-11-19 07:29:56 --> Helper loaded: my_helper
INFO - 2021-11-19 07:29:56 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:29:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:29:56 --> Controller Class Initialized
DEBUG - 2021-11-19 07:29:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-11-19 07:29:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 07:29:57 --> Final output sent to browser
DEBUG - 2021-11-19 07:29:57 --> Total execution time: 0.2120
INFO - 2021-11-19 07:29:58 --> Config Class Initialized
INFO - 2021-11-19 07:29:58 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:29:58 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:29:58 --> Utf8 Class Initialized
INFO - 2021-11-19 07:29:58 --> URI Class Initialized
INFO - 2021-11-19 07:29:58 --> Router Class Initialized
INFO - 2021-11-19 07:29:58 --> Output Class Initialized
INFO - 2021-11-19 07:29:58 --> Security Class Initialized
DEBUG - 2021-11-19 07:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:29:58 --> Input Class Initialized
INFO - 2021-11-19 07:29:58 --> Language Class Initialized
INFO - 2021-11-19 07:29:58 --> Language Class Initialized
INFO - 2021-11-19 07:29:58 --> Config Class Initialized
INFO - 2021-11-19 07:29:58 --> Loader Class Initialized
INFO - 2021-11-19 07:29:58 --> Helper loaded: url_helper
INFO - 2021-11-19 07:29:58 --> Helper loaded: file_helper
INFO - 2021-11-19 07:29:58 --> Helper loaded: form_helper
INFO - 2021-11-19 07:29:58 --> Helper loaded: my_helper
INFO - 2021-11-19 07:29:58 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:29:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:29:58 --> Controller Class Initialized
DEBUG - 2021-11-19 07:29:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-11-19 07:29:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 07:29:58 --> Final output sent to browser
DEBUG - 2021-11-19 07:29:58 --> Total execution time: 0.0927
INFO - 2021-11-19 07:30:00 --> Config Class Initialized
INFO - 2021-11-19 07:30:00 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:30:00 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:30:00 --> Utf8 Class Initialized
INFO - 2021-11-19 07:30:00 --> URI Class Initialized
INFO - 2021-11-19 07:30:00 --> Router Class Initialized
INFO - 2021-11-19 07:30:00 --> Output Class Initialized
INFO - 2021-11-19 07:30:00 --> Security Class Initialized
DEBUG - 2021-11-19 07:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:30:00 --> Input Class Initialized
INFO - 2021-11-19 07:30:00 --> Language Class Initialized
INFO - 2021-11-19 07:30:00 --> Language Class Initialized
INFO - 2021-11-19 07:30:00 --> Config Class Initialized
INFO - 2021-11-19 07:30:00 --> Loader Class Initialized
INFO - 2021-11-19 07:30:00 --> Helper loaded: url_helper
INFO - 2021-11-19 07:30:00 --> Helper loaded: file_helper
INFO - 2021-11-19 07:30:00 --> Helper loaded: form_helper
INFO - 2021-11-19 07:30:00 --> Helper loaded: my_helper
INFO - 2021-11-19 07:30:00 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:30:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:30:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:30:00 --> Controller Class Initialized
DEBUG - 2021-11-19 07:30:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-19 07:30:00 --> Final output sent to browser
DEBUG - 2021-11-19 07:30:00 --> Total execution time: 0.1398
INFO - 2021-11-19 07:30:16 --> Config Class Initialized
INFO - 2021-11-19 07:30:16 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:30:16 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:30:16 --> Utf8 Class Initialized
INFO - 2021-11-19 07:30:16 --> URI Class Initialized
INFO - 2021-11-19 07:30:16 --> Router Class Initialized
INFO - 2021-11-19 07:30:16 --> Output Class Initialized
INFO - 2021-11-19 07:30:16 --> Security Class Initialized
DEBUG - 2021-11-19 07:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:30:16 --> Input Class Initialized
INFO - 2021-11-19 07:30:16 --> Language Class Initialized
INFO - 2021-11-19 07:30:16 --> Language Class Initialized
INFO - 2021-11-19 07:30:16 --> Config Class Initialized
INFO - 2021-11-19 07:30:16 --> Loader Class Initialized
INFO - 2021-11-19 07:30:16 --> Helper loaded: url_helper
INFO - 2021-11-19 07:30:16 --> Helper loaded: file_helper
INFO - 2021-11-19 07:30:16 --> Helper loaded: form_helper
INFO - 2021-11-19 07:30:16 --> Helper loaded: my_helper
INFO - 2021-11-19 07:30:16 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:30:16 --> Controller Class Initialized
DEBUG - 2021-11-19 07:30:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2021-11-19 07:30:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 07:30:16 --> Final output sent to browser
DEBUG - 2021-11-19 07:30:16 --> Total execution time: 0.1100
INFO - 2021-11-19 07:30:17 --> Config Class Initialized
INFO - 2021-11-19 07:30:17 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:30:17 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:30:17 --> Utf8 Class Initialized
INFO - 2021-11-19 07:30:17 --> URI Class Initialized
INFO - 2021-11-19 07:30:17 --> Router Class Initialized
INFO - 2021-11-19 07:30:17 --> Output Class Initialized
INFO - 2021-11-19 07:30:17 --> Security Class Initialized
DEBUG - 2021-11-19 07:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:30:17 --> Input Class Initialized
INFO - 2021-11-19 07:30:17 --> Language Class Initialized
INFO - 2021-11-19 07:30:17 --> Language Class Initialized
INFO - 2021-11-19 07:30:17 --> Config Class Initialized
INFO - 2021-11-19 07:30:17 --> Loader Class Initialized
INFO - 2021-11-19 07:30:17 --> Helper loaded: url_helper
INFO - 2021-11-19 07:30:17 --> Helper loaded: file_helper
INFO - 2021-11-19 07:30:18 --> Helper loaded: form_helper
INFO - 2021-11-19 07:30:18 --> Helper loaded: my_helper
INFO - 2021-11-19 07:30:18 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:30:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:30:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:30:18 --> Controller Class Initialized
DEBUG - 2021-11-19 07:30:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-11-19 07:30:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 07:30:18 --> Final output sent to browser
DEBUG - 2021-11-19 07:30:18 --> Total execution time: 0.1893
INFO - 2021-11-19 07:30:35 --> Config Class Initialized
INFO - 2021-11-19 07:30:35 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:30:35 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:30:35 --> Utf8 Class Initialized
INFO - 2021-11-19 07:30:35 --> URI Class Initialized
INFO - 2021-11-19 07:30:35 --> Router Class Initialized
INFO - 2021-11-19 07:30:35 --> Output Class Initialized
INFO - 2021-11-19 07:30:35 --> Security Class Initialized
DEBUG - 2021-11-19 07:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:30:35 --> Input Class Initialized
INFO - 2021-11-19 07:30:35 --> Language Class Initialized
INFO - 2021-11-19 07:30:35 --> Language Class Initialized
INFO - 2021-11-19 07:30:35 --> Config Class Initialized
INFO - 2021-11-19 07:30:35 --> Loader Class Initialized
INFO - 2021-11-19 07:30:35 --> Helper loaded: url_helper
INFO - 2021-11-19 07:30:35 --> Helper loaded: file_helper
INFO - 2021-11-19 07:30:35 --> Helper loaded: form_helper
INFO - 2021-11-19 07:30:35 --> Helper loaded: my_helper
INFO - 2021-11-19 07:30:35 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:30:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:30:35 --> Controller Class Initialized
INFO - 2021-11-19 07:30:35 --> Final output sent to browser
DEBUG - 2021-11-19 07:30:35 --> Total execution time: 0.1167
INFO - 2021-11-19 07:30:37 --> Config Class Initialized
INFO - 2021-11-19 07:30:37 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:30:37 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:30:37 --> Utf8 Class Initialized
INFO - 2021-11-19 07:30:37 --> URI Class Initialized
INFO - 2021-11-19 07:30:37 --> Router Class Initialized
INFO - 2021-11-19 07:30:37 --> Output Class Initialized
INFO - 2021-11-19 07:30:37 --> Security Class Initialized
DEBUG - 2021-11-19 07:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:30:37 --> Input Class Initialized
INFO - 2021-11-19 07:30:37 --> Language Class Initialized
INFO - 2021-11-19 07:30:37 --> Language Class Initialized
INFO - 2021-11-19 07:30:37 --> Config Class Initialized
INFO - 2021-11-19 07:30:37 --> Loader Class Initialized
INFO - 2021-11-19 07:30:37 --> Helper loaded: url_helper
INFO - 2021-11-19 07:30:37 --> Helper loaded: file_helper
INFO - 2021-11-19 07:30:37 --> Helper loaded: form_helper
INFO - 2021-11-19 07:30:37 --> Helper loaded: my_helper
INFO - 2021-11-19 07:30:37 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:30:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:30:37 --> Controller Class Initialized
DEBUG - 2021-11-19 07:30:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-11-19 07:30:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 07:30:37 --> Final output sent to browser
DEBUG - 2021-11-19 07:30:37 --> Total execution time: 0.0951
INFO - 2021-11-19 07:30:41 --> Config Class Initialized
INFO - 2021-11-19 07:30:41 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:30:41 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:30:41 --> Utf8 Class Initialized
INFO - 2021-11-19 07:30:41 --> URI Class Initialized
INFO - 2021-11-19 07:30:41 --> Router Class Initialized
INFO - 2021-11-19 07:30:41 --> Output Class Initialized
INFO - 2021-11-19 07:30:41 --> Security Class Initialized
DEBUG - 2021-11-19 07:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:30:41 --> Input Class Initialized
INFO - 2021-11-19 07:30:41 --> Language Class Initialized
INFO - 2021-11-19 07:30:41 --> Language Class Initialized
INFO - 2021-11-19 07:30:41 --> Config Class Initialized
INFO - 2021-11-19 07:30:41 --> Loader Class Initialized
INFO - 2021-11-19 07:30:41 --> Helper loaded: url_helper
INFO - 2021-11-19 07:30:41 --> Helper loaded: file_helper
INFO - 2021-11-19 07:30:41 --> Helper loaded: form_helper
INFO - 2021-11-19 07:30:41 --> Helper loaded: my_helper
INFO - 2021-11-19 07:30:41 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:30:41 --> Controller Class Initialized
DEBUG - 2021-11-19 07:30:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-11-19 07:30:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 07:30:41 --> Final output sent to browser
DEBUG - 2021-11-19 07:30:41 --> Total execution time: 0.1210
INFO - 2021-11-19 07:30:54 --> Config Class Initialized
INFO - 2021-11-19 07:30:54 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:30:54 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:30:54 --> Utf8 Class Initialized
INFO - 2021-11-19 07:30:54 --> URI Class Initialized
INFO - 2021-11-19 07:30:54 --> Router Class Initialized
INFO - 2021-11-19 07:30:54 --> Output Class Initialized
INFO - 2021-11-19 07:30:54 --> Security Class Initialized
DEBUG - 2021-11-19 07:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:30:54 --> Input Class Initialized
INFO - 2021-11-19 07:30:54 --> Language Class Initialized
INFO - 2021-11-19 07:30:55 --> Language Class Initialized
INFO - 2021-11-19 07:30:55 --> Config Class Initialized
INFO - 2021-11-19 07:30:55 --> Loader Class Initialized
INFO - 2021-11-19 07:30:55 --> Helper loaded: url_helper
INFO - 2021-11-19 07:30:55 --> Helper loaded: file_helper
INFO - 2021-11-19 07:30:55 --> Helper loaded: form_helper
INFO - 2021-11-19 07:30:55 --> Helper loaded: my_helper
INFO - 2021-11-19 07:30:55 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:30:55 --> Controller Class Initialized
DEBUG - 2021-11-19 07:30:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-11-19 07:30:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 07:30:55 --> Final output sent to browser
DEBUG - 2021-11-19 07:30:55 --> Total execution time: 0.1701
INFO - 2021-11-19 07:30:56 --> Config Class Initialized
INFO - 2021-11-19 07:30:56 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:30:56 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:30:56 --> Utf8 Class Initialized
INFO - 2021-11-19 07:30:56 --> URI Class Initialized
INFO - 2021-11-19 07:30:56 --> Router Class Initialized
INFO - 2021-11-19 07:30:56 --> Output Class Initialized
INFO - 2021-11-19 07:30:56 --> Security Class Initialized
DEBUG - 2021-11-19 07:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:30:56 --> Input Class Initialized
INFO - 2021-11-19 07:30:56 --> Language Class Initialized
INFO - 2021-11-19 07:30:56 --> Language Class Initialized
INFO - 2021-11-19 07:30:56 --> Config Class Initialized
INFO - 2021-11-19 07:30:56 --> Loader Class Initialized
INFO - 2021-11-19 07:30:56 --> Helper loaded: url_helper
INFO - 2021-11-19 07:30:56 --> Helper loaded: file_helper
INFO - 2021-11-19 07:30:56 --> Helper loaded: form_helper
INFO - 2021-11-19 07:30:56 --> Helper loaded: my_helper
INFO - 2021-11-19 07:30:56 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:30:56 --> Controller Class Initialized
INFO - 2021-11-19 07:30:56 --> Final output sent to browser
DEBUG - 2021-11-19 07:30:56 --> Total execution time: 0.0535
INFO - 2021-11-19 07:31:02 --> Config Class Initialized
INFO - 2021-11-19 07:31:02 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:31:02 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:31:02 --> Utf8 Class Initialized
INFO - 2021-11-19 07:31:02 --> URI Class Initialized
INFO - 2021-11-19 07:31:02 --> Router Class Initialized
INFO - 2021-11-19 07:31:02 --> Output Class Initialized
INFO - 2021-11-19 07:31:02 --> Security Class Initialized
DEBUG - 2021-11-19 07:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:31:02 --> Input Class Initialized
INFO - 2021-11-19 07:31:02 --> Language Class Initialized
INFO - 2021-11-19 07:31:02 --> Language Class Initialized
INFO - 2021-11-19 07:31:02 --> Config Class Initialized
INFO - 2021-11-19 07:31:02 --> Loader Class Initialized
INFO - 2021-11-19 07:31:02 --> Helper loaded: url_helper
INFO - 2021-11-19 07:31:02 --> Helper loaded: file_helper
INFO - 2021-11-19 07:31:02 --> Helper loaded: form_helper
INFO - 2021-11-19 07:31:02 --> Helper loaded: my_helper
INFO - 2021-11-19 07:31:02 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:31:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:31:02 --> Controller Class Initialized
DEBUG - 2021-11-19 07:31:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-11-19 07:31:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 07:31:02 --> Final output sent to browser
DEBUG - 2021-11-19 07:31:02 --> Total execution time: 0.1479
INFO - 2021-11-19 07:31:07 --> Config Class Initialized
INFO - 2021-11-19 07:31:07 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:31:07 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:31:07 --> Utf8 Class Initialized
INFO - 2021-11-19 07:31:07 --> URI Class Initialized
INFO - 2021-11-19 07:31:07 --> Router Class Initialized
INFO - 2021-11-19 07:31:07 --> Output Class Initialized
INFO - 2021-11-19 07:31:07 --> Security Class Initialized
DEBUG - 2021-11-19 07:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:31:07 --> Input Class Initialized
INFO - 2021-11-19 07:31:07 --> Language Class Initialized
INFO - 2021-11-19 07:31:07 --> Language Class Initialized
INFO - 2021-11-19 07:31:07 --> Config Class Initialized
INFO - 2021-11-19 07:31:07 --> Loader Class Initialized
INFO - 2021-11-19 07:31:07 --> Helper loaded: url_helper
INFO - 2021-11-19 07:31:07 --> Helper loaded: file_helper
INFO - 2021-11-19 07:31:07 --> Helper loaded: form_helper
INFO - 2021-11-19 07:31:07 --> Helper loaded: my_helper
INFO - 2021-11-19 07:31:07 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:31:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:31:07 --> Controller Class Initialized
INFO - 2021-11-19 07:31:07 --> Final output sent to browser
DEBUG - 2021-11-19 07:31:07 --> Total execution time: 0.1035
INFO - 2021-11-19 07:31:15 --> Config Class Initialized
INFO - 2021-11-19 07:31:15 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:31:15 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:31:15 --> Utf8 Class Initialized
INFO - 2021-11-19 07:31:15 --> URI Class Initialized
INFO - 2021-11-19 07:31:15 --> Router Class Initialized
INFO - 2021-11-19 07:31:15 --> Output Class Initialized
INFO - 2021-11-19 07:31:15 --> Security Class Initialized
DEBUG - 2021-11-19 07:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:31:15 --> Input Class Initialized
INFO - 2021-11-19 07:31:15 --> Language Class Initialized
INFO - 2021-11-19 07:31:15 --> Language Class Initialized
INFO - 2021-11-19 07:31:15 --> Config Class Initialized
INFO - 2021-11-19 07:31:15 --> Loader Class Initialized
INFO - 2021-11-19 07:31:15 --> Helper loaded: url_helper
INFO - 2021-11-19 07:31:15 --> Helper loaded: file_helper
INFO - 2021-11-19 07:31:15 --> Helper loaded: form_helper
INFO - 2021-11-19 07:31:15 --> Helper loaded: my_helper
INFO - 2021-11-19 07:31:15 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:31:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:31:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:31:15 --> Controller Class Initialized
DEBUG - 2021-11-19 07:31:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-19 07:31:15 --> Final output sent to browser
DEBUG - 2021-11-19 07:31:15 --> Total execution time: 0.0762
INFO - 2021-11-19 07:46:25 --> Config Class Initialized
INFO - 2021-11-19 07:46:25 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:46:25 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:46:25 --> Utf8 Class Initialized
INFO - 2021-11-19 07:46:25 --> URI Class Initialized
INFO - 2021-11-19 07:46:25 --> Router Class Initialized
INFO - 2021-11-19 07:46:25 --> Output Class Initialized
INFO - 2021-11-19 07:46:25 --> Security Class Initialized
DEBUG - 2021-11-19 07:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:46:25 --> Input Class Initialized
INFO - 2021-11-19 07:46:25 --> Language Class Initialized
INFO - 2021-11-19 07:46:25 --> Language Class Initialized
INFO - 2021-11-19 07:46:25 --> Config Class Initialized
INFO - 2021-11-19 07:46:25 --> Loader Class Initialized
INFO - 2021-11-19 07:46:25 --> Helper loaded: url_helper
INFO - 2021-11-19 07:46:25 --> Helper loaded: file_helper
INFO - 2021-11-19 07:46:25 --> Helper loaded: form_helper
INFO - 2021-11-19 07:46:25 --> Helper loaded: my_helper
INFO - 2021-11-19 07:46:25 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:46:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:46:25 --> Controller Class Initialized
INFO - 2021-11-19 07:46:25 --> Helper loaded: cookie_helper
INFO - 2021-11-19 07:46:25 --> Config Class Initialized
INFO - 2021-11-19 07:46:25 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:46:25 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:46:25 --> Utf8 Class Initialized
INFO - 2021-11-19 07:46:25 --> URI Class Initialized
INFO - 2021-11-19 07:46:25 --> Router Class Initialized
INFO - 2021-11-19 07:46:25 --> Output Class Initialized
INFO - 2021-11-19 07:46:25 --> Security Class Initialized
DEBUG - 2021-11-19 07:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:46:25 --> Input Class Initialized
INFO - 2021-11-19 07:46:25 --> Language Class Initialized
INFO - 2021-11-19 07:46:25 --> Language Class Initialized
INFO - 2021-11-19 07:46:25 --> Config Class Initialized
INFO - 2021-11-19 07:46:25 --> Loader Class Initialized
INFO - 2021-11-19 07:46:25 --> Helper loaded: url_helper
INFO - 2021-11-19 07:46:25 --> Helper loaded: file_helper
INFO - 2021-11-19 07:46:25 --> Helper loaded: form_helper
INFO - 2021-11-19 07:46:25 --> Helper loaded: my_helper
INFO - 2021-11-19 07:46:25 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:46:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:46:25 --> Controller Class Initialized
DEBUG - 2021-11-19 07:46:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-11-19 07:46:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 07:46:25 --> Final output sent to browser
DEBUG - 2021-11-19 07:46:25 --> Total execution time: 0.0566
INFO - 2021-11-19 07:46:30 --> Config Class Initialized
INFO - 2021-11-19 07:46:30 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:46:30 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:46:30 --> Utf8 Class Initialized
INFO - 2021-11-19 07:46:30 --> URI Class Initialized
INFO - 2021-11-19 07:46:30 --> Router Class Initialized
INFO - 2021-11-19 07:46:30 --> Output Class Initialized
INFO - 2021-11-19 07:46:30 --> Security Class Initialized
DEBUG - 2021-11-19 07:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:46:30 --> Input Class Initialized
INFO - 2021-11-19 07:46:30 --> Language Class Initialized
INFO - 2021-11-19 07:46:30 --> Language Class Initialized
INFO - 2021-11-19 07:46:30 --> Config Class Initialized
INFO - 2021-11-19 07:46:30 --> Loader Class Initialized
INFO - 2021-11-19 07:46:30 --> Helper loaded: url_helper
INFO - 2021-11-19 07:46:30 --> Helper loaded: file_helper
INFO - 2021-11-19 07:46:30 --> Helper loaded: form_helper
INFO - 2021-11-19 07:46:30 --> Helper loaded: my_helper
INFO - 2021-11-19 07:46:30 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:46:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:46:30 --> Controller Class Initialized
INFO - 2021-11-19 07:46:30 --> Helper loaded: cookie_helper
INFO - 2021-11-19 07:46:30 --> Final output sent to browser
DEBUG - 2021-11-19 07:46:30 --> Total execution time: 0.0731
INFO - 2021-11-19 07:46:30 --> Config Class Initialized
INFO - 2021-11-19 07:46:30 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:46:30 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:46:30 --> Utf8 Class Initialized
INFO - 2021-11-19 07:46:30 --> URI Class Initialized
INFO - 2021-11-19 07:46:30 --> Router Class Initialized
INFO - 2021-11-19 07:46:30 --> Output Class Initialized
INFO - 2021-11-19 07:46:30 --> Security Class Initialized
DEBUG - 2021-11-19 07:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:46:30 --> Input Class Initialized
INFO - 2021-11-19 07:46:30 --> Language Class Initialized
INFO - 2021-11-19 07:46:30 --> Language Class Initialized
INFO - 2021-11-19 07:46:30 --> Config Class Initialized
INFO - 2021-11-19 07:46:30 --> Loader Class Initialized
INFO - 2021-11-19 07:46:30 --> Helper loaded: url_helper
INFO - 2021-11-19 07:46:30 --> Helper loaded: file_helper
INFO - 2021-11-19 07:46:30 --> Helper loaded: form_helper
INFO - 2021-11-19 07:46:30 --> Helper loaded: my_helper
INFO - 2021-11-19 07:46:30 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:46:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:46:30 --> Controller Class Initialized
DEBUG - 2021-11-19 07:46:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-11-19 07:46:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 07:46:31 --> Final output sent to browser
DEBUG - 2021-11-19 07:46:31 --> Total execution time: 0.2595
INFO - 2021-11-19 07:46:36 --> Config Class Initialized
INFO - 2021-11-19 07:46:36 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:46:36 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:46:36 --> Utf8 Class Initialized
INFO - 2021-11-19 07:46:36 --> URI Class Initialized
INFO - 2021-11-19 07:46:36 --> Router Class Initialized
INFO - 2021-11-19 07:46:36 --> Output Class Initialized
INFO - 2021-11-19 07:46:36 --> Security Class Initialized
DEBUG - 2021-11-19 07:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:46:36 --> Input Class Initialized
INFO - 2021-11-19 07:46:36 --> Language Class Initialized
INFO - 2021-11-19 07:46:36 --> Language Class Initialized
INFO - 2021-11-19 07:46:36 --> Config Class Initialized
INFO - 2021-11-19 07:46:36 --> Loader Class Initialized
INFO - 2021-11-19 07:46:36 --> Helper loaded: url_helper
INFO - 2021-11-19 07:46:36 --> Helper loaded: file_helper
INFO - 2021-11-19 07:46:36 --> Helper loaded: form_helper
INFO - 2021-11-19 07:46:36 --> Helper loaded: my_helper
INFO - 2021-11-19 07:46:36 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:46:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:46:36 --> Controller Class Initialized
DEBUG - 2021-11-19 07:46:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-11-19 07:46:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 07:46:36 --> Final output sent to browser
DEBUG - 2021-11-19 07:46:36 --> Total execution time: 0.0760
INFO - 2021-11-19 07:46:36 --> Config Class Initialized
INFO - 2021-11-19 07:46:36 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:46:36 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:46:36 --> Utf8 Class Initialized
INFO - 2021-11-19 07:46:36 --> URI Class Initialized
INFO - 2021-11-19 07:46:36 --> Router Class Initialized
INFO - 2021-11-19 07:46:36 --> Output Class Initialized
INFO - 2021-11-19 07:46:36 --> Security Class Initialized
DEBUG - 2021-11-19 07:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:46:36 --> Input Class Initialized
INFO - 2021-11-19 07:46:36 --> Language Class Initialized
INFO - 2021-11-19 07:46:36 --> Language Class Initialized
INFO - 2021-11-19 07:46:36 --> Config Class Initialized
INFO - 2021-11-19 07:46:36 --> Loader Class Initialized
INFO - 2021-11-19 07:46:36 --> Helper loaded: url_helper
INFO - 2021-11-19 07:46:36 --> Helper loaded: file_helper
INFO - 2021-11-19 07:46:36 --> Helper loaded: form_helper
INFO - 2021-11-19 07:46:36 --> Helper loaded: my_helper
INFO - 2021-11-19 07:46:36 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:46:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:46:36 --> Controller Class Initialized
INFO - 2021-11-19 07:46:37 --> Config Class Initialized
INFO - 2021-11-19 07:46:37 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:46:37 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:46:37 --> Utf8 Class Initialized
INFO - 2021-11-19 07:46:37 --> URI Class Initialized
INFO - 2021-11-19 07:46:37 --> Router Class Initialized
INFO - 2021-11-19 07:46:37 --> Output Class Initialized
INFO - 2021-11-19 07:46:37 --> Security Class Initialized
DEBUG - 2021-11-19 07:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:46:37 --> Input Class Initialized
INFO - 2021-11-19 07:46:37 --> Language Class Initialized
INFO - 2021-11-19 07:46:37 --> Language Class Initialized
INFO - 2021-11-19 07:46:37 --> Config Class Initialized
INFO - 2021-11-19 07:46:37 --> Loader Class Initialized
INFO - 2021-11-19 07:46:37 --> Helper loaded: url_helper
INFO - 2021-11-19 07:46:37 --> Helper loaded: file_helper
INFO - 2021-11-19 07:46:37 --> Helper loaded: form_helper
INFO - 2021-11-19 07:46:37 --> Helper loaded: my_helper
INFO - 2021-11-19 07:46:37 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:46:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:46:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:46:37 --> Controller Class Initialized
INFO - 2021-11-19 07:46:37 --> Final output sent to browser
DEBUG - 2021-11-19 07:46:37 --> Total execution time: 0.0811
INFO - 2021-11-19 07:46:37 --> Config Class Initialized
INFO - 2021-11-19 07:46:37 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:46:37 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:46:37 --> Utf8 Class Initialized
INFO - 2021-11-19 07:46:37 --> URI Class Initialized
INFO - 2021-11-19 07:46:37 --> Router Class Initialized
INFO - 2021-11-19 07:46:37 --> Output Class Initialized
INFO - 2021-11-19 07:46:37 --> Security Class Initialized
DEBUG - 2021-11-19 07:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:46:37 --> Input Class Initialized
INFO - 2021-11-19 07:46:37 --> Language Class Initialized
INFO - 2021-11-19 07:46:37 --> Language Class Initialized
INFO - 2021-11-19 07:46:37 --> Config Class Initialized
INFO - 2021-11-19 07:46:37 --> Loader Class Initialized
INFO - 2021-11-19 07:46:37 --> Helper loaded: url_helper
INFO - 2021-11-19 07:46:37 --> Helper loaded: file_helper
INFO - 2021-11-19 07:46:37 --> Helper loaded: form_helper
INFO - 2021-11-19 07:46:37 --> Helper loaded: my_helper
INFO - 2021-11-19 07:46:37 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:46:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:46:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:46:37 --> Controller Class Initialized
INFO - 2021-11-19 07:46:39 --> Config Class Initialized
INFO - 2021-11-19 07:46:39 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:46:39 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:46:39 --> Utf8 Class Initialized
INFO - 2021-11-19 07:46:39 --> URI Class Initialized
INFO - 2021-11-19 07:46:39 --> Router Class Initialized
INFO - 2021-11-19 07:46:39 --> Output Class Initialized
INFO - 2021-11-19 07:46:39 --> Security Class Initialized
DEBUG - 2021-11-19 07:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:46:39 --> Input Class Initialized
INFO - 2021-11-19 07:46:39 --> Language Class Initialized
INFO - 2021-11-19 07:46:39 --> Language Class Initialized
INFO - 2021-11-19 07:46:39 --> Config Class Initialized
INFO - 2021-11-19 07:46:39 --> Loader Class Initialized
INFO - 2021-11-19 07:46:39 --> Helper loaded: url_helper
INFO - 2021-11-19 07:46:39 --> Helper loaded: file_helper
INFO - 2021-11-19 07:46:39 --> Helper loaded: form_helper
INFO - 2021-11-19 07:46:39 --> Helper loaded: my_helper
INFO - 2021-11-19 07:46:39 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:46:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:46:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:46:39 --> Controller Class Initialized
INFO - 2021-11-19 07:46:39 --> Helper loaded: cookie_helper
INFO - 2021-11-19 07:46:39 --> Config Class Initialized
INFO - 2021-11-19 07:46:39 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:46:39 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:46:39 --> Utf8 Class Initialized
INFO - 2021-11-19 07:46:39 --> URI Class Initialized
INFO - 2021-11-19 07:46:39 --> Router Class Initialized
INFO - 2021-11-19 07:46:39 --> Output Class Initialized
INFO - 2021-11-19 07:46:39 --> Security Class Initialized
DEBUG - 2021-11-19 07:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:46:39 --> Input Class Initialized
INFO - 2021-11-19 07:46:39 --> Language Class Initialized
INFO - 2021-11-19 07:46:39 --> Language Class Initialized
INFO - 2021-11-19 07:46:39 --> Config Class Initialized
INFO - 2021-11-19 07:46:39 --> Loader Class Initialized
INFO - 2021-11-19 07:46:39 --> Helper loaded: url_helper
INFO - 2021-11-19 07:46:39 --> Helper loaded: file_helper
INFO - 2021-11-19 07:46:39 --> Helper loaded: form_helper
INFO - 2021-11-19 07:46:39 --> Helper loaded: my_helper
INFO - 2021-11-19 07:46:39 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:46:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:46:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:46:39 --> Controller Class Initialized
DEBUG - 2021-11-19 07:46:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-11-19 07:46:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 07:46:39 --> Final output sent to browser
DEBUG - 2021-11-19 07:46:39 --> Total execution time: 0.0872
INFO - 2021-11-19 07:46:44 --> Config Class Initialized
INFO - 2021-11-19 07:46:44 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:46:44 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:46:44 --> Utf8 Class Initialized
INFO - 2021-11-19 07:46:44 --> URI Class Initialized
INFO - 2021-11-19 07:46:44 --> Router Class Initialized
INFO - 2021-11-19 07:46:44 --> Output Class Initialized
INFO - 2021-11-19 07:46:44 --> Security Class Initialized
DEBUG - 2021-11-19 07:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:46:44 --> Input Class Initialized
INFO - 2021-11-19 07:46:44 --> Language Class Initialized
INFO - 2021-11-19 07:46:44 --> Language Class Initialized
INFO - 2021-11-19 07:46:44 --> Config Class Initialized
INFO - 2021-11-19 07:46:44 --> Loader Class Initialized
INFO - 2021-11-19 07:46:44 --> Helper loaded: url_helper
INFO - 2021-11-19 07:46:44 --> Helper loaded: file_helper
INFO - 2021-11-19 07:46:44 --> Helper loaded: form_helper
INFO - 2021-11-19 07:46:44 --> Helper loaded: my_helper
INFO - 2021-11-19 07:46:44 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:46:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:46:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:46:44 --> Controller Class Initialized
INFO - 2021-11-19 07:46:44 --> Helper loaded: cookie_helper
INFO - 2021-11-19 07:46:44 --> Final output sent to browser
DEBUG - 2021-11-19 07:46:44 --> Total execution time: 0.1078
INFO - 2021-11-19 07:46:44 --> Config Class Initialized
INFO - 2021-11-19 07:46:44 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:46:44 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:46:44 --> Utf8 Class Initialized
INFO - 2021-11-19 07:46:44 --> URI Class Initialized
INFO - 2021-11-19 07:46:44 --> Router Class Initialized
INFO - 2021-11-19 07:46:44 --> Output Class Initialized
INFO - 2021-11-19 07:46:44 --> Security Class Initialized
DEBUG - 2021-11-19 07:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:46:44 --> Input Class Initialized
INFO - 2021-11-19 07:46:44 --> Language Class Initialized
INFO - 2021-11-19 07:46:44 --> Language Class Initialized
INFO - 2021-11-19 07:46:44 --> Config Class Initialized
INFO - 2021-11-19 07:46:44 --> Loader Class Initialized
INFO - 2021-11-19 07:46:44 --> Helper loaded: url_helper
INFO - 2021-11-19 07:46:44 --> Helper loaded: file_helper
INFO - 2021-11-19 07:46:44 --> Helper loaded: form_helper
INFO - 2021-11-19 07:46:44 --> Helper loaded: my_helper
INFO - 2021-11-19 07:46:44 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:46:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:46:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:46:44 --> Controller Class Initialized
DEBUG - 2021-11-19 07:46:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-11-19 07:46:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 07:46:45 --> Final output sent to browser
DEBUG - 2021-11-19 07:46:45 --> Total execution time: 1.0495
INFO - 2021-11-19 07:46:49 --> Config Class Initialized
INFO - 2021-11-19 07:46:49 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:46:49 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:46:49 --> Utf8 Class Initialized
INFO - 2021-11-19 07:46:49 --> URI Class Initialized
INFO - 2021-11-19 07:46:49 --> Router Class Initialized
INFO - 2021-11-19 07:46:49 --> Output Class Initialized
INFO - 2021-11-19 07:46:49 --> Security Class Initialized
DEBUG - 2021-11-19 07:46:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:46:49 --> Input Class Initialized
INFO - 2021-11-19 07:46:49 --> Language Class Initialized
INFO - 2021-11-19 07:46:49 --> Language Class Initialized
INFO - 2021-11-19 07:46:49 --> Config Class Initialized
INFO - 2021-11-19 07:46:49 --> Loader Class Initialized
INFO - 2021-11-19 07:46:49 --> Helper loaded: url_helper
INFO - 2021-11-19 07:46:49 --> Helper loaded: file_helper
INFO - 2021-11-19 07:46:49 --> Helper loaded: form_helper
INFO - 2021-11-19 07:46:49 --> Helper loaded: my_helper
INFO - 2021-11-19 07:46:49 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:46:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:46:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:46:49 --> Controller Class Initialized
DEBUG - 2021-11-19 07:46:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-11-19 07:46:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 07:46:49 --> Final output sent to browser
DEBUG - 2021-11-19 07:46:49 --> Total execution time: 0.0841
INFO - 2021-11-19 07:46:51 --> Config Class Initialized
INFO - 2021-11-19 07:46:51 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:46:51 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:46:51 --> Utf8 Class Initialized
INFO - 2021-11-19 07:46:51 --> URI Class Initialized
INFO - 2021-11-19 07:46:51 --> Router Class Initialized
INFO - 2021-11-19 07:46:51 --> Output Class Initialized
INFO - 2021-11-19 07:46:51 --> Security Class Initialized
DEBUG - 2021-11-19 07:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:46:51 --> Input Class Initialized
INFO - 2021-11-19 07:46:51 --> Language Class Initialized
INFO - 2021-11-19 07:46:51 --> Language Class Initialized
INFO - 2021-11-19 07:46:51 --> Config Class Initialized
INFO - 2021-11-19 07:46:51 --> Loader Class Initialized
INFO - 2021-11-19 07:46:51 --> Helper loaded: url_helper
INFO - 2021-11-19 07:46:51 --> Helper loaded: file_helper
INFO - 2021-11-19 07:46:51 --> Helper loaded: form_helper
INFO - 2021-11-19 07:46:51 --> Helper loaded: my_helper
INFO - 2021-11-19 07:46:51 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:46:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:46:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:46:51 --> Controller Class Initialized
DEBUG - 2021-11-19 07:46:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-19 07:46:51 --> Final output sent to browser
DEBUG - 2021-11-19 07:46:51 --> Total execution time: 0.2174
INFO - 2021-11-19 07:47:08 --> Config Class Initialized
INFO - 2021-11-19 07:47:08 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:47:08 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:47:08 --> Utf8 Class Initialized
INFO - 2021-11-19 07:47:08 --> URI Class Initialized
INFO - 2021-11-19 07:47:08 --> Router Class Initialized
INFO - 2021-11-19 07:47:08 --> Output Class Initialized
INFO - 2021-11-19 07:47:08 --> Security Class Initialized
DEBUG - 2021-11-19 07:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:47:08 --> Input Class Initialized
INFO - 2021-11-19 07:47:08 --> Language Class Initialized
INFO - 2021-11-19 07:47:08 --> Language Class Initialized
INFO - 2021-11-19 07:47:08 --> Config Class Initialized
INFO - 2021-11-19 07:47:08 --> Loader Class Initialized
INFO - 2021-11-19 07:47:08 --> Helper loaded: url_helper
INFO - 2021-11-19 07:47:08 --> Helper loaded: file_helper
INFO - 2021-11-19 07:47:08 --> Helper loaded: form_helper
INFO - 2021-11-19 07:47:08 --> Helper loaded: my_helper
INFO - 2021-11-19 07:47:08 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:47:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:47:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:47:08 --> Controller Class Initialized
INFO - 2021-11-19 07:47:08 --> Helper loaded: cookie_helper
INFO - 2021-11-19 07:47:08 --> Config Class Initialized
INFO - 2021-11-19 07:47:08 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:47:08 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:47:08 --> Utf8 Class Initialized
INFO - 2021-11-19 07:47:08 --> URI Class Initialized
INFO - 2021-11-19 07:47:08 --> Router Class Initialized
INFO - 2021-11-19 07:47:08 --> Output Class Initialized
INFO - 2021-11-19 07:47:08 --> Security Class Initialized
DEBUG - 2021-11-19 07:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:47:08 --> Input Class Initialized
INFO - 2021-11-19 07:47:08 --> Language Class Initialized
INFO - 2021-11-19 07:47:08 --> Language Class Initialized
INFO - 2021-11-19 07:47:08 --> Config Class Initialized
INFO - 2021-11-19 07:47:08 --> Loader Class Initialized
INFO - 2021-11-19 07:47:08 --> Helper loaded: url_helper
INFO - 2021-11-19 07:47:08 --> Helper loaded: file_helper
INFO - 2021-11-19 07:47:08 --> Helper loaded: form_helper
INFO - 2021-11-19 07:47:08 --> Helper loaded: my_helper
INFO - 2021-11-19 07:47:08 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:47:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:47:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:47:08 --> Controller Class Initialized
DEBUG - 2021-11-19 07:47:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-11-19 07:47:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 07:47:08 --> Final output sent to browser
DEBUG - 2021-11-19 07:47:08 --> Total execution time: 0.0527
INFO - 2021-11-19 07:47:12 --> Config Class Initialized
INFO - 2021-11-19 07:47:12 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:47:12 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:47:12 --> Utf8 Class Initialized
INFO - 2021-11-19 07:47:12 --> URI Class Initialized
INFO - 2021-11-19 07:47:12 --> Router Class Initialized
INFO - 2021-11-19 07:47:12 --> Output Class Initialized
INFO - 2021-11-19 07:47:12 --> Security Class Initialized
DEBUG - 2021-11-19 07:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:47:12 --> Input Class Initialized
INFO - 2021-11-19 07:47:12 --> Language Class Initialized
INFO - 2021-11-19 07:47:13 --> Language Class Initialized
INFO - 2021-11-19 07:47:13 --> Config Class Initialized
INFO - 2021-11-19 07:47:13 --> Loader Class Initialized
INFO - 2021-11-19 07:47:13 --> Helper loaded: url_helper
INFO - 2021-11-19 07:47:13 --> Helper loaded: file_helper
INFO - 2021-11-19 07:47:13 --> Helper loaded: form_helper
INFO - 2021-11-19 07:47:13 --> Helper loaded: my_helper
INFO - 2021-11-19 07:47:13 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:47:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:47:13 --> Controller Class Initialized
INFO - 2021-11-19 07:47:13 --> Helper loaded: cookie_helper
INFO - 2021-11-19 07:47:13 --> Final output sent to browser
DEBUG - 2021-11-19 07:47:13 --> Total execution time: 0.0764
INFO - 2021-11-19 07:47:13 --> Config Class Initialized
INFO - 2021-11-19 07:47:13 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:47:13 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:47:13 --> Utf8 Class Initialized
INFO - 2021-11-19 07:47:13 --> URI Class Initialized
INFO - 2021-11-19 07:47:13 --> Router Class Initialized
INFO - 2021-11-19 07:47:13 --> Output Class Initialized
INFO - 2021-11-19 07:47:13 --> Security Class Initialized
DEBUG - 2021-11-19 07:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:47:13 --> Input Class Initialized
INFO - 2021-11-19 07:47:13 --> Language Class Initialized
INFO - 2021-11-19 07:47:13 --> Language Class Initialized
INFO - 2021-11-19 07:47:13 --> Config Class Initialized
INFO - 2021-11-19 07:47:13 --> Loader Class Initialized
INFO - 2021-11-19 07:47:13 --> Helper loaded: url_helper
INFO - 2021-11-19 07:47:13 --> Helper loaded: file_helper
INFO - 2021-11-19 07:47:13 --> Helper loaded: form_helper
INFO - 2021-11-19 07:47:13 --> Helper loaded: my_helper
INFO - 2021-11-19 07:47:13 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:47:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:47:13 --> Controller Class Initialized
DEBUG - 2021-11-19 07:47:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-11-19 07:47:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 07:47:14 --> Final output sent to browser
DEBUG - 2021-11-19 07:47:14 --> Total execution time: 1.1108
INFO - 2021-11-19 07:47:18 --> Config Class Initialized
INFO - 2021-11-19 07:47:18 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:47:18 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:47:18 --> Utf8 Class Initialized
INFO - 2021-11-19 07:47:18 --> URI Class Initialized
INFO - 2021-11-19 07:47:18 --> Router Class Initialized
INFO - 2021-11-19 07:47:18 --> Output Class Initialized
INFO - 2021-11-19 07:47:18 --> Security Class Initialized
DEBUG - 2021-11-19 07:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:47:18 --> Input Class Initialized
INFO - 2021-11-19 07:47:18 --> Language Class Initialized
INFO - 2021-11-19 07:47:18 --> Language Class Initialized
INFO - 2021-11-19 07:47:18 --> Config Class Initialized
INFO - 2021-11-19 07:47:18 --> Loader Class Initialized
INFO - 2021-11-19 07:47:18 --> Helper loaded: url_helper
INFO - 2021-11-19 07:47:18 --> Helper loaded: file_helper
INFO - 2021-11-19 07:47:18 --> Helper loaded: form_helper
INFO - 2021-11-19 07:47:18 --> Helper loaded: my_helper
INFO - 2021-11-19 07:47:18 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:47:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:47:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:47:18 --> Controller Class Initialized
DEBUG - 2021-11-19 07:47:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-11-19 07:47:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 07:47:18 --> Final output sent to browser
DEBUG - 2021-11-19 07:47:18 --> Total execution time: 0.0980
INFO - 2021-11-19 07:47:20 --> Config Class Initialized
INFO - 2021-11-19 07:47:20 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:47:20 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:47:20 --> Utf8 Class Initialized
INFO - 2021-11-19 07:47:20 --> URI Class Initialized
INFO - 2021-11-19 07:47:20 --> Router Class Initialized
INFO - 2021-11-19 07:47:20 --> Output Class Initialized
INFO - 2021-11-19 07:47:20 --> Security Class Initialized
DEBUG - 2021-11-19 07:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:47:20 --> Input Class Initialized
INFO - 2021-11-19 07:47:20 --> Language Class Initialized
INFO - 2021-11-19 07:47:20 --> Language Class Initialized
INFO - 2021-11-19 07:47:20 --> Config Class Initialized
INFO - 2021-11-19 07:47:20 --> Loader Class Initialized
INFO - 2021-11-19 07:47:20 --> Helper loaded: url_helper
INFO - 2021-11-19 07:47:20 --> Helper loaded: file_helper
INFO - 2021-11-19 07:47:20 --> Helper loaded: form_helper
INFO - 2021-11-19 07:47:20 --> Helper loaded: my_helper
INFO - 2021-11-19 07:47:20 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:47:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:47:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:47:20 --> Controller Class Initialized
DEBUG - 2021-11-19 07:47:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-11-19 07:47:21 --> Final output sent to browser
DEBUG - 2021-11-19 07:47:21 --> Total execution time: 0.2329
INFO - 2021-11-19 07:47:49 --> Config Class Initialized
INFO - 2021-11-19 07:47:49 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:47:49 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:47:49 --> Utf8 Class Initialized
INFO - 2021-11-19 07:47:49 --> URI Class Initialized
INFO - 2021-11-19 07:47:49 --> Router Class Initialized
INFO - 2021-11-19 07:47:49 --> Output Class Initialized
INFO - 2021-11-19 07:47:49 --> Security Class Initialized
DEBUG - 2021-11-19 07:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:47:49 --> Input Class Initialized
INFO - 2021-11-19 07:47:49 --> Language Class Initialized
INFO - 2021-11-19 07:47:49 --> Language Class Initialized
INFO - 2021-11-19 07:47:49 --> Config Class Initialized
INFO - 2021-11-19 07:47:49 --> Loader Class Initialized
INFO - 2021-11-19 07:47:49 --> Helper loaded: url_helper
INFO - 2021-11-19 07:47:49 --> Helper loaded: file_helper
INFO - 2021-11-19 07:47:49 --> Helper loaded: form_helper
INFO - 2021-11-19 07:47:49 --> Helper loaded: my_helper
INFO - 2021-11-19 07:47:49 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:47:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:47:49 --> Controller Class Initialized
INFO - 2021-11-19 07:47:50 --> Helper loaded: cookie_helper
INFO - 2021-11-19 07:47:50 --> Config Class Initialized
INFO - 2021-11-19 07:47:50 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:47:50 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:47:50 --> Utf8 Class Initialized
INFO - 2021-11-19 07:47:50 --> URI Class Initialized
INFO - 2021-11-19 07:47:50 --> Router Class Initialized
INFO - 2021-11-19 07:47:50 --> Output Class Initialized
INFO - 2021-11-19 07:47:50 --> Security Class Initialized
DEBUG - 2021-11-19 07:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:47:50 --> Input Class Initialized
INFO - 2021-11-19 07:47:50 --> Language Class Initialized
INFO - 2021-11-19 07:47:50 --> Language Class Initialized
INFO - 2021-11-19 07:47:50 --> Config Class Initialized
INFO - 2021-11-19 07:47:50 --> Loader Class Initialized
INFO - 2021-11-19 07:47:50 --> Helper loaded: url_helper
INFO - 2021-11-19 07:47:50 --> Helper loaded: file_helper
INFO - 2021-11-19 07:47:50 --> Helper loaded: form_helper
INFO - 2021-11-19 07:47:50 --> Helper loaded: my_helper
INFO - 2021-11-19 07:47:50 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:47:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:47:50 --> Controller Class Initialized
DEBUG - 2021-11-19 07:47:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-11-19 07:47:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 07:47:50 --> Final output sent to browser
DEBUG - 2021-11-19 07:47:50 --> Total execution time: 0.0731
INFO - 2021-11-19 07:47:53 --> Config Class Initialized
INFO - 2021-11-19 07:47:53 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:47:53 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:47:53 --> Utf8 Class Initialized
INFO - 2021-11-19 07:47:53 --> URI Class Initialized
INFO - 2021-11-19 07:47:53 --> Router Class Initialized
INFO - 2021-11-19 07:47:53 --> Output Class Initialized
INFO - 2021-11-19 07:47:53 --> Security Class Initialized
DEBUG - 2021-11-19 07:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:47:53 --> Input Class Initialized
INFO - 2021-11-19 07:47:53 --> Language Class Initialized
INFO - 2021-11-19 07:47:53 --> Language Class Initialized
INFO - 2021-11-19 07:47:53 --> Config Class Initialized
INFO - 2021-11-19 07:47:53 --> Loader Class Initialized
INFO - 2021-11-19 07:47:53 --> Helper loaded: url_helper
INFO - 2021-11-19 07:47:53 --> Helper loaded: file_helper
INFO - 2021-11-19 07:47:53 --> Helper loaded: form_helper
INFO - 2021-11-19 07:47:53 --> Helper loaded: my_helper
INFO - 2021-11-19 07:47:53 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:47:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:47:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:47:53 --> Controller Class Initialized
INFO - 2021-11-19 07:47:53 --> Helper loaded: cookie_helper
INFO - 2021-11-19 07:47:53 --> Final output sent to browser
DEBUG - 2021-11-19 07:47:53 --> Total execution time: 0.0863
INFO - 2021-11-19 07:47:53 --> Config Class Initialized
INFO - 2021-11-19 07:47:53 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:47:53 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:47:53 --> Utf8 Class Initialized
INFO - 2021-11-19 07:47:53 --> URI Class Initialized
INFO - 2021-11-19 07:47:53 --> Router Class Initialized
INFO - 2021-11-19 07:47:53 --> Output Class Initialized
INFO - 2021-11-19 07:47:53 --> Security Class Initialized
DEBUG - 2021-11-19 07:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:47:53 --> Input Class Initialized
INFO - 2021-11-19 07:47:53 --> Language Class Initialized
INFO - 2021-11-19 07:47:53 --> Language Class Initialized
INFO - 2021-11-19 07:47:53 --> Config Class Initialized
INFO - 2021-11-19 07:47:53 --> Loader Class Initialized
INFO - 2021-11-19 07:47:53 --> Helper loaded: url_helper
INFO - 2021-11-19 07:47:53 --> Helper loaded: file_helper
INFO - 2021-11-19 07:47:53 --> Helper loaded: form_helper
INFO - 2021-11-19 07:47:53 --> Helper loaded: my_helper
INFO - 2021-11-19 07:47:53 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:47:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:47:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:47:53 --> Controller Class Initialized
DEBUG - 2021-11-19 07:47:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-11-19 07:47:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 07:47:54 --> Final output sent to browser
DEBUG - 2021-11-19 07:47:54 --> Total execution time: 1.0455
INFO - 2021-11-19 07:47:55 --> Config Class Initialized
INFO - 2021-11-19 07:47:55 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:47:55 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:47:55 --> Utf8 Class Initialized
INFO - 2021-11-19 07:47:55 --> URI Class Initialized
INFO - 2021-11-19 07:47:55 --> Router Class Initialized
INFO - 2021-11-19 07:47:55 --> Output Class Initialized
INFO - 2021-11-19 07:47:55 --> Security Class Initialized
DEBUG - 2021-11-19 07:47:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:47:55 --> Input Class Initialized
INFO - 2021-11-19 07:47:55 --> Language Class Initialized
INFO - 2021-11-19 07:47:55 --> Language Class Initialized
INFO - 2021-11-19 07:47:55 --> Config Class Initialized
INFO - 2021-11-19 07:47:55 --> Loader Class Initialized
INFO - 2021-11-19 07:47:55 --> Helper loaded: url_helper
INFO - 2021-11-19 07:47:55 --> Helper loaded: file_helper
INFO - 2021-11-19 07:47:55 --> Helper loaded: form_helper
INFO - 2021-11-19 07:47:55 --> Helper loaded: my_helper
INFO - 2021-11-19 07:47:55 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:47:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:47:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:47:55 --> Controller Class Initialized
DEBUG - 2021-11-19 07:47:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-11-19 07:47:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 07:47:55 --> Final output sent to browser
DEBUG - 2021-11-19 07:47:55 --> Total execution time: 0.0996
INFO - 2021-11-19 07:47:56 --> Config Class Initialized
INFO - 2021-11-19 07:47:56 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:47:56 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:47:56 --> Utf8 Class Initialized
INFO - 2021-11-19 07:47:56 --> URI Class Initialized
INFO - 2021-11-19 07:47:56 --> Router Class Initialized
INFO - 2021-11-19 07:47:56 --> Output Class Initialized
INFO - 2021-11-19 07:47:56 --> Security Class Initialized
DEBUG - 2021-11-19 07:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:47:56 --> Input Class Initialized
INFO - 2021-11-19 07:47:56 --> Language Class Initialized
INFO - 2021-11-19 07:47:56 --> Language Class Initialized
INFO - 2021-11-19 07:47:56 --> Config Class Initialized
INFO - 2021-11-19 07:47:56 --> Loader Class Initialized
INFO - 2021-11-19 07:47:56 --> Helper loaded: url_helper
INFO - 2021-11-19 07:47:56 --> Helper loaded: file_helper
INFO - 2021-11-19 07:47:56 --> Helper loaded: form_helper
INFO - 2021-11-19 07:47:56 --> Helper loaded: my_helper
INFO - 2021-11-19 07:47:56 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:47:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:47:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:47:56 --> Controller Class Initialized
DEBUG - 2021-11-19 07:47:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-19 07:47:57 --> Final output sent to browser
DEBUG - 2021-11-19 07:47:57 --> Total execution time: 0.2155
INFO - 2021-11-19 07:48:54 --> Config Class Initialized
INFO - 2021-11-19 07:48:54 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:48:54 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:48:54 --> Utf8 Class Initialized
INFO - 2021-11-19 07:48:54 --> URI Class Initialized
INFO - 2021-11-19 07:48:54 --> Router Class Initialized
INFO - 2021-11-19 07:48:54 --> Output Class Initialized
INFO - 2021-11-19 07:48:54 --> Security Class Initialized
DEBUG - 2021-11-19 07:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:48:54 --> Input Class Initialized
INFO - 2021-11-19 07:48:54 --> Language Class Initialized
INFO - 2021-11-19 07:48:54 --> Language Class Initialized
INFO - 2021-11-19 07:48:54 --> Config Class Initialized
INFO - 2021-11-19 07:48:54 --> Loader Class Initialized
INFO - 2021-11-19 07:48:54 --> Helper loaded: url_helper
INFO - 2021-11-19 07:48:54 --> Helper loaded: file_helper
INFO - 2021-11-19 07:48:54 --> Helper loaded: form_helper
INFO - 2021-11-19 07:48:54 --> Helper loaded: my_helper
INFO - 2021-11-19 07:48:54 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:48:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:48:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:48:54 --> Controller Class Initialized
DEBUG - 2021-11-19 07:48:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-11-19 07:48:54 --> Final output sent to browser
DEBUG - 2021-11-19 07:48:54 --> Total execution time: 0.2083
INFO - 2021-11-19 07:49:09 --> Config Class Initialized
INFO - 2021-11-19 07:49:09 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:49:09 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:49:09 --> Utf8 Class Initialized
INFO - 2021-11-19 07:49:09 --> URI Class Initialized
INFO - 2021-11-19 07:49:09 --> Router Class Initialized
INFO - 2021-11-19 07:49:09 --> Output Class Initialized
INFO - 2021-11-19 07:49:09 --> Security Class Initialized
DEBUG - 2021-11-19 07:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:49:09 --> Input Class Initialized
INFO - 2021-11-19 07:49:09 --> Language Class Initialized
INFO - 2021-11-19 07:49:09 --> Language Class Initialized
INFO - 2021-11-19 07:49:09 --> Config Class Initialized
INFO - 2021-11-19 07:49:09 --> Loader Class Initialized
INFO - 2021-11-19 07:49:09 --> Helper loaded: url_helper
INFO - 2021-11-19 07:49:09 --> Helper loaded: file_helper
INFO - 2021-11-19 07:49:09 --> Helper loaded: form_helper
INFO - 2021-11-19 07:49:09 --> Helper loaded: my_helper
INFO - 2021-11-19 07:49:09 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:49:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:49:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:49:09 --> Controller Class Initialized
DEBUG - 2021-11-19 07:49:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-11-19 07:49:09 --> Final output sent to browser
DEBUG - 2021-11-19 07:49:09 --> Total execution time: 0.1469
INFO - 2021-11-19 07:49:19 --> Config Class Initialized
INFO - 2021-11-19 07:49:19 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:49:19 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:49:19 --> Utf8 Class Initialized
INFO - 2021-11-19 07:49:19 --> URI Class Initialized
INFO - 2021-11-19 07:49:19 --> Router Class Initialized
INFO - 2021-11-19 07:49:19 --> Output Class Initialized
INFO - 2021-11-19 07:49:19 --> Security Class Initialized
DEBUG - 2021-11-19 07:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:49:19 --> Input Class Initialized
INFO - 2021-11-19 07:49:19 --> Language Class Initialized
INFO - 2021-11-19 07:49:19 --> Language Class Initialized
INFO - 2021-11-19 07:49:19 --> Config Class Initialized
INFO - 2021-11-19 07:49:19 --> Loader Class Initialized
INFO - 2021-11-19 07:49:19 --> Helper loaded: url_helper
INFO - 2021-11-19 07:49:19 --> Helper loaded: file_helper
INFO - 2021-11-19 07:49:19 --> Helper loaded: form_helper
INFO - 2021-11-19 07:49:19 --> Helper loaded: my_helper
INFO - 2021-11-19 07:49:19 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:49:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:49:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:49:19 --> Controller Class Initialized
DEBUG - 2021-11-19 07:49:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-11-19 07:49:19 --> Final output sent to browser
DEBUG - 2021-11-19 07:49:19 --> Total execution time: 0.1553
INFO - 2021-11-19 07:50:09 --> Config Class Initialized
INFO - 2021-11-19 07:50:09 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:50:09 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:50:09 --> Utf8 Class Initialized
INFO - 2021-11-19 07:50:09 --> URI Class Initialized
INFO - 2021-11-19 07:50:09 --> Router Class Initialized
INFO - 2021-11-19 07:50:09 --> Output Class Initialized
INFO - 2021-11-19 07:50:09 --> Security Class Initialized
DEBUG - 2021-11-19 07:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:50:09 --> Input Class Initialized
INFO - 2021-11-19 07:50:09 --> Language Class Initialized
INFO - 2021-11-19 07:50:09 --> Language Class Initialized
INFO - 2021-11-19 07:50:09 --> Config Class Initialized
INFO - 2021-11-19 07:50:09 --> Loader Class Initialized
INFO - 2021-11-19 07:50:09 --> Helper loaded: url_helper
INFO - 2021-11-19 07:50:09 --> Helper loaded: file_helper
INFO - 2021-11-19 07:50:09 --> Helper loaded: form_helper
INFO - 2021-11-19 07:50:09 --> Helper loaded: my_helper
INFO - 2021-11-19 07:50:09 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:50:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:50:09 --> Controller Class Initialized
INFO - 2021-11-19 07:50:09 --> Helper loaded: cookie_helper
INFO - 2021-11-19 07:50:09 --> Config Class Initialized
INFO - 2021-11-19 07:50:09 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:50:09 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:50:09 --> Utf8 Class Initialized
INFO - 2021-11-19 07:50:09 --> URI Class Initialized
INFO - 2021-11-19 07:50:09 --> Router Class Initialized
INFO - 2021-11-19 07:50:09 --> Output Class Initialized
INFO - 2021-11-19 07:50:09 --> Security Class Initialized
DEBUG - 2021-11-19 07:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:50:09 --> Input Class Initialized
INFO - 2021-11-19 07:50:09 --> Language Class Initialized
INFO - 2021-11-19 07:50:09 --> Language Class Initialized
INFO - 2021-11-19 07:50:09 --> Config Class Initialized
INFO - 2021-11-19 07:50:09 --> Loader Class Initialized
INFO - 2021-11-19 07:50:09 --> Helper loaded: url_helper
INFO - 2021-11-19 07:50:09 --> Helper loaded: file_helper
INFO - 2021-11-19 07:50:09 --> Helper loaded: form_helper
INFO - 2021-11-19 07:50:09 --> Helper loaded: my_helper
INFO - 2021-11-19 07:50:09 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:50:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:50:09 --> Controller Class Initialized
DEBUG - 2021-11-19 07:50:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-11-19 07:50:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 07:50:09 --> Final output sent to browser
DEBUG - 2021-11-19 07:50:09 --> Total execution time: 0.0659
INFO - 2021-11-19 07:50:37 --> Config Class Initialized
INFO - 2021-11-19 07:50:37 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:50:37 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:50:37 --> Utf8 Class Initialized
INFO - 2021-11-19 07:50:37 --> URI Class Initialized
INFO - 2021-11-19 07:50:37 --> Router Class Initialized
INFO - 2021-11-19 07:50:37 --> Output Class Initialized
INFO - 2021-11-19 07:50:37 --> Security Class Initialized
DEBUG - 2021-11-19 07:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:50:37 --> Input Class Initialized
INFO - 2021-11-19 07:50:37 --> Language Class Initialized
INFO - 2021-11-19 07:50:37 --> Language Class Initialized
INFO - 2021-11-19 07:50:37 --> Config Class Initialized
INFO - 2021-11-19 07:50:37 --> Loader Class Initialized
INFO - 2021-11-19 07:50:37 --> Helper loaded: url_helper
INFO - 2021-11-19 07:50:37 --> Helper loaded: file_helper
INFO - 2021-11-19 07:50:37 --> Helper loaded: form_helper
INFO - 2021-11-19 07:50:37 --> Helper loaded: my_helper
INFO - 2021-11-19 07:50:37 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:50:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:50:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:50:37 --> Controller Class Initialized
INFO - 2021-11-19 07:50:37 --> Helper loaded: cookie_helper
INFO - 2021-11-19 07:50:37 --> Final output sent to browser
DEBUG - 2021-11-19 07:50:37 --> Total execution time: 0.0943
INFO - 2021-11-19 07:50:37 --> Config Class Initialized
INFO - 2021-11-19 07:50:37 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:50:37 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:50:37 --> Utf8 Class Initialized
INFO - 2021-11-19 07:50:37 --> URI Class Initialized
INFO - 2021-11-19 07:50:37 --> Router Class Initialized
INFO - 2021-11-19 07:50:37 --> Output Class Initialized
INFO - 2021-11-19 07:50:37 --> Security Class Initialized
DEBUG - 2021-11-19 07:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:50:37 --> Input Class Initialized
INFO - 2021-11-19 07:50:37 --> Language Class Initialized
INFO - 2021-11-19 07:50:37 --> Language Class Initialized
INFO - 2021-11-19 07:50:37 --> Config Class Initialized
INFO - 2021-11-19 07:50:37 --> Loader Class Initialized
INFO - 2021-11-19 07:50:37 --> Helper loaded: url_helper
INFO - 2021-11-19 07:50:37 --> Helper loaded: file_helper
INFO - 2021-11-19 07:50:37 --> Helper loaded: form_helper
INFO - 2021-11-19 07:50:37 --> Helper loaded: my_helper
INFO - 2021-11-19 07:50:37 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:50:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:50:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:50:37 --> Controller Class Initialized
DEBUG - 2021-11-19 07:50:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-11-19 07:50:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 07:50:39 --> Final output sent to browser
DEBUG - 2021-11-19 07:50:39 --> Total execution time: 1.1576
INFO - 2021-11-19 07:50:43 --> Config Class Initialized
INFO - 2021-11-19 07:50:43 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:50:43 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:50:43 --> Utf8 Class Initialized
INFO - 2021-11-19 07:50:43 --> URI Class Initialized
INFO - 2021-11-19 07:50:43 --> Router Class Initialized
INFO - 2021-11-19 07:50:43 --> Output Class Initialized
INFO - 2021-11-19 07:50:43 --> Security Class Initialized
DEBUG - 2021-11-19 07:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:50:43 --> Input Class Initialized
INFO - 2021-11-19 07:50:43 --> Language Class Initialized
INFO - 2021-11-19 07:50:43 --> Language Class Initialized
INFO - 2021-11-19 07:50:43 --> Config Class Initialized
INFO - 2021-11-19 07:50:43 --> Loader Class Initialized
INFO - 2021-11-19 07:50:43 --> Helper loaded: url_helper
INFO - 2021-11-19 07:50:43 --> Helper loaded: file_helper
INFO - 2021-11-19 07:50:43 --> Helper loaded: form_helper
INFO - 2021-11-19 07:50:43 --> Helper loaded: my_helper
INFO - 2021-11-19 07:50:43 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:50:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:50:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:50:43 --> Controller Class Initialized
DEBUG - 2021-11-19 07:50:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-11-19 07:50:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 07:50:43 --> Final output sent to browser
DEBUG - 2021-11-19 07:50:43 --> Total execution time: 0.0969
INFO - 2021-11-19 07:50:46 --> Config Class Initialized
INFO - 2021-11-19 07:50:46 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:50:46 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:50:46 --> Utf8 Class Initialized
INFO - 2021-11-19 07:50:46 --> URI Class Initialized
INFO - 2021-11-19 07:50:46 --> Router Class Initialized
INFO - 2021-11-19 07:50:46 --> Output Class Initialized
INFO - 2021-11-19 07:50:46 --> Security Class Initialized
DEBUG - 2021-11-19 07:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:50:46 --> Input Class Initialized
INFO - 2021-11-19 07:50:46 --> Language Class Initialized
INFO - 2021-11-19 07:50:46 --> Language Class Initialized
INFO - 2021-11-19 07:50:46 --> Config Class Initialized
INFO - 2021-11-19 07:50:46 --> Loader Class Initialized
INFO - 2021-11-19 07:50:46 --> Helper loaded: url_helper
INFO - 2021-11-19 07:50:46 --> Helper loaded: file_helper
INFO - 2021-11-19 07:50:46 --> Helper loaded: form_helper
INFO - 2021-11-19 07:50:46 --> Helper loaded: my_helper
INFO - 2021-11-19 07:50:46 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:50:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:50:46 --> Controller Class Initialized
DEBUG - 2021-11-19 07:50:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-11-19 07:50:46 --> Final output sent to browser
DEBUG - 2021-11-19 07:50:46 --> Total execution time: 0.2336
INFO - 2021-11-19 07:51:51 --> Config Class Initialized
INFO - 2021-11-19 07:51:51 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:51:51 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:51:51 --> Utf8 Class Initialized
INFO - 2021-11-19 07:51:51 --> URI Class Initialized
INFO - 2021-11-19 07:51:51 --> Router Class Initialized
INFO - 2021-11-19 07:51:51 --> Output Class Initialized
INFO - 2021-11-19 07:51:51 --> Security Class Initialized
DEBUG - 2021-11-19 07:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:51:51 --> Input Class Initialized
INFO - 2021-11-19 07:51:51 --> Language Class Initialized
INFO - 2021-11-19 07:51:51 --> Language Class Initialized
INFO - 2021-11-19 07:51:51 --> Config Class Initialized
INFO - 2021-11-19 07:51:51 --> Loader Class Initialized
INFO - 2021-11-19 07:51:51 --> Helper loaded: url_helper
INFO - 2021-11-19 07:51:51 --> Helper loaded: file_helper
INFO - 2021-11-19 07:51:51 --> Helper loaded: form_helper
INFO - 2021-11-19 07:51:51 --> Helper loaded: my_helper
INFO - 2021-11-19 07:51:51 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:51:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:51:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:51:51 --> Controller Class Initialized
DEBUG - 2021-11-19 07:51:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-11-19 07:51:51 --> Final output sent to browser
DEBUG - 2021-11-19 07:51:51 --> Total execution time: 0.1512
INFO - 2021-11-19 07:53:46 --> Config Class Initialized
INFO - 2021-11-19 07:53:46 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:53:46 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:53:46 --> Utf8 Class Initialized
INFO - 2021-11-19 07:53:46 --> URI Class Initialized
INFO - 2021-11-19 07:53:46 --> Router Class Initialized
INFO - 2021-11-19 07:53:46 --> Output Class Initialized
INFO - 2021-11-19 07:53:46 --> Security Class Initialized
DEBUG - 2021-11-19 07:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:53:46 --> Input Class Initialized
INFO - 2021-11-19 07:53:46 --> Language Class Initialized
INFO - 2021-11-19 07:53:46 --> Language Class Initialized
INFO - 2021-11-19 07:53:46 --> Config Class Initialized
INFO - 2021-11-19 07:53:46 --> Loader Class Initialized
INFO - 2021-11-19 07:53:46 --> Helper loaded: url_helper
INFO - 2021-11-19 07:53:46 --> Helper loaded: file_helper
INFO - 2021-11-19 07:53:46 --> Helper loaded: form_helper
INFO - 2021-11-19 07:53:46 --> Helper loaded: my_helper
INFO - 2021-11-19 07:53:46 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:53:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:53:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:53:46 --> Controller Class Initialized
DEBUG - 2021-11-19 07:53:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-11-19 07:53:46 --> Final output sent to browser
DEBUG - 2021-11-19 07:53:46 --> Total execution time: 0.1667
INFO - 2021-11-19 07:54:00 --> Config Class Initialized
INFO - 2021-11-19 07:54:00 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:54:00 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:54:00 --> Utf8 Class Initialized
INFO - 2021-11-19 07:54:00 --> URI Class Initialized
INFO - 2021-11-19 07:54:00 --> Router Class Initialized
INFO - 2021-11-19 07:54:00 --> Output Class Initialized
INFO - 2021-11-19 07:54:00 --> Security Class Initialized
DEBUG - 2021-11-19 07:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:54:00 --> Input Class Initialized
INFO - 2021-11-19 07:54:00 --> Language Class Initialized
INFO - 2021-11-19 07:54:00 --> Language Class Initialized
INFO - 2021-11-19 07:54:00 --> Config Class Initialized
INFO - 2021-11-19 07:54:00 --> Loader Class Initialized
INFO - 2021-11-19 07:54:00 --> Helper loaded: url_helper
INFO - 2021-11-19 07:54:00 --> Helper loaded: file_helper
INFO - 2021-11-19 07:54:00 --> Helper loaded: form_helper
INFO - 2021-11-19 07:54:00 --> Helper loaded: my_helper
INFO - 2021-11-19 07:54:00 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:54:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:54:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:54:00 --> Controller Class Initialized
DEBUG - 2021-11-19 07:54:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-11-19 07:54:00 --> Final output sent to browser
DEBUG - 2021-11-19 07:54:00 --> Total execution time: 0.1574
INFO - 2021-11-19 07:54:07 --> Config Class Initialized
INFO - 2021-11-19 07:54:07 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:54:07 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:54:07 --> Utf8 Class Initialized
INFO - 2021-11-19 07:54:07 --> URI Class Initialized
INFO - 2021-11-19 07:54:07 --> Router Class Initialized
INFO - 2021-11-19 07:54:07 --> Output Class Initialized
INFO - 2021-11-19 07:54:07 --> Security Class Initialized
DEBUG - 2021-11-19 07:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:54:07 --> Input Class Initialized
INFO - 2021-11-19 07:54:07 --> Language Class Initialized
INFO - 2021-11-19 07:54:07 --> Language Class Initialized
INFO - 2021-11-19 07:54:07 --> Config Class Initialized
INFO - 2021-11-19 07:54:07 --> Loader Class Initialized
INFO - 2021-11-19 07:54:07 --> Helper loaded: url_helper
INFO - 2021-11-19 07:54:07 --> Helper loaded: file_helper
INFO - 2021-11-19 07:54:07 --> Helper loaded: form_helper
INFO - 2021-11-19 07:54:07 --> Helper loaded: my_helper
INFO - 2021-11-19 07:54:07 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:54:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:54:07 --> Controller Class Initialized
DEBUG - 2021-11-19 07:54:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-11-19 07:54:07 --> Final output sent to browser
DEBUG - 2021-11-19 07:54:07 --> Total execution time: 0.1563
INFO - 2021-11-19 07:54:44 --> Config Class Initialized
INFO - 2021-11-19 07:54:44 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:54:44 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:54:44 --> Utf8 Class Initialized
INFO - 2021-11-19 07:54:44 --> URI Class Initialized
INFO - 2021-11-19 07:54:44 --> Router Class Initialized
INFO - 2021-11-19 07:54:44 --> Output Class Initialized
INFO - 2021-11-19 07:54:44 --> Security Class Initialized
DEBUG - 2021-11-19 07:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:54:44 --> Input Class Initialized
INFO - 2021-11-19 07:54:44 --> Language Class Initialized
INFO - 2021-11-19 07:54:44 --> Language Class Initialized
INFO - 2021-11-19 07:54:44 --> Config Class Initialized
INFO - 2021-11-19 07:54:44 --> Loader Class Initialized
INFO - 2021-11-19 07:54:44 --> Helper loaded: url_helper
INFO - 2021-11-19 07:54:44 --> Helper loaded: file_helper
INFO - 2021-11-19 07:54:44 --> Helper loaded: form_helper
INFO - 2021-11-19 07:54:44 --> Helper loaded: my_helper
INFO - 2021-11-19 07:54:44 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:54:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:54:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:54:44 --> Controller Class Initialized
DEBUG - 2021-11-19 07:54:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-11-19 07:54:44 --> Final output sent to browser
DEBUG - 2021-11-19 07:54:44 --> Total execution time: 0.1681
INFO - 2021-11-19 07:55:40 --> Config Class Initialized
INFO - 2021-11-19 07:55:40 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:55:40 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:55:40 --> Utf8 Class Initialized
INFO - 2021-11-19 07:55:40 --> URI Class Initialized
INFO - 2021-11-19 07:55:40 --> Router Class Initialized
INFO - 2021-11-19 07:55:40 --> Output Class Initialized
INFO - 2021-11-19 07:55:40 --> Security Class Initialized
DEBUG - 2021-11-19 07:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:55:40 --> Input Class Initialized
INFO - 2021-11-19 07:55:40 --> Language Class Initialized
INFO - 2021-11-19 07:55:40 --> Language Class Initialized
INFO - 2021-11-19 07:55:40 --> Config Class Initialized
INFO - 2021-11-19 07:55:40 --> Loader Class Initialized
INFO - 2021-11-19 07:55:40 --> Helper loaded: url_helper
INFO - 2021-11-19 07:55:40 --> Helper loaded: file_helper
INFO - 2021-11-19 07:55:40 --> Helper loaded: form_helper
INFO - 2021-11-19 07:55:40 --> Helper loaded: my_helper
INFO - 2021-11-19 07:55:40 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:55:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:55:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:55:40 --> Controller Class Initialized
DEBUG - 2021-11-19 07:55:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-11-19 07:55:40 --> Final output sent to browser
DEBUG - 2021-11-19 07:55:40 --> Total execution time: 0.1479
INFO - 2021-11-19 07:55:50 --> Config Class Initialized
INFO - 2021-11-19 07:55:50 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:55:50 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:55:50 --> Utf8 Class Initialized
INFO - 2021-11-19 07:55:50 --> URI Class Initialized
INFO - 2021-11-19 07:55:50 --> Router Class Initialized
INFO - 2021-11-19 07:55:50 --> Output Class Initialized
INFO - 2021-11-19 07:55:50 --> Security Class Initialized
DEBUG - 2021-11-19 07:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:55:50 --> Input Class Initialized
INFO - 2021-11-19 07:55:50 --> Language Class Initialized
INFO - 2021-11-19 07:55:50 --> Language Class Initialized
INFO - 2021-11-19 07:55:50 --> Config Class Initialized
INFO - 2021-11-19 07:55:50 --> Loader Class Initialized
INFO - 2021-11-19 07:55:50 --> Helper loaded: url_helper
INFO - 2021-11-19 07:55:50 --> Helper loaded: file_helper
INFO - 2021-11-19 07:55:50 --> Helper loaded: form_helper
INFO - 2021-11-19 07:55:50 --> Helper loaded: my_helper
INFO - 2021-11-19 07:55:50 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:55:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:55:50 --> Controller Class Initialized
DEBUG - 2021-11-19 07:55:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-11-19 07:55:50 --> Final output sent to browser
DEBUG - 2021-11-19 07:55:50 --> Total execution time: 0.1593
INFO - 2021-11-19 07:56:43 --> Config Class Initialized
INFO - 2021-11-19 07:56:43 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:56:43 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:56:43 --> Utf8 Class Initialized
INFO - 2021-11-19 07:56:43 --> URI Class Initialized
INFO - 2021-11-19 07:56:43 --> Router Class Initialized
INFO - 2021-11-19 07:56:43 --> Output Class Initialized
INFO - 2021-11-19 07:56:43 --> Security Class Initialized
DEBUG - 2021-11-19 07:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:56:43 --> Input Class Initialized
INFO - 2021-11-19 07:56:43 --> Language Class Initialized
INFO - 2021-11-19 07:56:43 --> Language Class Initialized
INFO - 2021-11-19 07:56:43 --> Config Class Initialized
INFO - 2021-11-19 07:56:43 --> Loader Class Initialized
INFO - 2021-11-19 07:56:43 --> Helper loaded: url_helper
INFO - 2021-11-19 07:56:43 --> Helper loaded: file_helper
INFO - 2021-11-19 07:56:43 --> Helper loaded: form_helper
INFO - 2021-11-19 07:56:43 --> Helper loaded: my_helper
INFO - 2021-11-19 07:56:43 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:56:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:56:43 --> Controller Class Initialized
INFO - 2021-11-19 07:56:43 --> Helper loaded: cookie_helper
INFO - 2021-11-19 07:56:43 --> Config Class Initialized
INFO - 2021-11-19 07:56:43 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:56:43 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:56:43 --> Utf8 Class Initialized
INFO - 2021-11-19 07:56:43 --> URI Class Initialized
INFO - 2021-11-19 07:56:43 --> Router Class Initialized
INFO - 2021-11-19 07:56:43 --> Output Class Initialized
INFO - 2021-11-19 07:56:43 --> Security Class Initialized
DEBUG - 2021-11-19 07:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:56:43 --> Input Class Initialized
INFO - 2021-11-19 07:56:43 --> Language Class Initialized
INFO - 2021-11-19 07:56:43 --> Language Class Initialized
INFO - 2021-11-19 07:56:43 --> Config Class Initialized
INFO - 2021-11-19 07:56:43 --> Loader Class Initialized
INFO - 2021-11-19 07:56:43 --> Helper loaded: url_helper
INFO - 2021-11-19 07:56:43 --> Helper loaded: file_helper
INFO - 2021-11-19 07:56:43 --> Helper loaded: form_helper
INFO - 2021-11-19 07:56:43 --> Helper loaded: my_helper
INFO - 2021-11-19 07:56:43 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:56:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:56:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:56:44 --> Controller Class Initialized
DEBUG - 2021-11-19 07:56:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-11-19 07:56:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 07:56:44 --> Final output sent to browser
DEBUG - 2021-11-19 07:56:44 --> Total execution time: 0.0741
INFO - 2021-11-19 07:56:55 --> Config Class Initialized
INFO - 2021-11-19 07:56:55 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:56:55 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:56:55 --> Utf8 Class Initialized
INFO - 2021-11-19 07:56:55 --> URI Class Initialized
INFO - 2021-11-19 07:56:55 --> Router Class Initialized
INFO - 2021-11-19 07:56:55 --> Output Class Initialized
INFO - 2021-11-19 07:56:55 --> Security Class Initialized
DEBUG - 2021-11-19 07:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:56:55 --> Input Class Initialized
INFO - 2021-11-19 07:56:55 --> Language Class Initialized
INFO - 2021-11-19 07:56:55 --> Language Class Initialized
INFO - 2021-11-19 07:56:55 --> Config Class Initialized
INFO - 2021-11-19 07:56:55 --> Loader Class Initialized
INFO - 2021-11-19 07:56:55 --> Helper loaded: url_helper
INFO - 2021-11-19 07:56:55 --> Helper loaded: file_helper
INFO - 2021-11-19 07:56:55 --> Helper loaded: form_helper
INFO - 2021-11-19 07:56:55 --> Helper loaded: my_helper
INFO - 2021-11-19 07:56:55 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:56:55 --> Controller Class Initialized
INFO - 2021-11-19 07:56:55 --> Helper loaded: cookie_helper
INFO - 2021-11-19 07:56:55 --> Final output sent to browser
DEBUG - 2021-11-19 07:56:55 --> Total execution time: 0.0966
INFO - 2021-11-19 07:56:55 --> Config Class Initialized
INFO - 2021-11-19 07:56:55 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:56:55 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:56:55 --> Utf8 Class Initialized
INFO - 2021-11-19 07:56:55 --> URI Class Initialized
INFO - 2021-11-19 07:56:55 --> Router Class Initialized
INFO - 2021-11-19 07:56:55 --> Output Class Initialized
INFO - 2021-11-19 07:56:55 --> Security Class Initialized
DEBUG - 2021-11-19 07:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:56:55 --> Input Class Initialized
INFO - 2021-11-19 07:56:55 --> Language Class Initialized
INFO - 2021-11-19 07:56:55 --> Language Class Initialized
INFO - 2021-11-19 07:56:55 --> Config Class Initialized
INFO - 2021-11-19 07:56:55 --> Loader Class Initialized
INFO - 2021-11-19 07:56:55 --> Helper loaded: url_helper
INFO - 2021-11-19 07:56:55 --> Helper loaded: file_helper
INFO - 2021-11-19 07:56:55 --> Helper loaded: form_helper
INFO - 2021-11-19 07:56:55 --> Helper loaded: my_helper
INFO - 2021-11-19 07:56:55 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:56:55 --> Controller Class Initialized
DEBUG - 2021-11-19 07:56:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-11-19 07:56:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 07:56:56 --> Final output sent to browser
DEBUG - 2021-11-19 07:56:56 --> Total execution time: 1.1421
INFO - 2021-11-19 07:57:05 --> Config Class Initialized
INFO - 2021-11-19 07:57:05 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:57:05 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:57:05 --> Utf8 Class Initialized
INFO - 2021-11-19 07:57:05 --> URI Class Initialized
INFO - 2021-11-19 07:57:05 --> Router Class Initialized
INFO - 2021-11-19 07:57:05 --> Output Class Initialized
INFO - 2021-11-19 07:57:05 --> Security Class Initialized
DEBUG - 2021-11-19 07:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:57:05 --> Input Class Initialized
INFO - 2021-11-19 07:57:05 --> Language Class Initialized
INFO - 2021-11-19 07:57:05 --> Language Class Initialized
INFO - 2021-11-19 07:57:05 --> Config Class Initialized
INFO - 2021-11-19 07:57:05 --> Loader Class Initialized
INFO - 2021-11-19 07:57:05 --> Helper loaded: url_helper
INFO - 2021-11-19 07:57:05 --> Helper loaded: file_helper
INFO - 2021-11-19 07:57:05 --> Helper loaded: form_helper
INFO - 2021-11-19 07:57:05 --> Helper loaded: my_helper
INFO - 2021-11-19 07:57:05 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:57:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:57:05 --> Controller Class Initialized
INFO - 2021-11-19 07:57:05 --> Helper loaded: cookie_helper
INFO - 2021-11-19 07:57:05 --> Config Class Initialized
INFO - 2021-11-19 07:57:05 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:57:05 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:57:05 --> Utf8 Class Initialized
INFO - 2021-11-19 07:57:05 --> URI Class Initialized
INFO - 2021-11-19 07:57:05 --> Router Class Initialized
INFO - 2021-11-19 07:57:05 --> Output Class Initialized
INFO - 2021-11-19 07:57:05 --> Security Class Initialized
DEBUG - 2021-11-19 07:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:57:05 --> Input Class Initialized
INFO - 2021-11-19 07:57:05 --> Language Class Initialized
INFO - 2021-11-19 07:57:05 --> Language Class Initialized
INFO - 2021-11-19 07:57:05 --> Config Class Initialized
INFO - 2021-11-19 07:57:05 --> Loader Class Initialized
INFO - 2021-11-19 07:57:05 --> Helper loaded: url_helper
INFO - 2021-11-19 07:57:05 --> Helper loaded: file_helper
INFO - 2021-11-19 07:57:05 --> Helper loaded: form_helper
INFO - 2021-11-19 07:57:05 --> Helper loaded: my_helper
INFO - 2021-11-19 07:57:05 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:57:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:57:05 --> Controller Class Initialized
DEBUG - 2021-11-19 07:57:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-11-19 07:57:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 07:57:05 --> Final output sent to browser
DEBUG - 2021-11-19 07:57:05 --> Total execution time: 0.0668
INFO - 2021-11-19 07:57:12 --> Config Class Initialized
INFO - 2021-11-19 07:57:12 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:57:12 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:57:12 --> Utf8 Class Initialized
INFO - 2021-11-19 07:57:12 --> URI Class Initialized
INFO - 2021-11-19 07:57:12 --> Router Class Initialized
INFO - 2021-11-19 07:57:12 --> Output Class Initialized
INFO - 2021-11-19 07:57:12 --> Security Class Initialized
DEBUG - 2021-11-19 07:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:57:12 --> Input Class Initialized
INFO - 2021-11-19 07:57:12 --> Language Class Initialized
INFO - 2021-11-19 07:57:12 --> Language Class Initialized
INFO - 2021-11-19 07:57:12 --> Config Class Initialized
INFO - 2021-11-19 07:57:12 --> Loader Class Initialized
INFO - 2021-11-19 07:57:12 --> Helper loaded: url_helper
INFO - 2021-11-19 07:57:12 --> Helper loaded: file_helper
INFO - 2021-11-19 07:57:12 --> Helper loaded: form_helper
INFO - 2021-11-19 07:57:12 --> Helper loaded: my_helper
INFO - 2021-11-19 07:57:12 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:57:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:57:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:57:12 --> Controller Class Initialized
INFO - 2021-11-19 07:57:12 --> Helper loaded: cookie_helper
INFO - 2021-11-19 07:57:12 --> Final output sent to browser
DEBUG - 2021-11-19 07:57:12 --> Total execution time: 0.0709
INFO - 2021-11-19 07:57:13 --> Config Class Initialized
INFO - 2021-11-19 07:57:13 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:57:13 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:57:13 --> Utf8 Class Initialized
INFO - 2021-11-19 07:57:13 --> URI Class Initialized
INFO - 2021-11-19 07:57:13 --> Router Class Initialized
INFO - 2021-11-19 07:57:13 --> Output Class Initialized
INFO - 2021-11-19 07:57:13 --> Security Class Initialized
DEBUG - 2021-11-19 07:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:57:13 --> Input Class Initialized
INFO - 2021-11-19 07:57:13 --> Language Class Initialized
INFO - 2021-11-19 07:57:13 --> Language Class Initialized
INFO - 2021-11-19 07:57:13 --> Config Class Initialized
INFO - 2021-11-19 07:57:13 --> Loader Class Initialized
INFO - 2021-11-19 07:57:13 --> Helper loaded: url_helper
INFO - 2021-11-19 07:57:13 --> Helper loaded: file_helper
INFO - 2021-11-19 07:57:13 --> Helper loaded: form_helper
INFO - 2021-11-19 07:57:13 --> Helper loaded: my_helper
INFO - 2021-11-19 07:57:13 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:57:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:57:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:57:13 --> Controller Class Initialized
DEBUG - 2021-11-19 07:57:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-11-19 07:57:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 07:57:14 --> Final output sent to browser
DEBUG - 2021-11-19 07:57:14 --> Total execution time: 1.0272
INFO - 2021-11-19 07:57:21 --> Config Class Initialized
INFO - 2021-11-19 07:57:21 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:57:21 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:57:21 --> Utf8 Class Initialized
INFO - 2021-11-19 07:57:21 --> URI Class Initialized
INFO - 2021-11-19 07:57:21 --> Router Class Initialized
INFO - 2021-11-19 07:57:21 --> Output Class Initialized
INFO - 2021-11-19 07:57:21 --> Security Class Initialized
DEBUG - 2021-11-19 07:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:57:21 --> Input Class Initialized
INFO - 2021-11-19 07:57:21 --> Language Class Initialized
INFO - 2021-11-19 07:57:21 --> Language Class Initialized
INFO - 2021-11-19 07:57:21 --> Config Class Initialized
INFO - 2021-11-19 07:57:21 --> Loader Class Initialized
INFO - 2021-11-19 07:57:21 --> Helper loaded: url_helper
INFO - 2021-11-19 07:57:21 --> Helper loaded: file_helper
INFO - 2021-11-19 07:57:21 --> Helper loaded: form_helper
INFO - 2021-11-19 07:57:21 --> Helper loaded: my_helper
INFO - 2021-11-19 07:57:21 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:57:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:57:21 --> Controller Class Initialized
DEBUG - 2021-11-19 07:57:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-11-19 07:57:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 07:57:21 --> Final output sent to browser
DEBUG - 2021-11-19 07:57:21 --> Total execution time: 0.0844
INFO - 2021-11-19 07:57:23 --> Config Class Initialized
INFO - 2021-11-19 07:57:23 --> Hooks Class Initialized
DEBUG - 2021-11-19 07:57:23 --> UTF-8 Support Enabled
INFO - 2021-11-19 07:57:23 --> Utf8 Class Initialized
INFO - 2021-11-19 07:57:23 --> URI Class Initialized
INFO - 2021-11-19 07:57:23 --> Router Class Initialized
INFO - 2021-11-19 07:57:23 --> Output Class Initialized
INFO - 2021-11-19 07:57:23 --> Security Class Initialized
DEBUG - 2021-11-19 07:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 07:57:23 --> Input Class Initialized
INFO - 2021-11-19 07:57:23 --> Language Class Initialized
INFO - 2021-11-19 07:57:23 --> Language Class Initialized
INFO - 2021-11-19 07:57:23 --> Config Class Initialized
INFO - 2021-11-19 07:57:23 --> Loader Class Initialized
INFO - 2021-11-19 07:57:23 --> Helper loaded: url_helper
INFO - 2021-11-19 07:57:23 --> Helper loaded: file_helper
INFO - 2021-11-19 07:57:23 --> Helper loaded: form_helper
INFO - 2021-11-19 07:57:23 --> Helper loaded: my_helper
INFO - 2021-11-19 07:57:23 --> Database Driver Class Initialized
DEBUG - 2021-11-19 07:57:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 07:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 07:57:23 --> Controller Class Initialized
DEBUG - 2021-11-19 07:57:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-11-19 07:57:23 --> Final output sent to browser
DEBUG - 2021-11-19 07:57:23 --> Total execution time: 0.2992
INFO - 2021-11-19 08:12:18 --> Config Class Initialized
INFO - 2021-11-19 08:12:18 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:12:18 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:12:18 --> Utf8 Class Initialized
INFO - 2021-11-19 08:12:18 --> URI Class Initialized
INFO - 2021-11-19 08:12:18 --> Router Class Initialized
INFO - 2021-11-19 08:12:18 --> Output Class Initialized
INFO - 2021-11-19 08:12:18 --> Security Class Initialized
DEBUG - 2021-11-19 08:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:12:18 --> Input Class Initialized
INFO - 2021-11-19 08:12:18 --> Language Class Initialized
INFO - 2021-11-19 08:12:18 --> Language Class Initialized
INFO - 2021-11-19 08:12:18 --> Config Class Initialized
INFO - 2021-11-19 08:12:18 --> Loader Class Initialized
INFO - 2021-11-19 08:12:18 --> Helper loaded: url_helper
INFO - 2021-11-19 08:12:18 --> Helper loaded: file_helper
INFO - 2021-11-19 08:12:18 --> Helper loaded: form_helper
INFO - 2021-11-19 08:12:18 --> Helper loaded: my_helper
INFO - 2021-11-19 08:12:18 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:12:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:12:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:12:18 --> Controller Class Initialized
DEBUG - 2021-11-19 08:12:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-11-19 08:12:19 --> Final output sent to browser
DEBUG - 2021-11-19 08:12:19 --> Total execution time: 0.1763
INFO - 2021-11-19 08:12:31 --> Config Class Initialized
INFO - 2021-11-19 08:12:31 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:12:31 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:12:31 --> Utf8 Class Initialized
INFO - 2021-11-19 08:12:31 --> URI Class Initialized
INFO - 2021-11-19 08:12:31 --> Router Class Initialized
INFO - 2021-11-19 08:12:31 --> Output Class Initialized
INFO - 2021-11-19 08:12:31 --> Security Class Initialized
DEBUG - 2021-11-19 08:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:12:31 --> Input Class Initialized
INFO - 2021-11-19 08:12:31 --> Language Class Initialized
INFO - 2021-11-19 08:12:31 --> Language Class Initialized
INFO - 2021-11-19 08:12:31 --> Config Class Initialized
INFO - 2021-11-19 08:12:31 --> Loader Class Initialized
INFO - 2021-11-19 08:12:31 --> Helper loaded: url_helper
INFO - 2021-11-19 08:12:31 --> Helper loaded: file_helper
INFO - 2021-11-19 08:12:31 --> Helper loaded: form_helper
INFO - 2021-11-19 08:12:31 --> Helper loaded: my_helper
INFO - 2021-11-19 08:12:31 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:12:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:12:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:12:31 --> Controller Class Initialized
DEBUG - 2021-11-19 08:12:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-11-19 08:12:31 --> Final output sent to browser
DEBUG - 2021-11-19 08:12:31 --> Total execution time: 0.1463
INFO - 2021-11-19 08:13:34 --> Config Class Initialized
INFO - 2021-11-19 08:13:34 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:13:34 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:13:34 --> Utf8 Class Initialized
INFO - 2021-11-19 08:13:34 --> URI Class Initialized
INFO - 2021-11-19 08:13:34 --> Router Class Initialized
INFO - 2021-11-19 08:13:34 --> Output Class Initialized
INFO - 2021-11-19 08:13:34 --> Security Class Initialized
DEBUG - 2021-11-19 08:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:13:34 --> Input Class Initialized
INFO - 2021-11-19 08:13:34 --> Language Class Initialized
INFO - 2021-11-19 08:13:34 --> Language Class Initialized
INFO - 2021-11-19 08:13:34 --> Config Class Initialized
INFO - 2021-11-19 08:13:34 --> Loader Class Initialized
INFO - 2021-11-19 08:13:34 --> Helper loaded: url_helper
INFO - 2021-11-19 08:13:34 --> Helper loaded: file_helper
INFO - 2021-11-19 08:13:34 --> Helper loaded: form_helper
INFO - 2021-11-19 08:13:34 --> Helper loaded: my_helper
INFO - 2021-11-19 08:13:34 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:13:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:13:34 --> Controller Class Initialized
DEBUG - 2021-11-19 08:13:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-11-19 08:13:34 --> Final output sent to browser
DEBUG - 2021-11-19 08:13:34 --> Total execution time: 0.1617
INFO - 2021-11-19 08:13:48 --> Config Class Initialized
INFO - 2021-11-19 08:13:48 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:13:48 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:13:48 --> Utf8 Class Initialized
INFO - 2021-11-19 08:13:48 --> URI Class Initialized
INFO - 2021-11-19 08:13:48 --> Router Class Initialized
INFO - 2021-11-19 08:13:48 --> Output Class Initialized
INFO - 2021-11-19 08:13:48 --> Security Class Initialized
DEBUG - 2021-11-19 08:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:13:48 --> Input Class Initialized
INFO - 2021-11-19 08:13:48 --> Language Class Initialized
INFO - 2021-11-19 08:13:48 --> Language Class Initialized
INFO - 2021-11-19 08:13:48 --> Config Class Initialized
INFO - 2021-11-19 08:13:48 --> Loader Class Initialized
INFO - 2021-11-19 08:13:48 --> Helper loaded: url_helper
INFO - 2021-11-19 08:13:48 --> Helper loaded: file_helper
INFO - 2021-11-19 08:13:48 --> Helper loaded: form_helper
INFO - 2021-11-19 08:13:48 --> Helper loaded: my_helper
INFO - 2021-11-19 08:13:48 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:13:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:13:48 --> Controller Class Initialized
DEBUG - 2021-11-19 08:13:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-11-19 08:13:48 --> Final output sent to browser
DEBUG - 2021-11-19 08:13:48 --> Total execution time: 0.1392
INFO - 2021-11-19 08:13:58 --> Config Class Initialized
INFO - 2021-11-19 08:13:58 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:13:58 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:13:58 --> Utf8 Class Initialized
INFO - 2021-11-19 08:13:58 --> URI Class Initialized
INFO - 2021-11-19 08:13:58 --> Router Class Initialized
INFO - 2021-11-19 08:13:58 --> Output Class Initialized
INFO - 2021-11-19 08:13:58 --> Security Class Initialized
DEBUG - 2021-11-19 08:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:13:58 --> Input Class Initialized
INFO - 2021-11-19 08:13:58 --> Language Class Initialized
INFO - 2021-11-19 08:13:58 --> Language Class Initialized
INFO - 2021-11-19 08:13:58 --> Config Class Initialized
INFO - 2021-11-19 08:13:58 --> Loader Class Initialized
INFO - 2021-11-19 08:13:58 --> Helper loaded: url_helper
INFO - 2021-11-19 08:13:58 --> Helper loaded: file_helper
INFO - 2021-11-19 08:13:58 --> Helper loaded: form_helper
INFO - 2021-11-19 08:13:58 --> Helper loaded: my_helper
INFO - 2021-11-19 08:13:58 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:13:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:13:58 --> Controller Class Initialized
DEBUG - 2021-11-19 08:13:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-11-19 08:13:58 --> Final output sent to browser
DEBUG - 2021-11-19 08:13:58 --> Total execution time: 0.1564
INFO - 2021-11-19 08:14:08 --> Config Class Initialized
INFO - 2021-11-19 08:14:08 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:14:08 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:14:08 --> Utf8 Class Initialized
INFO - 2021-11-19 08:14:08 --> URI Class Initialized
INFO - 2021-11-19 08:14:08 --> Router Class Initialized
INFO - 2021-11-19 08:14:08 --> Output Class Initialized
INFO - 2021-11-19 08:14:08 --> Security Class Initialized
DEBUG - 2021-11-19 08:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:14:08 --> Input Class Initialized
INFO - 2021-11-19 08:14:08 --> Language Class Initialized
INFO - 2021-11-19 08:14:08 --> Language Class Initialized
INFO - 2021-11-19 08:14:08 --> Config Class Initialized
INFO - 2021-11-19 08:14:08 --> Loader Class Initialized
INFO - 2021-11-19 08:14:08 --> Helper loaded: url_helper
INFO - 2021-11-19 08:14:08 --> Helper loaded: file_helper
INFO - 2021-11-19 08:14:08 --> Helper loaded: form_helper
INFO - 2021-11-19 08:14:08 --> Helper loaded: my_helper
INFO - 2021-11-19 08:14:08 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:14:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:14:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:14:08 --> Controller Class Initialized
DEBUG - 2021-11-19 08:14:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-11-19 08:14:08 --> Final output sent to browser
DEBUG - 2021-11-19 08:14:08 --> Total execution time: 0.1561
INFO - 2021-11-19 08:14:43 --> Config Class Initialized
INFO - 2021-11-19 08:14:43 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:14:43 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:14:43 --> Utf8 Class Initialized
INFO - 2021-11-19 08:14:43 --> URI Class Initialized
INFO - 2021-11-19 08:14:43 --> Router Class Initialized
INFO - 2021-11-19 08:14:43 --> Output Class Initialized
INFO - 2021-11-19 08:14:43 --> Security Class Initialized
DEBUG - 2021-11-19 08:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:14:43 --> Input Class Initialized
INFO - 2021-11-19 08:14:43 --> Language Class Initialized
INFO - 2021-11-19 08:14:43 --> Language Class Initialized
INFO - 2021-11-19 08:14:43 --> Config Class Initialized
INFO - 2021-11-19 08:14:43 --> Loader Class Initialized
INFO - 2021-11-19 08:14:43 --> Helper loaded: url_helper
INFO - 2021-11-19 08:14:43 --> Helper loaded: file_helper
INFO - 2021-11-19 08:14:43 --> Helper loaded: form_helper
INFO - 2021-11-19 08:14:43 --> Helper loaded: my_helper
INFO - 2021-11-19 08:14:43 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:14:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:14:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:14:43 --> Controller Class Initialized
INFO - 2021-11-19 08:14:43 --> Helper loaded: cookie_helper
INFO - 2021-11-19 08:14:43 --> Config Class Initialized
INFO - 2021-11-19 08:14:43 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:14:43 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:14:43 --> Utf8 Class Initialized
INFO - 2021-11-19 08:14:43 --> URI Class Initialized
INFO - 2021-11-19 08:14:43 --> Router Class Initialized
INFO - 2021-11-19 08:14:43 --> Output Class Initialized
INFO - 2021-11-19 08:14:43 --> Security Class Initialized
DEBUG - 2021-11-19 08:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:14:43 --> Input Class Initialized
INFO - 2021-11-19 08:14:43 --> Language Class Initialized
INFO - 2021-11-19 08:14:43 --> Language Class Initialized
INFO - 2021-11-19 08:14:43 --> Config Class Initialized
INFO - 2021-11-19 08:14:43 --> Loader Class Initialized
INFO - 2021-11-19 08:14:43 --> Helper loaded: url_helper
INFO - 2021-11-19 08:14:43 --> Helper loaded: file_helper
INFO - 2021-11-19 08:14:43 --> Helper loaded: form_helper
INFO - 2021-11-19 08:14:43 --> Helper loaded: my_helper
INFO - 2021-11-19 08:14:43 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:14:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:14:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:14:43 --> Controller Class Initialized
DEBUG - 2021-11-19 08:14:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-11-19 08:14:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 08:14:43 --> Final output sent to browser
DEBUG - 2021-11-19 08:14:43 --> Total execution time: 0.0887
INFO - 2021-11-19 08:17:00 --> Config Class Initialized
INFO - 2021-11-19 08:17:00 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:17:00 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:17:00 --> Utf8 Class Initialized
INFO - 2021-11-19 08:17:00 --> URI Class Initialized
INFO - 2021-11-19 08:17:00 --> Router Class Initialized
INFO - 2021-11-19 08:17:00 --> Output Class Initialized
INFO - 2021-11-19 08:17:00 --> Security Class Initialized
DEBUG - 2021-11-19 08:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:17:00 --> Input Class Initialized
INFO - 2021-11-19 08:17:00 --> Language Class Initialized
INFO - 2021-11-19 08:17:00 --> Language Class Initialized
INFO - 2021-11-19 08:17:00 --> Config Class Initialized
INFO - 2021-11-19 08:17:00 --> Loader Class Initialized
INFO - 2021-11-19 08:17:00 --> Helper loaded: url_helper
INFO - 2021-11-19 08:17:00 --> Helper loaded: file_helper
INFO - 2021-11-19 08:17:00 --> Helper loaded: form_helper
INFO - 2021-11-19 08:17:00 --> Helper loaded: my_helper
INFO - 2021-11-19 08:17:00 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:17:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:17:00 --> Controller Class Initialized
INFO - 2021-11-19 08:17:00 --> Helper loaded: cookie_helper
INFO - 2021-11-19 08:17:00 --> Final output sent to browser
DEBUG - 2021-11-19 08:17:00 --> Total execution time: 0.0859
INFO - 2021-11-19 08:17:00 --> Config Class Initialized
INFO - 2021-11-19 08:17:00 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:17:00 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:17:00 --> Utf8 Class Initialized
INFO - 2021-11-19 08:17:00 --> URI Class Initialized
INFO - 2021-11-19 08:17:00 --> Router Class Initialized
INFO - 2021-11-19 08:17:00 --> Output Class Initialized
INFO - 2021-11-19 08:17:00 --> Security Class Initialized
DEBUG - 2021-11-19 08:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:17:00 --> Input Class Initialized
INFO - 2021-11-19 08:17:00 --> Language Class Initialized
INFO - 2021-11-19 08:17:00 --> Language Class Initialized
INFO - 2021-11-19 08:17:00 --> Config Class Initialized
INFO - 2021-11-19 08:17:00 --> Loader Class Initialized
INFO - 2021-11-19 08:17:00 --> Helper loaded: url_helper
INFO - 2021-11-19 08:17:00 --> Helper loaded: file_helper
INFO - 2021-11-19 08:17:00 --> Helper loaded: form_helper
INFO - 2021-11-19 08:17:00 --> Helper loaded: my_helper
INFO - 2021-11-19 08:17:00 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:17:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:17:00 --> Controller Class Initialized
DEBUG - 2021-11-19 08:17:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-11-19 08:17:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 08:17:01 --> Final output sent to browser
DEBUG - 2021-11-19 08:17:01 --> Total execution time: 1.1171
INFO - 2021-11-19 08:17:04 --> Config Class Initialized
INFO - 2021-11-19 08:17:04 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:17:04 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:17:04 --> Utf8 Class Initialized
INFO - 2021-11-19 08:17:04 --> URI Class Initialized
INFO - 2021-11-19 08:17:04 --> Router Class Initialized
INFO - 2021-11-19 08:17:04 --> Output Class Initialized
INFO - 2021-11-19 08:17:04 --> Security Class Initialized
DEBUG - 2021-11-19 08:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:17:04 --> Input Class Initialized
INFO - 2021-11-19 08:17:04 --> Language Class Initialized
INFO - 2021-11-19 08:17:04 --> Language Class Initialized
INFO - 2021-11-19 08:17:04 --> Config Class Initialized
INFO - 2021-11-19 08:17:04 --> Loader Class Initialized
INFO - 2021-11-19 08:17:04 --> Helper loaded: url_helper
INFO - 2021-11-19 08:17:04 --> Helper loaded: file_helper
INFO - 2021-11-19 08:17:04 --> Helper loaded: form_helper
INFO - 2021-11-19 08:17:04 --> Helper loaded: my_helper
INFO - 2021-11-19 08:17:04 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:17:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:17:04 --> Controller Class Initialized
DEBUG - 2021-11-19 08:17:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-11-19 08:17:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 08:17:04 --> Final output sent to browser
DEBUG - 2021-11-19 08:17:04 --> Total execution time: 0.0994
INFO - 2021-11-19 08:17:09 --> Config Class Initialized
INFO - 2021-11-19 08:17:09 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:17:09 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:17:09 --> Utf8 Class Initialized
INFO - 2021-11-19 08:17:09 --> URI Class Initialized
INFO - 2021-11-19 08:17:09 --> Router Class Initialized
INFO - 2021-11-19 08:17:09 --> Output Class Initialized
INFO - 2021-11-19 08:17:09 --> Security Class Initialized
DEBUG - 2021-11-19 08:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:17:09 --> Input Class Initialized
INFO - 2021-11-19 08:17:09 --> Language Class Initialized
INFO - 2021-11-19 08:17:09 --> Language Class Initialized
INFO - 2021-11-19 08:17:09 --> Config Class Initialized
INFO - 2021-11-19 08:17:09 --> Loader Class Initialized
INFO - 2021-11-19 08:17:09 --> Helper loaded: url_helper
INFO - 2021-11-19 08:17:09 --> Helper loaded: file_helper
INFO - 2021-11-19 08:17:09 --> Helper loaded: form_helper
INFO - 2021-11-19 08:17:09 --> Helper loaded: my_helper
INFO - 2021-11-19 08:17:09 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:17:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:17:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:17:09 --> Controller Class Initialized
DEBUG - 2021-11-19 08:17:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-11-19 08:17:09 --> Final output sent to browser
DEBUG - 2021-11-19 08:17:09 --> Total execution time: 0.2274
INFO - 2021-11-19 08:17:31 --> Config Class Initialized
INFO - 2021-11-19 08:17:31 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:17:31 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:17:31 --> Utf8 Class Initialized
INFO - 2021-11-19 08:17:31 --> URI Class Initialized
INFO - 2021-11-19 08:17:31 --> Router Class Initialized
INFO - 2021-11-19 08:17:31 --> Output Class Initialized
INFO - 2021-11-19 08:17:31 --> Security Class Initialized
DEBUG - 2021-11-19 08:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:17:31 --> Input Class Initialized
INFO - 2021-11-19 08:17:31 --> Language Class Initialized
INFO - 2021-11-19 08:17:31 --> Language Class Initialized
INFO - 2021-11-19 08:17:31 --> Config Class Initialized
INFO - 2021-11-19 08:17:31 --> Loader Class Initialized
INFO - 2021-11-19 08:17:31 --> Helper loaded: url_helper
INFO - 2021-11-19 08:17:31 --> Helper loaded: file_helper
INFO - 2021-11-19 08:17:31 --> Helper loaded: form_helper
INFO - 2021-11-19 08:17:31 --> Helper loaded: my_helper
INFO - 2021-11-19 08:17:31 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:17:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:17:31 --> Controller Class Initialized
DEBUG - 2021-11-19 08:17:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-11-19 08:17:31 --> Final output sent to browser
DEBUG - 2021-11-19 08:17:31 --> Total execution time: 0.1570
INFO - 2021-11-19 08:18:16 --> Config Class Initialized
INFO - 2021-11-19 08:18:16 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:18:16 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:18:16 --> Utf8 Class Initialized
INFO - 2021-11-19 08:18:16 --> URI Class Initialized
INFO - 2021-11-19 08:18:16 --> Router Class Initialized
INFO - 2021-11-19 08:18:16 --> Output Class Initialized
INFO - 2021-11-19 08:18:16 --> Security Class Initialized
DEBUG - 2021-11-19 08:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:18:16 --> Input Class Initialized
INFO - 2021-11-19 08:18:16 --> Language Class Initialized
INFO - 2021-11-19 08:18:16 --> Language Class Initialized
INFO - 2021-11-19 08:18:16 --> Config Class Initialized
INFO - 2021-11-19 08:18:16 --> Loader Class Initialized
INFO - 2021-11-19 08:18:16 --> Helper loaded: url_helper
INFO - 2021-11-19 08:18:16 --> Helper loaded: file_helper
INFO - 2021-11-19 08:18:16 --> Helper loaded: form_helper
INFO - 2021-11-19 08:18:16 --> Helper loaded: my_helper
INFO - 2021-11-19 08:18:16 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:18:16 --> Controller Class Initialized
DEBUG - 2021-11-19 08:18:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-11-19 08:18:16 --> Final output sent to browser
DEBUG - 2021-11-19 08:18:16 --> Total execution time: 0.1545
INFO - 2021-11-19 08:21:45 --> Config Class Initialized
INFO - 2021-11-19 08:21:45 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:21:45 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:21:45 --> Utf8 Class Initialized
INFO - 2021-11-19 08:21:45 --> URI Class Initialized
INFO - 2021-11-19 08:21:45 --> Router Class Initialized
INFO - 2021-11-19 08:21:45 --> Output Class Initialized
INFO - 2021-11-19 08:21:45 --> Security Class Initialized
DEBUG - 2021-11-19 08:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:21:45 --> Input Class Initialized
INFO - 2021-11-19 08:21:45 --> Language Class Initialized
INFO - 2021-11-19 08:21:45 --> Language Class Initialized
INFO - 2021-11-19 08:21:45 --> Config Class Initialized
INFO - 2021-11-19 08:21:45 --> Loader Class Initialized
INFO - 2021-11-19 08:21:45 --> Helper loaded: url_helper
INFO - 2021-11-19 08:21:45 --> Helper loaded: file_helper
INFO - 2021-11-19 08:21:45 --> Helper loaded: form_helper
INFO - 2021-11-19 08:21:45 --> Helper loaded: my_helper
INFO - 2021-11-19 08:21:45 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:21:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:21:45 --> Controller Class Initialized
DEBUG - 2021-11-19 08:21:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-11-19 08:21:45 --> Final output sent to browser
DEBUG - 2021-11-19 08:21:45 --> Total execution time: 0.1530
INFO - 2021-11-19 08:22:01 --> Config Class Initialized
INFO - 2021-11-19 08:22:01 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:22:01 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:22:01 --> Utf8 Class Initialized
INFO - 2021-11-19 08:22:01 --> URI Class Initialized
INFO - 2021-11-19 08:22:01 --> Router Class Initialized
INFO - 2021-11-19 08:22:01 --> Output Class Initialized
INFO - 2021-11-19 08:22:01 --> Security Class Initialized
DEBUG - 2021-11-19 08:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:22:01 --> Input Class Initialized
INFO - 2021-11-19 08:22:01 --> Language Class Initialized
INFO - 2021-11-19 08:22:01 --> Language Class Initialized
INFO - 2021-11-19 08:22:01 --> Config Class Initialized
INFO - 2021-11-19 08:22:01 --> Loader Class Initialized
INFO - 2021-11-19 08:22:01 --> Helper loaded: url_helper
INFO - 2021-11-19 08:22:01 --> Helper loaded: file_helper
INFO - 2021-11-19 08:22:01 --> Helper loaded: form_helper
INFO - 2021-11-19 08:22:01 --> Helper loaded: my_helper
INFO - 2021-11-19 08:22:01 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:22:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:22:01 --> Controller Class Initialized
DEBUG - 2021-11-19 08:22:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-11-19 08:22:01 --> Final output sent to browser
DEBUG - 2021-11-19 08:22:01 --> Total execution time: 0.1359
INFO - 2021-11-19 08:22:11 --> Config Class Initialized
INFO - 2021-11-19 08:22:11 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:22:11 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:22:11 --> Utf8 Class Initialized
INFO - 2021-11-19 08:22:11 --> URI Class Initialized
INFO - 2021-11-19 08:22:11 --> Router Class Initialized
INFO - 2021-11-19 08:22:11 --> Output Class Initialized
INFO - 2021-11-19 08:22:11 --> Security Class Initialized
DEBUG - 2021-11-19 08:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:22:11 --> Input Class Initialized
INFO - 2021-11-19 08:22:11 --> Language Class Initialized
INFO - 2021-11-19 08:22:11 --> Language Class Initialized
INFO - 2021-11-19 08:22:11 --> Config Class Initialized
INFO - 2021-11-19 08:22:11 --> Loader Class Initialized
INFO - 2021-11-19 08:22:11 --> Helper loaded: url_helper
INFO - 2021-11-19 08:22:11 --> Helper loaded: file_helper
INFO - 2021-11-19 08:22:11 --> Helper loaded: form_helper
INFO - 2021-11-19 08:22:11 --> Helper loaded: my_helper
INFO - 2021-11-19 08:22:11 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:22:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:22:11 --> Controller Class Initialized
DEBUG - 2021-11-19 08:22:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-11-19 08:22:12 --> Final output sent to browser
DEBUG - 2021-11-19 08:22:12 --> Total execution time: 0.1335
INFO - 2021-11-19 08:22:23 --> Config Class Initialized
INFO - 2021-11-19 08:22:23 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:22:23 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:22:23 --> Utf8 Class Initialized
INFO - 2021-11-19 08:22:23 --> URI Class Initialized
INFO - 2021-11-19 08:22:23 --> Router Class Initialized
INFO - 2021-11-19 08:22:23 --> Output Class Initialized
INFO - 2021-11-19 08:22:23 --> Security Class Initialized
DEBUG - 2021-11-19 08:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:22:23 --> Input Class Initialized
INFO - 2021-11-19 08:22:23 --> Language Class Initialized
INFO - 2021-11-19 08:22:23 --> Language Class Initialized
INFO - 2021-11-19 08:22:23 --> Config Class Initialized
INFO - 2021-11-19 08:22:23 --> Loader Class Initialized
INFO - 2021-11-19 08:22:23 --> Helper loaded: url_helper
INFO - 2021-11-19 08:22:23 --> Helper loaded: file_helper
INFO - 2021-11-19 08:22:23 --> Helper loaded: form_helper
INFO - 2021-11-19 08:22:23 --> Helper loaded: my_helper
INFO - 2021-11-19 08:22:23 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:22:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:22:23 --> Controller Class Initialized
DEBUG - 2021-11-19 08:22:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-11-19 08:22:23 --> Final output sent to browser
DEBUG - 2021-11-19 08:22:23 --> Total execution time: 0.1553
INFO - 2021-11-19 08:22:33 --> Config Class Initialized
INFO - 2021-11-19 08:22:33 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:22:33 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:22:33 --> Utf8 Class Initialized
INFO - 2021-11-19 08:22:33 --> URI Class Initialized
INFO - 2021-11-19 08:22:33 --> Router Class Initialized
INFO - 2021-11-19 08:22:33 --> Output Class Initialized
INFO - 2021-11-19 08:22:33 --> Security Class Initialized
DEBUG - 2021-11-19 08:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:22:33 --> Input Class Initialized
INFO - 2021-11-19 08:22:33 --> Language Class Initialized
INFO - 2021-11-19 08:22:33 --> Language Class Initialized
INFO - 2021-11-19 08:22:33 --> Config Class Initialized
INFO - 2021-11-19 08:22:33 --> Loader Class Initialized
INFO - 2021-11-19 08:22:33 --> Helper loaded: url_helper
INFO - 2021-11-19 08:22:33 --> Helper loaded: file_helper
INFO - 2021-11-19 08:22:33 --> Helper loaded: form_helper
INFO - 2021-11-19 08:22:33 --> Helper loaded: my_helper
INFO - 2021-11-19 08:22:33 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:22:33 --> Controller Class Initialized
DEBUG - 2021-11-19 08:22:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-11-19 08:22:33 --> Final output sent to browser
DEBUG - 2021-11-19 08:22:33 --> Total execution time: 0.1314
INFO - 2021-11-19 08:24:24 --> Config Class Initialized
INFO - 2021-11-19 08:24:24 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:24:24 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:24:24 --> Utf8 Class Initialized
INFO - 2021-11-19 08:24:24 --> URI Class Initialized
INFO - 2021-11-19 08:24:24 --> Router Class Initialized
INFO - 2021-11-19 08:24:24 --> Output Class Initialized
INFO - 2021-11-19 08:24:24 --> Security Class Initialized
DEBUG - 2021-11-19 08:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:24:24 --> Input Class Initialized
INFO - 2021-11-19 08:24:24 --> Language Class Initialized
INFO - 2021-11-19 08:24:24 --> Language Class Initialized
INFO - 2021-11-19 08:24:24 --> Config Class Initialized
INFO - 2021-11-19 08:24:24 --> Loader Class Initialized
INFO - 2021-11-19 08:24:24 --> Helper loaded: url_helper
INFO - 2021-11-19 08:24:24 --> Helper loaded: file_helper
INFO - 2021-11-19 08:24:24 --> Helper loaded: form_helper
INFO - 2021-11-19 08:24:24 --> Helper loaded: my_helper
INFO - 2021-11-19 08:24:24 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:24:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:24:24 --> Controller Class Initialized
DEBUG - 2021-11-19 08:24:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-11-19 08:24:24 --> Final output sent to browser
DEBUG - 2021-11-19 08:24:24 --> Total execution time: 0.1276
INFO - 2021-11-19 08:24:47 --> Config Class Initialized
INFO - 2021-11-19 08:24:47 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:24:47 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:24:47 --> Utf8 Class Initialized
INFO - 2021-11-19 08:24:47 --> URI Class Initialized
INFO - 2021-11-19 08:24:47 --> Router Class Initialized
INFO - 2021-11-19 08:24:47 --> Output Class Initialized
INFO - 2021-11-19 08:24:47 --> Security Class Initialized
DEBUG - 2021-11-19 08:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:24:47 --> Input Class Initialized
INFO - 2021-11-19 08:24:47 --> Language Class Initialized
INFO - 2021-11-19 08:24:47 --> Language Class Initialized
INFO - 2021-11-19 08:24:47 --> Config Class Initialized
INFO - 2021-11-19 08:24:47 --> Loader Class Initialized
INFO - 2021-11-19 08:24:47 --> Helper loaded: url_helper
INFO - 2021-11-19 08:24:47 --> Helper loaded: file_helper
INFO - 2021-11-19 08:24:47 --> Helper loaded: form_helper
INFO - 2021-11-19 08:24:47 --> Helper loaded: my_helper
INFO - 2021-11-19 08:24:47 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:24:47 --> Controller Class Initialized
DEBUG - 2021-11-19 08:24:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-11-19 08:24:47 --> Final output sent to browser
DEBUG - 2021-11-19 08:24:47 --> Total execution time: 0.1440
INFO - 2021-11-19 08:25:11 --> Config Class Initialized
INFO - 2021-11-19 08:25:11 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:25:11 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:25:11 --> Utf8 Class Initialized
INFO - 2021-11-19 08:25:11 --> URI Class Initialized
INFO - 2021-11-19 08:25:11 --> Router Class Initialized
INFO - 2021-11-19 08:25:11 --> Output Class Initialized
INFO - 2021-11-19 08:25:11 --> Security Class Initialized
DEBUG - 2021-11-19 08:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:25:11 --> Input Class Initialized
INFO - 2021-11-19 08:25:11 --> Language Class Initialized
INFO - 2021-11-19 08:25:11 --> Language Class Initialized
INFO - 2021-11-19 08:25:11 --> Config Class Initialized
INFO - 2021-11-19 08:25:11 --> Loader Class Initialized
INFO - 2021-11-19 08:25:11 --> Helper loaded: url_helper
INFO - 2021-11-19 08:25:11 --> Helper loaded: file_helper
INFO - 2021-11-19 08:25:11 --> Helper loaded: form_helper
INFO - 2021-11-19 08:25:11 --> Helper loaded: my_helper
INFO - 2021-11-19 08:25:11 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:25:11 --> Controller Class Initialized
DEBUG - 2021-11-19 08:25:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-11-19 08:25:11 --> Final output sent to browser
DEBUG - 2021-11-19 08:25:11 --> Total execution time: 0.1785
INFO - 2021-11-19 08:25:29 --> Config Class Initialized
INFO - 2021-11-19 08:25:29 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:25:29 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:25:29 --> Utf8 Class Initialized
INFO - 2021-11-19 08:25:29 --> URI Class Initialized
INFO - 2021-11-19 08:25:29 --> Router Class Initialized
INFO - 2021-11-19 08:25:29 --> Output Class Initialized
INFO - 2021-11-19 08:25:29 --> Security Class Initialized
DEBUG - 2021-11-19 08:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:25:29 --> Input Class Initialized
INFO - 2021-11-19 08:25:29 --> Language Class Initialized
INFO - 2021-11-19 08:25:29 --> Language Class Initialized
INFO - 2021-11-19 08:25:29 --> Config Class Initialized
INFO - 2021-11-19 08:25:29 --> Loader Class Initialized
INFO - 2021-11-19 08:25:29 --> Helper loaded: url_helper
INFO - 2021-11-19 08:25:29 --> Helper loaded: file_helper
INFO - 2021-11-19 08:25:29 --> Helper loaded: form_helper
INFO - 2021-11-19 08:25:29 --> Helper loaded: my_helper
INFO - 2021-11-19 08:25:29 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:25:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:25:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:25:29 --> Controller Class Initialized
DEBUG - 2021-11-19 08:25:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-11-19 08:25:29 --> Final output sent to browser
DEBUG - 2021-11-19 08:25:29 --> Total execution time: 0.1437
INFO - 2021-11-19 08:25:53 --> Config Class Initialized
INFO - 2021-11-19 08:25:53 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:25:53 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:25:53 --> Utf8 Class Initialized
INFO - 2021-11-19 08:25:53 --> URI Class Initialized
INFO - 2021-11-19 08:25:53 --> Router Class Initialized
INFO - 2021-11-19 08:25:53 --> Output Class Initialized
INFO - 2021-11-19 08:25:53 --> Security Class Initialized
DEBUG - 2021-11-19 08:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:25:53 --> Input Class Initialized
INFO - 2021-11-19 08:25:53 --> Language Class Initialized
INFO - 2021-11-19 08:25:53 --> Language Class Initialized
INFO - 2021-11-19 08:25:53 --> Config Class Initialized
INFO - 2021-11-19 08:25:53 --> Loader Class Initialized
INFO - 2021-11-19 08:25:53 --> Helper loaded: url_helper
INFO - 2021-11-19 08:25:53 --> Helper loaded: file_helper
INFO - 2021-11-19 08:25:53 --> Helper loaded: form_helper
INFO - 2021-11-19 08:25:53 --> Helper loaded: my_helper
INFO - 2021-11-19 08:25:53 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:25:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:25:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:25:53 --> Controller Class Initialized
DEBUG - 2021-11-19 08:25:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-11-19 08:25:53 --> Final output sent to browser
DEBUG - 2021-11-19 08:25:53 --> Total execution time: 0.1310
INFO - 2021-11-19 08:26:16 --> Config Class Initialized
INFO - 2021-11-19 08:26:16 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:26:16 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:26:16 --> Utf8 Class Initialized
INFO - 2021-11-19 08:26:16 --> URI Class Initialized
INFO - 2021-11-19 08:26:16 --> Router Class Initialized
INFO - 2021-11-19 08:26:16 --> Output Class Initialized
INFO - 2021-11-19 08:26:16 --> Security Class Initialized
DEBUG - 2021-11-19 08:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:26:16 --> Input Class Initialized
INFO - 2021-11-19 08:26:16 --> Language Class Initialized
INFO - 2021-11-19 08:26:16 --> Language Class Initialized
INFO - 2021-11-19 08:26:16 --> Config Class Initialized
INFO - 2021-11-19 08:26:16 --> Loader Class Initialized
INFO - 2021-11-19 08:26:16 --> Helper loaded: url_helper
INFO - 2021-11-19 08:26:16 --> Helper loaded: file_helper
INFO - 2021-11-19 08:26:16 --> Helper loaded: form_helper
INFO - 2021-11-19 08:26:16 --> Helper loaded: my_helper
INFO - 2021-11-19 08:26:16 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:26:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:26:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:26:16 --> Controller Class Initialized
DEBUG - 2021-11-19 08:26:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-11-19 08:26:16 --> Final output sent to browser
DEBUG - 2021-11-19 08:26:16 --> Total execution time: 0.1665
INFO - 2021-11-19 08:26:30 --> Config Class Initialized
INFO - 2021-11-19 08:26:30 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:26:30 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:26:30 --> Utf8 Class Initialized
INFO - 2021-11-19 08:26:30 --> URI Class Initialized
INFO - 2021-11-19 08:26:30 --> Router Class Initialized
INFO - 2021-11-19 08:26:30 --> Output Class Initialized
INFO - 2021-11-19 08:26:30 --> Security Class Initialized
DEBUG - 2021-11-19 08:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:26:30 --> Input Class Initialized
INFO - 2021-11-19 08:26:30 --> Language Class Initialized
INFO - 2021-11-19 08:26:30 --> Language Class Initialized
INFO - 2021-11-19 08:26:30 --> Config Class Initialized
INFO - 2021-11-19 08:26:30 --> Loader Class Initialized
INFO - 2021-11-19 08:26:30 --> Helper loaded: url_helper
INFO - 2021-11-19 08:26:30 --> Helper loaded: file_helper
INFO - 2021-11-19 08:26:30 --> Helper loaded: form_helper
INFO - 2021-11-19 08:26:30 --> Helper loaded: my_helper
INFO - 2021-11-19 08:26:30 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:26:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:26:30 --> Controller Class Initialized
INFO - 2021-11-19 08:26:30 --> Helper loaded: cookie_helper
INFO - 2021-11-19 08:26:30 --> Config Class Initialized
INFO - 2021-11-19 08:26:30 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:26:30 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:26:30 --> Utf8 Class Initialized
INFO - 2021-11-19 08:26:30 --> URI Class Initialized
INFO - 2021-11-19 08:26:30 --> Router Class Initialized
INFO - 2021-11-19 08:26:30 --> Output Class Initialized
INFO - 2021-11-19 08:26:30 --> Security Class Initialized
DEBUG - 2021-11-19 08:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:26:30 --> Input Class Initialized
INFO - 2021-11-19 08:26:30 --> Language Class Initialized
INFO - 2021-11-19 08:26:30 --> Language Class Initialized
INFO - 2021-11-19 08:26:30 --> Config Class Initialized
INFO - 2021-11-19 08:26:30 --> Loader Class Initialized
INFO - 2021-11-19 08:26:30 --> Helper loaded: url_helper
INFO - 2021-11-19 08:26:30 --> Helper loaded: file_helper
INFO - 2021-11-19 08:26:30 --> Helper loaded: form_helper
INFO - 2021-11-19 08:26:30 --> Helper loaded: my_helper
INFO - 2021-11-19 08:26:30 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:26:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:26:30 --> Controller Class Initialized
DEBUG - 2021-11-19 08:26:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-11-19 08:26:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 08:26:30 --> Final output sent to browser
DEBUG - 2021-11-19 08:26:30 --> Total execution time: 0.0520
INFO - 2021-11-19 08:26:33 --> Config Class Initialized
INFO - 2021-11-19 08:26:33 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:26:33 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:26:33 --> Utf8 Class Initialized
INFO - 2021-11-19 08:26:33 --> URI Class Initialized
INFO - 2021-11-19 08:26:33 --> Router Class Initialized
INFO - 2021-11-19 08:26:33 --> Output Class Initialized
INFO - 2021-11-19 08:26:33 --> Security Class Initialized
DEBUG - 2021-11-19 08:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:26:33 --> Input Class Initialized
INFO - 2021-11-19 08:26:33 --> Language Class Initialized
INFO - 2021-11-19 08:26:33 --> Language Class Initialized
INFO - 2021-11-19 08:26:33 --> Config Class Initialized
INFO - 2021-11-19 08:26:33 --> Loader Class Initialized
INFO - 2021-11-19 08:26:33 --> Helper loaded: url_helper
INFO - 2021-11-19 08:26:33 --> Helper loaded: file_helper
INFO - 2021-11-19 08:26:33 --> Helper loaded: form_helper
INFO - 2021-11-19 08:26:33 --> Helper loaded: my_helper
INFO - 2021-11-19 08:26:33 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:26:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:26:33 --> Controller Class Initialized
INFO - 2021-11-19 08:26:33 --> Helper loaded: cookie_helper
INFO - 2021-11-19 08:26:33 --> Final output sent to browser
DEBUG - 2021-11-19 08:26:33 --> Total execution time: 0.1015
INFO - 2021-11-19 08:26:33 --> Config Class Initialized
INFO - 2021-11-19 08:26:33 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:26:33 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:26:33 --> Utf8 Class Initialized
INFO - 2021-11-19 08:26:33 --> URI Class Initialized
INFO - 2021-11-19 08:26:33 --> Router Class Initialized
INFO - 2021-11-19 08:26:33 --> Output Class Initialized
INFO - 2021-11-19 08:26:33 --> Security Class Initialized
DEBUG - 2021-11-19 08:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:26:33 --> Input Class Initialized
INFO - 2021-11-19 08:26:33 --> Language Class Initialized
INFO - 2021-11-19 08:26:33 --> Language Class Initialized
INFO - 2021-11-19 08:26:33 --> Config Class Initialized
INFO - 2021-11-19 08:26:33 --> Loader Class Initialized
INFO - 2021-11-19 08:26:33 --> Helper loaded: url_helper
INFO - 2021-11-19 08:26:33 --> Helper loaded: file_helper
INFO - 2021-11-19 08:26:33 --> Helper loaded: form_helper
INFO - 2021-11-19 08:26:33 --> Helper loaded: my_helper
INFO - 2021-11-19 08:26:33 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:26:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:26:33 --> Controller Class Initialized
DEBUG - 2021-11-19 08:26:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-11-19 08:26:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 08:26:34 --> Final output sent to browser
DEBUG - 2021-11-19 08:26:34 --> Total execution time: 1.0194
INFO - 2021-11-19 08:26:36 --> Config Class Initialized
INFO - 2021-11-19 08:26:36 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:26:36 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:26:36 --> Utf8 Class Initialized
INFO - 2021-11-19 08:26:36 --> URI Class Initialized
INFO - 2021-11-19 08:26:36 --> Router Class Initialized
INFO - 2021-11-19 08:26:36 --> Output Class Initialized
INFO - 2021-11-19 08:26:36 --> Security Class Initialized
DEBUG - 2021-11-19 08:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:26:36 --> Input Class Initialized
INFO - 2021-11-19 08:26:36 --> Language Class Initialized
INFO - 2021-11-19 08:26:36 --> Language Class Initialized
INFO - 2021-11-19 08:26:36 --> Config Class Initialized
INFO - 2021-11-19 08:26:36 --> Loader Class Initialized
INFO - 2021-11-19 08:26:36 --> Helper loaded: url_helper
INFO - 2021-11-19 08:26:36 --> Helper loaded: file_helper
INFO - 2021-11-19 08:26:36 --> Helper loaded: form_helper
INFO - 2021-11-19 08:26:36 --> Helper loaded: my_helper
INFO - 2021-11-19 08:26:36 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:26:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:26:36 --> Controller Class Initialized
DEBUG - 2021-11-19 08:26:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-11-19 08:26:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 08:26:36 --> Final output sent to browser
DEBUG - 2021-11-19 08:26:36 --> Total execution time: 0.0923
INFO - 2021-11-19 08:26:37 --> Config Class Initialized
INFO - 2021-11-19 08:26:37 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:26:37 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:26:37 --> Utf8 Class Initialized
INFO - 2021-11-19 08:26:37 --> URI Class Initialized
INFO - 2021-11-19 08:26:37 --> Router Class Initialized
INFO - 2021-11-19 08:26:37 --> Output Class Initialized
INFO - 2021-11-19 08:26:37 --> Security Class Initialized
DEBUG - 2021-11-19 08:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:26:37 --> Input Class Initialized
INFO - 2021-11-19 08:26:37 --> Language Class Initialized
INFO - 2021-11-19 08:26:37 --> Language Class Initialized
INFO - 2021-11-19 08:26:37 --> Config Class Initialized
INFO - 2021-11-19 08:26:37 --> Loader Class Initialized
INFO - 2021-11-19 08:26:37 --> Helper loaded: url_helper
INFO - 2021-11-19 08:26:37 --> Helper loaded: file_helper
INFO - 2021-11-19 08:26:37 --> Helper loaded: form_helper
INFO - 2021-11-19 08:26:37 --> Helper loaded: my_helper
INFO - 2021-11-19 08:26:37 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:26:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:26:37 --> Controller Class Initialized
DEBUG - 2021-11-19 08:26:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-19 08:26:37 --> Final output sent to browser
DEBUG - 2021-11-19 08:26:37 --> Total execution time: 0.2368
INFO - 2021-11-19 08:26:50 --> Config Class Initialized
INFO - 2021-11-19 08:26:50 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:26:50 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:26:50 --> Utf8 Class Initialized
INFO - 2021-11-19 08:26:50 --> URI Class Initialized
INFO - 2021-11-19 08:26:50 --> Router Class Initialized
INFO - 2021-11-19 08:26:50 --> Output Class Initialized
INFO - 2021-11-19 08:26:50 --> Security Class Initialized
DEBUG - 2021-11-19 08:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:26:50 --> Input Class Initialized
INFO - 2021-11-19 08:26:50 --> Language Class Initialized
INFO - 2021-11-19 08:26:50 --> Language Class Initialized
INFO - 2021-11-19 08:26:50 --> Config Class Initialized
INFO - 2021-11-19 08:26:50 --> Loader Class Initialized
INFO - 2021-11-19 08:26:50 --> Helper loaded: url_helper
INFO - 2021-11-19 08:26:50 --> Helper loaded: file_helper
INFO - 2021-11-19 08:26:50 --> Helper loaded: form_helper
INFO - 2021-11-19 08:26:50 --> Helper loaded: my_helper
INFO - 2021-11-19 08:26:50 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:26:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:26:50 --> Controller Class Initialized
INFO - 2021-11-19 08:26:50 --> Helper loaded: cookie_helper
INFO - 2021-11-19 08:26:50 --> Config Class Initialized
INFO - 2021-11-19 08:26:50 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:26:50 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:26:50 --> Utf8 Class Initialized
INFO - 2021-11-19 08:26:50 --> URI Class Initialized
INFO - 2021-11-19 08:26:50 --> Router Class Initialized
INFO - 2021-11-19 08:26:50 --> Output Class Initialized
INFO - 2021-11-19 08:26:50 --> Security Class Initialized
DEBUG - 2021-11-19 08:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:26:50 --> Input Class Initialized
INFO - 2021-11-19 08:26:50 --> Language Class Initialized
INFO - 2021-11-19 08:26:50 --> Language Class Initialized
INFO - 2021-11-19 08:26:50 --> Config Class Initialized
INFO - 2021-11-19 08:26:50 --> Loader Class Initialized
INFO - 2021-11-19 08:26:50 --> Helper loaded: url_helper
INFO - 2021-11-19 08:26:50 --> Helper loaded: file_helper
INFO - 2021-11-19 08:26:50 --> Helper loaded: form_helper
INFO - 2021-11-19 08:26:50 --> Helper loaded: my_helper
INFO - 2021-11-19 08:26:50 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:26:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:26:50 --> Controller Class Initialized
DEBUG - 2021-11-19 08:26:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-11-19 08:26:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 08:26:50 --> Final output sent to browser
DEBUG - 2021-11-19 08:26:50 --> Total execution time: 0.0876
INFO - 2021-11-19 08:26:55 --> Config Class Initialized
INFO - 2021-11-19 08:26:55 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:26:55 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:26:55 --> Utf8 Class Initialized
INFO - 2021-11-19 08:26:55 --> URI Class Initialized
INFO - 2021-11-19 08:26:55 --> Router Class Initialized
INFO - 2021-11-19 08:26:55 --> Output Class Initialized
INFO - 2021-11-19 08:26:55 --> Security Class Initialized
DEBUG - 2021-11-19 08:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:26:55 --> Input Class Initialized
INFO - 2021-11-19 08:26:55 --> Language Class Initialized
INFO - 2021-11-19 08:26:55 --> Language Class Initialized
INFO - 2021-11-19 08:26:55 --> Config Class Initialized
INFO - 2021-11-19 08:26:55 --> Loader Class Initialized
INFO - 2021-11-19 08:26:55 --> Helper loaded: url_helper
INFO - 2021-11-19 08:26:55 --> Helper loaded: file_helper
INFO - 2021-11-19 08:26:55 --> Helper loaded: form_helper
INFO - 2021-11-19 08:26:55 --> Helper loaded: my_helper
INFO - 2021-11-19 08:26:55 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:26:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:26:55 --> Controller Class Initialized
INFO - 2021-11-19 08:26:55 --> Helper loaded: cookie_helper
INFO - 2021-11-19 08:26:55 --> Final output sent to browser
DEBUG - 2021-11-19 08:26:55 --> Total execution time: 0.0739
INFO - 2021-11-19 08:26:56 --> Config Class Initialized
INFO - 2021-11-19 08:26:56 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:26:56 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:26:56 --> Utf8 Class Initialized
INFO - 2021-11-19 08:26:56 --> URI Class Initialized
INFO - 2021-11-19 08:26:56 --> Router Class Initialized
INFO - 2021-11-19 08:26:56 --> Output Class Initialized
INFO - 2021-11-19 08:26:56 --> Security Class Initialized
DEBUG - 2021-11-19 08:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:26:56 --> Input Class Initialized
INFO - 2021-11-19 08:26:56 --> Language Class Initialized
INFO - 2021-11-19 08:26:56 --> Language Class Initialized
INFO - 2021-11-19 08:26:56 --> Config Class Initialized
INFO - 2021-11-19 08:26:56 --> Loader Class Initialized
INFO - 2021-11-19 08:26:56 --> Helper loaded: url_helper
INFO - 2021-11-19 08:26:56 --> Helper loaded: file_helper
INFO - 2021-11-19 08:26:56 --> Helper loaded: form_helper
INFO - 2021-11-19 08:26:56 --> Helper loaded: my_helper
INFO - 2021-11-19 08:26:56 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:26:56 --> Controller Class Initialized
DEBUG - 2021-11-19 08:26:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-11-19 08:26:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 08:26:57 --> Final output sent to browser
DEBUG - 2021-11-19 08:26:57 --> Total execution time: 1.1030
INFO - 2021-11-19 08:27:00 --> Config Class Initialized
INFO - 2021-11-19 08:27:00 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:27:00 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:27:00 --> Utf8 Class Initialized
INFO - 2021-11-19 08:27:00 --> URI Class Initialized
INFO - 2021-11-19 08:27:00 --> Router Class Initialized
INFO - 2021-11-19 08:27:00 --> Output Class Initialized
INFO - 2021-11-19 08:27:00 --> Security Class Initialized
DEBUG - 2021-11-19 08:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:27:00 --> Input Class Initialized
INFO - 2021-11-19 08:27:00 --> Language Class Initialized
INFO - 2021-11-19 08:27:00 --> Language Class Initialized
INFO - 2021-11-19 08:27:00 --> Config Class Initialized
INFO - 2021-11-19 08:27:00 --> Loader Class Initialized
INFO - 2021-11-19 08:27:00 --> Helper loaded: url_helper
INFO - 2021-11-19 08:27:00 --> Helper loaded: file_helper
INFO - 2021-11-19 08:27:00 --> Helper loaded: form_helper
INFO - 2021-11-19 08:27:00 --> Helper loaded: my_helper
INFO - 2021-11-19 08:27:00 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:27:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:27:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:27:00 --> Controller Class Initialized
DEBUG - 2021-11-19 08:27:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-11-19 08:27:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 08:27:00 --> Final output sent to browser
DEBUG - 2021-11-19 08:27:00 --> Total execution time: 0.1012
INFO - 2021-11-19 08:27:01 --> Config Class Initialized
INFO - 2021-11-19 08:27:01 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:27:01 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:27:01 --> Utf8 Class Initialized
INFO - 2021-11-19 08:27:01 --> URI Class Initialized
INFO - 2021-11-19 08:27:01 --> Router Class Initialized
INFO - 2021-11-19 08:27:01 --> Output Class Initialized
INFO - 2021-11-19 08:27:01 --> Security Class Initialized
DEBUG - 2021-11-19 08:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:27:01 --> Input Class Initialized
INFO - 2021-11-19 08:27:01 --> Language Class Initialized
INFO - 2021-11-19 08:27:01 --> Language Class Initialized
INFO - 2021-11-19 08:27:01 --> Config Class Initialized
INFO - 2021-11-19 08:27:01 --> Loader Class Initialized
INFO - 2021-11-19 08:27:01 --> Helper loaded: url_helper
INFO - 2021-11-19 08:27:01 --> Helper loaded: file_helper
INFO - 2021-11-19 08:27:01 --> Helper loaded: form_helper
INFO - 2021-11-19 08:27:01 --> Helper loaded: my_helper
INFO - 2021-11-19 08:27:02 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:27:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:27:02 --> Controller Class Initialized
DEBUG - 2021-11-19 08:27:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2021-11-19 08:27:02 --> Final output sent to browser
DEBUG - 2021-11-19 08:27:02 --> Total execution time: 0.2111
INFO - 2021-11-19 08:27:52 --> Config Class Initialized
INFO - 2021-11-19 08:27:52 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:27:52 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:27:52 --> Utf8 Class Initialized
INFO - 2021-11-19 08:27:52 --> URI Class Initialized
INFO - 2021-11-19 08:27:52 --> Router Class Initialized
INFO - 2021-11-19 08:27:52 --> Output Class Initialized
INFO - 2021-11-19 08:27:52 --> Security Class Initialized
DEBUG - 2021-11-19 08:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:27:52 --> Input Class Initialized
INFO - 2021-11-19 08:27:52 --> Language Class Initialized
INFO - 2021-11-19 08:27:52 --> Language Class Initialized
INFO - 2021-11-19 08:27:52 --> Config Class Initialized
INFO - 2021-11-19 08:27:52 --> Loader Class Initialized
INFO - 2021-11-19 08:27:52 --> Helper loaded: url_helper
INFO - 2021-11-19 08:27:52 --> Helper loaded: file_helper
INFO - 2021-11-19 08:27:52 --> Helper loaded: form_helper
INFO - 2021-11-19 08:27:52 --> Helper loaded: my_helper
INFO - 2021-11-19 08:27:52 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:27:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:27:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:27:52 --> Controller Class Initialized
DEBUG - 2021-11-19 08:27:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2021-11-19 08:27:52 --> Final output sent to browser
DEBUG - 2021-11-19 08:27:52 --> Total execution time: 0.1634
INFO - 2021-11-19 08:28:47 --> Config Class Initialized
INFO - 2021-11-19 08:28:47 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:28:47 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:28:47 --> Utf8 Class Initialized
INFO - 2021-11-19 08:28:47 --> URI Class Initialized
INFO - 2021-11-19 08:28:47 --> Router Class Initialized
INFO - 2021-11-19 08:28:47 --> Output Class Initialized
INFO - 2021-11-19 08:28:47 --> Security Class Initialized
DEBUG - 2021-11-19 08:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:28:47 --> Input Class Initialized
INFO - 2021-11-19 08:28:47 --> Language Class Initialized
INFO - 2021-11-19 08:28:47 --> Language Class Initialized
INFO - 2021-11-19 08:28:47 --> Config Class Initialized
INFO - 2021-11-19 08:28:47 --> Loader Class Initialized
INFO - 2021-11-19 08:28:47 --> Helper loaded: url_helper
INFO - 2021-11-19 08:28:47 --> Helper loaded: file_helper
INFO - 2021-11-19 08:28:47 --> Helper loaded: form_helper
INFO - 2021-11-19 08:28:47 --> Helper loaded: my_helper
INFO - 2021-11-19 08:28:48 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:28:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:28:48 --> Controller Class Initialized
DEBUG - 2021-11-19 08:28:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2021-11-19 08:28:48 --> Final output sent to browser
DEBUG - 2021-11-19 08:28:48 --> Total execution time: 0.1511
INFO - 2021-11-19 08:29:35 --> Config Class Initialized
INFO - 2021-11-19 08:29:35 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:29:35 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:29:35 --> Utf8 Class Initialized
INFO - 2021-11-19 08:29:35 --> URI Class Initialized
INFO - 2021-11-19 08:29:35 --> Router Class Initialized
INFO - 2021-11-19 08:29:35 --> Output Class Initialized
INFO - 2021-11-19 08:29:35 --> Security Class Initialized
DEBUG - 2021-11-19 08:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:29:35 --> Input Class Initialized
INFO - 2021-11-19 08:29:35 --> Language Class Initialized
INFO - 2021-11-19 08:29:35 --> Language Class Initialized
INFO - 2021-11-19 08:29:35 --> Config Class Initialized
INFO - 2021-11-19 08:29:35 --> Loader Class Initialized
INFO - 2021-11-19 08:29:35 --> Helper loaded: url_helper
INFO - 2021-11-19 08:29:35 --> Helper loaded: file_helper
INFO - 2021-11-19 08:29:35 --> Helper loaded: form_helper
INFO - 2021-11-19 08:29:35 --> Helper loaded: my_helper
INFO - 2021-11-19 08:29:35 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:29:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:29:35 --> Controller Class Initialized
DEBUG - 2021-11-19 08:29:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2021-11-19 08:29:35 --> Final output sent to browser
DEBUG - 2021-11-19 08:29:35 --> Total execution time: 0.1501
INFO - 2021-11-19 08:29:49 --> Config Class Initialized
INFO - 2021-11-19 08:29:49 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:29:49 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:29:49 --> Utf8 Class Initialized
INFO - 2021-11-19 08:29:49 --> URI Class Initialized
INFO - 2021-11-19 08:29:49 --> Router Class Initialized
INFO - 2021-11-19 08:29:49 --> Output Class Initialized
INFO - 2021-11-19 08:29:49 --> Security Class Initialized
DEBUG - 2021-11-19 08:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:29:49 --> Input Class Initialized
INFO - 2021-11-19 08:29:49 --> Language Class Initialized
INFO - 2021-11-19 08:29:49 --> Language Class Initialized
INFO - 2021-11-19 08:29:49 --> Config Class Initialized
INFO - 2021-11-19 08:29:49 --> Loader Class Initialized
INFO - 2021-11-19 08:29:49 --> Helper loaded: url_helper
INFO - 2021-11-19 08:29:49 --> Helper loaded: file_helper
INFO - 2021-11-19 08:29:49 --> Helper loaded: form_helper
INFO - 2021-11-19 08:29:49 --> Helper loaded: my_helper
INFO - 2021-11-19 08:29:49 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:29:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:29:49 --> Controller Class Initialized
DEBUG - 2021-11-19 08:29:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2021-11-19 08:29:49 --> Final output sent to browser
DEBUG - 2021-11-19 08:29:49 --> Total execution time: 0.1417
INFO - 2021-11-19 08:30:19 --> Config Class Initialized
INFO - 2021-11-19 08:30:19 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:30:19 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:30:19 --> Utf8 Class Initialized
INFO - 2021-11-19 08:30:19 --> URI Class Initialized
INFO - 2021-11-19 08:30:19 --> Router Class Initialized
INFO - 2021-11-19 08:30:19 --> Output Class Initialized
INFO - 2021-11-19 08:30:19 --> Security Class Initialized
DEBUG - 2021-11-19 08:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:30:19 --> Input Class Initialized
INFO - 2021-11-19 08:30:19 --> Language Class Initialized
INFO - 2021-11-19 08:30:19 --> Language Class Initialized
INFO - 2021-11-19 08:30:19 --> Config Class Initialized
INFO - 2021-11-19 08:30:19 --> Loader Class Initialized
INFO - 2021-11-19 08:30:19 --> Helper loaded: url_helper
INFO - 2021-11-19 08:30:19 --> Helper loaded: file_helper
INFO - 2021-11-19 08:30:19 --> Helper loaded: form_helper
INFO - 2021-11-19 08:30:19 --> Helper loaded: my_helper
INFO - 2021-11-19 08:30:19 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:30:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:30:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:30:19 --> Controller Class Initialized
INFO - 2021-11-19 08:30:19 --> Helper loaded: cookie_helper
INFO - 2021-11-19 08:30:19 --> Config Class Initialized
INFO - 2021-11-19 08:30:19 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:30:19 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:30:19 --> Utf8 Class Initialized
INFO - 2021-11-19 08:30:19 --> URI Class Initialized
INFO - 2021-11-19 08:30:19 --> Router Class Initialized
INFO - 2021-11-19 08:30:19 --> Output Class Initialized
INFO - 2021-11-19 08:30:19 --> Security Class Initialized
DEBUG - 2021-11-19 08:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:30:19 --> Input Class Initialized
INFO - 2021-11-19 08:30:19 --> Language Class Initialized
INFO - 2021-11-19 08:30:19 --> Language Class Initialized
INFO - 2021-11-19 08:30:19 --> Config Class Initialized
INFO - 2021-11-19 08:30:19 --> Loader Class Initialized
INFO - 2021-11-19 08:30:19 --> Helper loaded: url_helper
INFO - 2021-11-19 08:30:19 --> Helper loaded: file_helper
INFO - 2021-11-19 08:30:19 --> Helper loaded: form_helper
INFO - 2021-11-19 08:30:19 --> Helper loaded: my_helper
INFO - 2021-11-19 08:30:20 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:30:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:30:20 --> Controller Class Initialized
DEBUG - 2021-11-19 08:30:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-11-19 08:30:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 08:30:20 --> Final output sent to browser
DEBUG - 2021-11-19 08:30:20 --> Total execution time: 0.0621
INFO - 2021-11-19 08:30:51 --> Config Class Initialized
INFO - 2021-11-19 08:30:51 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:30:51 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:30:51 --> Utf8 Class Initialized
INFO - 2021-11-19 08:30:51 --> URI Class Initialized
INFO - 2021-11-19 08:30:51 --> Router Class Initialized
INFO - 2021-11-19 08:30:51 --> Output Class Initialized
INFO - 2021-11-19 08:30:51 --> Security Class Initialized
DEBUG - 2021-11-19 08:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:30:51 --> Input Class Initialized
INFO - 2021-11-19 08:30:51 --> Language Class Initialized
INFO - 2021-11-19 08:30:51 --> Language Class Initialized
INFO - 2021-11-19 08:30:51 --> Config Class Initialized
INFO - 2021-11-19 08:30:51 --> Loader Class Initialized
INFO - 2021-11-19 08:30:51 --> Helper loaded: url_helper
INFO - 2021-11-19 08:30:51 --> Helper loaded: file_helper
INFO - 2021-11-19 08:30:51 --> Helper loaded: form_helper
INFO - 2021-11-19 08:30:51 --> Helper loaded: my_helper
INFO - 2021-11-19 08:30:51 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:30:51 --> Controller Class Initialized
INFO - 2021-11-19 08:30:51 --> Helper loaded: cookie_helper
INFO - 2021-11-19 08:30:51 --> Final output sent to browser
DEBUG - 2021-11-19 08:30:51 --> Total execution time: 0.0857
INFO - 2021-11-19 08:30:51 --> Config Class Initialized
INFO - 2021-11-19 08:30:51 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:30:51 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:30:51 --> Utf8 Class Initialized
INFO - 2021-11-19 08:30:51 --> URI Class Initialized
INFO - 2021-11-19 08:30:51 --> Router Class Initialized
INFO - 2021-11-19 08:30:51 --> Output Class Initialized
INFO - 2021-11-19 08:30:51 --> Security Class Initialized
DEBUG - 2021-11-19 08:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:30:51 --> Input Class Initialized
INFO - 2021-11-19 08:30:51 --> Language Class Initialized
INFO - 2021-11-19 08:30:51 --> Language Class Initialized
INFO - 2021-11-19 08:30:51 --> Config Class Initialized
INFO - 2021-11-19 08:30:51 --> Loader Class Initialized
INFO - 2021-11-19 08:30:51 --> Helper loaded: url_helper
INFO - 2021-11-19 08:30:51 --> Helper loaded: file_helper
INFO - 2021-11-19 08:30:51 --> Helper loaded: form_helper
INFO - 2021-11-19 08:30:51 --> Helper loaded: my_helper
INFO - 2021-11-19 08:30:51 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:30:51 --> Controller Class Initialized
DEBUG - 2021-11-19 08:30:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-11-19 08:30:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 08:30:52 --> Final output sent to browser
DEBUG - 2021-11-19 08:30:52 --> Total execution time: 1.1257
INFO - 2021-11-19 08:30:57 --> Config Class Initialized
INFO - 2021-11-19 08:30:57 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:30:57 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:30:57 --> Utf8 Class Initialized
INFO - 2021-11-19 08:30:57 --> URI Class Initialized
INFO - 2021-11-19 08:30:57 --> Router Class Initialized
INFO - 2021-11-19 08:30:57 --> Output Class Initialized
INFO - 2021-11-19 08:30:57 --> Security Class Initialized
DEBUG - 2021-11-19 08:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:30:57 --> Input Class Initialized
INFO - 2021-11-19 08:30:57 --> Language Class Initialized
INFO - 2021-11-19 08:30:57 --> Language Class Initialized
INFO - 2021-11-19 08:30:57 --> Config Class Initialized
INFO - 2021-11-19 08:30:57 --> Loader Class Initialized
INFO - 2021-11-19 08:30:57 --> Helper loaded: url_helper
INFO - 2021-11-19 08:30:57 --> Helper loaded: file_helper
INFO - 2021-11-19 08:30:57 --> Helper loaded: form_helper
INFO - 2021-11-19 08:30:57 --> Helper loaded: my_helper
INFO - 2021-11-19 08:30:57 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:30:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:30:57 --> Controller Class Initialized
DEBUG - 2021-11-19 08:30:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-11-19 08:30:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 08:30:57 --> Final output sent to browser
DEBUG - 2021-11-19 08:30:57 --> Total execution time: 0.1000
INFO - 2021-11-19 08:31:05 --> Config Class Initialized
INFO - 2021-11-19 08:31:05 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:31:05 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:31:05 --> Utf8 Class Initialized
INFO - 2021-11-19 08:31:05 --> URI Class Initialized
INFO - 2021-11-19 08:31:05 --> Router Class Initialized
INFO - 2021-11-19 08:31:05 --> Output Class Initialized
INFO - 2021-11-19 08:31:05 --> Security Class Initialized
DEBUG - 2021-11-19 08:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:31:05 --> Input Class Initialized
INFO - 2021-11-19 08:31:05 --> Language Class Initialized
INFO - 2021-11-19 08:31:05 --> Language Class Initialized
INFO - 2021-11-19 08:31:05 --> Config Class Initialized
INFO - 2021-11-19 08:31:05 --> Loader Class Initialized
INFO - 2021-11-19 08:31:05 --> Helper loaded: url_helper
INFO - 2021-11-19 08:31:05 --> Helper loaded: file_helper
INFO - 2021-11-19 08:31:05 --> Helper loaded: form_helper
INFO - 2021-11-19 08:31:05 --> Helper loaded: my_helper
INFO - 2021-11-19 08:31:05 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:31:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:31:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:31:06 --> Controller Class Initialized
INFO - 2021-11-19 08:31:06 --> Helper loaded: cookie_helper
INFO - 2021-11-19 08:31:06 --> Config Class Initialized
INFO - 2021-11-19 08:31:06 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:31:06 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:31:06 --> Utf8 Class Initialized
INFO - 2021-11-19 08:31:06 --> URI Class Initialized
INFO - 2021-11-19 08:31:06 --> Router Class Initialized
INFO - 2021-11-19 08:31:06 --> Output Class Initialized
INFO - 2021-11-19 08:31:06 --> Security Class Initialized
DEBUG - 2021-11-19 08:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:31:06 --> Input Class Initialized
INFO - 2021-11-19 08:31:06 --> Language Class Initialized
INFO - 2021-11-19 08:31:06 --> Language Class Initialized
INFO - 2021-11-19 08:31:06 --> Config Class Initialized
INFO - 2021-11-19 08:31:06 --> Loader Class Initialized
INFO - 2021-11-19 08:31:06 --> Helper loaded: url_helper
INFO - 2021-11-19 08:31:06 --> Helper loaded: file_helper
INFO - 2021-11-19 08:31:06 --> Helper loaded: form_helper
INFO - 2021-11-19 08:31:06 --> Helper loaded: my_helper
INFO - 2021-11-19 08:31:06 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:31:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:31:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:31:06 --> Controller Class Initialized
DEBUG - 2021-11-19 08:31:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-11-19 08:31:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 08:31:06 --> Final output sent to browser
DEBUG - 2021-11-19 08:31:06 --> Total execution time: 0.0677
INFO - 2021-11-19 08:31:13 --> Config Class Initialized
INFO - 2021-11-19 08:31:13 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:31:13 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:31:13 --> Utf8 Class Initialized
INFO - 2021-11-19 08:31:13 --> URI Class Initialized
INFO - 2021-11-19 08:31:13 --> Router Class Initialized
INFO - 2021-11-19 08:31:13 --> Output Class Initialized
INFO - 2021-11-19 08:31:13 --> Security Class Initialized
DEBUG - 2021-11-19 08:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:31:13 --> Input Class Initialized
INFO - 2021-11-19 08:31:13 --> Language Class Initialized
INFO - 2021-11-19 08:31:13 --> Language Class Initialized
INFO - 2021-11-19 08:31:13 --> Config Class Initialized
INFO - 2021-11-19 08:31:13 --> Loader Class Initialized
INFO - 2021-11-19 08:31:13 --> Helper loaded: url_helper
INFO - 2021-11-19 08:31:13 --> Helper loaded: file_helper
INFO - 2021-11-19 08:31:13 --> Helper loaded: form_helper
INFO - 2021-11-19 08:31:13 --> Helper loaded: my_helper
INFO - 2021-11-19 08:31:13 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:31:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:31:13 --> Controller Class Initialized
INFO - 2021-11-19 08:31:13 --> Helper loaded: cookie_helper
INFO - 2021-11-19 08:31:13 --> Final output sent to browser
DEBUG - 2021-11-19 08:31:13 --> Total execution time: 0.0880
INFO - 2021-11-19 08:31:13 --> Config Class Initialized
INFO - 2021-11-19 08:31:13 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:31:13 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:31:13 --> Utf8 Class Initialized
INFO - 2021-11-19 08:31:13 --> URI Class Initialized
INFO - 2021-11-19 08:31:13 --> Router Class Initialized
INFO - 2021-11-19 08:31:13 --> Output Class Initialized
INFO - 2021-11-19 08:31:13 --> Security Class Initialized
DEBUG - 2021-11-19 08:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:31:13 --> Input Class Initialized
INFO - 2021-11-19 08:31:13 --> Language Class Initialized
INFO - 2021-11-19 08:31:13 --> Language Class Initialized
INFO - 2021-11-19 08:31:13 --> Config Class Initialized
INFO - 2021-11-19 08:31:13 --> Loader Class Initialized
INFO - 2021-11-19 08:31:13 --> Helper loaded: url_helper
INFO - 2021-11-19 08:31:13 --> Helper loaded: file_helper
INFO - 2021-11-19 08:31:13 --> Helper loaded: form_helper
INFO - 2021-11-19 08:31:13 --> Helper loaded: my_helper
INFO - 2021-11-19 08:31:13 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:31:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:31:13 --> Controller Class Initialized
DEBUG - 2021-11-19 08:31:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-11-19 08:31:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 08:31:14 --> Final output sent to browser
DEBUG - 2021-11-19 08:31:14 --> Total execution time: 1.0183
INFO - 2021-11-19 08:31:16 --> Config Class Initialized
INFO - 2021-11-19 08:31:16 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:31:16 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:31:16 --> Utf8 Class Initialized
INFO - 2021-11-19 08:31:16 --> URI Class Initialized
INFO - 2021-11-19 08:31:16 --> Router Class Initialized
INFO - 2021-11-19 08:31:16 --> Output Class Initialized
INFO - 2021-11-19 08:31:16 --> Security Class Initialized
DEBUG - 2021-11-19 08:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:31:16 --> Input Class Initialized
INFO - 2021-11-19 08:31:16 --> Language Class Initialized
INFO - 2021-11-19 08:31:16 --> Language Class Initialized
INFO - 2021-11-19 08:31:16 --> Config Class Initialized
INFO - 2021-11-19 08:31:16 --> Loader Class Initialized
INFO - 2021-11-19 08:31:16 --> Helper loaded: url_helper
INFO - 2021-11-19 08:31:16 --> Helper loaded: file_helper
INFO - 2021-11-19 08:31:16 --> Helper loaded: form_helper
INFO - 2021-11-19 08:31:16 --> Helper loaded: my_helper
INFO - 2021-11-19 08:31:16 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:31:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:31:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:31:16 --> Controller Class Initialized
DEBUG - 2021-11-19 08:31:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-11-19 08:31:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 08:31:16 --> Final output sent to browser
DEBUG - 2021-11-19 08:31:16 --> Total execution time: 0.0740
INFO - 2021-11-19 08:31:23 --> Config Class Initialized
INFO - 2021-11-19 08:31:23 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:31:23 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:31:23 --> Utf8 Class Initialized
INFO - 2021-11-19 08:31:23 --> URI Class Initialized
DEBUG - 2021-11-19 08:31:23 --> No URI present. Default controller set.
INFO - 2021-11-19 08:31:23 --> Router Class Initialized
INFO - 2021-11-19 08:31:23 --> Output Class Initialized
INFO - 2021-11-19 08:31:23 --> Security Class Initialized
DEBUG - 2021-11-19 08:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:31:23 --> Input Class Initialized
INFO - 2021-11-19 08:31:23 --> Language Class Initialized
INFO - 2021-11-19 08:31:23 --> Language Class Initialized
INFO - 2021-11-19 08:31:23 --> Config Class Initialized
INFO - 2021-11-19 08:31:23 --> Loader Class Initialized
INFO - 2021-11-19 08:31:23 --> Helper loaded: url_helper
INFO - 2021-11-19 08:31:23 --> Helper loaded: file_helper
INFO - 2021-11-19 08:31:23 --> Helper loaded: form_helper
INFO - 2021-11-19 08:31:23 --> Helper loaded: my_helper
INFO - 2021-11-19 08:31:23 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:31:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:31:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:31:23 --> Controller Class Initialized
DEBUG - 2021-11-19 08:31:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-11-19 08:31:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 08:31:24 --> Final output sent to browser
DEBUG - 2021-11-19 08:31:24 --> Total execution time: 0.9022
INFO - 2021-11-19 08:31:28 --> Config Class Initialized
INFO - 2021-11-19 08:31:28 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:31:28 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:31:28 --> Utf8 Class Initialized
INFO - 2021-11-19 08:31:28 --> URI Class Initialized
INFO - 2021-11-19 08:31:28 --> Router Class Initialized
INFO - 2021-11-19 08:31:28 --> Output Class Initialized
INFO - 2021-11-19 08:31:28 --> Security Class Initialized
DEBUG - 2021-11-19 08:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:31:28 --> Input Class Initialized
INFO - 2021-11-19 08:31:28 --> Language Class Initialized
INFO - 2021-11-19 08:31:28 --> Language Class Initialized
INFO - 2021-11-19 08:31:28 --> Config Class Initialized
INFO - 2021-11-19 08:31:28 --> Loader Class Initialized
INFO - 2021-11-19 08:31:28 --> Helper loaded: url_helper
INFO - 2021-11-19 08:31:28 --> Helper loaded: file_helper
INFO - 2021-11-19 08:31:28 --> Helper loaded: form_helper
INFO - 2021-11-19 08:31:28 --> Helper loaded: my_helper
INFO - 2021-11-19 08:31:28 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:31:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:31:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:31:28 --> Controller Class Initialized
DEBUG - 2021-11-19 08:31:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-11-19 08:31:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 08:31:28 --> Final output sent to browser
DEBUG - 2021-11-19 08:31:28 --> Total execution time: 0.1217
INFO - 2021-11-19 08:31:30 --> Config Class Initialized
INFO - 2021-11-19 08:31:30 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:31:30 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:31:30 --> Utf8 Class Initialized
INFO - 2021-11-19 08:31:30 --> URI Class Initialized
INFO - 2021-11-19 08:31:30 --> Router Class Initialized
INFO - 2021-11-19 08:31:30 --> Output Class Initialized
INFO - 2021-11-19 08:31:30 --> Security Class Initialized
DEBUG - 2021-11-19 08:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:31:30 --> Input Class Initialized
INFO - 2021-11-19 08:31:30 --> Language Class Initialized
INFO - 2021-11-19 08:31:30 --> Language Class Initialized
INFO - 2021-11-19 08:31:30 --> Config Class Initialized
INFO - 2021-11-19 08:31:30 --> Loader Class Initialized
INFO - 2021-11-19 08:31:30 --> Helper loaded: url_helper
INFO - 2021-11-19 08:31:30 --> Helper loaded: file_helper
INFO - 2021-11-19 08:31:30 --> Helper loaded: form_helper
INFO - 2021-11-19 08:31:30 --> Helper loaded: my_helper
INFO - 2021-11-19 08:31:30 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:31:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:31:30 --> Controller Class Initialized
DEBUG - 2021-11-19 08:31:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-11-19 08:31:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 08:31:30 --> Final output sent to browser
DEBUG - 2021-11-19 08:31:30 --> Total execution time: 0.1060
INFO - 2021-11-19 08:31:36 --> Config Class Initialized
INFO - 2021-11-19 08:31:36 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:31:36 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:31:36 --> Utf8 Class Initialized
INFO - 2021-11-19 08:31:36 --> URI Class Initialized
INFO - 2021-11-19 08:31:36 --> Router Class Initialized
INFO - 2021-11-19 08:31:36 --> Output Class Initialized
INFO - 2021-11-19 08:31:36 --> Security Class Initialized
DEBUG - 2021-11-19 08:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:31:36 --> Input Class Initialized
INFO - 2021-11-19 08:31:36 --> Language Class Initialized
INFO - 2021-11-19 08:31:36 --> Language Class Initialized
INFO - 2021-11-19 08:31:36 --> Config Class Initialized
INFO - 2021-11-19 08:31:36 --> Loader Class Initialized
INFO - 2021-11-19 08:31:36 --> Helper loaded: url_helper
INFO - 2021-11-19 08:31:36 --> Helper loaded: file_helper
INFO - 2021-11-19 08:31:36 --> Helper loaded: form_helper
INFO - 2021-11-19 08:31:36 --> Helper loaded: my_helper
INFO - 2021-11-19 08:31:36 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:31:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:31:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:31:36 --> Controller Class Initialized
DEBUG - 2021-11-19 08:31:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-11-19 08:31:36 --> Final output sent to browser
DEBUG - 2021-11-19 08:31:36 --> Total execution time: 0.2239
INFO - 2021-11-19 08:32:12 --> Config Class Initialized
INFO - 2021-11-19 08:32:12 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:32:12 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:32:12 --> Utf8 Class Initialized
INFO - 2021-11-19 08:32:12 --> URI Class Initialized
INFO - 2021-11-19 08:32:12 --> Router Class Initialized
INFO - 2021-11-19 08:32:13 --> Output Class Initialized
INFO - 2021-11-19 08:32:13 --> Security Class Initialized
DEBUG - 2021-11-19 08:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:32:13 --> Input Class Initialized
INFO - 2021-11-19 08:32:13 --> Language Class Initialized
INFO - 2021-11-19 08:32:13 --> Language Class Initialized
INFO - 2021-11-19 08:32:13 --> Config Class Initialized
INFO - 2021-11-19 08:32:13 --> Loader Class Initialized
INFO - 2021-11-19 08:32:13 --> Helper loaded: url_helper
INFO - 2021-11-19 08:32:13 --> Helper loaded: file_helper
INFO - 2021-11-19 08:32:13 --> Helper loaded: form_helper
INFO - 2021-11-19 08:32:13 --> Helper loaded: my_helper
INFO - 2021-11-19 08:32:13 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:32:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:32:13 --> Controller Class Initialized
DEBUG - 2021-11-19 08:32:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-11-19 08:32:13 --> Final output sent to browser
DEBUG - 2021-11-19 08:32:13 --> Total execution time: 0.1775
INFO - 2021-11-19 08:32:27 --> Config Class Initialized
INFO - 2021-11-19 08:32:27 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:32:27 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:32:27 --> Utf8 Class Initialized
INFO - 2021-11-19 08:32:27 --> URI Class Initialized
INFO - 2021-11-19 08:32:27 --> Router Class Initialized
INFO - 2021-11-19 08:32:27 --> Output Class Initialized
INFO - 2021-11-19 08:32:27 --> Security Class Initialized
DEBUG - 2021-11-19 08:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:32:27 --> Input Class Initialized
INFO - 2021-11-19 08:32:27 --> Language Class Initialized
INFO - 2021-11-19 08:32:27 --> Language Class Initialized
INFO - 2021-11-19 08:32:27 --> Config Class Initialized
INFO - 2021-11-19 08:32:27 --> Loader Class Initialized
INFO - 2021-11-19 08:32:27 --> Helper loaded: url_helper
INFO - 2021-11-19 08:32:27 --> Helper loaded: file_helper
INFO - 2021-11-19 08:32:27 --> Helper loaded: form_helper
INFO - 2021-11-19 08:32:27 --> Helper loaded: my_helper
INFO - 2021-11-19 08:32:27 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:32:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:32:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:32:27 --> Controller Class Initialized
DEBUG - 2021-11-19 08:32:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-11-19 08:32:27 --> Final output sent to browser
DEBUG - 2021-11-19 08:32:27 --> Total execution time: 0.1594
INFO - 2021-11-19 08:33:33 --> Config Class Initialized
INFO - 2021-11-19 08:33:33 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:33:33 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:33:33 --> Utf8 Class Initialized
INFO - 2021-11-19 08:33:33 --> URI Class Initialized
INFO - 2021-11-19 08:33:33 --> Router Class Initialized
INFO - 2021-11-19 08:33:33 --> Output Class Initialized
INFO - 2021-11-19 08:33:33 --> Security Class Initialized
DEBUG - 2021-11-19 08:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:33:33 --> Input Class Initialized
INFO - 2021-11-19 08:33:33 --> Language Class Initialized
INFO - 2021-11-19 08:33:33 --> Language Class Initialized
INFO - 2021-11-19 08:33:33 --> Config Class Initialized
INFO - 2021-11-19 08:33:33 --> Loader Class Initialized
INFO - 2021-11-19 08:33:33 --> Helper loaded: url_helper
INFO - 2021-11-19 08:33:33 --> Helper loaded: file_helper
INFO - 2021-11-19 08:33:33 --> Helper loaded: form_helper
INFO - 2021-11-19 08:33:33 --> Helper loaded: my_helper
INFO - 2021-11-19 08:33:33 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:33:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:33:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:33:33 --> Controller Class Initialized
DEBUG - 2021-11-19 08:33:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-11-19 08:33:33 --> Final output sent to browser
DEBUG - 2021-11-19 08:33:33 --> Total execution time: 0.1450
INFO - 2021-11-19 08:33:42 --> Config Class Initialized
INFO - 2021-11-19 08:33:42 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:33:42 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:33:42 --> Utf8 Class Initialized
INFO - 2021-11-19 08:33:42 --> URI Class Initialized
INFO - 2021-11-19 08:33:42 --> Router Class Initialized
INFO - 2021-11-19 08:33:42 --> Output Class Initialized
INFO - 2021-11-19 08:33:42 --> Security Class Initialized
DEBUG - 2021-11-19 08:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:33:42 --> Input Class Initialized
INFO - 2021-11-19 08:33:42 --> Language Class Initialized
INFO - 2021-11-19 08:33:42 --> Language Class Initialized
INFO - 2021-11-19 08:33:42 --> Config Class Initialized
INFO - 2021-11-19 08:33:42 --> Loader Class Initialized
INFO - 2021-11-19 08:33:42 --> Helper loaded: url_helper
INFO - 2021-11-19 08:33:42 --> Helper loaded: file_helper
INFO - 2021-11-19 08:33:42 --> Helper loaded: form_helper
INFO - 2021-11-19 08:33:42 --> Helper loaded: my_helper
INFO - 2021-11-19 08:33:42 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:33:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:33:42 --> Controller Class Initialized
DEBUG - 2021-11-19 08:33:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-11-19 08:33:43 --> Final output sent to browser
DEBUG - 2021-11-19 08:33:43 --> Total execution time: 0.1847
INFO - 2021-11-19 08:34:43 --> Config Class Initialized
INFO - 2021-11-19 08:34:43 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:34:43 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:34:43 --> Utf8 Class Initialized
INFO - 2021-11-19 08:34:43 --> URI Class Initialized
INFO - 2021-11-19 08:34:43 --> Router Class Initialized
INFO - 2021-11-19 08:34:43 --> Output Class Initialized
INFO - 2021-11-19 08:34:43 --> Security Class Initialized
DEBUG - 2021-11-19 08:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:34:43 --> Input Class Initialized
INFO - 2021-11-19 08:34:43 --> Language Class Initialized
INFO - 2021-11-19 08:34:43 --> Language Class Initialized
INFO - 2021-11-19 08:34:43 --> Config Class Initialized
INFO - 2021-11-19 08:34:43 --> Loader Class Initialized
INFO - 2021-11-19 08:34:43 --> Helper loaded: url_helper
INFO - 2021-11-19 08:34:43 --> Helper loaded: file_helper
INFO - 2021-11-19 08:34:43 --> Helper loaded: form_helper
INFO - 2021-11-19 08:34:43 --> Helper loaded: my_helper
INFO - 2021-11-19 08:34:43 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:34:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:34:43 --> Controller Class Initialized
DEBUG - 2021-11-19 08:34:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-11-19 08:34:43 --> Final output sent to browser
DEBUG - 2021-11-19 08:34:43 --> Total execution time: 0.1481
INFO - 2021-11-19 08:35:22 --> Config Class Initialized
INFO - 2021-11-19 08:35:22 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:35:22 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:35:22 --> Utf8 Class Initialized
INFO - 2021-11-19 08:35:22 --> URI Class Initialized
INFO - 2021-11-19 08:35:22 --> Router Class Initialized
INFO - 2021-11-19 08:35:22 --> Output Class Initialized
INFO - 2021-11-19 08:35:22 --> Security Class Initialized
DEBUG - 2021-11-19 08:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:35:22 --> Input Class Initialized
INFO - 2021-11-19 08:35:22 --> Language Class Initialized
INFO - 2021-11-19 08:35:22 --> Language Class Initialized
INFO - 2021-11-19 08:35:22 --> Config Class Initialized
INFO - 2021-11-19 08:35:22 --> Loader Class Initialized
INFO - 2021-11-19 08:35:22 --> Helper loaded: url_helper
INFO - 2021-11-19 08:35:22 --> Helper loaded: file_helper
INFO - 2021-11-19 08:35:22 --> Helper loaded: form_helper
INFO - 2021-11-19 08:35:22 --> Helper loaded: my_helper
INFO - 2021-11-19 08:35:22 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:35:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:35:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:35:22 --> Controller Class Initialized
DEBUG - 2021-11-19 08:35:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-11-19 08:35:22 --> Final output sent to browser
DEBUG - 2021-11-19 08:35:22 --> Total execution time: 0.2494
INFO - 2021-11-19 08:36:05 --> Config Class Initialized
INFO - 2021-11-19 08:36:05 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:36:05 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:36:05 --> Utf8 Class Initialized
INFO - 2021-11-19 08:36:05 --> URI Class Initialized
INFO - 2021-11-19 08:36:05 --> Router Class Initialized
INFO - 2021-11-19 08:36:05 --> Output Class Initialized
INFO - 2021-11-19 08:36:05 --> Security Class Initialized
DEBUG - 2021-11-19 08:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:36:05 --> Input Class Initialized
INFO - 2021-11-19 08:36:05 --> Language Class Initialized
INFO - 2021-11-19 08:36:05 --> Language Class Initialized
INFO - 2021-11-19 08:36:05 --> Config Class Initialized
INFO - 2021-11-19 08:36:05 --> Loader Class Initialized
INFO - 2021-11-19 08:36:05 --> Helper loaded: url_helper
INFO - 2021-11-19 08:36:05 --> Helper loaded: file_helper
INFO - 2021-11-19 08:36:05 --> Helper loaded: form_helper
INFO - 2021-11-19 08:36:05 --> Helper loaded: my_helper
INFO - 2021-11-19 08:36:05 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:36:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:36:05 --> Controller Class Initialized
INFO - 2021-11-19 08:36:05 --> Helper loaded: cookie_helper
INFO - 2021-11-19 08:36:05 --> Config Class Initialized
INFO - 2021-11-19 08:36:05 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:36:05 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:36:05 --> Utf8 Class Initialized
INFO - 2021-11-19 08:36:05 --> URI Class Initialized
INFO - 2021-11-19 08:36:05 --> Router Class Initialized
INFO - 2021-11-19 08:36:05 --> Output Class Initialized
INFO - 2021-11-19 08:36:05 --> Security Class Initialized
DEBUG - 2021-11-19 08:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:36:05 --> Input Class Initialized
INFO - 2021-11-19 08:36:05 --> Language Class Initialized
INFO - 2021-11-19 08:36:05 --> Language Class Initialized
INFO - 2021-11-19 08:36:05 --> Config Class Initialized
INFO - 2021-11-19 08:36:05 --> Loader Class Initialized
INFO - 2021-11-19 08:36:05 --> Helper loaded: url_helper
INFO - 2021-11-19 08:36:05 --> Helper loaded: file_helper
INFO - 2021-11-19 08:36:05 --> Helper loaded: form_helper
INFO - 2021-11-19 08:36:05 --> Helper loaded: my_helper
INFO - 2021-11-19 08:36:05 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:36:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:36:05 --> Controller Class Initialized
DEBUG - 2021-11-19 08:36:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-11-19 08:36:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 08:36:05 --> Final output sent to browser
DEBUG - 2021-11-19 08:36:05 --> Total execution time: 0.0561
INFO - 2021-11-19 08:36:20 --> Config Class Initialized
INFO - 2021-11-19 08:36:20 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:36:20 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:36:20 --> Utf8 Class Initialized
INFO - 2021-11-19 08:36:20 --> URI Class Initialized
INFO - 2021-11-19 08:36:20 --> Router Class Initialized
INFO - 2021-11-19 08:36:20 --> Output Class Initialized
INFO - 2021-11-19 08:36:20 --> Security Class Initialized
DEBUG - 2021-11-19 08:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:36:20 --> Input Class Initialized
INFO - 2021-11-19 08:36:20 --> Language Class Initialized
INFO - 2021-11-19 08:36:20 --> Language Class Initialized
INFO - 2021-11-19 08:36:20 --> Config Class Initialized
INFO - 2021-11-19 08:36:20 --> Loader Class Initialized
INFO - 2021-11-19 08:36:20 --> Helper loaded: url_helper
INFO - 2021-11-19 08:36:20 --> Helper loaded: file_helper
INFO - 2021-11-19 08:36:20 --> Helper loaded: form_helper
INFO - 2021-11-19 08:36:20 --> Helper loaded: my_helper
INFO - 2021-11-19 08:36:20 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:36:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:36:20 --> Controller Class Initialized
INFO - 2021-11-19 08:36:20 --> Helper loaded: cookie_helper
INFO - 2021-11-19 08:36:20 --> Final output sent to browser
DEBUG - 2021-11-19 08:36:20 --> Total execution time: 0.0874
INFO - 2021-11-19 08:36:21 --> Config Class Initialized
INFO - 2021-11-19 08:36:21 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:36:21 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:36:21 --> Utf8 Class Initialized
INFO - 2021-11-19 08:36:21 --> URI Class Initialized
INFO - 2021-11-19 08:36:21 --> Router Class Initialized
INFO - 2021-11-19 08:36:21 --> Output Class Initialized
INFO - 2021-11-19 08:36:21 --> Security Class Initialized
DEBUG - 2021-11-19 08:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:36:21 --> Input Class Initialized
INFO - 2021-11-19 08:36:21 --> Language Class Initialized
INFO - 2021-11-19 08:36:21 --> Language Class Initialized
INFO - 2021-11-19 08:36:21 --> Config Class Initialized
INFO - 2021-11-19 08:36:21 --> Loader Class Initialized
INFO - 2021-11-19 08:36:21 --> Helper loaded: url_helper
INFO - 2021-11-19 08:36:21 --> Helper loaded: file_helper
INFO - 2021-11-19 08:36:21 --> Helper loaded: form_helper
INFO - 2021-11-19 08:36:21 --> Helper loaded: my_helper
INFO - 2021-11-19 08:36:21 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:36:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:36:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:36:21 --> Controller Class Initialized
DEBUG - 2021-11-19 08:36:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-11-19 08:36:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 08:36:22 --> Final output sent to browser
DEBUG - 2021-11-19 08:36:22 --> Total execution time: 1.1217
INFO - 2021-11-19 08:36:45 --> Config Class Initialized
INFO - 2021-11-19 08:36:45 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:36:45 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:36:45 --> Utf8 Class Initialized
INFO - 2021-11-19 08:36:45 --> URI Class Initialized
INFO - 2021-11-19 08:36:45 --> Router Class Initialized
INFO - 2021-11-19 08:36:45 --> Output Class Initialized
INFO - 2021-11-19 08:36:45 --> Security Class Initialized
DEBUG - 2021-11-19 08:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:36:45 --> Input Class Initialized
INFO - 2021-11-19 08:36:45 --> Language Class Initialized
INFO - 2021-11-19 08:36:45 --> Language Class Initialized
INFO - 2021-11-19 08:36:45 --> Config Class Initialized
INFO - 2021-11-19 08:36:45 --> Loader Class Initialized
INFO - 2021-11-19 08:36:45 --> Helper loaded: url_helper
INFO - 2021-11-19 08:36:45 --> Helper loaded: file_helper
INFO - 2021-11-19 08:36:45 --> Helper loaded: form_helper
INFO - 2021-11-19 08:36:45 --> Helper loaded: my_helper
INFO - 2021-11-19 08:36:45 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:36:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:36:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:36:45 --> Controller Class Initialized
DEBUG - 2021-11-19 08:36:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-11-19 08:36:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 08:36:45 --> Final output sent to browser
DEBUG - 2021-11-19 08:36:45 --> Total execution time: 0.0989
INFO - 2021-11-19 08:36:49 --> Config Class Initialized
INFO - 2021-11-19 08:36:49 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:36:49 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:36:49 --> Utf8 Class Initialized
INFO - 2021-11-19 08:36:49 --> URI Class Initialized
INFO - 2021-11-19 08:36:49 --> Router Class Initialized
INFO - 2021-11-19 08:36:49 --> Output Class Initialized
INFO - 2021-11-19 08:36:49 --> Security Class Initialized
DEBUG - 2021-11-19 08:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:36:49 --> Input Class Initialized
INFO - 2021-11-19 08:36:49 --> Language Class Initialized
INFO - 2021-11-19 08:36:49 --> Language Class Initialized
INFO - 2021-11-19 08:36:49 --> Config Class Initialized
INFO - 2021-11-19 08:36:49 --> Loader Class Initialized
INFO - 2021-11-19 08:36:49 --> Helper loaded: url_helper
INFO - 2021-11-19 08:36:49 --> Helper loaded: file_helper
INFO - 2021-11-19 08:36:49 --> Helper loaded: form_helper
INFO - 2021-11-19 08:36:49 --> Helper loaded: my_helper
INFO - 2021-11-19 08:36:49 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:36:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:36:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:36:49 --> Controller Class Initialized
DEBUG - 2021-11-19 08:36:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-11-19 08:36:49 --> Final output sent to browser
DEBUG - 2021-11-19 08:36:49 --> Total execution time: 0.2317
INFO - 2021-11-19 08:38:05 --> Config Class Initialized
INFO - 2021-11-19 08:38:05 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:38:05 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:38:05 --> Utf8 Class Initialized
INFO - 2021-11-19 08:38:05 --> URI Class Initialized
INFO - 2021-11-19 08:38:05 --> Router Class Initialized
INFO - 2021-11-19 08:38:05 --> Output Class Initialized
INFO - 2021-11-19 08:38:05 --> Security Class Initialized
DEBUG - 2021-11-19 08:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:38:05 --> Input Class Initialized
INFO - 2021-11-19 08:38:05 --> Language Class Initialized
INFO - 2021-11-19 08:38:05 --> Language Class Initialized
INFO - 2021-11-19 08:38:05 --> Config Class Initialized
INFO - 2021-11-19 08:38:05 --> Loader Class Initialized
INFO - 2021-11-19 08:38:05 --> Helper loaded: url_helper
INFO - 2021-11-19 08:38:05 --> Helper loaded: file_helper
INFO - 2021-11-19 08:38:05 --> Helper loaded: form_helper
INFO - 2021-11-19 08:38:05 --> Helper loaded: my_helper
INFO - 2021-11-19 08:38:05 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:38:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:38:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:38:05 --> Controller Class Initialized
DEBUG - 2021-11-19 08:38:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-11-19 08:38:05 --> Final output sent to browser
DEBUG - 2021-11-19 08:38:05 --> Total execution time: 0.1571
INFO - 2021-11-19 08:39:04 --> Config Class Initialized
INFO - 2021-11-19 08:39:04 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:39:04 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:39:04 --> Utf8 Class Initialized
INFO - 2021-11-19 08:39:04 --> URI Class Initialized
INFO - 2021-11-19 08:39:04 --> Router Class Initialized
INFO - 2021-11-19 08:39:04 --> Output Class Initialized
INFO - 2021-11-19 08:39:04 --> Security Class Initialized
DEBUG - 2021-11-19 08:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:39:04 --> Input Class Initialized
INFO - 2021-11-19 08:39:04 --> Language Class Initialized
INFO - 2021-11-19 08:39:04 --> Language Class Initialized
INFO - 2021-11-19 08:39:04 --> Config Class Initialized
INFO - 2021-11-19 08:39:04 --> Loader Class Initialized
INFO - 2021-11-19 08:39:04 --> Helper loaded: url_helper
INFO - 2021-11-19 08:39:04 --> Helper loaded: file_helper
INFO - 2021-11-19 08:39:04 --> Helper loaded: form_helper
INFO - 2021-11-19 08:39:04 --> Helper loaded: my_helper
INFO - 2021-11-19 08:39:04 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:39:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:39:04 --> Controller Class Initialized
DEBUG - 2021-11-19 08:39:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-11-19 08:39:04 --> Final output sent to browser
DEBUG - 2021-11-19 08:39:04 --> Total execution time: 0.1419
INFO - 2021-11-19 08:39:16 --> Config Class Initialized
INFO - 2021-11-19 08:39:16 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:39:16 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:39:16 --> Utf8 Class Initialized
INFO - 2021-11-19 08:39:16 --> URI Class Initialized
INFO - 2021-11-19 08:39:16 --> Router Class Initialized
INFO - 2021-11-19 08:39:16 --> Output Class Initialized
INFO - 2021-11-19 08:39:16 --> Security Class Initialized
DEBUG - 2021-11-19 08:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:39:16 --> Input Class Initialized
INFO - 2021-11-19 08:39:16 --> Language Class Initialized
INFO - 2021-11-19 08:39:16 --> Language Class Initialized
INFO - 2021-11-19 08:39:16 --> Config Class Initialized
INFO - 2021-11-19 08:39:16 --> Loader Class Initialized
INFO - 2021-11-19 08:39:16 --> Helper loaded: url_helper
INFO - 2021-11-19 08:39:16 --> Helper loaded: file_helper
INFO - 2021-11-19 08:39:16 --> Helper loaded: form_helper
INFO - 2021-11-19 08:39:16 --> Helper loaded: my_helper
INFO - 2021-11-19 08:39:16 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:39:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:39:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:39:16 --> Controller Class Initialized
DEBUG - 2021-11-19 08:39:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-11-19 08:39:16 --> Final output sent to browser
DEBUG - 2021-11-19 08:39:16 --> Total execution time: 0.1438
INFO - 2021-11-19 08:39:49 --> Config Class Initialized
INFO - 2021-11-19 08:39:49 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:39:49 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:39:49 --> Utf8 Class Initialized
INFO - 2021-11-19 08:39:49 --> URI Class Initialized
INFO - 2021-11-19 08:39:49 --> Router Class Initialized
INFO - 2021-11-19 08:39:49 --> Output Class Initialized
INFO - 2021-11-19 08:39:49 --> Security Class Initialized
DEBUG - 2021-11-19 08:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:39:49 --> Input Class Initialized
INFO - 2021-11-19 08:39:49 --> Language Class Initialized
INFO - 2021-11-19 08:39:49 --> Language Class Initialized
INFO - 2021-11-19 08:39:49 --> Config Class Initialized
INFO - 2021-11-19 08:39:49 --> Loader Class Initialized
INFO - 2021-11-19 08:39:49 --> Helper loaded: url_helper
INFO - 2021-11-19 08:39:49 --> Helper loaded: file_helper
INFO - 2021-11-19 08:39:49 --> Helper loaded: form_helper
INFO - 2021-11-19 08:39:49 --> Helper loaded: my_helper
INFO - 2021-11-19 08:39:49 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:39:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:39:49 --> Controller Class Initialized
DEBUG - 2021-11-19 08:39:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-11-19 08:39:49 --> Final output sent to browser
DEBUG - 2021-11-19 08:39:49 --> Total execution time: 0.1460
INFO - 2021-11-19 08:41:44 --> Config Class Initialized
INFO - 2021-11-19 08:41:44 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:41:44 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:41:44 --> Utf8 Class Initialized
INFO - 2021-11-19 08:41:44 --> URI Class Initialized
INFO - 2021-11-19 08:41:44 --> Router Class Initialized
INFO - 2021-11-19 08:41:44 --> Output Class Initialized
INFO - 2021-11-19 08:41:44 --> Security Class Initialized
DEBUG - 2021-11-19 08:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:41:44 --> Input Class Initialized
INFO - 2021-11-19 08:41:44 --> Language Class Initialized
INFO - 2021-11-19 08:41:44 --> Language Class Initialized
INFO - 2021-11-19 08:41:44 --> Config Class Initialized
INFO - 2021-11-19 08:41:44 --> Loader Class Initialized
INFO - 2021-11-19 08:41:44 --> Helper loaded: url_helper
INFO - 2021-11-19 08:41:44 --> Helper loaded: file_helper
INFO - 2021-11-19 08:41:44 --> Helper loaded: form_helper
INFO - 2021-11-19 08:41:44 --> Helper loaded: my_helper
INFO - 2021-11-19 08:41:44 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:41:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:41:44 --> Controller Class Initialized
INFO - 2021-11-19 08:41:44 --> Helper loaded: cookie_helper
INFO - 2021-11-19 08:41:44 --> Config Class Initialized
INFO - 2021-11-19 08:41:44 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:41:44 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:41:44 --> Utf8 Class Initialized
INFO - 2021-11-19 08:41:44 --> URI Class Initialized
INFO - 2021-11-19 08:41:44 --> Router Class Initialized
INFO - 2021-11-19 08:41:44 --> Output Class Initialized
INFO - 2021-11-19 08:41:44 --> Security Class Initialized
DEBUG - 2021-11-19 08:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:41:44 --> Input Class Initialized
INFO - 2021-11-19 08:41:44 --> Language Class Initialized
INFO - 2021-11-19 08:41:44 --> Language Class Initialized
INFO - 2021-11-19 08:41:44 --> Config Class Initialized
INFO - 2021-11-19 08:41:44 --> Loader Class Initialized
INFO - 2021-11-19 08:41:44 --> Helper loaded: url_helper
INFO - 2021-11-19 08:41:44 --> Helper loaded: file_helper
INFO - 2021-11-19 08:41:44 --> Helper loaded: form_helper
INFO - 2021-11-19 08:41:44 --> Helper loaded: my_helper
INFO - 2021-11-19 08:41:44 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:41:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:41:44 --> Controller Class Initialized
DEBUG - 2021-11-19 08:41:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-11-19 08:41:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 08:41:44 --> Final output sent to browser
DEBUG - 2021-11-19 08:41:44 --> Total execution time: 0.0904
INFO - 2021-11-19 08:41:48 --> Config Class Initialized
INFO - 2021-11-19 08:41:48 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:41:48 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:41:48 --> Utf8 Class Initialized
INFO - 2021-11-19 08:41:48 --> URI Class Initialized
INFO - 2021-11-19 08:41:48 --> Router Class Initialized
INFO - 2021-11-19 08:41:48 --> Output Class Initialized
INFO - 2021-11-19 08:41:48 --> Security Class Initialized
DEBUG - 2021-11-19 08:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:41:48 --> Input Class Initialized
INFO - 2021-11-19 08:41:48 --> Language Class Initialized
INFO - 2021-11-19 08:41:48 --> Language Class Initialized
INFO - 2021-11-19 08:41:48 --> Config Class Initialized
INFO - 2021-11-19 08:41:48 --> Loader Class Initialized
INFO - 2021-11-19 08:41:48 --> Helper loaded: url_helper
INFO - 2021-11-19 08:41:48 --> Helper loaded: file_helper
INFO - 2021-11-19 08:41:48 --> Helper loaded: form_helper
INFO - 2021-11-19 08:41:48 --> Helper loaded: my_helper
INFO - 2021-11-19 08:41:48 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:41:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:41:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:41:48 --> Controller Class Initialized
INFO - 2021-11-19 08:41:48 --> Helper loaded: cookie_helper
INFO - 2021-11-19 08:41:48 --> Final output sent to browser
DEBUG - 2021-11-19 08:41:48 --> Total execution time: 0.0814
INFO - 2021-11-19 08:41:48 --> Config Class Initialized
INFO - 2021-11-19 08:41:48 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:41:48 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:41:48 --> Utf8 Class Initialized
INFO - 2021-11-19 08:41:48 --> URI Class Initialized
INFO - 2021-11-19 08:41:48 --> Router Class Initialized
INFO - 2021-11-19 08:41:48 --> Output Class Initialized
INFO - 2021-11-19 08:41:48 --> Security Class Initialized
DEBUG - 2021-11-19 08:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:41:48 --> Input Class Initialized
INFO - 2021-11-19 08:41:48 --> Language Class Initialized
INFO - 2021-11-19 08:41:48 --> Language Class Initialized
INFO - 2021-11-19 08:41:48 --> Config Class Initialized
INFO - 2021-11-19 08:41:48 --> Loader Class Initialized
INFO - 2021-11-19 08:41:48 --> Helper loaded: url_helper
INFO - 2021-11-19 08:41:48 --> Helper loaded: file_helper
INFO - 2021-11-19 08:41:48 --> Helper loaded: form_helper
INFO - 2021-11-19 08:41:48 --> Helper loaded: my_helper
INFO - 2021-11-19 08:41:48 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:41:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:41:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:41:48 --> Controller Class Initialized
DEBUG - 2021-11-19 08:41:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-11-19 08:41:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 08:41:49 --> Final output sent to browser
DEBUG - 2021-11-19 08:41:49 --> Total execution time: 1.1067
INFO - 2021-11-19 08:42:00 --> Config Class Initialized
INFO - 2021-11-19 08:42:00 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:42:00 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:42:00 --> Utf8 Class Initialized
INFO - 2021-11-19 08:42:00 --> URI Class Initialized
INFO - 2021-11-19 08:42:00 --> Router Class Initialized
INFO - 2021-11-19 08:42:00 --> Output Class Initialized
INFO - 2021-11-19 08:42:00 --> Security Class Initialized
DEBUG - 2021-11-19 08:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:42:00 --> Input Class Initialized
INFO - 2021-11-19 08:42:00 --> Language Class Initialized
INFO - 2021-11-19 08:42:00 --> Language Class Initialized
INFO - 2021-11-19 08:42:00 --> Config Class Initialized
INFO - 2021-11-19 08:42:00 --> Loader Class Initialized
INFO - 2021-11-19 08:42:00 --> Helper loaded: url_helper
INFO - 2021-11-19 08:42:00 --> Helper loaded: file_helper
INFO - 2021-11-19 08:42:00 --> Helper loaded: form_helper
INFO - 2021-11-19 08:42:00 --> Helper loaded: my_helper
INFO - 2021-11-19 08:42:00 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:42:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:42:00 --> Controller Class Initialized
DEBUG - 2021-11-19 08:42:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-11-19 08:42:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 08:42:00 --> Final output sent to browser
DEBUG - 2021-11-19 08:42:00 --> Total execution time: 0.0830
INFO - 2021-11-19 08:42:03 --> Config Class Initialized
INFO - 2021-11-19 08:42:03 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:42:03 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:42:03 --> Utf8 Class Initialized
INFO - 2021-11-19 08:42:03 --> URI Class Initialized
INFO - 2021-11-19 08:42:03 --> Router Class Initialized
INFO - 2021-11-19 08:42:03 --> Output Class Initialized
INFO - 2021-11-19 08:42:03 --> Security Class Initialized
DEBUG - 2021-11-19 08:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:42:03 --> Input Class Initialized
INFO - 2021-11-19 08:42:03 --> Language Class Initialized
INFO - 2021-11-19 08:42:03 --> Language Class Initialized
INFO - 2021-11-19 08:42:03 --> Config Class Initialized
INFO - 2021-11-19 08:42:03 --> Loader Class Initialized
INFO - 2021-11-19 08:42:03 --> Helper loaded: url_helper
INFO - 2021-11-19 08:42:03 --> Helper loaded: file_helper
INFO - 2021-11-19 08:42:03 --> Helper loaded: form_helper
INFO - 2021-11-19 08:42:03 --> Helper loaded: my_helper
INFO - 2021-11-19 08:42:03 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:42:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:42:03 --> Controller Class Initialized
DEBUG - 2021-11-19 08:42:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-11-19 08:42:03 --> Final output sent to browser
DEBUG - 2021-11-19 08:42:03 --> Total execution time: 0.2145
INFO - 2021-11-19 08:44:34 --> Config Class Initialized
INFO - 2021-11-19 08:44:34 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:44:34 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:44:34 --> Utf8 Class Initialized
INFO - 2021-11-19 08:44:34 --> URI Class Initialized
INFO - 2021-11-19 08:44:34 --> Router Class Initialized
INFO - 2021-11-19 08:44:34 --> Output Class Initialized
INFO - 2021-11-19 08:44:34 --> Security Class Initialized
DEBUG - 2021-11-19 08:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:44:34 --> Input Class Initialized
INFO - 2021-11-19 08:44:34 --> Language Class Initialized
INFO - 2021-11-19 08:44:34 --> Language Class Initialized
INFO - 2021-11-19 08:44:34 --> Config Class Initialized
INFO - 2021-11-19 08:44:34 --> Loader Class Initialized
INFO - 2021-11-19 08:44:34 --> Helper loaded: url_helper
INFO - 2021-11-19 08:44:34 --> Helper loaded: file_helper
INFO - 2021-11-19 08:44:34 --> Helper loaded: form_helper
INFO - 2021-11-19 08:44:34 --> Helper loaded: my_helper
INFO - 2021-11-19 08:44:34 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:44:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:44:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:44:34 --> Controller Class Initialized
DEBUG - 2021-11-19 08:44:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-11-19 08:44:34 --> Final output sent to browser
DEBUG - 2021-11-19 08:44:34 --> Total execution time: 0.1629
INFO - 2021-11-19 08:44:54 --> Config Class Initialized
INFO - 2021-11-19 08:44:54 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:44:54 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:44:54 --> Utf8 Class Initialized
INFO - 2021-11-19 08:44:54 --> URI Class Initialized
INFO - 2021-11-19 08:44:54 --> Router Class Initialized
INFO - 2021-11-19 08:44:54 --> Output Class Initialized
INFO - 2021-11-19 08:44:54 --> Security Class Initialized
DEBUG - 2021-11-19 08:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:44:54 --> Input Class Initialized
INFO - 2021-11-19 08:44:54 --> Language Class Initialized
INFO - 2021-11-19 08:44:54 --> Language Class Initialized
INFO - 2021-11-19 08:44:54 --> Config Class Initialized
INFO - 2021-11-19 08:44:54 --> Loader Class Initialized
INFO - 2021-11-19 08:44:54 --> Helper loaded: url_helper
INFO - 2021-11-19 08:44:54 --> Helper loaded: file_helper
INFO - 2021-11-19 08:44:54 --> Helper loaded: form_helper
INFO - 2021-11-19 08:44:54 --> Helper loaded: my_helper
INFO - 2021-11-19 08:44:54 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:44:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:44:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:44:54 --> Controller Class Initialized
DEBUG - 2021-11-19 08:44:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-11-19 08:44:54 --> Final output sent to browser
DEBUG - 2021-11-19 08:44:54 --> Total execution time: 0.1555
INFO - 2021-11-19 08:45:05 --> Config Class Initialized
INFO - 2021-11-19 08:45:05 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:45:05 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:45:05 --> Utf8 Class Initialized
INFO - 2021-11-19 08:45:05 --> URI Class Initialized
INFO - 2021-11-19 08:45:05 --> Router Class Initialized
INFO - 2021-11-19 08:45:05 --> Output Class Initialized
INFO - 2021-11-19 08:45:05 --> Security Class Initialized
DEBUG - 2021-11-19 08:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:45:05 --> Input Class Initialized
INFO - 2021-11-19 08:45:05 --> Language Class Initialized
INFO - 2021-11-19 08:45:05 --> Language Class Initialized
INFO - 2021-11-19 08:45:05 --> Config Class Initialized
INFO - 2021-11-19 08:45:05 --> Loader Class Initialized
INFO - 2021-11-19 08:45:05 --> Helper loaded: url_helper
INFO - 2021-11-19 08:45:05 --> Helper loaded: file_helper
INFO - 2021-11-19 08:45:05 --> Helper loaded: form_helper
INFO - 2021-11-19 08:45:05 --> Helper loaded: my_helper
INFO - 2021-11-19 08:45:05 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:45:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:45:05 --> Controller Class Initialized
DEBUG - 2021-11-19 08:45:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-11-19 08:45:05 --> Final output sent to browser
DEBUG - 2021-11-19 08:45:05 --> Total execution time: 0.1279
INFO - 2021-11-19 08:46:45 --> Config Class Initialized
INFO - 2021-11-19 08:46:45 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:46:45 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:46:45 --> Utf8 Class Initialized
INFO - 2021-11-19 08:46:45 --> URI Class Initialized
INFO - 2021-11-19 08:46:45 --> Router Class Initialized
INFO - 2021-11-19 08:46:45 --> Output Class Initialized
INFO - 2021-11-19 08:46:45 --> Security Class Initialized
DEBUG - 2021-11-19 08:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:46:45 --> Input Class Initialized
INFO - 2021-11-19 08:46:45 --> Language Class Initialized
INFO - 2021-11-19 08:46:45 --> Language Class Initialized
INFO - 2021-11-19 08:46:45 --> Config Class Initialized
INFO - 2021-11-19 08:46:45 --> Loader Class Initialized
INFO - 2021-11-19 08:46:45 --> Helper loaded: url_helper
INFO - 2021-11-19 08:46:45 --> Helper loaded: file_helper
INFO - 2021-11-19 08:46:45 --> Helper loaded: form_helper
INFO - 2021-11-19 08:46:45 --> Helper loaded: my_helper
INFO - 2021-11-19 08:46:45 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:46:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:46:45 --> Controller Class Initialized
INFO - 2021-11-19 08:46:45 --> Helper loaded: cookie_helper
INFO - 2021-11-19 08:46:45 --> Config Class Initialized
INFO - 2021-11-19 08:46:45 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:46:45 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:46:45 --> Utf8 Class Initialized
INFO - 2021-11-19 08:46:45 --> URI Class Initialized
INFO - 2021-11-19 08:46:45 --> Router Class Initialized
INFO - 2021-11-19 08:46:45 --> Output Class Initialized
INFO - 2021-11-19 08:46:45 --> Security Class Initialized
DEBUG - 2021-11-19 08:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:46:45 --> Input Class Initialized
INFO - 2021-11-19 08:46:45 --> Language Class Initialized
INFO - 2021-11-19 08:46:45 --> Language Class Initialized
INFO - 2021-11-19 08:46:45 --> Config Class Initialized
INFO - 2021-11-19 08:46:45 --> Loader Class Initialized
INFO - 2021-11-19 08:46:45 --> Helper loaded: url_helper
INFO - 2021-11-19 08:46:45 --> Helper loaded: file_helper
INFO - 2021-11-19 08:46:45 --> Helper loaded: form_helper
INFO - 2021-11-19 08:46:45 --> Helper loaded: my_helper
INFO - 2021-11-19 08:46:45 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:46:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:46:45 --> Controller Class Initialized
DEBUG - 2021-11-19 08:46:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-11-19 08:46:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 08:46:45 --> Final output sent to browser
DEBUG - 2021-11-19 08:46:45 --> Total execution time: 0.0519
INFO - 2021-11-19 08:47:39 --> Config Class Initialized
INFO - 2021-11-19 08:47:39 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:47:39 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:47:39 --> Utf8 Class Initialized
INFO - 2021-11-19 08:47:39 --> URI Class Initialized
INFO - 2021-11-19 08:47:39 --> Router Class Initialized
INFO - 2021-11-19 08:47:39 --> Output Class Initialized
INFO - 2021-11-19 08:47:39 --> Security Class Initialized
DEBUG - 2021-11-19 08:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:47:39 --> Input Class Initialized
INFO - 2021-11-19 08:47:39 --> Language Class Initialized
INFO - 2021-11-19 08:47:39 --> Language Class Initialized
INFO - 2021-11-19 08:47:39 --> Config Class Initialized
INFO - 2021-11-19 08:47:39 --> Loader Class Initialized
INFO - 2021-11-19 08:47:39 --> Helper loaded: url_helper
INFO - 2021-11-19 08:47:39 --> Helper loaded: file_helper
INFO - 2021-11-19 08:47:39 --> Helper loaded: form_helper
INFO - 2021-11-19 08:47:39 --> Helper loaded: my_helper
INFO - 2021-11-19 08:47:39 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:47:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:47:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:47:39 --> Controller Class Initialized
INFO - 2021-11-19 08:47:39 --> Helper loaded: cookie_helper
INFO - 2021-11-19 08:47:39 --> Final output sent to browser
DEBUG - 2021-11-19 08:47:39 --> Total execution time: 0.0783
INFO - 2021-11-19 08:47:39 --> Config Class Initialized
INFO - 2021-11-19 08:47:39 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:47:39 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:47:39 --> Utf8 Class Initialized
INFO - 2021-11-19 08:47:39 --> URI Class Initialized
INFO - 2021-11-19 08:47:39 --> Router Class Initialized
INFO - 2021-11-19 08:47:39 --> Output Class Initialized
INFO - 2021-11-19 08:47:39 --> Security Class Initialized
DEBUG - 2021-11-19 08:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:47:39 --> Input Class Initialized
INFO - 2021-11-19 08:47:39 --> Language Class Initialized
INFO - 2021-11-19 08:47:39 --> Language Class Initialized
INFO - 2021-11-19 08:47:39 --> Config Class Initialized
INFO - 2021-11-19 08:47:39 --> Loader Class Initialized
INFO - 2021-11-19 08:47:39 --> Helper loaded: url_helper
INFO - 2021-11-19 08:47:39 --> Helper loaded: file_helper
INFO - 2021-11-19 08:47:39 --> Helper loaded: form_helper
INFO - 2021-11-19 08:47:39 --> Helper loaded: my_helper
INFO - 2021-11-19 08:47:39 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:47:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:47:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:47:39 --> Controller Class Initialized
DEBUG - 2021-11-19 08:47:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-11-19 08:47:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 08:47:40 --> Final output sent to browser
DEBUG - 2021-11-19 08:47:40 --> Total execution time: 1.0412
INFO - 2021-11-19 08:47:42 --> Config Class Initialized
INFO - 2021-11-19 08:47:42 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:47:42 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:47:42 --> Utf8 Class Initialized
INFO - 2021-11-19 08:47:42 --> URI Class Initialized
INFO - 2021-11-19 08:47:42 --> Router Class Initialized
INFO - 2021-11-19 08:47:42 --> Output Class Initialized
INFO - 2021-11-19 08:47:42 --> Security Class Initialized
DEBUG - 2021-11-19 08:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:47:42 --> Input Class Initialized
INFO - 2021-11-19 08:47:42 --> Language Class Initialized
INFO - 2021-11-19 08:47:42 --> Language Class Initialized
INFO - 2021-11-19 08:47:42 --> Config Class Initialized
INFO - 2021-11-19 08:47:42 --> Loader Class Initialized
INFO - 2021-11-19 08:47:42 --> Helper loaded: url_helper
INFO - 2021-11-19 08:47:42 --> Helper loaded: file_helper
INFO - 2021-11-19 08:47:42 --> Helper loaded: form_helper
INFO - 2021-11-19 08:47:42 --> Helper loaded: my_helper
INFO - 2021-11-19 08:47:42 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:47:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:47:42 --> Controller Class Initialized
DEBUG - 2021-11-19 08:47:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-11-19 08:47:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 08:47:42 --> Final output sent to browser
DEBUG - 2021-11-19 08:47:42 --> Total execution time: 0.0922
INFO - 2021-11-19 08:47:46 --> Config Class Initialized
INFO - 2021-11-19 08:47:46 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:47:46 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:47:46 --> Utf8 Class Initialized
INFO - 2021-11-19 08:47:46 --> URI Class Initialized
DEBUG - 2021-11-19 08:47:46 --> No URI present. Default controller set.
INFO - 2021-11-19 08:47:46 --> Router Class Initialized
INFO - 2021-11-19 08:47:46 --> Output Class Initialized
INFO - 2021-11-19 08:47:46 --> Security Class Initialized
DEBUG - 2021-11-19 08:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:47:46 --> Input Class Initialized
INFO - 2021-11-19 08:47:46 --> Language Class Initialized
INFO - 2021-11-19 08:47:46 --> Language Class Initialized
INFO - 2021-11-19 08:47:46 --> Config Class Initialized
INFO - 2021-11-19 08:47:46 --> Loader Class Initialized
INFO - 2021-11-19 08:47:46 --> Helper loaded: url_helper
INFO - 2021-11-19 08:47:46 --> Helper loaded: file_helper
INFO - 2021-11-19 08:47:46 --> Helper loaded: form_helper
INFO - 2021-11-19 08:47:46 --> Helper loaded: my_helper
INFO - 2021-11-19 08:47:46 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:47:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:47:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:47:46 --> Controller Class Initialized
DEBUG - 2021-11-19 08:47:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-11-19 08:47:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 08:47:47 --> Final output sent to browser
DEBUG - 2021-11-19 08:47:47 --> Total execution time: 0.9101
INFO - 2021-11-19 08:47:49 --> Config Class Initialized
INFO - 2021-11-19 08:47:49 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:47:49 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:47:49 --> Utf8 Class Initialized
INFO - 2021-11-19 08:47:49 --> URI Class Initialized
INFO - 2021-11-19 08:47:49 --> Router Class Initialized
INFO - 2021-11-19 08:47:49 --> Output Class Initialized
INFO - 2021-11-19 08:47:49 --> Security Class Initialized
DEBUG - 2021-11-19 08:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:47:49 --> Input Class Initialized
INFO - 2021-11-19 08:47:49 --> Language Class Initialized
INFO - 2021-11-19 08:47:49 --> Language Class Initialized
INFO - 2021-11-19 08:47:49 --> Config Class Initialized
INFO - 2021-11-19 08:47:49 --> Loader Class Initialized
INFO - 2021-11-19 08:47:49 --> Helper loaded: url_helper
INFO - 2021-11-19 08:47:49 --> Helper loaded: file_helper
INFO - 2021-11-19 08:47:49 --> Helper loaded: form_helper
INFO - 2021-11-19 08:47:49 --> Helper loaded: my_helper
INFO - 2021-11-19 08:47:49 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:47:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:47:49 --> Controller Class Initialized
DEBUG - 2021-11-19 08:47:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-11-19 08:47:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 08:47:49 --> Final output sent to browser
DEBUG - 2021-11-19 08:47:49 --> Total execution time: 0.0834
INFO - 2021-11-19 08:47:52 --> Config Class Initialized
INFO - 2021-11-19 08:47:52 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:47:52 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:47:52 --> Utf8 Class Initialized
INFO - 2021-11-19 08:47:52 --> URI Class Initialized
INFO - 2021-11-19 08:47:52 --> Router Class Initialized
INFO - 2021-11-19 08:47:52 --> Output Class Initialized
INFO - 2021-11-19 08:47:52 --> Security Class Initialized
DEBUG - 2021-11-19 08:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:47:52 --> Input Class Initialized
INFO - 2021-11-19 08:47:52 --> Language Class Initialized
INFO - 2021-11-19 08:47:52 --> Language Class Initialized
INFO - 2021-11-19 08:47:52 --> Config Class Initialized
INFO - 2021-11-19 08:47:52 --> Loader Class Initialized
INFO - 2021-11-19 08:47:52 --> Helper loaded: url_helper
INFO - 2021-11-19 08:47:52 --> Helper loaded: file_helper
INFO - 2021-11-19 08:47:52 --> Helper loaded: form_helper
INFO - 2021-11-19 08:47:52 --> Helper loaded: my_helper
INFO - 2021-11-19 08:47:52 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:47:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:47:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:47:52 --> Controller Class Initialized
DEBUG - 2021-11-19 08:47:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-19 08:47:53 --> Final output sent to browser
DEBUG - 2021-11-19 08:47:53 --> Total execution time: 0.2382
INFO - 2021-11-19 08:49:12 --> Config Class Initialized
INFO - 2021-11-19 08:49:12 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:49:12 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:49:12 --> Utf8 Class Initialized
INFO - 2021-11-19 08:49:12 --> URI Class Initialized
INFO - 2021-11-19 08:49:12 --> Router Class Initialized
INFO - 2021-11-19 08:49:12 --> Output Class Initialized
INFO - 2021-11-19 08:49:12 --> Security Class Initialized
DEBUG - 2021-11-19 08:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:49:12 --> Input Class Initialized
INFO - 2021-11-19 08:49:12 --> Language Class Initialized
INFO - 2021-11-19 08:49:12 --> Language Class Initialized
INFO - 2021-11-19 08:49:12 --> Config Class Initialized
INFO - 2021-11-19 08:49:12 --> Loader Class Initialized
INFO - 2021-11-19 08:49:12 --> Helper loaded: url_helper
INFO - 2021-11-19 08:49:12 --> Helper loaded: file_helper
INFO - 2021-11-19 08:49:12 --> Helper loaded: form_helper
INFO - 2021-11-19 08:49:12 --> Helper loaded: my_helper
INFO - 2021-11-19 08:49:12 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:49:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:49:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:49:12 --> Controller Class Initialized
DEBUG - 2021-11-19 08:49:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-19 08:49:13 --> Final output sent to browser
DEBUG - 2021-11-19 08:49:13 --> Total execution time: 0.1664
INFO - 2021-11-19 08:49:29 --> Config Class Initialized
INFO - 2021-11-19 08:49:29 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:49:29 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:49:29 --> Utf8 Class Initialized
INFO - 2021-11-19 08:49:29 --> URI Class Initialized
INFO - 2021-11-19 08:49:29 --> Router Class Initialized
INFO - 2021-11-19 08:49:29 --> Output Class Initialized
INFO - 2021-11-19 08:49:29 --> Security Class Initialized
DEBUG - 2021-11-19 08:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:49:29 --> Input Class Initialized
INFO - 2021-11-19 08:49:29 --> Language Class Initialized
INFO - 2021-11-19 08:49:29 --> Language Class Initialized
INFO - 2021-11-19 08:49:29 --> Config Class Initialized
INFO - 2021-11-19 08:49:29 --> Loader Class Initialized
INFO - 2021-11-19 08:49:29 --> Helper loaded: url_helper
INFO - 2021-11-19 08:49:29 --> Helper loaded: file_helper
INFO - 2021-11-19 08:49:29 --> Helper loaded: form_helper
INFO - 2021-11-19 08:49:29 --> Helper loaded: my_helper
INFO - 2021-11-19 08:49:29 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:49:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:49:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:49:29 --> Controller Class Initialized
DEBUG - 2021-11-19 08:49:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-19 08:49:30 --> Final output sent to browser
DEBUG - 2021-11-19 08:49:30 --> Total execution time: 0.1536
INFO - 2021-11-19 08:49:36 --> Config Class Initialized
INFO - 2021-11-19 08:49:36 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:49:36 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:49:36 --> Utf8 Class Initialized
INFO - 2021-11-19 08:49:36 --> URI Class Initialized
INFO - 2021-11-19 08:49:36 --> Router Class Initialized
INFO - 2021-11-19 08:49:36 --> Output Class Initialized
INFO - 2021-11-19 08:49:36 --> Security Class Initialized
DEBUG - 2021-11-19 08:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:49:36 --> Input Class Initialized
INFO - 2021-11-19 08:49:36 --> Language Class Initialized
INFO - 2021-11-19 08:49:36 --> Language Class Initialized
INFO - 2021-11-19 08:49:36 --> Config Class Initialized
INFO - 2021-11-19 08:49:36 --> Loader Class Initialized
INFO - 2021-11-19 08:49:36 --> Helper loaded: url_helper
INFO - 2021-11-19 08:49:36 --> Helper loaded: file_helper
INFO - 2021-11-19 08:49:36 --> Helper loaded: form_helper
INFO - 2021-11-19 08:49:36 --> Helper loaded: my_helper
INFO - 2021-11-19 08:49:36 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:49:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:49:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:49:36 --> Controller Class Initialized
DEBUG - 2021-11-19 08:49:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-19 08:49:36 --> Final output sent to browser
DEBUG - 2021-11-19 08:49:36 --> Total execution time: 0.1355
INFO - 2021-11-19 08:49:43 --> Config Class Initialized
INFO - 2021-11-19 08:49:43 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:49:43 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:49:43 --> Utf8 Class Initialized
INFO - 2021-11-19 08:49:43 --> URI Class Initialized
INFO - 2021-11-19 08:49:43 --> Router Class Initialized
INFO - 2021-11-19 08:49:43 --> Output Class Initialized
INFO - 2021-11-19 08:49:43 --> Security Class Initialized
DEBUG - 2021-11-19 08:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:49:43 --> Input Class Initialized
INFO - 2021-11-19 08:49:43 --> Language Class Initialized
INFO - 2021-11-19 08:49:43 --> Language Class Initialized
INFO - 2021-11-19 08:49:43 --> Config Class Initialized
INFO - 2021-11-19 08:49:43 --> Loader Class Initialized
INFO - 2021-11-19 08:49:43 --> Helper loaded: url_helper
INFO - 2021-11-19 08:49:43 --> Helper loaded: file_helper
INFO - 2021-11-19 08:49:43 --> Helper loaded: form_helper
INFO - 2021-11-19 08:49:43 --> Helper loaded: my_helper
INFO - 2021-11-19 08:49:43 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:49:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:49:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:49:43 --> Controller Class Initialized
DEBUG - 2021-11-19 08:49:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-19 08:49:43 --> Final output sent to browser
DEBUG - 2021-11-19 08:49:43 --> Total execution time: 0.1432
INFO - 2021-11-19 08:49:51 --> Config Class Initialized
INFO - 2021-11-19 08:49:51 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:49:51 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:49:51 --> Utf8 Class Initialized
INFO - 2021-11-19 08:49:51 --> URI Class Initialized
INFO - 2021-11-19 08:49:51 --> Router Class Initialized
INFO - 2021-11-19 08:49:51 --> Output Class Initialized
INFO - 2021-11-19 08:49:51 --> Security Class Initialized
DEBUG - 2021-11-19 08:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:49:51 --> Input Class Initialized
INFO - 2021-11-19 08:49:51 --> Language Class Initialized
INFO - 2021-11-19 08:49:51 --> Language Class Initialized
INFO - 2021-11-19 08:49:51 --> Config Class Initialized
INFO - 2021-11-19 08:49:51 --> Loader Class Initialized
INFO - 2021-11-19 08:49:51 --> Helper loaded: url_helper
INFO - 2021-11-19 08:49:51 --> Helper loaded: file_helper
INFO - 2021-11-19 08:49:51 --> Helper loaded: form_helper
INFO - 2021-11-19 08:49:51 --> Helper loaded: my_helper
INFO - 2021-11-19 08:49:51 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:49:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:49:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:49:51 --> Controller Class Initialized
DEBUG - 2021-11-19 08:49:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-19 08:49:51 --> Final output sent to browser
DEBUG - 2021-11-19 08:49:51 --> Total execution time: 0.1328
INFO - 2021-11-19 08:50:08 --> Config Class Initialized
INFO - 2021-11-19 08:50:08 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:50:08 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:50:08 --> Utf8 Class Initialized
INFO - 2021-11-19 08:50:08 --> URI Class Initialized
INFO - 2021-11-19 08:50:08 --> Router Class Initialized
INFO - 2021-11-19 08:50:08 --> Output Class Initialized
INFO - 2021-11-19 08:50:08 --> Security Class Initialized
DEBUG - 2021-11-19 08:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:50:08 --> Input Class Initialized
INFO - 2021-11-19 08:50:08 --> Language Class Initialized
INFO - 2021-11-19 08:50:08 --> Language Class Initialized
INFO - 2021-11-19 08:50:08 --> Config Class Initialized
INFO - 2021-11-19 08:50:08 --> Loader Class Initialized
INFO - 2021-11-19 08:50:08 --> Helper loaded: url_helper
INFO - 2021-11-19 08:50:08 --> Helper loaded: file_helper
INFO - 2021-11-19 08:50:08 --> Helper loaded: form_helper
INFO - 2021-11-19 08:50:08 --> Helper loaded: my_helper
INFO - 2021-11-19 08:50:08 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:50:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:50:08 --> Controller Class Initialized
DEBUG - 2021-11-19 08:50:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-19 08:50:08 --> Final output sent to browser
DEBUG - 2021-11-19 08:50:08 --> Total execution time: 0.1591
INFO - 2021-11-19 08:50:23 --> Config Class Initialized
INFO - 2021-11-19 08:50:23 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:50:23 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:50:23 --> Utf8 Class Initialized
INFO - 2021-11-19 08:50:23 --> URI Class Initialized
INFO - 2021-11-19 08:50:23 --> Router Class Initialized
INFO - 2021-11-19 08:50:23 --> Output Class Initialized
INFO - 2021-11-19 08:50:23 --> Security Class Initialized
DEBUG - 2021-11-19 08:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:50:23 --> Input Class Initialized
INFO - 2021-11-19 08:50:23 --> Language Class Initialized
INFO - 2021-11-19 08:50:23 --> Language Class Initialized
INFO - 2021-11-19 08:50:23 --> Config Class Initialized
INFO - 2021-11-19 08:50:23 --> Loader Class Initialized
INFO - 2021-11-19 08:50:23 --> Helper loaded: url_helper
INFO - 2021-11-19 08:50:23 --> Helper loaded: file_helper
INFO - 2021-11-19 08:50:23 --> Helper loaded: form_helper
INFO - 2021-11-19 08:50:23 --> Helper loaded: my_helper
INFO - 2021-11-19 08:50:23 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:50:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:50:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:50:23 --> Controller Class Initialized
DEBUG - 2021-11-19 08:50:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-19 08:50:23 --> Final output sent to browser
DEBUG - 2021-11-19 08:50:23 --> Total execution time: 0.1286
INFO - 2021-11-19 08:50:48 --> Config Class Initialized
INFO - 2021-11-19 08:50:48 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:50:48 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:50:48 --> Utf8 Class Initialized
INFO - 2021-11-19 08:50:48 --> URI Class Initialized
INFO - 2021-11-19 08:50:48 --> Router Class Initialized
INFO - 2021-11-19 08:50:48 --> Output Class Initialized
INFO - 2021-11-19 08:50:48 --> Security Class Initialized
DEBUG - 2021-11-19 08:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:50:48 --> Input Class Initialized
INFO - 2021-11-19 08:50:48 --> Language Class Initialized
INFO - 2021-11-19 08:50:48 --> Language Class Initialized
INFO - 2021-11-19 08:50:48 --> Config Class Initialized
INFO - 2021-11-19 08:50:48 --> Loader Class Initialized
INFO - 2021-11-19 08:50:48 --> Helper loaded: url_helper
INFO - 2021-11-19 08:50:48 --> Helper loaded: file_helper
INFO - 2021-11-19 08:50:48 --> Helper loaded: form_helper
INFO - 2021-11-19 08:50:48 --> Helper loaded: my_helper
INFO - 2021-11-19 08:50:48 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:50:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:50:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:50:48 --> Controller Class Initialized
INFO - 2021-11-19 08:50:48 --> Helper loaded: cookie_helper
INFO - 2021-11-19 08:50:48 --> Config Class Initialized
INFO - 2021-11-19 08:50:48 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:50:48 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:50:48 --> Utf8 Class Initialized
INFO - 2021-11-19 08:50:48 --> URI Class Initialized
INFO - 2021-11-19 08:50:48 --> Router Class Initialized
INFO - 2021-11-19 08:50:48 --> Output Class Initialized
INFO - 2021-11-19 08:50:48 --> Security Class Initialized
DEBUG - 2021-11-19 08:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:50:48 --> Input Class Initialized
INFO - 2021-11-19 08:50:48 --> Language Class Initialized
INFO - 2021-11-19 08:50:48 --> Language Class Initialized
INFO - 2021-11-19 08:50:48 --> Config Class Initialized
INFO - 2021-11-19 08:50:48 --> Loader Class Initialized
INFO - 2021-11-19 08:50:48 --> Helper loaded: url_helper
INFO - 2021-11-19 08:50:48 --> Helper loaded: file_helper
INFO - 2021-11-19 08:50:48 --> Helper loaded: form_helper
INFO - 2021-11-19 08:50:48 --> Helper loaded: my_helper
INFO - 2021-11-19 08:50:48 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:50:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:50:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:50:48 --> Controller Class Initialized
DEBUG - 2021-11-19 08:50:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-11-19 08:50:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 08:50:48 --> Final output sent to browser
DEBUG - 2021-11-19 08:50:48 --> Total execution time: 0.0611
INFO - 2021-11-19 08:50:50 --> Config Class Initialized
INFO - 2021-11-19 08:50:50 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:50:50 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:50:50 --> Utf8 Class Initialized
INFO - 2021-11-19 08:50:50 --> URI Class Initialized
INFO - 2021-11-19 08:50:50 --> Router Class Initialized
INFO - 2021-11-19 08:50:50 --> Output Class Initialized
INFO - 2021-11-19 08:50:50 --> Security Class Initialized
DEBUG - 2021-11-19 08:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:50:50 --> Input Class Initialized
INFO - 2021-11-19 08:50:50 --> Language Class Initialized
INFO - 2021-11-19 08:50:50 --> Language Class Initialized
INFO - 2021-11-19 08:50:50 --> Config Class Initialized
INFO - 2021-11-19 08:50:50 --> Loader Class Initialized
INFO - 2021-11-19 08:50:50 --> Helper loaded: url_helper
INFO - 2021-11-19 08:50:50 --> Helper loaded: file_helper
INFO - 2021-11-19 08:50:50 --> Helper loaded: form_helper
INFO - 2021-11-19 08:50:50 --> Helper loaded: my_helper
INFO - 2021-11-19 08:50:50 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:50:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:50:50 --> Controller Class Initialized
INFO - 2021-11-19 08:50:50 --> Helper loaded: cookie_helper
INFO - 2021-11-19 08:50:50 --> Final output sent to browser
DEBUG - 2021-11-19 08:50:50 --> Total execution time: 0.0843
INFO - 2021-11-19 08:50:51 --> Config Class Initialized
INFO - 2021-11-19 08:50:51 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:50:51 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:50:51 --> Utf8 Class Initialized
INFO - 2021-11-19 08:50:51 --> URI Class Initialized
INFO - 2021-11-19 08:50:51 --> Router Class Initialized
INFO - 2021-11-19 08:50:51 --> Output Class Initialized
INFO - 2021-11-19 08:50:51 --> Security Class Initialized
DEBUG - 2021-11-19 08:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:50:51 --> Input Class Initialized
INFO - 2021-11-19 08:50:51 --> Language Class Initialized
INFO - 2021-11-19 08:50:51 --> Language Class Initialized
INFO - 2021-11-19 08:50:51 --> Config Class Initialized
INFO - 2021-11-19 08:50:51 --> Loader Class Initialized
INFO - 2021-11-19 08:50:51 --> Helper loaded: url_helper
INFO - 2021-11-19 08:50:51 --> Helper loaded: file_helper
INFO - 2021-11-19 08:50:51 --> Helper loaded: form_helper
INFO - 2021-11-19 08:50:51 --> Helper loaded: my_helper
INFO - 2021-11-19 08:50:51 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:50:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:50:51 --> Controller Class Initialized
DEBUG - 2021-11-19 08:50:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-11-19 08:50:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 08:50:52 --> Final output sent to browser
DEBUG - 2021-11-19 08:50:52 --> Total execution time: 1.2073
INFO - 2021-11-19 08:50:54 --> Config Class Initialized
INFO - 2021-11-19 08:50:54 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:50:54 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:50:54 --> Utf8 Class Initialized
INFO - 2021-11-19 08:50:54 --> URI Class Initialized
INFO - 2021-11-19 08:50:54 --> Router Class Initialized
INFO - 2021-11-19 08:50:54 --> Output Class Initialized
INFO - 2021-11-19 08:50:54 --> Security Class Initialized
DEBUG - 2021-11-19 08:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:50:54 --> Input Class Initialized
INFO - 2021-11-19 08:50:54 --> Language Class Initialized
INFO - 2021-11-19 08:50:54 --> Language Class Initialized
INFO - 2021-11-19 08:50:54 --> Config Class Initialized
INFO - 2021-11-19 08:50:54 --> Loader Class Initialized
INFO - 2021-11-19 08:50:54 --> Helper loaded: url_helper
INFO - 2021-11-19 08:50:54 --> Helper loaded: file_helper
INFO - 2021-11-19 08:50:54 --> Helper loaded: form_helper
INFO - 2021-11-19 08:50:54 --> Helper loaded: my_helper
INFO - 2021-11-19 08:50:54 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:50:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:50:54 --> Controller Class Initialized
DEBUG - 2021-11-19 08:50:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-11-19 08:50:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 08:50:54 --> Final output sent to browser
DEBUG - 2021-11-19 08:50:54 --> Total execution time: 0.0990
INFO - 2021-11-19 08:50:56 --> Config Class Initialized
INFO - 2021-11-19 08:50:56 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:50:56 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:50:56 --> Utf8 Class Initialized
INFO - 2021-11-19 08:50:56 --> URI Class Initialized
INFO - 2021-11-19 08:50:56 --> Router Class Initialized
INFO - 2021-11-19 08:50:56 --> Output Class Initialized
INFO - 2021-11-19 08:50:56 --> Security Class Initialized
DEBUG - 2021-11-19 08:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:50:56 --> Input Class Initialized
INFO - 2021-11-19 08:50:56 --> Language Class Initialized
INFO - 2021-11-19 08:50:56 --> Language Class Initialized
INFO - 2021-11-19 08:50:56 --> Config Class Initialized
INFO - 2021-11-19 08:50:56 --> Loader Class Initialized
INFO - 2021-11-19 08:50:56 --> Helper loaded: url_helper
INFO - 2021-11-19 08:50:56 --> Helper loaded: file_helper
INFO - 2021-11-19 08:50:56 --> Helper loaded: form_helper
INFO - 2021-11-19 08:50:56 --> Helper loaded: my_helper
INFO - 2021-11-19 08:50:56 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:50:56 --> Controller Class Initialized
DEBUG - 2021-11-19 08:50:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-19 08:50:56 --> Final output sent to browser
DEBUG - 2021-11-19 08:50:56 --> Total execution time: 0.2130
INFO - 2021-11-19 08:51:43 --> Config Class Initialized
INFO - 2021-11-19 08:51:43 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:51:43 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:51:43 --> Utf8 Class Initialized
INFO - 2021-11-19 08:51:43 --> URI Class Initialized
INFO - 2021-11-19 08:51:43 --> Router Class Initialized
INFO - 2021-11-19 08:51:43 --> Output Class Initialized
INFO - 2021-11-19 08:51:43 --> Security Class Initialized
DEBUG - 2021-11-19 08:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:51:43 --> Input Class Initialized
INFO - 2021-11-19 08:51:43 --> Language Class Initialized
INFO - 2021-11-19 08:51:43 --> Language Class Initialized
INFO - 2021-11-19 08:51:43 --> Config Class Initialized
INFO - 2021-11-19 08:51:43 --> Loader Class Initialized
INFO - 2021-11-19 08:51:43 --> Helper loaded: url_helper
INFO - 2021-11-19 08:51:43 --> Helper loaded: file_helper
INFO - 2021-11-19 08:51:43 --> Helper loaded: form_helper
INFO - 2021-11-19 08:51:43 --> Helper loaded: my_helper
INFO - 2021-11-19 08:51:43 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:51:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:51:43 --> Controller Class Initialized
DEBUG - 2021-11-19 08:51:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-19 08:51:43 --> Final output sent to browser
DEBUG - 2021-11-19 08:51:43 --> Total execution time: 0.1704
INFO - 2021-11-19 08:52:26 --> Config Class Initialized
INFO - 2021-11-19 08:52:26 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:52:26 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:52:26 --> Utf8 Class Initialized
INFO - 2021-11-19 08:52:26 --> URI Class Initialized
INFO - 2021-11-19 08:52:26 --> Router Class Initialized
INFO - 2021-11-19 08:52:26 --> Output Class Initialized
INFO - 2021-11-19 08:52:26 --> Security Class Initialized
DEBUG - 2021-11-19 08:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:52:26 --> Input Class Initialized
INFO - 2021-11-19 08:52:26 --> Language Class Initialized
INFO - 2021-11-19 08:52:26 --> Language Class Initialized
INFO - 2021-11-19 08:52:26 --> Config Class Initialized
INFO - 2021-11-19 08:52:26 --> Loader Class Initialized
INFO - 2021-11-19 08:52:26 --> Helper loaded: url_helper
INFO - 2021-11-19 08:52:26 --> Helper loaded: file_helper
INFO - 2021-11-19 08:52:26 --> Helper loaded: form_helper
INFO - 2021-11-19 08:52:26 --> Helper loaded: my_helper
INFO - 2021-11-19 08:52:26 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:52:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:52:26 --> Controller Class Initialized
DEBUG - 2021-11-19 08:52:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-19 08:52:26 --> Final output sent to browser
DEBUG - 2021-11-19 08:52:26 --> Total execution time: 0.1373
INFO - 2021-11-19 08:53:07 --> Config Class Initialized
INFO - 2021-11-19 08:53:07 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:53:07 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:53:07 --> Utf8 Class Initialized
INFO - 2021-11-19 08:53:07 --> URI Class Initialized
INFO - 2021-11-19 08:53:07 --> Router Class Initialized
INFO - 2021-11-19 08:53:07 --> Output Class Initialized
INFO - 2021-11-19 08:53:07 --> Security Class Initialized
DEBUG - 2021-11-19 08:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:53:07 --> Input Class Initialized
INFO - 2021-11-19 08:53:07 --> Language Class Initialized
INFO - 2021-11-19 08:53:07 --> Language Class Initialized
INFO - 2021-11-19 08:53:07 --> Config Class Initialized
INFO - 2021-11-19 08:53:07 --> Loader Class Initialized
INFO - 2021-11-19 08:53:07 --> Helper loaded: url_helper
INFO - 2021-11-19 08:53:07 --> Helper loaded: file_helper
INFO - 2021-11-19 08:53:07 --> Helper loaded: form_helper
INFO - 2021-11-19 08:53:07 --> Helper loaded: my_helper
INFO - 2021-11-19 08:53:07 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:53:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:53:07 --> Controller Class Initialized
DEBUG - 2021-11-19 08:53:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-19 08:53:07 --> Final output sent to browser
DEBUG - 2021-11-19 08:53:07 --> Total execution time: 0.1404
INFO - 2021-11-19 08:53:35 --> Config Class Initialized
INFO - 2021-11-19 08:53:35 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:53:35 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:53:35 --> Utf8 Class Initialized
INFO - 2021-11-19 08:53:35 --> URI Class Initialized
INFO - 2021-11-19 08:53:35 --> Router Class Initialized
INFO - 2021-11-19 08:53:35 --> Output Class Initialized
INFO - 2021-11-19 08:53:35 --> Security Class Initialized
DEBUG - 2021-11-19 08:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:53:35 --> Input Class Initialized
INFO - 2021-11-19 08:53:35 --> Language Class Initialized
INFO - 2021-11-19 08:53:35 --> Language Class Initialized
INFO - 2021-11-19 08:53:35 --> Config Class Initialized
INFO - 2021-11-19 08:53:35 --> Loader Class Initialized
INFO - 2021-11-19 08:53:35 --> Helper loaded: url_helper
INFO - 2021-11-19 08:53:35 --> Helper loaded: file_helper
INFO - 2021-11-19 08:53:35 --> Helper loaded: form_helper
INFO - 2021-11-19 08:53:35 --> Helper loaded: my_helper
INFO - 2021-11-19 08:53:35 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:53:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:53:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:53:35 --> Controller Class Initialized
DEBUG - 2021-11-19 08:53:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-19 08:53:35 --> Final output sent to browser
DEBUG - 2021-11-19 08:53:35 --> Total execution time: 0.1584
INFO - 2021-11-19 08:53:58 --> Config Class Initialized
INFO - 2021-11-19 08:53:58 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:53:58 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:53:58 --> Utf8 Class Initialized
INFO - 2021-11-19 08:53:58 --> URI Class Initialized
INFO - 2021-11-19 08:53:58 --> Router Class Initialized
INFO - 2021-11-19 08:53:58 --> Output Class Initialized
INFO - 2021-11-19 08:53:58 --> Security Class Initialized
DEBUG - 2021-11-19 08:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:53:58 --> Input Class Initialized
INFO - 2021-11-19 08:53:58 --> Language Class Initialized
INFO - 2021-11-19 08:53:58 --> Language Class Initialized
INFO - 2021-11-19 08:53:58 --> Config Class Initialized
INFO - 2021-11-19 08:53:58 --> Loader Class Initialized
INFO - 2021-11-19 08:53:58 --> Helper loaded: url_helper
INFO - 2021-11-19 08:53:58 --> Helper loaded: file_helper
INFO - 2021-11-19 08:53:58 --> Helper loaded: form_helper
INFO - 2021-11-19 08:53:58 --> Helper loaded: my_helper
INFO - 2021-11-19 08:53:58 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:53:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:53:58 --> Controller Class Initialized
DEBUG - 2021-11-19 08:53:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-19 08:53:58 --> Final output sent to browser
DEBUG - 2021-11-19 08:53:58 --> Total execution time: 0.1626
INFO - 2021-11-19 08:54:08 --> Config Class Initialized
INFO - 2021-11-19 08:54:08 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:54:08 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:54:08 --> Utf8 Class Initialized
INFO - 2021-11-19 08:54:08 --> URI Class Initialized
INFO - 2021-11-19 08:54:08 --> Router Class Initialized
INFO - 2021-11-19 08:54:08 --> Output Class Initialized
INFO - 2021-11-19 08:54:08 --> Security Class Initialized
DEBUG - 2021-11-19 08:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:54:08 --> Input Class Initialized
INFO - 2021-11-19 08:54:08 --> Language Class Initialized
INFO - 2021-11-19 08:54:08 --> Language Class Initialized
INFO - 2021-11-19 08:54:08 --> Config Class Initialized
INFO - 2021-11-19 08:54:08 --> Loader Class Initialized
INFO - 2021-11-19 08:54:08 --> Helper loaded: url_helper
INFO - 2021-11-19 08:54:08 --> Helper loaded: file_helper
INFO - 2021-11-19 08:54:08 --> Helper loaded: form_helper
INFO - 2021-11-19 08:54:08 --> Helper loaded: my_helper
INFO - 2021-11-19 08:54:08 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:54:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:54:08 --> Controller Class Initialized
DEBUG - 2021-11-19 08:54:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-19 08:54:08 --> Final output sent to browser
DEBUG - 2021-11-19 08:54:08 --> Total execution time: 0.1487
INFO - 2021-11-19 08:55:14 --> Config Class Initialized
INFO - 2021-11-19 08:55:14 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:55:14 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:55:14 --> Utf8 Class Initialized
INFO - 2021-11-19 08:55:14 --> URI Class Initialized
INFO - 2021-11-19 08:55:14 --> Router Class Initialized
INFO - 2021-11-19 08:55:14 --> Output Class Initialized
INFO - 2021-11-19 08:55:14 --> Security Class Initialized
DEBUG - 2021-11-19 08:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:55:14 --> Input Class Initialized
INFO - 2021-11-19 08:55:14 --> Language Class Initialized
INFO - 2021-11-19 08:55:14 --> Language Class Initialized
INFO - 2021-11-19 08:55:14 --> Config Class Initialized
INFO - 2021-11-19 08:55:14 --> Loader Class Initialized
INFO - 2021-11-19 08:55:14 --> Helper loaded: url_helper
INFO - 2021-11-19 08:55:14 --> Helper loaded: file_helper
INFO - 2021-11-19 08:55:14 --> Helper loaded: form_helper
INFO - 2021-11-19 08:55:14 --> Helper loaded: my_helper
INFO - 2021-11-19 08:55:14 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:55:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:55:14 --> Controller Class Initialized
DEBUG - 2021-11-19 08:55:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-19 08:55:14 --> Final output sent to browser
DEBUG - 2021-11-19 08:55:14 --> Total execution time: 0.1541
INFO - 2021-11-19 08:59:56 --> Config Class Initialized
INFO - 2021-11-19 08:59:56 --> Hooks Class Initialized
DEBUG - 2021-11-19 08:59:56 --> UTF-8 Support Enabled
INFO - 2021-11-19 08:59:56 --> Utf8 Class Initialized
INFO - 2021-11-19 08:59:56 --> URI Class Initialized
INFO - 2021-11-19 08:59:56 --> Router Class Initialized
INFO - 2021-11-19 08:59:56 --> Output Class Initialized
INFO - 2021-11-19 08:59:56 --> Security Class Initialized
DEBUG - 2021-11-19 08:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 08:59:56 --> Input Class Initialized
INFO - 2021-11-19 08:59:56 --> Language Class Initialized
INFO - 2021-11-19 08:59:56 --> Language Class Initialized
INFO - 2021-11-19 08:59:56 --> Config Class Initialized
INFO - 2021-11-19 08:59:56 --> Loader Class Initialized
INFO - 2021-11-19 08:59:56 --> Helper loaded: url_helper
INFO - 2021-11-19 08:59:56 --> Helper loaded: file_helper
INFO - 2021-11-19 08:59:56 --> Helper loaded: form_helper
INFO - 2021-11-19 08:59:56 --> Helper loaded: my_helper
INFO - 2021-11-19 08:59:56 --> Database Driver Class Initialized
DEBUG - 2021-11-19 08:59:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 08:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 08:59:56 --> Controller Class Initialized
DEBUG - 2021-11-19 08:59:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-19 08:59:56 --> Final output sent to browser
DEBUG - 2021-11-19 08:59:56 --> Total execution time: 0.2045
INFO - 2021-11-19 09:00:10 --> Config Class Initialized
INFO - 2021-11-19 09:00:10 --> Hooks Class Initialized
DEBUG - 2021-11-19 09:00:10 --> UTF-8 Support Enabled
INFO - 2021-11-19 09:00:10 --> Utf8 Class Initialized
INFO - 2021-11-19 09:00:10 --> URI Class Initialized
INFO - 2021-11-19 09:00:10 --> Router Class Initialized
INFO - 2021-11-19 09:00:10 --> Output Class Initialized
INFO - 2021-11-19 09:00:10 --> Security Class Initialized
DEBUG - 2021-11-19 09:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 09:00:10 --> Input Class Initialized
INFO - 2021-11-19 09:00:10 --> Language Class Initialized
INFO - 2021-11-19 09:00:10 --> Language Class Initialized
INFO - 2021-11-19 09:00:10 --> Config Class Initialized
INFO - 2021-11-19 09:00:10 --> Loader Class Initialized
INFO - 2021-11-19 09:00:10 --> Helper loaded: url_helper
INFO - 2021-11-19 09:00:10 --> Helper loaded: file_helper
INFO - 2021-11-19 09:00:10 --> Helper loaded: form_helper
INFO - 2021-11-19 09:00:10 --> Helper loaded: my_helper
INFO - 2021-11-19 09:00:10 --> Database Driver Class Initialized
DEBUG - 2021-11-19 09:00:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 09:00:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 09:00:10 --> Controller Class Initialized
DEBUG - 2021-11-19 09:00:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-19 09:00:10 --> Final output sent to browser
DEBUG - 2021-11-19 09:00:10 --> Total execution time: 0.1361
INFO - 2021-11-19 09:00:29 --> Config Class Initialized
INFO - 2021-11-19 09:00:29 --> Hooks Class Initialized
DEBUG - 2021-11-19 09:00:29 --> UTF-8 Support Enabled
INFO - 2021-11-19 09:00:29 --> Utf8 Class Initialized
INFO - 2021-11-19 09:00:29 --> URI Class Initialized
INFO - 2021-11-19 09:00:29 --> Router Class Initialized
INFO - 2021-11-19 09:00:29 --> Output Class Initialized
INFO - 2021-11-19 09:00:29 --> Security Class Initialized
DEBUG - 2021-11-19 09:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 09:00:29 --> Input Class Initialized
INFO - 2021-11-19 09:00:29 --> Language Class Initialized
INFO - 2021-11-19 09:00:29 --> Language Class Initialized
INFO - 2021-11-19 09:00:29 --> Config Class Initialized
INFO - 2021-11-19 09:00:29 --> Loader Class Initialized
INFO - 2021-11-19 09:00:29 --> Helper loaded: url_helper
INFO - 2021-11-19 09:00:29 --> Helper loaded: file_helper
INFO - 2021-11-19 09:00:29 --> Helper loaded: form_helper
INFO - 2021-11-19 09:00:29 --> Helper loaded: my_helper
INFO - 2021-11-19 09:00:29 --> Database Driver Class Initialized
DEBUG - 2021-11-19 09:00:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 09:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 09:00:29 --> Controller Class Initialized
DEBUG - 2021-11-19 09:00:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-19 09:00:29 --> Final output sent to browser
DEBUG - 2021-11-19 09:00:29 --> Total execution time: 0.1563
INFO - 2021-11-19 09:00:38 --> Config Class Initialized
INFO - 2021-11-19 09:00:38 --> Hooks Class Initialized
DEBUG - 2021-11-19 09:00:38 --> UTF-8 Support Enabled
INFO - 2021-11-19 09:00:38 --> Utf8 Class Initialized
INFO - 2021-11-19 09:00:38 --> URI Class Initialized
INFO - 2021-11-19 09:00:38 --> Router Class Initialized
INFO - 2021-11-19 09:00:38 --> Output Class Initialized
INFO - 2021-11-19 09:00:38 --> Security Class Initialized
DEBUG - 2021-11-19 09:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 09:00:38 --> Input Class Initialized
INFO - 2021-11-19 09:00:38 --> Language Class Initialized
INFO - 2021-11-19 09:00:38 --> Language Class Initialized
INFO - 2021-11-19 09:00:38 --> Config Class Initialized
INFO - 2021-11-19 09:00:38 --> Loader Class Initialized
INFO - 2021-11-19 09:00:38 --> Helper loaded: url_helper
INFO - 2021-11-19 09:00:38 --> Helper loaded: file_helper
INFO - 2021-11-19 09:00:38 --> Helper loaded: form_helper
INFO - 2021-11-19 09:00:38 --> Helper loaded: my_helper
INFO - 2021-11-19 09:00:38 --> Database Driver Class Initialized
DEBUG - 2021-11-19 09:00:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 09:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 09:00:38 --> Controller Class Initialized
DEBUG - 2021-11-19 09:00:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-19 09:00:39 --> Final output sent to browser
DEBUG - 2021-11-19 09:00:39 --> Total execution time: 0.1284
INFO - 2021-11-19 09:01:17 --> Config Class Initialized
INFO - 2021-11-19 09:01:17 --> Hooks Class Initialized
DEBUG - 2021-11-19 09:01:17 --> UTF-8 Support Enabled
INFO - 2021-11-19 09:01:17 --> Utf8 Class Initialized
INFO - 2021-11-19 09:01:17 --> URI Class Initialized
INFO - 2021-11-19 09:01:17 --> Router Class Initialized
INFO - 2021-11-19 09:01:17 --> Output Class Initialized
INFO - 2021-11-19 09:01:17 --> Security Class Initialized
DEBUG - 2021-11-19 09:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 09:01:17 --> Input Class Initialized
INFO - 2021-11-19 09:01:17 --> Language Class Initialized
INFO - 2021-11-19 09:01:17 --> Language Class Initialized
INFO - 2021-11-19 09:01:17 --> Config Class Initialized
INFO - 2021-11-19 09:01:17 --> Loader Class Initialized
INFO - 2021-11-19 09:01:17 --> Helper loaded: url_helper
INFO - 2021-11-19 09:01:17 --> Helper loaded: file_helper
INFO - 2021-11-19 09:01:17 --> Helper loaded: form_helper
INFO - 2021-11-19 09:01:17 --> Helper loaded: my_helper
INFO - 2021-11-19 09:01:17 --> Database Driver Class Initialized
DEBUG - 2021-11-19 09:01:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 09:01:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 09:01:17 --> Controller Class Initialized
DEBUG - 2021-11-19 09:01:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-19 09:01:17 --> Final output sent to browser
DEBUG - 2021-11-19 09:01:17 --> Total execution time: 0.1612
INFO - 2021-11-19 09:01:27 --> Config Class Initialized
INFO - 2021-11-19 09:01:27 --> Hooks Class Initialized
DEBUG - 2021-11-19 09:01:27 --> UTF-8 Support Enabled
INFO - 2021-11-19 09:01:27 --> Utf8 Class Initialized
INFO - 2021-11-19 09:01:27 --> URI Class Initialized
INFO - 2021-11-19 09:01:27 --> Router Class Initialized
INFO - 2021-11-19 09:01:27 --> Output Class Initialized
INFO - 2021-11-19 09:01:27 --> Security Class Initialized
DEBUG - 2021-11-19 09:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 09:01:27 --> Input Class Initialized
INFO - 2021-11-19 09:01:27 --> Language Class Initialized
INFO - 2021-11-19 09:01:27 --> Language Class Initialized
INFO - 2021-11-19 09:01:27 --> Config Class Initialized
INFO - 2021-11-19 09:01:27 --> Loader Class Initialized
INFO - 2021-11-19 09:01:27 --> Helper loaded: url_helper
INFO - 2021-11-19 09:01:27 --> Helper loaded: file_helper
INFO - 2021-11-19 09:01:27 --> Helper loaded: form_helper
INFO - 2021-11-19 09:01:27 --> Helper loaded: my_helper
INFO - 2021-11-19 09:01:27 --> Database Driver Class Initialized
DEBUG - 2021-11-19 09:01:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 09:01:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 09:01:27 --> Controller Class Initialized
DEBUG - 2021-11-19 09:01:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-19 09:01:27 --> Final output sent to browser
DEBUG - 2021-11-19 09:01:27 --> Total execution time: 0.1531
INFO - 2021-11-19 09:02:25 --> Config Class Initialized
INFO - 2021-11-19 09:02:25 --> Hooks Class Initialized
DEBUG - 2021-11-19 09:02:25 --> UTF-8 Support Enabled
INFO - 2021-11-19 09:02:25 --> Utf8 Class Initialized
INFO - 2021-11-19 09:02:25 --> URI Class Initialized
INFO - 2021-11-19 09:02:25 --> Router Class Initialized
INFO - 2021-11-19 09:02:25 --> Output Class Initialized
INFO - 2021-11-19 09:02:25 --> Security Class Initialized
DEBUG - 2021-11-19 09:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 09:02:25 --> Input Class Initialized
INFO - 2021-11-19 09:02:25 --> Language Class Initialized
INFO - 2021-11-19 09:02:25 --> Language Class Initialized
INFO - 2021-11-19 09:02:25 --> Config Class Initialized
INFO - 2021-11-19 09:02:25 --> Loader Class Initialized
INFO - 2021-11-19 09:02:25 --> Helper loaded: url_helper
INFO - 2021-11-19 09:02:25 --> Helper loaded: file_helper
INFO - 2021-11-19 09:02:25 --> Helper loaded: form_helper
INFO - 2021-11-19 09:02:25 --> Helper loaded: my_helper
INFO - 2021-11-19 09:02:25 --> Database Driver Class Initialized
DEBUG - 2021-11-19 09:02:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 09:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 09:02:25 --> Controller Class Initialized
INFO - 2021-11-19 09:02:25 --> Helper loaded: cookie_helper
INFO - 2021-11-19 09:02:25 --> Config Class Initialized
INFO - 2021-11-19 09:02:25 --> Hooks Class Initialized
DEBUG - 2021-11-19 09:02:25 --> UTF-8 Support Enabled
INFO - 2021-11-19 09:02:25 --> Utf8 Class Initialized
INFO - 2021-11-19 09:02:25 --> URI Class Initialized
INFO - 2021-11-19 09:02:25 --> Router Class Initialized
INFO - 2021-11-19 09:02:25 --> Output Class Initialized
INFO - 2021-11-19 09:02:25 --> Security Class Initialized
DEBUG - 2021-11-19 09:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 09:02:25 --> Input Class Initialized
INFO - 2021-11-19 09:02:25 --> Language Class Initialized
INFO - 2021-11-19 09:02:25 --> Language Class Initialized
INFO - 2021-11-19 09:02:25 --> Config Class Initialized
INFO - 2021-11-19 09:02:25 --> Loader Class Initialized
INFO - 2021-11-19 09:02:25 --> Helper loaded: url_helper
INFO - 2021-11-19 09:02:25 --> Helper loaded: file_helper
INFO - 2021-11-19 09:02:25 --> Helper loaded: form_helper
INFO - 2021-11-19 09:02:25 --> Helper loaded: my_helper
INFO - 2021-11-19 09:02:25 --> Database Driver Class Initialized
DEBUG - 2021-11-19 09:02:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 09:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 09:02:25 --> Controller Class Initialized
DEBUG - 2021-11-19 09:02:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-11-19 09:02:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 09:02:25 --> Final output sent to browser
DEBUG - 2021-11-19 09:02:25 --> Total execution time: 0.0523
INFO - 2021-11-19 09:02:30 --> Config Class Initialized
INFO - 2021-11-19 09:02:30 --> Hooks Class Initialized
DEBUG - 2021-11-19 09:02:30 --> UTF-8 Support Enabled
INFO - 2021-11-19 09:02:30 --> Utf8 Class Initialized
INFO - 2021-11-19 09:02:30 --> URI Class Initialized
INFO - 2021-11-19 09:02:30 --> Router Class Initialized
INFO - 2021-11-19 09:02:30 --> Output Class Initialized
INFO - 2021-11-19 09:02:30 --> Security Class Initialized
DEBUG - 2021-11-19 09:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 09:02:30 --> Input Class Initialized
INFO - 2021-11-19 09:02:30 --> Language Class Initialized
INFO - 2021-11-19 09:02:30 --> Language Class Initialized
INFO - 2021-11-19 09:02:30 --> Config Class Initialized
INFO - 2021-11-19 09:02:30 --> Loader Class Initialized
INFO - 2021-11-19 09:02:30 --> Helper loaded: url_helper
INFO - 2021-11-19 09:02:30 --> Helper loaded: file_helper
INFO - 2021-11-19 09:02:30 --> Helper loaded: form_helper
INFO - 2021-11-19 09:02:30 --> Helper loaded: my_helper
INFO - 2021-11-19 09:02:30 --> Database Driver Class Initialized
DEBUG - 2021-11-19 09:02:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 09:02:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 09:02:30 --> Controller Class Initialized
INFO - 2021-11-19 09:02:30 --> Helper loaded: cookie_helper
INFO - 2021-11-19 09:02:30 --> Final output sent to browser
DEBUG - 2021-11-19 09:02:30 --> Total execution time: 0.0916
INFO - 2021-11-19 09:02:30 --> Config Class Initialized
INFO - 2021-11-19 09:02:30 --> Hooks Class Initialized
DEBUG - 2021-11-19 09:02:30 --> UTF-8 Support Enabled
INFO - 2021-11-19 09:02:30 --> Utf8 Class Initialized
INFO - 2021-11-19 09:02:30 --> URI Class Initialized
INFO - 2021-11-19 09:02:30 --> Router Class Initialized
INFO - 2021-11-19 09:02:30 --> Output Class Initialized
INFO - 2021-11-19 09:02:30 --> Security Class Initialized
DEBUG - 2021-11-19 09:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 09:02:30 --> Input Class Initialized
INFO - 2021-11-19 09:02:30 --> Language Class Initialized
INFO - 2021-11-19 09:02:30 --> Language Class Initialized
INFO - 2021-11-19 09:02:30 --> Config Class Initialized
INFO - 2021-11-19 09:02:30 --> Loader Class Initialized
INFO - 2021-11-19 09:02:30 --> Helper loaded: url_helper
INFO - 2021-11-19 09:02:30 --> Helper loaded: file_helper
INFO - 2021-11-19 09:02:30 --> Helper loaded: form_helper
INFO - 2021-11-19 09:02:30 --> Helper loaded: my_helper
INFO - 2021-11-19 09:02:30 --> Database Driver Class Initialized
DEBUG - 2021-11-19 09:02:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 09:02:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 09:02:30 --> Controller Class Initialized
DEBUG - 2021-11-19 09:02:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-11-19 09:02:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 09:02:31 --> Final output sent to browser
DEBUG - 2021-11-19 09:02:31 --> Total execution time: 1.0976
INFO - 2021-11-19 09:02:34 --> Config Class Initialized
INFO - 2021-11-19 09:02:34 --> Hooks Class Initialized
DEBUG - 2021-11-19 09:02:34 --> UTF-8 Support Enabled
INFO - 2021-11-19 09:02:34 --> Utf8 Class Initialized
INFO - 2021-11-19 09:02:34 --> URI Class Initialized
INFO - 2021-11-19 09:02:34 --> Router Class Initialized
INFO - 2021-11-19 09:02:34 --> Output Class Initialized
INFO - 2021-11-19 09:02:34 --> Security Class Initialized
DEBUG - 2021-11-19 09:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 09:02:34 --> Input Class Initialized
INFO - 2021-11-19 09:02:34 --> Language Class Initialized
INFO - 2021-11-19 09:02:34 --> Language Class Initialized
INFO - 2021-11-19 09:02:34 --> Config Class Initialized
INFO - 2021-11-19 09:02:34 --> Loader Class Initialized
INFO - 2021-11-19 09:02:34 --> Helper loaded: url_helper
INFO - 2021-11-19 09:02:34 --> Helper loaded: file_helper
INFO - 2021-11-19 09:02:34 --> Helper loaded: form_helper
INFO - 2021-11-19 09:02:34 --> Helper loaded: my_helper
INFO - 2021-11-19 09:02:34 --> Database Driver Class Initialized
DEBUG - 2021-11-19 09:02:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 09:02:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 09:02:34 --> Controller Class Initialized
DEBUG - 2021-11-19 09:02:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-11-19 09:02:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 09:02:34 --> Final output sent to browser
DEBUG - 2021-11-19 09:02:34 --> Total execution time: 0.0869
INFO - 2021-11-19 09:02:37 --> Config Class Initialized
INFO - 2021-11-19 09:02:37 --> Hooks Class Initialized
DEBUG - 2021-11-19 09:02:37 --> UTF-8 Support Enabled
INFO - 2021-11-19 09:02:37 --> Utf8 Class Initialized
INFO - 2021-11-19 09:02:37 --> URI Class Initialized
INFO - 2021-11-19 09:02:37 --> Router Class Initialized
INFO - 2021-11-19 09:02:37 --> Output Class Initialized
INFO - 2021-11-19 09:02:37 --> Security Class Initialized
DEBUG - 2021-11-19 09:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 09:02:37 --> Input Class Initialized
INFO - 2021-11-19 09:02:37 --> Language Class Initialized
INFO - 2021-11-19 09:02:37 --> Language Class Initialized
INFO - 2021-11-19 09:02:37 --> Config Class Initialized
INFO - 2021-11-19 09:02:37 --> Loader Class Initialized
INFO - 2021-11-19 09:02:37 --> Helper loaded: url_helper
INFO - 2021-11-19 09:02:37 --> Helper loaded: file_helper
INFO - 2021-11-19 09:02:37 --> Helper loaded: form_helper
INFO - 2021-11-19 09:02:37 --> Helper loaded: my_helper
INFO - 2021-11-19 09:02:37 --> Database Driver Class Initialized
DEBUG - 2021-11-19 09:02:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 09:02:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 09:02:37 --> Controller Class Initialized
DEBUG - 2021-11-19 09:02:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-11-19 09:02:37 --> Final output sent to browser
DEBUG - 2021-11-19 09:02:37 --> Total execution time: 0.2296
INFO - 2021-11-19 09:03:39 --> Config Class Initialized
INFO - 2021-11-19 09:03:39 --> Hooks Class Initialized
DEBUG - 2021-11-19 09:03:39 --> UTF-8 Support Enabled
INFO - 2021-11-19 09:03:39 --> Utf8 Class Initialized
INFO - 2021-11-19 09:03:39 --> URI Class Initialized
INFO - 2021-11-19 09:03:39 --> Router Class Initialized
INFO - 2021-11-19 09:03:39 --> Output Class Initialized
INFO - 2021-11-19 09:03:39 --> Security Class Initialized
DEBUG - 2021-11-19 09:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 09:03:39 --> Input Class Initialized
INFO - 2021-11-19 09:03:39 --> Language Class Initialized
INFO - 2021-11-19 09:03:39 --> Language Class Initialized
INFO - 2021-11-19 09:03:39 --> Config Class Initialized
INFO - 2021-11-19 09:03:39 --> Loader Class Initialized
INFO - 2021-11-19 09:03:39 --> Helper loaded: url_helper
INFO - 2021-11-19 09:03:39 --> Helper loaded: file_helper
INFO - 2021-11-19 09:03:39 --> Helper loaded: form_helper
INFO - 2021-11-19 09:03:39 --> Helper loaded: my_helper
INFO - 2021-11-19 09:03:39 --> Database Driver Class Initialized
DEBUG - 2021-11-19 09:03:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 09:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 09:03:39 --> Controller Class Initialized
INFO - 2021-11-19 09:03:39 --> Helper loaded: cookie_helper
INFO - 2021-11-19 09:03:39 --> Config Class Initialized
INFO - 2021-11-19 09:03:39 --> Hooks Class Initialized
DEBUG - 2021-11-19 09:03:39 --> UTF-8 Support Enabled
INFO - 2021-11-19 09:03:39 --> Utf8 Class Initialized
INFO - 2021-11-19 09:03:39 --> URI Class Initialized
INFO - 2021-11-19 09:03:39 --> Router Class Initialized
INFO - 2021-11-19 09:03:39 --> Output Class Initialized
INFO - 2021-11-19 09:03:39 --> Security Class Initialized
DEBUG - 2021-11-19 09:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 09:03:39 --> Input Class Initialized
INFO - 2021-11-19 09:03:39 --> Language Class Initialized
INFO - 2021-11-19 09:03:39 --> Language Class Initialized
INFO - 2021-11-19 09:03:39 --> Config Class Initialized
INFO - 2021-11-19 09:03:39 --> Loader Class Initialized
INFO - 2021-11-19 09:03:39 --> Helper loaded: url_helper
INFO - 2021-11-19 09:03:39 --> Helper loaded: file_helper
INFO - 2021-11-19 09:03:39 --> Helper loaded: form_helper
INFO - 2021-11-19 09:03:39 --> Helper loaded: my_helper
INFO - 2021-11-19 09:03:39 --> Database Driver Class Initialized
DEBUG - 2021-11-19 09:03:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 09:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 09:03:39 --> Controller Class Initialized
DEBUG - 2021-11-19 09:03:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-11-19 09:03:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 09:03:39 --> Final output sent to browser
DEBUG - 2021-11-19 09:03:39 --> Total execution time: 0.0768
INFO - 2021-11-19 09:03:45 --> Config Class Initialized
INFO - 2021-11-19 09:03:45 --> Hooks Class Initialized
DEBUG - 2021-11-19 09:03:45 --> UTF-8 Support Enabled
INFO - 2021-11-19 09:03:45 --> Utf8 Class Initialized
INFO - 2021-11-19 09:03:45 --> URI Class Initialized
INFO - 2021-11-19 09:03:45 --> Router Class Initialized
INFO - 2021-11-19 09:03:45 --> Output Class Initialized
INFO - 2021-11-19 09:03:45 --> Security Class Initialized
DEBUG - 2021-11-19 09:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 09:03:45 --> Input Class Initialized
INFO - 2021-11-19 09:03:45 --> Language Class Initialized
INFO - 2021-11-19 09:03:45 --> Language Class Initialized
INFO - 2021-11-19 09:03:45 --> Config Class Initialized
INFO - 2021-11-19 09:03:45 --> Loader Class Initialized
INFO - 2021-11-19 09:03:45 --> Helper loaded: url_helper
INFO - 2021-11-19 09:03:45 --> Helper loaded: file_helper
INFO - 2021-11-19 09:03:45 --> Helper loaded: form_helper
INFO - 2021-11-19 09:03:45 --> Helper loaded: my_helper
INFO - 2021-11-19 09:03:45 --> Database Driver Class Initialized
DEBUG - 2021-11-19 09:03:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 09:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 09:03:45 --> Controller Class Initialized
INFO - 2021-11-19 09:03:45 --> Helper loaded: cookie_helper
INFO - 2021-11-19 09:03:45 --> Final output sent to browser
DEBUG - 2021-11-19 09:03:45 --> Total execution time: 0.0728
INFO - 2021-11-19 09:03:45 --> Config Class Initialized
INFO - 2021-11-19 09:03:45 --> Hooks Class Initialized
DEBUG - 2021-11-19 09:03:45 --> UTF-8 Support Enabled
INFO - 2021-11-19 09:03:45 --> Utf8 Class Initialized
INFO - 2021-11-19 09:03:45 --> URI Class Initialized
INFO - 2021-11-19 09:03:45 --> Router Class Initialized
INFO - 2021-11-19 09:03:45 --> Output Class Initialized
INFO - 2021-11-19 09:03:45 --> Security Class Initialized
DEBUG - 2021-11-19 09:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 09:03:45 --> Input Class Initialized
INFO - 2021-11-19 09:03:45 --> Language Class Initialized
INFO - 2021-11-19 09:03:45 --> Language Class Initialized
INFO - 2021-11-19 09:03:45 --> Config Class Initialized
INFO - 2021-11-19 09:03:45 --> Loader Class Initialized
INFO - 2021-11-19 09:03:45 --> Helper loaded: url_helper
INFO - 2021-11-19 09:03:45 --> Helper loaded: file_helper
INFO - 2021-11-19 09:03:45 --> Helper loaded: form_helper
INFO - 2021-11-19 09:03:45 --> Helper loaded: my_helper
INFO - 2021-11-19 09:03:45 --> Database Driver Class Initialized
DEBUG - 2021-11-19 09:03:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 09:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 09:03:45 --> Controller Class Initialized
DEBUG - 2021-11-19 09:03:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-11-19 09:03:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 09:03:46 --> Final output sent to browser
DEBUG - 2021-11-19 09:03:46 --> Total execution time: 1.0979
INFO - 2021-11-19 09:03:48 --> Config Class Initialized
INFO - 2021-11-19 09:03:48 --> Hooks Class Initialized
DEBUG - 2021-11-19 09:03:48 --> UTF-8 Support Enabled
INFO - 2021-11-19 09:03:48 --> Utf8 Class Initialized
INFO - 2021-11-19 09:03:48 --> URI Class Initialized
INFO - 2021-11-19 09:03:48 --> Router Class Initialized
INFO - 2021-11-19 09:03:48 --> Output Class Initialized
INFO - 2021-11-19 09:03:48 --> Security Class Initialized
DEBUG - 2021-11-19 09:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 09:03:48 --> Input Class Initialized
INFO - 2021-11-19 09:03:48 --> Language Class Initialized
INFO - 2021-11-19 09:03:48 --> Language Class Initialized
INFO - 2021-11-19 09:03:48 --> Config Class Initialized
INFO - 2021-11-19 09:03:48 --> Loader Class Initialized
INFO - 2021-11-19 09:03:48 --> Helper loaded: url_helper
INFO - 2021-11-19 09:03:48 --> Helper loaded: file_helper
INFO - 2021-11-19 09:03:48 --> Helper loaded: form_helper
INFO - 2021-11-19 09:03:48 --> Helper loaded: my_helper
INFO - 2021-11-19 09:03:48 --> Database Driver Class Initialized
DEBUG - 2021-11-19 09:03:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 09:03:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 09:03:48 --> Controller Class Initialized
DEBUG - 2021-11-19 09:03:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-11-19 09:03:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 09:03:48 --> Final output sent to browser
DEBUG - 2021-11-19 09:03:48 --> Total execution time: 0.0954
INFO - 2021-11-19 09:03:51 --> Config Class Initialized
INFO - 2021-11-19 09:03:51 --> Hooks Class Initialized
DEBUG - 2021-11-19 09:03:51 --> UTF-8 Support Enabled
INFO - 2021-11-19 09:03:51 --> Utf8 Class Initialized
INFO - 2021-11-19 09:03:51 --> URI Class Initialized
INFO - 2021-11-19 09:03:51 --> Router Class Initialized
INFO - 2021-11-19 09:03:51 --> Output Class Initialized
INFO - 2021-11-19 09:03:51 --> Security Class Initialized
DEBUG - 2021-11-19 09:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 09:03:51 --> Input Class Initialized
INFO - 2021-11-19 09:03:51 --> Language Class Initialized
INFO - 2021-11-19 09:03:51 --> Language Class Initialized
INFO - 2021-11-19 09:03:51 --> Config Class Initialized
INFO - 2021-11-19 09:03:51 --> Loader Class Initialized
INFO - 2021-11-19 09:03:51 --> Helper loaded: url_helper
INFO - 2021-11-19 09:03:51 --> Helper loaded: file_helper
INFO - 2021-11-19 09:03:51 --> Helper loaded: form_helper
INFO - 2021-11-19 09:03:51 --> Helper loaded: my_helper
INFO - 2021-11-19 09:03:51 --> Database Driver Class Initialized
DEBUG - 2021-11-19 09:03:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 09:03:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 09:03:51 --> Controller Class Initialized
DEBUG - 2021-11-19 09:03:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-19 09:03:51 --> Final output sent to browser
DEBUG - 2021-11-19 09:03:51 --> Total execution time: 0.2250
INFO - 2021-11-19 09:13:22 --> Config Class Initialized
INFO - 2021-11-19 09:13:22 --> Hooks Class Initialized
DEBUG - 2021-11-19 09:13:22 --> UTF-8 Support Enabled
INFO - 2021-11-19 09:13:22 --> Utf8 Class Initialized
INFO - 2021-11-19 09:13:22 --> URI Class Initialized
INFO - 2021-11-19 09:13:22 --> Router Class Initialized
INFO - 2021-11-19 09:13:22 --> Output Class Initialized
INFO - 2021-11-19 09:13:22 --> Security Class Initialized
DEBUG - 2021-11-19 09:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 09:13:22 --> Input Class Initialized
INFO - 2021-11-19 09:13:22 --> Language Class Initialized
INFO - 2021-11-19 09:13:22 --> Language Class Initialized
INFO - 2021-11-19 09:13:22 --> Config Class Initialized
INFO - 2021-11-19 09:13:22 --> Loader Class Initialized
INFO - 2021-11-19 09:13:22 --> Helper loaded: url_helper
INFO - 2021-11-19 09:13:22 --> Helper loaded: file_helper
INFO - 2021-11-19 09:13:22 --> Helper loaded: form_helper
INFO - 2021-11-19 09:13:22 --> Helper loaded: my_helper
INFO - 2021-11-19 09:13:22 --> Database Driver Class Initialized
DEBUG - 2021-11-19 09:13:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 09:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 09:13:22 --> Controller Class Initialized
DEBUG - 2021-11-19 09:13:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-19 09:13:22 --> Final output sent to browser
DEBUG - 2021-11-19 09:13:22 --> Total execution time: 0.1782
INFO - 2021-11-19 09:14:39 --> Config Class Initialized
INFO - 2021-11-19 09:14:39 --> Hooks Class Initialized
DEBUG - 2021-11-19 09:14:39 --> UTF-8 Support Enabled
INFO - 2021-11-19 09:14:39 --> Utf8 Class Initialized
INFO - 2021-11-19 09:14:39 --> URI Class Initialized
INFO - 2021-11-19 09:14:39 --> Router Class Initialized
INFO - 2021-11-19 09:14:39 --> Output Class Initialized
INFO - 2021-11-19 09:14:39 --> Security Class Initialized
DEBUG - 2021-11-19 09:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 09:14:39 --> Input Class Initialized
INFO - 2021-11-19 09:14:39 --> Language Class Initialized
INFO - 2021-11-19 09:14:39 --> Language Class Initialized
INFO - 2021-11-19 09:14:39 --> Config Class Initialized
INFO - 2021-11-19 09:14:39 --> Loader Class Initialized
INFO - 2021-11-19 09:14:39 --> Helper loaded: url_helper
INFO - 2021-11-19 09:14:39 --> Helper loaded: file_helper
INFO - 2021-11-19 09:14:39 --> Helper loaded: form_helper
INFO - 2021-11-19 09:14:39 --> Helper loaded: my_helper
INFO - 2021-11-19 09:14:39 --> Database Driver Class Initialized
DEBUG - 2021-11-19 09:14:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 09:14:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 09:14:39 --> Controller Class Initialized
DEBUG - 2021-11-19 09:14:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-19 09:14:39 --> Final output sent to browser
DEBUG - 2021-11-19 09:14:39 --> Total execution time: 0.1524
INFO - 2021-11-19 09:19:35 --> Config Class Initialized
INFO - 2021-11-19 09:19:35 --> Hooks Class Initialized
DEBUG - 2021-11-19 09:19:35 --> UTF-8 Support Enabled
INFO - 2021-11-19 09:19:35 --> Utf8 Class Initialized
INFO - 2021-11-19 09:19:35 --> URI Class Initialized
INFO - 2021-11-19 09:19:35 --> Router Class Initialized
INFO - 2021-11-19 09:19:35 --> Output Class Initialized
INFO - 2021-11-19 09:19:35 --> Security Class Initialized
DEBUG - 2021-11-19 09:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 09:19:35 --> Input Class Initialized
INFO - 2021-11-19 09:19:35 --> Language Class Initialized
INFO - 2021-11-19 09:19:35 --> Language Class Initialized
INFO - 2021-11-19 09:19:35 --> Config Class Initialized
INFO - 2021-11-19 09:19:35 --> Loader Class Initialized
INFO - 2021-11-19 09:19:35 --> Helper loaded: url_helper
INFO - 2021-11-19 09:19:35 --> Helper loaded: file_helper
INFO - 2021-11-19 09:19:35 --> Helper loaded: form_helper
INFO - 2021-11-19 09:19:35 --> Helper loaded: my_helper
INFO - 2021-11-19 09:19:35 --> Database Driver Class Initialized
DEBUG - 2021-11-19 09:19:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 09:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 09:19:35 --> Controller Class Initialized
DEBUG - 2021-11-19 09:19:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-19 09:19:36 --> Final output sent to browser
DEBUG - 2021-11-19 09:19:36 --> Total execution time: 0.1618
INFO - 2021-11-19 09:20:47 --> Config Class Initialized
INFO - 2021-11-19 09:20:47 --> Hooks Class Initialized
DEBUG - 2021-11-19 09:20:47 --> UTF-8 Support Enabled
INFO - 2021-11-19 09:20:47 --> Utf8 Class Initialized
INFO - 2021-11-19 09:20:47 --> URI Class Initialized
INFO - 2021-11-19 09:20:47 --> Router Class Initialized
INFO - 2021-11-19 09:20:47 --> Output Class Initialized
INFO - 2021-11-19 09:20:47 --> Security Class Initialized
DEBUG - 2021-11-19 09:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 09:20:47 --> Input Class Initialized
INFO - 2021-11-19 09:20:47 --> Language Class Initialized
INFO - 2021-11-19 09:20:47 --> Language Class Initialized
INFO - 2021-11-19 09:20:47 --> Config Class Initialized
INFO - 2021-11-19 09:20:47 --> Loader Class Initialized
INFO - 2021-11-19 09:20:47 --> Helper loaded: url_helper
INFO - 2021-11-19 09:20:47 --> Helper loaded: file_helper
INFO - 2021-11-19 09:20:47 --> Helper loaded: form_helper
INFO - 2021-11-19 09:20:47 --> Helper loaded: my_helper
INFO - 2021-11-19 09:20:47 --> Database Driver Class Initialized
DEBUG - 2021-11-19 09:20:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 09:20:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 09:20:47 --> Controller Class Initialized
DEBUG - 2021-11-19 09:20:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-19 09:20:47 --> Final output sent to browser
DEBUG - 2021-11-19 09:20:47 --> Total execution time: 0.1358
INFO - 2021-11-19 09:21:10 --> Config Class Initialized
INFO - 2021-11-19 09:21:10 --> Hooks Class Initialized
DEBUG - 2021-11-19 09:21:10 --> UTF-8 Support Enabled
INFO - 2021-11-19 09:21:10 --> Utf8 Class Initialized
INFO - 2021-11-19 09:21:10 --> URI Class Initialized
INFO - 2021-11-19 09:21:10 --> Router Class Initialized
INFO - 2021-11-19 09:21:10 --> Output Class Initialized
INFO - 2021-11-19 09:21:10 --> Security Class Initialized
DEBUG - 2021-11-19 09:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 09:21:10 --> Input Class Initialized
INFO - 2021-11-19 09:21:10 --> Language Class Initialized
INFO - 2021-11-19 09:21:10 --> Language Class Initialized
INFO - 2021-11-19 09:21:10 --> Config Class Initialized
INFO - 2021-11-19 09:21:10 --> Loader Class Initialized
INFO - 2021-11-19 09:21:10 --> Helper loaded: url_helper
INFO - 2021-11-19 09:21:10 --> Helper loaded: file_helper
INFO - 2021-11-19 09:21:10 --> Helper loaded: form_helper
INFO - 2021-11-19 09:21:10 --> Helper loaded: my_helper
INFO - 2021-11-19 09:21:10 --> Database Driver Class Initialized
DEBUG - 2021-11-19 09:21:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 09:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 09:21:10 --> Controller Class Initialized
DEBUG - 2021-11-19 09:21:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-19 09:21:10 --> Final output sent to browser
DEBUG - 2021-11-19 09:21:10 --> Total execution time: 0.1326
INFO - 2021-11-19 09:21:31 --> Config Class Initialized
INFO - 2021-11-19 09:21:31 --> Hooks Class Initialized
DEBUG - 2021-11-19 09:21:31 --> UTF-8 Support Enabled
INFO - 2021-11-19 09:21:31 --> Utf8 Class Initialized
INFO - 2021-11-19 09:21:31 --> URI Class Initialized
INFO - 2021-11-19 09:21:31 --> Router Class Initialized
INFO - 2021-11-19 09:21:31 --> Output Class Initialized
INFO - 2021-11-19 09:21:31 --> Security Class Initialized
DEBUG - 2021-11-19 09:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 09:21:31 --> Input Class Initialized
INFO - 2021-11-19 09:21:31 --> Language Class Initialized
INFO - 2021-11-19 09:21:31 --> Language Class Initialized
INFO - 2021-11-19 09:21:31 --> Config Class Initialized
INFO - 2021-11-19 09:21:31 --> Loader Class Initialized
INFO - 2021-11-19 09:21:31 --> Helper loaded: url_helper
INFO - 2021-11-19 09:21:31 --> Helper loaded: file_helper
INFO - 2021-11-19 09:21:31 --> Helper loaded: form_helper
INFO - 2021-11-19 09:21:31 --> Helper loaded: my_helper
INFO - 2021-11-19 09:21:31 --> Database Driver Class Initialized
DEBUG - 2021-11-19 09:21:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 09:21:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 09:21:31 --> Controller Class Initialized
DEBUG - 2021-11-19 09:21:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-19 09:21:32 --> Final output sent to browser
DEBUG - 2021-11-19 09:21:32 --> Total execution time: 0.1339
INFO - 2021-11-19 09:21:41 --> Config Class Initialized
INFO - 2021-11-19 09:21:41 --> Hooks Class Initialized
DEBUG - 2021-11-19 09:21:41 --> UTF-8 Support Enabled
INFO - 2021-11-19 09:21:41 --> Utf8 Class Initialized
INFO - 2021-11-19 09:21:41 --> URI Class Initialized
INFO - 2021-11-19 09:21:41 --> Router Class Initialized
INFO - 2021-11-19 09:21:41 --> Output Class Initialized
INFO - 2021-11-19 09:21:41 --> Security Class Initialized
DEBUG - 2021-11-19 09:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 09:21:41 --> Input Class Initialized
INFO - 2021-11-19 09:21:41 --> Language Class Initialized
INFO - 2021-11-19 09:21:41 --> Language Class Initialized
INFO - 2021-11-19 09:21:41 --> Config Class Initialized
INFO - 2021-11-19 09:21:41 --> Loader Class Initialized
INFO - 2021-11-19 09:21:41 --> Helper loaded: url_helper
INFO - 2021-11-19 09:21:41 --> Helper loaded: file_helper
INFO - 2021-11-19 09:21:41 --> Helper loaded: form_helper
INFO - 2021-11-19 09:21:41 --> Helper loaded: my_helper
INFO - 2021-11-19 09:21:41 --> Database Driver Class Initialized
DEBUG - 2021-11-19 09:21:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 09:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 09:21:41 --> Controller Class Initialized
DEBUG - 2021-11-19 09:21:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-19 09:21:41 --> Final output sent to browser
DEBUG - 2021-11-19 09:21:41 --> Total execution time: 0.1277
INFO - 2021-11-19 09:22:28 --> Config Class Initialized
INFO - 2021-11-19 09:22:28 --> Hooks Class Initialized
DEBUG - 2021-11-19 09:22:28 --> UTF-8 Support Enabled
INFO - 2021-11-19 09:22:28 --> Utf8 Class Initialized
INFO - 2021-11-19 09:22:28 --> URI Class Initialized
INFO - 2021-11-19 09:22:28 --> Router Class Initialized
INFO - 2021-11-19 09:22:28 --> Output Class Initialized
INFO - 2021-11-19 09:22:28 --> Security Class Initialized
DEBUG - 2021-11-19 09:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 09:22:28 --> Input Class Initialized
INFO - 2021-11-19 09:22:28 --> Language Class Initialized
INFO - 2021-11-19 09:22:28 --> Language Class Initialized
INFO - 2021-11-19 09:22:28 --> Config Class Initialized
INFO - 2021-11-19 09:22:28 --> Loader Class Initialized
INFO - 2021-11-19 09:22:28 --> Helper loaded: url_helper
INFO - 2021-11-19 09:22:28 --> Helper loaded: file_helper
INFO - 2021-11-19 09:22:28 --> Helper loaded: form_helper
INFO - 2021-11-19 09:22:28 --> Helper loaded: my_helper
INFO - 2021-11-19 09:22:28 --> Database Driver Class Initialized
DEBUG - 2021-11-19 09:22:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 09:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 09:22:28 --> Controller Class Initialized
DEBUG - 2021-11-19 09:22:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-19 09:22:28 --> Final output sent to browser
DEBUG - 2021-11-19 09:22:28 --> Total execution time: 0.1401
INFO - 2021-11-19 09:23:32 --> Config Class Initialized
INFO - 2021-11-19 09:23:32 --> Hooks Class Initialized
DEBUG - 2021-11-19 09:23:32 --> UTF-8 Support Enabled
INFO - 2021-11-19 09:23:32 --> Utf8 Class Initialized
INFO - 2021-11-19 09:23:32 --> URI Class Initialized
INFO - 2021-11-19 09:23:32 --> Router Class Initialized
INFO - 2021-11-19 09:23:32 --> Output Class Initialized
INFO - 2021-11-19 09:23:32 --> Security Class Initialized
DEBUG - 2021-11-19 09:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 09:23:32 --> Input Class Initialized
INFO - 2021-11-19 09:23:32 --> Language Class Initialized
INFO - 2021-11-19 09:23:32 --> Language Class Initialized
INFO - 2021-11-19 09:23:32 --> Config Class Initialized
INFO - 2021-11-19 09:23:32 --> Loader Class Initialized
INFO - 2021-11-19 09:23:32 --> Helper loaded: url_helper
INFO - 2021-11-19 09:23:32 --> Helper loaded: file_helper
INFO - 2021-11-19 09:23:32 --> Helper loaded: form_helper
INFO - 2021-11-19 09:23:32 --> Helper loaded: my_helper
INFO - 2021-11-19 09:23:32 --> Database Driver Class Initialized
DEBUG - 2021-11-19 09:23:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 09:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 09:23:32 --> Controller Class Initialized
DEBUG - 2021-11-19 09:23:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-19 09:23:32 --> Final output sent to browser
DEBUG - 2021-11-19 09:23:32 --> Total execution time: 0.1271
INFO - 2021-11-19 09:23:51 --> Config Class Initialized
INFO - 2021-11-19 09:23:51 --> Hooks Class Initialized
DEBUG - 2021-11-19 09:23:51 --> UTF-8 Support Enabled
INFO - 2021-11-19 09:23:51 --> Utf8 Class Initialized
INFO - 2021-11-19 09:23:51 --> URI Class Initialized
INFO - 2021-11-19 09:23:51 --> Router Class Initialized
INFO - 2021-11-19 09:23:51 --> Output Class Initialized
INFO - 2021-11-19 09:23:51 --> Security Class Initialized
DEBUG - 2021-11-19 09:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 09:23:51 --> Input Class Initialized
INFO - 2021-11-19 09:23:51 --> Language Class Initialized
INFO - 2021-11-19 09:23:51 --> Language Class Initialized
INFO - 2021-11-19 09:23:51 --> Config Class Initialized
INFO - 2021-11-19 09:23:51 --> Loader Class Initialized
INFO - 2021-11-19 09:23:51 --> Helper loaded: url_helper
INFO - 2021-11-19 09:23:51 --> Helper loaded: file_helper
INFO - 2021-11-19 09:23:51 --> Helper loaded: form_helper
INFO - 2021-11-19 09:23:51 --> Helper loaded: my_helper
INFO - 2021-11-19 09:23:51 --> Database Driver Class Initialized
DEBUG - 2021-11-19 09:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 09:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 09:23:51 --> Controller Class Initialized
DEBUG - 2021-11-19 09:23:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-19 09:23:51 --> Final output sent to browser
DEBUG - 2021-11-19 09:23:51 --> Total execution time: 0.1354
INFO - 2021-11-19 09:24:16 --> Config Class Initialized
INFO - 2021-11-19 09:24:16 --> Hooks Class Initialized
DEBUG - 2021-11-19 09:24:16 --> UTF-8 Support Enabled
INFO - 2021-11-19 09:24:16 --> Utf8 Class Initialized
INFO - 2021-11-19 09:24:16 --> URI Class Initialized
INFO - 2021-11-19 09:24:16 --> Router Class Initialized
INFO - 2021-11-19 09:24:16 --> Output Class Initialized
INFO - 2021-11-19 09:24:16 --> Security Class Initialized
DEBUG - 2021-11-19 09:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 09:24:16 --> Input Class Initialized
INFO - 2021-11-19 09:24:16 --> Language Class Initialized
INFO - 2021-11-19 09:24:16 --> Language Class Initialized
INFO - 2021-11-19 09:24:16 --> Config Class Initialized
INFO - 2021-11-19 09:24:16 --> Loader Class Initialized
INFO - 2021-11-19 09:24:16 --> Helper loaded: url_helper
INFO - 2021-11-19 09:24:16 --> Helper loaded: file_helper
INFO - 2021-11-19 09:24:16 --> Helper loaded: form_helper
INFO - 2021-11-19 09:24:16 --> Helper loaded: my_helper
INFO - 2021-11-19 09:24:16 --> Database Driver Class Initialized
DEBUG - 2021-11-19 09:24:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 09:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 09:24:16 --> Controller Class Initialized
DEBUG - 2021-11-19 09:24:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-19 09:24:16 --> Final output sent to browser
DEBUG - 2021-11-19 09:24:16 --> Total execution time: 0.1381
INFO - 2021-11-19 09:25:31 --> Config Class Initialized
INFO - 2021-11-19 09:25:31 --> Hooks Class Initialized
DEBUG - 2021-11-19 09:25:31 --> UTF-8 Support Enabled
INFO - 2021-11-19 09:25:31 --> Utf8 Class Initialized
INFO - 2021-11-19 09:25:31 --> URI Class Initialized
INFO - 2021-11-19 09:25:31 --> Router Class Initialized
INFO - 2021-11-19 09:25:31 --> Output Class Initialized
INFO - 2021-11-19 09:25:31 --> Security Class Initialized
DEBUG - 2021-11-19 09:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 09:25:31 --> Input Class Initialized
INFO - 2021-11-19 09:25:31 --> Language Class Initialized
INFO - 2021-11-19 09:25:31 --> Language Class Initialized
INFO - 2021-11-19 09:25:31 --> Config Class Initialized
INFO - 2021-11-19 09:25:31 --> Loader Class Initialized
INFO - 2021-11-19 09:25:31 --> Helper loaded: url_helper
INFO - 2021-11-19 09:25:31 --> Helper loaded: file_helper
INFO - 2021-11-19 09:25:31 --> Helper loaded: form_helper
INFO - 2021-11-19 09:25:31 --> Helper loaded: my_helper
INFO - 2021-11-19 09:25:31 --> Database Driver Class Initialized
DEBUG - 2021-11-19 09:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 09:25:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 09:25:31 --> Controller Class Initialized
DEBUG - 2021-11-19 09:25:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-11-19 09:25:31 --> Final output sent to browser
DEBUG - 2021-11-19 09:25:31 --> Total execution time: 0.1395
INFO - 2021-11-19 09:25:50 --> Config Class Initialized
INFO - 2021-11-19 09:25:50 --> Hooks Class Initialized
DEBUG - 2021-11-19 09:25:50 --> UTF-8 Support Enabled
INFO - 2021-11-19 09:25:50 --> Utf8 Class Initialized
INFO - 2021-11-19 09:25:50 --> URI Class Initialized
INFO - 2021-11-19 09:25:50 --> Router Class Initialized
INFO - 2021-11-19 09:25:50 --> Output Class Initialized
INFO - 2021-11-19 09:25:50 --> Security Class Initialized
DEBUG - 2021-11-19 09:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 09:25:50 --> Input Class Initialized
INFO - 2021-11-19 09:25:50 --> Language Class Initialized
INFO - 2021-11-19 09:25:50 --> Language Class Initialized
INFO - 2021-11-19 09:25:50 --> Config Class Initialized
INFO - 2021-11-19 09:25:50 --> Loader Class Initialized
INFO - 2021-11-19 09:25:50 --> Helper loaded: url_helper
INFO - 2021-11-19 09:25:50 --> Helper loaded: file_helper
INFO - 2021-11-19 09:25:50 --> Helper loaded: form_helper
INFO - 2021-11-19 09:25:50 --> Helper loaded: my_helper
INFO - 2021-11-19 09:25:50 --> Database Driver Class Initialized
DEBUG - 2021-11-19 09:25:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 09:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 09:25:50 --> Controller Class Initialized
DEBUG - 2021-11-19 09:25:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-11-19 09:25:50 --> Final output sent to browser
DEBUG - 2021-11-19 09:25:50 --> Total execution time: 0.1596
INFO - 2021-11-19 09:26:00 --> Config Class Initialized
INFO - 2021-11-19 09:26:00 --> Hooks Class Initialized
DEBUG - 2021-11-19 09:26:00 --> UTF-8 Support Enabled
INFO - 2021-11-19 09:26:00 --> Utf8 Class Initialized
INFO - 2021-11-19 09:26:00 --> URI Class Initialized
INFO - 2021-11-19 09:26:00 --> Router Class Initialized
INFO - 2021-11-19 09:26:00 --> Output Class Initialized
INFO - 2021-11-19 09:26:00 --> Security Class Initialized
DEBUG - 2021-11-19 09:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 09:26:00 --> Input Class Initialized
INFO - 2021-11-19 09:26:00 --> Language Class Initialized
INFO - 2021-11-19 09:26:00 --> Language Class Initialized
INFO - 2021-11-19 09:26:00 --> Config Class Initialized
INFO - 2021-11-19 09:26:00 --> Loader Class Initialized
INFO - 2021-11-19 09:26:00 --> Helper loaded: url_helper
INFO - 2021-11-19 09:26:00 --> Helper loaded: file_helper
INFO - 2021-11-19 09:26:00 --> Helper loaded: form_helper
INFO - 2021-11-19 09:26:00 --> Helper loaded: my_helper
INFO - 2021-11-19 09:26:00 --> Database Driver Class Initialized
DEBUG - 2021-11-19 09:26:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 09:26:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 09:26:00 --> Controller Class Initialized
DEBUG - 2021-11-19 09:26:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-11-19 09:26:00 --> Final output sent to browser
DEBUG - 2021-11-19 09:26:00 --> Total execution time: 0.1567
INFO - 2021-11-19 09:26:45 --> Config Class Initialized
INFO - 2021-11-19 09:26:45 --> Hooks Class Initialized
DEBUG - 2021-11-19 09:26:45 --> UTF-8 Support Enabled
INFO - 2021-11-19 09:26:45 --> Utf8 Class Initialized
INFO - 2021-11-19 09:26:45 --> URI Class Initialized
INFO - 2021-11-19 09:26:45 --> Router Class Initialized
INFO - 2021-11-19 09:26:45 --> Output Class Initialized
INFO - 2021-11-19 09:26:45 --> Security Class Initialized
DEBUG - 2021-11-19 09:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 09:26:45 --> Input Class Initialized
INFO - 2021-11-19 09:26:45 --> Language Class Initialized
INFO - 2021-11-19 09:26:45 --> Language Class Initialized
INFO - 2021-11-19 09:26:45 --> Config Class Initialized
INFO - 2021-11-19 09:26:45 --> Loader Class Initialized
INFO - 2021-11-19 09:26:45 --> Helper loaded: url_helper
INFO - 2021-11-19 09:26:45 --> Helper loaded: file_helper
INFO - 2021-11-19 09:26:45 --> Helper loaded: form_helper
INFO - 2021-11-19 09:26:45 --> Helper loaded: my_helper
INFO - 2021-11-19 09:26:45 --> Database Driver Class Initialized
DEBUG - 2021-11-19 09:26:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 09:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 09:26:45 --> Controller Class Initialized
DEBUG - 2021-11-19 09:26:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-11-19 09:26:45 --> Final output sent to browser
DEBUG - 2021-11-19 09:26:45 --> Total execution time: 0.1787
INFO - 2021-11-19 09:26:58 --> Config Class Initialized
INFO - 2021-11-19 09:26:58 --> Hooks Class Initialized
DEBUG - 2021-11-19 09:26:58 --> UTF-8 Support Enabled
INFO - 2021-11-19 09:26:58 --> Utf8 Class Initialized
INFO - 2021-11-19 09:26:58 --> URI Class Initialized
INFO - 2021-11-19 09:26:58 --> Router Class Initialized
INFO - 2021-11-19 09:26:58 --> Output Class Initialized
INFO - 2021-11-19 09:26:58 --> Security Class Initialized
DEBUG - 2021-11-19 09:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 09:26:58 --> Input Class Initialized
INFO - 2021-11-19 09:26:58 --> Language Class Initialized
INFO - 2021-11-19 09:26:58 --> Language Class Initialized
INFO - 2021-11-19 09:26:58 --> Config Class Initialized
INFO - 2021-11-19 09:26:58 --> Loader Class Initialized
INFO - 2021-11-19 09:26:58 --> Helper loaded: url_helper
INFO - 2021-11-19 09:26:58 --> Helper loaded: file_helper
INFO - 2021-11-19 09:26:58 --> Helper loaded: form_helper
INFO - 2021-11-19 09:26:58 --> Helper loaded: my_helper
INFO - 2021-11-19 09:26:58 --> Database Driver Class Initialized
DEBUG - 2021-11-19 09:26:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 09:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 09:26:58 --> Controller Class Initialized
DEBUG - 2021-11-19 09:26:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-11-19 09:26:58 --> Final output sent to browser
DEBUG - 2021-11-19 09:26:58 --> Total execution time: 0.1346
INFO - 2021-11-19 09:27:10 --> Config Class Initialized
INFO - 2021-11-19 09:27:10 --> Hooks Class Initialized
DEBUG - 2021-11-19 09:27:10 --> UTF-8 Support Enabled
INFO - 2021-11-19 09:27:10 --> Utf8 Class Initialized
INFO - 2021-11-19 09:27:10 --> URI Class Initialized
INFO - 2021-11-19 09:27:10 --> Router Class Initialized
INFO - 2021-11-19 09:27:10 --> Output Class Initialized
INFO - 2021-11-19 09:27:10 --> Security Class Initialized
DEBUG - 2021-11-19 09:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 09:27:10 --> Input Class Initialized
INFO - 2021-11-19 09:27:10 --> Language Class Initialized
INFO - 2021-11-19 09:27:10 --> Language Class Initialized
INFO - 2021-11-19 09:27:10 --> Config Class Initialized
INFO - 2021-11-19 09:27:10 --> Loader Class Initialized
INFO - 2021-11-19 09:27:10 --> Helper loaded: url_helper
INFO - 2021-11-19 09:27:10 --> Helper loaded: file_helper
INFO - 2021-11-19 09:27:10 --> Helper loaded: form_helper
INFO - 2021-11-19 09:27:10 --> Helper loaded: my_helper
INFO - 2021-11-19 09:27:10 --> Database Driver Class Initialized
DEBUG - 2021-11-19 09:27:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 09:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 09:27:10 --> Controller Class Initialized
DEBUG - 2021-11-19 09:27:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-11-19 09:27:10 --> Final output sent to browser
DEBUG - 2021-11-19 09:27:10 --> Total execution time: 0.1598
INFO - 2021-11-19 09:27:18 --> Config Class Initialized
INFO - 2021-11-19 09:27:18 --> Hooks Class Initialized
DEBUG - 2021-11-19 09:27:18 --> UTF-8 Support Enabled
INFO - 2021-11-19 09:27:18 --> Utf8 Class Initialized
INFO - 2021-11-19 09:27:18 --> URI Class Initialized
INFO - 2021-11-19 09:27:18 --> Router Class Initialized
INFO - 2021-11-19 09:27:18 --> Output Class Initialized
INFO - 2021-11-19 09:27:18 --> Security Class Initialized
DEBUG - 2021-11-19 09:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 09:27:18 --> Input Class Initialized
INFO - 2021-11-19 09:27:18 --> Language Class Initialized
INFO - 2021-11-19 09:27:18 --> Language Class Initialized
INFO - 2021-11-19 09:27:18 --> Config Class Initialized
INFO - 2021-11-19 09:27:18 --> Loader Class Initialized
INFO - 2021-11-19 09:27:18 --> Helper loaded: url_helper
INFO - 2021-11-19 09:27:18 --> Helper loaded: file_helper
INFO - 2021-11-19 09:27:18 --> Helper loaded: form_helper
INFO - 2021-11-19 09:27:18 --> Helper loaded: my_helper
INFO - 2021-11-19 09:27:18 --> Database Driver Class Initialized
DEBUG - 2021-11-19 09:27:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 09:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 09:27:18 --> Controller Class Initialized
DEBUG - 2021-11-19 09:27:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-11-19 09:27:18 --> Final output sent to browser
DEBUG - 2021-11-19 09:27:18 --> Total execution time: 0.1610
INFO - 2021-11-19 09:28:31 --> Config Class Initialized
INFO - 2021-11-19 09:28:31 --> Hooks Class Initialized
DEBUG - 2021-11-19 09:28:31 --> UTF-8 Support Enabled
INFO - 2021-11-19 09:28:31 --> Utf8 Class Initialized
INFO - 2021-11-19 09:28:31 --> URI Class Initialized
INFO - 2021-11-19 09:28:31 --> Router Class Initialized
INFO - 2021-11-19 09:28:31 --> Output Class Initialized
INFO - 2021-11-19 09:28:31 --> Security Class Initialized
DEBUG - 2021-11-19 09:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 09:28:31 --> Input Class Initialized
INFO - 2021-11-19 09:28:31 --> Language Class Initialized
INFO - 2021-11-19 09:28:31 --> Language Class Initialized
INFO - 2021-11-19 09:28:31 --> Config Class Initialized
INFO - 2021-11-19 09:28:31 --> Loader Class Initialized
INFO - 2021-11-19 09:28:31 --> Helper loaded: url_helper
INFO - 2021-11-19 09:28:31 --> Helper loaded: file_helper
INFO - 2021-11-19 09:28:31 --> Helper loaded: form_helper
INFO - 2021-11-19 09:28:31 --> Helper loaded: my_helper
INFO - 2021-11-19 09:28:31 --> Database Driver Class Initialized
DEBUG - 2021-11-19 09:28:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 09:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 09:28:31 --> Controller Class Initialized
INFO - 2021-11-19 09:28:31 --> Helper loaded: cookie_helper
INFO - 2021-11-19 09:28:31 --> Config Class Initialized
INFO - 2021-11-19 09:28:31 --> Hooks Class Initialized
DEBUG - 2021-11-19 09:28:31 --> UTF-8 Support Enabled
INFO - 2021-11-19 09:28:31 --> Utf8 Class Initialized
INFO - 2021-11-19 09:28:31 --> URI Class Initialized
INFO - 2021-11-19 09:28:31 --> Router Class Initialized
INFO - 2021-11-19 09:28:31 --> Output Class Initialized
INFO - 2021-11-19 09:28:31 --> Security Class Initialized
DEBUG - 2021-11-19 09:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 09:28:31 --> Input Class Initialized
INFO - 2021-11-19 09:28:31 --> Language Class Initialized
INFO - 2021-11-19 09:28:31 --> Language Class Initialized
INFO - 2021-11-19 09:28:31 --> Config Class Initialized
INFO - 2021-11-19 09:28:31 --> Loader Class Initialized
INFO - 2021-11-19 09:28:31 --> Helper loaded: url_helper
INFO - 2021-11-19 09:28:31 --> Helper loaded: file_helper
INFO - 2021-11-19 09:28:31 --> Helper loaded: form_helper
INFO - 2021-11-19 09:28:31 --> Helper loaded: my_helper
INFO - 2021-11-19 09:28:31 --> Database Driver Class Initialized
DEBUG - 2021-11-19 09:28:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 09:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 09:28:31 --> Controller Class Initialized
DEBUG - 2021-11-19 09:28:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-11-19 09:28:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 09:28:31 --> Final output sent to browser
DEBUG - 2021-11-19 09:28:31 --> Total execution time: 0.0581
INFO - 2021-11-19 09:28:36 --> Config Class Initialized
INFO - 2021-11-19 09:28:36 --> Hooks Class Initialized
DEBUG - 2021-11-19 09:28:36 --> UTF-8 Support Enabled
INFO - 2021-11-19 09:28:36 --> Utf8 Class Initialized
INFO - 2021-11-19 09:28:36 --> URI Class Initialized
INFO - 2021-11-19 09:28:36 --> Router Class Initialized
INFO - 2021-11-19 09:28:36 --> Output Class Initialized
INFO - 2021-11-19 09:28:36 --> Security Class Initialized
DEBUG - 2021-11-19 09:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 09:28:36 --> Input Class Initialized
INFO - 2021-11-19 09:28:36 --> Language Class Initialized
INFO - 2021-11-19 09:28:36 --> Language Class Initialized
INFO - 2021-11-19 09:28:36 --> Config Class Initialized
INFO - 2021-11-19 09:28:36 --> Loader Class Initialized
INFO - 2021-11-19 09:28:36 --> Helper loaded: url_helper
INFO - 2021-11-19 09:28:36 --> Helper loaded: file_helper
INFO - 2021-11-19 09:28:36 --> Helper loaded: form_helper
INFO - 2021-11-19 09:28:36 --> Helper loaded: my_helper
INFO - 2021-11-19 09:28:36 --> Database Driver Class Initialized
DEBUG - 2021-11-19 09:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 09:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 09:28:36 --> Controller Class Initialized
INFO - 2021-11-19 09:28:36 --> Helper loaded: cookie_helper
INFO - 2021-11-19 09:28:36 --> Final output sent to browser
DEBUG - 2021-11-19 09:28:36 --> Total execution time: 0.0742
INFO - 2021-11-19 09:28:36 --> Config Class Initialized
INFO - 2021-11-19 09:28:36 --> Hooks Class Initialized
DEBUG - 2021-11-19 09:28:36 --> UTF-8 Support Enabled
INFO - 2021-11-19 09:28:36 --> Utf8 Class Initialized
INFO - 2021-11-19 09:28:36 --> URI Class Initialized
INFO - 2021-11-19 09:28:36 --> Router Class Initialized
INFO - 2021-11-19 09:28:36 --> Output Class Initialized
INFO - 2021-11-19 09:28:36 --> Security Class Initialized
DEBUG - 2021-11-19 09:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 09:28:36 --> Input Class Initialized
INFO - 2021-11-19 09:28:36 --> Language Class Initialized
INFO - 2021-11-19 09:28:36 --> Language Class Initialized
INFO - 2021-11-19 09:28:36 --> Config Class Initialized
INFO - 2021-11-19 09:28:36 --> Loader Class Initialized
INFO - 2021-11-19 09:28:36 --> Helper loaded: url_helper
INFO - 2021-11-19 09:28:36 --> Helper loaded: file_helper
INFO - 2021-11-19 09:28:36 --> Helper loaded: form_helper
INFO - 2021-11-19 09:28:36 --> Helper loaded: my_helper
INFO - 2021-11-19 09:28:36 --> Database Driver Class Initialized
DEBUG - 2021-11-19 09:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 09:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 09:28:36 --> Controller Class Initialized
DEBUG - 2021-11-19 09:28:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-11-19 09:28:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 09:28:37 --> Final output sent to browser
DEBUG - 2021-11-19 09:28:37 --> Total execution time: 1.0677
INFO - 2021-11-19 09:28:39 --> Config Class Initialized
INFO - 2021-11-19 09:28:39 --> Hooks Class Initialized
DEBUG - 2021-11-19 09:28:39 --> UTF-8 Support Enabled
INFO - 2021-11-19 09:28:39 --> Utf8 Class Initialized
INFO - 2021-11-19 09:28:39 --> URI Class Initialized
INFO - 2021-11-19 09:28:39 --> Router Class Initialized
INFO - 2021-11-19 09:28:39 --> Output Class Initialized
INFO - 2021-11-19 09:28:39 --> Security Class Initialized
DEBUG - 2021-11-19 09:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 09:28:39 --> Input Class Initialized
INFO - 2021-11-19 09:28:39 --> Language Class Initialized
INFO - 2021-11-19 09:28:39 --> Language Class Initialized
INFO - 2021-11-19 09:28:39 --> Config Class Initialized
INFO - 2021-11-19 09:28:39 --> Loader Class Initialized
INFO - 2021-11-19 09:28:39 --> Helper loaded: url_helper
INFO - 2021-11-19 09:28:39 --> Helper loaded: file_helper
INFO - 2021-11-19 09:28:39 --> Helper loaded: form_helper
INFO - 2021-11-19 09:28:39 --> Helper loaded: my_helper
INFO - 2021-11-19 09:28:39 --> Database Driver Class Initialized
DEBUG - 2021-11-19 09:28:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 09:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 09:28:39 --> Controller Class Initialized
DEBUG - 2021-11-19 09:28:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-11-19 09:28:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 09:28:39 --> Final output sent to browser
DEBUG - 2021-11-19 09:28:39 --> Total execution time: 0.0751
INFO - 2021-11-19 09:28:41 --> Config Class Initialized
INFO - 2021-11-19 09:28:41 --> Hooks Class Initialized
DEBUG - 2021-11-19 09:28:41 --> UTF-8 Support Enabled
INFO - 2021-11-19 09:28:41 --> Utf8 Class Initialized
INFO - 2021-11-19 09:28:41 --> URI Class Initialized
INFO - 2021-11-19 09:28:41 --> Router Class Initialized
INFO - 2021-11-19 09:28:41 --> Output Class Initialized
INFO - 2021-11-19 09:28:41 --> Security Class Initialized
DEBUG - 2021-11-19 09:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 09:28:41 --> Input Class Initialized
INFO - 2021-11-19 09:28:41 --> Language Class Initialized
INFO - 2021-11-19 09:28:41 --> Language Class Initialized
INFO - 2021-11-19 09:28:41 --> Config Class Initialized
INFO - 2021-11-19 09:28:41 --> Loader Class Initialized
INFO - 2021-11-19 09:28:41 --> Helper loaded: url_helper
INFO - 2021-11-19 09:28:41 --> Helper loaded: file_helper
INFO - 2021-11-19 09:28:41 --> Helper loaded: form_helper
INFO - 2021-11-19 09:28:41 --> Helper loaded: my_helper
INFO - 2021-11-19 09:28:41 --> Database Driver Class Initialized
DEBUG - 2021-11-19 09:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 09:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 09:28:41 --> Controller Class Initialized
DEBUG - 2021-11-19 09:28:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-19 09:28:41 --> Final output sent to browser
DEBUG - 2021-11-19 09:28:41 --> Total execution time: 0.2205
INFO - 2021-11-19 09:30:42 --> Config Class Initialized
INFO - 2021-11-19 09:30:42 --> Hooks Class Initialized
DEBUG - 2021-11-19 09:30:42 --> UTF-8 Support Enabled
INFO - 2021-11-19 09:30:42 --> Utf8 Class Initialized
INFO - 2021-11-19 09:30:42 --> URI Class Initialized
INFO - 2021-11-19 09:30:42 --> Router Class Initialized
INFO - 2021-11-19 09:30:42 --> Output Class Initialized
INFO - 2021-11-19 09:30:42 --> Security Class Initialized
DEBUG - 2021-11-19 09:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 09:30:42 --> Input Class Initialized
INFO - 2021-11-19 09:30:42 --> Language Class Initialized
INFO - 2021-11-19 09:30:42 --> Language Class Initialized
INFO - 2021-11-19 09:30:42 --> Config Class Initialized
INFO - 2021-11-19 09:30:42 --> Loader Class Initialized
INFO - 2021-11-19 09:30:42 --> Helper loaded: url_helper
INFO - 2021-11-19 09:30:42 --> Helper loaded: file_helper
INFO - 2021-11-19 09:30:42 --> Helper loaded: form_helper
INFO - 2021-11-19 09:30:42 --> Helper loaded: my_helper
INFO - 2021-11-19 09:30:42 --> Database Driver Class Initialized
DEBUG - 2021-11-19 09:30:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 09:30:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 09:30:42 --> Controller Class Initialized
DEBUG - 2021-11-19 09:30:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-19 09:30:42 --> Final output sent to browser
DEBUG - 2021-11-19 09:30:42 --> Total execution time: 0.1681
INFO - 2021-11-19 09:31:05 --> Config Class Initialized
INFO - 2021-11-19 09:31:05 --> Hooks Class Initialized
DEBUG - 2021-11-19 09:31:05 --> UTF-8 Support Enabled
INFO - 2021-11-19 09:31:05 --> Utf8 Class Initialized
INFO - 2021-11-19 09:31:05 --> URI Class Initialized
INFO - 2021-11-19 09:31:05 --> Router Class Initialized
INFO - 2021-11-19 09:31:05 --> Output Class Initialized
INFO - 2021-11-19 09:31:05 --> Security Class Initialized
DEBUG - 2021-11-19 09:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 09:31:05 --> Input Class Initialized
INFO - 2021-11-19 09:31:05 --> Language Class Initialized
INFO - 2021-11-19 09:31:06 --> Language Class Initialized
INFO - 2021-11-19 09:31:06 --> Config Class Initialized
INFO - 2021-11-19 09:31:06 --> Loader Class Initialized
INFO - 2021-11-19 09:31:06 --> Helper loaded: url_helper
INFO - 2021-11-19 09:31:06 --> Helper loaded: file_helper
INFO - 2021-11-19 09:31:06 --> Helper loaded: form_helper
INFO - 2021-11-19 09:31:06 --> Helper loaded: my_helper
INFO - 2021-11-19 09:31:06 --> Database Driver Class Initialized
DEBUG - 2021-11-19 09:31:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 09:31:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 09:31:06 --> Controller Class Initialized
DEBUG - 2021-11-19 09:31:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-19 09:31:06 --> Final output sent to browser
DEBUG - 2021-11-19 09:31:06 --> Total execution time: 0.1372
INFO - 2021-11-19 09:31:25 --> Config Class Initialized
INFO - 2021-11-19 09:31:25 --> Hooks Class Initialized
DEBUG - 2021-11-19 09:31:25 --> UTF-8 Support Enabled
INFO - 2021-11-19 09:31:25 --> Utf8 Class Initialized
INFO - 2021-11-19 09:31:25 --> URI Class Initialized
INFO - 2021-11-19 09:31:25 --> Router Class Initialized
INFO - 2021-11-19 09:31:25 --> Output Class Initialized
INFO - 2021-11-19 09:31:25 --> Security Class Initialized
DEBUG - 2021-11-19 09:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 09:31:25 --> Input Class Initialized
INFO - 2021-11-19 09:31:25 --> Language Class Initialized
INFO - 2021-11-19 09:31:25 --> Language Class Initialized
INFO - 2021-11-19 09:31:25 --> Config Class Initialized
INFO - 2021-11-19 09:31:25 --> Loader Class Initialized
INFO - 2021-11-19 09:31:25 --> Helper loaded: url_helper
INFO - 2021-11-19 09:31:25 --> Helper loaded: file_helper
INFO - 2021-11-19 09:31:25 --> Helper loaded: form_helper
INFO - 2021-11-19 09:31:25 --> Helper loaded: my_helper
INFO - 2021-11-19 09:31:25 --> Database Driver Class Initialized
DEBUG - 2021-11-19 09:31:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 09:31:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 09:31:25 --> Controller Class Initialized
DEBUG - 2021-11-19 09:31:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-19 09:31:25 --> Final output sent to browser
DEBUG - 2021-11-19 09:31:25 --> Total execution time: 0.1294
INFO - 2021-11-19 09:31:33 --> Config Class Initialized
INFO - 2021-11-19 09:31:33 --> Hooks Class Initialized
DEBUG - 2021-11-19 09:31:33 --> UTF-8 Support Enabled
INFO - 2021-11-19 09:31:33 --> Utf8 Class Initialized
INFO - 2021-11-19 09:31:33 --> URI Class Initialized
INFO - 2021-11-19 09:31:33 --> Router Class Initialized
INFO - 2021-11-19 09:31:33 --> Output Class Initialized
INFO - 2021-11-19 09:31:33 --> Security Class Initialized
DEBUG - 2021-11-19 09:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 09:31:33 --> Input Class Initialized
INFO - 2021-11-19 09:31:33 --> Language Class Initialized
INFO - 2021-11-19 09:31:33 --> Language Class Initialized
INFO - 2021-11-19 09:31:33 --> Config Class Initialized
INFO - 2021-11-19 09:31:33 --> Loader Class Initialized
INFO - 2021-11-19 09:31:33 --> Helper loaded: url_helper
INFO - 2021-11-19 09:31:33 --> Helper loaded: file_helper
INFO - 2021-11-19 09:31:33 --> Helper loaded: form_helper
INFO - 2021-11-19 09:31:33 --> Helper loaded: my_helper
INFO - 2021-11-19 09:31:33 --> Database Driver Class Initialized
DEBUG - 2021-11-19 09:31:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 09:31:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 09:31:33 --> Controller Class Initialized
DEBUG - 2021-11-19 09:31:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-19 09:31:33 --> Final output sent to browser
DEBUG - 2021-11-19 09:31:33 --> Total execution time: 0.1698
INFO - 2021-11-19 09:32:27 --> Config Class Initialized
INFO - 2021-11-19 09:32:27 --> Hooks Class Initialized
DEBUG - 2021-11-19 09:32:27 --> UTF-8 Support Enabled
INFO - 2021-11-19 09:32:27 --> Utf8 Class Initialized
INFO - 2021-11-19 09:32:27 --> URI Class Initialized
INFO - 2021-11-19 09:32:27 --> Router Class Initialized
INFO - 2021-11-19 09:32:27 --> Output Class Initialized
INFO - 2021-11-19 09:32:27 --> Security Class Initialized
DEBUG - 2021-11-19 09:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 09:32:27 --> Input Class Initialized
INFO - 2021-11-19 09:32:27 --> Language Class Initialized
INFO - 2021-11-19 09:32:27 --> Language Class Initialized
INFO - 2021-11-19 09:32:27 --> Config Class Initialized
INFO - 2021-11-19 09:32:27 --> Loader Class Initialized
INFO - 2021-11-19 09:32:27 --> Helper loaded: url_helper
INFO - 2021-11-19 09:32:27 --> Helper loaded: file_helper
INFO - 2021-11-19 09:32:27 --> Helper loaded: form_helper
INFO - 2021-11-19 09:32:27 --> Helper loaded: my_helper
INFO - 2021-11-19 09:32:27 --> Database Driver Class Initialized
DEBUG - 2021-11-19 09:32:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 09:32:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 09:32:27 --> Controller Class Initialized
DEBUG - 2021-11-19 09:32:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-19 09:32:27 --> Final output sent to browser
DEBUG - 2021-11-19 09:32:27 --> Total execution time: 0.1560
INFO - 2021-11-19 09:32:37 --> Config Class Initialized
INFO - 2021-11-19 09:32:37 --> Hooks Class Initialized
DEBUG - 2021-11-19 09:32:37 --> UTF-8 Support Enabled
INFO - 2021-11-19 09:32:37 --> Utf8 Class Initialized
INFO - 2021-11-19 09:32:37 --> URI Class Initialized
INFO - 2021-11-19 09:32:37 --> Router Class Initialized
INFO - 2021-11-19 09:32:37 --> Output Class Initialized
INFO - 2021-11-19 09:32:37 --> Security Class Initialized
DEBUG - 2021-11-19 09:32:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 09:32:37 --> Input Class Initialized
INFO - 2021-11-19 09:32:37 --> Language Class Initialized
INFO - 2021-11-19 09:32:37 --> Language Class Initialized
INFO - 2021-11-19 09:32:37 --> Config Class Initialized
INFO - 2021-11-19 09:32:37 --> Loader Class Initialized
INFO - 2021-11-19 09:32:37 --> Helper loaded: url_helper
INFO - 2021-11-19 09:32:37 --> Helper loaded: file_helper
INFO - 2021-11-19 09:32:37 --> Helper loaded: form_helper
INFO - 2021-11-19 09:32:37 --> Helper loaded: my_helper
INFO - 2021-11-19 09:32:37 --> Database Driver Class Initialized
DEBUG - 2021-11-19 09:32:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 09:32:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 09:32:37 --> Controller Class Initialized
DEBUG - 2021-11-19 09:32:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-19 09:32:38 --> Final output sent to browser
DEBUG - 2021-11-19 09:32:38 --> Total execution time: 0.1423
INFO - 2021-11-19 09:37:37 --> Config Class Initialized
INFO - 2021-11-19 09:37:37 --> Hooks Class Initialized
DEBUG - 2021-11-19 09:37:37 --> UTF-8 Support Enabled
INFO - 2021-11-19 09:37:37 --> Utf8 Class Initialized
INFO - 2021-11-19 09:37:37 --> URI Class Initialized
INFO - 2021-11-19 09:37:37 --> Router Class Initialized
INFO - 2021-11-19 09:37:37 --> Output Class Initialized
INFO - 2021-11-19 09:37:37 --> Security Class Initialized
DEBUG - 2021-11-19 09:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 09:37:37 --> Input Class Initialized
INFO - 2021-11-19 09:37:37 --> Language Class Initialized
INFO - 2021-11-19 09:37:37 --> Language Class Initialized
INFO - 2021-11-19 09:37:37 --> Config Class Initialized
INFO - 2021-11-19 09:37:37 --> Loader Class Initialized
INFO - 2021-11-19 09:37:37 --> Helper loaded: url_helper
INFO - 2021-11-19 09:37:37 --> Helper loaded: file_helper
INFO - 2021-11-19 09:37:37 --> Helper loaded: form_helper
INFO - 2021-11-19 09:37:37 --> Helper loaded: my_helper
INFO - 2021-11-19 09:37:37 --> Database Driver Class Initialized
DEBUG - 2021-11-19 09:37:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 09:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 09:37:37 --> Controller Class Initialized
INFO - 2021-11-19 09:37:37 --> Helper loaded: cookie_helper
INFO - 2021-11-19 09:37:37 --> Config Class Initialized
INFO - 2021-11-19 09:37:37 --> Hooks Class Initialized
DEBUG - 2021-11-19 09:37:37 --> UTF-8 Support Enabled
INFO - 2021-11-19 09:37:37 --> Utf8 Class Initialized
INFO - 2021-11-19 09:37:37 --> URI Class Initialized
INFO - 2021-11-19 09:37:37 --> Router Class Initialized
INFO - 2021-11-19 09:37:37 --> Output Class Initialized
INFO - 2021-11-19 09:37:37 --> Security Class Initialized
DEBUG - 2021-11-19 09:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 09:37:37 --> Input Class Initialized
INFO - 2021-11-19 09:37:37 --> Language Class Initialized
INFO - 2021-11-19 09:37:37 --> Language Class Initialized
INFO - 2021-11-19 09:37:37 --> Config Class Initialized
INFO - 2021-11-19 09:37:37 --> Loader Class Initialized
INFO - 2021-11-19 09:37:37 --> Helper loaded: url_helper
INFO - 2021-11-19 09:37:37 --> Helper loaded: file_helper
INFO - 2021-11-19 09:37:37 --> Helper loaded: form_helper
INFO - 2021-11-19 09:37:37 --> Helper loaded: my_helper
INFO - 2021-11-19 09:37:37 --> Database Driver Class Initialized
DEBUG - 2021-11-19 09:37:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 09:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 09:37:37 --> Controller Class Initialized
DEBUG - 2021-11-19 09:37:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-11-19 09:37:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 09:37:37 --> Final output sent to browser
DEBUG - 2021-11-19 09:37:37 --> Total execution time: 0.0736
INFO - 2021-11-19 09:37:40 --> Config Class Initialized
INFO - 2021-11-19 09:37:40 --> Hooks Class Initialized
DEBUG - 2021-11-19 09:37:40 --> UTF-8 Support Enabled
INFO - 2021-11-19 09:37:40 --> Utf8 Class Initialized
INFO - 2021-11-19 09:37:40 --> URI Class Initialized
INFO - 2021-11-19 09:37:40 --> Router Class Initialized
INFO - 2021-11-19 09:37:40 --> Output Class Initialized
INFO - 2021-11-19 09:37:40 --> Security Class Initialized
DEBUG - 2021-11-19 09:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 09:37:40 --> Input Class Initialized
INFO - 2021-11-19 09:37:40 --> Language Class Initialized
INFO - 2021-11-19 09:37:40 --> Language Class Initialized
INFO - 2021-11-19 09:37:40 --> Config Class Initialized
INFO - 2021-11-19 09:37:40 --> Loader Class Initialized
INFO - 2021-11-19 09:37:40 --> Helper loaded: url_helper
INFO - 2021-11-19 09:37:40 --> Helper loaded: file_helper
INFO - 2021-11-19 09:37:40 --> Helper loaded: form_helper
INFO - 2021-11-19 09:37:40 --> Helper loaded: my_helper
INFO - 2021-11-19 09:37:40 --> Database Driver Class Initialized
DEBUG - 2021-11-19 09:37:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 09:37:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 09:37:40 --> Controller Class Initialized
INFO - 2021-11-19 09:37:40 --> Helper loaded: cookie_helper
INFO - 2021-11-19 09:37:40 --> Final output sent to browser
DEBUG - 2021-11-19 09:37:40 --> Total execution time: 0.0972
INFO - 2021-11-19 09:37:40 --> Config Class Initialized
INFO - 2021-11-19 09:37:40 --> Hooks Class Initialized
DEBUG - 2021-11-19 09:37:40 --> UTF-8 Support Enabled
INFO - 2021-11-19 09:37:40 --> Utf8 Class Initialized
INFO - 2021-11-19 09:37:40 --> URI Class Initialized
INFO - 2021-11-19 09:37:40 --> Router Class Initialized
INFO - 2021-11-19 09:37:40 --> Output Class Initialized
INFO - 2021-11-19 09:37:40 --> Security Class Initialized
DEBUG - 2021-11-19 09:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 09:37:40 --> Input Class Initialized
INFO - 2021-11-19 09:37:40 --> Language Class Initialized
INFO - 2021-11-19 09:37:40 --> Language Class Initialized
INFO - 2021-11-19 09:37:40 --> Config Class Initialized
INFO - 2021-11-19 09:37:40 --> Loader Class Initialized
INFO - 2021-11-19 09:37:40 --> Helper loaded: url_helper
INFO - 2021-11-19 09:37:40 --> Helper loaded: file_helper
INFO - 2021-11-19 09:37:40 --> Helper loaded: form_helper
INFO - 2021-11-19 09:37:40 --> Helper loaded: my_helper
INFO - 2021-11-19 09:37:40 --> Database Driver Class Initialized
DEBUG - 2021-11-19 09:37:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 09:37:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 09:37:40 --> Controller Class Initialized
DEBUG - 2021-11-19 09:37:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-11-19 09:37:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 09:37:41 --> Final output sent to browser
DEBUG - 2021-11-19 09:37:41 --> Total execution time: 1.1121
INFO - 2021-11-19 09:37:43 --> Config Class Initialized
INFO - 2021-11-19 09:37:43 --> Hooks Class Initialized
DEBUG - 2021-11-19 09:37:43 --> UTF-8 Support Enabled
INFO - 2021-11-19 09:37:43 --> Utf8 Class Initialized
INFO - 2021-11-19 09:37:43 --> URI Class Initialized
INFO - 2021-11-19 09:37:43 --> Router Class Initialized
INFO - 2021-11-19 09:37:43 --> Output Class Initialized
INFO - 2021-11-19 09:37:43 --> Security Class Initialized
DEBUG - 2021-11-19 09:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 09:37:43 --> Input Class Initialized
INFO - 2021-11-19 09:37:43 --> Language Class Initialized
INFO - 2021-11-19 09:37:43 --> Language Class Initialized
INFO - 2021-11-19 09:37:43 --> Config Class Initialized
INFO - 2021-11-19 09:37:43 --> Loader Class Initialized
INFO - 2021-11-19 09:37:43 --> Helper loaded: url_helper
INFO - 2021-11-19 09:37:43 --> Helper loaded: file_helper
INFO - 2021-11-19 09:37:43 --> Helper loaded: form_helper
INFO - 2021-11-19 09:37:43 --> Helper loaded: my_helper
INFO - 2021-11-19 09:37:43 --> Database Driver Class Initialized
DEBUG - 2021-11-19 09:37:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 09:37:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 09:37:43 --> Controller Class Initialized
DEBUG - 2021-11-19 09:37:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-11-19 09:37:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-19 09:37:43 --> Final output sent to browser
DEBUG - 2021-11-19 09:37:43 --> Total execution time: 0.0981
INFO - 2021-11-19 09:37:44 --> Config Class Initialized
INFO - 2021-11-19 09:37:44 --> Hooks Class Initialized
DEBUG - 2021-11-19 09:37:44 --> UTF-8 Support Enabled
INFO - 2021-11-19 09:37:44 --> Utf8 Class Initialized
INFO - 2021-11-19 09:37:44 --> URI Class Initialized
INFO - 2021-11-19 09:37:44 --> Router Class Initialized
INFO - 2021-11-19 09:37:44 --> Output Class Initialized
INFO - 2021-11-19 09:37:44 --> Security Class Initialized
DEBUG - 2021-11-19 09:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 09:37:44 --> Input Class Initialized
INFO - 2021-11-19 09:37:44 --> Language Class Initialized
INFO - 2021-11-19 09:37:44 --> Language Class Initialized
INFO - 2021-11-19 09:37:44 --> Config Class Initialized
INFO - 2021-11-19 09:37:44 --> Loader Class Initialized
INFO - 2021-11-19 09:37:44 --> Helper loaded: url_helper
INFO - 2021-11-19 09:37:44 --> Helper loaded: file_helper
INFO - 2021-11-19 09:37:44 --> Helper loaded: form_helper
INFO - 2021-11-19 09:37:44 --> Helper loaded: my_helper
INFO - 2021-11-19 09:37:44 --> Database Driver Class Initialized
DEBUG - 2021-11-19 09:37:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 09:37:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 09:37:44 --> Controller Class Initialized
DEBUG - 2021-11-19 09:37:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-19 09:37:44 --> Final output sent to browser
DEBUG - 2021-11-19 09:37:44 --> Total execution time: 0.2164
INFO - 2021-11-19 09:38:38 --> Config Class Initialized
INFO - 2021-11-19 09:38:38 --> Hooks Class Initialized
DEBUG - 2021-11-19 09:38:38 --> UTF-8 Support Enabled
INFO - 2021-11-19 09:38:38 --> Utf8 Class Initialized
INFO - 2021-11-19 09:38:38 --> URI Class Initialized
INFO - 2021-11-19 09:38:38 --> Router Class Initialized
INFO - 2021-11-19 09:38:38 --> Output Class Initialized
INFO - 2021-11-19 09:38:38 --> Security Class Initialized
DEBUG - 2021-11-19 09:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-19 09:38:38 --> Input Class Initialized
INFO - 2021-11-19 09:38:38 --> Language Class Initialized
INFO - 2021-11-19 09:38:38 --> Language Class Initialized
INFO - 2021-11-19 09:38:38 --> Config Class Initialized
INFO - 2021-11-19 09:38:38 --> Loader Class Initialized
INFO - 2021-11-19 09:38:38 --> Helper loaded: url_helper
INFO - 2021-11-19 09:38:38 --> Helper loaded: file_helper
INFO - 2021-11-19 09:38:38 --> Helper loaded: form_helper
INFO - 2021-11-19 09:38:38 --> Helper loaded: my_helper
INFO - 2021-11-19 09:38:38 --> Database Driver Class Initialized
DEBUG - 2021-11-19 09:38:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-19 09:38:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-19 09:38:38 --> Controller Class Initialized
DEBUG - 2021-11-19 09:38:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-19 09:38:38 --> Final output sent to browser
DEBUG - 2021-11-19 09:38:38 --> Total execution time: 0.1885
