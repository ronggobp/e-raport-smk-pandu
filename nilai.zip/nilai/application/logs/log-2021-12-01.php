<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-12-01 02:14:03 --> Config Class Initialized
INFO - 2021-12-01 02:14:03 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:14:03 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:14:03 --> Utf8 Class Initialized
INFO - 2021-12-01 02:14:03 --> URI Class Initialized
DEBUG - 2021-12-01 02:14:03 --> No URI present. Default controller set.
INFO - 2021-12-01 02:14:03 --> Router Class Initialized
INFO - 2021-12-01 02:14:03 --> Output Class Initialized
INFO - 2021-12-01 02:14:03 --> Security Class Initialized
DEBUG - 2021-12-01 02:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:14:03 --> Input Class Initialized
INFO - 2021-12-01 02:14:03 --> Language Class Initialized
INFO - 2021-12-01 02:14:03 --> Language Class Initialized
INFO - 2021-12-01 02:14:03 --> Config Class Initialized
INFO - 2021-12-01 02:14:03 --> Loader Class Initialized
INFO - 2021-12-01 02:14:03 --> Helper loaded: url_helper
INFO - 2021-12-01 02:14:03 --> Helper loaded: file_helper
INFO - 2021-12-01 02:14:03 --> Helper loaded: form_helper
INFO - 2021-12-01 02:14:03 --> Helper loaded: my_helper
INFO - 2021-12-01 02:14:04 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:14:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:14:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:14:04 --> Controller Class Initialized
INFO - 2021-12-01 02:14:04 --> Config Class Initialized
INFO - 2021-12-01 02:14:04 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:14:04 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:14:04 --> Utf8 Class Initialized
INFO - 2021-12-01 02:14:04 --> URI Class Initialized
INFO - 2021-12-01 02:14:04 --> Router Class Initialized
INFO - 2021-12-01 02:14:04 --> Output Class Initialized
INFO - 2021-12-01 02:14:04 --> Security Class Initialized
DEBUG - 2021-12-01 02:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:14:04 --> Input Class Initialized
INFO - 2021-12-01 02:14:04 --> Language Class Initialized
INFO - 2021-12-01 02:14:04 --> Language Class Initialized
INFO - 2021-12-01 02:14:04 --> Config Class Initialized
INFO - 2021-12-01 02:14:04 --> Loader Class Initialized
INFO - 2021-12-01 02:14:04 --> Helper loaded: url_helper
INFO - 2021-12-01 02:14:04 --> Helper loaded: file_helper
INFO - 2021-12-01 02:14:04 --> Helper loaded: form_helper
INFO - 2021-12-01 02:14:04 --> Helper loaded: my_helper
INFO - 2021-12-01 02:14:04 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:14:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:14:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:14:04 --> Controller Class Initialized
DEBUG - 2021-12-01 02:14:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-01 02:14:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 02:14:04 --> Final output sent to browser
DEBUG - 2021-12-01 02:14:04 --> Total execution time: 0.1005
INFO - 2021-12-01 02:14:11 --> Config Class Initialized
INFO - 2021-12-01 02:14:11 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:14:11 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:14:11 --> Utf8 Class Initialized
INFO - 2021-12-01 02:14:11 --> URI Class Initialized
INFO - 2021-12-01 02:14:11 --> Router Class Initialized
INFO - 2021-12-01 02:14:11 --> Output Class Initialized
INFO - 2021-12-01 02:14:11 --> Security Class Initialized
DEBUG - 2021-12-01 02:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:14:11 --> Input Class Initialized
INFO - 2021-12-01 02:14:11 --> Language Class Initialized
INFO - 2021-12-01 02:14:11 --> Language Class Initialized
INFO - 2021-12-01 02:14:11 --> Config Class Initialized
INFO - 2021-12-01 02:14:11 --> Loader Class Initialized
INFO - 2021-12-01 02:14:11 --> Helper loaded: url_helper
INFO - 2021-12-01 02:14:11 --> Helper loaded: file_helper
INFO - 2021-12-01 02:14:11 --> Helper loaded: form_helper
INFO - 2021-12-01 02:14:11 --> Helper loaded: my_helper
INFO - 2021-12-01 02:14:11 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:14:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:14:11 --> Controller Class Initialized
INFO - 2021-12-01 02:14:11 --> Helper loaded: cookie_helper
INFO - 2021-12-01 02:14:11 --> Final output sent to browser
DEBUG - 2021-12-01 02:14:11 --> Total execution time: 0.1182
INFO - 2021-12-01 02:14:12 --> Config Class Initialized
INFO - 2021-12-01 02:14:12 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:14:12 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:14:12 --> Utf8 Class Initialized
INFO - 2021-12-01 02:14:12 --> URI Class Initialized
INFO - 2021-12-01 02:14:12 --> Router Class Initialized
INFO - 2021-12-01 02:14:12 --> Output Class Initialized
INFO - 2021-12-01 02:14:12 --> Security Class Initialized
DEBUG - 2021-12-01 02:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:14:12 --> Input Class Initialized
INFO - 2021-12-01 02:14:12 --> Language Class Initialized
INFO - 2021-12-01 02:14:12 --> Language Class Initialized
INFO - 2021-12-01 02:14:12 --> Config Class Initialized
INFO - 2021-12-01 02:14:12 --> Loader Class Initialized
INFO - 2021-12-01 02:14:12 --> Helper loaded: url_helper
INFO - 2021-12-01 02:14:12 --> Helper loaded: file_helper
INFO - 2021-12-01 02:14:12 --> Helper loaded: form_helper
INFO - 2021-12-01 02:14:12 --> Helper loaded: my_helper
INFO - 2021-12-01 02:14:12 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:14:12 --> Controller Class Initialized
DEBUG - 2021-12-01 02:14:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-01 02:14:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 02:14:12 --> Final output sent to browser
DEBUG - 2021-12-01 02:14:12 --> Total execution time: 0.3386
INFO - 2021-12-01 02:14:20 --> Config Class Initialized
INFO - 2021-12-01 02:14:20 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:14:20 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:14:20 --> Utf8 Class Initialized
INFO - 2021-12-01 02:14:20 --> URI Class Initialized
INFO - 2021-12-01 02:14:20 --> Router Class Initialized
INFO - 2021-12-01 02:14:20 --> Output Class Initialized
INFO - 2021-12-01 02:14:20 --> Security Class Initialized
DEBUG - 2021-12-01 02:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:14:20 --> Input Class Initialized
INFO - 2021-12-01 02:14:20 --> Language Class Initialized
INFO - 2021-12-01 02:14:20 --> Language Class Initialized
INFO - 2021-12-01 02:14:20 --> Config Class Initialized
INFO - 2021-12-01 02:14:20 --> Loader Class Initialized
INFO - 2021-12-01 02:14:20 --> Helper loaded: url_helper
INFO - 2021-12-01 02:14:20 --> Helper loaded: file_helper
INFO - 2021-12-01 02:14:20 --> Helper loaded: form_helper
INFO - 2021-12-01 02:14:20 --> Helper loaded: my_helper
INFO - 2021-12-01 02:14:20 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:14:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:14:20 --> Controller Class Initialized
DEBUG - 2021-12-01 02:14:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-01 02:14:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 02:14:20 --> Final output sent to browser
DEBUG - 2021-12-01 02:14:20 --> Total execution time: 0.1567
INFO - 2021-12-01 02:14:58 --> Config Class Initialized
INFO - 2021-12-01 02:14:58 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:14:58 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:14:58 --> Utf8 Class Initialized
INFO - 2021-12-01 02:14:58 --> URI Class Initialized
INFO - 2021-12-01 02:14:58 --> Router Class Initialized
INFO - 2021-12-01 02:14:58 --> Output Class Initialized
INFO - 2021-12-01 02:14:58 --> Security Class Initialized
DEBUG - 2021-12-01 02:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:14:58 --> Input Class Initialized
INFO - 2021-12-01 02:14:58 --> Language Class Initialized
INFO - 2021-12-01 02:14:58 --> Language Class Initialized
INFO - 2021-12-01 02:14:58 --> Config Class Initialized
INFO - 2021-12-01 02:14:58 --> Loader Class Initialized
INFO - 2021-12-01 02:14:58 --> Helper loaded: url_helper
INFO - 2021-12-01 02:14:58 --> Helper loaded: file_helper
INFO - 2021-12-01 02:14:58 --> Helper loaded: form_helper
INFO - 2021-12-01 02:14:58 --> Helper loaded: my_helper
INFO - 2021-12-01 02:14:58 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:14:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:14:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:14:58 --> Controller Class Initialized
DEBUG - 2021-12-01 02:14:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 02:14:58 --> Final output sent to browser
DEBUG - 2021-12-01 02:14:58 --> Total execution time: 0.2588
INFO - 2021-12-01 02:15:14 --> Config Class Initialized
INFO - 2021-12-01 02:15:14 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:15:14 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:15:14 --> Utf8 Class Initialized
INFO - 2021-12-01 02:15:14 --> URI Class Initialized
INFO - 2021-12-01 02:15:14 --> Router Class Initialized
INFO - 2021-12-01 02:15:14 --> Output Class Initialized
INFO - 2021-12-01 02:15:14 --> Security Class Initialized
DEBUG - 2021-12-01 02:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:15:14 --> Input Class Initialized
INFO - 2021-12-01 02:15:14 --> Language Class Initialized
INFO - 2021-12-01 02:15:14 --> Language Class Initialized
INFO - 2021-12-01 02:15:14 --> Config Class Initialized
INFO - 2021-12-01 02:15:14 --> Loader Class Initialized
INFO - 2021-12-01 02:15:14 --> Helper loaded: url_helper
INFO - 2021-12-01 02:15:14 --> Helper loaded: file_helper
INFO - 2021-12-01 02:15:14 --> Helper loaded: form_helper
INFO - 2021-12-01 02:15:14 --> Helper loaded: my_helper
INFO - 2021-12-01 02:15:14 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:15:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:15:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:15:14 --> Controller Class Initialized
DEBUG - 2021-12-01 02:15:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 02:15:14 --> Final output sent to browser
DEBUG - 2021-12-01 02:15:14 --> Total execution time: 0.1349
INFO - 2021-12-01 02:16:02 --> Config Class Initialized
INFO - 2021-12-01 02:16:02 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:16:02 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:16:02 --> Utf8 Class Initialized
INFO - 2021-12-01 02:16:02 --> URI Class Initialized
INFO - 2021-12-01 02:16:02 --> Router Class Initialized
INFO - 2021-12-01 02:16:02 --> Output Class Initialized
INFO - 2021-12-01 02:16:02 --> Security Class Initialized
DEBUG - 2021-12-01 02:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:16:02 --> Input Class Initialized
INFO - 2021-12-01 02:16:02 --> Language Class Initialized
INFO - 2021-12-01 02:16:02 --> Language Class Initialized
INFO - 2021-12-01 02:16:02 --> Config Class Initialized
INFO - 2021-12-01 02:16:02 --> Loader Class Initialized
INFO - 2021-12-01 02:16:02 --> Helper loaded: url_helper
INFO - 2021-12-01 02:16:02 --> Helper loaded: file_helper
INFO - 2021-12-01 02:16:02 --> Helper loaded: form_helper
INFO - 2021-12-01 02:16:02 --> Helper loaded: my_helper
INFO - 2021-12-01 02:16:02 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:16:03 --> Controller Class Initialized
DEBUG - 2021-12-01 02:16:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 02:16:03 --> Final output sent to browser
DEBUG - 2021-12-01 02:16:03 --> Total execution time: 0.0990
INFO - 2021-12-01 02:16:03 --> Config Class Initialized
INFO - 2021-12-01 02:16:03 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:16:03 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:16:03 --> Utf8 Class Initialized
INFO - 2021-12-01 02:16:03 --> URI Class Initialized
INFO - 2021-12-01 02:16:03 --> Router Class Initialized
INFO - 2021-12-01 02:16:03 --> Output Class Initialized
INFO - 2021-12-01 02:16:03 --> Security Class Initialized
DEBUG - 2021-12-01 02:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:16:03 --> Input Class Initialized
INFO - 2021-12-01 02:16:03 --> Language Class Initialized
INFO - 2021-12-01 02:16:03 --> Language Class Initialized
INFO - 2021-12-01 02:16:03 --> Config Class Initialized
INFO - 2021-12-01 02:16:03 --> Loader Class Initialized
INFO - 2021-12-01 02:16:03 --> Helper loaded: url_helper
INFO - 2021-12-01 02:16:03 --> Helper loaded: file_helper
INFO - 2021-12-01 02:16:03 --> Helper loaded: form_helper
INFO - 2021-12-01 02:16:03 --> Helper loaded: my_helper
INFO - 2021-12-01 02:16:03 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:16:03 --> Controller Class Initialized
DEBUG - 2021-12-01 02:16:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 02:16:04 --> Final output sent to browser
DEBUG - 2021-12-01 02:16:04 --> Total execution time: 0.0853
INFO - 2021-12-01 02:16:04 --> Config Class Initialized
INFO - 2021-12-01 02:16:04 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:16:04 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:16:04 --> Utf8 Class Initialized
INFO - 2021-12-01 02:16:04 --> URI Class Initialized
INFO - 2021-12-01 02:16:04 --> Router Class Initialized
INFO - 2021-12-01 02:16:04 --> Output Class Initialized
INFO - 2021-12-01 02:16:04 --> Security Class Initialized
DEBUG - 2021-12-01 02:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:16:04 --> Input Class Initialized
INFO - 2021-12-01 02:16:04 --> Language Class Initialized
INFO - 2021-12-01 02:16:04 --> Language Class Initialized
INFO - 2021-12-01 02:16:04 --> Config Class Initialized
INFO - 2021-12-01 02:16:04 --> Loader Class Initialized
INFO - 2021-12-01 02:16:04 --> Helper loaded: url_helper
INFO - 2021-12-01 02:16:04 --> Helper loaded: file_helper
INFO - 2021-12-01 02:16:04 --> Helper loaded: form_helper
INFO - 2021-12-01 02:16:04 --> Helper loaded: my_helper
INFO - 2021-12-01 02:16:04 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:16:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:16:04 --> Controller Class Initialized
DEBUG - 2021-12-01 02:16:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 02:16:04 --> Final output sent to browser
DEBUG - 2021-12-01 02:16:04 --> Total execution time: 0.0780
INFO - 2021-12-01 02:16:05 --> Config Class Initialized
INFO - 2021-12-01 02:16:05 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:16:05 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:16:05 --> Utf8 Class Initialized
INFO - 2021-12-01 02:16:05 --> URI Class Initialized
INFO - 2021-12-01 02:16:05 --> Router Class Initialized
INFO - 2021-12-01 02:16:05 --> Output Class Initialized
INFO - 2021-12-01 02:16:05 --> Security Class Initialized
DEBUG - 2021-12-01 02:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:16:05 --> Input Class Initialized
INFO - 2021-12-01 02:16:05 --> Language Class Initialized
INFO - 2021-12-01 02:16:05 --> Language Class Initialized
INFO - 2021-12-01 02:16:05 --> Config Class Initialized
INFO - 2021-12-01 02:16:05 --> Loader Class Initialized
INFO - 2021-12-01 02:16:05 --> Helper loaded: url_helper
INFO - 2021-12-01 02:16:05 --> Helper loaded: file_helper
INFO - 2021-12-01 02:16:05 --> Helper loaded: form_helper
INFO - 2021-12-01 02:16:05 --> Helper loaded: my_helper
INFO - 2021-12-01 02:16:05 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:16:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:16:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:16:05 --> Controller Class Initialized
DEBUG - 2021-12-01 02:16:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 02:16:05 --> Final output sent to browser
DEBUG - 2021-12-01 02:16:05 --> Total execution time: 0.0691
INFO - 2021-12-01 02:16:05 --> Config Class Initialized
INFO - 2021-12-01 02:16:05 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:16:05 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:16:05 --> Utf8 Class Initialized
INFO - 2021-12-01 02:16:05 --> URI Class Initialized
INFO - 2021-12-01 02:16:05 --> Router Class Initialized
INFO - 2021-12-01 02:16:05 --> Output Class Initialized
INFO - 2021-12-01 02:16:05 --> Security Class Initialized
DEBUG - 2021-12-01 02:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:16:05 --> Input Class Initialized
INFO - 2021-12-01 02:16:05 --> Language Class Initialized
INFO - 2021-12-01 02:16:05 --> Language Class Initialized
INFO - 2021-12-01 02:16:05 --> Config Class Initialized
INFO - 2021-12-01 02:16:05 --> Loader Class Initialized
INFO - 2021-12-01 02:16:05 --> Helper loaded: url_helper
INFO - 2021-12-01 02:16:05 --> Helper loaded: file_helper
INFO - 2021-12-01 02:16:05 --> Helper loaded: form_helper
INFO - 2021-12-01 02:16:05 --> Helper loaded: my_helper
INFO - 2021-12-01 02:16:05 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:16:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:16:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:16:05 --> Controller Class Initialized
DEBUG - 2021-12-01 02:16:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 02:16:05 --> Final output sent to browser
DEBUG - 2021-12-01 02:16:05 --> Total execution time: 0.0677
INFO - 2021-12-01 02:16:06 --> Config Class Initialized
INFO - 2021-12-01 02:16:06 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:16:06 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:16:06 --> Utf8 Class Initialized
INFO - 2021-12-01 02:16:06 --> URI Class Initialized
INFO - 2021-12-01 02:16:06 --> Router Class Initialized
INFO - 2021-12-01 02:16:06 --> Output Class Initialized
INFO - 2021-12-01 02:16:06 --> Security Class Initialized
DEBUG - 2021-12-01 02:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:16:06 --> Input Class Initialized
INFO - 2021-12-01 02:16:06 --> Language Class Initialized
INFO - 2021-12-01 02:16:06 --> Language Class Initialized
INFO - 2021-12-01 02:16:06 --> Config Class Initialized
INFO - 2021-12-01 02:16:06 --> Loader Class Initialized
INFO - 2021-12-01 02:16:06 --> Helper loaded: url_helper
INFO - 2021-12-01 02:16:06 --> Helper loaded: file_helper
INFO - 2021-12-01 02:16:06 --> Helper loaded: form_helper
INFO - 2021-12-01 02:16:06 --> Helper loaded: my_helper
INFO - 2021-12-01 02:16:06 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:16:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:16:06 --> Controller Class Initialized
DEBUG - 2021-12-01 02:16:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 02:16:06 --> Final output sent to browser
DEBUG - 2021-12-01 02:16:06 --> Total execution time: 0.0651
INFO - 2021-12-01 02:16:07 --> Config Class Initialized
INFO - 2021-12-01 02:16:07 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:16:07 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:16:07 --> Utf8 Class Initialized
INFO - 2021-12-01 02:16:07 --> URI Class Initialized
INFO - 2021-12-01 02:16:07 --> Router Class Initialized
INFO - 2021-12-01 02:16:07 --> Output Class Initialized
INFO - 2021-12-01 02:16:07 --> Security Class Initialized
DEBUG - 2021-12-01 02:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:16:07 --> Input Class Initialized
INFO - 2021-12-01 02:16:07 --> Language Class Initialized
INFO - 2021-12-01 02:16:07 --> Language Class Initialized
INFO - 2021-12-01 02:16:07 --> Config Class Initialized
INFO - 2021-12-01 02:16:07 --> Loader Class Initialized
INFO - 2021-12-01 02:16:07 --> Helper loaded: url_helper
INFO - 2021-12-01 02:16:07 --> Helper loaded: file_helper
INFO - 2021-12-01 02:16:07 --> Helper loaded: form_helper
INFO - 2021-12-01 02:16:07 --> Helper loaded: my_helper
INFO - 2021-12-01 02:16:07 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:16:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:16:07 --> Controller Class Initialized
DEBUG - 2021-12-01 02:16:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 02:16:07 --> Final output sent to browser
DEBUG - 2021-12-01 02:16:07 --> Total execution time: 0.0690
INFO - 2021-12-01 02:16:22 --> Config Class Initialized
INFO - 2021-12-01 02:16:22 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:16:22 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:16:22 --> Utf8 Class Initialized
INFO - 2021-12-01 02:16:22 --> URI Class Initialized
INFO - 2021-12-01 02:16:22 --> Router Class Initialized
INFO - 2021-12-01 02:16:22 --> Output Class Initialized
INFO - 2021-12-01 02:16:22 --> Security Class Initialized
DEBUG - 2021-12-01 02:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:16:22 --> Input Class Initialized
INFO - 2021-12-01 02:16:22 --> Language Class Initialized
INFO - 2021-12-01 02:16:22 --> Language Class Initialized
INFO - 2021-12-01 02:16:22 --> Config Class Initialized
INFO - 2021-12-01 02:16:22 --> Loader Class Initialized
INFO - 2021-12-01 02:16:22 --> Helper loaded: url_helper
INFO - 2021-12-01 02:16:22 --> Helper loaded: file_helper
INFO - 2021-12-01 02:16:22 --> Helper loaded: form_helper
INFO - 2021-12-01 02:16:22 --> Helper loaded: my_helper
INFO - 2021-12-01 02:16:22 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:16:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:16:22 --> Controller Class Initialized
DEBUG - 2021-12-01 02:16:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 02:16:22 --> Final output sent to browser
DEBUG - 2021-12-01 02:16:22 --> Total execution time: 0.1513
INFO - 2021-12-01 02:17:27 --> Config Class Initialized
INFO - 2021-12-01 02:17:27 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:17:27 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:17:27 --> Utf8 Class Initialized
INFO - 2021-12-01 02:17:27 --> URI Class Initialized
INFO - 2021-12-01 02:17:27 --> Router Class Initialized
INFO - 2021-12-01 02:17:27 --> Output Class Initialized
INFO - 2021-12-01 02:17:27 --> Security Class Initialized
DEBUG - 2021-12-01 02:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:17:27 --> Input Class Initialized
INFO - 2021-12-01 02:17:27 --> Language Class Initialized
INFO - 2021-12-01 02:17:27 --> Language Class Initialized
INFO - 2021-12-01 02:17:27 --> Config Class Initialized
INFO - 2021-12-01 02:17:27 --> Loader Class Initialized
INFO - 2021-12-01 02:17:27 --> Helper loaded: url_helper
INFO - 2021-12-01 02:17:27 --> Helper loaded: file_helper
INFO - 2021-12-01 02:17:27 --> Helper loaded: form_helper
INFO - 2021-12-01 02:17:27 --> Helper loaded: my_helper
INFO - 2021-12-01 02:17:27 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:17:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:17:27 --> Controller Class Initialized
DEBUG - 2021-12-01 02:17:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-01 02:17:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 02:17:27 --> Final output sent to browser
DEBUG - 2021-12-01 02:17:27 --> Total execution time: 0.1828
INFO - 2021-12-01 02:18:02 --> Config Class Initialized
INFO - 2021-12-01 02:18:02 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:18:02 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:18:02 --> Utf8 Class Initialized
INFO - 2021-12-01 02:18:02 --> URI Class Initialized
INFO - 2021-12-01 02:18:02 --> Router Class Initialized
INFO - 2021-12-01 02:18:02 --> Output Class Initialized
INFO - 2021-12-01 02:18:02 --> Security Class Initialized
DEBUG - 2021-12-01 02:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:18:02 --> Input Class Initialized
INFO - 2021-12-01 02:18:02 --> Language Class Initialized
INFO - 2021-12-01 02:18:02 --> Language Class Initialized
INFO - 2021-12-01 02:18:02 --> Config Class Initialized
INFO - 2021-12-01 02:18:02 --> Loader Class Initialized
INFO - 2021-12-01 02:18:02 --> Helper loaded: url_helper
INFO - 2021-12-01 02:18:02 --> Helper loaded: file_helper
INFO - 2021-12-01 02:18:02 --> Helper loaded: form_helper
INFO - 2021-12-01 02:18:02 --> Helper loaded: my_helper
INFO - 2021-12-01 02:18:03 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:18:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:18:03 --> Controller Class Initialized
DEBUG - 2021-12-01 02:18:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-01 02:18:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 02:18:03 --> Final output sent to browser
DEBUG - 2021-12-01 02:18:03 --> Total execution time: 0.0684
INFO - 2021-12-01 02:18:05 --> Config Class Initialized
INFO - 2021-12-01 02:18:05 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:18:05 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:18:05 --> Utf8 Class Initialized
INFO - 2021-12-01 02:18:05 --> URI Class Initialized
INFO - 2021-12-01 02:18:05 --> Router Class Initialized
INFO - 2021-12-01 02:18:05 --> Output Class Initialized
INFO - 2021-12-01 02:18:05 --> Security Class Initialized
DEBUG - 2021-12-01 02:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:18:05 --> Input Class Initialized
INFO - 2021-12-01 02:18:05 --> Language Class Initialized
INFO - 2021-12-01 02:18:05 --> Language Class Initialized
INFO - 2021-12-01 02:18:05 --> Config Class Initialized
INFO - 2021-12-01 02:18:05 --> Loader Class Initialized
INFO - 2021-12-01 02:18:05 --> Helper loaded: url_helper
INFO - 2021-12-01 02:18:05 --> Helper loaded: file_helper
INFO - 2021-12-01 02:18:05 --> Helper loaded: form_helper
INFO - 2021-12-01 02:18:05 --> Helper loaded: my_helper
INFO - 2021-12-01 02:18:05 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:18:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:18:05 --> Controller Class Initialized
DEBUG - 2021-12-01 02:18:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 02:18:05 --> Final output sent to browser
DEBUG - 2021-12-01 02:18:05 --> Total execution time: 0.1280
INFO - 2021-12-01 02:20:15 --> Config Class Initialized
INFO - 2021-12-01 02:20:15 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:20:15 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:20:15 --> Utf8 Class Initialized
INFO - 2021-12-01 02:20:15 --> URI Class Initialized
INFO - 2021-12-01 02:20:15 --> Router Class Initialized
INFO - 2021-12-01 02:20:15 --> Output Class Initialized
INFO - 2021-12-01 02:20:15 --> Security Class Initialized
DEBUG - 2021-12-01 02:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:20:15 --> Input Class Initialized
INFO - 2021-12-01 02:20:15 --> Language Class Initialized
INFO - 2021-12-01 02:20:15 --> Language Class Initialized
INFO - 2021-12-01 02:20:15 --> Config Class Initialized
INFO - 2021-12-01 02:20:15 --> Loader Class Initialized
INFO - 2021-12-01 02:20:15 --> Helper loaded: url_helper
INFO - 2021-12-01 02:20:15 --> Helper loaded: file_helper
INFO - 2021-12-01 02:20:15 --> Helper loaded: form_helper
INFO - 2021-12-01 02:20:15 --> Helper loaded: my_helper
INFO - 2021-12-01 02:20:15 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:20:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:20:15 --> Controller Class Initialized
DEBUG - 2021-12-01 02:20:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-12-01 02:20:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 02:20:15 --> Final output sent to browser
DEBUG - 2021-12-01 02:20:15 --> Total execution time: 0.1237
INFO - 2021-12-01 02:20:17 --> Config Class Initialized
INFO - 2021-12-01 02:20:17 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:20:17 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:20:17 --> Utf8 Class Initialized
INFO - 2021-12-01 02:20:17 --> URI Class Initialized
INFO - 2021-12-01 02:20:17 --> Router Class Initialized
INFO - 2021-12-01 02:20:17 --> Output Class Initialized
INFO - 2021-12-01 02:20:17 --> Security Class Initialized
DEBUG - 2021-12-01 02:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:20:17 --> Input Class Initialized
INFO - 2021-12-01 02:20:17 --> Language Class Initialized
INFO - 2021-12-01 02:20:17 --> Language Class Initialized
INFO - 2021-12-01 02:20:17 --> Config Class Initialized
INFO - 2021-12-01 02:20:17 --> Loader Class Initialized
INFO - 2021-12-01 02:20:17 --> Helper loaded: url_helper
INFO - 2021-12-01 02:20:17 --> Helper loaded: file_helper
INFO - 2021-12-01 02:20:17 --> Helper loaded: form_helper
INFO - 2021-12-01 02:20:17 --> Helper loaded: my_helper
INFO - 2021-12-01 02:20:17 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:20:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:20:17 --> Controller Class Initialized
DEBUG - 2021-12-01 02:20:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-01 02:20:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 02:20:17 --> Final output sent to browser
DEBUG - 2021-12-01 02:20:17 --> Total execution time: 0.1132
INFO - 2021-12-01 02:20:30 --> Config Class Initialized
INFO - 2021-12-01 02:20:30 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:20:30 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:20:30 --> Utf8 Class Initialized
INFO - 2021-12-01 02:20:30 --> URI Class Initialized
INFO - 2021-12-01 02:20:30 --> Router Class Initialized
INFO - 2021-12-01 02:20:30 --> Output Class Initialized
INFO - 2021-12-01 02:20:30 --> Security Class Initialized
DEBUG - 2021-12-01 02:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:20:30 --> Input Class Initialized
INFO - 2021-12-01 02:20:30 --> Language Class Initialized
INFO - 2021-12-01 02:20:30 --> Language Class Initialized
INFO - 2021-12-01 02:20:30 --> Config Class Initialized
INFO - 2021-12-01 02:20:30 --> Loader Class Initialized
INFO - 2021-12-01 02:20:30 --> Helper loaded: url_helper
INFO - 2021-12-01 02:20:30 --> Helper loaded: file_helper
INFO - 2021-12-01 02:20:30 --> Helper loaded: form_helper
INFO - 2021-12-01 02:20:30 --> Helper loaded: my_helper
INFO - 2021-12-01 02:20:30 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:20:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:20:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:20:30 --> Controller Class Initialized
INFO - 2021-12-01 02:20:30 --> Final output sent to browser
DEBUG - 2021-12-01 02:20:30 --> Total execution time: 0.1676
INFO - 2021-12-01 02:20:33 --> Config Class Initialized
INFO - 2021-12-01 02:20:33 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:20:33 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:20:33 --> Utf8 Class Initialized
INFO - 2021-12-01 02:20:33 --> URI Class Initialized
INFO - 2021-12-01 02:20:33 --> Router Class Initialized
INFO - 2021-12-01 02:20:33 --> Output Class Initialized
INFO - 2021-12-01 02:20:33 --> Security Class Initialized
DEBUG - 2021-12-01 02:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:20:33 --> Input Class Initialized
INFO - 2021-12-01 02:20:33 --> Language Class Initialized
INFO - 2021-12-01 02:20:33 --> Language Class Initialized
INFO - 2021-12-01 02:20:33 --> Config Class Initialized
INFO - 2021-12-01 02:20:33 --> Loader Class Initialized
INFO - 2021-12-01 02:20:33 --> Helper loaded: url_helper
INFO - 2021-12-01 02:20:33 --> Helper loaded: file_helper
INFO - 2021-12-01 02:20:33 --> Helper loaded: form_helper
INFO - 2021-12-01 02:20:33 --> Helper loaded: my_helper
INFO - 2021-12-01 02:20:33 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:20:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:20:33 --> Controller Class Initialized
DEBUG - 2021-12-01 02:20:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 02:20:33 --> Final output sent to browser
DEBUG - 2021-12-01 02:20:33 --> Total execution time: 0.0682
INFO - 2021-12-01 02:21:01 --> Config Class Initialized
INFO - 2021-12-01 02:21:01 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:21:01 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:21:01 --> Utf8 Class Initialized
INFO - 2021-12-01 02:21:01 --> URI Class Initialized
INFO - 2021-12-01 02:21:01 --> Router Class Initialized
INFO - 2021-12-01 02:21:01 --> Output Class Initialized
INFO - 2021-12-01 02:21:01 --> Security Class Initialized
DEBUG - 2021-12-01 02:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:21:01 --> Input Class Initialized
INFO - 2021-12-01 02:21:01 --> Language Class Initialized
INFO - 2021-12-01 02:21:01 --> Language Class Initialized
INFO - 2021-12-01 02:21:01 --> Config Class Initialized
INFO - 2021-12-01 02:21:01 --> Loader Class Initialized
INFO - 2021-12-01 02:21:01 --> Helper loaded: url_helper
INFO - 2021-12-01 02:21:01 --> Helper loaded: file_helper
INFO - 2021-12-01 02:21:01 --> Helper loaded: form_helper
INFO - 2021-12-01 02:21:01 --> Helper loaded: my_helper
INFO - 2021-12-01 02:21:01 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:21:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:21:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:21:01 --> Controller Class Initialized
DEBUG - 2021-12-01 02:21:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-01 02:21:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 02:21:01 --> Final output sent to browser
DEBUG - 2021-12-01 02:21:01 --> Total execution time: 0.0928
INFO - 2021-12-01 02:21:59 --> Config Class Initialized
INFO - 2021-12-01 02:21:59 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:21:59 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:21:59 --> Utf8 Class Initialized
INFO - 2021-12-01 02:21:59 --> URI Class Initialized
INFO - 2021-12-01 02:21:59 --> Router Class Initialized
INFO - 2021-12-01 02:21:59 --> Output Class Initialized
INFO - 2021-12-01 02:21:59 --> Security Class Initialized
DEBUG - 2021-12-01 02:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:21:59 --> Input Class Initialized
INFO - 2021-12-01 02:21:59 --> Language Class Initialized
INFO - 2021-12-01 02:21:59 --> Language Class Initialized
INFO - 2021-12-01 02:21:59 --> Config Class Initialized
INFO - 2021-12-01 02:21:59 --> Loader Class Initialized
INFO - 2021-12-01 02:21:59 --> Helper loaded: url_helper
INFO - 2021-12-01 02:21:59 --> Helper loaded: file_helper
INFO - 2021-12-01 02:21:59 --> Helper loaded: form_helper
INFO - 2021-12-01 02:21:59 --> Helper loaded: my_helper
INFO - 2021-12-01 02:21:59 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:21:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:21:59 --> Controller Class Initialized
DEBUG - 2021-12-01 02:21:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 02:21:59 --> Final output sent to browser
DEBUG - 2021-12-01 02:21:59 --> Total execution time: 0.1340
INFO - 2021-12-01 02:22:02 --> Config Class Initialized
INFO - 2021-12-01 02:22:02 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:22:02 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:22:02 --> Utf8 Class Initialized
INFO - 2021-12-01 02:22:02 --> URI Class Initialized
INFO - 2021-12-01 02:22:02 --> Router Class Initialized
INFO - 2021-12-01 02:22:02 --> Output Class Initialized
INFO - 2021-12-01 02:22:02 --> Security Class Initialized
DEBUG - 2021-12-01 02:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:22:02 --> Input Class Initialized
INFO - 2021-12-01 02:22:02 --> Language Class Initialized
INFO - 2021-12-01 02:22:02 --> Language Class Initialized
INFO - 2021-12-01 02:22:02 --> Config Class Initialized
INFO - 2021-12-01 02:22:02 --> Loader Class Initialized
INFO - 2021-12-01 02:22:02 --> Helper loaded: url_helper
INFO - 2021-12-01 02:22:02 --> Helper loaded: file_helper
INFO - 2021-12-01 02:22:02 --> Helper loaded: form_helper
INFO - 2021-12-01 02:22:02 --> Helper loaded: my_helper
INFO - 2021-12-01 02:22:02 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:22:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:22:02 --> Controller Class Initialized
DEBUG - 2021-12-01 02:22:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 02:22:02 --> Final output sent to browser
DEBUG - 2021-12-01 02:22:02 --> Total execution time: 0.1195
INFO - 2021-12-01 02:22:05 --> Config Class Initialized
INFO - 2021-12-01 02:22:05 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:22:05 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:22:05 --> Utf8 Class Initialized
INFO - 2021-12-01 02:22:05 --> URI Class Initialized
INFO - 2021-12-01 02:22:05 --> Router Class Initialized
INFO - 2021-12-01 02:22:05 --> Output Class Initialized
INFO - 2021-12-01 02:22:05 --> Security Class Initialized
DEBUG - 2021-12-01 02:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:22:05 --> Input Class Initialized
INFO - 2021-12-01 02:22:05 --> Language Class Initialized
INFO - 2021-12-01 02:22:05 --> Language Class Initialized
INFO - 2021-12-01 02:22:05 --> Config Class Initialized
INFO - 2021-12-01 02:22:05 --> Loader Class Initialized
INFO - 2021-12-01 02:22:05 --> Helper loaded: url_helper
INFO - 2021-12-01 02:22:05 --> Helper loaded: file_helper
INFO - 2021-12-01 02:22:05 --> Helper loaded: form_helper
INFO - 2021-12-01 02:22:05 --> Helper loaded: my_helper
INFO - 2021-12-01 02:22:05 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:22:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:22:05 --> Controller Class Initialized
DEBUG - 2021-12-01 02:22:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 02:22:05 --> Final output sent to browser
DEBUG - 2021-12-01 02:22:05 --> Total execution time: 0.1515
INFO - 2021-12-01 02:22:07 --> Config Class Initialized
INFO - 2021-12-01 02:22:07 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:22:07 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:22:07 --> Utf8 Class Initialized
INFO - 2021-12-01 02:22:07 --> URI Class Initialized
INFO - 2021-12-01 02:22:07 --> Router Class Initialized
INFO - 2021-12-01 02:22:07 --> Output Class Initialized
INFO - 2021-12-01 02:22:07 --> Security Class Initialized
DEBUG - 2021-12-01 02:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:22:07 --> Input Class Initialized
INFO - 2021-12-01 02:22:07 --> Language Class Initialized
INFO - 2021-12-01 02:22:07 --> Language Class Initialized
INFO - 2021-12-01 02:22:07 --> Config Class Initialized
INFO - 2021-12-01 02:22:07 --> Loader Class Initialized
INFO - 2021-12-01 02:22:07 --> Helper loaded: url_helper
INFO - 2021-12-01 02:22:07 --> Helper loaded: file_helper
INFO - 2021-12-01 02:22:07 --> Helper loaded: form_helper
INFO - 2021-12-01 02:22:07 --> Helper loaded: my_helper
INFO - 2021-12-01 02:22:07 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:22:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:22:07 --> Controller Class Initialized
DEBUG - 2021-12-01 02:22:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 02:22:07 --> Final output sent to browser
DEBUG - 2021-12-01 02:22:07 --> Total execution time: 0.1233
INFO - 2021-12-01 02:22:09 --> Config Class Initialized
INFO - 2021-12-01 02:22:09 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:22:09 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:22:09 --> Utf8 Class Initialized
INFO - 2021-12-01 02:22:09 --> URI Class Initialized
INFO - 2021-12-01 02:22:09 --> Router Class Initialized
INFO - 2021-12-01 02:22:09 --> Output Class Initialized
INFO - 2021-12-01 02:22:09 --> Security Class Initialized
DEBUG - 2021-12-01 02:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:22:09 --> Input Class Initialized
INFO - 2021-12-01 02:22:09 --> Language Class Initialized
INFO - 2021-12-01 02:22:09 --> Language Class Initialized
INFO - 2021-12-01 02:22:09 --> Config Class Initialized
INFO - 2021-12-01 02:22:09 --> Loader Class Initialized
INFO - 2021-12-01 02:22:09 --> Helper loaded: url_helper
INFO - 2021-12-01 02:22:09 --> Helper loaded: file_helper
INFO - 2021-12-01 02:22:09 --> Helper loaded: form_helper
INFO - 2021-12-01 02:22:09 --> Helper loaded: my_helper
INFO - 2021-12-01 02:22:09 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:22:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:22:09 --> Controller Class Initialized
DEBUG - 2021-12-01 02:22:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 02:22:09 --> Final output sent to browser
DEBUG - 2021-12-01 02:22:09 --> Total execution time: 0.1139
INFO - 2021-12-01 02:22:10 --> Config Class Initialized
INFO - 2021-12-01 02:22:10 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:22:10 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:22:10 --> Utf8 Class Initialized
INFO - 2021-12-01 02:22:10 --> URI Class Initialized
INFO - 2021-12-01 02:22:10 --> Router Class Initialized
INFO - 2021-12-01 02:22:10 --> Output Class Initialized
INFO - 2021-12-01 02:22:10 --> Security Class Initialized
DEBUG - 2021-12-01 02:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:22:10 --> Input Class Initialized
INFO - 2021-12-01 02:22:10 --> Language Class Initialized
INFO - 2021-12-01 02:22:10 --> Language Class Initialized
INFO - 2021-12-01 02:22:10 --> Config Class Initialized
INFO - 2021-12-01 02:22:10 --> Loader Class Initialized
INFO - 2021-12-01 02:22:10 --> Helper loaded: url_helper
INFO - 2021-12-01 02:22:10 --> Helper loaded: file_helper
INFO - 2021-12-01 02:22:10 --> Helper loaded: form_helper
INFO - 2021-12-01 02:22:10 --> Helper loaded: my_helper
INFO - 2021-12-01 02:22:10 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:22:10 --> Controller Class Initialized
DEBUG - 2021-12-01 02:22:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 02:22:10 --> Final output sent to browser
DEBUG - 2021-12-01 02:22:10 --> Total execution time: 0.1325
INFO - 2021-12-01 02:22:12 --> Config Class Initialized
INFO - 2021-12-01 02:22:12 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:22:12 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:22:12 --> Utf8 Class Initialized
INFO - 2021-12-01 02:22:12 --> URI Class Initialized
INFO - 2021-12-01 02:22:12 --> Router Class Initialized
INFO - 2021-12-01 02:22:12 --> Output Class Initialized
INFO - 2021-12-01 02:22:12 --> Security Class Initialized
DEBUG - 2021-12-01 02:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:22:12 --> Input Class Initialized
INFO - 2021-12-01 02:22:12 --> Language Class Initialized
INFO - 2021-12-01 02:22:12 --> Language Class Initialized
INFO - 2021-12-01 02:22:12 --> Config Class Initialized
INFO - 2021-12-01 02:22:12 --> Loader Class Initialized
INFO - 2021-12-01 02:22:12 --> Helper loaded: url_helper
INFO - 2021-12-01 02:22:12 --> Helper loaded: file_helper
INFO - 2021-12-01 02:22:12 --> Helper loaded: form_helper
INFO - 2021-12-01 02:22:12 --> Helper loaded: my_helper
INFO - 2021-12-01 02:22:12 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:22:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:22:12 --> Controller Class Initialized
DEBUG - 2021-12-01 02:22:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 02:22:12 --> Final output sent to browser
DEBUG - 2021-12-01 02:22:12 --> Total execution time: 0.1196
INFO - 2021-12-01 02:22:14 --> Config Class Initialized
INFO - 2021-12-01 02:22:14 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:22:14 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:22:14 --> Utf8 Class Initialized
INFO - 2021-12-01 02:22:14 --> URI Class Initialized
INFO - 2021-12-01 02:22:14 --> Router Class Initialized
INFO - 2021-12-01 02:22:14 --> Output Class Initialized
INFO - 2021-12-01 02:22:14 --> Security Class Initialized
DEBUG - 2021-12-01 02:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:22:14 --> Input Class Initialized
INFO - 2021-12-01 02:22:14 --> Language Class Initialized
INFO - 2021-12-01 02:22:14 --> Language Class Initialized
INFO - 2021-12-01 02:22:14 --> Config Class Initialized
INFO - 2021-12-01 02:22:14 --> Loader Class Initialized
INFO - 2021-12-01 02:22:14 --> Helper loaded: url_helper
INFO - 2021-12-01 02:22:14 --> Helper loaded: file_helper
INFO - 2021-12-01 02:22:14 --> Helper loaded: form_helper
INFO - 2021-12-01 02:22:14 --> Helper loaded: my_helper
INFO - 2021-12-01 02:22:14 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:22:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:22:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:22:14 --> Controller Class Initialized
DEBUG - 2021-12-01 02:22:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 02:22:14 --> Final output sent to browser
DEBUG - 2021-12-01 02:22:14 --> Total execution time: 0.1140
INFO - 2021-12-01 02:22:16 --> Config Class Initialized
INFO - 2021-12-01 02:22:16 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:22:16 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:22:16 --> Utf8 Class Initialized
INFO - 2021-12-01 02:22:16 --> URI Class Initialized
INFO - 2021-12-01 02:22:16 --> Router Class Initialized
INFO - 2021-12-01 02:22:16 --> Output Class Initialized
INFO - 2021-12-01 02:22:16 --> Security Class Initialized
DEBUG - 2021-12-01 02:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:22:16 --> Input Class Initialized
INFO - 2021-12-01 02:22:16 --> Language Class Initialized
INFO - 2021-12-01 02:22:16 --> Language Class Initialized
INFO - 2021-12-01 02:22:16 --> Config Class Initialized
INFO - 2021-12-01 02:22:16 --> Loader Class Initialized
INFO - 2021-12-01 02:22:16 --> Helper loaded: url_helper
INFO - 2021-12-01 02:22:16 --> Helper loaded: file_helper
INFO - 2021-12-01 02:22:16 --> Helper loaded: form_helper
INFO - 2021-12-01 02:22:16 --> Helper loaded: my_helper
INFO - 2021-12-01 02:22:16 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:22:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:22:16 --> Controller Class Initialized
DEBUG - 2021-12-01 02:22:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 02:22:16 --> Final output sent to browser
DEBUG - 2021-12-01 02:22:16 --> Total execution time: 0.1363
INFO - 2021-12-01 02:22:19 --> Config Class Initialized
INFO - 2021-12-01 02:22:19 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:22:19 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:22:19 --> Utf8 Class Initialized
INFO - 2021-12-01 02:22:19 --> URI Class Initialized
INFO - 2021-12-01 02:22:19 --> Router Class Initialized
INFO - 2021-12-01 02:22:19 --> Output Class Initialized
INFO - 2021-12-01 02:22:19 --> Security Class Initialized
DEBUG - 2021-12-01 02:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:22:19 --> Input Class Initialized
INFO - 2021-12-01 02:22:19 --> Language Class Initialized
INFO - 2021-12-01 02:22:19 --> Language Class Initialized
INFO - 2021-12-01 02:22:19 --> Config Class Initialized
INFO - 2021-12-01 02:22:19 --> Loader Class Initialized
INFO - 2021-12-01 02:22:19 --> Helper loaded: url_helper
INFO - 2021-12-01 02:22:19 --> Helper loaded: file_helper
INFO - 2021-12-01 02:22:19 --> Helper loaded: form_helper
INFO - 2021-12-01 02:22:19 --> Helper loaded: my_helper
INFO - 2021-12-01 02:22:19 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:22:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:22:19 --> Controller Class Initialized
DEBUG - 2021-12-01 02:22:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 02:22:19 --> Final output sent to browser
DEBUG - 2021-12-01 02:22:19 --> Total execution time: 0.1124
INFO - 2021-12-01 02:22:20 --> Config Class Initialized
INFO - 2021-12-01 02:22:20 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:22:20 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:22:20 --> Utf8 Class Initialized
INFO - 2021-12-01 02:22:20 --> URI Class Initialized
INFO - 2021-12-01 02:22:20 --> Router Class Initialized
INFO - 2021-12-01 02:22:20 --> Output Class Initialized
INFO - 2021-12-01 02:22:20 --> Security Class Initialized
DEBUG - 2021-12-01 02:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:22:20 --> Input Class Initialized
INFO - 2021-12-01 02:22:20 --> Language Class Initialized
INFO - 2021-12-01 02:22:20 --> Language Class Initialized
INFO - 2021-12-01 02:22:20 --> Config Class Initialized
INFO - 2021-12-01 02:22:20 --> Loader Class Initialized
INFO - 2021-12-01 02:22:20 --> Helper loaded: url_helper
INFO - 2021-12-01 02:22:20 --> Helper loaded: file_helper
INFO - 2021-12-01 02:22:20 --> Helper loaded: form_helper
INFO - 2021-12-01 02:22:20 --> Helper loaded: my_helper
INFO - 2021-12-01 02:22:20 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:22:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:22:20 --> Controller Class Initialized
DEBUG - 2021-12-01 02:22:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 02:22:20 --> Final output sent to browser
DEBUG - 2021-12-01 02:22:20 --> Total execution time: 0.1443
INFO - 2021-12-01 02:22:22 --> Config Class Initialized
INFO - 2021-12-01 02:22:22 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:22:22 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:22:22 --> Utf8 Class Initialized
INFO - 2021-12-01 02:22:22 --> URI Class Initialized
INFO - 2021-12-01 02:22:22 --> Router Class Initialized
INFO - 2021-12-01 02:22:22 --> Output Class Initialized
INFO - 2021-12-01 02:22:22 --> Security Class Initialized
DEBUG - 2021-12-01 02:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:22:22 --> Input Class Initialized
INFO - 2021-12-01 02:22:22 --> Language Class Initialized
INFO - 2021-12-01 02:22:22 --> Language Class Initialized
INFO - 2021-12-01 02:22:22 --> Config Class Initialized
INFO - 2021-12-01 02:22:22 --> Loader Class Initialized
INFO - 2021-12-01 02:22:22 --> Helper loaded: url_helper
INFO - 2021-12-01 02:22:22 --> Helper loaded: file_helper
INFO - 2021-12-01 02:22:22 --> Helper loaded: form_helper
INFO - 2021-12-01 02:22:22 --> Helper loaded: my_helper
INFO - 2021-12-01 02:22:22 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:22:22 --> Controller Class Initialized
DEBUG - 2021-12-01 02:22:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 02:22:22 --> Final output sent to browser
DEBUG - 2021-12-01 02:22:22 --> Total execution time: 0.1179
INFO - 2021-12-01 02:22:24 --> Config Class Initialized
INFO - 2021-12-01 02:22:24 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:22:24 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:22:24 --> Utf8 Class Initialized
INFO - 2021-12-01 02:22:24 --> URI Class Initialized
INFO - 2021-12-01 02:22:24 --> Router Class Initialized
INFO - 2021-12-01 02:22:24 --> Output Class Initialized
INFO - 2021-12-01 02:22:24 --> Security Class Initialized
DEBUG - 2021-12-01 02:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:22:24 --> Input Class Initialized
INFO - 2021-12-01 02:22:24 --> Language Class Initialized
INFO - 2021-12-01 02:22:24 --> Language Class Initialized
INFO - 2021-12-01 02:22:24 --> Config Class Initialized
INFO - 2021-12-01 02:22:24 --> Loader Class Initialized
INFO - 2021-12-01 02:22:24 --> Helper loaded: url_helper
INFO - 2021-12-01 02:22:24 --> Helper loaded: file_helper
INFO - 2021-12-01 02:22:24 --> Helper loaded: form_helper
INFO - 2021-12-01 02:22:24 --> Helper loaded: my_helper
INFO - 2021-12-01 02:22:24 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:22:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:22:24 --> Controller Class Initialized
DEBUG - 2021-12-01 02:22:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 02:22:24 --> Final output sent to browser
DEBUG - 2021-12-01 02:22:24 --> Total execution time: 0.1412
INFO - 2021-12-01 02:22:26 --> Config Class Initialized
INFO - 2021-12-01 02:22:26 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:22:26 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:22:26 --> Utf8 Class Initialized
INFO - 2021-12-01 02:22:26 --> URI Class Initialized
INFO - 2021-12-01 02:22:26 --> Router Class Initialized
INFO - 2021-12-01 02:22:26 --> Output Class Initialized
INFO - 2021-12-01 02:22:26 --> Security Class Initialized
DEBUG - 2021-12-01 02:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:22:26 --> Input Class Initialized
INFO - 2021-12-01 02:22:26 --> Language Class Initialized
INFO - 2021-12-01 02:22:27 --> Language Class Initialized
INFO - 2021-12-01 02:22:27 --> Config Class Initialized
INFO - 2021-12-01 02:22:27 --> Loader Class Initialized
INFO - 2021-12-01 02:22:27 --> Helper loaded: url_helper
INFO - 2021-12-01 02:22:27 --> Helper loaded: file_helper
INFO - 2021-12-01 02:22:27 --> Helper loaded: form_helper
INFO - 2021-12-01 02:22:27 --> Helper loaded: my_helper
INFO - 2021-12-01 02:22:27 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:22:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:22:27 --> Controller Class Initialized
DEBUG - 2021-12-01 02:22:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 02:22:27 --> Final output sent to browser
DEBUG - 2021-12-01 02:22:27 --> Total execution time: 0.1361
INFO - 2021-12-01 02:22:28 --> Config Class Initialized
INFO - 2021-12-01 02:22:28 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:22:28 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:22:28 --> Utf8 Class Initialized
INFO - 2021-12-01 02:22:28 --> URI Class Initialized
INFO - 2021-12-01 02:22:28 --> Router Class Initialized
INFO - 2021-12-01 02:22:28 --> Output Class Initialized
INFO - 2021-12-01 02:22:28 --> Security Class Initialized
DEBUG - 2021-12-01 02:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:22:28 --> Input Class Initialized
INFO - 2021-12-01 02:22:28 --> Language Class Initialized
INFO - 2021-12-01 02:22:28 --> Language Class Initialized
INFO - 2021-12-01 02:22:28 --> Config Class Initialized
INFO - 2021-12-01 02:22:28 --> Loader Class Initialized
INFO - 2021-12-01 02:22:28 --> Helper loaded: url_helper
INFO - 2021-12-01 02:22:28 --> Helper loaded: file_helper
INFO - 2021-12-01 02:22:28 --> Helper loaded: form_helper
INFO - 2021-12-01 02:22:28 --> Helper loaded: my_helper
INFO - 2021-12-01 02:22:28 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:22:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:22:28 --> Controller Class Initialized
DEBUG - 2021-12-01 02:22:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 02:22:28 --> Final output sent to browser
DEBUG - 2021-12-01 02:22:28 --> Total execution time: 0.1343
INFO - 2021-12-01 02:22:30 --> Config Class Initialized
INFO - 2021-12-01 02:22:30 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:22:30 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:22:30 --> Utf8 Class Initialized
INFO - 2021-12-01 02:22:30 --> URI Class Initialized
INFO - 2021-12-01 02:22:30 --> Router Class Initialized
INFO - 2021-12-01 02:22:30 --> Output Class Initialized
INFO - 2021-12-01 02:22:30 --> Security Class Initialized
DEBUG - 2021-12-01 02:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:22:30 --> Input Class Initialized
INFO - 2021-12-01 02:22:30 --> Language Class Initialized
INFO - 2021-12-01 02:22:30 --> Language Class Initialized
INFO - 2021-12-01 02:22:30 --> Config Class Initialized
INFO - 2021-12-01 02:22:30 --> Loader Class Initialized
INFO - 2021-12-01 02:22:30 --> Helper loaded: url_helper
INFO - 2021-12-01 02:22:30 --> Helper loaded: file_helper
INFO - 2021-12-01 02:22:30 --> Helper loaded: form_helper
INFO - 2021-12-01 02:22:30 --> Helper loaded: my_helper
INFO - 2021-12-01 02:22:30 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:22:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:22:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:22:30 --> Controller Class Initialized
DEBUG - 2021-12-01 02:22:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 02:22:30 --> Final output sent to browser
DEBUG - 2021-12-01 02:22:30 --> Total execution time: 0.1112
INFO - 2021-12-01 02:22:32 --> Config Class Initialized
INFO - 2021-12-01 02:22:32 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:22:32 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:22:32 --> Utf8 Class Initialized
INFO - 2021-12-01 02:22:32 --> URI Class Initialized
INFO - 2021-12-01 02:22:32 --> Router Class Initialized
INFO - 2021-12-01 02:22:32 --> Output Class Initialized
INFO - 2021-12-01 02:22:32 --> Security Class Initialized
DEBUG - 2021-12-01 02:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:22:32 --> Input Class Initialized
INFO - 2021-12-01 02:22:32 --> Language Class Initialized
INFO - 2021-12-01 02:22:32 --> Language Class Initialized
INFO - 2021-12-01 02:22:32 --> Config Class Initialized
INFO - 2021-12-01 02:22:32 --> Loader Class Initialized
INFO - 2021-12-01 02:22:32 --> Helper loaded: url_helper
INFO - 2021-12-01 02:22:32 --> Helper loaded: file_helper
INFO - 2021-12-01 02:22:32 --> Helper loaded: form_helper
INFO - 2021-12-01 02:22:32 --> Helper loaded: my_helper
INFO - 2021-12-01 02:22:32 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:22:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:22:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:22:32 --> Controller Class Initialized
DEBUG - 2021-12-01 02:22:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 02:22:32 --> Final output sent to browser
DEBUG - 2021-12-01 02:22:32 --> Total execution time: 0.1502
INFO - 2021-12-01 02:22:34 --> Config Class Initialized
INFO - 2021-12-01 02:22:34 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:22:34 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:22:34 --> Utf8 Class Initialized
INFO - 2021-12-01 02:22:34 --> URI Class Initialized
INFO - 2021-12-01 02:22:34 --> Router Class Initialized
INFO - 2021-12-01 02:22:34 --> Output Class Initialized
INFO - 2021-12-01 02:22:34 --> Security Class Initialized
DEBUG - 2021-12-01 02:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:22:34 --> Input Class Initialized
INFO - 2021-12-01 02:22:34 --> Language Class Initialized
INFO - 2021-12-01 02:22:34 --> Language Class Initialized
INFO - 2021-12-01 02:22:34 --> Config Class Initialized
INFO - 2021-12-01 02:22:34 --> Loader Class Initialized
INFO - 2021-12-01 02:22:34 --> Helper loaded: url_helper
INFO - 2021-12-01 02:22:34 --> Helper loaded: file_helper
INFO - 2021-12-01 02:22:34 --> Helper loaded: form_helper
INFO - 2021-12-01 02:22:34 --> Helper loaded: my_helper
INFO - 2021-12-01 02:22:34 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:22:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:22:34 --> Controller Class Initialized
DEBUG - 2021-12-01 02:22:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 02:22:34 --> Final output sent to browser
DEBUG - 2021-12-01 02:22:34 --> Total execution time: 0.1195
INFO - 2021-12-01 02:22:36 --> Config Class Initialized
INFO - 2021-12-01 02:22:36 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:22:36 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:22:36 --> Utf8 Class Initialized
INFO - 2021-12-01 02:22:36 --> URI Class Initialized
INFO - 2021-12-01 02:22:36 --> Router Class Initialized
INFO - 2021-12-01 02:22:36 --> Output Class Initialized
INFO - 2021-12-01 02:22:36 --> Security Class Initialized
DEBUG - 2021-12-01 02:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:22:36 --> Input Class Initialized
INFO - 2021-12-01 02:22:36 --> Language Class Initialized
INFO - 2021-12-01 02:22:36 --> Language Class Initialized
INFO - 2021-12-01 02:22:36 --> Config Class Initialized
INFO - 2021-12-01 02:22:36 --> Loader Class Initialized
INFO - 2021-12-01 02:22:36 --> Helper loaded: url_helper
INFO - 2021-12-01 02:22:36 --> Helper loaded: file_helper
INFO - 2021-12-01 02:22:36 --> Helper loaded: form_helper
INFO - 2021-12-01 02:22:36 --> Helper loaded: my_helper
INFO - 2021-12-01 02:22:36 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:22:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:22:36 --> Controller Class Initialized
DEBUG - 2021-12-01 02:22:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 02:22:36 --> Final output sent to browser
DEBUG - 2021-12-01 02:22:36 --> Total execution time: 0.1363
INFO - 2021-12-01 02:22:38 --> Config Class Initialized
INFO - 2021-12-01 02:22:38 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:22:38 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:22:38 --> Utf8 Class Initialized
INFO - 2021-12-01 02:22:38 --> URI Class Initialized
INFO - 2021-12-01 02:22:38 --> Router Class Initialized
INFO - 2021-12-01 02:22:38 --> Output Class Initialized
INFO - 2021-12-01 02:22:38 --> Security Class Initialized
DEBUG - 2021-12-01 02:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:22:38 --> Input Class Initialized
INFO - 2021-12-01 02:22:38 --> Language Class Initialized
INFO - 2021-12-01 02:22:38 --> Language Class Initialized
INFO - 2021-12-01 02:22:38 --> Config Class Initialized
INFO - 2021-12-01 02:22:38 --> Loader Class Initialized
INFO - 2021-12-01 02:22:38 --> Helper loaded: url_helper
INFO - 2021-12-01 02:22:38 --> Helper loaded: file_helper
INFO - 2021-12-01 02:22:38 --> Helper loaded: form_helper
INFO - 2021-12-01 02:22:38 --> Helper loaded: my_helper
INFO - 2021-12-01 02:22:38 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:22:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:22:38 --> Controller Class Initialized
DEBUG - 2021-12-01 02:22:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 02:22:38 --> Final output sent to browser
DEBUG - 2021-12-01 02:22:38 --> Total execution time: 0.1416
INFO - 2021-12-01 02:22:40 --> Config Class Initialized
INFO - 2021-12-01 02:22:40 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:22:40 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:22:40 --> Utf8 Class Initialized
INFO - 2021-12-01 02:22:40 --> URI Class Initialized
INFO - 2021-12-01 02:22:40 --> Router Class Initialized
INFO - 2021-12-01 02:22:40 --> Output Class Initialized
INFO - 2021-12-01 02:22:40 --> Security Class Initialized
DEBUG - 2021-12-01 02:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:22:40 --> Input Class Initialized
INFO - 2021-12-01 02:22:40 --> Language Class Initialized
INFO - 2021-12-01 02:22:40 --> Language Class Initialized
INFO - 2021-12-01 02:22:40 --> Config Class Initialized
INFO - 2021-12-01 02:22:40 --> Loader Class Initialized
INFO - 2021-12-01 02:22:40 --> Helper loaded: url_helper
INFO - 2021-12-01 02:22:40 --> Helper loaded: file_helper
INFO - 2021-12-01 02:22:40 --> Helper loaded: form_helper
INFO - 2021-12-01 02:22:40 --> Helper loaded: my_helper
INFO - 2021-12-01 02:22:40 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:22:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:22:40 --> Controller Class Initialized
DEBUG - 2021-12-01 02:22:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 02:22:40 --> Final output sent to browser
DEBUG - 2021-12-01 02:22:40 --> Total execution time: 0.1387
INFO - 2021-12-01 02:22:42 --> Config Class Initialized
INFO - 2021-12-01 02:22:42 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:22:42 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:22:42 --> Utf8 Class Initialized
INFO - 2021-12-01 02:22:42 --> URI Class Initialized
INFO - 2021-12-01 02:22:42 --> Router Class Initialized
INFO - 2021-12-01 02:22:42 --> Output Class Initialized
INFO - 2021-12-01 02:22:42 --> Security Class Initialized
DEBUG - 2021-12-01 02:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:22:42 --> Input Class Initialized
INFO - 2021-12-01 02:22:42 --> Language Class Initialized
INFO - 2021-12-01 02:22:42 --> Language Class Initialized
INFO - 2021-12-01 02:22:42 --> Config Class Initialized
INFO - 2021-12-01 02:22:42 --> Loader Class Initialized
INFO - 2021-12-01 02:22:42 --> Helper loaded: url_helper
INFO - 2021-12-01 02:22:42 --> Helper loaded: file_helper
INFO - 2021-12-01 02:22:42 --> Helper loaded: form_helper
INFO - 2021-12-01 02:22:42 --> Helper loaded: my_helper
INFO - 2021-12-01 02:22:42 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:22:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:22:42 --> Controller Class Initialized
DEBUG - 2021-12-01 02:22:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 02:22:42 --> Final output sent to browser
DEBUG - 2021-12-01 02:22:42 --> Total execution time: 0.1361
INFO - 2021-12-01 02:22:44 --> Config Class Initialized
INFO - 2021-12-01 02:22:44 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:22:44 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:22:44 --> Utf8 Class Initialized
INFO - 2021-12-01 02:22:44 --> URI Class Initialized
INFO - 2021-12-01 02:22:44 --> Router Class Initialized
INFO - 2021-12-01 02:22:44 --> Output Class Initialized
INFO - 2021-12-01 02:22:44 --> Security Class Initialized
DEBUG - 2021-12-01 02:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:22:44 --> Input Class Initialized
INFO - 2021-12-01 02:22:44 --> Language Class Initialized
INFO - 2021-12-01 02:22:44 --> Language Class Initialized
INFO - 2021-12-01 02:22:44 --> Config Class Initialized
INFO - 2021-12-01 02:22:44 --> Loader Class Initialized
INFO - 2021-12-01 02:22:44 --> Helper loaded: url_helper
INFO - 2021-12-01 02:22:44 --> Helper loaded: file_helper
INFO - 2021-12-01 02:22:44 --> Helper loaded: form_helper
INFO - 2021-12-01 02:22:44 --> Helper loaded: my_helper
INFO - 2021-12-01 02:22:44 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:22:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:22:44 --> Controller Class Initialized
DEBUG - 2021-12-01 02:22:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 02:22:44 --> Final output sent to browser
DEBUG - 2021-12-01 02:22:44 --> Total execution time: 0.1495
INFO - 2021-12-01 02:27:12 --> Config Class Initialized
INFO - 2021-12-01 02:27:12 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:27:12 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:27:12 --> Utf8 Class Initialized
INFO - 2021-12-01 02:27:12 --> URI Class Initialized
INFO - 2021-12-01 02:27:12 --> Router Class Initialized
INFO - 2021-12-01 02:27:12 --> Output Class Initialized
INFO - 2021-12-01 02:27:12 --> Security Class Initialized
DEBUG - 2021-12-01 02:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:27:12 --> Input Class Initialized
INFO - 2021-12-01 02:27:12 --> Language Class Initialized
INFO - 2021-12-01 02:27:12 --> Language Class Initialized
INFO - 2021-12-01 02:27:12 --> Config Class Initialized
INFO - 2021-12-01 02:27:12 --> Loader Class Initialized
INFO - 2021-12-01 02:27:12 --> Helper loaded: url_helper
INFO - 2021-12-01 02:27:12 --> Helper loaded: file_helper
INFO - 2021-12-01 02:27:12 --> Helper loaded: form_helper
INFO - 2021-12-01 02:27:12 --> Helper loaded: my_helper
INFO - 2021-12-01 02:27:12 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:27:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:27:12 --> Controller Class Initialized
DEBUG - 2021-12-01 02:27:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-01 02:27:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 02:27:12 --> Final output sent to browser
DEBUG - 2021-12-01 02:27:12 --> Total execution time: 0.1400
INFO - 2021-12-01 02:28:24 --> Config Class Initialized
INFO - 2021-12-01 02:28:24 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:28:24 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:28:24 --> Utf8 Class Initialized
INFO - 2021-12-01 02:28:24 --> URI Class Initialized
INFO - 2021-12-01 02:28:24 --> Router Class Initialized
INFO - 2021-12-01 02:28:24 --> Output Class Initialized
INFO - 2021-12-01 02:28:24 --> Security Class Initialized
DEBUG - 2021-12-01 02:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:28:24 --> Input Class Initialized
INFO - 2021-12-01 02:28:24 --> Language Class Initialized
INFO - 2021-12-01 02:28:24 --> Language Class Initialized
INFO - 2021-12-01 02:28:24 --> Config Class Initialized
INFO - 2021-12-01 02:28:24 --> Loader Class Initialized
INFO - 2021-12-01 02:28:24 --> Helper loaded: url_helper
INFO - 2021-12-01 02:28:24 --> Helper loaded: file_helper
INFO - 2021-12-01 02:28:24 --> Helper loaded: form_helper
INFO - 2021-12-01 02:28:24 --> Helper loaded: my_helper
INFO - 2021-12-01 02:28:24 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:28:24 --> Controller Class Initialized
INFO - 2021-12-01 02:28:24 --> Final output sent to browser
DEBUG - 2021-12-01 02:28:24 --> Total execution time: 0.1843
INFO - 2021-12-01 02:28:31 --> Config Class Initialized
INFO - 2021-12-01 02:28:31 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:28:31 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:28:31 --> Utf8 Class Initialized
INFO - 2021-12-01 02:28:31 --> URI Class Initialized
INFO - 2021-12-01 02:28:31 --> Router Class Initialized
INFO - 2021-12-01 02:28:31 --> Output Class Initialized
INFO - 2021-12-01 02:28:31 --> Security Class Initialized
DEBUG - 2021-12-01 02:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:28:31 --> Input Class Initialized
INFO - 2021-12-01 02:28:31 --> Language Class Initialized
INFO - 2021-12-01 02:28:31 --> Language Class Initialized
INFO - 2021-12-01 02:28:31 --> Config Class Initialized
INFO - 2021-12-01 02:28:31 --> Loader Class Initialized
INFO - 2021-12-01 02:28:31 --> Helper loaded: url_helper
INFO - 2021-12-01 02:28:31 --> Helper loaded: file_helper
INFO - 2021-12-01 02:28:31 --> Helper loaded: form_helper
INFO - 2021-12-01 02:28:31 --> Helper loaded: my_helper
INFO - 2021-12-01 02:28:31 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:28:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:28:31 --> Controller Class Initialized
DEBUG - 2021-12-01 02:28:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-01 02:28:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 02:28:31 --> Final output sent to browser
DEBUG - 2021-12-01 02:28:31 --> Total execution time: 0.1019
INFO - 2021-12-01 02:28:34 --> Config Class Initialized
INFO - 2021-12-01 02:28:34 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:28:34 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:28:34 --> Utf8 Class Initialized
INFO - 2021-12-01 02:28:34 --> URI Class Initialized
INFO - 2021-12-01 02:28:34 --> Router Class Initialized
INFO - 2021-12-01 02:28:34 --> Output Class Initialized
INFO - 2021-12-01 02:28:34 --> Security Class Initialized
DEBUG - 2021-12-01 02:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:28:34 --> Input Class Initialized
INFO - 2021-12-01 02:28:34 --> Language Class Initialized
INFO - 2021-12-01 02:28:34 --> Language Class Initialized
INFO - 2021-12-01 02:28:34 --> Config Class Initialized
INFO - 2021-12-01 02:28:34 --> Loader Class Initialized
INFO - 2021-12-01 02:28:34 --> Helper loaded: url_helper
INFO - 2021-12-01 02:28:34 --> Helper loaded: file_helper
INFO - 2021-12-01 02:28:34 --> Helper loaded: form_helper
INFO - 2021-12-01 02:28:34 --> Helper loaded: my_helper
INFO - 2021-12-01 02:28:34 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:28:34 --> Controller Class Initialized
DEBUG - 2021-12-01 02:28:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 02:28:34 --> Final output sent to browser
DEBUG - 2021-12-01 02:28:34 --> Total execution time: 0.1439
INFO - 2021-12-01 02:29:57 --> Config Class Initialized
INFO - 2021-12-01 02:29:57 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:29:57 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:29:57 --> Utf8 Class Initialized
INFO - 2021-12-01 02:29:57 --> URI Class Initialized
INFO - 2021-12-01 02:29:57 --> Router Class Initialized
INFO - 2021-12-01 02:29:57 --> Output Class Initialized
INFO - 2021-12-01 02:29:57 --> Security Class Initialized
DEBUG - 2021-12-01 02:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:29:57 --> Input Class Initialized
INFO - 2021-12-01 02:29:57 --> Language Class Initialized
INFO - 2021-12-01 02:29:57 --> Language Class Initialized
INFO - 2021-12-01 02:29:57 --> Config Class Initialized
INFO - 2021-12-01 02:29:57 --> Loader Class Initialized
INFO - 2021-12-01 02:29:57 --> Helper loaded: url_helper
INFO - 2021-12-01 02:29:57 --> Helper loaded: file_helper
INFO - 2021-12-01 02:29:57 --> Helper loaded: form_helper
INFO - 2021-12-01 02:29:57 --> Helper loaded: my_helper
INFO - 2021-12-01 02:29:57 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:29:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:29:57 --> Controller Class Initialized
DEBUG - 2021-12-01 02:29:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-01 02:29:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 02:29:57 --> Final output sent to browser
DEBUG - 2021-12-01 02:29:57 --> Total execution time: 0.1079
INFO - 2021-12-01 02:30:37 --> Config Class Initialized
INFO - 2021-12-01 02:30:37 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:30:37 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:30:37 --> Utf8 Class Initialized
INFO - 2021-12-01 02:30:37 --> URI Class Initialized
INFO - 2021-12-01 02:30:37 --> Router Class Initialized
INFO - 2021-12-01 02:30:37 --> Output Class Initialized
INFO - 2021-12-01 02:30:37 --> Security Class Initialized
DEBUG - 2021-12-01 02:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:30:37 --> Input Class Initialized
INFO - 2021-12-01 02:30:37 --> Language Class Initialized
INFO - 2021-12-01 02:30:37 --> Language Class Initialized
INFO - 2021-12-01 02:30:37 --> Config Class Initialized
INFO - 2021-12-01 02:30:37 --> Loader Class Initialized
INFO - 2021-12-01 02:30:37 --> Helper loaded: url_helper
INFO - 2021-12-01 02:30:37 --> Helper loaded: file_helper
INFO - 2021-12-01 02:30:37 --> Helper loaded: form_helper
INFO - 2021-12-01 02:30:37 --> Helper loaded: my_helper
INFO - 2021-12-01 02:30:37 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:30:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:30:37 --> Controller Class Initialized
INFO - 2021-12-01 02:30:37 --> Final output sent to browser
DEBUG - 2021-12-01 02:30:37 --> Total execution time: 0.1782
INFO - 2021-12-01 02:30:41 --> Config Class Initialized
INFO - 2021-12-01 02:30:41 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:30:41 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:30:41 --> Utf8 Class Initialized
INFO - 2021-12-01 02:30:41 --> URI Class Initialized
INFO - 2021-12-01 02:30:41 --> Router Class Initialized
INFO - 2021-12-01 02:30:41 --> Output Class Initialized
INFO - 2021-12-01 02:30:41 --> Security Class Initialized
DEBUG - 2021-12-01 02:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:30:41 --> Input Class Initialized
INFO - 2021-12-01 02:30:41 --> Language Class Initialized
INFO - 2021-12-01 02:30:41 --> Language Class Initialized
INFO - 2021-12-01 02:30:41 --> Config Class Initialized
INFO - 2021-12-01 02:30:41 --> Loader Class Initialized
INFO - 2021-12-01 02:30:41 --> Helper loaded: url_helper
INFO - 2021-12-01 02:30:41 --> Helper loaded: file_helper
INFO - 2021-12-01 02:30:41 --> Helper loaded: form_helper
INFO - 2021-12-01 02:30:41 --> Helper loaded: my_helper
INFO - 2021-12-01 02:30:41 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:30:41 --> Controller Class Initialized
DEBUG - 2021-12-01 02:30:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-01 02:30:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 02:30:41 --> Final output sent to browser
DEBUG - 2021-12-01 02:30:41 --> Total execution time: 0.0894
INFO - 2021-12-01 02:30:47 --> Config Class Initialized
INFO - 2021-12-01 02:30:47 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:30:47 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:30:47 --> Utf8 Class Initialized
INFO - 2021-12-01 02:30:47 --> URI Class Initialized
INFO - 2021-12-01 02:30:47 --> Router Class Initialized
INFO - 2021-12-01 02:30:47 --> Output Class Initialized
INFO - 2021-12-01 02:30:47 --> Security Class Initialized
DEBUG - 2021-12-01 02:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:30:47 --> Input Class Initialized
INFO - 2021-12-01 02:30:47 --> Language Class Initialized
INFO - 2021-12-01 02:30:47 --> Language Class Initialized
INFO - 2021-12-01 02:30:47 --> Config Class Initialized
INFO - 2021-12-01 02:30:47 --> Loader Class Initialized
INFO - 2021-12-01 02:30:47 --> Helper loaded: url_helper
INFO - 2021-12-01 02:30:47 --> Helper loaded: file_helper
INFO - 2021-12-01 02:30:47 --> Helper loaded: form_helper
INFO - 2021-12-01 02:30:47 --> Helper loaded: my_helper
INFO - 2021-12-01 02:30:47 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:30:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:30:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:30:47 --> Controller Class Initialized
DEBUG - 2021-12-01 02:30:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 02:30:47 --> Final output sent to browser
DEBUG - 2021-12-01 02:30:47 --> Total execution time: 0.1506
INFO - 2021-12-01 02:32:11 --> Config Class Initialized
INFO - 2021-12-01 02:32:11 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:32:11 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:32:11 --> Utf8 Class Initialized
INFO - 2021-12-01 02:32:11 --> URI Class Initialized
INFO - 2021-12-01 02:32:11 --> Router Class Initialized
INFO - 2021-12-01 02:32:11 --> Output Class Initialized
INFO - 2021-12-01 02:32:11 --> Security Class Initialized
DEBUG - 2021-12-01 02:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:32:11 --> Input Class Initialized
INFO - 2021-12-01 02:32:11 --> Language Class Initialized
INFO - 2021-12-01 02:32:11 --> Language Class Initialized
INFO - 2021-12-01 02:32:11 --> Config Class Initialized
INFO - 2021-12-01 02:32:11 --> Loader Class Initialized
INFO - 2021-12-01 02:32:11 --> Helper loaded: url_helper
INFO - 2021-12-01 02:32:11 --> Helper loaded: file_helper
INFO - 2021-12-01 02:32:11 --> Helper loaded: form_helper
INFO - 2021-12-01 02:32:11 --> Helper loaded: my_helper
INFO - 2021-12-01 02:32:11 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:32:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:32:11 --> Controller Class Initialized
DEBUG - 2021-12-01 02:32:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-01 02:32:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 02:32:11 --> Final output sent to browser
DEBUG - 2021-12-01 02:32:11 --> Total execution time: 0.1159
INFO - 2021-12-01 02:32:23 --> Config Class Initialized
INFO - 2021-12-01 02:32:23 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:32:23 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:32:23 --> Utf8 Class Initialized
INFO - 2021-12-01 02:32:23 --> URI Class Initialized
INFO - 2021-12-01 02:32:23 --> Router Class Initialized
INFO - 2021-12-01 02:32:23 --> Output Class Initialized
INFO - 2021-12-01 02:32:23 --> Security Class Initialized
DEBUG - 2021-12-01 02:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:32:23 --> Input Class Initialized
INFO - 2021-12-01 02:32:23 --> Language Class Initialized
INFO - 2021-12-01 02:32:23 --> Language Class Initialized
INFO - 2021-12-01 02:32:23 --> Config Class Initialized
INFO - 2021-12-01 02:32:23 --> Loader Class Initialized
INFO - 2021-12-01 02:32:23 --> Helper loaded: url_helper
INFO - 2021-12-01 02:32:23 --> Helper loaded: file_helper
INFO - 2021-12-01 02:32:23 --> Helper loaded: form_helper
INFO - 2021-12-01 02:32:23 --> Helper loaded: my_helper
INFO - 2021-12-01 02:32:23 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:32:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:32:23 --> Controller Class Initialized
INFO - 2021-12-01 02:32:23 --> Final output sent to browser
DEBUG - 2021-12-01 02:32:23 --> Total execution time: 0.2090
INFO - 2021-12-01 02:32:24 --> Config Class Initialized
INFO - 2021-12-01 02:32:24 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:32:24 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:32:24 --> Utf8 Class Initialized
INFO - 2021-12-01 02:32:24 --> URI Class Initialized
INFO - 2021-12-01 02:32:24 --> Router Class Initialized
INFO - 2021-12-01 02:32:24 --> Output Class Initialized
INFO - 2021-12-01 02:32:24 --> Security Class Initialized
DEBUG - 2021-12-01 02:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:32:24 --> Input Class Initialized
INFO - 2021-12-01 02:32:24 --> Language Class Initialized
INFO - 2021-12-01 02:32:24 --> Language Class Initialized
INFO - 2021-12-01 02:32:24 --> Config Class Initialized
INFO - 2021-12-01 02:32:24 --> Loader Class Initialized
INFO - 2021-12-01 02:32:24 --> Helper loaded: url_helper
INFO - 2021-12-01 02:32:24 --> Helper loaded: file_helper
INFO - 2021-12-01 02:32:24 --> Helper loaded: form_helper
INFO - 2021-12-01 02:32:24 --> Helper loaded: my_helper
INFO - 2021-12-01 02:32:24 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:32:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:32:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:32:24 --> Controller Class Initialized
DEBUG - 2021-12-01 02:32:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-01 02:32:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 02:32:24 --> Final output sent to browser
DEBUG - 2021-12-01 02:32:24 --> Total execution time: 0.0955
INFO - 2021-12-01 02:32:30 --> Config Class Initialized
INFO - 2021-12-01 02:32:30 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:32:30 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:32:30 --> Utf8 Class Initialized
INFO - 2021-12-01 02:32:30 --> URI Class Initialized
INFO - 2021-12-01 02:32:30 --> Router Class Initialized
INFO - 2021-12-01 02:32:30 --> Output Class Initialized
INFO - 2021-12-01 02:32:30 --> Security Class Initialized
DEBUG - 2021-12-01 02:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:32:30 --> Input Class Initialized
INFO - 2021-12-01 02:32:30 --> Language Class Initialized
INFO - 2021-12-01 02:32:30 --> Language Class Initialized
INFO - 2021-12-01 02:32:30 --> Config Class Initialized
INFO - 2021-12-01 02:32:30 --> Loader Class Initialized
INFO - 2021-12-01 02:32:30 --> Helper loaded: url_helper
INFO - 2021-12-01 02:32:30 --> Helper loaded: file_helper
INFO - 2021-12-01 02:32:30 --> Helper loaded: form_helper
INFO - 2021-12-01 02:32:30 --> Helper loaded: my_helper
INFO - 2021-12-01 02:32:30 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:32:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:32:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:32:30 --> Controller Class Initialized
DEBUG - 2021-12-01 02:32:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 02:32:30 --> Final output sent to browser
DEBUG - 2021-12-01 02:32:30 --> Total execution time: 0.1693
INFO - 2021-12-01 02:33:01 --> Config Class Initialized
INFO - 2021-12-01 02:33:01 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:33:01 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:33:01 --> Utf8 Class Initialized
INFO - 2021-12-01 02:33:01 --> URI Class Initialized
INFO - 2021-12-01 02:33:01 --> Router Class Initialized
INFO - 2021-12-01 02:33:01 --> Output Class Initialized
INFO - 2021-12-01 02:33:01 --> Security Class Initialized
DEBUG - 2021-12-01 02:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:33:01 --> Input Class Initialized
INFO - 2021-12-01 02:33:01 --> Language Class Initialized
INFO - 2021-12-01 02:33:01 --> Language Class Initialized
INFO - 2021-12-01 02:33:01 --> Config Class Initialized
INFO - 2021-12-01 02:33:01 --> Loader Class Initialized
INFO - 2021-12-01 02:33:01 --> Helper loaded: url_helper
INFO - 2021-12-01 02:33:01 --> Helper loaded: file_helper
INFO - 2021-12-01 02:33:01 --> Helper loaded: form_helper
INFO - 2021-12-01 02:33:01 --> Helper loaded: my_helper
INFO - 2021-12-01 02:33:01 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:33:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:33:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:33:01 --> Controller Class Initialized
DEBUG - 2021-12-01 02:33:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-12-01 02:33:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 02:33:01 --> Final output sent to browser
DEBUG - 2021-12-01 02:33:01 --> Total execution time: 0.0809
INFO - 2021-12-01 02:33:05 --> Config Class Initialized
INFO - 2021-12-01 02:33:05 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:33:05 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:33:05 --> Utf8 Class Initialized
INFO - 2021-12-01 02:33:05 --> URI Class Initialized
INFO - 2021-12-01 02:33:05 --> Router Class Initialized
INFO - 2021-12-01 02:33:05 --> Output Class Initialized
INFO - 2021-12-01 02:33:05 --> Security Class Initialized
DEBUG - 2021-12-01 02:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:33:05 --> Input Class Initialized
INFO - 2021-12-01 02:33:05 --> Language Class Initialized
INFO - 2021-12-01 02:33:05 --> Language Class Initialized
INFO - 2021-12-01 02:33:05 --> Config Class Initialized
INFO - 2021-12-01 02:33:05 --> Loader Class Initialized
INFO - 2021-12-01 02:33:05 --> Helper loaded: url_helper
INFO - 2021-12-01 02:33:05 --> Helper loaded: file_helper
INFO - 2021-12-01 02:33:05 --> Helper loaded: form_helper
INFO - 2021-12-01 02:33:05 --> Helper loaded: my_helper
INFO - 2021-12-01 02:33:05 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:33:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:33:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:33:05 --> Controller Class Initialized
DEBUG - 2021-12-01 02:33:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-01 02:33:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 02:33:05 --> Final output sent to browser
DEBUG - 2021-12-01 02:33:05 --> Total execution time: 0.1248
INFO - 2021-12-01 02:33:14 --> Config Class Initialized
INFO - 2021-12-01 02:33:14 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:33:14 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:33:14 --> Utf8 Class Initialized
INFO - 2021-12-01 02:33:14 --> URI Class Initialized
INFO - 2021-12-01 02:33:14 --> Router Class Initialized
INFO - 2021-12-01 02:33:14 --> Output Class Initialized
INFO - 2021-12-01 02:33:14 --> Security Class Initialized
DEBUG - 2021-12-01 02:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:33:14 --> Input Class Initialized
INFO - 2021-12-01 02:33:14 --> Language Class Initialized
INFO - 2021-12-01 02:33:14 --> Language Class Initialized
INFO - 2021-12-01 02:33:14 --> Config Class Initialized
INFO - 2021-12-01 02:33:14 --> Loader Class Initialized
INFO - 2021-12-01 02:33:14 --> Helper loaded: url_helper
INFO - 2021-12-01 02:33:14 --> Helper loaded: file_helper
INFO - 2021-12-01 02:33:14 --> Helper loaded: form_helper
INFO - 2021-12-01 02:33:14 --> Helper loaded: my_helper
INFO - 2021-12-01 02:33:14 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:33:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:33:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:33:14 --> Controller Class Initialized
INFO - 2021-12-01 02:33:14 --> Final output sent to browser
DEBUG - 2021-12-01 02:33:14 --> Total execution time: 0.1818
INFO - 2021-12-01 02:33:17 --> Config Class Initialized
INFO - 2021-12-01 02:33:17 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:33:17 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:33:17 --> Utf8 Class Initialized
INFO - 2021-12-01 02:33:17 --> URI Class Initialized
INFO - 2021-12-01 02:33:17 --> Router Class Initialized
INFO - 2021-12-01 02:33:17 --> Output Class Initialized
INFO - 2021-12-01 02:33:17 --> Security Class Initialized
DEBUG - 2021-12-01 02:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:33:17 --> Input Class Initialized
INFO - 2021-12-01 02:33:17 --> Language Class Initialized
INFO - 2021-12-01 02:33:17 --> Language Class Initialized
INFO - 2021-12-01 02:33:17 --> Config Class Initialized
INFO - 2021-12-01 02:33:17 --> Loader Class Initialized
INFO - 2021-12-01 02:33:17 --> Helper loaded: url_helper
INFO - 2021-12-01 02:33:17 --> Helper loaded: file_helper
INFO - 2021-12-01 02:33:17 --> Helper loaded: form_helper
INFO - 2021-12-01 02:33:17 --> Helper loaded: my_helper
INFO - 2021-12-01 02:33:17 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:33:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:33:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:33:17 --> Controller Class Initialized
DEBUG - 2021-12-01 02:33:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-01 02:33:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 02:33:17 --> Final output sent to browser
DEBUG - 2021-12-01 02:33:17 --> Total execution time: 0.1143
INFO - 2021-12-01 02:33:23 --> Config Class Initialized
INFO - 2021-12-01 02:33:23 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:33:24 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:33:24 --> Utf8 Class Initialized
INFO - 2021-12-01 02:33:24 --> URI Class Initialized
INFO - 2021-12-01 02:33:24 --> Router Class Initialized
INFO - 2021-12-01 02:33:24 --> Output Class Initialized
INFO - 2021-12-01 02:33:24 --> Security Class Initialized
DEBUG - 2021-12-01 02:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:33:24 --> Input Class Initialized
INFO - 2021-12-01 02:33:24 --> Language Class Initialized
INFO - 2021-12-01 02:33:24 --> Language Class Initialized
INFO - 2021-12-01 02:33:24 --> Config Class Initialized
INFO - 2021-12-01 02:33:24 --> Loader Class Initialized
INFO - 2021-12-01 02:33:24 --> Helper loaded: url_helper
INFO - 2021-12-01 02:33:24 --> Helper loaded: file_helper
INFO - 2021-12-01 02:33:24 --> Helper loaded: form_helper
INFO - 2021-12-01 02:33:24 --> Helper loaded: my_helper
INFO - 2021-12-01 02:33:24 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:33:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:33:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:33:24 --> Controller Class Initialized
DEBUG - 2021-12-01 02:33:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 02:33:24 --> Final output sent to browser
DEBUG - 2021-12-01 02:33:24 --> Total execution time: 0.1538
INFO - 2021-12-01 02:34:07 --> Config Class Initialized
INFO - 2021-12-01 02:34:07 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:34:07 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:34:07 --> Utf8 Class Initialized
INFO - 2021-12-01 02:34:07 --> URI Class Initialized
INFO - 2021-12-01 02:34:07 --> Router Class Initialized
INFO - 2021-12-01 02:34:07 --> Output Class Initialized
INFO - 2021-12-01 02:34:07 --> Security Class Initialized
DEBUG - 2021-12-01 02:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:34:07 --> Input Class Initialized
INFO - 2021-12-01 02:34:07 --> Language Class Initialized
INFO - 2021-12-01 02:34:07 --> Language Class Initialized
INFO - 2021-12-01 02:34:07 --> Config Class Initialized
INFO - 2021-12-01 02:34:07 --> Loader Class Initialized
INFO - 2021-12-01 02:34:07 --> Helper loaded: url_helper
INFO - 2021-12-01 02:34:07 --> Helper loaded: file_helper
INFO - 2021-12-01 02:34:07 --> Helper loaded: form_helper
INFO - 2021-12-01 02:34:07 --> Helper loaded: my_helper
INFO - 2021-12-01 02:34:07 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:34:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:34:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:34:08 --> Controller Class Initialized
INFO - 2021-12-01 02:34:08 --> Helper loaded: cookie_helper
INFO - 2021-12-01 02:34:08 --> Config Class Initialized
INFO - 2021-12-01 02:34:08 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:34:08 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:34:08 --> Utf8 Class Initialized
INFO - 2021-12-01 02:34:08 --> URI Class Initialized
INFO - 2021-12-01 02:34:08 --> Router Class Initialized
INFO - 2021-12-01 02:34:08 --> Output Class Initialized
INFO - 2021-12-01 02:34:08 --> Security Class Initialized
DEBUG - 2021-12-01 02:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:34:08 --> Input Class Initialized
INFO - 2021-12-01 02:34:08 --> Language Class Initialized
INFO - 2021-12-01 02:34:08 --> Language Class Initialized
INFO - 2021-12-01 02:34:08 --> Config Class Initialized
INFO - 2021-12-01 02:34:08 --> Loader Class Initialized
INFO - 2021-12-01 02:34:08 --> Helper loaded: url_helper
INFO - 2021-12-01 02:34:08 --> Helper loaded: file_helper
INFO - 2021-12-01 02:34:08 --> Helper loaded: form_helper
INFO - 2021-12-01 02:34:08 --> Helper loaded: my_helper
INFO - 2021-12-01 02:34:08 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:34:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:34:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:34:08 --> Controller Class Initialized
DEBUG - 2021-12-01 02:34:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-01 02:34:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 02:34:08 --> Final output sent to browser
DEBUG - 2021-12-01 02:34:08 --> Total execution time: 0.0558
INFO - 2021-12-01 02:34:11 --> Config Class Initialized
INFO - 2021-12-01 02:34:11 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:34:11 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:34:11 --> Utf8 Class Initialized
INFO - 2021-12-01 02:34:11 --> URI Class Initialized
INFO - 2021-12-01 02:34:11 --> Router Class Initialized
INFO - 2021-12-01 02:34:11 --> Output Class Initialized
INFO - 2021-12-01 02:34:11 --> Security Class Initialized
DEBUG - 2021-12-01 02:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:34:11 --> Input Class Initialized
INFO - 2021-12-01 02:34:11 --> Language Class Initialized
INFO - 2021-12-01 02:34:11 --> Language Class Initialized
INFO - 2021-12-01 02:34:11 --> Config Class Initialized
INFO - 2021-12-01 02:34:11 --> Loader Class Initialized
INFO - 2021-12-01 02:34:11 --> Helper loaded: url_helper
INFO - 2021-12-01 02:34:11 --> Helper loaded: file_helper
INFO - 2021-12-01 02:34:11 --> Helper loaded: form_helper
INFO - 2021-12-01 02:34:11 --> Helper loaded: my_helper
INFO - 2021-12-01 02:34:11 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:34:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:34:11 --> Controller Class Initialized
INFO - 2021-12-01 02:34:11 --> Helper loaded: cookie_helper
INFO - 2021-12-01 02:34:11 --> Final output sent to browser
DEBUG - 2021-12-01 02:34:11 --> Total execution time: 0.0757
INFO - 2021-12-01 02:34:12 --> Config Class Initialized
INFO - 2021-12-01 02:34:12 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:34:12 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:34:12 --> Utf8 Class Initialized
INFO - 2021-12-01 02:34:12 --> URI Class Initialized
INFO - 2021-12-01 02:34:12 --> Router Class Initialized
INFO - 2021-12-01 02:34:12 --> Output Class Initialized
INFO - 2021-12-01 02:34:12 --> Security Class Initialized
DEBUG - 2021-12-01 02:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:34:12 --> Input Class Initialized
INFO - 2021-12-01 02:34:12 --> Language Class Initialized
INFO - 2021-12-01 02:34:12 --> Language Class Initialized
INFO - 2021-12-01 02:34:12 --> Config Class Initialized
INFO - 2021-12-01 02:34:12 --> Loader Class Initialized
INFO - 2021-12-01 02:34:12 --> Helper loaded: url_helper
INFO - 2021-12-01 02:34:12 --> Helper loaded: file_helper
INFO - 2021-12-01 02:34:12 --> Helper loaded: form_helper
INFO - 2021-12-01 02:34:12 --> Helper loaded: my_helper
INFO - 2021-12-01 02:34:12 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:34:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:34:12 --> Controller Class Initialized
DEBUG - 2021-12-01 02:34:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-01 02:34:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 02:34:12 --> Final output sent to browser
DEBUG - 2021-12-01 02:34:12 --> Total execution time: 0.2377
INFO - 2021-12-01 02:39:01 --> Config Class Initialized
INFO - 2021-12-01 02:39:01 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:39:01 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:39:01 --> Utf8 Class Initialized
INFO - 2021-12-01 02:39:01 --> URI Class Initialized
INFO - 2021-12-01 02:39:01 --> Router Class Initialized
INFO - 2021-12-01 02:39:01 --> Output Class Initialized
INFO - 2021-12-01 02:39:01 --> Security Class Initialized
DEBUG - 2021-12-01 02:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:39:01 --> Input Class Initialized
INFO - 2021-12-01 02:39:01 --> Language Class Initialized
INFO - 2021-12-01 02:39:01 --> Language Class Initialized
INFO - 2021-12-01 02:39:01 --> Config Class Initialized
INFO - 2021-12-01 02:39:01 --> Loader Class Initialized
INFO - 2021-12-01 02:39:01 --> Helper loaded: url_helper
INFO - 2021-12-01 02:39:01 --> Helper loaded: file_helper
INFO - 2021-12-01 02:39:01 --> Helper loaded: form_helper
INFO - 2021-12-01 02:39:01 --> Helper loaded: my_helper
INFO - 2021-12-01 02:39:01 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:39:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:39:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:39:01 --> Controller Class Initialized
INFO - 2021-12-01 02:39:01 --> Helper loaded: cookie_helper
INFO - 2021-12-01 02:39:01 --> Config Class Initialized
INFO - 2021-12-01 02:39:01 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:39:01 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:39:01 --> Utf8 Class Initialized
INFO - 2021-12-01 02:39:01 --> URI Class Initialized
INFO - 2021-12-01 02:39:01 --> Router Class Initialized
INFO - 2021-12-01 02:39:01 --> Output Class Initialized
INFO - 2021-12-01 02:39:01 --> Security Class Initialized
DEBUG - 2021-12-01 02:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:39:01 --> Input Class Initialized
INFO - 2021-12-01 02:39:01 --> Language Class Initialized
INFO - 2021-12-01 02:39:01 --> Language Class Initialized
INFO - 2021-12-01 02:39:01 --> Config Class Initialized
INFO - 2021-12-01 02:39:01 --> Loader Class Initialized
INFO - 2021-12-01 02:39:01 --> Helper loaded: url_helper
INFO - 2021-12-01 02:39:01 --> Helper loaded: file_helper
INFO - 2021-12-01 02:39:01 --> Helper loaded: form_helper
INFO - 2021-12-01 02:39:01 --> Helper loaded: my_helper
INFO - 2021-12-01 02:39:01 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:39:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:39:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:39:01 --> Controller Class Initialized
DEBUG - 2021-12-01 02:39:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-01 02:39:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 02:39:01 --> Final output sent to browser
DEBUG - 2021-12-01 02:39:01 --> Total execution time: 0.0598
INFO - 2021-12-01 02:40:08 --> Config Class Initialized
INFO - 2021-12-01 02:40:08 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:40:08 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:40:08 --> Utf8 Class Initialized
INFO - 2021-12-01 02:40:08 --> URI Class Initialized
INFO - 2021-12-01 02:40:08 --> Router Class Initialized
INFO - 2021-12-01 02:40:08 --> Output Class Initialized
INFO - 2021-12-01 02:40:08 --> Security Class Initialized
DEBUG - 2021-12-01 02:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:40:08 --> Input Class Initialized
INFO - 2021-12-01 02:40:08 --> Language Class Initialized
INFO - 2021-12-01 02:40:08 --> Language Class Initialized
INFO - 2021-12-01 02:40:08 --> Config Class Initialized
INFO - 2021-12-01 02:40:08 --> Loader Class Initialized
INFO - 2021-12-01 02:40:08 --> Helper loaded: url_helper
INFO - 2021-12-01 02:40:08 --> Helper loaded: file_helper
INFO - 2021-12-01 02:40:08 --> Helper loaded: form_helper
INFO - 2021-12-01 02:40:08 --> Helper loaded: my_helper
INFO - 2021-12-01 02:40:08 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:40:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:40:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:40:08 --> Controller Class Initialized
INFO - 2021-12-01 02:40:08 --> Helper loaded: cookie_helper
INFO - 2021-12-01 02:40:08 --> Final output sent to browser
DEBUG - 2021-12-01 02:40:08 --> Total execution time: 0.0759
INFO - 2021-12-01 02:40:08 --> Config Class Initialized
INFO - 2021-12-01 02:40:08 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:40:08 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:40:08 --> Utf8 Class Initialized
INFO - 2021-12-01 02:40:08 --> URI Class Initialized
INFO - 2021-12-01 02:40:08 --> Router Class Initialized
INFO - 2021-12-01 02:40:08 --> Output Class Initialized
INFO - 2021-12-01 02:40:08 --> Security Class Initialized
DEBUG - 2021-12-01 02:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:40:08 --> Input Class Initialized
INFO - 2021-12-01 02:40:08 --> Language Class Initialized
INFO - 2021-12-01 02:40:08 --> Language Class Initialized
INFO - 2021-12-01 02:40:08 --> Config Class Initialized
INFO - 2021-12-01 02:40:08 --> Loader Class Initialized
INFO - 2021-12-01 02:40:08 --> Helper loaded: url_helper
INFO - 2021-12-01 02:40:08 --> Helper loaded: file_helper
INFO - 2021-12-01 02:40:08 --> Helper loaded: form_helper
INFO - 2021-12-01 02:40:08 --> Helper loaded: my_helper
INFO - 2021-12-01 02:40:08 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:40:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:40:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:40:08 --> Controller Class Initialized
DEBUG - 2021-12-01 02:40:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-01 02:40:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 02:40:09 --> Final output sent to browser
DEBUG - 2021-12-01 02:40:09 --> Total execution time: 0.1917
INFO - 2021-12-01 02:40:14 --> Config Class Initialized
INFO - 2021-12-01 02:40:14 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:40:14 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:40:14 --> Utf8 Class Initialized
INFO - 2021-12-01 02:40:14 --> URI Class Initialized
INFO - 2021-12-01 02:40:14 --> Router Class Initialized
INFO - 2021-12-01 02:40:14 --> Output Class Initialized
INFO - 2021-12-01 02:40:14 --> Security Class Initialized
DEBUG - 2021-12-01 02:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:40:14 --> Input Class Initialized
INFO - 2021-12-01 02:40:14 --> Language Class Initialized
INFO - 2021-12-01 02:40:14 --> Language Class Initialized
INFO - 2021-12-01 02:40:14 --> Config Class Initialized
INFO - 2021-12-01 02:40:14 --> Loader Class Initialized
INFO - 2021-12-01 02:40:14 --> Helper loaded: url_helper
INFO - 2021-12-01 02:40:14 --> Helper loaded: file_helper
INFO - 2021-12-01 02:40:14 --> Helper loaded: form_helper
INFO - 2021-12-01 02:40:14 --> Helper loaded: my_helper
INFO - 2021-12-01 02:40:14 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:40:14 --> Controller Class Initialized
DEBUG - 2021-12-01 02:40:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-01 02:40:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 02:40:14 --> Final output sent to browser
DEBUG - 2021-12-01 02:40:14 --> Total execution time: 0.1349
INFO - 2021-12-01 02:40:15 --> Config Class Initialized
INFO - 2021-12-01 02:40:15 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:40:15 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:40:15 --> Utf8 Class Initialized
INFO - 2021-12-01 02:40:15 --> URI Class Initialized
INFO - 2021-12-01 02:40:15 --> Router Class Initialized
INFO - 2021-12-01 02:40:15 --> Output Class Initialized
INFO - 2021-12-01 02:40:15 --> Security Class Initialized
DEBUG - 2021-12-01 02:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:40:15 --> Input Class Initialized
INFO - 2021-12-01 02:40:15 --> Language Class Initialized
INFO - 2021-12-01 02:40:15 --> Language Class Initialized
INFO - 2021-12-01 02:40:15 --> Config Class Initialized
INFO - 2021-12-01 02:40:15 --> Loader Class Initialized
INFO - 2021-12-01 02:40:15 --> Helper loaded: url_helper
INFO - 2021-12-01 02:40:15 --> Helper loaded: file_helper
INFO - 2021-12-01 02:40:15 --> Helper loaded: form_helper
INFO - 2021-12-01 02:40:15 --> Helper loaded: my_helper
INFO - 2021-12-01 02:40:15 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:40:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:40:15 --> Controller Class Initialized
DEBUG - 2021-12-01 02:40:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-12-01 02:40:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 02:40:15 --> Final output sent to browser
DEBUG - 2021-12-01 02:40:15 --> Total execution time: 0.0884
INFO - 2021-12-01 02:40:15 --> Config Class Initialized
INFO - 2021-12-01 02:40:15 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:40:15 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:40:15 --> Utf8 Class Initialized
INFO - 2021-12-01 02:40:15 --> URI Class Initialized
INFO - 2021-12-01 02:40:15 --> Router Class Initialized
INFO - 2021-12-01 02:40:15 --> Output Class Initialized
INFO - 2021-12-01 02:40:15 --> Security Class Initialized
DEBUG - 2021-12-01 02:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:40:15 --> Input Class Initialized
INFO - 2021-12-01 02:40:15 --> Language Class Initialized
INFO - 2021-12-01 02:40:15 --> Language Class Initialized
INFO - 2021-12-01 02:40:15 --> Config Class Initialized
INFO - 2021-12-01 02:40:15 --> Loader Class Initialized
INFO - 2021-12-01 02:40:15 --> Helper loaded: url_helper
INFO - 2021-12-01 02:40:15 --> Helper loaded: file_helper
INFO - 2021-12-01 02:40:15 --> Helper loaded: form_helper
INFO - 2021-12-01 02:40:15 --> Helper loaded: my_helper
INFO - 2021-12-01 02:40:15 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:40:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:40:15 --> Controller Class Initialized
INFO - 2021-12-01 02:40:19 --> Config Class Initialized
INFO - 2021-12-01 02:40:19 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:40:19 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:40:19 --> Utf8 Class Initialized
INFO - 2021-12-01 02:40:19 --> URI Class Initialized
INFO - 2021-12-01 02:40:19 --> Router Class Initialized
INFO - 2021-12-01 02:40:19 --> Output Class Initialized
INFO - 2021-12-01 02:40:19 --> Security Class Initialized
DEBUG - 2021-12-01 02:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:40:19 --> Input Class Initialized
INFO - 2021-12-01 02:40:19 --> Language Class Initialized
INFO - 2021-12-01 02:40:19 --> Language Class Initialized
INFO - 2021-12-01 02:40:19 --> Config Class Initialized
INFO - 2021-12-01 02:40:19 --> Loader Class Initialized
INFO - 2021-12-01 02:40:19 --> Helper loaded: url_helper
INFO - 2021-12-01 02:40:19 --> Helper loaded: file_helper
INFO - 2021-12-01 02:40:19 --> Helper loaded: form_helper
INFO - 2021-12-01 02:40:19 --> Helper loaded: my_helper
INFO - 2021-12-01 02:40:19 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:40:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:40:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:40:19 --> Controller Class Initialized
INFO - 2021-12-01 02:40:19 --> Final output sent to browser
DEBUG - 2021-12-01 02:40:19 --> Total execution time: 0.0726
INFO - 2021-12-01 02:40:19 --> Config Class Initialized
INFO - 2021-12-01 02:40:19 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:40:19 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:40:19 --> Utf8 Class Initialized
INFO - 2021-12-01 02:40:19 --> URI Class Initialized
INFO - 2021-12-01 02:40:19 --> Router Class Initialized
INFO - 2021-12-01 02:40:19 --> Output Class Initialized
INFO - 2021-12-01 02:40:19 --> Security Class Initialized
DEBUG - 2021-12-01 02:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:40:19 --> Input Class Initialized
INFO - 2021-12-01 02:40:19 --> Language Class Initialized
INFO - 2021-12-01 02:40:19 --> Language Class Initialized
INFO - 2021-12-01 02:40:19 --> Config Class Initialized
INFO - 2021-12-01 02:40:19 --> Loader Class Initialized
INFO - 2021-12-01 02:40:19 --> Helper loaded: url_helper
INFO - 2021-12-01 02:40:19 --> Helper loaded: file_helper
INFO - 2021-12-01 02:40:19 --> Helper loaded: form_helper
INFO - 2021-12-01 02:40:19 --> Helper loaded: my_helper
INFO - 2021-12-01 02:40:19 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:40:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:40:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:40:19 --> Controller Class Initialized
INFO - 2021-12-01 02:41:05 --> Config Class Initialized
INFO - 2021-12-01 02:41:05 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:41:05 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:41:05 --> Utf8 Class Initialized
INFO - 2021-12-01 02:41:05 --> URI Class Initialized
INFO - 2021-12-01 02:41:05 --> Router Class Initialized
INFO - 2021-12-01 02:41:05 --> Output Class Initialized
INFO - 2021-12-01 02:41:05 --> Security Class Initialized
DEBUG - 2021-12-01 02:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:41:05 --> Input Class Initialized
INFO - 2021-12-01 02:41:05 --> Language Class Initialized
INFO - 2021-12-01 02:41:05 --> Language Class Initialized
INFO - 2021-12-01 02:41:05 --> Config Class Initialized
INFO - 2021-12-01 02:41:05 --> Loader Class Initialized
INFO - 2021-12-01 02:41:05 --> Helper loaded: url_helper
INFO - 2021-12-01 02:41:05 --> Helper loaded: file_helper
INFO - 2021-12-01 02:41:05 --> Helper loaded: form_helper
INFO - 2021-12-01 02:41:05 --> Helper loaded: my_helper
INFO - 2021-12-01 02:41:05 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:41:05 --> Controller Class Initialized
INFO - 2021-12-01 02:41:05 --> Helper loaded: cookie_helper
INFO - 2021-12-01 02:41:05 --> Config Class Initialized
INFO - 2021-12-01 02:41:05 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:41:05 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:41:05 --> Utf8 Class Initialized
INFO - 2021-12-01 02:41:05 --> URI Class Initialized
INFO - 2021-12-01 02:41:05 --> Router Class Initialized
INFO - 2021-12-01 02:41:05 --> Output Class Initialized
INFO - 2021-12-01 02:41:05 --> Security Class Initialized
DEBUG - 2021-12-01 02:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:41:05 --> Input Class Initialized
INFO - 2021-12-01 02:41:05 --> Language Class Initialized
INFO - 2021-12-01 02:41:05 --> Language Class Initialized
INFO - 2021-12-01 02:41:05 --> Config Class Initialized
INFO - 2021-12-01 02:41:05 --> Loader Class Initialized
INFO - 2021-12-01 02:41:05 --> Helper loaded: url_helper
INFO - 2021-12-01 02:41:05 --> Helper loaded: file_helper
INFO - 2021-12-01 02:41:05 --> Helper loaded: form_helper
INFO - 2021-12-01 02:41:05 --> Helper loaded: my_helper
INFO - 2021-12-01 02:41:05 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:41:05 --> Controller Class Initialized
DEBUG - 2021-12-01 02:41:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-01 02:41:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 02:41:05 --> Final output sent to browser
DEBUG - 2021-12-01 02:41:05 --> Total execution time: 0.0571
INFO - 2021-12-01 02:54:14 --> Config Class Initialized
INFO - 2021-12-01 02:54:14 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:54:14 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:54:14 --> Utf8 Class Initialized
INFO - 2021-12-01 02:54:14 --> URI Class Initialized
INFO - 2021-12-01 02:54:14 --> Router Class Initialized
INFO - 2021-12-01 02:54:14 --> Output Class Initialized
INFO - 2021-12-01 02:54:14 --> Security Class Initialized
DEBUG - 2021-12-01 02:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:54:14 --> Input Class Initialized
INFO - 2021-12-01 02:54:14 --> Language Class Initialized
INFO - 2021-12-01 02:54:14 --> Language Class Initialized
INFO - 2021-12-01 02:54:14 --> Config Class Initialized
INFO - 2021-12-01 02:54:14 --> Loader Class Initialized
INFO - 2021-12-01 02:54:14 --> Helper loaded: url_helper
INFO - 2021-12-01 02:54:14 --> Helper loaded: file_helper
INFO - 2021-12-01 02:54:14 --> Helper loaded: form_helper
INFO - 2021-12-01 02:54:14 --> Helper loaded: my_helper
INFO - 2021-12-01 02:54:14 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:54:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:54:14 --> Controller Class Initialized
INFO - 2021-12-01 02:54:14 --> Helper loaded: cookie_helper
INFO - 2021-12-01 02:54:14 --> Final output sent to browser
DEBUG - 2021-12-01 02:54:14 --> Total execution time: 0.1021
INFO - 2021-12-01 02:54:14 --> Config Class Initialized
INFO - 2021-12-01 02:54:14 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:54:14 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:54:14 --> Utf8 Class Initialized
INFO - 2021-12-01 02:54:14 --> URI Class Initialized
INFO - 2021-12-01 02:54:14 --> Router Class Initialized
INFO - 2021-12-01 02:54:14 --> Output Class Initialized
INFO - 2021-12-01 02:54:14 --> Security Class Initialized
DEBUG - 2021-12-01 02:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:54:14 --> Input Class Initialized
INFO - 2021-12-01 02:54:14 --> Language Class Initialized
INFO - 2021-12-01 02:54:14 --> Language Class Initialized
INFO - 2021-12-01 02:54:14 --> Config Class Initialized
INFO - 2021-12-01 02:54:14 --> Loader Class Initialized
INFO - 2021-12-01 02:54:14 --> Helper loaded: url_helper
INFO - 2021-12-01 02:54:14 --> Helper loaded: file_helper
INFO - 2021-12-01 02:54:14 --> Helper loaded: form_helper
INFO - 2021-12-01 02:54:14 --> Helper loaded: my_helper
INFO - 2021-12-01 02:54:14 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:54:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:54:14 --> Controller Class Initialized
DEBUG - 2021-12-01 02:54:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-01 02:54:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 02:54:14 --> Final output sent to browser
DEBUG - 2021-12-01 02:54:14 --> Total execution time: 0.2077
INFO - 2021-12-01 02:54:28 --> Config Class Initialized
INFO - 2021-12-01 02:54:28 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:54:28 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:54:28 --> Utf8 Class Initialized
INFO - 2021-12-01 02:54:28 --> URI Class Initialized
INFO - 2021-12-01 02:54:28 --> Router Class Initialized
INFO - 2021-12-01 02:54:28 --> Output Class Initialized
INFO - 2021-12-01 02:54:28 --> Security Class Initialized
DEBUG - 2021-12-01 02:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:54:28 --> Input Class Initialized
INFO - 2021-12-01 02:54:28 --> Language Class Initialized
INFO - 2021-12-01 02:54:28 --> Language Class Initialized
INFO - 2021-12-01 02:54:28 --> Config Class Initialized
INFO - 2021-12-01 02:54:28 --> Loader Class Initialized
INFO - 2021-12-01 02:54:28 --> Helper loaded: url_helper
INFO - 2021-12-01 02:54:28 --> Helper loaded: file_helper
INFO - 2021-12-01 02:54:28 --> Helper loaded: form_helper
INFO - 2021-12-01 02:54:28 --> Helper loaded: my_helper
INFO - 2021-12-01 02:54:28 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:54:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:54:28 --> Controller Class Initialized
DEBUG - 2021-12-01 02:54:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-01 02:54:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 02:54:28 --> Final output sent to browser
DEBUG - 2021-12-01 02:54:28 --> Total execution time: 0.0709
INFO - 2021-12-01 02:54:32 --> Config Class Initialized
INFO - 2021-12-01 02:54:32 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:54:32 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:54:32 --> Utf8 Class Initialized
INFO - 2021-12-01 02:54:32 --> URI Class Initialized
DEBUG - 2021-12-01 02:54:32 --> No URI present. Default controller set.
INFO - 2021-12-01 02:54:32 --> Router Class Initialized
INFO - 2021-12-01 02:54:32 --> Output Class Initialized
INFO - 2021-12-01 02:54:32 --> Security Class Initialized
DEBUG - 2021-12-01 02:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:54:32 --> Input Class Initialized
INFO - 2021-12-01 02:54:32 --> Language Class Initialized
INFO - 2021-12-01 02:54:32 --> Language Class Initialized
INFO - 2021-12-01 02:54:32 --> Config Class Initialized
INFO - 2021-12-01 02:54:32 --> Loader Class Initialized
INFO - 2021-12-01 02:54:32 --> Helper loaded: url_helper
INFO - 2021-12-01 02:54:32 --> Helper loaded: file_helper
INFO - 2021-12-01 02:54:32 --> Helper loaded: form_helper
INFO - 2021-12-01 02:54:32 --> Helper loaded: my_helper
INFO - 2021-12-01 02:54:32 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:54:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:54:32 --> Controller Class Initialized
DEBUG - 2021-12-01 02:54:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-01 02:54:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 02:54:33 --> Final output sent to browser
DEBUG - 2021-12-01 02:54:33 --> Total execution time: 0.2197
INFO - 2021-12-01 02:54:34 --> Config Class Initialized
INFO - 2021-12-01 02:54:34 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:54:34 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:54:34 --> Utf8 Class Initialized
INFO - 2021-12-01 02:54:34 --> URI Class Initialized
INFO - 2021-12-01 02:54:34 --> Router Class Initialized
INFO - 2021-12-01 02:54:34 --> Output Class Initialized
INFO - 2021-12-01 02:54:34 --> Security Class Initialized
DEBUG - 2021-12-01 02:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:54:34 --> Input Class Initialized
INFO - 2021-12-01 02:54:34 --> Language Class Initialized
INFO - 2021-12-01 02:54:34 --> Language Class Initialized
INFO - 2021-12-01 02:54:34 --> Config Class Initialized
INFO - 2021-12-01 02:54:34 --> Loader Class Initialized
INFO - 2021-12-01 02:54:34 --> Helper loaded: url_helper
INFO - 2021-12-01 02:54:34 --> Helper loaded: file_helper
INFO - 2021-12-01 02:54:34 --> Helper loaded: form_helper
INFO - 2021-12-01 02:54:34 --> Helper loaded: my_helper
INFO - 2021-12-01 02:54:34 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:54:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:54:34 --> Controller Class Initialized
DEBUG - 2021-12-01 02:54:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-12-01 02:54:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 02:54:34 --> Final output sent to browser
DEBUG - 2021-12-01 02:54:34 --> Total execution time: 0.1379
INFO - 2021-12-01 02:54:55 --> Config Class Initialized
INFO - 2021-12-01 02:54:55 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:54:55 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:54:55 --> Utf8 Class Initialized
INFO - 2021-12-01 02:54:55 --> URI Class Initialized
INFO - 2021-12-01 02:54:55 --> Router Class Initialized
INFO - 2021-12-01 02:54:55 --> Output Class Initialized
INFO - 2021-12-01 02:54:55 --> Security Class Initialized
DEBUG - 2021-12-01 02:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:54:55 --> Input Class Initialized
INFO - 2021-12-01 02:54:55 --> Language Class Initialized
INFO - 2021-12-01 02:54:55 --> Language Class Initialized
INFO - 2021-12-01 02:54:55 --> Config Class Initialized
INFO - 2021-12-01 02:54:55 --> Loader Class Initialized
INFO - 2021-12-01 02:54:55 --> Helper loaded: url_helper
INFO - 2021-12-01 02:54:55 --> Helper loaded: file_helper
INFO - 2021-12-01 02:54:55 --> Helper loaded: form_helper
INFO - 2021-12-01 02:54:55 --> Helper loaded: my_helper
INFO - 2021-12-01 02:54:55 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:54:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:54:55 --> Controller Class Initialized
DEBUG - 2021-12-01 02:54:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-12-01 02:54:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 02:54:55 --> Final output sent to browser
DEBUG - 2021-12-01 02:54:55 --> Total execution time: 0.0989
INFO - 2021-12-01 02:54:57 --> Config Class Initialized
INFO - 2021-12-01 02:54:57 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:54:57 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:54:57 --> Utf8 Class Initialized
INFO - 2021-12-01 02:54:57 --> URI Class Initialized
INFO - 2021-12-01 02:54:57 --> Router Class Initialized
INFO - 2021-12-01 02:54:57 --> Output Class Initialized
INFO - 2021-12-01 02:54:57 --> Security Class Initialized
DEBUG - 2021-12-01 02:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:54:57 --> Input Class Initialized
INFO - 2021-12-01 02:54:57 --> Language Class Initialized
INFO - 2021-12-01 02:54:57 --> Language Class Initialized
INFO - 2021-12-01 02:54:57 --> Config Class Initialized
INFO - 2021-12-01 02:54:57 --> Loader Class Initialized
INFO - 2021-12-01 02:54:57 --> Helper loaded: url_helper
INFO - 2021-12-01 02:54:57 --> Helper loaded: file_helper
INFO - 2021-12-01 02:54:57 --> Helper loaded: form_helper
INFO - 2021-12-01 02:54:57 --> Helper loaded: my_helper
INFO - 2021-12-01 02:54:57 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:54:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:54:57 --> Controller Class Initialized
DEBUG - 2021-12-01 02:54:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_to.php
INFO - 2021-12-01 02:54:57 --> Final output sent to browser
DEBUG - 2021-12-01 02:54:57 --> Total execution time: 0.1722
INFO - 2021-12-01 02:55:27 --> Config Class Initialized
INFO - 2021-12-01 02:55:27 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:55:27 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:55:27 --> Utf8 Class Initialized
INFO - 2021-12-01 02:55:27 --> URI Class Initialized
INFO - 2021-12-01 02:55:27 --> Router Class Initialized
INFO - 2021-12-01 02:55:27 --> Output Class Initialized
INFO - 2021-12-01 02:55:27 --> Security Class Initialized
DEBUG - 2021-12-01 02:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:55:27 --> Input Class Initialized
INFO - 2021-12-01 02:55:27 --> Language Class Initialized
INFO - 2021-12-01 02:55:27 --> Language Class Initialized
INFO - 2021-12-01 02:55:27 --> Config Class Initialized
INFO - 2021-12-01 02:55:27 --> Loader Class Initialized
INFO - 2021-12-01 02:55:27 --> Helper loaded: url_helper
INFO - 2021-12-01 02:55:27 --> Helper loaded: file_helper
INFO - 2021-12-01 02:55:27 --> Helper loaded: form_helper
INFO - 2021-12-01 02:55:27 --> Helper loaded: my_helper
INFO - 2021-12-01 02:55:27 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:55:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:55:27 --> Controller Class Initialized
DEBUG - 2021-12-01 02:55:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-01 02:55:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 02:55:27 --> Final output sent to browser
DEBUG - 2021-12-01 02:55:27 --> Total execution time: 0.0934
INFO - 2021-12-01 02:56:06 --> Config Class Initialized
INFO - 2021-12-01 02:56:06 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:56:06 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:56:06 --> Utf8 Class Initialized
INFO - 2021-12-01 02:56:06 --> URI Class Initialized
INFO - 2021-12-01 02:56:06 --> Router Class Initialized
INFO - 2021-12-01 02:56:06 --> Output Class Initialized
INFO - 2021-12-01 02:56:06 --> Security Class Initialized
DEBUG - 2021-12-01 02:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:56:06 --> Input Class Initialized
INFO - 2021-12-01 02:56:06 --> Language Class Initialized
INFO - 2021-12-01 02:56:06 --> Language Class Initialized
INFO - 2021-12-01 02:56:06 --> Config Class Initialized
INFO - 2021-12-01 02:56:06 --> Loader Class Initialized
INFO - 2021-12-01 02:56:06 --> Helper loaded: url_helper
INFO - 2021-12-01 02:56:06 --> Helper loaded: file_helper
INFO - 2021-12-01 02:56:06 --> Helper loaded: form_helper
INFO - 2021-12-01 02:56:06 --> Helper loaded: my_helper
INFO - 2021-12-01 02:56:06 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:56:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:56:06 --> Controller Class Initialized
DEBUG - 2021-12-01 02:56:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-01 02:56:06 --> Final output sent to browser
DEBUG - 2021-12-01 02:56:06 --> Total execution time: 0.1693
INFO - 2021-12-01 02:56:19 --> Config Class Initialized
INFO - 2021-12-01 02:56:19 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:56:19 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:56:19 --> Utf8 Class Initialized
INFO - 2021-12-01 02:56:19 --> URI Class Initialized
INFO - 2021-12-01 02:56:19 --> Router Class Initialized
INFO - 2021-12-01 02:56:19 --> Output Class Initialized
INFO - 2021-12-01 02:56:19 --> Security Class Initialized
DEBUG - 2021-12-01 02:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:56:19 --> Input Class Initialized
INFO - 2021-12-01 02:56:19 --> Language Class Initialized
INFO - 2021-12-01 02:56:19 --> Language Class Initialized
INFO - 2021-12-01 02:56:19 --> Config Class Initialized
INFO - 2021-12-01 02:56:19 --> Loader Class Initialized
INFO - 2021-12-01 02:56:19 --> Helper loaded: url_helper
INFO - 2021-12-01 02:56:19 --> Helper loaded: file_helper
INFO - 2021-12-01 02:56:19 --> Helper loaded: form_helper
INFO - 2021-12-01 02:56:19 --> Helper loaded: my_helper
INFO - 2021-12-01 02:56:19 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:56:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:56:19 --> Controller Class Initialized
DEBUG - 2021-12-01 02:56:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-01 02:56:19 --> Final output sent to browser
DEBUG - 2021-12-01 02:56:19 --> Total execution time: 0.1364
INFO - 2021-12-01 02:56:25 --> Config Class Initialized
INFO - 2021-12-01 02:56:25 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:56:25 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:56:25 --> Utf8 Class Initialized
INFO - 2021-12-01 02:56:25 --> URI Class Initialized
INFO - 2021-12-01 02:56:25 --> Router Class Initialized
INFO - 2021-12-01 02:56:25 --> Output Class Initialized
INFO - 2021-12-01 02:56:25 --> Security Class Initialized
DEBUG - 2021-12-01 02:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:56:25 --> Input Class Initialized
INFO - 2021-12-01 02:56:25 --> Language Class Initialized
INFO - 2021-12-01 02:56:25 --> Language Class Initialized
INFO - 2021-12-01 02:56:25 --> Config Class Initialized
INFO - 2021-12-01 02:56:25 --> Loader Class Initialized
INFO - 2021-12-01 02:56:25 --> Helper loaded: url_helper
INFO - 2021-12-01 02:56:25 --> Helper loaded: file_helper
INFO - 2021-12-01 02:56:25 --> Helper loaded: form_helper
INFO - 2021-12-01 02:56:25 --> Helper loaded: my_helper
INFO - 2021-12-01 02:56:25 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:56:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:56:25 --> Controller Class Initialized
DEBUG - 2021-12-01 02:56:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-01 02:56:25 --> Final output sent to browser
DEBUG - 2021-12-01 02:56:25 --> Total execution time: 0.1623
INFO - 2021-12-01 02:56:27 --> Config Class Initialized
INFO - 2021-12-01 02:56:27 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:56:27 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:56:27 --> Utf8 Class Initialized
INFO - 2021-12-01 02:56:27 --> URI Class Initialized
INFO - 2021-12-01 02:56:27 --> Router Class Initialized
INFO - 2021-12-01 02:56:27 --> Output Class Initialized
INFO - 2021-12-01 02:56:27 --> Security Class Initialized
DEBUG - 2021-12-01 02:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:56:27 --> Input Class Initialized
INFO - 2021-12-01 02:56:27 --> Language Class Initialized
INFO - 2021-12-01 02:56:27 --> Language Class Initialized
INFO - 2021-12-01 02:56:27 --> Config Class Initialized
INFO - 2021-12-01 02:56:27 --> Loader Class Initialized
INFO - 2021-12-01 02:56:27 --> Helper loaded: url_helper
INFO - 2021-12-01 02:56:27 --> Helper loaded: file_helper
INFO - 2021-12-01 02:56:27 --> Helper loaded: form_helper
INFO - 2021-12-01 02:56:28 --> Helper loaded: my_helper
INFO - 2021-12-01 02:56:28 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:56:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:56:28 --> Controller Class Initialized
DEBUG - 2021-12-01 02:56:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-01 02:56:28 --> Final output sent to browser
DEBUG - 2021-12-01 02:56:28 --> Total execution time: 0.1926
INFO - 2021-12-01 02:56:30 --> Config Class Initialized
INFO - 2021-12-01 02:56:30 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:56:30 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:56:30 --> Utf8 Class Initialized
INFO - 2021-12-01 02:56:30 --> URI Class Initialized
INFO - 2021-12-01 02:56:30 --> Router Class Initialized
INFO - 2021-12-01 02:56:30 --> Output Class Initialized
INFO - 2021-12-01 02:56:30 --> Security Class Initialized
DEBUG - 2021-12-01 02:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:56:30 --> Input Class Initialized
INFO - 2021-12-01 02:56:30 --> Language Class Initialized
INFO - 2021-12-01 02:56:30 --> Language Class Initialized
INFO - 2021-12-01 02:56:30 --> Config Class Initialized
INFO - 2021-12-01 02:56:30 --> Loader Class Initialized
INFO - 2021-12-01 02:56:30 --> Helper loaded: url_helper
INFO - 2021-12-01 02:56:30 --> Helper loaded: file_helper
INFO - 2021-12-01 02:56:30 --> Helper loaded: form_helper
INFO - 2021-12-01 02:56:30 --> Helper loaded: my_helper
INFO - 2021-12-01 02:56:30 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:56:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:56:30 --> Controller Class Initialized
DEBUG - 2021-12-01 02:56:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-01 02:56:30 --> Final output sent to browser
DEBUG - 2021-12-01 02:56:30 --> Total execution time: 0.1646
INFO - 2021-12-01 02:56:32 --> Config Class Initialized
INFO - 2021-12-01 02:56:32 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:56:32 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:56:32 --> Utf8 Class Initialized
INFO - 2021-12-01 02:56:32 --> URI Class Initialized
INFO - 2021-12-01 02:56:32 --> Router Class Initialized
INFO - 2021-12-01 02:56:32 --> Output Class Initialized
INFO - 2021-12-01 02:56:32 --> Security Class Initialized
DEBUG - 2021-12-01 02:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:56:32 --> Input Class Initialized
INFO - 2021-12-01 02:56:32 --> Language Class Initialized
INFO - 2021-12-01 02:56:32 --> Language Class Initialized
INFO - 2021-12-01 02:56:32 --> Config Class Initialized
INFO - 2021-12-01 02:56:32 --> Loader Class Initialized
INFO - 2021-12-01 02:56:32 --> Helper loaded: url_helper
INFO - 2021-12-01 02:56:32 --> Helper loaded: file_helper
INFO - 2021-12-01 02:56:32 --> Helper loaded: form_helper
INFO - 2021-12-01 02:56:32 --> Helper loaded: my_helper
INFO - 2021-12-01 02:56:32 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:56:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:56:32 --> Controller Class Initialized
DEBUG - 2021-12-01 02:56:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-01 02:56:32 --> Final output sent to browser
DEBUG - 2021-12-01 02:56:32 --> Total execution time: 0.1517
INFO - 2021-12-01 02:56:34 --> Config Class Initialized
INFO - 2021-12-01 02:56:34 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:56:34 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:56:34 --> Utf8 Class Initialized
INFO - 2021-12-01 02:56:34 --> URI Class Initialized
INFO - 2021-12-01 02:56:34 --> Router Class Initialized
INFO - 2021-12-01 02:56:34 --> Output Class Initialized
INFO - 2021-12-01 02:56:34 --> Security Class Initialized
DEBUG - 2021-12-01 02:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:56:34 --> Input Class Initialized
INFO - 2021-12-01 02:56:34 --> Language Class Initialized
INFO - 2021-12-01 02:56:34 --> Language Class Initialized
INFO - 2021-12-01 02:56:34 --> Config Class Initialized
INFO - 2021-12-01 02:56:34 --> Loader Class Initialized
INFO - 2021-12-01 02:56:34 --> Helper loaded: url_helper
INFO - 2021-12-01 02:56:34 --> Helper loaded: file_helper
INFO - 2021-12-01 02:56:34 --> Helper loaded: form_helper
INFO - 2021-12-01 02:56:34 --> Helper loaded: my_helper
INFO - 2021-12-01 02:56:34 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:56:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:56:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:56:34 --> Controller Class Initialized
DEBUG - 2021-12-01 02:56:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-01 02:56:34 --> Final output sent to browser
DEBUG - 2021-12-01 02:56:34 --> Total execution time: 0.1289
INFO - 2021-12-01 02:56:35 --> Config Class Initialized
INFO - 2021-12-01 02:56:35 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:56:35 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:56:35 --> Utf8 Class Initialized
INFO - 2021-12-01 02:56:35 --> URI Class Initialized
INFO - 2021-12-01 02:56:35 --> Router Class Initialized
INFO - 2021-12-01 02:56:35 --> Output Class Initialized
INFO - 2021-12-01 02:56:35 --> Security Class Initialized
DEBUG - 2021-12-01 02:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:56:35 --> Input Class Initialized
INFO - 2021-12-01 02:56:35 --> Language Class Initialized
INFO - 2021-12-01 02:56:35 --> Language Class Initialized
INFO - 2021-12-01 02:56:35 --> Config Class Initialized
INFO - 2021-12-01 02:56:35 --> Loader Class Initialized
INFO - 2021-12-01 02:56:35 --> Helper loaded: url_helper
INFO - 2021-12-01 02:56:35 --> Helper loaded: file_helper
INFO - 2021-12-01 02:56:35 --> Helper loaded: form_helper
INFO - 2021-12-01 02:56:35 --> Helper loaded: my_helper
INFO - 2021-12-01 02:56:35 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:56:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:56:35 --> Controller Class Initialized
DEBUG - 2021-12-01 02:56:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-01 02:56:35 --> Final output sent to browser
DEBUG - 2021-12-01 02:56:35 --> Total execution time: 0.1408
INFO - 2021-12-01 02:56:37 --> Config Class Initialized
INFO - 2021-12-01 02:56:37 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:56:37 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:56:37 --> Utf8 Class Initialized
INFO - 2021-12-01 02:56:37 --> URI Class Initialized
INFO - 2021-12-01 02:56:37 --> Router Class Initialized
INFO - 2021-12-01 02:56:37 --> Output Class Initialized
INFO - 2021-12-01 02:56:37 --> Security Class Initialized
DEBUG - 2021-12-01 02:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:56:37 --> Input Class Initialized
INFO - 2021-12-01 02:56:37 --> Language Class Initialized
INFO - 2021-12-01 02:56:37 --> Language Class Initialized
INFO - 2021-12-01 02:56:37 --> Config Class Initialized
INFO - 2021-12-01 02:56:37 --> Loader Class Initialized
INFO - 2021-12-01 02:56:37 --> Helper loaded: url_helper
INFO - 2021-12-01 02:56:37 --> Helper loaded: file_helper
INFO - 2021-12-01 02:56:37 --> Helper loaded: form_helper
INFO - 2021-12-01 02:56:37 --> Helper loaded: my_helper
INFO - 2021-12-01 02:56:37 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:56:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:56:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:56:37 --> Controller Class Initialized
DEBUG - 2021-12-01 02:56:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-01 02:56:37 --> Final output sent to browser
DEBUG - 2021-12-01 02:56:37 --> Total execution time: 0.1463
INFO - 2021-12-01 02:56:39 --> Config Class Initialized
INFO - 2021-12-01 02:56:39 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:56:39 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:56:39 --> Utf8 Class Initialized
INFO - 2021-12-01 02:56:39 --> URI Class Initialized
INFO - 2021-12-01 02:56:39 --> Router Class Initialized
INFO - 2021-12-01 02:56:39 --> Output Class Initialized
INFO - 2021-12-01 02:56:39 --> Security Class Initialized
DEBUG - 2021-12-01 02:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:56:39 --> Input Class Initialized
INFO - 2021-12-01 02:56:39 --> Language Class Initialized
INFO - 2021-12-01 02:56:39 --> Language Class Initialized
INFO - 2021-12-01 02:56:39 --> Config Class Initialized
INFO - 2021-12-01 02:56:39 --> Loader Class Initialized
INFO - 2021-12-01 02:56:39 --> Helper loaded: url_helper
INFO - 2021-12-01 02:56:39 --> Helper loaded: file_helper
INFO - 2021-12-01 02:56:39 --> Helper loaded: form_helper
INFO - 2021-12-01 02:56:39 --> Helper loaded: my_helper
INFO - 2021-12-01 02:56:39 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:56:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:56:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:56:39 --> Controller Class Initialized
DEBUG - 2021-12-01 02:56:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-01 02:56:39 --> Final output sent to browser
DEBUG - 2021-12-01 02:56:39 --> Total execution time: 0.1458
INFO - 2021-12-01 02:56:41 --> Config Class Initialized
INFO - 2021-12-01 02:56:41 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:56:41 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:56:41 --> Utf8 Class Initialized
INFO - 2021-12-01 02:56:41 --> URI Class Initialized
INFO - 2021-12-01 02:56:41 --> Router Class Initialized
INFO - 2021-12-01 02:56:41 --> Output Class Initialized
INFO - 2021-12-01 02:56:41 --> Security Class Initialized
DEBUG - 2021-12-01 02:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:56:41 --> Input Class Initialized
INFO - 2021-12-01 02:56:41 --> Language Class Initialized
INFO - 2021-12-01 02:56:41 --> Language Class Initialized
INFO - 2021-12-01 02:56:41 --> Config Class Initialized
INFO - 2021-12-01 02:56:41 --> Loader Class Initialized
INFO - 2021-12-01 02:56:41 --> Helper loaded: url_helper
INFO - 2021-12-01 02:56:41 --> Helper loaded: file_helper
INFO - 2021-12-01 02:56:41 --> Helper loaded: form_helper
INFO - 2021-12-01 02:56:41 --> Helper loaded: my_helper
INFO - 2021-12-01 02:56:41 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:56:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:56:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:56:41 --> Controller Class Initialized
DEBUG - 2021-12-01 02:56:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-01 02:56:41 --> Final output sent to browser
DEBUG - 2021-12-01 02:56:41 --> Total execution time: 0.1526
INFO - 2021-12-01 02:56:44 --> Config Class Initialized
INFO - 2021-12-01 02:56:44 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:56:44 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:56:44 --> Utf8 Class Initialized
INFO - 2021-12-01 02:56:44 --> URI Class Initialized
INFO - 2021-12-01 02:56:44 --> Router Class Initialized
INFO - 2021-12-01 02:56:44 --> Output Class Initialized
INFO - 2021-12-01 02:56:44 --> Security Class Initialized
DEBUG - 2021-12-01 02:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:56:44 --> Input Class Initialized
INFO - 2021-12-01 02:56:44 --> Language Class Initialized
INFO - 2021-12-01 02:56:44 --> Language Class Initialized
INFO - 2021-12-01 02:56:44 --> Config Class Initialized
INFO - 2021-12-01 02:56:44 --> Loader Class Initialized
INFO - 2021-12-01 02:56:44 --> Helper loaded: url_helper
INFO - 2021-12-01 02:56:44 --> Helper loaded: file_helper
INFO - 2021-12-01 02:56:44 --> Helper loaded: form_helper
INFO - 2021-12-01 02:56:44 --> Helper loaded: my_helper
INFO - 2021-12-01 02:56:44 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:56:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:56:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:56:44 --> Controller Class Initialized
DEBUG - 2021-12-01 02:56:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-01 02:56:44 --> Final output sent to browser
DEBUG - 2021-12-01 02:56:44 --> Total execution time: 0.1426
INFO - 2021-12-01 02:56:46 --> Config Class Initialized
INFO - 2021-12-01 02:56:46 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:56:46 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:56:46 --> Utf8 Class Initialized
INFO - 2021-12-01 02:56:46 --> URI Class Initialized
INFO - 2021-12-01 02:56:46 --> Router Class Initialized
INFO - 2021-12-01 02:56:46 --> Output Class Initialized
INFO - 2021-12-01 02:56:46 --> Security Class Initialized
DEBUG - 2021-12-01 02:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:56:46 --> Input Class Initialized
INFO - 2021-12-01 02:56:46 --> Language Class Initialized
INFO - 2021-12-01 02:56:46 --> Language Class Initialized
INFO - 2021-12-01 02:56:46 --> Config Class Initialized
INFO - 2021-12-01 02:56:46 --> Loader Class Initialized
INFO - 2021-12-01 02:56:46 --> Helper loaded: url_helper
INFO - 2021-12-01 02:56:46 --> Helper loaded: file_helper
INFO - 2021-12-01 02:56:46 --> Helper loaded: form_helper
INFO - 2021-12-01 02:56:46 --> Helper loaded: my_helper
INFO - 2021-12-01 02:56:46 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:56:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:56:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:56:46 --> Controller Class Initialized
DEBUG - 2021-12-01 02:56:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-01 02:56:46 --> Final output sent to browser
DEBUG - 2021-12-01 02:56:46 --> Total execution time: 0.1170
INFO - 2021-12-01 02:56:48 --> Config Class Initialized
INFO - 2021-12-01 02:56:48 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:56:48 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:56:48 --> Utf8 Class Initialized
INFO - 2021-12-01 02:56:48 --> URI Class Initialized
INFO - 2021-12-01 02:56:48 --> Router Class Initialized
INFO - 2021-12-01 02:56:48 --> Output Class Initialized
INFO - 2021-12-01 02:56:48 --> Security Class Initialized
DEBUG - 2021-12-01 02:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:56:48 --> Input Class Initialized
INFO - 2021-12-01 02:56:48 --> Language Class Initialized
INFO - 2021-12-01 02:56:48 --> Language Class Initialized
INFO - 2021-12-01 02:56:48 --> Config Class Initialized
INFO - 2021-12-01 02:56:48 --> Loader Class Initialized
INFO - 2021-12-01 02:56:48 --> Helper loaded: url_helper
INFO - 2021-12-01 02:56:48 --> Helper loaded: file_helper
INFO - 2021-12-01 02:56:48 --> Helper loaded: form_helper
INFO - 2021-12-01 02:56:48 --> Helper loaded: my_helper
INFO - 2021-12-01 02:56:48 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:56:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:56:48 --> Controller Class Initialized
DEBUG - 2021-12-01 02:56:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-01 02:56:48 --> Final output sent to browser
DEBUG - 2021-12-01 02:56:48 --> Total execution time: 0.1292
INFO - 2021-12-01 02:56:50 --> Config Class Initialized
INFO - 2021-12-01 02:56:50 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:56:50 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:56:50 --> Utf8 Class Initialized
INFO - 2021-12-01 02:56:50 --> URI Class Initialized
INFO - 2021-12-01 02:56:50 --> Router Class Initialized
INFO - 2021-12-01 02:56:50 --> Output Class Initialized
INFO - 2021-12-01 02:56:50 --> Security Class Initialized
DEBUG - 2021-12-01 02:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:56:50 --> Input Class Initialized
INFO - 2021-12-01 02:56:50 --> Language Class Initialized
INFO - 2021-12-01 02:56:50 --> Language Class Initialized
INFO - 2021-12-01 02:56:50 --> Config Class Initialized
INFO - 2021-12-01 02:56:50 --> Loader Class Initialized
INFO - 2021-12-01 02:56:50 --> Helper loaded: url_helper
INFO - 2021-12-01 02:56:50 --> Helper loaded: file_helper
INFO - 2021-12-01 02:56:50 --> Helper loaded: form_helper
INFO - 2021-12-01 02:56:50 --> Helper loaded: my_helper
INFO - 2021-12-01 02:56:50 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:56:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:56:50 --> Controller Class Initialized
DEBUG - 2021-12-01 02:56:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-01 02:56:50 --> Final output sent to browser
DEBUG - 2021-12-01 02:56:50 --> Total execution time: 0.1489
INFO - 2021-12-01 02:56:52 --> Config Class Initialized
INFO - 2021-12-01 02:56:52 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:56:52 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:56:52 --> Utf8 Class Initialized
INFO - 2021-12-01 02:56:52 --> URI Class Initialized
INFO - 2021-12-01 02:56:52 --> Router Class Initialized
INFO - 2021-12-01 02:56:52 --> Output Class Initialized
INFO - 2021-12-01 02:56:52 --> Security Class Initialized
DEBUG - 2021-12-01 02:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:56:52 --> Input Class Initialized
INFO - 2021-12-01 02:56:52 --> Language Class Initialized
INFO - 2021-12-01 02:56:52 --> Language Class Initialized
INFO - 2021-12-01 02:56:52 --> Config Class Initialized
INFO - 2021-12-01 02:56:52 --> Loader Class Initialized
INFO - 2021-12-01 02:56:52 --> Helper loaded: url_helper
INFO - 2021-12-01 02:56:52 --> Helper loaded: file_helper
INFO - 2021-12-01 02:56:52 --> Helper loaded: form_helper
INFO - 2021-12-01 02:56:52 --> Helper loaded: my_helper
INFO - 2021-12-01 02:56:52 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:56:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:56:52 --> Controller Class Initialized
DEBUG - 2021-12-01 02:56:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-01 02:56:52 --> Final output sent to browser
DEBUG - 2021-12-01 02:56:52 --> Total execution time: 0.1271
INFO - 2021-12-01 02:56:54 --> Config Class Initialized
INFO - 2021-12-01 02:56:54 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:56:54 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:56:54 --> Utf8 Class Initialized
INFO - 2021-12-01 02:56:54 --> URI Class Initialized
INFO - 2021-12-01 02:56:54 --> Router Class Initialized
INFO - 2021-12-01 02:56:54 --> Output Class Initialized
INFO - 2021-12-01 02:56:54 --> Security Class Initialized
DEBUG - 2021-12-01 02:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:56:54 --> Input Class Initialized
INFO - 2021-12-01 02:56:54 --> Language Class Initialized
INFO - 2021-12-01 02:56:54 --> Language Class Initialized
INFO - 2021-12-01 02:56:54 --> Config Class Initialized
INFO - 2021-12-01 02:56:54 --> Loader Class Initialized
INFO - 2021-12-01 02:56:54 --> Helper loaded: url_helper
INFO - 2021-12-01 02:56:54 --> Helper loaded: file_helper
INFO - 2021-12-01 02:56:54 --> Helper loaded: form_helper
INFO - 2021-12-01 02:56:54 --> Helper loaded: my_helper
INFO - 2021-12-01 02:56:54 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:56:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:56:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:56:54 --> Controller Class Initialized
DEBUG - 2021-12-01 02:56:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-01 02:56:54 --> Final output sent to browser
DEBUG - 2021-12-01 02:56:54 --> Total execution time: 0.1342
INFO - 2021-12-01 02:56:56 --> Config Class Initialized
INFO - 2021-12-01 02:56:56 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:56:56 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:56:56 --> Utf8 Class Initialized
INFO - 2021-12-01 02:56:56 --> URI Class Initialized
INFO - 2021-12-01 02:56:56 --> Router Class Initialized
INFO - 2021-12-01 02:56:56 --> Output Class Initialized
INFO - 2021-12-01 02:56:56 --> Security Class Initialized
DEBUG - 2021-12-01 02:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:56:56 --> Input Class Initialized
INFO - 2021-12-01 02:56:56 --> Language Class Initialized
INFO - 2021-12-01 02:56:56 --> Language Class Initialized
INFO - 2021-12-01 02:56:56 --> Config Class Initialized
INFO - 2021-12-01 02:56:56 --> Loader Class Initialized
INFO - 2021-12-01 02:56:56 --> Helper loaded: url_helper
INFO - 2021-12-01 02:56:56 --> Helper loaded: file_helper
INFO - 2021-12-01 02:56:56 --> Helper loaded: form_helper
INFO - 2021-12-01 02:56:56 --> Helper loaded: my_helper
INFO - 2021-12-01 02:56:56 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:56:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:56:56 --> Controller Class Initialized
DEBUG - 2021-12-01 02:56:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-01 02:56:56 --> Final output sent to browser
DEBUG - 2021-12-01 02:56:56 --> Total execution time: 0.1449
INFO - 2021-12-01 02:56:59 --> Config Class Initialized
INFO - 2021-12-01 02:56:59 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:56:59 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:56:59 --> Utf8 Class Initialized
INFO - 2021-12-01 02:56:59 --> URI Class Initialized
INFO - 2021-12-01 02:56:59 --> Router Class Initialized
INFO - 2021-12-01 02:56:59 --> Output Class Initialized
INFO - 2021-12-01 02:56:59 --> Security Class Initialized
DEBUG - 2021-12-01 02:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:56:59 --> Input Class Initialized
INFO - 2021-12-01 02:56:59 --> Language Class Initialized
INFO - 2021-12-01 02:56:59 --> Language Class Initialized
INFO - 2021-12-01 02:56:59 --> Config Class Initialized
INFO - 2021-12-01 02:56:59 --> Loader Class Initialized
INFO - 2021-12-01 02:56:59 --> Helper loaded: url_helper
INFO - 2021-12-01 02:56:59 --> Helper loaded: file_helper
INFO - 2021-12-01 02:56:59 --> Helper loaded: form_helper
INFO - 2021-12-01 02:56:59 --> Helper loaded: my_helper
INFO - 2021-12-01 02:56:59 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:56:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:56:59 --> Controller Class Initialized
DEBUG - 2021-12-01 02:56:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-01 02:56:59 --> Final output sent to browser
DEBUG - 2021-12-01 02:56:59 --> Total execution time: 0.1518
INFO - 2021-12-01 02:57:01 --> Config Class Initialized
INFO - 2021-12-01 02:57:01 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:57:01 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:57:01 --> Utf8 Class Initialized
INFO - 2021-12-01 02:57:01 --> URI Class Initialized
INFO - 2021-12-01 02:57:01 --> Router Class Initialized
INFO - 2021-12-01 02:57:01 --> Output Class Initialized
INFO - 2021-12-01 02:57:01 --> Security Class Initialized
DEBUG - 2021-12-01 02:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:57:01 --> Input Class Initialized
INFO - 2021-12-01 02:57:01 --> Language Class Initialized
INFO - 2021-12-01 02:57:01 --> Language Class Initialized
INFO - 2021-12-01 02:57:01 --> Config Class Initialized
INFO - 2021-12-01 02:57:01 --> Loader Class Initialized
INFO - 2021-12-01 02:57:01 --> Helper loaded: url_helper
INFO - 2021-12-01 02:57:01 --> Helper loaded: file_helper
INFO - 2021-12-01 02:57:01 --> Helper loaded: form_helper
INFO - 2021-12-01 02:57:01 --> Helper loaded: my_helper
INFO - 2021-12-01 02:57:01 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:57:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:57:01 --> Controller Class Initialized
DEBUG - 2021-12-01 02:57:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-01 02:57:01 --> Final output sent to browser
DEBUG - 2021-12-01 02:57:01 --> Total execution time: 0.1675
INFO - 2021-12-01 02:57:03 --> Config Class Initialized
INFO - 2021-12-01 02:57:03 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:57:03 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:57:03 --> Utf8 Class Initialized
INFO - 2021-12-01 02:57:03 --> URI Class Initialized
INFO - 2021-12-01 02:57:03 --> Router Class Initialized
INFO - 2021-12-01 02:57:03 --> Output Class Initialized
INFO - 2021-12-01 02:57:03 --> Security Class Initialized
DEBUG - 2021-12-01 02:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:57:03 --> Input Class Initialized
INFO - 2021-12-01 02:57:03 --> Language Class Initialized
INFO - 2021-12-01 02:57:03 --> Language Class Initialized
INFO - 2021-12-01 02:57:03 --> Config Class Initialized
INFO - 2021-12-01 02:57:03 --> Loader Class Initialized
INFO - 2021-12-01 02:57:03 --> Helper loaded: url_helper
INFO - 2021-12-01 02:57:03 --> Helper loaded: file_helper
INFO - 2021-12-01 02:57:03 --> Helper loaded: form_helper
INFO - 2021-12-01 02:57:03 --> Helper loaded: my_helper
INFO - 2021-12-01 02:57:03 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:57:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:57:03 --> Controller Class Initialized
DEBUG - 2021-12-01 02:57:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-01 02:57:03 --> Final output sent to browser
DEBUG - 2021-12-01 02:57:03 --> Total execution time: 0.1262
INFO - 2021-12-01 02:57:05 --> Config Class Initialized
INFO - 2021-12-01 02:57:05 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:57:05 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:57:05 --> Utf8 Class Initialized
INFO - 2021-12-01 02:57:05 --> URI Class Initialized
INFO - 2021-12-01 02:57:05 --> Router Class Initialized
INFO - 2021-12-01 02:57:05 --> Output Class Initialized
INFO - 2021-12-01 02:57:05 --> Security Class Initialized
DEBUG - 2021-12-01 02:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:57:05 --> Input Class Initialized
INFO - 2021-12-01 02:57:05 --> Language Class Initialized
INFO - 2021-12-01 02:57:05 --> Language Class Initialized
INFO - 2021-12-01 02:57:05 --> Config Class Initialized
INFO - 2021-12-01 02:57:05 --> Loader Class Initialized
INFO - 2021-12-01 02:57:05 --> Helper loaded: url_helper
INFO - 2021-12-01 02:57:05 --> Helper loaded: file_helper
INFO - 2021-12-01 02:57:05 --> Helper loaded: form_helper
INFO - 2021-12-01 02:57:05 --> Helper loaded: my_helper
INFO - 2021-12-01 02:57:05 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:57:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:57:05 --> Controller Class Initialized
DEBUG - 2021-12-01 02:57:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-01 02:57:05 --> Final output sent to browser
DEBUG - 2021-12-01 02:57:05 --> Total execution time: 0.1418
INFO - 2021-12-01 02:57:07 --> Config Class Initialized
INFO - 2021-12-01 02:57:07 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:57:07 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:57:07 --> Utf8 Class Initialized
INFO - 2021-12-01 02:57:07 --> URI Class Initialized
INFO - 2021-12-01 02:57:07 --> Router Class Initialized
INFO - 2021-12-01 02:57:07 --> Output Class Initialized
INFO - 2021-12-01 02:57:07 --> Security Class Initialized
DEBUG - 2021-12-01 02:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:57:07 --> Input Class Initialized
INFO - 2021-12-01 02:57:07 --> Language Class Initialized
INFO - 2021-12-01 02:57:07 --> Language Class Initialized
INFO - 2021-12-01 02:57:07 --> Config Class Initialized
INFO - 2021-12-01 02:57:07 --> Loader Class Initialized
INFO - 2021-12-01 02:57:07 --> Helper loaded: url_helper
INFO - 2021-12-01 02:57:07 --> Helper loaded: file_helper
INFO - 2021-12-01 02:57:07 --> Helper loaded: form_helper
INFO - 2021-12-01 02:57:07 --> Helper loaded: my_helper
INFO - 2021-12-01 02:57:07 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:57:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:57:08 --> Controller Class Initialized
DEBUG - 2021-12-01 02:57:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-01 02:57:08 --> Final output sent to browser
DEBUG - 2021-12-01 02:57:08 --> Total execution time: 0.1489
INFO - 2021-12-01 02:57:09 --> Config Class Initialized
INFO - 2021-12-01 02:57:09 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:57:09 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:57:09 --> Utf8 Class Initialized
INFO - 2021-12-01 02:57:09 --> URI Class Initialized
INFO - 2021-12-01 02:57:09 --> Router Class Initialized
INFO - 2021-12-01 02:57:09 --> Output Class Initialized
INFO - 2021-12-01 02:57:09 --> Security Class Initialized
DEBUG - 2021-12-01 02:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:57:09 --> Input Class Initialized
INFO - 2021-12-01 02:57:09 --> Language Class Initialized
INFO - 2021-12-01 02:57:09 --> Language Class Initialized
INFO - 2021-12-01 02:57:09 --> Config Class Initialized
INFO - 2021-12-01 02:57:09 --> Loader Class Initialized
INFO - 2021-12-01 02:57:09 --> Helper loaded: url_helper
INFO - 2021-12-01 02:57:09 --> Helper loaded: file_helper
INFO - 2021-12-01 02:57:09 --> Helper loaded: form_helper
INFO - 2021-12-01 02:57:09 --> Helper loaded: my_helper
INFO - 2021-12-01 02:57:09 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:57:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:57:09 --> Controller Class Initialized
DEBUG - 2021-12-01 02:57:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-01 02:57:09 --> Final output sent to browser
DEBUG - 2021-12-01 02:57:09 --> Total execution time: 0.1412
INFO - 2021-12-01 02:57:12 --> Config Class Initialized
INFO - 2021-12-01 02:57:12 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:57:12 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:57:12 --> Utf8 Class Initialized
INFO - 2021-12-01 02:57:12 --> URI Class Initialized
INFO - 2021-12-01 02:57:12 --> Router Class Initialized
INFO - 2021-12-01 02:57:12 --> Output Class Initialized
INFO - 2021-12-01 02:57:12 --> Security Class Initialized
DEBUG - 2021-12-01 02:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:57:12 --> Input Class Initialized
INFO - 2021-12-01 02:57:12 --> Language Class Initialized
INFO - 2021-12-01 02:57:12 --> Language Class Initialized
INFO - 2021-12-01 02:57:12 --> Config Class Initialized
INFO - 2021-12-01 02:57:12 --> Loader Class Initialized
INFO - 2021-12-01 02:57:12 --> Helper loaded: url_helper
INFO - 2021-12-01 02:57:12 --> Helper loaded: file_helper
INFO - 2021-12-01 02:57:12 --> Helper loaded: form_helper
INFO - 2021-12-01 02:57:12 --> Helper loaded: my_helper
INFO - 2021-12-01 02:57:12 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:57:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:57:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:57:12 --> Controller Class Initialized
DEBUG - 2021-12-01 02:57:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-01 02:57:12 --> Final output sent to browser
DEBUG - 2021-12-01 02:57:12 --> Total execution time: 0.1460
INFO - 2021-12-01 02:57:15 --> Config Class Initialized
INFO - 2021-12-01 02:57:15 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:57:15 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:57:15 --> Utf8 Class Initialized
INFO - 2021-12-01 02:57:15 --> URI Class Initialized
INFO - 2021-12-01 02:57:15 --> Router Class Initialized
INFO - 2021-12-01 02:57:15 --> Output Class Initialized
INFO - 2021-12-01 02:57:15 --> Security Class Initialized
DEBUG - 2021-12-01 02:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:57:15 --> Input Class Initialized
INFO - 2021-12-01 02:57:15 --> Language Class Initialized
INFO - 2021-12-01 02:57:15 --> Language Class Initialized
INFO - 2021-12-01 02:57:15 --> Config Class Initialized
INFO - 2021-12-01 02:57:15 --> Loader Class Initialized
INFO - 2021-12-01 02:57:15 --> Helper loaded: url_helper
INFO - 2021-12-01 02:57:15 --> Helper loaded: file_helper
INFO - 2021-12-01 02:57:15 --> Helper loaded: form_helper
INFO - 2021-12-01 02:57:15 --> Helper loaded: my_helper
INFO - 2021-12-01 02:57:15 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:57:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:57:15 --> Controller Class Initialized
DEBUG - 2021-12-01 02:57:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-01 02:57:15 --> Final output sent to browser
DEBUG - 2021-12-01 02:57:15 --> Total execution time: 0.1138
INFO - 2021-12-01 02:57:17 --> Config Class Initialized
INFO - 2021-12-01 02:57:17 --> Hooks Class Initialized
DEBUG - 2021-12-01 02:57:17 --> UTF-8 Support Enabled
INFO - 2021-12-01 02:57:17 --> Utf8 Class Initialized
INFO - 2021-12-01 02:57:17 --> URI Class Initialized
INFO - 2021-12-01 02:57:17 --> Router Class Initialized
INFO - 2021-12-01 02:57:17 --> Output Class Initialized
INFO - 2021-12-01 02:57:17 --> Security Class Initialized
DEBUG - 2021-12-01 02:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 02:57:17 --> Input Class Initialized
INFO - 2021-12-01 02:57:17 --> Language Class Initialized
INFO - 2021-12-01 02:57:17 --> Language Class Initialized
INFO - 2021-12-01 02:57:17 --> Config Class Initialized
INFO - 2021-12-01 02:57:17 --> Loader Class Initialized
INFO - 2021-12-01 02:57:17 --> Helper loaded: url_helper
INFO - 2021-12-01 02:57:17 --> Helper loaded: file_helper
INFO - 2021-12-01 02:57:17 --> Helper loaded: form_helper
INFO - 2021-12-01 02:57:17 --> Helper loaded: my_helper
INFO - 2021-12-01 02:57:17 --> Database Driver Class Initialized
DEBUG - 2021-12-01 02:57:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 02:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 02:57:17 --> Controller Class Initialized
DEBUG - 2021-12-01 02:57:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-01 02:57:17 --> Final output sent to browser
DEBUG - 2021-12-01 02:57:17 --> Total execution time: 0.1131
INFO - 2021-12-01 03:01:25 --> Config Class Initialized
INFO - 2021-12-01 03:01:25 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:01:25 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:01:25 --> Utf8 Class Initialized
INFO - 2021-12-01 03:01:25 --> URI Class Initialized
INFO - 2021-12-01 03:01:25 --> Router Class Initialized
INFO - 2021-12-01 03:01:25 --> Output Class Initialized
INFO - 2021-12-01 03:01:25 --> Security Class Initialized
DEBUG - 2021-12-01 03:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:01:25 --> Input Class Initialized
INFO - 2021-12-01 03:01:25 --> Language Class Initialized
INFO - 2021-12-01 03:01:25 --> Language Class Initialized
INFO - 2021-12-01 03:01:25 --> Config Class Initialized
INFO - 2021-12-01 03:01:25 --> Loader Class Initialized
INFO - 2021-12-01 03:01:25 --> Helper loaded: url_helper
INFO - 2021-12-01 03:01:25 --> Helper loaded: file_helper
INFO - 2021-12-01 03:01:25 --> Helper loaded: form_helper
INFO - 2021-12-01 03:01:25 --> Helper loaded: my_helper
INFO - 2021-12-01 03:01:25 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:01:25 --> Controller Class Initialized
INFO - 2021-12-01 03:01:25 --> Helper loaded: cookie_helper
INFO - 2021-12-01 03:01:25 --> Config Class Initialized
INFO - 2021-12-01 03:01:25 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:01:25 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:01:25 --> Utf8 Class Initialized
INFO - 2021-12-01 03:01:25 --> URI Class Initialized
INFO - 2021-12-01 03:01:25 --> Router Class Initialized
INFO - 2021-12-01 03:01:25 --> Output Class Initialized
INFO - 2021-12-01 03:01:25 --> Security Class Initialized
DEBUG - 2021-12-01 03:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:01:25 --> Input Class Initialized
INFO - 2021-12-01 03:01:25 --> Language Class Initialized
INFO - 2021-12-01 03:01:25 --> Language Class Initialized
INFO - 2021-12-01 03:01:25 --> Config Class Initialized
INFO - 2021-12-01 03:01:25 --> Loader Class Initialized
INFO - 2021-12-01 03:01:25 --> Helper loaded: url_helper
INFO - 2021-12-01 03:01:25 --> Helper loaded: file_helper
INFO - 2021-12-01 03:01:25 --> Helper loaded: form_helper
INFO - 2021-12-01 03:01:25 --> Helper loaded: my_helper
INFO - 2021-12-01 03:01:25 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:01:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:01:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:01:26 --> Controller Class Initialized
DEBUG - 2021-12-01 03:01:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-01 03:01:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 03:01:26 --> Final output sent to browser
DEBUG - 2021-12-01 03:01:26 --> Total execution time: 0.0703
INFO - 2021-12-01 03:01:35 --> Config Class Initialized
INFO - 2021-12-01 03:01:35 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:01:35 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:01:35 --> Utf8 Class Initialized
INFO - 2021-12-01 03:01:35 --> URI Class Initialized
INFO - 2021-12-01 03:01:35 --> Router Class Initialized
INFO - 2021-12-01 03:01:35 --> Output Class Initialized
INFO - 2021-12-01 03:01:35 --> Security Class Initialized
DEBUG - 2021-12-01 03:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:01:35 --> Input Class Initialized
INFO - 2021-12-01 03:01:35 --> Language Class Initialized
INFO - 2021-12-01 03:01:35 --> Language Class Initialized
INFO - 2021-12-01 03:01:35 --> Config Class Initialized
INFO - 2021-12-01 03:01:35 --> Loader Class Initialized
INFO - 2021-12-01 03:01:35 --> Helper loaded: url_helper
INFO - 2021-12-01 03:01:35 --> Helper loaded: file_helper
INFO - 2021-12-01 03:01:35 --> Helper loaded: form_helper
INFO - 2021-12-01 03:01:35 --> Helper loaded: my_helper
INFO - 2021-12-01 03:01:35 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:01:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:01:35 --> Controller Class Initialized
INFO - 2021-12-01 03:01:35 --> Helper loaded: cookie_helper
INFO - 2021-12-01 03:01:35 --> Final output sent to browser
DEBUG - 2021-12-01 03:01:35 --> Total execution time: 0.0842
INFO - 2021-12-01 03:01:36 --> Config Class Initialized
INFO - 2021-12-01 03:01:36 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:01:36 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:01:36 --> Utf8 Class Initialized
INFO - 2021-12-01 03:01:36 --> URI Class Initialized
INFO - 2021-12-01 03:01:36 --> Router Class Initialized
INFO - 2021-12-01 03:01:36 --> Output Class Initialized
INFO - 2021-12-01 03:01:36 --> Security Class Initialized
DEBUG - 2021-12-01 03:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:01:36 --> Input Class Initialized
INFO - 2021-12-01 03:01:36 --> Language Class Initialized
INFO - 2021-12-01 03:01:36 --> Language Class Initialized
INFO - 2021-12-01 03:01:36 --> Config Class Initialized
INFO - 2021-12-01 03:01:36 --> Loader Class Initialized
INFO - 2021-12-01 03:01:36 --> Helper loaded: url_helper
INFO - 2021-12-01 03:01:36 --> Helper loaded: file_helper
INFO - 2021-12-01 03:01:36 --> Helper loaded: form_helper
INFO - 2021-12-01 03:01:36 --> Helper loaded: my_helper
INFO - 2021-12-01 03:01:36 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:01:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:01:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:01:36 --> Controller Class Initialized
DEBUG - 2021-12-01 03:01:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-01 03:01:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 03:01:36 --> Final output sent to browser
DEBUG - 2021-12-01 03:01:36 --> Total execution time: 0.2478
INFO - 2021-12-01 03:01:46 --> Config Class Initialized
INFO - 2021-12-01 03:01:46 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:01:46 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:01:46 --> Utf8 Class Initialized
INFO - 2021-12-01 03:01:46 --> URI Class Initialized
INFO - 2021-12-01 03:01:46 --> Router Class Initialized
INFO - 2021-12-01 03:01:46 --> Output Class Initialized
INFO - 2021-12-01 03:01:46 --> Security Class Initialized
DEBUG - 2021-12-01 03:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:01:46 --> Input Class Initialized
INFO - 2021-12-01 03:01:46 --> Language Class Initialized
INFO - 2021-12-01 03:01:46 --> Language Class Initialized
INFO - 2021-12-01 03:01:46 --> Config Class Initialized
INFO - 2021-12-01 03:01:46 --> Loader Class Initialized
INFO - 2021-12-01 03:01:46 --> Helper loaded: url_helper
INFO - 2021-12-01 03:01:46 --> Helper loaded: file_helper
INFO - 2021-12-01 03:01:46 --> Helper loaded: form_helper
INFO - 2021-12-01 03:01:46 --> Helper loaded: my_helper
INFO - 2021-12-01 03:01:46 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:01:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:01:46 --> Controller Class Initialized
DEBUG - 2021-12-01 03:01:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-12-01 03:01:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 03:01:46 --> Final output sent to browser
DEBUG - 2021-12-01 03:01:46 --> Total execution time: 0.1035
INFO - 2021-12-01 03:01:47 --> Config Class Initialized
INFO - 2021-12-01 03:01:47 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:01:47 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:01:47 --> Utf8 Class Initialized
INFO - 2021-12-01 03:01:47 --> URI Class Initialized
INFO - 2021-12-01 03:01:47 --> Router Class Initialized
INFO - 2021-12-01 03:01:47 --> Output Class Initialized
INFO - 2021-12-01 03:01:47 --> Security Class Initialized
DEBUG - 2021-12-01 03:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:01:47 --> Input Class Initialized
INFO - 2021-12-01 03:01:47 --> Language Class Initialized
INFO - 2021-12-01 03:01:47 --> Language Class Initialized
INFO - 2021-12-01 03:01:47 --> Config Class Initialized
INFO - 2021-12-01 03:01:47 --> Loader Class Initialized
INFO - 2021-12-01 03:01:47 --> Helper loaded: url_helper
INFO - 2021-12-01 03:01:47 --> Helper loaded: file_helper
INFO - 2021-12-01 03:01:47 --> Helper loaded: form_helper
INFO - 2021-12-01 03:01:47 --> Helper loaded: my_helper
INFO - 2021-12-01 03:01:47 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:01:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:01:47 --> Controller Class Initialized
DEBUG - 2021-12-01 03:01:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_to.php
INFO - 2021-12-01 03:01:47 --> Final output sent to browser
DEBUG - 2021-12-01 03:01:47 --> Total execution time: 0.1656
INFO - 2021-12-01 03:02:12 --> Config Class Initialized
INFO - 2021-12-01 03:02:12 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:02:12 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:02:12 --> Utf8 Class Initialized
INFO - 2021-12-01 03:02:12 --> URI Class Initialized
INFO - 2021-12-01 03:02:12 --> Router Class Initialized
INFO - 2021-12-01 03:02:12 --> Output Class Initialized
INFO - 2021-12-01 03:02:12 --> Security Class Initialized
DEBUG - 2021-12-01 03:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:02:12 --> Input Class Initialized
INFO - 2021-12-01 03:02:12 --> Language Class Initialized
INFO - 2021-12-01 03:02:12 --> Language Class Initialized
INFO - 2021-12-01 03:02:12 --> Config Class Initialized
INFO - 2021-12-01 03:02:12 --> Loader Class Initialized
INFO - 2021-12-01 03:02:12 --> Helper loaded: url_helper
INFO - 2021-12-01 03:02:12 --> Helper loaded: file_helper
INFO - 2021-12-01 03:02:12 --> Helper loaded: form_helper
INFO - 2021-12-01 03:02:12 --> Helper loaded: my_helper
INFO - 2021-12-01 03:02:12 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:02:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:02:12 --> Controller Class Initialized
DEBUG - 2021-12-01 03:02:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-01 03:02:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 03:02:12 --> Final output sent to browser
DEBUG - 2021-12-01 03:02:12 --> Total execution time: 0.1057
INFO - 2021-12-01 03:02:15 --> Config Class Initialized
INFO - 2021-12-01 03:02:15 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:02:15 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:02:15 --> Utf8 Class Initialized
INFO - 2021-12-01 03:02:15 --> URI Class Initialized
INFO - 2021-12-01 03:02:15 --> Router Class Initialized
INFO - 2021-12-01 03:02:15 --> Output Class Initialized
INFO - 2021-12-01 03:02:15 --> Security Class Initialized
DEBUG - 2021-12-01 03:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:02:15 --> Input Class Initialized
INFO - 2021-12-01 03:02:15 --> Language Class Initialized
INFO - 2021-12-01 03:02:15 --> Language Class Initialized
INFO - 2021-12-01 03:02:15 --> Config Class Initialized
INFO - 2021-12-01 03:02:15 --> Loader Class Initialized
INFO - 2021-12-01 03:02:15 --> Helper loaded: url_helper
INFO - 2021-12-01 03:02:15 --> Helper loaded: file_helper
INFO - 2021-12-01 03:02:15 --> Helper loaded: form_helper
INFO - 2021-12-01 03:02:15 --> Helper loaded: my_helper
INFO - 2021-12-01 03:02:15 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:02:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:02:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:02:15 --> Controller Class Initialized
DEBUG - 2021-12-01 03:02:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-01 03:02:15 --> Final output sent to browser
DEBUG - 2021-12-01 03:02:15 --> Total execution time: 0.1541
INFO - 2021-12-01 03:02:27 --> Config Class Initialized
INFO - 2021-12-01 03:02:27 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:02:27 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:02:27 --> Utf8 Class Initialized
INFO - 2021-12-01 03:02:27 --> URI Class Initialized
INFO - 2021-12-01 03:02:27 --> Router Class Initialized
INFO - 2021-12-01 03:02:27 --> Output Class Initialized
INFO - 2021-12-01 03:02:27 --> Security Class Initialized
DEBUG - 2021-12-01 03:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:02:27 --> Input Class Initialized
INFO - 2021-12-01 03:02:27 --> Language Class Initialized
INFO - 2021-12-01 03:02:27 --> Language Class Initialized
INFO - 2021-12-01 03:02:27 --> Config Class Initialized
INFO - 2021-12-01 03:02:27 --> Loader Class Initialized
INFO - 2021-12-01 03:02:27 --> Helper loaded: url_helper
INFO - 2021-12-01 03:02:27 --> Helper loaded: file_helper
INFO - 2021-12-01 03:02:27 --> Helper loaded: form_helper
INFO - 2021-12-01 03:02:27 --> Helper loaded: my_helper
INFO - 2021-12-01 03:02:27 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:02:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:02:27 --> Controller Class Initialized
DEBUG - 2021-12-01 03:02:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-01 03:02:27 --> Final output sent to browser
DEBUG - 2021-12-01 03:02:27 --> Total execution time: 0.1415
INFO - 2021-12-01 03:02:38 --> Config Class Initialized
INFO - 2021-12-01 03:02:38 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:02:38 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:02:38 --> Utf8 Class Initialized
INFO - 2021-12-01 03:02:38 --> URI Class Initialized
INFO - 2021-12-01 03:02:38 --> Router Class Initialized
INFO - 2021-12-01 03:02:38 --> Output Class Initialized
INFO - 2021-12-01 03:02:38 --> Security Class Initialized
DEBUG - 2021-12-01 03:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:02:38 --> Input Class Initialized
INFO - 2021-12-01 03:02:38 --> Language Class Initialized
INFO - 2021-12-01 03:02:38 --> Language Class Initialized
INFO - 2021-12-01 03:02:38 --> Config Class Initialized
INFO - 2021-12-01 03:02:38 --> Loader Class Initialized
INFO - 2021-12-01 03:02:38 --> Helper loaded: url_helper
INFO - 2021-12-01 03:02:38 --> Helper loaded: file_helper
INFO - 2021-12-01 03:02:38 --> Helper loaded: form_helper
INFO - 2021-12-01 03:02:38 --> Helper loaded: my_helper
INFO - 2021-12-01 03:02:38 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:02:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:02:38 --> Controller Class Initialized
DEBUG - 2021-12-01 03:02:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-01 03:02:38 --> Final output sent to browser
DEBUG - 2021-12-01 03:02:38 --> Total execution time: 0.1540
INFO - 2021-12-01 03:02:40 --> Config Class Initialized
INFO - 2021-12-01 03:02:40 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:02:40 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:02:40 --> Utf8 Class Initialized
INFO - 2021-12-01 03:02:40 --> URI Class Initialized
INFO - 2021-12-01 03:02:40 --> Router Class Initialized
INFO - 2021-12-01 03:02:40 --> Output Class Initialized
INFO - 2021-12-01 03:02:40 --> Security Class Initialized
DEBUG - 2021-12-01 03:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:02:40 --> Input Class Initialized
INFO - 2021-12-01 03:02:40 --> Language Class Initialized
INFO - 2021-12-01 03:02:40 --> Language Class Initialized
INFO - 2021-12-01 03:02:40 --> Config Class Initialized
INFO - 2021-12-01 03:02:40 --> Loader Class Initialized
INFO - 2021-12-01 03:02:40 --> Helper loaded: url_helper
INFO - 2021-12-01 03:02:40 --> Helper loaded: file_helper
INFO - 2021-12-01 03:02:40 --> Helper loaded: form_helper
INFO - 2021-12-01 03:02:40 --> Helper loaded: my_helper
INFO - 2021-12-01 03:02:40 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:02:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:02:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:02:40 --> Controller Class Initialized
DEBUG - 2021-12-01 03:02:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-01 03:02:40 --> Final output sent to browser
DEBUG - 2021-12-01 03:02:40 --> Total execution time: 0.1593
INFO - 2021-12-01 03:02:42 --> Config Class Initialized
INFO - 2021-12-01 03:02:42 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:02:42 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:02:42 --> Utf8 Class Initialized
INFO - 2021-12-01 03:02:42 --> URI Class Initialized
INFO - 2021-12-01 03:02:42 --> Router Class Initialized
INFO - 2021-12-01 03:02:42 --> Output Class Initialized
INFO - 2021-12-01 03:02:42 --> Security Class Initialized
DEBUG - 2021-12-01 03:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:02:42 --> Input Class Initialized
INFO - 2021-12-01 03:02:42 --> Language Class Initialized
INFO - 2021-12-01 03:02:42 --> Language Class Initialized
INFO - 2021-12-01 03:02:42 --> Config Class Initialized
INFO - 2021-12-01 03:02:42 --> Loader Class Initialized
INFO - 2021-12-01 03:02:42 --> Helper loaded: url_helper
INFO - 2021-12-01 03:02:42 --> Helper loaded: file_helper
INFO - 2021-12-01 03:02:42 --> Helper loaded: form_helper
INFO - 2021-12-01 03:02:42 --> Helper loaded: my_helper
INFO - 2021-12-01 03:02:42 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:02:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:02:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:02:42 --> Controller Class Initialized
DEBUG - 2021-12-01 03:02:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-01 03:02:42 --> Final output sent to browser
DEBUG - 2021-12-01 03:02:42 --> Total execution time: 0.1189
INFO - 2021-12-01 03:02:44 --> Config Class Initialized
INFO - 2021-12-01 03:02:44 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:02:44 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:02:44 --> Utf8 Class Initialized
INFO - 2021-12-01 03:02:44 --> URI Class Initialized
INFO - 2021-12-01 03:02:44 --> Router Class Initialized
INFO - 2021-12-01 03:02:44 --> Output Class Initialized
INFO - 2021-12-01 03:02:44 --> Security Class Initialized
DEBUG - 2021-12-01 03:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:02:44 --> Input Class Initialized
INFO - 2021-12-01 03:02:44 --> Language Class Initialized
INFO - 2021-12-01 03:02:44 --> Language Class Initialized
INFO - 2021-12-01 03:02:44 --> Config Class Initialized
INFO - 2021-12-01 03:02:44 --> Loader Class Initialized
INFO - 2021-12-01 03:02:44 --> Helper loaded: url_helper
INFO - 2021-12-01 03:02:44 --> Helper loaded: file_helper
INFO - 2021-12-01 03:02:44 --> Helper loaded: form_helper
INFO - 2021-12-01 03:02:44 --> Helper loaded: my_helper
INFO - 2021-12-01 03:02:44 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:02:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:02:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:02:44 --> Controller Class Initialized
DEBUG - 2021-12-01 03:02:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-01 03:02:44 --> Final output sent to browser
DEBUG - 2021-12-01 03:02:44 --> Total execution time: 0.1359
INFO - 2021-12-01 03:02:46 --> Config Class Initialized
INFO - 2021-12-01 03:02:46 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:02:46 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:02:46 --> Utf8 Class Initialized
INFO - 2021-12-01 03:02:46 --> URI Class Initialized
INFO - 2021-12-01 03:02:46 --> Router Class Initialized
INFO - 2021-12-01 03:02:46 --> Output Class Initialized
INFO - 2021-12-01 03:02:46 --> Security Class Initialized
DEBUG - 2021-12-01 03:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:02:46 --> Input Class Initialized
INFO - 2021-12-01 03:02:46 --> Language Class Initialized
INFO - 2021-12-01 03:02:46 --> Language Class Initialized
INFO - 2021-12-01 03:02:46 --> Config Class Initialized
INFO - 2021-12-01 03:02:46 --> Loader Class Initialized
INFO - 2021-12-01 03:02:46 --> Helper loaded: url_helper
INFO - 2021-12-01 03:02:46 --> Helper loaded: file_helper
INFO - 2021-12-01 03:02:46 --> Helper loaded: form_helper
INFO - 2021-12-01 03:02:46 --> Helper loaded: my_helper
INFO - 2021-12-01 03:02:46 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:02:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:02:46 --> Controller Class Initialized
DEBUG - 2021-12-01 03:02:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-01 03:02:46 --> Final output sent to browser
DEBUG - 2021-12-01 03:02:46 --> Total execution time: 0.1742
INFO - 2021-12-01 03:02:48 --> Config Class Initialized
INFO - 2021-12-01 03:02:48 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:02:48 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:02:48 --> Utf8 Class Initialized
INFO - 2021-12-01 03:02:48 --> URI Class Initialized
INFO - 2021-12-01 03:02:48 --> Router Class Initialized
INFO - 2021-12-01 03:02:48 --> Output Class Initialized
INFO - 2021-12-01 03:02:48 --> Security Class Initialized
DEBUG - 2021-12-01 03:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:02:48 --> Input Class Initialized
INFO - 2021-12-01 03:02:48 --> Language Class Initialized
INFO - 2021-12-01 03:02:48 --> Language Class Initialized
INFO - 2021-12-01 03:02:48 --> Config Class Initialized
INFO - 2021-12-01 03:02:48 --> Loader Class Initialized
INFO - 2021-12-01 03:02:48 --> Helper loaded: url_helper
INFO - 2021-12-01 03:02:48 --> Helper loaded: file_helper
INFO - 2021-12-01 03:02:48 --> Helper loaded: form_helper
INFO - 2021-12-01 03:02:48 --> Helper loaded: my_helper
INFO - 2021-12-01 03:02:48 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:02:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:02:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:02:48 --> Controller Class Initialized
DEBUG - 2021-12-01 03:02:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-01 03:02:48 --> Final output sent to browser
DEBUG - 2021-12-01 03:02:48 --> Total execution time: 0.1480
INFO - 2021-12-01 03:02:50 --> Config Class Initialized
INFO - 2021-12-01 03:02:50 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:02:50 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:02:50 --> Utf8 Class Initialized
INFO - 2021-12-01 03:02:50 --> URI Class Initialized
INFO - 2021-12-01 03:02:50 --> Router Class Initialized
INFO - 2021-12-01 03:02:50 --> Output Class Initialized
INFO - 2021-12-01 03:02:50 --> Security Class Initialized
DEBUG - 2021-12-01 03:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:02:50 --> Input Class Initialized
INFO - 2021-12-01 03:02:50 --> Language Class Initialized
INFO - 2021-12-01 03:02:50 --> Language Class Initialized
INFO - 2021-12-01 03:02:50 --> Config Class Initialized
INFO - 2021-12-01 03:02:50 --> Loader Class Initialized
INFO - 2021-12-01 03:02:50 --> Helper loaded: url_helper
INFO - 2021-12-01 03:02:50 --> Helper loaded: file_helper
INFO - 2021-12-01 03:02:50 --> Helper loaded: form_helper
INFO - 2021-12-01 03:02:50 --> Helper loaded: my_helper
INFO - 2021-12-01 03:02:50 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:02:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:02:50 --> Controller Class Initialized
DEBUG - 2021-12-01 03:02:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-01 03:02:50 --> Final output sent to browser
DEBUG - 2021-12-01 03:02:50 --> Total execution time: 0.1318
INFO - 2021-12-01 03:02:52 --> Config Class Initialized
INFO - 2021-12-01 03:02:52 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:02:52 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:02:52 --> Utf8 Class Initialized
INFO - 2021-12-01 03:02:52 --> URI Class Initialized
INFO - 2021-12-01 03:02:52 --> Router Class Initialized
INFO - 2021-12-01 03:02:52 --> Output Class Initialized
INFO - 2021-12-01 03:02:52 --> Security Class Initialized
DEBUG - 2021-12-01 03:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:02:52 --> Input Class Initialized
INFO - 2021-12-01 03:02:52 --> Language Class Initialized
INFO - 2021-12-01 03:02:52 --> Language Class Initialized
INFO - 2021-12-01 03:02:52 --> Config Class Initialized
INFO - 2021-12-01 03:02:52 --> Loader Class Initialized
INFO - 2021-12-01 03:02:52 --> Helper loaded: url_helper
INFO - 2021-12-01 03:02:52 --> Helper loaded: file_helper
INFO - 2021-12-01 03:02:52 --> Helper loaded: form_helper
INFO - 2021-12-01 03:02:52 --> Helper loaded: my_helper
INFO - 2021-12-01 03:02:52 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:02:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:02:52 --> Controller Class Initialized
DEBUG - 2021-12-01 03:02:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-01 03:02:52 --> Final output sent to browser
DEBUG - 2021-12-01 03:02:52 --> Total execution time: 0.1154
INFO - 2021-12-01 03:02:54 --> Config Class Initialized
INFO - 2021-12-01 03:02:54 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:02:54 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:02:54 --> Utf8 Class Initialized
INFO - 2021-12-01 03:02:54 --> URI Class Initialized
INFO - 2021-12-01 03:02:54 --> Router Class Initialized
INFO - 2021-12-01 03:02:54 --> Output Class Initialized
INFO - 2021-12-01 03:02:54 --> Security Class Initialized
DEBUG - 2021-12-01 03:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:02:54 --> Input Class Initialized
INFO - 2021-12-01 03:02:54 --> Language Class Initialized
INFO - 2021-12-01 03:02:54 --> Language Class Initialized
INFO - 2021-12-01 03:02:54 --> Config Class Initialized
INFO - 2021-12-01 03:02:54 --> Loader Class Initialized
INFO - 2021-12-01 03:02:54 --> Helper loaded: url_helper
INFO - 2021-12-01 03:02:54 --> Helper loaded: file_helper
INFO - 2021-12-01 03:02:54 --> Helper loaded: form_helper
INFO - 2021-12-01 03:02:54 --> Helper loaded: my_helper
INFO - 2021-12-01 03:02:54 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:02:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:02:54 --> Controller Class Initialized
DEBUG - 2021-12-01 03:02:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-01 03:02:54 --> Final output sent to browser
DEBUG - 2021-12-01 03:02:54 --> Total execution time: 0.1135
INFO - 2021-12-01 03:02:56 --> Config Class Initialized
INFO - 2021-12-01 03:02:56 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:02:56 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:02:56 --> Utf8 Class Initialized
INFO - 2021-12-01 03:02:56 --> URI Class Initialized
INFO - 2021-12-01 03:02:56 --> Router Class Initialized
INFO - 2021-12-01 03:02:56 --> Output Class Initialized
INFO - 2021-12-01 03:02:56 --> Security Class Initialized
DEBUG - 2021-12-01 03:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:02:57 --> Input Class Initialized
INFO - 2021-12-01 03:02:57 --> Language Class Initialized
INFO - 2021-12-01 03:02:57 --> Language Class Initialized
INFO - 2021-12-01 03:02:57 --> Config Class Initialized
INFO - 2021-12-01 03:02:57 --> Loader Class Initialized
INFO - 2021-12-01 03:02:57 --> Helper loaded: url_helper
INFO - 2021-12-01 03:02:57 --> Helper loaded: file_helper
INFO - 2021-12-01 03:02:57 --> Helper loaded: form_helper
INFO - 2021-12-01 03:02:57 --> Helper loaded: my_helper
INFO - 2021-12-01 03:02:57 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:02:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:02:57 --> Controller Class Initialized
DEBUG - 2021-12-01 03:02:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-01 03:02:57 --> Final output sent to browser
DEBUG - 2021-12-01 03:02:57 --> Total execution time: 0.1312
INFO - 2021-12-01 03:02:59 --> Config Class Initialized
INFO - 2021-12-01 03:02:59 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:02:59 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:02:59 --> Utf8 Class Initialized
INFO - 2021-12-01 03:02:59 --> URI Class Initialized
INFO - 2021-12-01 03:02:59 --> Router Class Initialized
INFO - 2021-12-01 03:02:59 --> Output Class Initialized
INFO - 2021-12-01 03:02:59 --> Security Class Initialized
DEBUG - 2021-12-01 03:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:02:59 --> Input Class Initialized
INFO - 2021-12-01 03:02:59 --> Language Class Initialized
INFO - 2021-12-01 03:02:59 --> Language Class Initialized
INFO - 2021-12-01 03:02:59 --> Config Class Initialized
INFO - 2021-12-01 03:02:59 --> Loader Class Initialized
INFO - 2021-12-01 03:02:59 --> Helper loaded: url_helper
INFO - 2021-12-01 03:02:59 --> Helper loaded: file_helper
INFO - 2021-12-01 03:02:59 --> Helper loaded: form_helper
INFO - 2021-12-01 03:02:59 --> Helper loaded: my_helper
INFO - 2021-12-01 03:02:59 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:02:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:02:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:02:59 --> Controller Class Initialized
DEBUG - 2021-12-01 03:02:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-01 03:02:59 --> Final output sent to browser
DEBUG - 2021-12-01 03:02:59 --> Total execution time: 0.1184
INFO - 2021-12-01 03:03:00 --> Config Class Initialized
INFO - 2021-12-01 03:03:00 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:03:00 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:03:00 --> Utf8 Class Initialized
INFO - 2021-12-01 03:03:00 --> URI Class Initialized
INFO - 2021-12-01 03:03:00 --> Router Class Initialized
INFO - 2021-12-01 03:03:00 --> Output Class Initialized
INFO - 2021-12-01 03:03:00 --> Security Class Initialized
DEBUG - 2021-12-01 03:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:03:00 --> Input Class Initialized
INFO - 2021-12-01 03:03:00 --> Language Class Initialized
INFO - 2021-12-01 03:03:00 --> Language Class Initialized
INFO - 2021-12-01 03:03:00 --> Config Class Initialized
INFO - 2021-12-01 03:03:00 --> Loader Class Initialized
INFO - 2021-12-01 03:03:00 --> Helper loaded: url_helper
INFO - 2021-12-01 03:03:00 --> Helper loaded: file_helper
INFO - 2021-12-01 03:03:00 --> Helper loaded: form_helper
INFO - 2021-12-01 03:03:00 --> Helper loaded: my_helper
INFO - 2021-12-01 03:03:00 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:03:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:03:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:03:01 --> Controller Class Initialized
DEBUG - 2021-12-01 03:03:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-01 03:03:01 --> Final output sent to browser
DEBUG - 2021-12-01 03:03:01 --> Total execution time: 0.1392
INFO - 2021-12-01 03:03:02 --> Config Class Initialized
INFO - 2021-12-01 03:03:02 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:03:02 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:03:02 --> Utf8 Class Initialized
INFO - 2021-12-01 03:03:02 --> URI Class Initialized
INFO - 2021-12-01 03:03:02 --> Router Class Initialized
INFO - 2021-12-01 03:03:02 --> Output Class Initialized
INFO - 2021-12-01 03:03:02 --> Security Class Initialized
DEBUG - 2021-12-01 03:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:03:02 --> Input Class Initialized
INFO - 2021-12-01 03:03:02 --> Language Class Initialized
INFO - 2021-12-01 03:03:03 --> Language Class Initialized
INFO - 2021-12-01 03:03:03 --> Config Class Initialized
INFO - 2021-12-01 03:03:03 --> Loader Class Initialized
INFO - 2021-12-01 03:03:03 --> Helper loaded: url_helper
INFO - 2021-12-01 03:03:03 --> Helper loaded: file_helper
INFO - 2021-12-01 03:03:03 --> Helper loaded: form_helper
INFO - 2021-12-01 03:03:03 --> Helper loaded: my_helper
INFO - 2021-12-01 03:03:03 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:03:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:03:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:03:03 --> Controller Class Initialized
DEBUG - 2021-12-01 03:03:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-01 03:03:03 --> Final output sent to browser
DEBUG - 2021-12-01 03:03:03 --> Total execution time: 0.1242
INFO - 2021-12-01 03:03:04 --> Config Class Initialized
INFO - 2021-12-01 03:03:04 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:03:04 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:03:04 --> Utf8 Class Initialized
INFO - 2021-12-01 03:03:04 --> URI Class Initialized
INFO - 2021-12-01 03:03:04 --> Router Class Initialized
INFO - 2021-12-01 03:03:04 --> Output Class Initialized
INFO - 2021-12-01 03:03:05 --> Security Class Initialized
DEBUG - 2021-12-01 03:03:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:03:05 --> Input Class Initialized
INFO - 2021-12-01 03:03:05 --> Language Class Initialized
INFO - 2021-12-01 03:03:05 --> Language Class Initialized
INFO - 2021-12-01 03:03:05 --> Config Class Initialized
INFO - 2021-12-01 03:03:05 --> Loader Class Initialized
INFO - 2021-12-01 03:03:05 --> Helper loaded: url_helper
INFO - 2021-12-01 03:03:05 --> Helper loaded: file_helper
INFO - 2021-12-01 03:03:05 --> Helper loaded: form_helper
INFO - 2021-12-01 03:03:05 --> Helper loaded: my_helper
INFO - 2021-12-01 03:03:05 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:03:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:03:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:03:05 --> Controller Class Initialized
DEBUG - 2021-12-01 03:03:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-01 03:03:05 --> Final output sent to browser
DEBUG - 2021-12-01 03:03:05 --> Total execution time: 0.1412
INFO - 2021-12-01 03:03:06 --> Config Class Initialized
INFO - 2021-12-01 03:03:06 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:03:06 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:03:06 --> Utf8 Class Initialized
INFO - 2021-12-01 03:03:06 --> URI Class Initialized
INFO - 2021-12-01 03:03:06 --> Router Class Initialized
INFO - 2021-12-01 03:03:06 --> Output Class Initialized
INFO - 2021-12-01 03:03:06 --> Security Class Initialized
DEBUG - 2021-12-01 03:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:03:06 --> Input Class Initialized
INFO - 2021-12-01 03:03:06 --> Language Class Initialized
INFO - 2021-12-01 03:03:07 --> Language Class Initialized
INFO - 2021-12-01 03:03:07 --> Config Class Initialized
INFO - 2021-12-01 03:03:07 --> Loader Class Initialized
INFO - 2021-12-01 03:03:07 --> Helper loaded: url_helper
INFO - 2021-12-01 03:03:07 --> Helper loaded: file_helper
INFO - 2021-12-01 03:03:07 --> Helper loaded: form_helper
INFO - 2021-12-01 03:03:07 --> Helper loaded: my_helper
INFO - 2021-12-01 03:03:07 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:03:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:03:07 --> Controller Class Initialized
DEBUG - 2021-12-01 03:03:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-01 03:03:07 --> Final output sent to browser
DEBUG - 2021-12-01 03:03:07 --> Total execution time: 0.1217
INFO - 2021-12-01 03:03:08 --> Config Class Initialized
INFO - 2021-12-01 03:03:08 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:03:08 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:03:08 --> Utf8 Class Initialized
INFO - 2021-12-01 03:03:08 --> URI Class Initialized
INFO - 2021-12-01 03:03:08 --> Router Class Initialized
INFO - 2021-12-01 03:03:08 --> Output Class Initialized
INFO - 2021-12-01 03:03:08 --> Security Class Initialized
DEBUG - 2021-12-01 03:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:03:08 --> Input Class Initialized
INFO - 2021-12-01 03:03:08 --> Language Class Initialized
INFO - 2021-12-01 03:03:08 --> Language Class Initialized
INFO - 2021-12-01 03:03:08 --> Config Class Initialized
INFO - 2021-12-01 03:03:08 --> Loader Class Initialized
INFO - 2021-12-01 03:03:08 --> Helper loaded: url_helper
INFO - 2021-12-01 03:03:08 --> Helper loaded: file_helper
INFO - 2021-12-01 03:03:08 --> Helper loaded: form_helper
INFO - 2021-12-01 03:03:08 --> Helper loaded: my_helper
INFO - 2021-12-01 03:03:08 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:03:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:03:08 --> Controller Class Initialized
DEBUG - 2021-12-01 03:03:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-01 03:03:08 --> Final output sent to browser
DEBUG - 2021-12-01 03:03:08 --> Total execution time: 0.1387
INFO - 2021-12-01 03:03:10 --> Config Class Initialized
INFO - 2021-12-01 03:03:10 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:03:10 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:03:10 --> Utf8 Class Initialized
INFO - 2021-12-01 03:03:10 --> URI Class Initialized
INFO - 2021-12-01 03:03:10 --> Router Class Initialized
INFO - 2021-12-01 03:03:10 --> Output Class Initialized
INFO - 2021-12-01 03:03:10 --> Security Class Initialized
DEBUG - 2021-12-01 03:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:03:10 --> Input Class Initialized
INFO - 2021-12-01 03:03:10 --> Language Class Initialized
INFO - 2021-12-01 03:03:10 --> Language Class Initialized
INFO - 2021-12-01 03:03:10 --> Config Class Initialized
INFO - 2021-12-01 03:03:10 --> Loader Class Initialized
INFO - 2021-12-01 03:03:10 --> Helper loaded: url_helper
INFO - 2021-12-01 03:03:10 --> Helper loaded: file_helper
INFO - 2021-12-01 03:03:10 --> Helper loaded: form_helper
INFO - 2021-12-01 03:03:10 --> Helper loaded: my_helper
INFO - 2021-12-01 03:03:10 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:03:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:03:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:03:10 --> Controller Class Initialized
DEBUG - 2021-12-01 03:03:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-01 03:03:10 --> Final output sent to browser
DEBUG - 2021-12-01 03:03:10 --> Total execution time: 0.1315
INFO - 2021-12-01 03:03:12 --> Config Class Initialized
INFO - 2021-12-01 03:03:12 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:03:12 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:03:12 --> Utf8 Class Initialized
INFO - 2021-12-01 03:03:12 --> URI Class Initialized
INFO - 2021-12-01 03:03:12 --> Router Class Initialized
INFO - 2021-12-01 03:03:12 --> Output Class Initialized
INFO - 2021-12-01 03:03:12 --> Security Class Initialized
DEBUG - 2021-12-01 03:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:03:12 --> Input Class Initialized
INFO - 2021-12-01 03:03:12 --> Language Class Initialized
INFO - 2021-12-01 03:03:12 --> Language Class Initialized
INFO - 2021-12-01 03:03:12 --> Config Class Initialized
INFO - 2021-12-01 03:03:12 --> Loader Class Initialized
INFO - 2021-12-01 03:03:12 --> Helper loaded: url_helper
INFO - 2021-12-01 03:03:12 --> Helper loaded: file_helper
INFO - 2021-12-01 03:03:12 --> Helper loaded: form_helper
INFO - 2021-12-01 03:03:12 --> Helper loaded: my_helper
INFO - 2021-12-01 03:03:12 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:03:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:03:12 --> Controller Class Initialized
DEBUG - 2021-12-01 03:03:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-01 03:03:12 --> Final output sent to browser
DEBUG - 2021-12-01 03:03:12 --> Total execution time: 0.1382
INFO - 2021-12-01 03:03:14 --> Config Class Initialized
INFO - 2021-12-01 03:03:14 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:03:14 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:03:14 --> Utf8 Class Initialized
INFO - 2021-12-01 03:03:14 --> URI Class Initialized
INFO - 2021-12-01 03:03:14 --> Router Class Initialized
INFO - 2021-12-01 03:03:14 --> Output Class Initialized
INFO - 2021-12-01 03:03:14 --> Security Class Initialized
DEBUG - 2021-12-01 03:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:03:14 --> Input Class Initialized
INFO - 2021-12-01 03:03:14 --> Language Class Initialized
INFO - 2021-12-01 03:03:14 --> Language Class Initialized
INFO - 2021-12-01 03:03:14 --> Config Class Initialized
INFO - 2021-12-01 03:03:14 --> Loader Class Initialized
INFO - 2021-12-01 03:03:14 --> Helper loaded: url_helper
INFO - 2021-12-01 03:03:14 --> Helper loaded: file_helper
INFO - 2021-12-01 03:03:14 --> Helper loaded: form_helper
INFO - 2021-12-01 03:03:14 --> Helper loaded: my_helper
INFO - 2021-12-01 03:03:14 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:03:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:03:14 --> Controller Class Initialized
DEBUG - 2021-12-01 03:03:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-01 03:03:14 --> Final output sent to browser
DEBUG - 2021-12-01 03:03:14 --> Total execution time: 0.1369
INFO - 2021-12-01 03:03:16 --> Config Class Initialized
INFO - 2021-12-01 03:03:16 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:03:16 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:03:16 --> Utf8 Class Initialized
INFO - 2021-12-01 03:03:16 --> URI Class Initialized
INFO - 2021-12-01 03:03:16 --> Router Class Initialized
INFO - 2021-12-01 03:03:16 --> Output Class Initialized
INFO - 2021-12-01 03:03:16 --> Security Class Initialized
DEBUG - 2021-12-01 03:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:03:16 --> Input Class Initialized
INFO - 2021-12-01 03:03:16 --> Language Class Initialized
INFO - 2021-12-01 03:03:16 --> Language Class Initialized
INFO - 2021-12-01 03:03:16 --> Config Class Initialized
INFO - 2021-12-01 03:03:16 --> Loader Class Initialized
INFO - 2021-12-01 03:03:16 --> Helper loaded: url_helper
INFO - 2021-12-01 03:03:16 --> Helper loaded: file_helper
INFO - 2021-12-01 03:03:16 --> Helper loaded: form_helper
INFO - 2021-12-01 03:03:16 --> Helper loaded: my_helper
INFO - 2021-12-01 03:03:16 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:03:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:03:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:03:16 --> Controller Class Initialized
DEBUG - 2021-12-01 03:03:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-01 03:03:16 --> Final output sent to browser
DEBUG - 2021-12-01 03:03:16 --> Total execution time: 0.1534
INFO - 2021-12-01 03:03:19 --> Config Class Initialized
INFO - 2021-12-01 03:03:19 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:03:19 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:03:19 --> Utf8 Class Initialized
INFO - 2021-12-01 03:03:19 --> URI Class Initialized
INFO - 2021-12-01 03:03:19 --> Router Class Initialized
INFO - 2021-12-01 03:03:19 --> Output Class Initialized
INFO - 2021-12-01 03:03:19 --> Security Class Initialized
DEBUG - 2021-12-01 03:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:03:19 --> Input Class Initialized
INFO - 2021-12-01 03:03:19 --> Language Class Initialized
INFO - 2021-12-01 03:03:19 --> Language Class Initialized
INFO - 2021-12-01 03:03:19 --> Config Class Initialized
INFO - 2021-12-01 03:03:19 --> Loader Class Initialized
INFO - 2021-12-01 03:03:19 --> Helper loaded: url_helper
INFO - 2021-12-01 03:03:19 --> Helper loaded: file_helper
INFO - 2021-12-01 03:03:19 --> Helper loaded: form_helper
INFO - 2021-12-01 03:03:19 --> Helper loaded: my_helper
INFO - 2021-12-01 03:03:19 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:03:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:03:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:03:19 --> Controller Class Initialized
DEBUG - 2021-12-01 03:03:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-01 03:03:19 --> Final output sent to browser
DEBUG - 2021-12-01 03:03:19 --> Total execution time: 0.1571
INFO - 2021-12-01 03:03:21 --> Config Class Initialized
INFO - 2021-12-01 03:03:21 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:03:21 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:03:21 --> Utf8 Class Initialized
INFO - 2021-12-01 03:03:21 --> URI Class Initialized
INFO - 2021-12-01 03:03:21 --> Router Class Initialized
INFO - 2021-12-01 03:03:21 --> Output Class Initialized
INFO - 2021-12-01 03:03:21 --> Security Class Initialized
DEBUG - 2021-12-01 03:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:03:21 --> Input Class Initialized
INFO - 2021-12-01 03:03:21 --> Language Class Initialized
INFO - 2021-12-01 03:03:21 --> Language Class Initialized
INFO - 2021-12-01 03:03:21 --> Config Class Initialized
INFO - 2021-12-01 03:03:21 --> Loader Class Initialized
INFO - 2021-12-01 03:03:21 --> Helper loaded: url_helper
INFO - 2021-12-01 03:03:21 --> Helper loaded: file_helper
INFO - 2021-12-01 03:03:21 --> Helper loaded: form_helper
INFO - 2021-12-01 03:03:21 --> Helper loaded: my_helper
INFO - 2021-12-01 03:03:21 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:03:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:03:21 --> Controller Class Initialized
DEBUG - 2021-12-01 03:03:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-01 03:03:21 --> Final output sent to browser
DEBUG - 2021-12-01 03:03:21 --> Total execution time: 0.1497
INFO - 2021-12-01 03:03:23 --> Config Class Initialized
INFO - 2021-12-01 03:03:23 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:03:23 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:03:23 --> Utf8 Class Initialized
INFO - 2021-12-01 03:03:23 --> URI Class Initialized
INFO - 2021-12-01 03:03:23 --> Router Class Initialized
INFO - 2021-12-01 03:03:23 --> Output Class Initialized
INFO - 2021-12-01 03:03:23 --> Security Class Initialized
DEBUG - 2021-12-01 03:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:03:23 --> Input Class Initialized
INFO - 2021-12-01 03:03:23 --> Language Class Initialized
INFO - 2021-12-01 03:03:23 --> Language Class Initialized
INFO - 2021-12-01 03:03:23 --> Config Class Initialized
INFO - 2021-12-01 03:03:23 --> Loader Class Initialized
INFO - 2021-12-01 03:03:23 --> Helper loaded: url_helper
INFO - 2021-12-01 03:03:23 --> Helper loaded: file_helper
INFO - 2021-12-01 03:03:23 --> Helper loaded: form_helper
INFO - 2021-12-01 03:03:23 --> Helper loaded: my_helper
INFO - 2021-12-01 03:03:23 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:03:23 --> Controller Class Initialized
DEBUG - 2021-12-01 03:03:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-01 03:03:23 --> Final output sent to browser
DEBUG - 2021-12-01 03:03:23 --> Total execution time: 0.1177
INFO - 2021-12-01 03:07:28 --> Config Class Initialized
INFO - 2021-12-01 03:07:28 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:07:28 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:07:28 --> Utf8 Class Initialized
INFO - 2021-12-01 03:07:28 --> URI Class Initialized
INFO - 2021-12-01 03:07:28 --> Router Class Initialized
INFO - 2021-12-01 03:07:28 --> Output Class Initialized
INFO - 2021-12-01 03:07:28 --> Security Class Initialized
DEBUG - 2021-12-01 03:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:07:28 --> Input Class Initialized
INFO - 2021-12-01 03:07:28 --> Language Class Initialized
INFO - 2021-12-01 03:07:28 --> Language Class Initialized
INFO - 2021-12-01 03:07:28 --> Config Class Initialized
INFO - 2021-12-01 03:07:28 --> Loader Class Initialized
INFO - 2021-12-01 03:07:28 --> Helper loaded: url_helper
INFO - 2021-12-01 03:07:28 --> Helper loaded: file_helper
INFO - 2021-12-01 03:07:28 --> Helper loaded: form_helper
INFO - 2021-12-01 03:07:28 --> Helper loaded: my_helper
INFO - 2021-12-01 03:07:28 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:07:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:07:28 --> Controller Class Initialized
INFO - 2021-12-01 03:07:28 --> Helper loaded: cookie_helper
INFO - 2021-12-01 03:07:28 --> Config Class Initialized
INFO - 2021-12-01 03:07:28 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:07:28 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:07:28 --> Utf8 Class Initialized
INFO - 2021-12-01 03:07:28 --> URI Class Initialized
INFO - 2021-12-01 03:07:28 --> Router Class Initialized
INFO - 2021-12-01 03:07:28 --> Output Class Initialized
INFO - 2021-12-01 03:07:28 --> Security Class Initialized
DEBUG - 2021-12-01 03:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:07:28 --> Input Class Initialized
INFO - 2021-12-01 03:07:28 --> Language Class Initialized
INFO - 2021-12-01 03:07:28 --> Language Class Initialized
INFO - 2021-12-01 03:07:28 --> Config Class Initialized
INFO - 2021-12-01 03:07:28 --> Loader Class Initialized
INFO - 2021-12-01 03:07:28 --> Helper loaded: url_helper
INFO - 2021-12-01 03:07:28 --> Helper loaded: file_helper
INFO - 2021-12-01 03:07:28 --> Helper loaded: form_helper
INFO - 2021-12-01 03:07:28 --> Helper loaded: my_helper
INFO - 2021-12-01 03:07:28 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:07:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:07:28 --> Controller Class Initialized
DEBUG - 2021-12-01 03:07:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-01 03:07:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 03:07:28 --> Final output sent to browser
DEBUG - 2021-12-01 03:07:28 --> Total execution time: 0.0646
INFO - 2021-12-01 03:07:32 --> Config Class Initialized
INFO - 2021-12-01 03:07:32 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:07:32 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:07:32 --> Utf8 Class Initialized
INFO - 2021-12-01 03:07:32 --> URI Class Initialized
INFO - 2021-12-01 03:07:32 --> Router Class Initialized
INFO - 2021-12-01 03:07:32 --> Output Class Initialized
INFO - 2021-12-01 03:07:32 --> Security Class Initialized
DEBUG - 2021-12-01 03:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:07:32 --> Input Class Initialized
INFO - 2021-12-01 03:07:32 --> Language Class Initialized
INFO - 2021-12-01 03:07:32 --> Language Class Initialized
INFO - 2021-12-01 03:07:32 --> Config Class Initialized
INFO - 2021-12-01 03:07:32 --> Loader Class Initialized
INFO - 2021-12-01 03:07:32 --> Helper loaded: url_helper
INFO - 2021-12-01 03:07:32 --> Helper loaded: file_helper
INFO - 2021-12-01 03:07:32 --> Helper loaded: form_helper
INFO - 2021-12-01 03:07:32 --> Helper loaded: my_helper
INFO - 2021-12-01 03:07:32 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:07:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:07:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:07:32 --> Controller Class Initialized
INFO - 2021-12-01 03:07:32 --> Helper loaded: cookie_helper
INFO - 2021-12-01 03:07:32 --> Final output sent to browser
DEBUG - 2021-12-01 03:07:32 --> Total execution time: 0.0840
INFO - 2021-12-01 03:07:33 --> Config Class Initialized
INFO - 2021-12-01 03:07:33 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:07:33 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:07:33 --> Utf8 Class Initialized
INFO - 2021-12-01 03:07:33 --> URI Class Initialized
INFO - 2021-12-01 03:07:33 --> Router Class Initialized
INFO - 2021-12-01 03:07:33 --> Output Class Initialized
INFO - 2021-12-01 03:07:33 --> Security Class Initialized
DEBUG - 2021-12-01 03:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:07:33 --> Input Class Initialized
INFO - 2021-12-01 03:07:33 --> Language Class Initialized
INFO - 2021-12-01 03:07:33 --> Language Class Initialized
INFO - 2021-12-01 03:07:33 --> Config Class Initialized
INFO - 2021-12-01 03:07:33 --> Loader Class Initialized
INFO - 2021-12-01 03:07:33 --> Helper loaded: url_helper
INFO - 2021-12-01 03:07:33 --> Helper loaded: file_helper
INFO - 2021-12-01 03:07:33 --> Helper loaded: form_helper
INFO - 2021-12-01 03:07:33 --> Helper loaded: my_helper
INFO - 2021-12-01 03:07:33 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:07:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:07:33 --> Controller Class Initialized
DEBUG - 2021-12-01 03:07:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-01 03:07:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 03:07:33 --> Final output sent to browser
DEBUG - 2021-12-01 03:07:33 --> Total execution time: 0.2480
INFO - 2021-12-01 03:07:36 --> Config Class Initialized
INFO - 2021-12-01 03:07:36 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:07:36 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:07:36 --> Utf8 Class Initialized
INFO - 2021-12-01 03:07:36 --> URI Class Initialized
INFO - 2021-12-01 03:07:36 --> Router Class Initialized
INFO - 2021-12-01 03:07:36 --> Output Class Initialized
INFO - 2021-12-01 03:07:36 --> Security Class Initialized
DEBUG - 2021-12-01 03:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:07:36 --> Input Class Initialized
INFO - 2021-12-01 03:07:36 --> Language Class Initialized
INFO - 2021-12-01 03:07:36 --> Language Class Initialized
INFO - 2021-12-01 03:07:36 --> Config Class Initialized
INFO - 2021-12-01 03:07:36 --> Loader Class Initialized
INFO - 2021-12-01 03:07:36 --> Helper loaded: url_helper
INFO - 2021-12-01 03:07:36 --> Helper loaded: file_helper
INFO - 2021-12-01 03:07:36 --> Helper loaded: form_helper
INFO - 2021-12-01 03:07:36 --> Helper loaded: my_helper
INFO - 2021-12-01 03:07:36 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:07:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:07:36 --> Controller Class Initialized
DEBUG - 2021-12-01 03:07:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-12-01 03:07:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 03:07:36 --> Final output sent to browser
DEBUG - 2021-12-01 03:07:36 --> Total execution time: 0.0877
INFO - 2021-12-01 03:07:36 --> Config Class Initialized
INFO - 2021-12-01 03:07:36 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:07:36 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:07:36 --> Utf8 Class Initialized
INFO - 2021-12-01 03:07:36 --> URI Class Initialized
INFO - 2021-12-01 03:07:36 --> Router Class Initialized
INFO - 2021-12-01 03:07:36 --> Output Class Initialized
INFO - 2021-12-01 03:07:36 --> Security Class Initialized
DEBUG - 2021-12-01 03:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:07:36 --> Input Class Initialized
INFO - 2021-12-01 03:07:36 --> Language Class Initialized
INFO - 2021-12-01 03:07:36 --> Language Class Initialized
INFO - 2021-12-01 03:07:36 --> Config Class Initialized
INFO - 2021-12-01 03:07:36 --> Loader Class Initialized
INFO - 2021-12-01 03:07:36 --> Helper loaded: url_helper
INFO - 2021-12-01 03:07:36 --> Helper loaded: file_helper
INFO - 2021-12-01 03:07:36 --> Helper loaded: form_helper
INFO - 2021-12-01 03:07:36 --> Helper loaded: my_helper
INFO - 2021-12-01 03:07:36 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:07:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:07:36 --> Controller Class Initialized
INFO - 2021-12-01 03:07:41 --> Config Class Initialized
INFO - 2021-12-01 03:07:41 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:07:41 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:07:41 --> Utf8 Class Initialized
INFO - 2021-12-01 03:07:41 --> URI Class Initialized
INFO - 2021-12-01 03:07:41 --> Router Class Initialized
INFO - 2021-12-01 03:07:41 --> Output Class Initialized
INFO - 2021-12-01 03:07:41 --> Security Class Initialized
DEBUG - 2021-12-01 03:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:07:41 --> Input Class Initialized
INFO - 2021-12-01 03:07:41 --> Language Class Initialized
INFO - 2021-12-01 03:07:41 --> Language Class Initialized
INFO - 2021-12-01 03:07:41 --> Config Class Initialized
INFO - 2021-12-01 03:07:41 --> Loader Class Initialized
INFO - 2021-12-01 03:07:41 --> Helper loaded: url_helper
INFO - 2021-12-01 03:07:41 --> Helper loaded: file_helper
INFO - 2021-12-01 03:07:41 --> Helper loaded: form_helper
INFO - 2021-12-01 03:07:41 --> Helper loaded: my_helper
INFO - 2021-12-01 03:07:41 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:07:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:07:41 --> Controller Class Initialized
INFO - 2021-12-01 03:07:41 --> Final output sent to browser
DEBUG - 2021-12-01 03:07:41 --> Total execution time: 0.1116
INFO - 2021-12-01 03:07:41 --> Config Class Initialized
INFO - 2021-12-01 03:07:41 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:07:41 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:07:41 --> Utf8 Class Initialized
INFO - 2021-12-01 03:07:41 --> URI Class Initialized
INFO - 2021-12-01 03:07:41 --> Router Class Initialized
INFO - 2021-12-01 03:07:41 --> Output Class Initialized
INFO - 2021-12-01 03:07:41 --> Security Class Initialized
DEBUG - 2021-12-01 03:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:07:41 --> Input Class Initialized
INFO - 2021-12-01 03:07:41 --> Language Class Initialized
INFO - 2021-12-01 03:07:41 --> Language Class Initialized
INFO - 2021-12-01 03:07:41 --> Config Class Initialized
INFO - 2021-12-01 03:07:41 --> Loader Class Initialized
INFO - 2021-12-01 03:07:41 --> Helper loaded: url_helper
INFO - 2021-12-01 03:07:41 --> Helper loaded: file_helper
INFO - 2021-12-01 03:07:41 --> Helper loaded: form_helper
INFO - 2021-12-01 03:07:41 --> Helper loaded: my_helper
INFO - 2021-12-01 03:07:41 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:07:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:07:41 --> Controller Class Initialized
INFO - 2021-12-01 03:08:00 --> Config Class Initialized
INFO - 2021-12-01 03:08:00 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:08:00 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:08:00 --> Utf8 Class Initialized
INFO - 2021-12-01 03:08:00 --> URI Class Initialized
INFO - 2021-12-01 03:08:00 --> Router Class Initialized
INFO - 2021-12-01 03:08:00 --> Output Class Initialized
INFO - 2021-12-01 03:08:00 --> Security Class Initialized
DEBUG - 2021-12-01 03:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:08:00 --> Input Class Initialized
INFO - 2021-12-01 03:08:00 --> Language Class Initialized
INFO - 2021-12-01 03:08:00 --> Language Class Initialized
INFO - 2021-12-01 03:08:00 --> Config Class Initialized
INFO - 2021-12-01 03:08:00 --> Loader Class Initialized
INFO - 2021-12-01 03:08:00 --> Helper loaded: url_helper
INFO - 2021-12-01 03:08:00 --> Helper loaded: file_helper
INFO - 2021-12-01 03:08:00 --> Helper loaded: form_helper
INFO - 2021-12-01 03:08:00 --> Helper loaded: my_helper
INFO - 2021-12-01 03:08:00 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:08:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:08:01 --> Controller Class Initialized
INFO - 2021-12-01 03:08:01 --> Helper loaded: cookie_helper
INFO - 2021-12-01 03:08:01 --> Config Class Initialized
INFO - 2021-12-01 03:08:01 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:08:01 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:08:01 --> Utf8 Class Initialized
INFO - 2021-12-01 03:08:01 --> URI Class Initialized
INFO - 2021-12-01 03:08:01 --> Router Class Initialized
INFO - 2021-12-01 03:08:01 --> Output Class Initialized
INFO - 2021-12-01 03:08:01 --> Security Class Initialized
DEBUG - 2021-12-01 03:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:08:01 --> Input Class Initialized
INFO - 2021-12-01 03:08:01 --> Language Class Initialized
INFO - 2021-12-01 03:08:01 --> Language Class Initialized
INFO - 2021-12-01 03:08:01 --> Config Class Initialized
INFO - 2021-12-01 03:08:01 --> Loader Class Initialized
INFO - 2021-12-01 03:08:01 --> Helper loaded: url_helper
INFO - 2021-12-01 03:08:01 --> Helper loaded: file_helper
INFO - 2021-12-01 03:08:01 --> Helper loaded: form_helper
INFO - 2021-12-01 03:08:01 --> Helper loaded: my_helper
INFO - 2021-12-01 03:08:01 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:08:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:08:01 --> Controller Class Initialized
DEBUG - 2021-12-01 03:08:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-01 03:08:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 03:08:01 --> Final output sent to browser
DEBUG - 2021-12-01 03:08:01 --> Total execution time: 0.0685
INFO - 2021-12-01 03:08:08 --> Config Class Initialized
INFO - 2021-12-01 03:08:08 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:08:08 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:08:08 --> Utf8 Class Initialized
INFO - 2021-12-01 03:08:08 --> URI Class Initialized
INFO - 2021-12-01 03:08:08 --> Router Class Initialized
INFO - 2021-12-01 03:08:08 --> Output Class Initialized
INFO - 2021-12-01 03:08:08 --> Security Class Initialized
DEBUG - 2021-12-01 03:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:08:08 --> Input Class Initialized
INFO - 2021-12-01 03:08:08 --> Language Class Initialized
INFO - 2021-12-01 03:08:08 --> Language Class Initialized
INFO - 2021-12-01 03:08:08 --> Config Class Initialized
INFO - 2021-12-01 03:08:08 --> Loader Class Initialized
INFO - 2021-12-01 03:08:08 --> Helper loaded: url_helper
INFO - 2021-12-01 03:08:08 --> Helper loaded: file_helper
INFO - 2021-12-01 03:08:08 --> Helper loaded: form_helper
INFO - 2021-12-01 03:08:08 --> Helper loaded: my_helper
INFO - 2021-12-01 03:08:08 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:08:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:08:08 --> Controller Class Initialized
INFO - 2021-12-01 03:08:08 --> Helper loaded: cookie_helper
INFO - 2021-12-01 03:08:08 --> Final output sent to browser
DEBUG - 2021-12-01 03:08:08 --> Total execution time: 0.0927
INFO - 2021-12-01 03:08:08 --> Config Class Initialized
INFO - 2021-12-01 03:08:08 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:08:08 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:08:08 --> Utf8 Class Initialized
INFO - 2021-12-01 03:08:08 --> URI Class Initialized
INFO - 2021-12-01 03:08:08 --> Router Class Initialized
INFO - 2021-12-01 03:08:08 --> Output Class Initialized
INFO - 2021-12-01 03:08:08 --> Security Class Initialized
DEBUG - 2021-12-01 03:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:08:08 --> Input Class Initialized
INFO - 2021-12-01 03:08:08 --> Language Class Initialized
INFO - 2021-12-01 03:08:08 --> Language Class Initialized
INFO - 2021-12-01 03:08:08 --> Config Class Initialized
INFO - 2021-12-01 03:08:08 --> Loader Class Initialized
INFO - 2021-12-01 03:08:08 --> Helper loaded: url_helper
INFO - 2021-12-01 03:08:08 --> Helper loaded: file_helper
INFO - 2021-12-01 03:08:08 --> Helper loaded: form_helper
INFO - 2021-12-01 03:08:08 --> Helper loaded: my_helper
INFO - 2021-12-01 03:08:08 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:08:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:08:09 --> Controller Class Initialized
DEBUG - 2021-12-01 03:08:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-01 03:08:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 03:08:09 --> Final output sent to browser
DEBUG - 2021-12-01 03:08:09 --> Total execution time: 0.9583
INFO - 2021-12-01 03:20:20 --> Config Class Initialized
INFO - 2021-12-01 03:20:20 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:20:20 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:20:20 --> Utf8 Class Initialized
INFO - 2021-12-01 03:20:20 --> URI Class Initialized
INFO - 2021-12-01 03:20:20 --> Router Class Initialized
INFO - 2021-12-01 03:20:20 --> Output Class Initialized
INFO - 2021-12-01 03:20:20 --> Security Class Initialized
DEBUG - 2021-12-01 03:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:20:20 --> Input Class Initialized
INFO - 2021-12-01 03:20:20 --> Language Class Initialized
INFO - 2021-12-01 03:20:20 --> Language Class Initialized
INFO - 2021-12-01 03:20:20 --> Config Class Initialized
INFO - 2021-12-01 03:20:20 --> Loader Class Initialized
INFO - 2021-12-01 03:20:20 --> Helper loaded: url_helper
INFO - 2021-12-01 03:20:20 --> Helper loaded: file_helper
INFO - 2021-12-01 03:20:20 --> Helper loaded: form_helper
INFO - 2021-12-01 03:20:20 --> Helper loaded: my_helper
INFO - 2021-12-01 03:20:20 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:20:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:20:20 --> Controller Class Initialized
DEBUG - 2021-12-01 03:20:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-12-01 03:20:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 03:20:20 --> Final output sent to browser
DEBUG - 2021-12-01 03:20:20 --> Total execution time: 0.0969
INFO - 2021-12-01 03:20:23 --> Config Class Initialized
INFO - 2021-12-01 03:20:23 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:20:23 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:20:23 --> Utf8 Class Initialized
INFO - 2021-12-01 03:20:23 --> URI Class Initialized
INFO - 2021-12-01 03:20:23 --> Router Class Initialized
INFO - 2021-12-01 03:20:23 --> Output Class Initialized
INFO - 2021-12-01 03:20:23 --> Security Class Initialized
DEBUG - 2021-12-01 03:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:20:23 --> Input Class Initialized
INFO - 2021-12-01 03:20:23 --> Language Class Initialized
INFO - 2021-12-01 03:20:23 --> Language Class Initialized
INFO - 2021-12-01 03:20:23 --> Config Class Initialized
INFO - 2021-12-01 03:20:23 --> Loader Class Initialized
INFO - 2021-12-01 03:20:23 --> Helper loaded: url_helper
INFO - 2021-12-01 03:20:23 --> Helper loaded: file_helper
INFO - 2021-12-01 03:20:23 --> Helper loaded: form_helper
INFO - 2021-12-01 03:20:23 --> Helper loaded: my_helper
INFO - 2021-12-01 03:20:23 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:20:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:20:23 --> Controller Class Initialized
DEBUG - 2021-12-01 03:20:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tkro_xi.php
INFO - 2021-12-01 03:20:23 --> Final output sent to browser
DEBUG - 2021-12-01 03:20:23 --> Total execution time: 0.2986
INFO - 2021-12-01 03:21:20 --> Config Class Initialized
INFO - 2021-12-01 03:21:20 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:21:20 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:21:20 --> Utf8 Class Initialized
INFO - 2021-12-01 03:21:20 --> URI Class Initialized
INFO - 2021-12-01 03:21:20 --> Router Class Initialized
INFO - 2021-12-01 03:21:20 --> Output Class Initialized
INFO - 2021-12-01 03:21:20 --> Security Class Initialized
DEBUG - 2021-12-01 03:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:21:20 --> Input Class Initialized
INFO - 2021-12-01 03:21:20 --> Language Class Initialized
INFO - 2021-12-01 03:21:20 --> Language Class Initialized
INFO - 2021-12-01 03:21:20 --> Config Class Initialized
INFO - 2021-12-01 03:21:20 --> Loader Class Initialized
INFO - 2021-12-01 03:21:20 --> Helper loaded: url_helper
INFO - 2021-12-01 03:21:20 --> Helper loaded: file_helper
INFO - 2021-12-01 03:21:20 --> Helper loaded: form_helper
INFO - 2021-12-01 03:21:20 --> Helper loaded: my_helper
INFO - 2021-12-01 03:21:20 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:21:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:21:20 --> Controller Class Initialized
DEBUG - 2021-12-01 03:21:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-01 03:21:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 03:21:20 --> Final output sent to browser
DEBUG - 2021-12-01 03:21:20 --> Total execution time: 0.1007
INFO - 2021-12-01 03:21:25 --> Config Class Initialized
INFO - 2021-12-01 03:21:25 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:21:25 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:21:25 --> Utf8 Class Initialized
INFO - 2021-12-01 03:21:25 --> URI Class Initialized
INFO - 2021-12-01 03:21:25 --> Router Class Initialized
INFO - 2021-12-01 03:21:25 --> Output Class Initialized
INFO - 2021-12-01 03:21:25 --> Security Class Initialized
DEBUG - 2021-12-01 03:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:21:25 --> Input Class Initialized
INFO - 2021-12-01 03:21:25 --> Language Class Initialized
INFO - 2021-12-01 03:21:25 --> Language Class Initialized
INFO - 2021-12-01 03:21:25 --> Config Class Initialized
INFO - 2021-12-01 03:21:25 --> Loader Class Initialized
INFO - 2021-12-01 03:21:25 --> Helper loaded: url_helper
INFO - 2021-12-01 03:21:25 --> Helper loaded: file_helper
INFO - 2021-12-01 03:21:25 --> Helper loaded: form_helper
INFO - 2021-12-01 03:21:25 --> Helper loaded: my_helper
INFO - 2021-12-01 03:21:25 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:21:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:21:25 --> Controller Class Initialized
DEBUG - 2021-12-01 03:21:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-01 03:21:25 --> Final output sent to browser
DEBUG - 2021-12-01 03:21:25 --> Total execution time: 0.2083
INFO - 2021-12-01 03:21:56 --> Config Class Initialized
INFO - 2021-12-01 03:21:56 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:21:56 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:21:56 --> Utf8 Class Initialized
INFO - 2021-12-01 03:21:56 --> URI Class Initialized
INFO - 2021-12-01 03:21:56 --> Router Class Initialized
INFO - 2021-12-01 03:21:56 --> Output Class Initialized
INFO - 2021-12-01 03:21:56 --> Security Class Initialized
DEBUG - 2021-12-01 03:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:21:56 --> Input Class Initialized
INFO - 2021-12-01 03:21:56 --> Language Class Initialized
INFO - 2021-12-01 03:21:56 --> Language Class Initialized
INFO - 2021-12-01 03:21:56 --> Config Class Initialized
INFO - 2021-12-01 03:21:56 --> Loader Class Initialized
INFO - 2021-12-01 03:21:56 --> Helper loaded: url_helper
INFO - 2021-12-01 03:21:56 --> Helper loaded: file_helper
INFO - 2021-12-01 03:21:56 --> Helper loaded: form_helper
INFO - 2021-12-01 03:21:56 --> Helper loaded: my_helper
INFO - 2021-12-01 03:21:56 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:21:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:21:56 --> Controller Class Initialized
DEBUG - 2021-12-01 03:21:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-01 03:21:56 --> Final output sent to browser
DEBUG - 2021-12-01 03:21:56 --> Total execution time: 0.1829
INFO - 2021-12-01 03:22:10 --> Config Class Initialized
INFO - 2021-12-01 03:22:10 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:22:10 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:22:10 --> Utf8 Class Initialized
INFO - 2021-12-01 03:22:10 --> URI Class Initialized
INFO - 2021-12-01 03:22:10 --> Router Class Initialized
INFO - 2021-12-01 03:22:10 --> Output Class Initialized
INFO - 2021-12-01 03:22:10 --> Security Class Initialized
DEBUG - 2021-12-01 03:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:22:10 --> Input Class Initialized
INFO - 2021-12-01 03:22:10 --> Language Class Initialized
INFO - 2021-12-01 03:22:10 --> Language Class Initialized
INFO - 2021-12-01 03:22:10 --> Config Class Initialized
INFO - 2021-12-01 03:22:10 --> Loader Class Initialized
INFO - 2021-12-01 03:22:10 --> Helper loaded: url_helper
INFO - 2021-12-01 03:22:10 --> Helper loaded: file_helper
INFO - 2021-12-01 03:22:10 --> Helper loaded: form_helper
INFO - 2021-12-01 03:22:10 --> Helper loaded: my_helper
INFO - 2021-12-01 03:22:10 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:22:10 --> Controller Class Initialized
DEBUG - 2021-12-01 03:22:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-01 03:22:10 --> Final output sent to browser
DEBUG - 2021-12-01 03:22:10 --> Total execution time: 0.1944
INFO - 2021-12-01 03:22:12 --> Config Class Initialized
INFO - 2021-12-01 03:22:12 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:22:12 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:22:12 --> Utf8 Class Initialized
INFO - 2021-12-01 03:22:12 --> URI Class Initialized
INFO - 2021-12-01 03:22:12 --> Router Class Initialized
INFO - 2021-12-01 03:22:12 --> Output Class Initialized
INFO - 2021-12-01 03:22:12 --> Security Class Initialized
DEBUG - 2021-12-01 03:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:22:12 --> Input Class Initialized
INFO - 2021-12-01 03:22:12 --> Language Class Initialized
INFO - 2021-12-01 03:22:12 --> Language Class Initialized
INFO - 2021-12-01 03:22:12 --> Config Class Initialized
INFO - 2021-12-01 03:22:12 --> Loader Class Initialized
INFO - 2021-12-01 03:22:12 --> Helper loaded: url_helper
INFO - 2021-12-01 03:22:12 --> Helper loaded: file_helper
INFO - 2021-12-01 03:22:12 --> Helper loaded: form_helper
INFO - 2021-12-01 03:22:12 --> Helper loaded: my_helper
INFO - 2021-12-01 03:22:12 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:22:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:22:12 --> Controller Class Initialized
DEBUG - 2021-12-01 03:22:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-01 03:22:13 --> Final output sent to browser
DEBUG - 2021-12-01 03:22:13 --> Total execution time: 0.1922
INFO - 2021-12-01 03:22:15 --> Config Class Initialized
INFO - 2021-12-01 03:22:15 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:22:15 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:22:15 --> Utf8 Class Initialized
INFO - 2021-12-01 03:22:15 --> URI Class Initialized
INFO - 2021-12-01 03:22:15 --> Router Class Initialized
INFO - 2021-12-01 03:22:15 --> Output Class Initialized
INFO - 2021-12-01 03:22:15 --> Security Class Initialized
DEBUG - 2021-12-01 03:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:22:15 --> Input Class Initialized
INFO - 2021-12-01 03:22:15 --> Language Class Initialized
INFO - 2021-12-01 03:22:15 --> Language Class Initialized
INFO - 2021-12-01 03:22:15 --> Config Class Initialized
INFO - 2021-12-01 03:22:15 --> Loader Class Initialized
INFO - 2021-12-01 03:22:15 --> Helper loaded: url_helper
INFO - 2021-12-01 03:22:15 --> Helper loaded: file_helper
INFO - 2021-12-01 03:22:15 --> Helper loaded: form_helper
INFO - 2021-12-01 03:22:15 --> Helper loaded: my_helper
INFO - 2021-12-01 03:22:15 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:22:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:22:15 --> Controller Class Initialized
DEBUG - 2021-12-01 03:22:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-01 03:22:15 --> Final output sent to browser
DEBUG - 2021-12-01 03:22:15 --> Total execution time: 0.2241
INFO - 2021-12-01 03:22:17 --> Config Class Initialized
INFO - 2021-12-01 03:22:17 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:22:17 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:22:17 --> Utf8 Class Initialized
INFO - 2021-12-01 03:22:17 --> URI Class Initialized
INFO - 2021-12-01 03:22:17 --> Router Class Initialized
INFO - 2021-12-01 03:22:17 --> Output Class Initialized
INFO - 2021-12-01 03:22:17 --> Security Class Initialized
DEBUG - 2021-12-01 03:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:22:17 --> Input Class Initialized
INFO - 2021-12-01 03:22:17 --> Language Class Initialized
INFO - 2021-12-01 03:22:17 --> Language Class Initialized
INFO - 2021-12-01 03:22:17 --> Config Class Initialized
INFO - 2021-12-01 03:22:17 --> Loader Class Initialized
INFO - 2021-12-01 03:22:17 --> Helper loaded: url_helper
INFO - 2021-12-01 03:22:17 --> Helper loaded: file_helper
INFO - 2021-12-01 03:22:17 --> Helper loaded: form_helper
INFO - 2021-12-01 03:22:17 --> Helper loaded: my_helper
INFO - 2021-12-01 03:22:17 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:22:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:22:17 --> Controller Class Initialized
DEBUG - 2021-12-01 03:22:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-01 03:22:17 --> Final output sent to browser
DEBUG - 2021-12-01 03:22:17 --> Total execution time: 0.2281
INFO - 2021-12-01 03:22:19 --> Config Class Initialized
INFO - 2021-12-01 03:22:19 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:22:19 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:22:19 --> Utf8 Class Initialized
INFO - 2021-12-01 03:22:19 --> URI Class Initialized
INFO - 2021-12-01 03:22:19 --> Router Class Initialized
INFO - 2021-12-01 03:22:19 --> Output Class Initialized
INFO - 2021-12-01 03:22:19 --> Security Class Initialized
DEBUG - 2021-12-01 03:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:22:19 --> Input Class Initialized
INFO - 2021-12-01 03:22:19 --> Language Class Initialized
INFO - 2021-12-01 03:22:19 --> Language Class Initialized
INFO - 2021-12-01 03:22:19 --> Config Class Initialized
INFO - 2021-12-01 03:22:19 --> Loader Class Initialized
INFO - 2021-12-01 03:22:19 --> Helper loaded: url_helper
INFO - 2021-12-01 03:22:19 --> Helper loaded: file_helper
INFO - 2021-12-01 03:22:19 --> Helper loaded: form_helper
INFO - 2021-12-01 03:22:19 --> Helper loaded: my_helper
INFO - 2021-12-01 03:22:19 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:22:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:22:19 --> Controller Class Initialized
DEBUG - 2021-12-01 03:22:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-01 03:22:19 --> Final output sent to browser
DEBUG - 2021-12-01 03:22:19 --> Total execution time: 0.2098
INFO - 2021-12-01 03:22:22 --> Config Class Initialized
INFO - 2021-12-01 03:22:22 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:22:22 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:22:22 --> Utf8 Class Initialized
INFO - 2021-12-01 03:22:22 --> URI Class Initialized
INFO - 2021-12-01 03:22:22 --> Router Class Initialized
INFO - 2021-12-01 03:22:22 --> Output Class Initialized
INFO - 2021-12-01 03:22:22 --> Security Class Initialized
DEBUG - 2021-12-01 03:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:22:22 --> Input Class Initialized
INFO - 2021-12-01 03:22:22 --> Language Class Initialized
INFO - 2021-12-01 03:22:22 --> Language Class Initialized
INFO - 2021-12-01 03:22:22 --> Config Class Initialized
INFO - 2021-12-01 03:22:22 --> Loader Class Initialized
INFO - 2021-12-01 03:22:22 --> Helper loaded: url_helper
INFO - 2021-12-01 03:22:22 --> Helper loaded: file_helper
INFO - 2021-12-01 03:22:22 --> Helper loaded: form_helper
INFO - 2021-12-01 03:22:22 --> Helper loaded: my_helper
INFO - 2021-12-01 03:22:22 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:22:22 --> Controller Class Initialized
DEBUG - 2021-12-01 03:22:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-01 03:22:22 --> Final output sent to browser
DEBUG - 2021-12-01 03:22:22 --> Total execution time: 0.2136
INFO - 2021-12-01 03:22:24 --> Config Class Initialized
INFO - 2021-12-01 03:22:24 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:22:24 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:22:24 --> Utf8 Class Initialized
INFO - 2021-12-01 03:22:24 --> URI Class Initialized
INFO - 2021-12-01 03:22:24 --> Router Class Initialized
INFO - 2021-12-01 03:22:24 --> Output Class Initialized
INFO - 2021-12-01 03:22:24 --> Security Class Initialized
DEBUG - 2021-12-01 03:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:22:24 --> Input Class Initialized
INFO - 2021-12-01 03:22:24 --> Language Class Initialized
INFO - 2021-12-01 03:22:24 --> Language Class Initialized
INFO - 2021-12-01 03:22:24 --> Config Class Initialized
INFO - 2021-12-01 03:22:24 --> Loader Class Initialized
INFO - 2021-12-01 03:22:24 --> Helper loaded: url_helper
INFO - 2021-12-01 03:22:24 --> Helper loaded: file_helper
INFO - 2021-12-01 03:22:24 --> Helper loaded: form_helper
INFO - 2021-12-01 03:22:24 --> Helper loaded: my_helper
INFO - 2021-12-01 03:22:24 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:22:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:22:24 --> Controller Class Initialized
DEBUG - 2021-12-01 03:22:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-01 03:22:24 --> Final output sent to browser
DEBUG - 2021-12-01 03:22:24 --> Total execution time: 0.2076
INFO - 2021-12-01 03:22:26 --> Config Class Initialized
INFO - 2021-12-01 03:22:26 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:22:26 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:22:26 --> Utf8 Class Initialized
INFO - 2021-12-01 03:22:26 --> URI Class Initialized
INFO - 2021-12-01 03:22:26 --> Router Class Initialized
INFO - 2021-12-01 03:22:26 --> Output Class Initialized
INFO - 2021-12-01 03:22:26 --> Security Class Initialized
DEBUG - 2021-12-01 03:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:22:26 --> Input Class Initialized
INFO - 2021-12-01 03:22:26 --> Language Class Initialized
INFO - 2021-12-01 03:22:26 --> Language Class Initialized
INFO - 2021-12-01 03:22:26 --> Config Class Initialized
INFO - 2021-12-01 03:22:26 --> Loader Class Initialized
INFO - 2021-12-01 03:22:26 --> Helper loaded: url_helper
INFO - 2021-12-01 03:22:26 --> Helper loaded: file_helper
INFO - 2021-12-01 03:22:26 --> Helper loaded: form_helper
INFO - 2021-12-01 03:22:26 --> Helper loaded: my_helper
INFO - 2021-12-01 03:22:26 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:22:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:22:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:22:26 --> Controller Class Initialized
DEBUG - 2021-12-01 03:22:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-01 03:22:26 --> Final output sent to browser
DEBUG - 2021-12-01 03:22:26 --> Total execution time: 0.1951
INFO - 2021-12-01 03:22:28 --> Config Class Initialized
INFO - 2021-12-01 03:22:28 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:22:28 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:22:28 --> Utf8 Class Initialized
INFO - 2021-12-01 03:22:28 --> URI Class Initialized
INFO - 2021-12-01 03:22:28 --> Router Class Initialized
INFO - 2021-12-01 03:22:28 --> Output Class Initialized
INFO - 2021-12-01 03:22:28 --> Security Class Initialized
DEBUG - 2021-12-01 03:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:22:28 --> Input Class Initialized
INFO - 2021-12-01 03:22:28 --> Language Class Initialized
INFO - 2021-12-01 03:22:29 --> Language Class Initialized
INFO - 2021-12-01 03:22:29 --> Config Class Initialized
INFO - 2021-12-01 03:22:29 --> Loader Class Initialized
INFO - 2021-12-01 03:22:29 --> Helper loaded: url_helper
INFO - 2021-12-01 03:22:29 --> Helper loaded: file_helper
INFO - 2021-12-01 03:22:29 --> Helper loaded: form_helper
INFO - 2021-12-01 03:22:29 --> Helper loaded: my_helper
INFO - 2021-12-01 03:22:29 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:22:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:22:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:22:29 --> Controller Class Initialized
DEBUG - 2021-12-01 03:22:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-01 03:22:29 --> Final output sent to browser
DEBUG - 2021-12-01 03:22:29 --> Total execution time: 0.1879
INFO - 2021-12-01 03:22:31 --> Config Class Initialized
INFO - 2021-12-01 03:22:31 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:22:31 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:22:31 --> Utf8 Class Initialized
INFO - 2021-12-01 03:22:31 --> URI Class Initialized
INFO - 2021-12-01 03:22:31 --> Router Class Initialized
INFO - 2021-12-01 03:22:31 --> Output Class Initialized
INFO - 2021-12-01 03:22:31 --> Security Class Initialized
DEBUG - 2021-12-01 03:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:22:31 --> Input Class Initialized
INFO - 2021-12-01 03:22:31 --> Language Class Initialized
INFO - 2021-12-01 03:22:31 --> Language Class Initialized
INFO - 2021-12-01 03:22:31 --> Config Class Initialized
INFO - 2021-12-01 03:22:31 --> Loader Class Initialized
INFO - 2021-12-01 03:22:31 --> Helper loaded: url_helper
INFO - 2021-12-01 03:22:31 --> Helper loaded: file_helper
INFO - 2021-12-01 03:22:31 --> Helper loaded: form_helper
INFO - 2021-12-01 03:22:31 --> Helper loaded: my_helper
INFO - 2021-12-01 03:22:31 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:22:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:22:31 --> Controller Class Initialized
DEBUG - 2021-12-01 03:22:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-01 03:22:31 --> Final output sent to browser
DEBUG - 2021-12-01 03:22:31 --> Total execution time: 0.1960
INFO - 2021-12-01 03:22:33 --> Config Class Initialized
INFO - 2021-12-01 03:22:33 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:22:33 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:22:33 --> Utf8 Class Initialized
INFO - 2021-12-01 03:22:33 --> URI Class Initialized
INFO - 2021-12-01 03:22:33 --> Router Class Initialized
INFO - 2021-12-01 03:22:33 --> Output Class Initialized
INFO - 2021-12-01 03:22:33 --> Security Class Initialized
DEBUG - 2021-12-01 03:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:22:33 --> Input Class Initialized
INFO - 2021-12-01 03:22:33 --> Language Class Initialized
INFO - 2021-12-01 03:22:33 --> Language Class Initialized
INFO - 2021-12-01 03:22:33 --> Config Class Initialized
INFO - 2021-12-01 03:22:33 --> Loader Class Initialized
INFO - 2021-12-01 03:22:33 --> Helper loaded: url_helper
INFO - 2021-12-01 03:22:33 --> Helper loaded: file_helper
INFO - 2021-12-01 03:22:33 --> Helper loaded: form_helper
INFO - 2021-12-01 03:22:33 --> Helper loaded: my_helper
INFO - 2021-12-01 03:22:33 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:22:33 --> Controller Class Initialized
DEBUG - 2021-12-01 03:22:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-01 03:22:33 --> Final output sent to browser
DEBUG - 2021-12-01 03:22:33 --> Total execution time: 0.1773
INFO - 2021-12-01 03:22:36 --> Config Class Initialized
INFO - 2021-12-01 03:22:36 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:22:36 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:22:36 --> Utf8 Class Initialized
INFO - 2021-12-01 03:22:36 --> URI Class Initialized
INFO - 2021-12-01 03:22:36 --> Router Class Initialized
INFO - 2021-12-01 03:22:36 --> Output Class Initialized
INFO - 2021-12-01 03:22:36 --> Security Class Initialized
DEBUG - 2021-12-01 03:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:22:36 --> Input Class Initialized
INFO - 2021-12-01 03:22:36 --> Language Class Initialized
INFO - 2021-12-01 03:22:36 --> Language Class Initialized
INFO - 2021-12-01 03:22:36 --> Config Class Initialized
INFO - 2021-12-01 03:22:36 --> Loader Class Initialized
INFO - 2021-12-01 03:22:36 --> Helper loaded: url_helper
INFO - 2021-12-01 03:22:36 --> Helper loaded: file_helper
INFO - 2021-12-01 03:22:36 --> Helper loaded: form_helper
INFO - 2021-12-01 03:22:36 --> Helper loaded: my_helper
INFO - 2021-12-01 03:22:36 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:22:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:22:36 --> Controller Class Initialized
DEBUG - 2021-12-01 03:22:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-01 03:22:36 --> Final output sent to browser
DEBUG - 2021-12-01 03:22:36 --> Total execution time: 0.2072
INFO - 2021-12-01 03:22:38 --> Config Class Initialized
INFO - 2021-12-01 03:22:38 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:22:38 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:22:38 --> Utf8 Class Initialized
INFO - 2021-12-01 03:22:39 --> URI Class Initialized
INFO - 2021-12-01 03:22:39 --> Router Class Initialized
INFO - 2021-12-01 03:22:39 --> Output Class Initialized
INFO - 2021-12-01 03:22:39 --> Security Class Initialized
DEBUG - 2021-12-01 03:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:22:39 --> Input Class Initialized
INFO - 2021-12-01 03:22:39 --> Language Class Initialized
INFO - 2021-12-01 03:22:39 --> Language Class Initialized
INFO - 2021-12-01 03:22:39 --> Config Class Initialized
INFO - 2021-12-01 03:22:39 --> Loader Class Initialized
INFO - 2021-12-01 03:22:39 --> Helper loaded: url_helper
INFO - 2021-12-01 03:22:39 --> Helper loaded: file_helper
INFO - 2021-12-01 03:22:39 --> Helper loaded: form_helper
INFO - 2021-12-01 03:22:39 --> Helper loaded: my_helper
INFO - 2021-12-01 03:22:39 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:22:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:22:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:22:39 --> Controller Class Initialized
DEBUG - 2021-12-01 03:22:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-01 03:22:39 --> Final output sent to browser
DEBUG - 2021-12-01 03:22:39 --> Total execution time: 0.1974
INFO - 2021-12-01 03:22:40 --> Config Class Initialized
INFO - 2021-12-01 03:22:40 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:22:40 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:22:40 --> Utf8 Class Initialized
INFO - 2021-12-01 03:22:40 --> URI Class Initialized
INFO - 2021-12-01 03:22:40 --> Router Class Initialized
INFO - 2021-12-01 03:22:40 --> Output Class Initialized
INFO - 2021-12-01 03:22:40 --> Security Class Initialized
DEBUG - 2021-12-01 03:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:22:40 --> Input Class Initialized
INFO - 2021-12-01 03:22:40 --> Language Class Initialized
INFO - 2021-12-01 03:22:40 --> Language Class Initialized
INFO - 2021-12-01 03:22:40 --> Config Class Initialized
INFO - 2021-12-01 03:22:40 --> Loader Class Initialized
INFO - 2021-12-01 03:22:40 --> Helper loaded: url_helper
INFO - 2021-12-01 03:22:40 --> Helper loaded: file_helper
INFO - 2021-12-01 03:22:40 --> Helper loaded: form_helper
INFO - 2021-12-01 03:22:40 --> Helper loaded: my_helper
INFO - 2021-12-01 03:22:41 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:22:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:22:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:22:41 --> Controller Class Initialized
DEBUG - 2021-12-01 03:22:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-01 03:22:41 --> Final output sent to browser
DEBUG - 2021-12-01 03:22:41 --> Total execution time: 0.1874
INFO - 2021-12-01 03:22:43 --> Config Class Initialized
INFO - 2021-12-01 03:22:43 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:22:43 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:22:43 --> Utf8 Class Initialized
INFO - 2021-12-01 03:22:43 --> URI Class Initialized
INFO - 2021-12-01 03:22:43 --> Router Class Initialized
INFO - 2021-12-01 03:22:43 --> Output Class Initialized
INFO - 2021-12-01 03:22:43 --> Security Class Initialized
DEBUG - 2021-12-01 03:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:22:43 --> Input Class Initialized
INFO - 2021-12-01 03:22:43 --> Language Class Initialized
INFO - 2021-12-01 03:22:43 --> Language Class Initialized
INFO - 2021-12-01 03:22:43 --> Config Class Initialized
INFO - 2021-12-01 03:22:43 --> Loader Class Initialized
INFO - 2021-12-01 03:22:43 --> Helper loaded: url_helper
INFO - 2021-12-01 03:22:43 --> Helper loaded: file_helper
INFO - 2021-12-01 03:22:43 --> Helper loaded: form_helper
INFO - 2021-12-01 03:22:43 --> Helper loaded: my_helper
INFO - 2021-12-01 03:22:43 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:22:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:22:43 --> Controller Class Initialized
DEBUG - 2021-12-01 03:22:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-01 03:22:43 --> Final output sent to browser
DEBUG - 2021-12-01 03:22:43 --> Total execution time: 0.2105
INFO - 2021-12-01 03:22:45 --> Config Class Initialized
INFO - 2021-12-01 03:22:45 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:22:45 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:22:45 --> Utf8 Class Initialized
INFO - 2021-12-01 03:22:45 --> URI Class Initialized
INFO - 2021-12-01 03:22:45 --> Router Class Initialized
INFO - 2021-12-01 03:22:45 --> Output Class Initialized
INFO - 2021-12-01 03:22:45 --> Security Class Initialized
DEBUG - 2021-12-01 03:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:22:45 --> Input Class Initialized
INFO - 2021-12-01 03:22:45 --> Language Class Initialized
INFO - 2021-12-01 03:22:45 --> Language Class Initialized
INFO - 2021-12-01 03:22:45 --> Config Class Initialized
INFO - 2021-12-01 03:22:45 --> Loader Class Initialized
INFO - 2021-12-01 03:22:45 --> Helper loaded: url_helper
INFO - 2021-12-01 03:22:45 --> Helper loaded: file_helper
INFO - 2021-12-01 03:22:45 --> Helper loaded: form_helper
INFO - 2021-12-01 03:22:45 --> Helper loaded: my_helper
INFO - 2021-12-01 03:22:45 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:22:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:22:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:22:45 --> Controller Class Initialized
DEBUG - 2021-12-01 03:22:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-01 03:22:45 --> Final output sent to browser
DEBUG - 2021-12-01 03:22:45 --> Total execution time: 0.2211
INFO - 2021-12-01 03:22:47 --> Config Class Initialized
INFO - 2021-12-01 03:22:47 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:22:47 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:22:47 --> Utf8 Class Initialized
INFO - 2021-12-01 03:22:47 --> URI Class Initialized
INFO - 2021-12-01 03:22:47 --> Router Class Initialized
INFO - 2021-12-01 03:22:47 --> Output Class Initialized
INFO - 2021-12-01 03:22:47 --> Security Class Initialized
DEBUG - 2021-12-01 03:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:22:47 --> Input Class Initialized
INFO - 2021-12-01 03:22:47 --> Language Class Initialized
INFO - 2021-12-01 03:22:47 --> Language Class Initialized
INFO - 2021-12-01 03:22:47 --> Config Class Initialized
INFO - 2021-12-01 03:22:47 --> Loader Class Initialized
INFO - 2021-12-01 03:22:47 --> Helper loaded: url_helper
INFO - 2021-12-01 03:22:47 --> Helper loaded: file_helper
INFO - 2021-12-01 03:22:47 --> Helper loaded: form_helper
INFO - 2021-12-01 03:22:47 --> Helper loaded: my_helper
INFO - 2021-12-01 03:22:47 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:22:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:22:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:22:47 --> Controller Class Initialized
DEBUG - 2021-12-01 03:22:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-01 03:22:47 --> Final output sent to browser
DEBUG - 2021-12-01 03:22:47 --> Total execution time: 0.2064
INFO - 2021-12-01 03:22:49 --> Config Class Initialized
INFO - 2021-12-01 03:22:49 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:22:49 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:22:49 --> Utf8 Class Initialized
INFO - 2021-12-01 03:22:49 --> URI Class Initialized
INFO - 2021-12-01 03:22:49 --> Router Class Initialized
INFO - 2021-12-01 03:22:49 --> Output Class Initialized
INFO - 2021-12-01 03:22:49 --> Security Class Initialized
DEBUG - 2021-12-01 03:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:22:49 --> Input Class Initialized
INFO - 2021-12-01 03:22:49 --> Language Class Initialized
INFO - 2021-12-01 03:22:49 --> Language Class Initialized
INFO - 2021-12-01 03:22:49 --> Config Class Initialized
INFO - 2021-12-01 03:22:49 --> Loader Class Initialized
INFO - 2021-12-01 03:22:49 --> Helper loaded: url_helper
INFO - 2021-12-01 03:22:49 --> Helper loaded: file_helper
INFO - 2021-12-01 03:22:49 --> Helper loaded: form_helper
INFO - 2021-12-01 03:22:49 --> Helper loaded: my_helper
INFO - 2021-12-01 03:22:49 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:22:49 --> Controller Class Initialized
DEBUG - 2021-12-01 03:22:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-01 03:22:49 --> Final output sent to browser
DEBUG - 2021-12-01 03:22:49 --> Total execution time: 0.1836
INFO - 2021-12-01 03:22:51 --> Config Class Initialized
INFO - 2021-12-01 03:22:51 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:22:51 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:22:51 --> Utf8 Class Initialized
INFO - 2021-12-01 03:22:51 --> URI Class Initialized
INFO - 2021-12-01 03:22:51 --> Router Class Initialized
INFO - 2021-12-01 03:22:51 --> Output Class Initialized
INFO - 2021-12-01 03:22:51 --> Security Class Initialized
DEBUG - 2021-12-01 03:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:22:51 --> Input Class Initialized
INFO - 2021-12-01 03:22:51 --> Language Class Initialized
INFO - 2021-12-01 03:22:51 --> Language Class Initialized
INFO - 2021-12-01 03:22:51 --> Config Class Initialized
INFO - 2021-12-01 03:22:51 --> Loader Class Initialized
INFO - 2021-12-01 03:22:51 --> Helper loaded: url_helper
INFO - 2021-12-01 03:22:51 --> Helper loaded: file_helper
INFO - 2021-12-01 03:22:51 --> Helper loaded: form_helper
INFO - 2021-12-01 03:22:51 --> Helper loaded: my_helper
INFO - 2021-12-01 03:22:51 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:22:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:22:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:22:51 --> Controller Class Initialized
DEBUG - 2021-12-01 03:22:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-01 03:22:51 --> Final output sent to browser
DEBUG - 2021-12-01 03:22:51 --> Total execution time: 0.2052
INFO - 2021-12-01 03:22:54 --> Config Class Initialized
INFO - 2021-12-01 03:22:54 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:22:54 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:22:54 --> Utf8 Class Initialized
INFO - 2021-12-01 03:22:54 --> URI Class Initialized
INFO - 2021-12-01 03:22:54 --> Router Class Initialized
INFO - 2021-12-01 03:22:54 --> Output Class Initialized
INFO - 2021-12-01 03:22:54 --> Security Class Initialized
DEBUG - 2021-12-01 03:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:22:54 --> Input Class Initialized
INFO - 2021-12-01 03:22:54 --> Language Class Initialized
INFO - 2021-12-01 03:22:54 --> Language Class Initialized
INFO - 2021-12-01 03:22:54 --> Config Class Initialized
INFO - 2021-12-01 03:22:54 --> Loader Class Initialized
INFO - 2021-12-01 03:22:54 --> Helper loaded: url_helper
INFO - 2021-12-01 03:22:54 --> Helper loaded: file_helper
INFO - 2021-12-01 03:22:54 --> Helper loaded: form_helper
INFO - 2021-12-01 03:22:54 --> Helper loaded: my_helper
INFO - 2021-12-01 03:22:54 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:22:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:22:54 --> Controller Class Initialized
DEBUG - 2021-12-01 03:22:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-01 03:22:54 --> Final output sent to browser
DEBUG - 2021-12-01 03:22:54 --> Total execution time: 0.2023
INFO - 2021-12-01 03:22:56 --> Config Class Initialized
INFO - 2021-12-01 03:22:56 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:22:56 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:22:56 --> Utf8 Class Initialized
INFO - 2021-12-01 03:22:56 --> URI Class Initialized
INFO - 2021-12-01 03:22:56 --> Router Class Initialized
INFO - 2021-12-01 03:22:56 --> Output Class Initialized
INFO - 2021-12-01 03:22:56 --> Security Class Initialized
DEBUG - 2021-12-01 03:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:22:56 --> Input Class Initialized
INFO - 2021-12-01 03:22:56 --> Language Class Initialized
INFO - 2021-12-01 03:22:56 --> Language Class Initialized
INFO - 2021-12-01 03:22:56 --> Config Class Initialized
INFO - 2021-12-01 03:22:56 --> Loader Class Initialized
INFO - 2021-12-01 03:22:56 --> Helper loaded: url_helper
INFO - 2021-12-01 03:22:56 --> Helper loaded: file_helper
INFO - 2021-12-01 03:22:56 --> Helper loaded: form_helper
INFO - 2021-12-01 03:22:56 --> Helper loaded: my_helper
INFO - 2021-12-01 03:22:56 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:22:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:22:56 --> Controller Class Initialized
DEBUG - 2021-12-01 03:22:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-01 03:22:57 --> Final output sent to browser
DEBUG - 2021-12-01 03:22:57 --> Total execution time: 0.1996
INFO - 2021-12-01 03:23:00 --> Config Class Initialized
INFO - 2021-12-01 03:23:00 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:23:00 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:23:00 --> Utf8 Class Initialized
INFO - 2021-12-01 03:23:00 --> URI Class Initialized
INFO - 2021-12-01 03:23:00 --> Router Class Initialized
INFO - 2021-12-01 03:23:00 --> Output Class Initialized
INFO - 2021-12-01 03:23:00 --> Security Class Initialized
DEBUG - 2021-12-01 03:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:23:00 --> Input Class Initialized
INFO - 2021-12-01 03:23:00 --> Language Class Initialized
INFO - 2021-12-01 03:23:00 --> Language Class Initialized
INFO - 2021-12-01 03:23:00 --> Config Class Initialized
INFO - 2021-12-01 03:23:00 --> Loader Class Initialized
INFO - 2021-12-01 03:23:00 --> Helper loaded: url_helper
INFO - 2021-12-01 03:23:00 --> Helper loaded: file_helper
INFO - 2021-12-01 03:23:00 --> Helper loaded: form_helper
INFO - 2021-12-01 03:23:00 --> Helper loaded: my_helper
INFO - 2021-12-01 03:23:00 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:23:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:23:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:23:00 --> Controller Class Initialized
DEBUG - 2021-12-01 03:23:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-01 03:23:00 --> Final output sent to browser
DEBUG - 2021-12-01 03:23:00 --> Total execution time: 0.2110
INFO - 2021-12-01 03:23:02 --> Config Class Initialized
INFO - 2021-12-01 03:23:02 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:23:02 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:23:02 --> Utf8 Class Initialized
INFO - 2021-12-01 03:23:02 --> URI Class Initialized
INFO - 2021-12-01 03:23:02 --> Router Class Initialized
INFO - 2021-12-01 03:23:02 --> Output Class Initialized
INFO - 2021-12-01 03:23:02 --> Security Class Initialized
DEBUG - 2021-12-01 03:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:23:03 --> Input Class Initialized
INFO - 2021-12-01 03:23:03 --> Language Class Initialized
INFO - 2021-12-01 03:23:03 --> Language Class Initialized
INFO - 2021-12-01 03:23:03 --> Config Class Initialized
INFO - 2021-12-01 03:23:03 --> Loader Class Initialized
INFO - 2021-12-01 03:23:03 --> Helper loaded: url_helper
INFO - 2021-12-01 03:23:03 --> Helper loaded: file_helper
INFO - 2021-12-01 03:23:03 --> Helper loaded: form_helper
INFO - 2021-12-01 03:23:03 --> Helper loaded: my_helper
INFO - 2021-12-01 03:23:03 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:23:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:23:03 --> Controller Class Initialized
DEBUG - 2021-12-01 03:23:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-01 03:23:03 --> Final output sent to browser
DEBUG - 2021-12-01 03:23:03 --> Total execution time: 0.1816
INFO - 2021-12-01 03:35:19 --> Config Class Initialized
INFO - 2021-12-01 03:35:19 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:35:19 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:35:19 --> Utf8 Class Initialized
INFO - 2021-12-01 03:35:19 --> URI Class Initialized
INFO - 2021-12-01 03:35:19 --> Router Class Initialized
INFO - 2021-12-01 03:35:19 --> Output Class Initialized
INFO - 2021-12-01 03:35:19 --> Security Class Initialized
DEBUG - 2021-12-01 03:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:35:19 --> Input Class Initialized
INFO - 2021-12-01 03:35:19 --> Language Class Initialized
INFO - 2021-12-01 03:35:19 --> Language Class Initialized
INFO - 2021-12-01 03:35:19 --> Config Class Initialized
INFO - 2021-12-01 03:35:19 --> Loader Class Initialized
INFO - 2021-12-01 03:35:19 --> Helper loaded: url_helper
INFO - 2021-12-01 03:35:19 --> Helper loaded: file_helper
INFO - 2021-12-01 03:35:19 --> Helper loaded: form_helper
INFO - 2021-12-01 03:35:19 --> Helper loaded: my_helper
INFO - 2021-12-01 03:35:19 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:35:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:35:19 --> Controller Class Initialized
INFO - 2021-12-01 03:35:19 --> Helper loaded: cookie_helper
INFO - 2021-12-01 03:35:19 --> Config Class Initialized
INFO - 2021-12-01 03:35:19 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:35:19 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:35:19 --> Utf8 Class Initialized
INFO - 2021-12-01 03:35:19 --> URI Class Initialized
INFO - 2021-12-01 03:35:19 --> Router Class Initialized
INFO - 2021-12-01 03:35:19 --> Output Class Initialized
INFO - 2021-12-01 03:35:19 --> Security Class Initialized
DEBUG - 2021-12-01 03:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:35:19 --> Input Class Initialized
INFO - 2021-12-01 03:35:19 --> Language Class Initialized
INFO - 2021-12-01 03:35:19 --> Language Class Initialized
INFO - 2021-12-01 03:35:19 --> Config Class Initialized
INFO - 2021-12-01 03:35:19 --> Loader Class Initialized
INFO - 2021-12-01 03:35:19 --> Helper loaded: url_helper
INFO - 2021-12-01 03:35:19 --> Helper loaded: file_helper
INFO - 2021-12-01 03:35:19 --> Helper loaded: form_helper
INFO - 2021-12-01 03:35:19 --> Helper loaded: my_helper
INFO - 2021-12-01 03:35:19 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:35:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:35:19 --> Controller Class Initialized
DEBUG - 2021-12-01 03:35:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-01 03:35:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 03:35:19 --> Final output sent to browser
DEBUG - 2021-12-01 03:35:19 --> Total execution time: 0.0618
INFO - 2021-12-01 03:35:23 --> Config Class Initialized
INFO - 2021-12-01 03:35:23 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:35:23 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:35:23 --> Utf8 Class Initialized
INFO - 2021-12-01 03:35:23 --> URI Class Initialized
INFO - 2021-12-01 03:35:23 --> Router Class Initialized
INFO - 2021-12-01 03:35:23 --> Output Class Initialized
INFO - 2021-12-01 03:35:23 --> Security Class Initialized
DEBUG - 2021-12-01 03:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:35:23 --> Input Class Initialized
INFO - 2021-12-01 03:35:23 --> Language Class Initialized
INFO - 2021-12-01 03:35:23 --> Language Class Initialized
INFO - 2021-12-01 03:35:23 --> Config Class Initialized
INFO - 2021-12-01 03:35:23 --> Loader Class Initialized
INFO - 2021-12-01 03:35:23 --> Helper loaded: url_helper
INFO - 2021-12-01 03:35:23 --> Helper loaded: file_helper
INFO - 2021-12-01 03:35:23 --> Helper loaded: form_helper
INFO - 2021-12-01 03:35:23 --> Helper loaded: my_helper
INFO - 2021-12-01 03:35:23 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:35:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:35:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:35:23 --> Controller Class Initialized
INFO - 2021-12-01 03:35:23 --> Helper loaded: cookie_helper
INFO - 2021-12-01 03:35:23 --> Final output sent to browser
DEBUG - 2021-12-01 03:35:23 --> Total execution time: 0.0714
INFO - 2021-12-01 03:35:24 --> Config Class Initialized
INFO - 2021-12-01 03:35:24 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:35:24 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:35:24 --> Utf8 Class Initialized
INFO - 2021-12-01 03:35:24 --> URI Class Initialized
INFO - 2021-12-01 03:35:24 --> Router Class Initialized
INFO - 2021-12-01 03:35:24 --> Output Class Initialized
INFO - 2021-12-01 03:35:24 --> Security Class Initialized
DEBUG - 2021-12-01 03:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:35:24 --> Input Class Initialized
INFO - 2021-12-01 03:35:24 --> Language Class Initialized
INFO - 2021-12-01 03:35:24 --> Language Class Initialized
INFO - 2021-12-01 03:35:24 --> Config Class Initialized
INFO - 2021-12-01 03:35:24 --> Loader Class Initialized
INFO - 2021-12-01 03:35:24 --> Helper loaded: url_helper
INFO - 2021-12-01 03:35:24 --> Helper loaded: file_helper
INFO - 2021-12-01 03:35:24 --> Helper loaded: form_helper
INFO - 2021-12-01 03:35:24 --> Helper loaded: my_helper
INFO - 2021-12-01 03:35:24 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:35:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:35:24 --> Controller Class Initialized
DEBUG - 2021-12-01 03:35:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-01 03:35:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 03:35:25 --> Final output sent to browser
DEBUG - 2021-12-01 03:35:25 --> Total execution time: 1.0564
INFO - 2021-12-01 03:44:52 --> Config Class Initialized
INFO - 2021-12-01 03:44:52 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:44:52 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:44:52 --> Utf8 Class Initialized
INFO - 2021-12-01 03:44:52 --> URI Class Initialized
INFO - 2021-12-01 03:44:52 --> Router Class Initialized
INFO - 2021-12-01 03:44:52 --> Output Class Initialized
INFO - 2021-12-01 03:44:52 --> Security Class Initialized
DEBUG - 2021-12-01 03:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:44:52 --> Input Class Initialized
INFO - 2021-12-01 03:44:52 --> Language Class Initialized
INFO - 2021-12-01 03:44:52 --> Language Class Initialized
INFO - 2021-12-01 03:44:52 --> Config Class Initialized
INFO - 2021-12-01 03:44:52 --> Loader Class Initialized
INFO - 2021-12-01 03:44:52 --> Helper loaded: url_helper
INFO - 2021-12-01 03:44:52 --> Helper loaded: file_helper
INFO - 2021-12-01 03:44:52 --> Helper loaded: form_helper
INFO - 2021-12-01 03:44:52 --> Helper loaded: my_helper
INFO - 2021-12-01 03:44:52 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:44:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:44:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:44:52 --> Controller Class Initialized
DEBUG - 2021-12-01 03:44:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-12-01 03:44:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 03:44:52 --> Final output sent to browser
DEBUG - 2021-12-01 03:44:52 --> Total execution time: 0.1014
INFO - 2021-12-01 03:44:56 --> Config Class Initialized
INFO - 2021-12-01 03:44:56 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:44:56 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:44:56 --> Utf8 Class Initialized
INFO - 2021-12-01 03:44:56 --> URI Class Initialized
INFO - 2021-12-01 03:44:56 --> Router Class Initialized
INFO - 2021-12-01 03:44:56 --> Output Class Initialized
INFO - 2021-12-01 03:44:56 --> Security Class Initialized
DEBUG - 2021-12-01 03:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:44:56 --> Input Class Initialized
INFO - 2021-12-01 03:44:56 --> Language Class Initialized
INFO - 2021-12-01 03:44:56 --> Language Class Initialized
INFO - 2021-12-01 03:44:56 --> Config Class Initialized
INFO - 2021-12-01 03:44:56 --> Loader Class Initialized
INFO - 2021-12-01 03:44:56 --> Helper loaded: url_helper
INFO - 2021-12-01 03:44:56 --> Helper loaded: file_helper
INFO - 2021-12-01 03:44:56 --> Helper loaded: form_helper
INFO - 2021-12-01 03:44:56 --> Helper loaded: my_helper
INFO - 2021-12-01 03:44:56 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:44:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:44:56 --> Controller Class Initialized
DEBUG - 2021-12-01 03:44:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tbsm_xi.php
INFO - 2021-12-01 03:44:56 --> Final output sent to browser
DEBUG - 2021-12-01 03:44:56 --> Total execution time: 0.3248
INFO - 2021-12-01 03:45:20 --> Config Class Initialized
INFO - 2021-12-01 03:45:20 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:45:20 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:45:20 --> Utf8 Class Initialized
INFO - 2021-12-01 03:45:20 --> URI Class Initialized
INFO - 2021-12-01 03:45:20 --> Router Class Initialized
INFO - 2021-12-01 03:45:20 --> Output Class Initialized
INFO - 2021-12-01 03:45:20 --> Security Class Initialized
DEBUG - 2021-12-01 03:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:45:20 --> Input Class Initialized
INFO - 2021-12-01 03:45:20 --> Language Class Initialized
INFO - 2021-12-01 03:45:20 --> Language Class Initialized
INFO - 2021-12-01 03:45:20 --> Config Class Initialized
INFO - 2021-12-01 03:45:20 --> Loader Class Initialized
INFO - 2021-12-01 03:45:20 --> Helper loaded: url_helper
INFO - 2021-12-01 03:45:20 --> Helper loaded: file_helper
INFO - 2021-12-01 03:45:20 --> Helper loaded: form_helper
INFO - 2021-12-01 03:45:20 --> Helper loaded: my_helper
INFO - 2021-12-01 03:45:20 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:45:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:45:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:45:20 --> Controller Class Initialized
DEBUG - 2021-12-01 03:45:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-01 03:45:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 03:45:20 --> Final output sent to browser
DEBUG - 2021-12-01 03:45:20 --> Total execution time: 0.0871
INFO - 2021-12-01 03:45:59 --> Config Class Initialized
INFO - 2021-12-01 03:45:59 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:45:59 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:45:59 --> Utf8 Class Initialized
INFO - 2021-12-01 03:45:59 --> URI Class Initialized
INFO - 2021-12-01 03:45:59 --> Router Class Initialized
INFO - 2021-12-01 03:45:59 --> Output Class Initialized
INFO - 2021-12-01 03:45:59 --> Security Class Initialized
DEBUG - 2021-12-01 03:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:45:59 --> Input Class Initialized
INFO - 2021-12-01 03:45:59 --> Language Class Initialized
INFO - 2021-12-01 03:45:59 --> Language Class Initialized
INFO - 2021-12-01 03:45:59 --> Config Class Initialized
INFO - 2021-12-01 03:45:59 --> Loader Class Initialized
INFO - 2021-12-01 03:45:59 --> Helper loaded: url_helper
INFO - 2021-12-01 03:45:59 --> Helper loaded: file_helper
INFO - 2021-12-01 03:45:59 --> Helper loaded: form_helper
INFO - 2021-12-01 03:45:59 --> Helper loaded: my_helper
INFO - 2021-12-01 03:45:59 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:45:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:45:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:45:59 --> Controller Class Initialized
DEBUG - 2021-12-01 03:45:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 03:45:59 --> Final output sent to browser
DEBUG - 2021-12-01 03:45:59 --> Total execution time: 0.1961
INFO - 2021-12-01 03:46:12 --> Config Class Initialized
INFO - 2021-12-01 03:46:12 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:46:12 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:46:12 --> Utf8 Class Initialized
INFO - 2021-12-01 03:46:12 --> URI Class Initialized
INFO - 2021-12-01 03:46:12 --> Router Class Initialized
INFO - 2021-12-01 03:46:12 --> Output Class Initialized
INFO - 2021-12-01 03:46:12 --> Security Class Initialized
DEBUG - 2021-12-01 03:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:46:12 --> Input Class Initialized
INFO - 2021-12-01 03:46:12 --> Language Class Initialized
INFO - 2021-12-01 03:46:12 --> Language Class Initialized
INFO - 2021-12-01 03:46:12 --> Config Class Initialized
INFO - 2021-12-01 03:46:12 --> Loader Class Initialized
INFO - 2021-12-01 03:46:12 --> Helper loaded: url_helper
INFO - 2021-12-01 03:46:12 --> Helper loaded: file_helper
INFO - 2021-12-01 03:46:12 --> Helper loaded: form_helper
INFO - 2021-12-01 03:46:12 --> Helper loaded: my_helper
INFO - 2021-12-01 03:46:12 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:46:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:46:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:46:12 --> Controller Class Initialized
DEBUG - 2021-12-01 03:46:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 03:46:12 --> Final output sent to browser
DEBUG - 2021-12-01 03:46:12 --> Total execution time: 0.2084
INFO - 2021-12-01 03:46:14 --> Config Class Initialized
INFO - 2021-12-01 03:46:14 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:46:14 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:46:14 --> Utf8 Class Initialized
INFO - 2021-12-01 03:46:14 --> URI Class Initialized
INFO - 2021-12-01 03:46:14 --> Router Class Initialized
INFO - 2021-12-01 03:46:14 --> Output Class Initialized
INFO - 2021-12-01 03:46:14 --> Security Class Initialized
DEBUG - 2021-12-01 03:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:46:14 --> Input Class Initialized
INFO - 2021-12-01 03:46:14 --> Language Class Initialized
INFO - 2021-12-01 03:46:14 --> Language Class Initialized
INFO - 2021-12-01 03:46:14 --> Config Class Initialized
INFO - 2021-12-01 03:46:14 --> Loader Class Initialized
INFO - 2021-12-01 03:46:14 --> Helper loaded: url_helper
INFO - 2021-12-01 03:46:14 --> Helper loaded: file_helper
INFO - 2021-12-01 03:46:14 --> Helper loaded: form_helper
INFO - 2021-12-01 03:46:14 --> Helper loaded: my_helper
INFO - 2021-12-01 03:46:14 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:46:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:46:14 --> Controller Class Initialized
DEBUG - 2021-12-01 03:46:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 03:46:14 --> Final output sent to browser
DEBUG - 2021-12-01 03:46:14 --> Total execution time: 0.1818
INFO - 2021-12-01 03:46:16 --> Config Class Initialized
INFO - 2021-12-01 03:46:16 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:46:16 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:46:16 --> Utf8 Class Initialized
INFO - 2021-12-01 03:46:16 --> URI Class Initialized
INFO - 2021-12-01 03:46:16 --> Router Class Initialized
INFO - 2021-12-01 03:46:16 --> Output Class Initialized
INFO - 2021-12-01 03:46:16 --> Security Class Initialized
DEBUG - 2021-12-01 03:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:46:16 --> Input Class Initialized
INFO - 2021-12-01 03:46:16 --> Language Class Initialized
INFO - 2021-12-01 03:46:16 --> Language Class Initialized
INFO - 2021-12-01 03:46:16 --> Config Class Initialized
INFO - 2021-12-01 03:46:16 --> Loader Class Initialized
INFO - 2021-12-01 03:46:16 --> Helper loaded: url_helper
INFO - 2021-12-01 03:46:16 --> Helper loaded: file_helper
INFO - 2021-12-01 03:46:16 --> Helper loaded: form_helper
INFO - 2021-12-01 03:46:16 --> Helper loaded: my_helper
INFO - 2021-12-01 03:46:16 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:46:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:46:16 --> Controller Class Initialized
DEBUG - 2021-12-01 03:46:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 03:46:16 --> Final output sent to browser
DEBUG - 2021-12-01 03:46:16 --> Total execution time: 0.2022
INFO - 2021-12-01 03:46:18 --> Config Class Initialized
INFO - 2021-12-01 03:46:18 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:46:18 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:46:18 --> Utf8 Class Initialized
INFO - 2021-12-01 03:46:18 --> URI Class Initialized
INFO - 2021-12-01 03:46:18 --> Router Class Initialized
INFO - 2021-12-01 03:46:18 --> Output Class Initialized
INFO - 2021-12-01 03:46:18 --> Security Class Initialized
DEBUG - 2021-12-01 03:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:46:18 --> Input Class Initialized
INFO - 2021-12-01 03:46:18 --> Language Class Initialized
INFO - 2021-12-01 03:46:18 --> Language Class Initialized
INFO - 2021-12-01 03:46:18 --> Config Class Initialized
INFO - 2021-12-01 03:46:18 --> Loader Class Initialized
INFO - 2021-12-01 03:46:18 --> Helper loaded: url_helper
INFO - 2021-12-01 03:46:18 --> Helper loaded: file_helper
INFO - 2021-12-01 03:46:18 --> Helper loaded: form_helper
INFO - 2021-12-01 03:46:18 --> Helper loaded: my_helper
INFO - 2021-12-01 03:46:19 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:46:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:46:19 --> Controller Class Initialized
DEBUG - 2021-12-01 03:46:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 03:46:19 --> Final output sent to browser
DEBUG - 2021-12-01 03:46:19 --> Total execution time: 0.2103
INFO - 2021-12-01 03:46:20 --> Config Class Initialized
INFO - 2021-12-01 03:46:20 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:46:20 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:46:20 --> Utf8 Class Initialized
INFO - 2021-12-01 03:46:20 --> URI Class Initialized
INFO - 2021-12-01 03:46:20 --> Router Class Initialized
INFO - 2021-12-01 03:46:20 --> Output Class Initialized
INFO - 2021-12-01 03:46:20 --> Security Class Initialized
DEBUG - 2021-12-01 03:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:46:20 --> Input Class Initialized
INFO - 2021-12-01 03:46:20 --> Language Class Initialized
INFO - 2021-12-01 03:46:20 --> Language Class Initialized
INFO - 2021-12-01 03:46:20 --> Config Class Initialized
INFO - 2021-12-01 03:46:20 --> Loader Class Initialized
INFO - 2021-12-01 03:46:20 --> Helper loaded: url_helper
INFO - 2021-12-01 03:46:20 --> Helper loaded: file_helper
INFO - 2021-12-01 03:46:20 --> Helper loaded: form_helper
INFO - 2021-12-01 03:46:20 --> Helper loaded: my_helper
INFO - 2021-12-01 03:46:20 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:46:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:46:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:46:20 --> Controller Class Initialized
DEBUG - 2021-12-01 03:46:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 03:46:20 --> Final output sent to browser
DEBUG - 2021-12-01 03:46:20 --> Total execution time: 0.2121
INFO - 2021-12-01 03:46:23 --> Config Class Initialized
INFO - 2021-12-01 03:46:23 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:46:23 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:46:23 --> Utf8 Class Initialized
INFO - 2021-12-01 03:46:23 --> URI Class Initialized
INFO - 2021-12-01 03:46:23 --> Router Class Initialized
INFO - 2021-12-01 03:46:23 --> Output Class Initialized
INFO - 2021-12-01 03:46:23 --> Security Class Initialized
DEBUG - 2021-12-01 03:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:46:23 --> Input Class Initialized
INFO - 2021-12-01 03:46:23 --> Language Class Initialized
INFO - 2021-12-01 03:46:23 --> Language Class Initialized
INFO - 2021-12-01 03:46:23 --> Config Class Initialized
INFO - 2021-12-01 03:46:23 --> Loader Class Initialized
INFO - 2021-12-01 03:46:23 --> Helper loaded: url_helper
INFO - 2021-12-01 03:46:23 --> Helper loaded: file_helper
INFO - 2021-12-01 03:46:23 --> Helper loaded: form_helper
INFO - 2021-12-01 03:46:23 --> Helper loaded: my_helper
INFO - 2021-12-01 03:46:23 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:46:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:46:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:46:23 --> Controller Class Initialized
DEBUG - 2021-12-01 03:46:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 03:46:23 --> Final output sent to browser
DEBUG - 2021-12-01 03:46:23 --> Total execution time: 0.2172
INFO - 2021-12-01 03:46:24 --> Config Class Initialized
INFO - 2021-12-01 03:46:24 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:46:24 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:46:24 --> Utf8 Class Initialized
INFO - 2021-12-01 03:46:24 --> URI Class Initialized
INFO - 2021-12-01 03:46:24 --> Router Class Initialized
INFO - 2021-12-01 03:46:24 --> Output Class Initialized
INFO - 2021-12-01 03:46:24 --> Security Class Initialized
DEBUG - 2021-12-01 03:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:46:24 --> Input Class Initialized
INFO - 2021-12-01 03:46:24 --> Language Class Initialized
INFO - 2021-12-01 03:46:24 --> Language Class Initialized
INFO - 2021-12-01 03:46:24 --> Config Class Initialized
INFO - 2021-12-01 03:46:24 --> Loader Class Initialized
INFO - 2021-12-01 03:46:24 --> Helper loaded: url_helper
INFO - 2021-12-01 03:46:24 --> Helper loaded: file_helper
INFO - 2021-12-01 03:46:24 --> Helper loaded: form_helper
INFO - 2021-12-01 03:46:24 --> Helper loaded: my_helper
INFO - 2021-12-01 03:46:24 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:46:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:46:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:46:24 --> Controller Class Initialized
DEBUG - 2021-12-01 03:46:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 03:46:24 --> Final output sent to browser
DEBUG - 2021-12-01 03:46:24 --> Total execution time: 0.2079
INFO - 2021-12-01 03:46:27 --> Config Class Initialized
INFO - 2021-12-01 03:46:27 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:46:27 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:46:27 --> Utf8 Class Initialized
INFO - 2021-12-01 03:46:27 --> URI Class Initialized
INFO - 2021-12-01 03:46:27 --> Router Class Initialized
INFO - 2021-12-01 03:46:27 --> Output Class Initialized
INFO - 2021-12-01 03:46:27 --> Security Class Initialized
DEBUG - 2021-12-01 03:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:46:27 --> Input Class Initialized
INFO - 2021-12-01 03:46:27 --> Language Class Initialized
INFO - 2021-12-01 03:46:27 --> Language Class Initialized
INFO - 2021-12-01 03:46:27 --> Config Class Initialized
INFO - 2021-12-01 03:46:27 --> Loader Class Initialized
INFO - 2021-12-01 03:46:27 --> Helper loaded: url_helper
INFO - 2021-12-01 03:46:27 --> Helper loaded: file_helper
INFO - 2021-12-01 03:46:27 --> Helper loaded: form_helper
INFO - 2021-12-01 03:46:27 --> Helper loaded: my_helper
INFO - 2021-12-01 03:46:27 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:46:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:46:27 --> Controller Class Initialized
DEBUG - 2021-12-01 03:46:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 03:46:27 --> Final output sent to browser
DEBUG - 2021-12-01 03:46:27 --> Total execution time: 0.2188
INFO - 2021-12-01 03:46:28 --> Config Class Initialized
INFO - 2021-12-01 03:46:28 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:46:28 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:46:28 --> Utf8 Class Initialized
INFO - 2021-12-01 03:46:28 --> URI Class Initialized
INFO - 2021-12-01 03:46:28 --> Router Class Initialized
INFO - 2021-12-01 03:46:28 --> Output Class Initialized
INFO - 2021-12-01 03:46:28 --> Security Class Initialized
DEBUG - 2021-12-01 03:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:46:28 --> Input Class Initialized
INFO - 2021-12-01 03:46:28 --> Language Class Initialized
INFO - 2021-12-01 03:46:29 --> Language Class Initialized
INFO - 2021-12-01 03:46:29 --> Config Class Initialized
INFO - 2021-12-01 03:46:29 --> Loader Class Initialized
INFO - 2021-12-01 03:46:29 --> Helper loaded: url_helper
INFO - 2021-12-01 03:46:29 --> Helper loaded: file_helper
INFO - 2021-12-01 03:46:29 --> Helper loaded: form_helper
INFO - 2021-12-01 03:46:29 --> Helper loaded: my_helper
INFO - 2021-12-01 03:46:29 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:46:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:46:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:46:29 --> Controller Class Initialized
DEBUG - 2021-12-01 03:46:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 03:46:29 --> Final output sent to browser
DEBUG - 2021-12-01 03:46:29 --> Total execution time: 0.2102
INFO - 2021-12-01 03:46:31 --> Config Class Initialized
INFO - 2021-12-01 03:46:31 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:46:31 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:46:31 --> Utf8 Class Initialized
INFO - 2021-12-01 03:46:31 --> URI Class Initialized
INFO - 2021-12-01 03:46:31 --> Router Class Initialized
INFO - 2021-12-01 03:46:31 --> Output Class Initialized
INFO - 2021-12-01 03:46:31 --> Security Class Initialized
DEBUG - 2021-12-01 03:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:46:31 --> Input Class Initialized
INFO - 2021-12-01 03:46:31 --> Language Class Initialized
INFO - 2021-12-01 03:46:31 --> Language Class Initialized
INFO - 2021-12-01 03:46:31 --> Config Class Initialized
INFO - 2021-12-01 03:46:31 --> Loader Class Initialized
INFO - 2021-12-01 03:46:31 --> Helper loaded: url_helper
INFO - 2021-12-01 03:46:31 --> Helper loaded: file_helper
INFO - 2021-12-01 03:46:31 --> Helper loaded: form_helper
INFO - 2021-12-01 03:46:31 --> Helper loaded: my_helper
INFO - 2021-12-01 03:46:31 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:46:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:46:31 --> Controller Class Initialized
DEBUG - 2021-12-01 03:46:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 03:46:31 --> Final output sent to browser
DEBUG - 2021-12-01 03:46:31 --> Total execution time: 0.2136
INFO - 2021-12-01 03:46:33 --> Config Class Initialized
INFO - 2021-12-01 03:46:33 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:46:33 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:46:33 --> Utf8 Class Initialized
INFO - 2021-12-01 03:46:33 --> URI Class Initialized
INFO - 2021-12-01 03:46:33 --> Router Class Initialized
INFO - 2021-12-01 03:46:33 --> Output Class Initialized
INFO - 2021-12-01 03:46:33 --> Security Class Initialized
DEBUG - 2021-12-01 03:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:46:33 --> Input Class Initialized
INFO - 2021-12-01 03:46:33 --> Language Class Initialized
INFO - 2021-12-01 03:46:33 --> Language Class Initialized
INFO - 2021-12-01 03:46:33 --> Config Class Initialized
INFO - 2021-12-01 03:46:33 --> Loader Class Initialized
INFO - 2021-12-01 03:46:33 --> Helper loaded: url_helper
INFO - 2021-12-01 03:46:33 --> Helper loaded: file_helper
INFO - 2021-12-01 03:46:33 --> Helper loaded: form_helper
INFO - 2021-12-01 03:46:33 --> Helper loaded: my_helper
INFO - 2021-12-01 03:46:33 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:46:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:46:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:46:33 --> Controller Class Initialized
DEBUG - 2021-12-01 03:46:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 03:46:33 --> Final output sent to browser
DEBUG - 2021-12-01 03:46:33 --> Total execution time: 0.2111
INFO - 2021-12-01 03:46:36 --> Config Class Initialized
INFO - 2021-12-01 03:46:36 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:46:36 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:46:36 --> Utf8 Class Initialized
INFO - 2021-12-01 03:46:36 --> URI Class Initialized
INFO - 2021-12-01 03:46:36 --> Router Class Initialized
INFO - 2021-12-01 03:46:36 --> Output Class Initialized
INFO - 2021-12-01 03:46:36 --> Security Class Initialized
DEBUG - 2021-12-01 03:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:46:36 --> Input Class Initialized
INFO - 2021-12-01 03:46:36 --> Language Class Initialized
INFO - 2021-12-01 03:46:36 --> Language Class Initialized
INFO - 2021-12-01 03:46:36 --> Config Class Initialized
INFO - 2021-12-01 03:46:36 --> Loader Class Initialized
INFO - 2021-12-01 03:46:36 --> Helper loaded: url_helper
INFO - 2021-12-01 03:46:36 --> Helper loaded: file_helper
INFO - 2021-12-01 03:46:36 --> Helper loaded: form_helper
INFO - 2021-12-01 03:46:36 --> Helper loaded: my_helper
INFO - 2021-12-01 03:46:36 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:46:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:46:36 --> Controller Class Initialized
DEBUG - 2021-12-01 03:46:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 03:46:36 --> Final output sent to browser
DEBUG - 2021-12-01 03:46:36 --> Total execution time: 0.2338
INFO - 2021-12-01 03:46:37 --> Config Class Initialized
INFO - 2021-12-01 03:46:37 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:46:37 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:46:37 --> Utf8 Class Initialized
INFO - 2021-12-01 03:46:37 --> URI Class Initialized
INFO - 2021-12-01 03:46:37 --> Router Class Initialized
INFO - 2021-12-01 03:46:37 --> Output Class Initialized
INFO - 2021-12-01 03:46:37 --> Security Class Initialized
DEBUG - 2021-12-01 03:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:46:37 --> Input Class Initialized
INFO - 2021-12-01 03:46:37 --> Language Class Initialized
INFO - 2021-12-01 03:46:37 --> Language Class Initialized
INFO - 2021-12-01 03:46:37 --> Config Class Initialized
INFO - 2021-12-01 03:46:37 --> Loader Class Initialized
INFO - 2021-12-01 03:46:37 --> Helper loaded: url_helper
INFO - 2021-12-01 03:46:37 --> Helper loaded: file_helper
INFO - 2021-12-01 03:46:37 --> Helper loaded: form_helper
INFO - 2021-12-01 03:46:37 --> Helper loaded: my_helper
INFO - 2021-12-01 03:46:37 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:46:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:46:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:46:37 --> Controller Class Initialized
DEBUG - 2021-12-01 03:46:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 03:46:37 --> Final output sent to browser
DEBUG - 2021-12-01 03:46:37 --> Total execution time: 0.2097
INFO - 2021-12-01 03:46:40 --> Config Class Initialized
INFO - 2021-12-01 03:46:40 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:46:40 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:46:40 --> Utf8 Class Initialized
INFO - 2021-12-01 03:46:40 --> URI Class Initialized
INFO - 2021-12-01 03:46:40 --> Router Class Initialized
INFO - 2021-12-01 03:46:40 --> Output Class Initialized
INFO - 2021-12-01 03:46:40 --> Security Class Initialized
DEBUG - 2021-12-01 03:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:46:40 --> Input Class Initialized
INFO - 2021-12-01 03:46:40 --> Language Class Initialized
INFO - 2021-12-01 03:46:40 --> Language Class Initialized
INFO - 2021-12-01 03:46:40 --> Config Class Initialized
INFO - 2021-12-01 03:46:40 --> Loader Class Initialized
INFO - 2021-12-01 03:46:40 --> Helper loaded: url_helper
INFO - 2021-12-01 03:46:40 --> Helper loaded: file_helper
INFO - 2021-12-01 03:46:40 --> Helper loaded: form_helper
INFO - 2021-12-01 03:46:40 --> Helper loaded: my_helper
INFO - 2021-12-01 03:46:41 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:46:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:46:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:46:41 --> Controller Class Initialized
DEBUG - 2021-12-01 03:46:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 03:46:41 --> Final output sent to browser
DEBUG - 2021-12-01 03:46:41 --> Total execution time: 0.1938
INFO - 2021-12-01 03:46:42 --> Config Class Initialized
INFO - 2021-12-01 03:46:42 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:46:42 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:46:42 --> Utf8 Class Initialized
INFO - 2021-12-01 03:46:42 --> URI Class Initialized
INFO - 2021-12-01 03:46:42 --> Router Class Initialized
INFO - 2021-12-01 03:46:42 --> Output Class Initialized
INFO - 2021-12-01 03:46:42 --> Security Class Initialized
DEBUG - 2021-12-01 03:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:46:42 --> Input Class Initialized
INFO - 2021-12-01 03:46:42 --> Language Class Initialized
INFO - 2021-12-01 03:46:42 --> Language Class Initialized
INFO - 2021-12-01 03:46:42 --> Config Class Initialized
INFO - 2021-12-01 03:46:42 --> Loader Class Initialized
INFO - 2021-12-01 03:46:42 --> Helper loaded: url_helper
INFO - 2021-12-01 03:46:42 --> Helper loaded: file_helper
INFO - 2021-12-01 03:46:42 --> Helper loaded: form_helper
INFO - 2021-12-01 03:46:42 --> Helper loaded: my_helper
INFO - 2021-12-01 03:46:42 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:46:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:46:42 --> Controller Class Initialized
DEBUG - 2021-12-01 03:46:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 03:46:43 --> Final output sent to browser
DEBUG - 2021-12-01 03:46:43 --> Total execution time: 0.2032
INFO - 2021-12-01 03:46:45 --> Config Class Initialized
INFO - 2021-12-01 03:46:45 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:46:45 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:46:45 --> Utf8 Class Initialized
INFO - 2021-12-01 03:46:45 --> URI Class Initialized
INFO - 2021-12-01 03:46:45 --> Router Class Initialized
INFO - 2021-12-01 03:46:45 --> Output Class Initialized
INFO - 2021-12-01 03:46:45 --> Security Class Initialized
DEBUG - 2021-12-01 03:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:46:45 --> Input Class Initialized
INFO - 2021-12-01 03:46:45 --> Language Class Initialized
INFO - 2021-12-01 03:46:45 --> Language Class Initialized
INFO - 2021-12-01 03:46:45 --> Config Class Initialized
INFO - 2021-12-01 03:46:45 --> Loader Class Initialized
INFO - 2021-12-01 03:46:45 --> Helper loaded: url_helper
INFO - 2021-12-01 03:46:45 --> Helper loaded: file_helper
INFO - 2021-12-01 03:46:45 --> Helper loaded: form_helper
INFO - 2021-12-01 03:46:45 --> Helper loaded: my_helper
INFO - 2021-12-01 03:46:45 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:46:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:46:45 --> Controller Class Initialized
DEBUG - 2021-12-01 03:46:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 03:46:45 --> Final output sent to browser
DEBUG - 2021-12-01 03:46:45 --> Total execution time: 0.2121
INFO - 2021-12-01 03:46:47 --> Config Class Initialized
INFO - 2021-12-01 03:46:47 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:46:47 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:46:47 --> Utf8 Class Initialized
INFO - 2021-12-01 03:46:47 --> URI Class Initialized
INFO - 2021-12-01 03:46:47 --> Router Class Initialized
INFO - 2021-12-01 03:46:47 --> Output Class Initialized
INFO - 2021-12-01 03:46:47 --> Security Class Initialized
DEBUG - 2021-12-01 03:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:46:47 --> Input Class Initialized
INFO - 2021-12-01 03:46:47 --> Language Class Initialized
INFO - 2021-12-01 03:46:47 --> Language Class Initialized
INFO - 2021-12-01 03:46:47 --> Config Class Initialized
INFO - 2021-12-01 03:46:47 --> Loader Class Initialized
INFO - 2021-12-01 03:46:47 --> Helper loaded: url_helper
INFO - 2021-12-01 03:46:47 --> Helper loaded: file_helper
INFO - 2021-12-01 03:46:47 --> Helper loaded: form_helper
INFO - 2021-12-01 03:46:47 --> Helper loaded: my_helper
INFO - 2021-12-01 03:46:47 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:46:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:46:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:46:47 --> Controller Class Initialized
DEBUG - 2021-12-01 03:46:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 03:46:47 --> Final output sent to browser
DEBUG - 2021-12-01 03:46:47 --> Total execution time: 0.2123
INFO - 2021-12-01 03:46:50 --> Config Class Initialized
INFO - 2021-12-01 03:46:50 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:46:50 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:46:50 --> Utf8 Class Initialized
INFO - 2021-12-01 03:46:50 --> URI Class Initialized
INFO - 2021-12-01 03:46:50 --> Router Class Initialized
INFO - 2021-12-01 03:46:50 --> Output Class Initialized
INFO - 2021-12-01 03:46:50 --> Security Class Initialized
DEBUG - 2021-12-01 03:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:46:50 --> Input Class Initialized
INFO - 2021-12-01 03:46:50 --> Language Class Initialized
INFO - 2021-12-01 03:46:50 --> Language Class Initialized
INFO - 2021-12-01 03:46:50 --> Config Class Initialized
INFO - 2021-12-01 03:46:50 --> Loader Class Initialized
INFO - 2021-12-01 03:46:50 --> Helper loaded: url_helper
INFO - 2021-12-01 03:46:50 --> Helper loaded: file_helper
INFO - 2021-12-01 03:46:50 --> Helper loaded: form_helper
INFO - 2021-12-01 03:46:50 --> Helper loaded: my_helper
INFO - 2021-12-01 03:46:50 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:46:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:46:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:46:50 --> Controller Class Initialized
DEBUG - 2021-12-01 03:46:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 03:46:50 --> Final output sent to browser
DEBUG - 2021-12-01 03:46:50 --> Total execution time: 0.2304
INFO - 2021-12-01 03:46:51 --> Config Class Initialized
INFO - 2021-12-01 03:46:51 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:46:51 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:46:51 --> Utf8 Class Initialized
INFO - 2021-12-01 03:46:52 --> URI Class Initialized
INFO - 2021-12-01 03:46:52 --> Router Class Initialized
INFO - 2021-12-01 03:46:52 --> Output Class Initialized
INFO - 2021-12-01 03:46:52 --> Security Class Initialized
DEBUG - 2021-12-01 03:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:46:52 --> Input Class Initialized
INFO - 2021-12-01 03:46:52 --> Language Class Initialized
INFO - 2021-12-01 03:46:52 --> Language Class Initialized
INFO - 2021-12-01 03:46:52 --> Config Class Initialized
INFO - 2021-12-01 03:46:52 --> Loader Class Initialized
INFO - 2021-12-01 03:46:52 --> Helper loaded: url_helper
INFO - 2021-12-01 03:46:52 --> Helper loaded: file_helper
INFO - 2021-12-01 03:46:52 --> Helper loaded: form_helper
INFO - 2021-12-01 03:46:52 --> Helper loaded: my_helper
INFO - 2021-12-01 03:46:52 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:46:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:46:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:46:52 --> Controller Class Initialized
DEBUG - 2021-12-01 03:46:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 03:46:52 --> Final output sent to browser
DEBUG - 2021-12-01 03:46:52 --> Total execution time: 0.2247
INFO - 2021-12-01 03:46:54 --> Config Class Initialized
INFO - 2021-12-01 03:46:54 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:46:54 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:46:54 --> Utf8 Class Initialized
INFO - 2021-12-01 03:46:54 --> URI Class Initialized
INFO - 2021-12-01 03:46:54 --> Router Class Initialized
INFO - 2021-12-01 03:46:54 --> Output Class Initialized
INFO - 2021-12-01 03:46:54 --> Security Class Initialized
DEBUG - 2021-12-01 03:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:46:54 --> Input Class Initialized
INFO - 2021-12-01 03:46:54 --> Language Class Initialized
INFO - 2021-12-01 03:46:54 --> Language Class Initialized
INFO - 2021-12-01 03:46:54 --> Config Class Initialized
INFO - 2021-12-01 03:46:54 --> Loader Class Initialized
INFO - 2021-12-01 03:46:54 --> Helper loaded: url_helper
INFO - 2021-12-01 03:46:54 --> Helper loaded: file_helper
INFO - 2021-12-01 03:46:54 --> Helper loaded: form_helper
INFO - 2021-12-01 03:46:54 --> Helper loaded: my_helper
INFO - 2021-12-01 03:46:54 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:46:54 --> Controller Class Initialized
DEBUG - 2021-12-01 03:46:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 03:46:54 --> Final output sent to browser
DEBUG - 2021-12-01 03:46:54 --> Total execution time: 0.2123
INFO - 2021-12-01 03:46:56 --> Config Class Initialized
INFO - 2021-12-01 03:46:56 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:46:56 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:46:56 --> Utf8 Class Initialized
INFO - 2021-12-01 03:46:56 --> URI Class Initialized
INFO - 2021-12-01 03:46:56 --> Router Class Initialized
INFO - 2021-12-01 03:46:56 --> Output Class Initialized
INFO - 2021-12-01 03:46:56 --> Security Class Initialized
DEBUG - 2021-12-01 03:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:46:56 --> Input Class Initialized
INFO - 2021-12-01 03:46:56 --> Language Class Initialized
INFO - 2021-12-01 03:46:56 --> Language Class Initialized
INFO - 2021-12-01 03:46:56 --> Config Class Initialized
INFO - 2021-12-01 03:46:56 --> Loader Class Initialized
INFO - 2021-12-01 03:46:56 --> Helper loaded: url_helper
INFO - 2021-12-01 03:46:56 --> Helper loaded: file_helper
INFO - 2021-12-01 03:46:56 --> Helper loaded: form_helper
INFO - 2021-12-01 03:46:56 --> Helper loaded: my_helper
INFO - 2021-12-01 03:46:56 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:46:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:46:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:46:56 --> Controller Class Initialized
DEBUG - 2021-12-01 03:46:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 03:46:56 --> Final output sent to browser
DEBUG - 2021-12-01 03:46:56 --> Total execution time: 0.2071
INFO - 2021-12-01 03:46:59 --> Config Class Initialized
INFO - 2021-12-01 03:46:59 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:46:59 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:46:59 --> Utf8 Class Initialized
INFO - 2021-12-01 03:46:59 --> URI Class Initialized
INFO - 2021-12-01 03:46:59 --> Router Class Initialized
INFO - 2021-12-01 03:46:59 --> Output Class Initialized
INFO - 2021-12-01 03:46:59 --> Security Class Initialized
DEBUG - 2021-12-01 03:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:46:59 --> Input Class Initialized
INFO - 2021-12-01 03:46:59 --> Language Class Initialized
INFO - 2021-12-01 03:46:59 --> Language Class Initialized
INFO - 2021-12-01 03:46:59 --> Config Class Initialized
INFO - 2021-12-01 03:46:59 --> Loader Class Initialized
INFO - 2021-12-01 03:46:59 --> Helper loaded: url_helper
INFO - 2021-12-01 03:46:59 --> Helper loaded: file_helper
INFO - 2021-12-01 03:46:59 --> Helper loaded: form_helper
INFO - 2021-12-01 03:46:59 --> Helper loaded: my_helper
INFO - 2021-12-01 03:46:59 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:46:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:46:59 --> Controller Class Initialized
DEBUG - 2021-12-01 03:47:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 03:47:00 --> Final output sent to browser
DEBUG - 2021-12-01 03:47:00 --> Total execution time: 0.2077
INFO - 2021-12-01 03:47:02 --> Config Class Initialized
INFO - 2021-12-01 03:47:02 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:47:02 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:47:02 --> Utf8 Class Initialized
INFO - 2021-12-01 03:47:02 --> URI Class Initialized
INFO - 2021-12-01 03:47:02 --> Router Class Initialized
INFO - 2021-12-01 03:47:02 --> Output Class Initialized
INFO - 2021-12-01 03:47:02 --> Security Class Initialized
DEBUG - 2021-12-01 03:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:47:02 --> Input Class Initialized
INFO - 2021-12-01 03:47:02 --> Language Class Initialized
INFO - 2021-12-01 03:47:02 --> Language Class Initialized
INFO - 2021-12-01 03:47:02 --> Config Class Initialized
INFO - 2021-12-01 03:47:02 --> Loader Class Initialized
INFO - 2021-12-01 03:47:02 --> Helper loaded: url_helper
INFO - 2021-12-01 03:47:02 --> Helper loaded: file_helper
INFO - 2021-12-01 03:47:02 --> Helper loaded: form_helper
INFO - 2021-12-01 03:47:02 --> Helper loaded: my_helper
INFO - 2021-12-01 03:47:02 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:47:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:47:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:47:02 --> Controller Class Initialized
DEBUG - 2021-12-01 03:47:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 03:47:02 --> Final output sent to browser
DEBUG - 2021-12-01 03:47:02 --> Total execution time: 0.1755
INFO - 2021-12-01 03:47:04 --> Config Class Initialized
INFO - 2021-12-01 03:47:04 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:47:04 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:47:04 --> Utf8 Class Initialized
INFO - 2021-12-01 03:47:04 --> URI Class Initialized
INFO - 2021-12-01 03:47:04 --> Router Class Initialized
INFO - 2021-12-01 03:47:04 --> Output Class Initialized
INFO - 2021-12-01 03:47:04 --> Security Class Initialized
DEBUG - 2021-12-01 03:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:47:04 --> Input Class Initialized
INFO - 2021-12-01 03:47:04 --> Language Class Initialized
INFO - 2021-12-01 03:47:04 --> Language Class Initialized
INFO - 2021-12-01 03:47:04 --> Config Class Initialized
INFO - 2021-12-01 03:47:04 --> Loader Class Initialized
INFO - 2021-12-01 03:47:04 --> Helper loaded: url_helper
INFO - 2021-12-01 03:47:04 --> Helper loaded: file_helper
INFO - 2021-12-01 03:47:04 --> Helper loaded: form_helper
INFO - 2021-12-01 03:47:04 --> Helper loaded: my_helper
INFO - 2021-12-01 03:47:04 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:47:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:47:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:47:04 --> Controller Class Initialized
DEBUG - 2021-12-01 03:47:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 03:47:04 --> Final output sent to browser
DEBUG - 2021-12-01 03:47:04 --> Total execution time: 0.1839
INFO - 2021-12-01 03:47:06 --> Config Class Initialized
INFO - 2021-12-01 03:47:06 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:47:06 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:47:06 --> Utf8 Class Initialized
INFO - 2021-12-01 03:47:06 --> URI Class Initialized
INFO - 2021-12-01 03:47:06 --> Router Class Initialized
INFO - 2021-12-01 03:47:06 --> Output Class Initialized
INFO - 2021-12-01 03:47:06 --> Security Class Initialized
DEBUG - 2021-12-01 03:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:47:06 --> Input Class Initialized
INFO - 2021-12-01 03:47:06 --> Language Class Initialized
INFO - 2021-12-01 03:47:06 --> Language Class Initialized
INFO - 2021-12-01 03:47:06 --> Config Class Initialized
INFO - 2021-12-01 03:47:06 --> Loader Class Initialized
INFO - 2021-12-01 03:47:06 --> Helper loaded: url_helper
INFO - 2021-12-01 03:47:06 --> Helper loaded: file_helper
INFO - 2021-12-01 03:47:06 --> Helper loaded: form_helper
INFO - 2021-12-01 03:47:06 --> Helper loaded: my_helper
INFO - 2021-12-01 03:47:06 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:47:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:47:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:47:06 --> Controller Class Initialized
DEBUG - 2021-12-01 03:47:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 03:47:06 --> Final output sent to browser
DEBUG - 2021-12-01 03:47:06 --> Total execution time: 0.2055
INFO - 2021-12-01 03:47:08 --> Config Class Initialized
INFO - 2021-12-01 03:47:08 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:47:08 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:47:08 --> Utf8 Class Initialized
INFO - 2021-12-01 03:47:08 --> URI Class Initialized
INFO - 2021-12-01 03:47:08 --> Router Class Initialized
INFO - 2021-12-01 03:47:08 --> Output Class Initialized
INFO - 2021-12-01 03:47:08 --> Security Class Initialized
DEBUG - 2021-12-01 03:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:47:08 --> Input Class Initialized
INFO - 2021-12-01 03:47:08 --> Language Class Initialized
INFO - 2021-12-01 03:47:08 --> Language Class Initialized
INFO - 2021-12-01 03:47:08 --> Config Class Initialized
INFO - 2021-12-01 03:47:08 --> Loader Class Initialized
INFO - 2021-12-01 03:47:08 --> Helper loaded: url_helper
INFO - 2021-12-01 03:47:08 --> Helper loaded: file_helper
INFO - 2021-12-01 03:47:08 --> Helper loaded: form_helper
INFO - 2021-12-01 03:47:08 --> Helper loaded: my_helper
INFO - 2021-12-01 03:47:08 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:47:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:47:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:47:08 --> Controller Class Initialized
DEBUG - 2021-12-01 03:47:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 03:47:08 --> Final output sent to browser
DEBUG - 2021-12-01 03:47:08 --> Total execution time: 0.2418
INFO - 2021-12-01 03:53:01 --> Config Class Initialized
INFO - 2021-12-01 03:53:01 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:53:01 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:53:01 --> Utf8 Class Initialized
INFO - 2021-12-01 03:53:01 --> URI Class Initialized
INFO - 2021-12-01 03:53:01 --> Router Class Initialized
INFO - 2021-12-01 03:53:01 --> Output Class Initialized
INFO - 2021-12-01 03:53:01 --> Security Class Initialized
DEBUG - 2021-12-01 03:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:53:01 --> Input Class Initialized
INFO - 2021-12-01 03:53:01 --> Language Class Initialized
INFO - 2021-12-01 03:53:01 --> Language Class Initialized
INFO - 2021-12-01 03:53:01 --> Config Class Initialized
INFO - 2021-12-01 03:53:01 --> Loader Class Initialized
INFO - 2021-12-01 03:53:01 --> Helper loaded: url_helper
INFO - 2021-12-01 03:53:01 --> Helper loaded: file_helper
INFO - 2021-12-01 03:53:01 --> Helper loaded: form_helper
INFO - 2021-12-01 03:53:01 --> Helper loaded: my_helper
INFO - 2021-12-01 03:53:01 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:53:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:53:01 --> Controller Class Initialized
DEBUG - 2021-12-01 03:53:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-01 03:53:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 03:53:01 --> Final output sent to browser
DEBUG - 2021-12-01 03:53:01 --> Total execution time: 0.1224
INFO - 2021-12-01 03:53:29 --> Config Class Initialized
INFO - 2021-12-01 03:53:29 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:53:29 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:53:29 --> Utf8 Class Initialized
INFO - 2021-12-01 03:53:29 --> URI Class Initialized
INFO - 2021-12-01 03:53:29 --> Router Class Initialized
INFO - 2021-12-01 03:53:29 --> Output Class Initialized
INFO - 2021-12-01 03:53:29 --> Security Class Initialized
DEBUG - 2021-12-01 03:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:53:29 --> Input Class Initialized
INFO - 2021-12-01 03:53:29 --> Language Class Initialized
INFO - 2021-12-01 03:53:29 --> Language Class Initialized
INFO - 2021-12-01 03:53:29 --> Config Class Initialized
INFO - 2021-12-01 03:53:29 --> Loader Class Initialized
INFO - 2021-12-01 03:53:29 --> Helper loaded: url_helper
INFO - 2021-12-01 03:53:29 --> Helper loaded: file_helper
INFO - 2021-12-01 03:53:29 --> Helper loaded: form_helper
INFO - 2021-12-01 03:53:29 --> Helper loaded: my_helper
INFO - 2021-12-01 03:53:29 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:53:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:53:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:53:29 --> Controller Class Initialized
INFO - 2021-12-01 03:53:29 --> Final output sent to browser
DEBUG - 2021-12-01 03:53:29 --> Total execution time: 0.2332
INFO - 2021-12-01 03:53:32 --> Config Class Initialized
INFO - 2021-12-01 03:53:32 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:53:32 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:53:32 --> Utf8 Class Initialized
INFO - 2021-12-01 03:53:32 --> URI Class Initialized
INFO - 2021-12-01 03:53:32 --> Router Class Initialized
INFO - 2021-12-01 03:53:32 --> Output Class Initialized
INFO - 2021-12-01 03:53:32 --> Security Class Initialized
DEBUG - 2021-12-01 03:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:53:32 --> Input Class Initialized
INFO - 2021-12-01 03:53:32 --> Language Class Initialized
INFO - 2021-12-01 03:53:32 --> Language Class Initialized
INFO - 2021-12-01 03:53:32 --> Config Class Initialized
INFO - 2021-12-01 03:53:32 --> Loader Class Initialized
INFO - 2021-12-01 03:53:32 --> Helper loaded: url_helper
INFO - 2021-12-01 03:53:32 --> Helper loaded: file_helper
INFO - 2021-12-01 03:53:32 --> Helper loaded: form_helper
INFO - 2021-12-01 03:53:32 --> Helper loaded: my_helper
INFO - 2021-12-01 03:53:32 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:53:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:53:32 --> Controller Class Initialized
DEBUG - 2021-12-01 03:53:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-01 03:53:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 03:53:32 --> Final output sent to browser
DEBUG - 2021-12-01 03:53:32 --> Total execution time: 0.0922
INFO - 2021-12-01 03:53:37 --> Config Class Initialized
INFO - 2021-12-01 03:53:37 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:53:37 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:53:37 --> Utf8 Class Initialized
INFO - 2021-12-01 03:53:37 --> URI Class Initialized
INFO - 2021-12-01 03:53:37 --> Router Class Initialized
INFO - 2021-12-01 03:53:37 --> Output Class Initialized
INFO - 2021-12-01 03:53:37 --> Security Class Initialized
DEBUG - 2021-12-01 03:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:53:37 --> Input Class Initialized
INFO - 2021-12-01 03:53:37 --> Language Class Initialized
INFO - 2021-12-01 03:53:37 --> Language Class Initialized
INFO - 2021-12-01 03:53:37 --> Config Class Initialized
INFO - 2021-12-01 03:53:37 --> Loader Class Initialized
INFO - 2021-12-01 03:53:37 --> Helper loaded: url_helper
INFO - 2021-12-01 03:53:37 --> Helper loaded: file_helper
INFO - 2021-12-01 03:53:37 --> Helper loaded: form_helper
INFO - 2021-12-01 03:53:37 --> Helper loaded: my_helper
INFO - 2021-12-01 03:53:37 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:53:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:53:37 --> Controller Class Initialized
DEBUG - 2021-12-01 03:53:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 03:53:37 --> Final output sent to browser
DEBUG - 2021-12-01 03:53:37 --> Total execution time: 0.2144
INFO - 2021-12-01 03:54:07 --> Config Class Initialized
INFO - 2021-12-01 03:54:07 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:54:07 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:54:07 --> Utf8 Class Initialized
INFO - 2021-12-01 03:54:07 --> URI Class Initialized
INFO - 2021-12-01 03:54:07 --> Router Class Initialized
INFO - 2021-12-01 03:54:07 --> Output Class Initialized
INFO - 2021-12-01 03:54:07 --> Security Class Initialized
DEBUG - 2021-12-01 03:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:54:07 --> Input Class Initialized
INFO - 2021-12-01 03:54:07 --> Language Class Initialized
INFO - 2021-12-01 03:54:07 --> Language Class Initialized
INFO - 2021-12-01 03:54:07 --> Config Class Initialized
INFO - 2021-12-01 03:54:07 --> Loader Class Initialized
INFO - 2021-12-01 03:54:07 --> Helper loaded: url_helper
INFO - 2021-12-01 03:54:07 --> Helper loaded: file_helper
INFO - 2021-12-01 03:54:07 --> Helper loaded: form_helper
INFO - 2021-12-01 03:54:07 --> Helper loaded: my_helper
INFO - 2021-12-01 03:54:07 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:54:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:54:07 --> Controller Class Initialized
DEBUG - 2021-12-01 03:54:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-01 03:54:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 03:54:07 --> Final output sent to browser
DEBUG - 2021-12-01 03:54:07 --> Total execution time: 0.1271
INFO - 2021-12-01 03:54:26 --> Config Class Initialized
INFO - 2021-12-01 03:54:26 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:54:26 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:54:26 --> Utf8 Class Initialized
INFO - 2021-12-01 03:54:26 --> URI Class Initialized
INFO - 2021-12-01 03:54:26 --> Router Class Initialized
INFO - 2021-12-01 03:54:26 --> Output Class Initialized
INFO - 2021-12-01 03:54:26 --> Security Class Initialized
DEBUG - 2021-12-01 03:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:54:26 --> Input Class Initialized
INFO - 2021-12-01 03:54:26 --> Language Class Initialized
INFO - 2021-12-01 03:54:26 --> Language Class Initialized
INFO - 2021-12-01 03:54:26 --> Config Class Initialized
INFO - 2021-12-01 03:54:26 --> Loader Class Initialized
INFO - 2021-12-01 03:54:26 --> Helper loaded: url_helper
INFO - 2021-12-01 03:54:26 --> Helper loaded: file_helper
INFO - 2021-12-01 03:54:26 --> Helper loaded: form_helper
INFO - 2021-12-01 03:54:26 --> Helper loaded: my_helper
INFO - 2021-12-01 03:54:26 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:54:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:54:26 --> Controller Class Initialized
INFO - 2021-12-01 03:54:26 --> Final output sent to browser
DEBUG - 2021-12-01 03:54:26 --> Total execution time: 0.2212
INFO - 2021-12-01 03:54:33 --> Config Class Initialized
INFO - 2021-12-01 03:54:33 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:54:33 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:54:33 --> Utf8 Class Initialized
INFO - 2021-12-01 03:54:33 --> URI Class Initialized
INFO - 2021-12-01 03:54:33 --> Router Class Initialized
INFO - 2021-12-01 03:54:33 --> Output Class Initialized
INFO - 2021-12-01 03:54:33 --> Security Class Initialized
DEBUG - 2021-12-01 03:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:54:33 --> Input Class Initialized
INFO - 2021-12-01 03:54:33 --> Language Class Initialized
INFO - 2021-12-01 03:54:33 --> Language Class Initialized
INFO - 2021-12-01 03:54:33 --> Config Class Initialized
INFO - 2021-12-01 03:54:33 --> Loader Class Initialized
INFO - 2021-12-01 03:54:33 --> Helper loaded: url_helper
INFO - 2021-12-01 03:54:33 --> Helper loaded: file_helper
INFO - 2021-12-01 03:54:33 --> Helper loaded: form_helper
INFO - 2021-12-01 03:54:33 --> Helper loaded: my_helper
INFO - 2021-12-01 03:54:33 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:54:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:54:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:54:33 --> Controller Class Initialized
DEBUG - 2021-12-01 03:54:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-01 03:54:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 03:54:33 --> Final output sent to browser
DEBUG - 2021-12-01 03:54:33 --> Total execution time: 0.0975
INFO - 2021-12-01 03:54:37 --> Config Class Initialized
INFO - 2021-12-01 03:54:37 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:54:37 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:54:37 --> Utf8 Class Initialized
INFO - 2021-12-01 03:54:37 --> URI Class Initialized
INFO - 2021-12-01 03:54:37 --> Router Class Initialized
INFO - 2021-12-01 03:54:37 --> Output Class Initialized
INFO - 2021-12-01 03:54:37 --> Security Class Initialized
DEBUG - 2021-12-01 03:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:54:37 --> Input Class Initialized
INFO - 2021-12-01 03:54:37 --> Language Class Initialized
INFO - 2021-12-01 03:54:37 --> Language Class Initialized
INFO - 2021-12-01 03:54:37 --> Config Class Initialized
INFO - 2021-12-01 03:54:37 --> Loader Class Initialized
INFO - 2021-12-01 03:54:37 --> Helper loaded: url_helper
INFO - 2021-12-01 03:54:37 --> Helper loaded: file_helper
INFO - 2021-12-01 03:54:37 --> Helper loaded: form_helper
INFO - 2021-12-01 03:54:37 --> Helper loaded: my_helper
INFO - 2021-12-01 03:54:37 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:54:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:54:37 --> Controller Class Initialized
DEBUG - 2021-12-01 03:54:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 03:54:37 --> Final output sent to browser
DEBUG - 2021-12-01 03:54:37 --> Total execution time: 0.2624
INFO - 2021-12-01 03:55:22 --> Config Class Initialized
INFO - 2021-12-01 03:55:22 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:55:22 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:55:22 --> Utf8 Class Initialized
INFO - 2021-12-01 03:55:22 --> URI Class Initialized
INFO - 2021-12-01 03:55:22 --> Router Class Initialized
INFO - 2021-12-01 03:55:22 --> Output Class Initialized
INFO - 2021-12-01 03:55:22 --> Security Class Initialized
DEBUG - 2021-12-01 03:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:55:22 --> Input Class Initialized
INFO - 2021-12-01 03:55:22 --> Language Class Initialized
INFO - 2021-12-01 03:55:22 --> Language Class Initialized
INFO - 2021-12-01 03:55:22 --> Config Class Initialized
INFO - 2021-12-01 03:55:22 --> Loader Class Initialized
INFO - 2021-12-01 03:55:22 --> Helper loaded: url_helper
INFO - 2021-12-01 03:55:22 --> Helper loaded: file_helper
INFO - 2021-12-01 03:55:22 --> Helper loaded: form_helper
INFO - 2021-12-01 03:55:22 --> Helper loaded: my_helper
INFO - 2021-12-01 03:55:22 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:55:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:55:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:55:22 --> Controller Class Initialized
DEBUG - 2021-12-01 03:55:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-01 03:55:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 03:55:22 --> Final output sent to browser
DEBUG - 2021-12-01 03:55:22 --> Total execution time: 0.1491
INFO - 2021-12-01 03:55:56 --> Config Class Initialized
INFO - 2021-12-01 03:55:56 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:55:56 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:55:56 --> Utf8 Class Initialized
INFO - 2021-12-01 03:55:56 --> URI Class Initialized
INFO - 2021-12-01 03:55:56 --> Router Class Initialized
INFO - 2021-12-01 03:55:56 --> Output Class Initialized
INFO - 2021-12-01 03:55:56 --> Security Class Initialized
DEBUG - 2021-12-01 03:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:55:56 --> Input Class Initialized
INFO - 2021-12-01 03:55:56 --> Language Class Initialized
INFO - 2021-12-01 03:55:56 --> Language Class Initialized
INFO - 2021-12-01 03:55:56 --> Config Class Initialized
INFO - 2021-12-01 03:55:56 --> Loader Class Initialized
INFO - 2021-12-01 03:55:56 --> Helper loaded: url_helper
INFO - 2021-12-01 03:55:56 --> Helper loaded: file_helper
INFO - 2021-12-01 03:55:56 --> Helper loaded: form_helper
INFO - 2021-12-01 03:55:56 --> Helper loaded: my_helper
INFO - 2021-12-01 03:55:56 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:55:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:55:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:55:56 --> Controller Class Initialized
INFO - 2021-12-01 03:55:56 --> Final output sent to browser
DEBUG - 2021-12-01 03:55:56 --> Total execution time: 0.2008
INFO - 2021-12-01 03:55:59 --> Config Class Initialized
INFO - 2021-12-01 03:55:59 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:55:59 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:55:59 --> Utf8 Class Initialized
INFO - 2021-12-01 03:55:59 --> URI Class Initialized
INFO - 2021-12-01 03:55:59 --> Router Class Initialized
INFO - 2021-12-01 03:55:59 --> Output Class Initialized
INFO - 2021-12-01 03:55:59 --> Security Class Initialized
DEBUG - 2021-12-01 03:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:55:59 --> Input Class Initialized
INFO - 2021-12-01 03:55:59 --> Language Class Initialized
INFO - 2021-12-01 03:55:59 --> Language Class Initialized
INFO - 2021-12-01 03:55:59 --> Config Class Initialized
INFO - 2021-12-01 03:55:59 --> Loader Class Initialized
INFO - 2021-12-01 03:55:59 --> Helper loaded: url_helper
INFO - 2021-12-01 03:55:59 --> Helper loaded: file_helper
INFO - 2021-12-01 03:55:59 --> Helper loaded: form_helper
INFO - 2021-12-01 03:55:59 --> Helper loaded: my_helper
INFO - 2021-12-01 03:55:59 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:55:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:55:59 --> Controller Class Initialized
DEBUG - 2021-12-01 03:55:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-01 03:55:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 03:55:59 --> Final output sent to browser
DEBUG - 2021-12-01 03:55:59 --> Total execution time: 0.0671
INFO - 2021-12-01 03:56:03 --> Config Class Initialized
INFO - 2021-12-01 03:56:03 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:56:03 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:56:03 --> Utf8 Class Initialized
INFO - 2021-12-01 03:56:03 --> URI Class Initialized
INFO - 2021-12-01 03:56:03 --> Router Class Initialized
INFO - 2021-12-01 03:56:03 --> Output Class Initialized
INFO - 2021-12-01 03:56:03 --> Security Class Initialized
DEBUG - 2021-12-01 03:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:56:03 --> Input Class Initialized
INFO - 2021-12-01 03:56:03 --> Language Class Initialized
INFO - 2021-12-01 03:56:03 --> Language Class Initialized
INFO - 2021-12-01 03:56:03 --> Config Class Initialized
INFO - 2021-12-01 03:56:03 --> Loader Class Initialized
INFO - 2021-12-01 03:56:03 --> Helper loaded: url_helper
INFO - 2021-12-01 03:56:03 --> Helper loaded: file_helper
INFO - 2021-12-01 03:56:03 --> Helper loaded: form_helper
INFO - 2021-12-01 03:56:03 --> Helper loaded: my_helper
INFO - 2021-12-01 03:56:03 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:56:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:56:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:56:03 --> Controller Class Initialized
DEBUG - 2021-12-01 03:56:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 03:56:03 --> Final output sent to browser
DEBUG - 2021-12-01 03:56:03 --> Total execution time: 0.2769
INFO - 2021-12-01 03:56:32 --> Config Class Initialized
INFO - 2021-12-01 03:56:32 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:56:32 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:56:32 --> Utf8 Class Initialized
INFO - 2021-12-01 03:56:32 --> URI Class Initialized
INFO - 2021-12-01 03:56:32 --> Router Class Initialized
INFO - 2021-12-01 03:56:32 --> Output Class Initialized
INFO - 2021-12-01 03:56:32 --> Security Class Initialized
DEBUG - 2021-12-01 03:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:56:32 --> Input Class Initialized
INFO - 2021-12-01 03:56:32 --> Language Class Initialized
INFO - 2021-12-01 03:56:32 --> Language Class Initialized
INFO - 2021-12-01 03:56:32 --> Config Class Initialized
INFO - 2021-12-01 03:56:32 --> Loader Class Initialized
INFO - 2021-12-01 03:56:32 --> Helper loaded: url_helper
INFO - 2021-12-01 03:56:32 --> Helper loaded: file_helper
INFO - 2021-12-01 03:56:32 --> Helper loaded: form_helper
INFO - 2021-12-01 03:56:32 --> Helper loaded: my_helper
INFO - 2021-12-01 03:56:32 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:56:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:56:32 --> Controller Class Initialized
DEBUG - 2021-12-01 03:56:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-01 03:56:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 03:56:32 --> Final output sent to browser
DEBUG - 2021-12-01 03:56:32 --> Total execution time: 0.1338
INFO - 2021-12-01 03:56:59 --> Config Class Initialized
INFO - 2021-12-01 03:56:59 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:56:59 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:56:59 --> Utf8 Class Initialized
INFO - 2021-12-01 03:56:59 --> URI Class Initialized
INFO - 2021-12-01 03:56:59 --> Router Class Initialized
INFO - 2021-12-01 03:56:59 --> Output Class Initialized
INFO - 2021-12-01 03:56:59 --> Security Class Initialized
DEBUG - 2021-12-01 03:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:56:59 --> Input Class Initialized
INFO - 2021-12-01 03:56:59 --> Language Class Initialized
INFO - 2021-12-01 03:57:00 --> Language Class Initialized
INFO - 2021-12-01 03:57:00 --> Config Class Initialized
INFO - 2021-12-01 03:57:00 --> Loader Class Initialized
INFO - 2021-12-01 03:57:00 --> Helper loaded: url_helper
INFO - 2021-12-01 03:57:00 --> Helper loaded: file_helper
INFO - 2021-12-01 03:57:00 --> Helper loaded: form_helper
INFO - 2021-12-01 03:57:00 --> Helper loaded: my_helper
INFO - 2021-12-01 03:57:00 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:57:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:57:00 --> Controller Class Initialized
INFO - 2021-12-01 03:57:00 --> Final output sent to browser
DEBUG - 2021-12-01 03:57:00 --> Total execution time: 0.2011
INFO - 2021-12-01 03:57:02 --> Config Class Initialized
INFO - 2021-12-01 03:57:02 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:57:02 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:57:02 --> Utf8 Class Initialized
INFO - 2021-12-01 03:57:02 --> URI Class Initialized
INFO - 2021-12-01 03:57:02 --> Router Class Initialized
INFO - 2021-12-01 03:57:02 --> Output Class Initialized
INFO - 2021-12-01 03:57:02 --> Security Class Initialized
DEBUG - 2021-12-01 03:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:57:02 --> Input Class Initialized
INFO - 2021-12-01 03:57:02 --> Language Class Initialized
INFO - 2021-12-01 03:57:02 --> Language Class Initialized
INFO - 2021-12-01 03:57:02 --> Config Class Initialized
INFO - 2021-12-01 03:57:02 --> Loader Class Initialized
INFO - 2021-12-01 03:57:02 --> Helper loaded: url_helper
INFO - 2021-12-01 03:57:02 --> Helper loaded: file_helper
INFO - 2021-12-01 03:57:02 --> Helper loaded: form_helper
INFO - 2021-12-01 03:57:02 --> Helper loaded: my_helper
INFO - 2021-12-01 03:57:02 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:57:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:57:02 --> Controller Class Initialized
DEBUG - 2021-12-01 03:57:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-01 03:57:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 03:57:02 --> Final output sent to browser
DEBUG - 2021-12-01 03:57:02 --> Total execution time: 0.0772
INFO - 2021-12-01 03:57:06 --> Config Class Initialized
INFO - 2021-12-01 03:57:06 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:57:06 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:57:06 --> Utf8 Class Initialized
INFO - 2021-12-01 03:57:06 --> URI Class Initialized
INFO - 2021-12-01 03:57:06 --> Router Class Initialized
INFO - 2021-12-01 03:57:06 --> Output Class Initialized
INFO - 2021-12-01 03:57:06 --> Security Class Initialized
DEBUG - 2021-12-01 03:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:57:06 --> Input Class Initialized
INFO - 2021-12-01 03:57:06 --> Language Class Initialized
INFO - 2021-12-01 03:57:06 --> Language Class Initialized
INFO - 2021-12-01 03:57:06 --> Config Class Initialized
INFO - 2021-12-01 03:57:06 --> Loader Class Initialized
INFO - 2021-12-01 03:57:06 --> Helper loaded: url_helper
INFO - 2021-12-01 03:57:06 --> Helper loaded: file_helper
INFO - 2021-12-01 03:57:06 --> Helper loaded: form_helper
INFO - 2021-12-01 03:57:06 --> Helper loaded: my_helper
INFO - 2021-12-01 03:57:06 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:57:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:57:06 --> Controller Class Initialized
DEBUG - 2021-12-01 03:57:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 03:57:06 --> Final output sent to browser
DEBUG - 2021-12-01 03:57:06 --> Total execution time: 0.2997
INFO - 2021-12-01 03:57:35 --> Config Class Initialized
INFO - 2021-12-01 03:57:35 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:57:35 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:57:35 --> Utf8 Class Initialized
INFO - 2021-12-01 03:57:35 --> URI Class Initialized
INFO - 2021-12-01 03:57:35 --> Router Class Initialized
INFO - 2021-12-01 03:57:35 --> Output Class Initialized
INFO - 2021-12-01 03:57:35 --> Security Class Initialized
DEBUG - 2021-12-01 03:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:57:35 --> Input Class Initialized
INFO - 2021-12-01 03:57:35 --> Language Class Initialized
INFO - 2021-12-01 03:57:35 --> Language Class Initialized
INFO - 2021-12-01 03:57:35 --> Config Class Initialized
INFO - 2021-12-01 03:57:35 --> Loader Class Initialized
INFO - 2021-12-01 03:57:35 --> Helper loaded: url_helper
INFO - 2021-12-01 03:57:35 --> Helper loaded: file_helper
INFO - 2021-12-01 03:57:35 --> Helper loaded: form_helper
INFO - 2021-12-01 03:57:35 --> Helper loaded: my_helper
INFO - 2021-12-01 03:57:35 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:57:35 --> Controller Class Initialized
DEBUG - 2021-12-01 03:57:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-01 03:57:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 03:57:35 --> Final output sent to browser
DEBUG - 2021-12-01 03:57:35 --> Total execution time: 0.1305
INFO - 2021-12-01 03:57:51 --> Config Class Initialized
INFO - 2021-12-01 03:57:51 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:57:51 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:57:51 --> Utf8 Class Initialized
INFO - 2021-12-01 03:57:51 --> URI Class Initialized
INFO - 2021-12-01 03:57:51 --> Router Class Initialized
INFO - 2021-12-01 03:57:51 --> Output Class Initialized
INFO - 2021-12-01 03:57:51 --> Security Class Initialized
DEBUG - 2021-12-01 03:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:57:51 --> Input Class Initialized
INFO - 2021-12-01 03:57:51 --> Language Class Initialized
INFO - 2021-12-01 03:57:51 --> Language Class Initialized
INFO - 2021-12-01 03:57:51 --> Config Class Initialized
INFO - 2021-12-01 03:57:51 --> Loader Class Initialized
INFO - 2021-12-01 03:57:51 --> Helper loaded: url_helper
INFO - 2021-12-01 03:57:51 --> Helper loaded: file_helper
INFO - 2021-12-01 03:57:51 --> Helper loaded: form_helper
INFO - 2021-12-01 03:57:51 --> Helper loaded: my_helper
INFO - 2021-12-01 03:57:51 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:57:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:57:51 --> Controller Class Initialized
INFO - 2021-12-01 03:57:51 --> Final output sent to browser
DEBUG - 2021-12-01 03:57:51 --> Total execution time: 0.1779
INFO - 2021-12-01 03:57:55 --> Config Class Initialized
INFO - 2021-12-01 03:57:55 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:57:55 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:57:55 --> Utf8 Class Initialized
INFO - 2021-12-01 03:57:55 --> URI Class Initialized
INFO - 2021-12-01 03:57:55 --> Router Class Initialized
INFO - 2021-12-01 03:57:55 --> Output Class Initialized
INFO - 2021-12-01 03:57:55 --> Security Class Initialized
DEBUG - 2021-12-01 03:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:57:55 --> Input Class Initialized
INFO - 2021-12-01 03:57:55 --> Language Class Initialized
INFO - 2021-12-01 03:57:55 --> Language Class Initialized
INFO - 2021-12-01 03:57:55 --> Config Class Initialized
INFO - 2021-12-01 03:57:55 --> Loader Class Initialized
INFO - 2021-12-01 03:57:55 --> Helper loaded: url_helper
INFO - 2021-12-01 03:57:55 --> Helper loaded: file_helper
INFO - 2021-12-01 03:57:55 --> Helper loaded: form_helper
INFO - 2021-12-01 03:57:55 --> Helper loaded: my_helper
INFO - 2021-12-01 03:57:55 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:57:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:57:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:57:55 --> Controller Class Initialized
DEBUG - 2021-12-01 03:57:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-01 03:57:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 03:57:55 --> Final output sent to browser
DEBUG - 2021-12-01 03:57:55 --> Total execution time: 0.1367
INFO - 2021-12-01 03:57:59 --> Config Class Initialized
INFO - 2021-12-01 03:57:59 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:57:59 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:57:59 --> Utf8 Class Initialized
INFO - 2021-12-01 03:57:59 --> URI Class Initialized
INFO - 2021-12-01 03:57:59 --> Router Class Initialized
INFO - 2021-12-01 03:57:59 --> Output Class Initialized
INFO - 2021-12-01 03:57:59 --> Security Class Initialized
DEBUG - 2021-12-01 03:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:57:59 --> Input Class Initialized
INFO - 2021-12-01 03:57:59 --> Language Class Initialized
INFO - 2021-12-01 03:57:59 --> Language Class Initialized
INFO - 2021-12-01 03:57:59 --> Config Class Initialized
INFO - 2021-12-01 03:57:59 --> Loader Class Initialized
INFO - 2021-12-01 03:57:59 --> Helper loaded: url_helper
INFO - 2021-12-01 03:57:59 --> Helper loaded: file_helper
INFO - 2021-12-01 03:57:59 --> Helper loaded: form_helper
INFO - 2021-12-01 03:57:59 --> Helper loaded: my_helper
INFO - 2021-12-01 03:57:59 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:57:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:57:59 --> Controller Class Initialized
DEBUG - 2021-12-01 03:58:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 03:58:00 --> Final output sent to browser
DEBUG - 2021-12-01 03:58:00 --> Total execution time: 0.2880
INFO - 2021-12-01 03:58:54 --> Config Class Initialized
INFO - 2021-12-01 03:58:54 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:58:54 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:58:54 --> Utf8 Class Initialized
INFO - 2021-12-01 03:58:54 --> URI Class Initialized
INFO - 2021-12-01 03:58:54 --> Router Class Initialized
INFO - 2021-12-01 03:58:54 --> Output Class Initialized
INFO - 2021-12-01 03:58:54 --> Security Class Initialized
DEBUG - 2021-12-01 03:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:58:54 --> Input Class Initialized
INFO - 2021-12-01 03:58:54 --> Language Class Initialized
INFO - 2021-12-01 03:58:54 --> Language Class Initialized
INFO - 2021-12-01 03:58:54 --> Config Class Initialized
INFO - 2021-12-01 03:58:54 --> Loader Class Initialized
INFO - 2021-12-01 03:58:54 --> Helper loaded: url_helper
INFO - 2021-12-01 03:58:54 --> Helper loaded: file_helper
INFO - 2021-12-01 03:58:54 --> Helper loaded: form_helper
INFO - 2021-12-01 03:58:54 --> Helper loaded: my_helper
INFO - 2021-12-01 03:58:54 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:58:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:58:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:58:54 --> Controller Class Initialized
DEBUG - 2021-12-01 03:58:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-01 03:58:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 03:58:54 --> Final output sent to browser
DEBUG - 2021-12-01 03:58:54 --> Total execution time: 0.1484
INFO - 2021-12-01 03:59:18 --> Config Class Initialized
INFO - 2021-12-01 03:59:18 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:59:18 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:59:18 --> Utf8 Class Initialized
INFO - 2021-12-01 03:59:18 --> URI Class Initialized
INFO - 2021-12-01 03:59:18 --> Router Class Initialized
INFO - 2021-12-01 03:59:18 --> Output Class Initialized
INFO - 2021-12-01 03:59:18 --> Security Class Initialized
DEBUG - 2021-12-01 03:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:59:18 --> Input Class Initialized
INFO - 2021-12-01 03:59:18 --> Language Class Initialized
INFO - 2021-12-01 03:59:18 --> Language Class Initialized
INFO - 2021-12-01 03:59:18 --> Config Class Initialized
INFO - 2021-12-01 03:59:18 --> Loader Class Initialized
INFO - 2021-12-01 03:59:18 --> Helper loaded: url_helper
INFO - 2021-12-01 03:59:18 --> Helper loaded: file_helper
INFO - 2021-12-01 03:59:18 --> Helper loaded: form_helper
INFO - 2021-12-01 03:59:18 --> Helper loaded: my_helper
INFO - 2021-12-01 03:59:18 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:59:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:59:18 --> Controller Class Initialized
INFO - 2021-12-01 03:59:18 --> Final output sent to browser
DEBUG - 2021-12-01 03:59:18 --> Total execution time: 0.1695
INFO - 2021-12-01 03:59:20 --> Config Class Initialized
INFO - 2021-12-01 03:59:20 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:59:20 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:59:20 --> Utf8 Class Initialized
INFO - 2021-12-01 03:59:20 --> URI Class Initialized
INFO - 2021-12-01 03:59:20 --> Router Class Initialized
INFO - 2021-12-01 03:59:20 --> Output Class Initialized
INFO - 2021-12-01 03:59:20 --> Security Class Initialized
DEBUG - 2021-12-01 03:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:59:20 --> Input Class Initialized
INFO - 2021-12-01 03:59:20 --> Language Class Initialized
INFO - 2021-12-01 03:59:20 --> Language Class Initialized
INFO - 2021-12-01 03:59:20 --> Config Class Initialized
INFO - 2021-12-01 03:59:20 --> Loader Class Initialized
INFO - 2021-12-01 03:59:20 --> Helper loaded: url_helper
INFO - 2021-12-01 03:59:20 --> Helper loaded: file_helper
INFO - 2021-12-01 03:59:20 --> Helper loaded: form_helper
INFO - 2021-12-01 03:59:20 --> Helper loaded: my_helper
INFO - 2021-12-01 03:59:20 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:59:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:59:20 --> Controller Class Initialized
DEBUG - 2021-12-01 03:59:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-01 03:59:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 03:59:20 --> Final output sent to browser
DEBUG - 2021-12-01 03:59:20 --> Total execution time: 0.0952
INFO - 2021-12-01 03:59:34 --> Config Class Initialized
INFO - 2021-12-01 03:59:34 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:59:34 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:59:34 --> Utf8 Class Initialized
INFO - 2021-12-01 03:59:34 --> URI Class Initialized
INFO - 2021-12-01 03:59:34 --> Router Class Initialized
INFO - 2021-12-01 03:59:34 --> Output Class Initialized
INFO - 2021-12-01 03:59:34 --> Security Class Initialized
DEBUG - 2021-12-01 03:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:59:34 --> Input Class Initialized
INFO - 2021-12-01 03:59:34 --> Language Class Initialized
INFO - 2021-12-01 03:59:35 --> Language Class Initialized
INFO - 2021-12-01 03:59:35 --> Config Class Initialized
INFO - 2021-12-01 03:59:35 --> Loader Class Initialized
INFO - 2021-12-01 03:59:35 --> Helper loaded: url_helper
INFO - 2021-12-01 03:59:35 --> Helper loaded: file_helper
INFO - 2021-12-01 03:59:35 --> Helper loaded: form_helper
INFO - 2021-12-01 03:59:35 --> Helper loaded: my_helper
INFO - 2021-12-01 03:59:35 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:59:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:59:35 --> Controller Class Initialized
DEBUG - 2021-12-01 03:59:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 03:59:35 --> Final output sent to browser
DEBUG - 2021-12-01 03:59:35 --> Total execution time: 0.2459
INFO - 2021-12-01 03:59:49 --> Config Class Initialized
INFO - 2021-12-01 03:59:49 --> Hooks Class Initialized
DEBUG - 2021-12-01 03:59:49 --> UTF-8 Support Enabled
INFO - 2021-12-01 03:59:49 --> Utf8 Class Initialized
INFO - 2021-12-01 03:59:49 --> URI Class Initialized
INFO - 2021-12-01 03:59:49 --> Router Class Initialized
INFO - 2021-12-01 03:59:49 --> Output Class Initialized
INFO - 2021-12-01 03:59:49 --> Security Class Initialized
DEBUG - 2021-12-01 03:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 03:59:49 --> Input Class Initialized
INFO - 2021-12-01 03:59:49 --> Language Class Initialized
INFO - 2021-12-01 03:59:49 --> Language Class Initialized
INFO - 2021-12-01 03:59:49 --> Config Class Initialized
INFO - 2021-12-01 03:59:49 --> Loader Class Initialized
INFO - 2021-12-01 03:59:49 --> Helper loaded: url_helper
INFO - 2021-12-01 03:59:49 --> Helper loaded: file_helper
INFO - 2021-12-01 03:59:49 --> Helper loaded: form_helper
INFO - 2021-12-01 03:59:49 --> Helper loaded: my_helper
INFO - 2021-12-01 03:59:49 --> Database Driver Class Initialized
DEBUG - 2021-12-01 03:59:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 03:59:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 03:59:49 --> Controller Class Initialized
DEBUG - 2021-12-01 03:59:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-01 03:59:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 03:59:49 --> Final output sent to browser
DEBUG - 2021-12-01 03:59:49 --> Total execution time: 0.0841
INFO - 2021-12-01 04:00:18 --> Config Class Initialized
INFO - 2021-12-01 04:00:18 --> Hooks Class Initialized
DEBUG - 2021-12-01 04:00:18 --> UTF-8 Support Enabled
INFO - 2021-12-01 04:00:18 --> Utf8 Class Initialized
INFO - 2021-12-01 04:00:18 --> URI Class Initialized
INFO - 2021-12-01 04:00:18 --> Router Class Initialized
INFO - 2021-12-01 04:00:18 --> Output Class Initialized
INFO - 2021-12-01 04:00:18 --> Security Class Initialized
DEBUG - 2021-12-01 04:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 04:00:18 --> Input Class Initialized
INFO - 2021-12-01 04:00:18 --> Language Class Initialized
INFO - 2021-12-01 04:00:18 --> Language Class Initialized
INFO - 2021-12-01 04:00:18 --> Config Class Initialized
INFO - 2021-12-01 04:00:18 --> Loader Class Initialized
INFO - 2021-12-01 04:00:18 --> Helper loaded: url_helper
INFO - 2021-12-01 04:00:18 --> Helper loaded: file_helper
INFO - 2021-12-01 04:00:18 --> Helper loaded: form_helper
INFO - 2021-12-01 04:00:18 --> Helper loaded: my_helper
INFO - 2021-12-01 04:00:18 --> Database Driver Class Initialized
DEBUG - 2021-12-01 04:00:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 04:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 04:00:18 --> Controller Class Initialized
DEBUG - 2021-12-01 04:00:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-01 04:00:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 04:00:18 --> Final output sent to browser
DEBUG - 2021-12-01 04:00:18 --> Total execution time: 0.1446
INFO - 2021-12-01 04:00:37 --> Config Class Initialized
INFO - 2021-12-01 04:00:37 --> Hooks Class Initialized
DEBUG - 2021-12-01 04:00:37 --> UTF-8 Support Enabled
INFO - 2021-12-01 04:00:37 --> Utf8 Class Initialized
INFO - 2021-12-01 04:00:37 --> URI Class Initialized
INFO - 2021-12-01 04:00:37 --> Router Class Initialized
INFO - 2021-12-01 04:00:37 --> Output Class Initialized
INFO - 2021-12-01 04:00:37 --> Security Class Initialized
DEBUG - 2021-12-01 04:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 04:00:37 --> Input Class Initialized
INFO - 2021-12-01 04:00:37 --> Language Class Initialized
INFO - 2021-12-01 04:00:37 --> Language Class Initialized
INFO - 2021-12-01 04:00:37 --> Config Class Initialized
INFO - 2021-12-01 04:00:37 --> Loader Class Initialized
INFO - 2021-12-01 04:00:37 --> Helper loaded: url_helper
INFO - 2021-12-01 04:00:37 --> Helper loaded: file_helper
INFO - 2021-12-01 04:00:37 --> Helper loaded: form_helper
INFO - 2021-12-01 04:00:37 --> Helper loaded: my_helper
INFO - 2021-12-01 04:00:37 --> Database Driver Class Initialized
DEBUG - 2021-12-01 04:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 04:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 04:00:37 --> Controller Class Initialized
INFO - 2021-12-01 04:00:37 --> Final output sent to browser
DEBUG - 2021-12-01 04:00:37 --> Total execution time: 0.2001
INFO - 2021-12-01 04:00:41 --> Config Class Initialized
INFO - 2021-12-01 04:00:41 --> Hooks Class Initialized
DEBUG - 2021-12-01 04:00:41 --> UTF-8 Support Enabled
INFO - 2021-12-01 04:00:41 --> Utf8 Class Initialized
INFO - 2021-12-01 04:00:41 --> URI Class Initialized
INFO - 2021-12-01 04:00:41 --> Router Class Initialized
INFO - 2021-12-01 04:00:41 --> Output Class Initialized
INFO - 2021-12-01 04:00:41 --> Security Class Initialized
DEBUG - 2021-12-01 04:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 04:00:41 --> Input Class Initialized
INFO - 2021-12-01 04:00:41 --> Language Class Initialized
INFO - 2021-12-01 04:00:41 --> Language Class Initialized
INFO - 2021-12-01 04:00:41 --> Config Class Initialized
INFO - 2021-12-01 04:00:41 --> Loader Class Initialized
INFO - 2021-12-01 04:00:41 --> Helper loaded: url_helper
INFO - 2021-12-01 04:00:41 --> Helper loaded: file_helper
INFO - 2021-12-01 04:00:41 --> Helper loaded: form_helper
INFO - 2021-12-01 04:00:41 --> Helper loaded: my_helper
INFO - 2021-12-01 04:00:41 --> Database Driver Class Initialized
DEBUG - 2021-12-01 04:00:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 04:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 04:00:41 --> Controller Class Initialized
DEBUG - 2021-12-01 04:00:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-01 04:00:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 04:00:41 --> Final output sent to browser
DEBUG - 2021-12-01 04:00:41 --> Total execution time: 0.0961
INFO - 2021-12-01 04:00:49 --> Config Class Initialized
INFO - 2021-12-01 04:00:49 --> Hooks Class Initialized
DEBUG - 2021-12-01 04:00:49 --> UTF-8 Support Enabled
INFO - 2021-12-01 04:00:49 --> Utf8 Class Initialized
INFO - 2021-12-01 04:00:49 --> URI Class Initialized
INFO - 2021-12-01 04:00:49 --> Router Class Initialized
INFO - 2021-12-01 04:00:49 --> Output Class Initialized
INFO - 2021-12-01 04:00:49 --> Security Class Initialized
DEBUG - 2021-12-01 04:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 04:00:49 --> Input Class Initialized
INFO - 2021-12-01 04:00:49 --> Language Class Initialized
INFO - 2021-12-01 04:00:49 --> Language Class Initialized
INFO - 2021-12-01 04:00:49 --> Config Class Initialized
INFO - 2021-12-01 04:00:49 --> Loader Class Initialized
INFO - 2021-12-01 04:00:49 --> Helper loaded: url_helper
INFO - 2021-12-01 04:00:49 --> Helper loaded: file_helper
INFO - 2021-12-01 04:00:49 --> Helper loaded: form_helper
INFO - 2021-12-01 04:00:49 --> Helper loaded: my_helper
INFO - 2021-12-01 04:00:49 --> Database Driver Class Initialized
DEBUG - 2021-12-01 04:00:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 04:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 04:00:49 --> Controller Class Initialized
DEBUG - 2021-12-01 04:00:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 04:00:49 --> Final output sent to browser
DEBUG - 2021-12-01 04:00:49 --> Total execution time: 0.2625
INFO - 2021-12-01 04:01:48 --> Config Class Initialized
INFO - 2021-12-01 04:01:48 --> Hooks Class Initialized
DEBUG - 2021-12-01 04:01:48 --> UTF-8 Support Enabled
INFO - 2021-12-01 04:01:48 --> Utf8 Class Initialized
INFO - 2021-12-01 04:01:48 --> URI Class Initialized
INFO - 2021-12-01 04:01:48 --> Router Class Initialized
INFO - 2021-12-01 04:01:48 --> Output Class Initialized
INFO - 2021-12-01 04:01:48 --> Security Class Initialized
DEBUG - 2021-12-01 04:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 04:01:48 --> Input Class Initialized
INFO - 2021-12-01 04:01:48 --> Language Class Initialized
INFO - 2021-12-01 04:01:48 --> Language Class Initialized
INFO - 2021-12-01 04:01:48 --> Config Class Initialized
INFO - 2021-12-01 04:01:48 --> Loader Class Initialized
INFO - 2021-12-01 04:01:48 --> Helper loaded: url_helper
INFO - 2021-12-01 04:01:48 --> Helper loaded: file_helper
INFO - 2021-12-01 04:01:48 --> Helper loaded: form_helper
INFO - 2021-12-01 04:01:48 --> Helper loaded: my_helper
INFO - 2021-12-01 04:01:48 --> Database Driver Class Initialized
DEBUG - 2021-12-01 04:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 04:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 04:01:48 --> Controller Class Initialized
DEBUG - 2021-12-01 04:01:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-01 04:01:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 04:01:48 --> Final output sent to browser
DEBUG - 2021-12-01 04:01:48 --> Total execution time: 0.1497
INFO - 2021-12-01 04:02:06 --> Config Class Initialized
INFO - 2021-12-01 04:02:06 --> Hooks Class Initialized
DEBUG - 2021-12-01 04:02:06 --> UTF-8 Support Enabled
INFO - 2021-12-01 04:02:06 --> Utf8 Class Initialized
INFO - 2021-12-01 04:02:06 --> URI Class Initialized
INFO - 2021-12-01 04:02:06 --> Router Class Initialized
INFO - 2021-12-01 04:02:06 --> Output Class Initialized
INFO - 2021-12-01 04:02:06 --> Security Class Initialized
DEBUG - 2021-12-01 04:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 04:02:06 --> Input Class Initialized
INFO - 2021-12-01 04:02:06 --> Language Class Initialized
INFO - 2021-12-01 04:02:06 --> Language Class Initialized
INFO - 2021-12-01 04:02:06 --> Config Class Initialized
INFO - 2021-12-01 04:02:06 --> Loader Class Initialized
INFO - 2021-12-01 04:02:06 --> Helper loaded: url_helper
INFO - 2021-12-01 04:02:06 --> Helper loaded: file_helper
INFO - 2021-12-01 04:02:06 --> Helper loaded: form_helper
INFO - 2021-12-01 04:02:06 --> Helper loaded: my_helper
INFO - 2021-12-01 04:02:06 --> Database Driver Class Initialized
DEBUG - 2021-12-01 04:02:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 04:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 04:02:06 --> Controller Class Initialized
INFO - 2021-12-01 04:02:06 --> Final output sent to browser
DEBUG - 2021-12-01 04:02:06 --> Total execution time: 0.1907
INFO - 2021-12-01 04:02:10 --> Config Class Initialized
INFO - 2021-12-01 04:02:10 --> Hooks Class Initialized
DEBUG - 2021-12-01 04:02:10 --> UTF-8 Support Enabled
INFO - 2021-12-01 04:02:10 --> Utf8 Class Initialized
INFO - 2021-12-01 04:02:10 --> URI Class Initialized
INFO - 2021-12-01 04:02:10 --> Router Class Initialized
INFO - 2021-12-01 04:02:10 --> Output Class Initialized
INFO - 2021-12-01 04:02:10 --> Security Class Initialized
DEBUG - 2021-12-01 04:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 04:02:10 --> Input Class Initialized
INFO - 2021-12-01 04:02:10 --> Language Class Initialized
INFO - 2021-12-01 04:02:10 --> Language Class Initialized
INFO - 2021-12-01 04:02:10 --> Config Class Initialized
INFO - 2021-12-01 04:02:10 --> Loader Class Initialized
INFO - 2021-12-01 04:02:10 --> Helper loaded: url_helper
INFO - 2021-12-01 04:02:10 --> Helper loaded: file_helper
INFO - 2021-12-01 04:02:10 --> Helper loaded: form_helper
INFO - 2021-12-01 04:02:10 --> Helper loaded: my_helper
INFO - 2021-12-01 04:02:10 --> Database Driver Class Initialized
DEBUG - 2021-12-01 04:02:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 04:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 04:02:10 --> Controller Class Initialized
DEBUG - 2021-12-01 04:02:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-01 04:02:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 04:02:10 --> Final output sent to browser
DEBUG - 2021-12-01 04:02:10 --> Total execution time: 0.1053
INFO - 2021-12-01 04:02:16 --> Config Class Initialized
INFO - 2021-12-01 04:02:16 --> Hooks Class Initialized
DEBUG - 2021-12-01 04:02:16 --> UTF-8 Support Enabled
INFO - 2021-12-01 04:02:16 --> Utf8 Class Initialized
INFO - 2021-12-01 04:02:16 --> URI Class Initialized
INFO - 2021-12-01 04:02:16 --> Router Class Initialized
INFO - 2021-12-01 04:02:16 --> Output Class Initialized
INFO - 2021-12-01 04:02:16 --> Security Class Initialized
DEBUG - 2021-12-01 04:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 04:02:16 --> Input Class Initialized
INFO - 2021-12-01 04:02:16 --> Language Class Initialized
INFO - 2021-12-01 04:02:16 --> Language Class Initialized
INFO - 2021-12-01 04:02:16 --> Config Class Initialized
INFO - 2021-12-01 04:02:16 --> Loader Class Initialized
INFO - 2021-12-01 04:02:16 --> Helper loaded: url_helper
INFO - 2021-12-01 04:02:16 --> Helper loaded: file_helper
INFO - 2021-12-01 04:02:16 --> Helper loaded: form_helper
INFO - 2021-12-01 04:02:16 --> Helper loaded: my_helper
INFO - 2021-12-01 04:02:16 --> Database Driver Class Initialized
DEBUG - 2021-12-01 04:02:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 04:02:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 04:02:16 --> Controller Class Initialized
DEBUG - 2021-12-01 04:02:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 04:02:16 --> Final output sent to browser
DEBUG - 2021-12-01 04:02:16 --> Total execution time: 0.2668
INFO - 2021-12-01 04:02:42 --> Config Class Initialized
INFO - 2021-12-01 04:02:42 --> Hooks Class Initialized
DEBUG - 2021-12-01 04:02:42 --> UTF-8 Support Enabled
INFO - 2021-12-01 04:02:42 --> Utf8 Class Initialized
INFO - 2021-12-01 04:02:42 --> URI Class Initialized
INFO - 2021-12-01 04:02:42 --> Router Class Initialized
INFO - 2021-12-01 04:02:42 --> Output Class Initialized
INFO - 2021-12-01 04:02:42 --> Security Class Initialized
DEBUG - 2021-12-01 04:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 04:02:42 --> Input Class Initialized
INFO - 2021-12-01 04:02:42 --> Language Class Initialized
INFO - 2021-12-01 04:02:42 --> Language Class Initialized
INFO - 2021-12-01 04:02:42 --> Config Class Initialized
INFO - 2021-12-01 04:02:42 --> Loader Class Initialized
INFO - 2021-12-01 04:02:42 --> Helper loaded: url_helper
INFO - 2021-12-01 04:02:42 --> Helper loaded: file_helper
INFO - 2021-12-01 04:02:42 --> Helper loaded: form_helper
INFO - 2021-12-01 04:02:42 --> Helper loaded: my_helper
INFO - 2021-12-01 04:02:42 --> Database Driver Class Initialized
DEBUG - 2021-12-01 04:02:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 04:02:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 04:02:42 --> Controller Class Initialized
DEBUG - 2021-12-01 04:02:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-01 04:02:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 04:02:42 --> Final output sent to browser
DEBUG - 2021-12-01 04:02:42 --> Total execution time: 0.1347
INFO - 2021-12-01 04:03:01 --> Config Class Initialized
INFO - 2021-12-01 04:03:01 --> Hooks Class Initialized
DEBUG - 2021-12-01 04:03:01 --> UTF-8 Support Enabled
INFO - 2021-12-01 04:03:01 --> Utf8 Class Initialized
INFO - 2021-12-01 04:03:01 --> URI Class Initialized
INFO - 2021-12-01 04:03:01 --> Router Class Initialized
INFO - 2021-12-01 04:03:01 --> Output Class Initialized
INFO - 2021-12-01 04:03:01 --> Security Class Initialized
DEBUG - 2021-12-01 04:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 04:03:01 --> Input Class Initialized
INFO - 2021-12-01 04:03:01 --> Language Class Initialized
INFO - 2021-12-01 04:03:01 --> Language Class Initialized
INFO - 2021-12-01 04:03:01 --> Config Class Initialized
INFO - 2021-12-01 04:03:01 --> Loader Class Initialized
INFO - 2021-12-01 04:03:01 --> Helper loaded: url_helper
INFO - 2021-12-01 04:03:01 --> Helper loaded: file_helper
INFO - 2021-12-01 04:03:01 --> Helper loaded: form_helper
INFO - 2021-12-01 04:03:01 --> Helper loaded: my_helper
INFO - 2021-12-01 04:03:01 --> Database Driver Class Initialized
DEBUG - 2021-12-01 04:03:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 04:03:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 04:03:01 --> Controller Class Initialized
INFO - 2021-12-01 04:03:01 --> Final output sent to browser
DEBUG - 2021-12-01 04:03:01 --> Total execution time: 0.2153
INFO - 2021-12-01 04:03:03 --> Config Class Initialized
INFO - 2021-12-01 04:03:03 --> Hooks Class Initialized
DEBUG - 2021-12-01 04:03:03 --> UTF-8 Support Enabled
INFO - 2021-12-01 04:03:03 --> Utf8 Class Initialized
INFO - 2021-12-01 04:03:03 --> URI Class Initialized
INFO - 2021-12-01 04:03:03 --> Router Class Initialized
INFO - 2021-12-01 04:03:03 --> Output Class Initialized
INFO - 2021-12-01 04:03:03 --> Security Class Initialized
DEBUG - 2021-12-01 04:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 04:03:03 --> Input Class Initialized
INFO - 2021-12-01 04:03:03 --> Language Class Initialized
INFO - 2021-12-01 04:03:03 --> Language Class Initialized
INFO - 2021-12-01 04:03:03 --> Config Class Initialized
INFO - 2021-12-01 04:03:03 --> Loader Class Initialized
INFO - 2021-12-01 04:03:03 --> Helper loaded: url_helper
INFO - 2021-12-01 04:03:03 --> Helper loaded: file_helper
INFO - 2021-12-01 04:03:03 --> Helper loaded: form_helper
INFO - 2021-12-01 04:03:03 --> Helper loaded: my_helper
INFO - 2021-12-01 04:03:03 --> Database Driver Class Initialized
DEBUG - 2021-12-01 04:03:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 04:03:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 04:03:03 --> Controller Class Initialized
DEBUG - 2021-12-01 04:03:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-01 04:03:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 04:03:03 --> Final output sent to browser
DEBUG - 2021-12-01 04:03:03 --> Total execution time: 0.1042
INFO - 2021-12-01 04:03:11 --> Config Class Initialized
INFO - 2021-12-01 04:03:11 --> Hooks Class Initialized
DEBUG - 2021-12-01 04:03:11 --> UTF-8 Support Enabled
INFO - 2021-12-01 04:03:11 --> Utf8 Class Initialized
INFO - 2021-12-01 04:03:11 --> URI Class Initialized
INFO - 2021-12-01 04:03:11 --> Router Class Initialized
INFO - 2021-12-01 04:03:11 --> Output Class Initialized
INFO - 2021-12-01 04:03:11 --> Security Class Initialized
DEBUG - 2021-12-01 04:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 04:03:11 --> Input Class Initialized
INFO - 2021-12-01 04:03:11 --> Language Class Initialized
INFO - 2021-12-01 04:03:11 --> Language Class Initialized
INFO - 2021-12-01 04:03:11 --> Config Class Initialized
INFO - 2021-12-01 04:03:11 --> Loader Class Initialized
INFO - 2021-12-01 04:03:11 --> Helper loaded: url_helper
INFO - 2021-12-01 04:03:11 --> Helper loaded: file_helper
INFO - 2021-12-01 04:03:11 --> Helper loaded: form_helper
INFO - 2021-12-01 04:03:11 --> Helper loaded: my_helper
INFO - 2021-12-01 04:03:11 --> Database Driver Class Initialized
DEBUG - 2021-12-01 04:03:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 04:03:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 04:03:11 --> Controller Class Initialized
DEBUG - 2021-12-01 04:03:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-01 04:03:11 --> Final output sent to browser
DEBUG - 2021-12-01 04:03:11 --> Total execution time: 0.2639
INFO - 2021-12-01 04:03:40 --> Config Class Initialized
INFO - 2021-12-01 04:03:40 --> Hooks Class Initialized
DEBUG - 2021-12-01 04:03:40 --> UTF-8 Support Enabled
INFO - 2021-12-01 04:03:40 --> Utf8 Class Initialized
INFO - 2021-12-01 04:03:40 --> URI Class Initialized
INFO - 2021-12-01 04:03:40 --> Router Class Initialized
INFO - 2021-12-01 04:03:40 --> Output Class Initialized
INFO - 2021-12-01 04:03:40 --> Security Class Initialized
DEBUG - 2021-12-01 04:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 04:03:40 --> Input Class Initialized
INFO - 2021-12-01 04:03:40 --> Language Class Initialized
INFO - 2021-12-01 04:03:40 --> Language Class Initialized
INFO - 2021-12-01 04:03:40 --> Config Class Initialized
INFO - 2021-12-01 04:03:40 --> Loader Class Initialized
INFO - 2021-12-01 04:03:40 --> Helper loaded: url_helper
INFO - 2021-12-01 04:03:40 --> Helper loaded: file_helper
INFO - 2021-12-01 04:03:40 --> Helper loaded: form_helper
INFO - 2021-12-01 04:03:40 --> Helper loaded: my_helper
INFO - 2021-12-01 04:03:40 --> Database Driver Class Initialized
DEBUG - 2021-12-01 04:03:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 04:03:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 04:03:40 --> Controller Class Initialized
INFO - 2021-12-01 04:03:40 --> Helper loaded: cookie_helper
INFO - 2021-12-01 04:03:40 --> Config Class Initialized
INFO - 2021-12-01 04:03:40 --> Hooks Class Initialized
DEBUG - 2021-12-01 04:03:40 --> UTF-8 Support Enabled
INFO - 2021-12-01 04:03:40 --> Utf8 Class Initialized
INFO - 2021-12-01 04:03:40 --> URI Class Initialized
INFO - 2021-12-01 04:03:40 --> Router Class Initialized
INFO - 2021-12-01 04:03:40 --> Output Class Initialized
INFO - 2021-12-01 04:03:40 --> Security Class Initialized
DEBUG - 2021-12-01 04:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 04:03:40 --> Input Class Initialized
INFO - 2021-12-01 04:03:40 --> Language Class Initialized
INFO - 2021-12-01 04:03:40 --> Language Class Initialized
INFO - 2021-12-01 04:03:40 --> Config Class Initialized
INFO - 2021-12-01 04:03:40 --> Loader Class Initialized
INFO - 2021-12-01 04:03:40 --> Helper loaded: url_helper
INFO - 2021-12-01 04:03:40 --> Helper loaded: file_helper
INFO - 2021-12-01 04:03:40 --> Helper loaded: form_helper
INFO - 2021-12-01 04:03:40 --> Helper loaded: my_helper
INFO - 2021-12-01 04:03:40 --> Database Driver Class Initialized
DEBUG - 2021-12-01 04:03:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 04:03:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 04:03:40 --> Controller Class Initialized
DEBUG - 2021-12-01 04:03:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-01 04:03:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-01 04:03:40 --> Final output sent to browser
DEBUG - 2021-12-01 04:03:40 --> Total execution time: 0.0532
