<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-03-26 01:46:51 --> Config Class Initialized
INFO - 2021-03-26 01:46:51 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:46:51 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:46:51 --> Utf8 Class Initialized
INFO - 2021-03-26 01:46:51 --> URI Class Initialized
INFO - 2021-03-26 01:46:52 --> Router Class Initialized
INFO - 2021-03-26 01:46:52 --> Output Class Initialized
INFO - 2021-03-26 01:46:52 --> Security Class Initialized
DEBUG - 2021-03-26 01:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:46:52 --> Input Class Initialized
INFO - 2021-03-26 01:46:52 --> Language Class Initialized
INFO - 2021-03-26 01:46:52 --> Language Class Initialized
INFO - 2021-03-26 01:46:52 --> Config Class Initialized
INFO - 2021-03-26 01:46:52 --> Loader Class Initialized
INFO - 2021-03-26 01:46:52 --> Helper loaded: url_helper
INFO - 2021-03-26 01:46:52 --> Helper loaded: file_helper
INFO - 2021-03-26 01:46:52 --> Helper loaded: form_helper
INFO - 2021-03-26 01:46:52 --> Helper loaded: my_helper
INFO - 2021-03-26 01:46:53 --> Database Driver Class Initialized
DEBUG - 2021-03-26 01:46:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 01:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 01:46:53 --> Controller Class Initialized
INFO - 2021-03-26 01:46:53 --> Config Class Initialized
INFO - 2021-03-26 01:46:53 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:46:53 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:46:53 --> Utf8 Class Initialized
INFO - 2021-03-26 01:46:53 --> URI Class Initialized
INFO - 2021-03-26 01:46:53 --> Router Class Initialized
INFO - 2021-03-26 01:46:53 --> Output Class Initialized
INFO - 2021-03-26 01:46:53 --> Security Class Initialized
DEBUG - 2021-03-26 01:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:46:53 --> Input Class Initialized
INFO - 2021-03-26 01:46:53 --> Language Class Initialized
INFO - 2021-03-26 01:46:53 --> Language Class Initialized
INFO - 2021-03-26 01:46:54 --> Config Class Initialized
INFO - 2021-03-26 01:46:54 --> Loader Class Initialized
INFO - 2021-03-26 01:46:54 --> Helper loaded: url_helper
INFO - 2021-03-26 01:46:54 --> Helper loaded: file_helper
INFO - 2021-03-26 01:46:54 --> Helper loaded: form_helper
INFO - 2021-03-26 01:46:54 --> Helper loaded: my_helper
INFO - 2021-03-26 01:46:54 --> Database Driver Class Initialized
DEBUG - 2021-03-26 01:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 01:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 01:46:54 --> Controller Class Initialized
DEBUG - 2021-03-26 01:46:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-03-26 01:46:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-03-26 01:46:54 --> Final output sent to browser
DEBUG - 2021-03-26 01:46:54 --> Total execution time: 0.9200
INFO - 2021-03-26 01:47:14 --> Config Class Initialized
INFO - 2021-03-26 01:47:14 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:47:14 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:47:14 --> Utf8 Class Initialized
INFO - 2021-03-26 01:47:14 --> URI Class Initialized
INFO - 2021-03-26 01:47:14 --> Router Class Initialized
INFO - 2021-03-26 01:47:14 --> Output Class Initialized
INFO - 2021-03-26 01:47:14 --> Security Class Initialized
DEBUG - 2021-03-26 01:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:47:14 --> Input Class Initialized
INFO - 2021-03-26 01:47:14 --> Language Class Initialized
INFO - 2021-03-26 01:47:14 --> Language Class Initialized
INFO - 2021-03-26 01:47:14 --> Config Class Initialized
INFO - 2021-03-26 01:47:14 --> Loader Class Initialized
INFO - 2021-03-26 01:47:15 --> Helper loaded: url_helper
INFO - 2021-03-26 01:47:15 --> Helper loaded: file_helper
INFO - 2021-03-26 01:47:15 --> Helper loaded: form_helper
INFO - 2021-03-26 01:47:15 --> Helper loaded: my_helper
INFO - 2021-03-26 01:47:15 --> Database Driver Class Initialized
DEBUG - 2021-03-26 01:47:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 01:47:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 01:47:15 --> Controller Class Initialized
INFO - 2021-03-26 01:47:15 --> Helper loaded: cookie_helper
INFO - 2021-03-26 01:47:15 --> Final output sent to browser
DEBUG - 2021-03-26 01:47:15 --> Total execution time: 0.8570
INFO - 2021-03-26 01:47:16 --> Config Class Initialized
INFO - 2021-03-26 01:47:16 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:47:16 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:47:16 --> Utf8 Class Initialized
INFO - 2021-03-26 01:47:16 --> URI Class Initialized
INFO - 2021-03-26 01:47:16 --> Router Class Initialized
INFO - 2021-03-26 01:47:16 --> Output Class Initialized
INFO - 2021-03-26 01:47:16 --> Security Class Initialized
DEBUG - 2021-03-26 01:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:47:16 --> Input Class Initialized
INFO - 2021-03-26 01:47:16 --> Language Class Initialized
INFO - 2021-03-26 01:47:16 --> Language Class Initialized
INFO - 2021-03-26 01:47:16 --> Config Class Initialized
INFO - 2021-03-26 01:47:16 --> Loader Class Initialized
INFO - 2021-03-26 01:47:16 --> Helper loaded: url_helper
INFO - 2021-03-26 01:47:16 --> Helper loaded: file_helper
INFO - 2021-03-26 01:47:16 --> Helper loaded: form_helper
INFO - 2021-03-26 01:47:16 --> Helper loaded: my_helper
INFO - 2021-03-26 01:47:16 --> Database Driver Class Initialized
DEBUG - 2021-03-26 01:47:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 01:47:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 01:47:16 --> Controller Class Initialized
DEBUG - 2021-03-26 01:47:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-03-26 01:47:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-03-26 01:47:16 --> Final output sent to browser
DEBUG - 2021-03-26 01:47:16 --> Total execution time: 0.8311
INFO - 2021-03-26 01:47:18 --> Config Class Initialized
INFO - 2021-03-26 01:47:18 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:47:18 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:47:18 --> Utf8 Class Initialized
INFO - 2021-03-26 01:47:18 --> URI Class Initialized
INFO - 2021-03-26 01:47:18 --> Router Class Initialized
INFO - 2021-03-26 01:47:18 --> Output Class Initialized
INFO - 2021-03-26 01:47:18 --> Security Class Initialized
DEBUG - 2021-03-26 01:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:47:18 --> Input Class Initialized
INFO - 2021-03-26 01:47:18 --> Language Class Initialized
INFO - 2021-03-26 01:47:18 --> Language Class Initialized
INFO - 2021-03-26 01:47:18 --> Config Class Initialized
INFO - 2021-03-26 01:47:18 --> Loader Class Initialized
INFO - 2021-03-26 01:47:18 --> Helper loaded: url_helper
INFO - 2021-03-26 01:47:18 --> Helper loaded: file_helper
INFO - 2021-03-26 01:47:18 --> Helper loaded: form_helper
INFO - 2021-03-26 01:47:18 --> Helper loaded: my_helper
INFO - 2021-03-26 01:47:18 --> Database Driver Class Initialized
DEBUG - 2021-03-26 01:47:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 01:47:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 01:47:18 --> Controller Class Initialized
DEBUG - 2021-03-26 01:47:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2021-03-26 01:47:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-03-26 01:47:19 --> Final output sent to browser
DEBUG - 2021-03-26 01:47:19 --> Total execution time: 0.8322
INFO - 2021-03-26 01:47:19 --> Config Class Initialized
INFO - 2021-03-26 01:47:19 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:47:19 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:47:19 --> Utf8 Class Initialized
INFO - 2021-03-26 01:47:19 --> URI Class Initialized
INFO - 2021-03-26 01:47:19 --> Router Class Initialized
INFO - 2021-03-26 01:47:19 --> Output Class Initialized
INFO - 2021-03-26 01:47:19 --> Security Class Initialized
DEBUG - 2021-03-26 01:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:47:19 --> Input Class Initialized
INFO - 2021-03-26 01:47:19 --> Language Class Initialized
INFO - 2021-03-26 01:47:19 --> Language Class Initialized
INFO - 2021-03-26 01:47:19 --> Config Class Initialized
INFO - 2021-03-26 01:47:19 --> Loader Class Initialized
INFO - 2021-03-26 01:47:19 --> Helper loaded: url_helper
INFO - 2021-03-26 01:47:19 --> Helper loaded: file_helper
INFO - 2021-03-26 01:47:20 --> Helper loaded: form_helper
INFO - 2021-03-26 01:47:20 --> Helper loaded: my_helper
INFO - 2021-03-26 01:47:20 --> Database Driver Class Initialized
DEBUG - 2021-03-26 01:47:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 01:47:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 01:47:20 --> Controller Class Initialized
INFO - 2021-03-26 01:47:21 --> Config Class Initialized
INFO - 2021-03-26 01:47:21 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:47:21 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:47:21 --> Utf8 Class Initialized
INFO - 2021-03-26 01:47:21 --> URI Class Initialized
INFO - 2021-03-26 01:47:21 --> Router Class Initialized
INFO - 2021-03-26 01:47:21 --> Output Class Initialized
INFO - 2021-03-26 01:47:21 --> Security Class Initialized
DEBUG - 2021-03-26 01:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:47:21 --> Input Class Initialized
INFO - 2021-03-26 01:47:21 --> Language Class Initialized
INFO - 2021-03-26 01:47:21 --> Language Class Initialized
INFO - 2021-03-26 01:47:21 --> Config Class Initialized
INFO - 2021-03-26 01:47:21 --> Loader Class Initialized
INFO - 2021-03-26 01:47:21 --> Helper loaded: url_helper
INFO - 2021-03-26 01:47:21 --> Helper loaded: file_helper
INFO - 2021-03-26 01:47:21 --> Helper loaded: form_helper
INFO - 2021-03-26 01:47:21 --> Helper loaded: my_helper
INFO - 2021-03-26 01:47:21 --> Database Driver Class Initialized
DEBUG - 2021-03-26 01:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 01:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 01:47:21 --> Controller Class Initialized
DEBUG - 2021-03-26 01:47:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2021-03-26 01:47:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-03-26 01:47:22 --> Final output sent to browser
DEBUG - 2021-03-26 01:47:22 --> Total execution time: 0.9785
INFO - 2021-03-26 01:47:22 --> Config Class Initialized
INFO - 2021-03-26 01:47:22 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:47:22 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:47:22 --> Utf8 Class Initialized
INFO - 2021-03-26 01:47:22 --> URI Class Initialized
INFO - 2021-03-26 01:47:22 --> Router Class Initialized
INFO - 2021-03-26 01:47:22 --> Output Class Initialized
INFO - 2021-03-26 01:47:22 --> Security Class Initialized
DEBUG - 2021-03-26 01:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:47:22 --> Input Class Initialized
INFO - 2021-03-26 01:47:22 --> Language Class Initialized
INFO - 2021-03-26 01:47:22 --> Language Class Initialized
INFO - 2021-03-26 01:47:22 --> Config Class Initialized
INFO - 2021-03-26 01:47:22 --> Loader Class Initialized
INFO - 2021-03-26 01:47:22 --> Helper loaded: url_helper
INFO - 2021-03-26 01:47:22 --> Helper loaded: file_helper
INFO - 2021-03-26 01:47:22 --> Helper loaded: form_helper
INFO - 2021-03-26 01:47:22 --> Helper loaded: my_helper
INFO - 2021-03-26 01:47:22 --> Database Driver Class Initialized
DEBUG - 2021-03-26 01:47:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 01:47:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 01:47:22 --> Controller Class Initialized
INFO - 2021-03-26 01:47:24 --> Config Class Initialized
INFO - 2021-03-26 01:47:24 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:47:24 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:47:24 --> Utf8 Class Initialized
INFO - 2021-03-26 01:47:24 --> URI Class Initialized
INFO - 2021-03-26 01:47:24 --> Router Class Initialized
INFO - 2021-03-26 01:47:24 --> Output Class Initialized
INFO - 2021-03-26 01:47:24 --> Security Class Initialized
DEBUG - 2021-03-26 01:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:47:24 --> Input Class Initialized
INFO - 2021-03-26 01:47:25 --> Language Class Initialized
INFO - 2021-03-26 01:47:25 --> Language Class Initialized
INFO - 2021-03-26 01:47:25 --> Config Class Initialized
INFO - 2021-03-26 01:47:25 --> Loader Class Initialized
INFO - 2021-03-26 01:47:25 --> Helper loaded: url_helper
INFO - 2021-03-26 01:47:25 --> Helper loaded: file_helper
INFO - 2021-03-26 01:47:25 --> Helper loaded: form_helper
INFO - 2021-03-26 01:47:25 --> Helper loaded: my_helper
INFO - 2021-03-26 01:47:25 --> Database Driver Class Initialized
DEBUG - 2021-03-26 01:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 01:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 01:47:25 --> Controller Class Initialized
DEBUG - 2021-03-26 01:47:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-03-26 01:47:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-03-26 01:47:25 --> Final output sent to browser
DEBUG - 2021-03-26 01:47:25 --> Total execution time: 0.8352
INFO - 2021-03-26 01:47:25 --> Config Class Initialized
INFO - 2021-03-26 01:47:25 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:47:25 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:47:26 --> Utf8 Class Initialized
INFO - 2021-03-26 01:47:26 --> URI Class Initialized
INFO - 2021-03-26 01:47:26 --> Router Class Initialized
INFO - 2021-03-26 01:47:26 --> Output Class Initialized
INFO - 2021-03-26 01:47:26 --> Security Class Initialized
DEBUG - 2021-03-26 01:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:47:26 --> Input Class Initialized
INFO - 2021-03-26 01:47:26 --> Language Class Initialized
INFO - 2021-03-26 01:47:26 --> Language Class Initialized
INFO - 2021-03-26 01:47:26 --> Config Class Initialized
INFO - 2021-03-26 01:47:26 --> Loader Class Initialized
INFO - 2021-03-26 01:47:26 --> Helper loaded: url_helper
INFO - 2021-03-26 01:47:26 --> Helper loaded: file_helper
INFO - 2021-03-26 01:47:26 --> Helper loaded: form_helper
INFO - 2021-03-26 01:47:26 --> Helper loaded: my_helper
INFO - 2021-03-26 01:47:26 --> Database Driver Class Initialized
DEBUG - 2021-03-26 01:47:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 01:47:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 01:47:26 --> Controller Class Initialized
INFO - 2021-03-26 01:47:27 --> Config Class Initialized
INFO - 2021-03-26 01:47:27 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:47:27 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:47:27 --> Utf8 Class Initialized
INFO - 2021-03-26 01:47:27 --> URI Class Initialized
INFO - 2021-03-26 01:47:27 --> Router Class Initialized
INFO - 2021-03-26 01:47:27 --> Output Class Initialized
INFO - 2021-03-26 01:47:27 --> Security Class Initialized
DEBUG - 2021-03-26 01:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:47:27 --> Input Class Initialized
INFO - 2021-03-26 01:47:27 --> Language Class Initialized
INFO - 2021-03-26 01:47:28 --> Language Class Initialized
INFO - 2021-03-26 01:47:28 --> Config Class Initialized
INFO - 2021-03-26 01:47:28 --> Loader Class Initialized
INFO - 2021-03-26 01:47:28 --> Helper loaded: url_helper
INFO - 2021-03-26 01:47:28 --> Helper loaded: file_helper
INFO - 2021-03-26 01:47:28 --> Helper loaded: form_helper
INFO - 2021-03-26 01:47:28 --> Helper loaded: my_helper
INFO - 2021-03-26 01:47:28 --> Database Driver Class Initialized
DEBUG - 2021-03-26 01:47:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 01:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 01:47:28 --> Controller Class Initialized
DEBUG - 2021-03-26 01:47:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2021-03-26 01:47:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-03-26 01:47:28 --> Final output sent to browser
DEBUG - 2021-03-26 01:47:28 --> Total execution time: 0.9620
INFO - 2021-03-26 01:47:28 --> Config Class Initialized
INFO - 2021-03-26 01:47:29 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:47:29 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:47:29 --> Utf8 Class Initialized
INFO - 2021-03-26 01:47:29 --> URI Class Initialized
INFO - 2021-03-26 01:47:29 --> Router Class Initialized
INFO - 2021-03-26 01:47:29 --> Output Class Initialized
INFO - 2021-03-26 01:47:29 --> Security Class Initialized
DEBUG - 2021-03-26 01:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:47:29 --> Input Class Initialized
INFO - 2021-03-26 01:47:29 --> Language Class Initialized
INFO - 2021-03-26 01:47:29 --> Language Class Initialized
INFO - 2021-03-26 01:47:29 --> Config Class Initialized
INFO - 2021-03-26 01:47:29 --> Loader Class Initialized
INFO - 2021-03-26 01:47:29 --> Helper loaded: url_helper
INFO - 2021-03-26 01:47:29 --> Helper loaded: file_helper
INFO - 2021-03-26 01:47:29 --> Helper loaded: form_helper
INFO - 2021-03-26 01:47:29 --> Helper loaded: my_helper
INFO - 2021-03-26 01:47:29 --> Database Driver Class Initialized
DEBUG - 2021-03-26 01:47:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 01:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 01:47:29 --> Controller Class Initialized
INFO - 2021-03-26 01:47:31 --> Config Class Initialized
INFO - 2021-03-26 01:47:31 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:47:32 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:47:32 --> Utf8 Class Initialized
INFO - 2021-03-26 01:47:32 --> URI Class Initialized
INFO - 2021-03-26 01:47:32 --> Router Class Initialized
INFO - 2021-03-26 01:47:32 --> Output Class Initialized
INFO - 2021-03-26 01:47:32 --> Security Class Initialized
DEBUG - 2021-03-26 01:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:47:32 --> Input Class Initialized
INFO - 2021-03-26 01:47:32 --> Language Class Initialized
INFO - 2021-03-26 01:47:32 --> Language Class Initialized
INFO - 2021-03-26 01:47:32 --> Config Class Initialized
INFO - 2021-03-26 01:47:32 --> Loader Class Initialized
INFO - 2021-03-26 01:47:32 --> Helper loaded: url_helper
INFO - 2021-03-26 01:47:32 --> Helper loaded: file_helper
INFO - 2021-03-26 01:47:32 --> Helper loaded: form_helper
INFO - 2021-03-26 01:47:32 --> Helper loaded: my_helper
INFO - 2021-03-26 01:47:32 --> Database Driver Class Initialized
DEBUG - 2021-03-26 01:47:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 01:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 01:47:32 --> Controller Class Initialized
INFO - 2021-03-26 01:47:32 --> Final output sent to browser
DEBUG - 2021-03-26 01:47:32 --> Total execution time: 0.5918
INFO - 2021-03-26 01:54:02 --> Config Class Initialized
INFO - 2021-03-26 01:54:02 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:54:02 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:54:02 --> Utf8 Class Initialized
INFO - 2021-03-26 01:54:02 --> URI Class Initialized
INFO - 2021-03-26 01:54:02 --> Router Class Initialized
INFO - 2021-03-26 01:54:02 --> Output Class Initialized
INFO - 2021-03-26 01:54:02 --> Security Class Initialized
DEBUG - 2021-03-26 01:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:54:02 --> Input Class Initialized
INFO - 2021-03-26 01:54:02 --> Language Class Initialized
INFO - 2021-03-26 01:54:02 --> Language Class Initialized
INFO - 2021-03-26 01:54:02 --> Config Class Initialized
INFO - 2021-03-26 01:54:02 --> Loader Class Initialized
INFO - 2021-03-26 01:54:02 --> Helper loaded: url_helper
INFO - 2021-03-26 01:54:02 --> Helper loaded: file_helper
INFO - 2021-03-26 01:54:02 --> Helper loaded: form_helper
INFO - 2021-03-26 01:54:02 --> Helper loaded: my_helper
INFO - 2021-03-26 01:54:03 --> Database Driver Class Initialized
DEBUG - 2021-03-26 01:54:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 01:54:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 01:54:03 --> Controller Class Initialized
DEBUG - 2021-03-26 01:54:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2021-03-26 01:54:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-03-26 01:54:03 --> Final output sent to browser
DEBUG - 2021-03-26 01:54:03 --> Total execution time: 0.7235
INFO - 2021-03-26 01:54:03 --> Config Class Initialized
INFO - 2021-03-26 01:54:03 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:54:03 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:54:03 --> Utf8 Class Initialized
INFO - 2021-03-26 01:54:03 --> URI Class Initialized
INFO - 2021-03-26 01:54:03 --> Router Class Initialized
INFO - 2021-03-26 01:54:03 --> Output Class Initialized
INFO - 2021-03-26 01:54:03 --> Security Class Initialized
DEBUG - 2021-03-26 01:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:54:03 --> Input Class Initialized
INFO - 2021-03-26 01:54:03 --> Language Class Initialized
INFO - 2021-03-26 01:54:03 --> Language Class Initialized
INFO - 2021-03-26 01:54:03 --> Config Class Initialized
INFO - 2021-03-26 01:54:03 --> Loader Class Initialized
INFO - 2021-03-26 01:54:03 --> Helper loaded: url_helper
INFO - 2021-03-26 01:54:03 --> Helper loaded: file_helper
INFO - 2021-03-26 01:54:03 --> Helper loaded: form_helper
INFO - 2021-03-26 01:54:03 --> Helper loaded: my_helper
INFO - 2021-03-26 01:54:04 --> Database Driver Class Initialized
DEBUG - 2021-03-26 01:54:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 01:54:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 01:54:04 --> Controller Class Initialized
INFO - 2021-03-26 01:54:04 --> Config Class Initialized
INFO - 2021-03-26 01:54:04 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:54:04 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:54:04 --> Utf8 Class Initialized
INFO - 2021-03-26 01:54:04 --> URI Class Initialized
INFO - 2021-03-26 01:54:04 --> Router Class Initialized
INFO - 2021-03-26 01:54:04 --> Output Class Initialized
INFO - 2021-03-26 01:54:04 --> Security Class Initialized
DEBUG - 2021-03-26 01:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:54:04 --> Input Class Initialized
INFO - 2021-03-26 01:54:04 --> Language Class Initialized
INFO - 2021-03-26 01:54:04 --> Language Class Initialized
INFO - 2021-03-26 01:54:04 --> Config Class Initialized
INFO - 2021-03-26 01:54:04 --> Loader Class Initialized
INFO - 2021-03-26 01:54:04 --> Helper loaded: url_helper
INFO - 2021-03-26 01:54:04 --> Helper loaded: file_helper
INFO - 2021-03-26 01:54:04 --> Helper loaded: form_helper
INFO - 2021-03-26 01:54:04 --> Helper loaded: my_helper
INFO - 2021-03-26 01:54:04 --> Database Driver Class Initialized
DEBUG - 2021-03-26 01:54:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 01:54:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 01:54:04 --> Controller Class Initialized
INFO - 2021-03-26 01:54:04 --> Final output sent to browser
DEBUG - 2021-03-26 01:54:04 --> Total execution time: 0.4866
INFO - 2021-03-26 01:54:19 --> Config Class Initialized
INFO - 2021-03-26 01:54:19 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:54:19 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:54:19 --> Utf8 Class Initialized
INFO - 2021-03-26 01:54:19 --> URI Class Initialized
INFO - 2021-03-26 01:54:19 --> Router Class Initialized
INFO - 2021-03-26 01:54:19 --> Output Class Initialized
INFO - 2021-03-26 01:54:19 --> Security Class Initialized
DEBUG - 2021-03-26 01:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:54:19 --> Input Class Initialized
INFO - 2021-03-26 01:54:19 --> Language Class Initialized
INFO - 2021-03-26 01:54:19 --> Language Class Initialized
INFO - 2021-03-26 01:54:19 --> Config Class Initialized
INFO - 2021-03-26 01:54:19 --> Loader Class Initialized
INFO - 2021-03-26 01:54:19 --> Helper loaded: url_helper
INFO - 2021-03-26 01:54:19 --> Helper loaded: file_helper
INFO - 2021-03-26 01:54:19 --> Helper loaded: form_helper
INFO - 2021-03-26 01:54:19 --> Helper loaded: my_helper
INFO - 2021-03-26 01:54:19 --> Database Driver Class Initialized
DEBUG - 2021-03-26 01:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 01:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 01:54:19 --> Controller Class Initialized
INFO - 2021-03-26 01:54:19 --> Final output sent to browser
DEBUG - 2021-03-26 01:54:19 --> Total execution time: 0.7125
INFO - 2021-03-26 01:54:20 --> Config Class Initialized
INFO - 2021-03-26 01:54:20 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:54:20 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:54:20 --> Utf8 Class Initialized
INFO - 2021-03-26 01:54:20 --> URI Class Initialized
INFO - 2021-03-26 01:54:20 --> Router Class Initialized
INFO - 2021-03-26 01:54:20 --> Output Class Initialized
INFO - 2021-03-26 01:54:20 --> Security Class Initialized
DEBUG - 2021-03-26 01:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:54:20 --> Input Class Initialized
INFO - 2021-03-26 01:54:20 --> Language Class Initialized
INFO - 2021-03-26 01:54:20 --> Language Class Initialized
INFO - 2021-03-26 01:54:20 --> Config Class Initialized
INFO - 2021-03-26 01:54:20 --> Loader Class Initialized
INFO - 2021-03-26 01:54:20 --> Helper loaded: url_helper
INFO - 2021-03-26 01:54:20 --> Helper loaded: file_helper
INFO - 2021-03-26 01:54:20 --> Helper loaded: form_helper
INFO - 2021-03-26 01:54:20 --> Helper loaded: my_helper
INFO - 2021-03-26 01:54:20 --> Database Driver Class Initialized
DEBUG - 2021-03-26 01:54:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 01:54:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 01:54:21 --> Controller Class Initialized
INFO - 2021-03-26 01:54:24 --> Config Class Initialized
INFO - 2021-03-26 01:54:24 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:54:24 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:54:24 --> Utf8 Class Initialized
INFO - 2021-03-26 01:54:24 --> URI Class Initialized
INFO - 2021-03-26 01:54:24 --> Router Class Initialized
INFO - 2021-03-26 01:54:24 --> Output Class Initialized
INFO - 2021-03-26 01:54:24 --> Security Class Initialized
DEBUG - 2021-03-26 01:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:54:24 --> Input Class Initialized
INFO - 2021-03-26 01:54:24 --> Language Class Initialized
INFO - 2021-03-26 01:54:24 --> Language Class Initialized
INFO - 2021-03-26 01:54:24 --> Config Class Initialized
INFO - 2021-03-26 01:54:24 --> Loader Class Initialized
INFO - 2021-03-26 01:54:24 --> Helper loaded: url_helper
INFO - 2021-03-26 01:54:24 --> Helper loaded: file_helper
INFO - 2021-03-26 01:54:24 --> Helper loaded: form_helper
INFO - 2021-03-26 01:54:24 --> Helper loaded: my_helper
INFO - 2021-03-26 01:54:24 --> Database Driver Class Initialized
DEBUG - 2021-03-26 01:54:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 01:54:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 01:54:24 --> Controller Class Initialized
INFO - 2021-03-26 01:54:24 --> Final output sent to browser
DEBUG - 2021-03-26 01:54:24 --> Total execution time: 0.7278
INFO - 2021-03-26 01:54:33 --> Config Class Initialized
INFO - 2021-03-26 01:54:33 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:54:33 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:54:33 --> Utf8 Class Initialized
INFO - 2021-03-26 01:54:33 --> URI Class Initialized
INFO - 2021-03-26 01:54:33 --> Router Class Initialized
INFO - 2021-03-26 01:54:33 --> Output Class Initialized
INFO - 2021-03-26 01:54:33 --> Security Class Initialized
DEBUG - 2021-03-26 01:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:54:33 --> Input Class Initialized
INFO - 2021-03-26 01:54:33 --> Language Class Initialized
INFO - 2021-03-26 01:54:33 --> Language Class Initialized
INFO - 2021-03-26 01:54:33 --> Config Class Initialized
INFO - 2021-03-26 01:54:33 --> Loader Class Initialized
INFO - 2021-03-26 01:54:33 --> Helper loaded: url_helper
INFO - 2021-03-26 01:54:33 --> Helper loaded: file_helper
INFO - 2021-03-26 01:54:33 --> Helper loaded: form_helper
INFO - 2021-03-26 01:54:33 --> Helper loaded: my_helper
INFO - 2021-03-26 01:54:33 --> Database Driver Class Initialized
DEBUG - 2021-03-26 01:54:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 01:54:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 01:54:33 --> Controller Class Initialized
INFO - 2021-03-26 01:54:33 --> Final output sent to browser
DEBUG - 2021-03-26 01:54:33 --> Total execution time: 0.5093
INFO - 2021-03-26 01:54:33 --> Config Class Initialized
INFO - 2021-03-26 01:54:34 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:54:34 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:54:34 --> Utf8 Class Initialized
INFO - 2021-03-26 01:54:34 --> URI Class Initialized
INFO - 2021-03-26 01:54:34 --> Router Class Initialized
INFO - 2021-03-26 01:54:34 --> Output Class Initialized
INFO - 2021-03-26 01:54:34 --> Security Class Initialized
DEBUG - 2021-03-26 01:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:54:34 --> Input Class Initialized
INFO - 2021-03-26 01:54:34 --> Language Class Initialized
INFO - 2021-03-26 01:54:34 --> Language Class Initialized
INFO - 2021-03-26 01:54:34 --> Config Class Initialized
INFO - 2021-03-26 01:54:34 --> Loader Class Initialized
INFO - 2021-03-26 01:54:34 --> Helper loaded: url_helper
INFO - 2021-03-26 01:54:34 --> Helper loaded: file_helper
INFO - 2021-03-26 01:54:34 --> Helper loaded: form_helper
INFO - 2021-03-26 01:54:34 --> Helper loaded: my_helper
INFO - 2021-03-26 01:54:34 --> Database Driver Class Initialized
DEBUG - 2021-03-26 01:54:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 01:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 01:54:34 --> Controller Class Initialized
INFO - 2021-03-26 02:02:44 --> Config Class Initialized
INFO - 2021-03-26 02:02:45 --> Hooks Class Initialized
DEBUG - 2021-03-26 02:02:45 --> UTF-8 Support Enabled
INFO - 2021-03-26 02:02:45 --> Utf8 Class Initialized
INFO - 2021-03-26 02:02:45 --> URI Class Initialized
INFO - 2021-03-26 02:02:45 --> Router Class Initialized
INFO - 2021-03-26 02:02:45 --> Output Class Initialized
INFO - 2021-03-26 02:02:45 --> Security Class Initialized
DEBUG - 2021-03-26 02:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 02:02:45 --> Input Class Initialized
INFO - 2021-03-26 02:02:45 --> Language Class Initialized
INFO - 2021-03-26 02:02:45 --> Language Class Initialized
INFO - 2021-03-26 02:02:45 --> Config Class Initialized
INFO - 2021-03-26 02:02:45 --> Loader Class Initialized
INFO - 2021-03-26 02:02:45 --> Helper loaded: url_helper
INFO - 2021-03-26 02:02:45 --> Helper loaded: file_helper
INFO - 2021-03-26 02:02:45 --> Helper loaded: form_helper
INFO - 2021-03-26 02:02:45 --> Helper loaded: my_helper
INFO - 2021-03-26 02:02:45 --> Database Driver Class Initialized
DEBUG - 2021-03-26 02:02:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 02:02:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 02:02:45 --> Controller Class Initialized
INFO - 2021-03-26 02:02:45 --> Final output sent to browser
DEBUG - 2021-03-26 02:02:45 --> Total execution time: 0.6563
INFO - 2021-03-26 02:02:57 --> Config Class Initialized
INFO - 2021-03-26 02:02:57 --> Hooks Class Initialized
DEBUG - 2021-03-26 02:02:57 --> UTF-8 Support Enabled
INFO - 2021-03-26 02:02:57 --> Utf8 Class Initialized
INFO - 2021-03-26 02:02:57 --> URI Class Initialized
INFO - 2021-03-26 02:02:57 --> Router Class Initialized
INFO - 2021-03-26 02:02:57 --> Output Class Initialized
INFO - 2021-03-26 02:02:57 --> Security Class Initialized
DEBUG - 2021-03-26 02:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 02:02:57 --> Input Class Initialized
INFO - 2021-03-26 02:02:57 --> Language Class Initialized
INFO - 2021-03-26 02:02:57 --> Language Class Initialized
INFO - 2021-03-26 02:02:57 --> Config Class Initialized
INFO - 2021-03-26 02:02:57 --> Loader Class Initialized
INFO - 2021-03-26 02:02:57 --> Helper loaded: url_helper
INFO - 2021-03-26 02:02:57 --> Helper loaded: file_helper
INFO - 2021-03-26 02:02:57 --> Helper loaded: form_helper
INFO - 2021-03-26 02:02:57 --> Helper loaded: my_helper
INFO - 2021-03-26 02:02:57 --> Database Driver Class Initialized
DEBUG - 2021-03-26 02:02:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 02:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 02:02:57 --> Controller Class Initialized
INFO - 2021-03-26 02:02:57 --> Final output sent to browser
DEBUG - 2021-03-26 02:02:57 --> Total execution time: 0.6651
INFO - 2021-03-26 02:04:24 --> Config Class Initialized
INFO - 2021-03-26 02:04:24 --> Hooks Class Initialized
DEBUG - 2021-03-26 02:04:24 --> UTF-8 Support Enabled
INFO - 2021-03-26 02:04:24 --> Utf8 Class Initialized
INFO - 2021-03-26 02:04:24 --> URI Class Initialized
INFO - 2021-03-26 02:04:24 --> Router Class Initialized
INFO - 2021-03-26 02:04:24 --> Output Class Initialized
INFO - 2021-03-26 02:04:24 --> Security Class Initialized
DEBUG - 2021-03-26 02:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 02:04:24 --> Input Class Initialized
INFO - 2021-03-26 02:04:24 --> Language Class Initialized
INFO - 2021-03-26 02:04:24 --> Language Class Initialized
INFO - 2021-03-26 02:04:24 --> Config Class Initialized
INFO - 2021-03-26 02:04:24 --> Loader Class Initialized
INFO - 2021-03-26 02:04:24 --> Helper loaded: url_helper
INFO - 2021-03-26 02:04:24 --> Helper loaded: file_helper
INFO - 2021-03-26 02:04:24 --> Helper loaded: form_helper
INFO - 2021-03-26 02:04:24 --> Helper loaded: my_helper
INFO - 2021-03-26 02:04:25 --> Database Driver Class Initialized
DEBUG - 2021-03-26 02:04:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 02:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 02:04:25 --> Controller Class Initialized
INFO - 2021-03-26 02:04:25 --> Final output sent to browser
DEBUG - 2021-03-26 02:04:25 --> Total execution time: 0.6658
INFO - 2021-03-26 02:04:29 --> Config Class Initialized
INFO - 2021-03-26 02:04:29 --> Hooks Class Initialized
DEBUG - 2021-03-26 02:04:29 --> UTF-8 Support Enabled
INFO - 2021-03-26 02:04:29 --> Utf8 Class Initialized
INFO - 2021-03-26 02:04:29 --> URI Class Initialized
INFO - 2021-03-26 02:04:29 --> Router Class Initialized
INFO - 2021-03-26 02:04:29 --> Output Class Initialized
INFO - 2021-03-26 02:04:29 --> Security Class Initialized
DEBUG - 2021-03-26 02:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 02:04:29 --> Input Class Initialized
INFO - 2021-03-26 02:04:29 --> Language Class Initialized
INFO - 2021-03-26 02:04:30 --> Language Class Initialized
INFO - 2021-03-26 02:04:30 --> Config Class Initialized
INFO - 2021-03-26 02:04:30 --> Loader Class Initialized
INFO - 2021-03-26 02:04:30 --> Helper loaded: url_helper
INFO - 2021-03-26 02:04:30 --> Helper loaded: file_helper
INFO - 2021-03-26 02:04:30 --> Helper loaded: form_helper
INFO - 2021-03-26 02:04:30 --> Helper loaded: my_helper
INFO - 2021-03-26 02:04:30 --> Database Driver Class Initialized
DEBUG - 2021-03-26 02:04:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 02:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 02:04:30 --> Controller Class Initialized
INFO - 2021-03-26 02:04:30 --> Final output sent to browser
DEBUG - 2021-03-26 02:04:30 --> Total execution time: 0.6869
INFO - 2021-03-26 02:04:30 --> Config Class Initialized
INFO - 2021-03-26 02:04:30 --> Hooks Class Initialized
DEBUG - 2021-03-26 02:04:30 --> UTF-8 Support Enabled
INFO - 2021-03-26 02:04:30 --> Utf8 Class Initialized
INFO - 2021-03-26 02:04:30 --> URI Class Initialized
INFO - 2021-03-26 02:04:30 --> Router Class Initialized
INFO - 2021-03-26 02:04:30 --> Output Class Initialized
INFO - 2021-03-26 02:04:30 --> Security Class Initialized
DEBUG - 2021-03-26 02:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 02:04:30 --> Input Class Initialized
INFO - 2021-03-26 02:04:30 --> Language Class Initialized
INFO - 2021-03-26 02:04:31 --> Language Class Initialized
INFO - 2021-03-26 02:04:31 --> Config Class Initialized
INFO - 2021-03-26 02:04:31 --> Loader Class Initialized
INFO - 2021-03-26 02:04:31 --> Helper loaded: url_helper
INFO - 2021-03-26 02:04:31 --> Helper loaded: file_helper
INFO - 2021-03-26 02:04:31 --> Helper loaded: form_helper
INFO - 2021-03-26 02:04:31 --> Helper loaded: my_helper
INFO - 2021-03-26 02:04:31 --> Database Driver Class Initialized
DEBUG - 2021-03-26 02:04:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 02:04:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 02:04:31 --> Controller Class Initialized
INFO - 2021-03-26 02:04:48 --> Config Class Initialized
INFO - 2021-03-26 02:04:48 --> Hooks Class Initialized
DEBUG - 2021-03-26 02:04:48 --> UTF-8 Support Enabled
INFO - 2021-03-26 02:04:48 --> Utf8 Class Initialized
INFO - 2021-03-26 02:04:48 --> URI Class Initialized
INFO - 2021-03-26 02:04:48 --> Router Class Initialized
INFO - 2021-03-26 02:04:48 --> Output Class Initialized
INFO - 2021-03-26 02:04:48 --> Security Class Initialized
DEBUG - 2021-03-26 02:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 02:04:48 --> Input Class Initialized
INFO - 2021-03-26 02:04:49 --> Language Class Initialized
INFO - 2021-03-26 02:04:49 --> Language Class Initialized
INFO - 2021-03-26 02:04:49 --> Config Class Initialized
INFO - 2021-03-26 02:04:49 --> Loader Class Initialized
INFO - 2021-03-26 02:04:49 --> Helper loaded: url_helper
INFO - 2021-03-26 02:04:49 --> Helper loaded: file_helper
INFO - 2021-03-26 02:04:49 --> Helper loaded: form_helper
INFO - 2021-03-26 02:04:49 --> Helper loaded: my_helper
INFO - 2021-03-26 02:04:49 --> Database Driver Class Initialized
DEBUG - 2021-03-26 02:04:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 02:04:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 02:04:49 --> Controller Class Initialized
INFO - 2021-03-26 02:04:49 --> Final output sent to browser
DEBUG - 2021-03-26 02:04:49 --> Total execution time: 0.7436
INFO - 2021-03-26 02:08:55 --> Config Class Initialized
INFO - 2021-03-26 02:08:55 --> Hooks Class Initialized
DEBUG - 2021-03-26 02:08:55 --> UTF-8 Support Enabled
INFO - 2021-03-26 02:08:55 --> Utf8 Class Initialized
INFO - 2021-03-26 02:08:55 --> URI Class Initialized
INFO - 2021-03-26 02:08:55 --> Router Class Initialized
INFO - 2021-03-26 02:08:55 --> Output Class Initialized
INFO - 2021-03-26 02:08:55 --> Security Class Initialized
DEBUG - 2021-03-26 02:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 02:08:56 --> Input Class Initialized
INFO - 2021-03-26 02:08:56 --> Language Class Initialized
INFO - 2021-03-26 02:08:56 --> Language Class Initialized
INFO - 2021-03-26 02:08:56 --> Config Class Initialized
INFO - 2021-03-26 02:08:56 --> Loader Class Initialized
INFO - 2021-03-26 02:08:56 --> Helper loaded: url_helper
INFO - 2021-03-26 02:08:56 --> Helper loaded: file_helper
INFO - 2021-03-26 02:08:56 --> Helper loaded: form_helper
INFO - 2021-03-26 02:08:56 --> Helper loaded: my_helper
INFO - 2021-03-26 02:08:56 --> Database Driver Class Initialized
DEBUG - 2021-03-26 02:08:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 02:08:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 02:08:56 --> Controller Class Initialized
INFO - 2021-03-26 02:08:56 --> Final output sent to browser
DEBUG - 2021-03-26 02:08:56 --> Total execution time: 0.4791
INFO - 2021-03-26 02:08:58 --> Config Class Initialized
INFO - 2021-03-26 02:08:58 --> Hooks Class Initialized
DEBUG - 2021-03-26 02:08:58 --> UTF-8 Support Enabled
INFO - 2021-03-26 02:08:58 --> Utf8 Class Initialized
INFO - 2021-03-26 02:08:58 --> URI Class Initialized
INFO - 2021-03-26 02:08:58 --> Router Class Initialized
INFO - 2021-03-26 02:08:58 --> Output Class Initialized
INFO - 2021-03-26 02:08:58 --> Security Class Initialized
DEBUG - 2021-03-26 02:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 02:08:58 --> Input Class Initialized
INFO - 2021-03-26 02:08:58 --> Language Class Initialized
INFO - 2021-03-26 02:08:58 --> Language Class Initialized
INFO - 2021-03-26 02:08:58 --> Config Class Initialized
INFO - 2021-03-26 02:08:58 --> Loader Class Initialized
INFO - 2021-03-26 02:08:58 --> Helper loaded: url_helper
INFO - 2021-03-26 02:08:58 --> Helper loaded: file_helper
INFO - 2021-03-26 02:08:58 --> Helper loaded: form_helper
INFO - 2021-03-26 02:08:58 --> Helper loaded: my_helper
INFO - 2021-03-26 02:08:59 --> Database Driver Class Initialized
DEBUG - 2021-03-26 02:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 02:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 02:08:59 --> Controller Class Initialized
INFO - 2021-03-26 02:08:59 --> Final output sent to browser
DEBUG - 2021-03-26 02:08:59 --> Total execution time: 0.6795
INFO - 2021-03-26 02:08:59 --> Config Class Initialized
INFO - 2021-03-26 02:08:59 --> Hooks Class Initialized
DEBUG - 2021-03-26 02:08:59 --> UTF-8 Support Enabled
INFO - 2021-03-26 02:08:59 --> Utf8 Class Initialized
INFO - 2021-03-26 02:08:59 --> URI Class Initialized
INFO - 2021-03-26 02:08:59 --> Router Class Initialized
INFO - 2021-03-26 02:08:59 --> Output Class Initialized
INFO - 2021-03-26 02:08:59 --> Security Class Initialized
DEBUG - 2021-03-26 02:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 02:08:59 --> Input Class Initialized
INFO - 2021-03-26 02:08:59 --> Language Class Initialized
INFO - 2021-03-26 02:08:59 --> Language Class Initialized
INFO - 2021-03-26 02:08:59 --> Config Class Initialized
INFO - 2021-03-26 02:08:59 --> Loader Class Initialized
INFO - 2021-03-26 02:08:59 --> Helper loaded: url_helper
INFO - 2021-03-26 02:08:59 --> Helper loaded: file_helper
INFO - 2021-03-26 02:08:59 --> Helper loaded: form_helper
INFO - 2021-03-26 02:08:59 --> Helper loaded: my_helper
INFO - 2021-03-26 02:08:59 --> Database Driver Class Initialized
DEBUG - 2021-03-26 02:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 02:09:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 02:09:00 --> Controller Class Initialized
INFO - 2021-03-26 02:09:04 --> Config Class Initialized
INFO - 2021-03-26 02:09:04 --> Hooks Class Initialized
DEBUG - 2021-03-26 02:09:04 --> UTF-8 Support Enabled
INFO - 2021-03-26 02:09:04 --> Utf8 Class Initialized
INFO - 2021-03-26 02:09:04 --> URI Class Initialized
INFO - 2021-03-26 02:09:04 --> Router Class Initialized
INFO - 2021-03-26 02:09:05 --> Output Class Initialized
INFO - 2021-03-26 02:09:05 --> Security Class Initialized
DEBUG - 2021-03-26 02:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 02:09:05 --> Input Class Initialized
INFO - 2021-03-26 02:09:05 --> Language Class Initialized
INFO - 2021-03-26 02:09:05 --> Language Class Initialized
INFO - 2021-03-26 02:09:05 --> Config Class Initialized
INFO - 2021-03-26 02:09:05 --> Loader Class Initialized
INFO - 2021-03-26 02:09:05 --> Helper loaded: url_helper
INFO - 2021-03-26 02:09:05 --> Helper loaded: file_helper
INFO - 2021-03-26 02:09:05 --> Helper loaded: form_helper
INFO - 2021-03-26 02:09:05 --> Helper loaded: my_helper
INFO - 2021-03-26 02:09:05 --> Database Driver Class Initialized
DEBUG - 2021-03-26 02:09:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 02:09:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 02:09:05 --> Controller Class Initialized
INFO - 2021-03-26 02:09:05 --> Final output sent to browser
DEBUG - 2021-03-26 02:09:05 --> Total execution time: 0.7451
INFO - 2021-03-26 02:09:17 --> Config Class Initialized
INFO - 2021-03-26 02:09:17 --> Hooks Class Initialized
DEBUG - 2021-03-26 02:09:18 --> UTF-8 Support Enabled
INFO - 2021-03-26 02:09:18 --> Utf8 Class Initialized
INFO - 2021-03-26 02:09:18 --> URI Class Initialized
INFO - 2021-03-26 02:09:18 --> Router Class Initialized
INFO - 2021-03-26 02:09:18 --> Output Class Initialized
INFO - 2021-03-26 02:09:18 --> Security Class Initialized
DEBUG - 2021-03-26 02:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 02:09:18 --> Input Class Initialized
INFO - 2021-03-26 02:09:18 --> Language Class Initialized
INFO - 2021-03-26 02:09:18 --> Language Class Initialized
INFO - 2021-03-26 02:09:18 --> Config Class Initialized
INFO - 2021-03-26 02:09:18 --> Loader Class Initialized
INFO - 2021-03-26 02:09:18 --> Helper loaded: url_helper
INFO - 2021-03-26 02:09:18 --> Helper loaded: file_helper
INFO - 2021-03-26 02:09:18 --> Helper loaded: form_helper
INFO - 2021-03-26 02:09:18 --> Helper loaded: my_helper
INFO - 2021-03-26 02:09:18 --> Database Driver Class Initialized
DEBUG - 2021-03-26 02:09:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 02:09:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 02:09:18 --> Controller Class Initialized
INFO - 2021-03-26 02:09:18 --> Final output sent to browser
DEBUG - 2021-03-26 02:09:18 --> Total execution time: 0.6416
INFO - 2021-03-26 02:09:41 --> Config Class Initialized
INFO - 2021-03-26 02:09:41 --> Hooks Class Initialized
DEBUG - 2021-03-26 02:09:41 --> UTF-8 Support Enabled
INFO - 2021-03-26 02:09:41 --> Utf8 Class Initialized
INFO - 2021-03-26 02:09:41 --> URI Class Initialized
INFO - 2021-03-26 02:09:41 --> Router Class Initialized
INFO - 2021-03-26 02:09:41 --> Output Class Initialized
INFO - 2021-03-26 02:09:41 --> Security Class Initialized
DEBUG - 2021-03-26 02:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 02:09:41 --> Input Class Initialized
INFO - 2021-03-26 02:09:41 --> Language Class Initialized
INFO - 2021-03-26 02:09:41 --> Language Class Initialized
INFO - 2021-03-26 02:09:41 --> Config Class Initialized
INFO - 2021-03-26 02:09:41 --> Loader Class Initialized
INFO - 2021-03-26 02:09:41 --> Helper loaded: url_helper
INFO - 2021-03-26 02:09:41 --> Helper loaded: file_helper
INFO - 2021-03-26 02:09:41 --> Helper loaded: form_helper
INFO - 2021-03-26 02:09:41 --> Helper loaded: my_helper
INFO - 2021-03-26 02:09:42 --> Database Driver Class Initialized
DEBUG - 2021-03-26 02:09:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 02:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 02:09:42 --> Controller Class Initialized
DEBUG - 2021-03-26 02:09:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-03-26 02:09:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-03-26 02:09:42 --> Final output sent to browser
DEBUG - 2021-03-26 02:09:42 --> Total execution time: 1.0133
INFO - 2021-03-26 02:09:43 --> Config Class Initialized
INFO - 2021-03-26 02:09:43 --> Hooks Class Initialized
DEBUG - 2021-03-26 02:09:43 --> UTF-8 Support Enabled
INFO - 2021-03-26 02:09:43 --> Utf8 Class Initialized
INFO - 2021-03-26 02:09:43 --> URI Class Initialized
INFO - 2021-03-26 02:09:43 --> Router Class Initialized
INFO - 2021-03-26 02:09:43 --> Output Class Initialized
INFO - 2021-03-26 02:09:43 --> Security Class Initialized
DEBUG - 2021-03-26 02:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 02:09:44 --> Input Class Initialized
INFO - 2021-03-26 02:09:44 --> Language Class Initialized
INFO - 2021-03-26 02:09:44 --> Language Class Initialized
INFO - 2021-03-26 02:09:44 --> Config Class Initialized
INFO - 2021-03-26 02:09:44 --> Loader Class Initialized
INFO - 2021-03-26 02:09:44 --> Helper loaded: url_helper
INFO - 2021-03-26 02:09:44 --> Helper loaded: file_helper
INFO - 2021-03-26 02:09:44 --> Helper loaded: form_helper
INFO - 2021-03-26 02:09:44 --> Helper loaded: my_helper
INFO - 2021-03-26 02:09:44 --> Database Driver Class Initialized
DEBUG - 2021-03-26 02:09:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 02:09:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 02:09:44 --> Controller Class Initialized
DEBUG - 2021-03-26 02:09:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-03-26 02:09:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-03-26 02:09:44 --> Final output sent to browser
DEBUG - 2021-03-26 02:09:44 --> Total execution time: 0.9036
INFO - 2021-03-26 02:09:54 --> Config Class Initialized
INFO - 2021-03-26 02:09:54 --> Hooks Class Initialized
DEBUG - 2021-03-26 02:09:54 --> UTF-8 Support Enabled
INFO - 2021-03-26 02:09:54 --> Utf8 Class Initialized
INFO - 2021-03-26 02:09:54 --> URI Class Initialized
INFO - 2021-03-26 02:09:54 --> Router Class Initialized
INFO - 2021-03-26 02:09:54 --> Output Class Initialized
INFO - 2021-03-26 02:09:54 --> Security Class Initialized
DEBUG - 2021-03-26 02:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 02:09:54 --> Input Class Initialized
INFO - 2021-03-26 02:09:54 --> Language Class Initialized
INFO - 2021-03-26 02:09:54 --> Language Class Initialized
INFO - 2021-03-26 02:09:54 --> Config Class Initialized
INFO - 2021-03-26 02:09:54 --> Loader Class Initialized
INFO - 2021-03-26 02:09:54 --> Helper loaded: url_helper
INFO - 2021-03-26 02:09:54 --> Helper loaded: file_helper
INFO - 2021-03-26 02:09:54 --> Helper loaded: form_helper
INFO - 2021-03-26 02:09:54 --> Helper loaded: my_helper
INFO - 2021-03-26 02:09:54 --> Database Driver Class Initialized
DEBUG - 2021-03-26 02:09:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 02:09:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 02:09:54 --> Controller Class Initialized
INFO - 2021-03-26 02:09:55 --> Config Class Initialized
INFO - 2021-03-26 02:09:55 --> Hooks Class Initialized
DEBUG - 2021-03-26 02:09:55 --> UTF-8 Support Enabled
INFO - 2021-03-26 02:09:55 --> Utf8 Class Initialized
INFO - 2021-03-26 02:09:55 --> URI Class Initialized
INFO - 2021-03-26 02:09:55 --> Router Class Initialized
INFO - 2021-03-26 02:09:55 --> Output Class Initialized
INFO - 2021-03-26 02:09:55 --> Security Class Initialized
DEBUG - 2021-03-26 02:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 02:09:55 --> Input Class Initialized
INFO - 2021-03-26 02:09:55 --> Language Class Initialized
INFO - 2021-03-26 02:09:55 --> Language Class Initialized
INFO - 2021-03-26 02:09:55 --> Config Class Initialized
INFO - 2021-03-26 02:09:55 --> Loader Class Initialized
INFO - 2021-03-26 02:09:55 --> Helper loaded: url_helper
INFO - 2021-03-26 02:09:55 --> Helper loaded: file_helper
INFO - 2021-03-26 02:09:55 --> Helper loaded: form_helper
INFO - 2021-03-26 02:09:55 --> Helper loaded: my_helper
INFO - 2021-03-26 02:09:55 --> Database Driver Class Initialized
DEBUG - 2021-03-26 02:09:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 02:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 02:09:55 --> Controller Class Initialized
DEBUG - 2021-03-26 02:09:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-03-26 02:09:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-03-26 02:09:56 --> Final output sent to browser
DEBUG - 2021-03-26 02:09:56 --> Total execution time: 1.0012
INFO - 2021-03-26 02:10:16 --> Config Class Initialized
INFO - 2021-03-26 02:10:16 --> Hooks Class Initialized
DEBUG - 2021-03-26 02:10:16 --> UTF-8 Support Enabled
INFO - 2021-03-26 02:10:16 --> Utf8 Class Initialized
INFO - 2021-03-26 02:10:16 --> URI Class Initialized
INFO - 2021-03-26 02:10:16 --> Router Class Initialized
INFO - 2021-03-26 02:10:16 --> Output Class Initialized
INFO - 2021-03-26 02:10:16 --> Security Class Initialized
DEBUG - 2021-03-26 02:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 02:10:16 --> Input Class Initialized
INFO - 2021-03-26 02:10:16 --> Language Class Initialized
INFO - 2021-03-26 02:10:16 --> Language Class Initialized
INFO - 2021-03-26 02:10:16 --> Config Class Initialized
INFO - 2021-03-26 02:10:16 --> Loader Class Initialized
INFO - 2021-03-26 02:10:16 --> Helper loaded: url_helper
INFO - 2021-03-26 02:10:16 --> Helper loaded: file_helper
INFO - 2021-03-26 02:10:16 --> Helper loaded: form_helper
INFO - 2021-03-26 02:10:16 --> Helper loaded: my_helper
INFO - 2021-03-26 02:10:16 --> Database Driver Class Initialized
DEBUG - 2021-03-26 02:10:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 02:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 02:10:16 --> Controller Class Initialized
DEBUG - 2021-03-26 02:10:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-03-26 02:10:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-03-26 02:10:16 --> Final output sent to browser
DEBUG - 2021-03-26 02:10:16 --> Total execution time: 0.7369
INFO - 2021-03-26 04:41:12 --> Config Class Initialized
INFO - 2021-03-26 04:41:12 --> Hooks Class Initialized
DEBUG - 2021-03-26 04:41:12 --> UTF-8 Support Enabled
INFO - 2021-03-26 04:41:12 --> Utf8 Class Initialized
INFO - 2021-03-26 04:41:12 --> URI Class Initialized
DEBUG - 2021-03-26 04:41:12 --> No URI present. Default controller set.
INFO - 2021-03-26 04:41:12 --> Router Class Initialized
INFO - 2021-03-26 04:41:12 --> Output Class Initialized
INFO - 2021-03-26 04:41:12 --> Security Class Initialized
DEBUG - 2021-03-26 04:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 04:41:12 --> Input Class Initialized
INFO - 2021-03-26 04:41:12 --> Language Class Initialized
INFO - 2021-03-26 04:41:12 --> Language Class Initialized
INFO - 2021-03-26 04:41:12 --> Config Class Initialized
INFO - 2021-03-26 04:41:12 --> Loader Class Initialized
INFO - 2021-03-26 04:41:12 --> Helper loaded: url_helper
INFO - 2021-03-26 04:41:12 --> Helper loaded: file_helper
INFO - 2021-03-26 04:41:12 --> Helper loaded: form_helper
INFO - 2021-03-26 04:41:12 --> Helper loaded: my_helper
INFO - 2021-03-26 04:41:12 --> Database Driver Class Initialized
DEBUG - 2021-03-26 04:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 04:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 04:41:12 --> Controller Class Initialized
INFO - 2021-03-26 04:41:12 --> Config Class Initialized
INFO - 2021-03-26 04:41:12 --> Hooks Class Initialized
DEBUG - 2021-03-26 04:41:12 --> UTF-8 Support Enabled
INFO - 2021-03-26 04:41:12 --> Utf8 Class Initialized
INFO - 2021-03-26 04:41:12 --> URI Class Initialized
INFO - 2021-03-26 04:41:12 --> Router Class Initialized
INFO - 2021-03-26 04:41:12 --> Output Class Initialized
INFO - 2021-03-26 04:41:12 --> Security Class Initialized
DEBUG - 2021-03-26 04:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 04:41:12 --> Input Class Initialized
INFO - 2021-03-26 04:41:12 --> Language Class Initialized
INFO - 2021-03-26 04:41:12 --> Language Class Initialized
INFO - 2021-03-26 04:41:12 --> Config Class Initialized
INFO - 2021-03-26 04:41:12 --> Loader Class Initialized
INFO - 2021-03-26 04:41:12 --> Helper loaded: url_helper
INFO - 2021-03-26 04:41:12 --> Helper loaded: file_helper
INFO - 2021-03-26 04:41:12 --> Helper loaded: form_helper
INFO - 2021-03-26 04:41:12 --> Helper loaded: my_helper
INFO - 2021-03-26 04:41:13 --> Database Driver Class Initialized
DEBUG - 2021-03-26 04:41:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 04:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 04:41:13 --> Controller Class Initialized
DEBUG - 2021-03-26 04:41:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-03-26 04:41:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-03-26 04:41:13 --> Final output sent to browser
DEBUG - 2021-03-26 04:41:13 --> Total execution time: 0.3092
INFO - 2021-03-26 04:41:18 --> Config Class Initialized
INFO - 2021-03-26 04:41:18 --> Hooks Class Initialized
DEBUG - 2021-03-26 04:41:18 --> UTF-8 Support Enabled
INFO - 2021-03-26 04:41:18 --> Utf8 Class Initialized
INFO - 2021-03-26 04:41:18 --> URI Class Initialized
INFO - 2021-03-26 04:41:18 --> Router Class Initialized
INFO - 2021-03-26 04:41:18 --> Output Class Initialized
INFO - 2021-03-26 04:41:18 --> Security Class Initialized
DEBUG - 2021-03-26 04:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 04:41:18 --> Input Class Initialized
INFO - 2021-03-26 04:41:18 --> Language Class Initialized
INFO - 2021-03-26 04:41:18 --> Language Class Initialized
INFO - 2021-03-26 04:41:18 --> Config Class Initialized
INFO - 2021-03-26 04:41:18 --> Loader Class Initialized
INFO - 2021-03-26 04:41:18 --> Helper loaded: url_helper
INFO - 2021-03-26 04:41:18 --> Helper loaded: file_helper
INFO - 2021-03-26 04:41:18 --> Helper loaded: form_helper
INFO - 2021-03-26 04:41:18 --> Helper loaded: my_helper
INFO - 2021-03-26 04:41:18 --> Database Driver Class Initialized
DEBUG - 2021-03-26 04:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 04:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 04:41:18 --> Controller Class Initialized
INFO - 2021-03-26 04:41:18 --> Helper loaded: cookie_helper
INFO - 2021-03-26 04:41:18 --> Final output sent to browser
DEBUG - 2021-03-26 04:41:18 --> Total execution time: 0.3310
INFO - 2021-03-26 04:41:19 --> Config Class Initialized
INFO - 2021-03-26 04:41:19 --> Hooks Class Initialized
DEBUG - 2021-03-26 04:41:19 --> UTF-8 Support Enabled
INFO - 2021-03-26 04:41:19 --> Utf8 Class Initialized
INFO - 2021-03-26 04:41:19 --> URI Class Initialized
INFO - 2021-03-26 04:41:19 --> Router Class Initialized
INFO - 2021-03-26 04:41:19 --> Output Class Initialized
INFO - 2021-03-26 04:41:19 --> Security Class Initialized
DEBUG - 2021-03-26 04:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 04:41:19 --> Input Class Initialized
INFO - 2021-03-26 04:41:19 --> Language Class Initialized
INFO - 2021-03-26 04:41:19 --> Language Class Initialized
INFO - 2021-03-26 04:41:19 --> Config Class Initialized
INFO - 2021-03-26 04:41:19 --> Loader Class Initialized
INFO - 2021-03-26 04:41:19 --> Helper loaded: url_helper
INFO - 2021-03-26 04:41:19 --> Helper loaded: file_helper
INFO - 2021-03-26 04:41:19 --> Helper loaded: form_helper
INFO - 2021-03-26 04:41:19 --> Helper loaded: my_helper
INFO - 2021-03-26 04:41:19 --> Database Driver Class Initialized
DEBUG - 2021-03-26 04:41:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 04:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 04:41:19 --> Controller Class Initialized
DEBUG - 2021-03-26 04:41:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-03-26 04:41:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-03-26 04:41:20 --> Final output sent to browser
DEBUG - 2021-03-26 04:41:20 --> Total execution time: 0.4485
INFO - 2021-03-26 04:41:25 --> Config Class Initialized
INFO - 2021-03-26 04:41:25 --> Hooks Class Initialized
DEBUG - 2021-03-26 04:41:25 --> UTF-8 Support Enabled
INFO - 2021-03-26 04:41:25 --> Utf8 Class Initialized
INFO - 2021-03-26 04:41:25 --> URI Class Initialized
INFO - 2021-03-26 04:41:25 --> Router Class Initialized
INFO - 2021-03-26 04:41:25 --> Output Class Initialized
INFO - 2021-03-26 04:41:25 --> Security Class Initialized
DEBUG - 2021-03-26 04:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 04:41:25 --> Input Class Initialized
INFO - 2021-03-26 04:41:25 --> Language Class Initialized
INFO - 2021-03-26 04:41:25 --> Language Class Initialized
INFO - 2021-03-26 04:41:25 --> Config Class Initialized
INFO - 2021-03-26 04:41:25 --> Loader Class Initialized
INFO - 2021-03-26 04:41:25 --> Helper loaded: url_helper
INFO - 2021-03-26 04:41:25 --> Helper loaded: file_helper
INFO - 2021-03-26 04:41:25 --> Helper loaded: form_helper
INFO - 2021-03-26 04:41:25 --> Helper loaded: my_helper
INFO - 2021-03-26 04:41:25 --> Database Driver Class Initialized
DEBUG - 2021-03-26 04:41:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 04:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 04:41:25 --> Controller Class Initialized
DEBUG - 2021-03-26 04:41:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2021-03-26 04:41:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-03-26 04:41:25 --> Final output sent to browser
DEBUG - 2021-03-26 04:41:25 --> Total execution time: 0.3128
INFO - 2021-03-26 04:41:25 --> Config Class Initialized
INFO - 2021-03-26 04:41:25 --> Hooks Class Initialized
DEBUG - 2021-03-26 04:41:25 --> UTF-8 Support Enabled
INFO - 2021-03-26 04:41:25 --> Utf8 Class Initialized
INFO - 2021-03-26 04:41:25 --> URI Class Initialized
INFO - 2021-03-26 04:41:25 --> Router Class Initialized
INFO - 2021-03-26 04:41:25 --> Output Class Initialized
INFO - 2021-03-26 04:41:25 --> Security Class Initialized
DEBUG - 2021-03-26 04:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 04:41:25 --> Input Class Initialized
INFO - 2021-03-26 04:41:25 --> Language Class Initialized
INFO - 2021-03-26 04:41:25 --> Language Class Initialized
INFO - 2021-03-26 04:41:25 --> Config Class Initialized
INFO - 2021-03-26 04:41:25 --> Loader Class Initialized
INFO - 2021-03-26 04:41:25 --> Helper loaded: url_helper
INFO - 2021-03-26 04:41:25 --> Helper loaded: file_helper
INFO - 2021-03-26 04:41:25 --> Helper loaded: form_helper
INFO - 2021-03-26 04:41:25 --> Helper loaded: my_helper
INFO - 2021-03-26 04:41:25 --> Database Driver Class Initialized
DEBUG - 2021-03-26 04:41:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 04:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 04:41:25 --> Controller Class Initialized
INFO - 2021-03-26 04:41:27 --> Config Class Initialized
INFO - 2021-03-26 04:41:27 --> Hooks Class Initialized
DEBUG - 2021-03-26 04:41:27 --> UTF-8 Support Enabled
INFO - 2021-03-26 04:41:27 --> Utf8 Class Initialized
INFO - 2021-03-26 04:41:27 --> URI Class Initialized
INFO - 2021-03-26 04:41:27 --> Router Class Initialized
INFO - 2021-03-26 04:41:27 --> Output Class Initialized
INFO - 2021-03-26 04:41:27 --> Security Class Initialized
DEBUG - 2021-03-26 04:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 04:41:27 --> Input Class Initialized
INFO - 2021-03-26 04:41:27 --> Language Class Initialized
INFO - 2021-03-26 04:41:27 --> Language Class Initialized
INFO - 2021-03-26 04:41:27 --> Config Class Initialized
INFO - 2021-03-26 04:41:27 --> Loader Class Initialized
INFO - 2021-03-26 04:41:27 --> Helper loaded: url_helper
INFO - 2021-03-26 04:41:27 --> Helper loaded: file_helper
INFO - 2021-03-26 04:41:27 --> Helper loaded: form_helper
INFO - 2021-03-26 04:41:27 --> Helper loaded: my_helper
INFO - 2021-03-26 04:41:27 --> Database Driver Class Initialized
DEBUG - 2021-03-26 04:41:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 04:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 04:41:27 --> Controller Class Initialized
INFO - 2021-03-26 04:41:27 --> Final output sent to browser
DEBUG - 2021-03-26 04:41:27 --> Total execution time: 0.2698
INFO - 2021-03-26 04:41:31 --> Config Class Initialized
INFO - 2021-03-26 04:41:31 --> Hooks Class Initialized
DEBUG - 2021-03-26 04:41:31 --> UTF-8 Support Enabled
INFO - 2021-03-26 04:41:31 --> Utf8 Class Initialized
INFO - 2021-03-26 04:41:31 --> URI Class Initialized
INFO - 2021-03-26 04:41:31 --> Router Class Initialized
INFO - 2021-03-26 04:41:31 --> Output Class Initialized
INFO - 2021-03-26 04:41:31 --> Security Class Initialized
DEBUG - 2021-03-26 04:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 04:41:31 --> Input Class Initialized
INFO - 2021-03-26 04:41:31 --> Language Class Initialized
INFO - 2021-03-26 04:41:31 --> Language Class Initialized
INFO - 2021-03-26 04:41:31 --> Config Class Initialized
INFO - 2021-03-26 04:41:31 --> Loader Class Initialized
INFO - 2021-03-26 04:41:31 --> Helper loaded: url_helper
INFO - 2021-03-26 04:41:31 --> Helper loaded: file_helper
INFO - 2021-03-26 04:41:32 --> Helper loaded: form_helper
INFO - 2021-03-26 04:41:32 --> Helper loaded: my_helper
INFO - 2021-03-26 04:41:32 --> Database Driver Class Initialized
DEBUG - 2021-03-26 04:41:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 04:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 04:41:32 --> Controller Class Initialized
INFO - 2021-03-26 04:41:32 --> Final output sent to browser
DEBUG - 2021-03-26 04:41:32 --> Total execution time: 0.3192
INFO - 2021-03-26 04:41:32 --> Config Class Initialized
INFO - 2021-03-26 04:41:32 --> Hooks Class Initialized
DEBUG - 2021-03-26 04:41:32 --> UTF-8 Support Enabled
INFO - 2021-03-26 04:41:32 --> Utf8 Class Initialized
INFO - 2021-03-26 04:41:32 --> URI Class Initialized
INFO - 2021-03-26 04:41:32 --> Router Class Initialized
INFO - 2021-03-26 04:41:32 --> Output Class Initialized
INFO - 2021-03-26 04:41:32 --> Security Class Initialized
DEBUG - 2021-03-26 04:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 04:41:32 --> Input Class Initialized
INFO - 2021-03-26 04:41:32 --> Language Class Initialized
INFO - 2021-03-26 04:41:32 --> Language Class Initialized
INFO - 2021-03-26 04:41:32 --> Config Class Initialized
INFO - 2021-03-26 04:41:32 --> Loader Class Initialized
INFO - 2021-03-26 04:41:32 --> Helper loaded: url_helper
INFO - 2021-03-26 04:41:32 --> Helper loaded: file_helper
INFO - 2021-03-26 04:41:32 --> Helper loaded: form_helper
INFO - 2021-03-26 04:41:32 --> Helper loaded: my_helper
INFO - 2021-03-26 04:41:32 --> Database Driver Class Initialized
DEBUG - 2021-03-26 04:41:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 04:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 04:41:32 --> Controller Class Initialized
INFO - 2021-03-26 04:41:35 --> Config Class Initialized
INFO - 2021-03-26 04:41:35 --> Hooks Class Initialized
DEBUG - 2021-03-26 04:41:35 --> UTF-8 Support Enabled
INFO - 2021-03-26 04:41:35 --> Utf8 Class Initialized
INFO - 2021-03-26 04:41:35 --> URI Class Initialized
INFO - 2021-03-26 04:41:35 --> Router Class Initialized
INFO - 2021-03-26 04:41:35 --> Output Class Initialized
INFO - 2021-03-26 04:41:35 --> Security Class Initialized
DEBUG - 2021-03-26 04:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 04:41:35 --> Input Class Initialized
INFO - 2021-03-26 04:41:35 --> Language Class Initialized
INFO - 2021-03-26 04:41:35 --> Language Class Initialized
INFO - 2021-03-26 04:41:35 --> Config Class Initialized
INFO - 2021-03-26 04:41:35 --> Loader Class Initialized
INFO - 2021-03-26 04:41:35 --> Helper loaded: url_helper
INFO - 2021-03-26 04:41:35 --> Helper loaded: file_helper
INFO - 2021-03-26 04:41:35 --> Helper loaded: form_helper
INFO - 2021-03-26 04:41:35 --> Helper loaded: my_helper
INFO - 2021-03-26 04:41:36 --> Database Driver Class Initialized
DEBUG - 2021-03-26 04:41:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 04:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 04:41:36 --> Controller Class Initialized
INFO - 2021-03-26 04:41:36 --> Final output sent to browser
DEBUG - 2021-03-26 04:41:36 --> Total execution time: 0.4061
INFO - 2021-03-26 04:41:36 --> Config Class Initialized
INFO - 2021-03-26 04:41:36 --> Hooks Class Initialized
DEBUG - 2021-03-26 04:41:36 --> UTF-8 Support Enabled
INFO - 2021-03-26 04:41:36 --> Utf8 Class Initialized
INFO - 2021-03-26 04:41:36 --> URI Class Initialized
INFO - 2021-03-26 04:41:36 --> Router Class Initialized
INFO - 2021-03-26 04:41:36 --> Output Class Initialized
INFO - 2021-03-26 04:41:36 --> Security Class Initialized
DEBUG - 2021-03-26 04:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 04:41:36 --> Input Class Initialized
INFO - 2021-03-26 04:41:36 --> Language Class Initialized
INFO - 2021-03-26 04:41:36 --> Language Class Initialized
INFO - 2021-03-26 04:41:36 --> Config Class Initialized
INFO - 2021-03-26 04:41:36 --> Loader Class Initialized
INFO - 2021-03-26 04:41:36 --> Helper loaded: url_helper
INFO - 2021-03-26 04:41:36 --> Helper loaded: file_helper
INFO - 2021-03-26 04:41:36 --> Helper loaded: form_helper
INFO - 2021-03-26 04:41:36 --> Helper loaded: my_helper
INFO - 2021-03-26 04:41:36 --> Database Driver Class Initialized
DEBUG - 2021-03-26 04:41:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 04:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 04:41:36 --> Controller Class Initialized
INFO - 2021-03-26 04:42:22 --> Config Class Initialized
INFO - 2021-03-26 04:42:22 --> Hooks Class Initialized
DEBUG - 2021-03-26 04:42:22 --> UTF-8 Support Enabled
INFO - 2021-03-26 04:42:22 --> Utf8 Class Initialized
INFO - 2021-03-26 04:42:22 --> URI Class Initialized
INFO - 2021-03-26 04:42:22 --> Router Class Initialized
INFO - 2021-03-26 04:42:22 --> Output Class Initialized
INFO - 2021-03-26 04:42:22 --> Security Class Initialized
DEBUG - 2021-03-26 04:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 04:42:22 --> Input Class Initialized
INFO - 2021-03-26 04:42:22 --> Language Class Initialized
INFO - 2021-03-26 04:42:22 --> Language Class Initialized
INFO - 2021-03-26 04:42:22 --> Config Class Initialized
INFO - 2021-03-26 04:42:22 --> Loader Class Initialized
INFO - 2021-03-26 04:42:22 --> Helper loaded: url_helper
INFO - 2021-03-26 04:42:22 --> Helper loaded: file_helper
INFO - 2021-03-26 04:42:22 --> Helper loaded: form_helper
INFO - 2021-03-26 04:42:22 --> Helper loaded: my_helper
INFO - 2021-03-26 04:42:22 --> Database Driver Class Initialized
DEBUG - 2021-03-26 04:42:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 04:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 04:42:22 --> Controller Class Initialized
DEBUG - 2021-03-26 04:42:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2021-03-26 04:42:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-03-26 04:42:22 --> Final output sent to browser
DEBUG - 2021-03-26 04:42:22 --> Total execution time: 0.3808
INFO - 2021-03-26 04:42:22 --> Config Class Initialized
INFO - 2021-03-26 04:42:22 --> Hooks Class Initialized
DEBUG - 2021-03-26 04:42:22 --> UTF-8 Support Enabled
INFO - 2021-03-26 04:42:22 --> Utf8 Class Initialized
INFO - 2021-03-26 04:42:22 --> URI Class Initialized
INFO - 2021-03-26 04:42:22 --> Router Class Initialized
INFO - 2021-03-26 04:42:22 --> Output Class Initialized
INFO - 2021-03-26 04:42:22 --> Security Class Initialized
DEBUG - 2021-03-26 04:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 04:42:22 --> Input Class Initialized
INFO - 2021-03-26 04:42:22 --> Language Class Initialized
INFO - 2021-03-26 04:42:22 --> Language Class Initialized
INFO - 2021-03-26 04:42:22 --> Config Class Initialized
INFO - 2021-03-26 04:42:22 --> Loader Class Initialized
INFO - 2021-03-26 04:42:22 --> Helper loaded: url_helper
INFO - 2021-03-26 04:42:22 --> Helper loaded: file_helper
INFO - 2021-03-26 04:42:23 --> Helper loaded: form_helper
INFO - 2021-03-26 04:42:23 --> Helper loaded: my_helper
INFO - 2021-03-26 04:42:23 --> Database Driver Class Initialized
DEBUG - 2021-03-26 04:42:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 04:42:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 04:42:23 --> Controller Class Initialized
INFO - 2021-03-26 04:42:23 --> Config Class Initialized
INFO - 2021-03-26 04:42:23 --> Hooks Class Initialized
DEBUG - 2021-03-26 04:42:23 --> UTF-8 Support Enabled
INFO - 2021-03-26 04:42:23 --> Utf8 Class Initialized
INFO - 2021-03-26 04:42:23 --> URI Class Initialized
INFO - 2021-03-26 04:42:23 --> Router Class Initialized
INFO - 2021-03-26 04:42:23 --> Output Class Initialized
INFO - 2021-03-26 04:42:23 --> Security Class Initialized
DEBUG - 2021-03-26 04:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 04:42:23 --> Input Class Initialized
INFO - 2021-03-26 04:42:23 --> Language Class Initialized
INFO - 2021-03-26 04:42:23 --> Language Class Initialized
INFO - 2021-03-26 04:42:23 --> Config Class Initialized
INFO - 2021-03-26 04:42:23 --> Loader Class Initialized
INFO - 2021-03-26 04:42:23 --> Helper loaded: url_helper
INFO - 2021-03-26 04:42:23 --> Helper loaded: file_helper
INFO - 2021-03-26 04:42:23 --> Helper loaded: form_helper
INFO - 2021-03-26 04:42:23 --> Helper loaded: my_helper
INFO - 2021-03-26 04:42:24 --> Database Driver Class Initialized
DEBUG - 2021-03-26 04:42:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 04:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 04:42:24 --> Controller Class Initialized
INFO - 2021-03-26 04:42:24 --> Final output sent to browser
DEBUG - 2021-03-26 04:42:24 --> Total execution time: 0.2703
INFO - 2021-03-26 04:42:29 --> Config Class Initialized
INFO - 2021-03-26 04:42:29 --> Hooks Class Initialized
DEBUG - 2021-03-26 04:42:29 --> UTF-8 Support Enabled
INFO - 2021-03-26 04:42:29 --> Utf8 Class Initialized
INFO - 2021-03-26 04:42:29 --> URI Class Initialized
INFO - 2021-03-26 04:42:29 --> Router Class Initialized
INFO - 2021-03-26 04:42:29 --> Output Class Initialized
INFO - 2021-03-26 04:42:29 --> Security Class Initialized
DEBUG - 2021-03-26 04:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 04:42:29 --> Input Class Initialized
INFO - 2021-03-26 04:42:29 --> Language Class Initialized
INFO - 2021-03-26 04:42:29 --> Language Class Initialized
INFO - 2021-03-26 04:42:29 --> Config Class Initialized
INFO - 2021-03-26 04:42:29 --> Loader Class Initialized
INFO - 2021-03-26 04:42:29 --> Helper loaded: url_helper
INFO - 2021-03-26 04:42:29 --> Helper loaded: file_helper
INFO - 2021-03-26 04:42:29 --> Helper loaded: form_helper
INFO - 2021-03-26 04:42:29 --> Helper loaded: my_helper
INFO - 2021-03-26 04:42:29 --> Database Driver Class Initialized
DEBUG - 2021-03-26 04:42:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 04:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 04:42:29 --> Controller Class Initialized
DEBUG - 2021-03-26 04:42:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-03-26 04:42:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-03-26 04:42:29 --> Final output sent to browser
DEBUG - 2021-03-26 04:42:29 --> Total execution time: 0.2769
INFO - 2021-03-26 04:42:29 --> Config Class Initialized
INFO - 2021-03-26 04:42:29 --> Hooks Class Initialized
DEBUG - 2021-03-26 04:42:29 --> UTF-8 Support Enabled
INFO - 2021-03-26 04:42:29 --> Utf8 Class Initialized
INFO - 2021-03-26 04:42:29 --> URI Class Initialized
INFO - 2021-03-26 04:42:29 --> Router Class Initialized
INFO - 2021-03-26 04:42:29 --> Output Class Initialized
INFO - 2021-03-26 04:42:29 --> Security Class Initialized
DEBUG - 2021-03-26 04:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 04:42:29 --> Input Class Initialized
INFO - 2021-03-26 04:42:29 --> Language Class Initialized
INFO - 2021-03-26 04:42:29 --> Language Class Initialized
INFO - 2021-03-26 04:42:30 --> Config Class Initialized
INFO - 2021-03-26 04:42:30 --> Loader Class Initialized
INFO - 2021-03-26 04:42:30 --> Helper loaded: url_helper
INFO - 2021-03-26 04:42:30 --> Helper loaded: file_helper
INFO - 2021-03-26 04:42:30 --> Helper loaded: form_helper
INFO - 2021-03-26 04:42:30 --> Helper loaded: my_helper
INFO - 2021-03-26 04:42:30 --> Database Driver Class Initialized
DEBUG - 2021-03-26 04:42:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 04:42:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 04:42:30 --> Controller Class Initialized
INFO - 2021-03-26 04:42:30 --> Config Class Initialized
INFO - 2021-03-26 04:42:30 --> Hooks Class Initialized
DEBUG - 2021-03-26 04:42:31 --> UTF-8 Support Enabled
INFO - 2021-03-26 04:42:31 --> Utf8 Class Initialized
INFO - 2021-03-26 04:42:31 --> URI Class Initialized
INFO - 2021-03-26 04:42:31 --> Router Class Initialized
INFO - 2021-03-26 04:42:31 --> Output Class Initialized
INFO - 2021-03-26 04:42:31 --> Security Class Initialized
DEBUG - 2021-03-26 04:42:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 04:42:31 --> Input Class Initialized
INFO - 2021-03-26 04:42:31 --> Language Class Initialized
INFO - 2021-03-26 04:42:31 --> Language Class Initialized
INFO - 2021-03-26 04:42:31 --> Config Class Initialized
INFO - 2021-03-26 04:42:31 --> Loader Class Initialized
INFO - 2021-03-26 04:42:31 --> Helper loaded: url_helper
INFO - 2021-03-26 04:42:31 --> Helper loaded: file_helper
INFO - 2021-03-26 04:42:31 --> Helper loaded: form_helper
INFO - 2021-03-26 04:42:31 --> Helper loaded: my_helper
INFO - 2021-03-26 04:42:31 --> Database Driver Class Initialized
DEBUG - 2021-03-26 04:42:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 04:42:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 04:42:31 --> Controller Class Initialized
DEBUG - 2021-03-26 04:42:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2021-03-26 04:42:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-03-26 04:42:31 --> Final output sent to browser
DEBUG - 2021-03-26 04:42:31 --> Total execution time: 0.3073
INFO - 2021-03-26 04:42:31 --> Config Class Initialized
INFO - 2021-03-26 04:42:31 --> Hooks Class Initialized
DEBUG - 2021-03-26 04:42:31 --> UTF-8 Support Enabled
INFO - 2021-03-26 04:42:31 --> Utf8 Class Initialized
INFO - 2021-03-26 04:42:31 --> URI Class Initialized
INFO - 2021-03-26 04:42:31 --> Router Class Initialized
INFO - 2021-03-26 04:42:31 --> Output Class Initialized
INFO - 2021-03-26 04:42:31 --> Security Class Initialized
DEBUG - 2021-03-26 04:42:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 04:42:31 --> Input Class Initialized
INFO - 2021-03-26 04:42:31 --> Language Class Initialized
INFO - 2021-03-26 04:42:31 --> Language Class Initialized
INFO - 2021-03-26 04:42:31 --> Config Class Initialized
INFO - 2021-03-26 04:42:31 --> Loader Class Initialized
INFO - 2021-03-26 04:42:31 --> Helper loaded: url_helper
INFO - 2021-03-26 04:42:31 --> Helper loaded: file_helper
INFO - 2021-03-26 04:42:31 --> Helper loaded: form_helper
INFO - 2021-03-26 04:42:31 --> Helper loaded: my_helper
INFO - 2021-03-26 04:42:31 --> Database Driver Class Initialized
DEBUG - 2021-03-26 04:42:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 04:42:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 04:42:31 --> Controller Class Initialized
INFO - 2021-03-26 04:42:34 --> Config Class Initialized
INFO - 2021-03-26 04:42:34 --> Hooks Class Initialized
DEBUG - 2021-03-26 04:42:34 --> UTF-8 Support Enabled
INFO - 2021-03-26 04:42:34 --> Utf8 Class Initialized
INFO - 2021-03-26 04:42:34 --> URI Class Initialized
INFO - 2021-03-26 04:42:34 --> Router Class Initialized
INFO - 2021-03-26 04:42:34 --> Output Class Initialized
INFO - 2021-03-26 04:42:34 --> Security Class Initialized
DEBUG - 2021-03-26 04:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 04:42:34 --> Input Class Initialized
INFO - 2021-03-26 04:42:34 --> Language Class Initialized
INFO - 2021-03-26 04:42:34 --> Language Class Initialized
INFO - 2021-03-26 04:42:34 --> Config Class Initialized
INFO - 2021-03-26 04:42:34 --> Loader Class Initialized
INFO - 2021-03-26 04:42:34 --> Helper loaded: url_helper
INFO - 2021-03-26 04:42:34 --> Helper loaded: file_helper
INFO - 2021-03-26 04:42:34 --> Helper loaded: form_helper
INFO - 2021-03-26 04:42:34 --> Helper loaded: my_helper
INFO - 2021-03-26 04:42:34 --> Database Driver Class Initialized
DEBUG - 2021-03-26 04:42:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 04:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 04:42:34 --> Controller Class Initialized
INFO - 2021-03-26 04:42:34 --> Final output sent to browser
DEBUG - 2021-03-26 04:42:34 --> Total execution time: 0.2790
INFO - 2021-03-26 04:52:59 --> Config Class Initialized
INFO - 2021-03-26 04:52:59 --> Hooks Class Initialized
DEBUG - 2021-03-26 04:52:59 --> UTF-8 Support Enabled
INFO - 2021-03-26 04:52:59 --> Utf8 Class Initialized
INFO - 2021-03-26 04:52:59 --> URI Class Initialized
INFO - 2021-03-26 04:52:59 --> Router Class Initialized
INFO - 2021-03-26 04:53:00 --> Output Class Initialized
INFO - 2021-03-26 04:53:00 --> Security Class Initialized
DEBUG - 2021-03-26 04:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 04:53:00 --> Input Class Initialized
INFO - 2021-03-26 04:53:00 --> Language Class Initialized
INFO - 2021-03-26 04:53:00 --> Language Class Initialized
INFO - 2021-03-26 04:53:00 --> Config Class Initialized
INFO - 2021-03-26 04:53:00 --> Loader Class Initialized
INFO - 2021-03-26 04:53:00 --> Helper loaded: url_helper
INFO - 2021-03-26 04:53:00 --> Helper loaded: file_helper
INFO - 2021-03-26 04:53:00 --> Helper loaded: form_helper
INFO - 2021-03-26 04:53:00 --> Helper loaded: my_helper
INFO - 2021-03-26 04:53:00 --> Database Driver Class Initialized
DEBUG - 2021-03-26 04:53:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 04:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 04:53:00 --> Controller Class Initialized
DEBUG - 2021-03-26 04:53:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2021-03-26 04:53:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-03-26 04:53:00 --> Final output sent to browser
DEBUG - 2021-03-26 04:53:00 --> Total execution time: 0.4116
INFO - 2021-03-26 04:53:00 --> Config Class Initialized
INFO - 2021-03-26 04:53:00 --> Hooks Class Initialized
DEBUG - 2021-03-26 04:53:00 --> UTF-8 Support Enabled
INFO - 2021-03-26 04:53:00 --> Utf8 Class Initialized
INFO - 2021-03-26 04:53:00 --> URI Class Initialized
INFO - 2021-03-26 04:53:00 --> Router Class Initialized
INFO - 2021-03-26 04:53:00 --> Output Class Initialized
INFO - 2021-03-26 04:53:00 --> Security Class Initialized
DEBUG - 2021-03-26 04:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 04:53:00 --> Input Class Initialized
INFO - 2021-03-26 04:53:00 --> Language Class Initialized
INFO - 2021-03-26 04:53:00 --> Language Class Initialized
INFO - 2021-03-26 04:53:00 --> Config Class Initialized
INFO - 2021-03-26 04:53:00 --> Loader Class Initialized
INFO - 2021-03-26 04:53:00 --> Helper loaded: url_helper
INFO - 2021-03-26 04:53:00 --> Helper loaded: file_helper
INFO - 2021-03-26 04:53:00 --> Helper loaded: form_helper
INFO - 2021-03-26 04:53:00 --> Helper loaded: my_helper
INFO - 2021-03-26 04:53:00 --> Database Driver Class Initialized
DEBUG - 2021-03-26 04:53:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 04:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 04:53:00 --> Controller Class Initialized
INFO - 2021-03-26 04:53:02 --> Config Class Initialized
INFO - 2021-03-26 04:53:02 --> Hooks Class Initialized
DEBUG - 2021-03-26 04:53:02 --> UTF-8 Support Enabled
INFO - 2021-03-26 04:53:02 --> Utf8 Class Initialized
INFO - 2021-03-26 04:53:02 --> URI Class Initialized
INFO - 2021-03-26 04:53:02 --> Router Class Initialized
INFO - 2021-03-26 04:53:02 --> Output Class Initialized
INFO - 2021-03-26 04:53:02 --> Security Class Initialized
DEBUG - 2021-03-26 04:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 04:53:02 --> Input Class Initialized
INFO - 2021-03-26 04:53:02 --> Language Class Initialized
INFO - 2021-03-26 04:53:02 --> Language Class Initialized
INFO - 2021-03-26 04:53:02 --> Config Class Initialized
INFO - 2021-03-26 04:53:02 --> Loader Class Initialized
INFO - 2021-03-26 04:53:02 --> Helper loaded: url_helper
INFO - 2021-03-26 04:53:02 --> Helper loaded: file_helper
INFO - 2021-03-26 04:53:02 --> Helper loaded: form_helper
INFO - 2021-03-26 04:53:02 --> Helper loaded: my_helper
INFO - 2021-03-26 04:53:02 --> Database Driver Class Initialized
DEBUG - 2021-03-26 04:53:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 04:53:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 04:53:02 --> Controller Class Initialized
INFO - 2021-03-26 04:53:02 --> Final output sent to browser
DEBUG - 2021-03-26 04:53:02 --> Total execution time: 0.3173
INFO - 2021-03-26 04:53:06 --> Config Class Initialized
INFO - 2021-03-26 04:53:06 --> Hooks Class Initialized
DEBUG - 2021-03-26 04:53:06 --> UTF-8 Support Enabled
INFO - 2021-03-26 04:53:06 --> Utf8 Class Initialized
INFO - 2021-03-26 04:53:06 --> URI Class Initialized
INFO - 2021-03-26 04:53:06 --> Router Class Initialized
INFO - 2021-03-26 04:53:06 --> Output Class Initialized
INFO - 2021-03-26 04:53:06 --> Security Class Initialized
DEBUG - 2021-03-26 04:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 04:53:06 --> Input Class Initialized
INFO - 2021-03-26 04:53:06 --> Language Class Initialized
INFO - 2021-03-26 04:53:06 --> Language Class Initialized
INFO - 2021-03-26 04:53:06 --> Config Class Initialized
INFO - 2021-03-26 04:53:06 --> Loader Class Initialized
INFO - 2021-03-26 04:53:06 --> Helper loaded: url_helper
INFO - 2021-03-26 04:53:06 --> Helper loaded: file_helper
INFO - 2021-03-26 04:53:06 --> Helper loaded: form_helper
INFO - 2021-03-26 04:53:06 --> Helper loaded: my_helper
INFO - 2021-03-26 04:53:06 --> Database Driver Class Initialized
DEBUG - 2021-03-26 04:53:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 04:53:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 04:53:06 --> Controller Class Initialized
INFO - 2021-03-26 04:53:06 --> Final output sent to browser
DEBUG - 2021-03-26 04:53:06 --> Total execution time: 0.3150
INFO - 2021-03-26 04:53:06 --> Config Class Initialized
INFO - 2021-03-26 04:53:06 --> Hooks Class Initialized
DEBUG - 2021-03-26 04:53:07 --> UTF-8 Support Enabled
INFO - 2021-03-26 04:53:07 --> Utf8 Class Initialized
INFO - 2021-03-26 04:53:07 --> URI Class Initialized
INFO - 2021-03-26 04:53:07 --> Router Class Initialized
INFO - 2021-03-26 04:53:07 --> Output Class Initialized
INFO - 2021-03-26 04:53:07 --> Security Class Initialized
DEBUG - 2021-03-26 04:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 04:53:07 --> Input Class Initialized
INFO - 2021-03-26 04:53:07 --> Language Class Initialized
INFO - 2021-03-26 04:53:07 --> Language Class Initialized
INFO - 2021-03-26 04:53:07 --> Config Class Initialized
INFO - 2021-03-26 04:53:07 --> Loader Class Initialized
INFO - 2021-03-26 04:53:07 --> Helper loaded: url_helper
INFO - 2021-03-26 04:53:07 --> Helper loaded: file_helper
INFO - 2021-03-26 04:53:07 --> Helper loaded: form_helper
INFO - 2021-03-26 04:53:07 --> Helper loaded: my_helper
INFO - 2021-03-26 04:53:07 --> Database Driver Class Initialized
DEBUG - 2021-03-26 04:53:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 04:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 04:53:07 --> Controller Class Initialized
INFO - 2021-03-26 04:53:09 --> Config Class Initialized
INFO - 2021-03-26 04:53:09 --> Hooks Class Initialized
DEBUG - 2021-03-26 04:53:09 --> UTF-8 Support Enabled
INFO - 2021-03-26 04:53:09 --> Utf8 Class Initialized
INFO - 2021-03-26 04:53:09 --> URI Class Initialized
INFO - 2021-03-26 04:53:09 --> Router Class Initialized
INFO - 2021-03-26 04:53:09 --> Output Class Initialized
INFO - 2021-03-26 04:53:09 --> Security Class Initialized
DEBUG - 2021-03-26 04:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 04:53:09 --> Input Class Initialized
INFO - 2021-03-26 04:53:09 --> Language Class Initialized
INFO - 2021-03-26 04:53:09 --> Language Class Initialized
INFO - 2021-03-26 04:53:09 --> Config Class Initialized
INFO - 2021-03-26 04:53:09 --> Loader Class Initialized
INFO - 2021-03-26 04:53:09 --> Helper loaded: url_helper
INFO - 2021-03-26 04:53:09 --> Helper loaded: file_helper
INFO - 2021-03-26 04:53:09 --> Helper loaded: form_helper
INFO - 2021-03-26 04:53:09 --> Helper loaded: my_helper
INFO - 2021-03-26 04:53:09 --> Database Driver Class Initialized
DEBUG - 2021-03-26 04:53:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 04:53:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 04:53:09 --> Controller Class Initialized
INFO - 2021-03-26 04:53:09 --> Final output sent to browser
DEBUG - 2021-03-26 04:53:10 --> Total execution time: 0.2917
INFO - 2021-03-26 04:53:12 --> Config Class Initialized
INFO - 2021-03-26 04:53:12 --> Hooks Class Initialized
DEBUG - 2021-03-26 04:53:12 --> UTF-8 Support Enabled
INFO - 2021-03-26 04:53:12 --> Utf8 Class Initialized
INFO - 2021-03-26 04:53:12 --> URI Class Initialized
INFO - 2021-03-26 04:53:12 --> Router Class Initialized
INFO - 2021-03-26 04:53:12 --> Output Class Initialized
INFO - 2021-03-26 04:53:12 --> Security Class Initialized
DEBUG - 2021-03-26 04:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 04:53:12 --> Input Class Initialized
INFO - 2021-03-26 04:53:12 --> Language Class Initialized
INFO - 2021-03-26 04:53:12 --> Language Class Initialized
INFO - 2021-03-26 04:53:12 --> Config Class Initialized
INFO - 2021-03-26 04:53:12 --> Loader Class Initialized
INFO - 2021-03-26 04:53:12 --> Helper loaded: url_helper
INFO - 2021-03-26 04:53:13 --> Helper loaded: file_helper
INFO - 2021-03-26 04:53:13 --> Helper loaded: form_helper
INFO - 2021-03-26 04:53:13 --> Helper loaded: my_helper
INFO - 2021-03-26 04:53:13 --> Database Driver Class Initialized
DEBUG - 2021-03-26 04:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 04:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 04:53:13 --> Controller Class Initialized
INFO - 2021-03-26 04:53:13 --> Final output sent to browser
DEBUG - 2021-03-26 04:53:13 --> Total execution time: 0.3471
INFO - 2021-03-26 04:53:13 --> Config Class Initialized
INFO - 2021-03-26 04:53:13 --> Hooks Class Initialized
DEBUG - 2021-03-26 04:53:13 --> UTF-8 Support Enabled
INFO - 2021-03-26 04:53:13 --> Utf8 Class Initialized
INFO - 2021-03-26 04:53:13 --> URI Class Initialized
INFO - 2021-03-26 04:53:13 --> Router Class Initialized
INFO - 2021-03-26 04:53:13 --> Output Class Initialized
INFO - 2021-03-26 04:53:13 --> Security Class Initialized
DEBUG - 2021-03-26 04:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 04:53:13 --> Input Class Initialized
INFO - 2021-03-26 04:53:13 --> Language Class Initialized
INFO - 2021-03-26 04:53:13 --> Language Class Initialized
INFO - 2021-03-26 04:53:13 --> Config Class Initialized
INFO - 2021-03-26 04:53:13 --> Loader Class Initialized
INFO - 2021-03-26 04:53:13 --> Helper loaded: url_helper
INFO - 2021-03-26 04:53:13 --> Helper loaded: file_helper
INFO - 2021-03-26 04:53:13 --> Helper loaded: form_helper
INFO - 2021-03-26 04:53:13 --> Helper loaded: my_helper
INFO - 2021-03-26 04:53:13 --> Database Driver Class Initialized
DEBUG - 2021-03-26 04:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 04:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 04:53:13 --> Controller Class Initialized
INFO - 2021-03-26 04:54:02 --> Config Class Initialized
INFO - 2021-03-26 04:54:02 --> Hooks Class Initialized
DEBUG - 2021-03-26 04:54:02 --> UTF-8 Support Enabled
INFO - 2021-03-26 04:54:02 --> Utf8 Class Initialized
INFO - 2021-03-26 04:54:02 --> URI Class Initialized
INFO - 2021-03-26 04:54:02 --> Router Class Initialized
INFO - 2021-03-26 04:54:02 --> Output Class Initialized
INFO - 2021-03-26 04:54:02 --> Security Class Initialized
DEBUG - 2021-03-26 04:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 04:54:02 --> Input Class Initialized
INFO - 2021-03-26 04:54:02 --> Language Class Initialized
INFO - 2021-03-26 04:54:02 --> Language Class Initialized
INFO - 2021-03-26 04:54:02 --> Config Class Initialized
INFO - 2021-03-26 04:54:02 --> Loader Class Initialized
INFO - 2021-03-26 04:54:03 --> Helper loaded: url_helper
INFO - 2021-03-26 04:54:03 --> Helper loaded: file_helper
INFO - 2021-03-26 04:54:03 --> Helper loaded: form_helper
INFO - 2021-03-26 04:54:03 --> Helper loaded: my_helper
INFO - 2021-03-26 04:54:03 --> Database Driver Class Initialized
DEBUG - 2021-03-26 04:54:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 04:54:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 04:54:03 --> Controller Class Initialized
DEBUG - 2021-03-26 04:54:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2021-03-26 04:54:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-03-26 04:54:03 --> Final output sent to browser
DEBUG - 2021-03-26 04:54:03 --> Total execution time: 0.3104
INFO - 2021-03-26 04:54:03 --> Config Class Initialized
INFO - 2021-03-26 04:54:03 --> Hooks Class Initialized
DEBUG - 2021-03-26 04:54:03 --> UTF-8 Support Enabled
INFO - 2021-03-26 04:54:03 --> Utf8 Class Initialized
INFO - 2021-03-26 04:54:03 --> URI Class Initialized
INFO - 2021-03-26 04:54:03 --> Router Class Initialized
INFO - 2021-03-26 04:54:03 --> Output Class Initialized
INFO - 2021-03-26 04:54:03 --> Security Class Initialized
DEBUG - 2021-03-26 04:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 04:54:03 --> Input Class Initialized
INFO - 2021-03-26 04:54:03 --> Language Class Initialized
INFO - 2021-03-26 04:54:03 --> Language Class Initialized
INFO - 2021-03-26 04:54:03 --> Config Class Initialized
INFO - 2021-03-26 04:54:03 --> Loader Class Initialized
INFO - 2021-03-26 04:54:03 --> Helper loaded: url_helper
INFO - 2021-03-26 04:54:03 --> Helper loaded: file_helper
INFO - 2021-03-26 04:54:03 --> Helper loaded: form_helper
INFO - 2021-03-26 04:54:03 --> Helper loaded: my_helper
INFO - 2021-03-26 04:54:03 --> Database Driver Class Initialized
DEBUG - 2021-03-26 04:54:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 04:54:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 04:54:03 --> Controller Class Initialized
INFO - 2021-03-26 04:54:04 --> Config Class Initialized
INFO - 2021-03-26 04:54:04 --> Hooks Class Initialized
DEBUG - 2021-03-26 04:54:04 --> UTF-8 Support Enabled
INFO - 2021-03-26 04:54:04 --> Utf8 Class Initialized
INFO - 2021-03-26 04:54:04 --> URI Class Initialized
INFO - 2021-03-26 04:54:04 --> Router Class Initialized
INFO - 2021-03-26 04:54:04 --> Output Class Initialized
INFO - 2021-03-26 04:54:04 --> Security Class Initialized
DEBUG - 2021-03-26 04:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 04:54:04 --> Input Class Initialized
INFO - 2021-03-26 04:54:04 --> Language Class Initialized
INFO - 2021-03-26 04:54:04 --> Language Class Initialized
INFO - 2021-03-26 04:54:04 --> Config Class Initialized
INFO - 2021-03-26 04:54:04 --> Loader Class Initialized
INFO - 2021-03-26 04:54:04 --> Helper loaded: url_helper
INFO - 2021-03-26 04:54:04 --> Helper loaded: file_helper
INFO - 2021-03-26 04:54:04 --> Helper loaded: form_helper
INFO - 2021-03-26 04:54:04 --> Helper loaded: my_helper
INFO - 2021-03-26 04:54:04 --> Database Driver Class Initialized
DEBUG - 2021-03-26 04:54:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 04:54:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 04:54:04 --> Controller Class Initialized
INFO - 2021-03-26 04:54:04 --> Final output sent to browser
DEBUG - 2021-03-26 04:54:04 --> Total execution time: 0.3029
INFO - 2021-03-26 04:54:26 --> Config Class Initialized
INFO - 2021-03-26 04:54:26 --> Hooks Class Initialized
DEBUG - 2021-03-26 04:54:26 --> UTF-8 Support Enabled
INFO - 2021-03-26 04:54:26 --> Utf8 Class Initialized
INFO - 2021-03-26 04:54:26 --> URI Class Initialized
INFO - 2021-03-26 04:54:26 --> Router Class Initialized
INFO - 2021-03-26 04:54:26 --> Output Class Initialized
INFO - 2021-03-26 04:54:26 --> Security Class Initialized
DEBUG - 2021-03-26 04:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 04:54:26 --> Input Class Initialized
INFO - 2021-03-26 04:54:26 --> Language Class Initialized
INFO - 2021-03-26 04:54:26 --> Language Class Initialized
INFO - 2021-03-26 04:54:26 --> Config Class Initialized
INFO - 2021-03-26 04:54:26 --> Loader Class Initialized
INFO - 2021-03-26 04:54:26 --> Helper loaded: url_helper
INFO - 2021-03-26 04:54:26 --> Helper loaded: file_helper
INFO - 2021-03-26 04:54:26 --> Helper loaded: form_helper
INFO - 2021-03-26 04:54:26 --> Helper loaded: my_helper
INFO - 2021-03-26 04:54:26 --> Database Driver Class Initialized
DEBUG - 2021-03-26 04:54:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 04:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 04:54:26 --> Controller Class Initialized
DEBUG - 2021-03-26 04:54:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2021-03-26 04:54:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-03-26 04:54:26 --> Final output sent to browser
DEBUG - 2021-03-26 04:54:26 --> Total execution time: 0.4068
INFO - 2021-03-26 04:54:26 --> Config Class Initialized
INFO - 2021-03-26 04:54:26 --> Hooks Class Initialized
DEBUG - 2021-03-26 04:54:26 --> UTF-8 Support Enabled
INFO - 2021-03-26 04:54:26 --> Utf8 Class Initialized
INFO - 2021-03-26 04:54:26 --> URI Class Initialized
INFO - 2021-03-26 04:54:26 --> Router Class Initialized
INFO - 2021-03-26 04:54:26 --> Output Class Initialized
INFO - 2021-03-26 04:54:26 --> Security Class Initialized
DEBUG - 2021-03-26 04:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 04:54:26 --> Input Class Initialized
INFO - 2021-03-26 04:54:26 --> Language Class Initialized
INFO - 2021-03-26 04:54:26 --> Language Class Initialized
INFO - 2021-03-26 04:54:26 --> Config Class Initialized
INFO - 2021-03-26 04:54:26 --> Loader Class Initialized
INFO - 2021-03-26 04:54:26 --> Helper loaded: url_helper
INFO - 2021-03-26 04:54:26 --> Helper loaded: file_helper
INFO - 2021-03-26 04:54:26 --> Helper loaded: form_helper
INFO - 2021-03-26 04:54:26 --> Helper loaded: my_helper
INFO - 2021-03-26 04:54:26 --> Database Driver Class Initialized
DEBUG - 2021-03-26 04:54:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 04:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 04:54:26 --> Controller Class Initialized
INFO - 2021-03-26 04:54:27 --> Config Class Initialized
INFO - 2021-03-26 04:54:27 --> Hooks Class Initialized
DEBUG - 2021-03-26 04:54:27 --> UTF-8 Support Enabled
INFO - 2021-03-26 04:54:27 --> Utf8 Class Initialized
INFO - 2021-03-26 04:54:27 --> URI Class Initialized
INFO - 2021-03-26 04:54:27 --> Router Class Initialized
INFO - 2021-03-26 04:54:27 --> Output Class Initialized
INFO - 2021-03-26 04:54:27 --> Security Class Initialized
DEBUG - 2021-03-26 04:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 04:54:27 --> Input Class Initialized
INFO - 2021-03-26 04:54:27 --> Language Class Initialized
INFO - 2021-03-26 04:54:27 --> Language Class Initialized
INFO - 2021-03-26 04:54:27 --> Config Class Initialized
INFO - 2021-03-26 04:54:27 --> Loader Class Initialized
INFO - 2021-03-26 04:54:27 --> Helper loaded: url_helper
INFO - 2021-03-26 04:54:27 --> Helper loaded: file_helper
INFO - 2021-03-26 04:54:27 --> Helper loaded: form_helper
INFO - 2021-03-26 04:54:27 --> Helper loaded: my_helper
INFO - 2021-03-26 04:54:27 --> Database Driver Class Initialized
DEBUG - 2021-03-26 04:54:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 04:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 04:54:27 --> Controller Class Initialized
INFO - 2021-03-26 04:54:27 --> Final output sent to browser
DEBUG - 2021-03-26 04:54:27 --> Total execution time: 0.2958
INFO - 2021-03-26 04:55:31 --> Config Class Initialized
INFO - 2021-03-26 04:55:31 --> Hooks Class Initialized
DEBUG - 2021-03-26 04:55:31 --> UTF-8 Support Enabled
INFO - 2021-03-26 04:55:31 --> Utf8 Class Initialized
INFO - 2021-03-26 04:55:31 --> URI Class Initialized
INFO - 2021-03-26 04:55:31 --> Router Class Initialized
INFO - 2021-03-26 04:55:31 --> Output Class Initialized
INFO - 2021-03-26 04:55:31 --> Security Class Initialized
DEBUG - 2021-03-26 04:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 04:55:31 --> Input Class Initialized
INFO - 2021-03-26 04:55:31 --> Language Class Initialized
INFO - 2021-03-26 04:55:31 --> Language Class Initialized
INFO - 2021-03-26 04:55:31 --> Config Class Initialized
INFO - 2021-03-26 04:55:31 --> Loader Class Initialized
INFO - 2021-03-26 04:55:31 --> Helper loaded: url_helper
INFO - 2021-03-26 04:55:31 --> Helper loaded: file_helper
INFO - 2021-03-26 04:55:31 --> Helper loaded: form_helper
INFO - 2021-03-26 04:55:31 --> Helper loaded: my_helper
INFO - 2021-03-26 04:55:31 --> Database Driver Class Initialized
DEBUG - 2021-03-26 04:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 04:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 04:55:31 --> Controller Class Initialized
INFO - 2021-03-26 04:55:31 --> Final output sent to browser
DEBUG - 2021-03-26 04:55:31 --> Total execution time: 0.3272
INFO - 2021-03-26 04:55:33 --> Config Class Initialized
INFO - 2021-03-26 04:55:33 --> Hooks Class Initialized
DEBUG - 2021-03-26 04:55:33 --> UTF-8 Support Enabled
INFO - 2021-03-26 04:55:33 --> Utf8 Class Initialized
INFO - 2021-03-26 04:55:33 --> URI Class Initialized
INFO - 2021-03-26 04:55:33 --> Router Class Initialized
INFO - 2021-03-26 04:55:33 --> Output Class Initialized
INFO - 2021-03-26 04:55:33 --> Security Class Initialized
DEBUG - 2021-03-26 04:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 04:55:33 --> Input Class Initialized
INFO - 2021-03-26 04:55:33 --> Language Class Initialized
INFO - 2021-03-26 04:55:33 --> Language Class Initialized
INFO - 2021-03-26 04:55:33 --> Config Class Initialized
INFO - 2021-03-26 04:55:33 --> Loader Class Initialized
INFO - 2021-03-26 04:55:33 --> Helper loaded: url_helper
INFO - 2021-03-26 04:55:33 --> Helper loaded: file_helper
INFO - 2021-03-26 04:55:33 --> Helper loaded: form_helper
INFO - 2021-03-26 04:55:33 --> Helper loaded: my_helper
INFO - 2021-03-26 04:55:33 --> Database Driver Class Initialized
DEBUG - 2021-03-26 04:55:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 04:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 04:55:33 --> Controller Class Initialized
INFO - 2021-03-26 04:55:33 --> Final output sent to browser
DEBUG - 2021-03-26 04:55:33 --> Total execution time: 0.3047
INFO - 2021-03-26 04:55:33 --> Config Class Initialized
INFO - 2021-03-26 04:55:33 --> Hooks Class Initialized
DEBUG - 2021-03-26 04:55:33 --> UTF-8 Support Enabled
INFO - 2021-03-26 04:55:33 --> Utf8 Class Initialized
INFO - 2021-03-26 04:55:33 --> URI Class Initialized
INFO - 2021-03-26 04:55:33 --> Router Class Initialized
INFO - 2021-03-26 04:55:33 --> Output Class Initialized
INFO - 2021-03-26 04:55:33 --> Security Class Initialized
DEBUG - 2021-03-26 04:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 04:55:33 --> Input Class Initialized
INFO - 2021-03-26 04:55:33 --> Language Class Initialized
INFO - 2021-03-26 04:55:33 --> Language Class Initialized
INFO - 2021-03-26 04:55:33 --> Config Class Initialized
INFO - 2021-03-26 04:55:33 --> Loader Class Initialized
INFO - 2021-03-26 04:55:33 --> Helper loaded: url_helper
INFO - 2021-03-26 04:55:33 --> Helper loaded: file_helper
INFO - 2021-03-26 04:55:33 --> Helper loaded: form_helper
INFO - 2021-03-26 04:55:33 --> Helper loaded: my_helper
INFO - 2021-03-26 04:55:33 --> Database Driver Class Initialized
DEBUG - 2021-03-26 04:55:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 04:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 04:55:34 --> Controller Class Initialized
INFO - 2021-03-26 04:55:47 --> Config Class Initialized
INFO - 2021-03-26 04:55:47 --> Hooks Class Initialized
DEBUG - 2021-03-26 04:55:47 --> UTF-8 Support Enabled
INFO - 2021-03-26 04:55:47 --> Utf8 Class Initialized
INFO - 2021-03-26 04:55:47 --> URI Class Initialized
INFO - 2021-03-26 04:55:47 --> Router Class Initialized
INFO - 2021-03-26 04:55:47 --> Output Class Initialized
INFO - 2021-03-26 04:55:48 --> Security Class Initialized
DEBUG - 2021-03-26 04:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 04:55:48 --> Input Class Initialized
INFO - 2021-03-26 04:55:48 --> Language Class Initialized
INFO - 2021-03-26 04:55:48 --> Language Class Initialized
INFO - 2021-03-26 04:55:48 --> Config Class Initialized
INFO - 2021-03-26 04:55:48 --> Loader Class Initialized
INFO - 2021-03-26 04:55:48 --> Helper loaded: url_helper
INFO - 2021-03-26 04:55:48 --> Helper loaded: file_helper
INFO - 2021-03-26 04:55:48 --> Helper loaded: form_helper
INFO - 2021-03-26 04:55:48 --> Helper loaded: my_helper
INFO - 2021-03-26 04:55:48 --> Database Driver Class Initialized
DEBUG - 2021-03-26 04:55:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 04:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 04:55:48 --> Controller Class Initialized
INFO - 2021-03-26 04:55:48 --> Final output sent to browser
DEBUG - 2021-03-26 04:55:48 --> Total execution time: 0.3367
INFO - 2021-03-26 04:55:50 --> Config Class Initialized
INFO - 2021-03-26 04:55:50 --> Hooks Class Initialized
DEBUG - 2021-03-26 04:55:50 --> UTF-8 Support Enabled
INFO - 2021-03-26 04:55:50 --> Utf8 Class Initialized
INFO - 2021-03-26 04:55:50 --> URI Class Initialized
INFO - 2021-03-26 04:55:50 --> Router Class Initialized
INFO - 2021-03-26 04:55:50 --> Output Class Initialized
INFO - 2021-03-26 04:55:50 --> Security Class Initialized
DEBUG - 2021-03-26 04:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 04:55:50 --> Input Class Initialized
INFO - 2021-03-26 04:55:50 --> Language Class Initialized
INFO - 2021-03-26 04:55:50 --> Language Class Initialized
INFO - 2021-03-26 04:55:50 --> Config Class Initialized
INFO - 2021-03-26 04:55:50 --> Loader Class Initialized
INFO - 2021-03-26 04:55:50 --> Helper loaded: url_helper
INFO - 2021-03-26 04:55:50 --> Helper loaded: file_helper
INFO - 2021-03-26 04:55:50 --> Helper loaded: form_helper
INFO - 2021-03-26 04:55:50 --> Helper loaded: my_helper
INFO - 2021-03-26 04:55:50 --> Database Driver Class Initialized
DEBUG - 2021-03-26 04:55:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 04:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 04:55:51 --> Controller Class Initialized
INFO - 2021-03-26 04:55:51 --> Final output sent to browser
DEBUG - 2021-03-26 04:55:51 --> Total execution time: 0.3598
INFO - 2021-03-26 04:55:51 --> Config Class Initialized
INFO - 2021-03-26 04:55:51 --> Hooks Class Initialized
DEBUG - 2021-03-26 04:55:51 --> UTF-8 Support Enabled
INFO - 2021-03-26 04:55:51 --> Utf8 Class Initialized
INFO - 2021-03-26 04:55:51 --> URI Class Initialized
INFO - 2021-03-26 04:55:51 --> Router Class Initialized
INFO - 2021-03-26 04:55:51 --> Output Class Initialized
INFO - 2021-03-26 04:55:51 --> Security Class Initialized
DEBUG - 2021-03-26 04:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 04:55:51 --> Input Class Initialized
INFO - 2021-03-26 04:55:51 --> Language Class Initialized
INFO - 2021-03-26 04:55:51 --> Language Class Initialized
INFO - 2021-03-26 04:55:51 --> Config Class Initialized
INFO - 2021-03-26 04:55:51 --> Loader Class Initialized
INFO - 2021-03-26 04:55:51 --> Helper loaded: url_helper
INFO - 2021-03-26 04:55:51 --> Helper loaded: file_helper
INFO - 2021-03-26 04:55:51 --> Helper loaded: form_helper
INFO - 2021-03-26 04:55:51 --> Helper loaded: my_helper
INFO - 2021-03-26 04:55:51 --> Database Driver Class Initialized
DEBUG - 2021-03-26 04:55:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 04:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 04:55:51 --> Controller Class Initialized
INFO - 2021-03-26 05:21:29 --> Config Class Initialized
INFO - 2021-03-26 05:21:29 --> Hooks Class Initialized
DEBUG - 2021-03-26 05:21:29 --> UTF-8 Support Enabled
INFO - 2021-03-26 05:21:29 --> Utf8 Class Initialized
INFO - 2021-03-26 05:21:29 --> URI Class Initialized
INFO - 2021-03-26 05:21:29 --> Router Class Initialized
INFO - 2021-03-26 05:21:29 --> Output Class Initialized
INFO - 2021-03-26 05:21:29 --> Security Class Initialized
DEBUG - 2021-03-26 05:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 05:21:29 --> Input Class Initialized
INFO - 2021-03-26 05:21:29 --> Language Class Initialized
INFO - 2021-03-26 05:21:29 --> Language Class Initialized
INFO - 2021-03-26 05:21:29 --> Config Class Initialized
INFO - 2021-03-26 05:21:29 --> Loader Class Initialized
INFO - 2021-03-26 05:21:29 --> Helper loaded: url_helper
INFO - 2021-03-26 05:21:29 --> Helper loaded: file_helper
INFO - 2021-03-26 05:21:29 --> Helper loaded: form_helper
INFO - 2021-03-26 05:21:29 --> Helper loaded: my_helper
INFO - 2021-03-26 05:21:29 --> Database Driver Class Initialized
DEBUG - 2021-03-26 05:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 05:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 05:21:29 --> Controller Class Initialized
INFO - 2021-03-26 05:21:29 --> Final output sent to browser
DEBUG - 2021-03-26 05:21:29 --> Total execution time: 0.3078
INFO - 2021-03-26 05:21:48 --> Config Class Initialized
INFO - 2021-03-26 05:21:48 --> Hooks Class Initialized
DEBUG - 2021-03-26 05:21:48 --> UTF-8 Support Enabled
INFO - 2021-03-26 05:21:48 --> Utf8 Class Initialized
INFO - 2021-03-26 05:21:48 --> URI Class Initialized
INFO - 2021-03-26 05:21:48 --> Router Class Initialized
INFO - 2021-03-26 05:21:48 --> Output Class Initialized
INFO - 2021-03-26 05:21:48 --> Security Class Initialized
DEBUG - 2021-03-26 05:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 05:21:48 --> Input Class Initialized
INFO - 2021-03-26 05:21:48 --> Language Class Initialized
INFO - 2021-03-26 05:21:48 --> Language Class Initialized
INFO - 2021-03-26 05:21:48 --> Config Class Initialized
INFO - 2021-03-26 05:21:48 --> Loader Class Initialized
INFO - 2021-03-26 05:21:48 --> Helper loaded: url_helper
INFO - 2021-03-26 05:21:48 --> Helper loaded: file_helper
INFO - 2021-03-26 05:21:48 --> Helper loaded: form_helper
INFO - 2021-03-26 05:21:48 --> Helper loaded: my_helper
INFO - 2021-03-26 05:21:48 --> Database Driver Class Initialized
DEBUG - 2021-03-26 05:21:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 05:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 05:21:48 --> Controller Class Initialized
DEBUG - 2021-03-26 05:21:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2021-03-26 05:21:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-03-26 05:21:48 --> Final output sent to browser
DEBUG - 2021-03-26 05:21:48 --> Total execution time: 0.2882
INFO - 2021-03-26 05:21:49 --> Config Class Initialized
INFO - 2021-03-26 05:21:49 --> Hooks Class Initialized
DEBUG - 2021-03-26 05:21:49 --> UTF-8 Support Enabled
INFO - 2021-03-26 05:21:49 --> Utf8 Class Initialized
INFO - 2021-03-26 05:21:49 --> URI Class Initialized
INFO - 2021-03-26 05:21:49 --> Router Class Initialized
INFO - 2021-03-26 05:21:49 --> Output Class Initialized
INFO - 2021-03-26 05:21:49 --> Security Class Initialized
DEBUG - 2021-03-26 05:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 05:21:49 --> Input Class Initialized
INFO - 2021-03-26 05:21:49 --> Language Class Initialized
INFO - 2021-03-26 05:21:49 --> Language Class Initialized
INFO - 2021-03-26 05:21:49 --> Config Class Initialized
INFO - 2021-03-26 05:21:49 --> Loader Class Initialized
INFO - 2021-03-26 05:21:49 --> Helper loaded: url_helper
INFO - 2021-03-26 05:21:49 --> Helper loaded: file_helper
INFO - 2021-03-26 05:21:49 --> Helper loaded: form_helper
INFO - 2021-03-26 05:21:49 --> Helper loaded: my_helper
INFO - 2021-03-26 05:21:49 --> Database Driver Class Initialized
DEBUG - 2021-03-26 05:21:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 05:21:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 05:21:49 --> Controller Class Initialized
INFO - 2021-03-26 05:21:52 --> Config Class Initialized
INFO - 2021-03-26 05:21:52 --> Hooks Class Initialized
DEBUG - 2021-03-26 05:21:52 --> UTF-8 Support Enabled
INFO - 2021-03-26 05:21:52 --> Utf8 Class Initialized
INFO - 2021-03-26 05:21:52 --> URI Class Initialized
INFO - 2021-03-26 05:21:52 --> Router Class Initialized
INFO - 2021-03-26 05:21:52 --> Output Class Initialized
INFO - 2021-03-26 05:21:52 --> Security Class Initialized
DEBUG - 2021-03-26 05:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 05:21:52 --> Input Class Initialized
INFO - 2021-03-26 05:21:52 --> Language Class Initialized
INFO - 2021-03-26 05:21:52 --> Language Class Initialized
INFO - 2021-03-26 05:21:52 --> Config Class Initialized
INFO - 2021-03-26 05:21:52 --> Loader Class Initialized
INFO - 2021-03-26 05:21:52 --> Helper loaded: url_helper
INFO - 2021-03-26 05:21:52 --> Helper loaded: file_helper
INFO - 2021-03-26 05:21:52 --> Helper loaded: form_helper
INFO - 2021-03-26 05:21:52 --> Helper loaded: my_helper
INFO - 2021-03-26 05:21:52 --> Database Driver Class Initialized
DEBUG - 2021-03-26 05:21:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 05:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 05:21:52 --> Controller Class Initialized
INFO - 2021-03-26 05:21:52 --> Final output sent to browser
DEBUG - 2021-03-26 05:21:52 --> Total execution time: 0.2715
INFO - 2021-03-26 05:21:56 --> Config Class Initialized
INFO - 2021-03-26 05:21:56 --> Hooks Class Initialized
DEBUG - 2021-03-26 05:21:56 --> UTF-8 Support Enabled
INFO - 2021-03-26 05:21:56 --> Utf8 Class Initialized
INFO - 2021-03-26 05:21:56 --> URI Class Initialized
INFO - 2021-03-26 05:21:56 --> Router Class Initialized
INFO - 2021-03-26 05:21:56 --> Output Class Initialized
INFO - 2021-03-26 05:21:56 --> Security Class Initialized
DEBUG - 2021-03-26 05:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 05:21:56 --> Input Class Initialized
INFO - 2021-03-26 05:21:56 --> Language Class Initialized
INFO - 2021-03-26 05:21:56 --> Language Class Initialized
INFO - 2021-03-26 05:21:56 --> Config Class Initialized
INFO - 2021-03-26 05:21:56 --> Loader Class Initialized
INFO - 2021-03-26 05:21:56 --> Helper loaded: url_helper
INFO - 2021-03-26 05:21:56 --> Helper loaded: file_helper
INFO - 2021-03-26 05:21:56 --> Helper loaded: form_helper
INFO - 2021-03-26 05:21:56 --> Helper loaded: my_helper
INFO - 2021-03-26 05:21:56 --> Database Driver Class Initialized
DEBUG - 2021-03-26 05:21:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 05:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 05:21:56 --> Controller Class Initialized
INFO - 2021-03-26 05:21:56 --> Final output sent to browser
DEBUG - 2021-03-26 05:21:56 --> Total execution time: 0.3153
INFO - 2021-03-26 05:21:56 --> Config Class Initialized
INFO - 2021-03-26 05:21:56 --> Hooks Class Initialized
DEBUG - 2021-03-26 05:21:56 --> UTF-8 Support Enabled
INFO - 2021-03-26 05:21:56 --> Utf8 Class Initialized
INFO - 2021-03-26 05:21:56 --> URI Class Initialized
INFO - 2021-03-26 05:21:56 --> Router Class Initialized
INFO - 2021-03-26 05:21:56 --> Output Class Initialized
INFO - 2021-03-26 05:21:56 --> Security Class Initialized
DEBUG - 2021-03-26 05:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 05:21:56 --> Input Class Initialized
INFO - 2021-03-26 05:21:56 --> Language Class Initialized
INFO - 2021-03-26 05:21:56 --> Language Class Initialized
INFO - 2021-03-26 05:21:56 --> Config Class Initialized
INFO - 2021-03-26 05:21:56 --> Loader Class Initialized
INFO - 2021-03-26 05:21:56 --> Helper loaded: url_helper
INFO - 2021-03-26 05:21:56 --> Helper loaded: file_helper
INFO - 2021-03-26 05:21:56 --> Helper loaded: form_helper
INFO - 2021-03-26 05:21:56 --> Helper loaded: my_helper
INFO - 2021-03-26 05:21:56 --> Database Driver Class Initialized
DEBUG - 2021-03-26 05:21:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 05:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 05:21:56 --> Controller Class Initialized
INFO - 2021-03-26 05:22:06 --> Config Class Initialized
INFO - 2021-03-26 05:22:06 --> Hooks Class Initialized
DEBUG - 2021-03-26 05:22:06 --> UTF-8 Support Enabled
INFO - 2021-03-26 05:22:06 --> Utf8 Class Initialized
INFO - 2021-03-26 05:22:06 --> URI Class Initialized
INFO - 2021-03-26 05:22:06 --> Router Class Initialized
INFO - 2021-03-26 05:22:06 --> Output Class Initialized
INFO - 2021-03-26 05:22:06 --> Security Class Initialized
DEBUG - 2021-03-26 05:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 05:22:06 --> Input Class Initialized
INFO - 2021-03-26 05:22:06 --> Language Class Initialized
INFO - 2021-03-26 05:22:06 --> Language Class Initialized
INFO - 2021-03-26 05:22:06 --> Config Class Initialized
INFO - 2021-03-26 05:22:06 --> Loader Class Initialized
INFO - 2021-03-26 05:22:06 --> Helper loaded: url_helper
INFO - 2021-03-26 05:22:06 --> Helper loaded: file_helper
INFO - 2021-03-26 05:22:06 --> Helper loaded: form_helper
INFO - 2021-03-26 05:22:06 --> Helper loaded: my_helper
INFO - 2021-03-26 05:22:06 --> Database Driver Class Initialized
DEBUG - 2021-03-26 05:22:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 05:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 05:22:06 --> Controller Class Initialized
DEBUG - 2021-03-26 05:22:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2021-03-26 05:22:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-03-26 05:22:06 --> Final output sent to browser
DEBUG - 2021-03-26 05:22:06 --> Total execution time: 0.3189
INFO - 2021-03-26 05:22:07 --> Config Class Initialized
INFO - 2021-03-26 05:22:07 --> Hooks Class Initialized
DEBUG - 2021-03-26 05:22:07 --> UTF-8 Support Enabled
INFO - 2021-03-26 05:22:07 --> Utf8 Class Initialized
INFO - 2021-03-26 05:22:07 --> URI Class Initialized
INFO - 2021-03-26 05:22:07 --> Router Class Initialized
INFO - 2021-03-26 05:22:07 --> Output Class Initialized
INFO - 2021-03-26 05:22:07 --> Security Class Initialized
DEBUG - 2021-03-26 05:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 05:22:07 --> Input Class Initialized
INFO - 2021-03-26 05:22:07 --> Language Class Initialized
INFO - 2021-03-26 05:22:07 --> Language Class Initialized
INFO - 2021-03-26 05:22:07 --> Config Class Initialized
INFO - 2021-03-26 05:22:07 --> Loader Class Initialized
INFO - 2021-03-26 05:22:07 --> Helper loaded: url_helper
INFO - 2021-03-26 05:22:07 --> Helper loaded: file_helper
INFO - 2021-03-26 05:22:07 --> Helper loaded: form_helper
INFO - 2021-03-26 05:22:07 --> Helper loaded: my_helper
INFO - 2021-03-26 05:22:07 --> Database Driver Class Initialized
DEBUG - 2021-03-26 05:22:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 05:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 05:22:07 --> Controller Class Initialized
INFO - 2021-03-26 05:22:07 --> Config Class Initialized
INFO - 2021-03-26 05:22:07 --> Hooks Class Initialized
DEBUG - 2021-03-26 05:22:07 --> UTF-8 Support Enabled
INFO - 2021-03-26 05:22:07 --> Utf8 Class Initialized
INFO - 2021-03-26 05:22:07 --> URI Class Initialized
INFO - 2021-03-26 05:22:07 --> Router Class Initialized
INFO - 2021-03-26 05:22:07 --> Output Class Initialized
INFO - 2021-03-26 05:22:07 --> Security Class Initialized
DEBUG - 2021-03-26 05:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 05:22:07 --> Input Class Initialized
INFO - 2021-03-26 05:22:07 --> Language Class Initialized
INFO - 2021-03-26 05:22:07 --> Language Class Initialized
INFO - 2021-03-26 05:22:07 --> Config Class Initialized
INFO - 2021-03-26 05:22:07 --> Loader Class Initialized
INFO - 2021-03-26 05:22:07 --> Helper loaded: url_helper
INFO - 2021-03-26 05:22:07 --> Helper loaded: file_helper
INFO - 2021-03-26 05:22:07 --> Helper loaded: form_helper
INFO - 2021-03-26 05:22:07 --> Helper loaded: my_helper
INFO - 2021-03-26 05:22:07 --> Database Driver Class Initialized
DEBUG - 2021-03-26 05:22:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 05:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 05:22:08 --> Controller Class Initialized
INFO - 2021-03-26 05:22:08 --> Final output sent to browser
DEBUG - 2021-03-26 05:22:08 --> Total execution time: 0.3129
INFO - 2021-03-26 05:22:23 --> Config Class Initialized
INFO - 2021-03-26 05:22:23 --> Hooks Class Initialized
DEBUG - 2021-03-26 05:22:23 --> UTF-8 Support Enabled
INFO - 2021-03-26 05:22:23 --> Utf8 Class Initialized
INFO - 2021-03-26 05:22:23 --> URI Class Initialized
INFO - 2021-03-26 05:22:23 --> Router Class Initialized
INFO - 2021-03-26 05:22:23 --> Output Class Initialized
INFO - 2021-03-26 05:22:23 --> Security Class Initialized
DEBUG - 2021-03-26 05:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 05:22:23 --> Input Class Initialized
INFO - 2021-03-26 05:22:23 --> Language Class Initialized
INFO - 2021-03-26 05:22:23 --> Language Class Initialized
INFO - 2021-03-26 05:22:23 --> Config Class Initialized
INFO - 2021-03-26 05:22:23 --> Loader Class Initialized
INFO - 2021-03-26 05:22:23 --> Helper loaded: url_helper
INFO - 2021-03-26 05:22:23 --> Helper loaded: file_helper
INFO - 2021-03-26 05:22:23 --> Helper loaded: form_helper
INFO - 2021-03-26 05:22:23 --> Helper loaded: my_helper
INFO - 2021-03-26 05:22:23 --> Database Driver Class Initialized
DEBUG - 2021-03-26 05:22:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 05:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 05:22:23 --> Controller Class Initialized
DEBUG - 2021-03-26 05:22:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2021-03-26 05:22:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-03-26 05:22:24 --> Final output sent to browser
DEBUG - 2021-03-26 05:22:24 --> Total execution time: 0.3026
INFO - 2021-03-26 05:22:24 --> Config Class Initialized
INFO - 2021-03-26 05:22:24 --> Hooks Class Initialized
DEBUG - 2021-03-26 05:22:24 --> UTF-8 Support Enabled
INFO - 2021-03-26 05:22:24 --> Utf8 Class Initialized
INFO - 2021-03-26 05:22:24 --> URI Class Initialized
INFO - 2021-03-26 05:22:24 --> Router Class Initialized
INFO - 2021-03-26 05:22:24 --> Output Class Initialized
INFO - 2021-03-26 05:22:24 --> Security Class Initialized
DEBUG - 2021-03-26 05:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 05:22:24 --> Input Class Initialized
INFO - 2021-03-26 05:22:24 --> Language Class Initialized
INFO - 2021-03-26 05:22:24 --> Language Class Initialized
INFO - 2021-03-26 05:22:24 --> Config Class Initialized
INFO - 2021-03-26 05:22:24 --> Loader Class Initialized
INFO - 2021-03-26 05:22:24 --> Helper loaded: url_helper
INFO - 2021-03-26 05:22:24 --> Helper loaded: file_helper
INFO - 2021-03-26 05:22:24 --> Helper loaded: form_helper
INFO - 2021-03-26 05:22:24 --> Helper loaded: my_helper
INFO - 2021-03-26 05:22:24 --> Database Driver Class Initialized
DEBUG - 2021-03-26 05:22:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 05:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 05:22:24 --> Controller Class Initialized
INFO - 2021-03-26 05:22:25 --> Config Class Initialized
INFO - 2021-03-26 05:22:25 --> Hooks Class Initialized
DEBUG - 2021-03-26 05:22:25 --> UTF-8 Support Enabled
INFO - 2021-03-26 05:22:25 --> Utf8 Class Initialized
INFO - 2021-03-26 05:22:25 --> URI Class Initialized
INFO - 2021-03-26 05:22:25 --> Router Class Initialized
INFO - 2021-03-26 05:22:25 --> Output Class Initialized
INFO - 2021-03-26 05:22:25 --> Security Class Initialized
DEBUG - 2021-03-26 05:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 05:22:25 --> Input Class Initialized
INFO - 2021-03-26 05:22:25 --> Language Class Initialized
INFO - 2021-03-26 05:22:25 --> Language Class Initialized
INFO - 2021-03-26 05:22:25 --> Config Class Initialized
INFO - 2021-03-26 05:22:25 --> Loader Class Initialized
INFO - 2021-03-26 05:22:25 --> Helper loaded: url_helper
INFO - 2021-03-26 05:22:25 --> Helper loaded: file_helper
INFO - 2021-03-26 05:22:25 --> Helper loaded: form_helper
INFO - 2021-03-26 05:22:25 --> Helper loaded: my_helper
INFO - 2021-03-26 05:22:25 --> Database Driver Class Initialized
DEBUG - 2021-03-26 05:22:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 05:22:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 05:22:25 --> Controller Class Initialized
INFO - 2021-03-26 05:22:25 --> Final output sent to browser
DEBUG - 2021-03-26 05:22:25 --> Total execution time: 0.3245
INFO - 2021-03-26 05:22:29 --> Config Class Initialized
INFO - 2021-03-26 05:22:29 --> Hooks Class Initialized
DEBUG - 2021-03-26 05:22:29 --> UTF-8 Support Enabled
INFO - 2021-03-26 05:22:29 --> Utf8 Class Initialized
INFO - 2021-03-26 05:22:29 --> URI Class Initialized
INFO - 2021-03-26 05:22:29 --> Router Class Initialized
INFO - 2021-03-26 05:22:29 --> Output Class Initialized
INFO - 2021-03-26 05:22:29 --> Security Class Initialized
DEBUG - 2021-03-26 05:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 05:22:29 --> Input Class Initialized
INFO - 2021-03-26 05:22:29 --> Language Class Initialized
INFO - 2021-03-26 05:22:29 --> Language Class Initialized
INFO - 2021-03-26 05:22:29 --> Config Class Initialized
INFO - 2021-03-26 05:22:29 --> Loader Class Initialized
INFO - 2021-03-26 05:22:29 --> Helper loaded: url_helper
INFO - 2021-03-26 05:22:29 --> Helper loaded: file_helper
INFO - 2021-03-26 05:22:29 --> Helper loaded: form_helper
INFO - 2021-03-26 05:22:29 --> Helper loaded: my_helper
INFO - 2021-03-26 05:22:29 --> Database Driver Class Initialized
DEBUG - 2021-03-26 05:22:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 05:22:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 05:22:29 --> Controller Class Initialized
DEBUG - 2021-03-26 05:22:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-03-26 05:22:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-03-26 05:22:29 --> Final output sent to browser
DEBUG - 2021-03-26 05:22:29 --> Total execution time: 0.3388
INFO - 2021-03-26 05:22:31 --> Config Class Initialized
INFO - 2021-03-26 05:22:31 --> Hooks Class Initialized
DEBUG - 2021-03-26 05:22:31 --> UTF-8 Support Enabled
INFO - 2021-03-26 05:22:31 --> Utf8 Class Initialized
INFO - 2021-03-26 05:22:31 --> URI Class Initialized
INFO - 2021-03-26 05:22:31 --> Router Class Initialized
INFO - 2021-03-26 05:22:31 --> Output Class Initialized
INFO - 2021-03-26 05:22:31 --> Security Class Initialized
DEBUG - 2021-03-26 05:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 05:22:31 --> Input Class Initialized
INFO - 2021-03-26 05:22:31 --> Language Class Initialized
INFO - 2021-03-26 05:22:31 --> Language Class Initialized
INFO - 2021-03-26 05:22:31 --> Config Class Initialized
INFO - 2021-03-26 05:22:31 --> Loader Class Initialized
INFO - 2021-03-26 05:22:31 --> Helper loaded: url_helper
INFO - 2021-03-26 05:22:31 --> Helper loaded: file_helper
INFO - 2021-03-26 05:22:31 --> Helper loaded: form_helper
INFO - 2021-03-26 05:22:31 --> Helper loaded: my_helper
INFO - 2021-03-26 05:22:31 --> Database Driver Class Initialized
DEBUG - 2021-03-26 05:22:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 05:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 05:22:31 --> Controller Class Initialized
DEBUG - 2021-03-26 05:22:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-03-26 05:22:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-03-26 05:22:31 --> Final output sent to browser
DEBUG - 2021-03-26 05:22:31 --> Total execution time: 0.3448
INFO - 2021-03-26 05:22:44 --> Config Class Initialized
INFO - 2021-03-26 05:22:44 --> Hooks Class Initialized
DEBUG - 2021-03-26 05:22:44 --> UTF-8 Support Enabled
INFO - 2021-03-26 05:22:44 --> Utf8 Class Initialized
INFO - 2021-03-26 05:22:44 --> URI Class Initialized
INFO - 2021-03-26 05:22:44 --> Router Class Initialized
INFO - 2021-03-26 05:22:44 --> Output Class Initialized
INFO - 2021-03-26 05:22:44 --> Security Class Initialized
DEBUG - 2021-03-26 05:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 05:22:44 --> Input Class Initialized
INFO - 2021-03-26 05:22:44 --> Language Class Initialized
INFO - 2021-03-26 05:22:44 --> Language Class Initialized
INFO - 2021-03-26 05:22:44 --> Config Class Initialized
INFO - 2021-03-26 05:22:44 --> Loader Class Initialized
INFO - 2021-03-26 05:22:45 --> Helper loaded: url_helper
INFO - 2021-03-26 05:22:45 --> Helper loaded: file_helper
INFO - 2021-03-26 05:22:45 --> Helper loaded: form_helper
INFO - 2021-03-26 05:22:45 --> Helper loaded: my_helper
INFO - 2021-03-26 05:22:45 --> Database Driver Class Initialized
DEBUG - 2021-03-26 05:22:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 05:22:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 05:22:45 --> Controller Class Initialized
INFO - 2021-03-26 05:22:45 --> Config Class Initialized
INFO - 2021-03-26 05:22:45 --> Hooks Class Initialized
DEBUG - 2021-03-26 05:22:45 --> UTF-8 Support Enabled
INFO - 2021-03-26 05:22:45 --> Utf8 Class Initialized
INFO - 2021-03-26 05:22:45 --> URI Class Initialized
INFO - 2021-03-26 05:22:45 --> Router Class Initialized
INFO - 2021-03-26 05:22:45 --> Output Class Initialized
INFO - 2021-03-26 05:22:45 --> Security Class Initialized
DEBUG - 2021-03-26 05:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 05:22:45 --> Input Class Initialized
INFO - 2021-03-26 05:22:45 --> Language Class Initialized
INFO - 2021-03-26 05:22:45 --> Language Class Initialized
INFO - 2021-03-26 05:22:45 --> Config Class Initialized
INFO - 2021-03-26 05:22:45 --> Loader Class Initialized
INFO - 2021-03-26 05:22:45 --> Helper loaded: url_helper
INFO - 2021-03-26 05:22:45 --> Helper loaded: file_helper
INFO - 2021-03-26 05:22:45 --> Helper loaded: form_helper
INFO - 2021-03-26 05:22:45 --> Helper loaded: my_helper
INFO - 2021-03-26 05:22:45 --> Database Driver Class Initialized
DEBUG - 2021-03-26 05:22:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 05:22:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 05:22:45 --> Controller Class Initialized
DEBUG - 2021-03-26 05:22:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-03-26 05:22:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-03-26 05:22:45 --> Final output sent to browser
DEBUG - 2021-03-26 05:22:45 --> Total execution time: 0.3571
