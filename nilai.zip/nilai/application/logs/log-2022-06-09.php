<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-06-09 02:54:29 --> Config Class Initialized
INFO - 2022-06-09 02:54:29 --> Hooks Class Initialized
DEBUG - 2022-06-09 02:54:29 --> UTF-8 Support Enabled
INFO - 2022-06-09 02:54:29 --> Utf8 Class Initialized
INFO - 2022-06-09 02:54:29 --> URI Class Initialized
DEBUG - 2022-06-09 02:54:29 --> No URI present. Default controller set.
INFO - 2022-06-09 02:54:29 --> Router Class Initialized
INFO - 2022-06-09 02:54:29 --> Output Class Initialized
INFO - 2022-06-09 02:54:29 --> Security Class Initialized
DEBUG - 2022-06-09 02:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 02:54:29 --> Input Class Initialized
INFO - 2022-06-09 02:54:29 --> Language Class Initialized
INFO - 2022-06-09 02:54:29 --> Language Class Initialized
INFO - 2022-06-09 02:54:29 --> Config Class Initialized
INFO - 2022-06-09 02:54:29 --> Loader Class Initialized
INFO - 2022-06-09 02:54:30 --> Helper loaded: url_helper
INFO - 2022-06-09 02:54:30 --> Helper loaded: file_helper
INFO - 2022-06-09 02:54:30 --> Helper loaded: form_helper
INFO - 2022-06-09 02:54:30 --> Helper loaded: my_helper
INFO - 2022-06-09 02:54:30 --> Database Driver Class Initialized
DEBUG - 2022-06-09 02:54:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 02:54:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 02:54:30 --> Controller Class Initialized
INFO - 2022-06-09 02:54:30 --> Config Class Initialized
INFO - 2022-06-09 02:54:30 --> Hooks Class Initialized
DEBUG - 2022-06-09 02:54:30 --> UTF-8 Support Enabled
INFO - 2022-06-09 02:54:30 --> Utf8 Class Initialized
INFO - 2022-06-09 02:54:30 --> URI Class Initialized
INFO - 2022-06-09 02:54:30 --> Router Class Initialized
INFO - 2022-06-09 02:54:30 --> Output Class Initialized
INFO - 2022-06-09 02:54:30 --> Security Class Initialized
DEBUG - 2022-06-09 02:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 02:54:30 --> Input Class Initialized
INFO - 2022-06-09 02:54:30 --> Language Class Initialized
INFO - 2022-06-09 02:54:30 --> Language Class Initialized
INFO - 2022-06-09 02:54:30 --> Config Class Initialized
INFO - 2022-06-09 02:54:30 --> Loader Class Initialized
INFO - 2022-06-09 02:54:30 --> Helper loaded: url_helper
INFO - 2022-06-09 02:54:30 --> Helper loaded: file_helper
INFO - 2022-06-09 02:54:30 --> Helper loaded: form_helper
INFO - 2022-06-09 02:54:30 --> Helper loaded: my_helper
INFO - 2022-06-09 02:54:30 --> Database Driver Class Initialized
DEBUG - 2022-06-09 02:54:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 02:54:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 02:54:30 --> Controller Class Initialized
DEBUG - 2022-06-09 02:54:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-09 02:54:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-09 02:54:30 --> Final output sent to browser
DEBUG - 2022-06-09 02:54:30 --> Total execution time: 0.1280
INFO - 2022-06-09 02:54:36 --> Config Class Initialized
INFO - 2022-06-09 02:54:36 --> Hooks Class Initialized
DEBUG - 2022-06-09 02:54:36 --> UTF-8 Support Enabled
INFO - 2022-06-09 02:54:36 --> Utf8 Class Initialized
INFO - 2022-06-09 02:54:36 --> URI Class Initialized
INFO - 2022-06-09 02:54:36 --> Router Class Initialized
INFO - 2022-06-09 02:54:36 --> Output Class Initialized
INFO - 2022-06-09 02:54:36 --> Security Class Initialized
DEBUG - 2022-06-09 02:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 02:54:36 --> Input Class Initialized
INFO - 2022-06-09 02:54:36 --> Language Class Initialized
INFO - 2022-06-09 02:54:36 --> Language Class Initialized
INFO - 2022-06-09 02:54:36 --> Config Class Initialized
INFO - 2022-06-09 02:54:36 --> Loader Class Initialized
INFO - 2022-06-09 02:54:36 --> Helper loaded: url_helper
INFO - 2022-06-09 02:54:36 --> Helper loaded: file_helper
INFO - 2022-06-09 02:54:36 --> Helper loaded: form_helper
INFO - 2022-06-09 02:54:36 --> Helper loaded: my_helper
INFO - 2022-06-09 02:54:36 --> Database Driver Class Initialized
DEBUG - 2022-06-09 02:54:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 02:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 02:54:36 --> Controller Class Initialized
INFO - 2022-06-09 02:54:36 --> Helper loaded: cookie_helper
INFO - 2022-06-09 02:54:36 --> Final output sent to browser
DEBUG - 2022-06-09 02:54:36 --> Total execution time: 0.1118
INFO - 2022-06-09 02:54:37 --> Config Class Initialized
INFO - 2022-06-09 02:54:37 --> Hooks Class Initialized
DEBUG - 2022-06-09 02:54:37 --> UTF-8 Support Enabled
INFO - 2022-06-09 02:54:37 --> Utf8 Class Initialized
INFO - 2022-06-09 02:54:37 --> URI Class Initialized
INFO - 2022-06-09 02:54:37 --> Router Class Initialized
INFO - 2022-06-09 02:54:37 --> Output Class Initialized
INFO - 2022-06-09 02:54:37 --> Security Class Initialized
DEBUG - 2022-06-09 02:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 02:54:37 --> Input Class Initialized
INFO - 2022-06-09 02:54:37 --> Language Class Initialized
INFO - 2022-06-09 02:54:37 --> Language Class Initialized
INFO - 2022-06-09 02:54:37 --> Config Class Initialized
INFO - 2022-06-09 02:54:37 --> Loader Class Initialized
INFO - 2022-06-09 02:54:37 --> Helper loaded: url_helper
INFO - 2022-06-09 02:54:37 --> Helper loaded: file_helper
INFO - 2022-06-09 02:54:37 --> Helper loaded: form_helper
INFO - 2022-06-09 02:54:37 --> Helper loaded: my_helper
INFO - 2022-06-09 02:54:37 --> Database Driver Class Initialized
DEBUG - 2022-06-09 02:54:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 02:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 02:54:37 --> Controller Class Initialized
DEBUG - 2022-06-09 02:54:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-06-09 02:54:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-09 02:54:37 --> Final output sent to browser
DEBUG - 2022-06-09 02:54:37 --> Total execution time: 0.2126
INFO - 2022-06-09 02:59:47 --> Config Class Initialized
INFO - 2022-06-09 02:59:47 --> Hooks Class Initialized
DEBUG - 2022-06-09 02:59:47 --> UTF-8 Support Enabled
INFO - 2022-06-09 02:59:47 --> Utf8 Class Initialized
INFO - 2022-06-09 02:59:47 --> URI Class Initialized
INFO - 2022-06-09 02:59:47 --> Router Class Initialized
INFO - 2022-06-09 02:59:47 --> Output Class Initialized
INFO - 2022-06-09 02:59:47 --> Security Class Initialized
DEBUG - 2022-06-09 02:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 02:59:47 --> Input Class Initialized
INFO - 2022-06-09 02:59:47 --> Language Class Initialized
INFO - 2022-06-09 02:59:47 --> Language Class Initialized
INFO - 2022-06-09 02:59:47 --> Config Class Initialized
INFO - 2022-06-09 02:59:47 --> Loader Class Initialized
INFO - 2022-06-09 02:59:47 --> Helper loaded: url_helper
INFO - 2022-06-09 02:59:47 --> Helper loaded: file_helper
INFO - 2022-06-09 02:59:47 --> Helper loaded: form_helper
INFO - 2022-06-09 02:59:47 --> Helper loaded: my_helper
INFO - 2022-06-09 02:59:47 --> Database Driver Class Initialized
DEBUG - 2022-06-09 02:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 02:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 02:59:47 --> Controller Class Initialized
DEBUG - 2022-06-09 02:59:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2022-06-09 02:59:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-09 02:59:47 --> Final output sent to browser
DEBUG - 2022-06-09 02:59:47 --> Total execution time: 0.1099
INFO - 2022-06-09 02:59:47 --> Config Class Initialized
INFO - 2022-06-09 02:59:47 --> Hooks Class Initialized
DEBUG - 2022-06-09 02:59:47 --> UTF-8 Support Enabled
INFO - 2022-06-09 02:59:47 --> Utf8 Class Initialized
INFO - 2022-06-09 02:59:47 --> URI Class Initialized
INFO - 2022-06-09 02:59:47 --> Router Class Initialized
INFO - 2022-06-09 02:59:47 --> Output Class Initialized
INFO - 2022-06-09 02:59:47 --> Security Class Initialized
DEBUG - 2022-06-09 02:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 02:59:47 --> Input Class Initialized
INFO - 2022-06-09 02:59:47 --> Language Class Initialized
INFO - 2022-06-09 02:59:47 --> Language Class Initialized
INFO - 2022-06-09 02:59:47 --> Config Class Initialized
INFO - 2022-06-09 02:59:47 --> Loader Class Initialized
INFO - 2022-06-09 02:59:47 --> Helper loaded: url_helper
INFO - 2022-06-09 02:59:47 --> Helper loaded: file_helper
INFO - 2022-06-09 02:59:47 --> Helper loaded: form_helper
INFO - 2022-06-09 02:59:47 --> Helper loaded: my_helper
INFO - 2022-06-09 02:59:47 --> Database Driver Class Initialized
DEBUG - 2022-06-09 02:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 02:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 02:59:47 --> Controller Class Initialized
INFO - 2022-06-09 02:59:52 --> Config Class Initialized
INFO - 2022-06-09 02:59:52 --> Hooks Class Initialized
DEBUG - 2022-06-09 02:59:52 --> UTF-8 Support Enabled
INFO - 2022-06-09 02:59:52 --> Utf8 Class Initialized
INFO - 2022-06-09 02:59:52 --> URI Class Initialized
INFO - 2022-06-09 02:59:52 --> Router Class Initialized
INFO - 2022-06-09 02:59:52 --> Output Class Initialized
INFO - 2022-06-09 02:59:52 --> Security Class Initialized
DEBUG - 2022-06-09 02:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 02:59:52 --> Input Class Initialized
INFO - 2022-06-09 02:59:52 --> Language Class Initialized
INFO - 2022-06-09 02:59:52 --> Language Class Initialized
INFO - 2022-06-09 02:59:52 --> Config Class Initialized
INFO - 2022-06-09 02:59:52 --> Loader Class Initialized
INFO - 2022-06-09 02:59:52 --> Helper loaded: url_helper
INFO - 2022-06-09 02:59:52 --> Helper loaded: file_helper
INFO - 2022-06-09 02:59:52 --> Helper loaded: form_helper
INFO - 2022-06-09 02:59:52 --> Helper loaded: my_helper
INFO - 2022-06-09 02:59:52 --> Database Driver Class Initialized
DEBUG - 2022-06-09 02:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 02:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 02:59:52 --> Controller Class Initialized
ERROR - 2022-06-09 02:59:52 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilai`.`t_kelas_siswa`, CONSTRAINT `t_kelas_siswa_ibfk_2` FOREIGN KEY (`id_siswa`) REFERENCES `m_siswa` (`id`)) - Invalid query: DELETE FROM m_siswa WHERE id = '1'
INFO - 2022-06-09 02:59:52 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-09 02:59:55 --> Config Class Initialized
INFO - 2022-06-09 02:59:55 --> Hooks Class Initialized
DEBUG - 2022-06-09 02:59:55 --> UTF-8 Support Enabled
INFO - 2022-06-09 02:59:55 --> Utf8 Class Initialized
INFO - 2022-06-09 02:59:55 --> URI Class Initialized
INFO - 2022-06-09 02:59:55 --> Router Class Initialized
INFO - 2022-06-09 02:59:55 --> Output Class Initialized
INFO - 2022-06-09 02:59:55 --> Security Class Initialized
DEBUG - 2022-06-09 02:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 02:59:55 --> Input Class Initialized
INFO - 2022-06-09 02:59:55 --> Language Class Initialized
INFO - 2022-06-09 02:59:55 --> Language Class Initialized
INFO - 2022-06-09 02:59:55 --> Config Class Initialized
INFO - 2022-06-09 02:59:55 --> Loader Class Initialized
INFO - 2022-06-09 02:59:55 --> Helper loaded: url_helper
INFO - 2022-06-09 02:59:55 --> Helper loaded: file_helper
INFO - 2022-06-09 02:59:55 --> Helper loaded: form_helper
INFO - 2022-06-09 02:59:55 --> Helper loaded: my_helper
INFO - 2022-06-09 02:59:55 --> Database Driver Class Initialized
DEBUG - 2022-06-09 02:59:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 02:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 02:59:55 --> Controller Class Initialized
DEBUG - 2022-06-09 02:59:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2022-06-09 02:59:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-09 02:59:55 --> Final output sent to browser
DEBUG - 2022-06-09 02:59:55 --> Total execution time: 0.0859
INFO - 2022-06-09 02:59:56 --> Config Class Initialized
INFO - 2022-06-09 02:59:56 --> Hooks Class Initialized
DEBUG - 2022-06-09 02:59:56 --> UTF-8 Support Enabled
INFO - 2022-06-09 02:59:56 --> Utf8 Class Initialized
INFO - 2022-06-09 02:59:56 --> URI Class Initialized
INFO - 2022-06-09 02:59:56 --> Router Class Initialized
INFO - 2022-06-09 02:59:56 --> Output Class Initialized
INFO - 2022-06-09 02:59:56 --> Security Class Initialized
DEBUG - 2022-06-09 02:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 02:59:56 --> Input Class Initialized
INFO - 2022-06-09 02:59:56 --> Language Class Initialized
INFO - 2022-06-09 02:59:56 --> Language Class Initialized
INFO - 2022-06-09 02:59:56 --> Config Class Initialized
INFO - 2022-06-09 02:59:56 --> Loader Class Initialized
INFO - 2022-06-09 02:59:56 --> Helper loaded: url_helper
INFO - 2022-06-09 02:59:56 --> Helper loaded: file_helper
INFO - 2022-06-09 02:59:56 --> Helper loaded: form_helper
INFO - 2022-06-09 02:59:56 --> Helper loaded: my_helper
INFO - 2022-06-09 02:59:56 --> Database Driver Class Initialized
DEBUG - 2022-06-09 02:59:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 02:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 02:59:56 --> Controller Class Initialized
DEBUG - 2022-06-09 02:59:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2022-06-09 02:59:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-09 02:59:56 --> Final output sent to browser
DEBUG - 2022-06-09 02:59:56 --> Total execution time: 0.1024
INFO - 2022-06-09 02:59:56 --> Config Class Initialized
INFO - 2022-06-09 02:59:56 --> Hooks Class Initialized
DEBUG - 2022-06-09 02:59:56 --> UTF-8 Support Enabled
INFO - 2022-06-09 02:59:56 --> Utf8 Class Initialized
INFO - 2022-06-09 02:59:56 --> URI Class Initialized
INFO - 2022-06-09 02:59:56 --> Router Class Initialized
INFO - 2022-06-09 02:59:56 --> Output Class Initialized
INFO - 2022-06-09 02:59:56 --> Security Class Initialized
DEBUG - 2022-06-09 02:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 02:59:56 --> Input Class Initialized
INFO - 2022-06-09 02:59:56 --> Language Class Initialized
INFO - 2022-06-09 02:59:56 --> Language Class Initialized
INFO - 2022-06-09 02:59:56 --> Config Class Initialized
INFO - 2022-06-09 02:59:56 --> Loader Class Initialized
INFO - 2022-06-09 02:59:56 --> Helper loaded: url_helper
INFO - 2022-06-09 02:59:56 --> Helper loaded: file_helper
INFO - 2022-06-09 02:59:56 --> Helper loaded: form_helper
INFO - 2022-06-09 02:59:56 --> Helper loaded: my_helper
INFO - 2022-06-09 02:59:56 --> Database Driver Class Initialized
DEBUG - 2022-06-09 02:59:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 02:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 02:59:56 --> Controller Class Initialized
INFO - 2022-06-09 02:59:57 --> Config Class Initialized
INFO - 2022-06-09 02:59:57 --> Hooks Class Initialized
DEBUG - 2022-06-09 02:59:57 --> UTF-8 Support Enabled
INFO - 2022-06-09 02:59:57 --> Utf8 Class Initialized
INFO - 2022-06-09 02:59:57 --> URI Class Initialized
INFO - 2022-06-09 02:59:57 --> Router Class Initialized
INFO - 2022-06-09 02:59:57 --> Output Class Initialized
INFO - 2022-06-09 02:59:57 --> Security Class Initialized
DEBUG - 2022-06-09 02:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 02:59:57 --> Input Class Initialized
INFO - 2022-06-09 02:59:57 --> Language Class Initialized
INFO - 2022-06-09 02:59:57 --> Language Class Initialized
INFO - 2022-06-09 02:59:57 --> Config Class Initialized
INFO - 2022-06-09 02:59:57 --> Loader Class Initialized
INFO - 2022-06-09 02:59:57 --> Helper loaded: url_helper
INFO - 2022-06-09 02:59:57 --> Helper loaded: file_helper
INFO - 2022-06-09 02:59:57 --> Helper loaded: form_helper
INFO - 2022-06-09 02:59:57 --> Helper loaded: my_helper
INFO - 2022-06-09 02:59:57 --> Database Driver Class Initialized
DEBUG - 2022-06-09 02:59:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 02:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 02:59:57 --> Controller Class Initialized
DEBUG - 2022-06-09 02:59:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2022-06-09 02:59:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-09 02:59:57 --> Final output sent to browser
DEBUG - 2022-06-09 02:59:57 --> Total execution time: 0.0669
INFO - 2022-06-09 03:00:00 --> Config Class Initialized
INFO - 2022-06-09 03:00:00 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:00:00 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:00:00 --> Utf8 Class Initialized
INFO - 2022-06-09 03:00:00 --> URI Class Initialized
INFO - 2022-06-09 03:00:00 --> Router Class Initialized
INFO - 2022-06-09 03:00:00 --> Output Class Initialized
INFO - 2022-06-09 03:00:00 --> Security Class Initialized
DEBUG - 2022-06-09 03:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:00:00 --> Input Class Initialized
INFO - 2022-06-09 03:00:00 --> Language Class Initialized
INFO - 2022-06-09 03:00:00 --> Language Class Initialized
INFO - 2022-06-09 03:00:00 --> Config Class Initialized
INFO - 2022-06-09 03:00:00 --> Loader Class Initialized
INFO - 2022-06-09 03:00:00 --> Helper loaded: url_helper
INFO - 2022-06-09 03:00:00 --> Helper loaded: file_helper
INFO - 2022-06-09 03:00:00 --> Helper loaded: form_helper
INFO - 2022-06-09 03:00:00 --> Helper loaded: my_helper
INFO - 2022-06-09 03:00:00 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:00:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:00:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:00:00 --> Controller Class Initialized
ERROR - 2022-06-09 03:00:00 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '1' AND tasm = '20212'
INFO - 2022-06-09 03:00:00 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-09 03:00:05 --> Config Class Initialized
INFO - 2022-06-09 03:00:05 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:00:05 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:00:05 --> Utf8 Class Initialized
INFO - 2022-06-09 03:00:05 --> URI Class Initialized
INFO - 2022-06-09 03:00:05 --> Router Class Initialized
INFO - 2022-06-09 03:00:05 --> Output Class Initialized
INFO - 2022-06-09 03:00:05 --> Security Class Initialized
DEBUG - 2022-06-09 03:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:00:05 --> Input Class Initialized
INFO - 2022-06-09 03:00:05 --> Language Class Initialized
INFO - 2022-06-09 03:00:05 --> Language Class Initialized
INFO - 2022-06-09 03:00:05 --> Config Class Initialized
INFO - 2022-06-09 03:00:05 --> Loader Class Initialized
INFO - 2022-06-09 03:00:05 --> Helper loaded: url_helper
INFO - 2022-06-09 03:00:05 --> Helper loaded: file_helper
INFO - 2022-06-09 03:00:05 --> Helper loaded: form_helper
INFO - 2022-06-09 03:00:05 --> Helper loaded: my_helper
INFO - 2022-06-09 03:00:05 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:00:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:00:05 --> Controller Class Initialized
DEBUG - 2022-06-09 03:00:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2022-06-09 03:00:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-09 03:00:05 --> Final output sent to browser
DEBUG - 2022-06-09 03:00:05 --> Total execution time: 0.0978
INFO - 2022-06-09 03:00:06 --> Config Class Initialized
INFO - 2022-06-09 03:00:06 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:00:06 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:00:06 --> Utf8 Class Initialized
INFO - 2022-06-09 03:00:06 --> URI Class Initialized
INFO - 2022-06-09 03:00:06 --> Router Class Initialized
INFO - 2022-06-09 03:00:06 --> Output Class Initialized
INFO - 2022-06-09 03:00:06 --> Security Class Initialized
DEBUG - 2022-06-09 03:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:00:06 --> Input Class Initialized
INFO - 2022-06-09 03:00:06 --> Language Class Initialized
INFO - 2022-06-09 03:00:06 --> Language Class Initialized
INFO - 2022-06-09 03:00:06 --> Config Class Initialized
INFO - 2022-06-09 03:00:06 --> Loader Class Initialized
INFO - 2022-06-09 03:00:06 --> Helper loaded: url_helper
INFO - 2022-06-09 03:00:06 --> Helper loaded: file_helper
INFO - 2022-06-09 03:00:06 --> Helper loaded: form_helper
INFO - 2022-06-09 03:00:06 --> Helper loaded: my_helper
INFO - 2022-06-09 03:00:06 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:00:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:00:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:00:06 --> Controller Class Initialized
INFO - 2022-06-09 03:00:06 --> Config Class Initialized
INFO - 2022-06-09 03:00:06 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:00:06 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:00:06 --> Utf8 Class Initialized
INFO - 2022-06-09 03:00:06 --> URI Class Initialized
INFO - 2022-06-09 03:00:06 --> Router Class Initialized
INFO - 2022-06-09 03:00:06 --> Output Class Initialized
INFO - 2022-06-09 03:00:06 --> Security Class Initialized
DEBUG - 2022-06-09 03:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:00:06 --> Input Class Initialized
INFO - 2022-06-09 03:00:06 --> Language Class Initialized
INFO - 2022-06-09 03:00:06 --> Language Class Initialized
INFO - 2022-06-09 03:00:06 --> Config Class Initialized
INFO - 2022-06-09 03:00:06 --> Loader Class Initialized
INFO - 2022-06-09 03:00:06 --> Helper loaded: url_helper
INFO - 2022-06-09 03:00:06 --> Helper loaded: file_helper
INFO - 2022-06-09 03:00:06 --> Helper loaded: form_helper
INFO - 2022-06-09 03:00:06 --> Helper loaded: my_helper
INFO - 2022-06-09 03:00:06 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:00:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:00:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:00:06 --> Controller Class Initialized
DEBUG - 2022-06-09 03:00:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2022-06-09 03:00:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-09 03:00:06 --> Final output sent to browser
DEBUG - 2022-06-09 03:00:06 --> Total execution time: 0.0537
INFO - 2022-06-09 03:00:07 --> Config Class Initialized
INFO - 2022-06-09 03:00:07 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:00:07 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:00:07 --> Utf8 Class Initialized
INFO - 2022-06-09 03:00:07 --> URI Class Initialized
INFO - 2022-06-09 03:00:07 --> Router Class Initialized
INFO - 2022-06-09 03:00:07 --> Output Class Initialized
INFO - 2022-06-09 03:00:07 --> Security Class Initialized
DEBUG - 2022-06-09 03:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:00:07 --> Input Class Initialized
INFO - 2022-06-09 03:00:07 --> Language Class Initialized
INFO - 2022-06-09 03:00:07 --> Language Class Initialized
INFO - 2022-06-09 03:00:07 --> Config Class Initialized
INFO - 2022-06-09 03:00:07 --> Loader Class Initialized
INFO - 2022-06-09 03:00:07 --> Helper loaded: url_helper
INFO - 2022-06-09 03:00:07 --> Helper loaded: file_helper
INFO - 2022-06-09 03:00:07 --> Helper loaded: form_helper
INFO - 2022-06-09 03:00:07 --> Helper loaded: my_helper
INFO - 2022-06-09 03:00:07 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:00:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:00:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:00:07 --> Controller Class Initialized
INFO - 2022-06-09 03:00:11 --> Config Class Initialized
INFO - 2022-06-09 03:00:11 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:00:11 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:00:11 --> Utf8 Class Initialized
INFO - 2022-06-09 03:00:11 --> URI Class Initialized
INFO - 2022-06-09 03:00:11 --> Router Class Initialized
INFO - 2022-06-09 03:00:11 --> Output Class Initialized
INFO - 2022-06-09 03:00:11 --> Security Class Initialized
DEBUG - 2022-06-09 03:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:00:11 --> Input Class Initialized
INFO - 2022-06-09 03:00:11 --> Language Class Initialized
INFO - 2022-06-09 03:00:11 --> Language Class Initialized
INFO - 2022-06-09 03:00:11 --> Config Class Initialized
INFO - 2022-06-09 03:00:11 --> Loader Class Initialized
INFO - 2022-06-09 03:00:11 --> Helper loaded: url_helper
INFO - 2022-06-09 03:00:11 --> Helper loaded: file_helper
INFO - 2022-06-09 03:00:11 --> Helper loaded: form_helper
INFO - 2022-06-09 03:00:11 --> Helper loaded: my_helper
INFO - 2022-06-09 03:00:11 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:00:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:00:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:00:11 --> Controller Class Initialized
DEBUG - 2022-06-09 03:00:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2022-06-09 03:00:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-09 03:00:11 --> Final output sent to browser
DEBUG - 2022-06-09 03:00:11 --> Total execution time: 0.0753
INFO - 2022-06-09 03:00:12 --> Config Class Initialized
INFO - 2022-06-09 03:00:12 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:00:12 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:00:12 --> Utf8 Class Initialized
INFO - 2022-06-09 03:00:12 --> URI Class Initialized
INFO - 2022-06-09 03:00:12 --> Router Class Initialized
INFO - 2022-06-09 03:00:12 --> Output Class Initialized
INFO - 2022-06-09 03:00:12 --> Security Class Initialized
DEBUG - 2022-06-09 03:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:00:12 --> Input Class Initialized
INFO - 2022-06-09 03:00:12 --> Language Class Initialized
INFO - 2022-06-09 03:00:12 --> Language Class Initialized
INFO - 2022-06-09 03:00:12 --> Config Class Initialized
INFO - 2022-06-09 03:00:12 --> Loader Class Initialized
INFO - 2022-06-09 03:00:12 --> Helper loaded: url_helper
INFO - 2022-06-09 03:00:12 --> Helper loaded: file_helper
INFO - 2022-06-09 03:00:12 --> Helper loaded: form_helper
INFO - 2022-06-09 03:00:12 --> Helper loaded: my_helper
INFO - 2022-06-09 03:00:12 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:00:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:00:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:00:12 --> Controller Class Initialized
DEBUG - 2022-06-09 03:00:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2022-06-09 03:00:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-09 03:00:12 --> Final output sent to browser
DEBUG - 2022-06-09 03:00:12 --> Total execution time: 0.0952
INFO - 2022-06-09 03:00:12 --> Config Class Initialized
INFO - 2022-06-09 03:00:12 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:00:12 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:00:12 --> Utf8 Class Initialized
INFO - 2022-06-09 03:00:12 --> URI Class Initialized
INFO - 2022-06-09 03:00:12 --> Router Class Initialized
INFO - 2022-06-09 03:00:12 --> Output Class Initialized
INFO - 2022-06-09 03:00:12 --> Security Class Initialized
DEBUG - 2022-06-09 03:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:00:12 --> Input Class Initialized
INFO - 2022-06-09 03:00:12 --> Language Class Initialized
INFO - 2022-06-09 03:00:12 --> Language Class Initialized
INFO - 2022-06-09 03:00:12 --> Config Class Initialized
INFO - 2022-06-09 03:00:12 --> Loader Class Initialized
INFO - 2022-06-09 03:00:12 --> Helper loaded: url_helper
INFO - 2022-06-09 03:00:12 --> Helper loaded: file_helper
INFO - 2022-06-09 03:00:12 --> Helper loaded: form_helper
INFO - 2022-06-09 03:00:12 --> Helper loaded: my_helper
INFO - 2022-06-09 03:00:12 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:00:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:00:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:00:12 --> Controller Class Initialized
INFO - 2022-06-09 03:00:13 --> Config Class Initialized
INFO - 2022-06-09 03:00:13 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:00:13 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:00:13 --> Utf8 Class Initialized
INFO - 2022-06-09 03:00:13 --> URI Class Initialized
INFO - 2022-06-09 03:00:13 --> Router Class Initialized
INFO - 2022-06-09 03:00:13 --> Output Class Initialized
INFO - 2022-06-09 03:00:13 --> Security Class Initialized
DEBUG - 2022-06-09 03:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:00:13 --> Input Class Initialized
INFO - 2022-06-09 03:00:13 --> Language Class Initialized
INFO - 2022-06-09 03:00:13 --> Language Class Initialized
INFO - 2022-06-09 03:00:13 --> Config Class Initialized
INFO - 2022-06-09 03:00:13 --> Loader Class Initialized
INFO - 2022-06-09 03:00:13 --> Helper loaded: url_helper
INFO - 2022-06-09 03:00:13 --> Helper loaded: file_helper
INFO - 2022-06-09 03:00:13 --> Helper loaded: form_helper
INFO - 2022-06-09 03:00:13 --> Helper loaded: my_helper
INFO - 2022-06-09 03:00:13 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:00:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:00:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:00:13 --> Controller Class Initialized
DEBUG - 2022-06-09 03:00:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_ekstra/views/list.php
DEBUG - 2022-06-09 03:00:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-09 03:00:13 --> Final output sent to browser
DEBUG - 2022-06-09 03:00:13 --> Total execution time: 0.0933
INFO - 2022-06-09 03:00:13 --> Config Class Initialized
INFO - 2022-06-09 03:00:13 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:00:13 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:00:13 --> Utf8 Class Initialized
INFO - 2022-06-09 03:00:13 --> URI Class Initialized
INFO - 2022-06-09 03:00:13 --> Router Class Initialized
INFO - 2022-06-09 03:00:13 --> Output Class Initialized
INFO - 2022-06-09 03:00:13 --> Security Class Initialized
DEBUG - 2022-06-09 03:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:00:13 --> Input Class Initialized
INFO - 2022-06-09 03:00:13 --> Language Class Initialized
INFO - 2022-06-09 03:00:13 --> Language Class Initialized
INFO - 2022-06-09 03:00:13 --> Config Class Initialized
INFO - 2022-06-09 03:00:13 --> Loader Class Initialized
INFO - 2022-06-09 03:00:14 --> Helper loaded: url_helper
INFO - 2022-06-09 03:00:14 --> Helper loaded: file_helper
INFO - 2022-06-09 03:00:14 --> Helper loaded: form_helper
INFO - 2022-06-09 03:00:14 --> Helper loaded: my_helper
INFO - 2022-06-09 03:00:14 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:00:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:00:14 --> Controller Class Initialized
ERROR - 2022-06-09 03:00:14 --> Query error: Table 'db_nilai.m_ekstra' doesn't exist - Invalid query: SELECT id FROM m_ekstra
INFO - 2022-06-09 03:00:14 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-09 03:00:14 --> Config Class Initialized
INFO - 2022-06-09 03:00:14 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:00:14 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:00:14 --> Utf8 Class Initialized
INFO - 2022-06-09 03:00:14 --> URI Class Initialized
INFO - 2022-06-09 03:00:14 --> Router Class Initialized
INFO - 2022-06-09 03:00:14 --> Output Class Initialized
INFO - 2022-06-09 03:00:14 --> Security Class Initialized
DEBUG - 2022-06-09 03:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:00:14 --> Input Class Initialized
INFO - 2022-06-09 03:00:14 --> Language Class Initialized
INFO - 2022-06-09 03:00:14 --> Language Class Initialized
INFO - 2022-06-09 03:00:14 --> Config Class Initialized
INFO - 2022-06-09 03:00:14 --> Loader Class Initialized
INFO - 2022-06-09 03:00:14 --> Helper loaded: url_helper
INFO - 2022-06-09 03:00:14 --> Helper loaded: file_helper
INFO - 2022-06-09 03:00:14 --> Helper loaded: form_helper
INFO - 2022-06-09 03:00:14 --> Helper loaded: my_helper
INFO - 2022-06-09 03:00:14 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:00:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:00:14 --> Controller Class Initialized
DEBUG - 2022-06-09 03:00:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2022-06-09 03:00:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-09 03:00:14 --> Final output sent to browser
DEBUG - 2022-06-09 03:00:14 --> Total execution time: 0.0819
INFO - 2022-06-09 03:00:14 --> Config Class Initialized
INFO - 2022-06-09 03:00:14 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:00:14 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:00:14 --> Utf8 Class Initialized
INFO - 2022-06-09 03:00:14 --> URI Class Initialized
INFO - 2022-06-09 03:00:14 --> Router Class Initialized
INFO - 2022-06-09 03:00:14 --> Output Class Initialized
INFO - 2022-06-09 03:00:14 --> Security Class Initialized
DEBUG - 2022-06-09 03:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:00:14 --> Input Class Initialized
INFO - 2022-06-09 03:00:14 --> Language Class Initialized
INFO - 2022-06-09 03:00:14 --> Language Class Initialized
INFO - 2022-06-09 03:00:14 --> Config Class Initialized
INFO - 2022-06-09 03:00:14 --> Loader Class Initialized
INFO - 2022-06-09 03:00:14 --> Helper loaded: url_helper
INFO - 2022-06-09 03:00:14 --> Helper loaded: file_helper
INFO - 2022-06-09 03:00:14 --> Helper loaded: form_helper
INFO - 2022-06-09 03:00:14 --> Helper loaded: my_helper
INFO - 2022-06-09 03:00:14 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:00:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:00:14 --> Controller Class Initialized
INFO - 2022-06-09 03:00:16 --> Config Class Initialized
INFO - 2022-06-09 03:00:16 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:00:16 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:00:16 --> Utf8 Class Initialized
INFO - 2022-06-09 03:00:16 --> URI Class Initialized
INFO - 2022-06-09 03:00:16 --> Router Class Initialized
INFO - 2022-06-09 03:00:16 --> Output Class Initialized
INFO - 2022-06-09 03:00:16 --> Security Class Initialized
DEBUG - 2022-06-09 03:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:00:16 --> Input Class Initialized
INFO - 2022-06-09 03:00:16 --> Language Class Initialized
INFO - 2022-06-09 03:00:16 --> Language Class Initialized
INFO - 2022-06-09 03:00:16 --> Config Class Initialized
INFO - 2022-06-09 03:00:16 --> Loader Class Initialized
INFO - 2022-06-09 03:00:16 --> Helper loaded: url_helper
INFO - 2022-06-09 03:00:16 --> Helper loaded: file_helper
INFO - 2022-06-09 03:00:16 --> Helper loaded: form_helper
INFO - 2022-06-09 03:00:16 --> Helper loaded: my_helper
INFO - 2022-06-09 03:00:16 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:00:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:00:16 --> Controller Class Initialized
DEBUG - 2022-06-09 03:00:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_ekstra/views/list.php
DEBUG - 2022-06-09 03:00:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-09 03:00:16 --> Final output sent to browser
DEBUG - 2022-06-09 03:00:16 --> Total execution time: 0.0611
INFO - 2022-06-09 03:00:16 --> Config Class Initialized
INFO - 2022-06-09 03:00:16 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:00:16 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:00:16 --> Utf8 Class Initialized
INFO - 2022-06-09 03:00:16 --> URI Class Initialized
INFO - 2022-06-09 03:00:16 --> Router Class Initialized
INFO - 2022-06-09 03:00:16 --> Output Class Initialized
INFO - 2022-06-09 03:00:16 --> Security Class Initialized
DEBUG - 2022-06-09 03:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:00:16 --> Input Class Initialized
INFO - 2022-06-09 03:00:16 --> Language Class Initialized
INFO - 2022-06-09 03:00:16 --> Language Class Initialized
INFO - 2022-06-09 03:00:16 --> Config Class Initialized
INFO - 2022-06-09 03:00:16 --> Loader Class Initialized
INFO - 2022-06-09 03:00:16 --> Helper loaded: url_helper
INFO - 2022-06-09 03:00:16 --> Helper loaded: file_helper
INFO - 2022-06-09 03:00:16 --> Helper loaded: form_helper
INFO - 2022-06-09 03:00:16 --> Helper loaded: my_helper
INFO - 2022-06-09 03:00:16 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:00:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:00:16 --> Controller Class Initialized
ERROR - 2022-06-09 03:00:16 --> Query error: Table 'db_nilai.m_ekstra' doesn't exist - Invalid query: SELECT id FROM m_ekstra
INFO - 2022-06-09 03:00:16 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-09 03:00:19 --> Config Class Initialized
INFO - 2022-06-09 03:00:19 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:00:19 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:00:19 --> Utf8 Class Initialized
INFO - 2022-06-09 03:00:19 --> URI Class Initialized
INFO - 2022-06-09 03:00:19 --> Router Class Initialized
INFO - 2022-06-09 03:00:19 --> Output Class Initialized
INFO - 2022-06-09 03:00:19 --> Security Class Initialized
DEBUG - 2022-06-09 03:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:00:19 --> Input Class Initialized
INFO - 2022-06-09 03:00:19 --> Language Class Initialized
INFO - 2022-06-09 03:00:19 --> Language Class Initialized
INFO - 2022-06-09 03:00:19 --> Config Class Initialized
INFO - 2022-06-09 03:00:19 --> Loader Class Initialized
INFO - 2022-06-09 03:00:19 --> Helper loaded: url_helper
INFO - 2022-06-09 03:00:19 --> Helper loaded: file_helper
INFO - 2022-06-09 03:00:19 --> Helper loaded: form_helper
INFO - 2022-06-09 03:00:19 --> Helper loaded: my_helper
INFO - 2022-06-09 03:00:19 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:00:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:00:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:00:19 --> Controller Class Initialized
DEBUG - 2022-06-09 03:00:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2022-06-09 03:00:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-09 03:00:19 --> Final output sent to browser
DEBUG - 2022-06-09 03:00:19 --> Total execution time: 0.0718
INFO - 2022-06-09 03:00:19 --> Config Class Initialized
INFO - 2022-06-09 03:00:19 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:00:19 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:00:19 --> Utf8 Class Initialized
INFO - 2022-06-09 03:00:19 --> URI Class Initialized
INFO - 2022-06-09 03:00:19 --> Router Class Initialized
INFO - 2022-06-09 03:00:19 --> Output Class Initialized
INFO - 2022-06-09 03:00:19 --> Security Class Initialized
DEBUG - 2022-06-09 03:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:00:19 --> Input Class Initialized
INFO - 2022-06-09 03:00:19 --> Language Class Initialized
INFO - 2022-06-09 03:00:19 --> Language Class Initialized
INFO - 2022-06-09 03:00:19 --> Config Class Initialized
INFO - 2022-06-09 03:00:19 --> Loader Class Initialized
INFO - 2022-06-09 03:00:19 --> Helper loaded: url_helper
INFO - 2022-06-09 03:00:19 --> Helper loaded: file_helper
INFO - 2022-06-09 03:00:19 --> Helper loaded: form_helper
INFO - 2022-06-09 03:00:19 --> Helper loaded: my_helper
INFO - 2022-06-09 03:00:19 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:00:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:00:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:00:19 --> Controller Class Initialized
INFO - 2022-06-09 03:00:21 --> Config Class Initialized
INFO - 2022-06-09 03:00:21 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:00:21 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:00:21 --> Utf8 Class Initialized
INFO - 2022-06-09 03:00:21 --> URI Class Initialized
INFO - 2022-06-09 03:00:21 --> Router Class Initialized
INFO - 2022-06-09 03:00:21 --> Output Class Initialized
INFO - 2022-06-09 03:00:21 --> Security Class Initialized
DEBUG - 2022-06-09 03:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:00:21 --> Input Class Initialized
INFO - 2022-06-09 03:00:21 --> Language Class Initialized
INFO - 2022-06-09 03:00:21 --> Language Class Initialized
INFO - 2022-06-09 03:00:21 --> Config Class Initialized
INFO - 2022-06-09 03:00:21 --> Loader Class Initialized
INFO - 2022-06-09 03:00:21 --> Helper loaded: url_helper
INFO - 2022-06-09 03:00:21 --> Helper loaded: file_helper
INFO - 2022-06-09 03:00:21 --> Helper loaded: form_helper
INFO - 2022-06-09 03:00:21 --> Helper loaded: my_helper
INFO - 2022-06-09 03:00:21 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:00:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:00:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:00:21 --> Controller Class Initialized
DEBUG - 2022-06-09 03:00:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2022-06-09 03:00:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-09 03:00:21 --> Final output sent to browser
DEBUG - 2022-06-09 03:00:21 --> Total execution time: 0.0891
INFO - 2022-06-09 03:00:21 --> Config Class Initialized
INFO - 2022-06-09 03:00:21 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:00:21 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:00:21 --> Utf8 Class Initialized
INFO - 2022-06-09 03:00:21 --> URI Class Initialized
INFO - 2022-06-09 03:00:21 --> Router Class Initialized
INFO - 2022-06-09 03:00:21 --> Output Class Initialized
INFO - 2022-06-09 03:00:21 --> Security Class Initialized
DEBUG - 2022-06-09 03:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:00:21 --> Input Class Initialized
INFO - 2022-06-09 03:00:21 --> Language Class Initialized
INFO - 2022-06-09 03:00:21 --> Language Class Initialized
INFO - 2022-06-09 03:00:21 --> Config Class Initialized
INFO - 2022-06-09 03:00:21 --> Loader Class Initialized
INFO - 2022-06-09 03:00:21 --> Helper loaded: url_helper
INFO - 2022-06-09 03:00:21 --> Helper loaded: file_helper
INFO - 2022-06-09 03:00:21 --> Helper loaded: form_helper
INFO - 2022-06-09 03:00:21 --> Helper loaded: my_helper
INFO - 2022-06-09 03:00:21 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:00:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:00:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:00:21 --> Controller Class Initialized
INFO - 2022-06-09 03:00:22 --> Config Class Initialized
INFO - 2022-06-09 03:00:22 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:00:22 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:00:22 --> Utf8 Class Initialized
INFO - 2022-06-09 03:00:22 --> URI Class Initialized
INFO - 2022-06-09 03:00:22 --> Router Class Initialized
INFO - 2022-06-09 03:00:22 --> Output Class Initialized
INFO - 2022-06-09 03:00:22 --> Security Class Initialized
DEBUG - 2022-06-09 03:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:00:22 --> Input Class Initialized
INFO - 2022-06-09 03:00:22 --> Language Class Initialized
INFO - 2022-06-09 03:00:22 --> Language Class Initialized
INFO - 2022-06-09 03:00:22 --> Config Class Initialized
INFO - 2022-06-09 03:00:22 --> Loader Class Initialized
INFO - 2022-06-09 03:00:22 --> Helper loaded: url_helper
INFO - 2022-06-09 03:00:22 --> Helper loaded: file_helper
INFO - 2022-06-09 03:00:22 --> Helper loaded: form_helper
INFO - 2022-06-09 03:00:22 --> Helper loaded: my_helper
INFO - 2022-06-09 03:00:22 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:00:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:00:22 --> Controller Class Initialized
DEBUG - 2022-06-09 03:00:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2022-06-09 03:00:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-09 03:00:22 --> Final output sent to browser
DEBUG - 2022-06-09 03:00:22 --> Total execution time: 0.0541
INFO - 2022-06-09 03:00:22 --> Config Class Initialized
INFO - 2022-06-09 03:00:22 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:00:22 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:00:22 --> Utf8 Class Initialized
INFO - 2022-06-09 03:00:22 --> URI Class Initialized
INFO - 2022-06-09 03:00:22 --> Router Class Initialized
INFO - 2022-06-09 03:00:22 --> Output Class Initialized
INFO - 2022-06-09 03:00:22 --> Security Class Initialized
DEBUG - 2022-06-09 03:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:00:22 --> Input Class Initialized
INFO - 2022-06-09 03:00:22 --> Language Class Initialized
INFO - 2022-06-09 03:00:22 --> Language Class Initialized
INFO - 2022-06-09 03:00:22 --> Config Class Initialized
INFO - 2022-06-09 03:00:22 --> Loader Class Initialized
INFO - 2022-06-09 03:00:22 --> Helper loaded: url_helper
INFO - 2022-06-09 03:00:22 --> Helper loaded: file_helper
INFO - 2022-06-09 03:00:22 --> Helper loaded: form_helper
INFO - 2022-06-09 03:00:22 --> Helper loaded: my_helper
INFO - 2022-06-09 03:00:22 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:00:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:00:22 --> Controller Class Initialized
INFO - 2022-06-09 03:00:25 --> Config Class Initialized
INFO - 2022-06-09 03:00:25 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:00:25 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:00:25 --> Utf8 Class Initialized
INFO - 2022-06-09 03:00:25 --> URI Class Initialized
INFO - 2022-06-09 03:00:25 --> Router Class Initialized
INFO - 2022-06-09 03:00:25 --> Output Class Initialized
INFO - 2022-06-09 03:00:25 --> Security Class Initialized
DEBUG - 2022-06-09 03:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:00:25 --> Input Class Initialized
INFO - 2022-06-09 03:00:25 --> Language Class Initialized
INFO - 2022-06-09 03:00:25 --> Language Class Initialized
INFO - 2022-06-09 03:00:25 --> Config Class Initialized
INFO - 2022-06-09 03:00:25 --> Loader Class Initialized
INFO - 2022-06-09 03:00:25 --> Helper loaded: url_helper
INFO - 2022-06-09 03:00:25 --> Helper loaded: file_helper
INFO - 2022-06-09 03:00:25 --> Helper loaded: form_helper
INFO - 2022-06-09 03:00:25 --> Helper loaded: my_helper
INFO - 2022-06-09 03:00:25 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:00:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:00:25 --> Controller Class Initialized
INFO - 2022-06-09 03:00:25 --> Config Class Initialized
INFO - 2022-06-09 03:00:25 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:00:25 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:00:25 --> Utf8 Class Initialized
INFO - 2022-06-09 03:00:25 --> URI Class Initialized
INFO - 2022-06-09 03:00:25 --> Router Class Initialized
INFO - 2022-06-09 03:00:25 --> Output Class Initialized
INFO - 2022-06-09 03:00:25 --> Security Class Initialized
DEBUG - 2022-06-09 03:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:00:25 --> Input Class Initialized
INFO - 2022-06-09 03:00:25 --> Language Class Initialized
INFO - 2022-06-09 03:00:25 --> Language Class Initialized
INFO - 2022-06-09 03:00:25 --> Config Class Initialized
INFO - 2022-06-09 03:00:25 --> Loader Class Initialized
INFO - 2022-06-09 03:00:25 --> Helper loaded: url_helper
INFO - 2022-06-09 03:00:25 --> Helper loaded: file_helper
INFO - 2022-06-09 03:00:25 --> Helper loaded: form_helper
INFO - 2022-06-09 03:00:25 --> Helper loaded: my_helper
INFO - 2022-06-09 03:00:25 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:00:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:00:25 --> Controller Class Initialized
DEBUG - 2022-06-09 03:00:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2022-06-09 03:00:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-09 03:00:25 --> Final output sent to browser
DEBUG - 2022-06-09 03:00:25 --> Total execution time: 0.0780
INFO - 2022-06-09 03:00:25 --> Config Class Initialized
INFO - 2022-06-09 03:00:25 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:00:25 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:00:25 --> Utf8 Class Initialized
INFO - 2022-06-09 03:00:25 --> URI Class Initialized
INFO - 2022-06-09 03:00:25 --> Router Class Initialized
INFO - 2022-06-09 03:00:25 --> Output Class Initialized
INFO - 2022-06-09 03:00:25 --> Security Class Initialized
DEBUG - 2022-06-09 03:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:00:25 --> Input Class Initialized
INFO - 2022-06-09 03:00:25 --> Language Class Initialized
INFO - 2022-06-09 03:00:25 --> Language Class Initialized
INFO - 2022-06-09 03:00:25 --> Config Class Initialized
INFO - 2022-06-09 03:00:25 --> Loader Class Initialized
INFO - 2022-06-09 03:00:25 --> Helper loaded: url_helper
INFO - 2022-06-09 03:00:25 --> Helper loaded: file_helper
INFO - 2022-06-09 03:00:25 --> Helper loaded: form_helper
INFO - 2022-06-09 03:00:25 --> Helper loaded: my_helper
INFO - 2022-06-09 03:00:25 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:00:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:00:25 --> Controller Class Initialized
INFO - 2022-06-09 03:00:29 --> Config Class Initialized
INFO - 2022-06-09 03:00:29 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:00:29 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:00:29 --> Utf8 Class Initialized
INFO - 2022-06-09 03:00:29 --> URI Class Initialized
INFO - 2022-06-09 03:00:29 --> Router Class Initialized
INFO - 2022-06-09 03:00:29 --> Output Class Initialized
INFO - 2022-06-09 03:00:29 --> Security Class Initialized
DEBUG - 2022-06-09 03:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:00:29 --> Input Class Initialized
INFO - 2022-06-09 03:00:29 --> Language Class Initialized
INFO - 2022-06-09 03:00:29 --> Language Class Initialized
INFO - 2022-06-09 03:00:29 --> Config Class Initialized
INFO - 2022-06-09 03:00:29 --> Loader Class Initialized
INFO - 2022-06-09 03:00:29 --> Helper loaded: url_helper
INFO - 2022-06-09 03:00:29 --> Helper loaded: file_helper
INFO - 2022-06-09 03:00:29 --> Helper loaded: form_helper
INFO - 2022-06-09 03:00:29 --> Helper loaded: my_helper
INFO - 2022-06-09 03:00:29 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:00:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:00:29 --> Controller Class Initialized
DEBUG - 2022-06-09 03:00:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form_import.php
DEBUG - 2022-06-09 03:00:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-09 03:00:29 --> Final output sent to browser
DEBUG - 2022-06-09 03:00:29 --> Total execution time: 0.0740
INFO - 2022-06-09 03:00:41 --> Config Class Initialized
INFO - 2022-06-09 03:00:41 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:00:41 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:00:41 --> Utf8 Class Initialized
INFO - 2022-06-09 03:00:41 --> URI Class Initialized
INFO - 2022-06-09 03:00:41 --> Router Class Initialized
INFO - 2022-06-09 03:00:41 --> Output Class Initialized
INFO - 2022-06-09 03:00:41 --> Security Class Initialized
DEBUG - 2022-06-09 03:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:00:41 --> Input Class Initialized
INFO - 2022-06-09 03:00:41 --> Language Class Initialized
INFO - 2022-06-09 03:00:41 --> Language Class Initialized
INFO - 2022-06-09 03:00:41 --> Config Class Initialized
INFO - 2022-06-09 03:00:41 --> Loader Class Initialized
INFO - 2022-06-09 03:00:41 --> Helper loaded: url_helper
INFO - 2022-06-09 03:00:41 --> Helper loaded: file_helper
INFO - 2022-06-09 03:00:41 --> Helper loaded: form_helper
INFO - 2022-06-09 03:00:41 --> Helper loaded: my_helper
INFO - 2022-06-09 03:00:41 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:00:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:00:41 --> Controller Class Initialized
INFO - 2022-06-09 03:00:44 --> Config Class Initialized
INFO - 2022-06-09 03:00:44 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:00:44 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:00:44 --> Utf8 Class Initialized
INFO - 2022-06-09 03:00:44 --> URI Class Initialized
INFO - 2022-06-09 03:00:44 --> Router Class Initialized
INFO - 2022-06-09 03:00:44 --> Output Class Initialized
INFO - 2022-06-09 03:00:44 --> Security Class Initialized
DEBUG - 2022-06-09 03:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:00:44 --> Input Class Initialized
INFO - 2022-06-09 03:00:44 --> Language Class Initialized
INFO - 2022-06-09 03:00:44 --> Language Class Initialized
INFO - 2022-06-09 03:00:44 --> Config Class Initialized
INFO - 2022-06-09 03:00:44 --> Loader Class Initialized
INFO - 2022-06-09 03:00:44 --> Helper loaded: url_helper
INFO - 2022-06-09 03:00:44 --> Helper loaded: file_helper
INFO - 2022-06-09 03:00:44 --> Helper loaded: form_helper
INFO - 2022-06-09 03:00:44 --> Helper loaded: my_helper
INFO - 2022-06-09 03:00:44 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:00:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:00:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:00:44 --> Controller Class Initialized
DEBUG - 2022-06-09 03:00:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form_import.php
DEBUG - 2022-06-09 03:00:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-09 03:00:44 --> Final output sent to browser
DEBUG - 2022-06-09 03:00:44 --> Total execution time: 0.0678
INFO - 2022-06-09 03:00:47 --> Config Class Initialized
INFO - 2022-06-09 03:00:47 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:00:47 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:00:47 --> Utf8 Class Initialized
INFO - 2022-06-09 03:00:47 --> URI Class Initialized
INFO - 2022-06-09 03:00:47 --> Router Class Initialized
INFO - 2022-06-09 03:00:47 --> Output Class Initialized
INFO - 2022-06-09 03:00:47 --> Security Class Initialized
DEBUG - 2022-06-09 03:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:00:47 --> Input Class Initialized
INFO - 2022-06-09 03:00:47 --> Language Class Initialized
INFO - 2022-06-09 03:00:47 --> Language Class Initialized
INFO - 2022-06-09 03:00:47 --> Config Class Initialized
INFO - 2022-06-09 03:00:47 --> Loader Class Initialized
INFO - 2022-06-09 03:00:47 --> Helper loaded: url_helper
INFO - 2022-06-09 03:00:47 --> Helper loaded: file_helper
INFO - 2022-06-09 03:00:47 --> Helper loaded: form_helper
INFO - 2022-06-09 03:00:47 --> Helper loaded: my_helper
INFO - 2022-06-09 03:00:47 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:00:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:00:47 --> Controller Class Initialized
DEBUG - 2022-06-09 03:00:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2022-06-09 03:00:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-09 03:00:47 --> Final output sent to browser
DEBUG - 2022-06-09 03:00:47 --> Total execution time: 0.0582
INFO - 2022-06-09 03:00:47 --> Config Class Initialized
INFO - 2022-06-09 03:00:47 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:00:47 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:00:47 --> Utf8 Class Initialized
INFO - 2022-06-09 03:00:47 --> URI Class Initialized
INFO - 2022-06-09 03:00:47 --> Router Class Initialized
INFO - 2022-06-09 03:00:47 --> Output Class Initialized
INFO - 2022-06-09 03:00:47 --> Security Class Initialized
DEBUG - 2022-06-09 03:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:00:47 --> Input Class Initialized
INFO - 2022-06-09 03:00:47 --> Language Class Initialized
INFO - 2022-06-09 03:00:47 --> Language Class Initialized
INFO - 2022-06-09 03:00:47 --> Config Class Initialized
INFO - 2022-06-09 03:00:47 --> Loader Class Initialized
INFO - 2022-06-09 03:00:47 --> Helper loaded: url_helper
INFO - 2022-06-09 03:00:47 --> Helper loaded: file_helper
INFO - 2022-06-09 03:00:47 --> Helper loaded: form_helper
INFO - 2022-06-09 03:00:47 --> Helper loaded: my_helper
INFO - 2022-06-09 03:00:47 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:00:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:00:47 --> Controller Class Initialized
INFO - 2022-06-09 03:00:51 --> Config Class Initialized
INFO - 2022-06-09 03:00:51 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:00:51 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:00:51 --> Utf8 Class Initialized
INFO - 2022-06-09 03:00:51 --> URI Class Initialized
INFO - 2022-06-09 03:00:51 --> Router Class Initialized
INFO - 2022-06-09 03:00:51 --> Output Class Initialized
INFO - 2022-06-09 03:00:51 --> Security Class Initialized
DEBUG - 2022-06-09 03:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:00:51 --> Input Class Initialized
INFO - 2022-06-09 03:00:51 --> Language Class Initialized
INFO - 2022-06-09 03:00:51 --> Language Class Initialized
INFO - 2022-06-09 03:00:51 --> Config Class Initialized
INFO - 2022-06-09 03:00:51 --> Loader Class Initialized
INFO - 2022-06-09 03:00:51 --> Helper loaded: url_helper
INFO - 2022-06-09 03:00:51 --> Helper loaded: file_helper
INFO - 2022-06-09 03:00:51 --> Helper loaded: form_helper
INFO - 2022-06-09 03:00:51 --> Helper loaded: my_helper
INFO - 2022-06-09 03:00:51 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:00:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:00:51 --> Controller Class Initialized
ERROR - 2022-06-09 03:00:51 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2022-06-09 03:00:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2022-06-09 03:00:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-09 03:00:51 --> Final output sent to browser
DEBUG - 2022-06-09 03:00:51 --> Total execution time: 0.1089
INFO - 2022-06-09 03:00:55 --> Config Class Initialized
INFO - 2022-06-09 03:00:55 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:00:55 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:00:55 --> Utf8 Class Initialized
INFO - 2022-06-09 03:00:55 --> URI Class Initialized
INFO - 2022-06-09 03:00:55 --> Router Class Initialized
INFO - 2022-06-09 03:00:55 --> Output Class Initialized
INFO - 2022-06-09 03:00:55 --> Security Class Initialized
DEBUG - 2022-06-09 03:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:00:55 --> Input Class Initialized
INFO - 2022-06-09 03:00:55 --> Language Class Initialized
INFO - 2022-06-09 03:00:55 --> Language Class Initialized
INFO - 2022-06-09 03:00:55 --> Config Class Initialized
INFO - 2022-06-09 03:00:55 --> Loader Class Initialized
INFO - 2022-06-09 03:00:55 --> Helper loaded: url_helper
INFO - 2022-06-09 03:00:55 --> Helper loaded: file_helper
INFO - 2022-06-09 03:00:55 --> Helper loaded: form_helper
INFO - 2022-06-09 03:00:55 --> Helper loaded: my_helper
INFO - 2022-06-09 03:00:55 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:00:55 --> Controller Class Initialized
DEBUG - 2022-06-09 03:00:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2022-06-09 03:00:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-09 03:00:55 --> Final output sent to browser
DEBUG - 2022-06-09 03:00:55 --> Total execution time: 0.0576
INFO - 2022-06-09 03:00:55 --> Config Class Initialized
INFO - 2022-06-09 03:00:55 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:00:55 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:00:55 --> Utf8 Class Initialized
INFO - 2022-06-09 03:00:55 --> URI Class Initialized
INFO - 2022-06-09 03:00:55 --> Router Class Initialized
INFO - 2022-06-09 03:00:55 --> Output Class Initialized
INFO - 2022-06-09 03:00:55 --> Security Class Initialized
DEBUG - 2022-06-09 03:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:00:55 --> Input Class Initialized
INFO - 2022-06-09 03:00:55 --> Language Class Initialized
INFO - 2022-06-09 03:00:55 --> Language Class Initialized
INFO - 2022-06-09 03:00:55 --> Config Class Initialized
INFO - 2022-06-09 03:00:55 --> Loader Class Initialized
INFO - 2022-06-09 03:00:55 --> Helper loaded: url_helper
INFO - 2022-06-09 03:00:55 --> Helper loaded: file_helper
INFO - 2022-06-09 03:00:55 --> Helper loaded: form_helper
INFO - 2022-06-09 03:00:55 --> Helper loaded: my_helper
INFO - 2022-06-09 03:00:55 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:00:55 --> Controller Class Initialized
INFO - 2022-06-09 03:01:35 --> Config Class Initialized
INFO - 2022-06-09 03:01:35 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:01:35 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:01:35 --> Utf8 Class Initialized
INFO - 2022-06-09 03:01:35 --> URI Class Initialized
INFO - 2022-06-09 03:01:35 --> Router Class Initialized
INFO - 2022-06-09 03:01:35 --> Output Class Initialized
INFO - 2022-06-09 03:01:35 --> Security Class Initialized
DEBUG - 2022-06-09 03:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:01:35 --> Input Class Initialized
INFO - 2022-06-09 03:01:35 --> Language Class Initialized
INFO - 2022-06-09 03:01:35 --> Language Class Initialized
INFO - 2022-06-09 03:01:35 --> Config Class Initialized
INFO - 2022-06-09 03:01:35 --> Loader Class Initialized
INFO - 2022-06-09 03:01:35 --> Helper loaded: url_helper
INFO - 2022-06-09 03:01:35 --> Helper loaded: file_helper
INFO - 2022-06-09 03:01:35 --> Helper loaded: form_helper
INFO - 2022-06-09 03:01:35 --> Helper loaded: my_helper
INFO - 2022-06-09 03:01:35 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:01:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:01:35 --> Controller Class Initialized
DEBUG - 2022-06-09 03:01:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2022-06-09 03:01:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-09 03:01:35 --> Final output sent to browser
DEBUG - 2022-06-09 03:01:35 --> Total execution time: 0.0664
INFO - 2022-06-09 03:01:35 --> Config Class Initialized
INFO - 2022-06-09 03:01:35 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:01:35 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:01:35 --> Utf8 Class Initialized
INFO - 2022-06-09 03:01:35 --> URI Class Initialized
INFO - 2022-06-09 03:01:35 --> Router Class Initialized
INFO - 2022-06-09 03:01:35 --> Output Class Initialized
INFO - 2022-06-09 03:01:35 --> Security Class Initialized
DEBUG - 2022-06-09 03:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:01:35 --> Input Class Initialized
INFO - 2022-06-09 03:01:35 --> Language Class Initialized
INFO - 2022-06-09 03:01:35 --> Language Class Initialized
INFO - 2022-06-09 03:01:35 --> Config Class Initialized
INFO - 2022-06-09 03:01:35 --> Loader Class Initialized
INFO - 2022-06-09 03:01:35 --> Helper loaded: url_helper
INFO - 2022-06-09 03:01:35 --> Helper loaded: file_helper
INFO - 2022-06-09 03:01:35 --> Helper loaded: form_helper
INFO - 2022-06-09 03:01:35 --> Helper loaded: my_helper
INFO - 2022-06-09 03:01:35 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:01:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:01:35 --> Controller Class Initialized
INFO - 2022-06-09 03:01:42 --> Config Class Initialized
INFO - 2022-06-09 03:01:42 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:01:42 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:01:42 --> Utf8 Class Initialized
INFO - 2022-06-09 03:01:42 --> URI Class Initialized
INFO - 2022-06-09 03:01:42 --> Router Class Initialized
INFO - 2022-06-09 03:01:42 --> Output Class Initialized
INFO - 2022-06-09 03:01:42 --> Security Class Initialized
DEBUG - 2022-06-09 03:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:01:42 --> Input Class Initialized
INFO - 2022-06-09 03:01:42 --> Language Class Initialized
INFO - 2022-06-09 03:01:42 --> Language Class Initialized
INFO - 2022-06-09 03:01:42 --> Config Class Initialized
INFO - 2022-06-09 03:01:42 --> Loader Class Initialized
INFO - 2022-06-09 03:01:42 --> Helper loaded: url_helper
INFO - 2022-06-09 03:01:42 --> Helper loaded: file_helper
INFO - 2022-06-09 03:01:42 --> Helper loaded: form_helper
INFO - 2022-06-09 03:01:42 --> Helper loaded: my_helper
INFO - 2022-06-09 03:01:42 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:01:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:01:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:01:42 --> Controller Class Initialized
INFO - 2022-06-09 03:01:42 --> Final output sent to browser
DEBUG - 2022-06-09 03:01:42 --> Total execution time: 0.0761
INFO - 2022-06-09 03:01:58 --> Config Class Initialized
INFO - 2022-06-09 03:01:58 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:01:58 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:01:58 --> Utf8 Class Initialized
INFO - 2022-06-09 03:01:58 --> URI Class Initialized
INFO - 2022-06-09 03:01:58 --> Router Class Initialized
INFO - 2022-06-09 03:01:58 --> Output Class Initialized
INFO - 2022-06-09 03:01:58 --> Security Class Initialized
DEBUG - 2022-06-09 03:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:01:58 --> Input Class Initialized
INFO - 2022-06-09 03:01:58 --> Language Class Initialized
INFO - 2022-06-09 03:01:58 --> Language Class Initialized
INFO - 2022-06-09 03:01:58 --> Config Class Initialized
INFO - 2022-06-09 03:01:58 --> Loader Class Initialized
INFO - 2022-06-09 03:01:58 --> Helper loaded: url_helper
INFO - 2022-06-09 03:01:58 --> Helper loaded: file_helper
INFO - 2022-06-09 03:01:58 --> Helper loaded: form_helper
INFO - 2022-06-09 03:01:58 --> Helper loaded: my_helper
INFO - 2022-06-09 03:01:58 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:01:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:01:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:01:58 --> Controller Class Initialized
INFO - 2022-06-09 03:01:58 --> Final output sent to browser
DEBUG - 2022-06-09 03:01:58 --> Total execution time: 0.0801
INFO - 2022-06-09 03:01:58 --> Config Class Initialized
INFO - 2022-06-09 03:01:58 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:01:58 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:01:58 --> Utf8 Class Initialized
INFO - 2022-06-09 03:01:58 --> URI Class Initialized
INFO - 2022-06-09 03:01:58 --> Router Class Initialized
INFO - 2022-06-09 03:01:58 --> Output Class Initialized
INFO - 2022-06-09 03:01:58 --> Security Class Initialized
DEBUG - 2022-06-09 03:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:01:58 --> Input Class Initialized
INFO - 2022-06-09 03:01:58 --> Language Class Initialized
INFO - 2022-06-09 03:01:58 --> Language Class Initialized
INFO - 2022-06-09 03:01:58 --> Config Class Initialized
INFO - 2022-06-09 03:01:58 --> Loader Class Initialized
INFO - 2022-06-09 03:01:58 --> Helper loaded: url_helper
INFO - 2022-06-09 03:01:58 --> Helper loaded: file_helper
INFO - 2022-06-09 03:01:58 --> Helper loaded: form_helper
INFO - 2022-06-09 03:01:58 --> Helper loaded: my_helper
INFO - 2022-06-09 03:01:58 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:01:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:01:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:01:58 --> Controller Class Initialized
INFO - 2022-06-09 03:02:06 --> Config Class Initialized
INFO - 2022-06-09 03:02:06 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:02:06 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:02:06 --> Utf8 Class Initialized
INFO - 2022-06-09 03:02:06 --> URI Class Initialized
INFO - 2022-06-09 03:02:06 --> Router Class Initialized
INFO - 2022-06-09 03:02:06 --> Output Class Initialized
INFO - 2022-06-09 03:02:06 --> Security Class Initialized
DEBUG - 2022-06-09 03:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:02:06 --> Input Class Initialized
INFO - 2022-06-09 03:02:06 --> Language Class Initialized
INFO - 2022-06-09 03:02:06 --> Language Class Initialized
INFO - 2022-06-09 03:02:06 --> Config Class Initialized
INFO - 2022-06-09 03:02:06 --> Loader Class Initialized
INFO - 2022-06-09 03:02:06 --> Helper loaded: url_helper
INFO - 2022-06-09 03:02:06 --> Helper loaded: file_helper
INFO - 2022-06-09 03:02:06 --> Helper loaded: form_helper
INFO - 2022-06-09 03:02:06 --> Helper loaded: my_helper
INFO - 2022-06-09 03:02:06 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:02:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:02:06 --> Controller Class Initialized
INFO - 2022-06-09 03:02:06 --> Final output sent to browser
DEBUG - 2022-06-09 03:02:06 --> Total execution time: 0.0745
INFO - 2022-06-09 03:02:11 --> Config Class Initialized
INFO - 2022-06-09 03:02:11 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:02:11 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:02:11 --> Utf8 Class Initialized
INFO - 2022-06-09 03:02:11 --> URI Class Initialized
INFO - 2022-06-09 03:02:11 --> Router Class Initialized
INFO - 2022-06-09 03:02:11 --> Output Class Initialized
INFO - 2022-06-09 03:02:11 --> Security Class Initialized
DEBUG - 2022-06-09 03:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:02:11 --> Input Class Initialized
INFO - 2022-06-09 03:02:11 --> Language Class Initialized
INFO - 2022-06-09 03:02:11 --> Language Class Initialized
INFO - 2022-06-09 03:02:11 --> Config Class Initialized
INFO - 2022-06-09 03:02:11 --> Loader Class Initialized
INFO - 2022-06-09 03:02:11 --> Helper loaded: url_helper
INFO - 2022-06-09 03:02:11 --> Helper loaded: file_helper
INFO - 2022-06-09 03:02:11 --> Helper loaded: form_helper
INFO - 2022-06-09 03:02:11 --> Helper loaded: my_helper
INFO - 2022-06-09 03:02:11 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:02:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:02:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:02:11 --> Controller Class Initialized
INFO - 2022-06-09 03:02:11 --> Final output sent to browser
DEBUG - 2022-06-09 03:02:11 --> Total execution time: 0.0680
INFO - 2022-06-09 03:02:11 --> Config Class Initialized
INFO - 2022-06-09 03:02:11 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:02:11 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:02:11 --> Utf8 Class Initialized
INFO - 2022-06-09 03:02:11 --> URI Class Initialized
INFO - 2022-06-09 03:02:11 --> Router Class Initialized
INFO - 2022-06-09 03:02:11 --> Output Class Initialized
INFO - 2022-06-09 03:02:11 --> Security Class Initialized
DEBUG - 2022-06-09 03:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:02:11 --> Input Class Initialized
INFO - 2022-06-09 03:02:11 --> Language Class Initialized
INFO - 2022-06-09 03:02:11 --> Language Class Initialized
INFO - 2022-06-09 03:02:11 --> Config Class Initialized
INFO - 2022-06-09 03:02:11 --> Loader Class Initialized
INFO - 2022-06-09 03:02:11 --> Helper loaded: url_helper
INFO - 2022-06-09 03:02:11 --> Helper loaded: file_helper
INFO - 2022-06-09 03:02:11 --> Helper loaded: form_helper
INFO - 2022-06-09 03:02:11 --> Helper loaded: my_helper
INFO - 2022-06-09 03:02:11 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:02:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:02:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:02:11 --> Controller Class Initialized
INFO - 2022-06-09 03:02:18 --> Config Class Initialized
INFO - 2022-06-09 03:02:18 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:02:18 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:02:18 --> Utf8 Class Initialized
INFO - 2022-06-09 03:02:18 --> URI Class Initialized
INFO - 2022-06-09 03:02:18 --> Router Class Initialized
INFO - 2022-06-09 03:02:18 --> Output Class Initialized
INFO - 2022-06-09 03:02:18 --> Security Class Initialized
DEBUG - 2022-06-09 03:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:02:18 --> Input Class Initialized
INFO - 2022-06-09 03:02:18 --> Language Class Initialized
INFO - 2022-06-09 03:02:18 --> Language Class Initialized
INFO - 2022-06-09 03:02:18 --> Config Class Initialized
INFO - 2022-06-09 03:02:18 --> Loader Class Initialized
INFO - 2022-06-09 03:02:18 --> Helper loaded: url_helper
INFO - 2022-06-09 03:02:18 --> Helper loaded: file_helper
INFO - 2022-06-09 03:02:18 --> Helper loaded: form_helper
INFO - 2022-06-09 03:02:18 --> Helper loaded: my_helper
INFO - 2022-06-09 03:02:18 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:02:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:02:18 --> Controller Class Initialized
INFO - 2022-06-09 03:02:18 --> Final output sent to browser
DEBUG - 2022-06-09 03:02:18 --> Total execution time: 0.0582
INFO - 2022-06-09 03:02:28 --> Config Class Initialized
INFO - 2022-06-09 03:02:28 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:02:28 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:02:28 --> Utf8 Class Initialized
INFO - 2022-06-09 03:02:28 --> URI Class Initialized
INFO - 2022-06-09 03:02:28 --> Router Class Initialized
INFO - 2022-06-09 03:02:28 --> Output Class Initialized
INFO - 2022-06-09 03:02:28 --> Security Class Initialized
DEBUG - 2022-06-09 03:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:02:28 --> Input Class Initialized
INFO - 2022-06-09 03:02:28 --> Language Class Initialized
INFO - 2022-06-09 03:02:28 --> Language Class Initialized
INFO - 2022-06-09 03:02:28 --> Config Class Initialized
INFO - 2022-06-09 03:02:28 --> Loader Class Initialized
INFO - 2022-06-09 03:02:28 --> Helper loaded: url_helper
INFO - 2022-06-09 03:02:28 --> Helper loaded: file_helper
INFO - 2022-06-09 03:02:28 --> Helper loaded: form_helper
INFO - 2022-06-09 03:02:28 --> Helper loaded: my_helper
INFO - 2022-06-09 03:02:28 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:02:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:02:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:02:28 --> Controller Class Initialized
INFO - 2022-06-09 03:02:28 --> Final output sent to browser
DEBUG - 2022-06-09 03:02:28 --> Total execution time: 0.0804
INFO - 2022-06-09 03:02:28 --> Config Class Initialized
INFO - 2022-06-09 03:02:28 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:02:28 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:02:28 --> Utf8 Class Initialized
INFO - 2022-06-09 03:02:28 --> URI Class Initialized
INFO - 2022-06-09 03:02:28 --> Router Class Initialized
INFO - 2022-06-09 03:02:28 --> Output Class Initialized
INFO - 2022-06-09 03:02:28 --> Security Class Initialized
DEBUG - 2022-06-09 03:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:02:28 --> Input Class Initialized
INFO - 2022-06-09 03:02:28 --> Language Class Initialized
INFO - 2022-06-09 03:02:28 --> Language Class Initialized
INFO - 2022-06-09 03:02:28 --> Config Class Initialized
INFO - 2022-06-09 03:02:28 --> Loader Class Initialized
INFO - 2022-06-09 03:02:28 --> Helper loaded: url_helper
INFO - 2022-06-09 03:02:28 --> Helper loaded: file_helper
INFO - 2022-06-09 03:02:28 --> Helper loaded: form_helper
INFO - 2022-06-09 03:02:28 --> Helper loaded: my_helper
INFO - 2022-06-09 03:02:28 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:02:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:02:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:02:28 --> Controller Class Initialized
INFO - 2022-06-09 03:02:36 --> Config Class Initialized
INFO - 2022-06-09 03:02:36 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:02:36 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:02:36 --> Utf8 Class Initialized
INFO - 2022-06-09 03:02:36 --> URI Class Initialized
INFO - 2022-06-09 03:02:36 --> Router Class Initialized
INFO - 2022-06-09 03:02:36 --> Output Class Initialized
INFO - 2022-06-09 03:02:36 --> Security Class Initialized
DEBUG - 2022-06-09 03:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:02:36 --> Input Class Initialized
INFO - 2022-06-09 03:02:36 --> Language Class Initialized
INFO - 2022-06-09 03:02:36 --> Language Class Initialized
INFO - 2022-06-09 03:02:36 --> Config Class Initialized
INFO - 2022-06-09 03:02:36 --> Loader Class Initialized
INFO - 2022-06-09 03:02:36 --> Helper loaded: url_helper
INFO - 2022-06-09 03:02:36 --> Helper loaded: file_helper
INFO - 2022-06-09 03:02:36 --> Helper loaded: form_helper
INFO - 2022-06-09 03:02:36 --> Helper loaded: my_helper
INFO - 2022-06-09 03:02:36 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:02:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:02:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:02:36 --> Controller Class Initialized
INFO - 2022-06-09 03:02:36 --> Final output sent to browser
DEBUG - 2022-06-09 03:02:36 --> Total execution time: 0.0528
INFO - 2022-06-09 03:02:43 --> Config Class Initialized
INFO - 2022-06-09 03:02:43 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:02:43 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:02:43 --> Utf8 Class Initialized
INFO - 2022-06-09 03:02:43 --> URI Class Initialized
INFO - 2022-06-09 03:02:43 --> Router Class Initialized
INFO - 2022-06-09 03:02:43 --> Output Class Initialized
INFO - 2022-06-09 03:02:43 --> Security Class Initialized
DEBUG - 2022-06-09 03:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:02:43 --> Input Class Initialized
INFO - 2022-06-09 03:02:43 --> Language Class Initialized
INFO - 2022-06-09 03:02:43 --> Language Class Initialized
INFO - 2022-06-09 03:02:43 --> Config Class Initialized
INFO - 2022-06-09 03:02:43 --> Loader Class Initialized
INFO - 2022-06-09 03:02:43 --> Helper loaded: url_helper
INFO - 2022-06-09 03:02:43 --> Helper loaded: file_helper
INFO - 2022-06-09 03:02:43 --> Helper loaded: form_helper
INFO - 2022-06-09 03:02:43 --> Helper loaded: my_helper
INFO - 2022-06-09 03:02:43 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:02:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:02:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:02:43 --> Controller Class Initialized
INFO - 2022-06-09 03:02:43 --> Final output sent to browser
DEBUG - 2022-06-09 03:02:43 --> Total execution time: 0.0743
INFO - 2022-06-09 03:02:43 --> Config Class Initialized
INFO - 2022-06-09 03:02:43 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:02:43 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:02:43 --> Utf8 Class Initialized
INFO - 2022-06-09 03:02:43 --> URI Class Initialized
INFO - 2022-06-09 03:02:43 --> Router Class Initialized
INFO - 2022-06-09 03:02:43 --> Output Class Initialized
INFO - 2022-06-09 03:02:43 --> Security Class Initialized
DEBUG - 2022-06-09 03:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:02:43 --> Input Class Initialized
INFO - 2022-06-09 03:02:43 --> Language Class Initialized
INFO - 2022-06-09 03:02:43 --> Language Class Initialized
INFO - 2022-06-09 03:02:43 --> Config Class Initialized
INFO - 2022-06-09 03:02:43 --> Loader Class Initialized
INFO - 2022-06-09 03:02:43 --> Helper loaded: url_helper
INFO - 2022-06-09 03:02:43 --> Helper loaded: file_helper
INFO - 2022-06-09 03:02:43 --> Helper loaded: form_helper
INFO - 2022-06-09 03:02:43 --> Helper loaded: my_helper
INFO - 2022-06-09 03:02:43 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:02:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:02:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:02:43 --> Controller Class Initialized
INFO - 2022-06-09 03:02:45 --> Config Class Initialized
INFO - 2022-06-09 03:02:45 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:02:45 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:02:45 --> Utf8 Class Initialized
INFO - 2022-06-09 03:02:45 --> URI Class Initialized
INFO - 2022-06-09 03:02:45 --> Router Class Initialized
INFO - 2022-06-09 03:02:45 --> Output Class Initialized
INFO - 2022-06-09 03:02:45 --> Security Class Initialized
DEBUG - 2022-06-09 03:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:02:45 --> Input Class Initialized
INFO - 2022-06-09 03:02:45 --> Language Class Initialized
INFO - 2022-06-09 03:02:45 --> Language Class Initialized
INFO - 2022-06-09 03:02:45 --> Config Class Initialized
INFO - 2022-06-09 03:02:45 --> Loader Class Initialized
INFO - 2022-06-09 03:02:45 --> Helper loaded: url_helper
INFO - 2022-06-09 03:02:45 --> Helper loaded: file_helper
INFO - 2022-06-09 03:02:45 --> Helper loaded: form_helper
INFO - 2022-06-09 03:02:45 --> Helper loaded: my_helper
INFO - 2022-06-09 03:02:45 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:02:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:02:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:02:45 --> Controller Class Initialized
INFO - 2022-06-09 03:02:45 --> Final output sent to browser
DEBUG - 2022-06-09 03:02:45 --> Total execution time: 0.0580
INFO - 2022-06-09 03:02:53 --> Config Class Initialized
INFO - 2022-06-09 03:02:53 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:02:53 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:02:53 --> Utf8 Class Initialized
INFO - 2022-06-09 03:02:53 --> URI Class Initialized
INFO - 2022-06-09 03:02:53 --> Router Class Initialized
INFO - 2022-06-09 03:02:53 --> Output Class Initialized
INFO - 2022-06-09 03:02:53 --> Security Class Initialized
DEBUG - 2022-06-09 03:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:02:53 --> Input Class Initialized
INFO - 2022-06-09 03:02:53 --> Language Class Initialized
INFO - 2022-06-09 03:02:53 --> Language Class Initialized
INFO - 2022-06-09 03:02:53 --> Config Class Initialized
INFO - 2022-06-09 03:02:53 --> Loader Class Initialized
INFO - 2022-06-09 03:02:53 --> Helper loaded: url_helper
INFO - 2022-06-09 03:02:53 --> Helper loaded: file_helper
INFO - 2022-06-09 03:02:53 --> Helper loaded: form_helper
INFO - 2022-06-09 03:02:53 --> Helper loaded: my_helper
INFO - 2022-06-09 03:02:53 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:02:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:02:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:02:53 --> Controller Class Initialized
INFO - 2022-06-09 03:02:53 --> Final output sent to browser
DEBUG - 2022-06-09 03:02:53 --> Total execution time: 0.0608
INFO - 2022-06-09 03:02:53 --> Config Class Initialized
INFO - 2022-06-09 03:02:53 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:02:53 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:02:53 --> Utf8 Class Initialized
INFO - 2022-06-09 03:02:53 --> URI Class Initialized
INFO - 2022-06-09 03:02:53 --> Router Class Initialized
INFO - 2022-06-09 03:02:53 --> Output Class Initialized
INFO - 2022-06-09 03:02:53 --> Security Class Initialized
DEBUG - 2022-06-09 03:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:02:53 --> Input Class Initialized
INFO - 2022-06-09 03:02:53 --> Language Class Initialized
INFO - 2022-06-09 03:02:53 --> Language Class Initialized
INFO - 2022-06-09 03:02:53 --> Config Class Initialized
INFO - 2022-06-09 03:02:53 --> Loader Class Initialized
INFO - 2022-06-09 03:02:53 --> Helper loaded: url_helper
INFO - 2022-06-09 03:02:53 --> Helper loaded: file_helper
INFO - 2022-06-09 03:02:53 --> Helper loaded: form_helper
INFO - 2022-06-09 03:02:53 --> Helper loaded: my_helper
INFO - 2022-06-09 03:02:53 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:02:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:02:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:02:53 --> Controller Class Initialized
INFO - 2022-06-09 03:03:15 --> Config Class Initialized
INFO - 2022-06-09 03:03:15 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:03:15 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:03:15 --> Utf8 Class Initialized
INFO - 2022-06-09 03:03:15 --> URI Class Initialized
INFO - 2022-06-09 03:03:15 --> Router Class Initialized
INFO - 2022-06-09 03:03:15 --> Output Class Initialized
INFO - 2022-06-09 03:03:15 --> Security Class Initialized
DEBUG - 2022-06-09 03:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:03:15 --> Input Class Initialized
INFO - 2022-06-09 03:03:15 --> Language Class Initialized
INFO - 2022-06-09 03:03:15 --> Language Class Initialized
INFO - 2022-06-09 03:03:15 --> Config Class Initialized
INFO - 2022-06-09 03:03:15 --> Loader Class Initialized
INFO - 2022-06-09 03:03:15 --> Helper loaded: url_helper
INFO - 2022-06-09 03:03:15 --> Helper loaded: file_helper
INFO - 2022-06-09 03:03:15 --> Helper loaded: form_helper
INFO - 2022-06-09 03:03:15 --> Helper loaded: my_helper
INFO - 2022-06-09 03:03:15 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:03:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:03:15 --> Controller Class Initialized
INFO - 2022-06-09 03:03:15 --> Final output sent to browser
DEBUG - 2022-06-09 03:03:15 --> Total execution time: 0.0683
INFO - 2022-06-09 03:03:23 --> Config Class Initialized
INFO - 2022-06-09 03:03:23 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:03:23 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:03:23 --> Utf8 Class Initialized
INFO - 2022-06-09 03:03:23 --> URI Class Initialized
INFO - 2022-06-09 03:03:23 --> Router Class Initialized
INFO - 2022-06-09 03:03:23 --> Output Class Initialized
INFO - 2022-06-09 03:03:23 --> Security Class Initialized
DEBUG - 2022-06-09 03:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:03:23 --> Input Class Initialized
INFO - 2022-06-09 03:03:23 --> Language Class Initialized
INFO - 2022-06-09 03:03:23 --> Language Class Initialized
INFO - 2022-06-09 03:03:23 --> Config Class Initialized
INFO - 2022-06-09 03:03:23 --> Loader Class Initialized
INFO - 2022-06-09 03:03:23 --> Helper loaded: url_helper
INFO - 2022-06-09 03:03:23 --> Helper loaded: file_helper
INFO - 2022-06-09 03:03:23 --> Helper loaded: form_helper
INFO - 2022-06-09 03:03:23 --> Helper loaded: my_helper
INFO - 2022-06-09 03:03:23 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:03:23 --> Controller Class Initialized
INFO - 2022-06-09 03:03:23 --> Final output sent to browser
DEBUG - 2022-06-09 03:03:23 --> Total execution time: 0.0630
INFO - 2022-06-09 03:03:23 --> Config Class Initialized
INFO - 2022-06-09 03:03:23 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:03:23 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:03:23 --> Utf8 Class Initialized
INFO - 2022-06-09 03:03:23 --> URI Class Initialized
INFO - 2022-06-09 03:03:23 --> Router Class Initialized
INFO - 2022-06-09 03:03:23 --> Output Class Initialized
INFO - 2022-06-09 03:03:23 --> Security Class Initialized
DEBUG - 2022-06-09 03:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:03:23 --> Input Class Initialized
INFO - 2022-06-09 03:03:23 --> Language Class Initialized
INFO - 2022-06-09 03:03:23 --> Language Class Initialized
INFO - 2022-06-09 03:03:23 --> Config Class Initialized
INFO - 2022-06-09 03:03:23 --> Loader Class Initialized
INFO - 2022-06-09 03:03:23 --> Helper loaded: url_helper
INFO - 2022-06-09 03:03:23 --> Helper loaded: file_helper
INFO - 2022-06-09 03:03:23 --> Helper loaded: form_helper
INFO - 2022-06-09 03:03:23 --> Helper loaded: my_helper
INFO - 2022-06-09 03:03:23 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:03:23 --> Controller Class Initialized
INFO - 2022-06-09 03:03:24 --> Config Class Initialized
INFO - 2022-06-09 03:03:24 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:03:24 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:03:24 --> Utf8 Class Initialized
INFO - 2022-06-09 03:03:24 --> URI Class Initialized
INFO - 2022-06-09 03:03:24 --> Router Class Initialized
INFO - 2022-06-09 03:03:24 --> Output Class Initialized
INFO - 2022-06-09 03:03:24 --> Security Class Initialized
DEBUG - 2022-06-09 03:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:03:24 --> Input Class Initialized
INFO - 2022-06-09 03:03:24 --> Language Class Initialized
INFO - 2022-06-09 03:03:24 --> Language Class Initialized
INFO - 2022-06-09 03:03:24 --> Config Class Initialized
INFO - 2022-06-09 03:03:24 --> Loader Class Initialized
INFO - 2022-06-09 03:03:24 --> Helper loaded: url_helper
INFO - 2022-06-09 03:03:24 --> Helper loaded: file_helper
INFO - 2022-06-09 03:03:24 --> Helper loaded: form_helper
INFO - 2022-06-09 03:03:24 --> Helper loaded: my_helper
INFO - 2022-06-09 03:03:24 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:03:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:03:24 --> Controller Class Initialized
INFO - 2022-06-09 03:03:24 --> Final output sent to browser
DEBUG - 2022-06-09 03:03:24 --> Total execution time: 0.0669
INFO - 2022-06-09 03:03:30 --> Config Class Initialized
INFO - 2022-06-09 03:03:30 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:03:30 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:03:30 --> Utf8 Class Initialized
INFO - 2022-06-09 03:03:30 --> URI Class Initialized
INFO - 2022-06-09 03:03:30 --> Router Class Initialized
INFO - 2022-06-09 03:03:30 --> Output Class Initialized
INFO - 2022-06-09 03:03:30 --> Security Class Initialized
DEBUG - 2022-06-09 03:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:03:30 --> Input Class Initialized
INFO - 2022-06-09 03:03:30 --> Language Class Initialized
INFO - 2022-06-09 03:03:30 --> Language Class Initialized
INFO - 2022-06-09 03:03:30 --> Config Class Initialized
INFO - 2022-06-09 03:03:30 --> Loader Class Initialized
INFO - 2022-06-09 03:03:30 --> Helper loaded: url_helper
INFO - 2022-06-09 03:03:30 --> Helper loaded: file_helper
INFO - 2022-06-09 03:03:30 --> Helper loaded: form_helper
INFO - 2022-06-09 03:03:30 --> Helper loaded: my_helper
INFO - 2022-06-09 03:03:30 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:03:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:03:30 --> Controller Class Initialized
INFO - 2022-06-09 03:03:30 --> Final output sent to browser
DEBUG - 2022-06-09 03:03:30 --> Total execution time: 0.0592
INFO - 2022-06-09 03:03:30 --> Config Class Initialized
INFO - 2022-06-09 03:03:30 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:03:30 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:03:30 --> Utf8 Class Initialized
INFO - 2022-06-09 03:03:30 --> URI Class Initialized
INFO - 2022-06-09 03:03:30 --> Router Class Initialized
INFO - 2022-06-09 03:03:30 --> Output Class Initialized
INFO - 2022-06-09 03:03:30 --> Security Class Initialized
DEBUG - 2022-06-09 03:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:03:30 --> Input Class Initialized
INFO - 2022-06-09 03:03:30 --> Language Class Initialized
INFO - 2022-06-09 03:03:30 --> Language Class Initialized
INFO - 2022-06-09 03:03:30 --> Config Class Initialized
INFO - 2022-06-09 03:03:30 --> Loader Class Initialized
INFO - 2022-06-09 03:03:30 --> Helper loaded: url_helper
INFO - 2022-06-09 03:03:30 --> Helper loaded: file_helper
INFO - 2022-06-09 03:03:30 --> Helper loaded: form_helper
INFO - 2022-06-09 03:03:30 --> Helper loaded: my_helper
INFO - 2022-06-09 03:03:30 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:03:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:03:30 --> Controller Class Initialized
INFO - 2022-06-09 03:03:37 --> Config Class Initialized
INFO - 2022-06-09 03:03:37 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:03:37 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:03:37 --> Utf8 Class Initialized
INFO - 2022-06-09 03:03:37 --> URI Class Initialized
INFO - 2022-06-09 03:03:37 --> Router Class Initialized
INFO - 2022-06-09 03:03:37 --> Output Class Initialized
INFO - 2022-06-09 03:03:37 --> Security Class Initialized
DEBUG - 2022-06-09 03:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:03:37 --> Input Class Initialized
INFO - 2022-06-09 03:03:37 --> Language Class Initialized
INFO - 2022-06-09 03:03:37 --> Language Class Initialized
INFO - 2022-06-09 03:03:37 --> Config Class Initialized
INFO - 2022-06-09 03:03:37 --> Loader Class Initialized
INFO - 2022-06-09 03:03:37 --> Helper loaded: url_helper
INFO - 2022-06-09 03:03:37 --> Helper loaded: file_helper
INFO - 2022-06-09 03:03:37 --> Helper loaded: form_helper
INFO - 2022-06-09 03:03:37 --> Helper loaded: my_helper
INFO - 2022-06-09 03:03:37 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:03:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:03:37 --> Controller Class Initialized
INFO - 2022-06-09 03:03:37 --> Final output sent to browser
DEBUG - 2022-06-09 03:03:37 --> Total execution time: 0.0619
INFO - 2022-06-09 03:03:42 --> Config Class Initialized
INFO - 2022-06-09 03:03:42 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:03:42 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:03:42 --> Utf8 Class Initialized
INFO - 2022-06-09 03:03:42 --> URI Class Initialized
INFO - 2022-06-09 03:03:42 --> Router Class Initialized
INFO - 2022-06-09 03:03:42 --> Output Class Initialized
INFO - 2022-06-09 03:03:42 --> Security Class Initialized
DEBUG - 2022-06-09 03:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:03:42 --> Input Class Initialized
INFO - 2022-06-09 03:03:42 --> Language Class Initialized
INFO - 2022-06-09 03:03:42 --> Language Class Initialized
INFO - 2022-06-09 03:03:42 --> Config Class Initialized
INFO - 2022-06-09 03:03:42 --> Loader Class Initialized
INFO - 2022-06-09 03:03:42 --> Helper loaded: url_helper
INFO - 2022-06-09 03:03:42 --> Helper loaded: file_helper
INFO - 2022-06-09 03:03:42 --> Helper loaded: form_helper
INFO - 2022-06-09 03:03:42 --> Helper loaded: my_helper
INFO - 2022-06-09 03:03:42 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:03:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:03:42 --> Controller Class Initialized
INFO - 2022-06-09 03:03:42 --> Final output sent to browser
DEBUG - 2022-06-09 03:03:42 --> Total execution time: 0.0530
INFO - 2022-06-09 03:03:42 --> Config Class Initialized
INFO - 2022-06-09 03:03:42 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:03:42 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:03:42 --> Utf8 Class Initialized
INFO - 2022-06-09 03:03:42 --> URI Class Initialized
INFO - 2022-06-09 03:03:42 --> Router Class Initialized
INFO - 2022-06-09 03:03:42 --> Output Class Initialized
INFO - 2022-06-09 03:03:42 --> Security Class Initialized
DEBUG - 2022-06-09 03:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:03:42 --> Input Class Initialized
INFO - 2022-06-09 03:03:42 --> Language Class Initialized
INFO - 2022-06-09 03:03:42 --> Language Class Initialized
INFO - 2022-06-09 03:03:42 --> Config Class Initialized
INFO - 2022-06-09 03:03:42 --> Loader Class Initialized
INFO - 2022-06-09 03:03:42 --> Helper loaded: url_helper
INFO - 2022-06-09 03:03:42 --> Helper loaded: file_helper
INFO - 2022-06-09 03:03:42 --> Helper loaded: form_helper
INFO - 2022-06-09 03:03:42 --> Helper loaded: my_helper
INFO - 2022-06-09 03:03:42 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:03:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:03:42 --> Controller Class Initialized
INFO - 2022-06-09 03:03:48 --> Config Class Initialized
INFO - 2022-06-09 03:03:48 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:03:48 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:03:48 --> Utf8 Class Initialized
INFO - 2022-06-09 03:03:48 --> URI Class Initialized
INFO - 2022-06-09 03:03:48 --> Router Class Initialized
INFO - 2022-06-09 03:03:48 --> Output Class Initialized
INFO - 2022-06-09 03:03:48 --> Security Class Initialized
DEBUG - 2022-06-09 03:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:03:48 --> Input Class Initialized
INFO - 2022-06-09 03:03:48 --> Language Class Initialized
INFO - 2022-06-09 03:03:48 --> Language Class Initialized
INFO - 2022-06-09 03:03:48 --> Config Class Initialized
INFO - 2022-06-09 03:03:48 --> Loader Class Initialized
INFO - 2022-06-09 03:03:48 --> Helper loaded: url_helper
INFO - 2022-06-09 03:03:48 --> Helper loaded: file_helper
INFO - 2022-06-09 03:03:48 --> Helper loaded: form_helper
INFO - 2022-06-09 03:03:48 --> Helper loaded: my_helper
INFO - 2022-06-09 03:03:48 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:03:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:03:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:03:48 --> Controller Class Initialized
INFO - 2022-06-09 03:03:48 --> Final output sent to browser
DEBUG - 2022-06-09 03:03:48 --> Total execution time: 0.0712
INFO - 2022-06-09 03:03:54 --> Config Class Initialized
INFO - 2022-06-09 03:03:54 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:03:54 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:03:54 --> Utf8 Class Initialized
INFO - 2022-06-09 03:03:54 --> URI Class Initialized
INFO - 2022-06-09 03:03:54 --> Router Class Initialized
INFO - 2022-06-09 03:03:54 --> Output Class Initialized
INFO - 2022-06-09 03:03:54 --> Security Class Initialized
DEBUG - 2022-06-09 03:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:03:54 --> Input Class Initialized
INFO - 2022-06-09 03:03:54 --> Language Class Initialized
INFO - 2022-06-09 03:03:54 --> Language Class Initialized
INFO - 2022-06-09 03:03:54 --> Config Class Initialized
INFO - 2022-06-09 03:03:54 --> Loader Class Initialized
INFO - 2022-06-09 03:03:54 --> Helper loaded: url_helper
INFO - 2022-06-09 03:03:54 --> Helper loaded: file_helper
INFO - 2022-06-09 03:03:54 --> Helper loaded: form_helper
INFO - 2022-06-09 03:03:54 --> Helper loaded: my_helper
INFO - 2022-06-09 03:03:54 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:03:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:03:54 --> Controller Class Initialized
INFO - 2022-06-09 03:03:54 --> Final output sent to browser
DEBUG - 2022-06-09 03:03:54 --> Total execution time: 0.0789
INFO - 2022-06-09 03:03:54 --> Config Class Initialized
INFO - 2022-06-09 03:03:54 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:03:54 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:03:54 --> Utf8 Class Initialized
INFO - 2022-06-09 03:03:54 --> URI Class Initialized
INFO - 2022-06-09 03:03:54 --> Router Class Initialized
INFO - 2022-06-09 03:03:54 --> Output Class Initialized
INFO - 2022-06-09 03:03:54 --> Security Class Initialized
DEBUG - 2022-06-09 03:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:03:54 --> Input Class Initialized
INFO - 2022-06-09 03:03:54 --> Language Class Initialized
INFO - 2022-06-09 03:03:54 --> Language Class Initialized
INFO - 2022-06-09 03:03:54 --> Config Class Initialized
INFO - 2022-06-09 03:03:54 --> Loader Class Initialized
INFO - 2022-06-09 03:03:54 --> Helper loaded: url_helper
INFO - 2022-06-09 03:03:54 --> Helper loaded: file_helper
INFO - 2022-06-09 03:03:54 --> Helper loaded: form_helper
INFO - 2022-06-09 03:03:54 --> Helper loaded: my_helper
INFO - 2022-06-09 03:03:54 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:03:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:03:54 --> Controller Class Initialized
INFO - 2022-06-09 03:04:06 --> Config Class Initialized
INFO - 2022-06-09 03:04:06 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:04:06 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:04:06 --> Utf8 Class Initialized
INFO - 2022-06-09 03:04:06 --> URI Class Initialized
INFO - 2022-06-09 03:04:06 --> Router Class Initialized
INFO - 2022-06-09 03:04:06 --> Output Class Initialized
INFO - 2022-06-09 03:04:06 --> Security Class Initialized
DEBUG - 2022-06-09 03:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:04:06 --> Input Class Initialized
INFO - 2022-06-09 03:04:06 --> Language Class Initialized
INFO - 2022-06-09 03:04:06 --> Language Class Initialized
INFO - 2022-06-09 03:04:06 --> Config Class Initialized
INFO - 2022-06-09 03:04:06 --> Loader Class Initialized
INFO - 2022-06-09 03:04:06 --> Helper loaded: url_helper
INFO - 2022-06-09 03:04:06 --> Helper loaded: file_helper
INFO - 2022-06-09 03:04:06 --> Helper loaded: form_helper
INFO - 2022-06-09 03:04:06 --> Helper loaded: my_helper
INFO - 2022-06-09 03:04:06 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:04:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:04:06 --> Controller Class Initialized
INFO - 2022-06-09 03:04:06 --> Final output sent to browser
DEBUG - 2022-06-09 03:04:06 --> Total execution time: 0.0615
INFO - 2022-06-09 03:04:12 --> Config Class Initialized
INFO - 2022-06-09 03:04:12 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:04:12 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:04:12 --> Utf8 Class Initialized
INFO - 2022-06-09 03:04:12 --> URI Class Initialized
INFO - 2022-06-09 03:04:12 --> Router Class Initialized
INFO - 2022-06-09 03:04:12 --> Output Class Initialized
INFO - 2022-06-09 03:04:12 --> Security Class Initialized
DEBUG - 2022-06-09 03:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:04:12 --> Input Class Initialized
INFO - 2022-06-09 03:04:12 --> Language Class Initialized
INFO - 2022-06-09 03:04:12 --> Language Class Initialized
INFO - 2022-06-09 03:04:12 --> Config Class Initialized
INFO - 2022-06-09 03:04:12 --> Loader Class Initialized
INFO - 2022-06-09 03:04:12 --> Helper loaded: url_helper
INFO - 2022-06-09 03:04:12 --> Helper loaded: file_helper
INFO - 2022-06-09 03:04:12 --> Helper loaded: form_helper
INFO - 2022-06-09 03:04:12 --> Helper loaded: my_helper
INFO - 2022-06-09 03:04:12 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:04:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:04:12 --> Controller Class Initialized
INFO - 2022-06-09 03:04:12 --> Final output sent to browser
DEBUG - 2022-06-09 03:04:12 --> Total execution time: 0.0582
INFO - 2022-06-09 03:04:12 --> Config Class Initialized
INFO - 2022-06-09 03:04:12 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:04:12 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:04:12 --> Utf8 Class Initialized
INFO - 2022-06-09 03:04:12 --> URI Class Initialized
INFO - 2022-06-09 03:04:12 --> Router Class Initialized
INFO - 2022-06-09 03:04:12 --> Output Class Initialized
INFO - 2022-06-09 03:04:12 --> Security Class Initialized
DEBUG - 2022-06-09 03:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:04:12 --> Input Class Initialized
INFO - 2022-06-09 03:04:12 --> Language Class Initialized
INFO - 2022-06-09 03:04:12 --> Language Class Initialized
INFO - 2022-06-09 03:04:12 --> Config Class Initialized
INFO - 2022-06-09 03:04:12 --> Loader Class Initialized
INFO - 2022-06-09 03:04:12 --> Helper loaded: url_helper
INFO - 2022-06-09 03:04:12 --> Helper loaded: file_helper
INFO - 2022-06-09 03:04:12 --> Helper loaded: form_helper
INFO - 2022-06-09 03:04:12 --> Helper loaded: my_helper
INFO - 2022-06-09 03:04:12 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:04:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:04:12 --> Controller Class Initialized
INFO - 2022-06-09 03:04:19 --> Config Class Initialized
INFO - 2022-06-09 03:04:19 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:04:19 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:04:19 --> Utf8 Class Initialized
INFO - 2022-06-09 03:04:19 --> URI Class Initialized
INFO - 2022-06-09 03:04:19 --> Router Class Initialized
INFO - 2022-06-09 03:04:19 --> Output Class Initialized
INFO - 2022-06-09 03:04:19 --> Security Class Initialized
DEBUG - 2022-06-09 03:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:04:19 --> Input Class Initialized
INFO - 2022-06-09 03:04:19 --> Language Class Initialized
INFO - 2022-06-09 03:04:19 --> Language Class Initialized
INFO - 2022-06-09 03:04:19 --> Config Class Initialized
INFO - 2022-06-09 03:04:19 --> Loader Class Initialized
INFO - 2022-06-09 03:04:19 --> Helper loaded: url_helper
INFO - 2022-06-09 03:04:19 --> Helper loaded: file_helper
INFO - 2022-06-09 03:04:19 --> Helper loaded: form_helper
INFO - 2022-06-09 03:04:19 --> Helper loaded: my_helper
INFO - 2022-06-09 03:04:19 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:04:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:04:19 --> Controller Class Initialized
INFO - 2022-06-09 03:04:19 --> Final output sent to browser
DEBUG - 2022-06-09 03:04:19 --> Total execution time: 0.0675
INFO - 2022-06-09 03:04:25 --> Config Class Initialized
INFO - 2022-06-09 03:04:25 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:04:25 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:04:25 --> Utf8 Class Initialized
INFO - 2022-06-09 03:04:25 --> URI Class Initialized
INFO - 2022-06-09 03:04:25 --> Router Class Initialized
INFO - 2022-06-09 03:04:25 --> Output Class Initialized
INFO - 2022-06-09 03:04:25 --> Security Class Initialized
DEBUG - 2022-06-09 03:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:04:25 --> Input Class Initialized
INFO - 2022-06-09 03:04:25 --> Language Class Initialized
INFO - 2022-06-09 03:04:25 --> Language Class Initialized
INFO - 2022-06-09 03:04:25 --> Config Class Initialized
INFO - 2022-06-09 03:04:25 --> Loader Class Initialized
INFO - 2022-06-09 03:04:25 --> Helper loaded: url_helper
INFO - 2022-06-09 03:04:25 --> Helper loaded: file_helper
INFO - 2022-06-09 03:04:25 --> Helper loaded: form_helper
INFO - 2022-06-09 03:04:25 --> Helper loaded: my_helper
INFO - 2022-06-09 03:04:25 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:04:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:04:25 --> Controller Class Initialized
INFO - 2022-06-09 03:04:25 --> Final output sent to browser
DEBUG - 2022-06-09 03:04:25 --> Total execution time: 0.0814
INFO - 2022-06-09 03:04:25 --> Config Class Initialized
INFO - 2022-06-09 03:04:25 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:04:25 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:04:25 --> Utf8 Class Initialized
INFO - 2022-06-09 03:04:25 --> URI Class Initialized
INFO - 2022-06-09 03:04:25 --> Router Class Initialized
INFO - 2022-06-09 03:04:25 --> Output Class Initialized
INFO - 2022-06-09 03:04:25 --> Security Class Initialized
DEBUG - 2022-06-09 03:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:04:25 --> Input Class Initialized
INFO - 2022-06-09 03:04:25 --> Language Class Initialized
INFO - 2022-06-09 03:04:25 --> Language Class Initialized
INFO - 2022-06-09 03:04:25 --> Config Class Initialized
INFO - 2022-06-09 03:04:25 --> Loader Class Initialized
INFO - 2022-06-09 03:04:25 --> Helper loaded: url_helper
INFO - 2022-06-09 03:04:25 --> Helper loaded: file_helper
INFO - 2022-06-09 03:04:25 --> Helper loaded: form_helper
INFO - 2022-06-09 03:04:25 --> Helper loaded: my_helper
INFO - 2022-06-09 03:04:25 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:04:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:04:25 --> Controller Class Initialized
INFO - 2022-06-09 03:04:27 --> Config Class Initialized
INFO - 2022-06-09 03:04:27 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:04:27 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:04:27 --> Utf8 Class Initialized
INFO - 2022-06-09 03:04:27 --> URI Class Initialized
INFO - 2022-06-09 03:04:27 --> Router Class Initialized
INFO - 2022-06-09 03:04:27 --> Output Class Initialized
INFO - 2022-06-09 03:04:27 --> Security Class Initialized
DEBUG - 2022-06-09 03:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:04:27 --> Input Class Initialized
INFO - 2022-06-09 03:04:27 --> Language Class Initialized
INFO - 2022-06-09 03:04:27 --> Language Class Initialized
INFO - 2022-06-09 03:04:27 --> Config Class Initialized
INFO - 2022-06-09 03:04:27 --> Loader Class Initialized
INFO - 2022-06-09 03:04:27 --> Helper loaded: url_helper
INFO - 2022-06-09 03:04:27 --> Helper loaded: file_helper
INFO - 2022-06-09 03:04:27 --> Helper loaded: form_helper
INFO - 2022-06-09 03:04:27 --> Helper loaded: my_helper
INFO - 2022-06-09 03:04:27 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:04:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:04:27 --> Controller Class Initialized
INFO - 2022-06-09 03:04:27 --> Final output sent to browser
DEBUG - 2022-06-09 03:04:27 --> Total execution time: 0.0757
INFO - 2022-06-09 03:04:34 --> Config Class Initialized
INFO - 2022-06-09 03:04:34 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:04:34 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:04:34 --> Utf8 Class Initialized
INFO - 2022-06-09 03:04:34 --> URI Class Initialized
INFO - 2022-06-09 03:04:34 --> Router Class Initialized
INFO - 2022-06-09 03:04:34 --> Output Class Initialized
INFO - 2022-06-09 03:04:34 --> Security Class Initialized
DEBUG - 2022-06-09 03:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:04:34 --> Input Class Initialized
INFO - 2022-06-09 03:04:34 --> Language Class Initialized
INFO - 2022-06-09 03:04:34 --> Language Class Initialized
INFO - 2022-06-09 03:04:34 --> Config Class Initialized
INFO - 2022-06-09 03:04:34 --> Loader Class Initialized
INFO - 2022-06-09 03:04:34 --> Helper loaded: url_helper
INFO - 2022-06-09 03:04:34 --> Helper loaded: file_helper
INFO - 2022-06-09 03:04:34 --> Helper loaded: form_helper
INFO - 2022-06-09 03:04:34 --> Helper loaded: my_helper
INFO - 2022-06-09 03:04:34 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:04:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:04:34 --> Controller Class Initialized
INFO - 2022-06-09 03:04:34 --> Final output sent to browser
DEBUG - 2022-06-09 03:04:34 --> Total execution time: 0.0755
INFO - 2022-06-09 03:04:34 --> Config Class Initialized
INFO - 2022-06-09 03:04:34 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:04:34 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:04:34 --> Utf8 Class Initialized
INFO - 2022-06-09 03:04:34 --> URI Class Initialized
INFO - 2022-06-09 03:04:34 --> Router Class Initialized
INFO - 2022-06-09 03:04:34 --> Output Class Initialized
INFO - 2022-06-09 03:04:34 --> Security Class Initialized
DEBUG - 2022-06-09 03:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:04:34 --> Input Class Initialized
INFO - 2022-06-09 03:04:34 --> Language Class Initialized
INFO - 2022-06-09 03:04:34 --> Language Class Initialized
INFO - 2022-06-09 03:04:34 --> Config Class Initialized
INFO - 2022-06-09 03:04:34 --> Loader Class Initialized
INFO - 2022-06-09 03:04:34 --> Helper loaded: url_helper
INFO - 2022-06-09 03:04:34 --> Helper loaded: file_helper
INFO - 2022-06-09 03:04:34 --> Helper loaded: form_helper
INFO - 2022-06-09 03:04:34 --> Helper loaded: my_helper
INFO - 2022-06-09 03:04:34 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:04:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:04:34 --> Controller Class Initialized
INFO - 2022-06-09 03:04:47 --> Config Class Initialized
INFO - 2022-06-09 03:04:47 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:04:47 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:04:47 --> Utf8 Class Initialized
INFO - 2022-06-09 03:04:47 --> URI Class Initialized
INFO - 2022-06-09 03:04:47 --> Router Class Initialized
INFO - 2022-06-09 03:04:47 --> Output Class Initialized
INFO - 2022-06-09 03:04:47 --> Security Class Initialized
DEBUG - 2022-06-09 03:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:04:47 --> Input Class Initialized
INFO - 2022-06-09 03:04:47 --> Language Class Initialized
INFO - 2022-06-09 03:04:47 --> Language Class Initialized
INFO - 2022-06-09 03:04:47 --> Config Class Initialized
INFO - 2022-06-09 03:04:47 --> Loader Class Initialized
INFO - 2022-06-09 03:04:47 --> Helper loaded: url_helper
INFO - 2022-06-09 03:04:47 --> Helper loaded: file_helper
INFO - 2022-06-09 03:04:47 --> Helper loaded: form_helper
INFO - 2022-06-09 03:04:47 --> Helper loaded: my_helper
INFO - 2022-06-09 03:04:47 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:04:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:04:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:04:47 --> Controller Class Initialized
INFO - 2022-06-09 03:04:47 --> Final output sent to browser
DEBUG - 2022-06-09 03:04:47 --> Total execution time: 0.0772
INFO - 2022-06-09 03:04:59 --> Config Class Initialized
INFO - 2022-06-09 03:04:59 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:04:59 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:04:59 --> Utf8 Class Initialized
INFO - 2022-06-09 03:04:59 --> URI Class Initialized
INFO - 2022-06-09 03:04:59 --> Router Class Initialized
INFO - 2022-06-09 03:04:59 --> Output Class Initialized
INFO - 2022-06-09 03:04:59 --> Security Class Initialized
DEBUG - 2022-06-09 03:04:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:04:59 --> Input Class Initialized
INFO - 2022-06-09 03:04:59 --> Language Class Initialized
INFO - 2022-06-09 03:04:59 --> Language Class Initialized
INFO - 2022-06-09 03:04:59 --> Config Class Initialized
INFO - 2022-06-09 03:04:59 --> Loader Class Initialized
INFO - 2022-06-09 03:04:59 --> Helper loaded: url_helper
INFO - 2022-06-09 03:04:59 --> Helper loaded: file_helper
INFO - 2022-06-09 03:04:59 --> Helper loaded: form_helper
INFO - 2022-06-09 03:04:59 --> Helper loaded: my_helper
INFO - 2022-06-09 03:04:59 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:04:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:04:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:04:59 --> Controller Class Initialized
INFO - 2022-06-09 03:04:59 --> Final output sent to browser
DEBUG - 2022-06-09 03:04:59 --> Total execution time: 0.0789
INFO - 2022-06-09 03:04:59 --> Config Class Initialized
INFO - 2022-06-09 03:04:59 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:04:59 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:04:59 --> Utf8 Class Initialized
INFO - 2022-06-09 03:04:59 --> URI Class Initialized
INFO - 2022-06-09 03:04:59 --> Router Class Initialized
INFO - 2022-06-09 03:04:59 --> Output Class Initialized
INFO - 2022-06-09 03:04:59 --> Security Class Initialized
DEBUG - 2022-06-09 03:04:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:04:59 --> Input Class Initialized
INFO - 2022-06-09 03:04:59 --> Language Class Initialized
INFO - 2022-06-09 03:04:59 --> Language Class Initialized
INFO - 2022-06-09 03:04:59 --> Config Class Initialized
INFO - 2022-06-09 03:04:59 --> Loader Class Initialized
INFO - 2022-06-09 03:04:59 --> Helper loaded: url_helper
INFO - 2022-06-09 03:04:59 --> Helper loaded: file_helper
INFO - 2022-06-09 03:04:59 --> Helper loaded: form_helper
INFO - 2022-06-09 03:04:59 --> Helper loaded: my_helper
INFO - 2022-06-09 03:04:59 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:04:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:04:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:04:59 --> Controller Class Initialized
INFO - 2022-06-09 03:05:00 --> Config Class Initialized
INFO - 2022-06-09 03:05:00 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:05:00 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:05:00 --> Utf8 Class Initialized
INFO - 2022-06-09 03:05:00 --> URI Class Initialized
INFO - 2022-06-09 03:05:00 --> Router Class Initialized
INFO - 2022-06-09 03:05:00 --> Output Class Initialized
INFO - 2022-06-09 03:05:00 --> Security Class Initialized
DEBUG - 2022-06-09 03:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:05:00 --> Input Class Initialized
INFO - 2022-06-09 03:05:00 --> Language Class Initialized
INFO - 2022-06-09 03:05:00 --> Language Class Initialized
INFO - 2022-06-09 03:05:00 --> Config Class Initialized
INFO - 2022-06-09 03:05:00 --> Loader Class Initialized
INFO - 2022-06-09 03:05:00 --> Helper loaded: url_helper
INFO - 2022-06-09 03:05:00 --> Helper loaded: file_helper
INFO - 2022-06-09 03:05:00 --> Helper loaded: form_helper
INFO - 2022-06-09 03:05:00 --> Helper loaded: my_helper
INFO - 2022-06-09 03:05:00 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:05:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:05:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:05:00 --> Controller Class Initialized
INFO - 2022-06-09 03:05:00 --> Final output sent to browser
DEBUG - 2022-06-09 03:05:00 --> Total execution time: 0.0745
INFO - 2022-06-09 03:05:10 --> Config Class Initialized
INFO - 2022-06-09 03:05:10 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:05:10 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:05:10 --> Utf8 Class Initialized
INFO - 2022-06-09 03:05:10 --> URI Class Initialized
INFO - 2022-06-09 03:05:10 --> Router Class Initialized
INFO - 2022-06-09 03:05:10 --> Output Class Initialized
INFO - 2022-06-09 03:05:10 --> Security Class Initialized
DEBUG - 2022-06-09 03:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:05:10 --> Input Class Initialized
INFO - 2022-06-09 03:05:10 --> Language Class Initialized
INFO - 2022-06-09 03:05:10 --> Language Class Initialized
INFO - 2022-06-09 03:05:10 --> Config Class Initialized
INFO - 2022-06-09 03:05:10 --> Loader Class Initialized
INFO - 2022-06-09 03:05:10 --> Helper loaded: url_helper
INFO - 2022-06-09 03:05:10 --> Helper loaded: file_helper
INFO - 2022-06-09 03:05:10 --> Helper loaded: form_helper
INFO - 2022-06-09 03:05:10 --> Helper loaded: my_helper
INFO - 2022-06-09 03:05:10 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:05:10 --> Controller Class Initialized
INFO - 2022-06-09 03:05:10 --> Final output sent to browser
DEBUG - 2022-06-09 03:05:10 --> Total execution time: 0.0794
INFO - 2022-06-09 03:05:10 --> Config Class Initialized
INFO - 2022-06-09 03:05:10 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:05:10 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:05:10 --> Utf8 Class Initialized
INFO - 2022-06-09 03:05:10 --> URI Class Initialized
INFO - 2022-06-09 03:05:10 --> Router Class Initialized
INFO - 2022-06-09 03:05:10 --> Output Class Initialized
INFO - 2022-06-09 03:05:10 --> Security Class Initialized
DEBUG - 2022-06-09 03:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:05:10 --> Input Class Initialized
INFO - 2022-06-09 03:05:10 --> Language Class Initialized
INFO - 2022-06-09 03:05:10 --> Language Class Initialized
INFO - 2022-06-09 03:05:10 --> Config Class Initialized
INFO - 2022-06-09 03:05:10 --> Loader Class Initialized
INFO - 2022-06-09 03:05:10 --> Helper loaded: url_helper
INFO - 2022-06-09 03:05:10 --> Helper loaded: file_helper
INFO - 2022-06-09 03:05:10 --> Helper loaded: form_helper
INFO - 2022-06-09 03:05:10 --> Helper loaded: my_helper
INFO - 2022-06-09 03:05:10 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:05:10 --> Controller Class Initialized
INFO - 2022-06-09 03:05:11 --> Config Class Initialized
INFO - 2022-06-09 03:05:11 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:05:11 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:05:11 --> Utf8 Class Initialized
INFO - 2022-06-09 03:05:11 --> URI Class Initialized
INFO - 2022-06-09 03:05:11 --> Router Class Initialized
INFO - 2022-06-09 03:05:11 --> Output Class Initialized
INFO - 2022-06-09 03:05:11 --> Security Class Initialized
DEBUG - 2022-06-09 03:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:05:11 --> Input Class Initialized
INFO - 2022-06-09 03:05:11 --> Language Class Initialized
INFO - 2022-06-09 03:05:11 --> Language Class Initialized
INFO - 2022-06-09 03:05:11 --> Config Class Initialized
INFO - 2022-06-09 03:05:11 --> Loader Class Initialized
INFO - 2022-06-09 03:05:11 --> Helper loaded: url_helper
INFO - 2022-06-09 03:05:11 --> Helper loaded: file_helper
INFO - 2022-06-09 03:05:11 --> Helper loaded: form_helper
INFO - 2022-06-09 03:05:11 --> Helper loaded: my_helper
INFO - 2022-06-09 03:05:11 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:05:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:05:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:05:11 --> Controller Class Initialized
INFO - 2022-06-09 03:05:11 --> Final output sent to browser
DEBUG - 2022-06-09 03:05:11 --> Total execution time: 0.0705
INFO - 2022-06-09 03:05:24 --> Config Class Initialized
INFO - 2022-06-09 03:05:24 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:05:24 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:05:24 --> Utf8 Class Initialized
INFO - 2022-06-09 03:05:24 --> URI Class Initialized
INFO - 2022-06-09 03:05:24 --> Router Class Initialized
INFO - 2022-06-09 03:05:24 --> Output Class Initialized
INFO - 2022-06-09 03:05:24 --> Security Class Initialized
DEBUG - 2022-06-09 03:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:05:24 --> Input Class Initialized
INFO - 2022-06-09 03:05:24 --> Language Class Initialized
INFO - 2022-06-09 03:05:24 --> Language Class Initialized
INFO - 2022-06-09 03:05:24 --> Config Class Initialized
INFO - 2022-06-09 03:05:24 --> Loader Class Initialized
INFO - 2022-06-09 03:05:24 --> Helper loaded: url_helper
INFO - 2022-06-09 03:05:24 --> Helper loaded: file_helper
INFO - 2022-06-09 03:05:24 --> Helper loaded: form_helper
INFO - 2022-06-09 03:05:24 --> Helper loaded: my_helper
INFO - 2022-06-09 03:05:24 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:05:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:05:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:05:24 --> Controller Class Initialized
INFO - 2022-06-09 03:05:24 --> Final output sent to browser
DEBUG - 2022-06-09 03:05:24 --> Total execution time: 0.0585
INFO - 2022-06-09 03:05:24 --> Config Class Initialized
INFO - 2022-06-09 03:05:24 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:05:24 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:05:24 --> Utf8 Class Initialized
INFO - 2022-06-09 03:05:24 --> URI Class Initialized
INFO - 2022-06-09 03:05:24 --> Router Class Initialized
INFO - 2022-06-09 03:05:24 --> Output Class Initialized
INFO - 2022-06-09 03:05:24 --> Security Class Initialized
DEBUG - 2022-06-09 03:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:05:24 --> Input Class Initialized
INFO - 2022-06-09 03:05:24 --> Language Class Initialized
INFO - 2022-06-09 03:05:24 --> Language Class Initialized
INFO - 2022-06-09 03:05:24 --> Config Class Initialized
INFO - 2022-06-09 03:05:24 --> Loader Class Initialized
INFO - 2022-06-09 03:05:24 --> Helper loaded: url_helper
INFO - 2022-06-09 03:05:24 --> Helper loaded: file_helper
INFO - 2022-06-09 03:05:24 --> Helper loaded: form_helper
INFO - 2022-06-09 03:05:24 --> Helper loaded: my_helper
INFO - 2022-06-09 03:05:24 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:05:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:05:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:05:25 --> Controller Class Initialized
INFO - 2022-06-09 03:06:57 --> Config Class Initialized
INFO - 2022-06-09 03:06:57 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:06:57 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:06:57 --> Utf8 Class Initialized
INFO - 2022-06-09 03:06:57 --> URI Class Initialized
INFO - 2022-06-09 03:06:57 --> Router Class Initialized
INFO - 2022-06-09 03:06:57 --> Output Class Initialized
INFO - 2022-06-09 03:06:57 --> Security Class Initialized
DEBUG - 2022-06-09 03:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:06:57 --> Input Class Initialized
INFO - 2022-06-09 03:06:57 --> Language Class Initialized
INFO - 2022-06-09 03:06:57 --> Language Class Initialized
INFO - 2022-06-09 03:06:57 --> Config Class Initialized
INFO - 2022-06-09 03:06:57 --> Loader Class Initialized
INFO - 2022-06-09 03:06:57 --> Helper loaded: url_helper
INFO - 2022-06-09 03:06:57 --> Helper loaded: file_helper
INFO - 2022-06-09 03:06:57 --> Helper loaded: form_helper
INFO - 2022-06-09 03:06:57 --> Helper loaded: my_helper
INFO - 2022-06-09 03:06:57 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:06:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:06:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:06:57 --> Controller Class Initialized
INFO - 2022-06-09 03:06:57 --> Final output sent to browser
DEBUG - 2022-06-09 03:06:57 --> Total execution time: 0.0786
INFO - 2022-06-09 03:07:04 --> Config Class Initialized
INFO - 2022-06-09 03:07:04 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:07:04 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:07:04 --> Utf8 Class Initialized
INFO - 2022-06-09 03:07:04 --> URI Class Initialized
INFO - 2022-06-09 03:07:04 --> Router Class Initialized
INFO - 2022-06-09 03:07:04 --> Output Class Initialized
INFO - 2022-06-09 03:07:04 --> Security Class Initialized
DEBUG - 2022-06-09 03:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:07:04 --> Input Class Initialized
INFO - 2022-06-09 03:07:04 --> Language Class Initialized
INFO - 2022-06-09 03:07:04 --> Language Class Initialized
INFO - 2022-06-09 03:07:04 --> Config Class Initialized
INFO - 2022-06-09 03:07:04 --> Loader Class Initialized
INFO - 2022-06-09 03:07:04 --> Helper loaded: url_helper
INFO - 2022-06-09 03:07:04 --> Helper loaded: file_helper
INFO - 2022-06-09 03:07:04 --> Helper loaded: form_helper
INFO - 2022-06-09 03:07:04 --> Helper loaded: my_helper
INFO - 2022-06-09 03:07:04 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:07:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:07:04 --> Controller Class Initialized
INFO - 2022-06-09 03:07:04 --> Final output sent to browser
DEBUG - 2022-06-09 03:07:04 --> Total execution time: 0.0785
INFO - 2022-06-09 03:07:05 --> Config Class Initialized
INFO - 2022-06-09 03:07:05 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:07:05 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:07:05 --> Utf8 Class Initialized
INFO - 2022-06-09 03:07:05 --> URI Class Initialized
INFO - 2022-06-09 03:07:05 --> Router Class Initialized
INFO - 2022-06-09 03:07:05 --> Output Class Initialized
INFO - 2022-06-09 03:07:05 --> Security Class Initialized
DEBUG - 2022-06-09 03:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:07:05 --> Input Class Initialized
INFO - 2022-06-09 03:07:05 --> Language Class Initialized
INFO - 2022-06-09 03:07:05 --> Language Class Initialized
INFO - 2022-06-09 03:07:05 --> Config Class Initialized
INFO - 2022-06-09 03:07:05 --> Loader Class Initialized
INFO - 2022-06-09 03:07:05 --> Helper loaded: url_helper
INFO - 2022-06-09 03:07:05 --> Helper loaded: file_helper
INFO - 2022-06-09 03:07:05 --> Helper loaded: form_helper
INFO - 2022-06-09 03:07:05 --> Helper loaded: my_helper
INFO - 2022-06-09 03:07:05 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:07:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:07:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:07:05 --> Controller Class Initialized
INFO - 2022-06-09 03:07:06 --> Config Class Initialized
INFO - 2022-06-09 03:07:06 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:07:06 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:07:06 --> Utf8 Class Initialized
INFO - 2022-06-09 03:07:06 --> URI Class Initialized
INFO - 2022-06-09 03:07:06 --> Router Class Initialized
INFO - 2022-06-09 03:07:06 --> Output Class Initialized
INFO - 2022-06-09 03:07:06 --> Security Class Initialized
DEBUG - 2022-06-09 03:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:07:06 --> Input Class Initialized
INFO - 2022-06-09 03:07:06 --> Language Class Initialized
INFO - 2022-06-09 03:07:06 --> Language Class Initialized
INFO - 2022-06-09 03:07:06 --> Config Class Initialized
INFO - 2022-06-09 03:07:06 --> Loader Class Initialized
INFO - 2022-06-09 03:07:06 --> Helper loaded: url_helper
INFO - 2022-06-09 03:07:06 --> Helper loaded: file_helper
INFO - 2022-06-09 03:07:06 --> Helper loaded: form_helper
INFO - 2022-06-09 03:07:06 --> Helper loaded: my_helper
INFO - 2022-06-09 03:07:06 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:07:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:07:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:07:06 --> Controller Class Initialized
INFO - 2022-06-09 03:07:06 --> Final output sent to browser
DEBUG - 2022-06-09 03:07:06 --> Total execution time: 0.0733
INFO - 2022-06-09 03:07:12 --> Config Class Initialized
INFO - 2022-06-09 03:07:12 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:07:12 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:07:12 --> Utf8 Class Initialized
INFO - 2022-06-09 03:07:12 --> URI Class Initialized
INFO - 2022-06-09 03:07:12 --> Router Class Initialized
INFO - 2022-06-09 03:07:12 --> Output Class Initialized
INFO - 2022-06-09 03:07:12 --> Security Class Initialized
DEBUG - 2022-06-09 03:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:07:12 --> Input Class Initialized
INFO - 2022-06-09 03:07:12 --> Language Class Initialized
INFO - 2022-06-09 03:07:12 --> Language Class Initialized
INFO - 2022-06-09 03:07:12 --> Config Class Initialized
INFO - 2022-06-09 03:07:12 --> Loader Class Initialized
INFO - 2022-06-09 03:07:12 --> Helper loaded: url_helper
INFO - 2022-06-09 03:07:12 --> Helper loaded: file_helper
INFO - 2022-06-09 03:07:12 --> Helper loaded: form_helper
INFO - 2022-06-09 03:07:12 --> Helper loaded: my_helper
INFO - 2022-06-09 03:07:12 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:07:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:07:12 --> Controller Class Initialized
INFO - 2022-06-09 03:07:12 --> Final output sent to browser
DEBUG - 2022-06-09 03:07:12 --> Total execution time: 0.0772
INFO - 2022-06-09 03:07:12 --> Config Class Initialized
INFO - 2022-06-09 03:07:12 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:07:12 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:07:12 --> Utf8 Class Initialized
INFO - 2022-06-09 03:07:12 --> URI Class Initialized
INFO - 2022-06-09 03:07:12 --> Router Class Initialized
INFO - 2022-06-09 03:07:12 --> Output Class Initialized
INFO - 2022-06-09 03:07:12 --> Security Class Initialized
DEBUG - 2022-06-09 03:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:07:12 --> Input Class Initialized
INFO - 2022-06-09 03:07:12 --> Language Class Initialized
INFO - 2022-06-09 03:07:12 --> Language Class Initialized
INFO - 2022-06-09 03:07:12 --> Config Class Initialized
INFO - 2022-06-09 03:07:12 --> Loader Class Initialized
INFO - 2022-06-09 03:07:12 --> Helper loaded: url_helper
INFO - 2022-06-09 03:07:12 --> Helper loaded: file_helper
INFO - 2022-06-09 03:07:12 --> Helper loaded: form_helper
INFO - 2022-06-09 03:07:12 --> Helper loaded: my_helper
INFO - 2022-06-09 03:07:12 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:07:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:07:12 --> Controller Class Initialized
INFO - 2022-06-09 03:07:13 --> Config Class Initialized
INFO - 2022-06-09 03:07:13 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:07:13 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:07:13 --> Utf8 Class Initialized
INFO - 2022-06-09 03:07:13 --> URI Class Initialized
INFO - 2022-06-09 03:07:13 --> Router Class Initialized
INFO - 2022-06-09 03:07:13 --> Output Class Initialized
INFO - 2022-06-09 03:07:13 --> Security Class Initialized
DEBUG - 2022-06-09 03:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:07:13 --> Input Class Initialized
INFO - 2022-06-09 03:07:13 --> Language Class Initialized
INFO - 2022-06-09 03:07:13 --> Language Class Initialized
INFO - 2022-06-09 03:07:13 --> Config Class Initialized
INFO - 2022-06-09 03:07:13 --> Loader Class Initialized
INFO - 2022-06-09 03:07:13 --> Helper loaded: url_helper
INFO - 2022-06-09 03:07:13 --> Helper loaded: file_helper
INFO - 2022-06-09 03:07:13 --> Helper loaded: form_helper
INFO - 2022-06-09 03:07:13 --> Helper loaded: my_helper
INFO - 2022-06-09 03:07:13 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:07:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:07:13 --> Controller Class Initialized
INFO - 2022-06-09 03:07:13 --> Final output sent to browser
DEBUG - 2022-06-09 03:07:13 --> Total execution time: 0.0741
INFO - 2022-06-09 03:07:22 --> Config Class Initialized
INFO - 2022-06-09 03:07:22 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:07:22 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:07:22 --> Utf8 Class Initialized
INFO - 2022-06-09 03:07:22 --> URI Class Initialized
INFO - 2022-06-09 03:07:22 --> Router Class Initialized
INFO - 2022-06-09 03:07:22 --> Output Class Initialized
INFO - 2022-06-09 03:07:22 --> Security Class Initialized
DEBUG - 2022-06-09 03:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:07:22 --> Input Class Initialized
INFO - 2022-06-09 03:07:22 --> Language Class Initialized
INFO - 2022-06-09 03:07:22 --> Language Class Initialized
INFO - 2022-06-09 03:07:22 --> Config Class Initialized
INFO - 2022-06-09 03:07:22 --> Loader Class Initialized
INFO - 2022-06-09 03:07:22 --> Helper loaded: url_helper
INFO - 2022-06-09 03:07:22 --> Helper loaded: file_helper
INFO - 2022-06-09 03:07:22 --> Helper loaded: form_helper
INFO - 2022-06-09 03:07:22 --> Helper loaded: my_helper
INFO - 2022-06-09 03:07:22 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:07:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:07:22 --> Controller Class Initialized
INFO - 2022-06-09 03:07:22 --> Final output sent to browser
DEBUG - 2022-06-09 03:07:22 --> Total execution time: 0.0817
INFO - 2022-06-09 03:07:22 --> Config Class Initialized
INFO - 2022-06-09 03:07:22 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:07:22 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:07:22 --> Utf8 Class Initialized
INFO - 2022-06-09 03:07:22 --> URI Class Initialized
INFO - 2022-06-09 03:07:22 --> Router Class Initialized
INFO - 2022-06-09 03:07:22 --> Output Class Initialized
INFO - 2022-06-09 03:07:22 --> Security Class Initialized
DEBUG - 2022-06-09 03:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:07:22 --> Input Class Initialized
INFO - 2022-06-09 03:07:22 --> Language Class Initialized
INFO - 2022-06-09 03:07:22 --> Language Class Initialized
INFO - 2022-06-09 03:07:22 --> Config Class Initialized
INFO - 2022-06-09 03:07:22 --> Loader Class Initialized
INFO - 2022-06-09 03:07:22 --> Helper loaded: url_helper
INFO - 2022-06-09 03:07:22 --> Helper loaded: file_helper
INFO - 2022-06-09 03:07:22 --> Helper loaded: form_helper
INFO - 2022-06-09 03:07:22 --> Helper loaded: my_helper
INFO - 2022-06-09 03:07:22 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:07:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:07:22 --> Controller Class Initialized
INFO - 2022-06-09 03:07:24 --> Config Class Initialized
INFO - 2022-06-09 03:07:24 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:07:24 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:07:24 --> Utf8 Class Initialized
INFO - 2022-06-09 03:07:24 --> URI Class Initialized
INFO - 2022-06-09 03:07:24 --> Router Class Initialized
INFO - 2022-06-09 03:07:24 --> Output Class Initialized
INFO - 2022-06-09 03:07:24 --> Security Class Initialized
DEBUG - 2022-06-09 03:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:07:24 --> Input Class Initialized
INFO - 2022-06-09 03:07:24 --> Language Class Initialized
INFO - 2022-06-09 03:07:24 --> Language Class Initialized
INFO - 2022-06-09 03:07:24 --> Config Class Initialized
INFO - 2022-06-09 03:07:24 --> Loader Class Initialized
INFO - 2022-06-09 03:07:24 --> Helper loaded: url_helper
INFO - 2022-06-09 03:07:24 --> Helper loaded: file_helper
INFO - 2022-06-09 03:07:24 --> Helper loaded: form_helper
INFO - 2022-06-09 03:07:24 --> Helper loaded: my_helper
INFO - 2022-06-09 03:07:24 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:07:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:07:24 --> Controller Class Initialized
INFO - 2022-06-09 03:07:24 --> Final output sent to browser
DEBUG - 2022-06-09 03:07:24 --> Total execution time: 0.0739
INFO - 2022-06-09 03:07:32 --> Config Class Initialized
INFO - 2022-06-09 03:07:32 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:07:32 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:07:32 --> Utf8 Class Initialized
INFO - 2022-06-09 03:07:32 --> URI Class Initialized
INFO - 2022-06-09 03:07:32 --> Router Class Initialized
INFO - 2022-06-09 03:07:32 --> Output Class Initialized
INFO - 2022-06-09 03:07:32 --> Security Class Initialized
DEBUG - 2022-06-09 03:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:07:32 --> Input Class Initialized
INFO - 2022-06-09 03:07:32 --> Language Class Initialized
INFO - 2022-06-09 03:07:32 --> Language Class Initialized
INFO - 2022-06-09 03:07:32 --> Config Class Initialized
INFO - 2022-06-09 03:07:32 --> Loader Class Initialized
INFO - 2022-06-09 03:07:32 --> Helper loaded: url_helper
INFO - 2022-06-09 03:07:32 --> Helper loaded: file_helper
INFO - 2022-06-09 03:07:32 --> Helper loaded: form_helper
INFO - 2022-06-09 03:07:32 --> Helper loaded: my_helper
INFO - 2022-06-09 03:07:32 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:07:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:07:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:07:32 --> Controller Class Initialized
INFO - 2022-06-09 03:07:32 --> Final output sent to browser
DEBUG - 2022-06-09 03:07:32 --> Total execution time: 0.0599
INFO - 2022-06-09 03:07:32 --> Config Class Initialized
INFO - 2022-06-09 03:07:32 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:07:32 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:07:32 --> Utf8 Class Initialized
INFO - 2022-06-09 03:07:32 --> URI Class Initialized
INFO - 2022-06-09 03:07:32 --> Router Class Initialized
INFO - 2022-06-09 03:07:32 --> Output Class Initialized
INFO - 2022-06-09 03:07:32 --> Security Class Initialized
DEBUG - 2022-06-09 03:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:07:32 --> Input Class Initialized
INFO - 2022-06-09 03:07:32 --> Language Class Initialized
INFO - 2022-06-09 03:07:32 --> Language Class Initialized
INFO - 2022-06-09 03:07:32 --> Config Class Initialized
INFO - 2022-06-09 03:07:32 --> Loader Class Initialized
INFO - 2022-06-09 03:07:32 --> Helper loaded: url_helper
INFO - 2022-06-09 03:07:32 --> Helper loaded: file_helper
INFO - 2022-06-09 03:07:32 --> Helper loaded: form_helper
INFO - 2022-06-09 03:07:32 --> Helper loaded: my_helper
INFO - 2022-06-09 03:07:32 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:07:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:07:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:07:32 --> Controller Class Initialized
INFO - 2022-06-09 03:07:33 --> Config Class Initialized
INFO - 2022-06-09 03:07:33 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:07:33 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:07:33 --> Utf8 Class Initialized
INFO - 2022-06-09 03:07:33 --> URI Class Initialized
INFO - 2022-06-09 03:07:33 --> Router Class Initialized
INFO - 2022-06-09 03:07:33 --> Output Class Initialized
INFO - 2022-06-09 03:07:33 --> Security Class Initialized
DEBUG - 2022-06-09 03:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:07:33 --> Input Class Initialized
INFO - 2022-06-09 03:07:33 --> Language Class Initialized
INFO - 2022-06-09 03:07:33 --> Language Class Initialized
INFO - 2022-06-09 03:07:33 --> Config Class Initialized
INFO - 2022-06-09 03:07:33 --> Loader Class Initialized
INFO - 2022-06-09 03:07:33 --> Helper loaded: url_helper
INFO - 2022-06-09 03:07:33 --> Helper loaded: file_helper
INFO - 2022-06-09 03:07:33 --> Helper loaded: form_helper
INFO - 2022-06-09 03:07:33 --> Helper loaded: my_helper
INFO - 2022-06-09 03:07:33 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:07:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:07:33 --> Controller Class Initialized
INFO - 2022-06-09 03:07:33 --> Final output sent to browser
DEBUG - 2022-06-09 03:07:33 --> Total execution time: 0.0732
INFO - 2022-06-09 03:07:40 --> Config Class Initialized
INFO - 2022-06-09 03:07:40 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:07:40 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:07:40 --> Utf8 Class Initialized
INFO - 2022-06-09 03:07:40 --> URI Class Initialized
INFO - 2022-06-09 03:07:40 --> Router Class Initialized
INFO - 2022-06-09 03:07:40 --> Output Class Initialized
INFO - 2022-06-09 03:07:40 --> Security Class Initialized
DEBUG - 2022-06-09 03:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:07:40 --> Input Class Initialized
INFO - 2022-06-09 03:07:40 --> Language Class Initialized
INFO - 2022-06-09 03:07:40 --> Language Class Initialized
INFO - 2022-06-09 03:07:40 --> Config Class Initialized
INFO - 2022-06-09 03:07:40 --> Loader Class Initialized
INFO - 2022-06-09 03:07:40 --> Helper loaded: url_helper
INFO - 2022-06-09 03:07:40 --> Helper loaded: file_helper
INFO - 2022-06-09 03:07:40 --> Helper loaded: form_helper
INFO - 2022-06-09 03:07:40 --> Helper loaded: my_helper
INFO - 2022-06-09 03:07:40 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:07:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:07:40 --> Controller Class Initialized
INFO - 2022-06-09 03:07:40 --> Final output sent to browser
DEBUG - 2022-06-09 03:07:40 --> Total execution time: 0.0787
INFO - 2022-06-09 03:07:40 --> Config Class Initialized
INFO - 2022-06-09 03:07:40 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:07:40 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:07:40 --> Utf8 Class Initialized
INFO - 2022-06-09 03:07:40 --> URI Class Initialized
INFO - 2022-06-09 03:07:40 --> Router Class Initialized
INFO - 2022-06-09 03:07:40 --> Output Class Initialized
INFO - 2022-06-09 03:07:40 --> Security Class Initialized
DEBUG - 2022-06-09 03:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:07:40 --> Input Class Initialized
INFO - 2022-06-09 03:07:40 --> Language Class Initialized
INFO - 2022-06-09 03:07:40 --> Language Class Initialized
INFO - 2022-06-09 03:07:40 --> Config Class Initialized
INFO - 2022-06-09 03:07:40 --> Loader Class Initialized
INFO - 2022-06-09 03:07:40 --> Helper loaded: url_helper
INFO - 2022-06-09 03:07:40 --> Helper loaded: file_helper
INFO - 2022-06-09 03:07:40 --> Helper loaded: form_helper
INFO - 2022-06-09 03:07:40 --> Helper loaded: my_helper
INFO - 2022-06-09 03:07:40 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:07:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:07:40 --> Controller Class Initialized
INFO - 2022-06-09 03:07:43 --> Config Class Initialized
INFO - 2022-06-09 03:07:43 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:07:43 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:07:43 --> Utf8 Class Initialized
INFO - 2022-06-09 03:07:43 --> URI Class Initialized
INFO - 2022-06-09 03:07:43 --> Router Class Initialized
INFO - 2022-06-09 03:07:43 --> Output Class Initialized
INFO - 2022-06-09 03:07:43 --> Security Class Initialized
DEBUG - 2022-06-09 03:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:07:43 --> Input Class Initialized
INFO - 2022-06-09 03:07:43 --> Language Class Initialized
INFO - 2022-06-09 03:07:43 --> Language Class Initialized
INFO - 2022-06-09 03:07:43 --> Config Class Initialized
INFO - 2022-06-09 03:07:43 --> Loader Class Initialized
INFO - 2022-06-09 03:07:43 --> Helper loaded: url_helper
INFO - 2022-06-09 03:07:43 --> Helper loaded: file_helper
INFO - 2022-06-09 03:07:43 --> Helper loaded: form_helper
INFO - 2022-06-09 03:07:43 --> Helper loaded: my_helper
INFO - 2022-06-09 03:07:43 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:07:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:07:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:07:43 --> Controller Class Initialized
INFO - 2022-06-09 03:07:43 --> Final output sent to browser
DEBUG - 2022-06-09 03:07:43 --> Total execution time: 0.0733
INFO - 2022-06-09 03:07:50 --> Config Class Initialized
INFO - 2022-06-09 03:07:50 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:07:50 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:07:50 --> Utf8 Class Initialized
INFO - 2022-06-09 03:07:50 --> URI Class Initialized
INFO - 2022-06-09 03:07:50 --> Router Class Initialized
INFO - 2022-06-09 03:07:50 --> Output Class Initialized
INFO - 2022-06-09 03:07:50 --> Security Class Initialized
DEBUG - 2022-06-09 03:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:07:50 --> Input Class Initialized
INFO - 2022-06-09 03:07:50 --> Language Class Initialized
INFO - 2022-06-09 03:07:50 --> Language Class Initialized
INFO - 2022-06-09 03:07:50 --> Config Class Initialized
INFO - 2022-06-09 03:07:50 --> Loader Class Initialized
INFO - 2022-06-09 03:07:50 --> Helper loaded: url_helper
INFO - 2022-06-09 03:07:50 --> Helper loaded: file_helper
INFO - 2022-06-09 03:07:50 --> Helper loaded: form_helper
INFO - 2022-06-09 03:07:50 --> Helper loaded: my_helper
INFO - 2022-06-09 03:07:50 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:07:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:07:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:07:50 --> Controller Class Initialized
INFO - 2022-06-09 03:07:50 --> Final output sent to browser
DEBUG - 2022-06-09 03:07:50 --> Total execution time: 0.0784
INFO - 2022-06-09 03:07:51 --> Config Class Initialized
INFO - 2022-06-09 03:07:51 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:07:51 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:07:51 --> Utf8 Class Initialized
INFO - 2022-06-09 03:07:51 --> URI Class Initialized
INFO - 2022-06-09 03:07:51 --> Router Class Initialized
INFO - 2022-06-09 03:07:51 --> Output Class Initialized
INFO - 2022-06-09 03:07:51 --> Security Class Initialized
DEBUG - 2022-06-09 03:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:07:51 --> Input Class Initialized
INFO - 2022-06-09 03:07:51 --> Language Class Initialized
INFO - 2022-06-09 03:07:51 --> Language Class Initialized
INFO - 2022-06-09 03:07:51 --> Config Class Initialized
INFO - 2022-06-09 03:07:51 --> Loader Class Initialized
INFO - 2022-06-09 03:07:51 --> Helper loaded: url_helper
INFO - 2022-06-09 03:07:51 --> Helper loaded: file_helper
INFO - 2022-06-09 03:07:51 --> Helper loaded: form_helper
INFO - 2022-06-09 03:07:51 --> Helper loaded: my_helper
INFO - 2022-06-09 03:07:51 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:07:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:07:51 --> Controller Class Initialized
INFO - 2022-06-09 03:07:52 --> Config Class Initialized
INFO - 2022-06-09 03:07:52 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:07:52 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:07:52 --> Utf8 Class Initialized
INFO - 2022-06-09 03:07:52 --> URI Class Initialized
INFO - 2022-06-09 03:07:52 --> Router Class Initialized
INFO - 2022-06-09 03:07:52 --> Output Class Initialized
INFO - 2022-06-09 03:07:52 --> Security Class Initialized
DEBUG - 2022-06-09 03:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:07:52 --> Input Class Initialized
INFO - 2022-06-09 03:07:52 --> Language Class Initialized
INFO - 2022-06-09 03:07:52 --> Language Class Initialized
INFO - 2022-06-09 03:07:52 --> Config Class Initialized
INFO - 2022-06-09 03:07:52 --> Loader Class Initialized
INFO - 2022-06-09 03:07:52 --> Helper loaded: url_helper
INFO - 2022-06-09 03:07:52 --> Helper loaded: file_helper
INFO - 2022-06-09 03:07:52 --> Helper loaded: form_helper
INFO - 2022-06-09 03:07:52 --> Helper loaded: my_helper
INFO - 2022-06-09 03:07:52 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:07:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:07:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:07:52 --> Controller Class Initialized
INFO - 2022-06-09 03:07:52 --> Final output sent to browser
DEBUG - 2022-06-09 03:07:52 --> Total execution time: 0.0674
INFO - 2022-06-09 03:07:58 --> Config Class Initialized
INFO - 2022-06-09 03:07:58 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:07:58 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:07:58 --> Utf8 Class Initialized
INFO - 2022-06-09 03:07:58 --> URI Class Initialized
INFO - 2022-06-09 03:07:58 --> Router Class Initialized
INFO - 2022-06-09 03:07:58 --> Output Class Initialized
INFO - 2022-06-09 03:07:58 --> Security Class Initialized
DEBUG - 2022-06-09 03:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:07:58 --> Input Class Initialized
INFO - 2022-06-09 03:07:58 --> Language Class Initialized
INFO - 2022-06-09 03:07:58 --> Language Class Initialized
INFO - 2022-06-09 03:07:58 --> Config Class Initialized
INFO - 2022-06-09 03:07:58 --> Loader Class Initialized
INFO - 2022-06-09 03:07:58 --> Helper loaded: url_helper
INFO - 2022-06-09 03:07:58 --> Helper loaded: file_helper
INFO - 2022-06-09 03:07:58 --> Helper loaded: form_helper
INFO - 2022-06-09 03:07:58 --> Helper loaded: my_helper
INFO - 2022-06-09 03:07:58 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:07:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:07:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:07:58 --> Controller Class Initialized
INFO - 2022-06-09 03:07:58 --> Final output sent to browser
DEBUG - 2022-06-09 03:07:58 --> Total execution time: 0.0865
INFO - 2022-06-09 03:07:58 --> Config Class Initialized
INFO - 2022-06-09 03:07:58 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:07:58 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:07:58 --> Utf8 Class Initialized
INFO - 2022-06-09 03:07:58 --> URI Class Initialized
INFO - 2022-06-09 03:07:58 --> Router Class Initialized
INFO - 2022-06-09 03:07:58 --> Output Class Initialized
INFO - 2022-06-09 03:07:58 --> Security Class Initialized
DEBUG - 2022-06-09 03:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:07:58 --> Input Class Initialized
INFO - 2022-06-09 03:07:58 --> Language Class Initialized
INFO - 2022-06-09 03:07:58 --> Language Class Initialized
INFO - 2022-06-09 03:07:58 --> Config Class Initialized
INFO - 2022-06-09 03:07:58 --> Loader Class Initialized
INFO - 2022-06-09 03:07:58 --> Helper loaded: url_helper
INFO - 2022-06-09 03:07:58 --> Helper loaded: file_helper
INFO - 2022-06-09 03:07:58 --> Helper loaded: form_helper
INFO - 2022-06-09 03:07:58 --> Helper loaded: my_helper
INFO - 2022-06-09 03:07:58 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:07:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:07:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:07:58 --> Controller Class Initialized
INFO - 2022-06-09 03:08:29 --> Config Class Initialized
INFO - 2022-06-09 03:08:29 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:08:29 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:08:29 --> Utf8 Class Initialized
INFO - 2022-06-09 03:08:29 --> URI Class Initialized
INFO - 2022-06-09 03:08:29 --> Router Class Initialized
INFO - 2022-06-09 03:08:29 --> Output Class Initialized
INFO - 2022-06-09 03:08:29 --> Security Class Initialized
DEBUG - 2022-06-09 03:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:08:29 --> Input Class Initialized
INFO - 2022-06-09 03:08:29 --> Language Class Initialized
INFO - 2022-06-09 03:08:29 --> Language Class Initialized
INFO - 2022-06-09 03:08:29 --> Config Class Initialized
INFO - 2022-06-09 03:08:29 --> Loader Class Initialized
INFO - 2022-06-09 03:08:29 --> Helper loaded: url_helper
INFO - 2022-06-09 03:08:29 --> Helper loaded: file_helper
INFO - 2022-06-09 03:08:29 --> Helper loaded: form_helper
INFO - 2022-06-09 03:08:29 --> Helper loaded: my_helper
INFO - 2022-06-09 03:08:29 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:08:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:08:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:08:29 --> Controller Class Initialized
DEBUG - 2022-06-09 03:08:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2022-06-09 03:08:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-09 03:08:29 --> Final output sent to browser
DEBUG - 2022-06-09 03:08:29 --> Total execution time: 0.0950
INFO - 2022-06-09 03:08:30 --> Config Class Initialized
INFO - 2022-06-09 03:08:30 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:08:30 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:08:30 --> Utf8 Class Initialized
INFO - 2022-06-09 03:08:30 --> URI Class Initialized
INFO - 2022-06-09 03:08:30 --> Router Class Initialized
INFO - 2022-06-09 03:08:30 --> Output Class Initialized
INFO - 2022-06-09 03:08:30 --> Security Class Initialized
DEBUG - 2022-06-09 03:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:08:30 --> Input Class Initialized
INFO - 2022-06-09 03:08:30 --> Language Class Initialized
INFO - 2022-06-09 03:08:31 --> Language Class Initialized
INFO - 2022-06-09 03:08:31 --> Config Class Initialized
INFO - 2022-06-09 03:08:31 --> Loader Class Initialized
INFO - 2022-06-09 03:08:31 --> Helper loaded: url_helper
INFO - 2022-06-09 03:08:31 --> Helper loaded: file_helper
INFO - 2022-06-09 03:08:31 --> Helper loaded: form_helper
INFO - 2022-06-09 03:08:31 --> Helper loaded: my_helper
INFO - 2022-06-09 03:08:31 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:08:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:08:31 --> Controller Class Initialized
DEBUG - 2022-06-09 03:08:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2022-06-09 03:08:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-09 03:08:31 --> Final output sent to browser
DEBUG - 2022-06-09 03:08:31 --> Total execution time: 0.0846
INFO - 2022-06-09 03:08:31 --> Config Class Initialized
INFO - 2022-06-09 03:08:31 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:08:31 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:08:31 --> Utf8 Class Initialized
INFO - 2022-06-09 03:08:31 --> URI Class Initialized
INFO - 2022-06-09 03:08:31 --> Router Class Initialized
INFO - 2022-06-09 03:08:31 --> Output Class Initialized
INFO - 2022-06-09 03:08:31 --> Security Class Initialized
DEBUG - 2022-06-09 03:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:08:31 --> Input Class Initialized
INFO - 2022-06-09 03:08:31 --> Language Class Initialized
INFO - 2022-06-09 03:08:31 --> Language Class Initialized
INFO - 2022-06-09 03:08:31 --> Config Class Initialized
INFO - 2022-06-09 03:08:31 --> Loader Class Initialized
INFO - 2022-06-09 03:08:31 --> Helper loaded: url_helper
INFO - 2022-06-09 03:08:31 --> Helper loaded: file_helper
INFO - 2022-06-09 03:08:31 --> Helper loaded: form_helper
INFO - 2022-06-09 03:08:31 --> Helper loaded: my_helper
INFO - 2022-06-09 03:08:31 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:08:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:08:31 --> Controller Class Initialized
INFO - 2022-06-09 03:08:32 --> Config Class Initialized
INFO - 2022-06-09 03:08:32 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:08:32 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:08:32 --> Utf8 Class Initialized
INFO - 2022-06-09 03:08:32 --> URI Class Initialized
INFO - 2022-06-09 03:08:32 --> Router Class Initialized
INFO - 2022-06-09 03:08:32 --> Output Class Initialized
INFO - 2022-06-09 03:08:32 --> Security Class Initialized
DEBUG - 2022-06-09 03:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:08:32 --> Input Class Initialized
INFO - 2022-06-09 03:08:32 --> Language Class Initialized
INFO - 2022-06-09 03:08:32 --> Language Class Initialized
INFO - 2022-06-09 03:08:32 --> Config Class Initialized
INFO - 2022-06-09 03:08:32 --> Loader Class Initialized
INFO - 2022-06-09 03:08:32 --> Helper loaded: url_helper
INFO - 2022-06-09 03:08:32 --> Helper loaded: file_helper
INFO - 2022-06-09 03:08:32 --> Helper loaded: form_helper
INFO - 2022-06-09 03:08:32 --> Helper loaded: my_helper
INFO - 2022-06-09 03:08:32 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:08:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:08:32 --> Controller Class Initialized
DEBUG - 2022-06-09 03:08:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2022-06-09 03:08:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-09 03:08:32 --> Final output sent to browser
DEBUG - 2022-06-09 03:08:32 --> Total execution time: 0.0807
INFO - 2022-06-09 03:08:32 --> Config Class Initialized
INFO - 2022-06-09 03:08:32 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:08:32 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:08:32 --> Utf8 Class Initialized
INFO - 2022-06-09 03:08:32 --> URI Class Initialized
INFO - 2022-06-09 03:08:32 --> Router Class Initialized
INFO - 2022-06-09 03:08:32 --> Output Class Initialized
INFO - 2022-06-09 03:08:32 --> Security Class Initialized
DEBUG - 2022-06-09 03:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:08:32 --> Input Class Initialized
INFO - 2022-06-09 03:08:32 --> Language Class Initialized
INFO - 2022-06-09 03:08:32 --> Language Class Initialized
INFO - 2022-06-09 03:08:32 --> Config Class Initialized
INFO - 2022-06-09 03:08:32 --> Loader Class Initialized
INFO - 2022-06-09 03:08:32 --> Helper loaded: url_helper
INFO - 2022-06-09 03:08:32 --> Helper loaded: file_helper
INFO - 2022-06-09 03:08:32 --> Helper loaded: form_helper
INFO - 2022-06-09 03:08:32 --> Helper loaded: my_helper
INFO - 2022-06-09 03:08:32 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:08:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:08:32 --> Controller Class Initialized
INFO - 2022-06-09 03:11:04 --> Config Class Initialized
INFO - 2022-06-09 03:11:04 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:11:04 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:11:04 --> Utf8 Class Initialized
INFO - 2022-06-09 03:11:04 --> URI Class Initialized
INFO - 2022-06-09 03:11:04 --> Router Class Initialized
INFO - 2022-06-09 03:11:04 --> Output Class Initialized
INFO - 2022-06-09 03:11:04 --> Security Class Initialized
DEBUG - 2022-06-09 03:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:11:04 --> Input Class Initialized
INFO - 2022-06-09 03:11:04 --> Language Class Initialized
INFO - 2022-06-09 03:11:04 --> Language Class Initialized
INFO - 2022-06-09 03:11:04 --> Config Class Initialized
INFO - 2022-06-09 03:11:04 --> Loader Class Initialized
INFO - 2022-06-09 03:11:04 --> Helper loaded: url_helper
INFO - 2022-06-09 03:11:04 --> Helper loaded: file_helper
INFO - 2022-06-09 03:11:04 --> Helper loaded: form_helper
INFO - 2022-06-09 03:11:04 --> Helper loaded: my_helper
INFO - 2022-06-09 03:11:04 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:11:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:11:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:11:05 --> Controller Class Initialized
INFO - 2022-06-09 03:11:05 --> Final output sent to browser
DEBUG - 2022-06-09 03:11:05 --> Total execution time: 0.0560
INFO - 2022-06-09 03:11:12 --> Config Class Initialized
INFO - 2022-06-09 03:11:12 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:11:12 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:11:12 --> Utf8 Class Initialized
INFO - 2022-06-09 03:11:12 --> URI Class Initialized
INFO - 2022-06-09 03:11:12 --> Router Class Initialized
INFO - 2022-06-09 03:11:12 --> Output Class Initialized
INFO - 2022-06-09 03:11:12 --> Security Class Initialized
DEBUG - 2022-06-09 03:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:11:12 --> Input Class Initialized
INFO - 2022-06-09 03:11:12 --> Language Class Initialized
INFO - 2022-06-09 03:11:12 --> Language Class Initialized
INFO - 2022-06-09 03:11:12 --> Config Class Initialized
INFO - 2022-06-09 03:11:12 --> Loader Class Initialized
INFO - 2022-06-09 03:11:12 --> Helper loaded: url_helper
INFO - 2022-06-09 03:11:12 --> Helper loaded: file_helper
INFO - 2022-06-09 03:11:12 --> Helper loaded: form_helper
INFO - 2022-06-09 03:11:12 --> Helper loaded: my_helper
INFO - 2022-06-09 03:11:12 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:11:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:11:12 --> Controller Class Initialized
INFO - 2022-06-09 03:11:12 --> Final output sent to browser
DEBUG - 2022-06-09 03:11:12 --> Total execution time: 0.0752
INFO - 2022-06-09 03:11:12 --> Config Class Initialized
INFO - 2022-06-09 03:11:12 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:11:12 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:11:12 --> Utf8 Class Initialized
INFO - 2022-06-09 03:11:12 --> URI Class Initialized
INFO - 2022-06-09 03:11:12 --> Router Class Initialized
INFO - 2022-06-09 03:11:12 --> Output Class Initialized
INFO - 2022-06-09 03:11:12 --> Security Class Initialized
DEBUG - 2022-06-09 03:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:11:12 --> Input Class Initialized
INFO - 2022-06-09 03:11:12 --> Language Class Initialized
INFO - 2022-06-09 03:11:12 --> Language Class Initialized
INFO - 2022-06-09 03:11:12 --> Config Class Initialized
INFO - 2022-06-09 03:11:12 --> Loader Class Initialized
INFO - 2022-06-09 03:11:12 --> Helper loaded: url_helper
INFO - 2022-06-09 03:11:12 --> Helper loaded: file_helper
INFO - 2022-06-09 03:11:12 --> Helper loaded: form_helper
INFO - 2022-06-09 03:11:12 --> Helper loaded: my_helper
INFO - 2022-06-09 03:11:12 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:11:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:11:12 --> Controller Class Initialized
INFO - 2022-06-09 03:11:14 --> Config Class Initialized
INFO - 2022-06-09 03:11:14 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:11:14 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:11:14 --> Utf8 Class Initialized
INFO - 2022-06-09 03:11:14 --> URI Class Initialized
INFO - 2022-06-09 03:11:14 --> Router Class Initialized
INFO - 2022-06-09 03:11:14 --> Output Class Initialized
INFO - 2022-06-09 03:11:14 --> Security Class Initialized
DEBUG - 2022-06-09 03:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:11:14 --> Input Class Initialized
INFO - 2022-06-09 03:11:14 --> Language Class Initialized
INFO - 2022-06-09 03:11:14 --> Language Class Initialized
INFO - 2022-06-09 03:11:14 --> Config Class Initialized
INFO - 2022-06-09 03:11:14 --> Loader Class Initialized
INFO - 2022-06-09 03:11:14 --> Helper loaded: url_helper
INFO - 2022-06-09 03:11:14 --> Helper loaded: file_helper
INFO - 2022-06-09 03:11:14 --> Helper loaded: form_helper
INFO - 2022-06-09 03:11:14 --> Helper loaded: my_helper
INFO - 2022-06-09 03:11:14 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:11:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:11:14 --> Controller Class Initialized
INFO - 2022-06-09 03:11:14 --> Final output sent to browser
DEBUG - 2022-06-09 03:11:14 --> Total execution time: 0.0637
INFO - 2022-06-09 03:11:20 --> Config Class Initialized
INFO - 2022-06-09 03:11:20 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:11:20 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:11:20 --> Utf8 Class Initialized
INFO - 2022-06-09 03:11:20 --> URI Class Initialized
INFO - 2022-06-09 03:11:20 --> Router Class Initialized
INFO - 2022-06-09 03:11:20 --> Output Class Initialized
INFO - 2022-06-09 03:11:20 --> Security Class Initialized
DEBUG - 2022-06-09 03:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:11:20 --> Input Class Initialized
INFO - 2022-06-09 03:11:20 --> Language Class Initialized
INFO - 2022-06-09 03:11:20 --> Language Class Initialized
INFO - 2022-06-09 03:11:20 --> Config Class Initialized
INFO - 2022-06-09 03:11:20 --> Loader Class Initialized
INFO - 2022-06-09 03:11:20 --> Helper loaded: url_helper
INFO - 2022-06-09 03:11:20 --> Helper loaded: file_helper
INFO - 2022-06-09 03:11:20 --> Helper loaded: form_helper
INFO - 2022-06-09 03:11:20 --> Helper loaded: my_helper
INFO - 2022-06-09 03:11:20 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:11:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:11:20 --> Controller Class Initialized
INFO - 2022-06-09 03:11:20 --> Final output sent to browser
DEBUG - 2022-06-09 03:11:20 --> Total execution time: 0.0789
INFO - 2022-06-09 03:11:20 --> Config Class Initialized
INFO - 2022-06-09 03:11:20 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:11:20 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:11:20 --> Utf8 Class Initialized
INFO - 2022-06-09 03:11:20 --> URI Class Initialized
INFO - 2022-06-09 03:11:20 --> Router Class Initialized
INFO - 2022-06-09 03:11:20 --> Output Class Initialized
INFO - 2022-06-09 03:11:20 --> Security Class Initialized
DEBUG - 2022-06-09 03:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:11:20 --> Input Class Initialized
INFO - 2022-06-09 03:11:20 --> Language Class Initialized
INFO - 2022-06-09 03:11:20 --> Language Class Initialized
INFO - 2022-06-09 03:11:20 --> Config Class Initialized
INFO - 2022-06-09 03:11:20 --> Loader Class Initialized
INFO - 2022-06-09 03:11:20 --> Helper loaded: url_helper
INFO - 2022-06-09 03:11:20 --> Helper loaded: file_helper
INFO - 2022-06-09 03:11:20 --> Helper loaded: form_helper
INFO - 2022-06-09 03:11:20 --> Helper loaded: my_helper
INFO - 2022-06-09 03:11:20 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:11:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:11:20 --> Controller Class Initialized
INFO - 2022-06-09 03:11:21 --> Config Class Initialized
INFO - 2022-06-09 03:11:21 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:11:21 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:11:21 --> Utf8 Class Initialized
INFO - 2022-06-09 03:11:21 --> URI Class Initialized
INFO - 2022-06-09 03:11:21 --> Router Class Initialized
INFO - 2022-06-09 03:11:21 --> Output Class Initialized
INFO - 2022-06-09 03:11:21 --> Security Class Initialized
DEBUG - 2022-06-09 03:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:11:21 --> Input Class Initialized
INFO - 2022-06-09 03:11:21 --> Language Class Initialized
INFO - 2022-06-09 03:11:21 --> Language Class Initialized
INFO - 2022-06-09 03:11:21 --> Config Class Initialized
INFO - 2022-06-09 03:11:21 --> Loader Class Initialized
INFO - 2022-06-09 03:11:21 --> Helper loaded: url_helper
INFO - 2022-06-09 03:11:21 --> Helper loaded: file_helper
INFO - 2022-06-09 03:11:21 --> Helper loaded: form_helper
INFO - 2022-06-09 03:11:21 --> Helper loaded: my_helper
INFO - 2022-06-09 03:11:21 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:11:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:11:21 --> Controller Class Initialized
INFO - 2022-06-09 03:11:21 --> Final output sent to browser
DEBUG - 2022-06-09 03:11:21 --> Total execution time: 0.0536
INFO - 2022-06-09 03:11:39 --> Config Class Initialized
INFO - 2022-06-09 03:11:39 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:11:39 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:11:39 --> Utf8 Class Initialized
INFO - 2022-06-09 03:11:39 --> URI Class Initialized
INFO - 2022-06-09 03:11:39 --> Router Class Initialized
INFO - 2022-06-09 03:11:39 --> Output Class Initialized
INFO - 2022-06-09 03:11:39 --> Security Class Initialized
DEBUG - 2022-06-09 03:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:11:39 --> Input Class Initialized
INFO - 2022-06-09 03:11:39 --> Language Class Initialized
INFO - 2022-06-09 03:11:39 --> Language Class Initialized
INFO - 2022-06-09 03:11:39 --> Config Class Initialized
INFO - 2022-06-09 03:11:39 --> Loader Class Initialized
INFO - 2022-06-09 03:11:39 --> Helper loaded: url_helper
INFO - 2022-06-09 03:11:39 --> Helper loaded: file_helper
INFO - 2022-06-09 03:11:39 --> Helper loaded: form_helper
INFO - 2022-06-09 03:11:39 --> Helper loaded: my_helper
INFO - 2022-06-09 03:11:39 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:11:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:11:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:11:39 --> Controller Class Initialized
INFO - 2022-06-09 03:11:39 --> Final output sent to browser
DEBUG - 2022-06-09 03:11:39 --> Total execution time: 0.0770
INFO - 2022-06-09 03:11:39 --> Config Class Initialized
INFO - 2022-06-09 03:11:39 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:11:39 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:11:39 --> Utf8 Class Initialized
INFO - 2022-06-09 03:11:39 --> URI Class Initialized
INFO - 2022-06-09 03:11:39 --> Router Class Initialized
INFO - 2022-06-09 03:11:39 --> Output Class Initialized
INFO - 2022-06-09 03:11:39 --> Security Class Initialized
DEBUG - 2022-06-09 03:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:11:39 --> Input Class Initialized
INFO - 2022-06-09 03:11:39 --> Language Class Initialized
INFO - 2022-06-09 03:11:39 --> Language Class Initialized
INFO - 2022-06-09 03:11:39 --> Config Class Initialized
INFO - 2022-06-09 03:11:39 --> Loader Class Initialized
INFO - 2022-06-09 03:11:39 --> Helper loaded: url_helper
INFO - 2022-06-09 03:11:39 --> Helper loaded: file_helper
INFO - 2022-06-09 03:11:39 --> Helper loaded: form_helper
INFO - 2022-06-09 03:11:39 --> Helper loaded: my_helper
INFO - 2022-06-09 03:11:39 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:11:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:11:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:11:39 --> Controller Class Initialized
INFO - 2022-06-09 03:11:41 --> Config Class Initialized
INFO - 2022-06-09 03:11:41 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:11:41 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:11:41 --> Utf8 Class Initialized
INFO - 2022-06-09 03:11:41 --> URI Class Initialized
INFO - 2022-06-09 03:11:41 --> Router Class Initialized
INFO - 2022-06-09 03:11:41 --> Output Class Initialized
INFO - 2022-06-09 03:11:41 --> Security Class Initialized
DEBUG - 2022-06-09 03:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:11:41 --> Input Class Initialized
INFO - 2022-06-09 03:11:41 --> Language Class Initialized
INFO - 2022-06-09 03:11:41 --> Language Class Initialized
INFO - 2022-06-09 03:11:41 --> Config Class Initialized
INFO - 2022-06-09 03:11:41 --> Loader Class Initialized
INFO - 2022-06-09 03:11:41 --> Helper loaded: url_helper
INFO - 2022-06-09 03:11:41 --> Helper loaded: file_helper
INFO - 2022-06-09 03:11:41 --> Helper loaded: form_helper
INFO - 2022-06-09 03:11:41 --> Helper loaded: my_helper
INFO - 2022-06-09 03:11:41 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:11:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:11:41 --> Controller Class Initialized
INFO - 2022-06-09 03:11:41 --> Final output sent to browser
DEBUG - 2022-06-09 03:11:41 --> Total execution time: 0.0666
INFO - 2022-06-09 03:11:53 --> Config Class Initialized
INFO - 2022-06-09 03:11:53 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:11:53 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:11:53 --> Utf8 Class Initialized
INFO - 2022-06-09 03:11:53 --> URI Class Initialized
INFO - 2022-06-09 03:11:53 --> Router Class Initialized
INFO - 2022-06-09 03:11:53 --> Output Class Initialized
INFO - 2022-06-09 03:11:53 --> Security Class Initialized
DEBUG - 2022-06-09 03:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:11:53 --> Input Class Initialized
INFO - 2022-06-09 03:11:53 --> Language Class Initialized
INFO - 2022-06-09 03:11:53 --> Language Class Initialized
INFO - 2022-06-09 03:11:53 --> Config Class Initialized
INFO - 2022-06-09 03:11:53 --> Loader Class Initialized
INFO - 2022-06-09 03:11:53 --> Helper loaded: url_helper
INFO - 2022-06-09 03:11:53 --> Helper loaded: file_helper
INFO - 2022-06-09 03:11:53 --> Helper loaded: form_helper
INFO - 2022-06-09 03:11:53 --> Helper loaded: my_helper
INFO - 2022-06-09 03:11:53 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:11:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:11:53 --> Controller Class Initialized
INFO - 2022-06-09 03:11:53 --> Final output sent to browser
DEBUG - 2022-06-09 03:11:53 --> Total execution time: 0.0858
INFO - 2022-06-09 03:11:53 --> Config Class Initialized
INFO - 2022-06-09 03:11:53 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:11:53 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:11:53 --> Utf8 Class Initialized
INFO - 2022-06-09 03:11:53 --> URI Class Initialized
INFO - 2022-06-09 03:11:53 --> Router Class Initialized
INFO - 2022-06-09 03:11:53 --> Output Class Initialized
INFO - 2022-06-09 03:11:53 --> Security Class Initialized
DEBUG - 2022-06-09 03:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:11:53 --> Input Class Initialized
INFO - 2022-06-09 03:11:53 --> Language Class Initialized
INFO - 2022-06-09 03:11:53 --> Language Class Initialized
INFO - 2022-06-09 03:11:53 --> Config Class Initialized
INFO - 2022-06-09 03:11:53 --> Loader Class Initialized
INFO - 2022-06-09 03:11:53 --> Helper loaded: url_helper
INFO - 2022-06-09 03:11:53 --> Helper loaded: file_helper
INFO - 2022-06-09 03:11:53 --> Helper loaded: form_helper
INFO - 2022-06-09 03:11:53 --> Helper loaded: my_helper
INFO - 2022-06-09 03:11:53 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:11:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:11:53 --> Controller Class Initialized
INFO - 2022-06-09 03:11:54 --> Config Class Initialized
INFO - 2022-06-09 03:11:54 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:11:54 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:11:54 --> Utf8 Class Initialized
INFO - 2022-06-09 03:11:54 --> URI Class Initialized
INFO - 2022-06-09 03:11:54 --> Router Class Initialized
INFO - 2022-06-09 03:11:54 --> Output Class Initialized
INFO - 2022-06-09 03:11:54 --> Security Class Initialized
DEBUG - 2022-06-09 03:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:11:54 --> Input Class Initialized
INFO - 2022-06-09 03:11:54 --> Language Class Initialized
INFO - 2022-06-09 03:11:54 --> Language Class Initialized
INFO - 2022-06-09 03:11:54 --> Config Class Initialized
INFO - 2022-06-09 03:11:54 --> Loader Class Initialized
INFO - 2022-06-09 03:11:54 --> Helper loaded: url_helper
INFO - 2022-06-09 03:11:54 --> Helper loaded: file_helper
INFO - 2022-06-09 03:11:54 --> Helper loaded: form_helper
INFO - 2022-06-09 03:11:54 --> Helper loaded: my_helper
INFO - 2022-06-09 03:11:54 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:11:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:11:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:11:54 --> Controller Class Initialized
INFO - 2022-06-09 03:11:54 --> Final output sent to browser
DEBUG - 2022-06-09 03:11:54 --> Total execution time: 0.0641
INFO - 2022-06-09 03:12:12 --> Config Class Initialized
INFO - 2022-06-09 03:12:12 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:12:12 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:12:12 --> Utf8 Class Initialized
INFO - 2022-06-09 03:12:12 --> URI Class Initialized
INFO - 2022-06-09 03:12:12 --> Router Class Initialized
INFO - 2022-06-09 03:12:12 --> Output Class Initialized
INFO - 2022-06-09 03:12:12 --> Security Class Initialized
DEBUG - 2022-06-09 03:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:12:12 --> Input Class Initialized
INFO - 2022-06-09 03:12:12 --> Language Class Initialized
INFO - 2022-06-09 03:12:12 --> Language Class Initialized
INFO - 2022-06-09 03:12:12 --> Config Class Initialized
INFO - 2022-06-09 03:12:12 --> Loader Class Initialized
INFO - 2022-06-09 03:12:12 --> Helper loaded: url_helper
INFO - 2022-06-09 03:12:12 --> Helper loaded: file_helper
INFO - 2022-06-09 03:12:12 --> Helper loaded: form_helper
INFO - 2022-06-09 03:12:12 --> Helper loaded: my_helper
INFO - 2022-06-09 03:12:12 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:12:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:12:12 --> Controller Class Initialized
INFO - 2022-06-09 03:12:12 --> Final output sent to browser
DEBUG - 2022-06-09 03:12:12 --> Total execution time: 0.0536
INFO - 2022-06-09 03:12:12 --> Config Class Initialized
INFO - 2022-06-09 03:12:12 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:12:12 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:12:12 --> Utf8 Class Initialized
INFO - 2022-06-09 03:12:12 --> URI Class Initialized
INFO - 2022-06-09 03:12:12 --> Router Class Initialized
INFO - 2022-06-09 03:12:12 --> Output Class Initialized
INFO - 2022-06-09 03:12:12 --> Security Class Initialized
DEBUG - 2022-06-09 03:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:12:12 --> Input Class Initialized
INFO - 2022-06-09 03:12:12 --> Language Class Initialized
INFO - 2022-06-09 03:12:12 --> Language Class Initialized
INFO - 2022-06-09 03:12:12 --> Config Class Initialized
INFO - 2022-06-09 03:12:12 --> Loader Class Initialized
INFO - 2022-06-09 03:12:12 --> Helper loaded: url_helper
INFO - 2022-06-09 03:12:12 --> Helper loaded: file_helper
INFO - 2022-06-09 03:12:12 --> Helper loaded: form_helper
INFO - 2022-06-09 03:12:12 --> Helper loaded: my_helper
INFO - 2022-06-09 03:12:12 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:12:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:12:12 --> Controller Class Initialized
INFO - 2022-06-09 03:12:14 --> Config Class Initialized
INFO - 2022-06-09 03:12:14 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:12:14 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:12:14 --> Utf8 Class Initialized
INFO - 2022-06-09 03:12:14 --> URI Class Initialized
INFO - 2022-06-09 03:12:14 --> Router Class Initialized
INFO - 2022-06-09 03:12:14 --> Output Class Initialized
INFO - 2022-06-09 03:12:14 --> Security Class Initialized
DEBUG - 2022-06-09 03:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:12:14 --> Input Class Initialized
INFO - 2022-06-09 03:12:14 --> Language Class Initialized
INFO - 2022-06-09 03:12:14 --> Language Class Initialized
INFO - 2022-06-09 03:12:14 --> Config Class Initialized
INFO - 2022-06-09 03:12:14 --> Loader Class Initialized
INFO - 2022-06-09 03:12:14 --> Helper loaded: url_helper
INFO - 2022-06-09 03:12:14 --> Helper loaded: file_helper
INFO - 2022-06-09 03:12:14 --> Helper loaded: form_helper
INFO - 2022-06-09 03:12:14 --> Helper loaded: my_helper
INFO - 2022-06-09 03:12:14 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:12:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:12:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:12:14 --> Controller Class Initialized
INFO - 2022-06-09 03:12:14 --> Final output sent to browser
DEBUG - 2022-06-09 03:12:14 --> Total execution time: 0.0758
INFO - 2022-06-09 03:12:26 --> Config Class Initialized
INFO - 2022-06-09 03:12:26 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:12:26 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:12:26 --> Utf8 Class Initialized
INFO - 2022-06-09 03:12:26 --> URI Class Initialized
INFO - 2022-06-09 03:12:26 --> Router Class Initialized
INFO - 2022-06-09 03:12:26 --> Output Class Initialized
INFO - 2022-06-09 03:12:26 --> Security Class Initialized
DEBUG - 2022-06-09 03:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:12:26 --> Input Class Initialized
INFO - 2022-06-09 03:12:26 --> Language Class Initialized
INFO - 2022-06-09 03:12:26 --> Language Class Initialized
INFO - 2022-06-09 03:12:26 --> Config Class Initialized
INFO - 2022-06-09 03:12:26 --> Loader Class Initialized
INFO - 2022-06-09 03:12:26 --> Helper loaded: url_helper
INFO - 2022-06-09 03:12:26 --> Helper loaded: file_helper
INFO - 2022-06-09 03:12:26 --> Helper loaded: form_helper
INFO - 2022-06-09 03:12:26 --> Helper loaded: my_helper
INFO - 2022-06-09 03:12:26 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:12:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:12:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:12:26 --> Controller Class Initialized
INFO - 2022-06-09 03:12:26 --> Final output sent to browser
DEBUG - 2022-06-09 03:12:26 --> Total execution time: 0.0608
INFO - 2022-06-09 03:12:26 --> Config Class Initialized
INFO - 2022-06-09 03:12:26 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:12:26 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:12:26 --> Utf8 Class Initialized
INFO - 2022-06-09 03:12:26 --> URI Class Initialized
INFO - 2022-06-09 03:12:26 --> Router Class Initialized
INFO - 2022-06-09 03:12:26 --> Output Class Initialized
INFO - 2022-06-09 03:12:26 --> Security Class Initialized
DEBUG - 2022-06-09 03:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:12:26 --> Input Class Initialized
INFO - 2022-06-09 03:12:26 --> Language Class Initialized
INFO - 2022-06-09 03:12:26 --> Language Class Initialized
INFO - 2022-06-09 03:12:26 --> Config Class Initialized
INFO - 2022-06-09 03:12:26 --> Loader Class Initialized
INFO - 2022-06-09 03:12:26 --> Helper loaded: url_helper
INFO - 2022-06-09 03:12:26 --> Helper loaded: file_helper
INFO - 2022-06-09 03:12:26 --> Helper loaded: form_helper
INFO - 2022-06-09 03:12:26 --> Helper loaded: my_helper
INFO - 2022-06-09 03:12:26 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:12:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:12:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:12:26 --> Controller Class Initialized
INFO - 2022-06-09 03:12:28 --> Config Class Initialized
INFO - 2022-06-09 03:12:28 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:12:28 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:12:28 --> Utf8 Class Initialized
INFO - 2022-06-09 03:12:28 --> URI Class Initialized
INFO - 2022-06-09 03:12:28 --> Router Class Initialized
INFO - 2022-06-09 03:12:28 --> Output Class Initialized
INFO - 2022-06-09 03:12:28 --> Security Class Initialized
DEBUG - 2022-06-09 03:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:12:28 --> Input Class Initialized
INFO - 2022-06-09 03:12:28 --> Language Class Initialized
INFO - 2022-06-09 03:12:28 --> Language Class Initialized
INFO - 2022-06-09 03:12:28 --> Config Class Initialized
INFO - 2022-06-09 03:12:28 --> Loader Class Initialized
INFO - 2022-06-09 03:12:28 --> Helper loaded: url_helper
INFO - 2022-06-09 03:12:28 --> Helper loaded: file_helper
INFO - 2022-06-09 03:12:28 --> Helper loaded: form_helper
INFO - 2022-06-09 03:12:28 --> Helper loaded: my_helper
INFO - 2022-06-09 03:12:28 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:12:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:12:28 --> Controller Class Initialized
INFO - 2022-06-09 03:12:28 --> Final output sent to browser
DEBUG - 2022-06-09 03:12:28 --> Total execution time: 0.0595
INFO - 2022-06-09 03:12:37 --> Config Class Initialized
INFO - 2022-06-09 03:12:37 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:12:37 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:12:37 --> Utf8 Class Initialized
INFO - 2022-06-09 03:12:37 --> URI Class Initialized
INFO - 2022-06-09 03:12:37 --> Router Class Initialized
INFO - 2022-06-09 03:12:37 --> Output Class Initialized
INFO - 2022-06-09 03:12:37 --> Security Class Initialized
DEBUG - 2022-06-09 03:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:12:37 --> Input Class Initialized
INFO - 2022-06-09 03:12:37 --> Language Class Initialized
INFO - 2022-06-09 03:12:37 --> Language Class Initialized
INFO - 2022-06-09 03:12:37 --> Config Class Initialized
INFO - 2022-06-09 03:12:37 --> Loader Class Initialized
INFO - 2022-06-09 03:12:37 --> Helper loaded: url_helper
INFO - 2022-06-09 03:12:37 --> Helper loaded: file_helper
INFO - 2022-06-09 03:12:37 --> Helper loaded: form_helper
INFO - 2022-06-09 03:12:37 --> Helper loaded: my_helper
INFO - 2022-06-09 03:12:37 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:12:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:12:37 --> Controller Class Initialized
INFO - 2022-06-09 03:12:37 --> Final output sent to browser
DEBUG - 2022-06-09 03:12:37 --> Total execution time: 0.0821
INFO - 2022-06-09 03:12:37 --> Config Class Initialized
INFO - 2022-06-09 03:12:37 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:12:37 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:12:37 --> Utf8 Class Initialized
INFO - 2022-06-09 03:12:37 --> URI Class Initialized
INFO - 2022-06-09 03:12:37 --> Router Class Initialized
INFO - 2022-06-09 03:12:37 --> Output Class Initialized
INFO - 2022-06-09 03:12:37 --> Security Class Initialized
DEBUG - 2022-06-09 03:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:12:37 --> Input Class Initialized
INFO - 2022-06-09 03:12:37 --> Language Class Initialized
INFO - 2022-06-09 03:12:37 --> Language Class Initialized
INFO - 2022-06-09 03:12:37 --> Config Class Initialized
INFO - 2022-06-09 03:12:37 --> Loader Class Initialized
INFO - 2022-06-09 03:12:37 --> Helper loaded: url_helper
INFO - 2022-06-09 03:12:37 --> Helper loaded: file_helper
INFO - 2022-06-09 03:12:37 --> Helper loaded: form_helper
INFO - 2022-06-09 03:12:37 --> Helper loaded: my_helper
INFO - 2022-06-09 03:12:37 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:12:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:12:37 --> Controller Class Initialized
INFO - 2022-06-09 03:12:38 --> Config Class Initialized
INFO - 2022-06-09 03:12:38 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:12:38 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:12:38 --> Utf8 Class Initialized
INFO - 2022-06-09 03:12:38 --> URI Class Initialized
INFO - 2022-06-09 03:12:38 --> Router Class Initialized
INFO - 2022-06-09 03:12:38 --> Output Class Initialized
INFO - 2022-06-09 03:12:38 --> Security Class Initialized
DEBUG - 2022-06-09 03:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:12:38 --> Input Class Initialized
INFO - 2022-06-09 03:12:38 --> Language Class Initialized
INFO - 2022-06-09 03:12:38 --> Language Class Initialized
INFO - 2022-06-09 03:12:38 --> Config Class Initialized
INFO - 2022-06-09 03:12:38 --> Loader Class Initialized
INFO - 2022-06-09 03:12:38 --> Helper loaded: url_helper
INFO - 2022-06-09 03:12:38 --> Helper loaded: file_helper
INFO - 2022-06-09 03:12:38 --> Helper loaded: form_helper
INFO - 2022-06-09 03:12:38 --> Helper loaded: my_helper
INFO - 2022-06-09 03:12:38 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:12:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:12:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:12:38 --> Controller Class Initialized
INFO - 2022-06-09 03:12:38 --> Final output sent to browser
DEBUG - 2022-06-09 03:12:38 --> Total execution time: 0.0596
INFO - 2022-06-09 03:12:45 --> Config Class Initialized
INFO - 2022-06-09 03:12:45 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:12:45 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:12:45 --> Utf8 Class Initialized
INFO - 2022-06-09 03:12:45 --> URI Class Initialized
INFO - 2022-06-09 03:12:45 --> Router Class Initialized
INFO - 2022-06-09 03:12:45 --> Output Class Initialized
INFO - 2022-06-09 03:12:45 --> Security Class Initialized
DEBUG - 2022-06-09 03:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:12:45 --> Input Class Initialized
INFO - 2022-06-09 03:12:45 --> Language Class Initialized
INFO - 2022-06-09 03:12:45 --> Language Class Initialized
INFO - 2022-06-09 03:12:45 --> Config Class Initialized
INFO - 2022-06-09 03:12:45 --> Loader Class Initialized
INFO - 2022-06-09 03:12:45 --> Helper loaded: url_helper
INFO - 2022-06-09 03:12:45 --> Helper loaded: file_helper
INFO - 2022-06-09 03:12:45 --> Helper loaded: form_helper
INFO - 2022-06-09 03:12:45 --> Helper loaded: my_helper
INFO - 2022-06-09 03:12:45 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:12:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:12:45 --> Controller Class Initialized
INFO - 2022-06-09 03:12:45 --> Final output sent to browser
DEBUG - 2022-06-09 03:12:45 --> Total execution time: 0.0755
INFO - 2022-06-09 03:12:45 --> Config Class Initialized
INFO - 2022-06-09 03:12:45 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:12:45 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:12:45 --> Utf8 Class Initialized
INFO - 2022-06-09 03:12:45 --> URI Class Initialized
INFO - 2022-06-09 03:12:45 --> Router Class Initialized
INFO - 2022-06-09 03:12:45 --> Output Class Initialized
INFO - 2022-06-09 03:12:45 --> Security Class Initialized
DEBUG - 2022-06-09 03:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:12:45 --> Input Class Initialized
INFO - 2022-06-09 03:12:45 --> Language Class Initialized
INFO - 2022-06-09 03:12:45 --> Language Class Initialized
INFO - 2022-06-09 03:12:45 --> Config Class Initialized
INFO - 2022-06-09 03:12:45 --> Loader Class Initialized
INFO - 2022-06-09 03:12:45 --> Helper loaded: url_helper
INFO - 2022-06-09 03:12:45 --> Helper loaded: file_helper
INFO - 2022-06-09 03:12:45 --> Helper loaded: form_helper
INFO - 2022-06-09 03:12:45 --> Helper loaded: my_helper
INFO - 2022-06-09 03:12:45 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:12:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:12:45 --> Controller Class Initialized
INFO - 2022-06-09 03:12:46 --> Config Class Initialized
INFO - 2022-06-09 03:12:46 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:12:46 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:12:46 --> Utf8 Class Initialized
INFO - 2022-06-09 03:12:46 --> URI Class Initialized
INFO - 2022-06-09 03:12:46 --> Router Class Initialized
INFO - 2022-06-09 03:12:46 --> Output Class Initialized
INFO - 2022-06-09 03:12:46 --> Security Class Initialized
DEBUG - 2022-06-09 03:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:12:46 --> Input Class Initialized
INFO - 2022-06-09 03:12:46 --> Language Class Initialized
INFO - 2022-06-09 03:12:46 --> Language Class Initialized
INFO - 2022-06-09 03:12:46 --> Config Class Initialized
INFO - 2022-06-09 03:12:46 --> Loader Class Initialized
INFO - 2022-06-09 03:12:46 --> Helper loaded: url_helper
INFO - 2022-06-09 03:12:46 --> Helper loaded: file_helper
INFO - 2022-06-09 03:12:46 --> Helper loaded: form_helper
INFO - 2022-06-09 03:12:46 --> Helper loaded: my_helper
INFO - 2022-06-09 03:12:46 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:12:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:12:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:12:46 --> Controller Class Initialized
INFO - 2022-06-09 03:12:46 --> Final output sent to browser
DEBUG - 2022-06-09 03:12:46 --> Total execution time: 0.0739
INFO - 2022-06-09 03:12:57 --> Config Class Initialized
INFO - 2022-06-09 03:12:57 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:12:57 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:12:57 --> Utf8 Class Initialized
INFO - 2022-06-09 03:12:57 --> URI Class Initialized
INFO - 2022-06-09 03:12:57 --> Router Class Initialized
INFO - 2022-06-09 03:12:57 --> Output Class Initialized
INFO - 2022-06-09 03:12:57 --> Security Class Initialized
DEBUG - 2022-06-09 03:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:12:57 --> Input Class Initialized
INFO - 2022-06-09 03:12:57 --> Language Class Initialized
INFO - 2022-06-09 03:12:57 --> Language Class Initialized
INFO - 2022-06-09 03:12:57 --> Config Class Initialized
INFO - 2022-06-09 03:12:57 --> Loader Class Initialized
INFO - 2022-06-09 03:12:57 --> Helper loaded: url_helper
INFO - 2022-06-09 03:12:57 --> Helper loaded: file_helper
INFO - 2022-06-09 03:12:57 --> Helper loaded: form_helper
INFO - 2022-06-09 03:12:57 --> Helper loaded: my_helper
INFO - 2022-06-09 03:12:57 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:12:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:12:57 --> Controller Class Initialized
INFO - 2022-06-09 03:12:57 --> Final output sent to browser
DEBUG - 2022-06-09 03:12:57 --> Total execution time: 0.0780
INFO - 2022-06-09 03:12:57 --> Config Class Initialized
INFO - 2022-06-09 03:12:57 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:12:57 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:12:57 --> Utf8 Class Initialized
INFO - 2022-06-09 03:12:57 --> URI Class Initialized
INFO - 2022-06-09 03:12:57 --> Router Class Initialized
INFO - 2022-06-09 03:12:57 --> Output Class Initialized
INFO - 2022-06-09 03:12:57 --> Security Class Initialized
DEBUG - 2022-06-09 03:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:12:57 --> Input Class Initialized
INFO - 2022-06-09 03:12:57 --> Language Class Initialized
INFO - 2022-06-09 03:12:57 --> Language Class Initialized
INFO - 2022-06-09 03:12:57 --> Config Class Initialized
INFO - 2022-06-09 03:12:57 --> Loader Class Initialized
INFO - 2022-06-09 03:12:57 --> Helper loaded: url_helper
INFO - 2022-06-09 03:12:57 --> Helper loaded: file_helper
INFO - 2022-06-09 03:12:57 --> Helper loaded: form_helper
INFO - 2022-06-09 03:12:57 --> Helper loaded: my_helper
INFO - 2022-06-09 03:12:57 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:12:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:12:57 --> Controller Class Initialized
INFO - 2022-06-09 03:12:58 --> Config Class Initialized
INFO - 2022-06-09 03:12:58 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:12:58 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:12:58 --> Utf8 Class Initialized
INFO - 2022-06-09 03:12:58 --> URI Class Initialized
INFO - 2022-06-09 03:12:58 --> Router Class Initialized
INFO - 2022-06-09 03:12:58 --> Output Class Initialized
INFO - 2022-06-09 03:12:58 --> Security Class Initialized
DEBUG - 2022-06-09 03:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:12:58 --> Input Class Initialized
INFO - 2022-06-09 03:12:58 --> Language Class Initialized
INFO - 2022-06-09 03:12:58 --> Language Class Initialized
INFO - 2022-06-09 03:12:58 --> Config Class Initialized
INFO - 2022-06-09 03:12:58 --> Loader Class Initialized
INFO - 2022-06-09 03:12:58 --> Helper loaded: url_helper
INFO - 2022-06-09 03:12:58 --> Helper loaded: file_helper
INFO - 2022-06-09 03:12:58 --> Helper loaded: form_helper
INFO - 2022-06-09 03:12:58 --> Helper loaded: my_helper
INFO - 2022-06-09 03:12:58 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:12:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:12:58 --> Controller Class Initialized
INFO - 2022-06-09 03:12:58 --> Final output sent to browser
DEBUG - 2022-06-09 03:12:58 --> Total execution time: 0.0742
INFO - 2022-06-09 03:13:07 --> Config Class Initialized
INFO - 2022-06-09 03:13:07 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:13:07 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:13:07 --> Utf8 Class Initialized
INFO - 2022-06-09 03:13:07 --> URI Class Initialized
INFO - 2022-06-09 03:13:07 --> Router Class Initialized
INFO - 2022-06-09 03:13:07 --> Output Class Initialized
INFO - 2022-06-09 03:13:07 --> Security Class Initialized
DEBUG - 2022-06-09 03:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:13:07 --> Input Class Initialized
INFO - 2022-06-09 03:13:07 --> Language Class Initialized
INFO - 2022-06-09 03:13:07 --> Language Class Initialized
INFO - 2022-06-09 03:13:07 --> Config Class Initialized
INFO - 2022-06-09 03:13:07 --> Loader Class Initialized
INFO - 2022-06-09 03:13:07 --> Helper loaded: url_helper
INFO - 2022-06-09 03:13:07 --> Helper loaded: file_helper
INFO - 2022-06-09 03:13:07 --> Helper loaded: form_helper
INFO - 2022-06-09 03:13:07 --> Helper loaded: my_helper
INFO - 2022-06-09 03:13:07 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:13:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:13:08 --> Controller Class Initialized
INFO - 2022-06-09 03:13:08 --> Final output sent to browser
DEBUG - 2022-06-09 03:13:08 --> Total execution time: 0.0711
INFO - 2022-06-09 03:13:08 --> Config Class Initialized
INFO - 2022-06-09 03:13:08 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:13:08 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:13:08 --> Utf8 Class Initialized
INFO - 2022-06-09 03:13:08 --> URI Class Initialized
INFO - 2022-06-09 03:13:08 --> Router Class Initialized
INFO - 2022-06-09 03:13:08 --> Output Class Initialized
INFO - 2022-06-09 03:13:08 --> Security Class Initialized
DEBUG - 2022-06-09 03:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:13:08 --> Input Class Initialized
INFO - 2022-06-09 03:13:08 --> Language Class Initialized
INFO - 2022-06-09 03:13:08 --> Language Class Initialized
INFO - 2022-06-09 03:13:08 --> Config Class Initialized
INFO - 2022-06-09 03:13:08 --> Loader Class Initialized
INFO - 2022-06-09 03:13:08 --> Helper loaded: url_helper
INFO - 2022-06-09 03:13:08 --> Helper loaded: file_helper
INFO - 2022-06-09 03:13:08 --> Helper loaded: form_helper
INFO - 2022-06-09 03:13:08 --> Helper loaded: my_helper
INFO - 2022-06-09 03:13:08 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:13:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:13:08 --> Controller Class Initialized
INFO - 2022-06-09 03:13:09 --> Config Class Initialized
INFO - 2022-06-09 03:13:09 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:13:09 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:13:09 --> Utf8 Class Initialized
INFO - 2022-06-09 03:13:09 --> URI Class Initialized
INFO - 2022-06-09 03:13:09 --> Router Class Initialized
INFO - 2022-06-09 03:13:09 --> Output Class Initialized
INFO - 2022-06-09 03:13:09 --> Security Class Initialized
DEBUG - 2022-06-09 03:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:13:09 --> Input Class Initialized
INFO - 2022-06-09 03:13:09 --> Language Class Initialized
INFO - 2022-06-09 03:13:09 --> Language Class Initialized
INFO - 2022-06-09 03:13:09 --> Config Class Initialized
INFO - 2022-06-09 03:13:09 --> Loader Class Initialized
INFO - 2022-06-09 03:13:09 --> Helper loaded: url_helper
INFO - 2022-06-09 03:13:09 --> Helper loaded: file_helper
INFO - 2022-06-09 03:13:09 --> Helper loaded: form_helper
INFO - 2022-06-09 03:13:09 --> Helper loaded: my_helper
INFO - 2022-06-09 03:13:09 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:13:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:13:09 --> Controller Class Initialized
INFO - 2022-06-09 03:13:09 --> Final output sent to browser
DEBUG - 2022-06-09 03:13:09 --> Total execution time: 0.0843
INFO - 2022-06-09 03:13:19 --> Config Class Initialized
INFO - 2022-06-09 03:13:19 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:13:19 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:13:19 --> Utf8 Class Initialized
INFO - 2022-06-09 03:13:19 --> URI Class Initialized
INFO - 2022-06-09 03:13:19 --> Router Class Initialized
INFO - 2022-06-09 03:13:19 --> Output Class Initialized
INFO - 2022-06-09 03:13:19 --> Security Class Initialized
DEBUG - 2022-06-09 03:13:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:13:19 --> Input Class Initialized
INFO - 2022-06-09 03:13:19 --> Language Class Initialized
INFO - 2022-06-09 03:13:19 --> Language Class Initialized
INFO - 2022-06-09 03:13:19 --> Config Class Initialized
INFO - 2022-06-09 03:13:19 --> Loader Class Initialized
INFO - 2022-06-09 03:13:19 --> Helper loaded: url_helper
INFO - 2022-06-09 03:13:19 --> Helper loaded: file_helper
INFO - 2022-06-09 03:13:19 --> Helper loaded: form_helper
INFO - 2022-06-09 03:13:19 --> Helper loaded: my_helper
INFO - 2022-06-09 03:13:19 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:13:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:13:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:13:19 --> Controller Class Initialized
INFO - 2022-06-09 03:13:19 --> Final output sent to browser
DEBUG - 2022-06-09 03:13:19 --> Total execution time: 0.0606
INFO - 2022-06-09 03:13:19 --> Config Class Initialized
INFO - 2022-06-09 03:13:19 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:13:19 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:13:19 --> Utf8 Class Initialized
INFO - 2022-06-09 03:13:19 --> URI Class Initialized
INFO - 2022-06-09 03:13:19 --> Router Class Initialized
INFO - 2022-06-09 03:13:19 --> Output Class Initialized
INFO - 2022-06-09 03:13:19 --> Security Class Initialized
DEBUG - 2022-06-09 03:13:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:13:19 --> Input Class Initialized
INFO - 2022-06-09 03:13:19 --> Language Class Initialized
INFO - 2022-06-09 03:13:19 --> Language Class Initialized
INFO - 2022-06-09 03:13:19 --> Config Class Initialized
INFO - 2022-06-09 03:13:19 --> Loader Class Initialized
INFO - 2022-06-09 03:13:19 --> Helper loaded: url_helper
INFO - 2022-06-09 03:13:19 --> Helper loaded: file_helper
INFO - 2022-06-09 03:13:19 --> Helper loaded: form_helper
INFO - 2022-06-09 03:13:19 --> Helper loaded: my_helper
INFO - 2022-06-09 03:13:19 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:13:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:13:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:13:19 --> Controller Class Initialized
INFO - 2022-06-09 03:13:20 --> Config Class Initialized
INFO - 2022-06-09 03:13:20 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:13:20 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:13:20 --> Utf8 Class Initialized
INFO - 2022-06-09 03:13:20 --> URI Class Initialized
INFO - 2022-06-09 03:13:20 --> Router Class Initialized
INFO - 2022-06-09 03:13:20 --> Output Class Initialized
INFO - 2022-06-09 03:13:20 --> Security Class Initialized
DEBUG - 2022-06-09 03:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:13:20 --> Input Class Initialized
INFO - 2022-06-09 03:13:20 --> Language Class Initialized
INFO - 2022-06-09 03:13:20 --> Language Class Initialized
INFO - 2022-06-09 03:13:20 --> Config Class Initialized
INFO - 2022-06-09 03:13:20 --> Loader Class Initialized
INFO - 2022-06-09 03:13:20 --> Helper loaded: url_helper
INFO - 2022-06-09 03:13:20 --> Helper loaded: file_helper
INFO - 2022-06-09 03:13:20 --> Helper loaded: form_helper
INFO - 2022-06-09 03:13:20 --> Helper loaded: my_helper
INFO - 2022-06-09 03:13:20 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:13:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:13:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:13:20 --> Controller Class Initialized
INFO - 2022-06-09 03:13:20 --> Final output sent to browser
DEBUG - 2022-06-09 03:13:20 --> Total execution time: 0.0605
INFO - 2022-06-09 03:13:38 --> Config Class Initialized
INFO - 2022-06-09 03:13:38 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:13:38 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:13:38 --> Utf8 Class Initialized
INFO - 2022-06-09 03:13:38 --> URI Class Initialized
INFO - 2022-06-09 03:13:38 --> Router Class Initialized
INFO - 2022-06-09 03:13:38 --> Output Class Initialized
INFO - 2022-06-09 03:13:38 --> Security Class Initialized
DEBUG - 2022-06-09 03:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:13:38 --> Input Class Initialized
INFO - 2022-06-09 03:13:38 --> Language Class Initialized
INFO - 2022-06-09 03:13:38 --> Language Class Initialized
INFO - 2022-06-09 03:13:38 --> Config Class Initialized
INFO - 2022-06-09 03:13:38 --> Loader Class Initialized
INFO - 2022-06-09 03:13:38 --> Helper loaded: url_helper
INFO - 2022-06-09 03:13:38 --> Helper loaded: file_helper
INFO - 2022-06-09 03:13:38 --> Helper loaded: form_helper
INFO - 2022-06-09 03:13:38 --> Helper loaded: my_helper
INFO - 2022-06-09 03:13:38 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:13:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:13:38 --> Controller Class Initialized
INFO - 2022-06-09 03:13:38 --> Final output sent to browser
DEBUG - 2022-06-09 03:13:38 --> Total execution time: 0.0622
INFO - 2022-06-09 03:13:38 --> Config Class Initialized
INFO - 2022-06-09 03:13:38 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:13:38 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:13:38 --> Utf8 Class Initialized
INFO - 2022-06-09 03:13:38 --> URI Class Initialized
INFO - 2022-06-09 03:13:38 --> Router Class Initialized
INFO - 2022-06-09 03:13:38 --> Output Class Initialized
INFO - 2022-06-09 03:13:38 --> Security Class Initialized
DEBUG - 2022-06-09 03:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:13:38 --> Input Class Initialized
INFO - 2022-06-09 03:13:38 --> Language Class Initialized
INFO - 2022-06-09 03:13:38 --> Language Class Initialized
INFO - 2022-06-09 03:13:38 --> Config Class Initialized
INFO - 2022-06-09 03:13:38 --> Loader Class Initialized
INFO - 2022-06-09 03:13:38 --> Helper loaded: url_helper
INFO - 2022-06-09 03:13:38 --> Helper loaded: file_helper
INFO - 2022-06-09 03:13:38 --> Helper loaded: form_helper
INFO - 2022-06-09 03:13:38 --> Helper loaded: my_helper
INFO - 2022-06-09 03:13:38 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:13:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:13:38 --> Controller Class Initialized
INFO - 2022-06-09 03:13:40 --> Config Class Initialized
INFO - 2022-06-09 03:13:40 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:13:40 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:13:40 --> Utf8 Class Initialized
INFO - 2022-06-09 03:13:40 --> URI Class Initialized
INFO - 2022-06-09 03:13:40 --> Router Class Initialized
INFO - 2022-06-09 03:13:40 --> Output Class Initialized
INFO - 2022-06-09 03:13:40 --> Security Class Initialized
DEBUG - 2022-06-09 03:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:13:40 --> Input Class Initialized
INFO - 2022-06-09 03:13:40 --> Language Class Initialized
INFO - 2022-06-09 03:13:40 --> Language Class Initialized
INFO - 2022-06-09 03:13:40 --> Config Class Initialized
INFO - 2022-06-09 03:13:40 --> Loader Class Initialized
INFO - 2022-06-09 03:13:40 --> Helper loaded: url_helper
INFO - 2022-06-09 03:13:40 --> Helper loaded: file_helper
INFO - 2022-06-09 03:13:40 --> Helper loaded: form_helper
INFO - 2022-06-09 03:13:40 --> Helper loaded: my_helper
INFO - 2022-06-09 03:13:40 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:13:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:13:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:13:40 --> Controller Class Initialized
INFO - 2022-06-09 03:13:40 --> Final output sent to browser
DEBUG - 2022-06-09 03:13:40 --> Total execution time: 0.0679
INFO - 2022-06-09 03:13:50 --> Config Class Initialized
INFO - 2022-06-09 03:13:50 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:13:50 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:13:50 --> Utf8 Class Initialized
INFO - 2022-06-09 03:13:50 --> URI Class Initialized
INFO - 2022-06-09 03:13:50 --> Router Class Initialized
INFO - 2022-06-09 03:13:50 --> Output Class Initialized
INFO - 2022-06-09 03:13:50 --> Security Class Initialized
DEBUG - 2022-06-09 03:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:13:50 --> Input Class Initialized
INFO - 2022-06-09 03:13:50 --> Language Class Initialized
INFO - 2022-06-09 03:13:50 --> Language Class Initialized
INFO - 2022-06-09 03:13:50 --> Config Class Initialized
INFO - 2022-06-09 03:13:50 --> Loader Class Initialized
INFO - 2022-06-09 03:13:50 --> Helper loaded: url_helper
INFO - 2022-06-09 03:13:50 --> Helper loaded: file_helper
INFO - 2022-06-09 03:13:50 --> Helper loaded: form_helper
INFO - 2022-06-09 03:13:50 --> Helper loaded: my_helper
INFO - 2022-06-09 03:13:50 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:13:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:13:50 --> Controller Class Initialized
INFO - 2022-06-09 03:13:50 --> Final output sent to browser
DEBUG - 2022-06-09 03:13:50 --> Total execution time: 0.0591
INFO - 2022-06-09 03:13:50 --> Config Class Initialized
INFO - 2022-06-09 03:13:50 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:13:50 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:13:50 --> Utf8 Class Initialized
INFO - 2022-06-09 03:13:50 --> URI Class Initialized
INFO - 2022-06-09 03:13:50 --> Router Class Initialized
INFO - 2022-06-09 03:13:50 --> Output Class Initialized
INFO - 2022-06-09 03:13:50 --> Security Class Initialized
DEBUG - 2022-06-09 03:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:13:50 --> Input Class Initialized
INFO - 2022-06-09 03:13:50 --> Language Class Initialized
INFO - 2022-06-09 03:13:50 --> Language Class Initialized
INFO - 2022-06-09 03:13:50 --> Config Class Initialized
INFO - 2022-06-09 03:13:50 --> Loader Class Initialized
INFO - 2022-06-09 03:13:50 --> Helper loaded: url_helper
INFO - 2022-06-09 03:13:50 --> Helper loaded: file_helper
INFO - 2022-06-09 03:13:50 --> Helper loaded: form_helper
INFO - 2022-06-09 03:13:50 --> Helper loaded: my_helper
INFO - 2022-06-09 03:13:50 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:13:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:13:50 --> Controller Class Initialized
INFO - 2022-06-09 03:13:51 --> Config Class Initialized
INFO - 2022-06-09 03:13:51 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:13:51 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:13:51 --> Utf8 Class Initialized
INFO - 2022-06-09 03:13:51 --> URI Class Initialized
INFO - 2022-06-09 03:13:51 --> Router Class Initialized
INFO - 2022-06-09 03:13:51 --> Output Class Initialized
INFO - 2022-06-09 03:13:51 --> Security Class Initialized
DEBUG - 2022-06-09 03:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:13:51 --> Input Class Initialized
INFO - 2022-06-09 03:13:51 --> Language Class Initialized
INFO - 2022-06-09 03:13:51 --> Language Class Initialized
INFO - 2022-06-09 03:13:51 --> Config Class Initialized
INFO - 2022-06-09 03:13:51 --> Loader Class Initialized
INFO - 2022-06-09 03:13:51 --> Helper loaded: url_helper
INFO - 2022-06-09 03:13:51 --> Helper loaded: file_helper
INFO - 2022-06-09 03:13:51 --> Helper loaded: form_helper
INFO - 2022-06-09 03:13:51 --> Helper loaded: my_helper
INFO - 2022-06-09 03:13:51 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:13:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:13:51 --> Controller Class Initialized
INFO - 2022-06-09 03:13:51 --> Final output sent to browser
DEBUG - 2022-06-09 03:13:51 --> Total execution time: 0.0725
INFO - 2022-06-09 03:13:58 --> Config Class Initialized
INFO - 2022-06-09 03:13:58 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:13:58 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:13:58 --> Utf8 Class Initialized
INFO - 2022-06-09 03:13:58 --> URI Class Initialized
INFO - 2022-06-09 03:13:58 --> Router Class Initialized
INFO - 2022-06-09 03:13:58 --> Output Class Initialized
INFO - 2022-06-09 03:13:58 --> Security Class Initialized
DEBUG - 2022-06-09 03:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:13:58 --> Input Class Initialized
INFO - 2022-06-09 03:13:58 --> Language Class Initialized
INFO - 2022-06-09 03:13:58 --> Language Class Initialized
INFO - 2022-06-09 03:13:58 --> Config Class Initialized
INFO - 2022-06-09 03:13:58 --> Loader Class Initialized
INFO - 2022-06-09 03:13:58 --> Helper loaded: url_helper
INFO - 2022-06-09 03:13:58 --> Helper loaded: file_helper
INFO - 2022-06-09 03:13:58 --> Helper loaded: form_helper
INFO - 2022-06-09 03:13:58 --> Helper loaded: my_helper
INFO - 2022-06-09 03:13:58 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:13:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:13:58 --> Controller Class Initialized
INFO - 2022-06-09 03:13:58 --> Final output sent to browser
DEBUG - 2022-06-09 03:13:58 --> Total execution time: 0.0625
INFO - 2022-06-09 03:13:58 --> Config Class Initialized
INFO - 2022-06-09 03:13:58 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:13:58 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:13:58 --> Utf8 Class Initialized
INFO - 2022-06-09 03:13:58 --> URI Class Initialized
INFO - 2022-06-09 03:13:58 --> Router Class Initialized
INFO - 2022-06-09 03:13:58 --> Output Class Initialized
INFO - 2022-06-09 03:13:58 --> Security Class Initialized
DEBUG - 2022-06-09 03:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:13:58 --> Input Class Initialized
INFO - 2022-06-09 03:13:58 --> Language Class Initialized
INFO - 2022-06-09 03:13:58 --> Language Class Initialized
INFO - 2022-06-09 03:13:58 --> Config Class Initialized
INFO - 2022-06-09 03:13:58 --> Loader Class Initialized
INFO - 2022-06-09 03:13:58 --> Helper loaded: url_helper
INFO - 2022-06-09 03:13:58 --> Helper loaded: file_helper
INFO - 2022-06-09 03:13:58 --> Helper loaded: form_helper
INFO - 2022-06-09 03:13:58 --> Helper loaded: my_helper
INFO - 2022-06-09 03:13:58 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:13:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:13:58 --> Controller Class Initialized
INFO - 2022-06-09 03:13:59 --> Config Class Initialized
INFO - 2022-06-09 03:13:59 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:13:59 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:13:59 --> Utf8 Class Initialized
INFO - 2022-06-09 03:13:59 --> URI Class Initialized
INFO - 2022-06-09 03:13:59 --> Router Class Initialized
INFO - 2022-06-09 03:13:59 --> Output Class Initialized
INFO - 2022-06-09 03:13:59 --> Security Class Initialized
DEBUG - 2022-06-09 03:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:13:59 --> Input Class Initialized
INFO - 2022-06-09 03:13:59 --> Language Class Initialized
INFO - 2022-06-09 03:13:59 --> Language Class Initialized
INFO - 2022-06-09 03:13:59 --> Config Class Initialized
INFO - 2022-06-09 03:13:59 --> Loader Class Initialized
INFO - 2022-06-09 03:13:59 --> Helper loaded: url_helper
INFO - 2022-06-09 03:13:59 --> Helper loaded: file_helper
INFO - 2022-06-09 03:13:59 --> Helper loaded: form_helper
INFO - 2022-06-09 03:13:59 --> Helper loaded: my_helper
INFO - 2022-06-09 03:13:59 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:13:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:13:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:13:59 --> Controller Class Initialized
INFO - 2022-06-09 03:13:59 --> Final output sent to browser
DEBUG - 2022-06-09 03:13:59 --> Total execution time: 0.0824
INFO - 2022-06-09 03:14:06 --> Config Class Initialized
INFO - 2022-06-09 03:14:06 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:14:06 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:14:06 --> Utf8 Class Initialized
INFO - 2022-06-09 03:14:06 --> URI Class Initialized
INFO - 2022-06-09 03:14:06 --> Router Class Initialized
INFO - 2022-06-09 03:14:06 --> Output Class Initialized
INFO - 2022-06-09 03:14:06 --> Security Class Initialized
DEBUG - 2022-06-09 03:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:14:06 --> Input Class Initialized
INFO - 2022-06-09 03:14:06 --> Language Class Initialized
INFO - 2022-06-09 03:14:06 --> Language Class Initialized
INFO - 2022-06-09 03:14:06 --> Config Class Initialized
INFO - 2022-06-09 03:14:06 --> Loader Class Initialized
INFO - 2022-06-09 03:14:06 --> Helper loaded: url_helper
INFO - 2022-06-09 03:14:06 --> Helper loaded: file_helper
INFO - 2022-06-09 03:14:06 --> Helper loaded: form_helper
INFO - 2022-06-09 03:14:06 --> Helper loaded: my_helper
INFO - 2022-06-09 03:14:06 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:14:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:14:06 --> Controller Class Initialized
INFO - 2022-06-09 03:14:06 --> Final output sent to browser
DEBUG - 2022-06-09 03:14:06 --> Total execution time: 0.0648
INFO - 2022-06-09 03:14:06 --> Config Class Initialized
INFO - 2022-06-09 03:14:06 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:14:06 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:14:06 --> Utf8 Class Initialized
INFO - 2022-06-09 03:14:06 --> URI Class Initialized
INFO - 2022-06-09 03:14:06 --> Router Class Initialized
INFO - 2022-06-09 03:14:06 --> Output Class Initialized
INFO - 2022-06-09 03:14:06 --> Security Class Initialized
DEBUG - 2022-06-09 03:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:14:06 --> Input Class Initialized
INFO - 2022-06-09 03:14:06 --> Language Class Initialized
INFO - 2022-06-09 03:14:06 --> Language Class Initialized
INFO - 2022-06-09 03:14:06 --> Config Class Initialized
INFO - 2022-06-09 03:14:06 --> Loader Class Initialized
INFO - 2022-06-09 03:14:06 --> Helper loaded: url_helper
INFO - 2022-06-09 03:14:06 --> Helper loaded: file_helper
INFO - 2022-06-09 03:14:06 --> Helper loaded: form_helper
INFO - 2022-06-09 03:14:06 --> Helper loaded: my_helper
INFO - 2022-06-09 03:14:06 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:14:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:14:06 --> Controller Class Initialized
INFO - 2022-06-09 03:14:07 --> Config Class Initialized
INFO - 2022-06-09 03:14:07 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:14:07 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:14:07 --> Utf8 Class Initialized
INFO - 2022-06-09 03:14:07 --> URI Class Initialized
INFO - 2022-06-09 03:14:07 --> Router Class Initialized
INFO - 2022-06-09 03:14:07 --> Output Class Initialized
INFO - 2022-06-09 03:14:07 --> Security Class Initialized
DEBUG - 2022-06-09 03:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:14:07 --> Input Class Initialized
INFO - 2022-06-09 03:14:07 --> Language Class Initialized
INFO - 2022-06-09 03:14:07 --> Language Class Initialized
INFO - 2022-06-09 03:14:07 --> Config Class Initialized
INFO - 2022-06-09 03:14:07 --> Loader Class Initialized
INFO - 2022-06-09 03:14:07 --> Helper loaded: url_helper
INFO - 2022-06-09 03:14:07 --> Helper loaded: file_helper
INFO - 2022-06-09 03:14:07 --> Helper loaded: form_helper
INFO - 2022-06-09 03:14:07 --> Helper loaded: my_helper
INFO - 2022-06-09 03:14:07 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:14:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:14:07 --> Controller Class Initialized
INFO - 2022-06-09 03:14:07 --> Final output sent to browser
DEBUG - 2022-06-09 03:14:07 --> Total execution time: 0.0604
INFO - 2022-06-09 03:14:20 --> Config Class Initialized
INFO - 2022-06-09 03:14:20 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:14:20 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:14:20 --> Utf8 Class Initialized
INFO - 2022-06-09 03:14:20 --> URI Class Initialized
INFO - 2022-06-09 03:14:20 --> Router Class Initialized
INFO - 2022-06-09 03:14:20 --> Output Class Initialized
INFO - 2022-06-09 03:14:20 --> Security Class Initialized
DEBUG - 2022-06-09 03:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:14:20 --> Input Class Initialized
INFO - 2022-06-09 03:14:20 --> Language Class Initialized
INFO - 2022-06-09 03:14:20 --> Language Class Initialized
INFO - 2022-06-09 03:14:20 --> Config Class Initialized
INFO - 2022-06-09 03:14:20 --> Loader Class Initialized
INFO - 2022-06-09 03:14:20 --> Helper loaded: url_helper
INFO - 2022-06-09 03:14:20 --> Helper loaded: file_helper
INFO - 2022-06-09 03:14:20 --> Helper loaded: form_helper
INFO - 2022-06-09 03:14:20 --> Helper loaded: my_helper
INFO - 2022-06-09 03:14:20 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:14:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:14:20 --> Controller Class Initialized
INFO - 2022-06-09 03:14:20 --> Final output sent to browser
DEBUG - 2022-06-09 03:14:20 --> Total execution time: 0.0712
INFO - 2022-06-09 03:14:20 --> Config Class Initialized
INFO - 2022-06-09 03:14:20 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:14:20 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:14:20 --> Utf8 Class Initialized
INFO - 2022-06-09 03:14:20 --> URI Class Initialized
INFO - 2022-06-09 03:14:20 --> Router Class Initialized
INFO - 2022-06-09 03:14:20 --> Output Class Initialized
INFO - 2022-06-09 03:14:20 --> Security Class Initialized
DEBUG - 2022-06-09 03:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:14:20 --> Input Class Initialized
INFO - 2022-06-09 03:14:20 --> Language Class Initialized
INFO - 2022-06-09 03:14:20 --> Language Class Initialized
INFO - 2022-06-09 03:14:20 --> Config Class Initialized
INFO - 2022-06-09 03:14:20 --> Loader Class Initialized
INFO - 2022-06-09 03:14:20 --> Helper loaded: url_helper
INFO - 2022-06-09 03:14:20 --> Helper loaded: file_helper
INFO - 2022-06-09 03:14:20 --> Helper loaded: form_helper
INFO - 2022-06-09 03:14:20 --> Helper loaded: my_helper
INFO - 2022-06-09 03:14:20 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:14:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:14:20 --> Controller Class Initialized
INFO - 2022-06-09 03:14:21 --> Config Class Initialized
INFO - 2022-06-09 03:14:21 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:14:21 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:14:21 --> Utf8 Class Initialized
INFO - 2022-06-09 03:14:21 --> URI Class Initialized
INFO - 2022-06-09 03:14:21 --> Router Class Initialized
INFO - 2022-06-09 03:14:21 --> Output Class Initialized
INFO - 2022-06-09 03:14:21 --> Security Class Initialized
DEBUG - 2022-06-09 03:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:14:21 --> Input Class Initialized
INFO - 2022-06-09 03:14:21 --> Language Class Initialized
INFO - 2022-06-09 03:14:21 --> Language Class Initialized
INFO - 2022-06-09 03:14:21 --> Config Class Initialized
INFO - 2022-06-09 03:14:21 --> Loader Class Initialized
INFO - 2022-06-09 03:14:21 --> Helper loaded: url_helper
INFO - 2022-06-09 03:14:21 --> Helper loaded: file_helper
INFO - 2022-06-09 03:14:21 --> Helper loaded: form_helper
INFO - 2022-06-09 03:14:21 --> Helper loaded: my_helper
INFO - 2022-06-09 03:14:21 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:14:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:14:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:14:21 --> Controller Class Initialized
INFO - 2022-06-09 03:14:21 --> Final output sent to browser
DEBUG - 2022-06-09 03:14:21 --> Total execution time: 0.0710
INFO - 2022-06-09 03:14:30 --> Config Class Initialized
INFO - 2022-06-09 03:14:30 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:14:30 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:14:30 --> Utf8 Class Initialized
INFO - 2022-06-09 03:14:30 --> URI Class Initialized
INFO - 2022-06-09 03:14:30 --> Router Class Initialized
INFO - 2022-06-09 03:14:30 --> Output Class Initialized
INFO - 2022-06-09 03:14:30 --> Security Class Initialized
DEBUG - 2022-06-09 03:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:14:30 --> Input Class Initialized
INFO - 2022-06-09 03:14:30 --> Language Class Initialized
INFO - 2022-06-09 03:14:30 --> Language Class Initialized
INFO - 2022-06-09 03:14:30 --> Config Class Initialized
INFO - 2022-06-09 03:14:30 --> Loader Class Initialized
INFO - 2022-06-09 03:14:30 --> Helper loaded: url_helper
INFO - 2022-06-09 03:14:30 --> Helper loaded: file_helper
INFO - 2022-06-09 03:14:30 --> Helper loaded: form_helper
INFO - 2022-06-09 03:14:30 --> Helper loaded: my_helper
INFO - 2022-06-09 03:14:30 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:14:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:14:30 --> Controller Class Initialized
INFO - 2022-06-09 03:14:30 --> Final output sent to browser
DEBUG - 2022-06-09 03:14:30 --> Total execution time: 0.0736
INFO - 2022-06-09 03:14:30 --> Config Class Initialized
INFO - 2022-06-09 03:14:30 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:14:30 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:14:30 --> Utf8 Class Initialized
INFO - 2022-06-09 03:14:30 --> URI Class Initialized
INFO - 2022-06-09 03:14:30 --> Router Class Initialized
INFO - 2022-06-09 03:14:30 --> Output Class Initialized
INFO - 2022-06-09 03:14:30 --> Security Class Initialized
DEBUG - 2022-06-09 03:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:14:30 --> Input Class Initialized
INFO - 2022-06-09 03:14:30 --> Language Class Initialized
INFO - 2022-06-09 03:14:30 --> Language Class Initialized
INFO - 2022-06-09 03:14:30 --> Config Class Initialized
INFO - 2022-06-09 03:14:30 --> Loader Class Initialized
INFO - 2022-06-09 03:14:30 --> Helper loaded: url_helper
INFO - 2022-06-09 03:14:30 --> Helper loaded: file_helper
INFO - 2022-06-09 03:14:30 --> Helper loaded: form_helper
INFO - 2022-06-09 03:14:30 --> Helper loaded: my_helper
INFO - 2022-06-09 03:14:30 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:14:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:14:30 --> Controller Class Initialized
INFO - 2022-06-09 03:14:31 --> Config Class Initialized
INFO - 2022-06-09 03:14:31 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:14:31 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:14:31 --> Utf8 Class Initialized
INFO - 2022-06-09 03:14:31 --> URI Class Initialized
INFO - 2022-06-09 03:14:31 --> Router Class Initialized
INFO - 2022-06-09 03:14:31 --> Output Class Initialized
INFO - 2022-06-09 03:14:31 --> Security Class Initialized
DEBUG - 2022-06-09 03:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:14:31 --> Input Class Initialized
INFO - 2022-06-09 03:14:31 --> Language Class Initialized
INFO - 2022-06-09 03:14:31 --> Language Class Initialized
INFO - 2022-06-09 03:14:31 --> Config Class Initialized
INFO - 2022-06-09 03:14:31 --> Loader Class Initialized
INFO - 2022-06-09 03:14:31 --> Helper loaded: url_helper
INFO - 2022-06-09 03:14:31 --> Helper loaded: file_helper
INFO - 2022-06-09 03:14:31 --> Helper loaded: form_helper
INFO - 2022-06-09 03:14:31 --> Helper loaded: my_helper
INFO - 2022-06-09 03:14:31 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:14:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:14:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:14:31 --> Controller Class Initialized
INFO - 2022-06-09 03:14:31 --> Final output sent to browser
DEBUG - 2022-06-09 03:14:31 --> Total execution time: 0.0568
INFO - 2022-06-09 03:14:43 --> Config Class Initialized
INFO - 2022-06-09 03:14:43 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:14:43 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:14:43 --> Utf8 Class Initialized
INFO - 2022-06-09 03:14:43 --> URI Class Initialized
INFO - 2022-06-09 03:14:43 --> Router Class Initialized
INFO - 2022-06-09 03:14:43 --> Output Class Initialized
INFO - 2022-06-09 03:14:43 --> Security Class Initialized
DEBUG - 2022-06-09 03:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:14:43 --> Input Class Initialized
INFO - 2022-06-09 03:14:43 --> Language Class Initialized
INFO - 2022-06-09 03:14:43 --> Language Class Initialized
INFO - 2022-06-09 03:14:43 --> Config Class Initialized
INFO - 2022-06-09 03:14:43 --> Loader Class Initialized
INFO - 2022-06-09 03:14:43 --> Helper loaded: url_helper
INFO - 2022-06-09 03:14:43 --> Helper loaded: file_helper
INFO - 2022-06-09 03:14:43 --> Helper loaded: form_helper
INFO - 2022-06-09 03:14:43 --> Helper loaded: my_helper
INFO - 2022-06-09 03:14:43 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:14:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:14:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:14:43 --> Controller Class Initialized
INFO - 2022-06-09 03:14:43 --> Final output sent to browser
DEBUG - 2022-06-09 03:14:43 --> Total execution time: 0.0749
INFO - 2022-06-09 03:14:43 --> Config Class Initialized
INFO - 2022-06-09 03:14:43 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:14:43 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:14:43 --> Utf8 Class Initialized
INFO - 2022-06-09 03:14:43 --> URI Class Initialized
INFO - 2022-06-09 03:14:43 --> Router Class Initialized
INFO - 2022-06-09 03:14:43 --> Output Class Initialized
INFO - 2022-06-09 03:14:43 --> Security Class Initialized
DEBUG - 2022-06-09 03:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:14:43 --> Input Class Initialized
INFO - 2022-06-09 03:14:43 --> Language Class Initialized
INFO - 2022-06-09 03:14:43 --> Language Class Initialized
INFO - 2022-06-09 03:14:43 --> Config Class Initialized
INFO - 2022-06-09 03:14:43 --> Loader Class Initialized
INFO - 2022-06-09 03:14:43 --> Helper loaded: url_helper
INFO - 2022-06-09 03:14:43 --> Helper loaded: file_helper
INFO - 2022-06-09 03:14:43 --> Helper loaded: form_helper
INFO - 2022-06-09 03:14:43 --> Helper loaded: my_helper
INFO - 2022-06-09 03:14:43 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:14:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:14:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:14:43 --> Controller Class Initialized
INFO - 2022-06-09 03:14:44 --> Config Class Initialized
INFO - 2022-06-09 03:14:44 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:14:44 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:14:44 --> Utf8 Class Initialized
INFO - 2022-06-09 03:14:44 --> URI Class Initialized
INFO - 2022-06-09 03:14:44 --> Router Class Initialized
INFO - 2022-06-09 03:14:44 --> Output Class Initialized
INFO - 2022-06-09 03:14:44 --> Security Class Initialized
DEBUG - 2022-06-09 03:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:14:44 --> Input Class Initialized
INFO - 2022-06-09 03:14:44 --> Language Class Initialized
INFO - 2022-06-09 03:14:44 --> Language Class Initialized
INFO - 2022-06-09 03:14:44 --> Config Class Initialized
INFO - 2022-06-09 03:14:44 --> Loader Class Initialized
INFO - 2022-06-09 03:14:44 --> Helper loaded: url_helper
INFO - 2022-06-09 03:14:44 --> Helper loaded: file_helper
INFO - 2022-06-09 03:14:44 --> Helper loaded: form_helper
INFO - 2022-06-09 03:14:44 --> Helper loaded: my_helper
INFO - 2022-06-09 03:14:44 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:14:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:14:44 --> Controller Class Initialized
INFO - 2022-06-09 03:14:44 --> Final output sent to browser
DEBUG - 2022-06-09 03:14:44 --> Total execution time: 0.0552
INFO - 2022-06-09 03:14:51 --> Config Class Initialized
INFO - 2022-06-09 03:14:51 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:14:51 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:14:51 --> Utf8 Class Initialized
INFO - 2022-06-09 03:14:51 --> URI Class Initialized
INFO - 2022-06-09 03:14:51 --> Router Class Initialized
INFO - 2022-06-09 03:14:51 --> Output Class Initialized
INFO - 2022-06-09 03:14:51 --> Security Class Initialized
DEBUG - 2022-06-09 03:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:14:51 --> Input Class Initialized
INFO - 2022-06-09 03:14:51 --> Language Class Initialized
INFO - 2022-06-09 03:14:51 --> Language Class Initialized
INFO - 2022-06-09 03:14:51 --> Config Class Initialized
INFO - 2022-06-09 03:14:51 --> Loader Class Initialized
INFO - 2022-06-09 03:14:51 --> Helper loaded: url_helper
INFO - 2022-06-09 03:14:51 --> Helper loaded: file_helper
INFO - 2022-06-09 03:14:51 --> Helper loaded: form_helper
INFO - 2022-06-09 03:14:51 --> Helper loaded: my_helper
INFO - 2022-06-09 03:14:51 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:14:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:14:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:14:51 --> Controller Class Initialized
INFO - 2022-06-09 03:14:51 --> Final output sent to browser
DEBUG - 2022-06-09 03:14:51 --> Total execution time: 0.0760
INFO - 2022-06-09 03:14:51 --> Config Class Initialized
INFO - 2022-06-09 03:14:51 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:14:51 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:14:51 --> Utf8 Class Initialized
INFO - 2022-06-09 03:14:51 --> URI Class Initialized
INFO - 2022-06-09 03:14:51 --> Router Class Initialized
INFO - 2022-06-09 03:14:51 --> Output Class Initialized
INFO - 2022-06-09 03:14:51 --> Security Class Initialized
DEBUG - 2022-06-09 03:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:14:51 --> Input Class Initialized
INFO - 2022-06-09 03:14:51 --> Language Class Initialized
INFO - 2022-06-09 03:14:51 --> Language Class Initialized
INFO - 2022-06-09 03:14:51 --> Config Class Initialized
INFO - 2022-06-09 03:14:51 --> Loader Class Initialized
INFO - 2022-06-09 03:14:51 --> Helper loaded: url_helper
INFO - 2022-06-09 03:14:51 --> Helper loaded: file_helper
INFO - 2022-06-09 03:14:51 --> Helper loaded: form_helper
INFO - 2022-06-09 03:14:51 --> Helper loaded: my_helper
INFO - 2022-06-09 03:14:51 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:14:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:14:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:14:51 --> Controller Class Initialized
INFO - 2022-06-09 03:14:53 --> Config Class Initialized
INFO - 2022-06-09 03:14:53 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:14:53 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:14:53 --> Utf8 Class Initialized
INFO - 2022-06-09 03:14:53 --> URI Class Initialized
INFO - 2022-06-09 03:14:53 --> Router Class Initialized
INFO - 2022-06-09 03:14:53 --> Output Class Initialized
INFO - 2022-06-09 03:14:53 --> Security Class Initialized
DEBUG - 2022-06-09 03:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:14:53 --> Input Class Initialized
INFO - 2022-06-09 03:14:53 --> Language Class Initialized
INFO - 2022-06-09 03:14:53 --> Language Class Initialized
INFO - 2022-06-09 03:14:53 --> Config Class Initialized
INFO - 2022-06-09 03:14:53 --> Loader Class Initialized
INFO - 2022-06-09 03:14:53 --> Helper loaded: url_helper
INFO - 2022-06-09 03:14:53 --> Helper loaded: file_helper
INFO - 2022-06-09 03:14:53 --> Helper loaded: form_helper
INFO - 2022-06-09 03:14:53 --> Helper loaded: my_helper
INFO - 2022-06-09 03:14:53 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:14:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:14:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:14:53 --> Controller Class Initialized
INFO - 2022-06-09 03:14:53 --> Final output sent to browser
DEBUG - 2022-06-09 03:14:53 --> Total execution time: 0.0550
INFO - 2022-06-09 03:15:03 --> Config Class Initialized
INFO - 2022-06-09 03:15:03 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:15:03 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:15:03 --> Utf8 Class Initialized
INFO - 2022-06-09 03:15:03 --> URI Class Initialized
INFO - 2022-06-09 03:15:03 --> Router Class Initialized
INFO - 2022-06-09 03:15:03 --> Output Class Initialized
INFO - 2022-06-09 03:15:03 --> Security Class Initialized
DEBUG - 2022-06-09 03:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:15:03 --> Input Class Initialized
INFO - 2022-06-09 03:15:03 --> Language Class Initialized
INFO - 2022-06-09 03:15:03 --> Language Class Initialized
INFO - 2022-06-09 03:15:03 --> Config Class Initialized
INFO - 2022-06-09 03:15:03 --> Loader Class Initialized
INFO - 2022-06-09 03:15:03 --> Helper loaded: url_helper
INFO - 2022-06-09 03:15:03 --> Helper loaded: file_helper
INFO - 2022-06-09 03:15:03 --> Helper loaded: form_helper
INFO - 2022-06-09 03:15:03 --> Helper loaded: my_helper
INFO - 2022-06-09 03:15:03 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:15:03 --> Controller Class Initialized
INFO - 2022-06-09 03:15:03 --> Final output sent to browser
DEBUG - 2022-06-09 03:15:03 --> Total execution time: 0.0807
INFO - 2022-06-09 03:15:03 --> Config Class Initialized
INFO - 2022-06-09 03:15:03 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:15:03 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:15:03 --> Utf8 Class Initialized
INFO - 2022-06-09 03:15:03 --> URI Class Initialized
INFO - 2022-06-09 03:15:03 --> Router Class Initialized
INFO - 2022-06-09 03:15:03 --> Output Class Initialized
INFO - 2022-06-09 03:15:03 --> Security Class Initialized
DEBUG - 2022-06-09 03:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:15:03 --> Input Class Initialized
INFO - 2022-06-09 03:15:03 --> Language Class Initialized
INFO - 2022-06-09 03:15:03 --> Language Class Initialized
INFO - 2022-06-09 03:15:03 --> Config Class Initialized
INFO - 2022-06-09 03:15:03 --> Loader Class Initialized
INFO - 2022-06-09 03:15:03 --> Helper loaded: url_helper
INFO - 2022-06-09 03:15:03 --> Helper loaded: file_helper
INFO - 2022-06-09 03:15:03 --> Helper loaded: form_helper
INFO - 2022-06-09 03:15:03 --> Helper loaded: my_helper
INFO - 2022-06-09 03:15:03 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:15:03 --> Controller Class Initialized
INFO - 2022-06-09 03:15:04 --> Config Class Initialized
INFO - 2022-06-09 03:15:04 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:15:04 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:15:04 --> Utf8 Class Initialized
INFO - 2022-06-09 03:15:04 --> URI Class Initialized
INFO - 2022-06-09 03:15:04 --> Router Class Initialized
INFO - 2022-06-09 03:15:04 --> Output Class Initialized
INFO - 2022-06-09 03:15:04 --> Security Class Initialized
DEBUG - 2022-06-09 03:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:15:04 --> Input Class Initialized
INFO - 2022-06-09 03:15:04 --> Language Class Initialized
INFO - 2022-06-09 03:15:04 --> Language Class Initialized
INFO - 2022-06-09 03:15:04 --> Config Class Initialized
INFO - 2022-06-09 03:15:04 --> Loader Class Initialized
INFO - 2022-06-09 03:15:04 --> Helper loaded: url_helper
INFO - 2022-06-09 03:15:04 --> Helper loaded: file_helper
INFO - 2022-06-09 03:15:04 --> Helper loaded: form_helper
INFO - 2022-06-09 03:15:04 --> Helper loaded: my_helper
INFO - 2022-06-09 03:15:04 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:15:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:15:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:15:04 --> Controller Class Initialized
INFO - 2022-06-09 03:15:04 --> Final output sent to browser
DEBUG - 2022-06-09 03:15:04 --> Total execution time: 0.0695
INFO - 2022-06-09 03:15:17 --> Config Class Initialized
INFO - 2022-06-09 03:15:17 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:15:17 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:15:17 --> Utf8 Class Initialized
INFO - 2022-06-09 03:15:17 --> URI Class Initialized
INFO - 2022-06-09 03:15:17 --> Router Class Initialized
INFO - 2022-06-09 03:15:17 --> Output Class Initialized
INFO - 2022-06-09 03:15:17 --> Security Class Initialized
DEBUG - 2022-06-09 03:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:15:17 --> Input Class Initialized
INFO - 2022-06-09 03:15:17 --> Language Class Initialized
INFO - 2022-06-09 03:15:17 --> Language Class Initialized
INFO - 2022-06-09 03:15:17 --> Config Class Initialized
INFO - 2022-06-09 03:15:17 --> Loader Class Initialized
INFO - 2022-06-09 03:15:17 --> Helper loaded: url_helper
INFO - 2022-06-09 03:15:17 --> Helper loaded: file_helper
INFO - 2022-06-09 03:15:17 --> Helper loaded: form_helper
INFO - 2022-06-09 03:15:17 --> Helper loaded: my_helper
INFO - 2022-06-09 03:15:17 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:15:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:15:17 --> Controller Class Initialized
INFO - 2022-06-09 03:15:17 --> Final output sent to browser
DEBUG - 2022-06-09 03:15:17 --> Total execution time: 0.0735
INFO - 2022-06-09 03:15:17 --> Config Class Initialized
INFO - 2022-06-09 03:15:17 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:15:17 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:15:17 --> Utf8 Class Initialized
INFO - 2022-06-09 03:15:17 --> URI Class Initialized
INFO - 2022-06-09 03:15:17 --> Router Class Initialized
INFO - 2022-06-09 03:15:17 --> Output Class Initialized
INFO - 2022-06-09 03:15:17 --> Security Class Initialized
DEBUG - 2022-06-09 03:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:15:17 --> Input Class Initialized
INFO - 2022-06-09 03:15:17 --> Language Class Initialized
INFO - 2022-06-09 03:15:17 --> Language Class Initialized
INFO - 2022-06-09 03:15:17 --> Config Class Initialized
INFO - 2022-06-09 03:15:17 --> Loader Class Initialized
INFO - 2022-06-09 03:15:17 --> Helper loaded: url_helper
INFO - 2022-06-09 03:15:17 --> Helper loaded: file_helper
INFO - 2022-06-09 03:15:17 --> Helper loaded: form_helper
INFO - 2022-06-09 03:15:17 --> Helper loaded: my_helper
INFO - 2022-06-09 03:15:17 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:15:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:15:17 --> Controller Class Initialized
INFO - 2022-06-09 03:15:18 --> Config Class Initialized
INFO - 2022-06-09 03:15:18 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:15:18 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:15:18 --> Utf8 Class Initialized
INFO - 2022-06-09 03:15:18 --> URI Class Initialized
INFO - 2022-06-09 03:15:18 --> Router Class Initialized
INFO - 2022-06-09 03:15:18 --> Output Class Initialized
INFO - 2022-06-09 03:15:18 --> Security Class Initialized
DEBUG - 2022-06-09 03:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:15:18 --> Input Class Initialized
INFO - 2022-06-09 03:15:18 --> Language Class Initialized
INFO - 2022-06-09 03:15:18 --> Language Class Initialized
INFO - 2022-06-09 03:15:18 --> Config Class Initialized
INFO - 2022-06-09 03:15:18 --> Loader Class Initialized
INFO - 2022-06-09 03:15:18 --> Helper loaded: url_helper
INFO - 2022-06-09 03:15:18 --> Helper loaded: file_helper
INFO - 2022-06-09 03:15:18 --> Helper loaded: form_helper
INFO - 2022-06-09 03:15:18 --> Helper loaded: my_helper
INFO - 2022-06-09 03:15:18 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:15:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:15:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:15:18 --> Controller Class Initialized
INFO - 2022-06-09 03:15:18 --> Final output sent to browser
DEBUG - 2022-06-09 03:15:18 --> Total execution time: 0.0727
INFO - 2022-06-09 03:15:26 --> Config Class Initialized
INFO - 2022-06-09 03:15:26 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:15:26 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:15:26 --> Utf8 Class Initialized
INFO - 2022-06-09 03:15:26 --> URI Class Initialized
INFO - 2022-06-09 03:15:26 --> Router Class Initialized
INFO - 2022-06-09 03:15:26 --> Output Class Initialized
INFO - 2022-06-09 03:15:26 --> Security Class Initialized
DEBUG - 2022-06-09 03:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:15:26 --> Input Class Initialized
INFO - 2022-06-09 03:15:26 --> Language Class Initialized
INFO - 2022-06-09 03:15:26 --> Language Class Initialized
INFO - 2022-06-09 03:15:26 --> Config Class Initialized
INFO - 2022-06-09 03:15:26 --> Loader Class Initialized
INFO - 2022-06-09 03:15:26 --> Helper loaded: url_helper
INFO - 2022-06-09 03:15:26 --> Helper loaded: file_helper
INFO - 2022-06-09 03:15:26 --> Helper loaded: form_helper
INFO - 2022-06-09 03:15:26 --> Helper loaded: my_helper
INFO - 2022-06-09 03:15:26 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:15:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:15:26 --> Controller Class Initialized
INFO - 2022-06-09 03:15:26 --> Final output sent to browser
DEBUG - 2022-06-09 03:15:26 --> Total execution time: 0.0498
INFO - 2022-06-09 03:15:30 --> Config Class Initialized
INFO - 2022-06-09 03:15:30 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:15:30 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:15:30 --> Utf8 Class Initialized
INFO - 2022-06-09 03:15:30 --> URI Class Initialized
INFO - 2022-06-09 03:15:30 --> Router Class Initialized
INFO - 2022-06-09 03:15:30 --> Output Class Initialized
INFO - 2022-06-09 03:15:30 --> Security Class Initialized
DEBUG - 2022-06-09 03:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:15:30 --> Input Class Initialized
INFO - 2022-06-09 03:15:30 --> Language Class Initialized
INFO - 2022-06-09 03:15:30 --> Language Class Initialized
INFO - 2022-06-09 03:15:30 --> Config Class Initialized
INFO - 2022-06-09 03:15:30 --> Loader Class Initialized
INFO - 2022-06-09 03:15:30 --> Helper loaded: url_helper
INFO - 2022-06-09 03:15:30 --> Helper loaded: file_helper
INFO - 2022-06-09 03:15:30 --> Helper loaded: form_helper
INFO - 2022-06-09 03:15:30 --> Helper loaded: my_helper
INFO - 2022-06-09 03:15:30 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:15:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:15:30 --> Controller Class Initialized
INFO - 2022-06-09 03:15:30 --> Final output sent to browser
DEBUG - 2022-06-09 03:15:30 --> Total execution time: 0.0638
INFO - 2022-06-09 03:15:36 --> Config Class Initialized
INFO - 2022-06-09 03:15:36 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:15:36 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:15:36 --> Utf8 Class Initialized
INFO - 2022-06-09 03:15:36 --> URI Class Initialized
INFO - 2022-06-09 03:15:36 --> Router Class Initialized
INFO - 2022-06-09 03:15:36 --> Output Class Initialized
INFO - 2022-06-09 03:15:36 --> Security Class Initialized
DEBUG - 2022-06-09 03:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:15:36 --> Input Class Initialized
INFO - 2022-06-09 03:15:36 --> Language Class Initialized
INFO - 2022-06-09 03:15:36 --> Language Class Initialized
INFO - 2022-06-09 03:15:36 --> Config Class Initialized
INFO - 2022-06-09 03:15:36 --> Loader Class Initialized
INFO - 2022-06-09 03:15:36 --> Helper loaded: url_helper
INFO - 2022-06-09 03:15:36 --> Helper loaded: file_helper
INFO - 2022-06-09 03:15:36 --> Helper loaded: form_helper
INFO - 2022-06-09 03:15:36 --> Helper loaded: my_helper
INFO - 2022-06-09 03:15:36 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:15:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:15:36 --> Controller Class Initialized
INFO - 2022-06-09 03:15:36 --> Final output sent to browser
DEBUG - 2022-06-09 03:15:36 --> Total execution time: 0.0839
INFO - 2022-06-09 03:15:36 --> Config Class Initialized
INFO - 2022-06-09 03:15:36 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:15:36 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:15:36 --> Utf8 Class Initialized
INFO - 2022-06-09 03:15:36 --> URI Class Initialized
INFO - 2022-06-09 03:15:36 --> Router Class Initialized
INFO - 2022-06-09 03:15:36 --> Output Class Initialized
INFO - 2022-06-09 03:15:36 --> Security Class Initialized
DEBUG - 2022-06-09 03:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:15:36 --> Input Class Initialized
INFO - 2022-06-09 03:15:36 --> Language Class Initialized
INFO - 2022-06-09 03:15:36 --> Language Class Initialized
INFO - 2022-06-09 03:15:36 --> Config Class Initialized
INFO - 2022-06-09 03:15:36 --> Loader Class Initialized
INFO - 2022-06-09 03:15:36 --> Helper loaded: url_helper
INFO - 2022-06-09 03:15:36 --> Helper loaded: file_helper
INFO - 2022-06-09 03:15:36 --> Helper loaded: form_helper
INFO - 2022-06-09 03:15:36 --> Helper loaded: my_helper
INFO - 2022-06-09 03:15:36 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:15:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:15:36 --> Controller Class Initialized
INFO - 2022-06-09 03:15:40 --> Config Class Initialized
INFO - 2022-06-09 03:15:40 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:15:40 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:15:40 --> Utf8 Class Initialized
INFO - 2022-06-09 03:15:40 --> URI Class Initialized
INFO - 2022-06-09 03:15:40 --> Router Class Initialized
INFO - 2022-06-09 03:15:40 --> Output Class Initialized
INFO - 2022-06-09 03:15:40 --> Security Class Initialized
DEBUG - 2022-06-09 03:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:15:40 --> Input Class Initialized
INFO - 2022-06-09 03:15:40 --> Language Class Initialized
INFO - 2022-06-09 03:15:40 --> Language Class Initialized
INFO - 2022-06-09 03:15:40 --> Config Class Initialized
INFO - 2022-06-09 03:15:40 --> Loader Class Initialized
INFO - 2022-06-09 03:15:40 --> Helper loaded: url_helper
INFO - 2022-06-09 03:15:40 --> Helper loaded: file_helper
INFO - 2022-06-09 03:15:40 --> Helper loaded: form_helper
INFO - 2022-06-09 03:15:40 --> Helper loaded: my_helper
INFO - 2022-06-09 03:15:40 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:15:40 --> Controller Class Initialized
INFO - 2022-06-09 03:15:44 --> Config Class Initialized
INFO - 2022-06-09 03:15:44 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:15:44 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:15:44 --> Utf8 Class Initialized
INFO - 2022-06-09 03:15:44 --> URI Class Initialized
INFO - 2022-06-09 03:15:44 --> Router Class Initialized
INFO - 2022-06-09 03:15:44 --> Output Class Initialized
INFO - 2022-06-09 03:15:44 --> Security Class Initialized
DEBUG - 2022-06-09 03:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:15:44 --> Input Class Initialized
INFO - 2022-06-09 03:15:44 --> Language Class Initialized
INFO - 2022-06-09 03:15:44 --> Language Class Initialized
INFO - 2022-06-09 03:15:44 --> Config Class Initialized
INFO - 2022-06-09 03:15:44 --> Loader Class Initialized
INFO - 2022-06-09 03:15:44 --> Helper loaded: url_helper
INFO - 2022-06-09 03:15:44 --> Helper loaded: file_helper
INFO - 2022-06-09 03:15:44 --> Helper loaded: form_helper
INFO - 2022-06-09 03:15:44 --> Helper loaded: my_helper
INFO - 2022-06-09 03:15:44 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:15:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:15:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:15:44 --> Controller Class Initialized
INFO - 2022-06-09 03:15:46 --> Config Class Initialized
INFO - 2022-06-09 03:15:46 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:15:46 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:15:46 --> Utf8 Class Initialized
INFO - 2022-06-09 03:15:46 --> URI Class Initialized
INFO - 2022-06-09 03:15:46 --> Router Class Initialized
INFO - 2022-06-09 03:15:46 --> Output Class Initialized
INFO - 2022-06-09 03:15:46 --> Security Class Initialized
DEBUG - 2022-06-09 03:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:15:46 --> Input Class Initialized
INFO - 2022-06-09 03:15:46 --> Language Class Initialized
INFO - 2022-06-09 03:15:46 --> Language Class Initialized
INFO - 2022-06-09 03:15:46 --> Config Class Initialized
INFO - 2022-06-09 03:15:46 --> Loader Class Initialized
INFO - 2022-06-09 03:15:46 --> Helper loaded: url_helper
INFO - 2022-06-09 03:15:47 --> Helper loaded: file_helper
INFO - 2022-06-09 03:15:47 --> Helper loaded: form_helper
INFO - 2022-06-09 03:15:47 --> Helper loaded: my_helper
INFO - 2022-06-09 03:15:47 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:15:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:15:47 --> Controller Class Initialized
INFO - 2022-06-09 03:15:54 --> Config Class Initialized
INFO - 2022-06-09 03:15:54 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:15:54 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:15:54 --> Utf8 Class Initialized
INFO - 2022-06-09 03:15:54 --> URI Class Initialized
INFO - 2022-06-09 03:15:54 --> Router Class Initialized
INFO - 2022-06-09 03:15:54 --> Output Class Initialized
INFO - 2022-06-09 03:15:54 --> Security Class Initialized
DEBUG - 2022-06-09 03:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:15:54 --> Input Class Initialized
INFO - 2022-06-09 03:15:54 --> Language Class Initialized
INFO - 2022-06-09 03:15:54 --> Language Class Initialized
INFO - 2022-06-09 03:15:54 --> Config Class Initialized
INFO - 2022-06-09 03:15:54 --> Loader Class Initialized
INFO - 2022-06-09 03:15:54 --> Helper loaded: url_helper
INFO - 2022-06-09 03:15:54 --> Helper loaded: file_helper
INFO - 2022-06-09 03:15:54 --> Helper loaded: form_helper
INFO - 2022-06-09 03:15:54 --> Helper loaded: my_helper
INFO - 2022-06-09 03:15:54 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:15:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:15:54 --> Controller Class Initialized
INFO - 2022-06-09 03:16:00 --> Config Class Initialized
INFO - 2022-06-09 03:16:00 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:16:00 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:16:00 --> Utf8 Class Initialized
INFO - 2022-06-09 03:16:00 --> URI Class Initialized
INFO - 2022-06-09 03:16:00 --> Router Class Initialized
INFO - 2022-06-09 03:16:00 --> Output Class Initialized
INFO - 2022-06-09 03:16:00 --> Security Class Initialized
DEBUG - 2022-06-09 03:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:16:00 --> Input Class Initialized
INFO - 2022-06-09 03:16:00 --> Language Class Initialized
INFO - 2022-06-09 03:16:00 --> Language Class Initialized
INFO - 2022-06-09 03:16:00 --> Config Class Initialized
INFO - 2022-06-09 03:16:00 --> Loader Class Initialized
INFO - 2022-06-09 03:16:00 --> Helper loaded: url_helper
INFO - 2022-06-09 03:16:00 --> Helper loaded: file_helper
INFO - 2022-06-09 03:16:00 --> Helper loaded: form_helper
INFO - 2022-06-09 03:16:00 --> Helper loaded: my_helper
INFO - 2022-06-09 03:16:00 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:16:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:16:00 --> Controller Class Initialized
DEBUG - 2022-06-09 03:16:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2022-06-09 03:16:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-09 03:16:00 --> Final output sent to browser
DEBUG - 2022-06-09 03:16:00 --> Total execution time: 0.0534
INFO - 2022-06-09 03:16:01 --> Config Class Initialized
INFO - 2022-06-09 03:16:01 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:16:01 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:16:01 --> Utf8 Class Initialized
INFO - 2022-06-09 03:16:01 --> URI Class Initialized
INFO - 2022-06-09 03:16:01 --> Router Class Initialized
INFO - 2022-06-09 03:16:01 --> Output Class Initialized
INFO - 2022-06-09 03:16:01 --> Security Class Initialized
DEBUG - 2022-06-09 03:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:16:01 --> Input Class Initialized
INFO - 2022-06-09 03:16:01 --> Language Class Initialized
INFO - 2022-06-09 03:16:01 --> Language Class Initialized
INFO - 2022-06-09 03:16:01 --> Config Class Initialized
INFO - 2022-06-09 03:16:01 --> Loader Class Initialized
INFO - 2022-06-09 03:16:01 --> Helper loaded: url_helper
INFO - 2022-06-09 03:16:01 --> Helper loaded: file_helper
INFO - 2022-06-09 03:16:01 --> Helper loaded: form_helper
INFO - 2022-06-09 03:16:01 --> Helper loaded: my_helper
INFO - 2022-06-09 03:16:01 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:16:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:16:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:16:01 --> Controller Class Initialized
INFO - 2022-06-09 03:16:02 --> Config Class Initialized
INFO - 2022-06-09 03:16:02 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:16:02 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:16:02 --> Utf8 Class Initialized
INFO - 2022-06-09 03:16:02 --> URI Class Initialized
INFO - 2022-06-09 03:16:02 --> Router Class Initialized
INFO - 2022-06-09 03:16:02 --> Output Class Initialized
INFO - 2022-06-09 03:16:02 --> Security Class Initialized
DEBUG - 2022-06-09 03:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:16:02 --> Input Class Initialized
INFO - 2022-06-09 03:16:02 --> Language Class Initialized
INFO - 2022-06-09 03:16:02 --> Language Class Initialized
INFO - 2022-06-09 03:16:02 --> Config Class Initialized
INFO - 2022-06-09 03:16:02 --> Loader Class Initialized
INFO - 2022-06-09 03:16:02 --> Helper loaded: url_helper
INFO - 2022-06-09 03:16:02 --> Helper loaded: file_helper
INFO - 2022-06-09 03:16:02 --> Helper loaded: form_helper
INFO - 2022-06-09 03:16:02 --> Helper loaded: my_helper
INFO - 2022-06-09 03:16:02 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:16:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:16:02 --> Controller Class Initialized
DEBUG - 2022-06-09 03:16:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2022-06-09 03:16:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-09 03:16:02 --> Final output sent to browser
DEBUG - 2022-06-09 03:16:02 --> Total execution time: 0.0544
INFO - 2022-06-09 03:16:02 --> Config Class Initialized
INFO - 2022-06-09 03:16:02 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:16:02 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:16:02 --> Utf8 Class Initialized
INFO - 2022-06-09 03:16:02 --> URI Class Initialized
INFO - 2022-06-09 03:16:02 --> Router Class Initialized
INFO - 2022-06-09 03:16:02 --> Output Class Initialized
INFO - 2022-06-09 03:16:02 --> Security Class Initialized
DEBUG - 2022-06-09 03:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:16:02 --> Input Class Initialized
INFO - 2022-06-09 03:16:02 --> Language Class Initialized
INFO - 2022-06-09 03:16:02 --> Language Class Initialized
INFO - 2022-06-09 03:16:02 --> Config Class Initialized
INFO - 2022-06-09 03:16:02 --> Loader Class Initialized
INFO - 2022-06-09 03:16:02 --> Helper loaded: url_helper
INFO - 2022-06-09 03:16:02 --> Helper loaded: file_helper
INFO - 2022-06-09 03:16:02 --> Helper loaded: form_helper
INFO - 2022-06-09 03:16:02 --> Helper loaded: my_helper
INFO - 2022-06-09 03:16:02 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:16:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:16:02 --> Controller Class Initialized
INFO - 2022-06-09 03:16:10 --> Config Class Initialized
INFO - 2022-06-09 03:16:10 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:16:10 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:16:10 --> Utf8 Class Initialized
INFO - 2022-06-09 03:16:10 --> URI Class Initialized
INFO - 2022-06-09 03:16:10 --> Router Class Initialized
INFO - 2022-06-09 03:16:10 --> Output Class Initialized
INFO - 2022-06-09 03:16:10 --> Security Class Initialized
DEBUG - 2022-06-09 03:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:16:10 --> Input Class Initialized
INFO - 2022-06-09 03:16:10 --> Language Class Initialized
INFO - 2022-06-09 03:16:10 --> Language Class Initialized
INFO - 2022-06-09 03:16:10 --> Config Class Initialized
INFO - 2022-06-09 03:16:10 --> Loader Class Initialized
INFO - 2022-06-09 03:16:10 --> Helper loaded: url_helper
INFO - 2022-06-09 03:16:10 --> Helper loaded: file_helper
INFO - 2022-06-09 03:16:10 --> Helper loaded: form_helper
INFO - 2022-06-09 03:16:10 --> Helper loaded: my_helper
INFO - 2022-06-09 03:16:10 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:16:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:16:10 --> Controller Class Initialized
DEBUG - 2022-06-09 03:16:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2022-06-09 03:16:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-09 03:16:10 --> Final output sent to browser
DEBUG - 2022-06-09 03:16:10 --> Total execution time: 0.1075
INFO - 2022-06-09 03:21:37 --> Config Class Initialized
INFO - 2022-06-09 03:21:37 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:21:37 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:21:37 --> Utf8 Class Initialized
INFO - 2022-06-09 03:21:37 --> URI Class Initialized
INFO - 2022-06-09 03:21:37 --> Router Class Initialized
INFO - 2022-06-09 03:21:37 --> Output Class Initialized
INFO - 2022-06-09 03:21:37 --> Security Class Initialized
DEBUG - 2022-06-09 03:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:21:37 --> Input Class Initialized
INFO - 2022-06-09 03:21:37 --> Language Class Initialized
INFO - 2022-06-09 03:21:37 --> Language Class Initialized
INFO - 2022-06-09 03:21:37 --> Config Class Initialized
INFO - 2022-06-09 03:21:37 --> Loader Class Initialized
INFO - 2022-06-09 03:21:37 --> Helper loaded: url_helper
INFO - 2022-06-09 03:21:37 --> Helper loaded: file_helper
INFO - 2022-06-09 03:21:37 --> Helper loaded: form_helper
INFO - 2022-06-09 03:21:37 --> Helper loaded: my_helper
INFO - 2022-06-09 03:21:37 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:21:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:21:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:21:38 --> Controller Class Initialized
INFO - 2022-06-09 03:21:38 --> Config Class Initialized
INFO - 2022-06-09 03:21:38 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:21:38 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:21:38 --> Utf8 Class Initialized
INFO - 2022-06-09 03:21:38 --> URI Class Initialized
INFO - 2022-06-09 03:21:38 --> Router Class Initialized
INFO - 2022-06-09 03:21:38 --> Output Class Initialized
INFO - 2022-06-09 03:21:38 --> Security Class Initialized
DEBUG - 2022-06-09 03:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:21:38 --> Input Class Initialized
INFO - 2022-06-09 03:21:38 --> Language Class Initialized
INFO - 2022-06-09 03:21:38 --> Language Class Initialized
INFO - 2022-06-09 03:21:38 --> Config Class Initialized
INFO - 2022-06-09 03:21:38 --> Loader Class Initialized
INFO - 2022-06-09 03:21:38 --> Helper loaded: url_helper
INFO - 2022-06-09 03:21:38 --> Helper loaded: file_helper
INFO - 2022-06-09 03:21:38 --> Helper loaded: form_helper
INFO - 2022-06-09 03:21:38 --> Helper loaded: my_helper
INFO - 2022-06-09 03:21:38 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:21:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:21:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:21:38 --> Controller Class Initialized
DEBUG - 2022-06-09 03:21:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2022-06-09 03:21:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-09 03:21:38 --> Final output sent to browser
DEBUG - 2022-06-09 03:21:38 --> Total execution time: 0.0678
INFO - 2022-06-09 03:21:38 --> Config Class Initialized
INFO - 2022-06-09 03:21:38 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:21:38 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:21:38 --> Utf8 Class Initialized
INFO - 2022-06-09 03:21:38 --> URI Class Initialized
INFO - 2022-06-09 03:21:38 --> Router Class Initialized
INFO - 2022-06-09 03:21:38 --> Output Class Initialized
INFO - 2022-06-09 03:21:38 --> Security Class Initialized
DEBUG - 2022-06-09 03:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:21:38 --> Input Class Initialized
INFO - 2022-06-09 03:21:38 --> Language Class Initialized
INFO - 2022-06-09 03:21:38 --> Language Class Initialized
INFO - 2022-06-09 03:21:38 --> Config Class Initialized
INFO - 2022-06-09 03:21:38 --> Loader Class Initialized
INFO - 2022-06-09 03:21:38 --> Helper loaded: url_helper
INFO - 2022-06-09 03:21:38 --> Helper loaded: file_helper
INFO - 2022-06-09 03:21:38 --> Helper loaded: form_helper
INFO - 2022-06-09 03:21:38 --> Helper loaded: my_helper
INFO - 2022-06-09 03:21:38 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:21:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:21:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:21:38 --> Controller Class Initialized
INFO - 2022-06-09 03:21:40 --> Config Class Initialized
INFO - 2022-06-09 03:21:40 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:21:40 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:21:40 --> Utf8 Class Initialized
INFO - 2022-06-09 03:21:40 --> URI Class Initialized
INFO - 2022-06-09 03:21:40 --> Router Class Initialized
INFO - 2022-06-09 03:21:40 --> Output Class Initialized
INFO - 2022-06-09 03:21:40 --> Security Class Initialized
DEBUG - 2022-06-09 03:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:21:40 --> Input Class Initialized
INFO - 2022-06-09 03:21:40 --> Language Class Initialized
INFO - 2022-06-09 03:21:40 --> Language Class Initialized
INFO - 2022-06-09 03:21:40 --> Config Class Initialized
INFO - 2022-06-09 03:21:40 --> Loader Class Initialized
INFO - 2022-06-09 03:21:40 --> Helper loaded: url_helper
INFO - 2022-06-09 03:21:40 --> Helper loaded: file_helper
INFO - 2022-06-09 03:21:40 --> Helper loaded: form_helper
INFO - 2022-06-09 03:21:40 --> Helper loaded: my_helper
INFO - 2022-06-09 03:21:40 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:21:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:21:40 --> Controller Class Initialized
DEBUG - 2022-06-09 03:21:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2022-06-09 03:21:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-09 03:21:40 --> Final output sent to browser
DEBUG - 2022-06-09 03:21:40 --> Total execution time: 0.0729
INFO - 2022-06-09 03:27:13 --> Config Class Initialized
INFO - 2022-06-09 03:27:13 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:27:13 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:27:13 --> Utf8 Class Initialized
INFO - 2022-06-09 03:27:13 --> URI Class Initialized
INFO - 2022-06-09 03:27:13 --> Router Class Initialized
INFO - 2022-06-09 03:27:13 --> Output Class Initialized
INFO - 2022-06-09 03:27:13 --> Security Class Initialized
DEBUG - 2022-06-09 03:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:27:13 --> Input Class Initialized
INFO - 2022-06-09 03:27:13 --> Language Class Initialized
INFO - 2022-06-09 03:27:13 --> Language Class Initialized
INFO - 2022-06-09 03:27:13 --> Config Class Initialized
INFO - 2022-06-09 03:27:13 --> Loader Class Initialized
INFO - 2022-06-09 03:27:13 --> Helper loaded: url_helper
INFO - 2022-06-09 03:27:13 --> Helper loaded: file_helper
INFO - 2022-06-09 03:27:13 --> Helper loaded: form_helper
INFO - 2022-06-09 03:27:13 --> Helper loaded: my_helper
INFO - 2022-06-09 03:27:13 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:27:13 --> Controller Class Initialized
DEBUG - 2022-06-09 03:27:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2022-06-09 03:27:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-09 03:27:13 --> Final output sent to browser
DEBUG - 2022-06-09 03:27:13 --> Total execution time: 0.0699
INFO - 2022-06-09 03:27:13 --> Config Class Initialized
INFO - 2022-06-09 03:27:13 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:27:13 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:27:13 --> Utf8 Class Initialized
INFO - 2022-06-09 03:27:13 --> URI Class Initialized
INFO - 2022-06-09 03:27:13 --> Router Class Initialized
INFO - 2022-06-09 03:27:13 --> Output Class Initialized
INFO - 2022-06-09 03:27:13 --> Security Class Initialized
DEBUG - 2022-06-09 03:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:27:13 --> Input Class Initialized
INFO - 2022-06-09 03:27:13 --> Language Class Initialized
INFO - 2022-06-09 03:27:13 --> Language Class Initialized
INFO - 2022-06-09 03:27:13 --> Config Class Initialized
INFO - 2022-06-09 03:27:13 --> Loader Class Initialized
INFO - 2022-06-09 03:27:13 --> Helper loaded: url_helper
INFO - 2022-06-09 03:27:13 --> Helper loaded: file_helper
INFO - 2022-06-09 03:27:13 --> Helper loaded: form_helper
INFO - 2022-06-09 03:27:13 --> Helper loaded: my_helper
INFO - 2022-06-09 03:27:13 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:27:13 --> Controller Class Initialized
INFO - 2022-06-09 03:27:15 --> Config Class Initialized
INFO - 2022-06-09 03:27:15 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:27:15 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:27:15 --> Utf8 Class Initialized
INFO - 2022-06-09 03:27:15 --> URI Class Initialized
INFO - 2022-06-09 03:27:15 --> Router Class Initialized
INFO - 2022-06-09 03:27:15 --> Output Class Initialized
INFO - 2022-06-09 03:27:15 --> Security Class Initialized
DEBUG - 2022-06-09 03:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:27:15 --> Input Class Initialized
INFO - 2022-06-09 03:27:15 --> Language Class Initialized
INFO - 2022-06-09 03:27:15 --> Language Class Initialized
INFO - 2022-06-09 03:27:15 --> Config Class Initialized
INFO - 2022-06-09 03:27:15 --> Loader Class Initialized
INFO - 2022-06-09 03:27:15 --> Helper loaded: url_helper
INFO - 2022-06-09 03:27:15 --> Helper loaded: file_helper
INFO - 2022-06-09 03:27:15 --> Helper loaded: form_helper
INFO - 2022-06-09 03:27:15 --> Helper loaded: my_helper
INFO - 2022-06-09 03:27:15 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:27:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:27:15 --> Controller Class Initialized
INFO - 2022-06-09 03:27:15 --> Final output sent to browser
DEBUG - 2022-06-09 03:27:15 --> Total execution time: 0.0892
INFO - 2022-06-09 03:27:15 --> Config Class Initialized
INFO - 2022-06-09 03:27:15 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:27:15 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:27:15 --> Utf8 Class Initialized
INFO - 2022-06-09 03:27:15 --> URI Class Initialized
INFO - 2022-06-09 03:27:15 --> Router Class Initialized
INFO - 2022-06-09 03:27:15 --> Output Class Initialized
INFO - 2022-06-09 03:27:15 --> Security Class Initialized
DEBUG - 2022-06-09 03:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:27:15 --> Input Class Initialized
INFO - 2022-06-09 03:27:15 --> Language Class Initialized
INFO - 2022-06-09 03:27:15 --> Language Class Initialized
INFO - 2022-06-09 03:27:15 --> Config Class Initialized
INFO - 2022-06-09 03:27:15 --> Loader Class Initialized
INFO - 2022-06-09 03:27:15 --> Helper loaded: url_helper
INFO - 2022-06-09 03:27:15 --> Helper loaded: file_helper
INFO - 2022-06-09 03:27:15 --> Helper loaded: form_helper
INFO - 2022-06-09 03:27:15 --> Helper loaded: my_helper
INFO - 2022-06-09 03:27:15 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:27:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:27:15 --> Controller Class Initialized
INFO - 2022-06-09 03:27:17 --> Config Class Initialized
INFO - 2022-06-09 03:27:17 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:27:17 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:27:17 --> Utf8 Class Initialized
INFO - 2022-06-09 03:27:17 --> URI Class Initialized
INFO - 2022-06-09 03:27:17 --> Router Class Initialized
INFO - 2022-06-09 03:27:17 --> Output Class Initialized
INFO - 2022-06-09 03:27:17 --> Security Class Initialized
DEBUG - 2022-06-09 03:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:27:17 --> Input Class Initialized
INFO - 2022-06-09 03:27:17 --> Language Class Initialized
INFO - 2022-06-09 03:27:17 --> Language Class Initialized
INFO - 2022-06-09 03:27:17 --> Config Class Initialized
INFO - 2022-06-09 03:27:17 --> Loader Class Initialized
INFO - 2022-06-09 03:27:17 --> Helper loaded: url_helper
INFO - 2022-06-09 03:27:17 --> Helper loaded: file_helper
INFO - 2022-06-09 03:27:17 --> Helper loaded: form_helper
INFO - 2022-06-09 03:27:17 --> Helper loaded: my_helper
INFO - 2022-06-09 03:27:17 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:27:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:27:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:27:17 --> Controller Class Initialized
INFO - 2022-06-09 03:27:17 --> Final output sent to browser
DEBUG - 2022-06-09 03:27:17 --> Total execution time: 0.0943
INFO - 2022-06-09 03:27:17 --> Config Class Initialized
INFO - 2022-06-09 03:27:17 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:27:17 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:27:17 --> Utf8 Class Initialized
INFO - 2022-06-09 03:27:17 --> URI Class Initialized
INFO - 2022-06-09 03:27:17 --> Router Class Initialized
INFO - 2022-06-09 03:27:17 --> Output Class Initialized
INFO - 2022-06-09 03:27:17 --> Security Class Initialized
DEBUG - 2022-06-09 03:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:27:17 --> Input Class Initialized
INFO - 2022-06-09 03:27:17 --> Language Class Initialized
INFO - 2022-06-09 03:27:17 --> Language Class Initialized
INFO - 2022-06-09 03:27:17 --> Config Class Initialized
INFO - 2022-06-09 03:27:17 --> Loader Class Initialized
INFO - 2022-06-09 03:27:17 --> Helper loaded: url_helper
INFO - 2022-06-09 03:27:17 --> Helper loaded: file_helper
INFO - 2022-06-09 03:27:17 --> Helper loaded: form_helper
INFO - 2022-06-09 03:27:17 --> Helper loaded: my_helper
INFO - 2022-06-09 03:27:17 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:27:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:27:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:27:17 --> Controller Class Initialized
INFO - 2022-06-09 03:27:18 --> Config Class Initialized
INFO - 2022-06-09 03:27:18 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:27:18 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:27:18 --> Utf8 Class Initialized
INFO - 2022-06-09 03:27:18 --> URI Class Initialized
INFO - 2022-06-09 03:27:18 --> Router Class Initialized
INFO - 2022-06-09 03:27:18 --> Output Class Initialized
INFO - 2022-06-09 03:27:18 --> Security Class Initialized
DEBUG - 2022-06-09 03:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:27:18 --> Input Class Initialized
INFO - 2022-06-09 03:27:18 --> Language Class Initialized
INFO - 2022-06-09 03:27:18 --> Language Class Initialized
INFO - 2022-06-09 03:27:18 --> Config Class Initialized
INFO - 2022-06-09 03:27:18 --> Loader Class Initialized
INFO - 2022-06-09 03:27:18 --> Helper loaded: url_helper
INFO - 2022-06-09 03:27:18 --> Helper loaded: file_helper
INFO - 2022-06-09 03:27:18 --> Helper loaded: form_helper
INFO - 2022-06-09 03:27:18 --> Helper loaded: my_helper
INFO - 2022-06-09 03:27:18 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:27:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:27:18 --> Controller Class Initialized
DEBUG - 2022-06-09 03:27:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2022-06-09 03:27:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-09 03:27:18 --> Final output sent to browser
DEBUG - 2022-06-09 03:27:18 --> Total execution time: 0.0858
INFO - 2022-06-09 03:30:13 --> Config Class Initialized
INFO - 2022-06-09 03:30:13 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:30:13 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:30:13 --> Utf8 Class Initialized
INFO - 2022-06-09 03:30:13 --> URI Class Initialized
INFO - 2022-06-09 03:30:13 --> Router Class Initialized
INFO - 2022-06-09 03:30:13 --> Output Class Initialized
INFO - 2022-06-09 03:30:13 --> Security Class Initialized
DEBUG - 2022-06-09 03:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:30:13 --> Input Class Initialized
INFO - 2022-06-09 03:30:13 --> Language Class Initialized
INFO - 2022-06-09 03:30:13 --> Language Class Initialized
INFO - 2022-06-09 03:30:13 --> Config Class Initialized
INFO - 2022-06-09 03:30:13 --> Loader Class Initialized
INFO - 2022-06-09 03:30:13 --> Helper loaded: url_helper
INFO - 2022-06-09 03:30:13 --> Helper loaded: file_helper
INFO - 2022-06-09 03:30:13 --> Helper loaded: form_helper
INFO - 2022-06-09 03:30:13 --> Helper loaded: my_helper
INFO - 2022-06-09 03:30:13 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:30:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:30:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:30:13 --> Controller Class Initialized
DEBUG - 2022-06-09 03:30:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2022-06-09 03:30:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-09 03:30:13 --> Final output sent to browser
DEBUG - 2022-06-09 03:30:13 --> Total execution time: 0.0772
INFO - 2022-06-09 03:30:13 --> Config Class Initialized
INFO - 2022-06-09 03:30:13 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:30:13 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:30:13 --> Utf8 Class Initialized
INFO - 2022-06-09 03:30:13 --> URI Class Initialized
INFO - 2022-06-09 03:30:13 --> Router Class Initialized
INFO - 2022-06-09 03:30:13 --> Output Class Initialized
INFO - 2022-06-09 03:30:13 --> Security Class Initialized
DEBUG - 2022-06-09 03:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:30:13 --> Input Class Initialized
INFO - 2022-06-09 03:30:13 --> Language Class Initialized
INFO - 2022-06-09 03:30:13 --> Language Class Initialized
INFO - 2022-06-09 03:30:13 --> Config Class Initialized
INFO - 2022-06-09 03:30:13 --> Loader Class Initialized
INFO - 2022-06-09 03:30:13 --> Helper loaded: url_helper
INFO - 2022-06-09 03:30:13 --> Helper loaded: file_helper
INFO - 2022-06-09 03:30:13 --> Helper loaded: form_helper
INFO - 2022-06-09 03:30:13 --> Helper loaded: my_helper
INFO - 2022-06-09 03:30:13 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:30:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:30:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:30:13 --> Controller Class Initialized
INFO - 2022-06-09 03:33:30 --> Config Class Initialized
INFO - 2022-06-09 03:33:30 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:33:30 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:33:30 --> Utf8 Class Initialized
INFO - 2022-06-09 03:33:30 --> URI Class Initialized
INFO - 2022-06-09 03:33:30 --> Router Class Initialized
INFO - 2022-06-09 03:33:30 --> Output Class Initialized
INFO - 2022-06-09 03:33:30 --> Security Class Initialized
DEBUG - 2022-06-09 03:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:33:30 --> Input Class Initialized
INFO - 2022-06-09 03:33:30 --> Language Class Initialized
INFO - 2022-06-09 03:33:30 --> Language Class Initialized
INFO - 2022-06-09 03:33:30 --> Config Class Initialized
INFO - 2022-06-09 03:33:30 --> Loader Class Initialized
INFO - 2022-06-09 03:33:30 --> Helper loaded: url_helper
INFO - 2022-06-09 03:33:30 --> Helper loaded: file_helper
INFO - 2022-06-09 03:33:30 --> Helper loaded: form_helper
INFO - 2022-06-09 03:33:30 --> Helper loaded: my_helper
INFO - 2022-06-09 03:33:30 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:33:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:33:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:33:30 --> Controller Class Initialized
DEBUG - 2022-06-09 03:33:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2022-06-09 03:33:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-09 03:33:30 --> Final output sent to browser
DEBUG - 2022-06-09 03:33:30 --> Total execution time: 0.0823
INFO - 2022-06-09 03:33:36 --> Config Class Initialized
INFO - 2022-06-09 03:33:36 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:33:36 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:33:36 --> Utf8 Class Initialized
INFO - 2022-06-09 03:33:36 --> URI Class Initialized
INFO - 2022-06-09 03:33:36 --> Router Class Initialized
INFO - 2022-06-09 03:33:36 --> Output Class Initialized
INFO - 2022-06-09 03:33:36 --> Security Class Initialized
DEBUG - 2022-06-09 03:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:33:36 --> Input Class Initialized
INFO - 2022-06-09 03:33:36 --> Language Class Initialized
INFO - 2022-06-09 03:33:36 --> Language Class Initialized
INFO - 2022-06-09 03:33:36 --> Config Class Initialized
INFO - 2022-06-09 03:33:36 --> Loader Class Initialized
INFO - 2022-06-09 03:33:36 --> Helper loaded: url_helper
INFO - 2022-06-09 03:33:36 --> Helper loaded: file_helper
INFO - 2022-06-09 03:33:36 --> Helper loaded: form_helper
INFO - 2022-06-09 03:33:36 --> Helper loaded: my_helper
INFO - 2022-06-09 03:33:36 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:33:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:33:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:33:36 --> Controller Class Initialized
DEBUG - 2022-06-09 03:33:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2022-06-09 03:33:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-09 03:33:36 --> Final output sent to browser
DEBUG - 2022-06-09 03:33:36 --> Total execution time: 0.0788
INFO - 2022-06-09 03:33:37 --> Config Class Initialized
INFO - 2022-06-09 03:33:37 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:33:37 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:33:37 --> Utf8 Class Initialized
INFO - 2022-06-09 03:33:37 --> URI Class Initialized
INFO - 2022-06-09 03:33:37 --> Router Class Initialized
INFO - 2022-06-09 03:33:37 --> Output Class Initialized
INFO - 2022-06-09 03:33:37 --> Security Class Initialized
DEBUG - 2022-06-09 03:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:33:37 --> Input Class Initialized
INFO - 2022-06-09 03:33:37 --> Language Class Initialized
INFO - 2022-06-09 03:33:37 --> Language Class Initialized
INFO - 2022-06-09 03:33:37 --> Config Class Initialized
INFO - 2022-06-09 03:33:37 --> Loader Class Initialized
INFO - 2022-06-09 03:33:37 --> Helper loaded: url_helper
INFO - 2022-06-09 03:33:37 --> Helper loaded: file_helper
INFO - 2022-06-09 03:33:37 --> Helper loaded: form_helper
INFO - 2022-06-09 03:33:37 --> Helper loaded: my_helper
INFO - 2022-06-09 03:33:37 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:33:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:33:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:33:37 --> Controller Class Initialized
DEBUG - 2022-06-09 03:33:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2022-06-09 03:33:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-09 03:33:37 --> Final output sent to browser
DEBUG - 2022-06-09 03:33:37 --> Total execution time: 0.1065
INFO - 2022-06-09 03:41:30 --> Config Class Initialized
INFO - 2022-06-09 03:41:30 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:41:30 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:41:30 --> Utf8 Class Initialized
INFO - 2022-06-09 03:41:30 --> URI Class Initialized
INFO - 2022-06-09 03:41:30 --> Router Class Initialized
INFO - 2022-06-09 03:41:30 --> Output Class Initialized
INFO - 2022-06-09 03:41:30 --> Security Class Initialized
DEBUG - 2022-06-09 03:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:41:30 --> Input Class Initialized
INFO - 2022-06-09 03:41:30 --> Language Class Initialized
INFO - 2022-06-09 03:41:30 --> Language Class Initialized
INFO - 2022-06-09 03:41:30 --> Config Class Initialized
INFO - 2022-06-09 03:41:30 --> Loader Class Initialized
INFO - 2022-06-09 03:41:30 --> Helper loaded: url_helper
INFO - 2022-06-09 03:41:30 --> Helper loaded: file_helper
INFO - 2022-06-09 03:41:30 --> Helper loaded: form_helper
INFO - 2022-06-09 03:41:30 --> Helper loaded: my_helper
INFO - 2022-06-09 03:41:30 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:41:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:41:30 --> Controller Class Initialized
INFO - 2022-06-09 03:41:30 --> Config Class Initialized
INFO - 2022-06-09 03:41:30 --> Hooks Class Initialized
DEBUG - 2022-06-09 03:41:30 --> UTF-8 Support Enabled
INFO - 2022-06-09 03:41:30 --> Utf8 Class Initialized
INFO - 2022-06-09 03:41:30 --> URI Class Initialized
INFO - 2022-06-09 03:41:30 --> Router Class Initialized
INFO - 2022-06-09 03:41:30 --> Output Class Initialized
INFO - 2022-06-09 03:41:30 --> Security Class Initialized
DEBUG - 2022-06-09 03:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-09 03:41:30 --> Input Class Initialized
INFO - 2022-06-09 03:41:30 --> Language Class Initialized
INFO - 2022-06-09 03:41:30 --> Language Class Initialized
INFO - 2022-06-09 03:41:30 --> Config Class Initialized
INFO - 2022-06-09 03:41:30 --> Loader Class Initialized
INFO - 2022-06-09 03:41:30 --> Helper loaded: url_helper
INFO - 2022-06-09 03:41:30 --> Helper loaded: file_helper
INFO - 2022-06-09 03:41:30 --> Helper loaded: form_helper
INFO - 2022-06-09 03:41:30 --> Helper loaded: my_helper
INFO - 2022-06-09 03:41:30 --> Database Driver Class Initialized
DEBUG - 2022-06-09 03:41:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-09 03:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-09 03:41:30 --> Controller Class Initialized
DEBUG - 2022-06-09 03:41:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2022-06-09 03:41:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-09 03:41:30 --> Final output sent to browser
DEBUG - 2022-06-09 03:41:30 --> Total execution time: 0.0660
