<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-09-27 02:44:54 --> Config Class Initialized
INFO - 2022-09-27 02:44:54 --> Hooks Class Initialized
DEBUG - 2022-09-27 02:44:54 --> UTF-8 Support Enabled
INFO - 2022-09-27 02:44:54 --> Utf8 Class Initialized
INFO - 2022-09-27 02:44:54 --> URI Class Initialized
DEBUG - 2022-09-27 02:44:54 --> No URI present. Default controller set.
INFO - 2022-09-27 02:44:54 --> Router Class Initialized
INFO - 2022-09-27 02:44:54 --> Output Class Initialized
INFO - 2022-09-27 02:44:54 --> Security Class Initialized
DEBUG - 2022-09-27 02:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-27 02:44:54 --> Input Class Initialized
INFO - 2022-09-27 02:44:54 --> Language Class Initialized
INFO - 2022-09-27 02:44:55 --> Language Class Initialized
INFO - 2022-09-27 02:44:55 --> Config Class Initialized
INFO - 2022-09-27 02:44:55 --> Loader Class Initialized
INFO - 2022-09-27 02:44:55 --> Helper loaded: url_helper
INFO - 2022-09-27 02:44:55 --> Helper loaded: file_helper
INFO - 2022-09-27 02:44:55 --> Helper loaded: form_helper
INFO - 2022-09-27 02:44:55 --> Helper loaded: my_helper
INFO - 2022-09-27 02:44:55 --> Database Driver Class Initialized
DEBUG - 2022-09-27 02:44:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-27 02:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-27 02:44:55 --> Controller Class Initialized
INFO - 2022-09-27 02:44:55 --> Config Class Initialized
INFO - 2022-09-27 02:44:55 --> Hooks Class Initialized
DEBUG - 2022-09-27 02:44:55 --> UTF-8 Support Enabled
INFO - 2022-09-27 02:44:55 --> Utf8 Class Initialized
INFO - 2022-09-27 02:44:55 --> URI Class Initialized
INFO - 2022-09-27 02:44:55 --> Router Class Initialized
INFO - 2022-09-27 02:44:55 --> Output Class Initialized
INFO - 2022-09-27 02:44:55 --> Security Class Initialized
DEBUG - 2022-09-27 02:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-27 02:44:55 --> Input Class Initialized
INFO - 2022-09-27 02:44:55 --> Language Class Initialized
INFO - 2022-09-27 02:44:55 --> Language Class Initialized
INFO - 2022-09-27 02:44:55 --> Config Class Initialized
INFO - 2022-09-27 02:44:55 --> Loader Class Initialized
INFO - 2022-09-27 02:44:55 --> Helper loaded: url_helper
INFO - 2022-09-27 02:44:55 --> Helper loaded: file_helper
INFO - 2022-09-27 02:44:55 --> Helper loaded: form_helper
INFO - 2022-09-27 02:44:55 --> Helper loaded: my_helper
INFO - 2022-09-27 02:44:55 --> Database Driver Class Initialized
DEBUG - 2022-09-27 02:44:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-27 02:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-27 02:44:55 --> Controller Class Initialized
DEBUG - 2022-09-27 02:44:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-09-27 02:44:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-09-27 02:44:55 --> Final output sent to browser
DEBUG - 2022-09-27 02:44:55 --> Total execution time: 0.0850
