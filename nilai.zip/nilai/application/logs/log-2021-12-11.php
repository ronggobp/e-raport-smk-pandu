<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-12-11 03:27:33 --> Config Class Initialized
INFO - 2021-12-11 03:27:33 --> Hooks Class Initialized
DEBUG - 2021-12-11 03:27:33 --> UTF-8 Support Enabled
INFO - 2021-12-11 03:27:33 --> Utf8 Class Initialized
INFO - 2021-12-11 03:27:33 --> URI Class Initialized
DEBUG - 2021-12-11 03:27:33 --> No URI present. Default controller set.
INFO - 2021-12-11 03:27:33 --> Router Class Initialized
INFO - 2021-12-11 03:27:33 --> Output Class Initialized
INFO - 2021-12-11 03:27:33 --> Security Class Initialized
DEBUG - 2021-12-11 03:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 03:27:33 --> Input Class Initialized
INFO - 2021-12-11 03:27:33 --> Language Class Initialized
INFO - 2021-12-11 03:27:33 --> Language Class Initialized
INFO - 2021-12-11 03:27:33 --> Config Class Initialized
INFO - 2021-12-11 03:27:33 --> Loader Class Initialized
INFO - 2021-12-11 03:27:33 --> Helper loaded: url_helper
INFO - 2021-12-11 03:27:33 --> Helper loaded: file_helper
INFO - 2021-12-11 03:27:33 --> Helper loaded: form_helper
INFO - 2021-12-11 03:27:33 --> Helper loaded: my_helper
INFO - 2021-12-11 03:27:33 --> Database Driver Class Initialized
DEBUG - 2021-12-11 03:27:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 03:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 03:27:33 --> Controller Class Initialized
INFO - 2021-12-11 03:27:33 --> Config Class Initialized
INFO - 2021-12-11 03:27:33 --> Hooks Class Initialized
DEBUG - 2021-12-11 03:27:33 --> UTF-8 Support Enabled
INFO - 2021-12-11 03:27:33 --> Utf8 Class Initialized
INFO - 2021-12-11 03:27:33 --> URI Class Initialized
INFO - 2021-12-11 03:27:33 --> Router Class Initialized
INFO - 2021-12-11 03:27:33 --> Output Class Initialized
INFO - 2021-12-11 03:27:33 --> Security Class Initialized
DEBUG - 2021-12-11 03:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 03:27:33 --> Input Class Initialized
INFO - 2021-12-11 03:27:33 --> Language Class Initialized
INFO - 2021-12-11 03:27:33 --> Language Class Initialized
INFO - 2021-12-11 03:27:33 --> Config Class Initialized
INFO - 2021-12-11 03:27:33 --> Loader Class Initialized
INFO - 2021-12-11 03:27:33 --> Helper loaded: url_helper
INFO - 2021-12-11 03:27:33 --> Helper loaded: file_helper
INFO - 2021-12-11 03:27:33 --> Helper loaded: form_helper
INFO - 2021-12-11 03:27:33 --> Helper loaded: my_helper
INFO - 2021-12-11 03:27:33 --> Database Driver Class Initialized
DEBUG - 2021-12-11 03:27:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 03:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 03:27:33 --> Controller Class Initialized
DEBUG - 2021-12-11 03:27:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-11 03:27:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-11 03:27:33 --> Final output sent to browser
DEBUG - 2021-12-11 03:27:33 --> Total execution time: 0.0380
INFO - 2021-12-11 03:27:41 --> Config Class Initialized
INFO - 2021-12-11 03:27:41 --> Hooks Class Initialized
DEBUG - 2021-12-11 03:27:41 --> UTF-8 Support Enabled
INFO - 2021-12-11 03:27:41 --> Utf8 Class Initialized
INFO - 2021-12-11 03:27:41 --> URI Class Initialized
INFO - 2021-12-11 03:27:41 --> Router Class Initialized
INFO - 2021-12-11 03:27:41 --> Output Class Initialized
INFO - 2021-12-11 03:27:41 --> Security Class Initialized
DEBUG - 2021-12-11 03:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 03:27:41 --> Input Class Initialized
INFO - 2021-12-11 03:27:41 --> Language Class Initialized
INFO - 2021-12-11 03:27:41 --> Language Class Initialized
INFO - 2021-12-11 03:27:41 --> Config Class Initialized
INFO - 2021-12-11 03:27:41 --> Loader Class Initialized
INFO - 2021-12-11 03:27:41 --> Helper loaded: url_helper
INFO - 2021-12-11 03:27:41 --> Helper loaded: file_helper
INFO - 2021-12-11 03:27:41 --> Helper loaded: form_helper
INFO - 2021-12-11 03:27:41 --> Helper loaded: my_helper
INFO - 2021-12-11 03:27:41 --> Database Driver Class Initialized
DEBUG - 2021-12-11 03:27:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 03:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 03:27:41 --> Controller Class Initialized
INFO - 2021-12-11 03:27:41 --> Final output sent to browser
DEBUG - 2021-12-11 03:27:41 --> Total execution time: 0.0470
INFO - 2021-12-11 03:27:47 --> Config Class Initialized
INFO - 2021-12-11 03:27:47 --> Hooks Class Initialized
DEBUG - 2021-12-11 03:27:47 --> UTF-8 Support Enabled
INFO - 2021-12-11 03:27:47 --> Utf8 Class Initialized
INFO - 2021-12-11 03:27:47 --> URI Class Initialized
INFO - 2021-12-11 03:27:47 --> Router Class Initialized
INFO - 2021-12-11 03:27:47 --> Output Class Initialized
INFO - 2021-12-11 03:27:47 --> Security Class Initialized
DEBUG - 2021-12-11 03:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 03:27:47 --> Input Class Initialized
INFO - 2021-12-11 03:27:47 --> Language Class Initialized
INFO - 2021-12-11 03:27:47 --> Language Class Initialized
INFO - 2021-12-11 03:27:47 --> Config Class Initialized
INFO - 2021-12-11 03:27:47 --> Loader Class Initialized
INFO - 2021-12-11 03:27:47 --> Helper loaded: url_helper
INFO - 2021-12-11 03:27:47 --> Helper loaded: file_helper
INFO - 2021-12-11 03:27:47 --> Helper loaded: form_helper
INFO - 2021-12-11 03:27:47 --> Helper loaded: my_helper
INFO - 2021-12-11 03:27:47 --> Database Driver Class Initialized
DEBUG - 2021-12-11 03:27:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 03:27:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 03:27:47 --> Controller Class Initialized
INFO - 2021-12-11 03:27:47 --> Helper loaded: cookie_helper
INFO - 2021-12-11 03:27:47 --> Final output sent to browser
DEBUG - 2021-12-11 03:27:47 --> Total execution time: 0.0550
INFO - 2021-12-11 03:27:48 --> Config Class Initialized
INFO - 2021-12-11 03:27:48 --> Hooks Class Initialized
DEBUG - 2021-12-11 03:27:48 --> UTF-8 Support Enabled
INFO - 2021-12-11 03:27:48 --> Utf8 Class Initialized
INFO - 2021-12-11 03:27:48 --> URI Class Initialized
INFO - 2021-12-11 03:27:48 --> Router Class Initialized
INFO - 2021-12-11 03:27:48 --> Output Class Initialized
INFO - 2021-12-11 03:27:48 --> Security Class Initialized
DEBUG - 2021-12-11 03:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 03:27:48 --> Input Class Initialized
INFO - 2021-12-11 03:27:48 --> Language Class Initialized
INFO - 2021-12-11 03:27:48 --> Language Class Initialized
INFO - 2021-12-11 03:27:48 --> Config Class Initialized
INFO - 2021-12-11 03:27:48 --> Loader Class Initialized
INFO - 2021-12-11 03:27:48 --> Helper loaded: url_helper
INFO - 2021-12-11 03:27:48 --> Helper loaded: file_helper
INFO - 2021-12-11 03:27:48 --> Helper loaded: form_helper
INFO - 2021-12-11 03:27:48 --> Helper loaded: my_helper
INFO - 2021-12-11 03:27:48 --> Database Driver Class Initialized
DEBUG - 2021-12-11 03:27:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 03:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 03:27:48 --> Controller Class Initialized
DEBUG - 2021-12-11 03:27:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-11 03:27:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-11 03:27:48 --> Final output sent to browser
DEBUG - 2021-12-11 03:27:48 --> Total execution time: 0.2560
INFO - 2021-12-11 03:27:50 --> Config Class Initialized
INFO - 2021-12-11 03:27:50 --> Hooks Class Initialized
DEBUG - 2021-12-11 03:27:50 --> UTF-8 Support Enabled
INFO - 2021-12-11 03:27:50 --> Utf8 Class Initialized
INFO - 2021-12-11 03:27:50 --> URI Class Initialized
INFO - 2021-12-11 03:27:50 --> Router Class Initialized
INFO - 2021-12-11 03:27:50 --> Output Class Initialized
INFO - 2021-12-11 03:27:50 --> Security Class Initialized
DEBUG - 2021-12-11 03:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 03:27:50 --> Input Class Initialized
INFO - 2021-12-11 03:27:50 --> Language Class Initialized
INFO - 2021-12-11 03:27:50 --> Language Class Initialized
INFO - 2021-12-11 03:27:50 --> Config Class Initialized
INFO - 2021-12-11 03:27:50 --> Loader Class Initialized
INFO - 2021-12-11 03:27:50 --> Helper loaded: url_helper
INFO - 2021-12-11 03:27:50 --> Helper loaded: file_helper
INFO - 2021-12-11 03:27:50 --> Helper loaded: form_helper
INFO - 2021-12-11 03:27:50 --> Helper loaded: my_helper
INFO - 2021-12-11 03:27:50 --> Database Driver Class Initialized
DEBUG - 2021-12-11 03:27:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 03:27:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 03:27:50 --> Controller Class Initialized
DEBUG - 2021-12-11 03:27:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-12-11 03:27:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-11 03:27:50 --> Final output sent to browser
DEBUG - 2021-12-11 03:27:50 --> Total execution time: 0.0580
INFO - 2021-12-11 03:27:50 --> Config Class Initialized
INFO - 2021-12-11 03:27:50 --> Hooks Class Initialized
DEBUG - 2021-12-11 03:27:50 --> UTF-8 Support Enabled
INFO - 2021-12-11 03:27:50 --> Utf8 Class Initialized
INFO - 2021-12-11 03:27:50 --> URI Class Initialized
INFO - 2021-12-11 03:27:50 --> Router Class Initialized
INFO - 2021-12-11 03:27:50 --> Output Class Initialized
INFO - 2021-12-11 03:27:50 --> Security Class Initialized
DEBUG - 2021-12-11 03:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 03:27:50 --> Input Class Initialized
INFO - 2021-12-11 03:27:50 --> Language Class Initialized
INFO - 2021-12-11 03:27:50 --> Language Class Initialized
INFO - 2021-12-11 03:27:50 --> Config Class Initialized
INFO - 2021-12-11 03:27:50 --> Loader Class Initialized
INFO - 2021-12-11 03:27:50 --> Helper loaded: url_helper
INFO - 2021-12-11 03:27:50 --> Helper loaded: file_helper
INFO - 2021-12-11 03:27:50 --> Helper loaded: form_helper
INFO - 2021-12-11 03:27:50 --> Helper loaded: my_helper
INFO - 2021-12-11 03:27:50 --> Database Driver Class Initialized
DEBUG - 2021-12-11 03:27:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 03:27:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 03:27:50 --> Controller Class Initialized
INFO - 2021-12-11 03:27:52 --> Config Class Initialized
INFO - 2021-12-11 03:27:52 --> Hooks Class Initialized
DEBUG - 2021-12-11 03:27:52 --> UTF-8 Support Enabled
INFO - 2021-12-11 03:27:52 --> Utf8 Class Initialized
INFO - 2021-12-11 03:27:52 --> URI Class Initialized
INFO - 2021-12-11 03:27:52 --> Router Class Initialized
INFO - 2021-12-11 03:27:52 --> Output Class Initialized
INFO - 2021-12-11 03:27:52 --> Security Class Initialized
DEBUG - 2021-12-11 03:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 03:27:52 --> Input Class Initialized
INFO - 2021-12-11 03:27:52 --> Language Class Initialized
INFO - 2021-12-11 03:27:52 --> Language Class Initialized
INFO - 2021-12-11 03:27:52 --> Config Class Initialized
INFO - 2021-12-11 03:27:52 --> Loader Class Initialized
INFO - 2021-12-11 03:27:52 --> Helper loaded: url_helper
INFO - 2021-12-11 03:27:52 --> Helper loaded: file_helper
INFO - 2021-12-11 03:27:52 --> Helper loaded: form_helper
INFO - 2021-12-11 03:27:52 --> Helper loaded: my_helper
INFO - 2021-12-11 03:27:52 --> Database Driver Class Initialized
DEBUG - 2021-12-11 03:27:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 03:27:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 03:27:52 --> Controller Class Initialized
INFO - 2021-12-11 03:27:52 --> Final output sent to browser
DEBUG - 2021-12-11 03:27:52 --> Total execution time: 0.0630
INFO - 2021-12-11 03:27:52 --> Config Class Initialized
INFO - 2021-12-11 03:27:52 --> Hooks Class Initialized
DEBUG - 2021-12-11 03:27:52 --> UTF-8 Support Enabled
INFO - 2021-12-11 03:27:52 --> Utf8 Class Initialized
INFO - 2021-12-11 03:27:52 --> URI Class Initialized
INFO - 2021-12-11 03:27:52 --> Router Class Initialized
INFO - 2021-12-11 03:27:52 --> Output Class Initialized
INFO - 2021-12-11 03:27:52 --> Security Class Initialized
DEBUG - 2021-12-11 03:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 03:27:52 --> Input Class Initialized
INFO - 2021-12-11 03:27:52 --> Language Class Initialized
INFO - 2021-12-11 03:27:52 --> Language Class Initialized
INFO - 2021-12-11 03:27:52 --> Config Class Initialized
INFO - 2021-12-11 03:27:52 --> Loader Class Initialized
INFO - 2021-12-11 03:27:52 --> Helper loaded: url_helper
INFO - 2021-12-11 03:27:52 --> Helper loaded: file_helper
INFO - 2021-12-11 03:27:52 --> Helper loaded: form_helper
INFO - 2021-12-11 03:27:52 --> Helper loaded: my_helper
INFO - 2021-12-11 03:27:52 --> Database Driver Class Initialized
DEBUG - 2021-12-11 03:27:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 03:27:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 03:27:52 --> Controller Class Initialized
INFO - 2021-12-11 03:28:21 --> Config Class Initialized
INFO - 2021-12-11 03:28:21 --> Hooks Class Initialized
DEBUG - 2021-12-11 03:28:21 --> UTF-8 Support Enabled
INFO - 2021-12-11 03:28:21 --> Utf8 Class Initialized
INFO - 2021-12-11 03:28:21 --> URI Class Initialized
INFO - 2021-12-11 03:28:21 --> Router Class Initialized
INFO - 2021-12-11 03:28:21 --> Output Class Initialized
INFO - 2021-12-11 03:28:21 --> Security Class Initialized
DEBUG - 2021-12-11 03:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 03:28:21 --> Input Class Initialized
INFO - 2021-12-11 03:28:21 --> Language Class Initialized
INFO - 2021-12-11 03:28:21 --> Language Class Initialized
INFO - 2021-12-11 03:28:21 --> Config Class Initialized
INFO - 2021-12-11 03:28:21 --> Loader Class Initialized
INFO - 2021-12-11 03:28:21 --> Helper loaded: url_helper
INFO - 2021-12-11 03:28:21 --> Helper loaded: file_helper
INFO - 2021-12-11 03:28:21 --> Helper loaded: form_helper
INFO - 2021-12-11 03:28:21 --> Helper loaded: my_helper
INFO - 2021-12-11 03:28:21 --> Database Driver Class Initialized
DEBUG - 2021-12-11 03:28:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 03:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 03:28:21 --> Controller Class Initialized
INFO - 2021-12-11 03:28:21 --> Helper loaded: cookie_helper
INFO - 2021-12-11 03:28:21 --> Config Class Initialized
INFO - 2021-12-11 03:28:21 --> Hooks Class Initialized
DEBUG - 2021-12-11 03:28:21 --> UTF-8 Support Enabled
INFO - 2021-12-11 03:28:21 --> Utf8 Class Initialized
INFO - 2021-12-11 03:28:21 --> URI Class Initialized
INFO - 2021-12-11 03:28:21 --> Router Class Initialized
INFO - 2021-12-11 03:28:21 --> Output Class Initialized
INFO - 2021-12-11 03:28:21 --> Security Class Initialized
DEBUG - 2021-12-11 03:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 03:28:21 --> Input Class Initialized
INFO - 2021-12-11 03:28:21 --> Language Class Initialized
INFO - 2021-12-11 03:28:21 --> Language Class Initialized
INFO - 2021-12-11 03:28:21 --> Config Class Initialized
INFO - 2021-12-11 03:28:21 --> Loader Class Initialized
INFO - 2021-12-11 03:28:21 --> Helper loaded: url_helper
INFO - 2021-12-11 03:28:21 --> Helper loaded: file_helper
INFO - 2021-12-11 03:28:21 --> Helper loaded: form_helper
INFO - 2021-12-11 03:28:21 --> Helper loaded: my_helper
INFO - 2021-12-11 03:28:21 --> Database Driver Class Initialized
DEBUG - 2021-12-11 03:28:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 03:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 03:28:21 --> Controller Class Initialized
DEBUG - 2021-12-11 03:28:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-11 03:28:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-11 03:28:21 --> Final output sent to browser
DEBUG - 2021-12-11 03:28:21 --> Total execution time: 0.0420
INFO - 2021-12-11 03:28:32 --> Config Class Initialized
INFO - 2021-12-11 03:28:32 --> Hooks Class Initialized
DEBUG - 2021-12-11 03:28:32 --> UTF-8 Support Enabled
INFO - 2021-12-11 03:28:32 --> Utf8 Class Initialized
INFO - 2021-12-11 03:28:32 --> URI Class Initialized
INFO - 2021-12-11 03:28:32 --> Router Class Initialized
INFO - 2021-12-11 03:28:32 --> Output Class Initialized
INFO - 2021-12-11 03:28:32 --> Security Class Initialized
DEBUG - 2021-12-11 03:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 03:28:32 --> Input Class Initialized
INFO - 2021-12-11 03:28:32 --> Language Class Initialized
INFO - 2021-12-11 03:28:32 --> Language Class Initialized
INFO - 2021-12-11 03:28:32 --> Config Class Initialized
INFO - 2021-12-11 03:28:32 --> Loader Class Initialized
INFO - 2021-12-11 03:28:32 --> Helper loaded: url_helper
INFO - 2021-12-11 03:28:32 --> Helper loaded: file_helper
INFO - 2021-12-11 03:28:32 --> Helper loaded: form_helper
INFO - 2021-12-11 03:28:32 --> Helper loaded: my_helper
INFO - 2021-12-11 03:28:32 --> Database Driver Class Initialized
DEBUG - 2021-12-11 03:28:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 03:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 03:28:32 --> Controller Class Initialized
INFO - 2021-12-11 03:28:32 --> Helper loaded: cookie_helper
INFO - 2021-12-11 03:28:32 --> Final output sent to browser
DEBUG - 2021-12-11 03:28:32 --> Total execution time: 0.0540
INFO - 2021-12-11 03:28:32 --> Config Class Initialized
INFO - 2021-12-11 03:28:32 --> Hooks Class Initialized
DEBUG - 2021-12-11 03:28:32 --> UTF-8 Support Enabled
INFO - 2021-12-11 03:28:32 --> Utf8 Class Initialized
INFO - 2021-12-11 03:28:32 --> URI Class Initialized
INFO - 2021-12-11 03:28:32 --> Router Class Initialized
INFO - 2021-12-11 03:28:32 --> Output Class Initialized
INFO - 2021-12-11 03:28:32 --> Security Class Initialized
DEBUG - 2021-12-11 03:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 03:28:32 --> Input Class Initialized
INFO - 2021-12-11 03:28:32 --> Language Class Initialized
INFO - 2021-12-11 03:28:32 --> Language Class Initialized
INFO - 2021-12-11 03:28:32 --> Config Class Initialized
INFO - 2021-12-11 03:28:32 --> Loader Class Initialized
INFO - 2021-12-11 03:28:32 --> Helper loaded: url_helper
INFO - 2021-12-11 03:28:32 --> Helper loaded: file_helper
INFO - 2021-12-11 03:28:32 --> Helper loaded: form_helper
INFO - 2021-12-11 03:28:32 --> Helper loaded: my_helper
INFO - 2021-12-11 03:28:32 --> Database Driver Class Initialized
DEBUG - 2021-12-11 03:28:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 03:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 03:28:32 --> Controller Class Initialized
DEBUG - 2021-12-11 03:28:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-11 03:28:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-11 03:28:32 --> Final output sent to browser
DEBUG - 2021-12-11 03:28:32 --> Total execution time: 0.1570
INFO - 2021-12-11 05:15:18 --> Config Class Initialized
INFO - 2021-12-11 05:15:18 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:15:18 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:15:18 --> Utf8 Class Initialized
INFO - 2021-12-11 05:15:18 --> URI Class Initialized
INFO - 2021-12-11 05:15:18 --> Router Class Initialized
INFO - 2021-12-11 05:15:18 --> Output Class Initialized
INFO - 2021-12-11 05:15:18 --> Security Class Initialized
DEBUG - 2021-12-11 05:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:15:18 --> Input Class Initialized
INFO - 2021-12-11 05:15:18 --> Language Class Initialized
INFO - 2021-12-11 05:15:18 --> Language Class Initialized
INFO - 2021-12-11 05:15:18 --> Config Class Initialized
INFO - 2021-12-11 05:15:18 --> Loader Class Initialized
INFO - 2021-12-11 05:15:18 --> Helper loaded: url_helper
INFO - 2021-12-11 05:15:18 --> Helper loaded: file_helper
INFO - 2021-12-11 05:15:18 --> Helper loaded: form_helper
INFO - 2021-12-11 05:15:18 --> Helper loaded: my_helper
INFO - 2021-12-11 05:15:18 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:15:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:15:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:15:18 --> Controller Class Initialized
DEBUG - 2021-12-11 05:15:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-11 05:15:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-11 05:15:18 --> Final output sent to browser
DEBUG - 2021-12-11 05:15:18 --> Total execution time: 0.0670
INFO - 2021-12-11 05:16:23 --> Config Class Initialized
INFO - 2021-12-11 05:16:23 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:16:23 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:16:23 --> Utf8 Class Initialized
INFO - 2021-12-11 05:16:23 --> URI Class Initialized
INFO - 2021-12-11 05:16:23 --> Router Class Initialized
INFO - 2021-12-11 05:16:23 --> Output Class Initialized
INFO - 2021-12-11 05:16:23 --> Security Class Initialized
DEBUG - 2021-12-11 05:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:16:23 --> Input Class Initialized
INFO - 2021-12-11 05:16:23 --> Language Class Initialized
INFO - 2021-12-11 05:16:23 --> Language Class Initialized
INFO - 2021-12-11 05:16:23 --> Config Class Initialized
INFO - 2021-12-11 05:16:23 --> Loader Class Initialized
INFO - 2021-12-11 05:16:23 --> Helper loaded: url_helper
INFO - 2021-12-11 05:16:23 --> Helper loaded: file_helper
INFO - 2021-12-11 05:16:23 --> Helper loaded: form_helper
INFO - 2021-12-11 05:16:23 --> Helper loaded: my_helper
INFO - 2021-12-11 05:16:23 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:16:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:16:23 --> Controller Class Initialized
DEBUG - 2021-12-11 05:16:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:16:23 --> Final output sent to browser
DEBUG - 2021-12-11 05:16:23 --> Total execution time: 0.1210
INFO - 2021-12-11 05:16:38 --> Config Class Initialized
INFO - 2021-12-11 05:16:38 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:16:38 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:16:38 --> Utf8 Class Initialized
INFO - 2021-12-11 05:16:38 --> URI Class Initialized
INFO - 2021-12-11 05:16:38 --> Router Class Initialized
INFO - 2021-12-11 05:16:38 --> Output Class Initialized
INFO - 2021-12-11 05:16:38 --> Security Class Initialized
DEBUG - 2021-12-11 05:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:16:38 --> Input Class Initialized
INFO - 2021-12-11 05:16:38 --> Language Class Initialized
INFO - 2021-12-11 05:16:38 --> Language Class Initialized
INFO - 2021-12-11 05:16:38 --> Config Class Initialized
INFO - 2021-12-11 05:16:38 --> Loader Class Initialized
INFO - 2021-12-11 05:16:38 --> Helper loaded: url_helper
INFO - 2021-12-11 05:16:38 --> Helper loaded: file_helper
INFO - 2021-12-11 05:16:38 --> Helper loaded: form_helper
INFO - 2021-12-11 05:16:38 --> Helper loaded: my_helper
INFO - 2021-12-11 05:16:38 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:16:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:16:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:16:38 --> Controller Class Initialized
DEBUG - 2021-12-11 05:16:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:16:38 --> Final output sent to browser
DEBUG - 2021-12-11 05:16:38 --> Total execution time: 0.0670
INFO - 2021-12-11 05:16:39 --> Config Class Initialized
INFO - 2021-12-11 05:16:39 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:16:39 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:16:39 --> Utf8 Class Initialized
INFO - 2021-12-11 05:16:39 --> URI Class Initialized
INFO - 2021-12-11 05:16:39 --> Router Class Initialized
INFO - 2021-12-11 05:16:39 --> Output Class Initialized
INFO - 2021-12-11 05:16:39 --> Security Class Initialized
DEBUG - 2021-12-11 05:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:16:39 --> Input Class Initialized
INFO - 2021-12-11 05:16:39 --> Language Class Initialized
INFO - 2021-12-11 05:16:39 --> Language Class Initialized
INFO - 2021-12-11 05:16:39 --> Config Class Initialized
INFO - 2021-12-11 05:16:39 --> Loader Class Initialized
INFO - 2021-12-11 05:16:39 --> Helper loaded: url_helper
INFO - 2021-12-11 05:16:39 --> Helper loaded: file_helper
INFO - 2021-12-11 05:16:39 --> Helper loaded: form_helper
INFO - 2021-12-11 05:16:39 --> Helper loaded: my_helper
INFO - 2021-12-11 05:16:39 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:16:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:16:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:16:39 --> Controller Class Initialized
DEBUG - 2021-12-11 05:16:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:16:39 --> Final output sent to browser
DEBUG - 2021-12-11 05:16:39 --> Total execution time: 0.0690
INFO - 2021-12-11 05:16:41 --> Config Class Initialized
INFO - 2021-12-11 05:16:41 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:16:41 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:16:41 --> Utf8 Class Initialized
INFO - 2021-12-11 05:16:41 --> URI Class Initialized
INFO - 2021-12-11 05:16:41 --> Router Class Initialized
INFO - 2021-12-11 05:16:41 --> Output Class Initialized
INFO - 2021-12-11 05:16:41 --> Security Class Initialized
DEBUG - 2021-12-11 05:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:16:41 --> Input Class Initialized
INFO - 2021-12-11 05:16:41 --> Language Class Initialized
INFO - 2021-12-11 05:16:41 --> Language Class Initialized
INFO - 2021-12-11 05:16:41 --> Config Class Initialized
INFO - 2021-12-11 05:16:41 --> Loader Class Initialized
INFO - 2021-12-11 05:16:41 --> Helper loaded: url_helper
INFO - 2021-12-11 05:16:41 --> Helper loaded: file_helper
INFO - 2021-12-11 05:16:41 --> Helper loaded: form_helper
INFO - 2021-12-11 05:16:41 --> Helper loaded: my_helper
INFO - 2021-12-11 05:16:41 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:16:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:16:41 --> Controller Class Initialized
DEBUG - 2021-12-11 05:16:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:16:41 --> Final output sent to browser
DEBUG - 2021-12-11 05:16:41 --> Total execution time: 0.0650
INFO - 2021-12-11 05:16:43 --> Config Class Initialized
INFO - 2021-12-11 05:16:43 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:16:43 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:16:43 --> Utf8 Class Initialized
INFO - 2021-12-11 05:16:43 --> URI Class Initialized
INFO - 2021-12-11 05:16:43 --> Router Class Initialized
INFO - 2021-12-11 05:16:43 --> Output Class Initialized
INFO - 2021-12-11 05:16:43 --> Security Class Initialized
DEBUG - 2021-12-11 05:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:16:43 --> Input Class Initialized
INFO - 2021-12-11 05:16:43 --> Language Class Initialized
INFO - 2021-12-11 05:16:43 --> Language Class Initialized
INFO - 2021-12-11 05:16:43 --> Config Class Initialized
INFO - 2021-12-11 05:16:43 --> Loader Class Initialized
INFO - 2021-12-11 05:16:43 --> Helper loaded: url_helper
INFO - 2021-12-11 05:16:43 --> Helper loaded: file_helper
INFO - 2021-12-11 05:16:43 --> Helper loaded: form_helper
INFO - 2021-12-11 05:16:43 --> Helper loaded: my_helper
INFO - 2021-12-11 05:16:43 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:16:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:16:43 --> Controller Class Initialized
DEBUG - 2021-12-11 05:16:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:16:43 --> Final output sent to browser
DEBUG - 2021-12-11 05:16:43 --> Total execution time: 0.0650
INFO - 2021-12-11 05:16:44 --> Config Class Initialized
INFO - 2021-12-11 05:16:44 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:16:44 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:16:44 --> Utf8 Class Initialized
INFO - 2021-12-11 05:16:44 --> URI Class Initialized
INFO - 2021-12-11 05:16:44 --> Router Class Initialized
INFO - 2021-12-11 05:16:44 --> Output Class Initialized
INFO - 2021-12-11 05:16:44 --> Security Class Initialized
DEBUG - 2021-12-11 05:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:16:45 --> Input Class Initialized
INFO - 2021-12-11 05:16:45 --> Language Class Initialized
INFO - 2021-12-11 05:16:45 --> Language Class Initialized
INFO - 2021-12-11 05:16:45 --> Config Class Initialized
INFO - 2021-12-11 05:16:45 --> Loader Class Initialized
INFO - 2021-12-11 05:16:45 --> Helper loaded: url_helper
INFO - 2021-12-11 05:16:45 --> Helper loaded: file_helper
INFO - 2021-12-11 05:16:45 --> Helper loaded: form_helper
INFO - 2021-12-11 05:16:45 --> Helper loaded: my_helper
INFO - 2021-12-11 05:16:45 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:16:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:16:45 --> Controller Class Initialized
DEBUG - 2021-12-11 05:16:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:16:45 --> Final output sent to browser
DEBUG - 2021-12-11 05:16:45 --> Total execution time: 0.0600
INFO - 2021-12-11 05:16:46 --> Config Class Initialized
INFO - 2021-12-11 05:16:46 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:16:46 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:16:46 --> Utf8 Class Initialized
INFO - 2021-12-11 05:16:46 --> URI Class Initialized
INFO - 2021-12-11 05:16:46 --> Router Class Initialized
INFO - 2021-12-11 05:16:46 --> Output Class Initialized
INFO - 2021-12-11 05:16:46 --> Security Class Initialized
DEBUG - 2021-12-11 05:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:16:46 --> Input Class Initialized
INFO - 2021-12-11 05:16:46 --> Language Class Initialized
INFO - 2021-12-11 05:16:46 --> Language Class Initialized
INFO - 2021-12-11 05:16:46 --> Config Class Initialized
INFO - 2021-12-11 05:16:46 --> Loader Class Initialized
INFO - 2021-12-11 05:16:46 --> Helper loaded: url_helper
INFO - 2021-12-11 05:16:46 --> Helper loaded: file_helper
INFO - 2021-12-11 05:16:46 --> Helper loaded: form_helper
INFO - 2021-12-11 05:16:46 --> Helper loaded: my_helper
INFO - 2021-12-11 05:16:46 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:16:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:16:46 --> Controller Class Initialized
DEBUG - 2021-12-11 05:16:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:16:46 --> Final output sent to browser
DEBUG - 2021-12-11 05:16:46 --> Total execution time: 0.0620
INFO - 2021-12-11 05:16:49 --> Config Class Initialized
INFO - 2021-12-11 05:16:49 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:16:49 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:16:49 --> Utf8 Class Initialized
INFO - 2021-12-11 05:16:49 --> URI Class Initialized
INFO - 2021-12-11 05:16:49 --> Router Class Initialized
INFO - 2021-12-11 05:16:49 --> Output Class Initialized
INFO - 2021-12-11 05:16:49 --> Security Class Initialized
DEBUG - 2021-12-11 05:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:16:49 --> Input Class Initialized
INFO - 2021-12-11 05:16:49 --> Language Class Initialized
INFO - 2021-12-11 05:16:49 --> Language Class Initialized
INFO - 2021-12-11 05:16:49 --> Config Class Initialized
INFO - 2021-12-11 05:16:49 --> Loader Class Initialized
INFO - 2021-12-11 05:16:49 --> Helper loaded: url_helper
INFO - 2021-12-11 05:16:49 --> Helper loaded: file_helper
INFO - 2021-12-11 05:16:49 --> Helper loaded: form_helper
INFO - 2021-12-11 05:16:49 --> Helper loaded: my_helper
INFO - 2021-12-11 05:16:49 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:16:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:16:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:16:49 --> Controller Class Initialized
DEBUG - 2021-12-11 05:16:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:16:49 --> Final output sent to browser
DEBUG - 2021-12-11 05:16:49 --> Total execution time: 0.0520
INFO - 2021-12-11 05:16:51 --> Config Class Initialized
INFO - 2021-12-11 05:16:51 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:16:51 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:16:51 --> Utf8 Class Initialized
INFO - 2021-12-11 05:16:51 --> URI Class Initialized
INFO - 2021-12-11 05:16:51 --> Router Class Initialized
INFO - 2021-12-11 05:16:51 --> Output Class Initialized
INFO - 2021-12-11 05:16:51 --> Security Class Initialized
DEBUG - 2021-12-11 05:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:16:51 --> Input Class Initialized
INFO - 2021-12-11 05:16:51 --> Language Class Initialized
INFO - 2021-12-11 05:16:51 --> Language Class Initialized
INFO - 2021-12-11 05:16:51 --> Config Class Initialized
INFO - 2021-12-11 05:16:51 --> Loader Class Initialized
INFO - 2021-12-11 05:16:51 --> Helper loaded: url_helper
INFO - 2021-12-11 05:16:51 --> Helper loaded: file_helper
INFO - 2021-12-11 05:16:51 --> Helper loaded: form_helper
INFO - 2021-12-11 05:16:51 --> Helper loaded: my_helper
INFO - 2021-12-11 05:16:51 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:16:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:16:51 --> Controller Class Initialized
DEBUG - 2021-12-11 05:16:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:16:51 --> Final output sent to browser
DEBUG - 2021-12-11 05:16:51 --> Total execution time: 0.0600
INFO - 2021-12-11 05:16:52 --> Config Class Initialized
INFO - 2021-12-11 05:16:52 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:16:52 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:16:52 --> Utf8 Class Initialized
INFO - 2021-12-11 05:16:52 --> URI Class Initialized
INFO - 2021-12-11 05:16:52 --> Router Class Initialized
INFO - 2021-12-11 05:16:52 --> Output Class Initialized
INFO - 2021-12-11 05:16:52 --> Security Class Initialized
DEBUG - 2021-12-11 05:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:16:52 --> Input Class Initialized
INFO - 2021-12-11 05:16:52 --> Language Class Initialized
INFO - 2021-12-11 05:16:52 --> Language Class Initialized
INFO - 2021-12-11 05:16:52 --> Config Class Initialized
INFO - 2021-12-11 05:16:52 --> Loader Class Initialized
INFO - 2021-12-11 05:16:52 --> Helper loaded: url_helper
INFO - 2021-12-11 05:16:52 --> Helper loaded: file_helper
INFO - 2021-12-11 05:16:52 --> Helper loaded: form_helper
INFO - 2021-12-11 05:16:52 --> Helper loaded: my_helper
INFO - 2021-12-11 05:16:52 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:16:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:16:52 --> Controller Class Initialized
DEBUG - 2021-12-11 05:16:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:16:52 --> Final output sent to browser
DEBUG - 2021-12-11 05:16:52 --> Total execution time: 0.0730
INFO - 2021-12-11 05:16:55 --> Config Class Initialized
INFO - 2021-12-11 05:16:55 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:16:55 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:16:55 --> Utf8 Class Initialized
INFO - 2021-12-11 05:16:55 --> URI Class Initialized
INFO - 2021-12-11 05:16:55 --> Router Class Initialized
INFO - 2021-12-11 05:16:55 --> Output Class Initialized
INFO - 2021-12-11 05:16:55 --> Security Class Initialized
DEBUG - 2021-12-11 05:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:16:55 --> Input Class Initialized
INFO - 2021-12-11 05:16:55 --> Language Class Initialized
INFO - 2021-12-11 05:16:55 --> Language Class Initialized
INFO - 2021-12-11 05:16:55 --> Config Class Initialized
INFO - 2021-12-11 05:16:55 --> Loader Class Initialized
INFO - 2021-12-11 05:16:55 --> Helper loaded: url_helper
INFO - 2021-12-11 05:16:55 --> Helper loaded: file_helper
INFO - 2021-12-11 05:16:55 --> Helper loaded: form_helper
INFO - 2021-12-11 05:16:55 --> Helper loaded: my_helper
INFO - 2021-12-11 05:16:55 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:16:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:16:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:16:55 --> Controller Class Initialized
DEBUG - 2021-12-11 05:16:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:16:55 --> Final output sent to browser
DEBUG - 2021-12-11 05:16:55 --> Total execution time: 0.0630
INFO - 2021-12-11 05:16:56 --> Config Class Initialized
INFO - 2021-12-11 05:16:56 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:16:56 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:16:56 --> Utf8 Class Initialized
INFO - 2021-12-11 05:16:56 --> URI Class Initialized
INFO - 2021-12-11 05:16:56 --> Router Class Initialized
INFO - 2021-12-11 05:16:56 --> Output Class Initialized
INFO - 2021-12-11 05:16:56 --> Security Class Initialized
DEBUG - 2021-12-11 05:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:16:56 --> Input Class Initialized
INFO - 2021-12-11 05:16:56 --> Language Class Initialized
INFO - 2021-12-11 05:16:56 --> Language Class Initialized
INFO - 2021-12-11 05:16:56 --> Config Class Initialized
INFO - 2021-12-11 05:16:56 --> Loader Class Initialized
INFO - 2021-12-11 05:16:56 --> Helper loaded: url_helper
INFO - 2021-12-11 05:16:56 --> Helper loaded: file_helper
INFO - 2021-12-11 05:16:56 --> Helper loaded: form_helper
INFO - 2021-12-11 05:16:56 --> Helper loaded: my_helper
INFO - 2021-12-11 05:16:56 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:16:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:16:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:16:56 --> Controller Class Initialized
DEBUG - 2021-12-11 05:16:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:16:56 --> Final output sent to browser
DEBUG - 2021-12-11 05:16:56 --> Total execution time: 0.0630
INFO - 2021-12-11 05:16:58 --> Config Class Initialized
INFO - 2021-12-11 05:16:58 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:16:58 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:16:58 --> Utf8 Class Initialized
INFO - 2021-12-11 05:16:58 --> URI Class Initialized
INFO - 2021-12-11 05:16:58 --> Router Class Initialized
INFO - 2021-12-11 05:16:58 --> Output Class Initialized
INFO - 2021-12-11 05:16:58 --> Security Class Initialized
DEBUG - 2021-12-11 05:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:16:58 --> Input Class Initialized
INFO - 2021-12-11 05:16:58 --> Language Class Initialized
INFO - 2021-12-11 05:16:58 --> Language Class Initialized
INFO - 2021-12-11 05:16:58 --> Config Class Initialized
INFO - 2021-12-11 05:16:58 --> Loader Class Initialized
INFO - 2021-12-11 05:16:58 --> Helper loaded: url_helper
INFO - 2021-12-11 05:16:58 --> Helper loaded: file_helper
INFO - 2021-12-11 05:16:58 --> Helper loaded: form_helper
INFO - 2021-12-11 05:16:58 --> Helper loaded: my_helper
INFO - 2021-12-11 05:16:58 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:16:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:16:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:16:58 --> Controller Class Initialized
DEBUG - 2021-12-11 05:16:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:16:58 --> Final output sent to browser
DEBUG - 2021-12-11 05:16:58 --> Total execution time: 0.0660
INFO - 2021-12-11 05:17:01 --> Config Class Initialized
INFO - 2021-12-11 05:17:01 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:17:01 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:17:01 --> Utf8 Class Initialized
INFO - 2021-12-11 05:17:01 --> URI Class Initialized
INFO - 2021-12-11 05:17:01 --> Router Class Initialized
INFO - 2021-12-11 05:17:01 --> Output Class Initialized
INFO - 2021-12-11 05:17:01 --> Security Class Initialized
DEBUG - 2021-12-11 05:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:17:01 --> Input Class Initialized
INFO - 2021-12-11 05:17:01 --> Language Class Initialized
INFO - 2021-12-11 05:17:01 --> Language Class Initialized
INFO - 2021-12-11 05:17:01 --> Config Class Initialized
INFO - 2021-12-11 05:17:01 --> Loader Class Initialized
INFO - 2021-12-11 05:17:01 --> Helper loaded: url_helper
INFO - 2021-12-11 05:17:01 --> Helper loaded: file_helper
INFO - 2021-12-11 05:17:01 --> Helper loaded: form_helper
INFO - 2021-12-11 05:17:01 --> Helper loaded: my_helper
INFO - 2021-12-11 05:17:01 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:17:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:17:01 --> Controller Class Initialized
DEBUG - 2021-12-11 05:17:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:17:01 --> Final output sent to browser
DEBUG - 2021-12-11 05:17:01 --> Total execution time: 0.0680
INFO - 2021-12-11 05:17:03 --> Config Class Initialized
INFO - 2021-12-11 05:17:03 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:17:03 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:17:03 --> Utf8 Class Initialized
INFO - 2021-12-11 05:17:03 --> URI Class Initialized
INFO - 2021-12-11 05:17:03 --> Router Class Initialized
INFO - 2021-12-11 05:17:03 --> Output Class Initialized
INFO - 2021-12-11 05:17:03 --> Security Class Initialized
DEBUG - 2021-12-11 05:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:17:03 --> Input Class Initialized
INFO - 2021-12-11 05:17:03 --> Language Class Initialized
INFO - 2021-12-11 05:17:03 --> Language Class Initialized
INFO - 2021-12-11 05:17:03 --> Config Class Initialized
INFO - 2021-12-11 05:17:03 --> Loader Class Initialized
INFO - 2021-12-11 05:17:03 --> Helper loaded: url_helper
INFO - 2021-12-11 05:17:03 --> Helper loaded: file_helper
INFO - 2021-12-11 05:17:03 --> Helper loaded: form_helper
INFO - 2021-12-11 05:17:03 --> Helper loaded: my_helper
INFO - 2021-12-11 05:17:03 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:17:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:17:03 --> Controller Class Initialized
DEBUG - 2021-12-11 05:17:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:17:03 --> Final output sent to browser
DEBUG - 2021-12-11 05:17:03 --> Total execution time: 0.0650
INFO - 2021-12-11 05:17:06 --> Config Class Initialized
INFO - 2021-12-11 05:17:06 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:17:06 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:17:06 --> Utf8 Class Initialized
INFO - 2021-12-11 05:17:06 --> URI Class Initialized
INFO - 2021-12-11 05:17:06 --> Router Class Initialized
INFO - 2021-12-11 05:17:06 --> Output Class Initialized
INFO - 2021-12-11 05:17:06 --> Security Class Initialized
DEBUG - 2021-12-11 05:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:17:06 --> Input Class Initialized
INFO - 2021-12-11 05:17:06 --> Language Class Initialized
INFO - 2021-12-11 05:17:06 --> Language Class Initialized
INFO - 2021-12-11 05:17:06 --> Config Class Initialized
INFO - 2021-12-11 05:17:06 --> Loader Class Initialized
INFO - 2021-12-11 05:17:06 --> Helper loaded: url_helper
INFO - 2021-12-11 05:17:06 --> Helper loaded: file_helper
INFO - 2021-12-11 05:17:06 --> Helper loaded: form_helper
INFO - 2021-12-11 05:17:06 --> Helper loaded: my_helper
INFO - 2021-12-11 05:17:06 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:17:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:17:06 --> Controller Class Initialized
DEBUG - 2021-12-11 05:17:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:17:06 --> Final output sent to browser
DEBUG - 2021-12-11 05:17:06 --> Total execution time: 0.0580
INFO - 2021-12-11 05:17:07 --> Config Class Initialized
INFO - 2021-12-11 05:17:07 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:17:07 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:17:07 --> Utf8 Class Initialized
INFO - 2021-12-11 05:17:07 --> URI Class Initialized
INFO - 2021-12-11 05:17:07 --> Router Class Initialized
INFO - 2021-12-11 05:17:07 --> Output Class Initialized
INFO - 2021-12-11 05:17:07 --> Security Class Initialized
DEBUG - 2021-12-11 05:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:17:07 --> Input Class Initialized
INFO - 2021-12-11 05:17:07 --> Language Class Initialized
INFO - 2021-12-11 05:17:07 --> Language Class Initialized
INFO - 2021-12-11 05:17:07 --> Config Class Initialized
INFO - 2021-12-11 05:17:07 --> Loader Class Initialized
INFO - 2021-12-11 05:17:07 --> Helper loaded: url_helper
INFO - 2021-12-11 05:17:07 --> Helper loaded: file_helper
INFO - 2021-12-11 05:17:07 --> Helper loaded: form_helper
INFO - 2021-12-11 05:17:07 --> Helper loaded: my_helper
INFO - 2021-12-11 05:17:07 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:17:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:17:07 --> Controller Class Initialized
DEBUG - 2021-12-11 05:17:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:17:07 --> Final output sent to browser
DEBUG - 2021-12-11 05:17:07 --> Total execution time: 0.0530
INFO - 2021-12-11 05:17:10 --> Config Class Initialized
INFO - 2021-12-11 05:17:10 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:17:10 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:17:10 --> Utf8 Class Initialized
INFO - 2021-12-11 05:17:10 --> URI Class Initialized
INFO - 2021-12-11 05:17:10 --> Router Class Initialized
INFO - 2021-12-11 05:17:10 --> Output Class Initialized
INFO - 2021-12-11 05:17:10 --> Security Class Initialized
DEBUG - 2021-12-11 05:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:17:10 --> Input Class Initialized
INFO - 2021-12-11 05:17:10 --> Language Class Initialized
INFO - 2021-12-11 05:17:10 --> Language Class Initialized
INFO - 2021-12-11 05:17:10 --> Config Class Initialized
INFO - 2021-12-11 05:17:10 --> Loader Class Initialized
INFO - 2021-12-11 05:17:10 --> Helper loaded: url_helper
INFO - 2021-12-11 05:17:10 --> Helper loaded: file_helper
INFO - 2021-12-11 05:17:10 --> Helper loaded: form_helper
INFO - 2021-12-11 05:17:10 --> Helper loaded: my_helper
INFO - 2021-12-11 05:17:10 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:17:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:17:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:17:10 --> Controller Class Initialized
DEBUG - 2021-12-11 05:17:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:17:10 --> Final output sent to browser
DEBUG - 2021-12-11 05:17:10 --> Total execution time: 0.0670
INFO - 2021-12-11 05:17:12 --> Config Class Initialized
INFO - 2021-12-11 05:17:12 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:17:12 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:17:12 --> Utf8 Class Initialized
INFO - 2021-12-11 05:17:12 --> URI Class Initialized
INFO - 2021-12-11 05:17:12 --> Router Class Initialized
INFO - 2021-12-11 05:17:12 --> Output Class Initialized
INFO - 2021-12-11 05:17:12 --> Security Class Initialized
DEBUG - 2021-12-11 05:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:17:12 --> Input Class Initialized
INFO - 2021-12-11 05:17:12 --> Language Class Initialized
INFO - 2021-12-11 05:17:12 --> Language Class Initialized
INFO - 2021-12-11 05:17:12 --> Config Class Initialized
INFO - 2021-12-11 05:17:12 --> Loader Class Initialized
INFO - 2021-12-11 05:17:12 --> Helper loaded: url_helper
INFO - 2021-12-11 05:17:12 --> Helper loaded: file_helper
INFO - 2021-12-11 05:17:12 --> Helper loaded: form_helper
INFO - 2021-12-11 05:17:12 --> Helper loaded: my_helper
INFO - 2021-12-11 05:17:12 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:17:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:17:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:17:12 --> Controller Class Initialized
DEBUG - 2021-12-11 05:17:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:17:12 --> Final output sent to browser
DEBUG - 2021-12-11 05:17:12 --> Total execution time: 0.0740
INFO - 2021-12-11 05:17:14 --> Config Class Initialized
INFO - 2021-12-11 05:17:14 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:17:14 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:17:14 --> Utf8 Class Initialized
INFO - 2021-12-11 05:17:14 --> URI Class Initialized
INFO - 2021-12-11 05:17:14 --> Router Class Initialized
INFO - 2021-12-11 05:17:14 --> Output Class Initialized
INFO - 2021-12-11 05:17:14 --> Security Class Initialized
DEBUG - 2021-12-11 05:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:17:14 --> Input Class Initialized
INFO - 2021-12-11 05:17:14 --> Language Class Initialized
INFO - 2021-12-11 05:17:14 --> Language Class Initialized
INFO - 2021-12-11 05:17:14 --> Config Class Initialized
INFO - 2021-12-11 05:17:14 --> Loader Class Initialized
INFO - 2021-12-11 05:17:14 --> Helper loaded: url_helper
INFO - 2021-12-11 05:17:14 --> Helper loaded: file_helper
INFO - 2021-12-11 05:17:14 --> Helper loaded: form_helper
INFO - 2021-12-11 05:17:14 --> Helper loaded: my_helper
INFO - 2021-12-11 05:17:14 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:17:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:17:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:17:14 --> Controller Class Initialized
DEBUG - 2021-12-11 05:17:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:17:14 --> Final output sent to browser
DEBUG - 2021-12-11 05:17:14 --> Total execution time: 0.0650
INFO - 2021-12-11 05:17:16 --> Config Class Initialized
INFO - 2021-12-11 05:17:16 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:17:16 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:17:16 --> Utf8 Class Initialized
INFO - 2021-12-11 05:17:16 --> URI Class Initialized
INFO - 2021-12-11 05:17:16 --> Router Class Initialized
INFO - 2021-12-11 05:17:16 --> Output Class Initialized
INFO - 2021-12-11 05:17:16 --> Security Class Initialized
DEBUG - 2021-12-11 05:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:17:16 --> Input Class Initialized
INFO - 2021-12-11 05:17:16 --> Language Class Initialized
INFO - 2021-12-11 05:17:16 --> Language Class Initialized
INFO - 2021-12-11 05:17:16 --> Config Class Initialized
INFO - 2021-12-11 05:17:16 --> Loader Class Initialized
INFO - 2021-12-11 05:17:16 --> Helper loaded: url_helper
INFO - 2021-12-11 05:17:16 --> Helper loaded: file_helper
INFO - 2021-12-11 05:17:16 --> Helper loaded: form_helper
INFO - 2021-12-11 05:17:16 --> Helper loaded: my_helper
INFO - 2021-12-11 05:17:16 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:17:16 --> Controller Class Initialized
DEBUG - 2021-12-11 05:17:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:17:16 --> Final output sent to browser
DEBUG - 2021-12-11 05:17:16 --> Total execution time: 0.0600
INFO - 2021-12-11 05:17:18 --> Config Class Initialized
INFO - 2021-12-11 05:17:18 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:17:18 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:17:18 --> Utf8 Class Initialized
INFO - 2021-12-11 05:17:18 --> URI Class Initialized
INFO - 2021-12-11 05:17:18 --> Router Class Initialized
INFO - 2021-12-11 05:17:18 --> Output Class Initialized
INFO - 2021-12-11 05:17:18 --> Security Class Initialized
DEBUG - 2021-12-11 05:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:17:18 --> Input Class Initialized
INFO - 2021-12-11 05:17:18 --> Language Class Initialized
INFO - 2021-12-11 05:17:18 --> Language Class Initialized
INFO - 2021-12-11 05:17:18 --> Config Class Initialized
INFO - 2021-12-11 05:17:18 --> Loader Class Initialized
INFO - 2021-12-11 05:17:18 --> Helper loaded: url_helper
INFO - 2021-12-11 05:17:18 --> Helper loaded: file_helper
INFO - 2021-12-11 05:17:18 --> Helper loaded: form_helper
INFO - 2021-12-11 05:17:18 --> Helper loaded: my_helper
INFO - 2021-12-11 05:17:18 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:17:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:17:18 --> Controller Class Initialized
DEBUG - 2021-12-11 05:17:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:17:18 --> Final output sent to browser
DEBUG - 2021-12-11 05:17:18 --> Total execution time: 0.0660
INFO - 2021-12-11 05:17:29 --> Config Class Initialized
INFO - 2021-12-11 05:17:29 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:17:29 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:17:29 --> Utf8 Class Initialized
INFO - 2021-12-11 05:17:29 --> URI Class Initialized
INFO - 2021-12-11 05:17:29 --> Router Class Initialized
INFO - 2021-12-11 05:17:29 --> Output Class Initialized
INFO - 2021-12-11 05:17:29 --> Security Class Initialized
DEBUG - 2021-12-11 05:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:17:29 --> Input Class Initialized
INFO - 2021-12-11 05:17:29 --> Language Class Initialized
INFO - 2021-12-11 05:17:29 --> Language Class Initialized
INFO - 2021-12-11 05:17:29 --> Config Class Initialized
INFO - 2021-12-11 05:17:29 --> Loader Class Initialized
INFO - 2021-12-11 05:17:29 --> Helper loaded: url_helper
INFO - 2021-12-11 05:17:29 --> Helper loaded: file_helper
INFO - 2021-12-11 05:17:29 --> Helper loaded: form_helper
INFO - 2021-12-11 05:17:29 --> Helper loaded: my_helper
INFO - 2021-12-11 05:17:29 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:17:29 --> Controller Class Initialized
DEBUG - 2021-12-11 05:17:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:17:29 --> Final output sent to browser
DEBUG - 2021-12-11 05:17:29 --> Total execution time: 0.0620
INFO - 2021-12-11 05:17:31 --> Config Class Initialized
INFO - 2021-12-11 05:17:31 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:17:31 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:17:31 --> Utf8 Class Initialized
INFO - 2021-12-11 05:17:31 --> URI Class Initialized
INFO - 2021-12-11 05:17:31 --> Router Class Initialized
INFO - 2021-12-11 05:17:31 --> Output Class Initialized
INFO - 2021-12-11 05:17:31 --> Security Class Initialized
DEBUG - 2021-12-11 05:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:17:31 --> Input Class Initialized
INFO - 2021-12-11 05:17:31 --> Language Class Initialized
INFO - 2021-12-11 05:17:31 --> Language Class Initialized
INFO - 2021-12-11 05:17:31 --> Config Class Initialized
INFO - 2021-12-11 05:17:31 --> Loader Class Initialized
INFO - 2021-12-11 05:17:31 --> Helper loaded: url_helper
INFO - 2021-12-11 05:17:31 --> Helper loaded: file_helper
INFO - 2021-12-11 05:17:31 --> Helper loaded: form_helper
INFO - 2021-12-11 05:17:31 --> Helper loaded: my_helper
INFO - 2021-12-11 05:17:31 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:17:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:17:31 --> Controller Class Initialized
DEBUG - 2021-12-11 05:17:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:17:31 --> Final output sent to browser
DEBUG - 2021-12-11 05:17:31 --> Total execution time: 0.0640
INFO - 2021-12-11 05:17:33 --> Config Class Initialized
INFO - 2021-12-11 05:17:33 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:17:33 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:17:33 --> Utf8 Class Initialized
INFO - 2021-12-11 05:17:33 --> URI Class Initialized
INFO - 2021-12-11 05:17:33 --> Router Class Initialized
INFO - 2021-12-11 05:17:33 --> Output Class Initialized
INFO - 2021-12-11 05:17:33 --> Security Class Initialized
DEBUG - 2021-12-11 05:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:17:33 --> Input Class Initialized
INFO - 2021-12-11 05:17:33 --> Language Class Initialized
INFO - 2021-12-11 05:17:33 --> Language Class Initialized
INFO - 2021-12-11 05:17:33 --> Config Class Initialized
INFO - 2021-12-11 05:17:33 --> Loader Class Initialized
INFO - 2021-12-11 05:17:33 --> Helper loaded: url_helper
INFO - 2021-12-11 05:17:33 --> Helper loaded: file_helper
INFO - 2021-12-11 05:17:33 --> Helper loaded: form_helper
INFO - 2021-12-11 05:17:33 --> Helper loaded: my_helper
INFO - 2021-12-11 05:17:33 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:17:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:17:33 --> Controller Class Initialized
DEBUG - 2021-12-11 05:17:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:17:33 --> Final output sent to browser
DEBUG - 2021-12-11 05:17:33 --> Total execution time: 0.0700
INFO - 2021-12-11 05:17:34 --> Config Class Initialized
INFO - 2021-12-11 05:17:34 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:17:34 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:17:34 --> Utf8 Class Initialized
INFO - 2021-12-11 05:17:34 --> URI Class Initialized
INFO - 2021-12-11 05:17:34 --> Router Class Initialized
INFO - 2021-12-11 05:17:34 --> Output Class Initialized
INFO - 2021-12-11 05:17:34 --> Security Class Initialized
DEBUG - 2021-12-11 05:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:17:34 --> Input Class Initialized
INFO - 2021-12-11 05:17:34 --> Language Class Initialized
INFO - 2021-12-11 05:17:34 --> Language Class Initialized
INFO - 2021-12-11 05:17:34 --> Config Class Initialized
INFO - 2021-12-11 05:17:34 --> Loader Class Initialized
INFO - 2021-12-11 05:17:34 --> Helper loaded: url_helper
INFO - 2021-12-11 05:17:34 --> Helper loaded: file_helper
INFO - 2021-12-11 05:17:34 --> Helper loaded: form_helper
INFO - 2021-12-11 05:17:34 --> Helper loaded: my_helper
INFO - 2021-12-11 05:17:34 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:17:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:17:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:17:34 --> Controller Class Initialized
DEBUG - 2021-12-11 05:17:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:17:34 --> Final output sent to browser
DEBUG - 2021-12-11 05:17:34 --> Total execution time: 0.0690
INFO - 2021-12-11 05:22:24 --> Config Class Initialized
INFO - 2021-12-11 05:22:24 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:22:24 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:22:24 --> Utf8 Class Initialized
INFO - 2021-12-11 05:22:24 --> URI Class Initialized
INFO - 2021-12-11 05:22:24 --> Router Class Initialized
INFO - 2021-12-11 05:22:24 --> Output Class Initialized
INFO - 2021-12-11 05:22:24 --> Security Class Initialized
DEBUG - 2021-12-11 05:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:22:24 --> Input Class Initialized
INFO - 2021-12-11 05:22:24 --> Language Class Initialized
INFO - 2021-12-11 05:22:24 --> Language Class Initialized
INFO - 2021-12-11 05:22:24 --> Config Class Initialized
INFO - 2021-12-11 05:22:24 --> Loader Class Initialized
INFO - 2021-12-11 05:22:24 --> Helper loaded: url_helper
INFO - 2021-12-11 05:22:24 --> Helper loaded: file_helper
INFO - 2021-12-11 05:22:24 --> Helper loaded: form_helper
INFO - 2021-12-11 05:22:24 --> Helper loaded: my_helper
INFO - 2021-12-11 05:22:24 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:22:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:22:24 --> Controller Class Initialized
INFO - 2021-12-11 05:22:24 --> Helper loaded: cookie_helper
INFO - 2021-12-11 05:22:24 --> Config Class Initialized
INFO - 2021-12-11 05:22:24 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:22:24 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:22:24 --> Utf8 Class Initialized
INFO - 2021-12-11 05:22:24 --> URI Class Initialized
INFO - 2021-12-11 05:22:24 --> Router Class Initialized
INFO - 2021-12-11 05:22:24 --> Output Class Initialized
INFO - 2021-12-11 05:22:24 --> Security Class Initialized
DEBUG - 2021-12-11 05:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:22:24 --> Input Class Initialized
INFO - 2021-12-11 05:22:24 --> Language Class Initialized
INFO - 2021-12-11 05:22:24 --> Language Class Initialized
INFO - 2021-12-11 05:22:24 --> Config Class Initialized
INFO - 2021-12-11 05:22:24 --> Loader Class Initialized
INFO - 2021-12-11 05:22:24 --> Helper loaded: url_helper
INFO - 2021-12-11 05:22:24 --> Helper loaded: file_helper
INFO - 2021-12-11 05:22:24 --> Helper loaded: form_helper
INFO - 2021-12-11 05:22:24 --> Helper loaded: my_helper
INFO - 2021-12-11 05:22:24 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:22:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:22:24 --> Controller Class Initialized
DEBUG - 2021-12-11 05:22:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-11 05:22:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-11 05:22:24 --> Final output sent to browser
DEBUG - 2021-12-11 05:22:24 --> Total execution time: 0.0350
INFO - 2021-12-11 05:22:46 --> Config Class Initialized
INFO - 2021-12-11 05:22:46 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:22:46 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:22:46 --> Utf8 Class Initialized
INFO - 2021-12-11 05:22:46 --> URI Class Initialized
INFO - 2021-12-11 05:22:46 --> Router Class Initialized
INFO - 2021-12-11 05:22:46 --> Output Class Initialized
INFO - 2021-12-11 05:22:46 --> Security Class Initialized
DEBUG - 2021-12-11 05:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:22:46 --> Input Class Initialized
INFO - 2021-12-11 05:22:46 --> Language Class Initialized
INFO - 2021-12-11 05:22:46 --> Language Class Initialized
INFO - 2021-12-11 05:22:46 --> Config Class Initialized
INFO - 2021-12-11 05:22:46 --> Loader Class Initialized
INFO - 2021-12-11 05:22:46 --> Helper loaded: url_helper
INFO - 2021-12-11 05:22:46 --> Helper loaded: file_helper
INFO - 2021-12-11 05:22:46 --> Helper loaded: form_helper
INFO - 2021-12-11 05:22:46 --> Helper loaded: my_helper
INFO - 2021-12-11 05:22:46 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:22:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:22:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:22:46 --> Controller Class Initialized
INFO - 2021-12-11 05:22:46 --> Helper loaded: cookie_helper
INFO - 2021-12-11 05:22:46 --> Final output sent to browser
DEBUG - 2021-12-11 05:22:46 --> Total execution time: 0.0420
INFO - 2021-12-11 05:22:46 --> Config Class Initialized
INFO - 2021-12-11 05:22:46 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:22:46 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:22:46 --> Utf8 Class Initialized
INFO - 2021-12-11 05:22:46 --> URI Class Initialized
INFO - 2021-12-11 05:22:46 --> Router Class Initialized
INFO - 2021-12-11 05:22:46 --> Output Class Initialized
INFO - 2021-12-11 05:22:46 --> Security Class Initialized
DEBUG - 2021-12-11 05:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:22:46 --> Input Class Initialized
INFO - 2021-12-11 05:22:46 --> Language Class Initialized
INFO - 2021-12-11 05:22:46 --> Language Class Initialized
INFO - 2021-12-11 05:22:46 --> Config Class Initialized
INFO - 2021-12-11 05:22:46 --> Loader Class Initialized
INFO - 2021-12-11 05:22:46 --> Helper loaded: url_helper
INFO - 2021-12-11 05:22:46 --> Helper loaded: file_helper
INFO - 2021-12-11 05:22:46 --> Helper loaded: form_helper
INFO - 2021-12-11 05:22:46 --> Helper loaded: my_helper
INFO - 2021-12-11 05:22:46 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:22:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:22:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:22:46 --> Controller Class Initialized
DEBUG - 2021-12-11 05:22:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-11 05:22:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-11 05:22:47 --> Final output sent to browser
DEBUG - 2021-12-11 05:22:47 --> Total execution time: 0.2250
INFO - 2021-12-11 05:22:49 --> Config Class Initialized
INFO - 2021-12-11 05:22:49 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:22:49 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:22:49 --> Utf8 Class Initialized
INFO - 2021-12-11 05:22:49 --> URI Class Initialized
INFO - 2021-12-11 05:22:49 --> Router Class Initialized
INFO - 2021-12-11 05:22:49 --> Output Class Initialized
INFO - 2021-12-11 05:22:49 --> Security Class Initialized
DEBUG - 2021-12-11 05:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:22:49 --> Input Class Initialized
INFO - 2021-12-11 05:22:49 --> Language Class Initialized
INFO - 2021-12-11 05:22:49 --> Language Class Initialized
INFO - 2021-12-11 05:22:49 --> Config Class Initialized
INFO - 2021-12-11 05:22:49 --> Loader Class Initialized
INFO - 2021-12-11 05:22:49 --> Helper loaded: url_helper
INFO - 2021-12-11 05:22:49 --> Helper loaded: file_helper
INFO - 2021-12-11 05:22:49 --> Helper loaded: form_helper
INFO - 2021-12-11 05:22:49 --> Helper loaded: my_helper
INFO - 2021-12-11 05:22:49 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:22:49 --> Controller Class Initialized
DEBUG - 2021-12-11 05:22:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-11 05:22:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-11 05:22:49 --> Final output sent to browser
DEBUG - 2021-12-11 05:22:49 --> Total execution time: 0.0820
INFO - 2021-12-11 05:22:51 --> Config Class Initialized
INFO - 2021-12-11 05:22:51 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:22:51 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:22:51 --> Utf8 Class Initialized
INFO - 2021-12-11 05:22:51 --> URI Class Initialized
INFO - 2021-12-11 05:22:51 --> Router Class Initialized
INFO - 2021-12-11 05:22:51 --> Output Class Initialized
INFO - 2021-12-11 05:22:51 --> Security Class Initialized
DEBUG - 2021-12-11 05:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:22:51 --> Input Class Initialized
INFO - 2021-12-11 05:22:51 --> Language Class Initialized
INFO - 2021-12-11 05:22:51 --> Language Class Initialized
INFO - 2021-12-11 05:22:51 --> Config Class Initialized
INFO - 2021-12-11 05:22:51 --> Loader Class Initialized
INFO - 2021-12-11 05:22:51 --> Helper loaded: url_helper
INFO - 2021-12-11 05:22:51 --> Helper loaded: file_helper
INFO - 2021-12-11 05:22:51 --> Helper loaded: form_helper
INFO - 2021-12-11 05:22:51 --> Helper loaded: my_helper
INFO - 2021-12-11 05:22:51 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:22:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:22:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:22:51 --> Controller Class Initialized
DEBUG - 2021-12-11 05:22:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:22:51 --> Final output sent to browser
DEBUG - 2021-12-11 05:22:51 --> Total execution time: 0.1110
INFO - 2021-12-11 05:22:56 --> Config Class Initialized
INFO - 2021-12-11 05:22:56 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:22:56 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:22:56 --> Utf8 Class Initialized
INFO - 2021-12-11 05:22:56 --> URI Class Initialized
INFO - 2021-12-11 05:22:56 --> Router Class Initialized
INFO - 2021-12-11 05:22:56 --> Output Class Initialized
INFO - 2021-12-11 05:22:56 --> Security Class Initialized
DEBUG - 2021-12-11 05:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:22:56 --> Input Class Initialized
INFO - 2021-12-11 05:22:56 --> Language Class Initialized
INFO - 2021-12-11 05:22:56 --> Language Class Initialized
INFO - 2021-12-11 05:22:56 --> Config Class Initialized
INFO - 2021-12-11 05:22:56 --> Loader Class Initialized
INFO - 2021-12-11 05:22:56 --> Helper loaded: url_helper
INFO - 2021-12-11 05:22:56 --> Helper loaded: file_helper
INFO - 2021-12-11 05:22:56 --> Helper loaded: form_helper
INFO - 2021-12-11 05:22:56 --> Helper loaded: my_helper
INFO - 2021-12-11 05:22:56 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:22:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:22:56 --> Controller Class Initialized
DEBUG - 2021-12-11 05:22:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:22:56 --> Final output sent to browser
DEBUG - 2021-12-11 05:22:56 --> Total execution time: 0.0640
INFO - 2021-12-11 05:22:59 --> Config Class Initialized
INFO - 2021-12-11 05:22:59 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:22:59 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:22:59 --> Utf8 Class Initialized
INFO - 2021-12-11 05:22:59 --> URI Class Initialized
INFO - 2021-12-11 05:22:59 --> Router Class Initialized
INFO - 2021-12-11 05:22:59 --> Output Class Initialized
INFO - 2021-12-11 05:22:59 --> Security Class Initialized
DEBUG - 2021-12-11 05:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:22:59 --> Input Class Initialized
INFO - 2021-12-11 05:22:59 --> Language Class Initialized
INFO - 2021-12-11 05:22:59 --> Language Class Initialized
INFO - 2021-12-11 05:22:59 --> Config Class Initialized
INFO - 2021-12-11 05:22:59 --> Loader Class Initialized
INFO - 2021-12-11 05:22:59 --> Helper loaded: url_helper
INFO - 2021-12-11 05:22:59 --> Helper loaded: file_helper
INFO - 2021-12-11 05:22:59 --> Helper loaded: form_helper
INFO - 2021-12-11 05:22:59 --> Helper loaded: my_helper
INFO - 2021-12-11 05:22:59 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:22:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:22:59 --> Controller Class Initialized
DEBUG - 2021-12-11 05:22:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:22:59 --> Final output sent to browser
DEBUG - 2021-12-11 05:22:59 --> Total execution time: 0.0610
INFO - 2021-12-11 05:23:01 --> Config Class Initialized
INFO - 2021-12-11 05:23:01 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:23:01 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:23:01 --> Utf8 Class Initialized
INFO - 2021-12-11 05:23:01 --> URI Class Initialized
INFO - 2021-12-11 05:23:01 --> Router Class Initialized
INFO - 2021-12-11 05:23:01 --> Output Class Initialized
INFO - 2021-12-11 05:23:01 --> Security Class Initialized
DEBUG - 2021-12-11 05:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:23:01 --> Input Class Initialized
INFO - 2021-12-11 05:23:01 --> Language Class Initialized
INFO - 2021-12-11 05:23:01 --> Language Class Initialized
INFO - 2021-12-11 05:23:01 --> Config Class Initialized
INFO - 2021-12-11 05:23:01 --> Loader Class Initialized
INFO - 2021-12-11 05:23:01 --> Helper loaded: url_helper
INFO - 2021-12-11 05:23:01 --> Helper loaded: file_helper
INFO - 2021-12-11 05:23:01 --> Helper loaded: form_helper
INFO - 2021-12-11 05:23:01 --> Helper loaded: my_helper
INFO - 2021-12-11 05:23:01 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:23:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:23:01 --> Controller Class Initialized
DEBUG - 2021-12-11 05:23:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:23:01 --> Final output sent to browser
DEBUG - 2021-12-11 05:23:01 --> Total execution time: 0.0620
INFO - 2021-12-11 05:23:03 --> Config Class Initialized
INFO - 2021-12-11 05:23:03 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:23:03 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:23:03 --> Utf8 Class Initialized
INFO - 2021-12-11 05:23:03 --> URI Class Initialized
INFO - 2021-12-11 05:23:03 --> Router Class Initialized
INFO - 2021-12-11 05:23:03 --> Output Class Initialized
INFO - 2021-12-11 05:23:03 --> Security Class Initialized
DEBUG - 2021-12-11 05:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:23:03 --> Input Class Initialized
INFO - 2021-12-11 05:23:03 --> Language Class Initialized
INFO - 2021-12-11 05:23:03 --> Language Class Initialized
INFO - 2021-12-11 05:23:03 --> Config Class Initialized
INFO - 2021-12-11 05:23:03 --> Loader Class Initialized
INFO - 2021-12-11 05:23:03 --> Helper loaded: url_helper
INFO - 2021-12-11 05:23:03 --> Helper loaded: file_helper
INFO - 2021-12-11 05:23:03 --> Helper loaded: form_helper
INFO - 2021-12-11 05:23:03 --> Helper loaded: my_helper
INFO - 2021-12-11 05:23:03 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:23:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:23:03 --> Controller Class Initialized
DEBUG - 2021-12-11 05:23:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:23:03 --> Final output sent to browser
DEBUG - 2021-12-11 05:23:03 --> Total execution time: 0.0640
INFO - 2021-12-11 05:23:04 --> Config Class Initialized
INFO - 2021-12-11 05:23:04 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:23:04 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:23:04 --> Utf8 Class Initialized
INFO - 2021-12-11 05:23:04 --> URI Class Initialized
INFO - 2021-12-11 05:23:04 --> Router Class Initialized
INFO - 2021-12-11 05:23:04 --> Output Class Initialized
INFO - 2021-12-11 05:23:04 --> Security Class Initialized
DEBUG - 2021-12-11 05:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:23:04 --> Input Class Initialized
INFO - 2021-12-11 05:23:04 --> Language Class Initialized
INFO - 2021-12-11 05:23:04 --> Language Class Initialized
INFO - 2021-12-11 05:23:04 --> Config Class Initialized
INFO - 2021-12-11 05:23:04 --> Loader Class Initialized
INFO - 2021-12-11 05:23:04 --> Helper loaded: url_helper
INFO - 2021-12-11 05:23:04 --> Helper loaded: file_helper
INFO - 2021-12-11 05:23:04 --> Helper loaded: form_helper
INFO - 2021-12-11 05:23:04 --> Helper loaded: my_helper
INFO - 2021-12-11 05:23:04 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:23:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:23:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:23:04 --> Controller Class Initialized
DEBUG - 2021-12-11 05:23:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:23:04 --> Final output sent to browser
DEBUG - 2021-12-11 05:23:04 --> Total execution time: 0.0640
INFO - 2021-12-11 05:23:07 --> Config Class Initialized
INFO - 2021-12-11 05:23:07 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:23:07 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:23:07 --> Utf8 Class Initialized
INFO - 2021-12-11 05:23:07 --> URI Class Initialized
INFO - 2021-12-11 05:23:07 --> Router Class Initialized
INFO - 2021-12-11 05:23:07 --> Output Class Initialized
INFO - 2021-12-11 05:23:07 --> Security Class Initialized
DEBUG - 2021-12-11 05:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:23:07 --> Input Class Initialized
INFO - 2021-12-11 05:23:07 --> Language Class Initialized
INFO - 2021-12-11 05:23:07 --> Language Class Initialized
INFO - 2021-12-11 05:23:07 --> Config Class Initialized
INFO - 2021-12-11 05:23:07 --> Loader Class Initialized
INFO - 2021-12-11 05:23:07 --> Helper loaded: url_helper
INFO - 2021-12-11 05:23:07 --> Helper loaded: file_helper
INFO - 2021-12-11 05:23:07 --> Helper loaded: form_helper
INFO - 2021-12-11 05:23:07 --> Helper loaded: my_helper
INFO - 2021-12-11 05:23:07 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:23:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:23:07 --> Controller Class Initialized
DEBUG - 2021-12-11 05:23:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:23:07 --> Final output sent to browser
DEBUG - 2021-12-11 05:23:07 --> Total execution time: 0.0620
INFO - 2021-12-11 05:23:09 --> Config Class Initialized
INFO - 2021-12-11 05:23:09 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:23:09 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:23:09 --> Utf8 Class Initialized
INFO - 2021-12-11 05:23:09 --> URI Class Initialized
INFO - 2021-12-11 05:23:09 --> Router Class Initialized
INFO - 2021-12-11 05:23:09 --> Output Class Initialized
INFO - 2021-12-11 05:23:09 --> Security Class Initialized
DEBUG - 2021-12-11 05:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:23:09 --> Input Class Initialized
INFO - 2021-12-11 05:23:09 --> Language Class Initialized
INFO - 2021-12-11 05:23:09 --> Language Class Initialized
INFO - 2021-12-11 05:23:09 --> Config Class Initialized
INFO - 2021-12-11 05:23:09 --> Loader Class Initialized
INFO - 2021-12-11 05:23:09 --> Helper loaded: url_helper
INFO - 2021-12-11 05:23:09 --> Helper loaded: file_helper
INFO - 2021-12-11 05:23:09 --> Helper loaded: form_helper
INFO - 2021-12-11 05:23:09 --> Helper loaded: my_helper
INFO - 2021-12-11 05:23:09 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:23:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:23:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:23:09 --> Controller Class Initialized
DEBUG - 2021-12-11 05:23:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:23:09 --> Final output sent to browser
DEBUG - 2021-12-11 05:23:09 --> Total execution time: 0.0710
INFO - 2021-12-11 05:23:10 --> Config Class Initialized
INFO - 2021-12-11 05:23:10 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:23:10 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:23:10 --> Utf8 Class Initialized
INFO - 2021-12-11 05:23:10 --> URI Class Initialized
INFO - 2021-12-11 05:23:10 --> Router Class Initialized
INFO - 2021-12-11 05:23:10 --> Output Class Initialized
INFO - 2021-12-11 05:23:10 --> Security Class Initialized
DEBUG - 2021-12-11 05:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:23:10 --> Input Class Initialized
INFO - 2021-12-11 05:23:10 --> Language Class Initialized
INFO - 2021-12-11 05:23:10 --> Language Class Initialized
INFO - 2021-12-11 05:23:10 --> Config Class Initialized
INFO - 2021-12-11 05:23:10 --> Loader Class Initialized
INFO - 2021-12-11 05:23:10 --> Helper loaded: url_helper
INFO - 2021-12-11 05:23:10 --> Helper loaded: file_helper
INFO - 2021-12-11 05:23:10 --> Helper loaded: form_helper
INFO - 2021-12-11 05:23:10 --> Helper loaded: my_helper
INFO - 2021-12-11 05:23:10 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:23:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:23:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:23:10 --> Controller Class Initialized
DEBUG - 2021-12-11 05:23:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:23:10 --> Final output sent to browser
DEBUG - 2021-12-11 05:23:10 --> Total execution time: 0.0530
INFO - 2021-12-11 05:23:13 --> Config Class Initialized
INFO - 2021-12-11 05:23:13 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:23:13 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:23:13 --> Utf8 Class Initialized
INFO - 2021-12-11 05:23:13 --> URI Class Initialized
INFO - 2021-12-11 05:23:13 --> Router Class Initialized
INFO - 2021-12-11 05:23:13 --> Output Class Initialized
INFO - 2021-12-11 05:23:13 --> Security Class Initialized
DEBUG - 2021-12-11 05:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:23:13 --> Input Class Initialized
INFO - 2021-12-11 05:23:13 --> Language Class Initialized
INFO - 2021-12-11 05:23:13 --> Language Class Initialized
INFO - 2021-12-11 05:23:13 --> Config Class Initialized
INFO - 2021-12-11 05:23:13 --> Loader Class Initialized
INFO - 2021-12-11 05:23:13 --> Helper loaded: url_helper
INFO - 2021-12-11 05:23:13 --> Helper loaded: file_helper
INFO - 2021-12-11 05:23:13 --> Helper loaded: form_helper
INFO - 2021-12-11 05:23:13 --> Helper loaded: my_helper
INFO - 2021-12-11 05:23:13 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:23:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:23:13 --> Controller Class Initialized
DEBUG - 2021-12-11 05:23:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:23:13 --> Final output sent to browser
DEBUG - 2021-12-11 05:23:13 --> Total execution time: 0.0680
INFO - 2021-12-11 05:23:14 --> Config Class Initialized
INFO - 2021-12-11 05:23:14 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:23:14 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:23:14 --> Utf8 Class Initialized
INFO - 2021-12-11 05:23:14 --> URI Class Initialized
INFO - 2021-12-11 05:23:14 --> Router Class Initialized
INFO - 2021-12-11 05:23:14 --> Output Class Initialized
INFO - 2021-12-11 05:23:14 --> Security Class Initialized
DEBUG - 2021-12-11 05:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:23:14 --> Input Class Initialized
INFO - 2021-12-11 05:23:14 --> Language Class Initialized
INFO - 2021-12-11 05:23:14 --> Language Class Initialized
INFO - 2021-12-11 05:23:14 --> Config Class Initialized
INFO - 2021-12-11 05:23:14 --> Loader Class Initialized
INFO - 2021-12-11 05:23:14 --> Helper loaded: url_helper
INFO - 2021-12-11 05:23:14 --> Helper loaded: file_helper
INFO - 2021-12-11 05:23:14 --> Helper loaded: form_helper
INFO - 2021-12-11 05:23:14 --> Helper loaded: my_helper
INFO - 2021-12-11 05:23:14 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:23:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:23:14 --> Controller Class Initialized
DEBUG - 2021-12-11 05:23:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:23:14 --> Final output sent to browser
DEBUG - 2021-12-11 05:23:14 --> Total execution time: 0.0610
INFO - 2021-12-11 05:23:17 --> Config Class Initialized
INFO - 2021-12-11 05:23:17 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:23:17 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:23:17 --> Utf8 Class Initialized
INFO - 2021-12-11 05:23:17 --> URI Class Initialized
INFO - 2021-12-11 05:23:17 --> Router Class Initialized
INFO - 2021-12-11 05:23:17 --> Output Class Initialized
INFO - 2021-12-11 05:23:17 --> Security Class Initialized
DEBUG - 2021-12-11 05:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:23:17 --> Input Class Initialized
INFO - 2021-12-11 05:23:17 --> Language Class Initialized
INFO - 2021-12-11 05:23:17 --> Language Class Initialized
INFO - 2021-12-11 05:23:17 --> Config Class Initialized
INFO - 2021-12-11 05:23:17 --> Loader Class Initialized
INFO - 2021-12-11 05:23:17 --> Helper loaded: url_helper
INFO - 2021-12-11 05:23:17 --> Helper loaded: file_helper
INFO - 2021-12-11 05:23:17 --> Helper loaded: form_helper
INFO - 2021-12-11 05:23:17 --> Helper loaded: my_helper
INFO - 2021-12-11 05:23:17 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:23:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:23:17 --> Controller Class Initialized
DEBUG - 2021-12-11 05:23:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:23:17 --> Final output sent to browser
DEBUG - 2021-12-11 05:23:17 --> Total execution time: 0.0600
INFO - 2021-12-11 05:23:18 --> Config Class Initialized
INFO - 2021-12-11 05:23:18 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:23:18 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:23:18 --> Utf8 Class Initialized
INFO - 2021-12-11 05:23:18 --> URI Class Initialized
INFO - 2021-12-11 05:23:18 --> Router Class Initialized
INFO - 2021-12-11 05:23:18 --> Output Class Initialized
INFO - 2021-12-11 05:23:18 --> Security Class Initialized
DEBUG - 2021-12-11 05:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:23:18 --> Input Class Initialized
INFO - 2021-12-11 05:23:18 --> Language Class Initialized
INFO - 2021-12-11 05:23:18 --> Language Class Initialized
INFO - 2021-12-11 05:23:18 --> Config Class Initialized
INFO - 2021-12-11 05:23:18 --> Loader Class Initialized
INFO - 2021-12-11 05:23:18 --> Helper loaded: url_helper
INFO - 2021-12-11 05:23:18 --> Helper loaded: file_helper
INFO - 2021-12-11 05:23:18 --> Helper loaded: form_helper
INFO - 2021-12-11 05:23:18 --> Helper loaded: my_helper
INFO - 2021-12-11 05:23:18 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:23:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:23:18 --> Controller Class Initialized
DEBUG - 2021-12-11 05:23:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:23:18 --> Final output sent to browser
DEBUG - 2021-12-11 05:23:18 --> Total execution time: 0.0670
INFO - 2021-12-11 05:23:20 --> Config Class Initialized
INFO - 2021-12-11 05:23:20 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:23:20 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:23:20 --> Utf8 Class Initialized
INFO - 2021-12-11 05:23:20 --> URI Class Initialized
INFO - 2021-12-11 05:23:20 --> Router Class Initialized
INFO - 2021-12-11 05:23:20 --> Output Class Initialized
INFO - 2021-12-11 05:23:20 --> Security Class Initialized
DEBUG - 2021-12-11 05:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:23:20 --> Input Class Initialized
INFO - 2021-12-11 05:23:20 --> Language Class Initialized
INFO - 2021-12-11 05:23:20 --> Language Class Initialized
INFO - 2021-12-11 05:23:20 --> Config Class Initialized
INFO - 2021-12-11 05:23:20 --> Loader Class Initialized
INFO - 2021-12-11 05:23:20 --> Helper loaded: url_helper
INFO - 2021-12-11 05:23:20 --> Helper loaded: file_helper
INFO - 2021-12-11 05:23:20 --> Helper loaded: form_helper
INFO - 2021-12-11 05:23:20 --> Helper loaded: my_helper
INFO - 2021-12-11 05:23:20 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:23:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:23:20 --> Controller Class Initialized
DEBUG - 2021-12-11 05:23:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:23:20 --> Final output sent to browser
DEBUG - 2021-12-11 05:23:20 --> Total execution time: 0.0670
INFO - 2021-12-11 05:23:23 --> Config Class Initialized
INFO - 2021-12-11 05:23:23 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:23:23 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:23:23 --> Utf8 Class Initialized
INFO - 2021-12-11 05:23:23 --> URI Class Initialized
INFO - 2021-12-11 05:23:23 --> Router Class Initialized
INFO - 2021-12-11 05:23:23 --> Output Class Initialized
INFO - 2021-12-11 05:23:23 --> Security Class Initialized
DEBUG - 2021-12-11 05:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:23:23 --> Input Class Initialized
INFO - 2021-12-11 05:23:23 --> Language Class Initialized
INFO - 2021-12-11 05:23:23 --> Language Class Initialized
INFO - 2021-12-11 05:23:23 --> Config Class Initialized
INFO - 2021-12-11 05:23:23 --> Loader Class Initialized
INFO - 2021-12-11 05:23:23 --> Helper loaded: url_helper
INFO - 2021-12-11 05:23:23 --> Helper loaded: file_helper
INFO - 2021-12-11 05:23:23 --> Helper loaded: form_helper
INFO - 2021-12-11 05:23:23 --> Helper loaded: my_helper
INFO - 2021-12-11 05:23:23 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:23:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:23:23 --> Controller Class Initialized
DEBUG - 2021-12-11 05:23:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:23:23 --> Final output sent to browser
DEBUG - 2021-12-11 05:23:23 --> Total execution time: 0.0690
INFO - 2021-12-11 05:23:25 --> Config Class Initialized
INFO - 2021-12-11 05:23:25 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:23:25 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:23:25 --> Utf8 Class Initialized
INFO - 2021-12-11 05:23:25 --> URI Class Initialized
INFO - 2021-12-11 05:23:25 --> Router Class Initialized
INFO - 2021-12-11 05:23:25 --> Output Class Initialized
INFO - 2021-12-11 05:23:25 --> Security Class Initialized
DEBUG - 2021-12-11 05:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:23:25 --> Input Class Initialized
INFO - 2021-12-11 05:23:25 --> Language Class Initialized
INFO - 2021-12-11 05:23:25 --> Language Class Initialized
INFO - 2021-12-11 05:23:25 --> Config Class Initialized
INFO - 2021-12-11 05:23:25 --> Loader Class Initialized
INFO - 2021-12-11 05:23:25 --> Helper loaded: url_helper
INFO - 2021-12-11 05:23:25 --> Helper loaded: file_helper
INFO - 2021-12-11 05:23:25 --> Helper loaded: form_helper
INFO - 2021-12-11 05:23:25 --> Helper loaded: my_helper
INFO - 2021-12-11 05:23:25 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:23:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:23:25 --> Controller Class Initialized
DEBUG - 2021-12-11 05:23:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:23:25 --> Final output sent to browser
DEBUG - 2021-12-11 05:23:25 --> Total execution time: 0.0810
INFO - 2021-12-11 05:23:28 --> Config Class Initialized
INFO - 2021-12-11 05:23:28 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:23:28 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:23:28 --> Utf8 Class Initialized
INFO - 2021-12-11 05:23:28 --> URI Class Initialized
INFO - 2021-12-11 05:23:28 --> Router Class Initialized
INFO - 2021-12-11 05:23:28 --> Output Class Initialized
INFO - 2021-12-11 05:23:28 --> Security Class Initialized
DEBUG - 2021-12-11 05:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:23:28 --> Input Class Initialized
INFO - 2021-12-11 05:23:28 --> Language Class Initialized
INFO - 2021-12-11 05:23:28 --> Language Class Initialized
INFO - 2021-12-11 05:23:28 --> Config Class Initialized
INFO - 2021-12-11 05:23:28 --> Loader Class Initialized
INFO - 2021-12-11 05:23:28 --> Helper loaded: url_helper
INFO - 2021-12-11 05:23:28 --> Helper loaded: file_helper
INFO - 2021-12-11 05:23:28 --> Helper loaded: form_helper
INFO - 2021-12-11 05:23:28 --> Helper loaded: my_helper
INFO - 2021-12-11 05:23:28 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:23:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:23:28 --> Controller Class Initialized
DEBUG - 2021-12-11 05:23:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:23:28 --> Final output sent to browser
DEBUG - 2021-12-11 05:23:28 --> Total execution time: 0.0580
INFO - 2021-12-11 05:23:31 --> Config Class Initialized
INFO - 2021-12-11 05:23:31 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:23:31 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:23:31 --> Utf8 Class Initialized
INFO - 2021-12-11 05:23:31 --> URI Class Initialized
INFO - 2021-12-11 05:23:31 --> Router Class Initialized
INFO - 2021-12-11 05:23:31 --> Output Class Initialized
INFO - 2021-12-11 05:23:31 --> Security Class Initialized
DEBUG - 2021-12-11 05:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:23:31 --> Input Class Initialized
INFO - 2021-12-11 05:23:31 --> Language Class Initialized
INFO - 2021-12-11 05:23:31 --> Language Class Initialized
INFO - 2021-12-11 05:23:31 --> Config Class Initialized
INFO - 2021-12-11 05:23:31 --> Loader Class Initialized
INFO - 2021-12-11 05:23:31 --> Helper loaded: url_helper
INFO - 2021-12-11 05:23:31 --> Helper loaded: file_helper
INFO - 2021-12-11 05:23:31 --> Helper loaded: form_helper
INFO - 2021-12-11 05:23:31 --> Helper loaded: my_helper
INFO - 2021-12-11 05:23:31 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:23:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:23:31 --> Controller Class Initialized
DEBUG - 2021-12-11 05:23:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:23:31 --> Final output sent to browser
DEBUG - 2021-12-11 05:23:31 --> Total execution time: 0.0660
INFO - 2021-12-11 05:23:33 --> Config Class Initialized
INFO - 2021-12-11 05:23:33 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:23:33 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:23:33 --> Utf8 Class Initialized
INFO - 2021-12-11 05:23:33 --> URI Class Initialized
INFO - 2021-12-11 05:23:33 --> Router Class Initialized
INFO - 2021-12-11 05:23:33 --> Output Class Initialized
INFO - 2021-12-11 05:23:33 --> Security Class Initialized
DEBUG - 2021-12-11 05:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:23:33 --> Input Class Initialized
INFO - 2021-12-11 05:23:33 --> Language Class Initialized
INFO - 2021-12-11 05:23:33 --> Language Class Initialized
INFO - 2021-12-11 05:23:33 --> Config Class Initialized
INFO - 2021-12-11 05:23:33 --> Loader Class Initialized
INFO - 2021-12-11 05:23:33 --> Helper loaded: url_helper
INFO - 2021-12-11 05:23:33 --> Helper loaded: file_helper
INFO - 2021-12-11 05:23:33 --> Helper loaded: form_helper
INFO - 2021-12-11 05:23:33 --> Helper loaded: my_helper
INFO - 2021-12-11 05:23:33 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:23:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:23:33 --> Controller Class Initialized
DEBUG - 2021-12-11 05:23:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:23:33 --> Final output sent to browser
DEBUG - 2021-12-11 05:23:33 --> Total execution time: 0.0660
INFO - 2021-12-11 05:23:35 --> Config Class Initialized
INFO - 2021-12-11 05:23:35 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:23:35 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:23:35 --> Utf8 Class Initialized
INFO - 2021-12-11 05:23:35 --> URI Class Initialized
INFO - 2021-12-11 05:23:35 --> Router Class Initialized
INFO - 2021-12-11 05:23:35 --> Output Class Initialized
INFO - 2021-12-11 05:23:35 --> Security Class Initialized
DEBUG - 2021-12-11 05:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:23:35 --> Input Class Initialized
INFO - 2021-12-11 05:23:35 --> Language Class Initialized
INFO - 2021-12-11 05:23:35 --> Language Class Initialized
INFO - 2021-12-11 05:23:35 --> Config Class Initialized
INFO - 2021-12-11 05:23:35 --> Loader Class Initialized
INFO - 2021-12-11 05:23:35 --> Helper loaded: url_helper
INFO - 2021-12-11 05:23:35 --> Helper loaded: file_helper
INFO - 2021-12-11 05:23:35 --> Helper loaded: form_helper
INFO - 2021-12-11 05:23:35 --> Helper loaded: my_helper
INFO - 2021-12-11 05:23:35 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:23:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:23:35 --> Controller Class Initialized
DEBUG - 2021-12-11 05:23:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:23:35 --> Final output sent to browser
DEBUG - 2021-12-11 05:23:35 --> Total execution time: 0.0630
INFO - 2021-12-11 05:23:39 --> Config Class Initialized
INFO - 2021-12-11 05:23:39 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:23:39 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:23:39 --> Utf8 Class Initialized
INFO - 2021-12-11 05:23:39 --> URI Class Initialized
INFO - 2021-12-11 05:23:39 --> Router Class Initialized
INFO - 2021-12-11 05:23:39 --> Output Class Initialized
INFO - 2021-12-11 05:23:39 --> Security Class Initialized
DEBUG - 2021-12-11 05:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:23:39 --> Input Class Initialized
INFO - 2021-12-11 05:23:39 --> Language Class Initialized
INFO - 2021-12-11 05:23:39 --> Language Class Initialized
INFO - 2021-12-11 05:23:39 --> Config Class Initialized
INFO - 2021-12-11 05:23:39 --> Loader Class Initialized
INFO - 2021-12-11 05:23:39 --> Helper loaded: url_helper
INFO - 2021-12-11 05:23:39 --> Helper loaded: file_helper
INFO - 2021-12-11 05:23:39 --> Helper loaded: form_helper
INFO - 2021-12-11 05:23:39 --> Helper loaded: my_helper
INFO - 2021-12-11 05:23:39 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:23:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:23:39 --> Controller Class Initialized
DEBUG - 2021-12-11 05:23:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:23:39 --> Final output sent to browser
DEBUG - 2021-12-11 05:23:39 --> Total execution time: 0.0670
INFO - 2021-12-11 05:23:41 --> Config Class Initialized
INFO - 2021-12-11 05:23:41 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:23:41 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:23:41 --> Utf8 Class Initialized
INFO - 2021-12-11 05:23:41 --> URI Class Initialized
INFO - 2021-12-11 05:23:41 --> Router Class Initialized
INFO - 2021-12-11 05:23:41 --> Output Class Initialized
INFO - 2021-12-11 05:23:41 --> Security Class Initialized
DEBUG - 2021-12-11 05:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:23:41 --> Input Class Initialized
INFO - 2021-12-11 05:23:41 --> Language Class Initialized
INFO - 2021-12-11 05:23:41 --> Language Class Initialized
INFO - 2021-12-11 05:23:41 --> Config Class Initialized
INFO - 2021-12-11 05:23:41 --> Loader Class Initialized
INFO - 2021-12-11 05:23:41 --> Helper loaded: url_helper
INFO - 2021-12-11 05:23:41 --> Helper loaded: file_helper
INFO - 2021-12-11 05:23:41 --> Helper loaded: form_helper
INFO - 2021-12-11 05:23:41 --> Helper loaded: my_helper
INFO - 2021-12-11 05:23:41 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:23:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:23:41 --> Controller Class Initialized
DEBUG - 2021-12-11 05:23:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:23:41 --> Final output sent to browser
DEBUG - 2021-12-11 05:23:41 --> Total execution time: 0.0610
INFO - 2021-12-11 05:23:44 --> Config Class Initialized
INFO - 2021-12-11 05:23:44 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:23:44 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:23:44 --> Utf8 Class Initialized
INFO - 2021-12-11 05:23:44 --> URI Class Initialized
INFO - 2021-12-11 05:23:44 --> Router Class Initialized
INFO - 2021-12-11 05:23:44 --> Output Class Initialized
INFO - 2021-12-11 05:23:44 --> Security Class Initialized
DEBUG - 2021-12-11 05:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:23:44 --> Input Class Initialized
INFO - 2021-12-11 05:23:44 --> Language Class Initialized
INFO - 2021-12-11 05:23:44 --> Language Class Initialized
INFO - 2021-12-11 05:23:44 --> Config Class Initialized
INFO - 2021-12-11 05:23:44 --> Loader Class Initialized
INFO - 2021-12-11 05:23:44 --> Helper loaded: url_helper
INFO - 2021-12-11 05:23:44 --> Helper loaded: file_helper
INFO - 2021-12-11 05:23:44 --> Helper loaded: form_helper
INFO - 2021-12-11 05:23:44 --> Helper loaded: my_helper
INFO - 2021-12-11 05:23:44 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:23:44 --> Controller Class Initialized
DEBUG - 2021-12-11 05:23:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:23:44 --> Final output sent to browser
DEBUG - 2021-12-11 05:23:44 --> Total execution time: 0.0660
INFO - 2021-12-11 05:23:46 --> Config Class Initialized
INFO - 2021-12-11 05:23:46 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:23:46 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:23:46 --> Utf8 Class Initialized
INFO - 2021-12-11 05:23:46 --> URI Class Initialized
INFO - 2021-12-11 05:23:46 --> Router Class Initialized
INFO - 2021-12-11 05:23:46 --> Output Class Initialized
INFO - 2021-12-11 05:23:46 --> Security Class Initialized
DEBUG - 2021-12-11 05:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:23:46 --> Input Class Initialized
INFO - 2021-12-11 05:23:46 --> Language Class Initialized
INFO - 2021-12-11 05:23:46 --> Language Class Initialized
INFO - 2021-12-11 05:23:46 --> Config Class Initialized
INFO - 2021-12-11 05:23:46 --> Loader Class Initialized
INFO - 2021-12-11 05:23:46 --> Helper loaded: url_helper
INFO - 2021-12-11 05:23:46 --> Helper loaded: file_helper
INFO - 2021-12-11 05:23:46 --> Helper loaded: form_helper
INFO - 2021-12-11 05:23:46 --> Helper loaded: my_helper
INFO - 2021-12-11 05:23:46 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:23:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:23:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:23:46 --> Controller Class Initialized
DEBUG - 2021-12-11 05:23:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:23:46 --> Final output sent to browser
DEBUG - 2021-12-11 05:23:46 --> Total execution time: 0.0630
INFO - 2021-12-11 05:23:48 --> Config Class Initialized
INFO - 2021-12-11 05:23:48 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:23:48 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:23:48 --> Utf8 Class Initialized
INFO - 2021-12-11 05:23:48 --> URI Class Initialized
INFO - 2021-12-11 05:23:48 --> Router Class Initialized
INFO - 2021-12-11 05:23:48 --> Output Class Initialized
INFO - 2021-12-11 05:23:48 --> Security Class Initialized
DEBUG - 2021-12-11 05:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:23:48 --> Input Class Initialized
INFO - 2021-12-11 05:23:48 --> Language Class Initialized
INFO - 2021-12-11 05:23:48 --> Language Class Initialized
INFO - 2021-12-11 05:23:48 --> Config Class Initialized
INFO - 2021-12-11 05:23:48 --> Loader Class Initialized
INFO - 2021-12-11 05:23:48 --> Helper loaded: url_helper
INFO - 2021-12-11 05:23:48 --> Helper loaded: file_helper
INFO - 2021-12-11 05:23:48 --> Helper loaded: form_helper
INFO - 2021-12-11 05:23:48 --> Helper loaded: my_helper
INFO - 2021-12-11 05:23:48 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:23:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:23:48 --> Controller Class Initialized
DEBUG - 2021-12-11 05:23:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:23:48 --> Final output sent to browser
DEBUG - 2021-12-11 05:23:48 --> Total execution time: 0.0610
INFO - 2021-12-11 05:23:50 --> Config Class Initialized
INFO - 2021-12-11 05:23:50 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:23:50 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:23:50 --> Utf8 Class Initialized
INFO - 2021-12-11 05:23:50 --> URI Class Initialized
INFO - 2021-12-11 05:23:50 --> Router Class Initialized
INFO - 2021-12-11 05:23:50 --> Output Class Initialized
INFO - 2021-12-11 05:23:50 --> Security Class Initialized
DEBUG - 2021-12-11 05:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:23:50 --> Input Class Initialized
INFO - 2021-12-11 05:23:50 --> Language Class Initialized
INFO - 2021-12-11 05:23:50 --> Language Class Initialized
INFO - 2021-12-11 05:23:50 --> Config Class Initialized
INFO - 2021-12-11 05:23:50 --> Loader Class Initialized
INFO - 2021-12-11 05:23:50 --> Helper loaded: url_helper
INFO - 2021-12-11 05:23:50 --> Helper loaded: file_helper
INFO - 2021-12-11 05:23:50 --> Helper loaded: form_helper
INFO - 2021-12-11 05:23:50 --> Helper loaded: my_helper
INFO - 2021-12-11 05:23:50 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:23:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:23:50 --> Controller Class Initialized
DEBUG - 2021-12-11 05:23:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:23:50 --> Final output sent to browser
DEBUG - 2021-12-11 05:23:50 --> Total execution time: 0.0630
INFO - 2021-12-11 05:23:52 --> Config Class Initialized
INFO - 2021-12-11 05:23:52 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:23:52 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:23:52 --> Utf8 Class Initialized
INFO - 2021-12-11 05:23:52 --> URI Class Initialized
INFO - 2021-12-11 05:23:52 --> Router Class Initialized
INFO - 2021-12-11 05:23:52 --> Output Class Initialized
INFO - 2021-12-11 05:23:52 --> Security Class Initialized
DEBUG - 2021-12-11 05:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:23:52 --> Input Class Initialized
INFO - 2021-12-11 05:23:52 --> Language Class Initialized
INFO - 2021-12-11 05:23:52 --> Language Class Initialized
INFO - 2021-12-11 05:23:52 --> Config Class Initialized
INFO - 2021-12-11 05:23:52 --> Loader Class Initialized
INFO - 2021-12-11 05:23:52 --> Helper loaded: url_helper
INFO - 2021-12-11 05:23:52 --> Helper loaded: file_helper
INFO - 2021-12-11 05:23:52 --> Helper loaded: form_helper
INFO - 2021-12-11 05:23:52 --> Helper loaded: my_helper
INFO - 2021-12-11 05:23:52 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:23:52 --> Controller Class Initialized
DEBUG - 2021-12-11 05:23:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:23:52 --> Final output sent to browser
DEBUG - 2021-12-11 05:23:52 --> Total execution time: 0.0690
INFO - 2021-12-11 05:28:35 --> Config Class Initialized
INFO - 2021-12-11 05:28:35 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:28:35 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:28:35 --> Utf8 Class Initialized
INFO - 2021-12-11 05:28:35 --> URI Class Initialized
INFO - 2021-12-11 05:28:35 --> Router Class Initialized
INFO - 2021-12-11 05:28:35 --> Output Class Initialized
INFO - 2021-12-11 05:28:35 --> Security Class Initialized
DEBUG - 2021-12-11 05:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:28:35 --> Input Class Initialized
INFO - 2021-12-11 05:28:35 --> Language Class Initialized
INFO - 2021-12-11 05:28:35 --> Language Class Initialized
INFO - 2021-12-11 05:28:35 --> Config Class Initialized
INFO - 2021-12-11 05:28:35 --> Loader Class Initialized
INFO - 2021-12-11 05:28:35 --> Helper loaded: url_helper
INFO - 2021-12-11 05:28:35 --> Helper loaded: file_helper
INFO - 2021-12-11 05:28:35 --> Helper loaded: form_helper
INFO - 2021-12-11 05:28:35 --> Helper loaded: my_helper
INFO - 2021-12-11 05:28:35 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:28:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:28:35 --> Controller Class Initialized
INFO - 2021-12-11 05:28:35 --> Helper loaded: cookie_helper
INFO - 2021-12-11 05:28:35 --> Config Class Initialized
INFO - 2021-12-11 05:28:35 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:28:35 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:28:35 --> Utf8 Class Initialized
INFO - 2021-12-11 05:28:35 --> URI Class Initialized
INFO - 2021-12-11 05:28:35 --> Router Class Initialized
INFO - 2021-12-11 05:28:35 --> Output Class Initialized
INFO - 2021-12-11 05:28:35 --> Security Class Initialized
DEBUG - 2021-12-11 05:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:28:35 --> Input Class Initialized
INFO - 2021-12-11 05:28:35 --> Language Class Initialized
INFO - 2021-12-11 05:28:35 --> Language Class Initialized
INFO - 2021-12-11 05:28:35 --> Config Class Initialized
INFO - 2021-12-11 05:28:35 --> Loader Class Initialized
INFO - 2021-12-11 05:28:35 --> Helper loaded: url_helper
INFO - 2021-12-11 05:28:35 --> Helper loaded: file_helper
INFO - 2021-12-11 05:28:35 --> Helper loaded: form_helper
INFO - 2021-12-11 05:28:35 --> Helper loaded: my_helper
INFO - 2021-12-11 05:28:35 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:28:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:28:35 --> Controller Class Initialized
DEBUG - 2021-12-11 05:28:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-11 05:28:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-11 05:28:35 --> Final output sent to browser
DEBUG - 2021-12-11 05:28:35 --> Total execution time: 0.0390
INFO - 2021-12-11 05:28:41 --> Config Class Initialized
INFO - 2021-12-11 05:28:41 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:28:41 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:28:41 --> Utf8 Class Initialized
INFO - 2021-12-11 05:28:41 --> URI Class Initialized
INFO - 2021-12-11 05:28:41 --> Router Class Initialized
INFO - 2021-12-11 05:28:41 --> Output Class Initialized
INFO - 2021-12-11 05:28:41 --> Security Class Initialized
DEBUG - 2021-12-11 05:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:28:41 --> Input Class Initialized
INFO - 2021-12-11 05:28:41 --> Language Class Initialized
INFO - 2021-12-11 05:28:41 --> Language Class Initialized
INFO - 2021-12-11 05:28:41 --> Config Class Initialized
INFO - 2021-12-11 05:28:41 --> Loader Class Initialized
INFO - 2021-12-11 05:28:41 --> Helper loaded: url_helper
INFO - 2021-12-11 05:28:41 --> Helper loaded: file_helper
INFO - 2021-12-11 05:28:41 --> Helper loaded: form_helper
INFO - 2021-12-11 05:28:41 --> Helper loaded: my_helper
INFO - 2021-12-11 05:28:41 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:28:41 --> Controller Class Initialized
INFO - 2021-12-11 05:28:41 --> Helper loaded: cookie_helper
INFO - 2021-12-11 05:28:41 --> Final output sent to browser
DEBUG - 2021-12-11 05:28:41 --> Total execution time: 0.0590
INFO - 2021-12-11 05:28:41 --> Config Class Initialized
INFO - 2021-12-11 05:28:41 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:28:41 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:28:41 --> Utf8 Class Initialized
INFO - 2021-12-11 05:28:41 --> URI Class Initialized
INFO - 2021-12-11 05:28:41 --> Router Class Initialized
INFO - 2021-12-11 05:28:41 --> Output Class Initialized
INFO - 2021-12-11 05:28:41 --> Security Class Initialized
DEBUG - 2021-12-11 05:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:28:41 --> Input Class Initialized
INFO - 2021-12-11 05:28:41 --> Language Class Initialized
INFO - 2021-12-11 05:28:41 --> Language Class Initialized
INFO - 2021-12-11 05:28:41 --> Config Class Initialized
INFO - 2021-12-11 05:28:41 --> Loader Class Initialized
INFO - 2021-12-11 05:28:41 --> Helper loaded: url_helper
INFO - 2021-12-11 05:28:41 --> Helper loaded: file_helper
INFO - 2021-12-11 05:28:41 --> Helper loaded: form_helper
INFO - 2021-12-11 05:28:41 --> Helper loaded: my_helper
INFO - 2021-12-11 05:28:41 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:28:41 --> Controller Class Initialized
DEBUG - 2021-12-11 05:28:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-11 05:28:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-11 05:28:41 --> Final output sent to browser
DEBUG - 2021-12-11 05:28:41 --> Total execution time: 0.2220
INFO - 2021-12-11 05:28:42 --> Config Class Initialized
INFO - 2021-12-11 05:28:42 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:28:42 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:28:42 --> Utf8 Class Initialized
INFO - 2021-12-11 05:28:42 --> URI Class Initialized
INFO - 2021-12-11 05:28:42 --> Router Class Initialized
INFO - 2021-12-11 05:28:42 --> Output Class Initialized
INFO - 2021-12-11 05:28:42 --> Security Class Initialized
DEBUG - 2021-12-11 05:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:28:42 --> Input Class Initialized
INFO - 2021-12-11 05:28:42 --> Language Class Initialized
INFO - 2021-12-11 05:28:42 --> Language Class Initialized
INFO - 2021-12-11 05:28:42 --> Config Class Initialized
INFO - 2021-12-11 05:28:42 --> Loader Class Initialized
INFO - 2021-12-11 05:28:42 --> Helper loaded: url_helper
INFO - 2021-12-11 05:28:42 --> Helper loaded: file_helper
INFO - 2021-12-11 05:28:42 --> Helper loaded: form_helper
INFO - 2021-12-11 05:28:42 --> Helper loaded: my_helper
INFO - 2021-12-11 05:28:42 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:28:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:28:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:28:42 --> Controller Class Initialized
DEBUG - 2021-12-11 05:28:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-11 05:28:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-11 05:28:42 --> Final output sent to browser
DEBUG - 2021-12-11 05:28:42 --> Total execution time: 0.0570
INFO - 2021-12-11 05:28:49 --> Config Class Initialized
INFO - 2021-12-11 05:28:49 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:28:49 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:28:49 --> Utf8 Class Initialized
INFO - 2021-12-11 05:28:49 --> URI Class Initialized
INFO - 2021-12-11 05:28:49 --> Router Class Initialized
INFO - 2021-12-11 05:28:49 --> Output Class Initialized
INFO - 2021-12-11 05:28:49 --> Security Class Initialized
DEBUG - 2021-12-11 05:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:28:49 --> Input Class Initialized
INFO - 2021-12-11 05:28:49 --> Language Class Initialized
INFO - 2021-12-11 05:28:49 --> Language Class Initialized
INFO - 2021-12-11 05:28:49 --> Config Class Initialized
INFO - 2021-12-11 05:28:49 --> Loader Class Initialized
INFO - 2021-12-11 05:28:49 --> Helper loaded: url_helper
INFO - 2021-12-11 05:28:49 --> Helper loaded: file_helper
INFO - 2021-12-11 05:28:49 --> Helper loaded: form_helper
INFO - 2021-12-11 05:28:49 --> Helper loaded: my_helper
INFO - 2021-12-11 05:28:49 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:28:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:28:49 --> Controller Class Initialized
DEBUG - 2021-12-11 05:28:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:28:49 --> Final output sent to browser
DEBUG - 2021-12-11 05:28:49 --> Total execution time: 0.1160
INFO - 2021-12-11 05:28:51 --> Config Class Initialized
INFO - 2021-12-11 05:28:51 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:28:51 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:28:51 --> Utf8 Class Initialized
INFO - 2021-12-11 05:28:51 --> URI Class Initialized
INFO - 2021-12-11 05:28:51 --> Router Class Initialized
INFO - 2021-12-11 05:28:51 --> Output Class Initialized
INFO - 2021-12-11 05:28:51 --> Security Class Initialized
DEBUG - 2021-12-11 05:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:28:51 --> Input Class Initialized
INFO - 2021-12-11 05:28:51 --> Language Class Initialized
INFO - 2021-12-11 05:28:51 --> Language Class Initialized
INFO - 2021-12-11 05:28:51 --> Config Class Initialized
INFO - 2021-12-11 05:28:51 --> Loader Class Initialized
INFO - 2021-12-11 05:28:51 --> Helper loaded: url_helper
INFO - 2021-12-11 05:28:51 --> Helper loaded: file_helper
INFO - 2021-12-11 05:28:51 --> Helper loaded: form_helper
INFO - 2021-12-11 05:28:51 --> Helper loaded: my_helper
INFO - 2021-12-11 05:28:51 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:28:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:28:51 --> Controller Class Initialized
DEBUG - 2021-12-11 05:28:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:28:51 --> Final output sent to browser
DEBUG - 2021-12-11 05:28:51 --> Total execution time: 0.0550
INFO - 2021-12-11 05:28:52 --> Config Class Initialized
INFO - 2021-12-11 05:28:52 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:28:52 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:28:52 --> Utf8 Class Initialized
INFO - 2021-12-11 05:28:52 --> URI Class Initialized
INFO - 2021-12-11 05:28:52 --> Router Class Initialized
INFO - 2021-12-11 05:28:52 --> Output Class Initialized
INFO - 2021-12-11 05:28:52 --> Security Class Initialized
DEBUG - 2021-12-11 05:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:28:52 --> Input Class Initialized
INFO - 2021-12-11 05:28:52 --> Language Class Initialized
INFO - 2021-12-11 05:28:52 --> Language Class Initialized
INFO - 2021-12-11 05:28:52 --> Config Class Initialized
INFO - 2021-12-11 05:28:52 --> Loader Class Initialized
INFO - 2021-12-11 05:28:52 --> Helper loaded: url_helper
INFO - 2021-12-11 05:28:52 --> Helper loaded: file_helper
INFO - 2021-12-11 05:28:52 --> Helper loaded: form_helper
INFO - 2021-12-11 05:28:52 --> Helper loaded: my_helper
INFO - 2021-12-11 05:28:52 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:28:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:28:52 --> Controller Class Initialized
DEBUG - 2021-12-11 05:28:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:28:52 --> Final output sent to browser
DEBUG - 2021-12-11 05:28:52 --> Total execution time: 0.0690
INFO - 2021-12-11 05:28:55 --> Config Class Initialized
INFO - 2021-12-11 05:28:55 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:28:55 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:28:55 --> Utf8 Class Initialized
INFO - 2021-12-11 05:28:55 --> URI Class Initialized
INFO - 2021-12-11 05:28:55 --> Router Class Initialized
INFO - 2021-12-11 05:28:55 --> Output Class Initialized
INFO - 2021-12-11 05:28:55 --> Security Class Initialized
DEBUG - 2021-12-11 05:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:28:55 --> Input Class Initialized
INFO - 2021-12-11 05:28:55 --> Language Class Initialized
INFO - 2021-12-11 05:28:55 --> Language Class Initialized
INFO - 2021-12-11 05:28:55 --> Config Class Initialized
INFO - 2021-12-11 05:28:55 --> Loader Class Initialized
INFO - 2021-12-11 05:28:55 --> Helper loaded: url_helper
INFO - 2021-12-11 05:28:55 --> Helper loaded: file_helper
INFO - 2021-12-11 05:28:55 --> Helper loaded: form_helper
INFO - 2021-12-11 05:28:55 --> Helper loaded: my_helper
INFO - 2021-12-11 05:28:55 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:28:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:28:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:28:55 --> Controller Class Initialized
DEBUG - 2021-12-11 05:28:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:28:55 --> Final output sent to browser
DEBUG - 2021-12-11 05:28:55 --> Total execution time: 0.0610
INFO - 2021-12-11 05:28:57 --> Config Class Initialized
INFO - 2021-12-11 05:28:57 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:28:57 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:28:57 --> Utf8 Class Initialized
INFO - 2021-12-11 05:28:57 --> URI Class Initialized
INFO - 2021-12-11 05:28:57 --> Router Class Initialized
INFO - 2021-12-11 05:28:57 --> Output Class Initialized
INFO - 2021-12-11 05:28:57 --> Security Class Initialized
DEBUG - 2021-12-11 05:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:28:57 --> Input Class Initialized
INFO - 2021-12-11 05:28:57 --> Language Class Initialized
INFO - 2021-12-11 05:28:57 --> Language Class Initialized
INFO - 2021-12-11 05:28:57 --> Config Class Initialized
INFO - 2021-12-11 05:28:57 --> Loader Class Initialized
INFO - 2021-12-11 05:28:57 --> Helper loaded: url_helper
INFO - 2021-12-11 05:28:57 --> Helper loaded: file_helper
INFO - 2021-12-11 05:28:57 --> Helper loaded: form_helper
INFO - 2021-12-11 05:28:57 --> Helper loaded: my_helper
INFO - 2021-12-11 05:28:57 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:28:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:28:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:28:57 --> Controller Class Initialized
DEBUG - 2021-12-11 05:28:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:28:57 --> Final output sent to browser
DEBUG - 2021-12-11 05:28:57 --> Total execution time: 0.0610
INFO - 2021-12-11 05:28:59 --> Config Class Initialized
INFO - 2021-12-11 05:28:59 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:28:59 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:28:59 --> Utf8 Class Initialized
INFO - 2021-12-11 05:28:59 --> URI Class Initialized
INFO - 2021-12-11 05:28:59 --> Router Class Initialized
INFO - 2021-12-11 05:28:59 --> Output Class Initialized
INFO - 2021-12-11 05:28:59 --> Security Class Initialized
DEBUG - 2021-12-11 05:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:28:59 --> Input Class Initialized
INFO - 2021-12-11 05:28:59 --> Language Class Initialized
INFO - 2021-12-11 05:28:59 --> Language Class Initialized
INFO - 2021-12-11 05:28:59 --> Config Class Initialized
INFO - 2021-12-11 05:28:59 --> Loader Class Initialized
INFO - 2021-12-11 05:28:59 --> Helper loaded: url_helper
INFO - 2021-12-11 05:28:59 --> Helper loaded: file_helper
INFO - 2021-12-11 05:28:59 --> Helper loaded: form_helper
INFO - 2021-12-11 05:28:59 --> Helper loaded: my_helper
INFO - 2021-12-11 05:28:59 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:28:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:28:59 --> Controller Class Initialized
DEBUG - 2021-12-11 05:28:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:28:59 --> Final output sent to browser
DEBUG - 2021-12-11 05:28:59 --> Total execution time: 0.0600
INFO - 2021-12-11 05:29:01 --> Config Class Initialized
INFO - 2021-12-11 05:29:01 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:29:01 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:29:01 --> Utf8 Class Initialized
INFO - 2021-12-11 05:29:01 --> URI Class Initialized
INFO - 2021-12-11 05:29:01 --> Router Class Initialized
INFO - 2021-12-11 05:29:01 --> Output Class Initialized
INFO - 2021-12-11 05:29:01 --> Security Class Initialized
DEBUG - 2021-12-11 05:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:29:01 --> Input Class Initialized
INFO - 2021-12-11 05:29:01 --> Language Class Initialized
INFO - 2021-12-11 05:29:01 --> Language Class Initialized
INFO - 2021-12-11 05:29:01 --> Config Class Initialized
INFO - 2021-12-11 05:29:01 --> Loader Class Initialized
INFO - 2021-12-11 05:29:01 --> Helper loaded: url_helper
INFO - 2021-12-11 05:29:01 --> Helper loaded: file_helper
INFO - 2021-12-11 05:29:01 --> Helper loaded: form_helper
INFO - 2021-12-11 05:29:01 --> Helper loaded: my_helper
INFO - 2021-12-11 05:29:01 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:29:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:29:01 --> Controller Class Initialized
DEBUG - 2021-12-11 05:29:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:29:01 --> Final output sent to browser
DEBUG - 2021-12-11 05:29:01 --> Total execution time: 0.0620
INFO - 2021-12-11 05:29:04 --> Config Class Initialized
INFO - 2021-12-11 05:29:04 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:29:04 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:29:04 --> Utf8 Class Initialized
INFO - 2021-12-11 05:29:04 --> URI Class Initialized
INFO - 2021-12-11 05:29:04 --> Router Class Initialized
INFO - 2021-12-11 05:29:04 --> Output Class Initialized
INFO - 2021-12-11 05:29:04 --> Security Class Initialized
DEBUG - 2021-12-11 05:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:29:04 --> Input Class Initialized
INFO - 2021-12-11 05:29:04 --> Language Class Initialized
INFO - 2021-12-11 05:29:04 --> Language Class Initialized
INFO - 2021-12-11 05:29:04 --> Config Class Initialized
INFO - 2021-12-11 05:29:04 --> Loader Class Initialized
INFO - 2021-12-11 05:29:04 --> Helper loaded: url_helper
INFO - 2021-12-11 05:29:04 --> Helper loaded: file_helper
INFO - 2021-12-11 05:29:04 --> Helper loaded: form_helper
INFO - 2021-12-11 05:29:04 --> Helper loaded: my_helper
INFO - 2021-12-11 05:29:04 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:29:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:29:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:29:04 --> Controller Class Initialized
DEBUG - 2021-12-11 05:29:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:29:04 --> Final output sent to browser
DEBUG - 2021-12-11 05:29:04 --> Total execution time: 0.0640
INFO - 2021-12-11 05:29:05 --> Config Class Initialized
INFO - 2021-12-11 05:29:05 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:29:05 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:29:05 --> Utf8 Class Initialized
INFO - 2021-12-11 05:29:05 --> URI Class Initialized
INFO - 2021-12-11 05:29:05 --> Router Class Initialized
INFO - 2021-12-11 05:29:05 --> Output Class Initialized
INFO - 2021-12-11 05:29:05 --> Security Class Initialized
DEBUG - 2021-12-11 05:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:29:05 --> Input Class Initialized
INFO - 2021-12-11 05:29:05 --> Language Class Initialized
INFO - 2021-12-11 05:29:05 --> Language Class Initialized
INFO - 2021-12-11 05:29:05 --> Config Class Initialized
INFO - 2021-12-11 05:29:05 --> Loader Class Initialized
INFO - 2021-12-11 05:29:05 --> Helper loaded: url_helper
INFO - 2021-12-11 05:29:05 --> Helper loaded: file_helper
INFO - 2021-12-11 05:29:05 --> Helper loaded: form_helper
INFO - 2021-12-11 05:29:05 --> Helper loaded: my_helper
INFO - 2021-12-11 05:29:05 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:29:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:29:05 --> Controller Class Initialized
DEBUG - 2021-12-11 05:29:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:29:05 --> Final output sent to browser
DEBUG - 2021-12-11 05:29:05 --> Total execution time: 0.0620
INFO - 2021-12-11 05:29:07 --> Config Class Initialized
INFO - 2021-12-11 05:29:07 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:29:07 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:29:07 --> Utf8 Class Initialized
INFO - 2021-12-11 05:29:07 --> URI Class Initialized
INFO - 2021-12-11 05:29:07 --> Router Class Initialized
INFO - 2021-12-11 05:29:07 --> Output Class Initialized
INFO - 2021-12-11 05:29:07 --> Security Class Initialized
DEBUG - 2021-12-11 05:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:29:07 --> Input Class Initialized
INFO - 2021-12-11 05:29:07 --> Language Class Initialized
INFO - 2021-12-11 05:29:07 --> Language Class Initialized
INFO - 2021-12-11 05:29:07 --> Config Class Initialized
INFO - 2021-12-11 05:29:07 --> Loader Class Initialized
INFO - 2021-12-11 05:29:07 --> Helper loaded: url_helper
INFO - 2021-12-11 05:29:07 --> Helper loaded: file_helper
INFO - 2021-12-11 05:29:07 --> Helper loaded: form_helper
INFO - 2021-12-11 05:29:07 --> Helper loaded: my_helper
INFO - 2021-12-11 05:29:07 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:29:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:29:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:29:07 --> Controller Class Initialized
DEBUG - 2021-12-11 05:29:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:29:07 --> Final output sent to browser
DEBUG - 2021-12-11 05:29:07 --> Total execution time: 0.0670
INFO - 2021-12-11 05:29:09 --> Config Class Initialized
INFO - 2021-12-11 05:29:09 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:29:09 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:29:09 --> Utf8 Class Initialized
INFO - 2021-12-11 05:29:09 --> URI Class Initialized
INFO - 2021-12-11 05:29:09 --> Router Class Initialized
INFO - 2021-12-11 05:29:09 --> Output Class Initialized
INFO - 2021-12-11 05:29:09 --> Security Class Initialized
DEBUG - 2021-12-11 05:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:29:09 --> Input Class Initialized
INFO - 2021-12-11 05:29:09 --> Language Class Initialized
INFO - 2021-12-11 05:29:09 --> Language Class Initialized
INFO - 2021-12-11 05:29:09 --> Config Class Initialized
INFO - 2021-12-11 05:29:09 --> Loader Class Initialized
INFO - 2021-12-11 05:29:09 --> Helper loaded: url_helper
INFO - 2021-12-11 05:29:09 --> Helper loaded: file_helper
INFO - 2021-12-11 05:29:09 --> Helper loaded: form_helper
INFO - 2021-12-11 05:29:09 --> Helper loaded: my_helper
INFO - 2021-12-11 05:29:09 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:29:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:29:09 --> Controller Class Initialized
DEBUG - 2021-12-11 05:29:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:29:09 --> Final output sent to browser
DEBUG - 2021-12-11 05:29:09 --> Total execution time: 0.0640
INFO - 2021-12-11 05:29:10 --> Config Class Initialized
INFO - 2021-12-11 05:29:10 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:29:10 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:29:10 --> Utf8 Class Initialized
INFO - 2021-12-11 05:29:10 --> URI Class Initialized
INFO - 2021-12-11 05:29:10 --> Router Class Initialized
INFO - 2021-12-11 05:29:10 --> Output Class Initialized
INFO - 2021-12-11 05:29:10 --> Security Class Initialized
DEBUG - 2021-12-11 05:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:29:10 --> Input Class Initialized
INFO - 2021-12-11 05:29:10 --> Language Class Initialized
INFO - 2021-12-11 05:29:10 --> Language Class Initialized
INFO - 2021-12-11 05:29:10 --> Config Class Initialized
INFO - 2021-12-11 05:29:10 --> Loader Class Initialized
INFO - 2021-12-11 05:29:10 --> Helper loaded: url_helper
INFO - 2021-12-11 05:29:10 --> Helper loaded: file_helper
INFO - 2021-12-11 05:29:10 --> Helper loaded: form_helper
INFO - 2021-12-11 05:29:10 --> Helper loaded: my_helper
INFO - 2021-12-11 05:29:10 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:29:10 --> Controller Class Initialized
DEBUG - 2021-12-11 05:29:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:29:10 --> Final output sent to browser
DEBUG - 2021-12-11 05:29:10 --> Total execution time: 0.0720
INFO - 2021-12-11 05:29:12 --> Config Class Initialized
INFO - 2021-12-11 05:29:12 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:29:12 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:29:12 --> Utf8 Class Initialized
INFO - 2021-12-11 05:29:12 --> URI Class Initialized
INFO - 2021-12-11 05:29:12 --> Router Class Initialized
INFO - 2021-12-11 05:29:12 --> Output Class Initialized
INFO - 2021-12-11 05:29:12 --> Security Class Initialized
DEBUG - 2021-12-11 05:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:29:12 --> Input Class Initialized
INFO - 2021-12-11 05:29:12 --> Language Class Initialized
INFO - 2021-12-11 05:29:12 --> Language Class Initialized
INFO - 2021-12-11 05:29:12 --> Config Class Initialized
INFO - 2021-12-11 05:29:12 --> Loader Class Initialized
INFO - 2021-12-11 05:29:12 --> Helper loaded: url_helper
INFO - 2021-12-11 05:29:12 --> Helper loaded: file_helper
INFO - 2021-12-11 05:29:12 --> Helper loaded: form_helper
INFO - 2021-12-11 05:29:12 --> Helper loaded: my_helper
INFO - 2021-12-11 05:29:12 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:29:12 --> Controller Class Initialized
DEBUG - 2021-12-11 05:29:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:29:12 --> Final output sent to browser
DEBUG - 2021-12-11 05:29:12 --> Total execution time: 0.0610
INFO - 2021-12-11 05:29:15 --> Config Class Initialized
INFO - 2021-12-11 05:29:15 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:29:15 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:29:15 --> Utf8 Class Initialized
INFO - 2021-12-11 05:29:15 --> URI Class Initialized
INFO - 2021-12-11 05:29:15 --> Router Class Initialized
INFO - 2021-12-11 05:29:15 --> Output Class Initialized
INFO - 2021-12-11 05:29:15 --> Security Class Initialized
DEBUG - 2021-12-11 05:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:29:15 --> Input Class Initialized
INFO - 2021-12-11 05:29:15 --> Language Class Initialized
INFO - 2021-12-11 05:29:15 --> Language Class Initialized
INFO - 2021-12-11 05:29:15 --> Config Class Initialized
INFO - 2021-12-11 05:29:15 --> Loader Class Initialized
INFO - 2021-12-11 05:29:15 --> Helper loaded: url_helper
INFO - 2021-12-11 05:29:15 --> Helper loaded: file_helper
INFO - 2021-12-11 05:29:15 --> Helper loaded: form_helper
INFO - 2021-12-11 05:29:15 --> Helper loaded: my_helper
INFO - 2021-12-11 05:29:15 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:29:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:29:15 --> Controller Class Initialized
DEBUG - 2021-12-11 05:29:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:29:15 --> Final output sent to browser
DEBUG - 2021-12-11 05:29:15 --> Total execution time: 0.0590
INFO - 2021-12-11 05:29:17 --> Config Class Initialized
INFO - 2021-12-11 05:29:17 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:29:17 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:29:17 --> Utf8 Class Initialized
INFO - 2021-12-11 05:29:17 --> URI Class Initialized
INFO - 2021-12-11 05:29:17 --> Router Class Initialized
INFO - 2021-12-11 05:29:17 --> Output Class Initialized
INFO - 2021-12-11 05:29:17 --> Security Class Initialized
DEBUG - 2021-12-11 05:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:29:17 --> Input Class Initialized
INFO - 2021-12-11 05:29:17 --> Language Class Initialized
INFO - 2021-12-11 05:29:17 --> Language Class Initialized
INFO - 2021-12-11 05:29:17 --> Config Class Initialized
INFO - 2021-12-11 05:29:17 --> Loader Class Initialized
INFO - 2021-12-11 05:29:17 --> Helper loaded: url_helper
INFO - 2021-12-11 05:29:17 --> Helper loaded: file_helper
INFO - 2021-12-11 05:29:17 --> Helper loaded: form_helper
INFO - 2021-12-11 05:29:17 --> Helper loaded: my_helper
INFO - 2021-12-11 05:29:17 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:29:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:29:17 --> Controller Class Initialized
DEBUG - 2021-12-11 05:29:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:29:17 --> Final output sent to browser
DEBUG - 2021-12-11 05:29:17 --> Total execution time: 0.0640
INFO - 2021-12-11 05:29:19 --> Config Class Initialized
INFO - 2021-12-11 05:29:19 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:29:19 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:29:19 --> Utf8 Class Initialized
INFO - 2021-12-11 05:29:19 --> URI Class Initialized
INFO - 2021-12-11 05:29:19 --> Router Class Initialized
INFO - 2021-12-11 05:29:19 --> Output Class Initialized
INFO - 2021-12-11 05:29:19 --> Security Class Initialized
DEBUG - 2021-12-11 05:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:29:19 --> Input Class Initialized
INFO - 2021-12-11 05:29:19 --> Language Class Initialized
INFO - 2021-12-11 05:29:19 --> Language Class Initialized
INFO - 2021-12-11 05:29:19 --> Config Class Initialized
INFO - 2021-12-11 05:29:19 --> Loader Class Initialized
INFO - 2021-12-11 05:29:19 --> Helper loaded: url_helper
INFO - 2021-12-11 05:29:19 --> Helper loaded: file_helper
INFO - 2021-12-11 05:29:19 --> Helper loaded: form_helper
INFO - 2021-12-11 05:29:19 --> Helper loaded: my_helper
INFO - 2021-12-11 05:29:19 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:29:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:29:19 --> Controller Class Initialized
DEBUG - 2021-12-11 05:29:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:29:19 --> Final output sent to browser
DEBUG - 2021-12-11 05:29:19 --> Total execution time: 0.0600
INFO - 2021-12-11 05:29:20 --> Config Class Initialized
INFO - 2021-12-11 05:29:20 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:29:20 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:29:20 --> Utf8 Class Initialized
INFO - 2021-12-11 05:29:20 --> URI Class Initialized
INFO - 2021-12-11 05:29:20 --> Router Class Initialized
INFO - 2021-12-11 05:29:20 --> Output Class Initialized
INFO - 2021-12-11 05:29:20 --> Security Class Initialized
DEBUG - 2021-12-11 05:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:29:20 --> Input Class Initialized
INFO - 2021-12-11 05:29:20 --> Language Class Initialized
INFO - 2021-12-11 05:29:20 --> Language Class Initialized
INFO - 2021-12-11 05:29:20 --> Config Class Initialized
INFO - 2021-12-11 05:29:20 --> Loader Class Initialized
INFO - 2021-12-11 05:29:20 --> Helper loaded: url_helper
INFO - 2021-12-11 05:29:20 --> Helper loaded: file_helper
INFO - 2021-12-11 05:29:20 --> Helper loaded: form_helper
INFO - 2021-12-11 05:29:20 --> Helper loaded: my_helper
INFO - 2021-12-11 05:29:20 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:29:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:29:20 --> Controller Class Initialized
DEBUG - 2021-12-11 05:29:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:29:20 --> Final output sent to browser
DEBUG - 2021-12-11 05:29:20 --> Total execution time: 0.0630
INFO - 2021-12-11 05:29:23 --> Config Class Initialized
INFO - 2021-12-11 05:29:23 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:29:23 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:29:23 --> Utf8 Class Initialized
INFO - 2021-12-11 05:29:23 --> URI Class Initialized
INFO - 2021-12-11 05:29:23 --> Router Class Initialized
INFO - 2021-12-11 05:29:23 --> Output Class Initialized
INFO - 2021-12-11 05:29:23 --> Security Class Initialized
DEBUG - 2021-12-11 05:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:29:23 --> Input Class Initialized
INFO - 2021-12-11 05:29:23 --> Language Class Initialized
INFO - 2021-12-11 05:29:23 --> Language Class Initialized
INFO - 2021-12-11 05:29:23 --> Config Class Initialized
INFO - 2021-12-11 05:29:23 --> Loader Class Initialized
INFO - 2021-12-11 05:29:23 --> Helper loaded: url_helper
INFO - 2021-12-11 05:29:23 --> Helper loaded: file_helper
INFO - 2021-12-11 05:29:23 --> Helper loaded: form_helper
INFO - 2021-12-11 05:29:23 --> Helper loaded: my_helper
INFO - 2021-12-11 05:29:23 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:29:23 --> Controller Class Initialized
DEBUG - 2021-12-11 05:29:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:29:23 --> Final output sent to browser
DEBUG - 2021-12-11 05:29:23 --> Total execution time: 0.0590
INFO - 2021-12-11 05:29:25 --> Config Class Initialized
INFO - 2021-12-11 05:29:25 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:29:25 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:29:25 --> Utf8 Class Initialized
INFO - 2021-12-11 05:29:25 --> URI Class Initialized
INFO - 2021-12-11 05:29:25 --> Router Class Initialized
INFO - 2021-12-11 05:29:25 --> Output Class Initialized
INFO - 2021-12-11 05:29:25 --> Security Class Initialized
DEBUG - 2021-12-11 05:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:29:25 --> Input Class Initialized
INFO - 2021-12-11 05:29:25 --> Language Class Initialized
INFO - 2021-12-11 05:29:25 --> Language Class Initialized
INFO - 2021-12-11 05:29:25 --> Config Class Initialized
INFO - 2021-12-11 05:29:25 --> Loader Class Initialized
INFO - 2021-12-11 05:29:25 --> Helper loaded: url_helper
INFO - 2021-12-11 05:29:25 --> Helper loaded: file_helper
INFO - 2021-12-11 05:29:25 --> Helper loaded: form_helper
INFO - 2021-12-11 05:29:25 --> Helper loaded: my_helper
INFO - 2021-12-11 05:29:25 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:29:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:29:25 --> Controller Class Initialized
DEBUG - 2021-12-11 05:29:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:29:25 --> Final output sent to browser
DEBUG - 2021-12-11 05:29:25 --> Total execution time: 0.0640
INFO - 2021-12-11 05:29:27 --> Config Class Initialized
INFO - 2021-12-11 05:29:27 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:29:27 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:29:27 --> Utf8 Class Initialized
INFO - 2021-12-11 05:29:27 --> URI Class Initialized
INFO - 2021-12-11 05:29:27 --> Router Class Initialized
INFO - 2021-12-11 05:29:27 --> Output Class Initialized
INFO - 2021-12-11 05:29:27 --> Security Class Initialized
DEBUG - 2021-12-11 05:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:29:27 --> Input Class Initialized
INFO - 2021-12-11 05:29:27 --> Language Class Initialized
INFO - 2021-12-11 05:29:27 --> Language Class Initialized
INFO - 2021-12-11 05:29:27 --> Config Class Initialized
INFO - 2021-12-11 05:29:27 --> Loader Class Initialized
INFO - 2021-12-11 05:29:27 --> Helper loaded: url_helper
INFO - 2021-12-11 05:29:27 --> Helper loaded: file_helper
INFO - 2021-12-11 05:29:27 --> Helper loaded: form_helper
INFO - 2021-12-11 05:29:27 --> Helper loaded: my_helper
INFO - 2021-12-11 05:29:27 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:29:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:29:27 --> Controller Class Initialized
DEBUG - 2021-12-11 05:29:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:29:27 --> Final output sent to browser
DEBUG - 2021-12-11 05:29:27 --> Total execution time: 0.0660
INFO - 2021-12-11 05:29:29 --> Config Class Initialized
INFO - 2021-12-11 05:29:29 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:29:29 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:29:29 --> Utf8 Class Initialized
INFO - 2021-12-11 05:29:29 --> URI Class Initialized
INFO - 2021-12-11 05:29:29 --> Router Class Initialized
INFO - 2021-12-11 05:29:29 --> Output Class Initialized
INFO - 2021-12-11 05:29:29 --> Security Class Initialized
DEBUG - 2021-12-11 05:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:29:29 --> Input Class Initialized
INFO - 2021-12-11 05:29:29 --> Language Class Initialized
INFO - 2021-12-11 05:29:29 --> Language Class Initialized
INFO - 2021-12-11 05:29:29 --> Config Class Initialized
INFO - 2021-12-11 05:29:29 --> Loader Class Initialized
INFO - 2021-12-11 05:29:29 --> Helper loaded: url_helper
INFO - 2021-12-11 05:29:29 --> Helper loaded: file_helper
INFO - 2021-12-11 05:29:29 --> Helper loaded: form_helper
INFO - 2021-12-11 05:29:29 --> Helper loaded: my_helper
INFO - 2021-12-11 05:29:29 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:29:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:29:29 --> Controller Class Initialized
DEBUG - 2021-12-11 05:29:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:29:29 --> Final output sent to browser
DEBUG - 2021-12-11 05:29:29 --> Total execution time: 0.0630
INFO - 2021-12-11 05:29:31 --> Config Class Initialized
INFO - 2021-12-11 05:29:31 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:29:31 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:29:31 --> Utf8 Class Initialized
INFO - 2021-12-11 05:29:31 --> URI Class Initialized
INFO - 2021-12-11 05:29:31 --> Router Class Initialized
INFO - 2021-12-11 05:29:31 --> Output Class Initialized
INFO - 2021-12-11 05:29:31 --> Security Class Initialized
DEBUG - 2021-12-11 05:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:29:31 --> Input Class Initialized
INFO - 2021-12-11 05:29:31 --> Language Class Initialized
INFO - 2021-12-11 05:29:31 --> Language Class Initialized
INFO - 2021-12-11 05:29:31 --> Config Class Initialized
INFO - 2021-12-11 05:29:31 --> Loader Class Initialized
INFO - 2021-12-11 05:29:31 --> Helper loaded: url_helper
INFO - 2021-12-11 05:29:31 --> Helper loaded: file_helper
INFO - 2021-12-11 05:29:31 --> Helper loaded: form_helper
INFO - 2021-12-11 05:29:31 --> Helper loaded: my_helper
INFO - 2021-12-11 05:29:31 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:29:31 --> Controller Class Initialized
DEBUG - 2021-12-11 05:29:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:29:31 --> Final output sent to browser
DEBUG - 2021-12-11 05:29:31 --> Total execution time: 0.0710
INFO - 2021-12-11 05:29:33 --> Config Class Initialized
INFO - 2021-12-11 05:29:33 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:29:33 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:29:33 --> Utf8 Class Initialized
INFO - 2021-12-11 05:29:33 --> URI Class Initialized
INFO - 2021-12-11 05:29:33 --> Router Class Initialized
INFO - 2021-12-11 05:29:33 --> Output Class Initialized
INFO - 2021-12-11 05:29:33 --> Security Class Initialized
DEBUG - 2021-12-11 05:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:29:33 --> Input Class Initialized
INFO - 2021-12-11 05:29:33 --> Language Class Initialized
INFO - 2021-12-11 05:29:33 --> Language Class Initialized
INFO - 2021-12-11 05:29:33 --> Config Class Initialized
INFO - 2021-12-11 05:29:33 --> Loader Class Initialized
INFO - 2021-12-11 05:29:33 --> Helper loaded: url_helper
INFO - 2021-12-11 05:29:33 --> Helper loaded: file_helper
INFO - 2021-12-11 05:29:33 --> Helper loaded: form_helper
INFO - 2021-12-11 05:29:33 --> Helper loaded: my_helper
INFO - 2021-12-11 05:29:33 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:29:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:29:33 --> Controller Class Initialized
DEBUG - 2021-12-11 05:29:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:29:33 --> Final output sent to browser
DEBUG - 2021-12-11 05:29:33 --> Total execution time: 0.0630
INFO - 2021-12-11 05:29:35 --> Config Class Initialized
INFO - 2021-12-11 05:29:35 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:29:35 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:29:35 --> Utf8 Class Initialized
INFO - 2021-12-11 05:29:35 --> URI Class Initialized
INFO - 2021-12-11 05:29:35 --> Router Class Initialized
INFO - 2021-12-11 05:29:35 --> Output Class Initialized
INFO - 2021-12-11 05:29:35 --> Security Class Initialized
DEBUG - 2021-12-11 05:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:29:35 --> Input Class Initialized
INFO - 2021-12-11 05:29:35 --> Language Class Initialized
INFO - 2021-12-11 05:29:35 --> Language Class Initialized
INFO - 2021-12-11 05:29:35 --> Config Class Initialized
INFO - 2021-12-11 05:29:35 --> Loader Class Initialized
INFO - 2021-12-11 05:29:35 --> Helper loaded: url_helper
INFO - 2021-12-11 05:29:35 --> Helper loaded: file_helper
INFO - 2021-12-11 05:29:35 --> Helper loaded: form_helper
INFO - 2021-12-11 05:29:35 --> Helper loaded: my_helper
INFO - 2021-12-11 05:29:35 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:29:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:29:35 --> Controller Class Initialized
DEBUG - 2021-12-11 05:29:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:29:35 --> Final output sent to browser
DEBUG - 2021-12-11 05:29:35 --> Total execution time: 0.0620
INFO - 2021-12-11 05:29:37 --> Config Class Initialized
INFO - 2021-12-11 05:29:37 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:29:37 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:29:37 --> Utf8 Class Initialized
INFO - 2021-12-11 05:29:37 --> URI Class Initialized
INFO - 2021-12-11 05:29:37 --> Router Class Initialized
INFO - 2021-12-11 05:29:37 --> Output Class Initialized
INFO - 2021-12-11 05:29:37 --> Security Class Initialized
DEBUG - 2021-12-11 05:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:29:37 --> Input Class Initialized
INFO - 2021-12-11 05:29:37 --> Language Class Initialized
INFO - 2021-12-11 05:29:37 --> Language Class Initialized
INFO - 2021-12-11 05:29:37 --> Config Class Initialized
INFO - 2021-12-11 05:29:37 --> Loader Class Initialized
INFO - 2021-12-11 05:29:37 --> Helper loaded: url_helper
INFO - 2021-12-11 05:29:37 --> Helper loaded: file_helper
INFO - 2021-12-11 05:29:37 --> Helper loaded: form_helper
INFO - 2021-12-11 05:29:37 --> Helper loaded: my_helper
INFO - 2021-12-11 05:29:37 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:29:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:29:37 --> Controller Class Initialized
DEBUG - 2021-12-11 05:29:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:29:37 --> Final output sent to browser
DEBUG - 2021-12-11 05:29:37 --> Total execution time: 0.0640
INFO - 2021-12-11 05:35:12 --> Config Class Initialized
INFO - 2021-12-11 05:35:12 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:35:12 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:35:12 --> Utf8 Class Initialized
INFO - 2021-12-11 05:35:12 --> URI Class Initialized
INFO - 2021-12-11 05:35:12 --> Router Class Initialized
INFO - 2021-12-11 05:35:12 --> Output Class Initialized
INFO - 2021-12-11 05:35:12 --> Security Class Initialized
DEBUG - 2021-12-11 05:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:35:12 --> Input Class Initialized
INFO - 2021-12-11 05:35:12 --> Language Class Initialized
INFO - 2021-12-11 05:35:12 --> Language Class Initialized
INFO - 2021-12-11 05:35:12 --> Config Class Initialized
INFO - 2021-12-11 05:35:12 --> Loader Class Initialized
INFO - 2021-12-11 05:35:12 --> Helper loaded: url_helper
INFO - 2021-12-11 05:35:12 --> Helper loaded: file_helper
INFO - 2021-12-11 05:35:12 --> Helper loaded: form_helper
INFO - 2021-12-11 05:35:12 --> Helper loaded: my_helper
INFO - 2021-12-11 05:35:12 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:35:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:35:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:35:12 --> Controller Class Initialized
INFO - 2021-12-11 05:35:12 --> Helper loaded: cookie_helper
INFO - 2021-12-11 05:35:12 --> Config Class Initialized
INFO - 2021-12-11 05:35:12 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:35:12 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:35:12 --> Utf8 Class Initialized
INFO - 2021-12-11 05:35:12 --> URI Class Initialized
INFO - 2021-12-11 05:35:12 --> Router Class Initialized
INFO - 2021-12-11 05:35:12 --> Output Class Initialized
INFO - 2021-12-11 05:35:12 --> Security Class Initialized
DEBUG - 2021-12-11 05:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:35:12 --> Input Class Initialized
INFO - 2021-12-11 05:35:12 --> Language Class Initialized
INFO - 2021-12-11 05:35:12 --> Language Class Initialized
INFO - 2021-12-11 05:35:12 --> Config Class Initialized
INFO - 2021-12-11 05:35:12 --> Loader Class Initialized
INFO - 2021-12-11 05:35:12 --> Helper loaded: url_helper
INFO - 2021-12-11 05:35:12 --> Helper loaded: file_helper
INFO - 2021-12-11 05:35:12 --> Helper loaded: form_helper
INFO - 2021-12-11 05:35:12 --> Helper loaded: my_helper
INFO - 2021-12-11 05:35:12 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:35:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:35:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:35:12 --> Controller Class Initialized
DEBUG - 2021-12-11 05:35:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-11 05:35:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-11 05:35:12 --> Final output sent to browser
DEBUG - 2021-12-11 05:35:12 --> Total execution time: 0.0350
INFO - 2021-12-11 05:35:16 --> Config Class Initialized
INFO - 2021-12-11 05:35:16 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:35:16 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:35:16 --> Utf8 Class Initialized
INFO - 2021-12-11 05:35:16 --> URI Class Initialized
INFO - 2021-12-11 05:35:16 --> Router Class Initialized
INFO - 2021-12-11 05:35:16 --> Output Class Initialized
INFO - 2021-12-11 05:35:16 --> Security Class Initialized
DEBUG - 2021-12-11 05:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:35:16 --> Input Class Initialized
INFO - 2021-12-11 05:35:16 --> Language Class Initialized
INFO - 2021-12-11 05:35:16 --> Language Class Initialized
INFO - 2021-12-11 05:35:16 --> Config Class Initialized
INFO - 2021-12-11 05:35:16 --> Loader Class Initialized
INFO - 2021-12-11 05:35:16 --> Helper loaded: url_helper
INFO - 2021-12-11 05:35:16 --> Helper loaded: file_helper
INFO - 2021-12-11 05:35:16 --> Helper loaded: form_helper
INFO - 2021-12-11 05:35:16 --> Helper loaded: my_helper
INFO - 2021-12-11 05:35:16 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:35:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:35:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:35:16 --> Controller Class Initialized
INFO - 2021-12-11 05:35:16 --> Helper loaded: cookie_helper
INFO - 2021-12-11 05:35:16 --> Final output sent to browser
DEBUG - 2021-12-11 05:35:16 --> Total execution time: 0.0380
INFO - 2021-12-11 05:35:16 --> Config Class Initialized
INFO - 2021-12-11 05:35:16 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:35:16 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:35:16 --> Utf8 Class Initialized
INFO - 2021-12-11 05:35:16 --> URI Class Initialized
INFO - 2021-12-11 05:35:16 --> Router Class Initialized
INFO - 2021-12-11 05:35:16 --> Output Class Initialized
INFO - 2021-12-11 05:35:16 --> Security Class Initialized
DEBUG - 2021-12-11 05:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:35:16 --> Input Class Initialized
INFO - 2021-12-11 05:35:16 --> Language Class Initialized
INFO - 2021-12-11 05:35:16 --> Language Class Initialized
INFO - 2021-12-11 05:35:16 --> Config Class Initialized
INFO - 2021-12-11 05:35:16 --> Loader Class Initialized
INFO - 2021-12-11 05:35:16 --> Helper loaded: url_helper
INFO - 2021-12-11 05:35:16 --> Helper loaded: file_helper
INFO - 2021-12-11 05:35:16 --> Helper loaded: form_helper
INFO - 2021-12-11 05:35:16 --> Helper loaded: my_helper
INFO - 2021-12-11 05:35:16 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:35:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:35:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:35:16 --> Controller Class Initialized
DEBUG - 2021-12-11 05:35:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-11 05:35:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-11 05:35:16 --> Final output sent to browser
DEBUG - 2021-12-11 05:35:16 --> Total execution time: 0.2390
INFO - 2021-12-11 05:35:21 --> Config Class Initialized
INFO - 2021-12-11 05:35:21 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:35:21 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:35:21 --> Utf8 Class Initialized
INFO - 2021-12-11 05:35:21 --> URI Class Initialized
INFO - 2021-12-11 05:35:21 --> Router Class Initialized
INFO - 2021-12-11 05:35:21 --> Output Class Initialized
INFO - 2021-12-11 05:35:21 --> Security Class Initialized
DEBUG - 2021-12-11 05:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:35:21 --> Input Class Initialized
INFO - 2021-12-11 05:35:21 --> Language Class Initialized
INFO - 2021-12-11 05:35:21 --> Language Class Initialized
INFO - 2021-12-11 05:35:21 --> Config Class Initialized
INFO - 2021-12-11 05:35:21 --> Loader Class Initialized
INFO - 2021-12-11 05:35:21 --> Helper loaded: url_helper
INFO - 2021-12-11 05:35:21 --> Helper loaded: file_helper
INFO - 2021-12-11 05:35:21 --> Helper loaded: form_helper
INFO - 2021-12-11 05:35:21 --> Helper loaded: my_helper
INFO - 2021-12-11 05:35:21 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:35:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:35:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:35:21 --> Controller Class Initialized
DEBUG - 2021-12-11 05:35:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-11 05:35:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-11 05:35:21 --> Final output sent to browser
DEBUG - 2021-12-11 05:35:21 --> Total execution time: 0.0580
INFO - 2021-12-11 05:35:24 --> Config Class Initialized
INFO - 2021-12-11 05:35:24 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:35:24 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:35:24 --> Utf8 Class Initialized
INFO - 2021-12-11 05:35:24 --> URI Class Initialized
INFO - 2021-12-11 05:35:24 --> Router Class Initialized
INFO - 2021-12-11 05:35:24 --> Output Class Initialized
INFO - 2021-12-11 05:35:24 --> Security Class Initialized
DEBUG - 2021-12-11 05:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:35:24 --> Input Class Initialized
INFO - 2021-12-11 05:35:24 --> Language Class Initialized
INFO - 2021-12-11 05:35:24 --> Language Class Initialized
INFO - 2021-12-11 05:35:24 --> Config Class Initialized
INFO - 2021-12-11 05:35:24 --> Loader Class Initialized
INFO - 2021-12-11 05:35:25 --> Helper loaded: url_helper
INFO - 2021-12-11 05:35:25 --> Helper loaded: file_helper
INFO - 2021-12-11 05:35:25 --> Helper loaded: form_helper
INFO - 2021-12-11 05:35:25 --> Helper loaded: my_helper
INFO - 2021-12-11 05:35:25 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:35:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:35:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:35:25 --> Controller Class Initialized
DEBUG - 2021-12-11 05:35:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:35:25 --> Final output sent to browser
DEBUG - 2021-12-11 05:35:25 --> Total execution time: 0.1200
INFO - 2021-12-11 05:35:26 --> Config Class Initialized
INFO - 2021-12-11 05:35:26 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:35:26 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:35:26 --> Utf8 Class Initialized
INFO - 2021-12-11 05:35:26 --> URI Class Initialized
INFO - 2021-12-11 05:35:26 --> Router Class Initialized
INFO - 2021-12-11 05:35:26 --> Output Class Initialized
INFO - 2021-12-11 05:35:26 --> Security Class Initialized
DEBUG - 2021-12-11 05:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:35:26 --> Input Class Initialized
INFO - 2021-12-11 05:35:26 --> Language Class Initialized
INFO - 2021-12-11 05:35:26 --> Language Class Initialized
INFO - 2021-12-11 05:35:26 --> Config Class Initialized
INFO - 2021-12-11 05:35:26 --> Loader Class Initialized
INFO - 2021-12-11 05:35:26 --> Helper loaded: url_helper
INFO - 2021-12-11 05:35:26 --> Helper loaded: file_helper
INFO - 2021-12-11 05:35:26 --> Helper loaded: form_helper
INFO - 2021-12-11 05:35:26 --> Helper loaded: my_helper
INFO - 2021-12-11 05:35:26 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:35:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:35:26 --> Controller Class Initialized
DEBUG - 2021-12-11 05:35:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:35:26 --> Final output sent to browser
DEBUG - 2021-12-11 05:35:26 --> Total execution time: 0.0690
INFO - 2021-12-11 05:35:29 --> Config Class Initialized
INFO - 2021-12-11 05:35:29 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:35:29 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:35:29 --> Utf8 Class Initialized
INFO - 2021-12-11 05:35:29 --> URI Class Initialized
INFO - 2021-12-11 05:35:29 --> Router Class Initialized
INFO - 2021-12-11 05:35:29 --> Output Class Initialized
INFO - 2021-12-11 05:35:29 --> Security Class Initialized
DEBUG - 2021-12-11 05:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:35:29 --> Input Class Initialized
INFO - 2021-12-11 05:35:29 --> Language Class Initialized
INFO - 2021-12-11 05:35:29 --> Language Class Initialized
INFO - 2021-12-11 05:35:29 --> Config Class Initialized
INFO - 2021-12-11 05:35:29 --> Loader Class Initialized
INFO - 2021-12-11 05:35:29 --> Helper loaded: url_helper
INFO - 2021-12-11 05:35:29 --> Helper loaded: file_helper
INFO - 2021-12-11 05:35:29 --> Helper loaded: form_helper
INFO - 2021-12-11 05:35:29 --> Helper loaded: my_helper
INFO - 2021-12-11 05:35:29 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:35:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:35:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:35:29 --> Controller Class Initialized
DEBUG - 2021-12-11 05:35:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:35:29 --> Final output sent to browser
DEBUG - 2021-12-11 05:35:29 --> Total execution time: 0.0730
INFO - 2021-12-11 05:35:30 --> Config Class Initialized
INFO - 2021-12-11 05:35:30 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:35:30 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:35:30 --> Utf8 Class Initialized
INFO - 2021-12-11 05:35:30 --> URI Class Initialized
INFO - 2021-12-11 05:35:30 --> Router Class Initialized
INFO - 2021-12-11 05:35:30 --> Output Class Initialized
INFO - 2021-12-11 05:35:30 --> Security Class Initialized
DEBUG - 2021-12-11 05:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:35:30 --> Input Class Initialized
INFO - 2021-12-11 05:35:30 --> Language Class Initialized
INFO - 2021-12-11 05:35:30 --> Language Class Initialized
INFO - 2021-12-11 05:35:30 --> Config Class Initialized
INFO - 2021-12-11 05:35:30 --> Loader Class Initialized
INFO - 2021-12-11 05:35:30 --> Helper loaded: url_helper
INFO - 2021-12-11 05:35:30 --> Helper loaded: file_helper
INFO - 2021-12-11 05:35:30 --> Helper loaded: form_helper
INFO - 2021-12-11 05:35:30 --> Helper loaded: my_helper
INFO - 2021-12-11 05:35:30 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:35:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:35:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:35:30 --> Controller Class Initialized
DEBUG - 2021-12-11 05:35:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:35:30 --> Final output sent to browser
DEBUG - 2021-12-11 05:35:30 --> Total execution time: 0.0640
INFO - 2021-12-11 05:35:33 --> Config Class Initialized
INFO - 2021-12-11 05:35:33 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:35:33 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:35:33 --> Utf8 Class Initialized
INFO - 2021-12-11 05:35:33 --> URI Class Initialized
INFO - 2021-12-11 05:35:33 --> Router Class Initialized
INFO - 2021-12-11 05:35:33 --> Output Class Initialized
INFO - 2021-12-11 05:35:33 --> Security Class Initialized
DEBUG - 2021-12-11 05:35:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:35:33 --> Input Class Initialized
INFO - 2021-12-11 05:35:33 --> Language Class Initialized
INFO - 2021-12-11 05:35:33 --> Language Class Initialized
INFO - 2021-12-11 05:35:33 --> Config Class Initialized
INFO - 2021-12-11 05:35:33 --> Loader Class Initialized
INFO - 2021-12-11 05:35:33 --> Helper loaded: url_helper
INFO - 2021-12-11 05:35:33 --> Helper loaded: file_helper
INFO - 2021-12-11 05:35:33 --> Helper loaded: form_helper
INFO - 2021-12-11 05:35:33 --> Helper loaded: my_helper
INFO - 2021-12-11 05:35:33 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:35:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:35:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:35:33 --> Controller Class Initialized
DEBUG - 2021-12-11 05:35:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:35:33 --> Final output sent to browser
DEBUG - 2021-12-11 05:35:33 --> Total execution time: 0.0610
INFO - 2021-12-11 05:35:34 --> Config Class Initialized
INFO - 2021-12-11 05:35:34 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:35:34 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:35:34 --> Utf8 Class Initialized
INFO - 2021-12-11 05:35:34 --> URI Class Initialized
INFO - 2021-12-11 05:35:34 --> Router Class Initialized
INFO - 2021-12-11 05:35:34 --> Output Class Initialized
INFO - 2021-12-11 05:35:34 --> Security Class Initialized
DEBUG - 2021-12-11 05:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:35:34 --> Input Class Initialized
INFO - 2021-12-11 05:35:34 --> Language Class Initialized
INFO - 2021-12-11 05:35:34 --> Language Class Initialized
INFO - 2021-12-11 05:35:34 --> Config Class Initialized
INFO - 2021-12-11 05:35:34 --> Loader Class Initialized
INFO - 2021-12-11 05:35:34 --> Helper loaded: url_helper
INFO - 2021-12-11 05:35:34 --> Helper loaded: file_helper
INFO - 2021-12-11 05:35:34 --> Helper loaded: form_helper
INFO - 2021-12-11 05:35:34 --> Helper loaded: my_helper
INFO - 2021-12-11 05:35:34 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:35:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:35:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:35:34 --> Controller Class Initialized
DEBUG - 2021-12-11 05:35:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:35:34 --> Final output sent to browser
DEBUG - 2021-12-11 05:35:34 --> Total execution time: 0.0530
INFO - 2021-12-11 05:35:35 --> Config Class Initialized
INFO - 2021-12-11 05:35:35 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:35:35 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:35:35 --> Utf8 Class Initialized
INFO - 2021-12-11 05:35:35 --> URI Class Initialized
INFO - 2021-12-11 05:35:35 --> Router Class Initialized
INFO - 2021-12-11 05:35:35 --> Output Class Initialized
INFO - 2021-12-11 05:35:35 --> Security Class Initialized
DEBUG - 2021-12-11 05:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:35:35 --> Input Class Initialized
INFO - 2021-12-11 05:35:35 --> Language Class Initialized
INFO - 2021-12-11 05:35:35 --> Language Class Initialized
INFO - 2021-12-11 05:35:35 --> Config Class Initialized
INFO - 2021-12-11 05:35:35 --> Loader Class Initialized
INFO - 2021-12-11 05:35:35 --> Helper loaded: url_helper
INFO - 2021-12-11 05:35:35 --> Helper loaded: file_helper
INFO - 2021-12-11 05:35:35 --> Helper loaded: form_helper
INFO - 2021-12-11 05:35:35 --> Helper loaded: my_helper
INFO - 2021-12-11 05:35:35 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:35:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:35:35 --> Controller Class Initialized
DEBUG - 2021-12-11 05:35:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:35:35 --> Final output sent to browser
DEBUG - 2021-12-11 05:35:35 --> Total execution time: 0.0620
INFO - 2021-12-11 05:35:39 --> Config Class Initialized
INFO - 2021-12-11 05:35:39 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:35:39 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:35:39 --> Utf8 Class Initialized
INFO - 2021-12-11 05:35:39 --> URI Class Initialized
INFO - 2021-12-11 05:35:39 --> Router Class Initialized
INFO - 2021-12-11 05:35:39 --> Output Class Initialized
INFO - 2021-12-11 05:35:39 --> Security Class Initialized
DEBUG - 2021-12-11 05:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:35:39 --> Input Class Initialized
INFO - 2021-12-11 05:35:39 --> Language Class Initialized
INFO - 2021-12-11 05:35:39 --> Language Class Initialized
INFO - 2021-12-11 05:35:39 --> Config Class Initialized
INFO - 2021-12-11 05:35:39 --> Loader Class Initialized
INFO - 2021-12-11 05:35:39 --> Helper loaded: url_helper
INFO - 2021-12-11 05:35:39 --> Helper loaded: file_helper
INFO - 2021-12-11 05:35:39 --> Helper loaded: form_helper
INFO - 2021-12-11 05:35:39 --> Helper loaded: my_helper
INFO - 2021-12-11 05:35:39 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:35:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:35:39 --> Controller Class Initialized
DEBUG - 2021-12-11 05:35:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:35:39 --> Final output sent to browser
DEBUG - 2021-12-11 05:35:39 --> Total execution time: 0.0630
INFO - 2021-12-11 05:35:40 --> Config Class Initialized
INFO - 2021-12-11 05:35:40 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:35:40 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:35:40 --> Utf8 Class Initialized
INFO - 2021-12-11 05:35:40 --> URI Class Initialized
INFO - 2021-12-11 05:35:40 --> Router Class Initialized
INFO - 2021-12-11 05:35:40 --> Output Class Initialized
INFO - 2021-12-11 05:35:40 --> Security Class Initialized
DEBUG - 2021-12-11 05:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:35:40 --> Input Class Initialized
INFO - 2021-12-11 05:35:40 --> Language Class Initialized
INFO - 2021-12-11 05:35:40 --> Language Class Initialized
INFO - 2021-12-11 05:35:40 --> Config Class Initialized
INFO - 2021-12-11 05:35:40 --> Loader Class Initialized
INFO - 2021-12-11 05:35:40 --> Helper loaded: url_helper
INFO - 2021-12-11 05:35:40 --> Helper loaded: file_helper
INFO - 2021-12-11 05:35:40 --> Helper loaded: form_helper
INFO - 2021-12-11 05:35:40 --> Helper loaded: my_helper
INFO - 2021-12-11 05:35:40 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:35:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:35:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:35:40 --> Controller Class Initialized
DEBUG - 2021-12-11 05:35:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:35:40 --> Final output sent to browser
DEBUG - 2021-12-11 05:35:40 --> Total execution time: 0.0670
INFO - 2021-12-11 05:35:42 --> Config Class Initialized
INFO - 2021-12-11 05:35:42 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:35:42 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:35:42 --> Utf8 Class Initialized
INFO - 2021-12-11 05:35:42 --> URI Class Initialized
INFO - 2021-12-11 05:35:42 --> Router Class Initialized
INFO - 2021-12-11 05:35:42 --> Output Class Initialized
INFO - 2021-12-11 05:35:42 --> Security Class Initialized
DEBUG - 2021-12-11 05:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:35:42 --> Input Class Initialized
INFO - 2021-12-11 05:35:42 --> Language Class Initialized
INFO - 2021-12-11 05:35:42 --> Language Class Initialized
INFO - 2021-12-11 05:35:42 --> Config Class Initialized
INFO - 2021-12-11 05:35:42 --> Loader Class Initialized
INFO - 2021-12-11 05:35:42 --> Helper loaded: url_helper
INFO - 2021-12-11 05:35:42 --> Helper loaded: file_helper
INFO - 2021-12-11 05:35:42 --> Helper loaded: form_helper
INFO - 2021-12-11 05:35:42 --> Helper loaded: my_helper
INFO - 2021-12-11 05:35:42 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:35:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:35:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:35:42 --> Controller Class Initialized
DEBUG - 2021-12-11 05:35:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:35:42 --> Final output sent to browser
DEBUG - 2021-12-11 05:35:42 --> Total execution time: 0.0670
INFO - 2021-12-11 05:35:45 --> Config Class Initialized
INFO - 2021-12-11 05:35:45 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:35:45 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:35:45 --> Utf8 Class Initialized
INFO - 2021-12-11 05:35:45 --> URI Class Initialized
INFO - 2021-12-11 05:35:45 --> Router Class Initialized
INFO - 2021-12-11 05:35:45 --> Output Class Initialized
INFO - 2021-12-11 05:35:45 --> Security Class Initialized
DEBUG - 2021-12-11 05:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:35:45 --> Input Class Initialized
INFO - 2021-12-11 05:35:45 --> Language Class Initialized
INFO - 2021-12-11 05:35:45 --> Language Class Initialized
INFO - 2021-12-11 05:35:45 --> Config Class Initialized
INFO - 2021-12-11 05:35:45 --> Loader Class Initialized
INFO - 2021-12-11 05:35:45 --> Helper loaded: url_helper
INFO - 2021-12-11 05:35:45 --> Helper loaded: file_helper
INFO - 2021-12-11 05:35:45 --> Helper loaded: form_helper
INFO - 2021-12-11 05:35:45 --> Helper loaded: my_helper
INFO - 2021-12-11 05:35:45 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:35:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:35:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:35:45 --> Controller Class Initialized
DEBUG - 2021-12-11 05:35:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:35:45 --> Final output sent to browser
DEBUG - 2021-12-11 05:35:45 --> Total execution time: 0.0610
INFO - 2021-12-11 05:35:47 --> Config Class Initialized
INFO - 2021-12-11 05:35:47 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:35:47 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:35:47 --> Utf8 Class Initialized
INFO - 2021-12-11 05:35:47 --> URI Class Initialized
INFO - 2021-12-11 05:35:47 --> Router Class Initialized
INFO - 2021-12-11 05:35:47 --> Output Class Initialized
INFO - 2021-12-11 05:35:47 --> Security Class Initialized
DEBUG - 2021-12-11 05:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:35:47 --> Input Class Initialized
INFO - 2021-12-11 05:35:47 --> Language Class Initialized
INFO - 2021-12-11 05:35:47 --> Language Class Initialized
INFO - 2021-12-11 05:35:47 --> Config Class Initialized
INFO - 2021-12-11 05:35:47 --> Loader Class Initialized
INFO - 2021-12-11 05:35:47 --> Helper loaded: url_helper
INFO - 2021-12-11 05:35:47 --> Helper loaded: file_helper
INFO - 2021-12-11 05:35:47 --> Helper loaded: form_helper
INFO - 2021-12-11 05:35:47 --> Helper loaded: my_helper
INFO - 2021-12-11 05:35:47 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:35:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:35:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:35:47 --> Controller Class Initialized
DEBUG - 2021-12-11 05:35:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:35:47 --> Final output sent to browser
DEBUG - 2021-12-11 05:35:47 --> Total execution time: 0.0650
INFO - 2021-12-11 05:35:48 --> Config Class Initialized
INFO - 2021-12-11 05:35:48 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:35:48 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:35:48 --> Utf8 Class Initialized
INFO - 2021-12-11 05:35:48 --> URI Class Initialized
INFO - 2021-12-11 05:35:48 --> Router Class Initialized
INFO - 2021-12-11 05:35:48 --> Output Class Initialized
INFO - 2021-12-11 05:35:49 --> Security Class Initialized
DEBUG - 2021-12-11 05:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:35:49 --> Input Class Initialized
INFO - 2021-12-11 05:35:49 --> Language Class Initialized
INFO - 2021-12-11 05:35:49 --> Language Class Initialized
INFO - 2021-12-11 05:35:49 --> Config Class Initialized
INFO - 2021-12-11 05:35:49 --> Loader Class Initialized
INFO - 2021-12-11 05:35:49 --> Helper loaded: url_helper
INFO - 2021-12-11 05:35:49 --> Helper loaded: file_helper
INFO - 2021-12-11 05:35:49 --> Helper loaded: form_helper
INFO - 2021-12-11 05:35:49 --> Helper loaded: my_helper
INFO - 2021-12-11 05:35:49 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:35:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:35:49 --> Controller Class Initialized
DEBUG - 2021-12-11 05:35:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:35:49 --> Final output sent to browser
DEBUG - 2021-12-11 05:35:49 --> Total execution time: 0.0640
INFO - 2021-12-11 05:35:51 --> Config Class Initialized
INFO - 2021-12-11 05:35:51 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:35:51 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:35:51 --> Utf8 Class Initialized
INFO - 2021-12-11 05:35:51 --> URI Class Initialized
INFO - 2021-12-11 05:35:51 --> Router Class Initialized
INFO - 2021-12-11 05:35:51 --> Output Class Initialized
INFO - 2021-12-11 05:35:51 --> Security Class Initialized
DEBUG - 2021-12-11 05:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:35:51 --> Input Class Initialized
INFO - 2021-12-11 05:35:51 --> Language Class Initialized
INFO - 2021-12-11 05:35:51 --> Language Class Initialized
INFO - 2021-12-11 05:35:51 --> Config Class Initialized
INFO - 2021-12-11 05:35:51 --> Loader Class Initialized
INFO - 2021-12-11 05:35:51 --> Helper loaded: url_helper
INFO - 2021-12-11 05:35:51 --> Helper loaded: file_helper
INFO - 2021-12-11 05:35:51 --> Helper loaded: form_helper
INFO - 2021-12-11 05:35:51 --> Helper loaded: my_helper
INFO - 2021-12-11 05:35:51 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:35:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:35:51 --> Controller Class Initialized
DEBUG - 2021-12-11 05:35:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:35:51 --> Final output sent to browser
DEBUG - 2021-12-11 05:35:51 --> Total execution time: 0.0620
INFO - 2021-12-11 05:35:53 --> Config Class Initialized
INFO - 2021-12-11 05:35:53 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:35:53 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:35:53 --> Utf8 Class Initialized
INFO - 2021-12-11 05:35:53 --> URI Class Initialized
INFO - 2021-12-11 05:35:53 --> Router Class Initialized
INFO - 2021-12-11 05:35:53 --> Output Class Initialized
INFO - 2021-12-11 05:35:53 --> Security Class Initialized
DEBUG - 2021-12-11 05:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:35:53 --> Input Class Initialized
INFO - 2021-12-11 05:35:53 --> Language Class Initialized
INFO - 2021-12-11 05:35:53 --> Language Class Initialized
INFO - 2021-12-11 05:35:53 --> Config Class Initialized
INFO - 2021-12-11 05:35:53 --> Loader Class Initialized
INFO - 2021-12-11 05:35:53 --> Helper loaded: url_helper
INFO - 2021-12-11 05:35:53 --> Helper loaded: file_helper
INFO - 2021-12-11 05:35:53 --> Helper loaded: form_helper
INFO - 2021-12-11 05:35:53 --> Helper loaded: my_helper
INFO - 2021-12-11 05:35:53 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:35:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:35:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:35:53 --> Controller Class Initialized
DEBUG - 2021-12-11 05:35:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:35:53 --> Final output sent to browser
DEBUG - 2021-12-11 05:35:53 --> Total execution time: 0.0650
INFO - 2021-12-11 05:35:56 --> Config Class Initialized
INFO - 2021-12-11 05:35:56 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:35:56 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:35:56 --> Utf8 Class Initialized
INFO - 2021-12-11 05:35:56 --> URI Class Initialized
INFO - 2021-12-11 05:35:56 --> Router Class Initialized
INFO - 2021-12-11 05:35:56 --> Output Class Initialized
INFO - 2021-12-11 05:35:56 --> Security Class Initialized
DEBUG - 2021-12-11 05:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:35:56 --> Input Class Initialized
INFO - 2021-12-11 05:35:56 --> Language Class Initialized
INFO - 2021-12-11 05:35:56 --> Language Class Initialized
INFO - 2021-12-11 05:35:56 --> Config Class Initialized
INFO - 2021-12-11 05:35:56 --> Loader Class Initialized
INFO - 2021-12-11 05:35:56 --> Helper loaded: url_helper
INFO - 2021-12-11 05:35:56 --> Helper loaded: file_helper
INFO - 2021-12-11 05:35:56 --> Helper loaded: form_helper
INFO - 2021-12-11 05:35:56 --> Helper loaded: my_helper
INFO - 2021-12-11 05:35:56 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:35:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:35:56 --> Controller Class Initialized
DEBUG - 2021-12-11 05:35:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:35:56 --> Final output sent to browser
DEBUG - 2021-12-11 05:35:56 --> Total execution time: 0.0670
INFO - 2021-12-11 05:35:58 --> Config Class Initialized
INFO - 2021-12-11 05:35:58 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:35:58 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:35:58 --> Utf8 Class Initialized
INFO - 2021-12-11 05:35:58 --> URI Class Initialized
INFO - 2021-12-11 05:35:58 --> Router Class Initialized
INFO - 2021-12-11 05:35:58 --> Output Class Initialized
INFO - 2021-12-11 05:35:58 --> Security Class Initialized
DEBUG - 2021-12-11 05:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:35:58 --> Input Class Initialized
INFO - 2021-12-11 05:35:58 --> Language Class Initialized
INFO - 2021-12-11 05:35:58 --> Language Class Initialized
INFO - 2021-12-11 05:35:58 --> Config Class Initialized
INFO - 2021-12-11 05:35:58 --> Loader Class Initialized
INFO - 2021-12-11 05:35:58 --> Helper loaded: url_helper
INFO - 2021-12-11 05:35:58 --> Helper loaded: file_helper
INFO - 2021-12-11 05:35:58 --> Helper loaded: form_helper
INFO - 2021-12-11 05:35:58 --> Helper loaded: my_helper
INFO - 2021-12-11 05:35:58 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:35:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:35:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:35:58 --> Controller Class Initialized
DEBUG - 2021-12-11 05:35:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:35:58 --> Final output sent to browser
DEBUG - 2021-12-11 05:35:58 --> Total execution time: 0.0610
INFO - 2021-12-11 05:36:01 --> Config Class Initialized
INFO - 2021-12-11 05:36:01 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:36:01 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:36:01 --> Utf8 Class Initialized
INFO - 2021-12-11 05:36:01 --> URI Class Initialized
INFO - 2021-12-11 05:36:01 --> Router Class Initialized
INFO - 2021-12-11 05:36:01 --> Output Class Initialized
INFO - 2021-12-11 05:36:01 --> Security Class Initialized
DEBUG - 2021-12-11 05:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:36:01 --> Input Class Initialized
INFO - 2021-12-11 05:36:01 --> Language Class Initialized
INFO - 2021-12-11 05:36:01 --> Language Class Initialized
INFO - 2021-12-11 05:36:01 --> Config Class Initialized
INFO - 2021-12-11 05:36:01 --> Loader Class Initialized
INFO - 2021-12-11 05:36:01 --> Helper loaded: url_helper
INFO - 2021-12-11 05:36:01 --> Helper loaded: file_helper
INFO - 2021-12-11 05:36:01 --> Helper loaded: form_helper
INFO - 2021-12-11 05:36:01 --> Helper loaded: my_helper
INFO - 2021-12-11 05:36:01 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:36:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:36:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:36:01 --> Controller Class Initialized
DEBUG - 2021-12-11 05:36:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:36:01 --> Final output sent to browser
DEBUG - 2021-12-11 05:36:01 --> Total execution time: 0.0610
INFO - 2021-12-11 05:36:02 --> Config Class Initialized
INFO - 2021-12-11 05:36:02 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:36:02 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:36:02 --> Utf8 Class Initialized
INFO - 2021-12-11 05:36:03 --> URI Class Initialized
INFO - 2021-12-11 05:36:03 --> Router Class Initialized
INFO - 2021-12-11 05:36:03 --> Output Class Initialized
INFO - 2021-12-11 05:36:03 --> Security Class Initialized
DEBUG - 2021-12-11 05:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:36:03 --> Input Class Initialized
INFO - 2021-12-11 05:36:03 --> Language Class Initialized
INFO - 2021-12-11 05:36:03 --> Language Class Initialized
INFO - 2021-12-11 05:36:03 --> Config Class Initialized
INFO - 2021-12-11 05:36:03 --> Loader Class Initialized
INFO - 2021-12-11 05:36:03 --> Helper loaded: url_helper
INFO - 2021-12-11 05:36:03 --> Helper loaded: file_helper
INFO - 2021-12-11 05:36:03 --> Helper loaded: form_helper
INFO - 2021-12-11 05:36:03 --> Helper loaded: my_helper
INFO - 2021-12-11 05:36:03 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:36:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:36:03 --> Controller Class Initialized
DEBUG - 2021-12-11 05:36:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:36:03 --> Final output sent to browser
DEBUG - 2021-12-11 05:36:03 --> Total execution time: 0.0620
INFO - 2021-12-11 05:36:05 --> Config Class Initialized
INFO - 2021-12-11 05:36:05 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:36:05 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:36:05 --> Utf8 Class Initialized
INFO - 2021-12-11 05:36:05 --> URI Class Initialized
INFO - 2021-12-11 05:36:05 --> Router Class Initialized
INFO - 2021-12-11 05:36:05 --> Output Class Initialized
INFO - 2021-12-11 05:36:05 --> Security Class Initialized
DEBUG - 2021-12-11 05:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:36:05 --> Input Class Initialized
INFO - 2021-12-11 05:36:05 --> Language Class Initialized
INFO - 2021-12-11 05:36:05 --> Language Class Initialized
INFO - 2021-12-11 05:36:05 --> Config Class Initialized
INFO - 2021-12-11 05:36:05 --> Loader Class Initialized
INFO - 2021-12-11 05:36:05 --> Helper loaded: url_helper
INFO - 2021-12-11 05:36:05 --> Helper loaded: file_helper
INFO - 2021-12-11 05:36:05 --> Helper loaded: form_helper
INFO - 2021-12-11 05:36:05 --> Helper loaded: my_helper
INFO - 2021-12-11 05:36:05 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:36:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:36:05 --> Controller Class Initialized
DEBUG - 2021-12-11 05:36:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:36:05 --> Final output sent to browser
DEBUG - 2021-12-11 05:36:05 --> Total execution time: 0.0690
INFO - 2021-12-11 05:36:07 --> Config Class Initialized
INFO - 2021-12-11 05:36:07 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:36:07 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:36:07 --> Utf8 Class Initialized
INFO - 2021-12-11 05:36:07 --> URI Class Initialized
INFO - 2021-12-11 05:36:07 --> Router Class Initialized
INFO - 2021-12-11 05:36:07 --> Output Class Initialized
INFO - 2021-12-11 05:36:07 --> Security Class Initialized
DEBUG - 2021-12-11 05:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:36:07 --> Input Class Initialized
INFO - 2021-12-11 05:36:07 --> Language Class Initialized
INFO - 2021-12-11 05:36:07 --> Language Class Initialized
INFO - 2021-12-11 05:36:07 --> Config Class Initialized
INFO - 2021-12-11 05:36:07 --> Loader Class Initialized
INFO - 2021-12-11 05:36:07 --> Helper loaded: url_helper
INFO - 2021-12-11 05:36:07 --> Helper loaded: file_helper
INFO - 2021-12-11 05:36:07 --> Helper loaded: form_helper
INFO - 2021-12-11 05:36:07 --> Helper loaded: my_helper
INFO - 2021-12-11 05:36:07 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:36:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:36:07 --> Controller Class Initialized
DEBUG - 2021-12-11 05:36:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:36:07 --> Final output sent to browser
DEBUG - 2021-12-11 05:36:07 --> Total execution time: 0.0650
INFO - 2021-12-11 05:36:10 --> Config Class Initialized
INFO - 2021-12-11 05:36:10 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:36:10 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:36:10 --> Utf8 Class Initialized
INFO - 2021-12-11 05:36:10 --> URI Class Initialized
INFO - 2021-12-11 05:36:10 --> Router Class Initialized
INFO - 2021-12-11 05:36:10 --> Output Class Initialized
INFO - 2021-12-11 05:36:10 --> Security Class Initialized
DEBUG - 2021-12-11 05:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:36:10 --> Input Class Initialized
INFO - 2021-12-11 05:36:10 --> Language Class Initialized
INFO - 2021-12-11 05:36:10 --> Language Class Initialized
INFO - 2021-12-11 05:36:10 --> Config Class Initialized
INFO - 2021-12-11 05:36:10 --> Loader Class Initialized
INFO - 2021-12-11 05:36:10 --> Helper loaded: url_helper
INFO - 2021-12-11 05:36:10 --> Helper loaded: file_helper
INFO - 2021-12-11 05:36:10 --> Helper loaded: form_helper
INFO - 2021-12-11 05:36:10 --> Helper loaded: my_helper
INFO - 2021-12-11 05:36:10 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:36:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:36:10 --> Controller Class Initialized
DEBUG - 2021-12-11 05:36:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:36:10 --> Final output sent to browser
DEBUG - 2021-12-11 05:36:10 --> Total execution time: 0.0600
INFO - 2021-12-11 05:36:12 --> Config Class Initialized
INFO - 2021-12-11 05:36:12 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:36:12 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:36:12 --> Utf8 Class Initialized
INFO - 2021-12-11 05:36:12 --> URI Class Initialized
INFO - 2021-12-11 05:36:12 --> Router Class Initialized
INFO - 2021-12-11 05:36:12 --> Output Class Initialized
INFO - 2021-12-11 05:36:12 --> Security Class Initialized
DEBUG - 2021-12-11 05:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:36:12 --> Input Class Initialized
INFO - 2021-12-11 05:36:12 --> Language Class Initialized
INFO - 2021-12-11 05:36:12 --> Language Class Initialized
INFO - 2021-12-11 05:36:12 --> Config Class Initialized
INFO - 2021-12-11 05:36:12 --> Loader Class Initialized
INFO - 2021-12-11 05:36:12 --> Helper loaded: url_helper
INFO - 2021-12-11 05:36:12 --> Helper loaded: file_helper
INFO - 2021-12-11 05:36:12 --> Helper loaded: form_helper
INFO - 2021-12-11 05:36:12 --> Helper loaded: my_helper
INFO - 2021-12-11 05:36:12 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:36:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:36:12 --> Controller Class Initialized
DEBUG - 2021-12-11 05:36:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:36:12 --> Final output sent to browser
DEBUG - 2021-12-11 05:36:12 --> Total execution time: 0.0640
INFO - 2021-12-11 05:39:01 --> Config Class Initialized
INFO - 2021-12-11 05:39:01 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:39:01 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:39:01 --> Utf8 Class Initialized
INFO - 2021-12-11 05:39:01 --> URI Class Initialized
INFO - 2021-12-11 05:39:01 --> Router Class Initialized
INFO - 2021-12-11 05:39:01 --> Output Class Initialized
INFO - 2021-12-11 05:39:01 --> Security Class Initialized
DEBUG - 2021-12-11 05:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:39:01 --> Input Class Initialized
INFO - 2021-12-11 05:39:01 --> Language Class Initialized
INFO - 2021-12-11 05:39:01 --> Language Class Initialized
INFO - 2021-12-11 05:39:01 --> Config Class Initialized
INFO - 2021-12-11 05:39:01 --> Loader Class Initialized
INFO - 2021-12-11 05:39:01 --> Helper loaded: url_helper
INFO - 2021-12-11 05:39:01 --> Helper loaded: file_helper
INFO - 2021-12-11 05:39:01 --> Helper loaded: form_helper
INFO - 2021-12-11 05:39:01 --> Helper loaded: my_helper
INFO - 2021-12-11 05:39:01 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:39:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:39:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:39:01 --> Controller Class Initialized
INFO - 2021-12-11 05:39:01 --> Helper loaded: cookie_helper
INFO - 2021-12-11 05:39:01 --> Config Class Initialized
INFO - 2021-12-11 05:39:01 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:39:01 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:39:01 --> Utf8 Class Initialized
INFO - 2021-12-11 05:39:01 --> URI Class Initialized
INFO - 2021-12-11 05:39:01 --> Router Class Initialized
INFO - 2021-12-11 05:39:01 --> Output Class Initialized
INFO - 2021-12-11 05:39:01 --> Security Class Initialized
DEBUG - 2021-12-11 05:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:39:01 --> Input Class Initialized
INFO - 2021-12-11 05:39:01 --> Language Class Initialized
INFO - 2021-12-11 05:39:01 --> Language Class Initialized
INFO - 2021-12-11 05:39:01 --> Config Class Initialized
INFO - 2021-12-11 05:39:01 --> Loader Class Initialized
INFO - 2021-12-11 05:39:01 --> Helper loaded: url_helper
INFO - 2021-12-11 05:39:01 --> Helper loaded: file_helper
INFO - 2021-12-11 05:39:01 --> Helper loaded: form_helper
INFO - 2021-12-11 05:39:01 --> Helper loaded: my_helper
INFO - 2021-12-11 05:39:01 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:39:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:39:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:39:01 --> Controller Class Initialized
DEBUG - 2021-12-11 05:39:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-11 05:39:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-11 05:39:01 --> Final output sent to browser
DEBUG - 2021-12-11 05:39:01 --> Total execution time: 0.0340
INFO - 2021-12-11 05:39:07 --> Config Class Initialized
INFO - 2021-12-11 05:39:07 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:39:07 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:39:07 --> Utf8 Class Initialized
INFO - 2021-12-11 05:39:07 --> URI Class Initialized
INFO - 2021-12-11 05:39:07 --> Router Class Initialized
INFO - 2021-12-11 05:39:07 --> Output Class Initialized
INFO - 2021-12-11 05:39:07 --> Security Class Initialized
DEBUG - 2021-12-11 05:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:39:07 --> Input Class Initialized
INFO - 2021-12-11 05:39:07 --> Language Class Initialized
INFO - 2021-12-11 05:39:07 --> Language Class Initialized
INFO - 2021-12-11 05:39:07 --> Config Class Initialized
INFO - 2021-12-11 05:39:07 --> Loader Class Initialized
INFO - 2021-12-11 05:39:07 --> Helper loaded: url_helper
INFO - 2021-12-11 05:39:07 --> Helper loaded: file_helper
INFO - 2021-12-11 05:39:07 --> Helper loaded: form_helper
INFO - 2021-12-11 05:39:07 --> Helper loaded: my_helper
INFO - 2021-12-11 05:39:07 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:39:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:39:07 --> Controller Class Initialized
INFO - 2021-12-11 05:39:07 --> Helper loaded: cookie_helper
INFO - 2021-12-11 05:39:07 --> Final output sent to browser
DEBUG - 2021-12-11 05:39:07 --> Total execution time: 0.0410
INFO - 2021-12-11 05:39:07 --> Config Class Initialized
INFO - 2021-12-11 05:39:07 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:39:07 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:39:07 --> Utf8 Class Initialized
INFO - 2021-12-11 05:39:07 --> URI Class Initialized
INFO - 2021-12-11 05:39:07 --> Router Class Initialized
INFO - 2021-12-11 05:39:07 --> Output Class Initialized
INFO - 2021-12-11 05:39:07 --> Security Class Initialized
DEBUG - 2021-12-11 05:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:39:07 --> Input Class Initialized
INFO - 2021-12-11 05:39:07 --> Language Class Initialized
INFO - 2021-12-11 05:39:07 --> Language Class Initialized
INFO - 2021-12-11 05:39:07 --> Config Class Initialized
INFO - 2021-12-11 05:39:07 --> Loader Class Initialized
INFO - 2021-12-11 05:39:07 --> Helper loaded: url_helper
INFO - 2021-12-11 05:39:07 --> Helper loaded: file_helper
INFO - 2021-12-11 05:39:07 --> Helper loaded: form_helper
INFO - 2021-12-11 05:39:07 --> Helper loaded: my_helper
INFO - 2021-12-11 05:39:07 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:39:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:39:07 --> Controller Class Initialized
DEBUG - 2021-12-11 05:39:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-11 05:39:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-11 05:39:07 --> Final output sent to browser
DEBUG - 2021-12-11 05:39:07 --> Total execution time: 0.2200
INFO - 2021-12-11 05:39:12 --> Config Class Initialized
INFO - 2021-12-11 05:39:12 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:39:12 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:39:12 --> Utf8 Class Initialized
INFO - 2021-12-11 05:39:12 --> URI Class Initialized
INFO - 2021-12-11 05:39:12 --> Router Class Initialized
INFO - 2021-12-11 05:39:12 --> Output Class Initialized
INFO - 2021-12-11 05:39:12 --> Security Class Initialized
DEBUG - 2021-12-11 05:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:39:12 --> Input Class Initialized
INFO - 2021-12-11 05:39:12 --> Language Class Initialized
INFO - 2021-12-11 05:39:12 --> Language Class Initialized
INFO - 2021-12-11 05:39:12 --> Config Class Initialized
INFO - 2021-12-11 05:39:12 --> Loader Class Initialized
INFO - 2021-12-11 05:39:12 --> Helper loaded: url_helper
INFO - 2021-12-11 05:39:12 --> Helper loaded: file_helper
INFO - 2021-12-11 05:39:12 --> Helper loaded: form_helper
INFO - 2021-12-11 05:39:12 --> Helper loaded: my_helper
INFO - 2021-12-11 05:39:12 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:39:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:39:12 --> Controller Class Initialized
DEBUG - 2021-12-11 05:39:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-11 05:39:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-11 05:39:12 --> Final output sent to browser
DEBUG - 2021-12-11 05:39:12 --> Total execution time: 0.0590
INFO - 2021-12-11 05:39:17 --> Config Class Initialized
INFO - 2021-12-11 05:39:17 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:39:17 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:39:17 --> Utf8 Class Initialized
INFO - 2021-12-11 05:39:17 --> URI Class Initialized
INFO - 2021-12-11 05:39:17 --> Router Class Initialized
INFO - 2021-12-11 05:39:17 --> Output Class Initialized
INFO - 2021-12-11 05:39:17 --> Security Class Initialized
DEBUG - 2021-12-11 05:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:39:17 --> Input Class Initialized
INFO - 2021-12-11 05:39:17 --> Language Class Initialized
INFO - 2021-12-11 05:39:17 --> Language Class Initialized
INFO - 2021-12-11 05:39:17 --> Config Class Initialized
INFO - 2021-12-11 05:39:17 --> Loader Class Initialized
INFO - 2021-12-11 05:39:17 --> Helper loaded: url_helper
INFO - 2021-12-11 05:39:17 --> Helper loaded: file_helper
INFO - 2021-12-11 05:39:17 --> Helper loaded: form_helper
INFO - 2021-12-11 05:39:17 --> Helper loaded: my_helper
INFO - 2021-12-11 05:39:17 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:39:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:39:17 --> Controller Class Initialized
DEBUG - 2021-12-11 05:39:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:39:18 --> Final output sent to browser
DEBUG - 2021-12-11 05:39:18 --> Total execution time: 0.1040
INFO - 2021-12-11 05:39:19 --> Config Class Initialized
INFO - 2021-12-11 05:39:19 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:39:19 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:39:19 --> Utf8 Class Initialized
INFO - 2021-12-11 05:39:19 --> URI Class Initialized
INFO - 2021-12-11 05:39:19 --> Router Class Initialized
INFO - 2021-12-11 05:39:19 --> Output Class Initialized
INFO - 2021-12-11 05:39:19 --> Security Class Initialized
DEBUG - 2021-12-11 05:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:39:19 --> Input Class Initialized
INFO - 2021-12-11 05:39:19 --> Language Class Initialized
INFO - 2021-12-11 05:39:19 --> Language Class Initialized
INFO - 2021-12-11 05:39:19 --> Config Class Initialized
INFO - 2021-12-11 05:39:19 --> Loader Class Initialized
INFO - 2021-12-11 05:39:19 --> Helper loaded: url_helper
INFO - 2021-12-11 05:39:19 --> Helper loaded: file_helper
INFO - 2021-12-11 05:39:19 --> Helper loaded: form_helper
INFO - 2021-12-11 05:39:19 --> Helper loaded: my_helper
INFO - 2021-12-11 05:39:19 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:39:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:39:19 --> Controller Class Initialized
DEBUG - 2021-12-11 05:39:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:39:19 --> Final output sent to browser
DEBUG - 2021-12-11 05:39:19 --> Total execution time: 0.0670
INFO - 2021-12-11 05:39:21 --> Config Class Initialized
INFO - 2021-12-11 05:39:21 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:39:21 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:39:21 --> Utf8 Class Initialized
INFO - 2021-12-11 05:39:21 --> URI Class Initialized
INFO - 2021-12-11 05:39:21 --> Router Class Initialized
INFO - 2021-12-11 05:39:21 --> Output Class Initialized
INFO - 2021-12-11 05:39:21 --> Security Class Initialized
DEBUG - 2021-12-11 05:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:39:21 --> Input Class Initialized
INFO - 2021-12-11 05:39:21 --> Language Class Initialized
INFO - 2021-12-11 05:39:21 --> Language Class Initialized
INFO - 2021-12-11 05:39:21 --> Config Class Initialized
INFO - 2021-12-11 05:39:21 --> Loader Class Initialized
INFO - 2021-12-11 05:39:21 --> Helper loaded: url_helper
INFO - 2021-12-11 05:39:21 --> Helper loaded: file_helper
INFO - 2021-12-11 05:39:21 --> Helper loaded: form_helper
INFO - 2021-12-11 05:39:21 --> Helper loaded: my_helper
INFO - 2021-12-11 05:39:21 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:39:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:39:21 --> Controller Class Initialized
DEBUG - 2021-12-11 05:39:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:39:22 --> Final output sent to browser
DEBUG - 2021-12-11 05:39:22 --> Total execution time: 0.0650
INFO - 2021-12-11 05:39:23 --> Config Class Initialized
INFO - 2021-12-11 05:39:23 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:39:23 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:39:23 --> Utf8 Class Initialized
INFO - 2021-12-11 05:39:23 --> URI Class Initialized
INFO - 2021-12-11 05:39:23 --> Router Class Initialized
INFO - 2021-12-11 05:39:23 --> Output Class Initialized
INFO - 2021-12-11 05:39:23 --> Security Class Initialized
DEBUG - 2021-12-11 05:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:39:23 --> Input Class Initialized
INFO - 2021-12-11 05:39:23 --> Language Class Initialized
INFO - 2021-12-11 05:39:23 --> Language Class Initialized
INFO - 2021-12-11 05:39:23 --> Config Class Initialized
INFO - 2021-12-11 05:39:23 --> Loader Class Initialized
INFO - 2021-12-11 05:39:23 --> Helper loaded: url_helper
INFO - 2021-12-11 05:39:23 --> Helper loaded: file_helper
INFO - 2021-12-11 05:39:23 --> Helper loaded: form_helper
INFO - 2021-12-11 05:39:23 --> Helper loaded: my_helper
INFO - 2021-12-11 05:39:23 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:39:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:39:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:39:23 --> Controller Class Initialized
DEBUG - 2021-12-11 05:39:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-11 05:39:23 --> Final output sent to browser
DEBUG - 2021-12-11 05:39:23 --> Total execution time: 0.0760
INFO - 2021-12-11 05:40:17 --> Config Class Initialized
INFO - 2021-12-11 05:40:17 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:40:17 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:40:17 --> Utf8 Class Initialized
INFO - 2021-12-11 05:40:17 --> URI Class Initialized
INFO - 2021-12-11 05:40:17 --> Router Class Initialized
INFO - 2021-12-11 05:40:17 --> Output Class Initialized
INFO - 2021-12-11 05:40:17 --> Security Class Initialized
DEBUG - 2021-12-11 05:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:40:17 --> Input Class Initialized
INFO - 2021-12-11 05:40:17 --> Language Class Initialized
INFO - 2021-12-11 05:40:17 --> Language Class Initialized
INFO - 2021-12-11 05:40:17 --> Config Class Initialized
INFO - 2021-12-11 05:40:17 --> Loader Class Initialized
INFO - 2021-12-11 05:40:17 --> Helper loaded: url_helper
INFO - 2021-12-11 05:40:17 --> Helper loaded: file_helper
INFO - 2021-12-11 05:40:17 --> Helper loaded: form_helper
INFO - 2021-12-11 05:40:17 --> Helper loaded: my_helper
INFO - 2021-12-11 05:40:17 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:40:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:40:17 --> Controller Class Initialized
INFO - 2021-12-11 05:40:17 --> Helper loaded: cookie_helper
INFO - 2021-12-11 05:40:17 --> Config Class Initialized
INFO - 2021-12-11 05:40:17 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:40:17 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:40:17 --> Utf8 Class Initialized
INFO - 2021-12-11 05:40:17 --> URI Class Initialized
INFO - 2021-12-11 05:40:17 --> Router Class Initialized
INFO - 2021-12-11 05:40:17 --> Output Class Initialized
INFO - 2021-12-11 05:40:17 --> Security Class Initialized
DEBUG - 2021-12-11 05:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:40:17 --> Input Class Initialized
INFO - 2021-12-11 05:40:17 --> Language Class Initialized
INFO - 2021-12-11 05:40:17 --> Language Class Initialized
INFO - 2021-12-11 05:40:17 --> Config Class Initialized
INFO - 2021-12-11 05:40:17 --> Loader Class Initialized
INFO - 2021-12-11 05:40:17 --> Helper loaded: url_helper
INFO - 2021-12-11 05:40:17 --> Helper loaded: file_helper
INFO - 2021-12-11 05:40:17 --> Helper loaded: form_helper
INFO - 2021-12-11 05:40:17 --> Helper loaded: my_helper
INFO - 2021-12-11 05:40:17 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:40:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:40:17 --> Controller Class Initialized
DEBUG - 2021-12-11 05:40:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-11 05:40:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-11 05:40:17 --> Final output sent to browser
DEBUG - 2021-12-11 05:40:17 --> Total execution time: 0.0570
INFO - 2021-12-11 05:40:22 --> Config Class Initialized
INFO - 2021-12-11 05:40:22 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:40:22 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:40:22 --> Utf8 Class Initialized
INFO - 2021-12-11 05:40:22 --> URI Class Initialized
INFO - 2021-12-11 05:40:22 --> Router Class Initialized
INFO - 2021-12-11 05:40:22 --> Output Class Initialized
INFO - 2021-12-11 05:40:22 --> Security Class Initialized
DEBUG - 2021-12-11 05:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:40:22 --> Input Class Initialized
INFO - 2021-12-11 05:40:22 --> Language Class Initialized
INFO - 2021-12-11 05:40:22 --> Language Class Initialized
INFO - 2021-12-11 05:40:22 --> Config Class Initialized
INFO - 2021-12-11 05:40:22 --> Loader Class Initialized
INFO - 2021-12-11 05:40:22 --> Helper loaded: url_helper
INFO - 2021-12-11 05:40:22 --> Helper loaded: file_helper
INFO - 2021-12-11 05:40:22 --> Helper loaded: form_helper
INFO - 2021-12-11 05:40:22 --> Helper loaded: my_helper
INFO - 2021-12-11 05:40:22 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:40:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:40:22 --> Controller Class Initialized
INFO - 2021-12-11 05:40:22 --> Helper loaded: cookie_helper
INFO - 2021-12-11 05:40:22 --> Final output sent to browser
DEBUG - 2021-12-11 05:40:22 --> Total execution time: 0.0550
INFO - 2021-12-11 05:40:22 --> Config Class Initialized
INFO - 2021-12-11 05:40:22 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:40:22 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:40:22 --> Utf8 Class Initialized
INFO - 2021-12-11 05:40:22 --> URI Class Initialized
INFO - 2021-12-11 05:40:22 --> Router Class Initialized
INFO - 2021-12-11 05:40:22 --> Output Class Initialized
INFO - 2021-12-11 05:40:22 --> Security Class Initialized
DEBUG - 2021-12-11 05:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:40:22 --> Input Class Initialized
INFO - 2021-12-11 05:40:22 --> Language Class Initialized
INFO - 2021-12-11 05:40:22 --> Language Class Initialized
INFO - 2021-12-11 05:40:22 --> Config Class Initialized
INFO - 2021-12-11 05:40:22 --> Loader Class Initialized
INFO - 2021-12-11 05:40:22 --> Helper loaded: url_helper
INFO - 2021-12-11 05:40:22 --> Helper loaded: file_helper
INFO - 2021-12-11 05:40:22 --> Helper loaded: form_helper
INFO - 2021-12-11 05:40:22 --> Helper loaded: my_helper
INFO - 2021-12-11 05:40:22 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:40:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:40:22 --> Controller Class Initialized
DEBUG - 2021-12-11 05:40:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-11 05:40:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-11 05:40:22 --> Final output sent to browser
DEBUG - 2021-12-11 05:40:22 --> Total execution time: 0.2040
INFO - 2021-12-11 05:40:24 --> Config Class Initialized
INFO - 2021-12-11 05:40:24 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:40:24 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:40:24 --> Utf8 Class Initialized
INFO - 2021-12-11 05:40:24 --> URI Class Initialized
INFO - 2021-12-11 05:40:24 --> Router Class Initialized
INFO - 2021-12-11 05:40:24 --> Output Class Initialized
INFO - 2021-12-11 05:40:24 --> Security Class Initialized
DEBUG - 2021-12-11 05:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:40:24 --> Input Class Initialized
INFO - 2021-12-11 05:40:24 --> Language Class Initialized
INFO - 2021-12-11 05:40:24 --> Language Class Initialized
INFO - 2021-12-11 05:40:24 --> Config Class Initialized
INFO - 2021-12-11 05:40:24 --> Loader Class Initialized
INFO - 2021-12-11 05:40:24 --> Helper loaded: url_helper
INFO - 2021-12-11 05:40:24 --> Helper loaded: file_helper
INFO - 2021-12-11 05:40:24 --> Helper loaded: form_helper
INFO - 2021-12-11 05:40:24 --> Helper loaded: my_helper
INFO - 2021-12-11 05:40:24 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:40:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:40:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:40:24 --> Controller Class Initialized
DEBUG - 2021-12-11 05:40:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-11 05:40:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-11 05:40:24 --> Final output sent to browser
DEBUG - 2021-12-11 05:40:24 --> Total execution time: 0.0640
INFO - 2021-12-11 05:40:28 --> Config Class Initialized
INFO - 2021-12-11 05:40:28 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:40:28 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:40:28 --> Utf8 Class Initialized
INFO - 2021-12-11 05:40:28 --> URI Class Initialized
INFO - 2021-12-11 05:40:28 --> Router Class Initialized
INFO - 2021-12-11 05:40:28 --> Output Class Initialized
INFO - 2021-12-11 05:40:28 --> Security Class Initialized
DEBUG - 2021-12-11 05:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:40:28 --> Input Class Initialized
INFO - 2021-12-11 05:40:28 --> Language Class Initialized
INFO - 2021-12-11 05:40:28 --> Language Class Initialized
INFO - 2021-12-11 05:40:28 --> Config Class Initialized
INFO - 2021-12-11 05:40:28 --> Loader Class Initialized
INFO - 2021-12-11 05:40:28 --> Helper loaded: url_helper
INFO - 2021-12-11 05:40:28 --> Helper loaded: file_helper
INFO - 2021-12-11 05:40:28 --> Helper loaded: form_helper
INFO - 2021-12-11 05:40:28 --> Helper loaded: my_helper
INFO - 2021-12-11 05:40:28 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:40:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:40:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:40:28 --> Controller Class Initialized
DEBUG - 2021-12-11 05:40:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-12-11 05:40:28 --> Final output sent to browser
DEBUG - 2021-12-11 05:40:28 --> Total execution time: 0.1070
INFO - 2021-12-11 05:40:30 --> Config Class Initialized
INFO - 2021-12-11 05:40:30 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:40:30 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:40:30 --> Utf8 Class Initialized
INFO - 2021-12-11 05:40:30 --> URI Class Initialized
INFO - 2021-12-11 05:40:30 --> Router Class Initialized
INFO - 2021-12-11 05:40:30 --> Output Class Initialized
INFO - 2021-12-11 05:40:30 --> Security Class Initialized
DEBUG - 2021-12-11 05:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:40:30 --> Input Class Initialized
INFO - 2021-12-11 05:40:30 --> Language Class Initialized
INFO - 2021-12-11 05:40:30 --> Language Class Initialized
INFO - 2021-12-11 05:40:30 --> Config Class Initialized
INFO - 2021-12-11 05:40:30 --> Loader Class Initialized
INFO - 2021-12-11 05:40:30 --> Helper loaded: url_helper
INFO - 2021-12-11 05:40:30 --> Helper loaded: file_helper
INFO - 2021-12-11 05:40:30 --> Helper loaded: form_helper
INFO - 2021-12-11 05:40:30 --> Helper loaded: my_helper
INFO - 2021-12-11 05:40:30 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:40:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:40:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:40:30 --> Controller Class Initialized
DEBUG - 2021-12-11 05:40:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-12-11 05:40:30 --> Final output sent to browser
DEBUG - 2021-12-11 05:40:30 --> Total execution time: 0.0590
INFO - 2021-12-11 05:40:32 --> Config Class Initialized
INFO - 2021-12-11 05:40:32 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:40:32 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:40:32 --> Utf8 Class Initialized
INFO - 2021-12-11 05:40:32 --> URI Class Initialized
INFO - 2021-12-11 05:40:32 --> Router Class Initialized
INFO - 2021-12-11 05:40:32 --> Output Class Initialized
INFO - 2021-12-11 05:40:32 --> Security Class Initialized
DEBUG - 2021-12-11 05:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:40:32 --> Input Class Initialized
INFO - 2021-12-11 05:40:32 --> Language Class Initialized
INFO - 2021-12-11 05:40:32 --> Language Class Initialized
INFO - 2021-12-11 05:40:32 --> Config Class Initialized
INFO - 2021-12-11 05:40:32 --> Loader Class Initialized
INFO - 2021-12-11 05:40:32 --> Helper loaded: url_helper
INFO - 2021-12-11 05:40:32 --> Helper loaded: file_helper
INFO - 2021-12-11 05:40:32 --> Helper loaded: form_helper
INFO - 2021-12-11 05:40:32 --> Helper loaded: my_helper
INFO - 2021-12-11 05:40:32 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:40:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:40:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:40:32 --> Controller Class Initialized
DEBUG - 2021-12-11 05:40:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-12-11 05:40:32 --> Final output sent to browser
DEBUG - 2021-12-11 05:40:32 --> Total execution time: 0.0600
INFO - 2021-12-11 05:40:34 --> Config Class Initialized
INFO - 2021-12-11 05:40:34 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:40:34 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:40:34 --> Utf8 Class Initialized
INFO - 2021-12-11 05:40:34 --> URI Class Initialized
INFO - 2021-12-11 05:40:34 --> Router Class Initialized
INFO - 2021-12-11 05:40:34 --> Output Class Initialized
INFO - 2021-12-11 05:40:34 --> Security Class Initialized
DEBUG - 2021-12-11 05:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:40:34 --> Input Class Initialized
INFO - 2021-12-11 05:40:34 --> Language Class Initialized
INFO - 2021-12-11 05:40:34 --> Language Class Initialized
INFO - 2021-12-11 05:40:34 --> Config Class Initialized
INFO - 2021-12-11 05:40:34 --> Loader Class Initialized
INFO - 2021-12-11 05:40:34 --> Helper loaded: url_helper
INFO - 2021-12-11 05:40:34 --> Helper loaded: file_helper
INFO - 2021-12-11 05:40:34 --> Helper loaded: form_helper
INFO - 2021-12-11 05:40:34 --> Helper loaded: my_helper
INFO - 2021-12-11 05:40:34 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:40:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:40:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:40:34 --> Controller Class Initialized
DEBUG - 2021-12-11 05:40:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-12-11 05:40:34 --> Final output sent to browser
DEBUG - 2021-12-11 05:40:34 --> Total execution time: 0.0690
INFO - 2021-12-11 05:40:36 --> Config Class Initialized
INFO - 2021-12-11 05:40:36 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:40:36 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:40:36 --> Utf8 Class Initialized
INFO - 2021-12-11 05:40:36 --> URI Class Initialized
INFO - 2021-12-11 05:40:36 --> Router Class Initialized
INFO - 2021-12-11 05:40:36 --> Output Class Initialized
INFO - 2021-12-11 05:40:36 --> Security Class Initialized
DEBUG - 2021-12-11 05:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:40:36 --> Input Class Initialized
INFO - 2021-12-11 05:40:36 --> Language Class Initialized
INFO - 2021-12-11 05:40:36 --> Language Class Initialized
INFO - 2021-12-11 05:40:36 --> Config Class Initialized
INFO - 2021-12-11 05:40:36 --> Loader Class Initialized
INFO - 2021-12-11 05:40:36 --> Helper loaded: url_helper
INFO - 2021-12-11 05:40:36 --> Helper loaded: file_helper
INFO - 2021-12-11 05:40:36 --> Helper loaded: form_helper
INFO - 2021-12-11 05:40:36 --> Helper loaded: my_helper
INFO - 2021-12-11 05:40:36 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:40:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:40:36 --> Controller Class Initialized
DEBUG - 2021-12-11 05:40:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-12-11 05:40:36 --> Final output sent to browser
DEBUG - 2021-12-11 05:40:36 --> Total execution time: 0.0620
INFO - 2021-12-11 05:40:37 --> Config Class Initialized
INFO - 2021-12-11 05:40:37 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:40:37 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:40:37 --> Utf8 Class Initialized
INFO - 2021-12-11 05:40:37 --> URI Class Initialized
INFO - 2021-12-11 05:40:37 --> Router Class Initialized
INFO - 2021-12-11 05:40:37 --> Output Class Initialized
INFO - 2021-12-11 05:40:37 --> Security Class Initialized
DEBUG - 2021-12-11 05:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:40:37 --> Input Class Initialized
INFO - 2021-12-11 05:40:37 --> Language Class Initialized
INFO - 2021-12-11 05:40:37 --> Language Class Initialized
INFO - 2021-12-11 05:40:37 --> Config Class Initialized
INFO - 2021-12-11 05:40:37 --> Loader Class Initialized
INFO - 2021-12-11 05:40:37 --> Helper loaded: url_helper
INFO - 2021-12-11 05:40:37 --> Helper loaded: file_helper
INFO - 2021-12-11 05:40:37 --> Helper loaded: form_helper
INFO - 2021-12-11 05:40:37 --> Helper loaded: my_helper
INFO - 2021-12-11 05:40:37 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:40:37 --> Controller Class Initialized
DEBUG - 2021-12-11 05:40:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-12-11 05:40:38 --> Final output sent to browser
DEBUG - 2021-12-11 05:40:38 --> Total execution time: 0.0640
INFO - 2021-12-11 05:40:40 --> Config Class Initialized
INFO - 2021-12-11 05:40:40 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:40:40 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:40:40 --> Utf8 Class Initialized
INFO - 2021-12-11 05:40:40 --> URI Class Initialized
INFO - 2021-12-11 05:40:40 --> Router Class Initialized
INFO - 2021-12-11 05:40:40 --> Output Class Initialized
INFO - 2021-12-11 05:40:40 --> Security Class Initialized
DEBUG - 2021-12-11 05:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:40:40 --> Input Class Initialized
INFO - 2021-12-11 05:40:40 --> Language Class Initialized
INFO - 2021-12-11 05:40:40 --> Language Class Initialized
INFO - 2021-12-11 05:40:40 --> Config Class Initialized
INFO - 2021-12-11 05:40:40 --> Loader Class Initialized
INFO - 2021-12-11 05:40:40 --> Helper loaded: url_helper
INFO - 2021-12-11 05:40:40 --> Helper loaded: file_helper
INFO - 2021-12-11 05:40:40 --> Helper loaded: form_helper
INFO - 2021-12-11 05:40:40 --> Helper loaded: my_helper
INFO - 2021-12-11 05:40:40 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:40:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:40:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:40:40 --> Controller Class Initialized
DEBUG - 2021-12-11 05:40:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-12-11 05:40:40 --> Final output sent to browser
DEBUG - 2021-12-11 05:40:40 --> Total execution time: 0.0630
INFO - 2021-12-11 05:40:41 --> Config Class Initialized
INFO - 2021-12-11 05:40:41 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:40:41 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:40:41 --> Utf8 Class Initialized
INFO - 2021-12-11 05:40:41 --> URI Class Initialized
INFO - 2021-12-11 05:40:41 --> Router Class Initialized
INFO - 2021-12-11 05:40:41 --> Output Class Initialized
INFO - 2021-12-11 05:40:41 --> Security Class Initialized
DEBUG - 2021-12-11 05:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:40:41 --> Input Class Initialized
INFO - 2021-12-11 05:40:41 --> Language Class Initialized
INFO - 2021-12-11 05:40:41 --> Language Class Initialized
INFO - 2021-12-11 05:40:41 --> Config Class Initialized
INFO - 2021-12-11 05:40:41 --> Loader Class Initialized
INFO - 2021-12-11 05:40:41 --> Helper loaded: url_helper
INFO - 2021-12-11 05:40:41 --> Helper loaded: file_helper
INFO - 2021-12-11 05:40:41 --> Helper loaded: form_helper
INFO - 2021-12-11 05:40:41 --> Helper loaded: my_helper
INFO - 2021-12-11 05:40:41 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:40:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:40:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:40:41 --> Controller Class Initialized
DEBUG - 2021-12-11 05:40:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-12-11 05:40:41 --> Final output sent to browser
DEBUG - 2021-12-11 05:40:41 --> Total execution time: 0.0640
INFO - 2021-12-11 05:40:44 --> Config Class Initialized
INFO - 2021-12-11 05:40:44 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:40:44 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:40:44 --> Utf8 Class Initialized
INFO - 2021-12-11 05:40:44 --> URI Class Initialized
INFO - 2021-12-11 05:40:44 --> Router Class Initialized
INFO - 2021-12-11 05:40:44 --> Output Class Initialized
INFO - 2021-12-11 05:40:44 --> Security Class Initialized
DEBUG - 2021-12-11 05:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:40:44 --> Input Class Initialized
INFO - 2021-12-11 05:40:44 --> Language Class Initialized
INFO - 2021-12-11 05:40:44 --> Language Class Initialized
INFO - 2021-12-11 05:40:44 --> Config Class Initialized
INFO - 2021-12-11 05:40:44 --> Loader Class Initialized
INFO - 2021-12-11 05:40:44 --> Helper loaded: url_helper
INFO - 2021-12-11 05:40:44 --> Helper loaded: file_helper
INFO - 2021-12-11 05:40:44 --> Helper loaded: form_helper
INFO - 2021-12-11 05:40:44 --> Helper loaded: my_helper
INFO - 2021-12-11 05:40:44 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:40:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:40:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:40:44 --> Controller Class Initialized
DEBUG - 2021-12-11 05:40:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-12-11 05:40:44 --> Final output sent to browser
DEBUG - 2021-12-11 05:40:44 --> Total execution time: 0.0630
INFO - 2021-12-11 05:40:46 --> Config Class Initialized
INFO - 2021-12-11 05:40:46 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:40:46 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:40:46 --> Utf8 Class Initialized
INFO - 2021-12-11 05:40:46 --> URI Class Initialized
INFO - 2021-12-11 05:40:46 --> Router Class Initialized
INFO - 2021-12-11 05:40:46 --> Output Class Initialized
INFO - 2021-12-11 05:40:46 --> Security Class Initialized
DEBUG - 2021-12-11 05:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:40:46 --> Input Class Initialized
INFO - 2021-12-11 05:40:46 --> Language Class Initialized
INFO - 2021-12-11 05:40:46 --> Language Class Initialized
INFO - 2021-12-11 05:40:46 --> Config Class Initialized
INFO - 2021-12-11 05:40:46 --> Loader Class Initialized
INFO - 2021-12-11 05:40:46 --> Helper loaded: url_helper
INFO - 2021-12-11 05:40:46 --> Helper loaded: file_helper
INFO - 2021-12-11 05:40:46 --> Helper loaded: form_helper
INFO - 2021-12-11 05:40:46 --> Helper loaded: my_helper
INFO - 2021-12-11 05:40:46 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:40:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:40:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:40:46 --> Controller Class Initialized
DEBUG - 2021-12-11 05:40:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-12-11 05:40:46 --> Final output sent to browser
DEBUG - 2021-12-11 05:40:46 --> Total execution time: 0.0630
INFO - 2021-12-11 05:40:47 --> Config Class Initialized
INFO - 2021-12-11 05:40:47 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:40:47 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:40:47 --> Utf8 Class Initialized
INFO - 2021-12-11 05:40:47 --> URI Class Initialized
INFO - 2021-12-11 05:40:47 --> Router Class Initialized
INFO - 2021-12-11 05:40:47 --> Output Class Initialized
INFO - 2021-12-11 05:40:47 --> Security Class Initialized
DEBUG - 2021-12-11 05:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:40:47 --> Input Class Initialized
INFO - 2021-12-11 05:40:47 --> Language Class Initialized
INFO - 2021-12-11 05:40:47 --> Language Class Initialized
INFO - 2021-12-11 05:40:47 --> Config Class Initialized
INFO - 2021-12-11 05:40:47 --> Loader Class Initialized
INFO - 2021-12-11 05:40:47 --> Helper loaded: url_helper
INFO - 2021-12-11 05:40:47 --> Helper loaded: file_helper
INFO - 2021-12-11 05:40:47 --> Helper loaded: form_helper
INFO - 2021-12-11 05:40:47 --> Helper loaded: my_helper
INFO - 2021-12-11 05:40:47 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:40:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:40:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:40:47 --> Controller Class Initialized
DEBUG - 2021-12-11 05:40:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-12-11 05:40:47 --> Final output sent to browser
DEBUG - 2021-12-11 05:40:47 --> Total execution time: 0.0700
INFO - 2021-12-11 05:40:50 --> Config Class Initialized
INFO - 2021-12-11 05:40:50 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:40:50 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:40:50 --> Utf8 Class Initialized
INFO - 2021-12-11 05:40:50 --> URI Class Initialized
INFO - 2021-12-11 05:40:50 --> Router Class Initialized
INFO - 2021-12-11 05:40:50 --> Output Class Initialized
INFO - 2021-12-11 05:40:50 --> Security Class Initialized
DEBUG - 2021-12-11 05:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:40:50 --> Input Class Initialized
INFO - 2021-12-11 05:40:50 --> Language Class Initialized
INFO - 2021-12-11 05:40:50 --> Language Class Initialized
INFO - 2021-12-11 05:40:50 --> Config Class Initialized
INFO - 2021-12-11 05:40:50 --> Loader Class Initialized
INFO - 2021-12-11 05:40:50 --> Helper loaded: url_helper
INFO - 2021-12-11 05:40:50 --> Helper loaded: file_helper
INFO - 2021-12-11 05:40:50 --> Helper loaded: form_helper
INFO - 2021-12-11 05:40:50 --> Helper loaded: my_helper
INFO - 2021-12-11 05:40:50 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:40:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:40:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:40:50 --> Controller Class Initialized
DEBUG - 2021-12-11 05:40:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-12-11 05:40:50 --> Final output sent to browser
DEBUG - 2021-12-11 05:40:50 --> Total execution time: 0.0660
INFO - 2021-12-11 05:40:52 --> Config Class Initialized
INFO - 2021-12-11 05:40:52 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:40:52 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:40:52 --> Utf8 Class Initialized
INFO - 2021-12-11 05:40:52 --> URI Class Initialized
INFO - 2021-12-11 05:40:52 --> Router Class Initialized
INFO - 2021-12-11 05:40:52 --> Output Class Initialized
INFO - 2021-12-11 05:40:52 --> Security Class Initialized
DEBUG - 2021-12-11 05:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:40:52 --> Input Class Initialized
INFO - 2021-12-11 05:40:52 --> Language Class Initialized
INFO - 2021-12-11 05:40:52 --> Language Class Initialized
INFO - 2021-12-11 05:40:52 --> Config Class Initialized
INFO - 2021-12-11 05:40:52 --> Loader Class Initialized
INFO - 2021-12-11 05:40:52 --> Helper loaded: url_helper
INFO - 2021-12-11 05:40:52 --> Helper loaded: file_helper
INFO - 2021-12-11 05:40:52 --> Helper loaded: form_helper
INFO - 2021-12-11 05:40:52 --> Helper loaded: my_helper
INFO - 2021-12-11 05:40:52 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:40:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:40:52 --> Controller Class Initialized
DEBUG - 2021-12-11 05:40:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-12-11 05:40:52 --> Final output sent to browser
DEBUG - 2021-12-11 05:40:52 --> Total execution time: 0.0630
INFO - 2021-12-11 05:40:53 --> Config Class Initialized
INFO - 2021-12-11 05:40:53 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:40:53 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:40:53 --> Utf8 Class Initialized
INFO - 2021-12-11 05:40:53 --> URI Class Initialized
INFO - 2021-12-11 05:40:53 --> Router Class Initialized
INFO - 2021-12-11 05:40:53 --> Output Class Initialized
INFO - 2021-12-11 05:40:53 --> Security Class Initialized
DEBUG - 2021-12-11 05:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:40:53 --> Input Class Initialized
INFO - 2021-12-11 05:40:53 --> Language Class Initialized
INFO - 2021-12-11 05:40:53 --> Language Class Initialized
INFO - 2021-12-11 05:40:53 --> Config Class Initialized
INFO - 2021-12-11 05:40:53 --> Loader Class Initialized
INFO - 2021-12-11 05:40:53 --> Helper loaded: url_helper
INFO - 2021-12-11 05:40:53 --> Helper loaded: file_helper
INFO - 2021-12-11 05:40:53 --> Helper loaded: form_helper
INFO - 2021-12-11 05:40:53 --> Helper loaded: my_helper
INFO - 2021-12-11 05:40:53 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:40:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:40:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:40:53 --> Controller Class Initialized
DEBUG - 2021-12-11 05:40:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-12-11 05:40:53 --> Final output sent to browser
DEBUG - 2021-12-11 05:40:53 --> Total execution time: 0.0690
INFO - 2021-12-11 05:40:56 --> Config Class Initialized
INFO - 2021-12-11 05:40:56 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:40:56 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:40:56 --> Utf8 Class Initialized
INFO - 2021-12-11 05:40:56 --> URI Class Initialized
INFO - 2021-12-11 05:40:56 --> Router Class Initialized
INFO - 2021-12-11 05:40:56 --> Output Class Initialized
INFO - 2021-12-11 05:40:56 --> Security Class Initialized
DEBUG - 2021-12-11 05:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:40:56 --> Input Class Initialized
INFO - 2021-12-11 05:40:56 --> Language Class Initialized
INFO - 2021-12-11 05:40:56 --> Language Class Initialized
INFO - 2021-12-11 05:40:56 --> Config Class Initialized
INFO - 2021-12-11 05:40:56 --> Loader Class Initialized
INFO - 2021-12-11 05:40:56 --> Helper loaded: url_helper
INFO - 2021-12-11 05:40:56 --> Helper loaded: file_helper
INFO - 2021-12-11 05:40:56 --> Helper loaded: form_helper
INFO - 2021-12-11 05:40:56 --> Helper loaded: my_helper
INFO - 2021-12-11 05:40:56 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:40:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:40:56 --> Controller Class Initialized
DEBUG - 2021-12-11 05:40:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-12-11 05:40:56 --> Final output sent to browser
DEBUG - 2021-12-11 05:40:56 --> Total execution time: 0.0680
INFO - 2021-12-11 05:40:58 --> Config Class Initialized
INFO - 2021-12-11 05:40:58 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:40:58 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:40:58 --> Utf8 Class Initialized
INFO - 2021-12-11 05:40:58 --> URI Class Initialized
INFO - 2021-12-11 05:40:58 --> Router Class Initialized
INFO - 2021-12-11 05:40:58 --> Output Class Initialized
INFO - 2021-12-11 05:40:58 --> Security Class Initialized
DEBUG - 2021-12-11 05:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:40:58 --> Input Class Initialized
INFO - 2021-12-11 05:40:58 --> Language Class Initialized
INFO - 2021-12-11 05:40:58 --> Language Class Initialized
INFO - 2021-12-11 05:40:58 --> Config Class Initialized
INFO - 2021-12-11 05:40:58 --> Loader Class Initialized
INFO - 2021-12-11 05:40:58 --> Helper loaded: url_helper
INFO - 2021-12-11 05:40:58 --> Helper loaded: file_helper
INFO - 2021-12-11 05:40:58 --> Helper loaded: form_helper
INFO - 2021-12-11 05:40:58 --> Helper loaded: my_helper
INFO - 2021-12-11 05:40:58 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:40:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:40:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:40:58 --> Controller Class Initialized
DEBUG - 2021-12-11 05:40:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-12-11 05:40:58 --> Final output sent to browser
DEBUG - 2021-12-11 05:40:58 --> Total execution time: 0.0630
INFO - 2021-12-11 05:41:49 --> Config Class Initialized
INFO - 2021-12-11 05:41:49 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:41:49 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:41:49 --> Utf8 Class Initialized
INFO - 2021-12-11 05:41:49 --> URI Class Initialized
INFO - 2021-12-11 05:41:49 --> Router Class Initialized
INFO - 2021-12-11 05:41:49 --> Output Class Initialized
INFO - 2021-12-11 05:41:49 --> Security Class Initialized
DEBUG - 2021-12-11 05:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:41:49 --> Input Class Initialized
INFO - 2021-12-11 05:41:49 --> Language Class Initialized
INFO - 2021-12-11 05:41:49 --> Language Class Initialized
INFO - 2021-12-11 05:41:49 --> Config Class Initialized
INFO - 2021-12-11 05:41:49 --> Loader Class Initialized
INFO - 2021-12-11 05:41:49 --> Helper loaded: url_helper
INFO - 2021-12-11 05:41:49 --> Helper loaded: file_helper
INFO - 2021-12-11 05:41:49 --> Helper loaded: form_helper
INFO - 2021-12-11 05:41:49 --> Helper loaded: my_helper
INFO - 2021-12-11 05:41:49 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:41:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:41:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:41:49 --> Controller Class Initialized
INFO - 2021-12-11 05:41:49 --> Helper loaded: cookie_helper
INFO - 2021-12-11 05:41:49 --> Config Class Initialized
INFO - 2021-12-11 05:41:49 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:41:49 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:41:49 --> Utf8 Class Initialized
INFO - 2021-12-11 05:41:49 --> URI Class Initialized
INFO - 2021-12-11 05:41:49 --> Router Class Initialized
INFO - 2021-12-11 05:41:49 --> Output Class Initialized
INFO - 2021-12-11 05:41:49 --> Security Class Initialized
DEBUG - 2021-12-11 05:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:41:49 --> Input Class Initialized
INFO - 2021-12-11 05:41:49 --> Language Class Initialized
INFO - 2021-12-11 05:41:49 --> Language Class Initialized
INFO - 2021-12-11 05:41:49 --> Config Class Initialized
INFO - 2021-12-11 05:41:49 --> Loader Class Initialized
INFO - 2021-12-11 05:41:49 --> Helper loaded: url_helper
INFO - 2021-12-11 05:41:49 --> Helper loaded: file_helper
INFO - 2021-12-11 05:41:49 --> Helper loaded: form_helper
INFO - 2021-12-11 05:41:49 --> Helper loaded: my_helper
INFO - 2021-12-11 05:41:49 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:41:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:41:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:41:49 --> Controller Class Initialized
DEBUG - 2021-12-11 05:41:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-11 05:41:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-11 05:41:49 --> Final output sent to browser
DEBUG - 2021-12-11 05:41:49 --> Total execution time: 0.0580
INFO - 2021-12-11 05:41:55 --> Config Class Initialized
INFO - 2021-12-11 05:41:55 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:41:55 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:41:55 --> Utf8 Class Initialized
INFO - 2021-12-11 05:41:55 --> URI Class Initialized
INFO - 2021-12-11 05:41:55 --> Router Class Initialized
INFO - 2021-12-11 05:41:55 --> Output Class Initialized
INFO - 2021-12-11 05:41:55 --> Security Class Initialized
DEBUG - 2021-12-11 05:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:41:55 --> Input Class Initialized
INFO - 2021-12-11 05:41:55 --> Language Class Initialized
INFO - 2021-12-11 05:41:55 --> Language Class Initialized
INFO - 2021-12-11 05:41:55 --> Config Class Initialized
INFO - 2021-12-11 05:41:55 --> Loader Class Initialized
INFO - 2021-12-11 05:41:55 --> Helper loaded: url_helper
INFO - 2021-12-11 05:41:55 --> Helper loaded: file_helper
INFO - 2021-12-11 05:41:55 --> Helper loaded: form_helper
INFO - 2021-12-11 05:41:55 --> Helper loaded: my_helper
INFO - 2021-12-11 05:41:55 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:41:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:41:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:41:55 --> Controller Class Initialized
INFO - 2021-12-11 05:41:55 --> Helper loaded: cookie_helper
INFO - 2021-12-11 05:41:55 --> Final output sent to browser
DEBUG - 2021-12-11 05:41:55 --> Total execution time: 0.0430
INFO - 2021-12-11 05:41:56 --> Config Class Initialized
INFO - 2021-12-11 05:41:56 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:41:56 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:41:56 --> Utf8 Class Initialized
INFO - 2021-12-11 05:41:56 --> URI Class Initialized
INFO - 2021-12-11 05:41:56 --> Router Class Initialized
INFO - 2021-12-11 05:41:56 --> Output Class Initialized
INFO - 2021-12-11 05:41:56 --> Security Class Initialized
DEBUG - 2021-12-11 05:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:41:56 --> Input Class Initialized
INFO - 2021-12-11 05:41:56 --> Language Class Initialized
INFO - 2021-12-11 05:41:56 --> Language Class Initialized
INFO - 2021-12-11 05:41:56 --> Config Class Initialized
INFO - 2021-12-11 05:41:56 --> Loader Class Initialized
INFO - 2021-12-11 05:41:56 --> Helper loaded: url_helper
INFO - 2021-12-11 05:41:56 --> Helper loaded: file_helper
INFO - 2021-12-11 05:41:56 --> Helper loaded: form_helper
INFO - 2021-12-11 05:41:56 --> Helper loaded: my_helper
INFO - 2021-12-11 05:41:56 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:41:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:41:56 --> Controller Class Initialized
DEBUG - 2021-12-11 05:41:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-11 05:41:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-11 05:41:56 --> Final output sent to browser
DEBUG - 2021-12-11 05:41:56 --> Total execution time: 0.2480
INFO - 2021-12-11 05:41:57 --> Config Class Initialized
INFO - 2021-12-11 05:41:57 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:41:58 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:41:58 --> Utf8 Class Initialized
INFO - 2021-12-11 05:41:58 --> URI Class Initialized
INFO - 2021-12-11 05:41:58 --> Router Class Initialized
INFO - 2021-12-11 05:41:58 --> Output Class Initialized
INFO - 2021-12-11 05:41:58 --> Security Class Initialized
DEBUG - 2021-12-11 05:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:41:58 --> Input Class Initialized
INFO - 2021-12-11 05:41:58 --> Language Class Initialized
INFO - 2021-12-11 05:41:58 --> Language Class Initialized
INFO - 2021-12-11 05:41:58 --> Config Class Initialized
INFO - 2021-12-11 05:41:58 --> Loader Class Initialized
INFO - 2021-12-11 05:41:58 --> Helper loaded: url_helper
INFO - 2021-12-11 05:41:58 --> Helper loaded: file_helper
INFO - 2021-12-11 05:41:58 --> Helper loaded: form_helper
INFO - 2021-12-11 05:41:58 --> Helper loaded: my_helper
INFO - 2021-12-11 05:41:58 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:41:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:41:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:41:58 --> Controller Class Initialized
DEBUG - 2021-12-11 05:41:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-12-11 05:41:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-11 05:41:58 --> Final output sent to browser
DEBUG - 2021-12-11 05:41:58 --> Total execution time: 0.0600
INFO - 2021-12-11 05:41:58 --> Config Class Initialized
INFO - 2021-12-11 05:41:58 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:41:58 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:41:58 --> Utf8 Class Initialized
INFO - 2021-12-11 05:41:58 --> URI Class Initialized
INFO - 2021-12-11 05:41:58 --> Router Class Initialized
INFO - 2021-12-11 05:41:58 --> Output Class Initialized
INFO - 2021-12-11 05:41:58 --> Security Class Initialized
DEBUG - 2021-12-11 05:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:41:58 --> Input Class Initialized
INFO - 2021-12-11 05:41:58 --> Language Class Initialized
INFO - 2021-12-11 05:41:58 --> Language Class Initialized
INFO - 2021-12-11 05:41:58 --> Config Class Initialized
INFO - 2021-12-11 05:41:58 --> Loader Class Initialized
INFO - 2021-12-11 05:41:58 --> Helper loaded: url_helper
INFO - 2021-12-11 05:41:58 --> Helper loaded: file_helper
INFO - 2021-12-11 05:41:58 --> Helper loaded: form_helper
INFO - 2021-12-11 05:41:58 --> Helper loaded: my_helper
INFO - 2021-12-11 05:41:58 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:41:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:41:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:41:58 --> Controller Class Initialized
INFO - 2021-12-11 05:42:02 --> Config Class Initialized
INFO - 2021-12-11 05:42:02 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:42:02 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:42:02 --> Utf8 Class Initialized
INFO - 2021-12-11 05:42:02 --> URI Class Initialized
INFO - 2021-12-11 05:42:02 --> Router Class Initialized
INFO - 2021-12-11 05:42:02 --> Output Class Initialized
INFO - 2021-12-11 05:42:02 --> Security Class Initialized
DEBUG - 2021-12-11 05:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:42:02 --> Input Class Initialized
INFO - 2021-12-11 05:42:02 --> Language Class Initialized
INFO - 2021-12-11 05:42:02 --> Language Class Initialized
INFO - 2021-12-11 05:42:02 --> Config Class Initialized
INFO - 2021-12-11 05:42:02 --> Loader Class Initialized
INFO - 2021-12-11 05:42:02 --> Helper loaded: url_helper
INFO - 2021-12-11 05:42:02 --> Helper loaded: file_helper
INFO - 2021-12-11 05:42:02 --> Helper loaded: form_helper
INFO - 2021-12-11 05:42:02 --> Helper loaded: my_helper
INFO - 2021-12-11 05:42:02 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:42:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:42:02 --> Controller Class Initialized
INFO - 2021-12-11 05:42:02 --> Config Class Initialized
INFO - 2021-12-11 05:42:02 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:42:02 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:42:02 --> Utf8 Class Initialized
INFO - 2021-12-11 05:42:02 --> URI Class Initialized
INFO - 2021-12-11 05:42:02 --> Router Class Initialized
INFO - 2021-12-11 05:42:02 --> Output Class Initialized
INFO - 2021-12-11 05:42:02 --> Security Class Initialized
DEBUG - 2021-12-11 05:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:42:02 --> Input Class Initialized
INFO - 2021-12-11 05:42:02 --> Language Class Initialized
INFO - 2021-12-11 05:42:02 --> Language Class Initialized
INFO - 2021-12-11 05:42:02 --> Config Class Initialized
INFO - 2021-12-11 05:42:02 --> Loader Class Initialized
INFO - 2021-12-11 05:42:02 --> Helper loaded: url_helper
INFO - 2021-12-11 05:42:02 --> Helper loaded: file_helper
INFO - 2021-12-11 05:42:02 --> Helper loaded: form_helper
INFO - 2021-12-11 05:42:02 --> Helper loaded: my_helper
INFO - 2021-12-11 05:42:02 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:42:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:42:02 --> Controller Class Initialized
INFO - 2021-12-11 05:42:02 --> Config Class Initialized
INFO - 2021-12-11 05:42:02 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:42:02 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:42:02 --> Utf8 Class Initialized
INFO - 2021-12-11 05:42:02 --> URI Class Initialized
INFO - 2021-12-11 05:42:03 --> Router Class Initialized
INFO - 2021-12-11 05:42:03 --> Output Class Initialized
INFO - 2021-12-11 05:42:03 --> Security Class Initialized
DEBUG - 2021-12-11 05:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:42:03 --> Input Class Initialized
INFO - 2021-12-11 05:42:03 --> Language Class Initialized
INFO - 2021-12-11 05:42:03 --> Language Class Initialized
INFO - 2021-12-11 05:42:03 --> Config Class Initialized
INFO - 2021-12-11 05:42:03 --> Loader Class Initialized
INFO - 2021-12-11 05:42:03 --> Helper loaded: url_helper
INFO - 2021-12-11 05:42:03 --> Helper loaded: file_helper
INFO - 2021-12-11 05:42:03 --> Helper loaded: form_helper
INFO - 2021-12-11 05:42:03 --> Helper loaded: my_helper
INFO - 2021-12-11 05:42:03 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:42:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:42:03 --> Controller Class Initialized
INFO - 2021-12-11 05:42:03 --> Config Class Initialized
INFO - 2021-12-11 05:42:03 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:42:03 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:42:03 --> Utf8 Class Initialized
INFO - 2021-12-11 05:42:03 --> URI Class Initialized
INFO - 2021-12-11 05:42:03 --> Router Class Initialized
INFO - 2021-12-11 05:42:03 --> Output Class Initialized
INFO - 2021-12-11 05:42:03 --> Security Class Initialized
DEBUG - 2021-12-11 05:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:42:03 --> Input Class Initialized
INFO - 2021-12-11 05:42:03 --> Language Class Initialized
INFO - 2021-12-11 05:42:03 --> Language Class Initialized
INFO - 2021-12-11 05:42:03 --> Config Class Initialized
INFO - 2021-12-11 05:42:03 --> Loader Class Initialized
INFO - 2021-12-11 05:42:03 --> Helper loaded: url_helper
INFO - 2021-12-11 05:42:03 --> Helper loaded: file_helper
INFO - 2021-12-11 05:42:03 --> Helper loaded: form_helper
INFO - 2021-12-11 05:42:03 --> Helper loaded: my_helper
INFO - 2021-12-11 05:42:03 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:42:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:42:03 --> Controller Class Initialized
INFO - 2021-12-11 05:42:06 --> Config Class Initialized
INFO - 2021-12-11 05:42:06 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:42:06 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:42:06 --> Utf8 Class Initialized
INFO - 2021-12-11 05:42:06 --> URI Class Initialized
INFO - 2021-12-11 05:42:06 --> Router Class Initialized
INFO - 2021-12-11 05:42:06 --> Output Class Initialized
INFO - 2021-12-11 05:42:06 --> Security Class Initialized
DEBUG - 2021-12-11 05:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:42:06 --> Input Class Initialized
INFO - 2021-12-11 05:42:06 --> Language Class Initialized
INFO - 2021-12-11 05:42:06 --> Language Class Initialized
INFO - 2021-12-11 05:42:06 --> Config Class Initialized
INFO - 2021-12-11 05:42:06 --> Loader Class Initialized
INFO - 2021-12-11 05:42:06 --> Helper loaded: url_helper
INFO - 2021-12-11 05:42:06 --> Helper loaded: file_helper
INFO - 2021-12-11 05:42:06 --> Helper loaded: form_helper
INFO - 2021-12-11 05:42:06 --> Helper loaded: my_helper
INFO - 2021-12-11 05:42:06 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:42:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:42:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:42:06 --> Controller Class Initialized
ERROR - 2021-12-11 05:42:06 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2021-12-11 05:42:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-12-11 05:42:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-11 05:42:06 --> Final output sent to browser
DEBUG - 2021-12-11 05:42:06 --> Total execution time: 0.0600
INFO - 2021-12-11 05:42:38 --> Config Class Initialized
INFO - 2021-12-11 05:42:38 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:42:38 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:42:38 --> Utf8 Class Initialized
INFO - 2021-12-11 05:42:38 --> URI Class Initialized
INFO - 2021-12-11 05:42:38 --> Router Class Initialized
INFO - 2021-12-11 05:42:38 --> Output Class Initialized
INFO - 2021-12-11 05:42:38 --> Security Class Initialized
DEBUG - 2021-12-11 05:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:42:38 --> Input Class Initialized
INFO - 2021-12-11 05:42:38 --> Language Class Initialized
INFO - 2021-12-11 05:42:38 --> Language Class Initialized
INFO - 2021-12-11 05:42:38 --> Config Class Initialized
INFO - 2021-12-11 05:42:38 --> Loader Class Initialized
INFO - 2021-12-11 05:42:38 --> Helper loaded: url_helper
INFO - 2021-12-11 05:42:38 --> Helper loaded: file_helper
INFO - 2021-12-11 05:42:38 --> Helper loaded: form_helper
INFO - 2021-12-11 05:42:38 --> Helper loaded: my_helper
INFO - 2021-12-11 05:42:38 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:42:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:42:38 --> Controller Class Initialized
INFO - 2021-12-11 05:42:38 --> Upload Class Initialized
INFO - 2021-12-11 05:42:38 --> Language file loaded: language/english/upload_lang.php
ERROR - 2021-12-11 05:42:38 --> The upload path does not appear to be valid.
INFO - 2021-12-11 05:42:38 --> Config Class Initialized
INFO - 2021-12-11 05:42:38 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:42:38 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:42:38 --> Utf8 Class Initialized
INFO - 2021-12-11 05:42:38 --> URI Class Initialized
INFO - 2021-12-11 05:42:38 --> Router Class Initialized
INFO - 2021-12-11 05:42:38 --> Output Class Initialized
INFO - 2021-12-11 05:42:38 --> Security Class Initialized
DEBUG - 2021-12-11 05:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:42:38 --> Input Class Initialized
INFO - 2021-12-11 05:42:38 --> Language Class Initialized
INFO - 2021-12-11 05:42:38 --> Language Class Initialized
INFO - 2021-12-11 05:42:38 --> Config Class Initialized
INFO - 2021-12-11 05:42:38 --> Loader Class Initialized
INFO - 2021-12-11 05:42:38 --> Helper loaded: url_helper
INFO - 2021-12-11 05:42:38 --> Helper loaded: file_helper
INFO - 2021-12-11 05:42:38 --> Helper loaded: form_helper
INFO - 2021-12-11 05:42:38 --> Helper loaded: my_helper
INFO - 2021-12-11 05:42:38 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:42:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:42:38 --> Controller Class Initialized
DEBUG - 2021-12-11 05:42:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-12-11 05:42:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-11 05:42:38 --> Final output sent to browser
DEBUG - 2021-12-11 05:42:38 --> Total execution time: 0.0350
INFO - 2021-12-11 05:42:39 --> Config Class Initialized
INFO - 2021-12-11 05:42:39 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:42:39 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:42:39 --> Utf8 Class Initialized
INFO - 2021-12-11 05:42:39 --> URI Class Initialized
INFO - 2021-12-11 05:42:39 --> Router Class Initialized
INFO - 2021-12-11 05:42:39 --> Output Class Initialized
INFO - 2021-12-11 05:42:39 --> Security Class Initialized
DEBUG - 2021-12-11 05:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:42:39 --> Input Class Initialized
INFO - 2021-12-11 05:42:39 --> Language Class Initialized
INFO - 2021-12-11 05:42:39 --> Language Class Initialized
INFO - 2021-12-11 05:42:39 --> Config Class Initialized
INFO - 2021-12-11 05:42:39 --> Loader Class Initialized
INFO - 2021-12-11 05:42:39 --> Helper loaded: url_helper
INFO - 2021-12-11 05:42:39 --> Helper loaded: file_helper
INFO - 2021-12-11 05:42:39 --> Helper loaded: form_helper
INFO - 2021-12-11 05:42:39 --> Helper loaded: my_helper
INFO - 2021-12-11 05:42:39 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:42:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:42:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:42:39 --> Controller Class Initialized
INFO - 2021-12-11 05:42:40 --> Config Class Initialized
INFO - 2021-12-11 05:42:40 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:42:40 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:42:40 --> Utf8 Class Initialized
INFO - 2021-12-11 05:42:40 --> URI Class Initialized
INFO - 2021-12-11 05:42:40 --> Router Class Initialized
INFO - 2021-12-11 05:42:40 --> Output Class Initialized
INFO - 2021-12-11 05:42:40 --> Security Class Initialized
DEBUG - 2021-12-11 05:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:42:40 --> Input Class Initialized
INFO - 2021-12-11 05:42:40 --> Language Class Initialized
INFO - 2021-12-11 05:42:40 --> Language Class Initialized
INFO - 2021-12-11 05:42:40 --> Config Class Initialized
INFO - 2021-12-11 05:42:40 --> Loader Class Initialized
INFO - 2021-12-11 05:42:40 --> Helper loaded: url_helper
INFO - 2021-12-11 05:42:40 --> Helper loaded: file_helper
INFO - 2021-12-11 05:42:40 --> Helper loaded: form_helper
INFO - 2021-12-11 05:42:40 --> Helper loaded: my_helper
INFO - 2021-12-11 05:42:40 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:42:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:42:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:42:40 --> Controller Class Initialized
DEBUG - 2021-12-11 05:42:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-12-11 05:42:40 --> Final output sent to browser
DEBUG - 2021-12-11 05:42:40 --> Total execution time: 0.1230
INFO - 2021-12-11 05:48:20 --> Config Class Initialized
INFO - 2021-12-11 05:48:20 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:48:20 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:48:20 --> Utf8 Class Initialized
INFO - 2021-12-11 05:48:20 --> URI Class Initialized
INFO - 2021-12-11 05:48:20 --> Router Class Initialized
INFO - 2021-12-11 05:48:20 --> Output Class Initialized
INFO - 2021-12-11 05:48:20 --> Security Class Initialized
DEBUG - 2021-12-11 05:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:48:20 --> Input Class Initialized
INFO - 2021-12-11 05:48:20 --> Language Class Initialized
INFO - 2021-12-11 05:48:20 --> Language Class Initialized
INFO - 2021-12-11 05:48:20 --> Config Class Initialized
INFO - 2021-12-11 05:48:20 --> Loader Class Initialized
INFO - 2021-12-11 05:48:20 --> Helper loaded: url_helper
INFO - 2021-12-11 05:48:20 --> Helper loaded: file_helper
INFO - 2021-12-11 05:48:20 --> Helper loaded: form_helper
INFO - 2021-12-11 05:48:20 --> Helper loaded: my_helper
INFO - 2021-12-11 05:48:20 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:48:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:48:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:48:20 --> Controller Class Initialized
INFO - 2021-12-11 05:48:20 --> Helper loaded: cookie_helper
INFO - 2021-12-11 05:48:20 --> Config Class Initialized
INFO - 2021-12-11 05:48:20 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:48:20 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:48:20 --> Utf8 Class Initialized
INFO - 2021-12-11 05:48:20 --> URI Class Initialized
INFO - 2021-12-11 05:48:20 --> Router Class Initialized
INFO - 2021-12-11 05:48:20 --> Output Class Initialized
INFO - 2021-12-11 05:48:20 --> Security Class Initialized
DEBUG - 2021-12-11 05:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:48:20 --> Input Class Initialized
INFO - 2021-12-11 05:48:20 --> Language Class Initialized
INFO - 2021-12-11 05:48:20 --> Language Class Initialized
INFO - 2021-12-11 05:48:20 --> Config Class Initialized
INFO - 2021-12-11 05:48:20 --> Loader Class Initialized
INFO - 2021-12-11 05:48:20 --> Helper loaded: url_helper
INFO - 2021-12-11 05:48:20 --> Helper loaded: file_helper
INFO - 2021-12-11 05:48:20 --> Helper loaded: form_helper
INFO - 2021-12-11 05:48:20 --> Helper loaded: my_helper
INFO - 2021-12-11 05:48:20 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:48:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:48:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:48:20 --> Controller Class Initialized
DEBUG - 2021-12-11 05:48:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-11 05:48:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-11 05:48:20 --> Final output sent to browser
DEBUG - 2021-12-11 05:48:20 --> Total execution time: 0.0390
INFO - 2021-12-11 05:48:26 --> Config Class Initialized
INFO - 2021-12-11 05:48:26 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:48:26 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:48:26 --> Utf8 Class Initialized
INFO - 2021-12-11 05:48:26 --> URI Class Initialized
INFO - 2021-12-11 05:48:26 --> Router Class Initialized
INFO - 2021-12-11 05:48:26 --> Output Class Initialized
INFO - 2021-12-11 05:48:26 --> Security Class Initialized
DEBUG - 2021-12-11 05:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:48:26 --> Input Class Initialized
INFO - 2021-12-11 05:48:26 --> Language Class Initialized
INFO - 2021-12-11 05:48:26 --> Language Class Initialized
INFO - 2021-12-11 05:48:26 --> Config Class Initialized
INFO - 2021-12-11 05:48:26 --> Loader Class Initialized
INFO - 2021-12-11 05:48:26 --> Helper loaded: url_helper
INFO - 2021-12-11 05:48:26 --> Helper loaded: file_helper
INFO - 2021-12-11 05:48:26 --> Helper loaded: form_helper
INFO - 2021-12-11 05:48:26 --> Helper loaded: my_helper
INFO - 2021-12-11 05:48:26 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:48:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:48:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:48:26 --> Controller Class Initialized
INFO - 2021-12-11 05:48:26 --> Helper loaded: cookie_helper
INFO - 2021-12-11 05:48:26 --> Final output sent to browser
DEBUG - 2021-12-11 05:48:26 --> Total execution time: 0.0450
INFO - 2021-12-11 05:48:26 --> Config Class Initialized
INFO - 2021-12-11 05:48:26 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:48:26 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:48:26 --> Utf8 Class Initialized
INFO - 2021-12-11 05:48:26 --> URI Class Initialized
INFO - 2021-12-11 05:48:26 --> Router Class Initialized
INFO - 2021-12-11 05:48:26 --> Output Class Initialized
INFO - 2021-12-11 05:48:26 --> Security Class Initialized
DEBUG - 2021-12-11 05:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:48:26 --> Input Class Initialized
INFO - 2021-12-11 05:48:26 --> Language Class Initialized
INFO - 2021-12-11 05:48:26 --> Language Class Initialized
INFO - 2021-12-11 05:48:26 --> Config Class Initialized
INFO - 2021-12-11 05:48:26 --> Loader Class Initialized
INFO - 2021-12-11 05:48:26 --> Helper loaded: url_helper
INFO - 2021-12-11 05:48:26 --> Helper loaded: file_helper
INFO - 2021-12-11 05:48:26 --> Helper loaded: form_helper
INFO - 2021-12-11 05:48:26 --> Helper loaded: my_helper
INFO - 2021-12-11 05:48:26 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:48:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:48:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:48:26 --> Controller Class Initialized
DEBUG - 2021-12-11 05:48:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-11 05:48:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-11 05:48:27 --> Final output sent to browser
DEBUG - 2021-12-11 05:48:27 --> Total execution time: 0.2310
INFO - 2021-12-11 05:48:43 --> Config Class Initialized
INFO - 2021-12-11 05:48:43 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:48:43 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:48:43 --> Utf8 Class Initialized
INFO - 2021-12-11 05:48:43 --> URI Class Initialized
INFO - 2021-12-11 05:48:43 --> Router Class Initialized
INFO - 2021-12-11 05:48:43 --> Output Class Initialized
INFO - 2021-12-11 05:48:43 --> Security Class Initialized
DEBUG - 2021-12-11 05:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:48:43 --> Input Class Initialized
INFO - 2021-12-11 05:48:43 --> Language Class Initialized
INFO - 2021-12-11 05:48:43 --> Language Class Initialized
INFO - 2021-12-11 05:48:43 --> Config Class Initialized
INFO - 2021-12-11 05:48:43 --> Loader Class Initialized
INFO - 2021-12-11 05:48:43 --> Helper loaded: url_helper
INFO - 2021-12-11 05:48:43 --> Helper loaded: file_helper
INFO - 2021-12-11 05:48:43 --> Helper loaded: form_helper
INFO - 2021-12-11 05:48:43 --> Helper loaded: my_helper
INFO - 2021-12-11 05:48:43 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:48:43 --> Controller Class Initialized
DEBUG - 2021-12-11 05:48:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-12-11 05:48:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-11 05:48:43 --> Final output sent to browser
DEBUG - 2021-12-11 05:48:43 --> Total execution time: 0.0440
INFO - 2021-12-11 05:48:43 --> Config Class Initialized
INFO - 2021-12-11 05:48:43 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:48:43 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:48:43 --> Utf8 Class Initialized
INFO - 2021-12-11 05:48:43 --> URI Class Initialized
INFO - 2021-12-11 05:48:43 --> Router Class Initialized
INFO - 2021-12-11 05:48:43 --> Output Class Initialized
INFO - 2021-12-11 05:48:43 --> Security Class Initialized
DEBUG - 2021-12-11 05:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:48:43 --> Input Class Initialized
INFO - 2021-12-11 05:48:43 --> Language Class Initialized
INFO - 2021-12-11 05:48:43 --> Language Class Initialized
INFO - 2021-12-11 05:48:43 --> Config Class Initialized
INFO - 2021-12-11 05:48:43 --> Loader Class Initialized
INFO - 2021-12-11 05:48:43 --> Helper loaded: url_helper
INFO - 2021-12-11 05:48:43 --> Helper loaded: file_helper
INFO - 2021-12-11 05:48:43 --> Helper loaded: form_helper
INFO - 2021-12-11 05:48:43 --> Helper loaded: my_helper
INFO - 2021-12-11 05:48:43 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:48:43 --> Controller Class Initialized
INFO - 2021-12-11 05:48:44 --> Config Class Initialized
INFO - 2021-12-11 05:48:44 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:48:44 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:48:44 --> Utf8 Class Initialized
INFO - 2021-12-11 05:48:44 --> URI Class Initialized
INFO - 2021-12-11 05:48:44 --> Router Class Initialized
INFO - 2021-12-11 05:48:44 --> Output Class Initialized
INFO - 2021-12-11 05:48:44 --> Security Class Initialized
DEBUG - 2021-12-11 05:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:48:44 --> Input Class Initialized
INFO - 2021-12-11 05:48:44 --> Language Class Initialized
INFO - 2021-12-11 05:48:44 --> Language Class Initialized
INFO - 2021-12-11 05:48:44 --> Config Class Initialized
INFO - 2021-12-11 05:48:44 --> Loader Class Initialized
INFO - 2021-12-11 05:48:44 --> Helper loaded: url_helper
INFO - 2021-12-11 05:48:44 --> Helper loaded: file_helper
INFO - 2021-12-11 05:48:44 --> Helper loaded: form_helper
INFO - 2021-12-11 05:48:44 --> Helper loaded: my_helper
INFO - 2021-12-11 05:48:44 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:48:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:48:44 --> Controller Class Initialized
INFO - 2021-12-11 05:48:44 --> Final output sent to browser
DEBUG - 2021-12-11 05:48:44 --> Total execution time: 0.0580
INFO - 2021-12-11 05:48:44 --> Config Class Initialized
INFO - 2021-12-11 05:48:44 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:48:44 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:48:44 --> Utf8 Class Initialized
INFO - 2021-12-11 05:48:44 --> URI Class Initialized
INFO - 2021-12-11 05:48:44 --> Router Class Initialized
INFO - 2021-12-11 05:48:44 --> Output Class Initialized
INFO - 2021-12-11 05:48:44 --> Security Class Initialized
DEBUG - 2021-12-11 05:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:48:44 --> Input Class Initialized
INFO - 2021-12-11 05:48:44 --> Language Class Initialized
INFO - 2021-12-11 05:48:44 --> Language Class Initialized
INFO - 2021-12-11 05:48:44 --> Config Class Initialized
INFO - 2021-12-11 05:48:44 --> Loader Class Initialized
INFO - 2021-12-11 05:48:44 --> Helper loaded: url_helper
INFO - 2021-12-11 05:48:44 --> Helper loaded: file_helper
INFO - 2021-12-11 05:48:44 --> Helper loaded: form_helper
INFO - 2021-12-11 05:48:44 --> Helper loaded: my_helper
INFO - 2021-12-11 05:48:44 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:48:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:48:44 --> Controller Class Initialized
INFO - 2021-12-11 05:48:46 --> Config Class Initialized
INFO - 2021-12-11 05:48:46 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:48:46 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:48:46 --> Utf8 Class Initialized
INFO - 2021-12-11 05:48:46 --> URI Class Initialized
INFO - 2021-12-11 05:48:46 --> Router Class Initialized
INFO - 2021-12-11 05:48:46 --> Output Class Initialized
INFO - 2021-12-11 05:48:46 --> Security Class Initialized
DEBUG - 2021-12-11 05:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:48:46 --> Input Class Initialized
INFO - 2021-12-11 05:48:46 --> Language Class Initialized
INFO - 2021-12-11 05:48:46 --> Language Class Initialized
INFO - 2021-12-11 05:48:46 --> Config Class Initialized
INFO - 2021-12-11 05:48:46 --> Loader Class Initialized
INFO - 2021-12-11 05:48:46 --> Helper loaded: url_helper
INFO - 2021-12-11 05:48:46 --> Helper loaded: file_helper
INFO - 2021-12-11 05:48:46 --> Helper loaded: form_helper
INFO - 2021-12-11 05:48:46 --> Helper loaded: my_helper
INFO - 2021-12-11 05:48:46 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:48:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:48:46 --> Controller Class Initialized
INFO - 2021-12-11 05:48:46 --> Helper loaded: cookie_helper
INFO - 2021-12-11 05:48:46 --> Config Class Initialized
INFO - 2021-12-11 05:48:46 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:48:46 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:48:46 --> Utf8 Class Initialized
INFO - 2021-12-11 05:48:46 --> URI Class Initialized
INFO - 2021-12-11 05:48:46 --> Router Class Initialized
INFO - 2021-12-11 05:48:46 --> Output Class Initialized
INFO - 2021-12-11 05:48:46 --> Security Class Initialized
DEBUG - 2021-12-11 05:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:48:46 --> Input Class Initialized
INFO - 2021-12-11 05:48:46 --> Language Class Initialized
INFO - 2021-12-11 05:48:46 --> Language Class Initialized
INFO - 2021-12-11 05:48:46 --> Config Class Initialized
INFO - 2021-12-11 05:48:46 --> Loader Class Initialized
INFO - 2021-12-11 05:48:46 --> Helper loaded: url_helper
INFO - 2021-12-11 05:48:46 --> Helper loaded: file_helper
INFO - 2021-12-11 05:48:46 --> Helper loaded: form_helper
INFO - 2021-12-11 05:48:46 --> Helper loaded: my_helper
INFO - 2021-12-11 05:48:46 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:48:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:48:46 --> Controller Class Initialized
DEBUG - 2021-12-11 05:48:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-11 05:48:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-11 05:48:46 --> Final output sent to browser
DEBUG - 2021-12-11 05:48:46 --> Total execution time: 0.0400
INFO - 2021-12-11 05:49:09 --> Config Class Initialized
INFO - 2021-12-11 05:49:09 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:49:09 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:49:09 --> Utf8 Class Initialized
INFO - 2021-12-11 05:49:09 --> URI Class Initialized
INFO - 2021-12-11 05:49:09 --> Router Class Initialized
INFO - 2021-12-11 05:49:09 --> Output Class Initialized
INFO - 2021-12-11 05:49:09 --> Security Class Initialized
DEBUG - 2021-12-11 05:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:49:09 --> Input Class Initialized
INFO - 2021-12-11 05:49:09 --> Language Class Initialized
INFO - 2021-12-11 05:49:09 --> Language Class Initialized
INFO - 2021-12-11 05:49:09 --> Config Class Initialized
INFO - 2021-12-11 05:49:09 --> Loader Class Initialized
INFO - 2021-12-11 05:49:09 --> Helper loaded: url_helper
INFO - 2021-12-11 05:49:09 --> Helper loaded: file_helper
INFO - 2021-12-11 05:49:09 --> Helper loaded: form_helper
INFO - 2021-12-11 05:49:09 --> Helper loaded: my_helper
INFO - 2021-12-11 05:49:09 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:49:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:49:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:49:09 --> Controller Class Initialized
INFO - 2021-12-11 05:49:09 --> Helper loaded: cookie_helper
INFO - 2021-12-11 05:49:09 --> Final output sent to browser
DEBUG - 2021-12-11 05:49:09 --> Total execution time: 0.0480
INFO - 2021-12-11 05:49:10 --> Config Class Initialized
INFO - 2021-12-11 05:49:10 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:49:10 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:49:10 --> Utf8 Class Initialized
INFO - 2021-12-11 05:49:10 --> URI Class Initialized
INFO - 2021-12-11 05:49:10 --> Router Class Initialized
INFO - 2021-12-11 05:49:10 --> Output Class Initialized
INFO - 2021-12-11 05:49:10 --> Security Class Initialized
DEBUG - 2021-12-11 05:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:49:10 --> Input Class Initialized
INFO - 2021-12-11 05:49:10 --> Language Class Initialized
INFO - 2021-12-11 05:49:10 --> Language Class Initialized
INFO - 2021-12-11 05:49:10 --> Config Class Initialized
INFO - 2021-12-11 05:49:10 --> Loader Class Initialized
INFO - 2021-12-11 05:49:10 --> Helper loaded: url_helper
INFO - 2021-12-11 05:49:10 --> Helper loaded: file_helper
INFO - 2021-12-11 05:49:10 --> Helper loaded: form_helper
INFO - 2021-12-11 05:49:10 --> Helper loaded: my_helper
INFO - 2021-12-11 05:49:10 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:49:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:49:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:49:10 --> Controller Class Initialized
DEBUG - 2021-12-11 05:49:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-11 05:49:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-11 05:49:10 --> Final output sent to browser
DEBUG - 2021-12-11 05:49:10 --> Total execution time: 0.1480
INFO - 2021-12-11 05:49:14 --> Config Class Initialized
INFO - 2021-12-11 05:49:14 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:49:14 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:49:14 --> Utf8 Class Initialized
INFO - 2021-12-11 05:49:14 --> URI Class Initialized
INFO - 2021-12-11 05:49:14 --> Router Class Initialized
INFO - 2021-12-11 05:49:14 --> Output Class Initialized
INFO - 2021-12-11 05:49:14 --> Security Class Initialized
DEBUG - 2021-12-11 05:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:49:14 --> Input Class Initialized
INFO - 2021-12-11 05:49:14 --> Language Class Initialized
INFO - 2021-12-11 05:49:14 --> Language Class Initialized
INFO - 2021-12-11 05:49:14 --> Config Class Initialized
INFO - 2021-12-11 05:49:14 --> Loader Class Initialized
INFO - 2021-12-11 05:49:14 --> Helper loaded: url_helper
INFO - 2021-12-11 05:49:14 --> Helper loaded: file_helper
INFO - 2021-12-11 05:49:14 --> Helper loaded: form_helper
INFO - 2021-12-11 05:49:14 --> Helper loaded: my_helper
INFO - 2021-12-11 05:49:14 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:49:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:49:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:49:14 --> Controller Class Initialized
DEBUG - 2021-12-11 05:49:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-11 05:49:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-11 05:49:14 --> Final output sent to browser
DEBUG - 2021-12-11 05:49:14 --> Total execution time: 0.0660
INFO - 2021-12-11 05:49:17 --> Config Class Initialized
INFO - 2021-12-11 05:49:17 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:49:17 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:49:17 --> Utf8 Class Initialized
INFO - 2021-12-11 05:49:17 --> URI Class Initialized
INFO - 2021-12-11 05:49:17 --> Router Class Initialized
INFO - 2021-12-11 05:49:17 --> Output Class Initialized
INFO - 2021-12-11 05:49:17 --> Security Class Initialized
DEBUG - 2021-12-11 05:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:49:17 --> Input Class Initialized
INFO - 2021-12-11 05:49:17 --> Language Class Initialized
INFO - 2021-12-11 05:49:17 --> Language Class Initialized
INFO - 2021-12-11 05:49:17 --> Config Class Initialized
INFO - 2021-12-11 05:49:17 --> Loader Class Initialized
INFO - 2021-12-11 05:49:17 --> Helper loaded: url_helper
INFO - 2021-12-11 05:49:17 --> Helper loaded: file_helper
INFO - 2021-12-11 05:49:17 --> Helper loaded: form_helper
INFO - 2021-12-11 05:49:17 --> Helper loaded: my_helper
INFO - 2021-12-11 05:49:17 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:49:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:49:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:49:17 --> Controller Class Initialized
DEBUG - 2021-12-11 05:49:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-11 05:49:17 --> Final output sent to browser
DEBUG - 2021-12-11 05:49:17 --> Total execution time: 0.1080
INFO - 2021-12-11 05:49:31 --> Config Class Initialized
INFO - 2021-12-11 05:49:31 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:49:31 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:49:31 --> Utf8 Class Initialized
INFO - 2021-12-11 05:49:31 --> URI Class Initialized
INFO - 2021-12-11 05:49:31 --> Router Class Initialized
INFO - 2021-12-11 05:49:31 --> Output Class Initialized
INFO - 2021-12-11 05:49:31 --> Security Class Initialized
DEBUG - 2021-12-11 05:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:49:31 --> Input Class Initialized
INFO - 2021-12-11 05:49:31 --> Language Class Initialized
INFO - 2021-12-11 05:49:31 --> Language Class Initialized
INFO - 2021-12-11 05:49:31 --> Config Class Initialized
INFO - 2021-12-11 05:49:31 --> Loader Class Initialized
INFO - 2021-12-11 05:49:31 --> Helper loaded: url_helper
INFO - 2021-12-11 05:49:31 --> Helper loaded: file_helper
INFO - 2021-12-11 05:49:31 --> Helper loaded: form_helper
INFO - 2021-12-11 05:49:31 --> Helper loaded: my_helper
INFO - 2021-12-11 05:49:31 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:49:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:49:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:49:31 --> Controller Class Initialized
DEBUG - 2021-12-11 05:49:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-11 05:49:31 --> Final output sent to browser
DEBUG - 2021-12-11 05:49:31 --> Total execution time: 0.0710
INFO - 2021-12-11 05:49:33 --> Config Class Initialized
INFO - 2021-12-11 05:49:33 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:49:33 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:49:33 --> Utf8 Class Initialized
INFO - 2021-12-11 05:49:33 --> URI Class Initialized
INFO - 2021-12-11 05:49:33 --> Router Class Initialized
INFO - 2021-12-11 05:49:33 --> Output Class Initialized
INFO - 2021-12-11 05:49:33 --> Security Class Initialized
DEBUG - 2021-12-11 05:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:49:33 --> Input Class Initialized
INFO - 2021-12-11 05:49:33 --> Language Class Initialized
INFO - 2021-12-11 05:49:33 --> Language Class Initialized
INFO - 2021-12-11 05:49:33 --> Config Class Initialized
INFO - 2021-12-11 05:49:33 --> Loader Class Initialized
INFO - 2021-12-11 05:49:33 --> Helper loaded: url_helper
INFO - 2021-12-11 05:49:33 --> Helper loaded: file_helper
INFO - 2021-12-11 05:49:33 --> Helper loaded: form_helper
INFO - 2021-12-11 05:49:33 --> Helper loaded: my_helper
INFO - 2021-12-11 05:49:33 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:49:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:49:33 --> Controller Class Initialized
DEBUG - 2021-12-11 05:49:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-11 05:49:33 --> Final output sent to browser
DEBUG - 2021-12-11 05:49:33 --> Total execution time: 0.0660
INFO - 2021-12-11 05:49:34 --> Config Class Initialized
INFO - 2021-12-11 05:49:34 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:49:34 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:49:34 --> Utf8 Class Initialized
INFO - 2021-12-11 05:49:34 --> URI Class Initialized
INFO - 2021-12-11 05:49:34 --> Router Class Initialized
INFO - 2021-12-11 05:49:34 --> Output Class Initialized
INFO - 2021-12-11 05:49:34 --> Security Class Initialized
DEBUG - 2021-12-11 05:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:49:34 --> Input Class Initialized
INFO - 2021-12-11 05:49:34 --> Language Class Initialized
INFO - 2021-12-11 05:49:34 --> Language Class Initialized
INFO - 2021-12-11 05:49:34 --> Config Class Initialized
INFO - 2021-12-11 05:49:34 --> Loader Class Initialized
INFO - 2021-12-11 05:49:34 --> Helper loaded: url_helper
INFO - 2021-12-11 05:49:34 --> Helper loaded: file_helper
INFO - 2021-12-11 05:49:34 --> Helper loaded: form_helper
INFO - 2021-12-11 05:49:34 --> Helper loaded: my_helper
INFO - 2021-12-11 05:49:34 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:49:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:49:34 --> Controller Class Initialized
DEBUG - 2021-12-11 05:49:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-11 05:49:34 --> Final output sent to browser
DEBUG - 2021-12-11 05:49:34 --> Total execution time: 0.0680
INFO - 2021-12-11 05:49:37 --> Config Class Initialized
INFO - 2021-12-11 05:49:37 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:49:37 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:49:37 --> Utf8 Class Initialized
INFO - 2021-12-11 05:49:37 --> URI Class Initialized
INFO - 2021-12-11 05:49:37 --> Router Class Initialized
INFO - 2021-12-11 05:49:37 --> Output Class Initialized
INFO - 2021-12-11 05:49:37 --> Security Class Initialized
DEBUG - 2021-12-11 05:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:49:37 --> Input Class Initialized
INFO - 2021-12-11 05:49:37 --> Language Class Initialized
INFO - 2021-12-11 05:49:37 --> Language Class Initialized
INFO - 2021-12-11 05:49:37 --> Config Class Initialized
INFO - 2021-12-11 05:49:37 --> Loader Class Initialized
INFO - 2021-12-11 05:49:37 --> Helper loaded: url_helper
INFO - 2021-12-11 05:49:37 --> Helper loaded: file_helper
INFO - 2021-12-11 05:49:37 --> Helper loaded: form_helper
INFO - 2021-12-11 05:49:37 --> Helper loaded: my_helper
INFO - 2021-12-11 05:49:37 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:49:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:49:37 --> Controller Class Initialized
DEBUG - 2021-12-11 05:49:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-11 05:49:37 --> Final output sent to browser
DEBUG - 2021-12-11 05:49:37 --> Total execution time: 0.0540
INFO - 2021-12-11 05:49:39 --> Config Class Initialized
INFO - 2021-12-11 05:49:39 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:49:39 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:49:39 --> Utf8 Class Initialized
INFO - 2021-12-11 05:49:39 --> URI Class Initialized
INFO - 2021-12-11 05:49:39 --> Router Class Initialized
INFO - 2021-12-11 05:49:39 --> Output Class Initialized
INFO - 2021-12-11 05:49:39 --> Security Class Initialized
DEBUG - 2021-12-11 05:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:49:39 --> Input Class Initialized
INFO - 2021-12-11 05:49:39 --> Language Class Initialized
INFO - 2021-12-11 05:49:39 --> Language Class Initialized
INFO - 2021-12-11 05:49:39 --> Config Class Initialized
INFO - 2021-12-11 05:49:39 --> Loader Class Initialized
INFO - 2021-12-11 05:49:39 --> Helper loaded: url_helper
INFO - 2021-12-11 05:49:39 --> Helper loaded: file_helper
INFO - 2021-12-11 05:49:39 --> Helper loaded: form_helper
INFO - 2021-12-11 05:49:39 --> Helper loaded: my_helper
INFO - 2021-12-11 05:49:39 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:49:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:49:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:49:39 --> Controller Class Initialized
DEBUG - 2021-12-11 05:49:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-11 05:49:39 --> Final output sent to browser
DEBUG - 2021-12-11 05:49:39 --> Total execution time: 0.0590
INFO - 2021-12-11 05:49:42 --> Config Class Initialized
INFO - 2021-12-11 05:49:42 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:49:42 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:49:42 --> Utf8 Class Initialized
INFO - 2021-12-11 05:49:42 --> URI Class Initialized
INFO - 2021-12-11 05:49:42 --> Router Class Initialized
INFO - 2021-12-11 05:49:42 --> Output Class Initialized
INFO - 2021-12-11 05:49:42 --> Security Class Initialized
DEBUG - 2021-12-11 05:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:49:42 --> Input Class Initialized
INFO - 2021-12-11 05:49:42 --> Language Class Initialized
INFO - 2021-12-11 05:49:42 --> Language Class Initialized
INFO - 2021-12-11 05:49:42 --> Config Class Initialized
INFO - 2021-12-11 05:49:42 --> Loader Class Initialized
INFO - 2021-12-11 05:49:42 --> Helper loaded: url_helper
INFO - 2021-12-11 05:49:42 --> Helper loaded: file_helper
INFO - 2021-12-11 05:49:42 --> Helper loaded: form_helper
INFO - 2021-12-11 05:49:42 --> Helper loaded: my_helper
INFO - 2021-12-11 05:49:42 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:49:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:49:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:49:42 --> Controller Class Initialized
DEBUG - 2021-12-11 05:49:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-11 05:49:42 --> Final output sent to browser
DEBUG - 2021-12-11 05:49:42 --> Total execution time: 0.0560
INFO - 2021-12-11 05:49:44 --> Config Class Initialized
INFO - 2021-12-11 05:49:44 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:49:44 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:49:44 --> Utf8 Class Initialized
INFO - 2021-12-11 05:49:44 --> URI Class Initialized
INFO - 2021-12-11 05:49:44 --> Router Class Initialized
INFO - 2021-12-11 05:49:44 --> Output Class Initialized
INFO - 2021-12-11 05:49:44 --> Security Class Initialized
DEBUG - 2021-12-11 05:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:49:44 --> Input Class Initialized
INFO - 2021-12-11 05:49:44 --> Language Class Initialized
INFO - 2021-12-11 05:49:44 --> Language Class Initialized
INFO - 2021-12-11 05:49:44 --> Config Class Initialized
INFO - 2021-12-11 05:49:44 --> Loader Class Initialized
INFO - 2021-12-11 05:49:44 --> Helper loaded: url_helper
INFO - 2021-12-11 05:49:44 --> Helper loaded: file_helper
INFO - 2021-12-11 05:49:44 --> Helper loaded: form_helper
INFO - 2021-12-11 05:49:44 --> Helper loaded: my_helper
INFO - 2021-12-11 05:49:44 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:49:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:49:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:49:44 --> Controller Class Initialized
DEBUG - 2021-12-11 05:49:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-11 05:49:44 --> Final output sent to browser
DEBUG - 2021-12-11 05:49:44 --> Total execution time: 0.0650
INFO - 2021-12-11 05:49:47 --> Config Class Initialized
INFO - 2021-12-11 05:49:47 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:49:47 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:49:47 --> Utf8 Class Initialized
INFO - 2021-12-11 05:49:47 --> URI Class Initialized
INFO - 2021-12-11 05:49:47 --> Router Class Initialized
INFO - 2021-12-11 05:49:47 --> Output Class Initialized
INFO - 2021-12-11 05:49:47 --> Security Class Initialized
DEBUG - 2021-12-11 05:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:49:47 --> Input Class Initialized
INFO - 2021-12-11 05:49:47 --> Language Class Initialized
INFO - 2021-12-11 05:49:47 --> Language Class Initialized
INFO - 2021-12-11 05:49:47 --> Config Class Initialized
INFO - 2021-12-11 05:49:47 --> Loader Class Initialized
INFO - 2021-12-11 05:49:47 --> Helper loaded: url_helper
INFO - 2021-12-11 05:49:47 --> Helper loaded: file_helper
INFO - 2021-12-11 05:49:47 --> Helper loaded: form_helper
INFO - 2021-12-11 05:49:47 --> Helper loaded: my_helper
INFO - 2021-12-11 05:49:47 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:49:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:49:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:49:47 --> Controller Class Initialized
DEBUG - 2021-12-11 05:49:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-11 05:49:47 --> Final output sent to browser
DEBUG - 2021-12-11 05:49:47 --> Total execution time: 0.0620
INFO - 2021-12-11 05:49:48 --> Config Class Initialized
INFO - 2021-12-11 05:49:48 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:49:48 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:49:48 --> Utf8 Class Initialized
INFO - 2021-12-11 05:49:48 --> URI Class Initialized
INFO - 2021-12-11 05:49:48 --> Router Class Initialized
INFO - 2021-12-11 05:49:48 --> Output Class Initialized
INFO - 2021-12-11 05:49:48 --> Security Class Initialized
DEBUG - 2021-12-11 05:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:49:48 --> Input Class Initialized
INFO - 2021-12-11 05:49:48 --> Language Class Initialized
INFO - 2021-12-11 05:49:48 --> Language Class Initialized
INFO - 2021-12-11 05:49:48 --> Config Class Initialized
INFO - 2021-12-11 05:49:48 --> Loader Class Initialized
INFO - 2021-12-11 05:49:48 --> Helper loaded: url_helper
INFO - 2021-12-11 05:49:48 --> Helper loaded: file_helper
INFO - 2021-12-11 05:49:48 --> Helper loaded: form_helper
INFO - 2021-12-11 05:49:48 --> Helper loaded: my_helper
INFO - 2021-12-11 05:49:48 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:49:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:49:48 --> Controller Class Initialized
DEBUG - 2021-12-11 05:49:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-11 05:49:48 --> Final output sent to browser
DEBUG - 2021-12-11 05:49:48 --> Total execution time: 0.0600
INFO - 2021-12-11 05:49:51 --> Config Class Initialized
INFO - 2021-12-11 05:49:51 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:49:51 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:49:51 --> Utf8 Class Initialized
INFO - 2021-12-11 05:49:51 --> URI Class Initialized
INFO - 2021-12-11 05:49:51 --> Router Class Initialized
INFO - 2021-12-11 05:49:51 --> Output Class Initialized
INFO - 2021-12-11 05:49:51 --> Security Class Initialized
DEBUG - 2021-12-11 05:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:49:51 --> Input Class Initialized
INFO - 2021-12-11 05:49:51 --> Language Class Initialized
INFO - 2021-12-11 05:49:51 --> Language Class Initialized
INFO - 2021-12-11 05:49:51 --> Config Class Initialized
INFO - 2021-12-11 05:49:51 --> Loader Class Initialized
INFO - 2021-12-11 05:49:51 --> Helper loaded: url_helper
INFO - 2021-12-11 05:49:51 --> Helper loaded: file_helper
INFO - 2021-12-11 05:49:51 --> Helper loaded: form_helper
INFO - 2021-12-11 05:49:51 --> Helper loaded: my_helper
INFO - 2021-12-11 05:49:51 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:49:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:49:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:49:51 --> Controller Class Initialized
DEBUG - 2021-12-11 05:49:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-11 05:49:51 --> Final output sent to browser
DEBUG - 2021-12-11 05:49:51 --> Total execution time: 0.0610
INFO - 2021-12-11 05:49:53 --> Config Class Initialized
INFO - 2021-12-11 05:49:53 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:49:53 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:49:53 --> Utf8 Class Initialized
INFO - 2021-12-11 05:49:53 --> URI Class Initialized
INFO - 2021-12-11 05:49:53 --> Router Class Initialized
INFO - 2021-12-11 05:49:53 --> Output Class Initialized
INFO - 2021-12-11 05:49:53 --> Security Class Initialized
DEBUG - 2021-12-11 05:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:49:53 --> Input Class Initialized
INFO - 2021-12-11 05:49:53 --> Language Class Initialized
INFO - 2021-12-11 05:49:53 --> Language Class Initialized
INFO - 2021-12-11 05:49:53 --> Config Class Initialized
INFO - 2021-12-11 05:49:53 --> Loader Class Initialized
INFO - 2021-12-11 05:49:53 --> Helper loaded: url_helper
INFO - 2021-12-11 05:49:53 --> Helper loaded: file_helper
INFO - 2021-12-11 05:49:53 --> Helper loaded: form_helper
INFO - 2021-12-11 05:49:53 --> Helper loaded: my_helper
INFO - 2021-12-11 05:49:53 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:49:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:49:53 --> Controller Class Initialized
DEBUG - 2021-12-11 05:49:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-11 05:49:53 --> Final output sent to browser
DEBUG - 2021-12-11 05:49:53 --> Total execution time: 0.0610
INFO - 2021-12-11 05:49:56 --> Config Class Initialized
INFO - 2021-12-11 05:49:56 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:49:56 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:49:56 --> Utf8 Class Initialized
INFO - 2021-12-11 05:49:56 --> URI Class Initialized
INFO - 2021-12-11 05:49:56 --> Router Class Initialized
INFO - 2021-12-11 05:49:56 --> Output Class Initialized
INFO - 2021-12-11 05:49:56 --> Security Class Initialized
DEBUG - 2021-12-11 05:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:49:56 --> Input Class Initialized
INFO - 2021-12-11 05:49:56 --> Language Class Initialized
INFO - 2021-12-11 05:49:56 --> Language Class Initialized
INFO - 2021-12-11 05:49:56 --> Config Class Initialized
INFO - 2021-12-11 05:49:56 --> Loader Class Initialized
INFO - 2021-12-11 05:49:56 --> Helper loaded: url_helper
INFO - 2021-12-11 05:49:56 --> Helper loaded: file_helper
INFO - 2021-12-11 05:49:56 --> Helper loaded: form_helper
INFO - 2021-12-11 05:49:56 --> Helper loaded: my_helper
INFO - 2021-12-11 05:49:56 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:49:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:49:56 --> Controller Class Initialized
DEBUG - 2021-12-11 05:49:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-11 05:49:56 --> Final output sent to browser
DEBUG - 2021-12-11 05:49:56 --> Total execution time: 0.0650
INFO - 2021-12-11 05:50:00 --> Config Class Initialized
INFO - 2021-12-11 05:50:00 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:50:00 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:50:00 --> Utf8 Class Initialized
INFO - 2021-12-11 05:50:00 --> URI Class Initialized
INFO - 2021-12-11 05:50:00 --> Router Class Initialized
INFO - 2021-12-11 05:50:00 --> Output Class Initialized
INFO - 2021-12-11 05:50:00 --> Security Class Initialized
DEBUG - 2021-12-11 05:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:50:00 --> Input Class Initialized
INFO - 2021-12-11 05:50:00 --> Language Class Initialized
INFO - 2021-12-11 05:50:00 --> Language Class Initialized
INFO - 2021-12-11 05:50:00 --> Config Class Initialized
INFO - 2021-12-11 05:50:00 --> Loader Class Initialized
INFO - 2021-12-11 05:50:00 --> Helper loaded: url_helper
INFO - 2021-12-11 05:50:00 --> Helper loaded: file_helper
INFO - 2021-12-11 05:50:00 --> Helper loaded: form_helper
INFO - 2021-12-11 05:50:00 --> Helper loaded: my_helper
INFO - 2021-12-11 05:50:00 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:50:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:50:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:50:00 --> Controller Class Initialized
DEBUG - 2021-12-11 05:50:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-11 05:50:00 --> Final output sent to browser
DEBUG - 2021-12-11 05:50:00 --> Total execution time: 0.0680
INFO - 2021-12-11 05:50:02 --> Config Class Initialized
INFO - 2021-12-11 05:50:02 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:50:02 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:50:02 --> Utf8 Class Initialized
INFO - 2021-12-11 05:50:02 --> URI Class Initialized
INFO - 2021-12-11 05:50:02 --> Router Class Initialized
INFO - 2021-12-11 05:50:02 --> Output Class Initialized
INFO - 2021-12-11 05:50:02 --> Security Class Initialized
DEBUG - 2021-12-11 05:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:50:02 --> Input Class Initialized
INFO - 2021-12-11 05:50:02 --> Language Class Initialized
INFO - 2021-12-11 05:50:02 --> Language Class Initialized
INFO - 2021-12-11 05:50:02 --> Config Class Initialized
INFO - 2021-12-11 05:50:02 --> Loader Class Initialized
INFO - 2021-12-11 05:50:02 --> Helper loaded: url_helper
INFO - 2021-12-11 05:50:02 --> Helper loaded: file_helper
INFO - 2021-12-11 05:50:02 --> Helper loaded: form_helper
INFO - 2021-12-11 05:50:02 --> Helper loaded: my_helper
INFO - 2021-12-11 05:50:02 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:50:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:50:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:50:02 --> Controller Class Initialized
DEBUG - 2021-12-11 05:50:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-11 05:50:02 --> Final output sent to browser
DEBUG - 2021-12-11 05:50:02 --> Total execution time: 0.0660
INFO - 2021-12-11 05:50:05 --> Config Class Initialized
INFO - 2021-12-11 05:50:05 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:50:05 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:50:05 --> Utf8 Class Initialized
INFO - 2021-12-11 05:50:05 --> URI Class Initialized
INFO - 2021-12-11 05:50:05 --> Router Class Initialized
INFO - 2021-12-11 05:50:05 --> Output Class Initialized
INFO - 2021-12-11 05:50:05 --> Security Class Initialized
DEBUG - 2021-12-11 05:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:50:05 --> Input Class Initialized
INFO - 2021-12-11 05:50:05 --> Language Class Initialized
INFO - 2021-12-11 05:50:05 --> Language Class Initialized
INFO - 2021-12-11 05:50:05 --> Config Class Initialized
INFO - 2021-12-11 05:50:05 --> Loader Class Initialized
INFO - 2021-12-11 05:50:05 --> Helper loaded: url_helper
INFO - 2021-12-11 05:50:05 --> Helper loaded: file_helper
INFO - 2021-12-11 05:50:05 --> Helper loaded: form_helper
INFO - 2021-12-11 05:50:05 --> Helper loaded: my_helper
INFO - 2021-12-11 05:50:05 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:50:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:50:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:50:05 --> Controller Class Initialized
DEBUG - 2021-12-11 05:50:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-11 05:50:05 --> Final output sent to browser
DEBUG - 2021-12-11 05:50:05 --> Total execution time: 0.0560
INFO - 2021-12-11 05:50:06 --> Config Class Initialized
INFO - 2021-12-11 05:50:06 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:50:06 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:50:06 --> Utf8 Class Initialized
INFO - 2021-12-11 05:50:06 --> URI Class Initialized
INFO - 2021-12-11 05:50:06 --> Router Class Initialized
INFO - 2021-12-11 05:50:06 --> Output Class Initialized
INFO - 2021-12-11 05:50:06 --> Security Class Initialized
DEBUG - 2021-12-11 05:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:50:06 --> Input Class Initialized
INFO - 2021-12-11 05:50:06 --> Language Class Initialized
INFO - 2021-12-11 05:50:07 --> Language Class Initialized
INFO - 2021-12-11 05:50:07 --> Config Class Initialized
INFO - 2021-12-11 05:50:07 --> Loader Class Initialized
INFO - 2021-12-11 05:50:07 --> Helper loaded: url_helper
INFO - 2021-12-11 05:50:07 --> Helper loaded: file_helper
INFO - 2021-12-11 05:50:07 --> Helper loaded: form_helper
INFO - 2021-12-11 05:50:07 --> Helper loaded: my_helper
INFO - 2021-12-11 05:50:07 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:50:07 --> Controller Class Initialized
DEBUG - 2021-12-11 05:50:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-11 05:50:07 --> Final output sent to browser
DEBUG - 2021-12-11 05:50:07 --> Total execution time: 0.0620
INFO - 2021-12-11 05:50:08 --> Config Class Initialized
INFO - 2021-12-11 05:50:08 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:50:08 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:50:08 --> Utf8 Class Initialized
INFO - 2021-12-11 05:50:08 --> URI Class Initialized
INFO - 2021-12-11 05:50:08 --> Router Class Initialized
INFO - 2021-12-11 05:50:08 --> Output Class Initialized
INFO - 2021-12-11 05:50:08 --> Security Class Initialized
DEBUG - 2021-12-11 05:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:50:08 --> Input Class Initialized
INFO - 2021-12-11 05:50:08 --> Language Class Initialized
INFO - 2021-12-11 05:50:08 --> Language Class Initialized
INFO - 2021-12-11 05:50:08 --> Config Class Initialized
INFO - 2021-12-11 05:50:08 --> Loader Class Initialized
INFO - 2021-12-11 05:50:08 --> Helper loaded: url_helper
INFO - 2021-12-11 05:50:08 --> Helper loaded: file_helper
INFO - 2021-12-11 05:50:08 --> Helper loaded: form_helper
INFO - 2021-12-11 05:50:08 --> Helper loaded: my_helper
INFO - 2021-12-11 05:50:08 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:50:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:50:08 --> Controller Class Initialized
DEBUG - 2021-12-11 05:50:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-11 05:50:08 --> Final output sent to browser
DEBUG - 2021-12-11 05:50:08 --> Total execution time: 0.0620
INFO - 2021-12-11 05:50:13 --> Config Class Initialized
INFO - 2021-12-11 05:50:13 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:50:13 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:50:13 --> Utf8 Class Initialized
INFO - 2021-12-11 05:50:13 --> URI Class Initialized
INFO - 2021-12-11 05:50:13 --> Router Class Initialized
INFO - 2021-12-11 05:50:13 --> Output Class Initialized
INFO - 2021-12-11 05:50:13 --> Security Class Initialized
DEBUG - 2021-12-11 05:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:50:13 --> Input Class Initialized
INFO - 2021-12-11 05:50:13 --> Language Class Initialized
INFO - 2021-12-11 05:50:13 --> Language Class Initialized
INFO - 2021-12-11 05:50:13 --> Config Class Initialized
INFO - 2021-12-11 05:50:13 --> Loader Class Initialized
INFO - 2021-12-11 05:50:13 --> Helper loaded: url_helper
INFO - 2021-12-11 05:50:13 --> Helper loaded: file_helper
INFO - 2021-12-11 05:50:13 --> Helper loaded: form_helper
INFO - 2021-12-11 05:50:13 --> Helper loaded: my_helper
INFO - 2021-12-11 05:50:13 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:50:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:50:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:50:13 --> Controller Class Initialized
DEBUG - 2021-12-11 05:50:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-11 05:50:13 --> Final output sent to browser
DEBUG - 2021-12-11 05:50:13 --> Total execution time: 0.0470
INFO - 2021-12-11 05:50:16 --> Config Class Initialized
INFO - 2021-12-11 05:50:16 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:50:16 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:50:16 --> Utf8 Class Initialized
INFO - 2021-12-11 05:50:16 --> URI Class Initialized
INFO - 2021-12-11 05:50:16 --> Router Class Initialized
INFO - 2021-12-11 05:50:16 --> Output Class Initialized
INFO - 2021-12-11 05:50:16 --> Security Class Initialized
DEBUG - 2021-12-11 05:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:50:16 --> Input Class Initialized
INFO - 2021-12-11 05:50:16 --> Language Class Initialized
INFO - 2021-12-11 05:50:16 --> Language Class Initialized
INFO - 2021-12-11 05:50:16 --> Config Class Initialized
INFO - 2021-12-11 05:50:16 --> Loader Class Initialized
INFO - 2021-12-11 05:50:16 --> Helper loaded: url_helper
INFO - 2021-12-11 05:50:16 --> Helper loaded: file_helper
INFO - 2021-12-11 05:50:16 --> Helper loaded: form_helper
INFO - 2021-12-11 05:50:16 --> Helper loaded: my_helper
INFO - 2021-12-11 05:50:16 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:50:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:50:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:50:16 --> Controller Class Initialized
DEBUG - 2021-12-11 05:50:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-11 05:50:16 --> Final output sent to browser
DEBUG - 2021-12-11 05:50:16 --> Total execution time: 0.0620
INFO - 2021-12-11 05:50:18 --> Config Class Initialized
INFO - 2021-12-11 05:50:18 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:50:18 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:50:18 --> Utf8 Class Initialized
INFO - 2021-12-11 05:50:18 --> URI Class Initialized
INFO - 2021-12-11 05:50:18 --> Router Class Initialized
INFO - 2021-12-11 05:50:18 --> Output Class Initialized
INFO - 2021-12-11 05:50:18 --> Security Class Initialized
DEBUG - 2021-12-11 05:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:50:18 --> Input Class Initialized
INFO - 2021-12-11 05:50:18 --> Language Class Initialized
INFO - 2021-12-11 05:50:18 --> Language Class Initialized
INFO - 2021-12-11 05:50:18 --> Config Class Initialized
INFO - 2021-12-11 05:50:18 --> Loader Class Initialized
INFO - 2021-12-11 05:50:18 --> Helper loaded: url_helper
INFO - 2021-12-11 05:50:18 --> Helper loaded: file_helper
INFO - 2021-12-11 05:50:18 --> Helper loaded: form_helper
INFO - 2021-12-11 05:50:18 --> Helper loaded: my_helper
INFO - 2021-12-11 05:50:18 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:50:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:50:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:50:18 --> Controller Class Initialized
DEBUG - 2021-12-11 05:50:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-11 05:50:18 --> Final output sent to browser
DEBUG - 2021-12-11 05:50:18 --> Total execution time: 0.0490
INFO - 2021-12-11 05:50:20 --> Config Class Initialized
INFO - 2021-12-11 05:50:20 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:50:20 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:50:20 --> Utf8 Class Initialized
INFO - 2021-12-11 05:50:20 --> URI Class Initialized
INFO - 2021-12-11 05:50:20 --> Router Class Initialized
INFO - 2021-12-11 05:50:20 --> Output Class Initialized
INFO - 2021-12-11 05:50:20 --> Security Class Initialized
DEBUG - 2021-12-11 05:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:50:20 --> Input Class Initialized
INFO - 2021-12-11 05:50:20 --> Language Class Initialized
INFO - 2021-12-11 05:50:20 --> Language Class Initialized
INFO - 2021-12-11 05:50:20 --> Config Class Initialized
INFO - 2021-12-11 05:50:20 --> Loader Class Initialized
INFO - 2021-12-11 05:50:20 --> Helper loaded: url_helper
INFO - 2021-12-11 05:50:20 --> Helper loaded: file_helper
INFO - 2021-12-11 05:50:20 --> Helper loaded: form_helper
INFO - 2021-12-11 05:50:20 --> Helper loaded: my_helper
INFO - 2021-12-11 05:50:20 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:50:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:50:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:50:20 --> Controller Class Initialized
DEBUG - 2021-12-11 05:50:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-11 05:50:20 --> Final output sent to browser
DEBUG - 2021-12-11 05:50:20 --> Total execution time: 0.0580
INFO - 2021-12-11 05:50:23 --> Config Class Initialized
INFO - 2021-12-11 05:50:23 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:50:23 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:50:23 --> Utf8 Class Initialized
INFO - 2021-12-11 05:50:23 --> URI Class Initialized
INFO - 2021-12-11 05:50:23 --> Router Class Initialized
INFO - 2021-12-11 05:50:23 --> Output Class Initialized
INFO - 2021-12-11 05:50:23 --> Security Class Initialized
DEBUG - 2021-12-11 05:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:50:23 --> Input Class Initialized
INFO - 2021-12-11 05:50:23 --> Language Class Initialized
INFO - 2021-12-11 05:50:23 --> Language Class Initialized
INFO - 2021-12-11 05:50:23 --> Config Class Initialized
INFO - 2021-12-11 05:50:23 --> Loader Class Initialized
INFO - 2021-12-11 05:50:23 --> Helper loaded: url_helper
INFO - 2021-12-11 05:50:23 --> Helper loaded: file_helper
INFO - 2021-12-11 05:50:23 --> Helper loaded: form_helper
INFO - 2021-12-11 05:50:23 --> Helper loaded: my_helper
INFO - 2021-12-11 05:50:23 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:50:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:50:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:50:23 --> Controller Class Initialized
DEBUG - 2021-12-11 05:50:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-11 05:50:23 --> Final output sent to browser
DEBUG - 2021-12-11 05:50:23 --> Total execution time: 0.0590
INFO - 2021-12-11 05:50:25 --> Config Class Initialized
INFO - 2021-12-11 05:50:25 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:50:25 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:50:25 --> Utf8 Class Initialized
INFO - 2021-12-11 05:50:25 --> URI Class Initialized
INFO - 2021-12-11 05:50:25 --> Router Class Initialized
INFO - 2021-12-11 05:50:25 --> Output Class Initialized
INFO - 2021-12-11 05:50:25 --> Security Class Initialized
DEBUG - 2021-12-11 05:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:50:25 --> Input Class Initialized
INFO - 2021-12-11 05:50:25 --> Language Class Initialized
INFO - 2021-12-11 05:50:25 --> Language Class Initialized
INFO - 2021-12-11 05:50:25 --> Config Class Initialized
INFO - 2021-12-11 05:50:25 --> Loader Class Initialized
INFO - 2021-12-11 05:50:25 --> Helper loaded: url_helper
INFO - 2021-12-11 05:50:25 --> Helper loaded: file_helper
INFO - 2021-12-11 05:50:25 --> Helper loaded: form_helper
INFO - 2021-12-11 05:50:25 --> Helper loaded: my_helper
INFO - 2021-12-11 05:50:25 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:50:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:50:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:50:25 --> Controller Class Initialized
DEBUG - 2021-12-11 05:50:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-11 05:50:25 --> Final output sent to browser
DEBUG - 2021-12-11 05:50:25 --> Total execution time: 0.0580
INFO - 2021-12-11 05:50:27 --> Config Class Initialized
INFO - 2021-12-11 05:50:27 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:50:27 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:50:27 --> Utf8 Class Initialized
INFO - 2021-12-11 05:50:27 --> URI Class Initialized
INFO - 2021-12-11 05:50:27 --> Router Class Initialized
INFO - 2021-12-11 05:50:27 --> Output Class Initialized
INFO - 2021-12-11 05:50:27 --> Security Class Initialized
DEBUG - 2021-12-11 05:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:50:27 --> Input Class Initialized
INFO - 2021-12-11 05:50:27 --> Language Class Initialized
INFO - 2021-12-11 05:50:27 --> Language Class Initialized
INFO - 2021-12-11 05:50:27 --> Config Class Initialized
INFO - 2021-12-11 05:50:27 --> Loader Class Initialized
INFO - 2021-12-11 05:50:27 --> Helper loaded: url_helper
INFO - 2021-12-11 05:50:27 --> Helper loaded: file_helper
INFO - 2021-12-11 05:50:27 --> Helper loaded: form_helper
INFO - 2021-12-11 05:50:27 --> Helper loaded: my_helper
INFO - 2021-12-11 05:50:27 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:50:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:50:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:50:27 --> Controller Class Initialized
DEBUG - 2021-12-11 05:50:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-11 05:50:27 --> Final output sent to browser
DEBUG - 2021-12-11 05:50:27 --> Total execution time: 0.0550
INFO - 2021-12-11 05:50:28 --> Config Class Initialized
INFO - 2021-12-11 05:50:28 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:50:28 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:50:28 --> Utf8 Class Initialized
INFO - 2021-12-11 05:50:28 --> URI Class Initialized
INFO - 2021-12-11 05:50:28 --> Router Class Initialized
INFO - 2021-12-11 05:50:28 --> Output Class Initialized
INFO - 2021-12-11 05:50:28 --> Security Class Initialized
DEBUG - 2021-12-11 05:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:50:28 --> Input Class Initialized
INFO - 2021-12-11 05:50:28 --> Language Class Initialized
INFO - 2021-12-11 05:50:28 --> Language Class Initialized
INFO - 2021-12-11 05:50:28 --> Config Class Initialized
INFO - 2021-12-11 05:50:28 --> Loader Class Initialized
INFO - 2021-12-11 05:50:28 --> Helper loaded: url_helper
INFO - 2021-12-11 05:50:28 --> Helper loaded: file_helper
INFO - 2021-12-11 05:50:28 --> Helper loaded: form_helper
INFO - 2021-12-11 05:50:28 --> Helper loaded: my_helper
INFO - 2021-12-11 05:50:28 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:50:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:50:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:50:28 --> Controller Class Initialized
DEBUG - 2021-12-11 05:50:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-11 05:50:28 --> Final output sent to browser
DEBUG - 2021-12-11 05:50:28 --> Total execution time: 0.0470
INFO - 2021-12-11 05:53:13 --> Config Class Initialized
INFO - 2021-12-11 05:53:13 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:53:13 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:53:13 --> Utf8 Class Initialized
INFO - 2021-12-11 05:53:13 --> URI Class Initialized
INFO - 2021-12-11 05:53:13 --> Router Class Initialized
INFO - 2021-12-11 05:53:13 --> Output Class Initialized
INFO - 2021-12-11 05:53:13 --> Security Class Initialized
DEBUG - 2021-12-11 05:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:53:13 --> Input Class Initialized
INFO - 2021-12-11 05:53:13 --> Language Class Initialized
INFO - 2021-12-11 05:53:13 --> Language Class Initialized
INFO - 2021-12-11 05:53:13 --> Config Class Initialized
INFO - 2021-12-11 05:53:13 --> Loader Class Initialized
INFO - 2021-12-11 05:53:13 --> Helper loaded: url_helper
INFO - 2021-12-11 05:53:13 --> Helper loaded: file_helper
INFO - 2021-12-11 05:53:13 --> Helper loaded: form_helper
INFO - 2021-12-11 05:53:13 --> Helper loaded: my_helper
INFO - 2021-12-11 05:53:13 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:53:13 --> Controller Class Initialized
INFO - 2021-12-11 05:53:13 --> Helper loaded: cookie_helper
INFO - 2021-12-11 05:53:13 --> Config Class Initialized
INFO - 2021-12-11 05:53:13 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:53:13 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:53:13 --> Utf8 Class Initialized
INFO - 2021-12-11 05:53:13 --> URI Class Initialized
INFO - 2021-12-11 05:53:13 --> Router Class Initialized
INFO - 2021-12-11 05:53:13 --> Output Class Initialized
INFO - 2021-12-11 05:53:13 --> Security Class Initialized
DEBUG - 2021-12-11 05:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:53:13 --> Input Class Initialized
INFO - 2021-12-11 05:53:13 --> Language Class Initialized
INFO - 2021-12-11 05:53:13 --> Language Class Initialized
INFO - 2021-12-11 05:53:13 --> Config Class Initialized
INFO - 2021-12-11 05:53:13 --> Loader Class Initialized
INFO - 2021-12-11 05:53:13 --> Helper loaded: url_helper
INFO - 2021-12-11 05:53:13 --> Helper loaded: file_helper
INFO - 2021-12-11 05:53:13 --> Helper loaded: form_helper
INFO - 2021-12-11 05:53:13 --> Helper loaded: my_helper
INFO - 2021-12-11 05:53:13 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:53:13 --> Controller Class Initialized
DEBUG - 2021-12-11 05:53:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-11 05:53:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-11 05:53:13 --> Final output sent to browser
DEBUG - 2021-12-11 05:53:13 --> Total execution time: 0.0350
INFO - 2021-12-11 05:53:17 --> Config Class Initialized
INFO - 2021-12-11 05:53:17 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:53:17 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:53:17 --> Utf8 Class Initialized
INFO - 2021-12-11 05:53:17 --> URI Class Initialized
INFO - 2021-12-11 05:53:17 --> Router Class Initialized
INFO - 2021-12-11 05:53:17 --> Output Class Initialized
INFO - 2021-12-11 05:53:17 --> Security Class Initialized
DEBUG - 2021-12-11 05:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:53:17 --> Input Class Initialized
INFO - 2021-12-11 05:53:17 --> Language Class Initialized
INFO - 2021-12-11 05:53:17 --> Language Class Initialized
INFO - 2021-12-11 05:53:17 --> Config Class Initialized
INFO - 2021-12-11 05:53:17 --> Loader Class Initialized
INFO - 2021-12-11 05:53:17 --> Helper loaded: url_helper
INFO - 2021-12-11 05:53:17 --> Helper loaded: file_helper
INFO - 2021-12-11 05:53:17 --> Helper loaded: form_helper
INFO - 2021-12-11 05:53:17 --> Helper loaded: my_helper
INFO - 2021-12-11 05:53:17 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:53:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:53:17 --> Controller Class Initialized
INFO - 2021-12-11 05:53:17 --> Helper loaded: cookie_helper
INFO - 2021-12-11 05:53:17 --> Final output sent to browser
DEBUG - 2021-12-11 05:53:17 --> Total execution time: 0.0440
INFO - 2021-12-11 05:53:17 --> Config Class Initialized
INFO - 2021-12-11 05:53:17 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:53:17 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:53:17 --> Utf8 Class Initialized
INFO - 2021-12-11 05:53:17 --> URI Class Initialized
INFO - 2021-12-11 05:53:17 --> Router Class Initialized
INFO - 2021-12-11 05:53:17 --> Output Class Initialized
INFO - 2021-12-11 05:53:17 --> Security Class Initialized
DEBUG - 2021-12-11 05:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:53:17 --> Input Class Initialized
INFO - 2021-12-11 05:53:17 --> Language Class Initialized
INFO - 2021-12-11 05:53:17 --> Language Class Initialized
INFO - 2021-12-11 05:53:17 --> Config Class Initialized
INFO - 2021-12-11 05:53:17 --> Loader Class Initialized
INFO - 2021-12-11 05:53:17 --> Helper loaded: url_helper
INFO - 2021-12-11 05:53:17 --> Helper loaded: file_helper
INFO - 2021-12-11 05:53:17 --> Helper loaded: form_helper
INFO - 2021-12-11 05:53:17 --> Helper loaded: my_helper
INFO - 2021-12-11 05:53:17 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:53:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:53:17 --> Controller Class Initialized
DEBUG - 2021-12-11 05:53:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-11 05:53:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-11 05:53:17 --> Final output sent to browser
DEBUG - 2021-12-11 05:53:17 --> Total execution time: 0.1700
INFO - 2021-12-11 05:53:28 --> Config Class Initialized
INFO - 2021-12-11 05:53:28 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:53:28 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:53:28 --> Utf8 Class Initialized
INFO - 2021-12-11 05:53:28 --> URI Class Initialized
INFO - 2021-12-11 05:53:28 --> Router Class Initialized
INFO - 2021-12-11 05:53:28 --> Output Class Initialized
INFO - 2021-12-11 05:53:28 --> Security Class Initialized
DEBUG - 2021-12-11 05:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:53:28 --> Input Class Initialized
INFO - 2021-12-11 05:53:28 --> Language Class Initialized
INFO - 2021-12-11 05:53:28 --> Language Class Initialized
INFO - 2021-12-11 05:53:28 --> Config Class Initialized
INFO - 2021-12-11 05:53:28 --> Loader Class Initialized
INFO - 2021-12-11 05:53:28 --> Helper loaded: url_helper
INFO - 2021-12-11 05:53:28 --> Helper loaded: file_helper
INFO - 2021-12-11 05:53:28 --> Helper loaded: form_helper
INFO - 2021-12-11 05:53:28 --> Helper loaded: my_helper
INFO - 2021-12-11 05:53:28 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:53:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:53:28 --> Controller Class Initialized
DEBUG - 2021-12-11 05:53:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-12-11 05:53:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-11 05:53:28 --> Final output sent to browser
DEBUG - 2021-12-11 05:53:28 --> Total execution time: 0.0600
INFO - 2021-12-11 05:53:28 --> Config Class Initialized
INFO - 2021-12-11 05:53:28 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:53:28 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:53:28 --> Utf8 Class Initialized
INFO - 2021-12-11 05:53:28 --> URI Class Initialized
INFO - 2021-12-11 05:53:28 --> Router Class Initialized
INFO - 2021-12-11 05:53:28 --> Output Class Initialized
INFO - 2021-12-11 05:53:28 --> Security Class Initialized
DEBUG - 2021-12-11 05:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:53:28 --> Input Class Initialized
INFO - 2021-12-11 05:53:28 --> Language Class Initialized
INFO - 2021-12-11 05:53:28 --> Language Class Initialized
INFO - 2021-12-11 05:53:28 --> Config Class Initialized
INFO - 2021-12-11 05:53:28 --> Loader Class Initialized
INFO - 2021-12-11 05:53:28 --> Helper loaded: url_helper
INFO - 2021-12-11 05:53:28 --> Helper loaded: file_helper
INFO - 2021-12-11 05:53:28 --> Helper loaded: form_helper
INFO - 2021-12-11 05:53:28 --> Helper loaded: my_helper
INFO - 2021-12-11 05:53:28 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:53:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:53:28 --> Controller Class Initialized
INFO - 2021-12-11 05:53:30 --> Config Class Initialized
INFO - 2021-12-11 05:53:30 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:53:30 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:53:30 --> Utf8 Class Initialized
INFO - 2021-12-11 05:53:30 --> URI Class Initialized
INFO - 2021-12-11 05:53:30 --> Router Class Initialized
INFO - 2021-12-11 05:53:30 --> Output Class Initialized
INFO - 2021-12-11 05:53:30 --> Security Class Initialized
DEBUG - 2021-12-11 05:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:53:30 --> Input Class Initialized
INFO - 2021-12-11 05:53:30 --> Language Class Initialized
INFO - 2021-12-11 05:53:30 --> Language Class Initialized
INFO - 2021-12-11 05:53:30 --> Config Class Initialized
INFO - 2021-12-11 05:53:30 --> Loader Class Initialized
INFO - 2021-12-11 05:53:30 --> Helper loaded: url_helper
INFO - 2021-12-11 05:53:30 --> Helper loaded: file_helper
INFO - 2021-12-11 05:53:30 --> Helper loaded: form_helper
INFO - 2021-12-11 05:53:30 --> Helper loaded: my_helper
INFO - 2021-12-11 05:53:30 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:53:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:53:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:53:30 --> Controller Class Initialized
INFO - 2021-12-11 05:53:31 --> Config Class Initialized
INFO - 2021-12-11 05:53:31 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:53:31 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:53:31 --> Utf8 Class Initialized
INFO - 2021-12-11 05:53:31 --> URI Class Initialized
INFO - 2021-12-11 05:53:31 --> Router Class Initialized
INFO - 2021-12-11 05:53:31 --> Output Class Initialized
INFO - 2021-12-11 05:53:31 --> Security Class Initialized
DEBUG - 2021-12-11 05:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:53:31 --> Input Class Initialized
INFO - 2021-12-11 05:53:31 --> Language Class Initialized
INFO - 2021-12-11 05:53:31 --> Language Class Initialized
INFO - 2021-12-11 05:53:31 --> Config Class Initialized
INFO - 2021-12-11 05:53:31 --> Loader Class Initialized
INFO - 2021-12-11 05:53:31 --> Helper loaded: url_helper
INFO - 2021-12-11 05:53:31 --> Helper loaded: file_helper
INFO - 2021-12-11 05:53:31 --> Helper loaded: form_helper
INFO - 2021-12-11 05:53:31 --> Helper loaded: my_helper
INFO - 2021-12-11 05:53:31 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:53:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:53:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:53:31 --> Controller Class Initialized
ERROR - 2021-12-11 05:53:31 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2021-12-11 05:53:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-12-11 05:53:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-11 05:53:31 --> Final output sent to browser
DEBUG - 2021-12-11 05:53:31 --> Total execution time: 0.0560
INFO - 2021-12-11 05:53:57 --> Config Class Initialized
INFO - 2021-12-11 05:53:57 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:53:57 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:53:57 --> Utf8 Class Initialized
INFO - 2021-12-11 05:53:57 --> URI Class Initialized
INFO - 2021-12-11 05:53:57 --> Router Class Initialized
INFO - 2021-12-11 05:53:57 --> Output Class Initialized
INFO - 2021-12-11 05:53:57 --> Security Class Initialized
DEBUG - 2021-12-11 05:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:53:57 --> Input Class Initialized
INFO - 2021-12-11 05:53:57 --> Language Class Initialized
INFO - 2021-12-11 05:53:57 --> Language Class Initialized
INFO - 2021-12-11 05:53:57 --> Config Class Initialized
INFO - 2021-12-11 05:53:57 --> Loader Class Initialized
INFO - 2021-12-11 05:53:57 --> Helper loaded: url_helper
INFO - 2021-12-11 05:53:57 --> Helper loaded: file_helper
INFO - 2021-12-11 05:53:57 --> Helper loaded: form_helper
INFO - 2021-12-11 05:53:57 --> Helper loaded: my_helper
INFO - 2021-12-11 05:53:57 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:53:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:53:57 --> Controller Class Initialized
INFO - 2021-12-11 05:53:57 --> Upload Class Initialized
INFO - 2021-12-11 05:53:57 --> Language file loaded: language/english/upload_lang.php
ERROR - 2021-12-11 05:53:57 --> The upload path does not appear to be valid.
INFO - 2021-12-11 05:53:57 --> Config Class Initialized
INFO - 2021-12-11 05:53:57 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:53:57 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:53:57 --> Utf8 Class Initialized
INFO - 2021-12-11 05:53:57 --> URI Class Initialized
INFO - 2021-12-11 05:53:57 --> Router Class Initialized
INFO - 2021-12-11 05:53:57 --> Output Class Initialized
INFO - 2021-12-11 05:53:57 --> Security Class Initialized
DEBUG - 2021-12-11 05:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:53:57 --> Input Class Initialized
INFO - 2021-12-11 05:53:57 --> Language Class Initialized
INFO - 2021-12-11 05:53:57 --> Language Class Initialized
INFO - 2021-12-11 05:53:57 --> Config Class Initialized
INFO - 2021-12-11 05:53:57 --> Loader Class Initialized
INFO - 2021-12-11 05:53:57 --> Helper loaded: url_helper
INFO - 2021-12-11 05:53:57 --> Helper loaded: file_helper
INFO - 2021-12-11 05:53:57 --> Helper loaded: form_helper
INFO - 2021-12-11 05:53:57 --> Helper loaded: my_helper
INFO - 2021-12-11 05:53:57 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:53:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:53:57 --> Controller Class Initialized
DEBUG - 2021-12-11 05:53:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-12-11 05:53:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-11 05:53:57 --> Final output sent to browser
DEBUG - 2021-12-11 05:53:57 --> Total execution time: 0.0410
INFO - 2021-12-11 05:53:58 --> Config Class Initialized
INFO - 2021-12-11 05:53:58 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:53:58 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:53:58 --> Utf8 Class Initialized
INFO - 2021-12-11 05:53:58 --> URI Class Initialized
INFO - 2021-12-11 05:53:58 --> Router Class Initialized
INFO - 2021-12-11 05:53:58 --> Output Class Initialized
INFO - 2021-12-11 05:53:58 --> Security Class Initialized
DEBUG - 2021-12-11 05:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:53:58 --> Input Class Initialized
INFO - 2021-12-11 05:53:58 --> Language Class Initialized
INFO - 2021-12-11 05:53:58 --> Language Class Initialized
INFO - 2021-12-11 05:53:58 --> Config Class Initialized
INFO - 2021-12-11 05:53:58 --> Loader Class Initialized
INFO - 2021-12-11 05:53:58 --> Helper loaded: url_helper
INFO - 2021-12-11 05:53:58 --> Helper loaded: file_helper
INFO - 2021-12-11 05:53:58 --> Helper loaded: form_helper
INFO - 2021-12-11 05:53:58 --> Helper loaded: my_helper
INFO - 2021-12-11 05:53:58 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:53:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:53:58 --> Controller Class Initialized
INFO - 2021-12-11 05:54:01 --> Config Class Initialized
INFO - 2021-12-11 05:54:01 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:54:01 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:54:01 --> Utf8 Class Initialized
INFO - 2021-12-11 05:54:01 --> URI Class Initialized
INFO - 2021-12-11 05:54:01 --> Router Class Initialized
INFO - 2021-12-11 05:54:01 --> Output Class Initialized
INFO - 2021-12-11 05:54:01 --> Security Class Initialized
DEBUG - 2021-12-11 05:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:54:01 --> Input Class Initialized
INFO - 2021-12-11 05:54:01 --> Language Class Initialized
INFO - 2021-12-11 05:54:01 --> Language Class Initialized
INFO - 2021-12-11 05:54:01 --> Config Class Initialized
INFO - 2021-12-11 05:54:01 --> Loader Class Initialized
INFO - 2021-12-11 05:54:01 --> Helper loaded: url_helper
INFO - 2021-12-11 05:54:01 --> Helper loaded: file_helper
INFO - 2021-12-11 05:54:01 --> Helper loaded: form_helper
INFO - 2021-12-11 05:54:01 --> Helper loaded: my_helper
INFO - 2021-12-11 05:54:01 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:54:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:54:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:54:01 --> Controller Class Initialized
DEBUG - 2021-12-11 05:54:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-11 05:54:01 --> Final output sent to browser
DEBUG - 2021-12-11 05:54:01 --> Total execution time: 0.1050
INFO - 2021-12-11 06:16:59 --> Config Class Initialized
INFO - 2021-12-11 06:16:59 --> Hooks Class Initialized
DEBUG - 2021-12-11 06:16:59 --> UTF-8 Support Enabled
INFO - 2021-12-11 06:16:59 --> Utf8 Class Initialized
INFO - 2021-12-11 06:16:59 --> URI Class Initialized
INFO - 2021-12-11 06:16:59 --> Router Class Initialized
INFO - 2021-12-11 06:16:59 --> Output Class Initialized
INFO - 2021-12-11 06:16:59 --> Security Class Initialized
DEBUG - 2021-12-11 06:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 06:16:59 --> Input Class Initialized
INFO - 2021-12-11 06:16:59 --> Language Class Initialized
INFO - 2021-12-11 06:16:59 --> Language Class Initialized
INFO - 2021-12-11 06:16:59 --> Config Class Initialized
INFO - 2021-12-11 06:16:59 --> Loader Class Initialized
INFO - 2021-12-11 06:16:59 --> Helper loaded: url_helper
INFO - 2021-12-11 06:16:59 --> Helper loaded: file_helper
INFO - 2021-12-11 06:16:59 --> Helper loaded: form_helper
INFO - 2021-12-11 06:16:59 --> Helper loaded: my_helper
INFO - 2021-12-11 06:16:59 --> Database Driver Class Initialized
DEBUG - 2021-12-11 06:16:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 06:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 06:16:59 --> Controller Class Initialized
INFO - 2021-12-11 06:16:59 --> Helper loaded: cookie_helper
INFO - 2021-12-11 06:16:59 --> Config Class Initialized
INFO - 2021-12-11 06:16:59 --> Hooks Class Initialized
DEBUG - 2021-12-11 06:16:59 --> UTF-8 Support Enabled
INFO - 2021-12-11 06:16:59 --> Utf8 Class Initialized
INFO - 2021-12-11 06:16:59 --> URI Class Initialized
INFO - 2021-12-11 06:16:59 --> Router Class Initialized
INFO - 2021-12-11 06:16:59 --> Output Class Initialized
INFO - 2021-12-11 06:16:59 --> Security Class Initialized
DEBUG - 2021-12-11 06:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 06:16:59 --> Input Class Initialized
INFO - 2021-12-11 06:16:59 --> Language Class Initialized
INFO - 2021-12-11 06:16:59 --> Language Class Initialized
INFO - 2021-12-11 06:16:59 --> Config Class Initialized
INFO - 2021-12-11 06:16:59 --> Loader Class Initialized
INFO - 2021-12-11 06:16:59 --> Helper loaded: url_helper
INFO - 2021-12-11 06:16:59 --> Helper loaded: file_helper
INFO - 2021-12-11 06:16:59 --> Helper loaded: form_helper
INFO - 2021-12-11 06:16:59 --> Helper loaded: my_helper
INFO - 2021-12-11 06:16:59 --> Database Driver Class Initialized
DEBUG - 2021-12-11 06:16:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 06:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 06:16:59 --> Controller Class Initialized
DEBUG - 2021-12-11 06:16:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-11 06:16:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-11 06:16:59 --> Final output sent to browser
DEBUG - 2021-12-11 06:16:59 --> Total execution time: 0.0250
