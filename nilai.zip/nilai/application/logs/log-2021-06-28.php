<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-06-28 02:10:49 --> Config Class Initialized
INFO - 2021-06-28 02:10:49 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:10:49 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:10:49 --> Utf8 Class Initialized
INFO - 2021-06-28 02:10:49 --> URI Class Initialized
DEBUG - 2021-06-28 02:10:49 --> No URI present. Default controller set.
INFO - 2021-06-28 02:10:49 --> Router Class Initialized
INFO - 2021-06-28 02:10:49 --> Output Class Initialized
INFO - 2021-06-28 02:10:49 --> Security Class Initialized
DEBUG - 2021-06-28 02:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:10:49 --> Input Class Initialized
INFO - 2021-06-28 02:10:49 --> Language Class Initialized
INFO - 2021-06-28 02:10:49 --> Language Class Initialized
INFO - 2021-06-28 02:10:49 --> Config Class Initialized
INFO - 2021-06-28 02:10:49 --> Loader Class Initialized
INFO - 2021-06-28 02:10:49 --> Helper loaded: url_helper
INFO - 2021-06-28 02:10:49 --> Helper loaded: file_helper
INFO - 2021-06-28 02:10:49 --> Helper loaded: form_helper
INFO - 2021-06-28 02:10:49 --> Helper loaded: my_helper
INFO - 2021-06-28 02:10:49 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:10:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:10:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:10:49 --> Controller Class Initialized
INFO - 2021-06-28 02:10:49 --> Config Class Initialized
INFO - 2021-06-28 02:10:49 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:10:49 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:10:49 --> Utf8 Class Initialized
INFO - 2021-06-28 02:10:49 --> URI Class Initialized
INFO - 2021-06-28 02:10:49 --> Router Class Initialized
INFO - 2021-06-28 02:10:49 --> Output Class Initialized
INFO - 2021-06-28 02:10:49 --> Security Class Initialized
DEBUG - 2021-06-28 02:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:10:49 --> Input Class Initialized
INFO - 2021-06-28 02:10:49 --> Language Class Initialized
INFO - 2021-06-28 02:10:49 --> Language Class Initialized
INFO - 2021-06-28 02:10:49 --> Config Class Initialized
INFO - 2021-06-28 02:10:49 --> Loader Class Initialized
INFO - 2021-06-28 02:10:49 --> Helper loaded: url_helper
INFO - 2021-06-28 02:10:49 --> Helper loaded: file_helper
INFO - 2021-06-28 02:10:49 --> Helper loaded: form_helper
INFO - 2021-06-28 02:10:49 --> Helper loaded: my_helper
INFO - 2021-06-28 02:10:49 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:10:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:10:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:10:49 --> Controller Class Initialized
DEBUG - 2021-06-28 02:10:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-28 02:10:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 02:10:49 --> Final output sent to browser
DEBUG - 2021-06-28 02:10:49 --> Total execution time: 0.0443
INFO - 2021-06-28 02:10:50 --> Config Class Initialized
INFO - 2021-06-28 02:10:50 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:10:50 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:10:50 --> Utf8 Class Initialized
INFO - 2021-06-28 02:10:50 --> URI Class Initialized
DEBUG - 2021-06-28 02:10:50 --> No URI present. Default controller set.
INFO - 2021-06-28 02:10:50 --> Router Class Initialized
INFO - 2021-06-28 02:10:50 --> Output Class Initialized
INFO - 2021-06-28 02:10:50 --> Security Class Initialized
DEBUG - 2021-06-28 02:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:10:50 --> Input Class Initialized
INFO - 2021-06-28 02:10:50 --> Language Class Initialized
INFO - 2021-06-28 02:10:50 --> Language Class Initialized
INFO - 2021-06-28 02:10:50 --> Config Class Initialized
INFO - 2021-06-28 02:10:50 --> Loader Class Initialized
INFO - 2021-06-28 02:10:50 --> Helper loaded: url_helper
INFO - 2021-06-28 02:10:50 --> Helper loaded: file_helper
INFO - 2021-06-28 02:10:50 --> Helper loaded: form_helper
INFO - 2021-06-28 02:10:50 --> Helper loaded: my_helper
INFO - 2021-06-28 02:10:50 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:10:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:10:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:10:50 --> Controller Class Initialized
INFO - 2021-06-28 02:10:50 --> Config Class Initialized
INFO - 2021-06-28 02:10:50 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:10:50 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:10:50 --> Utf8 Class Initialized
INFO - 2021-06-28 02:10:50 --> URI Class Initialized
INFO - 2021-06-28 02:10:50 --> Router Class Initialized
INFO - 2021-06-28 02:10:50 --> Output Class Initialized
INFO - 2021-06-28 02:10:50 --> Security Class Initialized
DEBUG - 2021-06-28 02:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:10:50 --> Input Class Initialized
INFO - 2021-06-28 02:10:50 --> Language Class Initialized
INFO - 2021-06-28 02:10:50 --> Language Class Initialized
INFO - 2021-06-28 02:10:50 --> Config Class Initialized
INFO - 2021-06-28 02:10:50 --> Loader Class Initialized
INFO - 2021-06-28 02:10:50 --> Helper loaded: url_helper
INFO - 2021-06-28 02:10:50 --> Helper loaded: file_helper
INFO - 2021-06-28 02:10:50 --> Helper loaded: form_helper
INFO - 2021-06-28 02:10:50 --> Helper loaded: my_helper
INFO - 2021-06-28 02:10:50 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:10:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:10:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:10:50 --> Controller Class Initialized
DEBUG - 2021-06-28 02:10:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-28 02:10:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 02:10:50 --> Final output sent to browser
DEBUG - 2021-06-28 02:10:50 --> Total execution time: 0.0523
INFO - 2021-06-28 02:10:53 --> Config Class Initialized
INFO - 2021-06-28 02:10:53 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:10:53 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:10:53 --> Utf8 Class Initialized
INFO - 2021-06-28 02:10:53 --> URI Class Initialized
INFO - 2021-06-28 02:10:53 --> Router Class Initialized
INFO - 2021-06-28 02:10:53 --> Output Class Initialized
INFO - 2021-06-28 02:10:53 --> Security Class Initialized
DEBUG - 2021-06-28 02:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:10:53 --> Input Class Initialized
INFO - 2021-06-28 02:10:53 --> Language Class Initialized
INFO - 2021-06-28 02:10:53 --> Language Class Initialized
INFO - 2021-06-28 02:10:53 --> Config Class Initialized
INFO - 2021-06-28 02:10:53 --> Loader Class Initialized
INFO - 2021-06-28 02:10:53 --> Helper loaded: url_helper
INFO - 2021-06-28 02:10:53 --> Helper loaded: file_helper
INFO - 2021-06-28 02:10:53 --> Helper loaded: form_helper
INFO - 2021-06-28 02:10:53 --> Helper loaded: my_helper
INFO - 2021-06-28 02:10:53 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:10:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:10:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:10:53 --> Controller Class Initialized
INFO - 2021-06-28 02:10:53 --> Helper loaded: cookie_helper
INFO - 2021-06-28 02:10:53 --> Final output sent to browser
DEBUG - 2021-06-28 02:10:53 --> Total execution time: 0.0786
INFO - 2021-06-28 02:10:54 --> Config Class Initialized
INFO - 2021-06-28 02:10:54 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:10:54 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:10:54 --> Utf8 Class Initialized
INFO - 2021-06-28 02:10:54 --> URI Class Initialized
INFO - 2021-06-28 02:10:54 --> Router Class Initialized
INFO - 2021-06-28 02:10:54 --> Output Class Initialized
INFO - 2021-06-28 02:10:54 --> Security Class Initialized
DEBUG - 2021-06-28 02:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:10:54 --> Input Class Initialized
INFO - 2021-06-28 02:10:54 --> Language Class Initialized
INFO - 2021-06-28 02:10:54 --> Language Class Initialized
INFO - 2021-06-28 02:10:54 --> Config Class Initialized
INFO - 2021-06-28 02:10:54 --> Loader Class Initialized
INFO - 2021-06-28 02:10:54 --> Helper loaded: url_helper
INFO - 2021-06-28 02:10:54 --> Helper loaded: file_helper
INFO - 2021-06-28 02:10:54 --> Helper loaded: form_helper
INFO - 2021-06-28 02:10:54 --> Helper loaded: my_helper
INFO - 2021-06-28 02:10:54 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:10:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:10:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:10:54 --> Controller Class Initialized
DEBUG - 2021-06-28 02:10:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-28 02:10:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 02:10:55 --> Final output sent to browser
DEBUG - 2021-06-28 02:10:55 --> Total execution time: 0.7073
INFO - 2021-06-28 02:10:57 --> Config Class Initialized
INFO - 2021-06-28 02:10:57 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:10:57 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:10:57 --> Utf8 Class Initialized
INFO - 2021-06-28 02:10:57 --> URI Class Initialized
INFO - 2021-06-28 02:10:57 --> Router Class Initialized
INFO - 2021-06-28 02:10:57 --> Output Class Initialized
INFO - 2021-06-28 02:10:57 --> Security Class Initialized
DEBUG - 2021-06-28 02:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:10:57 --> Input Class Initialized
INFO - 2021-06-28 02:10:57 --> Language Class Initialized
INFO - 2021-06-28 02:10:57 --> Language Class Initialized
INFO - 2021-06-28 02:10:57 --> Config Class Initialized
INFO - 2021-06-28 02:10:57 --> Loader Class Initialized
INFO - 2021-06-28 02:10:57 --> Helper loaded: url_helper
INFO - 2021-06-28 02:10:57 --> Helper loaded: file_helper
INFO - 2021-06-28 02:10:57 --> Helper loaded: form_helper
INFO - 2021-06-28 02:10:57 --> Helper loaded: my_helper
INFO - 2021-06-28 02:10:57 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:10:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:10:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:10:57 --> Controller Class Initialized
INFO - 2021-06-28 02:10:57 --> Helper loaded: cookie_helper
INFO - 2021-06-28 02:10:57 --> Config Class Initialized
INFO - 2021-06-28 02:10:57 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:10:57 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:10:57 --> Utf8 Class Initialized
INFO - 2021-06-28 02:10:57 --> URI Class Initialized
INFO - 2021-06-28 02:10:57 --> Router Class Initialized
INFO - 2021-06-28 02:10:57 --> Output Class Initialized
INFO - 2021-06-28 02:10:57 --> Security Class Initialized
DEBUG - 2021-06-28 02:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:10:57 --> Input Class Initialized
INFO - 2021-06-28 02:10:57 --> Language Class Initialized
INFO - 2021-06-28 02:10:57 --> Language Class Initialized
INFO - 2021-06-28 02:10:57 --> Config Class Initialized
INFO - 2021-06-28 02:10:57 --> Loader Class Initialized
INFO - 2021-06-28 02:10:57 --> Helper loaded: url_helper
INFO - 2021-06-28 02:10:57 --> Helper loaded: file_helper
INFO - 2021-06-28 02:10:57 --> Helper loaded: form_helper
INFO - 2021-06-28 02:10:57 --> Helper loaded: my_helper
INFO - 2021-06-28 02:10:57 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:10:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:10:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:10:57 --> Controller Class Initialized
DEBUG - 2021-06-28 02:10:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-28 02:10:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 02:10:57 --> Final output sent to browser
DEBUG - 2021-06-28 02:10:57 --> Total execution time: 0.0399
INFO - 2021-06-28 02:11:01 --> Config Class Initialized
INFO - 2021-06-28 02:11:01 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:11:01 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:11:01 --> Utf8 Class Initialized
INFO - 2021-06-28 02:11:01 --> URI Class Initialized
INFO - 2021-06-28 02:11:01 --> Router Class Initialized
INFO - 2021-06-28 02:11:01 --> Output Class Initialized
INFO - 2021-06-28 02:11:01 --> Security Class Initialized
DEBUG - 2021-06-28 02:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:11:01 --> Input Class Initialized
INFO - 2021-06-28 02:11:01 --> Language Class Initialized
INFO - 2021-06-28 02:11:01 --> Language Class Initialized
INFO - 2021-06-28 02:11:01 --> Config Class Initialized
INFO - 2021-06-28 02:11:01 --> Loader Class Initialized
INFO - 2021-06-28 02:11:01 --> Helper loaded: url_helper
INFO - 2021-06-28 02:11:01 --> Helper loaded: file_helper
INFO - 2021-06-28 02:11:01 --> Helper loaded: form_helper
INFO - 2021-06-28 02:11:01 --> Helper loaded: my_helper
INFO - 2021-06-28 02:11:01 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:11:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:11:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:11:01 --> Controller Class Initialized
INFO - 2021-06-28 02:11:01 --> Helper loaded: cookie_helper
INFO - 2021-06-28 02:11:01 --> Final output sent to browser
DEBUG - 2021-06-28 02:11:01 --> Total execution time: 0.0396
INFO - 2021-06-28 02:11:02 --> Config Class Initialized
INFO - 2021-06-28 02:11:02 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:11:02 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:11:02 --> Utf8 Class Initialized
INFO - 2021-06-28 02:11:02 --> URI Class Initialized
INFO - 2021-06-28 02:11:02 --> Router Class Initialized
INFO - 2021-06-28 02:11:02 --> Output Class Initialized
INFO - 2021-06-28 02:11:02 --> Security Class Initialized
DEBUG - 2021-06-28 02:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:11:02 --> Input Class Initialized
INFO - 2021-06-28 02:11:02 --> Language Class Initialized
INFO - 2021-06-28 02:11:02 --> Language Class Initialized
INFO - 2021-06-28 02:11:02 --> Config Class Initialized
INFO - 2021-06-28 02:11:02 --> Loader Class Initialized
INFO - 2021-06-28 02:11:02 --> Helper loaded: url_helper
INFO - 2021-06-28 02:11:02 --> Helper loaded: file_helper
INFO - 2021-06-28 02:11:02 --> Helper loaded: form_helper
INFO - 2021-06-28 02:11:02 --> Helper loaded: my_helper
INFO - 2021-06-28 02:11:02 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:11:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:11:02 --> Controller Class Initialized
DEBUG - 2021-06-28 02:11:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-28 02:11:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 02:11:02 --> Final output sent to browser
DEBUG - 2021-06-28 02:11:02 --> Total execution time: 0.6046
INFO - 2021-06-28 02:11:03 --> Config Class Initialized
INFO - 2021-06-28 02:11:03 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:11:03 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:11:03 --> Utf8 Class Initialized
INFO - 2021-06-28 02:11:03 --> URI Class Initialized
INFO - 2021-06-28 02:11:03 --> Router Class Initialized
INFO - 2021-06-28 02:11:03 --> Output Class Initialized
INFO - 2021-06-28 02:11:03 --> Security Class Initialized
DEBUG - 2021-06-28 02:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:11:03 --> Input Class Initialized
INFO - 2021-06-28 02:11:03 --> Language Class Initialized
INFO - 2021-06-28 02:11:03 --> Language Class Initialized
INFO - 2021-06-28 02:11:03 --> Config Class Initialized
INFO - 2021-06-28 02:11:03 --> Loader Class Initialized
INFO - 2021-06-28 02:11:03 --> Helper loaded: url_helper
INFO - 2021-06-28 02:11:03 --> Helper loaded: file_helper
INFO - 2021-06-28 02:11:03 --> Helper loaded: form_helper
INFO - 2021-06-28 02:11:03 --> Helper loaded: my_helper
INFO - 2021-06-28 02:11:03 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:11:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:11:03 --> Controller Class Initialized
DEBUG - 2021-06-28 02:11:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-28 02:11:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 02:11:04 --> Final output sent to browser
DEBUG - 2021-06-28 02:11:04 --> Total execution time: 0.0881
INFO - 2021-06-28 02:11:07 --> Config Class Initialized
INFO - 2021-06-28 02:11:07 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:11:07 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:11:07 --> Utf8 Class Initialized
INFO - 2021-06-28 02:11:07 --> URI Class Initialized
INFO - 2021-06-28 02:11:07 --> Router Class Initialized
INFO - 2021-06-28 02:11:07 --> Output Class Initialized
INFO - 2021-06-28 02:11:07 --> Security Class Initialized
DEBUG - 2021-06-28 02:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:11:07 --> Input Class Initialized
INFO - 2021-06-28 02:11:07 --> Language Class Initialized
INFO - 2021-06-28 02:11:07 --> Language Class Initialized
INFO - 2021-06-28 02:11:07 --> Config Class Initialized
INFO - 2021-06-28 02:11:07 --> Loader Class Initialized
INFO - 2021-06-28 02:11:07 --> Helper loaded: url_helper
INFO - 2021-06-28 02:11:07 --> Helper loaded: file_helper
INFO - 2021-06-28 02:11:07 --> Helper loaded: form_helper
INFO - 2021-06-28 02:11:07 --> Helper loaded: my_helper
INFO - 2021-06-28 02:11:07 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:11:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:11:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:11:07 --> Controller Class Initialized
DEBUG - 2021-06-28 02:11:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-28 02:11:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 02:11:07 --> Final output sent to browser
DEBUG - 2021-06-28 02:11:07 --> Total execution time: 0.1447
INFO - 2021-06-28 02:11:08 --> Config Class Initialized
INFO - 2021-06-28 02:11:08 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:11:08 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:11:08 --> Utf8 Class Initialized
INFO - 2021-06-28 02:11:08 --> URI Class Initialized
INFO - 2021-06-28 02:11:08 --> Router Class Initialized
INFO - 2021-06-28 02:11:08 --> Output Class Initialized
INFO - 2021-06-28 02:11:08 --> Security Class Initialized
DEBUG - 2021-06-28 02:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:11:08 --> Input Class Initialized
INFO - 2021-06-28 02:11:08 --> Language Class Initialized
INFO - 2021-06-28 02:11:08 --> Language Class Initialized
INFO - 2021-06-28 02:11:08 --> Config Class Initialized
INFO - 2021-06-28 02:11:08 --> Loader Class Initialized
INFO - 2021-06-28 02:11:08 --> Helper loaded: url_helper
INFO - 2021-06-28 02:11:08 --> Helper loaded: file_helper
INFO - 2021-06-28 02:11:08 --> Helper loaded: form_helper
INFO - 2021-06-28 02:11:08 --> Helper loaded: my_helper
INFO - 2021-06-28 02:11:08 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:11:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:11:08 --> Controller Class Initialized
INFO - 2021-06-28 02:11:10 --> Config Class Initialized
INFO - 2021-06-28 02:11:10 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:11:10 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:11:10 --> Utf8 Class Initialized
INFO - 2021-06-28 02:11:10 --> URI Class Initialized
INFO - 2021-06-28 02:11:10 --> Router Class Initialized
INFO - 2021-06-28 02:11:10 --> Output Class Initialized
INFO - 2021-06-28 02:11:10 --> Security Class Initialized
DEBUG - 2021-06-28 02:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:11:10 --> Input Class Initialized
INFO - 2021-06-28 02:11:10 --> Language Class Initialized
INFO - 2021-06-28 02:11:10 --> Language Class Initialized
INFO - 2021-06-28 02:11:10 --> Config Class Initialized
INFO - 2021-06-28 02:11:10 --> Loader Class Initialized
INFO - 2021-06-28 02:11:10 --> Helper loaded: url_helper
INFO - 2021-06-28 02:11:10 --> Helper loaded: file_helper
INFO - 2021-06-28 02:11:10 --> Helper loaded: form_helper
INFO - 2021-06-28 02:11:10 --> Helper loaded: my_helper
INFO - 2021-06-28 02:11:10 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:11:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:11:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:11:10 --> Controller Class Initialized
INFO - 2021-06-28 02:11:10 --> Final output sent to browser
DEBUG - 2021-06-28 02:11:10 --> Total execution time: 0.1088
INFO - 2021-06-28 02:11:16 --> Config Class Initialized
INFO - 2021-06-28 02:11:16 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:11:17 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:11:17 --> Utf8 Class Initialized
INFO - 2021-06-28 02:11:17 --> URI Class Initialized
INFO - 2021-06-28 02:11:17 --> Router Class Initialized
INFO - 2021-06-28 02:11:17 --> Output Class Initialized
INFO - 2021-06-28 02:11:17 --> Security Class Initialized
DEBUG - 2021-06-28 02:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:11:17 --> Input Class Initialized
INFO - 2021-06-28 02:11:17 --> Language Class Initialized
INFO - 2021-06-28 02:11:17 --> Language Class Initialized
INFO - 2021-06-28 02:11:17 --> Config Class Initialized
INFO - 2021-06-28 02:11:17 --> Loader Class Initialized
INFO - 2021-06-28 02:11:17 --> Helper loaded: url_helper
INFO - 2021-06-28 02:11:17 --> Helper loaded: file_helper
INFO - 2021-06-28 02:11:17 --> Helper loaded: form_helper
INFO - 2021-06-28 02:11:17 --> Helper loaded: my_helper
INFO - 2021-06-28 02:11:17 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:11:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:11:17 --> Controller Class Initialized
INFO - 2021-06-28 02:11:21 --> Config Class Initialized
INFO - 2021-06-28 02:11:21 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:11:21 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:11:21 --> Utf8 Class Initialized
INFO - 2021-06-28 02:11:21 --> URI Class Initialized
INFO - 2021-06-28 02:11:21 --> Router Class Initialized
INFO - 2021-06-28 02:11:21 --> Output Class Initialized
INFO - 2021-06-28 02:11:21 --> Security Class Initialized
DEBUG - 2021-06-28 02:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:11:21 --> Input Class Initialized
INFO - 2021-06-28 02:11:21 --> Language Class Initialized
INFO - 2021-06-28 02:11:21 --> Language Class Initialized
INFO - 2021-06-28 02:11:21 --> Config Class Initialized
INFO - 2021-06-28 02:11:21 --> Loader Class Initialized
INFO - 2021-06-28 02:11:21 --> Helper loaded: url_helper
INFO - 2021-06-28 02:11:21 --> Helper loaded: file_helper
INFO - 2021-06-28 02:11:21 --> Helper loaded: form_helper
INFO - 2021-06-28 02:11:21 --> Helper loaded: my_helper
INFO - 2021-06-28 02:11:21 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:11:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:11:21 --> Controller Class Initialized
DEBUG - 2021-06-28 02:11:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-28 02:11:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 02:11:21 --> Final output sent to browser
DEBUG - 2021-06-28 02:11:21 --> Total execution time: 0.1864
INFO - 2021-06-28 02:11:23 --> Config Class Initialized
INFO - 2021-06-28 02:11:23 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:11:23 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:11:23 --> Utf8 Class Initialized
INFO - 2021-06-28 02:11:23 --> URI Class Initialized
INFO - 2021-06-28 02:11:23 --> Router Class Initialized
INFO - 2021-06-28 02:11:23 --> Output Class Initialized
INFO - 2021-06-28 02:11:23 --> Security Class Initialized
DEBUG - 2021-06-28 02:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:11:24 --> Input Class Initialized
INFO - 2021-06-28 02:11:24 --> Language Class Initialized
INFO - 2021-06-28 02:11:24 --> Language Class Initialized
INFO - 2021-06-28 02:11:24 --> Config Class Initialized
INFO - 2021-06-28 02:11:24 --> Loader Class Initialized
INFO - 2021-06-28 02:11:24 --> Helper loaded: url_helper
INFO - 2021-06-28 02:11:24 --> Helper loaded: file_helper
INFO - 2021-06-28 02:11:24 --> Helper loaded: form_helper
INFO - 2021-06-28 02:11:24 --> Helper loaded: my_helper
INFO - 2021-06-28 02:11:24 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:11:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:11:24 --> Controller Class Initialized
INFO - 2021-06-28 02:12:38 --> Config Class Initialized
INFO - 2021-06-28 02:12:38 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:12:38 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:12:38 --> Utf8 Class Initialized
INFO - 2021-06-28 02:12:38 --> URI Class Initialized
INFO - 2021-06-28 02:12:38 --> Router Class Initialized
INFO - 2021-06-28 02:12:38 --> Output Class Initialized
INFO - 2021-06-28 02:12:38 --> Security Class Initialized
DEBUG - 2021-06-28 02:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:12:38 --> Input Class Initialized
INFO - 2021-06-28 02:12:38 --> Language Class Initialized
INFO - 2021-06-28 02:12:38 --> Language Class Initialized
INFO - 2021-06-28 02:12:38 --> Config Class Initialized
INFO - 2021-06-28 02:12:38 --> Loader Class Initialized
INFO - 2021-06-28 02:12:38 --> Helper loaded: url_helper
INFO - 2021-06-28 02:12:38 --> Helper loaded: file_helper
INFO - 2021-06-28 02:12:38 --> Helper loaded: form_helper
INFO - 2021-06-28 02:12:38 --> Helper loaded: my_helper
INFO - 2021-06-28 02:12:38 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:12:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:12:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:12:38 --> Controller Class Initialized
DEBUG - 2021-06-28 02:12:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2021-06-28 02:12:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 02:12:38 --> Final output sent to browser
DEBUG - 2021-06-28 02:12:38 --> Total execution time: 0.0576
INFO - 2021-06-28 02:12:43 --> Config Class Initialized
INFO - 2021-06-28 02:12:43 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:12:43 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:12:43 --> Utf8 Class Initialized
INFO - 2021-06-28 02:12:43 --> URI Class Initialized
INFO - 2021-06-28 02:12:43 --> Router Class Initialized
INFO - 2021-06-28 02:12:43 --> Output Class Initialized
INFO - 2021-06-28 02:12:43 --> Security Class Initialized
DEBUG - 2021-06-28 02:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:12:43 --> Input Class Initialized
INFO - 2021-06-28 02:12:43 --> Language Class Initialized
INFO - 2021-06-28 02:12:43 --> Language Class Initialized
INFO - 2021-06-28 02:12:43 --> Config Class Initialized
INFO - 2021-06-28 02:12:43 --> Loader Class Initialized
INFO - 2021-06-28 02:12:43 --> Helper loaded: url_helper
INFO - 2021-06-28 02:12:43 --> Helper loaded: file_helper
INFO - 2021-06-28 02:12:43 --> Helper loaded: form_helper
INFO - 2021-06-28 02:12:43 --> Helper loaded: my_helper
INFO - 2021-06-28 02:12:43 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:12:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:12:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:12:43 --> Controller Class Initialized
INFO - 2021-06-28 02:12:44 --> Config Class Initialized
INFO - 2021-06-28 02:12:44 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:12:44 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:12:44 --> Utf8 Class Initialized
INFO - 2021-06-28 02:12:44 --> URI Class Initialized
INFO - 2021-06-28 02:12:44 --> Router Class Initialized
INFO - 2021-06-28 02:12:44 --> Output Class Initialized
INFO - 2021-06-28 02:12:44 --> Security Class Initialized
DEBUG - 2021-06-28 02:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:12:44 --> Input Class Initialized
INFO - 2021-06-28 02:12:44 --> Language Class Initialized
INFO - 2021-06-28 02:12:44 --> Language Class Initialized
INFO - 2021-06-28 02:12:44 --> Config Class Initialized
INFO - 2021-06-28 02:12:44 --> Loader Class Initialized
INFO - 2021-06-28 02:12:44 --> Helper loaded: url_helper
INFO - 2021-06-28 02:12:44 --> Helper loaded: file_helper
INFO - 2021-06-28 02:12:44 --> Helper loaded: form_helper
INFO - 2021-06-28 02:12:44 --> Helper loaded: my_helper
INFO - 2021-06-28 02:12:44 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:12:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:12:44 --> Controller Class Initialized
DEBUG - 2021-06-28 02:12:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-28 02:12:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 02:12:44 --> Final output sent to browser
DEBUG - 2021-06-28 02:12:44 --> Total execution time: 0.0858
INFO - 2021-06-28 02:12:44 --> Config Class Initialized
INFO - 2021-06-28 02:12:44 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:12:44 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:12:44 --> Utf8 Class Initialized
INFO - 2021-06-28 02:12:44 --> URI Class Initialized
INFO - 2021-06-28 02:12:44 --> Router Class Initialized
INFO - 2021-06-28 02:12:44 --> Output Class Initialized
INFO - 2021-06-28 02:12:44 --> Security Class Initialized
DEBUG - 2021-06-28 02:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:12:44 --> Input Class Initialized
INFO - 2021-06-28 02:12:44 --> Language Class Initialized
INFO - 2021-06-28 02:12:44 --> Language Class Initialized
INFO - 2021-06-28 02:12:44 --> Config Class Initialized
INFO - 2021-06-28 02:12:44 --> Loader Class Initialized
INFO - 2021-06-28 02:12:44 --> Helper loaded: url_helper
INFO - 2021-06-28 02:12:44 --> Helper loaded: file_helper
INFO - 2021-06-28 02:12:44 --> Helper loaded: form_helper
INFO - 2021-06-28 02:12:44 --> Helper loaded: my_helper
INFO - 2021-06-28 02:12:44 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:12:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:12:44 --> Controller Class Initialized
INFO - 2021-06-28 02:12:46 --> Config Class Initialized
INFO - 2021-06-28 02:12:46 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:12:46 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:12:46 --> Utf8 Class Initialized
INFO - 2021-06-28 02:12:46 --> URI Class Initialized
INFO - 2021-06-28 02:12:46 --> Router Class Initialized
INFO - 2021-06-28 02:12:46 --> Output Class Initialized
INFO - 2021-06-28 02:12:46 --> Security Class Initialized
DEBUG - 2021-06-28 02:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:12:46 --> Input Class Initialized
INFO - 2021-06-28 02:12:46 --> Language Class Initialized
INFO - 2021-06-28 02:12:46 --> Language Class Initialized
INFO - 2021-06-28 02:12:46 --> Config Class Initialized
INFO - 2021-06-28 02:12:46 --> Loader Class Initialized
INFO - 2021-06-28 02:12:46 --> Helper loaded: url_helper
INFO - 2021-06-28 02:12:46 --> Helper loaded: file_helper
INFO - 2021-06-28 02:12:46 --> Helper loaded: form_helper
INFO - 2021-06-28 02:12:46 --> Helper loaded: my_helper
INFO - 2021-06-28 02:12:46 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:12:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:12:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:12:46 --> Controller Class Initialized
DEBUG - 2021-06-28 02:12:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2021-06-28 02:12:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 02:12:46 --> Final output sent to browser
DEBUG - 2021-06-28 02:12:46 --> Total execution time: 0.0670
INFO - 2021-06-28 02:12:49 --> Config Class Initialized
INFO - 2021-06-28 02:12:49 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:12:49 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:12:49 --> Utf8 Class Initialized
INFO - 2021-06-28 02:12:49 --> URI Class Initialized
INFO - 2021-06-28 02:12:49 --> Router Class Initialized
INFO - 2021-06-28 02:12:49 --> Output Class Initialized
INFO - 2021-06-28 02:12:49 --> Security Class Initialized
DEBUG - 2021-06-28 02:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:12:49 --> Input Class Initialized
INFO - 2021-06-28 02:12:49 --> Language Class Initialized
INFO - 2021-06-28 02:12:49 --> Language Class Initialized
INFO - 2021-06-28 02:12:49 --> Config Class Initialized
INFO - 2021-06-28 02:12:49 --> Loader Class Initialized
INFO - 2021-06-28 02:12:49 --> Helper loaded: url_helper
INFO - 2021-06-28 02:12:49 --> Helper loaded: file_helper
INFO - 2021-06-28 02:12:49 --> Helper loaded: form_helper
INFO - 2021-06-28 02:12:49 --> Helper loaded: my_helper
INFO - 2021-06-28 02:12:49 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:12:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:12:49 --> Controller Class Initialized
INFO - 2021-06-28 02:12:49 --> Config Class Initialized
INFO - 2021-06-28 02:12:49 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:12:49 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:12:49 --> Utf8 Class Initialized
INFO - 2021-06-28 02:12:49 --> URI Class Initialized
INFO - 2021-06-28 02:12:49 --> Router Class Initialized
INFO - 2021-06-28 02:12:49 --> Output Class Initialized
INFO - 2021-06-28 02:12:49 --> Security Class Initialized
DEBUG - 2021-06-28 02:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:12:49 --> Input Class Initialized
INFO - 2021-06-28 02:12:49 --> Language Class Initialized
INFO - 2021-06-28 02:12:49 --> Language Class Initialized
INFO - 2021-06-28 02:12:49 --> Config Class Initialized
INFO - 2021-06-28 02:12:49 --> Loader Class Initialized
INFO - 2021-06-28 02:12:49 --> Helper loaded: url_helper
INFO - 2021-06-28 02:12:50 --> Helper loaded: file_helper
INFO - 2021-06-28 02:12:50 --> Helper loaded: form_helper
INFO - 2021-06-28 02:12:50 --> Helper loaded: my_helper
INFO - 2021-06-28 02:12:50 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:12:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:12:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:12:50 --> Controller Class Initialized
DEBUG - 2021-06-28 02:12:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-28 02:12:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 02:12:50 --> Final output sent to browser
DEBUG - 2021-06-28 02:12:50 --> Total execution time: 0.0438
INFO - 2021-06-28 02:12:53 --> Config Class Initialized
INFO - 2021-06-28 02:12:53 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:12:53 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:12:53 --> Utf8 Class Initialized
INFO - 2021-06-28 02:12:53 --> URI Class Initialized
INFO - 2021-06-28 02:12:53 --> Router Class Initialized
INFO - 2021-06-28 02:12:53 --> Output Class Initialized
INFO - 2021-06-28 02:12:53 --> Security Class Initialized
DEBUG - 2021-06-28 02:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:12:53 --> Input Class Initialized
INFO - 2021-06-28 02:12:53 --> Language Class Initialized
INFO - 2021-06-28 02:12:53 --> Language Class Initialized
INFO - 2021-06-28 02:12:53 --> Config Class Initialized
INFO - 2021-06-28 02:12:53 --> Loader Class Initialized
INFO - 2021-06-28 02:12:53 --> Helper loaded: url_helper
INFO - 2021-06-28 02:12:53 --> Helper loaded: file_helper
INFO - 2021-06-28 02:12:53 --> Helper loaded: form_helper
INFO - 2021-06-28 02:12:53 --> Helper loaded: my_helper
INFO - 2021-06-28 02:12:53 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:12:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:12:53 --> Controller Class Initialized
INFO - 2021-06-28 02:12:53 --> Helper loaded: cookie_helper
INFO - 2021-06-28 02:12:53 --> Config Class Initialized
INFO - 2021-06-28 02:12:53 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:12:53 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:12:53 --> Utf8 Class Initialized
INFO - 2021-06-28 02:12:53 --> URI Class Initialized
INFO - 2021-06-28 02:12:53 --> Router Class Initialized
INFO - 2021-06-28 02:12:53 --> Output Class Initialized
INFO - 2021-06-28 02:12:53 --> Security Class Initialized
DEBUG - 2021-06-28 02:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:12:53 --> Input Class Initialized
INFO - 2021-06-28 02:12:53 --> Language Class Initialized
INFO - 2021-06-28 02:12:53 --> Language Class Initialized
INFO - 2021-06-28 02:12:53 --> Config Class Initialized
INFO - 2021-06-28 02:12:53 --> Loader Class Initialized
INFO - 2021-06-28 02:12:53 --> Helper loaded: url_helper
INFO - 2021-06-28 02:12:53 --> Helper loaded: file_helper
INFO - 2021-06-28 02:12:53 --> Helper loaded: form_helper
INFO - 2021-06-28 02:12:53 --> Helper loaded: my_helper
INFO - 2021-06-28 02:12:53 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:12:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:12:53 --> Controller Class Initialized
DEBUG - 2021-06-28 02:12:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-28 02:12:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 02:12:53 --> Final output sent to browser
DEBUG - 2021-06-28 02:12:53 --> Total execution time: 0.0657
INFO - 2021-06-28 02:12:57 --> Config Class Initialized
INFO - 2021-06-28 02:12:57 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:12:57 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:12:57 --> Utf8 Class Initialized
INFO - 2021-06-28 02:12:57 --> URI Class Initialized
INFO - 2021-06-28 02:12:57 --> Router Class Initialized
INFO - 2021-06-28 02:12:58 --> Output Class Initialized
INFO - 2021-06-28 02:12:58 --> Security Class Initialized
DEBUG - 2021-06-28 02:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:12:58 --> Input Class Initialized
INFO - 2021-06-28 02:12:58 --> Language Class Initialized
INFO - 2021-06-28 02:12:58 --> Language Class Initialized
INFO - 2021-06-28 02:12:58 --> Config Class Initialized
INFO - 2021-06-28 02:12:58 --> Loader Class Initialized
INFO - 2021-06-28 02:12:58 --> Helper loaded: url_helper
INFO - 2021-06-28 02:12:58 --> Helper loaded: file_helper
INFO - 2021-06-28 02:12:58 --> Helper loaded: form_helper
INFO - 2021-06-28 02:12:58 --> Helper loaded: my_helper
INFO - 2021-06-28 02:12:58 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:12:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:12:58 --> Controller Class Initialized
INFO - 2021-06-28 02:12:58 --> Helper loaded: cookie_helper
INFO - 2021-06-28 02:12:58 --> Final output sent to browser
DEBUG - 2021-06-28 02:12:58 --> Total execution time: 0.0426
INFO - 2021-06-28 02:12:58 --> Config Class Initialized
INFO - 2021-06-28 02:12:58 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:12:58 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:12:58 --> Utf8 Class Initialized
INFO - 2021-06-28 02:12:58 --> URI Class Initialized
INFO - 2021-06-28 02:12:58 --> Router Class Initialized
INFO - 2021-06-28 02:12:58 --> Output Class Initialized
INFO - 2021-06-28 02:12:58 --> Security Class Initialized
DEBUG - 2021-06-28 02:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:12:58 --> Input Class Initialized
INFO - 2021-06-28 02:12:58 --> Language Class Initialized
INFO - 2021-06-28 02:12:58 --> Language Class Initialized
INFO - 2021-06-28 02:12:58 --> Config Class Initialized
INFO - 2021-06-28 02:12:58 --> Loader Class Initialized
INFO - 2021-06-28 02:12:58 --> Helper loaded: url_helper
INFO - 2021-06-28 02:12:58 --> Helper loaded: file_helper
INFO - 2021-06-28 02:12:58 --> Helper loaded: form_helper
INFO - 2021-06-28 02:12:58 --> Helper loaded: my_helper
INFO - 2021-06-28 02:12:58 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:12:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:12:58 --> Controller Class Initialized
DEBUG - 2021-06-28 02:12:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-28 02:12:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 02:12:58 --> Final output sent to browser
DEBUG - 2021-06-28 02:12:58 --> Total execution time: 0.7046
INFO - 2021-06-28 02:13:00 --> Config Class Initialized
INFO - 2021-06-28 02:13:00 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:13:00 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:13:00 --> Utf8 Class Initialized
INFO - 2021-06-28 02:13:00 --> URI Class Initialized
INFO - 2021-06-28 02:13:00 --> Router Class Initialized
INFO - 2021-06-28 02:13:00 --> Output Class Initialized
INFO - 2021-06-28 02:13:00 --> Security Class Initialized
DEBUG - 2021-06-28 02:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:13:00 --> Input Class Initialized
INFO - 2021-06-28 02:13:00 --> Language Class Initialized
INFO - 2021-06-28 02:13:00 --> Language Class Initialized
INFO - 2021-06-28 02:13:00 --> Config Class Initialized
INFO - 2021-06-28 02:13:00 --> Loader Class Initialized
INFO - 2021-06-28 02:13:00 --> Helper loaded: url_helper
INFO - 2021-06-28 02:13:00 --> Helper loaded: file_helper
INFO - 2021-06-28 02:13:00 --> Helper loaded: form_helper
INFO - 2021-06-28 02:13:00 --> Helper loaded: my_helper
INFO - 2021-06-28 02:13:00 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:13:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:13:00 --> Controller Class Initialized
DEBUG - 2021-06-28 02:13:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-28 02:13:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 02:13:00 --> Final output sent to browser
DEBUG - 2021-06-28 02:13:00 --> Total execution time: 0.0930
INFO - 2021-06-28 02:13:02 --> Config Class Initialized
INFO - 2021-06-28 02:13:02 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:13:02 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:13:02 --> Utf8 Class Initialized
INFO - 2021-06-28 02:13:02 --> URI Class Initialized
INFO - 2021-06-28 02:13:02 --> Router Class Initialized
INFO - 2021-06-28 02:13:02 --> Output Class Initialized
INFO - 2021-06-28 02:13:02 --> Security Class Initialized
DEBUG - 2021-06-28 02:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:13:02 --> Input Class Initialized
INFO - 2021-06-28 02:13:02 --> Language Class Initialized
INFO - 2021-06-28 02:13:02 --> Language Class Initialized
INFO - 2021-06-28 02:13:02 --> Config Class Initialized
INFO - 2021-06-28 02:13:02 --> Loader Class Initialized
INFO - 2021-06-28 02:13:02 --> Helper loaded: url_helper
INFO - 2021-06-28 02:13:02 --> Helper loaded: file_helper
INFO - 2021-06-28 02:13:02 --> Helper loaded: form_helper
INFO - 2021-06-28 02:13:02 --> Helper loaded: my_helper
INFO - 2021-06-28 02:13:02 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:13:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:13:02 --> Controller Class Initialized
DEBUG - 2021-06-28 02:13:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-28 02:13:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 02:13:02 --> Final output sent to browser
DEBUG - 2021-06-28 02:13:02 --> Total execution time: 0.0448
INFO - 2021-06-28 02:13:02 --> Config Class Initialized
INFO - 2021-06-28 02:13:02 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:13:02 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:13:02 --> Utf8 Class Initialized
INFO - 2021-06-28 02:13:02 --> URI Class Initialized
INFO - 2021-06-28 02:13:02 --> Router Class Initialized
INFO - 2021-06-28 02:13:02 --> Output Class Initialized
INFO - 2021-06-28 02:13:02 --> Security Class Initialized
DEBUG - 2021-06-28 02:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:13:02 --> Input Class Initialized
INFO - 2021-06-28 02:13:02 --> Language Class Initialized
INFO - 2021-06-28 02:13:02 --> Language Class Initialized
INFO - 2021-06-28 02:13:02 --> Config Class Initialized
INFO - 2021-06-28 02:13:02 --> Loader Class Initialized
INFO - 2021-06-28 02:13:02 --> Helper loaded: url_helper
INFO - 2021-06-28 02:13:02 --> Helper loaded: file_helper
INFO - 2021-06-28 02:13:02 --> Helper loaded: form_helper
INFO - 2021-06-28 02:13:02 --> Helper loaded: my_helper
INFO - 2021-06-28 02:13:02 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:13:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:13:02 --> Controller Class Initialized
INFO - 2021-06-28 02:13:03 --> Config Class Initialized
INFO - 2021-06-28 02:13:03 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:13:03 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:13:03 --> Utf8 Class Initialized
INFO - 2021-06-28 02:13:03 --> URI Class Initialized
INFO - 2021-06-28 02:13:03 --> Router Class Initialized
INFO - 2021-06-28 02:13:03 --> Output Class Initialized
INFO - 2021-06-28 02:13:03 --> Security Class Initialized
DEBUG - 2021-06-28 02:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:13:03 --> Input Class Initialized
INFO - 2021-06-28 02:13:03 --> Language Class Initialized
INFO - 2021-06-28 02:13:03 --> Language Class Initialized
INFO - 2021-06-28 02:13:03 --> Config Class Initialized
INFO - 2021-06-28 02:13:03 --> Loader Class Initialized
INFO - 2021-06-28 02:13:03 --> Helper loaded: url_helper
INFO - 2021-06-28 02:13:03 --> Helper loaded: file_helper
INFO - 2021-06-28 02:13:03 --> Helper loaded: form_helper
INFO - 2021-06-28 02:13:03 --> Helper loaded: my_helper
INFO - 2021-06-28 02:13:03 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:13:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:13:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:13:03 --> Controller Class Initialized
DEBUG - 2021-06-28 02:13:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-28 02:13:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 02:13:03 --> Final output sent to browser
DEBUG - 2021-06-28 02:13:03 --> Total execution time: 0.0452
INFO - 2021-06-28 02:13:04 --> Config Class Initialized
INFO - 2021-06-28 02:13:04 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:13:04 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:13:04 --> Utf8 Class Initialized
INFO - 2021-06-28 02:13:04 --> URI Class Initialized
INFO - 2021-06-28 02:13:04 --> Router Class Initialized
INFO - 2021-06-28 02:13:04 --> Output Class Initialized
INFO - 2021-06-28 02:13:04 --> Security Class Initialized
DEBUG - 2021-06-28 02:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:13:04 --> Input Class Initialized
INFO - 2021-06-28 02:13:04 --> Language Class Initialized
INFO - 2021-06-28 02:13:04 --> Language Class Initialized
INFO - 2021-06-28 02:13:04 --> Config Class Initialized
INFO - 2021-06-28 02:13:04 --> Loader Class Initialized
INFO - 2021-06-28 02:13:04 --> Helper loaded: url_helper
INFO - 2021-06-28 02:13:04 --> Helper loaded: file_helper
INFO - 2021-06-28 02:13:04 --> Helper loaded: form_helper
INFO - 2021-06-28 02:13:04 --> Helper loaded: my_helper
INFO - 2021-06-28 02:13:04 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:13:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:13:04 --> Controller Class Initialized
INFO - 2021-06-28 02:13:06 --> Config Class Initialized
INFO - 2021-06-28 02:13:06 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:13:06 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:13:06 --> Utf8 Class Initialized
INFO - 2021-06-28 02:13:06 --> URI Class Initialized
INFO - 2021-06-28 02:13:06 --> Router Class Initialized
INFO - 2021-06-28 02:13:06 --> Output Class Initialized
INFO - 2021-06-28 02:13:06 --> Security Class Initialized
DEBUG - 2021-06-28 02:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:13:06 --> Input Class Initialized
INFO - 2021-06-28 02:13:06 --> Language Class Initialized
INFO - 2021-06-28 02:13:06 --> Language Class Initialized
INFO - 2021-06-28 02:13:06 --> Config Class Initialized
INFO - 2021-06-28 02:13:06 --> Loader Class Initialized
INFO - 2021-06-28 02:13:06 --> Helper loaded: url_helper
INFO - 2021-06-28 02:13:06 --> Helper loaded: file_helper
INFO - 2021-06-28 02:13:06 --> Helper loaded: form_helper
INFO - 2021-06-28 02:13:06 --> Helper loaded: my_helper
INFO - 2021-06-28 02:13:06 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:13:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:13:06 --> Controller Class Initialized
INFO - 2021-06-28 02:14:40 --> Config Class Initialized
INFO - 2021-06-28 02:14:40 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:14:40 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:14:40 --> Utf8 Class Initialized
INFO - 2021-06-28 02:14:40 --> URI Class Initialized
INFO - 2021-06-28 02:14:40 --> Router Class Initialized
INFO - 2021-06-28 02:14:40 --> Output Class Initialized
INFO - 2021-06-28 02:14:40 --> Security Class Initialized
DEBUG - 2021-06-28 02:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:14:40 --> Input Class Initialized
INFO - 2021-06-28 02:14:40 --> Language Class Initialized
INFO - 2021-06-28 02:14:40 --> Language Class Initialized
INFO - 2021-06-28 02:14:40 --> Config Class Initialized
INFO - 2021-06-28 02:14:40 --> Loader Class Initialized
INFO - 2021-06-28 02:14:40 --> Helper loaded: url_helper
INFO - 2021-06-28 02:14:40 --> Helper loaded: file_helper
INFO - 2021-06-28 02:14:40 --> Helper loaded: form_helper
INFO - 2021-06-28 02:14:40 --> Helper loaded: my_helper
INFO - 2021-06-28 02:14:40 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:14:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:14:40 --> Controller Class Initialized
DEBUG - 2021-06-28 02:14:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2021-06-28 02:14:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 02:14:40 --> Final output sent to browser
DEBUG - 2021-06-28 02:14:40 --> Total execution time: 0.0440
INFO - 2021-06-28 02:14:43 --> Config Class Initialized
INFO - 2021-06-28 02:14:43 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:14:43 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:14:43 --> Utf8 Class Initialized
INFO - 2021-06-28 02:14:43 --> URI Class Initialized
INFO - 2021-06-28 02:14:43 --> Router Class Initialized
INFO - 2021-06-28 02:14:43 --> Output Class Initialized
INFO - 2021-06-28 02:14:43 --> Security Class Initialized
DEBUG - 2021-06-28 02:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:14:43 --> Input Class Initialized
INFO - 2021-06-28 02:14:43 --> Language Class Initialized
INFO - 2021-06-28 02:14:43 --> Language Class Initialized
INFO - 2021-06-28 02:14:43 --> Config Class Initialized
INFO - 2021-06-28 02:14:43 --> Loader Class Initialized
INFO - 2021-06-28 02:14:43 --> Helper loaded: url_helper
INFO - 2021-06-28 02:14:43 --> Helper loaded: file_helper
INFO - 2021-06-28 02:14:43 --> Helper loaded: form_helper
INFO - 2021-06-28 02:14:43 --> Helper loaded: my_helper
INFO - 2021-06-28 02:14:43 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:14:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:14:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:14:43 --> Controller Class Initialized
INFO - 2021-06-28 02:14:43 --> Config Class Initialized
INFO - 2021-06-28 02:14:43 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:14:43 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:14:43 --> Utf8 Class Initialized
INFO - 2021-06-28 02:14:43 --> URI Class Initialized
INFO - 2021-06-28 02:14:43 --> Router Class Initialized
INFO - 2021-06-28 02:14:43 --> Output Class Initialized
INFO - 2021-06-28 02:14:43 --> Security Class Initialized
DEBUG - 2021-06-28 02:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:14:43 --> Input Class Initialized
INFO - 2021-06-28 02:14:43 --> Language Class Initialized
INFO - 2021-06-28 02:14:43 --> Language Class Initialized
INFO - 2021-06-28 02:14:43 --> Config Class Initialized
INFO - 2021-06-28 02:14:43 --> Loader Class Initialized
INFO - 2021-06-28 02:14:43 --> Helper loaded: url_helper
INFO - 2021-06-28 02:14:43 --> Helper loaded: file_helper
INFO - 2021-06-28 02:14:43 --> Helper loaded: form_helper
INFO - 2021-06-28 02:14:43 --> Helper loaded: my_helper
INFO - 2021-06-28 02:14:43 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:14:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:14:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:14:43 --> Controller Class Initialized
DEBUG - 2021-06-28 02:14:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-28 02:14:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 02:14:43 --> Final output sent to browser
DEBUG - 2021-06-28 02:14:43 --> Total execution time: 0.0545
INFO - 2021-06-28 02:14:43 --> Config Class Initialized
INFO - 2021-06-28 02:14:43 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:14:43 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:14:43 --> Utf8 Class Initialized
INFO - 2021-06-28 02:14:43 --> URI Class Initialized
INFO - 2021-06-28 02:14:43 --> Router Class Initialized
INFO - 2021-06-28 02:14:43 --> Output Class Initialized
INFO - 2021-06-28 02:14:43 --> Security Class Initialized
DEBUG - 2021-06-28 02:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:14:43 --> Input Class Initialized
INFO - 2021-06-28 02:14:43 --> Language Class Initialized
INFO - 2021-06-28 02:14:43 --> Language Class Initialized
INFO - 2021-06-28 02:14:43 --> Config Class Initialized
INFO - 2021-06-28 02:14:43 --> Loader Class Initialized
INFO - 2021-06-28 02:14:43 --> Helper loaded: url_helper
INFO - 2021-06-28 02:14:43 --> Helper loaded: file_helper
INFO - 2021-06-28 02:14:43 --> Helper loaded: form_helper
INFO - 2021-06-28 02:14:43 --> Helper loaded: my_helper
INFO - 2021-06-28 02:14:43 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:14:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:14:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:14:43 --> Controller Class Initialized
INFO - 2021-06-28 02:14:45 --> Config Class Initialized
INFO - 2021-06-28 02:14:45 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:14:45 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:14:45 --> Utf8 Class Initialized
INFO - 2021-06-28 02:14:45 --> URI Class Initialized
INFO - 2021-06-28 02:14:45 --> Router Class Initialized
INFO - 2021-06-28 02:14:45 --> Output Class Initialized
INFO - 2021-06-28 02:14:45 --> Security Class Initialized
DEBUG - 2021-06-28 02:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:14:45 --> Input Class Initialized
INFO - 2021-06-28 02:14:45 --> Language Class Initialized
INFO - 2021-06-28 02:14:46 --> Language Class Initialized
INFO - 2021-06-28 02:14:46 --> Config Class Initialized
INFO - 2021-06-28 02:14:46 --> Loader Class Initialized
INFO - 2021-06-28 02:14:46 --> Helper loaded: url_helper
INFO - 2021-06-28 02:14:46 --> Helper loaded: file_helper
INFO - 2021-06-28 02:14:46 --> Helper loaded: form_helper
INFO - 2021-06-28 02:14:46 --> Helper loaded: my_helper
INFO - 2021-06-28 02:14:46 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:14:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:14:46 --> Controller Class Initialized
DEBUG - 2021-06-28 02:14:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2021-06-28 02:14:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 02:14:46 --> Final output sent to browser
DEBUG - 2021-06-28 02:14:46 --> Total execution time: 0.0421
INFO - 2021-06-28 02:14:49 --> Config Class Initialized
INFO - 2021-06-28 02:14:49 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:14:49 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:14:49 --> Utf8 Class Initialized
INFO - 2021-06-28 02:14:49 --> URI Class Initialized
INFO - 2021-06-28 02:14:49 --> Router Class Initialized
INFO - 2021-06-28 02:14:49 --> Output Class Initialized
INFO - 2021-06-28 02:14:49 --> Security Class Initialized
DEBUG - 2021-06-28 02:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:14:49 --> Input Class Initialized
INFO - 2021-06-28 02:14:49 --> Language Class Initialized
INFO - 2021-06-28 02:14:49 --> Language Class Initialized
INFO - 2021-06-28 02:14:49 --> Config Class Initialized
INFO - 2021-06-28 02:14:49 --> Loader Class Initialized
INFO - 2021-06-28 02:14:49 --> Helper loaded: url_helper
INFO - 2021-06-28 02:14:49 --> Helper loaded: file_helper
INFO - 2021-06-28 02:14:49 --> Helper loaded: form_helper
INFO - 2021-06-28 02:14:49 --> Helper loaded: my_helper
INFO - 2021-06-28 02:14:49 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:14:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:14:49 --> Controller Class Initialized
INFO - 2021-06-28 02:14:49 --> Config Class Initialized
INFO - 2021-06-28 02:14:49 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:14:49 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:14:49 --> Utf8 Class Initialized
INFO - 2021-06-28 02:14:49 --> URI Class Initialized
INFO - 2021-06-28 02:14:49 --> Router Class Initialized
INFO - 2021-06-28 02:14:49 --> Output Class Initialized
INFO - 2021-06-28 02:14:49 --> Security Class Initialized
DEBUG - 2021-06-28 02:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:14:49 --> Input Class Initialized
INFO - 2021-06-28 02:14:49 --> Language Class Initialized
INFO - 2021-06-28 02:14:49 --> Language Class Initialized
INFO - 2021-06-28 02:14:49 --> Config Class Initialized
INFO - 2021-06-28 02:14:49 --> Loader Class Initialized
INFO - 2021-06-28 02:14:49 --> Helper loaded: url_helper
INFO - 2021-06-28 02:14:49 --> Helper loaded: file_helper
INFO - 2021-06-28 02:14:49 --> Helper loaded: form_helper
INFO - 2021-06-28 02:14:49 --> Helper loaded: my_helper
INFO - 2021-06-28 02:14:49 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:14:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:14:49 --> Controller Class Initialized
DEBUG - 2021-06-28 02:14:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-28 02:14:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 02:14:49 --> Final output sent to browser
DEBUG - 2021-06-28 02:14:49 --> Total execution time: 0.0522
INFO - 2021-06-28 02:14:54 --> Config Class Initialized
INFO - 2021-06-28 02:14:54 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:14:54 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:14:54 --> Utf8 Class Initialized
INFO - 2021-06-28 02:14:54 --> URI Class Initialized
INFO - 2021-06-28 02:14:54 --> Router Class Initialized
INFO - 2021-06-28 02:14:54 --> Output Class Initialized
INFO - 2021-06-28 02:14:54 --> Security Class Initialized
DEBUG - 2021-06-28 02:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:14:54 --> Input Class Initialized
INFO - 2021-06-28 02:14:54 --> Language Class Initialized
INFO - 2021-06-28 02:14:54 --> Language Class Initialized
INFO - 2021-06-28 02:14:54 --> Config Class Initialized
INFO - 2021-06-28 02:14:54 --> Loader Class Initialized
INFO - 2021-06-28 02:14:54 --> Helper loaded: url_helper
INFO - 2021-06-28 02:14:54 --> Helper loaded: file_helper
INFO - 2021-06-28 02:14:54 --> Helper loaded: form_helper
INFO - 2021-06-28 02:14:54 --> Helper loaded: my_helper
INFO - 2021-06-28 02:14:54 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:14:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:14:54 --> Controller Class Initialized
INFO - 2021-06-28 02:14:54 --> Helper loaded: cookie_helper
INFO - 2021-06-28 02:14:54 --> Config Class Initialized
INFO - 2021-06-28 02:14:54 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:14:54 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:14:54 --> Utf8 Class Initialized
INFO - 2021-06-28 02:14:54 --> URI Class Initialized
INFO - 2021-06-28 02:14:54 --> Router Class Initialized
INFO - 2021-06-28 02:14:54 --> Output Class Initialized
INFO - 2021-06-28 02:14:54 --> Security Class Initialized
DEBUG - 2021-06-28 02:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:14:54 --> Input Class Initialized
INFO - 2021-06-28 02:14:54 --> Language Class Initialized
INFO - 2021-06-28 02:14:54 --> Language Class Initialized
INFO - 2021-06-28 02:14:54 --> Config Class Initialized
INFO - 2021-06-28 02:14:54 --> Loader Class Initialized
INFO - 2021-06-28 02:14:54 --> Helper loaded: url_helper
INFO - 2021-06-28 02:14:54 --> Helper loaded: file_helper
INFO - 2021-06-28 02:14:54 --> Helper loaded: form_helper
INFO - 2021-06-28 02:14:54 --> Helper loaded: my_helper
INFO - 2021-06-28 02:14:54 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:14:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:14:54 --> Controller Class Initialized
DEBUG - 2021-06-28 02:14:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-28 02:14:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 02:14:54 --> Final output sent to browser
DEBUG - 2021-06-28 02:14:54 --> Total execution time: 0.0487
INFO - 2021-06-28 02:15:02 --> Config Class Initialized
INFO - 2021-06-28 02:15:02 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:15:02 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:15:02 --> Utf8 Class Initialized
INFO - 2021-06-28 02:15:02 --> URI Class Initialized
INFO - 2021-06-28 02:15:02 --> Router Class Initialized
INFO - 2021-06-28 02:15:02 --> Output Class Initialized
INFO - 2021-06-28 02:15:02 --> Security Class Initialized
DEBUG - 2021-06-28 02:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:15:02 --> Input Class Initialized
INFO - 2021-06-28 02:15:02 --> Language Class Initialized
INFO - 2021-06-28 02:15:02 --> Language Class Initialized
INFO - 2021-06-28 02:15:02 --> Config Class Initialized
INFO - 2021-06-28 02:15:02 --> Loader Class Initialized
INFO - 2021-06-28 02:15:02 --> Helper loaded: url_helper
INFO - 2021-06-28 02:15:02 --> Helper loaded: file_helper
INFO - 2021-06-28 02:15:02 --> Helper loaded: form_helper
INFO - 2021-06-28 02:15:02 --> Helper loaded: my_helper
INFO - 2021-06-28 02:15:02 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:15:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:15:02 --> Controller Class Initialized
INFO - 2021-06-28 02:15:02 --> Helper loaded: cookie_helper
INFO - 2021-06-28 02:15:02 --> Final output sent to browser
DEBUG - 2021-06-28 02:15:02 --> Total execution time: 0.0465
INFO - 2021-06-28 02:15:02 --> Config Class Initialized
INFO - 2021-06-28 02:15:02 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:15:02 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:15:02 --> Utf8 Class Initialized
INFO - 2021-06-28 02:15:02 --> URI Class Initialized
INFO - 2021-06-28 02:15:02 --> Router Class Initialized
INFO - 2021-06-28 02:15:02 --> Output Class Initialized
INFO - 2021-06-28 02:15:02 --> Security Class Initialized
DEBUG - 2021-06-28 02:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:15:02 --> Input Class Initialized
INFO - 2021-06-28 02:15:02 --> Language Class Initialized
INFO - 2021-06-28 02:15:02 --> Language Class Initialized
INFO - 2021-06-28 02:15:02 --> Config Class Initialized
INFO - 2021-06-28 02:15:02 --> Loader Class Initialized
INFO - 2021-06-28 02:15:02 --> Helper loaded: url_helper
INFO - 2021-06-28 02:15:02 --> Helper loaded: file_helper
INFO - 2021-06-28 02:15:02 --> Helper loaded: form_helper
INFO - 2021-06-28 02:15:02 --> Helper loaded: my_helper
INFO - 2021-06-28 02:15:02 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:15:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:15:02 --> Controller Class Initialized
DEBUG - 2021-06-28 02:15:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-28 02:15:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 02:15:03 --> Final output sent to browser
DEBUG - 2021-06-28 02:15:03 --> Total execution time: 0.6403
INFO - 2021-06-28 02:15:06 --> Config Class Initialized
INFO - 2021-06-28 02:15:06 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:15:06 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:15:06 --> Utf8 Class Initialized
INFO - 2021-06-28 02:15:06 --> URI Class Initialized
INFO - 2021-06-28 02:15:06 --> Router Class Initialized
INFO - 2021-06-28 02:15:06 --> Output Class Initialized
INFO - 2021-06-28 02:15:06 --> Security Class Initialized
DEBUG - 2021-06-28 02:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:15:06 --> Input Class Initialized
INFO - 2021-06-28 02:15:06 --> Language Class Initialized
INFO - 2021-06-28 02:15:06 --> Language Class Initialized
INFO - 2021-06-28 02:15:06 --> Config Class Initialized
INFO - 2021-06-28 02:15:06 --> Loader Class Initialized
INFO - 2021-06-28 02:15:06 --> Helper loaded: url_helper
INFO - 2021-06-28 02:15:06 --> Helper loaded: file_helper
INFO - 2021-06-28 02:15:06 --> Helper loaded: form_helper
INFO - 2021-06-28 02:15:06 --> Helper loaded: my_helper
INFO - 2021-06-28 02:15:07 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:15:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:15:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:15:07 --> Controller Class Initialized
DEBUG - 2021-06-28 02:15:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-06-28 02:15:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 02:15:07 --> Final output sent to browser
DEBUG - 2021-06-28 02:15:07 --> Total execution time: 0.0775
INFO - 2021-06-28 02:15:09 --> Config Class Initialized
INFO - 2021-06-28 02:15:09 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:15:09 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:15:09 --> Utf8 Class Initialized
INFO - 2021-06-28 02:15:09 --> URI Class Initialized
INFO - 2021-06-28 02:15:09 --> Router Class Initialized
INFO - 2021-06-28 02:15:09 --> Output Class Initialized
INFO - 2021-06-28 02:15:09 --> Security Class Initialized
DEBUG - 2021-06-28 02:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:15:09 --> Input Class Initialized
INFO - 2021-06-28 02:15:09 --> Language Class Initialized
INFO - 2021-06-28 02:15:09 --> Language Class Initialized
INFO - 2021-06-28 02:15:09 --> Config Class Initialized
INFO - 2021-06-28 02:15:09 --> Loader Class Initialized
INFO - 2021-06-28 02:15:09 --> Helper loaded: url_helper
INFO - 2021-06-28 02:15:09 --> Helper loaded: file_helper
INFO - 2021-06-28 02:15:09 --> Helper loaded: form_helper
INFO - 2021-06-28 02:15:09 --> Helper loaded: my_helper
INFO - 2021-06-28 02:15:09 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:15:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:15:09 --> Controller Class Initialized
DEBUG - 2021-06-28 02:15:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_to.php
INFO - 2021-06-28 02:15:09 --> Final output sent to browser
DEBUG - 2021-06-28 02:15:09 --> Total execution time: 0.3623
INFO - 2021-06-28 02:15:49 --> Config Class Initialized
INFO - 2021-06-28 02:15:49 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:15:49 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:15:49 --> Utf8 Class Initialized
INFO - 2021-06-28 02:15:49 --> URI Class Initialized
INFO - 2021-06-28 02:15:49 --> Router Class Initialized
INFO - 2021-06-28 02:15:49 --> Output Class Initialized
INFO - 2021-06-28 02:15:49 --> Security Class Initialized
DEBUG - 2021-06-28 02:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:15:49 --> Input Class Initialized
INFO - 2021-06-28 02:15:49 --> Language Class Initialized
INFO - 2021-06-28 02:15:49 --> Language Class Initialized
INFO - 2021-06-28 02:15:49 --> Config Class Initialized
INFO - 2021-06-28 02:15:49 --> Loader Class Initialized
INFO - 2021-06-28 02:15:49 --> Helper loaded: url_helper
INFO - 2021-06-28 02:15:49 --> Helper loaded: file_helper
INFO - 2021-06-28 02:15:49 --> Helper loaded: form_helper
INFO - 2021-06-28 02:15:49 --> Helper loaded: my_helper
INFO - 2021-06-28 02:15:49 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:15:49 --> Controller Class Initialized
DEBUG - 2021-06-28 02:15:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-06-28 02:15:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 02:15:49 --> Final output sent to browser
DEBUG - 2021-06-28 02:15:49 --> Total execution time: 0.1284
INFO - 2021-06-28 02:16:18 --> Config Class Initialized
INFO - 2021-06-28 02:16:18 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:16:18 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:16:18 --> Utf8 Class Initialized
INFO - 2021-06-28 02:16:18 --> URI Class Initialized
INFO - 2021-06-28 02:16:18 --> Router Class Initialized
INFO - 2021-06-28 02:16:18 --> Output Class Initialized
INFO - 2021-06-28 02:16:18 --> Security Class Initialized
DEBUG - 2021-06-28 02:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:16:18 --> Input Class Initialized
INFO - 2021-06-28 02:16:18 --> Language Class Initialized
INFO - 2021-06-28 02:16:18 --> Language Class Initialized
INFO - 2021-06-28 02:16:18 --> Config Class Initialized
INFO - 2021-06-28 02:16:18 --> Loader Class Initialized
INFO - 2021-06-28 02:16:18 --> Helper loaded: url_helper
INFO - 2021-06-28 02:16:18 --> Helper loaded: file_helper
INFO - 2021-06-28 02:16:18 --> Helper loaded: form_helper
INFO - 2021-06-28 02:16:18 --> Helper loaded: my_helper
INFO - 2021-06-28 02:16:18 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:16:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:16:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:16:18 --> Controller Class Initialized
DEBUG - 2021-06-28 02:16:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-28 02:16:18 --> Final output sent to browser
DEBUG - 2021-06-28 02:16:18 --> Total execution time: 0.3215
INFO - 2021-06-28 02:16:54 --> Config Class Initialized
INFO - 2021-06-28 02:16:54 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:16:54 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:16:54 --> Utf8 Class Initialized
INFO - 2021-06-28 02:16:54 --> URI Class Initialized
INFO - 2021-06-28 02:16:54 --> Router Class Initialized
INFO - 2021-06-28 02:16:54 --> Output Class Initialized
INFO - 2021-06-28 02:16:54 --> Security Class Initialized
DEBUG - 2021-06-28 02:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:16:54 --> Input Class Initialized
INFO - 2021-06-28 02:16:54 --> Language Class Initialized
INFO - 2021-06-28 02:16:54 --> Language Class Initialized
INFO - 2021-06-28 02:16:54 --> Config Class Initialized
INFO - 2021-06-28 02:16:54 --> Loader Class Initialized
INFO - 2021-06-28 02:16:54 --> Helper loaded: url_helper
INFO - 2021-06-28 02:16:54 --> Helper loaded: file_helper
INFO - 2021-06-28 02:16:54 --> Helper loaded: form_helper
INFO - 2021-06-28 02:16:54 --> Helper loaded: my_helper
INFO - 2021-06-28 02:16:54 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:16:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:16:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:16:54 --> Controller Class Initialized
DEBUG - 2021-06-28 02:16:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-28 02:16:54 --> Final output sent to browser
DEBUG - 2021-06-28 02:16:54 --> Total execution time: 0.2130
INFO - 2021-06-28 02:16:57 --> Config Class Initialized
INFO - 2021-06-28 02:16:57 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:16:57 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:16:57 --> Utf8 Class Initialized
INFO - 2021-06-28 02:16:57 --> URI Class Initialized
INFO - 2021-06-28 02:16:57 --> Router Class Initialized
INFO - 2021-06-28 02:16:57 --> Output Class Initialized
INFO - 2021-06-28 02:16:57 --> Security Class Initialized
DEBUG - 2021-06-28 02:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:16:57 --> Input Class Initialized
INFO - 2021-06-28 02:16:57 --> Language Class Initialized
INFO - 2021-06-28 02:16:57 --> Language Class Initialized
INFO - 2021-06-28 02:16:57 --> Config Class Initialized
INFO - 2021-06-28 02:16:57 --> Loader Class Initialized
INFO - 2021-06-28 02:16:57 --> Helper loaded: url_helper
INFO - 2021-06-28 02:16:57 --> Helper loaded: file_helper
INFO - 2021-06-28 02:16:57 --> Helper loaded: form_helper
INFO - 2021-06-28 02:16:57 --> Helper loaded: my_helper
INFO - 2021-06-28 02:16:57 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:16:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:16:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:16:57 --> Controller Class Initialized
DEBUG - 2021-06-28 02:16:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-28 02:16:57 --> Final output sent to browser
DEBUG - 2021-06-28 02:16:57 --> Total execution time: 0.2132
INFO - 2021-06-28 02:16:58 --> Config Class Initialized
INFO - 2021-06-28 02:16:58 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:16:58 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:16:58 --> Utf8 Class Initialized
INFO - 2021-06-28 02:16:58 --> URI Class Initialized
INFO - 2021-06-28 02:16:58 --> Router Class Initialized
INFO - 2021-06-28 02:16:58 --> Output Class Initialized
INFO - 2021-06-28 02:16:58 --> Security Class Initialized
DEBUG - 2021-06-28 02:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:16:58 --> Input Class Initialized
INFO - 2021-06-28 02:16:58 --> Language Class Initialized
INFO - 2021-06-28 02:16:59 --> Language Class Initialized
INFO - 2021-06-28 02:16:59 --> Config Class Initialized
INFO - 2021-06-28 02:16:59 --> Loader Class Initialized
INFO - 2021-06-28 02:16:59 --> Helper loaded: url_helper
INFO - 2021-06-28 02:16:59 --> Helper loaded: file_helper
INFO - 2021-06-28 02:16:59 --> Helper loaded: form_helper
INFO - 2021-06-28 02:16:59 --> Helper loaded: my_helper
INFO - 2021-06-28 02:16:59 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:16:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:16:59 --> Controller Class Initialized
DEBUG - 2021-06-28 02:16:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-28 02:16:59 --> Final output sent to browser
DEBUG - 2021-06-28 02:16:59 --> Total execution time: 0.2723
INFO - 2021-06-28 02:17:02 --> Config Class Initialized
INFO - 2021-06-28 02:17:02 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:17:02 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:17:02 --> Utf8 Class Initialized
INFO - 2021-06-28 02:17:02 --> URI Class Initialized
INFO - 2021-06-28 02:17:02 --> Router Class Initialized
INFO - 2021-06-28 02:17:02 --> Output Class Initialized
INFO - 2021-06-28 02:17:02 --> Security Class Initialized
DEBUG - 2021-06-28 02:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:17:02 --> Input Class Initialized
INFO - 2021-06-28 02:17:02 --> Language Class Initialized
INFO - 2021-06-28 02:17:02 --> Language Class Initialized
INFO - 2021-06-28 02:17:02 --> Config Class Initialized
INFO - 2021-06-28 02:17:02 --> Loader Class Initialized
INFO - 2021-06-28 02:17:02 --> Helper loaded: url_helper
INFO - 2021-06-28 02:17:02 --> Helper loaded: file_helper
INFO - 2021-06-28 02:17:02 --> Helper loaded: form_helper
INFO - 2021-06-28 02:17:02 --> Helper loaded: my_helper
INFO - 2021-06-28 02:17:02 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:17:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:17:02 --> Controller Class Initialized
DEBUG - 2021-06-28 02:17:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-28 02:17:03 --> Final output sent to browser
DEBUG - 2021-06-28 02:17:03 --> Total execution time: 0.1980
INFO - 2021-06-28 02:17:05 --> Config Class Initialized
INFO - 2021-06-28 02:17:05 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:17:05 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:17:05 --> Utf8 Class Initialized
INFO - 2021-06-28 02:17:05 --> URI Class Initialized
INFO - 2021-06-28 02:17:05 --> Router Class Initialized
INFO - 2021-06-28 02:17:05 --> Output Class Initialized
INFO - 2021-06-28 02:17:05 --> Security Class Initialized
DEBUG - 2021-06-28 02:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:17:05 --> Input Class Initialized
INFO - 2021-06-28 02:17:05 --> Language Class Initialized
INFO - 2021-06-28 02:17:05 --> Language Class Initialized
INFO - 2021-06-28 02:17:05 --> Config Class Initialized
INFO - 2021-06-28 02:17:05 --> Loader Class Initialized
INFO - 2021-06-28 02:17:05 --> Helper loaded: url_helper
INFO - 2021-06-28 02:17:05 --> Helper loaded: file_helper
INFO - 2021-06-28 02:17:05 --> Helper loaded: form_helper
INFO - 2021-06-28 02:17:05 --> Helper loaded: my_helper
INFO - 2021-06-28 02:17:05 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:17:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:17:05 --> Controller Class Initialized
DEBUG - 2021-06-28 02:17:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-28 02:17:05 --> Final output sent to browser
DEBUG - 2021-06-28 02:17:05 --> Total execution time: 0.1957
INFO - 2021-06-28 02:17:07 --> Config Class Initialized
INFO - 2021-06-28 02:17:07 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:17:07 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:17:07 --> Utf8 Class Initialized
INFO - 2021-06-28 02:17:07 --> URI Class Initialized
INFO - 2021-06-28 02:17:07 --> Router Class Initialized
INFO - 2021-06-28 02:17:07 --> Output Class Initialized
INFO - 2021-06-28 02:17:07 --> Security Class Initialized
DEBUG - 2021-06-28 02:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:17:07 --> Input Class Initialized
INFO - 2021-06-28 02:17:07 --> Language Class Initialized
INFO - 2021-06-28 02:17:07 --> Language Class Initialized
INFO - 2021-06-28 02:17:07 --> Config Class Initialized
INFO - 2021-06-28 02:17:07 --> Loader Class Initialized
INFO - 2021-06-28 02:17:07 --> Helper loaded: url_helper
INFO - 2021-06-28 02:17:07 --> Helper loaded: file_helper
INFO - 2021-06-28 02:17:07 --> Helper loaded: form_helper
INFO - 2021-06-28 02:17:07 --> Helper loaded: my_helper
INFO - 2021-06-28 02:17:07 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:17:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:17:07 --> Controller Class Initialized
DEBUG - 2021-06-28 02:17:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-28 02:17:07 --> Final output sent to browser
DEBUG - 2021-06-28 02:17:07 --> Total execution time: 0.2017
INFO - 2021-06-28 02:17:10 --> Config Class Initialized
INFO - 2021-06-28 02:17:10 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:17:10 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:17:10 --> Utf8 Class Initialized
INFO - 2021-06-28 02:17:10 --> URI Class Initialized
INFO - 2021-06-28 02:17:10 --> Router Class Initialized
INFO - 2021-06-28 02:17:10 --> Output Class Initialized
INFO - 2021-06-28 02:17:10 --> Security Class Initialized
DEBUG - 2021-06-28 02:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:17:10 --> Input Class Initialized
INFO - 2021-06-28 02:17:10 --> Language Class Initialized
INFO - 2021-06-28 02:17:10 --> Language Class Initialized
INFO - 2021-06-28 02:17:10 --> Config Class Initialized
INFO - 2021-06-28 02:17:10 --> Loader Class Initialized
INFO - 2021-06-28 02:17:10 --> Helper loaded: url_helper
INFO - 2021-06-28 02:17:10 --> Helper loaded: file_helper
INFO - 2021-06-28 02:17:10 --> Helper loaded: form_helper
INFO - 2021-06-28 02:17:10 --> Helper loaded: my_helper
INFO - 2021-06-28 02:17:10 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:17:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:17:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:17:10 --> Controller Class Initialized
DEBUG - 2021-06-28 02:17:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-28 02:17:10 --> Final output sent to browser
DEBUG - 2021-06-28 02:17:10 --> Total execution time: 0.1961
INFO - 2021-06-28 02:17:11 --> Config Class Initialized
INFO - 2021-06-28 02:17:11 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:17:12 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:17:12 --> Utf8 Class Initialized
INFO - 2021-06-28 02:17:12 --> URI Class Initialized
INFO - 2021-06-28 02:17:12 --> Router Class Initialized
INFO - 2021-06-28 02:17:12 --> Output Class Initialized
INFO - 2021-06-28 02:17:12 --> Security Class Initialized
DEBUG - 2021-06-28 02:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:17:12 --> Input Class Initialized
INFO - 2021-06-28 02:17:12 --> Language Class Initialized
INFO - 2021-06-28 02:17:12 --> Language Class Initialized
INFO - 2021-06-28 02:17:12 --> Config Class Initialized
INFO - 2021-06-28 02:17:12 --> Loader Class Initialized
INFO - 2021-06-28 02:17:12 --> Helper loaded: url_helper
INFO - 2021-06-28 02:17:12 --> Helper loaded: file_helper
INFO - 2021-06-28 02:17:12 --> Helper loaded: form_helper
INFO - 2021-06-28 02:17:12 --> Helper loaded: my_helper
INFO - 2021-06-28 02:17:12 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:17:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:17:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:17:12 --> Controller Class Initialized
DEBUG - 2021-06-28 02:17:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-28 02:17:12 --> Final output sent to browser
DEBUG - 2021-06-28 02:17:12 --> Total execution time: 0.2734
INFO - 2021-06-28 02:17:13 --> Config Class Initialized
INFO - 2021-06-28 02:17:13 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:17:13 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:17:13 --> Utf8 Class Initialized
INFO - 2021-06-28 02:17:13 --> URI Class Initialized
INFO - 2021-06-28 02:17:13 --> Router Class Initialized
INFO - 2021-06-28 02:17:13 --> Output Class Initialized
INFO - 2021-06-28 02:17:13 --> Security Class Initialized
DEBUG - 2021-06-28 02:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:17:13 --> Input Class Initialized
INFO - 2021-06-28 02:17:13 --> Language Class Initialized
INFO - 2021-06-28 02:17:13 --> Language Class Initialized
INFO - 2021-06-28 02:17:13 --> Config Class Initialized
INFO - 2021-06-28 02:17:13 --> Loader Class Initialized
INFO - 2021-06-28 02:17:13 --> Helper loaded: url_helper
INFO - 2021-06-28 02:17:13 --> Helper loaded: file_helper
INFO - 2021-06-28 02:17:13 --> Helper loaded: form_helper
INFO - 2021-06-28 02:17:13 --> Helper loaded: my_helper
INFO - 2021-06-28 02:17:13 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:17:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:17:13 --> Controller Class Initialized
DEBUG - 2021-06-28 02:17:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-28 02:17:14 --> Final output sent to browser
DEBUG - 2021-06-28 02:17:14 --> Total execution time: 0.2025
INFO - 2021-06-28 02:17:15 --> Config Class Initialized
INFO - 2021-06-28 02:17:15 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:17:15 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:17:15 --> Utf8 Class Initialized
INFO - 2021-06-28 02:17:15 --> URI Class Initialized
INFO - 2021-06-28 02:17:15 --> Router Class Initialized
INFO - 2021-06-28 02:17:15 --> Output Class Initialized
INFO - 2021-06-28 02:17:15 --> Security Class Initialized
DEBUG - 2021-06-28 02:17:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:17:15 --> Input Class Initialized
INFO - 2021-06-28 02:17:15 --> Language Class Initialized
INFO - 2021-06-28 02:17:15 --> Language Class Initialized
INFO - 2021-06-28 02:17:15 --> Config Class Initialized
INFO - 2021-06-28 02:17:15 --> Loader Class Initialized
INFO - 2021-06-28 02:17:15 --> Helper loaded: url_helper
INFO - 2021-06-28 02:17:15 --> Helper loaded: file_helper
INFO - 2021-06-28 02:17:15 --> Helper loaded: form_helper
INFO - 2021-06-28 02:17:15 --> Helper loaded: my_helper
INFO - 2021-06-28 02:17:15 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:17:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:17:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:17:15 --> Controller Class Initialized
DEBUG - 2021-06-28 02:17:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-28 02:17:15 --> Final output sent to browser
DEBUG - 2021-06-28 02:17:15 --> Total execution time: 0.1949
INFO - 2021-06-28 02:17:17 --> Config Class Initialized
INFO - 2021-06-28 02:17:17 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:17:17 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:17:17 --> Utf8 Class Initialized
INFO - 2021-06-28 02:17:17 --> URI Class Initialized
INFO - 2021-06-28 02:17:17 --> Router Class Initialized
INFO - 2021-06-28 02:17:17 --> Output Class Initialized
INFO - 2021-06-28 02:17:17 --> Security Class Initialized
DEBUG - 2021-06-28 02:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:17:17 --> Input Class Initialized
INFO - 2021-06-28 02:17:17 --> Language Class Initialized
INFO - 2021-06-28 02:17:17 --> Language Class Initialized
INFO - 2021-06-28 02:17:17 --> Config Class Initialized
INFO - 2021-06-28 02:17:17 --> Loader Class Initialized
INFO - 2021-06-28 02:17:17 --> Helper loaded: url_helper
INFO - 2021-06-28 02:17:17 --> Helper loaded: file_helper
INFO - 2021-06-28 02:17:17 --> Helper loaded: form_helper
INFO - 2021-06-28 02:17:17 --> Helper loaded: my_helper
INFO - 2021-06-28 02:17:17 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:17:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:17:17 --> Controller Class Initialized
DEBUG - 2021-06-28 02:17:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-28 02:17:17 --> Final output sent to browser
DEBUG - 2021-06-28 02:17:17 --> Total execution time: 0.2415
INFO - 2021-06-28 02:17:18 --> Config Class Initialized
INFO - 2021-06-28 02:17:18 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:17:18 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:17:18 --> Utf8 Class Initialized
INFO - 2021-06-28 02:17:18 --> URI Class Initialized
INFO - 2021-06-28 02:17:18 --> Router Class Initialized
INFO - 2021-06-28 02:17:18 --> Output Class Initialized
INFO - 2021-06-28 02:17:18 --> Security Class Initialized
DEBUG - 2021-06-28 02:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:17:18 --> Input Class Initialized
INFO - 2021-06-28 02:17:18 --> Language Class Initialized
INFO - 2021-06-28 02:17:18 --> Language Class Initialized
INFO - 2021-06-28 02:17:18 --> Config Class Initialized
INFO - 2021-06-28 02:17:18 --> Loader Class Initialized
INFO - 2021-06-28 02:17:18 --> Helper loaded: url_helper
INFO - 2021-06-28 02:17:18 --> Helper loaded: file_helper
INFO - 2021-06-28 02:17:18 --> Helper loaded: form_helper
INFO - 2021-06-28 02:17:18 --> Helper loaded: my_helper
INFO - 2021-06-28 02:17:18 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:17:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:17:18 --> Controller Class Initialized
DEBUG - 2021-06-28 02:17:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-28 02:17:18 --> Final output sent to browser
DEBUG - 2021-06-28 02:17:18 --> Total execution time: 0.1911
INFO - 2021-06-28 02:17:21 --> Config Class Initialized
INFO - 2021-06-28 02:17:21 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:17:21 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:17:21 --> Utf8 Class Initialized
INFO - 2021-06-28 02:17:21 --> URI Class Initialized
INFO - 2021-06-28 02:17:21 --> Router Class Initialized
INFO - 2021-06-28 02:17:21 --> Output Class Initialized
INFO - 2021-06-28 02:17:21 --> Security Class Initialized
DEBUG - 2021-06-28 02:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:17:21 --> Input Class Initialized
INFO - 2021-06-28 02:17:21 --> Language Class Initialized
INFO - 2021-06-28 02:17:21 --> Language Class Initialized
INFO - 2021-06-28 02:17:21 --> Config Class Initialized
INFO - 2021-06-28 02:17:21 --> Loader Class Initialized
INFO - 2021-06-28 02:17:21 --> Helper loaded: url_helper
INFO - 2021-06-28 02:17:21 --> Helper loaded: file_helper
INFO - 2021-06-28 02:17:21 --> Helper loaded: form_helper
INFO - 2021-06-28 02:17:21 --> Helper loaded: my_helper
INFO - 2021-06-28 02:17:21 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:17:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:17:21 --> Controller Class Initialized
DEBUG - 2021-06-28 02:17:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-28 02:17:21 --> Final output sent to browser
DEBUG - 2021-06-28 02:17:21 --> Total execution time: 0.2511
INFO - 2021-06-28 02:17:22 --> Config Class Initialized
INFO - 2021-06-28 02:17:22 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:17:22 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:17:22 --> Utf8 Class Initialized
INFO - 2021-06-28 02:17:22 --> URI Class Initialized
INFO - 2021-06-28 02:17:22 --> Router Class Initialized
INFO - 2021-06-28 02:17:22 --> Output Class Initialized
INFO - 2021-06-28 02:17:22 --> Security Class Initialized
DEBUG - 2021-06-28 02:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:17:22 --> Input Class Initialized
INFO - 2021-06-28 02:17:22 --> Language Class Initialized
INFO - 2021-06-28 02:17:22 --> Language Class Initialized
INFO - 2021-06-28 02:17:22 --> Config Class Initialized
INFO - 2021-06-28 02:17:22 --> Loader Class Initialized
INFO - 2021-06-28 02:17:22 --> Helper loaded: url_helper
INFO - 2021-06-28 02:17:22 --> Helper loaded: file_helper
INFO - 2021-06-28 02:17:22 --> Helper loaded: form_helper
INFO - 2021-06-28 02:17:22 --> Helper loaded: my_helper
INFO - 2021-06-28 02:17:22 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:17:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:17:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:17:22 --> Controller Class Initialized
DEBUG - 2021-06-28 02:17:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-28 02:17:22 --> Final output sent to browser
DEBUG - 2021-06-28 02:17:22 --> Total execution time: 0.1987
INFO - 2021-06-28 02:17:24 --> Config Class Initialized
INFO - 2021-06-28 02:17:24 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:17:24 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:17:24 --> Utf8 Class Initialized
INFO - 2021-06-28 02:17:24 --> URI Class Initialized
INFO - 2021-06-28 02:17:24 --> Router Class Initialized
INFO - 2021-06-28 02:17:24 --> Output Class Initialized
INFO - 2021-06-28 02:17:24 --> Security Class Initialized
DEBUG - 2021-06-28 02:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:17:24 --> Input Class Initialized
INFO - 2021-06-28 02:17:24 --> Language Class Initialized
INFO - 2021-06-28 02:17:24 --> Language Class Initialized
INFO - 2021-06-28 02:17:24 --> Config Class Initialized
INFO - 2021-06-28 02:17:24 --> Loader Class Initialized
INFO - 2021-06-28 02:17:24 --> Helper loaded: url_helper
INFO - 2021-06-28 02:17:24 --> Helper loaded: file_helper
INFO - 2021-06-28 02:17:24 --> Helper loaded: form_helper
INFO - 2021-06-28 02:17:24 --> Helper loaded: my_helper
INFO - 2021-06-28 02:17:24 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:17:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:17:24 --> Controller Class Initialized
DEBUG - 2021-06-28 02:17:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-28 02:17:24 --> Final output sent to browser
DEBUG - 2021-06-28 02:17:24 --> Total execution time: 0.1889
INFO - 2021-06-28 02:17:26 --> Config Class Initialized
INFO - 2021-06-28 02:17:26 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:17:26 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:17:26 --> Utf8 Class Initialized
INFO - 2021-06-28 02:17:26 --> URI Class Initialized
INFO - 2021-06-28 02:17:26 --> Router Class Initialized
INFO - 2021-06-28 02:17:26 --> Output Class Initialized
INFO - 2021-06-28 02:17:26 --> Security Class Initialized
DEBUG - 2021-06-28 02:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:17:26 --> Input Class Initialized
INFO - 2021-06-28 02:17:26 --> Language Class Initialized
INFO - 2021-06-28 02:17:26 --> Language Class Initialized
INFO - 2021-06-28 02:17:26 --> Config Class Initialized
INFO - 2021-06-28 02:17:26 --> Loader Class Initialized
INFO - 2021-06-28 02:17:26 --> Helper loaded: url_helper
INFO - 2021-06-28 02:17:26 --> Helper loaded: file_helper
INFO - 2021-06-28 02:17:26 --> Helper loaded: form_helper
INFO - 2021-06-28 02:17:26 --> Helper loaded: my_helper
INFO - 2021-06-28 02:17:26 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:17:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:17:26 --> Controller Class Initialized
DEBUG - 2021-06-28 02:17:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-28 02:17:26 --> Final output sent to browser
DEBUG - 2021-06-28 02:17:26 --> Total execution time: 0.2526
INFO - 2021-06-28 02:17:29 --> Config Class Initialized
INFO - 2021-06-28 02:17:29 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:17:29 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:17:29 --> Utf8 Class Initialized
INFO - 2021-06-28 02:17:29 --> URI Class Initialized
INFO - 2021-06-28 02:17:29 --> Router Class Initialized
INFO - 2021-06-28 02:17:29 --> Output Class Initialized
INFO - 2021-06-28 02:17:29 --> Security Class Initialized
DEBUG - 2021-06-28 02:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:17:29 --> Input Class Initialized
INFO - 2021-06-28 02:17:29 --> Language Class Initialized
INFO - 2021-06-28 02:17:29 --> Language Class Initialized
INFO - 2021-06-28 02:17:29 --> Config Class Initialized
INFO - 2021-06-28 02:17:29 --> Loader Class Initialized
INFO - 2021-06-28 02:17:29 --> Helper loaded: url_helper
INFO - 2021-06-28 02:17:29 --> Helper loaded: file_helper
INFO - 2021-06-28 02:17:29 --> Helper loaded: form_helper
INFO - 2021-06-28 02:17:29 --> Helper loaded: my_helper
INFO - 2021-06-28 02:17:29 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:17:29 --> Controller Class Initialized
DEBUG - 2021-06-28 02:17:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-28 02:17:29 --> Final output sent to browser
DEBUG - 2021-06-28 02:17:29 --> Total execution time: 0.1912
INFO - 2021-06-28 02:17:31 --> Config Class Initialized
INFO - 2021-06-28 02:17:31 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:17:31 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:17:31 --> Utf8 Class Initialized
INFO - 2021-06-28 02:17:31 --> URI Class Initialized
INFO - 2021-06-28 02:17:31 --> Router Class Initialized
INFO - 2021-06-28 02:17:31 --> Output Class Initialized
INFO - 2021-06-28 02:17:31 --> Security Class Initialized
DEBUG - 2021-06-28 02:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:17:31 --> Input Class Initialized
INFO - 2021-06-28 02:17:31 --> Language Class Initialized
INFO - 2021-06-28 02:17:31 --> Language Class Initialized
INFO - 2021-06-28 02:17:31 --> Config Class Initialized
INFO - 2021-06-28 02:17:31 --> Loader Class Initialized
INFO - 2021-06-28 02:17:31 --> Helper loaded: url_helper
INFO - 2021-06-28 02:17:31 --> Helper loaded: file_helper
INFO - 2021-06-28 02:17:31 --> Helper loaded: form_helper
INFO - 2021-06-28 02:17:31 --> Helper loaded: my_helper
INFO - 2021-06-28 02:17:31 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:17:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:17:31 --> Controller Class Initialized
DEBUG - 2021-06-28 02:17:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-28 02:17:31 --> Final output sent to browser
DEBUG - 2021-06-28 02:17:31 --> Total execution time: 0.1873
INFO - 2021-06-28 02:17:33 --> Config Class Initialized
INFO - 2021-06-28 02:17:33 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:17:33 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:17:33 --> Utf8 Class Initialized
INFO - 2021-06-28 02:17:33 --> URI Class Initialized
INFO - 2021-06-28 02:17:33 --> Router Class Initialized
INFO - 2021-06-28 02:17:33 --> Output Class Initialized
INFO - 2021-06-28 02:17:33 --> Security Class Initialized
DEBUG - 2021-06-28 02:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:17:33 --> Input Class Initialized
INFO - 2021-06-28 02:17:33 --> Language Class Initialized
INFO - 2021-06-28 02:17:33 --> Language Class Initialized
INFO - 2021-06-28 02:17:33 --> Config Class Initialized
INFO - 2021-06-28 02:17:33 --> Loader Class Initialized
INFO - 2021-06-28 02:17:33 --> Helper loaded: url_helper
INFO - 2021-06-28 02:17:33 --> Helper loaded: file_helper
INFO - 2021-06-28 02:17:33 --> Helper loaded: form_helper
INFO - 2021-06-28 02:17:33 --> Helper loaded: my_helper
INFO - 2021-06-28 02:17:33 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:17:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:17:33 --> Controller Class Initialized
DEBUG - 2021-06-28 02:17:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-28 02:17:33 --> Final output sent to browser
DEBUG - 2021-06-28 02:17:33 --> Total execution time: 0.2803
INFO - 2021-06-28 02:17:34 --> Config Class Initialized
INFO - 2021-06-28 02:17:34 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:17:34 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:17:34 --> Utf8 Class Initialized
INFO - 2021-06-28 02:17:34 --> URI Class Initialized
INFO - 2021-06-28 02:17:34 --> Router Class Initialized
INFO - 2021-06-28 02:17:34 --> Output Class Initialized
INFO - 2021-06-28 02:17:34 --> Security Class Initialized
DEBUG - 2021-06-28 02:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:17:34 --> Input Class Initialized
INFO - 2021-06-28 02:17:34 --> Language Class Initialized
INFO - 2021-06-28 02:17:34 --> Language Class Initialized
INFO - 2021-06-28 02:17:34 --> Config Class Initialized
INFO - 2021-06-28 02:17:34 --> Loader Class Initialized
INFO - 2021-06-28 02:17:34 --> Helper loaded: url_helper
INFO - 2021-06-28 02:17:34 --> Helper loaded: file_helper
INFO - 2021-06-28 02:17:34 --> Helper loaded: form_helper
INFO - 2021-06-28 02:17:34 --> Helper loaded: my_helper
INFO - 2021-06-28 02:17:34 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:17:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:17:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:17:34 --> Controller Class Initialized
DEBUG - 2021-06-28 02:17:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-28 02:17:34 --> Final output sent to browser
DEBUG - 2021-06-28 02:17:34 --> Total execution time: 0.2076
INFO - 2021-06-28 02:17:36 --> Config Class Initialized
INFO - 2021-06-28 02:17:36 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:17:36 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:17:36 --> Utf8 Class Initialized
INFO - 2021-06-28 02:17:36 --> URI Class Initialized
INFO - 2021-06-28 02:17:36 --> Router Class Initialized
INFO - 2021-06-28 02:17:36 --> Output Class Initialized
INFO - 2021-06-28 02:17:36 --> Security Class Initialized
DEBUG - 2021-06-28 02:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:17:36 --> Input Class Initialized
INFO - 2021-06-28 02:17:36 --> Language Class Initialized
INFO - 2021-06-28 02:17:36 --> Language Class Initialized
INFO - 2021-06-28 02:17:36 --> Config Class Initialized
INFO - 2021-06-28 02:17:36 --> Loader Class Initialized
INFO - 2021-06-28 02:17:36 --> Helper loaded: url_helper
INFO - 2021-06-28 02:17:36 --> Helper loaded: file_helper
INFO - 2021-06-28 02:17:36 --> Helper loaded: form_helper
INFO - 2021-06-28 02:17:36 --> Helper loaded: my_helper
INFO - 2021-06-28 02:17:36 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:17:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:17:36 --> Controller Class Initialized
DEBUG - 2021-06-28 02:17:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-28 02:17:36 --> Final output sent to browser
DEBUG - 2021-06-28 02:17:36 --> Total execution time: 0.1971
INFO - 2021-06-28 02:17:37 --> Config Class Initialized
INFO - 2021-06-28 02:17:37 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:17:37 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:17:37 --> Utf8 Class Initialized
INFO - 2021-06-28 02:17:37 --> URI Class Initialized
INFO - 2021-06-28 02:17:37 --> Router Class Initialized
INFO - 2021-06-28 02:17:37 --> Output Class Initialized
INFO - 2021-06-28 02:17:37 --> Security Class Initialized
DEBUG - 2021-06-28 02:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:17:37 --> Input Class Initialized
INFO - 2021-06-28 02:17:37 --> Language Class Initialized
INFO - 2021-06-28 02:17:37 --> Language Class Initialized
INFO - 2021-06-28 02:17:37 --> Config Class Initialized
INFO - 2021-06-28 02:17:37 --> Loader Class Initialized
INFO - 2021-06-28 02:17:38 --> Helper loaded: url_helper
INFO - 2021-06-28 02:17:38 --> Helper loaded: file_helper
INFO - 2021-06-28 02:17:38 --> Helper loaded: form_helper
INFO - 2021-06-28 02:17:38 --> Helper loaded: my_helper
INFO - 2021-06-28 02:17:38 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:17:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:17:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:17:38 --> Controller Class Initialized
DEBUG - 2021-06-28 02:17:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-28 02:17:38 --> Final output sent to browser
DEBUG - 2021-06-28 02:17:38 --> Total execution time: 0.1939
INFO - 2021-06-28 02:17:42 --> Config Class Initialized
INFO - 2021-06-28 02:17:42 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:17:42 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:17:42 --> Utf8 Class Initialized
INFO - 2021-06-28 02:17:42 --> URI Class Initialized
INFO - 2021-06-28 02:17:42 --> Router Class Initialized
INFO - 2021-06-28 02:17:42 --> Output Class Initialized
INFO - 2021-06-28 02:17:42 --> Security Class Initialized
DEBUG - 2021-06-28 02:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:17:42 --> Input Class Initialized
INFO - 2021-06-28 02:17:42 --> Language Class Initialized
INFO - 2021-06-28 02:17:42 --> Language Class Initialized
INFO - 2021-06-28 02:17:42 --> Config Class Initialized
INFO - 2021-06-28 02:17:42 --> Loader Class Initialized
INFO - 2021-06-28 02:17:42 --> Helper loaded: url_helper
INFO - 2021-06-28 02:17:42 --> Helper loaded: file_helper
INFO - 2021-06-28 02:17:42 --> Helper loaded: form_helper
INFO - 2021-06-28 02:17:42 --> Helper loaded: my_helper
INFO - 2021-06-28 02:17:42 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:17:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:17:42 --> Controller Class Initialized
DEBUG - 2021-06-28 02:17:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-28 02:17:42 --> Final output sent to browser
DEBUG - 2021-06-28 02:17:42 --> Total execution time: 0.1898
INFO - 2021-06-28 02:17:44 --> Config Class Initialized
INFO - 2021-06-28 02:17:44 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:17:44 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:17:44 --> Utf8 Class Initialized
INFO - 2021-06-28 02:17:44 --> URI Class Initialized
INFO - 2021-06-28 02:17:44 --> Router Class Initialized
INFO - 2021-06-28 02:17:44 --> Output Class Initialized
INFO - 2021-06-28 02:17:44 --> Security Class Initialized
DEBUG - 2021-06-28 02:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:17:44 --> Input Class Initialized
INFO - 2021-06-28 02:17:44 --> Language Class Initialized
INFO - 2021-06-28 02:17:44 --> Language Class Initialized
INFO - 2021-06-28 02:17:44 --> Config Class Initialized
INFO - 2021-06-28 02:17:44 --> Loader Class Initialized
INFO - 2021-06-28 02:17:44 --> Helper loaded: url_helper
INFO - 2021-06-28 02:17:44 --> Helper loaded: file_helper
INFO - 2021-06-28 02:17:44 --> Helper loaded: form_helper
INFO - 2021-06-28 02:17:44 --> Helper loaded: my_helper
INFO - 2021-06-28 02:17:44 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:17:44 --> Controller Class Initialized
DEBUG - 2021-06-28 02:17:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-28 02:17:44 --> Final output sent to browser
DEBUG - 2021-06-28 02:17:44 --> Total execution time: 0.2018
INFO - 2021-06-28 02:20:10 --> Config Class Initialized
INFO - 2021-06-28 02:20:10 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:20:10 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:20:10 --> Utf8 Class Initialized
INFO - 2021-06-28 02:20:10 --> URI Class Initialized
INFO - 2021-06-28 02:20:10 --> Router Class Initialized
INFO - 2021-06-28 02:20:10 --> Output Class Initialized
INFO - 2021-06-28 02:20:10 --> Security Class Initialized
DEBUG - 2021-06-28 02:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:20:10 --> Input Class Initialized
INFO - 2021-06-28 02:20:10 --> Language Class Initialized
INFO - 2021-06-28 02:20:10 --> Language Class Initialized
INFO - 2021-06-28 02:20:10 --> Config Class Initialized
INFO - 2021-06-28 02:20:10 --> Loader Class Initialized
INFO - 2021-06-28 02:20:10 --> Helper loaded: url_helper
INFO - 2021-06-28 02:20:10 --> Helper loaded: file_helper
INFO - 2021-06-28 02:20:10 --> Helper loaded: form_helper
INFO - 2021-06-28 02:20:10 --> Helper loaded: my_helper
INFO - 2021-06-28 02:20:10 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:20:10 --> Controller Class Initialized
INFO - 2021-06-28 02:20:10 --> Helper loaded: cookie_helper
INFO - 2021-06-28 02:20:10 --> Config Class Initialized
INFO - 2021-06-28 02:20:10 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:20:10 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:20:10 --> Utf8 Class Initialized
INFO - 2021-06-28 02:20:10 --> URI Class Initialized
INFO - 2021-06-28 02:20:10 --> Router Class Initialized
INFO - 2021-06-28 02:20:10 --> Output Class Initialized
INFO - 2021-06-28 02:20:10 --> Security Class Initialized
DEBUG - 2021-06-28 02:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:20:10 --> Input Class Initialized
INFO - 2021-06-28 02:20:10 --> Language Class Initialized
INFO - 2021-06-28 02:20:10 --> Language Class Initialized
INFO - 2021-06-28 02:20:10 --> Config Class Initialized
INFO - 2021-06-28 02:20:10 --> Loader Class Initialized
INFO - 2021-06-28 02:20:10 --> Helper loaded: url_helper
INFO - 2021-06-28 02:20:10 --> Helper loaded: file_helper
INFO - 2021-06-28 02:20:10 --> Helper loaded: form_helper
INFO - 2021-06-28 02:20:10 --> Helper loaded: my_helper
INFO - 2021-06-28 02:20:10 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:20:10 --> Controller Class Initialized
DEBUG - 2021-06-28 02:20:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-28 02:20:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 02:20:10 --> Final output sent to browser
DEBUG - 2021-06-28 02:20:10 --> Total execution time: 0.0401
INFO - 2021-06-28 02:26:39 --> Config Class Initialized
INFO - 2021-06-28 02:26:39 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:26:39 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:26:39 --> Utf8 Class Initialized
INFO - 2021-06-28 02:26:39 --> URI Class Initialized
INFO - 2021-06-28 02:26:39 --> Router Class Initialized
INFO - 2021-06-28 02:26:39 --> Output Class Initialized
INFO - 2021-06-28 02:26:39 --> Security Class Initialized
DEBUG - 2021-06-28 02:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:26:39 --> Input Class Initialized
INFO - 2021-06-28 02:26:39 --> Language Class Initialized
INFO - 2021-06-28 02:26:39 --> Language Class Initialized
INFO - 2021-06-28 02:26:39 --> Config Class Initialized
INFO - 2021-06-28 02:26:39 --> Loader Class Initialized
INFO - 2021-06-28 02:26:39 --> Helper loaded: url_helper
INFO - 2021-06-28 02:26:39 --> Helper loaded: file_helper
INFO - 2021-06-28 02:26:39 --> Helper loaded: form_helper
INFO - 2021-06-28 02:26:39 --> Helper loaded: my_helper
INFO - 2021-06-28 02:26:39 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:26:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:26:39 --> Controller Class Initialized
INFO - 2021-06-28 02:26:39 --> Helper loaded: cookie_helper
INFO - 2021-06-28 02:26:39 --> Final output sent to browser
DEBUG - 2021-06-28 02:26:39 --> Total execution time: 0.0446
INFO - 2021-06-28 02:26:39 --> Config Class Initialized
INFO - 2021-06-28 02:26:39 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:26:39 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:26:39 --> Utf8 Class Initialized
INFO - 2021-06-28 02:26:39 --> URI Class Initialized
INFO - 2021-06-28 02:26:39 --> Router Class Initialized
INFO - 2021-06-28 02:26:39 --> Output Class Initialized
INFO - 2021-06-28 02:26:39 --> Security Class Initialized
DEBUG - 2021-06-28 02:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:26:39 --> Input Class Initialized
INFO - 2021-06-28 02:26:39 --> Language Class Initialized
INFO - 2021-06-28 02:26:39 --> Language Class Initialized
INFO - 2021-06-28 02:26:39 --> Config Class Initialized
INFO - 2021-06-28 02:26:39 --> Loader Class Initialized
INFO - 2021-06-28 02:26:39 --> Helper loaded: url_helper
INFO - 2021-06-28 02:26:39 --> Helper loaded: file_helper
INFO - 2021-06-28 02:26:39 --> Helper loaded: form_helper
INFO - 2021-06-28 02:26:39 --> Helper loaded: my_helper
INFO - 2021-06-28 02:26:39 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:26:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:26:39 --> Controller Class Initialized
DEBUG - 2021-06-28 02:26:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-28 02:26:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 02:26:40 --> Final output sent to browser
DEBUG - 2021-06-28 02:26:40 --> Total execution time: 0.6482
INFO - 2021-06-28 02:26:42 --> Config Class Initialized
INFO - 2021-06-28 02:26:42 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:26:42 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:26:42 --> Utf8 Class Initialized
INFO - 2021-06-28 02:26:42 --> URI Class Initialized
INFO - 2021-06-28 02:26:42 --> Router Class Initialized
INFO - 2021-06-28 02:26:42 --> Output Class Initialized
INFO - 2021-06-28 02:26:42 --> Security Class Initialized
DEBUG - 2021-06-28 02:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:26:42 --> Input Class Initialized
INFO - 2021-06-28 02:26:42 --> Language Class Initialized
INFO - 2021-06-28 02:26:42 --> Language Class Initialized
INFO - 2021-06-28 02:26:42 --> Config Class Initialized
INFO - 2021-06-28 02:26:42 --> Loader Class Initialized
INFO - 2021-06-28 02:26:42 --> Helper loaded: url_helper
INFO - 2021-06-28 02:26:42 --> Helper loaded: file_helper
INFO - 2021-06-28 02:26:42 --> Helper loaded: form_helper
INFO - 2021-06-28 02:26:42 --> Helper loaded: my_helper
INFO - 2021-06-28 02:26:42 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:26:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:26:42 --> Controller Class Initialized
DEBUG - 2021-06-28 02:26:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-28 02:26:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 02:26:42 --> Final output sent to browser
DEBUG - 2021-06-28 02:26:42 --> Total execution time: 0.0527
INFO - 2021-06-28 02:26:48 --> Config Class Initialized
INFO - 2021-06-28 02:26:48 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:26:48 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:26:48 --> Utf8 Class Initialized
INFO - 2021-06-28 02:26:48 --> URI Class Initialized
INFO - 2021-06-28 02:26:48 --> Router Class Initialized
INFO - 2021-06-28 02:26:48 --> Output Class Initialized
INFO - 2021-06-28 02:26:48 --> Security Class Initialized
DEBUG - 2021-06-28 02:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:26:48 --> Input Class Initialized
INFO - 2021-06-28 02:26:48 --> Language Class Initialized
INFO - 2021-06-28 02:26:48 --> Language Class Initialized
INFO - 2021-06-28 02:26:48 --> Config Class Initialized
INFO - 2021-06-28 02:26:48 --> Loader Class Initialized
INFO - 2021-06-28 02:26:48 --> Helper loaded: url_helper
INFO - 2021-06-28 02:26:48 --> Helper loaded: file_helper
INFO - 2021-06-28 02:26:48 --> Helper loaded: form_helper
INFO - 2021-06-28 02:26:48 --> Helper loaded: my_helper
INFO - 2021-06-28 02:26:48 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:26:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:26:48 --> Controller Class Initialized
DEBUG - 2021-06-28 02:26:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-28 02:26:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 02:26:48 --> Final output sent to browser
DEBUG - 2021-06-28 02:26:48 --> Total execution time: 0.0486
INFO - 2021-06-28 02:26:51 --> Config Class Initialized
INFO - 2021-06-28 02:26:51 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:26:51 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:26:51 --> Utf8 Class Initialized
INFO - 2021-06-28 02:26:51 --> URI Class Initialized
INFO - 2021-06-28 02:26:51 --> Router Class Initialized
INFO - 2021-06-28 02:26:51 --> Output Class Initialized
INFO - 2021-06-28 02:26:51 --> Security Class Initialized
DEBUG - 2021-06-28 02:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:26:51 --> Input Class Initialized
INFO - 2021-06-28 02:26:51 --> Language Class Initialized
INFO - 2021-06-28 02:26:51 --> Language Class Initialized
INFO - 2021-06-28 02:26:51 --> Config Class Initialized
INFO - 2021-06-28 02:26:51 --> Loader Class Initialized
INFO - 2021-06-28 02:26:51 --> Helper loaded: url_helper
INFO - 2021-06-28 02:26:51 --> Helper loaded: file_helper
INFO - 2021-06-28 02:26:51 --> Helper loaded: form_helper
INFO - 2021-06-28 02:26:51 --> Helper loaded: my_helper
INFO - 2021-06-28 02:26:51 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:26:51 --> Controller Class Initialized
INFO - 2021-06-28 02:26:51 --> Final output sent to browser
DEBUG - 2021-06-28 02:26:51 --> Total execution time: 0.1015
INFO - 2021-06-28 02:26:59 --> Config Class Initialized
INFO - 2021-06-28 02:26:59 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:26:59 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:26:59 --> Utf8 Class Initialized
INFO - 2021-06-28 02:26:59 --> URI Class Initialized
INFO - 2021-06-28 02:26:59 --> Router Class Initialized
INFO - 2021-06-28 02:26:59 --> Output Class Initialized
INFO - 2021-06-28 02:26:59 --> Security Class Initialized
DEBUG - 2021-06-28 02:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:26:59 --> Input Class Initialized
INFO - 2021-06-28 02:26:59 --> Language Class Initialized
INFO - 2021-06-28 02:26:59 --> Language Class Initialized
INFO - 2021-06-28 02:26:59 --> Config Class Initialized
INFO - 2021-06-28 02:26:59 --> Loader Class Initialized
INFO - 2021-06-28 02:26:59 --> Helper loaded: url_helper
INFO - 2021-06-28 02:26:59 --> Helper loaded: file_helper
INFO - 2021-06-28 02:26:59 --> Helper loaded: form_helper
INFO - 2021-06-28 02:26:59 --> Helper loaded: my_helper
INFO - 2021-06-28 02:26:59 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:26:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:26:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:26:59 --> Controller Class Initialized
INFO - 2021-06-28 02:27:00 --> Final output sent to browser
DEBUG - 2021-06-28 02:27:00 --> Total execution time: 0.9828
INFO - 2021-06-28 02:27:00 --> Config Class Initialized
INFO - 2021-06-28 02:27:00 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:27:00 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:27:00 --> Utf8 Class Initialized
INFO - 2021-06-28 02:27:00 --> URI Class Initialized
INFO - 2021-06-28 02:27:00 --> Router Class Initialized
INFO - 2021-06-28 02:27:00 --> Output Class Initialized
INFO - 2021-06-28 02:27:00 --> Security Class Initialized
DEBUG - 2021-06-28 02:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:27:00 --> Input Class Initialized
INFO - 2021-06-28 02:27:00 --> Language Class Initialized
INFO - 2021-06-28 02:27:00 --> Language Class Initialized
INFO - 2021-06-28 02:27:00 --> Config Class Initialized
INFO - 2021-06-28 02:27:00 --> Loader Class Initialized
INFO - 2021-06-28 02:27:00 --> Helper loaded: url_helper
INFO - 2021-06-28 02:27:00 --> Helper loaded: file_helper
INFO - 2021-06-28 02:27:00 --> Helper loaded: form_helper
INFO - 2021-06-28 02:27:00 --> Helper loaded: my_helper
INFO - 2021-06-28 02:27:00 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:27:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:27:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:27:00 --> Controller Class Initialized
INFO - 2021-06-28 02:27:00 --> Final output sent to browser
DEBUG - 2021-06-28 02:27:00 --> Total execution time: 0.0550
INFO - 2021-06-28 02:27:05 --> Config Class Initialized
INFO - 2021-06-28 02:27:05 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:27:05 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:27:05 --> Utf8 Class Initialized
INFO - 2021-06-28 02:27:05 --> URI Class Initialized
INFO - 2021-06-28 02:27:05 --> Router Class Initialized
INFO - 2021-06-28 02:27:05 --> Output Class Initialized
INFO - 2021-06-28 02:27:05 --> Security Class Initialized
DEBUG - 2021-06-28 02:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:27:05 --> Input Class Initialized
INFO - 2021-06-28 02:27:05 --> Language Class Initialized
INFO - 2021-06-28 02:27:05 --> Language Class Initialized
INFO - 2021-06-28 02:27:05 --> Config Class Initialized
INFO - 2021-06-28 02:27:05 --> Loader Class Initialized
INFO - 2021-06-28 02:27:05 --> Helper loaded: url_helper
INFO - 2021-06-28 02:27:05 --> Helper loaded: file_helper
INFO - 2021-06-28 02:27:05 --> Helper loaded: form_helper
INFO - 2021-06-28 02:27:05 --> Helper loaded: my_helper
INFO - 2021-06-28 02:27:05 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:27:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:27:05 --> Controller Class Initialized
INFO - 2021-06-28 02:27:05 --> Final output sent to browser
DEBUG - 2021-06-28 02:27:05 --> Total execution time: 0.0525
INFO - 2021-06-28 02:27:07 --> Config Class Initialized
INFO - 2021-06-28 02:27:07 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:27:07 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:27:07 --> Utf8 Class Initialized
INFO - 2021-06-28 02:27:07 --> URI Class Initialized
INFO - 2021-06-28 02:27:07 --> Router Class Initialized
INFO - 2021-06-28 02:27:07 --> Output Class Initialized
INFO - 2021-06-28 02:27:07 --> Security Class Initialized
DEBUG - 2021-06-28 02:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:27:07 --> Input Class Initialized
INFO - 2021-06-28 02:27:07 --> Language Class Initialized
INFO - 2021-06-28 02:27:07 --> Language Class Initialized
INFO - 2021-06-28 02:27:07 --> Config Class Initialized
INFO - 2021-06-28 02:27:07 --> Loader Class Initialized
INFO - 2021-06-28 02:27:07 --> Helper loaded: url_helper
INFO - 2021-06-28 02:27:07 --> Helper loaded: file_helper
INFO - 2021-06-28 02:27:07 --> Helper loaded: form_helper
INFO - 2021-06-28 02:27:07 --> Helper loaded: my_helper
INFO - 2021-06-28 02:27:07 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:27:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:27:07 --> Controller Class Initialized
INFO - 2021-06-28 02:27:07 --> Final output sent to browser
DEBUG - 2021-06-28 02:27:07 --> Total execution time: 0.0523
INFO - 2021-06-28 02:27:16 --> Config Class Initialized
INFO - 2021-06-28 02:27:16 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:27:16 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:27:16 --> Utf8 Class Initialized
INFO - 2021-06-28 02:27:16 --> URI Class Initialized
INFO - 2021-06-28 02:27:16 --> Router Class Initialized
INFO - 2021-06-28 02:27:16 --> Output Class Initialized
INFO - 2021-06-28 02:27:16 --> Security Class Initialized
DEBUG - 2021-06-28 02:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:27:16 --> Input Class Initialized
INFO - 2021-06-28 02:27:16 --> Language Class Initialized
INFO - 2021-06-28 02:27:16 --> Language Class Initialized
INFO - 2021-06-28 02:27:16 --> Config Class Initialized
INFO - 2021-06-28 02:27:16 --> Loader Class Initialized
INFO - 2021-06-28 02:27:16 --> Helper loaded: url_helper
INFO - 2021-06-28 02:27:16 --> Helper loaded: file_helper
INFO - 2021-06-28 02:27:16 --> Helper loaded: form_helper
INFO - 2021-06-28 02:27:16 --> Helper loaded: my_helper
INFO - 2021-06-28 02:27:16 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:27:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:27:16 --> Controller Class Initialized
INFO - 2021-06-28 02:27:17 --> Final output sent to browser
DEBUG - 2021-06-28 02:27:17 --> Total execution time: 1.0301
INFO - 2021-06-28 02:27:22 --> Config Class Initialized
INFO - 2021-06-28 02:27:22 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:27:22 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:27:22 --> Utf8 Class Initialized
INFO - 2021-06-28 02:27:22 --> URI Class Initialized
INFO - 2021-06-28 02:27:22 --> Router Class Initialized
INFO - 2021-06-28 02:27:22 --> Output Class Initialized
INFO - 2021-06-28 02:27:22 --> Security Class Initialized
DEBUG - 2021-06-28 02:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:27:22 --> Input Class Initialized
INFO - 2021-06-28 02:27:22 --> Language Class Initialized
INFO - 2021-06-28 02:27:22 --> Language Class Initialized
INFO - 2021-06-28 02:27:22 --> Config Class Initialized
INFO - 2021-06-28 02:27:22 --> Loader Class Initialized
INFO - 2021-06-28 02:27:22 --> Helper loaded: url_helper
INFO - 2021-06-28 02:27:22 --> Helper loaded: file_helper
INFO - 2021-06-28 02:27:22 --> Helper loaded: form_helper
INFO - 2021-06-28 02:27:22 --> Helper loaded: my_helper
INFO - 2021-06-28 02:27:22 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:27:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:27:22 --> Controller Class Initialized
DEBUG - 2021-06-28 02:27:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-28 02:27:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 02:27:22 --> Final output sent to browser
DEBUG - 2021-06-28 02:27:22 --> Total execution time: 0.0554
INFO - 2021-06-28 02:27:25 --> Config Class Initialized
INFO - 2021-06-28 02:27:25 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:27:25 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:27:25 --> Utf8 Class Initialized
INFO - 2021-06-28 02:27:25 --> URI Class Initialized
INFO - 2021-06-28 02:27:25 --> Router Class Initialized
INFO - 2021-06-28 02:27:25 --> Output Class Initialized
INFO - 2021-06-28 02:27:25 --> Security Class Initialized
DEBUG - 2021-06-28 02:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:27:25 --> Input Class Initialized
INFO - 2021-06-28 02:27:25 --> Language Class Initialized
INFO - 2021-06-28 02:27:25 --> Language Class Initialized
INFO - 2021-06-28 02:27:25 --> Config Class Initialized
INFO - 2021-06-28 02:27:25 --> Loader Class Initialized
INFO - 2021-06-28 02:27:25 --> Helper loaded: url_helper
INFO - 2021-06-28 02:27:25 --> Helper loaded: file_helper
INFO - 2021-06-28 02:27:25 --> Helper loaded: form_helper
INFO - 2021-06-28 02:27:25 --> Helper loaded: my_helper
INFO - 2021-06-28 02:27:25 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:27:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:27:25 --> Controller Class Initialized
DEBUG - 2021-06-28 02:27:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-28 02:27:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 02:27:25 --> Final output sent to browser
DEBUG - 2021-06-28 02:27:25 --> Total execution time: 0.0486
INFO - 2021-06-28 02:27:25 --> Config Class Initialized
INFO - 2021-06-28 02:27:25 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:27:25 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:27:25 --> Utf8 Class Initialized
INFO - 2021-06-28 02:27:25 --> URI Class Initialized
INFO - 2021-06-28 02:27:25 --> Router Class Initialized
INFO - 2021-06-28 02:27:25 --> Output Class Initialized
INFO - 2021-06-28 02:27:25 --> Security Class Initialized
DEBUG - 2021-06-28 02:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:27:25 --> Input Class Initialized
INFO - 2021-06-28 02:27:25 --> Language Class Initialized
INFO - 2021-06-28 02:27:25 --> Language Class Initialized
INFO - 2021-06-28 02:27:25 --> Config Class Initialized
INFO - 2021-06-28 02:27:25 --> Loader Class Initialized
INFO - 2021-06-28 02:27:25 --> Helper loaded: url_helper
INFO - 2021-06-28 02:27:25 --> Helper loaded: file_helper
INFO - 2021-06-28 02:27:25 --> Helper loaded: form_helper
INFO - 2021-06-28 02:27:25 --> Helper loaded: my_helper
INFO - 2021-06-28 02:27:25 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:27:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:27:26 --> Controller Class Initialized
INFO - 2021-06-28 02:27:28 --> Config Class Initialized
INFO - 2021-06-28 02:27:28 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:27:28 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:27:28 --> Utf8 Class Initialized
INFO - 2021-06-28 02:27:28 --> URI Class Initialized
INFO - 2021-06-28 02:27:29 --> Router Class Initialized
INFO - 2021-06-28 02:27:29 --> Output Class Initialized
INFO - 2021-06-28 02:27:29 --> Security Class Initialized
DEBUG - 2021-06-28 02:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:27:29 --> Input Class Initialized
INFO - 2021-06-28 02:27:29 --> Language Class Initialized
INFO - 2021-06-28 02:27:29 --> Language Class Initialized
INFO - 2021-06-28 02:27:29 --> Config Class Initialized
INFO - 2021-06-28 02:27:29 --> Loader Class Initialized
INFO - 2021-06-28 02:27:29 --> Helper loaded: url_helper
INFO - 2021-06-28 02:27:29 --> Helper loaded: file_helper
INFO - 2021-06-28 02:27:29 --> Helper loaded: form_helper
INFO - 2021-06-28 02:27:29 --> Helper loaded: my_helper
INFO - 2021-06-28 02:27:29 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:27:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:27:29 --> Controller Class Initialized
INFO - 2021-06-28 02:27:29 --> Final output sent to browser
DEBUG - 2021-06-28 02:27:29 --> Total execution time: 0.1163
INFO - 2021-06-28 02:27:35 --> Config Class Initialized
INFO - 2021-06-28 02:27:35 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:27:35 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:27:35 --> Utf8 Class Initialized
INFO - 2021-06-28 02:27:35 --> URI Class Initialized
INFO - 2021-06-28 02:27:35 --> Router Class Initialized
INFO - 2021-06-28 02:27:35 --> Output Class Initialized
INFO - 2021-06-28 02:27:35 --> Security Class Initialized
DEBUG - 2021-06-28 02:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:27:35 --> Input Class Initialized
INFO - 2021-06-28 02:27:35 --> Language Class Initialized
INFO - 2021-06-28 02:27:35 --> Language Class Initialized
INFO - 2021-06-28 02:27:35 --> Config Class Initialized
INFO - 2021-06-28 02:27:35 --> Loader Class Initialized
INFO - 2021-06-28 02:27:35 --> Helper loaded: url_helper
INFO - 2021-06-28 02:27:35 --> Helper loaded: file_helper
INFO - 2021-06-28 02:27:35 --> Helper loaded: form_helper
INFO - 2021-06-28 02:27:35 --> Helper loaded: my_helper
INFO - 2021-06-28 02:27:35 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:27:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:27:35 --> Controller Class Initialized
INFO - 2021-06-28 02:27:35 --> Final output sent to browser
DEBUG - 2021-06-28 02:27:35 --> Total execution time: 0.0430
INFO - 2021-06-28 02:27:37 --> Config Class Initialized
INFO - 2021-06-28 02:27:37 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:27:37 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:27:37 --> Utf8 Class Initialized
INFO - 2021-06-28 02:27:37 --> URI Class Initialized
INFO - 2021-06-28 02:27:37 --> Router Class Initialized
INFO - 2021-06-28 02:27:37 --> Output Class Initialized
INFO - 2021-06-28 02:27:37 --> Security Class Initialized
DEBUG - 2021-06-28 02:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:27:37 --> Input Class Initialized
INFO - 2021-06-28 02:27:37 --> Language Class Initialized
INFO - 2021-06-28 02:27:37 --> Language Class Initialized
INFO - 2021-06-28 02:27:37 --> Config Class Initialized
INFO - 2021-06-28 02:27:37 --> Loader Class Initialized
INFO - 2021-06-28 02:27:37 --> Helper loaded: url_helper
INFO - 2021-06-28 02:27:37 --> Helper loaded: file_helper
INFO - 2021-06-28 02:27:37 --> Helper loaded: form_helper
INFO - 2021-06-28 02:27:37 --> Helper loaded: my_helper
INFO - 2021-06-28 02:27:37 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:27:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:27:37 --> Controller Class Initialized
INFO - 2021-06-28 02:27:37 --> Final output sent to browser
DEBUG - 2021-06-28 02:27:37 --> Total execution time: 0.0515
INFO - 2021-06-28 02:27:39 --> Config Class Initialized
INFO - 2021-06-28 02:27:39 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:27:39 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:27:39 --> Utf8 Class Initialized
INFO - 2021-06-28 02:27:39 --> URI Class Initialized
INFO - 2021-06-28 02:27:39 --> Router Class Initialized
INFO - 2021-06-28 02:27:39 --> Output Class Initialized
INFO - 2021-06-28 02:27:39 --> Security Class Initialized
DEBUG - 2021-06-28 02:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:27:39 --> Input Class Initialized
INFO - 2021-06-28 02:27:39 --> Language Class Initialized
INFO - 2021-06-28 02:27:39 --> Language Class Initialized
INFO - 2021-06-28 02:27:39 --> Config Class Initialized
INFO - 2021-06-28 02:27:39 --> Loader Class Initialized
INFO - 2021-06-28 02:27:39 --> Helper loaded: url_helper
INFO - 2021-06-28 02:27:39 --> Helper loaded: file_helper
INFO - 2021-06-28 02:27:39 --> Helper loaded: form_helper
INFO - 2021-06-28 02:27:39 --> Helper loaded: my_helper
INFO - 2021-06-28 02:27:39 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:27:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:27:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:27:39 --> Controller Class Initialized
INFO - 2021-06-28 02:27:39 --> Final output sent to browser
DEBUG - 2021-06-28 02:27:39 --> Total execution time: 0.0638
INFO - 2021-06-28 02:27:41 --> Config Class Initialized
INFO - 2021-06-28 02:27:41 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:27:41 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:27:41 --> Utf8 Class Initialized
INFO - 2021-06-28 02:27:41 --> URI Class Initialized
INFO - 2021-06-28 02:27:41 --> Router Class Initialized
INFO - 2021-06-28 02:27:41 --> Output Class Initialized
INFO - 2021-06-28 02:27:41 --> Security Class Initialized
DEBUG - 2021-06-28 02:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:27:41 --> Input Class Initialized
INFO - 2021-06-28 02:27:41 --> Language Class Initialized
INFO - 2021-06-28 02:27:41 --> Language Class Initialized
INFO - 2021-06-28 02:27:41 --> Config Class Initialized
INFO - 2021-06-28 02:27:41 --> Loader Class Initialized
INFO - 2021-06-28 02:27:41 --> Helper loaded: url_helper
INFO - 2021-06-28 02:27:41 --> Helper loaded: file_helper
INFO - 2021-06-28 02:27:41 --> Helper loaded: form_helper
INFO - 2021-06-28 02:27:41 --> Helper loaded: my_helper
INFO - 2021-06-28 02:27:41 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:27:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:27:41 --> Controller Class Initialized
INFO - 2021-06-28 02:27:41 --> Final output sent to browser
DEBUG - 2021-06-28 02:27:41 --> Total execution time: 0.0507
INFO - 2021-06-28 02:27:52 --> Config Class Initialized
INFO - 2021-06-28 02:27:52 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:27:52 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:27:52 --> Utf8 Class Initialized
INFO - 2021-06-28 02:27:52 --> URI Class Initialized
INFO - 2021-06-28 02:27:52 --> Router Class Initialized
INFO - 2021-06-28 02:27:52 --> Output Class Initialized
INFO - 2021-06-28 02:27:52 --> Security Class Initialized
DEBUG - 2021-06-28 02:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:27:52 --> Input Class Initialized
INFO - 2021-06-28 02:27:52 --> Language Class Initialized
INFO - 2021-06-28 02:27:52 --> Language Class Initialized
INFO - 2021-06-28 02:27:52 --> Config Class Initialized
INFO - 2021-06-28 02:27:52 --> Loader Class Initialized
INFO - 2021-06-28 02:27:52 --> Helper loaded: url_helper
INFO - 2021-06-28 02:27:52 --> Helper loaded: file_helper
INFO - 2021-06-28 02:27:52 --> Helper loaded: form_helper
INFO - 2021-06-28 02:27:52 --> Helper loaded: my_helper
INFO - 2021-06-28 02:27:52 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:27:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:27:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:27:52 --> Controller Class Initialized
INFO - 2021-06-28 02:27:52 --> Helper loaded: cookie_helper
INFO - 2021-06-28 02:27:52 --> Config Class Initialized
INFO - 2021-06-28 02:27:52 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:27:52 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:27:52 --> Utf8 Class Initialized
INFO - 2021-06-28 02:27:52 --> URI Class Initialized
INFO - 2021-06-28 02:27:52 --> Router Class Initialized
INFO - 2021-06-28 02:27:52 --> Output Class Initialized
INFO - 2021-06-28 02:27:52 --> Security Class Initialized
DEBUG - 2021-06-28 02:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:27:52 --> Input Class Initialized
INFO - 2021-06-28 02:27:52 --> Language Class Initialized
INFO - 2021-06-28 02:27:52 --> Language Class Initialized
INFO - 2021-06-28 02:27:52 --> Config Class Initialized
INFO - 2021-06-28 02:27:52 --> Loader Class Initialized
INFO - 2021-06-28 02:27:52 --> Helper loaded: url_helper
INFO - 2021-06-28 02:27:52 --> Helper loaded: file_helper
INFO - 2021-06-28 02:27:52 --> Helper loaded: form_helper
INFO - 2021-06-28 02:27:52 --> Helper loaded: my_helper
INFO - 2021-06-28 02:27:52 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:27:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:27:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:27:52 --> Controller Class Initialized
DEBUG - 2021-06-28 02:27:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-28 02:27:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 02:27:52 --> Final output sent to browser
DEBUG - 2021-06-28 02:27:52 --> Total execution time: 0.0514
INFO - 2021-06-28 02:27:57 --> Config Class Initialized
INFO - 2021-06-28 02:27:57 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:27:57 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:27:57 --> Utf8 Class Initialized
INFO - 2021-06-28 02:27:57 --> URI Class Initialized
INFO - 2021-06-28 02:27:57 --> Router Class Initialized
INFO - 2021-06-28 02:27:57 --> Output Class Initialized
INFO - 2021-06-28 02:27:57 --> Security Class Initialized
DEBUG - 2021-06-28 02:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:27:57 --> Input Class Initialized
INFO - 2021-06-28 02:27:57 --> Language Class Initialized
INFO - 2021-06-28 02:27:57 --> Language Class Initialized
INFO - 2021-06-28 02:27:57 --> Config Class Initialized
INFO - 2021-06-28 02:27:57 --> Loader Class Initialized
INFO - 2021-06-28 02:27:57 --> Helper loaded: url_helper
INFO - 2021-06-28 02:27:57 --> Helper loaded: file_helper
INFO - 2021-06-28 02:27:57 --> Helper loaded: form_helper
INFO - 2021-06-28 02:27:57 --> Helper loaded: my_helper
INFO - 2021-06-28 02:27:57 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:27:57 --> Controller Class Initialized
INFO - 2021-06-28 02:27:57 --> Helper loaded: cookie_helper
INFO - 2021-06-28 02:27:57 --> Final output sent to browser
DEBUG - 2021-06-28 02:27:57 --> Total execution time: 0.0531
INFO - 2021-06-28 02:27:58 --> Config Class Initialized
INFO - 2021-06-28 02:27:58 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:27:58 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:27:58 --> Utf8 Class Initialized
INFO - 2021-06-28 02:27:58 --> URI Class Initialized
INFO - 2021-06-28 02:27:58 --> Router Class Initialized
INFO - 2021-06-28 02:27:58 --> Output Class Initialized
INFO - 2021-06-28 02:27:58 --> Security Class Initialized
DEBUG - 2021-06-28 02:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:27:58 --> Input Class Initialized
INFO - 2021-06-28 02:27:58 --> Language Class Initialized
INFO - 2021-06-28 02:27:58 --> Language Class Initialized
INFO - 2021-06-28 02:27:58 --> Config Class Initialized
INFO - 2021-06-28 02:27:58 --> Loader Class Initialized
INFO - 2021-06-28 02:27:58 --> Helper loaded: url_helper
INFO - 2021-06-28 02:27:58 --> Helper loaded: file_helper
INFO - 2021-06-28 02:27:58 --> Helper loaded: form_helper
INFO - 2021-06-28 02:27:58 --> Helper loaded: my_helper
INFO - 2021-06-28 02:27:58 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:27:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:27:58 --> Controller Class Initialized
DEBUG - 2021-06-28 02:27:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-28 02:27:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 02:27:59 --> Final output sent to browser
DEBUG - 2021-06-28 02:27:59 --> Total execution time: 0.6645
INFO - 2021-06-28 02:28:05 --> Config Class Initialized
INFO - 2021-06-28 02:28:05 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:28:05 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:28:05 --> Utf8 Class Initialized
INFO - 2021-06-28 02:28:05 --> URI Class Initialized
INFO - 2021-06-28 02:28:05 --> Router Class Initialized
INFO - 2021-06-28 02:28:05 --> Output Class Initialized
INFO - 2021-06-28 02:28:05 --> Security Class Initialized
DEBUG - 2021-06-28 02:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:28:05 --> Input Class Initialized
INFO - 2021-06-28 02:28:05 --> Language Class Initialized
INFO - 2021-06-28 02:28:05 --> Language Class Initialized
INFO - 2021-06-28 02:28:05 --> Config Class Initialized
INFO - 2021-06-28 02:28:05 --> Loader Class Initialized
INFO - 2021-06-28 02:28:05 --> Helper loaded: url_helper
INFO - 2021-06-28 02:28:05 --> Helper loaded: file_helper
INFO - 2021-06-28 02:28:05 --> Helper loaded: form_helper
INFO - 2021-06-28 02:28:05 --> Helper loaded: my_helper
INFO - 2021-06-28 02:28:05 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:28:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:28:05 --> Controller Class Initialized
DEBUG - 2021-06-28 02:28:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-06-28 02:28:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 02:28:05 --> Final output sent to browser
DEBUG - 2021-06-28 02:28:05 --> Total execution time: 0.0626
INFO - 2021-06-28 02:28:08 --> Config Class Initialized
INFO - 2021-06-28 02:28:08 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:28:08 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:28:08 --> Utf8 Class Initialized
INFO - 2021-06-28 02:28:08 --> URI Class Initialized
INFO - 2021-06-28 02:28:08 --> Router Class Initialized
INFO - 2021-06-28 02:28:08 --> Output Class Initialized
INFO - 2021-06-28 02:28:08 --> Security Class Initialized
DEBUG - 2021-06-28 02:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:28:08 --> Input Class Initialized
INFO - 2021-06-28 02:28:08 --> Language Class Initialized
INFO - 2021-06-28 02:28:08 --> Language Class Initialized
INFO - 2021-06-28 02:28:08 --> Config Class Initialized
INFO - 2021-06-28 02:28:08 --> Loader Class Initialized
INFO - 2021-06-28 02:28:08 --> Helper loaded: url_helper
INFO - 2021-06-28 02:28:08 --> Helper loaded: file_helper
INFO - 2021-06-28 02:28:08 --> Helper loaded: form_helper
INFO - 2021-06-28 02:28:08 --> Helper loaded: my_helper
INFO - 2021-06-28 02:28:08 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:28:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:28:08 --> Controller Class Initialized
DEBUG - 2021-06-28 02:28:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tki.php
INFO - 2021-06-28 02:28:09 --> Final output sent to browser
DEBUG - 2021-06-28 02:28:09 --> Total execution time: 0.2852
INFO - 2021-06-28 02:28:20 --> Config Class Initialized
INFO - 2021-06-28 02:28:20 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:28:20 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:28:20 --> Utf8 Class Initialized
INFO - 2021-06-28 02:28:20 --> URI Class Initialized
INFO - 2021-06-28 02:28:20 --> Router Class Initialized
INFO - 2021-06-28 02:28:20 --> Output Class Initialized
INFO - 2021-06-28 02:28:20 --> Security Class Initialized
DEBUG - 2021-06-28 02:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:28:20 --> Input Class Initialized
INFO - 2021-06-28 02:28:20 --> Language Class Initialized
INFO - 2021-06-28 02:28:20 --> Language Class Initialized
INFO - 2021-06-28 02:28:20 --> Config Class Initialized
INFO - 2021-06-28 02:28:20 --> Loader Class Initialized
INFO - 2021-06-28 02:28:20 --> Helper loaded: url_helper
INFO - 2021-06-28 02:28:20 --> Helper loaded: file_helper
INFO - 2021-06-28 02:28:20 --> Helper loaded: form_helper
INFO - 2021-06-28 02:28:20 --> Helper loaded: my_helper
INFO - 2021-06-28 02:28:20 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:28:20 --> Controller Class Initialized
INFO - 2021-06-28 02:28:20 --> Helper loaded: cookie_helper
INFO - 2021-06-28 02:28:20 --> Config Class Initialized
INFO - 2021-06-28 02:28:20 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:28:20 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:28:20 --> Utf8 Class Initialized
INFO - 2021-06-28 02:28:20 --> URI Class Initialized
INFO - 2021-06-28 02:28:20 --> Router Class Initialized
INFO - 2021-06-28 02:28:20 --> Output Class Initialized
INFO - 2021-06-28 02:28:20 --> Security Class Initialized
DEBUG - 2021-06-28 02:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:28:20 --> Input Class Initialized
INFO - 2021-06-28 02:28:20 --> Language Class Initialized
INFO - 2021-06-28 02:28:20 --> Language Class Initialized
INFO - 2021-06-28 02:28:20 --> Config Class Initialized
INFO - 2021-06-28 02:28:20 --> Loader Class Initialized
INFO - 2021-06-28 02:28:20 --> Helper loaded: url_helper
INFO - 2021-06-28 02:28:20 --> Helper loaded: file_helper
INFO - 2021-06-28 02:28:20 --> Helper loaded: form_helper
INFO - 2021-06-28 02:28:20 --> Helper loaded: my_helper
INFO - 2021-06-28 02:28:20 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:28:20 --> Controller Class Initialized
DEBUG - 2021-06-28 02:28:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-28 02:28:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 02:28:20 --> Final output sent to browser
DEBUG - 2021-06-28 02:28:20 --> Total execution time: 0.0533
INFO - 2021-06-28 02:28:28 --> Config Class Initialized
INFO - 2021-06-28 02:28:28 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:28:28 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:28:28 --> Utf8 Class Initialized
INFO - 2021-06-28 02:28:28 --> URI Class Initialized
INFO - 2021-06-28 02:28:28 --> Router Class Initialized
INFO - 2021-06-28 02:28:28 --> Output Class Initialized
INFO - 2021-06-28 02:28:28 --> Security Class Initialized
DEBUG - 2021-06-28 02:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:28:28 --> Input Class Initialized
INFO - 2021-06-28 02:28:28 --> Language Class Initialized
INFO - 2021-06-28 02:28:28 --> Language Class Initialized
INFO - 2021-06-28 02:28:28 --> Config Class Initialized
INFO - 2021-06-28 02:28:28 --> Loader Class Initialized
INFO - 2021-06-28 02:28:28 --> Helper loaded: url_helper
INFO - 2021-06-28 02:28:28 --> Helper loaded: file_helper
INFO - 2021-06-28 02:28:28 --> Helper loaded: form_helper
INFO - 2021-06-28 02:28:28 --> Helper loaded: my_helper
INFO - 2021-06-28 02:28:28 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:28:28 --> Controller Class Initialized
INFO - 2021-06-28 02:28:28 --> Helper loaded: cookie_helper
INFO - 2021-06-28 02:28:28 --> Final output sent to browser
DEBUG - 2021-06-28 02:28:28 --> Total execution time: 0.0556
INFO - 2021-06-28 02:28:29 --> Config Class Initialized
INFO - 2021-06-28 02:28:29 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:28:29 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:28:29 --> Utf8 Class Initialized
INFO - 2021-06-28 02:28:29 --> URI Class Initialized
INFO - 2021-06-28 02:28:29 --> Router Class Initialized
INFO - 2021-06-28 02:28:29 --> Output Class Initialized
INFO - 2021-06-28 02:28:29 --> Security Class Initialized
DEBUG - 2021-06-28 02:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:28:29 --> Input Class Initialized
INFO - 2021-06-28 02:28:29 --> Language Class Initialized
INFO - 2021-06-28 02:28:29 --> Language Class Initialized
INFO - 2021-06-28 02:28:29 --> Config Class Initialized
INFO - 2021-06-28 02:28:29 --> Loader Class Initialized
INFO - 2021-06-28 02:28:29 --> Helper loaded: url_helper
INFO - 2021-06-28 02:28:29 --> Helper loaded: file_helper
INFO - 2021-06-28 02:28:29 --> Helper loaded: form_helper
INFO - 2021-06-28 02:28:29 --> Helper loaded: my_helper
INFO - 2021-06-28 02:28:29 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:28:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:28:29 --> Controller Class Initialized
DEBUG - 2021-06-28 02:28:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-28 02:28:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 02:28:29 --> Final output sent to browser
DEBUG - 2021-06-28 02:28:29 --> Total execution time: 0.6517
INFO - 2021-06-28 02:28:32 --> Config Class Initialized
INFO - 2021-06-28 02:28:32 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:28:32 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:28:32 --> Utf8 Class Initialized
INFO - 2021-06-28 02:28:32 --> URI Class Initialized
INFO - 2021-06-28 02:28:32 --> Router Class Initialized
INFO - 2021-06-28 02:28:32 --> Output Class Initialized
INFO - 2021-06-28 02:28:32 --> Security Class Initialized
DEBUG - 2021-06-28 02:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:28:32 --> Input Class Initialized
INFO - 2021-06-28 02:28:32 --> Language Class Initialized
INFO - 2021-06-28 02:28:32 --> Language Class Initialized
INFO - 2021-06-28 02:28:32 --> Config Class Initialized
INFO - 2021-06-28 02:28:32 --> Loader Class Initialized
INFO - 2021-06-28 02:28:32 --> Helper loaded: url_helper
INFO - 2021-06-28 02:28:32 --> Helper loaded: file_helper
INFO - 2021-06-28 02:28:32 --> Helper loaded: form_helper
INFO - 2021-06-28 02:28:32 --> Helper loaded: my_helper
INFO - 2021-06-28 02:28:32 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:28:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:28:32 --> Controller Class Initialized
DEBUG - 2021-06-28 02:28:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-06-28 02:28:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 02:28:32 --> Final output sent to browser
DEBUG - 2021-06-28 02:28:32 --> Total execution time: 0.0639
INFO - 2021-06-28 02:28:39 --> Config Class Initialized
INFO - 2021-06-28 02:28:39 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:28:39 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:28:39 --> Utf8 Class Initialized
INFO - 2021-06-28 02:28:40 --> URI Class Initialized
INFO - 2021-06-28 02:28:40 --> Router Class Initialized
INFO - 2021-06-28 02:28:40 --> Output Class Initialized
INFO - 2021-06-28 02:28:40 --> Security Class Initialized
DEBUG - 2021-06-28 02:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:28:40 --> Input Class Initialized
INFO - 2021-06-28 02:28:40 --> Language Class Initialized
INFO - 2021-06-28 02:28:40 --> Language Class Initialized
INFO - 2021-06-28 02:28:40 --> Config Class Initialized
INFO - 2021-06-28 02:28:40 --> Loader Class Initialized
INFO - 2021-06-28 02:28:40 --> Helper loaded: url_helper
INFO - 2021-06-28 02:28:40 --> Helper loaded: file_helper
INFO - 2021-06-28 02:28:40 --> Helper loaded: form_helper
INFO - 2021-06-28 02:28:40 --> Helper loaded: my_helper
INFO - 2021-06-28 02:28:40 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:28:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:28:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:28:40 --> Controller Class Initialized
DEBUG - 2021-06-28 02:28:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-06-28 02:28:40 --> Final output sent to browser
DEBUG - 2021-06-28 02:28:40 --> Total execution time: 0.3248
INFO - 2021-06-28 02:28:51 --> Config Class Initialized
INFO - 2021-06-28 02:28:51 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:28:51 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:28:51 --> Utf8 Class Initialized
INFO - 2021-06-28 02:28:51 --> URI Class Initialized
INFO - 2021-06-28 02:28:51 --> Router Class Initialized
INFO - 2021-06-28 02:28:51 --> Output Class Initialized
INFO - 2021-06-28 02:28:51 --> Security Class Initialized
DEBUG - 2021-06-28 02:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:28:51 --> Input Class Initialized
INFO - 2021-06-28 02:28:51 --> Language Class Initialized
INFO - 2021-06-28 02:28:51 --> Language Class Initialized
INFO - 2021-06-28 02:28:51 --> Config Class Initialized
INFO - 2021-06-28 02:28:51 --> Loader Class Initialized
INFO - 2021-06-28 02:28:51 --> Helper loaded: url_helper
INFO - 2021-06-28 02:28:51 --> Helper loaded: file_helper
INFO - 2021-06-28 02:28:51 --> Helper loaded: form_helper
INFO - 2021-06-28 02:28:51 --> Helper loaded: my_helper
INFO - 2021-06-28 02:28:51 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:28:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:28:51 --> Controller Class Initialized
DEBUG - 2021-06-28 02:28:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-06-28 02:28:51 --> Final output sent to browser
DEBUG - 2021-06-28 02:28:51 --> Total execution time: 0.1933
INFO - 2021-06-28 02:30:34 --> Config Class Initialized
INFO - 2021-06-28 02:30:34 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:30:34 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:30:34 --> Utf8 Class Initialized
INFO - 2021-06-28 02:30:34 --> URI Class Initialized
INFO - 2021-06-28 02:30:34 --> Router Class Initialized
INFO - 2021-06-28 02:30:34 --> Output Class Initialized
INFO - 2021-06-28 02:30:34 --> Security Class Initialized
DEBUG - 2021-06-28 02:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:30:34 --> Input Class Initialized
INFO - 2021-06-28 02:30:34 --> Language Class Initialized
INFO - 2021-06-28 02:30:34 --> Language Class Initialized
INFO - 2021-06-28 02:30:34 --> Config Class Initialized
INFO - 2021-06-28 02:30:34 --> Loader Class Initialized
INFO - 2021-06-28 02:30:34 --> Helper loaded: url_helper
INFO - 2021-06-28 02:30:34 --> Helper loaded: file_helper
INFO - 2021-06-28 02:30:34 --> Helper loaded: form_helper
INFO - 2021-06-28 02:30:34 --> Helper loaded: my_helper
INFO - 2021-06-28 02:30:34 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:30:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:30:34 --> Controller Class Initialized
INFO - 2021-06-28 02:30:34 --> Helper loaded: cookie_helper
INFO - 2021-06-28 02:30:34 --> Config Class Initialized
INFO - 2021-06-28 02:30:34 --> Hooks Class Initialized
DEBUG - 2021-06-28 02:30:34 --> UTF-8 Support Enabled
INFO - 2021-06-28 02:30:34 --> Utf8 Class Initialized
INFO - 2021-06-28 02:30:34 --> URI Class Initialized
INFO - 2021-06-28 02:30:34 --> Router Class Initialized
INFO - 2021-06-28 02:30:34 --> Output Class Initialized
INFO - 2021-06-28 02:30:34 --> Security Class Initialized
DEBUG - 2021-06-28 02:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 02:30:34 --> Input Class Initialized
INFO - 2021-06-28 02:30:34 --> Language Class Initialized
INFO - 2021-06-28 02:30:34 --> Language Class Initialized
INFO - 2021-06-28 02:30:34 --> Config Class Initialized
INFO - 2021-06-28 02:30:34 --> Loader Class Initialized
INFO - 2021-06-28 02:30:34 --> Helper loaded: url_helper
INFO - 2021-06-28 02:30:34 --> Helper loaded: file_helper
INFO - 2021-06-28 02:30:34 --> Helper loaded: form_helper
INFO - 2021-06-28 02:30:34 --> Helper loaded: my_helper
INFO - 2021-06-28 02:30:34 --> Database Driver Class Initialized
DEBUG - 2021-06-28 02:30:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 02:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 02:30:34 --> Controller Class Initialized
DEBUG - 2021-06-28 02:30:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-28 02:30:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 02:30:34 --> Final output sent to browser
DEBUG - 2021-06-28 02:30:34 --> Total execution time: 0.0511
INFO - 2021-06-28 03:05:07 --> Config Class Initialized
INFO - 2021-06-28 03:05:07 --> Hooks Class Initialized
DEBUG - 2021-06-28 03:05:07 --> UTF-8 Support Enabled
INFO - 2021-06-28 03:05:07 --> Utf8 Class Initialized
INFO - 2021-06-28 03:05:07 --> URI Class Initialized
DEBUG - 2021-06-28 03:05:07 --> No URI present. Default controller set.
INFO - 2021-06-28 03:05:07 --> Router Class Initialized
INFO - 2021-06-28 03:05:07 --> Output Class Initialized
INFO - 2021-06-28 03:05:07 --> Security Class Initialized
DEBUG - 2021-06-28 03:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 03:05:07 --> Input Class Initialized
INFO - 2021-06-28 03:05:07 --> Language Class Initialized
INFO - 2021-06-28 03:05:07 --> Language Class Initialized
INFO - 2021-06-28 03:05:07 --> Config Class Initialized
INFO - 2021-06-28 03:05:07 --> Loader Class Initialized
INFO - 2021-06-28 03:05:07 --> Helper loaded: url_helper
INFO - 2021-06-28 03:05:07 --> Helper loaded: file_helper
INFO - 2021-06-28 03:05:07 --> Helper loaded: form_helper
INFO - 2021-06-28 03:05:07 --> Helper loaded: my_helper
INFO - 2021-06-28 03:05:07 --> Database Driver Class Initialized
DEBUG - 2021-06-28 03:05:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 03:05:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 03:05:07 --> Controller Class Initialized
INFO - 2021-06-28 03:05:07 --> Config Class Initialized
INFO - 2021-06-28 03:05:07 --> Hooks Class Initialized
DEBUG - 2021-06-28 03:05:07 --> UTF-8 Support Enabled
INFO - 2021-06-28 03:05:07 --> Utf8 Class Initialized
INFO - 2021-06-28 03:05:07 --> URI Class Initialized
INFO - 2021-06-28 03:05:07 --> Router Class Initialized
INFO - 2021-06-28 03:05:07 --> Output Class Initialized
INFO - 2021-06-28 03:05:07 --> Security Class Initialized
DEBUG - 2021-06-28 03:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 03:05:07 --> Input Class Initialized
INFO - 2021-06-28 03:05:07 --> Language Class Initialized
INFO - 2021-06-28 03:05:07 --> Language Class Initialized
INFO - 2021-06-28 03:05:07 --> Config Class Initialized
INFO - 2021-06-28 03:05:07 --> Loader Class Initialized
INFO - 2021-06-28 03:05:07 --> Helper loaded: url_helper
INFO - 2021-06-28 03:05:07 --> Helper loaded: file_helper
INFO - 2021-06-28 03:05:07 --> Helper loaded: form_helper
INFO - 2021-06-28 03:05:07 --> Helper loaded: my_helper
INFO - 2021-06-28 03:05:07 --> Database Driver Class Initialized
DEBUG - 2021-06-28 03:05:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 03:05:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 03:05:07 --> Controller Class Initialized
DEBUG - 2021-06-28 03:05:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-28 03:05:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 03:05:07 --> Final output sent to browser
DEBUG - 2021-06-28 03:05:07 --> Total execution time: 0.0411
INFO - 2021-06-28 03:05:21 --> Config Class Initialized
INFO - 2021-06-28 03:05:21 --> Hooks Class Initialized
DEBUG - 2021-06-28 03:05:21 --> UTF-8 Support Enabled
INFO - 2021-06-28 03:05:21 --> Utf8 Class Initialized
INFO - 2021-06-28 03:05:21 --> URI Class Initialized
INFO - 2021-06-28 03:05:21 --> Router Class Initialized
INFO - 2021-06-28 03:05:21 --> Output Class Initialized
INFO - 2021-06-28 03:05:21 --> Security Class Initialized
DEBUG - 2021-06-28 03:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 03:05:21 --> Input Class Initialized
INFO - 2021-06-28 03:05:21 --> Language Class Initialized
INFO - 2021-06-28 03:05:21 --> Language Class Initialized
INFO - 2021-06-28 03:05:21 --> Config Class Initialized
INFO - 2021-06-28 03:05:21 --> Loader Class Initialized
INFO - 2021-06-28 03:05:21 --> Helper loaded: url_helper
INFO - 2021-06-28 03:05:21 --> Helper loaded: file_helper
INFO - 2021-06-28 03:05:21 --> Helper loaded: form_helper
INFO - 2021-06-28 03:05:21 --> Helper loaded: my_helper
INFO - 2021-06-28 03:05:21 --> Database Driver Class Initialized
DEBUG - 2021-06-28 03:05:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 03:05:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 03:05:21 --> Controller Class Initialized
INFO - 2021-06-28 03:05:21 --> Helper loaded: cookie_helper
INFO - 2021-06-28 03:05:21 --> Final output sent to browser
DEBUG - 2021-06-28 03:05:21 --> Total execution time: 0.0584
INFO - 2021-06-28 03:05:22 --> Config Class Initialized
INFO - 2021-06-28 03:05:22 --> Hooks Class Initialized
DEBUG - 2021-06-28 03:05:22 --> UTF-8 Support Enabled
INFO - 2021-06-28 03:05:22 --> Utf8 Class Initialized
INFO - 2021-06-28 03:05:22 --> URI Class Initialized
INFO - 2021-06-28 03:05:22 --> Router Class Initialized
INFO - 2021-06-28 03:05:22 --> Output Class Initialized
INFO - 2021-06-28 03:05:22 --> Security Class Initialized
DEBUG - 2021-06-28 03:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 03:05:22 --> Input Class Initialized
INFO - 2021-06-28 03:05:22 --> Language Class Initialized
INFO - 2021-06-28 03:05:22 --> Language Class Initialized
INFO - 2021-06-28 03:05:22 --> Config Class Initialized
INFO - 2021-06-28 03:05:22 --> Loader Class Initialized
INFO - 2021-06-28 03:05:22 --> Helper loaded: url_helper
INFO - 2021-06-28 03:05:22 --> Helper loaded: file_helper
INFO - 2021-06-28 03:05:22 --> Helper loaded: form_helper
INFO - 2021-06-28 03:05:22 --> Helper loaded: my_helper
INFO - 2021-06-28 03:05:22 --> Database Driver Class Initialized
DEBUG - 2021-06-28 03:05:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 03:05:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 03:05:22 --> Controller Class Initialized
DEBUG - 2021-06-28 03:05:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-28 03:05:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 03:05:23 --> Final output sent to browser
DEBUG - 2021-06-28 03:05:23 --> Total execution time: 0.6638
INFO - 2021-06-28 03:05:41 --> Config Class Initialized
INFO - 2021-06-28 03:05:41 --> Hooks Class Initialized
DEBUG - 2021-06-28 03:05:41 --> UTF-8 Support Enabled
INFO - 2021-06-28 03:05:41 --> Utf8 Class Initialized
INFO - 2021-06-28 03:05:41 --> URI Class Initialized
INFO - 2021-06-28 03:05:41 --> Router Class Initialized
INFO - 2021-06-28 03:05:41 --> Output Class Initialized
INFO - 2021-06-28 03:05:41 --> Security Class Initialized
DEBUG - 2021-06-28 03:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 03:05:41 --> Input Class Initialized
INFO - 2021-06-28 03:05:41 --> Language Class Initialized
INFO - 2021-06-28 03:05:41 --> Language Class Initialized
INFO - 2021-06-28 03:05:41 --> Config Class Initialized
INFO - 2021-06-28 03:05:41 --> Loader Class Initialized
INFO - 2021-06-28 03:05:41 --> Helper loaded: url_helper
INFO - 2021-06-28 03:05:41 --> Helper loaded: file_helper
INFO - 2021-06-28 03:05:41 --> Helper loaded: form_helper
INFO - 2021-06-28 03:05:41 --> Helper loaded: my_helper
INFO - 2021-06-28 03:05:41 --> Database Driver Class Initialized
DEBUG - 2021-06-28 03:05:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 03:05:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 03:05:41 --> Controller Class Initialized
DEBUG - 2021-06-28 03:05:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2021-06-28 03:05:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 03:05:41 --> Final output sent to browser
DEBUG - 2021-06-28 03:05:41 --> Total execution time: 0.0727
INFO - 2021-06-28 03:05:41 --> Config Class Initialized
INFO - 2021-06-28 03:05:41 --> Hooks Class Initialized
DEBUG - 2021-06-28 03:05:41 --> UTF-8 Support Enabled
INFO - 2021-06-28 03:05:41 --> Utf8 Class Initialized
INFO - 2021-06-28 03:05:41 --> URI Class Initialized
INFO - 2021-06-28 03:05:41 --> Router Class Initialized
INFO - 2021-06-28 03:05:41 --> Output Class Initialized
INFO - 2021-06-28 03:05:41 --> Security Class Initialized
DEBUG - 2021-06-28 03:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 03:05:41 --> Input Class Initialized
INFO - 2021-06-28 03:05:41 --> Language Class Initialized
INFO - 2021-06-28 03:05:41 --> Language Class Initialized
INFO - 2021-06-28 03:05:41 --> Config Class Initialized
INFO - 2021-06-28 03:05:41 --> Loader Class Initialized
INFO - 2021-06-28 03:05:41 --> Helper loaded: url_helper
INFO - 2021-06-28 03:05:41 --> Helper loaded: file_helper
INFO - 2021-06-28 03:05:41 --> Helper loaded: form_helper
INFO - 2021-06-28 03:05:41 --> Helper loaded: my_helper
INFO - 2021-06-28 03:05:41 --> Database Driver Class Initialized
DEBUG - 2021-06-28 03:05:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 03:05:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 03:05:41 --> Controller Class Initialized
INFO - 2021-06-28 03:05:44 --> Config Class Initialized
INFO - 2021-06-28 03:05:44 --> Hooks Class Initialized
DEBUG - 2021-06-28 03:05:44 --> UTF-8 Support Enabled
INFO - 2021-06-28 03:05:44 --> Utf8 Class Initialized
INFO - 2021-06-28 03:05:44 --> URI Class Initialized
INFO - 2021-06-28 03:05:44 --> Router Class Initialized
INFO - 2021-06-28 03:05:44 --> Output Class Initialized
INFO - 2021-06-28 03:05:44 --> Security Class Initialized
DEBUG - 2021-06-28 03:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 03:05:44 --> Input Class Initialized
INFO - 2021-06-28 03:05:44 --> Language Class Initialized
INFO - 2021-06-28 03:05:44 --> Language Class Initialized
INFO - 2021-06-28 03:05:44 --> Config Class Initialized
INFO - 2021-06-28 03:05:44 --> Loader Class Initialized
INFO - 2021-06-28 03:05:44 --> Helper loaded: url_helper
INFO - 2021-06-28 03:05:44 --> Helper loaded: file_helper
INFO - 2021-06-28 03:05:44 --> Helper loaded: form_helper
INFO - 2021-06-28 03:05:44 --> Helper loaded: my_helper
INFO - 2021-06-28 03:05:44 --> Database Driver Class Initialized
DEBUG - 2021-06-28 03:05:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 03:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 03:05:44 --> Controller Class Initialized
INFO - 2021-06-28 03:05:44 --> Helper loaded: cookie_helper
INFO - 2021-06-28 03:05:44 --> Config Class Initialized
INFO - 2021-06-28 03:05:44 --> Hooks Class Initialized
DEBUG - 2021-06-28 03:05:44 --> UTF-8 Support Enabled
INFO - 2021-06-28 03:05:44 --> Utf8 Class Initialized
INFO - 2021-06-28 03:05:44 --> URI Class Initialized
INFO - 2021-06-28 03:05:44 --> Router Class Initialized
INFO - 2021-06-28 03:05:44 --> Output Class Initialized
INFO - 2021-06-28 03:05:44 --> Security Class Initialized
DEBUG - 2021-06-28 03:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 03:05:44 --> Input Class Initialized
INFO - 2021-06-28 03:05:44 --> Language Class Initialized
INFO - 2021-06-28 03:05:44 --> Language Class Initialized
INFO - 2021-06-28 03:05:44 --> Config Class Initialized
INFO - 2021-06-28 03:05:44 --> Loader Class Initialized
INFO - 2021-06-28 03:05:44 --> Helper loaded: url_helper
INFO - 2021-06-28 03:05:44 --> Helper loaded: file_helper
INFO - 2021-06-28 03:05:44 --> Helper loaded: form_helper
INFO - 2021-06-28 03:05:44 --> Helper loaded: my_helper
INFO - 2021-06-28 03:05:44 --> Database Driver Class Initialized
DEBUG - 2021-06-28 03:05:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 03:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 03:05:44 --> Controller Class Initialized
DEBUG - 2021-06-28 03:05:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-28 03:05:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 03:05:44 --> Final output sent to browser
DEBUG - 2021-06-28 03:05:44 --> Total execution time: 0.0487
INFO - 2021-06-28 03:05:54 --> Config Class Initialized
INFO - 2021-06-28 03:05:54 --> Hooks Class Initialized
DEBUG - 2021-06-28 03:05:54 --> UTF-8 Support Enabled
INFO - 2021-06-28 03:05:54 --> Utf8 Class Initialized
INFO - 2021-06-28 03:05:54 --> URI Class Initialized
INFO - 2021-06-28 03:05:54 --> Router Class Initialized
INFO - 2021-06-28 03:05:54 --> Output Class Initialized
INFO - 2021-06-28 03:05:54 --> Security Class Initialized
DEBUG - 2021-06-28 03:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 03:05:54 --> Input Class Initialized
INFO - 2021-06-28 03:05:54 --> Language Class Initialized
INFO - 2021-06-28 03:05:54 --> Language Class Initialized
INFO - 2021-06-28 03:05:54 --> Config Class Initialized
INFO - 2021-06-28 03:05:54 --> Loader Class Initialized
INFO - 2021-06-28 03:05:54 --> Helper loaded: url_helper
INFO - 2021-06-28 03:05:54 --> Helper loaded: file_helper
INFO - 2021-06-28 03:05:54 --> Helper loaded: form_helper
INFO - 2021-06-28 03:05:54 --> Helper loaded: my_helper
INFO - 2021-06-28 03:05:54 --> Database Driver Class Initialized
DEBUG - 2021-06-28 03:05:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 03:05:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 03:05:54 --> Controller Class Initialized
INFO - 2021-06-28 03:05:54 --> Helper loaded: cookie_helper
INFO - 2021-06-28 03:05:54 --> Final output sent to browser
DEBUG - 2021-06-28 03:05:54 --> Total execution time: 0.0525
INFO - 2021-06-28 03:05:55 --> Config Class Initialized
INFO - 2021-06-28 03:05:55 --> Hooks Class Initialized
DEBUG - 2021-06-28 03:05:55 --> UTF-8 Support Enabled
INFO - 2021-06-28 03:05:55 --> Utf8 Class Initialized
INFO - 2021-06-28 03:05:55 --> URI Class Initialized
INFO - 2021-06-28 03:05:55 --> Router Class Initialized
INFO - 2021-06-28 03:05:55 --> Output Class Initialized
INFO - 2021-06-28 03:05:55 --> Security Class Initialized
DEBUG - 2021-06-28 03:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 03:05:55 --> Input Class Initialized
INFO - 2021-06-28 03:05:55 --> Language Class Initialized
INFO - 2021-06-28 03:05:55 --> Language Class Initialized
INFO - 2021-06-28 03:05:55 --> Config Class Initialized
INFO - 2021-06-28 03:05:55 --> Loader Class Initialized
INFO - 2021-06-28 03:05:55 --> Helper loaded: url_helper
INFO - 2021-06-28 03:05:55 --> Helper loaded: file_helper
INFO - 2021-06-28 03:05:55 --> Helper loaded: form_helper
INFO - 2021-06-28 03:05:55 --> Helper loaded: my_helper
INFO - 2021-06-28 03:05:55 --> Database Driver Class Initialized
DEBUG - 2021-06-28 03:05:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 03:05:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 03:05:55 --> Controller Class Initialized
DEBUG - 2021-06-28 03:05:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-28 03:05:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 03:05:55 --> Final output sent to browser
DEBUG - 2021-06-28 03:05:55 --> Total execution time: 0.6129
INFO - 2021-06-28 03:05:57 --> Config Class Initialized
INFO - 2021-06-28 03:05:57 --> Hooks Class Initialized
DEBUG - 2021-06-28 03:05:57 --> UTF-8 Support Enabled
INFO - 2021-06-28 03:05:57 --> Utf8 Class Initialized
INFO - 2021-06-28 03:05:57 --> URI Class Initialized
INFO - 2021-06-28 03:05:57 --> Router Class Initialized
INFO - 2021-06-28 03:05:57 --> Output Class Initialized
INFO - 2021-06-28 03:05:57 --> Security Class Initialized
DEBUG - 2021-06-28 03:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 03:05:57 --> Input Class Initialized
INFO - 2021-06-28 03:05:57 --> Language Class Initialized
INFO - 2021-06-28 03:05:57 --> Language Class Initialized
INFO - 2021-06-28 03:05:57 --> Config Class Initialized
INFO - 2021-06-28 03:05:57 --> Loader Class Initialized
INFO - 2021-06-28 03:05:57 --> Helper loaded: url_helper
INFO - 2021-06-28 03:05:57 --> Helper loaded: file_helper
INFO - 2021-06-28 03:05:57 --> Helper loaded: form_helper
INFO - 2021-06-28 03:05:57 --> Helper loaded: my_helper
INFO - 2021-06-28 03:05:57 --> Database Driver Class Initialized
DEBUG - 2021-06-28 03:05:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 03:05:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 03:05:57 --> Controller Class Initialized
DEBUG - 2021-06-28 03:05:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-06-28 03:05:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 03:05:57 --> Final output sent to browser
DEBUG - 2021-06-28 03:05:57 --> Total execution time: 0.0517
INFO - 2021-06-28 03:06:00 --> Config Class Initialized
INFO - 2021-06-28 03:06:00 --> Hooks Class Initialized
DEBUG - 2021-06-28 03:06:00 --> UTF-8 Support Enabled
INFO - 2021-06-28 03:06:00 --> Utf8 Class Initialized
INFO - 2021-06-28 03:06:00 --> URI Class Initialized
INFO - 2021-06-28 03:06:00 --> Router Class Initialized
INFO - 2021-06-28 03:06:00 --> Output Class Initialized
INFO - 2021-06-28 03:06:00 --> Security Class Initialized
DEBUG - 2021-06-28 03:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 03:06:00 --> Input Class Initialized
INFO - 2021-06-28 03:06:00 --> Language Class Initialized
INFO - 2021-06-28 03:06:00 --> Language Class Initialized
INFO - 2021-06-28 03:06:00 --> Config Class Initialized
INFO - 2021-06-28 03:06:00 --> Loader Class Initialized
INFO - 2021-06-28 03:06:00 --> Helper loaded: url_helper
INFO - 2021-06-28 03:06:00 --> Helper loaded: file_helper
INFO - 2021-06-28 03:06:00 --> Helper loaded: form_helper
INFO - 2021-06-28 03:06:00 --> Helper loaded: my_helper
INFO - 2021-06-28 03:06:00 --> Database Driver Class Initialized
DEBUG - 2021-06-28 03:06:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 03:06:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 03:06:00 --> Controller Class Initialized
DEBUG - 2021-06-28 03:06:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul1.php
INFO - 2021-06-28 03:06:00 --> Final output sent to browser
DEBUG - 2021-06-28 03:06:00 --> Total execution time: 0.0540
INFO - 2021-06-28 03:06:09 --> Config Class Initialized
INFO - 2021-06-28 03:06:09 --> Hooks Class Initialized
DEBUG - 2021-06-28 03:06:09 --> UTF-8 Support Enabled
INFO - 2021-06-28 03:06:09 --> Utf8 Class Initialized
INFO - 2021-06-28 03:06:09 --> URI Class Initialized
INFO - 2021-06-28 03:06:09 --> Router Class Initialized
INFO - 2021-06-28 03:06:09 --> Output Class Initialized
INFO - 2021-06-28 03:06:09 --> Security Class Initialized
DEBUG - 2021-06-28 03:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 03:06:09 --> Input Class Initialized
INFO - 2021-06-28 03:06:09 --> Language Class Initialized
INFO - 2021-06-28 03:06:09 --> Language Class Initialized
INFO - 2021-06-28 03:06:09 --> Config Class Initialized
INFO - 2021-06-28 03:06:09 --> Loader Class Initialized
INFO - 2021-06-28 03:06:09 --> Helper loaded: url_helper
INFO - 2021-06-28 03:06:09 --> Helper loaded: file_helper
INFO - 2021-06-28 03:06:09 --> Helper loaded: form_helper
INFO - 2021-06-28 03:06:09 --> Helper loaded: my_helper
INFO - 2021-06-28 03:06:09 --> Database Driver Class Initialized
DEBUG - 2021-06-28 03:06:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 03:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 03:06:09 --> Controller Class Initialized
DEBUG - 2021-06-28 03:06:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-28 03:06:09 --> Final output sent to browser
DEBUG - 2021-06-28 03:06:09 --> Total execution time: 0.0543
INFO - 2021-06-28 03:06:27 --> Config Class Initialized
INFO - 2021-06-28 03:06:27 --> Hooks Class Initialized
DEBUG - 2021-06-28 03:06:27 --> UTF-8 Support Enabled
INFO - 2021-06-28 03:06:27 --> Utf8 Class Initialized
INFO - 2021-06-28 03:06:27 --> URI Class Initialized
INFO - 2021-06-28 03:06:27 --> Router Class Initialized
INFO - 2021-06-28 03:06:27 --> Output Class Initialized
INFO - 2021-06-28 03:06:27 --> Security Class Initialized
DEBUG - 2021-06-28 03:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 03:06:27 --> Input Class Initialized
INFO - 2021-06-28 03:06:27 --> Language Class Initialized
INFO - 2021-06-28 03:06:27 --> Language Class Initialized
INFO - 2021-06-28 03:06:27 --> Config Class Initialized
INFO - 2021-06-28 03:06:27 --> Loader Class Initialized
INFO - 2021-06-28 03:06:27 --> Helper loaded: url_helper
INFO - 2021-06-28 03:06:27 --> Helper loaded: file_helper
INFO - 2021-06-28 03:06:27 --> Helper loaded: form_helper
INFO - 2021-06-28 03:06:27 --> Helper loaded: my_helper
INFO - 2021-06-28 03:06:27 --> Database Driver Class Initialized
DEBUG - 2021-06-28 03:06:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 03:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 03:06:27 --> Controller Class Initialized
INFO - 2021-06-28 03:06:27 --> Helper loaded: cookie_helper
INFO - 2021-06-28 03:06:27 --> Config Class Initialized
INFO - 2021-06-28 03:06:27 --> Hooks Class Initialized
DEBUG - 2021-06-28 03:06:27 --> UTF-8 Support Enabled
INFO - 2021-06-28 03:06:27 --> Utf8 Class Initialized
INFO - 2021-06-28 03:06:27 --> URI Class Initialized
INFO - 2021-06-28 03:06:27 --> Router Class Initialized
INFO - 2021-06-28 03:06:27 --> Output Class Initialized
INFO - 2021-06-28 03:06:27 --> Security Class Initialized
DEBUG - 2021-06-28 03:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 03:06:27 --> Input Class Initialized
INFO - 2021-06-28 03:06:27 --> Language Class Initialized
INFO - 2021-06-28 03:06:27 --> Language Class Initialized
INFO - 2021-06-28 03:06:27 --> Config Class Initialized
INFO - 2021-06-28 03:06:27 --> Loader Class Initialized
INFO - 2021-06-28 03:06:27 --> Helper loaded: url_helper
INFO - 2021-06-28 03:06:27 --> Helper loaded: file_helper
INFO - 2021-06-28 03:06:27 --> Helper loaded: form_helper
INFO - 2021-06-28 03:06:27 --> Helper loaded: my_helper
INFO - 2021-06-28 03:06:27 --> Database Driver Class Initialized
DEBUG - 2021-06-28 03:06:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 03:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 03:06:27 --> Controller Class Initialized
DEBUG - 2021-06-28 03:06:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-28 03:06:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 03:06:27 --> Final output sent to browser
DEBUG - 2021-06-28 03:06:27 --> Total execution time: 0.0496
INFO - 2021-06-28 03:06:31 --> Config Class Initialized
INFO - 2021-06-28 03:06:31 --> Hooks Class Initialized
DEBUG - 2021-06-28 03:06:31 --> UTF-8 Support Enabled
INFO - 2021-06-28 03:06:31 --> Utf8 Class Initialized
INFO - 2021-06-28 03:06:31 --> URI Class Initialized
INFO - 2021-06-28 03:06:31 --> Router Class Initialized
INFO - 2021-06-28 03:06:31 --> Output Class Initialized
INFO - 2021-06-28 03:06:31 --> Security Class Initialized
DEBUG - 2021-06-28 03:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 03:06:31 --> Input Class Initialized
INFO - 2021-06-28 03:06:31 --> Language Class Initialized
INFO - 2021-06-28 03:06:31 --> Language Class Initialized
INFO - 2021-06-28 03:06:31 --> Config Class Initialized
INFO - 2021-06-28 03:06:31 --> Loader Class Initialized
INFO - 2021-06-28 03:06:31 --> Helper loaded: url_helper
INFO - 2021-06-28 03:06:31 --> Helper loaded: file_helper
INFO - 2021-06-28 03:06:31 --> Helper loaded: form_helper
INFO - 2021-06-28 03:06:31 --> Helper loaded: my_helper
INFO - 2021-06-28 03:06:31 --> Database Driver Class Initialized
DEBUG - 2021-06-28 03:06:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 03:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 03:06:31 --> Controller Class Initialized
INFO - 2021-06-28 03:06:31 --> Helper loaded: cookie_helper
INFO - 2021-06-28 03:06:31 --> Final output sent to browser
DEBUG - 2021-06-28 03:06:31 --> Total execution time: 0.0409
INFO - 2021-06-28 03:06:31 --> Config Class Initialized
INFO - 2021-06-28 03:06:31 --> Hooks Class Initialized
DEBUG - 2021-06-28 03:06:31 --> UTF-8 Support Enabled
INFO - 2021-06-28 03:06:31 --> Utf8 Class Initialized
INFO - 2021-06-28 03:06:31 --> URI Class Initialized
INFO - 2021-06-28 03:06:31 --> Router Class Initialized
INFO - 2021-06-28 03:06:31 --> Output Class Initialized
INFO - 2021-06-28 03:06:31 --> Security Class Initialized
DEBUG - 2021-06-28 03:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 03:06:31 --> Input Class Initialized
INFO - 2021-06-28 03:06:31 --> Language Class Initialized
INFO - 2021-06-28 03:06:31 --> Language Class Initialized
INFO - 2021-06-28 03:06:31 --> Config Class Initialized
INFO - 2021-06-28 03:06:31 --> Loader Class Initialized
INFO - 2021-06-28 03:06:31 --> Helper loaded: url_helper
INFO - 2021-06-28 03:06:31 --> Helper loaded: file_helper
INFO - 2021-06-28 03:06:31 --> Helper loaded: form_helper
INFO - 2021-06-28 03:06:31 --> Helper loaded: my_helper
INFO - 2021-06-28 03:06:31 --> Database Driver Class Initialized
DEBUG - 2021-06-28 03:06:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 03:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 03:06:31 --> Controller Class Initialized
DEBUG - 2021-06-28 03:06:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-28 03:06:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 03:06:32 --> Final output sent to browser
DEBUG - 2021-06-28 03:06:32 --> Total execution time: 0.6134
INFO - 2021-06-28 03:06:34 --> Config Class Initialized
INFO - 2021-06-28 03:06:34 --> Hooks Class Initialized
DEBUG - 2021-06-28 03:06:34 --> UTF-8 Support Enabled
INFO - 2021-06-28 03:06:34 --> Utf8 Class Initialized
INFO - 2021-06-28 03:06:34 --> URI Class Initialized
INFO - 2021-06-28 03:06:34 --> Router Class Initialized
INFO - 2021-06-28 03:06:34 --> Output Class Initialized
INFO - 2021-06-28 03:06:34 --> Security Class Initialized
DEBUG - 2021-06-28 03:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 03:06:34 --> Input Class Initialized
INFO - 2021-06-28 03:06:34 --> Language Class Initialized
INFO - 2021-06-28 03:06:34 --> Language Class Initialized
INFO - 2021-06-28 03:06:34 --> Config Class Initialized
INFO - 2021-06-28 03:06:34 --> Loader Class Initialized
INFO - 2021-06-28 03:06:34 --> Helper loaded: url_helper
INFO - 2021-06-28 03:06:34 --> Helper loaded: file_helper
INFO - 2021-06-28 03:06:34 --> Helper loaded: form_helper
INFO - 2021-06-28 03:06:34 --> Helper loaded: my_helper
INFO - 2021-06-28 03:06:34 --> Database Driver Class Initialized
DEBUG - 2021-06-28 03:06:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 03:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 03:06:34 --> Controller Class Initialized
DEBUG - 2021-06-28 03:06:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-06-28 03:06:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 03:06:34 --> Final output sent to browser
DEBUG - 2021-06-28 03:06:34 --> Total execution time: 0.0818
INFO - 2021-06-28 03:06:34 --> Config Class Initialized
INFO - 2021-06-28 03:06:34 --> Hooks Class Initialized
DEBUG - 2021-06-28 03:06:34 --> UTF-8 Support Enabled
INFO - 2021-06-28 03:06:34 --> Utf8 Class Initialized
INFO - 2021-06-28 03:06:34 --> URI Class Initialized
INFO - 2021-06-28 03:06:34 --> Router Class Initialized
INFO - 2021-06-28 03:06:34 --> Output Class Initialized
INFO - 2021-06-28 03:06:34 --> Security Class Initialized
DEBUG - 2021-06-28 03:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 03:06:34 --> Input Class Initialized
INFO - 2021-06-28 03:06:34 --> Language Class Initialized
INFO - 2021-06-28 03:06:34 --> Language Class Initialized
INFO - 2021-06-28 03:06:34 --> Config Class Initialized
INFO - 2021-06-28 03:06:34 --> Loader Class Initialized
INFO - 2021-06-28 03:06:34 --> Helper loaded: url_helper
INFO - 2021-06-28 03:06:34 --> Helper loaded: file_helper
INFO - 2021-06-28 03:06:34 --> Helper loaded: form_helper
INFO - 2021-06-28 03:06:34 --> Helper loaded: my_helper
INFO - 2021-06-28 03:06:34 --> Database Driver Class Initialized
DEBUG - 2021-06-28 03:06:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 03:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 03:06:34 --> Controller Class Initialized
INFO - 2021-06-28 03:32:58 --> Config Class Initialized
INFO - 2021-06-28 03:32:58 --> Hooks Class Initialized
DEBUG - 2021-06-28 03:32:58 --> UTF-8 Support Enabled
INFO - 2021-06-28 03:32:58 --> Utf8 Class Initialized
INFO - 2021-06-28 03:32:58 --> URI Class Initialized
INFO - 2021-06-28 03:32:58 --> Router Class Initialized
INFO - 2021-06-28 03:32:58 --> Output Class Initialized
INFO - 2021-06-28 03:32:58 --> Security Class Initialized
DEBUG - 2021-06-28 03:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 03:32:58 --> Input Class Initialized
INFO - 2021-06-28 03:32:58 --> Language Class Initialized
INFO - 2021-06-28 03:32:58 --> Language Class Initialized
INFO - 2021-06-28 03:32:58 --> Config Class Initialized
INFO - 2021-06-28 03:32:58 --> Loader Class Initialized
INFO - 2021-06-28 03:32:58 --> Helper loaded: url_helper
INFO - 2021-06-28 03:32:58 --> Helper loaded: file_helper
INFO - 2021-06-28 03:32:58 --> Helper loaded: form_helper
INFO - 2021-06-28 03:32:58 --> Helper loaded: my_helper
INFO - 2021-06-28 03:32:58 --> Database Driver Class Initialized
DEBUG - 2021-06-28 03:32:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 03:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 03:32:58 --> Controller Class Initialized
DEBUG - 2021-06-28 03:32:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul1.php
INFO - 2021-06-28 03:32:58 --> Final output sent to browser
DEBUG - 2021-06-28 03:32:58 --> Total execution time: 0.0504
INFO - 2021-06-28 03:33:09 --> Config Class Initialized
INFO - 2021-06-28 03:33:09 --> Hooks Class Initialized
DEBUG - 2021-06-28 03:33:09 --> UTF-8 Support Enabled
INFO - 2021-06-28 03:33:09 --> Utf8 Class Initialized
INFO - 2021-06-28 03:33:09 --> URI Class Initialized
INFO - 2021-06-28 03:33:09 --> Router Class Initialized
INFO - 2021-06-28 03:33:09 --> Output Class Initialized
INFO - 2021-06-28 03:33:09 --> Security Class Initialized
DEBUG - 2021-06-28 03:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 03:33:09 --> Input Class Initialized
INFO - 2021-06-28 03:33:09 --> Language Class Initialized
INFO - 2021-06-28 03:33:09 --> Language Class Initialized
INFO - 2021-06-28 03:33:09 --> Config Class Initialized
INFO - 2021-06-28 03:33:09 --> Loader Class Initialized
INFO - 2021-06-28 03:33:09 --> Helper loaded: url_helper
INFO - 2021-06-28 03:33:09 --> Helper loaded: file_helper
INFO - 2021-06-28 03:33:09 --> Helper loaded: form_helper
INFO - 2021-06-28 03:33:09 --> Helper loaded: my_helper
INFO - 2021-06-28 03:33:09 --> Database Driver Class Initialized
DEBUG - 2021-06-28 03:33:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 03:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 03:33:09 --> Controller Class Initialized
DEBUG - 2021-06-28 03:33:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul1.php
INFO - 2021-06-28 03:33:09 --> Final output sent to browser
DEBUG - 2021-06-28 03:33:09 --> Total execution time: 0.0460
INFO - 2021-06-28 03:33:31 --> Config Class Initialized
INFO - 2021-06-28 03:33:31 --> Hooks Class Initialized
DEBUG - 2021-06-28 03:33:31 --> UTF-8 Support Enabled
INFO - 2021-06-28 03:33:31 --> Utf8 Class Initialized
INFO - 2021-06-28 03:33:31 --> URI Class Initialized
INFO - 2021-06-28 03:33:31 --> Router Class Initialized
INFO - 2021-06-28 03:33:31 --> Output Class Initialized
INFO - 2021-06-28 03:33:31 --> Security Class Initialized
DEBUG - 2021-06-28 03:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 03:33:31 --> Input Class Initialized
INFO - 2021-06-28 03:33:31 --> Language Class Initialized
INFO - 2021-06-28 03:33:31 --> Language Class Initialized
INFO - 2021-06-28 03:33:31 --> Config Class Initialized
INFO - 2021-06-28 03:33:31 --> Loader Class Initialized
INFO - 2021-06-28 03:33:31 --> Helper loaded: url_helper
INFO - 2021-06-28 03:33:31 --> Helper loaded: file_helper
INFO - 2021-06-28 03:33:31 --> Helper loaded: form_helper
INFO - 2021-06-28 03:33:31 --> Helper loaded: my_helper
INFO - 2021-06-28 03:33:31 --> Database Driver Class Initialized
DEBUG - 2021-06-28 03:33:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 03:33:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 03:33:31 --> Controller Class Initialized
DEBUG - 2021-06-28 03:33:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul1.php
INFO - 2021-06-28 03:33:31 --> Final output sent to browser
DEBUG - 2021-06-28 03:33:31 --> Total execution time: 0.0467
INFO - 2021-06-28 03:34:41 --> Config Class Initialized
INFO - 2021-06-28 03:34:41 --> Hooks Class Initialized
DEBUG - 2021-06-28 03:34:41 --> UTF-8 Support Enabled
INFO - 2021-06-28 03:34:41 --> Utf8 Class Initialized
INFO - 2021-06-28 03:34:41 --> URI Class Initialized
INFO - 2021-06-28 03:34:41 --> Router Class Initialized
INFO - 2021-06-28 03:34:41 --> Output Class Initialized
INFO - 2021-06-28 03:34:41 --> Security Class Initialized
DEBUG - 2021-06-28 03:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 03:34:41 --> Input Class Initialized
INFO - 2021-06-28 03:34:41 --> Language Class Initialized
INFO - 2021-06-28 03:34:41 --> Language Class Initialized
INFO - 2021-06-28 03:34:41 --> Config Class Initialized
INFO - 2021-06-28 03:34:41 --> Loader Class Initialized
INFO - 2021-06-28 03:34:41 --> Helper loaded: url_helper
INFO - 2021-06-28 03:34:41 --> Helper loaded: file_helper
INFO - 2021-06-28 03:34:41 --> Helper loaded: form_helper
INFO - 2021-06-28 03:34:41 --> Helper loaded: my_helper
INFO - 2021-06-28 03:34:41 --> Database Driver Class Initialized
DEBUG - 2021-06-28 03:34:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 03:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 03:34:41 --> Controller Class Initialized
DEBUG - 2021-06-28 03:34:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul1.php
INFO - 2021-06-28 03:34:41 --> Final output sent to browser
DEBUG - 2021-06-28 03:34:41 --> Total execution time: 0.0464
INFO - 2021-06-28 03:35:26 --> Config Class Initialized
INFO - 2021-06-28 03:35:26 --> Hooks Class Initialized
DEBUG - 2021-06-28 03:35:26 --> UTF-8 Support Enabled
INFO - 2021-06-28 03:35:26 --> Utf8 Class Initialized
INFO - 2021-06-28 03:35:26 --> URI Class Initialized
INFO - 2021-06-28 03:35:26 --> Router Class Initialized
INFO - 2021-06-28 03:35:26 --> Output Class Initialized
INFO - 2021-06-28 03:35:26 --> Security Class Initialized
DEBUG - 2021-06-28 03:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 03:35:26 --> Input Class Initialized
INFO - 2021-06-28 03:35:26 --> Language Class Initialized
INFO - 2021-06-28 03:35:26 --> Language Class Initialized
INFO - 2021-06-28 03:35:26 --> Config Class Initialized
INFO - 2021-06-28 03:35:26 --> Loader Class Initialized
INFO - 2021-06-28 03:35:26 --> Helper loaded: url_helper
INFO - 2021-06-28 03:35:26 --> Helper loaded: file_helper
INFO - 2021-06-28 03:35:26 --> Helper loaded: form_helper
INFO - 2021-06-28 03:35:26 --> Helper loaded: my_helper
INFO - 2021-06-28 03:35:26 --> Database Driver Class Initialized
DEBUG - 2021-06-28 03:35:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 03:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 03:35:26 --> Controller Class Initialized
ERROR - 2021-06-28 03:35:26 --> Severity: Notice --> Undefined variable: det_siswa C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_sampul1.php 86
DEBUG - 2021-06-28 03:35:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul1.php
INFO - 2021-06-28 03:35:26 --> Final output sent to browser
DEBUG - 2021-06-28 03:35:26 --> Total execution time: 0.0959
INFO - 2021-06-28 03:37:58 --> Config Class Initialized
INFO - 2021-06-28 03:37:58 --> Hooks Class Initialized
DEBUG - 2021-06-28 03:37:58 --> UTF-8 Support Enabled
INFO - 2021-06-28 03:37:58 --> Utf8 Class Initialized
INFO - 2021-06-28 03:37:58 --> URI Class Initialized
INFO - 2021-06-28 03:37:58 --> Router Class Initialized
INFO - 2021-06-28 03:37:58 --> Output Class Initialized
INFO - 2021-06-28 03:37:58 --> Security Class Initialized
DEBUG - 2021-06-28 03:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 03:37:58 --> Input Class Initialized
INFO - 2021-06-28 03:37:58 --> Language Class Initialized
INFO - 2021-06-28 03:37:59 --> Language Class Initialized
INFO - 2021-06-28 03:37:59 --> Config Class Initialized
INFO - 2021-06-28 03:37:59 --> Loader Class Initialized
INFO - 2021-06-28 03:37:59 --> Helper loaded: url_helper
INFO - 2021-06-28 03:37:59 --> Helper loaded: file_helper
INFO - 2021-06-28 03:37:59 --> Helper loaded: form_helper
INFO - 2021-06-28 03:37:59 --> Helper loaded: my_helper
INFO - 2021-06-28 03:37:59 --> Database Driver Class Initialized
DEBUG - 2021-06-28 03:37:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 03:37:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 03:37:59 --> Controller Class Initialized
ERROR - 2021-06-28 03:37:59 --> Severity: Notice --> Undefined variable: siswa C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 23
DEBUG - 2021-06-28 03:37:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul1.php
INFO - 2021-06-28 03:37:59 --> Final output sent to browser
DEBUG - 2021-06-28 03:37:59 --> Total execution time: 0.0576
INFO - 2021-06-28 03:38:45 --> Config Class Initialized
INFO - 2021-06-28 03:38:45 --> Hooks Class Initialized
DEBUG - 2021-06-28 03:38:45 --> UTF-8 Support Enabled
INFO - 2021-06-28 03:38:45 --> Utf8 Class Initialized
INFO - 2021-06-28 03:38:45 --> URI Class Initialized
INFO - 2021-06-28 03:38:45 --> Router Class Initialized
INFO - 2021-06-28 03:38:45 --> Output Class Initialized
INFO - 2021-06-28 03:38:45 --> Security Class Initialized
DEBUG - 2021-06-28 03:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 03:38:45 --> Input Class Initialized
INFO - 2021-06-28 03:38:45 --> Language Class Initialized
INFO - 2021-06-28 03:38:45 --> Language Class Initialized
INFO - 2021-06-28 03:38:45 --> Config Class Initialized
INFO - 2021-06-28 03:38:45 --> Loader Class Initialized
INFO - 2021-06-28 03:38:45 --> Helper loaded: url_helper
INFO - 2021-06-28 03:38:45 --> Helper loaded: file_helper
INFO - 2021-06-28 03:38:45 --> Helper loaded: form_helper
INFO - 2021-06-28 03:38:45 --> Helper loaded: my_helper
INFO - 2021-06-28 03:38:45 --> Database Driver Class Initialized
DEBUG - 2021-06-28 03:38:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 03:38:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 03:38:45 --> Controller Class Initialized
ERROR - 2021-06-28 03:38:45 --> Severity: Notice --> Undefined index: ta C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 28
DEBUG - 2021-06-28 03:38:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul1.php
INFO - 2021-06-28 03:38:45 --> Final output sent to browser
DEBUG - 2021-06-28 03:38:45 --> Total execution time: 0.0592
INFO - 2021-06-28 03:38:46 --> Config Class Initialized
INFO - 2021-06-28 03:38:46 --> Hooks Class Initialized
DEBUG - 2021-06-28 03:38:46 --> UTF-8 Support Enabled
INFO - 2021-06-28 03:38:46 --> Utf8 Class Initialized
INFO - 2021-06-28 03:38:46 --> URI Class Initialized
INFO - 2021-06-28 03:38:46 --> Router Class Initialized
INFO - 2021-06-28 03:38:46 --> Output Class Initialized
INFO - 2021-06-28 03:38:46 --> Security Class Initialized
DEBUG - 2021-06-28 03:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 03:38:46 --> Input Class Initialized
INFO - 2021-06-28 03:38:46 --> Language Class Initialized
INFO - 2021-06-28 03:38:46 --> Language Class Initialized
INFO - 2021-06-28 03:38:46 --> Config Class Initialized
INFO - 2021-06-28 03:38:46 --> Loader Class Initialized
INFO - 2021-06-28 03:38:46 --> Helper loaded: url_helper
INFO - 2021-06-28 03:38:46 --> Helper loaded: file_helper
INFO - 2021-06-28 03:38:46 --> Helper loaded: form_helper
INFO - 2021-06-28 03:38:46 --> Helper loaded: my_helper
INFO - 2021-06-28 03:38:46 --> Database Driver Class Initialized
DEBUG - 2021-06-28 03:38:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 03:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 03:38:47 --> Controller Class Initialized
ERROR - 2021-06-28 03:38:47 --> Severity: Notice --> Undefined index: ta C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 28
DEBUG - 2021-06-28 03:38:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul1.php
INFO - 2021-06-28 03:38:47 --> Final output sent to browser
DEBUG - 2021-06-28 03:38:47 --> Total execution time: 0.0591
INFO - 2021-06-28 03:54:52 --> Config Class Initialized
INFO - 2021-06-28 03:54:52 --> Hooks Class Initialized
DEBUG - 2021-06-28 03:54:52 --> UTF-8 Support Enabled
INFO - 2021-06-28 03:54:52 --> Utf8 Class Initialized
INFO - 2021-06-28 03:54:52 --> URI Class Initialized
INFO - 2021-06-28 03:54:52 --> Router Class Initialized
INFO - 2021-06-28 03:54:52 --> Output Class Initialized
INFO - 2021-06-28 03:54:52 --> Security Class Initialized
DEBUG - 2021-06-28 03:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 03:54:52 --> Input Class Initialized
INFO - 2021-06-28 03:54:52 --> Language Class Initialized
INFO - 2021-06-28 03:54:52 --> Language Class Initialized
INFO - 2021-06-28 03:54:52 --> Config Class Initialized
INFO - 2021-06-28 03:54:52 --> Loader Class Initialized
INFO - 2021-06-28 03:54:52 --> Helper loaded: url_helper
INFO - 2021-06-28 03:54:52 --> Helper loaded: file_helper
INFO - 2021-06-28 03:54:52 --> Helper loaded: form_helper
INFO - 2021-06-28 03:54:52 --> Helper loaded: my_helper
INFO - 2021-06-28 03:54:52 --> Database Driver Class Initialized
DEBUG - 2021-06-28 03:54:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 03:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 03:54:52 --> Controller Class Initialized
ERROR - 2021-06-28 03:54:52 --> Severity: Notice --> Undefined index: ta C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 28
DEBUG - 2021-06-28 03:54:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul1.php
INFO - 2021-06-28 03:54:52 --> Final output sent to browser
DEBUG - 2021-06-28 03:54:52 --> Total execution time: 0.0496
INFO - 2021-06-28 03:56:32 --> Config Class Initialized
INFO - 2021-06-28 03:56:32 --> Hooks Class Initialized
DEBUG - 2021-06-28 03:56:32 --> UTF-8 Support Enabled
INFO - 2021-06-28 03:56:32 --> Utf8 Class Initialized
INFO - 2021-06-28 03:56:32 --> URI Class Initialized
INFO - 2021-06-28 03:56:32 --> Router Class Initialized
INFO - 2021-06-28 03:56:32 --> Output Class Initialized
INFO - 2021-06-28 03:56:32 --> Security Class Initialized
DEBUG - 2021-06-28 03:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 03:56:32 --> Input Class Initialized
INFO - 2021-06-28 03:56:32 --> Language Class Initialized
INFO - 2021-06-28 03:56:32 --> Language Class Initialized
INFO - 2021-06-28 03:56:32 --> Config Class Initialized
INFO - 2021-06-28 03:56:32 --> Loader Class Initialized
INFO - 2021-06-28 03:56:32 --> Helper loaded: url_helper
INFO - 2021-06-28 03:56:32 --> Helper loaded: file_helper
INFO - 2021-06-28 03:56:32 --> Helper loaded: form_helper
INFO - 2021-06-28 03:56:32 --> Helper loaded: my_helper
INFO - 2021-06-28 03:56:32 --> Database Driver Class Initialized
DEBUG - 2021-06-28 03:56:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 03:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 03:56:32 --> Controller Class Initialized
DEBUG - 2021-06-28 03:56:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul1.php
INFO - 2021-06-28 03:56:32 --> Final output sent to browser
DEBUG - 2021-06-28 03:56:32 --> Total execution time: 0.0474
INFO - 2021-06-28 03:58:00 --> Config Class Initialized
INFO - 2021-06-28 03:58:00 --> Hooks Class Initialized
DEBUG - 2021-06-28 03:58:00 --> UTF-8 Support Enabled
INFO - 2021-06-28 03:58:00 --> Utf8 Class Initialized
INFO - 2021-06-28 03:58:00 --> URI Class Initialized
INFO - 2021-06-28 03:58:00 --> Router Class Initialized
INFO - 2021-06-28 03:58:00 --> Output Class Initialized
INFO - 2021-06-28 03:58:00 --> Security Class Initialized
DEBUG - 2021-06-28 03:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 03:58:00 --> Input Class Initialized
INFO - 2021-06-28 03:58:00 --> Language Class Initialized
INFO - 2021-06-28 03:58:00 --> Language Class Initialized
INFO - 2021-06-28 03:58:00 --> Config Class Initialized
INFO - 2021-06-28 03:58:00 --> Loader Class Initialized
INFO - 2021-06-28 03:58:00 --> Helper loaded: url_helper
INFO - 2021-06-28 03:58:00 --> Helper loaded: file_helper
INFO - 2021-06-28 03:58:00 --> Helper loaded: form_helper
INFO - 2021-06-28 03:58:00 --> Helper loaded: my_helper
INFO - 2021-06-28 03:58:00 --> Database Driver Class Initialized
DEBUG - 2021-06-28 03:58:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 03:58:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 03:58:00 --> Controller Class Initialized
DEBUG - 2021-06-28 03:58:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul1.php
INFO - 2021-06-28 03:58:00 --> Final output sent to browser
DEBUG - 2021-06-28 03:58:00 --> Total execution time: 0.0449
INFO - 2021-06-28 04:11:45 --> Config Class Initialized
INFO - 2021-06-28 04:11:45 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:11:45 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:11:45 --> Utf8 Class Initialized
INFO - 2021-06-28 04:11:45 --> URI Class Initialized
INFO - 2021-06-28 04:11:45 --> Router Class Initialized
INFO - 2021-06-28 04:11:45 --> Output Class Initialized
INFO - 2021-06-28 04:11:45 --> Security Class Initialized
DEBUG - 2021-06-28 04:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:11:45 --> Input Class Initialized
INFO - 2021-06-28 04:11:45 --> Language Class Initialized
INFO - 2021-06-28 04:11:45 --> Language Class Initialized
INFO - 2021-06-28 04:11:45 --> Config Class Initialized
INFO - 2021-06-28 04:11:45 --> Loader Class Initialized
INFO - 2021-06-28 04:11:45 --> Helper loaded: url_helper
INFO - 2021-06-28 04:11:45 --> Helper loaded: file_helper
INFO - 2021-06-28 04:11:45 --> Helper loaded: form_helper
INFO - 2021-06-28 04:11:45 --> Helper loaded: my_helper
INFO - 2021-06-28 04:11:45 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:11:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:11:45 --> Controller Class Initialized
ERROR - 2021-06-28 04:11:45 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 241
DEBUG - 2021-06-28 04:11:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-06-28 04:11:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 04:11:45 --> Final output sent to browser
DEBUG - 2021-06-28 04:11:45 --> Total execution time: 0.0458
INFO - 2021-06-28 04:12:07 --> Config Class Initialized
INFO - 2021-06-28 04:12:07 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:12:07 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:12:07 --> Utf8 Class Initialized
INFO - 2021-06-28 04:12:07 --> URI Class Initialized
INFO - 2021-06-28 04:12:07 --> Router Class Initialized
INFO - 2021-06-28 04:12:07 --> Output Class Initialized
INFO - 2021-06-28 04:12:07 --> Security Class Initialized
DEBUG - 2021-06-28 04:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:12:07 --> Input Class Initialized
INFO - 2021-06-28 04:12:07 --> Language Class Initialized
INFO - 2021-06-28 04:12:07 --> Language Class Initialized
INFO - 2021-06-28 04:12:07 --> Config Class Initialized
INFO - 2021-06-28 04:12:07 --> Loader Class Initialized
INFO - 2021-06-28 04:12:07 --> Helper loaded: url_helper
INFO - 2021-06-28 04:12:07 --> Helper loaded: file_helper
INFO - 2021-06-28 04:12:07 --> Helper loaded: form_helper
INFO - 2021-06-28 04:12:07 --> Helper loaded: my_helper
INFO - 2021-06-28 04:12:07 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:12:07 --> Controller Class Initialized
DEBUG - 2021-06-28 04:12:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-06-28 04:12:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 04:12:07 --> Final output sent to browser
DEBUG - 2021-06-28 04:12:07 --> Total execution time: 0.0510
INFO - 2021-06-28 04:12:07 --> Config Class Initialized
INFO - 2021-06-28 04:12:07 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:12:07 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:12:07 --> Utf8 Class Initialized
INFO - 2021-06-28 04:12:07 --> URI Class Initialized
INFO - 2021-06-28 04:12:07 --> Router Class Initialized
INFO - 2021-06-28 04:12:07 --> Output Class Initialized
INFO - 2021-06-28 04:12:07 --> Security Class Initialized
DEBUG - 2021-06-28 04:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:12:07 --> Input Class Initialized
INFO - 2021-06-28 04:12:07 --> Language Class Initialized
INFO - 2021-06-28 04:12:07 --> Language Class Initialized
INFO - 2021-06-28 04:12:07 --> Config Class Initialized
INFO - 2021-06-28 04:12:07 --> Loader Class Initialized
INFO - 2021-06-28 04:12:07 --> Helper loaded: url_helper
INFO - 2021-06-28 04:12:07 --> Helper loaded: file_helper
INFO - 2021-06-28 04:12:07 --> Helper loaded: form_helper
INFO - 2021-06-28 04:12:07 --> Helper loaded: my_helper
INFO - 2021-06-28 04:12:07 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:12:07 --> Controller Class Initialized
INFO - 2021-06-28 04:25:14 --> Config Class Initialized
INFO - 2021-06-28 04:25:14 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:25:14 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:25:14 --> Utf8 Class Initialized
INFO - 2021-06-28 04:25:14 --> URI Class Initialized
INFO - 2021-06-28 04:25:14 --> Router Class Initialized
INFO - 2021-06-28 04:25:14 --> Output Class Initialized
INFO - 2021-06-28 04:25:14 --> Security Class Initialized
DEBUG - 2021-06-28 04:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:25:14 --> Input Class Initialized
INFO - 2021-06-28 04:25:14 --> Language Class Initialized
INFO - 2021-06-28 04:25:14 --> Language Class Initialized
INFO - 2021-06-28 04:25:14 --> Config Class Initialized
INFO - 2021-06-28 04:25:14 --> Loader Class Initialized
INFO - 2021-06-28 04:25:14 --> Helper loaded: url_helper
INFO - 2021-06-28 04:25:14 --> Helper loaded: file_helper
INFO - 2021-06-28 04:25:14 --> Helper loaded: form_helper
INFO - 2021-06-28 04:25:14 --> Helper loaded: my_helper
INFO - 2021-06-28 04:25:14 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:25:14 --> Controller Class Initialized
DEBUG - 2021-06-28 04:25:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form_import.php
DEBUG - 2021-06-28 04:25:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 04:25:14 --> Final output sent to browser
DEBUG - 2021-06-28 04:25:14 --> Total execution time: 0.0508
INFO - 2021-06-28 04:25:17 --> Config Class Initialized
INFO - 2021-06-28 04:25:17 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:25:17 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:25:17 --> Utf8 Class Initialized
INFO - 2021-06-28 04:25:17 --> URI Class Initialized
INFO - 2021-06-28 04:25:17 --> Router Class Initialized
INFO - 2021-06-28 04:25:17 --> Output Class Initialized
INFO - 2021-06-28 04:25:17 --> Security Class Initialized
DEBUG - 2021-06-28 04:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:25:17 --> Input Class Initialized
INFO - 2021-06-28 04:25:17 --> Language Class Initialized
INFO - 2021-06-28 04:25:17 --> Language Class Initialized
INFO - 2021-06-28 04:25:17 --> Config Class Initialized
INFO - 2021-06-28 04:25:17 --> Loader Class Initialized
INFO - 2021-06-28 04:25:17 --> Helper loaded: url_helper
INFO - 2021-06-28 04:25:17 --> Helper loaded: file_helper
INFO - 2021-06-28 04:25:17 --> Helper loaded: form_helper
INFO - 2021-06-28 04:25:17 --> Helper loaded: my_helper
INFO - 2021-06-28 04:25:17 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:25:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:25:17 --> Controller Class Initialized
INFO - 2021-06-28 04:25:20 --> Config Class Initialized
INFO - 2021-06-28 04:25:20 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:25:20 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:25:20 --> Utf8 Class Initialized
INFO - 2021-06-28 04:25:20 --> URI Class Initialized
INFO - 2021-06-28 04:25:20 --> Router Class Initialized
INFO - 2021-06-28 04:25:20 --> Output Class Initialized
INFO - 2021-06-28 04:25:20 --> Security Class Initialized
DEBUG - 2021-06-28 04:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:25:20 --> Input Class Initialized
INFO - 2021-06-28 04:25:20 --> Language Class Initialized
INFO - 2021-06-28 04:25:20 --> Language Class Initialized
INFO - 2021-06-28 04:25:20 --> Config Class Initialized
INFO - 2021-06-28 04:25:20 --> Loader Class Initialized
INFO - 2021-06-28 04:25:20 --> Helper loaded: url_helper
INFO - 2021-06-28 04:25:20 --> Helper loaded: file_helper
INFO - 2021-06-28 04:25:20 --> Helper loaded: form_helper
INFO - 2021-06-28 04:25:20 --> Helper loaded: my_helper
INFO - 2021-06-28 04:25:21 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:25:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:25:21 --> Controller Class Initialized
DEBUG - 2021-06-28 04:25:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form_import.php
DEBUG - 2021-06-28 04:25:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 04:25:21 --> Final output sent to browser
DEBUG - 2021-06-28 04:25:21 --> Total execution time: 0.0502
INFO - 2021-06-28 04:25:23 --> Config Class Initialized
INFO - 2021-06-28 04:25:23 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:25:23 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:25:23 --> Utf8 Class Initialized
INFO - 2021-06-28 04:25:23 --> URI Class Initialized
INFO - 2021-06-28 04:25:23 --> Router Class Initialized
INFO - 2021-06-28 04:25:23 --> Output Class Initialized
INFO - 2021-06-28 04:25:23 --> Security Class Initialized
DEBUG - 2021-06-28 04:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:25:23 --> Input Class Initialized
INFO - 2021-06-28 04:25:23 --> Language Class Initialized
INFO - 2021-06-28 04:25:23 --> Language Class Initialized
INFO - 2021-06-28 04:25:23 --> Config Class Initialized
INFO - 2021-06-28 04:25:23 --> Loader Class Initialized
INFO - 2021-06-28 04:25:23 --> Helper loaded: url_helper
INFO - 2021-06-28 04:25:23 --> Helper loaded: file_helper
INFO - 2021-06-28 04:25:23 --> Helper loaded: form_helper
INFO - 2021-06-28 04:25:23 --> Helper loaded: my_helper
INFO - 2021-06-28 04:25:23 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:25:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:25:23 --> Controller Class Initialized
DEBUG - 2021-06-28 04:25:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-06-28 04:25:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 04:25:23 --> Final output sent to browser
DEBUG - 2021-06-28 04:25:23 --> Total execution time: 0.0497
INFO - 2021-06-28 04:25:23 --> Config Class Initialized
INFO - 2021-06-28 04:25:23 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:25:23 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:25:23 --> Utf8 Class Initialized
INFO - 2021-06-28 04:25:23 --> URI Class Initialized
INFO - 2021-06-28 04:25:23 --> Router Class Initialized
INFO - 2021-06-28 04:25:23 --> Output Class Initialized
INFO - 2021-06-28 04:25:23 --> Security Class Initialized
DEBUG - 2021-06-28 04:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:25:23 --> Input Class Initialized
INFO - 2021-06-28 04:25:23 --> Language Class Initialized
INFO - 2021-06-28 04:25:23 --> Language Class Initialized
INFO - 2021-06-28 04:25:23 --> Config Class Initialized
INFO - 2021-06-28 04:25:23 --> Loader Class Initialized
INFO - 2021-06-28 04:25:23 --> Helper loaded: url_helper
INFO - 2021-06-28 04:25:23 --> Helper loaded: file_helper
INFO - 2021-06-28 04:25:23 --> Helper loaded: form_helper
INFO - 2021-06-28 04:25:23 --> Helper loaded: my_helper
INFO - 2021-06-28 04:25:23 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:25:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:25:23 --> Controller Class Initialized
INFO - 2021-06-28 04:25:26 --> Config Class Initialized
INFO - 2021-06-28 04:25:26 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:25:26 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:25:26 --> Utf8 Class Initialized
INFO - 2021-06-28 04:25:26 --> URI Class Initialized
INFO - 2021-06-28 04:25:26 --> Router Class Initialized
INFO - 2021-06-28 04:25:26 --> Output Class Initialized
INFO - 2021-06-28 04:25:26 --> Security Class Initialized
DEBUG - 2021-06-28 04:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:25:26 --> Input Class Initialized
INFO - 2021-06-28 04:25:26 --> Language Class Initialized
INFO - 2021-06-28 04:25:26 --> Language Class Initialized
INFO - 2021-06-28 04:25:26 --> Config Class Initialized
INFO - 2021-06-28 04:25:26 --> Loader Class Initialized
INFO - 2021-06-28 04:25:26 --> Helper loaded: url_helper
INFO - 2021-06-28 04:25:26 --> Helper loaded: file_helper
INFO - 2021-06-28 04:25:26 --> Helper loaded: form_helper
INFO - 2021-06-28 04:25:26 --> Helper loaded: my_helper
INFO - 2021-06-28 04:25:26 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:25:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:25:26 --> Controller Class Initialized
INFO - 2021-06-28 04:25:47 --> Config Class Initialized
INFO - 2021-06-28 04:25:47 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:25:47 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:25:47 --> Utf8 Class Initialized
INFO - 2021-06-28 04:25:47 --> URI Class Initialized
INFO - 2021-06-28 04:25:47 --> Router Class Initialized
INFO - 2021-06-28 04:25:47 --> Output Class Initialized
INFO - 2021-06-28 04:25:47 --> Security Class Initialized
DEBUG - 2021-06-28 04:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:25:47 --> Input Class Initialized
INFO - 2021-06-28 04:25:47 --> Language Class Initialized
INFO - 2021-06-28 04:25:47 --> Language Class Initialized
INFO - 2021-06-28 04:25:47 --> Config Class Initialized
INFO - 2021-06-28 04:25:47 --> Loader Class Initialized
INFO - 2021-06-28 04:25:47 --> Helper loaded: url_helper
INFO - 2021-06-28 04:25:47 --> Helper loaded: file_helper
INFO - 2021-06-28 04:25:47 --> Helper loaded: form_helper
INFO - 2021-06-28 04:25:47 --> Helper loaded: my_helper
INFO - 2021-06-28 04:25:47 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:25:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:25:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:25:47 --> Controller Class Initialized
INFO - 2021-06-28 04:25:53 --> Config Class Initialized
INFO - 2021-06-28 04:25:53 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:25:53 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:25:53 --> Utf8 Class Initialized
INFO - 2021-06-28 04:25:53 --> URI Class Initialized
INFO - 2021-06-28 04:25:53 --> Router Class Initialized
INFO - 2021-06-28 04:25:53 --> Output Class Initialized
INFO - 2021-06-28 04:25:53 --> Security Class Initialized
DEBUG - 2021-06-28 04:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:25:53 --> Input Class Initialized
INFO - 2021-06-28 04:25:53 --> Language Class Initialized
INFO - 2021-06-28 04:25:53 --> Language Class Initialized
INFO - 2021-06-28 04:25:53 --> Config Class Initialized
INFO - 2021-06-28 04:25:53 --> Loader Class Initialized
INFO - 2021-06-28 04:25:53 --> Helper loaded: url_helper
INFO - 2021-06-28 04:25:53 --> Helper loaded: file_helper
INFO - 2021-06-28 04:25:53 --> Helper loaded: form_helper
INFO - 2021-06-28 04:25:53 --> Helper loaded: my_helper
INFO - 2021-06-28 04:25:53 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:25:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:25:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:25:53 --> Controller Class Initialized
INFO - 2021-06-28 04:25:56 --> Config Class Initialized
INFO - 2021-06-28 04:25:56 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:25:56 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:25:56 --> Utf8 Class Initialized
INFO - 2021-06-28 04:25:56 --> URI Class Initialized
INFO - 2021-06-28 04:25:56 --> Router Class Initialized
INFO - 2021-06-28 04:25:56 --> Output Class Initialized
INFO - 2021-06-28 04:25:56 --> Security Class Initialized
DEBUG - 2021-06-28 04:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:25:56 --> Input Class Initialized
INFO - 2021-06-28 04:25:56 --> Language Class Initialized
INFO - 2021-06-28 04:25:56 --> Language Class Initialized
INFO - 2021-06-28 04:25:56 --> Config Class Initialized
INFO - 2021-06-28 04:25:56 --> Loader Class Initialized
INFO - 2021-06-28 04:25:56 --> Helper loaded: url_helper
INFO - 2021-06-28 04:25:56 --> Helper loaded: file_helper
INFO - 2021-06-28 04:25:56 --> Helper loaded: form_helper
INFO - 2021-06-28 04:25:56 --> Helper loaded: my_helper
INFO - 2021-06-28 04:25:56 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:25:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:25:56 --> Controller Class Initialized
INFO - 2021-06-28 04:26:32 --> Config Class Initialized
INFO - 2021-06-28 04:26:32 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:26:32 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:26:32 --> Utf8 Class Initialized
INFO - 2021-06-28 04:26:32 --> URI Class Initialized
INFO - 2021-06-28 04:26:32 --> Router Class Initialized
INFO - 2021-06-28 04:26:32 --> Output Class Initialized
INFO - 2021-06-28 04:26:32 --> Security Class Initialized
DEBUG - 2021-06-28 04:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:26:32 --> Input Class Initialized
INFO - 2021-06-28 04:26:32 --> Language Class Initialized
INFO - 2021-06-28 04:26:32 --> Language Class Initialized
INFO - 2021-06-28 04:26:32 --> Config Class Initialized
INFO - 2021-06-28 04:26:32 --> Loader Class Initialized
INFO - 2021-06-28 04:26:32 --> Helper loaded: url_helper
INFO - 2021-06-28 04:26:32 --> Helper loaded: file_helper
INFO - 2021-06-28 04:26:32 --> Helper loaded: form_helper
INFO - 2021-06-28 04:26:32 --> Helper loaded: my_helper
INFO - 2021-06-28 04:26:32 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:26:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:26:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:26:32 --> Controller Class Initialized
DEBUG - 2021-06-28 04:26:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form_import.php
DEBUG - 2021-06-28 04:26:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 04:26:32 --> Final output sent to browser
DEBUG - 2021-06-28 04:26:32 --> Total execution time: 0.0526
INFO - 2021-06-28 04:26:37 --> Config Class Initialized
INFO - 2021-06-28 04:26:37 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:26:37 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:26:37 --> Utf8 Class Initialized
INFO - 2021-06-28 04:26:37 --> URI Class Initialized
INFO - 2021-06-28 04:26:37 --> Router Class Initialized
INFO - 2021-06-28 04:26:37 --> Output Class Initialized
INFO - 2021-06-28 04:26:37 --> Security Class Initialized
DEBUG - 2021-06-28 04:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:26:37 --> Input Class Initialized
INFO - 2021-06-28 04:26:37 --> Language Class Initialized
INFO - 2021-06-28 04:26:37 --> Language Class Initialized
INFO - 2021-06-28 04:26:37 --> Config Class Initialized
INFO - 2021-06-28 04:26:37 --> Loader Class Initialized
INFO - 2021-06-28 04:26:37 --> Helper loaded: url_helper
INFO - 2021-06-28 04:26:37 --> Helper loaded: file_helper
INFO - 2021-06-28 04:26:37 --> Helper loaded: form_helper
INFO - 2021-06-28 04:26:37 --> Helper loaded: my_helper
INFO - 2021-06-28 04:26:37 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:26:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:26:37 --> Controller Class Initialized
INFO - 2021-06-28 04:26:40 --> Config Class Initialized
INFO - 2021-06-28 04:26:40 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:26:40 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:26:40 --> Utf8 Class Initialized
INFO - 2021-06-28 04:26:40 --> URI Class Initialized
INFO - 2021-06-28 04:26:40 --> Router Class Initialized
INFO - 2021-06-28 04:26:40 --> Output Class Initialized
INFO - 2021-06-28 04:26:40 --> Security Class Initialized
DEBUG - 2021-06-28 04:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:26:40 --> Input Class Initialized
INFO - 2021-06-28 04:26:40 --> Language Class Initialized
INFO - 2021-06-28 04:26:40 --> Language Class Initialized
INFO - 2021-06-28 04:26:40 --> Config Class Initialized
INFO - 2021-06-28 04:26:40 --> Loader Class Initialized
INFO - 2021-06-28 04:26:40 --> Helper loaded: url_helper
INFO - 2021-06-28 04:26:40 --> Helper loaded: file_helper
INFO - 2021-06-28 04:26:40 --> Helper loaded: form_helper
INFO - 2021-06-28 04:26:40 --> Helper loaded: my_helper
INFO - 2021-06-28 04:26:40 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:26:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:26:40 --> Controller Class Initialized
DEBUG - 2021-06-28 04:26:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form_import.php
DEBUG - 2021-06-28 04:26:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 04:26:40 --> Final output sent to browser
DEBUG - 2021-06-28 04:26:40 --> Total execution time: 0.0390
INFO - 2021-06-28 04:26:43 --> Config Class Initialized
INFO - 2021-06-28 04:26:43 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:26:43 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:26:43 --> Utf8 Class Initialized
INFO - 2021-06-28 04:26:43 --> URI Class Initialized
INFO - 2021-06-28 04:26:43 --> Router Class Initialized
INFO - 2021-06-28 04:26:43 --> Output Class Initialized
INFO - 2021-06-28 04:26:43 --> Security Class Initialized
DEBUG - 2021-06-28 04:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:26:43 --> Input Class Initialized
INFO - 2021-06-28 04:26:43 --> Language Class Initialized
INFO - 2021-06-28 04:26:43 --> Language Class Initialized
INFO - 2021-06-28 04:26:43 --> Config Class Initialized
INFO - 2021-06-28 04:26:43 --> Loader Class Initialized
INFO - 2021-06-28 04:26:43 --> Helper loaded: url_helper
INFO - 2021-06-28 04:26:43 --> Helper loaded: file_helper
INFO - 2021-06-28 04:26:43 --> Helper loaded: form_helper
INFO - 2021-06-28 04:26:43 --> Helper loaded: my_helper
INFO - 2021-06-28 04:26:43 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:26:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:26:43 --> Controller Class Initialized
DEBUG - 2021-06-28 04:26:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-06-28 04:26:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 04:26:43 --> Final output sent to browser
DEBUG - 2021-06-28 04:26:43 --> Total execution time: 0.0487
INFO - 2021-06-28 04:26:43 --> Config Class Initialized
INFO - 2021-06-28 04:26:43 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:26:43 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:26:43 --> Utf8 Class Initialized
INFO - 2021-06-28 04:26:43 --> URI Class Initialized
INFO - 2021-06-28 04:26:43 --> Router Class Initialized
INFO - 2021-06-28 04:26:43 --> Output Class Initialized
INFO - 2021-06-28 04:26:43 --> Security Class Initialized
DEBUG - 2021-06-28 04:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:26:43 --> Input Class Initialized
INFO - 2021-06-28 04:26:43 --> Language Class Initialized
INFO - 2021-06-28 04:26:43 --> Language Class Initialized
INFO - 2021-06-28 04:26:43 --> Config Class Initialized
INFO - 2021-06-28 04:26:43 --> Loader Class Initialized
INFO - 2021-06-28 04:26:43 --> Helper loaded: url_helper
INFO - 2021-06-28 04:26:43 --> Helper loaded: file_helper
INFO - 2021-06-28 04:26:43 --> Helper loaded: form_helper
INFO - 2021-06-28 04:26:43 --> Helper loaded: my_helper
INFO - 2021-06-28 04:26:43 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:26:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:26:43 --> Controller Class Initialized
INFO - 2021-06-28 04:26:48 --> Config Class Initialized
INFO - 2021-06-28 04:26:48 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:26:48 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:26:48 --> Utf8 Class Initialized
INFO - 2021-06-28 04:26:48 --> URI Class Initialized
INFO - 2021-06-28 04:26:48 --> Router Class Initialized
INFO - 2021-06-28 04:26:48 --> Output Class Initialized
INFO - 2021-06-28 04:26:48 --> Security Class Initialized
DEBUG - 2021-06-28 04:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:26:48 --> Input Class Initialized
INFO - 2021-06-28 04:26:48 --> Language Class Initialized
INFO - 2021-06-28 04:26:48 --> Language Class Initialized
INFO - 2021-06-28 04:26:48 --> Config Class Initialized
INFO - 2021-06-28 04:26:48 --> Loader Class Initialized
INFO - 2021-06-28 04:26:48 --> Helper loaded: url_helper
INFO - 2021-06-28 04:26:48 --> Helper loaded: file_helper
INFO - 2021-06-28 04:26:48 --> Helper loaded: form_helper
INFO - 2021-06-28 04:26:48 --> Helper loaded: my_helper
INFO - 2021-06-28 04:26:48 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:26:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:26:48 --> Controller Class Initialized
INFO - 2021-06-28 04:26:49 --> Config Class Initialized
INFO - 2021-06-28 04:26:49 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:26:49 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:26:49 --> Utf8 Class Initialized
INFO - 2021-06-28 04:26:49 --> URI Class Initialized
INFO - 2021-06-28 04:26:49 --> Router Class Initialized
INFO - 2021-06-28 04:26:49 --> Output Class Initialized
INFO - 2021-06-28 04:26:49 --> Security Class Initialized
DEBUG - 2021-06-28 04:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:26:49 --> Input Class Initialized
INFO - 2021-06-28 04:26:49 --> Language Class Initialized
INFO - 2021-06-28 04:26:49 --> Language Class Initialized
INFO - 2021-06-28 04:26:49 --> Config Class Initialized
INFO - 2021-06-28 04:26:49 --> Loader Class Initialized
INFO - 2021-06-28 04:26:49 --> Helper loaded: url_helper
INFO - 2021-06-28 04:26:49 --> Helper loaded: file_helper
INFO - 2021-06-28 04:26:49 --> Helper loaded: form_helper
INFO - 2021-06-28 04:26:49 --> Helper loaded: my_helper
INFO - 2021-06-28 04:26:49 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:26:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:26:49 --> Controller Class Initialized
DEBUG - 2021-06-28 04:26:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form_import.php
DEBUG - 2021-06-28 04:26:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 04:26:49 --> Final output sent to browser
DEBUG - 2021-06-28 04:26:49 --> Total execution time: 0.0403
INFO - 2021-06-28 04:26:52 --> Config Class Initialized
INFO - 2021-06-28 04:26:52 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:26:52 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:26:52 --> Utf8 Class Initialized
INFO - 2021-06-28 04:26:52 --> URI Class Initialized
INFO - 2021-06-28 04:26:52 --> Router Class Initialized
INFO - 2021-06-28 04:26:52 --> Output Class Initialized
INFO - 2021-06-28 04:26:52 --> Security Class Initialized
DEBUG - 2021-06-28 04:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:26:52 --> Input Class Initialized
INFO - 2021-06-28 04:26:52 --> Language Class Initialized
INFO - 2021-06-28 04:26:52 --> Language Class Initialized
INFO - 2021-06-28 04:26:52 --> Config Class Initialized
INFO - 2021-06-28 04:26:52 --> Loader Class Initialized
INFO - 2021-06-28 04:26:52 --> Helper loaded: url_helper
INFO - 2021-06-28 04:26:52 --> Helper loaded: file_helper
INFO - 2021-06-28 04:26:52 --> Helper loaded: form_helper
INFO - 2021-06-28 04:26:52 --> Helper loaded: my_helper
INFO - 2021-06-28 04:26:52 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:26:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:26:52 --> Controller Class Initialized
INFO - 2021-06-28 04:26:55 --> Config Class Initialized
INFO - 2021-06-28 04:26:55 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:26:55 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:26:55 --> Utf8 Class Initialized
INFO - 2021-06-28 04:26:55 --> URI Class Initialized
INFO - 2021-06-28 04:26:55 --> Router Class Initialized
INFO - 2021-06-28 04:26:55 --> Output Class Initialized
INFO - 2021-06-28 04:26:55 --> Security Class Initialized
DEBUG - 2021-06-28 04:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:26:55 --> Input Class Initialized
INFO - 2021-06-28 04:26:55 --> Language Class Initialized
INFO - 2021-06-28 04:26:55 --> Language Class Initialized
INFO - 2021-06-28 04:26:55 --> Config Class Initialized
INFO - 2021-06-28 04:26:55 --> Loader Class Initialized
INFO - 2021-06-28 04:26:55 --> Helper loaded: url_helper
INFO - 2021-06-28 04:26:55 --> Helper loaded: file_helper
INFO - 2021-06-28 04:26:55 --> Helper loaded: form_helper
INFO - 2021-06-28 04:26:55 --> Helper loaded: my_helper
INFO - 2021-06-28 04:26:55 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:26:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:26:55 --> Controller Class Initialized
DEBUG - 2021-06-28 04:26:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form_import.php
DEBUG - 2021-06-28 04:26:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 04:26:55 --> Final output sent to browser
DEBUG - 2021-06-28 04:26:55 --> Total execution time: 0.0491
INFO - 2021-06-28 04:26:59 --> Config Class Initialized
INFO - 2021-06-28 04:26:59 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:26:59 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:26:59 --> Utf8 Class Initialized
INFO - 2021-06-28 04:26:59 --> URI Class Initialized
INFO - 2021-06-28 04:26:59 --> Router Class Initialized
INFO - 2021-06-28 04:26:59 --> Output Class Initialized
INFO - 2021-06-28 04:26:59 --> Security Class Initialized
DEBUG - 2021-06-28 04:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:26:59 --> Input Class Initialized
INFO - 2021-06-28 04:26:59 --> Language Class Initialized
INFO - 2021-06-28 04:26:59 --> Language Class Initialized
INFO - 2021-06-28 04:26:59 --> Config Class Initialized
INFO - 2021-06-28 04:26:59 --> Loader Class Initialized
INFO - 2021-06-28 04:26:59 --> Helper loaded: url_helper
INFO - 2021-06-28 04:26:59 --> Helper loaded: file_helper
INFO - 2021-06-28 04:26:59 --> Helper loaded: form_helper
INFO - 2021-06-28 04:26:59 --> Helper loaded: my_helper
INFO - 2021-06-28 04:26:59 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:26:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:26:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:26:59 --> Controller Class Initialized
DEBUG - 2021-06-28 04:26:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-06-28 04:26:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 04:26:59 --> Final output sent to browser
DEBUG - 2021-06-28 04:26:59 --> Total execution time: 0.0396
INFO - 2021-06-28 04:27:00 --> Config Class Initialized
INFO - 2021-06-28 04:27:00 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:27:00 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:27:00 --> Utf8 Class Initialized
INFO - 2021-06-28 04:27:00 --> URI Class Initialized
INFO - 2021-06-28 04:27:00 --> Router Class Initialized
INFO - 2021-06-28 04:27:00 --> Output Class Initialized
INFO - 2021-06-28 04:27:00 --> Security Class Initialized
DEBUG - 2021-06-28 04:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:27:00 --> Input Class Initialized
INFO - 2021-06-28 04:27:00 --> Language Class Initialized
INFO - 2021-06-28 04:27:00 --> Language Class Initialized
INFO - 2021-06-28 04:27:00 --> Config Class Initialized
INFO - 2021-06-28 04:27:00 --> Loader Class Initialized
INFO - 2021-06-28 04:27:00 --> Helper loaded: url_helper
INFO - 2021-06-28 04:27:00 --> Helper loaded: file_helper
INFO - 2021-06-28 04:27:00 --> Helper loaded: form_helper
INFO - 2021-06-28 04:27:00 --> Helper loaded: my_helper
INFO - 2021-06-28 04:27:00 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:27:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:27:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:27:00 --> Controller Class Initialized
INFO - 2021-06-28 04:27:02 --> Config Class Initialized
INFO - 2021-06-28 04:27:02 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:27:02 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:27:02 --> Utf8 Class Initialized
INFO - 2021-06-28 04:27:02 --> URI Class Initialized
INFO - 2021-06-28 04:27:02 --> Router Class Initialized
INFO - 2021-06-28 04:27:02 --> Output Class Initialized
INFO - 2021-06-28 04:27:02 --> Security Class Initialized
DEBUG - 2021-06-28 04:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:27:02 --> Input Class Initialized
INFO - 2021-06-28 04:27:02 --> Language Class Initialized
INFO - 2021-06-28 04:27:02 --> Language Class Initialized
INFO - 2021-06-28 04:27:02 --> Config Class Initialized
INFO - 2021-06-28 04:27:02 --> Loader Class Initialized
INFO - 2021-06-28 04:27:02 --> Helper loaded: url_helper
INFO - 2021-06-28 04:27:02 --> Helper loaded: file_helper
INFO - 2021-06-28 04:27:02 --> Helper loaded: form_helper
INFO - 2021-06-28 04:27:02 --> Helper loaded: my_helper
INFO - 2021-06-28 04:27:02 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:27:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:27:02 --> Controller Class Initialized
INFO - 2021-06-28 04:27:37 --> Config Class Initialized
INFO - 2021-06-28 04:27:37 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:27:37 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:27:37 --> Utf8 Class Initialized
INFO - 2021-06-28 04:27:37 --> URI Class Initialized
INFO - 2021-06-28 04:27:37 --> Router Class Initialized
INFO - 2021-06-28 04:27:37 --> Output Class Initialized
INFO - 2021-06-28 04:27:37 --> Security Class Initialized
DEBUG - 2021-06-28 04:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:27:37 --> Input Class Initialized
INFO - 2021-06-28 04:27:37 --> Language Class Initialized
INFO - 2021-06-28 04:27:37 --> Language Class Initialized
INFO - 2021-06-28 04:27:37 --> Config Class Initialized
INFO - 2021-06-28 04:27:37 --> Loader Class Initialized
INFO - 2021-06-28 04:27:37 --> Helper loaded: url_helper
INFO - 2021-06-28 04:27:37 --> Helper loaded: file_helper
INFO - 2021-06-28 04:27:37 --> Helper loaded: form_helper
INFO - 2021-06-28 04:27:37 --> Helper loaded: my_helper
INFO - 2021-06-28 04:27:37 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:27:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:27:37 --> Controller Class Initialized
DEBUG - 2021-06-28 04:27:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form_import.php
DEBUG - 2021-06-28 04:27:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 04:27:37 --> Final output sent to browser
DEBUG - 2021-06-28 04:27:37 --> Total execution time: 0.0509
INFO - 2021-06-28 04:27:41 --> Config Class Initialized
INFO - 2021-06-28 04:27:41 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:27:41 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:27:41 --> Utf8 Class Initialized
INFO - 2021-06-28 04:27:41 --> URI Class Initialized
INFO - 2021-06-28 04:27:41 --> Router Class Initialized
INFO - 2021-06-28 04:27:41 --> Output Class Initialized
INFO - 2021-06-28 04:27:41 --> Security Class Initialized
DEBUG - 2021-06-28 04:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:27:41 --> Input Class Initialized
INFO - 2021-06-28 04:27:41 --> Language Class Initialized
INFO - 2021-06-28 04:27:41 --> Language Class Initialized
INFO - 2021-06-28 04:27:41 --> Config Class Initialized
INFO - 2021-06-28 04:27:41 --> Loader Class Initialized
INFO - 2021-06-28 04:27:41 --> Helper loaded: url_helper
INFO - 2021-06-28 04:27:41 --> Helper loaded: file_helper
INFO - 2021-06-28 04:27:41 --> Helper loaded: form_helper
INFO - 2021-06-28 04:27:41 --> Helper loaded: my_helper
INFO - 2021-06-28 04:27:41 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:27:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:27:41 --> Controller Class Initialized
INFO - 2021-06-28 04:27:43 --> Config Class Initialized
INFO - 2021-06-28 04:27:43 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:27:43 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:27:43 --> Utf8 Class Initialized
INFO - 2021-06-28 04:27:43 --> URI Class Initialized
INFO - 2021-06-28 04:27:43 --> Router Class Initialized
INFO - 2021-06-28 04:27:43 --> Output Class Initialized
INFO - 2021-06-28 04:27:43 --> Security Class Initialized
DEBUG - 2021-06-28 04:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:27:43 --> Input Class Initialized
INFO - 2021-06-28 04:27:43 --> Language Class Initialized
INFO - 2021-06-28 04:27:43 --> Language Class Initialized
INFO - 2021-06-28 04:27:43 --> Config Class Initialized
INFO - 2021-06-28 04:27:43 --> Loader Class Initialized
INFO - 2021-06-28 04:27:43 --> Helper loaded: url_helper
INFO - 2021-06-28 04:27:43 --> Helper loaded: file_helper
INFO - 2021-06-28 04:27:43 --> Helper loaded: form_helper
INFO - 2021-06-28 04:27:43 --> Helper loaded: my_helper
INFO - 2021-06-28 04:27:43 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:27:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:27:43 --> Controller Class Initialized
DEBUG - 2021-06-28 04:27:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form_import.php
DEBUG - 2021-06-28 04:27:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 04:27:43 --> Final output sent to browser
DEBUG - 2021-06-28 04:27:43 --> Total execution time: 0.0479
INFO - 2021-06-28 04:27:46 --> Config Class Initialized
INFO - 2021-06-28 04:27:46 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:27:46 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:27:46 --> Utf8 Class Initialized
INFO - 2021-06-28 04:27:46 --> URI Class Initialized
INFO - 2021-06-28 04:27:46 --> Router Class Initialized
INFO - 2021-06-28 04:27:46 --> Output Class Initialized
INFO - 2021-06-28 04:27:46 --> Security Class Initialized
DEBUG - 2021-06-28 04:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:27:46 --> Input Class Initialized
INFO - 2021-06-28 04:27:46 --> Language Class Initialized
INFO - 2021-06-28 04:27:46 --> Language Class Initialized
INFO - 2021-06-28 04:27:46 --> Config Class Initialized
INFO - 2021-06-28 04:27:46 --> Loader Class Initialized
INFO - 2021-06-28 04:27:46 --> Helper loaded: url_helper
INFO - 2021-06-28 04:27:46 --> Helper loaded: file_helper
INFO - 2021-06-28 04:27:46 --> Helper loaded: form_helper
INFO - 2021-06-28 04:27:46 --> Helper loaded: my_helper
INFO - 2021-06-28 04:27:46 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:27:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:27:46 --> Controller Class Initialized
DEBUG - 2021-06-28 04:27:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-06-28 04:27:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 04:27:46 --> Final output sent to browser
DEBUG - 2021-06-28 04:27:46 --> Total execution time: 0.0501
INFO - 2021-06-28 04:27:46 --> Config Class Initialized
INFO - 2021-06-28 04:27:46 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:27:46 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:27:46 --> Utf8 Class Initialized
INFO - 2021-06-28 04:27:46 --> URI Class Initialized
INFO - 2021-06-28 04:27:46 --> Router Class Initialized
INFO - 2021-06-28 04:27:46 --> Output Class Initialized
INFO - 2021-06-28 04:27:46 --> Security Class Initialized
DEBUG - 2021-06-28 04:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:27:46 --> Input Class Initialized
INFO - 2021-06-28 04:27:46 --> Language Class Initialized
INFO - 2021-06-28 04:27:46 --> Language Class Initialized
INFO - 2021-06-28 04:27:46 --> Config Class Initialized
INFO - 2021-06-28 04:27:46 --> Loader Class Initialized
INFO - 2021-06-28 04:27:46 --> Helper loaded: url_helper
INFO - 2021-06-28 04:27:46 --> Helper loaded: file_helper
INFO - 2021-06-28 04:27:46 --> Helper loaded: form_helper
INFO - 2021-06-28 04:27:46 --> Helper loaded: my_helper
INFO - 2021-06-28 04:27:46 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:27:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:27:46 --> Controller Class Initialized
INFO - 2021-06-28 04:27:48 --> Config Class Initialized
INFO - 2021-06-28 04:27:48 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:27:48 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:27:48 --> Utf8 Class Initialized
INFO - 2021-06-28 04:27:48 --> URI Class Initialized
INFO - 2021-06-28 04:27:48 --> Router Class Initialized
INFO - 2021-06-28 04:27:48 --> Output Class Initialized
INFO - 2021-06-28 04:27:48 --> Security Class Initialized
DEBUG - 2021-06-28 04:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:27:48 --> Input Class Initialized
INFO - 2021-06-28 04:27:48 --> Language Class Initialized
INFO - 2021-06-28 04:27:48 --> Language Class Initialized
INFO - 2021-06-28 04:27:48 --> Config Class Initialized
INFO - 2021-06-28 04:27:48 --> Loader Class Initialized
INFO - 2021-06-28 04:27:48 --> Helper loaded: url_helper
INFO - 2021-06-28 04:27:48 --> Helper loaded: file_helper
INFO - 2021-06-28 04:27:48 --> Helper loaded: form_helper
INFO - 2021-06-28 04:27:48 --> Helper loaded: my_helper
INFO - 2021-06-28 04:27:48 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:27:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:27:48 --> Controller Class Initialized
INFO - 2021-06-28 04:29:49 --> Config Class Initialized
INFO - 2021-06-28 04:29:49 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:29:49 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:29:49 --> Utf8 Class Initialized
INFO - 2021-06-28 04:29:49 --> URI Class Initialized
INFO - 2021-06-28 04:29:49 --> Router Class Initialized
INFO - 2021-06-28 04:29:49 --> Output Class Initialized
INFO - 2021-06-28 04:29:49 --> Security Class Initialized
DEBUG - 2021-06-28 04:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:29:49 --> Input Class Initialized
INFO - 2021-06-28 04:29:49 --> Language Class Initialized
INFO - 2021-06-28 04:29:49 --> Language Class Initialized
INFO - 2021-06-28 04:29:49 --> Config Class Initialized
INFO - 2021-06-28 04:29:49 --> Loader Class Initialized
INFO - 2021-06-28 04:29:49 --> Helper loaded: url_helper
INFO - 2021-06-28 04:29:49 --> Helper loaded: file_helper
INFO - 2021-06-28 04:29:49 --> Helper loaded: form_helper
INFO - 2021-06-28 04:29:49 --> Helper loaded: my_helper
INFO - 2021-06-28 04:29:49 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:29:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:29:49 --> Controller Class Initialized
DEBUG - 2021-06-28 04:29:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form_import.php
DEBUG - 2021-06-28 04:29:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 04:29:49 --> Final output sent to browser
DEBUG - 2021-06-28 04:29:49 --> Total execution time: 0.0498
INFO - 2021-06-28 04:29:52 --> Config Class Initialized
INFO - 2021-06-28 04:29:52 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:29:52 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:29:52 --> Utf8 Class Initialized
INFO - 2021-06-28 04:29:52 --> URI Class Initialized
INFO - 2021-06-28 04:29:52 --> Router Class Initialized
INFO - 2021-06-28 04:29:52 --> Output Class Initialized
INFO - 2021-06-28 04:29:52 --> Security Class Initialized
DEBUG - 2021-06-28 04:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:29:52 --> Input Class Initialized
INFO - 2021-06-28 04:29:52 --> Language Class Initialized
INFO - 2021-06-28 04:29:52 --> Language Class Initialized
INFO - 2021-06-28 04:29:52 --> Config Class Initialized
INFO - 2021-06-28 04:29:52 --> Loader Class Initialized
INFO - 2021-06-28 04:29:52 --> Helper loaded: url_helper
INFO - 2021-06-28 04:29:52 --> Helper loaded: file_helper
INFO - 2021-06-28 04:29:52 --> Helper loaded: form_helper
INFO - 2021-06-28 04:29:52 --> Helper loaded: my_helper
INFO - 2021-06-28 04:29:52 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:29:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:29:52 --> Controller Class Initialized
INFO - 2021-06-28 04:29:55 --> Config Class Initialized
INFO - 2021-06-28 04:29:55 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:29:55 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:29:55 --> Utf8 Class Initialized
INFO - 2021-06-28 04:29:55 --> URI Class Initialized
INFO - 2021-06-28 04:29:55 --> Router Class Initialized
INFO - 2021-06-28 04:29:55 --> Output Class Initialized
INFO - 2021-06-28 04:29:55 --> Security Class Initialized
DEBUG - 2021-06-28 04:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:29:55 --> Input Class Initialized
INFO - 2021-06-28 04:29:55 --> Language Class Initialized
INFO - 2021-06-28 04:29:55 --> Language Class Initialized
INFO - 2021-06-28 04:29:55 --> Config Class Initialized
INFO - 2021-06-28 04:29:55 --> Loader Class Initialized
INFO - 2021-06-28 04:29:55 --> Helper loaded: url_helper
INFO - 2021-06-28 04:29:55 --> Helper loaded: file_helper
INFO - 2021-06-28 04:29:55 --> Helper loaded: form_helper
INFO - 2021-06-28 04:29:55 --> Helper loaded: my_helper
INFO - 2021-06-28 04:29:55 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:29:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:29:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:29:55 --> Controller Class Initialized
DEBUG - 2021-06-28 04:29:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form_import.php
DEBUG - 2021-06-28 04:29:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 04:29:55 --> Final output sent to browser
DEBUG - 2021-06-28 04:29:55 --> Total execution time: 0.0484
INFO - 2021-06-28 04:29:56 --> Config Class Initialized
INFO - 2021-06-28 04:29:56 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:29:56 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:29:56 --> Utf8 Class Initialized
INFO - 2021-06-28 04:29:56 --> URI Class Initialized
INFO - 2021-06-28 04:29:56 --> Router Class Initialized
INFO - 2021-06-28 04:29:56 --> Output Class Initialized
INFO - 2021-06-28 04:29:56 --> Security Class Initialized
DEBUG - 2021-06-28 04:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:29:56 --> Input Class Initialized
INFO - 2021-06-28 04:29:56 --> Language Class Initialized
INFO - 2021-06-28 04:29:56 --> Language Class Initialized
INFO - 2021-06-28 04:29:56 --> Config Class Initialized
INFO - 2021-06-28 04:29:56 --> Loader Class Initialized
INFO - 2021-06-28 04:29:56 --> Helper loaded: url_helper
INFO - 2021-06-28 04:29:56 --> Helper loaded: file_helper
INFO - 2021-06-28 04:29:56 --> Helper loaded: form_helper
INFO - 2021-06-28 04:29:56 --> Helper loaded: my_helper
INFO - 2021-06-28 04:29:56 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:29:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:29:56 --> Controller Class Initialized
DEBUG - 2021-06-28 04:29:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-06-28 04:29:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 04:29:56 --> Final output sent to browser
DEBUG - 2021-06-28 04:29:56 --> Total execution time: 0.0491
INFO - 2021-06-28 04:29:56 --> Config Class Initialized
INFO - 2021-06-28 04:29:56 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:29:56 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:29:56 --> Utf8 Class Initialized
INFO - 2021-06-28 04:29:56 --> URI Class Initialized
INFO - 2021-06-28 04:29:56 --> Router Class Initialized
INFO - 2021-06-28 04:29:56 --> Output Class Initialized
INFO - 2021-06-28 04:29:56 --> Security Class Initialized
DEBUG - 2021-06-28 04:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:29:56 --> Input Class Initialized
INFO - 2021-06-28 04:29:56 --> Language Class Initialized
INFO - 2021-06-28 04:29:56 --> Language Class Initialized
INFO - 2021-06-28 04:29:56 --> Config Class Initialized
INFO - 2021-06-28 04:29:56 --> Loader Class Initialized
INFO - 2021-06-28 04:29:56 --> Helper loaded: url_helper
INFO - 2021-06-28 04:29:56 --> Helper loaded: file_helper
INFO - 2021-06-28 04:29:56 --> Helper loaded: form_helper
INFO - 2021-06-28 04:29:56 --> Helper loaded: my_helper
INFO - 2021-06-28 04:29:56 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:29:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:29:56 --> Controller Class Initialized
INFO - 2021-06-28 04:29:58 --> Config Class Initialized
INFO - 2021-06-28 04:29:58 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:29:58 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:29:58 --> Utf8 Class Initialized
INFO - 2021-06-28 04:29:58 --> URI Class Initialized
INFO - 2021-06-28 04:29:58 --> Router Class Initialized
INFO - 2021-06-28 04:29:58 --> Output Class Initialized
INFO - 2021-06-28 04:29:58 --> Security Class Initialized
DEBUG - 2021-06-28 04:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:29:58 --> Input Class Initialized
INFO - 2021-06-28 04:29:58 --> Language Class Initialized
INFO - 2021-06-28 04:29:58 --> Language Class Initialized
INFO - 2021-06-28 04:29:58 --> Config Class Initialized
INFO - 2021-06-28 04:29:58 --> Loader Class Initialized
INFO - 2021-06-28 04:29:58 --> Helper loaded: url_helper
INFO - 2021-06-28 04:29:58 --> Helper loaded: file_helper
INFO - 2021-06-28 04:29:58 --> Helper loaded: form_helper
INFO - 2021-06-28 04:29:58 --> Helper loaded: my_helper
INFO - 2021-06-28 04:29:58 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:29:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:29:58 --> Controller Class Initialized
INFO - 2021-06-28 04:30:30 --> Config Class Initialized
INFO - 2021-06-28 04:30:30 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:30:30 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:30:30 --> Utf8 Class Initialized
INFO - 2021-06-28 04:30:30 --> URI Class Initialized
INFO - 2021-06-28 04:30:30 --> Router Class Initialized
INFO - 2021-06-28 04:30:30 --> Output Class Initialized
INFO - 2021-06-28 04:30:30 --> Security Class Initialized
DEBUG - 2021-06-28 04:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:30:30 --> Input Class Initialized
INFO - 2021-06-28 04:30:30 --> Language Class Initialized
INFO - 2021-06-28 04:30:30 --> Language Class Initialized
INFO - 2021-06-28 04:30:30 --> Config Class Initialized
INFO - 2021-06-28 04:30:30 --> Loader Class Initialized
INFO - 2021-06-28 04:30:30 --> Helper loaded: url_helper
INFO - 2021-06-28 04:30:30 --> Helper loaded: file_helper
INFO - 2021-06-28 04:30:30 --> Helper loaded: form_helper
INFO - 2021-06-28 04:30:30 --> Helper loaded: my_helper
INFO - 2021-06-28 04:30:30 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:30:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:30:30 --> Controller Class Initialized
DEBUG - 2021-06-28 04:30:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form_import.php
DEBUG - 2021-06-28 04:30:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 04:30:30 --> Final output sent to browser
DEBUG - 2021-06-28 04:30:30 --> Total execution time: 0.0494
INFO - 2021-06-28 04:30:33 --> Config Class Initialized
INFO - 2021-06-28 04:30:33 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:30:33 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:30:33 --> Utf8 Class Initialized
INFO - 2021-06-28 04:30:33 --> URI Class Initialized
INFO - 2021-06-28 04:30:33 --> Router Class Initialized
INFO - 2021-06-28 04:30:33 --> Output Class Initialized
INFO - 2021-06-28 04:30:33 --> Security Class Initialized
DEBUG - 2021-06-28 04:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:30:33 --> Input Class Initialized
INFO - 2021-06-28 04:30:33 --> Language Class Initialized
INFO - 2021-06-28 04:30:33 --> Language Class Initialized
INFO - 2021-06-28 04:30:33 --> Config Class Initialized
INFO - 2021-06-28 04:30:33 --> Loader Class Initialized
INFO - 2021-06-28 04:30:33 --> Helper loaded: url_helper
INFO - 2021-06-28 04:30:33 --> Helper loaded: file_helper
INFO - 2021-06-28 04:30:33 --> Helper loaded: form_helper
INFO - 2021-06-28 04:30:33 --> Helper loaded: my_helper
INFO - 2021-06-28 04:30:33 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:30:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:30:33 --> Controller Class Initialized
INFO - 2021-06-28 04:30:36 --> Config Class Initialized
INFO - 2021-06-28 04:30:36 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:30:36 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:30:36 --> Utf8 Class Initialized
INFO - 2021-06-28 04:30:36 --> URI Class Initialized
INFO - 2021-06-28 04:30:36 --> Router Class Initialized
INFO - 2021-06-28 04:30:36 --> Output Class Initialized
INFO - 2021-06-28 04:30:36 --> Security Class Initialized
DEBUG - 2021-06-28 04:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:30:36 --> Input Class Initialized
INFO - 2021-06-28 04:30:36 --> Language Class Initialized
INFO - 2021-06-28 04:30:36 --> Language Class Initialized
INFO - 2021-06-28 04:30:36 --> Config Class Initialized
INFO - 2021-06-28 04:30:36 --> Loader Class Initialized
INFO - 2021-06-28 04:30:36 --> Helper loaded: url_helper
INFO - 2021-06-28 04:30:36 --> Helper loaded: file_helper
INFO - 2021-06-28 04:30:36 --> Helper loaded: form_helper
INFO - 2021-06-28 04:30:36 --> Helper loaded: my_helper
INFO - 2021-06-28 04:30:36 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:30:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:30:36 --> Controller Class Initialized
DEBUG - 2021-06-28 04:30:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form_import.php
DEBUG - 2021-06-28 04:30:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 04:30:36 --> Final output sent to browser
DEBUG - 2021-06-28 04:30:36 --> Total execution time: 0.0502
INFO - 2021-06-28 04:30:37 --> Config Class Initialized
INFO - 2021-06-28 04:30:37 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:30:37 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:30:37 --> Utf8 Class Initialized
INFO - 2021-06-28 04:30:37 --> URI Class Initialized
INFO - 2021-06-28 04:30:37 --> Router Class Initialized
INFO - 2021-06-28 04:30:37 --> Output Class Initialized
INFO - 2021-06-28 04:30:37 --> Security Class Initialized
DEBUG - 2021-06-28 04:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:30:37 --> Input Class Initialized
INFO - 2021-06-28 04:30:37 --> Language Class Initialized
INFO - 2021-06-28 04:30:37 --> Language Class Initialized
INFO - 2021-06-28 04:30:38 --> Config Class Initialized
INFO - 2021-06-28 04:30:38 --> Loader Class Initialized
INFO - 2021-06-28 04:30:38 --> Helper loaded: url_helper
INFO - 2021-06-28 04:30:38 --> Helper loaded: file_helper
INFO - 2021-06-28 04:30:38 --> Helper loaded: form_helper
INFO - 2021-06-28 04:30:38 --> Helper loaded: my_helper
INFO - 2021-06-28 04:30:38 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:30:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:30:38 --> Controller Class Initialized
DEBUG - 2021-06-28 04:30:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-06-28 04:30:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 04:30:38 --> Final output sent to browser
DEBUG - 2021-06-28 04:30:38 --> Total execution time: 0.0398
INFO - 2021-06-28 04:30:38 --> Config Class Initialized
INFO - 2021-06-28 04:30:38 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:30:38 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:30:38 --> Utf8 Class Initialized
INFO - 2021-06-28 04:30:38 --> URI Class Initialized
INFO - 2021-06-28 04:30:38 --> Router Class Initialized
INFO - 2021-06-28 04:30:38 --> Output Class Initialized
INFO - 2021-06-28 04:30:38 --> Security Class Initialized
DEBUG - 2021-06-28 04:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:30:38 --> Input Class Initialized
INFO - 2021-06-28 04:30:38 --> Language Class Initialized
INFO - 2021-06-28 04:30:38 --> Language Class Initialized
INFO - 2021-06-28 04:30:38 --> Config Class Initialized
INFO - 2021-06-28 04:30:38 --> Loader Class Initialized
INFO - 2021-06-28 04:30:38 --> Helper loaded: url_helper
INFO - 2021-06-28 04:30:38 --> Helper loaded: file_helper
INFO - 2021-06-28 04:30:38 --> Helper loaded: form_helper
INFO - 2021-06-28 04:30:38 --> Helper loaded: my_helper
INFO - 2021-06-28 04:30:38 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:30:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:30:38 --> Controller Class Initialized
INFO - 2021-06-28 04:30:40 --> Config Class Initialized
INFO - 2021-06-28 04:30:40 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:30:40 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:30:40 --> Utf8 Class Initialized
INFO - 2021-06-28 04:30:40 --> URI Class Initialized
INFO - 2021-06-28 04:30:40 --> Router Class Initialized
INFO - 2021-06-28 04:30:40 --> Output Class Initialized
INFO - 2021-06-28 04:30:40 --> Security Class Initialized
DEBUG - 2021-06-28 04:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:30:40 --> Input Class Initialized
INFO - 2021-06-28 04:30:40 --> Language Class Initialized
INFO - 2021-06-28 04:30:40 --> Language Class Initialized
INFO - 2021-06-28 04:30:40 --> Config Class Initialized
INFO - 2021-06-28 04:30:40 --> Loader Class Initialized
INFO - 2021-06-28 04:30:40 --> Helper loaded: url_helper
INFO - 2021-06-28 04:30:40 --> Helper loaded: file_helper
INFO - 2021-06-28 04:30:40 --> Helper loaded: form_helper
INFO - 2021-06-28 04:30:40 --> Helper loaded: my_helper
INFO - 2021-06-28 04:30:40 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:30:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:30:40 --> Controller Class Initialized
INFO - 2021-06-28 04:31:00 --> Config Class Initialized
INFO - 2021-06-28 04:31:00 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:31:00 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:31:00 --> Utf8 Class Initialized
INFO - 2021-06-28 04:31:00 --> URI Class Initialized
INFO - 2021-06-28 04:31:00 --> Router Class Initialized
INFO - 2021-06-28 04:31:00 --> Output Class Initialized
INFO - 2021-06-28 04:31:00 --> Security Class Initialized
DEBUG - 2021-06-28 04:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:31:00 --> Input Class Initialized
INFO - 2021-06-28 04:31:00 --> Language Class Initialized
INFO - 2021-06-28 04:31:00 --> Language Class Initialized
INFO - 2021-06-28 04:31:00 --> Config Class Initialized
INFO - 2021-06-28 04:31:00 --> Loader Class Initialized
INFO - 2021-06-28 04:31:00 --> Helper loaded: url_helper
INFO - 2021-06-28 04:31:00 --> Helper loaded: file_helper
INFO - 2021-06-28 04:31:00 --> Helper loaded: form_helper
INFO - 2021-06-28 04:31:00 --> Helper loaded: my_helper
INFO - 2021-06-28 04:31:00 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:31:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:31:00 --> Controller Class Initialized
INFO - 2021-06-28 04:32:08 --> Config Class Initialized
INFO - 2021-06-28 04:32:08 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:32:08 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:32:08 --> Utf8 Class Initialized
INFO - 2021-06-28 04:32:08 --> URI Class Initialized
INFO - 2021-06-28 04:32:08 --> Router Class Initialized
INFO - 2021-06-28 04:32:08 --> Output Class Initialized
INFO - 2021-06-28 04:32:08 --> Security Class Initialized
DEBUG - 2021-06-28 04:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:32:08 --> Input Class Initialized
INFO - 2021-06-28 04:32:08 --> Language Class Initialized
INFO - 2021-06-28 04:32:08 --> Language Class Initialized
INFO - 2021-06-28 04:32:08 --> Config Class Initialized
INFO - 2021-06-28 04:32:08 --> Loader Class Initialized
INFO - 2021-06-28 04:32:08 --> Helper loaded: url_helper
INFO - 2021-06-28 04:32:08 --> Helper loaded: file_helper
INFO - 2021-06-28 04:32:08 --> Helper loaded: form_helper
INFO - 2021-06-28 04:32:08 --> Helper loaded: my_helper
INFO - 2021-06-28 04:32:08 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:32:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:32:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:32:08 --> Controller Class Initialized
INFO - 2021-06-28 04:32:08 --> Helper loaded: cookie_helper
INFO - 2021-06-28 04:32:08 --> Config Class Initialized
INFO - 2021-06-28 04:32:08 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:32:08 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:32:08 --> Utf8 Class Initialized
INFO - 2021-06-28 04:32:08 --> URI Class Initialized
INFO - 2021-06-28 04:32:08 --> Router Class Initialized
INFO - 2021-06-28 04:32:08 --> Output Class Initialized
INFO - 2021-06-28 04:32:08 --> Security Class Initialized
DEBUG - 2021-06-28 04:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:32:08 --> Input Class Initialized
INFO - 2021-06-28 04:32:08 --> Language Class Initialized
INFO - 2021-06-28 04:32:08 --> Language Class Initialized
INFO - 2021-06-28 04:32:08 --> Config Class Initialized
INFO - 2021-06-28 04:32:08 --> Loader Class Initialized
INFO - 2021-06-28 04:32:08 --> Helper loaded: url_helper
INFO - 2021-06-28 04:32:08 --> Helper loaded: file_helper
INFO - 2021-06-28 04:32:08 --> Helper loaded: form_helper
INFO - 2021-06-28 04:32:08 --> Helper loaded: my_helper
INFO - 2021-06-28 04:32:08 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:32:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:32:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:32:08 --> Controller Class Initialized
DEBUG - 2021-06-28 04:32:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-28 04:32:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 04:32:08 --> Final output sent to browser
DEBUG - 2021-06-28 04:32:08 --> Total execution time: 0.0394
INFO - 2021-06-28 04:56:45 --> Config Class Initialized
INFO - 2021-06-28 04:56:45 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:56:45 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:56:45 --> Utf8 Class Initialized
INFO - 2021-06-28 04:56:45 --> URI Class Initialized
INFO - 2021-06-28 04:56:45 --> Router Class Initialized
INFO - 2021-06-28 04:56:45 --> Output Class Initialized
INFO - 2021-06-28 04:56:45 --> Security Class Initialized
DEBUG - 2021-06-28 04:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:56:45 --> Input Class Initialized
INFO - 2021-06-28 04:56:45 --> Language Class Initialized
INFO - 2021-06-28 04:56:45 --> Language Class Initialized
INFO - 2021-06-28 04:56:45 --> Config Class Initialized
INFO - 2021-06-28 04:56:45 --> Loader Class Initialized
INFO - 2021-06-28 04:56:45 --> Helper loaded: url_helper
INFO - 2021-06-28 04:56:45 --> Helper loaded: file_helper
INFO - 2021-06-28 04:56:45 --> Helper loaded: form_helper
INFO - 2021-06-28 04:56:45 --> Helper loaded: my_helper
INFO - 2021-06-28 04:56:45 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:56:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:56:45 --> Controller Class Initialized
INFO - 2021-06-28 04:56:45 --> Helper loaded: cookie_helper
INFO - 2021-06-28 04:56:45 --> Final output sent to browser
DEBUG - 2021-06-28 04:56:45 --> Total execution time: 0.0456
INFO - 2021-06-28 04:56:45 --> Config Class Initialized
INFO - 2021-06-28 04:56:45 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:56:45 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:56:45 --> Utf8 Class Initialized
INFO - 2021-06-28 04:56:45 --> URI Class Initialized
INFO - 2021-06-28 04:56:45 --> Router Class Initialized
INFO - 2021-06-28 04:56:45 --> Output Class Initialized
INFO - 2021-06-28 04:56:45 --> Security Class Initialized
DEBUG - 2021-06-28 04:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:56:45 --> Input Class Initialized
INFO - 2021-06-28 04:56:45 --> Language Class Initialized
INFO - 2021-06-28 04:56:45 --> Language Class Initialized
INFO - 2021-06-28 04:56:45 --> Config Class Initialized
INFO - 2021-06-28 04:56:45 --> Loader Class Initialized
INFO - 2021-06-28 04:56:45 --> Helper loaded: url_helper
INFO - 2021-06-28 04:56:45 --> Helper loaded: file_helper
INFO - 2021-06-28 04:56:45 --> Helper loaded: form_helper
INFO - 2021-06-28 04:56:45 --> Helper loaded: my_helper
INFO - 2021-06-28 04:56:45 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:56:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:56:45 --> Controller Class Initialized
DEBUG - 2021-06-28 04:56:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-28 04:56:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 04:56:46 --> Final output sent to browser
DEBUG - 2021-06-28 04:56:46 --> Total execution time: 0.6456
INFO - 2021-06-28 04:56:55 --> Config Class Initialized
INFO - 2021-06-28 04:56:55 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:56:55 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:56:55 --> Utf8 Class Initialized
INFO - 2021-06-28 04:56:55 --> URI Class Initialized
INFO - 2021-06-28 04:56:55 --> Router Class Initialized
INFO - 2021-06-28 04:56:55 --> Output Class Initialized
INFO - 2021-06-28 04:56:55 --> Security Class Initialized
DEBUG - 2021-06-28 04:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:56:55 --> Input Class Initialized
INFO - 2021-06-28 04:56:55 --> Language Class Initialized
INFO - 2021-06-28 04:56:55 --> Language Class Initialized
INFO - 2021-06-28 04:56:55 --> Config Class Initialized
INFO - 2021-06-28 04:56:55 --> Loader Class Initialized
INFO - 2021-06-28 04:56:55 --> Helper loaded: url_helper
INFO - 2021-06-28 04:56:55 --> Helper loaded: file_helper
INFO - 2021-06-28 04:56:55 --> Helper loaded: form_helper
INFO - 2021-06-28 04:56:55 --> Helper loaded: my_helper
INFO - 2021-06-28 04:56:55 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:56:55 --> Controller Class Initialized
DEBUG - 2021-06-28 04:56:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-06-28 04:56:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 04:56:55 --> Final output sent to browser
DEBUG - 2021-06-28 04:56:55 --> Total execution time: 0.0510
INFO - 2021-06-28 04:56:55 --> Config Class Initialized
INFO - 2021-06-28 04:56:55 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:56:55 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:56:55 --> Utf8 Class Initialized
INFO - 2021-06-28 04:56:55 --> URI Class Initialized
INFO - 2021-06-28 04:56:55 --> Router Class Initialized
INFO - 2021-06-28 04:56:55 --> Output Class Initialized
INFO - 2021-06-28 04:56:55 --> Security Class Initialized
DEBUG - 2021-06-28 04:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:56:55 --> Input Class Initialized
INFO - 2021-06-28 04:56:55 --> Language Class Initialized
INFO - 2021-06-28 04:56:55 --> Language Class Initialized
INFO - 2021-06-28 04:56:55 --> Config Class Initialized
INFO - 2021-06-28 04:56:55 --> Loader Class Initialized
INFO - 2021-06-28 04:56:55 --> Helper loaded: url_helper
INFO - 2021-06-28 04:56:55 --> Helper loaded: file_helper
INFO - 2021-06-28 04:56:55 --> Helper loaded: form_helper
INFO - 2021-06-28 04:56:55 --> Helper loaded: my_helper
INFO - 2021-06-28 04:56:55 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:56:55 --> Controller Class Initialized
INFO - 2021-06-28 04:56:57 --> Config Class Initialized
INFO - 2021-06-28 04:56:57 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:56:57 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:56:57 --> Utf8 Class Initialized
INFO - 2021-06-28 04:56:57 --> URI Class Initialized
INFO - 2021-06-28 04:56:57 --> Router Class Initialized
INFO - 2021-06-28 04:56:57 --> Output Class Initialized
INFO - 2021-06-28 04:56:57 --> Security Class Initialized
DEBUG - 2021-06-28 04:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:56:57 --> Input Class Initialized
INFO - 2021-06-28 04:56:57 --> Language Class Initialized
INFO - 2021-06-28 04:56:57 --> Language Class Initialized
INFO - 2021-06-28 04:56:57 --> Config Class Initialized
INFO - 2021-06-28 04:56:57 --> Loader Class Initialized
INFO - 2021-06-28 04:56:57 --> Helper loaded: url_helper
INFO - 2021-06-28 04:56:57 --> Helper loaded: file_helper
INFO - 2021-06-28 04:56:57 --> Helper loaded: form_helper
INFO - 2021-06-28 04:56:57 --> Helper loaded: my_helper
INFO - 2021-06-28 04:56:57 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:56:57 --> Controller Class Initialized
DEBUG - 2021-06-28 04:56:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form_import.php
DEBUG - 2021-06-28 04:56:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 04:56:57 --> Final output sent to browser
DEBUG - 2021-06-28 04:56:57 --> Total execution time: 0.0505
INFO - 2021-06-28 04:57:01 --> Config Class Initialized
INFO - 2021-06-28 04:57:01 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:57:01 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:57:01 --> Utf8 Class Initialized
INFO - 2021-06-28 04:57:01 --> URI Class Initialized
INFO - 2021-06-28 04:57:01 --> Router Class Initialized
INFO - 2021-06-28 04:57:01 --> Output Class Initialized
INFO - 2021-06-28 04:57:01 --> Security Class Initialized
DEBUG - 2021-06-28 04:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:57:01 --> Input Class Initialized
INFO - 2021-06-28 04:57:01 --> Language Class Initialized
INFO - 2021-06-28 04:57:01 --> Language Class Initialized
INFO - 2021-06-28 04:57:01 --> Config Class Initialized
INFO - 2021-06-28 04:57:01 --> Loader Class Initialized
INFO - 2021-06-28 04:57:01 --> Helper loaded: url_helper
INFO - 2021-06-28 04:57:01 --> Helper loaded: file_helper
INFO - 2021-06-28 04:57:01 --> Helper loaded: form_helper
INFO - 2021-06-28 04:57:01 --> Helper loaded: my_helper
INFO - 2021-06-28 04:57:01 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:57:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:57:01 --> Controller Class Initialized
INFO - 2021-06-28 04:57:04 --> Config Class Initialized
INFO - 2021-06-28 04:57:04 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:57:04 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:57:04 --> Utf8 Class Initialized
INFO - 2021-06-28 04:57:04 --> URI Class Initialized
INFO - 2021-06-28 04:57:04 --> Router Class Initialized
INFO - 2021-06-28 04:57:04 --> Output Class Initialized
INFO - 2021-06-28 04:57:04 --> Security Class Initialized
DEBUG - 2021-06-28 04:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:57:04 --> Input Class Initialized
INFO - 2021-06-28 04:57:04 --> Language Class Initialized
INFO - 2021-06-28 04:57:04 --> Language Class Initialized
INFO - 2021-06-28 04:57:04 --> Config Class Initialized
INFO - 2021-06-28 04:57:04 --> Loader Class Initialized
INFO - 2021-06-28 04:57:04 --> Helper loaded: url_helper
INFO - 2021-06-28 04:57:04 --> Helper loaded: file_helper
INFO - 2021-06-28 04:57:04 --> Helper loaded: form_helper
INFO - 2021-06-28 04:57:04 --> Helper loaded: my_helper
INFO - 2021-06-28 04:57:04 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:57:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:57:04 --> Controller Class Initialized
DEBUG - 2021-06-28 04:57:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form_import.php
DEBUG - 2021-06-28 04:57:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 04:57:04 --> Final output sent to browser
DEBUG - 2021-06-28 04:57:04 --> Total execution time: 0.0391
INFO - 2021-06-28 04:57:05 --> Config Class Initialized
INFO - 2021-06-28 04:57:05 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:57:05 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:57:05 --> Utf8 Class Initialized
INFO - 2021-06-28 04:57:05 --> URI Class Initialized
INFO - 2021-06-28 04:57:05 --> Router Class Initialized
INFO - 2021-06-28 04:57:05 --> Output Class Initialized
INFO - 2021-06-28 04:57:05 --> Security Class Initialized
DEBUG - 2021-06-28 04:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:57:05 --> Input Class Initialized
INFO - 2021-06-28 04:57:05 --> Language Class Initialized
INFO - 2021-06-28 04:57:05 --> Language Class Initialized
INFO - 2021-06-28 04:57:05 --> Config Class Initialized
INFO - 2021-06-28 04:57:05 --> Loader Class Initialized
INFO - 2021-06-28 04:57:05 --> Helper loaded: url_helper
INFO - 2021-06-28 04:57:05 --> Helper loaded: file_helper
INFO - 2021-06-28 04:57:05 --> Helper loaded: form_helper
INFO - 2021-06-28 04:57:05 --> Helper loaded: my_helper
INFO - 2021-06-28 04:57:05 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:57:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:57:05 --> Controller Class Initialized
DEBUG - 2021-06-28 04:57:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-06-28 04:57:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 04:57:05 --> Final output sent to browser
DEBUG - 2021-06-28 04:57:05 --> Total execution time: 0.0498
INFO - 2021-06-28 04:57:05 --> Config Class Initialized
INFO - 2021-06-28 04:57:05 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:57:05 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:57:05 --> Utf8 Class Initialized
INFO - 2021-06-28 04:57:05 --> URI Class Initialized
INFO - 2021-06-28 04:57:05 --> Router Class Initialized
INFO - 2021-06-28 04:57:05 --> Output Class Initialized
INFO - 2021-06-28 04:57:05 --> Security Class Initialized
DEBUG - 2021-06-28 04:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:57:05 --> Input Class Initialized
INFO - 2021-06-28 04:57:05 --> Language Class Initialized
INFO - 2021-06-28 04:57:05 --> Language Class Initialized
INFO - 2021-06-28 04:57:05 --> Config Class Initialized
INFO - 2021-06-28 04:57:05 --> Loader Class Initialized
INFO - 2021-06-28 04:57:05 --> Helper loaded: url_helper
INFO - 2021-06-28 04:57:05 --> Helper loaded: file_helper
INFO - 2021-06-28 04:57:05 --> Helper loaded: form_helper
INFO - 2021-06-28 04:57:05 --> Helper loaded: my_helper
INFO - 2021-06-28 04:57:05 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:57:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:57:05 --> Controller Class Initialized
INFO - 2021-06-28 04:57:08 --> Config Class Initialized
INFO - 2021-06-28 04:57:08 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:57:08 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:57:08 --> Utf8 Class Initialized
INFO - 2021-06-28 04:57:08 --> URI Class Initialized
INFO - 2021-06-28 04:57:08 --> Router Class Initialized
INFO - 2021-06-28 04:57:08 --> Output Class Initialized
INFO - 2021-06-28 04:57:08 --> Security Class Initialized
DEBUG - 2021-06-28 04:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:57:08 --> Input Class Initialized
INFO - 2021-06-28 04:57:08 --> Language Class Initialized
INFO - 2021-06-28 04:57:08 --> Language Class Initialized
INFO - 2021-06-28 04:57:08 --> Config Class Initialized
INFO - 2021-06-28 04:57:08 --> Loader Class Initialized
INFO - 2021-06-28 04:57:08 --> Helper loaded: url_helper
INFO - 2021-06-28 04:57:08 --> Helper loaded: file_helper
INFO - 2021-06-28 04:57:08 --> Helper loaded: form_helper
INFO - 2021-06-28 04:57:08 --> Helper loaded: my_helper
INFO - 2021-06-28 04:57:08 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:57:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:57:08 --> Controller Class Initialized
INFO - 2021-06-28 04:57:32 --> Config Class Initialized
INFO - 2021-06-28 04:57:32 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:57:32 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:57:32 --> Utf8 Class Initialized
INFO - 2021-06-28 04:57:32 --> URI Class Initialized
INFO - 2021-06-28 04:57:32 --> Router Class Initialized
INFO - 2021-06-28 04:57:32 --> Output Class Initialized
INFO - 2021-06-28 04:57:32 --> Security Class Initialized
DEBUG - 2021-06-28 04:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:57:32 --> Input Class Initialized
INFO - 2021-06-28 04:57:32 --> Language Class Initialized
INFO - 2021-06-28 04:57:32 --> Language Class Initialized
INFO - 2021-06-28 04:57:32 --> Config Class Initialized
INFO - 2021-06-28 04:57:32 --> Loader Class Initialized
INFO - 2021-06-28 04:57:32 --> Helper loaded: url_helper
INFO - 2021-06-28 04:57:32 --> Helper loaded: file_helper
INFO - 2021-06-28 04:57:32 --> Helper loaded: form_helper
INFO - 2021-06-28 04:57:32 --> Helper loaded: my_helper
INFO - 2021-06-28 04:57:32 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:57:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:57:32 --> Controller Class Initialized
DEBUG - 2021-06-28 04:57:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form_import.php
DEBUG - 2021-06-28 04:57:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 04:57:32 --> Final output sent to browser
DEBUG - 2021-06-28 04:57:32 --> Total execution time: 0.0507
INFO - 2021-06-28 04:57:35 --> Config Class Initialized
INFO - 2021-06-28 04:57:35 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:57:35 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:57:35 --> Utf8 Class Initialized
INFO - 2021-06-28 04:57:35 --> URI Class Initialized
INFO - 2021-06-28 04:57:35 --> Router Class Initialized
INFO - 2021-06-28 04:57:35 --> Output Class Initialized
INFO - 2021-06-28 04:57:35 --> Security Class Initialized
DEBUG - 2021-06-28 04:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:57:35 --> Input Class Initialized
INFO - 2021-06-28 04:57:35 --> Language Class Initialized
INFO - 2021-06-28 04:57:35 --> Language Class Initialized
INFO - 2021-06-28 04:57:35 --> Config Class Initialized
INFO - 2021-06-28 04:57:35 --> Loader Class Initialized
INFO - 2021-06-28 04:57:35 --> Helper loaded: url_helper
INFO - 2021-06-28 04:57:35 --> Helper loaded: file_helper
INFO - 2021-06-28 04:57:35 --> Helper loaded: form_helper
INFO - 2021-06-28 04:57:35 --> Helper loaded: my_helper
INFO - 2021-06-28 04:57:35 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:57:35 --> Controller Class Initialized
INFO - 2021-06-28 04:57:38 --> Config Class Initialized
INFO - 2021-06-28 04:57:38 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:57:38 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:57:38 --> Utf8 Class Initialized
INFO - 2021-06-28 04:57:38 --> URI Class Initialized
INFO - 2021-06-28 04:57:38 --> Router Class Initialized
INFO - 2021-06-28 04:57:38 --> Output Class Initialized
INFO - 2021-06-28 04:57:38 --> Security Class Initialized
DEBUG - 2021-06-28 04:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:57:38 --> Input Class Initialized
INFO - 2021-06-28 04:57:38 --> Language Class Initialized
INFO - 2021-06-28 04:57:38 --> Language Class Initialized
INFO - 2021-06-28 04:57:38 --> Config Class Initialized
INFO - 2021-06-28 04:57:38 --> Loader Class Initialized
INFO - 2021-06-28 04:57:38 --> Helper loaded: url_helper
INFO - 2021-06-28 04:57:38 --> Helper loaded: file_helper
INFO - 2021-06-28 04:57:38 --> Helper loaded: form_helper
INFO - 2021-06-28 04:57:38 --> Helper loaded: my_helper
INFO - 2021-06-28 04:57:38 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:57:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:57:38 --> Controller Class Initialized
DEBUG - 2021-06-28 04:57:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form_import.php
DEBUG - 2021-06-28 04:57:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 04:57:38 --> Final output sent to browser
DEBUG - 2021-06-28 04:57:38 --> Total execution time: 0.0484
INFO - 2021-06-28 04:57:41 --> Config Class Initialized
INFO - 2021-06-28 04:57:41 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:57:41 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:57:41 --> Utf8 Class Initialized
INFO - 2021-06-28 04:57:41 --> URI Class Initialized
INFO - 2021-06-28 04:57:41 --> Router Class Initialized
INFO - 2021-06-28 04:57:41 --> Output Class Initialized
INFO - 2021-06-28 04:57:41 --> Security Class Initialized
DEBUG - 2021-06-28 04:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:57:41 --> Input Class Initialized
INFO - 2021-06-28 04:57:41 --> Language Class Initialized
INFO - 2021-06-28 04:57:41 --> Language Class Initialized
INFO - 2021-06-28 04:57:41 --> Config Class Initialized
INFO - 2021-06-28 04:57:41 --> Loader Class Initialized
INFO - 2021-06-28 04:57:41 --> Helper loaded: url_helper
INFO - 2021-06-28 04:57:41 --> Helper loaded: file_helper
INFO - 2021-06-28 04:57:41 --> Helper loaded: form_helper
INFO - 2021-06-28 04:57:41 --> Helper loaded: my_helper
INFO - 2021-06-28 04:57:41 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:57:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:57:41 --> Controller Class Initialized
DEBUG - 2021-06-28 04:57:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-06-28 04:57:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 04:57:41 --> Final output sent to browser
DEBUG - 2021-06-28 04:57:41 --> Total execution time: 0.0500
INFO - 2021-06-28 04:57:41 --> Config Class Initialized
INFO - 2021-06-28 04:57:41 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:57:41 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:57:41 --> Utf8 Class Initialized
INFO - 2021-06-28 04:57:41 --> URI Class Initialized
INFO - 2021-06-28 04:57:41 --> Router Class Initialized
INFO - 2021-06-28 04:57:41 --> Output Class Initialized
INFO - 2021-06-28 04:57:41 --> Security Class Initialized
DEBUG - 2021-06-28 04:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:57:41 --> Input Class Initialized
INFO - 2021-06-28 04:57:41 --> Language Class Initialized
INFO - 2021-06-28 04:57:41 --> Language Class Initialized
INFO - 2021-06-28 04:57:41 --> Config Class Initialized
INFO - 2021-06-28 04:57:41 --> Loader Class Initialized
INFO - 2021-06-28 04:57:41 --> Helper loaded: url_helper
INFO - 2021-06-28 04:57:41 --> Helper loaded: file_helper
INFO - 2021-06-28 04:57:41 --> Helper loaded: form_helper
INFO - 2021-06-28 04:57:41 --> Helper loaded: my_helper
INFO - 2021-06-28 04:57:41 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:57:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:57:41 --> Controller Class Initialized
INFO - 2021-06-28 04:57:44 --> Config Class Initialized
INFO - 2021-06-28 04:57:44 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:57:44 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:57:44 --> Utf8 Class Initialized
INFO - 2021-06-28 04:57:44 --> URI Class Initialized
INFO - 2021-06-28 04:57:44 --> Router Class Initialized
INFO - 2021-06-28 04:57:44 --> Output Class Initialized
INFO - 2021-06-28 04:57:44 --> Security Class Initialized
DEBUG - 2021-06-28 04:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:57:44 --> Input Class Initialized
INFO - 2021-06-28 04:57:44 --> Language Class Initialized
INFO - 2021-06-28 04:57:44 --> Language Class Initialized
INFO - 2021-06-28 04:57:44 --> Config Class Initialized
INFO - 2021-06-28 04:57:44 --> Loader Class Initialized
INFO - 2021-06-28 04:57:44 --> Helper loaded: url_helper
INFO - 2021-06-28 04:57:44 --> Helper loaded: file_helper
INFO - 2021-06-28 04:57:44 --> Helper loaded: form_helper
INFO - 2021-06-28 04:57:44 --> Helper loaded: my_helper
INFO - 2021-06-28 04:57:44 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:57:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:57:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:57:44 --> Controller Class Initialized
INFO - 2021-06-28 04:57:46 --> Config Class Initialized
INFO - 2021-06-28 04:57:46 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:57:46 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:57:46 --> Utf8 Class Initialized
INFO - 2021-06-28 04:57:46 --> URI Class Initialized
INFO - 2021-06-28 04:57:46 --> Router Class Initialized
INFO - 2021-06-28 04:57:46 --> Output Class Initialized
INFO - 2021-06-28 04:57:46 --> Security Class Initialized
DEBUG - 2021-06-28 04:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:57:46 --> Input Class Initialized
INFO - 2021-06-28 04:57:46 --> Language Class Initialized
INFO - 2021-06-28 04:57:46 --> Language Class Initialized
INFO - 2021-06-28 04:57:46 --> Config Class Initialized
INFO - 2021-06-28 04:57:46 --> Loader Class Initialized
INFO - 2021-06-28 04:57:46 --> Helper loaded: url_helper
INFO - 2021-06-28 04:57:46 --> Helper loaded: file_helper
INFO - 2021-06-28 04:57:46 --> Helper loaded: form_helper
INFO - 2021-06-28 04:57:46 --> Helper loaded: my_helper
INFO - 2021-06-28 04:57:46 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:57:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:57:46 --> Controller Class Initialized
INFO - 2021-06-28 04:57:46 --> Config Class Initialized
INFO - 2021-06-28 04:57:46 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:57:46 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:57:46 --> Utf8 Class Initialized
INFO - 2021-06-28 04:57:46 --> URI Class Initialized
INFO - 2021-06-28 04:57:46 --> Router Class Initialized
INFO - 2021-06-28 04:57:46 --> Output Class Initialized
INFO - 2021-06-28 04:57:46 --> Security Class Initialized
DEBUG - 2021-06-28 04:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:57:46 --> Input Class Initialized
INFO - 2021-06-28 04:57:46 --> Language Class Initialized
INFO - 2021-06-28 04:57:46 --> Language Class Initialized
INFO - 2021-06-28 04:57:46 --> Config Class Initialized
INFO - 2021-06-28 04:57:46 --> Loader Class Initialized
INFO - 2021-06-28 04:57:46 --> Helper loaded: url_helper
INFO - 2021-06-28 04:57:46 --> Helper loaded: file_helper
INFO - 2021-06-28 04:57:46 --> Helper loaded: form_helper
INFO - 2021-06-28 04:57:46 --> Helper loaded: my_helper
INFO - 2021-06-28 04:57:46 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:57:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:57:46 --> Controller Class Initialized
INFO - 2021-06-28 04:57:47 --> Config Class Initialized
INFO - 2021-06-28 04:57:47 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:57:47 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:57:47 --> Utf8 Class Initialized
INFO - 2021-06-28 04:57:47 --> URI Class Initialized
INFO - 2021-06-28 04:57:47 --> Router Class Initialized
INFO - 2021-06-28 04:57:47 --> Output Class Initialized
INFO - 2021-06-28 04:57:47 --> Security Class Initialized
DEBUG - 2021-06-28 04:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:57:47 --> Input Class Initialized
INFO - 2021-06-28 04:57:47 --> Language Class Initialized
INFO - 2021-06-28 04:57:47 --> Language Class Initialized
INFO - 2021-06-28 04:57:47 --> Config Class Initialized
INFO - 2021-06-28 04:57:47 --> Loader Class Initialized
INFO - 2021-06-28 04:57:47 --> Helper loaded: url_helper
INFO - 2021-06-28 04:57:47 --> Helper loaded: file_helper
INFO - 2021-06-28 04:57:47 --> Helper loaded: form_helper
INFO - 2021-06-28 04:57:47 --> Helper loaded: my_helper
INFO - 2021-06-28 04:57:47 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:57:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:57:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:57:47 --> Controller Class Initialized
INFO - 2021-06-28 04:57:57 --> Config Class Initialized
INFO - 2021-06-28 04:57:57 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:57:57 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:57:57 --> Utf8 Class Initialized
INFO - 2021-06-28 04:57:57 --> URI Class Initialized
INFO - 2021-06-28 04:57:57 --> Router Class Initialized
INFO - 2021-06-28 04:57:57 --> Output Class Initialized
INFO - 2021-06-28 04:57:57 --> Security Class Initialized
DEBUG - 2021-06-28 04:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:57:57 --> Input Class Initialized
INFO - 2021-06-28 04:57:57 --> Language Class Initialized
INFO - 2021-06-28 04:57:57 --> Language Class Initialized
INFO - 2021-06-28 04:57:57 --> Config Class Initialized
INFO - 2021-06-28 04:57:57 --> Loader Class Initialized
INFO - 2021-06-28 04:57:57 --> Helper loaded: url_helper
INFO - 2021-06-28 04:57:57 --> Helper loaded: file_helper
INFO - 2021-06-28 04:57:57 --> Helper loaded: form_helper
INFO - 2021-06-28 04:57:57 --> Helper loaded: my_helper
INFO - 2021-06-28 04:57:57 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:57:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:57:57 --> Controller Class Initialized
ERROR - 2021-06-28 04:57:57 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 241
DEBUG - 2021-06-28 04:57:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-06-28 04:57:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 04:57:57 --> Final output sent to browser
DEBUG - 2021-06-28 04:57:57 --> Total execution time: 0.0446
INFO - 2021-06-28 04:58:17 --> Config Class Initialized
INFO - 2021-06-28 04:58:17 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:58:17 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:58:17 --> Utf8 Class Initialized
INFO - 2021-06-28 04:58:17 --> URI Class Initialized
INFO - 2021-06-28 04:58:17 --> Router Class Initialized
INFO - 2021-06-28 04:58:17 --> Output Class Initialized
INFO - 2021-06-28 04:58:17 --> Security Class Initialized
DEBUG - 2021-06-28 04:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:58:17 --> Input Class Initialized
INFO - 2021-06-28 04:58:17 --> Language Class Initialized
INFO - 2021-06-28 04:58:17 --> Language Class Initialized
INFO - 2021-06-28 04:58:17 --> Config Class Initialized
INFO - 2021-06-28 04:58:17 --> Loader Class Initialized
INFO - 2021-06-28 04:58:17 --> Helper loaded: url_helper
INFO - 2021-06-28 04:58:17 --> Helper loaded: file_helper
INFO - 2021-06-28 04:58:17 --> Helper loaded: form_helper
INFO - 2021-06-28 04:58:17 --> Helper loaded: my_helper
INFO - 2021-06-28 04:58:17 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:58:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:58:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:58:17 --> Controller Class Initialized
DEBUG - 2021-06-28 04:58:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-06-28 04:58:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 04:58:17 --> Final output sent to browser
DEBUG - 2021-06-28 04:58:17 --> Total execution time: 0.0520
INFO - 2021-06-28 04:58:18 --> Config Class Initialized
INFO - 2021-06-28 04:58:18 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:58:18 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:58:18 --> Utf8 Class Initialized
INFO - 2021-06-28 04:58:18 --> URI Class Initialized
INFO - 2021-06-28 04:58:18 --> Router Class Initialized
INFO - 2021-06-28 04:58:18 --> Output Class Initialized
INFO - 2021-06-28 04:58:18 --> Security Class Initialized
DEBUG - 2021-06-28 04:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:58:18 --> Input Class Initialized
INFO - 2021-06-28 04:58:18 --> Language Class Initialized
INFO - 2021-06-28 04:58:18 --> Language Class Initialized
INFO - 2021-06-28 04:58:18 --> Config Class Initialized
INFO - 2021-06-28 04:58:18 --> Loader Class Initialized
INFO - 2021-06-28 04:58:18 --> Helper loaded: url_helper
INFO - 2021-06-28 04:58:18 --> Helper loaded: file_helper
INFO - 2021-06-28 04:58:18 --> Helper loaded: form_helper
INFO - 2021-06-28 04:58:18 --> Helper loaded: my_helper
INFO - 2021-06-28 04:58:18 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:58:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:58:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:58:18 --> Controller Class Initialized
INFO - 2021-06-28 04:58:21 --> Config Class Initialized
INFO - 2021-06-28 04:58:21 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:58:21 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:58:21 --> Utf8 Class Initialized
INFO - 2021-06-28 04:58:21 --> URI Class Initialized
INFO - 2021-06-28 04:58:21 --> Router Class Initialized
INFO - 2021-06-28 04:58:21 --> Output Class Initialized
INFO - 2021-06-28 04:58:21 --> Security Class Initialized
DEBUG - 2021-06-28 04:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:58:21 --> Input Class Initialized
INFO - 2021-06-28 04:58:21 --> Language Class Initialized
INFO - 2021-06-28 04:58:21 --> Language Class Initialized
INFO - 2021-06-28 04:58:21 --> Config Class Initialized
INFO - 2021-06-28 04:58:21 --> Loader Class Initialized
INFO - 2021-06-28 04:58:21 --> Helper loaded: url_helper
INFO - 2021-06-28 04:58:21 --> Helper loaded: file_helper
INFO - 2021-06-28 04:58:21 --> Helper loaded: form_helper
INFO - 2021-06-28 04:58:21 --> Helper loaded: my_helper
INFO - 2021-06-28 04:58:21 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:58:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:58:21 --> Controller Class Initialized
INFO - 2021-06-28 04:58:21 --> Config Class Initialized
INFO - 2021-06-28 04:58:21 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:58:21 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:58:21 --> Utf8 Class Initialized
INFO - 2021-06-28 04:58:21 --> URI Class Initialized
INFO - 2021-06-28 04:58:21 --> Router Class Initialized
INFO - 2021-06-28 04:58:21 --> Output Class Initialized
INFO - 2021-06-28 04:58:21 --> Security Class Initialized
DEBUG - 2021-06-28 04:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:58:21 --> Input Class Initialized
INFO - 2021-06-28 04:58:21 --> Language Class Initialized
INFO - 2021-06-28 04:58:21 --> Language Class Initialized
INFO - 2021-06-28 04:58:21 --> Config Class Initialized
INFO - 2021-06-28 04:58:21 --> Loader Class Initialized
INFO - 2021-06-28 04:58:21 --> Helper loaded: url_helper
INFO - 2021-06-28 04:58:21 --> Helper loaded: file_helper
INFO - 2021-06-28 04:58:21 --> Helper loaded: form_helper
INFO - 2021-06-28 04:58:21 --> Helper loaded: my_helper
INFO - 2021-06-28 04:58:21 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:58:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:58:21 --> Controller Class Initialized
INFO - 2021-06-28 04:58:24 --> Config Class Initialized
INFO - 2021-06-28 04:58:24 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:58:24 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:58:24 --> Utf8 Class Initialized
INFO - 2021-06-28 04:58:24 --> URI Class Initialized
INFO - 2021-06-28 04:58:24 --> Router Class Initialized
INFO - 2021-06-28 04:58:24 --> Output Class Initialized
INFO - 2021-06-28 04:58:24 --> Security Class Initialized
DEBUG - 2021-06-28 04:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:58:24 --> Input Class Initialized
INFO - 2021-06-28 04:58:24 --> Language Class Initialized
INFO - 2021-06-28 04:58:24 --> Language Class Initialized
INFO - 2021-06-28 04:58:24 --> Config Class Initialized
INFO - 2021-06-28 04:58:24 --> Loader Class Initialized
INFO - 2021-06-28 04:58:24 --> Helper loaded: url_helper
INFO - 2021-06-28 04:58:24 --> Helper loaded: file_helper
INFO - 2021-06-28 04:58:24 --> Helper loaded: form_helper
INFO - 2021-06-28 04:58:24 --> Helper loaded: my_helper
INFO - 2021-06-28 04:58:24 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:58:24 --> Controller Class Initialized
INFO - 2021-06-28 04:58:25 --> Config Class Initialized
INFO - 2021-06-28 04:58:25 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:58:25 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:58:25 --> Utf8 Class Initialized
INFO - 2021-06-28 04:58:25 --> URI Class Initialized
INFO - 2021-06-28 04:58:25 --> Router Class Initialized
INFO - 2021-06-28 04:58:25 --> Output Class Initialized
INFO - 2021-06-28 04:58:25 --> Security Class Initialized
DEBUG - 2021-06-28 04:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:58:25 --> Input Class Initialized
INFO - 2021-06-28 04:58:25 --> Language Class Initialized
INFO - 2021-06-28 04:58:25 --> Language Class Initialized
INFO - 2021-06-28 04:58:25 --> Config Class Initialized
INFO - 2021-06-28 04:58:25 --> Loader Class Initialized
INFO - 2021-06-28 04:58:25 --> Helper loaded: url_helper
INFO - 2021-06-28 04:58:25 --> Helper loaded: file_helper
INFO - 2021-06-28 04:58:25 --> Helper loaded: form_helper
INFO - 2021-06-28 04:58:25 --> Helper loaded: my_helper
INFO - 2021-06-28 04:58:25 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:58:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:58:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:58:25 --> Controller Class Initialized
INFO - 2021-06-28 04:58:30 --> Config Class Initialized
INFO - 2021-06-28 04:58:30 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:58:30 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:58:30 --> Utf8 Class Initialized
INFO - 2021-06-28 04:58:30 --> URI Class Initialized
INFO - 2021-06-28 04:58:30 --> Router Class Initialized
INFO - 2021-06-28 04:58:30 --> Output Class Initialized
INFO - 2021-06-28 04:58:30 --> Security Class Initialized
DEBUG - 2021-06-28 04:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:58:30 --> Input Class Initialized
INFO - 2021-06-28 04:58:30 --> Language Class Initialized
INFO - 2021-06-28 04:58:30 --> Language Class Initialized
INFO - 2021-06-28 04:58:30 --> Config Class Initialized
INFO - 2021-06-28 04:58:30 --> Loader Class Initialized
INFO - 2021-06-28 04:58:30 --> Helper loaded: url_helper
INFO - 2021-06-28 04:58:30 --> Helper loaded: file_helper
INFO - 2021-06-28 04:58:30 --> Helper loaded: form_helper
INFO - 2021-06-28 04:58:30 --> Helper loaded: my_helper
INFO - 2021-06-28 04:58:30 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:58:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:58:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:58:30 --> Controller Class Initialized
INFO - 2021-06-28 04:58:30 --> Config Class Initialized
INFO - 2021-06-28 04:58:30 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:58:30 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:58:30 --> Utf8 Class Initialized
INFO - 2021-06-28 04:58:30 --> URI Class Initialized
INFO - 2021-06-28 04:58:30 --> Router Class Initialized
INFO - 2021-06-28 04:58:30 --> Output Class Initialized
INFO - 2021-06-28 04:58:30 --> Security Class Initialized
DEBUG - 2021-06-28 04:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:58:30 --> Input Class Initialized
INFO - 2021-06-28 04:58:30 --> Language Class Initialized
INFO - 2021-06-28 04:58:30 --> Language Class Initialized
INFO - 2021-06-28 04:58:30 --> Config Class Initialized
INFO - 2021-06-28 04:58:30 --> Loader Class Initialized
INFO - 2021-06-28 04:58:30 --> Helper loaded: url_helper
INFO - 2021-06-28 04:58:30 --> Helper loaded: file_helper
INFO - 2021-06-28 04:58:30 --> Helper loaded: form_helper
INFO - 2021-06-28 04:58:30 --> Helper loaded: my_helper
INFO - 2021-06-28 04:58:30 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:58:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:58:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:58:30 --> Controller Class Initialized
DEBUG - 2021-06-28 04:58:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-06-28 04:58:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 04:58:30 --> Final output sent to browser
DEBUG - 2021-06-28 04:58:30 --> Total execution time: 0.0506
INFO - 2021-06-28 04:58:30 --> Config Class Initialized
INFO - 2021-06-28 04:58:30 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:58:30 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:58:30 --> Utf8 Class Initialized
INFO - 2021-06-28 04:58:30 --> URI Class Initialized
INFO - 2021-06-28 04:58:30 --> Router Class Initialized
INFO - 2021-06-28 04:58:30 --> Output Class Initialized
INFO - 2021-06-28 04:58:30 --> Security Class Initialized
DEBUG - 2021-06-28 04:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:58:30 --> Input Class Initialized
INFO - 2021-06-28 04:58:30 --> Language Class Initialized
INFO - 2021-06-28 04:58:30 --> Language Class Initialized
INFO - 2021-06-28 04:58:30 --> Config Class Initialized
INFO - 2021-06-28 04:58:30 --> Loader Class Initialized
INFO - 2021-06-28 04:58:30 --> Helper loaded: url_helper
INFO - 2021-06-28 04:58:30 --> Helper loaded: file_helper
INFO - 2021-06-28 04:58:30 --> Helper loaded: form_helper
INFO - 2021-06-28 04:58:30 --> Helper loaded: my_helper
INFO - 2021-06-28 04:58:30 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:58:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:58:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:58:30 --> Controller Class Initialized
INFO - 2021-06-28 04:58:33 --> Config Class Initialized
INFO - 2021-06-28 04:58:33 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:58:33 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:58:33 --> Utf8 Class Initialized
INFO - 2021-06-28 04:58:33 --> URI Class Initialized
INFO - 2021-06-28 04:58:33 --> Router Class Initialized
INFO - 2021-06-28 04:58:33 --> Output Class Initialized
INFO - 2021-06-28 04:58:33 --> Security Class Initialized
DEBUG - 2021-06-28 04:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:58:33 --> Input Class Initialized
INFO - 2021-06-28 04:58:33 --> Language Class Initialized
INFO - 2021-06-28 04:58:33 --> Language Class Initialized
INFO - 2021-06-28 04:58:33 --> Config Class Initialized
INFO - 2021-06-28 04:58:33 --> Loader Class Initialized
INFO - 2021-06-28 04:58:33 --> Helper loaded: url_helper
INFO - 2021-06-28 04:58:33 --> Helper loaded: file_helper
INFO - 2021-06-28 04:58:33 --> Helper loaded: form_helper
INFO - 2021-06-28 04:58:33 --> Helper loaded: my_helper
INFO - 2021-06-28 04:58:33 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:58:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:58:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:58:33 --> Controller Class Initialized
INFO - 2021-06-28 04:58:36 --> Config Class Initialized
INFO - 2021-06-28 04:58:36 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:58:36 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:58:36 --> Utf8 Class Initialized
INFO - 2021-06-28 04:58:36 --> URI Class Initialized
INFO - 2021-06-28 04:58:36 --> Router Class Initialized
INFO - 2021-06-28 04:58:36 --> Output Class Initialized
INFO - 2021-06-28 04:58:36 --> Security Class Initialized
DEBUG - 2021-06-28 04:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:58:36 --> Input Class Initialized
INFO - 2021-06-28 04:58:36 --> Language Class Initialized
INFO - 2021-06-28 04:58:36 --> Language Class Initialized
INFO - 2021-06-28 04:58:36 --> Config Class Initialized
INFO - 2021-06-28 04:58:36 --> Loader Class Initialized
INFO - 2021-06-28 04:58:36 --> Helper loaded: url_helper
INFO - 2021-06-28 04:58:36 --> Helper loaded: file_helper
INFO - 2021-06-28 04:58:36 --> Helper loaded: form_helper
INFO - 2021-06-28 04:58:36 --> Helper loaded: my_helper
INFO - 2021-06-28 04:58:36 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:58:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:58:36 --> Controller Class Initialized
INFO - 2021-06-28 04:58:36 --> Config Class Initialized
INFO - 2021-06-28 04:58:36 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:58:36 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:58:36 --> Utf8 Class Initialized
INFO - 2021-06-28 04:58:36 --> URI Class Initialized
INFO - 2021-06-28 04:58:36 --> Router Class Initialized
INFO - 2021-06-28 04:58:36 --> Output Class Initialized
INFO - 2021-06-28 04:58:36 --> Security Class Initialized
DEBUG - 2021-06-28 04:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:58:36 --> Input Class Initialized
INFO - 2021-06-28 04:58:36 --> Language Class Initialized
INFO - 2021-06-28 04:58:36 --> Language Class Initialized
INFO - 2021-06-28 04:58:36 --> Config Class Initialized
INFO - 2021-06-28 04:58:36 --> Loader Class Initialized
INFO - 2021-06-28 04:58:36 --> Helper loaded: url_helper
INFO - 2021-06-28 04:58:36 --> Helper loaded: file_helper
INFO - 2021-06-28 04:58:36 --> Helper loaded: form_helper
INFO - 2021-06-28 04:58:36 --> Helper loaded: my_helper
INFO - 2021-06-28 04:58:36 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:58:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:58:36 --> Controller Class Initialized
INFO - 2021-06-28 04:58:37 --> Config Class Initialized
INFO - 2021-06-28 04:58:37 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:58:37 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:58:37 --> Utf8 Class Initialized
INFO - 2021-06-28 04:58:37 --> URI Class Initialized
INFO - 2021-06-28 04:58:37 --> Router Class Initialized
INFO - 2021-06-28 04:58:37 --> Output Class Initialized
INFO - 2021-06-28 04:58:37 --> Security Class Initialized
DEBUG - 2021-06-28 04:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:58:37 --> Input Class Initialized
INFO - 2021-06-28 04:58:37 --> Language Class Initialized
INFO - 2021-06-28 04:58:37 --> Language Class Initialized
INFO - 2021-06-28 04:58:37 --> Config Class Initialized
INFO - 2021-06-28 04:58:37 --> Loader Class Initialized
INFO - 2021-06-28 04:58:37 --> Helper loaded: url_helper
INFO - 2021-06-28 04:58:37 --> Helper loaded: file_helper
INFO - 2021-06-28 04:58:37 --> Helper loaded: form_helper
INFO - 2021-06-28 04:58:37 --> Helper loaded: my_helper
INFO - 2021-06-28 04:58:37 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:58:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:58:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:58:37 --> Controller Class Initialized
INFO - 2021-06-28 04:58:37 --> Config Class Initialized
INFO - 2021-06-28 04:58:37 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:58:37 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:58:37 --> Utf8 Class Initialized
INFO - 2021-06-28 04:58:37 --> URI Class Initialized
INFO - 2021-06-28 04:58:37 --> Router Class Initialized
INFO - 2021-06-28 04:58:37 --> Output Class Initialized
INFO - 2021-06-28 04:58:37 --> Security Class Initialized
DEBUG - 2021-06-28 04:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:58:37 --> Input Class Initialized
INFO - 2021-06-28 04:58:37 --> Language Class Initialized
INFO - 2021-06-28 04:58:37 --> Language Class Initialized
INFO - 2021-06-28 04:58:37 --> Config Class Initialized
INFO - 2021-06-28 04:58:37 --> Loader Class Initialized
INFO - 2021-06-28 04:58:37 --> Helper loaded: url_helper
INFO - 2021-06-28 04:58:37 --> Helper loaded: file_helper
INFO - 2021-06-28 04:58:37 --> Helper loaded: form_helper
INFO - 2021-06-28 04:58:37 --> Helper loaded: my_helper
INFO - 2021-06-28 04:58:37 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:58:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:58:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:58:37 --> Controller Class Initialized
INFO - 2021-06-28 04:58:37 --> Config Class Initialized
INFO - 2021-06-28 04:58:37 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:58:37 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:58:37 --> Utf8 Class Initialized
INFO - 2021-06-28 04:58:37 --> URI Class Initialized
INFO - 2021-06-28 04:58:37 --> Router Class Initialized
INFO - 2021-06-28 04:58:37 --> Output Class Initialized
INFO - 2021-06-28 04:58:37 --> Security Class Initialized
DEBUG - 2021-06-28 04:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:58:37 --> Input Class Initialized
INFO - 2021-06-28 04:58:37 --> Language Class Initialized
INFO - 2021-06-28 04:58:37 --> Language Class Initialized
INFO - 2021-06-28 04:58:37 --> Config Class Initialized
INFO - 2021-06-28 04:58:37 --> Loader Class Initialized
INFO - 2021-06-28 04:58:37 --> Helper loaded: url_helper
INFO - 2021-06-28 04:58:37 --> Helper loaded: file_helper
INFO - 2021-06-28 04:58:37 --> Helper loaded: form_helper
INFO - 2021-06-28 04:58:37 --> Helper loaded: my_helper
INFO - 2021-06-28 04:58:37 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:58:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:58:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:58:37 --> Controller Class Initialized
INFO - 2021-06-28 04:58:38 --> Config Class Initialized
INFO - 2021-06-28 04:58:38 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:58:38 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:58:38 --> Utf8 Class Initialized
INFO - 2021-06-28 04:58:38 --> URI Class Initialized
INFO - 2021-06-28 04:58:38 --> Router Class Initialized
INFO - 2021-06-28 04:58:38 --> Output Class Initialized
INFO - 2021-06-28 04:58:38 --> Security Class Initialized
DEBUG - 2021-06-28 04:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:58:38 --> Input Class Initialized
INFO - 2021-06-28 04:58:38 --> Language Class Initialized
INFO - 2021-06-28 04:58:38 --> Language Class Initialized
INFO - 2021-06-28 04:58:38 --> Config Class Initialized
INFO - 2021-06-28 04:58:38 --> Loader Class Initialized
INFO - 2021-06-28 04:58:38 --> Helper loaded: url_helper
INFO - 2021-06-28 04:58:38 --> Helper loaded: file_helper
INFO - 2021-06-28 04:58:38 --> Helper loaded: form_helper
INFO - 2021-06-28 04:58:38 --> Helper loaded: my_helper
INFO - 2021-06-28 04:58:38 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:58:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:58:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:58:38 --> Controller Class Initialized
INFO - 2021-06-28 04:58:42 --> Config Class Initialized
INFO - 2021-06-28 04:58:42 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:58:42 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:58:42 --> Utf8 Class Initialized
INFO - 2021-06-28 04:58:42 --> URI Class Initialized
INFO - 2021-06-28 04:58:42 --> Router Class Initialized
INFO - 2021-06-28 04:58:42 --> Output Class Initialized
INFO - 2021-06-28 04:58:42 --> Security Class Initialized
DEBUG - 2021-06-28 04:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:58:42 --> Input Class Initialized
INFO - 2021-06-28 04:58:42 --> Language Class Initialized
INFO - 2021-06-28 04:58:42 --> Language Class Initialized
INFO - 2021-06-28 04:58:42 --> Config Class Initialized
INFO - 2021-06-28 04:58:42 --> Loader Class Initialized
INFO - 2021-06-28 04:58:42 --> Helper loaded: url_helper
INFO - 2021-06-28 04:58:42 --> Helper loaded: file_helper
INFO - 2021-06-28 04:58:42 --> Helper loaded: form_helper
INFO - 2021-06-28 04:58:42 --> Helper loaded: my_helper
INFO - 2021-06-28 04:58:42 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:58:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:58:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:58:42 --> Controller Class Initialized
INFO - 2021-06-28 04:58:42 --> Config Class Initialized
INFO - 2021-06-28 04:58:42 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:58:42 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:58:42 --> Utf8 Class Initialized
INFO - 2021-06-28 04:58:42 --> URI Class Initialized
INFO - 2021-06-28 04:58:42 --> Router Class Initialized
INFO - 2021-06-28 04:58:42 --> Output Class Initialized
INFO - 2021-06-28 04:58:42 --> Security Class Initialized
DEBUG - 2021-06-28 04:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:58:42 --> Input Class Initialized
INFO - 2021-06-28 04:58:42 --> Language Class Initialized
INFO - 2021-06-28 04:58:42 --> Language Class Initialized
INFO - 2021-06-28 04:58:42 --> Config Class Initialized
INFO - 2021-06-28 04:58:42 --> Loader Class Initialized
INFO - 2021-06-28 04:58:42 --> Helper loaded: url_helper
INFO - 2021-06-28 04:58:42 --> Helper loaded: file_helper
INFO - 2021-06-28 04:58:42 --> Helper loaded: form_helper
INFO - 2021-06-28 04:58:42 --> Helper loaded: my_helper
INFO - 2021-06-28 04:58:42 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:58:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:58:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:58:42 --> Controller Class Initialized
DEBUG - 2021-06-28 04:58:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-06-28 04:58:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 04:58:42 --> Final output sent to browser
DEBUG - 2021-06-28 04:58:42 --> Total execution time: 0.0510
INFO - 2021-06-28 04:58:42 --> Config Class Initialized
INFO - 2021-06-28 04:58:42 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:58:42 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:58:42 --> Utf8 Class Initialized
INFO - 2021-06-28 04:58:42 --> URI Class Initialized
INFO - 2021-06-28 04:58:42 --> Router Class Initialized
INFO - 2021-06-28 04:58:42 --> Output Class Initialized
INFO - 2021-06-28 04:58:42 --> Security Class Initialized
DEBUG - 2021-06-28 04:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:58:42 --> Input Class Initialized
INFO - 2021-06-28 04:58:42 --> Language Class Initialized
INFO - 2021-06-28 04:58:42 --> Language Class Initialized
INFO - 2021-06-28 04:58:42 --> Config Class Initialized
INFO - 2021-06-28 04:58:42 --> Loader Class Initialized
INFO - 2021-06-28 04:58:42 --> Helper loaded: url_helper
INFO - 2021-06-28 04:58:42 --> Helper loaded: file_helper
INFO - 2021-06-28 04:58:42 --> Helper loaded: form_helper
INFO - 2021-06-28 04:58:42 --> Helper loaded: my_helper
INFO - 2021-06-28 04:58:42 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:58:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:58:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:58:42 --> Controller Class Initialized
INFO - 2021-06-28 04:58:44 --> Config Class Initialized
INFO - 2021-06-28 04:58:44 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:58:44 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:58:44 --> Utf8 Class Initialized
INFO - 2021-06-28 04:58:44 --> URI Class Initialized
INFO - 2021-06-28 04:58:44 --> Router Class Initialized
INFO - 2021-06-28 04:58:44 --> Output Class Initialized
INFO - 2021-06-28 04:58:44 --> Security Class Initialized
DEBUG - 2021-06-28 04:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:58:44 --> Input Class Initialized
INFO - 2021-06-28 04:58:44 --> Language Class Initialized
INFO - 2021-06-28 04:58:44 --> Language Class Initialized
INFO - 2021-06-28 04:58:44 --> Config Class Initialized
INFO - 2021-06-28 04:58:44 --> Loader Class Initialized
INFO - 2021-06-28 04:58:44 --> Helper loaded: url_helper
INFO - 2021-06-28 04:58:44 --> Helper loaded: file_helper
INFO - 2021-06-28 04:58:44 --> Helper loaded: form_helper
INFO - 2021-06-28 04:58:44 --> Helper loaded: my_helper
INFO - 2021-06-28 04:58:44 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:58:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:58:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:58:44 --> Controller Class Initialized
INFO - 2021-06-28 04:58:48 --> Config Class Initialized
INFO - 2021-06-28 04:58:48 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:58:48 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:58:48 --> Utf8 Class Initialized
INFO - 2021-06-28 04:58:48 --> URI Class Initialized
INFO - 2021-06-28 04:58:48 --> Router Class Initialized
INFO - 2021-06-28 04:58:48 --> Output Class Initialized
INFO - 2021-06-28 04:58:48 --> Security Class Initialized
DEBUG - 2021-06-28 04:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:58:48 --> Input Class Initialized
INFO - 2021-06-28 04:58:48 --> Language Class Initialized
INFO - 2021-06-28 04:58:48 --> Language Class Initialized
INFO - 2021-06-28 04:58:48 --> Config Class Initialized
INFO - 2021-06-28 04:58:48 --> Loader Class Initialized
INFO - 2021-06-28 04:58:48 --> Helper loaded: url_helper
INFO - 2021-06-28 04:58:48 --> Helper loaded: file_helper
INFO - 2021-06-28 04:58:48 --> Helper loaded: form_helper
INFO - 2021-06-28 04:58:48 --> Helper loaded: my_helper
INFO - 2021-06-28 04:58:48 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:58:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:58:48 --> Controller Class Initialized
INFO - 2021-06-28 04:58:50 --> Config Class Initialized
INFO - 2021-06-28 04:58:50 --> Hooks Class Initialized
DEBUG - 2021-06-28 04:58:50 --> UTF-8 Support Enabled
INFO - 2021-06-28 04:58:50 --> Utf8 Class Initialized
INFO - 2021-06-28 04:58:50 --> URI Class Initialized
INFO - 2021-06-28 04:58:50 --> Router Class Initialized
INFO - 2021-06-28 04:58:50 --> Output Class Initialized
INFO - 2021-06-28 04:58:50 --> Security Class Initialized
DEBUG - 2021-06-28 04:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 04:58:50 --> Input Class Initialized
INFO - 2021-06-28 04:58:50 --> Language Class Initialized
INFO - 2021-06-28 04:58:50 --> Language Class Initialized
INFO - 2021-06-28 04:58:50 --> Config Class Initialized
INFO - 2021-06-28 04:58:50 --> Loader Class Initialized
INFO - 2021-06-28 04:58:50 --> Helper loaded: url_helper
INFO - 2021-06-28 04:58:50 --> Helper loaded: file_helper
INFO - 2021-06-28 04:58:50 --> Helper loaded: form_helper
INFO - 2021-06-28 04:58:50 --> Helper loaded: my_helper
INFO - 2021-06-28 04:58:50 --> Database Driver Class Initialized
DEBUG - 2021-06-28 04:58:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 04:58:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 04:58:50 --> Controller Class Initialized
INFO - 2021-06-28 05:50:51 --> Config Class Initialized
INFO - 2021-06-28 05:50:51 --> Hooks Class Initialized
DEBUG - 2021-06-28 05:50:51 --> UTF-8 Support Enabled
INFO - 2021-06-28 05:50:51 --> Utf8 Class Initialized
INFO - 2021-06-28 05:50:51 --> URI Class Initialized
INFO - 2021-06-28 05:50:51 --> Router Class Initialized
INFO - 2021-06-28 05:50:51 --> Output Class Initialized
INFO - 2021-06-28 05:50:51 --> Security Class Initialized
DEBUG - 2021-06-28 05:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 05:50:51 --> Input Class Initialized
INFO - 2021-06-28 05:50:51 --> Language Class Initialized
INFO - 2021-06-28 05:50:51 --> Language Class Initialized
INFO - 2021-06-28 05:50:51 --> Config Class Initialized
INFO - 2021-06-28 05:50:51 --> Loader Class Initialized
INFO - 2021-06-28 05:50:51 --> Helper loaded: url_helper
INFO - 2021-06-28 05:50:51 --> Helper loaded: file_helper
INFO - 2021-06-28 05:50:51 --> Helper loaded: form_helper
INFO - 2021-06-28 05:50:51 --> Helper loaded: my_helper
INFO - 2021-06-28 05:50:51 --> Database Driver Class Initialized
DEBUG - 2021-06-28 05:50:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 05:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 05:50:51 --> Controller Class Initialized
DEBUG - 2021-06-28 05:50:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-28 05:50:51 --> Final output sent to browser
DEBUG - 2021-06-28 05:50:51 --> Total execution time: 0.0477
INFO - 2021-06-28 05:58:45 --> Config Class Initialized
INFO - 2021-06-28 05:58:45 --> Hooks Class Initialized
DEBUG - 2021-06-28 05:58:45 --> UTF-8 Support Enabled
INFO - 2021-06-28 05:58:45 --> Utf8 Class Initialized
INFO - 2021-06-28 05:58:45 --> URI Class Initialized
INFO - 2021-06-28 05:58:45 --> Router Class Initialized
INFO - 2021-06-28 05:58:45 --> Output Class Initialized
INFO - 2021-06-28 05:58:45 --> Security Class Initialized
DEBUG - 2021-06-28 05:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 05:58:45 --> Input Class Initialized
INFO - 2021-06-28 05:58:45 --> Language Class Initialized
INFO - 2021-06-28 05:58:45 --> Language Class Initialized
INFO - 2021-06-28 05:58:45 --> Config Class Initialized
INFO - 2021-06-28 05:58:45 --> Loader Class Initialized
INFO - 2021-06-28 05:58:45 --> Helper loaded: url_helper
INFO - 2021-06-28 05:58:45 --> Helper loaded: file_helper
INFO - 2021-06-28 05:58:45 --> Helper loaded: form_helper
INFO - 2021-06-28 05:58:45 --> Helper loaded: my_helper
INFO - 2021-06-28 05:58:45 --> Database Driver Class Initialized
DEBUG - 2021-06-28 05:58:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 05:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 05:58:46 --> Controller Class Initialized
DEBUG - 2021-06-28 05:58:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-28 05:58:46 --> Final output sent to browser
DEBUG - 2021-06-28 05:58:46 --> Total execution time: 0.0575
INFO - 2021-06-28 06:00:00 --> Config Class Initialized
INFO - 2021-06-28 06:00:00 --> Hooks Class Initialized
DEBUG - 2021-06-28 06:00:00 --> UTF-8 Support Enabled
INFO - 2021-06-28 06:00:00 --> Utf8 Class Initialized
INFO - 2021-06-28 06:00:00 --> URI Class Initialized
INFO - 2021-06-28 06:00:00 --> Router Class Initialized
INFO - 2021-06-28 06:00:00 --> Output Class Initialized
INFO - 2021-06-28 06:00:00 --> Security Class Initialized
DEBUG - 2021-06-28 06:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 06:00:00 --> Input Class Initialized
INFO - 2021-06-28 06:00:00 --> Language Class Initialized
INFO - 2021-06-28 06:00:00 --> Language Class Initialized
INFO - 2021-06-28 06:00:00 --> Config Class Initialized
INFO - 2021-06-28 06:00:00 --> Loader Class Initialized
INFO - 2021-06-28 06:00:00 --> Helper loaded: url_helper
INFO - 2021-06-28 06:00:00 --> Helper loaded: file_helper
INFO - 2021-06-28 06:00:00 --> Helper loaded: form_helper
INFO - 2021-06-28 06:00:00 --> Helper loaded: my_helper
INFO - 2021-06-28 06:00:00 --> Database Driver Class Initialized
DEBUG - 2021-06-28 06:00:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 06:00:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 06:00:00 --> Controller Class Initialized
INFO - 2021-06-28 06:00:02 --> Config Class Initialized
INFO - 2021-06-28 06:00:02 --> Hooks Class Initialized
DEBUG - 2021-06-28 06:00:02 --> UTF-8 Support Enabled
INFO - 2021-06-28 06:00:02 --> Utf8 Class Initialized
INFO - 2021-06-28 06:00:02 --> URI Class Initialized
INFO - 2021-06-28 06:00:02 --> Router Class Initialized
INFO - 2021-06-28 06:00:02 --> Output Class Initialized
INFO - 2021-06-28 06:00:02 --> Security Class Initialized
DEBUG - 2021-06-28 06:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 06:00:02 --> Input Class Initialized
INFO - 2021-06-28 06:00:02 --> Language Class Initialized
INFO - 2021-06-28 06:00:02 --> Language Class Initialized
INFO - 2021-06-28 06:00:02 --> Config Class Initialized
INFO - 2021-06-28 06:00:02 --> Loader Class Initialized
INFO - 2021-06-28 06:00:02 --> Helper loaded: url_helper
INFO - 2021-06-28 06:00:02 --> Helper loaded: file_helper
INFO - 2021-06-28 06:00:02 --> Helper loaded: form_helper
INFO - 2021-06-28 06:00:02 --> Helper loaded: my_helper
INFO - 2021-06-28 06:00:02 --> Database Driver Class Initialized
DEBUG - 2021-06-28 06:00:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 06:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 06:00:02 --> Controller Class Initialized
INFO - 2021-06-28 06:00:03 --> Config Class Initialized
INFO - 2021-06-28 06:00:03 --> Hooks Class Initialized
DEBUG - 2021-06-28 06:00:03 --> UTF-8 Support Enabled
INFO - 2021-06-28 06:00:03 --> Utf8 Class Initialized
INFO - 2021-06-28 06:00:03 --> URI Class Initialized
INFO - 2021-06-28 06:00:03 --> Router Class Initialized
INFO - 2021-06-28 06:00:03 --> Output Class Initialized
INFO - 2021-06-28 06:00:03 --> Security Class Initialized
DEBUG - 2021-06-28 06:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 06:00:03 --> Input Class Initialized
INFO - 2021-06-28 06:00:03 --> Language Class Initialized
INFO - 2021-06-28 06:00:03 --> Language Class Initialized
INFO - 2021-06-28 06:00:03 --> Config Class Initialized
INFO - 2021-06-28 06:00:03 --> Loader Class Initialized
INFO - 2021-06-28 06:00:03 --> Helper loaded: url_helper
INFO - 2021-06-28 06:00:03 --> Helper loaded: file_helper
INFO - 2021-06-28 06:00:03 --> Helper loaded: form_helper
INFO - 2021-06-28 06:00:03 --> Helper loaded: my_helper
INFO - 2021-06-28 06:00:03 --> Database Driver Class Initialized
DEBUG - 2021-06-28 06:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 06:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 06:00:03 --> Controller Class Initialized
INFO - 2021-06-28 06:00:03 --> Config Class Initialized
INFO - 2021-06-28 06:00:03 --> Hooks Class Initialized
DEBUG - 2021-06-28 06:00:03 --> UTF-8 Support Enabled
INFO - 2021-06-28 06:00:03 --> Utf8 Class Initialized
INFO - 2021-06-28 06:00:03 --> URI Class Initialized
INFO - 2021-06-28 06:00:03 --> Router Class Initialized
INFO - 2021-06-28 06:00:03 --> Output Class Initialized
INFO - 2021-06-28 06:00:03 --> Security Class Initialized
DEBUG - 2021-06-28 06:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 06:00:03 --> Input Class Initialized
INFO - 2021-06-28 06:00:03 --> Language Class Initialized
INFO - 2021-06-28 06:00:03 --> Language Class Initialized
INFO - 2021-06-28 06:00:03 --> Config Class Initialized
INFO - 2021-06-28 06:00:03 --> Loader Class Initialized
INFO - 2021-06-28 06:00:03 --> Helper loaded: url_helper
INFO - 2021-06-28 06:00:03 --> Helper loaded: file_helper
INFO - 2021-06-28 06:00:03 --> Helper loaded: form_helper
INFO - 2021-06-28 06:00:03 --> Helper loaded: my_helper
INFO - 2021-06-28 06:00:03 --> Database Driver Class Initialized
DEBUG - 2021-06-28 06:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 06:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 06:00:03 --> Controller Class Initialized
INFO - 2021-06-28 06:00:04 --> Config Class Initialized
INFO - 2021-06-28 06:00:04 --> Hooks Class Initialized
DEBUG - 2021-06-28 06:00:04 --> UTF-8 Support Enabled
INFO - 2021-06-28 06:00:04 --> Utf8 Class Initialized
INFO - 2021-06-28 06:00:04 --> URI Class Initialized
INFO - 2021-06-28 06:00:04 --> Router Class Initialized
INFO - 2021-06-28 06:00:04 --> Output Class Initialized
INFO - 2021-06-28 06:00:04 --> Security Class Initialized
DEBUG - 2021-06-28 06:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 06:00:04 --> Input Class Initialized
INFO - 2021-06-28 06:00:04 --> Language Class Initialized
INFO - 2021-06-28 06:00:04 --> Language Class Initialized
INFO - 2021-06-28 06:00:04 --> Config Class Initialized
INFO - 2021-06-28 06:00:04 --> Loader Class Initialized
INFO - 2021-06-28 06:00:04 --> Helper loaded: url_helper
INFO - 2021-06-28 06:00:04 --> Helper loaded: file_helper
INFO - 2021-06-28 06:00:04 --> Helper loaded: form_helper
INFO - 2021-06-28 06:00:04 --> Helper loaded: my_helper
INFO - 2021-06-28 06:00:04 --> Database Driver Class Initialized
DEBUG - 2021-06-28 06:00:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 06:00:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 06:00:04 --> Controller Class Initialized
INFO - 2021-06-28 06:00:05 --> Config Class Initialized
INFO - 2021-06-28 06:00:05 --> Hooks Class Initialized
DEBUG - 2021-06-28 06:00:05 --> UTF-8 Support Enabled
INFO - 2021-06-28 06:00:05 --> Utf8 Class Initialized
INFO - 2021-06-28 06:00:05 --> URI Class Initialized
INFO - 2021-06-28 06:00:05 --> Router Class Initialized
INFO - 2021-06-28 06:00:05 --> Output Class Initialized
INFO - 2021-06-28 06:00:05 --> Security Class Initialized
DEBUG - 2021-06-28 06:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 06:00:05 --> Input Class Initialized
INFO - 2021-06-28 06:00:05 --> Language Class Initialized
INFO - 2021-06-28 06:00:05 --> Language Class Initialized
INFO - 2021-06-28 06:00:05 --> Config Class Initialized
INFO - 2021-06-28 06:00:05 --> Loader Class Initialized
INFO - 2021-06-28 06:00:05 --> Helper loaded: url_helper
INFO - 2021-06-28 06:00:05 --> Helper loaded: file_helper
INFO - 2021-06-28 06:00:05 --> Helper loaded: form_helper
INFO - 2021-06-28 06:00:05 --> Helper loaded: my_helper
INFO - 2021-06-28 06:00:05 --> Database Driver Class Initialized
DEBUG - 2021-06-28 06:00:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 06:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 06:00:05 --> Controller Class Initialized
ERROR - 2021-06-28 06:00:05 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 241
DEBUG - 2021-06-28 06:00:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-06-28 06:00:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 06:00:05 --> Final output sent to browser
DEBUG - 2021-06-28 06:00:05 --> Total execution time: 0.0552
INFO - 2021-06-28 06:00:13 --> Config Class Initialized
INFO - 2021-06-28 06:00:13 --> Hooks Class Initialized
DEBUG - 2021-06-28 06:00:13 --> UTF-8 Support Enabled
INFO - 2021-06-28 06:00:13 --> Utf8 Class Initialized
INFO - 2021-06-28 06:00:13 --> URI Class Initialized
INFO - 2021-06-28 06:00:13 --> Router Class Initialized
INFO - 2021-06-28 06:00:13 --> Output Class Initialized
INFO - 2021-06-28 06:00:13 --> Security Class Initialized
DEBUG - 2021-06-28 06:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 06:00:13 --> Input Class Initialized
INFO - 2021-06-28 06:00:13 --> Language Class Initialized
INFO - 2021-06-28 06:00:13 --> Language Class Initialized
INFO - 2021-06-28 06:00:13 --> Config Class Initialized
INFO - 2021-06-28 06:00:13 --> Loader Class Initialized
INFO - 2021-06-28 06:00:13 --> Helper loaded: url_helper
INFO - 2021-06-28 06:00:13 --> Helper loaded: file_helper
INFO - 2021-06-28 06:00:13 --> Helper loaded: form_helper
INFO - 2021-06-28 06:00:13 --> Helper loaded: my_helper
INFO - 2021-06-28 06:00:13 --> Database Driver Class Initialized
DEBUG - 2021-06-28 06:00:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 06:00:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 06:00:13 --> Controller Class Initialized
INFO - 2021-06-28 06:00:14 --> Upload Class Initialized
INFO - 2021-06-28 06:00:14 --> Language file loaded: language/english/upload_lang.php
ERROR - 2021-06-28 06:00:14 --> The upload path does not appear to be valid.
INFO - 2021-06-28 06:00:14 --> Config Class Initialized
INFO - 2021-06-28 06:00:14 --> Hooks Class Initialized
DEBUG - 2021-06-28 06:00:14 --> UTF-8 Support Enabled
INFO - 2021-06-28 06:00:14 --> Utf8 Class Initialized
INFO - 2021-06-28 06:00:14 --> URI Class Initialized
INFO - 2021-06-28 06:00:14 --> Router Class Initialized
INFO - 2021-06-28 06:00:14 --> Output Class Initialized
INFO - 2021-06-28 06:00:14 --> Security Class Initialized
DEBUG - 2021-06-28 06:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 06:00:14 --> Input Class Initialized
INFO - 2021-06-28 06:00:14 --> Language Class Initialized
INFO - 2021-06-28 06:00:14 --> Language Class Initialized
INFO - 2021-06-28 06:00:14 --> Config Class Initialized
INFO - 2021-06-28 06:00:14 --> Loader Class Initialized
INFO - 2021-06-28 06:00:14 --> Helper loaded: url_helper
INFO - 2021-06-28 06:00:14 --> Helper loaded: file_helper
INFO - 2021-06-28 06:00:14 --> Helper loaded: form_helper
INFO - 2021-06-28 06:00:14 --> Helper loaded: my_helper
INFO - 2021-06-28 06:00:14 --> Database Driver Class Initialized
DEBUG - 2021-06-28 06:00:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 06:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 06:00:15 --> Controller Class Initialized
DEBUG - 2021-06-28 06:00:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-06-28 06:00:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 06:00:15 --> Final output sent to browser
DEBUG - 2021-06-28 06:00:15 --> Total execution time: 0.0494
INFO - 2021-06-28 06:00:15 --> Config Class Initialized
INFO - 2021-06-28 06:00:15 --> Hooks Class Initialized
DEBUG - 2021-06-28 06:00:15 --> UTF-8 Support Enabled
INFO - 2021-06-28 06:00:15 --> Utf8 Class Initialized
INFO - 2021-06-28 06:00:15 --> URI Class Initialized
INFO - 2021-06-28 06:00:15 --> Router Class Initialized
INFO - 2021-06-28 06:00:15 --> Output Class Initialized
INFO - 2021-06-28 06:00:15 --> Security Class Initialized
DEBUG - 2021-06-28 06:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 06:00:15 --> Input Class Initialized
INFO - 2021-06-28 06:00:15 --> Language Class Initialized
INFO - 2021-06-28 06:00:15 --> Language Class Initialized
INFO - 2021-06-28 06:00:15 --> Config Class Initialized
INFO - 2021-06-28 06:00:15 --> Loader Class Initialized
INFO - 2021-06-28 06:00:15 --> Helper loaded: url_helper
INFO - 2021-06-28 06:00:15 --> Helper loaded: file_helper
INFO - 2021-06-28 06:00:15 --> Helper loaded: form_helper
INFO - 2021-06-28 06:00:15 --> Helper loaded: my_helper
INFO - 2021-06-28 06:00:15 --> Database Driver Class Initialized
DEBUG - 2021-06-28 06:00:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 06:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 06:00:15 --> Controller Class Initialized
INFO - 2021-06-28 06:00:17 --> Config Class Initialized
INFO - 2021-06-28 06:00:17 --> Hooks Class Initialized
DEBUG - 2021-06-28 06:00:17 --> UTF-8 Support Enabled
INFO - 2021-06-28 06:00:17 --> Utf8 Class Initialized
INFO - 2021-06-28 06:00:17 --> URI Class Initialized
INFO - 2021-06-28 06:00:17 --> Router Class Initialized
INFO - 2021-06-28 06:00:17 --> Output Class Initialized
INFO - 2021-06-28 06:00:17 --> Security Class Initialized
DEBUG - 2021-06-28 06:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 06:00:17 --> Input Class Initialized
INFO - 2021-06-28 06:00:17 --> Language Class Initialized
INFO - 2021-06-28 06:00:17 --> Language Class Initialized
INFO - 2021-06-28 06:00:17 --> Config Class Initialized
INFO - 2021-06-28 06:00:17 --> Loader Class Initialized
INFO - 2021-06-28 06:00:17 --> Helper loaded: url_helper
INFO - 2021-06-28 06:00:17 --> Helper loaded: file_helper
INFO - 2021-06-28 06:00:17 --> Helper loaded: form_helper
INFO - 2021-06-28 06:00:17 --> Helper loaded: my_helper
INFO - 2021-06-28 06:00:17 --> Database Driver Class Initialized
DEBUG - 2021-06-28 06:00:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 06:00:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 06:00:17 --> Controller Class Initialized
DEBUG - 2021-06-28 06:00:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-28 06:00:17 --> Final output sent to browser
DEBUG - 2021-06-28 06:00:17 --> Total execution time: 0.0462
INFO - 2021-06-28 06:38:13 --> Config Class Initialized
INFO - 2021-06-28 06:38:13 --> Hooks Class Initialized
DEBUG - 2021-06-28 06:38:13 --> UTF-8 Support Enabled
INFO - 2021-06-28 06:38:13 --> Utf8 Class Initialized
INFO - 2021-06-28 06:38:13 --> URI Class Initialized
INFO - 2021-06-28 06:38:13 --> Router Class Initialized
INFO - 2021-06-28 06:38:13 --> Output Class Initialized
INFO - 2021-06-28 06:38:13 --> Security Class Initialized
DEBUG - 2021-06-28 06:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 06:38:13 --> Input Class Initialized
INFO - 2021-06-28 06:38:13 --> Language Class Initialized
INFO - 2021-06-28 06:38:13 --> Language Class Initialized
INFO - 2021-06-28 06:38:13 --> Config Class Initialized
INFO - 2021-06-28 06:38:13 --> Loader Class Initialized
INFO - 2021-06-28 06:38:13 --> Helper loaded: url_helper
INFO - 2021-06-28 06:38:13 --> Helper loaded: file_helper
INFO - 2021-06-28 06:38:13 --> Helper loaded: form_helper
INFO - 2021-06-28 06:38:13 --> Helper loaded: my_helper
INFO - 2021-06-28 06:38:13 --> Database Driver Class Initialized
DEBUG - 2021-06-28 06:38:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 06:38:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 06:38:13 --> Controller Class Initialized
INFO - 2021-06-28 06:38:13 --> Config Class Initialized
INFO - 2021-06-28 06:38:13 --> Hooks Class Initialized
DEBUG - 2021-06-28 06:38:13 --> UTF-8 Support Enabled
INFO - 2021-06-28 06:38:13 --> Utf8 Class Initialized
INFO - 2021-06-28 06:38:13 --> URI Class Initialized
INFO - 2021-06-28 06:38:13 --> Router Class Initialized
INFO - 2021-06-28 06:38:13 --> Output Class Initialized
INFO - 2021-06-28 06:38:13 --> Security Class Initialized
DEBUG - 2021-06-28 06:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 06:38:13 --> Input Class Initialized
INFO - 2021-06-28 06:38:13 --> Language Class Initialized
INFO - 2021-06-28 06:38:13 --> Language Class Initialized
INFO - 2021-06-28 06:38:13 --> Config Class Initialized
INFO - 2021-06-28 06:38:13 --> Loader Class Initialized
INFO - 2021-06-28 06:38:13 --> Helper loaded: url_helper
INFO - 2021-06-28 06:38:13 --> Helper loaded: file_helper
INFO - 2021-06-28 06:38:13 --> Helper loaded: form_helper
INFO - 2021-06-28 06:38:13 --> Helper loaded: my_helper
INFO - 2021-06-28 06:38:13 --> Database Driver Class Initialized
DEBUG - 2021-06-28 06:38:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 06:38:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 06:38:13 --> Controller Class Initialized
INFO - 2021-06-28 06:38:14 --> Config Class Initialized
INFO - 2021-06-28 06:38:14 --> Hooks Class Initialized
DEBUG - 2021-06-28 06:38:14 --> UTF-8 Support Enabled
INFO - 2021-06-28 06:38:14 --> Utf8 Class Initialized
INFO - 2021-06-28 06:38:14 --> URI Class Initialized
INFO - 2021-06-28 06:38:14 --> Router Class Initialized
INFO - 2021-06-28 06:38:14 --> Output Class Initialized
INFO - 2021-06-28 06:38:14 --> Security Class Initialized
DEBUG - 2021-06-28 06:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 06:38:14 --> Input Class Initialized
INFO - 2021-06-28 06:38:14 --> Language Class Initialized
INFO - 2021-06-28 06:38:14 --> Language Class Initialized
INFO - 2021-06-28 06:38:14 --> Config Class Initialized
INFO - 2021-06-28 06:38:14 --> Loader Class Initialized
INFO - 2021-06-28 06:38:14 --> Helper loaded: url_helper
INFO - 2021-06-28 06:38:14 --> Helper loaded: file_helper
INFO - 2021-06-28 06:38:14 --> Helper loaded: form_helper
INFO - 2021-06-28 06:38:14 --> Helper loaded: my_helper
INFO - 2021-06-28 06:38:14 --> Database Driver Class Initialized
DEBUG - 2021-06-28 06:38:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 06:38:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 06:38:14 --> Controller Class Initialized
INFO - 2021-06-28 06:38:17 --> Config Class Initialized
INFO - 2021-06-28 06:38:17 --> Hooks Class Initialized
DEBUG - 2021-06-28 06:38:17 --> UTF-8 Support Enabled
INFO - 2021-06-28 06:38:17 --> Utf8 Class Initialized
INFO - 2021-06-28 06:38:17 --> URI Class Initialized
INFO - 2021-06-28 06:38:17 --> Router Class Initialized
INFO - 2021-06-28 06:38:17 --> Output Class Initialized
INFO - 2021-06-28 06:38:17 --> Security Class Initialized
DEBUG - 2021-06-28 06:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 06:38:17 --> Input Class Initialized
INFO - 2021-06-28 06:38:17 --> Language Class Initialized
INFO - 2021-06-28 06:38:17 --> Language Class Initialized
INFO - 2021-06-28 06:38:17 --> Config Class Initialized
INFO - 2021-06-28 06:38:17 --> Loader Class Initialized
INFO - 2021-06-28 06:38:17 --> Helper loaded: url_helper
INFO - 2021-06-28 06:38:17 --> Helper loaded: file_helper
INFO - 2021-06-28 06:38:17 --> Helper loaded: form_helper
INFO - 2021-06-28 06:38:17 --> Helper loaded: my_helper
INFO - 2021-06-28 06:38:17 --> Database Driver Class Initialized
DEBUG - 2021-06-28 06:38:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 06:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 06:38:17 --> Controller Class Initialized
ERROR - 2021-06-28 06:38:17 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 241
DEBUG - 2021-06-28 06:38:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-06-28 06:38:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 06:38:17 --> Final output sent to browser
DEBUG - 2021-06-28 06:38:17 --> Total execution time: 0.0535
INFO - 2021-06-28 06:38:25 --> Config Class Initialized
INFO - 2021-06-28 06:38:25 --> Hooks Class Initialized
DEBUG - 2021-06-28 06:38:25 --> UTF-8 Support Enabled
INFO - 2021-06-28 06:38:25 --> Utf8 Class Initialized
INFO - 2021-06-28 06:38:25 --> URI Class Initialized
INFO - 2021-06-28 06:38:25 --> Router Class Initialized
INFO - 2021-06-28 06:38:25 --> Output Class Initialized
INFO - 2021-06-28 06:38:25 --> Security Class Initialized
DEBUG - 2021-06-28 06:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 06:38:25 --> Input Class Initialized
INFO - 2021-06-28 06:38:25 --> Language Class Initialized
INFO - 2021-06-28 06:38:25 --> Language Class Initialized
INFO - 2021-06-28 06:38:25 --> Config Class Initialized
INFO - 2021-06-28 06:38:25 --> Loader Class Initialized
INFO - 2021-06-28 06:38:25 --> Helper loaded: url_helper
INFO - 2021-06-28 06:38:25 --> Helper loaded: file_helper
INFO - 2021-06-28 06:38:25 --> Helper loaded: form_helper
INFO - 2021-06-28 06:38:25 --> Helper loaded: my_helper
INFO - 2021-06-28 06:38:25 --> Database Driver Class Initialized
DEBUG - 2021-06-28 06:38:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 06:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 06:38:25 --> Controller Class Initialized
INFO - 2021-06-28 06:38:25 --> Upload Class Initialized
INFO - 2021-06-28 06:38:25 --> Language file loaded: language/english/upload_lang.php
ERROR - 2021-06-28 06:38:25 --> The upload path does not appear to be valid.
INFO - 2021-06-28 06:38:25 --> Config Class Initialized
INFO - 2021-06-28 06:38:25 --> Hooks Class Initialized
DEBUG - 2021-06-28 06:38:25 --> UTF-8 Support Enabled
INFO - 2021-06-28 06:38:25 --> Utf8 Class Initialized
INFO - 2021-06-28 06:38:25 --> URI Class Initialized
INFO - 2021-06-28 06:38:25 --> Router Class Initialized
INFO - 2021-06-28 06:38:25 --> Output Class Initialized
INFO - 2021-06-28 06:38:25 --> Security Class Initialized
DEBUG - 2021-06-28 06:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 06:38:25 --> Input Class Initialized
INFO - 2021-06-28 06:38:25 --> Language Class Initialized
INFO - 2021-06-28 06:38:25 --> Language Class Initialized
INFO - 2021-06-28 06:38:25 --> Config Class Initialized
INFO - 2021-06-28 06:38:25 --> Loader Class Initialized
INFO - 2021-06-28 06:38:25 --> Helper loaded: url_helper
INFO - 2021-06-28 06:38:25 --> Helper loaded: file_helper
INFO - 2021-06-28 06:38:25 --> Helper loaded: form_helper
INFO - 2021-06-28 06:38:25 --> Helper loaded: my_helper
INFO - 2021-06-28 06:38:25 --> Database Driver Class Initialized
DEBUG - 2021-06-28 06:38:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 06:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 06:38:25 --> Controller Class Initialized
DEBUG - 2021-06-28 06:38:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-06-28 06:38:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 06:38:25 --> Final output sent to browser
DEBUG - 2021-06-28 06:38:25 --> Total execution time: 0.0388
INFO - 2021-06-28 06:38:25 --> Config Class Initialized
INFO - 2021-06-28 06:38:25 --> Hooks Class Initialized
DEBUG - 2021-06-28 06:38:25 --> UTF-8 Support Enabled
INFO - 2021-06-28 06:38:25 --> Utf8 Class Initialized
INFO - 2021-06-28 06:38:25 --> URI Class Initialized
INFO - 2021-06-28 06:38:25 --> Router Class Initialized
INFO - 2021-06-28 06:38:25 --> Output Class Initialized
INFO - 2021-06-28 06:38:25 --> Security Class Initialized
DEBUG - 2021-06-28 06:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 06:38:25 --> Input Class Initialized
INFO - 2021-06-28 06:38:25 --> Language Class Initialized
INFO - 2021-06-28 06:38:25 --> Language Class Initialized
INFO - 2021-06-28 06:38:25 --> Config Class Initialized
INFO - 2021-06-28 06:38:25 --> Loader Class Initialized
INFO - 2021-06-28 06:38:25 --> Helper loaded: url_helper
INFO - 2021-06-28 06:38:25 --> Helper loaded: file_helper
INFO - 2021-06-28 06:38:25 --> Helper loaded: form_helper
INFO - 2021-06-28 06:38:25 --> Helper loaded: my_helper
INFO - 2021-06-28 06:38:25 --> Database Driver Class Initialized
DEBUG - 2021-06-28 06:38:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 06:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 06:38:25 --> Controller Class Initialized
INFO - 2021-06-28 06:38:28 --> Config Class Initialized
INFO - 2021-06-28 06:38:28 --> Hooks Class Initialized
DEBUG - 2021-06-28 06:38:28 --> UTF-8 Support Enabled
INFO - 2021-06-28 06:38:28 --> Utf8 Class Initialized
INFO - 2021-06-28 06:38:28 --> URI Class Initialized
INFO - 2021-06-28 06:38:28 --> Router Class Initialized
INFO - 2021-06-28 06:38:28 --> Output Class Initialized
INFO - 2021-06-28 06:38:28 --> Security Class Initialized
DEBUG - 2021-06-28 06:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 06:38:28 --> Input Class Initialized
INFO - 2021-06-28 06:38:28 --> Language Class Initialized
INFO - 2021-06-28 06:38:28 --> Language Class Initialized
INFO - 2021-06-28 06:38:28 --> Config Class Initialized
INFO - 2021-06-28 06:38:28 --> Loader Class Initialized
INFO - 2021-06-28 06:38:28 --> Helper loaded: url_helper
INFO - 2021-06-28 06:38:28 --> Helper loaded: file_helper
INFO - 2021-06-28 06:38:28 --> Helper loaded: form_helper
INFO - 2021-06-28 06:38:28 --> Helper loaded: my_helper
INFO - 2021-06-28 06:38:28 --> Database Driver Class Initialized
DEBUG - 2021-06-28 06:38:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 06:38:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 06:38:28 --> Controller Class Initialized
DEBUG - 2021-06-28 06:38:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-28 06:38:28 --> Final output sent to browser
DEBUG - 2021-06-28 06:38:28 --> Total execution time: 0.0573
INFO - 2021-06-28 06:54:36 --> Config Class Initialized
INFO - 2021-06-28 06:54:36 --> Hooks Class Initialized
DEBUG - 2021-06-28 06:54:36 --> UTF-8 Support Enabled
INFO - 2021-06-28 06:54:36 --> Utf8 Class Initialized
INFO - 2021-06-28 06:54:36 --> URI Class Initialized
INFO - 2021-06-28 06:54:36 --> Router Class Initialized
INFO - 2021-06-28 06:54:36 --> Output Class Initialized
INFO - 2021-06-28 06:54:36 --> Security Class Initialized
DEBUG - 2021-06-28 06:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 06:54:36 --> Input Class Initialized
INFO - 2021-06-28 06:54:36 --> Language Class Initialized
INFO - 2021-06-28 06:54:36 --> Language Class Initialized
INFO - 2021-06-28 06:54:36 --> Config Class Initialized
INFO - 2021-06-28 06:54:36 --> Loader Class Initialized
INFO - 2021-06-28 06:54:36 --> Helper loaded: url_helper
INFO - 2021-06-28 06:54:36 --> Helper loaded: file_helper
INFO - 2021-06-28 06:54:36 --> Helper loaded: form_helper
INFO - 2021-06-28 06:54:36 --> Helper loaded: my_helper
INFO - 2021-06-28 06:54:36 --> Database Driver Class Initialized
DEBUG - 2021-06-28 06:54:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 06:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 06:54:36 --> Controller Class Initialized
DEBUG - 2021-06-28 06:54:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-28 06:54:36 --> Final output sent to browser
DEBUG - 2021-06-28 06:54:36 --> Total execution time: 0.0490
INFO - 2021-06-28 06:55:15 --> Config Class Initialized
INFO - 2021-06-28 06:55:15 --> Hooks Class Initialized
DEBUG - 2021-06-28 06:55:15 --> UTF-8 Support Enabled
INFO - 2021-06-28 06:55:15 --> Utf8 Class Initialized
INFO - 2021-06-28 06:55:15 --> URI Class Initialized
INFO - 2021-06-28 06:55:15 --> Router Class Initialized
INFO - 2021-06-28 06:55:15 --> Output Class Initialized
INFO - 2021-06-28 06:55:15 --> Security Class Initialized
DEBUG - 2021-06-28 06:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 06:55:15 --> Input Class Initialized
INFO - 2021-06-28 06:55:15 --> Language Class Initialized
INFO - 2021-06-28 06:55:15 --> Language Class Initialized
INFO - 2021-06-28 06:55:15 --> Config Class Initialized
INFO - 2021-06-28 06:55:15 --> Loader Class Initialized
INFO - 2021-06-28 06:55:15 --> Helper loaded: url_helper
INFO - 2021-06-28 06:55:15 --> Helper loaded: file_helper
INFO - 2021-06-28 06:55:15 --> Helper loaded: form_helper
INFO - 2021-06-28 06:55:15 --> Helper loaded: my_helper
INFO - 2021-06-28 06:55:15 --> Database Driver Class Initialized
DEBUG - 2021-06-28 06:55:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 06:55:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 06:55:15 --> Controller Class Initialized
INFO - 2021-06-28 06:55:15 --> Config Class Initialized
INFO - 2021-06-28 06:55:15 --> Hooks Class Initialized
DEBUG - 2021-06-28 06:55:15 --> UTF-8 Support Enabled
INFO - 2021-06-28 06:55:15 --> Utf8 Class Initialized
INFO - 2021-06-28 06:55:15 --> URI Class Initialized
INFO - 2021-06-28 06:55:15 --> Router Class Initialized
INFO - 2021-06-28 06:55:15 --> Output Class Initialized
INFO - 2021-06-28 06:55:15 --> Security Class Initialized
DEBUG - 2021-06-28 06:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 06:55:15 --> Input Class Initialized
INFO - 2021-06-28 06:55:15 --> Language Class Initialized
INFO - 2021-06-28 06:55:15 --> Language Class Initialized
INFO - 2021-06-28 06:55:15 --> Config Class Initialized
INFO - 2021-06-28 06:55:15 --> Loader Class Initialized
INFO - 2021-06-28 06:55:15 --> Helper loaded: url_helper
INFO - 2021-06-28 06:55:15 --> Helper loaded: file_helper
INFO - 2021-06-28 06:55:15 --> Helper loaded: form_helper
INFO - 2021-06-28 06:55:15 --> Helper loaded: my_helper
INFO - 2021-06-28 06:55:15 --> Database Driver Class Initialized
DEBUG - 2021-06-28 06:55:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 06:55:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 06:55:15 --> Controller Class Initialized
INFO - 2021-06-28 06:55:16 --> Config Class Initialized
INFO - 2021-06-28 06:55:16 --> Hooks Class Initialized
DEBUG - 2021-06-28 06:55:16 --> UTF-8 Support Enabled
INFO - 2021-06-28 06:55:16 --> Utf8 Class Initialized
INFO - 2021-06-28 06:55:16 --> URI Class Initialized
INFO - 2021-06-28 06:55:16 --> Router Class Initialized
INFO - 2021-06-28 06:55:16 --> Output Class Initialized
INFO - 2021-06-28 06:55:16 --> Security Class Initialized
DEBUG - 2021-06-28 06:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 06:55:16 --> Input Class Initialized
INFO - 2021-06-28 06:55:16 --> Language Class Initialized
INFO - 2021-06-28 06:55:16 --> Language Class Initialized
INFO - 2021-06-28 06:55:16 --> Config Class Initialized
INFO - 2021-06-28 06:55:16 --> Loader Class Initialized
INFO - 2021-06-28 06:55:16 --> Helper loaded: url_helper
INFO - 2021-06-28 06:55:16 --> Helper loaded: file_helper
INFO - 2021-06-28 06:55:16 --> Helper loaded: form_helper
INFO - 2021-06-28 06:55:16 --> Helper loaded: my_helper
INFO - 2021-06-28 06:55:16 --> Database Driver Class Initialized
DEBUG - 2021-06-28 06:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 06:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 06:55:16 --> Controller Class Initialized
INFO - 2021-06-28 06:55:17 --> Config Class Initialized
INFO - 2021-06-28 06:55:17 --> Hooks Class Initialized
DEBUG - 2021-06-28 06:55:17 --> UTF-8 Support Enabled
INFO - 2021-06-28 06:55:17 --> Utf8 Class Initialized
INFO - 2021-06-28 06:55:17 --> URI Class Initialized
INFO - 2021-06-28 06:55:17 --> Router Class Initialized
INFO - 2021-06-28 06:55:17 --> Output Class Initialized
INFO - 2021-06-28 06:55:17 --> Security Class Initialized
DEBUG - 2021-06-28 06:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 06:55:17 --> Input Class Initialized
INFO - 2021-06-28 06:55:17 --> Language Class Initialized
INFO - 2021-06-28 06:55:17 --> Language Class Initialized
INFO - 2021-06-28 06:55:17 --> Config Class Initialized
INFO - 2021-06-28 06:55:17 --> Loader Class Initialized
INFO - 2021-06-28 06:55:17 --> Helper loaded: url_helper
INFO - 2021-06-28 06:55:17 --> Helper loaded: file_helper
INFO - 2021-06-28 06:55:17 --> Helper loaded: form_helper
INFO - 2021-06-28 06:55:17 --> Helper loaded: my_helper
INFO - 2021-06-28 06:55:17 --> Database Driver Class Initialized
DEBUG - 2021-06-28 06:55:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 06:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 06:55:17 --> Controller Class Initialized
ERROR - 2021-06-28 06:55:17 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 241
DEBUG - 2021-06-28 06:55:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-06-28 06:55:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 06:55:17 --> Final output sent to browser
DEBUG - 2021-06-28 06:55:17 --> Total execution time: 0.0445
INFO - 2021-06-28 06:56:01 --> Config Class Initialized
INFO - 2021-06-28 06:56:01 --> Hooks Class Initialized
DEBUG - 2021-06-28 06:56:01 --> UTF-8 Support Enabled
INFO - 2021-06-28 06:56:01 --> Utf8 Class Initialized
INFO - 2021-06-28 06:56:01 --> URI Class Initialized
INFO - 2021-06-28 06:56:01 --> Router Class Initialized
INFO - 2021-06-28 06:56:01 --> Output Class Initialized
INFO - 2021-06-28 06:56:01 --> Security Class Initialized
DEBUG - 2021-06-28 06:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 06:56:01 --> Input Class Initialized
INFO - 2021-06-28 06:56:01 --> Language Class Initialized
INFO - 2021-06-28 06:56:01 --> Language Class Initialized
INFO - 2021-06-28 06:56:01 --> Config Class Initialized
INFO - 2021-06-28 06:56:01 --> Loader Class Initialized
INFO - 2021-06-28 06:56:01 --> Helper loaded: url_helper
INFO - 2021-06-28 06:56:01 --> Helper loaded: file_helper
INFO - 2021-06-28 06:56:01 --> Helper loaded: form_helper
INFO - 2021-06-28 06:56:01 --> Helper loaded: my_helper
INFO - 2021-06-28 06:56:01 --> Database Driver Class Initialized
DEBUG - 2021-06-28 06:56:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 06:56:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 06:56:01 --> Controller Class Initialized
DEBUG - 2021-06-28 06:56:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-28 06:56:01 --> Final output sent to browser
DEBUG - 2021-06-28 06:56:01 --> Total execution time: 0.0456
INFO - 2021-06-28 06:57:18 --> Config Class Initialized
INFO - 2021-06-28 06:57:18 --> Hooks Class Initialized
DEBUG - 2021-06-28 06:57:18 --> UTF-8 Support Enabled
INFO - 2021-06-28 06:57:18 --> Utf8 Class Initialized
INFO - 2021-06-28 06:57:18 --> URI Class Initialized
INFO - 2021-06-28 06:57:18 --> Router Class Initialized
INFO - 2021-06-28 06:57:18 --> Output Class Initialized
INFO - 2021-06-28 06:57:18 --> Security Class Initialized
DEBUG - 2021-06-28 06:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 06:57:18 --> Input Class Initialized
INFO - 2021-06-28 06:57:18 --> Language Class Initialized
INFO - 2021-06-28 06:57:18 --> Language Class Initialized
INFO - 2021-06-28 06:57:18 --> Config Class Initialized
INFO - 2021-06-28 06:57:18 --> Loader Class Initialized
INFO - 2021-06-28 06:57:18 --> Helper loaded: url_helper
INFO - 2021-06-28 06:57:18 --> Helper loaded: file_helper
INFO - 2021-06-28 06:57:18 --> Helper loaded: form_helper
INFO - 2021-06-28 06:57:18 --> Helper loaded: my_helper
INFO - 2021-06-28 06:57:19 --> Database Driver Class Initialized
DEBUG - 2021-06-28 06:57:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 06:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 06:57:19 --> Controller Class Initialized
DEBUG - 2021-06-28 06:57:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-06-28 06:57:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 06:57:19 --> Final output sent to browser
DEBUG - 2021-06-28 06:57:19 --> Total execution time: 0.0504
INFO - 2021-06-28 06:57:19 --> Config Class Initialized
INFO - 2021-06-28 06:57:19 --> Hooks Class Initialized
DEBUG - 2021-06-28 06:57:19 --> UTF-8 Support Enabled
INFO - 2021-06-28 06:57:19 --> Utf8 Class Initialized
INFO - 2021-06-28 06:57:19 --> URI Class Initialized
INFO - 2021-06-28 06:57:19 --> Router Class Initialized
INFO - 2021-06-28 06:57:19 --> Output Class Initialized
INFO - 2021-06-28 06:57:19 --> Security Class Initialized
DEBUG - 2021-06-28 06:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 06:57:19 --> Input Class Initialized
INFO - 2021-06-28 06:57:19 --> Language Class Initialized
INFO - 2021-06-28 06:57:19 --> Language Class Initialized
INFO - 2021-06-28 06:57:19 --> Config Class Initialized
INFO - 2021-06-28 06:57:19 --> Loader Class Initialized
INFO - 2021-06-28 06:57:19 --> Helper loaded: url_helper
INFO - 2021-06-28 06:57:19 --> Helper loaded: file_helper
INFO - 2021-06-28 06:57:19 --> Helper loaded: form_helper
INFO - 2021-06-28 06:57:19 --> Helper loaded: my_helper
INFO - 2021-06-28 06:57:19 --> Database Driver Class Initialized
DEBUG - 2021-06-28 06:57:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 06:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 06:57:19 --> Controller Class Initialized
INFO - 2021-06-28 08:05:01 --> Config Class Initialized
INFO - 2021-06-28 08:05:01 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:05:01 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:05:01 --> Utf8 Class Initialized
INFO - 2021-06-28 08:05:01 --> URI Class Initialized
INFO - 2021-06-28 08:05:01 --> Router Class Initialized
INFO - 2021-06-28 08:05:01 --> Output Class Initialized
INFO - 2021-06-28 08:05:01 --> Security Class Initialized
DEBUG - 2021-06-28 08:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:05:01 --> Input Class Initialized
INFO - 2021-06-28 08:05:01 --> Language Class Initialized
INFO - 2021-06-28 08:05:01 --> Language Class Initialized
INFO - 2021-06-28 08:05:01 --> Config Class Initialized
INFO - 2021-06-28 08:05:01 --> Loader Class Initialized
INFO - 2021-06-28 08:05:01 --> Helper loaded: url_helper
INFO - 2021-06-28 08:05:01 --> Helper loaded: file_helper
INFO - 2021-06-28 08:05:01 --> Helper loaded: form_helper
INFO - 2021-06-28 08:05:01 --> Helper loaded: my_helper
INFO - 2021-06-28 08:05:01 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:05:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:05:01 --> Controller Class Initialized
INFO - 2021-06-28 08:05:01 --> Helper loaded: cookie_helper
INFO - 2021-06-28 08:05:01 --> Config Class Initialized
INFO - 2021-06-28 08:05:01 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:05:01 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:05:01 --> Utf8 Class Initialized
INFO - 2021-06-28 08:05:01 --> URI Class Initialized
INFO - 2021-06-28 08:05:01 --> Router Class Initialized
INFO - 2021-06-28 08:05:01 --> Output Class Initialized
INFO - 2021-06-28 08:05:01 --> Security Class Initialized
DEBUG - 2021-06-28 08:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:05:01 --> Input Class Initialized
INFO - 2021-06-28 08:05:01 --> Language Class Initialized
INFO - 2021-06-28 08:05:01 --> Language Class Initialized
INFO - 2021-06-28 08:05:01 --> Config Class Initialized
INFO - 2021-06-28 08:05:01 --> Loader Class Initialized
INFO - 2021-06-28 08:05:01 --> Helper loaded: url_helper
INFO - 2021-06-28 08:05:01 --> Helper loaded: file_helper
INFO - 2021-06-28 08:05:01 --> Helper loaded: form_helper
INFO - 2021-06-28 08:05:01 --> Helper loaded: my_helper
INFO - 2021-06-28 08:05:01 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:05:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:05:01 --> Controller Class Initialized
DEBUG - 2021-06-28 08:05:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-28 08:05:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:05:01 --> Final output sent to browser
DEBUG - 2021-06-28 08:05:01 --> Total execution time: 0.0420
INFO - 2021-06-28 08:05:10 --> Config Class Initialized
INFO - 2021-06-28 08:05:10 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:05:10 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:05:10 --> Utf8 Class Initialized
INFO - 2021-06-28 08:05:10 --> URI Class Initialized
INFO - 2021-06-28 08:05:10 --> Router Class Initialized
INFO - 2021-06-28 08:05:10 --> Output Class Initialized
INFO - 2021-06-28 08:05:10 --> Security Class Initialized
DEBUG - 2021-06-28 08:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:05:10 --> Input Class Initialized
INFO - 2021-06-28 08:05:10 --> Language Class Initialized
INFO - 2021-06-28 08:05:10 --> Language Class Initialized
INFO - 2021-06-28 08:05:10 --> Config Class Initialized
INFO - 2021-06-28 08:05:10 --> Loader Class Initialized
INFO - 2021-06-28 08:05:10 --> Helper loaded: url_helper
INFO - 2021-06-28 08:05:10 --> Helper loaded: file_helper
INFO - 2021-06-28 08:05:10 --> Helper loaded: form_helper
INFO - 2021-06-28 08:05:10 --> Helper loaded: my_helper
INFO - 2021-06-28 08:05:10 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:05:10 --> Controller Class Initialized
INFO - 2021-06-28 08:05:10 --> Helper loaded: cookie_helper
INFO - 2021-06-28 08:05:10 --> Final output sent to browser
DEBUG - 2021-06-28 08:05:10 --> Total execution time: 0.0494
INFO - 2021-06-28 08:05:10 --> Config Class Initialized
INFO - 2021-06-28 08:05:10 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:05:10 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:05:10 --> Utf8 Class Initialized
INFO - 2021-06-28 08:05:10 --> URI Class Initialized
INFO - 2021-06-28 08:05:10 --> Router Class Initialized
INFO - 2021-06-28 08:05:10 --> Output Class Initialized
INFO - 2021-06-28 08:05:10 --> Security Class Initialized
DEBUG - 2021-06-28 08:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:05:10 --> Input Class Initialized
INFO - 2021-06-28 08:05:10 --> Language Class Initialized
INFO - 2021-06-28 08:05:10 --> Language Class Initialized
INFO - 2021-06-28 08:05:10 --> Config Class Initialized
INFO - 2021-06-28 08:05:10 --> Loader Class Initialized
INFO - 2021-06-28 08:05:10 --> Helper loaded: url_helper
INFO - 2021-06-28 08:05:10 --> Helper loaded: file_helper
INFO - 2021-06-28 08:05:10 --> Helper loaded: form_helper
INFO - 2021-06-28 08:05:10 --> Helper loaded: my_helper
INFO - 2021-06-28 08:05:10 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:05:10 --> Controller Class Initialized
DEBUG - 2021-06-28 08:05:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-28 08:05:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:05:11 --> Final output sent to browser
DEBUG - 2021-06-28 08:05:11 --> Total execution time: 0.6450
INFO - 2021-06-28 08:05:12 --> Config Class Initialized
INFO - 2021-06-28 08:05:12 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:05:12 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:05:12 --> Utf8 Class Initialized
INFO - 2021-06-28 08:05:12 --> URI Class Initialized
INFO - 2021-06-28 08:05:12 --> Router Class Initialized
INFO - 2021-06-28 08:05:12 --> Output Class Initialized
INFO - 2021-06-28 08:05:12 --> Security Class Initialized
DEBUG - 2021-06-28 08:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:05:12 --> Input Class Initialized
INFO - 2021-06-28 08:05:12 --> Language Class Initialized
INFO - 2021-06-28 08:05:12 --> Language Class Initialized
INFO - 2021-06-28 08:05:12 --> Config Class Initialized
INFO - 2021-06-28 08:05:12 --> Loader Class Initialized
INFO - 2021-06-28 08:05:12 --> Helper loaded: url_helper
INFO - 2021-06-28 08:05:12 --> Helper loaded: file_helper
INFO - 2021-06-28 08:05:12 --> Helper loaded: form_helper
INFO - 2021-06-28 08:05:12 --> Helper loaded: my_helper
INFO - 2021-06-28 08:05:12 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:05:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:05:12 --> Controller Class Initialized
INFO - 2021-06-28 08:05:12 --> Helper loaded: cookie_helper
INFO - 2021-06-28 08:05:12 --> Config Class Initialized
INFO - 2021-06-28 08:05:12 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:05:12 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:05:12 --> Utf8 Class Initialized
INFO - 2021-06-28 08:05:12 --> URI Class Initialized
INFO - 2021-06-28 08:05:12 --> Router Class Initialized
INFO - 2021-06-28 08:05:12 --> Output Class Initialized
INFO - 2021-06-28 08:05:12 --> Security Class Initialized
DEBUG - 2021-06-28 08:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:05:12 --> Input Class Initialized
INFO - 2021-06-28 08:05:12 --> Language Class Initialized
INFO - 2021-06-28 08:05:12 --> Language Class Initialized
INFO - 2021-06-28 08:05:12 --> Config Class Initialized
INFO - 2021-06-28 08:05:12 --> Loader Class Initialized
INFO - 2021-06-28 08:05:12 --> Helper loaded: url_helper
INFO - 2021-06-28 08:05:12 --> Helper loaded: file_helper
INFO - 2021-06-28 08:05:12 --> Helper loaded: form_helper
INFO - 2021-06-28 08:05:12 --> Helper loaded: my_helper
INFO - 2021-06-28 08:05:12 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:05:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:05:12 --> Controller Class Initialized
DEBUG - 2021-06-28 08:05:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-28 08:05:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:05:12 --> Final output sent to browser
DEBUG - 2021-06-28 08:05:12 --> Total execution time: 0.0497
INFO - 2021-06-28 08:05:17 --> Config Class Initialized
INFO - 2021-06-28 08:05:17 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:05:17 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:05:17 --> Utf8 Class Initialized
INFO - 2021-06-28 08:05:17 --> URI Class Initialized
INFO - 2021-06-28 08:05:17 --> Router Class Initialized
INFO - 2021-06-28 08:05:17 --> Output Class Initialized
INFO - 2021-06-28 08:05:17 --> Security Class Initialized
DEBUG - 2021-06-28 08:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:05:17 --> Input Class Initialized
INFO - 2021-06-28 08:05:17 --> Language Class Initialized
INFO - 2021-06-28 08:05:17 --> Language Class Initialized
INFO - 2021-06-28 08:05:17 --> Config Class Initialized
INFO - 2021-06-28 08:05:17 --> Loader Class Initialized
INFO - 2021-06-28 08:05:17 --> Helper loaded: url_helper
INFO - 2021-06-28 08:05:17 --> Helper loaded: file_helper
INFO - 2021-06-28 08:05:17 --> Helper loaded: form_helper
INFO - 2021-06-28 08:05:17 --> Helper loaded: my_helper
INFO - 2021-06-28 08:05:17 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:05:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:05:17 --> Controller Class Initialized
INFO - 2021-06-28 08:05:17 --> Helper loaded: cookie_helper
INFO - 2021-06-28 08:05:17 --> Final output sent to browser
DEBUG - 2021-06-28 08:05:17 --> Total execution time: 0.0424
INFO - 2021-06-28 08:05:18 --> Config Class Initialized
INFO - 2021-06-28 08:05:18 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:05:18 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:05:18 --> Utf8 Class Initialized
INFO - 2021-06-28 08:05:18 --> URI Class Initialized
INFO - 2021-06-28 08:05:18 --> Router Class Initialized
INFO - 2021-06-28 08:05:18 --> Output Class Initialized
INFO - 2021-06-28 08:05:18 --> Security Class Initialized
DEBUG - 2021-06-28 08:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:05:18 --> Input Class Initialized
INFO - 2021-06-28 08:05:18 --> Language Class Initialized
INFO - 2021-06-28 08:05:18 --> Language Class Initialized
INFO - 2021-06-28 08:05:18 --> Config Class Initialized
INFO - 2021-06-28 08:05:18 --> Loader Class Initialized
INFO - 2021-06-28 08:05:18 --> Helper loaded: url_helper
INFO - 2021-06-28 08:05:18 --> Helper loaded: file_helper
INFO - 2021-06-28 08:05:18 --> Helper loaded: form_helper
INFO - 2021-06-28 08:05:18 --> Helper loaded: my_helper
INFO - 2021-06-28 08:05:18 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:05:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:05:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:05:18 --> Controller Class Initialized
DEBUG - 2021-06-28 08:05:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-28 08:05:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:05:18 --> Final output sent to browser
DEBUG - 2021-06-28 08:05:18 --> Total execution time: 0.5997
INFO - 2021-06-28 08:05:19 --> Config Class Initialized
INFO - 2021-06-28 08:05:19 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:05:19 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:05:19 --> Utf8 Class Initialized
INFO - 2021-06-28 08:05:19 --> URI Class Initialized
INFO - 2021-06-28 08:05:19 --> Router Class Initialized
INFO - 2021-06-28 08:05:19 --> Output Class Initialized
INFO - 2021-06-28 08:05:19 --> Security Class Initialized
DEBUG - 2021-06-28 08:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:05:19 --> Input Class Initialized
INFO - 2021-06-28 08:05:19 --> Language Class Initialized
INFO - 2021-06-28 08:05:19 --> Language Class Initialized
INFO - 2021-06-28 08:05:19 --> Config Class Initialized
INFO - 2021-06-28 08:05:19 --> Loader Class Initialized
INFO - 2021-06-28 08:05:19 --> Helper loaded: url_helper
INFO - 2021-06-28 08:05:19 --> Helper loaded: file_helper
INFO - 2021-06-28 08:05:19 --> Helper loaded: form_helper
INFO - 2021-06-28 08:05:19 --> Helper loaded: my_helper
INFO - 2021-06-28 08:05:19 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:05:19 --> Controller Class Initialized
DEBUG - 2021-06-28 08:05:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-28 08:05:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:05:19 --> Final output sent to browser
DEBUG - 2021-06-28 08:05:19 --> Total execution time: 0.0542
INFO - 2021-06-28 08:05:20 --> Config Class Initialized
INFO - 2021-06-28 08:05:20 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:05:20 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:05:20 --> Utf8 Class Initialized
INFO - 2021-06-28 08:05:20 --> URI Class Initialized
DEBUG - 2021-06-28 08:05:20 --> No URI present. Default controller set.
INFO - 2021-06-28 08:05:20 --> Router Class Initialized
INFO - 2021-06-28 08:05:20 --> Output Class Initialized
INFO - 2021-06-28 08:05:20 --> Security Class Initialized
DEBUG - 2021-06-28 08:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:05:20 --> Input Class Initialized
INFO - 2021-06-28 08:05:20 --> Language Class Initialized
INFO - 2021-06-28 08:05:20 --> Language Class Initialized
INFO - 2021-06-28 08:05:20 --> Config Class Initialized
INFO - 2021-06-28 08:05:20 --> Loader Class Initialized
INFO - 2021-06-28 08:05:20 --> Helper loaded: url_helper
INFO - 2021-06-28 08:05:20 --> Helper loaded: file_helper
INFO - 2021-06-28 08:05:20 --> Helper loaded: form_helper
INFO - 2021-06-28 08:05:20 --> Helper loaded: my_helper
INFO - 2021-06-28 08:05:20 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:05:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:05:20 --> Controller Class Initialized
DEBUG - 2021-06-28 08:05:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-28 08:05:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:05:21 --> Final output sent to browser
DEBUG - 2021-06-28 08:05:21 --> Total execution time: 0.5943
INFO - 2021-06-28 08:05:23 --> Config Class Initialized
INFO - 2021-06-28 08:05:23 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:05:23 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:05:23 --> Utf8 Class Initialized
INFO - 2021-06-28 08:05:23 --> URI Class Initialized
INFO - 2021-06-28 08:05:23 --> Router Class Initialized
INFO - 2021-06-28 08:05:23 --> Output Class Initialized
INFO - 2021-06-28 08:05:23 --> Security Class Initialized
DEBUG - 2021-06-28 08:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:05:23 --> Input Class Initialized
INFO - 2021-06-28 08:05:23 --> Language Class Initialized
INFO - 2021-06-28 08:05:23 --> Language Class Initialized
INFO - 2021-06-28 08:05:23 --> Config Class Initialized
INFO - 2021-06-28 08:05:23 --> Loader Class Initialized
INFO - 2021-06-28 08:05:23 --> Helper loaded: url_helper
INFO - 2021-06-28 08:05:23 --> Helper loaded: file_helper
INFO - 2021-06-28 08:05:23 --> Helper loaded: form_helper
INFO - 2021-06-28 08:05:23 --> Helper loaded: my_helper
INFO - 2021-06-28 08:05:23 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:05:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:05:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:05:23 --> Controller Class Initialized
DEBUG - 2021-06-28 08:05:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-28 08:05:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:05:23 --> Final output sent to browser
DEBUG - 2021-06-28 08:05:23 --> Total execution time: 0.0497
INFO - 2021-06-28 08:05:25 --> Config Class Initialized
INFO - 2021-06-28 08:05:25 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:05:25 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:05:25 --> Utf8 Class Initialized
INFO - 2021-06-28 08:05:25 --> URI Class Initialized
INFO - 2021-06-28 08:05:25 --> Router Class Initialized
INFO - 2021-06-28 08:05:25 --> Output Class Initialized
INFO - 2021-06-28 08:05:25 --> Security Class Initialized
DEBUG - 2021-06-28 08:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:05:25 --> Input Class Initialized
INFO - 2021-06-28 08:05:25 --> Language Class Initialized
INFO - 2021-06-28 08:05:25 --> Language Class Initialized
INFO - 2021-06-28 08:05:25 --> Config Class Initialized
INFO - 2021-06-28 08:05:25 --> Loader Class Initialized
INFO - 2021-06-28 08:05:25 --> Helper loaded: url_helper
INFO - 2021-06-28 08:05:25 --> Helper loaded: file_helper
INFO - 2021-06-28 08:05:25 --> Helper loaded: form_helper
INFO - 2021-06-28 08:05:25 --> Helper loaded: my_helper
INFO - 2021-06-28 08:05:25 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:05:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:05:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:05:25 --> Controller Class Initialized
DEBUG - 2021-06-28 08:05:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-28 08:05:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:05:25 --> Final output sent to browser
DEBUG - 2021-06-28 08:05:25 --> Total execution time: 0.0503
INFO - 2021-06-28 08:05:26 --> Config Class Initialized
INFO - 2021-06-28 08:05:26 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:05:26 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:05:26 --> Utf8 Class Initialized
INFO - 2021-06-28 08:05:26 --> URI Class Initialized
INFO - 2021-06-28 08:05:26 --> Router Class Initialized
INFO - 2021-06-28 08:05:26 --> Output Class Initialized
INFO - 2021-06-28 08:05:26 --> Security Class Initialized
DEBUG - 2021-06-28 08:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:05:26 --> Input Class Initialized
INFO - 2021-06-28 08:05:26 --> Language Class Initialized
INFO - 2021-06-28 08:05:26 --> Language Class Initialized
INFO - 2021-06-28 08:05:26 --> Config Class Initialized
INFO - 2021-06-28 08:05:26 --> Loader Class Initialized
INFO - 2021-06-28 08:05:26 --> Helper loaded: url_helper
INFO - 2021-06-28 08:05:26 --> Helper loaded: file_helper
INFO - 2021-06-28 08:05:26 --> Helper loaded: form_helper
INFO - 2021-06-28 08:05:26 --> Helper loaded: my_helper
INFO - 2021-06-28 08:05:26 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:05:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:05:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:05:26 --> Controller Class Initialized
INFO - 2021-06-28 08:05:27 --> Config Class Initialized
INFO - 2021-06-28 08:05:27 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:05:27 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:05:27 --> Utf8 Class Initialized
INFO - 2021-06-28 08:05:27 --> URI Class Initialized
INFO - 2021-06-28 08:05:27 --> Router Class Initialized
INFO - 2021-06-28 08:05:27 --> Output Class Initialized
INFO - 2021-06-28 08:05:27 --> Security Class Initialized
DEBUG - 2021-06-28 08:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:05:27 --> Input Class Initialized
INFO - 2021-06-28 08:05:27 --> Language Class Initialized
INFO - 2021-06-28 08:05:27 --> Language Class Initialized
INFO - 2021-06-28 08:05:27 --> Config Class Initialized
INFO - 2021-06-28 08:05:27 --> Loader Class Initialized
INFO - 2021-06-28 08:05:27 --> Helper loaded: url_helper
INFO - 2021-06-28 08:05:27 --> Helper loaded: file_helper
INFO - 2021-06-28 08:05:27 --> Helper loaded: form_helper
INFO - 2021-06-28 08:05:27 --> Helper loaded: my_helper
INFO - 2021-06-28 08:05:27 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:05:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:05:27 --> Controller Class Initialized
DEBUG - 2021-06-28 08:05:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-28 08:05:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:05:27 --> Final output sent to browser
DEBUG - 2021-06-28 08:05:27 --> Total execution time: 0.0458
INFO - 2021-06-28 08:05:29 --> Config Class Initialized
INFO - 2021-06-28 08:05:29 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:05:29 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:05:29 --> Utf8 Class Initialized
INFO - 2021-06-28 08:05:29 --> URI Class Initialized
INFO - 2021-06-28 08:05:29 --> Router Class Initialized
INFO - 2021-06-28 08:05:29 --> Output Class Initialized
INFO - 2021-06-28 08:05:29 --> Security Class Initialized
DEBUG - 2021-06-28 08:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:05:29 --> Input Class Initialized
INFO - 2021-06-28 08:05:29 --> Language Class Initialized
INFO - 2021-06-28 08:05:29 --> Language Class Initialized
INFO - 2021-06-28 08:05:29 --> Config Class Initialized
INFO - 2021-06-28 08:05:29 --> Loader Class Initialized
INFO - 2021-06-28 08:05:29 --> Helper loaded: url_helper
INFO - 2021-06-28 08:05:29 --> Helper loaded: file_helper
INFO - 2021-06-28 08:05:29 --> Helper loaded: form_helper
INFO - 2021-06-28 08:05:29 --> Helper loaded: my_helper
INFO - 2021-06-28 08:05:29 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:05:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:05:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:05:29 --> Controller Class Initialized
INFO - 2021-06-28 08:05:29 --> Final output sent to browser
DEBUG - 2021-06-28 08:05:29 --> Total execution time: 0.1071
INFO - 2021-06-28 08:05:32 --> Config Class Initialized
INFO - 2021-06-28 08:05:32 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:05:32 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:05:32 --> Utf8 Class Initialized
INFO - 2021-06-28 08:05:32 --> URI Class Initialized
INFO - 2021-06-28 08:05:32 --> Router Class Initialized
INFO - 2021-06-28 08:05:32 --> Output Class Initialized
INFO - 2021-06-28 08:05:32 --> Security Class Initialized
DEBUG - 2021-06-28 08:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:05:32 --> Input Class Initialized
INFO - 2021-06-28 08:05:32 --> Language Class Initialized
INFO - 2021-06-28 08:05:32 --> Language Class Initialized
INFO - 2021-06-28 08:05:32 --> Config Class Initialized
INFO - 2021-06-28 08:05:32 --> Loader Class Initialized
INFO - 2021-06-28 08:05:32 --> Helper loaded: url_helper
INFO - 2021-06-28 08:05:32 --> Helper loaded: file_helper
INFO - 2021-06-28 08:05:32 --> Helper loaded: form_helper
INFO - 2021-06-28 08:05:32 --> Helper loaded: my_helper
INFO - 2021-06-28 08:05:32 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:05:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:05:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:05:32 --> Controller Class Initialized
INFO - 2021-06-28 08:05:35 --> Config Class Initialized
INFO - 2021-06-28 08:05:35 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:05:35 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:05:35 --> Utf8 Class Initialized
INFO - 2021-06-28 08:05:35 --> URI Class Initialized
INFO - 2021-06-28 08:05:35 --> Router Class Initialized
INFO - 2021-06-28 08:05:35 --> Output Class Initialized
INFO - 2021-06-28 08:05:35 --> Security Class Initialized
DEBUG - 2021-06-28 08:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:05:35 --> Input Class Initialized
INFO - 2021-06-28 08:05:35 --> Language Class Initialized
INFO - 2021-06-28 08:05:35 --> Language Class Initialized
INFO - 2021-06-28 08:05:35 --> Config Class Initialized
INFO - 2021-06-28 08:05:35 --> Loader Class Initialized
INFO - 2021-06-28 08:05:35 --> Helper loaded: url_helper
INFO - 2021-06-28 08:05:35 --> Helper loaded: file_helper
INFO - 2021-06-28 08:05:35 --> Helper loaded: form_helper
INFO - 2021-06-28 08:05:35 --> Helper loaded: my_helper
INFO - 2021-06-28 08:05:35 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:05:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:05:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:05:35 --> Controller Class Initialized
INFO - 2021-06-28 08:11:30 --> Config Class Initialized
INFO - 2021-06-28 08:11:30 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:11:30 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:11:30 --> Utf8 Class Initialized
INFO - 2021-06-28 08:11:30 --> URI Class Initialized
INFO - 2021-06-28 08:11:30 --> Router Class Initialized
INFO - 2021-06-28 08:11:30 --> Output Class Initialized
INFO - 2021-06-28 08:11:30 --> Security Class Initialized
DEBUG - 2021-06-28 08:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:11:30 --> Input Class Initialized
INFO - 2021-06-28 08:11:30 --> Language Class Initialized
INFO - 2021-06-28 08:11:30 --> Language Class Initialized
INFO - 2021-06-28 08:11:30 --> Config Class Initialized
INFO - 2021-06-28 08:11:30 --> Loader Class Initialized
INFO - 2021-06-28 08:11:30 --> Helper loaded: url_helper
INFO - 2021-06-28 08:11:30 --> Helper loaded: file_helper
INFO - 2021-06-28 08:11:30 --> Helper loaded: form_helper
INFO - 2021-06-28 08:11:30 --> Helper loaded: my_helper
INFO - 2021-06-28 08:11:30 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:11:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:11:30 --> Controller Class Initialized
DEBUG - 2021-06-28 08:11:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2021-06-28 08:11:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:11:30 --> Final output sent to browser
DEBUG - 2021-06-28 08:11:30 --> Total execution time: 0.0444
INFO - 2021-06-28 08:11:37 --> Config Class Initialized
INFO - 2021-06-28 08:11:37 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:11:37 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:11:37 --> Utf8 Class Initialized
INFO - 2021-06-28 08:11:37 --> URI Class Initialized
INFO - 2021-06-28 08:11:37 --> Router Class Initialized
INFO - 2021-06-28 08:11:37 --> Output Class Initialized
INFO - 2021-06-28 08:11:37 --> Security Class Initialized
DEBUG - 2021-06-28 08:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:11:37 --> Input Class Initialized
INFO - 2021-06-28 08:11:37 --> Language Class Initialized
INFO - 2021-06-28 08:11:37 --> Language Class Initialized
INFO - 2021-06-28 08:11:37 --> Config Class Initialized
INFO - 2021-06-28 08:11:37 --> Loader Class Initialized
INFO - 2021-06-28 08:11:37 --> Helper loaded: url_helper
INFO - 2021-06-28 08:11:37 --> Helper loaded: file_helper
INFO - 2021-06-28 08:11:37 --> Helper loaded: form_helper
INFO - 2021-06-28 08:11:37 --> Helper loaded: my_helper
INFO - 2021-06-28 08:11:37 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:11:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:11:37 --> Controller Class Initialized
INFO - 2021-06-28 08:11:38 --> Config Class Initialized
INFO - 2021-06-28 08:11:38 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:11:38 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:11:38 --> Utf8 Class Initialized
INFO - 2021-06-28 08:11:38 --> URI Class Initialized
INFO - 2021-06-28 08:11:38 --> Router Class Initialized
INFO - 2021-06-28 08:11:38 --> Output Class Initialized
INFO - 2021-06-28 08:11:38 --> Security Class Initialized
DEBUG - 2021-06-28 08:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:11:38 --> Input Class Initialized
INFO - 2021-06-28 08:11:38 --> Language Class Initialized
INFO - 2021-06-28 08:11:38 --> Language Class Initialized
INFO - 2021-06-28 08:11:38 --> Config Class Initialized
INFO - 2021-06-28 08:11:38 --> Loader Class Initialized
INFO - 2021-06-28 08:11:38 --> Helper loaded: url_helper
INFO - 2021-06-28 08:11:38 --> Helper loaded: file_helper
INFO - 2021-06-28 08:11:38 --> Helper loaded: form_helper
INFO - 2021-06-28 08:11:38 --> Helper loaded: my_helper
INFO - 2021-06-28 08:11:38 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:11:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:11:38 --> Controller Class Initialized
DEBUG - 2021-06-28 08:11:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-28 08:11:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:11:38 --> Final output sent to browser
DEBUG - 2021-06-28 08:11:38 --> Total execution time: 0.0530
INFO - 2021-06-28 08:11:38 --> Config Class Initialized
INFO - 2021-06-28 08:11:38 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:11:38 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:11:38 --> Utf8 Class Initialized
INFO - 2021-06-28 08:11:38 --> URI Class Initialized
INFO - 2021-06-28 08:11:38 --> Router Class Initialized
INFO - 2021-06-28 08:11:38 --> Output Class Initialized
INFO - 2021-06-28 08:11:38 --> Security Class Initialized
DEBUG - 2021-06-28 08:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:11:38 --> Input Class Initialized
INFO - 2021-06-28 08:11:38 --> Language Class Initialized
INFO - 2021-06-28 08:11:38 --> Language Class Initialized
INFO - 2021-06-28 08:11:38 --> Config Class Initialized
INFO - 2021-06-28 08:11:38 --> Loader Class Initialized
INFO - 2021-06-28 08:11:38 --> Helper loaded: url_helper
INFO - 2021-06-28 08:11:38 --> Helper loaded: file_helper
INFO - 2021-06-28 08:11:38 --> Helper loaded: form_helper
INFO - 2021-06-28 08:11:38 --> Helper loaded: my_helper
INFO - 2021-06-28 08:11:38 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:11:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:11:38 --> Controller Class Initialized
INFO - 2021-06-28 08:11:41 --> Config Class Initialized
INFO - 2021-06-28 08:11:41 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:11:41 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:11:41 --> Utf8 Class Initialized
INFO - 2021-06-28 08:11:41 --> URI Class Initialized
INFO - 2021-06-28 08:11:41 --> Router Class Initialized
INFO - 2021-06-28 08:11:41 --> Output Class Initialized
INFO - 2021-06-28 08:11:41 --> Security Class Initialized
DEBUG - 2021-06-28 08:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:11:41 --> Input Class Initialized
INFO - 2021-06-28 08:11:41 --> Language Class Initialized
INFO - 2021-06-28 08:11:41 --> Language Class Initialized
INFO - 2021-06-28 08:11:41 --> Config Class Initialized
INFO - 2021-06-28 08:11:41 --> Loader Class Initialized
INFO - 2021-06-28 08:11:41 --> Helper loaded: url_helper
INFO - 2021-06-28 08:11:41 --> Helper loaded: file_helper
INFO - 2021-06-28 08:11:41 --> Helper loaded: form_helper
INFO - 2021-06-28 08:11:41 --> Helper loaded: my_helper
INFO - 2021-06-28 08:11:41 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:11:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:11:41 --> Controller Class Initialized
DEBUG - 2021-06-28 08:11:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2021-06-28 08:11:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:11:41 --> Final output sent to browser
DEBUG - 2021-06-28 08:11:41 --> Total execution time: 0.0527
INFO - 2021-06-28 08:11:44 --> Config Class Initialized
INFO - 2021-06-28 08:11:44 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:11:44 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:11:44 --> Utf8 Class Initialized
INFO - 2021-06-28 08:11:44 --> URI Class Initialized
INFO - 2021-06-28 08:11:44 --> Router Class Initialized
INFO - 2021-06-28 08:11:44 --> Output Class Initialized
INFO - 2021-06-28 08:11:44 --> Security Class Initialized
DEBUG - 2021-06-28 08:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:11:44 --> Input Class Initialized
INFO - 2021-06-28 08:11:44 --> Language Class Initialized
INFO - 2021-06-28 08:11:44 --> Language Class Initialized
INFO - 2021-06-28 08:11:44 --> Config Class Initialized
INFO - 2021-06-28 08:11:44 --> Loader Class Initialized
INFO - 2021-06-28 08:11:44 --> Helper loaded: url_helper
INFO - 2021-06-28 08:11:44 --> Helper loaded: file_helper
INFO - 2021-06-28 08:11:44 --> Helper loaded: form_helper
INFO - 2021-06-28 08:11:44 --> Helper loaded: my_helper
INFO - 2021-06-28 08:11:44 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:11:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:11:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:11:44 --> Controller Class Initialized
INFO - 2021-06-28 08:11:44 --> Config Class Initialized
INFO - 2021-06-28 08:11:44 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:11:44 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:11:44 --> Utf8 Class Initialized
INFO - 2021-06-28 08:11:44 --> URI Class Initialized
INFO - 2021-06-28 08:11:44 --> Router Class Initialized
INFO - 2021-06-28 08:11:44 --> Output Class Initialized
INFO - 2021-06-28 08:11:44 --> Security Class Initialized
DEBUG - 2021-06-28 08:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:11:44 --> Input Class Initialized
INFO - 2021-06-28 08:11:44 --> Language Class Initialized
INFO - 2021-06-28 08:11:44 --> Language Class Initialized
INFO - 2021-06-28 08:11:44 --> Config Class Initialized
INFO - 2021-06-28 08:11:44 --> Loader Class Initialized
INFO - 2021-06-28 08:11:44 --> Helper loaded: url_helper
INFO - 2021-06-28 08:11:44 --> Helper loaded: file_helper
INFO - 2021-06-28 08:11:44 --> Helper loaded: form_helper
INFO - 2021-06-28 08:11:44 --> Helper loaded: my_helper
INFO - 2021-06-28 08:11:44 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:11:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:11:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:11:44 --> Controller Class Initialized
DEBUG - 2021-06-28 08:11:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-28 08:11:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:11:44 --> Final output sent to browser
DEBUG - 2021-06-28 08:11:44 --> Total execution time: 0.0446
INFO - 2021-06-28 08:11:48 --> Config Class Initialized
INFO - 2021-06-28 08:11:48 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:11:48 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:11:48 --> Utf8 Class Initialized
INFO - 2021-06-28 08:11:48 --> URI Class Initialized
INFO - 2021-06-28 08:11:48 --> Router Class Initialized
INFO - 2021-06-28 08:11:48 --> Output Class Initialized
INFO - 2021-06-28 08:11:48 --> Security Class Initialized
DEBUG - 2021-06-28 08:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:11:48 --> Input Class Initialized
INFO - 2021-06-28 08:11:48 --> Language Class Initialized
INFO - 2021-06-28 08:11:48 --> Language Class Initialized
INFO - 2021-06-28 08:11:48 --> Config Class Initialized
INFO - 2021-06-28 08:11:48 --> Loader Class Initialized
INFO - 2021-06-28 08:11:48 --> Helper loaded: url_helper
INFO - 2021-06-28 08:11:48 --> Helper loaded: file_helper
INFO - 2021-06-28 08:11:48 --> Helper loaded: form_helper
INFO - 2021-06-28 08:11:48 --> Helper loaded: my_helper
INFO - 2021-06-28 08:11:48 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:11:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:11:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:11:48 --> Controller Class Initialized
DEBUG - 2021-06-28 08:11:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-28 08:11:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:11:48 --> Final output sent to browser
DEBUG - 2021-06-28 08:11:48 --> Total execution time: 0.0470
INFO - 2021-06-28 08:11:48 --> Config Class Initialized
INFO - 2021-06-28 08:11:48 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:11:48 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:11:48 --> Utf8 Class Initialized
INFO - 2021-06-28 08:11:48 --> URI Class Initialized
INFO - 2021-06-28 08:11:48 --> Router Class Initialized
INFO - 2021-06-28 08:11:48 --> Output Class Initialized
INFO - 2021-06-28 08:11:48 --> Security Class Initialized
DEBUG - 2021-06-28 08:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:11:48 --> Input Class Initialized
INFO - 2021-06-28 08:11:48 --> Language Class Initialized
INFO - 2021-06-28 08:11:48 --> Language Class Initialized
INFO - 2021-06-28 08:11:48 --> Config Class Initialized
INFO - 2021-06-28 08:11:48 --> Loader Class Initialized
INFO - 2021-06-28 08:11:48 --> Helper loaded: url_helper
INFO - 2021-06-28 08:11:48 --> Helper loaded: file_helper
INFO - 2021-06-28 08:11:48 --> Helper loaded: form_helper
INFO - 2021-06-28 08:11:48 --> Helper loaded: my_helper
INFO - 2021-06-28 08:11:48 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:11:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:11:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:11:48 --> Controller Class Initialized
INFO - 2021-06-28 08:11:49 --> Config Class Initialized
INFO - 2021-06-28 08:11:49 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:11:49 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:11:49 --> Utf8 Class Initialized
INFO - 2021-06-28 08:11:49 --> URI Class Initialized
INFO - 2021-06-28 08:11:49 --> Router Class Initialized
INFO - 2021-06-28 08:11:49 --> Output Class Initialized
INFO - 2021-06-28 08:11:49 --> Security Class Initialized
DEBUG - 2021-06-28 08:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:11:49 --> Input Class Initialized
INFO - 2021-06-28 08:11:49 --> Language Class Initialized
INFO - 2021-06-28 08:11:49 --> Language Class Initialized
INFO - 2021-06-28 08:11:49 --> Config Class Initialized
INFO - 2021-06-28 08:11:49 --> Loader Class Initialized
INFO - 2021-06-28 08:11:49 --> Helper loaded: url_helper
INFO - 2021-06-28 08:11:49 --> Helper loaded: file_helper
INFO - 2021-06-28 08:11:49 --> Helper loaded: form_helper
INFO - 2021-06-28 08:11:49 --> Helper loaded: my_helper
INFO - 2021-06-28 08:11:49 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:11:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:11:49 --> Controller Class Initialized
DEBUG - 2021-06-28 08:11:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-28 08:11:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:11:49 --> Final output sent to browser
DEBUG - 2021-06-28 08:11:49 --> Total execution time: 0.0459
INFO - 2021-06-28 08:11:56 --> Config Class Initialized
INFO - 2021-06-28 08:11:56 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:11:56 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:11:56 --> Utf8 Class Initialized
INFO - 2021-06-28 08:11:56 --> URI Class Initialized
INFO - 2021-06-28 08:11:56 --> Router Class Initialized
INFO - 2021-06-28 08:11:56 --> Output Class Initialized
INFO - 2021-06-28 08:11:56 --> Security Class Initialized
DEBUG - 2021-06-28 08:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:11:56 --> Input Class Initialized
INFO - 2021-06-28 08:11:56 --> Language Class Initialized
INFO - 2021-06-28 08:11:56 --> Language Class Initialized
INFO - 2021-06-28 08:11:56 --> Config Class Initialized
INFO - 2021-06-28 08:11:56 --> Loader Class Initialized
INFO - 2021-06-28 08:11:56 --> Helper loaded: url_helper
INFO - 2021-06-28 08:11:56 --> Helper loaded: file_helper
INFO - 2021-06-28 08:11:56 --> Helper loaded: form_helper
INFO - 2021-06-28 08:11:56 --> Helper loaded: my_helper
INFO - 2021-06-28 08:11:56 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:11:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:11:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:11:56 --> Controller Class Initialized
INFO - 2021-06-28 08:11:59 --> Config Class Initialized
INFO - 2021-06-28 08:11:59 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:11:59 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:11:59 --> Utf8 Class Initialized
INFO - 2021-06-28 08:11:59 --> URI Class Initialized
INFO - 2021-06-28 08:11:59 --> Router Class Initialized
INFO - 2021-06-28 08:11:59 --> Output Class Initialized
INFO - 2021-06-28 08:11:59 --> Security Class Initialized
DEBUG - 2021-06-28 08:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:11:59 --> Input Class Initialized
INFO - 2021-06-28 08:11:59 --> Language Class Initialized
INFO - 2021-06-28 08:11:59 --> Language Class Initialized
INFO - 2021-06-28 08:11:59 --> Config Class Initialized
INFO - 2021-06-28 08:11:59 --> Loader Class Initialized
INFO - 2021-06-28 08:11:59 --> Helper loaded: url_helper
INFO - 2021-06-28 08:11:59 --> Helper loaded: file_helper
INFO - 2021-06-28 08:11:59 --> Helper loaded: form_helper
INFO - 2021-06-28 08:11:59 --> Helper loaded: my_helper
INFO - 2021-06-28 08:11:59 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:11:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:11:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:11:59 --> Controller Class Initialized
INFO - 2021-06-28 08:15:17 --> Config Class Initialized
INFO - 2021-06-28 08:15:17 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:15:17 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:15:17 --> Utf8 Class Initialized
INFO - 2021-06-28 08:15:17 --> URI Class Initialized
INFO - 2021-06-28 08:15:17 --> Router Class Initialized
INFO - 2021-06-28 08:15:17 --> Output Class Initialized
INFO - 2021-06-28 08:15:17 --> Security Class Initialized
DEBUG - 2021-06-28 08:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:15:17 --> Input Class Initialized
INFO - 2021-06-28 08:15:17 --> Language Class Initialized
INFO - 2021-06-28 08:15:17 --> Language Class Initialized
INFO - 2021-06-28 08:15:17 --> Config Class Initialized
INFO - 2021-06-28 08:15:17 --> Loader Class Initialized
INFO - 2021-06-28 08:15:17 --> Helper loaded: url_helper
INFO - 2021-06-28 08:15:17 --> Helper loaded: file_helper
INFO - 2021-06-28 08:15:17 --> Helper loaded: form_helper
INFO - 2021-06-28 08:15:17 --> Helper loaded: my_helper
INFO - 2021-06-28 08:15:17 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:15:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:15:17 --> Controller Class Initialized
INFO - 2021-06-28 08:15:31 --> Config Class Initialized
INFO - 2021-06-28 08:15:31 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:15:31 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:15:31 --> Utf8 Class Initialized
INFO - 2021-06-28 08:15:31 --> URI Class Initialized
INFO - 2021-06-28 08:15:31 --> Router Class Initialized
INFO - 2021-06-28 08:15:31 --> Output Class Initialized
INFO - 2021-06-28 08:15:31 --> Security Class Initialized
DEBUG - 2021-06-28 08:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:15:31 --> Input Class Initialized
INFO - 2021-06-28 08:15:31 --> Language Class Initialized
INFO - 2021-06-28 08:15:31 --> Language Class Initialized
INFO - 2021-06-28 08:15:31 --> Config Class Initialized
INFO - 2021-06-28 08:15:31 --> Loader Class Initialized
INFO - 2021-06-28 08:15:31 --> Helper loaded: url_helper
INFO - 2021-06-28 08:15:31 --> Helper loaded: file_helper
INFO - 2021-06-28 08:15:31 --> Helper loaded: form_helper
INFO - 2021-06-28 08:15:31 --> Helper loaded: my_helper
INFO - 2021-06-28 08:15:31 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:15:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:15:31 --> Controller Class Initialized
INFO - 2021-06-28 08:15:40 --> Config Class Initialized
INFO - 2021-06-28 08:15:40 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:15:40 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:15:40 --> Utf8 Class Initialized
INFO - 2021-06-28 08:15:40 --> URI Class Initialized
INFO - 2021-06-28 08:15:40 --> Router Class Initialized
INFO - 2021-06-28 08:15:40 --> Output Class Initialized
INFO - 2021-06-28 08:15:40 --> Security Class Initialized
DEBUG - 2021-06-28 08:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:15:40 --> Input Class Initialized
INFO - 2021-06-28 08:15:40 --> Language Class Initialized
INFO - 2021-06-28 08:15:40 --> Language Class Initialized
INFO - 2021-06-28 08:15:40 --> Config Class Initialized
INFO - 2021-06-28 08:15:40 --> Loader Class Initialized
INFO - 2021-06-28 08:15:40 --> Helper loaded: url_helper
INFO - 2021-06-28 08:15:40 --> Helper loaded: file_helper
INFO - 2021-06-28 08:15:40 --> Helper loaded: form_helper
INFO - 2021-06-28 08:15:40 --> Helper loaded: my_helper
INFO - 2021-06-28 08:15:40 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:15:40 --> Controller Class Initialized
DEBUG - 2021-06-28 08:15:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2021-06-28 08:15:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:15:40 --> Final output sent to browser
DEBUG - 2021-06-28 08:15:40 --> Total execution time: 0.0463
INFO - 2021-06-28 08:15:44 --> Config Class Initialized
INFO - 2021-06-28 08:15:44 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:15:44 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:15:44 --> Utf8 Class Initialized
INFO - 2021-06-28 08:15:44 --> URI Class Initialized
INFO - 2021-06-28 08:15:44 --> Router Class Initialized
INFO - 2021-06-28 08:15:44 --> Output Class Initialized
INFO - 2021-06-28 08:15:44 --> Security Class Initialized
DEBUG - 2021-06-28 08:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:15:44 --> Input Class Initialized
INFO - 2021-06-28 08:15:44 --> Language Class Initialized
INFO - 2021-06-28 08:15:44 --> Language Class Initialized
INFO - 2021-06-28 08:15:44 --> Config Class Initialized
INFO - 2021-06-28 08:15:44 --> Loader Class Initialized
INFO - 2021-06-28 08:15:44 --> Helper loaded: url_helper
INFO - 2021-06-28 08:15:44 --> Helper loaded: file_helper
INFO - 2021-06-28 08:15:44 --> Helper loaded: form_helper
INFO - 2021-06-28 08:15:44 --> Helper loaded: my_helper
INFO - 2021-06-28 08:15:44 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:15:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:15:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:15:44 --> Controller Class Initialized
INFO - 2021-06-28 08:15:45 --> Config Class Initialized
INFO - 2021-06-28 08:15:45 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:15:45 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:15:45 --> Utf8 Class Initialized
INFO - 2021-06-28 08:15:45 --> URI Class Initialized
INFO - 2021-06-28 08:15:45 --> Router Class Initialized
INFO - 2021-06-28 08:15:45 --> Output Class Initialized
INFO - 2021-06-28 08:15:45 --> Security Class Initialized
DEBUG - 2021-06-28 08:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:15:45 --> Input Class Initialized
INFO - 2021-06-28 08:15:45 --> Language Class Initialized
INFO - 2021-06-28 08:15:45 --> Language Class Initialized
INFO - 2021-06-28 08:15:45 --> Config Class Initialized
INFO - 2021-06-28 08:15:45 --> Loader Class Initialized
INFO - 2021-06-28 08:15:45 --> Helper loaded: url_helper
INFO - 2021-06-28 08:15:45 --> Helper loaded: file_helper
INFO - 2021-06-28 08:15:45 --> Helper loaded: form_helper
INFO - 2021-06-28 08:15:45 --> Helper loaded: my_helper
INFO - 2021-06-28 08:15:45 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:15:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:15:45 --> Controller Class Initialized
DEBUG - 2021-06-28 08:15:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-28 08:15:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:15:45 --> Final output sent to browser
DEBUG - 2021-06-28 08:15:45 --> Total execution time: 0.0569
INFO - 2021-06-28 08:15:45 --> Config Class Initialized
INFO - 2021-06-28 08:15:45 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:15:45 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:15:45 --> Utf8 Class Initialized
INFO - 2021-06-28 08:15:45 --> URI Class Initialized
INFO - 2021-06-28 08:15:45 --> Router Class Initialized
INFO - 2021-06-28 08:15:45 --> Output Class Initialized
INFO - 2021-06-28 08:15:45 --> Security Class Initialized
DEBUG - 2021-06-28 08:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:15:45 --> Input Class Initialized
INFO - 2021-06-28 08:15:45 --> Language Class Initialized
INFO - 2021-06-28 08:15:45 --> Language Class Initialized
INFO - 2021-06-28 08:15:45 --> Config Class Initialized
INFO - 2021-06-28 08:15:45 --> Loader Class Initialized
INFO - 2021-06-28 08:15:45 --> Helper loaded: url_helper
INFO - 2021-06-28 08:15:45 --> Helper loaded: file_helper
INFO - 2021-06-28 08:15:45 --> Helper loaded: form_helper
INFO - 2021-06-28 08:15:45 --> Helper loaded: my_helper
INFO - 2021-06-28 08:15:45 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:15:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:15:45 --> Controller Class Initialized
INFO - 2021-06-28 08:15:46 --> Config Class Initialized
INFO - 2021-06-28 08:15:46 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:15:46 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:15:46 --> Utf8 Class Initialized
INFO - 2021-06-28 08:15:46 --> URI Class Initialized
INFO - 2021-06-28 08:15:46 --> Router Class Initialized
INFO - 2021-06-28 08:15:46 --> Output Class Initialized
INFO - 2021-06-28 08:15:46 --> Security Class Initialized
DEBUG - 2021-06-28 08:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:15:46 --> Input Class Initialized
INFO - 2021-06-28 08:15:46 --> Language Class Initialized
INFO - 2021-06-28 08:15:46 --> Language Class Initialized
INFO - 2021-06-28 08:15:46 --> Config Class Initialized
INFO - 2021-06-28 08:15:46 --> Loader Class Initialized
INFO - 2021-06-28 08:15:46 --> Helper loaded: url_helper
INFO - 2021-06-28 08:15:46 --> Helper loaded: file_helper
INFO - 2021-06-28 08:15:46 --> Helper loaded: form_helper
INFO - 2021-06-28 08:15:46 --> Helper loaded: my_helper
INFO - 2021-06-28 08:15:46 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:15:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:15:46 --> Controller Class Initialized
DEBUG - 2021-06-28 08:15:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2021-06-28 08:15:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:15:46 --> Final output sent to browser
DEBUG - 2021-06-28 08:15:46 --> Total execution time: 0.0434
INFO - 2021-06-28 08:15:49 --> Config Class Initialized
INFO - 2021-06-28 08:15:49 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:15:49 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:15:49 --> Utf8 Class Initialized
INFO - 2021-06-28 08:15:49 --> URI Class Initialized
INFO - 2021-06-28 08:15:49 --> Router Class Initialized
INFO - 2021-06-28 08:15:49 --> Output Class Initialized
INFO - 2021-06-28 08:15:49 --> Security Class Initialized
DEBUG - 2021-06-28 08:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:15:49 --> Input Class Initialized
INFO - 2021-06-28 08:15:49 --> Language Class Initialized
INFO - 2021-06-28 08:15:49 --> Language Class Initialized
INFO - 2021-06-28 08:15:49 --> Config Class Initialized
INFO - 2021-06-28 08:15:49 --> Loader Class Initialized
INFO - 2021-06-28 08:15:49 --> Helper loaded: url_helper
INFO - 2021-06-28 08:15:49 --> Helper loaded: file_helper
INFO - 2021-06-28 08:15:49 --> Helper loaded: form_helper
INFO - 2021-06-28 08:15:49 --> Helper loaded: my_helper
INFO - 2021-06-28 08:15:49 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:15:49 --> Controller Class Initialized
INFO - 2021-06-28 08:15:49 --> Config Class Initialized
INFO - 2021-06-28 08:15:49 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:15:49 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:15:49 --> Utf8 Class Initialized
INFO - 2021-06-28 08:15:49 --> URI Class Initialized
INFO - 2021-06-28 08:15:49 --> Router Class Initialized
INFO - 2021-06-28 08:15:49 --> Output Class Initialized
INFO - 2021-06-28 08:15:49 --> Security Class Initialized
DEBUG - 2021-06-28 08:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:15:49 --> Input Class Initialized
INFO - 2021-06-28 08:15:49 --> Language Class Initialized
INFO - 2021-06-28 08:15:49 --> Language Class Initialized
INFO - 2021-06-28 08:15:49 --> Config Class Initialized
INFO - 2021-06-28 08:15:49 --> Loader Class Initialized
INFO - 2021-06-28 08:15:49 --> Helper loaded: url_helper
INFO - 2021-06-28 08:15:49 --> Helper loaded: file_helper
INFO - 2021-06-28 08:15:49 --> Helper loaded: form_helper
INFO - 2021-06-28 08:15:49 --> Helper loaded: my_helper
INFO - 2021-06-28 08:15:49 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:15:49 --> Controller Class Initialized
DEBUG - 2021-06-28 08:15:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-28 08:15:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:15:49 --> Final output sent to browser
DEBUG - 2021-06-28 08:15:49 --> Total execution time: 0.0534
INFO - 2021-06-28 08:16:11 --> Config Class Initialized
INFO - 2021-06-28 08:16:11 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:16:11 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:16:11 --> Utf8 Class Initialized
INFO - 2021-06-28 08:16:11 --> URI Class Initialized
INFO - 2021-06-28 08:16:11 --> Router Class Initialized
INFO - 2021-06-28 08:16:11 --> Output Class Initialized
INFO - 2021-06-28 08:16:11 --> Security Class Initialized
DEBUG - 2021-06-28 08:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:16:11 --> Input Class Initialized
INFO - 2021-06-28 08:16:11 --> Language Class Initialized
INFO - 2021-06-28 08:16:11 --> Language Class Initialized
INFO - 2021-06-28 08:16:11 --> Config Class Initialized
INFO - 2021-06-28 08:16:11 --> Loader Class Initialized
INFO - 2021-06-28 08:16:11 --> Helper loaded: url_helper
INFO - 2021-06-28 08:16:11 --> Helper loaded: file_helper
INFO - 2021-06-28 08:16:11 --> Helper loaded: form_helper
INFO - 2021-06-28 08:16:11 --> Helper loaded: my_helper
INFO - 2021-06-28 08:16:11 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:16:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:16:11 --> Controller Class Initialized
INFO - 2021-06-28 08:16:11 --> Helper loaded: cookie_helper
INFO - 2021-06-28 08:16:11 --> Config Class Initialized
INFO - 2021-06-28 08:16:11 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:16:11 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:16:11 --> Utf8 Class Initialized
INFO - 2021-06-28 08:16:11 --> URI Class Initialized
INFO - 2021-06-28 08:16:11 --> Router Class Initialized
INFO - 2021-06-28 08:16:11 --> Output Class Initialized
INFO - 2021-06-28 08:16:11 --> Security Class Initialized
DEBUG - 2021-06-28 08:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:16:11 --> Input Class Initialized
INFO - 2021-06-28 08:16:11 --> Language Class Initialized
INFO - 2021-06-28 08:16:11 --> Language Class Initialized
INFO - 2021-06-28 08:16:11 --> Config Class Initialized
INFO - 2021-06-28 08:16:11 --> Loader Class Initialized
INFO - 2021-06-28 08:16:11 --> Helper loaded: url_helper
INFO - 2021-06-28 08:16:11 --> Helper loaded: file_helper
INFO - 2021-06-28 08:16:11 --> Helper loaded: form_helper
INFO - 2021-06-28 08:16:11 --> Helper loaded: my_helper
INFO - 2021-06-28 08:16:11 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:16:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:16:11 --> Controller Class Initialized
DEBUG - 2021-06-28 08:16:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-28 08:16:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:16:11 --> Final output sent to browser
DEBUG - 2021-06-28 08:16:11 --> Total execution time: 0.0508
INFO - 2021-06-28 08:16:30 --> Config Class Initialized
INFO - 2021-06-28 08:16:30 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:16:30 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:16:30 --> Utf8 Class Initialized
INFO - 2021-06-28 08:16:30 --> URI Class Initialized
INFO - 2021-06-28 08:16:30 --> Router Class Initialized
INFO - 2021-06-28 08:16:30 --> Output Class Initialized
INFO - 2021-06-28 08:16:30 --> Security Class Initialized
DEBUG - 2021-06-28 08:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:16:30 --> Input Class Initialized
INFO - 2021-06-28 08:16:30 --> Language Class Initialized
INFO - 2021-06-28 08:16:30 --> Language Class Initialized
INFO - 2021-06-28 08:16:30 --> Config Class Initialized
INFO - 2021-06-28 08:16:30 --> Loader Class Initialized
INFO - 2021-06-28 08:16:30 --> Helper loaded: url_helper
INFO - 2021-06-28 08:16:30 --> Helper loaded: file_helper
INFO - 2021-06-28 08:16:30 --> Helper loaded: form_helper
INFO - 2021-06-28 08:16:30 --> Helper loaded: my_helper
INFO - 2021-06-28 08:16:30 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:16:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:16:30 --> Controller Class Initialized
INFO - 2021-06-28 08:16:30 --> Final output sent to browser
DEBUG - 2021-06-28 08:16:30 --> Total execution time: 0.0513
INFO - 2021-06-28 08:16:34 --> Config Class Initialized
INFO - 2021-06-28 08:16:34 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:16:34 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:16:34 --> Utf8 Class Initialized
INFO - 2021-06-28 08:16:34 --> URI Class Initialized
INFO - 2021-06-28 08:16:34 --> Router Class Initialized
INFO - 2021-06-28 08:16:34 --> Output Class Initialized
INFO - 2021-06-28 08:16:34 --> Security Class Initialized
DEBUG - 2021-06-28 08:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:16:34 --> Input Class Initialized
INFO - 2021-06-28 08:16:34 --> Language Class Initialized
INFO - 2021-06-28 08:16:34 --> Language Class Initialized
INFO - 2021-06-28 08:16:34 --> Config Class Initialized
INFO - 2021-06-28 08:16:34 --> Loader Class Initialized
INFO - 2021-06-28 08:16:34 --> Helper loaded: url_helper
INFO - 2021-06-28 08:16:34 --> Helper loaded: file_helper
INFO - 2021-06-28 08:16:34 --> Helper loaded: form_helper
INFO - 2021-06-28 08:16:34 --> Helper loaded: my_helper
INFO - 2021-06-28 08:16:34 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:16:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:16:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:16:34 --> Controller Class Initialized
INFO - 2021-06-28 08:16:34 --> Helper loaded: cookie_helper
INFO - 2021-06-28 08:16:34 --> Final output sent to browser
DEBUG - 2021-06-28 08:16:34 --> Total execution time: 0.0521
INFO - 2021-06-28 08:16:35 --> Config Class Initialized
INFO - 2021-06-28 08:16:35 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:16:35 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:16:35 --> Utf8 Class Initialized
INFO - 2021-06-28 08:16:35 --> URI Class Initialized
INFO - 2021-06-28 08:16:35 --> Router Class Initialized
INFO - 2021-06-28 08:16:35 --> Output Class Initialized
INFO - 2021-06-28 08:16:35 --> Security Class Initialized
DEBUG - 2021-06-28 08:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:16:35 --> Input Class Initialized
INFO - 2021-06-28 08:16:35 --> Language Class Initialized
INFO - 2021-06-28 08:16:35 --> Language Class Initialized
INFO - 2021-06-28 08:16:35 --> Config Class Initialized
INFO - 2021-06-28 08:16:35 --> Loader Class Initialized
INFO - 2021-06-28 08:16:35 --> Helper loaded: url_helper
INFO - 2021-06-28 08:16:35 --> Helper loaded: file_helper
INFO - 2021-06-28 08:16:35 --> Helper loaded: form_helper
INFO - 2021-06-28 08:16:35 --> Helper loaded: my_helper
INFO - 2021-06-28 08:16:35 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:16:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:16:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:16:35 --> Controller Class Initialized
DEBUG - 2021-06-28 08:16:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-28 08:16:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:16:35 --> Final output sent to browser
DEBUG - 2021-06-28 08:16:35 --> Total execution time: 0.6622
INFO - 2021-06-28 08:16:36 --> Config Class Initialized
INFO - 2021-06-28 08:16:36 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:16:36 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:16:36 --> Utf8 Class Initialized
INFO - 2021-06-28 08:16:36 --> URI Class Initialized
INFO - 2021-06-28 08:16:36 --> Router Class Initialized
INFO - 2021-06-28 08:16:36 --> Output Class Initialized
INFO - 2021-06-28 08:16:36 --> Security Class Initialized
DEBUG - 2021-06-28 08:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:16:36 --> Input Class Initialized
INFO - 2021-06-28 08:16:36 --> Language Class Initialized
INFO - 2021-06-28 08:16:36 --> Language Class Initialized
INFO - 2021-06-28 08:16:36 --> Config Class Initialized
INFO - 2021-06-28 08:16:36 --> Loader Class Initialized
INFO - 2021-06-28 08:16:36 --> Helper loaded: url_helper
INFO - 2021-06-28 08:16:36 --> Helper loaded: file_helper
INFO - 2021-06-28 08:16:36 --> Helper loaded: form_helper
INFO - 2021-06-28 08:16:36 --> Helper loaded: my_helper
INFO - 2021-06-28 08:16:36 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:16:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:16:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:16:36 --> Controller Class Initialized
DEBUG - 2021-06-28 08:16:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2021-06-28 08:16:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:16:36 --> Final output sent to browser
DEBUG - 2021-06-28 08:16:36 --> Total execution time: 0.0497
INFO - 2021-06-28 08:16:36 --> Config Class Initialized
INFO - 2021-06-28 08:16:36 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:16:36 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:16:36 --> Utf8 Class Initialized
INFO - 2021-06-28 08:16:36 --> URI Class Initialized
INFO - 2021-06-28 08:16:36 --> Router Class Initialized
INFO - 2021-06-28 08:16:36 --> Output Class Initialized
INFO - 2021-06-28 08:16:36 --> Security Class Initialized
DEBUG - 2021-06-28 08:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:16:36 --> Input Class Initialized
INFO - 2021-06-28 08:16:36 --> Language Class Initialized
INFO - 2021-06-28 08:16:36 --> Language Class Initialized
INFO - 2021-06-28 08:16:36 --> Config Class Initialized
INFO - 2021-06-28 08:16:36 --> Loader Class Initialized
INFO - 2021-06-28 08:16:36 --> Helper loaded: url_helper
INFO - 2021-06-28 08:16:36 --> Helper loaded: file_helper
INFO - 2021-06-28 08:16:36 --> Helper loaded: form_helper
INFO - 2021-06-28 08:16:36 --> Helper loaded: my_helper
INFO - 2021-06-28 08:16:36 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:16:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:16:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:16:36 --> Controller Class Initialized
INFO - 2021-06-28 08:16:40 --> Config Class Initialized
INFO - 2021-06-28 08:16:40 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:16:40 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:16:40 --> Utf8 Class Initialized
INFO - 2021-06-28 08:16:40 --> URI Class Initialized
INFO - 2021-06-28 08:16:40 --> Router Class Initialized
INFO - 2021-06-28 08:16:40 --> Output Class Initialized
INFO - 2021-06-28 08:16:40 --> Security Class Initialized
DEBUG - 2021-06-28 08:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:16:41 --> Input Class Initialized
INFO - 2021-06-28 08:16:41 --> Language Class Initialized
INFO - 2021-06-28 08:16:41 --> Language Class Initialized
INFO - 2021-06-28 08:16:41 --> Config Class Initialized
INFO - 2021-06-28 08:16:41 --> Loader Class Initialized
INFO - 2021-06-28 08:16:41 --> Helper loaded: url_helper
INFO - 2021-06-28 08:16:41 --> Helper loaded: file_helper
INFO - 2021-06-28 08:16:41 --> Helper loaded: form_helper
INFO - 2021-06-28 08:16:41 --> Helper loaded: my_helper
INFO - 2021-06-28 08:16:41 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:16:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:16:41 --> Controller Class Initialized
DEBUG - 2021-06-28 08:16:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2021-06-28 08:16:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:16:41 --> Final output sent to browser
DEBUG - 2021-06-28 08:16:41 --> Total execution time: 0.0787
INFO - 2021-06-28 08:16:41 --> Config Class Initialized
INFO - 2021-06-28 08:16:41 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:16:41 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:16:41 --> Utf8 Class Initialized
INFO - 2021-06-28 08:16:41 --> URI Class Initialized
INFO - 2021-06-28 08:16:41 --> Router Class Initialized
INFO - 2021-06-28 08:16:41 --> Output Class Initialized
INFO - 2021-06-28 08:16:41 --> Security Class Initialized
DEBUG - 2021-06-28 08:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:16:41 --> Input Class Initialized
INFO - 2021-06-28 08:16:41 --> Language Class Initialized
INFO - 2021-06-28 08:16:41 --> Language Class Initialized
INFO - 2021-06-28 08:16:41 --> Config Class Initialized
INFO - 2021-06-28 08:16:41 --> Loader Class Initialized
INFO - 2021-06-28 08:16:41 --> Helper loaded: url_helper
INFO - 2021-06-28 08:16:41 --> Helper loaded: file_helper
INFO - 2021-06-28 08:16:41 --> Helper loaded: form_helper
INFO - 2021-06-28 08:16:41 --> Helper loaded: my_helper
INFO - 2021-06-28 08:16:41 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:16:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:16:41 --> Controller Class Initialized
INFO - 2021-06-28 08:16:43 --> Config Class Initialized
INFO - 2021-06-28 08:16:43 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:16:43 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:16:43 --> Utf8 Class Initialized
INFO - 2021-06-28 08:16:43 --> URI Class Initialized
INFO - 2021-06-28 08:16:43 --> Router Class Initialized
INFO - 2021-06-28 08:16:43 --> Output Class Initialized
INFO - 2021-06-28 08:16:43 --> Security Class Initialized
DEBUG - 2021-06-28 08:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:16:43 --> Input Class Initialized
INFO - 2021-06-28 08:16:43 --> Language Class Initialized
INFO - 2021-06-28 08:16:43 --> Language Class Initialized
INFO - 2021-06-28 08:16:43 --> Config Class Initialized
INFO - 2021-06-28 08:16:43 --> Loader Class Initialized
INFO - 2021-06-28 08:16:43 --> Helper loaded: url_helper
INFO - 2021-06-28 08:16:43 --> Helper loaded: file_helper
INFO - 2021-06-28 08:16:43 --> Helper loaded: form_helper
INFO - 2021-06-28 08:16:43 --> Helper loaded: my_helper
INFO - 2021-06-28 08:16:43 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:16:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:16:43 --> Controller Class Initialized
INFO - 2021-06-28 08:16:44 --> Config Class Initialized
INFO - 2021-06-28 08:16:44 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:16:44 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:16:44 --> Utf8 Class Initialized
INFO - 2021-06-28 08:16:44 --> URI Class Initialized
INFO - 2021-06-28 08:16:44 --> Router Class Initialized
INFO - 2021-06-28 08:16:44 --> Output Class Initialized
INFO - 2021-06-28 08:16:44 --> Security Class Initialized
DEBUG - 2021-06-28 08:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:16:44 --> Input Class Initialized
INFO - 2021-06-28 08:16:44 --> Language Class Initialized
INFO - 2021-06-28 08:16:44 --> Language Class Initialized
INFO - 2021-06-28 08:16:44 --> Config Class Initialized
INFO - 2021-06-28 08:16:44 --> Loader Class Initialized
INFO - 2021-06-28 08:16:44 --> Helper loaded: url_helper
INFO - 2021-06-28 08:16:44 --> Helper loaded: file_helper
INFO - 2021-06-28 08:16:44 --> Helper loaded: form_helper
INFO - 2021-06-28 08:16:44 --> Helper loaded: my_helper
INFO - 2021-06-28 08:16:44 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:16:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:16:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:16:44 --> Controller Class Initialized
INFO - 2021-06-28 08:16:45 --> Config Class Initialized
INFO - 2021-06-28 08:16:45 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:16:45 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:16:45 --> Utf8 Class Initialized
INFO - 2021-06-28 08:16:45 --> URI Class Initialized
INFO - 2021-06-28 08:16:45 --> Router Class Initialized
INFO - 2021-06-28 08:16:45 --> Output Class Initialized
INFO - 2021-06-28 08:16:45 --> Security Class Initialized
DEBUG - 2021-06-28 08:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:16:45 --> Input Class Initialized
INFO - 2021-06-28 08:16:45 --> Language Class Initialized
INFO - 2021-06-28 08:16:45 --> Language Class Initialized
INFO - 2021-06-28 08:16:45 --> Config Class Initialized
INFO - 2021-06-28 08:16:45 --> Loader Class Initialized
INFO - 2021-06-28 08:16:45 --> Helper loaded: url_helper
INFO - 2021-06-28 08:16:45 --> Helper loaded: file_helper
INFO - 2021-06-28 08:16:45 --> Helper loaded: form_helper
INFO - 2021-06-28 08:16:45 --> Helper loaded: my_helper
INFO - 2021-06-28 08:16:45 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:16:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:16:45 --> Controller Class Initialized
INFO - 2021-06-28 08:16:52 --> Config Class Initialized
INFO - 2021-06-28 08:16:52 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:16:52 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:16:52 --> Utf8 Class Initialized
INFO - 2021-06-28 08:16:52 --> URI Class Initialized
INFO - 2021-06-28 08:16:52 --> Router Class Initialized
INFO - 2021-06-28 08:16:52 --> Output Class Initialized
INFO - 2021-06-28 08:16:52 --> Security Class Initialized
DEBUG - 2021-06-28 08:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:16:52 --> Input Class Initialized
INFO - 2021-06-28 08:16:52 --> Language Class Initialized
INFO - 2021-06-28 08:16:52 --> Language Class Initialized
INFO - 2021-06-28 08:16:52 --> Config Class Initialized
INFO - 2021-06-28 08:16:52 --> Loader Class Initialized
INFO - 2021-06-28 08:16:52 --> Helper loaded: url_helper
INFO - 2021-06-28 08:16:52 --> Helper loaded: file_helper
INFO - 2021-06-28 08:16:52 --> Helper loaded: form_helper
INFO - 2021-06-28 08:16:52 --> Helper loaded: my_helper
INFO - 2021-06-28 08:16:52 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:16:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:16:52 --> Controller Class Initialized
INFO - 2021-06-28 08:16:52 --> Helper loaded: cookie_helper
INFO - 2021-06-28 08:16:52 --> Config Class Initialized
INFO - 2021-06-28 08:16:52 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:16:52 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:16:52 --> Utf8 Class Initialized
INFO - 2021-06-28 08:16:52 --> URI Class Initialized
INFO - 2021-06-28 08:16:52 --> Router Class Initialized
INFO - 2021-06-28 08:16:52 --> Output Class Initialized
INFO - 2021-06-28 08:16:52 --> Security Class Initialized
DEBUG - 2021-06-28 08:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:16:52 --> Input Class Initialized
INFO - 2021-06-28 08:16:52 --> Language Class Initialized
INFO - 2021-06-28 08:16:52 --> Language Class Initialized
INFO - 2021-06-28 08:16:52 --> Config Class Initialized
INFO - 2021-06-28 08:16:52 --> Loader Class Initialized
INFO - 2021-06-28 08:16:52 --> Helper loaded: url_helper
INFO - 2021-06-28 08:16:52 --> Helper loaded: file_helper
INFO - 2021-06-28 08:16:52 --> Helper loaded: form_helper
INFO - 2021-06-28 08:16:52 --> Helper loaded: my_helper
INFO - 2021-06-28 08:16:52 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:16:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:16:52 --> Controller Class Initialized
DEBUG - 2021-06-28 08:16:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-28 08:16:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:16:52 --> Final output sent to browser
DEBUG - 2021-06-28 08:16:52 --> Total execution time: 0.0504
INFO - 2021-06-28 08:17:04 --> Config Class Initialized
INFO - 2021-06-28 08:17:04 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:17:04 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:17:04 --> Utf8 Class Initialized
INFO - 2021-06-28 08:17:04 --> URI Class Initialized
INFO - 2021-06-28 08:17:04 --> Router Class Initialized
INFO - 2021-06-28 08:17:04 --> Output Class Initialized
INFO - 2021-06-28 08:17:04 --> Security Class Initialized
DEBUG - 2021-06-28 08:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:17:04 --> Input Class Initialized
INFO - 2021-06-28 08:17:04 --> Language Class Initialized
INFO - 2021-06-28 08:17:04 --> Language Class Initialized
INFO - 2021-06-28 08:17:04 --> Config Class Initialized
INFO - 2021-06-28 08:17:04 --> Loader Class Initialized
INFO - 2021-06-28 08:17:04 --> Helper loaded: url_helper
INFO - 2021-06-28 08:17:04 --> Helper loaded: file_helper
INFO - 2021-06-28 08:17:04 --> Helper loaded: form_helper
INFO - 2021-06-28 08:17:04 --> Helper loaded: my_helper
INFO - 2021-06-28 08:17:04 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:17:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:17:04 --> Controller Class Initialized
INFO - 2021-06-28 08:17:04 --> Helper loaded: cookie_helper
INFO - 2021-06-28 08:17:04 --> Final output sent to browser
DEBUG - 2021-06-28 08:17:04 --> Total execution time: 0.0418
INFO - 2021-06-28 08:17:05 --> Config Class Initialized
INFO - 2021-06-28 08:17:05 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:17:05 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:17:05 --> Utf8 Class Initialized
INFO - 2021-06-28 08:17:05 --> URI Class Initialized
INFO - 2021-06-28 08:17:05 --> Router Class Initialized
INFO - 2021-06-28 08:17:05 --> Output Class Initialized
INFO - 2021-06-28 08:17:05 --> Security Class Initialized
DEBUG - 2021-06-28 08:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:17:05 --> Input Class Initialized
INFO - 2021-06-28 08:17:05 --> Language Class Initialized
INFO - 2021-06-28 08:17:05 --> Language Class Initialized
INFO - 2021-06-28 08:17:05 --> Config Class Initialized
INFO - 2021-06-28 08:17:05 --> Loader Class Initialized
INFO - 2021-06-28 08:17:05 --> Helper loaded: url_helper
INFO - 2021-06-28 08:17:05 --> Helper loaded: file_helper
INFO - 2021-06-28 08:17:05 --> Helper loaded: form_helper
INFO - 2021-06-28 08:17:05 --> Helper loaded: my_helper
INFO - 2021-06-28 08:17:05 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:17:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:17:05 --> Controller Class Initialized
DEBUG - 2021-06-28 08:17:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-28 08:17:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:17:05 --> Final output sent to browser
DEBUG - 2021-06-28 08:17:05 --> Total execution time: 0.5954
INFO - 2021-06-28 08:17:08 --> Config Class Initialized
INFO - 2021-06-28 08:17:08 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:17:08 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:17:08 --> Utf8 Class Initialized
INFO - 2021-06-28 08:17:08 --> URI Class Initialized
INFO - 2021-06-28 08:17:08 --> Router Class Initialized
INFO - 2021-06-28 08:17:08 --> Output Class Initialized
INFO - 2021-06-28 08:17:08 --> Security Class Initialized
DEBUG - 2021-06-28 08:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:17:08 --> Input Class Initialized
INFO - 2021-06-28 08:17:08 --> Language Class Initialized
INFO - 2021-06-28 08:17:08 --> Language Class Initialized
INFO - 2021-06-28 08:17:08 --> Config Class Initialized
INFO - 2021-06-28 08:17:08 --> Loader Class Initialized
INFO - 2021-06-28 08:17:08 --> Helper loaded: url_helper
INFO - 2021-06-28 08:17:08 --> Helper loaded: file_helper
INFO - 2021-06-28 08:17:08 --> Helper loaded: form_helper
INFO - 2021-06-28 08:17:08 --> Helper loaded: my_helper
INFO - 2021-06-28 08:17:08 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:17:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:17:08 --> Controller Class Initialized
DEBUG - 2021-06-28 08:17:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-28 08:17:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:17:08 --> Final output sent to browser
DEBUG - 2021-06-28 08:17:08 --> Total execution time: 0.0525
INFO - 2021-06-28 08:17:12 --> Config Class Initialized
INFO - 2021-06-28 08:17:12 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:17:12 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:17:12 --> Utf8 Class Initialized
INFO - 2021-06-28 08:17:12 --> URI Class Initialized
INFO - 2021-06-28 08:17:12 --> Router Class Initialized
INFO - 2021-06-28 08:17:12 --> Output Class Initialized
INFO - 2021-06-28 08:17:12 --> Security Class Initialized
DEBUG - 2021-06-28 08:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:17:12 --> Input Class Initialized
INFO - 2021-06-28 08:17:12 --> Language Class Initialized
INFO - 2021-06-28 08:17:12 --> Language Class Initialized
INFO - 2021-06-28 08:17:12 --> Config Class Initialized
INFO - 2021-06-28 08:17:12 --> Loader Class Initialized
INFO - 2021-06-28 08:17:12 --> Helper loaded: url_helper
INFO - 2021-06-28 08:17:12 --> Helper loaded: file_helper
INFO - 2021-06-28 08:17:12 --> Helper loaded: form_helper
INFO - 2021-06-28 08:17:12 --> Helper loaded: my_helper
INFO - 2021-06-28 08:17:12 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:17:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:17:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:17:12 --> Controller Class Initialized
DEBUG - 2021-06-28 08:17:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-28 08:17:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:17:12 --> Final output sent to browser
DEBUG - 2021-06-28 08:17:12 --> Total execution time: 0.0451
INFO - 2021-06-28 08:17:12 --> Config Class Initialized
INFO - 2021-06-28 08:17:12 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:17:12 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:17:12 --> Utf8 Class Initialized
INFO - 2021-06-28 08:17:12 --> URI Class Initialized
INFO - 2021-06-28 08:17:12 --> Router Class Initialized
INFO - 2021-06-28 08:17:12 --> Output Class Initialized
INFO - 2021-06-28 08:17:12 --> Security Class Initialized
DEBUG - 2021-06-28 08:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:17:12 --> Input Class Initialized
INFO - 2021-06-28 08:17:12 --> Language Class Initialized
INFO - 2021-06-28 08:17:12 --> Language Class Initialized
INFO - 2021-06-28 08:17:12 --> Config Class Initialized
INFO - 2021-06-28 08:17:12 --> Loader Class Initialized
INFO - 2021-06-28 08:17:12 --> Helper loaded: url_helper
INFO - 2021-06-28 08:17:12 --> Helper loaded: file_helper
INFO - 2021-06-28 08:17:12 --> Helper loaded: form_helper
INFO - 2021-06-28 08:17:12 --> Helper loaded: my_helper
INFO - 2021-06-28 08:17:12 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:17:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:17:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:17:12 --> Controller Class Initialized
INFO - 2021-06-28 08:17:16 --> Config Class Initialized
INFO - 2021-06-28 08:17:16 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:17:16 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:17:16 --> Utf8 Class Initialized
INFO - 2021-06-28 08:17:16 --> URI Class Initialized
INFO - 2021-06-28 08:17:16 --> Router Class Initialized
INFO - 2021-06-28 08:17:16 --> Output Class Initialized
INFO - 2021-06-28 08:17:16 --> Security Class Initialized
DEBUG - 2021-06-28 08:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:17:16 --> Input Class Initialized
INFO - 2021-06-28 08:17:16 --> Language Class Initialized
INFO - 2021-06-28 08:17:16 --> Language Class Initialized
INFO - 2021-06-28 08:17:16 --> Config Class Initialized
INFO - 2021-06-28 08:17:16 --> Loader Class Initialized
INFO - 2021-06-28 08:17:16 --> Helper loaded: url_helper
INFO - 2021-06-28 08:17:16 --> Helper loaded: file_helper
INFO - 2021-06-28 08:17:16 --> Helper loaded: form_helper
INFO - 2021-06-28 08:17:16 --> Helper loaded: my_helper
INFO - 2021-06-28 08:17:16 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:17:16 --> Controller Class Initialized
DEBUG - 2021-06-28 08:17:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-28 08:17:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:17:16 --> Final output sent to browser
DEBUG - 2021-06-28 08:17:16 --> Total execution time: 0.0444
INFO - 2021-06-28 08:17:18 --> Config Class Initialized
INFO - 2021-06-28 08:17:18 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:17:18 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:17:18 --> Utf8 Class Initialized
INFO - 2021-06-28 08:17:18 --> URI Class Initialized
INFO - 2021-06-28 08:17:18 --> Router Class Initialized
INFO - 2021-06-28 08:17:18 --> Output Class Initialized
INFO - 2021-06-28 08:17:18 --> Security Class Initialized
DEBUG - 2021-06-28 08:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:17:18 --> Input Class Initialized
INFO - 2021-06-28 08:17:18 --> Language Class Initialized
INFO - 2021-06-28 08:17:18 --> Language Class Initialized
INFO - 2021-06-28 08:17:18 --> Config Class Initialized
INFO - 2021-06-28 08:17:18 --> Loader Class Initialized
INFO - 2021-06-28 08:17:18 --> Helper loaded: url_helper
INFO - 2021-06-28 08:17:18 --> Helper loaded: file_helper
INFO - 2021-06-28 08:17:18 --> Helper loaded: form_helper
INFO - 2021-06-28 08:17:18 --> Helper loaded: my_helper
INFO - 2021-06-28 08:17:18 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:17:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:17:18 --> Controller Class Initialized
INFO - 2021-06-28 08:17:18 --> Final output sent to browser
DEBUG - 2021-06-28 08:17:18 --> Total execution time: 0.0996
INFO - 2021-06-28 08:17:30 --> Config Class Initialized
INFO - 2021-06-28 08:17:30 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:17:30 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:17:30 --> Utf8 Class Initialized
INFO - 2021-06-28 08:17:30 --> URI Class Initialized
INFO - 2021-06-28 08:17:30 --> Router Class Initialized
INFO - 2021-06-28 08:17:30 --> Output Class Initialized
INFO - 2021-06-28 08:17:30 --> Security Class Initialized
DEBUG - 2021-06-28 08:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:17:30 --> Input Class Initialized
INFO - 2021-06-28 08:17:30 --> Language Class Initialized
INFO - 2021-06-28 08:17:30 --> Language Class Initialized
INFO - 2021-06-28 08:17:30 --> Config Class Initialized
INFO - 2021-06-28 08:17:30 --> Loader Class Initialized
INFO - 2021-06-28 08:17:30 --> Helper loaded: url_helper
INFO - 2021-06-28 08:17:30 --> Helper loaded: file_helper
INFO - 2021-06-28 08:17:30 --> Helper loaded: form_helper
INFO - 2021-06-28 08:17:30 --> Helper loaded: my_helper
INFO - 2021-06-28 08:17:30 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:17:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:17:30 --> Controller Class Initialized
INFO - 2021-06-28 08:17:33 --> Config Class Initialized
INFO - 2021-06-28 08:17:33 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:17:33 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:17:33 --> Utf8 Class Initialized
INFO - 2021-06-28 08:17:33 --> URI Class Initialized
INFO - 2021-06-28 08:17:33 --> Router Class Initialized
INFO - 2021-06-28 08:17:33 --> Output Class Initialized
INFO - 2021-06-28 08:17:33 --> Security Class Initialized
DEBUG - 2021-06-28 08:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:17:33 --> Input Class Initialized
INFO - 2021-06-28 08:17:33 --> Language Class Initialized
INFO - 2021-06-28 08:17:33 --> Language Class Initialized
INFO - 2021-06-28 08:17:33 --> Config Class Initialized
INFO - 2021-06-28 08:17:33 --> Loader Class Initialized
INFO - 2021-06-28 08:17:33 --> Helper loaded: url_helper
INFO - 2021-06-28 08:17:33 --> Helper loaded: file_helper
INFO - 2021-06-28 08:17:33 --> Helper loaded: form_helper
INFO - 2021-06-28 08:17:33 --> Helper loaded: my_helper
INFO - 2021-06-28 08:17:33 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:17:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:17:33 --> Controller Class Initialized
INFO - 2021-06-28 08:18:23 --> Config Class Initialized
INFO - 2021-06-28 08:18:23 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:18:23 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:18:23 --> Utf8 Class Initialized
INFO - 2021-06-28 08:18:23 --> URI Class Initialized
INFO - 2021-06-28 08:18:23 --> Router Class Initialized
INFO - 2021-06-28 08:18:23 --> Output Class Initialized
INFO - 2021-06-28 08:18:23 --> Security Class Initialized
DEBUG - 2021-06-28 08:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:18:23 --> Input Class Initialized
INFO - 2021-06-28 08:18:23 --> Language Class Initialized
INFO - 2021-06-28 08:18:23 --> Language Class Initialized
INFO - 2021-06-28 08:18:23 --> Config Class Initialized
INFO - 2021-06-28 08:18:23 --> Loader Class Initialized
INFO - 2021-06-28 08:18:23 --> Helper loaded: url_helper
INFO - 2021-06-28 08:18:23 --> Helper loaded: file_helper
INFO - 2021-06-28 08:18:23 --> Helper loaded: form_helper
INFO - 2021-06-28 08:18:23 --> Helper loaded: my_helper
INFO - 2021-06-28 08:18:23 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:18:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:18:23 --> Controller Class Initialized
DEBUG - 2021-06-28 08:18:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2021-06-28 08:18:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:18:23 --> Final output sent to browser
DEBUG - 2021-06-28 08:18:23 --> Total execution time: 0.0439
INFO - 2021-06-28 08:18:28 --> Config Class Initialized
INFO - 2021-06-28 08:18:28 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:18:28 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:18:28 --> Utf8 Class Initialized
INFO - 2021-06-28 08:18:28 --> URI Class Initialized
INFO - 2021-06-28 08:18:28 --> Router Class Initialized
INFO - 2021-06-28 08:18:28 --> Output Class Initialized
INFO - 2021-06-28 08:18:28 --> Security Class Initialized
DEBUG - 2021-06-28 08:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:18:28 --> Input Class Initialized
INFO - 2021-06-28 08:18:28 --> Language Class Initialized
INFO - 2021-06-28 08:18:28 --> Language Class Initialized
INFO - 2021-06-28 08:18:28 --> Config Class Initialized
INFO - 2021-06-28 08:18:28 --> Loader Class Initialized
INFO - 2021-06-28 08:18:28 --> Helper loaded: url_helper
INFO - 2021-06-28 08:18:28 --> Helper loaded: file_helper
INFO - 2021-06-28 08:18:28 --> Helper loaded: form_helper
INFO - 2021-06-28 08:18:28 --> Helper loaded: my_helper
INFO - 2021-06-28 08:18:28 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:18:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:18:28 --> Controller Class Initialized
INFO - 2021-06-28 08:18:28 --> Config Class Initialized
INFO - 2021-06-28 08:18:28 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:18:28 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:18:28 --> Utf8 Class Initialized
INFO - 2021-06-28 08:18:28 --> URI Class Initialized
INFO - 2021-06-28 08:18:28 --> Router Class Initialized
INFO - 2021-06-28 08:18:28 --> Output Class Initialized
INFO - 2021-06-28 08:18:28 --> Security Class Initialized
DEBUG - 2021-06-28 08:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:18:28 --> Input Class Initialized
INFO - 2021-06-28 08:18:28 --> Language Class Initialized
INFO - 2021-06-28 08:18:28 --> Language Class Initialized
INFO - 2021-06-28 08:18:28 --> Config Class Initialized
INFO - 2021-06-28 08:18:28 --> Loader Class Initialized
INFO - 2021-06-28 08:18:28 --> Helper loaded: url_helper
INFO - 2021-06-28 08:18:28 --> Helper loaded: file_helper
INFO - 2021-06-28 08:18:28 --> Helper loaded: form_helper
INFO - 2021-06-28 08:18:28 --> Helper loaded: my_helper
INFO - 2021-06-28 08:18:28 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:18:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:18:28 --> Controller Class Initialized
DEBUG - 2021-06-28 08:18:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-28 08:18:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:18:28 --> Final output sent to browser
DEBUG - 2021-06-28 08:18:28 --> Total execution time: 0.0537
INFO - 2021-06-28 08:18:28 --> Config Class Initialized
INFO - 2021-06-28 08:18:28 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:18:28 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:18:28 --> Utf8 Class Initialized
INFO - 2021-06-28 08:18:28 --> URI Class Initialized
INFO - 2021-06-28 08:18:28 --> Router Class Initialized
INFO - 2021-06-28 08:18:28 --> Output Class Initialized
INFO - 2021-06-28 08:18:28 --> Security Class Initialized
DEBUG - 2021-06-28 08:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:18:28 --> Input Class Initialized
INFO - 2021-06-28 08:18:28 --> Language Class Initialized
INFO - 2021-06-28 08:18:28 --> Language Class Initialized
INFO - 2021-06-28 08:18:28 --> Config Class Initialized
INFO - 2021-06-28 08:18:28 --> Loader Class Initialized
INFO - 2021-06-28 08:18:28 --> Helper loaded: url_helper
INFO - 2021-06-28 08:18:28 --> Helper loaded: file_helper
INFO - 2021-06-28 08:18:28 --> Helper loaded: form_helper
INFO - 2021-06-28 08:18:28 --> Helper loaded: my_helper
INFO - 2021-06-28 08:18:28 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:18:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:18:28 --> Controller Class Initialized
INFO - 2021-06-28 08:18:29 --> Config Class Initialized
INFO - 2021-06-28 08:18:29 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:18:29 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:18:29 --> Utf8 Class Initialized
INFO - 2021-06-28 08:18:29 --> URI Class Initialized
INFO - 2021-06-28 08:18:29 --> Router Class Initialized
INFO - 2021-06-28 08:18:29 --> Output Class Initialized
INFO - 2021-06-28 08:18:29 --> Security Class Initialized
DEBUG - 2021-06-28 08:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:18:29 --> Input Class Initialized
INFO - 2021-06-28 08:18:29 --> Language Class Initialized
INFO - 2021-06-28 08:18:29 --> Language Class Initialized
INFO - 2021-06-28 08:18:29 --> Config Class Initialized
INFO - 2021-06-28 08:18:29 --> Loader Class Initialized
INFO - 2021-06-28 08:18:29 --> Helper loaded: url_helper
INFO - 2021-06-28 08:18:29 --> Helper loaded: file_helper
INFO - 2021-06-28 08:18:29 --> Helper loaded: form_helper
INFO - 2021-06-28 08:18:29 --> Helper loaded: my_helper
INFO - 2021-06-28 08:18:29 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:18:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:18:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:18:29 --> Controller Class Initialized
DEBUG - 2021-06-28 08:18:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2021-06-28 08:18:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:18:29 --> Final output sent to browser
DEBUG - 2021-06-28 08:18:29 --> Total execution time: 0.0526
INFO - 2021-06-28 08:18:32 --> Config Class Initialized
INFO - 2021-06-28 08:18:32 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:18:32 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:18:32 --> Utf8 Class Initialized
INFO - 2021-06-28 08:18:32 --> URI Class Initialized
INFO - 2021-06-28 08:18:32 --> Router Class Initialized
INFO - 2021-06-28 08:18:32 --> Output Class Initialized
INFO - 2021-06-28 08:18:32 --> Security Class Initialized
DEBUG - 2021-06-28 08:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:18:32 --> Input Class Initialized
INFO - 2021-06-28 08:18:32 --> Language Class Initialized
INFO - 2021-06-28 08:18:32 --> Language Class Initialized
INFO - 2021-06-28 08:18:32 --> Config Class Initialized
INFO - 2021-06-28 08:18:32 --> Loader Class Initialized
INFO - 2021-06-28 08:18:32 --> Helper loaded: url_helper
INFO - 2021-06-28 08:18:32 --> Helper loaded: file_helper
INFO - 2021-06-28 08:18:32 --> Helper loaded: form_helper
INFO - 2021-06-28 08:18:32 --> Helper loaded: my_helper
INFO - 2021-06-28 08:18:32 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:18:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:18:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:18:32 --> Controller Class Initialized
INFO - 2021-06-28 08:18:32 --> Config Class Initialized
INFO - 2021-06-28 08:18:32 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:18:32 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:18:32 --> Utf8 Class Initialized
INFO - 2021-06-28 08:18:32 --> URI Class Initialized
INFO - 2021-06-28 08:18:32 --> Router Class Initialized
INFO - 2021-06-28 08:18:32 --> Output Class Initialized
INFO - 2021-06-28 08:18:32 --> Security Class Initialized
DEBUG - 2021-06-28 08:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:18:32 --> Input Class Initialized
INFO - 2021-06-28 08:18:32 --> Language Class Initialized
INFO - 2021-06-28 08:18:32 --> Language Class Initialized
INFO - 2021-06-28 08:18:32 --> Config Class Initialized
INFO - 2021-06-28 08:18:32 --> Loader Class Initialized
INFO - 2021-06-28 08:18:32 --> Helper loaded: url_helper
INFO - 2021-06-28 08:18:32 --> Helper loaded: file_helper
INFO - 2021-06-28 08:18:32 --> Helper loaded: form_helper
INFO - 2021-06-28 08:18:32 --> Helper loaded: my_helper
INFO - 2021-06-28 08:18:32 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:18:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:18:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:18:32 --> Controller Class Initialized
DEBUG - 2021-06-28 08:18:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-28 08:18:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:18:32 --> Final output sent to browser
DEBUG - 2021-06-28 08:18:32 --> Total execution time: 0.0448
INFO - 2021-06-28 08:18:34 --> Config Class Initialized
INFO - 2021-06-28 08:18:34 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:18:34 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:18:34 --> Utf8 Class Initialized
INFO - 2021-06-28 08:18:34 --> URI Class Initialized
INFO - 2021-06-28 08:18:34 --> Router Class Initialized
INFO - 2021-06-28 08:18:34 --> Output Class Initialized
INFO - 2021-06-28 08:18:34 --> Security Class Initialized
DEBUG - 2021-06-28 08:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:18:34 --> Input Class Initialized
INFO - 2021-06-28 08:18:34 --> Language Class Initialized
INFO - 2021-06-28 08:18:34 --> Language Class Initialized
INFO - 2021-06-28 08:18:34 --> Config Class Initialized
INFO - 2021-06-28 08:18:34 --> Loader Class Initialized
INFO - 2021-06-28 08:18:34 --> Helper loaded: url_helper
INFO - 2021-06-28 08:18:34 --> Helper loaded: file_helper
INFO - 2021-06-28 08:18:34 --> Helper loaded: form_helper
INFO - 2021-06-28 08:18:34 --> Helper loaded: my_helper
INFO - 2021-06-28 08:18:34 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:18:34 --> Controller Class Initialized
INFO - 2021-06-28 08:18:34 --> Helper loaded: cookie_helper
INFO - 2021-06-28 08:18:34 --> Config Class Initialized
INFO - 2021-06-28 08:18:34 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:18:34 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:18:34 --> Utf8 Class Initialized
INFO - 2021-06-28 08:18:34 --> URI Class Initialized
INFO - 2021-06-28 08:18:34 --> Router Class Initialized
INFO - 2021-06-28 08:18:34 --> Output Class Initialized
INFO - 2021-06-28 08:18:34 --> Security Class Initialized
DEBUG - 2021-06-28 08:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:18:34 --> Input Class Initialized
INFO - 2021-06-28 08:18:34 --> Language Class Initialized
INFO - 2021-06-28 08:18:34 --> Language Class Initialized
INFO - 2021-06-28 08:18:34 --> Config Class Initialized
INFO - 2021-06-28 08:18:34 --> Loader Class Initialized
INFO - 2021-06-28 08:18:34 --> Helper loaded: url_helper
INFO - 2021-06-28 08:18:34 --> Helper loaded: file_helper
INFO - 2021-06-28 08:18:34 --> Helper loaded: form_helper
INFO - 2021-06-28 08:18:34 --> Helper loaded: my_helper
INFO - 2021-06-28 08:18:34 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:18:34 --> Controller Class Initialized
DEBUG - 2021-06-28 08:18:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-28 08:18:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:18:34 --> Final output sent to browser
DEBUG - 2021-06-28 08:18:34 --> Total execution time: 0.0490
INFO - 2021-06-28 08:18:39 --> Config Class Initialized
INFO - 2021-06-28 08:18:39 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:18:39 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:18:39 --> Utf8 Class Initialized
INFO - 2021-06-28 08:18:39 --> URI Class Initialized
INFO - 2021-06-28 08:18:39 --> Router Class Initialized
INFO - 2021-06-28 08:18:39 --> Output Class Initialized
INFO - 2021-06-28 08:18:39 --> Security Class Initialized
DEBUG - 2021-06-28 08:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:18:39 --> Input Class Initialized
INFO - 2021-06-28 08:18:39 --> Language Class Initialized
INFO - 2021-06-28 08:18:39 --> Language Class Initialized
INFO - 2021-06-28 08:18:39 --> Config Class Initialized
INFO - 2021-06-28 08:18:39 --> Loader Class Initialized
INFO - 2021-06-28 08:18:39 --> Helper loaded: url_helper
INFO - 2021-06-28 08:18:39 --> Helper loaded: file_helper
INFO - 2021-06-28 08:18:39 --> Helper loaded: form_helper
INFO - 2021-06-28 08:18:39 --> Helper loaded: my_helper
INFO - 2021-06-28 08:18:39 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:18:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:18:39 --> Controller Class Initialized
INFO - 2021-06-28 08:18:39 --> Helper loaded: cookie_helper
INFO - 2021-06-28 08:18:39 --> Final output sent to browser
DEBUG - 2021-06-28 08:18:39 --> Total execution time: 0.0429
INFO - 2021-06-28 08:18:39 --> Config Class Initialized
INFO - 2021-06-28 08:18:39 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:18:39 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:18:39 --> Utf8 Class Initialized
INFO - 2021-06-28 08:18:39 --> URI Class Initialized
INFO - 2021-06-28 08:18:39 --> Router Class Initialized
INFO - 2021-06-28 08:18:39 --> Output Class Initialized
INFO - 2021-06-28 08:18:39 --> Security Class Initialized
DEBUG - 2021-06-28 08:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:18:39 --> Input Class Initialized
INFO - 2021-06-28 08:18:39 --> Language Class Initialized
INFO - 2021-06-28 08:18:39 --> Language Class Initialized
INFO - 2021-06-28 08:18:39 --> Config Class Initialized
INFO - 2021-06-28 08:18:39 --> Loader Class Initialized
INFO - 2021-06-28 08:18:39 --> Helper loaded: url_helper
INFO - 2021-06-28 08:18:39 --> Helper loaded: file_helper
INFO - 2021-06-28 08:18:39 --> Helper loaded: form_helper
INFO - 2021-06-28 08:18:39 --> Helper loaded: my_helper
INFO - 2021-06-28 08:18:39 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:18:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:18:39 --> Controller Class Initialized
DEBUG - 2021-06-28 08:18:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-28 08:18:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:18:40 --> Final output sent to browser
DEBUG - 2021-06-28 08:18:40 --> Total execution time: 0.6420
INFO - 2021-06-28 08:18:43 --> Config Class Initialized
INFO - 2021-06-28 08:18:43 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:18:43 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:18:43 --> Utf8 Class Initialized
INFO - 2021-06-28 08:18:43 --> URI Class Initialized
INFO - 2021-06-28 08:18:43 --> Router Class Initialized
INFO - 2021-06-28 08:18:43 --> Output Class Initialized
INFO - 2021-06-28 08:18:43 --> Security Class Initialized
DEBUG - 2021-06-28 08:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:18:43 --> Input Class Initialized
INFO - 2021-06-28 08:18:43 --> Language Class Initialized
INFO - 2021-06-28 08:18:43 --> Language Class Initialized
INFO - 2021-06-28 08:18:43 --> Config Class Initialized
INFO - 2021-06-28 08:18:43 --> Loader Class Initialized
INFO - 2021-06-28 08:18:43 --> Helper loaded: url_helper
INFO - 2021-06-28 08:18:43 --> Helper loaded: file_helper
INFO - 2021-06-28 08:18:43 --> Helper loaded: form_helper
INFO - 2021-06-28 08:18:43 --> Helper loaded: my_helper
INFO - 2021-06-28 08:18:43 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:18:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:18:43 --> Controller Class Initialized
DEBUG - 2021-06-28 08:18:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-06-28 08:18:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:18:43 --> Final output sent to browser
DEBUG - 2021-06-28 08:18:43 --> Total execution time: 0.0502
INFO - 2021-06-28 08:18:47 --> Config Class Initialized
INFO - 2021-06-28 08:18:47 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:18:47 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:18:47 --> Utf8 Class Initialized
INFO - 2021-06-28 08:18:47 --> URI Class Initialized
DEBUG - 2021-06-28 08:18:47 --> No URI present. Default controller set.
INFO - 2021-06-28 08:18:47 --> Router Class Initialized
INFO - 2021-06-28 08:18:47 --> Output Class Initialized
INFO - 2021-06-28 08:18:47 --> Security Class Initialized
DEBUG - 2021-06-28 08:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:18:47 --> Input Class Initialized
INFO - 2021-06-28 08:18:47 --> Language Class Initialized
INFO - 2021-06-28 08:18:47 --> Language Class Initialized
INFO - 2021-06-28 08:18:47 --> Config Class Initialized
INFO - 2021-06-28 08:18:47 --> Loader Class Initialized
INFO - 2021-06-28 08:18:47 --> Helper loaded: url_helper
INFO - 2021-06-28 08:18:47 --> Helper loaded: file_helper
INFO - 2021-06-28 08:18:47 --> Helper loaded: form_helper
INFO - 2021-06-28 08:18:47 --> Helper loaded: my_helper
INFO - 2021-06-28 08:18:47 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:18:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:18:47 --> Controller Class Initialized
DEBUG - 2021-06-28 08:18:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-28 08:18:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:18:48 --> Final output sent to browser
DEBUG - 2021-06-28 08:18:48 --> Total execution time: 0.6219
INFO - 2021-06-28 08:18:49 --> Config Class Initialized
INFO - 2021-06-28 08:18:49 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:18:49 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:18:49 --> Utf8 Class Initialized
INFO - 2021-06-28 08:18:49 --> URI Class Initialized
INFO - 2021-06-28 08:18:49 --> Router Class Initialized
INFO - 2021-06-28 08:18:49 --> Output Class Initialized
INFO - 2021-06-28 08:18:49 --> Security Class Initialized
DEBUG - 2021-06-28 08:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:18:49 --> Input Class Initialized
INFO - 2021-06-28 08:18:49 --> Language Class Initialized
INFO - 2021-06-28 08:18:49 --> Language Class Initialized
INFO - 2021-06-28 08:18:49 --> Config Class Initialized
INFO - 2021-06-28 08:18:49 --> Loader Class Initialized
INFO - 2021-06-28 08:18:49 --> Helper loaded: url_helper
INFO - 2021-06-28 08:18:49 --> Helper loaded: file_helper
INFO - 2021-06-28 08:18:49 --> Helper loaded: form_helper
INFO - 2021-06-28 08:18:49 --> Helper loaded: my_helper
INFO - 2021-06-28 08:18:49 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:18:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:18:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:18:49 --> Controller Class Initialized
DEBUG - 2021-06-28 08:18:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-06-28 08:18:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:18:49 --> Final output sent to browser
DEBUG - 2021-06-28 08:18:49 --> Total execution time: 0.0581
INFO - 2021-06-28 08:18:50 --> Config Class Initialized
INFO - 2021-06-28 08:18:50 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:18:50 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:18:50 --> Utf8 Class Initialized
INFO - 2021-06-28 08:18:50 --> URI Class Initialized
INFO - 2021-06-28 08:18:50 --> Router Class Initialized
INFO - 2021-06-28 08:18:50 --> Output Class Initialized
INFO - 2021-06-28 08:18:50 --> Security Class Initialized
DEBUG - 2021-06-28 08:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:18:50 --> Input Class Initialized
INFO - 2021-06-28 08:18:50 --> Language Class Initialized
INFO - 2021-06-28 08:18:50 --> Language Class Initialized
INFO - 2021-06-28 08:18:50 --> Config Class Initialized
INFO - 2021-06-28 08:18:50 --> Loader Class Initialized
INFO - 2021-06-28 08:18:50 --> Helper loaded: url_helper
INFO - 2021-06-28 08:18:50 --> Helper loaded: file_helper
INFO - 2021-06-28 08:18:50 --> Helper loaded: form_helper
INFO - 2021-06-28 08:18:50 --> Helper loaded: my_helper
INFO - 2021-06-28 08:18:50 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:18:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:18:50 --> Controller Class Initialized
DEBUG - 2021-06-28 08:18:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tkro_xi.php
INFO - 2021-06-28 08:18:50 --> Final output sent to browser
DEBUG - 2021-06-28 08:18:50 --> Total execution time: 0.4024
INFO - 2021-06-28 08:18:54 --> Config Class Initialized
INFO - 2021-06-28 08:18:54 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:18:54 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:18:54 --> Utf8 Class Initialized
INFO - 2021-06-28 08:18:54 --> URI Class Initialized
INFO - 2021-06-28 08:18:54 --> Router Class Initialized
INFO - 2021-06-28 08:18:54 --> Output Class Initialized
INFO - 2021-06-28 08:18:54 --> Security Class Initialized
DEBUG - 2021-06-28 08:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:18:54 --> Input Class Initialized
INFO - 2021-06-28 08:18:54 --> Language Class Initialized
INFO - 2021-06-28 08:18:54 --> Language Class Initialized
INFO - 2021-06-28 08:18:54 --> Config Class Initialized
INFO - 2021-06-28 08:18:54 --> Loader Class Initialized
INFO - 2021-06-28 08:18:54 --> Helper loaded: url_helper
INFO - 2021-06-28 08:18:54 --> Helper loaded: file_helper
INFO - 2021-06-28 08:18:54 --> Helper loaded: form_helper
INFO - 2021-06-28 08:18:54 --> Helper loaded: my_helper
INFO - 2021-06-28 08:18:54 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:18:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:18:54 --> Controller Class Initialized
DEBUG - 2021-06-28 08:18:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tkro_xii.php
INFO - 2021-06-28 08:18:54 --> Final output sent to browser
DEBUG - 2021-06-28 08:18:54 --> Total execution time: 0.2927
INFO - 2021-06-28 08:19:23 --> Config Class Initialized
INFO - 2021-06-28 08:19:23 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:19:23 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:19:23 --> Utf8 Class Initialized
INFO - 2021-06-28 08:19:23 --> URI Class Initialized
INFO - 2021-06-28 08:19:23 --> Router Class Initialized
INFO - 2021-06-28 08:19:23 --> Output Class Initialized
INFO - 2021-06-28 08:19:23 --> Security Class Initialized
DEBUG - 2021-06-28 08:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:19:23 --> Input Class Initialized
INFO - 2021-06-28 08:19:23 --> Language Class Initialized
INFO - 2021-06-28 08:19:23 --> Language Class Initialized
INFO - 2021-06-28 08:19:23 --> Config Class Initialized
INFO - 2021-06-28 08:19:23 --> Loader Class Initialized
INFO - 2021-06-28 08:19:23 --> Helper loaded: url_helper
INFO - 2021-06-28 08:19:23 --> Helper loaded: file_helper
INFO - 2021-06-28 08:19:23 --> Helper loaded: form_helper
INFO - 2021-06-28 08:19:23 --> Helper loaded: my_helper
INFO - 2021-06-28 08:19:23 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:19:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:19:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:19:23 --> Controller Class Initialized
INFO - 2021-06-28 08:19:23 --> Helper loaded: cookie_helper
INFO - 2021-06-28 08:19:23 --> Config Class Initialized
INFO - 2021-06-28 08:19:23 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:19:23 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:19:23 --> Utf8 Class Initialized
INFO - 2021-06-28 08:19:23 --> URI Class Initialized
INFO - 2021-06-28 08:19:23 --> Router Class Initialized
INFO - 2021-06-28 08:19:23 --> Output Class Initialized
INFO - 2021-06-28 08:19:23 --> Security Class Initialized
DEBUG - 2021-06-28 08:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:19:23 --> Input Class Initialized
INFO - 2021-06-28 08:19:23 --> Language Class Initialized
INFO - 2021-06-28 08:19:23 --> Language Class Initialized
INFO - 2021-06-28 08:19:23 --> Config Class Initialized
INFO - 2021-06-28 08:19:23 --> Loader Class Initialized
INFO - 2021-06-28 08:19:23 --> Helper loaded: url_helper
INFO - 2021-06-28 08:19:23 --> Helper loaded: file_helper
INFO - 2021-06-28 08:19:23 --> Helper loaded: form_helper
INFO - 2021-06-28 08:19:23 --> Helper loaded: my_helper
INFO - 2021-06-28 08:19:23 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:19:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:19:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:19:23 --> Controller Class Initialized
DEBUG - 2021-06-28 08:19:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-28 08:19:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:19:23 --> Final output sent to browser
DEBUG - 2021-06-28 08:19:23 --> Total execution time: 0.0413
INFO - 2021-06-28 08:19:45 --> Config Class Initialized
INFO - 2021-06-28 08:19:45 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:19:45 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:19:45 --> Utf8 Class Initialized
INFO - 2021-06-28 08:19:45 --> URI Class Initialized
INFO - 2021-06-28 08:19:45 --> Router Class Initialized
INFO - 2021-06-28 08:19:45 --> Output Class Initialized
INFO - 2021-06-28 08:19:45 --> Security Class Initialized
DEBUG - 2021-06-28 08:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:19:45 --> Input Class Initialized
INFO - 2021-06-28 08:19:45 --> Language Class Initialized
INFO - 2021-06-28 08:19:45 --> Language Class Initialized
INFO - 2021-06-28 08:19:45 --> Config Class Initialized
INFO - 2021-06-28 08:19:45 --> Loader Class Initialized
INFO - 2021-06-28 08:19:45 --> Helper loaded: url_helper
INFO - 2021-06-28 08:19:45 --> Helper loaded: file_helper
INFO - 2021-06-28 08:19:45 --> Helper loaded: form_helper
INFO - 2021-06-28 08:19:45 --> Helper loaded: my_helper
INFO - 2021-06-28 08:19:45 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:19:45 --> Controller Class Initialized
INFO - 2021-06-28 08:19:45 --> Helper loaded: cookie_helper
INFO - 2021-06-28 08:19:45 --> Final output sent to browser
DEBUG - 2021-06-28 08:19:45 --> Total execution time: 0.0456
INFO - 2021-06-28 08:19:45 --> Config Class Initialized
INFO - 2021-06-28 08:19:45 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:19:45 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:19:45 --> Utf8 Class Initialized
INFO - 2021-06-28 08:19:45 --> URI Class Initialized
INFO - 2021-06-28 08:19:45 --> Router Class Initialized
INFO - 2021-06-28 08:19:45 --> Output Class Initialized
INFO - 2021-06-28 08:19:45 --> Security Class Initialized
DEBUG - 2021-06-28 08:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:19:45 --> Input Class Initialized
INFO - 2021-06-28 08:19:45 --> Language Class Initialized
INFO - 2021-06-28 08:19:45 --> Language Class Initialized
INFO - 2021-06-28 08:19:45 --> Config Class Initialized
INFO - 2021-06-28 08:19:45 --> Loader Class Initialized
INFO - 2021-06-28 08:19:45 --> Helper loaded: url_helper
INFO - 2021-06-28 08:19:45 --> Helper loaded: file_helper
INFO - 2021-06-28 08:19:45 --> Helper loaded: form_helper
INFO - 2021-06-28 08:19:45 --> Helper loaded: my_helper
INFO - 2021-06-28 08:19:45 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:19:45 --> Controller Class Initialized
DEBUG - 2021-06-28 08:19:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-28 08:19:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:19:46 --> Final output sent to browser
DEBUG - 2021-06-28 08:19:46 --> Total execution time: 0.6357
INFO - 2021-06-28 08:19:47 --> Config Class Initialized
INFO - 2021-06-28 08:19:47 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:19:47 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:19:47 --> Utf8 Class Initialized
INFO - 2021-06-28 08:19:47 --> URI Class Initialized
INFO - 2021-06-28 08:19:48 --> Router Class Initialized
INFO - 2021-06-28 08:19:48 --> Output Class Initialized
INFO - 2021-06-28 08:19:48 --> Security Class Initialized
DEBUG - 2021-06-28 08:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:19:48 --> Input Class Initialized
INFO - 2021-06-28 08:19:48 --> Language Class Initialized
INFO - 2021-06-28 08:19:48 --> Language Class Initialized
INFO - 2021-06-28 08:19:48 --> Config Class Initialized
INFO - 2021-06-28 08:19:48 --> Loader Class Initialized
INFO - 2021-06-28 08:19:48 --> Helper loaded: url_helper
INFO - 2021-06-28 08:19:48 --> Helper loaded: file_helper
INFO - 2021-06-28 08:19:48 --> Helper loaded: form_helper
INFO - 2021-06-28 08:19:48 --> Helper loaded: my_helper
INFO - 2021-06-28 08:19:48 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:19:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:19:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:19:48 --> Controller Class Initialized
DEBUG - 2021-06-28 08:19:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-06-28 08:19:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:19:48 --> Final output sent to browser
DEBUG - 2021-06-28 08:19:48 --> Total execution time: 0.0584
INFO - 2021-06-28 08:19:49 --> Config Class Initialized
INFO - 2021-06-28 08:19:49 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:19:49 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:19:49 --> Utf8 Class Initialized
INFO - 2021-06-28 08:19:49 --> URI Class Initialized
INFO - 2021-06-28 08:19:49 --> Router Class Initialized
INFO - 2021-06-28 08:19:49 --> Output Class Initialized
INFO - 2021-06-28 08:19:49 --> Security Class Initialized
DEBUG - 2021-06-28 08:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:19:49 --> Input Class Initialized
INFO - 2021-06-28 08:19:49 --> Language Class Initialized
INFO - 2021-06-28 08:19:49 --> Language Class Initialized
INFO - 2021-06-28 08:19:49 --> Config Class Initialized
INFO - 2021-06-28 08:19:49 --> Loader Class Initialized
INFO - 2021-06-28 08:19:49 --> Helper loaded: url_helper
INFO - 2021-06-28 08:19:49 --> Helper loaded: file_helper
INFO - 2021-06-28 08:19:49 --> Helper loaded: form_helper
INFO - 2021-06-28 08:19:49 --> Helper loaded: my_helper
INFO - 2021-06-28 08:19:49 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:19:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:19:49 --> Controller Class Initialized
DEBUG - 2021-06-28 08:19:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tkj_xii.php
INFO - 2021-06-28 08:19:49 --> Final output sent to browser
DEBUG - 2021-06-28 08:19:49 --> Total execution time: 0.3018
INFO - 2021-06-28 08:20:26 --> Config Class Initialized
INFO - 2021-06-28 08:20:26 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:20:26 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:20:26 --> Utf8 Class Initialized
INFO - 2021-06-28 08:20:26 --> URI Class Initialized
INFO - 2021-06-28 08:20:26 --> Router Class Initialized
INFO - 2021-06-28 08:20:26 --> Output Class Initialized
INFO - 2021-06-28 08:20:26 --> Security Class Initialized
DEBUG - 2021-06-28 08:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:20:26 --> Input Class Initialized
INFO - 2021-06-28 08:20:26 --> Language Class Initialized
INFO - 2021-06-28 08:20:26 --> Language Class Initialized
INFO - 2021-06-28 08:20:26 --> Config Class Initialized
INFO - 2021-06-28 08:20:26 --> Loader Class Initialized
INFO - 2021-06-28 08:20:26 --> Helper loaded: url_helper
INFO - 2021-06-28 08:20:26 --> Helper loaded: file_helper
INFO - 2021-06-28 08:20:26 --> Helper loaded: form_helper
INFO - 2021-06-28 08:20:26 --> Helper loaded: my_helper
INFO - 2021-06-28 08:20:26 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:20:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:20:26 --> Controller Class Initialized
INFO - 2021-06-28 08:20:26 --> Helper loaded: cookie_helper
INFO - 2021-06-28 08:20:26 --> Config Class Initialized
INFO - 2021-06-28 08:20:26 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:20:26 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:20:26 --> Utf8 Class Initialized
INFO - 2021-06-28 08:20:26 --> URI Class Initialized
INFO - 2021-06-28 08:20:26 --> Router Class Initialized
INFO - 2021-06-28 08:20:26 --> Output Class Initialized
INFO - 2021-06-28 08:20:26 --> Security Class Initialized
DEBUG - 2021-06-28 08:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:20:26 --> Input Class Initialized
INFO - 2021-06-28 08:20:26 --> Language Class Initialized
INFO - 2021-06-28 08:20:26 --> Language Class Initialized
INFO - 2021-06-28 08:20:26 --> Config Class Initialized
INFO - 2021-06-28 08:20:26 --> Loader Class Initialized
INFO - 2021-06-28 08:20:26 --> Helper loaded: url_helper
INFO - 2021-06-28 08:20:26 --> Helper loaded: file_helper
INFO - 2021-06-28 08:20:26 --> Helper loaded: form_helper
INFO - 2021-06-28 08:20:26 --> Helper loaded: my_helper
INFO - 2021-06-28 08:20:26 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:20:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:20:26 --> Controller Class Initialized
DEBUG - 2021-06-28 08:20:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-28 08:20:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:20:26 --> Final output sent to browser
DEBUG - 2021-06-28 08:20:26 --> Total execution time: 0.0505
INFO - 2021-06-28 08:20:30 --> Config Class Initialized
INFO - 2021-06-28 08:20:30 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:20:30 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:20:30 --> Utf8 Class Initialized
INFO - 2021-06-28 08:20:30 --> URI Class Initialized
INFO - 2021-06-28 08:20:30 --> Router Class Initialized
INFO - 2021-06-28 08:20:30 --> Output Class Initialized
INFO - 2021-06-28 08:20:30 --> Security Class Initialized
DEBUG - 2021-06-28 08:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:20:30 --> Input Class Initialized
INFO - 2021-06-28 08:20:30 --> Language Class Initialized
INFO - 2021-06-28 08:20:30 --> Language Class Initialized
INFO - 2021-06-28 08:20:30 --> Config Class Initialized
INFO - 2021-06-28 08:20:30 --> Loader Class Initialized
INFO - 2021-06-28 08:20:30 --> Helper loaded: url_helper
INFO - 2021-06-28 08:20:30 --> Helper loaded: file_helper
INFO - 2021-06-28 08:20:30 --> Helper loaded: form_helper
INFO - 2021-06-28 08:20:30 --> Helper loaded: my_helper
INFO - 2021-06-28 08:20:30 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:20:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:20:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:20:30 --> Controller Class Initialized
INFO - 2021-06-28 08:20:30 --> Helper loaded: cookie_helper
INFO - 2021-06-28 08:20:30 --> Final output sent to browser
DEBUG - 2021-06-28 08:20:30 --> Total execution time: 0.0455
INFO - 2021-06-28 08:20:30 --> Config Class Initialized
INFO - 2021-06-28 08:20:30 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:20:30 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:20:30 --> Utf8 Class Initialized
INFO - 2021-06-28 08:20:30 --> URI Class Initialized
INFO - 2021-06-28 08:20:30 --> Router Class Initialized
INFO - 2021-06-28 08:20:30 --> Output Class Initialized
INFO - 2021-06-28 08:20:30 --> Security Class Initialized
DEBUG - 2021-06-28 08:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:20:30 --> Input Class Initialized
INFO - 2021-06-28 08:20:30 --> Language Class Initialized
INFO - 2021-06-28 08:20:30 --> Language Class Initialized
INFO - 2021-06-28 08:20:30 --> Config Class Initialized
INFO - 2021-06-28 08:20:30 --> Loader Class Initialized
INFO - 2021-06-28 08:20:30 --> Helper loaded: url_helper
INFO - 2021-06-28 08:20:30 --> Helper loaded: file_helper
INFO - 2021-06-28 08:20:30 --> Helper loaded: form_helper
INFO - 2021-06-28 08:20:30 --> Helper loaded: my_helper
INFO - 2021-06-28 08:20:30 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:20:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:20:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:20:30 --> Controller Class Initialized
DEBUG - 2021-06-28 08:20:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-28 08:20:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:20:31 --> Final output sent to browser
DEBUG - 2021-06-28 08:20:31 --> Total execution time: 0.6507
INFO - 2021-06-28 08:20:32 --> Config Class Initialized
INFO - 2021-06-28 08:20:32 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:20:32 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:20:32 --> Utf8 Class Initialized
INFO - 2021-06-28 08:20:32 --> URI Class Initialized
INFO - 2021-06-28 08:20:32 --> Router Class Initialized
INFO - 2021-06-28 08:20:32 --> Output Class Initialized
INFO - 2021-06-28 08:20:32 --> Security Class Initialized
DEBUG - 2021-06-28 08:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:20:32 --> Input Class Initialized
INFO - 2021-06-28 08:20:32 --> Language Class Initialized
INFO - 2021-06-28 08:20:32 --> Language Class Initialized
INFO - 2021-06-28 08:20:32 --> Config Class Initialized
INFO - 2021-06-28 08:20:32 --> Loader Class Initialized
INFO - 2021-06-28 08:20:32 --> Helper loaded: url_helper
INFO - 2021-06-28 08:20:32 --> Helper loaded: file_helper
INFO - 2021-06-28 08:20:32 --> Helper loaded: form_helper
INFO - 2021-06-28 08:20:32 --> Helper loaded: my_helper
INFO - 2021-06-28 08:20:32 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:20:32 --> Controller Class Initialized
DEBUG - 2021-06-28 08:20:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-06-28 08:20:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:20:32 --> Final output sent to browser
DEBUG - 2021-06-28 08:20:32 --> Total execution time: 0.0585
INFO - 2021-06-28 08:20:34 --> Config Class Initialized
INFO - 2021-06-28 08:20:34 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:20:34 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:20:34 --> Utf8 Class Initialized
INFO - 2021-06-28 08:20:34 --> URI Class Initialized
INFO - 2021-06-28 08:20:34 --> Router Class Initialized
INFO - 2021-06-28 08:20:34 --> Output Class Initialized
INFO - 2021-06-28 08:20:34 --> Security Class Initialized
DEBUG - 2021-06-28 08:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:20:34 --> Input Class Initialized
INFO - 2021-06-28 08:20:34 --> Language Class Initialized
INFO - 2021-06-28 08:20:34 --> Language Class Initialized
INFO - 2021-06-28 08:20:34 --> Config Class Initialized
INFO - 2021-06-28 08:20:34 --> Loader Class Initialized
INFO - 2021-06-28 08:20:34 --> Helper loaded: url_helper
INFO - 2021-06-28 08:20:34 --> Helper loaded: file_helper
INFO - 2021-06-28 08:20:34 --> Helper loaded: form_helper
INFO - 2021-06-28 08:20:34 --> Helper loaded: my_helper
INFO - 2021-06-28 08:20:34 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:20:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:20:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:20:34 --> Controller Class Initialized
DEBUG - 2021-06-28 08:20:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tkj_xii.php
INFO - 2021-06-28 08:20:34 --> Final output sent to browser
DEBUG - 2021-06-28 08:20:34 --> Total execution time: 0.3051
INFO - 2021-06-28 08:22:21 --> Config Class Initialized
INFO - 2021-06-28 08:22:21 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:22:21 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:22:21 --> Utf8 Class Initialized
INFO - 2021-06-28 08:22:21 --> URI Class Initialized
INFO - 2021-06-28 08:22:21 --> Router Class Initialized
INFO - 2021-06-28 08:22:21 --> Output Class Initialized
INFO - 2021-06-28 08:22:21 --> Security Class Initialized
DEBUG - 2021-06-28 08:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:22:21 --> Input Class Initialized
INFO - 2021-06-28 08:22:21 --> Language Class Initialized
INFO - 2021-06-28 08:22:21 --> Language Class Initialized
INFO - 2021-06-28 08:22:21 --> Config Class Initialized
INFO - 2021-06-28 08:22:21 --> Loader Class Initialized
INFO - 2021-06-28 08:22:21 --> Helper loaded: url_helper
INFO - 2021-06-28 08:22:21 --> Helper loaded: file_helper
INFO - 2021-06-28 08:22:21 --> Helper loaded: form_helper
INFO - 2021-06-28 08:22:21 --> Helper loaded: my_helper
INFO - 2021-06-28 08:22:21 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:22:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:22:21 --> Controller Class Initialized
DEBUG - 2021-06-28 08:22:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-06-28 08:22:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:22:21 --> Final output sent to browser
DEBUG - 2021-06-28 08:22:21 --> Total execution time: 0.0527
INFO - 2021-06-28 08:22:30 --> Config Class Initialized
INFO - 2021-06-28 08:22:30 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:22:30 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:22:30 --> Utf8 Class Initialized
INFO - 2021-06-28 08:22:30 --> URI Class Initialized
INFO - 2021-06-28 08:22:30 --> Router Class Initialized
INFO - 2021-06-28 08:22:30 --> Output Class Initialized
INFO - 2021-06-28 08:22:30 --> Security Class Initialized
DEBUG - 2021-06-28 08:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:22:30 --> Input Class Initialized
INFO - 2021-06-28 08:22:30 --> Language Class Initialized
INFO - 2021-06-28 08:22:30 --> Language Class Initialized
INFO - 2021-06-28 08:22:30 --> Config Class Initialized
INFO - 2021-06-28 08:22:30 --> Loader Class Initialized
INFO - 2021-06-28 08:22:30 --> Helper loaded: url_helper
INFO - 2021-06-28 08:22:30 --> Helper loaded: file_helper
INFO - 2021-06-28 08:22:30 --> Helper loaded: form_helper
INFO - 2021-06-28 08:22:30 --> Helper loaded: my_helper
INFO - 2021-06-28 08:22:30 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:22:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:22:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:22:30 --> Controller Class Initialized
DEBUG - 2021-06-28 08:22:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-06-28 08:22:30 --> Final output sent to browser
DEBUG - 2021-06-28 08:22:30 --> Total execution time: 0.1891
INFO - 2021-06-28 08:29:38 --> Config Class Initialized
INFO - 2021-06-28 08:29:38 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:29:38 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:29:38 --> Utf8 Class Initialized
INFO - 2021-06-28 08:29:38 --> URI Class Initialized
INFO - 2021-06-28 08:29:38 --> Router Class Initialized
INFO - 2021-06-28 08:29:38 --> Output Class Initialized
INFO - 2021-06-28 08:29:38 --> Security Class Initialized
DEBUG - 2021-06-28 08:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:29:38 --> Input Class Initialized
INFO - 2021-06-28 08:29:38 --> Language Class Initialized
INFO - 2021-06-28 08:29:38 --> Language Class Initialized
INFO - 2021-06-28 08:29:38 --> Config Class Initialized
INFO - 2021-06-28 08:29:38 --> Loader Class Initialized
INFO - 2021-06-28 08:29:38 --> Helper loaded: url_helper
INFO - 2021-06-28 08:29:38 --> Helper loaded: file_helper
INFO - 2021-06-28 08:29:38 --> Helper loaded: form_helper
INFO - 2021-06-28 08:29:38 --> Helper loaded: my_helper
INFO - 2021-06-28 08:29:38 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:29:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:29:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:29:38 --> Controller Class Initialized
INFO - 2021-06-28 08:29:38 --> Helper loaded: cookie_helper
INFO - 2021-06-28 08:29:38 --> Config Class Initialized
INFO - 2021-06-28 08:29:38 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:29:38 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:29:38 --> Utf8 Class Initialized
INFO - 2021-06-28 08:29:38 --> URI Class Initialized
INFO - 2021-06-28 08:29:38 --> Router Class Initialized
INFO - 2021-06-28 08:29:38 --> Output Class Initialized
INFO - 2021-06-28 08:29:38 --> Security Class Initialized
DEBUG - 2021-06-28 08:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:29:38 --> Input Class Initialized
INFO - 2021-06-28 08:29:38 --> Language Class Initialized
INFO - 2021-06-28 08:29:38 --> Language Class Initialized
INFO - 2021-06-28 08:29:38 --> Config Class Initialized
INFO - 2021-06-28 08:29:38 --> Loader Class Initialized
INFO - 2021-06-28 08:29:38 --> Helper loaded: url_helper
INFO - 2021-06-28 08:29:38 --> Helper loaded: file_helper
INFO - 2021-06-28 08:29:38 --> Helper loaded: form_helper
INFO - 2021-06-28 08:29:38 --> Helper loaded: my_helper
INFO - 2021-06-28 08:29:38 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:29:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:29:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:29:38 --> Controller Class Initialized
DEBUG - 2021-06-28 08:29:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-28 08:29:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:29:38 --> Final output sent to browser
DEBUG - 2021-06-28 08:29:38 --> Total execution time: 0.0440
INFO - 2021-06-28 08:29:42 --> Config Class Initialized
INFO - 2021-06-28 08:29:42 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:29:42 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:29:42 --> Utf8 Class Initialized
INFO - 2021-06-28 08:29:42 --> URI Class Initialized
INFO - 2021-06-28 08:29:42 --> Router Class Initialized
INFO - 2021-06-28 08:29:42 --> Output Class Initialized
INFO - 2021-06-28 08:29:42 --> Security Class Initialized
DEBUG - 2021-06-28 08:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:29:42 --> Input Class Initialized
INFO - 2021-06-28 08:29:42 --> Language Class Initialized
INFO - 2021-06-28 08:29:42 --> Language Class Initialized
INFO - 2021-06-28 08:29:42 --> Config Class Initialized
INFO - 2021-06-28 08:29:42 --> Loader Class Initialized
INFO - 2021-06-28 08:29:42 --> Helper loaded: url_helper
INFO - 2021-06-28 08:29:42 --> Helper loaded: file_helper
INFO - 2021-06-28 08:29:42 --> Helper loaded: form_helper
INFO - 2021-06-28 08:29:42 --> Helper loaded: my_helper
INFO - 2021-06-28 08:29:42 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:29:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:29:42 --> Controller Class Initialized
INFO - 2021-06-28 08:29:42 --> Final output sent to browser
DEBUG - 2021-06-28 08:29:42 --> Total execution time: 0.0512
INFO - 2021-06-28 08:29:45 --> Config Class Initialized
INFO - 2021-06-28 08:29:45 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:29:45 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:29:45 --> Utf8 Class Initialized
INFO - 2021-06-28 08:29:45 --> URI Class Initialized
INFO - 2021-06-28 08:29:45 --> Router Class Initialized
INFO - 2021-06-28 08:29:45 --> Output Class Initialized
INFO - 2021-06-28 08:29:45 --> Security Class Initialized
DEBUG - 2021-06-28 08:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:29:45 --> Input Class Initialized
INFO - 2021-06-28 08:29:45 --> Language Class Initialized
INFO - 2021-06-28 08:29:45 --> Language Class Initialized
INFO - 2021-06-28 08:29:45 --> Config Class Initialized
INFO - 2021-06-28 08:29:45 --> Loader Class Initialized
INFO - 2021-06-28 08:29:45 --> Helper loaded: url_helper
INFO - 2021-06-28 08:29:45 --> Helper loaded: file_helper
INFO - 2021-06-28 08:29:45 --> Helper loaded: form_helper
INFO - 2021-06-28 08:29:45 --> Helper loaded: my_helper
INFO - 2021-06-28 08:29:45 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:29:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:29:45 --> Controller Class Initialized
INFO - 2021-06-28 08:29:45 --> Helper loaded: cookie_helper
INFO - 2021-06-28 08:29:45 --> Final output sent to browser
DEBUG - 2021-06-28 08:29:45 --> Total execution time: 0.0518
INFO - 2021-06-28 08:29:45 --> Config Class Initialized
INFO - 2021-06-28 08:29:45 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:29:45 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:29:45 --> Utf8 Class Initialized
INFO - 2021-06-28 08:29:45 --> URI Class Initialized
INFO - 2021-06-28 08:29:46 --> Router Class Initialized
INFO - 2021-06-28 08:29:46 --> Output Class Initialized
INFO - 2021-06-28 08:29:46 --> Security Class Initialized
DEBUG - 2021-06-28 08:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:29:46 --> Input Class Initialized
INFO - 2021-06-28 08:29:46 --> Language Class Initialized
INFO - 2021-06-28 08:29:46 --> Language Class Initialized
INFO - 2021-06-28 08:29:46 --> Config Class Initialized
INFO - 2021-06-28 08:29:46 --> Loader Class Initialized
INFO - 2021-06-28 08:29:46 --> Helper loaded: url_helper
INFO - 2021-06-28 08:29:46 --> Helper loaded: file_helper
INFO - 2021-06-28 08:29:46 --> Helper loaded: form_helper
INFO - 2021-06-28 08:29:46 --> Helper loaded: my_helper
INFO - 2021-06-28 08:29:46 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:29:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:29:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:29:46 --> Controller Class Initialized
DEBUG - 2021-06-28 08:29:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-28 08:29:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:29:46 --> Final output sent to browser
DEBUG - 2021-06-28 08:29:46 --> Total execution time: 0.6701
INFO - 2021-06-28 08:29:48 --> Config Class Initialized
INFO - 2021-06-28 08:29:48 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:29:48 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:29:48 --> Utf8 Class Initialized
INFO - 2021-06-28 08:29:48 --> URI Class Initialized
DEBUG - 2021-06-28 08:29:48 --> No URI present. Default controller set.
INFO - 2021-06-28 08:29:48 --> Router Class Initialized
INFO - 2021-06-28 08:29:48 --> Output Class Initialized
INFO - 2021-06-28 08:29:48 --> Security Class Initialized
DEBUG - 2021-06-28 08:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:29:48 --> Input Class Initialized
INFO - 2021-06-28 08:29:48 --> Language Class Initialized
INFO - 2021-06-28 08:29:48 --> Language Class Initialized
INFO - 2021-06-28 08:29:48 --> Config Class Initialized
INFO - 2021-06-28 08:29:48 --> Loader Class Initialized
INFO - 2021-06-28 08:29:48 --> Helper loaded: url_helper
INFO - 2021-06-28 08:29:48 --> Helper loaded: file_helper
INFO - 2021-06-28 08:29:48 --> Helper loaded: form_helper
INFO - 2021-06-28 08:29:48 --> Helper loaded: my_helper
INFO - 2021-06-28 08:29:48 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:29:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:29:48 --> Controller Class Initialized
DEBUG - 2021-06-28 08:29:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-28 08:29:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:29:49 --> Final output sent to browser
DEBUG - 2021-06-28 08:29:49 --> Total execution time: 0.6169
INFO - 2021-06-28 08:29:49 --> Config Class Initialized
INFO - 2021-06-28 08:29:49 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:29:49 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:29:49 --> Utf8 Class Initialized
INFO - 2021-06-28 08:29:49 --> URI Class Initialized
INFO - 2021-06-28 08:29:49 --> Router Class Initialized
INFO - 2021-06-28 08:29:49 --> Output Class Initialized
INFO - 2021-06-28 08:29:49 --> Security Class Initialized
DEBUG - 2021-06-28 08:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:29:49 --> Input Class Initialized
INFO - 2021-06-28 08:29:49 --> Language Class Initialized
INFO - 2021-06-28 08:29:49 --> Language Class Initialized
INFO - 2021-06-28 08:29:49 --> Config Class Initialized
INFO - 2021-06-28 08:29:49 --> Loader Class Initialized
INFO - 2021-06-28 08:29:49 --> Helper loaded: url_helper
INFO - 2021-06-28 08:29:49 --> Helper loaded: file_helper
INFO - 2021-06-28 08:29:49 --> Helper loaded: form_helper
INFO - 2021-06-28 08:29:49 --> Helper loaded: my_helper
INFO - 2021-06-28 08:29:49 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:29:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:29:49 --> Controller Class Initialized
DEBUG - 2021-06-28 08:29:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2021-06-28 08:29:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:29:49 --> Final output sent to browser
DEBUG - 2021-06-28 08:29:49 --> Total execution time: 0.0402
INFO - 2021-06-28 08:29:49 --> Config Class Initialized
INFO - 2021-06-28 08:29:49 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:29:49 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:29:49 --> Utf8 Class Initialized
INFO - 2021-06-28 08:29:49 --> URI Class Initialized
INFO - 2021-06-28 08:29:49 --> Router Class Initialized
INFO - 2021-06-28 08:29:49 --> Output Class Initialized
INFO - 2021-06-28 08:29:49 --> Security Class Initialized
DEBUG - 2021-06-28 08:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:29:49 --> Input Class Initialized
INFO - 2021-06-28 08:29:49 --> Language Class Initialized
INFO - 2021-06-28 08:29:49 --> Language Class Initialized
INFO - 2021-06-28 08:29:49 --> Config Class Initialized
INFO - 2021-06-28 08:29:49 --> Loader Class Initialized
INFO - 2021-06-28 08:29:49 --> Helper loaded: url_helper
INFO - 2021-06-28 08:29:49 --> Helper loaded: file_helper
INFO - 2021-06-28 08:29:49 --> Helper loaded: form_helper
INFO - 2021-06-28 08:29:49 --> Helper loaded: my_helper
INFO - 2021-06-28 08:29:49 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:29:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:29:49 --> Controller Class Initialized
INFO - 2021-06-28 08:29:49 --> Config Class Initialized
INFO - 2021-06-28 08:29:49 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:29:49 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:29:49 --> Utf8 Class Initialized
INFO - 2021-06-28 08:29:49 --> URI Class Initialized
INFO - 2021-06-28 08:29:49 --> Router Class Initialized
INFO - 2021-06-28 08:29:49 --> Output Class Initialized
INFO - 2021-06-28 08:29:49 --> Security Class Initialized
DEBUG - 2021-06-28 08:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:29:49 --> Input Class Initialized
INFO - 2021-06-28 08:29:49 --> Language Class Initialized
INFO - 2021-06-28 08:29:49 --> Language Class Initialized
INFO - 2021-06-28 08:29:49 --> Config Class Initialized
INFO - 2021-06-28 08:29:49 --> Loader Class Initialized
INFO - 2021-06-28 08:29:49 --> Helper loaded: url_helper
INFO - 2021-06-28 08:29:49 --> Helper loaded: file_helper
INFO - 2021-06-28 08:29:49 --> Helper loaded: form_helper
INFO - 2021-06-28 08:29:49 --> Helper loaded: my_helper
INFO - 2021-06-28 08:29:49 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:29:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:29:49 --> Controller Class Initialized
DEBUG - 2021-06-28 08:29:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-06-28 08:29:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:29:49 --> Final output sent to browser
DEBUG - 2021-06-28 08:29:49 --> Total execution time: 0.0493
INFO - 2021-06-28 08:29:50 --> Config Class Initialized
INFO - 2021-06-28 08:29:50 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:29:50 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:29:50 --> Utf8 Class Initialized
INFO - 2021-06-28 08:29:50 --> URI Class Initialized
INFO - 2021-06-28 08:29:50 --> Router Class Initialized
INFO - 2021-06-28 08:29:50 --> Output Class Initialized
INFO - 2021-06-28 08:29:50 --> Security Class Initialized
DEBUG - 2021-06-28 08:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:29:50 --> Input Class Initialized
INFO - 2021-06-28 08:29:50 --> Language Class Initialized
INFO - 2021-06-28 08:29:50 --> Language Class Initialized
INFO - 2021-06-28 08:29:50 --> Config Class Initialized
INFO - 2021-06-28 08:29:50 --> Loader Class Initialized
INFO - 2021-06-28 08:29:50 --> Helper loaded: url_helper
INFO - 2021-06-28 08:29:50 --> Helper loaded: file_helper
INFO - 2021-06-28 08:29:50 --> Helper loaded: form_helper
INFO - 2021-06-28 08:29:50 --> Helper loaded: my_helper
INFO - 2021-06-28 08:29:50 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:29:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:29:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:29:50 --> Controller Class Initialized
INFO - 2021-06-28 08:29:51 --> Config Class Initialized
INFO - 2021-06-28 08:29:51 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:29:51 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:29:51 --> Utf8 Class Initialized
INFO - 2021-06-28 08:29:51 --> URI Class Initialized
INFO - 2021-06-28 08:29:51 --> Router Class Initialized
INFO - 2021-06-28 08:29:51 --> Output Class Initialized
INFO - 2021-06-28 08:29:51 --> Security Class Initialized
DEBUG - 2021-06-28 08:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:29:51 --> Input Class Initialized
INFO - 2021-06-28 08:29:51 --> Language Class Initialized
INFO - 2021-06-28 08:29:51 --> Language Class Initialized
INFO - 2021-06-28 08:29:51 --> Config Class Initialized
INFO - 2021-06-28 08:29:51 --> Loader Class Initialized
INFO - 2021-06-28 08:29:51 --> Helper loaded: url_helper
INFO - 2021-06-28 08:29:51 --> Helper loaded: file_helper
INFO - 2021-06-28 08:29:51 --> Helper loaded: form_helper
INFO - 2021-06-28 08:29:51 --> Helper loaded: my_helper
INFO - 2021-06-28 08:29:51 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:29:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:29:51 --> Controller Class Initialized
ERROR - 2021-06-28 08:29:51 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 241
DEBUG - 2021-06-28 08:29:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-06-28 08:29:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:29:51 --> Final output sent to browser
DEBUG - 2021-06-28 08:29:51 --> Total execution time: 0.0551
INFO - 2021-06-28 08:39:07 --> Config Class Initialized
INFO - 2021-06-28 08:39:07 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:39:07 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:39:07 --> Utf8 Class Initialized
INFO - 2021-06-28 08:39:07 --> URI Class Initialized
INFO - 2021-06-28 08:39:07 --> Router Class Initialized
INFO - 2021-06-28 08:39:07 --> Output Class Initialized
INFO - 2021-06-28 08:39:07 --> Security Class Initialized
DEBUG - 2021-06-28 08:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:39:07 --> Input Class Initialized
INFO - 2021-06-28 08:39:07 --> Language Class Initialized
INFO - 2021-06-28 08:39:07 --> Language Class Initialized
INFO - 2021-06-28 08:39:07 --> Config Class Initialized
INFO - 2021-06-28 08:39:07 --> Loader Class Initialized
INFO - 2021-06-28 08:39:07 --> Helper loaded: url_helper
INFO - 2021-06-28 08:39:07 --> Helper loaded: file_helper
INFO - 2021-06-28 08:39:07 --> Helper loaded: form_helper
INFO - 2021-06-28 08:39:07 --> Helper loaded: my_helper
INFO - 2021-06-28 08:39:07 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:39:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:39:07 --> Controller Class Initialized
DEBUG - 2021-06-28 08:39:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-06-28 08:39:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:39:07 --> Final output sent to browser
DEBUG - 2021-06-28 08:39:07 --> Total execution time: 0.0416
INFO - 2021-06-28 08:39:07 --> Config Class Initialized
INFO - 2021-06-28 08:39:07 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:39:07 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:39:07 --> Utf8 Class Initialized
INFO - 2021-06-28 08:39:07 --> URI Class Initialized
INFO - 2021-06-28 08:39:07 --> Router Class Initialized
INFO - 2021-06-28 08:39:07 --> Output Class Initialized
INFO - 2021-06-28 08:39:07 --> Security Class Initialized
DEBUG - 2021-06-28 08:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:39:07 --> Input Class Initialized
INFO - 2021-06-28 08:39:07 --> Language Class Initialized
INFO - 2021-06-28 08:39:07 --> Language Class Initialized
INFO - 2021-06-28 08:39:07 --> Config Class Initialized
INFO - 2021-06-28 08:39:07 --> Loader Class Initialized
INFO - 2021-06-28 08:39:07 --> Helper loaded: url_helper
INFO - 2021-06-28 08:39:07 --> Helper loaded: file_helper
INFO - 2021-06-28 08:39:07 --> Helper loaded: form_helper
INFO - 2021-06-28 08:39:07 --> Helper loaded: my_helper
INFO - 2021-06-28 08:39:07 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:39:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:39:07 --> Controller Class Initialized
INFO - 2021-06-28 08:39:09 --> Config Class Initialized
INFO - 2021-06-28 08:39:09 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:39:09 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:39:09 --> Utf8 Class Initialized
INFO - 2021-06-28 08:39:09 --> URI Class Initialized
INFO - 2021-06-28 08:39:09 --> Router Class Initialized
INFO - 2021-06-28 08:39:09 --> Output Class Initialized
INFO - 2021-06-28 08:39:09 --> Security Class Initialized
DEBUG - 2021-06-28 08:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:39:09 --> Input Class Initialized
INFO - 2021-06-28 08:39:09 --> Language Class Initialized
INFO - 2021-06-28 08:39:09 --> Language Class Initialized
INFO - 2021-06-28 08:39:09 --> Config Class Initialized
INFO - 2021-06-28 08:39:09 --> Loader Class Initialized
INFO - 2021-06-28 08:39:09 --> Helper loaded: url_helper
INFO - 2021-06-28 08:39:09 --> Helper loaded: file_helper
INFO - 2021-06-28 08:39:09 --> Helper loaded: form_helper
INFO - 2021-06-28 08:39:09 --> Helper loaded: my_helper
INFO - 2021-06-28 08:39:09 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:39:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:39:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:39:09 --> Controller Class Initialized
ERROR - 2021-06-28 08:39:09 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 261
DEBUG - 2021-06-28 08:39:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-06-28 08:39:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:39:09 --> Final output sent to browser
DEBUG - 2021-06-28 08:39:09 --> Total execution time: 0.0534
INFO - 2021-06-28 08:43:35 --> Config Class Initialized
INFO - 2021-06-28 08:43:35 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:43:35 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:43:35 --> Utf8 Class Initialized
INFO - 2021-06-28 08:43:35 --> URI Class Initialized
INFO - 2021-06-28 08:43:35 --> Router Class Initialized
INFO - 2021-06-28 08:43:35 --> Output Class Initialized
INFO - 2021-06-28 08:43:35 --> Security Class Initialized
DEBUG - 2021-06-28 08:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:43:35 --> Input Class Initialized
INFO - 2021-06-28 08:43:35 --> Language Class Initialized
INFO - 2021-06-28 08:43:35 --> Language Class Initialized
INFO - 2021-06-28 08:43:35 --> Config Class Initialized
INFO - 2021-06-28 08:43:35 --> Loader Class Initialized
INFO - 2021-06-28 08:43:35 --> Helper loaded: url_helper
INFO - 2021-06-28 08:43:35 --> Helper loaded: file_helper
INFO - 2021-06-28 08:43:35 --> Helper loaded: form_helper
INFO - 2021-06-28 08:43:35 --> Helper loaded: my_helper
INFO - 2021-06-28 08:43:35 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:43:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:43:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:43:35 --> Controller Class Initialized
ERROR - 2021-06-28 08:43:35 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 261
DEBUG - 2021-06-28 08:43:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-06-28 08:43:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:43:35 --> Final output sent to browser
DEBUG - 2021-06-28 08:43:35 --> Total execution time: 0.0536
INFO - 2021-06-28 08:43:46 --> Config Class Initialized
INFO - 2021-06-28 08:43:46 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:43:46 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:43:46 --> Utf8 Class Initialized
INFO - 2021-06-28 08:43:46 --> URI Class Initialized
INFO - 2021-06-28 08:43:46 --> Router Class Initialized
INFO - 2021-06-28 08:43:46 --> Output Class Initialized
INFO - 2021-06-28 08:43:46 --> Security Class Initialized
DEBUG - 2021-06-28 08:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:43:46 --> Input Class Initialized
INFO - 2021-06-28 08:43:46 --> Language Class Initialized
INFO - 2021-06-28 08:43:46 --> Language Class Initialized
INFO - 2021-06-28 08:43:46 --> Config Class Initialized
INFO - 2021-06-28 08:43:46 --> Loader Class Initialized
INFO - 2021-06-28 08:43:46 --> Helper loaded: url_helper
INFO - 2021-06-28 08:43:46 --> Helper loaded: file_helper
INFO - 2021-06-28 08:43:46 --> Helper loaded: form_helper
INFO - 2021-06-28 08:43:46 --> Helper loaded: my_helper
INFO - 2021-06-28 08:43:46 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:43:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:43:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:43:46 --> Controller Class Initialized
ERROR - 2021-06-28 08:43:46 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 261
DEBUG - 2021-06-28 08:43:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-06-28 08:43:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:43:46 --> Final output sent to browser
DEBUG - 2021-06-28 08:43:46 --> Total execution time: 0.0532
INFO - 2021-06-28 08:44:09 --> Config Class Initialized
INFO - 2021-06-28 08:44:09 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:44:09 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:44:09 --> Utf8 Class Initialized
INFO - 2021-06-28 08:44:09 --> URI Class Initialized
INFO - 2021-06-28 08:44:09 --> Router Class Initialized
INFO - 2021-06-28 08:44:09 --> Output Class Initialized
INFO - 2021-06-28 08:44:09 --> Security Class Initialized
DEBUG - 2021-06-28 08:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:44:09 --> Input Class Initialized
INFO - 2021-06-28 08:44:09 --> Language Class Initialized
INFO - 2021-06-28 08:44:09 --> Language Class Initialized
INFO - 2021-06-28 08:44:09 --> Config Class Initialized
INFO - 2021-06-28 08:44:09 --> Loader Class Initialized
INFO - 2021-06-28 08:44:09 --> Helper loaded: url_helper
INFO - 2021-06-28 08:44:09 --> Helper loaded: file_helper
INFO - 2021-06-28 08:44:09 --> Helper loaded: form_helper
INFO - 2021-06-28 08:44:09 --> Helper loaded: my_helper
INFO - 2021-06-28 08:44:09 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:44:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:44:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:44:09 --> Controller Class Initialized
ERROR - 2021-06-28 08:44:09 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 261
DEBUG - 2021-06-28 08:44:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-06-28 08:44:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:44:09 --> Final output sent to browser
DEBUG - 2021-06-28 08:44:09 --> Total execution time: 0.0436
INFO - 2021-06-28 08:45:48 --> Config Class Initialized
INFO - 2021-06-28 08:45:48 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:45:48 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:45:48 --> Utf8 Class Initialized
INFO - 2021-06-28 08:45:48 --> URI Class Initialized
INFO - 2021-06-28 08:45:48 --> Router Class Initialized
INFO - 2021-06-28 08:45:48 --> Output Class Initialized
INFO - 2021-06-28 08:45:48 --> Security Class Initialized
DEBUG - 2021-06-28 08:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:45:48 --> Input Class Initialized
INFO - 2021-06-28 08:45:48 --> Language Class Initialized
INFO - 2021-06-28 08:45:48 --> Language Class Initialized
INFO - 2021-06-28 08:45:48 --> Config Class Initialized
INFO - 2021-06-28 08:45:48 --> Loader Class Initialized
INFO - 2021-06-28 08:45:48 --> Helper loaded: url_helper
INFO - 2021-06-28 08:45:48 --> Helper loaded: file_helper
INFO - 2021-06-28 08:45:48 --> Helper loaded: form_helper
INFO - 2021-06-28 08:45:48 --> Helper loaded: my_helper
INFO - 2021-06-28 08:45:48 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:45:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:45:48 --> Controller Class Initialized
ERROR - 2021-06-28 08:45:48 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 261
DEBUG - 2021-06-28 08:45:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-06-28 08:45:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:45:48 --> Final output sent to browser
DEBUG - 2021-06-28 08:45:48 --> Total execution time: 0.0536
INFO - 2021-06-28 08:46:16 --> Config Class Initialized
INFO - 2021-06-28 08:46:16 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:46:16 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:46:16 --> Utf8 Class Initialized
INFO - 2021-06-28 08:46:16 --> URI Class Initialized
INFO - 2021-06-28 08:46:16 --> Router Class Initialized
INFO - 2021-06-28 08:46:17 --> Output Class Initialized
INFO - 2021-06-28 08:46:17 --> Security Class Initialized
DEBUG - 2021-06-28 08:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:46:17 --> Input Class Initialized
INFO - 2021-06-28 08:46:17 --> Language Class Initialized
INFO - 2021-06-28 08:46:17 --> Language Class Initialized
INFO - 2021-06-28 08:46:17 --> Config Class Initialized
INFO - 2021-06-28 08:46:17 --> Loader Class Initialized
INFO - 2021-06-28 08:46:17 --> Helper loaded: url_helper
INFO - 2021-06-28 08:46:17 --> Helper loaded: file_helper
INFO - 2021-06-28 08:46:17 --> Helper loaded: form_helper
INFO - 2021-06-28 08:46:17 --> Helper loaded: my_helper
INFO - 2021-06-28 08:46:17 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:46:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:46:17 --> Controller Class Initialized
ERROR - 2021-06-28 08:46:17 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 261
DEBUG - 2021-06-28 08:46:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-06-28 08:46:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:46:17 --> Final output sent to browser
DEBUG - 2021-06-28 08:46:17 --> Total execution time: 0.0530
INFO - 2021-06-28 08:47:02 --> Config Class Initialized
INFO - 2021-06-28 08:47:02 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:47:02 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:47:02 --> Utf8 Class Initialized
INFO - 2021-06-28 08:47:02 --> URI Class Initialized
INFO - 2021-06-28 08:47:02 --> Router Class Initialized
INFO - 2021-06-28 08:47:02 --> Output Class Initialized
INFO - 2021-06-28 08:47:02 --> Security Class Initialized
DEBUG - 2021-06-28 08:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:47:02 --> Input Class Initialized
INFO - 2021-06-28 08:47:02 --> Language Class Initialized
INFO - 2021-06-28 08:47:02 --> Language Class Initialized
INFO - 2021-06-28 08:47:02 --> Config Class Initialized
INFO - 2021-06-28 08:47:02 --> Loader Class Initialized
INFO - 2021-06-28 08:47:02 --> Helper loaded: url_helper
INFO - 2021-06-28 08:47:02 --> Helper loaded: file_helper
INFO - 2021-06-28 08:47:02 --> Helper loaded: form_helper
INFO - 2021-06-28 08:47:02 --> Helper loaded: my_helper
INFO - 2021-06-28 08:47:02 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:47:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:47:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:47:02 --> Controller Class Initialized
ERROR - 2021-06-28 08:47:02 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 262
DEBUG - 2021-06-28 08:47:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-06-28 08:47:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:47:02 --> Final output sent to browser
DEBUG - 2021-06-28 08:47:02 --> Total execution time: 0.0443
INFO - 2021-06-28 08:47:03 --> Config Class Initialized
INFO - 2021-06-28 08:47:03 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:47:03 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:47:03 --> Utf8 Class Initialized
INFO - 2021-06-28 08:47:03 --> URI Class Initialized
INFO - 2021-06-28 08:47:03 --> Router Class Initialized
INFO - 2021-06-28 08:47:03 --> Output Class Initialized
INFO - 2021-06-28 08:47:03 --> Security Class Initialized
DEBUG - 2021-06-28 08:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:47:03 --> Input Class Initialized
INFO - 2021-06-28 08:47:03 --> Language Class Initialized
INFO - 2021-06-28 08:47:03 --> Language Class Initialized
INFO - 2021-06-28 08:47:03 --> Config Class Initialized
INFO - 2021-06-28 08:47:03 --> Loader Class Initialized
INFO - 2021-06-28 08:47:03 --> Helper loaded: url_helper
INFO - 2021-06-28 08:47:03 --> Helper loaded: file_helper
INFO - 2021-06-28 08:47:03 --> Helper loaded: form_helper
INFO - 2021-06-28 08:47:03 --> Helper loaded: my_helper
INFO - 2021-06-28 08:47:03 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:47:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:47:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:47:03 --> Controller Class Initialized
ERROR - 2021-06-28 08:47:03 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 262
DEBUG - 2021-06-28 08:47:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-06-28 08:47:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:47:03 --> Final output sent to browser
DEBUG - 2021-06-28 08:47:03 --> Total execution time: 0.0437
INFO - 2021-06-28 08:56:09 --> Config Class Initialized
INFO - 2021-06-28 08:56:09 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:56:09 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:56:09 --> Utf8 Class Initialized
INFO - 2021-06-28 08:56:09 --> URI Class Initialized
INFO - 2021-06-28 08:56:09 --> Router Class Initialized
INFO - 2021-06-28 08:56:09 --> Output Class Initialized
INFO - 2021-06-28 08:56:09 --> Security Class Initialized
DEBUG - 2021-06-28 08:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:56:09 --> Input Class Initialized
INFO - 2021-06-28 08:56:09 --> Language Class Initialized
INFO - 2021-06-28 08:56:09 --> Language Class Initialized
INFO - 2021-06-28 08:56:09 --> Config Class Initialized
INFO - 2021-06-28 08:56:09 --> Loader Class Initialized
INFO - 2021-06-28 08:56:09 --> Helper loaded: url_helper
INFO - 2021-06-28 08:56:09 --> Helper loaded: file_helper
INFO - 2021-06-28 08:56:09 --> Helper loaded: form_helper
INFO - 2021-06-28 08:56:09 --> Helper loaded: my_helper
INFO - 2021-06-28 08:56:09 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:56:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:56:09 --> Controller Class Initialized
ERROR - 2021-06-28 08:56:09 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 261
DEBUG - 2021-06-28 08:56:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-06-28 08:56:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:56:09 --> Final output sent to browser
DEBUG - 2021-06-28 08:56:09 --> Total execution time: 0.0467
INFO - 2021-06-28 08:56:45 --> Config Class Initialized
INFO - 2021-06-28 08:56:45 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:56:45 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:56:45 --> Utf8 Class Initialized
INFO - 2021-06-28 08:56:45 --> URI Class Initialized
INFO - 2021-06-28 08:56:45 --> Router Class Initialized
INFO - 2021-06-28 08:56:45 --> Output Class Initialized
INFO - 2021-06-28 08:56:45 --> Security Class Initialized
DEBUG - 2021-06-28 08:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:56:45 --> Input Class Initialized
INFO - 2021-06-28 08:56:45 --> Language Class Initialized
INFO - 2021-06-28 08:56:45 --> Language Class Initialized
INFO - 2021-06-28 08:56:45 --> Config Class Initialized
INFO - 2021-06-28 08:56:45 --> Loader Class Initialized
INFO - 2021-06-28 08:56:45 --> Helper loaded: url_helper
INFO - 2021-06-28 08:56:45 --> Helper loaded: file_helper
INFO - 2021-06-28 08:56:45 --> Helper loaded: form_helper
INFO - 2021-06-28 08:56:45 --> Helper loaded: my_helper
INFO - 2021-06-28 08:56:45 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:56:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:56:45 --> Controller Class Initialized
ERROR - 2021-06-28 08:56:45 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 261
DEBUG - 2021-06-28 08:56:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-06-28 08:56:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:56:45 --> Final output sent to browser
DEBUG - 2021-06-28 08:56:45 --> Total execution time: 0.0528
INFO - 2021-06-28 08:56:54 --> Config Class Initialized
INFO - 2021-06-28 08:56:54 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:56:54 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:56:54 --> Utf8 Class Initialized
INFO - 2021-06-28 08:56:54 --> URI Class Initialized
INFO - 2021-06-28 08:56:54 --> Router Class Initialized
INFO - 2021-06-28 08:56:54 --> Output Class Initialized
INFO - 2021-06-28 08:56:54 --> Security Class Initialized
DEBUG - 2021-06-28 08:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:56:54 --> Input Class Initialized
INFO - 2021-06-28 08:56:54 --> Language Class Initialized
INFO - 2021-06-28 08:56:54 --> Language Class Initialized
INFO - 2021-06-28 08:56:54 --> Config Class Initialized
INFO - 2021-06-28 08:56:54 --> Loader Class Initialized
INFO - 2021-06-28 08:56:54 --> Helper loaded: url_helper
INFO - 2021-06-28 08:56:54 --> Helper loaded: file_helper
INFO - 2021-06-28 08:56:54 --> Helper loaded: form_helper
INFO - 2021-06-28 08:56:54 --> Helper loaded: my_helper
INFO - 2021-06-28 08:56:54 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:56:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:56:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:56:54 --> Controller Class Initialized
ERROR - 2021-06-28 08:56:54 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 261
DEBUG - 2021-06-28 08:56:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-06-28 08:56:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:56:54 --> Final output sent to browser
DEBUG - 2021-06-28 08:56:54 --> Total execution time: 0.0431
INFO - 2021-06-28 08:57:52 --> Config Class Initialized
INFO - 2021-06-28 08:57:52 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:57:52 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:57:52 --> Utf8 Class Initialized
INFO - 2021-06-28 08:57:52 --> URI Class Initialized
INFO - 2021-06-28 08:57:52 --> Router Class Initialized
INFO - 2021-06-28 08:57:52 --> Output Class Initialized
INFO - 2021-06-28 08:57:52 --> Security Class Initialized
DEBUG - 2021-06-28 08:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:57:52 --> Input Class Initialized
INFO - 2021-06-28 08:57:52 --> Language Class Initialized
INFO - 2021-06-28 08:57:52 --> Language Class Initialized
INFO - 2021-06-28 08:57:52 --> Config Class Initialized
INFO - 2021-06-28 08:57:52 --> Loader Class Initialized
INFO - 2021-06-28 08:57:52 --> Helper loaded: url_helper
INFO - 2021-06-28 08:57:52 --> Helper loaded: file_helper
INFO - 2021-06-28 08:57:52 --> Helper loaded: form_helper
INFO - 2021-06-28 08:57:52 --> Helper loaded: my_helper
INFO - 2021-06-28 08:57:52 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:57:52 --> Controller Class Initialized
ERROR - 2021-06-28 08:57:52 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 260
DEBUG - 2021-06-28 08:57:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-06-28 08:57:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:57:52 --> Final output sent to browser
DEBUG - 2021-06-28 08:57:52 --> Total execution time: 0.0443
INFO - 2021-06-28 08:58:27 --> Config Class Initialized
INFO - 2021-06-28 08:58:27 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:58:27 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:58:27 --> Utf8 Class Initialized
INFO - 2021-06-28 08:58:27 --> URI Class Initialized
INFO - 2021-06-28 08:58:27 --> Router Class Initialized
INFO - 2021-06-28 08:58:27 --> Output Class Initialized
INFO - 2021-06-28 08:58:27 --> Security Class Initialized
DEBUG - 2021-06-28 08:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:58:27 --> Input Class Initialized
INFO - 2021-06-28 08:58:27 --> Language Class Initialized
INFO - 2021-06-28 08:58:27 --> Language Class Initialized
INFO - 2021-06-28 08:58:27 --> Config Class Initialized
INFO - 2021-06-28 08:58:27 --> Loader Class Initialized
INFO - 2021-06-28 08:58:27 --> Helper loaded: url_helper
INFO - 2021-06-28 08:58:27 --> Helper loaded: file_helper
INFO - 2021-06-28 08:58:27 --> Helper loaded: form_helper
INFO - 2021-06-28 08:58:28 --> Helper loaded: my_helper
INFO - 2021-06-28 08:58:28 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:58:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:58:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:58:28 --> Controller Class Initialized
ERROR - 2021-06-28 08:58:28 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 260
DEBUG - 2021-06-28 08:58:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-06-28 08:58:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:58:28 --> Final output sent to browser
DEBUG - 2021-06-28 08:58:28 --> Total execution time: 0.0534
INFO - 2021-06-28 08:59:04 --> Config Class Initialized
INFO - 2021-06-28 08:59:04 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:59:04 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:59:04 --> Utf8 Class Initialized
INFO - 2021-06-28 08:59:04 --> URI Class Initialized
INFO - 2021-06-28 08:59:05 --> Router Class Initialized
INFO - 2021-06-28 08:59:05 --> Output Class Initialized
INFO - 2021-06-28 08:59:05 --> Security Class Initialized
DEBUG - 2021-06-28 08:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:59:05 --> Input Class Initialized
INFO - 2021-06-28 08:59:05 --> Language Class Initialized
INFO - 2021-06-28 08:59:05 --> Language Class Initialized
INFO - 2021-06-28 08:59:05 --> Config Class Initialized
INFO - 2021-06-28 08:59:05 --> Loader Class Initialized
INFO - 2021-06-28 08:59:05 --> Helper loaded: url_helper
INFO - 2021-06-28 08:59:05 --> Helper loaded: file_helper
INFO - 2021-06-28 08:59:05 --> Helper loaded: form_helper
INFO - 2021-06-28 08:59:05 --> Helper loaded: my_helper
INFO - 2021-06-28 08:59:05 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:59:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:59:05 --> Controller Class Initialized
ERROR - 2021-06-28 08:59:05 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 260
DEBUG - 2021-06-28 08:59:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-06-28 08:59:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:59:05 --> Final output sent to browser
DEBUG - 2021-06-28 08:59:05 --> Total execution time: 0.0532
INFO - 2021-06-28 08:59:52 --> Config Class Initialized
INFO - 2021-06-28 08:59:52 --> Hooks Class Initialized
DEBUG - 2021-06-28 08:59:52 --> UTF-8 Support Enabled
INFO - 2021-06-28 08:59:52 --> Utf8 Class Initialized
INFO - 2021-06-28 08:59:52 --> URI Class Initialized
INFO - 2021-06-28 08:59:52 --> Router Class Initialized
INFO - 2021-06-28 08:59:52 --> Output Class Initialized
INFO - 2021-06-28 08:59:52 --> Security Class Initialized
DEBUG - 2021-06-28 08:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 08:59:52 --> Input Class Initialized
INFO - 2021-06-28 08:59:52 --> Language Class Initialized
INFO - 2021-06-28 08:59:52 --> Language Class Initialized
INFO - 2021-06-28 08:59:52 --> Config Class Initialized
INFO - 2021-06-28 08:59:52 --> Loader Class Initialized
INFO - 2021-06-28 08:59:52 --> Helper loaded: url_helper
INFO - 2021-06-28 08:59:52 --> Helper loaded: file_helper
INFO - 2021-06-28 08:59:52 --> Helper loaded: form_helper
INFO - 2021-06-28 08:59:52 --> Helper loaded: my_helper
INFO - 2021-06-28 08:59:52 --> Database Driver Class Initialized
DEBUG - 2021-06-28 08:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 08:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 08:59:52 --> Controller Class Initialized
ERROR - 2021-06-28 08:59:52 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 260
DEBUG - 2021-06-28 08:59:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-06-28 08:59:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 08:59:52 --> Final output sent to browser
DEBUG - 2021-06-28 08:59:52 --> Total execution time: 0.0536
INFO - 2021-06-28 09:00:28 --> Config Class Initialized
INFO - 2021-06-28 09:00:28 --> Hooks Class Initialized
DEBUG - 2021-06-28 09:00:28 --> UTF-8 Support Enabled
INFO - 2021-06-28 09:00:28 --> Utf8 Class Initialized
INFO - 2021-06-28 09:00:28 --> URI Class Initialized
INFO - 2021-06-28 09:00:28 --> Router Class Initialized
INFO - 2021-06-28 09:00:28 --> Output Class Initialized
INFO - 2021-06-28 09:00:28 --> Security Class Initialized
DEBUG - 2021-06-28 09:00:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 09:00:28 --> Input Class Initialized
INFO - 2021-06-28 09:00:28 --> Language Class Initialized
INFO - 2021-06-28 09:00:28 --> Language Class Initialized
INFO - 2021-06-28 09:00:28 --> Config Class Initialized
INFO - 2021-06-28 09:00:28 --> Loader Class Initialized
INFO - 2021-06-28 09:00:28 --> Helper loaded: url_helper
INFO - 2021-06-28 09:00:28 --> Helper loaded: file_helper
INFO - 2021-06-28 09:00:28 --> Helper loaded: form_helper
INFO - 2021-06-28 09:00:28 --> Helper loaded: my_helper
INFO - 2021-06-28 09:00:28 --> Database Driver Class Initialized
DEBUG - 2021-06-28 09:00:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 09:00:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 09:00:28 --> Controller Class Initialized
ERROR - 2021-06-28 09:00:28 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2021-06-28 09:00:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-06-28 09:00:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 09:00:28 --> Final output sent to browser
DEBUG - 2021-06-28 09:00:28 --> Total execution time: 0.0442
INFO - 2021-06-28 09:01:23 --> Config Class Initialized
INFO - 2021-06-28 09:01:23 --> Hooks Class Initialized
DEBUG - 2021-06-28 09:01:23 --> UTF-8 Support Enabled
INFO - 2021-06-28 09:01:23 --> Utf8 Class Initialized
INFO - 2021-06-28 09:01:23 --> URI Class Initialized
INFO - 2021-06-28 09:01:23 --> Router Class Initialized
INFO - 2021-06-28 09:01:23 --> Output Class Initialized
INFO - 2021-06-28 09:01:23 --> Security Class Initialized
DEBUG - 2021-06-28 09:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 09:01:23 --> Input Class Initialized
INFO - 2021-06-28 09:01:23 --> Language Class Initialized
INFO - 2021-06-28 09:01:23 --> Language Class Initialized
INFO - 2021-06-28 09:01:23 --> Config Class Initialized
INFO - 2021-06-28 09:01:23 --> Loader Class Initialized
INFO - 2021-06-28 09:01:23 --> Helper loaded: url_helper
INFO - 2021-06-28 09:01:23 --> Helper loaded: file_helper
INFO - 2021-06-28 09:01:23 --> Helper loaded: form_helper
INFO - 2021-06-28 09:01:23 --> Helper loaded: my_helper
INFO - 2021-06-28 09:01:23 --> Database Driver Class Initialized
DEBUG - 2021-06-28 09:01:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 09:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 09:01:23 --> Controller Class Initialized
ERROR - 2021-06-28 09:01:23 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2021-06-28 09:01:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-06-28 09:01:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 09:01:23 --> Final output sent to browser
DEBUG - 2021-06-28 09:01:23 --> Total execution time: 0.0541
INFO - 2021-06-28 09:01:32 --> Config Class Initialized
INFO - 2021-06-28 09:01:32 --> Hooks Class Initialized
DEBUG - 2021-06-28 09:01:32 --> UTF-8 Support Enabled
INFO - 2021-06-28 09:01:32 --> Utf8 Class Initialized
INFO - 2021-06-28 09:01:32 --> URI Class Initialized
INFO - 2021-06-28 09:01:32 --> Router Class Initialized
INFO - 2021-06-28 09:01:32 --> Output Class Initialized
INFO - 2021-06-28 09:01:32 --> Security Class Initialized
DEBUG - 2021-06-28 09:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 09:01:32 --> Input Class Initialized
INFO - 2021-06-28 09:01:32 --> Language Class Initialized
INFO - 2021-06-28 09:01:32 --> Language Class Initialized
INFO - 2021-06-28 09:01:32 --> Config Class Initialized
INFO - 2021-06-28 09:01:32 --> Loader Class Initialized
INFO - 2021-06-28 09:01:32 --> Helper loaded: url_helper
INFO - 2021-06-28 09:01:32 --> Helper loaded: file_helper
INFO - 2021-06-28 09:01:32 --> Helper loaded: form_helper
INFO - 2021-06-28 09:01:32 --> Helper loaded: my_helper
INFO - 2021-06-28 09:01:32 --> Database Driver Class Initialized
DEBUG - 2021-06-28 09:01:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 09:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 09:01:32 --> Controller Class Initialized
ERROR - 2021-06-28 09:01:32 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2021-06-28 09:01:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-06-28 09:01:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 09:01:32 --> Final output sent to browser
DEBUG - 2021-06-28 09:01:32 --> Total execution time: 0.0440
INFO - 2021-06-28 09:46:19 --> Config Class Initialized
INFO - 2021-06-28 09:46:19 --> Hooks Class Initialized
DEBUG - 2021-06-28 09:46:19 --> UTF-8 Support Enabled
INFO - 2021-06-28 09:46:19 --> Utf8 Class Initialized
INFO - 2021-06-28 09:46:19 --> URI Class Initialized
INFO - 2021-06-28 09:46:19 --> Router Class Initialized
INFO - 2021-06-28 09:46:19 --> Output Class Initialized
INFO - 2021-06-28 09:46:19 --> Security Class Initialized
DEBUG - 2021-06-28 09:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 09:46:19 --> Input Class Initialized
INFO - 2021-06-28 09:46:19 --> Language Class Initialized
INFO - 2021-06-28 09:46:19 --> Language Class Initialized
INFO - 2021-06-28 09:46:19 --> Config Class Initialized
INFO - 2021-06-28 09:46:19 --> Loader Class Initialized
INFO - 2021-06-28 09:46:19 --> Helper loaded: url_helper
INFO - 2021-06-28 09:46:19 --> Helper loaded: file_helper
INFO - 2021-06-28 09:46:19 --> Helper loaded: form_helper
INFO - 2021-06-28 09:46:19 --> Helper loaded: my_helper
INFO - 2021-06-28 09:46:19 --> Database Driver Class Initialized
DEBUG - 2021-06-28 09:46:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 09:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 09:46:19 --> Controller Class Initialized
DEBUG - 2021-06-28 09:46:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-28 09:46:19 --> Final output sent to browser
DEBUG - 2021-06-28 09:46:19 --> Total execution time: 0.0496
INFO - 2021-06-28 09:54:41 --> Config Class Initialized
INFO - 2021-06-28 09:54:41 --> Hooks Class Initialized
DEBUG - 2021-06-28 09:54:41 --> UTF-8 Support Enabled
INFO - 2021-06-28 09:54:41 --> Utf8 Class Initialized
INFO - 2021-06-28 09:54:41 --> URI Class Initialized
INFO - 2021-06-28 09:54:41 --> Router Class Initialized
INFO - 2021-06-28 09:54:41 --> Output Class Initialized
INFO - 2021-06-28 09:54:41 --> Security Class Initialized
DEBUG - 2021-06-28 09:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 09:54:41 --> Input Class Initialized
INFO - 2021-06-28 09:54:41 --> Language Class Initialized
INFO - 2021-06-28 09:54:41 --> Language Class Initialized
INFO - 2021-06-28 09:54:41 --> Config Class Initialized
INFO - 2021-06-28 09:54:41 --> Loader Class Initialized
INFO - 2021-06-28 09:54:41 --> Helper loaded: url_helper
INFO - 2021-06-28 09:54:41 --> Helper loaded: file_helper
INFO - 2021-06-28 09:54:41 --> Helper loaded: form_helper
INFO - 2021-06-28 09:54:41 --> Helper loaded: my_helper
INFO - 2021-06-28 09:54:41 --> Database Driver Class Initialized
DEBUG - 2021-06-28 09:54:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 09:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 09:54:41 --> Controller Class Initialized
INFO - 2021-06-28 09:54:41 --> Helper loaded: cookie_helper
INFO - 2021-06-28 09:54:41 --> Config Class Initialized
INFO - 2021-06-28 09:54:41 --> Hooks Class Initialized
DEBUG - 2021-06-28 09:54:41 --> UTF-8 Support Enabled
INFO - 2021-06-28 09:54:41 --> Utf8 Class Initialized
INFO - 2021-06-28 09:54:41 --> URI Class Initialized
INFO - 2021-06-28 09:54:41 --> Router Class Initialized
INFO - 2021-06-28 09:54:41 --> Output Class Initialized
INFO - 2021-06-28 09:54:41 --> Security Class Initialized
DEBUG - 2021-06-28 09:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 09:54:41 --> Input Class Initialized
INFO - 2021-06-28 09:54:41 --> Language Class Initialized
INFO - 2021-06-28 09:54:41 --> Language Class Initialized
INFO - 2021-06-28 09:54:41 --> Config Class Initialized
INFO - 2021-06-28 09:54:41 --> Loader Class Initialized
INFO - 2021-06-28 09:54:41 --> Helper loaded: url_helper
INFO - 2021-06-28 09:54:41 --> Helper loaded: file_helper
INFO - 2021-06-28 09:54:41 --> Helper loaded: form_helper
INFO - 2021-06-28 09:54:41 --> Helper loaded: my_helper
INFO - 2021-06-28 09:54:41 --> Database Driver Class Initialized
DEBUG - 2021-06-28 09:54:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 09:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 09:54:42 --> Controller Class Initialized
DEBUG - 2021-06-28 09:54:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-28 09:54:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 09:54:42 --> Final output sent to browser
DEBUG - 2021-06-28 09:54:42 --> Total execution time: 0.0415
INFO - 2021-06-28 09:54:46 --> Config Class Initialized
INFO - 2021-06-28 09:54:46 --> Hooks Class Initialized
DEBUG - 2021-06-28 09:54:46 --> UTF-8 Support Enabled
INFO - 2021-06-28 09:54:46 --> Utf8 Class Initialized
INFO - 2021-06-28 09:54:46 --> URI Class Initialized
INFO - 2021-06-28 09:54:46 --> Router Class Initialized
INFO - 2021-06-28 09:54:46 --> Output Class Initialized
INFO - 2021-06-28 09:54:46 --> Security Class Initialized
DEBUG - 2021-06-28 09:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 09:54:46 --> Input Class Initialized
INFO - 2021-06-28 09:54:46 --> Language Class Initialized
INFO - 2021-06-28 09:54:46 --> Language Class Initialized
INFO - 2021-06-28 09:54:46 --> Config Class Initialized
INFO - 2021-06-28 09:54:46 --> Loader Class Initialized
INFO - 2021-06-28 09:54:46 --> Helper loaded: url_helper
INFO - 2021-06-28 09:54:46 --> Helper loaded: file_helper
INFO - 2021-06-28 09:54:46 --> Helper loaded: form_helper
INFO - 2021-06-28 09:54:46 --> Helper loaded: my_helper
INFO - 2021-06-28 09:54:46 --> Database Driver Class Initialized
DEBUG - 2021-06-28 09:54:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 09:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 09:54:46 --> Controller Class Initialized
INFO - 2021-06-28 09:54:46 --> Helper loaded: cookie_helper
INFO - 2021-06-28 09:54:46 --> Final output sent to browser
DEBUG - 2021-06-28 09:54:46 --> Total execution time: 0.0447
INFO - 2021-06-28 09:54:46 --> Config Class Initialized
INFO - 2021-06-28 09:54:46 --> Hooks Class Initialized
DEBUG - 2021-06-28 09:54:46 --> UTF-8 Support Enabled
INFO - 2021-06-28 09:54:46 --> Utf8 Class Initialized
INFO - 2021-06-28 09:54:46 --> URI Class Initialized
INFO - 2021-06-28 09:54:46 --> Router Class Initialized
INFO - 2021-06-28 09:54:46 --> Output Class Initialized
INFO - 2021-06-28 09:54:46 --> Security Class Initialized
DEBUG - 2021-06-28 09:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 09:54:46 --> Input Class Initialized
INFO - 2021-06-28 09:54:46 --> Language Class Initialized
INFO - 2021-06-28 09:54:46 --> Language Class Initialized
INFO - 2021-06-28 09:54:46 --> Config Class Initialized
INFO - 2021-06-28 09:54:46 --> Loader Class Initialized
INFO - 2021-06-28 09:54:46 --> Helper loaded: url_helper
INFO - 2021-06-28 09:54:46 --> Helper loaded: file_helper
INFO - 2021-06-28 09:54:46 --> Helper loaded: form_helper
INFO - 2021-06-28 09:54:46 --> Helper loaded: my_helper
INFO - 2021-06-28 09:54:46 --> Database Driver Class Initialized
DEBUG - 2021-06-28 09:54:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 09:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 09:54:46 --> Controller Class Initialized
DEBUG - 2021-06-28 09:54:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-28 09:54:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 09:54:47 --> Final output sent to browser
DEBUG - 2021-06-28 09:54:47 --> Total execution time: 0.6565
INFO - 2021-06-28 09:55:16 --> Config Class Initialized
INFO - 2021-06-28 09:55:16 --> Hooks Class Initialized
DEBUG - 2021-06-28 09:55:16 --> UTF-8 Support Enabled
INFO - 2021-06-28 09:55:16 --> Utf8 Class Initialized
INFO - 2021-06-28 09:55:16 --> URI Class Initialized
INFO - 2021-06-28 09:55:16 --> Router Class Initialized
INFO - 2021-06-28 09:55:16 --> Output Class Initialized
INFO - 2021-06-28 09:55:16 --> Security Class Initialized
DEBUG - 2021-06-28 09:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 09:55:16 --> Input Class Initialized
INFO - 2021-06-28 09:55:16 --> Language Class Initialized
INFO - 2021-06-28 09:55:16 --> Language Class Initialized
INFO - 2021-06-28 09:55:16 --> Config Class Initialized
INFO - 2021-06-28 09:55:16 --> Loader Class Initialized
INFO - 2021-06-28 09:55:16 --> Helper loaded: url_helper
INFO - 2021-06-28 09:55:16 --> Helper loaded: file_helper
INFO - 2021-06-28 09:55:16 --> Helper loaded: form_helper
INFO - 2021-06-28 09:55:16 --> Helper loaded: my_helper
INFO - 2021-06-28 09:55:16 --> Database Driver Class Initialized
DEBUG - 2021-06-28 09:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 09:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 09:55:16 --> Controller Class Initialized
DEBUG - 2021-06-28 09:55:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-06-28 09:55:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-28 09:55:16 --> Final output sent to browser
DEBUG - 2021-06-28 09:55:16 --> Total execution time: 0.0595
INFO - 2021-06-28 09:55:18 --> Config Class Initialized
INFO - 2021-06-28 09:55:18 --> Hooks Class Initialized
DEBUG - 2021-06-28 09:55:18 --> UTF-8 Support Enabled
INFO - 2021-06-28 09:55:18 --> Utf8 Class Initialized
INFO - 2021-06-28 09:55:18 --> URI Class Initialized
INFO - 2021-06-28 09:55:18 --> Router Class Initialized
INFO - 2021-06-28 09:55:18 --> Output Class Initialized
INFO - 2021-06-28 09:55:18 --> Security Class Initialized
DEBUG - 2021-06-28 09:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 09:55:18 --> Input Class Initialized
INFO - 2021-06-28 09:55:18 --> Language Class Initialized
INFO - 2021-06-28 09:55:18 --> Language Class Initialized
INFO - 2021-06-28 09:55:18 --> Config Class Initialized
INFO - 2021-06-28 09:55:18 --> Loader Class Initialized
INFO - 2021-06-28 09:55:18 --> Helper loaded: url_helper
INFO - 2021-06-28 09:55:18 --> Helper loaded: file_helper
INFO - 2021-06-28 09:55:18 --> Helper loaded: form_helper
INFO - 2021-06-28 09:55:18 --> Helper loaded: my_helper
INFO - 2021-06-28 09:55:18 --> Database Driver Class Initialized
DEBUG - 2021-06-28 09:55:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 09:55:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 09:55:18 --> Controller Class Initialized
DEBUG - 2021-06-28 09:55:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-28 09:55:18 --> Final output sent to browser
DEBUG - 2021-06-28 09:55:18 --> Total execution time: 0.0469
INFO - 2021-06-28 09:56:00 --> Config Class Initialized
INFO - 2021-06-28 09:56:00 --> Hooks Class Initialized
DEBUG - 2021-06-28 09:56:00 --> UTF-8 Support Enabled
INFO - 2021-06-28 09:56:00 --> Utf8 Class Initialized
INFO - 2021-06-28 09:56:00 --> URI Class Initialized
INFO - 2021-06-28 09:56:00 --> Router Class Initialized
INFO - 2021-06-28 09:56:00 --> Output Class Initialized
INFO - 2021-06-28 09:56:00 --> Security Class Initialized
DEBUG - 2021-06-28 09:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 09:56:00 --> Input Class Initialized
INFO - 2021-06-28 09:56:00 --> Language Class Initialized
INFO - 2021-06-28 09:56:00 --> Language Class Initialized
INFO - 2021-06-28 09:56:00 --> Config Class Initialized
INFO - 2021-06-28 09:56:00 --> Loader Class Initialized
INFO - 2021-06-28 09:56:00 --> Helper loaded: url_helper
INFO - 2021-06-28 09:56:00 --> Helper loaded: file_helper
INFO - 2021-06-28 09:56:00 --> Helper loaded: form_helper
INFO - 2021-06-28 09:56:00 --> Helper loaded: my_helper
INFO - 2021-06-28 09:56:00 --> Database Driver Class Initialized
DEBUG - 2021-06-28 09:56:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 09:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 09:56:00 --> Controller Class Initialized
DEBUG - 2021-06-28 09:56:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-28 09:56:00 --> Final output sent to browser
DEBUG - 2021-06-28 09:56:00 --> Total execution time: 0.0466
INFO - 2021-06-28 09:56:40 --> Config Class Initialized
INFO - 2021-06-28 09:56:40 --> Hooks Class Initialized
DEBUG - 2021-06-28 09:56:40 --> UTF-8 Support Enabled
INFO - 2021-06-28 09:56:40 --> Utf8 Class Initialized
INFO - 2021-06-28 09:56:40 --> URI Class Initialized
INFO - 2021-06-28 09:56:40 --> Router Class Initialized
INFO - 2021-06-28 09:56:40 --> Output Class Initialized
INFO - 2021-06-28 09:56:40 --> Security Class Initialized
DEBUG - 2021-06-28 09:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 09:56:40 --> Input Class Initialized
INFO - 2021-06-28 09:56:40 --> Language Class Initialized
INFO - 2021-06-28 09:56:40 --> Language Class Initialized
INFO - 2021-06-28 09:56:40 --> Config Class Initialized
INFO - 2021-06-28 09:56:40 --> Loader Class Initialized
INFO - 2021-06-28 09:56:40 --> Helper loaded: url_helper
INFO - 2021-06-28 09:56:40 --> Helper loaded: file_helper
INFO - 2021-06-28 09:56:40 --> Helper loaded: form_helper
INFO - 2021-06-28 09:56:40 --> Helper loaded: my_helper
INFO - 2021-06-28 09:56:40 --> Database Driver Class Initialized
DEBUG - 2021-06-28 09:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 09:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 09:56:40 --> Controller Class Initialized
DEBUG - 2021-06-28 09:56:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-28 09:56:40 --> Final output sent to browser
DEBUG - 2021-06-28 09:56:40 --> Total execution time: 0.0565
INFO - 2021-06-28 09:56:49 --> Config Class Initialized
INFO - 2021-06-28 09:56:49 --> Hooks Class Initialized
DEBUG - 2021-06-28 09:56:49 --> UTF-8 Support Enabled
INFO - 2021-06-28 09:56:49 --> Utf8 Class Initialized
INFO - 2021-06-28 09:56:49 --> URI Class Initialized
INFO - 2021-06-28 09:56:49 --> Router Class Initialized
INFO - 2021-06-28 09:56:49 --> Output Class Initialized
INFO - 2021-06-28 09:56:49 --> Security Class Initialized
DEBUG - 2021-06-28 09:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 09:56:49 --> Input Class Initialized
INFO - 2021-06-28 09:56:49 --> Language Class Initialized
INFO - 2021-06-28 09:56:49 --> Language Class Initialized
INFO - 2021-06-28 09:56:49 --> Config Class Initialized
INFO - 2021-06-28 09:56:49 --> Loader Class Initialized
INFO - 2021-06-28 09:56:49 --> Helper loaded: url_helper
INFO - 2021-06-28 09:56:49 --> Helper loaded: file_helper
INFO - 2021-06-28 09:56:49 --> Helper loaded: form_helper
INFO - 2021-06-28 09:56:49 --> Helper loaded: my_helper
INFO - 2021-06-28 09:56:49 --> Database Driver Class Initialized
DEBUG - 2021-06-28 09:56:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 09:56:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 09:56:49 --> Controller Class Initialized
DEBUG - 2021-06-28 09:56:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-28 09:56:49 --> Final output sent to browser
DEBUG - 2021-06-28 09:56:49 --> Total execution time: 0.0475
INFO - 2021-06-28 10:10:02 --> Config Class Initialized
INFO - 2021-06-28 10:10:02 --> Hooks Class Initialized
DEBUG - 2021-06-28 10:10:02 --> UTF-8 Support Enabled
INFO - 2021-06-28 10:10:02 --> Utf8 Class Initialized
INFO - 2021-06-28 10:10:02 --> URI Class Initialized
INFO - 2021-06-28 10:10:02 --> Router Class Initialized
INFO - 2021-06-28 10:10:02 --> Output Class Initialized
INFO - 2021-06-28 10:10:02 --> Security Class Initialized
DEBUG - 2021-06-28 10:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 10:10:02 --> Input Class Initialized
INFO - 2021-06-28 10:10:02 --> Language Class Initialized
INFO - 2021-06-28 10:10:02 --> Language Class Initialized
INFO - 2021-06-28 10:10:02 --> Config Class Initialized
INFO - 2021-06-28 10:10:02 --> Loader Class Initialized
INFO - 2021-06-28 10:10:02 --> Helper loaded: url_helper
INFO - 2021-06-28 10:10:02 --> Helper loaded: file_helper
INFO - 2021-06-28 10:10:02 --> Helper loaded: form_helper
INFO - 2021-06-28 10:10:02 --> Helper loaded: my_helper
INFO - 2021-06-28 10:10:02 --> Database Driver Class Initialized
DEBUG - 2021-06-28 10:10:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 10:10:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 10:10:02 --> Controller Class Initialized
DEBUG - 2021-06-28 10:10:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-28 10:10:02 --> Final output sent to browser
DEBUG - 2021-06-28 10:10:02 --> Total execution time: 0.0470
INFO - 2021-06-28 10:10:17 --> Config Class Initialized
INFO - 2021-06-28 10:10:17 --> Hooks Class Initialized
DEBUG - 2021-06-28 10:10:17 --> UTF-8 Support Enabled
INFO - 2021-06-28 10:10:17 --> Utf8 Class Initialized
INFO - 2021-06-28 10:10:17 --> URI Class Initialized
INFO - 2021-06-28 10:10:17 --> Router Class Initialized
INFO - 2021-06-28 10:10:17 --> Output Class Initialized
INFO - 2021-06-28 10:10:17 --> Security Class Initialized
DEBUG - 2021-06-28 10:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 10:10:17 --> Input Class Initialized
INFO - 2021-06-28 10:10:17 --> Language Class Initialized
INFO - 2021-06-28 10:10:17 --> Language Class Initialized
INFO - 2021-06-28 10:10:17 --> Config Class Initialized
INFO - 2021-06-28 10:10:17 --> Loader Class Initialized
INFO - 2021-06-28 10:10:17 --> Helper loaded: url_helper
INFO - 2021-06-28 10:10:17 --> Helper loaded: file_helper
INFO - 2021-06-28 10:10:17 --> Helper loaded: form_helper
INFO - 2021-06-28 10:10:17 --> Helper loaded: my_helper
INFO - 2021-06-28 10:10:17 --> Database Driver Class Initialized
DEBUG - 2021-06-28 10:10:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 10:10:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 10:10:17 --> Controller Class Initialized
DEBUG - 2021-06-28 10:10:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-28 10:10:17 --> Final output sent to browser
DEBUG - 2021-06-28 10:10:17 --> Total execution time: 0.0457
INFO - 2021-06-28 10:11:46 --> Config Class Initialized
INFO - 2021-06-28 10:11:46 --> Hooks Class Initialized
DEBUG - 2021-06-28 10:11:46 --> UTF-8 Support Enabled
INFO - 2021-06-28 10:11:46 --> Utf8 Class Initialized
INFO - 2021-06-28 10:11:46 --> URI Class Initialized
INFO - 2021-06-28 10:11:46 --> Router Class Initialized
INFO - 2021-06-28 10:11:46 --> Output Class Initialized
INFO - 2021-06-28 10:11:46 --> Security Class Initialized
DEBUG - 2021-06-28 10:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 10:11:46 --> Input Class Initialized
INFO - 2021-06-28 10:11:46 --> Language Class Initialized
INFO - 2021-06-28 10:11:46 --> Language Class Initialized
INFO - 2021-06-28 10:11:46 --> Config Class Initialized
INFO - 2021-06-28 10:11:46 --> Loader Class Initialized
INFO - 2021-06-28 10:11:46 --> Helper loaded: url_helper
INFO - 2021-06-28 10:11:46 --> Helper loaded: file_helper
INFO - 2021-06-28 10:11:46 --> Helper loaded: form_helper
INFO - 2021-06-28 10:11:46 --> Helper loaded: my_helper
INFO - 2021-06-28 10:11:46 --> Database Driver Class Initialized
DEBUG - 2021-06-28 10:11:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 10:11:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 10:11:46 --> Controller Class Initialized
DEBUG - 2021-06-28 10:11:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-28 10:11:46 --> Final output sent to browser
DEBUG - 2021-06-28 10:11:46 --> Total execution time: 0.0557
INFO - 2021-06-28 10:12:13 --> Config Class Initialized
INFO - 2021-06-28 10:12:13 --> Hooks Class Initialized
DEBUG - 2021-06-28 10:12:13 --> UTF-8 Support Enabled
INFO - 2021-06-28 10:12:13 --> Utf8 Class Initialized
INFO - 2021-06-28 10:12:13 --> URI Class Initialized
INFO - 2021-06-28 10:12:13 --> Router Class Initialized
INFO - 2021-06-28 10:12:13 --> Output Class Initialized
INFO - 2021-06-28 10:12:13 --> Security Class Initialized
DEBUG - 2021-06-28 10:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 10:12:13 --> Input Class Initialized
INFO - 2021-06-28 10:12:13 --> Language Class Initialized
INFO - 2021-06-28 10:12:13 --> Language Class Initialized
INFO - 2021-06-28 10:12:13 --> Config Class Initialized
INFO - 2021-06-28 10:12:13 --> Loader Class Initialized
INFO - 2021-06-28 10:12:13 --> Helper loaded: url_helper
INFO - 2021-06-28 10:12:13 --> Helper loaded: file_helper
INFO - 2021-06-28 10:12:13 --> Helper loaded: form_helper
INFO - 2021-06-28 10:12:13 --> Helper loaded: my_helper
INFO - 2021-06-28 10:12:13 --> Database Driver Class Initialized
DEBUG - 2021-06-28 10:12:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 10:12:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 10:12:13 --> Controller Class Initialized
DEBUG - 2021-06-28 10:12:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-28 10:12:13 --> Final output sent to browser
DEBUG - 2021-06-28 10:12:13 --> Total execution time: 0.0577
INFO - 2021-06-28 10:19:17 --> Config Class Initialized
INFO - 2021-06-28 10:19:17 --> Hooks Class Initialized
DEBUG - 2021-06-28 10:19:17 --> UTF-8 Support Enabled
INFO - 2021-06-28 10:19:17 --> Utf8 Class Initialized
INFO - 2021-06-28 10:19:17 --> URI Class Initialized
INFO - 2021-06-28 10:19:17 --> Router Class Initialized
INFO - 2021-06-28 10:19:17 --> Output Class Initialized
INFO - 2021-06-28 10:19:17 --> Security Class Initialized
DEBUG - 2021-06-28 10:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 10:19:17 --> Input Class Initialized
INFO - 2021-06-28 10:19:17 --> Language Class Initialized
INFO - 2021-06-28 10:19:17 --> Language Class Initialized
INFO - 2021-06-28 10:19:17 --> Config Class Initialized
INFO - 2021-06-28 10:19:17 --> Loader Class Initialized
INFO - 2021-06-28 10:19:17 --> Helper loaded: url_helper
INFO - 2021-06-28 10:19:17 --> Helper loaded: file_helper
INFO - 2021-06-28 10:19:17 --> Helper loaded: form_helper
INFO - 2021-06-28 10:19:17 --> Helper loaded: my_helper
INFO - 2021-06-28 10:19:17 --> Database Driver Class Initialized
DEBUG - 2021-06-28 10:19:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 10:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 10:19:17 --> Controller Class Initialized
DEBUG - 2021-06-28 10:19:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-28 10:19:17 --> Final output sent to browser
DEBUG - 2021-06-28 10:19:17 --> Total execution time: 0.0459
INFO - 2021-06-28 10:19:55 --> Config Class Initialized
INFO - 2021-06-28 10:19:55 --> Hooks Class Initialized
DEBUG - 2021-06-28 10:19:55 --> UTF-8 Support Enabled
INFO - 2021-06-28 10:19:55 --> Utf8 Class Initialized
INFO - 2021-06-28 10:19:55 --> URI Class Initialized
INFO - 2021-06-28 10:19:55 --> Router Class Initialized
INFO - 2021-06-28 10:19:55 --> Output Class Initialized
INFO - 2021-06-28 10:19:55 --> Security Class Initialized
DEBUG - 2021-06-28 10:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 10:19:55 --> Input Class Initialized
INFO - 2021-06-28 10:19:55 --> Language Class Initialized
INFO - 2021-06-28 10:19:55 --> Language Class Initialized
INFO - 2021-06-28 10:19:55 --> Config Class Initialized
INFO - 2021-06-28 10:19:55 --> Loader Class Initialized
INFO - 2021-06-28 10:19:55 --> Helper loaded: url_helper
INFO - 2021-06-28 10:19:55 --> Helper loaded: file_helper
INFO - 2021-06-28 10:19:55 --> Helper loaded: form_helper
INFO - 2021-06-28 10:19:55 --> Helper loaded: my_helper
INFO - 2021-06-28 10:19:55 --> Database Driver Class Initialized
DEBUG - 2021-06-28 10:19:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 10:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 10:19:55 --> Controller Class Initialized
DEBUG - 2021-06-28 10:19:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-28 10:19:55 --> Final output sent to browser
DEBUG - 2021-06-28 10:19:55 --> Total execution time: 0.0549
INFO - 2021-06-28 10:20:30 --> Config Class Initialized
INFO - 2021-06-28 10:20:30 --> Hooks Class Initialized
DEBUG - 2021-06-28 10:20:30 --> UTF-8 Support Enabled
INFO - 2021-06-28 10:20:30 --> Utf8 Class Initialized
INFO - 2021-06-28 10:20:30 --> URI Class Initialized
INFO - 2021-06-28 10:20:30 --> Router Class Initialized
INFO - 2021-06-28 10:20:30 --> Output Class Initialized
INFO - 2021-06-28 10:20:30 --> Security Class Initialized
DEBUG - 2021-06-28 10:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 10:20:30 --> Input Class Initialized
INFO - 2021-06-28 10:20:30 --> Language Class Initialized
INFO - 2021-06-28 10:20:30 --> Language Class Initialized
INFO - 2021-06-28 10:20:30 --> Config Class Initialized
INFO - 2021-06-28 10:20:30 --> Loader Class Initialized
INFO - 2021-06-28 10:20:30 --> Helper loaded: url_helper
INFO - 2021-06-28 10:20:30 --> Helper loaded: file_helper
INFO - 2021-06-28 10:20:30 --> Helper loaded: form_helper
INFO - 2021-06-28 10:20:30 --> Helper loaded: my_helper
INFO - 2021-06-28 10:20:30 --> Database Driver Class Initialized
DEBUG - 2021-06-28 10:20:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 10:20:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 10:20:30 --> Controller Class Initialized
DEBUG - 2021-06-28 10:20:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-28 10:20:30 --> Final output sent to browser
DEBUG - 2021-06-28 10:20:30 --> Total execution time: 0.0539
INFO - 2021-06-28 10:21:20 --> Config Class Initialized
INFO - 2021-06-28 10:21:20 --> Hooks Class Initialized
DEBUG - 2021-06-28 10:21:20 --> UTF-8 Support Enabled
INFO - 2021-06-28 10:21:20 --> Utf8 Class Initialized
INFO - 2021-06-28 10:21:20 --> URI Class Initialized
INFO - 2021-06-28 10:21:20 --> Router Class Initialized
INFO - 2021-06-28 10:21:20 --> Output Class Initialized
INFO - 2021-06-28 10:21:20 --> Security Class Initialized
DEBUG - 2021-06-28 10:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 10:21:20 --> Input Class Initialized
INFO - 2021-06-28 10:21:20 --> Language Class Initialized
INFO - 2021-06-28 10:21:20 --> Language Class Initialized
INFO - 2021-06-28 10:21:20 --> Config Class Initialized
INFO - 2021-06-28 10:21:20 --> Loader Class Initialized
INFO - 2021-06-28 10:21:20 --> Helper loaded: url_helper
INFO - 2021-06-28 10:21:20 --> Helper loaded: file_helper
INFO - 2021-06-28 10:21:20 --> Helper loaded: form_helper
INFO - 2021-06-28 10:21:20 --> Helper loaded: my_helper
INFO - 2021-06-28 10:21:20 --> Database Driver Class Initialized
DEBUG - 2021-06-28 10:21:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 10:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 10:21:20 --> Controller Class Initialized
DEBUG - 2021-06-28 10:21:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-28 10:21:20 --> Final output sent to browser
DEBUG - 2021-06-28 10:21:20 --> Total execution time: 0.0565
INFO - 2021-06-28 10:21:55 --> Config Class Initialized
INFO - 2021-06-28 10:21:55 --> Hooks Class Initialized
DEBUG - 2021-06-28 10:21:55 --> UTF-8 Support Enabled
INFO - 2021-06-28 10:21:55 --> Utf8 Class Initialized
INFO - 2021-06-28 10:21:55 --> URI Class Initialized
INFO - 2021-06-28 10:21:55 --> Router Class Initialized
INFO - 2021-06-28 10:21:55 --> Output Class Initialized
INFO - 2021-06-28 10:21:55 --> Security Class Initialized
DEBUG - 2021-06-28 10:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 10:21:55 --> Input Class Initialized
INFO - 2021-06-28 10:21:55 --> Language Class Initialized
INFO - 2021-06-28 10:21:55 --> Language Class Initialized
INFO - 2021-06-28 10:21:55 --> Config Class Initialized
INFO - 2021-06-28 10:21:55 --> Loader Class Initialized
INFO - 2021-06-28 10:21:55 --> Helper loaded: url_helper
INFO - 2021-06-28 10:21:55 --> Helper loaded: file_helper
INFO - 2021-06-28 10:21:55 --> Helper loaded: form_helper
INFO - 2021-06-28 10:21:55 --> Helper loaded: my_helper
INFO - 2021-06-28 10:21:55 --> Database Driver Class Initialized
DEBUG - 2021-06-28 10:21:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 10:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 10:21:55 --> Controller Class Initialized
DEBUG - 2021-06-28 10:21:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-28 10:21:55 --> Final output sent to browser
DEBUG - 2021-06-28 10:21:55 --> Total execution time: 0.0564
INFO - 2021-06-28 10:23:06 --> Config Class Initialized
INFO - 2021-06-28 10:23:06 --> Hooks Class Initialized
DEBUG - 2021-06-28 10:23:06 --> UTF-8 Support Enabled
INFO - 2021-06-28 10:23:06 --> Utf8 Class Initialized
INFO - 2021-06-28 10:23:06 --> URI Class Initialized
INFO - 2021-06-28 10:23:06 --> Router Class Initialized
INFO - 2021-06-28 10:23:06 --> Output Class Initialized
INFO - 2021-06-28 10:23:06 --> Security Class Initialized
DEBUG - 2021-06-28 10:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 10:23:06 --> Input Class Initialized
INFO - 2021-06-28 10:23:06 --> Language Class Initialized
INFO - 2021-06-28 10:23:06 --> Language Class Initialized
INFO - 2021-06-28 10:23:06 --> Config Class Initialized
INFO - 2021-06-28 10:23:06 --> Loader Class Initialized
INFO - 2021-06-28 10:23:06 --> Helper loaded: url_helper
INFO - 2021-06-28 10:23:06 --> Helper loaded: file_helper
INFO - 2021-06-28 10:23:06 --> Helper loaded: form_helper
INFO - 2021-06-28 10:23:06 --> Helper loaded: my_helper
INFO - 2021-06-28 10:23:06 --> Database Driver Class Initialized
DEBUG - 2021-06-28 10:23:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 10:23:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 10:23:06 --> Controller Class Initialized
DEBUG - 2021-06-28 10:23:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-28 10:23:06 --> Final output sent to browser
DEBUG - 2021-06-28 10:23:06 --> Total execution time: 0.0551
INFO - 2021-06-28 10:23:39 --> Config Class Initialized
INFO - 2021-06-28 10:23:39 --> Hooks Class Initialized
DEBUG - 2021-06-28 10:23:39 --> UTF-8 Support Enabled
INFO - 2021-06-28 10:23:39 --> Utf8 Class Initialized
INFO - 2021-06-28 10:23:39 --> URI Class Initialized
INFO - 2021-06-28 10:23:39 --> Router Class Initialized
INFO - 2021-06-28 10:23:39 --> Output Class Initialized
INFO - 2021-06-28 10:23:39 --> Security Class Initialized
DEBUG - 2021-06-28 10:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 10:23:39 --> Input Class Initialized
INFO - 2021-06-28 10:23:39 --> Language Class Initialized
INFO - 2021-06-28 10:23:39 --> Language Class Initialized
INFO - 2021-06-28 10:23:39 --> Config Class Initialized
INFO - 2021-06-28 10:23:39 --> Loader Class Initialized
INFO - 2021-06-28 10:23:39 --> Helper loaded: url_helper
INFO - 2021-06-28 10:23:39 --> Helper loaded: file_helper
INFO - 2021-06-28 10:23:39 --> Helper loaded: form_helper
INFO - 2021-06-28 10:23:39 --> Helper loaded: my_helper
INFO - 2021-06-28 10:23:39 --> Database Driver Class Initialized
DEBUG - 2021-06-28 10:23:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 10:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 10:23:39 --> Controller Class Initialized
DEBUG - 2021-06-28 10:23:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-28 10:23:39 --> Final output sent to browser
DEBUG - 2021-06-28 10:23:39 --> Total execution time: 0.0549
INFO - 2021-06-28 10:23:55 --> Config Class Initialized
INFO - 2021-06-28 10:23:55 --> Hooks Class Initialized
DEBUG - 2021-06-28 10:23:55 --> UTF-8 Support Enabled
INFO - 2021-06-28 10:23:55 --> Utf8 Class Initialized
INFO - 2021-06-28 10:23:55 --> URI Class Initialized
INFO - 2021-06-28 10:23:55 --> Router Class Initialized
INFO - 2021-06-28 10:23:55 --> Output Class Initialized
INFO - 2021-06-28 10:23:55 --> Security Class Initialized
DEBUG - 2021-06-28 10:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 10:23:55 --> Input Class Initialized
INFO - 2021-06-28 10:23:55 --> Language Class Initialized
INFO - 2021-06-28 10:23:55 --> Language Class Initialized
INFO - 2021-06-28 10:23:55 --> Config Class Initialized
INFO - 2021-06-28 10:23:55 --> Loader Class Initialized
INFO - 2021-06-28 10:23:55 --> Helper loaded: url_helper
INFO - 2021-06-28 10:23:55 --> Helper loaded: file_helper
INFO - 2021-06-28 10:23:55 --> Helper loaded: form_helper
INFO - 2021-06-28 10:23:55 --> Helper loaded: my_helper
INFO - 2021-06-28 10:23:55 --> Database Driver Class Initialized
DEBUG - 2021-06-28 10:23:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 10:23:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 10:23:55 --> Controller Class Initialized
DEBUG - 2021-06-28 10:23:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-28 10:23:55 --> Final output sent to browser
DEBUG - 2021-06-28 10:23:55 --> Total execution time: 0.0533
INFO - 2021-06-28 10:25:00 --> Config Class Initialized
INFO - 2021-06-28 10:25:00 --> Hooks Class Initialized
DEBUG - 2021-06-28 10:25:00 --> UTF-8 Support Enabled
INFO - 2021-06-28 10:25:00 --> Utf8 Class Initialized
INFO - 2021-06-28 10:25:00 --> URI Class Initialized
INFO - 2021-06-28 10:25:00 --> Router Class Initialized
INFO - 2021-06-28 10:25:00 --> Output Class Initialized
INFO - 2021-06-28 10:25:00 --> Security Class Initialized
DEBUG - 2021-06-28 10:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 10:25:00 --> Input Class Initialized
INFO - 2021-06-28 10:25:00 --> Language Class Initialized
INFO - 2021-06-28 10:25:00 --> Language Class Initialized
INFO - 2021-06-28 10:25:00 --> Config Class Initialized
INFO - 2021-06-28 10:25:00 --> Loader Class Initialized
INFO - 2021-06-28 10:25:00 --> Helper loaded: url_helper
INFO - 2021-06-28 10:25:00 --> Helper loaded: file_helper
INFO - 2021-06-28 10:25:00 --> Helper loaded: form_helper
INFO - 2021-06-28 10:25:00 --> Helper loaded: my_helper
INFO - 2021-06-28 10:25:00 --> Database Driver Class Initialized
DEBUG - 2021-06-28 10:25:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 10:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 10:25:00 --> Controller Class Initialized
DEBUG - 2021-06-28 10:25:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-28 10:25:00 --> Final output sent to browser
DEBUG - 2021-06-28 10:25:00 --> Total execution time: 0.0574
INFO - 2021-06-28 10:25:38 --> Config Class Initialized
INFO - 2021-06-28 10:25:38 --> Hooks Class Initialized
DEBUG - 2021-06-28 10:25:38 --> UTF-8 Support Enabled
INFO - 2021-06-28 10:25:38 --> Utf8 Class Initialized
INFO - 2021-06-28 10:25:38 --> URI Class Initialized
INFO - 2021-06-28 10:25:38 --> Router Class Initialized
INFO - 2021-06-28 10:25:38 --> Output Class Initialized
INFO - 2021-06-28 10:25:38 --> Security Class Initialized
DEBUG - 2021-06-28 10:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 10:25:38 --> Input Class Initialized
INFO - 2021-06-28 10:25:38 --> Language Class Initialized
INFO - 2021-06-28 10:25:38 --> Language Class Initialized
INFO - 2021-06-28 10:25:38 --> Config Class Initialized
INFO - 2021-06-28 10:25:38 --> Loader Class Initialized
INFO - 2021-06-28 10:25:38 --> Helper loaded: url_helper
INFO - 2021-06-28 10:25:38 --> Helper loaded: file_helper
INFO - 2021-06-28 10:25:38 --> Helper loaded: form_helper
INFO - 2021-06-28 10:25:38 --> Helper loaded: my_helper
INFO - 2021-06-28 10:25:38 --> Database Driver Class Initialized
DEBUG - 2021-06-28 10:25:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 10:25:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 10:25:38 --> Controller Class Initialized
DEBUG - 2021-06-28 10:25:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-28 10:25:38 --> Final output sent to browser
DEBUG - 2021-06-28 10:25:38 --> Total execution time: 0.0558
INFO - 2021-06-28 10:25:39 --> Config Class Initialized
INFO - 2021-06-28 10:25:39 --> Hooks Class Initialized
DEBUG - 2021-06-28 10:25:39 --> UTF-8 Support Enabled
INFO - 2021-06-28 10:25:39 --> Utf8 Class Initialized
INFO - 2021-06-28 10:25:39 --> URI Class Initialized
INFO - 2021-06-28 10:25:39 --> Router Class Initialized
INFO - 2021-06-28 10:25:39 --> Output Class Initialized
INFO - 2021-06-28 10:25:39 --> Security Class Initialized
DEBUG - 2021-06-28 10:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 10:25:39 --> Input Class Initialized
INFO - 2021-06-28 10:25:39 --> Language Class Initialized
INFO - 2021-06-28 10:25:39 --> Language Class Initialized
INFO - 2021-06-28 10:25:39 --> Config Class Initialized
INFO - 2021-06-28 10:25:39 --> Loader Class Initialized
INFO - 2021-06-28 10:25:39 --> Helper loaded: url_helper
INFO - 2021-06-28 10:25:39 --> Helper loaded: file_helper
INFO - 2021-06-28 10:25:39 --> Helper loaded: form_helper
INFO - 2021-06-28 10:25:39 --> Helper loaded: my_helper
INFO - 2021-06-28 10:25:39 --> Database Driver Class Initialized
DEBUG - 2021-06-28 10:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 10:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 10:25:39 --> Controller Class Initialized
DEBUG - 2021-06-28 10:25:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-28 10:25:39 --> Final output sent to browser
DEBUG - 2021-06-28 10:25:39 --> Total execution time: 0.0455
INFO - 2021-06-28 10:30:14 --> Config Class Initialized
INFO - 2021-06-28 10:30:14 --> Hooks Class Initialized
DEBUG - 2021-06-28 10:30:14 --> UTF-8 Support Enabled
INFO - 2021-06-28 10:30:14 --> Utf8 Class Initialized
INFO - 2021-06-28 10:30:14 --> URI Class Initialized
INFO - 2021-06-28 10:30:14 --> Router Class Initialized
INFO - 2021-06-28 10:30:14 --> Output Class Initialized
INFO - 2021-06-28 10:30:14 --> Security Class Initialized
DEBUG - 2021-06-28 10:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 10:30:14 --> Input Class Initialized
INFO - 2021-06-28 10:30:14 --> Language Class Initialized
INFO - 2021-06-28 10:30:14 --> Language Class Initialized
INFO - 2021-06-28 10:30:14 --> Config Class Initialized
INFO - 2021-06-28 10:30:14 --> Loader Class Initialized
INFO - 2021-06-28 10:30:14 --> Helper loaded: url_helper
INFO - 2021-06-28 10:30:14 --> Helper loaded: file_helper
INFO - 2021-06-28 10:30:14 --> Helper loaded: form_helper
INFO - 2021-06-28 10:30:14 --> Helper loaded: my_helper
INFO - 2021-06-28 10:30:14 --> Database Driver Class Initialized
DEBUG - 2021-06-28 10:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 10:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 10:30:14 --> Controller Class Initialized
DEBUG - 2021-06-28 10:30:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-28 10:30:14 --> Final output sent to browser
DEBUG - 2021-06-28 10:30:14 --> Total execution time: 0.3054
INFO - 2021-06-28 10:34:05 --> Config Class Initialized
INFO - 2021-06-28 10:34:05 --> Hooks Class Initialized
DEBUG - 2021-06-28 10:34:05 --> UTF-8 Support Enabled
INFO - 2021-06-28 10:34:05 --> Utf8 Class Initialized
INFO - 2021-06-28 10:34:05 --> URI Class Initialized
INFO - 2021-06-28 10:34:05 --> Router Class Initialized
INFO - 2021-06-28 10:34:05 --> Output Class Initialized
INFO - 2021-06-28 10:34:05 --> Security Class Initialized
DEBUG - 2021-06-28 10:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 10:34:05 --> Input Class Initialized
INFO - 2021-06-28 10:34:05 --> Language Class Initialized
INFO - 2021-06-28 10:34:05 --> Language Class Initialized
INFO - 2021-06-28 10:34:05 --> Config Class Initialized
INFO - 2021-06-28 10:34:05 --> Loader Class Initialized
INFO - 2021-06-28 10:34:05 --> Helper loaded: url_helper
INFO - 2021-06-28 10:34:05 --> Helper loaded: file_helper
INFO - 2021-06-28 10:34:05 --> Helper loaded: form_helper
INFO - 2021-06-28 10:34:05 --> Helper loaded: my_helper
INFO - 2021-06-28 10:34:05 --> Database Driver Class Initialized
DEBUG - 2021-06-28 10:34:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 10:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 10:34:05 --> Controller Class Initialized
DEBUG - 2021-06-28 10:34:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-28 10:34:05 --> Final output sent to browser
DEBUG - 2021-06-28 10:34:05 --> Total execution time: 0.0560
INFO - 2021-06-28 10:35:17 --> Config Class Initialized
INFO - 2021-06-28 10:35:17 --> Hooks Class Initialized
DEBUG - 2021-06-28 10:35:17 --> UTF-8 Support Enabled
INFO - 2021-06-28 10:35:17 --> Utf8 Class Initialized
INFO - 2021-06-28 10:35:17 --> URI Class Initialized
INFO - 2021-06-28 10:35:17 --> Router Class Initialized
INFO - 2021-06-28 10:35:17 --> Output Class Initialized
INFO - 2021-06-28 10:35:17 --> Security Class Initialized
DEBUG - 2021-06-28 10:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-28 10:35:17 --> Input Class Initialized
INFO - 2021-06-28 10:35:17 --> Language Class Initialized
INFO - 2021-06-28 10:35:17 --> Language Class Initialized
INFO - 2021-06-28 10:35:17 --> Config Class Initialized
INFO - 2021-06-28 10:35:17 --> Loader Class Initialized
INFO - 2021-06-28 10:35:17 --> Helper loaded: url_helper
INFO - 2021-06-28 10:35:17 --> Helper loaded: file_helper
INFO - 2021-06-28 10:35:17 --> Helper loaded: form_helper
INFO - 2021-06-28 10:35:17 --> Helper loaded: my_helper
INFO - 2021-06-28 10:35:17 --> Database Driver Class Initialized
DEBUG - 2021-06-28 10:35:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-28 10:35:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-28 10:35:17 --> Controller Class Initialized
DEBUG - 2021-06-28 10:35:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-28 10:35:17 --> Final output sent to browser
DEBUG - 2021-06-28 10:35:17 --> Total execution time: 0.0547
