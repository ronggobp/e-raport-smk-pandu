<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-11-06 08:42:04 --> Config Class Initialized
INFO - 2020-11-06 08:42:04 --> Hooks Class Initialized
DEBUG - 2020-11-06 08:42:04 --> UTF-8 Support Enabled
INFO - 2020-11-06 08:42:04 --> Utf8 Class Initialized
INFO - 2020-11-06 08:42:04 --> URI Class Initialized
DEBUG - 2020-11-06 08:42:05 --> No URI present. Default controller set.
INFO - 2020-11-06 08:42:05 --> Router Class Initialized
INFO - 2020-11-06 08:42:05 --> Output Class Initialized
INFO - 2020-11-06 08:42:05 --> Security Class Initialized
DEBUG - 2020-11-06 08:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-06 08:42:05 --> Input Class Initialized
INFO - 2020-11-06 08:42:05 --> Language Class Initialized
INFO - 2020-11-06 08:42:05 --> Language Class Initialized
INFO - 2020-11-06 08:42:05 --> Config Class Initialized
INFO - 2020-11-06 08:42:05 --> Loader Class Initialized
INFO - 2020-11-06 08:42:05 --> Helper loaded: url_helper
INFO - 2020-11-06 08:42:05 --> Helper loaded: file_helper
INFO - 2020-11-06 08:42:05 --> Helper loaded: form_helper
INFO - 2020-11-06 08:42:05 --> Helper loaded: my_helper
INFO - 2020-11-06 08:42:05 --> Database Driver Class Initialized
DEBUG - 2020-11-06 08:42:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-06 08:42:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-06 08:42:06 --> Controller Class Initialized
INFO - 2020-11-06 08:42:06 --> Config Class Initialized
INFO - 2020-11-06 08:42:06 --> Hooks Class Initialized
DEBUG - 2020-11-06 08:42:06 --> UTF-8 Support Enabled
INFO - 2020-11-06 08:42:06 --> Utf8 Class Initialized
INFO - 2020-11-06 08:42:06 --> URI Class Initialized
INFO - 2020-11-06 08:42:06 --> Router Class Initialized
INFO - 2020-11-06 08:42:06 --> Output Class Initialized
INFO - 2020-11-06 08:42:06 --> Security Class Initialized
DEBUG - 2020-11-06 08:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-06 08:42:06 --> Input Class Initialized
INFO - 2020-11-06 08:42:06 --> Language Class Initialized
INFO - 2020-11-06 08:42:06 --> Language Class Initialized
INFO - 2020-11-06 08:42:06 --> Config Class Initialized
INFO - 2020-11-06 08:42:06 --> Loader Class Initialized
INFO - 2020-11-06 08:42:06 --> Helper loaded: url_helper
INFO - 2020-11-06 08:42:06 --> Helper loaded: file_helper
INFO - 2020-11-06 08:42:07 --> Helper loaded: form_helper
INFO - 2020-11-06 08:42:07 --> Helper loaded: my_helper
INFO - 2020-11-06 08:42:07 --> Database Driver Class Initialized
DEBUG - 2020-11-06 08:42:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-06 08:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-06 08:42:07 --> Controller Class Initialized
DEBUG - 2020-11-06 08:42:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-06 08:42:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-06 08:42:07 --> Final output sent to browser
DEBUG - 2020-11-06 08:42:07 --> Total execution time: 0.9194
INFO - 2020-11-06 08:42:22 --> Config Class Initialized
INFO - 2020-11-06 08:42:22 --> Hooks Class Initialized
DEBUG - 2020-11-06 08:42:22 --> UTF-8 Support Enabled
INFO - 2020-11-06 08:42:22 --> Utf8 Class Initialized
INFO - 2020-11-06 08:42:22 --> URI Class Initialized
INFO - 2020-11-06 08:42:22 --> Router Class Initialized
INFO - 2020-11-06 08:42:22 --> Output Class Initialized
INFO - 2020-11-06 08:42:22 --> Security Class Initialized
DEBUG - 2020-11-06 08:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-06 08:42:22 --> Input Class Initialized
INFO - 2020-11-06 08:42:22 --> Language Class Initialized
INFO - 2020-11-06 08:42:22 --> Language Class Initialized
INFO - 2020-11-06 08:42:22 --> Config Class Initialized
INFO - 2020-11-06 08:42:22 --> Loader Class Initialized
INFO - 2020-11-06 08:42:22 --> Helper loaded: url_helper
INFO - 2020-11-06 08:42:22 --> Helper loaded: file_helper
INFO - 2020-11-06 08:42:22 --> Helper loaded: form_helper
INFO - 2020-11-06 08:42:22 --> Helper loaded: my_helper
INFO - 2020-11-06 08:42:22 --> Database Driver Class Initialized
DEBUG - 2020-11-06 08:42:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-06 08:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-06 08:42:22 --> Controller Class Initialized
INFO - 2020-11-06 08:42:22 --> Helper loaded: cookie_helper
INFO - 2020-11-06 08:42:22 --> Final output sent to browser
DEBUG - 2020-11-06 08:42:22 --> Total execution time: 0.6519
INFO - 2020-11-06 08:42:23 --> Config Class Initialized
INFO - 2020-11-06 08:42:23 --> Hooks Class Initialized
DEBUG - 2020-11-06 08:42:23 --> UTF-8 Support Enabled
INFO - 2020-11-06 08:42:23 --> Utf8 Class Initialized
INFO - 2020-11-06 08:42:23 --> URI Class Initialized
INFO - 2020-11-06 08:42:24 --> Router Class Initialized
INFO - 2020-11-06 08:42:24 --> Output Class Initialized
INFO - 2020-11-06 08:42:24 --> Security Class Initialized
DEBUG - 2020-11-06 08:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-06 08:42:24 --> Input Class Initialized
INFO - 2020-11-06 08:42:24 --> Language Class Initialized
INFO - 2020-11-06 08:42:24 --> Language Class Initialized
INFO - 2020-11-06 08:42:24 --> Config Class Initialized
INFO - 2020-11-06 08:42:24 --> Loader Class Initialized
INFO - 2020-11-06 08:42:24 --> Helper loaded: url_helper
INFO - 2020-11-06 08:42:24 --> Helper loaded: file_helper
INFO - 2020-11-06 08:42:24 --> Helper loaded: form_helper
INFO - 2020-11-06 08:42:24 --> Helper loaded: my_helper
INFO - 2020-11-06 08:42:24 --> Database Driver Class Initialized
DEBUG - 2020-11-06 08:42:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-06 08:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-06 08:42:24 --> Controller Class Initialized
DEBUG - 2020-11-06 08:42:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-06 08:42:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-06 08:42:24 --> Final output sent to browser
DEBUG - 2020-11-06 08:42:24 --> Total execution time: 0.9806
