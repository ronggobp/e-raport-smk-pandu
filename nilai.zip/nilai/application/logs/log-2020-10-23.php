<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-10-23 03:25:40 --> Config Class Initialized
INFO - 2020-10-23 03:25:40 --> Hooks Class Initialized
DEBUG - 2020-10-23 03:25:40 --> UTF-8 Support Enabled
INFO - 2020-10-23 03:25:40 --> Utf8 Class Initialized
INFO - 2020-10-23 03:25:40 --> URI Class Initialized
DEBUG - 2020-10-23 03:25:40 --> No URI present. Default controller set.
INFO - 2020-10-23 03:25:40 --> Router Class Initialized
INFO - 2020-10-23 03:25:40 --> Output Class Initialized
INFO - 2020-10-23 03:25:40 --> Security Class Initialized
DEBUG - 2020-10-23 03:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-23 03:25:40 --> Input Class Initialized
INFO - 2020-10-23 03:25:40 --> Language Class Initialized
INFO - 2020-10-23 03:25:41 --> Language Class Initialized
INFO - 2020-10-23 03:25:41 --> Config Class Initialized
INFO - 2020-10-23 03:25:41 --> Loader Class Initialized
INFO - 2020-10-23 03:25:41 --> Helper loaded: url_helper
INFO - 2020-10-23 03:25:41 --> Helper loaded: file_helper
INFO - 2020-10-23 03:25:41 --> Helper loaded: form_helper
INFO - 2020-10-23 03:25:41 --> Helper loaded: my_helper
INFO - 2020-10-23 03:25:41 --> Database Driver Class Initialized
DEBUG - 2020-10-23 03:25:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-23 03:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-23 03:25:41 --> Controller Class Initialized
INFO - 2020-10-23 03:25:41 --> Config Class Initialized
INFO - 2020-10-23 03:25:41 --> Hooks Class Initialized
DEBUG - 2020-10-23 03:25:41 --> UTF-8 Support Enabled
INFO - 2020-10-23 03:25:41 --> Utf8 Class Initialized
INFO - 2020-10-23 03:25:41 --> URI Class Initialized
INFO - 2020-10-23 03:25:41 --> Router Class Initialized
INFO - 2020-10-23 03:25:41 --> Output Class Initialized
INFO - 2020-10-23 03:25:41 --> Security Class Initialized
DEBUG - 2020-10-23 03:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-23 03:25:41 --> Input Class Initialized
INFO - 2020-10-23 03:25:41 --> Language Class Initialized
INFO - 2020-10-23 03:25:41 --> Language Class Initialized
INFO - 2020-10-23 03:25:41 --> Config Class Initialized
INFO - 2020-10-23 03:25:41 --> Loader Class Initialized
INFO - 2020-10-23 03:25:41 --> Helper loaded: url_helper
INFO - 2020-10-23 03:25:41 --> Helper loaded: file_helper
INFO - 2020-10-23 03:25:41 --> Helper loaded: form_helper
INFO - 2020-10-23 03:25:41 --> Helper loaded: my_helper
INFO - 2020-10-23 03:25:41 --> Database Driver Class Initialized
DEBUG - 2020-10-23 03:25:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-23 03:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-23 03:25:41 --> Controller Class Initialized
DEBUG - 2020-10-23 03:25:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-23 03:25:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-23 03:25:41 --> Final output sent to browser
DEBUG - 2020-10-23 03:25:41 --> Total execution time: 0.3429
INFO - 2020-10-23 03:32:32 --> Config Class Initialized
INFO - 2020-10-23 03:32:32 --> Hooks Class Initialized
DEBUG - 2020-10-23 03:32:32 --> UTF-8 Support Enabled
INFO - 2020-10-23 03:32:32 --> Utf8 Class Initialized
INFO - 2020-10-23 03:32:32 --> URI Class Initialized
INFO - 2020-10-23 03:32:32 --> Router Class Initialized
INFO - 2020-10-23 03:32:32 --> Output Class Initialized
INFO - 2020-10-23 03:32:32 --> Security Class Initialized
DEBUG - 2020-10-23 03:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-23 03:32:32 --> Input Class Initialized
INFO - 2020-10-23 03:32:32 --> Language Class Initialized
INFO - 2020-10-23 03:32:32 --> Language Class Initialized
INFO - 2020-10-23 03:32:32 --> Config Class Initialized
INFO - 2020-10-23 03:32:32 --> Loader Class Initialized
INFO - 2020-10-23 03:32:32 --> Helper loaded: url_helper
INFO - 2020-10-23 03:32:32 --> Helper loaded: file_helper
INFO - 2020-10-23 03:32:32 --> Helper loaded: form_helper
INFO - 2020-10-23 03:32:32 --> Helper loaded: my_helper
INFO - 2020-10-23 03:32:32 --> Database Driver Class Initialized
DEBUG - 2020-10-23 03:32:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-23 03:32:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-23 03:32:32 --> Controller Class Initialized
INFO - 2020-10-23 03:32:32 --> Helper loaded: cookie_helper
INFO - 2020-10-23 03:32:32 --> Final output sent to browser
DEBUG - 2020-10-23 03:32:32 --> Total execution time: 0.2614
INFO - 2020-10-23 03:32:33 --> Config Class Initialized
INFO - 2020-10-23 03:32:33 --> Hooks Class Initialized
DEBUG - 2020-10-23 03:32:33 --> UTF-8 Support Enabled
INFO - 2020-10-23 03:32:33 --> Utf8 Class Initialized
INFO - 2020-10-23 03:32:33 --> URI Class Initialized
INFO - 2020-10-23 03:32:33 --> Router Class Initialized
INFO - 2020-10-23 03:32:33 --> Output Class Initialized
INFO - 2020-10-23 03:32:34 --> Security Class Initialized
DEBUG - 2020-10-23 03:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-23 03:32:34 --> Input Class Initialized
INFO - 2020-10-23 03:32:34 --> Language Class Initialized
INFO - 2020-10-23 03:32:34 --> Language Class Initialized
INFO - 2020-10-23 03:32:34 --> Config Class Initialized
INFO - 2020-10-23 03:32:34 --> Loader Class Initialized
INFO - 2020-10-23 03:32:34 --> Helper loaded: url_helper
INFO - 2020-10-23 03:32:34 --> Helper loaded: file_helper
INFO - 2020-10-23 03:32:34 --> Helper loaded: form_helper
INFO - 2020-10-23 03:32:34 --> Helper loaded: my_helper
INFO - 2020-10-23 03:32:34 --> Database Driver Class Initialized
DEBUG - 2020-10-23 03:32:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-23 03:32:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-23 03:32:34 --> Controller Class Initialized
DEBUG - 2020-10-23 03:32:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-23 03:32:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-23 03:32:34 --> Final output sent to browser
DEBUG - 2020-10-23 03:32:34 --> Total execution time: 0.2848
INFO - 2020-10-23 03:32:37 --> Config Class Initialized
INFO - 2020-10-23 03:32:37 --> Hooks Class Initialized
DEBUG - 2020-10-23 03:32:37 --> UTF-8 Support Enabled
INFO - 2020-10-23 03:32:37 --> Utf8 Class Initialized
INFO - 2020-10-23 03:32:37 --> URI Class Initialized
INFO - 2020-10-23 03:32:37 --> Router Class Initialized
INFO - 2020-10-23 03:32:37 --> Output Class Initialized
INFO - 2020-10-23 03:32:38 --> Security Class Initialized
DEBUG - 2020-10-23 03:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-23 03:32:38 --> Input Class Initialized
INFO - 2020-10-23 03:32:38 --> Language Class Initialized
INFO - 2020-10-23 03:32:38 --> Language Class Initialized
INFO - 2020-10-23 03:32:38 --> Config Class Initialized
INFO - 2020-10-23 03:32:38 --> Loader Class Initialized
INFO - 2020-10-23 03:32:38 --> Helper loaded: url_helper
INFO - 2020-10-23 03:32:38 --> Helper loaded: file_helper
INFO - 2020-10-23 03:32:38 --> Helper loaded: form_helper
INFO - 2020-10-23 03:32:38 --> Helper loaded: my_helper
INFO - 2020-10-23 03:32:38 --> Database Driver Class Initialized
DEBUG - 2020-10-23 03:32:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-23 03:32:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-23 03:32:38 --> Controller Class Initialized
DEBUG - 2020-10-23 03:32:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-23 03:32:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-23 03:32:38 --> Final output sent to browser
DEBUG - 2020-10-23 03:32:38 --> Total execution time: 0.2298
INFO - 2020-10-23 03:32:38 --> Config Class Initialized
INFO - 2020-10-23 03:32:38 --> Hooks Class Initialized
DEBUG - 2020-10-23 03:32:38 --> UTF-8 Support Enabled
INFO - 2020-10-23 03:32:38 --> Utf8 Class Initialized
INFO - 2020-10-23 03:32:38 --> URI Class Initialized
INFO - 2020-10-23 03:32:38 --> Router Class Initialized
INFO - 2020-10-23 03:32:38 --> Output Class Initialized
INFO - 2020-10-23 03:32:38 --> Security Class Initialized
DEBUG - 2020-10-23 03:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-23 03:32:38 --> Input Class Initialized
INFO - 2020-10-23 03:32:38 --> Language Class Initialized
INFO - 2020-10-23 03:32:38 --> Language Class Initialized
INFO - 2020-10-23 03:32:38 --> Config Class Initialized
INFO - 2020-10-23 03:32:38 --> Loader Class Initialized
INFO - 2020-10-23 03:32:38 --> Helper loaded: url_helper
INFO - 2020-10-23 03:32:38 --> Helper loaded: file_helper
INFO - 2020-10-23 03:32:38 --> Helper loaded: form_helper
INFO - 2020-10-23 03:32:38 --> Helper loaded: my_helper
INFO - 2020-10-23 03:32:38 --> Database Driver Class Initialized
DEBUG - 2020-10-23 03:32:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-23 03:32:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-23 03:32:38 --> Controller Class Initialized
INFO - 2020-10-23 03:43:05 --> Config Class Initialized
INFO - 2020-10-23 03:43:05 --> Hooks Class Initialized
DEBUG - 2020-10-23 03:43:05 --> UTF-8 Support Enabled
INFO - 2020-10-23 03:43:05 --> Utf8 Class Initialized
INFO - 2020-10-23 03:43:05 --> URI Class Initialized
INFO - 2020-10-23 03:43:05 --> Router Class Initialized
INFO - 2020-10-23 03:43:05 --> Output Class Initialized
INFO - 2020-10-23 03:43:05 --> Security Class Initialized
DEBUG - 2020-10-23 03:43:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-23 03:43:05 --> Input Class Initialized
INFO - 2020-10-23 03:43:05 --> Language Class Initialized
INFO - 2020-10-23 03:43:05 --> Language Class Initialized
INFO - 2020-10-23 03:43:05 --> Config Class Initialized
INFO - 2020-10-23 03:43:05 --> Loader Class Initialized
INFO - 2020-10-23 03:43:05 --> Helper loaded: url_helper
INFO - 2020-10-23 03:43:05 --> Helper loaded: file_helper
INFO - 2020-10-23 03:43:05 --> Helper loaded: form_helper
INFO - 2020-10-23 03:43:05 --> Helper loaded: my_helper
INFO - 2020-10-23 03:43:05 --> Database Driver Class Initialized
DEBUG - 2020-10-23 03:43:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-23 03:43:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-23 03:43:05 --> Controller Class Initialized
INFO - 2020-10-23 03:43:05 --> Final output sent to browser
DEBUG - 2020-10-23 03:43:05 --> Total execution time: 0.1557
INFO - 2020-10-23 04:25:48 --> Config Class Initialized
INFO - 2020-10-23 04:25:48 --> Hooks Class Initialized
DEBUG - 2020-10-23 04:25:48 --> UTF-8 Support Enabled
INFO - 2020-10-23 04:25:48 --> Utf8 Class Initialized
INFO - 2020-10-23 04:25:48 --> URI Class Initialized
INFO - 2020-10-23 04:25:48 --> Router Class Initialized
INFO - 2020-10-23 04:25:48 --> Output Class Initialized
INFO - 2020-10-23 04:25:48 --> Security Class Initialized
DEBUG - 2020-10-23 04:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-23 04:25:48 --> Input Class Initialized
INFO - 2020-10-23 04:25:48 --> Language Class Initialized
INFO - 2020-10-23 04:25:48 --> Language Class Initialized
INFO - 2020-10-23 04:25:48 --> Config Class Initialized
INFO - 2020-10-23 04:25:48 --> Loader Class Initialized
INFO - 2020-10-23 04:25:48 --> Helper loaded: url_helper
INFO - 2020-10-23 04:25:48 --> Helper loaded: file_helper
INFO - 2020-10-23 04:25:48 --> Helper loaded: form_helper
INFO - 2020-10-23 04:25:48 --> Helper loaded: my_helper
INFO - 2020-10-23 04:25:48 --> Database Driver Class Initialized
DEBUG - 2020-10-23 04:25:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-23 04:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-23 04:25:48 --> Controller Class Initialized
DEBUG - 2020-10-23 04:25:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-10-23 04:25:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-23 04:25:48 --> Final output sent to browser
DEBUG - 2020-10-23 04:25:48 --> Total execution time: 0.2438
INFO - 2020-10-23 04:25:48 --> Config Class Initialized
INFO - 2020-10-23 04:25:48 --> Hooks Class Initialized
DEBUG - 2020-10-23 04:25:48 --> UTF-8 Support Enabled
INFO - 2020-10-23 04:25:48 --> Utf8 Class Initialized
INFO - 2020-10-23 04:25:48 --> URI Class Initialized
INFO - 2020-10-23 04:25:48 --> Router Class Initialized
INFO - 2020-10-23 04:25:48 --> Output Class Initialized
INFO - 2020-10-23 04:25:48 --> Security Class Initialized
DEBUG - 2020-10-23 04:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-23 04:25:48 --> Input Class Initialized
INFO - 2020-10-23 04:25:48 --> Language Class Initialized
INFO - 2020-10-23 04:25:48 --> Language Class Initialized
INFO - 2020-10-23 04:25:48 --> Config Class Initialized
INFO - 2020-10-23 04:25:48 --> Loader Class Initialized
INFO - 2020-10-23 04:25:48 --> Helper loaded: url_helper
INFO - 2020-10-23 04:25:48 --> Helper loaded: file_helper
INFO - 2020-10-23 04:25:48 --> Helper loaded: form_helper
INFO - 2020-10-23 04:25:48 --> Helper loaded: my_helper
INFO - 2020-10-23 04:25:48 --> Database Driver Class Initialized
DEBUG - 2020-10-23 04:25:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-23 04:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-23 04:25:48 --> Controller Class Initialized
INFO - 2020-10-23 04:25:50 --> Config Class Initialized
INFO - 2020-10-23 04:25:50 --> Hooks Class Initialized
DEBUG - 2020-10-23 04:25:50 --> UTF-8 Support Enabled
INFO - 2020-10-23 04:25:50 --> Utf8 Class Initialized
INFO - 2020-10-23 04:25:50 --> URI Class Initialized
INFO - 2020-10-23 04:25:50 --> Router Class Initialized
INFO - 2020-10-23 04:25:50 --> Output Class Initialized
INFO - 2020-10-23 04:25:50 --> Security Class Initialized
DEBUG - 2020-10-23 04:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-23 04:25:50 --> Input Class Initialized
INFO - 2020-10-23 04:25:50 --> Language Class Initialized
INFO - 2020-10-23 04:25:50 --> Language Class Initialized
INFO - 2020-10-23 04:25:50 --> Config Class Initialized
INFO - 2020-10-23 04:25:50 --> Loader Class Initialized
INFO - 2020-10-23 04:25:50 --> Helper loaded: url_helper
INFO - 2020-10-23 04:25:50 --> Helper loaded: file_helper
INFO - 2020-10-23 04:25:50 --> Helper loaded: form_helper
INFO - 2020-10-23 04:25:50 --> Helper loaded: my_helper
INFO - 2020-10-23 04:25:50 --> Database Driver Class Initialized
DEBUG - 2020-10-23 04:25:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-23 04:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-23 04:25:50 --> Controller Class Initialized
DEBUG - 2020-10-23 04:25:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-10-23 04:25:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-23 04:25:51 --> Final output sent to browser
DEBUG - 2020-10-23 04:25:51 --> Total execution time: 0.1772
INFO - 2020-10-23 04:25:51 --> Config Class Initialized
INFO - 2020-10-23 04:25:51 --> Hooks Class Initialized
DEBUG - 2020-10-23 04:25:51 --> UTF-8 Support Enabled
INFO - 2020-10-23 04:25:51 --> Utf8 Class Initialized
INFO - 2020-10-23 04:25:51 --> URI Class Initialized
INFO - 2020-10-23 04:25:51 --> Router Class Initialized
INFO - 2020-10-23 04:25:51 --> Output Class Initialized
INFO - 2020-10-23 04:25:51 --> Security Class Initialized
DEBUG - 2020-10-23 04:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-23 04:25:51 --> Input Class Initialized
INFO - 2020-10-23 04:25:51 --> Language Class Initialized
INFO - 2020-10-23 04:25:51 --> Language Class Initialized
INFO - 2020-10-23 04:25:51 --> Config Class Initialized
INFO - 2020-10-23 04:25:51 --> Loader Class Initialized
INFO - 2020-10-23 04:25:51 --> Helper loaded: url_helper
INFO - 2020-10-23 04:25:51 --> Helper loaded: file_helper
INFO - 2020-10-23 04:25:51 --> Helper loaded: form_helper
INFO - 2020-10-23 04:25:51 --> Helper loaded: my_helper
INFO - 2020-10-23 04:25:51 --> Database Driver Class Initialized
DEBUG - 2020-10-23 04:25:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-23 04:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-23 04:25:51 --> Controller Class Initialized
INFO - 2020-10-23 05:19:10 --> Config Class Initialized
INFO - 2020-10-23 05:19:10 --> Hooks Class Initialized
DEBUG - 2020-10-23 05:19:10 --> UTF-8 Support Enabled
INFO - 2020-10-23 05:19:10 --> Utf8 Class Initialized
INFO - 2020-10-23 05:19:10 --> URI Class Initialized
INFO - 2020-10-23 05:19:10 --> Router Class Initialized
INFO - 2020-10-23 05:19:10 --> Output Class Initialized
INFO - 2020-10-23 05:19:10 --> Security Class Initialized
DEBUG - 2020-10-23 05:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-23 05:19:10 --> Input Class Initialized
INFO - 2020-10-23 05:19:10 --> Language Class Initialized
INFO - 2020-10-23 05:19:10 --> Language Class Initialized
INFO - 2020-10-23 05:19:10 --> Config Class Initialized
INFO - 2020-10-23 05:19:10 --> Loader Class Initialized
INFO - 2020-10-23 05:19:10 --> Helper loaded: url_helper
INFO - 2020-10-23 05:19:10 --> Helper loaded: file_helper
INFO - 2020-10-23 05:19:10 --> Helper loaded: form_helper
INFO - 2020-10-23 05:19:10 --> Helper loaded: my_helper
INFO - 2020-10-23 05:19:10 --> Database Driver Class Initialized
DEBUG - 2020-10-23 05:19:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-23 05:19:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-23 05:19:10 --> Controller Class Initialized
DEBUG - 2020-10-23 05:19:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-23 05:19:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-23 05:19:10 --> Final output sent to browser
DEBUG - 2020-10-23 05:19:10 --> Total execution time: 0.8096
INFO - 2020-10-23 05:19:10 --> Config Class Initialized
INFO - 2020-10-23 05:19:10 --> Hooks Class Initialized
DEBUG - 2020-10-23 05:19:10 --> UTF-8 Support Enabled
INFO - 2020-10-23 05:19:10 --> Utf8 Class Initialized
INFO - 2020-10-23 05:19:10 --> URI Class Initialized
INFO - 2020-10-23 05:19:10 --> Router Class Initialized
INFO - 2020-10-23 05:19:11 --> Output Class Initialized
INFO - 2020-10-23 05:19:11 --> Security Class Initialized
DEBUG - 2020-10-23 05:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-23 05:19:11 --> Input Class Initialized
INFO - 2020-10-23 05:19:11 --> Language Class Initialized
INFO - 2020-10-23 05:19:11 --> Language Class Initialized
INFO - 2020-10-23 05:19:11 --> Config Class Initialized
INFO - 2020-10-23 05:19:11 --> Loader Class Initialized
INFO - 2020-10-23 05:19:11 --> Helper loaded: url_helper
INFO - 2020-10-23 05:19:11 --> Helper loaded: file_helper
INFO - 2020-10-23 05:19:11 --> Helper loaded: form_helper
INFO - 2020-10-23 05:19:11 --> Helper loaded: my_helper
INFO - 2020-10-23 05:19:11 --> Database Driver Class Initialized
DEBUG - 2020-10-23 05:19:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-23 05:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-23 05:19:11 --> Controller Class Initialized
INFO - 2020-10-23 06:03:01 --> Config Class Initialized
INFO - 2020-10-23 06:03:01 --> Hooks Class Initialized
DEBUG - 2020-10-23 06:03:01 --> UTF-8 Support Enabled
INFO - 2020-10-23 06:03:01 --> Utf8 Class Initialized
INFO - 2020-10-23 06:03:01 --> URI Class Initialized
INFO - 2020-10-23 06:03:01 --> Router Class Initialized
INFO - 2020-10-23 06:03:01 --> Output Class Initialized
INFO - 2020-10-23 06:03:01 --> Security Class Initialized
DEBUG - 2020-10-23 06:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-23 06:03:01 --> Input Class Initialized
INFO - 2020-10-23 06:03:01 --> Language Class Initialized
INFO - 2020-10-23 06:03:01 --> Language Class Initialized
INFO - 2020-10-23 06:03:01 --> Config Class Initialized
INFO - 2020-10-23 06:03:01 --> Loader Class Initialized
INFO - 2020-10-23 06:03:01 --> Helper loaded: url_helper
INFO - 2020-10-23 06:03:01 --> Helper loaded: file_helper
INFO - 2020-10-23 06:03:01 --> Helper loaded: form_helper
INFO - 2020-10-23 06:03:01 --> Helper loaded: my_helper
INFO - 2020-10-23 06:03:01 --> Database Driver Class Initialized
DEBUG - 2020-10-23 06:03:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-23 06:03:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-23 06:03:01 --> Controller Class Initialized
INFO - 2020-10-23 06:03:01 --> Helper loaded: cookie_helper
INFO - 2020-10-23 06:03:01 --> Config Class Initialized
INFO - 2020-10-23 06:03:01 --> Hooks Class Initialized
DEBUG - 2020-10-23 06:03:01 --> UTF-8 Support Enabled
INFO - 2020-10-23 06:03:01 --> Utf8 Class Initialized
INFO - 2020-10-23 06:03:01 --> URI Class Initialized
INFO - 2020-10-23 06:03:01 --> Router Class Initialized
INFO - 2020-10-23 06:03:01 --> Output Class Initialized
INFO - 2020-10-23 06:03:01 --> Security Class Initialized
DEBUG - 2020-10-23 06:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-23 06:03:01 --> Input Class Initialized
INFO - 2020-10-23 06:03:01 --> Language Class Initialized
INFO - 2020-10-23 06:03:01 --> Language Class Initialized
INFO - 2020-10-23 06:03:01 --> Config Class Initialized
INFO - 2020-10-23 06:03:01 --> Loader Class Initialized
INFO - 2020-10-23 06:03:01 --> Helper loaded: url_helper
INFO - 2020-10-23 06:03:01 --> Helper loaded: file_helper
INFO - 2020-10-23 06:03:01 --> Helper loaded: form_helper
INFO - 2020-10-23 06:03:01 --> Helper loaded: my_helper
INFO - 2020-10-23 06:03:01 --> Database Driver Class Initialized
DEBUG - 2020-10-23 06:03:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-23 06:03:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-23 06:03:01 --> Controller Class Initialized
DEBUG - 2020-10-23 06:03:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-23 06:03:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-23 06:03:01 --> Final output sent to browser
DEBUG - 2020-10-23 06:03:01 --> Total execution time: 0.1653
INFO - 2020-10-23 06:03:07 --> Config Class Initialized
INFO - 2020-10-23 06:03:07 --> Hooks Class Initialized
DEBUG - 2020-10-23 06:03:07 --> UTF-8 Support Enabled
INFO - 2020-10-23 06:03:07 --> Utf8 Class Initialized
INFO - 2020-10-23 06:03:07 --> URI Class Initialized
INFO - 2020-10-23 06:03:07 --> Router Class Initialized
INFO - 2020-10-23 06:03:07 --> Output Class Initialized
INFO - 2020-10-23 06:03:07 --> Security Class Initialized
DEBUG - 2020-10-23 06:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-23 06:03:07 --> Input Class Initialized
INFO - 2020-10-23 06:03:07 --> Language Class Initialized
INFO - 2020-10-23 06:03:07 --> Language Class Initialized
INFO - 2020-10-23 06:03:07 --> Config Class Initialized
INFO - 2020-10-23 06:03:07 --> Loader Class Initialized
INFO - 2020-10-23 06:03:07 --> Helper loaded: url_helper
INFO - 2020-10-23 06:03:07 --> Helper loaded: file_helper
INFO - 2020-10-23 06:03:07 --> Helper loaded: form_helper
INFO - 2020-10-23 06:03:07 --> Helper loaded: my_helper
INFO - 2020-10-23 06:03:07 --> Database Driver Class Initialized
DEBUG - 2020-10-23 06:03:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-23 06:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-23 06:03:07 --> Controller Class Initialized
INFO - 2020-10-23 06:03:07 --> Helper loaded: cookie_helper
INFO - 2020-10-23 06:03:07 --> Final output sent to browser
DEBUG - 2020-10-23 06:03:07 --> Total execution time: 0.1687
INFO - 2020-10-23 06:03:09 --> Config Class Initialized
INFO - 2020-10-23 06:03:09 --> Hooks Class Initialized
DEBUG - 2020-10-23 06:03:09 --> UTF-8 Support Enabled
INFO - 2020-10-23 06:03:09 --> Utf8 Class Initialized
INFO - 2020-10-23 06:03:09 --> URI Class Initialized
INFO - 2020-10-23 06:03:09 --> Router Class Initialized
INFO - 2020-10-23 06:03:09 --> Output Class Initialized
INFO - 2020-10-23 06:03:09 --> Security Class Initialized
DEBUG - 2020-10-23 06:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-23 06:03:09 --> Input Class Initialized
INFO - 2020-10-23 06:03:09 --> Language Class Initialized
INFO - 2020-10-23 06:03:09 --> Language Class Initialized
INFO - 2020-10-23 06:03:09 --> Config Class Initialized
INFO - 2020-10-23 06:03:09 --> Loader Class Initialized
INFO - 2020-10-23 06:03:09 --> Helper loaded: url_helper
INFO - 2020-10-23 06:03:09 --> Helper loaded: file_helper
INFO - 2020-10-23 06:03:09 --> Helper loaded: form_helper
INFO - 2020-10-23 06:03:09 --> Helper loaded: my_helper
INFO - 2020-10-23 06:03:09 --> Database Driver Class Initialized
DEBUG - 2020-10-23 06:03:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-23 06:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-23 06:03:09 --> Controller Class Initialized
DEBUG - 2020-10-23 06:03:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-23 06:03:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-23 06:03:09 --> Final output sent to browser
DEBUG - 2020-10-23 06:03:09 --> Total execution time: 0.2421
INFO - 2020-10-23 06:03:17 --> Config Class Initialized
INFO - 2020-10-23 06:03:17 --> Hooks Class Initialized
DEBUG - 2020-10-23 06:03:17 --> UTF-8 Support Enabled
INFO - 2020-10-23 06:03:17 --> Utf8 Class Initialized
INFO - 2020-10-23 06:03:17 --> URI Class Initialized
INFO - 2020-10-23 06:03:17 --> Router Class Initialized
INFO - 2020-10-23 06:03:17 --> Output Class Initialized
INFO - 2020-10-23 06:03:17 --> Security Class Initialized
DEBUG - 2020-10-23 06:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-23 06:03:17 --> Input Class Initialized
INFO - 2020-10-23 06:03:17 --> Language Class Initialized
INFO - 2020-10-23 06:03:17 --> Language Class Initialized
INFO - 2020-10-23 06:03:17 --> Config Class Initialized
INFO - 2020-10-23 06:03:17 --> Loader Class Initialized
INFO - 2020-10-23 06:03:17 --> Helper loaded: url_helper
INFO - 2020-10-23 06:03:17 --> Helper loaded: file_helper
INFO - 2020-10-23 06:03:17 --> Helper loaded: form_helper
INFO - 2020-10-23 06:03:17 --> Helper loaded: my_helper
INFO - 2020-10-23 06:03:17 --> Database Driver Class Initialized
DEBUG - 2020-10-23 06:03:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-23 06:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-23 06:03:17 --> Controller Class Initialized
DEBUG - 2020-10-23 06:03:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2020-10-23 06:03:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-23 06:03:17 --> Final output sent to browser
DEBUG - 2020-10-23 06:03:17 --> Total execution time: 0.1926
INFO - 2020-10-23 06:03:17 --> Config Class Initialized
INFO - 2020-10-23 06:03:17 --> Hooks Class Initialized
DEBUG - 2020-10-23 06:03:17 --> UTF-8 Support Enabled
INFO - 2020-10-23 06:03:17 --> Utf8 Class Initialized
INFO - 2020-10-23 06:03:17 --> URI Class Initialized
INFO - 2020-10-23 06:03:17 --> Router Class Initialized
INFO - 2020-10-23 06:03:17 --> Output Class Initialized
INFO - 2020-10-23 06:03:17 --> Security Class Initialized
DEBUG - 2020-10-23 06:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-23 06:03:17 --> Input Class Initialized
INFO - 2020-10-23 06:03:17 --> Language Class Initialized
INFO - 2020-10-23 06:03:17 --> Language Class Initialized
INFO - 2020-10-23 06:03:17 --> Config Class Initialized
INFO - 2020-10-23 06:03:17 --> Loader Class Initialized
INFO - 2020-10-23 06:03:17 --> Helper loaded: url_helper
INFO - 2020-10-23 06:03:17 --> Helper loaded: file_helper
INFO - 2020-10-23 06:03:17 --> Helper loaded: form_helper
INFO - 2020-10-23 06:03:17 --> Helper loaded: my_helper
INFO - 2020-10-23 06:03:17 --> Database Driver Class Initialized
DEBUG - 2020-10-23 06:03:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-23 06:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-23 06:03:17 --> Controller Class Initialized
INFO - 2020-10-23 06:03:19 --> Config Class Initialized
INFO - 2020-10-23 06:03:19 --> Hooks Class Initialized
DEBUG - 2020-10-23 06:03:19 --> UTF-8 Support Enabled
INFO - 2020-10-23 06:03:19 --> Utf8 Class Initialized
INFO - 2020-10-23 06:03:19 --> URI Class Initialized
INFO - 2020-10-23 06:03:19 --> Router Class Initialized
INFO - 2020-10-23 06:03:19 --> Output Class Initialized
INFO - 2020-10-23 06:03:19 --> Security Class Initialized
DEBUG - 2020-10-23 06:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-23 06:03:19 --> Input Class Initialized
INFO - 2020-10-23 06:03:19 --> Language Class Initialized
INFO - 2020-10-23 06:03:19 --> Language Class Initialized
INFO - 2020-10-23 06:03:19 --> Config Class Initialized
INFO - 2020-10-23 06:03:19 --> Loader Class Initialized
INFO - 2020-10-23 06:03:19 --> Helper loaded: url_helper
INFO - 2020-10-23 06:03:19 --> Helper loaded: file_helper
INFO - 2020-10-23 06:03:19 --> Helper loaded: form_helper
INFO - 2020-10-23 06:03:19 --> Helper loaded: my_helper
INFO - 2020-10-23 06:03:19 --> Database Driver Class Initialized
DEBUG - 2020-10-23 06:03:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-23 06:03:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-23 06:03:19 --> Controller Class Initialized
DEBUG - 2020-10-23 06:03:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-10-23 06:03:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-23 06:03:19 --> Final output sent to browser
DEBUG - 2020-10-23 06:03:19 --> Total execution time: 0.2597
INFO - 2020-10-23 06:03:19 --> Config Class Initialized
INFO - 2020-10-23 06:03:19 --> Hooks Class Initialized
DEBUG - 2020-10-23 06:03:19 --> UTF-8 Support Enabled
INFO - 2020-10-23 06:03:19 --> Utf8 Class Initialized
INFO - 2020-10-23 06:03:19 --> URI Class Initialized
INFO - 2020-10-23 06:03:19 --> Router Class Initialized
INFO - 2020-10-23 06:03:19 --> Output Class Initialized
INFO - 2020-10-23 06:03:19 --> Security Class Initialized
DEBUG - 2020-10-23 06:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-23 06:03:19 --> Input Class Initialized
INFO - 2020-10-23 06:03:19 --> Language Class Initialized
INFO - 2020-10-23 06:03:19 --> Language Class Initialized
INFO - 2020-10-23 06:03:19 --> Config Class Initialized
INFO - 2020-10-23 06:03:19 --> Loader Class Initialized
INFO - 2020-10-23 06:03:19 --> Helper loaded: url_helper
INFO - 2020-10-23 06:03:19 --> Helper loaded: file_helper
INFO - 2020-10-23 06:03:19 --> Helper loaded: form_helper
INFO - 2020-10-23 06:03:19 --> Helper loaded: my_helper
INFO - 2020-10-23 06:03:19 --> Database Driver Class Initialized
DEBUG - 2020-10-23 06:03:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-23 06:03:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-23 06:03:19 --> Controller Class Initialized
INFO - 2020-10-23 06:03:21 --> Config Class Initialized
INFO - 2020-10-23 06:03:21 --> Hooks Class Initialized
DEBUG - 2020-10-23 06:03:21 --> UTF-8 Support Enabled
INFO - 2020-10-23 06:03:21 --> Utf8 Class Initialized
INFO - 2020-10-23 06:03:21 --> URI Class Initialized
INFO - 2020-10-23 06:03:21 --> Router Class Initialized
INFO - 2020-10-23 06:03:21 --> Output Class Initialized
INFO - 2020-10-23 06:03:21 --> Security Class Initialized
DEBUG - 2020-10-23 06:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-23 06:03:21 --> Input Class Initialized
INFO - 2020-10-23 06:03:21 --> Language Class Initialized
INFO - 2020-10-23 06:03:21 --> Language Class Initialized
INFO - 2020-10-23 06:03:21 --> Config Class Initialized
INFO - 2020-10-23 06:03:21 --> Loader Class Initialized
INFO - 2020-10-23 06:03:21 --> Helper loaded: url_helper
INFO - 2020-10-23 06:03:21 --> Helper loaded: file_helper
INFO - 2020-10-23 06:03:21 --> Helper loaded: form_helper
INFO - 2020-10-23 06:03:21 --> Helper loaded: my_helper
INFO - 2020-10-23 06:03:21 --> Database Driver Class Initialized
DEBUG - 2020-10-23 06:03:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-23 06:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-23 06:03:21 --> Controller Class Initialized
DEBUG - 2020-10-23 06:03:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-23 06:03:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-23 06:03:22 --> Final output sent to browser
DEBUG - 2020-10-23 06:03:22 --> Total execution time: 0.1727
INFO - 2020-10-23 06:03:22 --> Config Class Initialized
INFO - 2020-10-23 06:03:22 --> Hooks Class Initialized
DEBUG - 2020-10-23 06:03:22 --> UTF-8 Support Enabled
INFO - 2020-10-23 06:03:22 --> Utf8 Class Initialized
INFO - 2020-10-23 06:03:22 --> URI Class Initialized
INFO - 2020-10-23 06:03:22 --> Router Class Initialized
INFO - 2020-10-23 06:03:22 --> Output Class Initialized
INFO - 2020-10-23 06:03:22 --> Security Class Initialized
DEBUG - 2020-10-23 06:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-23 06:03:22 --> Input Class Initialized
INFO - 2020-10-23 06:03:22 --> Language Class Initialized
INFO - 2020-10-23 06:03:22 --> Language Class Initialized
INFO - 2020-10-23 06:03:22 --> Config Class Initialized
INFO - 2020-10-23 06:03:22 --> Loader Class Initialized
INFO - 2020-10-23 06:03:22 --> Helper loaded: url_helper
INFO - 2020-10-23 06:03:22 --> Helper loaded: file_helper
INFO - 2020-10-23 06:03:22 --> Helper loaded: form_helper
INFO - 2020-10-23 06:03:22 --> Helper loaded: my_helper
INFO - 2020-10-23 06:03:22 --> Database Driver Class Initialized
DEBUG - 2020-10-23 06:03:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-23 06:03:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-23 06:03:22 --> Controller Class Initialized
INFO - 2020-10-23 06:03:23 --> Config Class Initialized
INFO - 2020-10-23 06:03:23 --> Hooks Class Initialized
DEBUG - 2020-10-23 06:03:23 --> UTF-8 Support Enabled
INFO - 2020-10-23 06:03:23 --> Utf8 Class Initialized
INFO - 2020-10-23 06:03:23 --> URI Class Initialized
INFO - 2020-10-23 06:03:23 --> Router Class Initialized
INFO - 2020-10-23 06:03:23 --> Output Class Initialized
INFO - 2020-10-23 06:03:23 --> Security Class Initialized
DEBUG - 2020-10-23 06:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-23 06:03:23 --> Input Class Initialized
INFO - 2020-10-23 06:03:23 --> Language Class Initialized
INFO - 2020-10-23 06:03:23 --> Language Class Initialized
INFO - 2020-10-23 06:03:23 --> Config Class Initialized
INFO - 2020-10-23 06:03:23 --> Loader Class Initialized
INFO - 2020-10-23 06:03:23 --> Helper loaded: url_helper
INFO - 2020-10-23 06:03:23 --> Helper loaded: file_helper
INFO - 2020-10-23 06:03:23 --> Helper loaded: form_helper
INFO - 2020-10-23 06:03:23 --> Helper loaded: my_helper
INFO - 2020-10-23 06:03:23 --> Database Driver Class Initialized
DEBUG - 2020-10-23 06:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-23 06:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-23 06:03:23 --> Controller Class Initialized
DEBUG - 2020-10-23 06:03:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-10-23 06:03:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-23 06:03:23 --> Final output sent to browser
DEBUG - 2020-10-23 06:03:23 --> Total execution time: 0.1841
INFO - 2020-10-23 06:03:23 --> Config Class Initialized
INFO - 2020-10-23 06:03:23 --> Hooks Class Initialized
DEBUG - 2020-10-23 06:03:23 --> UTF-8 Support Enabled
INFO - 2020-10-23 06:03:23 --> Utf8 Class Initialized
INFO - 2020-10-23 06:03:23 --> URI Class Initialized
INFO - 2020-10-23 06:03:23 --> Router Class Initialized
INFO - 2020-10-23 06:03:23 --> Output Class Initialized
INFO - 2020-10-23 06:03:23 --> Security Class Initialized
DEBUG - 2020-10-23 06:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-23 06:03:23 --> Input Class Initialized
INFO - 2020-10-23 06:03:23 --> Language Class Initialized
INFO - 2020-10-23 06:03:23 --> Language Class Initialized
INFO - 2020-10-23 06:03:23 --> Config Class Initialized
INFO - 2020-10-23 06:03:23 --> Loader Class Initialized
INFO - 2020-10-23 06:03:23 --> Helper loaded: url_helper
INFO - 2020-10-23 06:03:23 --> Helper loaded: file_helper
INFO - 2020-10-23 06:03:23 --> Helper loaded: form_helper
INFO - 2020-10-23 06:03:23 --> Helper loaded: my_helper
INFO - 2020-10-23 06:03:23 --> Database Driver Class Initialized
DEBUG - 2020-10-23 06:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-23 06:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-23 06:03:23 --> Controller Class Initialized
INFO - 2020-10-23 06:03:24 --> Config Class Initialized
INFO - 2020-10-23 06:03:24 --> Hooks Class Initialized
DEBUG - 2020-10-23 06:03:24 --> UTF-8 Support Enabled
INFO - 2020-10-23 06:03:24 --> Utf8 Class Initialized
INFO - 2020-10-23 06:03:24 --> URI Class Initialized
INFO - 2020-10-23 06:03:24 --> Router Class Initialized
INFO - 2020-10-23 06:03:24 --> Output Class Initialized
INFO - 2020-10-23 06:03:24 --> Security Class Initialized
DEBUG - 2020-10-23 06:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-23 06:03:24 --> Input Class Initialized
INFO - 2020-10-23 06:03:24 --> Language Class Initialized
INFO - 2020-10-23 06:03:24 --> Language Class Initialized
INFO - 2020-10-23 06:03:24 --> Config Class Initialized
INFO - 2020-10-23 06:03:24 --> Loader Class Initialized
INFO - 2020-10-23 06:03:24 --> Helper loaded: url_helper
INFO - 2020-10-23 06:03:25 --> Helper loaded: file_helper
INFO - 2020-10-23 06:03:25 --> Helper loaded: form_helper
INFO - 2020-10-23 06:03:25 --> Helper loaded: my_helper
INFO - 2020-10-23 06:03:25 --> Database Driver Class Initialized
DEBUG - 2020-10-23 06:03:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-23 06:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-23 06:03:25 --> Controller Class Initialized
ERROR - 2020-10-23 06:03:25 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 235
DEBUG - 2020-10-23 06:03:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2020-10-23 06:03:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-23 06:03:25 --> Final output sent to browser
DEBUG - 2020-10-23 06:03:25 --> Total execution time: 0.2587
INFO - 2020-10-23 06:04:57 --> Config Class Initialized
INFO - 2020-10-23 06:04:57 --> Hooks Class Initialized
DEBUG - 2020-10-23 06:04:57 --> UTF-8 Support Enabled
INFO - 2020-10-23 06:04:57 --> Utf8 Class Initialized
INFO - 2020-10-23 06:04:57 --> URI Class Initialized
INFO - 2020-10-23 06:04:57 --> Router Class Initialized
INFO - 2020-10-23 06:04:57 --> Output Class Initialized
INFO - 2020-10-23 06:04:57 --> Security Class Initialized
DEBUG - 2020-10-23 06:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-23 06:04:57 --> Input Class Initialized
INFO - 2020-10-23 06:04:57 --> Language Class Initialized
INFO - 2020-10-23 06:04:57 --> Language Class Initialized
INFO - 2020-10-23 06:04:57 --> Config Class Initialized
INFO - 2020-10-23 06:04:57 --> Loader Class Initialized
INFO - 2020-10-23 06:04:57 --> Helper loaded: url_helper
INFO - 2020-10-23 06:04:57 --> Helper loaded: file_helper
INFO - 2020-10-23 06:04:57 --> Helper loaded: form_helper
INFO - 2020-10-23 06:04:57 --> Helper loaded: my_helper
INFO - 2020-10-23 06:04:57 --> Database Driver Class Initialized
DEBUG - 2020-10-23 06:04:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-23 06:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-23 06:04:57 --> Controller Class Initialized
ERROR - 2020-10-23 06:04:57 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 235
DEBUG - 2020-10-23 06:04:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2020-10-23 06:04:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-23 06:04:57 --> Final output sent to browser
DEBUG - 2020-10-23 06:04:57 --> Total execution time: 0.2092
INFO - 2020-10-23 06:05:16 --> Config Class Initialized
INFO - 2020-10-23 06:05:16 --> Hooks Class Initialized
DEBUG - 2020-10-23 06:05:16 --> UTF-8 Support Enabled
INFO - 2020-10-23 06:05:16 --> Utf8 Class Initialized
INFO - 2020-10-23 06:05:16 --> URI Class Initialized
INFO - 2020-10-23 06:05:16 --> Router Class Initialized
INFO - 2020-10-23 06:05:16 --> Output Class Initialized
INFO - 2020-10-23 06:05:16 --> Security Class Initialized
DEBUG - 2020-10-23 06:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-23 06:05:16 --> Input Class Initialized
INFO - 2020-10-23 06:05:16 --> Language Class Initialized
INFO - 2020-10-23 06:05:16 --> Language Class Initialized
INFO - 2020-10-23 06:05:16 --> Config Class Initialized
INFO - 2020-10-23 06:05:16 --> Loader Class Initialized
INFO - 2020-10-23 06:05:16 --> Helper loaded: url_helper
INFO - 2020-10-23 06:05:16 --> Helper loaded: file_helper
INFO - 2020-10-23 06:05:16 --> Helper loaded: form_helper
INFO - 2020-10-23 06:05:16 --> Helper loaded: my_helper
INFO - 2020-10-23 06:05:16 --> Database Driver Class Initialized
DEBUG - 2020-10-23 06:05:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-23 06:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-23 06:05:16 --> Controller Class Initialized
ERROR - 2020-10-23 06:05:16 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 235
DEBUG - 2020-10-23 06:05:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2020-10-23 06:05:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-23 06:05:16 --> Final output sent to browser
DEBUG - 2020-10-23 06:05:16 --> Total execution time: 0.2058
INFO - 2020-10-23 06:05:47 --> Config Class Initialized
INFO - 2020-10-23 06:05:47 --> Hooks Class Initialized
DEBUG - 2020-10-23 06:05:47 --> UTF-8 Support Enabled
INFO - 2020-10-23 06:05:47 --> Utf8 Class Initialized
INFO - 2020-10-23 06:05:47 --> URI Class Initialized
INFO - 2020-10-23 06:05:47 --> Router Class Initialized
INFO - 2020-10-23 06:05:47 --> Output Class Initialized
INFO - 2020-10-23 06:05:47 --> Security Class Initialized
DEBUG - 2020-10-23 06:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-23 06:05:47 --> Input Class Initialized
INFO - 2020-10-23 06:05:47 --> Language Class Initialized
INFO - 2020-10-23 06:05:47 --> Language Class Initialized
INFO - 2020-10-23 06:05:47 --> Config Class Initialized
INFO - 2020-10-23 06:05:47 --> Loader Class Initialized
INFO - 2020-10-23 06:05:47 --> Helper loaded: url_helper
INFO - 2020-10-23 06:05:47 --> Helper loaded: file_helper
INFO - 2020-10-23 06:05:47 --> Helper loaded: form_helper
INFO - 2020-10-23 06:05:47 --> Helper loaded: my_helper
INFO - 2020-10-23 06:05:47 --> Database Driver Class Initialized
DEBUG - 2020-10-23 06:05:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-23 06:05:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-23 06:05:47 --> Controller Class Initialized
ERROR - 2020-10-23 06:05:47 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 235
DEBUG - 2020-10-23 06:05:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2020-10-23 06:05:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-23 06:05:47 --> Final output sent to browser
DEBUG - 2020-10-23 06:05:47 --> Total execution time: 0.2650
INFO - 2020-10-23 06:06:07 --> Config Class Initialized
INFO - 2020-10-23 06:06:07 --> Hooks Class Initialized
DEBUG - 2020-10-23 06:06:07 --> UTF-8 Support Enabled
INFO - 2020-10-23 06:06:07 --> Utf8 Class Initialized
INFO - 2020-10-23 06:06:07 --> URI Class Initialized
INFO - 2020-10-23 06:06:07 --> Router Class Initialized
INFO - 2020-10-23 06:06:07 --> Output Class Initialized
INFO - 2020-10-23 06:06:07 --> Security Class Initialized
DEBUG - 2020-10-23 06:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-23 06:06:07 --> Input Class Initialized
INFO - 2020-10-23 06:06:07 --> Language Class Initialized
INFO - 2020-10-23 06:06:07 --> Language Class Initialized
INFO - 2020-10-23 06:06:07 --> Config Class Initialized
INFO - 2020-10-23 06:06:07 --> Loader Class Initialized
INFO - 2020-10-23 06:06:08 --> Helper loaded: url_helper
INFO - 2020-10-23 06:06:08 --> Helper loaded: file_helper
INFO - 2020-10-23 06:06:08 --> Helper loaded: form_helper
INFO - 2020-10-23 06:06:08 --> Helper loaded: my_helper
INFO - 2020-10-23 06:06:08 --> Database Driver Class Initialized
DEBUG - 2020-10-23 06:06:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-23 06:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-23 06:06:08 --> Controller Class Initialized
ERROR - 2020-10-23 06:06:08 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 235
DEBUG - 2020-10-23 06:06:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2020-10-23 06:06:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-23 06:06:08 --> Final output sent to browser
DEBUG - 2020-10-23 06:06:08 --> Total execution time: 0.2135
INFO - 2020-10-23 06:08:57 --> Config Class Initialized
INFO - 2020-10-23 06:08:57 --> Hooks Class Initialized
DEBUG - 2020-10-23 06:08:57 --> UTF-8 Support Enabled
INFO - 2020-10-23 06:08:57 --> Utf8 Class Initialized
INFO - 2020-10-23 06:08:57 --> URI Class Initialized
INFO - 2020-10-23 06:08:57 --> Router Class Initialized
INFO - 2020-10-23 06:08:57 --> Output Class Initialized
INFO - 2020-10-23 06:08:57 --> Security Class Initialized
DEBUG - 2020-10-23 06:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-23 06:08:57 --> Input Class Initialized
INFO - 2020-10-23 06:08:57 --> Language Class Initialized
ERROR - 2020-10-23 06:08:57 --> 404 Page Not Found: /index
INFO - 2020-10-23 06:13:04 --> Config Class Initialized
INFO - 2020-10-23 06:13:04 --> Hooks Class Initialized
DEBUG - 2020-10-23 06:13:04 --> UTF-8 Support Enabled
INFO - 2020-10-23 06:13:04 --> Utf8 Class Initialized
INFO - 2020-10-23 06:13:04 --> URI Class Initialized
INFO - 2020-10-23 06:13:04 --> Router Class Initialized
INFO - 2020-10-23 06:13:04 --> Output Class Initialized
INFO - 2020-10-23 06:13:04 --> Security Class Initialized
DEBUG - 2020-10-23 06:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-23 06:13:04 --> Input Class Initialized
INFO - 2020-10-23 06:13:04 --> Language Class Initialized
INFO - 2020-10-23 06:13:04 --> Language Class Initialized
INFO - 2020-10-23 06:13:04 --> Config Class Initialized
INFO - 2020-10-23 06:13:04 --> Loader Class Initialized
INFO - 2020-10-23 06:13:04 --> Helper loaded: url_helper
INFO - 2020-10-23 06:13:04 --> Helper loaded: file_helper
INFO - 2020-10-23 06:13:04 --> Helper loaded: form_helper
INFO - 2020-10-23 06:13:04 --> Helper loaded: my_helper
INFO - 2020-10-23 06:13:04 --> Database Driver Class Initialized
DEBUG - 2020-10-23 06:13:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-23 06:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-23 06:13:04 --> Controller Class Initialized
INFO - 2020-10-23 06:13:05 --> Upload Class Initialized
INFO - 2020-10-23 06:13:05 --> Language file loaded: language/english/upload_lang.php
ERROR - 2020-10-23 06:13:05 --> The upload path does not appear to be valid.
INFO - 2020-10-23 06:13:05 --> Config Class Initialized
INFO - 2020-10-23 06:13:05 --> Hooks Class Initialized
DEBUG - 2020-10-23 06:13:05 --> UTF-8 Support Enabled
INFO - 2020-10-23 06:13:05 --> Utf8 Class Initialized
INFO - 2020-10-23 06:13:05 --> URI Class Initialized
INFO - 2020-10-23 06:13:05 --> Router Class Initialized
INFO - 2020-10-23 06:13:05 --> Output Class Initialized
INFO - 2020-10-23 06:13:05 --> Security Class Initialized
DEBUG - 2020-10-23 06:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-23 06:13:05 --> Input Class Initialized
INFO - 2020-10-23 06:13:05 --> Language Class Initialized
INFO - 2020-10-23 06:13:05 --> Language Class Initialized
INFO - 2020-10-23 06:13:05 --> Config Class Initialized
INFO - 2020-10-23 06:13:05 --> Loader Class Initialized
INFO - 2020-10-23 06:13:05 --> Helper loaded: url_helper
INFO - 2020-10-23 06:13:05 --> Helper loaded: file_helper
INFO - 2020-10-23 06:13:05 --> Helper loaded: form_helper
INFO - 2020-10-23 06:13:05 --> Helper loaded: my_helper
INFO - 2020-10-23 06:13:05 --> Database Driver Class Initialized
DEBUG - 2020-10-23 06:13:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-23 06:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-23 06:13:05 --> Controller Class Initialized
DEBUG - 2020-10-23 06:13:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-10-23 06:13:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-23 06:13:05 --> Final output sent to browser
DEBUG - 2020-10-23 06:13:05 --> Total execution time: 0.2557
INFO - 2020-10-23 06:13:06 --> Config Class Initialized
INFO - 2020-10-23 06:13:06 --> Hooks Class Initialized
DEBUG - 2020-10-23 06:13:06 --> UTF-8 Support Enabled
INFO - 2020-10-23 06:13:06 --> Utf8 Class Initialized
INFO - 2020-10-23 06:13:06 --> URI Class Initialized
INFO - 2020-10-23 06:13:06 --> Router Class Initialized
INFO - 2020-10-23 06:13:06 --> Output Class Initialized
INFO - 2020-10-23 06:13:06 --> Security Class Initialized
DEBUG - 2020-10-23 06:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-23 06:13:06 --> Input Class Initialized
INFO - 2020-10-23 06:13:06 --> Language Class Initialized
INFO - 2020-10-23 06:13:06 --> Language Class Initialized
INFO - 2020-10-23 06:13:06 --> Config Class Initialized
INFO - 2020-10-23 06:13:06 --> Loader Class Initialized
INFO - 2020-10-23 06:13:06 --> Helper loaded: url_helper
INFO - 2020-10-23 06:13:06 --> Helper loaded: file_helper
INFO - 2020-10-23 06:13:06 --> Helper loaded: form_helper
INFO - 2020-10-23 06:13:06 --> Helper loaded: my_helper
INFO - 2020-10-23 06:13:06 --> Database Driver Class Initialized
DEBUG - 2020-10-23 06:13:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-23 06:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-23 06:13:06 --> Controller Class Initialized
INFO - 2020-10-23 06:18:57 --> Config Class Initialized
INFO - 2020-10-23 06:18:57 --> Hooks Class Initialized
DEBUG - 2020-10-23 06:18:57 --> UTF-8 Support Enabled
INFO - 2020-10-23 06:18:57 --> Utf8 Class Initialized
INFO - 2020-10-23 06:18:57 --> URI Class Initialized
INFO - 2020-10-23 06:18:57 --> Router Class Initialized
INFO - 2020-10-23 06:18:57 --> Output Class Initialized
INFO - 2020-10-23 06:18:57 --> Security Class Initialized
DEBUG - 2020-10-23 06:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-23 06:18:57 --> Input Class Initialized
INFO - 2020-10-23 06:18:57 --> Language Class Initialized
INFO - 2020-10-23 06:18:57 --> Language Class Initialized
INFO - 2020-10-23 06:18:57 --> Config Class Initialized
INFO - 2020-10-23 06:18:57 --> Loader Class Initialized
INFO - 2020-10-23 06:18:57 --> Helper loaded: url_helper
INFO - 2020-10-23 06:18:57 --> Helper loaded: file_helper
INFO - 2020-10-23 06:18:57 --> Helper loaded: form_helper
INFO - 2020-10-23 06:18:57 --> Helper loaded: my_helper
INFO - 2020-10-23 06:18:57 --> Database Driver Class Initialized
DEBUG - 2020-10-23 06:18:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-23 06:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-23 06:18:57 --> Controller Class Initialized
ERROR - 2020-10-23 06:18:57 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 235
DEBUG - 2020-10-23 06:18:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2020-10-23 06:18:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-23 06:18:57 --> Final output sent to browser
DEBUG - 2020-10-23 06:18:57 --> Total execution time: 0.1906
INFO - 2020-10-23 06:32:15 --> Config Class Initialized
INFO - 2020-10-23 06:32:15 --> Hooks Class Initialized
DEBUG - 2020-10-23 06:32:15 --> UTF-8 Support Enabled
INFO - 2020-10-23 06:32:15 --> Utf8 Class Initialized
INFO - 2020-10-23 06:32:15 --> URI Class Initialized
INFO - 2020-10-23 06:32:15 --> Router Class Initialized
INFO - 2020-10-23 06:32:15 --> Output Class Initialized
INFO - 2020-10-23 06:32:15 --> Security Class Initialized
DEBUG - 2020-10-23 06:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-23 06:32:15 --> Input Class Initialized
INFO - 2020-10-23 06:32:15 --> Language Class Initialized
INFO - 2020-10-23 06:32:15 --> Language Class Initialized
INFO - 2020-10-23 06:32:15 --> Config Class Initialized
INFO - 2020-10-23 06:32:15 --> Loader Class Initialized
INFO - 2020-10-23 06:32:15 --> Helper loaded: url_helper
INFO - 2020-10-23 06:32:15 --> Helper loaded: file_helper
INFO - 2020-10-23 06:32:15 --> Helper loaded: form_helper
INFO - 2020-10-23 06:32:15 --> Helper loaded: my_helper
INFO - 2020-10-23 06:32:15 --> Database Driver Class Initialized
DEBUG - 2020-10-23 06:32:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-23 06:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-23 06:32:15 --> Controller Class Initialized
ERROR - 2020-10-23 06:32:15 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 235
DEBUG - 2020-10-23 06:32:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2020-10-23 06:32:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-23 06:32:15 --> Final output sent to browser
DEBUG - 2020-10-23 06:32:15 --> Total execution time: 0.2063
INFO - 2020-10-23 06:33:39 --> Config Class Initialized
INFO - 2020-10-23 06:33:39 --> Hooks Class Initialized
DEBUG - 2020-10-23 06:33:39 --> UTF-8 Support Enabled
INFO - 2020-10-23 06:33:39 --> Utf8 Class Initialized
INFO - 2020-10-23 06:33:39 --> URI Class Initialized
INFO - 2020-10-23 06:33:39 --> Router Class Initialized
INFO - 2020-10-23 06:33:39 --> Output Class Initialized
INFO - 2020-10-23 06:33:39 --> Security Class Initialized
DEBUG - 2020-10-23 06:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-23 06:33:39 --> Input Class Initialized
INFO - 2020-10-23 06:33:39 --> Language Class Initialized
INFO - 2020-10-23 06:33:39 --> Language Class Initialized
INFO - 2020-10-23 06:33:39 --> Config Class Initialized
INFO - 2020-10-23 06:33:39 --> Loader Class Initialized
INFO - 2020-10-23 06:33:39 --> Helper loaded: url_helper
INFO - 2020-10-23 06:33:39 --> Helper loaded: file_helper
INFO - 2020-10-23 06:33:39 --> Helper loaded: form_helper
INFO - 2020-10-23 06:33:39 --> Helper loaded: my_helper
INFO - 2020-10-23 06:33:39 --> Database Driver Class Initialized
DEBUG - 2020-10-23 06:33:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-23 06:33:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-23 06:33:39 --> Controller Class Initialized
ERROR - 2020-10-23 06:33:39 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 235
DEBUG - 2020-10-23 06:33:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2020-10-23 06:33:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-23 06:33:39 --> Final output sent to browser
DEBUG - 2020-10-23 06:33:39 --> Total execution time: 0.2018
INFO - 2020-10-23 06:35:06 --> Config Class Initialized
INFO - 2020-10-23 06:35:06 --> Hooks Class Initialized
DEBUG - 2020-10-23 06:35:06 --> UTF-8 Support Enabled
INFO - 2020-10-23 06:35:06 --> Utf8 Class Initialized
INFO - 2020-10-23 06:35:06 --> URI Class Initialized
INFO - 2020-10-23 06:35:06 --> Router Class Initialized
INFO - 2020-10-23 06:35:06 --> Output Class Initialized
INFO - 2020-10-23 06:35:06 --> Security Class Initialized
DEBUG - 2020-10-23 06:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-23 06:35:06 --> Input Class Initialized
INFO - 2020-10-23 06:35:06 --> Language Class Initialized
INFO - 2020-10-23 06:35:06 --> Language Class Initialized
INFO - 2020-10-23 06:35:06 --> Config Class Initialized
INFO - 2020-10-23 06:35:06 --> Loader Class Initialized
INFO - 2020-10-23 06:35:06 --> Helper loaded: url_helper
INFO - 2020-10-23 06:35:06 --> Helper loaded: file_helper
INFO - 2020-10-23 06:35:06 --> Helper loaded: form_helper
INFO - 2020-10-23 06:35:06 --> Helper loaded: my_helper
INFO - 2020-10-23 06:35:06 --> Database Driver Class Initialized
DEBUG - 2020-10-23 06:35:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-23 06:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-23 06:35:06 --> Controller Class Initialized
DEBUG - 2020-10-23 06:35:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-10-23 06:35:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-23 06:35:06 --> Final output sent to browser
DEBUG - 2020-10-23 06:35:06 --> Total execution time: 0.1981
INFO - 2020-10-23 06:35:06 --> Config Class Initialized
INFO - 2020-10-23 06:35:06 --> Hooks Class Initialized
DEBUG - 2020-10-23 06:35:06 --> UTF-8 Support Enabled
INFO - 2020-10-23 06:35:06 --> Utf8 Class Initialized
INFO - 2020-10-23 06:35:06 --> URI Class Initialized
INFO - 2020-10-23 06:35:06 --> Router Class Initialized
INFO - 2020-10-23 06:35:06 --> Output Class Initialized
INFO - 2020-10-23 06:35:06 --> Security Class Initialized
DEBUG - 2020-10-23 06:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-23 06:35:06 --> Input Class Initialized
INFO - 2020-10-23 06:35:06 --> Language Class Initialized
INFO - 2020-10-23 06:35:06 --> Language Class Initialized
INFO - 2020-10-23 06:35:06 --> Config Class Initialized
INFO - 2020-10-23 06:35:06 --> Loader Class Initialized
INFO - 2020-10-23 06:35:06 --> Helper loaded: url_helper
INFO - 2020-10-23 06:35:06 --> Helper loaded: file_helper
INFO - 2020-10-23 06:35:06 --> Helper loaded: form_helper
INFO - 2020-10-23 06:35:06 --> Helper loaded: my_helper
INFO - 2020-10-23 06:35:06 --> Database Driver Class Initialized
DEBUG - 2020-10-23 06:35:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-23 06:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-23 06:35:06 --> Controller Class Initialized
INFO - 2020-10-23 06:35:07 --> Config Class Initialized
INFO - 2020-10-23 06:35:07 --> Hooks Class Initialized
DEBUG - 2020-10-23 06:35:07 --> UTF-8 Support Enabled
INFO - 2020-10-23 06:35:07 --> Utf8 Class Initialized
INFO - 2020-10-23 06:35:07 --> URI Class Initialized
INFO - 2020-10-23 06:35:07 --> Router Class Initialized
INFO - 2020-10-23 06:35:07 --> Output Class Initialized
INFO - 2020-10-23 06:35:07 --> Security Class Initialized
DEBUG - 2020-10-23 06:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-23 06:35:07 --> Input Class Initialized
INFO - 2020-10-23 06:35:07 --> Language Class Initialized
INFO - 2020-10-23 06:35:07 --> Language Class Initialized
INFO - 2020-10-23 06:35:07 --> Config Class Initialized
INFO - 2020-10-23 06:35:07 --> Loader Class Initialized
INFO - 2020-10-23 06:35:07 --> Helper loaded: url_helper
INFO - 2020-10-23 06:35:07 --> Helper loaded: file_helper
INFO - 2020-10-23 06:35:07 --> Helper loaded: form_helper
INFO - 2020-10-23 06:35:07 --> Helper loaded: my_helper
INFO - 2020-10-23 06:35:07 --> Database Driver Class Initialized
DEBUG - 2020-10-23 06:35:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-23 06:35:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-23 06:35:07 --> Controller Class Initialized
DEBUG - 2020-10-23 06:35:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form_import.php
DEBUG - 2020-10-23 06:35:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-23 06:35:07 --> Final output sent to browser
DEBUG - 2020-10-23 06:35:07 --> Total execution time: 0.2000
INFO - 2020-10-23 06:35:10 --> Config Class Initialized
INFO - 2020-10-23 06:35:10 --> Hooks Class Initialized
DEBUG - 2020-10-23 06:35:10 --> UTF-8 Support Enabled
INFO - 2020-10-23 06:35:10 --> Utf8 Class Initialized
INFO - 2020-10-23 06:35:10 --> URI Class Initialized
INFO - 2020-10-23 06:35:10 --> Router Class Initialized
INFO - 2020-10-23 06:35:10 --> Output Class Initialized
INFO - 2020-10-23 06:35:10 --> Security Class Initialized
DEBUG - 2020-10-23 06:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-23 06:35:10 --> Input Class Initialized
INFO - 2020-10-23 06:35:10 --> Language Class Initialized
INFO - 2020-10-23 06:35:10 --> Language Class Initialized
INFO - 2020-10-23 06:35:10 --> Config Class Initialized
INFO - 2020-10-23 06:35:10 --> Loader Class Initialized
INFO - 2020-10-23 06:35:10 --> Helper loaded: url_helper
INFO - 2020-10-23 06:35:10 --> Helper loaded: file_helper
INFO - 2020-10-23 06:35:10 --> Helper loaded: form_helper
INFO - 2020-10-23 06:35:10 --> Helper loaded: my_helper
INFO - 2020-10-23 06:35:10 --> Database Driver Class Initialized
DEBUG - 2020-10-23 06:35:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-23 06:35:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-23 06:35:10 --> Controller Class Initialized
DEBUG - 2020-10-23 06:35:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-10-23 06:35:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-23 06:35:10 --> Final output sent to browser
DEBUG - 2020-10-23 06:35:10 --> Total execution time: 0.2104
INFO - 2020-10-23 06:35:11 --> Config Class Initialized
INFO - 2020-10-23 06:35:11 --> Hooks Class Initialized
DEBUG - 2020-10-23 06:35:11 --> UTF-8 Support Enabled
INFO - 2020-10-23 06:35:11 --> Utf8 Class Initialized
INFO - 2020-10-23 06:35:11 --> URI Class Initialized
INFO - 2020-10-23 06:35:11 --> Router Class Initialized
INFO - 2020-10-23 06:35:11 --> Output Class Initialized
INFO - 2020-10-23 06:35:11 --> Security Class Initialized
DEBUG - 2020-10-23 06:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-23 06:35:11 --> Input Class Initialized
INFO - 2020-10-23 06:35:11 --> Language Class Initialized
INFO - 2020-10-23 06:35:11 --> Language Class Initialized
INFO - 2020-10-23 06:35:11 --> Config Class Initialized
INFO - 2020-10-23 06:35:11 --> Loader Class Initialized
INFO - 2020-10-23 06:35:11 --> Helper loaded: url_helper
INFO - 2020-10-23 06:35:11 --> Helper loaded: file_helper
INFO - 2020-10-23 06:35:11 --> Helper loaded: form_helper
INFO - 2020-10-23 06:35:11 --> Helper loaded: my_helper
INFO - 2020-10-23 06:35:11 --> Database Driver Class Initialized
DEBUG - 2020-10-23 06:35:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-23 06:35:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-23 06:35:11 --> Controller Class Initialized
INFO - 2020-10-23 06:35:36 --> Config Class Initialized
INFO - 2020-10-23 06:35:36 --> Hooks Class Initialized
DEBUG - 2020-10-23 06:35:36 --> UTF-8 Support Enabled
INFO - 2020-10-23 06:35:36 --> Utf8 Class Initialized
INFO - 2020-10-23 06:35:36 --> URI Class Initialized
INFO - 2020-10-23 06:35:36 --> Router Class Initialized
INFO - 2020-10-23 06:35:36 --> Output Class Initialized
INFO - 2020-10-23 06:35:36 --> Security Class Initialized
DEBUG - 2020-10-23 06:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-23 06:35:36 --> Input Class Initialized
INFO - 2020-10-23 06:35:36 --> Language Class Initialized
INFO - 2020-10-23 06:35:36 --> Language Class Initialized
INFO - 2020-10-23 06:35:36 --> Config Class Initialized
INFO - 2020-10-23 06:35:36 --> Loader Class Initialized
INFO - 2020-10-23 06:35:36 --> Helper loaded: url_helper
INFO - 2020-10-23 06:35:36 --> Helper loaded: file_helper
INFO - 2020-10-23 06:35:36 --> Helper loaded: form_helper
INFO - 2020-10-23 06:35:36 --> Helper loaded: my_helper
INFO - 2020-10-23 06:35:36 --> Database Driver Class Initialized
DEBUG - 2020-10-23 06:35:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-23 06:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-23 06:35:36 --> Controller Class Initialized
DEBUG - 2020-10-23 06:35:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2020-10-23 06:35:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-23 06:35:36 --> Final output sent to browser
DEBUG - 2020-10-23 06:35:36 --> Total execution time: 0.2150
INFO - 2020-10-23 06:35:36 --> Config Class Initialized
INFO - 2020-10-23 06:35:36 --> Hooks Class Initialized
DEBUG - 2020-10-23 06:35:36 --> UTF-8 Support Enabled
INFO - 2020-10-23 06:35:36 --> Utf8 Class Initialized
INFO - 2020-10-23 06:35:36 --> URI Class Initialized
INFO - 2020-10-23 06:35:36 --> Router Class Initialized
INFO - 2020-10-23 06:35:36 --> Output Class Initialized
INFO - 2020-10-23 06:35:36 --> Security Class Initialized
DEBUG - 2020-10-23 06:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-23 06:35:36 --> Input Class Initialized
INFO - 2020-10-23 06:35:36 --> Language Class Initialized
INFO - 2020-10-23 06:35:36 --> Language Class Initialized
INFO - 2020-10-23 06:35:36 --> Config Class Initialized
INFO - 2020-10-23 06:35:36 --> Loader Class Initialized
INFO - 2020-10-23 06:35:36 --> Helper loaded: url_helper
INFO - 2020-10-23 06:35:36 --> Helper loaded: file_helper
INFO - 2020-10-23 06:35:36 --> Helper loaded: form_helper
INFO - 2020-10-23 06:35:36 --> Helper loaded: my_helper
INFO - 2020-10-23 06:35:36 --> Database Driver Class Initialized
DEBUG - 2020-10-23 06:35:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-23 06:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-23 06:35:36 --> Controller Class Initialized
INFO - 2020-10-23 06:35:39 --> Config Class Initialized
INFO - 2020-10-23 06:35:39 --> Hooks Class Initialized
DEBUG - 2020-10-23 06:35:39 --> UTF-8 Support Enabled
INFO - 2020-10-23 06:35:39 --> Utf8 Class Initialized
INFO - 2020-10-23 06:35:39 --> URI Class Initialized
INFO - 2020-10-23 06:35:39 --> Router Class Initialized
INFO - 2020-10-23 06:35:39 --> Output Class Initialized
INFO - 2020-10-23 06:35:39 --> Security Class Initialized
DEBUG - 2020-10-23 06:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-23 06:35:39 --> Input Class Initialized
INFO - 2020-10-23 06:35:39 --> Language Class Initialized
INFO - 2020-10-23 06:35:39 --> Language Class Initialized
INFO - 2020-10-23 06:35:39 --> Config Class Initialized
INFO - 2020-10-23 06:35:39 --> Loader Class Initialized
INFO - 2020-10-23 06:35:39 --> Helper loaded: url_helper
INFO - 2020-10-23 06:35:39 --> Helper loaded: file_helper
INFO - 2020-10-23 06:35:39 --> Helper loaded: form_helper
INFO - 2020-10-23 06:35:39 --> Helper loaded: my_helper
INFO - 2020-10-23 06:35:39 --> Database Driver Class Initialized
DEBUG - 2020-10-23 06:35:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-23 06:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-23 06:35:39 --> Controller Class Initialized
DEBUG - 2020-10-23 06:35:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-10-23 06:35:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-23 06:35:39 --> Final output sent to browser
DEBUG - 2020-10-23 06:35:39 --> Total execution time: 0.2457
INFO - 2020-10-23 06:35:39 --> Config Class Initialized
INFO - 2020-10-23 06:35:39 --> Hooks Class Initialized
DEBUG - 2020-10-23 06:35:39 --> UTF-8 Support Enabled
INFO - 2020-10-23 06:35:39 --> Utf8 Class Initialized
INFO - 2020-10-23 06:35:39 --> URI Class Initialized
INFO - 2020-10-23 06:35:39 --> Router Class Initialized
INFO - 2020-10-23 06:35:39 --> Output Class Initialized
INFO - 2020-10-23 06:35:39 --> Security Class Initialized
DEBUG - 2020-10-23 06:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-23 06:35:39 --> Input Class Initialized
INFO - 2020-10-23 06:35:39 --> Language Class Initialized
INFO - 2020-10-23 06:35:39 --> Language Class Initialized
INFO - 2020-10-23 06:35:39 --> Config Class Initialized
INFO - 2020-10-23 06:35:39 --> Loader Class Initialized
INFO - 2020-10-23 06:35:39 --> Helper loaded: url_helper
INFO - 2020-10-23 06:35:39 --> Helper loaded: file_helper
INFO - 2020-10-23 06:35:39 --> Helper loaded: form_helper
INFO - 2020-10-23 06:35:39 --> Helper loaded: my_helper
INFO - 2020-10-23 06:35:39 --> Database Driver Class Initialized
DEBUG - 2020-10-23 06:35:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-23 06:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-23 06:35:39 --> Controller Class Initialized
INFO - 2020-10-23 06:35:49 --> Config Class Initialized
INFO - 2020-10-23 06:35:49 --> Hooks Class Initialized
DEBUG - 2020-10-23 06:35:49 --> UTF-8 Support Enabled
INFO - 2020-10-23 06:35:49 --> Utf8 Class Initialized
INFO - 2020-10-23 06:35:49 --> URI Class Initialized
INFO - 2020-10-23 06:35:49 --> Router Class Initialized
INFO - 2020-10-23 06:35:49 --> Output Class Initialized
INFO - 2020-10-23 06:35:49 --> Security Class Initialized
DEBUG - 2020-10-23 06:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-23 06:35:49 --> Input Class Initialized
INFO - 2020-10-23 06:35:49 --> Language Class Initialized
INFO - 2020-10-23 06:35:49 --> Language Class Initialized
INFO - 2020-10-23 06:35:49 --> Config Class Initialized
INFO - 2020-10-23 06:35:49 --> Loader Class Initialized
INFO - 2020-10-23 06:35:49 --> Helper loaded: url_helper
INFO - 2020-10-23 06:35:49 --> Helper loaded: file_helper
INFO - 2020-10-23 06:35:49 --> Helper loaded: form_helper
INFO - 2020-10-23 06:35:49 --> Helper loaded: my_helper
INFO - 2020-10-23 06:35:49 --> Database Driver Class Initialized
DEBUG - 2020-10-23 06:35:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-23 06:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-23 06:35:49 --> Controller Class Initialized
DEBUG - 2020-10-23 06:35:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-23 06:35:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-23 06:35:49 --> Final output sent to browser
DEBUG - 2020-10-23 06:35:49 --> Total execution time: 0.1891
INFO - 2020-10-23 06:35:49 --> Config Class Initialized
INFO - 2020-10-23 06:35:49 --> Hooks Class Initialized
DEBUG - 2020-10-23 06:35:49 --> UTF-8 Support Enabled
INFO - 2020-10-23 06:35:49 --> Utf8 Class Initialized
INFO - 2020-10-23 06:35:49 --> URI Class Initialized
INFO - 2020-10-23 06:35:49 --> Router Class Initialized
INFO - 2020-10-23 06:35:49 --> Output Class Initialized
INFO - 2020-10-23 06:35:49 --> Security Class Initialized
DEBUG - 2020-10-23 06:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-23 06:35:49 --> Input Class Initialized
INFO - 2020-10-23 06:35:49 --> Language Class Initialized
INFO - 2020-10-23 06:35:49 --> Language Class Initialized
INFO - 2020-10-23 06:35:49 --> Config Class Initialized
INFO - 2020-10-23 06:35:49 --> Loader Class Initialized
INFO - 2020-10-23 06:35:49 --> Helper loaded: url_helper
INFO - 2020-10-23 06:35:49 --> Helper loaded: file_helper
INFO - 2020-10-23 06:35:49 --> Helper loaded: form_helper
INFO - 2020-10-23 06:35:49 --> Helper loaded: my_helper
INFO - 2020-10-23 06:35:49 --> Database Driver Class Initialized
DEBUG - 2020-10-23 06:35:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-23 06:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-23 06:35:49 --> Controller Class Initialized
