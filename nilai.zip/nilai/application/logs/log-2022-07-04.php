<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-07-04 03:10:31 --> Config Class Initialized
INFO - 2022-07-04 03:10:31 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:10:31 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:10:31 --> Utf8 Class Initialized
INFO - 2022-07-04 03:10:31 --> URI Class Initialized
DEBUG - 2022-07-04 03:10:31 --> No URI present. Default controller set.
INFO - 2022-07-04 03:10:31 --> Router Class Initialized
INFO - 2022-07-04 03:10:31 --> Output Class Initialized
INFO - 2022-07-04 03:10:31 --> Security Class Initialized
DEBUG - 2022-07-04 03:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:10:31 --> Input Class Initialized
INFO - 2022-07-04 03:10:31 --> Language Class Initialized
INFO - 2022-07-04 03:10:31 --> Language Class Initialized
INFO - 2022-07-04 03:10:31 --> Config Class Initialized
INFO - 2022-07-04 03:10:31 --> Loader Class Initialized
INFO - 2022-07-04 03:10:31 --> Helper loaded: url_helper
INFO - 2022-07-04 03:10:31 --> Helper loaded: file_helper
INFO - 2022-07-04 03:10:31 --> Helper loaded: form_helper
INFO - 2022-07-04 03:10:31 --> Helper loaded: my_helper
INFO - 2022-07-04 03:10:31 --> Database Driver Class Initialized
INFO - 2022-07-04 03:10:31 --> Config Class Initialized
INFO - 2022-07-04 03:10:31 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:10:31 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:10:31 --> Utf8 Class Initialized
INFO - 2022-07-04 03:10:31 --> URI Class Initialized
DEBUG - 2022-07-04 03:10:31 --> No URI present. Default controller set.
INFO - 2022-07-04 03:10:31 --> Router Class Initialized
INFO - 2022-07-04 03:10:31 --> Output Class Initialized
INFO - 2022-07-04 03:10:31 --> Security Class Initialized
DEBUG - 2022-07-04 03:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:10:31 --> Input Class Initialized
INFO - 2022-07-04 03:10:31 --> Language Class Initialized
DEBUG - 2022-07-04 03:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:10:31 --> Controller Class Initialized
INFO - 2022-07-04 03:10:31 --> Language Class Initialized
INFO - 2022-07-04 03:10:31 --> Config Class Initialized
INFO - 2022-07-04 03:10:31 --> Loader Class Initialized
INFO - 2022-07-04 03:10:31 --> Helper loaded: url_helper
INFO - 2022-07-04 03:10:31 --> Helper loaded: file_helper
INFO - 2022-07-04 03:10:31 --> Helper loaded: form_helper
INFO - 2022-07-04 03:10:31 --> Helper loaded: my_helper
INFO - 2022-07-04 03:10:31 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:10:31 --> Controller Class Initialized
INFO - 2022-07-04 03:10:31 --> Config Class Initialized
INFO - 2022-07-04 03:10:31 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:10:31 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:10:31 --> Utf8 Class Initialized
INFO - 2022-07-04 03:10:31 --> URI Class Initialized
INFO - 2022-07-04 03:10:31 --> Router Class Initialized
INFO - 2022-07-04 03:10:31 --> Output Class Initialized
INFO - 2022-07-04 03:10:31 --> Security Class Initialized
DEBUG - 2022-07-04 03:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:10:31 --> Input Class Initialized
INFO - 2022-07-04 03:10:31 --> Language Class Initialized
INFO - 2022-07-04 03:10:31 --> Language Class Initialized
INFO - 2022-07-04 03:10:31 --> Config Class Initialized
INFO - 2022-07-04 03:10:31 --> Loader Class Initialized
INFO - 2022-07-04 03:10:31 --> Helper loaded: url_helper
INFO - 2022-07-04 03:10:31 --> Helper loaded: file_helper
INFO - 2022-07-04 03:10:31 --> Helper loaded: form_helper
INFO - 2022-07-04 03:10:31 --> Helper loaded: my_helper
INFO - 2022-07-04 03:10:31 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:10:31 --> Controller Class Initialized
DEBUG - 2022-07-04 03:10:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-07-04 03:10:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 03:10:31 --> Final output sent to browser
DEBUG - 2022-07-04 03:10:31 --> Total execution time: 0.0608
INFO - 2022-07-04 03:10:42 --> Config Class Initialized
INFO - 2022-07-04 03:10:42 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:10:42 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:10:42 --> Utf8 Class Initialized
INFO - 2022-07-04 03:10:42 --> URI Class Initialized
INFO - 2022-07-04 03:10:42 --> Router Class Initialized
INFO - 2022-07-04 03:10:42 --> Output Class Initialized
INFO - 2022-07-04 03:10:42 --> Security Class Initialized
DEBUG - 2022-07-04 03:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:10:42 --> Input Class Initialized
INFO - 2022-07-04 03:10:42 --> Language Class Initialized
INFO - 2022-07-04 03:10:42 --> Language Class Initialized
INFO - 2022-07-04 03:10:42 --> Config Class Initialized
INFO - 2022-07-04 03:10:42 --> Loader Class Initialized
INFO - 2022-07-04 03:10:42 --> Helper loaded: url_helper
INFO - 2022-07-04 03:10:42 --> Helper loaded: file_helper
INFO - 2022-07-04 03:10:42 --> Helper loaded: form_helper
INFO - 2022-07-04 03:10:42 --> Helper loaded: my_helper
INFO - 2022-07-04 03:10:42 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:10:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:10:42 --> Controller Class Initialized
INFO - 2022-07-04 03:10:42 --> Helper loaded: cookie_helper
INFO - 2022-07-04 03:10:42 --> Final output sent to browser
DEBUG - 2022-07-04 03:10:42 --> Total execution time: 0.0958
INFO - 2022-07-04 03:10:44 --> Config Class Initialized
INFO - 2022-07-04 03:10:44 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:10:44 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:10:44 --> Utf8 Class Initialized
INFO - 2022-07-04 03:10:44 --> URI Class Initialized
INFO - 2022-07-04 03:10:44 --> Router Class Initialized
INFO - 2022-07-04 03:10:44 --> Output Class Initialized
INFO - 2022-07-04 03:10:44 --> Security Class Initialized
DEBUG - 2022-07-04 03:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:10:44 --> Input Class Initialized
INFO - 2022-07-04 03:10:44 --> Language Class Initialized
INFO - 2022-07-04 03:10:44 --> Language Class Initialized
INFO - 2022-07-04 03:10:44 --> Config Class Initialized
INFO - 2022-07-04 03:10:44 --> Loader Class Initialized
INFO - 2022-07-04 03:10:44 --> Helper loaded: url_helper
INFO - 2022-07-04 03:10:44 --> Helper loaded: file_helper
INFO - 2022-07-04 03:10:44 --> Helper loaded: form_helper
INFO - 2022-07-04 03:10:44 --> Helper loaded: my_helper
INFO - 2022-07-04 03:10:44 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:10:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:10:45 --> Controller Class Initialized
DEBUG - 2022-07-04 03:10:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-07-04 03:10:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 03:10:45 --> Final output sent to browser
DEBUG - 2022-07-04 03:10:45 --> Total execution time: 0.6089
INFO - 2022-07-04 03:10:51 --> Config Class Initialized
INFO - 2022-07-04 03:10:51 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:10:51 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:10:51 --> Utf8 Class Initialized
INFO - 2022-07-04 03:10:51 --> URI Class Initialized
INFO - 2022-07-04 03:10:51 --> Router Class Initialized
INFO - 2022-07-04 03:10:51 --> Output Class Initialized
INFO - 2022-07-04 03:10:51 --> Security Class Initialized
DEBUG - 2022-07-04 03:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:10:51 --> Input Class Initialized
INFO - 2022-07-04 03:10:51 --> Language Class Initialized
INFO - 2022-07-04 03:10:51 --> Language Class Initialized
INFO - 2022-07-04 03:10:51 --> Config Class Initialized
INFO - 2022-07-04 03:10:51 --> Loader Class Initialized
INFO - 2022-07-04 03:10:51 --> Helper loaded: url_helper
INFO - 2022-07-04 03:10:51 --> Helper loaded: file_helper
INFO - 2022-07-04 03:10:51 --> Helper loaded: form_helper
INFO - 2022-07-04 03:10:51 --> Helper loaded: my_helper
INFO - 2022-07-04 03:10:51 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:10:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:10:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:10:51 --> Controller Class Initialized
DEBUG - 2022-07-04 03:10:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2022-07-04 03:10:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 03:10:51 --> Final output sent to browser
DEBUG - 2022-07-04 03:10:51 --> Total execution time: 0.1640
INFO - 2022-07-04 03:18:30 --> Config Class Initialized
INFO - 2022-07-04 03:18:30 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:18:30 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:18:30 --> Utf8 Class Initialized
INFO - 2022-07-04 03:18:30 --> URI Class Initialized
INFO - 2022-07-04 03:18:30 --> Router Class Initialized
INFO - 2022-07-04 03:18:30 --> Output Class Initialized
INFO - 2022-07-04 03:18:30 --> Security Class Initialized
DEBUG - 2022-07-04 03:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:18:30 --> Input Class Initialized
INFO - 2022-07-04 03:18:30 --> Language Class Initialized
INFO - 2022-07-04 03:18:30 --> Language Class Initialized
INFO - 2022-07-04 03:18:30 --> Config Class Initialized
INFO - 2022-07-04 03:18:30 --> Loader Class Initialized
INFO - 2022-07-04 03:18:30 --> Helper loaded: url_helper
INFO - 2022-07-04 03:18:30 --> Helper loaded: file_helper
INFO - 2022-07-04 03:18:30 --> Helper loaded: form_helper
INFO - 2022-07-04 03:18:30 --> Helper loaded: my_helper
INFO - 2022-07-04 03:18:30 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:18:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:18:30 --> Controller Class Initialized
INFO - 2022-07-04 03:18:30 --> Final output sent to browser
DEBUG - 2022-07-04 03:18:30 --> Total execution time: 0.6434
INFO - 2022-07-04 03:18:33 --> Config Class Initialized
INFO - 2022-07-04 03:18:33 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:18:33 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:18:33 --> Utf8 Class Initialized
INFO - 2022-07-04 03:18:33 --> URI Class Initialized
INFO - 2022-07-04 03:18:33 --> Router Class Initialized
INFO - 2022-07-04 03:18:33 --> Output Class Initialized
INFO - 2022-07-04 03:18:33 --> Security Class Initialized
DEBUG - 2022-07-04 03:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:18:33 --> Input Class Initialized
INFO - 2022-07-04 03:18:33 --> Language Class Initialized
INFO - 2022-07-04 03:18:33 --> Language Class Initialized
INFO - 2022-07-04 03:18:33 --> Config Class Initialized
INFO - 2022-07-04 03:18:33 --> Loader Class Initialized
INFO - 2022-07-04 03:18:33 --> Helper loaded: url_helper
INFO - 2022-07-04 03:18:33 --> Helper loaded: file_helper
INFO - 2022-07-04 03:18:33 --> Helper loaded: form_helper
INFO - 2022-07-04 03:18:33 --> Helper loaded: my_helper
INFO - 2022-07-04 03:18:33 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:18:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:18:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:18:33 --> Controller Class Initialized
DEBUG - 2022-07-04 03:18:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2022-07-04 03:18:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 03:18:33 --> Final output sent to browser
DEBUG - 2022-07-04 03:18:33 --> Total execution time: 0.1241
INFO - 2022-07-04 03:19:04 --> Config Class Initialized
INFO - 2022-07-04 03:19:04 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:19:04 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:19:04 --> Utf8 Class Initialized
INFO - 2022-07-04 03:19:04 --> URI Class Initialized
INFO - 2022-07-04 03:19:04 --> Router Class Initialized
INFO - 2022-07-04 03:19:04 --> Output Class Initialized
INFO - 2022-07-04 03:19:04 --> Security Class Initialized
DEBUG - 2022-07-04 03:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:19:04 --> Input Class Initialized
INFO - 2022-07-04 03:19:04 --> Language Class Initialized
INFO - 2022-07-04 03:19:04 --> Language Class Initialized
INFO - 2022-07-04 03:19:04 --> Config Class Initialized
INFO - 2022-07-04 03:19:04 --> Loader Class Initialized
INFO - 2022-07-04 03:19:04 --> Helper loaded: url_helper
INFO - 2022-07-04 03:19:04 --> Helper loaded: file_helper
INFO - 2022-07-04 03:19:04 --> Helper loaded: form_helper
INFO - 2022-07-04 03:19:04 --> Helper loaded: my_helper
INFO - 2022-07-04 03:19:04 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:19:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:19:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:19:04 --> Controller Class Initialized
INFO - 2022-07-04 03:19:04 --> Final output sent to browser
DEBUG - 2022-07-04 03:19:04 --> Total execution time: 0.0925
INFO - 2022-07-04 03:19:10 --> Config Class Initialized
INFO - 2022-07-04 03:19:10 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:19:10 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:19:10 --> Utf8 Class Initialized
INFO - 2022-07-04 03:19:10 --> URI Class Initialized
INFO - 2022-07-04 03:19:10 --> Router Class Initialized
INFO - 2022-07-04 03:19:10 --> Output Class Initialized
INFO - 2022-07-04 03:19:10 --> Security Class Initialized
DEBUG - 2022-07-04 03:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:19:10 --> Input Class Initialized
INFO - 2022-07-04 03:19:10 --> Language Class Initialized
INFO - 2022-07-04 03:19:10 --> Language Class Initialized
INFO - 2022-07-04 03:19:10 --> Config Class Initialized
INFO - 2022-07-04 03:19:10 --> Loader Class Initialized
INFO - 2022-07-04 03:19:10 --> Helper loaded: url_helper
INFO - 2022-07-04 03:19:10 --> Helper loaded: file_helper
INFO - 2022-07-04 03:19:10 --> Helper loaded: form_helper
INFO - 2022-07-04 03:19:10 --> Helper loaded: my_helper
INFO - 2022-07-04 03:19:10 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:19:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:19:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:19:10 --> Controller Class Initialized
DEBUG - 2022-07-04 03:19:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2022-07-04 03:19:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 03:19:10 --> Final output sent to browser
DEBUG - 2022-07-04 03:19:10 --> Total execution time: 0.0808
INFO - 2022-07-04 03:19:12 --> Config Class Initialized
INFO - 2022-07-04 03:19:12 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:19:12 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:19:12 --> Utf8 Class Initialized
INFO - 2022-07-04 03:19:12 --> URI Class Initialized
INFO - 2022-07-04 03:19:12 --> Router Class Initialized
INFO - 2022-07-04 03:19:12 --> Output Class Initialized
INFO - 2022-07-04 03:19:12 --> Security Class Initialized
DEBUG - 2022-07-04 03:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:19:12 --> Input Class Initialized
INFO - 2022-07-04 03:19:12 --> Language Class Initialized
INFO - 2022-07-04 03:19:12 --> Language Class Initialized
INFO - 2022-07-04 03:19:12 --> Config Class Initialized
INFO - 2022-07-04 03:19:12 --> Loader Class Initialized
INFO - 2022-07-04 03:19:12 --> Helper loaded: url_helper
INFO - 2022-07-04 03:19:12 --> Helper loaded: file_helper
INFO - 2022-07-04 03:19:12 --> Helper loaded: form_helper
INFO - 2022-07-04 03:19:12 --> Helper loaded: my_helper
INFO - 2022-07-04 03:19:12 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:19:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:19:12 --> Controller Class Initialized
DEBUG - 2022-07-04 03:19:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-07-04 03:19:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 03:19:12 --> Final output sent to browser
DEBUG - 2022-07-04 03:19:12 --> Total execution time: 0.1166
INFO - 2022-07-04 03:19:16 --> Config Class Initialized
INFO - 2022-07-04 03:19:16 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:19:16 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:19:16 --> Utf8 Class Initialized
INFO - 2022-07-04 03:19:16 --> URI Class Initialized
INFO - 2022-07-04 03:19:16 --> Router Class Initialized
INFO - 2022-07-04 03:19:16 --> Output Class Initialized
INFO - 2022-07-04 03:19:16 --> Security Class Initialized
DEBUG - 2022-07-04 03:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:19:16 --> Input Class Initialized
INFO - 2022-07-04 03:19:16 --> Language Class Initialized
INFO - 2022-07-04 03:19:16 --> Language Class Initialized
INFO - 2022-07-04 03:19:16 --> Config Class Initialized
INFO - 2022-07-04 03:19:16 --> Loader Class Initialized
INFO - 2022-07-04 03:19:16 --> Helper loaded: url_helper
INFO - 2022-07-04 03:19:16 --> Helper loaded: file_helper
INFO - 2022-07-04 03:19:16 --> Helper loaded: form_helper
INFO - 2022-07-04 03:19:16 --> Helper loaded: my_helper
INFO - 2022-07-04 03:19:16 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:19:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:19:16 --> Controller Class Initialized
INFO - 2022-07-04 03:19:16 --> Final output sent to browser
DEBUG - 2022-07-04 03:19:16 --> Total execution time: 0.0595
INFO - 2022-07-04 03:20:54 --> Config Class Initialized
INFO - 2022-07-04 03:20:54 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:20:54 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:20:54 --> Utf8 Class Initialized
INFO - 2022-07-04 03:20:54 --> URI Class Initialized
INFO - 2022-07-04 03:20:54 --> Router Class Initialized
INFO - 2022-07-04 03:20:54 --> Output Class Initialized
INFO - 2022-07-04 03:20:54 --> Security Class Initialized
DEBUG - 2022-07-04 03:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:20:54 --> Input Class Initialized
INFO - 2022-07-04 03:20:54 --> Language Class Initialized
INFO - 2022-07-04 03:20:54 --> Language Class Initialized
INFO - 2022-07-04 03:20:54 --> Config Class Initialized
INFO - 2022-07-04 03:20:54 --> Loader Class Initialized
INFO - 2022-07-04 03:20:54 --> Helper loaded: url_helper
INFO - 2022-07-04 03:20:54 --> Helper loaded: file_helper
INFO - 2022-07-04 03:20:54 --> Helper loaded: form_helper
INFO - 2022-07-04 03:20:54 --> Helper loaded: my_helper
INFO - 2022-07-04 03:20:54 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:20:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:20:54 --> Controller Class Initialized
INFO - 2022-07-04 03:20:54 --> Final output sent to browser
DEBUG - 2022-07-04 03:20:54 --> Total execution time: 0.0995
INFO - 2022-07-04 03:21:01 --> Config Class Initialized
INFO - 2022-07-04 03:21:01 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:21:01 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:21:01 --> Utf8 Class Initialized
INFO - 2022-07-04 03:21:01 --> URI Class Initialized
INFO - 2022-07-04 03:21:01 --> Router Class Initialized
INFO - 2022-07-04 03:21:01 --> Output Class Initialized
INFO - 2022-07-04 03:21:01 --> Security Class Initialized
DEBUG - 2022-07-04 03:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:21:01 --> Input Class Initialized
INFO - 2022-07-04 03:21:01 --> Language Class Initialized
INFO - 2022-07-04 03:21:01 --> Language Class Initialized
INFO - 2022-07-04 03:21:01 --> Config Class Initialized
INFO - 2022-07-04 03:21:01 --> Loader Class Initialized
INFO - 2022-07-04 03:21:01 --> Helper loaded: url_helper
INFO - 2022-07-04 03:21:01 --> Helper loaded: file_helper
INFO - 2022-07-04 03:21:01 --> Helper loaded: form_helper
INFO - 2022-07-04 03:21:01 --> Helper loaded: my_helper
INFO - 2022-07-04 03:21:01 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:21:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:21:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:21:01 --> Controller Class Initialized
DEBUG - 2022-07-04 03:21:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2022-07-04 03:21:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 03:21:01 --> Final output sent to browser
DEBUG - 2022-07-04 03:21:01 --> Total execution time: 0.0903
INFO - 2022-07-04 03:21:19 --> Config Class Initialized
INFO - 2022-07-04 03:21:19 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:21:19 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:21:19 --> Utf8 Class Initialized
INFO - 2022-07-04 03:21:19 --> URI Class Initialized
INFO - 2022-07-04 03:21:19 --> Router Class Initialized
INFO - 2022-07-04 03:21:19 --> Output Class Initialized
INFO - 2022-07-04 03:21:19 --> Security Class Initialized
DEBUG - 2022-07-04 03:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:21:19 --> Input Class Initialized
INFO - 2022-07-04 03:21:19 --> Language Class Initialized
INFO - 2022-07-04 03:21:19 --> Language Class Initialized
INFO - 2022-07-04 03:21:19 --> Config Class Initialized
INFO - 2022-07-04 03:21:19 --> Loader Class Initialized
INFO - 2022-07-04 03:21:19 --> Helper loaded: url_helper
INFO - 2022-07-04 03:21:19 --> Helper loaded: file_helper
INFO - 2022-07-04 03:21:19 --> Helper loaded: form_helper
INFO - 2022-07-04 03:21:19 --> Helper loaded: my_helper
INFO - 2022-07-04 03:21:19 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:21:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:21:19 --> Controller Class Initialized
DEBUG - 2022-07-04 03:21:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2022-07-04 03:21:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 03:21:19 --> Final output sent to browser
DEBUG - 2022-07-04 03:21:19 --> Total execution time: 0.1188
INFO - 2022-07-04 03:25:31 --> Config Class Initialized
INFO - 2022-07-04 03:25:31 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:25:31 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:25:31 --> Utf8 Class Initialized
INFO - 2022-07-04 03:25:31 --> URI Class Initialized
INFO - 2022-07-04 03:25:31 --> Router Class Initialized
INFO - 2022-07-04 03:25:31 --> Output Class Initialized
INFO - 2022-07-04 03:25:31 --> Security Class Initialized
DEBUG - 2022-07-04 03:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:25:31 --> Input Class Initialized
INFO - 2022-07-04 03:25:31 --> Language Class Initialized
INFO - 2022-07-04 03:25:31 --> Language Class Initialized
INFO - 2022-07-04 03:25:31 --> Config Class Initialized
INFO - 2022-07-04 03:25:31 --> Loader Class Initialized
INFO - 2022-07-04 03:25:31 --> Helper loaded: url_helper
INFO - 2022-07-04 03:25:31 --> Helper loaded: file_helper
INFO - 2022-07-04 03:25:31 --> Helper loaded: form_helper
INFO - 2022-07-04 03:25:31 --> Helper loaded: my_helper
INFO - 2022-07-04 03:25:31 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:25:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:25:31 --> Controller Class Initialized
INFO - 2022-07-04 03:25:31 --> Final output sent to browser
DEBUG - 2022-07-04 03:25:31 --> Total execution time: 0.1021
INFO - 2022-07-04 03:26:06 --> Config Class Initialized
INFO - 2022-07-04 03:26:06 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:26:06 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:26:06 --> Utf8 Class Initialized
INFO - 2022-07-04 03:26:06 --> URI Class Initialized
INFO - 2022-07-04 03:26:06 --> Router Class Initialized
INFO - 2022-07-04 03:26:06 --> Output Class Initialized
INFO - 2022-07-04 03:26:06 --> Security Class Initialized
DEBUG - 2022-07-04 03:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:26:06 --> Input Class Initialized
INFO - 2022-07-04 03:26:06 --> Language Class Initialized
INFO - 2022-07-04 03:26:06 --> Language Class Initialized
INFO - 2022-07-04 03:26:06 --> Config Class Initialized
INFO - 2022-07-04 03:26:06 --> Loader Class Initialized
INFO - 2022-07-04 03:26:06 --> Helper loaded: url_helper
INFO - 2022-07-04 03:26:06 --> Helper loaded: file_helper
INFO - 2022-07-04 03:26:06 --> Helper loaded: form_helper
INFO - 2022-07-04 03:26:06 --> Helper loaded: my_helper
INFO - 2022-07-04 03:26:06 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:26:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:26:06 --> Controller Class Initialized
INFO - 2022-07-04 03:26:06 --> Final output sent to browser
DEBUG - 2022-07-04 03:26:06 --> Total execution time: 0.1017
INFO - 2022-07-04 03:26:40 --> Config Class Initialized
INFO - 2022-07-04 03:26:40 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:26:40 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:26:40 --> Utf8 Class Initialized
INFO - 2022-07-04 03:26:40 --> URI Class Initialized
INFO - 2022-07-04 03:26:40 --> Router Class Initialized
INFO - 2022-07-04 03:26:40 --> Output Class Initialized
INFO - 2022-07-04 03:26:40 --> Security Class Initialized
DEBUG - 2022-07-04 03:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:26:40 --> Input Class Initialized
INFO - 2022-07-04 03:26:40 --> Language Class Initialized
INFO - 2022-07-04 03:26:40 --> Language Class Initialized
INFO - 2022-07-04 03:26:40 --> Config Class Initialized
INFO - 2022-07-04 03:26:40 --> Loader Class Initialized
INFO - 2022-07-04 03:26:40 --> Helper loaded: url_helper
INFO - 2022-07-04 03:26:40 --> Helper loaded: file_helper
INFO - 2022-07-04 03:26:40 --> Helper loaded: form_helper
INFO - 2022-07-04 03:26:40 --> Helper loaded: my_helper
INFO - 2022-07-04 03:26:40 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:26:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:26:40 --> Controller Class Initialized
INFO - 2022-07-04 03:26:40 --> Final output sent to browser
DEBUG - 2022-07-04 03:26:40 --> Total execution time: 0.0880
INFO - 2022-07-04 03:26:40 --> Config Class Initialized
INFO - 2022-07-04 03:26:40 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:26:40 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:26:40 --> Utf8 Class Initialized
INFO - 2022-07-04 03:26:40 --> URI Class Initialized
INFO - 2022-07-04 03:26:40 --> Router Class Initialized
INFO - 2022-07-04 03:26:40 --> Output Class Initialized
INFO - 2022-07-04 03:26:40 --> Security Class Initialized
DEBUG - 2022-07-04 03:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:26:40 --> Input Class Initialized
INFO - 2022-07-04 03:26:40 --> Language Class Initialized
INFO - 2022-07-04 03:26:40 --> Language Class Initialized
INFO - 2022-07-04 03:26:40 --> Config Class Initialized
INFO - 2022-07-04 03:26:40 --> Loader Class Initialized
INFO - 2022-07-04 03:26:40 --> Helper loaded: url_helper
INFO - 2022-07-04 03:26:40 --> Helper loaded: file_helper
INFO - 2022-07-04 03:26:40 --> Helper loaded: form_helper
INFO - 2022-07-04 03:26:40 --> Helper loaded: my_helper
INFO - 2022-07-04 03:26:40 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:26:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:26:40 --> Controller Class Initialized
INFO - 2022-07-04 03:26:40 --> Final output sent to browser
DEBUG - 2022-07-04 03:26:40 --> Total execution time: 0.1008
INFO - 2022-07-04 03:27:22 --> Config Class Initialized
INFO - 2022-07-04 03:27:22 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:27:22 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:27:22 --> Utf8 Class Initialized
INFO - 2022-07-04 03:27:22 --> URI Class Initialized
INFO - 2022-07-04 03:27:22 --> Router Class Initialized
INFO - 2022-07-04 03:27:22 --> Output Class Initialized
INFO - 2022-07-04 03:27:22 --> Security Class Initialized
DEBUG - 2022-07-04 03:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:27:22 --> Input Class Initialized
INFO - 2022-07-04 03:27:22 --> Language Class Initialized
INFO - 2022-07-04 03:27:22 --> Language Class Initialized
INFO - 2022-07-04 03:27:22 --> Config Class Initialized
INFO - 2022-07-04 03:27:22 --> Loader Class Initialized
INFO - 2022-07-04 03:27:22 --> Helper loaded: url_helper
INFO - 2022-07-04 03:27:22 --> Helper loaded: file_helper
INFO - 2022-07-04 03:27:22 --> Helper loaded: form_helper
INFO - 2022-07-04 03:27:22 --> Helper loaded: my_helper
INFO - 2022-07-04 03:27:22 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:27:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:27:22 --> Controller Class Initialized
DEBUG - 2022-07-04 03:27:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2022-07-04 03:27:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 03:27:23 --> Final output sent to browser
DEBUG - 2022-07-04 03:27:23 --> Total execution time: 0.1478
INFO - 2022-07-04 03:27:30 --> Config Class Initialized
INFO - 2022-07-04 03:27:30 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:27:30 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:27:30 --> Utf8 Class Initialized
INFO - 2022-07-04 03:27:30 --> URI Class Initialized
INFO - 2022-07-04 03:27:30 --> Router Class Initialized
INFO - 2022-07-04 03:27:30 --> Output Class Initialized
INFO - 2022-07-04 03:27:30 --> Security Class Initialized
DEBUG - 2022-07-04 03:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:27:30 --> Input Class Initialized
INFO - 2022-07-04 03:27:30 --> Language Class Initialized
INFO - 2022-07-04 03:27:30 --> Language Class Initialized
INFO - 2022-07-04 03:27:30 --> Config Class Initialized
INFO - 2022-07-04 03:27:30 --> Loader Class Initialized
INFO - 2022-07-04 03:27:30 --> Helper loaded: url_helper
INFO - 2022-07-04 03:27:30 --> Helper loaded: file_helper
INFO - 2022-07-04 03:27:30 --> Helper loaded: form_helper
INFO - 2022-07-04 03:27:30 --> Helper loaded: my_helper
INFO - 2022-07-04 03:27:30 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:27:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:27:30 --> Controller Class Initialized
DEBUG - 2022-07-04 03:27:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2022-07-04 03:27:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 03:27:30 --> Final output sent to browser
DEBUG - 2022-07-04 03:27:30 --> Total execution time: 0.0678
INFO - 2022-07-04 03:27:34 --> Config Class Initialized
INFO - 2022-07-04 03:27:34 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:27:34 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:27:34 --> Utf8 Class Initialized
INFO - 2022-07-04 03:27:34 --> URI Class Initialized
INFO - 2022-07-04 03:27:34 --> Router Class Initialized
INFO - 2022-07-04 03:27:34 --> Output Class Initialized
INFO - 2022-07-04 03:27:34 --> Security Class Initialized
DEBUG - 2022-07-04 03:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:27:34 --> Input Class Initialized
INFO - 2022-07-04 03:27:34 --> Language Class Initialized
INFO - 2022-07-04 03:27:34 --> Language Class Initialized
INFO - 2022-07-04 03:27:34 --> Config Class Initialized
INFO - 2022-07-04 03:27:34 --> Loader Class Initialized
INFO - 2022-07-04 03:27:34 --> Helper loaded: url_helper
INFO - 2022-07-04 03:27:34 --> Helper loaded: file_helper
INFO - 2022-07-04 03:27:34 --> Helper loaded: form_helper
INFO - 2022-07-04 03:27:34 --> Helper loaded: my_helper
INFO - 2022-07-04 03:27:34 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:27:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:27:34 --> Controller Class Initialized
DEBUG - 2022-07-04 03:27:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-07-04 03:27:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 03:27:34 --> Final output sent to browser
DEBUG - 2022-07-04 03:27:34 --> Total execution time: 0.0439
INFO - 2022-07-04 03:27:38 --> Config Class Initialized
INFO - 2022-07-04 03:27:38 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:27:38 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:27:38 --> Utf8 Class Initialized
INFO - 2022-07-04 03:27:38 --> URI Class Initialized
INFO - 2022-07-04 03:27:38 --> Router Class Initialized
INFO - 2022-07-04 03:27:38 --> Output Class Initialized
INFO - 2022-07-04 03:27:38 --> Security Class Initialized
DEBUG - 2022-07-04 03:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:27:38 --> Input Class Initialized
INFO - 2022-07-04 03:27:38 --> Language Class Initialized
INFO - 2022-07-04 03:27:38 --> Language Class Initialized
INFO - 2022-07-04 03:27:38 --> Config Class Initialized
INFO - 2022-07-04 03:27:38 --> Loader Class Initialized
INFO - 2022-07-04 03:27:38 --> Helper loaded: url_helper
INFO - 2022-07-04 03:27:38 --> Helper loaded: file_helper
INFO - 2022-07-04 03:27:38 --> Helper loaded: form_helper
INFO - 2022-07-04 03:27:38 --> Helper loaded: my_helper
INFO - 2022-07-04 03:27:38 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:27:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:27:38 --> Controller Class Initialized
INFO - 2022-07-04 03:27:38 --> Final output sent to browser
DEBUG - 2022-07-04 03:27:38 --> Total execution time: 0.0515
INFO - 2022-07-04 03:27:44 --> Config Class Initialized
INFO - 2022-07-04 03:27:44 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:27:44 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:27:44 --> Utf8 Class Initialized
INFO - 2022-07-04 03:27:44 --> URI Class Initialized
INFO - 2022-07-04 03:27:44 --> Router Class Initialized
INFO - 2022-07-04 03:27:44 --> Output Class Initialized
INFO - 2022-07-04 03:27:44 --> Security Class Initialized
DEBUG - 2022-07-04 03:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:27:44 --> Input Class Initialized
INFO - 2022-07-04 03:27:44 --> Language Class Initialized
INFO - 2022-07-04 03:27:44 --> Language Class Initialized
INFO - 2022-07-04 03:27:44 --> Config Class Initialized
INFO - 2022-07-04 03:27:44 --> Loader Class Initialized
INFO - 2022-07-04 03:27:44 --> Helper loaded: url_helper
INFO - 2022-07-04 03:27:44 --> Helper loaded: file_helper
INFO - 2022-07-04 03:27:44 --> Helper loaded: form_helper
INFO - 2022-07-04 03:27:44 --> Helper loaded: my_helper
INFO - 2022-07-04 03:27:44 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:27:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:27:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:27:44 --> Controller Class Initialized
DEBUG - 2022-07-04 03:27:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2022-07-04 03:27:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 03:27:44 --> Final output sent to browser
DEBUG - 2022-07-04 03:27:44 --> Total execution time: 0.0680
INFO - 2022-07-04 03:28:05 --> Config Class Initialized
INFO - 2022-07-04 03:28:05 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:28:05 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:28:05 --> Utf8 Class Initialized
INFO - 2022-07-04 03:28:05 --> URI Class Initialized
INFO - 2022-07-04 03:28:05 --> Router Class Initialized
INFO - 2022-07-04 03:28:05 --> Output Class Initialized
INFO - 2022-07-04 03:28:05 --> Security Class Initialized
DEBUG - 2022-07-04 03:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:28:05 --> Input Class Initialized
INFO - 2022-07-04 03:28:05 --> Language Class Initialized
INFO - 2022-07-04 03:28:05 --> Language Class Initialized
INFO - 2022-07-04 03:28:05 --> Config Class Initialized
INFO - 2022-07-04 03:28:05 --> Loader Class Initialized
INFO - 2022-07-04 03:28:05 --> Helper loaded: url_helper
INFO - 2022-07-04 03:28:05 --> Helper loaded: file_helper
INFO - 2022-07-04 03:28:05 --> Helper loaded: form_helper
INFO - 2022-07-04 03:28:05 --> Helper loaded: my_helper
INFO - 2022-07-04 03:28:05 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:28:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:28:05 --> Controller Class Initialized
INFO - 2022-07-04 03:28:05 --> Helper loaded: cookie_helper
INFO - 2022-07-04 03:28:05 --> Config Class Initialized
INFO - 2022-07-04 03:28:05 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:28:05 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:28:05 --> Utf8 Class Initialized
INFO - 2022-07-04 03:28:05 --> URI Class Initialized
INFO - 2022-07-04 03:28:05 --> Router Class Initialized
INFO - 2022-07-04 03:28:05 --> Output Class Initialized
INFO - 2022-07-04 03:28:05 --> Security Class Initialized
DEBUG - 2022-07-04 03:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:28:05 --> Input Class Initialized
INFO - 2022-07-04 03:28:05 --> Language Class Initialized
INFO - 2022-07-04 03:28:05 --> Language Class Initialized
INFO - 2022-07-04 03:28:05 --> Config Class Initialized
INFO - 2022-07-04 03:28:05 --> Loader Class Initialized
INFO - 2022-07-04 03:28:05 --> Helper loaded: url_helper
INFO - 2022-07-04 03:28:05 --> Helper loaded: file_helper
INFO - 2022-07-04 03:28:05 --> Helper loaded: form_helper
INFO - 2022-07-04 03:28:05 --> Helper loaded: my_helper
INFO - 2022-07-04 03:28:05 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:28:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:28:05 --> Controller Class Initialized
DEBUG - 2022-07-04 03:28:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-07-04 03:28:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 03:28:05 --> Final output sent to browser
DEBUG - 2022-07-04 03:28:05 --> Total execution time: 0.0520
INFO - 2022-07-04 03:28:16 --> Config Class Initialized
INFO - 2022-07-04 03:28:16 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:28:16 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:28:16 --> Utf8 Class Initialized
INFO - 2022-07-04 03:28:16 --> URI Class Initialized
INFO - 2022-07-04 03:28:16 --> Router Class Initialized
INFO - 2022-07-04 03:28:16 --> Output Class Initialized
INFO - 2022-07-04 03:28:16 --> Security Class Initialized
DEBUG - 2022-07-04 03:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:28:16 --> Input Class Initialized
INFO - 2022-07-04 03:28:16 --> Language Class Initialized
INFO - 2022-07-04 03:28:16 --> Language Class Initialized
INFO - 2022-07-04 03:28:16 --> Config Class Initialized
INFO - 2022-07-04 03:28:16 --> Loader Class Initialized
INFO - 2022-07-04 03:28:16 --> Helper loaded: url_helper
INFO - 2022-07-04 03:28:16 --> Helper loaded: file_helper
INFO - 2022-07-04 03:28:16 --> Helper loaded: form_helper
INFO - 2022-07-04 03:28:16 --> Helper loaded: my_helper
INFO - 2022-07-04 03:28:16 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:28:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:28:16 --> Controller Class Initialized
INFO - 2022-07-04 03:28:16 --> Helper loaded: cookie_helper
INFO - 2022-07-04 03:28:16 --> Final output sent to browser
DEBUG - 2022-07-04 03:28:16 --> Total execution time: 0.0473
INFO - 2022-07-04 03:28:18 --> Config Class Initialized
INFO - 2022-07-04 03:28:18 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:28:18 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:28:18 --> Utf8 Class Initialized
INFO - 2022-07-04 03:28:18 --> URI Class Initialized
INFO - 2022-07-04 03:28:18 --> Router Class Initialized
INFO - 2022-07-04 03:28:18 --> Output Class Initialized
INFO - 2022-07-04 03:28:18 --> Security Class Initialized
DEBUG - 2022-07-04 03:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:28:18 --> Input Class Initialized
INFO - 2022-07-04 03:28:18 --> Language Class Initialized
INFO - 2022-07-04 03:28:18 --> Language Class Initialized
INFO - 2022-07-04 03:28:18 --> Config Class Initialized
INFO - 2022-07-04 03:28:18 --> Loader Class Initialized
INFO - 2022-07-04 03:28:18 --> Helper loaded: url_helper
INFO - 2022-07-04 03:28:18 --> Helper loaded: file_helper
INFO - 2022-07-04 03:28:18 --> Helper loaded: form_helper
INFO - 2022-07-04 03:28:18 --> Helper loaded: my_helper
INFO - 2022-07-04 03:28:18 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:28:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:28:18 --> Controller Class Initialized
DEBUG - 2022-07-04 03:28:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-07-04 03:28:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 03:28:19 --> Final output sent to browser
DEBUG - 2022-07-04 03:28:19 --> Total execution time: 0.6441
INFO - 2022-07-04 03:28:23 --> Config Class Initialized
INFO - 2022-07-04 03:28:23 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:28:23 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:28:23 --> Utf8 Class Initialized
INFO - 2022-07-04 03:28:23 --> URI Class Initialized
INFO - 2022-07-04 03:28:23 --> Router Class Initialized
INFO - 2022-07-04 03:28:23 --> Output Class Initialized
INFO - 2022-07-04 03:28:23 --> Security Class Initialized
DEBUG - 2022-07-04 03:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:28:23 --> Input Class Initialized
INFO - 2022-07-04 03:28:23 --> Language Class Initialized
INFO - 2022-07-04 03:28:23 --> Language Class Initialized
INFO - 2022-07-04 03:28:23 --> Config Class Initialized
INFO - 2022-07-04 03:28:23 --> Loader Class Initialized
INFO - 2022-07-04 03:28:23 --> Helper loaded: url_helper
INFO - 2022-07-04 03:28:23 --> Helper loaded: file_helper
INFO - 2022-07-04 03:28:23 --> Helper loaded: form_helper
INFO - 2022-07-04 03:28:23 --> Helper loaded: my_helper
INFO - 2022-07-04 03:28:23 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:28:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:28:23 --> Controller Class Initialized
DEBUG - 2022-07-04 03:28:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2022-07-04 03:28:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 03:28:23 --> Final output sent to browser
DEBUG - 2022-07-04 03:28:23 --> Total execution time: 0.0764
INFO - 2022-07-04 03:31:18 --> Config Class Initialized
INFO - 2022-07-04 03:31:18 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:31:18 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:31:18 --> Utf8 Class Initialized
INFO - 2022-07-04 03:31:18 --> URI Class Initialized
INFO - 2022-07-04 03:31:18 --> Router Class Initialized
INFO - 2022-07-04 03:31:18 --> Output Class Initialized
INFO - 2022-07-04 03:31:18 --> Security Class Initialized
DEBUG - 2022-07-04 03:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:31:18 --> Input Class Initialized
INFO - 2022-07-04 03:31:18 --> Language Class Initialized
INFO - 2022-07-04 03:31:18 --> Language Class Initialized
INFO - 2022-07-04 03:31:18 --> Config Class Initialized
INFO - 2022-07-04 03:31:18 --> Loader Class Initialized
INFO - 2022-07-04 03:31:18 --> Helper loaded: url_helper
INFO - 2022-07-04 03:31:18 --> Helper loaded: file_helper
INFO - 2022-07-04 03:31:18 --> Helper loaded: form_helper
INFO - 2022-07-04 03:31:18 --> Helper loaded: my_helper
INFO - 2022-07-04 03:31:18 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:31:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:31:18 --> Controller Class Initialized
INFO - 2022-07-04 03:31:18 --> Final output sent to browser
DEBUG - 2022-07-04 03:31:18 --> Total execution time: 0.0498
INFO - 2022-07-04 03:31:37 --> Config Class Initialized
INFO - 2022-07-04 03:31:37 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:31:37 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:31:37 --> Utf8 Class Initialized
INFO - 2022-07-04 03:31:37 --> URI Class Initialized
INFO - 2022-07-04 03:31:37 --> Router Class Initialized
INFO - 2022-07-04 03:31:37 --> Output Class Initialized
INFO - 2022-07-04 03:31:37 --> Security Class Initialized
DEBUG - 2022-07-04 03:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:31:37 --> Input Class Initialized
INFO - 2022-07-04 03:31:37 --> Language Class Initialized
INFO - 2022-07-04 03:31:37 --> Language Class Initialized
INFO - 2022-07-04 03:31:37 --> Config Class Initialized
INFO - 2022-07-04 03:31:37 --> Loader Class Initialized
INFO - 2022-07-04 03:31:37 --> Helper loaded: url_helper
INFO - 2022-07-04 03:31:37 --> Helper loaded: file_helper
INFO - 2022-07-04 03:31:37 --> Helper loaded: form_helper
INFO - 2022-07-04 03:31:37 --> Helper loaded: my_helper
INFO - 2022-07-04 03:31:37 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:31:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:31:37 --> Controller Class Initialized
DEBUG - 2022-07-04 03:31:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2022-07-04 03:31:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 03:31:37 --> Final output sent to browser
DEBUG - 2022-07-04 03:31:37 --> Total execution time: 0.0783
INFO - 2022-07-04 03:31:39 --> Config Class Initialized
INFO - 2022-07-04 03:31:39 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:31:39 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:31:39 --> Utf8 Class Initialized
INFO - 2022-07-04 03:31:39 --> URI Class Initialized
INFO - 2022-07-04 03:31:39 --> Router Class Initialized
INFO - 2022-07-04 03:31:39 --> Output Class Initialized
INFO - 2022-07-04 03:31:39 --> Security Class Initialized
DEBUG - 2022-07-04 03:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:31:39 --> Input Class Initialized
INFO - 2022-07-04 03:31:39 --> Language Class Initialized
INFO - 2022-07-04 03:31:39 --> Language Class Initialized
INFO - 2022-07-04 03:31:39 --> Config Class Initialized
INFO - 2022-07-04 03:31:39 --> Loader Class Initialized
INFO - 2022-07-04 03:31:39 --> Helper loaded: url_helper
INFO - 2022-07-04 03:31:39 --> Helper loaded: file_helper
INFO - 2022-07-04 03:31:39 --> Helper loaded: form_helper
INFO - 2022-07-04 03:31:39 --> Helper loaded: my_helper
INFO - 2022-07-04 03:31:39 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:31:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:31:39 --> Controller Class Initialized
DEBUG - 2022-07-04 03:31:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2022-07-04 03:31:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 03:31:39 --> Final output sent to browser
DEBUG - 2022-07-04 03:31:39 --> Total execution time: 0.0588
INFO - 2022-07-04 03:32:43 --> Config Class Initialized
INFO - 2022-07-04 03:32:43 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:32:43 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:32:43 --> Utf8 Class Initialized
INFO - 2022-07-04 03:32:43 --> URI Class Initialized
INFO - 2022-07-04 03:32:43 --> Router Class Initialized
INFO - 2022-07-04 03:32:43 --> Output Class Initialized
INFO - 2022-07-04 03:32:43 --> Security Class Initialized
DEBUG - 2022-07-04 03:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:32:43 --> Input Class Initialized
INFO - 2022-07-04 03:32:43 --> Language Class Initialized
INFO - 2022-07-04 03:32:43 --> Language Class Initialized
INFO - 2022-07-04 03:32:43 --> Config Class Initialized
INFO - 2022-07-04 03:32:43 --> Loader Class Initialized
INFO - 2022-07-04 03:32:43 --> Helper loaded: url_helper
INFO - 2022-07-04 03:32:43 --> Helper loaded: file_helper
INFO - 2022-07-04 03:32:43 --> Helper loaded: form_helper
INFO - 2022-07-04 03:32:43 --> Helper loaded: my_helper
INFO - 2022-07-04 03:32:43 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:32:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:32:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:32:43 --> Controller Class Initialized
INFO - 2022-07-04 03:32:44 --> Final output sent to browser
DEBUG - 2022-07-04 03:32:44 --> Total execution time: 0.0612
INFO - 2022-07-04 03:32:55 --> Config Class Initialized
INFO - 2022-07-04 03:32:55 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:32:55 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:32:55 --> Utf8 Class Initialized
INFO - 2022-07-04 03:32:55 --> URI Class Initialized
INFO - 2022-07-04 03:32:55 --> Router Class Initialized
INFO - 2022-07-04 03:32:55 --> Output Class Initialized
INFO - 2022-07-04 03:32:55 --> Security Class Initialized
DEBUG - 2022-07-04 03:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:32:55 --> Input Class Initialized
INFO - 2022-07-04 03:32:55 --> Language Class Initialized
INFO - 2022-07-04 03:32:55 --> Language Class Initialized
INFO - 2022-07-04 03:32:55 --> Config Class Initialized
INFO - 2022-07-04 03:32:55 --> Loader Class Initialized
INFO - 2022-07-04 03:32:55 --> Helper loaded: url_helper
INFO - 2022-07-04 03:32:55 --> Helper loaded: file_helper
INFO - 2022-07-04 03:32:55 --> Helper loaded: form_helper
INFO - 2022-07-04 03:32:55 --> Helper loaded: my_helper
INFO - 2022-07-04 03:32:55 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:32:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:32:55 --> Controller Class Initialized
DEBUG - 2022-07-04 03:32:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2022-07-04 03:32:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 03:32:55 --> Final output sent to browser
DEBUG - 2022-07-04 03:32:55 --> Total execution time: 0.0736
INFO - 2022-07-04 03:32:56 --> Config Class Initialized
INFO - 2022-07-04 03:32:56 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:32:56 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:32:56 --> Utf8 Class Initialized
INFO - 2022-07-04 03:32:56 --> URI Class Initialized
INFO - 2022-07-04 03:32:56 --> Router Class Initialized
INFO - 2022-07-04 03:32:56 --> Output Class Initialized
INFO - 2022-07-04 03:32:56 --> Security Class Initialized
DEBUG - 2022-07-04 03:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:32:56 --> Input Class Initialized
INFO - 2022-07-04 03:32:56 --> Language Class Initialized
INFO - 2022-07-04 03:32:56 --> Language Class Initialized
INFO - 2022-07-04 03:32:56 --> Config Class Initialized
INFO - 2022-07-04 03:32:56 --> Loader Class Initialized
INFO - 2022-07-04 03:32:56 --> Helper loaded: url_helper
INFO - 2022-07-04 03:32:56 --> Helper loaded: file_helper
INFO - 2022-07-04 03:32:56 --> Helper loaded: form_helper
INFO - 2022-07-04 03:32:56 --> Helper loaded: my_helper
INFO - 2022-07-04 03:32:56 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:32:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:32:56 --> Controller Class Initialized
DEBUG - 2022-07-04 03:32:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2022-07-04 03:32:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 03:32:56 --> Final output sent to browser
DEBUG - 2022-07-04 03:32:56 --> Total execution time: 0.0663
INFO - 2022-07-04 03:32:58 --> Config Class Initialized
INFO - 2022-07-04 03:32:58 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:32:58 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:32:58 --> Utf8 Class Initialized
INFO - 2022-07-04 03:32:58 --> URI Class Initialized
INFO - 2022-07-04 03:32:58 --> Router Class Initialized
INFO - 2022-07-04 03:32:58 --> Output Class Initialized
INFO - 2022-07-04 03:32:58 --> Security Class Initialized
DEBUG - 2022-07-04 03:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:32:58 --> Input Class Initialized
INFO - 2022-07-04 03:32:58 --> Language Class Initialized
INFO - 2022-07-04 03:32:58 --> Language Class Initialized
INFO - 2022-07-04 03:32:58 --> Config Class Initialized
INFO - 2022-07-04 03:32:58 --> Loader Class Initialized
INFO - 2022-07-04 03:32:58 --> Helper loaded: url_helper
INFO - 2022-07-04 03:32:58 --> Helper loaded: file_helper
INFO - 2022-07-04 03:32:58 --> Helper loaded: form_helper
INFO - 2022-07-04 03:32:58 --> Helper loaded: my_helper
INFO - 2022-07-04 03:32:58 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:32:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:32:58 --> Controller Class Initialized
DEBUG - 2022-07-04 03:32:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-07-04 03:32:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 03:32:58 --> Final output sent to browser
DEBUG - 2022-07-04 03:32:58 --> Total execution time: 0.0426
INFO - 2022-07-04 03:33:00 --> Config Class Initialized
INFO - 2022-07-04 03:33:00 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:33:00 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:33:00 --> Utf8 Class Initialized
INFO - 2022-07-04 03:33:00 --> URI Class Initialized
INFO - 2022-07-04 03:33:00 --> Router Class Initialized
INFO - 2022-07-04 03:33:00 --> Output Class Initialized
INFO - 2022-07-04 03:33:00 --> Security Class Initialized
DEBUG - 2022-07-04 03:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:33:00 --> Input Class Initialized
INFO - 2022-07-04 03:33:00 --> Language Class Initialized
INFO - 2022-07-04 03:33:00 --> Language Class Initialized
INFO - 2022-07-04 03:33:00 --> Config Class Initialized
INFO - 2022-07-04 03:33:00 --> Loader Class Initialized
INFO - 2022-07-04 03:33:00 --> Helper loaded: url_helper
INFO - 2022-07-04 03:33:00 --> Helper loaded: file_helper
INFO - 2022-07-04 03:33:00 --> Helper loaded: form_helper
INFO - 2022-07-04 03:33:00 --> Helper loaded: my_helper
INFO - 2022-07-04 03:33:00 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:33:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:33:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:33:00 --> Controller Class Initialized
INFO - 2022-07-04 03:33:00 --> Final output sent to browser
DEBUG - 2022-07-04 03:33:00 --> Total execution time: 0.0416
INFO - 2022-07-04 03:33:18 --> Config Class Initialized
INFO - 2022-07-04 03:33:18 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:33:18 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:33:18 --> Utf8 Class Initialized
INFO - 2022-07-04 03:33:18 --> URI Class Initialized
INFO - 2022-07-04 03:33:18 --> Router Class Initialized
INFO - 2022-07-04 03:33:18 --> Output Class Initialized
INFO - 2022-07-04 03:33:18 --> Security Class Initialized
DEBUG - 2022-07-04 03:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:33:18 --> Input Class Initialized
INFO - 2022-07-04 03:33:18 --> Language Class Initialized
INFO - 2022-07-04 03:33:18 --> Language Class Initialized
INFO - 2022-07-04 03:33:18 --> Config Class Initialized
INFO - 2022-07-04 03:33:18 --> Loader Class Initialized
INFO - 2022-07-04 03:33:18 --> Helper loaded: url_helper
INFO - 2022-07-04 03:33:18 --> Helper loaded: file_helper
INFO - 2022-07-04 03:33:18 --> Helper loaded: form_helper
INFO - 2022-07-04 03:33:18 --> Helper loaded: my_helper
INFO - 2022-07-04 03:33:18 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:33:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:33:18 --> Controller Class Initialized
INFO - 2022-07-04 03:33:18 --> Final output sent to browser
DEBUG - 2022-07-04 03:33:18 --> Total execution time: 0.0644
INFO - 2022-07-04 03:33:24 --> Config Class Initialized
INFO - 2022-07-04 03:33:24 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:33:24 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:33:24 --> Utf8 Class Initialized
INFO - 2022-07-04 03:33:24 --> URI Class Initialized
INFO - 2022-07-04 03:33:24 --> Router Class Initialized
INFO - 2022-07-04 03:33:24 --> Output Class Initialized
INFO - 2022-07-04 03:33:24 --> Security Class Initialized
DEBUG - 2022-07-04 03:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:33:24 --> Input Class Initialized
INFO - 2022-07-04 03:33:24 --> Language Class Initialized
INFO - 2022-07-04 03:33:24 --> Language Class Initialized
INFO - 2022-07-04 03:33:24 --> Config Class Initialized
INFO - 2022-07-04 03:33:24 --> Loader Class Initialized
INFO - 2022-07-04 03:33:24 --> Helper loaded: url_helper
INFO - 2022-07-04 03:33:24 --> Helper loaded: file_helper
INFO - 2022-07-04 03:33:24 --> Helper loaded: form_helper
INFO - 2022-07-04 03:33:24 --> Helper loaded: my_helper
INFO - 2022-07-04 03:33:24 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:33:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:33:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:33:24 --> Controller Class Initialized
INFO - 2022-07-04 03:33:24 --> Final output sent to browser
DEBUG - 2022-07-04 03:33:24 --> Total execution time: 0.0664
INFO - 2022-07-04 03:33:35 --> Config Class Initialized
INFO - 2022-07-04 03:33:35 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:33:35 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:33:35 --> Utf8 Class Initialized
INFO - 2022-07-04 03:33:35 --> URI Class Initialized
INFO - 2022-07-04 03:33:35 --> Router Class Initialized
INFO - 2022-07-04 03:33:35 --> Output Class Initialized
INFO - 2022-07-04 03:33:35 --> Security Class Initialized
DEBUG - 2022-07-04 03:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:33:35 --> Input Class Initialized
INFO - 2022-07-04 03:33:35 --> Language Class Initialized
INFO - 2022-07-04 03:33:35 --> Language Class Initialized
INFO - 2022-07-04 03:33:35 --> Config Class Initialized
INFO - 2022-07-04 03:33:35 --> Loader Class Initialized
INFO - 2022-07-04 03:33:35 --> Helper loaded: url_helper
INFO - 2022-07-04 03:33:35 --> Helper loaded: file_helper
INFO - 2022-07-04 03:33:35 --> Helper loaded: form_helper
INFO - 2022-07-04 03:33:35 --> Helper loaded: my_helper
INFO - 2022-07-04 03:33:35 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:33:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:33:35 --> Controller Class Initialized
DEBUG - 2022-07-04 03:33:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2022-07-04 03:33:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 03:33:35 --> Final output sent to browser
DEBUG - 2022-07-04 03:33:35 --> Total execution time: 0.0630
INFO - 2022-07-04 03:33:49 --> Config Class Initialized
INFO - 2022-07-04 03:33:49 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:33:49 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:33:49 --> Utf8 Class Initialized
INFO - 2022-07-04 03:33:49 --> URI Class Initialized
INFO - 2022-07-04 03:33:49 --> Router Class Initialized
INFO - 2022-07-04 03:33:49 --> Output Class Initialized
INFO - 2022-07-04 03:33:49 --> Security Class Initialized
DEBUG - 2022-07-04 03:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:33:49 --> Input Class Initialized
INFO - 2022-07-04 03:33:49 --> Language Class Initialized
INFO - 2022-07-04 03:33:49 --> Language Class Initialized
INFO - 2022-07-04 03:33:49 --> Config Class Initialized
INFO - 2022-07-04 03:33:49 --> Loader Class Initialized
INFO - 2022-07-04 03:33:49 --> Helper loaded: url_helper
INFO - 2022-07-04 03:33:49 --> Helper loaded: file_helper
INFO - 2022-07-04 03:33:49 --> Helper loaded: form_helper
INFO - 2022-07-04 03:33:49 --> Helper loaded: my_helper
INFO - 2022-07-04 03:33:49 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:33:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:33:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:33:49 --> Controller Class Initialized
INFO - 2022-07-04 03:33:49 --> Final output sent to browser
DEBUG - 2022-07-04 03:33:49 --> Total execution time: 0.0710
INFO - 2022-07-04 03:33:59 --> Config Class Initialized
INFO - 2022-07-04 03:33:59 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:33:59 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:33:59 --> Utf8 Class Initialized
INFO - 2022-07-04 03:33:59 --> URI Class Initialized
INFO - 2022-07-04 03:33:59 --> Router Class Initialized
INFO - 2022-07-04 03:33:59 --> Output Class Initialized
INFO - 2022-07-04 03:33:59 --> Security Class Initialized
DEBUG - 2022-07-04 03:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:33:59 --> Input Class Initialized
INFO - 2022-07-04 03:33:59 --> Language Class Initialized
INFO - 2022-07-04 03:33:59 --> Language Class Initialized
INFO - 2022-07-04 03:33:59 --> Config Class Initialized
INFO - 2022-07-04 03:33:59 --> Loader Class Initialized
INFO - 2022-07-04 03:33:59 --> Helper loaded: url_helper
INFO - 2022-07-04 03:33:59 --> Helper loaded: file_helper
INFO - 2022-07-04 03:33:59 --> Helper loaded: form_helper
INFO - 2022-07-04 03:33:59 --> Helper loaded: my_helper
INFO - 2022-07-04 03:33:59 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:33:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:33:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:33:59 --> Controller Class Initialized
DEBUG - 2022-07-04 03:33:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-07-04 03:33:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 03:33:59 --> Final output sent to browser
DEBUG - 2022-07-04 03:33:59 --> Total execution time: 0.1248
INFO - 2022-07-04 03:34:09 --> Config Class Initialized
INFO - 2022-07-04 03:34:09 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:34:09 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:34:09 --> Utf8 Class Initialized
INFO - 2022-07-04 03:34:09 --> URI Class Initialized
INFO - 2022-07-04 03:34:09 --> Router Class Initialized
INFO - 2022-07-04 03:34:09 --> Output Class Initialized
INFO - 2022-07-04 03:34:09 --> Security Class Initialized
DEBUG - 2022-07-04 03:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:34:09 --> Input Class Initialized
INFO - 2022-07-04 03:34:09 --> Language Class Initialized
INFO - 2022-07-04 03:34:09 --> Language Class Initialized
INFO - 2022-07-04 03:34:09 --> Config Class Initialized
INFO - 2022-07-04 03:34:09 --> Loader Class Initialized
INFO - 2022-07-04 03:34:09 --> Helper loaded: url_helper
INFO - 2022-07-04 03:34:09 --> Helper loaded: file_helper
INFO - 2022-07-04 03:34:09 --> Helper loaded: form_helper
INFO - 2022-07-04 03:34:09 --> Helper loaded: my_helper
INFO - 2022-07-04 03:34:09 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:34:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:34:09 --> Controller Class Initialized
DEBUG - 2022-07-04 03:34:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2022-07-04 03:34:09 --> Final output sent to browser
DEBUG - 2022-07-04 03:34:09 --> Total execution time: 0.2801
INFO - 2022-07-04 03:34:58 --> Config Class Initialized
INFO - 2022-07-04 03:34:58 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:34:58 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:34:58 --> Utf8 Class Initialized
INFO - 2022-07-04 03:34:58 --> URI Class Initialized
INFO - 2022-07-04 03:34:58 --> Router Class Initialized
INFO - 2022-07-04 03:34:58 --> Output Class Initialized
INFO - 2022-07-04 03:34:58 --> Security Class Initialized
DEBUG - 2022-07-04 03:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:34:58 --> Input Class Initialized
INFO - 2022-07-04 03:34:58 --> Language Class Initialized
INFO - 2022-07-04 03:34:58 --> Language Class Initialized
INFO - 2022-07-04 03:34:58 --> Config Class Initialized
INFO - 2022-07-04 03:34:58 --> Loader Class Initialized
INFO - 2022-07-04 03:34:58 --> Helper loaded: url_helper
INFO - 2022-07-04 03:34:58 --> Helper loaded: file_helper
INFO - 2022-07-04 03:34:58 --> Helper loaded: form_helper
INFO - 2022-07-04 03:34:58 --> Helper loaded: my_helper
INFO - 2022-07-04 03:34:58 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:34:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:34:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:34:58 --> Controller Class Initialized
INFO - 2022-07-04 03:34:58 --> Helper loaded: cookie_helper
INFO - 2022-07-04 03:34:58 --> Config Class Initialized
INFO - 2022-07-04 03:34:58 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:34:58 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:34:58 --> Utf8 Class Initialized
INFO - 2022-07-04 03:34:58 --> URI Class Initialized
INFO - 2022-07-04 03:34:58 --> Router Class Initialized
INFO - 2022-07-04 03:34:58 --> Output Class Initialized
INFO - 2022-07-04 03:34:58 --> Security Class Initialized
DEBUG - 2022-07-04 03:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:34:58 --> Input Class Initialized
INFO - 2022-07-04 03:34:58 --> Language Class Initialized
INFO - 2022-07-04 03:34:58 --> Language Class Initialized
INFO - 2022-07-04 03:34:58 --> Config Class Initialized
INFO - 2022-07-04 03:34:58 --> Loader Class Initialized
INFO - 2022-07-04 03:34:58 --> Helper loaded: url_helper
INFO - 2022-07-04 03:34:58 --> Helper loaded: file_helper
INFO - 2022-07-04 03:34:58 --> Helper loaded: form_helper
INFO - 2022-07-04 03:34:58 --> Helper loaded: my_helper
INFO - 2022-07-04 03:34:58 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:34:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:34:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:34:58 --> Controller Class Initialized
DEBUG - 2022-07-04 03:34:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-07-04 03:34:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 03:34:58 --> Final output sent to browser
DEBUG - 2022-07-04 03:34:58 --> Total execution time: 0.0536
INFO - 2022-07-04 03:35:07 --> Config Class Initialized
INFO - 2022-07-04 03:35:07 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:35:07 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:35:07 --> Utf8 Class Initialized
INFO - 2022-07-04 03:35:07 --> URI Class Initialized
INFO - 2022-07-04 03:35:07 --> Router Class Initialized
INFO - 2022-07-04 03:35:07 --> Output Class Initialized
INFO - 2022-07-04 03:35:07 --> Security Class Initialized
DEBUG - 2022-07-04 03:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:35:07 --> Input Class Initialized
INFO - 2022-07-04 03:35:07 --> Language Class Initialized
INFO - 2022-07-04 03:35:07 --> Language Class Initialized
INFO - 2022-07-04 03:35:07 --> Config Class Initialized
INFO - 2022-07-04 03:35:07 --> Loader Class Initialized
INFO - 2022-07-04 03:35:07 --> Helper loaded: url_helper
INFO - 2022-07-04 03:35:07 --> Helper loaded: file_helper
INFO - 2022-07-04 03:35:07 --> Helper loaded: form_helper
INFO - 2022-07-04 03:35:07 --> Helper loaded: my_helper
INFO - 2022-07-04 03:35:07 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:35:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:35:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:35:07 --> Controller Class Initialized
INFO - 2022-07-04 03:35:07 --> Helper loaded: cookie_helper
INFO - 2022-07-04 03:35:07 --> Final output sent to browser
DEBUG - 2022-07-04 03:35:07 --> Total execution time: 0.0605
INFO - 2022-07-04 03:35:08 --> Config Class Initialized
INFO - 2022-07-04 03:35:08 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:35:08 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:35:08 --> Utf8 Class Initialized
INFO - 2022-07-04 03:35:08 --> URI Class Initialized
INFO - 2022-07-04 03:35:08 --> Router Class Initialized
INFO - 2022-07-04 03:35:08 --> Output Class Initialized
INFO - 2022-07-04 03:35:08 --> Security Class Initialized
DEBUG - 2022-07-04 03:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:35:08 --> Input Class Initialized
INFO - 2022-07-04 03:35:08 --> Language Class Initialized
INFO - 2022-07-04 03:35:08 --> Language Class Initialized
INFO - 2022-07-04 03:35:08 --> Config Class Initialized
INFO - 2022-07-04 03:35:08 --> Loader Class Initialized
INFO - 2022-07-04 03:35:08 --> Helper loaded: url_helper
INFO - 2022-07-04 03:35:08 --> Helper loaded: file_helper
INFO - 2022-07-04 03:35:08 --> Helper loaded: form_helper
INFO - 2022-07-04 03:35:08 --> Helper loaded: my_helper
INFO - 2022-07-04 03:35:08 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:35:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:35:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:35:08 --> Controller Class Initialized
DEBUG - 2022-07-04 03:35:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-07-04 03:35:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 03:35:08 --> Final output sent to browser
DEBUG - 2022-07-04 03:35:08 --> Total execution time: 0.5689
INFO - 2022-07-04 03:35:11 --> Config Class Initialized
INFO - 2022-07-04 03:35:11 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:35:11 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:35:11 --> Utf8 Class Initialized
INFO - 2022-07-04 03:35:11 --> URI Class Initialized
INFO - 2022-07-04 03:35:11 --> Router Class Initialized
INFO - 2022-07-04 03:35:11 --> Output Class Initialized
INFO - 2022-07-04 03:35:11 --> Security Class Initialized
DEBUG - 2022-07-04 03:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:35:11 --> Input Class Initialized
INFO - 2022-07-04 03:35:11 --> Language Class Initialized
INFO - 2022-07-04 03:35:11 --> Language Class Initialized
INFO - 2022-07-04 03:35:11 --> Config Class Initialized
INFO - 2022-07-04 03:35:11 --> Loader Class Initialized
INFO - 2022-07-04 03:35:11 --> Helper loaded: url_helper
INFO - 2022-07-04 03:35:11 --> Helper loaded: file_helper
INFO - 2022-07-04 03:35:11 --> Helper loaded: form_helper
INFO - 2022-07-04 03:35:11 --> Helper loaded: my_helper
INFO - 2022-07-04 03:35:11 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:35:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:35:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:35:11 --> Controller Class Initialized
DEBUG - 2022-07-04 03:35:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-07-04 03:35:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 03:35:11 --> Final output sent to browser
DEBUG - 2022-07-04 03:35:11 --> Total execution time: 0.0703
INFO - 2022-07-04 03:35:17 --> Config Class Initialized
INFO - 2022-07-04 03:35:17 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:35:17 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:35:17 --> Utf8 Class Initialized
INFO - 2022-07-04 03:35:17 --> URI Class Initialized
INFO - 2022-07-04 03:35:17 --> Router Class Initialized
INFO - 2022-07-04 03:35:17 --> Output Class Initialized
INFO - 2022-07-04 03:35:17 --> Security Class Initialized
DEBUG - 2022-07-04 03:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:35:17 --> Input Class Initialized
INFO - 2022-07-04 03:35:17 --> Language Class Initialized
INFO - 2022-07-04 03:35:17 --> Language Class Initialized
INFO - 2022-07-04 03:35:17 --> Config Class Initialized
INFO - 2022-07-04 03:35:17 --> Loader Class Initialized
INFO - 2022-07-04 03:35:17 --> Helper loaded: url_helper
INFO - 2022-07-04 03:35:17 --> Helper loaded: file_helper
INFO - 2022-07-04 03:35:17 --> Helper loaded: form_helper
INFO - 2022-07-04 03:35:17 --> Helper loaded: my_helper
INFO - 2022-07-04 03:35:17 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:35:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:35:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:35:17 --> Controller Class Initialized
DEBUG - 2022-07-04 03:35:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-07-04 03:35:17 --> Final output sent to browser
DEBUG - 2022-07-04 03:35:17 --> Total execution time: 0.2861
INFO - 2022-07-04 03:35:24 --> Config Class Initialized
INFO - 2022-07-04 03:35:24 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:35:24 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:35:24 --> Utf8 Class Initialized
INFO - 2022-07-04 03:35:24 --> URI Class Initialized
INFO - 2022-07-04 03:35:24 --> Router Class Initialized
INFO - 2022-07-04 03:35:24 --> Output Class Initialized
INFO - 2022-07-04 03:35:24 --> Security Class Initialized
DEBUG - 2022-07-04 03:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:35:24 --> Input Class Initialized
INFO - 2022-07-04 03:35:24 --> Language Class Initialized
INFO - 2022-07-04 03:35:24 --> Language Class Initialized
INFO - 2022-07-04 03:35:24 --> Config Class Initialized
INFO - 2022-07-04 03:35:24 --> Loader Class Initialized
INFO - 2022-07-04 03:35:24 --> Helper loaded: url_helper
INFO - 2022-07-04 03:35:24 --> Helper loaded: file_helper
INFO - 2022-07-04 03:35:24 --> Helper loaded: form_helper
INFO - 2022-07-04 03:35:24 --> Helper loaded: my_helper
INFO - 2022-07-04 03:35:24 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:35:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:35:24 --> Controller Class Initialized
DEBUG - 2022-07-04 03:35:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-07-04 03:35:24 --> Final output sent to browser
DEBUG - 2022-07-04 03:35:24 --> Total execution time: 0.1626
INFO - 2022-07-04 03:35:29 --> Config Class Initialized
INFO - 2022-07-04 03:35:29 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:35:29 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:35:29 --> Utf8 Class Initialized
INFO - 2022-07-04 03:35:29 --> URI Class Initialized
INFO - 2022-07-04 03:35:29 --> Router Class Initialized
INFO - 2022-07-04 03:35:29 --> Output Class Initialized
INFO - 2022-07-04 03:35:29 --> Security Class Initialized
DEBUG - 2022-07-04 03:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:35:29 --> Input Class Initialized
INFO - 2022-07-04 03:35:29 --> Language Class Initialized
INFO - 2022-07-04 03:35:29 --> Language Class Initialized
INFO - 2022-07-04 03:35:29 --> Config Class Initialized
INFO - 2022-07-04 03:35:29 --> Loader Class Initialized
INFO - 2022-07-04 03:35:29 --> Helper loaded: url_helper
INFO - 2022-07-04 03:35:29 --> Helper loaded: file_helper
INFO - 2022-07-04 03:35:29 --> Helper loaded: form_helper
INFO - 2022-07-04 03:35:29 --> Helper loaded: my_helper
INFO - 2022-07-04 03:35:29 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:35:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:35:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:35:29 --> Controller Class Initialized
DEBUG - 2022-07-04 03:35:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-07-04 03:35:29 --> Final output sent to browser
DEBUG - 2022-07-04 03:35:29 --> Total execution time: 0.1629
INFO - 2022-07-04 03:35:32 --> Config Class Initialized
INFO - 2022-07-04 03:35:32 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:35:32 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:35:32 --> Utf8 Class Initialized
INFO - 2022-07-04 03:35:32 --> URI Class Initialized
INFO - 2022-07-04 03:35:32 --> Router Class Initialized
INFO - 2022-07-04 03:35:32 --> Output Class Initialized
INFO - 2022-07-04 03:35:32 --> Security Class Initialized
DEBUG - 2022-07-04 03:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:35:32 --> Input Class Initialized
INFO - 2022-07-04 03:35:32 --> Language Class Initialized
INFO - 2022-07-04 03:35:32 --> Language Class Initialized
INFO - 2022-07-04 03:35:32 --> Config Class Initialized
INFO - 2022-07-04 03:35:32 --> Loader Class Initialized
INFO - 2022-07-04 03:35:32 --> Helper loaded: url_helper
INFO - 2022-07-04 03:35:32 --> Helper loaded: file_helper
INFO - 2022-07-04 03:35:32 --> Helper loaded: form_helper
INFO - 2022-07-04 03:35:32 --> Helper loaded: my_helper
INFO - 2022-07-04 03:35:32 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:35:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:35:32 --> Controller Class Initialized
DEBUG - 2022-07-04 03:35:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-07-04 03:35:32 --> Final output sent to browser
DEBUG - 2022-07-04 03:35:32 --> Total execution time: 0.1598
INFO - 2022-07-04 03:36:42 --> Config Class Initialized
INFO - 2022-07-04 03:36:42 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:36:42 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:36:42 --> Utf8 Class Initialized
INFO - 2022-07-04 03:36:42 --> URI Class Initialized
INFO - 2022-07-04 03:36:42 --> Router Class Initialized
INFO - 2022-07-04 03:36:42 --> Output Class Initialized
INFO - 2022-07-04 03:36:42 --> Security Class Initialized
DEBUG - 2022-07-04 03:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:36:42 --> Input Class Initialized
INFO - 2022-07-04 03:36:42 --> Language Class Initialized
INFO - 2022-07-04 03:36:42 --> Language Class Initialized
INFO - 2022-07-04 03:36:42 --> Config Class Initialized
INFO - 2022-07-04 03:36:42 --> Loader Class Initialized
INFO - 2022-07-04 03:36:42 --> Helper loaded: url_helper
INFO - 2022-07-04 03:36:42 --> Helper loaded: file_helper
INFO - 2022-07-04 03:36:42 --> Helper loaded: form_helper
INFO - 2022-07-04 03:36:42 --> Helper loaded: my_helper
INFO - 2022-07-04 03:36:42 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:36:42 --> Controller Class Initialized
INFO - 2022-07-04 03:36:42 --> Helper loaded: cookie_helper
INFO - 2022-07-04 03:36:42 --> Config Class Initialized
INFO - 2022-07-04 03:36:42 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:36:42 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:36:42 --> Utf8 Class Initialized
INFO - 2022-07-04 03:36:42 --> URI Class Initialized
INFO - 2022-07-04 03:36:42 --> Router Class Initialized
INFO - 2022-07-04 03:36:42 --> Output Class Initialized
INFO - 2022-07-04 03:36:42 --> Security Class Initialized
DEBUG - 2022-07-04 03:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:36:42 --> Input Class Initialized
INFO - 2022-07-04 03:36:42 --> Language Class Initialized
INFO - 2022-07-04 03:36:42 --> Language Class Initialized
INFO - 2022-07-04 03:36:42 --> Config Class Initialized
INFO - 2022-07-04 03:36:42 --> Loader Class Initialized
INFO - 2022-07-04 03:36:42 --> Helper loaded: url_helper
INFO - 2022-07-04 03:36:42 --> Helper loaded: file_helper
INFO - 2022-07-04 03:36:42 --> Helper loaded: form_helper
INFO - 2022-07-04 03:36:42 --> Helper loaded: my_helper
INFO - 2022-07-04 03:36:42 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:36:42 --> Controller Class Initialized
DEBUG - 2022-07-04 03:36:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-07-04 03:36:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 03:36:42 --> Final output sent to browser
DEBUG - 2022-07-04 03:36:42 --> Total execution time: 0.0418
INFO - 2022-07-04 03:50:08 --> Config Class Initialized
INFO - 2022-07-04 03:50:08 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:50:08 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:50:08 --> Utf8 Class Initialized
INFO - 2022-07-04 03:50:08 --> URI Class Initialized
INFO - 2022-07-04 03:50:08 --> Router Class Initialized
INFO - 2022-07-04 03:50:08 --> Output Class Initialized
INFO - 2022-07-04 03:50:08 --> Security Class Initialized
DEBUG - 2022-07-04 03:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:50:08 --> Input Class Initialized
INFO - 2022-07-04 03:50:08 --> Language Class Initialized
INFO - 2022-07-04 03:50:08 --> Language Class Initialized
INFO - 2022-07-04 03:50:08 --> Config Class Initialized
INFO - 2022-07-04 03:50:08 --> Loader Class Initialized
INFO - 2022-07-04 03:50:08 --> Helper loaded: url_helper
INFO - 2022-07-04 03:50:08 --> Helper loaded: file_helper
INFO - 2022-07-04 03:50:08 --> Helper loaded: form_helper
INFO - 2022-07-04 03:50:08 --> Helper loaded: my_helper
INFO - 2022-07-04 03:50:08 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:50:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:50:08 --> Controller Class Initialized
INFO - 2022-07-04 03:50:08 --> Helper loaded: cookie_helper
INFO - 2022-07-04 03:50:08 --> Final output sent to browser
DEBUG - 2022-07-04 03:50:08 --> Total execution time: 0.0767
INFO - 2022-07-04 03:50:08 --> Config Class Initialized
INFO - 2022-07-04 03:50:08 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:50:08 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:50:08 --> Utf8 Class Initialized
INFO - 2022-07-04 03:50:08 --> URI Class Initialized
INFO - 2022-07-04 03:50:08 --> Router Class Initialized
INFO - 2022-07-04 03:50:08 --> Output Class Initialized
INFO - 2022-07-04 03:50:08 --> Security Class Initialized
DEBUG - 2022-07-04 03:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:50:08 --> Input Class Initialized
INFO - 2022-07-04 03:50:08 --> Language Class Initialized
INFO - 2022-07-04 03:50:08 --> Language Class Initialized
INFO - 2022-07-04 03:50:08 --> Config Class Initialized
INFO - 2022-07-04 03:50:08 --> Loader Class Initialized
INFO - 2022-07-04 03:50:08 --> Helper loaded: url_helper
INFO - 2022-07-04 03:50:08 --> Helper loaded: file_helper
INFO - 2022-07-04 03:50:08 --> Helper loaded: form_helper
INFO - 2022-07-04 03:50:08 --> Helper loaded: my_helper
INFO - 2022-07-04 03:50:08 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:50:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:50:08 --> Controller Class Initialized
DEBUG - 2022-07-04 03:50:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-07-04 03:50:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 03:50:08 --> Final output sent to browser
DEBUG - 2022-07-04 03:50:08 --> Total execution time: 0.5750
INFO - 2022-07-04 03:50:10 --> Config Class Initialized
INFO - 2022-07-04 03:50:10 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:50:10 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:50:10 --> Utf8 Class Initialized
INFO - 2022-07-04 03:50:10 --> URI Class Initialized
INFO - 2022-07-04 03:50:10 --> Router Class Initialized
INFO - 2022-07-04 03:50:10 --> Output Class Initialized
INFO - 2022-07-04 03:50:10 --> Security Class Initialized
DEBUG - 2022-07-04 03:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:50:10 --> Input Class Initialized
INFO - 2022-07-04 03:50:10 --> Language Class Initialized
INFO - 2022-07-04 03:50:10 --> Language Class Initialized
INFO - 2022-07-04 03:50:10 --> Config Class Initialized
INFO - 2022-07-04 03:50:10 --> Loader Class Initialized
INFO - 2022-07-04 03:50:10 --> Helper loaded: url_helper
INFO - 2022-07-04 03:50:10 --> Helper loaded: file_helper
INFO - 2022-07-04 03:50:10 --> Helper loaded: form_helper
INFO - 2022-07-04 03:50:10 --> Helper loaded: my_helper
INFO - 2022-07-04 03:50:10 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:50:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:50:10 --> Controller Class Initialized
DEBUG - 2022-07-04 03:50:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-07-04 03:50:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 03:50:10 --> Final output sent to browser
DEBUG - 2022-07-04 03:50:10 --> Total execution time: 0.0691
INFO - 2022-07-04 03:50:14 --> Config Class Initialized
INFO - 2022-07-04 03:50:14 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:50:14 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:50:14 --> Utf8 Class Initialized
INFO - 2022-07-04 03:50:14 --> URI Class Initialized
INFO - 2022-07-04 03:50:14 --> Router Class Initialized
INFO - 2022-07-04 03:50:14 --> Output Class Initialized
INFO - 2022-07-04 03:50:14 --> Security Class Initialized
DEBUG - 2022-07-04 03:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:50:14 --> Input Class Initialized
INFO - 2022-07-04 03:50:14 --> Language Class Initialized
INFO - 2022-07-04 03:50:14 --> Language Class Initialized
INFO - 2022-07-04 03:50:14 --> Config Class Initialized
INFO - 2022-07-04 03:50:14 --> Loader Class Initialized
INFO - 2022-07-04 03:50:14 --> Helper loaded: url_helper
INFO - 2022-07-04 03:50:14 --> Helper loaded: file_helper
INFO - 2022-07-04 03:50:14 --> Helper loaded: form_helper
INFO - 2022-07-04 03:50:14 --> Helper loaded: my_helper
INFO - 2022-07-04 03:50:14 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:50:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:50:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:50:14 --> Controller Class Initialized
DEBUG - 2022-07-04 03:50:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-07-04 03:50:14 --> Final output sent to browser
DEBUG - 2022-07-04 03:50:14 --> Total execution time: 0.2943
INFO - 2022-07-04 03:50:38 --> Config Class Initialized
INFO - 2022-07-04 03:50:38 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:50:38 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:50:38 --> Utf8 Class Initialized
INFO - 2022-07-04 03:50:38 --> URI Class Initialized
INFO - 2022-07-04 03:50:38 --> Router Class Initialized
INFO - 2022-07-04 03:50:38 --> Output Class Initialized
INFO - 2022-07-04 03:50:38 --> Security Class Initialized
DEBUG - 2022-07-04 03:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:50:38 --> Input Class Initialized
INFO - 2022-07-04 03:50:38 --> Language Class Initialized
INFO - 2022-07-04 03:50:38 --> Language Class Initialized
INFO - 2022-07-04 03:50:38 --> Config Class Initialized
INFO - 2022-07-04 03:50:38 --> Loader Class Initialized
INFO - 2022-07-04 03:50:38 --> Helper loaded: url_helper
INFO - 2022-07-04 03:50:38 --> Helper loaded: file_helper
INFO - 2022-07-04 03:50:38 --> Helper loaded: form_helper
INFO - 2022-07-04 03:50:38 --> Helper loaded: my_helper
INFO - 2022-07-04 03:50:38 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:50:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:50:38 --> Controller Class Initialized
INFO - 2022-07-04 03:50:38 --> Helper loaded: cookie_helper
INFO - 2022-07-04 03:50:38 --> Config Class Initialized
INFO - 2022-07-04 03:50:38 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:50:38 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:50:38 --> Utf8 Class Initialized
INFO - 2022-07-04 03:50:38 --> URI Class Initialized
INFO - 2022-07-04 03:50:38 --> Router Class Initialized
INFO - 2022-07-04 03:50:38 --> Output Class Initialized
INFO - 2022-07-04 03:50:38 --> Security Class Initialized
DEBUG - 2022-07-04 03:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:50:38 --> Input Class Initialized
INFO - 2022-07-04 03:50:38 --> Language Class Initialized
INFO - 2022-07-04 03:50:38 --> Language Class Initialized
INFO - 2022-07-04 03:50:38 --> Config Class Initialized
INFO - 2022-07-04 03:50:38 --> Loader Class Initialized
INFO - 2022-07-04 03:50:38 --> Helper loaded: url_helper
INFO - 2022-07-04 03:50:38 --> Helper loaded: file_helper
INFO - 2022-07-04 03:50:38 --> Helper loaded: form_helper
INFO - 2022-07-04 03:50:38 --> Helper loaded: my_helper
INFO - 2022-07-04 03:50:38 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:50:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:50:38 --> Controller Class Initialized
DEBUG - 2022-07-04 03:50:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-07-04 03:50:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 03:50:38 --> Final output sent to browser
DEBUG - 2022-07-04 03:50:38 --> Total execution time: 0.0428
INFO - 2022-07-04 03:50:41 --> Config Class Initialized
INFO - 2022-07-04 03:50:41 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:50:41 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:50:41 --> Utf8 Class Initialized
INFO - 2022-07-04 03:50:41 --> URI Class Initialized
INFO - 2022-07-04 03:50:41 --> Router Class Initialized
INFO - 2022-07-04 03:50:41 --> Output Class Initialized
INFO - 2022-07-04 03:50:41 --> Security Class Initialized
DEBUG - 2022-07-04 03:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:50:41 --> Input Class Initialized
INFO - 2022-07-04 03:50:41 --> Language Class Initialized
INFO - 2022-07-04 03:50:41 --> Language Class Initialized
INFO - 2022-07-04 03:50:41 --> Config Class Initialized
INFO - 2022-07-04 03:50:41 --> Loader Class Initialized
INFO - 2022-07-04 03:50:41 --> Helper loaded: url_helper
INFO - 2022-07-04 03:50:41 --> Helper loaded: file_helper
INFO - 2022-07-04 03:50:41 --> Helper loaded: form_helper
INFO - 2022-07-04 03:50:41 --> Helper loaded: my_helper
INFO - 2022-07-04 03:50:41 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:50:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:50:41 --> Controller Class Initialized
INFO - 2022-07-04 03:50:41 --> Helper loaded: cookie_helper
INFO - 2022-07-04 03:50:41 --> Final output sent to browser
DEBUG - 2022-07-04 03:50:41 --> Total execution time: 0.0483
INFO - 2022-07-04 03:50:41 --> Config Class Initialized
INFO - 2022-07-04 03:50:41 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:50:41 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:50:41 --> Utf8 Class Initialized
INFO - 2022-07-04 03:50:41 --> URI Class Initialized
INFO - 2022-07-04 03:50:41 --> Router Class Initialized
INFO - 2022-07-04 03:50:41 --> Output Class Initialized
INFO - 2022-07-04 03:50:41 --> Security Class Initialized
DEBUG - 2022-07-04 03:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:50:41 --> Input Class Initialized
INFO - 2022-07-04 03:50:41 --> Language Class Initialized
INFO - 2022-07-04 03:50:41 --> Language Class Initialized
INFO - 2022-07-04 03:50:41 --> Config Class Initialized
INFO - 2022-07-04 03:50:41 --> Loader Class Initialized
INFO - 2022-07-04 03:50:42 --> Helper loaded: url_helper
INFO - 2022-07-04 03:50:42 --> Helper loaded: file_helper
INFO - 2022-07-04 03:50:42 --> Helper loaded: form_helper
INFO - 2022-07-04 03:50:42 --> Helper loaded: my_helper
INFO - 2022-07-04 03:50:42 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:50:42 --> Controller Class Initialized
DEBUG - 2022-07-04 03:50:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-07-04 03:50:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 03:50:42 --> Final output sent to browser
DEBUG - 2022-07-04 03:50:42 --> Total execution time: 0.5653
INFO - 2022-07-04 03:50:43 --> Config Class Initialized
INFO - 2022-07-04 03:50:43 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:50:43 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:50:43 --> Utf8 Class Initialized
INFO - 2022-07-04 03:50:43 --> URI Class Initialized
INFO - 2022-07-04 03:50:43 --> Router Class Initialized
INFO - 2022-07-04 03:50:43 --> Output Class Initialized
INFO - 2022-07-04 03:50:43 --> Security Class Initialized
DEBUG - 2022-07-04 03:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:50:43 --> Input Class Initialized
INFO - 2022-07-04 03:50:43 --> Language Class Initialized
INFO - 2022-07-04 03:50:43 --> Language Class Initialized
INFO - 2022-07-04 03:50:43 --> Config Class Initialized
INFO - 2022-07-04 03:50:43 --> Loader Class Initialized
INFO - 2022-07-04 03:50:43 --> Helper loaded: url_helper
INFO - 2022-07-04 03:50:43 --> Helper loaded: file_helper
INFO - 2022-07-04 03:50:43 --> Helper loaded: form_helper
INFO - 2022-07-04 03:50:43 --> Helper loaded: my_helper
INFO - 2022-07-04 03:50:43 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:50:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:50:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:50:43 --> Controller Class Initialized
DEBUG - 2022-07-04 03:50:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-07-04 03:50:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 03:50:43 --> Final output sent to browser
DEBUG - 2022-07-04 03:50:43 --> Total execution time: 0.0574
INFO - 2022-07-04 03:50:46 --> Config Class Initialized
INFO - 2022-07-04 03:50:46 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:50:46 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:50:46 --> Utf8 Class Initialized
INFO - 2022-07-04 03:50:46 --> URI Class Initialized
INFO - 2022-07-04 03:50:46 --> Router Class Initialized
INFO - 2022-07-04 03:50:46 --> Output Class Initialized
INFO - 2022-07-04 03:50:46 --> Security Class Initialized
DEBUG - 2022-07-04 03:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:50:46 --> Input Class Initialized
INFO - 2022-07-04 03:50:46 --> Language Class Initialized
INFO - 2022-07-04 03:50:46 --> Language Class Initialized
INFO - 2022-07-04 03:50:46 --> Config Class Initialized
INFO - 2022-07-04 03:50:46 --> Loader Class Initialized
INFO - 2022-07-04 03:50:46 --> Helper loaded: url_helper
INFO - 2022-07-04 03:50:46 --> Helper loaded: file_helper
INFO - 2022-07-04 03:50:46 --> Helper loaded: form_helper
INFO - 2022-07-04 03:50:46 --> Helper loaded: my_helper
INFO - 2022-07-04 03:50:46 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:50:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:50:46 --> Controller Class Initialized
DEBUG - 2022-07-04 03:50:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2022-07-04 03:50:47 --> Final output sent to browser
DEBUG - 2022-07-04 03:50:47 --> Total execution time: 0.2830
INFO - 2022-07-04 03:51:08 --> Config Class Initialized
INFO - 2022-07-04 03:51:08 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:51:08 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:51:08 --> Utf8 Class Initialized
INFO - 2022-07-04 03:51:08 --> URI Class Initialized
INFO - 2022-07-04 03:51:08 --> Router Class Initialized
INFO - 2022-07-04 03:51:08 --> Output Class Initialized
INFO - 2022-07-04 03:51:08 --> Security Class Initialized
DEBUG - 2022-07-04 03:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:51:08 --> Input Class Initialized
INFO - 2022-07-04 03:51:08 --> Language Class Initialized
INFO - 2022-07-04 03:51:08 --> Language Class Initialized
INFO - 2022-07-04 03:51:08 --> Config Class Initialized
INFO - 2022-07-04 03:51:08 --> Loader Class Initialized
INFO - 2022-07-04 03:51:08 --> Helper loaded: url_helper
INFO - 2022-07-04 03:51:08 --> Helper loaded: file_helper
INFO - 2022-07-04 03:51:08 --> Helper loaded: form_helper
INFO - 2022-07-04 03:51:08 --> Helper loaded: my_helper
INFO - 2022-07-04 03:51:08 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:51:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:51:08 --> Controller Class Initialized
INFO - 2022-07-04 03:51:08 --> Helper loaded: cookie_helper
INFO - 2022-07-04 03:51:08 --> Config Class Initialized
INFO - 2022-07-04 03:51:08 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:51:08 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:51:08 --> Utf8 Class Initialized
INFO - 2022-07-04 03:51:08 --> URI Class Initialized
INFO - 2022-07-04 03:51:08 --> Router Class Initialized
INFO - 2022-07-04 03:51:08 --> Output Class Initialized
INFO - 2022-07-04 03:51:08 --> Security Class Initialized
DEBUG - 2022-07-04 03:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:51:08 --> Input Class Initialized
INFO - 2022-07-04 03:51:08 --> Language Class Initialized
INFO - 2022-07-04 03:51:08 --> Language Class Initialized
INFO - 2022-07-04 03:51:08 --> Config Class Initialized
INFO - 2022-07-04 03:51:08 --> Loader Class Initialized
INFO - 2022-07-04 03:51:08 --> Helper loaded: url_helper
INFO - 2022-07-04 03:51:08 --> Helper loaded: file_helper
INFO - 2022-07-04 03:51:08 --> Helper loaded: form_helper
INFO - 2022-07-04 03:51:08 --> Helper loaded: my_helper
INFO - 2022-07-04 03:51:08 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:51:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:51:08 --> Controller Class Initialized
DEBUG - 2022-07-04 03:51:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-07-04 03:51:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 03:51:08 --> Final output sent to browser
DEBUG - 2022-07-04 03:51:08 --> Total execution time: 0.0414
INFO - 2022-07-04 03:58:05 --> Config Class Initialized
INFO - 2022-07-04 03:58:05 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:58:05 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:58:05 --> Utf8 Class Initialized
INFO - 2022-07-04 03:58:05 --> URI Class Initialized
INFO - 2022-07-04 03:58:05 --> Router Class Initialized
INFO - 2022-07-04 03:58:05 --> Output Class Initialized
INFO - 2022-07-04 03:58:05 --> Security Class Initialized
DEBUG - 2022-07-04 03:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:58:05 --> Input Class Initialized
INFO - 2022-07-04 03:58:05 --> Language Class Initialized
INFO - 2022-07-04 03:58:05 --> Language Class Initialized
INFO - 2022-07-04 03:58:05 --> Config Class Initialized
INFO - 2022-07-04 03:58:05 --> Loader Class Initialized
INFO - 2022-07-04 03:58:05 --> Helper loaded: url_helper
INFO - 2022-07-04 03:58:05 --> Helper loaded: file_helper
INFO - 2022-07-04 03:58:05 --> Helper loaded: form_helper
INFO - 2022-07-04 03:58:05 --> Helper loaded: my_helper
INFO - 2022-07-04 03:58:05 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:58:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:58:05 --> Controller Class Initialized
INFO - 2022-07-04 03:58:05 --> Helper loaded: cookie_helper
INFO - 2022-07-04 03:58:05 --> Final output sent to browser
DEBUG - 2022-07-04 03:58:05 --> Total execution time: 0.0504
INFO - 2022-07-04 03:58:05 --> Config Class Initialized
INFO - 2022-07-04 03:58:05 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:58:05 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:58:05 --> Utf8 Class Initialized
INFO - 2022-07-04 03:58:05 --> URI Class Initialized
INFO - 2022-07-04 03:58:05 --> Router Class Initialized
INFO - 2022-07-04 03:58:05 --> Output Class Initialized
INFO - 2022-07-04 03:58:05 --> Security Class Initialized
DEBUG - 2022-07-04 03:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:58:05 --> Input Class Initialized
INFO - 2022-07-04 03:58:05 --> Language Class Initialized
INFO - 2022-07-04 03:58:05 --> Language Class Initialized
INFO - 2022-07-04 03:58:05 --> Config Class Initialized
INFO - 2022-07-04 03:58:05 --> Loader Class Initialized
INFO - 2022-07-04 03:58:05 --> Helper loaded: url_helper
INFO - 2022-07-04 03:58:05 --> Helper loaded: file_helper
INFO - 2022-07-04 03:58:05 --> Helper loaded: form_helper
INFO - 2022-07-04 03:58:05 --> Helper loaded: my_helper
INFO - 2022-07-04 03:58:05 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:58:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:58:05 --> Controller Class Initialized
DEBUG - 2022-07-04 03:58:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-07-04 03:58:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 03:58:06 --> Final output sent to browser
DEBUG - 2022-07-04 03:58:06 --> Total execution time: 0.5784
INFO - 2022-07-04 03:58:07 --> Config Class Initialized
INFO - 2022-07-04 03:58:07 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:58:07 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:58:07 --> Utf8 Class Initialized
INFO - 2022-07-04 03:58:07 --> URI Class Initialized
INFO - 2022-07-04 03:58:07 --> Router Class Initialized
INFO - 2022-07-04 03:58:07 --> Output Class Initialized
INFO - 2022-07-04 03:58:07 --> Security Class Initialized
DEBUG - 2022-07-04 03:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:58:07 --> Input Class Initialized
INFO - 2022-07-04 03:58:07 --> Language Class Initialized
INFO - 2022-07-04 03:58:07 --> Language Class Initialized
INFO - 2022-07-04 03:58:07 --> Config Class Initialized
INFO - 2022-07-04 03:58:07 --> Loader Class Initialized
INFO - 2022-07-04 03:58:07 --> Helper loaded: url_helper
INFO - 2022-07-04 03:58:07 --> Helper loaded: file_helper
INFO - 2022-07-04 03:58:07 --> Helper loaded: form_helper
INFO - 2022-07-04 03:58:07 --> Helper loaded: my_helper
INFO - 2022-07-04 03:58:07 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:58:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:58:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:58:07 --> Controller Class Initialized
DEBUG - 2022-07-04 03:58:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-07-04 03:58:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 03:58:07 --> Final output sent to browser
DEBUG - 2022-07-04 03:58:07 --> Total execution time: 0.0642
INFO - 2022-07-04 03:58:47 --> Config Class Initialized
INFO - 2022-07-04 03:58:47 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:58:47 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:58:47 --> Utf8 Class Initialized
INFO - 2022-07-04 03:58:47 --> URI Class Initialized
INFO - 2022-07-04 03:58:47 --> Router Class Initialized
INFO - 2022-07-04 03:58:47 --> Output Class Initialized
INFO - 2022-07-04 03:58:47 --> Security Class Initialized
DEBUG - 2022-07-04 03:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:58:47 --> Input Class Initialized
INFO - 2022-07-04 03:58:47 --> Language Class Initialized
INFO - 2022-07-04 03:58:47 --> Language Class Initialized
INFO - 2022-07-04 03:58:47 --> Config Class Initialized
INFO - 2022-07-04 03:58:47 --> Loader Class Initialized
INFO - 2022-07-04 03:58:47 --> Helper loaded: url_helper
INFO - 2022-07-04 03:58:47 --> Helper loaded: file_helper
INFO - 2022-07-04 03:58:47 --> Helper loaded: form_helper
INFO - 2022-07-04 03:58:47 --> Helper loaded: my_helper
INFO - 2022-07-04 03:58:47 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:58:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:58:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:58:47 --> Controller Class Initialized
DEBUG - 2022-07-04 03:58:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-07-04 03:58:47 --> Final output sent to browser
DEBUG - 2022-07-04 03:58:47 --> Total execution time: 0.2194
INFO - 2022-07-04 03:59:38 --> Config Class Initialized
INFO - 2022-07-04 03:59:38 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:59:38 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:59:38 --> Utf8 Class Initialized
INFO - 2022-07-04 03:59:38 --> URI Class Initialized
INFO - 2022-07-04 03:59:38 --> Router Class Initialized
INFO - 2022-07-04 03:59:38 --> Output Class Initialized
INFO - 2022-07-04 03:59:38 --> Security Class Initialized
DEBUG - 2022-07-04 03:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:59:38 --> Input Class Initialized
INFO - 2022-07-04 03:59:38 --> Language Class Initialized
INFO - 2022-07-04 03:59:38 --> Language Class Initialized
INFO - 2022-07-04 03:59:38 --> Config Class Initialized
INFO - 2022-07-04 03:59:38 --> Loader Class Initialized
INFO - 2022-07-04 03:59:38 --> Helper loaded: url_helper
INFO - 2022-07-04 03:59:38 --> Helper loaded: file_helper
INFO - 2022-07-04 03:59:38 --> Helper loaded: form_helper
INFO - 2022-07-04 03:59:38 --> Helper loaded: my_helper
INFO - 2022-07-04 03:59:38 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:59:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:59:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:59:38 --> Controller Class Initialized
INFO - 2022-07-04 03:59:38 --> Helper loaded: cookie_helper
INFO - 2022-07-04 03:59:38 --> Config Class Initialized
INFO - 2022-07-04 03:59:38 --> Hooks Class Initialized
DEBUG - 2022-07-04 03:59:38 --> UTF-8 Support Enabled
INFO - 2022-07-04 03:59:38 --> Utf8 Class Initialized
INFO - 2022-07-04 03:59:38 --> URI Class Initialized
INFO - 2022-07-04 03:59:38 --> Router Class Initialized
INFO - 2022-07-04 03:59:38 --> Output Class Initialized
INFO - 2022-07-04 03:59:38 --> Security Class Initialized
DEBUG - 2022-07-04 03:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 03:59:38 --> Input Class Initialized
INFO - 2022-07-04 03:59:38 --> Language Class Initialized
INFO - 2022-07-04 03:59:38 --> Language Class Initialized
INFO - 2022-07-04 03:59:38 --> Config Class Initialized
INFO - 2022-07-04 03:59:38 --> Loader Class Initialized
INFO - 2022-07-04 03:59:38 --> Helper loaded: url_helper
INFO - 2022-07-04 03:59:38 --> Helper loaded: file_helper
INFO - 2022-07-04 03:59:38 --> Helper loaded: form_helper
INFO - 2022-07-04 03:59:38 --> Helper loaded: my_helper
INFO - 2022-07-04 03:59:38 --> Database Driver Class Initialized
DEBUG - 2022-07-04 03:59:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 03:59:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 03:59:38 --> Controller Class Initialized
DEBUG - 2022-07-04 03:59:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-07-04 03:59:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 03:59:38 --> Final output sent to browser
DEBUG - 2022-07-04 03:59:38 --> Total execution time: 0.0659
INFO - 2022-07-04 06:34:37 --> Config Class Initialized
INFO - 2022-07-04 06:34:37 --> Hooks Class Initialized
DEBUG - 2022-07-04 06:34:37 --> UTF-8 Support Enabled
INFO - 2022-07-04 06:34:37 --> Utf8 Class Initialized
INFO - 2022-07-04 06:34:37 --> URI Class Initialized
INFO - 2022-07-04 06:34:37 --> Router Class Initialized
INFO - 2022-07-04 06:34:37 --> Output Class Initialized
INFO - 2022-07-04 06:34:37 --> Security Class Initialized
DEBUG - 2022-07-04 06:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 06:34:37 --> Input Class Initialized
INFO - 2022-07-04 06:34:37 --> Language Class Initialized
INFO - 2022-07-04 06:34:37 --> Language Class Initialized
INFO - 2022-07-04 06:34:37 --> Config Class Initialized
INFO - 2022-07-04 06:34:37 --> Loader Class Initialized
INFO - 2022-07-04 06:34:37 --> Helper loaded: url_helper
INFO - 2022-07-04 06:34:37 --> Helper loaded: file_helper
INFO - 2022-07-04 06:34:37 --> Helper loaded: form_helper
INFO - 2022-07-04 06:34:37 --> Helper loaded: my_helper
INFO - 2022-07-04 06:34:37 --> Database Driver Class Initialized
DEBUG - 2022-07-04 06:34:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 06:34:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 06:34:37 --> Controller Class Initialized
INFO - 2022-07-04 06:34:37 --> Helper loaded: cookie_helper
INFO - 2022-07-04 06:34:37 --> Final output sent to browser
DEBUG - 2022-07-04 06:34:37 --> Total execution time: 0.0484
INFO - 2022-07-04 06:34:41 --> Config Class Initialized
INFO - 2022-07-04 06:34:41 --> Hooks Class Initialized
DEBUG - 2022-07-04 06:34:41 --> UTF-8 Support Enabled
INFO - 2022-07-04 06:34:41 --> Utf8 Class Initialized
INFO - 2022-07-04 06:34:41 --> URI Class Initialized
INFO - 2022-07-04 06:34:41 --> Router Class Initialized
INFO - 2022-07-04 06:34:41 --> Output Class Initialized
INFO - 2022-07-04 06:34:41 --> Security Class Initialized
DEBUG - 2022-07-04 06:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 06:34:41 --> Input Class Initialized
INFO - 2022-07-04 06:34:41 --> Language Class Initialized
INFO - 2022-07-04 06:34:41 --> Language Class Initialized
INFO - 2022-07-04 06:34:41 --> Config Class Initialized
INFO - 2022-07-04 06:34:41 --> Loader Class Initialized
INFO - 2022-07-04 06:34:41 --> Helper loaded: url_helper
INFO - 2022-07-04 06:34:41 --> Helper loaded: file_helper
INFO - 2022-07-04 06:34:41 --> Helper loaded: form_helper
INFO - 2022-07-04 06:34:41 --> Helper loaded: my_helper
INFO - 2022-07-04 06:34:41 --> Database Driver Class Initialized
DEBUG - 2022-07-04 06:34:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 06:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 06:34:41 --> Controller Class Initialized
DEBUG - 2022-07-04 06:34:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-07-04 06:34:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 06:34:42 --> Final output sent to browser
DEBUG - 2022-07-04 06:34:42 --> Total execution time: 0.5847
INFO - 2022-07-04 06:36:57 --> Config Class Initialized
INFO - 2022-07-04 06:36:57 --> Hooks Class Initialized
DEBUG - 2022-07-04 06:36:57 --> UTF-8 Support Enabled
INFO - 2022-07-04 06:36:57 --> Utf8 Class Initialized
INFO - 2022-07-04 06:36:57 --> URI Class Initialized
INFO - 2022-07-04 06:36:57 --> Router Class Initialized
INFO - 2022-07-04 06:36:57 --> Output Class Initialized
INFO - 2022-07-04 06:36:57 --> Security Class Initialized
DEBUG - 2022-07-04 06:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 06:36:57 --> Input Class Initialized
INFO - 2022-07-04 06:36:57 --> Language Class Initialized
INFO - 2022-07-04 06:36:57 --> Language Class Initialized
INFO - 2022-07-04 06:36:57 --> Config Class Initialized
INFO - 2022-07-04 06:36:57 --> Loader Class Initialized
INFO - 2022-07-04 06:36:57 --> Helper loaded: url_helper
INFO - 2022-07-04 06:36:57 --> Helper loaded: file_helper
INFO - 2022-07-04 06:36:57 --> Helper loaded: form_helper
INFO - 2022-07-04 06:36:57 --> Helper loaded: my_helper
INFO - 2022-07-04 06:36:57 --> Database Driver Class Initialized
DEBUG - 2022-07-04 06:36:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 06:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 06:36:57 --> Controller Class Initialized
DEBUG - 2022-07-04 06:36:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2022-07-04 06:36:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 06:36:57 --> Final output sent to browser
DEBUG - 2022-07-04 06:36:57 --> Total execution time: 0.0978
INFO - 2022-07-04 06:37:11 --> Config Class Initialized
INFO - 2022-07-04 06:37:11 --> Hooks Class Initialized
DEBUG - 2022-07-04 06:37:11 --> UTF-8 Support Enabled
INFO - 2022-07-04 06:37:11 --> Utf8 Class Initialized
INFO - 2022-07-04 06:37:11 --> URI Class Initialized
INFO - 2022-07-04 06:37:11 --> Router Class Initialized
INFO - 2022-07-04 06:37:11 --> Output Class Initialized
INFO - 2022-07-04 06:37:11 --> Security Class Initialized
DEBUG - 2022-07-04 06:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 06:37:11 --> Input Class Initialized
INFO - 2022-07-04 06:37:11 --> Language Class Initialized
INFO - 2022-07-04 06:37:11 --> Language Class Initialized
INFO - 2022-07-04 06:37:11 --> Config Class Initialized
INFO - 2022-07-04 06:37:11 --> Loader Class Initialized
INFO - 2022-07-04 06:37:11 --> Helper loaded: url_helper
INFO - 2022-07-04 06:37:11 --> Helper loaded: file_helper
INFO - 2022-07-04 06:37:11 --> Helper loaded: form_helper
INFO - 2022-07-04 06:37:11 --> Helper loaded: my_helper
INFO - 2022-07-04 06:37:11 --> Database Driver Class Initialized
DEBUG - 2022-07-04 06:37:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 06:37:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 06:37:11 --> Controller Class Initialized
INFO - 2022-07-04 06:37:11 --> Final output sent to browser
DEBUG - 2022-07-04 06:37:11 --> Total execution time: 0.2830
INFO - 2022-07-04 06:37:13 --> Config Class Initialized
INFO - 2022-07-04 06:37:13 --> Hooks Class Initialized
DEBUG - 2022-07-04 06:37:13 --> UTF-8 Support Enabled
INFO - 2022-07-04 06:37:13 --> Utf8 Class Initialized
INFO - 2022-07-04 06:37:13 --> URI Class Initialized
INFO - 2022-07-04 06:37:13 --> Router Class Initialized
INFO - 2022-07-04 06:37:13 --> Output Class Initialized
INFO - 2022-07-04 06:37:13 --> Security Class Initialized
DEBUG - 2022-07-04 06:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 06:37:13 --> Input Class Initialized
INFO - 2022-07-04 06:37:13 --> Language Class Initialized
INFO - 2022-07-04 06:37:13 --> Language Class Initialized
INFO - 2022-07-04 06:37:13 --> Config Class Initialized
INFO - 2022-07-04 06:37:13 --> Loader Class Initialized
INFO - 2022-07-04 06:37:13 --> Helper loaded: url_helper
INFO - 2022-07-04 06:37:13 --> Helper loaded: file_helper
INFO - 2022-07-04 06:37:13 --> Helper loaded: form_helper
INFO - 2022-07-04 06:37:13 --> Helper loaded: my_helper
INFO - 2022-07-04 06:37:13 --> Database Driver Class Initialized
DEBUG - 2022-07-04 06:37:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 06:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 06:37:13 --> Controller Class Initialized
DEBUG - 2022-07-04 06:37:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2022-07-04 06:37:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 06:37:13 --> Final output sent to browser
DEBUG - 2022-07-04 06:37:13 --> Total execution time: 0.0770
INFO - 2022-07-04 07:01:46 --> Config Class Initialized
INFO - 2022-07-04 07:01:46 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:01:46 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:01:46 --> Utf8 Class Initialized
INFO - 2022-07-04 07:01:46 --> URI Class Initialized
INFO - 2022-07-04 07:01:46 --> Router Class Initialized
INFO - 2022-07-04 07:01:46 --> Output Class Initialized
INFO - 2022-07-04 07:01:46 --> Security Class Initialized
DEBUG - 2022-07-04 07:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:01:46 --> Input Class Initialized
INFO - 2022-07-04 07:01:46 --> Language Class Initialized
INFO - 2022-07-04 07:01:46 --> Language Class Initialized
INFO - 2022-07-04 07:01:46 --> Config Class Initialized
INFO - 2022-07-04 07:01:46 --> Loader Class Initialized
INFO - 2022-07-04 07:01:46 --> Helper loaded: url_helper
INFO - 2022-07-04 07:01:46 --> Helper loaded: file_helper
INFO - 2022-07-04 07:01:46 --> Helper loaded: form_helper
INFO - 2022-07-04 07:01:46 --> Helper loaded: my_helper
INFO - 2022-07-04 07:01:46 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:01:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:01:46 --> Controller Class Initialized
INFO - 2022-07-04 07:01:47 --> Final output sent to browser
DEBUG - 2022-07-04 07:01:47 --> Total execution time: 0.1957
INFO - 2022-07-04 07:01:53 --> Config Class Initialized
INFO - 2022-07-04 07:01:53 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:01:53 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:01:53 --> Utf8 Class Initialized
INFO - 2022-07-04 07:01:53 --> URI Class Initialized
INFO - 2022-07-04 07:01:53 --> Router Class Initialized
INFO - 2022-07-04 07:01:53 --> Output Class Initialized
INFO - 2022-07-04 07:01:53 --> Security Class Initialized
DEBUG - 2022-07-04 07:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:01:53 --> Input Class Initialized
INFO - 2022-07-04 07:01:53 --> Language Class Initialized
INFO - 2022-07-04 07:01:53 --> Language Class Initialized
INFO - 2022-07-04 07:01:53 --> Config Class Initialized
INFO - 2022-07-04 07:01:53 --> Loader Class Initialized
INFO - 2022-07-04 07:01:53 --> Helper loaded: url_helper
INFO - 2022-07-04 07:01:53 --> Helper loaded: file_helper
INFO - 2022-07-04 07:01:53 --> Helper loaded: form_helper
INFO - 2022-07-04 07:01:53 --> Helper loaded: my_helper
INFO - 2022-07-04 07:01:53 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:01:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:01:53 --> Controller Class Initialized
INFO - 2022-07-04 07:01:53 --> Final output sent to browser
DEBUG - 2022-07-04 07:01:53 --> Total execution time: 0.1759
INFO - 2022-07-04 07:01:54 --> Config Class Initialized
INFO - 2022-07-04 07:01:54 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:01:54 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:01:54 --> Utf8 Class Initialized
INFO - 2022-07-04 07:01:54 --> URI Class Initialized
INFO - 2022-07-04 07:01:54 --> Router Class Initialized
INFO - 2022-07-04 07:01:54 --> Output Class Initialized
INFO - 2022-07-04 07:01:54 --> Security Class Initialized
DEBUG - 2022-07-04 07:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:01:54 --> Input Class Initialized
INFO - 2022-07-04 07:01:54 --> Language Class Initialized
INFO - 2022-07-04 07:01:54 --> Language Class Initialized
INFO - 2022-07-04 07:01:54 --> Config Class Initialized
INFO - 2022-07-04 07:01:54 --> Loader Class Initialized
INFO - 2022-07-04 07:01:54 --> Helper loaded: url_helper
INFO - 2022-07-04 07:01:54 --> Helper loaded: file_helper
INFO - 2022-07-04 07:01:54 --> Helper loaded: form_helper
INFO - 2022-07-04 07:01:54 --> Helper loaded: my_helper
INFO - 2022-07-04 07:01:54 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:01:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:01:54 --> Controller Class Initialized
DEBUG - 2022-07-04 07:01:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2022-07-04 07:01:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 07:01:54 --> Final output sent to browser
DEBUG - 2022-07-04 07:01:54 --> Total execution time: 0.0641
INFO - 2022-07-04 07:02:20 --> Config Class Initialized
INFO - 2022-07-04 07:02:20 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:02:20 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:02:20 --> Utf8 Class Initialized
INFO - 2022-07-04 07:02:20 --> URI Class Initialized
INFO - 2022-07-04 07:02:20 --> Router Class Initialized
INFO - 2022-07-04 07:02:20 --> Output Class Initialized
INFO - 2022-07-04 07:02:20 --> Security Class Initialized
DEBUG - 2022-07-04 07:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:02:20 --> Input Class Initialized
INFO - 2022-07-04 07:02:20 --> Language Class Initialized
INFO - 2022-07-04 07:02:20 --> Language Class Initialized
INFO - 2022-07-04 07:02:20 --> Config Class Initialized
INFO - 2022-07-04 07:02:20 --> Loader Class Initialized
INFO - 2022-07-04 07:02:20 --> Helper loaded: url_helper
INFO - 2022-07-04 07:02:20 --> Helper loaded: file_helper
INFO - 2022-07-04 07:02:20 --> Helper loaded: form_helper
INFO - 2022-07-04 07:02:20 --> Helper loaded: my_helper
INFO - 2022-07-04 07:02:20 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:02:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:02:20 --> Controller Class Initialized
DEBUG - 2022-07-04 07:02:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2022-07-04 07:02:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 07:02:20 --> Final output sent to browser
DEBUG - 2022-07-04 07:02:20 --> Total execution time: 0.0663
INFO - 2022-07-04 07:20:13 --> Config Class Initialized
INFO - 2022-07-04 07:20:13 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:20:13 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:20:13 --> Utf8 Class Initialized
INFO - 2022-07-04 07:20:13 --> URI Class Initialized
INFO - 2022-07-04 07:20:13 --> Router Class Initialized
INFO - 2022-07-04 07:20:13 --> Output Class Initialized
INFO - 2022-07-04 07:20:13 --> Security Class Initialized
DEBUG - 2022-07-04 07:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:20:13 --> Input Class Initialized
INFO - 2022-07-04 07:20:13 --> Language Class Initialized
INFO - 2022-07-04 07:20:13 --> Language Class Initialized
INFO - 2022-07-04 07:20:13 --> Config Class Initialized
INFO - 2022-07-04 07:20:13 --> Loader Class Initialized
INFO - 2022-07-04 07:20:13 --> Helper loaded: url_helper
INFO - 2022-07-04 07:20:13 --> Helper loaded: file_helper
INFO - 2022-07-04 07:20:13 --> Helper loaded: form_helper
INFO - 2022-07-04 07:20:13 --> Helper loaded: my_helper
INFO - 2022-07-04 07:20:13 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:20:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:20:13 --> Controller Class Initialized
DEBUG - 2022-07-04 07:20:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2022-07-04 07:20:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 07:20:13 --> Final output sent to browser
DEBUG - 2022-07-04 07:20:13 --> Total execution time: 0.0679
INFO - 2022-07-04 07:20:13 --> Config Class Initialized
INFO - 2022-07-04 07:20:13 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:20:13 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:20:13 --> Utf8 Class Initialized
INFO - 2022-07-04 07:20:13 --> URI Class Initialized
INFO - 2022-07-04 07:20:13 --> Router Class Initialized
INFO - 2022-07-04 07:20:13 --> Output Class Initialized
INFO - 2022-07-04 07:20:13 --> Security Class Initialized
DEBUG - 2022-07-04 07:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:20:13 --> Input Class Initialized
INFO - 2022-07-04 07:20:13 --> Language Class Initialized
INFO - 2022-07-04 07:20:13 --> Language Class Initialized
INFO - 2022-07-04 07:20:13 --> Config Class Initialized
INFO - 2022-07-04 07:20:13 --> Loader Class Initialized
INFO - 2022-07-04 07:20:13 --> Helper loaded: url_helper
INFO - 2022-07-04 07:20:13 --> Helper loaded: file_helper
INFO - 2022-07-04 07:20:13 --> Helper loaded: form_helper
INFO - 2022-07-04 07:20:13 --> Helper loaded: my_helper
INFO - 2022-07-04 07:20:13 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:20:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:20:13 --> Controller Class Initialized
INFO - 2022-07-04 07:20:16 --> Config Class Initialized
INFO - 2022-07-04 07:20:16 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:20:16 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:20:16 --> Utf8 Class Initialized
INFO - 2022-07-04 07:20:16 --> URI Class Initialized
INFO - 2022-07-04 07:20:16 --> Router Class Initialized
INFO - 2022-07-04 07:20:16 --> Output Class Initialized
INFO - 2022-07-04 07:20:16 --> Security Class Initialized
DEBUG - 2022-07-04 07:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:20:16 --> Input Class Initialized
INFO - 2022-07-04 07:20:16 --> Language Class Initialized
INFO - 2022-07-04 07:20:16 --> Language Class Initialized
INFO - 2022-07-04 07:20:16 --> Config Class Initialized
INFO - 2022-07-04 07:20:16 --> Loader Class Initialized
INFO - 2022-07-04 07:20:16 --> Helper loaded: url_helper
INFO - 2022-07-04 07:20:16 --> Helper loaded: file_helper
INFO - 2022-07-04 07:20:16 --> Helper loaded: form_helper
INFO - 2022-07-04 07:20:16 --> Helper loaded: my_helper
INFO - 2022-07-04 07:20:16 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:20:16 --> Controller Class Initialized
INFO - 2022-07-04 07:20:17 --> Config Class Initialized
INFO - 2022-07-04 07:20:17 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:20:17 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:20:17 --> Utf8 Class Initialized
INFO - 2022-07-04 07:20:17 --> URI Class Initialized
INFO - 2022-07-04 07:20:17 --> Router Class Initialized
INFO - 2022-07-04 07:20:17 --> Output Class Initialized
INFO - 2022-07-04 07:20:17 --> Security Class Initialized
DEBUG - 2022-07-04 07:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:20:17 --> Input Class Initialized
INFO - 2022-07-04 07:20:17 --> Language Class Initialized
INFO - 2022-07-04 07:20:17 --> Language Class Initialized
INFO - 2022-07-04 07:20:17 --> Config Class Initialized
INFO - 2022-07-04 07:20:17 --> Loader Class Initialized
INFO - 2022-07-04 07:20:17 --> Helper loaded: url_helper
INFO - 2022-07-04 07:20:17 --> Helper loaded: file_helper
INFO - 2022-07-04 07:20:17 --> Helper loaded: form_helper
INFO - 2022-07-04 07:20:17 --> Helper loaded: my_helper
INFO - 2022-07-04 07:20:17 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:20:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:20:17 --> Controller Class Initialized
INFO - 2022-07-04 07:20:17 --> Config Class Initialized
INFO - 2022-07-04 07:20:17 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:20:17 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:20:17 --> Utf8 Class Initialized
INFO - 2022-07-04 07:20:17 --> URI Class Initialized
INFO - 2022-07-04 07:20:17 --> Router Class Initialized
INFO - 2022-07-04 07:20:17 --> Output Class Initialized
INFO - 2022-07-04 07:20:17 --> Security Class Initialized
DEBUG - 2022-07-04 07:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:20:17 --> Input Class Initialized
INFO - 2022-07-04 07:20:17 --> Language Class Initialized
INFO - 2022-07-04 07:20:17 --> Language Class Initialized
INFO - 2022-07-04 07:20:17 --> Config Class Initialized
INFO - 2022-07-04 07:20:17 --> Loader Class Initialized
INFO - 2022-07-04 07:20:17 --> Helper loaded: url_helper
INFO - 2022-07-04 07:20:17 --> Helper loaded: file_helper
INFO - 2022-07-04 07:20:17 --> Helper loaded: form_helper
INFO - 2022-07-04 07:20:17 --> Helper loaded: my_helper
INFO - 2022-07-04 07:20:17 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:20:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:20:17 --> Controller Class Initialized
INFO - 2022-07-04 07:20:18 --> Config Class Initialized
INFO - 2022-07-04 07:20:18 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:20:18 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:20:19 --> Utf8 Class Initialized
INFO - 2022-07-04 07:20:19 --> URI Class Initialized
INFO - 2022-07-04 07:20:19 --> Router Class Initialized
INFO - 2022-07-04 07:20:19 --> Output Class Initialized
INFO - 2022-07-04 07:20:19 --> Security Class Initialized
DEBUG - 2022-07-04 07:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:20:19 --> Input Class Initialized
INFO - 2022-07-04 07:20:19 --> Language Class Initialized
INFO - 2022-07-04 07:20:19 --> Language Class Initialized
INFO - 2022-07-04 07:20:19 --> Config Class Initialized
INFO - 2022-07-04 07:20:19 --> Loader Class Initialized
INFO - 2022-07-04 07:20:19 --> Helper loaded: url_helper
INFO - 2022-07-04 07:20:19 --> Helper loaded: file_helper
INFO - 2022-07-04 07:20:19 --> Helper loaded: form_helper
INFO - 2022-07-04 07:20:19 --> Helper loaded: my_helper
INFO - 2022-07-04 07:20:19 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:20:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:20:19 --> Controller Class Initialized
INFO - 2022-07-04 07:20:19 --> Config Class Initialized
INFO - 2022-07-04 07:20:19 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:20:19 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:20:19 --> Utf8 Class Initialized
INFO - 2022-07-04 07:20:19 --> URI Class Initialized
INFO - 2022-07-04 07:20:19 --> Router Class Initialized
INFO - 2022-07-04 07:20:19 --> Output Class Initialized
INFO - 2022-07-04 07:20:19 --> Security Class Initialized
DEBUG - 2022-07-04 07:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:20:19 --> Input Class Initialized
INFO - 2022-07-04 07:20:19 --> Language Class Initialized
INFO - 2022-07-04 07:20:19 --> Language Class Initialized
INFO - 2022-07-04 07:20:19 --> Config Class Initialized
INFO - 2022-07-04 07:20:19 --> Loader Class Initialized
INFO - 2022-07-04 07:20:19 --> Helper loaded: url_helper
INFO - 2022-07-04 07:20:19 --> Helper loaded: file_helper
INFO - 2022-07-04 07:20:19 --> Helper loaded: form_helper
INFO - 2022-07-04 07:20:19 --> Helper loaded: my_helper
INFO - 2022-07-04 07:20:19 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:20:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:20:19 --> Controller Class Initialized
INFO - 2022-07-04 07:20:19 --> Config Class Initialized
INFO - 2022-07-04 07:20:19 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:20:19 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:20:19 --> Utf8 Class Initialized
INFO - 2022-07-04 07:20:19 --> URI Class Initialized
INFO - 2022-07-04 07:20:19 --> Router Class Initialized
INFO - 2022-07-04 07:20:19 --> Output Class Initialized
INFO - 2022-07-04 07:20:19 --> Security Class Initialized
DEBUG - 2022-07-04 07:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:20:19 --> Input Class Initialized
INFO - 2022-07-04 07:20:19 --> Language Class Initialized
INFO - 2022-07-04 07:20:19 --> Language Class Initialized
INFO - 2022-07-04 07:20:19 --> Config Class Initialized
INFO - 2022-07-04 07:20:19 --> Loader Class Initialized
INFO - 2022-07-04 07:20:19 --> Helper loaded: url_helper
INFO - 2022-07-04 07:20:19 --> Helper loaded: file_helper
INFO - 2022-07-04 07:20:19 --> Helper loaded: form_helper
INFO - 2022-07-04 07:20:19 --> Helper loaded: my_helper
INFO - 2022-07-04 07:20:19 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:20:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:20:19 --> Controller Class Initialized
INFO - 2022-07-04 07:20:20 --> Config Class Initialized
INFO - 2022-07-04 07:20:20 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:20:20 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:20:20 --> Utf8 Class Initialized
INFO - 2022-07-04 07:20:20 --> URI Class Initialized
INFO - 2022-07-04 07:20:20 --> Router Class Initialized
INFO - 2022-07-04 07:20:20 --> Output Class Initialized
INFO - 2022-07-04 07:20:20 --> Security Class Initialized
DEBUG - 2022-07-04 07:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:20:20 --> Input Class Initialized
INFO - 2022-07-04 07:20:20 --> Language Class Initialized
INFO - 2022-07-04 07:20:20 --> Language Class Initialized
INFO - 2022-07-04 07:20:20 --> Config Class Initialized
INFO - 2022-07-04 07:20:20 --> Loader Class Initialized
INFO - 2022-07-04 07:20:20 --> Helper loaded: url_helper
INFO - 2022-07-04 07:20:20 --> Helper loaded: file_helper
INFO - 2022-07-04 07:20:20 --> Helper loaded: form_helper
INFO - 2022-07-04 07:20:20 --> Helper loaded: my_helper
INFO - 2022-07-04 07:20:20 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:20:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:20:20 --> Controller Class Initialized
INFO - 2022-07-04 07:20:21 --> Config Class Initialized
INFO - 2022-07-04 07:20:21 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:20:21 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:20:21 --> Utf8 Class Initialized
INFO - 2022-07-04 07:20:21 --> URI Class Initialized
INFO - 2022-07-04 07:20:21 --> Router Class Initialized
INFO - 2022-07-04 07:20:21 --> Output Class Initialized
INFO - 2022-07-04 07:20:21 --> Security Class Initialized
DEBUG - 2022-07-04 07:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:20:21 --> Input Class Initialized
INFO - 2022-07-04 07:20:21 --> Language Class Initialized
INFO - 2022-07-04 07:20:21 --> Language Class Initialized
INFO - 2022-07-04 07:20:21 --> Config Class Initialized
INFO - 2022-07-04 07:20:21 --> Loader Class Initialized
INFO - 2022-07-04 07:20:21 --> Helper loaded: url_helper
INFO - 2022-07-04 07:20:21 --> Helper loaded: file_helper
INFO - 2022-07-04 07:20:21 --> Helper loaded: form_helper
INFO - 2022-07-04 07:20:21 --> Helper loaded: my_helper
INFO - 2022-07-04 07:20:21 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:20:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:20:21 --> Controller Class Initialized
INFO - 2022-07-04 07:20:38 --> Config Class Initialized
INFO - 2022-07-04 07:20:38 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:20:38 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:20:38 --> Utf8 Class Initialized
INFO - 2022-07-04 07:20:38 --> URI Class Initialized
INFO - 2022-07-04 07:20:38 --> Router Class Initialized
INFO - 2022-07-04 07:20:38 --> Output Class Initialized
INFO - 2022-07-04 07:20:38 --> Security Class Initialized
DEBUG - 2022-07-04 07:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:20:38 --> Input Class Initialized
INFO - 2022-07-04 07:20:38 --> Language Class Initialized
INFO - 2022-07-04 07:20:38 --> Language Class Initialized
INFO - 2022-07-04 07:20:38 --> Config Class Initialized
INFO - 2022-07-04 07:20:38 --> Loader Class Initialized
INFO - 2022-07-04 07:20:38 --> Helper loaded: url_helper
INFO - 2022-07-04 07:20:38 --> Helper loaded: file_helper
INFO - 2022-07-04 07:20:38 --> Helper loaded: form_helper
INFO - 2022-07-04 07:20:38 --> Helper loaded: my_helper
INFO - 2022-07-04 07:20:38 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:20:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:20:38 --> Controller Class Initialized
INFO - 2022-07-04 07:20:39 --> Config Class Initialized
INFO - 2022-07-04 07:20:39 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:20:39 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:20:39 --> Utf8 Class Initialized
INFO - 2022-07-04 07:20:39 --> URI Class Initialized
INFO - 2022-07-04 07:20:39 --> Router Class Initialized
INFO - 2022-07-04 07:20:39 --> Output Class Initialized
INFO - 2022-07-04 07:20:39 --> Security Class Initialized
DEBUG - 2022-07-04 07:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:20:39 --> Input Class Initialized
INFO - 2022-07-04 07:20:39 --> Language Class Initialized
INFO - 2022-07-04 07:20:39 --> Language Class Initialized
INFO - 2022-07-04 07:20:39 --> Config Class Initialized
INFO - 2022-07-04 07:20:39 --> Loader Class Initialized
INFO - 2022-07-04 07:20:39 --> Helper loaded: url_helper
INFO - 2022-07-04 07:20:39 --> Helper loaded: file_helper
INFO - 2022-07-04 07:20:39 --> Helper loaded: form_helper
INFO - 2022-07-04 07:20:39 --> Helper loaded: my_helper
INFO - 2022-07-04 07:20:39 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:20:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:20:39 --> Controller Class Initialized
INFO - 2022-07-04 07:20:40 --> Config Class Initialized
INFO - 2022-07-04 07:20:40 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:20:40 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:20:40 --> Utf8 Class Initialized
INFO - 2022-07-04 07:20:40 --> URI Class Initialized
INFO - 2022-07-04 07:20:40 --> Router Class Initialized
INFO - 2022-07-04 07:20:40 --> Output Class Initialized
INFO - 2022-07-04 07:20:40 --> Security Class Initialized
DEBUG - 2022-07-04 07:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:20:40 --> Input Class Initialized
INFO - 2022-07-04 07:20:40 --> Language Class Initialized
INFO - 2022-07-04 07:20:40 --> Language Class Initialized
INFO - 2022-07-04 07:20:40 --> Config Class Initialized
INFO - 2022-07-04 07:20:40 --> Loader Class Initialized
INFO - 2022-07-04 07:20:40 --> Helper loaded: url_helper
INFO - 2022-07-04 07:20:40 --> Helper loaded: file_helper
INFO - 2022-07-04 07:20:40 --> Helper loaded: form_helper
INFO - 2022-07-04 07:20:40 --> Helper loaded: my_helper
INFO - 2022-07-04 07:20:40 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:20:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:20:40 --> Controller Class Initialized
INFO - 2022-07-04 07:21:28 --> Config Class Initialized
INFO - 2022-07-04 07:21:28 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:21:28 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:21:28 --> Utf8 Class Initialized
INFO - 2022-07-04 07:21:28 --> URI Class Initialized
INFO - 2022-07-04 07:21:28 --> Router Class Initialized
INFO - 2022-07-04 07:21:28 --> Output Class Initialized
INFO - 2022-07-04 07:21:28 --> Security Class Initialized
DEBUG - 2022-07-04 07:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:21:28 --> Input Class Initialized
INFO - 2022-07-04 07:21:28 --> Language Class Initialized
INFO - 2022-07-04 07:21:28 --> Language Class Initialized
INFO - 2022-07-04 07:21:28 --> Config Class Initialized
INFO - 2022-07-04 07:21:28 --> Loader Class Initialized
INFO - 2022-07-04 07:21:28 --> Helper loaded: url_helper
INFO - 2022-07-04 07:21:28 --> Helper loaded: file_helper
INFO - 2022-07-04 07:21:28 --> Helper loaded: form_helper
INFO - 2022-07-04 07:21:28 --> Helper loaded: my_helper
INFO - 2022-07-04 07:21:28 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:21:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:21:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:21:28 --> Controller Class Initialized
INFO - 2022-07-04 07:21:28 --> Helper loaded: cookie_helper
INFO - 2022-07-04 07:21:28 --> Config Class Initialized
INFO - 2022-07-04 07:21:28 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:21:28 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:21:28 --> Utf8 Class Initialized
INFO - 2022-07-04 07:21:28 --> URI Class Initialized
INFO - 2022-07-04 07:21:28 --> Router Class Initialized
INFO - 2022-07-04 07:21:28 --> Output Class Initialized
INFO - 2022-07-04 07:21:28 --> Security Class Initialized
DEBUG - 2022-07-04 07:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:21:28 --> Input Class Initialized
INFO - 2022-07-04 07:21:28 --> Language Class Initialized
INFO - 2022-07-04 07:21:28 --> Language Class Initialized
INFO - 2022-07-04 07:21:28 --> Config Class Initialized
INFO - 2022-07-04 07:21:28 --> Loader Class Initialized
INFO - 2022-07-04 07:21:28 --> Helper loaded: url_helper
INFO - 2022-07-04 07:21:28 --> Helper loaded: file_helper
INFO - 2022-07-04 07:21:28 --> Helper loaded: form_helper
INFO - 2022-07-04 07:21:28 --> Helper loaded: my_helper
INFO - 2022-07-04 07:21:28 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:21:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:21:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:21:28 --> Controller Class Initialized
DEBUG - 2022-07-04 07:21:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-07-04 07:21:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 07:21:28 --> Final output sent to browser
DEBUG - 2022-07-04 07:21:28 --> Total execution time: 0.0528
INFO - 2022-07-04 07:21:33 --> Config Class Initialized
INFO - 2022-07-04 07:21:33 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:21:33 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:21:33 --> Utf8 Class Initialized
INFO - 2022-07-04 07:21:33 --> URI Class Initialized
INFO - 2022-07-04 07:21:33 --> Router Class Initialized
INFO - 2022-07-04 07:21:33 --> Output Class Initialized
INFO - 2022-07-04 07:21:33 --> Security Class Initialized
DEBUG - 2022-07-04 07:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:21:33 --> Input Class Initialized
INFO - 2022-07-04 07:21:33 --> Language Class Initialized
INFO - 2022-07-04 07:21:33 --> Language Class Initialized
INFO - 2022-07-04 07:21:33 --> Config Class Initialized
INFO - 2022-07-04 07:21:33 --> Loader Class Initialized
INFO - 2022-07-04 07:21:33 --> Helper loaded: url_helper
INFO - 2022-07-04 07:21:33 --> Helper loaded: file_helper
INFO - 2022-07-04 07:21:33 --> Helper loaded: form_helper
INFO - 2022-07-04 07:21:33 --> Helper loaded: my_helper
INFO - 2022-07-04 07:21:33 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:21:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:21:33 --> Controller Class Initialized
INFO - 2022-07-04 07:21:33 --> Helper loaded: cookie_helper
INFO - 2022-07-04 07:21:33 --> Final output sent to browser
DEBUG - 2022-07-04 07:21:33 --> Total execution time: 0.0719
INFO - 2022-07-04 07:21:33 --> Config Class Initialized
INFO - 2022-07-04 07:21:33 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:21:33 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:21:33 --> Utf8 Class Initialized
INFO - 2022-07-04 07:21:33 --> URI Class Initialized
INFO - 2022-07-04 07:21:33 --> Router Class Initialized
INFO - 2022-07-04 07:21:33 --> Output Class Initialized
INFO - 2022-07-04 07:21:33 --> Security Class Initialized
DEBUG - 2022-07-04 07:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:21:33 --> Input Class Initialized
INFO - 2022-07-04 07:21:33 --> Language Class Initialized
INFO - 2022-07-04 07:21:33 --> Language Class Initialized
INFO - 2022-07-04 07:21:33 --> Config Class Initialized
INFO - 2022-07-04 07:21:33 --> Loader Class Initialized
INFO - 2022-07-04 07:21:33 --> Helper loaded: url_helper
INFO - 2022-07-04 07:21:33 --> Helper loaded: file_helper
INFO - 2022-07-04 07:21:33 --> Helper loaded: form_helper
INFO - 2022-07-04 07:21:33 --> Helper loaded: my_helper
INFO - 2022-07-04 07:21:33 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:21:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:21:33 --> Controller Class Initialized
DEBUG - 2022-07-04 07:21:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-07-04 07:21:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 07:21:33 --> Final output sent to browser
DEBUG - 2022-07-04 07:21:33 --> Total execution time: 0.5434
INFO - 2022-07-04 07:21:36 --> Config Class Initialized
INFO - 2022-07-04 07:21:36 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:21:36 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:21:36 --> Utf8 Class Initialized
INFO - 2022-07-04 07:21:36 --> URI Class Initialized
DEBUG - 2022-07-04 07:21:36 --> No URI present. Default controller set.
INFO - 2022-07-04 07:21:36 --> Router Class Initialized
INFO - 2022-07-04 07:21:36 --> Output Class Initialized
INFO - 2022-07-04 07:21:36 --> Security Class Initialized
DEBUG - 2022-07-04 07:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:21:36 --> Input Class Initialized
INFO - 2022-07-04 07:21:36 --> Language Class Initialized
INFO - 2022-07-04 07:21:36 --> Language Class Initialized
INFO - 2022-07-04 07:21:36 --> Config Class Initialized
INFO - 2022-07-04 07:21:36 --> Loader Class Initialized
INFO - 2022-07-04 07:21:36 --> Helper loaded: url_helper
INFO - 2022-07-04 07:21:36 --> Helper loaded: file_helper
INFO - 2022-07-04 07:21:36 --> Helper loaded: form_helper
INFO - 2022-07-04 07:21:36 --> Helper loaded: my_helper
INFO - 2022-07-04 07:21:36 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:21:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:21:36 --> Controller Class Initialized
DEBUG - 2022-07-04 07:21:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-07-04 07:21:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 07:21:37 --> Final output sent to browser
DEBUG - 2022-07-04 07:21:37 --> Total execution time: 0.5465
INFO - 2022-07-04 07:21:37 --> Config Class Initialized
INFO - 2022-07-04 07:21:37 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:21:37 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:21:37 --> Utf8 Class Initialized
INFO - 2022-07-04 07:21:37 --> URI Class Initialized
DEBUG - 2022-07-04 07:21:37 --> No URI present. Default controller set.
INFO - 2022-07-04 07:21:37 --> Router Class Initialized
INFO - 2022-07-04 07:21:37 --> Output Class Initialized
INFO - 2022-07-04 07:21:37 --> Security Class Initialized
DEBUG - 2022-07-04 07:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:21:37 --> Input Class Initialized
INFO - 2022-07-04 07:21:37 --> Language Class Initialized
INFO - 2022-07-04 07:21:37 --> Language Class Initialized
INFO - 2022-07-04 07:21:37 --> Config Class Initialized
INFO - 2022-07-04 07:21:37 --> Loader Class Initialized
INFO - 2022-07-04 07:21:37 --> Helper loaded: url_helper
INFO - 2022-07-04 07:21:37 --> Helper loaded: file_helper
INFO - 2022-07-04 07:21:37 --> Helper loaded: form_helper
INFO - 2022-07-04 07:21:37 --> Helper loaded: my_helper
INFO - 2022-07-04 07:21:37 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:21:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:21:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:21:37 --> Controller Class Initialized
DEBUG - 2022-07-04 07:21:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-07-04 07:21:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 07:21:37 --> Final output sent to browser
DEBUG - 2022-07-04 07:21:37 --> Total execution time: 0.4978
INFO - 2022-07-04 07:21:37 --> Config Class Initialized
INFO - 2022-07-04 07:21:37 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:21:37 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:21:37 --> Utf8 Class Initialized
INFO - 2022-07-04 07:21:37 --> URI Class Initialized
INFO - 2022-07-04 07:21:37 --> Router Class Initialized
INFO - 2022-07-04 07:21:37 --> Output Class Initialized
INFO - 2022-07-04 07:21:37 --> Security Class Initialized
DEBUG - 2022-07-04 07:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:21:37 --> Input Class Initialized
INFO - 2022-07-04 07:21:37 --> Language Class Initialized
INFO - 2022-07-04 07:21:37 --> Language Class Initialized
INFO - 2022-07-04 07:21:37 --> Config Class Initialized
INFO - 2022-07-04 07:21:37 --> Loader Class Initialized
INFO - 2022-07-04 07:21:37 --> Helper loaded: url_helper
INFO - 2022-07-04 07:21:37 --> Helper loaded: file_helper
INFO - 2022-07-04 07:21:37 --> Helper loaded: form_helper
INFO - 2022-07-04 07:21:37 --> Helper loaded: my_helper
INFO - 2022-07-04 07:21:38 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:21:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:21:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:21:38 --> Controller Class Initialized
DEBUG - 2022-07-04 07:21:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-07-04 07:21:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 07:21:38 --> Final output sent to browser
DEBUG - 2022-07-04 07:21:38 --> Total execution time: 0.0732
INFO - 2022-07-04 07:21:38 --> Config Class Initialized
INFO - 2022-07-04 07:21:38 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:21:38 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:21:38 --> Utf8 Class Initialized
INFO - 2022-07-04 07:21:38 --> URI Class Initialized
INFO - 2022-07-04 07:21:38 --> Router Class Initialized
INFO - 2022-07-04 07:21:38 --> Output Class Initialized
INFO - 2022-07-04 07:21:38 --> Security Class Initialized
DEBUG - 2022-07-04 07:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:21:38 --> Input Class Initialized
INFO - 2022-07-04 07:21:38 --> Language Class Initialized
INFO - 2022-07-04 07:21:38 --> Language Class Initialized
INFO - 2022-07-04 07:21:38 --> Config Class Initialized
INFO - 2022-07-04 07:21:38 --> Loader Class Initialized
INFO - 2022-07-04 07:21:38 --> Helper loaded: url_helper
INFO - 2022-07-04 07:21:38 --> Helper loaded: file_helper
INFO - 2022-07-04 07:21:38 --> Helper loaded: form_helper
INFO - 2022-07-04 07:21:38 --> Helper loaded: my_helper
INFO - 2022-07-04 07:21:38 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:21:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:21:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:21:38 --> Controller Class Initialized
DEBUG - 2022-07-04 07:21:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-07-04 07:21:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 07:21:38 --> Final output sent to browser
DEBUG - 2022-07-04 07:21:38 --> Total execution time: 0.0415
INFO - 2022-07-04 07:21:44 --> Config Class Initialized
INFO - 2022-07-04 07:21:44 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:21:44 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:21:44 --> Utf8 Class Initialized
INFO - 2022-07-04 07:21:44 --> URI Class Initialized
INFO - 2022-07-04 07:21:44 --> Router Class Initialized
INFO - 2022-07-04 07:21:44 --> Output Class Initialized
INFO - 2022-07-04 07:21:44 --> Security Class Initialized
DEBUG - 2022-07-04 07:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:21:44 --> Input Class Initialized
INFO - 2022-07-04 07:21:44 --> Language Class Initialized
INFO - 2022-07-04 07:21:44 --> Language Class Initialized
INFO - 2022-07-04 07:21:44 --> Config Class Initialized
INFO - 2022-07-04 07:21:44 --> Loader Class Initialized
INFO - 2022-07-04 07:21:44 --> Helper loaded: url_helper
INFO - 2022-07-04 07:21:44 --> Helper loaded: file_helper
INFO - 2022-07-04 07:21:44 --> Helper loaded: form_helper
INFO - 2022-07-04 07:21:44 --> Helper loaded: my_helper
INFO - 2022-07-04 07:21:44 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:21:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:21:44 --> Controller Class Initialized
DEBUG - 2022-07-04 07:21:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-07-04 07:21:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 07:21:44 --> Final output sent to browser
DEBUG - 2022-07-04 07:21:44 --> Total execution time: 0.1027
INFO - 2022-07-04 07:21:44 --> Config Class Initialized
INFO - 2022-07-04 07:21:44 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:21:44 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:21:44 --> Utf8 Class Initialized
INFO - 2022-07-04 07:21:44 --> URI Class Initialized
INFO - 2022-07-04 07:21:44 --> Router Class Initialized
INFO - 2022-07-04 07:21:44 --> Output Class Initialized
INFO - 2022-07-04 07:21:44 --> Security Class Initialized
DEBUG - 2022-07-04 07:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:21:44 --> Input Class Initialized
INFO - 2022-07-04 07:21:44 --> Language Class Initialized
INFO - 2022-07-04 07:21:44 --> Language Class Initialized
INFO - 2022-07-04 07:21:44 --> Config Class Initialized
INFO - 2022-07-04 07:21:44 --> Loader Class Initialized
INFO - 2022-07-04 07:21:44 --> Helper loaded: url_helper
INFO - 2022-07-04 07:21:44 --> Helper loaded: file_helper
INFO - 2022-07-04 07:21:44 --> Helper loaded: form_helper
INFO - 2022-07-04 07:21:44 --> Helper loaded: my_helper
INFO - 2022-07-04 07:21:44 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:21:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:21:44 --> Controller Class Initialized
INFO - 2022-07-04 07:21:45 --> Config Class Initialized
INFO - 2022-07-04 07:21:45 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:21:45 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:21:45 --> Utf8 Class Initialized
INFO - 2022-07-04 07:21:45 --> URI Class Initialized
INFO - 2022-07-04 07:21:45 --> Router Class Initialized
INFO - 2022-07-04 07:21:45 --> Output Class Initialized
INFO - 2022-07-04 07:21:45 --> Security Class Initialized
DEBUG - 2022-07-04 07:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:21:45 --> Input Class Initialized
INFO - 2022-07-04 07:21:45 --> Language Class Initialized
INFO - 2022-07-04 07:21:45 --> Language Class Initialized
INFO - 2022-07-04 07:21:45 --> Config Class Initialized
INFO - 2022-07-04 07:21:45 --> Loader Class Initialized
INFO - 2022-07-04 07:21:45 --> Helper loaded: url_helper
INFO - 2022-07-04 07:21:45 --> Helper loaded: file_helper
INFO - 2022-07-04 07:21:45 --> Helper loaded: form_helper
INFO - 2022-07-04 07:21:45 --> Helper loaded: my_helper
INFO - 2022-07-04 07:21:45 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:21:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:21:45 --> Controller Class Initialized
DEBUG - 2022-07-04 07:21:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-07-04 07:21:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 07:21:45 --> Final output sent to browser
DEBUG - 2022-07-04 07:21:45 --> Total execution time: 0.1026
INFO - 2022-07-04 07:22:04 --> Config Class Initialized
INFO - 2022-07-04 07:22:04 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:22:04 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:22:04 --> Utf8 Class Initialized
INFO - 2022-07-04 07:22:04 --> URI Class Initialized
INFO - 2022-07-04 07:22:04 --> Router Class Initialized
INFO - 2022-07-04 07:22:04 --> Output Class Initialized
INFO - 2022-07-04 07:22:04 --> Security Class Initialized
DEBUG - 2022-07-04 07:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:22:04 --> Input Class Initialized
INFO - 2022-07-04 07:22:04 --> Language Class Initialized
INFO - 2022-07-04 07:22:04 --> Language Class Initialized
INFO - 2022-07-04 07:22:04 --> Config Class Initialized
INFO - 2022-07-04 07:22:04 --> Loader Class Initialized
INFO - 2022-07-04 07:22:04 --> Helper loaded: url_helper
INFO - 2022-07-04 07:22:04 --> Helper loaded: file_helper
INFO - 2022-07-04 07:22:04 --> Helper loaded: form_helper
INFO - 2022-07-04 07:22:04 --> Helper loaded: my_helper
INFO - 2022-07-04 07:22:04 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:22:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:22:04 --> Controller Class Initialized
INFO - 2022-07-04 07:22:06 --> Config Class Initialized
INFO - 2022-07-04 07:22:06 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:22:06 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:22:06 --> Utf8 Class Initialized
INFO - 2022-07-04 07:22:06 --> URI Class Initialized
INFO - 2022-07-04 07:22:06 --> Router Class Initialized
INFO - 2022-07-04 07:22:06 --> Output Class Initialized
INFO - 2022-07-04 07:22:06 --> Security Class Initialized
DEBUG - 2022-07-04 07:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:22:06 --> Input Class Initialized
INFO - 2022-07-04 07:22:06 --> Language Class Initialized
INFO - 2022-07-04 07:22:06 --> Language Class Initialized
INFO - 2022-07-04 07:22:06 --> Config Class Initialized
INFO - 2022-07-04 07:22:06 --> Loader Class Initialized
INFO - 2022-07-04 07:22:06 --> Helper loaded: url_helper
INFO - 2022-07-04 07:22:06 --> Helper loaded: file_helper
INFO - 2022-07-04 07:22:06 --> Helper loaded: form_helper
INFO - 2022-07-04 07:22:06 --> Helper loaded: my_helper
INFO - 2022-07-04 07:22:06 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:22:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:22:06 --> Controller Class Initialized
INFO - 2022-07-04 07:23:20 --> Config Class Initialized
INFO - 2022-07-04 07:23:20 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:23:20 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:23:20 --> Utf8 Class Initialized
INFO - 2022-07-04 07:23:20 --> URI Class Initialized
INFO - 2022-07-04 07:23:20 --> Router Class Initialized
INFO - 2022-07-04 07:23:20 --> Output Class Initialized
INFO - 2022-07-04 07:23:20 --> Security Class Initialized
DEBUG - 2022-07-04 07:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:23:20 --> Input Class Initialized
INFO - 2022-07-04 07:23:20 --> Language Class Initialized
INFO - 2022-07-04 07:23:20 --> Language Class Initialized
INFO - 2022-07-04 07:23:20 --> Config Class Initialized
INFO - 2022-07-04 07:23:20 --> Loader Class Initialized
INFO - 2022-07-04 07:23:20 --> Helper loaded: url_helper
INFO - 2022-07-04 07:23:20 --> Helper loaded: file_helper
INFO - 2022-07-04 07:23:20 --> Helper loaded: form_helper
INFO - 2022-07-04 07:23:20 --> Helper loaded: my_helper
INFO - 2022-07-04 07:23:20 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:23:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:23:20 --> Controller Class Initialized
INFO - 2022-07-04 07:23:20 --> Helper loaded: cookie_helper
INFO - 2022-07-04 07:23:20 --> Config Class Initialized
INFO - 2022-07-04 07:23:20 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:23:20 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:23:20 --> Utf8 Class Initialized
INFO - 2022-07-04 07:23:20 --> URI Class Initialized
INFO - 2022-07-04 07:23:20 --> Router Class Initialized
INFO - 2022-07-04 07:23:20 --> Output Class Initialized
INFO - 2022-07-04 07:23:20 --> Security Class Initialized
DEBUG - 2022-07-04 07:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:23:20 --> Input Class Initialized
INFO - 2022-07-04 07:23:20 --> Language Class Initialized
INFO - 2022-07-04 07:23:20 --> Language Class Initialized
INFO - 2022-07-04 07:23:20 --> Config Class Initialized
INFO - 2022-07-04 07:23:20 --> Loader Class Initialized
INFO - 2022-07-04 07:23:20 --> Helper loaded: url_helper
INFO - 2022-07-04 07:23:20 --> Helper loaded: file_helper
INFO - 2022-07-04 07:23:21 --> Helper loaded: form_helper
INFO - 2022-07-04 07:23:21 --> Helper loaded: my_helper
INFO - 2022-07-04 07:23:21 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:23:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:23:21 --> Controller Class Initialized
DEBUG - 2022-07-04 07:23:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-07-04 07:23:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 07:23:21 --> Final output sent to browser
DEBUG - 2022-07-04 07:23:21 --> Total execution time: 0.0534
INFO - 2022-07-04 07:23:26 --> Config Class Initialized
INFO - 2022-07-04 07:23:26 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:23:26 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:23:26 --> Utf8 Class Initialized
INFO - 2022-07-04 07:23:26 --> URI Class Initialized
INFO - 2022-07-04 07:23:26 --> Router Class Initialized
INFO - 2022-07-04 07:23:26 --> Output Class Initialized
INFO - 2022-07-04 07:23:26 --> Security Class Initialized
DEBUG - 2022-07-04 07:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:23:26 --> Input Class Initialized
INFO - 2022-07-04 07:23:26 --> Language Class Initialized
INFO - 2022-07-04 07:23:26 --> Language Class Initialized
INFO - 2022-07-04 07:23:26 --> Config Class Initialized
INFO - 2022-07-04 07:23:26 --> Loader Class Initialized
INFO - 2022-07-04 07:23:26 --> Helper loaded: url_helper
INFO - 2022-07-04 07:23:26 --> Helper loaded: file_helper
INFO - 2022-07-04 07:23:26 --> Helper loaded: form_helper
INFO - 2022-07-04 07:23:26 --> Helper loaded: my_helper
INFO - 2022-07-04 07:23:26 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:23:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:23:26 --> Controller Class Initialized
INFO - 2022-07-04 07:23:26 --> Helper loaded: cookie_helper
INFO - 2022-07-04 07:23:26 --> Final output sent to browser
DEBUG - 2022-07-04 07:23:26 --> Total execution time: 0.0570
INFO - 2022-07-04 07:23:26 --> Config Class Initialized
INFO - 2022-07-04 07:23:26 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:23:26 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:23:26 --> Utf8 Class Initialized
INFO - 2022-07-04 07:23:26 --> URI Class Initialized
INFO - 2022-07-04 07:23:26 --> Router Class Initialized
INFO - 2022-07-04 07:23:26 --> Output Class Initialized
INFO - 2022-07-04 07:23:26 --> Security Class Initialized
DEBUG - 2022-07-04 07:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:23:26 --> Input Class Initialized
INFO - 2022-07-04 07:23:26 --> Language Class Initialized
INFO - 2022-07-04 07:23:26 --> Language Class Initialized
INFO - 2022-07-04 07:23:26 --> Config Class Initialized
INFO - 2022-07-04 07:23:26 --> Loader Class Initialized
INFO - 2022-07-04 07:23:26 --> Helper loaded: url_helper
INFO - 2022-07-04 07:23:26 --> Helper loaded: file_helper
INFO - 2022-07-04 07:23:26 --> Helper loaded: form_helper
INFO - 2022-07-04 07:23:26 --> Helper loaded: my_helper
INFO - 2022-07-04 07:23:26 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:23:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:23:26 --> Controller Class Initialized
DEBUG - 2022-07-04 07:23:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-07-04 07:23:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 07:23:26 --> Final output sent to browser
DEBUG - 2022-07-04 07:23:26 --> Total execution time: 0.5811
INFO - 2022-07-04 07:23:37 --> Config Class Initialized
INFO - 2022-07-04 07:23:37 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:23:37 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:23:37 --> Utf8 Class Initialized
INFO - 2022-07-04 07:23:37 --> URI Class Initialized
INFO - 2022-07-04 07:23:37 --> Router Class Initialized
INFO - 2022-07-04 07:23:37 --> Output Class Initialized
INFO - 2022-07-04 07:23:37 --> Security Class Initialized
DEBUG - 2022-07-04 07:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:23:37 --> Input Class Initialized
INFO - 2022-07-04 07:23:37 --> Language Class Initialized
INFO - 2022-07-04 07:23:37 --> Language Class Initialized
INFO - 2022-07-04 07:23:37 --> Config Class Initialized
INFO - 2022-07-04 07:23:37 --> Loader Class Initialized
INFO - 2022-07-04 07:23:37 --> Helper loaded: url_helper
INFO - 2022-07-04 07:23:37 --> Helper loaded: file_helper
INFO - 2022-07-04 07:23:37 --> Helper loaded: form_helper
INFO - 2022-07-04 07:23:37 --> Helper loaded: my_helper
INFO - 2022-07-04 07:23:37 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:23:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:23:37 --> Controller Class Initialized
DEBUG - 2022-07-04 07:23:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-07-04 07:23:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 07:23:37 --> Final output sent to browser
DEBUG - 2022-07-04 07:23:37 --> Total execution time: 0.0468
INFO - 2022-07-04 07:23:40 --> Config Class Initialized
INFO - 2022-07-04 07:23:40 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:23:40 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:23:40 --> Utf8 Class Initialized
INFO - 2022-07-04 07:23:40 --> URI Class Initialized
INFO - 2022-07-04 07:23:40 --> Router Class Initialized
INFO - 2022-07-04 07:23:40 --> Output Class Initialized
INFO - 2022-07-04 07:23:40 --> Security Class Initialized
DEBUG - 2022-07-04 07:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:23:40 --> Input Class Initialized
INFO - 2022-07-04 07:23:40 --> Language Class Initialized
INFO - 2022-07-04 07:23:40 --> Language Class Initialized
INFO - 2022-07-04 07:23:40 --> Config Class Initialized
INFO - 2022-07-04 07:23:40 --> Loader Class Initialized
INFO - 2022-07-04 07:23:40 --> Helper loaded: url_helper
INFO - 2022-07-04 07:23:40 --> Helper loaded: file_helper
INFO - 2022-07-04 07:23:40 --> Helper loaded: form_helper
INFO - 2022-07-04 07:23:40 --> Helper loaded: my_helper
INFO - 2022-07-04 07:23:40 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:23:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:23:40 --> Controller Class Initialized
INFO - 2022-07-04 07:23:40 --> Helper loaded: cookie_helper
INFO - 2022-07-04 07:23:40 --> Final output sent to browser
DEBUG - 2022-07-04 07:23:40 --> Total execution time: 0.0463
INFO - 2022-07-04 07:23:41 --> Config Class Initialized
INFO - 2022-07-04 07:23:41 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:23:41 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:23:41 --> Utf8 Class Initialized
INFO - 2022-07-04 07:23:41 --> URI Class Initialized
INFO - 2022-07-04 07:23:41 --> Router Class Initialized
INFO - 2022-07-04 07:23:41 --> Output Class Initialized
INFO - 2022-07-04 07:23:41 --> Security Class Initialized
DEBUG - 2022-07-04 07:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:23:41 --> Input Class Initialized
INFO - 2022-07-04 07:23:41 --> Language Class Initialized
INFO - 2022-07-04 07:23:41 --> Language Class Initialized
INFO - 2022-07-04 07:23:41 --> Config Class Initialized
INFO - 2022-07-04 07:23:41 --> Loader Class Initialized
INFO - 2022-07-04 07:23:41 --> Helper loaded: url_helper
INFO - 2022-07-04 07:23:41 --> Helper loaded: file_helper
INFO - 2022-07-04 07:23:41 --> Helper loaded: form_helper
INFO - 2022-07-04 07:23:41 --> Helper loaded: my_helper
INFO - 2022-07-04 07:23:41 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:23:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:23:41 --> Controller Class Initialized
DEBUG - 2022-07-04 07:23:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-07-04 07:23:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 07:23:41 --> Final output sent to browser
DEBUG - 2022-07-04 07:23:41 --> Total execution time: 0.5657
INFO - 2022-07-04 07:23:44 --> Config Class Initialized
INFO - 2022-07-04 07:23:44 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:23:44 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:23:44 --> Utf8 Class Initialized
INFO - 2022-07-04 07:23:44 --> URI Class Initialized
INFO - 2022-07-04 07:23:44 --> Router Class Initialized
INFO - 2022-07-04 07:23:44 --> Output Class Initialized
INFO - 2022-07-04 07:23:44 --> Security Class Initialized
DEBUG - 2022-07-04 07:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:23:44 --> Input Class Initialized
INFO - 2022-07-04 07:23:44 --> Language Class Initialized
INFO - 2022-07-04 07:23:44 --> Language Class Initialized
INFO - 2022-07-04 07:23:44 --> Config Class Initialized
INFO - 2022-07-04 07:23:44 --> Loader Class Initialized
INFO - 2022-07-04 07:23:44 --> Helper loaded: url_helper
INFO - 2022-07-04 07:23:44 --> Helper loaded: file_helper
INFO - 2022-07-04 07:23:44 --> Helper loaded: form_helper
INFO - 2022-07-04 07:23:44 --> Helper loaded: my_helper
INFO - 2022-07-04 07:23:44 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:23:44 --> Controller Class Initialized
DEBUG - 2022-07-04 07:23:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2022-07-04 07:23:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 07:23:44 --> Final output sent to browser
DEBUG - 2022-07-04 07:23:44 --> Total execution time: 0.0765
INFO - 2022-07-04 07:23:48 --> Config Class Initialized
INFO - 2022-07-04 07:23:48 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:23:48 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:23:48 --> Utf8 Class Initialized
INFO - 2022-07-04 07:23:48 --> URI Class Initialized
INFO - 2022-07-04 07:23:48 --> Router Class Initialized
INFO - 2022-07-04 07:23:48 --> Output Class Initialized
INFO - 2022-07-04 07:23:48 --> Security Class Initialized
DEBUG - 2022-07-04 07:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:23:48 --> Input Class Initialized
INFO - 2022-07-04 07:23:48 --> Language Class Initialized
INFO - 2022-07-04 07:23:48 --> Language Class Initialized
INFO - 2022-07-04 07:23:48 --> Config Class Initialized
INFO - 2022-07-04 07:23:48 --> Loader Class Initialized
INFO - 2022-07-04 07:23:48 --> Helper loaded: url_helper
INFO - 2022-07-04 07:23:48 --> Helper loaded: file_helper
INFO - 2022-07-04 07:23:48 --> Helper loaded: form_helper
INFO - 2022-07-04 07:23:48 --> Helper loaded: my_helper
INFO - 2022-07-04 07:23:48 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:23:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:23:48 --> Controller Class Initialized
DEBUG - 2022-07-04 07:23:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tkro_xii.php
INFO - 2022-07-04 07:23:48 --> Final output sent to browser
DEBUG - 2022-07-04 07:23:48 --> Total execution time: 0.3063
INFO - 2022-07-04 07:25:03 --> Config Class Initialized
INFO - 2022-07-04 07:25:03 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:25:03 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:25:03 --> Utf8 Class Initialized
INFO - 2022-07-04 07:25:03 --> URI Class Initialized
INFO - 2022-07-04 07:25:03 --> Router Class Initialized
INFO - 2022-07-04 07:25:03 --> Output Class Initialized
INFO - 2022-07-04 07:25:03 --> Security Class Initialized
DEBUG - 2022-07-04 07:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:25:03 --> Input Class Initialized
INFO - 2022-07-04 07:25:03 --> Language Class Initialized
INFO - 2022-07-04 07:25:03 --> Language Class Initialized
INFO - 2022-07-04 07:25:03 --> Config Class Initialized
INFO - 2022-07-04 07:25:03 --> Loader Class Initialized
INFO - 2022-07-04 07:25:03 --> Helper loaded: url_helper
INFO - 2022-07-04 07:25:03 --> Helper loaded: file_helper
INFO - 2022-07-04 07:25:03 --> Helper loaded: form_helper
INFO - 2022-07-04 07:25:03 --> Helper loaded: my_helper
INFO - 2022-07-04 07:25:03 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:25:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:25:03 --> Controller Class Initialized
DEBUG - 2022-07-04 07:25:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2022-07-04 07:25:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 07:25:04 --> Final output sent to browser
DEBUG - 2022-07-04 07:25:04 --> Total execution time: 0.6563
INFO - 2022-07-04 07:25:08 --> Config Class Initialized
INFO - 2022-07-04 07:25:08 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:25:08 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:25:08 --> Utf8 Class Initialized
INFO - 2022-07-04 07:25:08 --> URI Class Initialized
INFO - 2022-07-04 07:25:08 --> Router Class Initialized
INFO - 2022-07-04 07:25:08 --> Output Class Initialized
INFO - 2022-07-04 07:25:08 --> Security Class Initialized
DEBUG - 2022-07-04 07:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:25:08 --> Input Class Initialized
INFO - 2022-07-04 07:25:08 --> Language Class Initialized
INFO - 2022-07-04 07:25:08 --> Language Class Initialized
INFO - 2022-07-04 07:25:08 --> Config Class Initialized
INFO - 2022-07-04 07:25:08 --> Loader Class Initialized
INFO - 2022-07-04 07:25:08 --> Helper loaded: url_helper
INFO - 2022-07-04 07:25:08 --> Helper loaded: file_helper
INFO - 2022-07-04 07:25:08 --> Helper loaded: form_helper
INFO - 2022-07-04 07:25:08 --> Helper loaded: my_helper
INFO - 2022-07-04 07:25:08 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:25:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:25:08 --> Controller Class Initialized
INFO - 2022-07-04 07:25:08 --> Config Class Initialized
INFO - 2022-07-04 07:25:08 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:25:08 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:25:08 --> Utf8 Class Initialized
INFO - 2022-07-04 07:25:08 --> URI Class Initialized
INFO - 2022-07-04 07:25:08 --> Router Class Initialized
INFO - 2022-07-04 07:25:08 --> Output Class Initialized
INFO - 2022-07-04 07:25:08 --> Security Class Initialized
DEBUG - 2022-07-04 07:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:25:08 --> Input Class Initialized
INFO - 2022-07-04 07:25:08 --> Language Class Initialized
INFO - 2022-07-04 07:25:08 --> Language Class Initialized
INFO - 2022-07-04 07:25:08 --> Config Class Initialized
INFO - 2022-07-04 07:25:08 --> Loader Class Initialized
INFO - 2022-07-04 07:25:08 --> Helper loaded: url_helper
INFO - 2022-07-04 07:25:08 --> Helper loaded: file_helper
INFO - 2022-07-04 07:25:08 --> Helper loaded: form_helper
INFO - 2022-07-04 07:25:08 --> Helper loaded: my_helper
INFO - 2022-07-04 07:25:08 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:25:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:25:08 --> Controller Class Initialized
DEBUG - 2022-07-04 07:25:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-07-04 07:25:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 07:25:08 --> Final output sent to browser
DEBUG - 2022-07-04 07:25:08 --> Total execution time: 0.0722
INFO - 2022-07-04 07:25:09 --> Config Class Initialized
INFO - 2022-07-04 07:25:09 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:25:09 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:25:09 --> Utf8 Class Initialized
INFO - 2022-07-04 07:25:09 --> URI Class Initialized
INFO - 2022-07-04 07:25:09 --> Router Class Initialized
INFO - 2022-07-04 07:25:09 --> Output Class Initialized
INFO - 2022-07-04 07:25:09 --> Security Class Initialized
DEBUG - 2022-07-04 07:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:25:09 --> Input Class Initialized
INFO - 2022-07-04 07:25:09 --> Language Class Initialized
INFO - 2022-07-04 07:25:09 --> Language Class Initialized
INFO - 2022-07-04 07:25:09 --> Config Class Initialized
INFO - 2022-07-04 07:25:09 --> Loader Class Initialized
INFO - 2022-07-04 07:25:09 --> Helper loaded: url_helper
INFO - 2022-07-04 07:25:09 --> Helper loaded: file_helper
INFO - 2022-07-04 07:25:09 --> Helper loaded: form_helper
INFO - 2022-07-04 07:25:09 --> Helper loaded: my_helper
INFO - 2022-07-04 07:25:09 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:25:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:25:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:25:09 --> Controller Class Initialized
INFO - 2022-07-04 07:25:10 --> Config Class Initialized
INFO - 2022-07-04 07:25:10 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:25:10 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:25:10 --> Utf8 Class Initialized
INFO - 2022-07-04 07:25:10 --> URI Class Initialized
INFO - 2022-07-04 07:25:10 --> Router Class Initialized
INFO - 2022-07-04 07:25:10 --> Output Class Initialized
INFO - 2022-07-04 07:25:10 --> Security Class Initialized
DEBUG - 2022-07-04 07:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:25:10 --> Input Class Initialized
INFO - 2022-07-04 07:25:10 --> Language Class Initialized
INFO - 2022-07-04 07:25:10 --> Language Class Initialized
INFO - 2022-07-04 07:25:10 --> Config Class Initialized
INFO - 2022-07-04 07:25:10 --> Loader Class Initialized
INFO - 2022-07-04 07:25:10 --> Helper loaded: url_helper
INFO - 2022-07-04 07:25:10 --> Helper loaded: file_helper
INFO - 2022-07-04 07:25:10 --> Helper loaded: form_helper
INFO - 2022-07-04 07:25:10 --> Helper loaded: my_helper
INFO - 2022-07-04 07:25:10 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:25:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:25:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:25:10 --> Controller Class Initialized
DEBUG - 2022-07-04 07:25:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2022-07-04 07:25:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 07:25:10 --> Final output sent to browser
DEBUG - 2022-07-04 07:25:10 --> Total execution time: 0.0581
INFO - 2022-07-04 07:25:13 --> Config Class Initialized
INFO - 2022-07-04 07:25:13 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:25:13 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:25:13 --> Utf8 Class Initialized
INFO - 2022-07-04 07:25:13 --> URI Class Initialized
INFO - 2022-07-04 07:25:13 --> Router Class Initialized
INFO - 2022-07-04 07:25:13 --> Output Class Initialized
INFO - 2022-07-04 07:25:13 --> Security Class Initialized
DEBUG - 2022-07-04 07:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:25:13 --> Input Class Initialized
INFO - 2022-07-04 07:25:13 --> Language Class Initialized
INFO - 2022-07-04 07:25:13 --> Language Class Initialized
INFO - 2022-07-04 07:25:13 --> Config Class Initialized
INFO - 2022-07-04 07:25:13 --> Loader Class Initialized
INFO - 2022-07-04 07:25:13 --> Helper loaded: url_helper
INFO - 2022-07-04 07:25:13 --> Helper loaded: file_helper
INFO - 2022-07-04 07:25:13 --> Helper loaded: form_helper
INFO - 2022-07-04 07:25:13 --> Helper loaded: my_helper
INFO - 2022-07-04 07:25:13 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:25:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:25:13 --> Controller Class Initialized
INFO - 2022-07-04 07:25:13 --> Config Class Initialized
INFO - 2022-07-04 07:25:13 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:25:13 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:25:13 --> Utf8 Class Initialized
INFO - 2022-07-04 07:25:13 --> URI Class Initialized
INFO - 2022-07-04 07:25:13 --> Router Class Initialized
INFO - 2022-07-04 07:25:13 --> Output Class Initialized
INFO - 2022-07-04 07:25:13 --> Security Class Initialized
DEBUG - 2022-07-04 07:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:25:13 --> Input Class Initialized
INFO - 2022-07-04 07:25:13 --> Language Class Initialized
INFO - 2022-07-04 07:25:13 --> Language Class Initialized
INFO - 2022-07-04 07:25:13 --> Config Class Initialized
INFO - 2022-07-04 07:25:13 --> Loader Class Initialized
INFO - 2022-07-04 07:25:13 --> Helper loaded: url_helper
INFO - 2022-07-04 07:25:13 --> Helper loaded: file_helper
INFO - 2022-07-04 07:25:13 --> Helper loaded: form_helper
INFO - 2022-07-04 07:25:13 --> Helper loaded: my_helper
INFO - 2022-07-04 07:25:13 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:25:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:25:13 --> Controller Class Initialized
DEBUG - 2022-07-04 07:25:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-07-04 07:25:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 07:25:13 --> Final output sent to browser
DEBUG - 2022-07-04 07:25:13 --> Total execution time: 0.0484
INFO - 2022-07-04 07:25:25 --> Config Class Initialized
INFO - 2022-07-04 07:25:25 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:25:25 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:25:25 --> Utf8 Class Initialized
INFO - 2022-07-04 07:25:25 --> URI Class Initialized
INFO - 2022-07-04 07:25:25 --> Router Class Initialized
INFO - 2022-07-04 07:25:25 --> Output Class Initialized
INFO - 2022-07-04 07:25:25 --> Security Class Initialized
DEBUG - 2022-07-04 07:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:25:25 --> Input Class Initialized
INFO - 2022-07-04 07:25:25 --> Language Class Initialized
INFO - 2022-07-04 07:25:25 --> Language Class Initialized
INFO - 2022-07-04 07:25:25 --> Config Class Initialized
INFO - 2022-07-04 07:25:25 --> Loader Class Initialized
INFO - 2022-07-04 07:25:25 --> Helper loaded: url_helper
INFO - 2022-07-04 07:25:25 --> Helper loaded: file_helper
INFO - 2022-07-04 07:25:25 --> Helper loaded: form_helper
INFO - 2022-07-04 07:25:25 --> Helper loaded: my_helper
INFO - 2022-07-04 07:25:25 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:25:25 --> Controller Class Initialized
INFO - 2022-07-04 07:25:25 --> Helper loaded: cookie_helper
INFO - 2022-07-04 07:25:25 --> Config Class Initialized
INFO - 2022-07-04 07:25:25 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:25:25 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:25:25 --> Utf8 Class Initialized
INFO - 2022-07-04 07:25:25 --> URI Class Initialized
INFO - 2022-07-04 07:25:25 --> Router Class Initialized
INFO - 2022-07-04 07:25:25 --> Output Class Initialized
INFO - 2022-07-04 07:25:25 --> Security Class Initialized
DEBUG - 2022-07-04 07:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:25:25 --> Input Class Initialized
INFO - 2022-07-04 07:25:25 --> Language Class Initialized
INFO - 2022-07-04 07:25:25 --> Language Class Initialized
INFO - 2022-07-04 07:25:25 --> Config Class Initialized
INFO - 2022-07-04 07:25:25 --> Loader Class Initialized
INFO - 2022-07-04 07:25:25 --> Helper loaded: url_helper
INFO - 2022-07-04 07:25:25 --> Helper loaded: file_helper
INFO - 2022-07-04 07:25:25 --> Helper loaded: form_helper
INFO - 2022-07-04 07:25:25 --> Helper loaded: my_helper
INFO - 2022-07-04 07:25:25 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:25:25 --> Controller Class Initialized
DEBUG - 2022-07-04 07:25:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-07-04 07:25:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 07:25:25 --> Final output sent to browser
DEBUG - 2022-07-04 07:25:25 --> Total execution time: 0.0441
INFO - 2022-07-04 07:25:54 --> Config Class Initialized
INFO - 2022-07-04 07:25:54 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:25:54 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:25:54 --> Utf8 Class Initialized
INFO - 2022-07-04 07:25:54 --> URI Class Initialized
INFO - 2022-07-04 07:25:54 --> Router Class Initialized
INFO - 2022-07-04 07:25:54 --> Output Class Initialized
INFO - 2022-07-04 07:25:54 --> Security Class Initialized
DEBUG - 2022-07-04 07:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:25:54 --> Input Class Initialized
INFO - 2022-07-04 07:25:54 --> Language Class Initialized
INFO - 2022-07-04 07:25:54 --> Language Class Initialized
INFO - 2022-07-04 07:25:54 --> Config Class Initialized
INFO - 2022-07-04 07:25:54 --> Loader Class Initialized
INFO - 2022-07-04 07:25:54 --> Helper loaded: url_helper
INFO - 2022-07-04 07:25:54 --> Helper loaded: file_helper
INFO - 2022-07-04 07:25:54 --> Helper loaded: form_helper
INFO - 2022-07-04 07:25:54 --> Helper loaded: my_helper
INFO - 2022-07-04 07:25:55 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:25:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:25:55 --> Controller Class Initialized
INFO - 2022-07-04 07:25:55 --> Helper loaded: cookie_helper
INFO - 2022-07-04 07:25:55 --> Final output sent to browser
DEBUG - 2022-07-04 07:25:55 --> Total execution time: 0.0656
INFO - 2022-07-04 07:25:55 --> Config Class Initialized
INFO - 2022-07-04 07:25:55 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:25:55 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:25:55 --> Utf8 Class Initialized
INFO - 2022-07-04 07:25:55 --> URI Class Initialized
INFO - 2022-07-04 07:25:55 --> Router Class Initialized
INFO - 2022-07-04 07:25:55 --> Output Class Initialized
INFO - 2022-07-04 07:25:55 --> Security Class Initialized
DEBUG - 2022-07-04 07:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:25:55 --> Input Class Initialized
INFO - 2022-07-04 07:25:55 --> Language Class Initialized
INFO - 2022-07-04 07:25:55 --> Language Class Initialized
INFO - 2022-07-04 07:25:55 --> Config Class Initialized
INFO - 2022-07-04 07:25:55 --> Loader Class Initialized
INFO - 2022-07-04 07:25:55 --> Helper loaded: url_helper
INFO - 2022-07-04 07:25:55 --> Helper loaded: file_helper
INFO - 2022-07-04 07:25:55 --> Helper loaded: form_helper
INFO - 2022-07-04 07:25:55 --> Helper loaded: my_helper
INFO - 2022-07-04 07:25:55 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:25:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:25:55 --> Controller Class Initialized
DEBUG - 2022-07-04 07:25:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-07-04 07:25:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 07:25:55 --> Final output sent to browser
DEBUG - 2022-07-04 07:25:55 --> Total execution time: 0.5749
INFO - 2022-07-04 07:25:59 --> Config Class Initialized
INFO - 2022-07-04 07:25:59 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:25:59 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:25:59 --> Utf8 Class Initialized
INFO - 2022-07-04 07:25:59 --> URI Class Initialized
INFO - 2022-07-04 07:25:59 --> Router Class Initialized
INFO - 2022-07-04 07:25:59 --> Output Class Initialized
INFO - 2022-07-04 07:25:59 --> Security Class Initialized
DEBUG - 2022-07-04 07:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:25:59 --> Input Class Initialized
INFO - 2022-07-04 07:25:59 --> Language Class Initialized
INFO - 2022-07-04 07:25:59 --> Language Class Initialized
INFO - 2022-07-04 07:25:59 --> Config Class Initialized
INFO - 2022-07-04 07:25:59 --> Loader Class Initialized
INFO - 2022-07-04 07:25:59 --> Helper loaded: url_helper
INFO - 2022-07-04 07:25:59 --> Helper loaded: file_helper
INFO - 2022-07-04 07:25:59 --> Helper loaded: form_helper
INFO - 2022-07-04 07:25:59 --> Helper loaded: my_helper
INFO - 2022-07-04 07:25:59 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:25:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:25:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:25:59 --> Controller Class Initialized
DEBUG - 2022-07-04 07:25:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-07-04 07:25:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 07:25:59 --> Final output sent to browser
DEBUG - 2022-07-04 07:25:59 --> Total execution time: 0.0457
INFO - 2022-07-04 07:26:11 --> Config Class Initialized
INFO - 2022-07-04 07:26:11 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:26:11 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:26:11 --> Utf8 Class Initialized
INFO - 2022-07-04 07:26:11 --> URI Class Initialized
INFO - 2022-07-04 07:26:11 --> Router Class Initialized
INFO - 2022-07-04 07:26:11 --> Output Class Initialized
INFO - 2022-07-04 07:26:11 --> Security Class Initialized
DEBUG - 2022-07-04 07:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:26:11 --> Input Class Initialized
INFO - 2022-07-04 07:26:11 --> Language Class Initialized
INFO - 2022-07-04 07:26:11 --> Language Class Initialized
INFO - 2022-07-04 07:26:11 --> Config Class Initialized
INFO - 2022-07-04 07:26:11 --> Loader Class Initialized
INFO - 2022-07-04 07:26:11 --> Helper loaded: url_helper
INFO - 2022-07-04 07:26:11 --> Helper loaded: file_helper
INFO - 2022-07-04 07:26:11 --> Helper loaded: form_helper
INFO - 2022-07-04 07:26:11 --> Helper loaded: my_helper
INFO - 2022-07-04 07:26:11 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:26:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:26:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:26:11 --> Controller Class Initialized
DEBUG - 2022-07-04 07:26:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-07-04 07:26:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 07:26:11 --> Final output sent to browser
DEBUG - 2022-07-04 07:26:11 --> Total execution time: 0.0494
INFO - 2022-07-04 07:26:11 --> Config Class Initialized
INFO - 2022-07-04 07:26:11 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:26:11 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:26:11 --> Utf8 Class Initialized
INFO - 2022-07-04 07:26:11 --> URI Class Initialized
INFO - 2022-07-04 07:26:11 --> Router Class Initialized
INFO - 2022-07-04 07:26:11 --> Output Class Initialized
INFO - 2022-07-04 07:26:11 --> Security Class Initialized
DEBUG - 2022-07-04 07:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:26:11 --> Input Class Initialized
INFO - 2022-07-04 07:26:11 --> Language Class Initialized
INFO - 2022-07-04 07:26:11 --> Language Class Initialized
INFO - 2022-07-04 07:26:11 --> Config Class Initialized
INFO - 2022-07-04 07:26:11 --> Loader Class Initialized
INFO - 2022-07-04 07:26:11 --> Helper loaded: url_helper
INFO - 2022-07-04 07:26:11 --> Helper loaded: file_helper
INFO - 2022-07-04 07:26:11 --> Helper loaded: form_helper
INFO - 2022-07-04 07:26:11 --> Helper loaded: my_helper
INFO - 2022-07-04 07:26:11 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:26:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:26:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:26:11 --> Controller Class Initialized
INFO - 2022-07-04 07:26:12 --> Config Class Initialized
INFO - 2022-07-04 07:26:12 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:26:12 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:26:12 --> Utf8 Class Initialized
INFO - 2022-07-04 07:26:12 --> URI Class Initialized
INFO - 2022-07-04 07:26:12 --> Router Class Initialized
INFO - 2022-07-04 07:26:12 --> Output Class Initialized
INFO - 2022-07-04 07:26:12 --> Security Class Initialized
DEBUG - 2022-07-04 07:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:26:12 --> Input Class Initialized
INFO - 2022-07-04 07:26:12 --> Language Class Initialized
INFO - 2022-07-04 07:26:12 --> Language Class Initialized
INFO - 2022-07-04 07:26:12 --> Config Class Initialized
INFO - 2022-07-04 07:26:12 --> Loader Class Initialized
INFO - 2022-07-04 07:26:12 --> Helper loaded: url_helper
INFO - 2022-07-04 07:26:12 --> Helper loaded: file_helper
INFO - 2022-07-04 07:26:12 --> Helper loaded: form_helper
INFO - 2022-07-04 07:26:12 --> Helper loaded: my_helper
INFO - 2022-07-04 07:26:12 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:26:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:26:12 --> Controller Class Initialized
DEBUG - 2022-07-04 07:26:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-07-04 07:26:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 07:26:12 --> Final output sent to browser
DEBUG - 2022-07-04 07:26:12 --> Total execution time: 0.0500
INFO - 2022-07-04 07:26:18 --> Config Class Initialized
INFO - 2022-07-04 07:26:18 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:26:18 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:26:18 --> Utf8 Class Initialized
INFO - 2022-07-04 07:26:18 --> URI Class Initialized
INFO - 2022-07-04 07:26:18 --> Router Class Initialized
INFO - 2022-07-04 07:26:18 --> Output Class Initialized
INFO - 2022-07-04 07:26:18 --> Security Class Initialized
DEBUG - 2022-07-04 07:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:26:18 --> Input Class Initialized
INFO - 2022-07-04 07:26:18 --> Language Class Initialized
INFO - 2022-07-04 07:26:18 --> Language Class Initialized
INFO - 2022-07-04 07:26:18 --> Config Class Initialized
INFO - 2022-07-04 07:26:18 --> Loader Class Initialized
INFO - 2022-07-04 07:26:18 --> Helper loaded: url_helper
INFO - 2022-07-04 07:26:18 --> Helper loaded: file_helper
INFO - 2022-07-04 07:26:18 --> Helper loaded: form_helper
INFO - 2022-07-04 07:26:18 --> Helper loaded: my_helper
INFO - 2022-07-04 07:26:18 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:26:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:26:18 --> Controller Class Initialized
INFO - 2022-07-04 07:26:19 --> Config Class Initialized
INFO - 2022-07-04 07:26:19 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:26:19 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:26:19 --> Utf8 Class Initialized
INFO - 2022-07-04 07:26:19 --> URI Class Initialized
INFO - 2022-07-04 07:26:19 --> Router Class Initialized
INFO - 2022-07-04 07:26:19 --> Output Class Initialized
INFO - 2022-07-04 07:26:19 --> Security Class Initialized
DEBUG - 2022-07-04 07:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:26:19 --> Input Class Initialized
INFO - 2022-07-04 07:26:19 --> Language Class Initialized
INFO - 2022-07-04 07:26:19 --> Language Class Initialized
INFO - 2022-07-04 07:26:19 --> Config Class Initialized
INFO - 2022-07-04 07:26:19 --> Loader Class Initialized
INFO - 2022-07-04 07:26:19 --> Helper loaded: url_helper
INFO - 2022-07-04 07:26:19 --> Helper loaded: file_helper
INFO - 2022-07-04 07:26:19 --> Helper loaded: form_helper
INFO - 2022-07-04 07:26:19 --> Helper loaded: my_helper
INFO - 2022-07-04 07:26:19 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:26:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:26:19 --> Controller Class Initialized
INFO - 2022-07-04 07:30:08 --> Config Class Initialized
INFO - 2022-07-04 07:30:08 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:30:08 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:30:08 --> Utf8 Class Initialized
INFO - 2022-07-04 07:30:08 --> URI Class Initialized
INFO - 2022-07-04 07:30:08 --> Router Class Initialized
INFO - 2022-07-04 07:30:08 --> Output Class Initialized
INFO - 2022-07-04 07:30:08 --> Security Class Initialized
DEBUG - 2022-07-04 07:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:30:08 --> Input Class Initialized
INFO - 2022-07-04 07:30:08 --> Language Class Initialized
INFO - 2022-07-04 07:30:08 --> Language Class Initialized
INFO - 2022-07-04 07:30:08 --> Config Class Initialized
INFO - 2022-07-04 07:30:08 --> Loader Class Initialized
INFO - 2022-07-04 07:30:08 --> Helper loaded: url_helper
INFO - 2022-07-04 07:30:08 --> Helper loaded: file_helper
INFO - 2022-07-04 07:30:08 --> Helper loaded: form_helper
INFO - 2022-07-04 07:30:08 --> Helper loaded: my_helper
INFO - 2022-07-04 07:30:08 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:30:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:30:08 --> Controller Class Initialized
DEBUG - 2022-07-04 07:30:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2022-07-04 07:30:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 07:30:08 --> Final output sent to browser
DEBUG - 2022-07-04 07:30:08 --> Total execution time: 0.0472
INFO - 2022-07-04 07:30:11 --> Config Class Initialized
INFO - 2022-07-04 07:30:11 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:30:11 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:30:11 --> Utf8 Class Initialized
INFO - 2022-07-04 07:30:11 --> URI Class Initialized
INFO - 2022-07-04 07:30:11 --> Router Class Initialized
INFO - 2022-07-04 07:30:11 --> Output Class Initialized
INFO - 2022-07-04 07:30:11 --> Security Class Initialized
DEBUG - 2022-07-04 07:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:30:11 --> Input Class Initialized
INFO - 2022-07-04 07:30:11 --> Language Class Initialized
INFO - 2022-07-04 07:30:11 --> Language Class Initialized
INFO - 2022-07-04 07:30:11 --> Config Class Initialized
INFO - 2022-07-04 07:30:11 --> Loader Class Initialized
INFO - 2022-07-04 07:30:11 --> Helper loaded: url_helper
INFO - 2022-07-04 07:30:11 --> Helper loaded: file_helper
INFO - 2022-07-04 07:30:11 --> Helper loaded: form_helper
INFO - 2022-07-04 07:30:11 --> Helper loaded: my_helper
INFO - 2022-07-04 07:30:11 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:30:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:30:11 --> Controller Class Initialized
INFO - 2022-07-04 07:30:11 --> Config Class Initialized
INFO - 2022-07-04 07:30:11 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:30:11 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:30:11 --> Utf8 Class Initialized
INFO - 2022-07-04 07:30:11 --> URI Class Initialized
INFO - 2022-07-04 07:30:11 --> Router Class Initialized
INFO - 2022-07-04 07:30:11 --> Output Class Initialized
INFO - 2022-07-04 07:30:11 --> Security Class Initialized
DEBUG - 2022-07-04 07:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:30:11 --> Input Class Initialized
INFO - 2022-07-04 07:30:11 --> Language Class Initialized
INFO - 2022-07-04 07:30:11 --> Language Class Initialized
INFO - 2022-07-04 07:30:11 --> Config Class Initialized
INFO - 2022-07-04 07:30:11 --> Loader Class Initialized
INFO - 2022-07-04 07:30:11 --> Helper loaded: url_helper
INFO - 2022-07-04 07:30:11 --> Helper loaded: file_helper
INFO - 2022-07-04 07:30:11 --> Helper loaded: form_helper
INFO - 2022-07-04 07:30:11 --> Helper loaded: my_helper
INFO - 2022-07-04 07:30:11 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:30:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:30:11 --> Controller Class Initialized
DEBUG - 2022-07-04 07:30:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-07-04 07:30:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 07:30:11 --> Final output sent to browser
DEBUG - 2022-07-04 07:30:11 --> Total execution time: 0.0673
INFO - 2022-07-04 07:30:11 --> Config Class Initialized
INFO - 2022-07-04 07:30:11 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:30:11 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:30:11 --> Utf8 Class Initialized
INFO - 2022-07-04 07:30:11 --> URI Class Initialized
INFO - 2022-07-04 07:30:11 --> Router Class Initialized
INFO - 2022-07-04 07:30:11 --> Output Class Initialized
INFO - 2022-07-04 07:30:11 --> Security Class Initialized
DEBUG - 2022-07-04 07:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:30:11 --> Input Class Initialized
INFO - 2022-07-04 07:30:11 --> Language Class Initialized
INFO - 2022-07-04 07:30:11 --> Language Class Initialized
INFO - 2022-07-04 07:30:11 --> Config Class Initialized
INFO - 2022-07-04 07:30:11 --> Loader Class Initialized
INFO - 2022-07-04 07:30:11 --> Helper loaded: url_helper
INFO - 2022-07-04 07:30:11 --> Helper loaded: file_helper
INFO - 2022-07-04 07:30:11 --> Helper loaded: form_helper
INFO - 2022-07-04 07:30:11 --> Helper loaded: my_helper
INFO - 2022-07-04 07:30:12 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:30:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:30:12 --> Controller Class Initialized
INFO - 2022-07-04 07:30:13 --> Config Class Initialized
INFO - 2022-07-04 07:30:13 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:30:13 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:30:13 --> Utf8 Class Initialized
INFO - 2022-07-04 07:30:13 --> URI Class Initialized
INFO - 2022-07-04 07:30:13 --> Router Class Initialized
INFO - 2022-07-04 07:30:13 --> Output Class Initialized
INFO - 2022-07-04 07:30:13 --> Security Class Initialized
DEBUG - 2022-07-04 07:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:30:13 --> Input Class Initialized
INFO - 2022-07-04 07:30:13 --> Language Class Initialized
INFO - 2022-07-04 07:30:13 --> Language Class Initialized
INFO - 2022-07-04 07:30:13 --> Config Class Initialized
INFO - 2022-07-04 07:30:13 --> Loader Class Initialized
INFO - 2022-07-04 07:30:13 --> Helper loaded: url_helper
INFO - 2022-07-04 07:30:13 --> Helper loaded: file_helper
INFO - 2022-07-04 07:30:13 --> Helper loaded: form_helper
INFO - 2022-07-04 07:30:13 --> Helper loaded: my_helper
INFO - 2022-07-04 07:30:13 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:30:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:30:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:30:13 --> Controller Class Initialized
DEBUG - 2022-07-04 07:30:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2022-07-04 07:30:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 07:30:13 --> Final output sent to browser
DEBUG - 2022-07-04 07:30:13 --> Total execution time: 0.0460
INFO - 2022-07-04 07:30:17 --> Config Class Initialized
INFO - 2022-07-04 07:30:17 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:30:17 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:30:17 --> Utf8 Class Initialized
INFO - 2022-07-04 07:30:17 --> URI Class Initialized
INFO - 2022-07-04 07:30:17 --> Router Class Initialized
INFO - 2022-07-04 07:30:17 --> Output Class Initialized
INFO - 2022-07-04 07:30:17 --> Security Class Initialized
DEBUG - 2022-07-04 07:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:30:17 --> Input Class Initialized
INFO - 2022-07-04 07:30:17 --> Language Class Initialized
INFO - 2022-07-04 07:30:17 --> Language Class Initialized
INFO - 2022-07-04 07:30:17 --> Config Class Initialized
INFO - 2022-07-04 07:30:17 --> Loader Class Initialized
INFO - 2022-07-04 07:30:17 --> Helper loaded: url_helper
INFO - 2022-07-04 07:30:17 --> Helper loaded: file_helper
INFO - 2022-07-04 07:30:17 --> Helper loaded: form_helper
INFO - 2022-07-04 07:30:17 --> Helper loaded: my_helper
INFO - 2022-07-04 07:30:17 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:30:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:30:17 --> Controller Class Initialized
INFO - 2022-07-04 07:30:17 --> Config Class Initialized
INFO - 2022-07-04 07:30:17 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:30:17 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:30:17 --> Utf8 Class Initialized
INFO - 2022-07-04 07:30:17 --> URI Class Initialized
INFO - 2022-07-04 07:30:17 --> Router Class Initialized
INFO - 2022-07-04 07:30:17 --> Output Class Initialized
INFO - 2022-07-04 07:30:17 --> Security Class Initialized
DEBUG - 2022-07-04 07:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:30:17 --> Input Class Initialized
INFO - 2022-07-04 07:30:17 --> Language Class Initialized
INFO - 2022-07-04 07:30:17 --> Language Class Initialized
INFO - 2022-07-04 07:30:17 --> Config Class Initialized
INFO - 2022-07-04 07:30:17 --> Loader Class Initialized
INFO - 2022-07-04 07:30:17 --> Helper loaded: url_helper
INFO - 2022-07-04 07:30:17 --> Helper loaded: file_helper
INFO - 2022-07-04 07:30:17 --> Helper loaded: form_helper
INFO - 2022-07-04 07:30:17 --> Helper loaded: my_helper
INFO - 2022-07-04 07:30:17 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:30:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:30:17 --> Controller Class Initialized
DEBUG - 2022-07-04 07:30:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-07-04 07:30:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 07:30:17 --> Final output sent to browser
DEBUG - 2022-07-04 07:30:17 --> Total execution time: 0.0659
INFO - 2022-07-04 07:30:20 --> Config Class Initialized
INFO - 2022-07-04 07:30:20 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:30:20 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:30:20 --> Utf8 Class Initialized
INFO - 2022-07-04 07:30:20 --> URI Class Initialized
INFO - 2022-07-04 07:30:20 --> Router Class Initialized
INFO - 2022-07-04 07:30:20 --> Output Class Initialized
INFO - 2022-07-04 07:30:20 --> Security Class Initialized
DEBUG - 2022-07-04 07:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:30:20 --> Input Class Initialized
INFO - 2022-07-04 07:30:20 --> Language Class Initialized
INFO - 2022-07-04 07:30:20 --> Language Class Initialized
INFO - 2022-07-04 07:30:20 --> Config Class Initialized
INFO - 2022-07-04 07:30:20 --> Loader Class Initialized
INFO - 2022-07-04 07:30:20 --> Helper loaded: url_helper
INFO - 2022-07-04 07:30:20 --> Helper loaded: file_helper
INFO - 2022-07-04 07:30:20 --> Helper loaded: form_helper
INFO - 2022-07-04 07:30:20 --> Helper loaded: my_helper
INFO - 2022-07-04 07:30:20 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:30:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:30:20 --> Controller Class Initialized
INFO - 2022-07-04 07:30:20 --> Helper loaded: cookie_helper
INFO - 2022-07-04 07:30:20 --> Config Class Initialized
INFO - 2022-07-04 07:30:20 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:30:20 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:30:20 --> Utf8 Class Initialized
INFO - 2022-07-04 07:30:20 --> URI Class Initialized
INFO - 2022-07-04 07:30:20 --> Router Class Initialized
INFO - 2022-07-04 07:30:20 --> Output Class Initialized
INFO - 2022-07-04 07:30:20 --> Security Class Initialized
DEBUG - 2022-07-04 07:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:30:20 --> Input Class Initialized
INFO - 2022-07-04 07:30:20 --> Language Class Initialized
INFO - 2022-07-04 07:30:20 --> Language Class Initialized
INFO - 2022-07-04 07:30:20 --> Config Class Initialized
INFO - 2022-07-04 07:30:20 --> Loader Class Initialized
INFO - 2022-07-04 07:30:20 --> Helper loaded: url_helper
INFO - 2022-07-04 07:30:20 --> Helper loaded: file_helper
INFO - 2022-07-04 07:30:20 --> Helper loaded: form_helper
INFO - 2022-07-04 07:30:20 --> Helper loaded: my_helper
INFO - 2022-07-04 07:30:20 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:30:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:30:20 --> Controller Class Initialized
DEBUG - 2022-07-04 07:30:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-07-04 07:30:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 07:30:20 --> Final output sent to browser
DEBUG - 2022-07-04 07:30:20 --> Total execution time: 0.0435
INFO - 2022-07-04 07:30:36 --> Config Class Initialized
INFO - 2022-07-04 07:30:36 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:30:36 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:30:36 --> Utf8 Class Initialized
INFO - 2022-07-04 07:30:36 --> URI Class Initialized
INFO - 2022-07-04 07:30:36 --> Router Class Initialized
INFO - 2022-07-04 07:30:36 --> Output Class Initialized
INFO - 2022-07-04 07:30:36 --> Security Class Initialized
DEBUG - 2022-07-04 07:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:30:36 --> Input Class Initialized
INFO - 2022-07-04 07:30:36 --> Language Class Initialized
INFO - 2022-07-04 07:30:36 --> Language Class Initialized
INFO - 2022-07-04 07:30:36 --> Config Class Initialized
INFO - 2022-07-04 07:30:36 --> Loader Class Initialized
INFO - 2022-07-04 07:30:36 --> Helper loaded: url_helper
INFO - 2022-07-04 07:30:36 --> Helper loaded: file_helper
INFO - 2022-07-04 07:30:36 --> Helper loaded: form_helper
INFO - 2022-07-04 07:30:36 --> Helper loaded: my_helper
INFO - 2022-07-04 07:30:36 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:30:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:30:36 --> Controller Class Initialized
INFO - 2022-07-04 07:30:36 --> Helper loaded: cookie_helper
INFO - 2022-07-04 07:30:36 --> Final output sent to browser
DEBUG - 2022-07-04 07:30:36 --> Total execution time: 0.0460
INFO - 2022-07-04 07:30:36 --> Config Class Initialized
INFO - 2022-07-04 07:30:36 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:30:36 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:30:36 --> Utf8 Class Initialized
INFO - 2022-07-04 07:30:36 --> URI Class Initialized
INFO - 2022-07-04 07:30:36 --> Router Class Initialized
INFO - 2022-07-04 07:30:36 --> Output Class Initialized
INFO - 2022-07-04 07:30:36 --> Security Class Initialized
DEBUG - 2022-07-04 07:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:30:36 --> Input Class Initialized
INFO - 2022-07-04 07:30:36 --> Language Class Initialized
INFO - 2022-07-04 07:30:36 --> Language Class Initialized
INFO - 2022-07-04 07:30:36 --> Config Class Initialized
INFO - 2022-07-04 07:30:36 --> Loader Class Initialized
INFO - 2022-07-04 07:30:36 --> Helper loaded: url_helper
INFO - 2022-07-04 07:30:36 --> Helper loaded: file_helper
INFO - 2022-07-04 07:30:36 --> Helper loaded: form_helper
INFO - 2022-07-04 07:30:36 --> Helper loaded: my_helper
INFO - 2022-07-04 07:30:36 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:30:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:30:36 --> Controller Class Initialized
DEBUG - 2022-07-04 07:30:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-07-04 07:30:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 07:30:36 --> Final output sent to browser
DEBUG - 2022-07-04 07:30:36 --> Total execution time: 0.5660
INFO - 2022-07-04 07:30:50 --> Config Class Initialized
INFO - 2022-07-04 07:30:50 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:30:50 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:30:50 --> Utf8 Class Initialized
INFO - 2022-07-04 07:30:50 --> URI Class Initialized
INFO - 2022-07-04 07:30:50 --> Router Class Initialized
INFO - 2022-07-04 07:30:50 --> Output Class Initialized
INFO - 2022-07-04 07:30:50 --> Security Class Initialized
DEBUG - 2022-07-04 07:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:30:50 --> Input Class Initialized
INFO - 2022-07-04 07:30:50 --> Language Class Initialized
INFO - 2022-07-04 07:30:50 --> Language Class Initialized
INFO - 2022-07-04 07:30:50 --> Config Class Initialized
INFO - 2022-07-04 07:30:50 --> Loader Class Initialized
INFO - 2022-07-04 07:30:50 --> Helper loaded: url_helper
INFO - 2022-07-04 07:30:50 --> Helper loaded: file_helper
INFO - 2022-07-04 07:30:50 --> Helper loaded: form_helper
INFO - 2022-07-04 07:30:50 --> Helper loaded: my_helper
INFO - 2022-07-04 07:30:50 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:30:50 --> Controller Class Initialized
DEBUG - 2022-07-04 07:30:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-07-04 07:30:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 07:30:50 --> Final output sent to browser
DEBUG - 2022-07-04 07:30:50 --> Total execution time: 0.0633
INFO - 2022-07-04 07:30:59 --> Config Class Initialized
INFO - 2022-07-04 07:30:59 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:30:59 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:30:59 --> Utf8 Class Initialized
INFO - 2022-07-04 07:30:59 --> URI Class Initialized
INFO - 2022-07-04 07:30:59 --> Router Class Initialized
INFO - 2022-07-04 07:30:59 --> Output Class Initialized
INFO - 2022-07-04 07:30:59 --> Security Class Initialized
DEBUG - 2022-07-04 07:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:30:59 --> Input Class Initialized
INFO - 2022-07-04 07:30:59 --> Language Class Initialized
INFO - 2022-07-04 07:30:59 --> Language Class Initialized
INFO - 2022-07-04 07:30:59 --> Config Class Initialized
INFO - 2022-07-04 07:30:59 --> Loader Class Initialized
INFO - 2022-07-04 07:30:59 --> Helper loaded: url_helper
INFO - 2022-07-04 07:30:59 --> Helper loaded: file_helper
INFO - 2022-07-04 07:30:59 --> Helper loaded: form_helper
INFO - 2022-07-04 07:30:59 --> Helper loaded: my_helper
INFO - 2022-07-04 07:30:59 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:30:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:30:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:30:59 --> Controller Class Initialized
DEBUG - 2022-07-04 07:30:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-07-04 07:30:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 07:30:59 --> Final output sent to browser
DEBUG - 2022-07-04 07:30:59 --> Total execution time: 0.0503
INFO - 2022-07-04 07:30:59 --> Config Class Initialized
INFO - 2022-07-04 07:30:59 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:30:59 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:30:59 --> Utf8 Class Initialized
INFO - 2022-07-04 07:30:59 --> URI Class Initialized
INFO - 2022-07-04 07:30:59 --> Router Class Initialized
INFO - 2022-07-04 07:30:59 --> Output Class Initialized
INFO - 2022-07-04 07:30:59 --> Security Class Initialized
DEBUG - 2022-07-04 07:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:30:59 --> Input Class Initialized
INFO - 2022-07-04 07:30:59 --> Language Class Initialized
INFO - 2022-07-04 07:30:59 --> Language Class Initialized
INFO - 2022-07-04 07:30:59 --> Config Class Initialized
INFO - 2022-07-04 07:30:59 --> Loader Class Initialized
INFO - 2022-07-04 07:30:59 --> Helper loaded: url_helper
INFO - 2022-07-04 07:30:59 --> Helper loaded: file_helper
INFO - 2022-07-04 07:30:59 --> Helper loaded: form_helper
INFO - 2022-07-04 07:30:59 --> Helper loaded: my_helper
INFO - 2022-07-04 07:30:59 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:30:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:30:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:30:59 --> Controller Class Initialized
INFO - 2022-07-04 07:31:00 --> Config Class Initialized
INFO - 2022-07-04 07:31:00 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:31:00 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:31:00 --> Utf8 Class Initialized
INFO - 2022-07-04 07:31:00 --> URI Class Initialized
INFO - 2022-07-04 07:31:00 --> Router Class Initialized
INFO - 2022-07-04 07:31:00 --> Output Class Initialized
INFO - 2022-07-04 07:31:00 --> Security Class Initialized
DEBUG - 2022-07-04 07:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:31:00 --> Input Class Initialized
INFO - 2022-07-04 07:31:00 --> Language Class Initialized
INFO - 2022-07-04 07:31:01 --> Language Class Initialized
INFO - 2022-07-04 07:31:01 --> Config Class Initialized
INFO - 2022-07-04 07:31:01 --> Loader Class Initialized
INFO - 2022-07-04 07:31:01 --> Helper loaded: url_helper
INFO - 2022-07-04 07:31:01 --> Helper loaded: file_helper
INFO - 2022-07-04 07:31:01 --> Helper loaded: form_helper
INFO - 2022-07-04 07:31:01 --> Helper loaded: my_helper
INFO - 2022-07-04 07:31:01 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:31:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:31:01 --> Controller Class Initialized
DEBUG - 2022-07-04 07:31:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-07-04 07:31:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 07:31:01 --> Final output sent to browser
DEBUG - 2022-07-04 07:31:01 --> Total execution time: 0.0484
INFO - 2022-07-04 07:31:02 --> Config Class Initialized
INFO - 2022-07-04 07:31:02 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:31:02 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:31:02 --> Utf8 Class Initialized
INFO - 2022-07-04 07:31:02 --> URI Class Initialized
INFO - 2022-07-04 07:31:02 --> Router Class Initialized
INFO - 2022-07-04 07:31:02 --> Output Class Initialized
INFO - 2022-07-04 07:31:02 --> Security Class Initialized
DEBUG - 2022-07-04 07:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:31:02 --> Input Class Initialized
INFO - 2022-07-04 07:31:02 --> Language Class Initialized
INFO - 2022-07-04 07:31:02 --> Language Class Initialized
INFO - 2022-07-04 07:31:02 --> Config Class Initialized
INFO - 2022-07-04 07:31:02 --> Loader Class Initialized
INFO - 2022-07-04 07:31:02 --> Helper loaded: url_helper
INFO - 2022-07-04 07:31:02 --> Helper loaded: file_helper
INFO - 2022-07-04 07:31:02 --> Helper loaded: form_helper
INFO - 2022-07-04 07:31:02 --> Helper loaded: my_helper
INFO - 2022-07-04 07:31:02 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:31:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:31:02 --> Controller Class Initialized
INFO - 2022-07-04 07:31:04 --> Config Class Initialized
INFO - 2022-07-04 07:31:04 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:31:04 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:31:04 --> Utf8 Class Initialized
INFO - 2022-07-04 07:31:04 --> URI Class Initialized
INFO - 2022-07-04 07:31:04 --> Router Class Initialized
INFO - 2022-07-04 07:31:04 --> Output Class Initialized
INFO - 2022-07-04 07:31:04 --> Security Class Initialized
DEBUG - 2022-07-04 07:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:31:04 --> Input Class Initialized
INFO - 2022-07-04 07:31:04 --> Language Class Initialized
INFO - 2022-07-04 07:31:04 --> Language Class Initialized
INFO - 2022-07-04 07:31:04 --> Config Class Initialized
INFO - 2022-07-04 07:31:04 --> Loader Class Initialized
INFO - 2022-07-04 07:31:04 --> Helper loaded: url_helper
INFO - 2022-07-04 07:31:04 --> Helper loaded: file_helper
INFO - 2022-07-04 07:31:04 --> Helper loaded: form_helper
INFO - 2022-07-04 07:31:04 --> Helper loaded: my_helper
INFO - 2022-07-04 07:31:04 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:31:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:31:04 --> Controller Class Initialized
INFO - 2022-07-04 07:32:24 --> Config Class Initialized
INFO - 2022-07-04 07:32:24 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:32:24 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:32:24 --> Utf8 Class Initialized
INFO - 2022-07-04 07:32:24 --> URI Class Initialized
INFO - 2022-07-04 07:32:24 --> Router Class Initialized
INFO - 2022-07-04 07:32:24 --> Output Class Initialized
INFO - 2022-07-04 07:32:24 --> Security Class Initialized
DEBUG - 2022-07-04 07:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:32:24 --> Input Class Initialized
INFO - 2022-07-04 07:32:24 --> Language Class Initialized
INFO - 2022-07-04 07:32:24 --> Language Class Initialized
INFO - 2022-07-04 07:32:24 --> Config Class Initialized
INFO - 2022-07-04 07:32:24 --> Loader Class Initialized
INFO - 2022-07-04 07:32:24 --> Helper loaded: url_helper
INFO - 2022-07-04 07:32:24 --> Helper loaded: file_helper
INFO - 2022-07-04 07:32:24 --> Helper loaded: form_helper
INFO - 2022-07-04 07:32:24 --> Helper loaded: my_helper
INFO - 2022-07-04 07:32:24 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:32:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:32:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:32:24 --> Controller Class Initialized
DEBUG - 2022-07-04 07:32:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2022-07-04 07:32:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 07:32:24 --> Final output sent to browser
DEBUG - 2022-07-04 07:32:24 --> Total execution time: 0.0515
INFO - 2022-07-04 07:32:28 --> Config Class Initialized
INFO - 2022-07-04 07:32:28 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:32:28 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:32:28 --> Utf8 Class Initialized
INFO - 2022-07-04 07:32:28 --> URI Class Initialized
INFO - 2022-07-04 07:32:28 --> Router Class Initialized
INFO - 2022-07-04 07:32:28 --> Output Class Initialized
INFO - 2022-07-04 07:32:28 --> Security Class Initialized
DEBUG - 2022-07-04 07:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:32:28 --> Input Class Initialized
INFO - 2022-07-04 07:32:28 --> Language Class Initialized
INFO - 2022-07-04 07:32:28 --> Language Class Initialized
INFO - 2022-07-04 07:32:28 --> Config Class Initialized
INFO - 2022-07-04 07:32:28 --> Loader Class Initialized
INFO - 2022-07-04 07:32:28 --> Helper loaded: url_helper
INFO - 2022-07-04 07:32:28 --> Helper loaded: file_helper
INFO - 2022-07-04 07:32:28 --> Helper loaded: form_helper
INFO - 2022-07-04 07:32:28 --> Helper loaded: my_helper
INFO - 2022-07-04 07:32:28 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:32:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:32:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:32:28 --> Controller Class Initialized
INFO - 2022-07-04 07:32:29 --> Config Class Initialized
INFO - 2022-07-04 07:32:29 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:32:29 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:32:29 --> Utf8 Class Initialized
INFO - 2022-07-04 07:32:29 --> URI Class Initialized
INFO - 2022-07-04 07:32:29 --> Router Class Initialized
INFO - 2022-07-04 07:32:29 --> Output Class Initialized
INFO - 2022-07-04 07:32:29 --> Security Class Initialized
DEBUG - 2022-07-04 07:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:32:29 --> Input Class Initialized
INFO - 2022-07-04 07:32:29 --> Language Class Initialized
INFO - 2022-07-04 07:32:29 --> Language Class Initialized
INFO - 2022-07-04 07:32:29 --> Config Class Initialized
INFO - 2022-07-04 07:32:29 --> Loader Class Initialized
INFO - 2022-07-04 07:32:29 --> Helper loaded: url_helper
INFO - 2022-07-04 07:32:29 --> Helper loaded: file_helper
INFO - 2022-07-04 07:32:29 --> Helper loaded: form_helper
INFO - 2022-07-04 07:32:29 --> Helper loaded: my_helper
INFO - 2022-07-04 07:32:29 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:32:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:32:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:32:29 --> Controller Class Initialized
DEBUG - 2022-07-04 07:32:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-07-04 07:32:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 07:32:29 --> Final output sent to browser
DEBUG - 2022-07-04 07:32:29 --> Total execution time: 0.0479
INFO - 2022-07-04 07:32:29 --> Config Class Initialized
INFO - 2022-07-04 07:32:29 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:32:29 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:32:29 --> Utf8 Class Initialized
INFO - 2022-07-04 07:32:29 --> URI Class Initialized
INFO - 2022-07-04 07:32:29 --> Router Class Initialized
INFO - 2022-07-04 07:32:29 --> Output Class Initialized
INFO - 2022-07-04 07:32:29 --> Security Class Initialized
DEBUG - 2022-07-04 07:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:32:29 --> Input Class Initialized
INFO - 2022-07-04 07:32:29 --> Language Class Initialized
INFO - 2022-07-04 07:32:29 --> Language Class Initialized
INFO - 2022-07-04 07:32:29 --> Config Class Initialized
INFO - 2022-07-04 07:32:29 --> Loader Class Initialized
INFO - 2022-07-04 07:32:29 --> Helper loaded: url_helper
INFO - 2022-07-04 07:32:29 --> Helper loaded: file_helper
INFO - 2022-07-04 07:32:29 --> Helper loaded: form_helper
INFO - 2022-07-04 07:32:29 --> Helper loaded: my_helper
INFO - 2022-07-04 07:32:29 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:32:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:32:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:32:29 --> Controller Class Initialized
INFO - 2022-07-04 07:32:30 --> Config Class Initialized
INFO - 2022-07-04 07:32:30 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:32:30 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:32:30 --> Utf8 Class Initialized
INFO - 2022-07-04 07:32:30 --> URI Class Initialized
INFO - 2022-07-04 07:32:30 --> Router Class Initialized
INFO - 2022-07-04 07:32:30 --> Output Class Initialized
INFO - 2022-07-04 07:32:30 --> Security Class Initialized
DEBUG - 2022-07-04 07:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:32:30 --> Input Class Initialized
INFO - 2022-07-04 07:32:30 --> Language Class Initialized
INFO - 2022-07-04 07:32:30 --> Language Class Initialized
INFO - 2022-07-04 07:32:30 --> Config Class Initialized
INFO - 2022-07-04 07:32:30 --> Loader Class Initialized
INFO - 2022-07-04 07:32:30 --> Helper loaded: url_helper
INFO - 2022-07-04 07:32:30 --> Helper loaded: file_helper
INFO - 2022-07-04 07:32:30 --> Helper loaded: form_helper
INFO - 2022-07-04 07:32:30 --> Helper loaded: my_helper
INFO - 2022-07-04 07:32:30 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:32:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:32:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:32:30 --> Controller Class Initialized
DEBUG - 2022-07-04 07:32:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2022-07-04 07:32:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 07:32:30 --> Final output sent to browser
DEBUG - 2022-07-04 07:32:30 --> Total execution time: 0.0599
INFO - 2022-07-04 07:32:33 --> Config Class Initialized
INFO - 2022-07-04 07:32:33 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:32:33 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:32:33 --> Utf8 Class Initialized
INFO - 2022-07-04 07:32:33 --> URI Class Initialized
INFO - 2022-07-04 07:32:33 --> Router Class Initialized
INFO - 2022-07-04 07:32:33 --> Output Class Initialized
INFO - 2022-07-04 07:32:33 --> Security Class Initialized
DEBUG - 2022-07-04 07:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:32:33 --> Input Class Initialized
INFO - 2022-07-04 07:32:33 --> Language Class Initialized
INFO - 2022-07-04 07:32:33 --> Language Class Initialized
INFO - 2022-07-04 07:32:33 --> Config Class Initialized
INFO - 2022-07-04 07:32:33 --> Loader Class Initialized
INFO - 2022-07-04 07:32:33 --> Helper loaded: url_helper
INFO - 2022-07-04 07:32:33 --> Helper loaded: file_helper
INFO - 2022-07-04 07:32:33 --> Helper loaded: form_helper
INFO - 2022-07-04 07:32:33 --> Helper loaded: my_helper
INFO - 2022-07-04 07:32:33 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:32:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:32:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:32:33 --> Controller Class Initialized
INFO - 2022-07-04 07:32:33 --> Config Class Initialized
INFO - 2022-07-04 07:32:33 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:32:33 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:32:33 --> Utf8 Class Initialized
INFO - 2022-07-04 07:32:33 --> URI Class Initialized
INFO - 2022-07-04 07:32:33 --> Router Class Initialized
INFO - 2022-07-04 07:32:33 --> Output Class Initialized
INFO - 2022-07-04 07:32:33 --> Security Class Initialized
DEBUG - 2022-07-04 07:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:32:33 --> Input Class Initialized
INFO - 2022-07-04 07:32:33 --> Language Class Initialized
INFO - 2022-07-04 07:32:33 --> Language Class Initialized
INFO - 2022-07-04 07:32:33 --> Config Class Initialized
INFO - 2022-07-04 07:32:33 --> Loader Class Initialized
INFO - 2022-07-04 07:32:33 --> Helper loaded: url_helper
INFO - 2022-07-04 07:32:33 --> Helper loaded: file_helper
INFO - 2022-07-04 07:32:33 --> Helper loaded: form_helper
INFO - 2022-07-04 07:32:33 --> Helper loaded: my_helper
INFO - 2022-07-04 07:32:33 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:32:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:32:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:32:33 --> Controller Class Initialized
DEBUG - 2022-07-04 07:32:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-07-04 07:32:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 07:32:33 --> Final output sent to browser
DEBUG - 2022-07-04 07:32:33 --> Total execution time: 0.0656
INFO - 2022-07-04 07:32:51 --> Config Class Initialized
INFO - 2022-07-04 07:32:51 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:32:51 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:32:51 --> Utf8 Class Initialized
INFO - 2022-07-04 07:32:51 --> URI Class Initialized
INFO - 2022-07-04 07:32:51 --> Router Class Initialized
INFO - 2022-07-04 07:32:51 --> Output Class Initialized
INFO - 2022-07-04 07:32:51 --> Security Class Initialized
DEBUG - 2022-07-04 07:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:32:51 --> Input Class Initialized
INFO - 2022-07-04 07:32:51 --> Language Class Initialized
INFO - 2022-07-04 07:32:51 --> Language Class Initialized
INFO - 2022-07-04 07:32:51 --> Config Class Initialized
INFO - 2022-07-04 07:32:51 --> Loader Class Initialized
INFO - 2022-07-04 07:32:51 --> Helper loaded: url_helper
INFO - 2022-07-04 07:32:51 --> Helper loaded: file_helper
INFO - 2022-07-04 07:32:51 --> Helper loaded: form_helper
INFO - 2022-07-04 07:32:51 --> Helper loaded: my_helper
INFO - 2022-07-04 07:32:51 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:32:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:32:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:32:51 --> Controller Class Initialized
INFO - 2022-07-04 07:32:51 --> Helper loaded: cookie_helper
INFO - 2022-07-04 07:32:51 --> Config Class Initialized
INFO - 2022-07-04 07:32:51 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:32:51 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:32:51 --> Utf8 Class Initialized
INFO - 2022-07-04 07:32:51 --> URI Class Initialized
INFO - 2022-07-04 07:32:51 --> Router Class Initialized
INFO - 2022-07-04 07:32:51 --> Output Class Initialized
INFO - 2022-07-04 07:32:51 --> Security Class Initialized
DEBUG - 2022-07-04 07:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:32:51 --> Input Class Initialized
INFO - 2022-07-04 07:32:51 --> Language Class Initialized
INFO - 2022-07-04 07:32:51 --> Language Class Initialized
INFO - 2022-07-04 07:32:51 --> Config Class Initialized
INFO - 2022-07-04 07:32:51 --> Loader Class Initialized
INFO - 2022-07-04 07:32:51 --> Helper loaded: url_helper
INFO - 2022-07-04 07:32:51 --> Helper loaded: file_helper
INFO - 2022-07-04 07:32:51 --> Helper loaded: form_helper
INFO - 2022-07-04 07:32:51 --> Helper loaded: my_helper
INFO - 2022-07-04 07:32:51 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:32:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:32:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:32:51 --> Controller Class Initialized
DEBUG - 2022-07-04 07:32:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-07-04 07:32:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 07:32:51 --> Final output sent to browser
DEBUG - 2022-07-04 07:32:51 --> Total execution time: 0.0486
INFO - 2022-07-04 07:32:51 --> Config Class Initialized
INFO - 2022-07-04 07:32:51 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:32:51 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:32:51 --> Utf8 Class Initialized
INFO - 2022-07-04 07:32:51 --> URI Class Initialized
INFO - 2022-07-04 07:32:51 --> Router Class Initialized
INFO - 2022-07-04 07:32:51 --> Output Class Initialized
INFO - 2022-07-04 07:32:51 --> Security Class Initialized
DEBUG - 2022-07-04 07:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:32:51 --> Input Class Initialized
INFO - 2022-07-04 07:32:51 --> Language Class Initialized
INFO - 2022-07-04 07:32:51 --> Language Class Initialized
INFO - 2022-07-04 07:32:51 --> Config Class Initialized
INFO - 2022-07-04 07:32:51 --> Loader Class Initialized
INFO - 2022-07-04 07:32:51 --> Helper loaded: url_helper
INFO - 2022-07-04 07:32:51 --> Helper loaded: file_helper
INFO - 2022-07-04 07:32:51 --> Helper loaded: form_helper
INFO - 2022-07-04 07:32:51 --> Helper loaded: my_helper
INFO - 2022-07-04 07:32:51 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:32:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:32:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:32:51 --> Controller Class Initialized
INFO - 2022-07-04 07:32:51 --> Helper loaded: cookie_helper
INFO - 2022-07-04 07:32:51 --> Config Class Initialized
INFO - 2022-07-04 07:32:51 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:32:51 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:32:51 --> Utf8 Class Initialized
INFO - 2022-07-04 07:32:51 --> URI Class Initialized
INFO - 2022-07-04 07:32:51 --> Router Class Initialized
INFO - 2022-07-04 07:32:51 --> Output Class Initialized
INFO - 2022-07-04 07:32:51 --> Security Class Initialized
DEBUG - 2022-07-04 07:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:32:51 --> Input Class Initialized
INFO - 2022-07-04 07:32:51 --> Language Class Initialized
INFO - 2022-07-04 07:32:51 --> Language Class Initialized
INFO - 2022-07-04 07:32:51 --> Config Class Initialized
INFO - 2022-07-04 07:32:51 --> Loader Class Initialized
INFO - 2022-07-04 07:32:51 --> Helper loaded: url_helper
INFO - 2022-07-04 07:32:51 --> Helper loaded: file_helper
INFO - 2022-07-04 07:32:51 --> Helper loaded: form_helper
INFO - 2022-07-04 07:32:51 --> Helper loaded: my_helper
INFO - 2022-07-04 07:32:51 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:32:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:32:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:32:51 --> Controller Class Initialized
DEBUG - 2022-07-04 07:32:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-07-04 07:32:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 07:32:51 --> Final output sent to browser
DEBUG - 2022-07-04 07:32:51 --> Total execution time: 0.0419
INFO - 2022-07-04 07:32:55 --> Config Class Initialized
INFO - 2022-07-04 07:32:55 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:32:55 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:32:55 --> Utf8 Class Initialized
INFO - 2022-07-04 07:32:55 --> URI Class Initialized
INFO - 2022-07-04 07:32:55 --> Router Class Initialized
INFO - 2022-07-04 07:32:55 --> Output Class Initialized
INFO - 2022-07-04 07:32:55 --> Security Class Initialized
DEBUG - 2022-07-04 07:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:32:55 --> Input Class Initialized
INFO - 2022-07-04 07:32:55 --> Language Class Initialized
INFO - 2022-07-04 07:32:55 --> Language Class Initialized
INFO - 2022-07-04 07:32:55 --> Config Class Initialized
INFO - 2022-07-04 07:32:55 --> Loader Class Initialized
INFO - 2022-07-04 07:32:55 --> Helper loaded: url_helper
INFO - 2022-07-04 07:32:55 --> Helper loaded: file_helper
INFO - 2022-07-04 07:32:55 --> Helper loaded: form_helper
INFO - 2022-07-04 07:32:55 --> Helper loaded: my_helper
INFO - 2022-07-04 07:32:55 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:32:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:32:55 --> Controller Class Initialized
INFO - 2022-07-04 07:32:55 --> Helper loaded: cookie_helper
INFO - 2022-07-04 07:32:55 --> Final output sent to browser
DEBUG - 2022-07-04 07:32:55 --> Total execution time: 0.0559
INFO - 2022-07-04 07:32:55 --> Config Class Initialized
INFO - 2022-07-04 07:32:55 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:32:55 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:32:55 --> Utf8 Class Initialized
INFO - 2022-07-04 07:32:55 --> URI Class Initialized
INFO - 2022-07-04 07:32:55 --> Router Class Initialized
INFO - 2022-07-04 07:32:55 --> Output Class Initialized
INFO - 2022-07-04 07:32:55 --> Security Class Initialized
DEBUG - 2022-07-04 07:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:32:55 --> Input Class Initialized
INFO - 2022-07-04 07:32:55 --> Language Class Initialized
INFO - 2022-07-04 07:32:55 --> Language Class Initialized
INFO - 2022-07-04 07:32:55 --> Config Class Initialized
INFO - 2022-07-04 07:32:55 --> Loader Class Initialized
INFO - 2022-07-04 07:32:55 --> Helper loaded: url_helper
INFO - 2022-07-04 07:32:55 --> Helper loaded: file_helper
INFO - 2022-07-04 07:32:55 --> Helper loaded: form_helper
INFO - 2022-07-04 07:32:55 --> Helper loaded: my_helper
INFO - 2022-07-04 07:32:55 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:32:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:32:55 --> Controller Class Initialized
DEBUG - 2022-07-04 07:32:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-07-04 07:32:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 07:32:55 --> Final output sent to browser
DEBUG - 2022-07-04 07:32:55 --> Total execution time: 0.5661
INFO - 2022-07-04 07:33:01 --> Config Class Initialized
INFO - 2022-07-04 07:33:01 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:33:01 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:33:01 --> Utf8 Class Initialized
INFO - 2022-07-04 07:33:01 --> URI Class Initialized
INFO - 2022-07-04 07:33:01 --> Router Class Initialized
INFO - 2022-07-04 07:33:01 --> Output Class Initialized
INFO - 2022-07-04 07:33:01 --> Security Class Initialized
DEBUG - 2022-07-04 07:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:33:01 --> Input Class Initialized
INFO - 2022-07-04 07:33:01 --> Language Class Initialized
INFO - 2022-07-04 07:33:01 --> Language Class Initialized
INFO - 2022-07-04 07:33:01 --> Config Class Initialized
INFO - 2022-07-04 07:33:01 --> Loader Class Initialized
INFO - 2022-07-04 07:33:01 --> Helper loaded: url_helper
INFO - 2022-07-04 07:33:01 --> Helper loaded: file_helper
INFO - 2022-07-04 07:33:01 --> Helper loaded: form_helper
INFO - 2022-07-04 07:33:01 --> Helper loaded: my_helper
INFO - 2022-07-04 07:33:01 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:33:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:33:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:33:01 --> Controller Class Initialized
DEBUG - 2022-07-04 07:33:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-07-04 07:33:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 07:33:01 --> Final output sent to browser
DEBUG - 2022-07-04 07:33:01 --> Total execution time: 0.0469
INFO - 2022-07-04 07:33:05 --> Config Class Initialized
INFO - 2022-07-04 07:33:05 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:33:05 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:33:05 --> Utf8 Class Initialized
INFO - 2022-07-04 07:33:05 --> URI Class Initialized
INFO - 2022-07-04 07:33:05 --> Router Class Initialized
INFO - 2022-07-04 07:33:05 --> Output Class Initialized
INFO - 2022-07-04 07:33:05 --> Security Class Initialized
DEBUG - 2022-07-04 07:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:33:05 --> Input Class Initialized
INFO - 2022-07-04 07:33:05 --> Language Class Initialized
INFO - 2022-07-04 07:33:05 --> Language Class Initialized
INFO - 2022-07-04 07:33:05 --> Config Class Initialized
INFO - 2022-07-04 07:33:05 --> Loader Class Initialized
INFO - 2022-07-04 07:33:05 --> Helper loaded: url_helper
INFO - 2022-07-04 07:33:05 --> Helper loaded: file_helper
INFO - 2022-07-04 07:33:05 --> Helper loaded: form_helper
INFO - 2022-07-04 07:33:05 --> Helper loaded: my_helper
INFO - 2022-07-04 07:33:05 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:33:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:33:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:33:05 --> Controller Class Initialized
DEBUG - 2022-07-04 07:33:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-07-04 07:33:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 07:33:05 --> Final output sent to browser
DEBUG - 2022-07-04 07:33:05 --> Total execution time: 0.0499
INFO - 2022-07-04 07:33:05 --> Config Class Initialized
INFO - 2022-07-04 07:33:05 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:33:05 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:33:05 --> Utf8 Class Initialized
INFO - 2022-07-04 07:33:05 --> URI Class Initialized
INFO - 2022-07-04 07:33:05 --> Router Class Initialized
INFO - 2022-07-04 07:33:05 --> Output Class Initialized
INFO - 2022-07-04 07:33:05 --> Security Class Initialized
DEBUG - 2022-07-04 07:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:33:05 --> Input Class Initialized
INFO - 2022-07-04 07:33:05 --> Language Class Initialized
INFO - 2022-07-04 07:33:05 --> Language Class Initialized
INFO - 2022-07-04 07:33:05 --> Config Class Initialized
INFO - 2022-07-04 07:33:05 --> Loader Class Initialized
INFO - 2022-07-04 07:33:05 --> Helper loaded: url_helper
INFO - 2022-07-04 07:33:05 --> Helper loaded: file_helper
INFO - 2022-07-04 07:33:05 --> Helper loaded: form_helper
INFO - 2022-07-04 07:33:05 --> Helper loaded: my_helper
INFO - 2022-07-04 07:33:05 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:33:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:33:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:33:05 --> Controller Class Initialized
INFO - 2022-07-04 07:33:06 --> Config Class Initialized
INFO - 2022-07-04 07:33:06 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:33:06 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:33:06 --> Utf8 Class Initialized
INFO - 2022-07-04 07:33:06 --> URI Class Initialized
INFO - 2022-07-04 07:33:06 --> Router Class Initialized
INFO - 2022-07-04 07:33:06 --> Output Class Initialized
INFO - 2022-07-04 07:33:06 --> Security Class Initialized
DEBUG - 2022-07-04 07:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:33:06 --> Input Class Initialized
INFO - 2022-07-04 07:33:06 --> Language Class Initialized
INFO - 2022-07-04 07:33:06 --> Language Class Initialized
INFO - 2022-07-04 07:33:06 --> Config Class Initialized
INFO - 2022-07-04 07:33:06 --> Loader Class Initialized
INFO - 2022-07-04 07:33:06 --> Helper loaded: url_helper
INFO - 2022-07-04 07:33:06 --> Helper loaded: file_helper
INFO - 2022-07-04 07:33:06 --> Helper loaded: form_helper
INFO - 2022-07-04 07:33:06 --> Helper loaded: my_helper
INFO - 2022-07-04 07:33:06 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:33:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:33:06 --> Controller Class Initialized
DEBUG - 2022-07-04 07:33:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-07-04 07:33:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 07:33:06 --> Final output sent to browser
DEBUG - 2022-07-04 07:33:06 --> Total execution time: 0.0484
INFO - 2022-07-04 07:34:14 --> Config Class Initialized
INFO - 2022-07-04 07:34:14 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:34:14 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:34:14 --> Utf8 Class Initialized
INFO - 2022-07-04 07:34:14 --> URI Class Initialized
INFO - 2022-07-04 07:34:14 --> Router Class Initialized
INFO - 2022-07-04 07:34:14 --> Output Class Initialized
INFO - 2022-07-04 07:34:14 --> Security Class Initialized
DEBUG - 2022-07-04 07:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:34:14 --> Input Class Initialized
INFO - 2022-07-04 07:34:14 --> Language Class Initialized
INFO - 2022-07-04 07:34:14 --> Language Class Initialized
INFO - 2022-07-04 07:34:14 --> Config Class Initialized
INFO - 2022-07-04 07:34:14 --> Loader Class Initialized
INFO - 2022-07-04 07:34:14 --> Helper loaded: url_helper
INFO - 2022-07-04 07:34:14 --> Helper loaded: file_helper
INFO - 2022-07-04 07:34:14 --> Helper loaded: form_helper
INFO - 2022-07-04 07:34:14 --> Helper loaded: my_helper
INFO - 2022-07-04 07:34:14 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:34:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:34:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:34:14 --> Controller Class Initialized
INFO - 2022-07-04 07:34:16 --> Config Class Initialized
INFO - 2022-07-04 07:34:16 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:34:16 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:34:16 --> Utf8 Class Initialized
INFO - 2022-07-04 07:34:16 --> URI Class Initialized
INFO - 2022-07-04 07:34:16 --> Router Class Initialized
INFO - 2022-07-04 07:34:16 --> Output Class Initialized
INFO - 2022-07-04 07:34:16 --> Security Class Initialized
DEBUG - 2022-07-04 07:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:34:16 --> Input Class Initialized
INFO - 2022-07-04 07:34:16 --> Language Class Initialized
INFO - 2022-07-04 07:34:16 --> Language Class Initialized
INFO - 2022-07-04 07:34:16 --> Config Class Initialized
INFO - 2022-07-04 07:34:16 --> Loader Class Initialized
INFO - 2022-07-04 07:34:16 --> Helper loaded: url_helper
INFO - 2022-07-04 07:34:16 --> Helper loaded: file_helper
INFO - 2022-07-04 07:34:16 --> Helper loaded: form_helper
INFO - 2022-07-04 07:34:16 --> Helper loaded: my_helper
INFO - 2022-07-04 07:34:16 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:34:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:34:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:34:16 --> Controller Class Initialized
INFO - 2022-07-04 07:38:24 --> Config Class Initialized
INFO - 2022-07-04 07:38:24 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:38:24 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:38:24 --> Utf8 Class Initialized
INFO - 2022-07-04 07:38:24 --> URI Class Initialized
INFO - 2022-07-04 07:38:24 --> Router Class Initialized
INFO - 2022-07-04 07:38:24 --> Output Class Initialized
INFO - 2022-07-04 07:38:24 --> Security Class Initialized
DEBUG - 2022-07-04 07:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:38:24 --> Input Class Initialized
INFO - 2022-07-04 07:38:24 --> Language Class Initialized
INFO - 2022-07-04 07:38:24 --> Language Class Initialized
INFO - 2022-07-04 07:38:24 --> Config Class Initialized
INFO - 2022-07-04 07:38:24 --> Loader Class Initialized
INFO - 2022-07-04 07:38:24 --> Helper loaded: url_helper
INFO - 2022-07-04 07:38:24 --> Helper loaded: file_helper
INFO - 2022-07-04 07:38:24 --> Helper loaded: form_helper
INFO - 2022-07-04 07:38:24 --> Helper loaded: my_helper
INFO - 2022-07-04 07:38:24 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:38:24 --> Controller Class Initialized
DEBUG - 2022-07-04 07:38:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2022-07-04 07:38:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 07:38:24 --> Final output sent to browser
DEBUG - 2022-07-04 07:38:24 --> Total execution time: 0.0483
INFO - 2022-07-04 07:38:28 --> Config Class Initialized
INFO - 2022-07-04 07:38:28 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:38:28 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:38:28 --> Utf8 Class Initialized
INFO - 2022-07-04 07:38:28 --> URI Class Initialized
INFO - 2022-07-04 07:38:28 --> Router Class Initialized
INFO - 2022-07-04 07:38:28 --> Output Class Initialized
INFO - 2022-07-04 07:38:28 --> Security Class Initialized
DEBUG - 2022-07-04 07:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:38:28 --> Input Class Initialized
INFO - 2022-07-04 07:38:28 --> Language Class Initialized
INFO - 2022-07-04 07:38:28 --> Language Class Initialized
INFO - 2022-07-04 07:38:28 --> Config Class Initialized
INFO - 2022-07-04 07:38:28 --> Loader Class Initialized
INFO - 2022-07-04 07:38:28 --> Helper loaded: url_helper
INFO - 2022-07-04 07:38:28 --> Helper loaded: file_helper
INFO - 2022-07-04 07:38:28 --> Helper loaded: form_helper
INFO - 2022-07-04 07:38:28 --> Helper loaded: my_helper
INFO - 2022-07-04 07:38:28 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:38:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:38:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:38:28 --> Controller Class Initialized
INFO - 2022-07-04 07:38:28 --> Config Class Initialized
INFO - 2022-07-04 07:38:28 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:38:28 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:38:28 --> Utf8 Class Initialized
INFO - 2022-07-04 07:38:28 --> URI Class Initialized
INFO - 2022-07-04 07:38:28 --> Router Class Initialized
INFO - 2022-07-04 07:38:28 --> Output Class Initialized
INFO - 2022-07-04 07:38:28 --> Security Class Initialized
DEBUG - 2022-07-04 07:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:38:28 --> Input Class Initialized
INFO - 2022-07-04 07:38:28 --> Language Class Initialized
INFO - 2022-07-04 07:38:28 --> Language Class Initialized
INFO - 2022-07-04 07:38:28 --> Config Class Initialized
INFO - 2022-07-04 07:38:28 --> Loader Class Initialized
INFO - 2022-07-04 07:38:28 --> Helper loaded: url_helper
INFO - 2022-07-04 07:38:28 --> Helper loaded: file_helper
INFO - 2022-07-04 07:38:28 --> Helper loaded: form_helper
INFO - 2022-07-04 07:38:28 --> Helper loaded: my_helper
INFO - 2022-07-04 07:38:28 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:38:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:38:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:38:28 --> Controller Class Initialized
DEBUG - 2022-07-04 07:38:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-07-04 07:38:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 07:38:28 --> Final output sent to browser
DEBUG - 2022-07-04 07:38:28 --> Total execution time: 0.0710
INFO - 2022-07-04 07:38:28 --> Config Class Initialized
INFO - 2022-07-04 07:38:28 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:38:28 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:38:28 --> Utf8 Class Initialized
INFO - 2022-07-04 07:38:28 --> URI Class Initialized
INFO - 2022-07-04 07:38:28 --> Router Class Initialized
INFO - 2022-07-04 07:38:28 --> Output Class Initialized
INFO - 2022-07-04 07:38:28 --> Security Class Initialized
DEBUG - 2022-07-04 07:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:38:28 --> Input Class Initialized
INFO - 2022-07-04 07:38:28 --> Language Class Initialized
INFO - 2022-07-04 07:38:28 --> Language Class Initialized
INFO - 2022-07-04 07:38:28 --> Config Class Initialized
INFO - 2022-07-04 07:38:28 --> Loader Class Initialized
INFO - 2022-07-04 07:38:28 --> Helper loaded: url_helper
INFO - 2022-07-04 07:38:28 --> Helper loaded: file_helper
INFO - 2022-07-04 07:38:28 --> Helper loaded: form_helper
INFO - 2022-07-04 07:38:28 --> Helper loaded: my_helper
INFO - 2022-07-04 07:38:28 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:38:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:38:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:38:28 --> Controller Class Initialized
INFO - 2022-07-04 07:38:31 --> Config Class Initialized
INFO - 2022-07-04 07:38:31 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:38:31 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:38:31 --> Utf8 Class Initialized
INFO - 2022-07-04 07:38:31 --> URI Class Initialized
INFO - 2022-07-04 07:38:31 --> Router Class Initialized
INFO - 2022-07-04 07:38:31 --> Output Class Initialized
INFO - 2022-07-04 07:38:31 --> Security Class Initialized
DEBUG - 2022-07-04 07:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:38:31 --> Input Class Initialized
INFO - 2022-07-04 07:38:31 --> Language Class Initialized
INFO - 2022-07-04 07:38:31 --> Language Class Initialized
INFO - 2022-07-04 07:38:31 --> Config Class Initialized
INFO - 2022-07-04 07:38:31 --> Loader Class Initialized
INFO - 2022-07-04 07:38:31 --> Helper loaded: url_helper
INFO - 2022-07-04 07:38:31 --> Helper loaded: file_helper
INFO - 2022-07-04 07:38:31 --> Helper loaded: form_helper
INFO - 2022-07-04 07:38:31 --> Helper loaded: my_helper
INFO - 2022-07-04 07:38:31 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:38:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:38:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:38:31 --> Controller Class Initialized
DEBUG - 2022-07-04 07:38:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2022-07-04 07:38:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 07:38:31 --> Final output sent to browser
DEBUG - 2022-07-04 07:38:31 --> Total execution time: 0.0452
INFO - 2022-07-04 07:38:35 --> Config Class Initialized
INFO - 2022-07-04 07:38:35 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:38:35 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:38:35 --> Utf8 Class Initialized
INFO - 2022-07-04 07:38:35 --> URI Class Initialized
INFO - 2022-07-04 07:38:35 --> Router Class Initialized
INFO - 2022-07-04 07:38:35 --> Output Class Initialized
INFO - 2022-07-04 07:38:35 --> Security Class Initialized
DEBUG - 2022-07-04 07:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:38:35 --> Input Class Initialized
INFO - 2022-07-04 07:38:35 --> Language Class Initialized
INFO - 2022-07-04 07:38:35 --> Language Class Initialized
INFO - 2022-07-04 07:38:35 --> Config Class Initialized
INFO - 2022-07-04 07:38:35 --> Loader Class Initialized
INFO - 2022-07-04 07:38:35 --> Helper loaded: url_helper
INFO - 2022-07-04 07:38:35 --> Helper loaded: file_helper
INFO - 2022-07-04 07:38:35 --> Helper loaded: form_helper
INFO - 2022-07-04 07:38:35 --> Helper loaded: my_helper
INFO - 2022-07-04 07:38:35 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:38:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:38:35 --> Controller Class Initialized
INFO - 2022-07-04 07:38:35 --> Config Class Initialized
INFO - 2022-07-04 07:38:35 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:38:35 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:38:35 --> Utf8 Class Initialized
INFO - 2022-07-04 07:38:35 --> URI Class Initialized
INFO - 2022-07-04 07:38:35 --> Router Class Initialized
INFO - 2022-07-04 07:38:35 --> Output Class Initialized
INFO - 2022-07-04 07:38:35 --> Security Class Initialized
DEBUG - 2022-07-04 07:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:38:35 --> Input Class Initialized
INFO - 2022-07-04 07:38:35 --> Language Class Initialized
INFO - 2022-07-04 07:38:35 --> Language Class Initialized
INFO - 2022-07-04 07:38:35 --> Config Class Initialized
INFO - 2022-07-04 07:38:35 --> Loader Class Initialized
INFO - 2022-07-04 07:38:35 --> Helper loaded: url_helper
INFO - 2022-07-04 07:38:35 --> Helper loaded: file_helper
INFO - 2022-07-04 07:38:35 --> Helper loaded: form_helper
INFO - 2022-07-04 07:38:35 --> Helper loaded: my_helper
INFO - 2022-07-04 07:38:35 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:38:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:38:35 --> Controller Class Initialized
DEBUG - 2022-07-04 07:38:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-07-04 07:38:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 07:38:35 --> Final output sent to browser
DEBUG - 2022-07-04 07:38:35 --> Total execution time: 0.0665
INFO - 2022-07-04 07:38:44 --> Config Class Initialized
INFO - 2022-07-04 07:38:44 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:38:44 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:38:44 --> Utf8 Class Initialized
INFO - 2022-07-04 07:38:44 --> URI Class Initialized
INFO - 2022-07-04 07:38:44 --> Router Class Initialized
INFO - 2022-07-04 07:38:44 --> Output Class Initialized
INFO - 2022-07-04 07:38:44 --> Security Class Initialized
DEBUG - 2022-07-04 07:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:38:44 --> Input Class Initialized
INFO - 2022-07-04 07:38:44 --> Language Class Initialized
INFO - 2022-07-04 07:38:44 --> Language Class Initialized
INFO - 2022-07-04 07:38:44 --> Config Class Initialized
INFO - 2022-07-04 07:38:44 --> Loader Class Initialized
INFO - 2022-07-04 07:38:44 --> Helper loaded: url_helper
INFO - 2022-07-04 07:38:44 --> Helper loaded: file_helper
INFO - 2022-07-04 07:38:44 --> Helper loaded: form_helper
INFO - 2022-07-04 07:38:44 --> Helper loaded: my_helper
INFO - 2022-07-04 07:38:44 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:38:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:38:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:38:44 --> Controller Class Initialized
DEBUG - 2022-07-04 07:38:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2022-07-04 07:38:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 07:38:44 --> Final output sent to browser
DEBUG - 2022-07-04 07:38:44 --> Total execution time: 0.0592
INFO - 2022-07-04 07:38:47 --> Config Class Initialized
INFO - 2022-07-04 07:38:47 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:38:47 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:38:47 --> Utf8 Class Initialized
INFO - 2022-07-04 07:38:47 --> URI Class Initialized
INFO - 2022-07-04 07:38:47 --> Router Class Initialized
INFO - 2022-07-04 07:38:47 --> Output Class Initialized
INFO - 2022-07-04 07:38:47 --> Security Class Initialized
DEBUG - 2022-07-04 07:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:38:47 --> Input Class Initialized
INFO - 2022-07-04 07:38:47 --> Language Class Initialized
INFO - 2022-07-04 07:38:47 --> Language Class Initialized
INFO - 2022-07-04 07:38:47 --> Config Class Initialized
INFO - 2022-07-04 07:38:47 --> Loader Class Initialized
INFO - 2022-07-04 07:38:47 --> Helper loaded: url_helper
INFO - 2022-07-04 07:38:47 --> Helper loaded: file_helper
INFO - 2022-07-04 07:38:47 --> Helper loaded: form_helper
INFO - 2022-07-04 07:38:47 --> Helper loaded: my_helper
INFO - 2022-07-04 07:38:47 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:38:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:38:47 --> Controller Class Initialized
INFO - 2022-07-04 07:38:47 --> Config Class Initialized
INFO - 2022-07-04 07:38:47 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:38:47 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:38:47 --> Utf8 Class Initialized
INFO - 2022-07-04 07:38:47 --> URI Class Initialized
INFO - 2022-07-04 07:38:47 --> Router Class Initialized
INFO - 2022-07-04 07:38:47 --> Output Class Initialized
INFO - 2022-07-04 07:38:47 --> Security Class Initialized
DEBUG - 2022-07-04 07:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:38:47 --> Input Class Initialized
INFO - 2022-07-04 07:38:47 --> Language Class Initialized
INFO - 2022-07-04 07:38:47 --> Language Class Initialized
INFO - 2022-07-04 07:38:47 --> Config Class Initialized
INFO - 2022-07-04 07:38:47 --> Loader Class Initialized
INFO - 2022-07-04 07:38:47 --> Helper loaded: url_helper
INFO - 2022-07-04 07:38:47 --> Helper loaded: file_helper
INFO - 2022-07-04 07:38:47 --> Helper loaded: form_helper
INFO - 2022-07-04 07:38:47 --> Helper loaded: my_helper
INFO - 2022-07-04 07:38:47 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:38:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:38:47 --> Controller Class Initialized
DEBUG - 2022-07-04 07:38:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-07-04 07:38:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 07:38:47 --> Final output sent to browser
DEBUG - 2022-07-04 07:38:47 --> Total execution time: 0.0467
INFO - 2022-07-04 07:38:50 --> Config Class Initialized
INFO - 2022-07-04 07:38:50 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:38:50 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:38:50 --> Utf8 Class Initialized
INFO - 2022-07-04 07:38:50 --> URI Class Initialized
INFO - 2022-07-04 07:38:50 --> Router Class Initialized
INFO - 2022-07-04 07:38:50 --> Output Class Initialized
INFO - 2022-07-04 07:38:50 --> Security Class Initialized
DEBUG - 2022-07-04 07:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:38:50 --> Input Class Initialized
INFO - 2022-07-04 07:38:50 --> Language Class Initialized
INFO - 2022-07-04 07:38:50 --> Language Class Initialized
INFO - 2022-07-04 07:38:50 --> Config Class Initialized
INFO - 2022-07-04 07:38:50 --> Loader Class Initialized
INFO - 2022-07-04 07:38:50 --> Helper loaded: url_helper
INFO - 2022-07-04 07:38:50 --> Helper loaded: file_helper
INFO - 2022-07-04 07:38:50 --> Helper loaded: form_helper
INFO - 2022-07-04 07:38:50 --> Helper loaded: my_helper
INFO - 2022-07-04 07:38:50 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:38:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:38:50 --> Controller Class Initialized
INFO - 2022-07-04 07:38:50 --> Helper loaded: cookie_helper
INFO - 2022-07-04 07:38:50 --> Config Class Initialized
INFO - 2022-07-04 07:38:50 --> Hooks Class Initialized
DEBUG - 2022-07-04 07:38:50 --> UTF-8 Support Enabled
INFO - 2022-07-04 07:38:50 --> Utf8 Class Initialized
INFO - 2022-07-04 07:38:50 --> URI Class Initialized
INFO - 2022-07-04 07:38:50 --> Router Class Initialized
INFO - 2022-07-04 07:38:50 --> Output Class Initialized
INFO - 2022-07-04 07:38:50 --> Security Class Initialized
DEBUG - 2022-07-04 07:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-04 07:38:50 --> Input Class Initialized
INFO - 2022-07-04 07:38:50 --> Language Class Initialized
INFO - 2022-07-04 07:38:50 --> Language Class Initialized
INFO - 2022-07-04 07:38:50 --> Config Class Initialized
INFO - 2022-07-04 07:38:50 --> Loader Class Initialized
INFO - 2022-07-04 07:38:50 --> Helper loaded: url_helper
INFO - 2022-07-04 07:38:50 --> Helper loaded: file_helper
INFO - 2022-07-04 07:38:50 --> Helper loaded: form_helper
INFO - 2022-07-04 07:38:50 --> Helper loaded: my_helper
INFO - 2022-07-04 07:38:50 --> Database Driver Class Initialized
DEBUG - 2022-07-04 07:38:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-04 07:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-04 07:38:50 --> Controller Class Initialized
DEBUG - 2022-07-04 07:38:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-07-04 07:38:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-04 07:38:50 --> Final output sent to browser
DEBUG - 2022-07-04 07:38:50 --> Total execution time: 0.0542
