<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-12-11 02:25:09 --> Config Class Initialized
INFO - 2020-12-11 02:25:09 --> Hooks Class Initialized
DEBUG - 2020-12-11 02:25:09 --> UTF-8 Support Enabled
INFO - 2020-12-11 02:25:09 --> Utf8 Class Initialized
INFO - 2020-12-11 02:25:09 --> URI Class Initialized
DEBUG - 2020-12-11 02:25:09 --> No URI present. Default controller set.
INFO - 2020-12-11 02:25:09 --> Router Class Initialized
INFO - 2020-12-11 02:25:09 --> Output Class Initialized
INFO - 2020-12-11 02:25:09 --> Security Class Initialized
DEBUG - 2020-12-11 02:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-11 02:25:09 --> Input Class Initialized
INFO - 2020-12-11 02:25:09 --> Language Class Initialized
INFO - 2020-12-11 02:25:09 --> Language Class Initialized
INFO - 2020-12-11 02:25:09 --> Config Class Initialized
INFO - 2020-12-11 02:25:09 --> Loader Class Initialized
INFO - 2020-12-11 02:25:09 --> Helper loaded: url_helper
INFO - 2020-12-11 02:25:09 --> Helper loaded: file_helper
INFO - 2020-12-11 02:25:09 --> Helper loaded: form_helper
INFO - 2020-12-11 02:25:09 --> Helper loaded: my_helper
INFO - 2020-12-11 02:25:09 --> Database Driver Class Initialized
DEBUG - 2020-12-11 02:25:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-11 02:25:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-11 02:25:09 --> Controller Class Initialized
INFO - 2020-12-11 02:25:09 --> Config Class Initialized
INFO - 2020-12-11 02:25:09 --> Hooks Class Initialized
DEBUG - 2020-12-11 02:25:09 --> UTF-8 Support Enabled
INFO - 2020-12-11 02:25:09 --> Utf8 Class Initialized
INFO - 2020-12-11 02:25:09 --> URI Class Initialized
INFO - 2020-12-11 02:25:09 --> Router Class Initialized
INFO - 2020-12-11 02:25:09 --> Output Class Initialized
INFO - 2020-12-11 02:25:09 --> Security Class Initialized
DEBUG - 2020-12-11 02:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-11 02:25:09 --> Input Class Initialized
INFO - 2020-12-11 02:25:09 --> Language Class Initialized
INFO - 2020-12-11 02:25:09 --> Language Class Initialized
INFO - 2020-12-11 02:25:09 --> Config Class Initialized
INFO - 2020-12-11 02:25:09 --> Loader Class Initialized
INFO - 2020-12-11 02:25:09 --> Helper loaded: url_helper
INFO - 2020-12-11 02:25:09 --> Helper loaded: file_helper
INFO - 2020-12-11 02:25:09 --> Helper loaded: form_helper
INFO - 2020-12-11 02:25:09 --> Helper loaded: my_helper
INFO - 2020-12-11 02:25:09 --> Database Driver Class Initialized
DEBUG - 2020-12-11 02:25:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-11 02:25:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-11 02:25:09 --> Controller Class Initialized
DEBUG - 2020-12-11 02:25:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-11 02:25:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-11 02:25:09 --> Final output sent to browser
DEBUG - 2020-12-11 02:25:09 --> Total execution time: 0.1267
INFO - 2020-12-11 04:27:42 --> Config Class Initialized
INFO - 2020-12-11 04:27:42 --> Hooks Class Initialized
DEBUG - 2020-12-11 04:27:42 --> UTF-8 Support Enabled
INFO - 2020-12-11 04:27:42 --> Utf8 Class Initialized
INFO - 2020-12-11 04:27:42 --> URI Class Initialized
INFO - 2020-12-11 04:27:42 --> Router Class Initialized
INFO - 2020-12-11 04:27:42 --> Output Class Initialized
INFO - 2020-12-11 04:27:42 --> Security Class Initialized
DEBUG - 2020-12-11 04:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-11 04:27:42 --> Input Class Initialized
INFO - 2020-12-11 04:27:42 --> Language Class Initialized
INFO - 2020-12-11 04:27:42 --> Language Class Initialized
INFO - 2020-12-11 04:27:42 --> Config Class Initialized
INFO - 2020-12-11 04:27:42 --> Loader Class Initialized
INFO - 2020-12-11 04:27:42 --> Helper loaded: url_helper
INFO - 2020-12-11 04:27:42 --> Helper loaded: file_helper
INFO - 2020-12-11 04:27:42 --> Helper loaded: form_helper
INFO - 2020-12-11 04:27:42 --> Helper loaded: my_helper
INFO - 2020-12-11 04:27:42 --> Database Driver Class Initialized
DEBUG - 2020-12-11 04:27:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-11 04:27:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-11 04:27:42 --> Controller Class Initialized
INFO - 2020-12-11 04:27:42 --> Helper loaded: cookie_helper
INFO - 2020-12-11 04:27:42 --> Final output sent to browser
DEBUG - 2020-12-11 04:27:42 --> Total execution time: 0.7204
INFO - 2020-12-11 04:27:43 --> Config Class Initialized
INFO - 2020-12-11 04:27:43 --> Hooks Class Initialized
DEBUG - 2020-12-11 04:27:43 --> UTF-8 Support Enabled
INFO - 2020-12-11 04:27:43 --> Utf8 Class Initialized
INFO - 2020-12-11 04:27:43 --> URI Class Initialized
INFO - 2020-12-11 04:27:43 --> Router Class Initialized
INFO - 2020-12-11 04:27:43 --> Output Class Initialized
INFO - 2020-12-11 04:27:43 --> Security Class Initialized
DEBUG - 2020-12-11 04:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-11 04:27:43 --> Input Class Initialized
INFO - 2020-12-11 04:27:43 --> Language Class Initialized
INFO - 2020-12-11 04:27:43 --> Language Class Initialized
INFO - 2020-12-11 04:27:43 --> Config Class Initialized
INFO - 2020-12-11 04:27:43 --> Loader Class Initialized
INFO - 2020-12-11 04:27:43 --> Helper loaded: url_helper
INFO - 2020-12-11 04:27:43 --> Helper loaded: file_helper
INFO - 2020-12-11 04:27:43 --> Helper loaded: form_helper
INFO - 2020-12-11 04:27:43 --> Helper loaded: my_helper
INFO - 2020-12-11 04:27:43 --> Database Driver Class Initialized
DEBUG - 2020-12-11 04:27:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-11 04:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-11 04:27:43 --> Controller Class Initialized
DEBUG - 2020-12-11 04:27:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-11 04:27:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-11 04:27:44 --> Final output sent to browser
DEBUG - 2020-12-11 04:27:44 --> Total execution time: 0.1892
INFO - 2020-12-11 04:27:47 --> Config Class Initialized
INFO - 2020-12-11 04:27:47 --> Hooks Class Initialized
DEBUG - 2020-12-11 04:27:47 --> UTF-8 Support Enabled
INFO - 2020-12-11 04:27:47 --> Utf8 Class Initialized
INFO - 2020-12-11 04:27:47 --> URI Class Initialized
INFO - 2020-12-11 04:27:47 --> Router Class Initialized
INFO - 2020-12-11 04:27:47 --> Output Class Initialized
INFO - 2020-12-11 04:27:47 --> Security Class Initialized
DEBUG - 2020-12-11 04:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-11 04:27:47 --> Input Class Initialized
INFO - 2020-12-11 04:27:47 --> Language Class Initialized
INFO - 2020-12-11 04:27:47 --> Language Class Initialized
INFO - 2020-12-11 04:27:47 --> Config Class Initialized
INFO - 2020-12-11 04:27:47 --> Loader Class Initialized
INFO - 2020-12-11 04:27:47 --> Helper loaded: url_helper
INFO - 2020-12-11 04:27:47 --> Helper loaded: file_helper
INFO - 2020-12-11 04:27:47 --> Helper loaded: form_helper
INFO - 2020-12-11 04:27:47 --> Helper loaded: my_helper
INFO - 2020-12-11 04:27:47 --> Database Driver Class Initialized
DEBUG - 2020-12-11 04:27:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-11 04:27:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-11 04:27:47 --> Controller Class Initialized
DEBUG - 2020-12-11 04:27:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-12-11 04:27:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-11 04:27:47 --> Final output sent to browser
DEBUG - 2020-12-11 04:27:47 --> Total execution time: 0.1236
INFO - 2020-12-11 04:27:48 --> Config Class Initialized
INFO - 2020-12-11 04:27:48 --> Hooks Class Initialized
DEBUG - 2020-12-11 04:27:48 --> UTF-8 Support Enabled
INFO - 2020-12-11 04:27:48 --> Utf8 Class Initialized
INFO - 2020-12-11 04:27:48 --> URI Class Initialized
INFO - 2020-12-11 04:27:48 --> Router Class Initialized
INFO - 2020-12-11 04:27:48 --> Output Class Initialized
INFO - 2020-12-11 04:27:48 --> Security Class Initialized
DEBUG - 2020-12-11 04:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-11 04:27:48 --> Input Class Initialized
INFO - 2020-12-11 04:27:48 --> Language Class Initialized
INFO - 2020-12-11 04:27:48 --> Language Class Initialized
INFO - 2020-12-11 04:27:48 --> Config Class Initialized
INFO - 2020-12-11 04:27:48 --> Loader Class Initialized
INFO - 2020-12-11 04:27:48 --> Helper loaded: url_helper
INFO - 2020-12-11 04:27:48 --> Helper loaded: file_helper
INFO - 2020-12-11 04:27:48 --> Helper loaded: form_helper
INFO - 2020-12-11 04:27:48 --> Helper loaded: my_helper
INFO - 2020-12-11 04:27:48 --> Database Driver Class Initialized
DEBUG - 2020-12-11 04:27:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-11 04:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-11 04:27:48 --> Controller Class Initialized
INFO - 2020-12-11 04:27:48 --> Final output sent to browser
DEBUG - 2020-12-11 04:27:48 --> Total execution time: 0.0672
