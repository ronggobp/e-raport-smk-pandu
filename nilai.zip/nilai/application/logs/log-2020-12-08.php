<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-12-08 01:17:22 --> Config Class Initialized
INFO - 2020-12-08 01:17:22 --> Hooks Class Initialized
DEBUG - 2020-12-08 01:17:22 --> UTF-8 Support Enabled
INFO - 2020-12-08 01:17:22 --> Utf8 Class Initialized
INFO - 2020-12-08 01:17:22 --> URI Class Initialized
DEBUG - 2020-12-08 01:17:23 --> No URI present. Default controller set.
INFO - 2020-12-08 01:17:23 --> Router Class Initialized
INFO - 2020-12-08 01:17:23 --> Output Class Initialized
INFO - 2020-12-08 01:17:23 --> Security Class Initialized
DEBUG - 2020-12-08 01:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-08 01:17:23 --> Input Class Initialized
INFO - 2020-12-08 01:17:23 --> Language Class Initialized
INFO - 2020-12-08 01:17:23 --> Language Class Initialized
INFO - 2020-12-08 01:17:23 --> Config Class Initialized
INFO - 2020-12-08 01:17:23 --> Loader Class Initialized
INFO - 2020-12-08 01:17:23 --> Helper loaded: url_helper
INFO - 2020-12-08 01:17:23 --> Helper loaded: file_helper
INFO - 2020-12-08 01:17:23 --> Helper loaded: form_helper
INFO - 2020-12-08 01:17:23 --> Helper loaded: my_helper
INFO - 2020-12-08 01:17:23 --> Database Driver Class Initialized
DEBUG - 2020-12-08 01:17:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-08 01:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-08 01:17:23 --> Controller Class Initialized
INFO - 2020-12-08 01:17:24 --> Config Class Initialized
INFO - 2020-12-08 01:17:24 --> Hooks Class Initialized
DEBUG - 2020-12-08 01:17:24 --> UTF-8 Support Enabled
INFO - 2020-12-08 01:17:24 --> Utf8 Class Initialized
INFO - 2020-12-08 01:17:24 --> URI Class Initialized
INFO - 2020-12-08 01:17:24 --> Router Class Initialized
INFO - 2020-12-08 01:17:24 --> Output Class Initialized
INFO - 2020-12-08 01:17:24 --> Security Class Initialized
DEBUG - 2020-12-08 01:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-08 01:17:24 --> Input Class Initialized
INFO - 2020-12-08 01:17:24 --> Language Class Initialized
INFO - 2020-12-08 01:17:24 --> Language Class Initialized
INFO - 2020-12-08 01:17:24 --> Config Class Initialized
INFO - 2020-12-08 01:17:24 --> Loader Class Initialized
INFO - 2020-12-08 01:17:24 --> Helper loaded: url_helper
INFO - 2020-12-08 01:17:24 --> Helper loaded: file_helper
INFO - 2020-12-08 01:17:24 --> Helper loaded: form_helper
INFO - 2020-12-08 01:17:24 --> Helper loaded: my_helper
INFO - 2020-12-08 01:17:24 --> Database Driver Class Initialized
DEBUG - 2020-12-08 01:17:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-08 01:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-08 01:17:24 --> Controller Class Initialized
DEBUG - 2020-12-08 01:17:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-08 01:17:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-08 01:17:24 --> Final output sent to browser
DEBUG - 2020-12-08 01:17:24 --> Total execution time: 0.3657
INFO - 2020-12-08 02:55:03 --> Config Class Initialized
INFO - 2020-12-08 02:55:03 --> Hooks Class Initialized
DEBUG - 2020-12-08 02:55:03 --> UTF-8 Support Enabled
INFO - 2020-12-08 02:55:03 --> Utf8 Class Initialized
INFO - 2020-12-08 02:55:03 --> URI Class Initialized
INFO - 2020-12-08 02:55:03 --> Router Class Initialized
INFO - 2020-12-08 02:55:03 --> Output Class Initialized
INFO - 2020-12-08 02:55:03 --> Security Class Initialized
DEBUG - 2020-12-08 02:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-08 02:55:03 --> Input Class Initialized
INFO - 2020-12-08 02:55:03 --> Language Class Initialized
INFO - 2020-12-08 02:55:03 --> Language Class Initialized
INFO - 2020-12-08 02:55:03 --> Config Class Initialized
INFO - 2020-12-08 02:55:03 --> Loader Class Initialized
INFO - 2020-12-08 02:55:03 --> Helper loaded: url_helper
INFO - 2020-12-08 02:55:03 --> Helper loaded: file_helper
INFO - 2020-12-08 02:55:04 --> Helper loaded: form_helper
INFO - 2020-12-08 02:55:04 --> Helper loaded: my_helper
INFO - 2020-12-08 02:55:04 --> Database Driver Class Initialized
DEBUG - 2020-12-08 02:55:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-08 02:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-08 02:55:04 --> Controller Class Initialized
INFO - 2020-12-08 02:55:04 --> Helper loaded: cookie_helper
INFO - 2020-12-08 02:55:04 --> Final output sent to browser
DEBUG - 2020-12-08 02:55:04 --> Total execution time: 0.4348
INFO - 2020-12-08 02:55:04 --> Config Class Initialized
INFO - 2020-12-08 02:55:04 --> Hooks Class Initialized
DEBUG - 2020-12-08 02:55:04 --> UTF-8 Support Enabled
INFO - 2020-12-08 02:55:04 --> Utf8 Class Initialized
INFO - 2020-12-08 02:55:04 --> URI Class Initialized
INFO - 2020-12-08 02:55:04 --> Router Class Initialized
INFO - 2020-12-08 02:55:04 --> Output Class Initialized
INFO - 2020-12-08 02:55:04 --> Security Class Initialized
DEBUG - 2020-12-08 02:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-08 02:55:04 --> Input Class Initialized
INFO - 2020-12-08 02:55:04 --> Language Class Initialized
INFO - 2020-12-08 02:55:04 --> Language Class Initialized
INFO - 2020-12-08 02:55:04 --> Config Class Initialized
INFO - 2020-12-08 02:55:04 --> Loader Class Initialized
INFO - 2020-12-08 02:55:04 --> Helper loaded: url_helper
INFO - 2020-12-08 02:55:04 --> Helper loaded: file_helper
INFO - 2020-12-08 02:55:04 --> Helper loaded: form_helper
INFO - 2020-12-08 02:55:04 --> Helper loaded: my_helper
INFO - 2020-12-08 02:55:04 --> Database Driver Class Initialized
DEBUG - 2020-12-08 02:55:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-08 02:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-08 02:55:04 --> Controller Class Initialized
DEBUG - 2020-12-08 02:55:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-08 02:55:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-08 02:55:04 --> Final output sent to browser
DEBUG - 2020-12-08 02:55:04 --> Total execution time: 0.2371
INFO - 2020-12-08 02:55:06 --> Config Class Initialized
INFO - 2020-12-08 02:55:06 --> Hooks Class Initialized
DEBUG - 2020-12-08 02:55:06 --> UTF-8 Support Enabled
INFO - 2020-12-08 02:55:06 --> Utf8 Class Initialized
INFO - 2020-12-08 02:55:06 --> URI Class Initialized
INFO - 2020-12-08 02:55:06 --> Router Class Initialized
INFO - 2020-12-08 02:55:06 --> Output Class Initialized
INFO - 2020-12-08 02:55:06 --> Security Class Initialized
DEBUG - 2020-12-08 02:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-08 02:55:06 --> Input Class Initialized
INFO - 2020-12-08 02:55:06 --> Language Class Initialized
INFO - 2020-12-08 02:55:06 --> Language Class Initialized
INFO - 2020-12-08 02:55:06 --> Config Class Initialized
INFO - 2020-12-08 02:55:06 --> Loader Class Initialized
INFO - 2020-12-08 02:55:06 --> Helper loaded: url_helper
INFO - 2020-12-08 02:55:06 --> Helper loaded: file_helper
INFO - 2020-12-08 02:55:07 --> Helper loaded: form_helper
INFO - 2020-12-08 02:55:07 --> Helper loaded: my_helper
INFO - 2020-12-08 02:55:07 --> Database Driver Class Initialized
DEBUG - 2020-12-08 02:55:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-08 02:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-08 02:55:07 --> Controller Class Initialized
DEBUG - 2020-12-08 02:55:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-08 02:55:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-08 02:55:07 --> Final output sent to browser
DEBUG - 2020-12-08 02:55:07 --> Total execution time: 0.2134
INFO - 2020-12-08 09:53:53 --> Config Class Initialized
INFO - 2020-12-08 09:53:53 --> Hooks Class Initialized
DEBUG - 2020-12-08 09:53:53 --> UTF-8 Support Enabled
INFO - 2020-12-08 09:53:53 --> Utf8 Class Initialized
INFO - 2020-12-08 09:53:53 --> URI Class Initialized
INFO - 2020-12-08 09:53:53 --> Router Class Initialized
INFO - 2020-12-08 09:53:53 --> Output Class Initialized
INFO - 2020-12-08 09:53:53 --> Security Class Initialized
DEBUG - 2020-12-08 09:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-08 09:53:53 --> Input Class Initialized
INFO - 2020-12-08 09:53:53 --> Language Class Initialized
INFO - 2020-12-08 09:53:53 --> Language Class Initialized
INFO - 2020-12-08 09:53:53 --> Config Class Initialized
INFO - 2020-12-08 09:53:53 --> Loader Class Initialized
INFO - 2020-12-08 09:53:53 --> Helper loaded: url_helper
INFO - 2020-12-08 09:53:53 --> Helper loaded: file_helper
INFO - 2020-12-08 09:53:53 --> Helper loaded: form_helper
INFO - 2020-12-08 09:53:53 --> Helper loaded: my_helper
INFO - 2020-12-08 09:53:53 --> Database Driver Class Initialized
DEBUG - 2020-12-08 09:53:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-08 09:53:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-08 09:53:53 --> Controller Class Initialized
ERROR - 2020-12-08 09:53:53 --> Severity: Parsing Error --> syntax error, unexpected 'form' (T_STRING) C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
INFO - 2020-12-08 09:54:40 --> Config Class Initialized
INFO - 2020-12-08 09:54:40 --> Hooks Class Initialized
DEBUG - 2020-12-08 09:54:40 --> UTF-8 Support Enabled
INFO - 2020-12-08 09:54:40 --> Utf8 Class Initialized
INFO - 2020-12-08 09:54:40 --> URI Class Initialized
INFO - 2020-12-08 09:54:40 --> Router Class Initialized
INFO - 2020-12-08 09:54:40 --> Output Class Initialized
INFO - 2020-12-08 09:54:40 --> Security Class Initialized
DEBUG - 2020-12-08 09:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-08 09:54:40 --> Input Class Initialized
INFO - 2020-12-08 09:54:40 --> Language Class Initialized
INFO - 2020-12-08 09:54:40 --> Language Class Initialized
INFO - 2020-12-08 09:54:40 --> Config Class Initialized
INFO - 2020-12-08 09:54:40 --> Loader Class Initialized
INFO - 2020-12-08 09:54:40 --> Helper loaded: url_helper
INFO - 2020-12-08 09:54:40 --> Helper loaded: file_helper
INFO - 2020-12-08 09:54:40 --> Helper loaded: form_helper
INFO - 2020-12-08 09:54:40 --> Helper loaded: my_helper
INFO - 2020-12-08 09:54:40 --> Database Driver Class Initialized
DEBUG - 2020-12-08 09:54:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-08 09:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-08 09:54:40 --> Controller Class Initialized
ERROR - 2020-12-08 09:54:40 --> Severity: Parsing Error --> syntax error, unexpected '<' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
INFO - 2020-12-08 09:58:16 --> Config Class Initialized
INFO - 2020-12-08 09:58:16 --> Hooks Class Initialized
DEBUG - 2020-12-08 09:58:16 --> UTF-8 Support Enabled
INFO - 2020-12-08 09:58:16 --> Utf8 Class Initialized
INFO - 2020-12-08 09:58:16 --> URI Class Initialized
INFO - 2020-12-08 09:58:16 --> Router Class Initialized
INFO - 2020-12-08 09:58:16 --> Output Class Initialized
INFO - 2020-12-08 09:58:16 --> Security Class Initialized
DEBUG - 2020-12-08 09:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-08 09:58:16 --> Input Class Initialized
INFO - 2020-12-08 09:58:16 --> Language Class Initialized
INFO - 2020-12-08 09:58:16 --> Language Class Initialized
INFO - 2020-12-08 09:58:16 --> Config Class Initialized
INFO - 2020-12-08 09:58:16 --> Loader Class Initialized
INFO - 2020-12-08 09:58:16 --> Helper loaded: url_helper
INFO - 2020-12-08 09:58:16 --> Helper loaded: file_helper
INFO - 2020-12-08 09:58:16 --> Helper loaded: form_helper
INFO - 2020-12-08 09:58:16 --> Helper loaded: my_helper
INFO - 2020-12-08 09:58:16 --> Database Driver Class Initialized
DEBUG - 2020-12-08 09:58:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-08 09:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-08 09:58:16 --> Controller Class Initialized
ERROR - 2020-12-08 09:58:16 --> Severity: Parsing Error --> syntax error, unexpected '<' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 133
INFO - 2020-12-08 09:58:48 --> Config Class Initialized
INFO - 2020-12-08 09:58:48 --> Hooks Class Initialized
DEBUG - 2020-12-08 09:58:48 --> UTF-8 Support Enabled
INFO - 2020-12-08 09:58:48 --> Utf8 Class Initialized
INFO - 2020-12-08 09:58:48 --> URI Class Initialized
INFO - 2020-12-08 09:58:48 --> Router Class Initialized
INFO - 2020-12-08 09:58:48 --> Output Class Initialized
INFO - 2020-12-08 09:58:48 --> Security Class Initialized
DEBUG - 2020-12-08 09:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-08 09:58:48 --> Input Class Initialized
INFO - 2020-12-08 09:58:48 --> Language Class Initialized
INFO - 2020-12-08 09:58:48 --> Language Class Initialized
INFO - 2020-12-08 09:58:48 --> Config Class Initialized
INFO - 2020-12-08 09:58:48 --> Loader Class Initialized
INFO - 2020-12-08 09:58:48 --> Helper loaded: url_helper
INFO - 2020-12-08 09:58:48 --> Helper loaded: file_helper
INFO - 2020-12-08 09:58:48 --> Helper loaded: form_helper
INFO - 2020-12-08 09:58:48 --> Helper loaded: my_helper
INFO - 2020-12-08 09:58:48 --> Database Driver Class Initialized
DEBUG - 2020-12-08 09:58:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-08 09:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-08 09:58:48 --> Controller Class Initialized
DEBUG - 2020-12-08 09:58:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-08 09:58:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-08 09:58:48 --> Final output sent to browser
DEBUG - 2020-12-08 09:58:48 --> Total execution time: 0.1903
