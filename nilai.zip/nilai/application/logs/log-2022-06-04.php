<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-06-04 10:07:03 --> Config Class Initialized
INFO - 2022-06-04 10:07:03 --> Hooks Class Initialized
DEBUG - 2022-06-04 10:07:03 --> UTF-8 Support Enabled
INFO - 2022-06-04 10:07:03 --> Utf8 Class Initialized
INFO - 2022-06-04 10:07:03 --> URI Class Initialized
DEBUG - 2022-06-04 10:07:03 --> No URI present. Default controller set.
INFO - 2022-06-04 10:07:03 --> Router Class Initialized
INFO - 2022-06-04 10:07:03 --> Output Class Initialized
INFO - 2022-06-04 10:07:03 --> Security Class Initialized
DEBUG - 2022-06-04 10:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-04 10:07:03 --> Input Class Initialized
INFO - 2022-06-04 10:07:03 --> Language Class Initialized
INFO - 2022-06-04 10:07:03 --> Language Class Initialized
INFO - 2022-06-04 10:07:03 --> Config Class Initialized
INFO - 2022-06-04 10:07:03 --> Loader Class Initialized
INFO - 2022-06-04 10:07:03 --> Helper loaded: url_helper
INFO - 2022-06-04 10:07:03 --> Helper loaded: file_helper
INFO - 2022-06-04 10:07:03 --> Helper loaded: form_helper
INFO - 2022-06-04 10:07:03 --> Helper loaded: my_helper
INFO - 2022-06-04 10:07:04 --> Database Driver Class Initialized
DEBUG - 2022-06-04 10:07:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-04 10:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-04 10:07:04 --> Controller Class Initialized
INFO - 2022-06-04 10:07:04 --> Config Class Initialized
INFO - 2022-06-04 10:07:04 --> Hooks Class Initialized
DEBUG - 2022-06-04 10:07:04 --> UTF-8 Support Enabled
INFO - 2022-06-04 10:07:04 --> Utf8 Class Initialized
INFO - 2022-06-04 10:07:04 --> URI Class Initialized
INFO - 2022-06-04 10:07:04 --> Router Class Initialized
INFO - 2022-06-04 10:07:04 --> Output Class Initialized
INFO - 2022-06-04 10:07:04 --> Security Class Initialized
DEBUG - 2022-06-04 10:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-04 10:07:04 --> Input Class Initialized
INFO - 2022-06-04 10:07:04 --> Language Class Initialized
INFO - 2022-06-04 10:07:04 --> Language Class Initialized
INFO - 2022-06-04 10:07:04 --> Config Class Initialized
INFO - 2022-06-04 10:07:04 --> Loader Class Initialized
INFO - 2022-06-04 10:07:04 --> Helper loaded: url_helper
INFO - 2022-06-04 10:07:04 --> Helper loaded: file_helper
INFO - 2022-06-04 10:07:04 --> Helper loaded: form_helper
INFO - 2022-06-04 10:07:04 --> Helper loaded: my_helper
INFO - 2022-06-04 10:07:04 --> Database Driver Class Initialized
DEBUG - 2022-06-04 10:07:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-04 10:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-04 10:07:04 --> Controller Class Initialized
DEBUG - 2022-06-04 10:07:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-04 10:07:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-04 10:07:04 --> Final output sent to browser
DEBUG - 2022-06-04 10:07:04 --> Total execution time: 0.2723
INFO - 2022-06-04 10:21:46 --> Config Class Initialized
INFO - 2022-06-04 10:21:46 --> Hooks Class Initialized
DEBUG - 2022-06-04 10:21:46 --> UTF-8 Support Enabled
INFO - 2022-06-04 10:21:46 --> Utf8 Class Initialized
INFO - 2022-06-04 10:21:46 --> URI Class Initialized
INFO - 2022-06-04 10:21:46 --> Router Class Initialized
INFO - 2022-06-04 10:21:46 --> Output Class Initialized
INFO - 2022-06-04 10:21:46 --> Security Class Initialized
DEBUG - 2022-06-04 10:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-04 10:21:46 --> Input Class Initialized
INFO - 2022-06-04 10:21:46 --> Language Class Initialized
INFO - 2022-06-04 10:21:46 --> Language Class Initialized
INFO - 2022-06-04 10:21:46 --> Config Class Initialized
INFO - 2022-06-04 10:21:46 --> Loader Class Initialized
INFO - 2022-06-04 10:21:46 --> Helper loaded: url_helper
INFO - 2022-06-04 10:21:46 --> Helper loaded: file_helper
INFO - 2022-06-04 10:21:46 --> Helper loaded: form_helper
INFO - 2022-06-04 10:21:46 --> Helper loaded: my_helper
INFO - 2022-06-04 10:21:46 --> Database Driver Class Initialized
DEBUG - 2022-06-04 10:21:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-04 10:21:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-04 10:21:46 --> Controller Class Initialized
INFO - 2022-06-04 10:21:46 --> Helper loaded: cookie_helper
INFO - 2022-06-04 10:21:46 --> Final output sent to browser
DEBUG - 2022-06-04 10:21:46 --> Total execution time: 0.1107
INFO - 2022-06-04 10:21:46 --> Config Class Initialized
INFO - 2022-06-04 10:21:46 --> Hooks Class Initialized
DEBUG - 2022-06-04 10:21:46 --> UTF-8 Support Enabled
INFO - 2022-06-04 10:21:46 --> Utf8 Class Initialized
INFO - 2022-06-04 10:21:46 --> URI Class Initialized
INFO - 2022-06-04 10:21:46 --> Router Class Initialized
INFO - 2022-06-04 10:21:46 --> Output Class Initialized
INFO - 2022-06-04 10:21:46 --> Security Class Initialized
DEBUG - 2022-06-04 10:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-04 10:21:46 --> Input Class Initialized
INFO - 2022-06-04 10:21:46 --> Language Class Initialized
INFO - 2022-06-04 10:21:46 --> Language Class Initialized
INFO - 2022-06-04 10:21:46 --> Config Class Initialized
INFO - 2022-06-04 10:21:46 --> Loader Class Initialized
INFO - 2022-06-04 10:21:46 --> Helper loaded: url_helper
INFO - 2022-06-04 10:21:46 --> Helper loaded: file_helper
INFO - 2022-06-04 10:21:46 --> Helper loaded: form_helper
INFO - 2022-06-04 10:21:46 --> Helper loaded: my_helper
INFO - 2022-06-04 10:21:46 --> Database Driver Class Initialized
DEBUG - 2022-06-04 10:21:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-04 10:21:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-04 10:21:46 --> Controller Class Initialized
DEBUG - 2022-06-04 10:21:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-06-04 10:21:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-04 10:21:46 --> Final output sent to browser
DEBUG - 2022-06-04 10:21:46 --> Total execution time: 0.1649
INFO - 2022-06-04 10:21:57 --> Config Class Initialized
INFO - 2022-06-04 10:21:57 --> Hooks Class Initialized
DEBUG - 2022-06-04 10:21:57 --> UTF-8 Support Enabled
INFO - 2022-06-04 10:21:57 --> Utf8 Class Initialized
INFO - 2022-06-04 10:21:57 --> URI Class Initialized
INFO - 2022-06-04 10:21:57 --> Router Class Initialized
INFO - 2022-06-04 10:21:57 --> Output Class Initialized
INFO - 2022-06-04 10:21:57 --> Security Class Initialized
DEBUG - 2022-06-04 10:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-04 10:21:57 --> Input Class Initialized
INFO - 2022-06-04 10:21:57 --> Language Class Initialized
INFO - 2022-06-04 10:21:57 --> Language Class Initialized
INFO - 2022-06-04 10:21:57 --> Config Class Initialized
INFO - 2022-06-04 10:21:57 --> Loader Class Initialized
INFO - 2022-06-04 10:21:57 --> Helper loaded: url_helper
INFO - 2022-06-04 10:21:57 --> Helper loaded: file_helper
INFO - 2022-06-04 10:21:57 --> Helper loaded: form_helper
INFO - 2022-06-04 10:21:57 --> Helper loaded: my_helper
INFO - 2022-06-04 10:21:57 --> Database Driver Class Initialized
DEBUG - 2022-06-04 10:21:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-04 10:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-04 10:21:57 --> Controller Class Initialized
DEBUG - 2022-06-04 10:21:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-06-04 10:21:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-04 10:21:57 --> Final output sent to browser
DEBUG - 2022-06-04 10:21:57 --> Total execution time: 0.1324
INFO - 2022-06-04 10:21:58 --> Config Class Initialized
INFO - 2022-06-04 10:21:58 --> Hooks Class Initialized
DEBUG - 2022-06-04 10:21:58 --> UTF-8 Support Enabled
INFO - 2022-06-04 10:21:58 --> Utf8 Class Initialized
INFO - 2022-06-04 10:21:58 --> URI Class Initialized
INFO - 2022-06-04 10:21:58 --> Router Class Initialized
INFO - 2022-06-04 10:21:58 --> Output Class Initialized
INFO - 2022-06-04 10:21:58 --> Security Class Initialized
DEBUG - 2022-06-04 10:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-04 10:21:58 --> Input Class Initialized
INFO - 2022-06-04 10:21:58 --> Language Class Initialized
INFO - 2022-06-04 10:21:58 --> Language Class Initialized
INFO - 2022-06-04 10:21:58 --> Config Class Initialized
INFO - 2022-06-04 10:21:58 --> Loader Class Initialized
INFO - 2022-06-04 10:21:58 --> Helper loaded: url_helper
INFO - 2022-06-04 10:21:58 --> Helper loaded: file_helper
INFO - 2022-06-04 10:21:58 --> Helper loaded: form_helper
INFO - 2022-06-04 10:21:58 --> Helper loaded: my_helper
INFO - 2022-06-04 10:21:58 --> Database Driver Class Initialized
DEBUG - 2022-06-04 10:21:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-04 10:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-04 10:21:58 --> Controller Class Initialized
ERROR - 2022-06-04 10:21:58 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-04 10:21:58 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-04 10:21:58 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 161
ERROR - 2022-06-04 10:21:58 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
ERROR - 2022-06-04 10:21:58 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-04 10:21:58 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-04 10:21:58 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 160
ERROR - 2022-06-04 10:21:58 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
DEBUG - 2022-06-04 10:21:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2022-06-04 10:21:58 --> Final output sent to browser
DEBUG - 2022-06-04 10:21:58 --> Total execution time: 0.2379
INFO - 2022-06-04 10:26:18 --> Config Class Initialized
INFO - 2022-06-04 10:26:18 --> Hooks Class Initialized
DEBUG - 2022-06-04 10:26:18 --> UTF-8 Support Enabled
INFO - 2022-06-04 10:26:18 --> Utf8 Class Initialized
INFO - 2022-06-04 10:26:18 --> URI Class Initialized
INFO - 2022-06-04 10:26:18 --> Router Class Initialized
INFO - 2022-06-04 10:26:18 --> Output Class Initialized
INFO - 2022-06-04 10:26:18 --> Security Class Initialized
DEBUG - 2022-06-04 10:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-04 10:26:18 --> Input Class Initialized
INFO - 2022-06-04 10:26:18 --> Language Class Initialized
INFO - 2022-06-04 10:26:18 --> Language Class Initialized
INFO - 2022-06-04 10:26:18 --> Config Class Initialized
INFO - 2022-06-04 10:26:18 --> Loader Class Initialized
INFO - 2022-06-04 10:26:18 --> Helper loaded: url_helper
INFO - 2022-06-04 10:26:18 --> Helper loaded: file_helper
INFO - 2022-06-04 10:26:18 --> Helper loaded: form_helper
INFO - 2022-06-04 10:26:18 --> Helper loaded: my_helper
INFO - 2022-06-04 10:26:18 --> Database Driver Class Initialized
DEBUG - 2022-06-04 10:26:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-04 10:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-04 10:26:18 --> Controller Class Initialized
DEBUG - 2022-06-04 10:26:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-06-04 10:26:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-04 10:26:18 --> Final output sent to browser
DEBUG - 2022-06-04 10:26:18 --> Total execution time: 0.1153
INFO - 2022-06-04 10:26:28 --> Config Class Initialized
INFO - 2022-06-04 10:26:28 --> Hooks Class Initialized
DEBUG - 2022-06-04 10:26:28 --> UTF-8 Support Enabled
INFO - 2022-06-04 10:26:28 --> Utf8 Class Initialized
INFO - 2022-06-04 10:26:28 --> URI Class Initialized
INFO - 2022-06-04 10:26:28 --> Router Class Initialized
INFO - 2022-06-04 10:26:28 --> Output Class Initialized
INFO - 2022-06-04 10:26:28 --> Security Class Initialized
DEBUG - 2022-06-04 10:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-04 10:26:28 --> Input Class Initialized
INFO - 2022-06-04 10:26:28 --> Language Class Initialized
INFO - 2022-06-04 10:26:28 --> Language Class Initialized
INFO - 2022-06-04 10:26:28 --> Config Class Initialized
INFO - 2022-06-04 10:26:28 --> Loader Class Initialized
INFO - 2022-06-04 10:26:28 --> Helper loaded: url_helper
INFO - 2022-06-04 10:26:28 --> Helper loaded: file_helper
INFO - 2022-06-04 10:26:28 --> Helper loaded: form_helper
INFO - 2022-06-04 10:26:28 --> Helper loaded: my_helper
INFO - 2022-06-04 10:26:28 --> Database Driver Class Initialized
DEBUG - 2022-06-04 10:26:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-04 10:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-04 10:26:28 --> Controller Class Initialized
ERROR - 2022-06-04 10:26:28 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-04 10:26:28 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-04 10:26:28 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 161
ERROR - 2022-06-04 10:26:28 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
ERROR - 2022-06-04 10:26:28 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-04 10:26:28 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-04 10:26:28 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 160
ERROR - 2022-06-04 10:26:28 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
DEBUG - 2022-06-04 10:26:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2022-06-04 10:26:28 --> Final output sent to browser
DEBUG - 2022-06-04 10:26:28 --> Total execution time: 0.0843
INFO - 2022-06-04 10:33:54 --> Config Class Initialized
INFO - 2022-06-04 10:33:54 --> Hooks Class Initialized
DEBUG - 2022-06-04 10:33:54 --> UTF-8 Support Enabled
INFO - 2022-06-04 10:33:54 --> Utf8 Class Initialized
INFO - 2022-06-04 10:33:54 --> URI Class Initialized
INFO - 2022-06-04 10:33:54 --> Router Class Initialized
INFO - 2022-06-04 10:33:54 --> Output Class Initialized
INFO - 2022-06-04 10:33:54 --> Security Class Initialized
DEBUG - 2022-06-04 10:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-04 10:33:54 --> Input Class Initialized
INFO - 2022-06-04 10:33:54 --> Language Class Initialized
INFO - 2022-06-04 10:33:54 --> Language Class Initialized
INFO - 2022-06-04 10:33:54 --> Config Class Initialized
INFO - 2022-06-04 10:33:54 --> Loader Class Initialized
INFO - 2022-06-04 10:33:54 --> Helper loaded: url_helper
INFO - 2022-06-04 10:33:54 --> Helper loaded: file_helper
INFO - 2022-06-04 10:33:54 --> Helper loaded: form_helper
INFO - 2022-06-04 10:33:54 --> Helper loaded: my_helper
INFO - 2022-06-04 10:33:54 --> Database Driver Class Initialized
DEBUG - 2022-06-04 10:33:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-04 10:33:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-04 10:33:54 --> Controller Class Initialized
DEBUG - 2022-06-04 10:33:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-06-04 10:33:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-04 10:33:54 --> Final output sent to browser
DEBUG - 2022-06-04 10:33:54 --> Total execution time: 0.0748
INFO - 2022-06-04 10:34:02 --> Config Class Initialized
INFO - 2022-06-04 10:34:02 --> Hooks Class Initialized
DEBUG - 2022-06-04 10:34:02 --> UTF-8 Support Enabled
INFO - 2022-06-04 10:34:02 --> Utf8 Class Initialized
INFO - 2022-06-04 10:34:02 --> URI Class Initialized
INFO - 2022-06-04 10:34:02 --> Router Class Initialized
INFO - 2022-06-04 10:34:02 --> Output Class Initialized
INFO - 2022-06-04 10:34:02 --> Security Class Initialized
DEBUG - 2022-06-04 10:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-04 10:34:02 --> Input Class Initialized
INFO - 2022-06-04 10:34:02 --> Language Class Initialized
INFO - 2022-06-04 10:34:02 --> Language Class Initialized
INFO - 2022-06-04 10:34:02 --> Config Class Initialized
INFO - 2022-06-04 10:34:02 --> Loader Class Initialized
INFO - 2022-06-04 10:34:02 --> Helper loaded: url_helper
INFO - 2022-06-04 10:34:02 --> Helper loaded: file_helper
INFO - 2022-06-04 10:34:02 --> Helper loaded: form_helper
INFO - 2022-06-04 10:34:02 --> Helper loaded: my_helper
INFO - 2022-06-04 10:34:02 --> Database Driver Class Initialized
DEBUG - 2022-06-04 10:34:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-04 10:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-04 10:34:02 --> Controller Class Initialized
INFO - 2022-06-04 10:34:02 --> Final output sent to browser
DEBUG - 2022-06-04 10:34:02 --> Total execution time: 0.0815
INFO - 2022-06-04 10:34:05 --> Config Class Initialized
INFO - 2022-06-04 10:34:05 --> Hooks Class Initialized
DEBUG - 2022-06-04 10:34:05 --> UTF-8 Support Enabled
INFO - 2022-06-04 10:34:05 --> Utf8 Class Initialized
INFO - 2022-06-04 10:34:05 --> URI Class Initialized
INFO - 2022-06-04 10:34:05 --> Router Class Initialized
INFO - 2022-06-04 10:34:05 --> Output Class Initialized
INFO - 2022-06-04 10:34:05 --> Security Class Initialized
DEBUG - 2022-06-04 10:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-04 10:34:05 --> Input Class Initialized
INFO - 2022-06-04 10:34:05 --> Language Class Initialized
INFO - 2022-06-04 10:34:05 --> Language Class Initialized
INFO - 2022-06-04 10:34:05 --> Config Class Initialized
INFO - 2022-06-04 10:34:05 --> Loader Class Initialized
INFO - 2022-06-04 10:34:05 --> Helper loaded: url_helper
INFO - 2022-06-04 10:34:05 --> Helper loaded: file_helper
INFO - 2022-06-04 10:34:05 --> Helper loaded: form_helper
INFO - 2022-06-04 10:34:05 --> Helper loaded: my_helper
INFO - 2022-06-04 10:34:05 --> Database Driver Class Initialized
DEBUG - 2022-06-04 10:34:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-04 10:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-04 10:34:05 --> Controller Class Initialized
ERROR - 2022-06-04 10:34:05 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-04 10:34:05 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-04 10:34:05 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 161
ERROR - 2022-06-04 10:34:05 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
ERROR - 2022-06-04 10:34:05 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-04 10:34:05 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 158
ERROR - 2022-06-04 10:34:05 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
DEBUG - 2022-06-04 10:34:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2022-06-04 10:34:05 --> Final output sent to browser
DEBUG - 2022-06-04 10:34:05 --> Total execution time: 0.0734
INFO - 2022-06-04 10:36:05 --> Config Class Initialized
INFO - 2022-06-04 10:36:05 --> Hooks Class Initialized
DEBUG - 2022-06-04 10:36:05 --> UTF-8 Support Enabled
INFO - 2022-06-04 10:36:05 --> Utf8 Class Initialized
INFO - 2022-06-04 10:36:05 --> URI Class Initialized
INFO - 2022-06-04 10:36:05 --> Router Class Initialized
INFO - 2022-06-04 10:36:05 --> Output Class Initialized
INFO - 2022-06-04 10:36:05 --> Security Class Initialized
DEBUG - 2022-06-04 10:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-04 10:36:05 --> Input Class Initialized
INFO - 2022-06-04 10:36:05 --> Language Class Initialized
INFO - 2022-06-04 10:36:05 --> Language Class Initialized
INFO - 2022-06-04 10:36:05 --> Config Class Initialized
INFO - 2022-06-04 10:36:05 --> Loader Class Initialized
INFO - 2022-06-04 10:36:05 --> Helper loaded: url_helper
INFO - 2022-06-04 10:36:05 --> Helper loaded: file_helper
INFO - 2022-06-04 10:36:05 --> Helper loaded: form_helper
INFO - 2022-06-04 10:36:05 --> Helper loaded: my_helper
INFO - 2022-06-04 10:36:05 --> Database Driver Class Initialized
DEBUG - 2022-06-04 10:36:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-04 10:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-04 10:36:05 --> Controller Class Initialized
ERROR - 2022-06-04 10:36:05 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-04 10:36:05 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-04 10:36:05 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 161
ERROR - 2022-06-04 10:36:05 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
ERROR - 2022-06-04 10:36:05 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-04 10:36:05 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 158
ERROR - 2022-06-04 10:36:05 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
DEBUG - 2022-06-04 10:36:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2022-06-04 10:36:05 --> Final output sent to browser
DEBUG - 2022-06-04 10:36:05 --> Total execution time: 0.0827
INFO - 2022-06-04 10:36:05 --> Config Class Initialized
INFO - 2022-06-04 10:36:05 --> Hooks Class Initialized
DEBUG - 2022-06-04 10:36:05 --> UTF-8 Support Enabled
INFO - 2022-06-04 10:36:05 --> Utf8 Class Initialized
INFO - 2022-06-04 10:36:05 --> URI Class Initialized
INFO - 2022-06-04 10:36:05 --> Router Class Initialized
INFO - 2022-06-04 10:36:05 --> Output Class Initialized
INFO - 2022-06-04 10:36:05 --> Security Class Initialized
DEBUG - 2022-06-04 10:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-04 10:36:05 --> Input Class Initialized
INFO - 2022-06-04 10:36:05 --> Language Class Initialized
INFO - 2022-06-04 10:36:05 --> Language Class Initialized
INFO - 2022-06-04 10:36:05 --> Config Class Initialized
INFO - 2022-06-04 10:36:05 --> Loader Class Initialized
INFO - 2022-06-04 10:36:05 --> Helper loaded: url_helper
INFO - 2022-06-04 10:36:05 --> Helper loaded: file_helper
INFO - 2022-06-04 10:36:05 --> Helper loaded: form_helper
INFO - 2022-06-04 10:36:05 --> Helper loaded: my_helper
INFO - 2022-06-04 10:36:05 --> Database Driver Class Initialized
DEBUG - 2022-06-04 10:36:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-04 10:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-04 10:36:05 --> Controller Class Initialized
ERROR - 2022-06-04 10:36:06 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-04 10:36:06 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-04 10:36:06 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 161
ERROR - 2022-06-04 10:36:06 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
ERROR - 2022-06-04 10:36:06 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-04 10:36:06 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 158
ERROR - 2022-06-04 10:36:06 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
DEBUG - 2022-06-04 10:36:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2022-06-04 10:36:06 --> Final output sent to browser
DEBUG - 2022-06-04 10:36:06 --> Total execution time: 0.0965
INFO - 2022-06-04 10:37:33 --> Config Class Initialized
INFO - 2022-06-04 10:37:33 --> Hooks Class Initialized
DEBUG - 2022-06-04 10:37:33 --> UTF-8 Support Enabled
INFO - 2022-06-04 10:37:33 --> Utf8 Class Initialized
INFO - 2022-06-04 10:37:33 --> URI Class Initialized
INFO - 2022-06-04 10:37:33 --> Router Class Initialized
INFO - 2022-06-04 10:37:33 --> Output Class Initialized
INFO - 2022-06-04 10:37:33 --> Security Class Initialized
DEBUG - 2022-06-04 10:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-04 10:37:33 --> Input Class Initialized
INFO - 2022-06-04 10:37:33 --> Language Class Initialized
INFO - 2022-06-04 10:37:33 --> Language Class Initialized
INFO - 2022-06-04 10:37:33 --> Config Class Initialized
INFO - 2022-06-04 10:37:33 --> Loader Class Initialized
INFO - 2022-06-04 10:37:33 --> Helper loaded: url_helper
INFO - 2022-06-04 10:37:33 --> Helper loaded: file_helper
INFO - 2022-06-04 10:37:33 --> Helper loaded: form_helper
INFO - 2022-06-04 10:37:33 --> Helper loaded: my_helper
INFO - 2022-06-04 10:37:33 --> Database Driver Class Initialized
DEBUG - 2022-06-04 10:37:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-04 10:37:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-04 10:37:33 --> Controller Class Initialized
ERROR - 2022-06-04 10:37:33 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-04 10:37:33 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-04 10:37:33 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 161
ERROR - 2022-06-04 10:37:33 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
ERROR - 2022-06-04 10:37:33 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-04 10:37:33 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 158
ERROR - 2022-06-04 10:37:33 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
ERROR - 2022-06-04 10:37:33 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-04 10:37:33 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-04 10:37:33 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 161
ERROR - 2022-06-04 10:37:33 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
ERROR - 2022-06-04 10:37:33 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-04 10:37:33 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-04 10:37:33 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 160
ERROR - 2022-06-04 10:37:33 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
DEBUG - 2022-06-04 10:37:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2022-06-04 10:37:33 --> Final output sent to browser
DEBUG - 2022-06-04 10:37:33 --> Total execution time: 0.0718
