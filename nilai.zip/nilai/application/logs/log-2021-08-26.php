<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-08-26 05:49:19 --> Config Class Initialized
INFO - 2021-08-26 05:49:19 --> Hooks Class Initialized
DEBUG - 2021-08-26 05:49:19 --> UTF-8 Support Enabled
INFO - 2021-08-26 05:49:19 --> Utf8 Class Initialized
INFO - 2021-08-26 05:49:19 --> URI Class Initialized
INFO - 2021-08-26 05:49:19 --> Router Class Initialized
INFO - 2021-08-26 05:49:19 --> Output Class Initialized
INFO - 2021-08-26 05:49:19 --> Security Class Initialized
DEBUG - 2021-08-26 05:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 05:49:19 --> Input Class Initialized
INFO - 2021-08-26 05:49:19 --> Language Class Initialized
INFO - 2021-08-26 05:49:19 --> Language Class Initialized
INFO - 2021-08-26 05:49:19 --> Config Class Initialized
INFO - 2021-08-26 05:49:19 --> Loader Class Initialized
INFO - 2021-08-26 05:49:19 --> Helper loaded: url_helper
INFO - 2021-08-26 05:49:19 --> Helper loaded: file_helper
INFO - 2021-08-26 05:49:19 --> Helper loaded: form_helper
INFO - 2021-08-26 05:49:19 --> Helper loaded: my_helper
INFO - 2021-08-26 05:49:19 --> Database Driver Class Initialized
DEBUG - 2021-08-26 05:49:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 05:49:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 05:49:19 --> Controller Class Initialized
DEBUG - 2021-08-26 05:49:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-08-26 05:49:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-26 05:49:19 --> Final output sent to browser
DEBUG - 2021-08-26 05:49:19 --> Total execution time: 0.6665
INFO - 2021-08-26 05:52:31 --> Config Class Initialized
INFO - 2021-08-26 05:52:31 --> Hooks Class Initialized
DEBUG - 2021-08-26 05:52:31 --> UTF-8 Support Enabled
INFO - 2021-08-26 05:52:31 --> Utf8 Class Initialized
INFO - 2021-08-26 05:52:31 --> URI Class Initialized
INFO - 2021-08-26 05:52:31 --> Router Class Initialized
INFO - 2021-08-26 05:52:31 --> Output Class Initialized
INFO - 2021-08-26 05:52:31 --> Security Class Initialized
DEBUG - 2021-08-26 05:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 05:52:31 --> Input Class Initialized
INFO - 2021-08-26 05:52:31 --> Language Class Initialized
INFO - 2021-08-26 05:52:31 --> Language Class Initialized
INFO - 2021-08-26 05:52:31 --> Config Class Initialized
INFO - 2021-08-26 05:52:31 --> Loader Class Initialized
INFO - 2021-08-26 05:52:31 --> Helper loaded: url_helper
INFO - 2021-08-26 05:52:31 --> Helper loaded: file_helper
INFO - 2021-08-26 05:52:31 --> Helper loaded: form_helper
INFO - 2021-08-26 05:52:31 --> Helper loaded: my_helper
INFO - 2021-08-26 05:52:31 --> Database Driver Class Initialized
DEBUG - 2021-08-26 05:52:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 05:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 05:52:31 --> Controller Class Initialized
INFO - 2021-08-26 05:52:31 --> Helper loaded: cookie_helper
INFO - 2021-08-26 05:52:31 --> Final output sent to browser
DEBUG - 2021-08-26 05:52:31 --> Total execution time: 0.0892
INFO - 2021-08-26 05:52:31 --> Config Class Initialized
INFO - 2021-08-26 05:52:31 --> Hooks Class Initialized
DEBUG - 2021-08-26 05:52:31 --> UTF-8 Support Enabled
INFO - 2021-08-26 05:52:31 --> Utf8 Class Initialized
INFO - 2021-08-26 05:52:31 --> URI Class Initialized
INFO - 2021-08-26 05:52:31 --> Router Class Initialized
INFO - 2021-08-26 05:52:31 --> Output Class Initialized
INFO - 2021-08-26 05:52:31 --> Security Class Initialized
DEBUG - 2021-08-26 05:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 05:52:31 --> Input Class Initialized
INFO - 2021-08-26 05:52:31 --> Language Class Initialized
INFO - 2021-08-26 05:52:31 --> Language Class Initialized
INFO - 2021-08-26 05:52:31 --> Config Class Initialized
INFO - 2021-08-26 05:52:31 --> Loader Class Initialized
INFO - 2021-08-26 05:52:31 --> Helper loaded: url_helper
INFO - 2021-08-26 05:52:31 --> Helper loaded: file_helper
INFO - 2021-08-26 05:52:31 --> Helper loaded: form_helper
INFO - 2021-08-26 05:52:31 --> Helper loaded: my_helper
INFO - 2021-08-26 05:52:31 --> Database Driver Class Initialized
DEBUG - 2021-08-26 05:52:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 05:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 05:52:31 --> Controller Class Initialized
DEBUG - 2021-08-26 05:52:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-08-26 05:52:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-26 05:52:32 --> Final output sent to browser
DEBUG - 2021-08-26 05:52:32 --> Total execution time: 0.8061
INFO - 2021-08-26 05:52:50 --> Config Class Initialized
INFO - 2021-08-26 05:52:50 --> Hooks Class Initialized
DEBUG - 2021-08-26 05:52:50 --> UTF-8 Support Enabled
INFO - 2021-08-26 05:52:50 --> Utf8 Class Initialized
INFO - 2021-08-26 05:52:50 --> URI Class Initialized
INFO - 2021-08-26 05:52:50 --> Router Class Initialized
INFO - 2021-08-26 05:52:50 --> Output Class Initialized
INFO - 2021-08-26 05:52:50 --> Security Class Initialized
DEBUG - 2021-08-26 05:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 05:52:50 --> Input Class Initialized
INFO - 2021-08-26 05:52:50 --> Language Class Initialized
INFO - 2021-08-26 05:52:50 --> Language Class Initialized
INFO - 2021-08-26 05:52:50 --> Config Class Initialized
INFO - 2021-08-26 05:52:50 --> Loader Class Initialized
INFO - 2021-08-26 05:52:50 --> Helper loaded: url_helper
INFO - 2021-08-26 05:52:50 --> Helper loaded: file_helper
INFO - 2021-08-26 05:52:50 --> Helper loaded: form_helper
INFO - 2021-08-26 05:52:50 --> Helper loaded: my_helper
INFO - 2021-08-26 05:52:50 --> Database Driver Class Initialized
DEBUG - 2021-08-26 05:52:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 05:52:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 05:52:50 --> Controller Class Initialized
DEBUG - 2021-08-26 05:52:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-08-26 05:52:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-26 05:52:51 --> Final output sent to browser
DEBUG - 2021-08-26 05:52:51 --> Total execution time: 0.1387
INFO - 2021-08-26 05:52:55 --> Config Class Initialized
INFO - 2021-08-26 05:52:55 --> Hooks Class Initialized
DEBUG - 2021-08-26 05:52:55 --> UTF-8 Support Enabled
INFO - 2021-08-26 05:52:55 --> Utf8 Class Initialized
INFO - 2021-08-26 05:52:55 --> URI Class Initialized
INFO - 2021-08-26 05:52:55 --> Router Class Initialized
INFO - 2021-08-26 05:52:55 --> Output Class Initialized
INFO - 2021-08-26 05:52:55 --> Security Class Initialized
DEBUG - 2021-08-26 05:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 05:52:55 --> Input Class Initialized
INFO - 2021-08-26 05:52:55 --> Language Class Initialized
INFO - 2021-08-26 05:52:55 --> Language Class Initialized
INFO - 2021-08-26 05:52:55 --> Config Class Initialized
INFO - 2021-08-26 05:52:55 --> Loader Class Initialized
INFO - 2021-08-26 05:52:55 --> Helper loaded: url_helper
INFO - 2021-08-26 05:52:55 --> Helper loaded: file_helper
INFO - 2021-08-26 05:52:55 --> Helper loaded: form_helper
INFO - 2021-08-26 05:52:55 --> Helper loaded: my_helper
INFO - 2021-08-26 05:52:55 --> Database Driver Class Initialized
DEBUG - 2021-08-26 05:52:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 05:52:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 05:52:55 --> Controller Class Initialized
DEBUG - 2021-08-26 05:52:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-08-26 05:52:55 --> Final output sent to browser
DEBUG - 2021-08-26 05:52:55 --> Total execution time: 0.3059
INFO - 2021-08-26 05:54:20 --> Config Class Initialized
INFO - 2021-08-26 05:54:20 --> Hooks Class Initialized
DEBUG - 2021-08-26 05:54:20 --> UTF-8 Support Enabled
INFO - 2021-08-26 05:54:20 --> Utf8 Class Initialized
INFO - 2021-08-26 05:54:20 --> URI Class Initialized
INFO - 2021-08-26 05:54:20 --> Router Class Initialized
INFO - 2021-08-26 05:54:20 --> Output Class Initialized
INFO - 2021-08-26 05:54:20 --> Security Class Initialized
DEBUG - 2021-08-26 05:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 05:54:20 --> Input Class Initialized
INFO - 2021-08-26 05:54:20 --> Language Class Initialized
INFO - 2021-08-26 05:54:20 --> Language Class Initialized
INFO - 2021-08-26 05:54:20 --> Config Class Initialized
INFO - 2021-08-26 05:54:20 --> Loader Class Initialized
INFO - 2021-08-26 05:54:20 --> Helper loaded: url_helper
INFO - 2021-08-26 05:54:20 --> Helper loaded: file_helper
INFO - 2021-08-26 05:54:20 --> Helper loaded: form_helper
INFO - 2021-08-26 05:54:20 --> Helper loaded: my_helper
INFO - 2021-08-26 05:54:20 --> Database Driver Class Initialized
DEBUG - 2021-08-26 05:54:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 05:54:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 05:54:20 --> Controller Class Initialized
DEBUG - 2021-08-26 05:54:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-08-26 05:54:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-26 05:54:20 --> Final output sent to browser
DEBUG - 2021-08-26 05:54:20 --> Total execution time: 0.0963
INFO - 2021-08-26 05:54:26 --> Config Class Initialized
INFO - 2021-08-26 05:54:26 --> Hooks Class Initialized
DEBUG - 2021-08-26 05:54:26 --> UTF-8 Support Enabled
INFO - 2021-08-26 05:54:26 --> Utf8 Class Initialized
INFO - 2021-08-26 05:54:26 --> URI Class Initialized
INFO - 2021-08-26 05:54:26 --> Router Class Initialized
INFO - 2021-08-26 05:54:26 --> Output Class Initialized
INFO - 2021-08-26 05:54:26 --> Security Class Initialized
DEBUG - 2021-08-26 05:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 05:54:26 --> Input Class Initialized
INFO - 2021-08-26 05:54:26 --> Language Class Initialized
INFO - 2021-08-26 05:54:26 --> Language Class Initialized
INFO - 2021-08-26 05:54:26 --> Config Class Initialized
INFO - 2021-08-26 05:54:26 --> Loader Class Initialized
INFO - 2021-08-26 05:54:26 --> Helper loaded: url_helper
INFO - 2021-08-26 05:54:26 --> Helper loaded: file_helper
INFO - 2021-08-26 05:54:26 --> Helper loaded: form_helper
INFO - 2021-08-26 05:54:26 --> Helper loaded: my_helper
INFO - 2021-08-26 05:54:26 --> Database Driver Class Initialized
DEBUG - 2021-08-26 05:54:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 05:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 05:54:26 --> Controller Class Initialized
DEBUG - 2021-08-26 05:54:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tkj_xi.php
INFO - 2021-08-26 05:54:26 --> Final output sent to browser
DEBUG - 2021-08-26 05:54:26 --> Total execution time: 0.2067
INFO - 2021-08-26 05:54:59 --> Config Class Initialized
INFO - 2021-08-26 05:54:59 --> Hooks Class Initialized
DEBUG - 2021-08-26 05:54:59 --> UTF-8 Support Enabled
INFO - 2021-08-26 05:54:59 --> Utf8 Class Initialized
INFO - 2021-08-26 05:54:59 --> URI Class Initialized
INFO - 2021-08-26 05:54:59 --> Router Class Initialized
INFO - 2021-08-26 05:54:59 --> Output Class Initialized
INFO - 2021-08-26 05:54:59 --> Security Class Initialized
DEBUG - 2021-08-26 05:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 05:54:59 --> Input Class Initialized
INFO - 2021-08-26 05:54:59 --> Language Class Initialized
INFO - 2021-08-26 05:54:59 --> Language Class Initialized
INFO - 2021-08-26 05:54:59 --> Config Class Initialized
INFO - 2021-08-26 05:54:59 --> Loader Class Initialized
INFO - 2021-08-26 05:54:59 --> Helper loaded: url_helper
INFO - 2021-08-26 05:54:59 --> Helper loaded: file_helper
INFO - 2021-08-26 05:54:59 --> Helper loaded: form_helper
INFO - 2021-08-26 05:54:59 --> Helper loaded: my_helper
INFO - 2021-08-26 05:54:59 --> Database Driver Class Initialized
DEBUG - 2021-08-26 05:54:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 05:54:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 05:54:59 --> Controller Class Initialized
DEBUG - 2021-08-26 05:54:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-08-26 05:54:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-26 05:54:59 --> Final output sent to browser
DEBUG - 2021-08-26 05:54:59 --> Total execution time: 0.0558
INFO - 2021-08-26 05:55:16 --> Config Class Initialized
INFO - 2021-08-26 05:55:16 --> Hooks Class Initialized
DEBUG - 2021-08-26 05:55:16 --> UTF-8 Support Enabled
INFO - 2021-08-26 05:55:16 --> Utf8 Class Initialized
INFO - 2021-08-26 05:55:16 --> URI Class Initialized
INFO - 2021-08-26 05:55:16 --> Router Class Initialized
INFO - 2021-08-26 05:55:16 --> Output Class Initialized
INFO - 2021-08-26 05:55:16 --> Security Class Initialized
DEBUG - 2021-08-26 05:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 05:55:16 --> Input Class Initialized
INFO - 2021-08-26 05:55:16 --> Language Class Initialized
INFO - 2021-08-26 05:55:16 --> Language Class Initialized
INFO - 2021-08-26 05:55:16 --> Config Class Initialized
INFO - 2021-08-26 05:55:16 --> Loader Class Initialized
INFO - 2021-08-26 05:55:16 --> Helper loaded: url_helper
INFO - 2021-08-26 05:55:16 --> Helper loaded: file_helper
INFO - 2021-08-26 05:55:16 --> Helper loaded: form_helper
INFO - 2021-08-26 05:55:16 --> Helper loaded: my_helper
INFO - 2021-08-26 05:55:16 --> Database Driver Class Initialized
DEBUG - 2021-08-26 05:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 05:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 05:55:16 --> Controller Class Initialized
DEBUG - 2021-08-26 05:55:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-08-26 05:55:16 --> Final output sent to browser
DEBUG - 2021-08-26 05:55:16 --> Total execution time: 0.1481
INFO - 2021-08-26 05:55:20 --> Config Class Initialized
INFO - 2021-08-26 05:55:20 --> Hooks Class Initialized
DEBUG - 2021-08-26 05:55:20 --> UTF-8 Support Enabled
INFO - 2021-08-26 05:55:20 --> Utf8 Class Initialized
INFO - 2021-08-26 05:55:20 --> URI Class Initialized
INFO - 2021-08-26 05:55:20 --> Router Class Initialized
INFO - 2021-08-26 05:55:20 --> Output Class Initialized
INFO - 2021-08-26 05:55:20 --> Security Class Initialized
DEBUG - 2021-08-26 05:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 05:55:20 --> Input Class Initialized
INFO - 2021-08-26 05:55:20 --> Language Class Initialized
INFO - 2021-08-26 05:55:20 --> Language Class Initialized
INFO - 2021-08-26 05:55:20 --> Config Class Initialized
INFO - 2021-08-26 05:55:20 --> Loader Class Initialized
INFO - 2021-08-26 05:55:20 --> Helper loaded: url_helper
INFO - 2021-08-26 05:55:20 --> Helper loaded: file_helper
INFO - 2021-08-26 05:55:20 --> Helper loaded: form_helper
INFO - 2021-08-26 05:55:20 --> Helper loaded: my_helper
INFO - 2021-08-26 05:55:20 --> Database Driver Class Initialized
DEBUG - 2021-08-26 05:55:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 05:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 05:55:20 --> Controller Class Initialized
DEBUG - 2021-08-26 05:55:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-08-26 05:55:20 --> Final output sent to browser
DEBUG - 2021-08-26 05:55:20 --> Total execution time: 0.1328
INFO - 2021-08-26 05:55:23 --> Config Class Initialized
INFO - 2021-08-26 05:55:23 --> Hooks Class Initialized
DEBUG - 2021-08-26 05:55:23 --> UTF-8 Support Enabled
INFO - 2021-08-26 05:55:23 --> Utf8 Class Initialized
INFO - 2021-08-26 05:55:23 --> URI Class Initialized
INFO - 2021-08-26 05:55:23 --> Router Class Initialized
INFO - 2021-08-26 05:55:23 --> Output Class Initialized
INFO - 2021-08-26 05:55:23 --> Security Class Initialized
DEBUG - 2021-08-26 05:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 05:55:23 --> Input Class Initialized
INFO - 2021-08-26 05:55:23 --> Language Class Initialized
INFO - 2021-08-26 05:55:23 --> Language Class Initialized
INFO - 2021-08-26 05:55:23 --> Config Class Initialized
INFO - 2021-08-26 05:55:23 --> Loader Class Initialized
INFO - 2021-08-26 05:55:23 --> Helper loaded: url_helper
INFO - 2021-08-26 05:55:23 --> Helper loaded: file_helper
INFO - 2021-08-26 05:55:23 --> Helper loaded: form_helper
INFO - 2021-08-26 05:55:23 --> Helper loaded: my_helper
INFO - 2021-08-26 05:55:23 --> Database Driver Class Initialized
DEBUG - 2021-08-26 05:55:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 05:55:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 05:55:23 --> Controller Class Initialized
DEBUG - 2021-08-26 05:55:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-08-26 05:55:23 --> Final output sent to browser
DEBUG - 2021-08-26 05:55:23 --> Total execution time: 0.1526
INFO - 2021-08-26 05:55:25 --> Config Class Initialized
INFO - 2021-08-26 05:55:25 --> Hooks Class Initialized
DEBUG - 2021-08-26 05:55:25 --> UTF-8 Support Enabled
INFO - 2021-08-26 05:55:25 --> Utf8 Class Initialized
INFO - 2021-08-26 05:55:25 --> URI Class Initialized
INFO - 2021-08-26 05:55:25 --> Router Class Initialized
INFO - 2021-08-26 05:55:25 --> Output Class Initialized
INFO - 2021-08-26 05:55:25 --> Security Class Initialized
DEBUG - 2021-08-26 05:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 05:55:25 --> Input Class Initialized
INFO - 2021-08-26 05:55:25 --> Language Class Initialized
INFO - 2021-08-26 05:55:25 --> Language Class Initialized
INFO - 2021-08-26 05:55:25 --> Config Class Initialized
INFO - 2021-08-26 05:55:25 --> Loader Class Initialized
INFO - 2021-08-26 05:55:25 --> Helper loaded: url_helper
INFO - 2021-08-26 05:55:25 --> Helper loaded: file_helper
INFO - 2021-08-26 05:55:25 --> Helper loaded: form_helper
INFO - 2021-08-26 05:55:25 --> Helper loaded: my_helper
INFO - 2021-08-26 05:55:25 --> Database Driver Class Initialized
DEBUG - 2021-08-26 05:55:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 05:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 05:55:25 --> Controller Class Initialized
DEBUG - 2021-08-26 05:55:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-08-26 05:55:25 --> Final output sent to browser
DEBUG - 2021-08-26 05:55:25 --> Total execution time: 0.1291
INFO - 2021-08-26 05:55:33 --> Config Class Initialized
INFO - 2021-08-26 05:55:33 --> Hooks Class Initialized
DEBUG - 2021-08-26 05:55:33 --> UTF-8 Support Enabled
INFO - 2021-08-26 05:55:33 --> Utf8 Class Initialized
INFO - 2021-08-26 05:55:33 --> URI Class Initialized
INFO - 2021-08-26 05:55:33 --> Router Class Initialized
INFO - 2021-08-26 05:55:33 --> Output Class Initialized
INFO - 2021-08-26 05:55:33 --> Security Class Initialized
DEBUG - 2021-08-26 05:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 05:55:33 --> Input Class Initialized
INFO - 2021-08-26 05:55:33 --> Language Class Initialized
INFO - 2021-08-26 05:55:33 --> Language Class Initialized
INFO - 2021-08-26 05:55:33 --> Config Class Initialized
INFO - 2021-08-26 05:55:33 --> Loader Class Initialized
INFO - 2021-08-26 05:55:33 --> Helper loaded: url_helper
INFO - 2021-08-26 05:55:33 --> Helper loaded: file_helper
INFO - 2021-08-26 05:55:33 --> Helper loaded: form_helper
INFO - 2021-08-26 05:55:33 --> Helper loaded: my_helper
INFO - 2021-08-26 05:55:33 --> Database Driver Class Initialized
DEBUG - 2021-08-26 05:55:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 05:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 05:55:33 --> Controller Class Initialized
DEBUG - 2021-08-26 05:55:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-08-26 05:55:33 --> Final output sent to browser
DEBUG - 2021-08-26 05:55:33 --> Total execution time: 0.1465
INFO - 2021-08-26 05:55:35 --> Config Class Initialized
INFO - 2021-08-26 05:55:35 --> Hooks Class Initialized
DEBUG - 2021-08-26 05:55:35 --> UTF-8 Support Enabled
INFO - 2021-08-26 05:55:35 --> Utf8 Class Initialized
INFO - 2021-08-26 05:55:35 --> URI Class Initialized
INFO - 2021-08-26 05:55:35 --> Router Class Initialized
INFO - 2021-08-26 05:55:35 --> Output Class Initialized
INFO - 2021-08-26 05:55:35 --> Security Class Initialized
DEBUG - 2021-08-26 05:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 05:55:35 --> Input Class Initialized
INFO - 2021-08-26 05:55:35 --> Language Class Initialized
INFO - 2021-08-26 05:55:36 --> Language Class Initialized
INFO - 2021-08-26 05:55:36 --> Config Class Initialized
INFO - 2021-08-26 05:55:36 --> Loader Class Initialized
INFO - 2021-08-26 05:55:36 --> Helper loaded: url_helper
INFO - 2021-08-26 05:55:36 --> Helper loaded: file_helper
INFO - 2021-08-26 05:55:36 --> Helper loaded: form_helper
INFO - 2021-08-26 05:55:36 --> Helper loaded: my_helper
INFO - 2021-08-26 05:55:36 --> Database Driver Class Initialized
DEBUG - 2021-08-26 05:55:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 05:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 05:55:36 --> Controller Class Initialized
DEBUG - 2021-08-26 05:55:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-08-26 05:55:36 --> Final output sent to browser
DEBUG - 2021-08-26 05:55:36 --> Total execution time: 0.1291
INFO - 2021-08-26 05:55:41 --> Config Class Initialized
INFO - 2021-08-26 05:55:41 --> Hooks Class Initialized
DEBUG - 2021-08-26 05:55:41 --> UTF-8 Support Enabled
INFO - 2021-08-26 05:55:41 --> Utf8 Class Initialized
INFO - 2021-08-26 05:55:41 --> URI Class Initialized
INFO - 2021-08-26 05:55:41 --> Router Class Initialized
INFO - 2021-08-26 05:55:41 --> Output Class Initialized
INFO - 2021-08-26 05:55:41 --> Security Class Initialized
DEBUG - 2021-08-26 05:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 05:55:41 --> Input Class Initialized
INFO - 2021-08-26 05:55:41 --> Language Class Initialized
INFO - 2021-08-26 05:55:41 --> Language Class Initialized
INFO - 2021-08-26 05:55:41 --> Config Class Initialized
INFO - 2021-08-26 05:55:41 --> Loader Class Initialized
INFO - 2021-08-26 05:55:41 --> Helper loaded: url_helper
INFO - 2021-08-26 05:55:41 --> Helper loaded: file_helper
INFO - 2021-08-26 05:55:41 --> Helper loaded: form_helper
INFO - 2021-08-26 05:55:41 --> Helper loaded: my_helper
INFO - 2021-08-26 05:55:41 --> Database Driver Class Initialized
DEBUG - 2021-08-26 05:55:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 05:55:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 05:55:41 --> Controller Class Initialized
DEBUG - 2021-08-26 05:55:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-08-26 05:55:41 --> Final output sent to browser
DEBUG - 2021-08-26 05:55:41 --> Total execution time: 0.1479
INFO - 2021-08-26 05:55:43 --> Config Class Initialized
INFO - 2021-08-26 05:55:43 --> Hooks Class Initialized
DEBUG - 2021-08-26 05:55:43 --> UTF-8 Support Enabled
INFO - 2021-08-26 05:55:43 --> Utf8 Class Initialized
INFO - 2021-08-26 05:55:43 --> URI Class Initialized
INFO - 2021-08-26 05:55:43 --> Router Class Initialized
INFO - 2021-08-26 05:55:43 --> Output Class Initialized
INFO - 2021-08-26 05:55:43 --> Security Class Initialized
DEBUG - 2021-08-26 05:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 05:55:43 --> Input Class Initialized
INFO - 2021-08-26 05:55:43 --> Language Class Initialized
INFO - 2021-08-26 05:55:43 --> Language Class Initialized
INFO - 2021-08-26 05:55:43 --> Config Class Initialized
INFO - 2021-08-26 05:55:43 --> Loader Class Initialized
INFO - 2021-08-26 05:55:43 --> Helper loaded: url_helper
INFO - 2021-08-26 05:55:43 --> Helper loaded: file_helper
INFO - 2021-08-26 05:55:43 --> Helper loaded: form_helper
INFO - 2021-08-26 05:55:43 --> Helper loaded: my_helper
INFO - 2021-08-26 05:55:43 --> Database Driver Class Initialized
DEBUG - 2021-08-26 05:55:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 05:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 05:55:43 --> Controller Class Initialized
DEBUG - 2021-08-26 05:55:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-08-26 05:55:43 --> Final output sent to browser
DEBUG - 2021-08-26 05:55:43 --> Total execution time: 0.1292
INFO - 2021-08-26 05:55:45 --> Config Class Initialized
INFO - 2021-08-26 05:55:45 --> Hooks Class Initialized
DEBUG - 2021-08-26 05:55:45 --> UTF-8 Support Enabled
INFO - 2021-08-26 05:55:45 --> Utf8 Class Initialized
INFO - 2021-08-26 05:55:45 --> URI Class Initialized
INFO - 2021-08-26 05:55:45 --> Router Class Initialized
INFO - 2021-08-26 05:55:45 --> Output Class Initialized
INFO - 2021-08-26 05:55:45 --> Security Class Initialized
DEBUG - 2021-08-26 05:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 05:55:45 --> Input Class Initialized
INFO - 2021-08-26 05:55:45 --> Language Class Initialized
INFO - 2021-08-26 05:55:45 --> Language Class Initialized
INFO - 2021-08-26 05:55:45 --> Config Class Initialized
INFO - 2021-08-26 05:55:45 --> Loader Class Initialized
INFO - 2021-08-26 05:55:45 --> Helper loaded: url_helper
INFO - 2021-08-26 05:55:45 --> Helper loaded: file_helper
INFO - 2021-08-26 05:55:45 --> Helper loaded: form_helper
INFO - 2021-08-26 05:55:45 --> Helper loaded: my_helper
INFO - 2021-08-26 05:55:45 --> Database Driver Class Initialized
DEBUG - 2021-08-26 05:55:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 05:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 05:55:45 --> Controller Class Initialized
DEBUG - 2021-08-26 05:55:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-08-26 05:55:45 --> Final output sent to browser
DEBUG - 2021-08-26 05:55:45 --> Total execution time: 0.1559
INFO - 2021-08-26 05:55:47 --> Config Class Initialized
INFO - 2021-08-26 05:55:47 --> Hooks Class Initialized
DEBUG - 2021-08-26 05:55:47 --> UTF-8 Support Enabled
INFO - 2021-08-26 05:55:47 --> Utf8 Class Initialized
INFO - 2021-08-26 05:55:47 --> URI Class Initialized
INFO - 2021-08-26 05:55:47 --> Router Class Initialized
INFO - 2021-08-26 05:55:47 --> Output Class Initialized
INFO - 2021-08-26 05:55:47 --> Security Class Initialized
DEBUG - 2021-08-26 05:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 05:55:47 --> Input Class Initialized
INFO - 2021-08-26 05:55:47 --> Language Class Initialized
INFO - 2021-08-26 05:55:47 --> Language Class Initialized
INFO - 2021-08-26 05:55:47 --> Config Class Initialized
INFO - 2021-08-26 05:55:47 --> Loader Class Initialized
INFO - 2021-08-26 05:55:47 --> Helper loaded: url_helper
INFO - 2021-08-26 05:55:47 --> Helper loaded: file_helper
INFO - 2021-08-26 05:55:47 --> Helper loaded: form_helper
INFO - 2021-08-26 05:55:47 --> Helper loaded: my_helper
INFO - 2021-08-26 05:55:47 --> Database Driver Class Initialized
DEBUG - 2021-08-26 05:55:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 05:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 05:55:47 --> Controller Class Initialized
DEBUG - 2021-08-26 05:55:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-08-26 05:55:47 --> Final output sent to browser
DEBUG - 2021-08-26 05:55:47 --> Total execution time: 0.1355
INFO - 2021-08-26 05:55:51 --> Config Class Initialized
INFO - 2021-08-26 05:55:51 --> Hooks Class Initialized
DEBUG - 2021-08-26 05:55:51 --> UTF-8 Support Enabled
INFO - 2021-08-26 05:55:51 --> Utf8 Class Initialized
INFO - 2021-08-26 05:55:51 --> URI Class Initialized
INFO - 2021-08-26 05:55:51 --> Router Class Initialized
INFO - 2021-08-26 05:55:51 --> Output Class Initialized
INFO - 2021-08-26 05:55:51 --> Security Class Initialized
DEBUG - 2021-08-26 05:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 05:55:51 --> Input Class Initialized
INFO - 2021-08-26 05:55:51 --> Language Class Initialized
INFO - 2021-08-26 05:55:51 --> Language Class Initialized
INFO - 2021-08-26 05:55:51 --> Config Class Initialized
INFO - 2021-08-26 05:55:51 --> Loader Class Initialized
INFO - 2021-08-26 05:55:51 --> Helper loaded: url_helper
INFO - 2021-08-26 05:55:51 --> Helper loaded: file_helper
INFO - 2021-08-26 05:55:51 --> Helper loaded: form_helper
INFO - 2021-08-26 05:55:51 --> Helper loaded: my_helper
INFO - 2021-08-26 05:55:51 --> Database Driver Class Initialized
DEBUG - 2021-08-26 05:55:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 05:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 05:55:51 --> Controller Class Initialized
DEBUG - 2021-08-26 05:55:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-08-26 05:55:51 --> Final output sent to browser
DEBUG - 2021-08-26 05:55:51 --> Total execution time: 0.1494
INFO - 2021-08-26 05:55:52 --> Config Class Initialized
INFO - 2021-08-26 05:55:52 --> Hooks Class Initialized
DEBUG - 2021-08-26 05:55:52 --> UTF-8 Support Enabled
INFO - 2021-08-26 05:55:52 --> Utf8 Class Initialized
INFO - 2021-08-26 05:55:52 --> URI Class Initialized
INFO - 2021-08-26 05:55:52 --> Router Class Initialized
INFO - 2021-08-26 05:55:52 --> Output Class Initialized
INFO - 2021-08-26 05:55:52 --> Security Class Initialized
DEBUG - 2021-08-26 05:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 05:55:52 --> Input Class Initialized
INFO - 2021-08-26 05:55:52 --> Language Class Initialized
INFO - 2021-08-26 05:55:52 --> Language Class Initialized
INFO - 2021-08-26 05:55:52 --> Config Class Initialized
INFO - 2021-08-26 05:55:52 --> Loader Class Initialized
INFO - 2021-08-26 05:55:52 --> Helper loaded: url_helper
INFO - 2021-08-26 05:55:52 --> Helper loaded: file_helper
INFO - 2021-08-26 05:55:52 --> Helper loaded: form_helper
INFO - 2021-08-26 05:55:52 --> Helper loaded: my_helper
INFO - 2021-08-26 05:55:52 --> Database Driver Class Initialized
DEBUG - 2021-08-26 05:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 05:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 05:55:52 --> Controller Class Initialized
DEBUG - 2021-08-26 05:55:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-08-26 05:55:53 --> Final output sent to browser
DEBUG - 2021-08-26 05:55:53 --> Total execution time: 0.1284
INFO - 2021-08-26 05:55:55 --> Config Class Initialized
INFO - 2021-08-26 05:55:55 --> Hooks Class Initialized
DEBUG - 2021-08-26 05:55:55 --> UTF-8 Support Enabled
INFO - 2021-08-26 05:55:55 --> Utf8 Class Initialized
INFO - 2021-08-26 05:55:55 --> URI Class Initialized
INFO - 2021-08-26 05:55:55 --> Router Class Initialized
INFO - 2021-08-26 05:55:55 --> Output Class Initialized
INFO - 2021-08-26 05:55:55 --> Security Class Initialized
DEBUG - 2021-08-26 05:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 05:55:55 --> Input Class Initialized
INFO - 2021-08-26 05:55:55 --> Language Class Initialized
INFO - 2021-08-26 05:55:55 --> Language Class Initialized
INFO - 2021-08-26 05:55:55 --> Config Class Initialized
INFO - 2021-08-26 05:55:55 --> Loader Class Initialized
INFO - 2021-08-26 05:55:55 --> Helper loaded: url_helper
INFO - 2021-08-26 05:55:55 --> Helper loaded: file_helper
INFO - 2021-08-26 05:55:55 --> Helper loaded: form_helper
INFO - 2021-08-26 05:55:55 --> Helper loaded: my_helper
INFO - 2021-08-26 05:55:55 --> Database Driver Class Initialized
DEBUG - 2021-08-26 05:55:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 05:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 05:55:55 --> Controller Class Initialized
DEBUG - 2021-08-26 05:55:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-08-26 05:55:55 --> Final output sent to browser
DEBUG - 2021-08-26 05:55:55 --> Total execution time: 0.1436
INFO - 2021-08-26 05:55:58 --> Config Class Initialized
INFO - 2021-08-26 05:55:58 --> Hooks Class Initialized
DEBUG - 2021-08-26 05:55:58 --> UTF-8 Support Enabled
INFO - 2021-08-26 05:55:58 --> Utf8 Class Initialized
INFO - 2021-08-26 05:55:58 --> URI Class Initialized
INFO - 2021-08-26 05:55:58 --> Router Class Initialized
INFO - 2021-08-26 05:55:58 --> Output Class Initialized
INFO - 2021-08-26 05:55:58 --> Security Class Initialized
DEBUG - 2021-08-26 05:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 05:55:58 --> Input Class Initialized
INFO - 2021-08-26 05:55:58 --> Language Class Initialized
INFO - 2021-08-26 05:55:58 --> Language Class Initialized
INFO - 2021-08-26 05:55:58 --> Config Class Initialized
INFO - 2021-08-26 05:55:58 --> Loader Class Initialized
INFO - 2021-08-26 05:55:58 --> Helper loaded: url_helper
INFO - 2021-08-26 05:55:58 --> Helper loaded: file_helper
INFO - 2021-08-26 05:55:58 --> Helper loaded: form_helper
INFO - 2021-08-26 05:55:58 --> Helper loaded: my_helper
INFO - 2021-08-26 05:55:58 --> Database Driver Class Initialized
DEBUG - 2021-08-26 05:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 05:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 05:55:58 --> Controller Class Initialized
DEBUG - 2021-08-26 05:55:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-08-26 05:55:59 --> Final output sent to browser
DEBUG - 2021-08-26 05:55:59 --> Total execution time: 0.1280
INFO - 2021-08-26 05:56:00 --> Config Class Initialized
INFO - 2021-08-26 05:56:00 --> Hooks Class Initialized
DEBUG - 2021-08-26 05:56:00 --> UTF-8 Support Enabled
INFO - 2021-08-26 05:56:00 --> Utf8 Class Initialized
INFO - 2021-08-26 05:56:00 --> URI Class Initialized
INFO - 2021-08-26 05:56:00 --> Router Class Initialized
INFO - 2021-08-26 05:56:00 --> Output Class Initialized
INFO - 2021-08-26 05:56:00 --> Security Class Initialized
DEBUG - 2021-08-26 05:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 05:56:00 --> Input Class Initialized
INFO - 2021-08-26 05:56:00 --> Language Class Initialized
INFO - 2021-08-26 05:56:00 --> Language Class Initialized
INFO - 2021-08-26 05:56:00 --> Config Class Initialized
INFO - 2021-08-26 05:56:00 --> Loader Class Initialized
INFO - 2021-08-26 05:56:00 --> Helper loaded: url_helper
INFO - 2021-08-26 05:56:00 --> Helper loaded: file_helper
INFO - 2021-08-26 05:56:00 --> Helper loaded: form_helper
INFO - 2021-08-26 05:56:00 --> Helper loaded: my_helper
INFO - 2021-08-26 05:56:00 --> Database Driver Class Initialized
DEBUG - 2021-08-26 05:56:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 05:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 05:56:00 --> Controller Class Initialized
DEBUG - 2021-08-26 05:56:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-08-26 05:56:00 --> Final output sent to browser
DEBUG - 2021-08-26 05:56:00 --> Total execution time: 0.1497
INFO - 2021-08-26 05:56:02 --> Config Class Initialized
INFO - 2021-08-26 05:56:02 --> Hooks Class Initialized
DEBUG - 2021-08-26 05:56:02 --> UTF-8 Support Enabled
INFO - 2021-08-26 05:56:02 --> Utf8 Class Initialized
INFO - 2021-08-26 05:56:02 --> URI Class Initialized
INFO - 2021-08-26 05:56:02 --> Router Class Initialized
INFO - 2021-08-26 05:56:02 --> Output Class Initialized
INFO - 2021-08-26 05:56:02 --> Security Class Initialized
DEBUG - 2021-08-26 05:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 05:56:02 --> Input Class Initialized
INFO - 2021-08-26 05:56:02 --> Language Class Initialized
INFO - 2021-08-26 05:56:02 --> Language Class Initialized
INFO - 2021-08-26 05:56:02 --> Config Class Initialized
INFO - 2021-08-26 05:56:02 --> Loader Class Initialized
INFO - 2021-08-26 05:56:02 --> Helper loaded: url_helper
INFO - 2021-08-26 05:56:02 --> Helper loaded: file_helper
INFO - 2021-08-26 05:56:02 --> Helper loaded: form_helper
INFO - 2021-08-26 05:56:02 --> Helper loaded: my_helper
INFO - 2021-08-26 05:56:02 --> Database Driver Class Initialized
DEBUG - 2021-08-26 05:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 05:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 05:56:02 --> Controller Class Initialized
DEBUG - 2021-08-26 05:56:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-08-26 05:56:02 --> Final output sent to browser
DEBUG - 2021-08-26 05:56:02 --> Total execution time: 0.1308
INFO - 2021-08-26 05:56:06 --> Config Class Initialized
INFO - 2021-08-26 05:56:06 --> Hooks Class Initialized
DEBUG - 2021-08-26 05:56:06 --> UTF-8 Support Enabled
INFO - 2021-08-26 05:56:06 --> Utf8 Class Initialized
INFO - 2021-08-26 05:56:06 --> URI Class Initialized
INFO - 2021-08-26 05:56:06 --> Router Class Initialized
INFO - 2021-08-26 05:56:06 --> Output Class Initialized
INFO - 2021-08-26 05:56:06 --> Security Class Initialized
DEBUG - 2021-08-26 05:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 05:56:06 --> Input Class Initialized
INFO - 2021-08-26 05:56:06 --> Language Class Initialized
INFO - 2021-08-26 05:56:06 --> Language Class Initialized
INFO - 2021-08-26 05:56:06 --> Config Class Initialized
INFO - 2021-08-26 05:56:06 --> Loader Class Initialized
INFO - 2021-08-26 05:56:06 --> Helper loaded: url_helper
INFO - 2021-08-26 05:56:06 --> Helper loaded: file_helper
INFO - 2021-08-26 05:56:06 --> Helper loaded: form_helper
INFO - 2021-08-26 05:56:06 --> Helper loaded: my_helper
INFO - 2021-08-26 05:56:06 --> Database Driver Class Initialized
DEBUG - 2021-08-26 05:56:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 05:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 05:56:06 --> Controller Class Initialized
DEBUG - 2021-08-26 05:56:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-08-26 05:56:06 --> Final output sent to browser
DEBUG - 2021-08-26 05:56:06 --> Total execution time: 0.1435
INFO - 2021-08-26 05:56:07 --> Config Class Initialized
INFO - 2021-08-26 05:56:07 --> Hooks Class Initialized
DEBUG - 2021-08-26 05:56:07 --> UTF-8 Support Enabled
INFO - 2021-08-26 05:56:07 --> Utf8 Class Initialized
INFO - 2021-08-26 05:56:07 --> URI Class Initialized
INFO - 2021-08-26 05:56:07 --> Router Class Initialized
INFO - 2021-08-26 05:56:07 --> Output Class Initialized
INFO - 2021-08-26 05:56:07 --> Security Class Initialized
DEBUG - 2021-08-26 05:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 05:56:07 --> Input Class Initialized
INFO - 2021-08-26 05:56:07 --> Language Class Initialized
INFO - 2021-08-26 05:56:07 --> Language Class Initialized
INFO - 2021-08-26 05:56:07 --> Config Class Initialized
INFO - 2021-08-26 05:56:07 --> Loader Class Initialized
INFO - 2021-08-26 05:56:07 --> Helper loaded: url_helper
INFO - 2021-08-26 05:56:07 --> Helper loaded: file_helper
INFO - 2021-08-26 05:56:07 --> Helper loaded: form_helper
INFO - 2021-08-26 05:56:07 --> Helper loaded: my_helper
INFO - 2021-08-26 05:56:07 --> Database Driver Class Initialized
DEBUG - 2021-08-26 05:56:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 05:56:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 05:56:07 --> Controller Class Initialized
DEBUG - 2021-08-26 05:56:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-08-26 05:56:07 --> Final output sent to browser
DEBUG - 2021-08-26 05:56:07 --> Total execution time: 0.1284
INFO - 2021-08-26 05:56:10 --> Config Class Initialized
INFO - 2021-08-26 05:56:10 --> Hooks Class Initialized
DEBUG - 2021-08-26 05:56:10 --> UTF-8 Support Enabled
INFO - 2021-08-26 05:56:10 --> Utf8 Class Initialized
INFO - 2021-08-26 05:56:10 --> URI Class Initialized
INFO - 2021-08-26 05:56:10 --> Router Class Initialized
INFO - 2021-08-26 05:56:10 --> Output Class Initialized
INFO - 2021-08-26 05:56:10 --> Security Class Initialized
DEBUG - 2021-08-26 05:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 05:56:10 --> Input Class Initialized
INFO - 2021-08-26 05:56:10 --> Language Class Initialized
INFO - 2021-08-26 05:56:10 --> Language Class Initialized
INFO - 2021-08-26 05:56:10 --> Config Class Initialized
INFO - 2021-08-26 05:56:10 --> Loader Class Initialized
INFO - 2021-08-26 05:56:10 --> Helper loaded: url_helper
INFO - 2021-08-26 05:56:10 --> Helper loaded: file_helper
INFO - 2021-08-26 05:56:10 --> Helper loaded: form_helper
INFO - 2021-08-26 05:56:10 --> Helper loaded: my_helper
INFO - 2021-08-26 05:56:10 --> Database Driver Class Initialized
DEBUG - 2021-08-26 05:56:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 05:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 05:56:10 --> Controller Class Initialized
DEBUG - 2021-08-26 05:56:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-08-26 05:56:10 --> Final output sent to browser
DEBUG - 2021-08-26 05:56:10 --> Total execution time: 0.1465
INFO - 2021-08-26 05:56:13 --> Config Class Initialized
INFO - 2021-08-26 05:56:13 --> Hooks Class Initialized
DEBUG - 2021-08-26 05:56:13 --> UTF-8 Support Enabled
INFO - 2021-08-26 05:56:13 --> Utf8 Class Initialized
INFO - 2021-08-26 05:56:13 --> URI Class Initialized
INFO - 2021-08-26 05:56:13 --> Router Class Initialized
INFO - 2021-08-26 05:56:13 --> Output Class Initialized
INFO - 2021-08-26 05:56:13 --> Security Class Initialized
DEBUG - 2021-08-26 05:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 05:56:13 --> Input Class Initialized
INFO - 2021-08-26 05:56:13 --> Language Class Initialized
INFO - 2021-08-26 05:56:13 --> Language Class Initialized
INFO - 2021-08-26 05:56:13 --> Config Class Initialized
INFO - 2021-08-26 05:56:13 --> Loader Class Initialized
INFO - 2021-08-26 05:56:13 --> Helper loaded: url_helper
INFO - 2021-08-26 05:56:13 --> Helper loaded: file_helper
INFO - 2021-08-26 05:56:13 --> Helper loaded: form_helper
INFO - 2021-08-26 05:56:13 --> Helper loaded: my_helper
INFO - 2021-08-26 05:56:13 --> Database Driver Class Initialized
DEBUG - 2021-08-26 05:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 05:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 05:56:13 --> Controller Class Initialized
DEBUG - 2021-08-26 05:56:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-08-26 05:56:13 --> Final output sent to browser
DEBUG - 2021-08-26 05:56:13 --> Total execution time: 0.1296
INFO - 2021-08-26 05:56:15 --> Config Class Initialized
INFO - 2021-08-26 05:56:15 --> Hooks Class Initialized
DEBUG - 2021-08-26 05:56:15 --> UTF-8 Support Enabled
INFO - 2021-08-26 05:56:15 --> Utf8 Class Initialized
INFO - 2021-08-26 05:56:15 --> URI Class Initialized
INFO - 2021-08-26 05:56:15 --> Router Class Initialized
INFO - 2021-08-26 05:56:15 --> Output Class Initialized
INFO - 2021-08-26 05:56:15 --> Security Class Initialized
DEBUG - 2021-08-26 05:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 05:56:15 --> Input Class Initialized
INFO - 2021-08-26 05:56:15 --> Language Class Initialized
INFO - 2021-08-26 05:56:15 --> Language Class Initialized
INFO - 2021-08-26 05:56:15 --> Config Class Initialized
INFO - 2021-08-26 05:56:15 --> Loader Class Initialized
INFO - 2021-08-26 05:56:15 --> Helper loaded: url_helper
INFO - 2021-08-26 05:56:15 --> Helper loaded: file_helper
INFO - 2021-08-26 05:56:15 --> Helper loaded: form_helper
INFO - 2021-08-26 05:56:15 --> Helper loaded: my_helper
INFO - 2021-08-26 05:56:15 --> Database Driver Class Initialized
DEBUG - 2021-08-26 05:56:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 05:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 05:56:15 --> Controller Class Initialized
DEBUG - 2021-08-26 05:56:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-08-26 05:56:15 --> Final output sent to browser
DEBUG - 2021-08-26 05:56:15 --> Total execution time: 0.1479
INFO - 2021-08-26 05:56:17 --> Config Class Initialized
INFO - 2021-08-26 05:56:17 --> Hooks Class Initialized
DEBUG - 2021-08-26 05:56:17 --> UTF-8 Support Enabled
INFO - 2021-08-26 05:56:17 --> Utf8 Class Initialized
INFO - 2021-08-26 05:56:17 --> URI Class Initialized
INFO - 2021-08-26 05:56:17 --> Router Class Initialized
INFO - 2021-08-26 05:56:17 --> Output Class Initialized
INFO - 2021-08-26 05:56:17 --> Security Class Initialized
DEBUG - 2021-08-26 05:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 05:56:17 --> Input Class Initialized
INFO - 2021-08-26 05:56:17 --> Language Class Initialized
INFO - 2021-08-26 05:56:17 --> Language Class Initialized
INFO - 2021-08-26 05:56:17 --> Config Class Initialized
INFO - 2021-08-26 05:56:17 --> Loader Class Initialized
INFO - 2021-08-26 05:56:17 --> Helper loaded: url_helper
INFO - 2021-08-26 05:56:17 --> Helper loaded: file_helper
INFO - 2021-08-26 05:56:17 --> Helper loaded: form_helper
INFO - 2021-08-26 05:56:17 --> Helper loaded: my_helper
INFO - 2021-08-26 05:56:17 --> Database Driver Class Initialized
DEBUG - 2021-08-26 05:56:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 05:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 05:56:17 --> Controller Class Initialized
DEBUG - 2021-08-26 05:56:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-08-26 05:56:17 --> Final output sent to browser
DEBUG - 2021-08-26 05:56:17 --> Total execution time: 0.1277
INFO - 2021-08-26 05:56:21 --> Config Class Initialized
INFO - 2021-08-26 05:56:21 --> Hooks Class Initialized
DEBUG - 2021-08-26 05:56:21 --> UTF-8 Support Enabled
INFO - 2021-08-26 05:56:21 --> Utf8 Class Initialized
INFO - 2021-08-26 05:56:21 --> URI Class Initialized
INFO - 2021-08-26 05:56:21 --> Router Class Initialized
INFO - 2021-08-26 05:56:21 --> Output Class Initialized
INFO - 2021-08-26 05:56:21 --> Security Class Initialized
DEBUG - 2021-08-26 05:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 05:56:21 --> Input Class Initialized
INFO - 2021-08-26 05:56:21 --> Language Class Initialized
INFO - 2021-08-26 05:56:21 --> Language Class Initialized
INFO - 2021-08-26 05:56:21 --> Config Class Initialized
INFO - 2021-08-26 05:56:21 --> Loader Class Initialized
INFO - 2021-08-26 05:56:21 --> Helper loaded: url_helper
INFO - 2021-08-26 05:56:21 --> Helper loaded: file_helper
INFO - 2021-08-26 05:56:21 --> Helper loaded: form_helper
INFO - 2021-08-26 05:56:21 --> Helper loaded: my_helper
INFO - 2021-08-26 05:56:21 --> Database Driver Class Initialized
DEBUG - 2021-08-26 05:56:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 05:56:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 05:56:21 --> Controller Class Initialized
DEBUG - 2021-08-26 05:56:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-08-26 05:56:21 --> Final output sent to browser
DEBUG - 2021-08-26 05:56:21 --> Total execution time: 0.1458
INFO - 2021-08-26 05:56:23 --> Config Class Initialized
INFO - 2021-08-26 05:56:23 --> Hooks Class Initialized
DEBUG - 2021-08-26 05:56:23 --> UTF-8 Support Enabled
INFO - 2021-08-26 05:56:23 --> Utf8 Class Initialized
INFO - 2021-08-26 05:56:23 --> URI Class Initialized
INFO - 2021-08-26 05:56:23 --> Router Class Initialized
INFO - 2021-08-26 05:56:23 --> Output Class Initialized
INFO - 2021-08-26 05:56:23 --> Security Class Initialized
DEBUG - 2021-08-26 05:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 05:56:23 --> Input Class Initialized
INFO - 2021-08-26 05:56:23 --> Language Class Initialized
INFO - 2021-08-26 05:56:23 --> Language Class Initialized
INFO - 2021-08-26 05:56:23 --> Config Class Initialized
INFO - 2021-08-26 05:56:23 --> Loader Class Initialized
INFO - 2021-08-26 05:56:23 --> Helper loaded: url_helper
INFO - 2021-08-26 05:56:23 --> Helper loaded: file_helper
INFO - 2021-08-26 05:56:23 --> Helper loaded: form_helper
INFO - 2021-08-26 05:56:23 --> Helper loaded: my_helper
INFO - 2021-08-26 05:56:23 --> Database Driver Class Initialized
DEBUG - 2021-08-26 05:56:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 05:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 05:56:23 --> Controller Class Initialized
DEBUG - 2021-08-26 05:56:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-08-26 05:56:23 --> Final output sent to browser
DEBUG - 2021-08-26 05:56:23 --> Total execution time: 0.1311
INFO - 2021-08-26 05:56:26 --> Config Class Initialized
INFO - 2021-08-26 05:56:26 --> Hooks Class Initialized
DEBUG - 2021-08-26 05:56:26 --> UTF-8 Support Enabled
INFO - 2021-08-26 05:56:26 --> Utf8 Class Initialized
INFO - 2021-08-26 05:56:26 --> URI Class Initialized
INFO - 2021-08-26 05:56:26 --> Router Class Initialized
INFO - 2021-08-26 05:56:26 --> Output Class Initialized
INFO - 2021-08-26 05:56:26 --> Security Class Initialized
DEBUG - 2021-08-26 05:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 05:56:26 --> Input Class Initialized
INFO - 2021-08-26 05:56:26 --> Language Class Initialized
INFO - 2021-08-26 05:56:26 --> Language Class Initialized
INFO - 2021-08-26 05:56:26 --> Config Class Initialized
INFO - 2021-08-26 05:56:26 --> Loader Class Initialized
INFO - 2021-08-26 05:56:26 --> Helper loaded: url_helper
INFO - 2021-08-26 05:56:26 --> Helper loaded: file_helper
INFO - 2021-08-26 05:56:26 --> Helper loaded: form_helper
INFO - 2021-08-26 05:56:26 --> Helper loaded: my_helper
INFO - 2021-08-26 05:56:26 --> Database Driver Class Initialized
DEBUG - 2021-08-26 05:56:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 05:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 05:56:26 --> Controller Class Initialized
DEBUG - 2021-08-26 05:56:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-08-26 05:56:26 --> Final output sent to browser
DEBUG - 2021-08-26 05:56:26 --> Total execution time: 0.1472
INFO - 2021-08-26 05:56:29 --> Config Class Initialized
INFO - 2021-08-26 05:56:29 --> Hooks Class Initialized
DEBUG - 2021-08-26 05:56:29 --> UTF-8 Support Enabled
INFO - 2021-08-26 05:56:29 --> Utf8 Class Initialized
INFO - 2021-08-26 05:56:29 --> URI Class Initialized
INFO - 2021-08-26 05:56:29 --> Router Class Initialized
INFO - 2021-08-26 05:56:29 --> Output Class Initialized
INFO - 2021-08-26 05:56:29 --> Security Class Initialized
DEBUG - 2021-08-26 05:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 05:56:29 --> Input Class Initialized
INFO - 2021-08-26 05:56:29 --> Language Class Initialized
INFO - 2021-08-26 05:56:29 --> Language Class Initialized
INFO - 2021-08-26 05:56:29 --> Config Class Initialized
INFO - 2021-08-26 05:56:29 --> Loader Class Initialized
INFO - 2021-08-26 05:56:29 --> Helper loaded: url_helper
INFO - 2021-08-26 05:56:29 --> Helper loaded: file_helper
INFO - 2021-08-26 05:56:29 --> Helper loaded: form_helper
INFO - 2021-08-26 05:56:29 --> Helper loaded: my_helper
INFO - 2021-08-26 05:56:29 --> Database Driver Class Initialized
DEBUG - 2021-08-26 05:56:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 05:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 05:56:30 --> Controller Class Initialized
DEBUG - 2021-08-26 05:56:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-08-26 05:56:30 --> Final output sent to browser
DEBUG - 2021-08-26 05:56:30 --> Total execution time: 0.1291
INFO - 2021-08-26 05:56:32 --> Config Class Initialized
INFO - 2021-08-26 05:56:32 --> Hooks Class Initialized
DEBUG - 2021-08-26 05:56:32 --> UTF-8 Support Enabled
INFO - 2021-08-26 05:56:32 --> Utf8 Class Initialized
INFO - 2021-08-26 05:56:32 --> URI Class Initialized
INFO - 2021-08-26 05:56:32 --> Router Class Initialized
INFO - 2021-08-26 05:56:32 --> Output Class Initialized
INFO - 2021-08-26 05:56:32 --> Security Class Initialized
DEBUG - 2021-08-26 05:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 05:56:32 --> Input Class Initialized
INFO - 2021-08-26 05:56:32 --> Language Class Initialized
INFO - 2021-08-26 05:56:32 --> Language Class Initialized
INFO - 2021-08-26 05:56:32 --> Config Class Initialized
INFO - 2021-08-26 05:56:32 --> Loader Class Initialized
INFO - 2021-08-26 05:56:32 --> Helper loaded: url_helper
INFO - 2021-08-26 05:56:32 --> Helper loaded: file_helper
INFO - 2021-08-26 05:56:32 --> Helper loaded: form_helper
INFO - 2021-08-26 05:56:32 --> Helper loaded: my_helper
INFO - 2021-08-26 05:56:32 --> Database Driver Class Initialized
DEBUG - 2021-08-26 05:56:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 05:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 05:56:32 --> Controller Class Initialized
DEBUG - 2021-08-26 05:56:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-08-26 05:56:32 --> Final output sent to browser
DEBUG - 2021-08-26 05:56:32 --> Total execution time: 0.1463
INFO - 2021-08-26 06:00:14 --> Config Class Initialized
INFO - 2021-08-26 06:00:14 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:00:14 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:00:14 --> Utf8 Class Initialized
INFO - 2021-08-26 06:00:14 --> URI Class Initialized
INFO - 2021-08-26 06:00:14 --> Router Class Initialized
INFO - 2021-08-26 06:00:14 --> Output Class Initialized
INFO - 2021-08-26 06:00:14 --> Security Class Initialized
DEBUG - 2021-08-26 06:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:00:14 --> Input Class Initialized
INFO - 2021-08-26 06:00:14 --> Language Class Initialized
INFO - 2021-08-26 06:00:14 --> Language Class Initialized
INFO - 2021-08-26 06:00:14 --> Config Class Initialized
INFO - 2021-08-26 06:00:14 --> Loader Class Initialized
INFO - 2021-08-26 06:00:14 --> Helper loaded: url_helper
INFO - 2021-08-26 06:00:14 --> Helper loaded: file_helper
INFO - 2021-08-26 06:00:14 --> Helper loaded: form_helper
INFO - 2021-08-26 06:00:14 --> Helper loaded: my_helper
INFO - 2021-08-26 06:00:14 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:00:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:00:14 --> Controller Class Initialized
INFO - 2021-08-26 06:00:14 --> Helper loaded: cookie_helper
INFO - 2021-08-26 06:00:14 --> Config Class Initialized
INFO - 2021-08-26 06:00:14 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:00:14 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:00:14 --> Utf8 Class Initialized
INFO - 2021-08-26 06:00:14 --> URI Class Initialized
INFO - 2021-08-26 06:00:14 --> Router Class Initialized
INFO - 2021-08-26 06:00:14 --> Output Class Initialized
INFO - 2021-08-26 06:00:14 --> Security Class Initialized
DEBUG - 2021-08-26 06:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:00:14 --> Input Class Initialized
INFO - 2021-08-26 06:00:14 --> Language Class Initialized
INFO - 2021-08-26 06:00:15 --> Language Class Initialized
INFO - 2021-08-26 06:00:15 --> Config Class Initialized
INFO - 2021-08-26 06:00:15 --> Loader Class Initialized
INFO - 2021-08-26 06:00:15 --> Helper loaded: url_helper
INFO - 2021-08-26 06:00:15 --> Helper loaded: file_helper
INFO - 2021-08-26 06:00:15 --> Helper loaded: form_helper
INFO - 2021-08-26 06:00:15 --> Helper loaded: my_helper
INFO - 2021-08-26 06:00:15 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:00:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:00:15 --> Controller Class Initialized
DEBUG - 2021-08-26 06:00:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-08-26 06:00:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-26 06:00:15 --> Final output sent to browser
DEBUG - 2021-08-26 06:00:15 --> Total execution time: 0.0886
INFO - 2021-08-26 06:00:18 --> Config Class Initialized
INFO - 2021-08-26 06:00:18 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:00:18 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:00:18 --> Utf8 Class Initialized
INFO - 2021-08-26 06:00:18 --> URI Class Initialized
INFO - 2021-08-26 06:00:18 --> Router Class Initialized
INFO - 2021-08-26 06:00:18 --> Output Class Initialized
INFO - 2021-08-26 06:00:18 --> Security Class Initialized
DEBUG - 2021-08-26 06:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:00:18 --> Input Class Initialized
INFO - 2021-08-26 06:00:18 --> Language Class Initialized
INFO - 2021-08-26 06:00:18 --> Language Class Initialized
INFO - 2021-08-26 06:00:18 --> Config Class Initialized
INFO - 2021-08-26 06:00:18 --> Loader Class Initialized
INFO - 2021-08-26 06:00:18 --> Helper loaded: url_helper
INFO - 2021-08-26 06:00:18 --> Helper loaded: file_helper
INFO - 2021-08-26 06:00:18 --> Helper loaded: form_helper
INFO - 2021-08-26 06:00:18 --> Helper loaded: my_helper
INFO - 2021-08-26 06:00:18 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:00:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:00:18 --> Controller Class Initialized
INFO - 2021-08-26 06:00:18 --> Helper loaded: cookie_helper
INFO - 2021-08-26 06:00:18 --> Final output sent to browser
DEBUG - 2021-08-26 06:00:18 --> Total execution time: 0.0662
INFO - 2021-08-26 06:00:19 --> Config Class Initialized
INFO - 2021-08-26 06:00:19 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:00:19 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:00:19 --> Utf8 Class Initialized
INFO - 2021-08-26 06:00:19 --> URI Class Initialized
INFO - 2021-08-26 06:00:19 --> Router Class Initialized
INFO - 2021-08-26 06:00:19 --> Output Class Initialized
INFO - 2021-08-26 06:00:19 --> Security Class Initialized
DEBUG - 2021-08-26 06:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:00:19 --> Input Class Initialized
INFO - 2021-08-26 06:00:19 --> Language Class Initialized
INFO - 2021-08-26 06:00:19 --> Language Class Initialized
INFO - 2021-08-26 06:00:19 --> Config Class Initialized
INFO - 2021-08-26 06:00:19 --> Loader Class Initialized
INFO - 2021-08-26 06:00:19 --> Helper loaded: url_helper
INFO - 2021-08-26 06:00:19 --> Helper loaded: file_helper
INFO - 2021-08-26 06:00:19 --> Helper loaded: form_helper
INFO - 2021-08-26 06:00:19 --> Helper loaded: my_helper
INFO - 2021-08-26 06:00:19 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:00:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:00:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:00:19 --> Controller Class Initialized
DEBUG - 2021-08-26 06:00:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-08-26 06:00:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-26 06:00:19 --> Final output sent to browser
DEBUG - 2021-08-26 06:00:19 --> Total execution time: 0.7647
INFO - 2021-08-26 06:00:30 --> Config Class Initialized
INFO - 2021-08-26 06:00:30 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:00:30 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:00:30 --> Utf8 Class Initialized
INFO - 2021-08-26 06:00:30 --> URI Class Initialized
INFO - 2021-08-26 06:00:30 --> Router Class Initialized
INFO - 2021-08-26 06:00:30 --> Output Class Initialized
INFO - 2021-08-26 06:00:30 --> Security Class Initialized
DEBUG - 2021-08-26 06:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:00:30 --> Input Class Initialized
INFO - 2021-08-26 06:00:30 --> Language Class Initialized
INFO - 2021-08-26 06:00:30 --> Language Class Initialized
INFO - 2021-08-26 06:00:30 --> Config Class Initialized
INFO - 2021-08-26 06:00:30 --> Loader Class Initialized
INFO - 2021-08-26 06:00:30 --> Helper loaded: url_helper
INFO - 2021-08-26 06:00:30 --> Helper loaded: file_helper
INFO - 2021-08-26 06:00:30 --> Helper loaded: form_helper
INFO - 2021-08-26 06:00:30 --> Helper loaded: my_helper
INFO - 2021-08-26 06:00:30 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:00:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:00:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:00:30 --> Controller Class Initialized
DEBUG - 2021-08-26 06:00:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-08-26 06:00:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-26 06:00:30 --> Final output sent to browser
DEBUG - 2021-08-26 06:00:30 --> Total execution time: 0.0961
INFO - 2021-08-26 06:00:32 --> Config Class Initialized
INFO - 2021-08-26 06:00:32 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:00:32 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:00:32 --> Utf8 Class Initialized
INFO - 2021-08-26 06:00:32 --> URI Class Initialized
INFO - 2021-08-26 06:00:32 --> Router Class Initialized
INFO - 2021-08-26 06:00:32 --> Output Class Initialized
INFO - 2021-08-26 06:00:32 --> Security Class Initialized
DEBUG - 2021-08-26 06:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:00:32 --> Input Class Initialized
INFO - 2021-08-26 06:00:32 --> Language Class Initialized
INFO - 2021-08-26 06:00:33 --> Language Class Initialized
INFO - 2021-08-26 06:00:33 --> Config Class Initialized
INFO - 2021-08-26 06:00:33 --> Loader Class Initialized
INFO - 2021-08-26 06:00:33 --> Helper loaded: url_helper
INFO - 2021-08-26 06:00:33 --> Helper loaded: file_helper
INFO - 2021-08-26 06:00:33 --> Helper loaded: form_helper
INFO - 2021-08-26 06:00:33 --> Helper loaded: my_helper
INFO - 2021-08-26 06:00:33 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:00:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:00:33 --> Controller Class Initialized
DEBUG - 2021-08-26 06:00:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_mm_xi.php
INFO - 2021-08-26 06:00:33 --> Final output sent to browser
DEBUG - 2021-08-26 06:00:33 --> Total execution time: 0.2483
INFO - 2021-08-26 06:00:56 --> Config Class Initialized
INFO - 2021-08-26 06:00:56 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:00:56 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:00:56 --> Utf8 Class Initialized
INFO - 2021-08-26 06:00:56 --> URI Class Initialized
INFO - 2021-08-26 06:00:56 --> Router Class Initialized
INFO - 2021-08-26 06:00:56 --> Output Class Initialized
INFO - 2021-08-26 06:00:56 --> Security Class Initialized
DEBUG - 2021-08-26 06:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:00:56 --> Input Class Initialized
INFO - 2021-08-26 06:00:56 --> Language Class Initialized
INFO - 2021-08-26 06:00:56 --> Language Class Initialized
INFO - 2021-08-26 06:00:56 --> Config Class Initialized
INFO - 2021-08-26 06:00:56 --> Loader Class Initialized
INFO - 2021-08-26 06:00:56 --> Helper loaded: url_helper
INFO - 2021-08-26 06:00:56 --> Helper loaded: file_helper
INFO - 2021-08-26 06:00:56 --> Helper loaded: form_helper
INFO - 2021-08-26 06:00:56 --> Helper loaded: my_helper
INFO - 2021-08-26 06:00:56 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:00:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:00:56 --> Controller Class Initialized
DEBUG - 2021-08-26 06:00:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-08-26 06:00:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-26 06:00:56 --> Final output sent to browser
DEBUG - 2021-08-26 06:00:56 --> Total execution time: 0.1209
INFO - 2021-08-26 06:00:59 --> Config Class Initialized
INFO - 2021-08-26 06:00:59 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:00:59 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:00:59 --> Utf8 Class Initialized
INFO - 2021-08-26 06:00:59 --> URI Class Initialized
INFO - 2021-08-26 06:00:59 --> Router Class Initialized
INFO - 2021-08-26 06:00:59 --> Output Class Initialized
INFO - 2021-08-26 06:00:59 --> Security Class Initialized
DEBUG - 2021-08-26 06:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:00:59 --> Input Class Initialized
INFO - 2021-08-26 06:00:59 --> Language Class Initialized
INFO - 2021-08-26 06:00:59 --> Language Class Initialized
INFO - 2021-08-26 06:00:59 --> Config Class Initialized
INFO - 2021-08-26 06:00:59 --> Loader Class Initialized
INFO - 2021-08-26 06:00:59 --> Helper loaded: url_helper
INFO - 2021-08-26 06:00:59 --> Helper loaded: file_helper
INFO - 2021-08-26 06:00:59 --> Helper loaded: form_helper
INFO - 2021-08-26 06:00:59 --> Helper loaded: my_helper
INFO - 2021-08-26 06:00:59 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:00:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:00:59 --> Controller Class Initialized
DEBUG - 2021-08-26 06:01:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-08-26 06:01:00 --> Final output sent to browser
DEBUG - 2021-08-26 06:01:00 --> Total execution time: 0.2010
INFO - 2021-08-26 06:01:02 --> Config Class Initialized
INFO - 2021-08-26 06:01:02 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:01:02 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:01:02 --> Utf8 Class Initialized
INFO - 2021-08-26 06:01:02 --> URI Class Initialized
INFO - 2021-08-26 06:01:02 --> Router Class Initialized
INFO - 2021-08-26 06:01:02 --> Output Class Initialized
INFO - 2021-08-26 06:01:02 --> Security Class Initialized
DEBUG - 2021-08-26 06:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:01:02 --> Input Class Initialized
INFO - 2021-08-26 06:01:02 --> Language Class Initialized
INFO - 2021-08-26 06:01:02 --> Language Class Initialized
INFO - 2021-08-26 06:01:02 --> Config Class Initialized
INFO - 2021-08-26 06:01:02 --> Loader Class Initialized
INFO - 2021-08-26 06:01:02 --> Helper loaded: url_helper
INFO - 2021-08-26 06:01:02 --> Helper loaded: file_helper
INFO - 2021-08-26 06:01:02 --> Helper loaded: form_helper
INFO - 2021-08-26 06:01:02 --> Helper loaded: my_helper
INFO - 2021-08-26 06:01:02 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:01:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:01:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:01:02 --> Controller Class Initialized
DEBUG - 2021-08-26 06:01:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-08-26 06:01:03 --> Final output sent to browser
DEBUG - 2021-08-26 06:01:03 --> Total execution time: 0.1519
INFO - 2021-08-26 06:01:04 --> Config Class Initialized
INFO - 2021-08-26 06:01:04 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:01:04 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:01:04 --> Utf8 Class Initialized
INFO - 2021-08-26 06:01:04 --> URI Class Initialized
INFO - 2021-08-26 06:01:04 --> Router Class Initialized
INFO - 2021-08-26 06:01:04 --> Output Class Initialized
INFO - 2021-08-26 06:01:04 --> Security Class Initialized
DEBUG - 2021-08-26 06:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:01:04 --> Input Class Initialized
INFO - 2021-08-26 06:01:04 --> Language Class Initialized
INFO - 2021-08-26 06:01:04 --> Language Class Initialized
INFO - 2021-08-26 06:01:04 --> Config Class Initialized
INFO - 2021-08-26 06:01:04 --> Loader Class Initialized
INFO - 2021-08-26 06:01:04 --> Helper loaded: url_helper
INFO - 2021-08-26 06:01:04 --> Helper loaded: file_helper
INFO - 2021-08-26 06:01:04 --> Helper loaded: form_helper
INFO - 2021-08-26 06:01:04 --> Helper loaded: my_helper
INFO - 2021-08-26 06:01:04 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:01:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:01:04 --> Controller Class Initialized
DEBUG - 2021-08-26 06:01:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-08-26 06:01:04 --> Final output sent to browser
DEBUG - 2021-08-26 06:01:04 --> Total execution time: 0.1558
INFO - 2021-08-26 06:01:06 --> Config Class Initialized
INFO - 2021-08-26 06:01:06 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:01:06 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:01:06 --> Utf8 Class Initialized
INFO - 2021-08-26 06:01:06 --> URI Class Initialized
INFO - 2021-08-26 06:01:06 --> Router Class Initialized
INFO - 2021-08-26 06:01:06 --> Output Class Initialized
INFO - 2021-08-26 06:01:06 --> Security Class Initialized
DEBUG - 2021-08-26 06:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:01:06 --> Input Class Initialized
INFO - 2021-08-26 06:01:06 --> Language Class Initialized
INFO - 2021-08-26 06:01:06 --> Language Class Initialized
INFO - 2021-08-26 06:01:06 --> Config Class Initialized
INFO - 2021-08-26 06:01:06 --> Loader Class Initialized
INFO - 2021-08-26 06:01:06 --> Helper loaded: url_helper
INFO - 2021-08-26 06:01:06 --> Helper loaded: file_helper
INFO - 2021-08-26 06:01:06 --> Helper loaded: form_helper
INFO - 2021-08-26 06:01:06 --> Helper loaded: my_helper
INFO - 2021-08-26 06:01:06 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:01:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:01:06 --> Controller Class Initialized
DEBUG - 2021-08-26 06:01:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-08-26 06:01:06 --> Final output sent to browser
DEBUG - 2021-08-26 06:01:06 --> Total execution time: 0.1457
INFO - 2021-08-26 06:01:20 --> Config Class Initialized
INFO - 2021-08-26 06:01:20 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:01:20 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:01:20 --> Utf8 Class Initialized
INFO - 2021-08-26 06:01:20 --> URI Class Initialized
INFO - 2021-08-26 06:01:20 --> Router Class Initialized
INFO - 2021-08-26 06:01:20 --> Output Class Initialized
INFO - 2021-08-26 06:01:20 --> Security Class Initialized
DEBUG - 2021-08-26 06:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:01:20 --> Input Class Initialized
INFO - 2021-08-26 06:01:20 --> Language Class Initialized
INFO - 2021-08-26 06:01:20 --> Language Class Initialized
INFO - 2021-08-26 06:01:20 --> Config Class Initialized
INFO - 2021-08-26 06:01:20 --> Loader Class Initialized
INFO - 2021-08-26 06:01:20 --> Helper loaded: url_helper
INFO - 2021-08-26 06:01:20 --> Helper loaded: file_helper
INFO - 2021-08-26 06:01:20 --> Helper loaded: form_helper
INFO - 2021-08-26 06:01:20 --> Helper loaded: my_helper
INFO - 2021-08-26 06:01:20 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:01:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:01:20 --> Controller Class Initialized
DEBUG - 2021-08-26 06:01:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-08-26 06:01:20 --> Final output sent to browser
DEBUG - 2021-08-26 06:01:20 --> Total execution time: 0.1427
INFO - 2021-08-26 06:01:22 --> Config Class Initialized
INFO - 2021-08-26 06:01:22 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:01:22 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:01:22 --> Utf8 Class Initialized
INFO - 2021-08-26 06:01:22 --> URI Class Initialized
INFO - 2021-08-26 06:01:22 --> Router Class Initialized
INFO - 2021-08-26 06:01:22 --> Output Class Initialized
INFO - 2021-08-26 06:01:22 --> Security Class Initialized
DEBUG - 2021-08-26 06:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:01:22 --> Input Class Initialized
INFO - 2021-08-26 06:01:22 --> Language Class Initialized
INFO - 2021-08-26 06:01:22 --> Language Class Initialized
INFO - 2021-08-26 06:01:22 --> Config Class Initialized
INFO - 2021-08-26 06:01:22 --> Loader Class Initialized
INFO - 2021-08-26 06:01:22 --> Helper loaded: url_helper
INFO - 2021-08-26 06:01:22 --> Helper loaded: file_helper
INFO - 2021-08-26 06:01:22 --> Helper loaded: form_helper
INFO - 2021-08-26 06:01:22 --> Helper loaded: my_helper
INFO - 2021-08-26 06:01:22 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:01:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:01:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:01:22 --> Controller Class Initialized
DEBUG - 2021-08-26 06:01:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-08-26 06:01:22 --> Final output sent to browser
DEBUG - 2021-08-26 06:01:22 --> Total execution time: 0.1414
INFO - 2021-08-26 06:01:24 --> Config Class Initialized
INFO - 2021-08-26 06:01:24 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:01:24 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:01:24 --> Utf8 Class Initialized
INFO - 2021-08-26 06:01:24 --> URI Class Initialized
INFO - 2021-08-26 06:01:24 --> Router Class Initialized
INFO - 2021-08-26 06:01:24 --> Output Class Initialized
INFO - 2021-08-26 06:01:24 --> Security Class Initialized
DEBUG - 2021-08-26 06:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:01:24 --> Input Class Initialized
INFO - 2021-08-26 06:01:24 --> Language Class Initialized
INFO - 2021-08-26 06:01:24 --> Language Class Initialized
INFO - 2021-08-26 06:01:24 --> Config Class Initialized
INFO - 2021-08-26 06:01:24 --> Loader Class Initialized
INFO - 2021-08-26 06:01:24 --> Helper loaded: url_helper
INFO - 2021-08-26 06:01:24 --> Helper loaded: file_helper
INFO - 2021-08-26 06:01:24 --> Helper loaded: form_helper
INFO - 2021-08-26 06:01:24 --> Helper loaded: my_helper
INFO - 2021-08-26 06:01:24 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:01:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:01:24 --> Controller Class Initialized
DEBUG - 2021-08-26 06:01:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-08-26 06:01:24 --> Final output sent to browser
DEBUG - 2021-08-26 06:01:24 --> Total execution time: 0.1438
INFO - 2021-08-26 06:01:28 --> Config Class Initialized
INFO - 2021-08-26 06:01:28 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:01:28 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:01:28 --> Utf8 Class Initialized
INFO - 2021-08-26 06:01:28 --> URI Class Initialized
INFO - 2021-08-26 06:01:28 --> Router Class Initialized
INFO - 2021-08-26 06:01:28 --> Output Class Initialized
INFO - 2021-08-26 06:01:28 --> Security Class Initialized
DEBUG - 2021-08-26 06:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:01:28 --> Input Class Initialized
INFO - 2021-08-26 06:01:28 --> Language Class Initialized
INFO - 2021-08-26 06:01:28 --> Language Class Initialized
INFO - 2021-08-26 06:01:28 --> Config Class Initialized
INFO - 2021-08-26 06:01:28 --> Loader Class Initialized
INFO - 2021-08-26 06:01:28 --> Helper loaded: url_helper
INFO - 2021-08-26 06:01:28 --> Helper loaded: file_helper
INFO - 2021-08-26 06:01:28 --> Helper loaded: form_helper
INFO - 2021-08-26 06:01:28 --> Helper loaded: my_helper
INFO - 2021-08-26 06:01:28 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:01:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:01:28 --> Controller Class Initialized
DEBUG - 2021-08-26 06:01:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-08-26 06:01:28 --> Final output sent to browser
DEBUG - 2021-08-26 06:01:28 --> Total execution time: 0.1414
INFO - 2021-08-26 06:01:29 --> Config Class Initialized
INFO - 2021-08-26 06:01:29 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:01:29 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:01:29 --> Utf8 Class Initialized
INFO - 2021-08-26 06:01:29 --> URI Class Initialized
INFO - 2021-08-26 06:01:29 --> Router Class Initialized
INFO - 2021-08-26 06:01:29 --> Output Class Initialized
INFO - 2021-08-26 06:01:29 --> Security Class Initialized
DEBUG - 2021-08-26 06:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:01:29 --> Input Class Initialized
INFO - 2021-08-26 06:01:29 --> Language Class Initialized
INFO - 2021-08-26 06:01:29 --> Language Class Initialized
INFO - 2021-08-26 06:01:29 --> Config Class Initialized
INFO - 2021-08-26 06:01:29 --> Loader Class Initialized
INFO - 2021-08-26 06:01:29 --> Helper loaded: url_helper
INFO - 2021-08-26 06:01:29 --> Helper loaded: file_helper
INFO - 2021-08-26 06:01:29 --> Helper loaded: form_helper
INFO - 2021-08-26 06:01:29 --> Helper loaded: my_helper
INFO - 2021-08-26 06:01:29 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:01:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:01:29 --> Controller Class Initialized
DEBUG - 2021-08-26 06:01:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-08-26 06:01:29 --> Final output sent to browser
DEBUG - 2021-08-26 06:01:29 --> Total execution time: 0.1420
INFO - 2021-08-26 06:01:31 --> Config Class Initialized
INFO - 2021-08-26 06:01:31 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:01:31 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:01:31 --> Utf8 Class Initialized
INFO - 2021-08-26 06:01:31 --> URI Class Initialized
INFO - 2021-08-26 06:01:31 --> Router Class Initialized
INFO - 2021-08-26 06:01:31 --> Output Class Initialized
INFO - 2021-08-26 06:01:31 --> Security Class Initialized
DEBUG - 2021-08-26 06:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:01:31 --> Input Class Initialized
INFO - 2021-08-26 06:01:31 --> Language Class Initialized
INFO - 2021-08-26 06:01:31 --> Language Class Initialized
INFO - 2021-08-26 06:01:31 --> Config Class Initialized
INFO - 2021-08-26 06:01:31 --> Loader Class Initialized
INFO - 2021-08-26 06:01:31 --> Helper loaded: url_helper
INFO - 2021-08-26 06:01:31 --> Helper loaded: file_helper
INFO - 2021-08-26 06:01:31 --> Helper loaded: form_helper
INFO - 2021-08-26 06:01:31 --> Helper loaded: my_helper
INFO - 2021-08-26 06:01:31 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:01:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:01:31 --> Controller Class Initialized
DEBUG - 2021-08-26 06:01:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-08-26 06:01:31 --> Final output sent to browser
DEBUG - 2021-08-26 06:01:31 --> Total execution time: 0.1426
INFO - 2021-08-26 06:01:33 --> Config Class Initialized
INFO - 2021-08-26 06:01:33 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:01:33 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:01:33 --> Utf8 Class Initialized
INFO - 2021-08-26 06:01:33 --> URI Class Initialized
INFO - 2021-08-26 06:01:33 --> Router Class Initialized
INFO - 2021-08-26 06:01:33 --> Output Class Initialized
INFO - 2021-08-26 06:01:33 --> Security Class Initialized
DEBUG - 2021-08-26 06:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:01:33 --> Input Class Initialized
INFO - 2021-08-26 06:01:33 --> Language Class Initialized
INFO - 2021-08-26 06:01:33 --> Language Class Initialized
INFO - 2021-08-26 06:01:33 --> Config Class Initialized
INFO - 2021-08-26 06:01:33 --> Loader Class Initialized
INFO - 2021-08-26 06:01:33 --> Helper loaded: url_helper
INFO - 2021-08-26 06:01:33 --> Helper loaded: file_helper
INFO - 2021-08-26 06:01:33 --> Helper loaded: form_helper
INFO - 2021-08-26 06:01:33 --> Helper loaded: my_helper
INFO - 2021-08-26 06:01:33 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:01:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:01:33 --> Controller Class Initialized
DEBUG - 2021-08-26 06:01:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-08-26 06:01:33 --> Final output sent to browser
DEBUG - 2021-08-26 06:01:33 --> Total execution time: 0.1432
INFO - 2021-08-26 06:01:43 --> Config Class Initialized
INFO - 2021-08-26 06:01:43 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:01:43 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:01:43 --> Utf8 Class Initialized
INFO - 2021-08-26 06:01:43 --> URI Class Initialized
INFO - 2021-08-26 06:01:43 --> Router Class Initialized
INFO - 2021-08-26 06:01:43 --> Output Class Initialized
INFO - 2021-08-26 06:01:43 --> Security Class Initialized
DEBUG - 2021-08-26 06:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:01:43 --> Input Class Initialized
INFO - 2021-08-26 06:01:43 --> Language Class Initialized
INFO - 2021-08-26 06:01:43 --> Language Class Initialized
INFO - 2021-08-26 06:01:43 --> Config Class Initialized
INFO - 2021-08-26 06:01:43 --> Loader Class Initialized
INFO - 2021-08-26 06:01:43 --> Helper loaded: url_helper
INFO - 2021-08-26 06:01:43 --> Helper loaded: file_helper
INFO - 2021-08-26 06:01:43 --> Helper loaded: form_helper
INFO - 2021-08-26 06:01:43 --> Helper loaded: my_helper
INFO - 2021-08-26 06:01:43 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:01:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:01:43 --> Controller Class Initialized
DEBUG - 2021-08-26 06:01:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-08-26 06:01:43 --> Final output sent to browser
DEBUG - 2021-08-26 06:01:43 --> Total execution time: 0.1422
INFO - 2021-08-26 06:01:44 --> Config Class Initialized
INFO - 2021-08-26 06:01:44 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:01:44 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:01:44 --> Utf8 Class Initialized
INFO - 2021-08-26 06:01:44 --> URI Class Initialized
INFO - 2021-08-26 06:01:44 --> Router Class Initialized
INFO - 2021-08-26 06:01:44 --> Output Class Initialized
INFO - 2021-08-26 06:01:44 --> Security Class Initialized
DEBUG - 2021-08-26 06:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:01:44 --> Input Class Initialized
INFO - 2021-08-26 06:01:44 --> Language Class Initialized
INFO - 2021-08-26 06:01:44 --> Language Class Initialized
INFO - 2021-08-26 06:01:44 --> Config Class Initialized
INFO - 2021-08-26 06:01:44 --> Loader Class Initialized
INFO - 2021-08-26 06:01:44 --> Helper loaded: url_helper
INFO - 2021-08-26 06:01:44 --> Helper loaded: file_helper
INFO - 2021-08-26 06:01:44 --> Helper loaded: form_helper
INFO - 2021-08-26 06:01:44 --> Helper loaded: my_helper
INFO - 2021-08-26 06:01:44 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:01:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:01:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:01:44 --> Controller Class Initialized
DEBUG - 2021-08-26 06:01:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-08-26 06:01:44 --> Final output sent to browser
DEBUG - 2021-08-26 06:01:44 --> Total execution time: 0.1403
INFO - 2021-08-26 06:01:47 --> Config Class Initialized
INFO - 2021-08-26 06:01:47 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:01:47 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:01:47 --> Utf8 Class Initialized
INFO - 2021-08-26 06:01:47 --> URI Class Initialized
INFO - 2021-08-26 06:01:47 --> Router Class Initialized
INFO - 2021-08-26 06:01:47 --> Output Class Initialized
INFO - 2021-08-26 06:01:47 --> Security Class Initialized
DEBUG - 2021-08-26 06:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:01:47 --> Input Class Initialized
INFO - 2021-08-26 06:01:47 --> Language Class Initialized
INFO - 2021-08-26 06:01:47 --> Language Class Initialized
INFO - 2021-08-26 06:01:47 --> Config Class Initialized
INFO - 2021-08-26 06:01:47 --> Loader Class Initialized
INFO - 2021-08-26 06:01:47 --> Helper loaded: url_helper
INFO - 2021-08-26 06:01:47 --> Helper loaded: file_helper
INFO - 2021-08-26 06:01:47 --> Helper loaded: form_helper
INFO - 2021-08-26 06:01:47 --> Helper loaded: my_helper
INFO - 2021-08-26 06:01:47 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:01:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:01:47 --> Controller Class Initialized
DEBUG - 2021-08-26 06:01:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-08-26 06:01:47 --> Final output sent to browser
DEBUG - 2021-08-26 06:01:47 --> Total execution time: 0.1542
INFO - 2021-08-26 06:01:51 --> Config Class Initialized
INFO - 2021-08-26 06:01:51 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:01:51 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:01:51 --> Utf8 Class Initialized
INFO - 2021-08-26 06:01:51 --> URI Class Initialized
INFO - 2021-08-26 06:01:51 --> Router Class Initialized
INFO - 2021-08-26 06:01:51 --> Output Class Initialized
INFO - 2021-08-26 06:01:51 --> Security Class Initialized
DEBUG - 2021-08-26 06:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:01:51 --> Input Class Initialized
INFO - 2021-08-26 06:01:51 --> Language Class Initialized
INFO - 2021-08-26 06:01:51 --> Language Class Initialized
INFO - 2021-08-26 06:01:51 --> Config Class Initialized
INFO - 2021-08-26 06:01:51 --> Loader Class Initialized
INFO - 2021-08-26 06:01:51 --> Helper loaded: url_helper
INFO - 2021-08-26 06:01:51 --> Helper loaded: file_helper
INFO - 2021-08-26 06:01:51 --> Helper loaded: form_helper
INFO - 2021-08-26 06:01:51 --> Helper loaded: my_helper
INFO - 2021-08-26 06:01:51 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:01:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:01:51 --> Controller Class Initialized
DEBUG - 2021-08-26 06:01:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-08-26 06:01:51 --> Final output sent to browser
DEBUG - 2021-08-26 06:01:51 --> Total execution time: 0.1400
INFO - 2021-08-26 06:01:53 --> Config Class Initialized
INFO - 2021-08-26 06:01:53 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:01:53 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:01:53 --> Utf8 Class Initialized
INFO - 2021-08-26 06:01:53 --> URI Class Initialized
INFO - 2021-08-26 06:01:53 --> Router Class Initialized
INFO - 2021-08-26 06:01:53 --> Output Class Initialized
INFO - 2021-08-26 06:01:53 --> Security Class Initialized
DEBUG - 2021-08-26 06:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:01:53 --> Input Class Initialized
INFO - 2021-08-26 06:01:53 --> Language Class Initialized
INFO - 2021-08-26 06:01:53 --> Language Class Initialized
INFO - 2021-08-26 06:01:53 --> Config Class Initialized
INFO - 2021-08-26 06:01:53 --> Loader Class Initialized
INFO - 2021-08-26 06:01:53 --> Helper loaded: url_helper
INFO - 2021-08-26 06:01:53 --> Helper loaded: file_helper
INFO - 2021-08-26 06:01:53 --> Helper loaded: form_helper
INFO - 2021-08-26 06:01:53 --> Helper loaded: my_helper
INFO - 2021-08-26 06:01:53 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:01:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:01:53 --> Controller Class Initialized
DEBUG - 2021-08-26 06:01:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-08-26 06:01:53 --> Final output sent to browser
DEBUG - 2021-08-26 06:01:53 --> Total execution time: 0.1505
INFO - 2021-08-26 06:01:55 --> Config Class Initialized
INFO - 2021-08-26 06:01:55 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:01:55 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:01:55 --> Utf8 Class Initialized
INFO - 2021-08-26 06:01:55 --> URI Class Initialized
INFO - 2021-08-26 06:01:55 --> Router Class Initialized
INFO - 2021-08-26 06:01:55 --> Output Class Initialized
INFO - 2021-08-26 06:01:55 --> Security Class Initialized
DEBUG - 2021-08-26 06:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:01:55 --> Input Class Initialized
INFO - 2021-08-26 06:01:55 --> Language Class Initialized
INFO - 2021-08-26 06:01:55 --> Language Class Initialized
INFO - 2021-08-26 06:01:55 --> Config Class Initialized
INFO - 2021-08-26 06:01:55 --> Loader Class Initialized
INFO - 2021-08-26 06:01:55 --> Helper loaded: url_helper
INFO - 2021-08-26 06:01:55 --> Helper loaded: file_helper
INFO - 2021-08-26 06:01:55 --> Helper loaded: form_helper
INFO - 2021-08-26 06:01:55 --> Helper loaded: my_helper
INFO - 2021-08-26 06:01:55 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:01:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:01:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:01:55 --> Controller Class Initialized
DEBUG - 2021-08-26 06:01:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-08-26 06:01:55 --> Final output sent to browser
DEBUG - 2021-08-26 06:01:55 --> Total execution time: 0.1419
INFO - 2021-08-26 06:04:18 --> Config Class Initialized
INFO - 2021-08-26 06:04:18 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:04:18 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:04:18 --> Utf8 Class Initialized
INFO - 2021-08-26 06:04:18 --> URI Class Initialized
INFO - 2021-08-26 06:04:18 --> Router Class Initialized
INFO - 2021-08-26 06:04:18 --> Output Class Initialized
INFO - 2021-08-26 06:04:18 --> Security Class Initialized
DEBUG - 2021-08-26 06:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:04:18 --> Input Class Initialized
INFO - 2021-08-26 06:04:18 --> Language Class Initialized
INFO - 2021-08-26 06:04:18 --> Language Class Initialized
INFO - 2021-08-26 06:04:18 --> Config Class Initialized
INFO - 2021-08-26 06:04:18 --> Loader Class Initialized
INFO - 2021-08-26 06:04:18 --> Helper loaded: url_helper
INFO - 2021-08-26 06:04:18 --> Helper loaded: file_helper
INFO - 2021-08-26 06:04:18 --> Helper loaded: form_helper
INFO - 2021-08-26 06:04:18 --> Helper loaded: my_helper
INFO - 2021-08-26 06:04:18 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:04:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:04:18 --> Controller Class Initialized
INFO - 2021-08-26 06:04:18 --> Helper loaded: cookie_helper
INFO - 2021-08-26 06:04:18 --> Config Class Initialized
INFO - 2021-08-26 06:04:18 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:04:18 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:04:18 --> Utf8 Class Initialized
INFO - 2021-08-26 06:04:18 --> URI Class Initialized
INFO - 2021-08-26 06:04:18 --> Router Class Initialized
INFO - 2021-08-26 06:04:18 --> Output Class Initialized
INFO - 2021-08-26 06:04:18 --> Security Class Initialized
DEBUG - 2021-08-26 06:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:04:18 --> Input Class Initialized
INFO - 2021-08-26 06:04:18 --> Language Class Initialized
INFO - 2021-08-26 06:04:18 --> Language Class Initialized
INFO - 2021-08-26 06:04:18 --> Config Class Initialized
INFO - 2021-08-26 06:04:18 --> Loader Class Initialized
INFO - 2021-08-26 06:04:18 --> Helper loaded: url_helper
INFO - 2021-08-26 06:04:18 --> Helper loaded: file_helper
INFO - 2021-08-26 06:04:18 --> Helper loaded: form_helper
INFO - 2021-08-26 06:04:18 --> Helper loaded: my_helper
INFO - 2021-08-26 06:04:18 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:04:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:04:18 --> Controller Class Initialized
DEBUG - 2021-08-26 06:04:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-08-26 06:04:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-26 06:04:18 --> Final output sent to browser
DEBUG - 2021-08-26 06:04:18 --> Total execution time: 0.0680
INFO - 2021-08-26 06:04:29 --> Config Class Initialized
INFO - 2021-08-26 06:04:29 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:04:29 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:04:29 --> Utf8 Class Initialized
INFO - 2021-08-26 06:04:29 --> URI Class Initialized
INFO - 2021-08-26 06:04:29 --> Router Class Initialized
INFO - 2021-08-26 06:04:29 --> Output Class Initialized
INFO - 2021-08-26 06:04:29 --> Security Class Initialized
DEBUG - 2021-08-26 06:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:04:29 --> Input Class Initialized
INFO - 2021-08-26 06:04:29 --> Language Class Initialized
INFO - 2021-08-26 06:04:29 --> Language Class Initialized
INFO - 2021-08-26 06:04:29 --> Config Class Initialized
INFO - 2021-08-26 06:04:29 --> Loader Class Initialized
INFO - 2021-08-26 06:04:29 --> Helper loaded: url_helper
INFO - 2021-08-26 06:04:29 --> Helper loaded: file_helper
INFO - 2021-08-26 06:04:29 --> Helper loaded: form_helper
INFO - 2021-08-26 06:04:29 --> Helper loaded: my_helper
INFO - 2021-08-26 06:04:29 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:04:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:04:29 --> Controller Class Initialized
INFO - 2021-08-26 06:04:29 --> Helper loaded: cookie_helper
INFO - 2021-08-26 06:04:29 --> Final output sent to browser
DEBUG - 2021-08-26 06:04:29 --> Total execution time: 0.0504
INFO - 2021-08-26 06:04:29 --> Config Class Initialized
INFO - 2021-08-26 06:04:29 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:04:29 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:04:29 --> Utf8 Class Initialized
INFO - 2021-08-26 06:04:29 --> URI Class Initialized
INFO - 2021-08-26 06:04:29 --> Router Class Initialized
INFO - 2021-08-26 06:04:29 --> Output Class Initialized
INFO - 2021-08-26 06:04:29 --> Security Class Initialized
DEBUG - 2021-08-26 06:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:04:29 --> Input Class Initialized
INFO - 2021-08-26 06:04:29 --> Language Class Initialized
INFO - 2021-08-26 06:04:29 --> Language Class Initialized
INFO - 2021-08-26 06:04:29 --> Config Class Initialized
INFO - 2021-08-26 06:04:29 --> Loader Class Initialized
INFO - 2021-08-26 06:04:29 --> Helper loaded: url_helper
INFO - 2021-08-26 06:04:29 --> Helper loaded: file_helper
INFO - 2021-08-26 06:04:29 --> Helper loaded: form_helper
INFO - 2021-08-26 06:04:29 --> Helper loaded: my_helper
INFO - 2021-08-26 06:04:29 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:04:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:04:29 --> Controller Class Initialized
DEBUG - 2021-08-26 06:04:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-08-26 06:04:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-26 06:04:30 --> Final output sent to browser
DEBUG - 2021-08-26 06:04:30 --> Total execution time: 0.7531
INFO - 2021-08-26 06:05:08 --> Config Class Initialized
INFO - 2021-08-26 06:05:08 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:05:08 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:05:08 --> Utf8 Class Initialized
INFO - 2021-08-26 06:05:08 --> URI Class Initialized
INFO - 2021-08-26 06:05:08 --> Router Class Initialized
INFO - 2021-08-26 06:05:08 --> Output Class Initialized
INFO - 2021-08-26 06:05:08 --> Security Class Initialized
DEBUG - 2021-08-26 06:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:05:08 --> Input Class Initialized
INFO - 2021-08-26 06:05:08 --> Language Class Initialized
INFO - 2021-08-26 06:05:08 --> Language Class Initialized
INFO - 2021-08-26 06:05:08 --> Config Class Initialized
INFO - 2021-08-26 06:05:08 --> Loader Class Initialized
INFO - 2021-08-26 06:05:08 --> Helper loaded: url_helper
INFO - 2021-08-26 06:05:08 --> Helper loaded: file_helper
INFO - 2021-08-26 06:05:08 --> Helper loaded: form_helper
INFO - 2021-08-26 06:05:08 --> Helper loaded: my_helper
INFO - 2021-08-26 06:05:08 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:05:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:05:08 --> Controller Class Initialized
DEBUG - 2021-08-26 06:05:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-08-26 06:05:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-26 06:05:08 --> Final output sent to browser
DEBUG - 2021-08-26 06:05:08 --> Total execution time: 0.0695
INFO - 2021-08-26 06:05:22 --> Config Class Initialized
INFO - 2021-08-26 06:05:22 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:05:22 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:05:22 --> Utf8 Class Initialized
INFO - 2021-08-26 06:05:22 --> URI Class Initialized
INFO - 2021-08-26 06:05:22 --> Router Class Initialized
INFO - 2021-08-26 06:05:22 --> Output Class Initialized
INFO - 2021-08-26 06:05:22 --> Security Class Initialized
DEBUG - 2021-08-26 06:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:05:22 --> Input Class Initialized
INFO - 2021-08-26 06:05:22 --> Language Class Initialized
INFO - 2021-08-26 06:05:22 --> Language Class Initialized
INFO - 2021-08-26 06:05:22 --> Config Class Initialized
INFO - 2021-08-26 06:05:22 --> Loader Class Initialized
INFO - 2021-08-26 06:05:22 --> Helper loaded: url_helper
INFO - 2021-08-26 06:05:22 --> Helper loaded: file_helper
INFO - 2021-08-26 06:05:22 --> Helper loaded: form_helper
INFO - 2021-08-26 06:05:22 --> Helper loaded: my_helper
INFO - 2021-08-26 06:05:22 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:05:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:05:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:05:22 --> Controller Class Initialized
DEBUG - 2021-08-26 06:05:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-26 06:05:22 --> Final output sent to browser
DEBUG - 2021-08-26 06:05:22 --> Total execution time: 0.2499
INFO - 2021-08-26 06:05:30 --> Config Class Initialized
INFO - 2021-08-26 06:05:30 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:05:30 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:05:30 --> Utf8 Class Initialized
INFO - 2021-08-26 06:05:30 --> URI Class Initialized
INFO - 2021-08-26 06:05:30 --> Router Class Initialized
INFO - 2021-08-26 06:05:30 --> Output Class Initialized
INFO - 2021-08-26 06:05:30 --> Security Class Initialized
DEBUG - 2021-08-26 06:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:05:30 --> Input Class Initialized
INFO - 2021-08-26 06:05:30 --> Language Class Initialized
INFO - 2021-08-26 06:05:30 --> Language Class Initialized
INFO - 2021-08-26 06:05:30 --> Config Class Initialized
INFO - 2021-08-26 06:05:30 --> Loader Class Initialized
INFO - 2021-08-26 06:05:30 --> Helper loaded: url_helper
INFO - 2021-08-26 06:05:30 --> Helper loaded: file_helper
INFO - 2021-08-26 06:05:30 --> Helper loaded: form_helper
INFO - 2021-08-26 06:05:30 --> Helper loaded: my_helper
INFO - 2021-08-26 06:05:30 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:05:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:05:30 --> Controller Class Initialized
DEBUG - 2021-08-26 06:05:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-08-26 06:05:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-26 06:05:30 --> Final output sent to browser
DEBUG - 2021-08-26 06:05:30 --> Total execution time: 0.0607
INFO - 2021-08-26 06:05:31 --> Config Class Initialized
INFO - 2021-08-26 06:05:31 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:05:31 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:05:31 --> Utf8 Class Initialized
INFO - 2021-08-26 06:05:31 --> URI Class Initialized
INFO - 2021-08-26 06:05:31 --> Router Class Initialized
INFO - 2021-08-26 06:05:31 --> Output Class Initialized
INFO - 2021-08-26 06:05:31 --> Security Class Initialized
DEBUG - 2021-08-26 06:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:05:31 --> Input Class Initialized
INFO - 2021-08-26 06:05:31 --> Language Class Initialized
INFO - 2021-08-26 06:05:31 --> Language Class Initialized
INFO - 2021-08-26 06:05:31 --> Config Class Initialized
INFO - 2021-08-26 06:05:31 --> Loader Class Initialized
INFO - 2021-08-26 06:05:31 --> Helper loaded: url_helper
INFO - 2021-08-26 06:05:31 --> Helper loaded: file_helper
INFO - 2021-08-26 06:05:31 --> Helper loaded: form_helper
INFO - 2021-08-26 06:05:31 --> Helper loaded: my_helper
INFO - 2021-08-26 06:05:31 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:05:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:05:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:05:31 --> Controller Class Initialized
DEBUG - 2021-08-26 06:05:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tki.php
INFO - 2021-08-26 06:05:32 --> Final output sent to browser
DEBUG - 2021-08-26 06:05:32 --> Total execution time: 0.2082
INFO - 2021-08-26 06:06:19 --> Config Class Initialized
INFO - 2021-08-26 06:06:19 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:06:19 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:06:19 --> Utf8 Class Initialized
INFO - 2021-08-26 06:06:19 --> URI Class Initialized
INFO - 2021-08-26 06:06:19 --> Router Class Initialized
INFO - 2021-08-26 06:06:19 --> Output Class Initialized
INFO - 2021-08-26 06:06:19 --> Security Class Initialized
DEBUG - 2021-08-26 06:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:06:19 --> Input Class Initialized
INFO - 2021-08-26 06:06:19 --> Language Class Initialized
INFO - 2021-08-26 06:06:19 --> Language Class Initialized
INFO - 2021-08-26 06:06:19 --> Config Class Initialized
INFO - 2021-08-26 06:06:19 --> Loader Class Initialized
INFO - 2021-08-26 06:06:19 --> Helper loaded: url_helper
INFO - 2021-08-26 06:06:19 --> Helper loaded: file_helper
INFO - 2021-08-26 06:06:19 --> Helper loaded: form_helper
INFO - 2021-08-26 06:06:19 --> Helper loaded: my_helper
INFO - 2021-08-26 06:06:19 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:06:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:06:19 --> Controller Class Initialized
DEBUG - 2021-08-26 06:06:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-08-26 06:06:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-26 06:06:19 --> Final output sent to browser
DEBUG - 2021-08-26 06:06:19 --> Total execution time: 0.0776
INFO - 2021-08-26 06:06:48 --> Config Class Initialized
INFO - 2021-08-26 06:06:48 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:06:48 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:06:48 --> Utf8 Class Initialized
INFO - 2021-08-26 06:06:48 --> URI Class Initialized
INFO - 2021-08-26 06:06:48 --> Router Class Initialized
INFO - 2021-08-26 06:06:48 --> Output Class Initialized
INFO - 2021-08-26 06:06:48 --> Security Class Initialized
DEBUG - 2021-08-26 06:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:06:48 --> Input Class Initialized
INFO - 2021-08-26 06:06:48 --> Language Class Initialized
INFO - 2021-08-26 06:06:48 --> Language Class Initialized
INFO - 2021-08-26 06:06:48 --> Config Class Initialized
INFO - 2021-08-26 06:06:48 --> Loader Class Initialized
INFO - 2021-08-26 06:06:48 --> Helper loaded: url_helper
INFO - 2021-08-26 06:06:48 --> Helper loaded: file_helper
INFO - 2021-08-26 06:06:48 --> Helper loaded: form_helper
INFO - 2021-08-26 06:06:48 --> Helper loaded: my_helper
INFO - 2021-08-26 06:06:48 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:06:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:06:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:06:48 --> Controller Class Initialized
DEBUG - 2021-08-26 06:06:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-26 06:06:48 --> Final output sent to browser
DEBUG - 2021-08-26 06:06:48 --> Total execution time: 0.1494
INFO - 2021-08-26 06:07:57 --> Config Class Initialized
INFO - 2021-08-26 06:07:57 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:07:57 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:07:57 --> Utf8 Class Initialized
INFO - 2021-08-26 06:07:57 --> URI Class Initialized
INFO - 2021-08-26 06:07:57 --> Router Class Initialized
INFO - 2021-08-26 06:07:57 --> Output Class Initialized
INFO - 2021-08-26 06:07:57 --> Security Class Initialized
DEBUG - 2021-08-26 06:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:07:57 --> Input Class Initialized
INFO - 2021-08-26 06:07:57 --> Language Class Initialized
INFO - 2021-08-26 06:07:57 --> Language Class Initialized
INFO - 2021-08-26 06:07:57 --> Config Class Initialized
INFO - 2021-08-26 06:07:57 --> Loader Class Initialized
INFO - 2021-08-26 06:07:57 --> Helper loaded: url_helper
INFO - 2021-08-26 06:07:57 --> Helper loaded: file_helper
INFO - 2021-08-26 06:07:57 --> Helper loaded: form_helper
INFO - 2021-08-26 06:07:57 --> Helper loaded: my_helper
INFO - 2021-08-26 06:07:57 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:07:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:07:57 --> Controller Class Initialized
DEBUG - 2021-08-26 06:07:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tki.php
INFO - 2021-08-26 06:07:57 --> Final output sent to browser
DEBUG - 2021-08-26 06:07:57 --> Total execution time: 0.2306
INFO - 2021-08-26 06:08:27 --> Config Class Initialized
INFO - 2021-08-26 06:08:27 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:08:27 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:08:27 --> Utf8 Class Initialized
INFO - 2021-08-26 06:08:27 --> URI Class Initialized
INFO - 2021-08-26 06:08:27 --> Router Class Initialized
INFO - 2021-08-26 06:08:27 --> Output Class Initialized
INFO - 2021-08-26 06:08:27 --> Security Class Initialized
DEBUG - 2021-08-26 06:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:08:27 --> Input Class Initialized
INFO - 2021-08-26 06:08:27 --> Language Class Initialized
INFO - 2021-08-26 06:08:27 --> Language Class Initialized
INFO - 2021-08-26 06:08:27 --> Config Class Initialized
INFO - 2021-08-26 06:08:27 --> Loader Class Initialized
INFO - 2021-08-26 06:08:27 --> Helper loaded: url_helper
INFO - 2021-08-26 06:08:27 --> Helper loaded: file_helper
INFO - 2021-08-26 06:08:27 --> Helper loaded: form_helper
INFO - 2021-08-26 06:08:27 --> Helper loaded: my_helper
INFO - 2021-08-26 06:08:27 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:08:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:08:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:08:27 --> Controller Class Initialized
DEBUG - 2021-08-26 06:08:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-26 06:08:27 --> Final output sent to browser
DEBUG - 2021-08-26 06:08:27 --> Total execution time: 0.1461
INFO - 2021-08-26 06:08:30 --> Config Class Initialized
INFO - 2021-08-26 06:08:30 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:08:30 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:08:30 --> Utf8 Class Initialized
INFO - 2021-08-26 06:08:30 --> URI Class Initialized
INFO - 2021-08-26 06:08:30 --> Router Class Initialized
INFO - 2021-08-26 06:08:30 --> Output Class Initialized
INFO - 2021-08-26 06:08:30 --> Security Class Initialized
DEBUG - 2021-08-26 06:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:08:30 --> Input Class Initialized
INFO - 2021-08-26 06:08:30 --> Language Class Initialized
INFO - 2021-08-26 06:08:30 --> Language Class Initialized
INFO - 2021-08-26 06:08:30 --> Config Class Initialized
INFO - 2021-08-26 06:08:30 --> Loader Class Initialized
INFO - 2021-08-26 06:08:30 --> Helper loaded: url_helper
INFO - 2021-08-26 06:08:30 --> Helper loaded: file_helper
INFO - 2021-08-26 06:08:30 --> Helper loaded: form_helper
INFO - 2021-08-26 06:08:30 --> Helper loaded: my_helper
INFO - 2021-08-26 06:08:30 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:08:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:08:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:08:30 --> Controller Class Initialized
DEBUG - 2021-08-26 06:08:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-26 06:08:30 --> Final output sent to browser
DEBUG - 2021-08-26 06:08:30 --> Total execution time: 0.1542
INFO - 2021-08-26 06:12:11 --> Config Class Initialized
INFO - 2021-08-26 06:12:11 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:12:11 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:12:11 --> Utf8 Class Initialized
INFO - 2021-08-26 06:12:11 --> URI Class Initialized
INFO - 2021-08-26 06:12:11 --> Router Class Initialized
INFO - 2021-08-26 06:12:11 --> Output Class Initialized
INFO - 2021-08-26 06:12:11 --> Security Class Initialized
DEBUG - 2021-08-26 06:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:12:11 --> Input Class Initialized
INFO - 2021-08-26 06:12:11 --> Language Class Initialized
INFO - 2021-08-26 06:12:11 --> Language Class Initialized
INFO - 2021-08-26 06:12:11 --> Config Class Initialized
INFO - 2021-08-26 06:12:11 --> Loader Class Initialized
INFO - 2021-08-26 06:12:11 --> Helper loaded: url_helper
INFO - 2021-08-26 06:12:11 --> Helper loaded: file_helper
INFO - 2021-08-26 06:12:11 --> Helper loaded: form_helper
INFO - 2021-08-26 06:12:11 --> Helper loaded: my_helper
INFO - 2021-08-26 06:12:11 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:12:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:12:11 --> Controller Class Initialized
DEBUG - 2021-08-26 06:12:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-26 06:12:12 --> Final output sent to browser
DEBUG - 2021-08-26 06:12:12 --> Total execution time: 0.1428
INFO - 2021-08-26 06:12:22 --> Config Class Initialized
INFO - 2021-08-26 06:12:22 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:12:22 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:12:22 --> Utf8 Class Initialized
INFO - 2021-08-26 06:12:22 --> URI Class Initialized
INFO - 2021-08-26 06:12:22 --> Router Class Initialized
INFO - 2021-08-26 06:12:22 --> Output Class Initialized
INFO - 2021-08-26 06:12:22 --> Security Class Initialized
DEBUG - 2021-08-26 06:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:12:22 --> Input Class Initialized
INFO - 2021-08-26 06:12:22 --> Language Class Initialized
INFO - 2021-08-26 06:12:22 --> Language Class Initialized
INFO - 2021-08-26 06:12:22 --> Config Class Initialized
INFO - 2021-08-26 06:12:22 --> Loader Class Initialized
INFO - 2021-08-26 06:12:22 --> Helper loaded: url_helper
INFO - 2021-08-26 06:12:22 --> Helper loaded: file_helper
INFO - 2021-08-26 06:12:22 --> Helper loaded: form_helper
INFO - 2021-08-26 06:12:22 --> Helper loaded: my_helper
INFO - 2021-08-26 06:12:22 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:12:22 --> Controller Class Initialized
DEBUG - 2021-08-26 06:12:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-26 06:12:22 --> Final output sent to browser
DEBUG - 2021-08-26 06:12:22 --> Total execution time: 0.1395
INFO - 2021-08-26 06:12:24 --> Config Class Initialized
INFO - 2021-08-26 06:12:24 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:12:24 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:12:24 --> Utf8 Class Initialized
INFO - 2021-08-26 06:12:24 --> URI Class Initialized
INFO - 2021-08-26 06:12:24 --> Router Class Initialized
INFO - 2021-08-26 06:12:24 --> Output Class Initialized
INFO - 2021-08-26 06:12:24 --> Security Class Initialized
DEBUG - 2021-08-26 06:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:12:24 --> Input Class Initialized
INFO - 2021-08-26 06:12:24 --> Language Class Initialized
INFO - 2021-08-26 06:12:24 --> Language Class Initialized
INFO - 2021-08-26 06:12:24 --> Config Class Initialized
INFO - 2021-08-26 06:12:24 --> Loader Class Initialized
INFO - 2021-08-26 06:12:24 --> Helper loaded: url_helper
INFO - 2021-08-26 06:12:24 --> Helper loaded: file_helper
INFO - 2021-08-26 06:12:24 --> Helper loaded: form_helper
INFO - 2021-08-26 06:12:24 --> Helper loaded: my_helper
INFO - 2021-08-26 06:12:24 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:12:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:12:24 --> Controller Class Initialized
DEBUG - 2021-08-26 06:12:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-26 06:12:24 --> Final output sent to browser
DEBUG - 2021-08-26 06:12:24 --> Total execution time: 0.1445
INFO - 2021-08-26 06:12:33 --> Config Class Initialized
INFO - 2021-08-26 06:12:33 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:12:33 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:12:33 --> Utf8 Class Initialized
INFO - 2021-08-26 06:12:33 --> URI Class Initialized
INFO - 2021-08-26 06:12:33 --> Router Class Initialized
INFO - 2021-08-26 06:12:33 --> Output Class Initialized
INFO - 2021-08-26 06:12:33 --> Security Class Initialized
DEBUG - 2021-08-26 06:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:12:33 --> Input Class Initialized
INFO - 2021-08-26 06:12:33 --> Language Class Initialized
INFO - 2021-08-26 06:12:33 --> Language Class Initialized
INFO - 2021-08-26 06:12:33 --> Config Class Initialized
INFO - 2021-08-26 06:12:33 --> Loader Class Initialized
INFO - 2021-08-26 06:12:33 --> Helper loaded: url_helper
INFO - 2021-08-26 06:12:33 --> Helper loaded: file_helper
INFO - 2021-08-26 06:12:33 --> Helper loaded: form_helper
INFO - 2021-08-26 06:12:33 --> Helper loaded: my_helper
INFO - 2021-08-26 06:12:33 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:12:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:12:33 --> Controller Class Initialized
DEBUG - 2021-08-26 06:12:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-26 06:12:33 --> Final output sent to browser
DEBUG - 2021-08-26 06:12:33 --> Total execution time: 0.1424
INFO - 2021-08-26 06:12:36 --> Config Class Initialized
INFO - 2021-08-26 06:12:36 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:12:36 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:12:36 --> Utf8 Class Initialized
INFO - 2021-08-26 06:12:36 --> URI Class Initialized
INFO - 2021-08-26 06:12:36 --> Router Class Initialized
INFO - 2021-08-26 06:12:36 --> Output Class Initialized
INFO - 2021-08-26 06:12:36 --> Security Class Initialized
DEBUG - 2021-08-26 06:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:12:36 --> Input Class Initialized
INFO - 2021-08-26 06:12:36 --> Language Class Initialized
INFO - 2021-08-26 06:12:36 --> Language Class Initialized
INFO - 2021-08-26 06:12:36 --> Config Class Initialized
INFO - 2021-08-26 06:12:36 --> Loader Class Initialized
INFO - 2021-08-26 06:12:36 --> Helper loaded: url_helper
INFO - 2021-08-26 06:12:36 --> Helper loaded: file_helper
INFO - 2021-08-26 06:12:36 --> Helper loaded: form_helper
INFO - 2021-08-26 06:12:36 --> Helper loaded: my_helper
INFO - 2021-08-26 06:12:36 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:12:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:12:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:12:36 --> Controller Class Initialized
DEBUG - 2021-08-26 06:12:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-26 06:12:36 --> Final output sent to browser
DEBUG - 2021-08-26 06:12:36 --> Total execution time: 0.1481
INFO - 2021-08-26 06:12:43 --> Config Class Initialized
INFO - 2021-08-26 06:12:43 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:12:43 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:12:43 --> Utf8 Class Initialized
INFO - 2021-08-26 06:12:43 --> URI Class Initialized
INFO - 2021-08-26 06:12:43 --> Router Class Initialized
INFO - 2021-08-26 06:12:43 --> Output Class Initialized
INFO - 2021-08-26 06:12:43 --> Security Class Initialized
DEBUG - 2021-08-26 06:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:12:43 --> Input Class Initialized
INFO - 2021-08-26 06:12:43 --> Language Class Initialized
INFO - 2021-08-26 06:12:43 --> Language Class Initialized
INFO - 2021-08-26 06:12:43 --> Config Class Initialized
INFO - 2021-08-26 06:12:43 --> Loader Class Initialized
INFO - 2021-08-26 06:12:43 --> Helper loaded: url_helper
INFO - 2021-08-26 06:12:43 --> Helper loaded: file_helper
INFO - 2021-08-26 06:12:43 --> Helper loaded: form_helper
INFO - 2021-08-26 06:12:43 --> Helper loaded: my_helper
INFO - 2021-08-26 06:12:43 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:12:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:12:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:12:43 --> Controller Class Initialized
DEBUG - 2021-08-26 06:12:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-26 06:12:43 --> Final output sent to browser
DEBUG - 2021-08-26 06:12:43 --> Total execution time: 0.1727
INFO - 2021-08-26 06:12:52 --> Config Class Initialized
INFO - 2021-08-26 06:12:52 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:12:52 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:12:52 --> Utf8 Class Initialized
INFO - 2021-08-26 06:12:52 --> URI Class Initialized
INFO - 2021-08-26 06:12:52 --> Router Class Initialized
INFO - 2021-08-26 06:12:52 --> Output Class Initialized
INFO - 2021-08-26 06:12:52 --> Security Class Initialized
DEBUG - 2021-08-26 06:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:12:52 --> Input Class Initialized
INFO - 2021-08-26 06:12:52 --> Language Class Initialized
INFO - 2021-08-26 06:12:52 --> Language Class Initialized
INFO - 2021-08-26 06:12:52 --> Config Class Initialized
INFO - 2021-08-26 06:12:52 --> Loader Class Initialized
INFO - 2021-08-26 06:12:52 --> Helper loaded: url_helper
INFO - 2021-08-26 06:12:52 --> Helper loaded: file_helper
INFO - 2021-08-26 06:12:52 --> Helper loaded: form_helper
INFO - 2021-08-26 06:12:52 --> Helper loaded: my_helper
INFO - 2021-08-26 06:12:52 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:12:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:12:52 --> Controller Class Initialized
DEBUG - 2021-08-26 06:12:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-26 06:12:52 --> Final output sent to browser
DEBUG - 2021-08-26 06:12:52 --> Total execution time: 0.1459
INFO - 2021-08-26 06:12:54 --> Config Class Initialized
INFO - 2021-08-26 06:12:54 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:12:54 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:12:54 --> Utf8 Class Initialized
INFO - 2021-08-26 06:12:54 --> URI Class Initialized
INFO - 2021-08-26 06:12:54 --> Router Class Initialized
INFO - 2021-08-26 06:12:54 --> Output Class Initialized
INFO - 2021-08-26 06:12:54 --> Security Class Initialized
DEBUG - 2021-08-26 06:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:12:54 --> Input Class Initialized
INFO - 2021-08-26 06:12:54 --> Language Class Initialized
INFO - 2021-08-26 06:12:54 --> Language Class Initialized
INFO - 2021-08-26 06:12:54 --> Config Class Initialized
INFO - 2021-08-26 06:12:54 --> Loader Class Initialized
INFO - 2021-08-26 06:12:54 --> Helper loaded: url_helper
INFO - 2021-08-26 06:12:54 --> Helper loaded: file_helper
INFO - 2021-08-26 06:12:54 --> Helper loaded: form_helper
INFO - 2021-08-26 06:12:54 --> Helper loaded: my_helper
INFO - 2021-08-26 06:12:54 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:12:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:12:54 --> Controller Class Initialized
DEBUG - 2021-08-26 06:12:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-26 06:12:54 --> Final output sent to browser
DEBUG - 2021-08-26 06:12:54 --> Total execution time: 0.1555
INFO - 2021-08-26 06:13:05 --> Config Class Initialized
INFO - 2021-08-26 06:13:05 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:13:05 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:13:05 --> Utf8 Class Initialized
INFO - 2021-08-26 06:13:05 --> URI Class Initialized
INFO - 2021-08-26 06:13:05 --> Router Class Initialized
INFO - 2021-08-26 06:13:05 --> Output Class Initialized
INFO - 2021-08-26 06:13:05 --> Security Class Initialized
DEBUG - 2021-08-26 06:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:13:05 --> Input Class Initialized
INFO - 2021-08-26 06:13:05 --> Language Class Initialized
INFO - 2021-08-26 06:13:05 --> Language Class Initialized
INFO - 2021-08-26 06:13:05 --> Config Class Initialized
INFO - 2021-08-26 06:13:05 --> Loader Class Initialized
INFO - 2021-08-26 06:13:05 --> Helper loaded: url_helper
INFO - 2021-08-26 06:13:05 --> Helper loaded: file_helper
INFO - 2021-08-26 06:13:05 --> Helper loaded: form_helper
INFO - 2021-08-26 06:13:05 --> Helper loaded: my_helper
INFO - 2021-08-26 06:13:05 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:13:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:13:05 --> Controller Class Initialized
DEBUG - 2021-08-26 06:13:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-26 06:13:05 --> Final output sent to browser
DEBUG - 2021-08-26 06:13:05 --> Total execution time: 0.1504
INFO - 2021-08-26 06:13:14 --> Config Class Initialized
INFO - 2021-08-26 06:13:14 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:13:14 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:13:14 --> Utf8 Class Initialized
INFO - 2021-08-26 06:13:14 --> URI Class Initialized
INFO - 2021-08-26 06:13:14 --> Router Class Initialized
INFO - 2021-08-26 06:13:14 --> Output Class Initialized
INFO - 2021-08-26 06:13:14 --> Security Class Initialized
DEBUG - 2021-08-26 06:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:13:14 --> Input Class Initialized
INFO - 2021-08-26 06:13:14 --> Language Class Initialized
INFO - 2021-08-26 06:13:14 --> Language Class Initialized
INFO - 2021-08-26 06:13:14 --> Config Class Initialized
INFO - 2021-08-26 06:13:14 --> Loader Class Initialized
INFO - 2021-08-26 06:13:14 --> Helper loaded: url_helper
INFO - 2021-08-26 06:13:14 --> Helper loaded: file_helper
INFO - 2021-08-26 06:13:14 --> Helper loaded: form_helper
INFO - 2021-08-26 06:13:14 --> Helper loaded: my_helper
INFO - 2021-08-26 06:13:14 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:13:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:13:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:13:14 --> Controller Class Initialized
DEBUG - 2021-08-26 06:13:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-26 06:13:14 --> Final output sent to browser
DEBUG - 2021-08-26 06:13:14 --> Total execution time: 0.1392
INFO - 2021-08-26 06:13:15 --> Config Class Initialized
INFO - 2021-08-26 06:13:15 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:13:15 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:13:15 --> Utf8 Class Initialized
INFO - 2021-08-26 06:13:15 --> URI Class Initialized
INFO - 2021-08-26 06:13:15 --> Router Class Initialized
INFO - 2021-08-26 06:13:15 --> Output Class Initialized
INFO - 2021-08-26 06:13:15 --> Security Class Initialized
DEBUG - 2021-08-26 06:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:13:15 --> Input Class Initialized
INFO - 2021-08-26 06:13:15 --> Language Class Initialized
INFO - 2021-08-26 06:13:15 --> Language Class Initialized
INFO - 2021-08-26 06:13:15 --> Config Class Initialized
INFO - 2021-08-26 06:13:15 --> Loader Class Initialized
INFO - 2021-08-26 06:13:15 --> Helper loaded: url_helper
INFO - 2021-08-26 06:13:15 --> Helper loaded: file_helper
INFO - 2021-08-26 06:13:15 --> Helper loaded: form_helper
INFO - 2021-08-26 06:13:15 --> Helper loaded: my_helper
INFO - 2021-08-26 06:13:15 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:13:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:13:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:13:15 --> Controller Class Initialized
DEBUG - 2021-08-26 06:13:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-26 06:13:15 --> Final output sent to browser
DEBUG - 2021-08-26 06:13:15 --> Total execution time: 0.1445
INFO - 2021-08-26 06:23:01 --> Config Class Initialized
INFO - 2021-08-26 06:23:01 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:23:01 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:23:01 --> Utf8 Class Initialized
INFO - 2021-08-26 06:23:01 --> URI Class Initialized
INFO - 2021-08-26 06:23:01 --> Router Class Initialized
INFO - 2021-08-26 06:23:01 --> Output Class Initialized
INFO - 2021-08-26 06:23:01 --> Security Class Initialized
DEBUG - 2021-08-26 06:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:23:01 --> Input Class Initialized
INFO - 2021-08-26 06:23:01 --> Language Class Initialized
INFO - 2021-08-26 06:23:01 --> Language Class Initialized
INFO - 2021-08-26 06:23:01 --> Config Class Initialized
INFO - 2021-08-26 06:23:01 --> Loader Class Initialized
INFO - 2021-08-26 06:23:01 --> Helper loaded: url_helper
INFO - 2021-08-26 06:23:01 --> Helper loaded: file_helper
INFO - 2021-08-26 06:23:01 --> Helper loaded: form_helper
INFO - 2021-08-26 06:23:01 --> Helper loaded: my_helper
INFO - 2021-08-26 06:23:01 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:23:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:23:01 --> Controller Class Initialized
INFO - 2021-08-26 06:23:01 --> Helper loaded: cookie_helper
INFO - 2021-08-26 06:23:01 --> Config Class Initialized
INFO - 2021-08-26 06:23:01 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:23:01 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:23:01 --> Utf8 Class Initialized
INFO - 2021-08-26 06:23:01 --> URI Class Initialized
INFO - 2021-08-26 06:23:01 --> Router Class Initialized
INFO - 2021-08-26 06:23:01 --> Output Class Initialized
INFO - 2021-08-26 06:23:01 --> Security Class Initialized
DEBUG - 2021-08-26 06:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:23:01 --> Input Class Initialized
INFO - 2021-08-26 06:23:01 --> Language Class Initialized
INFO - 2021-08-26 06:23:01 --> Language Class Initialized
INFO - 2021-08-26 06:23:01 --> Config Class Initialized
INFO - 2021-08-26 06:23:01 --> Loader Class Initialized
INFO - 2021-08-26 06:23:01 --> Helper loaded: url_helper
INFO - 2021-08-26 06:23:01 --> Helper loaded: file_helper
INFO - 2021-08-26 06:23:01 --> Helper loaded: form_helper
INFO - 2021-08-26 06:23:01 --> Helper loaded: my_helper
INFO - 2021-08-26 06:23:01 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:23:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:23:01 --> Controller Class Initialized
DEBUG - 2021-08-26 06:23:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-08-26 06:23:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-26 06:23:01 --> Final output sent to browser
DEBUG - 2021-08-26 06:23:01 --> Total execution time: 0.0442
INFO - 2021-08-26 06:23:05 --> Config Class Initialized
INFO - 2021-08-26 06:23:05 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:23:05 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:23:05 --> Utf8 Class Initialized
INFO - 2021-08-26 06:23:05 --> URI Class Initialized
INFO - 2021-08-26 06:23:05 --> Router Class Initialized
INFO - 2021-08-26 06:23:05 --> Output Class Initialized
INFO - 2021-08-26 06:23:05 --> Security Class Initialized
DEBUG - 2021-08-26 06:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:23:05 --> Input Class Initialized
INFO - 2021-08-26 06:23:05 --> Language Class Initialized
INFO - 2021-08-26 06:23:05 --> Language Class Initialized
INFO - 2021-08-26 06:23:05 --> Config Class Initialized
INFO - 2021-08-26 06:23:05 --> Loader Class Initialized
INFO - 2021-08-26 06:23:05 --> Helper loaded: url_helper
INFO - 2021-08-26 06:23:05 --> Helper loaded: file_helper
INFO - 2021-08-26 06:23:05 --> Helper loaded: form_helper
INFO - 2021-08-26 06:23:05 --> Helper loaded: my_helper
INFO - 2021-08-26 06:23:05 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:23:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:23:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:23:05 --> Controller Class Initialized
INFO - 2021-08-26 06:23:05 --> Helper loaded: cookie_helper
INFO - 2021-08-26 06:23:05 --> Final output sent to browser
DEBUG - 2021-08-26 06:23:05 --> Total execution time: 0.0567
INFO - 2021-08-26 06:23:06 --> Config Class Initialized
INFO - 2021-08-26 06:23:06 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:23:06 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:23:06 --> Utf8 Class Initialized
INFO - 2021-08-26 06:23:06 --> URI Class Initialized
INFO - 2021-08-26 06:23:06 --> Router Class Initialized
INFO - 2021-08-26 06:23:06 --> Output Class Initialized
INFO - 2021-08-26 06:23:06 --> Security Class Initialized
DEBUG - 2021-08-26 06:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:23:06 --> Input Class Initialized
INFO - 2021-08-26 06:23:06 --> Language Class Initialized
INFO - 2021-08-26 06:23:06 --> Language Class Initialized
INFO - 2021-08-26 06:23:06 --> Config Class Initialized
INFO - 2021-08-26 06:23:06 --> Loader Class Initialized
INFO - 2021-08-26 06:23:06 --> Helper loaded: url_helper
INFO - 2021-08-26 06:23:06 --> Helper loaded: file_helper
INFO - 2021-08-26 06:23:06 --> Helper loaded: form_helper
INFO - 2021-08-26 06:23:06 --> Helper loaded: my_helper
INFO - 2021-08-26 06:23:06 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:23:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:23:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:23:06 --> Controller Class Initialized
DEBUG - 2021-08-26 06:23:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-08-26 06:23:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-26 06:23:06 --> Final output sent to browser
DEBUG - 2021-08-26 06:23:06 --> Total execution time: 0.7279
INFO - 2021-08-26 06:30:27 --> Config Class Initialized
INFO - 2021-08-26 06:30:27 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:30:27 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:30:27 --> Utf8 Class Initialized
INFO - 2021-08-26 06:30:27 --> URI Class Initialized
INFO - 2021-08-26 06:30:27 --> Router Class Initialized
INFO - 2021-08-26 06:30:27 --> Output Class Initialized
INFO - 2021-08-26 06:30:27 --> Security Class Initialized
DEBUG - 2021-08-26 06:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:30:27 --> Input Class Initialized
INFO - 2021-08-26 06:30:27 --> Language Class Initialized
INFO - 2021-08-26 06:30:27 --> Language Class Initialized
INFO - 2021-08-26 06:30:27 --> Config Class Initialized
INFO - 2021-08-26 06:30:27 --> Loader Class Initialized
INFO - 2021-08-26 06:30:27 --> Helper loaded: url_helper
INFO - 2021-08-26 06:30:27 --> Helper loaded: file_helper
INFO - 2021-08-26 06:30:27 --> Helper loaded: form_helper
INFO - 2021-08-26 06:30:27 --> Helper loaded: my_helper
INFO - 2021-08-26 06:30:27 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:30:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:30:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:30:27 --> Controller Class Initialized
DEBUG - 2021-08-26 06:30:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-08-26 06:30:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-26 06:30:27 --> Final output sent to browser
DEBUG - 2021-08-26 06:30:27 --> Total execution time: 0.0595
INFO - 2021-08-26 06:30:28 --> Config Class Initialized
INFO - 2021-08-26 06:30:28 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:30:28 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:30:28 --> Utf8 Class Initialized
INFO - 2021-08-26 06:30:28 --> URI Class Initialized
INFO - 2021-08-26 06:30:28 --> Router Class Initialized
INFO - 2021-08-26 06:30:28 --> Output Class Initialized
INFO - 2021-08-26 06:30:28 --> Security Class Initialized
DEBUG - 2021-08-26 06:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:30:28 --> Input Class Initialized
INFO - 2021-08-26 06:30:28 --> Language Class Initialized
INFO - 2021-08-26 06:30:28 --> Language Class Initialized
INFO - 2021-08-26 06:30:28 --> Config Class Initialized
INFO - 2021-08-26 06:30:28 --> Loader Class Initialized
INFO - 2021-08-26 06:30:28 --> Helper loaded: url_helper
INFO - 2021-08-26 06:30:28 --> Helper loaded: file_helper
INFO - 2021-08-26 06:30:28 --> Helper loaded: form_helper
INFO - 2021-08-26 06:30:28 --> Helper loaded: my_helper
INFO - 2021-08-26 06:30:28 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:30:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:30:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:30:28 --> Controller Class Initialized
DEBUG - 2021-08-26 06:30:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tki.php
INFO - 2021-08-26 06:30:29 --> Final output sent to browser
DEBUG - 2021-08-26 06:30:29 --> Total execution time: 0.2522
INFO - 2021-08-26 06:31:01 --> Config Class Initialized
INFO - 2021-08-26 06:31:01 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:31:01 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:31:01 --> Utf8 Class Initialized
INFO - 2021-08-26 06:31:01 --> URI Class Initialized
INFO - 2021-08-26 06:31:01 --> Router Class Initialized
INFO - 2021-08-26 06:31:01 --> Output Class Initialized
INFO - 2021-08-26 06:31:01 --> Security Class Initialized
DEBUG - 2021-08-26 06:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:31:01 --> Input Class Initialized
INFO - 2021-08-26 06:31:01 --> Language Class Initialized
INFO - 2021-08-26 06:31:01 --> Language Class Initialized
INFO - 2021-08-26 06:31:01 --> Config Class Initialized
INFO - 2021-08-26 06:31:01 --> Loader Class Initialized
INFO - 2021-08-26 06:31:01 --> Helper loaded: url_helper
INFO - 2021-08-26 06:31:01 --> Helper loaded: file_helper
INFO - 2021-08-26 06:31:01 --> Helper loaded: form_helper
INFO - 2021-08-26 06:31:01 --> Helper loaded: my_helper
INFO - 2021-08-26 06:31:01 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:31:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:31:01 --> Controller Class Initialized
DEBUG - 2021-08-26 06:31:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tki.php
INFO - 2021-08-26 06:31:01 --> Final output sent to browser
DEBUG - 2021-08-26 06:31:01 --> Total execution time: 0.2030
INFO - 2021-08-26 06:31:20 --> Config Class Initialized
INFO - 2021-08-26 06:31:20 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:31:20 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:31:20 --> Utf8 Class Initialized
INFO - 2021-08-26 06:31:20 --> URI Class Initialized
INFO - 2021-08-26 06:31:20 --> Router Class Initialized
INFO - 2021-08-26 06:31:20 --> Output Class Initialized
INFO - 2021-08-26 06:31:20 --> Security Class Initialized
DEBUG - 2021-08-26 06:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:31:20 --> Input Class Initialized
INFO - 2021-08-26 06:31:20 --> Language Class Initialized
INFO - 2021-08-26 06:31:20 --> Language Class Initialized
INFO - 2021-08-26 06:31:20 --> Config Class Initialized
INFO - 2021-08-26 06:31:20 --> Loader Class Initialized
INFO - 2021-08-26 06:31:20 --> Helper loaded: url_helper
INFO - 2021-08-26 06:31:20 --> Helper loaded: file_helper
INFO - 2021-08-26 06:31:20 --> Helper loaded: form_helper
INFO - 2021-08-26 06:31:20 --> Helper loaded: my_helper
INFO - 2021-08-26 06:31:20 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:31:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:31:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:31:20 --> Controller Class Initialized
DEBUG - 2021-08-26 06:31:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-08-26 06:31:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-26 06:31:20 --> Final output sent to browser
DEBUG - 2021-08-26 06:31:20 --> Total execution time: 0.0723
INFO - 2021-08-26 06:31:24 --> Config Class Initialized
INFO - 2021-08-26 06:31:24 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:31:24 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:31:24 --> Utf8 Class Initialized
INFO - 2021-08-26 06:31:24 --> URI Class Initialized
INFO - 2021-08-26 06:31:24 --> Router Class Initialized
INFO - 2021-08-26 06:31:24 --> Output Class Initialized
INFO - 2021-08-26 06:31:24 --> Security Class Initialized
DEBUG - 2021-08-26 06:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:31:24 --> Input Class Initialized
INFO - 2021-08-26 06:31:24 --> Language Class Initialized
INFO - 2021-08-26 06:31:24 --> Language Class Initialized
INFO - 2021-08-26 06:31:24 --> Config Class Initialized
INFO - 2021-08-26 06:31:24 --> Loader Class Initialized
INFO - 2021-08-26 06:31:24 --> Helper loaded: url_helper
INFO - 2021-08-26 06:31:24 --> Helper loaded: file_helper
INFO - 2021-08-26 06:31:24 --> Helper loaded: form_helper
INFO - 2021-08-26 06:31:24 --> Helper loaded: my_helper
INFO - 2021-08-26 06:31:24 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:31:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:31:24 --> Controller Class Initialized
DEBUG - 2021-08-26 06:31:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-26 06:31:24 --> Final output sent to browser
DEBUG - 2021-08-26 06:31:24 --> Total execution time: 0.1470
INFO - 2021-08-26 06:31:35 --> Config Class Initialized
INFO - 2021-08-26 06:31:35 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:31:35 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:31:35 --> Utf8 Class Initialized
INFO - 2021-08-26 06:31:35 --> URI Class Initialized
INFO - 2021-08-26 06:31:35 --> Router Class Initialized
INFO - 2021-08-26 06:31:35 --> Output Class Initialized
INFO - 2021-08-26 06:31:35 --> Security Class Initialized
DEBUG - 2021-08-26 06:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:31:35 --> Input Class Initialized
INFO - 2021-08-26 06:31:35 --> Language Class Initialized
INFO - 2021-08-26 06:31:35 --> Language Class Initialized
INFO - 2021-08-26 06:31:35 --> Config Class Initialized
INFO - 2021-08-26 06:31:35 --> Loader Class Initialized
INFO - 2021-08-26 06:31:35 --> Helper loaded: url_helper
INFO - 2021-08-26 06:31:35 --> Helper loaded: file_helper
INFO - 2021-08-26 06:31:35 --> Helper loaded: form_helper
INFO - 2021-08-26 06:31:35 --> Helper loaded: my_helper
INFO - 2021-08-26 06:31:35 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:31:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:31:35 --> Controller Class Initialized
DEBUG - 2021-08-26 06:31:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-26 06:31:35 --> Final output sent to browser
DEBUG - 2021-08-26 06:31:35 --> Total execution time: 0.1386
INFO - 2021-08-26 06:31:45 --> Config Class Initialized
INFO - 2021-08-26 06:31:45 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:31:45 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:31:45 --> Utf8 Class Initialized
INFO - 2021-08-26 06:31:45 --> URI Class Initialized
INFO - 2021-08-26 06:31:45 --> Router Class Initialized
INFO - 2021-08-26 06:31:45 --> Output Class Initialized
INFO - 2021-08-26 06:31:45 --> Security Class Initialized
DEBUG - 2021-08-26 06:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:31:45 --> Input Class Initialized
INFO - 2021-08-26 06:31:45 --> Language Class Initialized
INFO - 2021-08-26 06:31:45 --> Language Class Initialized
INFO - 2021-08-26 06:31:45 --> Config Class Initialized
INFO - 2021-08-26 06:31:45 --> Loader Class Initialized
INFO - 2021-08-26 06:31:45 --> Helper loaded: url_helper
INFO - 2021-08-26 06:31:45 --> Helper loaded: file_helper
INFO - 2021-08-26 06:31:45 --> Helper loaded: form_helper
INFO - 2021-08-26 06:31:45 --> Helper loaded: my_helper
INFO - 2021-08-26 06:31:45 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:31:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:31:45 --> Controller Class Initialized
DEBUG - 2021-08-26 06:31:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-26 06:31:45 --> Final output sent to browser
DEBUG - 2021-08-26 06:31:45 --> Total execution time: 0.1574
INFO - 2021-08-26 06:31:52 --> Config Class Initialized
INFO - 2021-08-26 06:31:52 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:31:52 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:31:52 --> Utf8 Class Initialized
INFO - 2021-08-26 06:31:52 --> URI Class Initialized
INFO - 2021-08-26 06:31:52 --> Router Class Initialized
INFO - 2021-08-26 06:31:52 --> Output Class Initialized
INFO - 2021-08-26 06:31:52 --> Security Class Initialized
DEBUG - 2021-08-26 06:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:31:52 --> Input Class Initialized
INFO - 2021-08-26 06:31:52 --> Language Class Initialized
INFO - 2021-08-26 06:31:52 --> Language Class Initialized
INFO - 2021-08-26 06:31:52 --> Config Class Initialized
INFO - 2021-08-26 06:31:52 --> Loader Class Initialized
INFO - 2021-08-26 06:31:52 --> Helper loaded: url_helper
INFO - 2021-08-26 06:31:52 --> Helper loaded: file_helper
INFO - 2021-08-26 06:31:52 --> Helper loaded: form_helper
INFO - 2021-08-26 06:31:52 --> Helper loaded: my_helper
INFO - 2021-08-26 06:31:52 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:31:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:31:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:31:52 --> Controller Class Initialized
DEBUG - 2021-08-26 06:31:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-26 06:31:52 --> Final output sent to browser
DEBUG - 2021-08-26 06:31:52 --> Total execution time: 0.1306
INFO - 2021-08-26 06:35:46 --> Config Class Initialized
INFO - 2021-08-26 06:35:46 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:35:46 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:35:46 --> Utf8 Class Initialized
INFO - 2021-08-26 06:35:46 --> URI Class Initialized
INFO - 2021-08-26 06:35:46 --> Router Class Initialized
INFO - 2021-08-26 06:35:46 --> Output Class Initialized
INFO - 2021-08-26 06:35:46 --> Security Class Initialized
DEBUG - 2021-08-26 06:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:35:46 --> Input Class Initialized
INFO - 2021-08-26 06:35:46 --> Language Class Initialized
INFO - 2021-08-26 06:35:46 --> Language Class Initialized
INFO - 2021-08-26 06:35:46 --> Config Class Initialized
INFO - 2021-08-26 06:35:46 --> Loader Class Initialized
INFO - 2021-08-26 06:35:46 --> Helper loaded: url_helper
INFO - 2021-08-26 06:35:46 --> Helper loaded: file_helper
INFO - 2021-08-26 06:35:46 --> Helper loaded: form_helper
INFO - 2021-08-26 06:35:46 --> Helper loaded: my_helper
INFO - 2021-08-26 06:35:46 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:35:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:35:46 --> Controller Class Initialized
INFO - 2021-08-26 06:35:46 --> Helper loaded: cookie_helper
INFO - 2021-08-26 06:35:46 --> Config Class Initialized
INFO - 2021-08-26 06:35:46 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:35:46 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:35:46 --> Utf8 Class Initialized
INFO - 2021-08-26 06:35:46 --> URI Class Initialized
INFO - 2021-08-26 06:35:46 --> Router Class Initialized
INFO - 2021-08-26 06:35:46 --> Output Class Initialized
INFO - 2021-08-26 06:35:46 --> Security Class Initialized
DEBUG - 2021-08-26 06:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:35:46 --> Input Class Initialized
INFO - 2021-08-26 06:35:46 --> Language Class Initialized
INFO - 2021-08-26 06:35:46 --> Language Class Initialized
INFO - 2021-08-26 06:35:46 --> Config Class Initialized
INFO - 2021-08-26 06:35:46 --> Loader Class Initialized
INFO - 2021-08-26 06:35:46 --> Helper loaded: url_helper
INFO - 2021-08-26 06:35:46 --> Helper loaded: file_helper
INFO - 2021-08-26 06:35:46 --> Helper loaded: form_helper
INFO - 2021-08-26 06:35:46 --> Helper loaded: my_helper
INFO - 2021-08-26 06:35:46 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:35:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:35:46 --> Controller Class Initialized
DEBUG - 2021-08-26 06:35:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-08-26 06:35:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-26 06:35:46 --> Final output sent to browser
DEBUG - 2021-08-26 06:35:46 --> Total execution time: 0.0546
INFO - 2021-08-26 06:36:19 --> Config Class Initialized
INFO - 2021-08-26 06:36:19 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:36:19 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:36:19 --> Utf8 Class Initialized
INFO - 2021-08-26 06:36:19 --> URI Class Initialized
INFO - 2021-08-26 06:36:19 --> Router Class Initialized
INFO - 2021-08-26 06:36:19 --> Output Class Initialized
INFO - 2021-08-26 06:36:19 --> Security Class Initialized
DEBUG - 2021-08-26 06:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:36:20 --> Input Class Initialized
INFO - 2021-08-26 06:36:20 --> Language Class Initialized
INFO - 2021-08-26 06:36:20 --> Language Class Initialized
INFO - 2021-08-26 06:36:20 --> Config Class Initialized
INFO - 2021-08-26 06:36:20 --> Loader Class Initialized
INFO - 2021-08-26 06:36:20 --> Helper loaded: url_helper
INFO - 2021-08-26 06:36:20 --> Helper loaded: file_helper
INFO - 2021-08-26 06:36:20 --> Helper loaded: form_helper
INFO - 2021-08-26 06:36:20 --> Helper loaded: my_helper
INFO - 2021-08-26 06:36:20 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:36:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:36:20 --> Controller Class Initialized
INFO - 2021-08-26 06:36:20 --> Helper loaded: cookie_helper
INFO - 2021-08-26 06:36:20 --> Final output sent to browser
DEBUG - 2021-08-26 06:36:20 --> Total execution time: 0.0631
INFO - 2021-08-26 06:36:20 --> Config Class Initialized
INFO - 2021-08-26 06:36:20 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:36:20 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:36:20 --> Utf8 Class Initialized
INFO - 2021-08-26 06:36:20 --> URI Class Initialized
INFO - 2021-08-26 06:36:20 --> Router Class Initialized
INFO - 2021-08-26 06:36:20 --> Output Class Initialized
INFO - 2021-08-26 06:36:20 --> Security Class Initialized
DEBUG - 2021-08-26 06:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:36:20 --> Input Class Initialized
INFO - 2021-08-26 06:36:20 --> Language Class Initialized
INFO - 2021-08-26 06:36:20 --> Language Class Initialized
INFO - 2021-08-26 06:36:20 --> Config Class Initialized
INFO - 2021-08-26 06:36:20 --> Loader Class Initialized
INFO - 2021-08-26 06:36:20 --> Helper loaded: url_helper
INFO - 2021-08-26 06:36:20 --> Helper loaded: file_helper
INFO - 2021-08-26 06:36:20 --> Helper loaded: form_helper
INFO - 2021-08-26 06:36:20 --> Helper loaded: my_helper
INFO - 2021-08-26 06:36:20 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:36:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:36:20 --> Controller Class Initialized
DEBUG - 2021-08-26 06:36:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-08-26 06:36:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-26 06:36:21 --> Final output sent to browser
DEBUG - 2021-08-26 06:36:21 --> Total execution time: 0.7483
INFO - 2021-08-26 06:36:24 --> Config Class Initialized
INFO - 2021-08-26 06:36:24 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:36:24 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:36:24 --> Utf8 Class Initialized
INFO - 2021-08-26 06:36:24 --> URI Class Initialized
INFO - 2021-08-26 06:36:24 --> Router Class Initialized
INFO - 2021-08-26 06:36:24 --> Output Class Initialized
INFO - 2021-08-26 06:36:24 --> Security Class Initialized
DEBUG - 2021-08-26 06:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:36:24 --> Input Class Initialized
INFO - 2021-08-26 06:36:24 --> Language Class Initialized
INFO - 2021-08-26 06:36:24 --> Language Class Initialized
INFO - 2021-08-26 06:36:24 --> Config Class Initialized
INFO - 2021-08-26 06:36:24 --> Loader Class Initialized
INFO - 2021-08-26 06:36:24 --> Helper loaded: url_helper
INFO - 2021-08-26 06:36:24 --> Helper loaded: file_helper
INFO - 2021-08-26 06:36:24 --> Helper loaded: form_helper
INFO - 2021-08-26 06:36:24 --> Helper loaded: my_helper
INFO - 2021-08-26 06:36:24 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:36:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:36:24 --> Controller Class Initialized
DEBUG - 2021-08-26 06:36:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-08-26 06:36:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-26 06:36:24 --> Final output sent to browser
DEBUG - 2021-08-26 06:36:24 --> Total execution time: 0.0730
INFO - 2021-08-26 06:36:25 --> Config Class Initialized
INFO - 2021-08-26 06:36:25 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:36:25 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:36:25 --> Utf8 Class Initialized
INFO - 2021-08-26 06:36:25 --> URI Class Initialized
INFO - 2021-08-26 06:36:25 --> Router Class Initialized
INFO - 2021-08-26 06:36:25 --> Output Class Initialized
INFO - 2021-08-26 06:36:25 --> Security Class Initialized
DEBUG - 2021-08-26 06:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:36:25 --> Input Class Initialized
INFO - 2021-08-26 06:36:25 --> Language Class Initialized
INFO - 2021-08-26 06:36:25 --> Language Class Initialized
INFO - 2021-08-26 06:36:25 --> Config Class Initialized
INFO - 2021-08-26 06:36:25 --> Loader Class Initialized
INFO - 2021-08-26 06:36:25 --> Helper loaded: url_helper
INFO - 2021-08-26 06:36:25 --> Helper loaded: file_helper
INFO - 2021-08-26 06:36:25 --> Helper loaded: form_helper
INFO - 2021-08-26 06:36:25 --> Helper loaded: my_helper
INFO - 2021-08-26 06:36:25 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:36:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:36:25 --> Controller Class Initialized
DEBUG - 2021-08-26 06:36:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tki.php
INFO - 2021-08-26 06:36:26 --> Final output sent to browser
DEBUG - 2021-08-26 06:36:26 --> Total execution time: 0.2590
INFO - 2021-08-26 06:36:57 --> Config Class Initialized
INFO - 2021-08-26 06:36:57 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:36:57 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:36:57 --> Utf8 Class Initialized
INFO - 2021-08-26 06:36:57 --> URI Class Initialized
INFO - 2021-08-26 06:36:57 --> Router Class Initialized
INFO - 2021-08-26 06:36:57 --> Output Class Initialized
INFO - 2021-08-26 06:36:57 --> Security Class Initialized
DEBUG - 2021-08-26 06:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:36:57 --> Input Class Initialized
INFO - 2021-08-26 06:36:57 --> Language Class Initialized
INFO - 2021-08-26 06:36:57 --> Language Class Initialized
INFO - 2021-08-26 06:36:57 --> Config Class Initialized
INFO - 2021-08-26 06:36:57 --> Loader Class Initialized
INFO - 2021-08-26 06:36:57 --> Helper loaded: url_helper
INFO - 2021-08-26 06:36:57 --> Helper loaded: file_helper
INFO - 2021-08-26 06:36:57 --> Helper loaded: form_helper
INFO - 2021-08-26 06:36:57 --> Helper loaded: my_helper
INFO - 2021-08-26 06:36:57 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:36:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:36:57 --> Controller Class Initialized
DEBUG - 2021-08-26 06:36:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-08-26 06:36:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-26 06:36:57 --> Final output sent to browser
DEBUG - 2021-08-26 06:36:57 --> Total execution time: 0.0700
INFO - 2021-08-26 06:37:00 --> Config Class Initialized
INFO - 2021-08-26 06:37:00 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:37:00 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:37:00 --> Utf8 Class Initialized
INFO - 2021-08-26 06:37:00 --> URI Class Initialized
INFO - 2021-08-26 06:37:00 --> Router Class Initialized
INFO - 2021-08-26 06:37:00 --> Output Class Initialized
INFO - 2021-08-26 06:37:00 --> Security Class Initialized
DEBUG - 2021-08-26 06:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:37:00 --> Input Class Initialized
INFO - 2021-08-26 06:37:00 --> Language Class Initialized
INFO - 2021-08-26 06:37:00 --> Language Class Initialized
INFO - 2021-08-26 06:37:00 --> Config Class Initialized
INFO - 2021-08-26 06:37:00 --> Loader Class Initialized
INFO - 2021-08-26 06:37:00 --> Helper loaded: url_helper
INFO - 2021-08-26 06:37:00 --> Helper loaded: file_helper
INFO - 2021-08-26 06:37:00 --> Helper loaded: form_helper
INFO - 2021-08-26 06:37:00 --> Helper loaded: my_helper
INFO - 2021-08-26 06:37:00 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:37:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:37:00 --> Controller Class Initialized
DEBUG - 2021-08-26 06:37:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tki.php
INFO - 2021-08-26 06:37:01 --> Final output sent to browser
DEBUG - 2021-08-26 06:37:01 --> Total execution time: 0.2187
INFO - 2021-08-26 06:37:34 --> Config Class Initialized
INFO - 2021-08-26 06:37:34 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:37:34 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:37:34 --> Utf8 Class Initialized
INFO - 2021-08-26 06:37:34 --> URI Class Initialized
INFO - 2021-08-26 06:37:34 --> Router Class Initialized
INFO - 2021-08-26 06:37:34 --> Output Class Initialized
INFO - 2021-08-26 06:37:34 --> Security Class Initialized
DEBUG - 2021-08-26 06:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:37:34 --> Input Class Initialized
INFO - 2021-08-26 06:37:34 --> Language Class Initialized
INFO - 2021-08-26 06:37:34 --> Language Class Initialized
INFO - 2021-08-26 06:37:34 --> Config Class Initialized
INFO - 2021-08-26 06:37:34 --> Loader Class Initialized
INFO - 2021-08-26 06:37:34 --> Helper loaded: url_helper
INFO - 2021-08-26 06:37:34 --> Helper loaded: file_helper
INFO - 2021-08-26 06:37:34 --> Helper loaded: form_helper
INFO - 2021-08-26 06:37:34 --> Helper loaded: my_helper
INFO - 2021-08-26 06:37:34 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:37:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:37:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:37:34 --> Controller Class Initialized
DEBUG - 2021-08-26 06:37:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-26 06:37:34 --> Final output sent to browser
DEBUG - 2021-08-26 06:37:34 --> Total execution time: 0.1530
INFO - 2021-08-26 06:37:36 --> Config Class Initialized
INFO - 2021-08-26 06:37:36 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:37:36 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:37:36 --> Utf8 Class Initialized
INFO - 2021-08-26 06:37:36 --> URI Class Initialized
INFO - 2021-08-26 06:37:36 --> Router Class Initialized
INFO - 2021-08-26 06:37:36 --> Output Class Initialized
INFO - 2021-08-26 06:37:36 --> Security Class Initialized
DEBUG - 2021-08-26 06:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:37:36 --> Input Class Initialized
INFO - 2021-08-26 06:37:36 --> Language Class Initialized
INFO - 2021-08-26 06:37:36 --> Language Class Initialized
INFO - 2021-08-26 06:37:36 --> Config Class Initialized
INFO - 2021-08-26 06:37:36 --> Loader Class Initialized
INFO - 2021-08-26 06:37:36 --> Helper loaded: url_helper
INFO - 2021-08-26 06:37:36 --> Helper loaded: file_helper
INFO - 2021-08-26 06:37:36 --> Helper loaded: form_helper
INFO - 2021-08-26 06:37:36 --> Helper loaded: my_helper
INFO - 2021-08-26 06:37:36 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:37:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:37:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:37:36 --> Controller Class Initialized
DEBUG - 2021-08-26 06:37:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-26 06:37:36 --> Final output sent to browser
DEBUG - 2021-08-26 06:37:36 --> Total execution time: 0.1360
INFO - 2021-08-26 06:37:37 --> Config Class Initialized
INFO - 2021-08-26 06:37:37 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:37:37 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:37:37 --> Utf8 Class Initialized
INFO - 2021-08-26 06:37:37 --> URI Class Initialized
INFO - 2021-08-26 06:37:37 --> Router Class Initialized
INFO - 2021-08-26 06:37:37 --> Output Class Initialized
INFO - 2021-08-26 06:37:37 --> Security Class Initialized
DEBUG - 2021-08-26 06:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:37:37 --> Input Class Initialized
INFO - 2021-08-26 06:37:37 --> Language Class Initialized
INFO - 2021-08-26 06:37:37 --> Language Class Initialized
INFO - 2021-08-26 06:37:37 --> Config Class Initialized
INFO - 2021-08-26 06:37:37 --> Loader Class Initialized
INFO - 2021-08-26 06:37:37 --> Helper loaded: url_helper
INFO - 2021-08-26 06:37:37 --> Helper loaded: file_helper
INFO - 2021-08-26 06:37:37 --> Helper loaded: form_helper
INFO - 2021-08-26 06:37:37 --> Helper loaded: my_helper
INFO - 2021-08-26 06:37:37 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:37:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:37:37 --> Controller Class Initialized
DEBUG - 2021-08-26 06:37:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-26 06:37:38 --> Final output sent to browser
DEBUG - 2021-08-26 06:37:38 --> Total execution time: 0.1509
INFO - 2021-08-26 06:37:39 --> Config Class Initialized
INFO - 2021-08-26 06:37:39 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:37:39 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:37:39 --> Utf8 Class Initialized
INFO - 2021-08-26 06:37:39 --> URI Class Initialized
INFO - 2021-08-26 06:37:39 --> Router Class Initialized
INFO - 2021-08-26 06:37:39 --> Output Class Initialized
INFO - 2021-08-26 06:37:39 --> Security Class Initialized
DEBUG - 2021-08-26 06:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:37:39 --> Input Class Initialized
INFO - 2021-08-26 06:37:39 --> Language Class Initialized
INFO - 2021-08-26 06:37:39 --> Language Class Initialized
INFO - 2021-08-26 06:37:39 --> Config Class Initialized
INFO - 2021-08-26 06:37:39 --> Loader Class Initialized
INFO - 2021-08-26 06:37:39 --> Helper loaded: url_helper
INFO - 2021-08-26 06:37:39 --> Helper loaded: file_helper
INFO - 2021-08-26 06:37:39 --> Helper loaded: form_helper
INFO - 2021-08-26 06:37:39 --> Helper loaded: my_helper
INFO - 2021-08-26 06:37:39 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:37:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:37:39 --> Controller Class Initialized
DEBUG - 2021-08-26 06:37:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-26 06:37:39 --> Final output sent to browser
DEBUG - 2021-08-26 06:37:39 --> Total execution time: 0.1336
INFO - 2021-08-26 06:37:43 --> Config Class Initialized
INFO - 2021-08-26 06:37:43 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:37:43 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:37:43 --> Utf8 Class Initialized
INFO - 2021-08-26 06:37:43 --> URI Class Initialized
INFO - 2021-08-26 06:37:43 --> Router Class Initialized
INFO - 2021-08-26 06:37:43 --> Output Class Initialized
INFO - 2021-08-26 06:37:43 --> Security Class Initialized
DEBUG - 2021-08-26 06:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:37:43 --> Input Class Initialized
INFO - 2021-08-26 06:37:43 --> Language Class Initialized
INFO - 2021-08-26 06:37:43 --> Language Class Initialized
INFO - 2021-08-26 06:37:43 --> Config Class Initialized
INFO - 2021-08-26 06:37:43 --> Loader Class Initialized
INFO - 2021-08-26 06:37:43 --> Helper loaded: url_helper
INFO - 2021-08-26 06:37:43 --> Helper loaded: file_helper
INFO - 2021-08-26 06:37:43 --> Helper loaded: form_helper
INFO - 2021-08-26 06:37:43 --> Helper loaded: my_helper
INFO - 2021-08-26 06:37:43 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:37:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:37:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:37:43 --> Controller Class Initialized
DEBUG - 2021-08-26 06:37:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-26 06:37:43 --> Final output sent to browser
DEBUG - 2021-08-26 06:37:43 --> Total execution time: 0.1494
INFO - 2021-08-26 06:37:45 --> Config Class Initialized
INFO - 2021-08-26 06:37:45 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:37:45 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:37:45 --> Utf8 Class Initialized
INFO - 2021-08-26 06:37:45 --> URI Class Initialized
INFO - 2021-08-26 06:37:45 --> Router Class Initialized
INFO - 2021-08-26 06:37:45 --> Output Class Initialized
INFO - 2021-08-26 06:37:45 --> Security Class Initialized
DEBUG - 2021-08-26 06:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:37:45 --> Input Class Initialized
INFO - 2021-08-26 06:37:45 --> Language Class Initialized
INFO - 2021-08-26 06:37:45 --> Language Class Initialized
INFO - 2021-08-26 06:37:45 --> Config Class Initialized
INFO - 2021-08-26 06:37:45 --> Loader Class Initialized
INFO - 2021-08-26 06:37:45 --> Helper loaded: url_helper
INFO - 2021-08-26 06:37:45 --> Helper loaded: file_helper
INFO - 2021-08-26 06:37:45 --> Helper loaded: form_helper
INFO - 2021-08-26 06:37:45 --> Helper loaded: my_helper
INFO - 2021-08-26 06:37:45 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:37:45 --> Controller Class Initialized
DEBUG - 2021-08-26 06:37:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-26 06:37:46 --> Final output sent to browser
DEBUG - 2021-08-26 06:37:46 --> Total execution time: 0.1625
INFO - 2021-08-26 06:37:47 --> Config Class Initialized
INFO - 2021-08-26 06:37:47 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:37:47 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:37:47 --> Utf8 Class Initialized
INFO - 2021-08-26 06:37:47 --> URI Class Initialized
INFO - 2021-08-26 06:37:47 --> Router Class Initialized
INFO - 2021-08-26 06:37:47 --> Output Class Initialized
INFO - 2021-08-26 06:37:47 --> Security Class Initialized
DEBUG - 2021-08-26 06:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:37:47 --> Input Class Initialized
INFO - 2021-08-26 06:37:47 --> Language Class Initialized
INFO - 2021-08-26 06:37:47 --> Language Class Initialized
INFO - 2021-08-26 06:37:47 --> Config Class Initialized
INFO - 2021-08-26 06:37:47 --> Loader Class Initialized
INFO - 2021-08-26 06:37:47 --> Helper loaded: url_helper
INFO - 2021-08-26 06:37:47 --> Helper loaded: file_helper
INFO - 2021-08-26 06:37:47 --> Helper loaded: form_helper
INFO - 2021-08-26 06:37:47 --> Helper loaded: my_helper
INFO - 2021-08-26 06:37:47 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:37:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:37:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:37:47 --> Controller Class Initialized
DEBUG - 2021-08-26 06:37:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-26 06:37:47 --> Final output sent to browser
DEBUG - 2021-08-26 06:37:47 --> Total execution time: 0.1453
INFO - 2021-08-26 06:37:50 --> Config Class Initialized
INFO - 2021-08-26 06:37:50 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:37:50 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:37:50 --> Utf8 Class Initialized
INFO - 2021-08-26 06:37:50 --> URI Class Initialized
INFO - 2021-08-26 06:37:50 --> Router Class Initialized
INFO - 2021-08-26 06:37:50 --> Output Class Initialized
INFO - 2021-08-26 06:37:50 --> Security Class Initialized
DEBUG - 2021-08-26 06:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:37:50 --> Input Class Initialized
INFO - 2021-08-26 06:37:50 --> Language Class Initialized
INFO - 2021-08-26 06:37:50 --> Language Class Initialized
INFO - 2021-08-26 06:37:50 --> Config Class Initialized
INFO - 2021-08-26 06:37:50 --> Loader Class Initialized
INFO - 2021-08-26 06:37:50 --> Helper loaded: url_helper
INFO - 2021-08-26 06:37:50 --> Helper loaded: file_helper
INFO - 2021-08-26 06:37:50 --> Helper loaded: form_helper
INFO - 2021-08-26 06:37:50 --> Helper loaded: my_helper
INFO - 2021-08-26 06:37:50 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:37:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:37:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:37:50 --> Controller Class Initialized
DEBUG - 2021-08-26 06:37:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-26 06:37:50 --> Final output sent to browser
DEBUG - 2021-08-26 06:37:50 --> Total execution time: 0.1407
INFO - 2021-08-26 06:37:53 --> Config Class Initialized
INFO - 2021-08-26 06:37:53 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:37:53 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:37:53 --> Utf8 Class Initialized
INFO - 2021-08-26 06:37:53 --> URI Class Initialized
INFO - 2021-08-26 06:37:53 --> Router Class Initialized
INFO - 2021-08-26 06:37:53 --> Output Class Initialized
INFO - 2021-08-26 06:37:53 --> Security Class Initialized
DEBUG - 2021-08-26 06:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:37:53 --> Input Class Initialized
INFO - 2021-08-26 06:37:53 --> Language Class Initialized
INFO - 2021-08-26 06:37:53 --> Language Class Initialized
INFO - 2021-08-26 06:37:53 --> Config Class Initialized
INFO - 2021-08-26 06:37:53 --> Loader Class Initialized
INFO - 2021-08-26 06:37:53 --> Helper loaded: url_helper
INFO - 2021-08-26 06:37:53 --> Helper loaded: file_helper
INFO - 2021-08-26 06:37:53 --> Helper loaded: form_helper
INFO - 2021-08-26 06:37:53 --> Helper loaded: my_helper
INFO - 2021-08-26 06:37:53 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:37:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:37:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:37:53 --> Controller Class Initialized
DEBUG - 2021-08-26 06:37:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-26 06:37:53 --> Final output sent to browser
DEBUG - 2021-08-26 06:37:53 --> Total execution time: 0.1432
INFO - 2021-08-26 06:37:54 --> Config Class Initialized
INFO - 2021-08-26 06:37:54 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:37:54 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:37:54 --> Utf8 Class Initialized
INFO - 2021-08-26 06:37:54 --> URI Class Initialized
INFO - 2021-08-26 06:37:54 --> Router Class Initialized
INFO - 2021-08-26 06:37:54 --> Output Class Initialized
INFO - 2021-08-26 06:37:55 --> Security Class Initialized
DEBUG - 2021-08-26 06:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:37:55 --> Input Class Initialized
INFO - 2021-08-26 06:37:55 --> Language Class Initialized
INFO - 2021-08-26 06:37:55 --> Language Class Initialized
INFO - 2021-08-26 06:37:55 --> Config Class Initialized
INFO - 2021-08-26 06:37:55 --> Loader Class Initialized
INFO - 2021-08-26 06:37:55 --> Helper loaded: url_helper
INFO - 2021-08-26 06:37:55 --> Helper loaded: file_helper
INFO - 2021-08-26 06:37:55 --> Helper loaded: form_helper
INFO - 2021-08-26 06:37:55 --> Helper loaded: my_helper
INFO - 2021-08-26 06:37:55 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:37:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:37:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:37:55 --> Controller Class Initialized
DEBUG - 2021-08-26 06:37:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-26 06:37:55 --> Final output sent to browser
DEBUG - 2021-08-26 06:37:55 --> Total execution time: 0.1468
INFO - 2021-08-26 06:37:56 --> Config Class Initialized
INFO - 2021-08-26 06:37:56 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:37:56 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:37:56 --> Utf8 Class Initialized
INFO - 2021-08-26 06:37:56 --> URI Class Initialized
INFO - 2021-08-26 06:37:56 --> Router Class Initialized
INFO - 2021-08-26 06:37:56 --> Output Class Initialized
INFO - 2021-08-26 06:37:56 --> Security Class Initialized
DEBUG - 2021-08-26 06:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:37:56 --> Input Class Initialized
INFO - 2021-08-26 06:37:56 --> Language Class Initialized
INFO - 2021-08-26 06:37:56 --> Language Class Initialized
INFO - 2021-08-26 06:37:56 --> Config Class Initialized
INFO - 2021-08-26 06:37:56 --> Loader Class Initialized
INFO - 2021-08-26 06:37:56 --> Helper loaded: url_helper
INFO - 2021-08-26 06:37:56 --> Helper loaded: file_helper
INFO - 2021-08-26 06:37:56 --> Helper loaded: form_helper
INFO - 2021-08-26 06:37:56 --> Helper loaded: my_helper
INFO - 2021-08-26 06:37:56 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:37:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:37:57 --> Controller Class Initialized
DEBUG - 2021-08-26 06:37:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-26 06:37:57 --> Final output sent to browser
DEBUG - 2021-08-26 06:37:57 --> Total execution time: 0.1497
INFO - 2021-08-26 06:37:58 --> Config Class Initialized
INFO - 2021-08-26 06:37:58 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:37:58 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:37:58 --> Utf8 Class Initialized
INFO - 2021-08-26 06:37:58 --> URI Class Initialized
INFO - 2021-08-26 06:37:58 --> Router Class Initialized
INFO - 2021-08-26 06:37:58 --> Output Class Initialized
INFO - 2021-08-26 06:37:58 --> Security Class Initialized
DEBUG - 2021-08-26 06:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:37:58 --> Input Class Initialized
INFO - 2021-08-26 06:37:58 --> Language Class Initialized
INFO - 2021-08-26 06:37:58 --> Language Class Initialized
INFO - 2021-08-26 06:37:58 --> Config Class Initialized
INFO - 2021-08-26 06:37:58 --> Loader Class Initialized
INFO - 2021-08-26 06:37:58 --> Helper loaded: url_helper
INFO - 2021-08-26 06:37:58 --> Helper loaded: file_helper
INFO - 2021-08-26 06:37:58 --> Helper loaded: form_helper
INFO - 2021-08-26 06:37:58 --> Helper loaded: my_helper
INFO - 2021-08-26 06:37:58 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:37:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:37:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:37:58 --> Controller Class Initialized
DEBUG - 2021-08-26 06:37:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-26 06:37:58 --> Final output sent to browser
DEBUG - 2021-08-26 06:37:58 --> Total execution time: 0.1453
INFO - 2021-08-26 06:38:02 --> Config Class Initialized
INFO - 2021-08-26 06:38:02 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:38:02 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:38:02 --> Utf8 Class Initialized
INFO - 2021-08-26 06:38:02 --> URI Class Initialized
INFO - 2021-08-26 06:38:02 --> Router Class Initialized
INFO - 2021-08-26 06:38:02 --> Output Class Initialized
INFO - 2021-08-26 06:38:02 --> Security Class Initialized
DEBUG - 2021-08-26 06:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:38:02 --> Input Class Initialized
INFO - 2021-08-26 06:38:02 --> Language Class Initialized
INFO - 2021-08-26 06:38:02 --> Language Class Initialized
INFO - 2021-08-26 06:38:02 --> Config Class Initialized
INFO - 2021-08-26 06:38:02 --> Loader Class Initialized
INFO - 2021-08-26 06:38:02 --> Helper loaded: url_helper
INFO - 2021-08-26 06:38:02 --> Helper loaded: file_helper
INFO - 2021-08-26 06:38:02 --> Helper loaded: form_helper
INFO - 2021-08-26 06:38:02 --> Helper loaded: my_helper
INFO - 2021-08-26 06:38:02 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:38:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:38:02 --> Controller Class Initialized
DEBUG - 2021-08-26 06:38:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-26 06:38:02 --> Final output sent to browser
DEBUG - 2021-08-26 06:38:02 --> Total execution time: 0.1434
INFO - 2021-08-26 06:38:03 --> Config Class Initialized
INFO - 2021-08-26 06:38:03 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:38:03 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:38:03 --> Utf8 Class Initialized
INFO - 2021-08-26 06:38:03 --> URI Class Initialized
INFO - 2021-08-26 06:38:03 --> Router Class Initialized
INFO - 2021-08-26 06:38:03 --> Output Class Initialized
INFO - 2021-08-26 06:38:03 --> Security Class Initialized
DEBUG - 2021-08-26 06:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:38:03 --> Input Class Initialized
INFO - 2021-08-26 06:38:03 --> Language Class Initialized
INFO - 2021-08-26 06:38:03 --> Language Class Initialized
INFO - 2021-08-26 06:38:03 --> Config Class Initialized
INFO - 2021-08-26 06:38:03 --> Loader Class Initialized
INFO - 2021-08-26 06:38:03 --> Helper loaded: url_helper
INFO - 2021-08-26 06:38:03 --> Helper loaded: file_helper
INFO - 2021-08-26 06:38:03 --> Helper loaded: form_helper
INFO - 2021-08-26 06:38:03 --> Helper loaded: my_helper
INFO - 2021-08-26 06:38:03 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:38:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:38:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:38:03 --> Controller Class Initialized
DEBUG - 2021-08-26 06:38:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-26 06:38:03 --> Final output sent to browser
DEBUG - 2021-08-26 06:38:03 --> Total execution time: 0.1464
INFO - 2021-08-26 06:38:05 --> Config Class Initialized
INFO - 2021-08-26 06:38:05 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:38:05 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:38:05 --> Utf8 Class Initialized
INFO - 2021-08-26 06:38:05 --> URI Class Initialized
INFO - 2021-08-26 06:38:05 --> Router Class Initialized
INFO - 2021-08-26 06:38:05 --> Output Class Initialized
INFO - 2021-08-26 06:38:05 --> Security Class Initialized
DEBUG - 2021-08-26 06:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:38:05 --> Input Class Initialized
INFO - 2021-08-26 06:38:05 --> Language Class Initialized
INFO - 2021-08-26 06:38:05 --> Language Class Initialized
INFO - 2021-08-26 06:38:05 --> Config Class Initialized
INFO - 2021-08-26 06:38:05 --> Loader Class Initialized
INFO - 2021-08-26 06:38:05 --> Helper loaded: url_helper
INFO - 2021-08-26 06:38:05 --> Helper loaded: file_helper
INFO - 2021-08-26 06:38:05 --> Helper loaded: form_helper
INFO - 2021-08-26 06:38:05 --> Helper loaded: my_helper
INFO - 2021-08-26 06:38:05 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:38:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:38:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:38:05 --> Controller Class Initialized
DEBUG - 2021-08-26 06:38:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-26 06:38:05 --> Final output sent to browser
DEBUG - 2021-08-26 06:38:05 --> Total execution time: 0.1439
INFO - 2021-08-26 06:38:07 --> Config Class Initialized
INFO - 2021-08-26 06:38:07 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:38:07 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:38:07 --> Utf8 Class Initialized
INFO - 2021-08-26 06:38:07 --> URI Class Initialized
INFO - 2021-08-26 06:38:07 --> Router Class Initialized
INFO - 2021-08-26 06:38:07 --> Output Class Initialized
INFO - 2021-08-26 06:38:07 --> Security Class Initialized
DEBUG - 2021-08-26 06:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:38:07 --> Input Class Initialized
INFO - 2021-08-26 06:38:07 --> Language Class Initialized
INFO - 2021-08-26 06:38:07 --> Language Class Initialized
INFO - 2021-08-26 06:38:07 --> Config Class Initialized
INFO - 2021-08-26 06:38:07 --> Loader Class Initialized
INFO - 2021-08-26 06:38:07 --> Helper loaded: url_helper
INFO - 2021-08-26 06:38:07 --> Helper loaded: file_helper
INFO - 2021-08-26 06:38:07 --> Helper loaded: form_helper
INFO - 2021-08-26 06:38:07 --> Helper loaded: my_helper
INFO - 2021-08-26 06:38:07 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:38:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:38:07 --> Controller Class Initialized
DEBUG - 2021-08-26 06:38:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-26 06:38:07 --> Final output sent to browser
DEBUG - 2021-08-26 06:38:07 --> Total execution time: 0.1475
INFO - 2021-08-26 06:38:09 --> Config Class Initialized
INFO - 2021-08-26 06:38:09 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:38:09 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:38:09 --> Utf8 Class Initialized
INFO - 2021-08-26 06:38:09 --> URI Class Initialized
INFO - 2021-08-26 06:38:09 --> Router Class Initialized
INFO - 2021-08-26 06:38:09 --> Output Class Initialized
INFO - 2021-08-26 06:38:09 --> Security Class Initialized
DEBUG - 2021-08-26 06:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:38:09 --> Input Class Initialized
INFO - 2021-08-26 06:38:09 --> Language Class Initialized
INFO - 2021-08-26 06:38:09 --> Language Class Initialized
INFO - 2021-08-26 06:38:09 --> Config Class Initialized
INFO - 2021-08-26 06:38:09 --> Loader Class Initialized
INFO - 2021-08-26 06:38:09 --> Helper loaded: url_helper
INFO - 2021-08-26 06:38:09 --> Helper loaded: file_helper
INFO - 2021-08-26 06:38:09 --> Helper loaded: form_helper
INFO - 2021-08-26 06:38:09 --> Helper loaded: my_helper
INFO - 2021-08-26 06:38:09 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:38:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:38:09 --> Controller Class Initialized
DEBUG - 2021-08-26 06:38:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-26 06:38:09 --> Final output sent to browser
DEBUG - 2021-08-26 06:38:09 --> Total execution time: 0.1429
INFO - 2021-08-26 06:38:13 --> Config Class Initialized
INFO - 2021-08-26 06:38:13 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:38:13 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:38:13 --> Utf8 Class Initialized
INFO - 2021-08-26 06:38:13 --> URI Class Initialized
INFO - 2021-08-26 06:38:13 --> Router Class Initialized
INFO - 2021-08-26 06:38:13 --> Output Class Initialized
INFO - 2021-08-26 06:38:13 --> Security Class Initialized
DEBUG - 2021-08-26 06:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:38:13 --> Input Class Initialized
INFO - 2021-08-26 06:38:13 --> Language Class Initialized
INFO - 2021-08-26 06:38:13 --> Language Class Initialized
INFO - 2021-08-26 06:38:13 --> Config Class Initialized
INFO - 2021-08-26 06:38:13 --> Loader Class Initialized
INFO - 2021-08-26 06:38:13 --> Helper loaded: url_helper
INFO - 2021-08-26 06:38:13 --> Helper loaded: file_helper
INFO - 2021-08-26 06:38:13 --> Helper loaded: form_helper
INFO - 2021-08-26 06:38:13 --> Helper loaded: my_helper
INFO - 2021-08-26 06:38:13 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:38:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:38:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:38:13 --> Controller Class Initialized
DEBUG - 2021-08-26 06:38:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-26 06:38:13 --> Final output sent to browser
DEBUG - 2021-08-26 06:38:13 --> Total execution time: 0.1467
INFO - 2021-08-26 06:38:15 --> Config Class Initialized
INFO - 2021-08-26 06:38:15 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:38:15 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:38:15 --> Utf8 Class Initialized
INFO - 2021-08-26 06:38:15 --> URI Class Initialized
INFO - 2021-08-26 06:38:15 --> Router Class Initialized
INFO - 2021-08-26 06:38:15 --> Output Class Initialized
INFO - 2021-08-26 06:38:15 --> Security Class Initialized
DEBUG - 2021-08-26 06:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:38:15 --> Input Class Initialized
INFO - 2021-08-26 06:38:15 --> Language Class Initialized
INFO - 2021-08-26 06:38:15 --> Language Class Initialized
INFO - 2021-08-26 06:38:15 --> Config Class Initialized
INFO - 2021-08-26 06:38:15 --> Loader Class Initialized
INFO - 2021-08-26 06:38:15 --> Helper loaded: url_helper
INFO - 2021-08-26 06:38:15 --> Helper loaded: file_helper
INFO - 2021-08-26 06:38:15 --> Helper loaded: form_helper
INFO - 2021-08-26 06:38:15 --> Helper loaded: my_helper
INFO - 2021-08-26 06:38:15 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:38:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:38:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:38:15 --> Controller Class Initialized
DEBUG - 2021-08-26 06:38:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-26 06:38:15 --> Final output sent to browser
DEBUG - 2021-08-26 06:38:15 --> Total execution time: 0.1415
INFO - 2021-08-26 06:38:17 --> Config Class Initialized
INFO - 2021-08-26 06:38:17 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:38:17 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:38:17 --> Utf8 Class Initialized
INFO - 2021-08-26 06:38:17 --> URI Class Initialized
INFO - 2021-08-26 06:38:17 --> Router Class Initialized
INFO - 2021-08-26 06:38:17 --> Output Class Initialized
INFO - 2021-08-26 06:38:17 --> Security Class Initialized
DEBUG - 2021-08-26 06:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:38:17 --> Input Class Initialized
INFO - 2021-08-26 06:38:17 --> Language Class Initialized
INFO - 2021-08-26 06:38:17 --> Language Class Initialized
INFO - 2021-08-26 06:38:17 --> Config Class Initialized
INFO - 2021-08-26 06:38:17 --> Loader Class Initialized
INFO - 2021-08-26 06:38:17 --> Helper loaded: url_helper
INFO - 2021-08-26 06:38:17 --> Helper loaded: file_helper
INFO - 2021-08-26 06:38:17 --> Helper loaded: form_helper
INFO - 2021-08-26 06:38:17 --> Helper loaded: my_helper
INFO - 2021-08-26 06:38:17 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:38:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:38:17 --> Controller Class Initialized
DEBUG - 2021-08-26 06:38:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-26 06:38:17 --> Final output sent to browser
DEBUG - 2021-08-26 06:38:17 --> Total execution time: 0.1454
INFO - 2021-08-26 06:38:19 --> Config Class Initialized
INFO - 2021-08-26 06:38:19 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:38:19 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:38:19 --> Utf8 Class Initialized
INFO - 2021-08-26 06:38:19 --> URI Class Initialized
INFO - 2021-08-26 06:38:19 --> Router Class Initialized
INFO - 2021-08-26 06:38:19 --> Output Class Initialized
INFO - 2021-08-26 06:38:19 --> Security Class Initialized
DEBUG - 2021-08-26 06:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:38:19 --> Input Class Initialized
INFO - 2021-08-26 06:38:19 --> Language Class Initialized
INFO - 2021-08-26 06:38:19 --> Language Class Initialized
INFO - 2021-08-26 06:38:19 --> Config Class Initialized
INFO - 2021-08-26 06:38:19 --> Loader Class Initialized
INFO - 2021-08-26 06:38:19 --> Helper loaded: url_helper
INFO - 2021-08-26 06:38:19 --> Helper loaded: file_helper
INFO - 2021-08-26 06:38:19 --> Helper loaded: form_helper
INFO - 2021-08-26 06:38:19 --> Helper loaded: my_helper
INFO - 2021-08-26 06:38:19 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:38:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:38:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:38:19 --> Controller Class Initialized
DEBUG - 2021-08-26 06:38:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-26 06:38:19 --> Final output sent to browser
DEBUG - 2021-08-26 06:38:19 --> Total execution time: 0.1449
INFO - 2021-08-26 06:38:20 --> Config Class Initialized
INFO - 2021-08-26 06:38:20 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:38:20 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:38:20 --> Utf8 Class Initialized
INFO - 2021-08-26 06:38:20 --> URI Class Initialized
INFO - 2021-08-26 06:38:20 --> Router Class Initialized
INFO - 2021-08-26 06:38:20 --> Output Class Initialized
INFO - 2021-08-26 06:38:20 --> Security Class Initialized
DEBUG - 2021-08-26 06:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:38:20 --> Input Class Initialized
INFO - 2021-08-26 06:38:20 --> Language Class Initialized
INFO - 2021-08-26 06:38:20 --> Language Class Initialized
INFO - 2021-08-26 06:38:20 --> Config Class Initialized
INFO - 2021-08-26 06:38:20 --> Loader Class Initialized
INFO - 2021-08-26 06:38:20 --> Helper loaded: url_helper
INFO - 2021-08-26 06:38:20 --> Helper loaded: file_helper
INFO - 2021-08-26 06:38:20 --> Helper loaded: form_helper
INFO - 2021-08-26 06:38:20 --> Helper loaded: my_helper
INFO - 2021-08-26 06:38:20 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:38:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:38:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:38:20 --> Controller Class Initialized
DEBUG - 2021-08-26 06:38:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-26 06:38:21 --> Final output sent to browser
DEBUG - 2021-08-26 06:38:21 --> Total execution time: 0.1473
INFO - 2021-08-26 06:38:24 --> Config Class Initialized
INFO - 2021-08-26 06:38:24 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:38:24 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:38:24 --> Utf8 Class Initialized
INFO - 2021-08-26 06:38:24 --> URI Class Initialized
INFO - 2021-08-26 06:38:24 --> Router Class Initialized
INFO - 2021-08-26 06:38:24 --> Output Class Initialized
INFO - 2021-08-26 06:38:24 --> Security Class Initialized
DEBUG - 2021-08-26 06:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:38:24 --> Input Class Initialized
INFO - 2021-08-26 06:38:24 --> Language Class Initialized
INFO - 2021-08-26 06:38:24 --> Language Class Initialized
INFO - 2021-08-26 06:38:24 --> Config Class Initialized
INFO - 2021-08-26 06:38:24 --> Loader Class Initialized
INFO - 2021-08-26 06:38:24 --> Helper loaded: url_helper
INFO - 2021-08-26 06:38:24 --> Helper loaded: file_helper
INFO - 2021-08-26 06:38:24 --> Helper loaded: form_helper
INFO - 2021-08-26 06:38:24 --> Helper loaded: my_helper
INFO - 2021-08-26 06:38:24 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:38:24 --> Controller Class Initialized
DEBUG - 2021-08-26 06:38:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-26 06:38:24 --> Final output sent to browser
DEBUG - 2021-08-26 06:38:24 --> Total execution time: 0.1731
INFO - 2021-08-26 06:38:25 --> Config Class Initialized
INFO - 2021-08-26 06:38:25 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:38:25 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:38:25 --> Utf8 Class Initialized
INFO - 2021-08-26 06:38:25 --> URI Class Initialized
INFO - 2021-08-26 06:38:25 --> Router Class Initialized
INFO - 2021-08-26 06:38:25 --> Output Class Initialized
INFO - 2021-08-26 06:38:25 --> Security Class Initialized
DEBUG - 2021-08-26 06:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:38:25 --> Input Class Initialized
INFO - 2021-08-26 06:38:25 --> Language Class Initialized
INFO - 2021-08-26 06:38:25 --> Language Class Initialized
INFO - 2021-08-26 06:38:25 --> Config Class Initialized
INFO - 2021-08-26 06:38:25 --> Loader Class Initialized
INFO - 2021-08-26 06:38:25 --> Helper loaded: url_helper
INFO - 2021-08-26 06:38:25 --> Helper loaded: file_helper
INFO - 2021-08-26 06:38:25 --> Helper loaded: form_helper
INFO - 2021-08-26 06:38:25 --> Helper loaded: my_helper
INFO - 2021-08-26 06:38:25 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:38:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:38:25 --> Controller Class Initialized
DEBUG - 2021-08-26 06:38:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-26 06:38:25 --> Final output sent to browser
DEBUG - 2021-08-26 06:38:25 --> Total execution time: 0.1424
INFO - 2021-08-26 06:38:26 --> Config Class Initialized
INFO - 2021-08-26 06:38:26 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:38:26 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:38:26 --> Utf8 Class Initialized
INFO - 2021-08-26 06:38:26 --> URI Class Initialized
INFO - 2021-08-26 06:38:26 --> Router Class Initialized
INFO - 2021-08-26 06:38:26 --> Output Class Initialized
INFO - 2021-08-26 06:38:26 --> Security Class Initialized
DEBUG - 2021-08-26 06:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:38:26 --> Input Class Initialized
INFO - 2021-08-26 06:38:26 --> Language Class Initialized
INFO - 2021-08-26 06:38:26 --> Language Class Initialized
INFO - 2021-08-26 06:38:26 --> Config Class Initialized
INFO - 2021-08-26 06:38:26 --> Loader Class Initialized
INFO - 2021-08-26 06:38:26 --> Helper loaded: url_helper
INFO - 2021-08-26 06:38:26 --> Helper loaded: file_helper
INFO - 2021-08-26 06:38:26 --> Helper loaded: form_helper
INFO - 2021-08-26 06:38:26 --> Helper loaded: my_helper
INFO - 2021-08-26 06:38:26 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:38:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:38:26 --> Controller Class Initialized
DEBUG - 2021-08-26 06:38:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-26 06:38:26 --> Final output sent to browser
DEBUG - 2021-08-26 06:38:26 --> Total execution time: 0.1508
INFO - 2021-08-26 06:38:28 --> Config Class Initialized
INFO - 2021-08-26 06:38:28 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:38:28 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:38:28 --> Utf8 Class Initialized
INFO - 2021-08-26 06:38:28 --> URI Class Initialized
INFO - 2021-08-26 06:38:28 --> Router Class Initialized
INFO - 2021-08-26 06:38:28 --> Output Class Initialized
INFO - 2021-08-26 06:38:28 --> Security Class Initialized
DEBUG - 2021-08-26 06:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:38:28 --> Input Class Initialized
INFO - 2021-08-26 06:38:28 --> Language Class Initialized
INFO - 2021-08-26 06:38:28 --> Language Class Initialized
INFO - 2021-08-26 06:38:28 --> Config Class Initialized
INFO - 2021-08-26 06:38:28 --> Loader Class Initialized
INFO - 2021-08-26 06:38:28 --> Helper loaded: url_helper
INFO - 2021-08-26 06:38:28 --> Helper loaded: file_helper
INFO - 2021-08-26 06:38:28 --> Helper loaded: form_helper
INFO - 2021-08-26 06:38:28 --> Helper loaded: my_helper
INFO - 2021-08-26 06:38:28 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:38:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:38:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:38:28 --> Controller Class Initialized
DEBUG - 2021-08-26 06:38:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-26 06:38:28 --> Final output sent to browser
DEBUG - 2021-08-26 06:38:28 --> Total execution time: 0.1479
INFO - 2021-08-26 06:38:30 --> Config Class Initialized
INFO - 2021-08-26 06:38:30 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:38:30 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:38:30 --> Utf8 Class Initialized
INFO - 2021-08-26 06:38:30 --> URI Class Initialized
INFO - 2021-08-26 06:38:30 --> Router Class Initialized
INFO - 2021-08-26 06:38:30 --> Output Class Initialized
INFO - 2021-08-26 06:38:30 --> Security Class Initialized
DEBUG - 2021-08-26 06:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:38:30 --> Input Class Initialized
INFO - 2021-08-26 06:38:30 --> Language Class Initialized
INFO - 2021-08-26 06:38:30 --> Language Class Initialized
INFO - 2021-08-26 06:38:30 --> Config Class Initialized
INFO - 2021-08-26 06:38:30 --> Loader Class Initialized
INFO - 2021-08-26 06:38:30 --> Helper loaded: url_helper
INFO - 2021-08-26 06:38:30 --> Helper loaded: file_helper
INFO - 2021-08-26 06:38:30 --> Helper loaded: form_helper
INFO - 2021-08-26 06:38:30 --> Helper loaded: my_helper
INFO - 2021-08-26 06:38:30 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:38:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:38:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:38:30 --> Controller Class Initialized
DEBUG - 2021-08-26 06:38:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-26 06:38:30 --> Final output sent to browser
DEBUG - 2021-08-26 06:38:30 --> Total execution time: 0.1501
INFO - 2021-08-26 06:38:33 --> Config Class Initialized
INFO - 2021-08-26 06:38:33 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:38:33 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:38:33 --> Utf8 Class Initialized
INFO - 2021-08-26 06:38:33 --> URI Class Initialized
INFO - 2021-08-26 06:38:33 --> Router Class Initialized
INFO - 2021-08-26 06:38:33 --> Output Class Initialized
INFO - 2021-08-26 06:38:33 --> Security Class Initialized
DEBUG - 2021-08-26 06:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:38:33 --> Input Class Initialized
INFO - 2021-08-26 06:38:33 --> Language Class Initialized
INFO - 2021-08-26 06:38:33 --> Language Class Initialized
INFO - 2021-08-26 06:38:33 --> Config Class Initialized
INFO - 2021-08-26 06:38:33 --> Loader Class Initialized
INFO - 2021-08-26 06:38:33 --> Helper loaded: url_helper
INFO - 2021-08-26 06:38:33 --> Helper loaded: file_helper
INFO - 2021-08-26 06:38:33 --> Helper loaded: form_helper
INFO - 2021-08-26 06:38:33 --> Helper loaded: my_helper
INFO - 2021-08-26 06:38:33 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:38:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:38:33 --> Controller Class Initialized
DEBUG - 2021-08-26 06:38:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-26 06:38:33 --> Final output sent to browser
DEBUG - 2021-08-26 06:38:33 --> Total execution time: 0.1438
INFO - 2021-08-26 06:38:35 --> Config Class Initialized
INFO - 2021-08-26 06:38:35 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:38:35 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:38:35 --> Utf8 Class Initialized
INFO - 2021-08-26 06:38:35 --> URI Class Initialized
INFO - 2021-08-26 06:38:35 --> Router Class Initialized
INFO - 2021-08-26 06:38:35 --> Output Class Initialized
INFO - 2021-08-26 06:38:35 --> Security Class Initialized
DEBUG - 2021-08-26 06:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:38:35 --> Input Class Initialized
INFO - 2021-08-26 06:38:35 --> Language Class Initialized
INFO - 2021-08-26 06:38:35 --> Language Class Initialized
INFO - 2021-08-26 06:38:35 --> Config Class Initialized
INFO - 2021-08-26 06:38:35 --> Loader Class Initialized
INFO - 2021-08-26 06:38:35 --> Helper loaded: url_helper
INFO - 2021-08-26 06:38:35 --> Helper loaded: file_helper
INFO - 2021-08-26 06:38:35 --> Helper loaded: form_helper
INFO - 2021-08-26 06:38:35 --> Helper loaded: my_helper
INFO - 2021-08-26 06:38:35 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:38:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:38:35 --> Controller Class Initialized
DEBUG - 2021-08-26 06:38:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-26 06:38:35 --> Final output sent to browser
DEBUG - 2021-08-26 06:38:35 --> Total execution time: 0.1471
INFO - 2021-08-26 06:38:37 --> Config Class Initialized
INFO - 2021-08-26 06:38:37 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:38:37 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:38:37 --> Utf8 Class Initialized
INFO - 2021-08-26 06:38:37 --> URI Class Initialized
INFO - 2021-08-26 06:38:37 --> Router Class Initialized
INFO - 2021-08-26 06:38:37 --> Output Class Initialized
INFO - 2021-08-26 06:38:37 --> Security Class Initialized
DEBUG - 2021-08-26 06:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:38:37 --> Input Class Initialized
INFO - 2021-08-26 06:38:37 --> Language Class Initialized
INFO - 2021-08-26 06:38:37 --> Language Class Initialized
INFO - 2021-08-26 06:38:37 --> Config Class Initialized
INFO - 2021-08-26 06:38:37 --> Loader Class Initialized
INFO - 2021-08-26 06:38:37 --> Helper loaded: url_helper
INFO - 2021-08-26 06:38:37 --> Helper loaded: file_helper
INFO - 2021-08-26 06:38:37 --> Helper loaded: form_helper
INFO - 2021-08-26 06:38:37 --> Helper loaded: my_helper
INFO - 2021-08-26 06:38:37 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:38:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:38:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:38:37 --> Controller Class Initialized
DEBUG - 2021-08-26 06:38:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-26 06:38:37 --> Final output sent to browser
DEBUG - 2021-08-26 06:38:37 --> Total execution time: 0.1450
INFO - 2021-08-26 06:38:39 --> Config Class Initialized
INFO - 2021-08-26 06:38:39 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:38:39 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:38:39 --> Utf8 Class Initialized
INFO - 2021-08-26 06:38:39 --> URI Class Initialized
INFO - 2021-08-26 06:38:39 --> Router Class Initialized
INFO - 2021-08-26 06:38:39 --> Output Class Initialized
INFO - 2021-08-26 06:38:39 --> Security Class Initialized
DEBUG - 2021-08-26 06:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:38:39 --> Input Class Initialized
INFO - 2021-08-26 06:38:39 --> Language Class Initialized
INFO - 2021-08-26 06:38:39 --> Language Class Initialized
INFO - 2021-08-26 06:38:39 --> Config Class Initialized
INFO - 2021-08-26 06:38:39 --> Loader Class Initialized
INFO - 2021-08-26 06:38:39 --> Helper loaded: url_helper
INFO - 2021-08-26 06:38:39 --> Helper loaded: file_helper
INFO - 2021-08-26 06:38:39 --> Helper loaded: form_helper
INFO - 2021-08-26 06:38:39 --> Helper loaded: my_helper
INFO - 2021-08-26 06:38:39 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:38:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:38:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:38:39 --> Controller Class Initialized
DEBUG - 2021-08-26 06:38:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-26 06:38:39 --> Final output sent to browser
DEBUG - 2021-08-26 06:38:39 --> Total execution time: 0.1457
INFO - 2021-08-26 06:38:41 --> Config Class Initialized
INFO - 2021-08-26 06:38:41 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:38:41 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:38:41 --> Utf8 Class Initialized
INFO - 2021-08-26 06:38:41 --> URI Class Initialized
INFO - 2021-08-26 06:38:41 --> Router Class Initialized
INFO - 2021-08-26 06:38:41 --> Output Class Initialized
INFO - 2021-08-26 06:38:41 --> Security Class Initialized
DEBUG - 2021-08-26 06:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:38:41 --> Input Class Initialized
INFO - 2021-08-26 06:38:41 --> Language Class Initialized
INFO - 2021-08-26 06:38:41 --> Language Class Initialized
INFO - 2021-08-26 06:38:41 --> Config Class Initialized
INFO - 2021-08-26 06:38:41 --> Loader Class Initialized
INFO - 2021-08-26 06:38:41 --> Helper loaded: url_helper
INFO - 2021-08-26 06:38:41 --> Helper loaded: file_helper
INFO - 2021-08-26 06:38:41 --> Helper loaded: form_helper
INFO - 2021-08-26 06:38:41 --> Helper loaded: my_helper
INFO - 2021-08-26 06:38:41 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:38:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:38:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:38:41 --> Controller Class Initialized
DEBUG - 2021-08-26 06:38:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-26 06:38:41 --> Final output sent to browser
DEBUG - 2021-08-26 06:38:41 --> Total execution time: 0.1457
INFO - 2021-08-26 06:51:40 --> Config Class Initialized
INFO - 2021-08-26 06:51:40 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:51:40 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:51:40 --> Utf8 Class Initialized
INFO - 2021-08-26 06:51:40 --> URI Class Initialized
INFO - 2021-08-26 06:51:40 --> Router Class Initialized
INFO - 2021-08-26 06:51:40 --> Output Class Initialized
INFO - 2021-08-26 06:51:40 --> Security Class Initialized
DEBUG - 2021-08-26 06:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:51:40 --> Input Class Initialized
INFO - 2021-08-26 06:51:40 --> Language Class Initialized
INFO - 2021-08-26 06:51:40 --> Language Class Initialized
INFO - 2021-08-26 06:51:40 --> Config Class Initialized
INFO - 2021-08-26 06:51:40 --> Loader Class Initialized
INFO - 2021-08-26 06:51:40 --> Helper loaded: url_helper
INFO - 2021-08-26 06:51:40 --> Helper loaded: file_helper
INFO - 2021-08-26 06:51:40 --> Helper loaded: form_helper
INFO - 2021-08-26 06:51:40 --> Helper loaded: my_helper
INFO - 2021-08-26 06:51:40 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:51:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:51:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:51:40 --> Controller Class Initialized
DEBUG - 2021-08-26 06:51:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-08-26 06:51:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-26 06:51:40 --> Final output sent to browser
DEBUG - 2021-08-26 06:51:40 --> Total execution time: 0.0592
INFO - 2021-08-26 06:51:43 --> Config Class Initialized
INFO - 2021-08-26 06:51:43 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:51:43 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:51:43 --> Utf8 Class Initialized
INFO - 2021-08-26 06:51:43 --> URI Class Initialized
INFO - 2021-08-26 06:51:43 --> Router Class Initialized
INFO - 2021-08-26 06:51:43 --> Output Class Initialized
INFO - 2021-08-26 06:51:43 --> Security Class Initialized
DEBUG - 2021-08-26 06:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:51:43 --> Input Class Initialized
INFO - 2021-08-26 06:51:43 --> Language Class Initialized
INFO - 2021-08-26 06:51:43 --> Language Class Initialized
INFO - 2021-08-26 06:51:43 --> Config Class Initialized
INFO - 2021-08-26 06:51:43 --> Loader Class Initialized
INFO - 2021-08-26 06:51:43 --> Helper loaded: url_helper
INFO - 2021-08-26 06:51:43 --> Helper loaded: file_helper
INFO - 2021-08-26 06:51:43 --> Helper loaded: form_helper
INFO - 2021-08-26 06:51:43 --> Helper loaded: my_helper
INFO - 2021-08-26 06:51:43 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:51:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:51:43 --> Controller Class Initialized
INFO - 2021-08-26 06:51:43 --> Helper loaded: cookie_helper
INFO - 2021-08-26 06:51:43 --> Config Class Initialized
INFO - 2021-08-26 06:51:43 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:51:43 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:51:43 --> Utf8 Class Initialized
INFO - 2021-08-26 06:51:43 --> URI Class Initialized
INFO - 2021-08-26 06:51:43 --> Router Class Initialized
INFO - 2021-08-26 06:51:43 --> Output Class Initialized
INFO - 2021-08-26 06:51:43 --> Security Class Initialized
DEBUG - 2021-08-26 06:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:51:43 --> Input Class Initialized
INFO - 2021-08-26 06:51:43 --> Language Class Initialized
INFO - 2021-08-26 06:51:43 --> Language Class Initialized
INFO - 2021-08-26 06:51:43 --> Config Class Initialized
INFO - 2021-08-26 06:51:43 --> Loader Class Initialized
INFO - 2021-08-26 06:51:43 --> Helper loaded: url_helper
INFO - 2021-08-26 06:51:43 --> Helper loaded: file_helper
INFO - 2021-08-26 06:51:43 --> Helper loaded: form_helper
INFO - 2021-08-26 06:51:43 --> Helper loaded: my_helper
INFO - 2021-08-26 06:51:43 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:51:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:51:43 --> Controller Class Initialized
DEBUG - 2021-08-26 06:51:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-08-26 06:51:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-26 06:51:43 --> Final output sent to browser
DEBUG - 2021-08-26 06:51:43 --> Total execution time: 0.0665
INFO - 2021-08-26 06:51:57 --> Config Class Initialized
INFO - 2021-08-26 06:51:57 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:51:57 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:51:57 --> Utf8 Class Initialized
INFO - 2021-08-26 06:51:57 --> URI Class Initialized
INFO - 2021-08-26 06:51:57 --> Router Class Initialized
INFO - 2021-08-26 06:51:57 --> Output Class Initialized
INFO - 2021-08-26 06:51:57 --> Security Class Initialized
DEBUG - 2021-08-26 06:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:51:57 --> Input Class Initialized
INFO - 2021-08-26 06:51:57 --> Language Class Initialized
INFO - 2021-08-26 06:51:57 --> Language Class Initialized
INFO - 2021-08-26 06:51:57 --> Config Class Initialized
INFO - 2021-08-26 06:51:57 --> Loader Class Initialized
INFO - 2021-08-26 06:51:57 --> Helper loaded: url_helper
INFO - 2021-08-26 06:51:57 --> Helper loaded: file_helper
INFO - 2021-08-26 06:51:57 --> Helper loaded: form_helper
INFO - 2021-08-26 06:51:57 --> Helper loaded: my_helper
INFO - 2021-08-26 06:51:57 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:51:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:51:57 --> Controller Class Initialized
INFO - 2021-08-26 06:51:57 --> Helper loaded: cookie_helper
INFO - 2021-08-26 06:51:57 --> Final output sent to browser
DEBUG - 2021-08-26 06:51:57 --> Total execution time: 0.0553
INFO - 2021-08-26 06:51:58 --> Config Class Initialized
INFO - 2021-08-26 06:51:58 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:51:58 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:51:58 --> Utf8 Class Initialized
INFO - 2021-08-26 06:51:58 --> URI Class Initialized
INFO - 2021-08-26 06:51:58 --> Router Class Initialized
INFO - 2021-08-26 06:51:58 --> Output Class Initialized
INFO - 2021-08-26 06:51:58 --> Security Class Initialized
DEBUG - 2021-08-26 06:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:51:58 --> Input Class Initialized
INFO - 2021-08-26 06:51:58 --> Language Class Initialized
INFO - 2021-08-26 06:51:58 --> Language Class Initialized
INFO - 2021-08-26 06:51:58 --> Config Class Initialized
INFO - 2021-08-26 06:51:58 --> Loader Class Initialized
INFO - 2021-08-26 06:51:58 --> Helper loaded: url_helper
INFO - 2021-08-26 06:51:58 --> Helper loaded: file_helper
INFO - 2021-08-26 06:51:58 --> Helper loaded: form_helper
INFO - 2021-08-26 06:51:58 --> Helper loaded: my_helper
INFO - 2021-08-26 06:51:58 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:51:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:51:58 --> Controller Class Initialized
DEBUG - 2021-08-26 06:51:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-08-26 06:51:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-26 06:51:58 --> Final output sent to browser
DEBUG - 2021-08-26 06:51:58 --> Total execution time: 0.7252
INFO - 2021-08-26 06:52:02 --> Config Class Initialized
INFO - 2021-08-26 06:52:02 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:52:02 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:52:02 --> Utf8 Class Initialized
INFO - 2021-08-26 06:52:02 --> URI Class Initialized
INFO - 2021-08-26 06:52:02 --> Router Class Initialized
INFO - 2021-08-26 06:52:02 --> Output Class Initialized
INFO - 2021-08-26 06:52:02 --> Security Class Initialized
DEBUG - 2021-08-26 06:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:52:02 --> Input Class Initialized
INFO - 2021-08-26 06:52:02 --> Language Class Initialized
INFO - 2021-08-26 06:52:02 --> Language Class Initialized
INFO - 2021-08-26 06:52:02 --> Config Class Initialized
INFO - 2021-08-26 06:52:02 --> Loader Class Initialized
INFO - 2021-08-26 06:52:02 --> Helper loaded: url_helper
INFO - 2021-08-26 06:52:02 --> Helper loaded: file_helper
INFO - 2021-08-26 06:52:02 --> Helper loaded: form_helper
INFO - 2021-08-26 06:52:02 --> Helper loaded: my_helper
INFO - 2021-08-26 06:52:02 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:52:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:52:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:52:02 --> Controller Class Initialized
DEBUG - 2021-08-26 06:52:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-08-26 06:52:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-26 06:52:02 --> Final output sent to browser
DEBUG - 2021-08-26 06:52:02 --> Total execution time: 0.0749
INFO - 2021-08-26 06:52:21 --> Config Class Initialized
INFO - 2021-08-26 06:52:21 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:52:21 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:52:21 --> Utf8 Class Initialized
INFO - 2021-08-26 06:52:21 --> URI Class Initialized
INFO - 2021-08-26 06:52:21 --> Router Class Initialized
INFO - 2021-08-26 06:52:21 --> Output Class Initialized
INFO - 2021-08-26 06:52:21 --> Security Class Initialized
DEBUG - 2021-08-26 06:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:52:21 --> Input Class Initialized
INFO - 2021-08-26 06:52:21 --> Language Class Initialized
INFO - 2021-08-26 06:52:21 --> Language Class Initialized
INFO - 2021-08-26 06:52:21 --> Config Class Initialized
INFO - 2021-08-26 06:52:21 --> Loader Class Initialized
INFO - 2021-08-26 06:52:21 --> Helper loaded: url_helper
INFO - 2021-08-26 06:52:21 --> Helper loaded: file_helper
INFO - 2021-08-26 06:52:21 --> Helper loaded: form_helper
INFO - 2021-08-26 06:52:21 --> Helper loaded: my_helper
INFO - 2021-08-26 06:52:21 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:52:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:52:21 --> Controller Class Initialized
DEBUG - 2021-08-26 06:52:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-08-26 06:52:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-26 06:52:21 --> Final output sent to browser
DEBUG - 2021-08-26 06:52:21 --> Total execution time: 0.0572
INFO - 2021-08-26 06:52:22 --> Config Class Initialized
INFO - 2021-08-26 06:52:22 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:52:22 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:52:22 --> Utf8 Class Initialized
INFO - 2021-08-26 06:52:22 --> URI Class Initialized
INFO - 2021-08-26 06:52:22 --> Router Class Initialized
INFO - 2021-08-26 06:52:22 --> Output Class Initialized
INFO - 2021-08-26 06:52:22 --> Security Class Initialized
DEBUG - 2021-08-26 06:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:52:22 --> Input Class Initialized
INFO - 2021-08-26 06:52:22 --> Language Class Initialized
INFO - 2021-08-26 06:52:22 --> Language Class Initialized
INFO - 2021-08-26 06:52:22 --> Config Class Initialized
INFO - 2021-08-26 06:52:22 --> Loader Class Initialized
INFO - 2021-08-26 06:52:22 --> Helper loaded: url_helper
INFO - 2021-08-26 06:52:22 --> Helper loaded: file_helper
INFO - 2021-08-26 06:52:22 --> Helper loaded: form_helper
INFO - 2021-08-26 06:52:22 --> Helper loaded: my_helper
INFO - 2021-08-26 06:52:22 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:52:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:52:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:52:22 --> Controller Class Initialized
DEBUG - 2021-08-26 06:52:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tki.php
INFO - 2021-08-26 06:52:23 --> Final output sent to browser
DEBUG - 2021-08-26 06:52:23 --> Total execution time: 0.2459
INFO - 2021-08-26 06:53:22 --> Config Class Initialized
INFO - 2021-08-26 06:53:22 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:53:22 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:53:22 --> Utf8 Class Initialized
INFO - 2021-08-26 06:53:22 --> URI Class Initialized
INFO - 2021-08-26 06:53:22 --> Router Class Initialized
INFO - 2021-08-26 06:53:22 --> Output Class Initialized
INFO - 2021-08-26 06:53:22 --> Security Class Initialized
DEBUG - 2021-08-26 06:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:53:22 --> Input Class Initialized
INFO - 2021-08-26 06:53:22 --> Language Class Initialized
INFO - 2021-08-26 06:53:22 --> Language Class Initialized
INFO - 2021-08-26 06:53:22 --> Config Class Initialized
INFO - 2021-08-26 06:53:22 --> Loader Class Initialized
INFO - 2021-08-26 06:53:22 --> Helper loaded: url_helper
INFO - 2021-08-26 06:53:22 --> Helper loaded: file_helper
INFO - 2021-08-26 06:53:22 --> Helper loaded: form_helper
INFO - 2021-08-26 06:53:22 --> Helper loaded: my_helper
INFO - 2021-08-26 06:53:22 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:53:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:53:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:53:22 --> Controller Class Initialized
DEBUG - 2021-08-26 06:53:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-08-26 06:53:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-26 06:53:22 --> Final output sent to browser
DEBUG - 2021-08-26 06:53:22 --> Total execution time: 0.0725
INFO - 2021-08-26 06:53:25 --> Config Class Initialized
INFO - 2021-08-26 06:53:25 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:53:25 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:53:25 --> Utf8 Class Initialized
INFO - 2021-08-26 06:53:25 --> URI Class Initialized
INFO - 2021-08-26 06:53:25 --> Router Class Initialized
INFO - 2021-08-26 06:53:25 --> Output Class Initialized
INFO - 2021-08-26 06:53:25 --> Security Class Initialized
DEBUG - 2021-08-26 06:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:53:25 --> Input Class Initialized
INFO - 2021-08-26 06:53:25 --> Language Class Initialized
INFO - 2021-08-26 06:53:25 --> Language Class Initialized
INFO - 2021-08-26 06:53:25 --> Config Class Initialized
INFO - 2021-08-26 06:53:25 --> Loader Class Initialized
INFO - 2021-08-26 06:53:25 --> Helper loaded: url_helper
INFO - 2021-08-26 06:53:25 --> Helper loaded: file_helper
INFO - 2021-08-26 06:53:25 --> Helper loaded: form_helper
INFO - 2021-08-26 06:53:25 --> Helper loaded: my_helper
INFO - 2021-08-26 06:53:25 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:53:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:53:25 --> Controller Class Initialized
DEBUG - 2021-08-26 06:53:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-26 06:53:25 --> Final output sent to browser
DEBUG - 2021-08-26 06:53:25 --> Total execution time: 0.1648
INFO - 2021-08-26 06:53:26 --> Config Class Initialized
INFO - 2021-08-26 06:53:26 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:53:26 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:53:26 --> Utf8 Class Initialized
INFO - 2021-08-26 06:53:26 --> URI Class Initialized
INFO - 2021-08-26 06:53:26 --> Router Class Initialized
INFO - 2021-08-26 06:53:26 --> Output Class Initialized
INFO - 2021-08-26 06:53:26 --> Security Class Initialized
DEBUG - 2021-08-26 06:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:53:26 --> Input Class Initialized
INFO - 2021-08-26 06:53:26 --> Language Class Initialized
INFO - 2021-08-26 06:53:26 --> Language Class Initialized
INFO - 2021-08-26 06:53:26 --> Config Class Initialized
INFO - 2021-08-26 06:53:26 --> Loader Class Initialized
INFO - 2021-08-26 06:53:26 --> Helper loaded: url_helper
INFO - 2021-08-26 06:53:26 --> Helper loaded: file_helper
INFO - 2021-08-26 06:53:26 --> Helper loaded: form_helper
INFO - 2021-08-26 06:53:26 --> Helper loaded: my_helper
INFO - 2021-08-26 06:53:26 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:53:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:53:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:53:26 --> Controller Class Initialized
DEBUG - 2021-08-26 06:53:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-26 06:53:27 --> Final output sent to browser
DEBUG - 2021-08-26 06:53:27 --> Total execution time: 0.1483
INFO - 2021-08-26 06:53:34 --> Config Class Initialized
INFO - 2021-08-26 06:53:34 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:53:34 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:53:34 --> Utf8 Class Initialized
INFO - 2021-08-26 06:53:34 --> URI Class Initialized
INFO - 2021-08-26 06:53:34 --> Router Class Initialized
INFO - 2021-08-26 06:53:34 --> Output Class Initialized
INFO - 2021-08-26 06:53:34 --> Security Class Initialized
DEBUG - 2021-08-26 06:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:53:34 --> Input Class Initialized
INFO - 2021-08-26 06:53:34 --> Language Class Initialized
INFO - 2021-08-26 06:53:34 --> Language Class Initialized
INFO - 2021-08-26 06:53:34 --> Config Class Initialized
INFO - 2021-08-26 06:53:34 --> Loader Class Initialized
INFO - 2021-08-26 06:53:34 --> Helper loaded: url_helper
INFO - 2021-08-26 06:53:34 --> Helper loaded: file_helper
INFO - 2021-08-26 06:53:34 --> Helper loaded: form_helper
INFO - 2021-08-26 06:53:34 --> Helper loaded: my_helper
INFO - 2021-08-26 06:53:34 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:53:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:53:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:53:34 --> Controller Class Initialized
DEBUG - 2021-08-26 06:53:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-26 06:53:34 --> Final output sent to browser
DEBUG - 2021-08-26 06:53:34 --> Total execution time: 0.1508
INFO - 2021-08-26 06:53:49 --> Config Class Initialized
INFO - 2021-08-26 06:53:49 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:53:49 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:53:49 --> Utf8 Class Initialized
INFO - 2021-08-26 06:53:49 --> URI Class Initialized
INFO - 2021-08-26 06:53:49 --> Router Class Initialized
INFO - 2021-08-26 06:53:49 --> Output Class Initialized
INFO - 2021-08-26 06:53:49 --> Security Class Initialized
DEBUG - 2021-08-26 06:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:53:49 --> Input Class Initialized
INFO - 2021-08-26 06:53:49 --> Language Class Initialized
INFO - 2021-08-26 06:53:49 --> Language Class Initialized
INFO - 2021-08-26 06:53:49 --> Config Class Initialized
INFO - 2021-08-26 06:53:49 --> Loader Class Initialized
INFO - 2021-08-26 06:53:49 --> Helper loaded: url_helper
INFO - 2021-08-26 06:53:49 --> Helper loaded: file_helper
INFO - 2021-08-26 06:53:49 --> Helper loaded: form_helper
INFO - 2021-08-26 06:53:49 --> Helper loaded: my_helper
INFO - 2021-08-26 06:53:49 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:53:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:53:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:53:49 --> Controller Class Initialized
DEBUG - 2021-08-26 06:53:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-26 06:53:50 --> Final output sent to browser
DEBUG - 2021-08-26 06:53:50 --> Total execution time: 0.1361
INFO - 2021-08-26 06:53:51 --> Config Class Initialized
INFO - 2021-08-26 06:53:51 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:53:51 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:53:51 --> Utf8 Class Initialized
INFO - 2021-08-26 06:53:51 --> URI Class Initialized
INFO - 2021-08-26 06:53:51 --> Router Class Initialized
INFO - 2021-08-26 06:53:51 --> Output Class Initialized
INFO - 2021-08-26 06:53:51 --> Security Class Initialized
DEBUG - 2021-08-26 06:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:53:51 --> Input Class Initialized
INFO - 2021-08-26 06:53:51 --> Language Class Initialized
INFO - 2021-08-26 06:53:51 --> Language Class Initialized
INFO - 2021-08-26 06:53:51 --> Config Class Initialized
INFO - 2021-08-26 06:53:51 --> Loader Class Initialized
INFO - 2021-08-26 06:53:51 --> Helper loaded: url_helper
INFO - 2021-08-26 06:53:51 --> Helper loaded: file_helper
INFO - 2021-08-26 06:53:51 --> Helper loaded: form_helper
INFO - 2021-08-26 06:53:51 --> Helper loaded: my_helper
INFO - 2021-08-26 06:53:51 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:53:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:53:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:53:51 --> Controller Class Initialized
DEBUG - 2021-08-26 06:53:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-26 06:53:51 --> Final output sent to browser
DEBUG - 2021-08-26 06:53:51 --> Total execution time: 0.1361
INFO - 2021-08-26 06:54:02 --> Config Class Initialized
INFO - 2021-08-26 06:54:02 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:54:02 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:54:02 --> Utf8 Class Initialized
INFO - 2021-08-26 06:54:02 --> URI Class Initialized
INFO - 2021-08-26 06:54:02 --> Router Class Initialized
INFO - 2021-08-26 06:54:02 --> Output Class Initialized
INFO - 2021-08-26 06:54:02 --> Security Class Initialized
DEBUG - 2021-08-26 06:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:54:02 --> Input Class Initialized
INFO - 2021-08-26 06:54:02 --> Language Class Initialized
INFO - 2021-08-26 06:54:02 --> Language Class Initialized
INFO - 2021-08-26 06:54:02 --> Config Class Initialized
INFO - 2021-08-26 06:54:02 --> Loader Class Initialized
INFO - 2021-08-26 06:54:02 --> Helper loaded: url_helper
INFO - 2021-08-26 06:54:02 --> Helper loaded: file_helper
INFO - 2021-08-26 06:54:02 --> Helper loaded: form_helper
INFO - 2021-08-26 06:54:02 --> Helper loaded: my_helper
INFO - 2021-08-26 06:54:02 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:54:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:54:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:54:02 --> Controller Class Initialized
DEBUG - 2021-08-26 06:54:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-26 06:54:02 --> Final output sent to browser
DEBUG - 2021-08-26 06:54:02 --> Total execution time: 0.1292
INFO - 2021-08-26 06:54:48 --> Config Class Initialized
INFO - 2021-08-26 06:54:48 --> Hooks Class Initialized
DEBUG - 2021-08-26 06:54:48 --> UTF-8 Support Enabled
INFO - 2021-08-26 06:54:48 --> Utf8 Class Initialized
INFO - 2021-08-26 06:54:48 --> URI Class Initialized
INFO - 2021-08-26 06:54:48 --> Router Class Initialized
INFO - 2021-08-26 06:54:48 --> Output Class Initialized
INFO - 2021-08-26 06:54:48 --> Security Class Initialized
DEBUG - 2021-08-26 06:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 06:54:48 --> Input Class Initialized
INFO - 2021-08-26 06:54:48 --> Language Class Initialized
INFO - 2021-08-26 06:54:48 --> Language Class Initialized
INFO - 2021-08-26 06:54:48 --> Config Class Initialized
INFO - 2021-08-26 06:54:48 --> Loader Class Initialized
INFO - 2021-08-26 06:54:48 --> Helper loaded: url_helper
INFO - 2021-08-26 06:54:48 --> Helper loaded: file_helper
INFO - 2021-08-26 06:54:48 --> Helper loaded: form_helper
INFO - 2021-08-26 06:54:48 --> Helper loaded: my_helper
INFO - 2021-08-26 06:54:48 --> Database Driver Class Initialized
DEBUG - 2021-08-26 06:54:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 06:54:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 06:54:48 --> Controller Class Initialized
DEBUG - 2021-08-26 06:54:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-26 06:54:48 --> Final output sent to browser
DEBUG - 2021-08-26 06:54:48 --> Total execution time: 0.1381
