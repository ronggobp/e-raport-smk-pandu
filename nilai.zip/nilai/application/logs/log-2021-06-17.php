<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-06-17 02:25:16 --> Config Class Initialized
INFO - 2021-06-17 02:25:16 --> Hooks Class Initialized
DEBUG - 2021-06-17 02:25:16 --> UTF-8 Support Enabled
INFO - 2021-06-17 02:25:16 --> Utf8 Class Initialized
INFO - 2021-06-17 02:25:16 --> URI Class Initialized
DEBUG - 2021-06-17 02:25:16 --> No URI present. Default controller set.
INFO - 2021-06-17 02:25:16 --> Router Class Initialized
INFO - 2021-06-17 02:25:16 --> Output Class Initialized
INFO - 2021-06-17 02:25:16 --> Security Class Initialized
DEBUG - 2021-06-17 02:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 02:25:16 --> Input Class Initialized
INFO - 2021-06-17 02:25:16 --> Language Class Initialized
INFO - 2021-06-17 02:25:16 --> Language Class Initialized
INFO - 2021-06-17 02:25:16 --> Config Class Initialized
INFO - 2021-06-17 02:25:16 --> Loader Class Initialized
INFO - 2021-06-17 02:25:17 --> Helper loaded: url_helper
INFO - 2021-06-17 02:25:17 --> Helper loaded: file_helper
INFO - 2021-06-17 02:25:17 --> Helper loaded: form_helper
INFO - 2021-06-17 02:25:17 --> Helper loaded: my_helper
INFO - 2021-06-17 02:25:17 --> Database Driver Class Initialized
DEBUG - 2021-06-17 02:25:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 02:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 02:25:17 --> Controller Class Initialized
INFO - 2021-06-17 02:25:17 --> Config Class Initialized
INFO - 2021-06-17 02:25:17 --> Hooks Class Initialized
DEBUG - 2021-06-17 02:25:17 --> UTF-8 Support Enabled
INFO - 2021-06-17 02:25:17 --> Utf8 Class Initialized
INFO - 2021-06-17 02:25:17 --> URI Class Initialized
INFO - 2021-06-17 02:25:17 --> Router Class Initialized
INFO - 2021-06-17 02:25:17 --> Output Class Initialized
INFO - 2021-06-17 02:25:17 --> Security Class Initialized
DEBUG - 2021-06-17 02:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 02:25:17 --> Input Class Initialized
INFO - 2021-06-17 02:25:17 --> Language Class Initialized
INFO - 2021-06-17 02:25:17 --> Language Class Initialized
INFO - 2021-06-17 02:25:17 --> Config Class Initialized
INFO - 2021-06-17 02:25:17 --> Loader Class Initialized
INFO - 2021-06-17 02:25:17 --> Helper loaded: url_helper
INFO - 2021-06-17 02:25:17 --> Helper loaded: file_helper
INFO - 2021-06-17 02:25:17 --> Helper loaded: form_helper
INFO - 2021-06-17 02:25:17 --> Helper loaded: my_helper
INFO - 2021-06-17 02:25:17 --> Database Driver Class Initialized
DEBUG - 2021-06-17 02:25:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 02:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 02:25:17 --> Controller Class Initialized
DEBUG - 2021-06-17 02:25:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-17 02:25:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 02:25:17 --> Final output sent to browser
DEBUG - 2021-06-17 02:25:17 --> Total execution time: 0.0935
INFO - 2021-06-17 02:25:24 --> Config Class Initialized
INFO - 2021-06-17 02:25:24 --> Hooks Class Initialized
DEBUG - 2021-06-17 02:25:24 --> UTF-8 Support Enabled
INFO - 2021-06-17 02:25:24 --> Utf8 Class Initialized
INFO - 2021-06-17 02:25:24 --> URI Class Initialized
INFO - 2021-06-17 02:25:24 --> Router Class Initialized
INFO - 2021-06-17 02:25:24 --> Output Class Initialized
INFO - 2021-06-17 02:25:24 --> Security Class Initialized
DEBUG - 2021-06-17 02:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 02:25:24 --> Input Class Initialized
INFO - 2021-06-17 02:25:24 --> Language Class Initialized
INFO - 2021-06-17 02:25:24 --> Language Class Initialized
INFO - 2021-06-17 02:25:24 --> Config Class Initialized
INFO - 2021-06-17 02:25:24 --> Loader Class Initialized
INFO - 2021-06-17 02:25:24 --> Helper loaded: url_helper
INFO - 2021-06-17 02:25:24 --> Helper loaded: file_helper
INFO - 2021-06-17 02:25:24 --> Helper loaded: form_helper
INFO - 2021-06-17 02:25:24 --> Helper loaded: my_helper
INFO - 2021-06-17 02:25:24 --> Database Driver Class Initialized
DEBUG - 2021-06-17 02:25:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 02:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 02:25:24 --> Controller Class Initialized
INFO - 2021-06-17 02:25:24 --> Helper loaded: cookie_helper
INFO - 2021-06-17 02:25:24 --> Final output sent to browser
DEBUG - 2021-06-17 02:25:24 --> Total execution time: 0.0759
INFO - 2021-06-17 02:25:25 --> Config Class Initialized
INFO - 2021-06-17 02:25:25 --> Hooks Class Initialized
DEBUG - 2021-06-17 02:25:25 --> UTF-8 Support Enabled
INFO - 2021-06-17 02:25:25 --> Utf8 Class Initialized
INFO - 2021-06-17 02:25:25 --> URI Class Initialized
INFO - 2021-06-17 02:25:25 --> Router Class Initialized
INFO - 2021-06-17 02:25:25 --> Output Class Initialized
INFO - 2021-06-17 02:25:25 --> Security Class Initialized
DEBUG - 2021-06-17 02:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 02:25:25 --> Input Class Initialized
INFO - 2021-06-17 02:25:25 --> Language Class Initialized
INFO - 2021-06-17 02:25:25 --> Language Class Initialized
INFO - 2021-06-17 02:25:25 --> Config Class Initialized
INFO - 2021-06-17 02:25:25 --> Loader Class Initialized
INFO - 2021-06-17 02:25:25 --> Helper loaded: url_helper
INFO - 2021-06-17 02:25:25 --> Helper loaded: file_helper
INFO - 2021-06-17 02:25:25 --> Helper loaded: form_helper
INFO - 2021-06-17 02:25:25 --> Helper loaded: my_helper
INFO - 2021-06-17 02:25:25 --> Database Driver Class Initialized
DEBUG - 2021-06-17 02:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 02:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 02:25:25 --> Controller Class Initialized
DEBUG - 2021-06-17 02:25:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-17 02:25:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 02:25:25 --> Final output sent to browser
DEBUG - 2021-06-17 02:25:25 --> Total execution time: 0.2926
INFO - 2021-06-17 02:25:28 --> Config Class Initialized
INFO - 2021-06-17 02:25:28 --> Hooks Class Initialized
DEBUG - 2021-06-17 02:25:28 --> UTF-8 Support Enabled
INFO - 2021-06-17 02:25:28 --> Utf8 Class Initialized
INFO - 2021-06-17 02:25:28 --> URI Class Initialized
INFO - 2021-06-17 02:25:28 --> Router Class Initialized
INFO - 2021-06-17 02:25:28 --> Output Class Initialized
INFO - 2021-06-17 02:25:28 --> Security Class Initialized
DEBUG - 2021-06-17 02:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 02:25:28 --> Input Class Initialized
INFO - 2021-06-17 02:25:28 --> Language Class Initialized
INFO - 2021-06-17 02:25:28 --> Language Class Initialized
INFO - 2021-06-17 02:25:28 --> Config Class Initialized
INFO - 2021-06-17 02:25:28 --> Loader Class Initialized
INFO - 2021-06-17 02:25:28 --> Helper loaded: url_helper
INFO - 2021-06-17 02:25:28 --> Helper loaded: file_helper
INFO - 2021-06-17 02:25:28 --> Helper loaded: form_helper
INFO - 2021-06-17 02:25:28 --> Helper loaded: my_helper
INFO - 2021-06-17 02:25:28 --> Database Driver Class Initialized
DEBUG - 2021-06-17 02:25:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 02:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 02:25:28 --> Controller Class Initialized
DEBUG - 2021-06-17 02:25:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-06-17 02:25:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 02:25:28 --> Final output sent to browser
DEBUG - 2021-06-17 02:25:28 --> Total execution time: 0.0746
INFO - 2021-06-17 02:25:28 --> Config Class Initialized
INFO - 2021-06-17 02:25:28 --> Hooks Class Initialized
DEBUG - 2021-06-17 02:25:28 --> UTF-8 Support Enabled
INFO - 2021-06-17 02:25:28 --> Utf8 Class Initialized
INFO - 2021-06-17 02:25:28 --> URI Class Initialized
INFO - 2021-06-17 02:25:28 --> Router Class Initialized
INFO - 2021-06-17 02:25:28 --> Output Class Initialized
INFO - 2021-06-17 02:25:28 --> Security Class Initialized
DEBUG - 2021-06-17 02:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 02:25:28 --> Input Class Initialized
INFO - 2021-06-17 02:25:28 --> Language Class Initialized
INFO - 2021-06-17 02:25:28 --> Language Class Initialized
INFO - 2021-06-17 02:25:28 --> Config Class Initialized
INFO - 2021-06-17 02:25:28 --> Loader Class Initialized
INFO - 2021-06-17 02:25:28 --> Helper loaded: url_helper
INFO - 2021-06-17 02:25:28 --> Helper loaded: file_helper
INFO - 2021-06-17 02:25:28 --> Helper loaded: form_helper
INFO - 2021-06-17 02:25:28 --> Helper loaded: my_helper
INFO - 2021-06-17 02:25:28 --> Database Driver Class Initialized
DEBUG - 2021-06-17 02:25:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 02:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 02:25:28 --> Controller Class Initialized
INFO - 2021-06-17 02:25:47 --> Config Class Initialized
INFO - 2021-06-17 02:25:47 --> Hooks Class Initialized
DEBUG - 2021-06-17 02:25:47 --> UTF-8 Support Enabled
INFO - 2021-06-17 02:25:47 --> Utf8 Class Initialized
INFO - 2021-06-17 02:25:47 --> URI Class Initialized
INFO - 2021-06-17 02:25:47 --> Router Class Initialized
INFO - 2021-06-17 02:25:47 --> Output Class Initialized
INFO - 2021-06-17 02:25:47 --> Security Class Initialized
DEBUG - 2021-06-17 02:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 02:25:47 --> Input Class Initialized
INFO - 2021-06-17 02:25:47 --> Language Class Initialized
INFO - 2021-06-17 02:25:47 --> Language Class Initialized
INFO - 2021-06-17 02:25:47 --> Config Class Initialized
INFO - 2021-06-17 02:25:47 --> Loader Class Initialized
INFO - 2021-06-17 02:25:47 --> Helper loaded: url_helper
INFO - 2021-06-17 02:25:47 --> Helper loaded: file_helper
INFO - 2021-06-17 02:25:47 --> Helper loaded: form_helper
INFO - 2021-06-17 02:25:47 --> Helper loaded: my_helper
INFO - 2021-06-17 02:25:47 --> Database Driver Class Initialized
DEBUG - 2021-06-17 02:25:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 02:25:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 02:25:47 --> Controller Class Initialized
INFO - 2021-06-17 02:25:56 --> Config Class Initialized
INFO - 2021-06-17 02:25:56 --> Hooks Class Initialized
DEBUG - 2021-06-17 02:25:56 --> UTF-8 Support Enabled
INFO - 2021-06-17 02:25:56 --> Utf8 Class Initialized
INFO - 2021-06-17 02:25:56 --> URI Class Initialized
INFO - 2021-06-17 02:25:56 --> Router Class Initialized
INFO - 2021-06-17 02:25:56 --> Output Class Initialized
INFO - 2021-06-17 02:25:56 --> Security Class Initialized
DEBUG - 2021-06-17 02:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 02:25:56 --> Input Class Initialized
INFO - 2021-06-17 02:25:56 --> Language Class Initialized
INFO - 2021-06-17 02:25:56 --> Language Class Initialized
INFO - 2021-06-17 02:25:56 --> Config Class Initialized
INFO - 2021-06-17 02:25:56 --> Loader Class Initialized
INFO - 2021-06-17 02:25:56 --> Helper loaded: url_helper
INFO - 2021-06-17 02:25:56 --> Helper loaded: file_helper
INFO - 2021-06-17 02:25:56 --> Helper loaded: form_helper
INFO - 2021-06-17 02:25:56 --> Helper loaded: my_helper
INFO - 2021-06-17 02:25:56 --> Database Driver Class Initialized
DEBUG - 2021-06-17 02:25:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 02:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 02:25:56 --> Controller Class Initialized
INFO - 2021-06-17 02:26:09 --> Config Class Initialized
INFO - 2021-06-17 02:26:09 --> Hooks Class Initialized
DEBUG - 2021-06-17 02:26:09 --> UTF-8 Support Enabled
INFO - 2021-06-17 02:26:09 --> Utf8 Class Initialized
INFO - 2021-06-17 02:26:09 --> URI Class Initialized
INFO - 2021-06-17 02:26:09 --> Router Class Initialized
INFO - 2021-06-17 02:26:09 --> Output Class Initialized
INFO - 2021-06-17 02:26:09 --> Security Class Initialized
DEBUG - 2021-06-17 02:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 02:26:09 --> Input Class Initialized
INFO - 2021-06-17 02:26:09 --> Language Class Initialized
INFO - 2021-06-17 02:26:09 --> Language Class Initialized
INFO - 2021-06-17 02:26:09 --> Config Class Initialized
INFO - 2021-06-17 02:26:09 --> Loader Class Initialized
INFO - 2021-06-17 02:26:09 --> Helper loaded: url_helper
INFO - 2021-06-17 02:26:09 --> Helper loaded: file_helper
INFO - 2021-06-17 02:26:09 --> Helper loaded: form_helper
INFO - 2021-06-17 02:26:09 --> Helper loaded: my_helper
INFO - 2021-06-17 02:26:09 --> Database Driver Class Initialized
DEBUG - 2021-06-17 02:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 02:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 02:26:09 --> Controller Class Initialized
INFO - 2021-06-17 02:26:18 --> Config Class Initialized
INFO - 2021-06-17 02:26:18 --> Hooks Class Initialized
DEBUG - 2021-06-17 02:26:18 --> UTF-8 Support Enabled
INFO - 2021-06-17 02:26:18 --> Utf8 Class Initialized
INFO - 2021-06-17 02:26:18 --> URI Class Initialized
INFO - 2021-06-17 02:26:18 --> Router Class Initialized
INFO - 2021-06-17 02:26:18 --> Output Class Initialized
INFO - 2021-06-17 02:26:18 --> Security Class Initialized
DEBUG - 2021-06-17 02:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 02:26:18 --> Input Class Initialized
INFO - 2021-06-17 02:26:18 --> Language Class Initialized
INFO - 2021-06-17 02:26:18 --> Language Class Initialized
INFO - 2021-06-17 02:26:18 --> Config Class Initialized
INFO - 2021-06-17 02:26:18 --> Loader Class Initialized
INFO - 2021-06-17 02:26:18 --> Helper loaded: url_helper
INFO - 2021-06-17 02:26:18 --> Helper loaded: file_helper
INFO - 2021-06-17 02:26:18 --> Helper loaded: form_helper
INFO - 2021-06-17 02:26:18 --> Helper loaded: my_helper
INFO - 2021-06-17 02:26:18 --> Database Driver Class Initialized
DEBUG - 2021-06-17 02:26:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 02:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 02:26:18 --> Controller Class Initialized
INFO - 2021-06-17 02:26:19 --> Config Class Initialized
INFO - 2021-06-17 02:26:19 --> Hooks Class Initialized
DEBUG - 2021-06-17 02:26:19 --> UTF-8 Support Enabled
INFO - 2021-06-17 02:26:19 --> Utf8 Class Initialized
INFO - 2021-06-17 02:26:19 --> URI Class Initialized
INFO - 2021-06-17 02:26:19 --> Router Class Initialized
INFO - 2021-06-17 02:26:19 --> Output Class Initialized
INFO - 2021-06-17 02:26:19 --> Security Class Initialized
DEBUG - 2021-06-17 02:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 02:26:19 --> Input Class Initialized
INFO - 2021-06-17 02:26:19 --> Language Class Initialized
INFO - 2021-06-17 02:26:19 --> Language Class Initialized
INFO - 2021-06-17 02:26:19 --> Config Class Initialized
INFO - 2021-06-17 02:26:19 --> Loader Class Initialized
INFO - 2021-06-17 02:26:19 --> Helper loaded: url_helper
INFO - 2021-06-17 02:26:19 --> Helper loaded: file_helper
INFO - 2021-06-17 02:26:19 --> Helper loaded: form_helper
INFO - 2021-06-17 02:26:19 --> Helper loaded: my_helper
INFO - 2021-06-17 02:26:19 --> Database Driver Class Initialized
DEBUG - 2021-06-17 02:26:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 02:26:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 02:26:20 --> Controller Class Initialized
INFO - 2021-06-17 02:26:20 --> Config Class Initialized
INFO - 2021-06-17 02:26:20 --> Hooks Class Initialized
DEBUG - 2021-06-17 02:26:20 --> UTF-8 Support Enabled
INFO - 2021-06-17 02:26:20 --> Utf8 Class Initialized
INFO - 2021-06-17 02:26:20 --> URI Class Initialized
INFO - 2021-06-17 02:26:20 --> Router Class Initialized
INFO - 2021-06-17 02:26:20 --> Output Class Initialized
INFO - 2021-06-17 02:26:20 --> Security Class Initialized
DEBUG - 2021-06-17 02:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 02:26:20 --> Input Class Initialized
INFO - 2021-06-17 02:26:20 --> Language Class Initialized
INFO - 2021-06-17 02:26:21 --> Language Class Initialized
INFO - 2021-06-17 02:26:21 --> Config Class Initialized
INFO - 2021-06-17 02:26:21 --> Loader Class Initialized
INFO - 2021-06-17 02:26:21 --> Helper loaded: url_helper
INFO - 2021-06-17 02:26:21 --> Helper loaded: file_helper
INFO - 2021-06-17 02:26:21 --> Helper loaded: form_helper
INFO - 2021-06-17 02:26:21 --> Helper loaded: my_helper
INFO - 2021-06-17 02:26:21 --> Database Driver Class Initialized
DEBUG - 2021-06-17 02:26:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 02:26:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 02:26:21 --> Controller Class Initialized
INFO - 2021-06-17 02:26:32 --> Config Class Initialized
INFO - 2021-06-17 02:26:32 --> Hooks Class Initialized
DEBUG - 2021-06-17 02:26:32 --> UTF-8 Support Enabled
INFO - 2021-06-17 02:26:32 --> Utf8 Class Initialized
INFO - 2021-06-17 02:26:32 --> URI Class Initialized
INFO - 2021-06-17 02:26:32 --> Router Class Initialized
INFO - 2021-06-17 02:26:32 --> Output Class Initialized
INFO - 2021-06-17 02:26:32 --> Security Class Initialized
DEBUG - 2021-06-17 02:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 02:26:32 --> Input Class Initialized
INFO - 2021-06-17 02:26:32 --> Language Class Initialized
INFO - 2021-06-17 02:26:32 --> Language Class Initialized
INFO - 2021-06-17 02:26:32 --> Config Class Initialized
INFO - 2021-06-17 02:26:32 --> Loader Class Initialized
INFO - 2021-06-17 02:26:32 --> Helper loaded: url_helper
INFO - 2021-06-17 02:26:32 --> Helper loaded: file_helper
INFO - 2021-06-17 02:26:32 --> Helper loaded: form_helper
INFO - 2021-06-17 02:26:32 --> Helper loaded: my_helper
INFO - 2021-06-17 02:26:32 --> Database Driver Class Initialized
DEBUG - 2021-06-17 02:26:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 02:26:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 02:26:32 --> Controller Class Initialized
INFO - 2021-06-17 02:26:33 --> Config Class Initialized
INFO - 2021-06-17 02:26:33 --> Hooks Class Initialized
DEBUG - 2021-06-17 02:26:33 --> UTF-8 Support Enabled
INFO - 2021-06-17 02:26:33 --> Utf8 Class Initialized
INFO - 2021-06-17 02:26:33 --> URI Class Initialized
INFO - 2021-06-17 02:26:33 --> Router Class Initialized
INFO - 2021-06-17 02:26:33 --> Output Class Initialized
INFO - 2021-06-17 02:26:33 --> Security Class Initialized
DEBUG - 2021-06-17 02:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 02:26:33 --> Input Class Initialized
INFO - 2021-06-17 02:26:33 --> Language Class Initialized
INFO - 2021-06-17 02:26:33 --> Language Class Initialized
INFO - 2021-06-17 02:26:33 --> Config Class Initialized
INFO - 2021-06-17 02:26:33 --> Loader Class Initialized
INFO - 2021-06-17 02:26:33 --> Helper loaded: url_helper
INFO - 2021-06-17 02:26:33 --> Helper loaded: file_helper
INFO - 2021-06-17 02:26:33 --> Helper loaded: form_helper
INFO - 2021-06-17 02:26:33 --> Helper loaded: my_helper
INFO - 2021-06-17 02:26:33 --> Database Driver Class Initialized
DEBUG - 2021-06-17 02:26:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 02:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 02:26:33 --> Controller Class Initialized
INFO - 2021-06-17 02:26:40 --> Config Class Initialized
INFO - 2021-06-17 02:26:40 --> Hooks Class Initialized
DEBUG - 2021-06-17 02:26:40 --> UTF-8 Support Enabled
INFO - 2021-06-17 02:26:40 --> Utf8 Class Initialized
INFO - 2021-06-17 02:26:40 --> URI Class Initialized
INFO - 2021-06-17 02:26:40 --> Router Class Initialized
INFO - 2021-06-17 02:26:40 --> Output Class Initialized
INFO - 2021-06-17 02:26:40 --> Security Class Initialized
DEBUG - 2021-06-17 02:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 02:26:40 --> Input Class Initialized
INFO - 2021-06-17 02:26:40 --> Language Class Initialized
INFO - 2021-06-17 02:26:40 --> Language Class Initialized
INFO - 2021-06-17 02:26:40 --> Config Class Initialized
INFO - 2021-06-17 02:26:40 --> Loader Class Initialized
INFO - 2021-06-17 02:26:40 --> Helper loaded: url_helper
INFO - 2021-06-17 02:26:40 --> Helper loaded: file_helper
INFO - 2021-06-17 02:26:40 --> Helper loaded: form_helper
INFO - 2021-06-17 02:26:40 --> Helper loaded: my_helper
INFO - 2021-06-17 02:26:40 --> Database Driver Class Initialized
DEBUG - 2021-06-17 02:26:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 02:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 02:26:40 --> Controller Class Initialized
INFO - 2021-06-17 02:26:41 --> Config Class Initialized
INFO - 2021-06-17 02:26:41 --> Hooks Class Initialized
DEBUG - 2021-06-17 02:26:41 --> UTF-8 Support Enabled
INFO - 2021-06-17 02:26:41 --> Utf8 Class Initialized
INFO - 2021-06-17 02:26:41 --> URI Class Initialized
INFO - 2021-06-17 02:26:41 --> Router Class Initialized
INFO - 2021-06-17 02:26:41 --> Output Class Initialized
INFO - 2021-06-17 02:26:41 --> Security Class Initialized
DEBUG - 2021-06-17 02:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 02:26:41 --> Input Class Initialized
INFO - 2021-06-17 02:26:41 --> Language Class Initialized
INFO - 2021-06-17 02:26:41 --> Language Class Initialized
INFO - 2021-06-17 02:26:41 --> Config Class Initialized
INFO - 2021-06-17 02:26:41 --> Loader Class Initialized
INFO - 2021-06-17 02:26:41 --> Helper loaded: url_helper
INFO - 2021-06-17 02:26:41 --> Helper loaded: file_helper
INFO - 2021-06-17 02:26:41 --> Helper loaded: form_helper
INFO - 2021-06-17 02:26:41 --> Helper loaded: my_helper
INFO - 2021-06-17 02:26:41 --> Database Driver Class Initialized
DEBUG - 2021-06-17 02:26:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 02:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 02:26:41 --> Controller Class Initialized
INFO - 2021-06-17 02:26:50 --> Config Class Initialized
INFO - 2021-06-17 02:26:50 --> Hooks Class Initialized
DEBUG - 2021-06-17 02:26:50 --> UTF-8 Support Enabled
INFO - 2021-06-17 02:26:50 --> Utf8 Class Initialized
INFO - 2021-06-17 02:26:50 --> URI Class Initialized
INFO - 2021-06-17 02:26:50 --> Router Class Initialized
INFO - 2021-06-17 02:26:50 --> Output Class Initialized
INFO - 2021-06-17 02:26:50 --> Security Class Initialized
DEBUG - 2021-06-17 02:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 02:26:50 --> Input Class Initialized
INFO - 2021-06-17 02:26:50 --> Language Class Initialized
INFO - 2021-06-17 02:26:50 --> Language Class Initialized
INFO - 2021-06-17 02:26:50 --> Config Class Initialized
INFO - 2021-06-17 02:26:50 --> Loader Class Initialized
INFO - 2021-06-17 02:26:50 --> Helper loaded: url_helper
INFO - 2021-06-17 02:26:50 --> Helper loaded: file_helper
INFO - 2021-06-17 02:26:50 --> Helper loaded: form_helper
INFO - 2021-06-17 02:26:50 --> Helper loaded: my_helper
INFO - 2021-06-17 02:26:50 --> Database Driver Class Initialized
DEBUG - 2021-06-17 02:26:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 02:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 02:26:50 --> Controller Class Initialized
INFO - 2021-06-17 02:26:51 --> Config Class Initialized
INFO - 2021-06-17 02:26:51 --> Hooks Class Initialized
DEBUG - 2021-06-17 02:26:51 --> UTF-8 Support Enabled
INFO - 2021-06-17 02:26:51 --> Utf8 Class Initialized
INFO - 2021-06-17 02:26:51 --> URI Class Initialized
INFO - 2021-06-17 02:26:51 --> Router Class Initialized
INFO - 2021-06-17 02:26:51 --> Output Class Initialized
INFO - 2021-06-17 02:26:51 --> Security Class Initialized
DEBUG - 2021-06-17 02:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 02:26:51 --> Input Class Initialized
INFO - 2021-06-17 02:26:51 --> Language Class Initialized
INFO - 2021-06-17 02:26:51 --> Language Class Initialized
INFO - 2021-06-17 02:26:51 --> Config Class Initialized
INFO - 2021-06-17 02:26:51 --> Loader Class Initialized
INFO - 2021-06-17 02:26:51 --> Helper loaded: url_helper
INFO - 2021-06-17 02:26:51 --> Helper loaded: file_helper
INFO - 2021-06-17 02:26:51 --> Helper loaded: form_helper
INFO - 2021-06-17 02:26:51 --> Helper loaded: my_helper
INFO - 2021-06-17 02:26:51 --> Database Driver Class Initialized
DEBUG - 2021-06-17 02:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 02:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 02:26:51 --> Controller Class Initialized
INFO - 2021-06-17 02:26:58 --> Config Class Initialized
INFO - 2021-06-17 02:26:58 --> Hooks Class Initialized
DEBUG - 2021-06-17 02:26:58 --> UTF-8 Support Enabled
INFO - 2021-06-17 02:26:58 --> Utf8 Class Initialized
INFO - 2021-06-17 02:26:58 --> URI Class Initialized
INFO - 2021-06-17 02:26:58 --> Router Class Initialized
INFO - 2021-06-17 02:26:58 --> Output Class Initialized
INFO - 2021-06-17 02:26:58 --> Security Class Initialized
DEBUG - 2021-06-17 02:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 02:26:58 --> Input Class Initialized
INFO - 2021-06-17 02:26:58 --> Language Class Initialized
INFO - 2021-06-17 02:26:58 --> Language Class Initialized
INFO - 2021-06-17 02:26:58 --> Config Class Initialized
INFO - 2021-06-17 02:26:58 --> Loader Class Initialized
INFO - 2021-06-17 02:26:58 --> Helper loaded: url_helper
INFO - 2021-06-17 02:26:58 --> Helper loaded: file_helper
INFO - 2021-06-17 02:26:58 --> Helper loaded: form_helper
INFO - 2021-06-17 02:26:58 --> Helper loaded: my_helper
INFO - 2021-06-17 02:26:58 --> Database Driver Class Initialized
DEBUG - 2021-06-17 02:26:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 02:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 02:26:58 --> Controller Class Initialized
INFO - 2021-06-17 02:26:59 --> Config Class Initialized
INFO - 2021-06-17 02:26:59 --> Hooks Class Initialized
DEBUG - 2021-06-17 02:26:59 --> UTF-8 Support Enabled
INFO - 2021-06-17 02:26:59 --> Utf8 Class Initialized
INFO - 2021-06-17 02:26:59 --> URI Class Initialized
INFO - 2021-06-17 02:26:59 --> Router Class Initialized
INFO - 2021-06-17 02:26:59 --> Output Class Initialized
INFO - 2021-06-17 02:26:59 --> Security Class Initialized
DEBUG - 2021-06-17 02:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 02:26:59 --> Input Class Initialized
INFO - 2021-06-17 02:26:59 --> Language Class Initialized
INFO - 2021-06-17 02:26:59 --> Language Class Initialized
INFO - 2021-06-17 02:26:59 --> Config Class Initialized
INFO - 2021-06-17 02:26:59 --> Loader Class Initialized
INFO - 2021-06-17 02:26:59 --> Helper loaded: url_helper
INFO - 2021-06-17 02:26:59 --> Helper loaded: file_helper
INFO - 2021-06-17 02:26:59 --> Helper loaded: form_helper
INFO - 2021-06-17 02:26:59 --> Helper loaded: my_helper
INFO - 2021-06-17 02:26:59 --> Database Driver Class Initialized
DEBUG - 2021-06-17 02:26:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 02:26:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 02:26:59 --> Controller Class Initialized
INFO - 2021-06-17 02:27:08 --> Config Class Initialized
INFO - 2021-06-17 02:27:08 --> Hooks Class Initialized
DEBUG - 2021-06-17 02:27:08 --> UTF-8 Support Enabled
INFO - 2021-06-17 02:27:08 --> Utf8 Class Initialized
INFO - 2021-06-17 02:27:08 --> URI Class Initialized
INFO - 2021-06-17 02:27:08 --> Router Class Initialized
INFO - 2021-06-17 02:27:08 --> Output Class Initialized
INFO - 2021-06-17 02:27:08 --> Security Class Initialized
DEBUG - 2021-06-17 02:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 02:27:08 --> Input Class Initialized
INFO - 2021-06-17 02:27:08 --> Language Class Initialized
INFO - 2021-06-17 02:27:08 --> Language Class Initialized
INFO - 2021-06-17 02:27:08 --> Config Class Initialized
INFO - 2021-06-17 02:27:08 --> Loader Class Initialized
INFO - 2021-06-17 02:27:08 --> Helper loaded: url_helper
INFO - 2021-06-17 02:27:08 --> Helper loaded: file_helper
INFO - 2021-06-17 02:27:08 --> Helper loaded: form_helper
INFO - 2021-06-17 02:27:08 --> Helper loaded: my_helper
INFO - 2021-06-17 02:27:08 --> Database Driver Class Initialized
DEBUG - 2021-06-17 02:27:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 02:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 02:27:08 --> Controller Class Initialized
INFO - 2021-06-17 02:27:16 --> Config Class Initialized
INFO - 2021-06-17 02:27:16 --> Hooks Class Initialized
DEBUG - 2021-06-17 02:27:16 --> UTF-8 Support Enabled
INFO - 2021-06-17 02:27:16 --> Utf8 Class Initialized
INFO - 2021-06-17 02:27:16 --> URI Class Initialized
INFO - 2021-06-17 02:27:16 --> Router Class Initialized
INFO - 2021-06-17 02:27:16 --> Output Class Initialized
INFO - 2021-06-17 02:27:16 --> Security Class Initialized
DEBUG - 2021-06-17 02:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 02:27:16 --> Input Class Initialized
INFO - 2021-06-17 02:27:16 --> Language Class Initialized
INFO - 2021-06-17 02:27:16 --> Language Class Initialized
INFO - 2021-06-17 02:27:16 --> Config Class Initialized
INFO - 2021-06-17 02:27:16 --> Loader Class Initialized
INFO - 2021-06-17 02:27:16 --> Helper loaded: url_helper
INFO - 2021-06-17 02:27:16 --> Helper loaded: file_helper
INFO - 2021-06-17 02:27:16 --> Helper loaded: form_helper
INFO - 2021-06-17 02:27:16 --> Helper loaded: my_helper
INFO - 2021-06-17 02:27:16 --> Database Driver Class Initialized
DEBUG - 2021-06-17 02:27:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 02:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 02:27:16 --> Controller Class Initialized
INFO - 2021-06-17 02:27:25 --> Config Class Initialized
INFO - 2021-06-17 02:27:25 --> Hooks Class Initialized
DEBUG - 2021-06-17 02:27:25 --> UTF-8 Support Enabled
INFO - 2021-06-17 02:27:25 --> Utf8 Class Initialized
INFO - 2021-06-17 02:27:25 --> URI Class Initialized
INFO - 2021-06-17 02:27:25 --> Router Class Initialized
INFO - 2021-06-17 02:27:25 --> Output Class Initialized
INFO - 2021-06-17 02:27:25 --> Security Class Initialized
DEBUG - 2021-06-17 02:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 02:27:25 --> Input Class Initialized
INFO - 2021-06-17 02:27:25 --> Language Class Initialized
INFO - 2021-06-17 02:27:25 --> Language Class Initialized
INFO - 2021-06-17 02:27:25 --> Config Class Initialized
INFO - 2021-06-17 02:27:25 --> Loader Class Initialized
INFO - 2021-06-17 02:27:25 --> Helper loaded: url_helper
INFO - 2021-06-17 02:27:25 --> Helper loaded: file_helper
INFO - 2021-06-17 02:27:25 --> Helper loaded: form_helper
INFO - 2021-06-17 02:27:25 --> Helper loaded: my_helper
INFO - 2021-06-17 02:27:25 --> Database Driver Class Initialized
DEBUG - 2021-06-17 02:27:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 02:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 02:27:25 --> Controller Class Initialized
INFO - 2021-06-17 02:27:39 --> Config Class Initialized
INFO - 2021-06-17 02:27:39 --> Hooks Class Initialized
DEBUG - 2021-06-17 02:27:39 --> UTF-8 Support Enabled
INFO - 2021-06-17 02:27:39 --> Utf8 Class Initialized
INFO - 2021-06-17 02:27:39 --> URI Class Initialized
INFO - 2021-06-17 02:27:39 --> Router Class Initialized
INFO - 2021-06-17 02:27:39 --> Output Class Initialized
INFO - 2021-06-17 02:27:39 --> Security Class Initialized
DEBUG - 2021-06-17 02:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 02:27:39 --> Input Class Initialized
INFO - 2021-06-17 02:27:39 --> Language Class Initialized
INFO - 2021-06-17 02:27:39 --> Language Class Initialized
INFO - 2021-06-17 02:27:39 --> Config Class Initialized
INFO - 2021-06-17 02:27:39 --> Loader Class Initialized
INFO - 2021-06-17 02:27:39 --> Helper loaded: url_helper
INFO - 2021-06-17 02:27:39 --> Helper loaded: file_helper
INFO - 2021-06-17 02:27:39 --> Helper loaded: form_helper
INFO - 2021-06-17 02:27:39 --> Helper loaded: my_helper
INFO - 2021-06-17 02:27:39 --> Database Driver Class Initialized
DEBUG - 2021-06-17 02:27:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 02:27:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 02:27:39 --> Controller Class Initialized
INFO - 2021-06-17 02:27:51 --> Config Class Initialized
INFO - 2021-06-17 02:27:51 --> Hooks Class Initialized
DEBUG - 2021-06-17 02:27:51 --> UTF-8 Support Enabled
INFO - 2021-06-17 02:27:51 --> Utf8 Class Initialized
INFO - 2021-06-17 02:27:51 --> URI Class Initialized
INFO - 2021-06-17 02:27:51 --> Router Class Initialized
INFO - 2021-06-17 02:27:51 --> Output Class Initialized
INFO - 2021-06-17 02:27:51 --> Security Class Initialized
DEBUG - 2021-06-17 02:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 02:27:51 --> Input Class Initialized
INFO - 2021-06-17 02:27:51 --> Language Class Initialized
INFO - 2021-06-17 02:27:51 --> Language Class Initialized
INFO - 2021-06-17 02:27:51 --> Config Class Initialized
INFO - 2021-06-17 02:27:51 --> Loader Class Initialized
INFO - 2021-06-17 02:27:51 --> Helper loaded: url_helper
INFO - 2021-06-17 02:27:51 --> Helper loaded: file_helper
INFO - 2021-06-17 02:27:51 --> Helper loaded: form_helper
INFO - 2021-06-17 02:27:51 --> Helper loaded: my_helper
INFO - 2021-06-17 02:27:51 --> Database Driver Class Initialized
DEBUG - 2021-06-17 02:27:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 02:27:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 02:27:51 --> Controller Class Initialized
INFO - 2021-06-17 02:28:00 --> Config Class Initialized
INFO - 2021-06-17 02:28:00 --> Hooks Class Initialized
DEBUG - 2021-06-17 02:28:00 --> UTF-8 Support Enabled
INFO - 2021-06-17 02:28:00 --> Utf8 Class Initialized
INFO - 2021-06-17 02:28:00 --> URI Class Initialized
INFO - 2021-06-17 02:28:00 --> Router Class Initialized
INFO - 2021-06-17 02:28:00 --> Output Class Initialized
INFO - 2021-06-17 02:28:00 --> Security Class Initialized
DEBUG - 2021-06-17 02:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 02:28:00 --> Input Class Initialized
INFO - 2021-06-17 02:28:00 --> Language Class Initialized
INFO - 2021-06-17 02:28:00 --> Language Class Initialized
INFO - 2021-06-17 02:28:00 --> Config Class Initialized
INFO - 2021-06-17 02:28:00 --> Loader Class Initialized
INFO - 2021-06-17 02:28:00 --> Helper loaded: url_helper
INFO - 2021-06-17 02:28:00 --> Helper loaded: file_helper
INFO - 2021-06-17 02:28:00 --> Helper loaded: form_helper
INFO - 2021-06-17 02:28:00 --> Helper loaded: my_helper
INFO - 2021-06-17 02:28:00 --> Database Driver Class Initialized
DEBUG - 2021-06-17 02:28:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 02:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 02:28:00 --> Controller Class Initialized
INFO - 2021-06-17 02:28:07 --> Config Class Initialized
INFO - 2021-06-17 02:28:07 --> Hooks Class Initialized
DEBUG - 2021-06-17 02:28:07 --> UTF-8 Support Enabled
INFO - 2021-06-17 02:28:07 --> Utf8 Class Initialized
INFO - 2021-06-17 02:28:07 --> URI Class Initialized
INFO - 2021-06-17 02:28:07 --> Router Class Initialized
INFO - 2021-06-17 02:28:07 --> Output Class Initialized
INFO - 2021-06-17 02:28:07 --> Security Class Initialized
DEBUG - 2021-06-17 02:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 02:28:07 --> Input Class Initialized
INFO - 2021-06-17 02:28:07 --> Language Class Initialized
INFO - 2021-06-17 02:28:07 --> Language Class Initialized
INFO - 2021-06-17 02:28:07 --> Config Class Initialized
INFO - 2021-06-17 02:28:07 --> Loader Class Initialized
INFO - 2021-06-17 02:28:07 --> Helper loaded: url_helper
INFO - 2021-06-17 02:28:07 --> Helper loaded: file_helper
INFO - 2021-06-17 02:28:07 --> Helper loaded: form_helper
INFO - 2021-06-17 02:28:07 --> Helper loaded: my_helper
INFO - 2021-06-17 02:28:07 --> Database Driver Class Initialized
DEBUG - 2021-06-17 02:28:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 02:28:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 02:28:07 --> Controller Class Initialized
INFO - 2021-06-17 02:28:17 --> Config Class Initialized
INFO - 2021-06-17 02:28:17 --> Hooks Class Initialized
DEBUG - 2021-06-17 02:28:17 --> UTF-8 Support Enabled
INFO - 2021-06-17 02:28:17 --> Utf8 Class Initialized
INFO - 2021-06-17 02:28:17 --> URI Class Initialized
INFO - 2021-06-17 02:28:17 --> Router Class Initialized
INFO - 2021-06-17 02:28:17 --> Output Class Initialized
INFO - 2021-06-17 02:28:17 --> Security Class Initialized
DEBUG - 2021-06-17 02:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 02:28:17 --> Input Class Initialized
INFO - 2021-06-17 02:28:17 --> Language Class Initialized
INFO - 2021-06-17 02:28:17 --> Language Class Initialized
INFO - 2021-06-17 02:28:17 --> Config Class Initialized
INFO - 2021-06-17 02:28:17 --> Loader Class Initialized
INFO - 2021-06-17 02:28:17 --> Helper loaded: url_helper
INFO - 2021-06-17 02:28:17 --> Helper loaded: file_helper
INFO - 2021-06-17 02:28:17 --> Helper loaded: form_helper
INFO - 2021-06-17 02:28:17 --> Helper loaded: my_helper
INFO - 2021-06-17 02:28:17 --> Database Driver Class Initialized
DEBUG - 2021-06-17 02:28:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 02:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 02:28:17 --> Controller Class Initialized
INFO - 2021-06-17 02:28:34 --> Config Class Initialized
INFO - 2021-06-17 02:28:34 --> Hooks Class Initialized
DEBUG - 2021-06-17 02:28:34 --> UTF-8 Support Enabled
INFO - 2021-06-17 02:28:34 --> Utf8 Class Initialized
INFO - 2021-06-17 02:28:34 --> URI Class Initialized
INFO - 2021-06-17 02:28:34 --> Router Class Initialized
INFO - 2021-06-17 02:28:34 --> Output Class Initialized
INFO - 2021-06-17 02:28:34 --> Security Class Initialized
DEBUG - 2021-06-17 02:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 02:28:34 --> Input Class Initialized
INFO - 2021-06-17 02:28:34 --> Language Class Initialized
INFO - 2021-06-17 02:28:34 --> Language Class Initialized
INFO - 2021-06-17 02:28:34 --> Config Class Initialized
INFO - 2021-06-17 02:28:34 --> Loader Class Initialized
INFO - 2021-06-17 02:28:34 --> Helper loaded: url_helper
INFO - 2021-06-17 02:28:34 --> Helper loaded: file_helper
INFO - 2021-06-17 02:28:34 --> Helper loaded: form_helper
INFO - 2021-06-17 02:28:34 --> Helper loaded: my_helper
INFO - 2021-06-17 02:28:34 --> Database Driver Class Initialized
DEBUG - 2021-06-17 02:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 02:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 02:28:34 --> Controller Class Initialized
INFO - 2021-06-17 02:28:42 --> Config Class Initialized
INFO - 2021-06-17 02:28:42 --> Hooks Class Initialized
DEBUG - 2021-06-17 02:28:42 --> UTF-8 Support Enabled
INFO - 2021-06-17 02:28:42 --> Utf8 Class Initialized
INFO - 2021-06-17 02:28:42 --> URI Class Initialized
INFO - 2021-06-17 02:28:42 --> Router Class Initialized
INFO - 2021-06-17 02:28:42 --> Output Class Initialized
INFO - 2021-06-17 02:28:42 --> Security Class Initialized
DEBUG - 2021-06-17 02:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 02:28:42 --> Input Class Initialized
INFO - 2021-06-17 02:28:42 --> Language Class Initialized
INFO - 2021-06-17 02:28:42 --> Language Class Initialized
INFO - 2021-06-17 02:28:42 --> Config Class Initialized
INFO - 2021-06-17 02:28:42 --> Loader Class Initialized
INFO - 2021-06-17 02:28:42 --> Helper loaded: url_helper
INFO - 2021-06-17 02:28:42 --> Helper loaded: file_helper
INFO - 2021-06-17 02:28:42 --> Helper loaded: form_helper
INFO - 2021-06-17 02:28:42 --> Helper loaded: my_helper
INFO - 2021-06-17 02:28:42 --> Database Driver Class Initialized
DEBUG - 2021-06-17 02:28:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 02:28:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 02:28:42 --> Controller Class Initialized
INFO - 2021-06-17 02:28:56 --> Config Class Initialized
INFO - 2021-06-17 02:28:56 --> Hooks Class Initialized
DEBUG - 2021-06-17 02:28:56 --> UTF-8 Support Enabled
INFO - 2021-06-17 02:28:56 --> Utf8 Class Initialized
INFO - 2021-06-17 02:28:56 --> URI Class Initialized
INFO - 2021-06-17 02:28:56 --> Router Class Initialized
INFO - 2021-06-17 02:28:56 --> Output Class Initialized
INFO - 2021-06-17 02:28:56 --> Security Class Initialized
DEBUG - 2021-06-17 02:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 02:28:56 --> Input Class Initialized
INFO - 2021-06-17 02:28:56 --> Language Class Initialized
INFO - 2021-06-17 02:28:56 --> Language Class Initialized
INFO - 2021-06-17 02:28:56 --> Config Class Initialized
INFO - 2021-06-17 02:28:56 --> Loader Class Initialized
INFO - 2021-06-17 02:28:56 --> Helper loaded: url_helper
INFO - 2021-06-17 02:28:56 --> Helper loaded: file_helper
INFO - 2021-06-17 02:28:56 --> Helper loaded: form_helper
INFO - 2021-06-17 02:28:56 --> Helper loaded: my_helper
INFO - 2021-06-17 02:28:56 --> Database Driver Class Initialized
DEBUG - 2021-06-17 02:28:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 02:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 02:28:56 --> Controller Class Initialized
INFO - 2021-06-17 02:29:05 --> Config Class Initialized
INFO - 2021-06-17 02:29:05 --> Hooks Class Initialized
DEBUG - 2021-06-17 02:29:05 --> UTF-8 Support Enabled
INFO - 2021-06-17 02:29:05 --> Utf8 Class Initialized
INFO - 2021-06-17 02:29:05 --> URI Class Initialized
INFO - 2021-06-17 02:29:05 --> Router Class Initialized
INFO - 2021-06-17 02:29:05 --> Output Class Initialized
INFO - 2021-06-17 02:29:05 --> Security Class Initialized
DEBUG - 2021-06-17 02:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 02:29:05 --> Input Class Initialized
INFO - 2021-06-17 02:29:05 --> Language Class Initialized
INFO - 2021-06-17 02:29:05 --> Language Class Initialized
INFO - 2021-06-17 02:29:05 --> Config Class Initialized
INFO - 2021-06-17 02:29:05 --> Loader Class Initialized
INFO - 2021-06-17 02:29:05 --> Helper loaded: url_helper
INFO - 2021-06-17 02:29:05 --> Helper loaded: file_helper
INFO - 2021-06-17 02:29:05 --> Helper loaded: form_helper
INFO - 2021-06-17 02:29:05 --> Helper loaded: my_helper
INFO - 2021-06-17 02:29:05 --> Database Driver Class Initialized
DEBUG - 2021-06-17 02:29:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 02:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 02:29:05 --> Controller Class Initialized
INFO - 2021-06-17 02:29:07 --> Config Class Initialized
INFO - 2021-06-17 02:29:07 --> Hooks Class Initialized
DEBUG - 2021-06-17 02:29:07 --> UTF-8 Support Enabled
INFO - 2021-06-17 02:29:07 --> Utf8 Class Initialized
INFO - 2021-06-17 02:29:07 --> URI Class Initialized
INFO - 2021-06-17 02:29:07 --> Router Class Initialized
INFO - 2021-06-17 02:29:07 --> Output Class Initialized
INFO - 2021-06-17 02:29:07 --> Security Class Initialized
DEBUG - 2021-06-17 02:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 02:29:07 --> Input Class Initialized
INFO - 2021-06-17 02:29:07 --> Language Class Initialized
INFO - 2021-06-17 02:29:07 --> Language Class Initialized
INFO - 2021-06-17 02:29:07 --> Config Class Initialized
INFO - 2021-06-17 02:29:07 --> Loader Class Initialized
INFO - 2021-06-17 02:29:07 --> Helper loaded: url_helper
INFO - 2021-06-17 02:29:07 --> Helper loaded: file_helper
INFO - 2021-06-17 02:29:07 --> Helper loaded: form_helper
INFO - 2021-06-17 02:29:07 --> Helper loaded: my_helper
INFO - 2021-06-17 02:29:07 --> Database Driver Class Initialized
DEBUG - 2021-06-17 02:29:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 02:29:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 02:29:07 --> Controller Class Initialized
INFO - 2021-06-17 02:29:09 --> Config Class Initialized
INFO - 2021-06-17 02:29:09 --> Hooks Class Initialized
DEBUG - 2021-06-17 02:29:09 --> UTF-8 Support Enabled
INFO - 2021-06-17 02:29:09 --> Utf8 Class Initialized
INFO - 2021-06-17 02:29:09 --> URI Class Initialized
INFO - 2021-06-17 02:29:09 --> Router Class Initialized
INFO - 2021-06-17 02:29:09 --> Output Class Initialized
INFO - 2021-06-17 02:29:09 --> Security Class Initialized
DEBUG - 2021-06-17 02:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 02:29:09 --> Input Class Initialized
INFO - 2021-06-17 02:29:09 --> Language Class Initialized
INFO - 2021-06-17 02:29:09 --> Language Class Initialized
INFO - 2021-06-17 02:29:09 --> Config Class Initialized
INFO - 2021-06-17 02:29:09 --> Loader Class Initialized
INFO - 2021-06-17 02:29:09 --> Helper loaded: url_helper
INFO - 2021-06-17 02:29:09 --> Helper loaded: file_helper
INFO - 2021-06-17 02:29:09 --> Helper loaded: form_helper
INFO - 2021-06-17 02:29:09 --> Helper loaded: my_helper
INFO - 2021-06-17 02:29:09 --> Database Driver Class Initialized
DEBUG - 2021-06-17 02:29:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 02:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 02:29:09 --> Controller Class Initialized
INFO - 2021-06-17 02:29:09 --> Helper loaded: cookie_helper
INFO - 2021-06-17 02:29:09 --> Config Class Initialized
INFO - 2021-06-17 02:29:09 --> Hooks Class Initialized
DEBUG - 2021-06-17 02:29:09 --> UTF-8 Support Enabled
INFO - 2021-06-17 02:29:09 --> Utf8 Class Initialized
INFO - 2021-06-17 02:29:09 --> URI Class Initialized
INFO - 2021-06-17 02:29:09 --> Router Class Initialized
INFO - 2021-06-17 02:29:09 --> Output Class Initialized
INFO - 2021-06-17 02:29:09 --> Security Class Initialized
DEBUG - 2021-06-17 02:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 02:29:09 --> Input Class Initialized
INFO - 2021-06-17 02:29:09 --> Language Class Initialized
INFO - 2021-06-17 02:29:09 --> Language Class Initialized
INFO - 2021-06-17 02:29:09 --> Config Class Initialized
INFO - 2021-06-17 02:29:09 --> Loader Class Initialized
INFO - 2021-06-17 02:29:09 --> Helper loaded: url_helper
INFO - 2021-06-17 02:29:09 --> Helper loaded: file_helper
INFO - 2021-06-17 02:29:09 --> Helper loaded: form_helper
INFO - 2021-06-17 02:29:09 --> Helper loaded: my_helper
INFO - 2021-06-17 02:29:09 --> Database Driver Class Initialized
DEBUG - 2021-06-17 02:29:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 02:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 02:29:09 --> Controller Class Initialized
DEBUG - 2021-06-17 02:29:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-17 02:29:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 02:29:09 --> Final output sent to browser
DEBUG - 2021-06-17 02:29:09 --> Total execution time: 0.0467
INFO - 2021-06-17 05:05:50 --> Config Class Initialized
INFO - 2021-06-17 05:05:50 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:05:50 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:05:50 --> Utf8 Class Initialized
INFO - 2021-06-17 05:05:50 --> URI Class Initialized
DEBUG - 2021-06-17 05:05:50 --> No URI present. Default controller set.
INFO - 2021-06-17 05:05:50 --> Router Class Initialized
INFO - 2021-06-17 05:05:50 --> Output Class Initialized
INFO - 2021-06-17 05:05:50 --> Security Class Initialized
DEBUG - 2021-06-17 05:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:05:50 --> Input Class Initialized
INFO - 2021-06-17 05:05:50 --> Language Class Initialized
INFO - 2021-06-17 05:05:50 --> Language Class Initialized
INFO - 2021-06-17 05:05:50 --> Config Class Initialized
INFO - 2021-06-17 05:05:50 --> Loader Class Initialized
INFO - 2021-06-17 05:05:50 --> Helper loaded: url_helper
INFO - 2021-06-17 05:05:50 --> Helper loaded: file_helper
INFO - 2021-06-17 05:05:50 --> Helper loaded: form_helper
INFO - 2021-06-17 05:05:50 --> Helper loaded: my_helper
INFO - 2021-06-17 05:05:50 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:05:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:05:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:05:50 --> Controller Class Initialized
INFO - 2021-06-17 05:05:50 --> Config Class Initialized
INFO - 2021-06-17 05:05:50 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:05:50 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:05:50 --> Utf8 Class Initialized
INFO - 2021-06-17 05:05:50 --> URI Class Initialized
INFO - 2021-06-17 05:05:50 --> Router Class Initialized
INFO - 2021-06-17 05:05:50 --> Output Class Initialized
INFO - 2021-06-17 05:05:50 --> Security Class Initialized
DEBUG - 2021-06-17 05:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:05:50 --> Input Class Initialized
INFO - 2021-06-17 05:05:50 --> Language Class Initialized
INFO - 2021-06-17 05:05:50 --> Language Class Initialized
INFO - 2021-06-17 05:05:50 --> Config Class Initialized
INFO - 2021-06-17 05:05:50 --> Loader Class Initialized
INFO - 2021-06-17 05:05:50 --> Helper loaded: url_helper
INFO - 2021-06-17 05:05:50 --> Helper loaded: file_helper
INFO - 2021-06-17 05:05:50 --> Helper loaded: form_helper
INFO - 2021-06-17 05:05:50 --> Helper loaded: my_helper
INFO - 2021-06-17 05:05:50 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:05:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:05:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:05:50 --> Controller Class Initialized
DEBUG - 2021-06-17 05:05:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-17 05:05:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 05:05:50 --> Final output sent to browser
DEBUG - 2021-06-17 05:05:50 --> Total execution time: 0.0442
INFO - 2021-06-17 05:06:13 --> Config Class Initialized
INFO - 2021-06-17 05:06:14 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:06:14 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:06:14 --> Utf8 Class Initialized
INFO - 2021-06-17 05:06:14 --> URI Class Initialized
INFO - 2021-06-17 05:06:14 --> Router Class Initialized
INFO - 2021-06-17 05:06:14 --> Output Class Initialized
INFO - 2021-06-17 05:06:14 --> Security Class Initialized
DEBUG - 2021-06-17 05:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:06:14 --> Input Class Initialized
INFO - 2021-06-17 05:06:14 --> Language Class Initialized
INFO - 2021-06-17 05:06:14 --> Language Class Initialized
INFO - 2021-06-17 05:06:14 --> Config Class Initialized
INFO - 2021-06-17 05:06:14 --> Loader Class Initialized
INFO - 2021-06-17 05:06:14 --> Helper loaded: url_helper
INFO - 2021-06-17 05:06:14 --> Helper loaded: file_helper
INFO - 2021-06-17 05:06:14 --> Helper loaded: form_helper
INFO - 2021-06-17 05:06:14 --> Helper loaded: my_helper
INFO - 2021-06-17 05:06:14 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:06:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:06:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:06:14 --> Controller Class Initialized
INFO - 2021-06-17 05:06:14 --> Final output sent to browser
DEBUG - 2021-06-17 05:06:14 --> Total execution time: 0.0526
INFO - 2021-06-17 05:06:34 --> Config Class Initialized
INFO - 2021-06-17 05:06:34 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:06:34 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:06:34 --> Utf8 Class Initialized
INFO - 2021-06-17 05:06:34 --> URI Class Initialized
INFO - 2021-06-17 05:06:34 --> Router Class Initialized
INFO - 2021-06-17 05:06:34 --> Output Class Initialized
INFO - 2021-06-17 05:06:34 --> Security Class Initialized
DEBUG - 2021-06-17 05:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:06:34 --> Input Class Initialized
INFO - 2021-06-17 05:06:34 --> Language Class Initialized
INFO - 2021-06-17 05:06:34 --> Language Class Initialized
INFO - 2021-06-17 05:06:34 --> Config Class Initialized
INFO - 2021-06-17 05:06:34 --> Loader Class Initialized
INFO - 2021-06-17 05:06:34 --> Helper loaded: url_helper
INFO - 2021-06-17 05:06:34 --> Helper loaded: file_helper
INFO - 2021-06-17 05:06:34 --> Helper loaded: form_helper
INFO - 2021-06-17 05:06:34 --> Helper loaded: my_helper
INFO - 2021-06-17 05:06:34 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:06:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:06:34 --> Controller Class Initialized
INFO - 2021-06-17 05:06:34 --> Helper loaded: cookie_helper
INFO - 2021-06-17 05:06:34 --> Final output sent to browser
DEBUG - 2021-06-17 05:06:34 --> Total execution time: 0.0628
INFO - 2021-06-17 05:06:37 --> Config Class Initialized
INFO - 2021-06-17 05:06:37 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:06:37 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:06:37 --> Utf8 Class Initialized
INFO - 2021-06-17 05:06:37 --> URI Class Initialized
INFO - 2021-06-17 05:06:37 --> Router Class Initialized
INFO - 2021-06-17 05:06:37 --> Output Class Initialized
INFO - 2021-06-17 05:06:37 --> Security Class Initialized
DEBUG - 2021-06-17 05:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:06:37 --> Input Class Initialized
INFO - 2021-06-17 05:06:37 --> Language Class Initialized
INFO - 2021-06-17 05:06:37 --> Language Class Initialized
INFO - 2021-06-17 05:06:37 --> Config Class Initialized
INFO - 2021-06-17 05:06:37 --> Loader Class Initialized
INFO - 2021-06-17 05:06:37 --> Helper loaded: url_helper
INFO - 2021-06-17 05:06:37 --> Helper loaded: file_helper
INFO - 2021-06-17 05:06:37 --> Helper loaded: form_helper
INFO - 2021-06-17 05:06:37 --> Helper loaded: my_helper
INFO - 2021-06-17 05:06:37 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:06:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:06:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:06:37 --> Controller Class Initialized
DEBUG - 2021-06-17 05:06:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-17 05:06:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 05:06:37 --> Final output sent to browser
DEBUG - 2021-06-17 05:06:37 --> Total execution time: 0.2212
INFO - 2021-06-17 05:07:20 --> Config Class Initialized
INFO - 2021-06-17 05:07:20 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:07:20 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:07:20 --> Utf8 Class Initialized
INFO - 2021-06-17 05:07:20 --> URI Class Initialized
INFO - 2021-06-17 05:07:20 --> Router Class Initialized
INFO - 2021-06-17 05:07:20 --> Output Class Initialized
INFO - 2021-06-17 05:07:20 --> Security Class Initialized
DEBUG - 2021-06-17 05:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:07:20 --> Input Class Initialized
INFO - 2021-06-17 05:07:20 --> Language Class Initialized
INFO - 2021-06-17 05:07:21 --> Language Class Initialized
INFO - 2021-06-17 05:07:21 --> Config Class Initialized
INFO - 2021-06-17 05:07:21 --> Loader Class Initialized
INFO - 2021-06-17 05:07:21 --> Helper loaded: url_helper
INFO - 2021-06-17 05:07:21 --> Helper loaded: file_helper
INFO - 2021-06-17 05:07:21 --> Helper loaded: form_helper
INFO - 2021-06-17 05:07:21 --> Helper loaded: my_helper
INFO - 2021-06-17 05:07:21 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:07:21 --> Controller Class Initialized
DEBUG - 2021-06-17 05:07:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-17 05:07:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 05:07:21 --> Final output sent to browser
DEBUG - 2021-06-17 05:07:21 --> Total execution time: 0.0900
INFO - 2021-06-17 05:07:27 --> Config Class Initialized
INFO - 2021-06-17 05:07:27 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:07:27 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:07:27 --> Utf8 Class Initialized
INFO - 2021-06-17 05:07:27 --> URI Class Initialized
INFO - 2021-06-17 05:07:27 --> Router Class Initialized
INFO - 2021-06-17 05:07:27 --> Output Class Initialized
INFO - 2021-06-17 05:07:27 --> Security Class Initialized
DEBUG - 2021-06-17 05:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:07:27 --> Input Class Initialized
INFO - 2021-06-17 05:07:27 --> Language Class Initialized
INFO - 2021-06-17 05:07:27 --> Language Class Initialized
INFO - 2021-06-17 05:07:27 --> Config Class Initialized
INFO - 2021-06-17 05:07:27 --> Loader Class Initialized
INFO - 2021-06-17 05:07:28 --> Helper loaded: url_helper
INFO - 2021-06-17 05:07:28 --> Helper loaded: file_helper
INFO - 2021-06-17 05:07:28 --> Helper loaded: form_helper
INFO - 2021-06-17 05:07:28 --> Helper loaded: my_helper
INFO - 2021-06-17 05:07:28 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:07:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:07:28 --> Controller Class Initialized
DEBUG - 2021-06-17 05:07:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-17 05:07:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 05:07:28 --> Final output sent to browser
DEBUG - 2021-06-17 05:07:28 --> Total execution time: 0.1073
INFO - 2021-06-17 05:07:28 --> Config Class Initialized
INFO - 2021-06-17 05:07:28 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:07:28 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:07:28 --> Utf8 Class Initialized
INFO - 2021-06-17 05:07:28 --> URI Class Initialized
INFO - 2021-06-17 05:07:28 --> Router Class Initialized
INFO - 2021-06-17 05:07:28 --> Output Class Initialized
INFO - 2021-06-17 05:07:28 --> Security Class Initialized
DEBUG - 2021-06-17 05:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:07:28 --> Input Class Initialized
INFO - 2021-06-17 05:07:28 --> Language Class Initialized
INFO - 2021-06-17 05:07:28 --> Language Class Initialized
INFO - 2021-06-17 05:07:28 --> Config Class Initialized
INFO - 2021-06-17 05:07:28 --> Loader Class Initialized
INFO - 2021-06-17 05:07:28 --> Helper loaded: url_helper
INFO - 2021-06-17 05:07:28 --> Helper loaded: file_helper
INFO - 2021-06-17 05:07:28 --> Helper loaded: form_helper
INFO - 2021-06-17 05:07:28 --> Helper loaded: my_helper
INFO - 2021-06-17 05:07:28 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:07:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:07:28 --> Controller Class Initialized
INFO - 2021-06-17 05:23:16 --> Config Class Initialized
INFO - 2021-06-17 05:23:16 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:23:16 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:23:16 --> Utf8 Class Initialized
INFO - 2021-06-17 05:23:16 --> URI Class Initialized
INFO - 2021-06-17 05:23:16 --> Router Class Initialized
INFO - 2021-06-17 05:23:16 --> Output Class Initialized
INFO - 2021-06-17 05:23:16 --> Security Class Initialized
DEBUG - 2021-06-17 05:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:23:16 --> Input Class Initialized
INFO - 2021-06-17 05:23:16 --> Language Class Initialized
INFO - 2021-06-17 05:23:16 --> Language Class Initialized
INFO - 2021-06-17 05:23:16 --> Config Class Initialized
INFO - 2021-06-17 05:23:16 --> Loader Class Initialized
INFO - 2021-06-17 05:23:16 --> Helper loaded: url_helper
INFO - 2021-06-17 05:23:16 --> Helper loaded: file_helper
INFO - 2021-06-17 05:23:16 --> Helper loaded: form_helper
INFO - 2021-06-17 05:23:16 --> Helper loaded: my_helper
INFO - 2021-06-17 05:23:16 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:23:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:23:16 --> Controller Class Initialized
INFO - 2021-06-17 05:23:16 --> Final output sent to browser
DEBUG - 2021-06-17 05:23:16 --> Total execution time: 0.0640
INFO - 2021-06-17 05:23:31 --> Config Class Initialized
INFO - 2021-06-17 05:23:31 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:23:31 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:23:31 --> Utf8 Class Initialized
INFO - 2021-06-17 05:23:31 --> URI Class Initialized
INFO - 2021-06-17 05:23:31 --> Router Class Initialized
INFO - 2021-06-17 05:23:31 --> Output Class Initialized
INFO - 2021-06-17 05:23:31 --> Security Class Initialized
DEBUG - 2021-06-17 05:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:23:31 --> Input Class Initialized
INFO - 2021-06-17 05:23:31 --> Language Class Initialized
INFO - 2021-06-17 05:23:31 --> Language Class Initialized
INFO - 2021-06-17 05:23:31 --> Config Class Initialized
INFO - 2021-06-17 05:23:31 --> Loader Class Initialized
INFO - 2021-06-17 05:23:31 --> Helper loaded: url_helper
INFO - 2021-06-17 05:23:31 --> Helper loaded: file_helper
INFO - 2021-06-17 05:23:31 --> Helper loaded: form_helper
INFO - 2021-06-17 05:23:31 --> Helper loaded: my_helper
INFO - 2021-06-17 05:23:31 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:23:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:23:31 --> Controller Class Initialized
INFO - 2021-06-17 05:23:31 --> Final output sent to browser
DEBUG - 2021-06-17 05:23:31 --> Total execution time: 0.0508
INFO - 2021-06-17 05:23:31 --> Config Class Initialized
INFO - 2021-06-17 05:23:31 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:23:31 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:23:31 --> Utf8 Class Initialized
INFO - 2021-06-17 05:23:31 --> URI Class Initialized
INFO - 2021-06-17 05:23:31 --> Router Class Initialized
INFO - 2021-06-17 05:23:31 --> Output Class Initialized
INFO - 2021-06-17 05:23:31 --> Security Class Initialized
DEBUG - 2021-06-17 05:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:23:31 --> Input Class Initialized
INFO - 2021-06-17 05:23:31 --> Language Class Initialized
INFO - 2021-06-17 05:23:31 --> Language Class Initialized
INFO - 2021-06-17 05:23:31 --> Config Class Initialized
INFO - 2021-06-17 05:23:31 --> Loader Class Initialized
INFO - 2021-06-17 05:23:31 --> Helper loaded: url_helper
INFO - 2021-06-17 05:23:31 --> Helper loaded: file_helper
INFO - 2021-06-17 05:23:31 --> Helper loaded: form_helper
INFO - 2021-06-17 05:23:31 --> Helper loaded: my_helper
INFO - 2021-06-17 05:23:31 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:23:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:23:31 --> Controller Class Initialized
INFO - 2021-06-17 05:23:36 --> Config Class Initialized
INFO - 2021-06-17 05:23:36 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:23:36 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:23:36 --> Utf8 Class Initialized
INFO - 2021-06-17 05:23:36 --> URI Class Initialized
INFO - 2021-06-17 05:23:36 --> Router Class Initialized
INFO - 2021-06-17 05:23:36 --> Output Class Initialized
INFO - 2021-06-17 05:23:36 --> Security Class Initialized
DEBUG - 2021-06-17 05:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:23:36 --> Input Class Initialized
INFO - 2021-06-17 05:23:36 --> Language Class Initialized
INFO - 2021-06-17 05:23:36 --> Language Class Initialized
INFO - 2021-06-17 05:23:36 --> Config Class Initialized
INFO - 2021-06-17 05:23:36 --> Loader Class Initialized
INFO - 2021-06-17 05:23:36 --> Helper loaded: url_helper
INFO - 2021-06-17 05:23:36 --> Helper loaded: file_helper
INFO - 2021-06-17 05:23:36 --> Helper loaded: form_helper
INFO - 2021-06-17 05:23:36 --> Helper loaded: my_helper
INFO - 2021-06-17 05:23:36 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:23:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:23:36 --> Controller Class Initialized
INFO - 2021-06-17 05:23:36 --> Final output sent to browser
DEBUG - 2021-06-17 05:23:36 --> Total execution time: 0.0495
INFO - 2021-06-17 05:25:11 --> Config Class Initialized
INFO - 2021-06-17 05:25:11 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:25:11 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:25:11 --> Utf8 Class Initialized
INFO - 2021-06-17 05:25:11 --> URI Class Initialized
INFO - 2021-06-17 05:25:11 --> Router Class Initialized
INFO - 2021-06-17 05:25:11 --> Output Class Initialized
INFO - 2021-06-17 05:25:11 --> Security Class Initialized
DEBUG - 2021-06-17 05:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:25:11 --> Input Class Initialized
INFO - 2021-06-17 05:25:11 --> Language Class Initialized
INFO - 2021-06-17 05:25:11 --> Language Class Initialized
INFO - 2021-06-17 05:25:11 --> Config Class Initialized
INFO - 2021-06-17 05:25:11 --> Loader Class Initialized
INFO - 2021-06-17 05:25:11 --> Helper loaded: url_helper
INFO - 2021-06-17 05:25:11 --> Helper loaded: file_helper
INFO - 2021-06-17 05:25:11 --> Helper loaded: form_helper
INFO - 2021-06-17 05:25:11 --> Helper loaded: my_helper
INFO - 2021-06-17 05:25:11 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:25:11 --> Controller Class Initialized
INFO - 2021-06-17 05:25:11 --> Final output sent to browser
DEBUG - 2021-06-17 05:25:11 --> Total execution time: 0.1201
INFO - 2021-06-17 05:25:11 --> Config Class Initialized
INFO - 2021-06-17 05:25:11 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:25:11 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:25:11 --> Utf8 Class Initialized
INFO - 2021-06-17 05:25:11 --> URI Class Initialized
INFO - 2021-06-17 05:25:11 --> Router Class Initialized
INFO - 2021-06-17 05:25:11 --> Output Class Initialized
INFO - 2021-06-17 05:25:11 --> Security Class Initialized
DEBUG - 2021-06-17 05:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:25:11 --> Input Class Initialized
INFO - 2021-06-17 05:25:11 --> Language Class Initialized
INFO - 2021-06-17 05:25:11 --> Language Class Initialized
INFO - 2021-06-17 05:25:11 --> Config Class Initialized
INFO - 2021-06-17 05:25:11 --> Loader Class Initialized
INFO - 2021-06-17 05:25:11 --> Helper loaded: url_helper
INFO - 2021-06-17 05:25:11 --> Helper loaded: file_helper
INFO - 2021-06-17 05:25:11 --> Helper loaded: form_helper
INFO - 2021-06-17 05:25:11 --> Helper loaded: my_helper
INFO - 2021-06-17 05:25:11 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:25:11 --> Controller Class Initialized
INFO - 2021-06-17 05:25:13 --> Config Class Initialized
INFO - 2021-06-17 05:25:13 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:25:13 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:25:13 --> Utf8 Class Initialized
INFO - 2021-06-17 05:25:13 --> URI Class Initialized
INFO - 2021-06-17 05:25:13 --> Router Class Initialized
INFO - 2021-06-17 05:25:13 --> Output Class Initialized
INFO - 2021-06-17 05:25:13 --> Security Class Initialized
DEBUG - 2021-06-17 05:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:25:13 --> Input Class Initialized
INFO - 2021-06-17 05:25:13 --> Language Class Initialized
INFO - 2021-06-17 05:25:13 --> Language Class Initialized
INFO - 2021-06-17 05:25:13 --> Config Class Initialized
INFO - 2021-06-17 05:25:13 --> Loader Class Initialized
INFO - 2021-06-17 05:25:13 --> Helper loaded: url_helper
INFO - 2021-06-17 05:25:13 --> Helper loaded: file_helper
INFO - 2021-06-17 05:25:13 --> Helper loaded: form_helper
INFO - 2021-06-17 05:25:13 --> Helper loaded: my_helper
INFO - 2021-06-17 05:25:14 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:25:14 --> Controller Class Initialized
INFO - 2021-06-17 05:25:14 --> Final output sent to browser
DEBUG - 2021-06-17 05:25:14 --> Total execution time: 0.0486
INFO - 2021-06-17 05:25:51 --> Config Class Initialized
INFO - 2021-06-17 05:25:51 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:25:51 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:25:51 --> Utf8 Class Initialized
INFO - 2021-06-17 05:25:51 --> URI Class Initialized
INFO - 2021-06-17 05:25:51 --> Router Class Initialized
INFO - 2021-06-17 05:25:51 --> Output Class Initialized
INFO - 2021-06-17 05:25:51 --> Security Class Initialized
DEBUG - 2021-06-17 05:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:25:51 --> Input Class Initialized
INFO - 2021-06-17 05:25:51 --> Language Class Initialized
INFO - 2021-06-17 05:25:51 --> Language Class Initialized
INFO - 2021-06-17 05:25:51 --> Config Class Initialized
INFO - 2021-06-17 05:25:51 --> Loader Class Initialized
INFO - 2021-06-17 05:25:51 --> Helper loaded: url_helper
INFO - 2021-06-17 05:25:51 --> Helper loaded: file_helper
INFO - 2021-06-17 05:25:51 --> Helper loaded: form_helper
INFO - 2021-06-17 05:25:51 --> Helper loaded: my_helper
INFO - 2021-06-17 05:25:51 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:25:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:25:51 --> Controller Class Initialized
INFO - 2021-06-17 05:25:51 --> Final output sent to browser
DEBUG - 2021-06-17 05:25:51 --> Total execution time: 0.0502
INFO - 2021-06-17 05:25:51 --> Config Class Initialized
INFO - 2021-06-17 05:25:51 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:25:51 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:25:51 --> Utf8 Class Initialized
INFO - 2021-06-17 05:25:51 --> URI Class Initialized
INFO - 2021-06-17 05:25:51 --> Router Class Initialized
INFO - 2021-06-17 05:25:51 --> Output Class Initialized
INFO - 2021-06-17 05:25:51 --> Security Class Initialized
DEBUG - 2021-06-17 05:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:25:51 --> Input Class Initialized
INFO - 2021-06-17 05:25:51 --> Language Class Initialized
INFO - 2021-06-17 05:25:51 --> Language Class Initialized
INFO - 2021-06-17 05:25:51 --> Config Class Initialized
INFO - 2021-06-17 05:25:51 --> Loader Class Initialized
INFO - 2021-06-17 05:25:51 --> Helper loaded: url_helper
INFO - 2021-06-17 05:25:51 --> Helper loaded: file_helper
INFO - 2021-06-17 05:25:51 --> Helper loaded: form_helper
INFO - 2021-06-17 05:25:51 --> Helper loaded: my_helper
INFO - 2021-06-17 05:25:51 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:25:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:25:51 --> Controller Class Initialized
INFO - 2021-06-17 05:25:53 --> Config Class Initialized
INFO - 2021-06-17 05:25:53 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:25:53 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:25:53 --> Utf8 Class Initialized
INFO - 2021-06-17 05:25:53 --> URI Class Initialized
INFO - 2021-06-17 05:25:53 --> Router Class Initialized
INFO - 2021-06-17 05:25:53 --> Output Class Initialized
INFO - 2021-06-17 05:25:53 --> Security Class Initialized
DEBUG - 2021-06-17 05:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:25:53 --> Input Class Initialized
INFO - 2021-06-17 05:25:53 --> Language Class Initialized
INFO - 2021-06-17 05:25:53 --> Language Class Initialized
INFO - 2021-06-17 05:25:53 --> Config Class Initialized
INFO - 2021-06-17 05:25:53 --> Loader Class Initialized
INFO - 2021-06-17 05:25:53 --> Helper loaded: url_helper
INFO - 2021-06-17 05:25:53 --> Helper loaded: file_helper
INFO - 2021-06-17 05:25:53 --> Helper loaded: form_helper
INFO - 2021-06-17 05:25:53 --> Helper loaded: my_helper
INFO - 2021-06-17 05:25:53 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:25:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:25:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:25:53 --> Controller Class Initialized
INFO - 2021-06-17 05:25:53 --> Final output sent to browser
DEBUG - 2021-06-17 05:25:53 --> Total execution time: 0.0477
INFO - 2021-06-17 05:26:45 --> Config Class Initialized
INFO - 2021-06-17 05:26:45 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:26:45 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:26:45 --> Utf8 Class Initialized
INFO - 2021-06-17 05:26:45 --> URI Class Initialized
INFO - 2021-06-17 05:26:45 --> Router Class Initialized
INFO - 2021-06-17 05:26:45 --> Output Class Initialized
INFO - 2021-06-17 05:26:45 --> Security Class Initialized
DEBUG - 2021-06-17 05:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:26:45 --> Input Class Initialized
INFO - 2021-06-17 05:26:45 --> Language Class Initialized
INFO - 2021-06-17 05:26:45 --> Language Class Initialized
INFO - 2021-06-17 05:26:45 --> Config Class Initialized
INFO - 2021-06-17 05:26:45 --> Loader Class Initialized
INFO - 2021-06-17 05:26:45 --> Helper loaded: url_helper
INFO - 2021-06-17 05:26:45 --> Helper loaded: file_helper
INFO - 2021-06-17 05:26:45 --> Helper loaded: form_helper
INFO - 2021-06-17 05:26:45 --> Helper loaded: my_helper
INFO - 2021-06-17 05:26:45 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:26:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:26:45 --> Controller Class Initialized
INFO - 2021-06-17 05:26:45 --> Final output sent to browser
DEBUG - 2021-06-17 05:26:45 --> Total execution time: 0.0408
INFO - 2021-06-17 05:26:45 --> Config Class Initialized
INFO - 2021-06-17 05:26:45 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:26:45 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:26:45 --> Utf8 Class Initialized
INFO - 2021-06-17 05:26:45 --> URI Class Initialized
INFO - 2021-06-17 05:26:45 --> Router Class Initialized
INFO - 2021-06-17 05:26:45 --> Output Class Initialized
INFO - 2021-06-17 05:26:45 --> Security Class Initialized
DEBUG - 2021-06-17 05:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:26:45 --> Input Class Initialized
INFO - 2021-06-17 05:26:45 --> Language Class Initialized
INFO - 2021-06-17 05:26:45 --> Language Class Initialized
INFO - 2021-06-17 05:26:45 --> Config Class Initialized
INFO - 2021-06-17 05:26:45 --> Loader Class Initialized
INFO - 2021-06-17 05:26:45 --> Helper loaded: url_helper
INFO - 2021-06-17 05:26:45 --> Helper loaded: file_helper
INFO - 2021-06-17 05:26:45 --> Helper loaded: form_helper
INFO - 2021-06-17 05:26:45 --> Helper loaded: my_helper
INFO - 2021-06-17 05:26:45 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:26:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:26:46 --> Controller Class Initialized
INFO - 2021-06-17 05:26:49 --> Config Class Initialized
INFO - 2021-06-17 05:26:49 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:26:49 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:26:49 --> Utf8 Class Initialized
INFO - 2021-06-17 05:26:49 --> URI Class Initialized
INFO - 2021-06-17 05:26:49 --> Router Class Initialized
INFO - 2021-06-17 05:26:49 --> Output Class Initialized
INFO - 2021-06-17 05:26:49 --> Security Class Initialized
DEBUG - 2021-06-17 05:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:26:49 --> Input Class Initialized
INFO - 2021-06-17 05:26:49 --> Language Class Initialized
INFO - 2021-06-17 05:26:49 --> Language Class Initialized
INFO - 2021-06-17 05:26:49 --> Config Class Initialized
INFO - 2021-06-17 05:26:49 --> Loader Class Initialized
INFO - 2021-06-17 05:26:49 --> Helper loaded: url_helper
INFO - 2021-06-17 05:26:49 --> Helper loaded: file_helper
INFO - 2021-06-17 05:26:49 --> Helper loaded: form_helper
INFO - 2021-06-17 05:26:49 --> Helper loaded: my_helper
INFO - 2021-06-17 05:26:49 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:26:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:26:49 --> Controller Class Initialized
INFO - 2021-06-17 05:26:49 --> Final output sent to browser
DEBUG - 2021-06-17 05:26:49 --> Total execution time: 0.0495
INFO - 2021-06-17 05:27:23 --> Config Class Initialized
INFO - 2021-06-17 05:27:23 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:27:23 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:27:23 --> Utf8 Class Initialized
INFO - 2021-06-17 05:27:23 --> URI Class Initialized
INFO - 2021-06-17 05:27:23 --> Router Class Initialized
INFO - 2021-06-17 05:27:23 --> Output Class Initialized
INFO - 2021-06-17 05:27:23 --> Security Class Initialized
DEBUG - 2021-06-17 05:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:27:23 --> Input Class Initialized
INFO - 2021-06-17 05:27:23 --> Language Class Initialized
INFO - 2021-06-17 05:27:23 --> Language Class Initialized
INFO - 2021-06-17 05:27:23 --> Config Class Initialized
INFO - 2021-06-17 05:27:23 --> Loader Class Initialized
INFO - 2021-06-17 05:27:23 --> Helper loaded: url_helper
INFO - 2021-06-17 05:27:23 --> Helper loaded: file_helper
INFO - 2021-06-17 05:27:23 --> Helper loaded: form_helper
INFO - 2021-06-17 05:27:23 --> Helper loaded: my_helper
INFO - 2021-06-17 05:27:23 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:27:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:27:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:27:23 --> Controller Class Initialized
INFO - 2021-06-17 05:27:23 --> Final output sent to browser
DEBUG - 2021-06-17 05:27:23 --> Total execution time: 0.0630
INFO - 2021-06-17 05:27:23 --> Config Class Initialized
INFO - 2021-06-17 05:27:23 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:27:23 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:27:23 --> Utf8 Class Initialized
INFO - 2021-06-17 05:27:23 --> URI Class Initialized
INFO - 2021-06-17 05:27:23 --> Router Class Initialized
INFO - 2021-06-17 05:27:23 --> Output Class Initialized
INFO - 2021-06-17 05:27:23 --> Security Class Initialized
DEBUG - 2021-06-17 05:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:27:23 --> Input Class Initialized
INFO - 2021-06-17 05:27:23 --> Language Class Initialized
INFO - 2021-06-17 05:27:23 --> Language Class Initialized
INFO - 2021-06-17 05:27:23 --> Config Class Initialized
INFO - 2021-06-17 05:27:23 --> Loader Class Initialized
INFO - 2021-06-17 05:27:23 --> Helper loaded: url_helper
INFO - 2021-06-17 05:27:23 --> Helper loaded: file_helper
INFO - 2021-06-17 05:27:23 --> Helper loaded: form_helper
INFO - 2021-06-17 05:27:23 --> Helper loaded: my_helper
INFO - 2021-06-17 05:27:23 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:27:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:27:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:27:23 --> Controller Class Initialized
INFO - 2021-06-17 05:27:27 --> Config Class Initialized
INFO - 2021-06-17 05:27:27 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:27:27 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:27:27 --> Utf8 Class Initialized
INFO - 2021-06-17 05:27:27 --> URI Class Initialized
INFO - 2021-06-17 05:27:27 --> Router Class Initialized
INFO - 2021-06-17 05:27:27 --> Output Class Initialized
INFO - 2021-06-17 05:27:27 --> Security Class Initialized
DEBUG - 2021-06-17 05:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:27:27 --> Input Class Initialized
INFO - 2021-06-17 05:27:27 --> Language Class Initialized
INFO - 2021-06-17 05:27:27 --> Language Class Initialized
INFO - 2021-06-17 05:27:27 --> Config Class Initialized
INFO - 2021-06-17 05:27:27 --> Loader Class Initialized
INFO - 2021-06-17 05:27:27 --> Helper loaded: url_helper
INFO - 2021-06-17 05:27:27 --> Helper loaded: file_helper
INFO - 2021-06-17 05:27:27 --> Helper loaded: form_helper
INFO - 2021-06-17 05:27:27 --> Helper loaded: my_helper
INFO - 2021-06-17 05:27:27 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:27:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:27:27 --> Controller Class Initialized
INFO - 2021-06-17 05:27:27 --> Final output sent to browser
DEBUG - 2021-06-17 05:27:27 --> Total execution time: 0.0484
INFO - 2021-06-17 05:27:56 --> Config Class Initialized
INFO - 2021-06-17 05:27:56 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:27:56 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:27:56 --> Utf8 Class Initialized
INFO - 2021-06-17 05:27:56 --> URI Class Initialized
INFO - 2021-06-17 05:27:56 --> Router Class Initialized
INFO - 2021-06-17 05:27:56 --> Output Class Initialized
INFO - 2021-06-17 05:27:56 --> Security Class Initialized
DEBUG - 2021-06-17 05:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:27:56 --> Input Class Initialized
INFO - 2021-06-17 05:27:56 --> Language Class Initialized
INFO - 2021-06-17 05:27:56 --> Language Class Initialized
INFO - 2021-06-17 05:27:56 --> Config Class Initialized
INFO - 2021-06-17 05:27:56 --> Loader Class Initialized
INFO - 2021-06-17 05:27:56 --> Helper loaded: url_helper
INFO - 2021-06-17 05:27:56 --> Helper loaded: file_helper
INFO - 2021-06-17 05:27:56 --> Helper loaded: form_helper
INFO - 2021-06-17 05:27:56 --> Helper loaded: my_helper
INFO - 2021-06-17 05:27:56 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:27:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:27:56 --> Controller Class Initialized
INFO - 2021-06-17 05:27:56 --> Final output sent to browser
DEBUG - 2021-06-17 05:27:56 --> Total execution time: 0.0503
INFO - 2021-06-17 05:27:56 --> Config Class Initialized
INFO - 2021-06-17 05:27:56 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:27:56 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:27:56 --> Utf8 Class Initialized
INFO - 2021-06-17 05:27:56 --> URI Class Initialized
INFO - 2021-06-17 05:27:56 --> Router Class Initialized
INFO - 2021-06-17 05:27:56 --> Output Class Initialized
INFO - 2021-06-17 05:27:56 --> Security Class Initialized
DEBUG - 2021-06-17 05:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:27:56 --> Input Class Initialized
INFO - 2021-06-17 05:27:56 --> Language Class Initialized
INFO - 2021-06-17 05:27:56 --> Language Class Initialized
INFO - 2021-06-17 05:27:56 --> Config Class Initialized
INFO - 2021-06-17 05:27:56 --> Loader Class Initialized
INFO - 2021-06-17 05:27:56 --> Helper loaded: url_helper
INFO - 2021-06-17 05:27:56 --> Helper loaded: file_helper
INFO - 2021-06-17 05:27:56 --> Helper loaded: form_helper
INFO - 2021-06-17 05:27:56 --> Helper loaded: my_helper
INFO - 2021-06-17 05:27:56 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:27:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:27:56 --> Controller Class Initialized
INFO - 2021-06-17 05:27:59 --> Config Class Initialized
INFO - 2021-06-17 05:27:59 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:27:59 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:27:59 --> Utf8 Class Initialized
INFO - 2021-06-17 05:27:59 --> URI Class Initialized
INFO - 2021-06-17 05:27:59 --> Router Class Initialized
INFO - 2021-06-17 05:27:59 --> Output Class Initialized
INFO - 2021-06-17 05:27:59 --> Security Class Initialized
DEBUG - 2021-06-17 05:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:27:59 --> Input Class Initialized
INFO - 2021-06-17 05:27:59 --> Language Class Initialized
INFO - 2021-06-17 05:27:59 --> Language Class Initialized
INFO - 2021-06-17 05:27:59 --> Config Class Initialized
INFO - 2021-06-17 05:27:59 --> Loader Class Initialized
INFO - 2021-06-17 05:27:59 --> Helper loaded: url_helper
INFO - 2021-06-17 05:27:59 --> Helper loaded: file_helper
INFO - 2021-06-17 05:27:59 --> Helper loaded: form_helper
INFO - 2021-06-17 05:27:59 --> Helper loaded: my_helper
INFO - 2021-06-17 05:27:59 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:27:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:27:59 --> Controller Class Initialized
INFO - 2021-06-17 05:27:59 --> Final output sent to browser
DEBUG - 2021-06-17 05:27:59 --> Total execution time: 0.0486
INFO - 2021-06-17 05:28:36 --> Config Class Initialized
INFO - 2021-06-17 05:28:36 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:28:36 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:28:36 --> Utf8 Class Initialized
INFO - 2021-06-17 05:28:36 --> URI Class Initialized
INFO - 2021-06-17 05:28:36 --> Router Class Initialized
INFO - 2021-06-17 05:28:36 --> Output Class Initialized
INFO - 2021-06-17 05:28:36 --> Security Class Initialized
DEBUG - 2021-06-17 05:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:28:36 --> Input Class Initialized
INFO - 2021-06-17 05:28:36 --> Language Class Initialized
INFO - 2021-06-17 05:28:36 --> Language Class Initialized
INFO - 2021-06-17 05:28:36 --> Config Class Initialized
INFO - 2021-06-17 05:28:36 --> Loader Class Initialized
INFO - 2021-06-17 05:28:36 --> Helper loaded: url_helper
INFO - 2021-06-17 05:28:36 --> Helper loaded: file_helper
INFO - 2021-06-17 05:28:36 --> Helper loaded: form_helper
INFO - 2021-06-17 05:28:36 --> Helper loaded: my_helper
INFO - 2021-06-17 05:28:36 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:28:36 --> Controller Class Initialized
INFO - 2021-06-17 05:28:36 --> Final output sent to browser
DEBUG - 2021-06-17 05:28:36 --> Total execution time: 0.0408
INFO - 2021-06-17 05:28:36 --> Config Class Initialized
INFO - 2021-06-17 05:28:36 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:28:36 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:28:36 --> Utf8 Class Initialized
INFO - 2021-06-17 05:28:36 --> URI Class Initialized
INFO - 2021-06-17 05:28:36 --> Router Class Initialized
INFO - 2021-06-17 05:28:36 --> Output Class Initialized
INFO - 2021-06-17 05:28:36 --> Security Class Initialized
DEBUG - 2021-06-17 05:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:28:36 --> Input Class Initialized
INFO - 2021-06-17 05:28:36 --> Language Class Initialized
INFO - 2021-06-17 05:28:36 --> Language Class Initialized
INFO - 2021-06-17 05:28:36 --> Config Class Initialized
INFO - 2021-06-17 05:28:36 --> Loader Class Initialized
INFO - 2021-06-17 05:28:36 --> Helper loaded: url_helper
INFO - 2021-06-17 05:28:36 --> Helper loaded: file_helper
INFO - 2021-06-17 05:28:36 --> Helper loaded: form_helper
INFO - 2021-06-17 05:28:36 --> Helper loaded: my_helper
INFO - 2021-06-17 05:28:36 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:28:36 --> Controller Class Initialized
INFO - 2021-06-17 05:29:43 --> Config Class Initialized
INFO - 2021-06-17 05:29:43 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:29:43 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:29:43 --> Utf8 Class Initialized
INFO - 2021-06-17 05:29:43 --> URI Class Initialized
INFO - 2021-06-17 05:29:43 --> Router Class Initialized
INFO - 2021-06-17 05:29:43 --> Output Class Initialized
INFO - 2021-06-17 05:29:43 --> Security Class Initialized
DEBUG - 2021-06-17 05:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:29:43 --> Input Class Initialized
INFO - 2021-06-17 05:29:43 --> Language Class Initialized
INFO - 2021-06-17 05:29:43 --> Language Class Initialized
INFO - 2021-06-17 05:29:43 --> Config Class Initialized
INFO - 2021-06-17 05:29:43 --> Loader Class Initialized
INFO - 2021-06-17 05:29:43 --> Helper loaded: url_helper
INFO - 2021-06-17 05:29:43 --> Helper loaded: file_helper
INFO - 2021-06-17 05:29:43 --> Helper loaded: form_helper
INFO - 2021-06-17 05:29:43 --> Helper loaded: my_helper
INFO - 2021-06-17 05:29:43 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:29:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:29:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:29:43 --> Controller Class Initialized
DEBUG - 2021-06-17 05:29:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-17 05:29:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 05:29:43 --> Final output sent to browser
DEBUG - 2021-06-17 05:29:43 --> Total execution time: 0.0510
INFO - 2021-06-17 05:29:47 --> Config Class Initialized
INFO - 2021-06-17 05:29:47 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:29:47 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:29:47 --> Utf8 Class Initialized
INFO - 2021-06-17 05:29:47 --> URI Class Initialized
INFO - 2021-06-17 05:29:47 --> Router Class Initialized
INFO - 2021-06-17 05:29:47 --> Output Class Initialized
INFO - 2021-06-17 05:29:47 --> Security Class Initialized
DEBUG - 2021-06-17 05:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:29:47 --> Input Class Initialized
INFO - 2021-06-17 05:29:47 --> Language Class Initialized
INFO - 2021-06-17 05:29:47 --> Language Class Initialized
INFO - 2021-06-17 05:29:47 --> Config Class Initialized
INFO - 2021-06-17 05:29:47 --> Loader Class Initialized
INFO - 2021-06-17 05:29:47 --> Helper loaded: url_helper
INFO - 2021-06-17 05:29:47 --> Helper loaded: file_helper
INFO - 2021-06-17 05:29:47 --> Helper loaded: form_helper
INFO - 2021-06-17 05:29:47 --> Helper loaded: my_helper
INFO - 2021-06-17 05:29:47 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:29:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:29:47 --> Controller Class Initialized
DEBUG - 2021-06-17 05:29:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-17 05:29:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 05:29:47 --> Final output sent to browser
DEBUG - 2021-06-17 05:29:47 --> Total execution time: 0.0494
INFO - 2021-06-17 05:29:47 --> Config Class Initialized
INFO - 2021-06-17 05:29:47 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:29:47 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:29:47 --> Utf8 Class Initialized
INFO - 2021-06-17 05:29:47 --> URI Class Initialized
INFO - 2021-06-17 05:29:47 --> Router Class Initialized
INFO - 2021-06-17 05:29:47 --> Output Class Initialized
INFO - 2021-06-17 05:29:47 --> Security Class Initialized
DEBUG - 2021-06-17 05:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:29:47 --> Input Class Initialized
INFO - 2021-06-17 05:29:47 --> Language Class Initialized
INFO - 2021-06-17 05:29:47 --> Language Class Initialized
INFO - 2021-06-17 05:29:47 --> Config Class Initialized
INFO - 2021-06-17 05:29:47 --> Loader Class Initialized
INFO - 2021-06-17 05:29:47 --> Helper loaded: url_helper
INFO - 2021-06-17 05:29:47 --> Helper loaded: file_helper
INFO - 2021-06-17 05:29:47 --> Helper loaded: form_helper
INFO - 2021-06-17 05:29:47 --> Helper loaded: my_helper
INFO - 2021-06-17 05:29:47 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:29:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:29:47 --> Controller Class Initialized
INFO - 2021-06-17 05:29:54 --> Config Class Initialized
INFO - 2021-06-17 05:29:54 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:29:54 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:29:54 --> Utf8 Class Initialized
INFO - 2021-06-17 05:29:54 --> URI Class Initialized
INFO - 2021-06-17 05:29:54 --> Router Class Initialized
INFO - 2021-06-17 05:29:54 --> Output Class Initialized
INFO - 2021-06-17 05:29:54 --> Security Class Initialized
DEBUG - 2021-06-17 05:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:29:54 --> Input Class Initialized
INFO - 2021-06-17 05:29:54 --> Language Class Initialized
INFO - 2021-06-17 05:29:54 --> Language Class Initialized
INFO - 2021-06-17 05:29:54 --> Config Class Initialized
INFO - 2021-06-17 05:29:54 --> Loader Class Initialized
INFO - 2021-06-17 05:29:54 --> Helper loaded: url_helper
INFO - 2021-06-17 05:29:54 --> Helper loaded: file_helper
INFO - 2021-06-17 05:29:54 --> Helper loaded: form_helper
INFO - 2021-06-17 05:29:54 --> Helper loaded: my_helper
INFO - 2021-06-17 05:29:54 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:29:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:29:54 --> Controller Class Initialized
DEBUG - 2021-06-17 05:29:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-17 05:29:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 05:29:54 --> Final output sent to browser
DEBUG - 2021-06-17 05:29:54 --> Total execution time: 0.0510
INFO - 2021-06-17 05:29:56 --> Config Class Initialized
INFO - 2021-06-17 05:29:56 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:29:56 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:29:56 --> Utf8 Class Initialized
INFO - 2021-06-17 05:29:56 --> URI Class Initialized
INFO - 2021-06-17 05:29:56 --> Router Class Initialized
INFO - 2021-06-17 05:29:56 --> Output Class Initialized
INFO - 2021-06-17 05:29:56 --> Security Class Initialized
DEBUG - 2021-06-17 05:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:29:56 --> Input Class Initialized
INFO - 2021-06-17 05:29:56 --> Language Class Initialized
INFO - 2021-06-17 05:29:56 --> Language Class Initialized
INFO - 2021-06-17 05:29:56 --> Config Class Initialized
INFO - 2021-06-17 05:29:56 --> Loader Class Initialized
INFO - 2021-06-17 05:29:56 --> Helper loaded: url_helper
INFO - 2021-06-17 05:29:56 --> Helper loaded: file_helper
INFO - 2021-06-17 05:29:56 --> Helper loaded: form_helper
INFO - 2021-06-17 05:29:56 --> Helper loaded: my_helper
INFO - 2021-06-17 05:29:56 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:29:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:29:56 --> Controller Class Initialized
DEBUG - 2021-06-17 05:29:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 05:29:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 05:29:56 --> Final output sent to browser
DEBUG - 2021-06-17 05:29:56 --> Total execution time: 0.1111
INFO - 2021-06-17 05:30:06 --> Config Class Initialized
INFO - 2021-06-17 05:30:06 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:30:06 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:30:06 --> Utf8 Class Initialized
INFO - 2021-06-17 05:30:06 --> URI Class Initialized
INFO - 2021-06-17 05:30:06 --> Router Class Initialized
INFO - 2021-06-17 05:30:06 --> Output Class Initialized
INFO - 2021-06-17 05:30:06 --> Security Class Initialized
DEBUG - 2021-06-17 05:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:30:06 --> Input Class Initialized
INFO - 2021-06-17 05:30:06 --> Language Class Initialized
INFO - 2021-06-17 05:30:06 --> Language Class Initialized
INFO - 2021-06-17 05:30:06 --> Config Class Initialized
INFO - 2021-06-17 05:30:06 --> Loader Class Initialized
INFO - 2021-06-17 05:30:06 --> Helper loaded: url_helper
INFO - 2021-06-17 05:30:06 --> Helper loaded: file_helper
INFO - 2021-06-17 05:30:06 --> Helper loaded: form_helper
INFO - 2021-06-17 05:30:06 --> Helper loaded: my_helper
INFO - 2021-06-17 05:30:06 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:30:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:30:06 --> Controller Class Initialized
DEBUG - 2021-06-17 05:30:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-17 05:30:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 05:30:06 --> Final output sent to browser
DEBUG - 2021-06-17 05:30:06 --> Total execution time: 0.0488
INFO - 2021-06-17 05:30:10 --> Config Class Initialized
INFO - 2021-06-17 05:30:10 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:30:10 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:30:10 --> Utf8 Class Initialized
INFO - 2021-06-17 05:30:10 --> URI Class Initialized
INFO - 2021-06-17 05:30:10 --> Router Class Initialized
INFO - 2021-06-17 05:30:10 --> Output Class Initialized
INFO - 2021-06-17 05:30:10 --> Security Class Initialized
DEBUG - 2021-06-17 05:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:30:10 --> Input Class Initialized
INFO - 2021-06-17 05:30:10 --> Language Class Initialized
INFO - 2021-06-17 05:30:10 --> Language Class Initialized
INFO - 2021-06-17 05:30:10 --> Config Class Initialized
INFO - 2021-06-17 05:30:10 --> Loader Class Initialized
INFO - 2021-06-17 05:30:10 --> Helper loaded: url_helper
INFO - 2021-06-17 05:30:10 --> Helper loaded: file_helper
INFO - 2021-06-17 05:30:10 --> Helper loaded: form_helper
INFO - 2021-06-17 05:30:10 --> Helper loaded: my_helper
INFO - 2021-06-17 05:30:11 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:30:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:30:11 --> Controller Class Initialized
DEBUG - 2021-06-17 05:30:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-17 05:30:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 05:30:11 --> Final output sent to browser
DEBUG - 2021-06-17 05:30:11 --> Total execution time: 0.0504
INFO - 2021-06-17 05:30:11 --> Config Class Initialized
INFO - 2021-06-17 05:30:11 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:30:11 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:30:11 --> Utf8 Class Initialized
INFO - 2021-06-17 05:30:11 --> URI Class Initialized
INFO - 2021-06-17 05:30:11 --> Router Class Initialized
INFO - 2021-06-17 05:30:11 --> Output Class Initialized
INFO - 2021-06-17 05:30:11 --> Security Class Initialized
DEBUG - 2021-06-17 05:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:30:11 --> Input Class Initialized
INFO - 2021-06-17 05:30:11 --> Language Class Initialized
INFO - 2021-06-17 05:30:11 --> Language Class Initialized
INFO - 2021-06-17 05:30:11 --> Config Class Initialized
INFO - 2021-06-17 05:30:11 --> Loader Class Initialized
INFO - 2021-06-17 05:30:11 --> Helper loaded: url_helper
INFO - 2021-06-17 05:30:11 --> Helper loaded: file_helper
INFO - 2021-06-17 05:30:11 --> Helper loaded: form_helper
INFO - 2021-06-17 05:30:11 --> Helper loaded: my_helper
INFO - 2021-06-17 05:30:11 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:30:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:30:11 --> Controller Class Initialized
INFO - 2021-06-17 05:30:14 --> Config Class Initialized
INFO - 2021-06-17 05:30:14 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:30:14 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:30:14 --> Utf8 Class Initialized
INFO - 2021-06-17 05:30:14 --> URI Class Initialized
INFO - 2021-06-17 05:30:14 --> Router Class Initialized
INFO - 2021-06-17 05:30:14 --> Output Class Initialized
INFO - 2021-06-17 05:30:14 --> Security Class Initialized
DEBUG - 2021-06-17 05:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:30:14 --> Input Class Initialized
INFO - 2021-06-17 05:30:14 --> Language Class Initialized
INFO - 2021-06-17 05:30:14 --> Language Class Initialized
INFO - 2021-06-17 05:30:14 --> Config Class Initialized
INFO - 2021-06-17 05:30:14 --> Loader Class Initialized
INFO - 2021-06-17 05:30:14 --> Helper loaded: url_helper
INFO - 2021-06-17 05:30:14 --> Helper loaded: file_helper
INFO - 2021-06-17 05:30:14 --> Helper loaded: form_helper
INFO - 2021-06-17 05:30:14 --> Helper loaded: my_helper
INFO - 2021-06-17 05:30:14 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:30:14 --> Controller Class Initialized
DEBUG - 2021-06-17 05:30:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-17 05:30:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 05:30:14 --> Final output sent to browser
DEBUG - 2021-06-17 05:30:14 --> Total execution time: 0.0511
INFO - 2021-06-17 05:30:22 --> Config Class Initialized
INFO - 2021-06-17 05:30:22 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:30:22 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:30:22 --> Utf8 Class Initialized
INFO - 2021-06-17 05:30:22 --> URI Class Initialized
INFO - 2021-06-17 05:30:22 --> Router Class Initialized
INFO - 2021-06-17 05:30:22 --> Output Class Initialized
INFO - 2021-06-17 05:30:22 --> Security Class Initialized
DEBUG - 2021-06-17 05:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:30:22 --> Input Class Initialized
INFO - 2021-06-17 05:30:22 --> Language Class Initialized
INFO - 2021-06-17 05:30:22 --> Language Class Initialized
INFO - 2021-06-17 05:30:22 --> Config Class Initialized
INFO - 2021-06-17 05:30:22 --> Loader Class Initialized
INFO - 2021-06-17 05:30:22 --> Helper loaded: url_helper
INFO - 2021-06-17 05:30:22 --> Helper loaded: file_helper
INFO - 2021-06-17 05:30:22 --> Helper loaded: form_helper
INFO - 2021-06-17 05:30:22 --> Helper loaded: my_helper
INFO - 2021-06-17 05:30:22 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:30:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:30:22 --> Controller Class Initialized
DEBUG - 2021-06-17 05:30:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 05:30:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 05:30:22 --> Final output sent to browser
DEBUG - 2021-06-17 05:30:22 --> Total execution time: 0.0515
INFO - 2021-06-17 05:30:27 --> Config Class Initialized
INFO - 2021-06-17 05:30:27 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:30:27 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:30:27 --> Utf8 Class Initialized
INFO - 2021-06-17 05:30:27 --> URI Class Initialized
INFO - 2021-06-17 05:30:27 --> Router Class Initialized
INFO - 2021-06-17 05:30:27 --> Output Class Initialized
INFO - 2021-06-17 05:30:27 --> Security Class Initialized
DEBUG - 2021-06-17 05:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:30:27 --> Input Class Initialized
INFO - 2021-06-17 05:30:27 --> Language Class Initialized
INFO - 2021-06-17 05:30:27 --> Language Class Initialized
INFO - 2021-06-17 05:30:27 --> Config Class Initialized
INFO - 2021-06-17 05:30:27 --> Loader Class Initialized
INFO - 2021-06-17 05:30:27 --> Helper loaded: url_helper
INFO - 2021-06-17 05:30:27 --> Helper loaded: file_helper
INFO - 2021-06-17 05:30:27 --> Helper loaded: form_helper
INFO - 2021-06-17 05:30:27 --> Helper loaded: my_helper
INFO - 2021-06-17 05:30:27 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:30:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:30:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:30:27 --> Controller Class Initialized
INFO - 2021-06-17 05:30:27 --> Final output sent to browser
DEBUG - 2021-06-17 05:30:27 --> Total execution time: 0.0479
INFO - 2021-06-17 05:31:00 --> Config Class Initialized
INFO - 2021-06-17 05:31:00 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:31:00 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:31:00 --> Utf8 Class Initialized
INFO - 2021-06-17 05:31:00 --> URI Class Initialized
INFO - 2021-06-17 05:31:00 --> Router Class Initialized
INFO - 2021-06-17 05:31:00 --> Output Class Initialized
INFO - 2021-06-17 05:31:00 --> Security Class Initialized
DEBUG - 2021-06-17 05:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:31:00 --> Input Class Initialized
INFO - 2021-06-17 05:31:00 --> Language Class Initialized
INFO - 2021-06-17 05:31:00 --> Language Class Initialized
INFO - 2021-06-17 05:31:00 --> Config Class Initialized
INFO - 2021-06-17 05:31:00 --> Loader Class Initialized
INFO - 2021-06-17 05:31:00 --> Helper loaded: url_helper
INFO - 2021-06-17 05:31:00 --> Helper loaded: file_helper
INFO - 2021-06-17 05:31:00 --> Helper loaded: form_helper
INFO - 2021-06-17 05:31:00 --> Helper loaded: my_helper
INFO - 2021-06-17 05:31:00 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:31:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:31:00 --> Controller Class Initialized
INFO - 2021-06-17 05:31:00 --> Final output sent to browser
DEBUG - 2021-06-17 05:31:00 --> Total execution time: 0.0494
INFO - 2021-06-17 05:31:00 --> Config Class Initialized
INFO - 2021-06-17 05:31:00 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:31:00 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:31:00 --> Utf8 Class Initialized
INFO - 2021-06-17 05:31:00 --> URI Class Initialized
INFO - 2021-06-17 05:31:00 --> Router Class Initialized
INFO - 2021-06-17 05:31:00 --> Output Class Initialized
INFO - 2021-06-17 05:31:00 --> Security Class Initialized
DEBUG - 2021-06-17 05:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:31:00 --> Input Class Initialized
INFO - 2021-06-17 05:31:00 --> Language Class Initialized
INFO - 2021-06-17 05:31:00 --> Language Class Initialized
INFO - 2021-06-17 05:31:00 --> Config Class Initialized
INFO - 2021-06-17 05:31:00 --> Loader Class Initialized
INFO - 2021-06-17 05:31:00 --> Helper loaded: url_helper
INFO - 2021-06-17 05:31:00 --> Helper loaded: file_helper
INFO - 2021-06-17 05:31:00 --> Helper loaded: form_helper
INFO - 2021-06-17 05:31:00 --> Helper loaded: my_helper
INFO - 2021-06-17 05:31:00 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:31:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:31:00 --> Controller Class Initialized
DEBUG - 2021-06-17 05:31:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 05:31:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 05:31:00 --> Final output sent to browser
DEBUG - 2021-06-17 05:31:00 --> Total execution time: 0.0416
INFO - 2021-06-17 05:31:02 --> Config Class Initialized
INFO - 2021-06-17 05:31:02 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:31:02 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:31:02 --> Utf8 Class Initialized
INFO - 2021-06-17 05:31:02 --> URI Class Initialized
INFO - 2021-06-17 05:31:02 --> Router Class Initialized
INFO - 2021-06-17 05:31:02 --> Output Class Initialized
INFO - 2021-06-17 05:31:02 --> Security Class Initialized
DEBUG - 2021-06-17 05:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:31:02 --> Input Class Initialized
INFO - 2021-06-17 05:31:02 --> Language Class Initialized
INFO - 2021-06-17 05:31:02 --> Language Class Initialized
INFO - 2021-06-17 05:31:02 --> Config Class Initialized
INFO - 2021-06-17 05:31:02 --> Loader Class Initialized
INFO - 2021-06-17 05:31:02 --> Helper loaded: url_helper
INFO - 2021-06-17 05:31:02 --> Helper loaded: file_helper
INFO - 2021-06-17 05:31:02 --> Helper loaded: form_helper
INFO - 2021-06-17 05:31:02 --> Helper loaded: my_helper
INFO - 2021-06-17 05:31:02 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:31:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:31:02 --> Controller Class Initialized
INFO - 2021-06-17 05:31:02 --> Final output sent to browser
DEBUG - 2021-06-17 05:31:02 --> Total execution time: 0.0478
INFO - 2021-06-17 05:31:29 --> Config Class Initialized
INFO - 2021-06-17 05:31:29 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:31:29 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:31:29 --> Utf8 Class Initialized
INFO - 2021-06-17 05:31:29 --> URI Class Initialized
INFO - 2021-06-17 05:31:29 --> Router Class Initialized
INFO - 2021-06-17 05:31:29 --> Output Class Initialized
INFO - 2021-06-17 05:31:29 --> Security Class Initialized
DEBUG - 2021-06-17 05:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:31:29 --> Input Class Initialized
INFO - 2021-06-17 05:31:29 --> Language Class Initialized
INFO - 2021-06-17 05:31:29 --> Language Class Initialized
INFO - 2021-06-17 05:31:29 --> Config Class Initialized
INFO - 2021-06-17 05:31:29 --> Loader Class Initialized
INFO - 2021-06-17 05:31:29 --> Helper loaded: url_helper
INFO - 2021-06-17 05:31:29 --> Helper loaded: file_helper
INFO - 2021-06-17 05:31:29 --> Helper loaded: form_helper
INFO - 2021-06-17 05:31:29 --> Helper loaded: my_helper
INFO - 2021-06-17 05:31:29 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:31:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:31:29 --> Controller Class Initialized
INFO - 2021-06-17 05:31:29 --> Final output sent to browser
DEBUG - 2021-06-17 05:31:29 --> Total execution time: 0.0512
INFO - 2021-06-17 05:31:29 --> Config Class Initialized
INFO - 2021-06-17 05:31:29 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:31:29 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:31:29 --> Utf8 Class Initialized
INFO - 2021-06-17 05:31:29 --> URI Class Initialized
INFO - 2021-06-17 05:31:29 --> Router Class Initialized
INFO - 2021-06-17 05:31:29 --> Output Class Initialized
INFO - 2021-06-17 05:31:29 --> Security Class Initialized
DEBUG - 2021-06-17 05:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:31:29 --> Input Class Initialized
INFO - 2021-06-17 05:31:29 --> Language Class Initialized
INFO - 2021-06-17 05:31:29 --> Language Class Initialized
INFO - 2021-06-17 05:31:29 --> Config Class Initialized
INFO - 2021-06-17 05:31:29 --> Loader Class Initialized
INFO - 2021-06-17 05:31:29 --> Helper loaded: url_helper
INFO - 2021-06-17 05:31:29 --> Helper loaded: file_helper
INFO - 2021-06-17 05:31:29 --> Helper loaded: form_helper
INFO - 2021-06-17 05:31:29 --> Helper loaded: my_helper
INFO - 2021-06-17 05:31:29 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:31:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:31:29 --> Controller Class Initialized
DEBUG - 2021-06-17 05:31:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 05:31:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 05:31:29 --> Final output sent to browser
DEBUG - 2021-06-17 05:31:29 --> Total execution time: 0.0518
INFO - 2021-06-17 05:31:32 --> Config Class Initialized
INFO - 2021-06-17 05:31:32 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:31:32 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:31:32 --> Utf8 Class Initialized
INFO - 2021-06-17 05:31:32 --> URI Class Initialized
INFO - 2021-06-17 05:31:32 --> Router Class Initialized
INFO - 2021-06-17 05:31:32 --> Output Class Initialized
INFO - 2021-06-17 05:31:32 --> Security Class Initialized
DEBUG - 2021-06-17 05:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:31:32 --> Input Class Initialized
INFO - 2021-06-17 05:31:32 --> Language Class Initialized
INFO - 2021-06-17 05:31:32 --> Language Class Initialized
INFO - 2021-06-17 05:31:32 --> Config Class Initialized
INFO - 2021-06-17 05:31:32 --> Loader Class Initialized
INFO - 2021-06-17 05:31:32 --> Helper loaded: url_helper
INFO - 2021-06-17 05:31:32 --> Helper loaded: file_helper
INFO - 2021-06-17 05:31:32 --> Helper loaded: form_helper
INFO - 2021-06-17 05:31:32 --> Helper loaded: my_helper
INFO - 2021-06-17 05:31:32 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:31:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:31:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:31:32 --> Controller Class Initialized
INFO - 2021-06-17 05:31:32 --> Final output sent to browser
DEBUG - 2021-06-17 05:31:32 --> Total execution time: 0.0486
INFO - 2021-06-17 05:32:23 --> Config Class Initialized
INFO - 2021-06-17 05:32:23 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:32:23 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:32:23 --> Utf8 Class Initialized
INFO - 2021-06-17 05:32:23 --> URI Class Initialized
INFO - 2021-06-17 05:32:23 --> Router Class Initialized
INFO - 2021-06-17 05:32:23 --> Output Class Initialized
INFO - 2021-06-17 05:32:23 --> Security Class Initialized
DEBUG - 2021-06-17 05:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:32:23 --> Input Class Initialized
INFO - 2021-06-17 05:32:23 --> Language Class Initialized
INFO - 2021-06-17 05:32:23 --> Language Class Initialized
INFO - 2021-06-17 05:32:23 --> Config Class Initialized
INFO - 2021-06-17 05:32:23 --> Loader Class Initialized
INFO - 2021-06-17 05:32:23 --> Helper loaded: url_helper
INFO - 2021-06-17 05:32:23 --> Helper loaded: file_helper
INFO - 2021-06-17 05:32:23 --> Helper loaded: form_helper
INFO - 2021-06-17 05:32:23 --> Helper loaded: my_helper
INFO - 2021-06-17 05:32:23 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:32:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:32:23 --> Controller Class Initialized
INFO - 2021-06-17 05:32:23 --> Final output sent to browser
DEBUG - 2021-06-17 05:32:23 --> Total execution time: 0.0411
INFO - 2021-06-17 05:32:23 --> Config Class Initialized
INFO - 2021-06-17 05:32:23 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:32:23 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:32:23 --> Utf8 Class Initialized
INFO - 2021-06-17 05:32:23 --> URI Class Initialized
INFO - 2021-06-17 05:32:23 --> Router Class Initialized
INFO - 2021-06-17 05:32:23 --> Output Class Initialized
INFO - 2021-06-17 05:32:23 --> Security Class Initialized
DEBUG - 2021-06-17 05:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:32:23 --> Input Class Initialized
INFO - 2021-06-17 05:32:23 --> Language Class Initialized
INFO - 2021-06-17 05:32:23 --> Language Class Initialized
INFO - 2021-06-17 05:32:23 --> Config Class Initialized
INFO - 2021-06-17 05:32:23 --> Loader Class Initialized
INFO - 2021-06-17 05:32:23 --> Helper loaded: url_helper
INFO - 2021-06-17 05:32:23 --> Helper loaded: file_helper
INFO - 2021-06-17 05:32:23 --> Helper loaded: form_helper
INFO - 2021-06-17 05:32:23 --> Helper loaded: my_helper
INFO - 2021-06-17 05:32:23 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:32:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:32:23 --> Controller Class Initialized
DEBUG - 2021-06-17 05:32:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 05:32:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 05:32:23 --> Final output sent to browser
DEBUG - 2021-06-17 05:32:23 --> Total execution time: 0.0419
INFO - 2021-06-17 05:32:25 --> Config Class Initialized
INFO - 2021-06-17 05:32:25 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:32:25 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:32:25 --> Utf8 Class Initialized
INFO - 2021-06-17 05:32:25 --> URI Class Initialized
INFO - 2021-06-17 05:32:25 --> Router Class Initialized
INFO - 2021-06-17 05:32:25 --> Output Class Initialized
INFO - 2021-06-17 05:32:25 --> Security Class Initialized
DEBUG - 2021-06-17 05:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:32:25 --> Input Class Initialized
INFO - 2021-06-17 05:32:25 --> Language Class Initialized
INFO - 2021-06-17 05:32:25 --> Language Class Initialized
INFO - 2021-06-17 05:32:25 --> Config Class Initialized
INFO - 2021-06-17 05:32:25 --> Loader Class Initialized
INFO - 2021-06-17 05:32:25 --> Helper loaded: url_helper
INFO - 2021-06-17 05:32:25 --> Helper loaded: file_helper
INFO - 2021-06-17 05:32:25 --> Helper loaded: form_helper
INFO - 2021-06-17 05:32:25 --> Helper loaded: my_helper
INFO - 2021-06-17 05:32:25 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:32:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:32:25 --> Controller Class Initialized
INFO - 2021-06-17 05:32:25 --> Final output sent to browser
DEBUG - 2021-06-17 05:32:25 --> Total execution time: 0.0487
INFO - 2021-06-17 05:32:58 --> Config Class Initialized
INFO - 2021-06-17 05:32:58 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:32:58 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:32:58 --> Utf8 Class Initialized
INFO - 2021-06-17 05:32:58 --> URI Class Initialized
INFO - 2021-06-17 05:32:58 --> Router Class Initialized
INFO - 2021-06-17 05:32:58 --> Output Class Initialized
INFO - 2021-06-17 05:32:58 --> Security Class Initialized
DEBUG - 2021-06-17 05:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:32:58 --> Input Class Initialized
INFO - 2021-06-17 05:32:58 --> Language Class Initialized
INFO - 2021-06-17 05:32:58 --> Language Class Initialized
INFO - 2021-06-17 05:32:58 --> Config Class Initialized
INFO - 2021-06-17 05:32:58 --> Loader Class Initialized
INFO - 2021-06-17 05:32:58 --> Helper loaded: url_helper
INFO - 2021-06-17 05:32:58 --> Helper loaded: file_helper
INFO - 2021-06-17 05:32:58 --> Helper loaded: form_helper
INFO - 2021-06-17 05:32:58 --> Helper loaded: my_helper
INFO - 2021-06-17 05:32:58 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:32:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:32:58 --> Controller Class Initialized
INFO - 2021-06-17 05:32:58 --> Final output sent to browser
DEBUG - 2021-06-17 05:32:58 --> Total execution time: 0.0518
INFO - 2021-06-17 05:32:58 --> Config Class Initialized
INFO - 2021-06-17 05:32:58 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:32:58 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:32:58 --> Utf8 Class Initialized
INFO - 2021-06-17 05:32:58 --> URI Class Initialized
INFO - 2021-06-17 05:32:58 --> Router Class Initialized
INFO - 2021-06-17 05:32:58 --> Output Class Initialized
INFO - 2021-06-17 05:32:58 --> Security Class Initialized
DEBUG - 2021-06-17 05:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:32:58 --> Input Class Initialized
INFO - 2021-06-17 05:32:58 --> Language Class Initialized
INFO - 2021-06-17 05:32:58 --> Language Class Initialized
INFO - 2021-06-17 05:32:58 --> Config Class Initialized
INFO - 2021-06-17 05:32:58 --> Loader Class Initialized
INFO - 2021-06-17 05:32:58 --> Helper loaded: url_helper
INFO - 2021-06-17 05:32:58 --> Helper loaded: file_helper
INFO - 2021-06-17 05:32:58 --> Helper loaded: form_helper
INFO - 2021-06-17 05:32:58 --> Helper loaded: my_helper
INFO - 2021-06-17 05:32:58 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:32:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:32:58 --> Controller Class Initialized
DEBUG - 2021-06-17 05:32:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 05:32:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 05:32:58 --> Final output sent to browser
DEBUG - 2021-06-17 05:32:58 --> Total execution time: 0.0561
INFO - 2021-06-17 05:33:03 --> Config Class Initialized
INFO - 2021-06-17 05:33:03 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:33:03 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:33:03 --> Utf8 Class Initialized
INFO - 2021-06-17 05:33:03 --> URI Class Initialized
INFO - 2021-06-17 05:33:03 --> Router Class Initialized
INFO - 2021-06-17 05:33:03 --> Output Class Initialized
INFO - 2021-06-17 05:33:03 --> Security Class Initialized
DEBUG - 2021-06-17 05:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:33:03 --> Input Class Initialized
INFO - 2021-06-17 05:33:03 --> Language Class Initialized
INFO - 2021-06-17 05:33:03 --> Language Class Initialized
INFO - 2021-06-17 05:33:03 --> Config Class Initialized
INFO - 2021-06-17 05:33:03 --> Loader Class Initialized
INFO - 2021-06-17 05:33:03 --> Helper loaded: url_helper
INFO - 2021-06-17 05:33:03 --> Helper loaded: file_helper
INFO - 2021-06-17 05:33:03 --> Helper loaded: form_helper
INFO - 2021-06-17 05:33:03 --> Helper loaded: my_helper
INFO - 2021-06-17 05:33:03 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:33:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:33:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:33:03 --> Controller Class Initialized
INFO - 2021-06-17 05:33:03 --> Final output sent to browser
DEBUG - 2021-06-17 05:33:03 --> Total execution time: 0.0485
INFO - 2021-06-17 05:33:30 --> Config Class Initialized
INFO - 2021-06-17 05:33:30 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:33:30 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:33:30 --> Utf8 Class Initialized
INFO - 2021-06-17 05:33:30 --> URI Class Initialized
INFO - 2021-06-17 05:33:30 --> Router Class Initialized
INFO - 2021-06-17 05:33:30 --> Output Class Initialized
INFO - 2021-06-17 05:33:30 --> Security Class Initialized
DEBUG - 2021-06-17 05:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:33:30 --> Input Class Initialized
INFO - 2021-06-17 05:33:30 --> Language Class Initialized
INFO - 2021-06-17 05:33:30 --> Language Class Initialized
INFO - 2021-06-17 05:33:30 --> Config Class Initialized
INFO - 2021-06-17 05:33:30 --> Loader Class Initialized
INFO - 2021-06-17 05:33:30 --> Helper loaded: url_helper
INFO - 2021-06-17 05:33:30 --> Helper loaded: file_helper
INFO - 2021-06-17 05:33:30 --> Helper loaded: form_helper
INFO - 2021-06-17 05:33:30 --> Helper loaded: my_helper
INFO - 2021-06-17 05:33:30 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:33:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:33:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:33:30 --> Controller Class Initialized
DEBUG - 2021-06-17 05:33:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-17 05:33:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 05:33:30 --> Final output sent to browser
DEBUG - 2021-06-17 05:33:30 --> Total execution time: 0.0387
INFO - 2021-06-17 05:33:33 --> Config Class Initialized
INFO - 2021-06-17 05:33:33 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:33:33 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:33:33 --> Utf8 Class Initialized
INFO - 2021-06-17 05:33:33 --> URI Class Initialized
INFO - 2021-06-17 05:33:33 --> Router Class Initialized
INFO - 2021-06-17 05:33:33 --> Output Class Initialized
INFO - 2021-06-17 05:33:33 --> Security Class Initialized
DEBUG - 2021-06-17 05:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:33:33 --> Input Class Initialized
INFO - 2021-06-17 05:33:33 --> Language Class Initialized
INFO - 2021-06-17 05:33:33 --> Language Class Initialized
INFO - 2021-06-17 05:33:33 --> Config Class Initialized
INFO - 2021-06-17 05:33:33 --> Loader Class Initialized
INFO - 2021-06-17 05:33:33 --> Helper loaded: url_helper
INFO - 2021-06-17 05:33:33 --> Helper loaded: file_helper
INFO - 2021-06-17 05:33:33 --> Helper loaded: form_helper
INFO - 2021-06-17 05:33:33 --> Helper loaded: my_helper
INFO - 2021-06-17 05:33:33 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:33:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:33:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:33:33 --> Controller Class Initialized
INFO - 2021-06-17 05:33:33 --> Final output sent to browser
DEBUG - 2021-06-17 05:33:33 --> Total execution time: 0.0498
INFO - 2021-06-17 05:33:33 --> Config Class Initialized
INFO - 2021-06-17 05:33:33 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:33:33 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:33:33 --> Utf8 Class Initialized
INFO - 2021-06-17 05:33:33 --> URI Class Initialized
INFO - 2021-06-17 05:33:33 --> Router Class Initialized
INFO - 2021-06-17 05:33:33 --> Output Class Initialized
INFO - 2021-06-17 05:33:33 --> Security Class Initialized
DEBUG - 2021-06-17 05:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:33:33 --> Input Class Initialized
INFO - 2021-06-17 05:33:33 --> Language Class Initialized
INFO - 2021-06-17 05:33:33 --> Language Class Initialized
INFO - 2021-06-17 05:33:33 --> Config Class Initialized
INFO - 2021-06-17 05:33:33 --> Loader Class Initialized
INFO - 2021-06-17 05:33:33 --> Helper loaded: url_helper
INFO - 2021-06-17 05:33:33 --> Helper loaded: file_helper
INFO - 2021-06-17 05:33:33 --> Helper loaded: form_helper
INFO - 2021-06-17 05:33:33 --> Helper loaded: my_helper
INFO - 2021-06-17 05:33:33 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:33:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:33:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:33:33 --> Controller Class Initialized
DEBUG - 2021-06-17 05:33:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 05:33:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 05:33:33 --> Final output sent to browser
DEBUG - 2021-06-17 05:33:33 --> Total execution time: 0.0516
INFO - 2021-06-17 05:33:36 --> Config Class Initialized
INFO - 2021-06-17 05:33:36 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:33:36 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:33:36 --> Utf8 Class Initialized
INFO - 2021-06-17 05:33:36 --> URI Class Initialized
INFO - 2021-06-17 05:33:36 --> Router Class Initialized
INFO - 2021-06-17 05:33:36 --> Output Class Initialized
INFO - 2021-06-17 05:33:36 --> Security Class Initialized
DEBUG - 2021-06-17 05:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:33:36 --> Input Class Initialized
INFO - 2021-06-17 05:33:36 --> Language Class Initialized
INFO - 2021-06-17 05:33:36 --> Language Class Initialized
INFO - 2021-06-17 05:33:36 --> Config Class Initialized
INFO - 2021-06-17 05:33:36 --> Loader Class Initialized
INFO - 2021-06-17 05:33:36 --> Helper loaded: url_helper
INFO - 2021-06-17 05:33:36 --> Helper loaded: file_helper
INFO - 2021-06-17 05:33:36 --> Helper loaded: form_helper
INFO - 2021-06-17 05:33:36 --> Helper loaded: my_helper
INFO - 2021-06-17 05:33:36 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:33:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:33:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:33:36 --> Controller Class Initialized
DEBUG - 2021-06-17 05:33:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-17 05:33:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 05:33:36 --> Final output sent to browser
DEBUG - 2021-06-17 05:33:36 --> Total execution time: 0.0499
INFO - 2021-06-17 05:33:49 --> Config Class Initialized
INFO - 2021-06-17 05:33:49 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:33:49 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:33:49 --> Utf8 Class Initialized
INFO - 2021-06-17 05:33:49 --> URI Class Initialized
INFO - 2021-06-17 05:33:49 --> Router Class Initialized
INFO - 2021-06-17 05:33:49 --> Output Class Initialized
INFO - 2021-06-17 05:33:49 --> Security Class Initialized
DEBUG - 2021-06-17 05:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:33:49 --> Input Class Initialized
INFO - 2021-06-17 05:33:49 --> Language Class Initialized
INFO - 2021-06-17 05:33:49 --> Language Class Initialized
INFO - 2021-06-17 05:33:49 --> Config Class Initialized
INFO - 2021-06-17 05:33:49 --> Loader Class Initialized
INFO - 2021-06-17 05:33:49 --> Helper loaded: url_helper
INFO - 2021-06-17 05:33:49 --> Helper loaded: file_helper
INFO - 2021-06-17 05:33:49 --> Helper loaded: form_helper
INFO - 2021-06-17 05:33:49 --> Helper loaded: my_helper
INFO - 2021-06-17 05:33:49 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:33:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:33:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:33:49 --> Controller Class Initialized
DEBUG - 2021-06-17 05:33:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-17 05:33:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 05:33:49 --> Final output sent to browser
DEBUG - 2021-06-17 05:33:49 --> Total execution time: 0.0498
INFO - 2021-06-17 05:33:49 --> Config Class Initialized
INFO - 2021-06-17 05:33:49 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:33:49 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:33:49 --> Utf8 Class Initialized
INFO - 2021-06-17 05:33:49 --> URI Class Initialized
INFO - 2021-06-17 05:33:49 --> Router Class Initialized
INFO - 2021-06-17 05:33:49 --> Output Class Initialized
INFO - 2021-06-17 05:33:49 --> Security Class Initialized
DEBUG - 2021-06-17 05:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:33:49 --> Input Class Initialized
INFO - 2021-06-17 05:33:49 --> Language Class Initialized
INFO - 2021-06-17 05:33:49 --> Language Class Initialized
INFO - 2021-06-17 05:33:49 --> Config Class Initialized
INFO - 2021-06-17 05:33:49 --> Loader Class Initialized
INFO - 2021-06-17 05:33:49 --> Helper loaded: url_helper
INFO - 2021-06-17 05:33:49 --> Helper loaded: file_helper
INFO - 2021-06-17 05:33:49 --> Helper loaded: form_helper
INFO - 2021-06-17 05:33:49 --> Helper loaded: my_helper
INFO - 2021-06-17 05:33:49 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:33:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:33:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:33:49 --> Controller Class Initialized
INFO - 2021-06-17 05:33:52 --> Config Class Initialized
INFO - 2021-06-17 05:33:52 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:33:52 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:33:52 --> Utf8 Class Initialized
INFO - 2021-06-17 05:33:52 --> URI Class Initialized
INFO - 2021-06-17 05:33:52 --> Router Class Initialized
INFO - 2021-06-17 05:33:52 --> Output Class Initialized
INFO - 2021-06-17 05:33:52 --> Security Class Initialized
DEBUG - 2021-06-17 05:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:33:52 --> Input Class Initialized
INFO - 2021-06-17 05:33:52 --> Language Class Initialized
INFO - 2021-06-17 05:33:52 --> Language Class Initialized
INFO - 2021-06-17 05:33:52 --> Config Class Initialized
INFO - 2021-06-17 05:33:53 --> Loader Class Initialized
INFO - 2021-06-17 05:33:53 --> Helper loaded: url_helper
INFO - 2021-06-17 05:33:53 --> Helper loaded: file_helper
INFO - 2021-06-17 05:33:53 --> Helper loaded: form_helper
INFO - 2021-06-17 05:33:53 --> Helper loaded: my_helper
INFO - 2021-06-17 05:33:53 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:33:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:33:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:33:53 --> Controller Class Initialized
DEBUG - 2021-06-17 05:33:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-17 05:33:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 05:33:53 --> Final output sent to browser
DEBUG - 2021-06-17 05:33:53 --> Total execution time: 0.0509
INFO - 2021-06-17 05:33:55 --> Config Class Initialized
INFO - 2021-06-17 05:33:55 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:33:55 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:33:55 --> Utf8 Class Initialized
INFO - 2021-06-17 05:33:55 --> URI Class Initialized
INFO - 2021-06-17 05:33:55 --> Router Class Initialized
INFO - 2021-06-17 05:33:55 --> Output Class Initialized
INFO - 2021-06-17 05:33:55 --> Security Class Initialized
DEBUG - 2021-06-17 05:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:33:55 --> Input Class Initialized
INFO - 2021-06-17 05:33:55 --> Language Class Initialized
INFO - 2021-06-17 05:33:55 --> Language Class Initialized
INFO - 2021-06-17 05:33:55 --> Config Class Initialized
INFO - 2021-06-17 05:33:55 --> Loader Class Initialized
INFO - 2021-06-17 05:33:55 --> Helper loaded: url_helper
INFO - 2021-06-17 05:33:55 --> Helper loaded: file_helper
INFO - 2021-06-17 05:33:55 --> Helper loaded: form_helper
INFO - 2021-06-17 05:33:55 --> Helper loaded: my_helper
INFO - 2021-06-17 05:33:55 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:33:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:33:55 --> Controller Class Initialized
DEBUG - 2021-06-17 05:33:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-17 05:33:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 05:33:55 --> Final output sent to browser
DEBUG - 2021-06-17 05:33:55 --> Total execution time: 0.0498
INFO - 2021-06-17 05:33:55 --> Config Class Initialized
INFO - 2021-06-17 05:33:55 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:33:55 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:33:55 --> Utf8 Class Initialized
INFO - 2021-06-17 05:33:55 --> URI Class Initialized
INFO - 2021-06-17 05:33:55 --> Router Class Initialized
INFO - 2021-06-17 05:33:55 --> Output Class Initialized
INFO - 2021-06-17 05:33:55 --> Security Class Initialized
DEBUG - 2021-06-17 05:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:33:55 --> Input Class Initialized
INFO - 2021-06-17 05:33:55 --> Language Class Initialized
INFO - 2021-06-17 05:33:55 --> Language Class Initialized
INFO - 2021-06-17 05:33:55 --> Config Class Initialized
INFO - 2021-06-17 05:33:55 --> Loader Class Initialized
INFO - 2021-06-17 05:33:55 --> Helper loaded: url_helper
INFO - 2021-06-17 05:33:55 --> Helper loaded: file_helper
INFO - 2021-06-17 05:33:55 --> Helper loaded: form_helper
INFO - 2021-06-17 05:33:55 --> Helper loaded: my_helper
INFO - 2021-06-17 05:33:55 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:33:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:33:55 --> Controller Class Initialized
INFO - 2021-06-17 05:34:06 --> Config Class Initialized
INFO - 2021-06-17 05:34:06 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:34:06 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:34:06 --> Utf8 Class Initialized
INFO - 2021-06-17 05:34:06 --> URI Class Initialized
INFO - 2021-06-17 05:34:06 --> Router Class Initialized
INFO - 2021-06-17 05:34:06 --> Output Class Initialized
INFO - 2021-06-17 05:34:06 --> Security Class Initialized
DEBUG - 2021-06-17 05:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:34:06 --> Input Class Initialized
INFO - 2021-06-17 05:34:06 --> Language Class Initialized
INFO - 2021-06-17 05:34:06 --> Language Class Initialized
INFO - 2021-06-17 05:34:06 --> Config Class Initialized
INFO - 2021-06-17 05:34:06 --> Loader Class Initialized
INFO - 2021-06-17 05:34:06 --> Helper loaded: url_helper
INFO - 2021-06-17 05:34:06 --> Helper loaded: file_helper
INFO - 2021-06-17 05:34:06 --> Helper loaded: form_helper
INFO - 2021-06-17 05:34:06 --> Helper loaded: my_helper
INFO - 2021-06-17 05:34:06 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:34:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:34:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:34:06 --> Controller Class Initialized
DEBUG - 2021-06-17 05:34:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-17 05:34:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 05:34:06 --> Final output sent to browser
DEBUG - 2021-06-17 05:34:06 --> Total execution time: 0.0483
INFO - 2021-06-17 05:34:09 --> Config Class Initialized
INFO - 2021-06-17 05:34:09 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:34:09 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:34:09 --> Utf8 Class Initialized
INFO - 2021-06-17 05:34:09 --> URI Class Initialized
INFO - 2021-06-17 05:34:09 --> Router Class Initialized
INFO - 2021-06-17 05:34:09 --> Output Class Initialized
INFO - 2021-06-17 05:34:09 --> Security Class Initialized
DEBUG - 2021-06-17 05:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:34:09 --> Input Class Initialized
INFO - 2021-06-17 05:34:09 --> Language Class Initialized
INFO - 2021-06-17 05:34:09 --> Language Class Initialized
INFO - 2021-06-17 05:34:09 --> Config Class Initialized
INFO - 2021-06-17 05:34:09 --> Loader Class Initialized
INFO - 2021-06-17 05:34:09 --> Helper loaded: url_helper
INFO - 2021-06-17 05:34:09 --> Helper loaded: file_helper
INFO - 2021-06-17 05:34:09 --> Helper loaded: form_helper
INFO - 2021-06-17 05:34:09 --> Helper loaded: my_helper
INFO - 2021-06-17 05:34:09 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:34:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:34:09 --> Controller Class Initialized
INFO - 2021-06-17 05:34:09 --> Helper loaded: cookie_helper
INFO - 2021-06-17 05:34:09 --> Final output sent to browser
DEBUG - 2021-06-17 05:34:09 --> Total execution time: 0.0477
INFO - 2021-06-17 05:34:15 --> Config Class Initialized
INFO - 2021-06-17 05:34:15 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:34:15 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:34:15 --> Utf8 Class Initialized
INFO - 2021-06-17 05:34:15 --> URI Class Initialized
INFO - 2021-06-17 05:34:15 --> Router Class Initialized
INFO - 2021-06-17 05:34:15 --> Output Class Initialized
INFO - 2021-06-17 05:34:15 --> Security Class Initialized
DEBUG - 2021-06-17 05:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:34:15 --> Input Class Initialized
INFO - 2021-06-17 05:34:15 --> Language Class Initialized
INFO - 2021-06-17 05:34:15 --> Language Class Initialized
INFO - 2021-06-17 05:34:15 --> Config Class Initialized
INFO - 2021-06-17 05:34:15 --> Loader Class Initialized
INFO - 2021-06-17 05:34:15 --> Helper loaded: url_helper
INFO - 2021-06-17 05:34:15 --> Helper loaded: file_helper
INFO - 2021-06-17 05:34:15 --> Helper loaded: form_helper
INFO - 2021-06-17 05:34:15 --> Helper loaded: my_helper
INFO - 2021-06-17 05:34:15 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:34:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:34:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:34:15 --> Controller Class Initialized
DEBUG - 2021-06-17 05:34:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-17 05:34:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 05:34:15 --> Final output sent to browser
DEBUG - 2021-06-17 05:34:15 --> Total execution time: 0.0513
INFO - 2021-06-17 05:34:15 --> Config Class Initialized
INFO - 2021-06-17 05:34:15 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:34:15 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:34:15 --> Utf8 Class Initialized
INFO - 2021-06-17 05:34:15 --> URI Class Initialized
INFO - 2021-06-17 05:34:15 --> Router Class Initialized
INFO - 2021-06-17 05:34:15 --> Output Class Initialized
INFO - 2021-06-17 05:34:15 --> Security Class Initialized
DEBUG - 2021-06-17 05:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:34:15 --> Input Class Initialized
INFO - 2021-06-17 05:34:15 --> Language Class Initialized
INFO - 2021-06-17 05:34:15 --> Language Class Initialized
INFO - 2021-06-17 05:34:15 --> Config Class Initialized
INFO - 2021-06-17 05:34:15 --> Loader Class Initialized
INFO - 2021-06-17 05:34:15 --> Helper loaded: url_helper
INFO - 2021-06-17 05:34:15 --> Helper loaded: file_helper
INFO - 2021-06-17 05:34:15 --> Helper loaded: form_helper
INFO - 2021-06-17 05:34:15 --> Helper loaded: my_helper
INFO - 2021-06-17 05:34:15 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:34:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:34:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:34:15 --> Controller Class Initialized
INFO - 2021-06-17 05:34:17 --> Config Class Initialized
INFO - 2021-06-17 05:34:17 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:34:17 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:34:17 --> Utf8 Class Initialized
INFO - 2021-06-17 05:34:17 --> URI Class Initialized
INFO - 2021-06-17 05:34:17 --> Router Class Initialized
INFO - 2021-06-17 05:34:17 --> Output Class Initialized
INFO - 2021-06-17 05:34:17 --> Security Class Initialized
DEBUG - 2021-06-17 05:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:34:17 --> Input Class Initialized
INFO - 2021-06-17 05:34:17 --> Language Class Initialized
INFO - 2021-06-17 05:34:17 --> Language Class Initialized
INFO - 2021-06-17 05:34:17 --> Config Class Initialized
INFO - 2021-06-17 05:34:17 --> Loader Class Initialized
INFO - 2021-06-17 05:34:17 --> Helper loaded: url_helper
INFO - 2021-06-17 05:34:17 --> Helper loaded: file_helper
INFO - 2021-06-17 05:34:17 --> Helper loaded: form_helper
INFO - 2021-06-17 05:34:17 --> Helper loaded: my_helper
INFO - 2021-06-17 05:34:17 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:34:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:34:17 --> Controller Class Initialized
DEBUG - 2021-06-17 05:34:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-17 05:34:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 05:34:17 --> Final output sent to browser
DEBUG - 2021-06-17 05:34:17 --> Total execution time: 0.1738
INFO - 2021-06-17 05:34:25 --> Config Class Initialized
INFO - 2021-06-17 05:34:25 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:34:25 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:34:25 --> Utf8 Class Initialized
INFO - 2021-06-17 05:34:25 --> URI Class Initialized
INFO - 2021-06-17 05:34:25 --> Router Class Initialized
INFO - 2021-06-17 05:34:25 --> Output Class Initialized
INFO - 2021-06-17 05:34:25 --> Security Class Initialized
DEBUG - 2021-06-17 05:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:34:25 --> Input Class Initialized
INFO - 2021-06-17 05:34:25 --> Language Class Initialized
INFO - 2021-06-17 05:34:25 --> Language Class Initialized
INFO - 2021-06-17 05:34:25 --> Config Class Initialized
INFO - 2021-06-17 05:34:25 --> Loader Class Initialized
INFO - 2021-06-17 05:34:25 --> Helper loaded: url_helper
INFO - 2021-06-17 05:34:25 --> Helper loaded: file_helper
INFO - 2021-06-17 05:34:25 --> Helper loaded: form_helper
INFO - 2021-06-17 05:34:25 --> Helper loaded: my_helper
INFO - 2021-06-17 05:34:25 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:34:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:34:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:34:25 --> Controller Class Initialized
DEBUG - 2021-06-17 05:34:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-17 05:34:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 05:34:25 --> Final output sent to browser
DEBUG - 2021-06-17 05:34:25 --> Total execution time: 0.0501
INFO - 2021-06-17 05:34:28 --> Config Class Initialized
INFO - 2021-06-17 05:34:28 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:34:28 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:34:28 --> Utf8 Class Initialized
INFO - 2021-06-17 05:34:28 --> URI Class Initialized
INFO - 2021-06-17 05:34:28 --> Router Class Initialized
INFO - 2021-06-17 05:34:28 --> Output Class Initialized
INFO - 2021-06-17 05:34:28 --> Security Class Initialized
DEBUG - 2021-06-17 05:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:34:28 --> Input Class Initialized
INFO - 2021-06-17 05:34:28 --> Language Class Initialized
INFO - 2021-06-17 05:34:28 --> Language Class Initialized
INFO - 2021-06-17 05:34:28 --> Config Class Initialized
INFO - 2021-06-17 05:34:28 --> Loader Class Initialized
INFO - 2021-06-17 05:34:28 --> Helper loaded: url_helper
INFO - 2021-06-17 05:34:28 --> Helper loaded: file_helper
INFO - 2021-06-17 05:34:28 --> Helper loaded: form_helper
INFO - 2021-06-17 05:34:28 --> Helper loaded: my_helper
INFO - 2021-06-17 05:34:28 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:34:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:34:28 --> Controller Class Initialized
DEBUG - 2021-06-17 05:34:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-17 05:34:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 05:34:28 --> Final output sent to browser
DEBUG - 2021-06-17 05:34:28 --> Total execution time: 0.0496
INFO - 2021-06-17 05:34:28 --> Config Class Initialized
INFO - 2021-06-17 05:34:28 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:34:28 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:34:28 --> Utf8 Class Initialized
INFO - 2021-06-17 05:34:28 --> URI Class Initialized
INFO - 2021-06-17 05:34:28 --> Router Class Initialized
INFO - 2021-06-17 05:34:28 --> Output Class Initialized
INFO - 2021-06-17 05:34:28 --> Security Class Initialized
DEBUG - 2021-06-17 05:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:34:28 --> Input Class Initialized
INFO - 2021-06-17 05:34:28 --> Language Class Initialized
INFO - 2021-06-17 05:34:28 --> Language Class Initialized
INFO - 2021-06-17 05:34:28 --> Config Class Initialized
INFO - 2021-06-17 05:34:28 --> Loader Class Initialized
INFO - 2021-06-17 05:34:28 --> Helper loaded: url_helper
INFO - 2021-06-17 05:34:28 --> Helper loaded: file_helper
INFO - 2021-06-17 05:34:28 --> Helper loaded: form_helper
INFO - 2021-06-17 05:34:28 --> Helper loaded: my_helper
INFO - 2021-06-17 05:34:28 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:34:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:34:28 --> Controller Class Initialized
INFO - 2021-06-17 05:34:37 --> Config Class Initialized
INFO - 2021-06-17 05:34:37 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:34:37 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:34:37 --> Utf8 Class Initialized
INFO - 2021-06-17 05:34:37 --> URI Class Initialized
INFO - 2021-06-17 05:34:37 --> Router Class Initialized
INFO - 2021-06-17 05:34:37 --> Output Class Initialized
INFO - 2021-06-17 05:34:37 --> Security Class Initialized
DEBUG - 2021-06-17 05:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:34:37 --> Input Class Initialized
INFO - 2021-06-17 05:34:37 --> Language Class Initialized
INFO - 2021-06-17 05:34:37 --> Language Class Initialized
INFO - 2021-06-17 05:34:37 --> Config Class Initialized
INFO - 2021-06-17 05:34:37 --> Loader Class Initialized
INFO - 2021-06-17 05:34:37 --> Helper loaded: url_helper
INFO - 2021-06-17 05:34:37 --> Helper loaded: file_helper
INFO - 2021-06-17 05:34:37 --> Helper loaded: form_helper
INFO - 2021-06-17 05:34:37 --> Helper loaded: my_helper
INFO - 2021-06-17 05:34:37 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:34:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:34:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:34:37 --> Controller Class Initialized
DEBUG - 2021-06-17 05:34:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-17 05:34:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 05:34:37 --> Final output sent to browser
DEBUG - 2021-06-17 05:34:37 --> Total execution time: 0.0507
INFO - 2021-06-17 05:34:40 --> Config Class Initialized
INFO - 2021-06-17 05:34:40 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:34:40 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:34:40 --> Utf8 Class Initialized
INFO - 2021-06-17 05:34:40 --> URI Class Initialized
INFO - 2021-06-17 05:34:40 --> Router Class Initialized
INFO - 2021-06-17 05:34:40 --> Output Class Initialized
INFO - 2021-06-17 05:34:40 --> Security Class Initialized
DEBUG - 2021-06-17 05:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:34:40 --> Input Class Initialized
INFO - 2021-06-17 05:34:40 --> Language Class Initialized
INFO - 2021-06-17 05:34:40 --> Language Class Initialized
INFO - 2021-06-17 05:34:40 --> Config Class Initialized
INFO - 2021-06-17 05:34:40 --> Loader Class Initialized
INFO - 2021-06-17 05:34:40 --> Helper loaded: url_helper
INFO - 2021-06-17 05:34:40 --> Helper loaded: file_helper
INFO - 2021-06-17 05:34:40 --> Helper loaded: form_helper
INFO - 2021-06-17 05:34:40 --> Helper loaded: my_helper
INFO - 2021-06-17 05:34:40 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:34:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:34:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:34:40 --> Controller Class Initialized
DEBUG - 2021-06-17 05:34:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-17 05:34:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 05:34:40 --> Final output sent to browser
DEBUG - 2021-06-17 05:34:40 --> Total execution time: 0.0393
INFO - 2021-06-17 05:34:40 --> Config Class Initialized
INFO - 2021-06-17 05:34:40 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:34:40 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:34:40 --> Utf8 Class Initialized
INFO - 2021-06-17 05:34:40 --> URI Class Initialized
INFO - 2021-06-17 05:34:40 --> Router Class Initialized
INFO - 2021-06-17 05:34:40 --> Output Class Initialized
INFO - 2021-06-17 05:34:40 --> Security Class Initialized
DEBUG - 2021-06-17 05:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:34:40 --> Input Class Initialized
INFO - 2021-06-17 05:34:40 --> Language Class Initialized
INFO - 2021-06-17 05:34:40 --> Language Class Initialized
INFO - 2021-06-17 05:34:40 --> Config Class Initialized
INFO - 2021-06-17 05:34:40 --> Loader Class Initialized
INFO - 2021-06-17 05:34:40 --> Helper loaded: url_helper
INFO - 2021-06-17 05:34:40 --> Helper loaded: file_helper
INFO - 2021-06-17 05:34:40 --> Helper loaded: form_helper
INFO - 2021-06-17 05:34:40 --> Helper loaded: my_helper
INFO - 2021-06-17 05:34:40 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:34:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:34:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:34:40 --> Controller Class Initialized
DEBUG - 2021-06-17 05:34:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-17 05:34:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 05:34:40 --> Final output sent to browser
DEBUG - 2021-06-17 05:34:40 --> Total execution time: 0.0500
INFO - 2021-06-17 05:34:41 --> Config Class Initialized
INFO - 2021-06-17 05:34:41 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:34:41 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:34:41 --> Utf8 Class Initialized
INFO - 2021-06-17 05:34:41 --> URI Class Initialized
INFO - 2021-06-17 05:34:41 --> Router Class Initialized
INFO - 2021-06-17 05:34:41 --> Output Class Initialized
INFO - 2021-06-17 05:34:41 --> Security Class Initialized
DEBUG - 2021-06-17 05:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:34:41 --> Input Class Initialized
INFO - 2021-06-17 05:34:41 --> Language Class Initialized
INFO - 2021-06-17 05:34:41 --> Language Class Initialized
INFO - 2021-06-17 05:34:41 --> Config Class Initialized
INFO - 2021-06-17 05:34:41 --> Loader Class Initialized
INFO - 2021-06-17 05:34:41 --> Helper loaded: url_helper
INFO - 2021-06-17 05:34:41 --> Helper loaded: file_helper
INFO - 2021-06-17 05:34:41 --> Helper loaded: form_helper
INFO - 2021-06-17 05:34:41 --> Helper loaded: my_helper
INFO - 2021-06-17 05:34:41 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:34:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:34:41 --> Controller Class Initialized
DEBUG - 2021-06-17 05:34:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 05:34:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 05:34:41 --> Final output sent to browser
DEBUG - 2021-06-17 05:34:41 --> Total execution time: 0.0496
INFO - 2021-06-17 05:34:49 --> Config Class Initialized
INFO - 2021-06-17 05:34:49 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:34:49 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:34:49 --> Utf8 Class Initialized
INFO - 2021-06-17 05:34:49 --> URI Class Initialized
INFO - 2021-06-17 05:34:49 --> Router Class Initialized
INFO - 2021-06-17 05:34:49 --> Output Class Initialized
INFO - 2021-06-17 05:34:49 --> Security Class Initialized
DEBUG - 2021-06-17 05:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:34:49 --> Input Class Initialized
INFO - 2021-06-17 05:34:49 --> Language Class Initialized
INFO - 2021-06-17 05:34:49 --> Language Class Initialized
INFO - 2021-06-17 05:34:49 --> Config Class Initialized
INFO - 2021-06-17 05:34:49 --> Loader Class Initialized
INFO - 2021-06-17 05:34:49 --> Helper loaded: url_helper
INFO - 2021-06-17 05:34:49 --> Helper loaded: file_helper
INFO - 2021-06-17 05:34:49 --> Helper loaded: form_helper
INFO - 2021-06-17 05:34:49 --> Helper loaded: my_helper
INFO - 2021-06-17 05:34:49 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:34:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:34:49 --> Controller Class Initialized
DEBUG - 2021-06-17 05:34:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-17 05:34:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 05:34:49 --> Final output sent to browser
DEBUG - 2021-06-17 05:34:49 --> Total execution time: 0.0500
INFO - 2021-06-17 05:35:19 --> Config Class Initialized
INFO - 2021-06-17 05:35:19 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:35:19 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:35:19 --> Utf8 Class Initialized
INFO - 2021-06-17 05:35:19 --> URI Class Initialized
INFO - 2021-06-17 05:35:19 --> Router Class Initialized
INFO - 2021-06-17 05:35:19 --> Output Class Initialized
INFO - 2021-06-17 05:35:19 --> Security Class Initialized
DEBUG - 2021-06-17 05:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:35:19 --> Input Class Initialized
INFO - 2021-06-17 05:35:19 --> Language Class Initialized
INFO - 2021-06-17 05:35:19 --> Language Class Initialized
INFO - 2021-06-17 05:35:19 --> Config Class Initialized
INFO - 2021-06-17 05:35:19 --> Loader Class Initialized
INFO - 2021-06-17 05:35:19 --> Helper loaded: url_helper
INFO - 2021-06-17 05:35:19 --> Helper loaded: file_helper
INFO - 2021-06-17 05:35:19 --> Helper loaded: form_helper
INFO - 2021-06-17 05:35:19 --> Helper loaded: my_helper
INFO - 2021-06-17 05:35:19 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:35:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:35:19 --> Controller Class Initialized
DEBUG - 2021-06-17 05:35:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-17 05:35:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 05:35:19 --> Final output sent to browser
DEBUG - 2021-06-17 05:35:19 --> Total execution time: 0.0491
INFO - 2021-06-17 05:35:31 --> Config Class Initialized
INFO - 2021-06-17 05:35:31 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:35:31 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:35:31 --> Utf8 Class Initialized
INFO - 2021-06-17 05:35:31 --> URI Class Initialized
INFO - 2021-06-17 05:35:31 --> Router Class Initialized
INFO - 2021-06-17 05:35:31 --> Output Class Initialized
INFO - 2021-06-17 05:35:31 --> Security Class Initialized
DEBUG - 2021-06-17 05:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:35:31 --> Input Class Initialized
INFO - 2021-06-17 05:35:31 --> Language Class Initialized
INFO - 2021-06-17 05:35:31 --> Language Class Initialized
INFO - 2021-06-17 05:35:31 --> Config Class Initialized
INFO - 2021-06-17 05:35:31 --> Loader Class Initialized
INFO - 2021-06-17 05:35:31 --> Helper loaded: url_helper
INFO - 2021-06-17 05:35:31 --> Helper loaded: file_helper
INFO - 2021-06-17 05:35:31 --> Helper loaded: form_helper
INFO - 2021-06-17 05:35:31 --> Helper loaded: my_helper
INFO - 2021-06-17 05:35:31 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:35:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:35:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:35:31 --> Controller Class Initialized
INFO - 2021-06-17 05:35:56 --> Config Class Initialized
INFO - 2021-06-17 05:35:56 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:35:56 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:35:56 --> Utf8 Class Initialized
INFO - 2021-06-17 05:35:56 --> URI Class Initialized
INFO - 2021-06-17 05:35:56 --> Router Class Initialized
INFO - 2021-06-17 05:35:56 --> Output Class Initialized
INFO - 2021-06-17 05:35:56 --> Security Class Initialized
DEBUG - 2021-06-17 05:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:35:56 --> Input Class Initialized
INFO - 2021-06-17 05:35:56 --> Language Class Initialized
INFO - 2021-06-17 05:35:56 --> Language Class Initialized
INFO - 2021-06-17 05:35:56 --> Config Class Initialized
INFO - 2021-06-17 05:35:56 --> Loader Class Initialized
INFO - 2021-06-17 05:35:56 --> Helper loaded: url_helper
INFO - 2021-06-17 05:35:56 --> Helper loaded: file_helper
INFO - 2021-06-17 05:35:56 --> Helper loaded: form_helper
INFO - 2021-06-17 05:35:56 --> Helper loaded: my_helper
INFO - 2021-06-17 05:35:56 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:35:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:35:56 --> Controller Class Initialized
INFO - 2021-06-17 05:35:56 --> Final output sent to browser
DEBUG - 2021-06-17 05:35:56 --> Total execution time: 0.0452
INFO - 2021-06-17 05:36:01 --> Config Class Initialized
INFO - 2021-06-17 05:36:01 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:36:01 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:36:01 --> Utf8 Class Initialized
INFO - 2021-06-17 05:36:01 --> URI Class Initialized
INFO - 2021-06-17 05:36:01 --> Router Class Initialized
INFO - 2021-06-17 05:36:01 --> Output Class Initialized
INFO - 2021-06-17 05:36:01 --> Security Class Initialized
DEBUG - 2021-06-17 05:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:36:01 --> Input Class Initialized
INFO - 2021-06-17 05:36:01 --> Language Class Initialized
INFO - 2021-06-17 05:36:01 --> Language Class Initialized
INFO - 2021-06-17 05:36:01 --> Config Class Initialized
INFO - 2021-06-17 05:36:01 --> Loader Class Initialized
INFO - 2021-06-17 05:36:01 --> Helper loaded: url_helper
INFO - 2021-06-17 05:36:01 --> Helper loaded: file_helper
INFO - 2021-06-17 05:36:01 --> Helper loaded: form_helper
INFO - 2021-06-17 05:36:01 --> Helper loaded: my_helper
INFO - 2021-06-17 05:36:01 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:36:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:36:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:36:01 --> Controller Class Initialized
INFO - 2021-06-17 05:36:01 --> Final output sent to browser
DEBUG - 2021-06-17 05:36:01 --> Total execution time: 0.0363
INFO - 2021-06-17 05:36:06 --> Config Class Initialized
INFO - 2021-06-17 05:36:06 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:36:06 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:36:06 --> Utf8 Class Initialized
INFO - 2021-06-17 05:36:06 --> URI Class Initialized
INFO - 2021-06-17 05:36:06 --> Router Class Initialized
INFO - 2021-06-17 05:36:06 --> Output Class Initialized
INFO - 2021-06-17 05:36:06 --> Security Class Initialized
DEBUG - 2021-06-17 05:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:36:06 --> Input Class Initialized
INFO - 2021-06-17 05:36:06 --> Language Class Initialized
INFO - 2021-06-17 05:36:06 --> Language Class Initialized
INFO - 2021-06-17 05:36:06 --> Config Class Initialized
INFO - 2021-06-17 05:36:06 --> Loader Class Initialized
INFO - 2021-06-17 05:36:06 --> Helper loaded: url_helper
INFO - 2021-06-17 05:36:06 --> Helper loaded: file_helper
INFO - 2021-06-17 05:36:06 --> Helper loaded: form_helper
INFO - 2021-06-17 05:36:06 --> Helper loaded: my_helper
INFO - 2021-06-17 05:36:06 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:36:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:36:06 --> Controller Class Initialized
INFO - 2021-06-17 05:36:06 --> Final output sent to browser
DEBUG - 2021-06-17 05:36:06 --> Total execution time: 0.0454
INFO - 2021-06-17 05:36:46 --> Config Class Initialized
INFO - 2021-06-17 05:36:46 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:36:46 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:36:46 --> Utf8 Class Initialized
INFO - 2021-06-17 05:36:46 --> URI Class Initialized
INFO - 2021-06-17 05:36:46 --> Router Class Initialized
INFO - 2021-06-17 05:36:46 --> Output Class Initialized
INFO - 2021-06-17 05:36:46 --> Security Class Initialized
DEBUG - 2021-06-17 05:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:36:46 --> Input Class Initialized
INFO - 2021-06-17 05:36:46 --> Language Class Initialized
INFO - 2021-06-17 05:36:46 --> Language Class Initialized
INFO - 2021-06-17 05:36:46 --> Config Class Initialized
INFO - 2021-06-17 05:36:46 --> Loader Class Initialized
INFO - 2021-06-17 05:36:46 --> Helper loaded: url_helper
INFO - 2021-06-17 05:36:46 --> Helper loaded: file_helper
INFO - 2021-06-17 05:36:46 --> Helper loaded: form_helper
INFO - 2021-06-17 05:36:46 --> Helper loaded: my_helper
INFO - 2021-06-17 05:36:46 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:36:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:36:46 --> Controller Class Initialized
INFO - 2021-06-17 05:36:46 --> Final output sent to browser
DEBUG - 2021-06-17 05:36:46 --> Total execution time: 0.0474
INFO - 2021-06-17 05:36:46 --> Config Class Initialized
INFO - 2021-06-17 05:36:46 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:36:46 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:36:46 --> Utf8 Class Initialized
INFO - 2021-06-17 05:36:46 --> URI Class Initialized
INFO - 2021-06-17 05:36:46 --> Router Class Initialized
INFO - 2021-06-17 05:36:46 --> Output Class Initialized
INFO - 2021-06-17 05:36:46 --> Security Class Initialized
DEBUG - 2021-06-17 05:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:36:46 --> Input Class Initialized
INFO - 2021-06-17 05:36:46 --> Language Class Initialized
INFO - 2021-06-17 05:36:46 --> Language Class Initialized
INFO - 2021-06-17 05:36:46 --> Config Class Initialized
INFO - 2021-06-17 05:36:46 --> Loader Class Initialized
INFO - 2021-06-17 05:36:46 --> Helper loaded: url_helper
INFO - 2021-06-17 05:36:46 --> Helper loaded: file_helper
INFO - 2021-06-17 05:36:46 --> Helper loaded: form_helper
INFO - 2021-06-17 05:36:46 --> Helper loaded: my_helper
INFO - 2021-06-17 05:36:46 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:36:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:36:46 --> Controller Class Initialized
INFO - 2021-06-17 05:36:49 --> Config Class Initialized
INFO - 2021-06-17 05:36:49 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:36:49 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:36:49 --> Utf8 Class Initialized
INFO - 2021-06-17 05:36:49 --> URI Class Initialized
INFO - 2021-06-17 05:36:49 --> Router Class Initialized
INFO - 2021-06-17 05:36:49 --> Output Class Initialized
INFO - 2021-06-17 05:36:49 --> Security Class Initialized
DEBUG - 2021-06-17 05:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:36:49 --> Input Class Initialized
INFO - 2021-06-17 05:36:49 --> Language Class Initialized
INFO - 2021-06-17 05:36:49 --> Language Class Initialized
INFO - 2021-06-17 05:36:49 --> Config Class Initialized
INFO - 2021-06-17 05:36:49 --> Loader Class Initialized
INFO - 2021-06-17 05:36:49 --> Helper loaded: url_helper
INFO - 2021-06-17 05:36:49 --> Helper loaded: file_helper
INFO - 2021-06-17 05:36:49 --> Helper loaded: form_helper
INFO - 2021-06-17 05:36:49 --> Helper loaded: my_helper
INFO - 2021-06-17 05:36:49 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:36:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:36:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:36:49 --> Controller Class Initialized
INFO - 2021-06-17 05:36:49 --> Final output sent to browser
DEBUG - 2021-06-17 05:36:49 --> Total execution time: 0.0456
INFO - 2021-06-17 05:37:04 --> Config Class Initialized
INFO - 2021-06-17 05:37:04 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:37:04 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:37:04 --> Utf8 Class Initialized
INFO - 2021-06-17 05:37:04 --> URI Class Initialized
INFO - 2021-06-17 05:37:04 --> Router Class Initialized
INFO - 2021-06-17 05:37:04 --> Output Class Initialized
INFO - 2021-06-17 05:37:04 --> Security Class Initialized
DEBUG - 2021-06-17 05:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:37:04 --> Input Class Initialized
INFO - 2021-06-17 05:37:04 --> Language Class Initialized
INFO - 2021-06-17 05:37:04 --> Language Class Initialized
INFO - 2021-06-17 05:37:04 --> Config Class Initialized
INFO - 2021-06-17 05:37:04 --> Loader Class Initialized
INFO - 2021-06-17 05:37:04 --> Helper loaded: url_helper
INFO - 2021-06-17 05:37:04 --> Helper loaded: file_helper
INFO - 2021-06-17 05:37:04 --> Helper loaded: form_helper
INFO - 2021-06-17 05:37:04 --> Helper loaded: my_helper
INFO - 2021-06-17 05:37:04 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:37:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:37:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:37:04 --> Controller Class Initialized
INFO - 2021-06-17 05:37:04 --> Final output sent to browser
DEBUG - 2021-06-17 05:37:04 --> Total execution time: 0.0388
INFO - 2021-06-17 05:37:04 --> Config Class Initialized
INFO - 2021-06-17 05:37:04 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:37:04 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:37:04 --> Utf8 Class Initialized
INFO - 2021-06-17 05:37:04 --> URI Class Initialized
INFO - 2021-06-17 05:37:04 --> Router Class Initialized
INFO - 2021-06-17 05:37:04 --> Output Class Initialized
INFO - 2021-06-17 05:37:04 --> Security Class Initialized
DEBUG - 2021-06-17 05:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:37:04 --> Input Class Initialized
INFO - 2021-06-17 05:37:04 --> Language Class Initialized
INFO - 2021-06-17 05:37:04 --> Language Class Initialized
INFO - 2021-06-17 05:37:04 --> Config Class Initialized
INFO - 2021-06-17 05:37:04 --> Loader Class Initialized
INFO - 2021-06-17 05:37:04 --> Helper loaded: url_helper
INFO - 2021-06-17 05:37:04 --> Helper loaded: file_helper
INFO - 2021-06-17 05:37:04 --> Helper loaded: form_helper
INFO - 2021-06-17 05:37:04 --> Helper loaded: my_helper
INFO - 2021-06-17 05:37:04 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:37:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:37:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:37:04 --> Controller Class Initialized
INFO - 2021-06-17 05:37:07 --> Config Class Initialized
INFO - 2021-06-17 05:37:07 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:37:07 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:37:07 --> Utf8 Class Initialized
INFO - 2021-06-17 05:37:07 --> URI Class Initialized
INFO - 2021-06-17 05:37:07 --> Router Class Initialized
INFO - 2021-06-17 05:37:07 --> Output Class Initialized
INFO - 2021-06-17 05:37:07 --> Security Class Initialized
DEBUG - 2021-06-17 05:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:37:07 --> Input Class Initialized
INFO - 2021-06-17 05:37:07 --> Language Class Initialized
INFO - 2021-06-17 05:37:07 --> Language Class Initialized
INFO - 2021-06-17 05:37:07 --> Config Class Initialized
INFO - 2021-06-17 05:37:07 --> Loader Class Initialized
INFO - 2021-06-17 05:37:07 --> Helper loaded: url_helper
INFO - 2021-06-17 05:37:07 --> Helper loaded: file_helper
INFO - 2021-06-17 05:37:07 --> Helper loaded: form_helper
INFO - 2021-06-17 05:37:07 --> Helper loaded: my_helper
INFO - 2021-06-17 05:37:07 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:37:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:37:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:37:07 --> Controller Class Initialized
INFO - 2021-06-17 05:37:07 --> Final output sent to browser
DEBUG - 2021-06-17 05:37:07 --> Total execution time: 0.0462
INFO - 2021-06-17 05:37:35 --> Config Class Initialized
INFO - 2021-06-17 05:37:35 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:37:35 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:37:35 --> Utf8 Class Initialized
INFO - 2021-06-17 05:37:35 --> URI Class Initialized
INFO - 2021-06-17 05:37:35 --> Router Class Initialized
INFO - 2021-06-17 05:37:35 --> Output Class Initialized
INFO - 2021-06-17 05:37:35 --> Security Class Initialized
DEBUG - 2021-06-17 05:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:37:35 --> Input Class Initialized
INFO - 2021-06-17 05:37:35 --> Language Class Initialized
INFO - 2021-06-17 05:37:35 --> Language Class Initialized
INFO - 2021-06-17 05:37:35 --> Config Class Initialized
INFO - 2021-06-17 05:37:35 --> Loader Class Initialized
INFO - 2021-06-17 05:37:35 --> Helper loaded: url_helper
INFO - 2021-06-17 05:37:35 --> Helper loaded: file_helper
INFO - 2021-06-17 05:37:35 --> Helper loaded: form_helper
INFO - 2021-06-17 05:37:35 --> Helper loaded: my_helper
INFO - 2021-06-17 05:37:35 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:37:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:37:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:37:35 --> Controller Class Initialized
INFO - 2021-06-17 05:37:35 --> Final output sent to browser
DEBUG - 2021-06-17 05:37:35 --> Total execution time: 0.0475
INFO - 2021-06-17 05:37:35 --> Config Class Initialized
INFO - 2021-06-17 05:37:35 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:37:35 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:37:35 --> Utf8 Class Initialized
INFO - 2021-06-17 05:37:35 --> URI Class Initialized
INFO - 2021-06-17 05:37:35 --> Router Class Initialized
INFO - 2021-06-17 05:37:35 --> Output Class Initialized
INFO - 2021-06-17 05:37:35 --> Security Class Initialized
DEBUG - 2021-06-17 05:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:37:35 --> Input Class Initialized
INFO - 2021-06-17 05:37:35 --> Language Class Initialized
INFO - 2021-06-17 05:37:35 --> Language Class Initialized
INFO - 2021-06-17 05:37:35 --> Config Class Initialized
INFO - 2021-06-17 05:37:35 --> Loader Class Initialized
INFO - 2021-06-17 05:37:35 --> Helper loaded: url_helper
INFO - 2021-06-17 05:37:35 --> Helper loaded: file_helper
INFO - 2021-06-17 05:37:35 --> Helper loaded: form_helper
INFO - 2021-06-17 05:37:35 --> Helper loaded: my_helper
INFO - 2021-06-17 05:37:35 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:37:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:37:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:37:35 --> Controller Class Initialized
INFO - 2021-06-17 05:37:53 --> Config Class Initialized
INFO - 2021-06-17 05:37:53 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:37:53 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:37:53 --> Utf8 Class Initialized
INFO - 2021-06-17 05:37:53 --> URI Class Initialized
INFO - 2021-06-17 05:37:53 --> Router Class Initialized
INFO - 2021-06-17 05:37:53 --> Output Class Initialized
INFO - 2021-06-17 05:37:53 --> Security Class Initialized
DEBUG - 2021-06-17 05:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:37:53 --> Input Class Initialized
INFO - 2021-06-17 05:37:53 --> Language Class Initialized
INFO - 2021-06-17 05:37:53 --> Language Class Initialized
INFO - 2021-06-17 05:37:53 --> Config Class Initialized
INFO - 2021-06-17 05:37:53 --> Loader Class Initialized
INFO - 2021-06-17 05:37:53 --> Helper loaded: url_helper
INFO - 2021-06-17 05:37:53 --> Helper loaded: file_helper
INFO - 2021-06-17 05:37:53 --> Helper loaded: form_helper
INFO - 2021-06-17 05:37:53 --> Helper loaded: my_helper
INFO - 2021-06-17 05:37:53 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:37:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:37:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:37:53 --> Controller Class Initialized
INFO - 2021-06-17 05:37:53 --> Final output sent to browser
DEBUG - 2021-06-17 05:37:53 --> Total execution time: 0.0451
INFO - 2021-06-17 05:37:55 --> Config Class Initialized
INFO - 2021-06-17 05:37:55 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:37:55 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:37:55 --> Utf8 Class Initialized
INFO - 2021-06-17 05:37:55 --> URI Class Initialized
INFO - 2021-06-17 05:37:55 --> Router Class Initialized
INFO - 2021-06-17 05:37:55 --> Output Class Initialized
INFO - 2021-06-17 05:37:55 --> Security Class Initialized
DEBUG - 2021-06-17 05:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:37:55 --> Input Class Initialized
INFO - 2021-06-17 05:37:55 --> Language Class Initialized
INFO - 2021-06-17 05:37:55 --> Language Class Initialized
INFO - 2021-06-17 05:37:55 --> Config Class Initialized
INFO - 2021-06-17 05:37:55 --> Loader Class Initialized
INFO - 2021-06-17 05:37:55 --> Helper loaded: url_helper
INFO - 2021-06-17 05:37:55 --> Helper loaded: file_helper
INFO - 2021-06-17 05:37:55 --> Helper loaded: form_helper
INFO - 2021-06-17 05:37:55 --> Helper loaded: my_helper
INFO - 2021-06-17 05:37:55 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:37:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:37:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:37:55 --> Controller Class Initialized
INFO - 2021-06-17 05:37:55 --> Final output sent to browser
DEBUG - 2021-06-17 05:37:55 --> Total execution time: 0.0467
INFO - 2021-06-17 05:38:12 --> Config Class Initialized
INFO - 2021-06-17 05:38:12 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:38:12 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:38:12 --> Utf8 Class Initialized
INFO - 2021-06-17 05:38:12 --> URI Class Initialized
INFO - 2021-06-17 05:38:12 --> Router Class Initialized
INFO - 2021-06-17 05:38:12 --> Output Class Initialized
INFO - 2021-06-17 05:38:12 --> Security Class Initialized
DEBUG - 2021-06-17 05:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:38:12 --> Input Class Initialized
INFO - 2021-06-17 05:38:12 --> Language Class Initialized
INFO - 2021-06-17 05:38:12 --> Language Class Initialized
INFO - 2021-06-17 05:38:12 --> Config Class Initialized
INFO - 2021-06-17 05:38:12 --> Loader Class Initialized
INFO - 2021-06-17 05:38:12 --> Helper loaded: url_helper
INFO - 2021-06-17 05:38:12 --> Helper loaded: file_helper
INFO - 2021-06-17 05:38:12 --> Helper loaded: form_helper
INFO - 2021-06-17 05:38:12 --> Helper loaded: my_helper
INFO - 2021-06-17 05:38:12 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:38:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:38:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:38:12 --> Controller Class Initialized
INFO - 2021-06-17 05:38:12 --> Final output sent to browser
DEBUG - 2021-06-17 05:38:12 --> Total execution time: 0.0522
INFO - 2021-06-17 05:38:12 --> Config Class Initialized
INFO - 2021-06-17 05:38:12 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:38:12 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:38:12 --> Utf8 Class Initialized
INFO - 2021-06-17 05:38:12 --> URI Class Initialized
INFO - 2021-06-17 05:38:12 --> Router Class Initialized
INFO - 2021-06-17 05:38:12 --> Output Class Initialized
INFO - 2021-06-17 05:38:12 --> Security Class Initialized
DEBUG - 2021-06-17 05:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:38:12 --> Input Class Initialized
INFO - 2021-06-17 05:38:12 --> Language Class Initialized
INFO - 2021-06-17 05:38:12 --> Language Class Initialized
INFO - 2021-06-17 05:38:12 --> Config Class Initialized
INFO - 2021-06-17 05:38:12 --> Loader Class Initialized
INFO - 2021-06-17 05:38:12 --> Helper loaded: url_helper
INFO - 2021-06-17 05:38:12 --> Helper loaded: file_helper
INFO - 2021-06-17 05:38:12 --> Helper loaded: form_helper
INFO - 2021-06-17 05:38:12 --> Helper loaded: my_helper
INFO - 2021-06-17 05:38:12 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:38:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:38:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:38:12 --> Controller Class Initialized
INFO - 2021-06-17 05:38:19 --> Config Class Initialized
INFO - 2021-06-17 05:38:19 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:38:19 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:38:19 --> Utf8 Class Initialized
INFO - 2021-06-17 05:38:19 --> URI Class Initialized
INFO - 2021-06-17 05:38:19 --> Router Class Initialized
INFO - 2021-06-17 05:38:19 --> Output Class Initialized
INFO - 2021-06-17 05:38:19 --> Security Class Initialized
DEBUG - 2021-06-17 05:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:38:19 --> Input Class Initialized
INFO - 2021-06-17 05:38:19 --> Language Class Initialized
INFO - 2021-06-17 05:38:19 --> Language Class Initialized
INFO - 2021-06-17 05:38:19 --> Config Class Initialized
INFO - 2021-06-17 05:38:19 --> Loader Class Initialized
INFO - 2021-06-17 05:38:19 --> Helper loaded: url_helper
INFO - 2021-06-17 05:38:19 --> Helper loaded: file_helper
INFO - 2021-06-17 05:38:19 --> Helper loaded: form_helper
INFO - 2021-06-17 05:38:19 --> Helper loaded: my_helper
INFO - 2021-06-17 05:38:19 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:38:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:38:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:38:19 --> Controller Class Initialized
INFO - 2021-06-17 05:38:19 --> Final output sent to browser
DEBUG - 2021-06-17 05:38:19 --> Total execution time: 0.0423
INFO - 2021-06-17 05:38:53 --> Config Class Initialized
INFO - 2021-06-17 05:38:53 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:38:53 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:38:53 --> Utf8 Class Initialized
INFO - 2021-06-17 05:38:53 --> URI Class Initialized
INFO - 2021-06-17 05:38:53 --> Router Class Initialized
INFO - 2021-06-17 05:38:53 --> Output Class Initialized
INFO - 2021-06-17 05:38:53 --> Security Class Initialized
DEBUG - 2021-06-17 05:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:38:53 --> Input Class Initialized
INFO - 2021-06-17 05:38:53 --> Language Class Initialized
INFO - 2021-06-17 05:38:53 --> Language Class Initialized
INFO - 2021-06-17 05:38:53 --> Config Class Initialized
INFO - 2021-06-17 05:38:53 --> Loader Class Initialized
INFO - 2021-06-17 05:38:53 --> Helper loaded: url_helper
INFO - 2021-06-17 05:38:53 --> Helper loaded: file_helper
INFO - 2021-06-17 05:38:53 --> Helper loaded: form_helper
INFO - 2021-06-17 05:38:53 --> Helper loaded: my_helper
INFO - 2021-06-17 05:38:53 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:38:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:38:53 --> Controller Class Initialized
INFO - 2021-06-17 05:38:53 --> Final output sent to browser
DEBUG - 2021-06-17 05:38:53 --> Total execution time: 0.0484
INFO - 2021-06-17 05:38:53 --> Config Class Initialized
INFO - 2021-06-17 05:38:53 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:38:53 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:38:53 --> Utf8 Class Initialized
INFO - 2021-06-17 05:38:53 --> URI Class Initialized
INFO - 2021-06-17 05:38:53 --> Router Class Initialized
INFO - 2021-06-17 05:38:53 --> Output Class Initialized
INFO - 2021-06-17 05:38:53 --> Security Class Initialized
DEBUG - 2021-06-17 05:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:38:53 --> Input Class Initialized
INFO - 2021-06-17 05:38:53 --> Language Class Initialized
INFO - 2021-06-17 05:38:53 --> Language Class Initialized
INFO - 2021-06-17 05:38:53 --> Config Class Initialized
INFO - 2021-06-17 05:38:53 --> Loader Class Initialized
INFO - 2021-06-17 05:38:53 --> Helper loaded: url_helper
INFO - 2021-06-17 05:38:53 --> Helper loaded: file_helper
INFO - 2021-06-17 05:38:53 --> Helper loaded: form_helper
INFO - 2021-06-17 05:38:53 --> Helper loaded: my_helper
INFO - 2021-06-17 05:38:53 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:38:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:38:53 --> Controller Class Initialized
INFO - 2021-06-17 05:38:59 --> Config Class Initialized
INFO - 2021-06-17 05:38:59 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:38:59 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:38:59 --> Utf8 Class Initialized
INFO - 2021-06-17 05:38:59 --> URI Class Initialized
INFO - 2021-06-17 05:38:59 --> Router Class Initialized
INFO - 2021-06-17 05:38:59 --> Output Class Initialized
INFO - 2021-06-17 05:38:59 --> Security Class Initialized
DEBUG - 2021-06-17 05:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:38:59 --> Input Class Initialized
INFO - 2021-06-17 05:38:59 --> Language Class Initialized
INFO - 2021-06-17 05:38:59 --> Language Class Initialized
INFO - 2021-06-17 05:38:59 --> Config Class Initialized
INFO - 2021-06-17 05:38:59 --> Loader Class Initialized
INFO - 2021-06-17 05:38:59 --> Helper loaded: url_helper
INFO - 2021-06-17 05:38:59 --> Helper loaded: file_helper
INFO - 2021-06-17 05:38:59 --> Helper loaded: form_helper
INFO - 2021-06-17 05:38:59 --> Helper loaded: my_helper
INFO - 2021-06-17 05:38:59 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:39:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:39:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:39:00 --> Controller Class Initialized
INFO - 2021-06-17 05:39:00 --> Final output sent to browser
DEBUG - 2021-06-17 05:39:00 --> Total execution time: 0.0484
INFO - 2021-06-17 05:39:00 --> Config Class Initialized
INFO - 2021-06-17 05:39:00 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:39:00 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:39:00 --> Utf8 Class Initialized
INFO - 2021-06-17 05:39:00 --> URI Class Initialized
INFO - 2021-06-17 05:39:00 --> Router Class Initialized
INFO - 2021-06-17 05:39:00 --> Output Class Initialized
INFO - 2021-06-17 05:39:00 --> Security Class Initialized
DEBUG - 2021-06-17 05:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:39:00 --> Input Class Initialized
INFO - 2021-06-17 05:39:00 --> Language Class Initialized
INFO - 2021-06-17 05:39:00 --> Language Class Initialized
INFO - 2021-06-17 05:39:00 --> Config Class Initialized
INFO - 2021-06-17 05:39:00 --> Loader Class Initialized
INFO - 2021-06-17 05:39:00 --> Helper loaded: url_helper
INFO - 2021-06-17 05:39:00 --> Helper loaded: file_helper
INFO - 2021-06-17 05:39:00 --> Helper loaded: form_helper
INFO - 2021-06-17 05:39:00 --> Helper loaded: my_helper
INFO - 2021-06-17 05:39:00 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:39:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:39:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:39:00 --> Controller Class Initialized
INFO - 2021-06-17 05:39:00 --> Final output sent to browser
DEBUG - 2021-06-17 05:39:00 --> Total execution time: 0.0364
INFO - 2021-06-17 05:39:25 --> Config Class Initialized
INFO - 2021-06-17 05:39:25 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:39:25 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:39:25 --> Utf8 Class Initialized
INFO - 2021-06-17 05:39:25 --> URI Class Initialized
INFO - 2021-06-17 05:39:25 --> Router Class Initialized
INFO - 2021-06-17 05:39:25 --> Output Class Initialized
INFO - 2021-06-17 05:39:25 --> Security Class Initialized
DEBUG - 2021-06-17 05:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:39:25 --> Input Class Initialized
INFO - 2021-06-17 05:39:25 --> Language Class Initialized
INFO - 2021-06-17 05:39:25 --> Language Class Initialized
INFO - 2021-06-17 05:39:25 --> Config Class Initialized
INFO - 2021-06-17 05:39:25 --> Loader Class Initialized
INFO - 2021-06-17 05:39:25 --> Helper loaded: url_helper
INFO - 2021-06-17 05:39:25 --> Helper loaded: file_helper
INFO - 2021-06-17 05:39:25 --> Helper loaded: form_helper
INFO - 2021-06-17 05:39:25 --> Helper loaded: my_helper
INFO - 2021-06-17 05:39:25 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:39:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:39:25 --> Controller Class Initialized
INFO - 2021-06-17 05:39:25 --> Final output sent to browser
DEBUG - 2021-06-17 05:39:25 --> Total execution time: 0.0487
INFO - 2021-06-17 05:39:25 --> Config Class Initialized
INFO - 2021-06-17 05:39:25 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:39:25 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:39:25 --> Utf8 Class Initialized
INFO - 2021-06-17 05:39:25 --> URI Class Initialized
INFO - 2021-06-17 05:39:25 --> Router Class Initialized
INFO - 2021-06-17 05:39:25 --> Output Class Initialized
INFO - 2021-06-17 05:39:25 --> Security Class Initialized
DEBUG - 2021-06-17 05:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:39:25 --> Input Class Initialized
INFO - 2021-06-17 05:39:25 --> Language Class Initialized
INFO - 2021-06-17 05:39:25 --> Language Class Initialized
INFO - 2021-06-17 05:39:25 --> Config Class Initialized
INFO - 2021-06-17 05:39:25 --> Loader Class Initialized
INFO - 2021-06-17 05:39:25 --> Helper loaded: url_helper
INFO - 2021-06-17 05:39:25 --> Helper loaded: file_helper
INFO - 2021-06-17 05:39:25 --> Helper loaded: form_helper
INFO - 2021-06-17 05:39:25 --> Helper loaded: my_helper
INFO - 2021-06-17 05:39:25 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:39:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:39:25 --> Controller Class Initialized
INFO - 2021-06-17 05:40:01 --> Config Class Initialized
INFO - 2021-06-17 05:40:01 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:40:01 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:40:01 --> Utf8 Class Initialized
INFO - 2021-06-17 05:40:01 --> URI Class Initialized
INFO - 2021-06-17 05:40:01 --> Router Class Initialized
INFO - 2021-06-17 05:40:01 --> Output Class Initialized
INFO - 2021-06-17 05:40:01 --> Security Class Initialized
DEBUG - 2021-06-17 05:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:40:01 --> Input Class Initialized
INFO - 2021-06-17 05:40:01 --> Language Class Initialized
INFO - 2021-06-17 05:40:01 --> Language Class Initialized
INFO - 2021-06-17 05:40:01 --> Config Class Initialized
INFO - 2021-06-17 05:40:01 --> Loader Class Initialized
INFO - 2021-06-17 05:40:01 --> Helper loaded: url_helper
INFO - 2021-06-17 05:40:01 --> Helper loaded: file_helper
INFO - 2021-06-17 05:40:01 --> Helper loaded: form_helper
INFO - 2021-06-17 05:40:01 --> Helper loaded: my_helper
INFO - 2021-06-17 05:40:01 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:40:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:40:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:40:01 --> Controller Class Initialized
DEBUG - 2021-06-17 05:40:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-17 05:40:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 05:40:01 --> Final output sent to browser
DEBUG - 2021-06-17 05:40:01 --> Total execution time: 0.0385
INFO - 2021-06-17 05:40:16 --> Config Class Initialized
INFO - 2021-06-17 05:40:16 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:40:16 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:40:16 --> Utf8 Class Initialized
INFO - 2021-06-17 05:40:16 --> URI Class Initialized
INFO - 2021-06-17 05:40:16 --> Router Class Initialized
INFO - 2021-06-17 05:40:16 --> Output Class Initialized
INFO - 2021-06-17 05:40:16 --> Security Class Initialized
DEBUG - 2021-06-17 05:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:40:16 --> Input Class Initialized
INFO - 2021-06-17 05:40:16 --> Language Class Initialized
INFO - 2021-06-17 05:40:16 --> Language Class Initialized
INFO - 2021-06-17 05:40:16 --> Config Class Initialized
INFO - 2021-06-17 05:40:16 --> Loader Class Initialized
INFO - 2021-06-17 05:40:16 --> Helper loaded: url_helper
INFO - 2021-06-17 05:40:16 --> Helper loaded: file_helper
INFO - 2021-06-17 05:40:16 --> Helper loaded: form_helper
INFO - 2021-06-17 05:40:16 --> Helper loaded: my_helper
INFO - 2021-06-17 05:40:16 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:40:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:40:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:40:16 --> Controller Class Initialized
DEBUG - 2021-06-17 05:40:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 05:40:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 05:40:16 --> Final output sent to browser
DEBUG - 2021-06-17 05:40:16 --> Total execution time: 0.0591
INFO - 2021-06-17 05:40:23 --> Config Class Initialized
INFO - 2021-06-17 05:40:23 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:40:23 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:40:23 --> Utf8 Class Initialized
INFO - 2021-06-17 05:40:23 --> URI Class Initialized
INFO - 2021-06-17 05:40:23 --> Router Class Initialized
INFO - 2021-06-17 05:40:23 --> Output Class Initialized
INFO - 2021-06-17 05:40:23 --> Security Class Initialized
DEBUG - 2021-06-17 05:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:40:23 --> Input Class Initialized
INFO - 2021-06-17 05:40:23 --> Language Class Initialized
INFO - 2021-06-17 05:40:23 --> Language Class Initialized
INFO - 2021-06-17 05:40:23 --> Config Class Initialized
INFO - 2021-06-17 05:40:23 --> Loader Class Initialized
INFO - 2021-06-17 05:40:23 --> Helper loaded: url_helper
INFO - 2021-06-17 05:40:23 --> Helper loaded: file_helper
INFO - 2021-06-17 05:40:23 --> Helper loaded: form_helper
INFO - 2021-06-17 05:40:23 --> Helper loaded: my_helper
INFO - 2021-06-17 05:40:23 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:40:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:40:23 --> Controller Class Initialized
DEBUG - 2021-06-17 05:40:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-17 05:40:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 05:40:23 --> Final output sent to browser
DEBUG - 2021-06-17 05:40:23 --> Total execution time: 0.0521
INFO - 2021-06-17 05:40:33 --> Config Class Initialized
INFO - 2021-06-17 05:40:33 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:40:33 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:40:33 --> Utf8 Class Initialized
INFO - 2021-06-17 05:40:33 --> URI Class Initialized
INFO - 2021-06-17 05:40:33 --> Router Class Initialized
INFO - 2021-06-17 05:40:33 --> Output Class Initialized
INFO - 2021-06-17 05:40:33 --> Security Class Initialized
DEBUG - 2021-06-17 05:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:40:33 --> Input Class Initialized
INFO - 2021-06-17 05:40:33 --> Language Class Initialized
INFO - 2021-06-17 05:40:33 --> Language Class Initialized
INFO - 2021-06-17 05:40:33 --> Config Class Initialized
INFO - 2021-06-17 05:40:33 --> Loader Class Initialized
INFO - 2021-06-17 05:40:33 --> Helper loaded: url_helper
INFO - 2021-06-17 05:40:33 --> Helper loaded: file_helper
INFO - 2021-06-17 05:40:33 --> Helper loaded: form_helper
INFO - 2021-06-17 05:40:33 --> Helper loaded: my_helper
INFO - 2021-06-17 05:40:33 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:40:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:40:33 --> Controller Class Initialized
DEBUG - 2021-06-17 05:40:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 05:40:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 05:40:33 --> Final output sent to browser
DEBUG - 2021-06-17 05:40:33 --> Total execution time: 0.0461
INFO - 2021-06-17 05:40:48 --> Config Class Initialized
INFO - 2021-06-17 05:40:48 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:40:48 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:40:48 --> Utf8 Class Initialized
INFO - 2021-06-17 05:40:48 --> URI Class Initialized
INFO - 2021-06-17 05:40:48 --> Router Class Initialized
INFO - 2021-06-17 05:40:48 --> Output Class Initialized
INFO - 2021-06-17 05:40:48 --> Security Class Initialized
DEBUG - 2021-06-17 05:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:40:48 --> Input Class Initialized
INFO - 2021-06-17 05:40:48 --> Language Class Initialized
INFO - 2021-06-17 05:40:48 --> Language Class Initialized
INFO - 2021-06-17 05:40:48 --> Config Class Initialized
INFO - 2021-06-17 05:40:48 --> Loader Class Initialized
INFO - 2021-06-17 05:40:48 --> Helper loaded: url_helper
INFO - 2021-06-17 05:40:48 --> Helper loaded: file_helper
INFO - 2021-06-17 05:40:48 --> Helper loaded: form_helper
INFO - 2021-06-17 05:40:48 --> Helper loaded: my_helper
INFO - 2021-06-17 05:40:48 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:40:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:40:48 --> Controller Class Initialized
INFO - 2021-06-17 05:40:48 --> Final output sent to browser
DEBUG - 2021-06-17 05:40:48 --> Total execution time: 0.0412
INFO - 2021-06-17 05:41:17 --> Config Class Initialized
INFO - 2021-06-17 05:41:17 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:41:17 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:41:17 --> Utf8 Class Initialized
INFO - 2021-06-17 05:41:17 --> URI Class Initialized
INFO - 2021-06-17 05:41:17 --> Router Class Initialized
INFO - 2021-06-17 05:41:17 --> Output Class Initialized
INFO - 2021-06-17 05:41:17 --> Security Class Initialized
DEBUG - 2021-06-17 05:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:41:17 --> Input Class Initialized
INFO - 2021-06-17 05:41:17 --> Language Class Initialized
INFO - 2021-06-17 05:41:17 --> Language Class Initialized
INFO - 2021-06-17 05:41:17 --> Config Class Initialized
INFO - 2021-06-17 05:41:17 --> Loader Class Initialized
INFO - 2021-06-17 05:41:17 --> Helper loaded: url_helper
INFO - 2021-06-17 05:41:17 --> Helper loaded: file_helper
INFO - 2021-06-17 05:41:17 --> Helper loaded: form_helper
INFO - 2021-06-17 05:41:17 --> Helper loaded: my_helper
INFO - 2021-06-17 05:41:17 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:41:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:41:17 --> Controller Class Initialized
INFO - 2021-06-17 05:41:17 --> Final output sent to browser
DEBUG - 2021-06-17 05:41:17 --> Total execution time: 0.0389
INFO - 2021-06-17 05:41:17 --> Config Class Initialized
INFO - 2021-06-17 05:41:17 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:41:17 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:41:17 --> Utf8 Class Initialized
INFO - 2021-06-17 05:41:17 --> URI Class Initialized
INFO - 2021-06-17 05:41:17 --> Router Class Initialized
INFO - 2021-06-17 05:41:17 --> Output Class Initialized
INFO - 2021-06-17 05:41:17 --> Security Class Initialized
DEBUG - 2021-06-17 05:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:41:17 --> Input Class Initialized
INFO - 2021-06-17 05:41:17 --> Language Class Initialized
INFO - 2021-06-17 05:41:17 --> Language Class Initialized
INFO - 2021-06-17 05:41:17 --> Config Class Initialized
INFO - 2021-06-17 05:41:17 --> Loader Class Initialized
INFO - 2021-06-17 05:41:17 --> Helper loaded: url_helper
INFO - 2021-06-17 05:41:17 --> Helper loaded: file_helper
INFO - 2021-06-17 05:41:17 --> Helper loaded: form_helper
INFO - 2021-06-17 05:41:17 --> Helper loaded: my_helper
INFO - 2021-06-17 05:41:17 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:41:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:41:17 --> Controller Class Initialized
DEBUG - 2021-06-17 05:41:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 05:41:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 05:41:17 --> Final output sent to browser
DEBUG - 2021-06-17 05:41:17 --> Total execution time: 0.0505
INFO - 2021-06-17 05:41:33 --> Config Class Initialized
INFO - 2021-06-17 05:41:33 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:41:33 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:41:33 --> Utf8 Class Initialized
INFO - 2021-06-17 05:41:33 --> URI Class Initialized
INFO - 2021-06-17 05:41:33 --> Router Class Initialized
INFO - 2021-06-17 05:41:33 --> Output Class Initialized
INFO - 2021-06-17 05:41:33 --> Security Class Initialized
DEBUG - 2021-06-17 05:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:41:33 --> Input Class Initialized
INFO - 2021-06-17 05:41:33 --> Language Class Initialized
INFO - 2021-06-17 05:41:33 --> Language Class Initialized
INFO - 2021-06-17 05:41:33 --> Config Class Initialized
INFO - 2021-06-17 05:41:33 --> Loader Class Initialized
INFO - 2021-06-17 05:41:33 --> Helper loaded: url_helper
INFO - 2021-06-17 05:41:33 --> Helper loaded: file_helper
INFO - 2021-06-17 05:41:33 --> Helper loaded: form_helper
INFO - 2021-06-17 05:41:33 --> Helper loaded: my_helper
INFO - 2021-06-17 05:41:33 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:41:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:41:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:41:33 --> Controller Class Initialized
INFO - 2021-06-17 05:41:33 --> Final output sent to browser
DEBUG - 2021-06-17 05:41:33 --> Total execution time: 0.0483
INFO - 2021-06-17 05:41:44 --> Config Class Initialized
INFO - 2021-06-17 05:41:44 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:41:44 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:41:44 --> Utf8 Class Initialized
INFO - 2021-06-17 05:41:44 --> URI Class Initialized
INFO - 2021-06-17 05:41:44 --> Router Class Initialized
INFO - 2021-06-17 05:41:44 --> Output Class Initialized
INFO - 2021-06-17 05:41:44 --> Security Class Initialized
DEBUG - 2021-06-17 05:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:41:44 --> Input Class Initialized
INFO - 2021-06-17 05:41:44 --> Language Class Initialized
INFO - 2021-06-17 05:41:44 --> Language Class Initialized
INFO - 2021-06-17 05:41:44 --> Config Class Initialized
INFO - 2021-06-17 05:41:44 --> Loader Class Initialized
INFO - 2021-06-17 05:41:44 --> Helper loaded: url_helper
INFO - 2021-06-17 05:41:44 --> Helper loaded: file_helper
INFO - 2021-06-17 05:41:44 --> Helper loaded: form_helper
INFO - 2021-06-17 05:41:44 --> Helper loaded: my_helper
INFO - 2021-06-17 05:41:44 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:41:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:41:44 --> Controller Class Initialized
INFO - 2021-06-17 05:41:44 --> Final output sent to browser
DEBUG - 2021-06-17 05:41:44 --> Total execution time: 0.0389
INFO - 2021-06-17 05:41:44 --> Config Class Initialized
INFO - 2021-06-17 05:41:44 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:41:44 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:41:44 --> Utf8 Class Initialized
INFO - 2021-06-17 05:41:44 --> URI Class Initialized
INFO - 2021-06-17 05:41:44 --> Router Class Initialized
INFO - 2021-06-17 05:41:44 --> Output Class Initialized
INFO - 2021-06-17 05:41:44 --> Security Class Initialized
DEBUG - 2021-06-17 05:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:41:44 --> Input Class Initialized
INFO - 2021-06-17 05:41:44 --> Language Class Initialized
INFO - 2021-06-17 05:41:44 --> Language Class Initialized
INFO - 2021-06-17 05:41:44 --> Config Class Initialized
INFO - 2021-06-17 05:41:44 --> Loader Class Initialized
INFO - 2021-06-17 05:41:44 --> Helper loaded: url_helper
INFO - 2021-06-17 05:41:44 --> Helper loaded: file_helper
INFO - 2021-06-17 05:41:44 --> Helper loaded: form_helper
INFO - 2021-06-17 05:41:44 --> Helper loaded: my_helper
INFO - 2021-06-17 05:41:44 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:41:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:41:44 --> Controller Class Initialized
DEBUG - 2021-06-17 05:41:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 05:41:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 05:41:44 --> Final output sent to browser
DEBUG - 2021-06-17 05:41:44 --> Total execution time: 0.0405
INFO - 2021-06-17 05:42:02 --> Config Class Initialized
INFO - 2021-06-17 05:42:02 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:42:02 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:42:02 --> Utf8 Class Initialized
INFO - 2021-06-17 05:42:02 --> URI Class Initialized
INFO - 2021-06-17 05:42:02 --> Router Class Initialized
INFO - 2021-06-17 05:42:02 --> Output Class Initialized
INFO - 2021-06-17 05:42:02 --> Security Class Initialized
DEBUG - 2021-06-17 05:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:42:02 --> Input Class Initialized
INFO - 2021-06-17 05:42:02 --> Language Class Initialized
INFO - 2021-06-17 05:42:02 --> Language Class Initialized
INFO - 2021-06-17 05:42:02 --> Config Class Initialized
INFO - 2021-06-17 05:42:02 --> Loader Class Initialized
INFO - 2021-06-17 05:42:02 --> Helper loaded: url_helper
INFO - 2021-06-17 05:42:02 --> Helper loaded: file_helper
INFO - 2021-06-17 05:42:02 --> Helper loaded: form_helper
INFO - 2021-06-17 05:42:02 --> Helper loaded: my_helper
INFO - 2021-06-17 05:42:02 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:42:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:42:02 --> Controller Class Initialized
INFO - 2021-06-17 05:42:02 --> Final output sent to browser
DEBUG - 2021-06-17 05:42:02 --> Total execution time: 0.0500
INFO - 2021-06-17 05:42:08 --> Config Class Initialized
INFO - 2021-06-17 05:42:08 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:42:08 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:42:08 --> Utf8 Class Initialized
INFO - 2021-06-17 05:42:08 --> URI Class Initialized
INFO - 2021-06-17 05:42:08 --> Router Class Initialized
INFO - 2021-06-17 05:42:08 --> Output Class Initialized
INFO - 2021-06-17 05:42:08 --> Security Class Initialized
DEBUG - 2021-06-17 05:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:42:08 --> Input Class Initialized
INFO - 2021-06-17 05:42:08 --> Language Class Initialized
INFO - 2021-06-17 05:42:08 --> Language Class Initialized
INFO - 2021-06-17 05:42:08 --> Config Class Initialized
INFO - 2021-06-17 05:42:08 --> Loader Class Initialized
INFO - 2021-06-17 05:42:08 --> Helper loaded: url_helper
INFO - 2021-06-17 05:42:08 --> Helper loaded: file_helper
INFO - 2021-06-17 05:42:08 --> Helper loaded: form_helper
INFO - 2021-06-17 05:42:08 --> Helper loaded: my_helper
INFO - 2021-06-17 05:42:08 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:42:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:42:08 --> Controller Class Initialized
INFO - 2021-06-17 05:42:08 --> Final output sent to browser
DEBUG - 2021-06-17 05:42:08 --> Total execution time: 0.0407
INFO - 2021-06-17 05:42:17 --> Config Class Initialized
INFO - 2021-06-17 05:42:17 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:42:17 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:42:17 --> Utf8 Class Initialized
INFO - 2021-06-17 05:42:17 --> URI Class Initialized
INFO - 2021-06-17 05:42:17 --> Router Class Initialized
INFO - 2021-06-17 05:42:17 --> Output Class Initialized
INFO - 2021-06-17 05:42:17 --> Security Class Initialized
DEBUG - 2021-06-17 05:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:42:17 --> Input Class Initialized
INFO - 2021-06-17 05:42:17 --> Language Class Initialized
INFO - 2021-06-17 05:42:17 --> Language Class Initialized
INFO - 2021-06-17 05:42:17 --> Config Class Initialized
INFO - 2021-06-17 05:42:17 --> Loader Class Initialized
INFO - 2021-06-17 05:42:17 --> Helper loaded: url_helper
INFO - 2021-06-17 05:42:17 --> Helper loaded: file_helper
INFO - 2021-06-17 05:42:17 --> Helper loaded: form_helper
INFO - 2021-06-17 05:42:17 --> Helper loaded: my_helper
INFO - 2021-06-17 05:42:17 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:42:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:42:18 --> Controller Class Initialized
INFO - 2021-06-17 05:42:18 --> Final output sent to browser
DEBUG - 2021-06-17 05:42:18 --> Total execution time: 0.0494
INFO - 2021-06-17 05:42:18 --> Config Class Initialized
INFO - 2021-06-17 05:42:18 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:42:18 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:42:18 --> Utf8 Class Initialized
INFO - 2021-06-17 05:42:18 --> URI Class Initialized
INFO - 2021-06-17 05:42:18 --> Router Class Initialized
INFO - 2021-06-17 05:42:18 --> Output Class Initialized
INFO - 2021-06-17 05:42:18 --> Security Class Initialized
DEBUG - 2021-06-17 05:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:42:18 --> Input Class Initialized
INFO - 2021-06-17 05:42:18 --> Language Class Initialized
INFO - 2021-06-17 05:42:18 --> Language Class Initialized
INFO - 2021-06-17 05:42:18 --> Config Class Initialized
INFO - 2021-06-17 05:42:18 --> Loader Class Initialized
INFO - 2021-06-17 05:42:18 --> Helper loaded: url_helper
INFO - 2021-06-17 05:42:18 --> Helper loaded: file_helper
INFO - 2021-06-17 05:42:18 --> Helper loaded: form_helper
INFO - 2021-06-17 05:42:18 --> Helper loaded: my_helper
INFO - 2021-06-17 05:42:18 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:42:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:42:18 --> Controller Class Initialized
DEBUG - 2021-06-17 05:42:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 05:42:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 05:42:18 --> Final output sent to browser
DEBUG - 2021-06-17 05:42:18 --> Total execution time: 0.0469
INFO - 2021-06-17 05:42:35 --> Config Class Initialized
INFO - 2021-06-17 05:42:35 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:42:35 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:42:35 --> Utf8 Class Initialized
INFO - 2021-06-17 05:42:35 --> URI Class Initialized
INFO - 2021-06-17 05:42:35 --> Router Class Initialized
INFO - 2021-06-17 05:42:35 --> Output Class Initialized
INFO - 2021-06-17 05:42:35 --> Security Class Initialized
DEBUG - 2021-06-17 05:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:42:35 --> Input Class Initialized
INFO - 2021-06-17 05:42:35 --> Language Class Initialized
INFO - 2021-06-17 05:42:35 --> Language Class Initialized
INFO - 2021-06-17 05:42:35 --> Config Class Initialized
INFO - 2021-06-17 05:42:35 --> Loader Class Initialized
INFO - 2021-06-17 05:42:35 --> Helper loaded: url_helper
INFO - 2021-06-17 05:42:35 --> Helper loaded: file_helper
INFO - 2021-06-17 05:42:35 --> Helper loaded: form_helper
INFO - 2021-06-17 05:42:35 --> Helper loaded: my_helper
INFO - 2021-06-17 05:42:35 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:42:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:42:35 --> Controller Class Initialized
INFO - 2021-06-17 05:42:35 --> Final output sent to browser
DEBUG - 2021-06-17 05:42:35 --> Total execution time: 0.0490
INFO - 2021-06-17 05:42:35 --> Config Class Initialized
INFO - 2021-06-17 05:42:35 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:42:35 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:42:35 --> Utf8 Class Initialized
INFO - 2021-06-17 05:42:35 --> URI Class Initialized
INFO - 2021-06-17 05:42:35 --> Router Class Initialized
INFO - 2021-06-17 05:42:35 --> Output Class Initialized
INFO - 2021-06-17 05:42:35 --> Security Class Initialized
DEBUG - 2021-06-17 05:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:42:35 --> Input Class Initialized
INFO - 2021-06-17 05:42:35 --> Language Class Initialized
INFO - 2021-06-17 05:42:35 --> Language Class Initialized
INFO - 2021-06-17 05:42:35 --> Config Class Initialized
INFO - 2021-06-17 05:42:35 --> Loader Class Initialized
INFO - 2021-06-17 05:42:35 --> Helper loaded: url_helper
INFO - 2021-06-17 05:42:35 --> Helper loaded: file_helper
INFO - 2021-06-17 05:42:35 --> Helper loaded: form_helper
INFO - 2021-06-17 05:42:35 --> Helper loaded: my_helper
INFO - 2021-06-17 05:42:35 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:42:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:42:35 --> Controller Class Initialized
INFO - 2021-06-17 05:42:35 --> Final output sent to browser
DEBUG - 2021-06-17 05:42:35 --> Total execution time: 0.0387
INFO - 2021-06-17 05:42:48 --> Config Class Initialized
INFO - 2021-06-17 05:42:48 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:42:48 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:42:48 --> Utf8 Class Initialized
INFO - 2021-06-17 05:42:48 --> URI Class Initialized
INFO - 2021-06-17 05:42:48 --> Router Class Initialized
INFO - 2021-06-17 05:42:48 --> Output Class Initialized
INFO - 2021-06-17 05:42:48 --> Security Class Initialized
DEBUG - 2021-06-17 05:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:42:48 --> Input Class Initialized
INFO - 2021-06-17 05:42:48 --> Language Class Initialized
INFO - 2021-06-17 05:42:48 --> Language Class Initialized
INFO - 2021-06-17 05:42:48 --> Config Class Initialized
INFO - 2021-06-17 05:42:48 --> Loader Class Initialized
INFO - 2021-06-17 05:42:48 --> Helper loaded: url_helper
INFO - 2021-06-17 05:42:48 --> Helper loaded: file_helper
INFO - 2021-06-17 05:42:48 --> Helper loaded: form_helper
INFO - 2021-06-17 05:42:48 --> Helper loaded: my_helper
INFO - 2021-06-17 05:42:48 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:42:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:42:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:42:48 --> Controller Class Initialized
INFO - 2021-06-17 05:42:48 --> Final output sent to browser
DEBUG - 2021-06-17 05:42:48 --> Total execution time: 0.0419
INFO - 2021-06-17 05:42:48 --> Config Class Initialized
INFO - 2021-06-17 05:42:48 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:42:48 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:42:48 --> Utf8 Class Initialized
INFO - 2021-06-17 05:42:48 --> URI Class Initialized
INFO - 2021-06-17 05:42:48 --> Router Class Initialized
INFO - 2021-06-17 05:42:48 --> Output Class Initialized
INFO - 2021-06-17 05:42:48 --> Security Class Initialized
DEBUG - 2021-06-17 05:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:42:48 --> Input Class Initialized
INFO - 2021-06-17 05:42:48 --> Language Class Initialized
INFO - 2021-06-17 05:42:48 --> Language Class Initialized
INFO - 2021-06-17 05:42:48 --> Config Class Initialized
INFO - 2021-06-17 05:42:48 --> Loader Class Initialized
INFO - 2021-06-17 05:42:48 --> Helper loaded: url_helper
INFO - 2021-06-17 05:42:48 --> Helper loaded: file_helper
INFO - 2021-06-17 05:42:48 --> Helper loaded: form_helper
INFO - 2021-06-17 05:42:48 --> Helper loaded: my_helper
INFO - 2021-06-17 05:42:48 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:42:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:42:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:42:48 --> Controller Class Initialized
DEBUG - 2021-06-17 05:42:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 05:42:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 05:42:48 --> Final output sent to browser
DEBUG - 2021-06-17 05:42:48 --> Total execution time: 0.0448
INFO - 2021-06-17 05:43:06 --> Config Class Initialized
INFO - 2021-06-17 05:43:06 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:43:06 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:43:06 --> Utf8 Class Initialized
INFO - 2021-06-17 05:43:06 --> URI Class Initialized
INFO - 2021-06-17 05:43:06 --> Router Class Initialized
INFO - 2021-06-17 05:43:06 --> Output Class Initialized
INFO - 2021-06-17 05:43:06 --> Security Class Initialized
DEBUG - 2021-06-17 05:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:43:06 --> Input Class Initialized
INFO - 2021-06-17 05:43:06 --> Language Class Initialized
INFO - 2021-06-17 05:43:06 --> Language Class Initialized
INFO - 2021-06-17 05:43:06 --> Config Class Initialized
INFO - 2021-06-17 05:43:06 --> Loader Class Initialized
INFO - 2021-06-17 05:43:06 --> Helper loaded: url_helper
INFO - 2021-06-17 05:43:06 --> Helper loaded: file_helper
INFO - 2021-06-17 05:43:06 --> Helper loaded: form_helper
INFO - 2021-06-17 05:43:06 --> Helper loaded: my_helper
INFO - 2021-06-17 05:43:06 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:43:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:43:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:43:06 --> Controller Class Initialized
INFO - 2021-06-17 05:43:06 --> Final output sent to browser
DEBUG - 2021-06-17 05:43:06 --> Total execution time: 0.0501
INFO - 2021-06-17 05:43:20 --> Config Class Initialized
INFO - 2021-06-17 05:43:20 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:43:20 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:43:20 --> Utf8 Class Initialized
INFO - 2021-06-17 05:43:20 --> URI Class Initialized
INFO - 2021-06-17 05:43:20 --> Router Class Initialized
INFO - 2021-06-17 05:43:20 --> Output Class Initialized
INFO - 2021-06-17 05:43:20 --> Security Class Initialized
DEBUG - 2021-06-17 05:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:43:20 --> Input Class Initialized
INFO - 2021-06-17 05:43:20 --> Language Class Initialized
INFO - 2021-06-17 05:43:20 --> Language Class Initialized
INFO - 2021-06-17 05:43:20 --> Config Class Initialized
INFO - 2021-06-17 05:43:20 --> Loader Class Initialized
INFO - 2021-06-17 05:43:20 --> Helper loaded: url_helper
INFO - 2021-06-17 05:43:20 --> Helper loaded: file_helper
INFO - 2021-06-17 05:43:20 --> Helper loaded: form_helper
INFO - 2021-06-17 05:43:20 --> Helper loaded: my_helper
INFO - 2021-06-17 05:43:20 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:43:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:43:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:43:20 --> Controller Class Initialized
INFO - 2021-06-17 05:43:20 --> Final output sent to browser
DEBUG - 2021-06-17 05:43:20 --> Total execution time: 0.0445
INFO - 2021-06-17 05:43:20 --> Config Class Initialized
INFO - 2021-06-17 05:43:20 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:43:20 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:43:20 --> Utf8 Class Initialized
INFO - 2021-06-17 05:43:20 --> URI Class Initialized
INFO - 2021-06-17 05:43:20 --> Router Class Initialized
INFO - 2021-06-17 05:43:20 --> Output Class Initialized
INFO - 2021-06-17 05:43:20 --> Security Class Initialized
DEBUG - 2021-06-17 05:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:43:20 --> Input Class Initialized
INFO - 2021-06-17 05:43:20 --> Language Class Initialized
INFO - 2021-06-17 05:43:20 --> Language Class Initialized
INFO - 2021-06-17 05:43:20 --> Config Class Initialized
INFO - 2021-06-17 05:43:20 --> Loader Class Initialized
INFO - 2021-06-17 05:43:20 --> Helper loaded: url_helper
INFO - 2021-06-17 05:43:20 --> Helper loaded: file_helper
INFO - 2021-06-17 05:43:20 --> Helper loaded: form_helper
INFO - 2021-06-17 05:43:20 --> Helper loaded: my_helper
INFO - 2021-06-17 05:43:20 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:43:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:43:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:43:20 --> Controller Class Initialized
DEBUG - 2021-06-17 05:43:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 05:43:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 05:43:20 --> Final output sent to browser
DEBUG - 2021-06-17 05:43:20 --> Total execution time: 0.0524
INFO - 2021-06-17 05:43:34 --> Config Class Initialized
INFO - 2021-06-17 05:43:34 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:43:34 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:43:34 --> Utf8 Class Initialized
INFO - 2021-06-17 05:43:34 --> URI Class Initialized
INFO - 2021-06-17 05:43:34 --> Router Class Initialized
INFO - 2021-06-17 05:43:34 --> Output Class Initialized
INFO - 2021-06-17 05:43:34 --> Security Class Initialized
DEBUG - 2021-06-17 05:43:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:43:34 --> Input Class Initialized
INFO - 2021-06-17 05:43:34 --> Language Class Initialized
INFO - 2021-06-17 05:43:34 --> Language Class Initialized
INFO - 2021-06-17 05:43:34 --> Config Class Initialized
INFO - 2021-06-17 05:43:34 --> Loader Class Initialized
INFO - 2021-06-17 05:43:34 --> Helper loaded: url_helper
INFO - 2021-06-17 05:43:34 --> Helper loaded: file_helper
INFO - 2021-06-17 05:43:34 --> Helper loaded: form_helper
INFO - 2021-06-17 05:43:34 --> Helper loaded: my_helper
INFO - 2021-06-17 05:43:34 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:43:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:43:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:43:34 --> Controller Class Initialized
INFO - 2021-06-17 05:43:34 --> Final output sent to browser
DEBUG - 2021-06-17 05:43:34 --> Total execution time: 0.0380
INFO - 2021-06-17 05:43:40 --> Config Class Initialized
INFO - 2021-06-17 05:43:40 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:43:40 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:43:40 --> Utf8 Class Initialized
INFO - 2021-06-17 05:43:40 --> URI Class Initialized
INFO - 2021-06-17 05:43:40 --> Router Class Initialized
INFO - 2021-06-17 05:43:40 --> Output Class Initialized
INFO - 2021-06-17 05:43:40 --> Security Class Initialized
DEBUG - 2021-06-17 05:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:43:40 --> Input Class Initialized
INFO - 2021-06-17 05:43:40 --> Language Class Initialized
INFO - 2021-06-17 05:43:40 --> Language Class Initialized
INFO - 2021-06-17 05:43:40 --> Config Class Initialized
INFO - 2021-06-17 05:43:40 --> Loader Class Initialized
INFO - 2021-06-17 05:43:40 --> Helper loaded: url_helper
INFO - 2021-06-17 05:43:40 --> Helper loaded: file_helper
INFO - 2021-06-17 05:43:40 --> Helper loaded: form_helper
INFO - 2021-06-17 05:43:40 --> Helper loaded: my_helper
INFO - 2021-06-17 05:43:40 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:43:40 --> Controller Class Initialized
INFO - 2021-06-17 05:43:40 --> Final output sent to browser
DEBUG - 2021-06-17 05:43:40 --> Total execution time: 0.0473
INFO - 2021-06-17 05:43:49 --> Config Class Initialized
INFO - 2021-06-17 05:43:49 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:43:49 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:43:49 --> Utf8 Class Initialized
INFO - 2021-06-17 05:43:49 --> URI Class Initialized
INFO - 2021-06-17 05:43:49 --> Router Class Initialized
INFO - 2021-06-17 05:43:49 --> Output Class Initialized
INFO - 2021-06-17 05:43:49 --> Security Class Initialized
DEBUG - 2021-06-17 05:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:43:49 --> Input Class Initialized
INFO - 2021-06-17 05:43:49 --> Language Class Initialized
INFO - 2021-06-17 05:43:49 --> Language Class Initialized
INFO - 2021-06-17 05:43:49 --> Config Class Initialized
INFO - 2021-06-17 05:43:49 --> Loader Class Initialized
INFO - 2021-06-17 05:43:49 --> Helper loaded: url_helper
INFO - 2021-06-17 05:43:49 --> Helper loaded: file_helper
INFO - 2021-06-17 05:43:49 --> Helper loaded: form_helper
INFO - 2021-06-17 05:43:49 --> Helper loaded: my_helper
INFO - 2021-06-17 05:43:49 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:43:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:43:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:43:49 --> Controller Class Initialized
INFO - 2021-06-17 05:43:49 --> Final output sent to browser
DEBUG - 2021-06-17 05:43:49 --> Total execution time: 0.0504
INFO - 2021-06-17 05:43:49 --> Config Class Initialized
INFO - 2021-06-17 05:43:49 --> Hooks Class Initialized
DEBUG - 2021-06-17 05:43:49 --> UTF-8 Support Enabled
INFO - 2021-06-17 05:43:49 --> Utf8 Class Initialized
INFO - 2021-06-17 05:43:49 --> URI Class Initialized
INFO - 2021-06-17 05:43:49 --> Router Class Initialized
INFO - 2021-06-17 05:43:49 --> Output Class Initialized
INFO - 2021-06-17 05:43:49 --> Security Class Initialized
DEBUG - 2021-06-17 05:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 05:43:49 --> Input Class Initialized
INFO - 2021-06-17 05:43:49 --> Language Class Initialized
INFO - 2021-06-17 05:43:49 --> Language Class Initialized
INFO - 2021-06-17 05:43:49 --> Config Class Initialized
INFO - 2021-06-17 05:43:49 --> Loader Class Initialized
INFO - 2021-06-17 05:43:49 --> Helper loaded: url_helper
INFO - 2021-06-17 05:43:49 --> Helper loaded: file_helper
INFO - 2021-06-17 05:43:49 --> Helper loaded: form_helper
INFO - 2021-06-17 05:43:49 --> Helper loaded: my_helper
INFO - 2021-06-17 05:43:49 --> Database Driver Class Initialized
DEBUG - 2021-06-17 05:43:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 05:43:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 05:43:49 --> Controller Class Initialized
DEBUG - 2021-06-17 05:43:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 05:43:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 05:43:49 --> Final output sent to browser
DEBUG - 2021-06-17 05:43:49 --> Total execution time: 0.0472
INFO - 2021-06-17 06:01:21 --> Config Class Initialized
INFO - 2021-06-17 06:01:21 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:01:21 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:01:21 --> Utf8 Class Initialized
INFO - 2021-06-17 06:01:21 --> URI Class Initialized
INFO - 2021-06-17 06:01:21 --> Router Class Initialized
INFO - 2021-06-17 06:01:21 --> Output Class Initialized
INFO - 2021-06-17 06:01:21 --> Security Class Initialized
DEBUG - 2021-06-17 06:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:01:21 --> Input Class Initialized
INFO - 2021-06-17 06:01:21 --> Language Class Initialized
INFO - 2021-06-17 06:01:21 --> Language Class Initialized
INFO - 2021-06-17 06:01:21 --> Config Class Initialized
INFO - 2021-06-17 06:01:21 --> Loader Class Initialized
INFO - 2021-06-17 06:01:21 --> Helper loaded: url_helper
INFO - 2021-06-17 06:01:21 --> Helper loaded: file_helper
INFO - 2021-06-17 06:01:21 --> Helper loaded: form_helper
INFO - 2021-06-17 06:01:21 --> Helper loaded: my_helper
INFO - 2021-06-17 06:01:21 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:01:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:01:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:01:21 --> Controller Class Initialized
INFO - 2021-06-17 06:01:21 --> Helper loaded: cookie_helper
INFO - 2021-06-17 06:01:21 --> Config Class Initialized
INFO - 2021-06-17 06:01:21 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:01:21 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:01:21 --> Utf8 Class Initialized
INFO - 2021-06-17 06:01:21 --> URI Class Initialized
INFO - 2021-06-17 06:01:21 --> Router Class Initialized
INFO - 2021-06-17 06:01:21 --> Output Class Initialized
INFO - 2021-06-17 06:01:21 --> Security Class Initialized
DEBUG - 2021-06-17 06:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:01:21 --> Input Class Initialized
INFO - 2021-06-17 06:01:21 --> Language Class Initialized
INFO - 2021-06-17 06:01:21 --> Language Class Initialized
INFO - 2021-06-17 06:01:21 --> Config Class Initialized
INFO - 2021-06-17 06:01:21 --> Loader Class Initialized
INFO - 2021-06-17 06:01:21 --> Helper loaded: url_helper
INFO - 2021-06-17 06:01:21 --> Helper loaded: file_helper
INFO - 2021-06-17 06:01:21 --> Helper loaded: form_helper
INFO - 2021-06-17 06:01:21 --> Helper loaded: my_helper
INFO - 2021-06-17 06:01:21 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:01:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:01:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:01:21 --> Controller Class Initialized
DEBUG - 2021-06-17 06:01:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-17 06:01:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:01:21 --> Final output sent to browser
DEBUG - 2021-06-17 06:01:21 --> Total execution time: 0.0496
INFO - 2021-06-17 06:01:25 --> Config Class Initialized
INFO - 2021-06-17 06:01:25 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:01:25 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:01:25 --> Utf8 Class Initialized
INFO - 2021-06-17 06:01:25 --> URI Class Initialized
INFO - 2021-06-17 06:01:25 --> Router Class Initialized
INFO - 2021-06-17 06:01:25 --> Output Class Initialized
INFO - 2021-06-17 06:01:25 --> Security Class Initialized
DEBUG - 2021-06-17 06:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:01:25 --> Input Class Initialized
INFO - 2021-06-17 06:01:25 --> Language Class Initialized
INFO - 2021-06-17 06:01:25 --> Language Class Initialized
INFO - 2021-06-17 06:01:25 --> Config Class Initialized
INFO - 2021-06-17 06:01:25 --> Loader Class Initialized
INFO - 2021-06-17 06:01:25 --> Helper loaded: url_helper
INFO - 2021-06-17 06:01:25 --> Helper loaded: file_helper
INFO - 2021-06-17 06:01:25 --> Helper loaded: form_helper
INFO - 2021-06-17 06:01:25 --> Helper loaded: my_helper
INFO - 2021-06-17 06:01:25 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:01:25 --> Controller Class Initialized
INFO - 2021-06-17 06:01:25 --> Helper loaded: cookie_helper
INFO - 2021-06-17 06:01:25 --> Final output sent to browser
DEBUG - 2021-06-17 06:01:25 --> Total execution time: 0.0496
INFO - 2021-06-17 06:01:25 --> Config Class Initialized
INFO - 2021-06-17 06:01:25 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:01:25 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:01:25 --> Utf8 Class Initialized
INFO - 2021-06-17 06:01:25 --> URI Class Initialized
INFO - 2021-06-17 06:01:25 --> Router Class Initialized
INFO - 2021-06-17 06:01:25 --> Output Class Initialized
INFO - 2021-06-17 06:01:25 --> Security Class Initialized
DEBUG - 2021-06-17 06:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:01:25 --> Input Class Initialized
INFO - 2021-06-17 06:01:25 --> Language Class Initialized
INFO - 2021-06-17 06:01:25 --> Language Class Initialized
INFO - 2021-06-17 06:01:25 --> Config Class Initialized
INFO - 2021-06-17 06:01:25 --> Loader Class Initialized
INFO - 2021-06-17 06:01:25 --> Helper loaded: url_helper
INFO - 2021-06-17 06:01:25 --> Helper loaded: file_helper
INFO - 2021-06-17 06:01:25 --> Helper loaded: form_helper
INFO - 2021-06-17 06:01:25 --> Helper loaded: my_helper
INFO - 2021-06-17 06:01:25 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:01:25 --> Controller Class Initialized
DEBUG - 2021-06-17 06:01:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-17 06:01:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:01:25 --> Final output sent to browser
DEBUG - 2021-06-17 06:01:25 --> Total execution time: 0.2043
INFO - 2021-06-17 06:01:29 --> Config Class Initialized
INFO - 2021-06-17 06:01:29 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:01:29 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:01:29 --> Utf8 Class Initialized
INFO - 2021-06-17 06:01:29 --> URI Class Initialized
INFO - 2021-06-17 06:01:29 --> Router Class Initialized
INFO - 2021-06-17 06:01:29 --> Output Class Initialized
INFO - 2021-06-17 06:01:29 --> Security Class Initialized
DEBUG - 2021-06-17 06:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:01:29 --> Input Class Initialized
INFO - 2021-06-17 06:01:29 --> Language Class Initialized
INFO - 2021-06-17 06:01:29 --> Language Class Initialized
INFO - 2021-06-17 06:01:29 --> Config Class Initialized
INFO - 2021-06-17 06:01:29 --> Loader Class Initialized
INFO - 2021-06-17 06:01:29 --> Helper loaded: url_helper
INFO - 2021-06-17 06:01:29 --> Helper loaded: file_helper
INFO - 2021-06-17 06:01:29 --> Helper loaded: form_helper
INFO - 2021-06-17 06:01:29 --> Helper loaded: my_helper
INFO - 2021-06-17 06:01:29 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:01:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:01:29 --> Controller Class Initialized
DEBUG - 2021-06-17 06:01:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2021-06-17 06:01:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:01:29 --> Final output sent to browser
DEBUG - 2021-06-17 06:01:29 --> Total execution time: 0.0849
INFO - 2021-06-17 06:01:31 --> Config Class Initialized
INFO - 2021-06-17 06:01:31 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:01:31 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:01:31 --> Utf8 Class Initialized
INFO - 2021-06-17 06:01:31 --> URI Class Initialized
INFO - 2021-06-17 06:01:31 --> Router Class Initialized
INFO - 2021-06-17 06:01:31 --> Output Class Initialized
INFO - 2021-06-17 06:01:31 --> Security Class Initialized
DEBUG - 2021-06-17 06:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:01:31 --> Input Class Initialized
INFO - 2021-06-17 06:01:31 --> Language Class Initialized
INFO - 2021-06-17 06:01:31 --> Language Class Initialized
INFO - 2021-06-17 06:01:31 --> Config Class Initialized
INFO - 2021-06-17 06:01:31 --> Loader Class Initialized
INFO - 2021-06-17 06:01:31 --> Helper loaded: url_helper
INFO - 2021-06-17 06:01:31 --> Helper loaded: file_helper
INFO - 2021-06-17 06:01:31 --> Helper loaded: form_helper
INFO - 2021-06-17 06:01:31 --> Helper loaded: my_helper
INFO - 2021-06-17 06:01:31 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:01:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:01:31 --> Controller Class Initialized
DEBUG - 2021-06-17 06:01:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-17 06:01:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:01:31 --> Final output sent to browser
DEBUG - 2021-06-17 06:01:31 --> Total execution time: 0.0503
INFO - 2021-06-17 06:01:34 --> Config Class Initialized
INFO - 2021-06-17 06:01:34 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:01:34 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:01:34 --> Utf8 Class Initialized
INFO - 2021-06-17 06:01:34 --> URI Class Initialized
INFO - 2021-06-17 06:01:34 --> Router Class Initialized
INFO - 2021-06-17 06:01:34 --> Output Class Initialized
INFO - 2021-06-17 06:01:34 --> Security Class Initialized
DEBUG - 2021-06-17 06:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:01:34 --> Input Class Initialized
INFO - 2021-06-17 06:01:34 --> Language Class Initialized
INFO - 2021-06-17 06:01:34 --> Language Class Initialized
INFO - 2021-06-17 06:01:34 --> Config Class Initialized
INFO - 2021-06-17 06:01:34 --> Loader Class Initialized
INFO - 2021-06-17 06:01:34 --> Helper loaded: url_helper
INFO - 2021-06-17 06:01:34 --> Helper loaded: file_helper
INFO - 2021-06-17 06:01:34 --> Helper loaded: form_helper
INFO - 2021-06-17 06:01:34 --> Helper loaded: my_helper
INFO - 2021-06-17 06:01:34 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:01:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:01:34 --> Controller Class Initialized
DEBUG - 2021-06-17 06:01:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-17 06:01:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:01:34 --> Final output sent to browser
DEBUG - 2021-06-17 06:01:34 --> Total execution time: 0.0444
INFO - 2021-06-17 06:01:34 --> Config Class Initialized
INFO - 2021-06-17 06:01:34 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:01:34 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:01:34 --> Utf8 Class Initialized
INFO - 2021-06-17 06:01:34 --> URI Class Initialized
INFO - 2021-06-17 06:01:34 --> Router Class Initialized
INFO - 2021-06-17 06:01:34 --> Output Class Initialized
INFO - 2021-06-17 06:01:34 --> Security Class Initialized
DEBUG - 2021-06-17 06:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:01:34 --> Input Class Initialized
INFO - 2021-06-17 06:01:34 --> Language Class Initialized
INFO - 2021-06-17 06:01:34 --> Language Class Initialized
INFO - 2021-06-17 06:01:34 --> Config Class Initialized
INFO - 2021-06-17 06:01:34 --> Loader Class Initialized
INFO - 2021-06-17 06:01:34 --> Helper loaded: url_helper
INFO - 2021-06-17 06:01:34 --> Helper loaded: file_helper
INFO - 2021-06-17 06:01:34 --> Helper loaded: form_helper
INFO - 2021-06-17 06:01:34 --> Helper loaded: my_helper
INFO - 2021-06-17 06:01:34 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:01:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:01:34 --> Controller Class Initialized
INFO - 2021-06-17 06:01:36 --> Config Class Initialized
INFO - 2021-06-17 06:01:36 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:01:36 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:01:36 --> Utf8 Class Initialized
INFO - 2021-06-17 06:01:36 --> URI Class Initialized
INFO - 2021-06-17 06:01:36 --> Router Class Initialized
INFO - 2021-06-17 06:01:36 --> Output Class Initialized
INFO - 2021-06-17 06:01:36 --> Security Class Initialized
DEBUG - 2021-06-17 06:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:01:36 --> Input Class Initialized
INFO - 2021-06-17 06:01:36 --> Language Class Initialized
INFO - 2021-06-17 06:01:36 --> Language Class Initialized
INFO - 2021-06-17 06:01:36 --> Config Class Initialized
INFO - 2021-06-17 06:01:36 --> Loader Class Initialized
INFO - 2021-06-17 06:01:36 --> Helper loaded: url_helper
INFO - 2021-06-17 06:01:36 --> Helper loaded: file_helper
INFO - 2021-06-17 06:01:36 --> Helper loaded: form_helper
INFO - 2021-06-17 06:01:36 --> Helper loaded: my_helper
INFO - 2021-06-17 06:01:36 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:01:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:01:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:01:36 --> Controller Class Initialized
DEBUG - 2021-06-17 06:01:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 06:01:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:01:36 --> Final output sent to browser
DEBUG - 2021-06-17 06:01:36 --> Total execution time: 0.0438
INFO - 2021-06-17 06:01:38 --> Config Class Initialized
INFO - 2021-06-17 06:01:38 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:01:38 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:01:38 --> Utf8 Class Initialized
INFO - 2021-06-17 06:01:38 --> URI Class Initialized
INFO - 2021-06-17 06:01:38 --> Router Class Initialized
INFO - 2021-06-17 06:01:38 --> Output Class Initialized
INFO - 2021-06-17 06:01:38 --> Security Class Initialized
DEBUG - 2021-06-17 06:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:01:38 --> Input Class Initialized
INFO - 2021-06-17 06:01:38 --> Language Class Initialized
INFO - 2021-06-17 06:01:38 --> Language Class Initialized
INFO - 2021-06-17 06:01:38 --> Config Class Initialized
INFO - 2021-06-17 06:01:38 --> Loader Class Initialized
INFO - 2021-06-17 06:01:38 --> Helper loaded: url_helper
INFO - 2021-06-17 06:01:38 --> Helper loaded: file_helper
INFO - 2021-06-17 06:01:38 --> Helper loaded: form_helper
INFO - 2021-06-17 06:01:38 --> Helper loaded: my_helper
INFO - 2021-06-17 06:01:38 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:01:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:01:38 --> Controller Class Initialized
INFO - 2021-06-17 06:01:38 --> Final output sent to browser
DEBUG - 2021-06-17 06:01:38 --> Total execution time: 0.0705
INFO - 2021-06-17 06:02:33 --> Config Class Initialized
INFO - 2021-06-17 06:02:33 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:02:33 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:02:33 --> Utf8 Class Initialized
INFO - 2021-06-17 06:02:33 --> URI Class Initialized
INFO - 2021-06-17 06:02:33 --> Router Class Initialized
INFO - 2021-06-17 06:02:33 --> Output Class Initialized
INFO - 2021-06-17 06:02:33 --> Security Class Initialized
DEBUG - 2021-06-17 06:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:02:33 --> Input Class Initialized
INFO - 2021-06-17 06:02:33 --> Language Class Initialized
INFO - 2021-06-17 06:02:33 --> Language Class Initialized
INFO - 2021-06-17 06:02:33 --> Config Class Initialized
INFO - 2021-06-17 06:02:33 --> Loader Class Initialized
INFO - 2021-06-17 06:02:33 --> Helper loaded: url_helper
INFO - 2021-06-17 06:02:33 --> Helper loaded: file_helper
INFO - 2021-06-17 06:02:33 --> Helper loaded: form_helper
INFO - 2021-06-17 06:02:33 --> Helper loaded: my_helper
INFO - 2021-06-17 06:02:33 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:02:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:02:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:02:33 --> Controller Class Initialized
INFO - 2021-06-17 06:02:33 --> Final output sent to browser
DEBUG - 2021-06-17 06:02:33 --> Total execution time: 0.0499
INFO - 2021-06-17 06:03:33 --> Config Class Initialized
INFO - 2021-06-17 06:03:33 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:03:33 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:03:33 --> Utf8 Class Initialized
INFO - 2021-06-17 06:03:33 --> URI Class Initialized
INFO - 2021-06-17 06:03:33 --> Router Class Initialized
INFO - 2021-06-17 06:03:33 --> Output Class Initialized
INFO - 2021-06-17 06:03:33 --> Security Class Initialized
DEBUG - 2021-06-17 06:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:03:33 --> Input Class Initialized
INFO - 2021-06-17 06:03:33 --> Language Class Initialized
INFO - 2021-06-17 06:03:33 --> Language Class Initialized
INFO - 2021-06-17 06:03:33 --> Config Class Initialized
INFO - 2021-06-17 06:03:33 --> Loader Class Initialized
INFO - 2021-06-17 06:03:33 --> Helper loaded: url_helper
INFO - 2021-06-17 06:03:33 --> Helper loaded: file_helper
INFO - 2021-06-17 06:03:33 --> Helper loaded: form_helper
INFO - 2021-06-17 06:03:33 --> Helper loaded: my_helper
INFO - 2021-06-17 06:03:33 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:03:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:03:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:03:33 --> Controller Class Initialized
INFO - 2021-06-17 06:03:33 --> Helper loaded: cookie_helper
INFO - 2021-06-17 06:03:33 --> Config Class Initialized
INFO - 2021-06-17 06:03:33 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:03:33 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:03:33 --> Utf8 Class Initialized
INFO - 2021-06-17 06:03:33 --> URI Class Initialized
INFO - 2021-06-17 06:03:33 --> Router Class Initialized
INFO - 2021-06-17 06:03:33 --> Output Class Initialized
INFO - 2021-06-17 06:03:33 --> Security Class Initialized
DEBUG - 2021-06-17 06:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:03:33 --> Input Class Initialized
INFO - 2021-06-17 06:03:33 --> Language Class Initialized
INFO - 2021-06-17 06:03:33 --> Language Class Initialized
INFO - 2021-06-17 06:03:33 --> Config Class Initialized
INFO - 2021-06-17 06:03:33 --> Loader Class Initialized
INFO - 2021-06-17 06:03:33 --> Helper loaded: url_helper
INFO - 2021-06-17 06:03:33 --> Helper loaded: file_helper
INFO - 2021-06-17 06:03:33 --> Helper loaded: form_helper
INFO - 2021-06-17 06:03:33 --> Helper loaded: my_helper
INFO - 2021-06-17 06:03:33 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:03:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:03:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:03:33 --> Controller Class Initialized
DEBUG - 2021-06-17 06:03:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-17 06:03:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:03:33 --> Final output sent to browser
DEBUG - 2021-06-17 06:03:33 --> Total execution time: 0.0386
INFO - 2021-06-17 06:03:53 --> Config Class Initialized
INFO - 2021-06-17 06:03:53 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:03:53 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:03:53 --> Utf8 Class Initialized
INFO - 2021-06-17 06:03:53 --> URI Class Initialized
INFO - 2021-06-17 06:03:53 --> Router Class Initialized
INFO - 2021-06-17 06:03:53 --> Output Class Initialized
INFO - 2021-06-17 06:03:53 --> Security Class Initialized
DEBUG - 2021-06-17 06:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:03:53 --> Input Class Initialized
INFO - 2021-06-17 06:03:53 --> Language Class Initialized
INFO - 2021-06-17 06:03:53 --> Language Class Initialized
INFO - 2021-06-17 06:03:53 --> Config Class Initialized
INFO - 2021-06-17 06:03:53 --> Loader Class Initialized
INFO - 2021-06-17 06:03:53 --> Helper loaded: url_helper
INFO - 2021-06-17 06:03:53 --> Helper loaded: file_helper
INFO - 2021-06-17 06:03:53 --> Helper loaded: form_helper
INFO - 2021-06-17 06:03:53 --> Helper loaded: my_helper
INFO - 2021-06-17 06:03:53 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:03:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:03:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:03:53 --> Controller Class Initialized
INFO - 2021-06-17 06:03:53 --> Final output sent to browser
DEBUG - 2021-06-17 06:03:53 --> Total execution time: 0.0468
INFO - 2021-06-17 06:03:58 --> Config Class Initialized
INFO - 2021-06-17 06:03:58 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:03:58 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:03:58 --> Utf8 Class Initialized
INFO - 2021-06-17 06:03:58 --> URI Class Initialized
INFO - 2021-06-17 06:03:58 --> Router Class Initialized
INFO - 2021-06-17 06:03:58 --> Output Class Initialized
INFO - 2021-06-17 06:03:58 --> Security Class Initialized
DEBUG - 2021-06-17 06:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:03:58 --> Input Class Initialized
INFO - 2021-06-17 06:03:58 --> Language Class Initialized
INFO - 2021-06-17 06:03:58 --> Language Class Initialized
INFO - 2021-06-17 06:03:58 --> Config Class Initialized
INFO - 2021-06-17 06:03:58 --> Loader Class Initialized
INFO - 2021-06-17 06:03:58 --> Helper loaded: url_helper
INFO - 2021-06-17 06:03:58 --> Helper loaded: file_helper
INFO - 2021-06-17 06:03:58 --> Helper loaded: form_helper
INFO - 2021-06-17 06:03:58 --> Helper loaded: my_helper
INFO - 2021-06-17 06:03:58 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:03:58 --> Controller Class Initialized
INFO - 2021-06-17 06:03:58 --> Helper loaded: cookie_helper
INFO - 2021-06-17 06:03:58 --> Final output sent to browser
DEBUG - 2021-06-17 06:03:58 --> Total execution time: 0.0491
INFO - 2021-06-17 06:03:58 --> Config Class Initialized
INFO - 2021-06-17 06:03:58 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:03:58 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:03:58 --> Utf8 Class Initialized
INFO - 2021-06-17 06:03:58 --> URI Class Initialized
INFO - 2021-06-17 06:03:58 --> Router Class Initialized
INFO - 2021-06-17 06:03:58 --> Output Class Initialized
INFO - 2021-06-17 06:03:58 --> Security Class Initialized
DEBUG - 2021-06-17 06:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:03:58 --> Input Class Initialized
INFO - 2021-06-17 06:03:58 --> Language Class Initialized
INFO - 2021-06-17 06:03:58 --> Language Class Initialized
INFO - 2021-06-17 06:03:58 --> Config Class Initialized
INFO - 2021-06-17 06:03:58 --> Loader Class Initialized
INFO - 2021-06-17 06:03:58 --> Helper loaded: url_helper
INFO - 2021-06-17 06:03:58 --> Helper loaded: file_helper
INFO - 2021-06-17 06:03:58 --> Helper loaded: form_helper
INFO - 2021-06-17 06:03:58 --> Helper loaded: my_helper
INFO - 2021-06-17 06:03:58 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:03:58 --> Controller Class Initialized
DEBUG - 2021-06-17 06:03:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-17 06:03:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:03:59 --> Final output sent to browser
DEBUG - 2021-06-17 06:03:59 --> Total execution time: 0.1964
INFO - 2021-06-17 06:04:00 --> Config Class Initialized
INFO - 2021-06-17 06:04:00 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:04:00 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:04:00 --> Utf8 Class Initialized
INFO - 2021-06-17 06:04:00 --> URI Class Initialized
INFO - 2021-06-17 06:04:00 --> Router Class Initialized
INFO - 2021-06-17 06:04:00 --> Output Class Initialized
INFO - 2021-06-17 06:04:00 --> Security Class Initialized
DEBUG - 2021-06-17 06:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:04:00 --> Input Class Initialized
INFO - 2021-06-17 06:04:00 --> Language Class Initialized
INFO - 2021-06-17 06:04:00 --> Language Class Initialized
INFO - 2021-06-17 06:04:00 --> Config Class Initialized
INFO - 2021-06-17 06:04:00 --> Loader Class Initialized
INFO - 2021-06-17 06:04:00 --> Helper loaded: url_helper
INFO - 2021-06-17 06:04:00 --> Helper loaded: file_helper
INFO - 2021-06-17 06:04:00 --> Helper loaded: form_helper
INFO - 2021-06-17 06:04:00 --> Helper loaded: my_helper
INFO - 2021-06-17 06:04:00 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:04:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:04:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:04:00 --> Controller Class Initialized
DEBUG - 2021-06-17 06:04:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-17 06:04:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:04:00 --> Final output sent to browser
DEBUG - 2021-06-17 06:04:00 --> Total execution time: 0.0407
INFO - 2021-06-17 06:04:03 --> Config Class Initialized
INFO - 2021-06-17 06:04:03 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:04:03 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:04:03 --> Utf8 Class Initialized
INFO - 2021-06-17 06:04:03 --> URI Class Initialized
INFO - 2021-06-17 06:04:03 --> Router Class Initialized
INFO - 2021-06-17 06:04:03 --> Output Class Initialized
INFO - 2021-06-17 06:04:03 --> Security Class Initialized
DEBUG - 2021-06-17 06:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:04:03 --> Input Class Initialized
INFO - 2021-06-17 06:04:03 --> Language Class Initialized
INFO - 2021-06-17 06:04:03 --> Language Class Initialized
INFO - 2021-06-17 06:04:03 --> Config Class Initialized
INFO - 2021-06-17 06:04:03 --> Loader Class Initialized
INFO - 2021-06-17 06:04:03 --> Helper loaded: url_helper
INFO - 2021-06-17 06:04:03 --> Helper loaded: file_helper
INFO - 2021-06-17 06:04:03 --> Helper loaded: form_helper
INFO - 2021-06-17 06:04:03 --> Helper loaded: my_helper
INFO - 2021-06-17 06:04:03 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:04:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:04:03 --> Controller Class Initialized
DEBUG - 2021-06-17 06:04:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-17 06:04:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:04:03 --> Final output sent to browser
DEBUG - 2021-06-17 06:04:03 --> Total execution time: 0.0438
INFO - 2021-06-17 06:04:04 --> Config Class Initialized
INFO - 2021-06-17 06:04:04 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:04:04 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:04:04 --> Utf8 Class Initialized
INFO - 2021-06-17 06:04:04 --> URI Class Initialized
INFO - 2021-06-17 06:04:04 --> Router Class Initialized
INFO - 2021-06-17 06:04:04 --> Output Class Initialized
INFO - 2021-06-17 06:04:04 --> Security Class Initialized
DEBUG - 2021-06-17 06:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:04:04 --> Input Class Initialized
INFO - 2021-06-17 06:04:04 --> Language Class Initialized
INFO - 2021-06-17 06:04:04 --> Language Class Initialized
INFO - 2021-06-17 06:04:04 --> Config Class Initialized
INFO - 2021-06-17 06:04:04 --> Loader Class Initialized
INFO - 2021-06-17 06:04:04 --> Helper loaded: url_helper
INFO - 2021-06-17 06:04:04 --> Helper loaded: file_helper
INFO - 2021-06-17 06:04:04 --> Helper loaded: form_helper
INFO - 2021-06-17 06:04:04 --> Helper loaded: my_helper
INFO - 2021-06-17 06:04:04 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:04:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:04:04 --> Controller Class Initialized
INFO - 2021-06-17 06:04:05 --> Config Class Initialized
INFO - 2021-06-17 06:04:05 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:04:05 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:04:05 --> Utf8 Class Initialized
INFO - 2021-06-17 06:04:05 --> URI Class Initialized
INFO - 2021-06-17 06:04:05 --> Router Class Initialized
INFO - 2021-06-17 06:04:05 --> Output Class Initialized
INFO - 2021-06-17 06:04:05 --> Security Class Initialized
DEBUG - 2021-06-17 06:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:04:05 --> Input Class Initialized
INFO - 2021-06-17 06:04:05 --> Language Class Initialized
INFO - 2021-06-17 06:04:05 --> Language Class Initialized
INFO - 2021-06-17 06:04:05 --> Config Class Initialized
INFO - 2021-06-17 06:04:05 --> Loader Class Initialized
INFO - 2021-06-17 06:04:05 --> Helper loaded: url_helper
INFO - 2021-06-17 06:04:05 --> Helper loaded: file_helper
INFO - 2021-06-17 06:04:05 --> Helper loaded: form_helper
INFO - 2021-06-17 06:04:05 --> Helper loaded: my_helper
INFO - 2021-06-17 06:04:05 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:04:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:04:05 --> Controller Class Initialized
DEBUG - 2021-06-17 06:04:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 06:04:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:04:05 --> Final output sent to browser
DEBUG - 2021-06-17 06:04:05 --> Total execution time: 0.0449
INFO - 2021-06-17 06:04:09 --> Config Class Initialized
INFO - 2021-06-17 06:04:09 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:04:09 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:04:09 --> Utf8 Class Initialized
INFO - 2021-06-17 06:04:09 --> URI Class Initialized
INFO - 2021-06-17 06:04:09 --> Router Class Initialized
INFO - 2021-06-17 06:04:09 --> Output Class Initialized
INFO - 2021-06-17 06:04:09 --> Security Class Initialized
DEBUG - 2021-06-17 06:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:04:09 --> Input Class Initialized
INFO - 2021-06-17 06:04:09 --> Language Class Initialized
INFO - 2021-06-17 06:04:09 --> Language Class Initialized
INFO - 2021-06-17 06:04:09 --> Config Class Initialized
INFO - 2021-06-17 06:04:09 --> Loader Class Initialized
INFO - 2021-06-17 06:04:09 --> Helper loaded: url_helper
INFO - 2021-06-17 06:04:09 --> Helper loaded: file_helper
INFO - 2021-06-17 06:04:09 --> Helper loaded: form_helper
INFO - 2021-06-17 06:04:09 --> Helper loaded: my_helper
INFO - 2021-06-17 06:04:09 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:04:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:04:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:04:09 --> Controller Class Initialized
INFO - 2021-06-17 06:04:09 --> Final output sent to browser
DEBUG - 2021-06-17 06:04:09 --> Total execution time: 0.0497
INFO - 2021-06-17 06:04:11 --> Config Class Initialized
INFO - 2021-06-17 06:04:11 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:04:11 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:04:11 --> Utf8 Class Initialized
INFO - 2021-06-17 06:04:11 --> URI Class Initialized
INFO - 2021-06-17 06:04:11 --> Router Class Initialized
INFO - 2021-06-17 06:04:11 --> Output Class Initialized
INFO - 2021-06-17 06:04:11 --> Security Class Initialized
DEBUG - 2021-06-17 06:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:04:11 --> Input Class Initialized
INFO - 2021-06-17 06:04:11 --> Language Class Initialized
INFO - 2021-06-17 06:04:11 --> Language Class Initialized
INFO - 2021-06-17 06:04:11 --> Config Class Initialized
INFO - 2021-06-17 06:04:11 --> Loader Class Initialized
INFO - 2021-06-17 06:04:11 --> Helper loaded: url_helper
INFO - 2021-06-17 06:04:11 --> Helper loaded: file_helper
INFO - 2021-06-17 06:04:11 --> Helper loaded: form_helper
INFO - 2021-06-17 06:04:11 --> Helper loaded: my_helper
INFO - 2021-06-17 06:04:11 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:04:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:04:11 --> Controller Class Initialized
INFO - 2021-06-17 06:04:11 --> Final output sent to browser
DEBUG - 2021-06-17 06:04:11 --> Total execution time: 0.0493
INFO - 2021-06-17 06:04:47 --> Config Class Initialized
INFO - 2021-06-17 06:04:47 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:04:47 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:04:47 --> Utf8 Class Initialized
INFO - 2021-06-17 06:04:47 --> URI Class Initialized
INFO - 2021-06-17 06:04:47 --> Router Class Initialized
INFO - 2021-06-17 06:04:47 --> Output Class Initialized
INFO - 2021-06-17 06:04:47 --> Security Class Initialized
DEBUG - 2021-06-17 06:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:04:47 --> Input Class Initialized
INFO - 2021-06-17 06:04:47 --> Language Class Initialized
INFO - 2021-06-17 06:04:47 --> Language Class Initialized
INFO - 2021-06-17 06:04:47 --> Config Class Initialized
INFO - 2021-06-17 06:04:47 --> Loader Class Initialized
INFO - 2021-06-17 06:04:47 --> Helper loaded: url_helper
INFO - 2021-06-17 06:04:47 --> Helper loaded: file_helper
INFO - 2021-06-17 06:04:47 --> Helper loaded: form_helper
INFO - 2021-06-17 06:04:47 --> Helper loaded: my_helper
INFO - 2021-06-17 06:04:47 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:04:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:04:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:04:47 --> Controller Class Initialized
INFO - 2021-06-17 06:10:16 --> Config Class Initialized
INFO - 2021-06-17 06:10:16 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:10:16 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:10:16 --> Utf8 Class Initialized
INFO - 2021-06-17 06:10:16 --> URI Class Initialized
INFO - 2021-06-17 06:10:16 --> Router Class Initialized
INFO - 2021-06-17 06:10:16 --> Output Class Initialized
INFO - 2021-06-17 06:10:16 --> Security Class Initialized
DEBUG - 2021-06-17 06:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:10:16 --> Input Class Initialized
INFO - 2021-06-17 06:10:16 --> Language Class Initialized
INFO - 2021-06-17 06:10:16 --> Language Class Initialized
INFO - 2021-06-17 06:10:16 --> Config Class Initialized
INFO - 2021-06-17 06:10:16 --> Loader Class Initialized
INFO - 2021-06-17 06:10:16 --> Helper loaded: url_helper
INFO - 2021-06-17 06:10:16 --> Helper loaded: file_helper
INFO - 2021-06-17 06:10:16 --> Helper loaded: form_helper
INFO - 2021-06-17 06:10:16 --> Helper loaded: my_helper
INFO - 2021-06-17 06:10:16 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:10:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:10:16 --> Controller Class Initialized
INFO - 2021-06-17 06:10:16 --> Helper loaded: cookie_helper
INFO - 2021-06-17 06:10:16 --> Config Class Initialized
INFO - 2021-06-17 06:10:16 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:10:16 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:10:16 --> Utf8 Class Initialized
INFO - 2021-06-17 06:10:16 --> URI Class Initialized
INFO - 2021-06-17 06:10:16 --> Router Class Initialized
INFO - 2021-06-17 06:10:16 --> Output Class Initialized
INFO - 2021-06-17 06:10:16 --> Security Class Initialized
DEBUG - 2021-06-17 06:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:10:16 --> Input Class Initialized
INFO - 2021-06-17 06:10:16 --> Language Class Initialized
INFO - 2021-06-17 06:10:16 --> Language Class Initialized
INFO - 2021-06-17 06:10:16 --> Config Class Initialized
INFO - 2021-06-17 06:10:16 --> Loader Class Initialized
INFO - 2021-06-17 06:10:16 --> Helper loaded: url_helper
INFO - 2021-06-17 06:10:16 --> Helper loaded: file_helper
INFO - 2021-06-17 06:10:16 --> Helper loaded: form_helper
INFO - 2021-06-17 06:10:16 --> Helper loaded: my_helper
INFO - 2021-06-17 06:10:16 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:10:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:10:16 --> Controller Class Initialized
DEBUG - 2021-06-17 06:10:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-17 06:10:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:10:16 --> Final output sent to browser
DEBUG - 2021-06-17 06:10:16 --> Total execution time: 0.0383
INFO - 2021-06-17 06:10:20 --> Config Class Initialized
INFO - 2021-06-17 06:10:20 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:10:20 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:10:20 --> Utf8 Class Initialized
INFO - 2021-06-17 06:10:20 --> URI Class Initialized
INFO - 2021-06-17 06:10:20 --> Router Class Initialized
INFO - 2021-06-17 06:10:20 --> Output Class Initialized
INFO - 2021-06-17 06:10:20 --> Security Class Initialized
DEBUG - 2021-06-17 06:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:10:20 --> Input Class Initialized
INFO - 2021-06-17 06:10:20 --> Language Class Initialized
INFO - 2021-06-17 06:10:20 --> Language Class Initialized
INFO - 2021-06-17 06:10:20 --> Config Class Initialized
INFO - 2021-06-17 06:10:20 --> Loader Class Initialized
INFO - 2021-06-17 06:10:20 --> Helper loaded: url_helper
INFO - 2021-06-17 06:10:20 --> Helper loaded: file_helper
INFO - 2021-06-17 06:10:20 --> Helper loaded: form_helper
INFO - 2021-06-17 06:10:20 --> Helper loaded: my_helper
INFO - 2021-06-17 06:10:20 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:10:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:10:20 --> Controller Class Initialized
INFO - 2021-06-17 06:10:20 --> Helper loaded: cookie_helper
INFO - 2021-06-17 06:10:20 --> Final output sent to browser
DEBUG - 2021-06-17 06:10:20 --> Total execution time: 0.0391
INFO - 2021-06-17 06:10:20 --> Config Class Initialized
INFO - 2021-06-17 06:10:20 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:10:20 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:10:20 --> Utf8 Class Initialized
INFO - 2021-06-17 06:10:20 --> URI Class Initialized
INFO - 2021-06-17 06:10:20 --> Router Class Initialized
INFO - 2021-06-17 06:10:20 --> Output Class Initialized
INFO - 2021-06-17 06:10:20 --> Security Class Initialized
DEBUG - 2021-06-17 06:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:10:20 --> Input Class Initialized
INFO - 2021-06-17 06:10:20 --> Language Class Initialized
INFO - 2021-06-17 06:10:20 --> Language Class Initialized
INFO - 2021-06-17 06:10:20 --> Config Class Initialized
INFO - 2021-06-17 06:10:20 --> Loader Class Initialized
INFO - 2021-06-17 06:10:20 --> Helper loaded: url_helper
INFO - 2021-06-17 06:10:20 --> Helper loaded: file_helper
INFO - 2021-06-17 06:10:20 --> Helper loaded: form_helper
INFO - 2021-06-17 06:10:20 --> Helper loaded: my_helper
INFO - 2021-06-17 06:10:20 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:10:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:10:20 --> Controller Class Initialized
DEBUG - 2021-06-17 06:10:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-17 06:10:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:10:21 --> Final output sent to browser
DEBUG - 2021-06-17 06:10:21 --> Total execution time: 0.1903
INFO - 2021-06-17 06:10:22 --> Config Class Initialized
INFO - 2021-06-17 06:10:22 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:10:22 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:10:22 --> Utf8 Class Initialized
INFO - 2021-06-17 06:10:22 --> URI Class Initialized
INFO - 2021-06-17 06:10:22 --> Router Class Initialized
INFO - 2021-06-17 06:10:22 --> Output Class Initialized
INFO - 2021-06-17 06:10:22 --> Security Class Initialized
DEBUG - 2021-06-17 06:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:10:22 --> Input Class Initialized
INFO - 2021-06-17 06:10:22 --> Language Class Initialized
INFO - 2021-06-17 06:10:22 --> Language Class Initialized
INFO - 2021-06-17 06:10:22 --> Config Class Initialized
INFO - 2021-06-17 06:10:22 --> Loader Class Initialized
INFO - 2021-06-17 06:10:22 --> Helper loaded: url_helper
INFO - 2021-06-17 06:10:22 --> Helper loaded: file_helper
INFO - 2021-06-17 06:10:22 --> Helper loaded: form_helper
INFO - 2021-06-17 06:10:22 --> Helper loaded: my_helper
INFO - 2021-06-17 06:10:22 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:10:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:10:22 --> Controller Class Initialized
DEBUG - 2021-06-17 06:10:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-17 06:10:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:10:22 --> Final output sent to browser
DEBUG - 2021-06-17 06:10:22 --> Total execution time: 0.0409
INFO - 2021-06-17 06:10:36 --> Config Class Initialized
INFO - 2021-06-17 06:10:36 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:10:36 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:10:36 --> Utf8 Class Initialized
INFO - 2021-06-17 06:10:36 --> URI Class Initialized
INFO - 2021-06-17 06:10:36 --> Router Class Initialized
INFO - 2021-06-17 06:10:36 --> Output Class Initialized
INFO - 2021-06-17 06:10:36 --> Security Class Initialized
DEBUG - 2021-06-17 06:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:10:36 --> Input Class Initialized
INFO - 2021-06-17 06:10:36 --> Language Class Initialized
INFO - 2021-06-17 06:10:36 --> Language Class Initialized
INFO - 2021-06-17 06:10:36 --> Config Class Initialized
INFO - 2021-06-17 06:10:36 --> Loader Class Initialized
INFO - 2021-06-17 06:10:36 --> Helper loaded: url_helper
INFO - 2021-06-17 06:10:36 --> Helper loaded: file_helper
INFO - 2021-06-17 06:10:36 --> Helper loaded: form_helper
INFO - 2021-06-17 06:10:36 --> Helper loaded: my_helper
INFO - 2021-06-17 06:10:36 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:10:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:10:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:10:36 --> Controller Class Initialized
DEBUG - 2021-06-17 06:10:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-17 06:10:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:10:36 --> Final output sent to browser
DEBUG - 2021-06-17 06:10:36 --> Total execution time: 0.0450
INFO - 2021-06-17 06:10:36 --> Config Class Initialized
INFO - 2021-06-17 06:10:36 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:10:36 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:10:36 --> Utf8 Class Initialized
INFO - 2021-06-17 06:10:36 --> URI Class Initialized
INFO - 2021-06-17 06:10:36 --> Router Class Initialized
INFO - 2021-06-17 06:10:36 --> Output Class Initialized
INFO - 2021-06-17 06:10:36 --> Security Class Initialized
DEBUG - 2021-06-17 06:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:10:36 --> Input Class Initialized
INFO - 2021-06-17 06:10:36 --> Language Class Initialized
INFO - 2021-06-17 06:10:36 --> Language Class Initialized
INFO - 2021-06-17 06:10:36 --> Config Class Initialized
INFO - 2021-06-17 06:10:36 --> Loader Class Initialized
INFO - 2021-06-17 06:10:36 --> Helper loaded: url_helper
INFO - 2021-06-17 06:10:36 --> Helper loaded: file_helper
INFO - 2021-06-17 06:10:36 --> Helper loaded: form_helper
INFO - 2021-06-17 06:10:36 --> Helper loaded: my_helper
INFO - 2021-06-17 06:10:36 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:10:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:10:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:10:36 --> Controller Class Initialized
INFO - 2021-06-17 06:10:38 --> Config Class Initialized
INFO - 2021-06-17 06:10:38 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:10:38 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:10:38 --> Utf8 Class Initialized
INFO - 2021-06-17 06:10:38 --> URI Class Initialized
INFO - 2021-06-17 06:10:38 --> Router Class Initialized
INFO - 2021-06-17 06:10:38 --> Output Class Initialized
INFO - 2021-06-17 06:10:38 --> Security Class Initialized
DEBUG - 2021-06-17 06:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:10:38 --> Input Class Initialized
INFO - 2021-06-17 06:10:38 --> Language Class Initialized
INFO - 2021-06-17 06:10:38 --> Language Class Initialized
INFO - 2021-06-17 06:10:38 --> Config Class Initialized
INFO - 2021-06-17 06:10:38 --> Loader Class Initialized
INFO - 2021-06-17 06:10:38 --> Helper loaded: url_helper
INFO - 2021-06-17 06:10:38 --> Helper loaded: file_helper
INFO - 2021-06-17 06:10:38 --> Helper loaded: form_helper
INFO - 2021-06-17 06:10:38 --> Helper loaded: my_helper
INFO - 2021-06-17 06:10:38 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:10:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:10:38 --> Controller Class Initialized
DEBUG - 2021-06-17 06:10:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 06:10:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:10:38 --> Final output sent to browser
DEBUG - 2021-06-17 06:10:38 --> Total execution time: 0.0446
INFO - 2021-06-17 06:10:41 --> Config Class Initialized
INFO - 2021-06-17 06:10:41 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:10:41 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:10:41 --> Utf8 Class Initialized
INFO - 2021-06-17 06:10:41 --> URI Class Initialized
INFO - 2021-06-17 06:10:41 --> Router Class Initialized
INFO - 2021-06-17 06:10:41 --> Output Class Initialized
INFO - 2021-06-17 06:10:41 --> Security Class Initialized
DEBUG - 2021-06-17 06:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:10:41 --> Input Class Initialized
INFO - 2021-06-17 06:10:41 --> Language Class Initialized
INFO - 2021-06-17 06:10:41 --> Language Class Initialized
INFO - 2021-06-17 06:10:41 --> Config Class Initialized
INFO - 2021-06-17 06:10:41 --> Loader Class Initialized
INFO - 2021-06-17 06:10:41 --> Helper loaded: url_helper
INFO - 2021-06-17 06:10:41 --> Helper loaded: file_helper
INFO - 2021-06-17 06:10:41 --> Helper loaded: form_helper
INFO - 2021-06-17 06:10:41 --> Helper loaded: my_helper
INFO - 2021-06-17 06:10:41 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:10:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:10:41 --> Controller Class Initialized
INFO - 2021-06-17 06:10:42 --> Config Class Initialized
INFO - 2021-06-17 06:10:42 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:10:42 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:10:42 --> Utf8 Class Initialized
INFO - 2021-06-17 06:10:42 --> URI Class Initialized
INFO - 2021-06-17 06:10:42 --> Router Class Initialized
INFO - 2021-06-17 06:10:42 --> Output Class Initialized
INFO - 2021-06-17 06:10:42 --> Security Class Initialized
DEBUG - 2021-06-17 06:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:10:42 --> Input Class Initialized
INFO - 2021-06-17 06:10:42 --> Language Class Initialized
INFO - 2021-06-17 06:10:42 --> Language Class Initialized
INFO - 2021-06-17 06:10:42 --> Config Class Initialized
INFO - 2021-06-17 06:10:42 --> Loader Class Initialized
INFO - 2021-06-17 06:10:42 --> Helper loaded: url_helper
INFO - 2021-06-17 06:10:42 --> Helper loaded: file_helper
INFO - 2021-06-17 06:10:42 --> Helper loaded: form_helper
INFO - 2021-06-17 06:10:42 --> Helper loaded: my_helper
INFO - 2021-06-17 06:10:42 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:10:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:10:42 --> Controller Class Initialized
INFO - 2021-06-17 06:11:00 --> Config Class Initialized
INFO - 2021-06-17 06:11:00 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:11:00 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:11:00 --> Utf8 Class Initialized
INFO - 2021-06-17 06:11:00 --> URI Class Initialized
INFO - 2021-06-17 06:11:00 --> Router Class Initialized
INFO - 2021-06-17 06:11:00 --> Output Class Initialized
INFO - 2021-06-17 06:11:00 --> Security Class Initialized
DEBUG - 2021-06-17 06:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:11:00 --> Input Class Initialized
INFO - 2021-06-17 06:11:00 --> Language Class Initialized
INFO - 2021-06-17 06:11:00 --> Language Class Initialized
INFO - 2021-06-17 06:11:00 --> Config Class Initialized
INFO - 2021-06-17 06:11:00 --> Loader Class Initialized
INFO - 2021-06-17 06:11:00 --> Helper loaded: url_helper
INFO - 2021-06-17 06:11:00 --> Helper loaded: file_helper
INFO - 2021-06-17 06:11:00 --> Helper loaded: form_helper
INFO - 2021-06-17 06:11:00 --> Helper loaded: my_helper
INFO - 2021-06-17 06:11:00 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:11:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:11:00 --> Controller Class Initialized
DEBUG - 2021-06-17 06:11:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-17 06:11:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:11:00 --> Final output sent to browser
DEBUG - 2021-06-17 06:11:00 --> Total execution time: 0.0434
INFO - 2021-06-17 06:11:00 --> Config Class Initialized
INFO - 2021-06-17 06:11:00 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:11:00 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:11:00 --> Utf8 Class Initialized
INFO - 2021-06-17 06:11:00 --> URI Class Initialized
INFO - 2021-06-17 06:11:00 --> Router Class Initialized
INFO - 2021-06-17 06:11:00 --> Output Class Initialized
INFO - 2021-06-17 06:11:00 --> Security Class Initialized
DEBUG - 2021-06-17 06:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:11:00 --> Input Class Initialized
INFO - 2021-06-17 06:11:00 --> Language Class Initialized
INFO - 2021-06-17 06:11:00 --> Language Class Initialized
INFO - 2021-06-17 06:11:00 --> Config Class Initialized
INFO - 2021-06-17 06:11:00 --> Loader Class Initialized
INFO - 2021-06-17 06:11:00 --> Helper loaded: url_helper
INFO - 2021-06-17 06:11:00 --> Helper loaded: file_helper
INFO - 2021-06-17 06:11:00 --> Helper loaded: form_helper
INFO - 2021-06-17 06:11:00 --> Helper loaded: my_helper
INFO - 2021-06-17 06:11:00 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:11:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:11:00 --> Controller Class Initialized
INFO - 2021-06-17 06:11:02 --> Config Class Initialized
INFO - 2021-06-17 06:11:02 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:11:02 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:11:02 --> Utf8 Class Initialized
INFO - 2021-06-17 06:11:02 --> URI Class Initialized
INFO - 2021-06-17 06:11:02 --> Router Class Initialized
INFO - 2021-06-17 06:11:02 --> Output Class Initialized
INFO - 2021-06-17 06:11:02 --> Security Class Initialized
DEBUG - 2021-06-17 06:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:11:02 --> Input Class Initialized
INFO - 2021-06-17 06:11:02 --> Language Class Initialized
INFO - 2021-06-17 06:11:02 --> Language Class Initialized
INFO - 2021-06-17 06:11:02 --> Config Class Initialized
INFO - 2021-06-17 06:11:02 --> Loader Class Initialized
INFO - 2021-06-17 06:11:02 --> Helper loaded: url_helper
INFO - 2021-06-17 06:11:02 --> Helper loaded: file_helper
INFO - 2021-06-17 06:11:02 --> Helper loaded: form_helper
INFO - 2021-06-17 06:11:02 --> Helper loaded: my_helper
INFO - 2021-06-17 06:11:02 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:11:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:11:02 --> Controller Class Initialized
DEBUG - 2021-06-17 06:11:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 06:11:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:11:02 --> Final output sent to browser
DEBUG - 2021-06-17 06:11:02 --> Total execution time: 0.0430
INFO - 2021-06-17 06:11:03 --> Config Class Initialized
INFO - 2021-06-17 06:11:03 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:11:03 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:11:03 --> Utf8 Class Initialized
INFO - 2021-06-17 06:11:03 --> URI Class Initialized
INFO - 2021-06-17 06:11:03 --> Router Class Initialized
INFO - 2021-06-17 06:11:03 --> Output Class Initialized
INFO - 2021-06-17 06:11:03 --> Security Class Initialized
DEBUG - 2021-06-17 06:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:11:03 --> Input Class Initialized
INFO - 2021-06-17 06:11:03 --> Language Class Initialized
INFO - 2021-06-17 06:11:03 --> Language Class Initialized
INFO - 2021-06-17 06:11:03 --> Config Class Initialized
INFO - 2021-06-17 06:11:03 --> Loader Class Initialized
INFO - 2021-06-17 06:11:03 --> Helper loaded: url_helper
INFO - 2021-06-17 06:11:03 --> Helper loaded: file_helper
INFO - 2021-06-17 06:11:03 --> Helper loaded: form_helper
INFO - 2021-06-17 06:11:03 --> Helper loaded: my_helper
INFO - 2021-06-17 06:11:03 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:11:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:11:03 --> Controller Class Initialized
INFO - 2021-06-17 06:11:04 --> Config Class Initialized
INFO - 2021-06-17 06:11:04 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:11:04 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:11:04 --> Utf8 Class Initialized
INFO - 2021-06-17 06:11:04 --> URI Class Initialized
INFO - 2021-06-17 06:11:04 --> Router Class Initialized
INFO - 2021-06-17 06:11:04 --> Output Class Initialized
INFO - 2021-06-17 06:11:04 --> Security Class Initialized
DEBUG - 2021-06-17 06:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:11:04 --> Input Class Initialized
INFO - 2021-06-17 06:11:04 --> Language Class Initialized
INFO - 2021-06-17 06:11:04 --> Language Class Initialized
INFO - 2021-06-17 06:11:04 --> Config Class Initialized
INFO - 2021-06-17 06:11:04 --> Loader Class Initialized
INFO - 2021-06-17 06:11:04 --> Helper loaded: url_helper
INFO - 2021-06-17 06:11:04 --> Helper loaded: file_helper
INFO - 2021-06-17 06:11:04 --> Helper loaded: form_helper
INFO - 2021-06-17 06:11:04 --> Helper loaded: my_helper
INFO - 2021-06-17 06:11:04 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:11:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:11:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:11:04 --> Controller Class Initialized
INFO - 2021-06-17 06:11:59 --> Config Class Initialized
INFO - 2021-06-17 06:11:59 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:11:59 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:11:59 --> Utf8 Class Initialized
INFO - 2021-06-17 06:11:59 --> URI Class Initialized
INFO - 2021-06-17 06:11:59 --> Router Class Initialized
INFO - 2021-06-17 06:11:59 --> Output Class Initialized
INFO - 2021-06-17 06:11:59 --> Security Class Initialized
DEBUG - 2021-06-17 06:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:11:59 --> Input Class Initialized
INFO - 2021-06-17 06:11:59 --> Language Class Initialized
INFO - 2021-06-17 06:11:59 --> Language Class Initialized
INFO - 2021-06-17 06:11:59 --> Config Class Initialized
INFO - 2021-06-17 06:11:59 --> Loader Class Initialized
INFO - 2021-06-17 06:11:59 --> Helper loaded: url_helper
INFO - 2021-06-17 06:11:59 --> Helper loaded: file_helper
INFO - 2021-06-17 06:11:59 --> Helper loaded: form_helper
INFO - 2021-06-17 06:11:59 --> Helper loaded: my_helper
INFO - 2021-06-17 06:11:59 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:11:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:11:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:11:59 --> Controller Class Initialized
INFO - 2021-06-17 06:11:59 --> Helper loaded: cookie_helper
INFO - 2021-06-17 06:11:59 --> Config Class Initialized
INFO - 2021-06-17 06:11:59 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:11:59 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:11:59 --> Utf8 Class Initialized
INFO - 2021-06-17 06:11:59 --> URI Class Initialized
INFO - 2021-06-17 06:11:59 --> Router Class Initialized
INFO - 2021-06-17 06:11:59 --> Output Class Initialized
INFO - 2021-06-17 06:11:59 --> Security Class Initialized
DEBUG - 2021-06-17 06:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:11:59 --> Input Class Initialized
INFO - 2021-06-17 06:11:59 --> Language Class Initialized
INFO - 2021-06-17 06:11:59 --> Language Class Initialized
INFO - 2021-06-17 06:11:59 --> Config Class Initialized
INFO - 2021-06-17 06:11:59 --> Loader Class Initialized
INFO - 2021-06-17 06:11:59 --> Helper loaded: url_helper
INFO - 2021-06-17 06:11:59 --> Helper loaded: file_helper
INFO - 2021-06-17 06:11:59 --> Helper loaded: form_helper
INFO - 2021-06-17 06:11:59 --> Helper loaded: my_helper
INFO - 2021-06-17 06:11:59 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:11:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:11:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:11:59 --> Controller Class Initialized
DEBUG - 2021-06-17 06:11:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-17 06:11:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:11:59 --> Final output sent to browser
DEBUG - 2021-06-17 06:11:59 --> Total execution time: 0.0496
INFO - 2021-06-17 06:12:05 --> Config Class Initialized
INFO - 2021-06-17 06:12:05 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:12:05 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:12:05 --> Utf8 Class Initialized
INFO - 2021-06-17 06:12:05 --> URI Class Initialized
INFO - 2021-06-17 06:12:05 --> Router Class Initialized
INFO - 2021-06-17 06:12:05 --> Output Class Initialized
INFO - 2021-06-17 06:12:05 --> Security Class Initialized
DEBUG - 2021-06-17 06:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:12:05 --> Input Class Initialized
INFO - 2021-06-17 06:12:05 --> Language Class Initialized
INFO - 2021-06-17 06:12:05 --> Language Class Initialized
INFO - 2021-06-17 06:12:05 --> Config Class Initialized
INFO - 2021-06-17 06:12:05 --> Loader Class Initialized
INFO - 2021-06-17 06:12:05 --> Helper loaded: url_helper
INFO - 2021-06-17 06:12:05 --> Helper loaded: file_helper
INFO - 2021-06-17 06:12:05 --> Helper loaded: form_helper
INFO - 2021-06-17 06:12:05 --> Helper loaded: my_helper
INFO - 2021-06-17 06:12:05 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:12:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:12:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:12:05 --> Controller Class Initialized
INFO - 2021-06-17 06:12:05 --> Helper loaded: cookie_helper
INFO - 2021-06-17 06:12:05 --> Final output sent to browser
DEBUG - 2021-06-17 06:12:05 --> Total execution time: 0.0501
INFO - 2021-06-17 06:12:05 --> Config Class Initialized
INFO - 2021-06-17 06:12:05 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:12:05 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:12:05 --> Utf8 Class Initialized
INFO - 2021-06-17 06:12:05 --> URI Class Initialized
INFO - 2021-06-17 06:12:05 --> Router Class Initialized
INFO - 2021-06-17 06:12:05 --> Output Class Initialized
INFO - 2021-06-17 06:12:05 --> Security Class Initialized
DEBUG - 2021-06-17 06:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:12:05 --> Input Class Initialized
INFO - 2021-06-17 06:12:05 --> Language Class Initialized
INFO - 2021-06-17 06:12:05 --> Language Class Initialized
INFO - 2021-06-17 06:12:05 --> Config Class Initialized
INFO - 2021-06-17 06:12:05 --> Loader Class Initialized
INFO - 2021-06-17 06:12:05 --> Helper loaded: url_helper
INFO - 2021-06-17 06:12:05 --> Helper loaded: file_helper
INFO - 2021-06-17 06:12:05 --> Helper loaded: form_helper
INFO - 2021-06-17 06:12:05 --> Helper loaded: my_helper
INFO - 2021-06-17 06:12:05 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:12:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:12:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:12:05 --> Controller Class Initialized
DEBUG - 2021-06-17 06:12:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-17 06:12:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:12:05 --> Final output sent to browser
DEBUG - 2021-06-17 06:12:05 --> Total execution time: 0.1921
INFO - 2021-06-17 06:12:06 --> Config Class Initialized
INFO - 2021-06-17 06:12:06 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:12:06 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:12:06 --> Utf8 Class Initialized
INFO - 2021-06-17 06:12:06 --> URI Class Initialized
INFO - 2021-06-17 06:12:06 --> Router Class Initialized
INFO - 2021-06-17 06:12:07 --> Output Class Initialized
INFO - 2021-06-17 06:12:07 --> Security Class Initialized
DEBUG - 2021-06-17 06:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:12:07 --> Input Class Initialized
INFO - 2021-06-17 06:12:07 --> Language Class Initialized
INFO - 2021-06-17 06:12:07 --> Language Class Initialized
INFO - 2021-06-17 06:12:07 --> Config Class Initialized
INFO - 2021-06-17 06:12:07 --> Loader Class Initialized
INFO - 2021-06-17 06:12:07 --> Helper loaded: url_helper
INFO - 2021-06-17 06:12:07 --> Helper loaded: file_helper
INFO - 2021-06-17 06:12:07 --> Helper loaded: form_helper
INFO - 2021-06-17 06:12:07 --> Helper loaded: my_helper
INFO - 2021-06-17 06:12:07 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:12:07 --> Controller Class Initialized
DEBUG - 2021-06-17 06:12:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-17 06:12:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:12:07 --> Final output sent to browser
DEBUG - 2021-06-17 06:12:07 --> Total execution time: 0.0500
INFO - 2021-06-17 06:12:11 --> Config Class Initialized
INFO - 2021-06-17 06:12:11 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:12:11 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:12:11 --> Utf8 Class Initialized
INFO - 2021-06-17 06:12:11 --> URI Class Initialized
INFO - 2021-06-17 06:12:11 --> Router Class Initialized
INFO - 2021-06-17 06:12:11 --> Output Class Initialized
INFO - 2021-06-17 06:12:11 --> Security Class Initialized
DEBUG - 2021-06-17 06:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:12:11 --> Input Class Initialized
INFO - 2021-06-17 06:12:11 --> Language Class Initialized
INFO - 2021-06-17 06:12:11 --> Language Class Initialized
INFO - 2021-06-17 06:12:11 --> Config Class Initialized
INFO - 2021-06-17 06:12:11 --> Loader Class Initialized
INFO - 2021-06-17 06:12:11 --> Helper loaded: url_helper
INFO - 2021-06-17 06:12:11 --> Helper loaded: file_helper
INFO - 2021-06-17 06:12:11 --> Helper loaded: form_helper
INFO - 2021-06-17 06:12:11 --> Helper loaded: my_helper
INFO - 2021-06-17 06:12:11 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:12:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:12:11 --> Controller Class Initialized
DEBUG - 2021-06-17 06:12:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-17 06:12:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:12:11 --> Final output sent to browser
DEBUG - 2021-06-17 06:12:11 --> Total execution time: 0.0437
INFO - 2021-06-17 06:12:11 --> Config Class Initialized
INFO - 2021-06-17 06:12:11 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:12:11 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:12:11 --> Utf8 Class Initialized
INFO - 2021-06-17 06:12:11 --> URI Class Initialized
INFO - 2021-06-17 06:12:11 --> Router Class Initialized
INFO - 2021-06-17 06:12:11 --> Output Class Initialized
INFO - 2021-06-17 06:12:11 --> Security Class Initialized
DEBUG - 2021-06-17 06:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:12:11 --> Input Class Initialized
INFO - 2021-06-17 06:12:11 --> Language Class Initialized
INFO - 2021-06-17 06:12:11 --> Language Class Initialized
INFO - 2021-06-17 06:12:11 --> Config Class Initialized
INFO - 2021-06-17 06:12:11 --> Loader Class Initialized
INFO - 2021-06-17 06:12:11 --> Helper loaded: url_helper
INFO - 2021-06-17 06:12:11 --> Helper loaded: file_helper
INFO - 2021-06-17 06:12:11 --> Helper loaded: form_helper
INFO - 2021-06-17 06:12:11 --> Helper loaded: my_helper
INFO - 2021-06-17 06:12:11 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:12:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:12:11 --> Controller Class Initialized
INFO - 2021-06-17 06:12:12 --> Config Class Initialized
INFO - 2021-06-17 06:12:12 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:12:12 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:12:12 --> Utf8 Class Initialized
INFO - 2021-06-17 06:12:12 --> URI Class Initialized
INFO - 2021-06-17 06:12:12 --> Router Class Initialized
INFO - 2021-06-17 06:12:12 --> Output Class Initialized
INFO - 2021-06-17 06:12:12 --> Security Class Initialized
DEBUG - 2021-06-17 06:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:12:12 --> Input Class Initialized
INFO - 2021-06-17 06:12:12 --> Language Class Initialized
INFO - 2021-06-17 06:12:12 --> Language Class Initialized
INFO - 2021-06-17 06:12:12 --> Config Class Initialized
INFO - 2021-06-17 06:12:12 --> Loader Class Initialized
INFO - 2021-06-17 06:12:12 --> Helper loaded: url_helper
INFO - 2021-06-17 06:12:12 --> Helper loaded: file_helper
INFO - 2021-06-17 06:12:12 --> Helper loaded: form_helper
INFO - 2021-06-17 06:12:12 --> Helper loaded: my_helper
INFO - 2021-06-17 06:12:12 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:12:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:12:12 --> Controller Class Initialized
DEBUG - 2021-06-17 06:12:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 06:12:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:12:12 --> Final output sent to browser
DEBUG - 2021-06-17 06:12:12 --> Total execution time: 0.0444
INFO - 2021-06-17 06:12:22 --> Config Class Initialized
INFO - 2021-06-17 06:12:22 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:12:22 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:12:22 --> Utf8 Class Initialized
INFO - 2021-06-17 06:12:22 --> URI Class Initialized
INFO - 2021-06-17 06:12:22 --> Router Class Initialized
INFO - 2021-06-17 06:12:22 --> Output Class Initialized
INFO - 2021-06-17 06:12:22 --> Security Class Initialized
DEBUG - 2021-06-17 06:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:12:22 --> Input Class Initialized
INFO - 2021-06-17 06:12:22 --> Language Class Initialized
INFO - 2021-06-17 06:12:22 --> Language Class Initialized
INFO - 2021-06-17 06:12:22 --> Config Class Initialized
INFO - 2021-06-17 06:12:22 --> Loader Class Initialized
INFO - 2021-06-17 06:12:22 --> Helper loaded: url_helper
INFO - 2021-06-17 06:12:22 --> Helper loaded: file_helper
INFO - 2021-06-17 06:12:22 --> Helper loaded: form_helper
INFO - 2021-06-17 06:12:22 --> Helper loaded: my_helper
INFO - 2021-06-17 06:12:22 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:12:22 --> Controller Class Initialized
INFO - 2021-06-17 06:12:25 --> Config Class Initialized
INFO - 2021-06-17 06:12:25 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:12:25 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:12:25 --> Utf8 Class Initialized
INFO - 2021-06-17 06:12:25 --> URI Class Initialized
INFO - 2021-06-17 06:12:25 --> Router Class Initialized
INFO - 2021-06-17 06:12:25 --> Output Class Initialized
INFO - 2021-06-17 06:12:25 --> Security Class Initialized
DEBUG - 2021-06-17 06:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:12:25 --> Input Class Initialized
INFO - 2021-06-17 06:12:25 --> Language Class Initialized
INFO - 2021-06-17 06:12:25 --> Language Class Initialized
INFO - 2021-06-17 06:12:25 --> Config Class Initialized
INFO - 2021-06-17 06:12:25 --> Loader Class Initialized
INFO - 2021-06-17 06:12:25 --> Helper loaded: url_helper
INFO - 2021-06-17 06:12:25 --> Helper loaded: file_helper
INFO - 2021-06-17 06:12:25 --> Helper loaded: form_helper
INFO - 2021-06-17 06:12:25 --> Helper loaded: my_helper
INFO - 2021-06-17 06:12:25 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:12:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:12:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:12:25 --> Controller Class Initialized
INFO - 2021-06-17 06:12:30 --> Config Class Initialized
INFO - 2021-06-17 06:12:30 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:12:30 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:12:30 --> Utf8 Class Initialized
INFO - 2021-06-17 06:12:30 --> URI Class Initialized
INFO - 2021-06-17 06:12:30 --> Router Class Initialized
INFO - 2021-06-17 06:12:30 --> Output Class Initialized
INFO - 2021-06-17 06:12:30 --> Security Class Initialized
DEBUG - 2021-06-17 06:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:12:30 --> Input Class Initialized
INFO - 2021-06-17 06:12:30 --> Language Class Initialized
INFO - 2021-06-17 06:12:30 --> Language Class Initialized
INFO - 2021-06-17 06:12:30 --> Config Class Initialized
INFO - 2021-06-17 06:12:30 --> Loader Class Initialized
INFO - 2021-06-17 06:12:30 --> Helper loaded: url_helper
INFO - 2021-06-17 06:12:30 --> Helper loaded: file_helper
INFO - 2021-06-17 06:12:30 --> Helper loaded: form_helper
INFO - 2021-06-17 06:12:30 --> Helper loaded: my_helper
INFO - 2021-06-17 06:12:30 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:12:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:12:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:12:30 --> Controller Class Initialized
DEBUG - 2021-06-17 06:12:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-17 06:12:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:12:30 --> Final output sent to browser
DEBUG - 2021-06-17 06:12:30 --> Total execution time: 0.0469
INFO - 2021-06-17 06:12:30 --> Config Class Initialized
INFO - 2021-06-17 06:12:30 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:12:30 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:12:30 --> Utf8 Class Initialized
INFO - 2021-06-17 06:12:30 --> URI Class Initialized
INFO - 2021-06-17 06:12:30 --> Router Class Initialized
INFO - 2021-06-17 06:12:30 --> Output Class Initialized
INFO - 2021-06-17 06:12:30 --> Security Class Initialized
DEBUG - 2021-06-17 06:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:12:30 --> Input Class Initialized
INFO - 2021-06-17 06:12:30 --> Language Class Initialized
INFO - 2021-06-17 06:12:30 --> Language Class Initialized
INFO - 2021-06-17 06:12:30 --> Config Class Initialized
INFO - 2021-06-17 06:12:30 --> Loader Class Initialized
INFO - 2021-06-17 06:12:30 --> Helper loaded: url_helper
INFO - 2021-06-17 06:12:30 --> Helper loaded: file_helper
INFO - 2021-06-17 06:12:30 --> Helper loaded: form_helper
INFO - 2021-06-17 06:12:30 --> Helper loaded: my_helper
INFO - 2021-06-17 06:12:30 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:12:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:12:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:12:30 --> Controller Class Initialized
INFO - 2021-06-17 06:12:31 --> Config Class Initialized
INFO - 2021-06-17 06:12:31 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:12:31 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:12:31 --> Utf8 Class Initialized
INFO - 2021-06-17 06:12:31 --> URI Class Initialized
INFO - 2021-06-17 06:12:31 --> Router Class Initialized
INFO - 2021-06-17 06:12:31 --> Output Class Initialized
INFO - 2021-06-17 06:12:31 --> Security Class Initialized
DEBUG - 2021-06-17 06:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:12:31 --> Input Class Initialized
INFO - 2021-06-17 06:12:31 --> Language Class Initialized
INFO - 2021-06-17 06:12:31 --> Language Class Initialized
INFO - 2021-06-17 06:12:31 --> Config Class Initialized
INFO - 2021-06-17 06:12:31 --> Loader Class Initialized
INFO - 2021-06-17 06:12:31 --> Helper loaded: url_helper
INFO - 2021-06-17 06:12:31 --> Helper loaded: file_helper
INFO - 2021-06-17 06:12:31 --> Helper loaded: form_helper
INFO - 2021-06-17 06:12:31 --> Helper loaded: my_helper
INFO - 2021-06-17 06:12:31 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:12:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:12:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:12:31 --> Controller Class Initialized
DEBUG - 2021-06-17 06:12:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 06:12:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:12:31 --> Final output sent to browser
DEBUG - 2021-06-17 06:12:31 --> Total execution time: 0.0445
INFO - 2021-06-17 06:12:32 --> Config Class Initialized
INFO - 2021-06-17 06:12:32 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:12:32 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:12:32 --> Utf8 Class Initialized
INFO - 2021-06-17 06:12:32 --> URI Class Initialized
INFO - 2021-06-17 06:12:32 --> Router Class Initialized
INFO - 2021-06-17 06:12:32 --> Output Class Initialized
INFO - 2021-06-17 06:12:32 --> Security Class Initialized
DEBUG - 2021-06-17 06:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:12:32 --> Input Class Initialized
INFO - 2021-06-17 06:12:32 --> Language Class Initialized
INFO - 2021-06-17 06:12:32 --> Language Class Initialized
INFO - 2021-06-17 06:12:32 --> Config Class Initialized
INFO - 2021-06-17 06:12:32 --> Loader Class Initialized
INFO - 2021-06-17 06:12:32 --> Helper loaded: url_helper
INFO - 2021-06-17 06:12:32 --> Helper loaded: file_helper
INFO - 2021-06-17 06:12:32 --> Helper loaded: form_helper
INFO - 2021-06-17 06:12:32 --> Helper loaded: my_helper
INFO - 2021-06-17 06:12:32 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:12:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:12:32 --> Controller Class Initialized
INFO - 2021-06-17 06:12:34 --> Config Class Initialized
INFO - 2021-06-17 06:12:34 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:12:34 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:12:34 --> Utf8 Class Initialized
INFO - 2021-06-17 06:12:34 --> URI Class Initialized
INFO - 2021-06-17 06:12:34 --> Router Class Initialized
INFO - 2021-06-17 06:12:34 --> Output Class Initialized
INFO - 2021-06-17 06:12:34 --> Security Class Initialized
DEBUG - 2021-06-17 06:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:12:34 --> Input Class Initialized
INFO - 2021-06-17 06:12:34 --> Language Class Initialized
INFO - 2021-06-17 06:12:34 --> Language Class Initialized
INFO - 2021-06-17 06:12:34 --> Config Class Initialized
INFO - 2021-06-17 06:12:34 --> Loader Class Initialized
INFO - 2021-06-17 06:12:34 --> Helper loaded: url_helper
INFO - 2021-06-17 06:12:34 --> Helper loaded: file_helper
INFO - 2021-06-17 06:12:34 --> Helper loaded: form_helper
INFO - 2021-06-17 06:12:34 --> Helper loaded: my_helper
INFO - 2021-06-17 06:12:34 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:12:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:12:34 --> Controller Class Initialized
INFO - 2021-06-17 06:12:38 --> Config Class Initialized
INFO - 2021-06-17 06:12:38 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:12:38 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:12:38 --> Utf8 Class Initialized
INFO - 2021-06-17 06:12:38 --> URI Class Initialized
INFO - 2021-06-17 06:12:38 --> Router Class Initialized
INFO - 2021-06-17 06:12:38 --> Output Class Initialized
INFO - 2021-06-17 06:12:38 --> Security Class Initialized
DEBUG - 2021-06-17 06:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:12:38 --> Input Class Initialized
INFO - 2021-06-17 06:12:38 --> Language Class Initialized
INFO - 2021-06-17 06:12:38 --> Language Class Initialized
INFO - 2021-06-17 06:12:38 --> Config Class Initialized
INFO - 2021-06-17 06:12:38 --> Loader Class Initialized
INFO - 2021-06-17 06:12:38 --> Helper loaded: url_helper
INFO - 2021-06-17 06:12:38 --> Helper loaded: file_helper
INFO - 2021-06-17 06:12:38 --> Helper loaded: form_helper
INFO - 2021-06-17 06:12:38 --> Helper loaded: my_helper
INFO - 2021-06-17 06:12:38 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:12:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:12:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:12:38 --> Controller Class Initialized
DEBUG - 2021-06-17 06:12:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-17 06:12:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:12:38 --> Final output sent to browser
DEBUG - 2021-06-17 06:12:38 --> Total execution time: 0.0456
INFO - 2021-06-17 06:12:38 --> Config Class Initialized
INFO - 2021-06-17 06:12:38 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:12:38 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:12:38 --> Utf8 Class Initialized
INFO - 2021-06-17 06:12:38 --> URI Class Initialized
INFO - 2021-06-17 06:12:38 --> Router Class Initialized
INFO - 2021-06-17 06:12:38 --> Output Class Initialized
INFO - 2021-06-17 06:12:38 --> Security Class Initialized
DEBUG - 2021-06-17 06:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:12:38 --> Input Class Initialized
INFO - 2021-06-17 06:12:38 --> Language Class Initialized
INFO - 2021-06-17 06:12:38 --> Language Class Initialized
INFO - 2021-06-17 06:12:38 --> Config Class Initialized
INFO - 2021-06-17 06:12:38 --> Loader Class Initialized
INFO - 2021-06-17 06:12:38 --> Helper loaded: url_helper
INFO - 2021-06-17 06:12:38 --> Helper loaded: file_helper
INFO - 2021-06-17 06:12:38 --> Helper loaded: form_helper
INFO - 2021-06-17 06:12:38 --> Helper loaded: my_helper
INFO - 2021-06-17 06:12:38 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:12:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:12:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:12:38 --> Controller Class Initialized
INFO - 2021-06-17 06:12:39 --> Config Class Initialized
INFO - 2021-06-17 06:12:39 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:12:39 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:12:39 --> Utf8 Class Initialized
INFO - 2021-06-17 06:12:39 --> URI Class Initialized
INFO - 2021-06-17 06:12:39 --> Router Class Initialized
INFO - 2021-06-17 06:12:39 --> Output Class Initialized
INFO - 2021-06-17 06:12:39 --> Security Class Initialized
DEBUG - 2021-06-17 06:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:12:39 --> Input Class Initialized
INFO - 2021-06-17 06:12:39 --> Language Class Initialized
INFO - 2021-06-17 06:12:39 --> Language Class Initialized
INFO - 2021-06-17 06:12:39 --> Config Class Initialized
INFO - 2021-06-17 06:12:39 --> Loader Class Initialized
INFO - 2021-06-17 06:12:39 --> Helper loaded: url_helper
INFO - 2021-06-17 06:12:39 --> Helper loaded: file_helper
INFO - 2021-06-17 06:12:39 --> Helper loaded: form_helper
INFO - 2021-06-17 06:12:39 --> Helper loaded: my_helper
INFO - 2021-06-17 06:12:39 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:12:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:12:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:12:39 --> Controller Class Initialized
DEBUG - 2021-06-17 06:12:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 06:12:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:12:39 --> Final output sent to browser
DEBUG - 2021-06-17 06:12:39 --> Total execution time: 0.0448
INFO - 2021-06-17 06:12:40 --> Config Class Initialized
INFO - 2021-06-17 06:12:40 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:12:40 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:12:40 --> Utf8 Class Initialized
INFO - 2021-06-17 06:12:40 --> URI Class Initialized
INFO - 2021-06-17 06:12:40 --> Router Class Initialized
INFO - 2021-06-17 06:12:40 --> Output Class Initialized
INFO - 2021-06-17 06:12:40 --> Security Class Initialized
DEBUG - 2021-06-17 06:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:12:40 --> Input Class Initialized
INFO - 2021-06-17 06:12:40 --> Language Class Initialized
INFO - 2021-06-17 06:12:40 --> Language Class Initialized
INFO - 2021-06-17 06:12:40 --> Config Class Initialized
INFO - 2021-06-17 06:12:40 --> Loader Class Initialized
INFO - 2021-06-17 06:12:40 --> Helper loaded: url_helper
INFO - 2021-06-17 06:12:40 --> Helper loaded: file_helper
INFO - 2021-06-17 06:12:40 --> Helper loaded: form_helper
INFO - 2021-06-17 06:12:40 --> Helper loaded: my_helper
INFO - 2021-06-17 06:12:40 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:12:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:12:40 --> Controller Class Initialized
INFO - 2021-06-17 06:12:42 --> Config Class Initialized
INFO - 2021-06-17 06:12:42 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:12:42 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:12:42 --> Utf8 Class Initialized
INFO - 2021-06-17 06:12:42 --> URI Class Initialized
INFO - 2021-06-17 06:12:42 --> Router Class Initialized
INFO - 2021-06-17 06:12:42 --> Output Class Initialized
INFO - 2021-06-17 06:12:42 --> Security Class Initialized
DEBUG - 2021-06-17 06:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:12:42 --> Input Class Initialized
INFO - 2021-06-17 06:12:42 --> Language Class Initialized
INFO - 2021-06-17 06:12:42 --> Language Class Initialized
INFO - 2021-06-17 06:12:42 --> Config Class Initialized
INFO - 2021-06-17 06:12:42 --> Loader Class Initialized
INFO - 2021-06-17 06:12:42 --> Helper loaded: url_helper
INFO - 2021-06-17 06:12:42 --> Helper loaded: file_helper
INFO - 2021-06-17 06:12:42 --> Helper loaded: form_helper
INFO - 2021-06-17 06:12:42 --> Helper loaded: my_helper
INFO - 2021-06-17 06:12:42 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:12:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:12:42 --> Controller Class Initialized
INFO - 2021-06-17 06:13:04 --> Config Class Initialized
INFO - 2021-06-17 06:13:04 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:13:04 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:13:04 --> Utf8 Class Initialized
INFO - 2021-06-17 06:13:04 --> URI Class Initialized
INFO - 2021-06-17 06:13:04 --> Router Class Initialized
INFO - 2021-06-17 06:13:04 --> Output Class Initialized
INFO - 2021-06-17 06:13:04 --> Security Class Initialized
DEBUG - 2021-06-17 06:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:13:04 --> Input Class Initialized
INFO - 2021-06-17 06:13:04 --> Language Class Initialized
INFO - 2021-06-17 06:13:04 --> Language Class Initialized
INFO - 2021-06-17 06:13:04 --> Config Class Initialized
INFO - 2021-06-17 06:13:04 --> Loader Class Initialized
INFO - 2021-06-17 06:13:04 --> Helper loaded: url_helper
INFO - 2021-06-17 06:13:04 --> Helper loaded: file_helper
INFO - 2021-06-17 06:13:04 --> Helper loaded: form_helper
INFO - 2021-06-17 06:13:04 --> Helper loaded: my_helper
INFO - 2021-06-17 06:13:04 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:13:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:13:04 --> Controller Class Initialized
DEBUG - 2021-06-17 06:13:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-17 06:13:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:13:04 --> Final output sent to browser
DEBUG - 2021-06-17 06:13:04 --> Total execution time: 0.0462
INFO - 2021-06-17 06:13:04 --> Config Class Initialized
INFO - 2021-06-17 06:13:04 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:13:04 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:13:04 --> Utf8 Class Initialized
INFO - 2021-06-17 06:13:04 --> URI Class Initialized
INFO - 2021-06-17 06:13:04 --> Router Class Initialized
INFO - 2021-06-17 06:13:04 --> Output Class Initialized
INFO - 2021-06-17 06:13:04 --> Security Class Initialized
DEBUG - 2021-06-17 06:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:13:04 --> Input Class Initialized
INFO - 2021-06-17 06:13:04 --> Language Class Initialized
INFO - 2021-06-17 06:13:04 --> Language Class Initialized
INFO - 2021-06-17 06:13:04 --> Config Class Initialized
INFO - 2021-06-17 06:13:04 --> Loader Class Initialized
INFO - 2021-06-17 06:13:04 --> Helper loaded: url_helper
INFO - 2021-06-17 06:13:04 --> Helper loaded: file_helper
INFO - 2021-06-17 06:13:04 --> Helper loaded: form_helper
INFO - 2021-06-17 06:13:04 --> Helper loaded: my_helper
INFO - 2021-06-17 06:13:04 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:13:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:13:05 --> Controller Class Initialized
INFO - 2021-06-17 06:13:06 --> Config Class Initialized
INFO - 2021-06-17 06:13:06 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:13:06 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:13:06 --> Utf8 Class Initialized
INFO - 2021-06-17 06:13:06 --> URI Class Initialized
INFO - 2021-06-17 06:13:06 --> Router Class Initialized
INFO - 2021-06-17 06:13:06 --> Output Class Initialized
INFO - 2021-06-17 06:13:06 --> Security Class Initialized
DEBUG - 2021-06-17 06:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:13:06 --> Input Class Initialized
INFO - 2021-06-17 06:13:06 --> Language Class Initialized
INFO - 2021-06-17 06:13:06 --> Language Class Initialized
INFO - 2021-06-17 06:13:06 --> Config Class Initialized
INFO - 2021-06-17 06:13:06 --> Loader Class Initialized
INFO - 2021-06-17 06:13:06 --> Helper loaded: url_helper
INFO - 2021-06-17 06:13:06 --> Helper loaded: file_helper
INFO - 2021-06-17 06:13:06 --> Helper loaded: form_helper
INFO - 2021-06-17 06:13:06 --> Helper loaded: my_helper
INFO - 2021-06-17 06:13:06 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:13:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:13:06 --> Controller Class Initialized
DEBUG - 2021-06-17 06:13:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 06:13:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:13:06 --> Final output sent to browser
DEBUG - 2021-06-17 06:13:06 --> Total execution time: 0.0442
INFO - 2021-06-17 06:13:07 --> Config Class Initialized
INFO - 2021-06-17 06:13:07 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:13:07 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:13:07 --> Utf8 Class Initialized
INFO - 2021-06-17 06:13:07 --> URI Class Initialized
INFO - 2021-06-17 06:13:07 --> Router Class Initialized
INFO - 2021-06-17 06:13:07 --> Output Class Initialized
INFO - 2021-06-17 06:13:07 --> Security Class Initialized
DEBUG - 2021-06-17 06:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:13:07 --> Input Class Initialized
INFO - 2021-06-17 06:13:07 --> Language Class Initialized
INFO - 2021-06-17 06:13:07 --> Language Class Initialized
INFO - 2021-06-17 06:13:07 --> Config Class Initialized
INFO - 2021-06-17 06:13:07 --> Loader Class Initialized
INFO - 2021-06-17 06:13:07 --> Helper loaded: url_helper
INFO - 2021-06-17 06:13:07 --> Helper loaded: file_helper
INFO - 2021-06-17 06:13:07 --> Helper loaded: form_helper
INFO - 2021-06-17 06:13:07 --> Helper loaded: my_helper
INFO - 2021-06-17 06:13:07 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:13:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:13:07 --> Controller Class Initialized
INFO - 2021-06-17 06:13:08 --> Config Class Initialized
INFO - 2021-06-17 06:13:08 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:13:08 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:13:08 --> Utf8 Class Initialized
INFO - 2021-06-17 06:13:08 --> URI Class Initialized
INFO - 2021-06-17 06:13:08 --> Router Class Initialized
INFO - 2021-06-17 06:13:08 --> Output Class Initialized
INFO - 2021-06-17 06:13:08 --> Security Class Initialized
DEBUG - 2021-06-17 06:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:13:08 --> Input Class Initialized
INFO - 2021-06-17 06:13:08 --> Language Class Initialized
INFO - 2021-06-17 06:13:08 --> Language Class Initialized
INFO - 2021-06-17 06:13:08 --> Config Class Initialized
INFO - 2021-06-17 06:13:08 --> Loader Class Initialized
INFO - 2021-06-17 06:13:08 --> Helper loaded: url_helper
INFO - 2021-06-17 06:13:08 --> Helper loaded: file_helper
INFO - 2021-06-17 06:13:08 --> Helper loaded: form_helper
INFO - 2021-06-17 06:13:08 --> Helper loaded: my_helper
INFO - 2021-06-17 06:13:08 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:13:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:13:08 --> Controller Class Initialized
INFO - 2021-06-17 06:13:24 --> Config Class Initialized
INFO - 2021-06-17 06:13:24 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:13:24 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:13:24 --> Utf8 Class Initialized
INFO - 2021-06-17 06:13:24 --> URI Class Initialized
INFO - 2021-06-17 06:13:24 --> Router Class Initialized
INFO - 2021-06-17 06:13:24 --> Output Class Initialized
INFO - 2021-06-17 06:13:24 --> Security Class Initialized
DEBUG - 2021-06-17 06:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:13:24 --> Input Class Initialized
INFO - 2021-06-17 06:13:24 --> Language Class Initialized
INFO - 2021-06-17 06:13:24 --> Language Class Initialized
INFO - 2021-06-17 06:13:24 --> Config Class Initialized
INFO - 2021-06-17 06:13:24 --> Loader Class Initialized
INFO - 2021-06-17 06:13:24 --> Helper loaded: url_helper
INFO - 2021-06-17 06:13:24 --> Helper loaded: file_helper
INFO - 2021-06-17 06:13:24 --> Helper loaded: form_helper
INFO - 2021-06-17 06:13:24 --> Helper loaded: my_helper
INFO - 2021-06-17 06:13:24 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:13:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:13:24 --> Controller Class Initialized
DEBUG - 2021-06-17 06:13:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-17 06:13:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:13:24 --> Final output sent to browser
DEBUG - 2021-06-17 06:13:24 --> Total execution time: 0.0449
INFO - 2021-06-17 06:13:24 --> Config Class Initialized
INFO - 2021-06-17 06:13:24 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:13:24 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:13:24 --> Utf8 Class Initialized
INFO - 2021-06-17 06:13:24 --> URI Class Initialized
INFO - 2021-06-17 06:13:24 --> Router Class Initialized
INFO - 2021-06-17 06:13:24 --> Output Class Initialized
INFO - 2021-06-17 06:13:24 --> Security Class Initialized
DEBUG - 2021-06-17 06:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:13:24 --> Input Class Initialized
INFO - 2021-06-17 06:13:24 --> Language Class Initialized
INFO - 2021-06-17 06:13:24 --> Language Class Initialized
INFO - 2021-06-17 06:13:24 --> Config Class Initialized
INFO - 2021-06-17 06:13:24 --> Loader Class Initialized
INFO - 2021-06-17 06:13:24 --> Helper loaded: url_helper
INFO - 2021-06-17 06:13:24 --> Helper loaded: file_helper
INFO - 2021-06-17 06:13:24 --> Helper loaded: form_helper
INFO - 2021-06-17 06:13:24 --> Helper loaded: my_helper
INFO - 2021-06-17 06:13:24 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:13:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:13:24 --> Controller Class Initialized
INFO - 2021-06-17 06:13:25 --> Config Class Initialized
INFO - 2021-06-17 06:13:25 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:13:25 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:13:25 --> Utf8 Class Initialized
INFO - 2021-06-17 06:13:25 --> URI Class Initialized
INFO - 2021-06-17 06:13:25 --> Router Class Initialized
INFO - 2021-06-17 06:13:25 --> Output Class Initialized
INFO - 2021-06-17 06:13:25 --> Security Class Initialized
DEBUG - 2021-06-17 06:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:13:25 --> Input Class Initialized
INFO - 2021-06-17 06:13:25 --> Language Class Initialized
INFO - 2021-06-17 06:13:25 --> Language Class Initialized
INFO - 2021-06-17 06:13:25 --> Config Class Initialized
INFO - 2021-06-17 06:13:25 --> Loader Class Initialized
INFO - 2021-06-17 06:13:25 --> Helper loaded: url_helper
INFO - 2021-06-17 06:13:25 --> Helper loaded: file_helper
INFO - 2021-06-17 06:13:25 --> Helper loaded: form_helper
INFO - 2021-06-17 06:13:25 --> Helper loaded: my_helper
INFO - 2021-06-17 06:13:25 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:13:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:13:25 --> Controller Class Initialized
DEBUG - 2021-06-17 06:13:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 06:13:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:13:25 --> Final output sent to browser
DEBUG - 2021-06-17 06:13:25 --> Total execution time: 0.0449
INFO - 2021-06-17 06:13:26 --> Config Class Initialized
INFO - 2021-06-17 06:13:26 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:13:26 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:13:26 --> Utf8 Class Initialized
INFO - 2021-06-17 06:13:26 --> URI Class Initialized
INFO - 2021-06-17 06:13:26 --> Router Class Initialized
INFO - 2021-06-17 06:13:26 --> Output Class Initialized
INFO - 2021-06-17 06:13:26 --> Security Class Initialized
DEBUG - 2021-06-17 06:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:13:26 --> Input Class Initialized
INFO - 2021-06-17 06:13:26 --> Language Class Initialized
INFO - 2021-06-17 06:13:26 --> Language Class Initialized
INFO - 2021-06-17 06:13:26 --> Config Class Initialized
INFO - 2021-06-17 06:13:26 --> Loader Class Initialized
INFO - 2021-06-17 06:13:26 --> Helper loaded: url_helper
INFO - 2021-06-17 06:13:26 --> Helper loaded: file_helper
INFO - 2021-06-17 06:13:26 --> Helper loaded: form_helper
INFO - 2021-06-17 06:13:26 --> Helper loaded: my_helper
INFO - 2021-06-17 06:13:26 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:13:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:13:26 --> Controller Class Initialized
INFO - 2021-06-17 06:13:27 --> Config Class Initialized
INFO - 2021-06-17 06:13:27 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:13:27 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:13:27 --> Utf8 Class Initialized
INFO - 2021-06-17 06:13:27 --> URI Class Initialized
INFO - 2021-06-17 06:13:27 --> Router Class Initialized
INFO - 2021-06-17 06:13:27 --> Output Class Initialized
INFO - 2021-06-17 06:13:27 --> Security Class Initialized
DEBUG - 2021-06-17 06:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:13:27 --> Input Class Initialized
INFO - 2021-06-17 06:13:27 --> Language Class Initialized
INFO - 2021-06-17 06:13:27 --> Language Class Initialized
INFO - 2021-06-17 06:13:27 --> Config Class Initialized
INFO - 2021-06-17 06:13:27 --> Loader Class Initialized
INFO - 2021-06-17 06:13:27 --> Helper loaded: url_helper
INFO - 2021-06-17 06:13:27 --> Helper loaded: file_helper
INFO - 2021-06-17 06:13:27 --> Helper loaded: form_helper
INFO - 2021-06-17 06:13:27 --> Helper loaded: my_helper
INFO - 2021-06-17 06:13:27 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:13:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:13:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:13:27 --> Controller Class Initialized
INFO - 2021-06-17 06:13:31 --> Config Class Initialized
INFO - 2021-06-17 06:13:31 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:13:31 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:13:31 --> Utf8 Class Initialized
INFO - 2021-06-17 06:13:31 --> URI Class Initialized
INFO - 2021-06-17 06:13:31 --> Router Class Initialized
INFO - 2021-06-17 06:13:31 --> Output Class Initialized
INFO - 2021-06-17 06:13:31 --> Security Class Initialized
DEBUG - 2021-06-17 06:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:13:31 --> Input Class Initialized
INFO - 2021-06-17 06:13:31 --> Language Class Initialized
INFO - 2021-06-17 06:13:31 --> Language Class Initialized
INFO - 2021-06-17 06:13:31 --> Config Class Initialized
INFO - 2021-06-17 06:13:31 --> Loader Class Initialized
INFO - 2021-06-17 06:13:31 --> Helper loaded: url_helper
INFO - 2021-06-17 06:13:31 --> Helper loaded: file_helper
INFO - 2021-06-17 06:13:31 --> Helper loaded: form_helper
INFO - 2021-06-17 06:13:31 --> Helper loaded: my_helper
INFO - 2021-06-17 06:13:31 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:13:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:13:31 --> Controller Class Initialized
DEBUG - 2021-06-17 06:13:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-17 06:13:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:13:31 --> Final output sent to browser
DEBUG - 2021-06-17 06:13:31 --> Total execution time: 0.0472
INFO - 2021-06-17 06:13:31 --> Config Class Initialized
INFO - 2021-06-17 06:13:31 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:13:31 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:13:31 --> Utf8 Class Initialized
INFO - 2021-06-17 06:13:31 --> URI Class Initialized
INFO - 2021-06-17 06:13:31 --> Router Class Initialized
INFO - 2021-06-17 06:13:31 --> Output Class Initialized
INFO - 2021-06-17 06:13:31 --> Security Class Initialized
DEBUG - 2021-06-17 06:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:13:31 --> Input Class Initialized
INFO - 2021-06-17 06:13:31 --> Language Class Initialized
INFO - 2021-06-17 06:13:31 --> Language Class Initialized
INFO - 2021-06-17 06:13:31 --> Config Class Initialized
INFO - 2021-06-17 06:13:31 --> Loader Class Initialized
INFO - 2021-06-17 06:13:31 --> Helper loaded: url_helper
INFO - 2021-06-17 06:13:31 --> Helper loaded: file_helper
INFO - 2021-06-17 06:13:31 --> Helper loaded: form_helper
INFO - 2021-06-17 06:13:31 --> Helper loaded: my_helper
INFO - 2021-06-17 06:13:31 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:13:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:13:31 --> Controller Class Initialized
INFO - 2021-06-17 06:13:32 --> Config Class Initialized
INFO - 2021-06-17 06:13:32 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:13:32 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:13:32 --> Utf8 Class Initialized
INFO - 2021-06-17 06:13:32 --> URI Class Initialized
INFO - 2021-06-17 06:13:32 --> Router Class Initialized
INFO - 2021-06-17 06:13:32 --> Output Class Initialized
INFO - 2021-06-17 06:13:32 --> Security Class Initialized
DEBUG - 2021-06-17 06:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:13:32 --> Input Class Initialized
INFO - 2021-06-17 06:13:32 --> Language Class Initialized
INFO - 2021-06-17 06:13:32 --> Language Class Initialized
INFO - 2021-06-17 06:13:32 --> Config Class Initialized
INFO - 2021-06-17 06:13:32 --> Loader Class Initialized
INFO - 2021-06-17 06:13:32 --> Helper loaded: url_helper
INFO - 2021-06-17 06:13:32 --> Helper loaded: file_helper
INFO - 2021-06-17 06:13:32 --> Helper loaded: form_helper
INFO - 2021-06-17 06:13:32 --> Helper loaded: my_helper
INFO - 2021-06-17 06:13:32 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:13:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:13:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:13:32 --> Controller Class Initialized
DEBUG - 2021-06-17 06:13:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 06:13:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:13:32 --> Final output sent to browser
DEBUG - 2021-06-17 06:13:32 --> Total execution time: 0.0449
INFO - 2021-06-17 06:13:33 --> Config Class Initialized
INFO - 2021-06-17 06:13:33 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:13:33 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:13:33 --> Utf8 Class Initialized
INFO - 2021-06-17 06:13:33 --> URI Class Initialized
INFO - 2021-06-17 06:13:33 --> Router Class Initialized
INFO - 2021-06-17 06:13:33 --> Output Class Initialized
INFO - 2021-06-17 06:13:33 --> Security Class Initialized
DEBUG - 2021-06-17 06:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:13:33 --> Input Class Initialized
INFO - 2021-06-17 06:13:33 --> Language Class Initialized
INFO - 2021-06-17 06:13:33 --> Language Class Initialized
INFO - 2021-06-17 06:13:33 --> Config Class Initialized
INFO - 2021-06-17 06:13:33 --> Loader Class Initialized
INFO - 2021-06-17 06:13:33 --> Helper loaded: url_helper
INFO - 2021-06-17 06:13:33 --> Helper loaded: file_helper
INFO - 2021-06-17 06:13:33 --> Helper loaded: form_helper
INFO - 2021-06-17 06:13:33 --> Helper loaded: my_helper
INFO - 2021-06-17 06:13:33 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:13:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:13:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:13:33 --> Controller Class Initialized
INFO - 2021-06-17 06:13:34 --> Config Class Initialized
INFO - 2021-06-17 06:13:34 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:13:34 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:13:34 --> Utf8 Class Initialized
INFO - 2021-06-17 06:13:34 --> URI Class Initialized
INFO - 2021-06-17 06:13:34 --> Router Class Initialized
INFO - 2021-06-17 06:13:34 --> Output Class Initialized
INFO - 2021-06-17 06:13:34 --> Security Class Initialized
DEBUG - 2021-06-17 06:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:13:34 --> Input Class Initialized
INFO - 2021-06-17 06:13:34 --> Language Class Initialized
INFO - 2021-06-17 06:13:34 --> Language Class Initialized
INFO - 2021-06-17 06:13:34 --> Config Class Initialized
INFO - 2021-06-17 06:13:34 --> Loader Class Initialized
INFO - 2021-06-17 06:13:34 --> Helper loaded: url_helper
INFO - 2021-06-17 06:13:34 --> Helper loaded: file_helper
INFO - 2021-06-17 06:13:34 --> Helper loaded: form_helper
INFO - 2021-06-17 06:13:34 --> Helper loaded: my_helper
INFO - 2021-06-17 06:13:34 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:13:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:13:34 --> Controller Class Initialized
INFO - 2021-06-17 06:14:05 --> Config Class Initialized
INFO - 2021-06-17 06:14:05 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:14:05 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:14:05 --> Utf8 Class Initialized
INFO - 2021-06-17 06:14:05 --> URI Class Initialized
INFO - 2021-06-17 06:14:05 --> Router Class Initialized
INFO - 2021-06-17 06:14:05 --> Output Class Initialized
INFO - 2021-06-17 06:14:05 --> Security Class Initialized
DEBUG - 2021-06-17 06:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:14:05 --> Input Class Initialized
INFO - 2021-06-17 06:14:05 --> Language Class Initialized
INFO - 2021-06-17 06:14:05 --> Language Class Initialized
INFO - 2021-06-17 06:14:05 --> Config Class Initialized
INFO - 2021-06-17 06:14:05 --> Loader Class Initialized
INFO - 2021-06-17 06:14:05 --> Helper loaded: url_helper
INFO - 2021-06-17 06:14:05 --> Helper loaded: file_helper
INFO - 2021-06-17 06:14:05 --> Helper loaded: form_helper
INFO - 2021-06-17 06:14:05 --> Helper loaded: my_helper
INFO - 2021-06-17 06:14:05 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:14:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:14:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:14:05 --> Controller Class Initialized
DEBUG - 2021-06-17 06:14:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-17 06:14:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:14:05 --> Final output sent to browser
DEBUG - 2021-06-17 06:14:05 --> Total execution time: 0.0461
INFO - 2021-06-17 06:14:06 --> Config Class Initialized
INFO - 2021-06-17 06:14:06 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:14:06 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:14:06 --> Utf8 Class Initialized
INFO - 2021-06-17 06:14:06 --> URI Class Initialized
INFO - 2021-06-17 06:14:06 --> Router Class Initialized
INFO - 2021-06-17 06:14:06 --> Output Class Initialized
INFO - 2021-06-17 06:14:06 --> Security Class Initialized
DEBUG - 2021-06-17 06:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:14:06 --> Input Class Initialized
INFO - 2021-06-17 06:14:06 --> Language Class Initialized
INFO - 2021-06-17 06:14:06 --> Language Class Initialized
INFO - 2021-06-17 06:14:06 --> Config Class Initialized
INFO - 2021-06-17 06:14:06 --> Loader Class Initialized
INFO - 2021-06-17 06:14:06 --> Helper loaded: url_helper
INFO - 2021-06-17 06:14:06 --> Helper loaded: file_helper
INFO - 2021-06-17 06:14:06 --> Helper loaded: form_helper
INFO - 2021-06-17 06:14:06 --> Helper loaded: my_helper
INFO - 2021-06-17 06:14:06 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:14:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:14:06 --> Controller Class Initialized
INFO - 2021-06-17 06:14:07 --> Config Class Initialized
INFO - 2021-06-17 06:14:07 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:14:07 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:14:07 --> Utf8 Class Initialized
INFO - 2021-06-17 06:14:07 --> URI Class Initialized
INFO - 2021-06-17 06:14:07 --> Router Class Initialized
INFO - 2021-06-17 06:14:07 --> Output Class Initialized
INFO - 2021-06-17 06:14:07 --> Security Class Initialized
DEBUG - 2021-06-17 06:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:14:07 --> Input Class Initialized
INFO - 2021-06-17 06:14:07 --> Language Class Initialized
INFO - 2021-06-17 06:14:07 --> Language Class Initialized
INFO - 2021-06-17 06:14:07 --> Config Class Initialized
INFO - 2021-06-17 06:14:07 --> Loader Class Initialized
INFO - 2021-06-17 06:14:07 --> Helper loaded: url_helper
INFO - 2021-06-17 06:14:07 --> Helper loaded: file_helper
INFO - 2021-06-17 06:14:07 --> Helper loaded: form_helper
INFO - 2021-06-17 06:14:07 --> Helper loaded: my_helper
INFO - 2021-06-17 06:14:07 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:14:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:14:07 --> Controller Class Initialized
DEBUG - 2021-06-17 06:14:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 06:14:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:14:07 --> Final output sent to browser
DEBUG - 2021-06-17 06:14:07 --> Total execution time: 0.0455
INFO - 2021-06-17 06:14:09 --> Config Class Initialized
INFO - 2021-06-17 06:14:09 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:14:09 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:14:09 --> Utf8 Class Initialized
INFO - 2021-06-17 06:14:09 --> URI Class Initialized
INFO - 2021-06-17 06:14:09 --> Router Class Initialized
INFO - 2021-06-17 06:14:09 --> Output Class Initialized
INFO - 2021-06-17 06:14:09 --> Security Class Initialized
DEBUG - 2021-06-17 06:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:14:09 --> Input Class Initialized
INFO - 2021-06-17 06:14:09 --> Language Class Initialized
INFO - 2021-06-17 06:14:09 --> Language Class Initialized
INFO - 2021-06-17 06:14:09 --> Config Class Initialized
INFO - 2021-06-17 06:14:09 --> Loader Class Initialized
INFO - 2021-06-17 06:14:09 --> Helper loaded: url_helper
INFO - 2021-06-17 06:14:09 --> Helper loaded: file_helper
INFO - 2021-06-17 06:14:09 --> Helper loaded: form_helper
INFO - 2021-06-17 06:14:09 --> Helper loaded: my_helper
INFO - 2021-06-17 06:14:09 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:14:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:14:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:14:09 --> Controller Class Initialized
INFO - 2021-06-17 06:14:10 --> Config Class Initialized
INFO - 2021-06-17 06:14:10 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:14:10 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:14:10 --> Utf8 Class Initialized
INFO - 2021-06-17 06:14:10 --> URI Class Initialized
INFO - 2021-06-17 06:14:10 --> Router Class Initialized
INFO - 2021-06-17 06:14:10 --> Output Class Initialized
INFO - 2021-06-17 06:14:10 --> Security Class Initialized
DEBUG - 2021-06-17 06:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:14:10 --> Input Class Initialized
INFO - 2021-06-17 06:14:10 --> Language Class Initialized
INFO - 2021-06-17 06:14:10 --> Language Class Initialized
INFO - 2021-06-17 06:14:10 --> Config Class Initialized
INFO - 2021-06-17 06:14:10 --> Loader Class Initialized
INFO - 2021-06-17 06:14:10 --> Helper loaded: url_helper
INFO - 2021-06-17 06:14:10 --> Helper loaded: file_helper
INFO - 2021-06-17 06:14:10 --> Helper loaded: form_helper
INFO - 2021-06-17 06:14:10 --> Helper loaded: my_helper
INFO - 2021-06-17 06:14:10 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:14:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:14:10 --> Controller Class Initialized
INFO - 2021-06-17 06:28:21 --> Config Class Initialized
INFO - 2021-06-17 06:28:21 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:28:21 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:28:21 --> Utf8 Class Initialized
INFO - 2021-06-17 06:28:21 --> URI Class Initialized
DEBUG - 2021-06-17 06:28:21 --> No URI present. Default controller set.
INFO - 2021-06-17 06:28:21 --> Router Class Initialized
INFO - 2021-06-17 06:28:21 --> Output Class Initialized
INFO - 2021-06-17 06:28:21 --> Security Class Initialized
DEBUG - 2021-06-17 06:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:28:21 --> Input Class Initialized
INFO - 2021-06-17 06:28:21 --> Language Class Initialized
INFO - 2021-06-17 06:28:21 --> Language Class Initialized
INFO - 2021-06-17 06:28:21 --> Config Class Initialized
INFO - 2021-06-17 06:28:21 --> Loader Class Initialized
INFO - 2021-06-17 06:28:21 --> Helper loaded: url_helper
INFO - 2021-06-17 06:28:21 --> Helper loaded: file_helper
INFO - 2021-06-17 06:28:21 --> Helper loaded: form_helper
INFO - 2021-06-17 06:28:21 --> Helper loaded: my_helper
INFO - 2021-06-17 06:28:21 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:28:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:28:21 --> Controller Class Initialized
INFO - 2021-06-17 06:28:21 --> Config Class Initialized
INFO - 2021-06-17 06:28:21 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:28:21 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:28:21 --> Utf8 Class Initialized
INFO - 2021-06-17 06:28:21 --> URI Class Initialized
INFO - 2021-06-17 06:28:21 --> Router Class Initialized
INFO - 2021-06-17 06:28:21 --> Output Class Initialized
INFO - 2021-06-17 06:28:21 --> Security Class Initialized
DEBUG - 2021-06-17 06:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:28:21 --> Input Class Initialized
INFO - 2021-06-17 06:28:21 --> Language Class Initialized
INFO - 2021-06-17 06:28:21 --> Language Class Initialized
INFO - 2021-06-17 06:28:21 --> Config Class Initialized
INFO - 2021-06-17 06:28:21 --> Loader Class Initialized
INFO - 2021-06-17 06:28:21 --> Helper loaded: url_helper
INFO - 2021-06-17 06:28:21 --> Helper loaded: file_helper
INFO - 2021-06-17 06:28:21 --> Helper loaded: form_helper
INFO - 2021-06-17 06:28:21 --> Helper loaded: my_helper
INFO - 2021-06-17 06:28:21 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:28:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:28:21 --> Controller Class Initialized
DEBUG - 2021-06-17 06:28:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-17 06:28:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:28:21 --> Final output sent to browser
DEBUG - 2021-06-17 06:28:21 --> Total execution time: 0.0407
INFO - 2021-06-17 06:28:33 --> Config Class Initialized
INFO - 2021-06-17 06:28:33 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:28:33 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:28:33 --> Utf8 Class Initialized
INFO - 2021-06-17 06:28:33 --> URI Class Initialized
INFO - 2021-06-17 06:28:33 --> Router Class Initialized
INFO - 2021-06-17 06:28:33 --> Output Class Initialized
INFO - 2021-06-17 06:28:33 --> Security Class Initialized
DEBUG - 2021-06-17 06:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:28:33 --> Input Class Initialized
INFO - 2021-06-17 06:28:33 --> Language Class Initialized
INFO - 2021-06-17 06:28:33 --> Language Class Initialized
INFO - 2021-06-17 06:28:33 --> Config Class Initialized
INFO - 2021-06-17 06:28:33 --> Loader Class Initialized
INFO - 2021-06-17 06:28:33 --> Helper loaded: url_helper
INFO - 2021-06-17 06:28:33 --> Helper loaded: file_helper
INFO - 2021-06-17 06:28:33 --> Helper loaded: form_helper
INFO - 2021-06-17 06:28:33 --> Helper loaded: my_helper
INFO - 2021-06-17 06:28:33 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:28:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:28:33 --> Controller Class Initialized
INFO - 2021-06-17 06:28:33 --> Helper loaded: cookie_helper
INFO - 2021-06-17 06:28:33 --> Final output sent to browser
DEBUG - 2021-06-17 06:28:33 --> Total execution time: 0.0399
INFO - 2021-06-17 06:28:33 --> Config Class Initialized
INFO - 2021-06-17 06:28:33 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:28:33 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:28:33 --> Utf8 Class Initialized
INFO - 2021-06-17 06:28:33 --> URI Class Initialized
INFO - 2021-06-17 06:28:33 --> Router Class Initialized
INFO - 2021-06-17 06:28:33 --> Output Class Initialized
INFO - 2021-06-17 06:28:33 --> Security Class Initialized
DEBUG - 2021-06-17 06:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:28:33 --> Input Class Initialized
INFO - 2021-06-17 06:28:33 --> Language Class Initialized
INFO - 2021-06-17 06:28:33 --> Language Class Initialized
INFO - 2021-06-17 06:28:33 --> Config Class Initialized
INFO - 2021-06-17 06:28:33 --> Loader Class Initialized
INFO - 2021-06-17 06:28:33 --> Helper loaded: url_helper
INFO - 2021-06-17 06:28:33 --> Helper loaded: file_helper
INFO - 2021-06-17 06:28:33 --> Helper loaded: form_helper
INFO - 2021-06-17 06:28:33 --> Helper loaded: my_helper
INFO - 2021-06-17 06:28:33 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:28:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:28:33 --> Controller Class Initialized
DEBUG - 2021-06-17 06:28:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-17 06:28:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:28:33 --> Final output sent to browser
DEBUG - 2021-06-17 06:28:33 --> Total execution time: 0.2000
INFO - 2021-06-17 06:28:36 --> Config Class Initialized
INFO - 2021-06-17 06:28:36 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:28:36 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:28:36 --> Utf8 Class Initialized
INFO - 2021-06-17 06:28:36 --> URI Class Initialized
INFO - 2021-06-17 06:28:36 --> Router Class Initialized
INFO - 2021-06-17 06:28:36 --> Output Class Initialized
INFO - 2021-06-17 06:28:36 --> Security Class Initialized
DEBUG - 2021-06-17 06:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:28:36 --> Input Class Initialized
INFO - 2021-06-17 06:28:36 --> Language Class Initialized
INFO - 2021-06-17 06:28:36 --> Language Class Initialized
INFO - 2021-06-17 06:28:36 --> Config Class Initialized
INFO - 2021-06-17 06:28:36 --> Loader Class Initialized
INFO - 2021-06-17 06:28:36 --> Helper loaded: url_helper
INFO - 2021-06-17 06:28:36 --> Helper loaded: file_helper
INFO - 2021-06-17 06:28:36 --> Helper loaded: form_helper
INFO - 2021-06-17 06:28:36 --> Helper loaded: my_helper
INFO - 2021-06-17 06:28:36 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:28:36 --> Controller Class Initialized
DEBUG - 2021-06-17 06:28:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-17 06:28:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:28:36 --> Final output sent to browser
DEBUG - 2021-06-17 06:28:36 --> Total execution time: 0.0509
INFO - 2021-06-17 06:29:02 --> Config Class Initialized
INFO - 2021-06-17 06:29:02 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:29:02 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:29:02 --> Utf8 Class Initialized
INFO - 2021-06-17 06:29:02 --> URI Class Initialized
INFO - 2021-06-17 06:29:02 --> Router Class Initialized
INFO - 2021-06-17 06:29:02 --> Output Class Initialized
INFO - 2021-06-17 06:29:02 --> Security Class Initialized
DEBUG - 2021-06-17 06:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:29:02 --> Input Class Initialized
INFO - 2021-06-17 06:29:02 --> Language Class Initialized
INFO - 2021-06-17 06:29:02 --> Language Class Initialized
INFO - 2021-06-17 06:29:02 --> Config Class Initialized
INFO - 2021-06-17 06:29:02 --> Loader Class Initialized
INFO - 2021-06-17 06:29:02 --> Helper loaded: url_helper
INFO - 2021-06-17 06:29:02 --> Helper loaded: file_helper
INFO - 2021-06-17 06:29:02 --> Helper loaded: form_helper
INFO - 2021-06-17 06:29:02 --> Helper loaded: my_helper
INFO - 2021-06-17 06:29:02 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:29:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:29:02 --> Controller Class Initialized
DEBUG - 2021-06-17 06:29:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-17 06:29:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:29:02 --> Final output sent to browser
DEBUG - 2021-06-17 06:29:02 --> Total execution time: 0.0422
INFO - 2021-06-17 06:29:02 --> Config Class Initialized
INFO - 2021-06-17 06:29:02 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:29:02 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:29:02 --> Utf8 Class Initialized
INFO - 2021-06-17 06:29:02 --> URI Class Initialized
INFO - 2021-06-17 06:29:02 --> Router Class Initialized
INFO - 2021-06-17 06:29:02 --> Output Class Initialized
INFO - 2021-06-17 06:29:02 --> Security Class Initialized
DEBUG - 2021-06-17 06:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:29:02 --> Input Class Initialized
INFO - 2021-06-17 06:29:02 --> Language Class Initialized
INFO - 2021-06-17 06:29:02 --> Language Class Initialized
INFO - 2021-06-17 06:29:02 --> Config Class Initialized
INFO - 2021-06-17 06:29:02 --> Loader Class Initialized
INFO - 2021-06-17 06:29:02 --> Helper loaded: url_helper
INFO - 2021-06-17 06:29:02 --> Helper loaded: file_helper
INFO - 2021-06-17 06:29:02 --> Helper loaded: form_helper
INFO - 2021-06-17 06:29:02 --> Helper loaded: my_helper
INFO - 2021-06-17 06:29:02 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:29:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:29:02 --> Controller Class Initialized
INFO - 2021-06-17 06:29:05 --> Config Class Initialized
INFO - 2021-06-17 06:29:05 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:29:05 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:29:05 --> Utf8 Class Initialized
INFO - 2021-06-17 06:29:05 --> URI Class Initialized
INFO - 2021-06-17 06:29:05 --> Router Class Initialized
INFO - 2021-06-17 06:29:05 --> Output Class Initialized
INFO - 2021-06-17 06:29:05 --> Security Class Initialized
DEBUG - 2021-06-17 06:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:29:05 --> Input Class Initialized
INFO - 2021-06-17 06:29:05 --> Language Class Initialized
INFO - 2021-06-17 06:29:05 --> Language Class Initialized
INFO - 2021-06-17 06:29:05 --> Config Class Initialized
INFO - 2021-06-17 06:29:05 --> Loader Class Initialized
INFO - 2021-06-17 06:29:05 --> Helper loaded: url_helper
INFO - 2021-06-17 06:29:05 --> Helper loaded: file_helper
INFO - 2021-06-17 06:29:05 --> Helper loaded: form_helper
INFO - 2021-06-17 06:29:05 --> Helper loaded: my_helper
INFO - 2021-06-17 06:29:05 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:29:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:29:05 --> Controller Class Initialized
INFO - 2021-06-17 06:29:05 --> Final output sent to browser
DEBUG - 2021-06-17 06:29:05 --> Total execution time: 0.0391
INFO - 2021-06-17 06:29:18 --> Config Class Initialized
INFO - 2021-06-17 06:29:18 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:29:18 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:29:18 --> Utf8 Class Initialized
INFO - 2021-06-17 06:29:18 --> URI Class Initialized
INFO - 2021-06-17 06:29:18 --> Router Class Initialized
INFO - 2021-06-17 06:29:18 --> Output Class Initialized
INFO - 2021-06-17 06:29:18 --> Security Class Initialized
DEBUG - 2021-06-17 06:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:29:18 --> Input Class Initialized
INFO - 2021-06-17 06:29:18 --> Language Class Initialized
INFO - 2021-06-17 06:29:18 --> Language Class Initialized
INFO - 2021-06-17 06:29:18 --> Config Class Initialized
INFO - 2021-06-17 06:29:18 --> Loader Class Initialized
INFO - 2021-06-17 06:29:18 --> Helper loaded: url_helper
INFO - 2021-06-17 06:29:18 --> Helper loaded: file_helper
INFO - 2021-06-17 06:29:18 --> Helper loaded: form_helper
INFO - 2021-06-17 06:29:18 --> Helper loaded: my_helper
INFO - 2021-06-17 06:29:18 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:29:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:29:18 --> Controller Class Initialized
INFO - 2021-06-17 06:29:18 --> Final output sent to browser
DEBUG - 2021-06-17 06:29:18 --> Total execution time: 0.0512
INFO - 2021-06-17 06:29:18 --> Config Class Initialized
INFO - 2021-06-17 06:29:18 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:29:18 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:29:18 --> Utf8 Class Initialized
INFO - 2021-06-17 06:29:18 --> URI Class Initialized
INFO - 2021-06-17 06:29:18 --> Router Class Initialized
INFO - 2021-06-17 06:29:18 --> Output Class Initialized
INFO - 2021-06-17 06:29:18 --> Security Class Initialized
DEBUG - 2021-06-17 06:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:29:18 --> Input Class Initialized
INFO - 2021-06-17 06:29:18 --> Language Class Initialized
INFO - 2021-06-17 06:29:18 --> Language Class Initialized
INFO - 2021-06-17 06:29:18 --> Config Class Initialized
INFO - 2021-06-17 06:29:18 --> Loader Class Initialized
INFO - 2021-06-17 06:29:18 --> Helper loaded: url_helper
INFO - 2021-06-17 06:29:18 --> Helper loaded: file_helper
INFO - 2021-06-17 06:29:18 --> Helper loaded: form_helper
INFO - 2021-06-17 06:29:18 --> Helper loaded: my_helper
INFO - 2021-06-17 06:29:18 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:29:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:29:18 --> Controller Class Initialized
INFO - 2021-06-17 06:29:20 --> Config Class Initialized
INFO - 2021-06-17 06:29:20 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:29:20 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:29:20 --> Utf8 Class Initialized
INFO - 2021-06-17 06:29:20 --> URI Class Initialized
INFO - 2021-06-17 06:29:20 --> Router Class Initialized
INFO - 2021-06-17 06:29:20 --> Output Class Initialized
INFO - 2021-06-17 06:29:20 --> Security Class Initialized
DEBUG - 2021-06-17 06:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:29:20 --> Input Class Initialized
INFO - 2021-06-17 06:29:20 --> Language Class Initialized
INFO - 2021-06-17 06:29:20 --> Language Class Initialized
INFO - 2021-06-17 06:29:20 --> Config Class Initialized
INFO - 2021-06-17 06:29:20 --> Loader Class Initialized
INFO - 2021-06-17 06:29:20 --> Helper loaded: url_helper
INFO - 2021-06-17 06:29:20 --> Helper loaded: file_helper
INFO - 2021-06-17 06:29:20 --> Helper loaded: form_helper
INFO - 2021-06-17 06:29:20 --> Helper loaded: my_helper
INFO - 2021-06-17 06:29:20 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:29:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:29:20 --> Controller Class Initialized
INFO - 2021-06-17 06:29:20 --> Final output sent to browser
DEBUG - 2021-06-17 06:29:20 --> Total execution time: 0.0398
INFO - 2021-06-17 06:29:33 --> Config Class Initialized
INFO - 2021-06-17 06:29:33 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:29:33 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:29:33 --> Utf8 Class Initialized
INFO - 2021-06-17 06:29:33 --> URI Class Initialized
INFO - 2021-06-17 06:29:33 --> Router Class Initialized
INFO - 2021-06-17 06:29:33 --> Output Class Initialized
INFO - 2021-06-17 06:29:33 --> Security Class Initialized
DEBUG - 2021-06-17 06:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:29:33 --> Input Class Initialized
INFO - 2021-06-17 06:29:33 --> Language Class Initialized
INFO - 2021-06-17 06:29:33 --> Language Class Initialized
INFO - 2021-06-17 06:29:33 --> Config Class Initialized
INFO - 2021-06-17 06:29:33 --> Loader Class Initialized
INFO - 2021-06-17 06:29:33 --> Helper loaded: url_helper
INFO - 2021-06-17 06:29:33 --> Helper loaded: file_helper
INFO - 2021-06-17 06:29:33 --> Helper loaded: form_helper
INFO - 2021-06-17 06:29:33 --> Helper loaded: my_helper
INFO - 2021-06-17 06:29:33 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:29:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:29:33 --> Controller Class Initialized
INFO - 2021-06-17 06:29:33 --> Final output sent to browser
DEBUG - 2021-06-17 06:29:33 --> Total execution time: 0.0512
INFO - 2021-06-17 06:29:33 --> Config Class Initialized
INFO - 2021-06-17 06:29:33 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:29:33 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:29:33 --> Utf8 Class Initialized
INFO - 2021-06-17 06:29:33 --> URI Class Initialized
INFO - 2021-06-17 06:29:33 --> Router Class Initialized
INFO - 2021-06-17 06:29:33 --> Output Class Initialized
INFO - 2021-06-17 06:29:33 --> Security Class Initialized
DEBUG - 2021-06-17 06:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:29:33 --> Input Class Initialized
INFO - 2021-06-17 06:29:33 --> Language Class Initialized
INFO - 2021-06-17 06:29:33 --> Language Class Initialized
INFO - 2021-06-17 06:29:33 --> Config Class Initialized
INFO - 2021-06-17 06:29:33 --> Loader Class Initialized
INFO - 2021-06-17 06:29:33 --> Helper loaded: url_helper
INFO - 2021-06-17 06:29:33 --> Helper loaded: file_helper
INFO - 2021-06-17 06:29:33 --> Helper loaded: form_helper
INFO - 2021-06-17 06:29:33 --> Helper loaded: my_helper
INFO - 2021-06-17 06:29:33 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:29:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:29:33 --> Controller Class Initialized
INFO - 2021-06-17 06:29:36 --> Config Class Initialized
INFO - 2021-06-17 06:29:36 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:29:36 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:29:36 --> Utf8 Class Initialized
INFO - 2021-06-17 06:29:36 --> URI Class Initialized
INFO - 2021-06-17 06:29:36 --> Router Class Initialized
INFO - 2021-06-17 06:29:36 --> Output Class Initialized
INFO - 2021-06-17 06:29:36 --> Security Class Initialized
DEBUG - 2021-06-17 06:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:29:36 --> Input Class Initialized
INFO - 2021-06-17 06:29:36 --> Language Class Initialized
INFO - 2021-06-17 06:29:36 --> Language Class Initialized
INFO - 2021-06-17 06:29:36 --> Config Class Initialized
INFO - 2021-06-17 06:29:36 --> Loader Class Initialized
INFO - 2021-06-17 06:29:36 --> Helper loaded: url_helper
INFO - 2021-06-17 06:29:36 --> Helper loaded: file_helper
INFO - 2021-06-17 06:29:36 --> Helper loaded: form_helper
INFO - 2021-06-17 06:29:36 --> Helper loaded: my_helper
INFO - 2021-06-17 06:29:36 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:29:36 --> Controller Class Initialized
INFO - 2021-06-17 06:29:36 --> Final output sent to browser
DEBUG - 2021-06-17 06:29:36 --> Total execution time: 0.0493
INFO - 2021-06-17 06:29:47 --> Config Class Initialized
INFO - 2021-06-17 06:29:47 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:29:47 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:29:47 --> Utf8 Class Initialized
INFO - 2021-06-17 06:29:47 --> URI Class Initialized
INFO - 2021-06-17 06:29:47 --> Router Class Initialized
INFO - 2021-06-17 06:29:47 --> Output Class Initialized
INFO - 2021-06-17 06:29:47 --> Security Class Initialized
DEBUG - 2021-06-17 06:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:29:47 --> Input Class Initialized
INFO - 2021-06-17 06:29:47 --> Language Class Initialized
INFO - 2021-06-17 06:29:47 --> Language Class Initialized
INFO - 2021-06-17 06:29:47 --> Config Class Initialized
INFO - 2021-06-17 06:29:47 --> Loader Class Initialized
INFO - 2021-06-17 06:29:47 --> Helper loaded: url_helper
INFO - 2021-06-17 06:29:47 --> Helper loaded: file_helper
INFO - 2021-06-17 06:29:47 --> Helper loaded: form_helper
INFO - 2021-06-17 06:29:47 --> Helper loaded: my_helper
INFO - 2021-06-17 06:29:47 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:29:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:29:47 --> Controller Class Initialized
INFO - 2021-06-17 06:29:47 --> Final output sent to browser
DEBUG - 2021-06-17 06:29:47 --> Total execution time: 0.0413
INFO - 2021-06-17 06:29:47 --> Config Class Initialized
INFO - 2021-06-17 06:29:47 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:29:47 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:29:47 --> Utf8 Class Initialized
INFO - 2021-06-17 06:29:47 --> URI Class Initialized
INFO - 2021-06-17 06:29:47 --> Router Class Initialized
INFO - 2021-06-17 06:29:47 --> Output Class Initialized
INFO - 2021-06-17 06:29:47 --> Security Class Initialized
DEBUG - 2021-06-17 06:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:29:47 --> Input Class Initialized
INFO - 2021-06-17 06:29:47 --> Language Class Initialized
INFO - 2021-06-17 06:29:47 --> Language Class Initialized
INFO - 2021-06-17 06:29:47 --> Config Class Initialized
INFO - 2021-06-17 06:29:47 --> Loader Class Initialized
INFO - 2021-06-17 06:29:47 --> Helper loaded: url_helper
INFO - 2021-06-17 06:29:47 --> Helper loaded: file_helper
INFO - 2021-06-17 06:29:47 --> Helper loaded: form_helper
INFO - 2021-06-17 06:29:47 --> Helper loaded: my_helper
INFO - 2021-06-17 06:29:47 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:29:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:29:47 --> Controller Class Initialized
INFO - 2021-06-17 06:29:48 --> Config Class Initialized
INFO - 2021-06-17 06:29:48 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:29:48 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:29:48 --> Utf8 Class Initialized
INFO - 2021-06-17 06:29:48 --> URI Class Initialized
INFO - 2021-06-17 06:29:48 --> Router Class Initialized
INFO - 2021-06-17 06:29:48 --> Output Class Initialized
INFO - 2021-06-17 06:29:48 --> Security Class Initialized
DEBUG - 2021-06-17 06:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:29:48 --> Input Class Initialized
INFO - 2021-06-17 06:29:48 --> Language Class Initialized
INFO - 2021-06-17 06:29:48 --> Language Class Initialized
INFO - 2021-06-17 06:29:48 --> Config Class Initialized
INFO - 2021-06-17 06:29:48 --> Loader Class Initialized
INFO - 2021-06-17 06:29:48 --> Helper loaded: url_helper
INFO - 2021-06-17 06:29:48 --> Helper loaded: file_helper
INFO - 2021-06-17 06:29:48 --> Helper loaded: form_helper
INFO - 2021-06-17 06:29:48 --> Helper loaded: my_helper
INFO - 2021-06-17 06:29:48 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:29:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:29:48 --> Controller Class Initialized
DEBUG - 2021-06-17 06:29:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-17 06:29:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:29:48 --> Final output sent to browser
DEBUG - 2021-06-17 06:29:48 --> Total execution time: 0.0499
INFO - 2021-06-17 06:29:50 --> Config Class Initialized
INFO - 2021-06-17 06:29:50 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:29:50 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:29:50 --> Utf8 Class Initialized
INFO - 2021-06-17 06:29:50 --> URI Class Initialized
INFO - 2021-06-17 06:29:50 --> Router Class Initialized
INFO - 2021-06-17 06:29:50 --> Output Class Initialized
INFO - 2021-06-17 06:29:50 --> Security Class Initialized
DEBUG - 2021-06-17 06:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:29:50 --> Input Class Initialized
INFO - 2021-06-17 06:29:50 --> Language Class Initialized
INFO - 2021-06-17 06:29:50 --> Language Class Initialized
INFO - 2021-06-17 06:29:50 --> Config Class Initialized
INFO - 2021-06-17 06:29:50 --> Loader Class Initialized
INFO - 2021-06-17 06:29:50 --> Helper loaded: url_helper
INFO - 2021-06-17 06:29:50 --> Helper loaded: file_helper
INFO - 2021-06-17 06:29:50 --> Helper loaded: form_helper
INFO - 2021-06-17 06:29:50 --> Helper loaded: my_helper
INFO - 2021-06-17 06:29:50 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:29:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:29:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:29:50 --> Controller Class Initialized
DEBUG - 2021-06-17 06:29:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 06:29:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:29:50 --> Final output sent to browser
DEBUG - 2021-06-17 06:29:50 --> Total execution time: 0.0508
INFO - 2021-06-17 06:29:51 --> Config Class Initialized
INFO - 2021-06-17 06:29:51 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:29:51 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:29:51 --> Utf8 Class Initialized
INFO - 2021-06-17 06:29:51 --> URI Class Initialized
INFO - 2021-06-17 06:29:51 --> Router Class Initialized
INFO - 2021-06-17 06:29:51 --> Output Class Initialized
INFO - 2021-06-17 06:29:51 --> Security Class Initialized
DEBUG - 2021-06-17 06:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:29:51 --> Input Class Initialized
INFO - 2021-06-17 06:29:51 --> Language Class Initialized
INFO - 2021-06-17 06:29:51 --> Language Class Initialized
INFO - 2021-06-17 06:29:51 --> Config Class Initialized
INFO - 2021-06-17 06:29:51 --> Loader Class Initialized
INFO - 2021-06-17 06:29:51 --> Helper loaded: url_helper
INFO - 2021-06-17 06:29:51 --> Helper loaded: file_helper
INFO - 2021-06-17 06:29:51 --> Helper loaded: form_helper
INFO - 2021-06-17 06:29:51 --> Helper loaded: my_helper
INFO - 2021-06-17 06:29:51 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:29:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:29:51 --> Controller Class Initialized
INFO - 2021-06-17 06:29:51 --> Final output sent to browser
DEBUG - 2021-06-17 06:29:51 --> Total execution time: 0.0501
INFO - 2021-06-17 06:30:03 --> Config Class Initialized
INFO - 2021-06-17 06:30:03 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:30:03 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:30:03 --> Utf8 Class Initialized
INFO - 2021-06-17 06:30:03 --> URI Class Initialized
INFO - 2021-06-17 06:30:03 --> Router Class Initialized
INFO - 2021-06-17 06:30:03 --> Output Class Initialized
INFO - 2021-06-17 06:30:03 --> Security Class Initialized
DEBUG - 2021-06-17 06:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:30:03 --> Input Class Initialized
INFO - 2021-06-17 06:30:03 --> Language Class Initialized
INFO - 2021-06-17 06:30:03 --> Language Class Initialized
INFO - 2021-06-17 06:30:03 --> Config Class Initialized
INFO - 2021-06-17 06:30:03 --> Loader Class Initialized
INFO - 2021-06-17 06:30:03 --> Helper loaded: url_helper
INFO - 2021-06-17 06:30:03 --> Helper loaded: file_helper
INFO - 2021-06-17 06:30:03 --> Helper loaded: form_helper
INFO - 2021-06-17 06:30:03 --> Helper loaded: my_helper
INFO - 2021-06-17 06:30:03 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:30:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:30:03 --> Controller Class Initialized
INFO - 2021-06-17 06:30:03 --> Final output sent to browser
DEBUG - 2021-06-17 06:30:03 --> Total execution time: 0.0507
INFO - 2021-06-17 06:30:03 --> Config Class Initialized
INFO - 2021-06-17 06:30:03 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:30:03 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:30:03 --> Utf8 Class Initialized
INFO - 2021-06-17 06:30:03 --> URI Class Initialized
INFO - 2021-06-17 06:30:03 --> Router Class Initialized
INFO - 2021-06-17 06:30:03 --> Output Class Initialized
INFO - 2021-06-17 06:30:03 --> Security Class Initialized
DEBUG - 2021-06-17 06:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:30:03 --> Input Class Initialized
INFO - 2021-06-17 06:30:03 --> Language Class Initialized
INFO - 2021-06-17 06:30:03 --> Language Class Initialized
INFO - 2021-06-17 06:30:03 --> Config Class Initialized
INFO - 2021-06-17 06:30:03 --> Loader Class Initialized
INFO - 2021-06-17 06:30:03 --> Helper loaded: url_helper
INFO - 2021-06-17 06:30:03 --> Helper loaded: file_helper
INFO - 2021-06-17 06:30:03 --> Helper loaded: form_helper
INFO - 2021-06-17 06:30:03 --> Helper loaded: my_helper
INFO - 2021-06-17 06:30:03 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:30:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:30:03 --> Controller Class Initialized
DEBUG - 2021-06-17 06:30:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 06:30:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:30:03 --> Final output sent to browser
DEBUG - 2021-06-17 06:30:03 --> Total execution time: 0.0528
INFO - 2021-06-17 06:30:06 --> Config Class Initialized
INFO - 2021-06-17 06:30:06 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:30:06 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:30:06 --> Utf8 Class Initialized
INFO - 2021-06-17 06:30:06 --> URI Class Initialized
INFO - 2021-06-17 06:30:06 --> Router Class Initialized
INFO - 2021-06-17 06:30:06 --> Output Class Initialized
INFO - 2021-06-17 06:30:06 --> Security Class Initialized
DEBUG - 2021-06-17 06:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:30:06 --> Input Class Initialized
INFO - 2021-06-17 06:30:06 --> Language Class Initialized
INFO - 2021-06-17 06:30:06 --> Language Class Initialized
INFO - 2021-06-17 06:30:06 --> Config Class Initialized
INFO - 2021-06-17 06:30:06 --> Loader Class Initialized
INFO - 2021-06-17 06:30:06 --> Helper loaded: url_helper
INFO - 2021-06-17 06:30:06 --> Helper loaded: file_helper
INFO - 2021-06-17 06:30:06 --> Helper loaded: form_helper
INFO - 2021-06-17 06:30:06 --> Helper loaded: my_helper
INFO - 2021-06-17 06:30:06 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:30:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:30:06 --> Controller Class Initialized
INFO - 2021-06-17 06:30:06 --> Final output sent to browser
DEBUG - 2021-06-17 06:30:06 --> Total execution time: 0.0385
INFO - 2021-06-17 06:30:16 --> Config Class Initialized
INFO - 2021-06-17 06:30:16 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:30:16 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:30:16 --> Utf8 Class Initialized
INFO - 2021-06-17 06:30:16 --> URI Class Initialized
INFO - 2021-06-17 06:30:16 --> Router Class Initialized
INFO - 2021-06-17 06:30:16 --> Output Class Initialized
INFO - 2021-06-17 06:30:16 --> Security Class Initialized
DEBUG - 2021-06-17 06:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:30:16 --> Input Class Initialized
INFO - 2021-06-17 06:30:16 --> Language Class Initialized
INFO - 2021-06-17 06:30:16 --> Language Class Initialized
INFO - 2021-06-17 06:30:16 --> Config Class Initialized
INFO - 2021-06-17 06:30:16 --> Loader Class Initialized
INFO - 2021-06-17 06:30:16 --> Helper loaded: url_helper
INFO - 2021-06-17 06:30:16 --> Helper loaded: file_helper
INFO - 2021-06-17 06:30:16 --> Helper loaded: form_helper
INFO - 2021-06-17 06:30:16 --> Helper loaded: my_helper
INFO - 2021-06-17 06:30:16 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:30:16 --> Controller Class Initialized
INFO - 2021-06-17 06:30:16 --> Final output sent to browser
DEBUG - 2021-06-17 06:30:16 --> Total execution time: 0.0502
INFO - 2021-06-17 06:30:16 --> Config Class Initialized
INFO - 2021-06-17 06:30:16 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:30:16 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:30:16 --> Utf8 Class Initialized
INFO - 2021-06-17 06:30:16 --> URI Class Initialized
INFO - 2021-06-17 06:30:16 --> Router Class Initialized
INFO - 2021-06-17 06:30:16 --> Output Class Initialized
INFO - 2021-06-17 06:30:16 --> Security Class Initialized
DEBUG - 2021-06-17 06:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:30:16 --> Input Class Initialized
INFO - 2021-06-17 06:30:16 --> Language Class Initialized
INFO - 2021-06-17 06:30:16 --> Language Class Initialized
INFO - 2021-06-17 06:30:16 --> Config Class Initialized
INFO - 2021-06-17 06:30:16 --> Loader Class Initialized
INFO - 2021-06-17 06:30:16 --> Helper loaded: url_helper
INFO - 2021-06-17 06:30:16 --> Helper loaded: file_helper
INFO - 2021-06-17 06:30:16 --> Helper loaded: form_helper
INFO - 2021-06-17 06:30:16 --> Helper loaded: my_helper
INFO - 2021-06-17 06:30:16 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:30:16 --> Controller Class Initialized
DEBUG - 2021-06-17 06:30:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 06:30:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:30:16 --> Final output sent to browser
DEBUG - 2021-06-17 06:30:16 --> Total execution time: 0.0547
INFO - 2021-06-17 06:30:18 --> Config Class Initialized
INFO - 2021-06-17 06:30:18 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:30:18 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:30:18 --> Utf8 Class Initialized
INFO - 2021-06-17 06:30:18 --> URI Class Initialized
INFO - 2021-06-17 06:30:18 --> Router Class Initialized
INFO - 2021-06-17 06:30:18 --> Output Class Initialized
INFO - 2021-06-17 06:30:18 --> Security Class Initialized
DEBUG - 2021-06-17 06:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:30:18 --> Input Class Initialized
INFO - 2021-06-17 06:30:18 --> Language Class Initialized
INFO - 2021-06-17 06:30:18 --> Language Class Initialized
INFO - 2021-06-17 06:30:18 --> Config Class Initialized
INFO - 2021-06-17 06:30:18 --> Loader Class Initialized
INFO - 2021-06-17 06:30:18 --> Helper loaded: url_helper
INFO - 2021-06-17 06:30:18 --> Helper loaded: file_helper
INFO - 2021-06-17 06:30:18 --> Helper loaded: form_helper
INFO - 2021-06-17 06:30:18 --> Helper loaded: my_helper
INFO - 2021-06-17 06:30:18 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:30:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:30:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:30:18 --> Controller Class Initialized
INFO - 2021-06-17 06:30:18 --> Final output sent to browser
DEBUG - 2021-06-17 06:30:18 --> Total execution time: 0.0394
INFO - 2021-06-17 06:30:28 --> Config Class Initialized
INFO - 2021-06-17 06:30:28 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:30:28 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:30:28 --> Utf8 Class Initialized
INFO - 2021-06-17 06:30:28 --> URI Class Initialized
INFO - 2021-06-17 06:30:28 --> Router Class Initialized
INFO - 2021-06-17 06:30:28 --> Output Class Initialized
INFO - 2021-06-17 06:30:28 --> Security Class Initialized
DEBUG - 2021-06-17 06:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:30:28 --> Input Class Initialized
INFO - 2021-06-17 06:30:28 --> Language Class Initialized
INFO - 2021-06-17 06:30:28 --> Language Class Initialized
INFO - 2021-06-17 06:30:28 --> Config Class Initialized
INFO - 2021-06-17 06:30:28 --> Loader Class Initialized
INFO - 2021-06-17 06:30:28 --> Helper loaded: url_helper
INFO - 2021-06-17 06:30:28 --> Helper loaded: file_helper
INFO - 2021-06-17 06:30:28 --> Helper loaded: form_helper
INFO - 2021-06-17 06:30:28 --> Helper loaded: my_helper
INFO - 2021-06-17 06:30:28 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:30:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:30:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:30:28 --> Controller Class Initialized
INFO - 2021-06-17 06:30:28 --> Final output sent to browser
DEBUG - 2021-06-17 06:30:28 --> Total execution time: 0.0502
INFO - 2021-06-17 06:30:28 --> Config Class Initialized
INFO - 2021-06-17 06:30:28 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:30:28 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:30:28 --> Utf8 Class Initialized
INFO - 2021-06-17 06:30:28 --> URI Class Initialized
INFO - 2021-06-17 06:30:28 --> Router Class Initialized
INFO - 2021-06-17 06:30:28 --> Output Class Initialized
INFO - 2021-06-17 06:30:28 --> Security Class Initialized
DEBUG - 2021-06-17 06:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:30:28 --> Input Class Initialized
INFO - 2021-06-17 06:30:28 --> Language Class Initialized
INFO - 2021-06-17 06:30:28 --> Language Class Initialized
INFO - 2021-06-17 06:30:28 --> Config Class Initialized
INFO - 2021-06-17 06:30:28 --> Loader Class Initialized
INFO - 2021-06-17 06:30:28 --> Helper loaded: url_helper
INFO - 2021-06-17 06:30:28 --> Helper loaded: file_helper
INFO - 2021-06-17 06:30:28 --> Helper loaded: form_helper
INFO - 2021-06-17 06:30:28 --> Helper loaded: my_helper
INFO - 2021-06-17 06:30:28 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:30:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:30:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:30:28 --> Controller Class Initialized
DEBUG - 2021-06-17 06:30:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 06:30:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:30:28 --> Final output sent to browser
DEBUG - 2021-06-17 06:30:28 --> Total execution time: 0.0423
INFO - 2021-06-17 06:30:29 --> Config Class Initialized
INFO - 2021-06-17 06:30:29 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:30:29 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:30:29 --> Utf8 Class Initialized
INFO - 2021-06-17 06:30:29 --> URI Class Initialized
INFO - 2021-06-17 06:30:30 --> Router Class Initialized
INFO - 2021-06-17 06:30:30 --> Output Class Initialized
INFO - 2021-06-17 06:30:30 --> Security Class Initialized
DEBUG - 2021-06-17 06:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:30:30 --> Input Class Initialized
INFO - 2021-06-17 06:30:30 --> Language Class Initialized
INFO - 2021-06-17 06:30:30 --> Language Class Initialized
INFO - 2021-06-17 06:30:30 --> Config Class Initialized
INFO - 2021-06-17 06:30:30 --> Loader Class Initialized
INFO - 2021-06-17 06:30:30 --> Helper loaded: url_helper
INFO - 2021-06-17 06:30:30 --> Helper loaded: file_helper
INFO - 2021-06-17 06:30:30 --> Helper loaded: form_helper
INFO - 2021-06-17 06:30:30 --> Helper loaded: my_helper
INFO - 2021-06-17 06:30:30 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:30:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:30:30 --> Controller Class Initialized
DEBUG - 2021-06-17 06:30:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-17 06:30:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:30:30 --> Final output sent to browser
DEBUG - 2021-06-17 06:30:30 --> Total execution time: 0.0501
INFO - 2021-06-17 06:30:31 --> Config Class Initialized
INFO - 2021-06-17 06:30:31 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:30:31 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:30:31 --> Utf8 Class Initialized
INFO - 2021-06-17 06:30:31 --> URI Class Initialized
INFO - 2021-06-17 06:30:31 --> Router Class Initialized
INFO - 2021-06-17 06:30:31 --> Output Class Initialized
INFO - 2021-06-17 06:30:31 --> Security Class Initialized
DEBUG - 2021-06-17 06:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:30:31 --> Input Class Initialized
INFO - 2021-06-17 06:30:31 --> Language Class Initialized
INFO - 2021-06-17 06:30:31 --> Language Class Initialized
INFO - 2021-06-17 06:30:31 --> Config Class Initialized
INFO - 2021-06-17 06:30:31 --> Loader Class Initialized
INFO - 2021-06-17 06:30:31 --> Helper loaded: url_helper
INFO - 2021-06-17 06:30:31 --> Helper loaded: file_helper
INFO - 2021-06-17 06:30:31 --> Helper loaded: form_helper
INFO - 2021-06-17 06:30:31 --> Helper loaded: my_helper
INFO - 2021-06-17 06:30:31 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:30:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:30:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:30:31 --> Controller Class Initialized
DEBUG - 2021-06-17 06:30:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-17 06:30:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:30:31 --> Final output sent to browser
DEBUG - 2021-06-17 06:30:31 --> Total execution time: 0.0441
INFO - 2021-06-17 06:30:31 --> Config Class Initialized
INFO - 2021-06-17 06:30:31 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:30:31 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:30:31 --> Utf8 Class Initialized
INFO - 2021-06-17 06:30:31 --> URI Class Initialized
INFO - 2021-06-17 06:30:31 --> Router Class Initialized
INFO - 2021-06-17 06:30:31 --> Output Class Initialized
INFO - 2021-06-17 06:30:31 --> Security Class Initialized
DEBUG - 2021-06-17 06:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:30:31 --> Input Class Initialized
INFO - 2021-06-17 06:30:31 --> Language Class Initialized
INFO - 2021-06-17 06:30:31 --> Language Class Initialized
INFO - 2021-06-17 06:30:31 --> Config Class Initialized
INFO - 2021-06-17 06:30:31 --> Loader Class Initialized
INFO - 2021-06-17 06:30:31 --> Helper loaded: url_helper
INFO - 2021-06-17 06:30:31 --> Helper loaded: file_helper
INFO - 2021-06-17 06:30:31 --> Helper loaded: form_helper
INFO - 2021-06-17 06:30:31 --> Helper loaded: my_helper
INFO - 2021-06-17 06:30:31 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:30:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:30:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:30:31 --> Controller Class Initialized
INFO - 2021-06-17 06:30:33 --> Config Class Initialized
INFO - 2021-06-17 06:30:33 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:30:33 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:30:33 --> Utf8 Class Initialized
INFO - 2021-06-17 06:30:33 --> URI Class Initialized
INFO - 2021-06-17 06:30:33 --> Router Class Initialized
INFO - 2021-06-17 06:30:33 --> Output Class Initialized
INFO - 2021-06-17 06:30:33 --> Security Class Initialized
DEBUG - 2021-06-17 06:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:30:33 --> Input Class Initialized
INFO - 2021-06-17 06:30:33 --> Language Class Initialized
INFO - 2021-06-17 06:30:33 --> Language Class Initialized
INFO - 2021-06-17 06:30:33 --> Config Class Initialized
INFO - 2021-06-17 06:30:33 --> Loader Class Initialized
INFO - 2021-06-17 06:30:33 --> Helper loaded: url_helper
INFO - 2021-06-17 06:30:33 --> Helper loaded: file_helper
INFO - 2021-06-17 06:30:33 --> Helper loaded: form_helper
INFO - 2021-06-17 06:30:33 --> Helper loaded: my_helper
INFO - 2021-06-17 06:30:33 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:30:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:30:33 --> Controller Class Initialized
DEBUG - 2021-06-17 06:30:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 06:30:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:30:33 --> Final output sent to browser
DEBUG - 2021-06-17 06:30:33 --> Total execution time: 0.0449
INFO - 2021-06-17 06:30:34 --> Config Class Initialized
INFO - 2021-06-17 06:30:34 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:30:34 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:30:34 --> Utf8 Class Initialized
INFO - 2021-06-17 06:30:34 --> URI Class Initialized
INFO - 2021-06-17 06:30:34 --> Router Class Initialized
INFO - 2021-06-17 06:30:34 --> Output Class Initialized
INFO - 2021-06-17 06:30:34 --> Security Class Initialized
DEBUG - 2021-06-17 06:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:30:34 --> Input Class Initialized
INFO - 2021-06-17 06:30:34 --> Language Class Initialized
INFO - 2021-06-17 06:30:34 --> Language Class Initialized
INFO - 2021-06-17 06:30:34 --> Config Class Initialized
INFO - 2021-06-17 06:30:34 --> Loader Class Initialized
INFO - 2021-06-17 06:30:34 --> Helper loaded: url_helper
INFO - 2021-06-17 06:30:34 --> Helper loaded: file_helper
INFO - 2021-06-17 06:30:34 --> Helper loaded: form_helper
INFO - 2021-06-17 06:30:34 --> Helper loaded: my_helper
INFO - 2021-06-17 06:30:34 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:30:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:30:34 --> Controller Class Initialized
INFO - 2021-06-17 06:30:36 --> Config Class Initialized
INFO - 2021-06-17 06:30:36 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:30:36 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:30:36 --> Utf8 Class Initialized
INFO - 2021-06-17 06:30:36 --> URI Class Initialized
INFO - 2021-06-17 06:30:36 --> Router Class Initialized
INFO - 2021-06-17 06:30:36 --> Output Class Initialized
INFO - 2021-06-17 06:30:36 --> Security Class Initialized
DEBUG - 2021-06-17 06:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:30:36 --> Input Class Initialized
INFO - 2021-06-17 06:30:36 --> Language Class Initialized
INFO - 2021-06-17 06:30:36 --> Language Class Initialized
INFO - 2021-06-17 06:30:36 --> Config Class Initialized
INFO - 2021-06-17 06:30:36 --> Loader Class Initialized
INFO - 2021-06-17 06:30:36 --> Helper loaded: url_helper
INFO - 2021-06-17 06:30:36 --> Helper loaded: file_helper
INFO - 2021-06-17 06:30:36 --> Helper loaded: form_helper
INFO - 2021-06-17 06:30:36 --> Helper loaded: my_helper
INFO - 2021-06-17 06:30:36 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:30:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:30:36 --> Controller Class Initialized
INFO - 2021-06-17 06:30:50 --> Config Class Initialized
INFO - 2021-06-17 06:30:50 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:30:50 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:30:50 --> Utf8 Class Initialized
INFO - 2021-06-17 06:30:50 --> URI Class Initialized
INFO - 2021-06-17 06:30:50 --> Router Class Initialized
INFO - 2021-06-17 06:30:50 --> Output Class Initialized
INFO - 2021-06-17 06:30:50 --> Security Class Initialized
DEBUG - 2021-06-17 06:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:30:50 --> Input Class Initialized
INFO - 2021-06-17 06:30:50 --> Language Class Initialized
INFO - 2021-06-17 06:30:50 --> Language Class Initialized
INFO - 2021-06-17 06:30:50 --> Config Class Initialized
INFO - 2021-06-17 06:30:50 --> Loader Class Initialized
INFO - 2021-06-17 06:30:50 --> Helper loaded: url_helper
INFO - 2021-06-17 06:30:50 --> Helper loaded: file_helper
INFO - 2021-06-17 06:30:50 --> Helper loaded: form_helper
INFO - 2021-06-17 06:30:50 --> Helper loaded: my_helper
INFO - 2021-06-17 06:30:50 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:30:50 --> Controller Class Initialized
DEBUG - 2021-06-17 06:30:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-17 06:30:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:30:50 --> Final output sent to browser
DEBUG - 2021-06-17 06:30:50 --> Total execution time: 0.0454
INFO - 2021-06-17 06:30:50 --> Config Class Initialized
INFO - 2021-06-17 06:30:50 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:30:50 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:30:50 --> Utf8 Class Initialized
INFO - 2021-06-17 06:30:50 --> URI Class Initialized
INFO - 2021-06-17 06:30:50 --> Router Class Initialized
INFO - 2021-06-17 06:30:50 --> Output Class Initialized
INFO - 2021-06-17 06:30:50 --> Security Class Initialized
DEBUG - 2021-06-17 06:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:30:50 --> Input Class Initialized
INFO - 2021-06-17 06:30:50 --> Language Class Initialized
INFO - 2021-06-17 06:30:50 --> Language Class Initialized
INFO - 2021-06-17 06:30:50 --> Config Class Initialized
INFO - 2021-06-17 06:30:50 --> Loader Class Initialized
INFO - 2021-06-17 06:30:50 --> Helper loaded: url_helper
INFO - 2021-06-17 06:30:50 --> Helper loaded: file_helper
INFO - 2021-06-17 06:30:50 --> Helper loaded: form_helper
INFO - 2021-06-17 06:30:50 --> Helper loaded: my_helper
INFO - 2021-06-17 06:30:50 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:30:50 --> Controller Class Initialized
INFO - 2021-06-17 06:30:51 --> Config Class Initialized
INFO - 2021-06-17 06:30:51 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:30:51 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:30:51 --> Utf8 Class Initialized
INFO - 2021-06-17 06:30:51 --> URI Class Initialized
INFO - 2021-06-17 06:30:51 --> Router Class Initialized
INFO - 2021-06-17 06:30:51 --> Output Class Initialized
INFO - 2021-06-17 06:30:51 --> Security Class Initialized
DEBUG - 2021-06-17 06:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:30:51 --> Input Class Initialized
INFO - 2021-06-17 06:30:51 --> Language Class Initialized
INFO - 2021-06-17 06:30:51 --> Language Class Initialized
INFO - 2021-06-17 06:30:51 --> Config Class Initialized
INFO - 2021-06-17 06:30:51 --> Loader Class Initialized
INFO - 2021-06-17 06:30:51 --> Helper loaded: url_helper
INFO - 2021-06-17 06:30:51 --> Helper loaded: file_helper
INFO - 2021-06-17 06:30:51 --> Helper loaded: form_helper
INFO - 2021-06-17 06:30:51 --> Helper loaded: my_helper
INFO - 2021-06-17 06:30:51 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:30:51 --> Controller Class Initialized
DEBUG - 2021-06-17 06:30:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 06:30:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:30:51 --> Final output sent to browser
DEBUG - 2021-06-17 06:30:51 --> Total execution time: 0.0443
INFO - 2021-06-17 06:30:55 --> Config Class Initialized
INFO - 2021-06-17 06:30:55 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:30:55 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:30:55 --> Utf8 Class Initialized
INFO - 2021-06-17 06:30:55 --> URI Class Initialized
INFO - 2021-06-17 06:30:55 --> Router Class Initialized
INFO - 2021-06-17 06:30:55 --> Output Class Initialized
INFO - 2021-06-17 06:30:55 --> Security Class Initialized
DEBUG - 2021-06-17 06:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:30:55 --> Input Class Initialized
INFO - 2021-06-17 06:30:55 --> Language Class Initialized
INFO - 2021-06-17 06:30:55 --> Language Class Initialized
INFO - 2021-06-17 06:30:55 --> Config Class Initialized
INFO - 2021-06-17 06:30:55 --> Loader Class Initialized
INFO - 2021-06-17 06:30:55 --> Helper loaded: url_helper
INFO - 2021-06-17 06:30:55 --> Helper loaded: file_helper
INFO - 2021-06-17 06:30:55 --> Helper loaded: form_helper
INFO - 2021-06-17 06:30:55 --> Helper loaded: my_helper
INFO - 2021-06-17 06:30:55 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:30:55 --> Controller Class Initialized
INFO - 2021-06-17 06:30:57 --> Config Class Initialized
INFO - 2021-06-17 06:30:57 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:30:57 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:30:57 --> Utf8 Class Initialized
INFO - 2021-06-17 06:30:57 --> URI Class Initialized
INFO - 2021-06-17 06:30:57 --> Router Class Initialized
INFO - 2021-06-17 06:30:57 --> Output Class Initialized
INFO - 2021-06-17 06:30:57 --> Security Class Initialized
DEBUG - 2021-06-17 06:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:30:57 --> Input Class Initialized
INFO - 2021-06-17 06:30:57 --> Language Class Initialized
INFO - 2021-06-17 06:30:57 --> Language Class Initialized
INFO - 2021-06-17 06:30:57 --> Config Class Initialized
INFO - 2021-06-17 06:30:57 --> Loader Class Initialized
INFO - 2021-06-17 06:30:57 --> Helper loaded: url_helper
INFO - 2021-06-17 06:30:57 --> Helper loaded: file_helper
INFO - 2021-06-17 06:30:57 --> Helper loaded: form_helper
INFO - 2021-06-17 06:30:57 --> Helper loaded: my_helper
INFO - 2021-06-17 06:30:57 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:30:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:30:57 --> Controller Class Initialized
INFO - 2021-06-17 06:31:02 --> Config Class Initialized
INFO - 2021-06-17 06:31:02 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:31:02 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:31:02 --> Utf8 Class Initialized
INFO - 2021-06-17 06:31:02 --> URI Class Initialized
INFO - 2021-06-17 06:31:02 --> Router Class Initialized
INFO - 2021-06-17 06:31:02 --> Output Class Initialized
INFO - 2021-06-17 06:31:02 --> Security Class Initialized
DEBUG - 2021-06-17 06:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:31:02 --> Input Class Initialized
INFO - 2021-06-17 06:31:02 --> Language Class Initialized
INFO - 2021-06-17 06:31:02 --> Language Class Initialized
INFO - 2021-06-17 06:31:02 --> Config Class Initialized
INFO - 2021-06-17 06:31:02 --> Loader Class Initialized
INFO - 2021-06-17 06:31:02 --> Helper loaded: url_helper
INFO - 2021-06-17 06:31:02 --> Helper loaded: file_helper
INFO - 2021-06-17 06:31:02 --> Helper loaded: form_helper
INFO - 2021-06-17 06:31:02 --> Helper loaded: my_helper
INFO - 2021-06-17 06:31:02 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:31:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:31:02 --> Controller Class Initialized
DEBUG - 2021-06-17 06:31:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-17 06:31:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:31:02 --> Final output sent to browser
DEBUG - 2021-06-17 06:31:02 --> Total execution time: 0.0448
INFO - 2021-06-17 06:31:02 --> Config Class Initialized
INFO - 2021-06-17 06:31:02 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:31:02 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:31:02 --> Utf8 Class Initialized
INFO - 2021-06-17 06:31:02 --> URI Class Initialized
INFO - 2021-06-17 06:31:02 --> Router Class Initialized
INFO - 2021-06-17 06:31:02 --> Output Class Initialized
INFO - 2021-06-17 06:31:02 --> Security Class Initialized
DEBUG - 2021-06-17 06:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:31:02 --> Input Class Initialized
INFO - 2021-06-17 06:31:02 --> Language Class Initialized
INFO - 2021-06-17 06:31:02 --> Language Class Initialized
INFO - 2021-06-17 06:31:02 --> Config Class Initialized
INFO - 2021-06-17 06:31:02 --> Loader Class Initialized
INFO - 2021-06-17 06:31:02 --> Helper loaded: url_helper
INFO - 2021-06-17 06:31:02 --> Helper loaded: file_helper
INFO - 2021-06-17 06:31:02 --> Helper loaded: form_helper
INFO - 2021-06-17 06:31:02 --> Helper loaded: my_helper
INFO - 2021-06-17 06:31:02 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:31:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:31:02 --> Controller Class Initialized
INFO - 2021-06-17 06:31:03 --> Config Class Initialized
INFO - 2021-06-17 06:31:03 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:31:03 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:31:03 --> Utf8 Class Initialized
INFO - 2021-06-17 06:31:03 --> URI Class Initialized
INFO - 2021-06-17 06:31:03 --> Router Class Initialized
INFO - 2021-06-17 06:31:03 --> Output Class Initialized
INFO - 2021-06-17 06:31:03 --> Security Class Initialized
DEBUG - 2021-06-17 06:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:31:03 --> Input Class Initialized
INFO - 2021-06-17 06:31:03 --> Language Class Initialized
INFO - 2021-06-17 06:31:03 --> Language Class Initialized
INFO - 2021-06-17 06:31:03 --> Config Class Initialized
INFO - 2021-06-17 06:31:03 --> Loader Class Initialized
INFO - 2021-06-17 06:31:03 --> Helper loaded: url_helper
INFO - 2021-06-17 06:31:03 --> Helper loaded: file_helper
INFO - 2021-06-17 06:31:03 --> Helper loaded: form_helper
INFO - 2021-06-17 06:31:03 --> Helper loaded: my_helper
INFO - 2021-06-17 06:31:03 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:31:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:31:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:31:03 --> Controller Class Initialized
DEBUG - 2021-06-17 06:31:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 06:31:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:31:03 --> Final output sent to browser
DEBUG - 2021-06-17 06:31:03 --> Total execution time: 0.0446
INFO - 2021-06-17 06:31:06 --> Config Class Initialized
INFO - 2021-06-17 06:31:06 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:31:06 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:31:06 --> Utf8 Class Initialized
INFO - 2021-06-17 06:31:06 --> URI Class Initialized
INFO - 2021-06-17 06:31:06 --> Router Class Initialized
INFO - 2021-06-17 06:31:06 --> Output Class Initialized
INFO - 2021-06-17 06:31:06 --> Security Class Initialized
DEBUG - 2021-06-17 06:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:31:06 --> Input Class Initialized
INFO - 2021-06-17 06:31:06 --> Language Class Initialized
INFO - 2021-06-17 06:31:06 --> Language Class Initialized
INFO - 2021-06-17 06:31:06 --> Config Class Initialized
INFO - 2021-06-17 06:31:06 --> Loader Class Initialized
INFO - 2021-06-17 06:31:06 --> Helper loaded: url_helper
INFO - 2021-06-17 06:31:06 --> Helper loaded: file_helper
INFO - 2021-06-17 06:31:06 --> Helper loaded: form_helper
INFO - 2021-06-17 06:31:06 --> Helper loaded: my_helper
INFO - 2021-06-17 06:31:06 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:31:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:31:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:31:06 --> Controller Class Initialized
INFO - 2021-06-17 06:31:07 --> Config Class Initialized
INFO - 2021-06-17 06:31:07 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:31:07 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:31:07 --> Utf8 Class Initialized
INFO - 2021-06-17 06:31:07 --> URI Class Initialized
INFO - 2021-06-17 06:31:07 --> Router Class Initialized
INFO - 2021-06-17 06:31:07 --> Output Class Initialized
INFO - 2021-06-17 06:31:07 --> Security Class Initialized
DEBUG - 2021-06-17 06:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:31:07 --> Input Class Initialized
INFO - 2021-06-17 06:31:07 --> Language Class Initialized
INFO - 2021-06-17 06:31:07 --> Language Class Initialized
INFO - 2021-06-17 06:31:07 --> Config Class Initialized
INFO - 2021-06-17 06:31:07 --> Loader Class Initialized
INFO - 2021-06-17 06:31:07 --> Helper loaded: url_helper
INFO - 2021-06-17 06:31:07 --> Helper loaded: file_helper
INFO - 2021-06-17 06:31:07 --> Helper loaded: form_helper
INFO - 2021-06-17 06:31:07 --> Helper loaded: my_helper
INFO - 2021-06-17 06:31:07 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:31:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:31:07 --> Controller Class Initialized
INFO - 2021-06-17 06:31:26 --> Config Class Initialized
INFO - 2021-06-17 06:31:26 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:31:26 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:31:26 --> Utf8 Class Initialized
INFO - 2021-06-17 06:31:26 --> URI Class Initialized
INFO - 2021-06-17 06:31:26 --> Router Class Initialized
INFO - 2021-06-17 06:31:26 --> Output Class Initialized
INFO - 2021-06-17 06:31:26 --> Security Class Initialized
DEBUG - 2021-06-17 06:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:31:26 --> Input Class Initialized
INFO - 2021-06-17 06:31:26 --> Language Class Initialized
INFO - 2021-06-17 06:31:26 --> Language Class Initialized
INFO - 2021-06-17 06:31:26 --> Config Class Initialized
INFO - 2021-06-17 06:31:26 --> Loader Class Initialized
INFO - 2021-06-17 06:31:26 --> Helper loaded: url_helper
INFO - 2021-06-17 06:31:26 --> Helper loaded: file_helper
INFO - 2021-06-17 06:31:26 --> Helper loaded: form_helper
INFO - 2021-06-17 06:31:26 --> Helper loaded: my_helper
INFO - 2021-06-17 06:31:26 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:31:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:31:26 --> Controller Class Initialized
DEBUG - 2021-06-17 06:31:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-17 06:31:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:31:26 --> Final output sent to browser
DEBUG - 2021-06-17 06:31:26 --> Total execution time: 0.0453
INFO - 2021-06-17 06:31:26 --> Config Class Initialized
INFO - 2021-06-17 06:31:26 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:31:26 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:31:26 --> Utf8 Class Initialized
INFO - 2021-06-17 06:31:26 --> URI Class Initialized
INFO - 2021-06-17 06:31:26 --> Router Class Initialized
INFO - 2021-06-17 06:31:26 --> Output Class Initialized
INFO - 2021-06-17 06:31:26 --> Security Class Initialized
DEBUG - 2021-06-17 06:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:31:26 --> Input Class Initialized
INFO - 2021-06-17 06:31:26 --> Language Class Initialized
INFO - 2021-06-17 06:31:26 --> Language Class Initialized
INFO - 2021-06-17 06:31:26 --> Config Class Initialized
INFO - 2021-06-17 06:31:26 --> Loader Class Initialized
INFO - 2021-06-17 06:31:26 --> Helper loaded: url_helper
INFO - 2021-06-17 06:31:26 --> Helper loaded: file_helper
INFO - 2021-06-17 06:31:26 --> Helper loaded: form_helper
INFO - 2021-06-17 06:31:26 --> Helper loaded: my_helper
INFO - 2021-06-17 06:31:26 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:31:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:31:26 --> Controller Class Initialized
INFO - 2021-06-17 06:31:27 --> Config Class Initialized
INFO - 2021-06-17 06:31:27 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:31:27 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:31:27 --> Utf8 Class Initialized
INFO - 2021-06-17 06:31:27 --> URI Class Initialized
INFO - 2021-06-17 06:31:27 --> Router Class Initialized
INFO - 2021-06-17 06:31:27 --> Output Class Initialized
INFO - 2021-06-17 06:31:27 --> Security Class Initialized
DEBUG - 2021-06-17 06:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:31:27 --> Input Class Initialized
INFO - 2021-06-17 06:31:27 --> Language Class Initialized
INFO - 2021-06-17 06:31:27 --> Language Class Initialized
INFO - 2021-06-17 06:31:27 --> Config Class Initialized
INFO - 2021-06-17 06:31:27 --> Loader Class Initialized
INFO - 2021-06-17 06:31:27 --> Helper loaded: url_helper
INFO - 2021-06-17 06:31:27 --> Helper loaded: file_helper
INFO - 2021-06-17 06:31:27 --> Helper loaded: form_helper
INFO - 2021-06-17 06:31:27 --> Helper loaded: my_helper
INFO - 2021-06-17 06:31:27 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:31:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:31:27 --> Controller Class Initialized
DEBUG - 2021-06-17 06:31:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 06:31:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:31:27 --> Final output sent to browser
DEBUG - 2021-06-17 06:31:27 --> Total execution time: 0.0447
INFO - 2021-06-17 06:31:28 --> Config Class Initialized
INFO - 2021-06-17 06:31:28 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:31:28 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:31:28 --> Utf8 Class Initialized
INFO - 2021-06-17 06:31:28 --> URI Class Initialized
INFO - 2021-06-17 06:31:28 --> Router Class Initialized
INFO - 2021-06-17 06:31:28 --> Output Class Initialized
INFO - 2021-06-17 06:31:28 --> Security Class Initialized
DEBUG - 2021-06-17 06:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:31:28 --> Input Class Initialized
INFO - 2021-06-17 06:31:28 --> Language Class Initialized
INFO - 2021-06-17 06:31:28 --> Language Class Initialized
INFO - 2021-06-17 06:31:28 --> Config Class Initialized
INFO - 2021-06-17 06:31:28 --> Loader Class Initialized
INFO - 2021-06-17 06:31:28 --> Helper loaded: url_helper
INFO - 2021-06-17 06:31:28 --> Helper loaded: file_helper
INFO - 2021-06-17 06:31:28 --> Helper loaded: form_helper
INFO - 2021-06-17 06:31:28 --> Helper loaded: my_helper
INFO - 2021-06-17 06:31:28 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:31:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:31:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:31:28 --> Controller Class Initialized
INFO - 2021-06-17 06:31:30 --> Config Class Initialized
INFO - 2021-06-17 06:31:30 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:31:30 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:31:30 --> Utf8 Class Initialized
INFO - 2021-06-17 06:31:30 --> URI Class Initialized
INFO - 2021-06-17 06:31:30 --> Router Class Initialized
INFO - 2021-06-17 06:31:30 --> Output Class Initialized
INFO - 2021-06-17 06:31:30 --> Security Class Initialized
DEBUG - 2021-06-17 06:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:31:30 --> Input Class Initialized
INFO - 2021-06-17 06:31:30 --> Language Class Initialized
INFO - 2021-06-17 06:31:30 --> Language Class Initialized
INFO - 2021-06-17 06:31:30 --> Config Class Initialized
INFO - 2021-06-17 06:31:30 --> Loader Class Initialized
INFO - 2021-06-17 06:31:30 --> Helper loaded: url_helper
INFO - 2021-06-17 06:31:30 --> Helper loaded: file_helper
INFO - 2021-06-17 06:31:30 --> Helper loaded: form_helper
INFO - 2021-06-17 06:31:30 --> Helper loaded: my_helper
INFO - 2021-06-17 06:31:30 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:31:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:31:30 --> Controller Class Initialized
INFO - 2021-06-17 06:31:49 --> Config Class Initialized
INFO - 2021-06-17 06:31:49 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:31:49 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:31:49 --> Utf8 Class Initialized
INFO - 2021-06-17 06:31:49 --> URI Class Initialized
INFO - 2021-06-17 06:31:49 --> Router Class Initialized
INFO - 2021-06-17 06:31:49 --> Output Class Initialized
INFO - 2021-06-17 06:31:49 --> Security Class Initialized
DEBUG - 2021-06-17 06:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:31:49 --> Input Class Initialized
INFO - 2021-06-17 06:31:49 --> Language Class Initialized
INFO - 2021-06-17 06:31:49 --> Language Class Initialized
INFO - 2021-06-17 06:31:49 --> Config Class Initialized
INFO - 2021-06-17 06:31:49 --> Loader Class Initialized
INFO - 2021-06-17 06:31:49 --> Helper loaded: url_helper
INFO - 2021-06-17 06:31:49 --> Helper loaded: file_helper
INFO - 2021-06-17 06:31:49 --> Helper loaded: form_helper
INFO - 2021-06-17 06:31:49 --> Helper loaded: my_helper
INFO - 2021-06-17 06:31:49 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:31:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:31:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:31:49 --> Controller Class Initialized
DEBUG - 2021-06-17 06:31:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-17 06:31:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:31:49 --> Final output sent to browser
DEBUG - 2021-06-17 06:31:49 --> Total execution time: 0.0444
INFO - 2021-06-17 06:31:49 --> Config Class Initialized
INFO - 2021-06-17 06:31:49 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:31:49 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:31:49 --> Utf8 Class Initialized
INFO - 2021-06-17 06:31:49 --> URI Class Initialized
INFO - 2021-06-17 06:31:49 --> Router Class Initialized
INFO - 2021-06-17 06:31:49 --> Output Class Initialized
INFO - 2021-06-17 06:31:49 --> Security Class Initialized
DEBUG - 2021-06-17 06:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:31:49 --> Input Class Initialized
INFO - 2021-06-17 06:31:49 --> Language Class Initialized
INFO - 2021-06-17 06:31:49 --> Language Class Initialized
INFO - 2021-06-17 06:31:49 --> Config Class Initialized
INFO - 2021-06-17 06:31:49 --> Loader Class Initialized
INFO - 2021-06-17 06:31:49 --> Helper loaded: url_helper
INFO - 2021-06-17 06:31:49 --> Helper loaded: file_helper
INFO - 2021-06-17 06:31:49 --> Helper loaded: form_helper
INFO - 2021-06-17 06:31:49 --> Helper loaded: my_helper
INFO - 2021-06-17 06:31:49 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:31:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:31:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:31:49 --> Controller Class Initialized
INFO - 2021-06-17 06:31:50 --> Config Class Initialized
INFO - 2021-06-17 06:31:50 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:31:50 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:31:50 --> Utf8 Class Initialized
INFO - 2021-06-17 06:31:50 --> URI Class Initialized
INFO - 2021-06-17 06:31:50 --> Router Class Initialized
INFO - 2021-06-17 06:31:50 --> Output Class Initialized
INFO - 2021-06-17 06:31:50 --> Security Class Initialized
DEBUG - 2021-06-17 06:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:31:50 --> Input Class Initialized
INFO - 2021-06-17 06:31:50 --> Language Class Initialized
INFO - 2021-06-17 06:31:50 --> Language Class Initialized
INFO - 2021-06-17 06:31:50 --> Config Class Initialized
INFO - 2021-06-17 06:31:50 --> Loader Class Initialized
INFO - 2021-06-17 06:31:50 --> Helper loaded: url_helper
INFO - 2021-06-17 06:31:50 --> Helper loaded: file_helper
INFO - 2021-06-17 06:31:50 --> Helper loaded: form_helper
INFO - 2021-06-17 06:31:50 --> Helper loaded: my_helper
INFO - 2021-06-17 06:31:50 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:31:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:31:50 --> Controller Class Initialized
DEBUG - 2021-06-17 06:31:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 06:31:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:31:50 --> Final output sent to browser
DEBUG - 2021-06-17 06:31:50 --> Total execution time: 0.0442
INFO - 2021-06-17 06:31:52 --> Config Class Initialized
INFO - 2021-06-17 06:31:52 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:31:52 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:31:52 --> Utf8 Class Initialized
INFO - 2021-06-17 06:31:52 --> URI Class Initialized
INFO - 2021-06-17 06:31:52 --> Router Class Initialized
INFO - 2021-06-17 06:31:52 --> Output Class Initialized
INFO - 2021-06-17 06:31:52 --> Security Class Initialized
DEBUG - 2021-06-17 06:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:31:52 --> Input Class Initialized
INFO - 2021-06-17 06:31:52 --> Language Class Initialized
INFO - 2021-06-17 06:31:52 --> Language Class Initialized
INFO - 2021-06-17 06:31:52 --> Config Class Initialized
INFO - 2021-06-17 06:31:52 --> Loader Class Initialized
INFO - 2021-06-17 06:31:52 --> Helper loaded: url_helper
INFO - 2021-06-17 06:31:52 --> Helper loaded: file_helper
INFO - 2021-06-17 06:31:52 --> Helper loaded: form_helper
INFO - 2021-06-17 06:31:52 --> Helper loaded: my_helper
INFO - 2021-06-17 06:31:52 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:31:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:31:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:31:52 --> Controller Class Initialized
INFO - 2021-06-17 06:31:53 --> Config Class Initialized
INFO - 2021-06-17 06:31:53 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:31:53 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:31:53 --> Utf8 Class Initialized
INFO - 2021-06-17 06:31:53 --> URI Class Initialized
INFO - 2021-06-17 06:31:53 --> Router Class Initialized
INFO - 2021-06-17 06:31:53 --> Output Class Initialized
INFO - 2021-06-17 06:31:53 --> Security Class Initialized
DEBUG - 2021-06-17 06:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:31:53 --> Input Class Initialized
INFO - 2021-06-17 06:31:53 --> Language Class Initialized
INFO - 2021-06-17 06:31:53 --> Language Class Initialized
INFO - 2021-06-17 06:31:53 --> Config Class Initialized
INFO - 2021-06-17 06:31:53 --> Loader Class Initialized
INFO - 2021-06-17 06:31:53 --> Helper loaded: url_helper
INFO - 2021-06-17 06:31:53 --> Helper loaded: file_helper
INFO - 2021-06-17 06:31:53 --> Helper loaded: form_helper
INFO - 2021-06-17 06:31:53 --> Helper loaded: my_helper
INFO - 2021-06-17 06:31:53 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:31:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:31:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:31:53 --> Controller Class Initialized
INFO - 2021-06-17 06:32:23 --> Config Class Initialized
INFO - 2021-06-17 06:32:23 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:32:23 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:32:23 --> Utf8 Class Initialized
INFO - 2021-06-17 06:32:23 --> URI Class Initialized
INFO - 2021-06-17 06:32:23 --> Router Class Initialized
INFO - 2021-06-17 06:32:23 --> Output Class Initialized
INFO - 2021-06-17 06:32:23 --> Security Class Initialized
DEBUG - 2021-06-17 06:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:32:23 --> Input Class Initialized
INFO - 2021-06-17 06:32:23 --> Language Class Initialized
INFO - 2021-06-17 06:32:23 --> Language Class Initialized
INFO - 2021-06-17 06:32:23 --> Config Class Initialized
INFO - 2021-06-17 06:32:23 --> Loader Class Initialized
INFO - 2021-06-17 06:32:23 --> Helper loaded: url_helper
INFO - 2021-06-17 06:32:23 --> Helper loaded: file_helper
INFO - 2021-06-17 06:32:23 --> Helper loaded: form_helper
INFO - 2021-06-17 06:32:23 --> Helper loaded: my_helper
INFO - 2021-06-17 06:32:23 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:32:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:32:23 --> Controller Class Initialized
DEBUG - 2021-06-17 06:32:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-17 06:32:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:32:23 --> Final output sent to browser
DEBUG - 2021-06-17 06:32:23 --> Total execution time: 0.0459
INFO - 2021-06-17 06:32:23 --> Config Class Initialized
INFO - 2021-06-17 06:32:23 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:32:23 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:32:23 --> Utf8 Class Initialized
INFO - 2021-06-17 06:32:23 --> URI Class Initialized
INFO - 2021-06-17 06:32:23 --> Router Class Initialized
INFO - 2021-06-17 06:32:23 --> Output Class Initialized
INFO - 2021-06-17 06:32:23 --> Security Class Initialized
DEBUG - 2021-06-17 06:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:32:23 --> Input Class Initialized
INFO - 2021-06-17 06:32:23 --> Language Class Initialized
INFO - 2021-06-17 06:32:23 --> Language Class Initialized
INFO - 2021-06-17 06:32:23 --> Config Class Initialized
INFO - 2021-06-17 06:32:23 --> Loader Class Initialized
INFO - 2021-06-17 06:32:23 --> Helper loaded: url_helper
INFO - 2021-06-17 06:32:23 --> Helper loaded: file_helper
INFO - 2021-06-17 06:32:23 --> Helper loaded: form_helper
INFO - 2021-06-17 06:32:23 --> Helper loaded: my_helper
INFO - 2021-06-17 06:32:23 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:32:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:32:23 --> Controller Class Initialized
INFO - 2021-06-17 06:32:24 --> Config Class Initialized
INFO - 2021-06-17 06:32:24 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:32:24 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:32:24 --> Utf8 Class Initialized
INFO - 2021-06-17 06:32:24 --> URI Class Initialized
INFO - 2021-06-17 06:32:24 --> Router Class Initialized
INFO - 2021-06-17 06:32:24 --> Output Class Initialized
INFO - 2021-06-17 06:32:24 --> Security Class Initialized
DEBUG - 2021-06-17 06:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:32:24 --> Input Class Initialized
INFO - 2021-06-17 06:32:24 --> Language Class Initialized
INFO - 2021-06-17 06:32:24 --> Language Class Initialized
INFO - 2021-06-17 06:32:24 --> Config Class Initialized
INFO - 2021-06-17 06:32:24 --> Loader Class Initialized
INFO - 2021-06-17 06:32:24 --> Helper loaded: url_helper
INFO - 2021-06-17 06:32:24 --> Helper loaded: file_helper
INFO - 2021-06-17 06:32:24 --> Helper loaded: form_helper
INFO - 2021-06-17 06:32:24 --> Helper loaded: my_helper
INFO - 2021-06-17 06:32:24 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:32:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:32:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:32:24 --> Controller Class Initialized
DEBUG - 2021-06-17 06:32:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 06:32:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:32:24 --> Final output sent to browser
DEBUG - 2021-06-17 06:32:24 --> Total execution time: 0.0445
INFO - 2021-06-17 06:32:25 --> Config Class Initialized
INFO - 2021-06-17 06:32:25 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:32:25 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:32:25 --> Utf8 Class Initialized
INFO - 2021-06-17 06:32:25 --> URI Class Initialized
INFO - 2021-06-17 06:32:25 --> Router Class Initialized
INFO - 2021-06-17 06:32:25 --> Output Class Initialized
INFO - 2021-06-17 06:32:25 --> Security Class Initialized
DEBUG - 2021-06-17 06:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:32:25 --> Input Class Initialized
INFO - 2021-06-17 06:32:25 --> Language Class Initialized
INFO - 2021-06-17 06:32:25 --> Language Class Initialized
INFO - 2021-06-17 06:32:25 --> Config Class Initialized
INFO - 2021-06-17 06:32:25 --> Loader Class Initialized
INFO - 2021-06-17 06:32:25 --> Helper loaded: url_helper
INFO - 2021-06-17 06:32:25 --> Helper loaded: file_helper
INFO - 2021-06-17 06:32:25 --> Helper loaded: form_helper
INFO - 2021-06-17 06:32:25 --> Helper loaded: my_helper
INFO - 2021-06-17 06:32:26 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:32:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:32:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:32:26 --> Controller Class Initialized
INFO - 2021-06-17 06:32:27 --> Config Class Initialized
INFO - 2021-06-17 06:32:27 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:32:27 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:32:27 --> Utf8 Class Initialized
INFO - 2021-06-17 06:32:27 --> URI Class Initialized
INFO - 2021-06-17 06:32:27 --> Router Class Initialized
INFO - 2021-06-17 06:32:27 --> Output Class Initialized
INFO - 2021-06-17 06:32:27 --> Security Class Initialized
DEBUG - 2021-06-17 06:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:32:27 --> Input Class Initialized
INFO - 2021-06-17 06:32:27 --> Language Class Initialized
INFO - 2021-06-17 06:32:27 --> Language Class Initialized
INFO - 2021-06-17 06:32:27 --> Config Class Initialized
INFO - 2021-06-17 06:32:27 --> Loader Class Initialized
INFO - 2021-06-17 06:32:27 --> Helper loaded: url_helper
INFO - 2021-06-17 06:32:27 --> Helper loaded: file_helper
INFO - 2021-06-17 06:32:27 --> Helper loaded: form_helper
INFO - 2021-06-17 06:32:27 --> Helper loaded: my_helper
INFO - 2021-06-17 06:32:27 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:32:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:32:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:32:27 --> Controller Class Initialized
INFO - 2021-06-17 06:32:49 --> Config Class Initialized
INFO - 2021-06-17 06:32:49 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:32:49 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:32:49 --> Utf8 Class Initialized
INFO - 2021-06-17 06:32:49 --> URI Class Initialized
INFO - 2021-06-17 06:32:49 --> Router Class Initialized
INFO - 2021-06-17 06:32:49 --> Output Class Initialized
INFO - 2021-06-17 06:32:49 --> Security Class Initialized
DEBUG - 2021-06-17 06:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:32:49 --> Input Class Initialized
INFO - 2021-06-17 06:32:49 --> Language Class Initialized
INFO - 2021-06-17 06:32:49 --> Language Class Initialized
INFO - 2021-06-17 06:32:49 --> Config Class Initialized
INFO - 2021-06-17 06:32:49 --> Loader Class Initialized
INFO - 2021-06-17 06:32:49 --> Helper loaded: url_helper
INFO - 2021-06-17 06:32:49 --> Helper loaded: file_helper
INFO - 2021-06-17 06:32:49 --> Helper loaded: form_helper
INFO - 2021-06-17 06:32:49 --> Helper loaded: my_helper
INFO - 2021-06-17 06:32:49 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:32:49 --> Controller Class Initialized
DEBUG - 2021-06-17 06:32:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-17 06:32:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:32:49 --> Final output sent to browser
DEBUG - 2021-06-17 06:32:49 --> Total execution time: 0.0446
INFO - 2021-06-17 06:32:49 --> Config Class Initialized
INFO - 2021-06-17 06:32:49 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:32:49 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:32:49 --> Utf8 Class Initialized
INFO - 2021-06-17 06:32:49 --> URI Class Initialized
INFO - 2021-06-17 06:32:49 --> Router Class Initialized
INFO - 2021-06-17 06:32:49 --> Output Class Initialized
INFO - 2021-06-17 06:32:49 --> Security Class Initialized
DEBUG - 2021-06-17 06:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:32:49 --> Input Class Initialized
INFO - 2021-06-17 06:32:49 --> Language Class Initialized
INFO - 2021-06-17 06:32:49 --> Language Class Initialized
INFO - 2021-06-17 06:32:49 --> Config Class Initialized
INFO - 2021-06-17 06:32:49 --> Loader Class Initialized
INFO - 2021-06-17 06:32:49 --> Helper loaded: url_helper
INFO - 2021-06-17 06:32:49 --> Helper loaded: file_helper
INFO - 2021-06-17 06:32:49 --> Helper loaded: form_helper
INFO - 2021-06-17 06:32:49 --> Helper loaded: my_helper
INFO - 2021-06-17 06:32:49 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:32:49 --> Controller Class Initialized
INFO - 2021-06-17 06:32:51 --> Config Class Initialized
INFO - 2021-06-17 06:32:51 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:32:51 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:32:51 --> Utf8 Class Initialized
INFO - 2021-06-17 06:32:51 --> URI Class Initialized
INFO - 2021-06-17 06:32:51 --> Router Class Initialized
INFO - 2021-06-17 06:32:51 --> Output Class Initialized
INFO - 2021-06-17 06:32:51 --> Security Class Initialized
DEBUG - 2021-06-17 06:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:32:51 --> Input Class Initialized
INFO - 2021-06-17 06:32:51 --> Language Class Initialized
INFO - 2021-06-17 06:32:51 --> Language Class Initialized
INFO - 2021-06-17 06:32:51 --> Config Class Initialized
INFO - 2021-06-17 06:32:51 --> Loader Class Initialized
INFO - 2021-06-17 06:32:51 --> Helper loaded: url_helper
INFO - 2021-06-17 06:32:51 --> Helper loaded: file_helper
INFO - 2021-06-17 06:32:51 --> Helper loaded: form_helper
INFO - 2021-06-17 06:32:51 --> Helper loaded: my_helper
INFO - 2021-06-17 06:32:51 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:32:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:32:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:32:51 --> Controller Class Initialized
DEBUG - 2021-06-17 06:32:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 06:32:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:32:51 --> Final output sent to browser
DEBUG - 2021-06-17 06:32:51 --> Total execution time: 0.0449
INFO - 2021-06-17 06:32:54 --> Config Class Initialized
INFO - 2021-06-17 06:32:54 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:32:54 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:32:54 --> Utf8 Class Initialized
INFO - 2021-06-17 06:32:54 --> URI Class Initialized
INFO - 2021-06-17 06:32:54 --> Router Class Initialized
INFO - 2021-06-17 06:32:54 --> Output Class Initialized
INFO - 2021-06-17 06:32:54 --> Security Class Initialized
DEBUG - 2021-06-17 06:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:32:54 --> Input Class Initialized
INFO - 2021-06-17 06:32:54 --> Language Class Initialized
INFO - 2021-06-17 06:32:54 --> Language Class Initialized
INFO - 2021-06-17 06:32:54 --> Config Class Initialized
INFO - 2021-06-17 06:32:54 --> Loader Class Initialized
INFO - 2021-06-17 06:32:54 --> Helper loaded: url_helper
INFO - 2021-06-17 06:32:54 --> Helper loaded: file_helper
INFO - 2021-06-17 06:32:54 --> Helper loaded: form_helper
INFO - 2021-06-17 06:32:54 --> Helper loaded: my_helper
INFO - 2021-06-17 06:32:54 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:32:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:32:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:32:54 --> Controller Class Initialized
INFO - 2021-06-17 06:32:55 --> Config Class Initialized
INFO - 2021-06-17 06:32:55 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:32:55 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:32:55 --> Utf8 Class Initialized
INFO - 2021-06-17 06:32:55 --> URI Class Initialized
INFO - 2021-06-17 06:32:55 --> Router Class Initialized
INFO - 2021-06-17 06:32:55 --> Output Class Initialized
INFO - 2021-06-17 06:32:55 --> Security Class Initialized
DEBUG - 2021-06-17 06:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:32:55 --> Input Class Initialized
INFO - 2021-06-17 06:32:55 --> Language Class Initialized
INFO - 2021-06-17 06:32:55 --> Language Class Initialized
INFO - 2021-06-17 06:32:55 --> Config Class Initialized
INFO - 2021-06-17 06:32:55 --> Loader Class Initialized
INFO - 2021-06-17 06:32:55 --> Helper loaded: url_helper
INFO - 2021-06-17 06:32:55 --> Helper loaded: file_helper
INFO - 2021-06-17 06:32:55 --> Helper loaded: form_helper
INFO - 2021-06-17 06:32:55 --> Helper loaded: my_helper
INFO - 2021-06-17 06:32:55 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:32:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:32:55 --> Controller Class Initialized
INFO - 2021-06-17 06:33:26 --> Config Class Initialized
INFO - 2021-06-17 06:33:26 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:33:26 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:33:26 --> Utf8 Class Initialized
INFO - 2021-06-17 06:33:26 --> URI Class Initialized
INFO - 2021-06-17 06:33:26 --> Router Class Initialized
INFO - 2021-06-17 06:33:26 --> Output Class Initialized
INFO - 2021-06-17 06:33:26 --> Security Class Initialized
DEBUG - 2021-06-17 06:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:33:26 --> Input Class Initialized
INFO - 2021-06-17 06:33:26 --> Language Class Initialized
INFO - 2021-06-17 06:33:26 --> Language Class Initialized
INFO - 2021-06-17 06:33:26 --> Config Class Initialized
INFO - 2021-06-17 06:33:26 --> Loader Class Initialized
INFO - 2021-06-17 06:33:26 --> Helper loaded: url_helper
INFO - 2021-06-17 06:33:26 --> Helper loaded: file_helper
INFO - 2021-06-17 06:33:26 --> Helper loaded: form_helper
INFO - 2021-06-17 06:33:26 --> Helper loaded: my_helper
INFO - 2021-06-17 06:33:26 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:33:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:33:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:33:26 --> Controller Class Initialized
DEBUG - 2021-06-17 06:33:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-17 06:33:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:33:26 --> Final output sent to browser
DEBUG - 2021-06-17 06:33:26 --> Total execution time: 0.0458
INFO - 2021-06-17 06:33:26 --> Config Class Initialized
INFO - 2021-06-17 06:33:26 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:33:26 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:33:26 --> Utf8 Class Initialized
INFO - 2021-06-17 06:33:26 --> URI Class Initialized
INFO - 2021-06-17 06:33:26 --> Router Class Initialized
INFO - 2021-06-17 06:33:26 --> Output Class Initialized
INFO - 2021-06-17 06:33:26 --> Security Class Initialized
DEBUG - 2021-06-17 06:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:33:26 --> Input Class Initialized
INFO - 2021-06-17 06:33:26 --> Language Class Initialized
INFO - 2021-06-17 06:33:26 --> Language Class Initialized
INFO - 2021-06-17 06:33:26 --> Config Class Initialized
INFO - 2021-06-17 06:33:26 --> Loader Class Initialized
INFO - 2021-06-17 06:33:26 --> Helper loaded: url_helper
INFO - 2021-06-17 06:33:26 --> Helper loaded: file_helper
INFO - 2021-06-17 06:33:26 --> Helper loaded: form_helper
INFO - 2021-06-17 06:33:26 --> Helper loaded: my_helper
INFO - 2021-06-17 06:33:26 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:33:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:33:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:33:26 --> Controller Class Initialized
INFO - 2021-06-17 06:33:27 --> Config Class Initialized
INFO - 2021-06-17 06:33:27 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:33:27 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:33:27 --> Utf8 Class Initialized
INFO - 2021-06-17 06:33:27 --> URI Class Initialized
INFO - 2021-06-17 06:33:27 --> Router Class Initialized
INFO - 2021-06-17 06:33:27 --> Output Class Initialized
INFO - 2021-06-17 06:33:27 --> Security Class Initialized
DEBUG - 2021-06-17 06:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:33:27 --> Input Class Initialized
INFO - 2021-06-17 06:33:27 --> Language Class Initialized
INFO - 2021-06-17 06:33:27 --> Language Class Initialized
INFO - 2021-06-17 06:33:27 --> Config Class Initialized
INFO - 2021-06-17 06:33:27 --> Loader Class Initialized
INFO - 2021-06-17 06:33:27 --> Helper loaded: url_helper
INFO - 2021-06-17 06:33:27 --> Helper loaded: file_helper
INFO - 2021-06-17 06:33:27 --> Helper loaded: form_helper
INFO - 2021-06-17 06:33:27 --> Helper loaded: my_helper
INFO - 2021-06-17 06:33:27 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:33:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:33:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:33:27 --> Controller Class Initialized
DEBUG - 2021-06-17 06:33:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 06:33:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:33:27 --> Final output sent to browser
DEBUG - 2021-06-17 06:33:27 --> Total execution time: 0.0448
INFO - 2021-06-17 06:33:29 --> Config Class Initialized
INFO - 2021-06-17 06:33:29 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:33:29 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:33:29 --> Utf8 Class Initialized
INFO - 2021-06-17 06:33:29 --> URI Class Initialized
INFO - 2021-06-17 06:33:29 --> Router Class Initialized
INFO - 2021-06-17 06:33:29 --> Output Class Initialized
INFO - 2021-06-17 06:33:29 --> Security Class Initialized
DEBUG - 2021-06-17 06:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:33:29 --> Input Class Initialized
INFO - 2021-06-17 06:33:29 --> Language Class Initialized
INFO - 2021-06-17 06:33:29 --> Language Class Initialized
INFO - 2021-06-17 06:33:29 --> Config Class Initialized
INFO - 2021-06-17 06:33:29 --> Loader Class Initialized
INFO - 2021-06-17 06:33:29 --> Helper loaded: url_helper
INFO - 2021-06-17 06:33:29 --> Helper loaded: file_helper
INFO - 2021-06-17 06:33:29 --> Helper loaded: form_helper
INFO - 2021-06-17 06:33:29 --> Helper loaded: my_helper
INFO - 2021-06-17 06:33:29 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:33:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:33:29 --> Controller Class Initialized
INFO - 2021-06-17 06:33:30 --> Config Class Initialized
INFO - 2021-06-17 06:33:30 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:33:30 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:33:30 --> Utf8 Class Initialized
INFO - 2021-06-17 06:33:30 --> URI Class Initialized
INFO - 2021-06-17 06:33:30 --> Router Class Initialized
INFO - 2021-06-17 06:33:30 --> Output Class Initialized
INFO - 2021-06-17 06:33:30 --> Security Class Initialized
DEBUG - 2021-06-17 06:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:33:30 --> Input Class Initialized
INFO - 2021-06-17 06:33:30 --> Language Class Initialized
INFO - 2021-06-17 06:33:30 --> Language Class Initialized
INFO - 2021-06-17 06:33:30 --> Config Class Initialized
INFO - 2021-06-17 06:33:30 --> Loader Class Initialized
INFO - 2021-06-17 06:33:30 --> Helper loaded: url_helper
INFO - 2021-06-17 06:33:30 --> Helper loaded: file_helper
INFO - 2021-06-17 06:33:30 --> Helper loaded: form_helper
INFO - 2021-06-17 06:33:30 --> Helper loaded: my_helper
INFO - 2021-06-17 06:33:30 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:33:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:33:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:33:30 --> Controller Class Initialized
INFO - 2021-06-17 06:34:40 --> Config Class Initialized
INFO - 2021-06-17 06:34:40 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:34:40 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:34:40 --> Utf8 Class Initialized
INFO - 2021-06-17 06:34:40 --> URI Class Initialized
INFO - 2021-06-17 06:34:40 --> Router Class Initialized
INFO - 2021-06-17 06:34:40 --> Output Class Initialized
INFO - 2021-06-17 06:34:40 --> Security Class Initialized
DEBUG - 2021-06-17 06:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:34:40 --> Input Class Initialized
INFO - 2021-06-17 06:34:40 --> Language Class Initialized
INFO - 2021-06-17 06:34:40 --> Language Class Initialized
INFO - 2021-06-17 06:34:40 --> Config Class Initialized
INFO - 2021-06-17 06:34:40 --> Loader Class Initialized
INFO - 2021-06-17 06:34:40 --> Helper loaded: url_helper
INFO - 2021-06-17 06:34:40 --> Helper loaded: file_helper
INFO - 2021-06-17 06:34:40 --> Helper loaded: form_helper
INFO - 2021-06-17 06:34:40 --> Helper loaded: my_helper
INFO - 2021-06-17 06:34:40 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:34:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:34:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:34:40 --> Controller Class Initialized
INFO - 2021-06-17 06:34:40 --> Helper loaded: cookie_helper
INFO - 2021-06-17 06:34:40 --> Config Class Initialized
INFO - 2021-06-17 06:34:40 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:34:40 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:34:40 --> Utf8 Class Initialized
INFO - 2021-06-17 06:34:40 --> URI Class Initialized
INFO - 2021-06-17 06:34:40 --> Router Class Initialized
INFO - 2021-06-17 06:34:40 --> Output Class Initialized
INFO - 2021-06-17 06:34:40 --> Security Class Initialized
DEBUG - 2021-06-17 06:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:34:40 --> Input Class Initialized
INFO - 2021-06-17 06:34:40 --> Language Class Initialized
INFO - 2021-06-17 06:34:40 --> Language Class Initialized
INFO - 2021-06-17 06:34:40 --> Config Class Initialized
INFO - 2021-06-17 06:34:40 --> Loader Class Initialized
INFO - 2021-06-17 06:34:40 --> Helper loaded: url_helper
INFO - 2021-06-17 06:34:40 --> Helper loaded: file_helper
INFO - 2021-06-17 06:34:40 --> Helper loaded: form_helper
INFO - 2021-06-17 06:34:40 --> Helper loaded: my_helper
INFO - 2021-06-17 06:34:40 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:34:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:34:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:34:40 --> Controller Class Initialized
DEBUG - 2021-06-17 06:34:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-17 06:34:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:34:40 --> Final output sent to browser
DEBUG - 2021-06-17 06:34:40 --> Total execution time: 0.0399
INFO - 2021-06-17 06:34:45 --> Config Class Initialized
INFO - 2021-06-17 06:34:45 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:34:45 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:34:45 --> Utf8 Class Initialized
INFO - 2021-06-17 06:34:45 --> URI Class Initialized
INFO - 2021-06-17 06:34:45 --> Router Class Initialized
INFO - 2021-06-17 06:34:45 --> Output Class Initialized
INFO - 2021-06-17 06:34:45 --> Security Class Initialized
DEBUG - 2021-06-17 06:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:34:45 --> Input Class Initialized
INFO - 2021-06-17 06:34:45 --> Language Class Initialized
INFO - 2021-06-17 06:34:45 --> Language Class Initialized
INFO - 2021-06-17 06:34:45 --> Config Class Initialized
INFO - 2021-06-17 06:34:45 --> Loader Class Initialized
INFO - 2021-06-17 06:34:45 --> Helper loaded: url_helper
INFO - 2021-06-17 06:34:45 --> Helper loaded: file_helper
INFO - 2021-06-17 06:34:45 --> Helper loaded: form_helper
INFO - 2021-06-17 06:34:45 --> Helper loaded: my_helper
INFO - 2021-06-17 06:34:45 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:34:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:34:45 --> Controller Class Initialized
INFO - 2021-06-17 06:34:45 --> Helper loaded: cookie_helper
INFO - 2021-06-17 06:34:45 --> Final output sent to browser
DEBUG - 2021-06-17 06:34:45 --> Total execution time: 0.0504
INFO - 2021-06-17 06:34:45 --> Config Class Initialized
INFO - 2021-06-17 06:34:45 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:34:45 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:34:45 --> Utf8 Class Initialized
INFO - 2021-06-17 06:34:45 --> URI Class Initialized
INFO - 2021-06-17 06:34:45 --> Router Class Initialized
INFO - 2021-06-17 06:34:45 --> Output Class Initialized
INFO - 2021-06-17 06:34:45 --> Security Class Initialized
DEBUG - 2021-06-17 06:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:34:45 --> Input Class Initialized
INFO - 2021-06-17 06:34:45 --> Language Class Initialized
INFO - 2021-06-17 06:34:45 --> Language Class Initialized
INFO - 2021-06-17 06:34:45 --> Config Class Initialized
INFO - 2021-06-17 06:34:45 --> Loader Class Initialized
INFO - 2021-06-17 06:34:45 --> Helper loaded: url_helper
INFO - 2021-06-17 06:34:45 --> Helper loaded: file_helper
INFO - 2021-06-17 06:34:45 --> Helper loaded: form_helper
INFO - 2021-06-17 06:34:45 --> Helper loaded: my_helper
INFO - 2021-06-17 06:34:45 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:34:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:34:45 --> Controller Class Initialized
DEBUG - 2021-06-17 06:34:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-17 06:34:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:34:45 --> Final output sent to browser
DEBUG - 2021-06-17 06:34:45 --> Total execution time: 0.1960
INFO - 2021-06-17 06:34:46 --> Config Class Initialized
INFO - 2021-06-17 06:34:46 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:34:46 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:34:46 --> Utf8 Class Initialized
INFO - 2021-06-17 06:34:46 --> URI Class Initialized
INFO - 2021-06-17 06:34:46 --> Router Class Initialized
INFO - 2021-06-17 06:34:46 --> Output Class Initialized
INFO - 2021-06-17 06:34:46 --> Security Class Initialized
DEBUG - 2021-06-17 06:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:34:46 --> Input Class Initialized
INFO - 2021-06-17 06:34:46 --> Language Class Initialized
INFO - 2021-06-17 06:34:46 --> Language Class Initialized
INFO - 2021-06-17 06:34:46 --> Config Class Initialized
INFO - 2021-06-17 06:34:46 --> Loader Class Initialized
INFO - 2021-06-17 06:34:46 --> Helper loaded: url_helper
INFO - 2021-06-17 06:34:46 --> Helper loaded: file_helper
INFO - 2021-06-17 06:34:46 --> Helper loaded: form_helper
INFO - 2021-06-17 06:34:46 --> Helper loaded: my_helper
INFO - 2021-06-17 06:34:46 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:34:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:34:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:34:46 --> Controller Class Initialized
DEBUG - 2021-06-17 06:34:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-17 06:34:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:34:46 --> Final output sent to browser
DEBUG - 2021-06-17 06:34:46 --> Total execution time: 0.0518
INFO - 2021-06-17 06:35:04 --> Config Class Initialized
INFO - 2021-06-17 06:35:04 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:35:04 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:35:04 --> Utf8 Class Initialized
INFO - 2021-06-17 06:35:04 --> URI Class Initialized
INFO - 2021-06-17 06:35:04 --> Router Class Initialized
INFO - 2021-06-17 06:35:04 --> Output Class Initialized
INFO - 2021-06-17 06:35:04 --> Security Class Initialized
DEBUG - 2021-06-17 06:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:35:04 --> Input Class Initialized
INFO - 2021-06-17 06:35:04 --> Language Class Initialized
INFO - 2021-06-17 06:35:04 --> Language Class Initialized
INFO - 2021-06-17 06:35:04 --> Config Class Initialized
INFO - 2021-06-17 06:35:04 --> Loader Class Initialized
INFO - 2021-06-17 06:35:04 --> Helper loaded: url_helper
INFO - 2021-06-17 06:35:04 --> Helper loaded: file_helper
INFO - 2021-06-17 06:35:04 --> Helper loaded: form_helper
INFO - 2021-06-17 06:35:04 --> Helper loaded: my_helper
INFO - 2021-06-17 06:35:04 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:35:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:35:04 --> Controller Class Initialized
DEBUG - 2021-06-17 06:35:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-17 06:35:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:35:04 --> Final output sent to browser
DEBUG - 2021-06-17 06:35:04 --> Total execution time: 0.0462
INFO - 2021-06-17 06:35:04 --> Config Class Initialized
INFO - 2021-06-17 06:35:04 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:35:04 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:35:04 --> Utf8 Class Initialized
INFO - 2021-06-17 06:35:04 --> URI Class Initialized
INFO - 2021-06-17 06:35:04 --> Router Class Initialized
INFO - 2021-06-17 06:35:04 --> Output Class Initialized
INFO - 2021-06-17 06:35:04 --> Security Class Initialized
DEBUG - 2021-06-17 06:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:35:04 --> Input Class Initialized
INFO - 2021-06-17 06:35:04 --> Language Class Initialized
INFO - 2021-06-17 06:35:04 --> Language Class Initialized
INFO - 2021-06-17 06:35:04 --> Config Class Initialized
INFO - 2021-06-17 06:35:04 --> Loader Class Initialized
INFO - 2021-06-17 06:35:04 --> Helper loaded: url_helper
INFO - 2021-06-17 06:35:04 --> Helper loaded: file_helper
INFO - 2021-06-17 06:35:04 --> Helper loaded: form_helper
INFO - 2021-06-17 06:35:04 --> Helper loaded: my_helper
INFO - 2021-06-17 06:35:04 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:35:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:35:04 --> Controller Class Initialized
INFO - 2021-06-17 06:35:05 --> Config Class Initialized
INFO - 2021-06-17 06:35:05 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:35:05 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:35:05 --> Utf8 Class Initialized
INFO - 2021-06-17 06:35:05 --> URI Class Initialized
INFO - 2021-06-17 06:35:05 --> Router Class Initialized
INFO - 2021-06-17 06:35:05 --> Output Class Initialized
INFO - 2021-06-17 06:35:05 --> Security Class Initialized
DEBUG - 2021-06-17 06:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:35:05 --> Input Class Initialized
INFO - 2021-06-17 06:35:05 --> Language Class Initialized
INFO - 2021-06-17 06:35:05 --> Language Class Initialized
INFO - 2021-06-17 06:35:05 --> Config Class Initialized
INFO - 2021-06-17 06:35:05 --> Loader Class Initialized
INFO - 2021-06-17 06:35:05 --> Helper loaded: url_helper
INFO - 2021-06-17 06:35:05 --> Helper loaded: file_helper
INFO - 2021-06-17 06:35:05 --> Helper loaded: form_helper
INFO - 2021-06-17 06:35:05 --> Helper loaded: my_helper
INFO - 2021-06-17 06:35:05 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:35:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:35:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:35:05 --> Controller Class Initialized
DEBUG - 2021-06-17 06:35:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 06:35:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:35:05 --> Final output sent to browser
DEBUG - 2021-06-17 06:35:05 --> Total execution time: 0.0451
INFO - 2021-06-17 06:35:06 --> Config Class Initialized
INFO - 2021-06-17 06:35:06 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:35:06 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:35:06 --> Utf8 Class Initialized
INFO - 2021-06-17 06:35:06 --> URI Class Initialized
INFO - 2021-06-17 06:35:06 --> Router Class Initialized
INFO - 2021-06-17 06:35:06 --> Output Class Initialized
INFO - 2021-06-17 06:35:06 --> Security Class Initialized
DEBUG - 2021-06-17 06:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:35:06 --> Input Class Initialized
INFO - 2021-06-17 06:35:06 --> Language Class Initialized
INFO - 2021-06-17 06:35:06 --> Language Class Initialized
INFO - 2021-06-17 06:35:06 --> Config Class Initialized
INFO - 2021-06-17 06:35:06 --> Loader Class Initialized
INFO - 2021-06-17 06:35:06 --> Helper loaded: url_helper
INFO - 2021-06-17 06:35:06 --> Helper loaded: file_helper
INFO - 2021-06-17 06:35:07 --> Helper loaded: form_helper
INFO - 2021-06-17 06:35:07 --> Helper loaded: my_helper
INFO - 2021-06-17 06:35:07 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:35:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:35:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:35:07 --> Controller Class Initialized
INFO - 2021-06-17 06:35:07 --> Final output sent to browser
DEBUG - 2021-06-17 06:35:07 --> Total execution time: 0.0516
INFO - 2021-06-17 06:35:23 --> Config Class Initialized
INFO - 2021-06-17 06:35:23 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:35:24 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:35:24 --> Utf8 Class Initialized
INFO - 2021-06-17 06:35:24 --> URI Class Initialized
INFO - 2021-06-17 06:35:24 --> Router Class Initialized
INFO - 2021-06-17 06:35:24 --> Output Class Initialized
INFO - 2021-06-17 06:35:24 --> Security Class Initialized
DEBUG - 2021-06-17 06:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:35:24 --> Input Class Initialized
INFO - 2021-06-17 06:35:24 --> Language Class Initialized
INFO - 2021-06-17 06:35:24 --> Language Class Initialized
INFO - 2021-06-17 06:35:24 --> Config Class Initialized
INFO - 2021-06-17 06:35:24 --> Loader Class Initialized
INFO - 2021-06-17 06:35:24 --> Helper loaded: url_helper
INFO - 2021-06-17 06:35:24 --> Helper loaded: file_helper
INFO - 2021-06-17 06:35:24 --> Helper loaded: form_helper
INFO - 2021-06-17 06:35:24 --> Helper loaded: my_helper
INFO - 2021-06-17 06:35:24 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:35:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:35:24 --> Controller Class Initialized
INFO - 2021-06-17 06:35:24 --> Final output sent to browser
DEBUG - 2021-06-17 06:35:24 --> Total execution time: 0.0512
INFO - 2021-06-17 06:35:24 --> Config Class Initialized
INFO - 2021-06-17 06:35:24 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:35:24 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:35:24 --> Utf8 Class Initialized
INFO - 2021-06-17 06:35:24 --> URI Class Initialized
INFO - 2021-06-17 06:35:24 --> Router Class Initialized
INFO - 2021-06-17 06:35:24 --> Output Class Initialized
INFO - 2021-06-17 06:35:24 --> Security Class Initialized
DEBUG - 2021-06-17 06:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:35:24 --> Input Class Initialized
INFO - 2021-06-17 06:35:24 --> Language Class Initialized
INFO - 2021-06-17 06:35:24 --> Language Class Initialized
INFO - 2021-06-17 06:35:24 --> Config Class Initialized
INFO - 2021-06-17 06:35:24 --> Loader Class Initialized
INFO - 2021-06-17 06:35:24 --> Helper loaded: url_helper
INFO - 2021-06-17 06:35:24 --> Helper loaded: file_helper
INFO - 2021-06-17 06:35:24 --> Helper loaded: form_helper
INFO - 2021-06-17 06:35:24 --> Helper loaded: my_helper
INFO - 2021-06-17 06:35:24 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:35:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:35:24 --> Controller Class Initialized
INFO - 2021-06-17 06:35:25 --> Config Class Initialized
INFO - 2021-06-17 06:35:25 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:35:25 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:35:25 --> Utf8 Class Initialized
INFO - 2021-06-17 06:35:25 --> URI Class Initialized
INFO - 2021-06-17 06:35:25 --> Router Class Initialized
INFO - 2021-06-17 06:35:25 --> Output Class Initialized
INFO - 2021-06-17 06:35:25 --> Security Class Initialized
DEBUG - 2021-06-17 06:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:35:25 --> Input Class Initialized
INFO - 2021-06-17 06:35:25 --> Language Class Initialized
INFO - 2021-06-17 06:35:25 --> Language Class Initialized
INFO - 2021-06-17 06:35:25 --> Config Class Initialized
INFO - 2021-06-17 06:35:25 --> Loader Class Initialized
INFO - 2021-06-17 06:35:25 --> Helper loaded: url_helper
INFO - 2021-06-17 06:35:25 --> Helper loaded: file_helper
INFO - 2021-06-17 06:35:25 --> Helper loaded: form_helper
INFO - 2021-06-17 06:35:25 --> Helper loaded: my_helper
INFO - 2021-06-17 06:35:25 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:35:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:35:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:35:25 --> Controller Class Initialized
INFO - 2021-06-17 06:35:25 --> Final output sent to browser
DEBUG - 2021-06-17 06:35:25 --> Total execution time: 0.0406
INFO - 2021-06-17 06:35:39 --> Config Class Initialized
INFO - 2021-06-17 06:35:39 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:35:39 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:35:39 --> Utf8 Class Initialized
INFO - 2021-06-17 06:35:39 --> URI Class Initialized
INFO - 2021-06-17 06:35:39 --> Router Class Initialized
INFO - 2021-06-17 06:35:39 --> Output Class Initialized
INFO - 2021-06-17 06:35:39 --> Security Class Initialized
DEBUG - 2021-06-17 06:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:35:39 --> Input Class Initialized
INFO - 2021-06-17 06:35:39 --> Language Class Initialized
INFO - 2021-06-17 06:35:39 --> Language Class Initialized
INFO - 2021-06-17 06:35:39 --> Config Class Initialized
INFO - 2021-06-17 06:35:39 --> Loader Class Initialized
INFO - 2021-06-17 06:35:39 --> Helper loaded: url_helper
INFO - 2021-06-17 06:35:39 --> Helper loaded: file_helper
INFO - 2021-06-17 06:35:39 --> Helper loaded: form_helper
INFO - 2021-06-17 06:35:39 --> Helper loaded: my_helper
INFO - 2021-06-17 06:35:39 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:35:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:35:39 --> Controller Class Initialized
INFO - 2021-06-17 06:35:39 --> Final output sent to browser
DEBUG - 2021-06-17 06:35:39 --> Total execution time: 0.0525
INFO - 2021-06-17 06:35:39 --> Config Class Initialized
INFO - 2021-06-17 06:35:39 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:35:39 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:35:39 --> Utf8 Class Initialized
INFO - 2021-06-17 06:35:39 --> URI Class Initialized
INFO - 2021-06-17 06:35:39 --> Router Class Initialized
INFO - 2021-06-17 06:35:39 --> Output Class Initialized
INFO - 2021-06-17 06:35:39 --> Security Class Initialized
DEBUG - 2021-06-17 06:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:35:39 --> Input Class Initialized
INFO - 2021-06-17 06:35:39 --> Language Class Initialized
INFO - 2021-06-17 06:35:39 --> Language Class Initialized
INFO - 2021-06-17 06:35:39 --> Config Class Initialized
INFO - 2021-06-17 06:35:39 --> Loader Class Initialized
INFO - 2021-06-17 06:35:39 --> Helper loaded: url_helper
INFO - 2021-06-17 06:35:39 --> Helper loaded: file_helper
INFO - 2021-06-17 06:35:39 --> Helper loaded: form_helper
INFO - 2021-06-17 06:35:39 --> Helper loaded: my_helper
INFO - 2021-06-17 06:35:39 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:35:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:35:39 --> Controller Class Initialized
INFO - 2021-06-17 06:35:51 --> Config Class Initialized
INFO - 2021-06-17 06:35:51 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:35:51 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:35:51 --> Utf8 Class Initialized
INFO - 2021-06-17 06:35:51 --> URI Class Initialized
INFO - 2021-06-17 06:35:51 --> Router Class Initialized
INFO - 2021-06-17 06:35:51 --> Output Class Initialized
INFO - 2021-06-17 06:35:51 --> Security Class Initialized
DEBUG - 2021-06-17 06:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:35:51 --> Input Class Initialized
INFO - 2021-06-17 06:35:51 --> Language Class Initialized
INFO - 2021-06-17 06:35:51 --> Language Class Initialized
INFO - 2021-06-17 06:35:51 --> Config Class Initialized
INFO - 2021-06-17 06:35:51 --> Loader Class Initialized
INFO - 2021-06-17 06:35:51 --> Helper loaded: url_helper
INFO - 2021-06-17 06:35:51 --> Helper loaded: file_helper
INFO - 2021-06-17 06:35:51 --> Helper loaded: form_helper
INFO - 2021-06-17 06:35:51 --> Helper loaded: my_helper
INFO - 2021-06-17 06:35:51 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:35:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:35:51 --> Controller Class Initialized
INFO - 2021-06-17 06:35:51 --> Final output sent to browser
DEBUG - 2021-06-17 06:35:51 --> Total execution time: 0.0402
INFO - 2021-06-17 06:35:56 --> Config Class Initialized
INFO - 2021-06-17 06:35:56 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:35:56 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:35:56 --> Utf8 Class Initialized
INFO - 2021-06-17 06:35:56 --> URI Class Initialized
INFO - 2021-06-17 06:35:56 --> Router Class Initialized
INFO - 2021-06-17 06:35:56 --> Output Class Initialized
INFO - 2021-06-17 06:35:56 --> Security Class Initialized
DEBUG - 2021-06-17 06:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:35:56 --> Input Class Initialized
INFO - 2021-06-17 06:35:56 --> Language Class Initialized
INFO - 2021-06-17 06:35:56 --> Language Class Initialized
INFO - 2021-06-17 06:35:56 --> Config Class Initialized
INFO - 2021-06-17 06:35:56 --> Loader Class Initialized
INFO - 2021-06-17 06:35:56 --> Helper loaded: url_helper
INFO - 2021-06-17 06:35:56 --> Helper loaded: file_helper
INFO - 2021-06-17 06:35:56 --> Helper loaded: form_helper
INFO - 2021-06-17 06:35:56 --> Helper loaded: my_helper
INFO - 2021-06-17 06:35:56 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:35:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:35:56 --> Controller Class Initialized
INFO - 2021-06-17 06:35:56 --> Final output sent to browser
DEBUG - 2021-06-17 06:35:56 --> Total execution time: 0.0405
INFO - 2021-06-17 06:35:56 --> Config Class Initialized
INFO - 2021-06-17 06:35:56 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:35:56 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:35:56 --> Utf8 Class Initialized
INFO - 2021-06-17 06:35:56 --> URI Class Initialized
INFO - 2021-06-17 06:35:56 --> Router Class Initialized
INFO - 2021-06-17 06:35:56 --> Output Class Initialized
INFO - 2021-06-17 06:35:56 --> Security Class Initialized
DEBUG - 2021-06-17 06:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:35:56 --> Input Class Initialized
INFO - 2021-06-17 06:35:56 --> Language Class Initialized
INFO - 2021-06-17 06:35:56 --> Language Class Initialized
INFO - 2021-06-17 06:35:56 --> Config Class Initialized
INFO - 2021-06-17 06:35:56 --> Loader Class Initialized
INFO - 2021-06-17 06:35:56 --> Helper loaded: url_helper
INFO - 2021-06-17 06:35:56 --> Helper loaded: file_helper
INFO - 2021-06-17 06:35:56 --> Helper loaded: form_helper
INFO - 2021-06-17 06:35:56 --> Helper loaded: my_helper
INFO - 2021-06-17 06:35:56 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:35:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:35:56 --> Controller Class Initialized
INFO - 2021-06-17 06:35:57 --> Config Class Initialized
INFO - 2021-06-17 06:35:57 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:35:57 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:35:57 --> Utf8 Class Initialized
INFO - 2021-06-17 06:35:57 --> URI Class Initialized
INFO - 2021-06-17 06:35:57 --> Router Class Initialized
INFO - 2021-06-17 06:35:57 --> Output Class Initialized
INFO - 2021-06-17 06:35:57 --> Security Class Initialized
DEBUG - 2021-06-17 06:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:35:57 --> Input Class Initialized
INFO - 2021-06-17 06:35:57 --> Language Class Initialized
INFO - 2021-06-17 06:35:57 --> Language Class Initialized
INFO - 2021-06-17 06:35:57 --> Config Class Initialized
INFO - 2021-06-17 06:35:57 --> Loader Class Initialized
INFO - 2021-06-17 06:35:57 --> Helper loaded: url_helper
INFO - 2021-06-17 06:35:57 --> Helper loaded: file_helper
INFO - 2021-06-17 06:35:57 --> Helper loaded: form_helper
INFO - 2021-06-17 06:35:57 --> Helper loaded: my_helper
INFO - 2021-06-17 06:35:57 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:35:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:35:57 --> Controller Class Initialized
INFO - 2021-06-17 06:35:57 --> Final output sent to browser
DEBUG - 2021-06-17 06:35:57 --> Total execution time: 0.0400
INFO - 2021-06-17 06:36:05 --> Config Class Initialized
INFO - 2021-06-17 06:36:05 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:36:05 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:36:05 --> Utf8 Class Initialized
INFO - 2021-06-17 06:36:05 --> URI Class Initialized
INFO - 2021-06-17 06:36:05 --> Router Class Initialized
INFO - 2021-06-17 06:36:05 --> Output Class Initialized
INFO - 2021-06-17 06:36:05 --> Security Class Initialized
DEBUG - 2021-06-17 06:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:36:05 --> Input Class Initialized
INFO - 2021-06-17 06:36:05 --> Language Class Initialized
INFO - 2021-06-17 06:36:05 --> Language Class Initialized
INFO - 2021-06-17 06:36:05 --> Config Class Initialized
INFO - 2021-06-17 06:36:05 --> Loader Class Initialized
INFO - 2021-06-17 06:36:05 --> Helper loaded: url_helper
INFO - 2021-06-17 06:36:05 --> Helper loaded: file_helper
INFO - 2021-06-17 06:36:05 --> Helper loaded: form_helper
INFO - 2021-06-17 06:36:05 --> Helper loaded: my_helper
INFO - 2021-06-17 06:36:05 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:36:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:36:05 --> Controller Class Initialized
INFO - 2021-06-17 06:36:05 --> Final output sent to browser
DEBUG - 2021-06-17 06:36:05 --> Total execution time: 0.0511
INFO - 2021-06-17 06:36:05 --> Config Class Initialized
INFO - 2021-06-17 06:36:05 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:36:05 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:36:05 --> Utf8 Class Initialized
INFO - 2021-06-17 06:36:05 --> URI Class Initialized
INFO - 2021-06-17 06:36:05 --> Router Class Initialized
INFO - 2021-06-17 06:36:05 --> Output Class Initialized
INFO - 2021-06-17 06:36:05 --> Security Class Initialized
DEBUG - 2021-06-17 06:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:36:05 --> Input Class Initialized
INFO - 2021-06-17 06:36:05 --> Language Class Initialized
INFO - 2021-06-17 06:36:05 --> Language Class Initialized
INFO - 2021-06-17 06:36:05 --> Config Class Initialized
INFO - 2021-06-17 06:36:05 --> Loader Class Initialized
INFO - 2021-06-17 06:36:05 --> Helper loaded: url_helper
INFO - 2021-06-17 06:36:05 --> Helper loaded: file_helper
INFO - 2021-06-17 06:36:05 --> Helper loaded: form_helper
INFO - 2021-06-17 06:36:05 --> Helper loaded: my_helper
INFO - 2021-06-17 06:36:05 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:36:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:36:05 --> Controller Class Initialized
INFO - 2021-06-17 06:36:08 --> Config Class Initialized
INFO - 2021-06-17 06:36:08 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:36:08 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:36:08 --> Utf8 Class Initialized
INFO - 2021-06-17 06:36:08 --> URI Class Initialized
INFO - 2021-06-17 06:36:08 --> Router Class Initialized
INFO - 2021-06-17 06:36:08 --> Output Class Initialized
INFO - 2021-06-17 06:36:08 --> Security Class Initialized
DEBUG - 2021-06-17 06:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:36:08 --> Input Class Initialized
INFO - 2021-06-17 06:36:08 --> Language Class Initialized
INFO - 2021-06-17 06:36:08 --> Language Class Initialized
INFO - 2021-06-17 06:36:08 --> Config Class Initialized
INFO - 2021-06-17 06:36:08 --> Loader Class Initialized
INFO - 2021-06-17 06:36:08 --> Helper loaded: url_helper
INFO - 2021-06-17 06:36:08 --> Helper loaded: file_helper
INFO - 2021-06-17 06:36:08 --> Helper loaded: form_helper
INFO - 2021-06-17 06:36:08 --> Helper loaded: my_helper
INFO - 2021-06-17 06:36:08 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:36:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:36:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:36:08 --> Controller Class Initialized
INFO - 2021-06-17 06:36:08 --> Final output sent to browser
DEBUG - 2021-06-17 06:36:08 --> Total execution time: 0.0493
INFO - 2021-06-17 06:36:59 --> Config Class Initialized
INFO - 2021-06-17 06:36:59 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:36:59 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:36:59 --> Utf8 Class Initialized
INFO - 2021-06-17 06:36:59 --> URI Class Initialized
INFO - 2021-06-17 06:36:59 --> Router Class Initialized
INFO - 2021-06-17 06:36:59 --> Output Class Initialized
INFO - 2021-06-17 06:36:59 --> Security Class Initialized
DEBUG - 2021-06-17 06:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:36:59 --> Input Class Initialized
INFO - 2021-06-17 06:36:59 --> Language Class Initialized
INFO - 2021-06-17 06:36:59 --> Language Class Initialized
INFO - 2021-06-17 06:36:59 --> Config Class Initialized
INFO - 2021-06-17 06:36:59 --> Loader Class Initialized
INFO - 2021-06-17 06:36:59 --> Helper loaded: url_helper
INFO - 2021-06-17 06:36:59 --> Helper loaded: file_helper
INFO - 2021-06-17 06:36:59 --> Helper loaded: form_helper
INFO - 2021-06-17 06:36:59 --> Helper loaded: my_helper
INFO - 2021-06-17 06:36:59 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:36:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:36:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:36:59 --> Controller Class Initialized
INFO - 2021-06-17 06:36:59 --> Final output sent to browser
DEBUG - 2021-06-17 06:36:59 --> Total execution time: 0.0485
INFO - 2021-06-17 06:37:19 --> Config Class Initialized
INFO - 2021-06-17 06:37:19 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:37:19 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:37:19 --> Utf8 Class Initialized
INFO - 2021-06-17 06:37:19 --> URI Class Initialized
INFO - 2021-06-17 06:37:19 --> Router Class Initialized
INFO - 2021-06-17 06:37:19 --> Output Class Initialized
INFO - 2021-06-17 06:37:19 --> Security Class Initialized
DEBUG - 2021-06-17 06:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:37:19 --> Input Class Initialized
INFO - 2021-06-17 06:37:19 --> Language Class Initialized
INFO - 2021-06-17 06:37:19 --> Language Class Initialized
INFO - 2021-06-17 06:37:19 --> Config Class Initialized
INFO - 2021-06-17 06:37:19 --> Loader Class Initialized
INFO - 2021-06-17 06:37:19 --> Helper loaded: url_helper
INFO - 2021-06-17 06:37:19 --> Helper loaded: file_helper
INFO - 2021-06-17 06:37:19 --> Helper loaded: form_helper
INFO - 2021-06-17 06:37:19 --> Helper loaded: my_helper
INFO - 2021-06-17 06:37:19 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:37:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:37:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:37:19 --> Controller Class Initialized
INFO - 2021-06-17 06:37:19 --> Final output sent to browser
DEBUG - 2021-06-17 06:37:19 --> Total execution time: 0.0712
INFO - 2021-06-17 06:37:19 --> Config Class Initialized
INFO - 2021-06-17 06:37:19 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:37:19 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:37:19 --> Utf8 Class Initialized
INFO - 2021-06-17 06:37:19 --> URI Class Initialized
INFO - 2021-06-17 06:37:19 --> Router Class Initialized
INFO - 2021-06-17 06:37:19 --> Output Class Initialized
INFO - 2021-06-17 06:37:19 --> Security Class Initialized
DEBUG - 2021-06-17 06:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:37:19 --> Input Class Initialized
INFO - 2021-06-17 06:37:19 --> Language Class Initialized
INFO - 2021-06-17 06:37:19 --> Language Class Initialized
INFO - 2021-06-17 06:37:19 --> Config Class Initialized
INFO - 2021-06-17 06:37:19 --> Loader Class Initialized
INFO - 2021-06-17 06:37:19 --> Helper loaded: url_helper
INFO - 2021-06-17 06:37:19 --> Helper loaded: file_helper
INFO - 2021-06-17 06:37:19 --> Helper loaded: form_helper
INFO - 2021-06-17 06:37:19 --> Helper loaded: my_helper
INFO - 2021-06-17 06:37:19 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:37:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:37:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:37:19 --> Controller Class Initialized
INFO - 2021-06-17 06:37:21 --> Config Class Initialized
INFO - 2021-06-17 06:37:21 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:37:21 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:37:21 --> Utf8 Class Initialized
INFO - 2021-06-17 06:37:21 --> URI Class Initialized
INFO - 2021-06-17 06:37:21 --> Router Class Initialized
INFO - 2021-06-17 06:37:21 --> Output Class Initialized
INFO - 2021-06-17 06:37:21 --> Security Class Initialized
DEBUG - 2021-06-17 06:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:37:21 --> Input Class Initialized
INFO - 2021-06-17 06:37:21 --> Language Class Initialized
INFO - 2021-06-17 06:37:21 --> Language Class Initialized
INFO - 2021-06-17 06:37:21 --> Config Class Initialized
INFO - 2021-06-17 06:37:21 --> Loader Class Initialized
INFO - 2021-06-17 06:37:21 --> Helper loaded: url_helper
INFO - 2021-06-17 06:37:21 --> Helper loaded: file_helper
INFO - 2021-06-17 06:37:21 --> Helper loaded: form_helper
INFO - 2021-06-17 06:37:21 --> Helper loaded: my_helper
INFO - 2021-06-17 06:37:21 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:37:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:37:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:37:21 --> Controller Class Initialized
INFO - 2021-06-17 06:37:21 --> Final output sent to browser
DEBUG - 2021-06-17 06:37:21 --> Total execution time: 0.0712
INFO - 2021-06-17 06:37:21 --> Config Class Initialized
INFO - 2021-06-17 06:37:21 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:37:21 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:37:21 --> Utf8 Class Initialized
INFO - 2021-06-17 06:37:21 --> URI Class Initialized
INFO - 2021-06-17 06:37:21 --> Router Class Initialized
INFO - 2021-06-17 06:37:21 --> Output Class Initialized
INFO - 2021-06-17 06:37:21 --> Security Class Initialized
DEBUG - 2021-06-17 06:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:37:21 --> Input Class Initialized
INFO - 2021-06-17 06:37:21 --> Language Class Initialized
INFO - 2021-06-17 06:37:21 --> Language Class Initialized
INFO - 2021-06-17 06:37:21 --> Config Class Initialized
INFO - 2021-06-17 06:37:21 --> Loader Class Initialized
INFO - 2021-06-17 06:37:21 --> Helper loaded: url_helper
INFO - 2021-06-17 06:37:21 --> Helper loaded: file_helper
INFO - 2021-06-17 06:37:21 --> Helper loaded: form_helper
INFO - 2021-06-17 06:37:21 --> Helper loaded: my_helper
INFO - 2021-06-17 06:37:21 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:37:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:37:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:37:21 --> Controller Class Initialized
INFO - 2021-06-17 06:37:22 --> Config Class Initialized
INFO - 2021-06-17 06:37:22 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:37:22 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:37:22 --> Utf8 Class Initialized
INFO - 2021-06-17 06:37:22 --> URI Class Initialized
INFO - 2021-06-17 06:37:22 --> Router Class Initialized
INFO - 2021-06-17 06:37:22 --> Output Class Initialized
INFO - 2021-06-17 06:37:22 --> Security Class Initialized
DEBUG - 2021-06-17 06:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:37:22 --> Input Class Initialized
INFO - 2021-06-17 06:37:22 --> Language Class Initialized
INFO - 2021-06-17 06:37:22 --> Language Class Initialized
INFO - 2021-06-17 06:37:22 --> Config Class Initialized
INFO - 2021-06-17 06:37:22 --> Loader Class Initialized
INFO - 2021-06-17 06:37:22 --> Helper loaded: url_helper
INFO - 2021-06-17 06:37:22 --> Helper loaded: file_helper
INFO - 2021-06-17 06:37:22 --> Helper loaded: form_helper
INFO - 2021-06-17 06:37:22 --> Helper loaded: my_helper
INFO - 2021-06-17 06:37:22 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:37:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:37:22 --> Controller Class Initialized
INFO - 2021-06-17 06:37:22 --> Final output sent to browser
DEBUG - 2021-06-17 06:37:22 --> Total execution time: 0.0707
INFO - 2021-06-17 06:37:23 --> Config Class Initialized
INFO - 2021-06-17 06:37:23 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:37:23 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:37:23 --> Utf8 Class Initialized
INFO - 2021-06-17 06:37:23 --> URI Class Initialized
INFO - 2021-06-17 06:37:23 --> Router Class Initialized
INFO - 2021-06-17 06:37:23 --> Output Class Initialized
INFO - 2021-06-17 06:37:23 --> Security Class Initialized
DEBUG - 2021-06-17 06:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:37:23 --> Input Class Initialized
INFO - 2021-06-17 06:37:23 --> Language Class Initialized
INFO - 2021-06-17 06:37:23 --> Language Class Initialized
INFO - 2021-06-17 06:37:23 --> Config Class Initialized
INFO - 2021-06-17 06:37:23 --> Loader Class Initialized
INFO - 2021-06-17 06:37:23 --> Helper loaded: url_helper
INFO - 2021-06-17 06:37:23 --> Helper loaded: file_helper
INFO - 2021-06-17 06:37:23 --> Helper loaded: form_helper
INFO - 2021-06-17 06:37:23 --> Helper loaded: my_helper
INFO - 2021-06-17 06:37:23 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:37:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:37:23 --> Controller Class Initialized
INFO - 2021-06-17 06:37:24 --> Config Class Initialized
INFO - 2021-06-17 06:37:24 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:37:24 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:37:24 --> Utf8 Class Initialized
INFO - 2021-06-17 06:37:24 --> URI Class Initialized
INFO - 2021-06-17 06:37:24 --> Router Class Initialized
INFO - 2021-06-17 06:37:24 --> Output Class Initialized
INFO - 2021-06-17 06:37:24 --> Security Class Initialized
DEBUG - 2021-06-17 06:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:37:24 --> Input Class Initialized
INFO - 2021-06-17 06:37:24 --> Language Class Initialized
INFO - 2021-06-17 06:37:24 --> Language Class Initialized
INFO - 2021-06-17 06:37:24 --> Config Class Initialized
INFO - 2021-06-17 06:37:24 --> Loader Class Initialized
INFO - 2021-06-17 06:37:24 --> Helper loaded: url_helper
INFO - 2021-06-17 06:37:24 --> Helper loaded: file_helper
INFO - 2021-06-17 06:37:24 --> Helper loaded: form_helper
INFO - 2021-06-17 06:37:24 --> Helper loaded: my_helper
INFO - 2021-06-17 06:37:24 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:37:24 --> Controller Class Initialized
INFO - 2021-06-17 06:37:24 --> Final output sent to browser
DEBUG - 2021-06-17 06:37:24 --> Total execution time: 0.0702
INFO - 2021-06-17 06:37:24 --> Config Class Initialized
INFO - 2021-06-17 06:37:24 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:37:24 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:37:24 --> Utf8 Class Initialized
INFO - 2021-06-17 06:37:24 --> URI Class Initialized
INFO - 2021-06-17 06:37:24 --> Router Class Initialized
INFO - 2021-06-17 06:37:24 --> Output Class Initialized
INFO - 2021-06-17 06:37:24 --> Security Class Initialized
DEBUG - 2021-06-17 06:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:37:24 --> Input Class Initialized
INFO - 2021-06-17 06:37:24 --> Language Class Initialized
INFO - 2021-06-17 06:37:24 --> Language Class Initialized
INFO - 2021-06-17 06:37:24 --> Config Class Initialized
INFO - 2021-06-17 06:37:24 --> Loader Class Initialized
INFO - 2021-06-17 06:37:24 --> Helper loaded: url_helper
INFO - 2021-06-17 06:37:24 --> Helper loaded: file_helper
INFO - 2021-06-17 06:37:24 --> Helper loaded: form_helper
INFO - 2021-06-17 06:37:24 --> Helper loaded: my_helper
INFO - 2021-06-17 06:37:24 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:37:24 --> Controller Class Initialized
INFO - 2021-06-17 06:37:25 --> Config Class Initialized
INFO - 2021-06-17 06:37:25 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:37:25 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:37:25 --> Utf8 Class Initialized
INFO - 2021-06-17 06:37:25 --> URI Class Initialized
INFO - 2021-06-17 06:37:25 --> Router Class Initialized
INFO - 2021-06-17 06:37:25 --> Output Class Initialized
INFO - 2021-06-17 06:37:25 --> Security Class Initialized
DEBUG - 2021-06-17 06:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:37:25 --> Input Class Initialized
INFO - 2021-06-17 06:37:25 --> Language Class Initialized
INFO - 2021-06-17 06:37:25 --> Language Class Initialized
INFO - 2021-06-17 06:37:25 --> Config Class Initialized
INFO - 2021-06-17 06:37:25 --> Loader Class Initialized
INFO - 2021-06-17 06:37:25 --> Helper loaded: url_helper
INFO - 2021-06-17 06:37:25 --> Helper loaded: file_helper
INFO - 2021-06-17 06:37:25 --> Helper loaded: form_helper
INFO - 2021-06-17 06:37:25 --> Helper loaded: my_helper
INFO - 2021-06-17 06:37:25 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:37:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:37:25 --> Controller Class Initialized
INFO - 2021-06-17 06:37:25 --> Final output sent to browser
DEBUG - 2021-06-17 06:37:25 --> Total execution time: 0.0497
INFO - 2021-06-17 06:37:38 --> Config Class Initialized
INFO - 2021-06-17 06:37:38 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:37:38 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:37:38 --> Utf8 Class Initialized
INFO - 2021-06-17 06:37:38 --> URI Class Initialized
INFO - 2021-06-17 06:37:38 --> Router Class Initialized
INFO - 2021-06-17 06:37:38 --> Output Class Initialized
INFO - 2021-06-17 06:37:38 --> Security Class Initialized
DEBUG - 2021-06-17 06:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:37:38 --> Input Class Initialized
INFO - 2021-06-17 06:37:38 --> Language Class Initialized
INFO - 2021-06-17 06:37:38 --> Language Class Initialized
INFO - 2021-06-17 06:37:38 --> Config Class Initialized
INFO - 2021-06-17 06:37:38 --> Loader Class Initialized
INFO - 2021-06-17 06:37:38 --> Helper loaded: url_helper
INFO - 2021-06-17 06:37:38 --> Helper loaded: file_helper
INFO - 2021-06-17 06:37:38 --> Helper loaded: form_helper
INFO - 2021-06-17 06:37:38 --> Helper loaded: my_helper
INFO - 2021-06-17 06:37:38 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:37:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:37:38 --> Controller Class Initialized
INFO - 2021-06-17 06:37:38 --> Final output sent to browser
DEBUG - 2021-06-17 06:37:38 --> Total execution time: 0.0507
INFO - 2021-06-17 06:37:38 --> Config Class Initialized
INFO - 2021-06-17 06:37:38 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:37:38 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:37:38 --> Utf8 Class Initialized
INFO - 2021-06-17 06:37:38 --> URI Class Initialized
INFO - 2021-06-17 06:37:38 --> Router Class Initialized
INFO - 2021-06-17 06:37:38 --> Output Class Initialized
INFO - 2021-06-17 06:37:38 --> Security Class Initialized
DEBUG - 2021-06-17 06:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:37:38 --> Input Class Initialized
INFO - 2021-06-17 06:37:38 --> Language Class Initialized
INFO - 2021-06-17 06:37:38 --> Language Class Initialized
INFO - 2021-06-17 06:37:38 --> Config Class Initialized
INFO - 2021-06-17 06:37:38 --> Loader Class Initialized
INFO - 2021-06-17 06:37:38 --> Helper loaded: url_helper
INFO - 2021-06-17 06:37:38 --> Helper loaded: file_helper
INFO - 2021-06-17 06:37:38 --> Helper loaded: form_helper
INFO - 2021-06-17 06:37:38 --> Helper loaded: my_helper
INFO - 2021-06-17 06:37:38 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:37:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:37:38 --> Controller Class Initialized
INFO - 2021-06-17 06:37:39 --> Config Class Initialized
INFO - 2021-06-17 06:37:39 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:37:39 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:37:39 --> Utf8 Class Initialized
INFO - 2021-06-17 06:37:39 --> URI Class Initialized
INFO - 2021-06-17 06:37:39 --> Router Class Initialized
INFO - 2021-06-17 06:37:39 --> Output Class Initialized
INFO - 2021-06-17 06:37:39 --> Security Class Initialized
DEBUG - 2021-06-17 06:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:37:39 --> Input Class Initialized
INFO - 2021-06-17 06:37:39 --> Language Class Initialized
INFO - 2021-06-17 06:37:39 --> Language Class Initialized
INFO - 2021-06-17 06:37:39 --> Config Class Initialized
INFO - 2021-06-17 06:37:39 --> Loader Class Initialized
INFO - 2021-06-17 06:37:39 --> Helper loaded: url_helper
INFO - 2021-06-17 06:37:39 --> Helper loaded: file_helper
INFO - 2021-06-17 06:37:39 --> Helper loaded: form_helper
INFO - 2021-06-17 06:37:39 --> Helper loaded: my_helper
INFO - 2021-06-17 06:37:39 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:37:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:37:39 --> Controller Class Initialized
INFO - 2021-06-17 06:37:39 --> Final output sent to browser
DEBUG - 2021-06-17 06:37:39 --> Total execution time: 0.0501
INFO - 2021-06-17 06:37:48 --> Config Class Initialized
INFO - 2021-06-17 06:37:48 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:37:48 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:37:48 --> Utf8 Class Initialized
INFO - 2021-06-17 06:37:48 --> URI Class Initialized
INFO - 2021-06-17 06:37:48 --> Router Class Initialized
INFO - 2021-06-17 06:37:48 --> Output Class Initialized
INFO - 2021-06-17 06:37:48 --> Security Class Initialized
DEBUG - 2021-06-17 06:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:37:48 --> Input Class Initialized
INFO - 2021-06-17 06:37:48 --> Language Class Initialized
INFO - 2021-06-17 06:37:48 --> Language Class Initialized
INFO - 2021-06-17 06:37:48 --> Config Class Initialized
INFO - 2021-06-17 06:37:48 --> Loader Class Initialized
INFO - 2021-06-17 06:37:48 --> Helper loaded: url_helper
INFO - 2021-06-17 06:37:48 --> Helper loaded: file_helper
INFO - 2021-06-17 06:37:48 --> Helper loaded: form_helper
INFO - 2021-06-17 06:37:48 --> Helper loaded: my_helper
INFO - 2021-06-17 06:37:48 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:37:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:37:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:37:48 --> Controller Class Initialized
INFO - 2021-06-17 06:37:48 --> Final output sent to browser
DEBUG - 2021-06-17 06:37:48 --> Total execution time: 0.0412
INFO - 2021-06-17 06:37:48 --> Config Class Initialized
INFO - 2021-06-17 06:37:48 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:37:48 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:37:48 --> Utf8 Class Initialized
INFO - 2021-06-17 06:37:48 --> URI Class Initialized
INFO - 2021-06-17 06:37:48 --> Router Class Initialized
INFO - 2021-06-17 06:37:48 --> Output Class Initialized
INFO - 2021-06-17 06:37:48 --> Security Class Initialized
DEBUG - 2021-06-17 06:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:37:48 --> Input Class Initialized
INFO - 2021-06-17 06:37:48 --> Language Class Initialized
INFO - 2021-06-17 06:37:48 --> Language Class Initialized
INFO - 2021-06-17 06:37:48 --> Config Class Initialized
INFO - 2021-06-17 06:37:48 --> Loader Class Initialized
INFO - 2021-06-17 06:37:48 --> Helper loaded: url_helper
INFO - 2021-06-17 06:37:48 --> Helper loaded: file_helper
INFO - 2021-06-17 06:37:48 --> Helper loaded: form_helper
INFO - 2021-06-17 06:37:48 --> Helper loaded: my_helper
INFO - 2021-06-17 06:37:48 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:37:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:37:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:37:48 --> Controller Class Initialized
INFO - 2021-06-17 06:37:50 --> Config Class Initialized
INFO - 2021-06-17 06:37:50 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:37:50 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:37:50 --> Utf8 Class Initialized
INFO - 2021-06-17 06:37:50 --> URI Class Initialized
INFO - 2021-06-17 06:37:50 --> Router Class Initialized
INFO - 2021-06-17 06:37:50 --> Output Class Initialized
INFO - 2021-06-17 06:37:50 --> Security Class Initialized
DEBUG - 2021-06-17 06:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:37:50 --> Input Class Initialized
INFO - 2021-06-17 06:37:50 --> Language Class Initialized
INFO - 2021-06-17 06:37:50 --> Language Class Initialized
INFO - 2021-06-17 06:37:50 --> Config Class Initialized
INFO - 2021-06-17 06:37:50 --> Loader Class Initialized
INFO - 2021-06-17 06:37:50 --> Helper loaded: url_helper
INFO - 2021-06-17 06:37:50 --> Helper loaded: file_helper
INFO - 2021-06-17 06:37:50 --> Helper loaded: form_helper
INFO - 2021-06-17 06:37:50 --> Helper loaded: my_helper
INFO - 2021-06-17 06:37:50 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:37:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:37:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:37:50 --> Controller Class Initialized
INFO - 2021-06-17 06:37:50 --> Final output sent to browser
DEBUG - 2021-06-17 06:37:50 --> Total execution time: 0.0499
INFO - 2021-06-17 06:38:00 --> Config Class Initialized
INFO - 2021-06-17 06:38:00 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:38:00 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:38:00 --> Utf8 Class Initialized
INFO - 2021-06-17 06:38:00 --> URI Class Initialized
INFO - 2021-06-17 06:38:00 --> Router Class Initialized
INFO - 2021-06-17 06:38:00 --> Output Class Initialized
INFO - 2021-06-17 06:38:00 --> Security Class Initialized
DEBUG - 2021-06-17 06:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:38:00 --> Input Class Initialized
INFO - 2021-06-17 06:38:00 --> Language Class Initialized
INFO - 2021-06-17 06:38:00 --> Language Class Initialized
INFO - 2021-06-17 06:38:00 --> Config Class Initialized
INFO - 2021-06-17 06:38:00 --> Loader Class Initialized
INFO - 2021-06-17 06:38:00 --> Helper loaded: url_helper
INFO - 2021-06-17 06:38:00 --> Helper loaded: file_helper
INFO - 2021-06-17 06:38:00 --> Helper loaded: form_helper
INFO - 2021-06-17 06:38:00 --> Helper loaded: my_helper
INFO - 2021-06-17 06:38:00 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:38:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:38:00 --> Controller Class Initialized
INFO - 2021-06-17 06:38:00 --> Final output sent to browser
DEBUG - 2021-06-17 06:38:00 --> Total execution time: 0.0410
INFO - 2021-06-17 06:38:00 --> Config Class Initialized
INFO - 2021-06-17 06:38:00 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:38:00 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:38:00 --> Utf8 Class Initialized
INFO - 2021-06-17 06:38:00 --> URI Class Initialized
INFO - 2021-06-17 06:38:00 --> Router Class Initialized
INFO - 2021-06-17 06:38:00 --> Output Class Initialized
INFO - 2021-06-17 06:38:00 --> Security Class Initialized
DEBUG - 2021-06-17 06:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:38:00 --> Input Class Initialized
INFO - 2021-06-17 06:38:00 --> Language Class Initialized
INFO - 2021-06-17 06:38:00 --> Language Class Initialized
INFO - 2021-06-17 06:38:00 --> Config Class Initialized
INFO - 2021-06-17 06:38:00 --> Loader Class Initialized
INFO - 2021-06-17 06:38:00 --> Helper loaded: url_helper
INFO - 2021-06-17 06:38:00 --> Helper loaded: file_helper
INFO - 2021-06-17 06:38:00 --> Helper loaded: form_helper
INFO - 2021-06-17 06:38:00 --> Helper loaded: my_helper
INFO - 2021-06-17 06:38:00 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:38:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:38:00 --> Controller Class Initialized
INFO - 2021-06-17 06:38:02 --> Config Class Initialized
INFO - 2021-06-17 06:38:02 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:38:02 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:38:02 --> Utf8 Class Initialized
INFO - 2021-06-17 06:38:02 --> URI Class Initialized
INFO - 2021-06-17 06:38:02 --> Router Class Initialized
INFO - 2021-06-17 06:38:02 --> Output Class Initialized
INFO - 2021-06-17 06:38:02 --> Security Class Initialized
DEBUG - 2021-06-17 06:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:38:02 --> Input Class Initialized
INFO - 2021-06-17 06:38:02 --> Language Class Initialized
INFO - 2021-06-17 06:38:02 --> Language Class Initialized
INFO - 2021-06-17 06:38:02 --> Config Class Initialized
INFO - 2021-06-17 06:38:02 --> Loader Class Initialized
INFO - 2021-06-17 06:38:02 --> Helper loaded: url_helper
INFO - 2021-06-17 06:38:02 --> Helper loaded: file_helper
INFO - 2021-06-17 06:38:02 --> Helper loaded: form_helper
INFO - 2021-06-17 06:38:02 --> Helper loaded: my_helper
INFO - 2021-06-17 06:38:02 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:38:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:38:02 --> Controller Class Initialized
DEBUG - 2021-06-17 06:38:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-17 06:38:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:38:02 --> Final output sent to browser
DEBUG - 2021-06-17 06:38:02 --> Total execution time: 0.0415
INFO - 2021-06-17 06:38:03 --> Config Class Initialized
INFO - 2021-06-17 06:38:03 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:38:03 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:38:03 --> Utf8 Class Initialized
INFO - 2021-06-17 06:38:03 --> URI Class Initialized
INFO - 2021-06-17 06:38:03 --> Router Class Initialized
INFO - 2021-06-17 06:38:03 --> Output Class Initialized
INFO - 2021-06-17 06:38:03 --> Security Class Initialized
DEBUG - 2021-06-17 06:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:38:03 --> Input Class Initialized
INFO - 2021-06-17 06:38:03 --> Language Class Initialized
INFO - 2021-06-17 06:38:03 --> Language Class Initialized
INFO - 2021-06-17 06:38:03 --> Config Class Initialized
INFO - 2021-06-17 06:38:03 --> Loader Class Initialized
INFO - 2021-06-17 06:38:03 --> Helper loaded: url_helper
INFO - 2021-06-17 06:38:03 --> Helper loaded: file_helper
INFO - 2021-06-17 06:38:03 --> Helper loaded: form_helper
INFO - 2021-06-17 06:38:03 --> Helper loaded: my_helper
INFO - 2021-06-17 06:38:03 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:38:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:38:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:38:03 --> Controller Class Initialized
DEBUG - 2021-06-17 06:38:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 06:38:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:38:03 --> Final output sent to browser
DEBUG - 2021-06-17 06:38:03 --> Total execution time: 0.0511
INFO - 2021-06-17 06:38:04 --> Config Class Initialized
INFO - 2021-06-17 06:38:04 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:38:04 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:38:04 --> Utf8 Class Initialized
INFO - 2021-06-17 06:38:04 --> URI Class Initialized
INFO - 2021-06-17 06:38:04 --> Router Class Initialized
INFO - 2021-06-17 06:38:04 --> Output Class Initialized
INFO - 2021-06-17 06:38:04 --> Security Class Initialized
DEBUG - 2021-06-17 06:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:38:04 --> Input Class Initialized
INFO - 2021-06-17 06:38:04 --> Language Class Initialized
INFO - 2021-06-17 06:38:04 --> Language Class Initialized
INFO - 2021-06-17 06:38:04 --> Config Class Initialized
INFO - 2021-06-17 06:38:04 --> Loader Class Initialized
INFO - 2021-06-17 06:38:04 --> Helper loaded: url_helper
INFO - 2021-06-17 06:38:04 --> Helper loaded: file_helper
INFO - 2021-06-17 06:38:04 --> Helper loaded: form_helper
INFO - 2021-06-17 06:38:04 --> Helper loaded: my_helper
INFO - 2021-06-17 06:38:04 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:38:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:38:04 --> Controller Class Initialized
INFO - 2021-06-17 06:38:04 --> Final output sent to browser
DEBUG - 2021-06-17 06:38:04 --> Total execution time: 0.0409
INFO - 2021-06-17 06:38:15 --> Config Class Initialized
INFO - 2021-06-17 06:38:15 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:38:15 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:38:15 --> Utf8 Class Initialized
INFO - 2021-06-17 06:38:15 --> URI Class Initialized
INFO - 2021-06-17 06:38:15 --> Router Class Initialized
INFO - 2021-06-17 06:38:15 --> Output Class Initialized
INFO - 2021-06-17 06:38:15 --> Security Class Initialized
DEBUG - 2021-06-17 06:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:38:15 --> Input Class Initialized
INFO - 2021-06-17 06:38:15 --> Language Class Initialized
INFO - 2021-06-17 06:38:15 --> Language Class Initialized
INFO - 2021-06-17 06:38:15 --> Config Class Initialized
INFO - 2021-06-17 06:38:15 --> Loader Class Initialized
INFO - 2021-06-17 06:38:15 --> Helper loaded: url_helper
INFO - 2021-06-17 06:38:15 --> Helper loaded: file_helper
INFO - 2021-06-17 06:38:15 --> Helper loaded: form_helper
INFO - 2021-06-17 06:38:15 --> Helper loaded: my_helper
INFO - 2021-06-17 06:38:15 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:38:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:38:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:38:15 --> Controller Class Initialized
INFO - 2021-06-17 06:38:15 --> Final output sent to browser
DEBUG - 2021-06-17 06:38:15 --> Total execution time: 0.0410
INFO - 2021-06-17 06:38:15 --> Config Class Initialized
INFO - 2021-06-17 06:38:15 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:38:15 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:38:15 --> Utf8 Class Initialized
INFO - 2021-06-17 06:38:15 --> URI Class Initialized
INFO - 2021-06-17 06:38:15 --> Router Class Initialized
INFO - 2021-06-17 06:38:15 --> Output Class Initialized
INFO - 2021-06-17 06:38:15 --> Security Class Initialized
DEBUG - 2021-06-17 06:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:38:15 --> Input Class Initialized
INFO - 2021-06-17 06:38:15 --> Language Class Initialized
INFO - 2021-06-17 06:38:15 --> Language Class Initialized
INFO - 2021-06-17 06:38:15 --> Config Class Initialized
INFO - 2021-06-17 06:38:15 --> Loader Class Initialized
INFO - 2021-06-17 06:38:15 --> Helper loaded: url_helper
INFO - 2021-06-17 06:38:15 --> Helper loaded: file_helper
INFO - 2021-06-17 06:38:15 --> Helper loaded: form_helper
INFO - 2021-06-17 06:38:15 --> Helper loaded: my_helper
INFO - 2021-06-17 06:38:15 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:38:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:38:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:38:15 --> Controller Class Initialized
DEBUG - 2021-06-17 06:38:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 06:38:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:38:15 --> Final output sent to browser
DEBUG - 2021-06-17 06:38:15 --> Total execution time: 0.0512
INFO - 2021-06-17 06:38:22 --> Config Class Initialized
INFO - 2021-06-17 06:38:22 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:38:22 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:38:22 --> Utf8 Class Initialized
INFO - 2021-06-17 06:38:22 --> URI Class Initialized
INFO - 2021-06-17 06:38:22 --> Router Class Initialized
INFO - 2021-06-17 06:38:22 --> Output Class Initialized
INFO - 2021-06-17 06:38:22 --> Security Class Initialized
DEBUG - 2021-06-17 06:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:38:22 --> Input Class Initialized
INFO - 2021-06-17 06:38:22 --> Language Class Initialized
INFO - 2021-06-17 06:38:22 --> Language Class Initialized
INFO - 2021-06-17 06:38:22 --> Config Class Initialized
INFO - 2021-06-17 06:38:22 --> Loader Class Initialized
INFO - 2021-06-17 06:38:22 --> Helper loaded: url_helper
INFO - 2021-06-17 06:38:22 --> Helper loaded: file_helper
INFO - 2021-06-17 06:38:22 --> Helper loaded: form_helper
INFO - 2021-06-17 06:38:22 --> Helper loaded: my_helper
INFO - 2021-06-17 06:38:22 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:38:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:38:22 --> Controller Class Initialized
INFO - 2021-06-17 06:38:22 --> Final output sent to browser
DEBUG - 2021-06-17 06:38:22 --> Total execution time: 0.0492
INFO - 2021-06-17 06:38:26 --> Config Class Initialized
INFO - 2021-06-17 06:38:26 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:38:26 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:38:26 --> Utf8 Class Initialized
INFO - 2021-06-17 06:38:26 --> URI Class Initialized
INFO - 2021-06-17 06:38:26 --> Router Class Initialized
INFO - 2021-06-17 06:38:26 --> Output Class Initialized
INFO - 2021-06-17 06:38:26 --> Security Class Initialized
DEBUG - 2021-06-17 06:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:38:26 --> Input Class Initialized
INFO - 2021-06-17 06:38:26 --> Language Class Initialized
INFO - 2021-06-17 06:38:26 --> Language Class Initialized
INFO - 2021-06-17 06:38:26 --> Config Class Initialized
INFO - 2021-06-17 06:38:26 --> Loader Class Initialized
INFO - 2021-06-17 06:38:26 --> Helper loaded: url_helper
INFO - 2021-06-17 06:38:26 --> Helper loaded: file_helper
INFO - 2021-06-17 06:38:26 --> Helper loaded: form_helper
INFO - 2021-06-17 06:38:26 --> Helper loaded: my_helper
INFO - 2021-06-17 06:38:26 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:38:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:38:26 --> Controller Class Initialized
INFO - 2021-06-17 06:38:26 --> Final output sent to browser
DEBUG - 2021-06-17 06:38:26 --> Total execution time: 0.0486
INFO - 2021-06-17 06:38:26 --> Config Class Initialized
INFO - 2021-06-17 06:38:26 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:38:26 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:38:26 --> Utf8 Class Initialized
INFO - 2021-06-17 06:38:26 --> URI Class Initialized
INFO - 2021-06-17 06:38:26 --> Router Class Initialized
INFO - 2021-06-17 06:38:26 --> Output Class Initialized
INFO - 2021-06-17 06:38:26 --> Security Class Initialized
DEBUG - 2021-06-17 06:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:38:26 --> Input Class Initialized
INFO - 2021-06-17 06:38:26 --> Language Class Initialized
INFO - 2021-06-17 06:38:26 --> Language Class Initialized
INFO - 2021-06-17 06:38:26 --> Config Class Initialized
INFO - 2021-06-17 06:38:26 --> Loader Class Initialized
INFO - 2021-06-17 06:38:26 --> Helper loaded: url_helper
INFO - 2021-06-17 06:38:26 --> Helper loaded: file_helper
INFO - 2021-06-17 06:38:26 --> Helper loaded: form_helper
INFO - 2021-06-17 06:38:26 --> Helper loaded: my_helper
INFO - 2021-06-17 06:38:26 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:38:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:38:26 --> Controller Class Initialized
DEBUG - 2021-06-17 06:38:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 06:38:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:38:26 --> Final output sent to browser
DEBUG - 2021-06-17 06:38:26 --> Total execution time: 0.0524
INFO - 2021-06-17 06:38:33 --> Config Class Initialized
INFO - 2021-06-17 06:38:33 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:38:33 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:38:33 --> Utf8 Class Initialized
INFO - 2021-06-17 06:38:33 --> URI Class Initialized
INFO - 2021-06-17 06:38:33 --> Router Class Initialized
INFO - 2021-06-17 06:38:33 --> Output Class Initialized
INFO - 2021-06-17 06:38:33 --> Security Class Initialized
DEBUG - 2021-06-17 06:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:38:33 --> Input Class Initialized
INFO - 2021-06-17 06:38:33 --> Language Class Initialized
INFO - 2021-06-17 06:38:33 --> Language Class Initialized
INFO - 2021-06-17 06:38:33 --> Config Class Initialized
INFO - 2021-06-17 06:38:33 --> Loader Class Initialized
INFO - 2021-06-17 06:38:33 --> Helper loaded: url_helper
INFO - 2021-06-17 06:38:33 --> Helper loaded: file_helper
INFO - 2021-06-17 06:38:33 --> Helper loaded: form_helper
INFO - 2021-06-17 06:38:33 --> Helper loaded: my_helper
INFO - 2021-06-17 06:38:33 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:38:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:38:33 --> Controller Class Initialized
INFO - 2021-06-17 06:38:33 --> Final output sent to browser
DEBUG - 2021-06-17 06:38:33 --> Total execution time: 0.0493
INFO - 2021-06-17 06:38:37 --> Config Class Initialized
INFO - 2021-06-17 06:38:37 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:38:37 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:38:37 --> Utf8 Class Initialized
INFO - 2021-06-17 06:38:37 --> URI Class Initialized
INFO - 2021-06-17 06:38:37 --> Router Class Initialized
INFO - 2021-06-17 06:38:37 --> Output Class Initialized
INFO - 2021-06-17 06:38:37 --> Security Class Initialized
DEBUG - 2021-06-17 06:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:38:37 --> Input Class Initialized
INFO - 2021-06-17 06:38:37 --> Language Class Initialized
INFO - 2021-06-17 06:38:37 --> Language Class Initialized
INFO - 2021-06-17 06:38:37 --> Config Class Initialized
INFO - 2021-06-17 06:38:37 --> Loader Class Initialized
INFO - 2021-06-17 06:38:37 --> Helper loaded: url_helper
INFO - 2021-06-17 06:38:37 --> Helper loaded: file_helper
INFO - 2021-06-17 06:38:37 --> Helper loaded: form_helper
INFO - 2021-06-17 06:38:37 --> Helper loaded: my_helper
INFO - 2021-06-17 06:38:37 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:38:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:38:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:38:37 --> Controller Class Initialized
INFO - 2021-06-17 06:38:37 --> Final output sent to browser
DEBUG - 2021-06-17 06:38:37 --> Total execution time: 0.0505
INFO - 2021-06-17 06:38:37 --> Config Class Initialized
INFO - 2021-06-17 06:38:37 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:38:37 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:38:37 --> Utf8 Class Initialized
INFO - 2021-06-17 06:38:37 --> URI Class Initialized
INFO - 2021-06-17 06:38:37 --> Router Class Initialized
INFO - 2021-06-17 06:38:37 --> Output Class Initialized
INFO - 2021-06-17 06:38:37 --> Security Class Initialized
DEBUG - 2021-06-17 06:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:38:37 --> Input Class Initialized
INFO - 2021-06-17 06:38:37 --> Language Class Initialized
INFO - 2021-06-17 06:38:37 --> Language Class Initialized
INFO - 2021-06-17 06:38:37 --> Config Class Initialized
INFO - 2021-06-17 06:38:37 --> Loader Class Initialized
INFO - 2021-06-17 06:38:37 --> Helper loaded: url_helper
INFO - 2021-06-17 06:38:37 --> Helper loaded: file_helper
INFO - 2021-06-17 06:38:37 --> Helper loaded: form_helper
INFO - 2021-06-17 06:38:37 --> Helper loaded: my_helper
INFO - 2021-06-17 06:38:37 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:38:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:38:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:38:37 --> Controller Class Initialized
DEBUG - 2021-06-17 06:38:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 06:38:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:38:37 --> Final output sent to browser
DEBUG - 2021-06-17 06:38:37 --> Total execution time: 0.0434
INFO - 2021-06-17 06:38:45 --> Config Class Initialized
INFO - 2021-06-17 06:38:45 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:38:45 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:38:45 --> Utf8 Class Initialized
INFO - 2021-06-17 06:38:45 --> URI Class Initialized
INFO - 2021-06-17 06:38:45 --> Router Class Initialized
INFO - 2021-06-17 06:38:45 --> Output Class Initialized
INFO - 2021-06-17 06:38:45 --> Security Class Initialized
DEBUG - 2021-06-17 06:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:38:45 --> Input Class Initialized
INFO - 2021-06-17 06:38:45 --> Language Class Initialized
INFO - 2021-06-17 06:38:45 --> Language Class Initialized
INFO - 2021-06-17 06:38:45 --> Config Class Initialized
INFO - 2021-06-17 06:38:45 --> Loader Class Initialized
INFO - 2021-06-17 06:38:45 --> Helper loaded: url_helper
INFO - 2021-06-17 06:38:45 --> Helper loaded: file_helper
INFO - 2021-06-17 06:38:45 --> Helper loaded: form_helper
INFO - 2021-06-17 06:38:45 --> Helper loaded: my_helper
INFO - 2021-06-17 06:38:45 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:38:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:38:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:38:45 --> Controller Class Initialized
DEBUG - 2021-06-17 06:38:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-17 06:38:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:38:45 --> Final output sent to browser
DEBUG - 2021-06-17 06:38:45 --> Total execution time: 0.0454
INFO - 2021-06-17 06:38:46 --> Config Class Initialized
INFO - 2021-06-17 06:38:46 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:38:46 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:38:46 --> Utf8 Class Initialized
INFO - 2021-06-17 06:38:46 --> URI Class Initialized
INFO - 2021-06-17 06:38:46 --> Router Class Initialized
INFO - 2021-06-17 06:38:46 --> Output Class Initialized
INFO - 2021-06-17 06:38:46 --> Security Class Initialized
DEBUG - 2021-06-17 06:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:38:46 --> Input Class Initialized
INFO - 2021-06-17 06:38:46 --> Language Class Initialized
INFO - 2021-06-17 06:38:46 --> Language Class Initialized
INFO - 2021-06-17 06:38:46 --> Config Class Initialized
INFO - 2021-06-17 06:38:46 --> Loader Class Initialized
INFO - 2021-06-17 06:38:46 --> Helper loaded: url_helper
INFO - 2021-06-17 06:38:46 --> Helper loaded: file_helper
INFO - 2021-06-17 06:38:46 --> Helper loaded: form_helper
INFO - 2021-06-17 06:38:46 --> Helper loaded: my_helper
INFO - 2021-06-17 06:38:46 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:38:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:38:46 --> Controller Class Initialized
INFO - 2021-06-17 06:38:47 --> Config Class Initialized
INFO - 2021-06-17 06:38:47 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:38:47 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:38:47 --> Utf8 Class Initialized
INFO - 2021-06-17 06:38:47 --> URI Class Initialized
INFO - 2021-06-17 06:38:47 --> Router Class Initialized
INFO - 2021-06-17 06:38:47 --> Output Class Initialized
INFO - 2021-06-17 06:38:47 --> Security Class Initialized
DEBUG - 2021-06-17 06:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:38:47 --> Input Class Initialized
INFO - 2021-06-17 06:38:47 --> Language Class Initialized
INFO - 2021-06-17 06:38:47 --> Language Class Initialized
INFO - 2021-06-17 06:38:47 --> Config Class Initialized
INFO - 2021-06-17 06:38:47 --> Loader Class Initialized
INFO - 2021-06-17 06:38:47 --> Helper loaded: url_helper
INFO - 2021-06-17 06:38:47 --> Helper loaded: file_helper
INFO - 2021-06-17 06:38:47 --> Helper loaded: form_helper
INFO - 2021-06-17 06:38:47 --> Helper loaded: my_helper
INFO - 2021-06-17 06:38:47 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:38:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:38:47 --> Controller Class Initialized
DEBUG - 2021-06-17 06:38:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 06:38:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:38:47 --> Final output sent to browser
DEBUG - 2021-06-17 06:38:47 --> Total execution time: 0.0454
INFO - 2021-06-17 06:38:50 --> Config Class Initialized
INFO - 2021-06-17 06:38:50 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:38:50 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:38:50 --> Utf8 Class Initialized
INFO - 2021-06-17 06:38:50 --> URI Class Initialized
INFO - 2021-06-17 06:38:50 --> Router Class Initialized
INFO - 2021-06-17 06:38:50 --> Output Class Initialized
INFO - 2021-06-17 06:38:50 --> Security Class Initialized
DEBUG - 2021-06-17 06:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:38:50 --> Input Class Initialized
INFO - 2021-06-17 06:38:50 --> Language Class Initialized
INFO - 2021-06-17 06:38:50 --> Language Class Initialized
INFO - 2021-06-17 06:38:50 --> Config Class Initialized
INFO - 2021-06-17 06:38:50 --> Loader Class Initialized
INFO - 2021-06-17 06:38:50 --> Helper loaded: url_helper
INFO - 2021-06-17 06:38:50 --> Helper loaded: file_helper
INFO - 2021-06-17 06:38:50 --> Helper loaded: form_helper
INFO - 2021-06-17 06:38:50 --> Helper loaded: my_helper
INFO - 2021-06-17 06:38:50 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:38:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:38:50 --> Controller Class Initialized
INFO - 2021-06-17 06:38:51 --> Config Class Initialized
INFO - 2021-06-17 06:38:51 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:38:51 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:38:51 --> Utf8 Class Initialized
INFO - 2021-06-17 06:38:51 --> URI Class Initialized
INFO - 2021-06-17 06:38:51 --> Router Class Initialized
INFO - 2021-06-17 06:38:51 --> Output Class Initialized
INFO - 2021-06-17 06:38:51 --> Security Class Initialized
DEBUG - 2021-06-17 06:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:38:51 --> Input Class Initialized
INFO - 2021-06-17 06:38:51 --> Language Class Initialized
INFO - 2021-06-17 06:38:51 --> Language Class Initialized
INFO - 2021-06-17 06:38:51 --> Config Class Initialized
INFO - 2021-06-17 06:38:51 --> Loader Class Initialized
INFO - 2021-06-17 06:38:51 --> Helper loaded: url_helper
INFO - 2021-06-17 06:38:51 --> Helper loaded: file_helper
INFO - 2021-06-17 06:38:51 --> Helper loaded: form_helper
INFO - 2021-06-17 06:38:51 --> Helper loaded: my_helper
INFO - 2021-06-17 06:38:51 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:38:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:38:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:38:51 --> Controller Class Initialized
INFO - 2021-06-17 06:40:04 --> Config Class Initialized
INFO - 2021-06-17 06:40:04 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:40:04 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:40:04 --> Utf8 Class Initialized
INFO - 2021-06-17 06:40:04 --> URI Class Initialized
INFO - 2021-06-17 06:40:04 --> Router Class Initialized
INFO - 2021-06-17 06:40:04 --> Output Class Initialized
INFO - 2021-06-17 06:40:04 --> Security Class Initialized
DEBUG - 2021-06-17 06:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:40:04 --> Input Class Initialized
INFO - 2021-06-17 06:40:04 --> Language Class Initialized
INFO - 2021-06-17 06:40:04 --> Language Class Initialized
INFO - 2021-06-17 06:40:04 --> Config Class Initialized
INFO - 2021-06-17 06:40:04 --> Loader Class Initialized
INFO - 2021-06-17 06:40:04 --> Helper loaded: url_helper
INFO - 2021-06-17 06:40:04 --> Helper loaded: file_helper
INFO - 2021-06-17 06:40:04 --> Helper loaded: form_helper
INFO - 2021-06-17 06:40:04 --> Helper loaded: my_helper
INFO - 2021-06-17 06:40:04 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:40:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:40:04 --> Controller Class Initialized
DEBUG - 2021-06-17 06:40:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-17 06:40:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:40:04 --> Final output sent to browser
DEBUG - 2021-06-17 06:40:04 --> Total execution time: 0.0479
INFO - 2021-06-17 06:40:04 --> Config Class Initialized
INFO - 2021-06-17 06:40:04 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:40:04 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:40:04 --> Utf8 Class Initialized
INFO - 2021-06-17 06:40:04 --> URI Class Initialized
INFO - 2021-06-17 06:40:04 --> Router Class Initialized
INFO - 2021-06-17 06:40:04 --> Output Class Initialized
INFO - 2021-06-17 06:40:04 --> Security Class Initialized
DEBUG - 2021-06-17 06:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:40:04 --> Input Class Initialized
INFO - 2021-06-17 06:40:04 --> Language Class Initialized
INFO - 2021-06-17 06:40:04 --> Language Class Initialized
INFO - 2021-06-17 06:40:04 --> Config Class Initialized
INFO - 2021-06-17 06:40:04 --> Loader Class Initialized
INFO - 2021-06-17 06:40:04 --> Helper loaded: url_helper
INFO - 2021-06-17 06:40:04 --> Helper loaded: file_helper
INFO - 2021-06-17 06:40:04 --> Helper loaded: form_helper
INFO - 2021-06-17 06:40:04 --> Helper loaded: my_helper
INFO - 2021-06-17 06:40:04 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:40:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:40:04 --> Controller Class Initialized
INFO - 2021-06-17 06:40:11 --> Config Class Initialized
INFO - 2021-06-17 06:40:11 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:40:11 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:40:11 --> Utf8 Class Initialized
INFO - 2021-06-17 06:40:11 --> URI Class Initialized
INFO - 2021-06-17 06:40:11 --> Router Class Initialized
INFO - 2021-06-17 06:40:11 --> Output Class Initialized
INFO - 2021-06-17 06:40:11 --> Security Class Initialized
DEBUG - 2021-06-17 06:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:40:11 --> Input Class Initialized
INFO - 2021-06-17 06:40:11 --> Language Class Initialized
INFO - 2021-06-17 06:40:11 --> Language Class Initialized
INFO - 2021-06-17 06:40:11 --> Config Class Initialized
INFO - 2021-06-17 06:40:11 --> Loader Class Initialized
INFO - 2021-06-17 06:40:11 --> Helper loaded: url_helper
INFO - 2021-06-17 06:40:11 --> Helper loaded: file_helper
INFO - 2021-06-17 06:40:11 --> Helper loaded: form_helper
INFO - 2021-06-17 06:40:11 --> Helper loaded: my_helper
INFO - 2021-06-17 06:40:11 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:40:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:40:11 --> Controller Class Initialized
INFO - 2021-06-17 06:40:11 --> Final output sent to browser
DEBUG - 2021-06-17 06:40:11 --> Total execution time: 0.0482
INFO - 2021-06-17 06:40:25 --> Config Class Initialized
INFO - 2021-06-17 06:40:25 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:40:25 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:40:25 --> Utf8 Class Initialized
INFO - 2021-06-17 06:40:25 --> URI Class Initialized
INFO - 2021-06-17 06:40:25 --> Router Class Initialized
INFO - 2021-06-17 06:40:25 --> Output Class Initialized
INFO - 2021-06-17 06:40:25 --> Security Class Initialized
DEBUG - 2021-06-17 06:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:40:25 --> Input Class Initialized
INFO - 2021-06-17 06:40:25 --> Language Class Initialized
INFO - 2021-06-17 06:40:25 --> Language Class Initialized
INFO - 2021-06-17 06:40:25 --> Config Class Initialized
INFO - 2021-06-17 06:40:25 --> Loader Class Initialized
INFO - 2021-06-17 06:40:25 --> Helper loaded: url_helper
INFO - 2021-06-17 06:40:25 --> Helper loaded: file_helper
INFO - 2021-06-17 06:40:25 --> Helper loaded: form_helper
INFO - 2021-06-17 06:40:25 --> Helper loaded: my_helper
INFO - 2021-06-17 06:40:25 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:40:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:40:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:40:25 --> Controller Class Initialized
INFO - 2021-06-17 06:40:25 --> Final output sent to browser
DEBUG - 2021-06-17 06:40:25 --> Total execution time: 0.0505
INFO - 2021-06-17 06:40:25 --> Config Class Initialized
INFO - 2021-06-17 06:40:25 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:40:25 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:40:25 --> Utf8 Class Initialized
INFO - 2021-06-17 06:40:25 --> URI Class Initialized
INFO - 2021-06-17 06:40:25 --> Router Class Initialized
INFO - 2021-06-17 06:40:25 --> Output Class Initialized
INFO - 2021-06-17 06:40:25 --> Security Class Initialized
DEBUG - 2021-06-17 06:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:40:25 --> Input Class Initialized
INFO - 2021-06-17 06:40:25 --> Language Class Initialized
INFO - 2021-06-17 06:40:25 --> Language Class Initialized
INFO - 2021-06-17 06:40:25 --> Config Class Initialized
INFO - 2021-06-17 06:40:25 --> Loader Class Initialized
INFO - 2021-06-17 06:40:25 --> Helper loaded: url_helper
INFO - 2021-06-17 06:40:25 --> Helper loaded: file_helper
INFO - 2021-06-17 06:40:25 --> Helper loaded: form_helper
INFO - 2021-06-17 06:40:25 --> Helper loaded: my_helper
INFO - 2021-06-17 06:40:25 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:40:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:40:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:40:25 --> Controller Class Initialized
INFO - 2021-06-17 06:40:33 --> Config Class Initialized
INFO - 2021-06-17 06:40:33 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:40:33 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:40:33 --> Utf8 Class Initialized
INFO - 2021-06-17 06:40:33 --> URI Class Initialized
INFO - 2021-06-17 06:40:33 --> Router Class Initialized
INFO - 2021-06-17 06:40:33 --> Output Class Initialized
INFO - 2021-06-17 06:40:33 --> Security Class Initialized
DEBUG - 2021-06-17 06:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:40:33 --> Input Class Initialized
INFO - 2021-06-17 06:40:33 --> Language Class Initialized
INFO - 2021-06-17 06:40:33 --> Language Class Initialized
INFO - 2021-06-17 06:40:33 --> Config Class Initialized
INFO - 2021-06-17 06:40:33 --> Loader Class Initialized
INFO - 2021-06-17 06:40:33 --> Helper loaded: url_helper
INFO - 2021-06-17 06:40:33 --> Helper loaded: file_helper
INFO - 2021-06-17 06:40:33 --> Helper loaded: form_helper
INFO - 2021-06-17 06:40:33 --> Helper loaded: my_helper
INFO - 2021-06-17 06:40:33 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:40:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:40:33 --> Controller Class Initialized
INFO - 2021-06-17 06:40:33 --> Final output sent to browser
DEBUG - 2021-06-17 06:40:33 --> Total execution time: 0.0414
INFO - 2021-06-17 06:40:38 --> Config Class Initialized
INFO - 2021-06-17 06:40:38 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:40:38 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:40:38 --> Utf8 Class Initialized
INFO - 2021-06-17 06:40:38 --> URI Class Initialized
INFO - 2021-06-17 06:40:38 --> Router Class Initialized
INFO - 2021-06-17 06:40:38 --> Output Class Initialized
INFO - 2021-06-17 06:40:38 --> Security Class Initialized
DEBUG - 2021-06-17 06:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:40:38 --> Input Class Initialized
INFO - 2021-06-17 06:40:38 --> Language Class Initialized
INFO - 2021-06-17 06:40:38 --> Language Class Initialized
INFO - 2021-06-17 06:40:38 --> Config Class Initialized
INFO - 2021-06-17 06:40:38 --> Loader Class Initialized
INFO - 2021-06-17 06:40:38 --> Helper loaded: url_helper
INFO - 2021-06-17 06:40:38 --> Helper loaded: file_helper
INFO - 2021-06-17 06:40:38 --> Helper loaded: form_helper
INFO - 2021-06-17 06:40:38 --> Helper loaded: my_helper
INFO - 2021-06-17 06:40:38 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:40:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:40:38 --> Controller Class Initialized
INFO - 2021-06-17 06:40:38 --> Final output sent to browser
DEBUG - 2021-06-17 06:40:38 --> Total execution time: 0.0613
INFO - 2021-06-17 06:40:38 --> Config Class Initialized
INFO - 2021-06-17 06:40:38 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:40:38 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:40:38 --> Utf8 Class Initialized
INFO - 2021-06-17 06:40:38 --> URI Class Initialized
INFO - 2021-06-17 06:40:38 --> Router Class Initialized
INFO - 2021-06-17 06:40:38 --> Output Class Initialized
INFO - 2021-06-17 06:40:38 --> Security Class Initialized
DEBUG - 2021-06-17 06:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:40:38 --> Input Class Initialized
INFO - 2021-06-17 06:40:38 --> Language Class Initialized
INFO - 2021-06-17 06:40:38 --> Language Class Initialized
INFO - 2021-06-17 06:40:38 --> Config Class Initialized
INFO - 2021-06-17 06:40:38 --> Loader Class Initialized
INFO - 2021-06-17 06:40:38 --> Helper loaded: url_helper
INFO - 2021-06-17 06:40:38 --> Helper loaded: file_helper
INFO - 2021-06-17 06:40:38 --> Helper loaded: form_helper
INFO - 2021-06-17 06:40:38 --> Helper loaded: my_helper
INFO - 2021-06-17 06:40:38 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:40:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:40:38 --> Controller Class Initialized
INFO - 2021-06-17 06:40:40 --> Config Class Initialized
INFO - 2021-06-17 06:40:40 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:40:40 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:40:40 --> Utf8 Class Initialized
INFO - 2021-06-17 06:40:40 --> URI Class Initialized
INFO - 2021-06-17 06:40:40 --> Router Class Initialized
INFO - 2021-06-17 06:40:40 --> Output Class Initialized
INFO - 2021-06-17 06:40:40 --> Security Class Initialized
DEBUG - 2021-06-17 06:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:40:40 --> Input Class Initialized
INFO - 2021-06-17 06:40:40 --> Language Class Initialized
INFO - 2021-06-17 06:40:40 --> Language Class Initialized
INFO - 2021-06-17 06:40:40 --> Config Class Initialized
INFO - 2021-06-17 06:40:40 --> Loader Class Initialized
INFO - 2021-06-17 06:40:40 --> Helper loaded: url_helper
INFO - 2021-06-17 06:40:40 --> Helper loaded: file_helper
INFO - 2021-06-17 06:40:40 --> Helper loaded: form_helper
INFO - 2021-06-17 06:40:40 --> Helper loaded: my_helper
INFO - 2021-06-17 06:40:40 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:40:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:40:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:40:40 --> Controller Class Initialized
INFO - 2021-06-17 06:40:40 --> Final output sent to browser
DEBUG - 2021-06-17 06:40:40 --> Total execution time: 0.0691
INFO - 2021-06-17 06:40:40 --> Config Class Initialized
INFO - 2021-06-17 06:40:40 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:40:40 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:40:40 --> Utf8 Class Initialized
INFO - 2021-06-17 06:40:40 --> URI Class Initialized
INFO - 2021-06-17 06:40:40 --> Router Class Initialized
INFO - 2021-06-17 06:40:40 --> Output Class Initialized
INFO - 2021-06-17 06:40:40 --> Security Class Initialized
DEBUG - 2021-06-17 06:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:40:40 --> Input Class Initialized
INFO - 2021-06-17 06:40:40 --> Language Class Initialized
INFO - 2021-06-17 06:40:40 --> Language Class Initialized
INFO - 2021-06-17 06:40:40 --> Config Class Initialized
INFO - 2021-06-17 06:40:40 --> Loader Class Initialized
INFO - 2021-06-17 06:40:40 --> Helper loaded: url_helper
INFO - 2021-06-17 06:40:40 --> Helper loaded: file_helper
INFO - 2021-06-17 06:40:40 --> Helper loaded: form_helper
INFO - 2021-06-17 06:40:40 --> Helper loaded: my_helper
INFO - 2021-06-17 06:40:40 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:40:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:40:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:40:40 --> Controller Class Initialized
INFO - 2021-06-17 06:40:42 --> Config Class Initialized
INFO - 2021-06-17 06:40:42 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:40:42 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:40:42 --> Utf8 Class Initialized
INFO - 2021-06-17 06:40:42 --> URI Class Initialized
INFO - 2021-06-17 06:40:42 --> Router Class Initialized
INFO - 2021-06-17 06:40:42 --> Output Class Initialized
INFO - 2021-06-17 06:40:42 --> Security Class Initialized
DEBUG - 2021-06-17 06:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:40:42 --> Input Class Initialized
INFO - 2021-06-17 06:40:42 --> Language Class Initialized
INFO - 2021-06-17 06:40:42 --> Language Class Initialized
INFO - 2021-06-17 06:40:42 --> Config Class Initialized
INFO - 2021-06-17 06:40:42 --> Loader Class Initialized
INFO - 2021-06-17 06:40:42 --> Helper loaded: url_helper
INFO - 2021-06-17 06:40:42 --> Helper loaded: file_helper
INFO - 2021-06-17 06:40:42 --> Helper loaded: form_helper
INFO - 2021-06-17 06:40:42 --> Helper loaded: my_helper
INFO - 2021-06-17 06:40:42 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:40:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:40:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:40:42 --> Controller Class Initialized
INFO - 2021-06-17 06:40:42 --> Final output sent to browser
DEBUG - 2021-06-17 06:40:42 --> Total execution time: 0.0691
INFO - 2021-06-17 06:40:42 --> Config Class Initialized
INFO - 2021-06-17 06:40:42 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:40:42 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:40:42 --> Utf8 Class Initialized
INFO - 2021-06-17 06:40:42 --> URI Class Initialized
INFO - 2021-06-17 06:40:42 --> Router Class Initialized
INFO - 2021-06-17 06:40:42 --> Output Class Initialized
INFO - 2021-06-17 06:40:42 --> Security Class Initialized
DEBUG - 2021-06-17 06:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:40:42 --> Input Class Initialized
INFO - 2021-06-17 06:40:42 --> Language Class Initialized
INFO - 2021-06-17 06:40:42 --> Language Class Initialized
INFO - 2021-06-17 06:40:42 --> Config Class Initialized
INFO - 2021-06-17 06:40:42 --> Loader Class Initialized
INFO - 2021-06-17 06:40:42 --> Helper loaded: url_helper
INFO - 2021-06-17 06:40:42 --> Helper loaded: file_helper
INFO - 2021-06-17 06:40:42 --> Helper loaded: form_helper
INFO - 2021-06-17 06:40:42 --> Helper loaded: my_helper
INFO - 2021-06-17 06:40:42 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:40:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:40:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:40:42 --> Controller Class Initialized
INFO - 2021-06-17 06:40:45 --> Config Class Initialized
INFO - 2021-06-17 06:40:45 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:40:45 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:40:45 --> Utf8 Class Initialized
INFO - 2021-06-17 06:40:45 --> URI Class Initialized
INFO - 2021-06-17 06:40:45 --> Router Class Initialized
INFO - 2021-06-17 06:40:45 --> Output Class Initialized
INFO - 2021-06-17 06:40:45 --> Security Class Initialized
DEBUG - 2021-06-17 06:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:40:45 --> Input Class Initialized
INFO - 2021-06-17 06:40:45 --> Language Class Initialized
INFO - 2021-06-17 06:40:45 --> Language Class Initialized
INFO - 2021-06-17 06:40:45 --> Config Class Initialized
INFO - 2021-06-17 06:40:45 --> Loader Class Initialized
INFO - 2021-06-17 06:40:45 --> Helper loaded: url_helper
INFO - 2021-06-17 06:40:45 --> Helper loaded: file_helper
INFO - 2021-06-17 06:40:45 --> Helper loaded: form_helper
INFO - 2021-06-17 06:40:45 --> Helper loaded: my_helper
INFO - 2021-06-17 06:40:45 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:40:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:40:45 --> Controller Class Initialized
DEBUG - 2021-06-17 06:40:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-17 06:40:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:40:45 --> Final output sent to browser
DEBUG - 2021-06-17 06:40:45 --> Total execution time: 0.0502
INFO - 2021-06-17 06:40:46 --> Config Class Initialized
INFO - 2021-06-17 06:40:46 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:40:46 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:40:46 --> Utf8 Class Initialized
INFO - 2021-06-17 06:40:46 --> URI Class Initialized
INFO - 2021-06-17 06:40:46 --> Router Class Initialized
INFO - 2021-06-17 06:40:46 --> Output Class Initialized
INFO - 2021-06-17 06:40:46 --> Security Class Initialized
DEBUG - 2021-06-17 06:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:40:46 --> Input Class Initialized
INFO - 2021-06-17 06:40:46 --> Language Class Initialized
INFO - 2021-06-17 06:40:46 --> Language Class Initialized
INFO - 2021-06-17 06:40:46 --> Config Class Initialized
INFO - 2021-06-17 06:40:46 --> Loader Class Initialized
INFO - 2021-06-17 06:40:46 --> Helper loaded: url_helper
INFO - 2021-06-17 06:40:46 --> Helper loaded: file_helper
INFO - 2021-06-17 06:40:46 --> Helper loaded: form_helper
INFO - 2021-06-17 06:40:46 --> Helper loaded: my_helper
INFO - 2021-06-17 06:40:46 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:40:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:40:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:40:46 --> Controller Class Initialized
DEBUG - 2021-06-17 06:40:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 06:40:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:40:46 --> Final output sent to browser
DEBUG - 2021-06-17 06:40:46 --> Total execution time: 0.0499
INFO - 2021-06-17 06:40:49 --> Config Class Initialized
INFO - 2021-06-17 06:40:49 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:40:49 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:40:49 --> Utf8 Class Initialized
INFO - 2021-06-17 06:40:49 --> URI Class Initialized
INFO - 2021-06-17 06:40:49 --> Router Class Initialized
INFO - 2021-06-17 06:40:49 --> Output Class Initialized
INFO - 2021-06-17 06:40:49 --> Security Class Initialized
DEBUG - 2021-06-17 06:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:40:49 --> Input Class Initialized
INFO - 2021-06-17 06:40:49 --> Language Class Initialized
INFO - 2021-06-17 06:40:49 --> Language Class Initialized
INFO - 2021-06-17 06:40:49 --> Config Class Initialized
INFO - 2021-06-17 06:40:49 --> Loader Class Initialized
INFO - 2021-06-17 06:40:49 --> Helper loaded: url_helper
INFO - 2021-06-17 06:40:49 --> Helper loaded: file_helper
INFO - 2021-06-17 06:40:49 --> Helper loaded: form_helper
INFO - 2021-06-17 06:40:49 --> Helper loaded: my_helper
INFO - 2021-06-17 06:40:49 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:40:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:40:49 --> Controller Class Initialized
INFO - 2021-06-17 06:40:49 --> Final output sent to browser
DEBUG - 2021-06-17 06:40:49 --> Total execution time: 0.0682
INFO - 2021-06-17 06:40:49 --> Config Class Initialized
INFO - 2021-06-17 06:40:49 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:40:49 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:40:49 --> Utf8 Class Initialized
INFO - 2021-06-17 06:40:49 --> URI Class Initialized
INFO - 2021-06-17 06:40:49 --> Router Class Initialized
INFO - 2021-06-17 06:40:49 --> Output Class Initialized
INFO - 2021-06-17 06:40:49 --> Security Class Initialized
DEBUG - 2021-06-17 06:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:40:49 --> Input Class Initialized
INFO - 2021-06-17 06:40:49 --> Language Class Initialized
INFO - 2021-06-17 06:40:49 --> Language Class Initialized
INFO - 2021-06-17 06:40:49 --> Config Class Initialized
INFO - 2021-06-17 06:40:49 --> Loader Class Initialized
INFO - 2021-06-17 06:40:49 --> Helper loaded: url_helper
INFO - 2021-06-17 06:40:49 --> Helper loaded: file_helper
INFO - 2021-06-17 06:40:49 --> Helper loaded: form_helper
INFO - 2021-06-17 06:40:49 --> Helper loaded: my_helper
INFO - 2021-06-17 06:40:49 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:40:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:40:49 --> Controller Class Initialized
DEBUG - 2021-06-17 06:40:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 06:40:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:40:49 --> Final output sent to browser
DEBUG - 2021-06-17 06:40:49 --> Total execution time: 0.0469
INFO - 2021-06-17 06:40:51 --> Config Class Initialized
INFO - 2021-06-17 06:40:51 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:40:51 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:40:51 --> Utf8 Class Initialized
INFO - 2021-06-17 06:40:51 --> URI Class Initialized
INFO - 2021-06-17 06:40:51 --> Router Class Initialized
INFO - 2021-06-17 06:40:51 --> Output Class Initialized
INFO - 2021-06-17 06:40:51 --> Security Class Initialized
DEBUG - 2021-06-17 06:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:40:51 --> Input Class Initialized
INFO - 2021-06-17 06:40:51 --> Language Class Initialized
INFO - 2021-06-17 06:40:51 --> Language Class Initialized
INFO - 2021-06-17 06:40:51 --> Config Class Initialized
INFO - 2021-06-17 06:40:51 --> Loader Class Initialized
INFO - 2021-06-17 06:40:51 --> Helper loaded: url_helper
INFO - 2021-06-17 06:40:51 --> Helper loaded: file_helper
INFO - 2021-06-17 06:40:51 --> Helper loaded: form_helper
INFO - 2021-06-17 06:40:51 --> Helper loaded: my_helper
INFO - 2021-06-17 06:40:51 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:40:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:40:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:40:51 --> Controller Class Initialized
INFO - 2021-06-17 06:40:51 --> Final output sent to browser
DEBUG - 2021-06-17 06:40:51 --> Total execution time: 0.0679
INFO - 2021-06-17 06:40:51 --> Config Class Initialized
INFO - 2021-06-17 06:40:51 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:40:51 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:40:51 --> Utf8 Class Initialized
INFO - 2021-06-17 06:40:51 --> URI Class Initialized
INFO - 2021-06-17 06:40:51 --> Router Class Initialized
INFO - 2021-06-17 06:40:51 --> Output Class Initialized
INFO - 2021-06-17 06:40:51 --> Security Class Initialized
DEBUG - 2021-06-17 06:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:40:51 --> Input Class Initialized
INFO - 2021-06-17 06:40:51 --> Language Class Initialized
INFO - 2021-06-17 06:40:51 --> Language Class Initialized
INFO - 2021-06-17 06:40:51 --> Config Class Initialized
INFO - 2021-06-17 06:40:51 --> Loader Class Initialized
INFO - 2021-06-17 06:40:51 --> Helper loaded: url_helper
INFO - 2021-06-17 06:40:51 --> Helper loaded: file_helper
INFO - 2021-06-17 06:40:51 --> Helper loaded: form_helper
INFO - 2021-06-17 06:40:51 --> Helper loaded: my_helper
INFO - 2021-06-17 06:40:51 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:40:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:40:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:40:51 --> Controller Class Initialized
DEBUG - 2021-06-17 06:40:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 06:40:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:40:51 --> Final output sent to browser
DEBUG - 2021-06-17 06:40:51 --> Total execution time: 0.0557
INFO - 2021-06-17 06:40:53 --> Config Class Initialized
INFO - 2021-06-17 06:40:53 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:40:53 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:40:53 --> Utf8 Class Initialized
INFO - 2021-06-17 06:40:53 --> URI Class Initialized
INFO - 2021-06-17 06:40:53 --> Router Class Initialized
INFO - 2021-06-17 06:40:53 --> Output Class Initialized
INFO - 2021-06-17 06:40:53 --> Security Class Initialized
DEBUG - 2021-06-17 06:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:40:53 --> Input Class Initialized
INFO - 2021-06-17 06:40:53 --> Language Class Initialized
INFO - 2021-06-17 06:40:53 --> Language Class Initialized
INFO - 2021-06-17 06:40:53 --> Config Class Initialized
INFO - 2021-06-17 06:40:53 --> Loader Class Initialized
INFO - 2021-06-17 06:40:53 --> Helper loaded: url_helper
INFO - 2021-06-17 06:40:53 --> Helper loaded: file_helper
INFO - 2021-06-17 06:40:53 --> Helper loaded: form_helper
INFO - 2021-06-17 06:40:53 --> Helper loaded: my_helper
INFO - 2021-06-17 06:40:53 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:40:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:40:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:40:53 --> Controller Class Initialized
INFO - 2021-06-17 06:40:53 --> Final output sent to browser
DEBUG - 2021-06-17 06:40:53 --> Total execution time: 0.0680
INFO - 2021-06-17 06:40:53 --> Config Class Initialized
INFO - 2021-06-17 06:40:53 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:40:53 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:40:53 --> Utf8 Class Initialized
INFO - 2021-06-17 06:40:53 --> URI Class Initialized
INFO - 2021-06-17 06:40:53 --> Router Class Initialized
INFO - 2021-06-17 06:40:53 --> Output Class Initialized
INFO - 2021-06-17 06:40:53 --> Security Class Initialized
DEBUG - 2021-06-17 06:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:40:53 --> Input Class Initialized
INFO - 2021-06-17 06:40:53 --> Language Class Initialized
INFO - 2021-06-17 06:40:53 --> Language Class Initialized
INFO - 2021-06-17 06:40:53 --> Config Class Initialized
INFO - 2021-06-17 06:40:53 --> Loader Class Initialized
INFO - 2021-06-17 06:40:53 --> Helper loaded: url_helper
INFO - 2021-06-17 06:40:53 --> Helper loaded: file_helper
INFO - 2021-06-17 06:40:53 --> Helper loaded: form_helper
INFO - 2021-06-17 06:40:53 --> Helper loaded: my_helper
INFO - 2021-06-17 06:40:53 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:40:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:40:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:40:53 --> Controller Class Initialized
DEBUG - 2021-06-17 06:40:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 06:40:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:40:53 --> Final output sent to browser
DEBUG - 2021-06-17 06:40:53 --> Total execution time: 0.0432
INFO - 2021-06-17 06:40:55 --> Config Class Initialized
INFO - 2021-06-17 06:40:55 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:40:55 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:40:55 --> Utf8 Class Initialized
INFO - 2021-06-17 06:40:55 --> URI Class Initialized
INFO - 2021-06-17 06:40:55 --> Router Class Initialized
INFO - 2021-06-17 06:40:55 --> Output Class Initialized
INFO - 2021-06-17 06:40:55 --> Security Class Initialized
DEBUG - 2021-06-17 06:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:40:55 --> Input Class Initialized
INFO - 2021-06-17 06:40:55 --> Language Class Initialized
INFO - 2021-06-17 06:40:55 --> Language Class Initialized
INFO - 2021-06-17 06:40:55 --> Config Class Initialized
INFO - 2021-06-17 06:40:55 --> Loader Class Initialized
INFO - 2021-06-17 06:40:55 --> Helper loaded: url_helper
INFO - 2021-06-17 06:40:55 --> Helper loaded: file_helper
INFO - 2021-06-17 06:40:55 --> Helper loaded: form_helper
INFO - 2021-06-17 06:40:55 --> Helper loaded: my_helper
INFO - 2021-06-17 06:40:55 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:40:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:40:55 --> Controller Class Initialized
DEBUG - 2021-06-17 06:40:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-17 06:40:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:40:55 --> Final output sent to browser
DEBUG - 2021-06-17 06:40:55 --> Total execution time: 0.0510
INFO - 2021-06-17 06:40:56 --> Config Class Initialized
INFO - 2021-06-17 06:40:56 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:40:56 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:40:56 --> Utf8 Class Initialized
INFO - 2021-06-17 06:40:56 --> URI Class Initialized
INFO - 2021-06-17 06:40:56 --> Router Class Initialized
INFO - 2021-06-17 06:40:56 --> Output Class Initialized
INFO - 2021-06-17 06:40:56 --> Security Class Initialized
DEBUG - 2021-06-17 06:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:40:56 --> Input Class Initialized
INFO - 2021-06-17 06:40:56 --> Language Class Initialized
INFO - 2021-06-17 06:40:56 --> Language Class Initialized
INFO - 2021-06-17 06:40:56 --> Config Class Initialized
INFO - 2021-06-17 06:40:56 --> Loader Class Initialized
INFO - 2021-06-17 06:40:56 --> Helper loaded: url_helper
INFO - 2021-06-17 06:40:56 --> Helper loaded: file_helper
INFO - 2021-06-17 06:40:56 --> Helper loaded: form_helper
INFO - 2021-06-17 06:40:56 --> Helper loaded: my_helper
INFO - 2021-06-17 06:40:56 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:40:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:40:56 --> Controller Class Initialized
DEBUG - 2021-06-17 06:40:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-17 06:40:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:40:56 --> Final output sent to browser
DEBUG - 2021-06-17 06:40:56 --> Total execution time: 0.0412
INFO - 2021-06-17 06:40:56 --> Config Class Initialized
INFO - 2021-06-17 06:40:56 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:40:56 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:40:56 --> Utf8 Class Initialized
INFO - 2021-06-17 06:40:56 --> URI Class Initialized
INFO - 2021-06-17 06:40:56 --> Router Class Initialized
INFO - 2021-06-17 06:40:56 --> Output Class Initialized
INFO - 2021-06-17 06:40:56 --> Security Class Initialized
DEBUG - 2021-06-17 06:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:40:56 --> Input Class Initialized
INFO - 2021-06-17 06:40:56 --> Language Class Initialized
INFO - 2021-06-17 06:40:56 --> Language Class Initialized
INFO - 2021-06-17 06:40:56 --> Config Class Initialized
INFO - 2021-06-17 06:40:56 --> Loader Class Initialized
INFO - 2021-06-17 06:40:56 --> Helper loaded: url_helper
INFO - 2021-06-17 06:40:56 --> Helper loaded: file_helper
INFO - 2021-06-17 06:40:56 --> Helper loaded: form_helper
INFO - 2021-06-17 06:40:56 --> Helper loaded: my_helper
INFO - 2021-06-17 06:40:56 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:40:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:40:56 --> Controller Class Initialized
INFO - 2021-06-17 06:40:58 --> Config Class Initialized
INFO - 2021-06-17 06:40:58 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:40:58 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:40:58 --> Utf8 Class Initialized
INFO - 2021-06-17 06:40:58 --> URI Class Initialized
INFO - 2021-06-17 06:40:58 --> Router Class Initialized
INFO - 2021-06-17 06:40:58 --> Output Class Initialized
INFO - 2021-06-17 06:40:58 --> Security Class Initialized
DEBUG - 2021-06-17 06:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:40:58 --> Input Class Initialized
INFO - 2021-06-17 06:40:58 --> Language Class Initialized
INFO - 2021-06-17 06:40:58 --> Language Class Initialized
INFO - 2021-06-17 06:40:58 --> Config Class Initialized
INFO - 2021-06-17 06:40:58 --> Loader Class Initialized
INFO - 2021-06-17 06:40:58 --> Helper loaded: url_helper
INFO - 2021-06-17 06:40:58 --> Helper loaded: file_helper
INFO - 2021-06-17 06:40:58 --> Helper loaded: form_helper
INFO - 2021-06-17 06:40:58 --> Helper loaded: my_helper
INFO - 2021-06-17 06:40:58 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:40:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:40:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:40:58 --> Controller Class Initialized
INFO - 2021-06-17 06:40:58 --> Final output sent to browser
DEBUG - 2021-06-17 06:40:58 --> Total execution time: 0.0496
INFO - 2021-06-17 06:41:08 --> Config Class Initialized
INFO - 2021-06-17 06:41:08 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:41:08 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:41:08 --> Utf8 Class Initialized
INFO - 2021-06-17 06:41:08 --> URI Class Initialized
INFO - 2021-06-17 06:41:08 --> Router Class Initialized
INFO - 2021-06-17 06:41:08 --> Output Class Initialized
INFO - 2021-06-17 06:41:08 --> Security Class Initialized
DEBUG - 2021-06-17 06:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:41:08 --> Input Class Initialized
INFO - 2021-06-17 06:41:08 --> Language Class Initialized
INFO - 2021-06-17 06:41:08 --> Language Class Initialized
INFO - 2021-06-17 06:41:08 --> Config Class Initialized
INFO - 2021-06-17 06:41:08 --> Loader Class Initialized
INFO - 2021-06-17 06:41:08 --> Helper loaded: url_helper
INFO - 2021-06-17 06:41:08 --> Helper loaded: file_helper
INFO - 2021-06-17 06:41:08 --> Helper loaded: form_helper
INFO - 2021-06-17 06:41:08 --> Helper loaded: my_helper
INFO - 2021-06-17 06:41:08 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:41:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:41:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:41:08 --> Controller Class Initialized
INFO - 2021-06-17 06:41:08 --> Final output sent to browser
DEBUG - 2021-06-17 06:41:08 --> Total execution time: 0.0412
INFO - 2021-06-17 06:41:08 --> Config Class Initialized
INFO - 2021-06-17 06:41:08 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:41:08 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:41:08 --> Utf8 Class Initialized
INFO - 2021-06-17 06:41:08 --> URI Class Initialized
INFO - 2021-06-17 06:41:08 --> Router Class Initialized
INFO - 2021-06-17 06:41:08 --> Output Class Initialized
INFO - 2021-06-17 06:41:08 --> Security Class Initialized
DEBUG - 2021-06-17 06:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:41:08 --> Input Class Initialized
INFO - 2021-06-17 06:41:08 --> Language Class Initialized
INFO - 2021-06-17 06:41:08 --> Language Class Initialized
INFO - 2021-06-17 06:41:08 --> Config Class Initialized
INFO - 2021-06-17 06:41:08 --> Loader Class Initialized
INFO - 2021-06-17 06:41:08 --> Helper loaded: url_helper
INFO - 2021-06-17 06:41:08 --> Helper loaded: file_helper
INFO - 2021-06-17 06:41:08 --> Helper loaded: form_helper
INFO - 2021-06-17 06:41:08 --> Helper loaded: my_helper
INFO - 2021-06-17 06:41:08 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:41:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:41:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:41:08 --> Controller Class Initialized
INFO - 2021-06-17 06:41:09 --> Config Class Initialized
INFO - 2021-06-17 06:41:09 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:41:09 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:41:09 --> Utf8 Class Initialized
INFO - 2021-06-17 06:41:09 --> URI Class Initialized
INFO - 2021-06-17 06:41:09 --> Router Class Initialized
INFO - 2021-06-17 06:41:09 --> Output Class Initialized
INFO - 2021-06-17 06:41:09 --> Security Class Initialized
DEBUG - 2021-06-17 06:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:41:09 --> Input Class Initialized
INFO - 2021-06-17 06:41:09 --> Language Class Initialized
INFO - 2021-06-17 06:41:09 --> Language Class Initialized
INFO - 2021-06-17 06:41:09 --> Config Class Initialized
INFO - 2021-06-17 06:41:09 --> Loader Class Initialized
INFO - 2021-06-17 06:41:09 --> Helper loaded: url_helper
INFO - 2021-06-17 06:41:09 --> Helper loaded: file_helper
INFO - 2021-06-17 06:41:09 --> Helper loaded: form_helper
INFO - 2021-06-17 06:41:09 --> Helper loaded: my_helper
INFO - 2021-06-17 06:41:09 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:41:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:41:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:41:09 --> Controller Class Initialized
INFO - 2021-06-17 06:41:09 --> Final output sent to browser
DEBUG - 2021-06-17 06:41:09 --> Total execution time: 0.0399
INFO - 2021-06-17 06:41:18 --> Config Class Initialized
INFO - 2021-06-17 06:41:18 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:41:18 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:41:18 --> Utf8 Class Initialized
INFO - 2021-06-17 06:41:18 --> URI Class Initialized
INFO - 2021-06-17 06:41:18 --> Router Class Initialized
INFO - 2021-06-17 06:41:18 --> Output Class Initialized
INFO - 2021-06-17 06:41:18 --> Security Class Initialized
DEBUG - 2021-06-17 06:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:41:18 --> Input Class Initialized
INFO - 2021-06-17 06:41:18 --> Language Class Initialized
INFO - 2021-06-17 06:41:18 --> Language Class Initialized
INFO - 2021-06-17 06:41:18 --> Config Class Initialized
INFO - 2021-06-17 06:41:18 --> Loader Class Initialized
INFO - 2021-06-17 06:41:18 --> Helper loaded: url_helper
INFO - 2021-06-17 06:41:18 --> Helper loaded: file_helper
INFO - 2021-06-17 06:41:18 --> Helper loaded: form_helper
INFO - 2021-06-17 06:41:18 --> Helper loaded: my_helper
INFO - 2021-06-17 06:41:18 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:41:18 --> Controller Class Initialized
INFO - 2021-06-17 06:41:18 --> Final output sent to browser
DEBUG - 2021-06-17 06:41:18 --> Total execution time: 0.0497
INFO - 2021-06-17 06:41:18 --> Config Class Initialized
INFO - 2021-06-17 06:41:18 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:41:18 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:41:18 --> Utf8 Class Initialized
INFO - 2021-06-17 06:41:18 --> URI Class Initialized
INFO - 2021-06-17 06:41:18 --> Router Class Initialized
INFO - 2021-06-17 06:41:18 --> Output Class Initialized
INFO - 2021-06-17 06:41:18 --> Security Class Initialized
DEBUG - 2021-06-17 06:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:41:18 --> Input Class Initialized
INFO - 2021-06-17 06:41:18 --> Language Class Initialized
INFO - 2021-06-17 06:41:18 --> Language Class Initialized
INFO - 2021-06-17 06:41:18 --> Config Class Initialized
INFO - 2021-06-17 06:41:18 --> Loader Class Initialized
INFO - 2021-06-17 06:41:18 --> Helper loaded: url_helper
INFO - 2021-06-17 06:41:18 --> Helper loaded: file_helper
INFO - 2021-06-17 06:41:18 --> Helper loaded: form_helper
INFO - 2021-06-17 06:41:18 --> Helper loaded: my_helper
INFO - 2021-06-17 06:41:18 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:41:18 --> Controller Class Initialized
INFO - 2021-06-17 06:41:27 --> Config Class Initialized
INFO - 2021-06-17 06:41:27 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:41:27 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:41:27 --> Utf8 Class Initialized
INFO - 2021-06-17 06:41:27 --> URI Class Initialized
INFO - 2021-06-17 06:41:27 --> Router Class Initialized
INFO - 2021-06-17 06:41:27 --> Output Class Initialized
INFO - 2021-06-17 06:41:27 --> Security Class Initialized
DEBUG - 2021-06-17 06:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:41:27 --> Input Class Initialized
INFO - 2021-06-17 06:41:27 --> Language Class Initialized
INFO - 2021-06-17 06:41:27 --> Language Class Initialized
INFO - 2021-06-17 06:41:27 --> Config Class Initialized
INFO - 2021-06-17 06:41:27 --> Loader Class Initialized
INFO - 2021-06-17 06:41:27 --> Helper loaded: url_helper
INFO - 2021-06-17 06:41:27 --> Helper loaded: file_helper
INFO - 2021-06-17 06:41:27 --> Helper loaded: form_helper
INFO - 2021-06-17 06:41:27 --> Helper loaded: my_helper
INFO - 2021-06-17 06:41:27 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:41:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:41:27 --> Controller Class Initialized
INFO - 2021-06-17 06:41:27 --> Final output sent to browser
DEBUG - 2021-06-17 06:41:27 --> Total execution time: 0.0494
INFO - 2021-06-17 06:41:30 --> Config Class Initialized
INFO - 2021-06-17 06:41:30 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:41:30 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:41:30 --> Utf8 Class Initialized
INFO - 2021-06-17 06:41:30 --> URI Class Initialized
INFO - 2021-06-17 06:41:30 --> Router Class Initialized
INFO - 2021-06-17 06:41:30 --> Output Class Initialized
INFO - 2021-06-17 06:41:30 --> Security Class Initialized
DEBUG - 2021-06-17 06:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:41:30 --> Input Class Initialized
INFO - 2021-06-17 06:41:30 --> Language Class Initialized
INFO - 2021-06-17 06:41:30 --> Language Class Initialized
INFO - 2021-06-17 06:41:30 --> Config Class Initialized
INFO - 2021-06-17 06:41:30 --> Loader Class Initialized
INFO - 2021-06-17 06:41:30 --> Helper loaded: url_helper
INFO - 2021-06-17 06:41:30 --> Helper loaded: file_helper
INFO - 2021-06-17 06:41:30 --> Helper loaded: form_helper
INFO - 2021-06-17 06:41:30 --> Helper loaded: my_helper
INFO - 2021-06-17 06:41:30 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:41:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:41:30 --> Controller Class Initialized
INFO - 2021-06-17 06:41:30 --> Final output sent to browser
DEBUG - 2021-06-17 06:41:30 --> Total execution time: 0.0498
INFO - 2021-06-17 06:41:30 --> Config Class Initialized
INFO - 2021-06-17 06:41:30 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:41:30 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:41:30 --> Utf8 Class Initialized
INFO - 2021-06-17 06:41:30 --> URI Class Initialized
INFO - 2021-06-17 06:41:30 --> Router Class Initialized
INFO - 2021-06-17 06:41:30 --> Output Class Initialized
INFO - 2021-06-17 06:41:30 --> Security Class Initialized
DEBUG - 2021-06-17 06:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:41:30 --> Input Class Initialized
INFO - 2021-06-17 06:41:30 --> Language Class Initialized
INFO - 2021-06-17 06:41:30 --> Language Class Initialized
INFO - 2021-06-17 06:41:30 --> Config Class Initialized
INFO - 2021-06-17 06:41:30 --> Loader Class Initialized
INFO - 2021-06-17 06:41:30 --> Helper loaded: url_helper
INFO - 2021-06-17 06:41:30 --> Helper loaded: file_helper
INFO - 2021-06-17 06:41:30 --> Helper loaded: form_helper
INFO - 2021-06-17 06:41:30 --> Helper loaded: my_helper
INFO - 2021-06-17 06:41:30 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:41:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:41:30 --> Controller Class Initialized
INFO - 2021-06-17 06:41:31 --> Config Class Initialized
INFO - 2021-06-17 06:41:31 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:41:31 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:41:31 --> Utf8 Class Initialized
INFO - 2021-06-17 06:41:31 --> URI Class Initialized
INFO - 2021-06-17 06:41:31 --> Router Class Initialized
INFO - 2021-06-17 06:41:31 --> Output Class Initialized
INFO - 2021-06-17 06:41:31 --> Security Class Initialized
DEBUG - 2021-06-17 06:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:41:31 --> Input Class Initialized
INFO - 2021-06-17 06:41:31 --> Language Class Initialized
INFO - 2021-06-17 06:41:31 --> Language Class Initialized
INFO - 2021-06-17 06:41:31 --> Config Class Initialized
INFO - 2021-06-17 06:41:31 --> Loader Class Initialized
INFO - 2021-06-17 06:41:31 --> Helper loaded: url_helper
INFO - 2021-06-17 06:41:31 --> Helper loaded: file_helper
INFO - 2021-06-17 06:41:31 --> Helper loaded: form_helper
INFO - 2021-06-17 06:41:31 --> Helper loaded: my_helper
INFO - 2021-06-17 06:41:31 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:41:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:41:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:41:31 --> Controller Class Initialized
INFO - 2021-06-17 06:41:31 --> Final output sent to browser
DEBUG - 2021-06-17 06:41:31 --> Total execution time: 0.0389
INFO - 2021-06-17 06:41:39 --> Config Class Initialized
INFO - 2021-06-17 06:41:39 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:41:39 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:41:39 --> Utf8 Class Initialized
INFO - 2021-06-17 06:41:39 --> URI Class Initialized
INFO - 2021-06-17 06:41:39 --> Router Class Initialized
INFO - 2021-06-17 06:41:39 --> Output Class Initialized
INFO - 2021-06-17 06:41:39 --> Security Class Initialized
DEBUG - 2021-06-17 06:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:41:39 --> Input Class Initialized
INFO - 2021-06-17 06:41:39 --> Language Class Initialized
INFO - 2021-06-17 06:41:39 --> Language Class Initialized
INFO - 2021-06-17 06:41:39 --> Config Class Initialized
INFO - 2021-06-17 06:41:39 --> Loader Class Initialized
INFO - 2021-06-17 06:41:39 --> Helper loaded: url_helper
INFO - 2021-06-17 06:41:39 --> Helper loaded: file_helper
INFO - 2021-06-17 06:41:39 --> Helper loaded: form_helper
INFO - 2021-06-17 06:41:39 --> Helper loaded: my_helper
INFO - 2021-06-17 06:41:39 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:41:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:41:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:41:39 --> Controller Class Initialized
INFO - 2021-06-17 06:41:39 --> Final output sent to browser
DEBUG - 2021-06-17 06:41:39 --> Total execution time: 0.0397
INFO - 2021-06-17 06:41:39 --> Config Class Initialized
INFO - 2021-06-17 06:41:39 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:41:39 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:41:39 --> Utf8 Class Initialized
INFO - 2021-06-17 06:41:39 --> URI Class Initialized
INFO - 2021-06-17 06:41:39 --> Router Class Initialized
INFO - 2021-06-17 06:41:39 --> Output Class Initialized
INFO - 2021-06-17 06:41:39 --> Security Class Initialized
DEBUG - 2021-06-17 06:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:41:39 --> Input Class Initialized
INFO - 2021-06-17 06:41:39 --> Language Class Initialized
INFO - 2021-06-17 06:41:39 --> Language Class Initialized
INFO - 2021-06-17 06:41:39 --> Config Class Initialized
INFO - 2021-06-17 06:41:39 --> Loader Class Initialized
INFO - 2021-06-17 06:41:39 --> Helper loaded: url_helper
INFO - 2021-06-17 06:41:39 --> Helper loaded: file_helper
INFO - 2021-06-17 06:41:39 --> Helper loaded: form_helper
INFO - 2021-06-17 06:41:39 --> Helper loaded: my_helper
INFO - 2021-06-17 06:41:39 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:41:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:41:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:41:39 --> Controller Class Initialized
INFO - 2021-06-17 06:41:41 --> Config Class Initialized
INFO - 2021-06-17 06:41:41 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:41:41 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:41:41 --> Utf8 Class Initialized
INFO - 2021-06-17 06:41:41 --> URI Class Initialized
INFO - 2021-06-17 06:41:41 --> Router Class Initialized
INFO - 2021-06-17 06:41:41 --> Output Class Initialized
INFO - 2021-06-17 06:41:41 --> Security Class Initialized
DEBUG - 2021-06-17 06:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:41:41 --> Input Class Initialized
INFO - 2021-06-17 06:41:41 --> Language Class Initialized
INFO - 2021-06-17 06:41:41 --> Language Class Initialized
INFO - 2021-06-17 06:41:41 --> Config Class Initialized
INFO - 2021-06-17 06:41:41 --> Loader Class Initialized
INFO - 2021-06-17 06:41:41 --> Helper loaded: url_helper
INFO - 2021-06-17 06:41:41 --> Helper loaded: file_helper
INFO - 2021-06-17 06:41:41 --> Helper loaded: form_helper
INFO - 2021-06-17 06:41:41 --> Helper loaded: my_helper
INFO - 2021-06-17 06:41:41 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:41:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:41:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:41:41 --> Controller Class Initialized
INFO - 2021-06-17 06:41:41 --> Final output sent to browser
DEBUG - 2021-06-17 06:41:41 --> Total execution time: 0.0404
INFO - 2021-06-17 06:41:51 --> Config Class Initialized
INFO - 2021-06-17 06:41:51 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:41:51 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:41:51 --> Utf8 Class Initialized
INFO - 2021-06-17 06:41:51 --> URI Class Initialized
INFO - 2021-06-17 06:41:51 --> Router Class Initialized
INFO - 2021-06-17 06:41:51 --> Output Class Initialized
INFO - 2021-06-17 06:41:51 --> Security Class Initialized
DEBUG - 2021-06-17 06:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:41:51 --> Input Class Initialized
INFO - 2021-06-17 06:41:51 --> Language Class Initialized
INFO - 2021-06-17 06:41:51 --> Language Class Initialized
INFO - 2021-06-17 06:41:51 --> Config Class Initialized
INFO - 2021-06-17 06:41:51 --> Loader Class Initialized
INFO - 2021-06-17 06:41:51 --> Helper loaded: url_helper
INFO - 2021-06-17 06:41:51 --> Helper loaded: file_helper
INFO - 2021-06-17 06:41:51 --> Helper loaded: form_helper
INFO - 2021-06-17 06:41:51 --> Helper loaded: my_helper
INFO - 2021-06-17 06:41:51 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:41:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:41:51 --> Controller Class Initialized
INFO - 2021-06-17 06:41:51 --> Final output sent to browser
DEBUG - 2021-06-17 06:41:51 --> Total execution time: 0.0502
INFO - 2021-06-17 06:41:51 --> Config Class Initialized
INFO - 2021-06-17 06:41:51 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:41:51 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:41:51 --> Utf8 Class Initialized
INFO - 2021-06-17 06:41:51 --> URI Class Initialized
INFO - 2021-06-17 06:41:51 --> Router Class Initialized
INFO - 2021-06-17 06:41:51 --> Output Class Initialized
INFO - 2021-06-17 06:41:51 --> Security Class Initialized
DEBUG - 2021-06-17 06:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:41:51 --> Input Class Initialized
INFO - 2021-06-17 06:41:51 --> Language Class Initialized
INFO - 2021-06-17 06:41:51 --> Language Class Initialized
INFO - 2021-06-17 06:41:51 --> Config Class Initialized
INFO - 2021-06-17 06:41:51 --> Loader Class Initialized
INFO - 2021-06-17 06:41:51 --> Helper loaded: url_helper
INFO - 2021-06-17 06:41:51 --> Helper loaded: file_helper
INFO - 2021-06-17 06:41:51 --> Helper loaded: form_helper
INFO - 2021-06-17 06:41:51 --> Helper loaded: my_helper
INFO - 2021-06-17 06:41:51 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:41:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:41:51 --> Controller Class Initialized
INFO - 2021-06-17 06:41:58 --> Config Class Initialized
INFO - 2021-06-17 06:41:58 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:41:58 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:41:58 --> Utf8 Class Initialized
INFO - 2021-06-17 06:41:58 --> URI Class Initialized
INFO - 2021-06-17 06:41:58 --> Router Class Initialized
INFO - 2021-06-17 06:41:58 --> Output Class Initialized
INFO - 2021-06-17 06:41:58 --> Security Class Initialized
DEBUG - 2021-06-17 06:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:41:58 --> Input Class Initialized
INFO - 2021-06-17 06:41:58 --> Language Class Initialized
INFO - 2021-06-17 06:41:58 --> Language Class Initialized
INFO - 2021-06-17 06:41:58 --> Config Class Initialized
INFO - 2021-06-17 06:41:58 --> Loader Class Initialized
INFO - 2021-06-17 06:41:58 --> Helper loaded: url_helper
INFO - 2021-06-17 06:41:58 --> Helper loaded: file_helper
INFO - 2021-06-17 06:41:58 --> Helper loaded: form_helper
INFO - 2021-06-17 06:41:58 --> Helper loaded: my_helper
INFO - 2021-06-17 06:41:58 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:41:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:41:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:41:58 --> Controller Class Initialized
INFO - 2021-06-17 06:41:58 --> Final output sent to browser
DEBUG - 2021-06-17 06:41:58 --> Total execution time: 0.0493
INFO - 2021-06-17 06:42:01 --> Config Class Initialized
INFO - 2021-06-17 06:42:01 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:42:01 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:42:01 --> Utf8 Class Initialized
INFO - 2021-06-17 06:42:01 --> URI Class Initialized
INFO - 2021-06-17 06:42:01 --> Router Class Initialized
INFO - 2021-06-17 06:42:01 --> Output Class Initialized
INFO - 2021-06-17 06:42:01 --> Security Class Initialized
DEBUG - 2021-06-17 06:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:42:01 --> Input Class Initialized
INFO - 2021-06-17 06:42:01 --> Language Class Initialized
INFO - 2021-06-17 06:42:01 --> Language Class Initialized
INFO - 2021-06-17 06:42:01 --> Config Class Initialized
INFO - 2021-06-17 06:42:01 --> Loader Class Initialized
INFO - 2021-06-17 06:42:01 --> Helper loaded: url_helper
INFO - 2021-06-17 06:42:01 --> Helper loaded: file_helper
INFO - 2021-06-17 06:42:01 --> Helper loaded: form_helper
INFO - 2021-06-17 06:42:01 --> Helper loaded: my_helper
INFO - 2021-06-17 06:42:01 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:42:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:42:01 --> Controller Class Initialized
INFO - 2021-06-17 06:42:01 --> Final output sent to browser
DEBUG - 2021-06-17 06:42:01 --> Total execution time: 0.0491
INFO - 2021-06-17 06:42:01 --> Config Class Initialized
INFO - 2021-06-17 06:42:01 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:42:01 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:42:01 --> Utf8 Class Initialized
INFO - 2021-06-17 06:42:01 --> URI Class Initialized
INFO - 2021-06-17 06:42:01 --> Router Class Initialized
INFO - 2021-06-17 06:42:01 --> Output Class Initialized
INFO - 2021-06-17 06:42:01 --> Security Class Initialized
DEBUG - 2021-06-17 06:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:42:01 --> Input Class Initialized
INFO - 2021-06-17 06:42:01 --> Language Class Initialized
INFO - 2021-06-17 06:42:01 --> Language Class Initialized
INFO - 2021-06-17 06:42:01 --> Config Class Initialized
INFO - 2021-06-17 06:42:01 --> Loader Class Initialized
INFO - 2021-06-17 06:42:01 --> Helper loaded: url_helper
INFO - 2021-06-17 06:42:01 --> Helper loaded: file_helper
INFO - 2021-06-17 06:42:01 --> Helper loaded: form_helper
INFO - 2021-06-17 06:42:01 --> Helper loaded: my_helper
INFO - 2021-06-17 06:42:01 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:42:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:42:01 --> Controller Class Initialized
INFO - 2021-06-17 06:42:06 --> Config Class Initialized
INFO - 2021-06-17 06:42:06 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:42:06 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:42:06 --> Utf8 Class Initialized
INFO - 2021-06-17 06:42:06 --> URI Class Initialized
INFO - 2021-06-17 06:42:06 --> Router Class Initialized
INFO - 2021-06-17 06:42:06 --> Output Class Initialized
INFO - 2021-06-17 06:42:06 --> Security Class Initialized
DEBUG - 2021-06-17 06:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:42:06 --> Input Class Initialized
INFO - 2021-06-17 06:42:06 --> Language Class Initialized
INFO - 2021-06-17 06:42:06 --> Language Class Initialized
INFO - 2021-06-17 06:42:06 --> Config Class Initialized
INFO - 2021-06-17 06:42:06 --> Loader Class Initialized
INFO - 2021-06-17 06:42:06 --> Helper loaded: url_helper
INFO - 2021-06-17 06:42:06 --> Helper loaded: file_helper
INFO - 2021-06-17 06:42:06 --> Helper loaded: form_helper
INFO - 2021-06-17 06:42:06 --> Helper loaded: my_helper
INFO - 2021-06-17 06:42:06 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:42:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:42:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:42:06 --> Controller Class Initialized
DEBUG - 2021-06-17 06:42:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-17 06:42:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:42:06 --> Final output sent to browser
DEBUG - 2021-06-17 06:42:06 --> Total execution time: 0.0413
INFO - 2021-06-17 06:42:08 --> Config Class Initialized
INFO - 2021-06-17 06:42:08 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:42:08 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:42:08 --> Utf8 Class Initialized
INFO - 2021-06-17 06:42:08 --> URI Class Initialized
INFO - 2021-06-17 06:42:08 --> Router Class Initialized
INFO - 2021-06-17 06:42:08 --> Output Class Initialized
INFO - 2021-06-17 06:42:08 --> Security Class Initialized
DEBUG - 2021-06-17 06:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:42:08 --> Input Class Initialized
INFO - 2021-06-17 06:42:08 --> Language Class Initialized
INFO - 2021-06-17 06:42:08 --> Language Class Initialized
INFO - 2021-06-17 06:42:08 --> Config Class Initialized
INFO - 2021-06-17 06:42:08 --> Loader Class Initialized
INFO - 2021-06-17 06:42:08 --> Helper loaded: url_helper
INFO - 2021-06-17 06:42:08 --> Helper loaded: file_helper
INFO - 2021-06-17 06:42:08 --> Helper loaded: form_helper
INFO - 2021-06-17 06:42:08 --> Helper loaded: my_helper
INFO - 2021-06-17 06:42:08 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:42:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:42:08 --> Controller Class Initialized
DEBUG - 2021-06-17 06:42:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 06:42:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:42:08 --> Final output sent to browser
DEBUG - 2021-06-17 06:42:08 --> Total execution time: 0.0408
INFO - 2021-06-17 06:42:09 --> Config Class Initialized
INFO - 2021-06-17 06:42:09 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:42:09 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:42:09 --> Utf8 Class Initialized
INFO - 2021-06-17 06:42:09 --> URI Class Initialized
INFO - 2021-06-17 06:42:09 --> Router Class Initialized
INFO - 2021-06-17 06:42:09 --> Output Class Initialized
INFO - 2021-06-17 06:42:09 --> Security Class Initialized
DEBUG - 2021-06-17 06:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:42:09 --> Input Class Initialized
INFO - 2021-06-17 06:42:09 --> Language Class Initialized
INFO - 2021-06-17 06:42:09 --> Language Class Initialized
INFO - 2021-06-17 06:42:09 --> Config Class Initialized
INFO - 2021-06-17 06:42:09 --> Loader Class Initialized
INFO - 2021-06-17 06:42:09 --> Helper loaded: url_helper
INFO - 2021-06-17 06:42:09 --> Helper loaded: file_helper
INFO - 2021-06-17 06:42:09 --> Helper loaded: form_helper
INFO - 2021-06-17 06:42:09 --> Helper loaded: my_helper
INFO - 2021-06-17 06:42:09 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:42:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:42:09 --> Controller Class Initialized
INFO - 2021-06-17 06:42:09 --> Final output sent to browser
DEBUG - 2021-06-17 06:42:09 --> Total execution time: 0.0511
INFO - 2021-06-17 06:42:22 --> Config Class Initialized
INFO - 2021-06-17 06:42:22 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:42:22 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:42:22 --> Utf8 Class Initialized
INFO - 2021-06-17 06:42:22 --> URI Class Initialized
INFO - 2021-06-17 06:42:22 --> Router Class Initialized
INFO - 2021-06-17 06:42:22 --> Output Class Initialized
INFO - 2021-06-17 06:42:22 --> Security Class Initialized
DEBUG - 2021-06-17 06:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:42:22 --> Input Class Initialized
INFO - 2021-06-17 06:42:22 --> Language Class Initialized
INFO - 2021-06-17 06:42:22 --> Language Class Initialized
INFO - 2021-06-17 06:42:22 --> Config Class Initialized
INFO - 2021-06-17 06:42:22 --> Loader Class Initialized
INFO - 2021-06-17 06:42:22 --> Helper loaded: url_helper
INFO - 2021-06-17 06:42:22 --> Helper loaded: file_helper
INFO - 2021-06-17 06:42:22 --> Helper loaded: form_helper
INFO - 2021-06-17 06:42:22 --> Helper loaded: my_helper
INFO - 2021-06-17 06:42:22 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:42:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:42:22 --> Controller Class Initialized
INFO - 2021-06-17 06:42:22 --> Final output sent to browser
DEBUG - 2021-06-17 06:42:22 --> Total execution time: 0.0510
INFO - 2021-06-17 06:42:22 --> Config Class Initialized
INFO - 2021-06-17 06:42:22 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:42:22 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:42:22 --> Utf8 Class Initialized
INFO - 2021-06-17 06:42:22 --> URI Class Initialized
INFO - 2021-06-17 06:42:22 --> Router Class Initialized
INFO - 2021-06-17 06:42:22 --> Output Class Initialized
INFO - 2021-06-17 06:42:22 --> Security Class Initialized
DEBUG - 2021-06-17 06:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:42:22 --> Input Class Initialized
INFO - 2021-06-17 06:42:22 --> Language Class Initialized
INFO - 2021-06-17 06:42:22 --> Language Class Initialized
INFO - 2021-06-17 06:42:22 --> Config Class Initialized
INFO - 2021-06-17 06:42:22 --> Loader Class Initialized
INFO - 2021-06-17 06:42:22 --> Helper loaded: url_helper
INFO - 2021-06-17 06:42:22 --> Helper loaded: file_helper
INFO - 2021-06-17 06:42:22 --> Helper loaded: form_helper
INFO - 2021-06-17 06:42:22 --> Helper loaded: my_helper
INFO - 2021-06-17 06:42:22 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:42:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:42:22 --> Controller Class Initialized
DEBUG - 2021-06-17 06:42:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 06:42:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:42:22 --> Final output sent to browser
DEBUG - 2021-06-17 06:42:22 --> Total execution time: 0.0514
INFO - 2021-06-17 06:42:24 --> Config Class Initialized
INFO - 2021-06-17 06:42:24 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:42:24 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:42:24 --> Utf8 Class Initialized
INFO - 2021-06-17 06:42:24 --> URI Class Initialized
INFO - 2021-06-17 06:42:24 --> Router Class Initialized
INFO - 2021-06-17 06:42:24 --> Output Class Initialized
INFO - 2021-06-17 06:42:24 --> Security Class Initialized
DEBUG - 2021-06-17 06:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:42:24 --> Input Class Initialized
INFO - 2021-06-17 06:42:24 --> Language Class Initialized
INFO - 2021-06-17 06:42:24 --> Language Class Initialized
INFO - 2021-06-17 06:42:24 --> Config Class Initialized
INFO - 2021-06-17 06:42:24 --> Loader Class Initialized
INFO - 2021-06-17 06:42:24 --> Helper loaded: url_helper
INFO - 2021-06-17 06:42:24 --> Helper loaded: file_helper
INFO - 2021-06-17 06:42:24 --> Helper loaded: form_helper
INFO - 2021-06-17 06:42:24 --> Helper loaded: my_helper
INFO - 2021-06-17 06:42:24 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:42:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:42:24 --> Controller Class Initialized
INFO - 2021-06-17 06:42:24 --> Final output sent to browser
DEBUG - 2021-06-17 06:42:24 --> Total execution time: 0.0488
INFO - 2021-06-17 06:42:32 --> Config Class Initialized
INFO - 2021-06-17 06:42:32 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:42:32 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:42:32 --> Utf8 Class Initialized
INFO - 2021-06-17 06:42:32 --> URI Class Initialized
INFO - 2021-06-17 06:42:32 --> Router Class Initialized
INFO - 2021-06-17 06:42:32 --> Output Class Initialized
INFO - 2021-06-17 06:42:32 --> Security Class Initialized
DEBUG - 2021-06-17 06:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:42:32 --> Input Class Initialized
INFO - 2021-06-17 06:42:32 --> Language Class Initialized
INFO - 2021-06-17 06:42:32 --> Language Class Initialized
INFO - 2021-06-17 06:42:32 --> Config Class Initialized
INFO - 2021-06-17 06:42:32 --> Loader Class Initialized
INFO - 2021-06-17 06:42:32 --> Helper loaded: url_helper
INFO - 2021-06-17 06:42:32 --> Helper loaded: file_helper
INFO - 2021-06-17 06:42:32 --> Helper loaded: form_helper
INFO - 2021-06-17 06:42:32 --> Helper loaded: my_helper
INFO - 2021-06-17 06:42:32 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:42:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:42:32 --> Controller Class Initialized
INFO - 2021-06-17 06:42:32 --> Final output sent to browser
DEBUG - 2021-06-17 06:42:32 --> Total execution time: 0.0503
INFO - 2021-06-17 06:42:32 --> Config Class Initialized
INFO - 2021-06-17 06:42:32 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:42:32 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:42:32 --> Utf8 Class Initialized
INFO - 2021-06-17 06:42:32 --> URI Class Initialized
INFO - 2021-06-17 06:42:32 --> Router Class Initialized
INFO - 2021-06-17 06:42:32 --> Output Class Initialized
INFO - 2021-06-17 06:42:32 --> Security Class Initialized
DEBUG - 2021-06-17 06:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:42:32 --> Input Class Initialized
INFO - 2021-06-17 06:42:32 --> Language Class Initialized
INFO - 2021-06-17 06:42:32 --> Language Class Initialized
INFO - 2021-06-17 06:42:32 --> Config Class Initialized
INFO - 2021-06-17 06:42:32 --> Loader Class Initialized
INFO - 2021-06-17 06:42:32 --> Helper loaded: url_helper
INFO - 2021-06-17 06:42:32 --> Helper loaded: file_helper
INFO - 2021-06-17 06:42:32 --> Helper loaded: form_helper
INFO - 2021-06-17 06:42:32 --> Helper loaded: my_helper
INFO - 2021-06-17 06:42:32 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:42:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:42:32 --> Controller Class Initialized
DEBUG - 2021-06-17 06:42:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 06:42:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:42:32 --> Final output sent to browser
DEBUG - 2021-06-17 06:42:32 --> Total execution time: 0.0414
INFO - 2021-06-17 06:42:33 --> Config Class Initialized
INFO - 2021-06-17 06:42:33 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:42:33 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:42:33 --> Utf8 Class Initialized
INFO - 2021-06-17 06:42:33 --> URI Class Initialized
INFO - 2021-06-17 06:42:33 --> Router Class Initialized
INFO - 2021-06-17 06:42:33 --> Output Class Initialized
INFO - 2021-06-17 06:42:33 --> Security Class Initialized
DEBUG - 2021-06-17 06:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:42:33 --> Input Class Initialized
INFO - 2021-06-17 06:42:33 --> Language Class Initialized
INFO - 2021-06-17 06:42:33 --> Language Class Initialized
INFO - 2021-06-17 06:42:33 --> Config Class Initialized
INFO - 2021-06-17 06:42:33 --> Loader Class Initialized
INFO - 2021-06-17 06:42:33 --> Helper loaded: url_helper
INFO - 2021-06-17 06:42:33 --> Helper loaded: file_helper
INFO - 2021-06-17 06:42:33 --> Helper loaded: form_helper
INFO - 2021-06-17 06:42:33 --> Helper loaded: my_helper
INFO - 2021-06-17 06:42:33 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:42:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:42:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:42:33 --> Controller Class Initialized
INFO - 2021-06-17 06:42:33 --> Final output sent to browser
DEBUG - 2021-06-17 06:42:33 --> Total execution time: 0.0495
INFO - 2021-06-17 06:42:41 --> Config Class Initialized
INFO - 2021-06-17 06:42:41 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:42:41 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:42:41 --> Utf8 Class Initialized
INFO - 2021-06-17 06:42:41 --> URI Class Initialized
INFO - 2021-06-17 06:42:41 --> Router Class Initialized
INFO - 2021-06-17 06:42:41 --> Output Class Initialized
INFO - 2021-06-17 06:42:41 --> Security Class Initialized
DEBUG - 2021-06-17 06:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:42:41 --> Input Class Initialized
INFO - 2021-06-17 06:42:41 --> Language Class Initialized
INFO - 2021-06-17 06:42:41 --> Language Class Initialized
INFO - 2021-06-17 06:42:41 --> Config Class Initialized
INFO - 2021-06-17 06:42:41 --> Loader Class Initialized
INFO - 2021-06-17 06:42:41 --> Helper loaded: url_helper
INFO - 2021-06-17 06:42:41 --> Helper loaded: file_helper
INFO - 2021-06-17 06:42:41 --> Helper loaded: form_helper
INFO - 2021-06-17 06:42:41 --> Helper loaded: my_helper
INFO - 2021-06-17 06:42:41 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:42:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:42:41 --> Controller Class Initialized
INFO - 2021-06-17 06:42:41 --> Final output sent to browser
DEBUG - 2021-06-17 06:42:41 --> Total execution time: 0.0499
INFO - 2021-06-17 06:42:41 --> Config Class Initialized
INFO - 2021-06-17 06:42:41 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:42:41 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:42:41 --> Utf8 Class Initialized
INFO - 2021-06-17 06:42:41 --> URI Class Initialized
INFO - 2021-06-17 06:42:41 --> Router Class Initialized
INFO - 2021-06-17 06:42:41 --> Output Class Initialized
INFO - 2021-06-17 06:42:41 --> Security Class Initialized
DEBUG - 2021-06-17 06:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:42:41 --> Input Class Initialized
INFO - 2021-06-17 06:42:41 --> Language Class Initialized
INFO - 2021-06-17 06:42:41 --> Language Class Initialized
INFO - 2021-06-17 06:42:41 --> Config Class Initialized
INFO - 2021-06-17 06:42:41 --> Loader Class Initialized
INFO - 2021-06-17 06:42:41 --> Helper loaded: url_helper
INFO - 2021-06-17 06:42:41 --> Helper loaded: file_helper
INFO - 2021-06-17 06:42:41 --> Helper loaded: form_helper
INFO - 2021-06-17 06:42:41 --> Helper loaded: my_helper
INFO - 2021-06-17 06:42:41 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:42:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:42:41 --> Controller Class Initialized
DEBUG - 2021-06-17 06:42:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 06:42:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:42:41 --> Final output sent to browser
DEBUG - 2021-06-17 06:42:41 --> Total execution time: 0.0416
INFO - 2021-06-17 06:42:44 --> Config Class Initialized
INFO - 2021-06-17 06:42:44 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:42:44 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:42:44 --> Utf8 Class Initialized
INFO - 2021-06-17 06:42:44 --> URI Class Initialized
INFO - 2021-06-17 06:42:44 --> Router Class Initialized
INFO - 2021-06-17 06:42:44 --> Output Class Initialized
INFO - 2021-06-17 06:42:44 --> Security Class Initialized
DEBUG - 2021-06-17 06:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:42:44 --> Input Class Initialized
INFO - 2021-06-17 06:42:44 --> Language Class Initialized
INFO - 2021-06-17 06:42:44 --> Language Class Initialized
INFO - 2021-06-17 06:42:44 --> Config Class Initialized
INFO - 2021-06-17 06:42:44 --> Loader Class Initialized
INFO - 2021-06-17 06:42:44 --> Helper loaded: url_helper
INFO - 2021-06-17 06:42:44 --> Helper loaded: file_helper
INFO - 2021-06-17 06:42:44 --> Helper loaded: form_helper
INFO - 2021-06-17 06:42:44 --> Helper loaded: my_helper
INFO - 2021-06-17 06:42:44 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:42:44 --> Controller Class Initialized
INFO - 2021-06-17 06:42:44 --> Final output sent to browser
DEBUG - 2021-06-17 06:42:44 --> Total execution time: 0.0399
INFO - 2021-06-17 06:42:51 --> Config Class Initialized
INFO - 2021-06-17 06:42:51 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:42:51 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:42:51 --> Utf8 Class Initialized
INFO - 2021-06-17 06:42:51 --> URI Class Initialized
INFO - 2021-06-17 06:42:51 --> Router Class Initialized
INFO - 2021-06-17 06:42:51 --> Output Class Initialized
INFO - 2021-06-17 06:42:51 --> Security Class Initialized
DEBUG - 2021-06-17 06:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:42:51 --> Input Class Initialized
INFO - 2021-06-17 06:42:51 --> Language Class Initialized
INFO - 2021-06-17 06:42:51 --> Language Class Initialized
INFO - 2021-06-17 06:42:51 --> Config Class Initialized
INFO - 2021-06-17 06:42:51 --> Loader Class Initialized
INFO - 2021-06-17 06:42:51 --> Helper loaded: url_helper
INFO - 2021-06-17 06:42:51 --> Helper loaded: file_helper
INFO - 2021-06-17 06:42:51 --> Helper loaded: form_helper
INFO - 2021-06-17 06:42:51 --> Helper loaded: my_helper
INFO - 2021-06-17 06:42:51 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:42:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:42:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:42:51 --> Controller Class Initialized
INFO - 2021-06-17 06:42:51 --> Final output sent to browser
DEBUG - 2021-06-17 06:42:51 --> Total execution time: 0.0492
INFO - 2021-06-17 06:42:51 --> Config Class Initialized
INFO - 2021-06-17 06:42:51 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:42:51 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:42:51 --> Utf8 Class Initialized
INFO - 2021-06-17 06:42:51 --> URI Class Initialized
INFO - 2021-06-17 06:42:51 --> Router Class Initialized
INFO - 2021-06-17 06:42:51 --> Output Class Initialized
INFO - 2021-06-17 06:42:51 --> Security Class Initialized
DEBUG - 2021-06-17 06:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:42:51 --> Input Class Initialized
INFO - 2021-06-17 06:42:51 --> Language Class Initialized
INFO - 2021-06-17 06:42:51 --> Language Class Initialized
INFO - 2021-06-17 06:42:51 --> Config Class Initialized
INFO - 2021-06-17 06:42:51 --> Loader Class Initialized
INFO - 2021-06-17 06:42:51 --> Helper loaded: url_helper
INFO - 2021-06-17 06:42:51 --> Helper loaded: file_helper
INFO - 2021-06-17 06:42:51 --> Helper loaded: form_helper
INFO - 2021-06-17 06:42:51 --> Helper loaded: my_helper
INFO - 2021-06-17 06:42:51 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:42:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:42:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:42:51 --> Controller Class Initialized
DEBUG - 2021-06-17 06:42:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 06:42:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:42:51 --> Final output sent to browser
DEBUG - 2021-06-17 06:42:51 --> Total execution time: 0.0422
INFO - 2021-06-17 06:43:00 --> Config Class Initialized
INFO - 2021-06-17 06:43:00 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:43:00 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:43:00 --> Utf8 Class Initialized
INFO - 2021-06-17 06:43:00 --> URI Class Initialized
INFO - 2021-06-17 06:43:00 --> Router Class Initialized
INFO - 2021-06-17 06:43:00 --> Output Class Initialized
INFO - 2021-06-17 06:43:00 --> Security Class Initialized
DEBUG - 2021-06-17 06:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:43:00 --> Input Class Initialized
INFO - 2021-06-17 06:43:00 --> Language Class Initialized
INFO - 2021-06-17 06:43:00 --> Language Class Initialized
INFO - 2021-06-17 06:43:00 --> Config Class Initialized
INFO - 2021-06-17 06:43:00 --> Loader Class Initialized
INFO - 2021-06-17 06:43:00 --> Helper loaded: url_helper
INFO - 2021-06-17 06:43:00 --> Helper loaded: file_helper
INFO - 2021-06-17 06:43:00 --> Helper loaded: form_helper
INFO - 2021-06-17 06:43:00 --> Helper loaded: my_helper
INFO - 2021-06-17 06:43:00 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:43:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:43:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:43:00 --> Controller Class Initialized
INFO - 2021-06-17 06:43:00 --> Final output sent to browser
DEBUG - 2021-06-17 06:43:00 --> Total execution time: 0.0399
INFO - 2021-06-17 06:43:03 --> Config Class Initialized
INFO - 2021-06-17 06:43:03 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:43:03 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:43:03 --> Utf8 Class Initialized
INFO - 2021-06-17 06:43:03 --> URI Class Initialized
INFO - 2021-06-17 06:43:03 --> Router Class Initialized
INFO - 2021-06-17 06:43:03 --> Output Class Initialized
INFO - 2021-06-17 06:43:03 --> Security Class Initialized
DEBUG - 2021-06-17 06:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:43:03 --> Input Class Initialized
INFO - 2021-06-17 06:43:03 --> Language Class Initialized
INFO - 2021-06-17 06:43:03 --> Language Class Initialized
INFO - 2021-06-17 06:43:03 --> Config Class Initialized
INFO - 2021-06-17 06:43:03 --> Loader Class Initialized
INFO - 2021-06-17 06:43:03 --> Helper loaded: url_helper
INFO - 2021-06-17 06:43:03 --> Helper loaded: file_helper
INFO - 2021-06-17 06:43:03 --> Helper loaded: form_helper
INFO - 2021-06-17 06:43:03 --> Helper loaded: my_helper
INFO - 2021-06-17 06:43:03 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:43:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:43:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:43:03 --> Controller Class Initialized
INFO - 2021-06-17 06:43:03 --> Final output sent to browser
DEBUG - 2021-06-17 06:43:03 --> Total execution time: 0.0492
INFO - 2021-06-17 06:43:03 --> Config Class Initialized
INFO - 2021-06-17 06:43:03 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:43:03 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:43:03 --> Utf8 Class Initialized
INFO - 2021-06-17 06:43:03 --> URI Class Initialized
INFO - 2021-06-17 06:43:03 --> Router Class Initialized
INFO - 2021-06-17 06:43:03 --> Output Class Initialized
INFO - 2021-06-17 06:43:03 --> Security Class Initialized
DEBUG - 2021-06-17 06:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:43:03 --> Input Class Initialized
INFO - 2021-06-17 06:43:03 --> Language Class Initialized
INFO - 2021-06-17 06:43:03 --> Language Class Initialized
INFO - 2021-06-17 06:43:03 --> Config Class Initialized
INFO - 2021-06-17 06:43:03 --> Loader Class Initialized
INFO - 2021-06-17 06:43:03 --> Helper loaded: url_helper
INFO - 2021-06-17 06:43:03 --> Helper loaded: file_helper
INFO - 2021-06-17 06:43:03 --> Helper loaded: form_helper
INFO - 2021-06-17 06:43:03 --> Helper loaded: my_helper
INFO - 2021-06-17 06:43:03 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:43:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:43:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:43:03 --> Controller Class Initialized
DEBUG - 2021-06-17 06:43:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 06:43:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:43:03 --> Final output sent to browser
DEBUG - 2021-06-17 06:43:03 --> Total execution time: 0.0432
INFO - 2021-06-17 06:43:09 --> Config Class Initialized
INFO - 2021-06-17 06:43:09 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:43:09 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:43:09 --> Utf8 Class Initialized
INFO - 2021-06-17 06:43:09 --> URI Class Initialized
INFO - 2021-06-17 06:43:09 --> Router Class Initialized
INFO - 2021-06-17 06:43:09 --> Output Class Initialized
INFO - 2021-06-17 06:43:09 --> Security Class Initialized
DEBUG - 2021-06-17 06:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:43:09 --> Input Class Initialized
INFO - 2021-06-17 06:43:09 --> Language Class Initialized
INFO - 2021-06-17 06:43:09 --> Language Class Initialized
INFO - 2021-06-17 06:43:09 --> Config Class Initialized
INFO - 2021-06-17 06:43:09 --> Loader Class Initialized
INFO - 2021-06-17 06:43:09 --> Helper loaded: url_helper
INFO - 2021-06-17 06:43:09 --> Helper loaded: file_helper
INFO - 2021-06-17 06:43:09 --> Helper loaded: form_helper
INFO - 2021-06-17 06:43:09 --> Helper loaded: my_helper
INFO - 2021-06-17 06:43:09 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:43:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:43:09 --> Controller Class Initialized
INFO - 2021-06-17 06:43:09 --> Final output sent to browser
DEBUG - 2021-06-17 06:43:09 --> Total execution time: 0.0489
INFO - 2021-06-17 06:43:13 --> Config Class Initialized
INFO - 2021-06-17 06:43:13 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:43:13 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:43:13 --> Utf8 Class Initialized
INFO - 2021-06-17 06:43:13 --> URI Class Initialized
INFO - 2021-06-17 06:43:13 --> Router Class Initialized
INFO - 2021-06-17 06:43:13 --> Output Class Initialized
INFO - 2021-06-17 06:43:13 --> Security Class Initialized
DEBUG - 2021-06-17 06:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:43:13 --> Input Class Initialized
INFO - 2021-06-17 06:43:13 --> Language Class Initialized
INFO - 2021-06-17 06:43:13 --> Language Class Initialized
INFO - 2021-06-17 06:43:13 --> Config Class Initialized
INFO - 2021-06-17 06:43:13 --> Loader Class Initialized
INFO - 2021-06-17 06:43:13 --> Helper loaded: url_helper
INFO - 2021-06-17 06:43:13 --> Helper loaded: file_helper
INFO - 2021-06-17 06:43:13 --> Helper loaded: form_helper
INFO - 2021-06-17 06:43:13 --> Helper loaded: my_helper
INFO - 2021-06-17 06:43:13 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:43:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:43:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:43:13 --> Controller Class Initialized
INFO - 2021-06-17 06:43:13 --> Final output sent to browser
DEBUG - 2021-06-17 06:43:13 --> Total execution time: 0.0399
INFO - 2021-06-17 06:43:13 --> Config Class Initialized
INFO - 2021-06-17 06:43:13 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:43:13 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:43:13 --> Utf8 Class Initialized
INFO - 2021-06-17 06:43:13 --> URI Class Initialized
INFO - 2021-06-17 06:43:13 --> Router Class Initialized
INFO - 2021-06-17 06:43:13 --> Output Class Initialized
INFO - 2021-06-17 06:43:13 --> Security Class Initialized
DEBUG - 2021-06-17 06:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:43:13 --> Input Class Initialized
INFO - 2021-06-17 06:43:13 --> Language Class Initialized
INFO - 2021-06-17 06:43:13 --> Language Class Initialized
INFO - 2021-06-17 06:43:13 --> Config Class Initialized
INFO - 2021-06-17 06:43:13 --> Loader Class Initialized
INFO - 2021-06-17 06:43:13 --> Helper loaded: url_helper
INFO - 2021-06-17 06:43:13 --> Helper loaded: file_helper
INFO - 2021-06-17 06:43:13 --> Helper loaded: form_helper
INFO - 2021-06-17 06:43:13 --> Helper loaded: my_helper
INFO - 2021-06-17 06:43:13 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:43:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:43:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:43:13 --> Controller Class Initialized
DEBUG - 2021-06-17 06:43:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 06:43:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:43:13 --> Final output sent to browser
DEBUG - 2021-06-17 06:43:13 --> Total execution time: 0.0510
INFO - 2021-06-17 06:43:20 --> Config Class Initialized
INFO - 2021-06-17 06:43:20 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:43:20 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:43:20 --> Utf8 Class Initialized
INFO - 2021-06-17 06:43:20 --> URI Class Initialized
INFO - 2021-06-17 06:43:20 --> Router Class Initialized
INFO - 2021-06-17 06:43:20 --> Output Class Initialized
INFO - 2021-06-17 06:43:20 --> Security Class Initialized
DEBUG - 2021-06-17 06:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:43:20 --> Input Class Initialized
INFO - 2021-06-17 06:43:20 --> Language Class Initialized
INFO - 2021-06-17 06:43:20 --> Language Class Initialized
INFO - 2021-06-17 06:43:20 --> Config Class Initialized
INFO - 2021-06-17 06:43:20 --> Loader Class Initialized
INFO - 2021-06-17 06:43:20 --> Helper loaded: url_helper
INFO - 2021-06-17 06:43:20 --> Helper loaded: file_helper
INFO - 2021-06-17 06:43:20 --> Helper loaded: form_helper
INFO - 2021-06-17 06:43:20 --> Helper loaded: my_helper
INFO - 2021-06-17 06:43:20 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:43:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:43:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:43:20 --> Controller Class Initialized
INFO - 2021-06-17 06:43:20 --> Final output sent to browser
DEBUG - 2021-06-17 06:43:20 --> Total execution time: 0.0400
INFO - 2021-06-17 06:43:24 --> Config Class Initialized
INFO - 2021-06-17 06:43:24 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:43:24 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:43:24 --> Utf8 Class Initialized
INFO - 2021-06-17 06:43:24 --> URI Class Initialized
INFO - 2021-06-17 06:43:24 --> Router Class Initialized
INFO - 2021-06-17 06:43:24 --> Output Class Initialized
INFO - 2021-06-17 06:43:24 --> Security Class Initialized
DEBUG - 2021-06-17 06:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:43:24 --> Input Class Initialized
INFO - 2021-06-17 06:43:24 --> Language Class Initialized
INFO - 2021-06-17 06:43:24 --> Language Class Initialized
INFO - 2021-06-17 06:43:24 --> Config Class Initialized
INFO - 2021-06-17 06:43:24 --> Loader Class Initialized
INFO - 2021-06-17 06:43:24 --> Helper loaded: url_helper
INFO - 2021-06-17 06:43:24 --> Helper loaded: file_helper
INFO - 2021-06-17 06:43:24 --> Helper loaded: form_helper
INFO - 2021-06-17 06:43:24 --> Helper loaded: my_helper
INFO - 2021-06-17 06:43:24 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:43:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:43:24 --> Controller Class Initialized
INFO - 2021-06-17 06:43:24 --> Final output sent to browser
DEBUG - 2021-06-17 06:43:24 --> Total execution time: 0.0497
INFO - 2021-06-17 06:43:24 --> Config Class Initialized
INFO - 2021-06-17 06:43:24 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:43:24 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:43:24 --> Utf8 Class Initialized
INFO - 2021-06-17 06:43:24 --> URI Class Initialized
INFO - 2021-06-17 06:43:24 --> Router Class Initialized
INFO - 2021-06-17 06:43:24 --> Output Class Initialized
INFO - 2021-06-17 06:43:24 --> Security Class Initialized
DEBUG - 2021-06-17 06:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:43:24 --> Input Class Initialized
INFO - 2021-06-17 06:43:24 --> Language Class Initialized
INFO - 2021-06-17 06:43:24 --> Language Class Initialized
INFO - 2021-06-17 06:43:24 --> Config Class Initialized
INFO - 2021-06-17 06:43:24 --> Loader Class Initialized
INFO - 2021-06-17 06:43:24 --> Helper loaded: url_helper
INFO - 2021-06-17 06:43:24 --> Helper loaded: file_helper
INFO - 2021-06-17 06:43:24 --> Helper loaded: form_helper
INFO - 2021-06-17 06:43:24 --> Helper loaded: my_helper
INFO - 2021-06-17 06:43:24 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:43:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:43:24 --> Controller Class Initialized
DEBUG - 2021-06-17 06:43:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 06:43:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:43:24 --> Final output sent to browser
DEBUG - 2021-06-17 06:43:24 --> Total execution time: 0.0420
INFO - 2021-06-17 06:43:29 --> Config Class Initialized
INFO - 2021-06-17 06:43:29 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:43:29 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:43:29 --> Utf8 Class Initialized
INFO - 2021-06-17 06:43:29 --> URI Class Initialized
INFO - 2021-06-17 06:43:29 --> Router Class Initialized
INFO - 2021-06-17 06:43:29 --> Output Class Initialized
INFO - 2021-06-17 06:43:29 --> Security Class Initialized
DEBUG - 2021-06-17 06:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:43:29 --> Input Class Initialized
INFO - 2021-06-17 06:43:29 --> Language Class Initialized
INFO - 2021-06-17 06:43:29 --> Language Class Initialized
INFO - 2021-06-17 06:43:29 --> Config Class Initialized
INFO - 2021-06-17 06:43:29 --> Loader Class Initialized
INFO - 2021-06-17 06:43:29 --> Helper loaded: url_helper
INFO - 2021-06-17 06:43:29 --> Helper loaded: file_helper
INFO - 2021-06-17 06:43:29 --> Helper loaded: form_helper
INFO - 2021-06-17 06:43:29 --> Helper loaded: my_helper
INFO - 2021-06-17 06:43:29 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:43:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:43:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:43:29 --> Controller Class Initialized
DEBUG - 2021-06-17 06:43:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-17 06:43:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:43:29 --> Final output sent to browser
DEBUG - 2021-06-17 06:43:29 --> Total execution time: 0.0442
INFO - 2021-06-17 06:43:30 --> Config Class Initialized
INFO - 2021-06-17 06:43:30 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:43:30 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:43:30 --> Utf8 Class Initialized
INFO - 2021-06-17 06:43:30 --> URI Class Initialized
INFO - 2021-06-17 06:43:30 --> Router Class Initialized
INFO - 2021-06-17 06:43:30 --> Output Class Initialized
INFO - 2021-06-17 06:43:30 --> Security Class Initialized
DEBUG - 2021-06-17 06:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:43:30 --> Input Class Initialized
INFO - 2021-06-17 06:43:30 --> Language Class Initialized
INFO - 2021-06-17 06:43:30 --> Language Class Initialized
INFO - 2021-06-17 06:43:30 --> Config Class Initialized
INFO - 2021-06-17 06:43:30 --> Loader Class Initialized
INFO - 2021-06-17 06:43:30 --> Helper loaded: url_helper
INFO - 2021-06-17 06:43:30 --> Helper loaded: file_helper
INFO - 2021-06-17 06:43:30 --> Helper loaded: form_helper
INFO - 2021-06-17 06:43:30 --> Helper loaded: my_helper
INFO - 2021-06-17 06:43:30 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:43:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:43:30 --> Controller Class Initialized
INFO - 2021-06-17 06:43:31 --> Config Class Initialized
INFO - 2021-06-17 06:43:31 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:43:31 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:43:31 --> Utf8 Class Initialized
INFO - 2021-06-17 06:43:31 --> URI Class Initialized
INFO - 2021-06-17 06:43:31 --> Router Class Initialized
INFO - 2021-06-17 06:43:31 --> Output Class Initialized
INFO - 2021-06-17 06:43:31 --> Security Class Initialized
DEBUG - 2021-06-17 06:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:43:31 --> Input Class Initialized
INFO - 2021-06-17 06:43:31 --> Language Class Initialized
INFO - 2021-06-17 06:43:31 --> Language Class Initialized
INFO - 2021-06-17 06:43:31 --> Config Class Initialized
INFO - 2021-06-17 06:43:31 --> Loader Class Initialized
INFO - 2021-06-17 06:43:31 --> Helper loaded: url_helper
INFO - 2021-06-17 06:43:31 --> Helper loaded: file_helper
INFO - 2021-06-17 06:43:31 --> Helper loaded: form_helper
INFO - 2021-06-17 06:43:31 --> Helper loaded: my_helper
INFO - 2021-06-17 06:43:31 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:43:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:43:31 --> Controller Class Initialized
DEBUG - 2021-06-17 06:43:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 06:43:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:43:31 --> Final output sent to browser
DEBUG - 2021-06-17 06:43:31 --> Total execution time: 0.0452
INFO - 2021-06-17 06:43:32 --> Config Class Initialized
INFO - 2021-06-17 06:43:32 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:43:32 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:43:32 --> Utf8 Class Initialized
INFO - 2021-06-17 06:43:32 --> URI Class Initialized
INFO - 2021-06-17 06:43:32 --> Router Class Initialized
INFO - 2021-06-17 06:43:32 --> Output Class Initialized
INFO - 2021-06-17 06:43:32 --> Security Class Initialized
DEBUG - 2021-06-17 06:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:43:32 --> Input Class Initialized
INFO - 2021-06-17 06:43:32 --> Language Class Initialized
INFO - 2021-06-17 06:43:32 --> Language Class Initialized
INFO - 2021-06-17 06:43:32 --> Config Class Initialized
INFO - 2021-06-17 06:43:32 --> Loader Class Initialized
INFO - 2021-06-17 06:43:32 --> Helper loaded: url_helper
INFO - 2021-06-17 06:43:32 --> Helper loaded: file_helper
INFO - 2021-06-17 06:43:32 --> Helper loaded: form_helper
INFO - 2021-06-17 06:43:32 --> Helper loaded: my_helper
INFO - 2021-06-17 06:43:32 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:43:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:43:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:43:32 --> Controller Class Initialized
INFO - 2021-06-17 06:43:34 --> Config Class Initialized
INFO - 2021-06-17 06:43:34 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:43:34 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:43:34 --> Utf8 Class Initialized
INFO - 2021-06-17 06:43:34 --> URI Class Initialized
INFO - 2021-06-17 06:43:34 --> Router Class Initialized
INFO - 2021-06-17 06:43:34 --> Output Class Initialized
INFO - 2021-06-17 06:43:34 --> Security Class Initialized
DEBUG - 2021-06-17 06:43:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:43:34 --> Input Class Initialized
INFO - 2021-06-17 06:43:34 --> Language Class Initialized
INFO - 2021-06-17 06:43:34 --> Language Class Initialized
INFO - 2021-06-17 06:43:34 --> Config Class Initialized
INFO - 2021-06-17 06:43:34 --> Loader Class Initialized
INFO - 2021-06-17 06:43:34 --> Helper loaded: url_helper
INFO - 2021-06-17 06:43:34 --> Helper loaded: file_helper
INFO - 2021-06-17 06:43:34 --> Helper loaded: form_helper
INFO - 2021-06-17 06:43:34 --> Helper loaded: my_helper
INFO - 2021-06-17 06:43:34 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:43:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:43:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:43:34 --> Controller Class Initialized
INFO - 2021-06-17 06:43:37 --> Config Class Initialized
INFO - 2021-06-17 06:43:37 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:43:37 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:43:37 --> Utf8 Class Initialized
INFO - 2021-06-17 06:43:37 --> URI Class Initialized
INFO - 2021-06-17 06:43:37 --> Router Class Initialized
INFO - 2021-06-17 06:43:37 --> Output Class Initialized
INFO - 2021-06-17 06:43:37 --> Security Class Initialized
DEBUG - 2021-06-17 06:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:43:37 --> Input Class Initialized
INFO - 2021-06-17 06:43:37 --> Language Class Initialized
INFO - 2021-06-17 06:43:37 --> Language Class Initialized
INFO - 2021-06-17 06:43:37 --> Config Class Initialized
INFO - 2021-06-17 06:43:37 --> Loader Class Initialized
INFO - 2021-06-17 06:43:37 --> Helper loaded: url_helper
INFO - 2021-06-17 06:43:37 --> Helper loaded: file_helper
INFO - 2021-06-17 06:43:37 --> Helper loaded: form_helper
INFO - 2021-06-17 06:43:37 --> Helper loaded: my_helper
INFO - 2021-06-17 06:43:37 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:43:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:43:37 --> Controller Class Initialized
DEBUG - 2021-06-17 06:43:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-17 06:43:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:43:37 --> Final output sent to browser
DEBUG - 2021-06-17 06:43:37 --> Total execution time: 0.0438
INFO - 2021-06-17 06:43:38 --> Config Class Initialized
INFO - 2021-06-17 06:43:38 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:43:38 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:43:38 --> Utf8 Class Initialized
INFO - 2021-06-17 06:43:38 --> URI Class Initialized
INFO - 2021-06-17 06:43:38 --> Router Class Initialized
INFO - 2021-06-17 06:43:38 --> Output Class Initialized
INFO - 2021-06-17 06:43:38 --> Security Class Initialized
DEBUG - 2021-06-17 06:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:43:38 --> Input Class Initialized
INFO - 2021-06-17 06:43:38 --> Language Class Initialized
INFO - 2021-06-17 06:43:38 --> Language Class Initialized
INFO - 2021-06-17 06:43:38 --> Config Class Initialized
INFO - 2021-06-17 06:43:38 --> Loader Class Initialized
INFO - 2021-06-17 06:43:38 --> Helper loaded: url_helper
INFO - 2021-06-17 06:43:38 --> Helper loaded: file_helper
INFO - 2021-06-17 06:43:38 --> Helper loaded: form_helper
INFO - 2021-06-17 06:43:38 --> Helper loaded: my_helper
INFO - 2021-06-17 06:43:38 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:43:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:43:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:43:38 --> Controller Class Initialized
INFO - 2021-06-17 06:43:39 --> Config Class Initialized
INFO - 2021-06-17 06:43:39 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:43:39 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:43:39 --> Utf8 Class Initialized
INFO - 2021-06-17 06:43:39 --> URI Class Initialized
INFO - 2021-06-17 06:43:39 --> Router Class Initialized
INFO - 2021-06-17 06:43:39 --> Output Class Initialized
INFO - 2021-06-17 06:43:39 --> Security Class Initialized
DEBUG - 2021-06-17 06:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:43:39 --> Input Class Initialized
INFO - 2021-06-17 06:43:39 --> Language Class Initialized
INFO - 2021-06-17 06:43:39 --> Language Class Initialized
INFO - 2021-06-17 06:43:39 --> Config Class Initialized
INFO - 2021-06-17 06:43:39 --> Loader Class Initialized
INFO - 2021-06-17 06:43:39 --> Helper loaded: url_helper
INFO - 2021-06-17 06:43:39 --> Helper loaded: file_helper
INFO - 2021-06-17 06:43:39 --> Helper loaded: form_helper
INFO - 2021-06-17 06:43:39 --> Helper loaded: my_helper
INFO - 2021-06-17 06:43:39 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:43:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:43:39 --> Controller Class Initialized
DEBUG - 2021-06-17 06:43:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 06:43:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:43:39 --> Final output sent to browser
DEBUG - 2021-06-17 06:43:39 --> Total execution time: 0.0436
INFO - 2021-06-17 06:43:41 --> Config Class Initialized
INFO - 2021-06-17 06:43:41 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:43:41 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:43:41 --> Utf8 Class Initialized
INFO - 2021-06-17 06:43:41 --> URI Class Initialized
INFO - 2021-06-17 06:43:41 --> Router Class Initialized
INFO - 2021-06-17 06:43:41 --> Output Class Initialized
INFO - 2021-06-17 06:43:41 --> Security Class Initialized
DEBUG - 2021-06-17 06:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:43:41 --> Input Class Initialized
INFO - 2021-06-17 06:43:41 --> Language Class Initialized
INFO - 2021-06-17 06:43:41 --> Language Class Initialized
INFO - 2021-06-17 06:43:41 --> Config Class Initialized
INFO - 2021-06-17 06:43:41 --> Loader Class Initialized
INFO - 2021-06-17 06:43:41 --> Helper loaded: url_helper
INFO - 2021-06-17 06:43:41 --> Helper loaded: file_helper
INFO - 2021-06-17 06:43:41 --> Helper loaded: form_helper
INFO - 2021-06-17 06:43:41 --> Helper loaded: my_helper
INFO - 2021-06-17 06:43:41 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:43:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:43:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:43:41 --> Controller Class Initialized
INFO - 2021-06-17 06:43:42 --> Config Class Initialized
INFO - 2021-06-17 06:43:42 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:43:42 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:43:42 --> Utf8 Class Initialized
INFO - 2021-06-17 06:43:42 --> URI Class Initialized
INFO - 2021-06-17 06:43:42 --> Router Class Initialized
INFO - 2021-06-17 06:43:42 --> Output Class Initialized
INFO - 2021-06-17 06:43:42 --> Security Class Initialized
DEBUG - 2021-06-17 06:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:43:42 --> Input Class Initialized
INFO - 2021-06-17 06:43:42 --> Language Class Initialized
INFO - 2021-06-17 06:43:42 --> Language Class Initialized
INFO - 2021-06-17 06:43:42 --> Config Class Initialized
INFO - 2021-06-17 06:43:42 --> Loader Class Initialized
INFO - 2021-06-17 06:43:42 --> Helper loaded: url_helper
INFO - 2021-06-17 06:43:42 --> Helper loaded: file_helper
INFO - 2021-06-17 06:43:42 --> Helper loaded: form_helper
INFO - 2021-06-17 06:43:42 --> Helper loaded: my_helper
INFO - 2021-06-17 06:43:42 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:43:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:43:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:43:42 --> Controller Class Initialized
INFO - 2021-06-17 06:43:46 --> Config Class Initialized
INFO - 2021-06-17 06:43:46 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:43:46 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:43:46 --> Utf8 Class Initialized
INFO - 2021-06-17 06:43:46 --> URI Class Initialized
INFO - 2021-06-17 06:43:46 --> Router Class Initialized
INFO - 2021-06-17 06:43:46 --> Output Class Initialized
INFO - 2021-06-17 06:43:46 --> Security Class Initialized
DEBUG - 2021-06-17 06:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:43:46 --> Input Class Initialized
INFO - 2021-06-17 06:43:46 --> Language Class Initialized
INFO - 2021-06-17 06:43:46 --> Language Class Initialized
INFO - 2021-06-17 06:43:46 --> Config Class Initialized
INFO - 2021-06-17 06:43:46 --> Loader Class Initialized
INFO - 2021-06-17 06:43:46 --> Helper loaded: url_helper
INFO - 2021-06-17 06:43:46 --> Helper loaded: file_helper
INFO - 2021-06-17 06:43:46 --> Helper loaded: form_helper
INFO - 2021-06-17 06:43:46 --> Helper loaded: my_helper
INFO - 2021-06-17 06:43:46 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:43:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:43:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:43:46 --> Controller Class Initialized
DEBUG - 2021-06-17 06:43:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-17 06:43:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:43:46 --> Final output sent to browser
DEBUG - 2021-06-17 06:43:46 --> Total execution time: 0.0460
INFO - 2021-06-17 06:43:46 --> Config Class Initialized
INFO - 2021-06-17 06:43:46 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:43:46 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:43:46 --> Utf8 Class Initialized
INFO - 2021-06-17 06:43:46 --> URI Class Initialized
INFO - 2021-06-17 06:43:46 --> Router Class Initialized
INFO - 2021-06-17 06:43:46 --> Output Class Initialized
INFO - 2021-06-17 06:43:46 --> Security Class Initialized
DEBUG - 2021-06-17 06:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:43:46 --> Input Class Initialized
INFO - 2021-06-17 06:43:46 --> Language Class Initialized
INFO - 2021-06-17 06:43:46 --> Language Class Initialized
INFO - 2021-06-17 06:43:46 --> Config Class Initialized
INFO - 2021-06-17 06:43:46 --> Loader Class Initialized
INFO - 2021-06-17 06:43:46 --> Helper loaded: url_helper
INFO - 2021-06-17 06:43:46 --> Helper loaded: file_helper
INFO - 2021-06-17 06:43:46 --> Helper loaded: form_helper
INFO - 2021-06-17 06:43:46 --> Helper loaded: my_helper
INFO - 2021-06-17 06:43:46 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:43:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:43:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:43:46 --> Controller Class Initialized
INFO - 2021-06-17 06:43:47 --> Config Class Initialized
INFO - 2021-06-17 06:43:47 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:43:47 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:43:47 --> Utf8 Class Initialized
INFO - 2021-06-17 06:43:47 --> URI Class Initialized
INFO - 2021-06-17 06:43:47 --> Router Class Initialized
INFO - 2021-06-17 06:43:47 --> Output Class Initialized
INFO - 2021-06-17 06:43:47 --> Security Class Initialized
DEBUG - 2021-06-17 06:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:43:47 --> Input Class Initialized
INFO - 2021-06-17 06:43:47 --> Language Class Initialized
INFO - 2021-06-17 06:43:47 --> Language Class Initialized
INFO - 2021-06-17 06:43:47 --> Config Class Initialized
INFO - 2021-06-17 06:43:47 --> Loader Class Initialized
INFO - 2021-06-17 06:43:47 --> Helper loaded: url_helper
INFO - 2021-06-17 06:43:47 --> Helper loaded: file_helper
INFO - 2021-06-17 06:43:47 --> Helper loaded: form_helper
INFO - 2021-06-17 06:43:47 --> Helper loaded: my_helper
INFO - 2021-06-17 06:43:47 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:43:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:43:47 --> Controller Class Initialized
DEBUG - 2021-06-17 06:43:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 06:43:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:43:47 --> Final output sent to browser
DEBUG - 2021-06-17 06:43:47 --> Total execution time: 0.0448
INFO - 2021-06-17 06:43:48 --> Config Class Initialized
INFO - 2021-06-17 06:43:48 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:43:48 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:43:48 --> Utf8 Class Initialized
INFO - 2021-06-17 06:43:48 --> URI Class Initialized
INFO - 2021-06-17 06:43:48 --> Router Class Initialized
INFO - 2021-06-17 06:43:48 --> Output Class Initialized
INFO - 2021-06-17 06:43:48 --> Security Class Initialized
DEBUG - 2021-06-17 06:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:43:48 --> Input Class Initialized
INFO - 2021-06-17 06:43:48 --> Language Class Initialized
INFO - 2021-06-17 06:43:48 --> Language Class Initialized
INFO - 2021-06-17 06:43:48 --> Config Class Initialized
INFO - 2021-06-17 06:43:48 --> Loader Class Initialized
INFO - 2021-06-17 06:43:48 --> Helper loaded: url_helper
INFO - 2021-06-17 06:43:48 --> Helper loaded: file_helper
INFO - 2021-06-17 06:43:48 --> Helper loaded: form_helper
INFO - 2021-06-17 06:43:48 --> Helper loaded: my_helper
INFO - 2021-06-17 06:43:48 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:43:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:43:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:43:48 --> Controller Class Initialized
INFO - 2021-06-17 06:43:49 --> Config Class Initialized
INFO - 2021-06-17 06:43:49 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:43:49 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:43:49 --> Utf8 Class Initialized
INFO - 2021-06-17 06:43:49 --> URI Class Initialized
INFO - 2021-06-17 06:43:49 --> Router Class Initialized
INFO - 2021-06-17 06:43:49 --> Output Class Initialized
INFO - 2021-06-17 06:43:49 --> Security Class Initialized
DEBUG - 2021-06-17 06:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:43:49 --> Input Class Initialized
INFO - 2021-06-17 06:43:49 --> Language Class Initialized
INFO - 2021-06-17 06:43:49 --> Language Class Initialized
INFO - 2021-06-17 06:43:49 --> Config Class Initialized
INFO - 2021-06-17 06:43:49 --> Loader Class Initialized
INFO - 2021-06-17 06:43:49 --> Helper loaded: url_helper
INFO - 2021-06-17 06:43:49 --> Helper loaded: file_helper
INFO - 2021-06-17 06:43:49 --> Helper loaded: form_helper
INFO - 2021-06-17 06:43:49 --> Helper loaded: my_helper
INFO - 2021-06-17 06:43:49 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:43:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:43:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:43:49 --> Controller Class Initialized
INFO - 2021-06-17 06:44:20 --> Config Class Initialized
INFO - 2021-06-17 06:44:20 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:44:20 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:44:20 --> Utf8 Class Initialized
INFO - 2021-06-17 06:44:20 --> URI Class Initialized
INFO - 2021-06-17 06:44:20 --> Router Class Initialized
INFO - 2021-06-17 06:44:20 --> Output Class Initialized
INFO - 2021-06-17 06:44:20 --> Security Class Initialized
DEBUG - 2021-06-17 06:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:44:20 --> Input Class Initialized
INFO - 2021-06-17 06:44:20 --> Language Class Initialized
INFO - 2021-06-17 06:44:20 --> Language Class Initialized
INFO - 2021-06-17 06:44:20 --> Config Class Initialized
INFO - 2021-06-17 06:44:20 --> Loader Class Initialized
INFO - 2021-06-17 06:44:20 --> Helper loaded: url_helper
INFO - 2021-06-17 06:44:20 --> Helper loaded: file_helper
INFO - 2021-06-17 06:44:20 --> Helper loaded: form_helper
INFO - 2021-06-17 06:44:20 --> Helper loaded: my_helper
INFO - 2021-06-17 06:44:20 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:44:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:44:20 --> Controller Class Initialized
DEBUG - 2021-06-17 06:44:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-17 06:44:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:44:20 --> Final output sent to browser
DEBUG - 2021-06-17 06:44:20 --> Total execution time: 0.0450
INFO - 2021-06-17 06:44:20 --> Config Class Initialized
INFO - 2021-06-17 06:44:20 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:44:20 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:44:20 --> Utf8 Class Initialized
INFO - 2021-06-17 06:44:20 --> URI Class Initialized
INFO - 2021-06-17 06:44:20 --> Router Class Initialized
INFO - 2021-06-17 06:44:20 --> Output Class Initialized
INFO - 2021-06-17 06:44:20 --> Security Class Initialized
DEBUG - 2021-06-17 06:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:44:20 --> Input Class Initialized
INFO - 2021-06-17 06:44:20 --> Language Class Initialized
INFO - 2021-06-17 06:44:20 --> Language Class Initialized
INFO - 2021-06-17 06:44:20 --> Config Class Initialized
INFO - 2021-06-17 06:44:20 --> Loader Class Initialized
INFO - 2021-06-17 06:44:20 --> Helper loaded: url_helper
INFO - 2021-06-17 06:44:20 --> Helper loaded: file_helper
INFO - 2021-06-17 06:44:20 --> Helper loaded: form_helper
INFO - 2021-06-17 06:44:20 --> Helper loaded: my_helper
INFO - 2021-06-17 06:44:20 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:44:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:44:20 --> Controller Class Initialized
INFO - 2021-06-17 06:44:21 --> Config Class Initialized
INFO - 2021-06-17 06:44:21 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:44:21 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:44:21 --> Utf8 Class Initialized
INFO - 2021-06-17 06:44:21 --> URI Class Initialized
INFO - 2021-06-17 06:44:21 --> Router Class Initialized
INFO - 2021-06-17 06:44:21 --> Output Class Initialized
INFO - 2021-06-17 06:44:21 --> Security Class Initialized
DEBUG - 2021-06-17 06:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:44:21 --> Input Class Initialized
INFO - 2021-06-17 06:44:21 --> Language Class Initialized
INFO - 2021-06-17 06:44:21 --> Language Class Initialized
INFO - 2021-06-17 06:44:21 --> Config Class Initialized
INFO - 2021-06-17 06:44:21 --> Loader Class Initialized
INFO - 2021-06-17 06:44:21 --> Helper loaded: url_helper
INFO - 2021-06-17 06:44:21 --> Helper loaded: file_helper
INFO - 2021-06-17 06:44:21 --> Helper loaded: form_helper
INFO - 2021-06-17 06:44:21 --> Helper loaded: my_helper
INFO - 2021-06-17 06:44:21 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:44:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:44:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:44:21 --> Controller Class Initialized
DEBUG - 2021-06-17 06:44:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 06:44:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:44:21 --> Final output sent to browser
DEBUG - 2021-06-17 06:44:21 --> Total execution time: 0.0444
INFO - 2021-06-17 06:44:23 --> Config Class Initialized
INFO - 2021-06-17 06:44:23 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:44:23 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:44:23 --> Utf8 Class Initialized
INFO - 2021-06-17 06:44:23 --> URI Class Initialized
INFO - 2021-06-17 06:44:23 --> Router Class Initialized
INFO - 2021-06-17 06:44:23 --> Output Class Initialized
INFO - 2021-06-17 06:44:23 --> Security Class Initialized
DEBUG - 2021-06-17 06:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:44:23 --> Input Class Initialized
INFO - 2021-06-17 06:44:23 --> Language Class Initialized
INFO - 2021-06-17 06:44:23 --> Language Class Initialized
INFO - 2021-06-17 06:44:23 --> Config Class Initialized
INFO - 2021-06-17 06:44:23 --> Loader Class Initialized
INFO - 2021-06-17 06:44:23 --> Helper loaded: url_helper
INFO - 2021-06-17 06:44:23 --> Helper loaded: file_helper
INFO - 2021-06-17 06:44:23 --> Helper loaded: form_helper
INFO - 2021-06-17 06:44:23 --> Helper loaded: my_helper
INFO - 2021-06-17 06:44:23 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:44:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:44:23 --> Controller Class Initialized
INFO - 2021-06-17 06:44:24 --> Config Class Initialized
INFO - 2021-06-17 06:44:24 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:44:24 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:44:24 --> Utf8 Class Initialized
INFO - 2021-06-17 06:44:24 --> URI Class Initialized
INFO - 2021-06-17 06:44:24 --> Router Class Initialized
INFO - 2021-06-17 06:44:24 --> Output Class Initialized
INFO - 2021-06-17 06:44:24 --> Security Class Initialized
DEBUG - 2021-06-17 06:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:44:24 --> Input Class Initialized
INFO - 2021-06-17 06:44:24 --> Language Class Initialized
INFO - 2021-06-17 06:44:24 --> Language Class Initialized
INFO - 2021-06-17 06:44:24 --> Config Class Initialized
INFO - 2021-06-17 06:44:24 --> Loader Class Initialized
INFO - 2021-06-17 06:44:24 --> Helper loaded: url_helper
INFO - 2021-06-17 06:44:24 --> Helper loaded: file_helper
INFO - 2021-06-17 06:44:24 --> Helper loaded: form_helper
INFO - 2021-06-17 06:44:24 --> Helper loaded: my_helper
INFO - 2021-06-17 06:44:24 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:44:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:44:24 --> Controller Class Initialized
INFO - 2021-06-17 06:44:40 --> Config Class Initialized
INFO - 2021-06-17 06:44:40 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:44:40 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:44:40 --> Utf8 Class Initialized
INFO - 2021-06-17 06:44:40 --> URI Class Initialized
INFO - 2021-06-17 06:44:40 --> Router Class Initialized
INFO - 2021-06-17 06:44:40 --> Output Class Initialized
INFO - 2021-06-17 06:44:40 --> Security Class Initialized
DEBUG - 2021-06-17 06:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:44:40 --> Input Class Initialized
INFO - 2021-06-17 06:44:40 --> Language Class Initialized
INFO - 2021-06-17 06:44:40 --> Language Class Initialized
INFO - 2021-06-17 06:44:40 --> Config Class Initialized
INFO - 2021-06-17 06:44:40 --> Loader Class Initialized
INFO - 2021-06-17 06:44:40 --> Helper loaded: url_helper
INFO - 2021-06-17 06:44:40 --> Helper loaded: file_helper
INFO - 2021-06-17 06:44:40 --> Helper loaded: form_helper
INFO - 2021-06-17 06:44:40 --> Helper loaded: my_helper
INFO - 2021-06-17 06:44:40 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:44:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:44:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:44:40 --> Controller Class Initialized
DEBUG - 2021-06-17 06:44:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-17 06:44:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:44:40 --> Final output sent to browser
DEBUG - 2021-06-17 06:44:40 --> Total execution time: 0.0464
INFO - 2021-06-17 06:44:41 --> Config Class Initialized
INFO - 2021-06-17 06:44:41 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:44:41 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:44:41 --> Utf8 Class Initialized
INFO - 2021-06-17 06:44:41 --> URI Class Initialized
INFO - 2021-06-17 06:44:41 --> Router Class Initialized
INFO - 2021-06-17 06:44:41 --> Output Class Initialized
INFO - 2021-06-17 06:44:41 --> Security Class Initialized
DEBUG - 2021-06-17 06:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:44:41 --> Input Class Initialized
INFO - 2021-06-17 06:44:41 --> Language Class Initialized
INFO - 2021-06-17 06:44:41 --> Language Class Initialized
INFO - 2021-06-17 06:44:41 --> Config Class Initialized
INFO - 2021-06-17 06:44:41 --> Loader Class Initialized
INFO - 2021-06-17 06:44:41 --> Helper loaded: url_helper
INFO - 2021-06-17 06:44:41 --> Helper loaded: file_helper
INFO - 2021-06-17 06:44:41 --> Helper loaded: form_helper
INFO - 2021-06-17 06:44:41 --> Helper loaded: my_helper
INFO - 2021-06-17 06:44:41 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:44:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:44:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:44:41 --> Controller Class Initialized
INFO - 2021-06-17 06:44:41 --> Config Class Initialized
INFO - 2021-06-17 06:44:41 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:44:41 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:44:41 --> Utf8 Class Initialized
INFO - 2021-06-17 06:44:41 --> URI Class Initialized
INFO - 2021-06-17 06:44:41 --> Router Class Initialized
INFO - 2021-06-17 06:44:41 --> Output Class Initialized
INFO - 2021-06-17 06:44:41 --> Security Class Initialized
DEBUG - 2021-06-17 06:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:44:41 --> Input Class Initialized
INFO - 2021-06-17 06:44:41 --> Language Class Initialized
INFO - 2021-06-17 06:44:41 --> Language Class Initialized
INFO - 2021-06-17 06:44:41 --> Config Class Initialized
INFO - 2021-06-17 06:44:41 --> Loader Class Initialized
INFO - 2021-06-17 06:44:41 --> Helper loaded: url_helper
INFO - 2021-06-17 06:44:41 --> Helper loaded: file_helper
INFO - 2021-06-17 06:44:41 --> Helper loaded: form_helper
INFO - 2021-06-17 06:44:41 --> Helper loaded: my_helper
INFO - 2021-06-17 06:44:41 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:44:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:44:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:44:41 --> Controller Class Initialized
DEBUG - 2021-06-17 06:44:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 06:44:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:44:41 --> Final output sent to browser
DEBUG - 2021-06-17 06:44:41 --> Total execution time: 0.0430
INFO - 2021-06-17 06:44:43 --> Config Class Initialized
INFO - 2021-06-17 06:44:43 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:44:43 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:44:43 --> Utf8 Class Initialized
INFO - 2021-06-17 06:44:43 --> URI Class Initialized
INFO - 2021-06-17 06:44:43 --> Router Class Initialized
INFO - 2021-06-17 06:44:43 --> Output Class Initialized
INFO - 2021-06-17 06:44:43 --> Security Class Initialized
DEBUG - 2021-06-17 06:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:44:43 --> Input Class Initialized
INFO - 2021-06-17 06:44:43 --> Language Class Initialized
INFO - 2021-06-17 06:44:43 --> Language Class Initialized
INFO - 2021-06-17 06:44:43 --> Config Class Initialized
INFO - 2021-06-17 06:44:43 --> Loader Class Initialized
INFO - 2021-06-17 06:44:43 --> Helper loaded: url_helper
INFO - 2021-06-17 06:44:43 --> Helper loaded: file_helper
INFO - 2021-06-17 06:44:43 --> Helper loaded: form_helper
INFO - 2021-06-17 06:44:43 --> Helper loaded: my_helper
INFO - 2021-06-17 06:44:43 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:44:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:44:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:44:43 --> Controller Class Initialized
INFO - 2021-06-17 06:44:44 --> Config Class Initialized
INFO - 2021-06-17 06:44:44 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:44:44 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:44:44 --> Utf8 Class Initialized
INFO - 2021-06-17 06:44:44 --> URI Class Initialized
INFO - 2021-06-17 06:44:44 --> Router Class Initialized
INFO - 2021-06-17 06:44:44 --> Output Class Initialized
INFO - 2021-06-17 06:44:44 --> Security Class Initialized
DEBUG - 2021-06-17 06:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:44:44 --> Input Class Initialized
INFO - 2021-06-17 06:44:44 --> Language Class Initialized
INFO - 2021-06-17 06:44:44 --> Language Class Initialized
INFO - 2021-06-17 06:44:44 --> Config Class Initialized
INFO - 2021-06-17 06:44:44 --> Loader Class Initialized
INFO - 2021-06-17 06:44:44 --> Helper loaded: url_helper
INFO - 2021-06-17 06:44:44 --> Helper loaded: file_helper
INFO - 2021-06-17 06:44:44 --> Helper loaded: form_helper
INFO - 2021-06-17 06:44:44 --> Helper loaded: my_helper
INFO - 2021-06-17 06:44:44 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:44:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:44:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:44:44 --> Controller Class Initialized
INFO - 2021-06-17 06:45:03 --> Config Class Initialized
INFO - 2021-06-17 06:45:03 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:45:03 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:45:03 --> Utf8 Class Initialized
INFO - 2021-06-17 06:45:03 --> URI Class Initialized
INFO - 2021-06-17 06:45:03 --> Router Class Initialized
INFO - 2021-06-17 06:45:03 --> Output Class Initialized
INFO - 2021-06-17 06:45:03 --> Security Class Initialized
DEBUG - 2021-06-17 06:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:45:03 --> Input Class Initialized
INFO - 2021-06-17 06:45:03 --> Language Class Initialized
INFO - 2021-06-17 06:45:03 --> Language Class Initialized
INFO - 2021-06-17 06:45:03 --> Config Class Initialized
INFO - 2021-06-17 06:45:03 --> Loader Class Initialized
INFO - 2021-06-17 06:45:03 --> Helper loaded: url_helper
INFO - 2021-06-17 06:45:03 --> Helper loaded: file_helper
INFO - 2021-06-17 06:45:03 --> Helper loaded: form_helper
INFO - 2021-06-17 06:45:03 --> Helper loaded: my_helper
INFO - 2021-06-17 06:45:03 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:45:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:45:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:45:03 --> Controller Class Initialized
DEBUG - 2021-06-17 06:45:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-17 06:45:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:45:03 --> Final output sent to browser
DEBUG - 2021-06-17 06:45:03 --> Total execution time: 0.0446
INFO - 2021-06-17 06:45:03 --> Config Class Initialized
INFO - 2021-06-17 06:45:03 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:45:03 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:45:03 --> Utf8 Class Initialized
INFO - 2021-06-17 06:45:03 --> URI Class Initialized
INFO - 2021-06-17 06:45:03 --> Router Class Initialized
INFO - 2021-06-17 06:45:03 --> Output Class Initialized
INFO - 2021-06-17 06:45:03 --> Security Class Initialized
DEBUG - 2021-06-17 06:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:45:03 --> Input Class Initialized
INFO - 2021-06-17 06:45:03 --> Language Class Initialized
INFO - 2021-06-17 06:45:03 --> Language Class Initialized
INFO - 2021-06-17 06:45:03 --> Config Class Initialized
INFO - 2021-06-17 06:45:03 --> Loader Class Initialized
INFO - 2021-06-17 06:45:03 --> Helper loaded: url_helper
INFO - 2021-06-17 06:45:03 --> Helper loaded: file_helper
INFO - 2021-06-17 06:45:03 --> Helper loaded: form_helper
INFO - 2021-06-17 06:45:03 --> Helper loaded: my_helper
INFO - 2021-06-17 06:45:03 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:45:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:45:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:45:03 --> Controller Class Initialized
INFO - 2021-06-17 06:45:04 --> Config Class Initialized
INFO - 2021-06-17 06:45:04 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:45:04 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:45:04 --> Utf8 Class Initialized
INFO - 2021-06-17 06:45:04 --> URI Class Initialized
INFO - 2021-06-17 06:45:04 --> Router Class Initialized
INFO - 2021-06-17 06:45:04 --> Output Class Initialized
INFO - 2021-06-17 06:45:04 --> Security Class Initialized
DEBUG - 2021-06-17 06:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:45:04 --> Input Class Initialized
INFO - 2021-06-17 06:45:04 --> Language Class Initialized
INFO - 2021-06-17 06:45:04 --> Language Class Initialized
INFO - 2021-06-17 06:45:04 --> Config Class Initialized
INFO - 2021-06-17 06:45:04 --> Loader Class Initialized
INFO - 2021-06-17 06:45:04 --> Helper loaded: url_helper
INFO - 2021-06-17 06:45:04 --> Helper loaded: file_helper
INFO - 2021-06-17 06:45:04 --> Helper loaded: form_helper
INFO - 2021-06-17 06:45:04 --> Helper loaded: my_helper
INFO - 2021-06-17 06:45:04 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:45:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:45:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:45:04 --> Controller Class Initialized
DEBUG - 2021-06-17 06:45:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 06:45:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:45:04 --> Final output sent to browser
DEBUG - 2021-06-17 06:45:04 --> Total execution time: 0.0442
INFO - 2021-06-17 06:45:05 --> Config Class Initialized
INFO - 2021-06-17 06:45:05 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:45:05 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:45:05 --> Utf8 Class Initialized
INFO - 2021-06-17 06:45:05 --> URI Class Initialized
INFO - 2021-06-17 06:45:05 --> Router Class Initialized
INFO - 2021-06-17 06:45:05 --> Output Class Initialized
INFO - 2021-06-17 06:45:05 --> Security Class Initialized
DEBUG - 2021-06-17 06:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:45:05 --> Input Class Initialized
INFO - 2021-06-17 06:45:05 --> Language Class Initialized
INFO - 2021-06-17 06:45:05 --> Language Class Initialized
INFO - 2021-06-17 06:45:05 --> Config Class Initialized
INFO - 2021-06-17 06:45:05 --> Loader Class Initialized
INFO - 2021-06-17 06:45:05 --> Helper loaded: url_helper
INFO - 2021-06-17 06:45:05 --> Helper loaded: file_helper
INFO - 2021-06-17 06:45:05 --> Helper loaded: form_helper
INFO - 2021-06-17 06:45:05 --> Helper loaded: my_helper
INFO - 2021-06-17 06:45:05 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:45:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:45:05 --> Controller Class Initialized
INFO - 2021-06-17 06:45:06 --> Config Class Initialized
INFO - 2021-06-17 06:45:06 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:45:06 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:45:06 --> Utf8 Class Initialized
INFO - 2021-06-17 06:45:06 --> URI Class Initialized
INFO - 2021-06-17 06:45:06 --> Router Class Initialized
INFO - 2021-06-17 06:45:06 --> Output Class Initialized
INFO - 2021-06-17 06:45:06 --> Security Class Initialized
DEBUG - 2021-06-17 06:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:45:06 --> Input Class Initialized
INFO - 2021-06-17 06:45:06 --> Language Class Initialized
INFO - 2021-06-17 06:45:06 --> Language Class Initialized
INFO - 2021-06-17 06:45:06 --> Config Class Initialized
INFO - 2021-06-17 06:45:06 --> Loader Class Initialized
INFO - 2021-06-17 06:45:06 --> Helper loaded: url_helper
INFO - 2021-06-17 06:45:06 --> Helper loaded: file_helper
INFO - 2021-06-17 06:45:06 --> Helper loaded: form_helper
INFO - 2021-06-17 06:45:06 --> Helper loaded: my_helper
INFO - 2021-06-17 06:45:06 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:45:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:45:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:45:06 --> Controller Class Initialized
INFO - 2021-06-17 06:45:23 --> Config Class Initialized
INFO - 2021-06-17 06:45:23 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:45:23 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:45:23 --> Utf8 Class Initialized
INFO - 2021-06-17 06:45:23 --> URI Class Initialized
INFO - 2021-06-17 06:45:23 --> Router Class Initialized
INFO - 2021-06-17 06:45:23 --> Output Class Initialized
INFO - 2021-06-17 06:45:23 --> Security Class Initialized
DEBUG - 2021-06-17 06:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:45:23 --> Input Class Initialized
INFO - 2021-06-17 06:45:23 --> Language Class Initialized
INFO - 2021-06-17 06:45:23 --> Language Class Initialized
INFO - 2021-06-17 06:45:23 --> Config Class Initialized
INFO - 2021-06-17 06:45:23 --> Loader Class Initialized
INFO - 2021-06-17 06:45:23 --> Helper loaded: url_helper
INFO - 2021-06-17 06:45:23 --> Helper loaded: file_helper
INFO - 2021-06-17 06:45:23 --> Helper loaded: form_helper
INFO - 2021-06-17 06:45:23 --> Helper loaded: my_helper
INFO - 2021-06-17 06:45:23 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:45:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:45:23 --> Controller Class Initialized
DEBUG - 2021-06-17 06:45:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-17 06:45:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:45:23 --> Final output sent to browser
DEBUG - 2021-06-17 06:45:23 --> Total execution time: 0.0444
INFO - 2021-06-17 06:45:23 --> Config Class Initialized
INFO - 2021-06-17 06:45:23 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:45:23 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:45:23 --> Utf8 Class Initialized
INFO - 2021-06-17 06:45:23 --> URI Class Initialized
INFO - 2021-06-17 06:45:23 --> Router Class Initialized
INFO - 2021-06-17 06:45:23 --> Output Class Initialized
INFO - 2021-06-17 06:45:23 --> Security Class Initialized
DEBUG - 2021-06-17 06:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:45:23 --> Input Class Initialized
INFO - 2021-06-17 06:45:23 --> Language Class Initialized
INFO - 2021-06-17 06:45:23 --> Language Class Initialized
INFO - 2021-06-17 06:45:23 --> Config Class Initialized
INFO - 2021-06-17 06:45:23 --> Loader Class Initialized
INFO - 2021-06-17 06:45:23 --> Helper loaded: url_helper
INFO - 2021-06-17 06:45:23 --> Helper loaded: file_helper
INFO - 2021-06-17 06:45:23 --> Helper loaded: form_helper
INFO - 2021-06-17 06:45:23 --> Helper loaded: my_helper
INFO - 2021-06-17 06:45:23 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:45:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:45:23 --> Controller Class Initialized
INFO - 2021-06-17 06:45:24 --> Config Class Initialized
INFO - 2021-06-17 06:45:24 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:45:24 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:45:24 --> Utf8 Class Initialized
INFO - 2021-06-17 06:45:24 --> URI Class Initialized
INFO - 2021-06-17 06:45:24 --> Router Class Initialized
INFO - 2021-06-17 06:45:24 --> Output Class Initialized
INFO - 2021-06-17 06:45:24 --> Security Class Initialized
DEBUG - 2021-06-17 06:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:45:24 --> Input Class Initialized
INFO - 2021-06-17 06:45:24 --> Language Class Initialized
INFO - 2021-06-17 06:45:24 --> Language Class Initialized
INFO - 2021-06-17 06:45:24 --> Config Class Initialized
INFO - 2021-06-17 06:45:24 --> Loader Class Initialized
INFO - 2021-06-17 06:45:24 --> Helper loaded: url_helper
INFO - 2021-06-17 06:45:24 --> Helper loaded: file_helper
INFO - 2021-06-17 06:45:24 --> Helper loaded: form_helper
INFO - 2021-06-17 06:45:24 --> Helper loaded: my_helper
INFO - 2021-06-17 06:45:24 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:45:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:45:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:45:24 --> Controller Class Initialized
DEBUG - 2021-06-17 06:45:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 06:45:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:45:24 --> Final output sent to browser
DEBUG - 2021-06-17 06:45:24 --> Total execution time: 0.0444
INFO - 2021-06-17 06:45:26 --> Config Class Initialized
INFO - 2021-06-17 06:45:26 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:45:26 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:45:26 --> Utf8 Class Initialized
INFO - 2021-06-17 06:45:26 --> URI Class Initialized
INFO - 2021-06-17 06:45:26 --> Router Class Initialized
INFO - 2021-06-17 06:45:26 --> Output Class Initialized
INFO - 2021-06-17 06:45:26 --> Security Class Initialized
DEBUG - 2021-06-17 06:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:45:26 --> Input Class Initialized
INFO - 2021-06-17 06:45:26 --> Language Class Initialized
INFO - 2021-06-17 06:45:26 --> Language Class Initialized
INFO - 2021-06-17 06:45:26 --> Config Class Initialized
INFO - 2021-06-17 06:45:26 --> Loader Class Initialized
INFO - 2021-06-17 06:45:26 --> Helper loaded: url_helper
INFO - 2021-06-17 06:45:26 --> Helper loaded: file_helper
INFO - 2021-06-17 06:45:26 --> Helper loaded: form_helper
INFO - 2021-06-17 06:45:26 --> Helper loaded: my_helper
INFO - 2021-06-17 06:45:26 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:45:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:45:26 --> Controller Class Initialized
INFO - 2021-06-17 06:45:27 --> Config Class Initialized
INFO - 2021-06-17 06:45:27 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:45:27 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:45:27 --> Utf8 Class Initialized
INFO - 2021-06-17 06:45:27 --> URI Class Initialized
INFO - 2021-06-17 06:45:27 --> Router Class Initialized
INFO - 2021-06-17 06:45:27 --> Output Class Initialized
INFO - 2021-06-17 06:45:27 --> Security Class Initialized
DEBUG - 2021-06-17 06:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:45:27 --> Input Class Initialized
INFO - 2021-06-17 06:45:27 --> Language Class Initialized
INFO - 2021-06-17 06:45:27 --> Language Class Initialized
INFO - 2021-06-17 06:45:27 --> Config Class Initialized
INFO - 2021-06-17 06:45:27 --> Loader Class Initialized
INFO - 2021-06-17 06:45:27 --> Helper loaded: url_helper
INFO - 2021-06-17 06:45:27 --> Helper loaded: file_helper
INFO - 2021-06-17 06:45:27 --> Helper loaded: form_helper
INFO - 2021-06-17 06:45:27 --> Helper loaded: my_helper
INFO - 2021-06-17 06:45:27 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:45:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:45:27 --> Controller Class Initialized
INFO - 2021-06-17 06:45:44 --> Config Class Initialized
INFO - 2021-06-17 06:45:44 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:45:44 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:45:44 --> Utf8 Class Initialized
INFO - 2021-06-17 06:45:44 --> URI Class Initialized
INFO - 2021-06-17 06:45:44 --> Router Class Initialized
INFO - 2021-06-17 06:45:44 --> Output Class Initialized
INFO - 2021-06-17 06:45:44 --> Security Class Initialized
DEBUG - 2021-06-17 06:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:45:44 --> Input Class Initialized
INFO - 2021-06-17 06:45:44 --> Language Class Initialized
INFO - 2021-06-17 06:45:44 --> Language Class Initialized
INFO - 2021-06-17 06:45:44 --> Config Class Initialized
INFO - 2021-06-17 06:45:44 --> Loader Class Initialized
INFO - 2021-06-17 06:45:44 --> Helper loaded: url_helper
INFO - 2021-06-17 06:45:44 --> Helper loaded: file_helper
INFO - 2021-06-17 06:45:44 --> Helper loaded: form_helper
INFO - 2021-06-17 06:45:44 --> Helper loaded: my_helper
INFO - 2021-06-17 06:45:44 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:45:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:45:44 --> Controller Class Initialized
DEBUG - 2021-06-17 06:45:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-17 06:45:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:45:44 --> Final output sent to browser
DEBUG - 2021-06-17 06:45:44 --> Total execution time: 0.0470
INFO - 2021-06-17 06:45:44 --> Config Class Initialized
INFO - 2021-06-17 06:45:44 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:45:44 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:45:44 --> Utf8 Class Initialized
INFO - 2021-06-17 06:45:44 --> URI Class Initialized
INFO - 2021-06-17 06:45:44 --> Router Class Initialized
INFO - 2021-06-17 06:45:44 --> Output Class Initialized
INFO - 2021-06-17 06:45:44 --> Security Class Initialized
DEBUG - 2021-06-17 06:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:45:44 --> Input Class Initialized
INFO - 2021-06-17 06:45:44 --> Language Class Initialized
INFO - 2021-06-17 06:45:44 --> Language Class Initialized
INFO - 2021-06-17 06:45:44 --> Config Class Initialized
INFO - 2021-06-17 06:45:44 --> Loader Class Initialized
INFO - 2021-06-17 06:45:44 --> Helper loaded: url_helper
INFO - 2021-06-17 06:45:44 --> Helper loaded: file_helper
INFO - 2021-06-17 06:45:44 --> Helper loaded: form_helper
INFO - 2021-06-17 06:45:44 --> Helper loaded: my_helper
INFO - 2021-06-17 06:45:44 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:45:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:45:44 --> Controller Class Initialized
INFO - 2021-06-17 06:45:45 --> Config Class Initialized
INFO - 2021-06-17 06:45:45 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:45:45 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:45:45 --> Utf8 Class Initialized
INFO - 2021-06-17 06:45:45 --> URI Class Initialized
INFO - 2021-06-17 06:45:45 --> Router Class Initialized
INFO - 2021-06-17 06:45:45 --> Output Class Initialized
INFO - 2021-06-17 06:45:45 --> Security Class Initialized
DEBUG - 2021-06-17 06:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:45:45 --> Input Class Initialized
INFO - 2021-06-17 06:45:45 --> Language Class Initialized
INFO - 2021-06-17 06:45:45 --> Language Class Initialized
INFO - 2021-06-17 06:45:45 --> Config Class Initialized
INFO - 2021-06-17 06:45:45 --> Loader Class Initialized
INFO - 2021-06-17 06:45:45 --> Helper loaded: url_helper
INFO - 2021-06-17 06:45:45 --> Helper loaded: file_helper
INFO - 2021-06-17 06:45:45 --> Helper loaded: form_helper
INFO - 2021-06-17 06:45:45 --> Helper loaded: my_helper
INFO - 2021-06-17 06:45:45 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:45:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:45:45 --> Controller Class Initialized
DEBUG - 2021-06-17 06:45:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 06:45:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:45:45 --> Final output sent to browser
DEBUG - 2021-06-17 06:45:45 --> Total execution time: 0.0439
INFO - 2021-06-17 06:45:47 --> Config Class Initialized
INFO - 2021-06-17 06:45:47 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:45:47 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:45:47 --> Utf8 Class Initialized
INFO - 2021-06-17 06:45:47 --> URI Class Initialized
INFO - 2021-06-17 06:45:47 --> Router Class Initialized
INFO - 2021-06-17 06:45:47 --> Output Class Initialized
INFO - 2021-06-17 06:45:47 --> Security Class Initialized
DEBUG - 2021-06-17 06:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:45:47 --> Input Class Initialized
INFO - 2021-06-17 06:45:47 --> Language Class Initialized
INFO - 2021-06-17 06:45:47 --> Language Class Initialized
INFO - 2021-06-17 06:45:47 --> Config Class Initialized
INFO - 2021-06-17 06:45:47 --> Loader Class Initialized
INFO - 2021-06-17 06:45:47 --> Helper loaded: url_helper
INFO - 2021-06-17 06:45:47 --> Helper loaded: file_helper
INFO - 2021-06-17 06:45:47 --> Helper loaded: form_helper
INFO - 2021-06-17 06:45:47 --> Helper loaded: my_helper
INFO - 2021-06-17 06:45:47 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:45:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:45:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:45:47 --> Controller Class Initialized
INFO - 2021-06-17 06:45:48 --> Config Class Initialized
INFO - 2021-06-17 06:45:48 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:45:48 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:45:48 --> Utf8 Class Initialized
INFO - 2021-06-17 06:45:48 --> URI Class Initialized
INFO - 2021-06-17 06:45:48 --> Router Class Initialized
INFO - 2021-06-17 06:45:48 --> Output Class Initialized
INFO - 2021-06-17 06:45:48 --> Security Class Initialized
DEBUG - 2021-06-17 06:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:45:48 --> Input Class Initialized
INFO - 2021-06-17 06:45:48 --> Language Class Initialized
INFO - 2021-06-17 06:45:48 --> Language Class Initialized
INFO - 2021-06-17 06:45:48 --> Config Class Initialized
INFO - 2021-06-17 06:45:48 --> Loader Class Initialized
INFO - 2021-06-17 06:45:48 --> Helper loaded: url_helper
INFO - 2021-06-17 06:45:48 --> Helper loaded: file_helper
INFO - 2021-06-17 06:45:48 --> Helper loaded: form_helper
INFO - 2021-06-17 06:45:48 --> Helper loaded: my_helper
INFO - 2021-06-17 06:45:48 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:45:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:45:48 --> Controller Class Initialized
INFO - 2021-06-17 06:48:38 --> Config Class Initialized
INFO - 2021-06-17 06:48:38 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:48:38 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:48:38 --> Utf8 Class Initialized
INFO - 2021-06-17 06:48:38 --> URI Class Initialized
INFO - 2021-06-17 06:48:38 --> Router Class Initialized
INFO - 2021-06-17 06:48:38 --> Output Class Initialized
INFO - 2021-06-17 06:48:38 --> Security Class Initialized
DEBUG - 2021-06-17 06:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:48:38 --> Input Class Initialized
INFO - 2021-06-17 06:48:38 --> Language Class Initialized
INFO - 2021-06-17 06:48:38 --> Language Class Initialized
INFO - 2021-06-17 06:48:38 --> Config Class Initialized
INFO - 2021-06-17 06:48:38 --> Loader Class Initialized
INFO - 2021-06-17 06:48:38 --> Helper loaded: url_helper
INFO - 2021-06-17 06:48:38 --> Helper loaded: file_helper
INFO - 2021-06-17 06:48:38 --> Helper loaded: form_helper
INFO - 2021-06-17 06:48:38 --> Helper loaded: my_helper
INFO - 2021-06-17 06:48:38 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:48:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:48:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:48:38 --> Controller Class Initialized
INFO - 2021-06-17 06:48:38 --> Helper loaded: cookie_helper
INFO - 2021-06-17 06:48:38 --> Config Class Initialized
INFO - 2021-06-17 06:48:38 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:48:38 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:48:38 --> Utf8 Class Initialized
INFO - 2021-06-17 06:48:38 --> URI Class Initialized
INFO - 2021-06-17 06:48:38 --> Router Class Initialized
INFO - 2021-06-17 06:48:39 --> Output Class Initialized
INFO - 2021-06-17 06:48:39 --> Security Class Initialized
DEBUG - 2021-06-17 06:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:48:39 --> Input Class Initialized
INFO - 2021-06-17 06:48:39 --> Language Class Initialized
INFO - 2021-06-17 06:48:39 --> Language Class Initialized
INFO - 2021-06-17 06:48:39 --> Config Class Initialized
INFO - 2021-06-17 06:48:39 --> Loader Class Initialized
INFO - 2021-06-17 06:48:39 --> Helper loaded: url_helper
INFO - 2021-06-17 06:48:39 --> Helper loaded: file_helper
INFO - 2021-06-17 06:48:39 --> Helper loaded: form_helper
INFO - 2021-06-17 06:48:39 --> Helper loaded: my_helper
INFO - 2021-06-17 06:48:39 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:48:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:48:39 --> Controller Class Initialized
DEBUG - 2021-06-17 06:48:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-17 06:48:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:48:39 --> Final output sent to browser
DEBUG - 2021-06-17 06:48:39 --> Total execution time: 0.0501
INFO - 2021-06-17 06:57:21 --> Config Class Initialized
INFO - 2021-06-17 06:57:21 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:57:21 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:57:21 --> Utf8 Class Initialized
INFO - 2021-06-17 06:57:21 --> URI Class Initialized
DEBUG - 2021-06-17 06:57:21 --> No URI present. Default controller set.
INFO - 2021-06-17 06:57:21 --> Router Class Initialized
INFO - 2021-06-17 06:57:21 --> Output Class Initialized
INFO - 2021-06-17 06:57:21 --> Security Class Initialized
DEBUG - 2021-06-17 06:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:57:21 --> Input Class Initialized
INFO - 2021-06-17 06:57:21 --> Language Class Initialized
INFO - 2021-06-17 06:57:21 --> Language Class Initialized
INFO - 2021-06-17 06:57:21 --> Config Class Initialized
INFO - 2021-06-17 06:57:21 --> Loader Class Initialized
INFO - 2021-06-17 06:57:21 --> Helper loaded: url_helper
INFO - 2021-06-17 06:57:21 --> Helper loaded: file_helper
INFO - 2021-06-17 06:57:21 --> Helper loaded: form_helper
INFO - 2021-06-17 06:57:21 --> Helper loaded: my_helper
INFO - 2021-06-17 06:57:21 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:57:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:57:21 --> Controller Class Initialized
INFO - 2021-06-17 06:57:21 --> Config Class Initialized
INFO - 2021-06-17 06:57:21 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:57:21 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:57:21 --> Utf8 Class Initialized
INFO - 2021-06-17 06:57:21 --> URI Class Initialized
INFO - 2021-06-17 06:57:21 --> Router Class Initialized
INFO - 2021-06-17 06:57:21 --> Output Class Initialized
INFO - 2021-06-17 06:57:21 --> Security Class Initialized
DEBUG - 2021-06-17 06:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:57:21 --> Input Class Initialized
INFO - 2021-06-17 06:57:21 --> Language Class Initialized
INFO - 2021-06-17 06:57:21 --> Language Class Initialized
INFO - 2021-06-17 06:57:21 --> Config Class Initialized
INFO - 2021-06-17 06:57:21 --> Loader Class Initialized
INFO - 2021-06-17 06:57:21 --> Helper loaded: url_helper
INFO - 2021-06-17 06:57:21 --> Helper loaded: file_helper
INFO - 2021-06-17 06:57:21 --> Helper loaded: form_helper
INFO - 2021-06-17 06:57:21 --> Helper loaded: my_helper
INFO - 2021-06-17 06:57:21 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:57:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:57:21 --> Controller Class Initialized
DEBUG - 2021-06-17 06:57:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-17 06:57:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:57:21 --> Final output sent to browser
DEBUG - 2021-06-17 06:57:21 --> Total execution time: 0.0404
INFO - 2021-06-17 06:57:25 --> Config Class Initialized
INFO - 2021-06-17 06:57:25 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:57:25 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:57:25 --> Utf8 Class Initialized
INFO - 2021-06-17 06:57:25 --> URI Class Initialized
INFO - 2021-06-17 06:57:25 --> Router Class Initialized
INFO - 2021-06-17 06:57:25 --> Output Class Initialized
INFO - 2021-06-17 06:57:25 --> Security Class Initialized
DEBUG - 2021-06-17 06:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:57:25 --> Input Class Initialized
INFO - 2021-06-17 06:57:25 --> Language Class Initialized
INFO - 2021-06-17 06:57:25 --> Language Class Initialized
INFO - 2021-06-17 06:57:25 --> Config Class Initialized
INFO - 2021-06-17 06:57:25 --> Loader Class Initialized
INFO - 2021-06-17 06:57:25 --> Helper loaded: url_helper
INFO - 2021-06-17 06:57:25 --> Helper loaded: file_helper
INFO - 2021-06-17 06:57:25 --> Helper loaded: form_helper
INFO - 2021-06-17 06:57:25 --> Helper loaded: my_helper
INFO - 2021-06-17 06:57:25 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:57:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:57:25 --> Controller Class Initialized
INFO - 2021-06-17 06:57:25 --> Helper loaded: cookie_helper
INFO - 2021-06-17 06:57:25 --> Final output sent to browser
DEBUG - 2021-06-17 06:57:25 --> Total execution time: 0.0561
INFO - 2021-06-17 06:57:25 --> Config Class Initialized
INFO - 2021-06-17 06:57:25 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:57:25 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:57:25 --> Utf8 Class Initialized
INFO - 2021-06-17 06:57:25 --> URI Class Initialized
INFO - 2021-06-17 06:57:25 --> Router Class Initialized
INFO - 2021-06-17 06:57:25 --> Output Class Initialized
INFO - 2021-06-17 06:57:25 --> Security Class Initialized
DEBUG - 2021-06-17 06:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:57:25 --> Input Class Initialized
INFO - 2021-06-17 06:57:25 --> Language Class Initialized
INFO - 2021-06-17 06:57:25 --> Language Class Initialized
INFO - 2021-06-17 06:57:25 --> Config Class Initialized
INFO - 2021-06-17 06:57:25 --> Loader Class Initialized
INFO - 2021-06-17 06:57:25 --> Helper loaded: url_helper
INFO - 2021-06-17 06:57:25 --> Helper loaded: file_helper
INFO - 2021-06-17 06:57:25 --> Helper loaded: form_helper
INFO - 2021-06-17 06:57:25 --> Helper loaded: my_helper
INFO - 2021-06-17 06:57:25 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:57:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:57:25 --> Controller Class Initialized
DEBUG - 2021-06-17 06:57:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-17 06:57:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:57:26 --> Final output sent to browser
DEBUG - 2021-06-17 06:57:26 --> Total execution time: 0.2181
INFO - 2021-06-17 06:57:27 --> Config Class Initialized
INFO - 2021-06-17 06:57:27 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:57:27 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:57:27 --> Utf8 Class Initialized
INFO - 2021-06-17 06:57:27 --> URI Class Initialized
INFO - 2021-06-17 06:57:27 --> Router Class Initialized
INFO - 2021-06-17 06:57:27 --> Output Class Initialized
INFO - 2021-06-17 06:57:27 --> Security Class Initialized
DEBUG - 2021-06-17 06:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:57:27 --> Input Class Initialized
INFO - 2021-06-17 06:57:27 --> Language Class Initialized
INFO - 2021-06-17 06:57:27 --> Language Class Initialized
INFO - 2021-06-17 06:57:27 --> Config Class Initialized
INFO - 2021-06-17 06:57:27 --> Loader Class Initialized
INFO - 2021-06-17 06:57:27 --> Helper loaded: url_helper
INFO - 2021-06-17 06:57:27 --> Helper loaded: file_helper
INFO - 2021-06-17 06:57:27 --> Helper loaded: form_helper
INFO - 2021-06-17 06:57:27 --> Helper loaded: my_helper
INFO - 2021-06-17 06:57:27 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:57:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:57:27 --> Controller Class Initialized
DEBUG - 2021-06-17 06:57:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-17 06:57:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:57:27 --> Final output sent to browser
DEBUG - 2021-06-17 06:57:27 --> Total execution time: 0.0512
INFO - 2021-06-17 06:57:40 --> Config Class Initialized
INFO - 2021-06-17 06:57:40 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:57:40 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:57:40 --> Utf8 Class Initialized
INFO - 2021-06-17 06:57:40 --> URI Class Initialized
INFO - 2021-06-17 06:57:40 --> Router Class Initialized
INFO - 2021-06-17 06:57:40 --> Output Class Initialized
INFO - 2021-06-17 06:57:40 --> Security Class Initialized
DEBUG - 2021-06-17 06:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:57:40 --> Input Class Initialized
INFO - 2021-06-17 06:57:40 --> Language Class Initialized
INFO - 2021-06-17 06:57:40 --> Language Class Initialized
INFO - 2021-06-17 06:57:40 --> Config Class Initialized
INFO - 2021-06-17 06:57:40 --> Loader Class Initialized
INFO - 2021-06-17 06:57:40 --> Helper loaded: url_helper
INFO - 2021-06-17 06:57:40 --> Helper loaded: file_helper
INFO - 2021-06-17 06:57:40 --> Helper loaded: form_helper
INFO - 2021-06-17 06:57:40 --> Helper loaded: my_helper
INFO - 2021-06-17 06:57:40 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:57:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:57:40 --> Controller Class Initialized
DEBUG - 2021-06-17 06:57:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-17 06:57:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:57:40 --> Final output sent to browser
DEBUG - 2021-06-17 06:57:40 --> Total execution time: 0.0450
INFO - 2021-06-17 06:57:41 --> Config Class Initialized
INFO - 2021-06-17 06:57:41 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:57:41 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:57:41 --> Utf8 Class Initialized
INFO - 2021-06-17 06:57:41 --> URI Class Initialized
INFO - 2021-06-17 06:57:41 --> Router Class Initialized
INFO - 2021-06-17 06:57:41 --> Output Class Initialized
INFO - 2021-06-17 06:57:41 --> Security Class Initialized
DEBUG - 2021-06-17 06:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:57:41 --> Input Class Initialized
INFO - 2021-06-17 06:57:41 --> Language Class Initialized
INFO - 2021-06-17 06:57:41 --> Language Class Initialized
INFO - 2021-06-17 06:57:41 --> Config Class Initialized
INFO - 2021-06-17 06:57:41 --> Loader Class Initialized
INFO - 2021-06-17 06:57:41 --> Helper loaded: url_helper
INFO - 2021-06-17 06:57:41 --> Helper loaded: file_helper
INFO - 2021-06-17 06:57:41 --> Helper loaded: form_helper
INFO - 2021-06-17 06:57:41 --> Helper loaded: my_helper
INFO - 2021-06-17 06:57:41 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:57:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:57:41 --> Controller Class Initialized
INFO - 2021-06-17 06:57:41 --> Config Class Initialized
INFO - 2021-06-17 06:57:41 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:57:41 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:57:41 --> Utf8 Class Initialized
INFO - 2021-06-17 06:57:41 --> URI Class Initialized
INFO - 2021-06-17 06:57:41 --> Router Class Initialized
INFO - 2021-06-17 06:57:41 --> Output Class Initialized
INFO - 2021-06-17 06:57:41 --> Security Class Initialized
DEBUG - 2021-06-17 06:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:57:41 --> Input Class Initialized
INFO - 2021-06-17 06:57:41 --> Language Class Initialized
INFO - 2021-06-17 06:57:41 --> Language Class Initialized
INFO - 2021-06-17 06:57:41 --> Config Class Initialized
INFO - 2021-06-17 06:57:41 --> Loader Class Initialized
INFO - 2021-06-17 06:57:41 --> Helper loaded: url_helper
INFO - 2021-06-17 06:57:41 --> Helper loaded: file_helper
INFO - 2021-06-17 06:57:41 --> Helper loaded: form_helper
INFO - 2021-06-17 06:57:41 --> Helper loaded: my_helper
INFO - 2021-06-17 06:57:41 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:57:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:57:41 --> Controller Class Initialized
DEBUG - 2021-06-17 06:57:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 06:57:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:57:41 --> Final output sent to browser
DEBUG - 2021-06-17 06:57:41 --> Total execution time: 0.0437
INFO - 2021-06-17 06:57:43 --> Config Class Initialized
INFO - 2021-06-17 06:57:43 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:57:43 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:57:43 --> Utf8 Class Initialized
INFO - 2021-06-17 06:57:43 --> URI Class Initialized
INFO - 2021-06-17 06:57:43 --> Router Class Initialized
INFO - 2021-06-17 06:57:43 --> Output Class Initialized
INFO - 2021-06-17 06:57:43 --> Security Class Initialized
DEBUG - 2021-06-17 06:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:57:43 --> Input Class Initialized
INFO - 2021-06-17 06:57:43 --> Language Class Initialized
INFO - 2021-06-17 06:57:43 --> Language Class Initialized
INFO - 2021-06-17 06:57:43 --> Config Class Initialized
INFO - 2021-06-17 06:57:43 --> Loader Class Initialized
INFO - 2021-06-17 06:57:43 --> Helper loaded: url_helper
INFO - 2021-06-17 06:57:43 --> Helper loaded: file_helper
INFO - 2021-06-17 06:57:43 --> Helper loaded: form_helper
INFO - 2021-06-17 06:57:43 --> Helper loaded: my_helper
INFO - 2021-06-17 06:57:43 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:57:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:57:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:57:43 --> Controller Class Initialized
INFO - 2021-06-17 06:57:44 --> Config Class Initialized
INFO - 2021-06-17 06:57:44 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:57:44 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:57:44 --> Utf8 Class Initialized
INFO - 2021-06-17 06:57:44 --> URI Class Initialized
INFO - 2021-06-17 06:57:44 --> Router Class Initialized
INFO - 2021-06-17 06:57:44 --> Output Class Initialized
INFO - 2021-06-17 06:57:44 --> Security Class Initialized
DEBUG - 2021-06-17 06:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:57:44 --> Input Class Initialized
INFO - 2021-06-17 06:57:44 --> Language Class Initialized
INFO - 2021-06-17 06:57:44 --> Language Class Initialized
INFO - 2021-06-17 06:57:44 --> Config Class Initialized
INFO - 2021-06-17 06:57:44 --> Loader Class Initialized
INFO - 2021-06-17 06:57:44 --> Helper loaded: url_helper
INFO - 2021-06-17 06:57:44 --> Helper loaded: file_helper
INFO - 2021-06-17 06:57:44 --> Helper loaded: form_helper
INFO - 2021-06-17 06:57:44 --> Helper loaded: my_helper
INFO - 2021-06-17 06:57:44 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:57:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:57:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:57:44 --> Controller Class Initialized
INFO - 2021-06-17 06:57:48 --> Config Class Initialized
INFO - 2021-06-17 06:57:48 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:57:48 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:57:48 --> Utf8 Class Initialized
INFO - 2021-06-17 06:57:48 --> URI Class Initialized
INFO - 2021-06-17 06:57:48 --> Router Class Initialized
INFO - 2021-06-17 06:57:48 --> Output Class Initialized
INFO - 2021-06-17 06:57:48 --> Security Class Initialized
DEBUG - 2021-06-17 06:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:57:48 --> Input Class Initialized
INFO - 2021-06-17 06:57:48 --> Language Class Initialized
INFO - 2021-06-17 06:57:48 --> Language Class Initialized
INFO - 2021-06-17 06:57:48 --> Config Class Initialized
INFO - 2021-06-17 06:57:48 --> Loader Class Initialized
INFO - 2021-06-17 06:57:48 --> Helper loaded: url_helper
INFO - 2021-06-17 06:57:48 --> Helper loaded: file_helper
INFO - 2021-06-17 06:57:48 --> Helper loaded: form_helper
INFO - 2021-06-17 06:57:48 --> Helper loaded: my_helper
INFO - 2021-06-17 06:57:48 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:57:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:57:48 --> Controller Class Initialized
DEBUG - 2021-06-17 06:57:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-17 06:57:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:57:48 --> Final output sent to browser
DEBUG - 2021-06-17 06:57:48 --> Total execution time: 0.0455
INFO - 2021-06-17 06:57:49 --> Config Class Initialized
INFO - 2021-06-17 06:57:49 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:57:49 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:57:49 --> Utf8 Class Initialized
INFO - 2021-06-17 06:57:49 --> URI Class Initialized
INFO - 2021-06-17 06:57:49 --> Router Class Initialized
INFO - 2021-06-17 06:57:49 --> Output Class Initialized
INFO - 2021-06-17 06:57:49 --> Security Class Initialized
DEBUG - 2021-06-17 06:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:57:49 --> Input Class Initialized
INFO - 2021-06-17 06:57:49 --> Language Class Initialized
INFO - 2021-06-17 06:57:49 --> Language Class Initialized
INFO - 2021-06-17 06:57:49 --> Config Class Initialized
INFO - 2021-06-17 06:57:49 --> Loader Class Initialized
INFO - 2021-06-17 06:57:49 --> Helper loaded: url_helper
INFO - 2021-06-17 06:57:49 --> Helper loaded: file_helper
INFO - 2021-06-17 06:57:49 --> Helper loaded: form_helper
INFO - 2021-06-17 06:57:49 --> Helper loaded: my_helper
INFO - 2021-06-17 06:57:49 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:57:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:57:49 --> Controller Class Initialized
INFO - 2021-06-17 06:57:49 --> Config Class Initialized
INFO - 2021-06-17 06:57:49 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:57:49 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:57:49 --> Utf8 Class Initialized
INFO - 2021-06-17 06:57:49 --> URI Class Initialized
INFO - 2021-06-17 06:57:49 --> Router Class Initialized
INFO - 2021-06-17 06:57:49 --> Output Class Initialized
INFO - 2021-06-17 06:57:49 --> Security Class Initialized
DEBUG - 2021-06-17 06:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:57:49 --> Input Class Initialized
INFO - 2021-06-17 06:57:49 --> Language Class Initialized
INFO - 2021-06-17 06:57:49 --> Language Class Initialized
INFO - 2021-06-17 06:57:49 --> Config Class Initialized
INFO - 2021-06-17 06:57:49 --> Loader Class Initialized
INFO - 2021-06-17 06:57:49 --> Helper loaded: url_helper
INFO - 2021-06-17 06:57:49 --> Helper loaded: file_helper
INFO - 2021-06-17 06:57:49 --> Helper loaded: form_helper
INFO - 2021-06-17 06:57:49 --> Helper loaded: my_helper
INFO - 2021-06-17 06:57:49 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:57:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:57:49 --> Controller Class Initialized
DEBUG - 2021-06-17 06:57:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 06:57:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:57:49 --> Final output sent to browser
DEBUG - 2021-06-17 06:57:49 --> Total execution time: 0.0447
INFO - 2021-06-17 06:57:51 --> Config Class Initialized
INFO - 2021-06-17 06:57:51 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:57:51 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:57:51 --> Utf8 Class Initialized
INFO - 2021-06-17 06:57:51 --> URI Class Initialized
INFO - 2021-06-17 06:57:51 --> Router Class Initialized
INFO - 2021-06-17 06:57:51 --> Output Class Initialized
INFO - 2021-06-17 06:57:51 --> Security Class Initialized
DEBUG - 2021-06-17 06:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:57:51 --> Input Class Initialized
INFO - 2021-06-17 06:57:51 --> Language Class Initialized
INFO - 2021-06-17 06:57:51 --> Language Class Initialized
INFO - 2021-06-17 06:57:51 --> Config Class Initialized
INFO - 2021-06-17 06:57:51 --> Loader Class Initialized
INFO - 2021-06-17 06:57:51 --> Helper loaded: url_helper
INFO - 2021-06-17 06:57:51 --> Helper loaded: file_helper
INFO - 2021-06-17 06:57:51 --> Helper loaded: form_helper
INFO - 2021-06-17 06:57:51 --> Helper loaded: my_helper
INFO - 2021-06-17 06:57:51 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:57:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:57:51 --> Controller Class Initialized
INFO - 2021-06-17 06:57:52 --> Config Class Initialized
INFO - 2021-06-17 06:57:52 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:57:52 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:57:52 --> Utf8 Class Initialized
INFO - 2021-06-17 06:57:52 --> URI Class Initialized
INFO - 2021-06-17 06:57:52 --> Router Class Initialized
INFO - 2021-06-17 06:57:52 --> Output Class Initialized
INFO - 2021-06-17 06:57:52 --> Security Class Initialized
DEBUG - 2021-06-17 06:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:57:52 --> Input Class Initialized
INFO - 2021-06-17 06:57:52 --> Language Class Initialized
INFO - 2021-06-17 06:57:52 --> Language Class Initialized
INFO - 2021-06-17 06:57:52 --> Config Class Initialized
INFO - 2021-06-17 06:57:52 --> Loader Class Initialized
INFO - 2021-06-17 06:57:52 --> Helper loaded: url_helper
INFO - 2021-06-17 06:57:52 --> Helper loaded: file_helper
INFO - 2021-06-17 06:57:52 --> Helper loaded: form_helper
INFO - 2021-06-17 06:57:52 --> Helper loaded: my_helper
INFO - 2021-06-17 06:57:52 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:57:52 --> Controller Class Initialized
INFO - 2021-06-17 06:57:55 --> Config Class Initialized
INFO - 2021-06-17 06:57:55 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:57:55 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:57:55 --> Utf8 Class Initialized
INFO - 2021-06-17 06:57:55 --> URI Class Initialized
INFO - 2021-06-17 06:57:55 --> Router Class Initialized
INFO - 2021-06-17 06:57:55 --> Output Class Initialized
INFO - 2021-06-17 06:57:55 --> Security Class Initialized
DEBUG - 2021-06-17 06:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:57:55 --> Input Class Initialized
INFO - 2021-06-17 06:57:55 --> Language Class Initialized
INFO - 2021-06-17 06:57:55 --> Language Class Initialized
INFO - 2021-06-17 06:57:55 --> Config Class Initialized
INFO - 2021-06-17 06:57:55 --> Loader Class Initialized
INFO - 2021-06-17 06:57:55 --> Helper loaded: url_helper
INFO - 2021-06-17 06:57:55 --> Helper loaded: file_helper
INFO - 2021-06-17 06:57:55 --> Helper loaded: form_helper
INFO - 2021-06-17 06:57:55 --> Helper loaded: my_helper
INFO - 2021-06-17 06:57:55 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:57:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:57:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:57:55 --> Controller Class Initialized
DEBUG - 2021-06-17 06:57:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-17 06:57:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:57:55 --> Final output sent to browser
DEBUG - 2021-06-17 06:57:55 --> Total execution time: 0.0466
INFO - 2021-06-17 06:57:55 --> Config Class Initialized
INFO - 2021-06-17 06:57:55 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:57:55 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:57:55 --> Utf8 Class Initialized
INFO - 2021-06-17 06:57:55 --> URI Class Initialized
INFO - 2021-06-17 06:57:55 --> Router Class Initialized
INFO - 2021-06-17 06:57:55 --> Output Class Initialized
INFO - 2021-06-17 06:57:55 --> Security Class Initialized
DEBUG - 2021-06-17 06:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:57:55 --> Input Class Initialized
INFO - 2021-06-17 06:57:55 --> Language Class Initialized
INFO - 2021-06-17 06:57:55 --> Language Class Initialized
INFO - 2021-06-17 06:57:55 --> Config Class Initialized
INFO - 2021-06-17 06:57:55 --> Loader Class Initialized
INFO - 2021-06-17 06:57:55 --> Helper loaded: url_helper
INFO - 2021-06-17 06:57:55 --> Helper loaded: file_helper
INFO - 2021-06-17 06:57:55 --> Helper loaded: form_helper
INFO - 2021-06-17 06:57:55 --> Helper loaded: my_helper
INFO - 2021-06-17 06:57:55 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:57:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:57:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:57:55 --> Controller Class Initialized
INFO - 2021-06-17 06:57:55 --> Config Class Initialized
INFO - 2021-06-17 06:57:55 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:57:55 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:57:55 --> Utf8 Class Initialized
INFO - 2021-06-17 06:57:55 --> URI Class Initialized
INFO - 2021-06-17 06:57:55 --> Router Class Initialized
INFO - 2021-06-17 06:57:55 --> Output Class Initialized
INFO - 2021-06-17 06:57:55 --> Security Class Initialized
DEBUG - 2021-06-17 06:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:57:55 --> Input Class Initialized
INFO - 2021-06-17 06:57:55 --> Language Class Initialized
INFO - 2021-06-17 06:57:55 --> Language Class Initialized
INFO - 2021-06-17 06:57:55 --> Config Class Initialized
INFO - 2021-06-17 06:57:55 --> Loader Class Initialized
INFO - 2021-06-17 06:57:55 --> Helper loaded: url_helper
INFO - 2021-06-17 06:57:55 --> Helper loaded: file_helper
INFO - 2021-06-17 06:57:56 --> Helper loaded: form_helper
INFO - 2021-06-17 06:57:56 --> Helper loaded: my_helper
INFO - 2021-06-17 06:57:56 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:57:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:57:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:57:56 --> Controller Class Initialized
DEBUG - 2021-06-17 06:57:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 06:57:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:57:56 --> Final output sent to browser
DEBUG - 2021-06-17 06:57:56 --> Total execution time: 0.0449
INFO - 2021-06-17 06:57:57 --> Config Class Initialized
INFO - 2021-06-17 06:57:57 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:57:57 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:57:57 --> Utf8 Class Initialized
INFO - 2021-06-17 06:57:57 --> URI Class Initialized
INFO - 2021-06-17 06:57:57 --> Router Class Initialized
INFO - 2021-06-17 06:57:57 --> Output Class Initialized
INFO - 2021-06-17 06:57:57 --> Security Class Initialized
DEBUG - 2021-06-17 06:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:57:57 --> Input Class Initialized
INFO - 2021-06-17 06:57:57 --> Language Class Initialized
INFO - 2021-06-17 06:57:57 --> Language Class Initialized
INFO - 2021-06-17 06:57:57 --> Config Class Initialized
INFO - 2021-06-17 06:57:57 --> Loader Class Initialized
INFO - 2021-06-17 06:57:57 --> Helper loaded: url_helper
INFO - 2021-06-17 06:57:57 --> Helper loaded: file_helper
INFO - 2021-06-17 06:57:57 --> Helper loaded: form_helper
INFO - 2021-06-17 06:57:57 --> Helper loaded: my_helper
INFO - 2021-06-17 06:57:57 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:57:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:57:57 --> Controller Class Initialized
INFO - 2021-06-17 06:57:58 --> Config Class Initialized
INFO - 2021-06-17 06:57:58 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:57:58 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:57:58 --> Utf8 Class Initialized
INFO - 2021-06-17 06:57:58 --> URI Class Initialized
INFO - 2021-06-17 06:57:58 --> Router Class Initialized
INFO - 2021-06-17 06:57:58 --> Output Class Initialized
INFO - 2021-06-17 06:57:58 --> Security Class Initialized
DEBUG - 2021-06-17 06:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:57:58 --> Input Class Initialized
INFO - 2021-06-17 06:57:58 --> Language Class Initialized
INFO - 2021-06-17 06:57:58 --> Language Class Initialized
INFO - 2021-06-17 06:57:58 --> Config Class Initialized
INFO - 2021-06-17 06:57:58 --> Loader Class Initialized
INFO - 2021-06-17 06:57:58 --> Helper loaded: url_helper
INFO - 2021-06-17 06:57:58 --> Helper loaded: file_helper
INFO - 2021-06-17 06:57:58 --> Helper loaded: form_helper
INFO - 2021-06-17 06:57:58 --> Helper loaded: my_helper
INFO - 2021-06-17 06:57:58 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:57:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:57:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:57:58 --> Controller Class Initialized
INFO - 2021-06-17 06:58:16 --> Config Class Initialized
INFO - 2021-06-17 06:58:16 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:58:16 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:58:16 --> Utf8 Class Initialized
INFO - 2021-06-17 06:58:16 --> URI Class Initialized
INFO - 2021-06-17 06:58:16 --> Router Class Initialized
INFO - 2021-06-17 06:58:16 --> Output Class Initialized
INFO - 2021-06-17 06:58:16 --> Security Class Initialized
DEBUG - 2021-06-17 06:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:58:16 --> Input Class Initialized
INFO - 2021-06-17 06:58:16 --> Language Class Initialized
INFO - 2021-06-17 06:58:16 --> Language Class Initialized
INFO - 2021-06-17 06:58:16 --> Config Class Initialized
INFO - 2021-06-17 06:58:16 --> Loader Class Initialized
INFO - 2021-06-17 06:58:16 --> Helper loaded: url_helper
INFO - 2021-06-17 06:58:16 --> Helper loaded: file_helper
INFO - 2021-06-17 06:58:16 --> Helper loaded: form_helper
INFO - 2021-06-17 06:58:16 --> Helper loaded: my_helper
INFO - 2021-06-17 06:58:16 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:58:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:58:16 --> Controller Class Initialized
DEBUG - 2021-06-17 06:58:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-17 06:58:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:58:16 --> Final output sent to browser
DEBUG - 2021-06-17 06:58:16 --> Total execution time: 0.0443
INFO - 2021-06-17 06:58:16 --> Config Class Initialized
INFO - 2021-06-17 06:58:16 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:58:16 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:58:16 --> Utf8 Class Initialized
INFO - 2021-06-17 06:58:16 --> URI Class Initialized
INFO - 2021-06-17 06:58:16 --> Router Class Initialized
INFO - 2021-06-17 06:58:16 --> Output Class Initialized
INFO - 2021-06-17 06:58:16 --> Security Class Initialized
DEBUG - 2021-06-17 06:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:58:16 --> Input Class Initialized
INFO - 2021-06-17 06:58:16 --> Language Class Initialized
INFO - 2021-06-17 06:58:16 --> Language Class Initialized
INFO - 2021-06-17 06:58:16 --> Config Class Initialized
INFO - 2021-06-17 06:58:16 --> Loader Class Initialized
INFO - 2021-06-17 06:58:16 --> Helper loaded: url_helper
INFO - 2021-06-17 06:58:16 --> Helper loaded: file_helper
INFO - 2021-06-17 06:58:16 --> Helper loaded: form_helper
INFO - 2021-06-17 06:58:16 --> Helper loaded: my_helper
INFO - 2021-06-17 06:58:16 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:58:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:58:16 --> Controller Class Initialized
INFO - 2021-06-17 06:58:17 --> Config Class Initialized
INFO - 2021-06-17 06:58:17 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:58:17 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:58:17 --> Utf8 Class Initialized
INFO - 2021-06-17 06:58:17 --> URI Class Initialized
INFO - 2021-06-17 06:58:17 --> Router Class Initialized
INFO - 2021-06-17 06:58:17 --> Output Class Initialized
INFO - 2021-06-17 06:58:17 --> Security Class Initialized
DEBUG - 2021-06-17 06:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:58:17 --> Input Class Initialized
INFO - 2021-06-17 06:58:17 --> Language Class Initialized
INFO - 2021-06-17 06:58:17 --> Language Class Initialized
INFO - 2021-06-17 06:58:17 --> Config Class Initialized
INFO - 2021-06-17 06:58:17 --> Loader Class Initialized
INFO - 2021-06-17 06:58:17 --> Helper loaded: url_helper
INFO - 2021-06-17 06:58:17 --> Helper loaded: file_helper
INFO - 2021-06-17 06:58:17 --> Helper loaded: form_helper
INFO - 2021-06-17 06:58:17 --> Helper loaded: my_helper
INFO - 2021-06-17 06:58:17 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:58:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:58:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:58:17 --> Controller Class Initialized
DEBUG - 2021-06-17 06:58:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 06:58:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:58:17 --> Final output sent to browser
DEBUG - 2021-06-17 06:58:17 --> Total execution time: 0.0447
INFO - 2021-06-17 06:58:19 --> Config Class Initialized
INFO - 2021-06-17 06:58:19 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:58:19 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:58:19 --> Utf8 Class Initialized
INFO - 2021-06-17 06:58:19 --> URI Class Initialized
INFO - 2021-06-17 06:58:19 --> Router Class Initialized
INFO - 2021-06-17 06:58:19 --> Output Class Initialized
INFO - 2021-06-17 06:58:19 --> Security Class Initialized
DEBUG - 2021-06-17 06:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:58:19 --> Input Class Initialized
INFO - 2021-06-17 06:58:19 --> Language Class Initialized
INFO - 2021-06-17 06:58:19 --> Language Class Initialized
INFO - 2021-06-17 06:58:19 --> Config Class Initialized
INFO - 2021-06-17 06:58:19 --> Loader Class Initialized
INFO - 2021-06-17 06:58:19 --> Helper loaded: url_helper
INFO - 2021-06-17 06:58:19 --> Helper loaded: file_helper
INFO - 2021-06-17 06:58:19 --> Helper loaded: form_helper
INFO - 2021-06-17 06:58:19 --> Helper loaded: my_helper
INFO - 2021-06-17 06:58:19 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:58:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:58:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:58:19 --> Controller Class Initialized
INFO - 2021-06-17 06:58:21 --> Config Class Initialized
INFO - 2021-06-17 06:58:21 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:58:21 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:58:21 --> Utf8 Class Initialized
INFO - 2021-06-17 06:58:21 --> URI Class Initialized
INFO - 2021-06-17 06:58:21 --> Router Class Initialized
INFO - 2021-06-17 06:58:21 --> Output Class Initialized
INFO - 2021-06-17 06:58:21 --> Security Class Initialized
DEBUG - 2021-06-17 06:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:58:21 --> Input Class Initialized
INFO - 2021-06-17 06:58:21 --> Language Class Initialized
INFO - 2021-06-17 06:58:21 --> Language Class Initialized
INFO - 2021-06-17 06:58:21 --> Config Class Initialized
INFO - 2021-06-17 06:58:21 --> Loader Class Initialized
INFO - 2021-06-17 06:58:21 --> Helper loaded: url_helper
INFO - 2021-06-17 06:58:21 --> Helper loaded: file_helper
INFO - 2021-06-17 06:58:21 --> Helper loaded: form_helper
INFO - 2021-06-17 06:58:21 --> Helper loaded: my_helper
INFO - 2021-06-17 06:58:21 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:58:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:58:21 --> Controller Class Initialized
INFO - 2021-06-17 06:58:36 --> Config Class Initialized
INFO - 2021-06-17 06:58:36 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:58:36 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:58:36 --> Utf8 Class Initialized
INFO - 2021-06-17 06:58:36 --> URI Class Initialized
INFO - 2021-06-17 06:58:36 --> Router Class Initialized
INFO - 2021-06-17 06:58:36 --> Output Class Initialized
INFO - 2021-06-17 06:58:36 --> Security Class Initialized
DEBUG - 2021-06-17 06:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:58:36 --> Input Class Initialized
INFO - 2021-06-17 06:58:36 --> Language Class Initialized
INFO - 2021-06-17 06:58:37 --> Language Class Initialized
INFO - 2021-06-17 06:58:37 --> Config Class Initialized
INFO - 2021-06-17 06:58:37 --> Loader Class Initialized
INFO - 2021-06-17 06:58:37 --> Helper loaded: url_helper
INFO - 2021-06-17 06:58:37 --> Helper loaded: file_helper
INFO - 2021-06-17 06:58:37 --> Helper loaded: form_helper
INFO - 2021-06-17 06:58:37 --> Helper loaded: my_helper
INFO - 2021-06-17 06:58:37 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:58:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:58:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:58:37 --> Controller Class Initialized
DEBUG - 2021-06-17 06:58:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-17 06:58:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:58:37 --> Final output sent to browser
DEBUG - 2021-06-17 06:58:37 --> Total execution time: 0.0451
INFO - 2021-06-17 06:58:37 --> Config Class Initialized
INFO - 2021-06-17 06:58:37 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:58:37 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:58:37 --> Utf8 Class Initialized
INFO - 2021-06-17 06:58:37 --> URI Class Initialized
INFO - 2021-06-17 06:58:37 --> Router Class Initialized
INFO - 2021-06-17 06:58:37 --> Output Class Initialized
INFO - 2021-06-17 06:58:37 --> Security Class Initialized
DEBUG - 2021-06-17 06:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:58:37 --> Input Class Initialized
INFO - 2021-06-17 06:58:37 --> Language Class Initialized
INFO - 2021-06-17 06:58:37 --> Language Class Initialized
INFO - 2021-06-17 06:58:37 --> Config Class Initialized
INFO - 2021-06-17 06:58:37 --> Loader Class Initialized
INFO - 2021-06-17 06:58:37 --> Helper loaded: url_helper
INFO - 2021-06-17 06:58:37 --> Helper loaded: file_helper
INFO - 2021-06-17 06:58:37 --> Helper loaded: form_helper
INFO - 2021-06-17 06:58:37 --> Helper loaded: my_helper
INFO - 2021-06-17 06:58:37 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:58:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:58:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:58:37 --> Controller Class Initialized
INFO - 2021-06-17 06:58:38 --> Config Class Initialized
INFO - 2021-06-17 06:58:38 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:58:38 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:58:38 --> Utf8 Class Initialized
INFO - 2021-06-17 06:58:38 --> URI Class Initialized
INFO - 2021-06-17 06:58:38 --> Router Class Initialized
INFO - 2021-06-17 06:58:38 --> Output Class Initialized
INFO - 2021-06-17 06:58:38 --> Security Class Initialized
DEBUG - 2021-06-17 06:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:58:38 --> Input Class Initialized
INFO - 2021-06-17 06:58:38 --> Language Class Initialized
INFO - 2021-06-17 06:58:38 --> Language Class Initialized
INFO - 2021-06-17 06:58:38 --> Config Class Initialized
INFO - 2021-06-17 06:58:38 --> Loader Class Initialized
INFO - 2021-06-17 06:58:38 --> Helper loaded: url_helper
INFO - 2021-06-17 06:58:38 --> Helper loaded: file_helper
INFO - 2021-06-17 06:58:38 --> Helper loaded: form_helper
INFO - 2021-06-17 06:58:38 --> Helper loaded: my_helper
INFO - 2021-06-17 06:58:38 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:58:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:58:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:58:38 --> Controller Class Initialized
DEBUG - 2021-06-17 06:58:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 06:58:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:58:38 --> Final output sent to browser
DEBUG - 2021-06-17 06:58:38 --> Total execution time: 0.0447
INFO - 2021-06-17 06:58:39 --> Config Class Initialized
INFO - 2021-06-17 06:58:39 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:58:39 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:58:39 --> Utf8 Class Initialized
INFO - 2021-06-17 06:58:39 --> URI Class Initialized
INFO - 2021-06-17 06:58:39 --> Router Class Initialized
INFO - 2021-06-17 06:58:39 --> Output Class Initialized
INFO - 2021-06-17 06:58:39 --> Security Class Initialized
DEBUG - 2021-06-17 06:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:58:39 --> Input Class Initialized
INFO - 2021-06-17 06:58:39 --> Language Class Initialized
INFO - 2021-06-17 06:58:39 --> Language Class Initialized
INFO - 2021-06-17 06:58:39 --> Config Class Initialized
INFO - 2021-06-17 06:58:39 --> Loader Class Initialized
INFO - 2021-06-17 06:58:39 --> Helper loaded: url_helper
INFO - 2021-06-17 06:58:39 --> Helper loaded: file_helper
INFO - 2021-06-17 06:58:39 --> Helper loaded: form_helper
INFO - 2021-06-17 06:58:39 --> Helper loaded: my_helper
INFO - 2021-06-17 06:58:39 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:58:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:58:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:58:39 --> Controller Class Initialized
INFO - 2021-06-17 06:58:40 --> Config Class Initialized
INFO - 2021-06-17 06:58:40 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:58:40 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:58:40 --> Utf8 Class Initialized
INFO - 2021-06-17 06:58:40 --> URI Class Initialized
INFO - 2021-06-17 06:58:40 --> Router Class Initialized
INFO - 2021-06-17 06:58:40 --> Output Class Initialized
INFO - 2021-06-17 06:58:40 --> Security Class Initialized
DEBUG - 2021-06-17 06:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:58:40 --> Input Class Initialized
INFO - 2021-06-17 06:58:40 --> Language Class Initialized
INFO - 2021-06-17 06:58:40 --> Language Class Initialized
INFO - 2021-06-17 06:58:40 --> Config Class Initialized
INFO - 2021-06-17 06:58:40 --> Loader Class Initialized
INFO - 2021-06-17 06:58:40 --> Helper loaded: url_helper
INFO - 2021-06-17 06:58:40 --> Helper loaded: file_helper
INFO - 2021-06-17 06:58:40 --> Helper loaded: form_helper
INFO - 2021-06-17 06:58:40 --> Helper loaded: my_helper
INFO - 2021-06-17 06:58:40 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:58:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:58:40 --> Controller Class Initialized
INFO - 2021-06-17 06:59:05 --> Config Class Initialized
INFO - 2021-06-17 06:59:05 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:59:05 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:59:05 --> Utf8 Class Initialized
INFO - 2021-06-17 06:59:05 --> URI Class Initialized
INFO - 2021-06-17 06:59:05 --> Router Class Initialized
INFO - 2021-06-17 06:59:05 --> Output Class Initialized
INFO - 2021-06-17 06:59:05 --> Security Class Initialized
DEBUG - 2021-06-17 06:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:59:05 --> Input Class Initialized
INFO - 2021-06-17 06:59:05 --> Language Class Initialized
INFO - 2021-06-17 06:59:05 --> Language Class Initialized
INFO - 2021-06-17 06:59:05 --> Config Class Initialized
INFO - 2021-06-17 06:59:05 --> Loader Class Initialized
INFO - 2021-06-17 06:59:05 --> Helper loaded: url_helper
INFO - 2021-06-17 06:59:05 --> Helper loaded: file_helper
INFO - 2021-06-17 06:59:05 --> Helper loaded: form_helper
INFO - 2021-06-17 06:59:05 --> Helper loaded: my_helper
INFO - 2021-06-17 06:59:05 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:59:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:59:05 --> Controller Class Initialized
DEBUG - 2021-06-17 06:59:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-17 06:59:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:59:05 --> Final output sent to browser
DEBUG - 2021-06-17 06:59:05 --> Total execution time: 0.0518
INFO - 2021-06-17 06:59:05 --> Config Class Initialized
INFO - 2021-06-17 06:59:05 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:59:05 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:59:05 --> Utf8 Class Initialized
INFO - 2021-06-17 06:59:05 --> URI Class Initialized
INFO - 2021-06-17 06:59:05 --> Router Class Initialized
INFO - 2021-06-17 06:59:05 --> Output Class Initialized
INFO - 2021-06-17 06:59:05 --> Security Class Initialized
DEBUG - 2021-06-17 06:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:59:05 --> Input Class Initialized
INFO - 2021-06-17 06:59:05 --> Language Class Initialized
INFO - 2021-06-17 06:59:05 --> Language Class Initialized
INFO - 2021-06-17 06:59:05 --> Config Class Initialized
INFO - 2021-06-17 06:59:05 --> Loader Class Initialized
INFO - 2021-06-17 06:59:05 --> Helper loaded: url_helper
INFO - 2021-06-17 06:59:05 --> Helper loaded: file_helper
INFO - 2021-06-17 06:59:05 --> Helper loaded: form_helper
INFO - 2021-06-17 06:59:05 --> Helper loaded: my_helper
INFO - 2021-06-17 06:59:05 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:59:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:59:05 --> Controller Class Initialized
INFO - 2021-06-17 06:59:06 --> Config Class Initialized
INFO - 2021-06-17 06:59:06 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:59:06 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:59:06 --> Utf8 Class Initialized
INFO - 2021-06-17 06:59:06 --> URI Class Initialized
INFO - 2021-06-17 06:59:06 --> Router Class Initialized
INFO - 2021-06-17 06:59:06 --> Output Class Initialized
INFO - 2021-06-17 06:59:06 --> Security Class Initialized
DEBUG - 2021-06-17 06:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:59:06 --> Input Class Initialized
INFO - 2021-06-17 06:59:06 --> Language Class Initialized
INFO - 2021-06-17 06:59:06 --> Language Class Initialized
INFO - 2021-06-17 06:59:06 --> Config Class Initialized
INFO - 2021-06-17 06:59:06 --> Loader Class Initialized
INFO - 2021-06-17 06:59:06 --> Helper loaded: url_helper
INFO - 2021-06-17 06:59:06 --> Helper loaded: file_helper
INFO - 2021-06-17 06:59:06 --> Helper loaded: form_helper
INFO - 2021-06-17 06:59:06 --> Helper loaded: my_helper
INFO - 2021-06-17 06:59:06 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:59:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:59:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:59:06 --> Controller Class Initialized
DEBUG - 2021-06-17 06:59:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-17 06:59:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:59:06 --> Final output sent to browser
DEBUG - 2021-06-17 06:59:06 --> Total execution time: 0.0400
INFO - 2021-06-17 06:59:09 --> Config Class Initialized
INFO - 2021-06-17 06:59:09 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:59:09 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:59:09 --> Utf8 Class Initialized
INFO - 2021-06-17 06:59:09 --> URI Class Initialized
INFO - 2021-06-17 06:59:09 --> Router Class Initialized
INFO - 2021-06-17 06:59:09 --> Output Class Initialized
INFO - 2021-06-17 06:59:09 --> Security Class Initialized
DEBUG - 2021-06-17 06:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:59:09 --> Input Class Initialized
INFO - 2021-06-17 06:59:09 --> Language Class Initialized
INFO - 2021-06-17 06:59:09 --> Language Class Initialized
INFO - 2021-06-17 06:59:09 --> Config Class Initialized
INFO - 2021-06-17 06:59:09 --> Loader Class Initialized
INFO - 2021-06-17 06:59:09 --> Helper loaded: url_helper
INFO - 2021-06-17 06:59:09 --> Helper loaded: file_helper
INFO - 2021-06-17 06:59:09 --> Helper loaded: form_helper
INFO - 2021-06-17 06:59:09 --> Helper loaded: my_helper
INFO - 2021-06-17 06:59:09 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:59:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:59:09 --> Controller Class Initialized
DEBUG - 2021-06-17 06:59:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-17 06:59:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:59:09 --> Final output sent to browser
DEBUG - 2021-06-17 06:59:09 --> Total execution time: 0.0437
INFO - 2021-06-17 06:59:09 --> Config Class Initialized
INFO - 2021-06-17 06:59:09 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:59:09 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:59:09 --> Utf8 Class Initialized
INFO - 2021-06-17 06:59:09 --> URI Class Initialized
INFO - 2021-06-17 06:59:09 --> Router Class Initialized
INFO - 2021-06-17 06:59:09 --> Output Class Initialized
INFO - 2021-06-17 06:59:09 --> Security Class Initialized
DEBUG - 2021-06-17 06:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:59:09 --> Input Class Initialized
INFO - 2021-06-17 06:59:09 --> Language Class Initialized
INFO - 2021-06-17 06:59:09 --> Language Class Initialized
INFO - 2021-06-17 06:59:09 --> Config Class Initialized
INFO - 2021-06-17 06:59:09 --> Loader Class Initialized
INFO - 2021-06-17 06:59:09 --> Helper loaded: url_helper
INFO - 2021-06-17 06:59:09 --> Helper loaded: file_helper
INFO - 2021-06-17 06:59:09 --> Helper loaded: form_helper
INFO - 2021-06-17 06:59:09 --> Helper loaded: my_helper
INFO - 2021-06-17 06:59:09 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:59:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:59:09 --> Controller Class Initialized
INFO - 2021-06-17 06:59:10 --> Config Class Initialized
INFO - 2021-06-17 06:59:10 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:59:10 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:59:10 --> Utf8 Class Initialized
INFO - 2021-06-17 06:59:10 --> URI Class Initialized
INFO - 2021-06-17 06:59:10 --> Router Class Initialized
INFO - 2021-06-17 06:59:10 --> Output Class Initialized
INFO - 2021-06-17 06:59:10 --> Security Class Initialized
DEBUG - 2021-06-17 06:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:59:10 --> Input Class Initialized
INFO - 2021-06-17 06:59:10 --> Language Class Initialized
INFO - 2021-06-17 06:59:10 --> Language Class Initialized
INFO - 2021-06-17 06:59:10 --> Config Class Initialized
INFO - 2021-06-17 06:59:10 --> Loader Class Initialized
INFO - 2021-06-17 06:59:10 --> Helper loaded: url_helper
INFO - 2021-06-17 06:59:10 --> Helper loaded: file_helper
INFO - 2021-06-17 06:59:10 --> Helper loaded: form_helper
INFO - 2021-06-17 06:59:10 --> Helper loaded: my_helper
INFO - 2021-06-17 06:59:10 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:59:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:59:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:59:10 --> Controller Class Initialized
DEBUG - 2021-06-17 06:59:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 06:59:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:59:10 --> Final output sent to browser
DEBUG - 2021-06-17 06:59:10 --> Total execution time: 0.0427
INFO - 2021-06-17 06:59:12 --> Config Class Initialized
INFO - 2021-06-17 06:59:12 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:59:12 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:59:12 --> Utf8 Class Initialized
INFO - 2021-06-17 06:59:12 --> URI Class Initialized
INFO - 2021-06-17 06:59:12 --> Router Class Initialized
INFO - 2021-06-17 06:59:12 --> Output Class Initialized
INFO - 2021-06-17 06:59:12 --> Security Class Initialized
DEBUG - 2021-06-17 06:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:59:12 --> Input Class Initialized
INFO - 2021-06-17 06:59:12 --> Language Class Initialized
INFO - 2021-06-17 06:59:12 --> Language Class Initialized
INFO - 2021-06-17 06:59:12 --> Config Class Initialized
INFO - 2021-06-17 06:59:12 --> Loader Class Initialized
INFO - 2021-06-17 06:59:12 --> Helper loaded: url_helper
INFO - 2021-06-17 06:59:12 --> Helper loaded: file_helper
INFO - 2021-06-17 06:59:12 --> Helper loaded: form_helper
INFO - 2021-06-17 06:59:12 --> Helper loaded: my_helper
INFO - 2021-06-17 06:59:12 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:59:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:59:12 --> Controller Class Initialized
INFO - 2021-06-17 06:59:13 --> Config Class Initialized
INFO - 2021-06-17 06:59:13 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:59:13 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:59:13 --> Utf8 Class Initialized
INFO - 2021-06-17 06:59:13 --> URI Class Initialized
INFO - 2021-06-17 06:59:13 --> Router Class Initialized
INFO - 2021-06-17 06:59:13 --> Output Class Initialized
INFO - 2021-06-17 06:59:13 --> Security Class Initialized
DEBUG - 2021-06-17 06:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:59:13 --> Input Class Initialized
INFO - 2021-06-17 06:59:13 --> Language Class Initialized
INFO - 2021-06-17 06:59:13 --> Language Class Initialized
INFO - 2021-06-17 06:59:13 --> Config Class Initialized
INFO - 2021-06-17 06:59:13 --> Loader Class Initialized
INFO - 2021-06-17 06:59:13 --> Helper loaded: url_helper
INFO - 2021-06-17 06:59:13 --> Helper loaded: file_helper
INFO - 2021-06-17 06:59:13 --> Helper loaded: form_helper
INFO - 2021-06-17 06:59:13 --> Helper loaded: my_helper
INFO - 2021-06-17 06:59:13 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:59:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:59:13 --> Controller Class Initialized
INFO - 2021-06-17 06:59:31 --> Config Class Initialized
INFO - 2021-06-17 06:59:31 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:59:31 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:59:31 --> Utf8 Class Initialized
INFO - 2021-06-17 06:59:31 --> URI Class Initialized
INFO - 2021-06-17 06:59:31 --> Router Class Initialized
INFO - 2021-06-17 06:59:31 --> Output Class Initialized
INFO - 2021-06-17 06:59:31 --> Security Class Initialized
DEBUG - 2021-06-17 06:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:59:31 --> Input Class Initialized
INFO - 2021-06-17 06:59:31 --> Language Class Initialized
INFO - 2021-06-17 06:59:31 --> Language Class Initialized
INFO - 2021-06-17 06:59:31 --> Config Class Initialized
INFO - 2021-06-17 06:59:31 --> Loader Class Initialized
INFO - 2021-06-17 06:59:31 --> Helper loaded: url_helper
INFO - 2021-06-17 06:59:31 --> Helper loaded: file_helper
INFO - 2021-06-17 06:59:31 --> Helper loaded: form_helper
INFO - 2021-06-17 06:59:31 --> Helper loaded: my_helper
INFO - 2021-06-17 06:59:31 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:59:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:59:31 --> Controller Class Initialized
DEBUG - 2021-06-17 06:59:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-17 06:59:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:59:31 --> Final output sent to browser
DEBUG - 2021-06-17 06:59:31 --> Total execution time: 0.0441
INFO - 2021-06-17 06:59:31 --> Config Class Initialized
INFO - 2021-06-17 06:59:31 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:59:31 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:59:31 --> Utf8 Class Initialized
INFO - 2021-06-17 06:59:31 --> URI Class Initialized
INFO - 2021-06-17 06:59:31 --> Router Class Initialized
INFO - 2021-06-17 06:59:31 --> Output Class Initialized
INFO - 2021-06-17 06:59:31 --> Security Class Initialized
DEBUG - 2021-06-17 06:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:59:31 --> Input Class Initialized
INFO - 2021-06-17 06:59:31 --> Language Class Initialized
INFO - 2021-06-17 06:59:31 --> Language Class Initialized
INFO - 2021-06-17 06:59:31 --> Config Class Initialized
INFO - 2021-06-17 06:59:31 --> Loader Class Initialized
INFO - 2021-06-17 06:59:31 --> Helper loaded: url_helper
INFO - 2021-06-17 06:59:31 --> Helper loaded: file_helper
INFO - 2021-06-17 06:59:31 --> Helper loaded: form_helper
INFO - 2021-06-17 06:59:31 --> Helper loaded: my_helper
INFO - 2021-06-17 06:59:31 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:59:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:59:31 --> Controller Class Initialized
INFO - 2021-06-17 06:59:32 --> Config Class Initialized
INFO - 2021-06-17 06:59:32 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:59:32 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:59:32 --> Utf8 Class Initialized
INFO - 2021-06-17 06:59:32 --> URI Class Initialized
INFO - 2021-06-17 06:59:32 --> Router Class Initialized
INFO - 2021-06-17 06:59:32 --> Output Class Initialized
INFO - 2021-06-17 06:59:32 --> Security Class Initialized
DEBUG - 2021-06-17 06:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:59:32 --> Input Class Initialized
INFO - 2021-06-17 06:59:32 --> Language Class Initialized
INFO - 2021-06-17 06:59:32 --> Language Class Initialized
INFO - 2021-06-17 06:59:32 --> Config Class Initialized
INFO - 2021-06-17 06:59:32 --> Loader Class Initialized
INFO - 2021-06-17 06:59:32 --> Helper loaded: url_helper
INFO - 2021-06-17 06:59:32 --> Helper loaded: file_helper
INFO - 2021-06-17 06:59:32 --> Helper loaded: form_helper
INFO - 2021-06-17 06:59:32 --> Helper loaded: my_helper
INFO - 2021-06-17 06:59:32 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:59:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:59:32 --> Controller Class Initialized
DEBUG - 2021-06-17 06:59:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 06:59:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:59:32 --> Final output sent to browser
DEBUG - 2021-06-17 06:59:32 --> Total execution time: 0.0452
INFO - 2021-06-17 06:59:33 --> Config Class Initialized
INFO - 2021-06-17 06:59:33 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:59:33 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:59:33 --> Utf8 Class Initialized
INFO - 2021-06-17 06:59:33 --> URI Class Initialized
INFO - 2021-06-17 06:59:33 --> Router Class Initialized
INFO - 2021-06-17 06:59:33 --> Output Class Initialized
INFO - 2021-06-17 06:59:33 --> Security Class Initialized
DEBUG - 2021-06-17 06:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:59:33 --> Input Class Initialized
INFO - 2021-06-17 06:59:33 --> Language Class Initialized
INFO - 2021-06-17 06:59:33 --> Language Class Initialized
INFO - 2021-06-17 06:59:33 --> Config Class Initialized
INFO - 2021-06-17 06:59:33 --> Loader Class Initialized
INFO - 2021-06-17 06:59:33 --> Helper loaded: url_helper
INFO - 2021-06-17 06:59:33 --> Helper loaded: file_helper
INFO - 2021-06-17 06:59:33 --> Helper loaded: form_helper
INFO - 2021-06-17 06:59:33 --> Helper loaded: my_helper
INFO - 2021-06-17 06:59:33 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:59:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:59:33 --> Controller Class Initialized
INFO - 2021-06-17 06:59:35 --> Config Class Initialized
INFO - 2021-06-17 06:59:35 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:59:35 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:59:35 --> Utf8 Class Initialized
INFO - 2021-06-17 06:59:35 --> URI Class Initialized
INFO - 2021-06-17 06:59:35 --> Router Class Initialized
INFO - 2021-06-17 06:59:35 --> Output Class Initialized
INFO - 2021-06-17 06:59:35 --> Security Class Initialized
DEBUG - 2021-06-17 06:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:59:35 --> Input Class Initialized
INFO - 2021-06-17 06:59:35 --> Language Class Initialized
INFO - 2021-06-17 06:59:35 --> Language Class Initialized
INFO - 2021-06-17 06:59:35 --> Config Class Initialized
INFO - 2021-06-17 06:59:35 --> Loader Class Initialized
INFO - 2021-06-17 06:59:35 --> Helper loaded: url_helper
INFO - 2021-06-17 06:59:35 --> Helper loaded: file_helper
INFO - 2021-06-17 06:59:35 --> Helper loaded: form_helper
INFO - 2021-06-17 06:59:35 --> Helper loaded: my_helper
INFO - 2021-06-17 06:59:35 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:59:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:59:35 --> Controller Class Initialized
INFO - 2021-06-17 06:59:50 --> Config Class Initialized
INFO - 2021-06-17 06:59:50 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:59:50 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:59:50 --> Utf8 Class Initialized
INFO - 2021-06-17 06:59:50 --> URI Class Initialized
INFO - 2021-06-17 06:59:50 --> Router Class Initialized
INFO - 2021-06-17 06:59:50 --> Output Class Initialized
INFO - 2021-06-17 06:59:50 --> Security Class Initialized
DEBUG - 2021-06-17 06:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:59:50 --> Input Class Initialized
INFO - 2021-06-17 06:59:50 --> Language Class Initialized
INFO - 2021-06-17 06:59:50 --> Language Class Initialized
INFO - 2021-06-17 06:59:50 --> Config Class Initialized
INFO - 2021-06-17 06:59:50 --> Loader Class Initialized
INFO - 2021-06-17 06:59:50 --> Helper loaded: url_helper
INFO - 2021-06-17 06:59:50 --> Helper loaded: file_helper
INFO - 2021-06-17 06:59:50 --> Helper loaded: form_helper
INFO - 2021-06-17 06:59:50 --> Helper loaded: my_helper
INFO - 2021-06-17 06:59:50 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:59:51 --> Controller Class Initialized
DEBUG - 2021-06-17 06:59:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-17 06:59:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:59:51 --> Final output sent to browser
DEBUG - 2021-06-17 06:59:51 --> Total execution time: 0.0440
INFO - 2021-06-17 06:59:51 --> Config Class Initialized
INFO - 2021-06-17 06:59:51 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:59:51 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:59:51 --> Utf8 Class Initialized
INFO - 2021-06-17 06:59:51 --> URI Class Initialized
INFO - 2021-06-17 06:59:51 --> Router Class Initialized
INFO - 2021-06-17 06:59:51 --> Output Class Initialized
INFO - 2021-06-17 06:59:51 --> Security Class Initialized
DEBUG - 2021-06-17 06:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:59:51 --> Input Class Initialized
INFO - 2021-06-17 06:59:51 --> Language Class Initialized
INFO - 2021-06-17 06:59:51 --> Language Class Initialized
INFO - 2021-06-17 06:59:51 --> Config Class Initialized
INFO - 2021-06-17 06:59:51 --> Loader Class Initialized
INFO - 2021-06-17 06:59:51 --> Helper loaded: url_helper
INFO - 2021-06-17 06:59:51 --> Helper loaded: file_helper
INFO - 2021-06-17 06:59:51 --> Helper loaded: form_helper
INFO - 2021-06-17 06:59:51 --> Helper loaded: my_helper
INFO - 2021-06-17 06:59:51 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:59:51 --> Controller Class Initialized
INFO - 2021-06-17 06:59:52 --> Config Class Initialized
INFO - 2021-06-17 06:59:52 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:59:52 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:59:52 --> Utf8 Class Initialized
INFO - 2021-06-17 06:59:52 --> URI Class Initialized
INFO - 2021-06-17 06:59:52 --> Router Class Initialized
INFO - 2021-06-17 06:59:52 --> Output Class Initialized
INFO - 2021-06-17 06:59:52 --> Security Class Initialized
DEBUG - 2021-06-17 06:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:59:52 --> Input Class Initialized
INFO - 2021-06-17 06:59:52 --> Language Class Initialized
INFO - 2021-06-17 06:59:52 --> Language Class Initialized
INFO - 2021-06-17 06:59:52 --> Config Class Initialized
INFO - 2021-06-17 06:59:52 --> Loader Class Initialized
INFO - 2021-06-17 06:59:52 --> Helper loaded: url_helper
INFO - 2021-06-17 06:59:52 --> Helper loaded: file_helper
INFO - 2021-06-17 06:59:52 --> Helper loaded: form_helper
INFO - 2021-06-17 06:59:52 --> Helper loaded: my_helper
INFO - 2021-06-17 06:59:52 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:59:52 --> Controller Class Initialized
DEBUG - 2021-06-17 06:59:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 06:59:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 06:59:52 --> Final output sent to browser
DEBUG - 2021-06-17 06:59:52 --> Total execution time: 0.0459
INFO - 2021-06-17 06:59:53 --> Config Class Initialized
INFO - 2021-06-17 06:59:53 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:59:53 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:59:53 --> Utf8 Class Initialized
INFO - 2021-06-17 06:59:53 --> URI Class Initialized
INFO - 2021-06-17 06:59:53 --> Router Class Initialized
INFO - 2021-06-17 06:59:53 --> Output Class Initialized
INFO - 2021-06-17 06:59:53 --> Security Class Initialized
DEBUG - 2021-06-17 06:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:59:53 --> Input Class Initialized
INFO - 2021-06-17 06:59:53 --> Language Class Initialized
INFO - 2021-06-17 06:59:53 --> Language Class Initialized
INFO - 2021-06-17 06:59:53 --> Config Class Initialized
INFO - 2021-06-17 06:59:53 --> Loader Class Initialized
INFO - 2021-06-17 06:59:53 --> Helper loaded: url_helper
INFO - 2021-06-17 06:59:53 --> Helper loaded: file_helper
INFO - 2021-06-17 06:59:53 --> Helper loaded: form_helper
INFO - 2021-06-17 06:59:53 --> Helper loaded: my_helper
INFO - 2021-06-17 06:59:53 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:59:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:59:53 --> Controller Class Initialized
INFO - 2021-06-17 06:59:54 --> Config Class Initialized
INFO - 2021-06-17 06:59:54 --> Hooks Class Initialized
DEBUG - 2021-06-17 06:59:54 --> UTF-8 Support Enabled
INFO - 2021-06-17 06:59:54 --> Utf8 Class Initialized
INFO - 2021-06-17 06:59:54 --> URI Class Initialized
INFO - 2021-06-17 06:59:54 --> Router Class Initialized
INFO - 2021-06-17 06:59:54 --> Output Class Initialized
INFO - 2021-06-17 06:59:54 --> Security Class Initialized
DEBUG - 2021-06-17 06:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 06:59:54 --> Input Class Initialized
INFO - 2021-06-17 06:59:54 --> Language Class Initialized
INFO - 2021-06-17 06:59:54 --> Language Class Initialized
INFO - 2021-06-17 06:59:54 --> Config Class Initialized
INFO - 2021-06-17 06:59:54 --> Loader Class Initialized
INFO - 2021-06-17 06:59:54 --> Helper loaded: url_helper
INFO - 2021-06-17 06:59:54 --> Helper loaded: file_helper
INFO - 2021-06-17 06:59:54 --> Helper loaded: form_helper
INFO - 2021-06-17 06:59:54 --> Helper loaded: my_helper
INFO - 2021-06-17 06:59:54 --> Database Driver Class Initialized
DEBUG - 2021-06-17 06:59:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 06:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 06:59:54 --> Controller Class Initialized
INFO - 2021-06-17 08:37:08 --> Config Class Initialized
INFO - 2021-06-17 08:37:08 --> Hooks Class Initialized
DEBUG - 2021-06-17 08:37:08 --> UTF-8 Support Enabled
INFO - 2021-06-17 08:37:08 --> Utf8 Class Initialized
INFO - 2021-06-17 08:37:08 --> URI Class Initialized
DEBUG - 2021-06-17 08:37:08 --> No URI present. Default controller set.
INFO - 2021-06-17 08:37:08 --> Router Class Initialized
INFO - 2021-06-17 08:37:08 --> Output Class Initialized
INFO - 2021-06-17 08:37:08 --> Security Class Initialized
DEBUG - 2021-06-17 08:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 08:37:08 --> Input Class Initialized
INFO - 2021-06-17 08:37:08 --> Language Class Initialized
INFO - 2021-06-17 08:37:08 --> Language Class Initialized
INFO - 2021-06-17 08:37:08 --> Config Class Initialized
INFO - 2021-06-17 08:37:08 --> Loader Class Initialized
INFO - 2021-06-17 08:37:08 --> Helper loaded: url_helper
INFO - 2021-06-17 08:37:08 --> Helper loaded: file_helper
INFO - 2021-06-17 08:37:08 --> Helper loaded: form_helper
INFO - 2021-06-17 08:37:08 --> Helper loaded: my_helper
INFO - 2021-06-17 08:37:08 --> Database Driver Class Initialized
DEBUG - 2021-06-17 08:37:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 08:37:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 08:37:08 --> Controller Class Initialized
INFO - 2021-06-17 08:37:08 --> Config Class Initialized
INFO - 2021-06-17 08:37:08 --> Hooks Class Initialized
DEBUG - 2021-06-17 08:37:08 --> UTF-8 Support Enabled
INFO - 2021-06-17 08:37:08 --> Utf8 Class Initialized
INFO - 2021-06-17 08:37:08 --> URI Class Initialized
INFO - 2021-06-17 08:37:08 --> Router Class Initialized
INFO - 2021-06-17 08:37:08 --> Output Class Initialized
INFO - 2021-06-17 08:37:08 --> Security Class Initialized
DEBUG - 2021-06-17 08:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 08:37:08 --> Input Class Initialized
INFO - 2021-06-17 08:37:08 --> Language Class Initialized
INFO - 2021-06-17 08:37:08 --> Language Class Initialized
INFO - 2021-06-17 08:37:08 --> Config Class Initialized
INFO - 2021-06-17 08:37:08 --> Loader Class Initialized
INFO - 2021-06-17 08:37:08 --> Helper loaded: url_helper
INFO - 2021-06-17 08:37:08 --> Helper loaded: file_helper
INFO - 2021-06-17 08:37:08 --> Helper loaded: form_helper
INFO - 2021-06-17 08:37:08 --> Helper loaded: my_helper
INFO - 2021-06-17 08:37:08 --> Database Driver Class Initialized
DEBUG - 2021-06-17 08:37:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 08:37:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 08:37:08 --> Controller Class Initialized
DEBUG - 2021-06-17 08:37:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-17 08:37:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 08:37:08 --> Final output sent to browser
DEBUG - 2021-06-17 08:37:08 --> Total execution time: 0.0409
INFO - 2021-06-17 08:37:18 --> Config Class Initialized
INFO - 2021-06-17 08:37:18 --> Hooks Class Initialized
DEBUG - 2021-06-17 08:37:18 --> UTF-8 Support Enabled
INFO - 2021-06-17 08:37:18 --> Utf8 Class Initialized
INFO - 2021-06-17 08:37:18 --> URI Class Initialized
INFO - 2021-06-17 08:37:18 --> Router Class Initialized
INFO - 2021-06-17 08:37:18 --> Output Class Initialized
INFO - 2021-06-17 08:37:18 --> Security Class Initialized
DEBUG - 2021-06-17 08:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 08:37:18 --> Input Class Initialized
INFO - 2021-06-17 08:37:18 --> Language Class Initialized
INFO - 2021-06-17 08:37:18 --> Language Class Initialized
INFO - 2021-06-17 08:37:18 --> Config Class Initialized
INFO - 2021-06-17 08:37:18 --> Loader Class Initialized
INFO - 2021-06-17 08:37:18 --> Helper loaded: url_helper
INFO - 2021-06-17 08:37:18 --> Helper loaded: file_helper
INFO - 2021-06-17 08:37:18 --> Helper loaded: form_helper
INFO - 2021-06-17 08:37:18 --> Helper loaded: my_helper
INFO - 2021-06-17 08:37:18 --> Database Driver Class Initialized
DEBUG - 2021-06-17 08:37:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 08:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 08:37:18 --> Controller Class Initialized
INFO - 2021-06-17 08:37:18 --> Helper loaded: cookie_helper
INFO - 2021-06-17 08:37:18 --> Final output sent to browser
DEBUG - 2021-06-17 08:37:18 --> Total execution time: 0.0474
INFO - 2021-06-17 08:37:18 --> Config Class Initialized
INFO - 2021-06-17 08:37:18 --> Hooks Class Initialized
DEBUG - 2021-06-17 08:37:18 --> UTF-8 Support Enabled
INFO - 2021-06-17 08:37:18 --> Utf8 Class Initialized
INFO - 2021-06-17 08:37:18 --> URI Class Initialized
INFO - 2021-06-17 08:37:18 --> Router Class Initialized
INFO - 2021-06-17 08:37:18 --> Output Class Initialized
INFO - 2021-06-17 08:37:18 --> Security Class Initialized
DEBUG - 2021-06-17 08:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 08:37:18 --> Input Class Initialized
INFO - 2021-06-17 08:37:18 --> Language Class Initialized
INFO - 2021-06-17 08:37:18 --> Language Class Initialized
INFO - 2021-06-17 08:37:18 --> Config Class Initialized
INFO - 2021-06-17 08:37:18 --> Loader Class Initialized
INFO - 2021-06-17 08:37:18 --> Helper loaded: url_helper
INFO - 2021-06-17 08:37:18 --> Helper loaded: file_helper
INFO - 2021-06-17 08:37:18 --> Helper loaded: form_helper
INFO - 2021-06-17 08:37:18 --> Helper loaded: my_helper
INFO - 2021-06-17 08:37:18 --> Database Driver Class Initialized
DEBUG - 2021-06-17 08:37:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 08:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 08:37:18 --> Controller Class Initialized
DEBUG - 2021-06-17 08:37:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-17 08:37:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 08:37:18 --> Final output sent to browser
DEBUG - 2021-06-17 08:37:18 --> Total execution time: 0.2208
INFO - 2021-06-17 08:37:19 --> Config Class Initialized
INFO - 2021-06-17 08:37:19 --> Hooks Class Initialized
DEBUG - 2021-06-17 08:37:19 --> UTF-8 Support Enabled
INFO - 2021-06-17 08:37:19 --> Utf8 Class Initialized
INFO - 2021-06-17 08:37:19 --> URI Class Initialized
INFO - 2021-06-17 08:37:19 --> Router Class Initialized
INFO - 2021-06-17 08:37:19 --> Output Class Initialized
INFO - 2021-06-17 08:37:19 --> Security Class Initialized
DEBUG - 2021-06-17 08:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 08:37:19 --> Input Class Initialized
INFO - 2021-06-17 08:37:19 --> Language Class Initialized
INFO - 2021-06-17 08:37:19 --> Language Class Initialized
INFO - 2021-06-17 08:37:19 --> Config Class Initialized
INFO - 2021-06-17 08:37:19 --> Loader Class Initialized
INFO - 2021-06-17 08:37:19 --> Helper loaded: url_helper
INFO - 2021-06-17 08:37:19 --> Helper loaded: file_helper
INFO - 2021-06-17 08:37:19 --> Helper loaded: form_helper
INFO - 2021-06-17 08:37:19 --> Helper loaded: my_helper
INFO - 2021-06-17 08:37:19 --> Database Driver Class Initialized
DEBUG - 2021-06-17 08:37:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 08:37:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 08:37:19 --> Controller Class Initialized
DEBUG - 2021-06-17 08:37:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-17 08:37:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 08:37:19 --> Final output sent to browser
DEBUG - 2021-06-17 08:37:19 --> Total execution time: 0.0408
INFO - 2021-06-17 08:38:22 --> Config Class Initialized
INFO - 2021-06-17 08:38:22 --> Hooks Class Initialized
DEBUG - 2021-06-17 08:38:22 --> UTF-8 Support Enabled
INFO - 2021-06-17 08:38:22 --> Utf8 Class Initialized
INFO - 2021-06-17 08:38:22 --> URI Class Initialized
INFO - 2021-06-17 08:38:22 --> Router Class Initialized
INFO - 2021-06-17 08:38:22 --> Output Class Initialized
INFO - 2021-06-17 08:38:22 --> Security Class Initialized
DEBUG - 2021-06-17 08:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 08:38:22 --> Input Class Initialized
INFO - 2021-06-17 08:38:22 --> Language Class Initialized
INFO - 2021-06-17 08:38:22 --> Language Class Initialized
INFO - 2021-06-17 08:38:22 --> Config Class Initialized
INFO - 2021-06-17 08:38:22 --> Loader Class Initialized
INFO - 2021-06-17 08:38:22 --> Helper loaded: url_helper
INFO - 2021-06-17 08:38:22 --> Helper loaded: file_helper
INFO - 2021-06-17 08:38:22 --> Helper loaded: form_helper
INFO - 2021-06-17 08:38:22 --> Helper loaded: my_helper
INFO - 2021-06-17 08:38:22 --> Database Driver Class Initialized
DEBUG - 2021-06-17 08:38:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 08:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 08:38:22 --> Controller Class Initialized
INFO - 2021-06-17 08:38:22 --> Helper loaded: cookie_helper
INFO - 2021-06-17 08:38:22 --> Config Class Initialized
INFO - 2021-06-17 08:38:22 --> Hooks Class Initialized
DEBUG - 2021-06-17 08:38:22 --> UTF-8 Support Enabled
INFO - 2021-06-17 08:38:22 --> Utf8 Class Initialized
INFO - 2021-06-17 08:38:22 --> URI Class Initialized
INFO - 2021-06-17 08:38:22 --> Router Class Initialized
INFO - 2021-06-17 08:38:22 --> Output Class Initialized
INFO - 2021-06-17 08:38:22 --> Security Class Initialized
DEBUG - 2021-06-17 08:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 08:38:22 --> Input Class Initialized
INFO - 2021-06-17 08:38:22 --> Language Class Initialized
INFO - 2021-06-17 08:38:22 --> Language Class Initialized
INFO - 2021-06-17 08:38:22 --> Config Class Initialized
INFO - 2021-06-17 08:38:22 --> Loader Class Initialized
INFO - 2021-06-17 08:38:22 --> Helper loaded: url_helper
INFO - 2021-06-17 08:38:22 --> Helper loaded: file_helper
INFO - 2021-06-17 08:38:22 --> Helper loaded: form_helper
INFO - 2021-06-17 08:38:22 --> Helper loaded: my_helper
INFO - 2021-06-17 08:38:22 --> Database Driver Class Initialized
DEBUG - 2021-06-17 08:38:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 08:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 08:38:22 --> Controller Class Initialized
DEBUG - 2021-06-17 08:38:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-17 08:38:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 08:38:22 --> Final output sent to browser
DEBUG - 2021-06-17 08:38:22 --> Total execution time: 0.0480
INFO - 2021-06-17 08:38:27 --> Config Class Initialized
INFO - 2021-06-17 08:38:27 --> Hooks Class Initialized
DEBUG - 2021-06-17 08:38:27 --> UTF-8 Support Enabled
INFO - 2021-06-17 08:38:27 --> Utf8 Class Initialized
INFO - 2021-06-17 08:38:27 --> URI Class Initialized
INFO - 2021-06-17 08:38:27 --> Router Class Initialized
INFO - 2021-06-17 08:38:27 --> Output Class Initialized
INFO - 2021-06-17 08:38:27 --> Security Class Initialized
DEBUG - 2021-06-17 08:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 08:38:27 --> Input Class Initialized
INFO - 2021-06-17 08:38:27 --> Language Class Initialized
INFO - 2021-06-17 08:38:27 --> Language Class Initialized
INFO - 2021-06-17 08:38:27 --> Config Class Initialized
INFO - 2021-06-17 08:38:27 --> Loader Class Initialized
INFO - 2021-06-17 08:38:27 --> Helper loaded: url_helper
INFO - 2021-06-17 08:38:27 --> Helper loaded: file_helper
INFO - 2021-06-17 08:38:27 --> Helper loaded: form_helper
INFO - 2021-06-17 08:38:27 --> Helper loaded: my_helper
INFO - 2021-06-17 08:38:27 --> Database Driver Class Initialized
DEBUG - 2021-06-17 08:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 08:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 08:38:27 --> Controller Class Initialized
INFO - 2021-06-17 08:38:27 --> Helper loaded: cookie_helper
INFO - 2021-06-17 08:38:27 --> Final output sent to browser
DEBUG - 2021-06-17 08:38:27 --> Total execution time: 0.0395
INFO - 2021-06-17 08:38:27 --> Config Class Initialized
INFO - 2021-06-17 08:38:27 --> Hooks Class Initialized
DEBUG - 2021-06-17 08:38:27 --> UTF-8 Support Enabled
INFO - 2021-06-17 08:38:27 --> Utf8 Class Initialized
INFO - 2021-06-17 08:38:27 --> URI Class Initialized
INFO - 2021-06-17 08:38:27 --> Router Class Initialized
INFO - 2021-06-17 08:38:27 --> Output Class Initialized
INFO - 2021-06-17 08:38:27 --> Security Class Initialized
DEBUG - 2021-06-17 08:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 08:38:27 --> Input Class Initialized
INFO - 2021-06-17 08:38:27 --> Language Class Initialized
INFO - 2021-06-17 08:38:27 --> Language Class Initialized
INFO - 2021-06-17 08:38:27 --> Config Class Initialized
INFO - 2021-06-17 08:38:27 --> Loader Class Initialized
INFO - 2021-06-17 08:38:27 --> Helper loaded: url_helper
INFO - 2021-06-17 08:38:27 --> Helper loaded: file_helper
INFO - 2021-06-17 08:38:27 --> Helper loaded: form_helper
INFO - 2021-06-17 08:38:27 --> Helper loaded: my_helper
INFO - 2021-06-17 08:38:27 --> Database Driver Class Initialized
DEBUG - 2021-06-17 08:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 08:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 08:38:27 --> Controller Class Initialized
DEBUG - 2021-06-17 08:38:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-17 08:38:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 08:38:27 --> Final output sent to browser
DEBUG - 2021-06-17 08:38:27 --> Total execution time: 0.1853
INFO - 2021-06-17 08:38:30 --> Config Class Initialized
INFO - 2021-06-17 08:38:30 --> Hooks Class Initialized
DEBUG - 2021-06-17 08:38:30 --> UTF-8 Support Enabled
INFO - 2021-06-17 08:38:30 --> Utf8 Class Initialized
INFO - 2021-06-17 08:38:30 --> URI Class Initialized
INFO - 2021-06-17 08:38:30 --> Router Class Initialized
INFO - 2021-06-17 08:38:30 --> Output Class Initialized
INFO - 2021-06-17 08:38:30 --> Security Class Initialized
DEBUG - 2021-06-17 08:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 08:38:30 --> Input Class Initialized
INFO - 2021-06-17 08:38:30 --> Language Class Initialized
INFO - 2021-06-17 08:38:30 --> Language Class Initialized
INFO - 2021-06-17 08:38:30 --> Config Class Initialized
INFO - 2021-06-17 08:38:30 --> Loader Class Initialized
INFO - 2021-06-17 08:38:30 --> Helper loaded: url_helper
INFO - 2021-06-17 08:38:30 --> Helper loaded: file_helper
INFO - 2021-06-17 08:38:30 --> Helper loaded: form_helper
INFO - 2021-06-17 08:38:30 --> Helper loaded: my_helper
INFO - 2021-06-17 08:38:30 --> Database Driver Class Initialized
DEBUG - 2021-06-17 08:38:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 08:38:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 08:38:30 --> Controller Class Initialized
DEBUG - 2021-06-17 08:38:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-17 08:38:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 08:38:30 --> Final output sent to browser
DEBUG - 2021-06-17 08:38:30 --> Total execution time: 0.0497
INFO - 2021-06-17 08:38:33 --> Config Class Initialized
INFO - 2021-06-17 08:38:33 --> Hooks Class Initialized
DEBUG - 2021-06-17 08:38:33 --> UTF-8 Support Enabled
INFO - 2021-06-17 08:38:33 --> Utf8 Class Initialized
INFO - 2021-06-17 08:38:33 --> URI Class Initialized
INFO - 2021-06-17 08:38:33 --> Router Class Initialized
INFO - 2021-06-17 08:38:33 --> Output Class Initialized
INFO - 2021-06-17 08:38:33 --> Security Class Initialized
DEBUG - 2021-06-17 08:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 08:38:33 --> Input Class Initialized
INFO - 2021-06-17 08:38:33 --> Language Class Initialized
INFO - 2021-06-17 08:38:33 --> Language Class Initialized
INFO - 2021-06-17 08:38:33 --> Config Class Initialized
INFO - 2021-06-17 08:38:33 --> Loader Class Initialized
INFO - 2021-06-17 08:38:33 --> Helper loaded: url_helper
INFO - 2021-06-17 08:38:33 --> Helper loaded: file_helper
INFO - 2021-06-17 08:38:33 --> Helper loaded: form_helper
INFO - 2021-06-17 08:38:33 --> Helper loaded: my_helper
INFO - 2021-06-17 08:38:33 --> Database Driver Class Initialized
DEBUG - 2021-06-17 08:38:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 08:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 08:38:33 --> Controller Class Initialized
DEBUG - 2021-06-17 08:38:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-17 08:38:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 08:38:33 --> Final output sent to browser
DEBUG - 2021-06-17 08:38:33 --> Total execution time: 0.0470
INFO - 2021-06-17 08:38:33 --> Config Class Initialized
INFO - 2021-06-17 08:38:33 --> Hooks Class Initialized
DEBUG - 2021-06-17 08:38:33 --> UTF-8 Support Enabled
INFO - 2021-06-17 08:38:33 --> Utf8 Class Initialized
INFO - 2021-06-17 08:38:33 --> URI Class Initialized
INFO - 2021-06-17 08:38:33 --> Router Class Initialized
INFO - 2021-06-17 08:38:33 --> Output Class Initialized
INFO - 2021-06-17 08:38:33 --> Security Class Initialized
DEBUG - 2021-06-17 08:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 08:38:33 --> Input Class Initialized
INFO - 2021-06-17 08:38:33 --> Language Class Initialized
INFO - 2021-06-17 08:38:33 --> Language Class Initialized
INFO - 2021-06-17 08:38:33 --> Config Class Initialized
INFO - 2021-06-17 08:38:33 --> Loader Class Initialized
INFO - 2021-06-17 08:38:33 --> Helper loaded: url_helper
INFO - 2021-06-17 08:38:33 --> Helper loaded: file_helper
INFO - 2021-06-17 08:38:33 --> Helper loaded: form_helper
INFO - 2021-06-17 08:38:33 --> Helper loaded: my_helper
INFO - 2021-06-17 08:38:33 --> Database Driver Class Initialized
DEBUG - 2021-06-17 08:38:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 08:38:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 08:38:34 --> Controller Class Initialized
INFO - 2021-06-17 08:38:35 --> Config Class Initialized
INFO - 2021-06-17 08:38:35 --> Hooks Class Initialized
DEBUG - 2021-06-17 08:38:35 --> UTF-8 Support Enabled
INFO - 2021-06-17 08:38:35 --> Utf8 Class Initialized
INFO - 2021-06-17 08:38:35 --> URI Class Initialized
INFO - 2021-06-17 08:38:35 --> Router Class Initialized
INFO - 2021-06-17 08:38:35 --> Output Class Initialized
INFO - 2021-06-17 08:38:35 --> Security Class Initialized
DEBUG - 2021-06-17 08:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 08:38:35 --> Input Class Initialized
INFO - 2021-06-17 08:38:35 --> Language Class Initialized
INFO - 2021-06-17 08:38:35 --> Language Class Initialized
INFO - 2021-06-17 08:38:35 --> Config Class Initialized
INFO - 2021-06-17 08:38:35 --> Loader Class Initialized
INFO - 2021-06-17 08:38:35 --> Helper loaded: url_helper
INFO - 2021-06-17 08:38:35 --> Helper loaded: file_helper
INFO - 2021-06-17 08:38:35 --> Helper loaded: form_helper
INFO - 2021-06-17 08:38:35 --> Helper loaded: my_helper
INFO - 2021-06-17 08:38:35 --> Database Driver Class Initialized
DEBUG - 2021-06-17 08:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 08:38:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 08:38:35 --> Controller Class Initialized
DEBUG - 2021-06-17 08:38:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 08:38:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 08:38:35 --> Final output sent to browser
DEBUG - 2021-06-17 08:38:35 --> Total execution time: 0.0441
INFO - 2021-06-17 08:38:37 --> Config Class Initialized
INFO - 2021-06-17 08:38:37 --> Hooks Class Initialized
DEBUG - 2021-06-17 08:38:37 --> UTF-8 Support Enabled
INFO - 2021-06-17 08:38:37 --> Utf8 Class Initialized
INFO - 2021-06-17 08:38:37 --> URI Class Initialized
INFO - 2021-06-17 08:38:37 --> Router Class Initialized
INFO - 2021-06-17 08:38:37 --> Output Class Initialized
INFO - 2021-06-17 08:38:37 --> Security Class Initialized
DEBUG - 2021-06-17 08:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 08:38:37 --> Input Class Initialized
INFO - 2021-06-17 08:38:37 --> Language Class Initialized
INFO - 2021-06-17 08:38:37 --> Language Class Initialized
INFO - 2021-06-17 08:38:37 --> Config Class Initialized
INFO - 2021-06-17 08:38:37 --> Loader Class Initialized
INFO - 2021-06-17 08:38:37 --> Helper loaded: url_helper
INFO - 2021-06-17 08:38:37 --> Helper loaded: file_helper
INFO - 2021-06-17 08:38:37 --> Helper loaded: form_helper
INFO - 2021-06-17 08:38:37 --> Helper loaded: my_helper
INFO - 2021-06-17 08:38:37 --> Database Driver Class Initialized
DEBUG - 2021-06-17 08:38:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 08:38:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 08:38:37 --> Controller Class Initialized
INFO - 2021-06-17 08:38:37 --> Final output sent to browser
DEBUG - 2021-06-17 08:38:37 --> Total execution time: 0.0505
INFO - 2021-06-17 08:39:07 --> Config Class Initialized
INFO - 2021-06-17 08:39:07 --> Hooks Class Initialized
DEBUG - 2021-06-17 08:39:07 --> UTF-8 Support Enabled
INFO - 2021-06-17 08:39:07 --> Utf8 Class Initialized
INFO - 2021-06-17 08:39:07 --> URI Class Initialized
INFO - 2021-06-17 08:39:07 --> Router Class Initialized
INFO - 2021-06-17 08:39:07 --> Output Class Initialized
INFO - 2021-06-17 08:39:07 --> Security Class Initialized
DEBUG - 2021-06-17 08:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 08:39:07 --> Input Class Initialized
INFO - 2021-06-17 08:39:07 --> Language Class Initialized
INFO - 2021-06-17 08:39:07 --> Language Class Initialized
INFO - 2021-06-17 08:39:07 --> Config Class Initialized
INFO - 2021-06-17 08:39:07 --> Loader Class Initialized
INFO - 2021-06-17 08:39:07 --> Helper loaded: url_helper
INFO - 2021-06-17 08:39:07 --> Helper loaded: file_helper
INFO - 2021-06-17 08:39:07 --> Helper loaded: form_helper
INFO - 2021-06-17 08:39:07 --> Helper loaded: my_helper
INFO - 2021-06-17 08:39:07 --> Database Driver Class Initialized
DEBUG - 2021-06-17 08:39:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 08:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 08:39:07 --> Controller Class Initialized
INFO - 2021-06-17 08:39:07 --> Final output sent to browser
DEBUG - 2021-06-17 08:39:07 --> Total execution time: 0.0406
INFO - 2021-06-17 08:39:07 --> Config Class Initialized
INFO - 2021-06-17 08:39:07 --> Hooks Class Initialized
DEBUG - 2021-06-17 08:39:07 --> UTF-8 Support Enabled
INFO - 2021-06-17 08:39:07 --> Utf8 Class Initialized
INFO - 2021-06-17 08:39:07 --> URI Class Initialized
INFO - 2021-06-17 08:39:07 --> Router Class Initialized
INFO - 2021-06-17 08:39:07 --> Output Class Initialized
INFO - 2021-06-17 08:39:07 --> Security Class Initialized
DEBUG - 2021-06-17 08:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 08:39:07 --> Input Class Initialized
INFO - 2021-06-17 08:39:07 --> Language Class Initialized
INFO - 2021-06-17 08:39:07 --> Language Class Initialized
INFO - 2021-06-17 08:39:07 --> Config Class Initialized
INFO - 2021-06-17 08:39:07 --> Loader Class Initialized
INFO - 2021-06-17 08:39:07 --> Helper loaded: url_helper
INFO - 2021-06-17 08:39:07 --> Helper loaded: file_helper
INFO - 2021-06-17 08:39:07 --> Helper loaded: form_helper
INFO - 2021-06-17 08:39:07 --> Helper loaded: my_helper
INFO - 2021-06-17 08:39:07 --> Database Driver Class Initialized
DEBUG - 2021-06-17 08:39:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 08:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 08:39:07 --> Controller Class Initialized
INFO - 2021-06-17 08:39:09 --> Config Class Initialized
INFO - 2021-06-17 08:39:09 --> Hooks Class Initialized
DEBUG - 2021-06-17 08:39:09 --> UTF-8 Support Enabled
INFO - 2021-06-17 08:39:09 --> Utf8 Class Initialized
INFO - 2021-06-17 08:39:09 --> URI Class Initialized
INFO - 2021-06-17 08:39:09 --> Router Class Initialized
INFO - 2021-06-17 08:39:09 --> Output Class Initialized
INFO - 2021-06-17 08:39:09 --> Security Class Initialized
DEBUG - 2021-06-17 08:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 08:39:09 --> Input Class Initialized
INFO - 2021-06-17 08:39:09 --> Language Class Initialized
INFO - 2021-06-17 08:39:09 --> Language Class Initialized
INFO - 2021-06-17 08:39:09 --> Config Class Initialized
INFO - 2021-06-17 08:39:09 --> Loader Class Initialized
INFO - 2021-06-17 08:39:09 --> Helper loaded: url_helper
INFO - 2021-06-17 08:39:09 --> Helper loaded: file_helper
INFO - 2021-06-17 08:39:09 --> Helper loaded: form_helper
INFO - 2021-06-17 08:39:09 --> Helper loaded: my_helper
INFO - 2021-06-17 08:39:09 --> Database Driver Class Initialized
DEBUG - 2021-06-17 08:39:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 08:39:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 08:39:09 --> Controller Class Initialized
INFO - 2021-06-17 08:39:09 --> Final output sent to browser
DEBUG - 2021-06-17 08:39:09 --> Total execution time: 0.0388
INFO - 2021-06-17 08:39:17 --> Config Class Initialized
INFO - 2021-06-17 08:39:17 --> Hooks Class Initialized
DEBUG - 2021-06-17 08:39:17 --> UTF-8 Support Enabled
INFO - 2021-06-17 08:39:17 --> Utf8 Class Initialized
INFO - 2021-06-17 08:39:17 --> URI Class Initialized
INFO - 2021-06-17 08:39:17 --> Router Class Initialized
INFO - 2021-06-17 08:39:17 --> Output Class Initialized
INFO - 2021-06-17 08:39:17 --> Security Class Initialized
DEBUG - 2021-06-17 08:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 08:39:17 --> Input Class Initialized
INFO - 2021-06-17 08:39:17 --> Language Class Initialized
INFO - 2021-06-17 08:39:17 --> Language Class Initialized
INFO - 2021-06-17 08:39:17 --> Config Class Initialized
INFO - 2021-06-17 08:39:17 --> Loader Class Initialized
INFO - 2021-06-17 08:39:17 --> Helper loaded: url_helper
INFO - 2021-06-17 08:39:17 --> Helper loaded: file_helper
INFO - 2021-06-17 08:39:17 --> Helper loaded: form_helper
INFO - 2021-06-17 08:39:17 --> Helper loaded: my_helper
INFO - 2021-06-17 08:39:17 --> Database Driver Class Initialized
DEBUG - 2021-06-17 08:39:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 08:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 08:39:17 --> Controller Class Initialized
INFO - 2021-06-17 08:39:17 --> Final output sent to browser
DEBUG - 2021-06-17 08:39:17 --> Total execution time: 0.0501
INFO - 2021-06-17 08:39:17 --> Config Class Initialized
INFO - 2021-06-17 08:39:17 --> Hooks Class Initialized
DEBUG - 2021-06-17 08:39:17 --> UTF-8 Support Enabled
INFO - 2021-06-17 08:39:17 --> Utf8 Class Initialized
INFO - 2021-06-17 08:39:17 --> URI Class Initialized
INFO - 2021-06-17 08:39:17 --> Router Class Initialized
INFO - 2021-06-17 08:39:17 --> Output Class Initialized
INFO - 2021-06-17 08:39:17 --> Security Class Initialized
DEBUG - 2021-06-17 08:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 08:39:17 --> Input Class Initialized
INFO - 2021-06-17 08:39:17 --> Language Class Initialized
INFO - 2021-06-17 08:39:17 --> Language Class Initialized
INFO - 2021-06-17 08:39:17 --> Config Class Initialized
INFO - 2021-06-17 08:39:17 --> Loader Class Initialized
INFO - 2021-06-17 08:39:17 --> Helper loaded: url_helper
INFO - 2021-06-17 08:39:17 --> Helper loaded: file_helper
INFO - 2021-06-17 08:39:17 --> Helper loaded: form_helper
INFO - 2021-06-17 08:39:17 --> Helper loaded: my_helper
INFO - 2021-06-17 08:39:17 --> Database Driver Class Initialized
DEBUG - 2021-06-17 08:39:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 08:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 08:39:17 --> Controller Class Initialized
INFO - 2021-06-17 08:39:26 --> Config Class Initialized
INFO - 2021-06-17 08:39:26 --> Hooks Class Initialized
DEBUG - 2021-06-17 08:39:26 --> UTF-8 Support Enabled
INFO - 2021-06-17 08:39:26 --> Utf8 Class Initialized
INFO - 2021-06-17 08:39:26 --> URI Class Initialized
INFO - 2021-06-17 08:39:26 --> Router Class Initialized
INFO - 2021-06-17 08:39:26 --> Output Class Initialized
INFO - 2021-06-17 08:39:26 --> Security Class Initialized
DEBUG - 2021-06-17 08:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 08:39:26 --> Input Class Initialized
INFO - 2021-06-17 08:39:26 --> Language Class Initialized
INFO - 2021-06-17 08:39:26 --> Language Class Initialized
INFO - 2021-06-17 08:39:26 --> Config Class Initialized
INFO - 2021-06-17 08:39:26 --> Loader Class Initialized
INFO - 2021-06-17 08:39:26 --> Helper loaded: url_helper
INFO - 2021-06-17 08:39:26 --> Helper loaded: file_helper
INFO - 2021-06-17 08:39:26 --> Helper loaded: form_helper
INFO - 2021-06-17 08:39:26 --> Helper loaded: my_helper
INFO - 2021-06-17 08:39:26 --> Database Driver Class Initialized
DEBUG - 2021-06-17 08:39:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 08:39:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 08:39:26 --> Controller Class Initialized
INFO - 2021-06-17 08:39:26 --> Final output sent to browser
DEBUG - 2021-06-17 08:39:26 --> Total execution time: 0.0486
INFO - 2021-06-17 08:39:30 --> Config Class Initialized
INFO - 2021-06-17 08:39:30 --> Hooks Class Initialized
DEBUG - 2021-06-17 08:39:30 --> UTF-8 Support Enabled
INFO - 2021-06-17 08:39:30 --> Utf8 Class Initialized
INFO - 2021-06-17 08:39:30 --> URI Class Initialized
INFO - 2021-06-17 08:39:30 --> Router Class Initialized
INFO - 2021-06-17 08:39:30 --> Output Class Initialized
INFO - 2021-06-17 08:39:30 --> Security Class Initialized
DEBUG - 2021-06-17 08:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 08:39:30 --> Input Class Initialized
INFO - 2021-06-17 08:39:30 --> Language Class Initialized
INFO - 2021-06-17 08:39:30 --> Language Class Initialized
INFO - 2021-06-17 08:39:30 --> Config Class Initialized
INFO - 2021-06-17 08:39:30 --> Loader Class Initialized
INFO - 2021-06-17 08:39:30 --> Helper loaded: url_helper
INFO - 2021-06-17 08:39:30 --> Helper loaded: file_helper
INFO - 2021-06-17 08:39:30 --> Helper loaded: form_helper
INFO - 2021-06-17 08:39:30 --> Helper loaded: my_helper
INFO - 2021-06-17 08:39:30 --> Database Driver Class Initialized
DEBUG - 2021-06-17 08:39:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 08:39:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 08:39:30 --> Controller Class Initialized
INFO - 2021-06-17 08:39:30 --> Final output sent to browser
DEBUG - 2021-06-17 08:39:30 --> Total execution time: 0.0494
INFO - 2021-06-17 08:39:30 --> Config Class Initialized
INFO - 2021-06-17 08:39:30 --> Hooks Class Initialized
DEBUG - 2021-06-17 08:39:30 --> UTF-8 Support Enabled
INFO - 2021-06-17 08:39:30 --> Utf8 Class Initialized
INFO - 2021-06-17 08:39:30 --> URI Class Initialized
INFO - 2021-06-17 08:39:30 --> Router Class Initialized
INFO - 2021-06-17 08:39:30 --> Output Class Initialized
INFO - 2021-06-17 08:39:30 --> Security Class Initialized
DEBUG - 2021-06-17 08:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 08:39:30 --> Input Class Initialized
INFO - 2021-06-17 08:39:30 --> Language Class Initialized
INFO - 2021-06-17 08:39:30 --> Language Class Initialized
INFO - 2021-06-17 08:39:30 --> Config Class Initialized
INFO - 2021-06-17 08:39:30 --> Loader Class Initialized
INFO - 2021-06-17 08:39:30 --> Helper loaded: url_helper
INFO - 2021-06-17 08:39:30 --> Helper loaded: file_helper
INFO - 2021-06-17 08:39:30 --> Helper loaded: form_helper
INFO - 2021-06-17 08:39:30 --> Helper loaded: my_helper
INFO - 2021-06-17 08:39:30 --> Database Driver Class Initialized
DEBUG - 2021-06-17 08:39:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 08:39:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 08:39:30 --> Controller Class Initialized
INFO - 2021-06-17 08:39:36 --> Config Class Initialized
INFO - 2021-06-17 08:39:36 --> Hooks Class Initialized
DEBUG - 2021-06-17 08:39:36 --> UTF-8 Support Enabled
INFO - 2021-06-17 08:39:36 --> Utf8 Class Initialized
INFO - 2021-06-17 08:39:36 --> URI Class Initialized
INFO - 2021-06-17 08:39:36 --> Router Class Initialized
INFO - 2021-06-17 08:39:36 --> Output Class Initialized
INFO - 2021-06-17 08:39:36 --> Security Class Initialized
DEBUG - 2021-06-17 08:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 08:39:36 --> Input Class Initialized
INFO - 2021-06-17 08:39:36 --> Language Class Initialized
INFO - 2021-06-17 08:39:36 --> Language Class Initialized
INFO - 2021-06-17 08:39:36 --> Config Class Initialized
INFO - 2021-06-17 08:39:36 --> Loader Class Initialized
INFO - 2021-06-17 08:39:36 --> Helper loaded: url_helper
INFO - 2021-06-17 08:39:36 --> Helper loaded: file_helper
INFO - 2021-06-17 08:39:36 --> Helper loaded: form_helper
INFO - 2021-06-17 08:39:36 --> Helper loaded: my_helper
INFO - 2021-06-17 08:39:36 --> Database Driver Class Initialized
DEBUG - 2021-06-17 08:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 08:39:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 08:39:36 --> Controller Class Initialized
DEBUG - 2021-06-17 08:39:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 08:39:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 08:39:36 --> Final output sent to browser
DEBUG - 2021-06-17 08:39:36 --> Total execution time: 0.0453
INFO - 2021-06-17 08:39:38 --> Config Class Initialized
INFO - 2021-06-17 08:39:38 --> Hooks Class Initialized
DEBUG - 2021-06-17 08:39:38 --> UTF-8 Support Enabled
INFO - 2021-06-17 08:39:38 --> Utf8 Class Initialized
INFO - 2021-06-17 08:39:38 --> URI Class Initialized
INFO - 2021-06-17 08:39:38 --> Router Class Initialized
INFO - 2021-06-17 08:39:38 --> Output Class Initialized
INFO - 2021-06-17 08:39:38 --> Security Class Initialized
DEBUG - 2021-06-17 08:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 08:39:38 --> Input Class Initialized
INFO - 2021-06-17 08:39:38 --> Language Class Initialized
INFO - 2021-06-17 08:39:38 --> Language Class Initialized
INFO - 2021-06-17 08:39:38 --> Config Class Initialized
INFO - 2021-06-17 08:39:38 --> Loader Class Initialized
INFO - 2021-06-17 08:39:38 --> Helper loaded: url_helper
INFO - 2021-06-17 08:39:38 --> Helper loaded: file_helper
INFO - 2021-06-17 08:39:38 --> Helper loaded: form_helper
INFO - 2021-06-17 08:39:38 --> Helper loaded: my_helper
INFO - 2021-06-17 08:39:38 --> Database Driver Class Initialized
DEBUG - 2021-06-17 08:39:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 08:39:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 08:39:38 --> Controller Class Initialized
INFO - 2021-06-17 08:39:38 --> Final output sent to browser
DEBUG - 2021-06-17 08:39:38 --> Total execution time: 0.0391
INFO - 2021-06-17 08:39:47 --> Config Class Initialized
INFO - 2021-06-17 08:39:47 --> Hooks Class Initialized
DEBUG - 2021-06-17 08:39:47 --> UTF-8 Support Enabled
INFO - 2021-06-17 08:39:47 --> Utf8 Class Initialized
INFO - 2021-06-17 08:39:47 --> URI Class Initialized
INFO - 2021-06-17 08:39:47 --> Router Class Initialized
INFO - 2021-06-17 08:39:47 --> Output Class Initialized
INFO - 2021-06-17 08:39:47 --> Security Class Initialized
DEBUG - 2021-06-17 08:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 08:39:47 --> Input Class Initialized
INFO - 2021-06-17 08:39:47 --> Language Class Initialized
INFO - 2021-06-17 08:39:47 --> Language Class Initialized
INFO - 2021-06-17 08:39:47 --> Config Class Initialized
INFO - 2021-06-17 08:39:47 --> Loader Class Initialized
INFO - 2021-06-17 08:39:47 --> Helper loaded: url_helper
INFO - 2021-06-17 08:39:47 --> Helper loaded: file_helper
INFO - 2021-06-17 08:39:47 --> Helper loaded: form_helper
INFO - 2021-06-17 08:39:47 --> Helper loaded: my_helper
INFO - 2021-06-17 08:39:47 --> Database Driver Class Initialized
DEBUG - 2021-06-17 08:39:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 08:39:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 08:39:47 --> Controller Class Initialized
INFO - 2021-06-17 08:39:47 --> Final output sent to browser
DEBUG - 2021-06-17 08:39:47 --> Total execution time: 0.0507
INFO - 2021-06-17 08:39:47 --> Config Class Initialized
INFO - 2021-06-17 08:39:47 --> Hooks Class Initialized
DEBUG - 2021-06-17 08:39:47 --> UTF-8 Support Enabled
INFO - 2021-06-17 08:39:47 --> Utf8 Class Initialized
INFO - 2021-06-17 08:39:47 --> URI Class Initialized
INFO - 2021-06-17 08:39:47 --> Router Class Initialized
INFO - 2021-06-17 08:39:47 --> Output Class Initialized
INFO - 2021-06-17 08:39:47 --> Security Class Initialized
DEBUG - 2021-06-17 08:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 08:39:47 --> Input Class Initialized
INFO - 2021-06-17 08:39:47 --> Language Class Initialized
INFO - 2021-06-17 08:39:47 --> Language Class Initialized
INFO - 2021-06-17 08:39:47 --> Config Class Initialized
INFO - 2021-06-17 08:39:47 --> Loader Class Initialized
INFO - 2021-06-17 08:39:47 --> Helper loaded: url_helper
INFO - 2021-06-17 08:39:47 --> Helper loaded: file_helper
INFO - 2021-06-17 08:39:47 --> Helper loaded: form_helper
INFO - 2021-06-17 08:39:47 --> Helper loaded: my_helper
INFO - 2021-06-17 08:39:47 --> Database Driver Class Initialized
DEBUG - 2021-06-17 08:39:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 08:39:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 08:39:47 --> Controller Class Initialized
DEBUG - 2021-06-17 08:39:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 08:39:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 08:39:47 --> Final output sent to browser
DEBUG - 2021-06-17 08:39:47 --> Total execution time: 0.0404
INFO - 2021-06-17 08:39:49 --> Config Class Initialized
INFO - 2021-06-17 08:39:49 --> Hooks Class Initialized
DEBUG - 2021-06-17 08:39:49 --> UTF-8 Support Enabled
INFO - 2021-06-17 08:39:49 --> Utf8 Class Initialized
INFO - 2021-06-17 08:39:49 --> URI Class Initialized
INFO - 2021-06-17 08:39:49 --> Router Class Initialized
INFO - 2021-06-17 08:39:49 --> Output Class Initialized
INFO - 2021-06-17 08:39:49 --> Security Class Initialized
DEBUG - 2021-06-17 08:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 08:39:49 --> Input Class Initialized
INFO - 2021-06-17 08:39:49 --> Language Class Initialized
INFO - 2021-06-17 08:39:49 --> Language Class Initialized
INFO - 2021-06-17 08:39:49 --> Config Class Initialized
INFO - 2021-06-17 08:39:49 --> Loader Class Initialized
INFO - 2021-06-17 08:39:49 --> Helper loaded: url_helper
INFO - 2021-06-17 08:39:49 --> Helper loaded: file_helper
INFO - 2021-06-17 08:39:49 --> Helper loaded: form_helper
INFO - 2021-06-17 08:39:49 --> Helper loaded: my_helper
INFO - 2021-06-17 08:39:49 --> Database Driver Class Initialized
DEBUG - 2021-06-17 08:39:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 08:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 08:39:49 --> Controller Class Initialized
INFO - 2021-06-17 08:39:49 --> Final output sent to browser
DEBUG - 2021-06-17 08:39:49 --> Total execution time: 0.0396
INFO - 2021-06-17 08:39:56 --> Config Class Initialized
INFO - 2021-06-17 08:39:56 --> Hooks Class Initialized
DEBUG - 2021-06-17 08:39:56 --> UTF-8 Support Enabled
INFO - 2021-06-17 08:39:56 --> Utf8 Class Initialized
INFO - 2021-06-17 08:39:56 --> URI Class Initialized
INFO - 2021-06-17 08:39:56 --> Router Class Initialized
INFO - 2021-06-17 08:39:56 --> Output Class Initialized
INFO - 2021-06-17 08:39:56 --> Security Class Initialized
DEBUG - 2021-06-17 08:39:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 08:39:56 --> Input Class Initialized
INFO - 2021-06-17 08:39:56 --> Language Class Initialized
INFO - 2021-06-17 08:39:56 --> Language Class Initialized
INFO - 2021-06-17 08:39:56 --> Config Class Initialized
INFO - 2021-06-17 08:39:56 --> Loader Class Initialized
INFO - 2021-06-17 08:39:56 --> Helper loaded: url_helper
INFO - 2021-06-17 08:39:56 --> Helper loaded: file_helper
INFO - 2021-06-17 08:39:56 --> Helper loaded: form_helper
INFO - 2021-06-17 08:39:56 --> Helper loaded: my_helper
INFO - 2021-06-17 08:39:56 --> Database Driver Class Initialized
DEBUG - 2021-06-17 08:39:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 08:39:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 08:39:56 --> Controller Class Initialized
INFO - 2021-06-17 08:39:56 --> Final output sent to browser
DEBUG - 2021-06-17 08:39:56 --> Total execution time: 0.0494
INFO - 2021-06-17 08:39:56 --> Config Class Initialized
INFO - 2021-06-17 08:39:56 --> Hooks Class Initialized
DEBUG - 2021-06-17 08:39:56 --> UTF-8 Support Enabled
INFO - 2021-06-17 08:39:56 --> Utf8 Class Initialized
INFO - 2021-06-17 08:39:56 --> URI Class Initialized
INFO - 2021-06-17 08:39:56 --> Router Class Initialized
INFO - 2021-06-17 08:39:56 --> Output Class Initialized
INFO - 2021-06-17 08:39:56 --> Security Class Initialized
DEBUG - 2021-06-17 08:39:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 08:39:56 --> Input Class Initialized
INFO - 2021-06-17 08:39:56 --> Language Class Initialized
INFO - 2021-06-17 08:39:56 --> Language Class Initialized
INFO - 2021-06-17 08:39:56 --> Config Class Initialized
INFO - 2021-06-17 08:39:56 --> Loader Class Initialized
INFO - 2021-06-17 08:39:56 --> Helper loaded: url_helper
INFO - 2021-06-17 08:39:56 --> Helper loaded: file_helper
INFO - 2021-06-17 08:39:56 --> Helper loaded: form_helper
INFO - 2021-06-17 08:39:56 --> Helper loaded: my_helper
INFO - 2021-06-17 08:39:56 --> Database Driver Class Initialized
DEBUG - 2021-06-17 08:39:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 08:39:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 08:39:56 --> Controller Class Initialized
DEBUG - 2021-06-17 08:39:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 08:39:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 08:39:56 --> Final output sent to browser
DEBUG - 2021-06-17 08:39:56 --> Total execution time: 0.0508
INFO - 2021-06-17 08:39:58 --> Config Class Initialized
INFO - 2021-06-17 08:39:58 --> Hooks Class Initialized
DEBUG - 2021-06-17 08:39:58 --> UTF-8 Support Enabled
INFO - 2021-06-17 08:39:58 --> Utf8 Class Initialized
INFO - 2021-06-17 08:39:58 --> URI Class Initialized
INFO - 2021-06-17 08:39:58 --> Router Class Initialized
INFO - 2021-06-17 08:39:58 --> Output Class Initialized
INFO - 2021-06-17 08:39:58 --> Security Class Initialized
DEBUG - 2021-06-17 08:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 08:39:58 --> Input Class Initialized
INFO - 2021-06-17 08:39:58 --> Language Class Initialized
INFO - 2021-06-17 08:39:58 --> Language Class Initialized
INFO - 2021-06-17 08:39:58 --> Config Class Initialized
INFO - 2021-06-17 08:39:58 --> Loader Class Initialized
INFO - 2021-06-17 08:39:58 --> Helper loaded: url_helper
INFO - 2021-06-17 08:39:58 --> Helper loaded: file_helper
INFO - 2021-06-17 08:39:58 --> Helper loaded: form_helper
INFO - 2021-06-17 08:39:58 --> Helper loaded: my_helper
INFO - 2021-06-17 08:39:58 --> Database Driver Class Initialized
DEBUG - 2021-06-17 08:39:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 08:39:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 08:39:58 --> Controller Class Initialized
INFO - 2021-06-17 08:39:58 --> Final output sent to browser
DEBUG - 2021-06-17 08:39:58 --> Total execution time: 0.0384
INFO - 2021-06-17 08:40:05 --> Config Class Initialized
INFO - 2021-06-17 08:40:05 --> Hooks Class Initialized
DEBUG - 2021-06-17 08:40:05 --> UTF-8 Support Enabled
INFO - 2021-06-17 08:40:05 --> Utf8 Class Initialized
INFO - 2021-06-17 08:40:05 --> URI Class Initialized
INFO - 2021-06-17 08:40:05 --> Router Class Initialized
INFO - 2021-06-17 08:40:05 --> Output Class Initialized
INFO - 2021-06-17 08:40:05 --> Security Class Initialized
DEBUG - 2021-06-17 08:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 08:40:05 --> Input Class Initialized
INFO - 2021-06-17 08:40:05 --> Language Class Initialized
INFO - 2021-06-17 08:40:05 --> Language Class Initialized
INFO - 2021-06-17 08:40:05 --> Config Class Initialized
INFO - 2021-06-17 08:40:05 --> Loader Class Initialized
INFO - 2021-06-17 08:40:05 --> Helper loaded: url_helper
INFO - 2021-06-17 08:40:05 --> Helper loaded: file_helper
INFO - 2021-06-17 08:40:05 --> Helper loaded: form_helper
INFO - 2021-06-17 08:40:05 --> Helper loaded: my_helper
INFO - 2021-06-17 08:40:05 --> Database Driver Class Initialized
DEBUG - 2021-06-17 08:40:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 08:40:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 08:40:05 --> Controller Class Initialized
INFO - 2021-06-17 08:40:05 --> Final output sent to browser
DEBUG - 2021-06-17 08:40:05 --> Total execution time: 0.0499
INFO - 2021-06-17 08:40:05 --> Config Class Initialized
INFO - 2021-06-17 08:40:05 --> Hooks Class Initialized
DEBUG - 2021-06-17 08:40:05 --> UTF-8 Support Enabled
INFO - 2021-06-17 08:40:05 --> Utf8 Class Initialized
INFO - 2021-06-17 08:40:05 --> URI Class Initialized
INFO - 2021-06-17 08:40:05 --> Router Class Initialized
INFO - 2021-06-17 08:40:05 --> Output Class Initialized
INFO - 2021-06-17 08:40:05 --> Security Class Initialized
DEBUG - 2021-06-17 08:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 08:40:05 --> Input Class Initialized
INFO - 2021-06-17 08:40:05 --> Language Class Initialized
INFO - 2021-06-17 08:40:05 --> Language Class Initialized
INFO - 2021-06-17 08:40:05 --> Config Class Initialized
INFO - 2021-06-17 08:40:05 --> Loader Class Initialized
INFO - 2021-06-17 08:40:05 --> Helper loaded: url_helper
INFO - 2021-06-17 08:40:05 --> Helper loaded: file_helper
INFO - 2021-06-17 08:40:05 --> Helper loaded: form_helper
INFO - 2021-06-17 08:40:05 --> Helper loaded: my_helper
INFO - 2021-06-17 08:40:05 --> Database Driver Class Initialized
DEBUG - 2021-06-17 08:40:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 08:40:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 08:40:05 --> Controller Class Initialized
DEBUG - 2021-06-17 08:40:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 08:40:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 08:40:05 --> Final output sent to browser
DEBUG - 2021-06-17 08:40:05 --> Total execution time: 0.0526
INFO - 2021-06-17 08:40:11 --> Config Class Initialized
INFO - 2021-06-17 08:40:11 --> Hooks Class Initialized
DEBUG - 2021-06-17 08:40:11 --> UTF-8 Support Enabled
INFO - 2021-06-17 08:40:11 --> Utf8 Class Initialized
INFO - 2021-06-17 08:40:11 --> URI Class Initialized
INFO - 2021-06-17 08:40:11 --> Router Class Initialized
INFO - 2021-06-17 08:40:11 --> Output Class Initialized
INFO - 2021-06-17 08:40:11 --> Security Class Initialized
DEBUG - 2021-06-17 08:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 08:40:11 --> Input Class Initialized
INFO - 2021-06-17 08:40:11 --> Language Class Initialized
INFO - 2021-06-17 08:40:11 --> Language Class Initialized
INFO - 2021-06-17 08:40:11 --> Config Class Initialized
INFO - 2021-06-17 08:40:11 --> Loader Class Initialized
INFO - 2021-06-17 08:40:11 --> Helper loaded: url_helper
INFO - 2021-06-17 08:40:11 --> Helper loaded: file_helper
INFO - 2021-06-17 08:40:11 --> Helper loaded: form_helper
INFO - 2021-06-17 08:40:11 --> Helper loaded: my_helper
INFO - 2021-06-17 08:40:11 --> Database Driver Class Initialized
DEBUG - 2021-06-17 08:40:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 08:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 08:40:11 --> Controller Class Initialized
DEBUG - 2021-06-17 08:40:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-17 08:40:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 08:40:11 --> Final output sent to browser
DEBUG - 2021-06-17 08:40:11 --> Total execution time: 0.0429
INFO - 2021-06-17 08:40:11 --> Config Class Initialized
INFO - 2021-06-17 08:40:11 --> Hooks Class Initialized
DEBUG - 2021-06-17 08:40:11 --> UTF-8 Support Enabled
INFO - 2021-06-17 08:40:11 --> Utf8 Class Initialized
INFO - 2021-06-17 08:40:11 --> URI Class Initialized
INFO - 2021-06-17 08:40:11 --> Router Class Initialized
INFO - 2021-06-17 08:40:11 --> Output Class Initialized
INFO - 2021-06-17 08:40:11 --> Security Class Initialized
DEBUG - 2021-06-17 08:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 08:40:11 --> Input Class Initialized
INFO - 2021-06-17 08:40:11 --> Language Class Initialized
INFO - 2021-06-17 08:40:11 --> Language Class Initialized
INFO - 2021-06-17 08:40:11 --> Config Class Initialized
INFO - 2021-06-17 08:40:11 --> Loader Class Initialized
INFO - 2021-06-17 08:40:11 --> Helper loaded: url_helper
INFO - 2021-06-17 08:40:11 --> Helper loaded: file_helper
INFO - 2021-06-17 08:40:11 --> Helper loaded: form_helper
INFO - 2021-06-17 08:40:11 --> Helper loaded: my_helper
INFO - 2021-06-17 08:40:11 --> Database Driver Class Initialized
DEBUG - 2021-06-17 08:40:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 08:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 08:40:11 --> Controller Class Initialized
INFO - 2021-06-17 08:40:12 --> Config Class Initialized
INFO - 2021-06-17 08:40:12 --> Hooks Class Initialized
DEBUG - 2021-06-17 08:40:12 --> UTF-8 Support Enabled
INFO - 2021-06-17 08:40:12 --> Utf8 Class Initialized
INFO - 2021-06-17 08:40:12 --> URI Class Initialized
INFO - 2021-06-17 08:40:12 --> Router Class Initialized
INFO - 2021-06-17 08:40:12 --> Output Class Initialized
INFO - 2021-06-17 08:40:12 --> Security Class Initialized
DEBUG - 2021-06-17 08:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 08:40:12 --> Input Class Initialized
INFO - 2021-06-17 08:40:12 --> Language Class Initialized
INFO - 2021-06-17 08:40:12 --> Language Class Initialized
INFO - 2021-06-17 08:40:12 --> Config Class Initialized
INFO - 2021-06-17 08:40:12 --> Loader Class Initialized
INFO - 2021-06-17 08:40:12 --> Helper loaded: url_helper
INFO - 2021-06-17 08:40:12 --> Helper loaded: file_helper
INFO - 2021-06-17 08:40:12 --> Helper loaded: form_helper
INFO - 2021-06-17 08:40:12 --> Helper loaded: my_helper
INFO - 2021-06-17 08:40:12 --> Database Driver Class Initialized
DEBUG - 2021-06-17 08:40:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 08:40:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 08:40:12 --> Controller Class Initialized
DEBUG - 2021-06-17 08:40:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 08:40:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 08:40:12 --> Final output sent to browser
DEBUG - 2021-06-17 08:40:12 --> Total execution time: 0.0425
INFO - 2021-06-17 08:40:14 --> Config Class Initialized
INFO - 2021-06-17 08:40:14 --> Hooks Class Initialized
DEBUG - 2021-06-17 08:40:14 --> UTF-8 Support Enabled
INFO - 2021-06-17 08:40:14 --> Utf8 Class Initialized
INFO - 2021-06-17 08:40:14 --> URI Class Initialized
INFO - 2021-06-17 08:40:14 --> Router Class Initialized
INFO - 2021-06-17 08:40:14 --> Output Class Initialized
INFO - 2021-06-17 08:40:14 --> Security Class Initialized
DEBUG - 2021-06-17 08:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 08:40:14 --> Input Class Initialized
INFO - 2021-06-17 08:40:14 --> Language Class Initialized
INFO - 2021-06-17 08:40:14 --> Language Class Initialized
INFO - 2021-06-17 08:40:14 --> Config Class Initialized
INFO - 2021-06-17 08:40:14 --> Loader Class Initialized
INFO - 2021-06-17 08:40:14 --> Helper loaded: url_helper
INFO - 2021-06-17 08:40:14 --> Helper loaded: file_helper
INFO - 2021-06-17 08:40:14 --> Helper loaded: form_helper
INFO - 2021-06-17 08:40:14 --> Helper loaded: my_helper
INFO - 2021-06-17 08:40:14 --> Database Driver Class Initialized
DEBUG - 2021-06-17 08:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 08:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 08:40:14 --> Controller Class Initialized
DEBUG - 2021-06-17 08:40:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-17 08:40:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 08:40:14 --> Final output sent to browser
DEBUG - 2021-06-17 08:40:14 --> Total execution time: 0.0434
INFO - 2021-06-17 08:40:14 --> Config Class Initialized
INFO - 2021-06-17 08:40:14 --> Hooks Class Initialized
DEBUG - 2021-06-17 08:40:14 --> UTF-8 Support Enabled
INFO - 2021-06-17 08:40:14 --> Utf8 Class Initialized
INFO - 2021-06-17 08:40:14 --> URI Class Initialized
INFO - 2021-06-17 08:40:14 --> Router Class Initialized
INFO - 2021-06-17 08:40:14 --> Output Class Initialized
INFO - 2021-06-17 08:40:14 --> Security Class Initialized
DEBUG - 2021-06-17 08:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 08:40:14 --> Input Class Initialized
INFO - 2021-06-17 08:40:14 --> Language Class Initialized
INFO - 2021-06-17 08:40:14 --> Language Class Initialized
INFO - 2021-06-17 08:40:14 --> Config Class Initialized
INFO - 2021-06-17 08:40:14 --> Loader Class Initialized
INFO - 2021-06-17 08:40:14 --> Helper loaded: url_helper
INFO - 2021-06-17 08:40:14 --> Helper loaded: file_helper
INFO - 2021-06-17 08:40:14 --> Helper loaded: form_helper
INFO - 2021-06-17 08:40:14 --> Helper loaded: my_helper
INFO - 2021-06-17 08:40:14 --> Database Driver Class Initialized
DEBUG - 2021-06-17 08:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 08:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 08:40:14 --> Controller Class Initialized
INFO - 2021-06-17 08:40:15 --> Config Class Initialized
INFO - 2021-06-17 08:40:15 --> Hooks Class Initialized
DEBUG - 2021-06-17 08:40:15 --> UTF-8 Support Enabled
INFO - 2021-06-17 08:40:15 --> Utf8 Class Initialized
INFO - 2021-06-17 08:40:15 --> URI Class Initialized
INFO - 2021-06-17 08:40:15 --> Router Class Initialized
INFO - 2021-06-17 08:40:15 --> Output Class Initialized
INFO - 2021-06-17 08:40:15 --> Security Class Initialized
DEBUG - 2021-06-17 08:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 08:40:15 --> Input Class Initialized
INFO - 2021-06-17 08:40:15 --> Language Class Initialized
INFO - 2021-06-17 08:40:15 --> Language Class Initialized
INFO - 2021-06-17 08:40:15 --> Config Class Initialized
INFO - 2021-06-17 08:40:15 --> Loader Class Initialized
INFO - 2021-06-17 08:40:15 --> Helper loaded: url_helper
INFO - 2021-06-17 08:40:15 --> Helper loaded: file_helper
INFO - 2021-06-17 08:40:15 --> Helper loaded: form_helper
INFO - 2021-06-17 08:40:15 --> Helper loaded: my_helper
INFO - 2021-06-17 08:40:15 --> Database Driver Class Initialized
DEBUG - 2021-06-17 08:40:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 08:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 08:40:15 --> Controller Class Initialized
DEBUG - 2021-06-17 08:40:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 08:40:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 08:40:15 --> Final output sent to browser
DEBUG - 2021-06-17 08:40:15 --> Total execution time: 0.0426
INFO - 2021-06-17 08:40:17 --> Config Class Initialized
INFO - 2021-06-17 08:40:17 --> Hooks Class Initialized
DEBUG - 2021-06-17 08:40:17 --> UTF-8 Support Enabled
INFO - 2021-06-17 08:40:17 --> Utf8 Class Initialized
INFO - 2021-06-17 08:40:17 --> URI Class Initialized
INFO - 2021-06-17 08:40:17 --> Router Class Initialized
INFO - 2021-06-17 08:40:17 --> Output Class Initialized
INFO - 2021-06-17 08:40:17 --> Security Class Initialized
DEBUG - 2021-06-17 08:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 08:40:17 --> Input Class Initialized
INFO - 2021-06-17 08:40:17 --> Language Class Initialized
INFO - 2021-06-17 08:40:17 --> Language Class Initialized
INFO - 2021-06-17 08:40:17 --> Config Class Initialized
INFO - 2021-06-17 08:40:17 --> Loader Class Initialized
INFO - 2021-06-17 08:40:17 --> Helper loaded: url_helper
INFO - 2021-06-17 08:40:17 --> Helper loaded: file_helper
INFO - 2021-06-17 08:40:17 --> Helper loaded: form_helper
INFO - 2021-06-17 08:40:17 --> Helper loaded: my_helper
INFO - 2021-06-17 08:40:17 --> Database Driver Class Initialized
DEBUG - 2021-06-17 08:40:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 08:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 08:40:17 --> Controller Class Initialized
INFO - 2021-06-17 08:40:17 --> Final output sent to browser
DEBUG - 2021-06-17 08:40:17 --> Total execution time: 0.0761
INFO - 2021-06-17 08:40:23 --> Config Class Initialized
INFO - 2021-06-17 08:40:23 --> Hooks Class Initialized
DEBUG - 2021-06-17 08:40:23 --> UTF-8 Support Enabled
INFO - 2021-06-17 08:40:23 --> Utf8 Class Initialized
INFO - 2021-06-17 08:40:23 --> URI Class Initialized
INFO - 2021-06-17 08:40:23 --> Router Class Initialized
INFO - 2021-06-17 08:40:23 --> Output Class Initialized
INFO - 2021-06-17 08:40:23 --> Security Class Initialized
DEBUG - 2021-06-17 08:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 08:40:23 --> Input Class Initialized
INFO - 2021-06-17 08:40:23 --> Language Class Initialized
INFO - 2021-06-17 08:40:23 --> Language Class Initialized
INFO - 2021-06-17 08:40:23 --> Config Class Initialized
INFO - 2021-06-17 08:40:23 --> Loader Class Initialized
INFO - 2021-06-17 08:40:23 --> Helper loaded: url_helper
INFO - 2021-06-17 08:40:23 --> Helper loaded: file_helper
INFO - 2021-06-17 08:40:23 --> Helper loaded: form_helper
INFO - 2021-06-17 08:40:23 --> Helper loaded: my_helper
INFO - 2021-06-17 08:40:23 --> Database Driver Class Initialized
DEBUG - 2021-06-17 08:40:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 08:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 08:40:23 --> Controller Class Initialized
INFO - 2021-06-17 08:40:23 --> Final output sent to browser
DEBUG - 2021-06-17 08:40:23 --> Total execution time: 0.0670
INFO - 2021-06-17 08:40:29 --> Config Class Initialized
INFO - 2021-06-17 08:40:29 --> Hooks Class Initialized
DEBUG - 2021-06-17 08:40:29 --> UTF-8 Support Enabled
INFO - 2021-06-17 08:40:29 --> Utf8 Class Initialized
INFO - 2021-06-17 08:40:29 --> URI Class Initialized
INFO - 2021-06-17 08:40:29 --> Router Class Initialized
INFO - 2021-06-17 08:40:29 --> Output Class Initialized
INFO - 2021-06-17 08:40:29 --> Security Class Initialized
DEBUG - 2021-06-17 08:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 08:40:29 --> Input Class Initialized
INFO - 2021-06-17 08:40:29 --> Language Class Initialized
INFO - 2021-06-17 08:40:29 --> Language Class Initialized
INFO - 2021-06-17 08:40:29 --> Config Class Initialized
INFO - 2021-06-17 08:40:29 --> Loader Class Initialized
INFO - 2021-06-17 08:40:29 --> Helper loaded: url_helper
INFO - 2021-06-17 08:40:29 --> Helper loaded: file_helper
INFO - 2021-06-17 08:40:29 --> Helper loaded: form_helper
INFO - 2021-06-17 08:40:29 --> Helper loaded: my_helper
INFO - 2021-06-17 08:40:29 --> Database Driver Class Initialized
DEBUG - 2021-06-17 08:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 08:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 08:40:29 --> Controller Class Initialized
INFO - 2021-06-17 08:40:31 --> Config Class Initialized
INFO - 2021-06-17 08:40:31 --> Hooks Class Initialized
DEBUG - 2021-06-17 08:40:31 --> UTF-8 Support Enabled
INFO - 2021-06-17 08:40:31 --> Utf8 Class Initialized
INFO - 2021-06-17 08:40:31 --> URI Class Initialized
INFO - 2021-06-17 08:40:31 --> Router Class Initialized
INFO - 2021-06-17 08:40:31 --> Output Class Initialized
INFO - 2021-06-17 08:40:31 --> Security Class Initialized
DEBUG - 2021-06-17 08:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 08:40:31 --> Input Class Initialized
INFO - 2021-06-17 08:40:31 --> Language Class Initialized
INFO - 2021-06-17 08:40:31 --> Language Class Initialized
INFO - 2021-06-17 08:40:31 --> Config Class Initialized
INFO - 2021-06-17 08:40:31 --> Loader Class Initialized
INFO - 2021-06-17 08:40:31 --> Helper loaded: url_helper
INFO - 2021-06-17 08:40:31 --> Helper loaded: file_helper
INFO - 2021-06-17 08:40:31 --> Helper loaded: form_helper
INFO - 2021-06-17 08:40:31 --> Helper loaded: my_helper
INFO - 2021-06-17 08:40:31 --> Database Driver Class Initialized
DEBUG - 2021-06-17 08:40:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 08:40:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 08:40:31 --> Controller Class Initialized
INFO - 2021-06-17 08:40:35 --> Config Class Initialized
INFO - 2021-06-17 08:40:35 --> Hooks Class Initialized
DEBUG - 2021-06-17 08:40:35 --> UTF-8 Support Enabled
INFO - 2021-06-17 08:40:35 --> Utf8 Class Initialized
INFO - 2021-06-17 08:40:35 --> URI Class Initialized
INFO - 2021-06-17 08:40:35 --> Router Class Initialized
INFO - 2021-06-17 08:40:35 --> Output Class Initialized
INFO - 2021-06-17 08:40:35 --> Security Class Initialized
DEBUG - 2021-06-17 08:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 08:40:35 --> Input Class Initialized
INFO - 2021-06-17 08:40:35 --> Language Class Initialized
INFO - 2021-06-17 08:40:35 --> Language Class Initialized
INFO - 2021-06-17 08:40:35 --> Config Class Initialized
INFO - 2021-06-17 08:40:35 --> Loader Class Initialized
INFO - 2021-06-17 08:40:35 --> Helper loaded: url_helper
INFO - 2021-06-17 08:40:35 --> Helper loaded: file_helper
INFO - 2021-06-17 08:40:35 --> Helper loaded: form_helper
INFO - 2021-06-17 08:40:35 --> Helper loaded: my_helper
INFO - 2021-06-17 08:40:35 --> Database Driver Class Initialized
DEBUG - 2021-06-17 08:40:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 08:40:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 08:40:35 --> Controller Class Initialized
INFO - 2021-06-17 08:40:35 --> Helper loaded: cookie_helper
INFO - 2021-06-17 08:40:35 --> Config Class Initialized
INFO - 2021-06-17 08:40:35 --> Hooks Class Initialized
DEBUG - 2021-06-17 08:40:35 --> UTF-8 Support Enabled
INFO - 2021-06-17 08:40:35 --> Utf8 Class Initialized
INFO - 2021-06-17 08:40:35 --> URI Class Initialized
INFO - 2021-06-17 08:40:35 --> Router Class Initialized
INFO - 2021-06-17 08:40:35 --> Output Class Initialized
INFO - 2021-06-17 08:40:35 --> Security Class Initialized
DEBUG - 2021-06-17 08:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 08:40:35 --> Input Class Initialized
INFO - 2021-06-17 08:40:35 --> Language Class Initialized
INFO - 2021-06-17 08:40:35 --> Language Class Initialized
INFO - 2021-06-17 08:40:35 --> Config Class Initialized
INFO - 2021-06-17 08:40:35 --> Loader Class Initialized
INFO - 2021-06-17 08:40:35 --> Helper loaded: url_helper
INFO - 2021-06-17 08:40:35 --> Helper loaded: file_helper
INFO - 2021-06-17 08:40:35 --> Helper loaded: form_helper
INFO - 2021-06-17 08:40:35 --> Helper loaded: my_helper
INFO - 2021-06-17 08:40:35 --> Database Driver Class Initialized
DEBUG - 2021-06-17 08:40:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 08:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 08:40:36 --> Controller Class Initialized
DEBUG - 2021-06-17 08:40:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-17 08:40:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 08:40:36 --> Final output sent to browser
DEBUG - 2021-06-17 08:40:36 --> Total execution time: 0.0523
INFO - 2021-06-17 09:09:48 --> Config Class Initialized
INFO - 2021-06-17 09:09:48 --> Hooks Class Initialized
DEBUG - 2021-06-17 09:09:48 --> UTF-8 Support Enabled
INFO - 2021-06-17 09:09:48 --> Utf8 Class Initialized
INFO - 2021-06-17 09:09:48 --> URI Class Initialized
DEBUG - 2021-06-17 09:09:48 --> No URI present. Default controller set.
INFO - 2021-06-17 09:09:48 --> Router Class Initialized
INFO - 2021-06-17 09:09:48 --> Output Class Initialized
INFO - 2021-06-17 09:09:48 --> Security Class Initialized
DEBUG - 2021-06-17 09:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 09:09:48 --> Input Class Initialized
INFO - 2021-06-17 09:09:48 --> Language Class Initialized
INFO - 2021-06-17 09:09:49 --> Language Class Initialized
INFO - 2021-06-17 09:09:49 --> Config Class Initialized
INFO - 2021-06-17 09:09:49 --> Loader Class Initialized
INFO - 2021-06-17 09:09:49 --> Helper loaded: url_helper
INFO - 2021-06-17 09:09:49 --> Helper loaded: file_helper
INFO - 2021-06-17 09:09:49 --> Helper loaded: form_helper
INFO - 2021-06-17 09:09:49 --> Helper loaded: my_helper
INFO - 2021-06-17 09:09:49 --> Database Driver Class Initialized
DEBUG - 2021-06-17 09:09:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 09:09:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 09:09:49 --> Controller Class Initialized
INFO - 2021-06-17 09:09:49 --> Config Class Initialized
INFO - 2021-06-17 09:09:49 --> Hooks Class Initialized
DEBUG - 2021-06-17 09:09:49 --> UTF-8 Support Enabled
INFO - 2021-06-17 09:09:49 --> Utf8 Class Initialized
INFO - 2021-06-17 09:09:49 --> URI Class Initialized
INFO - 2021-06-17 09:09:49 --> Router Class Initialized
INFO - 2021-06-17 09:09:49 --> Output Class Initialized
INFO - 2021-06-17 09:09:49 --> Security Class Initialized
DEBUG - 2021-06-17 09:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 09:09:49 --> Input Class Initialized
INFO - 2021-06-17 09:09:49 --> Language Class Initialized
INFO - 2021-06-17 09:09:49 --> Language Class Initialized
INFO - 2021-06-17 09:09:49 --> Config Class Initialized
INFO - 2021-06-17 09:09:49 --> Loader Class Initialized
INFO - 2021-06-17 09:09:49 --> Helper loaded: url_helper
INFO - 2021-06-17 09:09:49 --> Helper loaded: file_helper
INFO - 2021-06-17 09:09:49 --> Helper loaded: form_helper
INFO - 2021-06-17 09:09:49 --> Helper loaded: my_helper
INFO - 2021-06-17 09:09:49 --> Database Driver Class Initialized
DEBUG - 2021-06-17 09:09:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 09:09:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 09:09:49 --> Controller Class Initialized
DEBUG - 2021-06-17 09:09:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-17 09:09:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 09:09:49 --> Final output sent to browser
DEBUG - 2021-06-17 09:09:49 --> Total execution time: 0.1094
INFO - 2021-06-17 09:10:08 --> Config Class Initialized
INFO - 2021-06-17 09:10:08 --> Hooks Class Initialized
DEBUG - 2021-06-17 09:10:08 --> UTF-8 Support Enabled
INFO - 2021-06-17 09:10:08 --> Utf8 Class Initialized
INFO - 2021-06-17 09:10:08 --> URI Class Initialized
INFO - 2021-06-17 09:10:08 --> Router Class Initialized
INFO - 2021-06-17 09:10:08 --> Output Class Initialized
INFO - 2021-06-17 09:10:08 --> Security Class Initialized
DEBUG - 2021-06-17 09:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 09:10:08 --> Input Class Initialized
INFO - 2021-06-17 09:10:08 --> Language Class Initialized
INFO - 2021-06-17 09:10:08 --> Language Class Initialized
INFO - 2021-06-17 09:10:08 --> Config Class Initialized
INFO - 2021-06-17 09:10:08 --> Loader Class Initialized
INFO - 2021-06-17 09:10:08 --> Helper loaded: url_helper
INFO - 2021-06-17 09:10:08 --> Helper loaded: file_helper
INFO - 2021-06-17 09:10:08 --> Helper loaded: form_helper
INFO - 2021-06-17 09:10:08 --> Helper loaded: my_helper
INFO - 2021-06-17 09:10:08 --> Database Driver Class Initialized
DEBUG - 2021-06-17 09:10:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 09:10:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 09:10:08 --> Controller Class Initialized
INFO - 2021-06-17 09:10:08 --> Helper loaded: cookie_helper
INFO - 2021-06-17 09:10:08 --> Final output sent to browser
DEBUG - 2021-06-17 09:10:08 --> Total execution time: 0.0984
INFO - 2021-06-17 09:10:11 --> Config Class Initialized
INFO - 2021-06-17 09:10:11 --> Hooks Class Initialized
DEBUG - 2021-06-17 09:10:11 --> UTF-8 Support Enabled
INFO - 2021-06-17 09:10:11 --> Utf8 Class Initialized
INFO - 2021-06-17 09:10:11 --> URI Class Initialized
INFO - 2021-06-17 09:10:11 --> Router Class Initialized
INFO - 2021-06-17 09:10:11 --> Output Class Initialized
INFO - 2021-06-17 09:10:11 --> Security Class Initialized
DEBUG - 2021-06-17 09:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 09:10:11 --> Input Class Initialized
INFO - 2021-06-17 09:10:11 --> Language Class Initialized
INFO - 2021-06-17 09:10:11 --> Language Class Initialized
INFO - 2021-06-17 09:10:11 --> Config Class Initialized
INFO - 2021-06-17 09:10:11 --> Loader Class Initialized
INFO - 2021-06-17 09:10:11 --> Helper loaded: url_helper
INFO - 2021-06-17 09:10:11 --> Helper loaded: file_helper
INFO - 2021-06-17 09:10:11 --> Helper loaded: form_helper
INFO - 2021-06-17 09:10:11 --> Helper loaded: my_helper
INFO - 2021-06-17 09:10:11 --> Database Driver Class Initialized
DEBUG - 2021-06-17 09:10:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 09:10:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 09:10:11 --> Controller Class Initialized
DEBUG - 2021-06-17 09:10:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-17 09:10:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 09:10:11 --> Final output sent to browser
DEBUG - 2021-06-17 09:10:11 --> Total execution time: 0.2800
INFO - 2021-06-17 09:10:22 --> Config Class Initialized
INFO - 2021-06-17 09:10:22 --> Hooks Class Initialized
DEBUG - 2021-06-17 09:10:22 --> UTF-8 Support Enabled
INFO - 2021-06-17 09:10:22 --> Utf8 Class Initialized
INFO - 2021-06-17 09:10:22 --> URI Class Initialized
INFO - 2021-06-17 09:10:22 --> Router Class Initialized
INFO - 2021-06-17 09:10:22 --> Output Class Initialized
INFO - 2021-06-17 09:10:22 --> Security Class Initialized
DEBUG - 2021-06-17 09:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 09:10:22 --> Input Class Initialized
INFO - 2021-06-17 09:10:22 --> Language Class Initialized
INFO - 2021-06-17 09:10:22 --> Language Class Initialized
INFO - 2021-06-17 09:10:22 --> Config Class Initialized
INFO - 2021-06-17 09:10:22 --> Loader Class Initialized
INFO - 2021-06-17 09:10:22 --> Helper loaded: url_helper
INFO - 2021-06-17 09:10:22 --> Helper loaded: file_helper
INFO - 2021-06-17 09:10:22 --> Helper loaded: form_helper
INFO - 2021-06-17 09:10:22 --> Helper loaded: my_helper
INFO - 2021-06-17 09:10:22 --> Database Driver Class Initialized
DEBUG - 2021-06-17 09:10:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 09:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 09:10:22 --> Controller Class Initialized
DEBUG - 2021-06-17 09:10:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-17 09:10:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 09:10:22 --> Final output sent to browser
DEBUG - 2021-06-17 09:10:22 --> Total execution time: 0.0781
INFO - 2021-06-17 09:10:29 --> Config Class Initialized
INFO - 2021-06-17 09:10:29 --> Hooks Class Initialized
DEBUG - 2021-06-17 09:10:29 --> UTF-8 Support Enabled
INFO - 2021-06-17 09:10:29 --> Utf8 Class Initialized
INFO - 2021-06-17 09:10:29 --> URI Class Initialized
INFO - 2021-06-17 09:10:29 --> Router Class Initialized
INFO - 2021-06-17 09:10:29 --> Output Class Initialized
INFO - 2021-06-17 09:10:29 --> Security Class Initialized
DEBUG - 2021-06-17 09:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 09:10:29 --> Input Class Initialized
INFO - 2021-06-17 09:10:29 --> Language Class Initialized
INFO - 2021-06-17 09:10:29 --> Language Class Initialized
INFO - 2021-06-17 09:10:29 --> Config Class Initialized
INFO - 2021-06-17 09:10:29 --> Loader Class Initialized
INFO - 2021-06-17 09:10:29 --> Helper loaded: url_helper
INFO - 2021-06-17 09:10:29 --> Helper loaded: file_helper
INFO - 2021-06-17 09:10:29 --> Helper loaded: form_helper
INFO - 2021-06-17 09:10:29 --> Helper loaded: my_helper
INFO - 2021-06-17 09:10:29 --> Database Driver Class Initialized
DEBUG - 2021-06-17 09:10:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 09:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 09:10:29 --> Controller Class Initialized
DEBUG - 2021-06-17 09:10:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-17 09:10:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 09:10:29 --> Final output sent to browser
DEBUG - 2021-06-17 09:10:29 --> Total execution time: 0.0969
INFO - 2021-06-17 09:10:29 --> Config Class Initialized
INFO - 2021-06-17 09:10:29 --> Hooks Class Initialized
DEBUG - 2021-06-17 09:10:29 --> UTF-8 Support Enabled
INFO - 2021-06-17 09:10:29 --> Utf8 Class Initialized
INFO - 2021-06-17 09:10:29 --> URI Class Initialized
INFO - 2021-06-17 09:10:29 --> Router Class Initialized
INFO - 2021-06-17 09:10:29 --> Output Class Initialized
INFO - 2021-06-17 09:10:29 --> Security Class Initialized
DEBUG - 2021-06-17 09:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 09:10:29 --> Input Class Initialized
INFO - 2021-06-17 09:10:29 --> Language Class Initialized
INFO - 2021-06-17 09:10:29 --> Language Class Initialized
INFO - 2021-06-17 09:10:29 --> Config Class Initialized
INFO - 2021-06-17 09:10:29 --> Loader Class Initialized
INFO - 2021-06-17 09:10:29 --> Helper loaded: url_helper
INFO - 2021-06-17 09:10:29 --> Helper loaded: file_helper
INFO - 2021-06-17 09:10:29 --> Helper loaded: form_helper
INFO - 2021-06-17 09:10:29 --> Helper loaded: my_helper
INFO - 2021-06-17 09:10:29 --> Database Driver Class Initialized
DEBUG - 2021-06-17 09:10:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 09:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 09:10:29 --> Controller Class Initialized
INFO - 2021-06-17 09:10:35 --> Config Class Initialized
INFO - 2021-06-17 09:10:35 --> Hooks Class Initialized
DEBUG - 2021-06-17 09:10:35 --> UTF-8 Support Enabled
INFO - 2021-06-17 09:10:35 --> Utf8 Class Initialized
INFO - 2021-06-17 09:10:35 --> URI Class Initialized
INFO - 2021-06-17 09:10:35 --> Router Class Initialized
INFO - 2021-06-17 09:10:35 --> Output Class Initialized
INFO - 2021-06-17 09:10:35 --> Security Class Initialized
DEBUG - 2021-06-17 09:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 09:10:35 --> Input Class Initialized
INFO - 2021-06-17 09:10:35 --> Language Class Initialized
INFO - 2021-06-17 09:10:35 --> Language Class Initialized
INFO - 2021-06-17 09:10:35 --> Config Class Initialized
INFO - 2021-06-17 09:10:35 --> Loader Class Initialized
INFO - 2021-06-17 09:10:35 --> Helper loaded: url_helper
INFO - 2021-06-17 09:10:35 --> Helper loaded: file_helper
INFO - 2021-06-17 09:10:35 --> Helper loaded: form_helper
INFO - 2021-06-17 09:10:35 --> Helper loaded: my_helper
INFO - 2021-06-17 09:10:35 --> Database Driver Class Initialized
DEBUG - 2021-06-17 09:10:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 09:10:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 09:10:35 --> Controller Class Initialized
INFO - 2021-06-17 09:10:35 --> Final output sent to browser
DEBUG - 2021-06-17 09:10:35 --> Total execution time: 0.0616
INFO - 2021-06-17 09:12:53 --> Config Class Initialized
INFO - 2021-06-17 09:12:53 --> Hooks Class Initialized
DEBUG - 2021-06-17 09:12:53 --> UTF-8 Support Enabled
INFO - 2021-06-17 09:12:53 --> Utf8 Class Initialized
INFO - 2021-06-17 09:12:53 --> URI Class Initialized
INFO - 2021-06-17 09:12:53 --> Router Class Initialized
INFO - 2021-06-17 09:12:53 --> Output Class Initialized
INFO - 2021-06-17 09:12:53 --> Security Class Initialized
DEBUG - 2021-06-17 09:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 09:12:53 --> Input Class Initialized
INFO - 2021-06-17 09:12:53 --> Language Class Initialized
INFO - 2021-06-17 09:12:53 --> Language Class Initialized
INFO - 2021-06-17 09:12:53 --> Config Class Initialized
INFO - 2021-06-17 09:12:53 --> Loader Class Initialized
INFO - 2021-06-17 09:12:53 --> Helper loaded: url_helper
INFO - 2021-06-17 09:12:53 --> Helper loaded: file_helper
INFO - 2021-06-17 09:12:53 --> Helper loaded: form_helper
INFO - 2021-06-17 09:12:53 --> Helper loaded: my_helper
INFO - 2021-06-17 09:12:53 --> Database Driver Class Initialized
DEBUG - 2021-06-17 09:12:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 09:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 09:12:53 --> Controller Class Initialized
INFO - 2021-06-17 09:12:53 --> Final output sent to browser
DEBUG - 2021-06-17 09:12:53 --> Total execution time: 0.0493
INFO - 2021-06-17 09:12:53 --> Config Class Initialized
INFO - 2021-06-17 09:12:53 --> Hooks Class Initialized
DEBUG - 2021-06-17 09:12:53 --> UTF-8 Support Enabled
INFO - 2021-06-17 09:12:53 --> Utf8 Class Initialized
INFO - 2021-06-17 09:12:53 --> URI Class Initialized
INFO - 2021-06-17 09:12:53 --> Router Class Initialized
INFO - 2021-06-17 09:12:53 --> Output Class Initialized
INFO - 2021-06-17 09:12:53 --> Security Class Initialized
DEBUG - 2021-06-17 09:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 09:12:53 --> Input Class Initialized
INFO - 2021-06-17 09:12:53 --> Language Class Initialized
INFO - 2021-06-17 09:12:53 --> Language Class Initialized
INFO - 2021-06-17 09:12:53 --> Config Class Initialized
INFO - 2021-06-17 09:12:53 --> Loader Class Initialized
INFO - 2021-06-17 09:12:53 --> Helper loaded: url_helper
INFO - 2021-06-17 09:12:53 --> Helper loaded: file_helper
INFO - 2021-06-17 09:12:53 --> Helper loaded: form_helper
INFO - 2021-06-17 09:12:53 --> Helper loaded: my_helper
INFO - 2021-06-17 09:12:53 --> Database Driver Class Initialized
DEBUG - 2021-06-17 09:12:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 09:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 09:12:53 --> Controller Class Initialized
INFO - 2021-06-17 09:12:56 --> Config Class Initialized
INFO - 2021-06-17 09:12:56 --> Hooks Class Initialized
DEBUG - 2021-06-17 09:12:56 --> UTF-8 Support Enabled
INFO - 2021-06-17 09:12:56 --> Utf8 Class Initialized
INFO - 2021-06-17 09:12:56 --> URI Class Initialized
INFO - 2021-06-17 09:12:56 --> Router Class Initialized
INFO - 2021-06-17 09:12:56 --> Output Class Initialized
INFO - 2021-06-17 09:12:56 --> Security Class Initialized
DEBUG - 2021-06-17 09:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 09:12:56 --> Input Class Initialized
INFO - 2021-06-17 09:12:56 --> Language Class Initialized
INFO - 2021-06-17 09:12:56 --> Language Class Initialized
INFO - 2021-06-17 09:12:56 --> Config Class Initialized
INFO - 2021-06-17 09:12:56 --> Loader Class Initialized
INFO - 2021-06-17 09:12:56 --> Helper loaded: url_helper
INFO - 2021-06-17 09:12:56 --> Helper loaded: file_helper
INFO - 2021-06-17 09:12:56 --> Helper loaded: form_helper
INFO - 2021-06-17 09:12:56 --> Helper loaded: my_helper
INFO - 2021-06-17 09:12:56 --> Database Driver Class Initialized
DEBUG - 2021-06-17 09:12:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 09:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 09:12:56 --> Controller Class Initialized
INFO - 2021-06-17 09:12:56 --> Final output sent to browser
DEBUG - 2021-06-17 09:12:56 --> Total execution time: 0.0361
INFO - 2021-06-17 09:13:07 --> Config Class Initialized
INFO - 2021-06-17 09:13:07 --> Hooks Class Initialized
DEBUG - 2021-06-17 09:13:07 --> UTF-8 Support Enabled
INFO - 2021-06-17 09:13:07 --> Utf8 Class Initialized
INFO - 2021-06-17 09:13:07 --> URI Class Initialized
INFO - 2021-06-17 09:13:07 --> Router Class Initialized
INFO - 2021-06-17 09:13:07 --> Output Class Initialized
INFO - 2021-06-17 09:13:07 --> Security Class Initialized
DEBUG - 2021-06-17 09:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 09:13:07 --> Input Class Initialized
INFO - 2021-06-17 09:13:07 --> Language Class Initialized
INFO - 2021-06-17 09:13:07 --> Language Class Initialized
INFO - 2021-06-17 09:13:07 --> Config Class Initialized
INFO - 2021-06-17 09:13:07 --> Loader Class Initialized
INFO - 2021-06-17 09:13:07 --> Helper loaded: url_helper
INFO - 2021-06-17 09:13:07 --> Helper loaded: file_helper
INFO - 2021-06-17 09:13:07 --> Helper loaded: form_helper
INFO - 2021-06-17 09:13:07 --> Helper loaded: my_helper
INFO - 2021-06-17 09:13:07 --> Database Driver Class Initialized
DEBUG - 2021-06-17 09:13:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 09:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 09:13:07 --> Controller Class Initialized
INFO - 2021-06-17 09:13:07 --> Final output sent to browser
DEBUG - 2021-06-17 09:13:07 --> Total execution time: 0.0481
INFO - 2021-06-17 09:14:13 --> Config Class Initialized
INFO - 2021-06-17 09:14:13 --> Hooks Class Initialized
DEBUG - 2021-06-17 09:14:13 --> UTF-8 Support Enabled
INFO - 2021-06-17 09:14:13 --> Utf8 Class Initialized
INFO - 2021-06-17 09:14:13 --> URI Class Initialized
INFO - 2021-06-17 09:14:13 --> Router Class Initialized
INFO - 2021-06-17 09:14:13 --> Output Class Initialized
INFO - 2021-06-17 09:14:13 --> Security Class Initialized
DEBUG - 2021-06-17 09:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 09:14:13 --> Input Class Initialized
INFO - 2021-06-17 09:14:13 --> Language Class Initialized
INFO - 2021-06-17 09:14:13 --> Language Class Initialized
INFO - 2021-06-17 09:14:13 --> Config Class Initialized
INFO - 2021-06-17 09:14:13 --> Loader Class Initialized
INFO - 2021-06-17 09:14:13 --> Helper loaded: url_helper
INFO - 2021-06-17 09:14:13 --> Helper loaded: file_helper
INFO - 2021-06-17 09:14:13 --> Helper loaded: form_helper
INFO - 2021-06-17 09:14:13 --> Helper loaded: my_helper
INFO - 2021-06-17 09:14:13 --> Database Driver Class Initialized
DEBUG - 2021-06-17 09:14:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 09:14:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 09:14:13 --> Controller Class Initialized
INFO - 2021-06-17 09:14:13 --> Final output sent to browser
DEBUG - 2021-06-17 09:14:13 --> Total execution time: 0.0487
INFO - 2021-06-17 09:14:13 --> Config Class Initialized
INFO - 2021-06-17 09:14:13 --> Hooks Class Initialized
DEBUG - 2021-06-17 09:14:13 --> UTF-8 Support Enabled
INFO - 2021-06-17 09:14:13 --> Utf8 Class Initialized
INFO - 2021-06-17 09:14:13 --> URI Class Initialized
INFO - 2021-06-17 09:14:13 --> Router Class Initialized
INFO - 2021-06-17 09:14:13 --> Output Class Initialized
INFO - 2021-06-17 09:14:13 --> Security Class Initialized
DEBUG - 2021-06-17 09:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 09:14:13 --> Input Class Initialized
INFO - 2021-06-17 09:14:13 --> Language Class Initialized
INFO - 2021-06-17 09:14:13 --> Language Class Initialized
INFO - 2021-06-17 09:14:13 --> Config Class Initialized
INFO - 2021-06-17 09:14:13 --> Loader Class Initialized
INFO - 2021-06-17 09:14:13 --> Helper loaded: url_helper
INFO - 2021-06-17 09:14:13 --> Helper loaded: file_helper
INFO - 2021-06-17 09:14:13 --> Helper loaded: form_helper
INFO - 2021-06-17 09:14:13 --> Helper loaded: my_helper
INFO - 2021-06-17 09:14:13 --> Database Driver Class Initialized
DEBUG - 2021-06-17 09:14:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 09:14:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 09:14:13 --> Controller Class Initialized
INFO - 2021-06-17 09:14:15 --> Config Class Initialized
INFO - 2021-06-17 09:14:15 --> Hooks Class Initialized
DEBUG - 2021-06-17 09:14:15 --> UTF-8 Support Enabled
INFO - 2021-06-17 09:14:15 --> Utf8 Class Initialized
INFO - 2021-06-17 09:14:15 --> URI Class Initialized
INFO - 2021-06-17 09:14:15 --> Router Class Initialized
INFO - 2021-06-17 09:14:15 --> Output Class Initialized
INFO - 2021-06-17 09:14:15 --> Security Class Initialized
DEBUG - 2021-06-17 09:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 09:14:15 --> Input Class Initialized
INFO - 2021-06-17 09:14:15 --> Language Class Initialized
INFO - 2021-06-17 09:14:15 --> Language Class Initialized
INFO - 2021-06-17 09:14:15 --> Config Class Initialized
INFO - 2021-06-17 09:14:15 --> Loader Class Initialized
INFO - 2021-06-17 09:14:15 --> Helper loaded: url_helper
INFO - 2021-06-17 09:14:15 --> Helper loaded: file_helper
INFO - 2021-06-17 09:14:15 --> Helper loaded: form_helper
INFO - 2021-06-17 09:14:15 --> Helper loaded: my_helper
INFO - 2021-06-17 09:14:15 --> Database Driver Class Initialized
DEBUG - 2021-06-17 09:14:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 09:14:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 09:14:15 --> Controller Class Initialized
INFO - 2021-06-17 09:14:15 --> Final output sent to browser
DEBUG - 2021-06-17 09:14:15 --> Total execution time: 0.0364
INFO - 2021-06-17 09:15:16 --> Config Class Initialized
INFO - 2021-06-17 09:15:16 --> Hooks Class Initialized
DEBUG - 2021-06-17 09:15:16 --> UTF-8 Support Enabled
INFO - 2021-06-17 09:15:16 --> Utf8 Class Initialized
INFO - 2021-06-17 09:15:16 --> URI Class Initialized
INFO - 2021-06-17 09:15:16 --> Router Class Initialized
INFO - 2021-06-17 09:15:16 --> Output Class Initialized
INFO - 2021-06-17 09:15:16 --> Security Class Initialized
DEBUG - 2021-06-17 09:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 09:15:16 --> Input Class Initialized
INFO - 2021-06-17 09:15:16 --> Language Class Initialized
INFO - 2021-06-17 09:15:16 --> Language Class Initialized
INFO - 2021-06-17 09:15:16 --> Config Class Initialized
INFO - 2021-06-17 09:15:16 --> Loader Class Initialized
INFO - 2021-06-17 09:15:16 --> Helper loaded: url_helper
INFO - 2021-06-17 09:15:16 --> Helper loaded: file_helper
INFO - 2021-06-17 09:15:16 --> Helper loaded: form_helper
INFO - 2021-06-17 09:15:16 --> Helper loaded: my_helper
INFO - 2021-06-17 09:15:16 --> Database Driver Class Initialized
DEBUG - 2021-06-17 09:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 09:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 09:15:16 --> Controller Class Initialized
INFO - 2021-06-17 09:15:16 --> Final output sent to browser
DEBUG - 2021-06-17 09:15:16 --> Total execution time: 0.0493
INFO - 2021-06-17 09:15:16 --> Config Class Initialized
INFO - 2021-06-17 09:15:16 --> Hooks Class Initialized
DEBUG - 2021-06-17 09:15:16 --> UTF-8 Support Enabled
INFO - 2021-06-17 09:15:16 --> Utf8 Class Initialized
INFO - 2021-06-17 09:15:16 --> URI Class Initialized
INFO - 2021-06-17 09:15:16 --> Router Class Initialized
INFO - 2021-06-17 09:15:16 --> Output Class Initialized
INFO - 2021-06-17 09:15:16 --> Security Class Initialized
DEBUG - 2021-06-17 09:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 09:15:16 --> Input Class Initialized
INFO - 2021-06-17 09:15:16 --> Language Class Initialized
INFO - 2021-06-17 09:15:16 --> Language Class Initialized
INFO - 2021-06-17 09:15:16 --> Config Class Initialized
INFO - 2021-06-17 09:15:16 --> Loader Class Initialized
INFO - 2021-06-17 09:15:16 --> Helper loaded: url_helper
INFO - 2021-06-17 09:15:16 --> Helper loaded: file_helper
INFO - 2021-06-17 09:15:16 --> Helper loaded: form_helper
INFO - 2021-06-17 09:15:16 --> Helper loaded: my_helper
INFO - 2021-06-17 09:15:16 --> Database Driver Class Initialized
DEBUG - 2021-06-17 09:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 09:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 09:15:16 --> Controller Class Initialized
INFO - 2021-06-17 09:15:54 --> Config Class Initialized
INFO - 2021-06-17 09:15:54 --> Hooks Class Initialized
DEBUG - 2021-06-17 09:15:54 --> UTF-8 Support Enabled
INFO - 2021-06-17 09:15:54 --> Utf8 Class Initialized
INFO - 2021-06-17 09:15:54 --> URI Class Initialized
INFO - 2021-06-17 09:15:54 --> Router Class Initialized
INFO - 2021-06-17 09:15:54 --> Output Class Initialized
INFO - 2021-06-17 09:15:54 --> Security Class Initialized
DEBUG - 2021-06-17 09:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 09:15:54 --> Input Class Initialized
INFO - 2021-06-17 09:15:54 --> Language Class Initialized
INFO - 2021-06-17 09:15:54 --> Language Class Initialized
INFO - 2021-06-17 09:15:54 --> Config Class Initialized
INFO - 2021-06-17 09:15:54 --> Loader Class Initialized
INFO - 2021-06-17 09:15:54 --> Helper loaded: url_helper
INFO - 2021-06-17 09:15:54 --> Helper loaded: file_helper
INFO - 2021-06-17 09:15:54 --> Helper loaded: form_helper
INFO - 2021-06-17 09:15:54 --> Helper loaded: my_helper
INFO - 2021-06-17 09:15:54 --> Database Driver Class Initialized
DEBUG - 2021-06-17 09:15:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 09:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 09:15:54 --> Controller Class Initialized
DEBUG - 2021-06-17 09:15:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-17 09:15:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 09:15:54 --> Final output sent to browser
DEBUG - 2021-06-17 09:15:54 --> Total execution time: 0.0481
INFO - 2021-06-17 09:16:10 --> Config Class Initialized
INFO - 2021-06-17 09:16:10 --> Hooks Class Initialized
DEBUG - 2021-06-17 09:16:10 --> UTF-8 Support Enabled
INFO - 2021-06-17 09:16:10 --> Utf8 Class Initialized
INFO - 2021-06-17 09:16:10 --> URI Class Initialized
INFO - 2021-06-17 09:16:10 --> Router Class Initialized
INFO - 2021-06-17 09:16:10 --> Output Class Initialized
INFO - 2021-06-17 09:16:10 --> Security Class Initialized
DEBUG - 2021-06-17 09:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 09:16:10 --> Input Class Initialized
INFO - 2021-06-17 09:16:10 --> Language Class Initialized
INFO - 2021-06-17 09:16:10 --> Language Class Initialized
INFO - 2021-06-17 09:16:10 --> Config Class Initialized
INFO - 2021-06-17 09:16:10 --> Loader Class Initialized
INFO - 2021-06-17 09:16:10 --> Helper loaded: url_helper
INFO - 2021-06-17 09:16:10 --> Helper loaded: file_helper
INFO - 2021-06-17 09:16:10 --> Helper loaded: form_helper
INFO - 2021-06-17 09:16:10 --> Helper loaded: my_helper
INFO - 2021-06-17 09:16:10 --> Database Driver Class Initialized
DEBUG - 2021-06-17 09:16:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 09:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 09:16:10 --> Controller Class Initialized
DEBUG - 2021-06-17 09:16:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 09:16:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 09:16:10 --> Final output sent to browser
DEBUG - 2021-06-17 09:16:10 --> Total execution time: 0.1065
INFO - 2021-06-17 09:16:28 --> Config Class Initialized
INFO - 2021-06-17 09:16:28 --> Hooks Class Initialized
DEBUG - 2021-06-17 09:16:28 --> UTF-8 Support Enabled
INFO - 2021-06-17 09:16:28 --> Utf8 Class Initialized
INFO - 2021-06-17 09:16:28 --> URI Class Initialized
INFO - 2021-06-17 09:16:28 --> Router Class Initialized
INFO - 2021-06-17 09:16:28 --> Output Class Initialized
INFO - 2021-06-17 09:16:28 --> Security Class Initialized
DEBUG - 2021-06-17 09:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 09:16:28 --> Input Class Initialized
INFO - 2021-06-17 09:16:28 --> Language Class Initialized
INFO - 2021-06-17 09:16:28 --> Language Class Initialized
INFO - 2021-06-17 09:16:28 --> Config Class Initialized
INFO - 2021-06-17 09:16:28 --> Loader Class Initialized
INFO - 2021-06-17 09:16:28 --> Helper loaded: url_helper
INFO - 2021-06-17 09:16:28 --> Helper loaded: file_helper
INFO - 2021-06-17 09:16:28 --> Helper loaded: form_helper
INFO - 2021-06-17 09:16:28 --> Helper loaded: my_helper
INFO - 2021-06-17 09:16:28 --> Database Driver Class Initialized
DEBUG - 2021-06-17 09:16:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 09:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 09:16:28 --> Controller Class Initialized
INFO - 2021-06-17 09:16:28 --> Final output sent to browser
DEBUG - 2021-06-17 09:16:28 --> Total execution time: 0.0365
INFO - 2021-06-17 09:17:25 --> Config Class Initialized
INFO - 2021-06-17 09:17:25 --> Hooks Class Initialized
DEBUG - 2021-06-17 09:17:25 --> UTF-8 Support Enabled
INFO - 2021-06-17 09:17:25 --> Utf8 Class Initialized
INFO - 2021-06-17 09:17:25 --> URI Class Initialized
INFO - 2021-06-17 09:17:25 --> Router Class Initialized
INFO - 2021-06-17 09:17:25 --> Output Class Initialized
INFO - 2021-06-17 09:17:25 --> Security Class Initialized
DEBUG - 2021-06-17 09:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 09:17:25 --> Input Class Initialized
INFO - 2021-06-17 09:17:25 --> Language Class Initialized
INFO - 2021-06-17 09:17:25 --> Language Class Initialized
INFO - 2021-06-17 09:17:25 --> Config Class Initialized
INFO - 2021-06-17 09:17:25 --> Loader Class Initialized
INFO - 2021-06-17 09:17:25 --> Helper loaded: url_helper
INFO - 2021-06-17 09:17:25 --> Helper loaded: file_helper
INFO - 2021-06-17 09:17:25 --> Helper loaded: form_helper
INFO - 2021-06-17 09:17:25 --> Helper loaded: my_helper
INFO - 2021-06-17 09:17:25 --> Database Driver Class Initialized
DEBUG - 2021-06-17 09:17:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 09:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 09:17:25 --> Controller Class Initialized
INFO - 2021-06-17 09:17:25 --> Final output sent to browser
DEBUG - 2021-06-17 09:17:25 --> Total execution time: 0.0488
INFO - 2021-06-17 09:17:25 --> Config Class Initialized
INFO - 2021-06-17 09:17:25 --> Hooks Class Initialized
DEBUG - 2021-06-17 09:17:25 --> UTF-8 Support Enabled
INFO - 2021-06-17 09:17:25 --> Utf8 Class Initialized
INFO - 2021-06-17 09:17:25 --> URI Class Initialized
INFO - 2021-06-17 09:17:25 --> Router Class Initialized
INFO - 2021-06-17 09:17:25 --> Output Class Initialized
INFO - 2021-06-17 09:17:25 --> Security Class Initialized
DEBUG - 2021-06-17 09:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 09:17:25 --> Input Class Initialized
INFO - 2021-06-17 09:17:25 --> Language Class Initialized
INFO - 2021-06-17 09:17:25 --> Language Class Initialized
INFO - 2021-06-17 09:17:25 --> Config Class Initialized
INFO - 2021-06-17 09:17:25 --> Loader Class Initialized
INFO - 2021-06-17 09:17:25 --> Helper loaded: url_helper
INFO - 2021-06-17 09:17:25 --> Helper loaded: file_helper
INFO - 2021-06-17 09:17:25 --> Helper loaded: form_helper
INFO - 2021-06-17 09:17:25 --> Helper loaded: my_helper
INFO - 2021-06-17 09:17:25 --> Database Driver Class Initialized
DEBUG - 2021-06-17 09:17:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 09:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 09:17:25 --> Controller Class Initialized
DEBUG - 2021-06-17 09:17:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 09:17:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 09:17:25 --> Final output sent to browser
DEBUG - 2021-06-17 09:17:25 --> Total execution time: 0.0579
INFO - 2021-06-17 09:17:27 --> Config Class Initialized
INFO - 2021-06-17 09:17:27 --> Hooks Class Initialized
DEBUG - 2021-06-17 09:17:27 --> UTF-8 Support Enabled
INFO - 2021-06-17 09:17:27 --> Utf8 Class Initialized
INFO - 2021-06-17 09:17:27 --> URI Class Initialized
INFO - 2021-06-17 09:17:27 --> Router Class Initialized
INFO - 2021-06-17 09:17:27 --> Output Class Initialized
INFO - 2021-06-17 09:17:27 --> Security Class Initialized
DEBUG - 2021-06-17 09:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 09:17:27 --> Input Class Initialized
INFO - 2021-06-17 09:17:27 --> Language Class Initialized
INFO - 2021-06-17 09:17:27 --> Language Class Initialized
INFO - 2021-06-17 09:17:27 --> Config Class Initialized
INFO - 2021-06-17 09:17:27 --> Loader Class Initialized
INFO - 2021-06-17 09:17:27 --> Helper loaded: url_helper
INFO - 2021-06-17 09:17:27 --> Helper loaded: file_helper
INFO - 2021-06-17 09:17:27 --> Helper loaded: form_helper
INFO - 2021-06-17 09:17:27 --> Helper loaded: my_helper
INFO - 2021-06-17 09:17:27 --> Database Driver Class Initialized
DEBUG - 2021-06-17 09:17:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 09:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 09:17:27 --> Controller Class Initialized
INFO - 2021-06-17 09:17:27 --> Final output sent to browser
DEBUG - 2021-06-17 09:17:27 --> Total execution time: 0.0457
INFO - 2021-06-17 09:18:04 --> Config Class Initialized
INFO - 2021-06-17 09:18:04 --> Hooks Class Initialized
DEBUG - 2021-06-17 09:18:04 --> UTF-8 Support Enabled
INFO - 2021-06-17 09:18:04 --> Utf8 Class Initialized
INFO - 2021-06-17 09:18:04 --> URI Class Initialized
INFO - 2021-06-17 09:18:04 --> Router Class Initialized
INFO - 2021-06-17 09:18:04 --> Output Class Initialized
INFO - 2021-06-17 09:18:04 --> Security Class Initialized
DEBUG - 2021-06-17 09:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 09:18:04 --> Input Class Initialized
INFO - 2021-06-17 09:18:04 --> Language Class Initialized
INFO - 2021-06-17 09:18:04 --> Language Class Initialized
INFO - 2021-06-17 09:18:04 --> Config Class Initialized
INFO - 2021-06-17 09:18:04 --> Loader Class Initialized
INFO - 2021-06-17 09:18:04 --> Helper loaded: url_helper
INFO - 2021-06-17 09:18:04 --> Helper loaded: file_helper
INFO - 2021-06-17 09:18:04 --> Helper loaded: form_helper
INFO - 2021-06-17 09:18:04 --> Helper loaded: my_helper
INFO - 2021-06-17 09:18:04 --> Database Driver Class Initialized
DEBUG - 2021-06-17 09:18:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 09:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 09:18:04 --> Controller Class Initialized
INFO - 2021-06-17 09:18:04 --> Final output sent to browser
DEBUG - 2021-06-17 09:18:04 --> Total execution time: 0.0473
INFO - 2021-06-17 09:18:04 --> Config Class Initialized
INFO - 2021-06-17 09:18:04 --> Hooks Class Initialized
DEBUG - 2021-06-17 09:18:04 --> UTF-8 Support Enabled
INFO - 2021-06-17 09:18:04 --> Utf8 Class Initialized
INFO - 2021-06-17 09:18:04 --> URI Class Initialized
INFO - 2021-06-17 09:18:04 --> Router Class Initialized
INFO - 2021-06-17 09:18:04 --> Output Class Initialized
INFO - 2021-06-17 09:18:04 --> Security Class Initialized
DEBUG - 2021-06-17 09:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 09:18:04 --> Input Class Initialized
INFO - 2021-06-17 09:18:04 --> Language Class Initialized
INFO - 2021-06-17 09:18:04 --> Language Class Initialized
INFO - 2021-06-17 09:18:04 --> Config Class Initialized
INFO - 2021-06-17 09:18:04 --> Loader Class Initialized
INFO - 2021-06-17 09:18:04 --> Helper loaded: url_helper
INFO - 2021-06-17 09:18:04 --> Helper loaded: file_helper
INFO - 2021-06-17 09:18:04 --> Helper loaded: form_helper
INFO - 2021-06-17 09:18:04 --> Helper loaded: my_helper
INFO - 2021-06-17 09:18:04 --> Database Driver Class Initialized
DEBUG - 2021-06-17 09:18:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 09:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 09:18:04 --> Controller Class Initialized
DEBUG - 2021-06-17 09:18:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 09:18:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 09:18:04 --> Final output sent to browser
DEBUG - 2021-06-17 09:18:04 --> Total execution time: 0.0398
INFO - 2021-06-17 09:18:06 --> Config Class Initialized
INFO - 2021-06-17 09:18:06 --> Hooks Class Initialized
DEBUG - 2021-06-17 09:18:06 --> UTF-8 Support Enabled
INFO - 2021-06-17 09:18:06 --> Utf8 Class Initialized
INFO - 2021-06-17 09:18:06 --> URI Class Initialized
INFO - 2021-06-17 09:18:06 --> Router Class Initialized
INFO - 2021-06-17 09:18:06 --> Output Class Initialized
INFO - 2021-06-17 09:18:06 --> Security Class Initialized
DEBUG - 2021-06-17 09:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 09:18:06 --> Input Class Initialized
INFO - 2021-06-17 09:18:06 --> Language Class Initialized
INFO - 2021-06-17 09:18:06 --> Language Class Initialized
INFO - 2021-06-17 09:18:06 --> Config Class Initialized
INFO - 2021-06-17 09:18:06 --> Loader Class Initialized
INFO - 2021-06-17 09:18:06 --> Helper loaded: url_helper
INFO - 2021-06-17 09:18:06 --> Helper loaded: file_helper
INFO - 2021-06-17 09:18:06 --> Helper loaded: form_helper
INFO - 2021-06-17 09:18:06 --> Helper loaded: my_helper
INFO - 2021-06-17 09:18:06 --> Database Driver Class Initialized
DEBUG - 2021-06-17 09:18:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 09:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 09:18:06 --> Controller Class Initialized
INFO - 2021-06-17 09:18:06 --> Final output sent to browser
DEBUG - 2021-06-17 09:18:06 --> Total execution time: 0.0472
INFO - 2021-06-17 09:18:25 --> Config Class Initialized
INFO - 2021-06-17 09:18:25 --> Hooks Class Initialized
DEBUG - 2021-06-17 09:18:25 --> UTF-8 Support Enabled
INFO - 2021-06-17 09:18:25 --> Utf8 Class Initialized
INFO - 2021-06-17 09:18:25 --> URI Class Initialized
INFO - 2021-06-17 09:18:25 --> Router Class Initialized
INFO - 2021-06-17 09:18:25 --> Output Class Initialized
INFO - 2021-06-17 09:18:25 --> Security Class Initialized
DEBUG - 2021-06-17 09:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 09:18:25 --> Input Class Initialized
INFO - 2021-06-17 09:18:25 --> Language Class Initialized
INFO - 2021-06-17 09:18:25 --> Language Class Initialized
INFO - 2021-06-17 09:18:25 --> Config Class Initialized
INFO - 2021-06-17 09:18:25 --> Loader Class Initialized
INFO - 2021-06-17 09:18:25 --> Helper loaded: url_helper
INFO - 2021-06-17 09:18:25 --> Helper loaded: file_helper
INFO - 2021-06-17 09:18:25 --> Helper loaded: form_helper
INFO - 2021-06-17 09:18:25 --> Helper loaded: my_helper
INFO - 2021-06-17 09:18:25 --> Database Driver Class Initialized
DEBUG - 2021-06-17 09:18:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 09:18:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 09:18:26 --> Controller Class Initialized
INFO - 2021-06-17 09:18:26 --> Final output sent to browser
DEBUG - 2021-06-17 09:18:26 --> Total execution time: 0.0481
INFO - 2021-06-17 09:18:38 --> Config Class Initialized
INFO - 2021-06-17 09:18:38 --> Hooks Class Initialized
DEBUG - 2021-06-17 09:18:38 --> UTF-8 Support Enabled
INFO - 2021-06-17 09:18:38 --> Utf8 Class Initialized
INFO - 2021-06-17 09:18:38 --> URI Class Initialized
INFO - 2021-06-17 09:18:38 --> Router Class Initialized
INFO - 2021-06-17 09:18:38 --> Output Class Initialized
INFO - 2021-06-17 09:18:38 --> Security Class Initialized
DEBUG - 2021-06-17 09:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 09:18:38 --> Input Class Initialized
INFO - 2021-06-17 09:18:38 --> Language Class Initialized
INFO - 2021-06-17 09:18:38 --> Language Class Initialized
INFO - 2021-06-17 09:18:38 --> Config Class Initialized
INFO - 2021-06-17 09:18:38 --> Loader Class Initialized
INFO - 2021-06-17 09:18:38 --> Helper loaded: url_helper
INFO - 2021-06-17 09:18:38 --> Helper loaded: file_helper
INFO - 2021-06-17 09:18:38 --> Helper loaded: form_helper
INFO - 2021-06-17 09:18:38 --> Helper loaded: my_helper
INFO - 2021-06-17 09:18:38 --> Database Driver Class Initialized
DEBUG - 2021-06-17 09:18:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 09:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 09:18:38 --> Controller Class Initialized
INFO - 2021-06-17 09:18:38 --> Final output sent to browser
DEBUG - 2021-06-17 09:18:38 --> Total execution time: 0.0404
INFO - 2021-06-17 09:18:38 --> Config Class Initialized
INFO - 2021-06-17 09:18:38 --> Hooks Class Initialized
DEBUG - 2021-06-17 09:18:38 --> UTF-8 Support Enabled
INFO - 2021-06-17 09:18:38 --> Utf8 Class Initialized
INFO - 2021-06-17 09:18:38 --> URI Class Initialized
INFO - 2021-06-17 09:18:38 --> Router Class Initialized
INFO - 2021-06-17 09:18:38 --> Output Class Initialized
INFO - 2021-06-17 09:18:38 --> Security Class Initialized
DEBUG - 2021-06-17 09:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 09:18:38 --> Input Class Initialized
INFO - 2021-06-17 09:18:38 --> Language Class Initialized
INFO - 2021-06-17 09:18:38 --> Language Class Initialized
INFO - 2021-06-17 09:18:38 --> Config Class Initialized
INFO - 2021-06-17 09:18:38 --> Loader Class Initialized
INFO - 2021-06-17 09:18:38 --> Helper loaded: url_helper
INFO - 2021-06-17 09:18:38 --> Helper loaded: file_helper
INFO - 2021-06-17 09:18:38 --> Helper loaded: form_helper
INFO - 2021-06-17 09:18:38 --> Helper loaded: my_helper
INFO - 2021-06-17 09:18:38 --> Database Driver Class Initialized
DEBUG - 2021-06-17 09:18:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 09:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 09:18:38 --> Controller Class Initialized
DEBUG - 2021-06-17 09:18:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 09:18:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 09:18:38 --> Final output sent to browser
DEBUG - 2021-06-17 09:18:38 --> Total execution time: 0.0524
INFO - 2021-06-17 09:18:42 --> Config Class Initialized
INFO - 2021-06-17 09:18:42 --> Hooks Class Initialized
DEBUG - 2021-06-17 09:18:42 --> UTF-8 Support Enabled
INFO - 2021-06-17 09:18:42 --> Utf8 Class Initialized
INFO - 2021-06-17 09:18:42 --> URI Class Initialized
INFO - 2021-06-17 09:18:42 --> Router Class Initialized
INFO - 2021-06-17 09:18:42 --> Output Class Initialized
INFO - 2021-06-17 09:18:42 --> Security Class Initialized
DEBUG - 2021-06-17 09:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 09:18:42 --> Input Class Initialized
INFO - 2021-06-17 09:18:42 --> Language Class Initialized
INFO - 2021-06-17 09:18:42 --> Language Class Initialized
INFO - 2021-06-17 09:18:42 --> Config Class Initialized
INFO - 2021-06-17 09:18:42 --> Loader Class Initialized
INFO - 2021-06-17 09:18:42 --> Helper loaded: url_helper
INFO - 2021-06-17 09:18:42 --> Helper loaded: file_helper
INFO - 2021-06-17 09:18:42 --> Helper loaded: form_helper
INFO - 2021-06-17 09:18:42 --> Helper loaded: my_helper
INFO - 2021-06-17 09:18:42 --> Database Driver Class Initialized
DEBUG - 2021-06-17 09:18:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 09:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 09:18:42 --> Controller Class Initialized
INFO - 2021-06-17 09:18:42 --> Final output sent to browser
DEBUG - 2021-06-17 09:18:42 --> Total execution time: 0.0474
INFO - 2021-06-17 09:19:21 --> Config Class Initialized
INFO - 2021-06-17 09:19:21 --> Hooks Class Initialized
DEBUG - 2021-06-17 09:19:21 --> UTF-8 Support Enabled
INFO - 2021-06-17 09:19:21 --> Utf8 Class Initialized
INFO - 2021-06-17 09:19:21 --> URI Class Initialized
INFO - 2021-06-17 09:19:21 --> Router Class Initialized
INFO - 2021-06-17 09:19:21 --> Output Class Initialized
INFO - 2021-06-17 09:19:21 --> Security Class Initialized
DEBUG - 2021-06-17 09:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 09:19:21 --> Input Class Initialized
INFO - 2021-06-17 09:19:21 --> Language Class Initialized
INFO - 2021-06-17 09:19:21 --> Language Class Initialized
INFO - 2021-06-17 09:19:21 --> Config Class Initialized
INFO - 2021-06-17 09:19:21 --> Loader Class Initialized
INFO - 2021-06-17 09:19:21 --> Helper loaded: url_helper
INFO - 2021-06-17 09:19:21 --> Helper loaded: file_helper
INFO - 2021-06-17 09:19:21 --> Helper loaded: form_helper
INFO - 2021-06-17 09:19:21 --> Helper loaded: my_helper
INFO - 2021-06-17 09:19:21 --> Database Driver Class Initialized
DEBUG - 2021-06-17 09:19:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 09:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 09:19:21 --> Controller Class Initialized
INFO - 2021-06-17 09:19:21 --> Final output sent to browser
DEBUG - 2021-06-17 09:19:21 --> Total execution time: 0.5763
INFO - 2021-06-17 09:19:22 --> Config Class Initialized
INFO - 2021-06-17 09:19:22 --> Hooks Class Initialized
DEBUG - 2021-06-17 09:19:22 --> UTF-8 Support Enabled
INFO - 2021-06-17 09:19:22 --> Utf8 Class Initialized
INFO - 2021-06-17 09:19:22 --> URI Class Initialized
INFO - 2021-06-17 09:19:22 --> Router Class Initialized
INFO - 2021-06-17 09:19:22 --> Output Class Initialized
INFO - 2021-06-17 09:19:22 --> Security Class Initialized
DEBUG - 2021-06-17 09:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 09:19:22 --> Input Class Initialized
INFO - 2021-06-17 09:19:22 --> Language Class Initialized
INFO - 2021-06-17 09:19:22 --> Language Class Initialized
INFO - 2021-06-17 09:19:22 --> Config Class Initialized
INFO - 2021-06-17 09:19:22 --> Loader Class Initialized
INFO - 2021-06-17 09:19:22 --> Helper loaded: url_helper
INFO - 2021-06-17 09:19:22 --> Helper loaded: file_helper
INFO - 2021-06-17 09:19:22 --> Helper loaded: form_helper
INFO - 2021-06-17 09:19:22 --> Helper loaded: my_helper
INFO - 2021-06-17 09:19:22 --> Database Driver Class Initialized
DEBUG - 2021-06-17 09:19:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 09:19:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 09:19:22 --> Controller Class Initialized
DEBUG - 2021-06-17 09:19:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 09:19:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 09:19:22 --> Final output sent to browser
DEBUG - 2021-06-17 09:19:22 --> Total execution time: 0.1238
INFO - 2021-06-17 09:19:42 --> Config Class Initialized
INFO - 2021-06-17 09:19:42 --> Hooks Class Initialized
DEBUG - 2021-06-17 09:19:42 --> UTF-8 Support Enabled
INFO - 2021-06-17 09:19:42 --> Utf8 Class Initialized
INFO - 2021-06-17 09:19:42 --> URI Class Initialized
INFO - 2021-06-17 09:19:42 --> Router Class Initialized
INFO - 2021-06-17 09:19:42 --> Output Class Initialized
INFO - 2021-06-17 09:19:42 --> Security Class Initialized
DEBUG - 2021-06-17 09:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 09:19:42 --> Input Class Initialized
INFO - 2021-06-17 09:19:42 --> Language Class Initialized
INFO - 2021-06-17 09:19:42 --> Language Class Initialized
INFO - 2021-06-17 09:19:42 --> Config Class Initialized
INFO - 2021-06-17 09:19:42 --> Loader Class Initialized
INFO - 2021-06-17 09:19:42 --> Helper loaded: url_helper
INFO - 2021-06-17 09:19:42 --> Helper loaded: file_helper
INFO - 2021-06-17 09:19:42 --> Helper loaded: form_helper
INFO - 2021-06-17 09:19:42 --> Helper loaded: my_helper
INFO - 2021-06-17 09:19:42 --> Database Driver Class Initialized
DEBUG - 2021-06-17 09:19:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 09:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 09:19:42 --> Controller Class Initialized
DEBUG - 2021-06-17 09:19:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-17 09:19:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 09:19:42 --> Final output sent to browser
DEBUG - 2021-06-17 09:19:42 --> Total execution time: 0.0841
INFO - 2021-06-17 09:19:43 --> Config Class Initialized
INFO - 2021-06-17 09:19:43 --> Hooks Class Initialized
DEBUG - 2021-06-17 09:19:43 --> UTF-8 Support Enabled
INFO - 2021-06-17 09:19:43 --> Utf8 Class Initialized
INFO - 2021-06-17 09:19:43 --> URI Class Initialized
INFO - 2021-06-17 09:19:43 --> Router Class Initialized
INFO - 2021-06-17 09:19:43 --> Output Class Initialized
INFO - 2021-06-17 09:19:43 --> Security Class Initialized
DEBUG - 2021-06-17 09:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 09:19:43 --> Input Class Initialized
INFO - 2021-06-17 09:19:43 --> Language Class Initialized
INFO - 2021-06-17 09:19:43 --> Language Class Initialized
INFO - 2021-06-17 09:19:43 --> Config Class Initialized
INFO - 2021-06-17 09:19:43 --> Loader Class Initialized
INFO - 2021-06-17 09:19:43 --> Helper loaded: url_helper
INFO - 2021-06-17 09:19:43 --> Helper loaded: file_helper
INFO - 2021-06-17 09:19:43 --> Helper loaded: form_helper
INFO - 2021-06-17 09:19:43 --> Helper loaded: my_helper
INFO - 2021-06-17 09:19:43 --> Database Driver Class Initialized
DEBUG - 2021-06-17 09:19:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 09:19:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 09:19:43 --> Controller Class Initialized
DEBUG - 2021-06-17 09:19:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-17 09:19:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 09:19:43 --> Final output sent to browser
DEBUG - 2021-06-17 09:19:43 --> Total execution time: 0.0854
INFO - 2021-06-17 09:19:44 --> Config Class Initialized
INFO - 2021-06-17 09:19:44 --> Hooks Class Initialized
DEBUG - 2021-06-17 09:19:44 --> UTF-8 Support Enabled
INFO - 2021-06-17 09:19:44 --> Utf8 Class Initialized
INFO - 2021-06-17 09:19:44 --> URI Class Initialized
INFO - 2021-06-17 09:19:44 --> Router Class Initialized
INFO - 2021-06-17 09:19:44 --> Output Class Initialized
INFO - 2021-06-17 09:19:44 --> Security Class Initialized
DEBUG - 2021-06-17 09:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 09:19:44 --> Input Class Initialized
INFO - 2021-06-17 09:19:44 --> Language Class Initialized
INFO - 2021-06-17 09:19:44 --> Language Class Initialized
INFO - 2021-06-17 09:19:44 --> Config Class Initialized
INFO - 2021-06-17 09:19:44 --> Loader Class Initialized
INFO - 2021-06-17 09:19:44 --> Helper loaded: url_helper
INFO - 2021-06-17 09:19:44 --> Helper loaded: file_helper
INFO - 2021-06-17 09:19:44 --> Helper loaded: form_helper
INFO - 2021-06-17 09:19:44 --> Helper loaded: my_helper
INFO - 2021-06-17 09:19:44 --> Database Driver Class Initialized
DEBUG - 2021-06-17 09:19:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 09:19:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 09:19:44 --> Controller Class Initialized
INFO - 2021-06-17 09:19:46 --> Config Class Initialized
INFO - 2021-06-17 09:19:46 --> Hooks Class Initialized
DEBUG - 2021-06-17 09:19:46 --> UTF-8 Support Enabled
INFO - 2021-06-17 09:19:46 --> Utf8 Class Initialized
INFO - 2021-06-17 09:19:46 --> URI Class Initialized
INFO - 2021-06-17 09:19:46 --> Router Class Initialized
INFO - 2021-06-17 09:19:46 --> Output Class Initialized
INFO - 2021-06-17 09:19:46 --> Security Class Initialized
DEBUG - 2021-06-17 09:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 09:19:46 --> Input Class Initialized
INFO - 2021-06-17 09:19:46 --> Language Class Initialized
INFO - 2021-06-17 09:19:46 --> Language Class Initialized
INFO - 2021-06-17 09:19:46 --> Config Class Initialized
INFO - 2021-06-17 09:19:46 --> Loader Class Initialized
INFO - 2021-06-17 09:19:46 --> Helper loaded: url_helper
INFO - 2021-06-17 09:19:46 --> Helper loaded: file_helper
INFO - 2021-06-17 09:19:46 --> Helper loaded: form_helper
INFO - 2021-06-17 09:19:46 --> Helper loaded: my_helper
INFO - 2021-06-17 09:19:46 --> Database Driver Class Initialized
DEBUG - 2021-06-17 09:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 09:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 09:19:46 --> Controller Class Initialized
INFO - 2021-06-17 09:19:46 --> Final output sent to browser
DEBUG - 2021-06-17 09:19:46 --> Total execution time: 0.0845
INFO - 2021-06-17 09:19:47 --> Config Class Initialized
INFO - 2021-06-17 09:19:47 --> Hooks Class Initialized
DEBUG - 2021-06-17 09:19:47 --> UTF-8 Support Enabled
INFO - 2021-06-17 09:19:47 --> Utf8 Class Initialized
INFO - 2021-06-17 09:19:47 --> URI Class Initialized
INFO - 2021-06-17 09:19:47 --> Router Class Initialized
INFO - 2021-06-17 09:19:47 --> Output Class Initialized
INFO - 2021-06-17 09:19:47 --> Security Class Initialized
DEBUG - 2021-06-17 09:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 09:19:47 --> Input Class Initialized
INFO - 2021-06-17 09:19:47 --> Language Class Initialized
INFO - 2021-06-17 09:19:47 --> Language Class Initialized
INFO - 2021-06-17 09:19:47 --> Config Class Initialized
INFO - 2021-06-17 09:19:47 --> Loader Class Initialized
INFO - 2021-06-17 09:19:47 --> Helper loaded: url_helper
INFO - 2021-06-17 09:19:47 --> Helper loaded: file_helper
INFO - 2021-06-17 09:19:47 --> Helper loaded: form_helper
INFO - 2021-06-17 09:19:47 --> Helper loaded: my_helper
INFO - 2021-06-17 09:19:47 --> Database Driver Class Initialized
DEBUG - 2021-06-17 09:19:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 09:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 09:19:47 --> Controller Class Initialized
INFO - 2021-06-17 09:19:47 --> Final output sent to browser
DEBUG - 2021-06-17 09:19:47 --> Total execution time: 0.0467
INFO - 2021-06-17 09:19:49 --> Config Class Initialized
INFO - 2021-06-17 09:19:49 --> Hooks Class Initialized
DEBUG - 2021-06-17 09:19:49 --> UTF-8 Support Enabled
INFO - 2021-06-17 09:19:49 --> Utf8 Class Initialized
INFO - 2021-06-17 09:19:49 --> URI Class Initialized
INFO - 2021-06-17 09:19:49 --> Router Class Initialized
INFO - 2021-06-17 09:19:49 --> Output Class Initialized
INFO - 2021-06-17 09:19:49 --> Security Class Initialized
DEBUG - 2021-06-17 09:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 09:19:49 --> Input Class Initialized
INFO - 2021-06-17 09:19:49 --> Language Class Initialized
INFO - 2021-06-17 09:19:49 --> Language Class Initialized
INFO - 2021-06-17 09:19:49 --> Config Class Initialized
INFO - 2021-06-17 09:19:49 --> Loader Class Initialized
INFO - 2021-06-17 09:19:49 --> Helper loaded: url_helper
INFO - 2021-06-17 09:19:49 --> Helper loaded: file_helper
INFO - 2021-06-17 09:19:49 --> Helper loaded: form_helper
INFO - 2021-06-17 09:19:49 --> Helper loaded: my_helper
INFO - 2021-06-17 09:19:49 --> Database Driver Class Initialized
DEBUG - 2021-06-17 09:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 09:19:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 09:19:49 --> Controller Class Initialized
DEBUG - 2021-06-17 09:19:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-17 09:19:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 09:19:49 --> Final output sent to browser
DEBUG - 2021-06-17 09:19:49 --> Total execution time: 0.0490
INFO - 2021-06-17 09:19:50 --> Config Class Initialized
INFO - 2021-06-17 09:19:50 --> Hooks Class Initialized
DEBUG - 2021-06-17 09:19:50 --> UTF-8 Support Enabled
INFO - 2021-06-17 09:19:50 --> Utf8 Class Initialized
INFO - 2021-06-17 09:19:50 --> URI Class Initialized
INFO - 2021-06-17 09:19:50 --> Router Class Initialized
INFO - 2021-06-17 09:19:50 --> Output Class Initialized
INFO - 2021-06-17 09:19:50 --> Security Class Initialized
DEBUG - 2021-06-17 09:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 09:19:50 --> Input Class Initialized
INFO - 2021-06-17 09:19:50 --> Language Class Initialized
INFO - 2021-06-17 09:19:50 --> Language Class Initialized
INFO - 2021-06-17 09:19:50 --> Config Class Initialized
INFO - 2021-06-17 09:19:50 --> Loader Class Initialized
INFO - 2021-06-17 09:19:50 --> Helper loaded: url_helper
INFO - 2021-06-17 09:19:50 --> Helper loaded: file_helper
INFO - 2021-06-17 09:19:50 --> Helper loaded: form_helper
INFO - 2021-06-17 09:19:50 --> Helper loaded: my_helper
INFO - 2021-06-17 09:19:50 --> Database Driver Class Initialized
DEBUG - 2021-06-17 09:19:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 09:19:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 09:19:50 --> Controller Class Initialized
DEBUG - 2021-06-17 09:19:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-17 09:19:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 09:19:50 --> Final output sent to browser
DEBUG - 2021-06-17 09:19:50 --> Total execution time: 0.0387
INFO - 2021-06-17 09:19:50 --> Config Class Initialized
INFO - 2021-06-17 09:19:50 --> Hooks Class Initialized
DEBUG - 2021-06-17 09:19:50 --> UTF-8 Support Enabled
INFO - 2021-06-17 09:19:50 --> Utf8 Class Initialized
INFO - 2021-06-17 09:19:50 --> URI Class Initialized
INFO - 2021-06-17 09:19:50 --> Router Class Initialized
INFO - 2021-06-17 09:19:50 --> Output Class Initialized
INFO - 2021-06-17 09:19:50 --> Security Class Initialized
DEBUG - 2021-06-17 09:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 09:19:50 --> Input Class Initialized
INFO - 2021-06-17 09:19:50 --> Language Class Initialized
INFO - 2021-06-17 09:19:50 --> Language Class Initialized
INFO - 2021-06-17 09:19:50 --> Config Class Initialized
INFO - 2021-06-17 09:19:50 --> Loader Class Initialized
INFO - 2021-06-17 09:19:50 --> Helper loaded: url_helper
INFO - 2021-06-17 09:19:50 --> Helper loaded: file_helper
INFO - 2021-06-17 09:19:50 --> Helper loaded: form_helper
INFO - 2021-06-17 09:19:50 --> Helper loaded: my_helper
INFO - 2021-06-17 09:19:50 --> Database Driver Class Initialized
DEBUG - 2021-06-17 09:19:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 09:19:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 09:19:50 --> Controller Class Initialized
INFO - 2021-06-17 09:19:51 --> Config Class Initialized
INFO - 2021-06-17 09:19:51 --> Hooks Class Initialized
DEBUG - 2021-06-17 09:19:51 --> UTF-8 Support Enabled
INFO - 2021-06-17 09:19:51 --> Utf8 Class Initialized
INFO - 2021-06-17 09:19:51 --> URI Class Initialized
INFO - 2021-06-17 09:19:51 --> Router Class Initialized
INFO - 2021-06-17 09:19:51 --> Output Class Initialized
INFO - 2021-06-17 09:19:51 --> Security Class Initialized
DEBUG - 2021-06-17 09:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 09:19:51 --> Input Class Initialized
INFO - 2021-06-17 09:19:51 --> Language Class Initialized
INFO - 2021-06-17 09:19:51 --> Language Class Initialized
INFO - 2021-06-17 09:19:51 --> Config Class Initialized
INFO - 2021-06-17 09:19:51 --> Loader Class Initialized
INFO - 2021-06-17 09:19:51 --> Helper loaded: url_helper
INFO - 2021-06-17 09:19:51 --> Helper loaded: file_helper
INFO - 2021-06-17 09:19:51 --> Helper loaded: form_helper
INFO - 2021-06-17 09:19:51 --> Helper loaded: my_helper
INFO - 2021-06-17 09:19:51 --> Database Driver Class Initialized
DEBUG - 2021-06-17 09:19:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 09:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 09:19:51 --> Controller Class Initialized
INFO - 2021-06-17 09:19:51 --> Final output sent to browser
DEBUG - 2021-06-17 09:19:51 --> Total execution time: 0.0500
INFO - 2021-06-17 09:19:52 --> Config Class Initialized
INFO - 2021-06-17 09:19:52 --> Hooks Class Initialized
DEBUG - 2021-06-17 09:19:52 --> UTF-8 Support Enabled
INFO - 2021-06-17 09:19:52 --> Utf8 Class Initialized
INFO - 2021-06-17 09:19:52 --> URI Class Initialized
INFO - 2021-06-17 09:19:52 --> Router Class Initialized
INFO - 2021-06-17 09:19:52 --> Output Class Initialized
INFO - 2021-06-17 09:19:52 --> Security Class Initialized
DEBUG - 2021-06-17 09:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 09:19:52 --> Input Class Initialized
INFO - 2021-06-17 09:19:52 --> Language Class Initialized
INFO - 2021-06-17 09:19:52 --> Language Class Initialized
INFO - 2021-06-17 09:19:52 --> Config Class Initialized
INFO - 2021-06-17 09:19:52 --> Loader Class Initialized
INFO - 2021-06-17 09:19:52 --> Helper loaded: url_helper
INFO - 2021-06-17 09:19:52 --> Helper loaded: file_helper
INFO - 2021-06-17 09:19:52 --> Helper loaded: form_helper
INFO - 2021-06-17 09:19:52 --> Helper loaded: my_helper
INFO - 2021-06-17 09:19:52 --> Database Driver Class Initialized
DEBUG - 2021-06-17 09:19:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 09:19:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 09:19:52 --> Controller Class Initialized
DEBUG - 2021-06-17 09:19:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-17 09:19:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 09:19:52 --> Final output sent to browser
DEBUG - 2021-06-17 09:19:52 --> Total execution time: 0.0384
INFO - 2021-06-17 09:20:16 --> Config Class Initialized
INFO - 2021-06-17 09:20:16 --> Hooks Class Initialized
DEBUG - 2021-06-17 09:20:16 --> UTF-8 Support Enabled
INFO - 2021-06-17 09:20:16 --> Utf8 Class Initialized
INFO - 2021-06-17 09:20:16 --> URI Class Initialized
INFO - 2021-06-17 09:20:16 --> Router Class Initialized
INFO - 2021-06-17 09:20:16 --> Output Class Initialized
INFO - 2021-06-17 09:20:16 --> Security Class Initialized
DEBUG - 2021-06-17 09:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 09:20:16 --> Input Class Initialized
INFO - 2021-06-17 09:20:16 --> Language Class Initialized
INFO - 2021-06-17 09:20:16 --> Language Class Initialized
INFO - 2021-06-17 09:20:16 --> Config Class Initialized
INFO - 2021-06-17 09:20:16 --> Loader Class Initialized
INFO - 2021-06-17 09:20:16 --> Helper loaded: url_helper
INFO - 2021-06-17 09:20:16 --> Helper loaded: file_helper
INFO - 2021-06-17 09:20:16 --> Helper loaded: form_helper
INFO - 2021-06-17 09:20:16 --> Helper loaded: my_helper
INFO - 2021-06-17 09:20:16 --> Database Driver Class Initialized
DEBUG - 2021-06-17 09:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 09:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 09:20:16 --> Controller Class Initialized
DEBUG - 2021-06-17 09:20:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-17 09:20:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 09:20:16 --> Final output sent to browser
DEBUG - 2021-06-17 09:20:16 --> Total execution time: 0.0408
INFO - 2021-06-17 09:20:17 --> Config Class Initialized
INFO - 2021-06-17 09:20:17 --> Hooks Class Initialized
DEBUG - 2021-06-17 09:20:17 --> UTF-8 Support Enabled
INFO - 2021-06-17 09:20:17 --> Utf8 Class Initialized
INFO - 2021-06-17 09:20:17 --> URI Class Initialized
INFO - 2021-06-17 09:20:17 --> Router Class Initialized
INFO - 2021-06-17 09:20:17 --> Output Class Initialized
INFO - 2021-06-17 09:20:17 --> Security Class Initialized
DEBUG - 2021-06-17 09:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 09:20:17 --> Input Class Initialized
INFO - 2021-06-17 09:20:17 --> Language Class Initialized
INFO - 2021-06-17 09:20:17 --> Language Class Initialized
INFO - 2021-06-17 09:20:17 --> Config Class Initialized
INFO - 2021-06-17 09:20:17 --> Loader Class Initialized
INFO - 2021-06-17 09:20:17 --> Helper loaded: url_helper
INFO - 2021-06-17 09:20:17 --> Helper loaded: file_helper
INFO - 2021-06-17 09:20:17 --> Helper loaded: form_helper
INFO - 2021-06-17 09:20:17 --> Helper loaded: my_helper
INFO - 2021-06-17 09:20:17 --> Database Driver Class Initialized
DEBUG - 2021-06-17 09:20:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 09:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 09:20:17 --> Controller Class Initialized
INFO - 2021-06-17 09:20:18 --> Config Class Initialized
INFO - 2021-06-17 09:20:18 --> Hooks Class Initialized
DEBUG - 2021-06-17 09:20:18 --> UTF-8 Support Enabled
INFO - 2021-06-17 09:20:18 --> Utf8 Class Initialized
INFO - 2021-06-17 09:20:18 --> URI Class Initialized
INFO - 2021-06-17 09:20:18 --> Router Class Initialized
INFO - 2021-06-17 09:20:18 --> Output Class Initialized
INFO - 2021-06-17 09:20:18 --> Security Class Initialized
DEBUG - 2021-06-17 09:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 09:20:18 --> Input Class Initialized
INFO - 2021-06-17 09:20:18 --> Language Class Initialized
INFO - 2021-06-17 09:20:18 --> Language Class Initialized
INFO - 2021-06-17 09:20:18 --> Config Class Initialized
INFO - 2021-06-17 09:20:18 --> Loader Class Initialized
INFO - 2021-06-17 09:20:18 --> Helper loaded: url_helper
INFO - 2021-06-17 09:20:18 --> Helper loaded: file_helper
INFO - 2021-06-17 09:20:18 --> Helper loaded: form_helper
INFO - 2021-06-17 09:20:18 --> Helper loaded: my_helper
INFO - 2021-06-17 09:20:18 --> Database Driver Class Initialized
DEBUG - 2021-06-17 09:20:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 09:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 09:20:18 --> Controller Class Initialized
DEBUG - 2021-06-17 09:20:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 09:20:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 09:20:18 --> Final output sent to browser
DEBUG - 2021-06-17 09:20:18 --> Total execution time: 0.0399
INFO - 2021-06-17 09:20:20 --> Config Class Initialized
INFO - 2021-06-17 09:20:20 --> Hooks Class Initialized
DEBUG - 2021-06-17 09:20:20 --> UTF-8 Support Enabled
INFO - 2021-06-17 09:20:20 --> Utf8 Class Initialized
INFO - 2021-06-17 09:20:20 --> URI Class Initialized
INFO - 2021-06-17 09:20:20 --> Router Class Initialized
INFO - 2021-06-17 09:20:20 --> Output Class Initialized
INFO - 2021-06-17 09:20:20 --> Security Class Initialized
DEBUG - 2021-06-17 09:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 09:20:20 --> Input Class Initialized
INFO - 2021-06-17 09:20:20 --> Language Class Initialized
INFO - 2021-06-17 09:20:20 --> Language Class Initialized
INFO - 2021-06-17 09:20:20 --> Config Class Initialized
INFO - 2021-06-17 09:20:20 --> Loader Class Initialized
INFO - 2021-06-17 09:20:20 --> Helper loaded: url_helper
INFO - 2021-06-17 09:20:20 --> Helper loaded: file_helper
INFO - 2021-06-17 09:20:20 --> Helper loaded: form_helper
INFO - 2021-06-17 09:20:20 --> Helper loaded: my_helper
INFO - 2021-06-17 09:20:20 --> Database Driver Class Initialized
DEBUG - 2021-06-17 09:20:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 09:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 09:20:20 --> Controller Class Initialized
INFO - 2021-06-17 09:20:22 --> Config Class Initialized
INFO - 2021-06-17 09:20:22 --> Hooks Class Initialized
DEBUG - 2021-06-17 09:20:22 --> UTF-8 Support Enabled
INFO - 2021-06-17 09:20:22 --> Utf8 Class Initialized
INFO - 2021-06-17 09:20:22 --> URI Class Initialized
INFO - 2021-06-17 09:20:22 --> Router Class Initialized
INFO - 2021-06-17 09:20:22 --> Output Class Initialized
INFO - 2021-06-17 09:20:22 --> Security Class Initialized
DEBUG - 2021-06-17 09:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 09:20:22 --> Input Class Initialized
INFO - 2021-06-17 09:20:22 --> Language Class Initialized
INFO - 2021-06-17 09:20:22 --> Language Class Initialized
INFO - 2021-06-17 09:20:22 --> Config Class Initialized
INFO - 2021-06-17 09:20:22 --> Loader Class Initialized
INFO - 2021-06-17 09:20:22 --> Helper loaded: url_helper
INFO - 2021-06-17 09:20:22 --> Helper loaded: file_helper
INFO - 2021-06-17 09:20:22 --> Helper loaded: form_helper
INFO - 2021-06-17 09:20:22 --> Helper loaded: my_helper
INFO - 2021-06-17 09:20:22 --> Database Driver Class Initialized
DEBUG - 2021-06-17 09:20:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 09:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 09:20:22 --> Controller Class Initialized
INFO - 2021-06-17 09:21:02 --> Config Class Initialized
INFO - 2021-06-17 09:21:02 --> Hooks Class Initialized
DEBUG - 2021-06-17 09:21:02 --> UTF-8 Support Enabled
INFO - 2021-06-17 09:21:02 --> Utf8 Class Initialized
INFO - 2021-06-17 09:21:02 --> URI Class Initialized
INFO - 2021-06-17 09:21:02 --> Router Class Initialized
INFO - 2021-06-17 09:21:02 --> Output Class Initialized
INFO - 2021-06-17 09:21:02 --> Security Class Initialized
DEBUG - 2021-06-17 09:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 09:21:02 --> Input Class Initialized
INFO - 2021-06-17 09:21:02 --> Language Class Initialized
INFO - 2021-06-17 09:21:02 --> Language Class Initialized
INFO - 2021-06-17 09:21:02 --> Config Class Initialized
INFO - 2021-06-17 09:21:02 --> Loader Class Initialized
INFO - 2021-06-17 09:21:02 --> Helper loaded: url_helper
INFO - 2021-06-17 09:21:02 --> Helper loaded: file_helper
INFO - 2021-06-17 09:21:02 --> Helper loaded: form_helper
INFO - 2021-06-17 09:21:02 --> Helper loaded: my_helper
INFO - 2021-06-17 09:21:02 --> Database Driver Class Initialized
DEBUG - 2021-06-17 09:21:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 09:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 09:21:02 --> Controller Class Initialized
DEBUG - 2021-06-17 09:21:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-17 09:21:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 09:21:02 --> Final output sent to browser
DEBUG - 2021-06-17 09:21:02 --> Total execution time: 0.0449
INFO - 2021-06-17 09:21:02 --> Config Class Initialized
INFO - 2021-06-17 09:21:02 --> Hooks Class Initialized
DEBUG - 2021-06-17 09:21:02 --> UTF-8 Support Enabled
INFO - 2021-06-17 09:21:02 --> Utf8 Class Initialized
INFO - 2021-06-17 09:21:02 --> URI Class Initialized
INFO - 2021-06-17 09:21:02 --> Router Class Initialized
INFO - 2021-06-17 09:21:02 --> Output Class Initialized
INFO - 2021-06-17 09:21:02 --> Security Class Initialized
DEBUG - 2021-06-17 09:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 09:21:02 --> Input Class Initialized
INFO - 2021-06-17 09:21:02 --> Language Class Initialized
INFO - 2021-06-17 09:21:02 --> Language Class Initialized
INFO - 2021-06-17 09:21:02 --> Config Class Initialized
INFO - 2021-06-17 09:21:02 --> Loader Class Initialized
INFO - 2021-06-17 09:21:02 --> Helper loaded: url_helper
INFO - 2021-06-17 09:21:02 --> Helper loaded: file_helper
INFO - 2021-06-17 09:21:02 --> Helper loaded: form_helper
INFO - 2021-06-17 09:21:02 --> Helper loaded: my_helper
INFO - 2021-06-17 09:21:02 --> Database Driver Class Initialized
DEBUG - 2021-06-17 09:21:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 09:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 09:21:02 --> Controller Class Initialized
INFO - 2021-06-17 09:21:04 --> Config Class Initialized
INFO - 2021-06-17 09:21:04 --> Hooks Class Initialized
DEBUG - 2021-06-17 09:21:04 --> UTF-8 Support Enabled
INFO - 2021-06-17 09:21:04 --> Utf8 Class Initialized
INFO - 2021-06-17 09:21:04 --> URI Class Initialized
INFO - 2021-06-17 09:21:04 --> Router Class Initialized
INFO - 2021-06-17 09:21:04 --> Output Class Initialized
INFO - 2021-06-17 09:21:04 --> Security Class Initialized
DEBUG - 2021-06-17 09:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 09:21:04 --> Input Class Initialized
INFO - 2021-06-17 09:21:04 --> Language Class Initialized
INFO - 2021-06-17 09:21:04 --> Language Class Initialized
INFO - 2021-06-17 09:21:04 --> Config Class Initialized
INFO - 2021-06-17 09:21:04 --> Loader Class Initialized
INFO - 2021-06-17 09:21:04 --> Helper loaded: url_helper
INFO - 2021-06-17 09:21:04 --> Helper loaded: file_helper
INFO - 2021-06-17 09:21:04 --> Helper loaded: form_helper
INFO - 2021-06-17 09:21:04 --> Helper loaded: my_helper
INFO - 2021-06-17 09:21:04 --> Database Driver Class Initialized
DEBUG - 2021-06-17 09:21:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 09:21:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 09:21:04 --> Controller Class Initialized
DEBUG - 2021-06-17 09:21:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-17 09:21:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 09:21:04 --> Final output sent to browser
DEBUG - 2021-06-17 09:21:04 --> Total execution time: 0.0441
INFO - 2021-06-17 09:21:07 --> Config Class Initialized
INFO - 2021-06-17 09:21:07 --> Hooks Class Initialized
DEBUG - 2021-06-17 09:21:07 --> UTF-8 Support Enabled
INFO - 2021-06-17 09:21:07 --> Utf8 Class Initialized
INFO - 2021-06-17 09:21:07 --> URI Class Initialized
INFO - 2021-06-17 09:21:07 --> Router Class Initialized
INFO - 2021-06-17 09:21:07 --> Output Class Initialized
INFO - 2021-06-17 09:21:07 --> Security Class Initialized
DEBUG - 2021-06-17 09:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 09:21:07 --> Input Class Initialized
INFO - 2021-06-17 09:21:07 --> Language Class Initialized
INFO - 2021-06-17 09:21:07 --> Language Class Initialized
INFO - 2021-06-17 09:21:07 --> Config Class Initialized
INFO - 2021-06-17 09:21:07 --> Loader Class Initialized
INFO - 2021-06-17 09:21:07 --> Helper loaded: url_helper
INFO - 2021-06-17 09:21:07 --> Helper loaded: file_helper
INFO - 2021-06-17 09:21:07 --> Helper loaded: form_helper
INFO - 2021-06-17 09:21:07 --> Helper loaded: my_helper
INFO - 2021-06-17 09:21:07 --> Database Driver Class Initialized
DEBUG - 2021-06-17 09:21:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 09:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 09:21:07 --> Controller Class Initialized
INFO - 2021-06-17 09:21:09 --> Config Class Initialized
INFO - 2021-06-17 09:21:09 --> Hooks Class Initialized
DEBUG - 2021-06-17 09:21:09 --> UTF-8 Support Enabled
INFO - 2021-06-17 09:21:09 --> Utf8 Class Initialized
INFO - 2021-06-17 09:21:09 --> URI Class Initialized
INFO - 2021-06-17 09:21:09 --> Router Class Initialized
INFO - 2021-06-17 09:21:09 --> Output Class Initialized
INFO - 2021-06-17 09:21:09 --> Security Class Initialized
DEBUG - 2021-06-17 09:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 09:21:09 --> Input Class Initialized
INFO - 2021-06-17 09:21:09 --> Language Class Initialized
INFO - 2021-06-17 09:21:09 --> Language Class Initialized
INFO - 2021-06-17 09:21:09 --> Config Class Initialized
INFO - 2021-06-17 09:21:09 --> Loader Class Initialized
INFO - 2021-06-17 09:21:09 --> Helper loaded: url_helper
INFO - 2021-06-17 09:21:09 --> Helper loaded: file_helper
INFO - 2021-06-17 09:21:09 --> Helper loaded: form_helper
INFO - 2021-06-17 09:21:09 --> Helper loaded: my_helper
INFO - 2021-06-17 09:21:09 --> Database Driver Class Initialized
DEBUG - 2021-06-17 09:21:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 09:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 09:21:09 --> Controller Class Initialized
INFO - 2021-06-17 09:21:10 --> Config Class Initialized
INFO - 2021-06-17 09:21:10 --> Hooks Class Initialized
DEBUG - 2021-06-17 09:21:10 --> UTF-8 Support Enabled
INFO - 2021-06-17 09:21:10 --> Utf8 Class Initialized
INFO - 2021-06-17 09:21:10 --> URI Class Initialized
INFO - 2021-06-17 09:21:10 --> Router Class Initialized
INFO - 2021-06-17 09:21:10 --> Output Class Initialized
INFO - 2021-06-17 09:21:10 --> Security Class Initialized
DEBUG - 2021-06-17 09:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 09:21:10 --> Input Class Initialized
INFO - 2021-06-17 09:21:10 --> Language Class Initialized
INFO - 2021-06-17 09:21:10 --> Language Class Initialized
INFO - 2021-06-17 09:21:10 --> Config Class Initialized
INFO - 2021-06-17 09:21:10 --> Loader Class Initialized
INFO - 2021-06-17 09:21:10 --> Helper loaded: url_helper
INFO - 2021-06-17 09:21:10 --> Helper loaded: file_helper
INFO - 2021-06-17 09:21:10 --> Helper loaded: form_helper
INFO - 2021-06-17 09:21:10 --> Helper loaded: my_helper
INFO - 2021-06-17 09:21:10 --> Database Driver Class Initialized
DEBUG - 2021-06-17 09:21:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 09:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 09:21:10 --> Controller Class Initialized
INFO - 2021-06-17 09:21:10 --> Final output sent to browser
DEBUG - 2021-06-17 09:21:10 --> Total execution time: 0.0449
INFO - 2021-06-17 09:21:14 --> Config Class Initialized
INFO - 2021-06-17 09:21:14 --> Hooks Class Initialized
DEBUG - 2021-06-17 09:21:14 --> UTF-8 Support Enabled
INFO - 2021-06-17 09:21:14 --> Utf8 Class Initialized
INFO - 2021-06-17 09:21:14 --> URI Class Initialized
INFO - 2021-06-17 09:21:14 --> Router Class Initialized
INFO - 2021-06-17 09:21:14 --> Output Class Initialized
INFO - 2021-06-17 09:21:14 --> Security Class Initialized
DEBUG - 2021-06-17 09:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 09:21:14 --> Input Class Initialized
INFO - 2021-06-17 09:21:14 --> Language Class Initialized
INFO - 2021-06-17 09:21:14 --> Language Class Initialized
INFO - 2021-06-17 09:21:14 --> Config Class Initialized
INFO - 2021-06-17 09:21:14 --> Loader Class Initialized
INFO - 2021-06-17 09:21:14 --> Helper loaded: url_helper
INFO - 2021-06-17 09:21:14 --> Helper loaded: file_helper
INFO - 2021-06-17 09:21:14 --> Helper loaded: form_helper
INFO - 2021-06-17 09:21:14 --> Helper loaded: my_helper
INFO - 2021-06-17 09:21:14 --> Database Driver Class Initialized
DEBUG - 2021-06-17 09:21:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 09:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 09:21:14 --> Controller Class Initialized
DEBUG - 2021-06-17 09:21:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-17 09:21:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-17 09:21:14 --> Final output sent to browser
DEBUG - 2021-06-17 09:21:14 --> Total execution time: 0.0503
INFO - 2021-06-17 09:21:14 --> Config Class Initialized
INFO - 2021-06-17 09:21:14 --> Hooks Class Initialized
DEBUG - 2021-06-17 09:21:14 --> UTF-8 Support Enabled
INFO - 2021-06-17 09:21:14 --> Utf8 Class Initialized
INFO - 2021-06-17 09:21:14 --> URI Class Initialized
INFO - 2021-06-17 09:21:14 --> Router Class Initialized
INFO - 2021-06-17 09:21:14 --> Output Class Initialized
INFO - 2021-06-17 09:21:14 --> Security Class Initialized
DEBUG - 2021-06-17 09:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 09:21:14 --> Input Class Initialized
INFO - 2021-06-17 09:21:14 --> Language Class Initialized
INFO - 2021-06-17 09:21:14 --> Language Class Initialized
INFO - 2021-06-17 09:21:14 --> Config Class Initialized
INFO - 2021-06-17 09:21:14 --> Loader Class Initialized
INFO - 2021-06-17 09:21:14 --> Helper loaded: url_helper
INFO - 2021-06-17 09:21:14 --> Helper loaded: file_helper
INFO - 2021-06-17 09:21:14 --> Helper loaded: form_helper
INFO - 2021-06-17 09:21:14 --> Helper loaded: my_helper
INFO - 2021-06-17 09:21:14 --> Database Driver Class Initialized
DEBUG - 2021-06-17 09:21:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 09:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 09:21:14 --> Controller Class Initialized
INFO - 2021-06-17 09:21:15 --> Config Class Initialized
INFO - 2021-06-17 09:21:15 --> Hooks Class Initialized
DEBUG - 2021-06-17 09:21:15 --> UTF-8 Support Enabled
INFO - 2021-06-17 09:21:15 --> Utf8 Class Initialized
INFO - 2021-06-17 09:21:15 --> URI Class Initialized
INFO - 2021-06-17 09:21:15 --> Router Class Initialized
INFO - 2021-06-17 09:21:15 --> Output Class Initialized
INFO - 2021-06-17 09:21:15 --> Security Class Initialized
DEBUG - 2021-06-17 09:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-17 09:21:15 --> Input Class Initialized
INFO - 2021-06-17 09:21:15 --> Language Class Initialized
INFO - 2021-06-17 09:21:15 --> Language Class Initialized
INFO - 2021-06-17 09:21:15 --> Config Class Initialized
INFO - 2021-06-17 09:21:15 --> Loader Class Initialized
INFO - 2021-06-17 09:21:15 --> Helper loaded: url_helper
INFO - 2021-06-17 09:21:15 --> Helper loaded: file_helper
INFO - 2021-06-17 09:21:15 --> Helper loaded: form_helper
INFO - 2021-06-17 09:21:15 --> Helper loaded: my_helper
INFO - 2021-06-17 09:21:15 --> Database Driver Class Initialized
DEBUG - 2021-06-17 09:21:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-17 09:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-17 09:21:15 --> Controller Class Initialized
INFO - 2021-06-17 09:21:15 --> Final output sent to browser
DEBUG - 2021-06-17 09:21:15 --> Total execution time: 0.0518
