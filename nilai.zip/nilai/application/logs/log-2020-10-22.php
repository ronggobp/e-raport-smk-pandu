<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-10-22 03:13:53 --> Config Class Initialized
INFO - 2020-10-22 03:13:53 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:13:53 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:13:53 --> Utf8 Class Initialized
INFO - 2020-10-22 03:13:53 --> URI Class Initialized
DEBUG - 2020-10-22 03:13:53 --> No URI present. Default controller set.
INFO - 2020-10-22 03:13:53 --> Router Class Initialized
INFO - 2020-10-22 03:13:53 --> Output Class Initialized
INFO - 2020-10-22 03:13:53 --> Security Class Initialized
DEBUG - 2020-10-22 03:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:13:53 --> Input Class Initialized
INFO - 2020-10-22 03:13:53 --> Language Class Initialized
INFO - 2020-10-22 03:13:53 --> Language Class Initialized
INFO - 2020-10-22 03:13:53 --> Config Class Initialized
INFO - 2020-10-22 03:13:53 --> Loader Class Initialized
INFO - 2020-10-22 03:13:53 --> Helper loaded: url_helper
INFO - 2020-10-22 03:13:53 --> Helper loaded: file_helper
INFO - 2020-10-22 03:13:53 --> Helper loaded: form_helper
INFO - 2020-10-22 03:13:53 --> Helper loaded: my_helper
INFO - 2020-10-22 03:13:54 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:13:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:13:54 --> Controller Class Initialized
ERROR - 2020-10-22 03:13:54 --> Query error: Table 'db_nilai.tahun' doesn't exist in engine - Invalid query: SELECT tahun FROM tahun WHERE aktif = 'Y'
INFO - 2020-10-22 03:13:54 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-22 03:14:12 --> Config Class Initialized
INFO - 2020-10-22 03:14:12 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:14:12 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:14:12 --> Utf8 Class Initialized
INFO - 2020-10-22 03:14:12 --> URI Class Initialized
DEBUG - 2020-10-22 03:14:12 --> No URI present. Default controller set.
INFO - 2020-10-22 03:14:12 --> Router Class Initialized
INFO - 2020-10-22 03:14:12 --> Output Class Initialized
INFO - 2020-10-22 03:14:12 --> Security Class Initialized
DEBUG - 2020-10-22 03:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:14:12 --> Input Class Initialized
INFO - 2020-10-22 03:14:12 --> Language Class Initialized
INFO - 2020-10-22 03:14:12 --> Language Class Initialized
INFO - 2020-10-22 03:14:12 --> Config Class Initialized
INFO - 2020-10-22 03:14:12 --> Loader Class Initialized
INFO - 2020-10-22 03:14:12 --> Helper loaded: url_helper
INFO - 2020-10-22 03:14:12 --> Helper loaded: file_helper
INFO - 2020-10-22 03:14:12 --> Helper loaded: form_helper
INFO - 2020-10-22 03:14:12 --> Helper loaded: my_helper
INFO - 2020-10-22 03:14:12 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:14:12 --> Controller Class Initialized
ERROR - 2020-10-22 03:14:12 --> Query error: Table 'db_nilai.tahun' doesn't exist in engine - Invalid query: SELECT tahun FROM tahun WHERE aktif = 'Y'
INFO - 2020-10-22 03:14:12 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-22 03:15:45 --> Config Class Initialized
INFO - 2020-10-22 03:15:45 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:15:45 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:15:45 --> Utf8 Class Initialized
INFO - 2020-10-22 03:15:45 --> URI Class Initialized
DEBUG - 2020-10-22 03:15:45 --> No URI present. Default controller set.
INFO - 2020-10-22 03:15:45 --> Router Class Initialized
INFO - 2020-10-22 03:15:45 --> Output Class Initialized
INFO - 2020-10-22 03:15:45 --> Security Class Initialized
DEBUG - 2020-10-22 03:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:15:45 --> Input Class Initialized
INFO - 2020-10-22 03:15:45 --> Language Class Initialized
INFO - 2020-10-22 03:15:45 --> Language Class Initialized
INFO - 2020-10-22 03:15:45 --> Config Class Initialized
INFO - 2020-10-22 03:15:45 --> Loader Class Initialized
INFO - 2020-10-22 03:15:45 --> Helper loaded: url_helper
INFO - 2020-10-22 03:15:45 --> Helper loaded: file_helper
INFO - 2020-10-22 03:15:45 --> Helper loaded: form_helper
INFO - 2020-10-22 03:15:45 --> Helper loaded: my_helper
INFO - 2020-10-22 03:15:45 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:15:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:15:45 --> Controller Class Initialized
ERROR - 2020-10-22 03:15:45 --> Query error: Table 'db_nilai.tahun' doesn't exist in engine - Invalid query: SELECT tahun FROM tahun WHERE aktif = 'Y'
INFO - 2020-10-22 03:15:45 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-22 03:15:46 --> Config Class Initialized
INFO - 2020-10-22 03:15:46 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:15:46 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:15:46 --> Utf8 Class Initialized
INFO - 2020-10-22 03:15:46 --> URI Class Initialized
DEBUG - 2020-10-22 03:15:46 --> No URI present. Default controller set.
INFO - 2020-10-22 03:15:46 --> Router Class Initialized
INFO - 2020-10-22 03:15:46 --> Output Class Initialized
INFO - 2020-10-22 03:15:46 --> Security Class Initialized
DEBUG - 2020-10-22 03:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:15:46 --> Input Class Initialized
INFO - 2020-10-22 03:15:46 --> Language Class Initialized
INFO - 2020-10-22 03:15:46 --> Language Class Initialized
INFO - 2020-10-22 03:15:46 --> Config Class Initialized
INFO - 2020-10-22 03:15:46 --> Loader Class Initialized
INFO - 2020-10-22 03:15:46 --> Helper loaded: url_helper
INFO - 2020-10-22 03:15:46 --> Helper loaded: file_helper
INFO - 2020-10-22 03:15:46 --> Helper loaded: form_helper
INFO - 2020-10-22 03:15:46 --> Helper loaded: my_helper
INFO - 2020-10-22 03:15:46 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:15:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:15:46 --> Controller Class Initialized
ERROR - 2020-10-22 03:15:46 --> Query error: Table 'db_nilai.tahun' doesn't exist in engine - Invalid query: SELECT tahun FROM tahun WHERE aktif = 'Y'
INFO - 2020-10-22 03:15:46 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-22 03:16:20 --> Config Class Initialized
INFO - 2020-10-22 03:16:20 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:16:20 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:16:20 --> Utf8 Class Initialized
INFO - 2020-10-22 03:16:20 --> URI Class Initialized
DEBUG - 2020-10-22 03:16:20 --> No URI present. Default controller set.
INFO - 2020-10-22 03:16:20 --> Router Class Initialized
INFO - 2020-10-22 03:16:20 --> Output Class Initialized
INFO - 2020-10-22 03:16:20 --> Security Class Initialized
DEBUG - 2020-10-22 03:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:16:20 --> Input Class Initialized
INFO - 2020-10-22 03:16:20 --> Language Class Initialized
INFO - 2020-10-22 03:16:20 --> Language Class Initialized
INFO - 2020-10-22 03:16:20 --> Config Class Initialized
INFO - 2020-10-22 03:16:20 --> Loader Class Initialized
INFO - 2020-10-22 03:16:20 --> Helper loaded: url_helper
INFO - 2020-10-22 03:16:20 --> Helper loaded: file_helper
INFO - 2020-10-22 03:16:20 --> Helper loaded: form_helper
INFO - 2020-10-22 03:16:20 --> Helper loaded: my_helper
INFO - 2020-10-22 03:16:20 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:16:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:16:20 --> Controller Class Initialized
ERROR - 2020-10-22 03:16:20 --> Query error: Table 'db_nilai.tahun' doesn't exist in engine - Invalid query: SELECT tahun FROM tahun WHERE aktif = 'Y'
INFO - 2020-10-22 03:16:20 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-22 03:18:12 --> Config Class Initialized
INFO - 2020-10-22 03:18:12 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:18:12 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:18:12 --> Utf8 Class Initialized
INFO - 2020-10-22 03:18:12 --> URI Class Initialized
DEBUG - 2020-10-22 03:18:12 --> No URI present. Default controller set.
INFO - 2020-10-22 03:18:12 --> Router Class Initialized
INFO - 2020-10-22 03:18:12 --> Output Class Initialized
INFO - 2020-10-22 03:18:12 --> Security Class Initialized
DEBUG - 2020-10-22 03:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:18:12 --> Input Class Initialized
INFO - 2020-10-22 03:18:12 --> Language Class Initialized
INFO - 2020-10-22 03:18:12 --> Language Class Initialized
INFO - 2020-10-22 03:18:12 --> Config Class Initialized
INFO - 2020-10-22 03:18:12 --> Loader Class Initialized
INFO - 2020-10-22 03:18:12 --> Helper loaded: url_helper
INFO - 2020-10-22 03:18:12 --> Helper loaded: file_helper
INFO - 2020-10-22 03:18:12 --> Helper loaded: form_helper
INFO - 2020-10-22 03:18:12 --> Helper loaded: my_helper
INFO - 2020-10-22 03:18:12 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:18:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:18:13 --> Controller Class Initialized
INFO - 2020-10-22 03:18:13 --> Config Class Initialized
INFO - 2020-10-22 03:18:13 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:18:13 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:18:13 --> Utf8 Class Initialized
INFO - 2020-10-22 03:18:13 --> URI Class Initialized
INFO - 2020-10-22 03:18:13 --> Router Class Initialized
INFO - 2020-10-22 03:18:13 --> Output Class Initialized
INFO - 2020-10-22 03:18:13 --> Security Class Initialized
DEBUG - 2020-10-22 03:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:18:13 --> Input Class Initialized
INFO - 2020-10-22 03:18:13 --> Language Class Initialized
INFO - 2020-10-22 03:18:13 --> Language Class Initialized
INFO - 2020-10-22 03:18:13 --> Config Class Initialized
INFO - 2020-10-22 03:18:13 --> Loader Class Initialized
INFO - 2020-10-22 03:18:13 --> Helper loaded: url_helper
INFO - 2020-10-22 03:18:13 --> Helper loaded: file_helper
INFO - 2020-10-22 03:18:13 --> Helper loaded: form_helper
INFO - 2020-10-22 03:18:13 --> Helper loaded: my_helper
INFO - 2020-10-22 03:18:13 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:18:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:18:13 --> Controller Class Initialized
DEBUG - 2020-10-22 03:18:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-22 03:18:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-22 03:18:13 --> Final output sent to browser
DEBUG - 2020-10-22 03:18:13 --> Total execution time: 0.2609
INFO - 2020-10-22 03:23:19 --> Config Class Initialized
INFO - 2020-10-22 03:23:19 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:23:19 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:23:19 --> Utf8 Class Initialized
INFO - 2020-10-22 03:23:19 --> URI Class Initialized
INFO - 2020-10-22 03:23:19 --> Router Class Initialized
INFO - 2020-10-22 03:23:19 --> Output Class Initialized
INFO - 2020-10-22 03:23:19 --> Security Class Initialized
DEBUG - 2020-10-22 03:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:23:19 --> Input Class Initialized
INFO - 2020-10-22 03:23:19 --> Language Class Initialized
INFO - 2020-10-22 03:23:19 --> Language Class Initialized
INFO - 2020-10-22 03:23:19 --> Config Class Initialized
INFO - 2020-10-22 03:23:19 --> Loader Class Initialized
INFO - 2020-10-22 03:23:19 --> Helper loaded: url_helper
INFO - 2020-10-22 03:23:19 --> Helper loaded: file_helper
INFO - 2020-10-22 03:23:19 --> Helper loaded: form_helper
INFO - 2020-10-22 03:23:19 --> Helper loaded: my_helper
INFO - 2020-10-22 03:23:20 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:23:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:23:20 --> Controller Class Initialized
INFO - 2020-10-22 03:23:20 --> Helper loaded: cookie_helper
INFO - 2020-10-22 03:23:20 --> Final output sent to browser
DEBUG - 2020-10-22 03:23:20 --> Total execution time: 0.2207
INFO - 2020-10-22 03:23:20 --> Config Class Initialized
INFO - 2020-10-22 03:23:20 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:23:20 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:23:20 --> Utf8 Class Initialized
INFO - 2020-10-22 03:23:20 --> URI Class Initialized
INFO - 2020-10-22 03:23:20 --> Router Class Initialized
INFO - 2020-10-22 03:23:20 --> Output Class Initialized
INFO - 2020-10-22 03:23:20 --> Security Class Initialized
DEBUG - 2020-10-22 03:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:23:20 --> Input Class Initialized
INFO - 2020-10-22 03:23:20 --> Language Class Initialized
INFO - 2020-10-22 03:23:20 --> Language Class Initialized
INFO - 2020-10-22 03:23:20 --> Config Class Initialized
INFO - 2020-10-22 03:23:20 --> Loader Class Initialized
INFO - 2020-10-22 03:23:20 --> Helper loaded: url_helper
INFO - 2020-10-22 03:23:20 --> Helper loaded: file_helper
INFO - 2020-10-22 03:23:20 --> Helper loaded: form_helper
INFO - 2020-10-22 03:23:20 --> Helper loaded: my_helper
INFO - 2020-10-22 03:23:20 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:23:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:23:20 --> Controller Class Initialized
DEBUG - 2020-10-22 03:23:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-22 03:23:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-22 03:23:21 --> Final output sent to browser
DEBUG - 2020-10-22 03:23:21 --> Total execution time: 0.3042
INFO - 2020-10-22 03:23:24 --> Config Class Initialized
INFO - 2020-10-22 03:23:24 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:23:24 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:23:24 --> Utf8 Class Initialized
INFO - 2020-10-22 03:23:24 --> URI Class Initialized
INFO - 2020-10-22 03:23:24 --> Router Class Initialized
INFO - 2020-10-22 03:23:24 --> Output Class Initialized
INFO - 2020-10-22 03:23:24 --> Security Class Initialized
DEBUG - 2020-10-22 03:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:23:25 --> Input Class Initialized
INFO - 2020-10-22 03:23:25 --> Language Class Initialized
INFO - 2020-10-22 03:23:25 --> Language Class Initialized
INFO - 2020-10-22 03:23:25 --> Config Class Initialized
INFO - 2020-10-22 03:23:25 --> Loader Class Initialized
INFO - 2020-10-22 03:23:25 --> Helper loaded: url_helper
INFO - 2020-10-22 03:23:25 --> Helper loaded: file_helper
INFO - 2020-10-22 03:23:25 --> Helper loaded: form_helper
INFO - 2020-10-22 03:23:25 --> Helper loaded: my_helper
INFO - 2020-10-22 03:23:25 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:23:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:23:25 --> Controller Class Initialized
DEBUG - 2020-10-22 03:23:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2020-10-22 03:23:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-22 03:23:25 --> Final output sent to browser
DEBUG - 2020-10-22 03:23:25 --> Total execution time: 0.2351
INFO - 2020-10-22 03:23:25 --> Config Class Initialized
INFO - 2020-10-22 03:23:25 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:23:25 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:23:25 --> Utf8 Class Initialized
INFO - 2020-10-22 03:23:25 --> URI Class Initialized
INFO - 2020-10-22 03:23:25 --> Router Class Initialized
INFO - 2020-10-22 03:23:25 --> Output Class Initialized
INFO - 2020-10-22 03:23:25 --> Security Class Initialized
DEBUG - 2020-10-22 03:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:23:25 --> Input Class Initialized
INFO - 2020-10-22 03:23:25 --> Language Class Initialized
INFO - 2020-10-22 03:23:25 --> Language Class Initialized
INFO - 2020-10-22 03:23:25 --> Config Class Initialized
INFO - 2020-10-22 03:23:25 --> Loader Class Initialized
INFO - 2020-10-22 03:23:25 --> Helper loaded: url_helper
INFO - 2020-10-22 03:23:25 --> Helper loaded: file_helper
INFO - 2020-10-22 03:23:25 --> Helper loaded: form_helper
INFO - 2020-10-22 03:23:25 --> Helper loaded: my_helper
INFO - 2020-10-22 03:23:25 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:23:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:23:25 --> Controller Class Initialized
INFO - 2020-10-22 03:23:26 --> Config Class Initialized
INFO - 2020-10-22 03:23:26 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:23:26 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:23:26 --> Utf8 Class Initialized
INFO - 2020-10-22 03:23:26 --> URI Class Initialized
INFO - 2020-10-22 03:23:26 --> Router Class Initialized
INFO - 2020-10-22 03:23:26 --> Output Class Initialized
INFO - 2020-10-22 03:23:26 --> Security Class Initialized
DEBUG - 2020-10-22 03:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:23:26 --> Input Class Initialized
INFO - 2020-10-22 03:23:26 --> Language Class Initialized
INFO - 2020-10-22 03:23:26 --> Language Class Initialized
INFO - 2020-10-22 03:23:26 --> Config Class Initialized
INFO - 2020-10-22 03:23:26 --> Loader Class Initialized
INFO - 2020-10-22 03:23:26 --> Helper loaded: url_helper
INFO - 2020-10-22 03:23:26 --> Helper loaded: file_helper
INFO - 2020-10-22 03:23:26 --> Helper loaded: form_helper
INFO - 2020-10-22 03:23:26 --> Helper loaded: my_helper
INFO - 2020-10-22 03:23:26 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:23:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:23:26 --> Controller Class Initialized
DEBUG - 2020-10-22 03:23:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-10-22 03:23:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-22 03:23:26 --> Final output sent to browser
DEBUG - 2020-10-22 03:23:26 --> Total execution time: 0.1931
INFO - 2020-10-22 03:23:26 --> Config Class Initialized
INFO - 2020-10-22 03:23:26 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:23:26 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:23:26 --> Utf8 Class Initialized
INFO - 2020-10-22 03:23:26 --> URI Class Initialized
INFO - 2020-10-22 03:23:26 --> Router Class Initialized
INFO - 2020-10-22 03:23:26 --> Output Class Initialized
INFO - 2020-10-22 03:23:26 --> Security Class Initialized
DEBUG - 2020-10-22 03:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:23:26 --> Input Class Initialized
INFO - 2020-10-22 03:23:26 --> Language Class Initialized
INFO - 2020-10-22 03:23:26 --> Language Class Initialized
INFO - 2020-10-22 03:23:26 --> Config Class Initialized
INFO - 2020-10-22 03:23:26 --> Loader Class Initialized
INFO - 2020-10-22 03:23:26 --> Helper loaded: url_helper
INFO - 2020-10-22 03:23:26 --> Helper loaded: file_helper
INFO - 2020-10-22 03:23:26 --> Helper loaded: form_helper
INFO - 2020-10-22 03:23:26 --> Helper loaded: my_helper
INFO - 2020-10-22 03:23:26 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:23:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:23:26 --> Controller Class Initialized
INFO - 2020-10-22 03:23:29 --> Config Class Initialized
INFO - 2020-10-22 03:23:29 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:23:29 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:23:29 --> Utf8 Class Initialized
INFO - 2020-10-22 03:23:29 --> URI Class Initialized
INFO - 2020-10-22 03:23:29 --> Router Class Initialized
INFO - 2020-10-22 03:23:29 --> Output Class Initialized
INFO - 2020-10-22 03:23:29 --> Security Class Initialized
DEBUG - 2020-10-22 03:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:23:29 --> Input Class Initialized
INFO - 2020-10-22 03:23:29 --> Language Class Initialized
INFO - 2020-10-22 03:23:29 --> Language Class Initialized
INFO - 2020-10-22 03:23:29 --> Config Class Initialized
INFO - 2020-10-22 03:23:29 --> Loader Class Initialized
INFO - 2020-10-22 03:23:29 --> Helper loaded: url_helper
INFO - 2020-10-22 03:23:29 --> Helper loaded: file_helper
INFO - 2020-10-22 03:23:29 --> Helper loaded: form_helper
INFO - 2020-10-22 03:23:29 --> Helper loaded: my_helper
INFO - 2020-10-22 03:23:29 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:23:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:23:29 --> Controller Class Initialized
DEBUG - 2020-10-22 03:23:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-10-22 03:23:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-22 03:23:29 --> Final output sent to browser
DEBUG - 2020-10-22 03:23:29 --> Total execution time: 0.2166
INFO - 2020-10-22 03:23:29 --> Config Class Initialized
INFO - 2020-10-22 03:23:29 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:23:29 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:23:29 --> Utf8 Class Initialized
INFO - 2020-10-22 03:23:29 --> URI Class Initialized
INFO - 2020-10-22 03:23:29 --> Router Class Initialized
INFO - 2020-10-22 03:23:29 --> Output Class Initialized
INFO - 2020-10-22 03:23:29 --> Security Class Initialized
DEBUG - 2020-10-22 03:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:23:29 --> Input Class Initialized
INFO - 2020-10-22 03:23:29 --> Language Class Initialized
INFO - 2020-10-22 03:23:29 --> Language Class Initialized
INFO - 2020-10-22 03:23:29 --> Config Class Initialized
INFO - 2020-10-22 03:23:29 --> Loader Class Initialized
INFO - 2020-10-22 03:23:29 --> Helper loaded: url_helper
INFO - 2020-10-22 03:23:29 --> Helper loaded: file_helper
INFO - 2020-10-22 03:23:29 --> Helper loaded: form_helper
INFO - 2020-10-22 03:23:29 --> Helper loaded: my_helper
INFO - 2020-10-22 03:23:29 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:23:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:23:29 --> Controller Class Initialized
INFO - 2020-10-22 03:23:30 --> Config Class Initialized
INFO - 2020-10-22 03:23:30 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:23:30 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:23:30 --> Utf8 Class Initialized
INFO - 2020-10-22 03:23:30 --> URI Class Initialized
INFO - 2020-10-22 03:23:30 --> Router Class Initialized
INFO - 2020-10-22 03:23:30 --> Output Class Initialized
INFO - 2020-10-22 03:23:30 --> Security Class Initialized
DEBUG - 2020-10-22 03:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:23:30 --> Input Class Initialized
INFO - 2020-10-22 03:23:30 --> Language Class Initialized
INFO - 2020-10-22 03:23:30 --> Language Class Initialized
INFO - 2020-10-22 03:23:30 --> Config Class Initialized
INFO - 2020-10-22 03:23:30 --> Loader Class Initialized
INFO - 2020-10-22 03:23:30 --> Helper loaded: url_helper
INFO - 2020-10-22 03:23:30 --> Helper loaded: file_helper
INFO - 2020-10-22 03:23:30 --> Helper loaded: form_helper
INFO - 2020-10-22 03:23:30 --> Helper loaded: my_helper
INFO - 2020-10-22 03:23:30 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:23:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:23:30 --> Controller Class Initialized
DEBUG - 2020-10-22 03:23:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-10-22 03:23:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-22 03:23:30 --> Final output sent to browser
DEBUG - 2020-10-22 03:23:30 --> Total execution time: 0.1853
INFO - 2020-10-22 03:23:30 --> Config Class Initialized
INFO - 2020-10-22 03:23:30 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:23:30 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:23:30 --> Utf8 Class Initialized
INFO - 2020-10-22 03:23:30 --> URI Class Initialized
INFO - 2020-10-22 03:23:30 --> Router Class Initialized
INFO - 2020-10-22 03:23:30 --> Output Class Initialized
INFO - 2020-10-22 03:23:30 --> Security Class Initialized
DEBUG - 2020-10-22 03:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:23:30 --> Input Class Initialized
INFO - 2020-10-22 03:23:30 --> Language Class Initialized
INFO - 2020-10-22 03:23:30 --> Language Class Initialized
INFO - 2020-10-22 03:23:30 --> Config Class Initialized
INFO - 2020-10-22 03:23:30 --> Loader Class Initialized
INFO - 2020-10-22 03:23:30 --> Helper loaded: url_helper
INFO - 2020-10-22 03:23:30 --> Helper loaded: file_helper
INFO - 2020-10-22 03:23:30 --> Helper loaded: form_helper
INFO - 2020-10-22 03:23:30 --> Helper loaded: my_helper
INFO - 2020-10-22 03:23:30 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:23:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:23:30 --> Controller Class Initialized
INFO - 2020-10-22 03:23:32 --> Config Class Initialized
INFO - 2020-10-22 03:23:32 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:23:32 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:23:32 --> Utf8 Class Initialized
INFO - 2020-10-22 03:23:32 --> URI Class Initialized
INFO - 2020-10-22 03:23:32 --> Router Class Initialized
INFO - 2020-10-22 03:23:32 --> Output Class Initialized
INFO - 2020-10-22 03:23:32 --> Security Class Initialized
DEBUG - 2020-10-22 03:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:23:32 --> Input Class Initialized
INFO - 2020-10-22 03:23:32 --> Language Class Initialized
INFO - 2020-10-22 03:23:32 --> Language Class Initialized
INFO - 2020-10-22 03:23:32 --> Config Class Initialized
INFO - 2020-10-22 03:23:32 --> Loader Class Initialized
INFO - 2020-10-22 03:23:32 --> Helper loaded: url_helper
INFO - 2020-10-22 03:23:32 --> Helper loaded: file_helper
INFO - 2020-10-22 03:23:32 --> Helper loaded: form_helper
INFO - 2020-10-22 03:23:32 --> Helper loaded: my_helper
INFO - 2020-10-22 03:23:32 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:23:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:23:32 --> Controller Class Initialized
DEBUG - 2020-10-22 03:23:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-10-22 03:23:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-22 03:23:32 --> Final output sent to browser
DEBUG - 2020-10-22 03:23:32 --> Total execution time: 0.2143
INFO - 2020-10-22 03:23:32 --> Config Class Initialized
INFO - 2020-10-22 03:23:32 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:23:32 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:23:32 --> Utf8 Class Initialized
INFO - 2020-10-22 03:23:32 --> URI Class Initialized
INFO - 2020-10-22 03:23:32 --> Router Class Initialized
INFO - 2020-10-22 03:23:32 --> Output Class Initialized
INFO - 2020-10-22 03:23:32 --> Security Class Initialized
DEBUG - 2020-10-22 03:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:23:32 --> Input Class Initialized
INFO - 2020-10-22 03:23:32 --> Language Class Initialized
INFO - 2020-10-22 03:23:32 --> Language Class Initialized
INFO - 2020-10-22 03:23:32 --> Config Class Initialized
INFO - 2020-10-22 03:23:32 --> Loader Class Initialized
INFO - 2020-10-22 03:23:32 --> Helper loaded: url_helper
INFO - 2020-10-22 03:23:32 --> Helper loaded: file_helper
INFO - 2020-10-22 03:23:32 --> Helper loaded: form_helper
INFO - 2020-10-22 03:23:32 --> Helper loaded: my_helper
INFO - 2020-10-22 03:23:32 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:23:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:23:32 --> Controller Class Initialized
INFO - 2020-10-22 03:23:33 --> Config Class Initialized
INFO - 2020-10-22 03:23:33 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:23:33 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:23:33 --> Utf8 Class Initialized
INFO - 2020-10-22 03:23:33 --> URI Class Initialized
INFO - 2020-10-22 03:23:33 --> Router Class Initialized
INFO - 2020-10-22 03:23:33 --> Output Class Initialized
INFO - 2020-10-22 03:23:33 --> Security Class Initialized
DEBUG - 2020-10-22 03:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:23:33 --> Input Class Initialized
INFO - 2020-10-22 03:23:33 --> Language Class Initialized
INFO - 2020-10-22 03:23:33 --> Language Class Initialized
INFO - 2020-10-22 03:23:33 --> Config Class Initialized
INFO - 2020-10-22 03:23:33 --> Loader Class Initialized
INFO - 2020-10-22 03:23:33 --> Helper loaded: url_helper
INFO - 2020-10-22 03:23:33 --> Helper loaded: file_helper
INFO - 2020-10-22 03:23:33 --> Helper loaded: form_helper
INFO - 2020-10-22 03:23:33 --> Helper loaded: my_helper
INFO - 2020-10-22 03:23:33 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:23:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:23:33 --> Controller Class Initialized
DEBUG - 2020-10-22 03:23:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-22 03:23:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-22 03:23:33 --> Final output sent to browser
DEBUG - 2020-10-22 03:23:33 --> Total execution time: 0.2823
INFO - 2020-10-22 03:23:33 --> Config Class Initialized
INFO - 2020-10-22 03:23:33 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:23:33 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:23:33 --> Utf8 Class Initialized
INFO - 2020-10-22 03:23:33 --> URI Class Initialized
INFO - 2020-10-22 03:23:33 --> Router Class Initialized
INFO - 2020-10-22 03:23:33 --> Output Class Initialized
INFO - 2020-10-22 03:23:33 --> Security Class Initialized
DEBUG - 2020-10-22 03:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:23:33 --> Input Class Initialized
INFO - 2020-10-22 03:23:33 --> Language Class Initialized
INFO - 2020-10-22 03:23:33 --> Language Class Initialized
INFO - 2020-10-22 03:23:33 --> Config Class Initialized
INFO - 2020-10-22 03:23:33 --> Loader Class Initialized
INFO - 2020-10-22 03:23:33 --> Helper loaded: url_helper
INFO - 2020-10-22 03:23:33 --> Helper loaded: file_helper
INFO - 2020-10-22 03:23:33 --> Helper loaded: form_helper
INFO - 2020-10-22 03:23:34 --> Helper loaded: my_helper
INFO - 2020-10-22 03:23:34 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:23:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:23:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:23:34 --> Controller Class Initialized
INFO - 2020-10-22 03:23:35 --> Config Class Initialized
INFO - 2020-10-22 03:23:35 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:23:35 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:23:35 --> Utf8 Class Initialized
INFO - 2020-10-22 03:23:35 --> URI Class Initialized
INFO - 2020-10-22 03:23:35 --> Router Class Initialized
INFO - 2020-10-22 03:23:35 --> Output Class Initialized
INFO - 2020-10-22 03:23:35 --> Security Class Initialized
DEBUG - 2020-10-22 03:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:23:35 --> Input Class Initialized
INFO - 2020-10-22 03:23:35 --> Language Class Initialized
INFO - 2020-10-22 03:23:35 --> Language Class Initialized
INFO - 2020-10-22 03:23:35 --> Config Class Initialized
INFO - 2020-10-22 03:23:35 --> Loader Class Initialized
INFO - 2020-10-22 03:23:35 --> Helper loaded: url_helper
INFO - 2020-10-22 03:23:35 --> Helper loaded: file_helper
INFO - 2020-10-22 03:23:35 --> Helper loaded: form_helper
INFO - 2020-10-22 03:23:35 --> Helper loaded: my_helper
INFO - 2020-10-22 03:23:35 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:23:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:23:35 --> Controller Class Initialized
DEBUG - 2020-10-22 03:23:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-22 03:23:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-22 03:23:35 --> Final output sent to browser
DEBUG - 2020-10-22 03:23:35 --> Total execution time: 0.1971
INFO - 2020-10-22 03:23:35 --> Config Class Initialized
INFO - 2020-10-22 03:23:35 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:23:35 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:23:35 --> Utf8 Class Initialized
INFO - 2020-10-22 03:23:35 --> URI Class Initialized
INFO - 2020-10-22 03:23:35 --> Router Class Initialized
INFO - 2020-10-22 03:23:35 --> Output Class Initialized
INFO - 2020-10-22 03:23:35 --> Security Class Initialized
DEBUG - 2020-10-22 03:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:23:35 --> Input Class Initialized
INFO - 2020-10-22 03:23:35 --> Language Class Initialized
INFO - 2020-10-22 03:23:35 --> Language Class Initialized
INFO - 2020-10-22 03:23:35 --> Config Class Initialized
INFO - 2020-10-22 03:23:35 --> Loader Class Initialized
INFO - 2020-10-22 03:23:35 --> Helper loaded: url_helper
INFO - 2020-10-22 03:23:35 --> Helper loaded: file_helper
INFO - 2020-10-22 03:23:36 --> Helper loaded: form_helper
INFO - 2020-10-22 03:23:36 --> Helper loaded: my_helper
INFO - 2020-10-22 03:23:36 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:23:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:23:36 --> Controller Class Initialized
INFO - 2020-10-22 03:23:42 --> Config Class Initialized
INFO - 2020-10-22 03:23:42 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:23:42 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:23:42 --> Utf8 Class Initialized
INFO - 2020-10-22 03:23:42 --> URI Class Initialized
INFO - 2020-10-22 03:23:42 --> Router Class Initialized
INFO - 2020-10-22 03:23:42 --> Output Class Initialized
INFO - 2020-10-22 03:23:42 --> Security Class Initialized
DEBUG - 2020-10-22 03:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:23:42 --> Input Class Initialized
INFO - 2020-10-22 03:23:42 --> Language Class Initialized
INFO - 2020-10-22 03:23:42 --> Language Class Initialized
INFO - 2020-10-22 03:23:42 --> Config Class Initialized
INFO - 2020-10-22 03:23:42 --> Loader Class Initialized
INFO - 2020-10-22 03:23:42 --> Helper loaded: url_helper
INFO - 2020-10-22 03:23:42 --> Helper loaded: file_helper
INFO - 2020-10-22 03:23:42 --> Helper loaded: form_helper
INFO - 2020-10-22 03:23:42 --> Helper loaded: my_helper
INFO - 2020-10-22 03:23:42 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:23:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:23:42 --> Controller Class Initialized
INFO - 2020-10-22 03:23:42 --> Helper loaded: cookie_helper
INFO - 2020-10-22 03:23:42 --> Config Class Initialized
INFO - 2020-10-22 03:23:42 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:23:42 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:23:42 --> Utf8 Class Initialized
INFO - 2020-10-22 03:23:42 --> URI Class Initialized
INFO - 2020-10-22 03:23:42 --> Router Class Initialized
INFO - 2020-10-22 03:23:42 --> Output Class Initialized
INFO - 2020-10-22 03:23:42 --> Security Class Initialized
DEBUG - 2020-10-22 03:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:23:42 --> Input Class Initialized
INFO - 2020-10-22 03:23:42 --> Language Class Initialized
INFO - 2020-10-22 03:23:42 --> Language Class Initialized
INFO - 2020-10-22 03:23:42 --> Config Class Initialized
INFO - 2020-10-22 03:23:42 --> Loader Class Initialized
INFO - 2020-10-22 03:23:42 --> Helper loaded: url_helper
INFO - 2020-10-22 03:23:42 --> Helper loaded: file_helper
INFO - 2020-10-22 03:23:42 --> Helper loaded: form_helper
INFO - 2020-10-22 03:23:42 --> Helper loaded: my_helper
INFO - 2020-10-22 03:23:42 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:23:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:23:42 --> Controller Class Initialized
DEBUG - 2020-10-22 03:23:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-22 03:23:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-22 03:23:42 --> Final output sent to browser
DEBUG - 2020-10-22 03:23:42 --> Total execution time: 0.1769
INFO - 2020-10-22 03:23:49 --> Config Class Initialized
INFO - 2020-10-22 03:23:49 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:23:49 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:23:49 --> Utf8 Class Initialized
INFO - 2020-10-22 03:23:49 --> URI Class Initialized
INFO - 2020-10-22 03:23:49 --> Router Class Initialized
INFO - 2020-10-22 03:23:49 --> Output Class Initialized
INFO - 2020-10-22 03:23:49 --> Security Class Initialized
DEBUG - 2020-10-22 03:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:23:49 --> Input Class Initialized
INFO - 2020-10-22 03:23:49 --> Language Class Initialized
INFO - 2020-10-22 03:23:49 --> Language Class Initialized
INFO - 2020-10-22 03:23:49 --> Config Class Initialized
INFO - 2020-10-22 03:23:49 --> Loader Class Initialized
INFO - 2020-10-22 03:23:49 --> Helper loaded: url_helper
INFO - 2020-10-22 03:23:49 --> Helper loaded: file_helper
INFO - 2020-10-22 03:23:49 --> Helper loaded: form_helper
INFO - 2020-10-22 03:23:49 --> Helper loaded: my_helper
INFO - 2020-10-22 03:23:49 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:23:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:23:49 --> Controller Class Initialized
INFO - 2020-10-22 03:23:49 --> Helper loaded: cookie_helper
INFO - 2020-10-22 03:23:49 --> Final output sent to browser
DEBUG - 2020-10-22 03:23:49 --> Total execution time: 0.1785
INFO - 2020-10-22 03:23:52 --> Config Class Initialized
INFO - 2020-10-22 03:23:52 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:23:52 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:23:52 --> Utf8 Class Initialized
INFO - 2020-10-22 03:23:52 --> URI Class Initialized
INFO - 2020-10-22 03:23:52 --> Router Class Initialized
INFO - 2020-10-22 03:23:52 --> Output Class Initialized
INFO - 2020-10-22 03:23:52 --> Security Class Initialized
DEBUG - 2020-10-22 03:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:23:52 --> Input Class Initialized
INFO - 2020-10-22 03:23:52 --> Language Class Initialized
INFO - 2020-10-22 03:23:52 --> Language Class Initialized
INFO - 2020-10-22 03:23:52 --> Config Class Initialized
INFO - 2020-10-22 03:23:52 --> Loader Class Initialized
INFO - 2020-10-22 03:23:52 --> Helper loaded: url_helper
INFO - 2020-10-22 03:23:52 --> Helper loaded: file_helper
INFO - 2020-10-22 03:23:52 --> Helper loaded: form_helper
INFO - 2020-10-22 03:23:52 --> Helper loaded: my_helper
INFO - 2020-10-22 03:23:52 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:23:52 --> Controller Class Initialized
DEBUG - 2020-10-22 03:23:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-22 03:23:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-22 03:23:52 --> Final output sent to browser
DEBUG - 2020-10-22 03:23:52 --> Total execution time: 0.2662
INFO - 2020-10-22 03:23:56 --> Config Class Initialized
INFO - 2020-10-22 03:23:56 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:23:56 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:23:56 --> Utf8 Class Initialized
INFO - 2020-10-22 03:23:56 --> URI Class Initialized
INFO - 2020-10-22 03:23:56 --> Router Class Initialized
INFO - 2020-10-22 03:23:56 --> Output Class Initialized
INFO - 2020-10-22 03:23:56 --> Security Class Initialized
DEBUG - 2020-10-22 03:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:23:56 --> Input Class Initialized
INFO - 2020-10-22 03:23:56 --> Language Class Initialized
INFO - 2020-10-22 03:23:56 --> Language Class Initialized
INFO - 2020-10-22 03:23:56 --> Config Class Initialized
INFO - 2020-10-22 03:23:56 --> Loader Class Initialized
INFO - 2020-10-22 03:23:56 --> Helper loaded: url_helper
INFO - 2020-10-22 03:23:56 --> Helper loaded: file_helper
INFO - 2020-10-22 03:23:56 --> Helper loaded: form_helper
INFO - 2020-10-22 03:23:56 --> Helper loaded: my_helper
INFO - 2020-10-22 03:23:56 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:23:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:23:56 --> Controller Class Initialized
DEBUG - 2020-10-22 03:23:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-10-22 03:23:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-22 03:23:56 --> Final output sent to browser
DEBUG - 2020-10-22 03:23:56 --> Total execution time: 0.2212
INFO - 2020-10-22 03:23:59 --> Config Class Initialized
INFO - 2020-10-22 03:23:59 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:23:59 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:23:59 --> Utf8 Class Initialized
INFO - 2020-10-22 03:23:59 --> URI Class Initialized
INFO - 2020-10-22 03:23:59 --> Router Class Initialized
INFO - 2020-10-22 03:23:59 --> Output Class Initialized
INFO - 2020-10-22 03:23:59 --> Security Class Initialized
DEBUG - 2020-10-22 03:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:23:59 --> Input Class Initialized
INFO - 2020-10-22 03:23:59 --> Language Class Initialized
INFO - 2020-10-22 03:23:59 --> Language Class Initialized
INFO - 2020-10-22 03:23:59 --> Config Class Initialized
INFO - 2020-10-22 03:23:59 --> Loader Class Initialized
INFO - 2020-10-22 03:23:59 --> Helper loaded: url_helper
INFO - 2020-10-22 03:23:59 --> Helper loaded: file_helper
INFO - 2020-10-22 03:23:59 --> Helper loaded: form_helper
INFO - 2020-10-22 03:23:59 --> Helper loaded: my_helper
INFO - 2020-10-22 03:23:59 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:23:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:23:59 --> Controller Class Initialized
DEBUG - 2020-10-22 03:23:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-10-22 03:23:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-22 03:23:59 --> Final output sent to browser
DEBUG - 2020-10-22 03:23:59 --> Total execution time: 0.1981
INFO - 2020-10-22 03:23:59 --> Config Class Initialized
INFO - 2020-10-22 03:23:59 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:23:59 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:23:59 --> Utf8 Class Initialized
INFO - 2020-10-22 03:23:59 --> URI Class Initialized
INFO - 2020-10-22 03:23:59 --> Router Class Initialized
INFO - 2020-10-22 03:23:59 --> Output Class Initialized
INFO - 2020-10-22 03:23:59 --> Security Class Initialized
DEBUG - 2020-10-22 03:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:23:59 --> Input Class Initialized
INFO - 2020-10-22 03:23:59 --> Language Class Initialized
INFO - 2020-10-22 03:23:59 --> Language Class Initialized
INFO - 2020-10-22 03:23:59 --> Config Class Initialized
INFO - 2020-10-22 03:23:59 --> Loader Class Initialized
INFO - 2020-10-22 03:23:59 --> Helper loaded: url_helper
INFO - 2020-10-22 03:23:59 --> Helper loaded: file_helper
INFO - 2020-10-22 03:24:00 --> Helper loaded: form_helper
INFO - 2020-10-22 03:24:00 --> Helper loaded: my_helper
INFO - 2020-10-22 03:24:00 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:24:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:24:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:24:00 --> Controller Class Initialized
INFO - 2020-10-22 03:24:12 --> Config Class Initialized
INFO - 2020-10-22 03:24:12 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:24:12 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:24:12 --> Utf8 Class Initialized
INFO - 2020-10-22 03:24:12 --> URI Class Initialized
INFO - 2020-10-22 03:24:12 --> Router Class Initialized
INFO - 2020-10-22 03:24:12 --> Output Class Initialized
INFO - 2020-10-22 03:24:12 --> Security Class Initialized
DEBUG - 2020-10-22 03:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:24:12 --> Input Class Initialized
INFO - 2020-10-22 03:24:12 --> Language Class Initialized
INFO - 2020-10-22 03:24:12 --> Language Class Initialized
INFO - 2020-10-22 03:24:12 --> Config Class Initialized
INFO - 2020-10-22 03:24:12 --> Loader Class Initialized
INFO - 2020-10-22 03:24:12 --> Helper loaded: url_helper
INFO - 2020-10-22 03:24:12 --> Helper loaded: file_helper
INFO - 2020-10-22 03:24:12 --> Helper loaded: form_helper
INFO - 2020-10-22 03:24:12 --> Helper loaded: my_helper
INFO - 2020-10-22 03:24:12 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:24:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:24:12 --> Controller Class Initialized
DEBUG - 2020-10-22 03:24:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-10-22 03:24:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-22 03:24:12 --> Final output sent to browser
DEBUG - 2020-10-22 03:24:12 --> Total execution time: 0.2011
INFO - 2020-10-22 03:24:12 --> Config Class Initialized
INFO - 2020-10-22 03:24:12 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:24:12 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:24:12 --> Utf8 Class Initialized
INFO - 2020-10-22 03:24:12 --> URI Class Initialized
INFO - 2020-10-22 03:24:12 --> Router Class Initialized
INFO - 2020-10-22 03:24:12 --> Output Class Initialized
INFO - 2020-10-22 03:24:12 --> Security Class Initialized
DEBUG - 2020-10-22 03:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:24:12 --> Input Class Initialized
INFO - 2020-10-22 03:24:12 --> Language Class Initialized
INFO - 2020-10-22 03:24:12 --> Language Class Initialized
INFO - 2020-10-22 03:24:12 --> Config Class Initialized
INFO - 2020-10-22 03:24:12 --> Loader Class Initialized
INFO - 2020-10-22 03:24:12 --> Helper loaded: url_helper
INFO - 2020-10-22 03:24:12 --> Helper loaded: file_helper
INFO - 2020-10-22 03:24:12 --> Helper loaded: form_helper
INFO - 2020-10-22 03:24:13 --> Helper loaded: my_helper
INFO - 2020-10-22 03:24:13 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:24:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:24:13 --> Controller Class Initialized
INFO - 2020-10-22 03:24:18 --> Config Class Initialized
INFO - 2020-10-22 03:24:18 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:24:18 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:24:18 --> Utf8 Class Initialized
INFO - 2020-10-22 03:24:18 --> URI Class Initialized
INFO - 2020-10-22 03:24:18 --> Router Class Initialized
INFO - 2020-10-22 03:24:18 --> Output Class Initialized
INFO - 2020-10-22 03:24:18 --> Security Class Initialized
DEBUG - 2020-10-22 03:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:24:18 --> Input Class Initialized
INFO - 2020-10-22 03:24:18 --> Language Class Initialized
INFO - 2020-10-22 03:24:18 --> Language Class Initialized
INFO - 2020-10-22 03:24:18 --> Config Class Initialized
INFO - 2020-10-22 03:24:18 --> Loader Class Initialized
INFO - 2020-10-22 03:24:18 --> Helper loaded: url_helper
INFO - 2020-10-22 03:24:18 --> Helper loaded: file_helper
INFO - 2020-10-22 03:24:18 --> Helper loaded: form_helper
INFO - 2020-10-22 03:24:18 --> Helper loaded: my_helper
INFO - 2020-10-22 03:24:18 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:24:18 --> Controller Class Initialized
DEBUG - 2020-10-22 03:24:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2020-10-22 03:24:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-22 03:24:18 --> Final output sent to browser
DEBUG - 2020-10-22 03:24:18 --> Total execution time: 0.2285
INFO - 2020-10-22 03:24:18 --> Config Class Initialized
INFO - 2020-10-22 03:24:18 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:24:18 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:24:18 --> Utf8 Class Initialized
INFO - 2020-10-22 03:24:18 --> URI Class Initialized
INFO - 2020-10-22 03:24:18 --> Router Class Initialized
INFO - 2020-10-22 03:24:18 --> Output Class Initialized
INFO - 2020-10-22 03:24:18 --> Security Class Initialized
DEBUG - 2020-10-22 03:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:24:18 --> Input Class Initialized
INFO - 2020-10-22 03:24:18 --> Language Class Initialized
INFO - 2020-10-22 03:24:18 --> Language Class Initialized
INFO - 2020-10-22 03:24:18 --> Config Class Initialized
INFO - 2020-10-22 03:24:18 --> Loader Class Initialized
INFO - 2020-10-22 03:24:18 --> Helper loaded: url_helper
INFO - 2020-10-22 03:24:18 --> Helper loaded: file_helper
INFO - 2020-10-22 03:24:18 --> Helper loaded: form_helper
INFO - 2020-10-22 03:24:18 --> Helper loaded: my_helper
INFO - 2020-10-22 03:24:18 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:24:18 --> Controller Class Initialized
INFO - 2020-10-22 03:24:19 --> Config Class Initialized
INFO - 2020-10-22 03:24:19 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:24:19 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:24:19 --> Utf8 Class Initialized
INFO - 2020-10-22 03:24:19 --> URI Class Initialized
INFO - 2020-10-22 03:24:19 --> Router Class Initialized
INFO - 2020-10-22 03:24:19 --> Output Class Initialized
INFO - 2020-10-22 03:24:19 --> Security Class Initialized
DEBUG - 2020-10-22 03:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:24:19 --> Input Class Initialized
INFO - 2020-10-22 03:24:19 --> Language Class Initialized
INFO - 2020-10-22 03:24:19 --> Language Class Initialized
INFO - 2020-10-22 03:24:19 --> Config Class Initialized
INFO - 2020-10-22 03:24:19 --> Loader Class Initialized
INFO - 2020-10-22 03:24:19 --> Helper loaded: url_helper
INFO - 2020-10-22 03:24:19 --> Helper loaded: file_helper
INFO - 2020-10-22 03:24:19 --> Helper loaded: form_helper
INFO - 2020-10-22 03:24:19 --> Helper loaded: my_helper
INFO - 2020-10-22 03:24:20 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:24:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:24:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:24:20 --> Controller Class Initialized
DEBUG - 2020-10-22 03:24:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_ubah_password.php
DEBUG - 2020-10-22 03:24:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-22 03:24:20 --> Final output sent to browser
DEBUG - 2020-10-22 03:24:20 --> Total execution time: 0.2225
INFO - 2020-10-22 03:24:20 --> Config Class Initialized
INFO - 2020-10-22 03:24:20 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:24:20 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:24:20 --> Utf8 Class Initialized
INFO - 2020-10-22 03:24:20 --> URI Class Initialized
INFO - 2020-10-22 03:24:20 --> Router Class Initialized
INFO - 2020-10-22 03:24:20 --> Output Class Initialized
INFO - 2020-10-22 03:24:20 --> Security Class Initialized
DEBUG - 2020-10-22 03:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:24:20 --> Input Class Initialized
INFO - 2020-10-22 03:24:20 --> Language Class Initialized
INFO - 2020-10-22 03:24:20 --> Language Class Initialized
INFO - 2020-10-22 03:24:20 --> Config Class Initialized
INFO - 2020-10-22 03:24:20 --> Loader Class Initialized
INFO - 2020-10-22 03:24:20 --> Helper loaded: url_helper
INFO - 2020-10-22 03:24:20 --> Helper loaded: file_helper
INFO - 2020-10-22 03:24:20 --> Helper loaded: form_helper
INFO - 2020-10-22 03:24:20 --> Helper loaded: my_helper
INFO - 2020-10-22 03:24:20 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:24:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:24:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:24:20 --> Controller Class Initialized
DEBUG - 2020-10-22 03:24:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-10-22 03:24:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-22 03:24:20 --> Final output sent to browser
DEBUG - 2020-10-22 03:24:20 --> Total execution time: 0.1940
INFO - 2020-10-22 03:24:20 --> Config Class Initialized
INFO - 2020-10-22 03:24:20 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:24:20 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:24:20 --> Utf8 Class Initialized
INFO - 2020-10-22 03:24:20 --> URI Class Initialized
INFO - 2020-10-22 03:24:20 --> Router Class Initialized
INFO - 2020-10-22 03:24:20 --> Output Class Initialized
INFO - 2020-10-22 03:24:21 --> Security Class Initialized
DEBUG - 2020-10-22 03:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:24:21 --> Input Class Initialized
INFO - 2020-10-22 03:24:21 --> Language Class Initialized
INFO - 2020-10-22 03:24:21 --> Language Class Initialized
INFO - 2020-10-22 03:24:21 --> Config Class Initialized
INFO - 2020-10-22 03:24:21 --> Loader Class Initialized
INFO - 2020-10-22 03:24:21 --> Helper loaded: url_helper
INFO - 2020-10-22 03:24:21 --> Helper loaded: file_helper
INFO - 2020-10-22 03:24:21 --> Helper loaded: form_helper
INFO - 2020-10-22 03:24:21 --> Helper loaded: my_helper
INFO - 2020-10-22 03:24:21 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:24:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:24:21 --> Controller Class Initialized
INFO - 2020-10-22 03:24:24 --> Config Class Initialized
INFO - 2020-10-22 03:24:24 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:24:24 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:24:24 --> Utf8 Class Initialized
INFO - 2020-10-22 03:24:24 --> URI Class Initialized
INFO - 2020-10-22 03:24:24 --> Router Class Initialized
INFO - 2020-10-22 03:24:24 --> Output Class Initialized
INFO - 2020-10-22 03:24:24 --> Security Class Initialized
DEBUG - 2020-10-22 03:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:24:24 --> Input Class Initialized
INFO - 2020-10-22 03:24:24 --> Language Class Initialized
INFO - 2020-10-22 03:24:24 --> Language Class Initialized
INFO - 2020-10-22 03:24:24 --> Config Class Initialized
INFO - 2020-10-22 03:24:24 --> Loader Class Initialized
INFO - 2020-10-22 03:24:24 --> Helper loaded: url_helper
INFO - 2020-10-22 03:24:24 --> Helper loaded: file_helper
INFO - 2020-10-22 03:24:24 --> Helper loaded: form_helper
INFO - 2020-10-22 03:24:24 --> Helper loaded: my_helper
INFO - 2020-10-22 03:24:24 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:24:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:24:24 --> Controller Class Initialized
INFO - 2020-10-22 03:24:29 --> Config Class Initialized
INFO - 2020-10-22 03:24:29 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:24:29 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:24:29 --> Utf8 Class Initialized
INFO - 2020-10-22 03:24:29 --> URI Class Initialized
INFO - 2020-10-22 03:24:29 --> Router Class Initialized
INFO - 2020-10-22 03:24:29 --> Output Class Initialized
INFO - 2020-10-22 03:24:29 --> Security Class Initialized
DEBUG - 2020-10-22 03:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:24:29 --> Input Class Initialized
INFO - 2020-10-22 03:24:29 --> Language Class Initialized
INFO - 2020-10-22 03:24:29 --> Language Class Initialized
INFO - 2020-10-22 03:24:29 --> Config Class Initialized
INFO - 2020-10-22 03:24:29 --> Loader Class Initialized
INFO - 2020-10-22 03:24:29 --> Helper loaded: url_helper
INFO - 2020-10-22 03:24:29 --> Helper loaded: file_helper
INFO - 2020-10-22 03:24:29 --> Helper loaded: form_helper
INFO - 2020-10-22 03:24:29 --> Helper loaded: my_helper
INFO - 2020-10-22 03:24:30 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:24:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:24:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:24:30 --> Controller Class Initialized
DEBUG - 2020-10-22 03:24:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-10-22 03:24:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-22 03:24:30 --> Final output sent to browser
DEBUG - 2020-10-22 03:24:30 --> Total execution time: 0.1986
INFO - 2020-10-22 03:24:30 --> Config Class Initialized
INFO - 2020-10-22 03:24:30 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:24:30 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:24:30 --> Utf8 Class Initialized
INFO - 2020-10-22 03:24:30 --> URI Class Initialized
INFO - 2020-10-22 03:24:30 --> Router Class Initialized
INFO - 2020-10-22 03:24:30 --> Output Class Initialized
INFO - 2020-10-22 03:24:30 --> Security Class Initialized
DEBUG - 2020-10-22 03:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:24:30 --> Input Class Initialized
INFO - 2020-10-22 03:24:30 --> Language Class Initialized
INFO - 2020-10-22 03:24:30 --> Language Class Initialized
INFO - 2020-10-22 03:24:30 --> Config Class Initialized
INFO - 2020-10-22 03:24:30 --> Loader Class Initialized
INFO - 2020-10-22 03:24:30 --> Helper loaded: url_helper
INFO - 2020-10-22 03:24:31 --> Helper loaded: file_helper
INFO - 2020-10-22 03:24:31 --> Helper loaded: form_helper
INFO - 2020-10-22 03:24:31 --> Helper loaded: my_helper
INFO - 2020-10-22 03:24:31 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:24:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:24:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:24:31 --> Controller Class Initialized
DEBUG - 2020-10-22 03:24:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2020-10-22 03:24:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-22 03:24:31 --> Final output sent to browser
DEBUG - 2020-10-22 03:24:31 --> Total execution time: 0.2407
INFO - 2020-10-22 03:24:31 --> Config Class Initialized
INFO - 2020-10-22 03:24:31 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:24:31 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:24:31 --> Utf8 Class Initialized
INFO - 2020-10-22 03:24:31 --> URI Class Initialized
INFO - 2020-10-22 03:24:31 --> Router Class Initialized
INFO - 2020-10-22 03:24:31 --> Output Class Initialized
INFO - 2020-10-22 03:24:31 --> Security Class Initialized
DEBUG - 2020-10-22 03:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:24:31 --> Input Class Initialized
INFO - 2020-10-22 03:24:31 --> Language Class Initialized
INFO - 2020-10-22 03:24:31 --> Language Class Initialized
INFO - 2020-10-22 03:24:31 --> Config Class Initialized
INFO - 2020-10-22 03:24:31 --> Loader Class Initialized
INFO - 2020-10-22 03:24:31 --> Helper loaded: url_helper
INFO - 2020-10-22 03:24:31 --> Helper loaded: file_helper
INFO - 2020-10-22 03:24:31 --> Helper loaded: form_helper
INFO - 2020-10-22 03:24:31 --> Helper loaded: my_helper
INFO - 2020-10-22 03:24:31 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:24:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:24:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:24:31 --> Controller Class Initialized
INFO - 2020-10-22 03:24:32 --> Config Class Initialized
INFO - 2020-10-22 03:24:32 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:24:32 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:24:32 --> Utf8 Class Initialized
INFO - 2020-10-22 03:24:32 --> URI Class Initialized
INFO - 2020-10-22 03:24:32 --> Router Class Initialized
INFO - 2020-10-22 03:24:32 --> Output Class Initialized
INFO - 2020-10-22 03:24:32 --> Security Class Initialized
DEBUG - 2020-10-22 03:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:24:32 --> Input Class Initialized
INFO - 2020-10-22 03:24:32 --> Language Class Initialized
INFO - 2020-10-22 03:24:32 --> Language Class Initialized
INFO - 2020-10-22 03:24:32 --> Config Class Initialized
INFO - 2020-10-22 03:24:32 --> Loader Class Initialized
INFO - 2020-10-22 03:24:32 --> Helper loaded: url_helper
INFO - 2020-10-22 03:24:32 --> Helper loaded: file_helper
INFO - 2020-10-22 03:24:32 --> Helper loaded: form_helper
INFO - 2020-10-22 03:24:32 --> Helper loaded: my_helper
INFO - 2020-10-22 03:24:32 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:24:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:24:33 --> Controller Class Initialized
DEBUG - 2020-10-22 03:24:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_ekstra/views/list.php
DEBUG - 2020-10-22 03:24:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-22 03:24:33 --> Final output sent to browser
DEBUG - 2020-10-22 03:24:33 --> Total execution time: 0.3471
INFO - 2020-10-22 03:24:33 --> Config Class Initialized
INFO - 2020-10-22 03:24:33 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:24:33 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:24:33 --> Utf8 Class Initialized
INFO - 2020-10-22 03:24:33 --> URI Class Initialized
INFO - 2020-10-22 03:24:33 --> Router Class Initialized
INFO - 2020-10-22 03:24:33 --> Output Class Initialized
INFO - 2020-10-22 03:24:33 --> Security Class Initialized
DEBUG - 2020-10-22 03:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:24:33 --> Input Class Initialized
INFO - 2020-10-22 03:24:33 --> Language Class Initialized
INFO - 2020-10-22 03:24:33 --> Language Class Initialized
INFO - 2020-10-22 03:24:33 --> Config Class Initialized
INFO - 2020-10-22 03:24:33 --> Loader Class Initialized
INFO - 2020-10-22 03:24:33 --> Helper loaded: url_helper
INFO - 2020-10-22 03:24:33 --> Helper loaded: file_helper
INFO - 2020-10-22 03:24:33 --> Helper loaded: form_helper
INFO - 2020-10-22 03:24:33 --> Helper loaded: my_helper
INFO - 2020-10-22 03:24:33 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:24:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:24:33 --> Controller Class Initialized
INFO - 2020-10-22 03:24:33 --> Config Class Initialized
INFO - 2020-10-22 03:24:33 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:24:33 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:24:33 --> Utf8 Class Initialized
INFO - 2020-10-22 03:24:34 --> URI Class Initialized
INFO - 2020-10-22 03:24:34 --> Router Class Initialized
INFO - 2020-10-22 03:24:34 --> Output Class Initialized
INFO - 2020-10-22 03:24:34 --> Security Class Initialized
DEBUG - 2020-10-22 03:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:24:34 --> Input Class Initialized
INFO - 2020-10-22 03:24:34 --> Language Class Initialized
INFO - 2020-10-22 03:24:34 --> Language Class Initialized
INFO - 2020-10-22 03:24:34 --> Config Class Initialized
INFO - 2020-10-22 03:24:34 --> Loader Class Initialized
INFO - 2020-10-22 03:24:34 --> Helper loaded: url_helper
INFO - 2020-10-22 03:24:34 --> Helper loaded: file_helper
INFO - 2020-10-22 03:24:34 --> Helper loaded: form_helper
INFO - 2020-10-22 03:24:34 --> Helper loaded: my_helper
INFO - 2020-10-22 03:24:34 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:24:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:24:34 --> Controller Class Initialized
DEBUG - 2020-10-22 03:24:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-22 03:24:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-22 03:24:34 --> Final output sent to browser
DEBUG - 2020-10-22 03:24:34 --> Total execution time: 0.2455
INFO - 2020-10-22 03:24:34 --> Config Class Initialized
INFO - 2020-10-22 03:24:34 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:24:34 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:24:34 --> Utf8 Class Initialized
INFO - 2020-10-22 03:24:34 --> URI Class Initialized
INFO - 2020-10-22 03:24:34 --> Router Class Initialized
INFO - 2020-10-22 03:24:34 --> Output Class Initialized
INFO - 2020-10-22 03:24:34 --> Security Class Initialized
DEBUG - 2020-10-22 03:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:24:34 --> Input Class Initialized
INFO - 2020-10-22 03:24:34 --> Language Class Initialized
INFO - 2020-10-22 03:24:34 --> Language Class Initialized
INFO - 2020-10-22 03:24:34 --> Config Class Initialized
INFO - 2020-10-22 03:24:34 --> Loader Class Initialized
INFO - 2020-10-22 03:24:34 --> Helper loaded: url_helper
INFO - 2020-10-22 03:24:34 --> Helper loaded: file_helper
INFO - 2020-10-22 03:24:34 --> Helper loaded: form_helper
INFO - 2020-10-22 03:24:34 --> Helper loaded: my_helper
INFO - 2020-10-22 03:24:34 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:24:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:24:34 --> Controller Class Initialized
INFO - 2020-10-22 03:24:36 --> Config Class Initialized
INFO - 2020-10-22 03:24:36 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:24:36 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:24:36 --> Utf8 Class Initialized
INFO - 2020-10-22 03:24:36 --> URI Class Initialized
INFO - 2020-10-22 03:24:36 --> Router Class Initialized
INFO - 2020-10-22 03:24:36 --> Output Class Initialized
INFO - 2020-10-22 03:24:36 --> Security Class Initialized
DEBUG - 2020-10-22 03:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:24:36 --> Input Class Initialized
INFO - 2020-10-22 03:24:36 --> Language Class Initialized
INFO - 2020-10-22 03:24:36 --> Language Class Initialized
INFO - 2020-10-22 03:24:36 --> Config Class Initialized
INFO - 2020-10-22 03:24:36 --> Loader Class Initialized
INFO - 2020-10-22 03:24:36 --> Helper loaded: url_helper
INFO - 2020-10-22 03:24:36 --> Helper loaded: file_helper
INFO - 2020-10-22 03:24:36 --> Helper loaded: form_helper
INFO - 2020-10-22 03:24:36 --> Helper loaded: my_helper
INFO - 2020-10-22 03:24:36 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:24:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:24:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:24:36 --> Controller Class Initialized
DEBUG - 2020-10-22 03:24:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2020-10-22 03:24:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-22 03:24:36 --> Final output sent to browser
DEBUG - 2020-10-22 03:24:36 --> Total execution time: 0.2147
INFO - 2020-10-22 03:24:36 --> Config Class Initialized
INFO - 2020-10-22 03:24:36 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:24:36 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:24:36 --> Utf8 Class Initialized
INFO - 2020-10-22 03:24:36 --> URI Class Initialized
INFO - 2020-10-22 03:24:36 --> Router Class Initialized
INFO - 2020-10-22 03:24:36 --> Output Class Initialized
INFO - 2020-10-22 03:24:36 --> Security Class Initialized
DEBUG - 2020-10-22 03:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:24:36 --> Input Class Initialized
INFO - 2020-10-22 03:24:36 --> Language Class Initialized
INFO - 2020-10-22 03:24:36 --> Language Class Initialized
INFO - 2020-10-22 03:24:36 --> Config Class Initialized
INFO - 2020-10-22 03:24:36 --> Loader Class Initialized
INFO - 2020-10-22 03:24:36 --> Helper loaded: url_helper
INFO - 2020-10-22 03:24:36 --> Helper loaded: file_helper
INFO - 2020-10-22 03:24:36 --> Helper loaded: form_helper
INFO - 2020-10-22 03:24:36 --> Helper loaded: my_helper
INFO - 2020-10-22 03:24:36 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:24:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:24:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:24:36 --> Controller Class Initialized
INFO - 2020-10-22 03:24:48 --> Config Class Initialized
INFO - 2020-10-22 03:24:48 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:24:48 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:24:48 --> Utf8 Class Initialized
INFO - 2020-10-22 03:24:48 --> URI Class Initialized
INFO - 2020-10-22 03:24:48 --> Router Class Initialized
INFO - 2020-10-22 03:24:48 --> Output Class Initialized
INFO - 2020-10-22 03:24:48 --> Security Class Initialized
DEBUG - 2020-10-22 03:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:24:48 --> Input Class Initialized
INFO - 2020-10-22 03:24:48 --> Language Class Initialized
INFO - 2020-10-22 03:24:48 --> Language Class Initialized
INFO - 2020-10-22 03:24:48 --> Config Class Initialized
INFO - 2020-10-22 03:24:48 --> Loader Class Initialized
INFO - 2020-10-22 03:24:48 --> Helper loaded: url_helper
INFO - 2020-10-22 03:24:48 --> Helper loaded: file_helper
INFO - 2020-10-22 03:24:48 --> Helper loaded: form_helper
INFO - 2020-10-22 03:24:48 --> Helper loaded: my_helper
INFO - 2020-10-22 03:24:48 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:24:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:24:48 --> Controller Class Initialized
DEBUG - 2020-10-22 03:24:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-10-22 03:24:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-22 03:24:48 --> Final output sent to browser
DEBUG - 2020-10-22 03:24:48 --> Total execution time: 0.2099
INFO - 2020-10-22 03:24:48 --> Config Class Initialized
INFO - 2020-10-22 03:24:48 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:24:48 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:24:48 --> Utf8 Class Initialized
INFO - 2020-10-22 03:24:48 --> URI Class Initialized
INFO - 2020-10-22 03:24:48 --> Router Class Initialized
INFO - 2020-10-22 03:24:48 --> Output Class Initialized
INFO - 2020-10-22 03:24:48 --> Security Class Initialized
DEBUG - 2020-10-22 03:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:24:48 --> Input Class Initialized
INFO - 2020-10-22 03:24:48 --> Language Class Initialized
INFO - 2020-10-22 03:24:48 --> Language Class Initialized
INFO - 2020-10-22 03:24:48 --> Config Class Initialized
INFO - 2020-10-22 03:24:48 --> Loader Class Initialized
INFO - 2020-10-22 03:24:48 --> Helper loaded: url_helper
INFO - 2020-10-22 03:24:48 --> Helper loaded: file_helper
INFO - 2020-10-22 03:24:48 --> Helper loaded: form_helper
INFO - 2020-10-22 03:24:48 --> Helper loaded: my_helper
INFO - 2020-10-22 03:24:48 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:24:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:24:48 --> Controller Class Initialized
INFO - 2020-10-22 03:24:55 --> Config Class Initialized
INFO - 2020-10-22 03:24:55 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:24:55 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:24:55 --> Utf8 Class Initialized
INFO - 2020-10-22 03:24:55 --> URI Class Initialized
INFO - 2020-10-22 03:24:55 --> Router Class Initialized
INFO - 2020-10-22 03:24:55 --> Output Class Initialized
INFO - 2020-10-22 03:24:55 --> Security Class Initialized
DEBUG - 2020-10-22 03:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:24:55 --> Input Class Initialized
INFO - 2020-10-22 03:24:55 --> Language Class Initialized
INFO - 2020-10-22 03:24:55 --> Language Class Initialized
INFO - 2020-10-22 03:24:55 --> Config Class Initialized
INFO - 2020-10-22 03:24:55 --> Loader Class Initialized
INFO - 2020-10-22 03:24:55 --> Helper loaded: url_helper
INFO - 2020-10-22 03:24:55 --> Helper loaded: file_helper
INFO - 2020-10-22 03:24:55 --> Helper loaded: form_helper
INFO - 2020-10-22 03:24:55 --> Helper loaded: my_helper
INFO - 2020-10-22 03:24:55 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:24:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:24:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:24:55 --> Controller Class Initialized
DEBUG - 2020-10-22 03:24:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-22 03:24:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-22 03:24:55 --> Final output sent to browser
DEBUG - 2020-10-22 03:24:55 --> Total execution time: 0.2068
INFO - 2020-10-22 03:24:55 --> Config Class Initialized
INFO - 2020-10-22 03:24:55 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:24:55 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:24:55 --> Utf8 Class Initialized
INFO - 2020-10-22 03:24:55 --> URI Class Initialized
INFO - 2020-10-22 03:24:55 --> Router Class Initialized
INFO - 2020-10-22 03:24:55 --> Output Class Initialized
INFO - 2020-10-22 03:24:55 --> Security Class Initialized
DEBUG - 2020-10-22 03:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:24:55 --> Input Class Initialized
INFO - 2020-10-22 03:24:55 --> Language Class Initialized
INFO - 2020-10-22 03:24:55 --> Language Class Initialized
INFO - 2020-10-22 03:24:55 --> Config Class Initialized
INFO - 2020-10-22 03:24:55 --> Loader Class Initialized
INFO - 2020-10-22 03:24:55 --> Helper loaded: url_helper
INFO - 2020-10-22 03:24:55 --> Helper loaded: file_helper
INFO - 2020-10-22 03:24:55 --> Helper loaded: form_helper
INFO - 2020-10-22 03:24:55 --> Helper loaded: my_helper
INFO - 2020-10-22 03:24:55 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:24:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:24:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:24:55 --> Controller Class Initialized
INFO - 2020-10-22 03:25:04 --> Config Class Initialized
INFO - 2020-10-22 03:25:04 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:25:04 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:25:04 --> Utf8 Class Initialized
INFO - 2020-10-22 03:25:04 --> URI Class Initialized
INFO - 2020-10-22 03:25:04 --> Router Class Initialized
INFO - 2020-10-22 03:25:04 --> Output Class Initialized
INFO - 2020-10-22 03:25:04 --> Security Class Initialized
DEBUG - 2020-10-22 03:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:25:04 --> Input Class Initialized
INFO - 2020-10-22 03:25:04 --> Language Class Initialized
INFO - 2020-10-22 03:25:04 --> Language Class Initialized
INFO - 2020-10-22 03:25:04 --> Config Class Initialized
INFO - 2020-10-22 03:25:04 --> Loader Class Initialized
INFO - 2020-10-22 03:25:04 --> Helper loaded: url_helper
INFO - 2020-10-22 03:25:04 --> Helper loaded: file_helper
INFO - 2020-10-22 03:25:04 --> Helper loaded: form_helper
INFO - 2020-10-22 03:25:04 --> Helper loaded: my_helper
INFO - 2020-10-22 03:25:04 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:25:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:25:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:25:04 --> Controller Class Initialized
DEBUG - 2020-10-22 03:25:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2020-10-22 03:25:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-22 03:25:04 --> Final output sent to browser
DEBUG - 2020-10-22 03:25:04 --> Total execution time: 0.2912
INFO - 2020-10-22 03:25:04 --> Config Class Initialized
INFO - 2020-10-22 03:25:04 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:25:04 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:25:04 --> Utf8 Class Initialized
INFO - 2020-10-22 03:25:04 --> URI Class Initialized
INFO - 2020-10-22 03:25:04 --> Router Class Initialized
INFO - 2020-10-22 03:25:04 --> Output Class Initialized
INFO - 2020-10-22 03:25:04 --> Security Class Initialized
DEBUG - 2020-10-22 03:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:25:04 --> Input Class Initialized
INFO - 2020-10-22 03:25:04 --> Language Class Initialized
INFO - 2020-10-22 03:25:04 --> Language Class Initialized
INFO - 2020-10-22 03:25:04 --> Config Class Initialized
INFO - 2020-10-22 03:25:04 --> Loader Class Initialized
INFO - 2020-10-22 03:25:04 --> Helper loaded: url_helper
INFO - 2020-10-22 03:25:04 --> Helper loaded: file_helper
INFO - 2020-10-22 03:25:04 --> Helper loaded: form_helper
INFO - 2020-10-22 03:25:04 --> Helper loaded: my_helper
INFO - 2020-10-22 03:25:04 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:25:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:25:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:25:04 --> Controller Class Initialized
INFO - 2020-10-22 03:25:08 --> Config Class Initialized
INFO - 2020-10-22 03:25:08 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:25:08 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:25:08 --> Utf8 Class Initialized
INFO - 2020-10-22 03:25:08 --> URI Class Initialized
INFO - 2020-10-22 03:25:08 --> Router Class Initialized
INFO - 2020-10-22 03:25:08 --> Output Class Initialized
INFO - 2020-10-22 03:25:08 --> Security Class Initialized
DEBUG - 2020-10-22 03:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:25:08 --> Input Class Initialized
INFO - 2020-10-22 03:25:08 --> Language Class Initialized
INFO - 2020-10-22 03:25:08 --> Language Class Initialized
INFO - 2020-10-22 03:25:08 --> Config Class Initialized
INFO - 2020-10-22 03:25:08 --> Loader Class Initialized
INFO - 2020-10-22 03:25:08 --> Helper loaded: url_helper
INFO - 2020-10-22 03:25:08 --> Helper loaded: file_helper
INFO - 2020-10-22 03:25:08 --> Helper loaded: form_helper
INFO - 2020-10-22 03:25:08 --> Helper loaded: my_helper
INFO - 2020-10-22 03:25:08 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:25:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:25:08 --> Controller Class Initialized
DEBUG - 2020-10-22 03:25:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2020-10-22 03:25:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-22 03:25:08 --> Final output sent to browser
DEBUG - 2020-10-22 03:25:08 --> Total execution time: 0.2107
INFO - 2020-10-22 03:25:09 --> Config Class Initialized
INFO - 2020-10-22 03:25:09 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:25:09 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:25:09 --> Utf8 Class Initialized
INFO - 2020-10-22 03:25:09 --> URI Class Initialized
INFO - 2020-10-22 03:25:09 --> Router Class Initialized
INFO - 2020-10-22 03:25:09 --> Output Class Initialized
INFO - 2020-10-22 03:25:09 --> Security Class Initialized
DEBUG - 2020-10-22 03:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:25:09 --> Input Class Initialized
INFO - 2020-10-22 03:25:09 --> Language Class Initialized
INFO - 2020-10-22 03:25:09 --> Language Class Initialized
INFO - 2020-10-22 03:25:09 --> Config Class Initialized
INFO - 2020-10-22 03:25:09 --> Loader Class Initialized
INFO - 2020-10-22 03:25:09 --> Helper loaded: url_helper
INFO - 2020-10-22 03:25:09 --> Helper loaded: file_helper
INFO - 2020-10-22 03:25:09 --> Helper loaded: form_helper
INFO - 2020-10-22 03:25:09 --> Helper loaded: my_helper
INFO - 2020-10-22 03:25:09 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:25:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:25:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:25:09 --> Controller Class Initialized
INFO - 2020-10-22 03:25:11 --> Config Class Initialized
INFO - 2020-10-22 03:25:11 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:25:11 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:25:11 --> Utf8 Class Initialized
INFO - 2020-10-22 03:25:11 --> URI Class Initialized
INFO - 2020-10-22 03:25:11 --> Router Class Initialized
INFO - 2020-10-22 03:25:11 --> Output Class Initialized
INFO - 2020-10-22 03:25:11 --> Security Class Initialized
DEBUG - 2020-10-22 03:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:25:11 --> Input Class Initialized
INFO - 2020-10-22 03:25:11 --> Language Class Initialized
INFO - 2020-10-22 03:25:11 --> Language Class Initialized
INFO - 2020-10-22 03:25:11 --> Config Class Initialized
INFO - 2020-10-22 03:25:11 --> Loader Class Initialized
INFO - 2020-10-22 03:25:11 --> Helper loaded: url_helper
INFO - 2020-10-22 03:25:11 --> Helper loaded: file_helper
INFO - 2020-10-22 03:25:11 --> Helper loaded: form_helper
INFO - 2020-10-22 03:25:11 --> Helper loaded: my_helper
INFO - 2020-10-22 03:25:11 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:25:11 --> Controller Class Initialized
INFO - 2020-10-22 03:25:11 --> Helper loaded: cookie_helper
INFO - 2020-10-22 03:25:11 --> Config Class Initialized
INFO - 2020-10-22 03:25:11 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:25:11 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:25:11 --> Utf8 Class Initialized
INFO - 2020-10-22 03:25:11 --> URI Class Initialized
INFO - 2020-10-22 03:25:11 --> Router Class Initialized
INFO - 2020-10-22 03:25:11 --> Output Class Initialized
INFO - 2020-10-22 03:25:11 --> Security Class Initialized
DEBUG - 2020-10-22 03:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:25:11 --> Input Class Initialized
INFO - 2020-10-22 03:25:11 --> Language Class Initialized
INFO - 2020-10-22 03:25:11 --> Language Class Initialized
INFO - 2020-10-22 03:25:11 --> Config Class Initialized
INFO - 2020-10-22 03:25:11 --> Loader Class Initialized
INFO - 2020-10-22 03:25:11 --> Helper loaded: url_helper
INFO - 2020-10-22 03:25:11 --> Helper loaded: file_helper
INFO - 2020-10-22 03:25:11 --> Helper loaded: form_helper
INFO - 2020-10-22 03:25:11 --> Helper loaded: my_helper
INFO - 2020-10-22 03:25:11 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:25:11 --> Controller Class Initialized
DEBUG - 2020-10-22 03:25:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-22 03:25:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-22 03:25:11 --> Final output sent to browser
DEBUG - 2020-10-22 03:25:11 --> Total execution time: 0.2286
INFO - 2020-10-22 03:25:18 --> Config Class Initialized
INFO - 2020-10-22 03:25:18 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:25:18 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:25:18 --> Utf8 Class Initialized
INFO - 2020-10-22 03:25:18 --> URI Class Initialized
INFO - 2020-10-22 03:25:18 --> Router Class Initialized
INFO - 2020-10-22 03:25:18 --> Output Class Initialized
INFO - 2020-10-22 03:25:18 --> Security Class Initialized
DEBUG - 2020-10-22 03:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:25:18 --> Input Class Initialized
INFO - 2020-10-22 03:25:18 --> Language Class Initialized
INFO - 2020-10-22 03:25:18 --> Language Class Initialized
INFO - 2020-10-22 03:25:18 --> Config Class Initialized
INFO - 2020-10-22 03:25:18 --> Loader Class Initialized
INFO - 2020-10-22 03:25:18 --> Helper loaded: url_helper
INFO - 2020-10-22 03:25:18 --> Helper loaded: file_helper
INFO - 2020-10-22 03:25:18 --> Helper loaded: form_helper
INFO - 2020-10-22 03:25:18 --> Helper loaded: my_helper
INFO - 2020-10-22 03:25:18 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:25:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:25:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:25:18 --> Controller Class Initialized
INFO - 2020-10-22 03:25:18 --> Helper loaded: cookie_helper
INFO - 2020-10-22 03:25:18 --> Final output sent to browser
DEBUG - 2020-10-22 03:25:18 --> Total execution time: 0.1982
INFO - 2020-10-22 03:25:19 --> Config Class Initialized
INFO - 2020-10-22 03:25:19 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:25:19 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:25:19 --> Utf8 Class Initialized
INFO - 2020-10-22 03:25:19 --> URI Class Initialized
INFO - 2020-10-22 03:25:19 --> Router Class Initialized
INFO - 2020-10-22 03:25:19 --> Output Class Initialized
INFO - 2020-10-22 03:25:19 --> Security Class Initialized
DEBUG - 2020-10-22 03:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:25:19 --> Input Class Initialized
INFO - 2020-10-22 03:25:19 --> Language Class Initialized
INFO - 2020-10-22 03:25:20 --> Language Class Initialized
INFO - 2020-10-22 03:25:20 --> Config Class Initialized
INFO - 2020-10-22 03:25:20 --> Loader Class Initialized
INFO - 2020-10-22 03:25:20 --> Helper loaded: url_helper
INFO - 2020-10-22 03:25:20 --> Helper loaded: file_helper
INFO - 2020-10-22 03:25:20 --> Helper loaded: form_helper
INFO - 2020-10-22 03:25:20 --> Helper loaded: my_helper
INFO - 2020-10-22 03:25:20 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:25:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:25:20 --> Controller Class Initialized
DEBUG - 2020-10-22 03:25:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-22 03:25:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-22 03:25:20 --> Final output sent to browser
DEBUG - 2020-10-22 03:25:20 --> Total execution time: 0.2810
INFO - 2020-10-22 03:25:22 --> Config Class Initialized
INFO - 2020-10-22 03:25:22 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:25:22 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:25:22 --> Utf8 Class Initialized
INFO - 2020-10-22 03:25:22 --> URI Class Initialized
INFO - 2020-10-22 03:25:22 --> Router Class Initialized
INFO - 2020-10-22 03:25:22 --> Output Class Initialized
INFO - 2020-10-22 03:25:22 --> Security Class Initialized
DEBUG - 2020-10-22 03:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:25:22 --> Input Class Initialized
INFO - 2020-10-22 03:25:22 --> Language Class Initialized
INFO - 2020-10-22 03:25:22 --> Language Class Initialized
INFO - 2020-10-22 03:25:22 --> Config Class Initialized
INFO - 2020-10-22 03:25:22 --> Loader Class Initialized
INFO - 2020-10-22 03:25:22 --> Helper loaded: url_helper
INFO - 2020-10-22 03:25:22 --> Helper loaded: file_helper
INFO - 2020-10-22 03:25:22 --> Helper loaded: form_helper
INFO - 2020-10-22 03:25:22 --> Helper loaded: my_helper
INFO - 2020-10-22 03:25:22 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:25:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:25:22 --> Controller Class Initialized
DEBUG - 2020-10-22 03:25:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2020-10-22 03:25:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-22 03:25:23 --> Final output sent to browser
DEBUG - 2020-10-22 03:25:23 --> Total execution time: 0.2940
INFO - 2020-10-22 03:25:25 --> Config Class Initialized
INFO - 2020-10-22 03:25:25 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:25:25 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:25:25 --> Utf8 Class Initialized
INFO - 2020-10-22 03:25:25 --> URI Class Initialized
INFO - 2020-10-22 03:25:25 --> Router Class Initialized
INFO - 2020-10-22 03:25:25 --> Output Class Initialized
INFO - 2020-10-22 03:25:25 --> Security Class Initialized
DEBUG - 2020-10-22 03:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:25:25 --> Input Class Initialized
INFO - 2020-10-22 03:25:25 --> Language Class Initialized
INFO - 2020-10-22 03:25:25 --> Language Class Initialized
INFO - 2020-10-22 03:25:25 --> Config Class Initialized
INFO - 2020-10-22 03:25:25 --> Loader Class Initialized
INFO - 2020-10-22 03:25:25 --> Helper loaded: url_helper
INFO - 2020-10-22 03:25:25 --> Helper loaded: file_helper
INFO - 2020-10-22 03:25:25 --> Helper loaded: form_helper
INFO - 2020-10-22 03:25:25 --> Helper loaded: my_helper
INFO - 2020-10-22 03:25:25 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:25:25 --> Controller Class Initialized
ERROR - 2020-10-22 03:25:25 --> Severity: Notice --> Undefined variable: kelompok C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_rapot.php 57
ERROR - 2020-10-22 03:25:25 --> Severity: Notice --> Undefined variable: kd_singkat C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_rapot.php 62
DEBUG - 2020-10-22 03:25:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-10-22 03:25:25 --> Final output sent to browser
DEBUG - 2020-10-22 03:25:25 --> Total execution time: 0.4361
INFO - 2020-10-22 03:27:12 --> Config Class Initialized
INFO - 2020-10-22 03:27:12 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:27:12 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:27:12 --> Utf8 Class Initialized
INFO - 2020-10-22 03:27:12 --> URI Class Initialized
INFO - 2020-10-22 03:27:12 --> Router Class Initialized
INFO - 2020-10-22 03:27:12 --> Output Class Initialized
INFO - 2020-10-22 03:27:12 --> Security Class Initialized
DEBUG - 2020-10-22 03:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:27:12 --> Input Class Initialized
INFO - 2020-10-22 03:27:12 --> Language Class Initialized
INFO - 2020-10-22 03:27:12 --> Language Class Initialized
INFO - 2020-10-22 03:27:12 --> Config Class Initialized
INFO - 2020-10-22 03:27:12 --> Loader Class Initialized
INFO - 2020-10-22 03:27:12 --> Helper loaded: url_helper
INFO - 2020-10-22 03:27:12 --> Helper loaded: file_helper
INFO - 2020-10-22 03:27:12 --> Helper loaded: form_helper
INFO - 2020-10-22 03:27:12 --> Helper loaded: my_helper
INFO - 2020-10-22 03:27:12 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:27:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:27:12 --> Controller Class Initialized
DEBUG - 2020-10-22 03:27:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_prestasi/views/list.php
DEBUG - 2020-10-22 03:27:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-22 03:27:12 --> Final output sent to browser
DEBUG - 2020-10-22 03:27:12 --> Total execution time: 0.2237
INFO - 2020-10-22 03:27:12 --> Config Class Initialized
INFO - 2020-10-22 03:27:12 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:27:12 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:27:12 --> Utf8 Class Initialized
INFO - 2020-10-22 03:27:12 --> URI Class Initialized
INFO - 2020-10-22 03:27:12 --> Router Class Initialized
INFO - 2020-10-22 03:27:12 --> Output Class Initialized
INFO - 2020-10-22 03:27:12 --> Security Class Initialized
DEBUG - 2020-10-22 03:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:27:12 --> Input Class Initialized
INFO - 2020-10-22 03:27:12 --> Language Class Initialized
INFO - 2020-10-22 03:27:12 --> Language Class Initialized
INFO - 2020-10-22 03:27:12 --> Config Class Initialized
INFO - 2020-10-22 03:27:12 --> Loader Class Initialized
INFO - 2020-10-22 03:27:12 --> Helper loaded: url_helper
INFO - 2020-10-22 03:27:12 --> Helper loaded: file_helper
INFO - 2020-10-22 03:27:12 --> Helper loaded: form_helper
INFO - 2020-10-22 03:27:12 --> Helper loaded: my_helper
INFO - 2020-10-22 03:27:12 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:27:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:27:12 --> Controller Class Initialized
INFO - 2020-10-22 03:27:13 --> Config Class Initialized
INFO - 2020-10-22 03:27:13 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:27:13 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:27:13 --> Utf8 Class Initialized
INFO - 2020-10-22 03:27:13 --> URI Class Initialized
INFO - 2020-10-22 03:27:13 --> Router Class Initialized
INFO - 2020-10-22 03:27:13 --> Output Class Initialized
INFO - 2020-10-22 03:27:13 --> Security Class Initialized
DEBUG - 2020-10-22 03:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:27:13 --> Input Class Initialized
INFO - 2020-10-22 03:27:13 --> Language Class Initialized
INFO - 2020-10-22 03:27:13 --> Language Class Initialized
INFO - 2020-10-22 03:27:13 --> Config Class Initialized
INFO - 2020-10-22 03:27:13 --> Loader Class Initialized
INFO - 2020-10-22 03:27:13 --> Helper loaded: url_helper
INFO - 2020-10-22 03:27:13 --> Helper loaded: file_helper
INFO - 2020-10-22 03:27:13 --> Helper loaded: form_helper
INFO - 2020-10-22 03:27:13 --> Helper loaded: my_helper
INFO - 2020-10-22 03:27:13 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:27:13 --> Controller Class Initialized
DEBUG - 2020-10-22 03:27:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2020-10-22 03:27:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-22 03:27:13 --> Final output sent to browser
DEBUG - 2020-10-22 03:27:13 --> Total execution time: 0.2958
INFO - 2020-10-22 03:27:15 --> Config Class Initialized
INFO - 2020-10-22 03:27:15 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:27:15 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:27:15 --> Utf8 Class Initialized
INFO - 2020-10-22 03:27:15 --> URI Class Initialized
INFO - 2020-10-22 03:27:15 --> Router Class Initialized
INFO - 2020-10-22 03:27:15 --> Output Class Initialized
INFO - 2020-10-22 03:27:15 --> Security Class Initialized
DEBUG - 2020-10-22 03:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:27:15 --> Input Class Initialized
INFO - 2020-10-22 03:27:15 --> Language Class Initialized
INFO - 2020-10-22 03:27:15 --> Language Class Initialized
INFO - 2020-10-22 03:27:15 --> Config Class Initialized
INFO - 2020-10-22 03:27:15 --> Loader Class Initialized
INFO - 2020-10-22 03:27:15 --> Helper loaded: url_helper
INFO - 2020-10-22 03:27:15 --> Helper loaded: file_helper
INFO - 2020-10-22 03:27:15 --> Helper loaded: form_helper
INFO - 2020-10-22 03:27:15 --> Helper loaded: my_helper
INFO - 2020-10-22 03:27:15 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:27:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:27:16 --> Controller Class Initialized
DEBUG - 2020-10-22 03:27:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-10-22 03:27:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-22 03:27:16 --> Final output sent to browser
DEBUG - 2020-10-22 03:27:16 --> Total execution time: 0.2624
INFO - 2020-10-22 03:27:22 --> Config Class Initialized
INFO - 2020-10-22 03:27:22 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:27:22 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:27:22 --> Utf8 Class Initialized
INFO - 2020-10-22 03:27:22 --> URI Class Initialized
INFO - 2020-10-22 03:27:22 --> Router Class Initialized
INFO - 2020-10-22 03:27:22 --> Output Class Initialized
INFO - 2020-10-22 03:27:22 --> Security Class Initialized
DEBUG - 2020-10-22 03:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:27:22 --> Input Class Initialized
INFO - 2020-10-22 03:27:22 --> Language Class Initialized
INFO - 2020-10-22 03:27:22 --> Language Class Initialized
INFO - 2020-10-22 03:27:22 --> Config Class Initialized
INFO - 2020-10-22 03:27:22 --> Loader Class Initialized
INFO - 2020-10-22 03:27:22 --> Helper loaded: url_helper
INFO - 2020-10-22 03:27:22 --> Helper loaded: file_helper
INFO - 2020-10-22 03:27:22 --> Helper loaded: form_helper
INFO - 2020-10-22 03:27:22 --> Helper loaded: my_helper
INFO - 2020-10-22 03:27:22 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:27:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:27:22 --> Controller Class Initialized
INFO - 2020-10-22 03:27:22 --> Helper loaded: cookie_helper
INFO - 2020-10-22 03:27:22 --> Config Class Initialized
INFO - 2020-10-22 03:27:22 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:27:22 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:27:22 --> Utf8 Class Initialized
INFO - 2020-10-22 03:27:22 --> URI Class Initialized
INFO - 2020-10-22 03:27:22 --> Router Class Initialized
INFO - 2020-10-22 03:27:22 --> Output Class Initialized
INFO - 2020-10-22 03:27:22 --> Security Class Initialized
DEBUG - 2020-10-22 03:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:27:22 --> Input Class Initialized
INFO - 2020-10-22 03:27:22 --> Language Class Initialized
INFO - 2020-10-22 03:27:22 --> Language Class Initialized
INFO - 2020-10-22 03:27:22 --> Config Class Initialized
INFO - 2020-10-22 03:27:22 --> Loader Class Initialized
INFO - 2020-10-22 03:27:22 --> Helper loaded: url_helper
INFO - 2020-10-22 03:27:22 --> Helper loaded: file_helper
INFO - 2020-10-22 03:27:22 --> Helper loaded: form_helper
INFO - 2020-10-22 03:27:22 --> Helper loaded: my_helper
INFO - 2020-10-22 03:27:22 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:27:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:27:22 --> Controller Class Initialized
DEBUG - 2020-10-22 03:27:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-22 03:27:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-22 03:27:22 --> Final output sent to browser
DEBUG - 2020-10-22 03:27:22 --> Total execution time: 0.1984
INFO - 2020-10-22 03:49:21 --> Config Class Initialized
INFO - 2020-10-22 03:49:21 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:49:21 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:49:21 --> Utf8 Class Initialized
INFO - 2020-10-22 03:49:21 --> URI Class Initialized
INFO - 2020-10-22 03:49:21 --> Router Class Initialized
INFO - 2020-10-22 03:49:21 --> Output Class Initialized
INFO - 2020-10-22 03:49:21 --> Security Class Initialized
DEBUG - 2020-10-22 03:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:49:21 --> Input Class Initialized
INFO - 2020-10-22 03:49:21 --> Language Class Initialized
INFO - 2020-10-22 03:49:21 --> Language Class Initialized
INFO - 2020-10-22 03:49:21 --> Config Class Initialized
INFO - 2020-10-22 03:49:21 --> Loader Class Initialized
INFO - 2020-10-22 03:49:21 --> Helper loaded: url_helper
INFO - 2020-10-22 03:49:21 --> Helper loaded: file_helper
INFO - 2020-10-22 03:49:21 --> Helper loaded: form_helper
INFO - 2020-10-22 03:49:21 --> Helper loaded: my_helper
INFO - 2020-10-22 03:49:21 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:49:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:49:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:49:21 --> Controller Class Initialized
ERROR - 2020-10-22 03:49:21 --> Severity: Parsing Error --> syntax error, unexpected '}', expecting ']' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_rapot.php 62
INFO - 2020-10-22 03:49:24 --> Config Class Initialized
INFO - 2020-10-22 03:49:24 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:49:24 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:49:24 --> Utf8 Class Initialized
INFO - 2020-10-22 03:49:24 --> URI Class Initialized
INFO - 2020-10-22 03:49:24 --> Router Class Initialized
INFO - 2020-10-22 03:49:24 --> Output Class Initialized
INFO - 2020-10-22 03:49:24 --> Security Class Initialized
DEBUG - 2020-10-22 03:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:49:24 --> Input Class Initialized
INFO - 2020-10-22 03:49:24 --> Language Class Initialized
INFO - 2020-10-22 03:49:24 --> Language Class Initialized
INFO - 2020-10-22 03:49:24 --> Config Class Initialized
INFO - 2020-10-22 03:49:24 --> Loader Class Initialized
INFO - 2020-10-22 03:49:24 --> Helper loaded: url_helper
INFO - 2020-10-22 03:49:24 --> Helper loaded: file_helper
INFO - 2020-10-22 03:49:24 --> Helper loaded: form_helper
INFO - 2020-10-22 03:49:24 --> Helper loaded: my_helper
INFO - 2020-10-22 03:49:24 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:49:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:49:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:49:24 --> Controller Class Initialized
ERROR - 2020-10-22 03:49:24 --> Severity: Parsing Error --> syntax error, unexpected '}', expecting ']' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_rapot.php 62
INFO - 2020-10-22 03:53:01 --> Config Class Initialized
INFO - 2020-10-22 03:53:01 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:53:01 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:53:01 --> Utf8 Class Initialized
INFO - 2020-10-22 03:53:01 --> URI Class Initialized
INFO - 2020-10-22 03:53:01 --> Router Class Initialized
INFO - 2020-10-22 03:53:01 --> Output Class Initialized
INFO - 2020-10-22 03:53:01 --> Security Class Initialized
DEBUG - 2020-10-22 03:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:53:01 --> Input Class Initialized
INFO - 2020-10-22 03:53:01 --> Language Class Initialized
INFO - 2020-10-22 03:53:01 --> Language Class Initialized
INFO - 2020-10-22 03:53:01 --> Config Class Initialized
INFO - 2020-10-22 03:53:01 --> Loader Class Initialized
INFO - 2020-10-22 03:53:01 --> Helper loaded: url_helper
INFO - 2020-10-22 03:53:01 --> Helper loaded: file_helper
INFO - 2020-10-22 03:53:01 --> Helper loaded: form_helper
INFO - 2020-10-22 03:53:01 --> Helper loaded: my_helper
INFO - 2020-10-22 03:53:01 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:53:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:53:01 --> Controller Class Initialized
ERROR - 2020-10-22 03:53:01 --> Severity: Parsing Error --> syntax error, unexpected '}', expecting ']' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_rapot.php 62
INFO - 2020-10-22 03:53:32 --> Config Class Initialized
INFO - 2020-10-22 03:53:32 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:53:32 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:53:32 --> Utf8 Class Initialized
INFO - 2020-10-22 03:53:32 --> URI Class Initialized
INFO - 2020-10-22 03:53:32 --> Router Class Initialized
INFO - 2020-10-22 03:53:32 --> Output Class Initialized
INFO - 2020-10-22 03:53:32 --> Security Class Initialized
DEBUG - 2020-10-22 03:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:53:32 --> Input Class Initialized
INFO - 2020-10-22 03:53:32 --> Language Class Initialized
INFO - 2020-10-22 03:53:32 --> Language Class Initialized
INFO - 2020-10-22 03:53:32 --> Config Class Initialized
INFO - 2020-10-22 03:53:32 --> Loader Class Initialized
INFO - 2020-10-22 03:53:33 --> Helper loaded: url_helper
INFO - 2020-10-22 03:53:33 --> Helper loaded: file_helper
INFO - 2020-10-22 03:53:33 --> Helper loaded: form_helper
INFO - 2020-10-22 03:53:33 --> Helper loaded: my_helper
INFO - 2020-10-22 03:53:33 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:53:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:53:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:53:33 --> Controller Class Initialized
ERROR - 2020-10-22 03:53:33 --> Severity: Notice --> Undefined variable: kelompok C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_rapot.php 57
ERROR - 2020-10-22 03:53:33 --> Severity: Notice --> Undefined variable: kd_singkat C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_rapot.php 62
DEBUG - 2020-10-22 03:53:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-10-22 03:53:33 --> Final output sent to browser
DEBUG - 2020-10-22 03:53:33 --> Total execution time: 0.2355
INFO - 2020-10-22 03:54:04 --> Config Class Initialized
INFO - 2020-10-22 03:54:04 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:54:04 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:54:04 --> Utf8 Class Initialized
INFO - 2020-10-22 03:54:04 --> URI Class Initialized
INFO - 2020-10-22 03:54:04 --> Router Class Initialized
INFO - 2020-10-22 03:54:04 --> Output Class Initialized
INFO - 2020-10-22 03:54:04 --> Security Class Initialized
DEBUG - 2020-10-22 03:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:54:05 --> Input Class Initialized
INFO - 2020-10-22 03:54:05 --> Language Class Initialized
INFO - 2020-10-22 03:54:05 --> Language Class Initialized
INFO - 2020-10-22 03:54:05 --> Config Class Initialized
INFO - 2020-10-22 03:54:05 --> Loader Class Initialized
INFO - 2020-10-22 03:54:05 --> Helper loaded: url_helper
INFO - 2020-10-22 03:54:05 --> Helper loaded: file_helper
INFO - 2020-10-22 03:54:05 --> Helper loaded: form_helper
INFO - 2020-10-22 03:54:05 --> Helper loaded: my_helper
INFO - 2020-10-22 03:54:05 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:54:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:54:05 --> Controller Class Initialized
ERROR - 2020-10-22 03:54:05 --> Severity: Notice --> Undefined property: MX_Config::$item C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_rapot.php 57
ERROR - 2020-10-22 03:54:05 --> Severity: Notice --> Undefined property: MX_Config::$item C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_rapot.php 62
DEBUG - 2020-10-22 03:54:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-10-22 03:54:05 --> Final output sent to browser
DEBUG - 2020-10-22 03:54:05 --> Total execution time: 0.2525
INFO - 2020-10-22 03:54:41 --> Config Class Initialized
INFO - 2020-10-22 03:54:41 --> Hooks Class Initialized
DEBUG - 2020-10-22 03:54:41 --> UTF-8 Support Enabled
INFO - 2020-10-22 03:54:41 --> Utf8 Class Initialized
INFO - 2020-10-22 03:54:41 --> URI Class Initialized
INFO - 2020-10-22 03:54:41 --> Router Class Initialized
INFO - 2020-10-22 03:54:41 --> Output Class Initialized
INFO - 2020-10-22 03:54:41 --> Security Class Initialized
DEBUG - 2020-10-22 03:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 03:54:41 --> Input Class Initialized
INFO - 2020-10-22 03:54:41 --> Language Class Initialized
INFO - 2020-10-22 03:54:41 --> Language Class Initialized
INFO - 2020-10-22 03:54:41 --> Config Class Initialized
INFO - 2020-10-22 03:54:41 --> Loader Class Initialized
INFO - 2020-10-22 03:54:41 --> Helper loaded: url_helper
INFO - 2020-10-22 03:54:41 --> Helper loaded: file_helper
INFO - 2020-10-22 03:54:42 --> Helper loaded: form_helper
INFO - 2020-10-22 03:54:42 --> Helper loaded: my_helper
INFO - 2020-10-22 03:54:42 --> Database Driver Class Initialized
DEBUG - 2020-10-22 03:54:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 03:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 03:54:42 --> Controller Class Initialized
ERROR - 2020-10-22 03:54:42 --> Severity: Notice --> Undefined index: kelompok C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_rapot.php 57
ERROR - 2020-10-22 03:54:42 --> Severity: Notice --> Undefined index: kd_singkat C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_rapot.php 62
DEBUG - 2020-10-22 03:54:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-10-22 03:54:42 --> Final output sent to browser
DEBUG - 2020-10-22 03:54:42 --> Total execution time: 0.2522
INFO - 2020-10-22 04:06:30 --> Config Class Initialized
INFO - 2020-10-22 04:06:30 --> Hooks Class Initialized
DEBUG - 2020-10-22 04:06:30 --> UTF-8 Support Enabled
INFO - 2020-10-22 04:06:30 --> Utf8 Class Initialized
INFO - 2020-10-22 04:06:30 --> URI Class Initialized
INFO - 2020-10-22 04:06:30 --> Router Class Initialized
INFO - 2020-10-22 04:06:30 --> Output Class Initialized
INFO - 2020-10-22 04:06:30 --> Security Class Initialized
DEBUG - 2020-10-22 04:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 04:06:30 --> Input Class Initialized
INFO - 2020-10-22 04:06:30 --> Language Class Initialized
INFO - 2020-10-22 04:06:30 --> Language Class Initialized
INFO - 2020-10-22 04:06:30 --> Config Class Initialized
INFO - 2020-10-22 04:06:30 --> Loader Class Initialized
INFO - 2020-10-22 04:06:30 --> Helper loaded: url_helper
INFO - 2020-10-22 04:06:30 --> Helper loaded: file_helper
INFO - 2020-10-22 04:06:30 --> Helper loaded: form_helper
INFO - 2020-10-22 04:06:30 --> Helper loaded: my_helper
INFO - 2020-10-22 04:06:30 --> Database Driver Class Initialized
DEBUG - 2020-10-22 04:06:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 04:06:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 04:06:30 --> Controller Class Initialized
DEBUG - 2020-10-22 04:06:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-22 04:06:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-22 04:06:30 --> Final output sent to browser
DEBUG - 2020-10-22 04:06:30 --> Total execution time: 0.2004
INFO - 2020-10-22 04:07:30 --> Config Class Initialized
INFO - 2020-10-22 04:07:30 --> Hooks Class Initialized
DEBUG - 2020-10-22 04:07:30 --> UTF-8 Support Enabled
INFO - 2020-10-22 04:07:30 --> Utf8 Class Initialized
INFO - 2020-10-22 04:07:30 --> URI Class Initialized
INFO - 2020-10-22 04:07:30 --> Router Class Initialized
INFO - 2020-10-22 04:07:30 --> Output Class Initialized
INFO - 2020-10-22 04:07:30 --> Security Class Initialized
DEBUG - 2020-10-22 04:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 04:07:30 --> Input Class Initialized
INFO - 2020-10-22 04:07:30 --> Language Class Initialized
INFO - 2020-10-22 04:07:31 --> Language Class Initialized
INFO - 2020-10-22 04:07:31 --> Config Class Initialized
INFO - 2020-10-22 04:07:31 --> Loader Class Initialized
INFO - 2020-10-22 04:07:31 --> Helper loaded: url_helper
INFO - 2020-10-22 04:07:31 --> Helper loaded: file_helper
INFO - 2020-10-22 04:07:31 --> Helper loaded: form_helper
INFO - 2020-10-22 04:07:31 --> Helper loaded: my_helper
INFO - 2020-10-22 04:07:31 --> Database Driver Class Initialized
DEBUG - 2020-10-22 04:07:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 04:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 04:07:31 --> Controller Class Initialized
DEBUG - 2020-10-22 04:07:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-22 04:07:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-22 04:07:31 --> Final output sent to browser
DEBUG - 2020-10-22 04:07:31 --> Total execution time: 0.2146
INFO - 2020-10-22 04:07:53 --> Config Class Initialized
INFO - 2020-10-22 04:07:53 --> Hooks Class Initialized
DEBUG - 2020-10-22 04:07:53 --> UTF-8 Support Enabled
INFO - 2020-10-22 04:07:53 --> Utf8 Class Initialized
INFO - 2020-10-22 04:07:53 --> URI Class Initialized
INFO - 2020-10-22 04:07:53 --> Router Class Initialized
INFO - 2020-10-22 04:07:53 --> Output Class Initialized
INFO - 2020-10-22 04:07:53 --> Security Class Initialized
DEBUG - 2020-10-22 04:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 04:07:53 --> Input Class Initialized
INFO - 2020-10-22 04:07:53 --> Language Class Initialized
INFO - 2020-10-22 04:07:53 --> Language Class Initialized
INFO - 2020-10-22 04:07:53 --> Config Class Initialized
INFO - 2020-10-22 04:07:53 --> Loader Class Initialized
INFO - 2020-10-22 04:07:53 --> Helper loaded: url_helper
INFO - 2020-10-22 04:07:53 --> Helper loaded: file_helper
INFO - 2020-10-22 04:07:53 --> Helper loaded: form_helper
INFO - 2020-10-22 04:07:53 --> Helper loaded: my_helper
INFO - 2020-10-22 04:07:53 --> Database Driver Class Initialized
DEBUG - 2020-10-22 04:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 04:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 04:07:53 --> Controller Class Initialized
DEBUG - 2020-10-22 04:07:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-22 04:07:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-22 04:07:53 --> Final output sent to browser
DEBUG - 2020-10-22 04:07:53 --> Total execution time: 0.2137
INFO - 2020-10-22 04:09:53 --> Config Class Initialized
INFO - 2020-10-22 04:09:53 --> Hooks Class Initialized
DEBUG - 2020-10-22 04:09:53 --> UTF-8 Support Enabled
INFO - 2020-10-22 04:09:53 --> Utf8 Class Initialized
INFO - 2020-10-22 04:09:53 --> URI Class Initialized
INFO - 2020-10-22 04:09:53 --> Router Class Initialized
INFO - 2020-10-22 04:09:53 --> Output Class Initialized
INFO - 2020-10-22 04:09:53 --> Security Class Initialized
DEBUG - 2020-10-22 04:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 04:09:53 --> Input Class Initialized
INFO - 2020-10-22 04:09:53 --> Language Class Initialized
INFO - 2020-10-22 04:09:53 --> Language Class Initialized
INFO - 2020-10-22 04:09:53 --> Config Class Initialized
INFO - 2020-10-22 04:09:53 --> Loader Class Initialized
INFO - 2020-10-22 04:09:53 --> Helper loaded: url_helper
INFO - 2020-10-22 04:09:53 --> Helper loaded: file_helper
INFO - 2020-10-22 04:09:53 --> Helper loaded: form_helper
INFO - 2020-10-22 04:09:53 --> Helper loaded: my_helper
INFO - 2020-10-22 04:09:53 --> Database Driver Class Initialized
DEBUG - 2020-10-22 04:09:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 04:09:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 04:09:53 --> Controller Class Initialized
DEBUG - 2020-10-22 04:09:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-22 04:09:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-22 04:09:53 --> Final output sent to browser
DEBUG - 2020-10-22 04:09:53 --> Total execution time: 0.2467
INFO - 2020-10-22 04:09:59 --> Config Class Initialized
INFO - 2020-10-22 04:09:59 --> Hooks Class Initialized
DEBUG - 2020-10-22 04:09:59 --> UTF-8 Support Enabled
INFO - 2020-10-22 04:09:59 --> Utf8 Class Initialized
INFO - 2020-10-22 04:09:59 --> URI Class Initialized
INFO - 2020-10-22 04:09:59 --> Router Class Initialized
INFO - 2020-10-22 04:09:59 --> Output Class Initialized
INFO - 2020-10-22 04:09:59 --> Security Class Initialized
DEBUG - 2020-10-22 04:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 04:09:59 --> Input Class Initialized
INFO - 2020-10-22 04:09:59 --> Language Class Initialized
INFO - 2020-10-22 04:09:59 --> Language Class Initialized
INFO - 2020-10-22 04:09:59 --> Config Class Initialized
INFO - 2020-10-22 04:09:59 --> Loader Class Initialized
INFO - 2020-10-22 04:09:59 --> Helper loaded: url_helper
INFO - 2020-10-22 04:09:59 --> Helper loaded: file_helper
INFO - 2020-10-22 04:09:59 --> Helper loaded: form_helper
INFO - 2020-10-22 04:09:59 --> Helper loaded: my_helper
INFO - 2020-10-22 04:09:59 --> Database Driver Class Initialized
DEBUG - 2020-10-22 04:09:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 04:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 04:09:59 --> Controller Class Initialized
DEBUG - 2020-10-22 04:09:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-22 04:09:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-22 04:09:59 --> Final output sent to browser
DEBUG - 2020-10-22 04:09:59 --> Total execution time: 0.2251
INFO - 2020-10-22 04:10:00 --> Config Class Initialized
INFO - 2020-10-22 04:10:00 --> Hooks Class Initialized
DEBUG - 2020-10-22 04:10:00 --> UTF-8 Support Enabled
INFO - 2020-10-22 04:10:00 --> Utf8 Class Initialized
INFO - 2020-10-22 04:10:00 --> URI Class Initialized
INFO - 2020-10-22 04:10:00 --> Router Class Initialized
INFO - 2020-10-22 04:10:00 --> Output Class Initialized
INFO - 2020-10-22 04:10:00 --> Security Class Initialized
DEBUG - 2020-10-22 04:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 04:10:00 --> Input Class Initialized
INFO - 2020-10-22 04:10:00 --> Language Class Initialized
INFO - 2020-10-22 04:10:00 --> Language Class Initialized
INFO - 2020-10-22 04:10:00 --> Config Class Initialized
INFO - 2020-10-22 04:10:00 --> Loader Class Initialized
INFO - 2020-10-22 04:10:00 --> Helper loaded: url_helper
INFO - 2020-10-22 04:10:00 --> Helper loaded: file_helper
INFO - 2020-10-22 04:10:00 --> Helper loaded: form_helper
INFO - 2020-10-22 04:10:00 --> Helper loaded: my_helper
INFO - 2020-10-22 04:10:00 --> Database Driver Class Initialized
DEBUG - 2020-10-22 04:10:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 04:10:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 04:10:00 --> Controller Class Initialized
DEBUG - 2020-10-22 04:10:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-22 04:10:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-22 04:10:00 --> Final output sent to browser
DEBUG - 2020-10-22 04:10:00 --> Total execution time: 0.2106
INFO - 2020-10-22 04:10:12 --> Config Class Initialized
INFO - 2020-10-22 04:10:12 --> Hooks Class Initialized
DEBUG - 2020-10-22 04:10:12 --> UTF-8 Support Enabled
INFO - 2020-10-22 04:10:12 --> Utf8 Class Initialized
INFO - 2020-10-22 04:10:12 --> URI Class Initialized
INFO - 2020-10-22 04:10:12 --> Router Class Initialized
INFO - 2020-10-22 04:10:12 --> Output Class Initialized
INFO - 2020-10-22 04:10:12 --> Security Class Initialized
DEBUG - 2020-10-22 04:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 04:10:12 --> Input Class Initialized
INFO - 2020-10-22 04:10:12 --> Language Class Initialized
INFO - 2020-10-22 04:10:12 --> Language Class Initialized
INFO - 2020-10-22 04:10:13 --> Config Class Initialized
INFO - 2020-10-22 04:10:13 --> Loader Class Initialized
INFO - 2020-10-22 04:10:13 --> Helper loaded: url_helper
INFO - 2020-10-22 04:10:13 --> Helper loaded: file_helper
INFO - 2020-10-22 04:10:13 --> Helper loaded: form_helper
INFO - 2020-10-22 04:10:13 --> Helper loaded: my_helper
INFO - 2020-10-22 04:10:13 --> Database Driver Class Initialized
DEBUG - 2020-10-22 04:10:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 04:10:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 04:10:13 --> Controller Class Initialized
DEBUG - 2020-10-22 04:10:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-22 04:10:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-22 04:10:13 --> Final output sent to browser
DEBUG - 2020-10-22 04:10:13 --> Total execution time: 0.2668
INFO - 2020-10-22 04:10:20 --> Config Class Initialized
INFO - 2020-10-22 04:10:20 --> Hooks Class Initialized
DEBUG - 2020-10-22 04:10:20 --> UTF-8 Support Enabled
INFO - 2020-10-22 04:10:20 --> Utf8 Class Initialized
INFO - 2020-10-22 04:10:20 --> URI Class Initialized
INFO - 2020-10-22 04:10:20 --> Router Class Initialized
INFO - 2020-10-22 04:10:20 --> Output Class Initialized
INFO - 2020-10-22 04:10:20 --> Security Class Initialized
DEBUG - 2020-10-22 04:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 04:10:20 --> Input Class Initialized
INFO - 2020-10-22 04:10:20 --> Language Class Initialized
INFO - 2020-10-22 04:10:20 --> Language Class Initialized
INFO - 2020-10-22 04:10:20 --> Config Class Initialized
INFO - 2020-10-22 04:10:20 --> Loader Class Initialized
INFO - 2020-10-22 04:10:20 --> Helper loaded: url_helper
INFO - 2020-10-22 04:10:20 --> Helper loaded: file_helper
INFO - 2020-10-22 04:10:20 --> Helper loaded: form_helper
INFO - 2020-10-22 04:10:20 --> Helper loaded: my_helper
INFO - 2020-10-22 04:10:20 --> Database Driver Class Initialized
DEBUG - 2020-10-22 04:10:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 04:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 04:10:20 --> Controller Class Initialized
DEBUG - 2020-10-22 04:10:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-22 04:10:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-22 04:10:20 --> Final output sent to browser
DEBUG - 2020-10-22 04:10:20 --> Total execution time: 0.2280
INFO - 2020-10-22 04:10:47 --> Config Class Initialized
INFO - 2020-10-22 04:10:47 --> Hooks Class Initialized
DEBUG - 2020-10-22 04:10:47 --> UTF-8 Support Enabled
INFO - 2020-10-22 04:10:47 --> Utf8 Class Initialized
INFO - 2020-10-22 04:10:47 --> URI Class Initialized
INFO - 2020-10-22 04:10:47 --> Router Class Initialized
INFO - 2020-10-22 04:10:47 --> Output Class Initialized
INFO - 2020-10-22 04:10:47 --> Security Class Initialized
DEBUG - 2020-10-22 04:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 04:10:47 --> Input Class Initialized
INFO - 2020-10-22 04:10:47 --> Language Class Initialized
INFO - 2020-10-22 04:10:47 --> Language Class Initialized
INFO - 2020-10-22 04:10:47 --> Config Class Initialized
INFO - 2020-10-22 04:10:47 --> Loader Class Initialized
INFO - 2020-10-22 04:10:47 --> Helper loaded: url_helper
INFO - 2020-10-22 04:10:47 --> Helper loaded: file_helper
INFO - 2020-10-22 04:10:47 --> Helper loaded: form_helper
INFO - 2020-10-22 04:10:47 --> Helper loaded: my_helper
INFO - 2020-10-22 04:10:47 --> Database Driver Class Initialized
DEBUG - 2020-10-22 04:10:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 04:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 04:10:47 --> Controller Class Initialized
DEBUG - 2020-10-22 04:10:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-22 04:10:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-22 04:10:47 --> Final output sent to browser
DEBUG - 2020-10-22 04:10:47 --> Total execution time: 0.2510
INFO - 2020-10-22 04:10:58 --> Config Class Initialized
INFO - 2020-10-22 04:10:58 --> Hooks Class Initialized
DEBUG - 2020-10-22 04:10:58 --> UTF-8 Support Enabled
INFO - 2020-10-22 04:10:58 --> Utf8 Class Initialized
INFO - 2020-10-22 04:10:58 --> URI Class Initialized
INFO - 2020-10-22 04:10:58 --> Router Class Initialized
INFO - 2020-10-22 04:10:58 --> Output Class Initialized
INFO - 2020-10-22 04:10:58 --> Security Class Initialized
DEBUG - 2020-10-22 04:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 04:10:59 --> Input Class Initialized
INFO - 2020-10-22 04:10:59 --> Language Class Initialized
INFO - 2020-10-22 04:10:59 --> Language Class Initialized
INFO - 2020-10-22 04:10:59 --> Config Class Initialized
INFO - 2020-10-22 04:10:59 --> Loader Class Initialized
INFO - 2020-10-22 04:10:59 --> Helper loaded: url_helper
INFO - 2020-10-22 04:10:59 --> Helper loaded: file_helper
INFO - 2020-10-22 04:10:59 --> Helper loaded: form_helper
INFO - 2020-10-22 04:10:59 --> Helper loaded: my_helper
INFO - 2020-10-22 04:10:59 --> Database Driver Class Initialized
DEBUG - 2020-10-22 04:10:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 04:10:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 04:10:59 --> Controller Class Initialized
DEBUG - 2020-10-22 04:10:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-22 04:10:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-22 04:10:59 --> Final output sent to browser
DEBUG - 2020-10-22 04:10:59 --> Total execution time: 0.2637
INFO - 2020-10-22 04:11:13 --> Config Class Initialized
INFO - 2020-10-22 04:11:13 --> Hooks Class Initialized
DEBUG - 2020-10-22 04:11:13 --> UTF-8 Support Enabled
INFO - 2020-10-22 04:11:13 --> Utf8 Class Initialized
INFO - 2020-10-22 04:11:13 --> URI Class Initialized
INFO - 2020-10-22 04:11:13 --> Router Class Initialized
INFO - 2020-10-22 04:11:13 --> Output Class Initialized
INFO - 2020-10-22 04:11:13 --> Security Class Initialized
DEBUG - 2020-10-22 04:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 04:11:13 --> Input Class Initialized
INFO - 2020-10-22 04:11:13 --> Language Class Initialized
INFO - 2020-10-22 04:11:13 --> Language Class Initialized
INFO - 2020-10-22 04:11:13 --> Config Class Initialized
INFO - 2020-10-22 04:11:13 --> Loader Class Initialized
INFO - 2020-10-22 04:11:13 --> Helper loaded: url_helper
INFO - 2020-10-22 04:11:13 --> Helper loaded: file_helper
INFO - 2020-10-22 04:11:13 --> Helper loaded: form_helper
INFO - 2020-10-22 04:11:13 --> Helper loaded: my_helper
INFO - 2020-10-22 04:11:13 --> Database Driver Class Initialized
DEBUG - 2020-10-22 04:11:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 04:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 04:11:13 --> Controller Class Initialized
DEBUG - 2020-10-22 04:11:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-22 04:11:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-22 04:11:13 --> Final output sent to browser
DEBUG - 2020-10-22 04:11:13 --> Total execution time: 0.2939
INFO - 2020-10-22 04:15:50 --> Config Class Initialized
INFO - 2020-10-22 04:15:50 --> Hooks Class Initialized
DEBUG - 2020-10-22 04:15:50 --> UTF-8 Support Enabled
INFO - 2020-10-22 04:15:50 --> Utf8 Class Initialized
INFO - 2020-10-22 04:15:50 --> URI Class Initialized
INFO - 2020-10-22 04:15:50 --> Router Class Initialized
INFO - 2020-10-22 04:15:50 --> Output Class Initialized
INFO - 2020-10-22 04:15:50 --> Security Class Initialized
DEBUG - 2020-10-22 04:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 04:15:50 --> Input Class Initialized
INFO - 2020-10-22 04:15:50 --> Language Class Initialized
INFO - 2020-10-22 04:15:50 --> Language Class Initialized
INFO - 2020-10-22 04:15:50 --> Config Class Initialized
INFO - 2020-10-22 04:15:50 --> Loader Class Initialized
INFO - 2020-10-22 04:15:50 --> Helper loaded: url_helper
INFO - 2020-10-22 04:15:50 --> Helper loaded: file_helper
INFO - 2020-10-22 04:15:50 --> Helper loaded: form_helper
INFO - 2020-10-22 04:15:50 --> Helper loaded: my_helper
INFO - 2020-10-22 04:15:50 --> Database Driver Class Initialized
DEBUG - 2020-10-22 04:15:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 04:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 04:15:50 --> Controller Class Initialized
DEBUG - 2020-10-22 04:15:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-22 04:15:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-22 04:15:50 --> Final output sent to browser
DEBUG - 2020-10-22 04:15:50 --> Total execution time: 0.2220
INFO - 2020-10-22 04:15:57 --> Config Class Initialized
INFO - 2020-10-22 04:15:57 --> Hooks Class Initialized
DEBUG - 2020-10-22 04:15:57 --> UTF-8 Support Enabled
INFO - 2020-10-22 04:15:57 --> Utf8 Class Initialized
INFO - 2020-10-22 04:15:57 --> URI Class Initialized
INFO - 2020-10-22 04:15:57 --> Router Class Initialized
INFO - 2020-10-22 04:15:57 --> Output Class Initialized
INFO - 2020-10-22 04:15:57 --> Security Class Initialized
DEBUG - 2020-10-22 04:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 04:15:57 --> Input Class Initialized
INFO - 2020-10-22 04:15:57 --> Language Class Initialized
INFO - 2020-10-22 04:15:57 --> Language Class Initialized
INFO - 2020-10-22 04:15:57 --> Config Class Initialized
INFO - 2020-10-22 04:15:58 --> Loader Class Initialized
INFO - 2020-10-22 04:15:58 --> Helper loaded: url_helper
INFO - 2020-10-22 04:15:58 --> Helper loaded: file_helper
INFO - 2020-10-22 04:15:58 --> Helper loaded: form_helper
INFO - 2020-10-22 04:15:58 --> Helper loaded: my_helper
INFO - 2020-10-22 04:15:58 --> Database Driver Class Initialized
DEBUG - 2020-10-22 04:15:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 04:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 04:15:58 --> Controller Class Initialized
DEBUG - 2020-10-22 04:15:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-22 04:15:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-22 04:15:58 --> Final output sent to browser
DEBUG - 2020-10-22 04:15:58 --> Total execution time: 0.2247
INFO - 2020-10-22 04:17:44 --> Config Class Initialized
INFO - 2020-10-22 04:17:44 --> Hooks Class Initialized
DEBUG - 2020-10-22 04:17:44 --> UTF-8 Support Enabled
INFO - 2020-10-22 04:17:44 --> Utf8 Class Initialized
INFO - 2020-10-22 04:17:44 --> URI Class Initialized
INFO - 2020-10-22 04:17:44 --> Router Class Initialized
INFO - 2020-10-22 04:17:44 --> Output Class Initialized
INFO - 2020-10-22 04:17:44 --> Security Class Initialized
DEBUG - 2020-10-22 04:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 04:17:44 --> Input Class Initialized
INFO - 2020-10-22 04:17:44 --> Language Class Initialized
INFO - 2020-10-22 04:17:44 --> Language Class Initialized
INFO - 2020-10-22 04:17:44 --> Config Class Initialized
INFO - 2020-10-22 04:17:44 --> Loader Class Initialized
INFO - 2020-10-22 04:17:44 --> Helper loaded: url_helper
INFO - 2020-10-22 04:17:44 --> Helper loaded: file_helper
INFO - 2020-10-22 04:17:44 --> Helper loaded: form_helper
INFO - 2020-10-22 04:17:44 --> Helper loaded: my_helper
INFO - 2020-10-22 04:17:44 --> Database Driver Class Initialized
DEBUG - 2020-10-22 04:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 04:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 04:17:44 --> Controller Class Initialized
DEBUG - 2020-10-22 04:17:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-22 04:17:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-22 04:17:44 --> Final output sent to browser
DEBUG - 2020-10-22 04:17:44 --> Total execution time: 0.2496
INFO - 2020-10-22 04:17:45 --> Config Class Initialized
INFO - 2020-10-22 04:17:45 --> Hooks Class Initialized
DEBUG - 2020-10-22 04:17:45 --> UTF-8 Support Enabled
INFO - 2020-10-22 04:17:45 --> Utf8 Class Initialized
INFO - 2020-10-22 04:17:45 --> URI Class Initialized
INFO - 2020-10-22 04:17:45 --> Router Class Initialized
INFO - 2020-10-22 04:17:45 --> Output Class Initialized
INFO - 2020-10-22 04:17:45 --> Security Class Initialized
DEBUG - 2020-10-22 04:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 04:17:45 --> Input Class Initialized
INFO - 2020-10-22 04:17:45 --> Language Class Initialized
INFO - 2020-10-22 04:17:45 --> Language Class Initialized
INFO - 2020-10-22 04:17:45 --> Config Class Initialized
INFO - 2020-10-22 04:17:45 --> Loader Class Initialized
INFO - 2020-10-22 04:17:45 --> Helper loaded: url_helper
INFO - 2020-10-22 04:17:45 --> Helper loaded: file_helper
INFO - 2020-10-22 04:17:45 --> Helper loaded: form_helper
INFO - 2020-10-22 04:17:45 --> Helper loaded: my_helper
INFO - 2020-10-22 04:17:45 --> Database Driver Class Initialized
DEBUG - 2020-10-22 04:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 04:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 04:17:45 --> Controller Class Initialized
DEBUG - 2020-10-22 04:17:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-22 04:17:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-22 04:17:45 --> Final output sent to browser
DEBUG - 2020-10-22 04:17:45 --> Total execution time: 0.2128
INFO - 2020-10-22 04:49:17 --> Config Class Initialized
INFO - 2020-10-22 04:49:17 --> Hooks Class Initialized
DEBUG - 2020-10-22 04:49:17 --> UTF-8 Support Enabled
INFO - 2020-10-22 04:49:17 --> Utf8 Class Initialized
INFO - 2020-10-22 04:49:17 --> URI Class Initialized
INFO - 2020-10-22 04:49:17 --> Router Class Initialized
INFO - 2020-10-22 04:49:17 --> Output Class Initialized
INFO - 2020-10-22 04:49:17 --> Security Class Initialized
DEBUG - 2020-10-22 04:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 04:49:17 --> Input Class Initialized
INFO - 2020-10-22 04:49:17 --> Language Class Initialized
INFO - 2020-10-22 04:49:17 --> Language Class Initialized
INFO - 2020-10-22 04:49:17 --> Config Class Initialized
INFO - 2020-10-22 04:49:17 --> Loader Class Initialized
INFO - 2020-10-22 04:49:17 --> Helper loaded: url_helper
INFO - 2020-10-22 04:49:17 --> Helper loaded: file_helper
INFO - 2020-10-22 04:49:17 --> Helper loaded: form_helper
INFO - 2020-10-22 04:49:17 --> Helper loaded: my_helper
INFO - 2020-10-22 04:49:17 --> Database Driver Class Initialized
DEBUG - 2020-10-22 04:49:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 04:49:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 04:49:17 --> Controller Class Initialized
DEBUG - 2020-10-22 04:49:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-22 04:49:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-22 04:49:17 --> Final output sent to browser
DEBUG - 2020-10-22 04:49:17 --> Total execution time: 0.2185
INFO - 2020-10-22 04:58:11 --> Config Class Initialized
INFO - 2020-10-22 04:58:11 --> Hooks Class Initialized
DEBUG - 2020-10-22 04:58:11 --> UTF-8 Support Enabled
INFO - 2020-10-22 04:58:11 --> Utf8 Class Initialized
INFO - 2020-10-22 04:58:11 --> URI Class Initialized
INFO - 2020-10-22 04:58:11 --> Router Class Initialized
INFO - 2020-10-22 04:58:11 --> Output Class Initialized
INFO - 2020-10-22 04:58:11 --> Security Class Initialized
DEBUG - 2020-10-22 04:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 04:58:11 --> Input Class Initialized
INFO - 2020-10-22 04:58:11 --> Language Class Initialized
INFO - 2020-10-22 04:58:11 --> Language Class Initialized
INFO - 2020-10-22 04:58:11 --> Config Class Initialized
INFO - 2020-10-22 04:58:11 --> Loader Class Initialized
INFO - 2020-10-22 04:58:11 --> Helper loaded: url_helper
INFO - 2020-10-22 04:58:11 --> Helper loaded: file_helper
INFO - 2020-10-22 04:58:11 --> Helper loaded: form_helper
INFO - 2020-10-22 04:58:11 --> Helper loaded: my_helper
INFO - 2020-10-22 04:58:11 --> Database Driver Class Initialized
DEBUG - 2020-10-22 04:58:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 04:58:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 04:58:11 --> Controller Class Initialized
DEBUG - 2020-10-22 04:58:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-22 04:58:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-22 04:58:11 --> Final output sent to browser
DEBUG - 2020-10-22 04:58:11 --> Total execution time: 0.2235
INFO - 2020-10-22 04:58:33 --> Config Class Initialized
INFO - 2020-10-22 04:58:33 --> Hooks Class Initialized
DEBUG - 2020-10-22 04:58:33 --> UTF-8 Support Enabled
INFO - 2020-10-22 04:58:33 --> Utf8 Class Initialized
INFO - 2020-10-22 04:58:33 --> URI Class Initialized
INFO - 2020-10-22 04:58:33 --> Router Class Initialized
INFO - 2020-10-22 04:58:33 --> Output Class Initialized
INFO - 2020-10-22 04:58:33 --> Security Class Initialized
DEBUG - 2020-10-22 04:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 04:58:33 --> Input Class Initialized
INFO - 2020-10-22 04:58:33 --> Language Class Initialized
INFO - 2020-10-22 04:58:33 --> Language Class Initialized
INFO - 2020-10-22 04:58:33 --> Config Class Initialized
INFO - 2020-10-22 04:58:33 --> Loader Class Initialized
INFO - 2020-10-22 04:58:33 --> Helper loaded: url_helper
INFO - 2020-10-22 04:58:33 --> Helper loaded: file_helper
INFO - 2020-10-22 04:58:33 --> Helper loaded: form_helper
INFO - 2020-10-22 04:58:33 --> Helper loaded: my_helper
INFO - 2020-10-22 04:58:33 --> Database Driver Class Initialized
DEBUG - 2020-10-22 04:58:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 04:58:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 04:58:33 --> Controller Class Initialized
DEBUG - 2020-10-22 04:58:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-22 04:58:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-22 04:58:33 --> Final output sent to browser
DEBUG - 2020-10-22 04:58:33 --> Total execution time: 0.2321
INFO - 2020-10-22 05:00:09 --> Config Class Initialized
INFO - 2020-10-22 05:00:09 --> Hooks Class Initialized
DEBUG - 2020-10-22 05:00:09 --> UTF-8 Support Enabled
INFO - 2020-10-22 05:00:09 --> Utf8 Class Initialized
INFO - 2020-10-22 05:00:09 --> URI Class Initialized
INFO - 2020-10-22 05:00:09 --> Router Class Initialized
INFO - 2020-10-22 05:00:09 --> Output Class Initialized
INFO - 2020-10-22 05:00:09 --> Security Class Initialized
DEBUG - 2020-10-22 05:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 05:00:09 --> Input Class Initialized
INFO - 2020-10-22 05:00:09 --> Language Class Initialized
INFO - 2020-10-22 05:00:09 --> Language Class Initialized
INFO - 2020-10-22 05:00:09 --> Config Class Initialized
INFO - 2020-10-22 05:00:09 --> Loader Class Initialized
INFO - 2020-10-22 05:00:09 --> Helper loaded: url_helper
INFO - 2020-10-22 05:00:09 --> Helper loaded: file_helper
INFO - 2020-10-22 05:00:09 --> Helper loaded: form_helper
INFO - 2020-10-22 05:00:09 --> Helper loaded: my_helper
INFO - 2020-10-22 05:00:09 --> Database Driver Class Initialized
DEBUG - 2020-10-22 05:00:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 05:00:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 05:00:09 --> Controller Class Initialized
DEBUG - 2020-10-22 05:00:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-22 05:00:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-22 05:00:09 --> Final output sent to browser
DEBUG - 2020-10-22 05:00:09 --> Total execution time: 0.2298
INFO - 2020-10-22 05:02:34 --> Config Class Initialized
INFO - 2020-10-22 05:02:34 --> Hooks Class Initialized
DEBUG - 2020-10-22 05:02:34 --> UTF-8 Support Enabled
INFO - 2020-10-22 05:02:34 --> Utf8 Class Initialized
INFO - 2020-10-22 05:02:34 --> URI Class Initialized
INFO - 2020-10-22 05:02:34 --> Router Class Initialized
INFO - 2020-10-22 05:02:34 --> Output Class Initialized
INFO - 2020-10-22 05:02:34 --> Security Class Initialized
DEBUG - 2020-10-22 05:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 05:02:34 --> Input Class Initialized
INFO - 2020-10-22 05:02:34 --> Language Class Initialized
INFO - 2020-10-22 05:02:34 --> Language Class Initialized
INFO - 2020-10-22 05:02:34 --> Config Class Initialized
INFO - 2020-10-22 05:02:34 --> Loader Class Initialized
INFO - 2020-10-22 05:02:34 --> Helper loaded: url_helper
INFO - 2020-10-22 05:02:34 --> Helper loaded: file_helper
INFO - 2020-10-22 05:02:34 --> Helper loaded: form_helper
INFO - 2020-10-22 05:02:34 --> Helper loaded: my_helper
INFO - 2020-10-22 05:02:34 --> Database Driver Class Initialized
DEBUG - 2020-10-22 05:02:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 05:02:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 05:02:34 --> Controller Class Initialized
DEBUG - 2020-10-22 05:02:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-22 05:02:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-22 05:02:34 --> Final output sent to browser
DEBUG - 2020-10-22 05:02:34 --> Total execution time: 0.2584
INFO - 2020-10-22 05:03:00 --> Config Class Initialized
INFO - 2020-10-22 05:03:00 --> Hooks Class Initialized
DEBUG - 2020-10-22 05:03:00 --> UTF-8 Support Enabled
INFO - 2020-10-22 05:03:00 --> Utf8 Class Initialized
INFO - 2020-10-22 05:03:00 --> URI Class Initialized
INFO - 2020-10-22 05:03:00 --> Router Class Initialized
INFO - 2020-10-22 05:03:00 --> Output Class Initialized
INFO - 2020-10-22 05:03:00 --> Security Class Initialized
DEBUG - 2020-10-22 05:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 05:03:00 --> Input Class Initialized
INFO - 2020-10-22 05:03:00 --> Language Class Initialized
INFO - 2020-10-22 05:03:00 --> Language Class Initialized
INFO - 2020-10-22 05:03:00 --> Config Class Initialized
INFO - 2020-10-22 05:03:00 --> Loader Class Initialized
INFO - 2020-10-22 05:03:00 --> Helper loaded: url_helper
INFO - 2020-10-22 05:03:00 --> Helper loaded: file_helper
INFO - 2020-10-22 05:03:00 --> Helper loaded: form_helper
INFO - 2020-10-22 05:03:00 --> Helper loaded: my_helper
INFO - 2020-10-22 05:03:00 --> Database Driver Class Initialized
DEBUG - 2020-10-22 05:03:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 05:03:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 05:03:00 --> Controller Class Initialized
DEBUG - 2020-10-22 05:03:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-22 05:03:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-22 05:03:00 --> Final output sent to browser
DEBUG - 2020-10-22 05:03:00 --> Total execution time: 0.2489
INFO - 2020-10-22 06:15:20 --> Config Class Initialized
INFO - 2020-10-22 06:15:20 --> Hooks Class Initialized
DEBUG - 2020-10-22 06:15:20 --> UTF-8 Support Enabled
INFO - 2020-10-22 06:15:20 --> Utf8 Class Initialized
INFO - 2020-10-22 06:15:20 --> URI Class Initialized
INFO - 2020-10-22 06:15:20 --> Router Class Initialized
INFO - 2020-10-22 06:15:20 --> Output Class Initialized
INFO - 2020-10-22 06:15:21 --> Security Class Initialized
DEBUG - 2020-10-22 06:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 06:15:21 --> Input Class Initialized
INFO - 2020-10-22 06:15:21 --> Language Class Initialized
INFO - 2020-10-22 06:15:21 --> Language Class Initialized
INFO - 2020-10-22 06:15:21 --> Config Class Initialized
INFO - 2020-10-22 06:15:21 --> Loader Class Initialized
INFO - 2020-10-22 06:15:21 --> Helper loaded: url_helper
INFO - 2020-10-22 06:15:21 --> Helper loaded: file_helper
INFO - 2020-10-22 06:15:21 --> Helper loaded: form_helper
INFO - 2020-10-22 06:15:21 --> Helper loaded: my_helper
INFO - 2020-10-22 06:15:21 --> Database Driver Class Initialized
DEBUG - 2020-10-22 06:15:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 06:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 06:15:21 --> Controller Class Initialized
INFO - 2020-10-22 06:15:21 --> Helper loaded: cookie_helper
INFO - 2020-10-22 06:15:21 --> Final output sent to browser
DEBUG - 2020-10-22 06:15:21 --> Total execution time: 0.2033
INFO - 2020-10-22 06:15:22 --> Config Class Initialized
INFO - 2020-10-22 06:15:22 --> Hooks Class Initialized
DEBUG - 2020-10-22 06:15:22 --> UTF-8 Support Enabled
INFO - 2020-10-22 06:15:22 --> Utf8 Class Initialized
INFO - 2020-10-22 06:15:22 --> URI Class Initialized
INFO - 2020-10-22 06:15:22 --> Router Class Initialized
INFO - 2020-10-22 06:15:22 --> Output Class Initialized
INFO - 2020-10-22 06:15:22 --> Security Class Initialized
DEBUG - 2020-10-22 06:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 06:15:22 --> Input Class Initialized
INFO - 2020-10-22 06:15:22 --> Language Class Initialized
INFO - 2020-10-22 06:15:22 --> Language Class Initialized
INFO - 2020-10-22 06:15:22 --> Config Class Initialized
INFO - 2020-10-22 06:15:22 --> Loader Class Initialized
INFO - 2020-10-22 06:15:22 --> Helper loaded: url_helper
INFO - 2020-10-22 06:15:22 --> Helper loaded: file_helper
INFO - 2020-10-22 06:15:22 --> Helper loaded: form_helper
INFO - 2020-10-22 06:15:22 --> Helper loaded: my_helper
INFO - 2020-10-22 06:15:22 --> Database Driver Class Initialized
DEBUG - 2020-10-22 06:15:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 06:15:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 06:15:22 --> Controller Class Initialized
DEBUG - 2020-10-22 06:15:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-22 06:15:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-22 06:15:22 --> Final output sent to browser
DEBUG - 2020-10-22 06:15:22 --> Total execution time: 0.2363
INFO - 2020-10-22 06:15:27 --> Config Class Initialized
INFO - 2020-10-22 06:15:27 --> Hooks Class Initialized
DEBUG - 2020-10-22 06:15:27 --> UTF-8 Support Enabled
INFO - 2020-10-22 06:15:27 --> Utf8 Class Initialized
INFO - 2020-10-22 06:15:27 --> URI Class Initialized
INFO - 2020-10-22 06:15:27 --> Router Class Initialized
INFO - 2020-10-22 06:15:27 --> Output Class Initialized
INFO - 2020-10-22 06:15:27 --> Security Class Initialized
DEBUG - 2020-10-22 06:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 06:15:27 --> Input Class Initialized
INFO - 2020-10-22 06:15:27 --> Language Class Initialized
INFO - 2020-10-22 06:15:27 --> Language Class Initialized
INFO - 2020-10-22 06:15:27 --> Config Class Initialized
INFO - 2020-10-22 06:15:27 --> Loader Class Initialized
INFO - 2020-10-22 06:15:27 --> Helper loaded: url_helper
INFO - 2020-10-22 06:15:27 --> Helper loaded: file_helper
INFO - 2020-10-22 06:15:27 --> Helper loaded: form_helper
INFO - 2020-10-22 06:15:27 --> Helper loaded: my_helper
INFO - 2020-10-22 06:15:27 --> Database Driver Class Initialized
DEBUG - 2020-10-22 06:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 06:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 06:15:27 --> Controller Class Initialized
DEBUG - 2020-10-22 06:15:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-10-22 06:15:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-22 06:15:27 --> Final output sent to browser
DEBUG - 2020-10-22 06:15:27 --> Total execution time: 0.2136
INFO - 2020-10-22 06:15:28 --> Config Class Initialized
INFO - 2020-10-22 06:15:28 --> Hooks Class Initialized
DEBUG - 2020-10-22 06:15:28 --> UTF-8 Support Enabled
INFO - 2020-10-22 06:15:28 --> Utf8 Class Initialized
INFO - 2020-10-22 06:15:28 --> URI Class Initialized
INFO - 2020-10-22 06:15:28 --> Router Class Initialized
INFO - 2020-10-22 06:15:28 --> Output Class Initialized
INFO - 2020-10-22 06:15:28 --> Security Class Initialized
DEBUG - 2020-10-22 06:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 06:15:28 --> Input Class Initialized
INFO - 2020-10-22 06:15:28 --> Language Class Initialized
INFO - 2020-10-22 06:15:28 --> Language Class Initialized
INFO - 2020-10-22 06:15:28 --> Config Class Initialized
INFO - 2020-10-22 06:15:28 --> Loader Class Initialized
INFO - 2020-10-22 06:15:28 --> Helper loaded: url_helper
INFO - 2020-10-22 06:15:28 --> Helper loaded: file_helper
INFO - 2020-10-22 06:15:28 --> Helper loaded: form_helper
INFO - 2020-10-22 06:15:28 --> Helper loaded: my_helper
INFO - 2020-10-22 06:15:28 --> Database Driver Class Initialized
DEBUG - 2020-10-22 06:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 06:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 06:15:28 --> Controller Class Initialized
INFO - 2020-10-22 06:15:30 --> Config Class Initialized
INFO - 2020-10-22 06:15:30 --> Hooks Class Initialized
DEBUG - 2020-10-22 06:15:30 --> UTF-8 Support Enabled
INFO - 2020-10-22 06:15:30 --> Utf8 Class Initialized
INFO - 2020-10-22 06:15:30 --> URI Class Initialized
INFO - 2020-10-22 06:15:30 --> Router Class Initialized
INFO - 2020-10-22 06:15:30 --> Output Class Initialized
INFO - 2020-10-22 06:15:30 --> Security Class Initialized
DEBUG - 2020-10-22 06:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 06:15:30 --> Input Class Initialized
INFO - 2020-10-22 06:15:30 --> Language Class Initialized
INFO - 2020-10-22 06:15:30 --> Language Class Initialized
INFO - 2020-10-22 06:15:30 --> Config Class Initialized
INFO - 2020-10-22 06:15:30 --> Loader Class Initialized
INFO - 2020-10-22 06:15:30 --> Helper loaded: url_helper
INFO - 2020-10-22 06:15:30 --> Helper loaded: file_helper
INFO - 2020-10-22 06:15:30 --> Helper loaded: form_helper
INFO - 2020-10-22 06:15:30 --> Helper loaded: my_helper
INFO - 2020-10-22 06:15:30 --> Database Driver Class Initialized
DEBUG - 2020-10-22 06:15:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 06:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 06:15:30 --> Controller Class Initialized
ERROR - 2020-10-22 06:15:30 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 223
DEBUG - 2020-10-22 06:15:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2020-10-22 06:15:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-22 06:15:31 --> Final output sent to browser
DEBUG - 2020-10-22 06:15:31 --> Total execution time: 0.2397
INFO - 2020-10-22 08:12:51 --> Config Class Initialized
INFO - 2020-10-22 08:12:51 --> Hooks Class Initialized
DEBUG - 2020-10-22 08:12:51 --> UTF-8 Support Enabled
INFO - 2020-10-22 08:12:51 --> Utf8 Class Initialized
INFO - 2020-10-22 08:12:51 --> URI Class Initialized
INFO - 2020-10-22 08:12:51 --> Router Class Initialized
INFO - 2020-10-22 08:12:51 --> Output Class Initialized
INFO - 2020-10-22 08:12:51 --> Security Class Initialized
DEBUG - 2020-10-22 08:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 08:12:52 --> Input Class Initialized
INFO - 2020-10-22 08:12:52 --> Language Class Initialized
INFO - 2020-10-22 08:12:52 --> Language Class Initialized
INFO - 2020-10-22 08:12:52 --> Config Class Initialized
INFO - 2020-10-22 08:12:52 --> Loader Class Initialized
INFO - 2020-10-22 08:12:52 --> Helper loaded: url_helper
INFO - 2020-10-22 08:12:52 --> Helper loaded: file_helper
INFO - 2020-10-22 08:12:52 --> Helper loaded: form_helper
INFO - 2020-10-22 08:12:52 --> Helper loaded: my_helper
INFO - 2020-10-22 08:12:52 --> Database Driver Class Initialized
DEBUG - 2020-10-22 08:12:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 08:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 08:12:52 --> Controller Class Initialized
INFO - 2020-10-22 08:12:52 --> Helper loaded: cookie_helper
INFO - 2020-10-22 08:12:52 --> Config Class Initialized
INFO - 2020-10-22 08:12:52 --> Hooks Class Initialized
DEBUG - 2020-10-22 08:12:52 --> UTF-8 Support Enabled
INFO - 2020-10-22 08:12:52 --> Utf8 Class Initialized
INFO - 2020-10-22 08:12:52 --> URI Class Initialized
INFO - 2020-10-22 08:12:52 --> Router Class Initialized
INFO - 2020-10-22 08:12:52 --> Output Class Initialized
INFO - 2020-10-22 08:12:52 --> Security Class Initialized
DEBUG - 2020-10-22 08:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 08:12:52 --> Input Class Initialized
INFO - 2020-10-22 08:12:52 --> Language Class Initialized
INFO - 2020-10-22 08:12:52 --> Language Class Initialized
INFO - 2020-10-22 08:12:52 --> Config Class Initialized
INFO - 2020-10-22 08:12:52 --> Loader Class Initialized
INFO - 2020-10-22 08:12:52 --> Helper loaded: url_helper
INFO - 2020-10-22 08:12:52 --> Helper loaded: file_helper
INFO - 2020-10-22 08:12:52 --> Helper loaded: form_helper
INFO - 2020-10-22 08:12:52 --> Helper loaded: my_helper
INFO - 2020-10-22 08:12:52 --> Database Driver Class Initialized
DEBUG - 2020-10-22 08:12:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 08:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 08:12:52 --> Controller Class Initialized
DEBUG - 2020-10-22 08:12:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-22 08:12:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-22 08:12:52 --> Final output sent to browser
DEBUG - 2020-10-22 08:12:52 --> Total execution time: 0.2342
INFO - 2020-10-22 08:13:33 --> Config Class Initialized
INFO - 2020-10-22 08:13:33 --> Hooks Class Initialized
DEBUG - 2020-10-22 08:13:33 --> UTF-8 Support Enabled
INFO - 2020-10-22 08:13:33 --> Utf8 Class Initialized
INFO - 2020-10-22 08:13:33 --> URI Class Initialized
INFO - 2020-10-22 08:13:33 --> Router Class Initialized
INFO - 2020-10-22 08:13:33 --> Output Class Initialized
INFO - 2020-10-22 08:13:33 --> Security Class Initialized
DEBUG - 2020-10-22 08:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 08:13:33 --> Input Class Initialized
INFO - 2020-10-22 08:13:33 --> Language Class Initialized
INFO - 2020-10-22 08:13:33 --> Language Class Initialized
INFO - 2020-10-22 08:13:33 --> Config Class Initialized
INFO - 2020-10-22 08:13:33 --> Loader Class Initialized
INFO - 2020-10-22 08:13:33 --> Helper loaded: url_helper
INFO - 2020-10-22 08:13:33 --> Helper loaded: file_helper
INFO - 2020-10-22 08:13:33 --> Helper loaded: form_helper
INFO - 2020-10-22 08:13:33 --> Helper loaded: my_helper
INFO - 2020-10-22 08:13:33 --> Database Driver Class Initialized
DEBUG - 2020-10-22 08:13:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 08:13:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 08:13:33 --> Controller Class Initialized
DEBUG - 2020-10-22 08:13:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2020-10-22 08:13:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-22 08:13:33 --> Final output sent to browser
DEBUG - 2020-10-22 08:13:33 --> Total execution time: 0.2310
INFO - 2020-10-22 08:13:33 --> Config Class Initialized
INFO - 2020-10-22 08:13:33 --> Hooks Class Initialized
DEBUG - 2020-10-22 08:13:33 --> UTF-8 Support Enabled
INFO - 2020-10-22 08:13:33 --> Utf8 Class Initialized
INFO - 2020-10-22 08:13:33 --> URI Class Initialized
INFO - 2020-10-22 08:13:33 --> Router Class Initialized
INFO - 2020-10-22 08:13:33 --> Output Class Initialized
INFO - 2020-10-22 08:13:33 --> Security Class Initialized
DEBUG - 2020-10-22 08:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 08:13:33 --> Input Class Initialized
INFO - 2020-10-22 08:13:33 --> Language Class Initialized
INFO - 2020-10-22 08:13:33 --> Language Class Initialized
INFO - 2020-10-22 08:13:33 --> Config Class Initialized
INFO - 2020-10-22 08:13:33 --> Loader Class Initialized
INFO - 2020-10-22 08:13:33 --> Helper loaded: url_helper
INFO - 2020-10-22 08:13:33 --> Helper loaded: file_helper
INFO - 2020-10-22 08:13:33 --> Helper loaded: form_helper
INFO - 2020-10-22 08:13:33 --> Helper loaded: my_helper
INFO - 2020-10-22 08:13:33 --> Database Driver Class Initialized
DEBUG - 2020-10-22 08:13:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 08:13:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 08:13:33 --> Controller Class Initialized
INFO - 2020-10-22 08:13:34 --> Config Class Initialized
INFO - 2020-10-22 08:13:34 --> Hooks Class Initialized
DEBUG - 2020-10-22 08:13:34 --> UTF-8 Support Enabled
INFO - 2020-10-22 08:13:34 --> Utf8 Class Initialized
INFO - 2020-10-22 08:13:34 --> URI Class Initialized
INFO - 2020-10-22 08:13:34 --> Router Class Initialized
INFO - 2020-10-22 08:13:34 --> Output Class Initialized
INFO - 2020-10-22 08:13:34 --> Security Class Initialized
DEBUG - 2020-10-22 08:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 08:13:34 --> Input Class Initialized
INFO - 2020-10-22 08:13:34 --> Language Class Initialized
INFO - 2020-10-22 08:13:34 --> Language Class Initialized
INFO - 2020-10-22 08:13:34 --> Config Class Initialized
INFO - 2020-10-22 08:13:34 --> Loader Class Initialized
INFO - 2020-10-22 08:13:34 --> Helper loaded: url_helper
INFO - 2020-10-22 08:13:34 --> Helper loaded: file_helper
INFO - 2020-10-22 08:13:34 --> Helper loaded: form_helper
INFO - 2020-10-22 08:13:34 --> Helper loaded: my_helper
INFO - 2020-10-22 08:13:34 --> Database Driver Class Initialized
DEBUG - 2020-10-22 08:13:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 08:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 08:13:34 --> Controller Class Initialized
DEBUG - 2020-10-22 08:13:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-10-22 08:13:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-22 08:13:34 --> Final output sent to browser
DEBUG - 2020-10-22 08:13:34 --> Total execution time: 0.2266
INFO - 2020-10-22 08:13:34 --> Config Class Initialized
INFO - 2020-10-22 08:13:34 --> Hooks Class Initialized
DEBUG - 2020-10-22 08:13:34 --> UTF-8 Support Enabled
INFO - 2020-10-22 08:13:34 --> Utf8 Class Initialized
INFO - 2020-10-22 08:13:34 --> URI Class Initialized
INFO - 2020-10-22 08:13:34 --> Router Class Initialized
INFO - 2020-10-22 08:13:34 --> Output Class Initialized
INFO - 2020-10-22 08:13:34 --> Security Class Initialized
DEBUG - 2020-10-22 08:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 08:13:34 --> Input Class Initialized
INFO - 2020-10-22 08:13:34 --> Language Class Initialized
INFO - 2020-10-22 08:13:34 --> Language Class Initialized
INFO - 2020-10-22 08:13:35 --> Config Class Initialized
INFO - 2020-10-22 08:13:35 --> Loader Class Initialized
INFO - 2020-10-22 08:13:35 --> Helper loaded: url_helper
INFO - 2020-10-22 08:13:35 --> Helper loaded: file_helper
INFO - 2020-10-22 08:13:35 --> Helper loaded: form_helper
INFO - 2020-10-22 08:13:35 --> Helper loaded: my_helper
INFO - 2020-10-22 08:13:35 --> Database Driver Class Initialized
DEBUG - 2020-10-22 08:13:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 08:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 08:13:35 --> Controller Class Initialized
INFO - 2020-10-22 08:13:51 --> Config Class Initialized
INFO - 2020-10-22 08:13:51 --> Hooks Class Initialized
DEBUG - 2020-10-22 08:13:51 --> UTF-8 Support Enabled
INFO - 2020-10-22 08:13:51 --> Utf8 Class Initialized
INFO - 2020-10-22 08:13:51 --> URI Class Initialized
INFO - 2020-10-22 08:13:51 --> Router Class Initialized
INFO - 2020-10-22 08:13:52 --> Output Class Initialized
INFO - 2020-10-22 08:13:52 --> Security Class Initialized
DEBUG - 2020-10-22 08:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 08:13:52 --> Input Class Initialized
INFO - 2020-10-22 08:13:52 --> Language Class Initialized
INFO - 2020-10-22 08:13:52 --> Language Class Initialized
INFO - 2020-10-22 08:13:52 --> Config Class Initialized
INFO - 2020-10-22 08:13:52 --> Loader Class Initialized
INFO - 2020-10-22 08:13:52 --> Helper loaded: url_helper
INFO - 2020-10-22 08:13:52 --> Helper loaded: file_helper
INFO - 2020-10-22 08:13:52 --> Helper loaded: form_helper
INFO - 2020-10-22 08:13:52 --> Helper loaded: my_helper
INFO - 2020-10-22 08:13:52 --> Database Driver Class Initialized
DEBUG - 2020-10-22 08:13:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 08:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 08:13:52 --> Controller Class Initialized
DEBUG - 2020-10-22 08:13:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-10-22 08:13:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-22 08:13:52 --> Final output sent to browser
DEBUG - 2020-10-22 08:13:52 --> Total execution time: 0.2337
INFO - 2020-10-22 08:13:52 --> Config Class Initialized
INFO - 2020-10-22 08:13:52 --> Hooks Class Initialized
DEBUG - 2020-10-22 08:13:52 --> UTF-8 Support Enabled
INFO - 2020-10-22 08:13:52 --> Utf8 Class Initialized
INFO - 2020-10-22 08:13:52 --> URI Class Initialized
INFO - 2020-10-22 08:13:52 --> Router Class Initialized
INFO - 2020-10-22 08:13:52 --> Output Class Initialized
INFO - 2020-10-22 08:13:52 --> Security Class Initialized
DEBUG - 2020-10-22 08:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 08:13:52 --> Input Class Initialized
INFO - 2020-10-22 08:13:52 --> Language Class Initialized
INFO - 2020-10-22 08:13:52 --> Language Class Initialized
INFO - 2020-10-22 08:13:52 --> Config Class Initialized
INFO - 2020-10-22 08:13:52 --> Loader Class Initialized
INFO - 2020-10-22 08:13:52 --> Helper loaded: url_helper
INFO - 2020-10-22 08:13:52 --> Helper loaded: file_helper
INFO - 2020-10-22 08:13:52 --> Helper loaded: form_helper
INFO - 2020-10-22 08:13:52 --> Helper loaded: my_helper
INFO - 2020-10-22 08:13:52 --> Database Driver Class Initialized
DEBUG - 2020-10-22 08:13:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 08:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 08:13:52 --> Controller Class Initialized
INFO - 2020-10-22 10:38:25 --> Config Class Initialized
INFO - 2020-10-22 10:38:25 --> Hooks Class Initialized
DEBUG - 2020-10-22 10:38:25 --> UTF-8 Support Enabled
INFO - 2020-10-22 10:38:25 --> Utf8 Class Initialized
INFO - 2020-10-22 10:38:25 --> URI Class Initialized
INFO - 2020-10-22 10:38:25 --> Router Class Initialized
INFO - 2020-10-22 10:38:25 --> Output Class Initialized
INFO - 2020-10-22 10:38:25 --> Security Class Initialized
DEBUG - 2020-10-22 10:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 10:38:25 --> Input Class Initialized
INFO - 2020-10-22 10:38:25 --> Language Class Initialized
INFO - 2020-10-22 10:38:25 --> Language Class Initialized
INFO - 2020-10-22 10:38:25 --> Config Class Initialized
INFO - 2020-10-22 10:38:25 --> Loader Class Initialized
INFO - 2020-10-22 10:38:25 --> Helper loaded: url_helper
INFO - 2020-10-22 10:38:25 --> Helper loaded: file_helper
INFO - 2020-10-22 10:38:25 --> Helper loaded: form_helper
INFO - 2020-10-22 10:38:25 --> Helper loaded: my_helper
INFO - 2020-10-22 10:38:25 --> Database Driver Class Initialized
DEBUG - 2020-10-22 10:38:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 10:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 10:38:25 --> Controller Class Initialized
DEBUG - 2020-10-22 10:38:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-22 10:38:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-22 10:38:25 --> Final output sent to browser
DEBUG - 2020-10-22 10:38:25 --> Total execution time: 0.2212
INFO - 2020-10-22 10:38:25 --> Config Class Initialized
INFO - 2020-10-22 10:38:25 --> Hooks Class Initialized
DEBUG - 2020-10-22 10:38:25 --> UTF-8 Support Enabled
INFO - 2020-10-22 10:38:25 --> Utf8 Class Initialized
INFO - 2020-10-22 10:38:25 --> URI Class Initialized
INFO - 2020-10-22 10:38:25 --> Router Class Initialized
INFO - 2020-10-22 10:38:25 --> Output Class Initialized
INFO - 2020-10-22 10:38:25 --> Security Class Initialized
DEBUG - 2020-10-22 10:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 10:38:25 --> Input Class Initialized
INFO - 2020-10-22 10:38:25 --> Language Class Initialized
INFO - 2020-10-22 10:38:25 --> Language Class Initialized
INFO - 2020-10-22 10:38:25 --> Config Class Initialized
INFO - 2020-10-22 10:38:25 --> Loader Class Initialized
INFO - 2020-10-22 10:38:25 --> Helper loaded: url_helper
INFO - 2020-10-22 10:38:25 --> Helper loaded: file_helper
INFO - 2020-10-22 10:38:25 --> Helper loaded: form_helper
INFO - 2020-10-22 10:38:25 --> Helper loaded: my_helper
INFO - 2020-10-22 10:38:25 --> Database Driver Class Initialized
DEBUG - 2020-10-22 10:38:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 10:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 10:38:25 --> Controller Class Initialized
INFO - 2020-10-22 10:49:28 --> Config Class Initialized
INFO - 2020-10-22 10:49:28 --> Hooks Class Initialized
DEBUG - 2020-10-22 10:49:28 --> UTF-8 Support Enabled
INFO - 2020-10-22 10:49:28 --> Utf8 Class Initialized
INFO - 2020-10-22 10:49:28 --> URI Class Initialized
INFO - 2020-10-22 10:49:28 --> Router Class Initialized
INFO - 2020-10-22 10:49:28 --> Output Class Initialized
INFO - 2020-10-22 10:49:28 --> Security Class Initialized
DEBUG - 2020-10-22 10:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 10:49:28 --> Input Class Initialized
INFO - 2020-10-22 10:49:28 --> Language Class Initialized
INFO - 2020-10-22 10:49:28 --> Language Class Initialized
INFO - 2020-10-22 10:49:28 --> Config Class Initialized
INFO - 2020-10-22 10:49:28 --> Loader Class Initialized
INFO - 2020-10-22 10:49:28 --> Helper loaded: url_helper
INFO - 2020-10-22 10:49:28 --> Helper loaded: file_helper
INFO - 2020-10-22 10:49:28 --> Helper loaded: form_helper
INFO - 2020-10-22 10:49:28 --> Helper loaded: my_helper
INFO - 2020-10-22 10:49:28 --> Database Driver Class Initialized
DEBUG - 2020-10-22 10:49:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 10:49:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 10:49:28 --> Controller Class Initialized
INFO - 2020-10-22 10:49:28 --> Final output sent to browser
DEBUG - 2020-10-22 10:49:28 --> Total execution time: 0.2007
INFO - 2020-10-22 10:50:10 --> Config Class Initialized
INFO - 2020-10-22 10:50:10 --> Hooks Class Initialized
DEBUG - 2020-10-22 10:50:10 --> UTF-8 Support Enabled
INFO - 2020-10-22 10:50:10 --> Utf8 Class Initialized
INFO - 2020-10-22 10:50:10 --> URI Class Initialized
INFO - 2020-10-22 10:50:10 --> Router Class Initialized
INFO - 2020-10-22 10:50:10 --> Output Class Initialized
INFO - 2020-10-22 10:50:10 --> Security Class Initialized
DEBUG - 2020-10-22 10:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 10:50:10 --> Input Class Initialized
INFO - 2020-10-22 10:50:10 --> Language Class Initialized
INFO - 2020-10-22 10:50:10 --> Language Class Initialized
INFO - 2020-10-22 10:50:10 --> Config Class Initialized
INFO - 2020-10-22 10:50:10 --> Loader Class Initialized
INFO - 2020-10-22 10:50:10 --> Helper loaded: url_helper
INFO - 2020-10-22 10:50:10 --> Helper loaded: file_helper
INFO - 2020-10-22 10:50:10 --> Helper loaded: form_helper
INFO - 2020-10-22 10:50:10 --> Helper loaded: my_helper
INFO - 2020-10-22 10:50:10 --> Database Driver Class Initialized
DEBUG - 2020-10-22 10:50:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-22 10:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 10:50:10 --> Controller Class Initialized
INFO - 2020-10-22 10:50:10 --> Final output sent to browser
DEBUG - 2020-10-22 10:50:10 --> Total execution time: 0.2039
