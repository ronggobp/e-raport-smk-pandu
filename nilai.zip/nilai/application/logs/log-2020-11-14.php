<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-11-14 02:17:57 --> Config Class Initialized
INFO - 2020-11-14 02:17:57 --> Hooks Class Initialized
DEBUG - 2020-11-14 02:17:57 --> UTF-8 Support Enabled
INFO - 2020-11-14 02:17:57 --> Utf8 Class Initialized
INFO - 2020-11-14 02:17:57 --> URI Class Initialized
DEBUG - 2020-11-14 02:17:57 --> No URI present. Default controller set.
INFO - 2020-11-14 02:17:57 --> Router Class Initialized
INFO - 2020-11-14 02:17:57 --> Output Class Initialized
INFO - 2020-11-14 02:17:57 --> Security Class Initialized
DEBUG - 2020-11-14 02:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 02:17:58 --> Input Class Initialized
INFO - 2020-11-14 02:17:58 --> Language Class Initialized
INFO - 2020-11-14 02:17:58 --> Language Class Initialized
INFO - 2020-11-14 02:17:58 --> Config Class Initialized
INFO - 2020-11-14 02:17:58 --> Loader Class Initialized
INFO - 2020-11-14 02:17:58 --> Helper loaded: url_helper
INFO - 2020-11-14 02:17:58 --> Helper loaded: file_helper
INFO - 2020-11-14 02:17:58 --> Helper loaded: form_helper
INFO - 2020-11-14 02:17:58 --> Helper loaded: my_helper
INFO - 2020-11-14 02:17:58 --> Database Driver Class Initialized
DEBUG - 2020-11-14 02:17:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-14 02:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 02:17:58 --> Controller Class Initialized
INFO - 2020-11-14 02:17:58 --> Config Class Initialized
INFO - 2020-11-14 02:17:58 --> Hooks Class Initialized
DEBUG - 2020-11-14 02:17:58 --> UTF-8 Support Enabled
INFO - 2020-11-14 02:17:58 --> Utf8 Class Initialized
INFO - 2020-11-14 02:17:58 --> URI Class Initialized
INFO - 2020-11-14 02:17:58 --> Router Class Initialized
INFO - 2020-11-14 02:17:58 --> Output Class Initialized
INFO - 2020-11-14 02:17:58 --> Security Class Initialized
DEBUG - 2020-11-14 02:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 02:17:58 --> Input Class Initialized
INFO - 2020-11-14 02:17:58 --> Language Class Initialized
INFO - 2020-11-14 02:17:58 --> Language Class Initialized
INFO - 2020-11-14 02:17:58 --> Config Class Initialized
INFO - 2020-11-14 02:17:58 --> Loader Class Initialized
INFO - 2020-11-14 02:17:58 --> Helper loaded: url_helper
INFO - 2020-11-14 02:17:58 --> Helper loaded: file_helper
INFO - 2020-11-14 02:17:58 --> Helper loaded: form_helper
INFO - 2020-11-14 02:17:58 --> Helper loaded: my_helper
INFO - 2020-11-14 02:17:58 --> Database Driver Class Initialized
DEBUG - 2020-11-14 02:17:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-14 02:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 02:17:58 --> Controller Class Initialized
DEBUG - 2020-11-14 02:17:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-14 02:17:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-14 02:17:58 --> Final output sent to browser
DEBUG - 2020-11-14 02:17:58 --> Total execution time: 0.3189
INFO - 2020-11-14 03:19:44 --> Config Class Initialized
INFO - 2020-11-14 03:19:44 --> Hooks Class Initialized
DEBUG - 2020-11-14 03:19:44 --> UTF-8 Support Enabled
INFO - 2020-11-14 03:19:44 --> Utf8 Class Initialized
INFO - 2020-11-14 03:19:44 --> URI Class Initialized
INFO - 2020-11-14 03:19:44 --> Router Class Initialized
INFO - 2020-11-14 03:19:44 --> Output Class Initialized
INFO - 2020-11-14 03:19:44 --> Security Class Initialized
DEBUG - 2020-11-14 03:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 03:19:44 --> Input Class Initialized
INFO - 2020-11-14 03:19:45 --> Language Class Initialized
INFO - 2020-11-14 03:19:45 --> Language Class Initialized
INFO - 2020-11-14 03:19:45 --> Config Class Initialized
INFO - 2020-11-14 03:19:45 --> Loader Class Initialized
INFO - 2020-11-14 03:19:45 --> Helper loaded: url_helper
INFO - 2020-11-14 03:19:45 --> Helper loaded: file_helper
INFO - 2020-11-14 03:19:45 --> Helper loaded: form_helper
INFO - 2020-11-14 03:19:45 --> Helper loaded: my_helper
INFO - 2020-11-14 03:19:45 --> Database Driver Class Initialized
DEBUG - 2020-11-14 03:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-14 03:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 03:19:45 --> Controller Class Initialized
DEBUG - 2020-11-14 03:19:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-14 03:19:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-14 03:19:45 --> Final output sent to browser
DEBUG - 2020-11-14 03:19:45 --> Total execution time: 0.6232
INFO - 2020-11-14 03:37:27 --> Config Class Initialized
INFO - 2020-11-14 03:37:27 --> Hooks Class Initialized
DEBUG - 2020-11-14 03:37:27 --> UTF-8 Support Enabled
INFO - 2020-11-14 03:37:27 --> Utf8 Class Initialized
INFO - 2020-11-14 03:37:27 --> URI Class Initialized
INFO - 2020-11-14 03:37:27 --> Router Class Initialized
INFO - 2020-11-14 03:37:27 --> Output Class Initialized
INFO - 2020-11-14 03:37:27 --> Security Class Initialized
DEBUG - 2020-11-14 03:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 03:37:27 --> Input Class Initialized
INFO - 2020-11-14 03:37:27 --> Language Class Initialized
INFO - 2020-11-14 03:37:27 --> Language Class Initialized
INFO - 2020-11-14 03:37:27 --> Config Class Initialized
INFO - 2020-11-14 03:37:27 --> Loader Class Initialized
INFO - 2020-11-14 03:37:27 --> Helper loaded: url_helper
INFO - 2020-11-14 03:37:27 --> Helper loaded: file_helper
INFO - 2020-11-14 03:37:27 --> Helper loaded: form_helper
INFO - 2020-11-14 03:37:27 --> Helper loaded: my_helper
INFO - 2020-11-14 03:37:27 --> Database Driver Class Initialized
DEBUG - 2020-11-14 03:37:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-14 03:37:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 03:37:27 --> Controller Class Initialized
INFO - 2020-11-14 03:37:27 --> Helper loaded: cookie_helper
INFO - 2020-11-14 03:37:27 --> Final output sent to browser
DEBUG - 2020-11-14 03:37:28 --> Total execution time: 0.6952
INFO - 2020-11-14 03:37:28 --> Config Class Initialized
INFO - 2020-11-14 03:37:28 --> Hooks Class Initialized
DEBUG - 2020-11-14 03:37:28 --> UTF-8 Support Enabled
INFO - 2020-11-14 03:37:28 --> Utf8 Class Initialized
INFO - 2020-11-14 03:37:28 --> URI Class Initialized
INFO - 2020-11-14 03:37:28 --> Router Class Initialized
INFO - 2020-11-14 03:37:28 --> Output Class Initialized
INFO - 2020-11-14 03:37:28 --> Security Class Initialized
DEBUG - 2020-11-14 03:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 03:37:29 --> Input Class Initialized
INFO - 2020-11-14 03:37:29 --> Language Class Initialized
INFO - 2020-11-14 03:37:29 --> Language Class Initialized
INFO - 2020-11-14 03:37:29 --> Config Class Initialized
INFO - 2020-11-14 03:37:29 --> Loader Class Initialized
INFO - 2020-11-14 03:37:29 --> Helper loaded: url_helper
INFO - 2020-11-14 03:37:29 --> Helper loaded: file_helper
INFO - 2020-11-14 03:37:29 --> Helper loaded: form_helper
INFO - 2020-11-14 03:37:29 --> Helper loaded: my_helper
INFO - 2020-11-14 03:37:29 --> Database Driver Class Initialized
DEBUG - 2020-11-14 03:37:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-14 03:37:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 03:37:29 --> Controller Class Initialized
DEBUG - 2020-11-14 03:37:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-14 03:37:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-14 03:37:29 --> Final output sent to browser
DEBUG - 2020-11-14 03:37:29 --> Total execution time: 0.8274
INFO - 2020-11-14 03:37:30 --> Config Class Initialized
INFO - 2020-11-14 03:37:30 --> Hooks Class Initialized
DEBUG - 2020-11-14 03:37:30 --> UTF-8 Support Enabled
INFO - 2020-11-14 03:37:31 --> Utf8 Class Initialized
INFO - 2020-11-14 03:37:31 --> URI Class Initialized
INFO - 2020-11-14 03:37:31 --> Router Class Initialized
INFO - 2020-11-14 03:37:31 --> Output Class Initialized
INFO - 2020-11-14 03:37:31 --> Security Class Initialized
DEBUG - 2020-11-14 03:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 03:37:31 --> Input Class Initialized
INFO - 2020-11-14 03:37:31 --> Language Class Initialized
INFO - 2020-11-14 03:37:31 --> Language Class Initialized
INFO - 2020-11-14 03:37:31 --> Config Class Initialized
INFO - 2020-11-14 03:37:31 --> Loader Class Initialized
INFO - 2020-11-14 03:37:31 --> Helper loaded: url_helper
INFO - 2020-11-14 03:37:31 --> Helper loaded: file_helper
INFO - 2020-11-14 03:37:31 --> Helper loaded: form_helper
INFO - 2020-11-14 03:37:31 --> Helper loaded: my_helper
INFO - 2020-11-14 03:37:31 --> Database Driver Class Initialized
DEBUG - 2020-11-14 03:37:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-14 03:37:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 03:37:31 --> Controller Class Initialized
DEBUG - 2020-11-14 03:37:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-14 03:37:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-14 03:37:31 --> Final output sent to browser
DEBUG - 2020-11-14 03:37:31 --> Total execution time: 0.7919
INFO - 2020-11-14 03:37:32 --> Config Class Initialized
INFO - 2020-11-14 03:37:32 --> Hooks Class Initialized
DEBUG - 2020-11-14 03:37:32 --> UTF-8 Support Enabled
INFO - 2020-11-14 03:37:32 --> Utf8 Class Initialized
INFO - 2020-11-14 03:37:32 --> URI Class Initialized
INFO - 2020-11-14 03:37:32 --> Router Class Initialized
INFO - 2020-11-14 03:37:32 --> Output Class Initialized
INFO - 2020-11-14 03:37:32 --> Security Class Initialized
DEBUG - 2020-11-14 03:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 03:37:32 --> Input Class Initialized
INFO - 2020-11-14 03:37:32 --> Language Class Initialized
INFO - 2020-11-14 03:37:33 --> Language Class Initialized
INFO - 2020-11-14 03:37:33 --> Config Class Initialized
INFO - 2020-11-14 03:37:33 --> Loader Class Initialized
INFO - 2020-11-14 03:37:33 --> Helper loaded: url_helper
INFO - 2020-11-14 03:37:33 --> Helper loaded: file_helper
INFO - 2020-11-14 03:37:33 --> Helper loaded: form_helper
INFO - 2020-11-14 03:37:33 --> Helper loaded: my_helper
INFO - 2020-11-14 03:37:33 --> Database Driver Class Initialized
DEBUG - 2020-11-14 03:37:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-14 03:37:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 03:37:33 --> Controller Class Initialized
DEBUG - 2020-11-14 03:37:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-11-14 03:37:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-14 03:37:33 --> Final output sent to browser
DEBUG - 2020-11-14 03:37:33 --> Total execution time: 0.8457
INFO - 2020-11-14 03:37:35 --> Config Class Initialized
INFO - 2020-11-14 03:37:35 --> Hooks Class Initialized
DEBUG - 2020-11-14 03:37:35 --> UTF-8 Support Enabled
INFO - 2020-11-14 03:37:35 --> Utf8 Class Initialized
INFO - 2020-11-14 03:37:35 --> URI Class Initialized
INFO - 2020-11-14 03:37:35 --> Router Class Initialized
INFO - 2020-11-14 03:37:35 --> Output Class Initialized
INFO - 2020-11-14 03:37:35 --> Security Class Initialized
DEBUG - 2020-11-14 03:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 03:37:35 --> Input Class Initialized
INFO - 2020-11-14 03:37:35 --> Language Class Initialized
INFO - 2020-11-14 03:37:35 --> Language Class Initialized
INFO - 2020-11-14 03:37:35 --> Config Class Initialized
INFO - 2020-11-14 03:37:35 --> Loader Class Initialized
INFO - 2020-11-14 03:37:35 --> Helper loaded: url_helper
INFO - 2020-11-14 03:37:35 --> Helper loaded: file_helper
INFO - 2020-11-14 03:37:35 --> Helper loaded: form_helper
INFO - 2020-11-14 03:37:35 --> Helper loaded: my_helper
INFO - 2020-11-14 03:37:35 --> Database Driver Class Initialized
DEBUG - 2020-11-14 03:37:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-14 03:37:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 03:37:35 --> Controller Class Initialized
INFO - 2020-11-14 03:38:54 --> Config Class Initialized
INFO - 2020-11-14 03:38:54 --> Hooks Class Initialized
DEBUG - 2020-11-14 03:38:54 --> UTF-8 Support Enabled
INFO - 2020-11-14 03:38:54 --> Utf8 Class Initialized
INFO - 2020-11-14 03:38:54 --> URI Class Initialized
INFO - 2020-11-14 03:38:54 --> Router Class Initialized
INFO - 2020-11-14 03:38:54 --> Output Class Initialized
INFO - 2020-11-14 03:38:54 --> Security Class Initialized
DEBUG - 2020-11-14 03:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 03:38:55 --> Input Class Initialized
INFO - 2020-11-14 03:38:55 --> Language Class Initialized
INFO - 2020-11-14 03:38:55 --> Language Class Initialized
INFO - 2020-11-14 03:38:55 --> Config Class Initialized
INFO - 2020-11-14 03:38:55 --> Loader Class Initialized
INFO - 2020-11-14 03:38:55 --> Helper loaded: url_helper
INFO - 2020-11-14 03:38:55 --> Helper loaded: file_helper
INFO - 2020-11-14 03:38:55 --> Helper loaded: form_helper
INFO - 2020-11-14 03:38:55 --> Helper loaded: my_helper
INFO - 2020-11-14 03:38:55 --> Database Driver Class Initialized
DEBUG - 2020-11-14 03:38:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-14 03:38:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 03:38:55 --> Controller Class Initialized
DEBUG - 2020-11-14 03:38:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-11-14 03:38:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-14 03:38:55 --> Final output sent to browser
DEBUG - 2020-11-14 03:38:55 --> Total execution time: 0.8306
INFO - 2020-11-14 03:38:56 --> Config Class Initialized
INFO - 2020-11-14 03:38:56 --> Hooks Class Initialized
DEBUG - 2020-11-14 03:38:56 --> UTF-8 Support Enabled
INFO - 2020-11-14 03:38:57 --> Utf8 Class Initialized
INFO - 2020-11-14 03:38:57 --> URI Class Initialized
INFO - 2020-11-14 03:38:57 --> Router Class Initialized
INFO - 2020-11-14 03:38:57 --> Output Class Initialized
INFO - 2020-11-14 03:38:57 --> Security Class Initialized
DEBUG - 2020-11-14 03:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 03:38:57 --> Input Class Initialized
INFO - 2020-11-14 03:38:57 --> Language Class Initialized
INFO - 2020-11-14 03:38:57 --> Language Class Initialized
INFO - 2020-11-14 03:38:57 --> Config Class Initialized
INFO - 2020-11-14 03:38:57 --> Loader Class Initialized
INFO - 2020-11-14 03:38:57 --> Helper loaded: url_helper
INFO - 2020-11-14 03:38:57 --> Helper loaded: file_helper
INFO - 2020-11-14 03:38:57 --> Helper loaded: form_helper
INFO - 2020-11-14 03:38:57 --> Helper loaded: my_helper
INFO - 2020-11-14 03:38:57 --> Database Driver Class Initialized
DEBUG - 2020-11-14 03:38:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-14 03:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 03:38:57 --> Controller Class Initialized
INFO - 2020-11-14 03:52:11 --> Config Class Initialized
INFO - 2020-11-14 03:52:11 --> Hooks Class Initialized
DEBUG - 2020-11-14 03:52:11 --> UTF-8 Support Enabled
INFO - 2020-11-14 03:52:11 --> Utf8 Class Initialized
INFO - 2020-11-14 03:52:11 --> URI Class Initialized
INFO - 2020-11-14 03:52:11 --> Router Class Initialized
INFO - 2020-11-14 03:52:11 --> Output Class Initialized
INFO - 2020-11-14 03:52:12 --> Security Class Initialized
DEBUG - 2020-11-14 03:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 03:52:12 --> Input Class Initialized
INFO - 2020-11-14 03:52:12 --> Language Class Initialized
INFO - 2020-11-14 03:52:12 --> Language Class Initialized
INFO - 2020-11-14 03:52:12 --> Config Class Initialized
INFO - 2020-11-14 03:52:12 --> Loader Class Initialized
INFO - 2020-11-14 03:52:12 --> Helper loaded: url_helper
INFO - 2020-11-14 03:52:12 --> Helper loaded: file_helper
INFO - 2020-11-14 03:52:12 --> Helper loaded: form_helper
INFO - 2020-11-14 03:52:12 --> Helper loaded: my_helper
INFO - 2020-11-14 03:52:12 --> Database Driver Class Initialized
DEBUG - 2020-11-14 03:52:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-14 03:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 03:52:12 --> Controller Class Initialized
DEBUG - 2020-11-14 03:52:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-11-14 03:52:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-14 03:52:12 --> Final output sent to browser
DEBUG - 2020-11-14 03:52:12 --> Total execution time: 0.8903
INFO - 2020-11-14 03:52:14 --> Config Class Initialized
INFO - 2020-11-14 03:52:14 --> Hooks Class Initialized
DEBUG - 2020-11-14 03:52:14 --> UTF-8 Support Enabled
INFO - 2020-11-14 03:52:14 --> Utf8 Class Initialized
INFO - 2020-11-14 03:52:14 --> URI Class Initialized
INFO - 2020-11-14 03:52:14 --> Router Class Initialized
INFO - 2020-11-14 03:52:14 --> Output Class Initialized
INFO - 2020-11-14 03:52:14 --> Security Class Initialized
DEBUG - 2020-11-14 03:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 03:52:14 --> Input Class Initialized
INFO - 2020-11-14 03:52:14 --> Language Class Initialized
INFO - 2020-11-14 03:52:14 --> Language Class Initialized
INFO - 2020-11-14 03:52:14 --> Config Class Initialized
INFO - 2020-11-14 03:52:14 --> Loader Class Initialized
INFO - 2020-11-14 03:52:14 --> Helper loaded: url_helper
INFO - 2020-11-14 03:52:14 --> Helper loaded: file_helper
INFO - 2020-11-14 03:52:14 --> Helper loaded: form_helper
INFO - 2020-11-14 03:52:14 --> Helper loaded: my_helper
INFO - 2020-11-14 03:52:14 --> Database Driver Class Initialized
DEBUG - 2020-11-14 03:52:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-14 03:52:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 03:52:14 --> Controller Class Initialized
INFO - 2020-11-14 03:53:46 --> Config Class Initialized
INFO - 2020-11-14 03:53:46 --> Hooks Class Initialized
DEBUG - 2020-11-14 03:53:46 --> UTF-8 Support Enabled
INFO - 2020-11-14 03:53:46 --> Utf8 Class Initialized
INFO - 2020-11-14 03:53:46 --> URI Class Initialized
INFO - 2020-11-14 03:53:46 --> Router Class Initialized
INFO - 2020-11-14 03:53:46 --> Output Class Initialized
INFO - 2020-11-14 03:53:46 --> Security Class Initialized
DEBUG - 2020-11-14 03:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 03:53:46 --> Input Class Initialized
INFO - 2020-11-14 03:53:46 --> Language Class Initialized
INFO - 2020-11-14 03:53:46 --> Language Class Initialized
INFO - 2020-11-14 03:53:46 --> Config Class Initialized
INFO - 2020-11-14 03:53:46 --> Loader Class Initialized
INFO - 2020-11-14 03:53:46 --> Helper loaded: url_helper
INFO - 2020-11-14 03:53:46 --> Helper loaded: file_helper
INFO - 2020-11-14 03:53:46 --> Helper loaded: form_helper
INFO - 2020-11-14 03:53:46 --> Helper loaded: my_helper
INFO - 2020-11-14 03:53:46 --> Database Driver Class Initialized
DEBUG - 2020-11-14 03:53:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-14 03:53:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 03:53:47 --> Controller Class Initialized
DEBUG - 2020-11-14 03:53:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-11-14 03:53:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-14 03:53:47 --> Final output sent to browser
DEBUG - 2020-11-14 03:53:47 --> Total execution time: 0.8814
INFO - 2020-11-14 03:53:49 --> Config Class Initialized
INFO - 2020-11-14 03:53:49 --> Hooks Class Initialized
DEBUG - 2020-11-14 03:53:49 --> UTF-8 Support Enabled
INFO - 2020-11-14 03:53:49 --> Utf8 Class Initialized
INFO - 2020-11-14 03:53:49 --> URI Class Initialized
INFO - 2020-11-14 03:53:49 --> Router Class Initialized
INFO - 2020-11-14 03:53:49 --> Output Class Initialized
INFO - 2020-11-14 03:53:49 --> Security Class Initialized
DEBUG - 2020-11-14 03:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 03:53:49 --> Input Class Initialized
INFO - 2020-11-14 03:53:49 --> Language Class Initialized
INFO - 2020-11-14 03:53:49 --> Language Class Initialized
INFO - 2020-11-14 03:53:49 --> Config Class Initialized
INFO - 2020-11-14 03:53:49 --> Loader Class Initialized
INFO - 2020-11-14 03:53:49 --> Helper loaded: url_helper
INFO - 2020-11-14 03:53:49 --> Helper loaded: file_helper
INFO - 2020-11-14 03:53:49 --> Helper loaded: form_helper
INFO - 2020-11-14 03:53:49 --> Helper loaded: my_helper
INFO - 2020-11-14 03:53:50 --> Database Driver Class Initialized
DEBUG - 2020-11-14 03:53:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-14 03:53:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 03:53:50 --> Controller Class Initialized
INFO - 2020-11-14 08:32:51 --> Config Class Initialized
INFO - 2020-11-14 08:32:51 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:32:51 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:32:51 --> Utf8 Class Initialized
INFO - 2020-11-14 08:32:51 --> URI Class Initialized
INFO - 2020-11-14 08:32:51 --> Router Class Initialized
INFO - 2020-11-14 08:32:51 --> Output Class Initialized
INFO - 2020-11-14 08:32:51 --> Security Class Initialized
DEBUG - 2020-11-14 08:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:32:51 --> Input Class Initialized
INFO - 2020-11-14 08:32:51 --> Language Class Initialized
INFO - 2020-11-14 08:32:51 --> Language Class Initialized
INFO - 2020-11-14 08:32:51 --> Config Class Initialized
INFO - 2020-11-14 08:32:51 --> Loader Class Initialized
INFO - 2020-11-14 08:32:51 --> Helper loaded: url_helper
INFO - 2020-11-14 08:32:51 --> Helper loaded: file_helper
INFO - 2020-11-14 08:32:51 --> Helper loaded: form_helper
INFO - 2020-11-14 08:32:51 --> Helper loaded: my_helper
INFO - 2020-11-14 08:32:51 --> Database Driver Class Initialized
DEBUG - 2020-11-14 08:32:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-14 08:32:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:32:51 --> Controller Class Initialized
INFO - 2020-11-14 08:32:51 --> Helper loaded: cookie_helper
INFO - 2020-11-14 08:32:51 --> Config Class Initialized
INFO - 2020-11-14 08:32:52 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:32:52 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:32:52 --> Utf8 Class Initialized
INFO - 2020-11-14 08:32:52 --> URI Class Initialized
INFO - 2020-11-14 08:32:52 --> Router Class Initialized
INFO - 2020-11-14 08:32:52 --> Output Class Initialized
INFO - 2020-11-14 08:32:52 --> Security Class Initialized
DEBUG - 2020-11-14 08:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:32:52 --> Input Class Initialized
INFO - 2020-11-14 08:32:52 --> Language Class Initialized
INFO - 2020-11-14 08:32:52 --> Language Class Initialized
INFO - 2020-11-14 08:32:52 --> Config Class Initialized
INFO - 2020-11-14 08:32:52 --> Loader Class Initialized
INFO - 2020-11-14 08:32:52 --> Helper loaded: url_helper
INFO - 2020-11-14 08:32:52 --> Helper loaded: file_helper
INFO - 2020-11-14 08:32:52 --> Helper loaded: form_helper
INFO - 2020-11-14 08:32:52 --> Helper loaded: my_helper
INFO - 2020-11-14 08:32:52 --> Database Driver Class Initialized
DEBUG - 2020-11-14 08:32:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-14 08:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:32:52 --> Controller Class Initialized
DEBUG - 2020-11-14 08:32:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-14 08:32:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-14 08:32:52 --> Final output sent to browser
DEBUG - 2020-11-14 08:32:52 --> Total execution time: 0.2477
INFO - 2020-11-14 09:17:20 --> Config Class Initialized
INFO - 2020-11-14 09:17:20 --> Hooks Class Initialized
DEBUG - 2020-11-14 09:17:20 --> UTF-8 Support Enabled
INFO - 2020-11-14 09:17:20 --> Utf8 Class Initialized
INFO - 2020-11-14 09:17:20 --> URI Class Initialized
INFO - 2020-11-14 09:17:20 --> Router Class Initialized
INFO - 2020-11-14 09:17:20 --> Output Class Initialized
INFO - 2020-11-14 09:17:20 --> Security Class Initialized
DEBUG - 2020-11-14 09:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 09:17:20 --> Input Class Initialized
INFO - 2020-11-14 09:17:20 --> Language Class Initialized
INFO - 2020-11-14 09:17:20 --> Language Class Initialized
INFO - 2020-11-14 09:17:20 --> Config Class Initialized
INFO - 2020-11-14 09:17:20 --> Loader Class Initialized
INFO - 2020-11-14 09:17:20 --> Helper loaded: url_helper
INFO - 2020-11-14 09:17:20 --> Helper loaded: file_helper
INFO - 2020-11-14 09:17:20 --> Helper loaded: form_helper
INFO - 2020-11-14 09:17:20 --> Helper loaded: my_helper
INFO - 2020-11-14 09:17:20 --> Database Driver Class Initialized
DEBUG - 2020-11-14 09:17:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-14 09:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 09:17:21 --> Controller Class Initialized
DEBUG - 2020-11-14 09:17:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-14 09:17:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-14 09:17:21 --> Final output sent to browser
DEBUG - 2020-11-14 09:17:21 --> Total execution time: 0.3292
INFO - 2020-11-14 09:39:26 --> Config Class Initialized
INFO - 2020-11-14 09:39:26 --> Hooks Class Initialized
DEBUG - 2020-11-14 09:39:26 --> UTF-8 Support Enabled
INFO - 2020-11-14 09:39:26 --> Utf8 Class Initialized
INFO - 2020-11-14 09:39:26 --> URI Class Initialized
INFO - 2020-11-14 09:39:26 --> Router Class Initialized
INFO - 2020-11-14 09:39:26 --> Output Class Initialized
INFO - 2020-11-14 09:39:26 --> Security Class Initialized
DEBUG - 2020-11-14 09:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 09:39:26 --> Input Class Initialized
INFO - 2020-11-14 09:39:26 --> Language Class Initialized
INFO - 2020-11-14 09:39:26 --> Language Class Initialized
INFO - 2020-11-14 09:39:26 --> Config Class Initialized
INFO - 2020-11-14 09:39:26 --> Loader Class Initialized
INFO - 2020-11-14 09:39:27 --> Helper loaded: url_helper
INFO - 2020-11-14 09:39:27 --> Helper loaded: file_helper
INFO - 2020-11-14 09:39:27 --> Helper loaded: form_helper
INFO - 2020-11-14 09:39:27 --> Helper loaded: my_helper
INFO - 2020-11-14 09:39:27 --> Database Driver Class Initialized
DEBUG - 2020-11-14 09:39:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-14 09:39:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 09:39:27 --> Controller Class Initialized
DEBUG - 2020-11-14 09:39:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-14 09:39:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-14 09:39:27 --> Final output sent to browser
DEBUG - 2020-11-14 09:39:27 --> Total execution time: 0.2273
