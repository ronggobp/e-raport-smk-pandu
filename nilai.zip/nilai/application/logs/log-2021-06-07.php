<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-06-07 02:37:44 --> Config Class Initialized
INFO - 2021-06-07 02:37:44 --> Hooks Class Initialized
DEBUG - 2021-06-07 02:37:44 --> UTF-8 Support Enabled
INFO - 2021-06-07 02:37:44 --> Utf8 Class Initialized
INFO - 2021-06-07 02:37:44 --> URI Class Initialized
INFO - 2021-06-07 02:37:45 --> Router Class Initialized
INFO - 2021-06-07 02:37:45 --> Output Class Initialized
INFO - 2021-06-07 02:37:45 --> Security Class Initialized
DEBUG - 2021-06-07 02:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 02:37:45 --> Input Class Initialized
INFO - 2021-06-07 02:37:45 --> Language Class Initialized
INFO - 2021-06-07 02:37:45 --> Language Class Initialized
INFO - 2021-06-07 02:37:45 --> Config Class Initialized
INFO - 2021-06-07 02:37:45 --> Loader Class Initialized
INFO - 2021-06-07 02:37:45 --> Helper loaded: url_helper
INFO - 2021-06-07 02:37:45 --> Helper loaded: file_helper
INFO - 2021-06-07 02:37:45 --> Helper loaded: form_helper
INFO - 2021-06-07 02:37:45 --> Helper loaded: my_helper
INFO - 2021-06-07 02:37:45 --> Database Driver Class Initialized
DEBUG - 2021-06-07 02:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 02:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 02:37:45 --> Controller Class Initialized
DEBUG - 2021-06-07 02:37:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-07 02:37:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-07 02:37:45 --> Final output sent to browser
DEBUG - 2021-06-07 02:37:45 --> Total execution time: 0.6737
INFO - 2021-06-07 02:38:03 --> Config Class Initialized
INFO - 2021-06-07 02:38:03 --> Hooks Class Initialized
DEBUG - 2021-06-07 02:38:03 --> UTF-8 Support Enabled
INFO - 2021-06-07 02:38:03 --> Utf8 Class Initialized
INFO - 2021-06-07 02:38:03 --> URI Class Initialized
DEBUG - 2021-06-07 02:38:03 --> No URI present. Default controller set.
INFO - 2021-06-07 02:38:03 --> Router Class Initialized
INFO - 2021-06-07 02:38:03 --> Output Class Initialized
INFO - 2021-06-07 02:38:03 --> Security Class Initialized
DEBUG - 2021-06-07 02:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 02:38:03 --> Input Class Initialized
INFO - 2021-06-07 02:38:03 --> Language Class Initialized
INFO - 2021-06-07 02:38:03 --> Language Class Initialized
INFO - 2021-06-07 02:38:03 --> Config Class Initialized
INFO - 2021-06-07 02:38:03 --> Loader Class Initialized
INFO - 2021-06-07 02:38:03 --> Helper loaded: url_helper
INFO - 2021-06-07 02:38:03 --> Helper loaded: file_helper
INFO - 2021-06-07 02:38:03 --> Helper loaded: form_helper
INFO - 2021-06-07 02:38:03 --> Helper loaded: my_helper
INFO - 2021-06-07 02:38:03 --> Database Driver Class Initialized
DEBUG - 2021-06-07 02:38:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 02:38:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 02:38:03 --> Controller Class Initialized
INFO - 2021-06-07 02:38:03 --> Config Class Initialized
INFO - 2021-06-07 02:38:03 --> Hooks Class Initialized
DEBUG - 2021-06-07 02:38:03 --> UTF-8 Support Enabled
INFO - 2021-06-07 02:38:03 --> Utf8 Class Initialized
INFO - 2021-06-07 02:38:03 --> URI Class Initialized
INFO - 2021-06-07 02:38:03 --> Router Class Initialized
INFO - 2021-06-07 02:38:03 --> Output Class Initialized
INFO - 2021-06-07 02:38:03 --> Security Class Initialized
DEBUG - 2021-06-07 02:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 02:38:03 --> Input Class Initialized
INFO - 2021-06-07 02:38:03 --> Language Class Initialized
INFO - 2021-06-07 02:38:03 --> Language Class Initialized
INFO - 2021-06-07 02:38:03 --> Config Class Initialized
INFO - 2021-06-07 02:38:03 --> Loader Class Initialized
INFO - 2021-06-07 02:38:03 --> Helper loaded: url_helper
INFO - 2021-06-07 02:38:03 --> Helper loaded: file_helper
INFO - 2021-06-07 02:38:03 --> Helper loaded: form_helper
INFO - 2021-06-07 02:38:03 --> Helper loaded: my_helper
INFO - 2021-06-07 02:38:03 --> Database Driver Class Initialized
DEBUG - 2021-06-07 02:38:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 02:38:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 02:38:03 --> Controller Class Initialized
DEBUG - 2021-06-07 02:38:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-07 02:38:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-07 02:38:03 --> Final output sent to browser
DEBUG - 2021-06-07 02:38:03 --> Total execution time: 0.0377
INFO - 2021-06-07 02:38:08 --> Config Class Initialized
INFO - 2021-06-07 02:38:08 --> Hooks Class Initialized
DEBUG - 2021-06-07 02:38:08 --> UTF-8 Support Enabled
INFO - 2021-06-07 02:38:08 --> Utf8 Class Initialized
INFO - 2021-06-07 02:38:08 --> URI Class Initialized
INFO - 2021-06-07 02:38:08 --> Router Class Initialized
INFO - 2021-06-07 02:38:08 --> Output Class Initialized
INFO - 2021-06-07 02:38:08 --> Security Class Initialized
DEBUG - 2021-06-07 02:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 02:38:08 --> Input Class Initialized
INFO - 2021-06-07 02:38:08 --> Language Class Initialized
INFO - 2021-06-07 02:38:08 --> Language Class Initialized
INFO - 2021-06-07 02:38:08 --> Config Class Initialized
INFO - 2021-06-07 02:38:08 --> Loader Class Initialized
INFO - 2021-06-07 02:38:08 --> Helper loaded: url_helper
INFO - 2021-06-07 02:38:08 --> Helper loaded: file_helper
INFO - 2021-06-07 02:38:08 --> Helper loaded: form_helper
INFO - 2021-06-07 02:38:08 --> Helper loaded: my_helper
INFO - 2021-06-07 02:38:08 --> Database Driver Class Initialized
DEBUG - 2021-06-07 02:38:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 02:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 02:38:08 --> Controller Class Initialized
DEBUG - 2021-06-07 02:38:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-07 02:38:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-07 02:38:08 --> Final output sent to browser
DEBUG - 2021-06-07 02:38:08 --> Total execution time: 0.0406
INFO - 2021-06-07 02:38:08 --> Config Class Initialized
INFO - 2021-06-07 02:38:08 --> Hooks Class Initialized
DEBUG - 2021-06-07 02:38:08 --> UTF-8 Support Enabled
INFO - 2021-06-07 02:38:08 --> Utf8 Class Initialized
INFO - 2021-06-07 02:38:08 --> URI Class Initialized
INFO - 2021-06-07 02:38:08 --> Router Class Initialized
INFO - 2021-06-07 02:38:08 --> Output Class Initialized
INFO - 2021-06-07 02:38:08 --> Security Class Initialized
DEBUG - 2021-06-07 02:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 02:38:08 --> Input Class Initialized
INFO - 2021-06-07 02:38:08 --> Language Class Initialized
INFO - 2021-06-07 02:38:08 --> Language Class Initialized
INFO - 2021-06-07 02:38:08 --> Config Class Initialized
INFO - 2021-06-07 02:38:08 --> Loader Class Initialized
INFO - 2021-06-07 02:38:08 --> Helper loaded: url_helper
INFO - 2021-06-07 02:38:08 --> Helper loaded: file_helper
INFO - 2021-06-07 02:38:08 --> Helper loaded: form_helper
INFO - 2021-06-07 02:38:08 --> Helper loaded: my_helper
INFO - 2021-06-07 02:38:08 --> Database Driver Class Initialized
DEBUG - 2021-06-07 02:38:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 02:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 02:38:08 --> Controller Class Initialized
INFO - 2021-06-07 02:38:08 --> Final output sent to browser
DEBUG - 2021-06-07 02:38:08 --> Total execution time: 0.0501
INFO - 2021-06-07 02:38:20 --> Config Class Initialized
INFO - 2021-06-07 02:38:20 --> Hooks Class Initialized
DEBUG - 2021-06-07 02:38:20 --> UTF-8 Support Enabled
INFO - 2021-06-07 02:38:20 --> Utf8 Class Initialized
INFO - 2021-06-07 02:38:20 --> URI Class Initialized
DEBUG - 2021-06-07 02:38:20 --> No URI present. Default controller set.
INFO - 2021-06-07 02:38:20 --> Router Class Initialized
INFO - 2021-06-07 02:38:20 --> Output Class Initialized
INFO - 2021-06-07 02:38:20 --> Security Class Initialized
DEBUG - 2021-06-07 02:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 02:38:20 --> Input Class Initialized
INFO - 2021-06-07 02:38:20 --> Language Class Initialized
INFO - 2021-06-07 02:38:20 --> Language Class Initialized
INFO - 2021-06-07 02:38:20 --> Config Class Initialized
INFO - 2021-06-07 02:38:20 --> Loader Class Initialized
INFO - 2021-06-07 02:38:20 --> Helper loaded: url_helper
INFO - 2021-06-07 02:38:20 --> Helper loaded: file_helper
INFO - 2021-06-07 02:38:20 --> Helper loaded: form_helper
INFO - 2021-06-07 02:38:20 --> Helper loaded: my_helper
INFO - 2021-06-07 02:38:20 --> Database Driver Class Initialized
DEBUG - 2021-06-07 02:38:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 02:38:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 02:38:20 --> Controller Class Initialized
INFO - 2021-06-07 02:38:20 --> Config Class Initialized
INFO - 2021-06-07 02:38:20 --> Hooks Class Initialized
DEBUG - 2021-06-07 02:38:20 --> UTF-8 Support Enabled
INFO - 2021-06-07 02:38:20 --> Utf8 Class Initialized
INFO - 2021-06-07 02:38:20 --> URI Class Initialized
INFO - 2021-06-07 02:38:20 --> Router Class Initialized
INFO - 2021-06-07 02:38:20 --> Output Class Initialized
INFO - 2021-06-07 02:38:20 --> Security Class Initialized
DEBUG - 2021-06-07 02:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 02:38:20 --> Input Class Initialized
INFO - 2021-06-07 02:38:20 --> Language Class Initialized
INFO - 2021-06-07 02:38:20 --> Language Class Initialized
INFO - 2021-06-07 02:38:20 --> Config Class Initialized
INFO - 2021-06-07 02:38:20 --> Loader Class Initialized
INFO - 2021-06-07 02:38:20 --> Helper loaded: url_helper
INFO - 2021-06-07 02:38:20 --> Helper loaded: file_helper
INFO - 2021-06-07 02:38:20 --> Helper loaded: form_helper
INFO - 2021-06-07 02:38:20 --> Helper loaded: my_helper
INFO - 2021-06-07 02:38:20 --> Database Driver Class Initialized
DEBUG - 2021-06-07 02:38:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 02:38:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 02:38:20 --> Controller Class Initialized
DEBUG - 2021-06-07 02:38:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-07 02:38:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-07 02:38:20 --> Final output sent to browser
DEBUG - 2021-06-07 02:38:20 --> Total execution time: 0.0392
INFO - 2021-06-07 02:38:33 --> Config Class Initialized
INFO - 2021-06-07 02:38:33 --> Hooks Class Initialized
DEBUG - 2021-06-07 02:38:33 --> UTF-8 Support Enabled
INFO - 2021-06-07 02:38:33 --> Utf8 Class Initialized
INFO - 2021-06-07 02:38:33 --> URI Class Initialized
DEBUG - 2021-06-07 02:38:33 --> No URI present. Default controller set.
INFO - 2021-06-07 02:38:33 --> Router Class Initialized
INFO - 2021-06-07 02:38:33 --> Output Class Initialized
INFO - 2021-06-07 02:38:33 --> Security Class Initialized
DEBUG - 2021-06-07 02:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 02:38:33 --> Input Class Initialized
INFO - 2021-06-07 02:38:33 --> Language Class Initialized
INFO - 2021-06-07 02:38:33 --> Language Class Initialized
INFO - 2021-06-07 02:38:33 --> Config Class Initialized
INFO - 2021-06-07 02:38:33 --> Loader Class Initialized
INFO - 2021-06-07 02:38:33 --> Helper loaded: url_helper
INFO - 2021-06-07 02:38:33 --> Helper loaded: file_helper
INFO - 2021-06-07 02:38:33 --> Helper loaded: form_helper
INFO - 2021-06-07 02:38:33 --> Helper loaded: my_helper
INFO - 2021-06-07 02:38:33 --> Database Driver Class Initialized
DEBUG - 2021-06-07 02:38:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 02:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 02:38:33 --> Controller Class Initialized
INFO - 2021-06-07 02:38:33 --> Config Class Initialized
INFO - 2021-06-07 02:38:33 --> Hooks Class Initialized
DEBUG - 2021-06-07 02:38:33 --> UTF-8 Support Enabled
INFO - 2021-06-07 02:38:33 --> Utf8 Class Initialized
INFO - 2021-06-07 02:38:33 --> URI Class Initialized
INFO - 2021-06-07 02:38:33 --> Router Class Initialized
INFO - 2021-06-07 02:38:33 --> Output Class Initialized
INFO - 2021-06-07 02:38:33 --> Security Class Initialized
DEBUG - 2021-06-07 02:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 02:38:33 --> Input Class Initialized
INFO - 2021-06-07 02:38:33 --> Language Class Initialized
INFO - 2021-06-07 02:38:33 --> Language Class Initialized
INFO - 2021-06-07 02:38:33 --> Config Class Initialized
INFO - 2021-06-07 02:38:33 --> Loader Class Initialized
INFO - 2021-06-07 02:38:33 --> Helper loaded: url_helper
INFO - 2021-06-07 02:38:33 --> Helper loaded: file_helper
INFO - 2021-06-07 02:38:33 --> Helper loaded: form_helper
INFO - 2021-06-07 02:38:33 --> Helper loaded: my_helper
INFO - 2021-06-07 02:38:33 --> Database Driver Class Initialized
DEBUG - 2021-06-07 02:38:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 02:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 02:38:33 --> Controller Class Initialized
DEBUG - 2021-06-07 02:38:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-07 02:38:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-07 02:38:33 --> Final output sent to browser
DEBUG - 2021-06-07 02:38:33 --> Total execution time: 0.0436
INFO - 2021-06-07 02:38:46 --> Config Class Initialized
INFO - 2021-06-07 02:38:46 --> Hooks Class Initialized
DEBUG - 2021-06-07 02:38:46 --> UTF-8 Support Enabled
INFO - 2021-06-07 02:38:46 --> Utf8 Class Initialized
INFO - 2021-06-07 02:38:46 --> URI Class Initialized
DEBUG - 2021-06-07 02:38:46 --> No URI present. Default controller set.
INFO - 2021-06-07 02:38:46 --> Router Class Initialized
INFO - 2021-06-07 02:38:46 --> Output Class Initialized
INFO - 2021-06-07 02:38:46 --> Security Class Initialized
DEBUG - 2021-06-07 02:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 02:38:46 --> Input Class Initialized
INFO - 2021-06-07 02:38:46 --> Language Class Initialized
INFO - 2021-06-07 02:38:46 --> Language Class Initialized
INFO - 2021-06-07 02:38:46 --> Config Class Initialized
INFO - 2021-06-07 02:38:46 --> Loader Class Initialized
INFO - 2021-06-07 02:38:46 --> Helper loaded: url_helper
INFO - 2021-06-07 02:38:46 --> Helper loaded: file_helper
INFO - 2021-06-07 02:38:46 --> Helper loaded: form_helper
INFO - 2021-06-07 02:38:46 --> Helper loaded: my_helper
INFO - 2021-06-07 02:38:46 --> Database Driver Class Initialized
DEBUG - 2021-06-07 02:38:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 02:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 02:38:46 --> Controller Class Initialized
INFO - 2021-06-07 02:38:46 --> Config Class Initialized
INFO - 2021-06-07 02:38:46 --> Hooks Class Initialized
DEBUG - 2021-06-07 02:38:46 --> UTF-8 Support Enabled
INFO - 2021-06-07 02:38:46 --> Utf8 Class Initialized
INFO - 2021-06-07 02:38:46 --> URI Class Initialized
INFO - 2021-06-07 02:38:46 --> Router Class Initialized
INFO - 2021-06-07 02:38:46 --> Output Class Initialized
INFO - 2021-06-07 02:38:46 --> Security Class Initialized
DEBUG - 2021-06-07 02:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 02:38:46 --> Input Class Initialized
INFO - 2021-06-07 02:38:46 --> Language Class Initialized
INFO - 2021-06-07 02:38:46 --> Language Class Initialized
INFO - 2021-06-07 02:38:46 --> Config Class Initialized
INFO - 2021-06-07 02:38:46 --> Loader Class Initialized
INFO - 2021-06-07 02:38:46 --> Helper loaded: url_helper
INFO - 2021-06-07 02:38:46 --> Helper loaded: file_helper
INFO - 2021-06-07 02:38:46 --> Helper loaded: form_helper
INFO - 2021-06-07 02:38:46 --> Helper loaded: my_helper
INFO - 2021-06-07 02:38:46 --> Database Driver Class Initialized
DEBUG - 2021-06-07 02:38:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 02:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 02:38:46 --> Controller Class Initialized
DEBUG - 2021-06-07 02:38:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-07 02:38:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-07 02:38:46 --> Final output sent to browser
DEBUG - 2021-06-07 02:38:46 --> Total execution time: 0.0449
INFO - 2021-06-07 02:39:03 --> Config Class Initialized
INFO - 2021-06-07 02:39:03 --> Hooks Class Initialized
DEBUG - 2021-06-07 02:39:03 --> UTF-8 Support Enabled
INFO - 2021-06-07 02:39:03 --> Utf8 Class Initialized
INFO - 2021-06-07 02:39:03 --> URI Class Initialized
DEBUG - 2021-06-07 02:39:03 --> No URI present. Default controller set.
INFO - 2021-06-07 02:39:03 --> Router Class Initialized
INFO - 2021-06-07 02:39:03 --> Output Class Initialized
INFO - 2021-06-07 02:39:03 --> Security Class Initialized
DEBUG - 2021-06-07 02:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 02:39:03 --> Input Class Initialized
INFO - 2021-06-07 02:39:03 --> Language Class Initialized
INFO - 2021-06-07 02:39:03 --> Language Class Initialized
INFO - 2021-06-07 02:39:03 --> Config Class Initialized
INFO - 2021-06-07 02:39:03 --> Loader Class Initialized
INFO - 2021-06-07 02:39:03 --> Helper loaded: url_helper
INFO - 2021-06-07 02:39:03 --> Helper loaded: file_helper
INFO - 2021-06-07 02:39:03 --> Helper loaded: form_helper
INFO - 2021-06-07 02:39:03 --> Helper loaded: my_helper
INFO - 2021-06-07 02:39:03 --> Database Driver Class Initialized
DEBUG - 2021-06-07 02:39:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 02:39:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 02:39:03 --> Controller Class Initialized
INFO - 2021-06-07 02:39:03 --> Config Class Initialized
INFO - 2021-06-07 02:39:03 --> Hooks Class Initialized
DEBUG - 2021-06-07 02:39:03 --> UTF-8 Support Enabled
INFO - 2021-06-07 02:39:03 --> Utf8 Class Initialized
INFO - 2021-06-07 02:39:03 --> URI Class Initialized
INFO - 2021-06-07 02:39:03 --> Router Class Initialized
INFO - 2021-06-07 02:39:03 --> Output Class Initialized
INFO - 2021-06-07 02:39:03 --> Security Class Initialized
DEBUG - 2021-06-07 02:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 02:39:03 --> Input Class Initialized
INFO - 2021-06-07 02:39:03 --> Language Class Initialized
INFO - 2021-06-07 02:39:03 --> Language Class Initialized
INFO - 2021-06-07 02:39:03 --> Config Class Initialized
INFO - 2021-06-07 02:39:03 --> Loader Class Initialized
INFO - 2021-06-07 02:39:03 --> Helper loaded: url_helper
INFO - 2021-06-07 02:39:03 --> Helper loaded: file_helper
INFO - 2021-06-07 02:39:03 --> Helper loaded: form_helper
INFO - 2021-06-07 02:39:03 --> Helper loaded: my_helper
INFO - 2021-06-07 02:39:03 --> Database Driver Class Initialized
DEBUG - 2021-06-07 02:39:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 02:39:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 02:39:03 --> Controller Class Initialized
DEBUG - 2021-06-07 02:39:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-07 02:39:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-07 02:39:03 --> Final output sent to browser
DEBUG - 2021-06-07 02:39:03 --> Total execution time: 0.0399
INFO - 2021-06-07 02:40:46 --> Config Class Initialized
INFO - 2021-06-07 02:40:46 --> Hooks Class Initialized
DEBUG - 2021-06-07 02:40:46 --> UTF-8 Support Enabled
INFO - 2021-06-07 02:40:46 --> Utf8 Class Initialized
INFO - 2021-06-07 02:40:46 --> URI Class Initialized
DEBUG - 2021-06-07 02:40:46 --> No URI present. Default controller set.
INFO - 2021-06-07 02:40:46 --> Router Class Initialized
INFO - 2021-06-07 02:40:46 --> Output Class Initialized
INFO - 2021-06-07 02:40:46 --> Security Class Initialized
DEBUG - 2021-06-07 02:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 02:40:46 --> Input Class Initialized
INFO - 2021-06-07 02:40:46 --> Language Class Initialized
INFO - 2021-06-07 02:40:46 --> Language Class Initialized
INFO - 2021-06-07 02:40:46 --> Config Class Initialized
INFO - 2021-06-07 02:40:46 --> Loader Class Initialized
INFO - 2021-06-07 02:40:46 --> Helper loaded: url_helper
INFO - 2021-06-07 02:40:46 --> Helper loaded: file_helper
INFO - 2021-06-07 02:40:46 --> Helper loaded: form_helper
INFO - 2021-06-07 02:40:46 --> Helper loaded: my_helper
INFO - 2021-06-07 02:40:46 --> Database Driver Class Initialized
DEBUG - 2021-06-07 02:40:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 02:40:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 02:40:46 --> Controller Class Initialized
INFO - 2021-06-07 02:40:46 --> Config Class Initialized
INFO - 2021-06-07 02:40:46 --> Hooks Class Initialized
DEBUG - 2021-06-07 02:40:46 --> UTF-8 Support Enabled
INFO - 2021-06-07 02:40:46 --> Utf8 Class Initialized
INFO - 2021-06-07 02:40:46 --> URI Class Initialized
INFO - 2021-06-07 02:40:46 --> Router Class Initialized
INFO - 2021-06-07 02:40:46 --> Output Class Initialized
INFO - 2021-06-07 02:40:46 --> Security Class Initialized
DEBUG - 2021-06-07 02:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 02:40:46 --> Input Class Initialized
INFO - 2021-06-07 02:40:46 --> Language Class Initialized
INFO - 2021-06-07 02:40:46 --> Language Class Initialized
INFO - 2021-06-07 02:40:46 --> Config Class Initialized
INFO - 2021-06-07 02:40:46 --> Loader Class Initialized
INFO - 2021-06-07 02:40:46 --> Helper loaded: url_helper
INFO - 2021-06-07 02:40:46 --> Helper loaded: file_helper
INFO - 2021-06-07 02:40:46 --> Helper loaded: form_helper
INFO - 2021-06-07 02:40:46 --> Helper loaded: my_helper
INFO - 2021-06-07 02:40:46 --> Database Driver Class Initialized
DEBUG - 2021-06-07 02:40:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 02:40:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 02:40:46 --> Controller Class Initialized
DEBUG - 2021-06-07 02:40:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-07 02:40:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-07 02:40:46 --> Final output sent to browser
DEBUG - 2021-06-07 02:40:46 --> Total execution time: 0.0517
INFO - 2021-06-07 02:41:03 --> Config Class Initialized
INFO - 2021-06-07 02:41:03 --> Hooks Class Initialized
DEBUG - 2021-06-07 02:41:03 --> UTF-8 Support Enabled
INFO - 2021-06-07 02:41:03 --> Utf8 Class Initialized
INFO - 2021-06-07 02:41:03 --> URI Class Initialized
DEBUG - 2021-06-07 02:41:03 --> No URI present. Default controller set.
INFO - 2021-06-07 02:41:03 --> Router Class Initialized
INFO - 2021-06-07 02:41:03 --> Output Class Initialized
INFO - 2021-06-07 02:41:03 --> Security Class Initialized
DEBUG - 2021-06-07 02:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 02:41:03 --> Input Class Initialized
INFO - 2021-06-07 02:41:03 --> Language Class Initialized
INFO - 2021-06-07 02:41:03 --> Language Class Initialized
INFO - 2021-06-07 02:41:03 --> Config Class Initialized
INFO - 2021-06-07 02:41:03 --> Loader Class Initialized
INFO - 2021-06-07 02:41:03 --> Helper loaded: url_helper
INFO - 2021-06-07 02:41:03 --> Helper loaded: file_helper
INFO - 2021-06-07 02:41:03 --> Helper loaded: form_helper
INFO - 2021-06-07 02:41:03 --> Helper loaded: my_helper
INFO - 2021-06-07 02:41:03 --> Database Driver Class Initialized
DEBUG - 2021-06-07 02:41:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 02:41:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 02:41:03 --> Controller Class Initialized
INFO - 2021-06-07 02:41:03 --> Config Class Initialized
INFO - 2021-06-07 02:41:03 --> Hooks Class Initialized
DEBUG - 2021-06-07 02:41:03 --> UTF-8 Support Enabled
INFO - 2021-06-07 02:41:03 --> Utf8 Class Initialized
INFO - 2021-06-07 02:41:03 --> URI Class Initialized
INFO - 2021-06-07 02:41:03 --> Router Class Initialized
INFO - 2021-06-07 02:41:03 --> Output Class Initialized
INFO - 2021-06-07 02:41:03 --> Security Class Initialized
DEBUG - 2021-06-07 02:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 02:41:03 --> Input Class Initialized
INFO - 2021-06-07 02:41:03 --> Language Class Initialized
INFO - 2021-06-07 02:41:03 --> Language Class Initialized
INFO - 2021-06-07 02:41:03 --> Config Class Initialized
INFO - 2021-06-07 02:41:03 --> Loader Class Initialized
INFO - 2021-06-07 02:41:04 --> Helper loaded: url_helper
INFO - 2021-06-07 02:41:04 --> Helper loaded: file_helper
INFO - 2021-06-07 02:41:04 --> Helper loaded: form_helper
INFO - 2021-06-07 02:41:04 --> Helper loaded: my_helper
INFO - 2021-06-07 02:41:04 --> Database Driver Class Initialized
DEBUG - 2021-06-07 02:41:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 02:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 02:41:04 --> Controller Class Initialized
DEBUG - 2021-06-07 02:41:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-07 02:41:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-07 02:41:04 --> Final output sent to browser
DEBUG - 2021-06-07 02:41:04 --> Total execution time: 0.0425
INFO - 2021-06-07 02:41:19 --> Config Class Initialized
INFO - 2021-06-07 02:41:19 --> Hooks Class Initialized
DEBUG - 2021-06-07 02:41:19 --> UTF-8 Support Enabled
INFO - 2021-06-07 02:41:19 --> Utf8 Class Initialized
INFO - 2021-06-07 02:41:19 --> URI Class Initialized
DEBUG - 2021-06-07 02:41:19 --> No URI present. Default controller set.
INFO - 2021-06-07 02:41:19 --> Router Class Initialized
INFO - 2021-06-07 02:41:19 --> Output Class Initialized
INFO - 2021-06-07 02:41:19 --> Security Class Initialized
DEBUG - 2021-06-07 02:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 02:41:19 --> Input Class Initialized
INFO - 2021-06-07 02:41:19 --> Language Class Initialized
INFO - 2021-06-07 02:41:19 --> Language Class Initialized
INFO - 2021-06-07 02:41:19 --> Config Class Initialized
INFO - 2021-06-07 02:41:19 --> Loader Class Initialized
INFO - 2021-06-07 02:41:19 --> Helper loaded: url_helper
INFO - 2021-06-07 02:41:19 --> Helper loaded: file_helper
INFO - 2021-06-07 02:41:19 --> Helper loaded: form_helper
INFO - 2021-06-07 02:41:19 --> Helper loaded: my_helper
INFO - 2021-06-07 02:41:19 --> Database Driver Class Initialized
DEBUG - 2021-06-07 02:41:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 02:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 02:41:19 --> Controller Class Initialized
INFO - 2021-06-07 02:41:19 --> Config Class Initialized
INFO - 2021-06-07 02:41:19 --> Hooks Class Initialized
DEBUG - 2021-06-07 02:41:19 --> UTF-8 Support Enabled
INFO - 2021-06-07 02:41:19 --> Utf8 Class Initialized
INFO - 2021-06-07 02:41:19 --> URI Class Initialized
INFO - 2021-06-07 02:41:19 --> Router Class Initialized
INFO - 2021-06-07 02:41:19 --> Output Class Initialized
INFO - 2021-06-07 02:41:19 --> Security Class Initialized
DEBUG - 2021-06-07 02:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 02:41:19 --> Input Class Initialized
INFO - 2021-06-07 02:41:19 --> Language Class Initialized
INFO - 2021-06-07 02:41:19 --> Language Class Initialized
INFO - 2021-06-07 02:41:19 --> Config Class Initialized
INFO - 2021-06-07 02:41:19 --> Loader Class Initialized
INFO - 2021-06-07 02:41:19 --> Helper loaded: url_helper
INFO - 2021-06-07 02:41:19 --> Helper loaded: file_helper
INFO - 2021-06-07 02:41:19 --> Helper loaded: form_helper
INFO - 2021-06-07 02:41:19 --> Helper loaded: my_helper
INFO - 2021-06-07 02:41:19 --> Database Driver Class Initialized
DEBUG - 2021-06-07 02:41:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 02:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 02:41:19 --> Controller Class Initialized
DEBUG - 2021-06-07 02:41:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-07 02:41:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-07 02:41:19 --> Final output sent to browser
DEBUG - 2021-06-07 02:41:19 --> Total execution time: 0.0501
INFO - 2021-06-07 02:41:31 --> Config Class Initialized
INFO - 2021-06-07 02:41:31 --> Hooks Class Initialized
DEBUG - 2021-06-07 02:41:31 --> UTF-8 Support Enabled
INFO - 2021-06-07 02:41:31 --> Utf8 Class Initialized
INFO - 2021-06-07 02:41:31 --> URI Class Initialized
DEBUG - 2021-06-07 02:41:31 --> No URI present. Default controller set.
INFO - 2021-06-07 02:41:31 --> Router Class Initialized
INFO - 2021-06-07 02:41:31 --> Output Class Initialized
INFO - 2021-06-07 02:41:31 --> Security Class Initialized
DEBUG - 2021-06-07 02:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 02:41:31 --> Input Class Initialized
INFO - 2021-06-07 02:41:31 --> Language Class Initialized
INFO - 2021-06-07 02:41:31 --> Language Class Initialized
INFO - 2021-06-07 02:41:31 --> Config Class Initialized
INFO - 2021-06-07 02:41:31 --> Loader Class Initialized
INFO - 2021-06-07 02:41:31 --> Helper loaded: url_helper
INFO - 2021-06-07 02:41:31 --> Helper loaded: file_helper
INFO - 2021-06-07 02:41:31 --> Helper loaded: form_helper
INFO - 2021-06-07 02:41:31 --> Helper loaded: my_helper
INFO - 2021-06-07 02:41:31 --> Database Driver Class Initialized
DEBUG - 2021-06-07 02:41:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 02:41:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 02:41:31 --> Controller Class Initialized
INFO - 2021-06-07 02:41:31 --> Config Class Initialized
INFO - 2021-06-07 02:41:31 --> Hooks Class Initialized
DEBUG - 2021-06-07 02:41:31 --> UTF-8 Support Enabled
INFO - 2021-06-07 02:41:31 --> Utf8 Class Initialized
INFO - 2021-06-07 02:41:31 --> URI Class Initialized
INFO - 2021-06-07 02:41:31 --> Router Class Initialized
INFO - 2021-06-07 02:41:31 --> Output Class Initialized
INFO - 2021-06-07 02:41:31 --> Security Class Initialized
DEBUG - 2021-06-07 02:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 02:41:31 --> Input Class Initialized
INFO - 2021-06-07 02:41:31 --> Language Class Initialized
INFO - 2021-06-07 02:41:31 --> Language Class Initialized
INFO - 2021-06-07 02:41:31 --> Config Class Initialized
INFO - 2021-06-07 02:41:31 --> Loader Class Initialized
INFO - 2021-06-07 02:41:31 --> Helper loaded: url_helper
INFO - 2021-06-07 02:41:31 --> Helper loaded: file_helper
INFO - 2021-06-07 02:41:31 --> Helper loaded: form_helper
INFO - 2021-06-07 02:41:31 --> Helper loaded: my_helper
INFO - 2021-06-07 02:41:31 --> Database Driver Class Initialized
DEBUG - 2021-06-07 02:41:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 02:41:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 02:41:31 --> Controller Class Initialized
DEBUG - 2021-06-07 02:41:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-07 02:41:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-07 02:41:31 --> Final output sent to browser
DEBUG - 2021-06-07 02:41:31 --> Total execution time: 0.0406
INFO - 2021-06-07 02:42:02 --> Config Class Initialized
INFO - 2021-06-07 02:42:02 --> Hooks Class Initialized
DEBUG - 2021-06-07 02:42:02 --> UTF-8 Support Enabled
INFO - 2021-06-07 02:42:02 --> Utf8 Class Initialized
INFO - 2021-06-07 02:42:02 --> URI Class Initialized
INFO - 2021-06-07 02:42:02 --> Router Class Initialized
INFO - 2021-06-07 02:42:02 --> Output Class Initialized
INFO - 2021-06-07 02:42:02 --> Security Class Initialized
DEBUG - 2021-06-07 02:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 02:42:02 --> Input Class Initialized
INFO - 2021-06-07 02:42:02 --> Language Class Initialized
INFO - 2021-06-07 02:42:02 --> Language Class Initialized
INFO - 2021-06-07 02:42:02 --> Config Class Initialized
INFO - 2021-06-07 02:42:02 --> Loader Class Initialized
INFO - 2021-06-07 02:42:02 --> Helper loaded: url_helper
INFO - 2021-06-07 02:42:02 --> Helper loaded: file_helper
INFO - 2021-06-07 02:42:02 --> Helper loaded: form_helper
INFO - 2021-06-07 02:42:02 --> Helper loaded: my_helper
INFO - 2021-06-07 02:42:02 --> Database Driver Class Initialized
DEBUG - 2021-06-07 02:42:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 02:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 02:42:02 --> Controller Class Initialized
INFO - 2021-06-07 02:42:02 --> Final output sent to browser
DEBUG - 2021-06-07 02:42:02 --> Total execution time: 0.0513
INFO - 2021-06-07 02:45:08 --> Config Class Initialized
INFO - 2021-06-07 02:45:08 --> Hooks Class Initialized
DEBUG - 2021-06-07 02:45:08 --> UTF-8 Support Enabled
INFO - 2021-06-07 02:45:08 --> Utf8 Class Initialized
INFO - 2021-06-07 02:45:08 --> URI Class Initialized
INFO - 2021-06-07 02:45:08 --> Router Class Initialized
INFO - 2021-06-07 02:45:08 --> Output Class Initialized
INFO - 2021-06-07 02:45:08 --> Security Class Initialized
DEBUG - 2021-06-07 02:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 02:45:08 --> Input Class Initialized
INFO - 2021-06-07 02:45:08 --> Language Class Initialized
INFO - 2021-06-07 02:45:08 --> Language Class Initialized
INFO - 2021-06-07 02:45:08 --> Config Class Initialized
INFO - 2021-06-07 02:45:08 --> Loader Class Initialized
INFO - 2021-06-07 02:45:08 --> Helper loaded: url_helper
INFO - 2021-06-07 02:45:08 --> Helper loaded: file_helper
INFO - 2021-06-07 02:45:08 --> Helper loaded: form_helper
INFO - 2021-06-07 02:45:08 --> Helper loaded: my_helper
INFO - 2021-06-07 02:45:08 --> Database Driver Class Initialized
DEBUG - 2021-06-07 02:45:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 02:45:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 02:45:08 --> Controller Class Initialized
INFO - 2021-06-07 02:45:08 --> Final output sent to browser
DEBUG - 2021-06-07 02:45:08 --> Total execution time: 0.0470
INFO - 2021-06-07 02:45:37 --> Config Class Initialized
INFO - 2021-06-07 02:45:37 --> Hooks Class Initialized
DEBUG - 2021-06-07 02:45:37 --> UTF-8 Support Enabled
INFO - 2021-06-07 02:45:37 --> Utf8 Class Initialized
INFO - 2021-06-07 02:45:37 --> URI Class Initialized
INFO - 2021-06-07 02:45:37 --> Router Class Initialized
INFO - 2021-06-07 02:45:37 --> Output Class Initialized
INFO - 2021-06-07 02:45:37 --> Security Class Initialized
DEBUG - 2021-06-07 02:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 02:45:37 --> Input Class Initialized
INFO - 2021-06-07 02:45:37 --> Language Class Initialized
INFO - 2021-06-07 02:45:37 --> Language Class Initialized
INFO - 2021-06-07 02:45:37 --> Config Class Initialized
INFO - 2021-06-07 02:45:37 --> Loader Class Initialized
INFO - 2021-06-07 02:45:37 --> Helper loaded: url_helper
INFO - 2021-06-07 02:45:37 --> Helper loaded: file_helper
INFO - 2021-06-07 02:45:37 --> Helper loaded: form_helper
INFO - 2021-06-07 02:45:37 --> Helper loaded: my_helper
INFO - 2021-06-07 02:45:37 --> Database Driver Class Initialized
DEBUG - 2021-06-07 02:45:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 02:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 02:45:37 --> Controller Class Initialized
INFO - 2021-06-07 02:45:37 --> Final output sent to browser
DEBUG - 2021-06-07 02:45:37 --> Total execution time: 0.0441
INFO - 2021-06-07 02:46:43 --> Config Class Initialized
INFO - 2021-06-07 02:46:43 --> Hooks Class Initialized
DEBUG - 2021-06-07 02:46:43 --> UTF-8 Support Enabled
INFO - 2021-06-07 02:46:43 --> Utf8 Class Initialized
INFO - 2021-06-07 02:46:43 --> URI Class Initialized
INFO - 2021-06-07 02:46:43 --> Router Class Initialized
INFO - 2021-06-07 02:46:43 --> Output Class Initialized
INFO - 2021-06-07 02:46:43 --> Security Class Initialized
DEBUG - 2021-06-07 02:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 02:46:43 --> Input Class Initialized
INFO - 2021-06-07 02:46:43 --> Language Class Initialized
INFO - 2021-06-07 02:46:43 --> Language Class Initialized
INFO - 2021-06-07 02:46:43 --> Config Class Initialized
INFO - 2021-06-07 02:46:43 --> Loader Class Initialized
INFO - 2021-06-07 02:46:43 --> Helper loaded: url_helper
INFO - 2021-06-07 02:46:43 --> Helper loaded: file_helper
INFO - 2021-06-07 02:46:43 --> Helper loaded: form_helper
INFO - 2021-06-07 02:46:43 --> Helper loaded: my_helper
INFO - 2021-06-07 02:46:43 --> Database Driver Class Initialized
DEBUG - 2021-06-07 02:46:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 02:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 02:46:43 --> Controller Class Initialized
INFO - 2021-06-07 02:46:43 --> Final output sent to browser
DEBUG - 2021-06-07 02:46:43 --> Total execution time: 0.0440
INFO - 2021-06-07 02:48:49 --> Config Class Initialized
INFO - 2021-06-07 02:48:49 --> Hooks Class Initialized
DEBUG - 2021-06-07 02:48:49 --> UTF-8 Support Enabled
INFO - 2021-06-07 02:48:49 --> Utf8 Class Initialized
INFO - 2021-06-07 02:48:49 --> URI Class Initialized
INFO - 2021-06-07 02:48:49 --> Router Class Initialized
INFO - 2021-06-07 02:48:49 --> Output Class Initialized
INFO - 2021-06-07 02:48:49 --> Security Class Initialized
DEBUG - 2021-06-07 02:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 02:48:49 --> Input Class Initialized
INFO - 2021-06-07 02:48:49 --> Language Class Initialized
INFO - 2021-06-07 02:48:49 --> Language Class Initialized
INFO - 2021-06-07 02:48:49 --> Config Class Initialized
INFO - 2021-06-07 02:48:49 --> Loader Class Initialized
INFO - 2021-06-07 02:48:49 --> Helper loaded: url_helper
INFO - 2021-06-07 02:48:49 --> Helper loaded: file_helper
INFO - 2021-06-07 02:48:49 --> Helper loaded: form_helper
INFO - 2021-06-07 02:48:49 --> Helper loaded: my_helper
INFO - 2021-06-07 02:48:49 --> Database Driver Class Initialized
DEBUG - 2021-06-07 02:48:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 02:48:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 02:48:49 --> Controller Class Initialized
INFO - 2021-06-07 02:48:49 --> Final output sent to browser
DEBUG - 2021-06-07 02:48:49 --> Total execution time: 0.0502
INFO - 2021-06-07 02:48:56 --> Config Class Initialized
INFO - 2021-06-07 02:48:56 --> Hooks Class Initialized
DEBUG - 2021-06-07 02:48:56 --> UTF-8 Support Enabled
INFO - 2021-06-07 02:48:56 --> Utf8 Class Initialized
INFO - 2021-06-07 02:48:56 --> URI Class Initialized
INFO - 2021-06-07 02:48:56 --> Router Class Initialized
INFO - 2021-06-07 02:48:56 --> Output Class Initialized
INFO - 2021-06-07 02:48:56 --> Security Class Initialized
DEBUG - 2021-06-07 02:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 02:48:56 --> Input Class Initialized
INFO - 2021-06-07 02:48:56 --> Language Class Initialized
INFO - 2021-06-07 02:48:56 --> Language Class Initialized
INFO - 2021-06-07 02:48:56 --> Config Class Initialized
INFO - 2021-06-07 02:48:56 --> Loader Class Initialized
INFO - 2021-06-07 02:48:56 --> Helper loaded: url_helper
INFO - 2021-06-07 02:48:56 --> Helper loaded: file_helper
INFO - 2021-06-07 02:48:56 --> Helper loaded: form_helper
INFO - 2021-06-07 02:48:56 --> Helper loaded: my_helper
INFO - 2021-06-07 02:48:56 --> Database Driver Class Initialized
DEBUG - 2021-06-07 02:48:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 02:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 02:48:56 --> Controller Class Initialized
INFO - 2021-06-07 02:48:56 --> Final output sent to browser
DEBUG - 2021-06-07 02:48:56 --> Total execution time: 0.0484
INFO - 2021-06-07 02:49:34 --> Config Class Initialized
INFO - 2021-06-07 02:49:34 --> Hooks Class Initialized
DEBUG - 2021-06-07 02:49:34 --> UTF-8 Support Enabled
INFO - 2021-06-07 02:49:34 --> Utf8 Class Initialized
INFO - 2021-06-07 02:49:34 --> URI Class Initialized
INFO - 2021-06-07 02:49:34 --> Router Class Initialized
INFO - 2021-06-07 02:49:34 --> Output Class Initialized
INFO - 2021-06-07 02:49:34 --> Security Class Initialized
DEBUG - 2021-06-07 02:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 02:49:34 --> Input Class Initialized
INFO - 2021-06-07 02:49:34 --> Language Class Initialized
INFO - 2021-06-07 02:49:34 --> Language Class Initialized
INFO - 2021-06-07 02:49:34 --> Config Class Initialized
INFO - 2021-06-07 02:49:34 --> Loader Class Initialized
INFO - 2021-06-07 02:49:34 --> Helper loaded: url_helper
INFO - 2021-06-07 02:49:34 --> Helper loaded: file_helper
INFO - 2021-06-07 02:49:34 --> Helper loaded: form_helper
INFO - 2021-06-07 02:49:34 --> Helper loaded: my_helper
INFO - 2021-06-07 02:49:34 --> Database Driver Class Initialized
DEBUG - 2021-06-07 02:49:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 02:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 02:49:34 --> Controller Class Initialized
INFO - 2021-06-07 02:49:34 --> Final output sent to browser
DEBUG - 2021-06-07 02:49:34 --> Total execution time: 0.0391
INFO - 2021-06-07 02:51:13 --> Config Class Initialized
INFO - 2021-06-07 02:51:13 --> Hooks Class Initialized
DEBUG - 2021-06-07 02:51:13 --> UTF-8 Support Enabled
INFO - 2021-06-07 02:51:13 --> Utf8 Class Initialized
INFO - 2021-06-07 02:51:13 --> URI Class Initialized
INFO - 2021-06-07 02:51:13 --> Router Class Initialized
INFO - 2021-06-07 02:51:13 --> Output Class Initialized
INFO - 2021-06-07 02:51:13 --> Security Class Initialized
DEBUG - 2021-06-07 02:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 02:51:13 --> Input Class Initialized
INFO - 2021-06-07 02:51:13 --> Language Class Initialized
INFO - 2021-06-07 02:51:13 --> Language Class Initialized
INFO - 2021-06-07 02:51:13 --> Config Class Initialized
INFO - 2021-06-07 02:51:13 --> Loader Class Initialized
INFO - 2021-06-07 02:51:13 --> Helper loaded: url_helper
INFO - 2021-06-07 02:51:13 --> Helper loaded: file_helper
INFO - 2021-06-07 02:51:13 --> Helper loaded: form_helper
INFO - 2021-06-07 02:51:13 --> Helper loaded: my_helper
INFO - 2021-06-07 02:51:13 --> Database Driver Class Initialized
DEBUG - 2021-06-07 02:51:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 02:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 02:51:13 --> Controller Class Initialized
DEBUG - 2021-06-07 02:51:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-07 02:51:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-07 02:51:13 --> Final output sent to browser
DEBUG - 2021-06-07 02:51:13 --> Total execution time: 0.0429
INFO - 2021-06-07 02:52:18 --> Config Class Initialized
INFO - 2021-06-07 02:52:18 --> Hooks Class Initialized
DEBUG - 2021-06-07 02:52:18 --> UTF-8 Support Enabled
INFO - 2021-06-07 02:52:18 --> Utf8 Class Initialized
INFO - 2021-06-07 02:52:18 --> URI Class Initialized
INFO - 2021-06-07 02:52:18 --> Router Class Initialized
INFO - 2021-06-07 02:52:18 --> Output Class Initialized
INFO - 2021-06-07 02:52:18 --> Security Class Initialized
DEBUG - 2021-06-07 02:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 02:52:18 --> Input Class Initialized
INFO - 2021-06-07 02:52:18 --> Language Class Initialized
INFO - 2021-06-07 02:52:18 --> Language Class Initialized
INFO - 2021-06-07 02:52:18 --> Config Class Initialized
INFO - 2021-06-07 02:52:18 --> Loader Class Initialized
INFO - 2021-06-07 02:52:18 --> Helper loaded: url_helper
INFO - 2021-06-07 02:52:18 --> Helper loaded: file_helper
INFO - 2021-06-07 02:52:18 --> Helper loaded: form_helper
INFO - 2021-06-07 02:52:18 --> Helper loaded: my_helper
INFO - 2021-06-07 02:52:18 --> Database Driver Class Initialized
DEBUG - 2021-06-07 02:52:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 02:52:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 02:52:18 --> Controller Class Initialized
DEBUG - 2021-06-07 02:52:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-07 02:52:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-07 02:52:18 --> Final output sent to browser
DEBUG - 2021-06-07 02:52:18 --> Total execution time: 0.0456
INFO - 2021-06-07 02:52:58 --> Config Class Initialized
INFO - 2021-06-07 02:52:58 --> Hooks Class Initialized
DEBUG - 2021-06-07 02:52:58 --> UTF-8 Support Enabled
INFO - 2021-06-07 02:52:58 --> Utf8 Class Initialized
INFO - 2021-06-07 02:52:58 --> URI Class Initialized
INFO - 2021-06-07 02:52:58 --> Router Class Initialized
INFO - 2021-06-07 02:52:58 --> Output Class Initialized
INFO - 2021-06-07 02:52:58 --> Security Class Initialized
DEBUG - 2021-06-07 02:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 02:52:58 --> Input Class Initialized
INFO - 2021-06-07 02:52:58 --> Language Class Initialized
INFO - 2021-06-07 02:52:58 --> Language Class Initialized
INFO - 2021-06-07 02:52:58 --> Config Class Initialized
INFO - 2021-06-07 02:52:58 --> Loader Class Initialized
INFO - 2021-06-07 02:52:58 --> Helper loaded: url_helper
INFO - 2021-06-07 02:52:58 --> Helper loaded: file_helper
INFO - 2021-06-07 02:52:58 --> Helper loaded: form_helper
INFO - 2021-06-07 02:52:58 --> Helper loaded: my_helper
INFO - 2021-06-07 02:52:58 --> Database Driver Class Initialized
DEBUG - 2021-06-07 02:52:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 02:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 02:52:58 --> Controller Class Initialized
DEBUG - 2021-06-07 02:52:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-07 02:52:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-07 02:52:58 --> Final output sent to browser
DEBUG - 2021-06-07 02:52:58 --> Total execution time: 0.0406
INFO - 2021-06-07 02:53:21 --> Config Class Initialized
INFO - 2021-06-07 02:53:21 --> Hooks Class Initialized
DEBUG - 2021-06-07 02:53:21 --> UTF-8 Support Enabled
INFO - 2021-06-07 02:53:21 --> Utf8 Class Initialized
INFO - 2021-06-07 02:53:21 --> URI Class Initialized
DEBUG - 2021-06-07 02:53:21 --> No URI present. Default controller set.
INFO - 2021-06-07 02:53:21 --> Router Class Initialized
INFO - 2021-06-07 02:53:21 --> Output Class Initialized
INFO - 2021-06-07 02:53:21 --> Security Class Initialized
DEBUG - 2021-06-07 02:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 02:53:21 --> Input Class Initialized
INFO - 2021-06-07 02:53:21 --> Language Class Initialized
INFO - 2021-06-07 02:53:21 --> Language Class Initialized
INFO - 2021-06-07 02:53:21 --> Config Class Initialized
INFO - 2021-06-07 02:53:21 --> Loader Class Initialized
INFO - 2021-06-07 02:53:21 --> Helper loaded: url_helper
INFO - 2021-06-07 02:53:21 --> Helper loaded: file_helper
INFO - 2021-06-07 02:53:21 --> Helper loaded: form_helper
INFO - 2021-06-07 02:53:21 --> Helper loaded: my_helper
INFO - 2021-06-07 02:53:21 --> Database Driver Class Initialized
DEBUG - 2021-06-07 02:53:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 02:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 02:53:21 --> Controller Class Initialized
INFO - 2021-06-07 02:53:21 --> Config Class Initialized
INFO - 2021-06-07 02:53:21 --> Hooks Class Initialized
DEBUG - 2021-06-07 02:53:21 --> UTF-8 Support Enabled
INFO - 2021-06-07 02:53:21 --> Utf8 Class Initialized
INFO - 2021-06-07 02:53:21 --> URI Class Initialized
INFO - 2021-06-07 02:53:21 --> Router Class Initialized
INFO - 2021-06-07 02:53:21 --> Output Class Initialized
INFO - 2021-06-07 02:53:21 --> Security Class Initialized
DEBUG - 2021-06-07 02:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 02:53:21 --> Input Class Initialized
INFO - 2021-06-07 02:53:21 --> Language Class Initialized
INFO - 2021-06-07 02:53:21 --> Language Class Initialized
INFO - 2021-06-07 02:53:21 --> Config Class Initialized
INFO - 2021-06-07 02:53:21 --> Loader Class Initialized
INFO - 2021-06-07 02:53:21 --> Helper loaded: url_helper
INFO - 2021-06-07 02:53:21 --> Helper loaded: file_helper
INFO - 2021-06-07 02:53:21 --> Helper loaded: form_helper
INFO - 2021-06-07 02:53:21 --> Helper loaded: my_helper
INFO - 2021-06-07 02:53:21 --> Database Driver Class Initialized
DEBUG - 2021-06-07 02:53:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 02:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 02:53:21 --> Controller Class Initialized
DEBUG - 2021-06-07 02:53:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-07 02:53:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-07 02:53:21 --> Final output sent to browser
DEBUG - 2021-06-07 02:53:21 --> Total execution time: 0.0405
INFO - 2021-06-07 02:53:44 --> Config Class Initialized
INFO - 2021-06-07 02:53:44 --> Hooks Class Initialized
DEBUG - 2021-06-07 02:53:44 --> UTF-8 Support Enabled
INFO - 2021-06-07 02:53:44 --> Utf8 Class Initialized
INFO - 2021-06-07 02:53:44 --> URI Class Initialized
DEBUG - 2021-06-07 02:53:44 --> No URI present. Default controller set.
INFO - 2021-06-07 02:53:44 --> Router Class Initialized
INFO - 2021-06-07 02:53:44 --> Output Class Initialized
INFO - 2021-06-07 02:53:44 --> Security Class Initialized
DEBUG - 2021-06-07 02:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 02:53:44 --> Input Class Initialized
INFO - 2021-06-07 02:53:44 --> Language Class Initialized
INFO - 2021-06-07 02:53:44 --> Language Class Initialized
INFO - 2021-06-07 02:53:44 --> Config Class Initialized
INFO - 2021-06-07 02:53:44 --> Loader Class Initialized
INFO - 2021-06-07 02:53:44 --> Helper loaded: url_helper
INFO - 2021-06-07 02:53:44 --> Helper loaded: file_helper
INFO - 2021-06-07 02:53:44 --> Helper loaded: form_helper
INFO - 2021-06-07 02:53:44 --> Helper loaded: my_helper
INFO - 2021-06-07 02:53:44 --> Database Driver Class Initialized
DEBUG - 2021-06-07 02:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 02:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 02:53:44 --> Controller Class Initialized
INFO - 2021-06-07 02:53:44 --> Config Class Initialized
INFO - 2021-06-07 02:53:44 --> Hooks Class Initialized
DEBUG - 2021-06-07 02:53:44 --> UTF-8 Support Enabled
INFO - 2021-06-07 02:53:44 --> Utf8 Class Initialized
INFO - 2021-06-07 02:53:44 --> URI Class Initialized
INFO - 2021-06-07 02:53:44 --> Router Class Initialized
INFO - 2021-06-07 02:53:44 --> Output Class Initialized
INFO - 2021-06-07 02:53:44 --> Security Class Initialized
DEBUG - 2021-06-07 02:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 02:53:44 --> Input Class Initialized
INFO - 2021-06-07 02:53:44 --> Language Class Initialized
INFO - 2021-06-07 02:53:44 --> Language Class Initialized
INFO - 2021-06-07 02:53:44 --> Config Class Initialized
INFO - 2021-06-07 02:53:44 --> Loader Class Initialized
INFO - 2021-06-07 02:53:44 --> Helper loaded: url_helper
INFO - 2021-06-07 02:53:44 --> Helper loaded: file_helper
INFO - 2021-06-07 02:53:44 --> Helper loaded: form_helper
INFO - 2021-06-07 02:53:44 --> Helper loaded: my_helper
INFO - 2021-06-07 02:53:44 --> Database Driver Class Initialized
DEBUG - 2021-06-07 02:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 02:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 02:53:44 --> Controller Class Initialized
DEBUG - 2021-06-07 02:53:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-07 02:53:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-07 02:53:44 --> Final output sent to browser
DEBUG - 2021-06-07 02:53:44 --> Total execution time: 0.0382
INFO - 2021-06-07 02:53:58 --> Config Class Initialized
INFO - 2021-06-07 02:53:58 --> Hooks Class Initialized
DEBUG - 2021-06-07 02:53:58 --> UTF-8 Support Enabled
INFO - 2021-06-07 02:53:58 --> Utf8 Class Initialized
INFO - 2021-06-07 02:53:58 --> URI Class Initialized
DEBUG - 2021-06-07 02:53:58 --> No URI present. Default controller set.
INFO - 2021-06-07 02:53:58 --> Router Class Initialized
INFO - 2021-06-07 02:53:58 --> Output Class Initialized
INFO - 2021-06-07 02:53:58 --> Security Class Initialized
DEBUG - 2021-06-07 02:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 02:53:58 --> Input Class Initialized
INFO - 2021-06-07 02:53:58 --> Language Class Initialized
INFO - 2021-06-07 02:53:58 --> Language Class Initialized
INFO - 2021-06-07 02:53:58 --> Config Class Initialized
INFO - 2021-06-07 02:53:58 --> Loader Class Initialized
INFO - 2021-06-07 02:53:58 --> Helper loaded: url_helper
INFO - 2021-06-07 02:53:58 --> Helper loaded: file_helper
INFO - 2021-06-07 02:53:58 --> Helper loaded: form_helper
INFO - 2021-06-07 02:53:58 --> Helper loaded: my_helper
INFO - 2021-06-07 02:53:58 --> Database Driver Class Initialized
DEBUG - 2021-06-07 02:53:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 02:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 02:53:58 --> Controller Class Initialized
INFO - 2021-06-07 02:53:58 --> Config Class Initialized
INFO - 2021-06-07 02:53:58 --> Hooks Class Initialized
DEBUG - 2021-06-07 02:53:58 --> UTF-8 Support Enabled
INFO - 2021-06-07 02:53:58 --> Utf8 Class Initialized
INFO - 2021-06-07 02:53:58 --> URI Class Initialized
INFO - 2021-06-07 02:53:58 --> Router Class Initialized
INFO - 2021-06-07 02:53:58 --> Output Class Initialized
INFO - 2021-06-07 02:53:58 --> Security Class Initialized
DEBUG - 2021-06-07 02:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 02:53:58 --> Input Class Initialized
INFO - 2021-06-07 02:53:58 --> Language Class Initialized
INFO - 2021-06-07 02:53:58 --> Language Class Initialized
INFO - 2021-06-07 02:53:58 --> Config Class Initialized
INFO - 2021-06-07 02:53:58 --> Loader Class Initialized
INFO - 2021-06-07 02:53:58 --> Helper loaded: url_helper
INFO - 2021-06-07 02:53:58 --> Helper loaded: file_helper
INFO - 2021-06-07 02:53:58 --> Helper loaded: form_helper
INFO - 2021-06-07 02:53:58 --> Helper loaded: my_helper
INFO - 2021-06-07 02:53:58 --> Database Driver Class Initialized
DEBUG - 2021-06-07 02:53:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 02:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 02:53:58 --> Controller Class Initialized
DEBUG - 2021-06-07 02:53:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-07 02:53:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-07 02:53:58 --> Final output sent to browser
DEBUG - 2021-06-07 02:53:58 --> Total execution time: 0.0405
INFO - 2021-06-07 02:54:29 --> Config Class Initialized
INFO - 2021-06-07 02:54:29 --> Hooks Class Initialized
DEBUG - 2021-06-07 02:54:29 --> UTF-8 Support Enabled
INFO - 2021-06-07 02:54:29 --> Utf8 Class Initialized
INFO - 2021-06-07 02:54:29 --> URI Class Initialized
DEBUG - 2021-06-07 02:54:29 --> No URI present. Default controller set.
INFO - 2021-06-07 02:54:29 --> Router Class Initialized
INFO - 2021-06-07 02:54:29 --> Output Class Initialized
INFO - 2021-06-07 02:54:29 --> Security Class Initialized
DEBUG - 2021-06-07 02:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 02:54:29 --> Input Class Initialized
INFO - 2021-06-07 02:54:29 --> Language Class Initialized
INFO - 2021-06-07 02:54:29 --> Language Class Initialized
INFO - 2021-06-07 02:54:29 --> Config Class Initialized
INFO - 2021-06-07 02:54:29 --> Loader Class Initialized
INFO - 2021-06-07 02:54:29 --> Helper loaded: url_helper
INFO - 2021-06-07 02:54:29 --> Helper loaded: file_helper
INFO - 2021-06-07 02:54:29 --> Helper loaded: form_helper
INFO - 2021-06-07 02:54:29 --> Helper loaded: my_helper
INFO - 2021-06-07 02:54:29 --> Database Driver Class Initialized
DEBUG - 2021-06-07 02:54:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 02:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 02:54:29 --> Controller Class Initialized
INFO - 2021-06-07 02:54:29 --> Config Class Initialized
INFO - 2021-06-07 02:54:29 --> Hooks Class Initialized
DEBUG - 2021-06-07 02:54:29 --> UTF-8 Support Enabled
INFO - 2021-06-07 02:54:29 --> Utf8 Class Initialized
INFO - 2021-06-07 02:54:29 --> URI Class Initialized
INFO - 2021-06-07 02:54:29 --> Router Class Initialized
INFO - 2021-06-07 02:54:29 --> Output Class Initialized
INFO - 2021-06-07 02:54:29 --> Security Class Initialized
DEBUG - 2021-06-07 02:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 02:54:29 --> Input Class Initialized
INFO - 2021-06-07 02:54:29 --> Language Class Initialized
INFO - 2021-06-07 02:54:29 --> Language Class Initialized
INFO - 2021-06-07 02:54:29 --> Config Class Initialized
INFO - 2021-06-07 02:54:29 --> Loader Class Initialized
INFO - 2021-06-07 02:54:29 --> Helper loaded: url_helper
INFO - 2021-06-07 02:54:29 --> Helper loaded: file_helper
INFO - 2021-06-07 02:54:29 --> Helper loaded: form_helper
INFO - 2021-06-07 02:54:29 --> Helper loaded: my_helper
INFO - 2021-06-07 02:54:29 --> Database Driver Class Initialized
DEBUG - 2021-06-07 02:54:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 02:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 02:54:29 --> Controller Class Initialized
DEBUG - 2021-06-07 02:54:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-07 02:54:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-07 02:54:29 --> Final output sent to browser
DEBUG - 2021-06-07 02:54:29 --> Total execution time: 0.0463
INFO - 2021-06-07 02:54:40 --> Config Class Initialized
INFO - 2021-06-07 02:54:40 --> Hooks Class Initialized
DEBUG - 2021-06-07 02:54:40 --> UTF-8 Support Enabled
INFO - 2021-06-07 02:54:40 --> Utf8 Class Initialized
INFO - 2021-06-07 02:54:40 --> URI Class Initialized
INFO - 2021-06-07 02:54:40 --> Router Class Initialized
INFO - 2021-06-07 02:54:40 --> Output Class Initialized
INFO - 2021-06-07 02:54:40 --> Security Class Initialized
DEBUG - 2021-06-07 02:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 02:54:40 --> Input Class Initialized
INFO - 2021-06-07 02:54:40 --> Language Class Initialized
INFO - 2021-06-07 02:54:40 --> Language Class Initialized
INFO - 2021-06-07 02:54:40 --> Config Class Initialized
INFO - 2021-06-07 02:54:40 --> Loader Class Initialized
INFO - 2021-06-07 02:54:40 --> Helper loaded: url_helper
INFO - 2021-06-07 02:54:40 --> Helper loaded: file_helper
INFO - 2021-06-07 02:54:40 --> Helper loaded: form_helper
INFO - 2021-06-07 02:54:40 --> Helper loaded: my_helper
INFO - 2021-06-07 02:54:40 --> Database Driver Class Initialized
DEBUG - 2021-06-07 02:54:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 02:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 02:54:40 --> Controller Class Initialized
INFO - 2021-06-07 02:54:40 --> Final output sent to browser
DEBUG - 2021-06-07 02:54:40 --> Total execution time: 0.0436
INFO - 2021-06-07 02:54:59 --> Config Class Initialized
INFO - 2021-06-07 02:54:59 --> Hooks Class Initialized
DEBUG - 2021-06-07 02:54:59 --> UTF-8 Support Enabled
INFO - 2021-06-07 02:54:59 --> Utf8 Class Initialized
INFO - 2021-06-07 02:54:59 --> URI Class Initialized
INFO - 2021-06-07 02:54:59 --> Router Class Initialized
INFO - 2021-06-07 02:54:59 --> Output Class Initialized
INFO - 2021-06-07 02:54:59 --> Security Class Initialized
DEBUG - 2021-06-07 02:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 02:54:59 --> Input Class Initialized
INFO - 2021-06-07 02:54:59 --> Language Class Initialized
INFO - 2021-06-07 02:54:59 --> Language Class Initialized
INFO - 2021-06-07 02:54:59 --> Config Class Initialized
INFO - 2021-06-07 02:54:59 --> Loader Class Initialized
INFO - 2021-06-07 02:54:59 --> Helper loaded: url_helper
INFO - 2021-06-07 02:54:59 --> Helper loaded: file_helper
INFO - 2021-06-07 02:54:59 --> Helper loaded: form_helper
INFO - 2021-06-07 02:54:59 --> Helper loaded: my_helper
INFO - 2021-06-07 02:54:59 --> Database Driver Class Initialized
DEBUG - 2021-06-07 02:54:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 02:54:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 02:54:59 --> Controller Class Initialized
INFO - 2021-06-07 02:54:59 --> Final output sent to browser
DEBUG - 2021-06-07 02:54:59 --> Total execution time: 0.0497
INFO - 2021-06-07 02:55:07 --> Config Class Initialized
INFO - 2021-06-07 02:55:07 --> Hooks Class Initialized
DEBUG - 2021-06-07 02:55:07 --> UTF-8 Support Enabled
INFO - 2021-06-07 02:55:07 --> Utf8 Class Initialized
INFO - 2021-06-07 02:55:07 --> URI Class Initialized
DEBUG - 2021-06-07 02:55:07 --> No URI present. Default controller set.
INFO - 2021-06-07 02:55:07 --> Router Class Initialized
INFO - 2021-06-07 02:55:07 --> Output Class Initialized
INFO - 2021-06-07 02:55:07 --> Security Class Initialized
DEBUG - 2021-06-07 02:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 02:55:07 --> Input Class Initialized
INFO - 2021-06-07 02:55:07 --> Language Class Initialized
INFO - 2021-06-07 02:55:07 --> Language Class Initialized
INFO - 2021-06-07 02:55:07 --> Config Class Initialized
INFO - 2021-06-07 02:55:07 --> Loader Class Initialized
INFO - 2021-06-07 02:55:07 --> Helper loaded: url_helper
INFO - 2021-06-07 02:55:07 --> Helper loaded: file_helper
INFO - 2021-06-07 02:55:07 --> Helper loaded: form_helper
INFO - 2021-06-07 02:55:07 --> Helper loaded: my_helper
INFO - 2021-06-07 02:55:07 --> Database Driver Class Initialized
DEBUG - 2021-06-07 02:55:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 02:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 02:55:07 --> Controller Class Initialized
INFO - 2021-06-07 02:55:07 --> Config Class Initialized
INFO - 2021-06-07 02:55:07 --> Hooks Class Initialized
DEBUG - 2021-06-07 02:55:07 --> UTF-8 Support Enabled
INFO - 2021-06-07 02:55:07 --> Utf8 Class Initialized
INFO - 2021-06-07 02:55:07 --> URI Class Initialized
INFO - 2021-06-07 02:55:07 --> Router Class Initialized
INFO - 2021-06-07 02:55:07 --> Output Class Initialized
INFO - 2021-06-07 02:55:07 --> Security Class Initialized
DEBUG - 2021-06-07 02:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 02:55:07 --> Input Class Initialized
INFO - 2021-06-07 02:55:07 --> Language Class Initialized
INFO - 2021-06-07 02:55:07 --> Language Class Initialized
INFO - 2021-06-07 02:55:07 --> Config Class Initialized
INFO - 2021-06-07 02:55:07 --> Loader Class Initialized
INFO - 2021-06-07 02:55:07 --> Helper loaded: url_helper
INFO - 2021-06-07 02:55:07 --> Helper loaded: file_helper
INFO - 2021-06-07 02:55:07 --> Helper loaded: form_helper
INFO - 2021-06-07 02:55:07 --> Helper loaded: my_helper
INFO - 2021-06-07 02:55:07 --> Database Driver Class Initialized
DEBUG - 2021-06-07 02:55:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 02:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 02:55:07 --> Controller Class Initialized
DEBUG - 2021-06-07 02:55:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-07 02:55:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-07 02:55:07 --> Final output sent to browser
DEBUG - 2021-06-07 02:55:07 --> Total execution time: 0.0497
INFO - 2021-06-07 02:55:16 --> Config Class Initialized
INFO - 2021-06-07 02:55:16 --> Hooks Class Initialized
DEBUG - 2021-06-07 02:55:16 --> UTF-8 Support Enabled
INFO - 2021-06-07 02:55:16 --> Utf8 Class Initialized
INFO - 2021-06-07 02:55:16 --> URI Class Initialized
INFO - 2021-06-07 02:55:16 --> Router Class Initialized
INFO - 2021-06-07 02:55:16 --> Output Class Initialized
INFO - 2021-06-07 02:55:16 --> Security Class Initialized
DEBUG - 2021-06-07 02:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 02:55:16 --> Input Class Initialized
INFO - 2021-06-07 02:55:16 --> Language Class Initialized
INFO - 2021-06-07 02:55:16 --> Language Class Initialized
INFO - 2021-06-07 02:55:16 --> Config Class Initialized
INFO - 2021-06-07 02:55:16 --> Loader Class Initialized
INFO - 2021-06-07 02:55:16 --> Helper loaded: url_helper
INFO - 2021-06-07 02:55:16 --> Helper loaded: file_helper
INFO - 2021-06-07 02:55:16 --> Helper loaded: form_helper
INFO - 2021-06-07 02:55:16 --> Helper loaded: my_helper
INFO - 2021-06-07 02:55:16 --> Database Driver Class Initialized
DEBUG - 2021-06-07 02:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 02:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 02:55:16 --> Controller Class Initialized
INFO - 2021-06-07 02:55:16 --> Final output sent to browser
DEBUG - 2021-06-07 02:55:16 --> Total execution time: 0.0400
INFO - 2021-06-07 02:55:26 --> Config Class Initialized
INFO - 2021-06-07 02:55:26 --> Hooks Class Initialized
DEBUG - 2021-06-07 02:55:26 --> UTF-8 Support Enabled
INFO - 2021-06-07 02:55:26 --> Utf8 Class Initialized
INFO - 2021-06-07 02:55:26 --> URI Class Initialized
INFO - 2021-06-07 02:55:26 --> Router Class Initialized
INFO - 2021-06-07 02:55:26 --> Output Class Initialized
INFO - 2021-06-07 02:55:26 --> Security Class Initialized
DEBUG - 2021-06-07 02:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 02:55:26 --> Input Class Initialized
INFO - 2021-06-07 02:55:26 --> Language Class Initialized
INFO - 2021-06-07 02:55:26 --> Language Class Initialized
INFO - 2021-06-07 02:55:26 --> Config Class Initialized
INFO - 2021-06-07 02:55:26 --> Loader Class Initialized
INFO - 2021-06-07 02:55:26 --> Helper loaded: url_helper
INFO - 2021-06-07 02:55:26 --> Helper loaded: file_helper
INFO - 2021-06-07 02:55:26 --> Helper loaded: form_helper
INFO - 2021-06-07 02:55:26 --> Helper loaded: my_helper
INFO - 2021-06-07 02:55:26 --> Database Driver Class Initialized
DEBUG - 2021-06-07 02:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 02:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 02:55:26 --> Controller Class Initialized
INFO - 2021-06-07 02:55:26 --> Final output sent to browser
DEBUG - 2021-06-07 02:55:26 --> Total execution time: 0.0385
INFO - 2021-06-07 02:55:27 --> Config Class Initialized
INFO - 2021-06-07 02:55:27 --> Hooks Class Initialized
DEBUG - 2021-06-07 02:55:27 --> UTF-8 Support Enabled
INFO - 2021-06-07 02:55:27 --> Utf8 Class Initialized
INFO - 2021-06-07 02:55:27 --> URI Class Initialized
DEBUG - 2021-06-07 02:55:27 --> No URI present. Default controller set.
INFO - 2021-06-07 02:55:27 --> Router Class Initialized
INFO - 2021-06-07 02:55:27 --> Output Class Initialized
INFO - 2021-06-07 02:55:27 --> Security Class Initialized
DEBUG - 2021-06-07 02:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 02:55:27 --> Input Class Initialized
INFO - 2021-06-07 02:55:27 --> Language Class Initialized
INFO - 2021-06-07 02:55:27 --> Language Class Initialized
INFO - 2021-06-07 02:55:27 --> Config Class Initialized
INFO - 2021-06-07 02:55:27 --> Loader Class Initialized
INFO - 2021-06-07 02:55:27 --> Helper loaded: url_helper
INFO - 2021-06-07 02:55:27 --> Helper loaded: file_helper
INFO - 2021-06-07 02:55:27 --> Helper loaded: form_helper
INFO - 2021-06-07 02:55:27 --> Helper loaded: my_helper
INFO - 2021-06-07 02:55:27 --> Database Driver Class Initialized
DEBUG - 2021-06-07 02:55:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 02:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 02:55:27 --> Controller Class Initialized
INFO - 2021-06-07 02:55:27 --> Config Class Initialized
INFO - 2021-06-07 02:55:27 --> Hooks Class Initialized
DEBUG - 2021-06-07 02:55:27 --> UTF-8 Support Enabled
INFO - 2021-06-07 02:55:27 --> Utf8 Class Initialized
INFO - 2021-06-07 02:55:27 --> URI Class Initialized
INFO - 2021-06-07 02:55:27 --> Router Class Initialized
INFO - 2021-06-07 02:55:27 --> Output Class Initialized
INFO - 2021-06-07 02:55:27 --> Security Class Initialized
DEBUG - 2021-06-07 02:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 02:55:27 --> Input Class Initialized
INFO - 2021-06-07 02:55:27 --> Language Class Initialized
INFO - 2021-06-07 02:55:27 --> Language Class Initialized
INFO - 2021-06-07 02:55:27 --> Config Class Initialized
INFO - 2021-06-07 02:55:27 --> Loader Class Initialized
INFO - 2021-06-07 02:55:27 --> Helper loaded: url_helper
INFO - 2021-06-07 02:55:27 --> Helper loaded: file_helper
INFO - 2021-06-07 02:55:27 --> Helper loaded: form_helper
INFO - 2021-06-07 02:55:27 --> Helper loaded: my_helper
INFO - 2021-06-07 02:55:27 --> Database Driver Class Initialized
DEBUG - 2021-06-07 02:55:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 02:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 02:55:27 --> Controller Class Initialized
DEBUG - 2021-06-07 02:55:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-07 02:55:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-07 02:55:27 --> Final output sent to browser
DEBUG - 2021-06-07 02:55:27 --> Total execution time: 0.0500
INFO - 2021-06-07 02:55:27 --> Config Class Initialized
INFO - 2021-06-07 02:55:27 --> Hooks Class Initialized
DEBUG - 2021-06-07 02:55:27 --> UTF-8 Support Enabled
INFO - 2021-06-07 02:55:27 --> Utf8 Class Initialized
INFO - 2021-06-07 02:55:27 --> URI Class Initialized
INFO - 2021-06-07 02:55:27 --> Router Class Initialized
INFO - 2021-06-07 02:55:27 --> Output Class Initialized
INFO - 2021-06-07 02:55:27 --> Security Class Initialized
DEBUG - 2021-06-07 02:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 02:55:27 --> Input Class Initialized
INFO - 2021-06-07 02:55:27 --> Language Class Initialized
INFO - 2021-06-07 02:55:27 --> Language Class Initialized
INFO - 2021-06-07 02:55:27 --> Config Class Initialized
INFO - 2021-06-07 02:55:27 --> Loader Class Initialized
INFO - 2021-06-07 02:55:27 --> Helper loaded: url_helper
INFO - 2021-06-07 02:55:27 --> Helper loaded: file_helper
INFO - 2021-06-07 02:55:27 --> Helper loaded: form_helper
INFO - 2021-06-07 02:55:27 --> Helper loaded: my_helper
INFO - 2021-06-07 02:55:27 --> Database Driver Class Initialized
DEBUG - 2021-06-07 02:55:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 02:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 02:55:27 --> Controller Class Initialized
INFO - 2021-06-07 02:55:27 --> Final output sent to browser
DEBUG - 2021-06-07 02:55:27 --> Total execution time: 0.0493
INFO - 2021-06-07 02:55:49 --> Config Class Initialized
INFO - 2021-06-07 02:55:49 --> Hooks Class Initialized
DEBUG - 2021-06-07 02:55:49 --> UTF-8 Support Enabled
INFO - 2021-06-07 02:55:49 --> Utf8 Class Initialized
INFO - 2021-06-07 02:55:49 --> URI Class Initialized
INFO - 2021-06-07 02:55:49 --> Router Class Initialized
INFO - 2021-06-07 02:55:49 --> Output Class Initialized
INFO - 2021-06-07 02:55:49 --> Security Class Initialized
DEBUG - 2021-06-07 02:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 02:55:49 --> Input Class Initialized
INFO - 2021-06-07 02:55:49 --> Language Class Initialized
INFO - 2021-06-07 02:55:49 --> Language Class Initialized
INFO - 2021-06-07 02:55:49 --> Config Class Initialized
INFO - 2021-06-07 02:55:49 --> Loader Class Initialized
INFO - 2021-06-07 02:55:49 --> Helper loaded: url_helper
INFO - 2021-06-07 02:55:49 --> Helper loaded: file_helper
INFO - 2021-06-07 02:55:49 --> Helper loaded: form_helper
INFO - 2021-06-07 02:55:49 --> Helper loaded: my_helper
INFO - 2021-06-07 02:55:49 --> Database Driver Class Initialized
DEBUG - 2021-06-07 02:55:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 02:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 02:55:49 --> Controller Class Initialized
INFO - 2021-06-07 02:55:49 --> Final output sent to browser
DEBUG - 2021-06-07 02:55:49 --> Total execution time: 0.0427
INFO - 2021-06-07 02:55:51 --> Config Class Initialized
INFO - 2021-06-07 02:55:51 --> Hooks Class Initialized
DEBUG - 2021-06-07 02:55:51 --> UTF-8 Support Enabled
INFO - 2021-06-07 02:55:51 --> Utf8 Class Initialized
INFO - 2021-06-07 02:55:51 --> URI Class Initialized
INFO - 2021-06-07 02:55:51 --> Router Class Initialized
INFO - 2021-06-07 02:55:51 --> Output Class Initialized
INFO - 2021-06-07 02:55:51 --> Security Class Initialized
DEBUG - 2021-06-07 02:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 02:55:51 --> Input Class Initialized
INFO - 2021-06-07 02:55:51 --> Language Class Initialized
INFO - 2021-06-07 02:55:51 --> Language Class Initialized
INFO - 2021-06-07 02:55:51 --> Config Class Initialized
INFO - 2021-06-07 02:55:51 --> Loader Class Initialized
INFO - 2021-06-07 02:55:51 --> Helper loaded: url_helper
INFO - 2021-06-07 02:55:51 --> Helper loaded: file_helper
INFO - 2021-06-07 02:55:51 --> Helper loaded: form_helper
INFO - 2021-06-07 02:55:51 --> Helper loaded: my_helper
INFO - 2021-06-07 02:55:51 --> Database Driver Class Initialized
DEBUG - 2021-06-07 02:55:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 02:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 02:55:51 --> Controller Class Initialized
INFO - 2021-06-07 02:55:51 --> Final output sent to browser
DEBUG - 2021-06-07 02:55:51 --> Total execution time: 0.0518
INFO - 2021-06-07 02:56:08 --> Config Class Initialized
INFO - 2021-06-07 02:56:08 --> Hooks Class Initialized
DEBUG - 2021-06-07 02:56:08 --> UTF-8 Support Enabled
INFO - 2021-06-07 02:56:08 --> Utf8 Class Initialized
INFO - 2021-06-07 02:56:08 --> URI Class Initialized
INFO - 2021-06-07 02:56:08 --> Router Class Initialized
INFO - 2021-06-07 02:56:08 --> Output Class Initialized
INFO - 2021-06-07 02:56:08 --> Security Class Initialized
DEBUG - 2021-06-07 02:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 02:56:08 --> Input Class Initialized
INFO - 2021-06-07 02:56:08 --> Language Class Initialized
INFO - 2021-06-07 02:56:08 --> Language Class Initialized
INFO - 2021-06-07 02:56:08 --> Config Class Initialized
INFO - 2021-06-07 02:56:08 --> Loader Class Initialized
INFO - 2021-06-07 02:56:08 --> Helper loaded: url_helper
INFO - 2021-06-07 02:56:08 --> Helper loaded: file_helper
INFO - 2021-06-07 02:56:08 --> Helper loaded: form_helper
INFO - 2021-06-07 02:56:08 --> Helper loaded: my_helper
INFO - 2021-06-07 02:56:08 --> Database Driver Class Initialized
DEBUG - 2021-06-07 02:56:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 02:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 02:56:08 --> Controller Class Initialized
INFO - 2021-06-07 02:56:08 --> Final output sent to browser
DEBUG - 2021-06-07 02:56:08 --> Total execution time: 0.0396
INFO - 2021-06-07 02:56:09 --> Config Class Initialized
INFO - 2021-06-07 02:56:09 --> Hooks Class Initialized
DEBUG - 2021-06-07 02:56:09 --> UTF-8 Support Enabled
INFO - 2021-06-07 02:56:09 --> Utf8 Class Initialized
INFO - 2021-06-07 02:56:09 --> URI Class Initialized
INFO - 2021-06-07 02:56:09 --> Router Class Initialized
INFO - 2021-06-07 02:56:09 --> Output Class Initialized
INFO - 2021-06-07 02:56:09 --> Security Class Initialized
DEBUG - 2021-06-07 02:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 02:56:09 --> Input Class Initialized
INFO - 2021-06-07 02:56:09 --> Language Class Initialized
INFO - 2021-06-07 02:56:09 --> Language Class Initialized
INFO - 2021-06-07 02:56:09 --> Config Class Initialized
INFO - 2021-06-07 02:56:09 --> Loader Class Initialized
INFO - 2021-06-07 02:56:09 --> Helper loaded: url_helper
INFO - 2021-06-07 02:56:09 --> Helper loaded: file_helper
INFO - 2021-06-07 02:56:09 --> Helper loaded: form_helper
INFO - 2021-06-07 02:56:09 --> Helper loaded: my_helper
INFO - 2021-06-07 02:56:09 --> Database Driver Class Initialized
DEBUG - 2021-06-07 02:56:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 02:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 02:56:09 --> Controller Class Initialized
INFO - 2021-06-07 02:56:09 --> Final output sent to browser
DEBUG - 2021-06-07 02:56:09 --> Total execution time: 0.0374
INFO - 2021-06-07 02:56:11 --> Config Class Initialized
INFO - 2021-06-07 02:56:11 --> Hooks Class Initialized
DEBUG - 2021-06-07 02:56:11 --> UTF-8 Support Enabled
INFO - 2021-06-07 02:56:11 --> Utf8 Class Initialized
INFO - 2021-06-07 02:56:11 --> URI Class Initialized
DEBUG - 2021-06-07 02:56:11 --> No URI present. Default controller set.
INFO - 2021-06-07 02:56:11 --> Router Class Initialized
INFO - 2021-06-07 02:56:11 --> Output Class Initialized
INFO - 2021-06-07 02:56:11 --> Security Class Initialized
DEBUG - 2021-06-07 02:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 02:56:11 --> Input Class Initialized
INFO - 2021-06-07 02:56:11 --> Language Class Initialized
INFO - 2021-06-07 02:56:11 --> Language Class Initialized
INFO - 2021-06-07 02:56:11 --> Config Class Initialized
INFO - 2021-06-07 02:56:11 --> Loader Class Initialized
INFO - 2021-06-07 02:56:11 --> Helper loaded: url_helper
INFO - 2021-06-07 02:56:11 --> Helper loaded: file_helper
INFO - 2021-06-07 02:56:11 --> Helper loaded: form_helper
INFO - 2021-06-07 02:56:11 --> Helper loaded: my_helper
INFO - 2021-06-07 02:56:11 --> Database Driver Class Initialized
DEBUG - 2021-06-07 02:56:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 02:56:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 02:56:11 --> Controller Class Initialized
INFO - 2021-06-07 02:56:11 --> Config Class Initialized
INFO - 2021-06-07 02:56:11 --> Hooks Class Initialized
DEBUG - 2021-06-07 02:56:11 --> UTF-8 Support Enabled
INFO - 2021-06-07 02:56:11 --> Utf8 Class Initialized
INFO - 2021-06-07 02:56:11 --> URI Class Initialized
INFO - 2021-06-07 02:56:11 --> Router Class Initialized
INFO - 2021-06-07 02:56:11 --> Output Class Initialized
INFO - 2021-06-07 02:56:11 --> Security Class Initialized
DEBUG - 2021-06-07 02:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 02:56:11 --> Input Class Initialized
INFO - 2021-06-07 02:56:11 --> Language Class Initialized
INFO - 2021-06-07 02:56:11 --> Language Class Initialized
INFO - 2021-06-07 02:56:11 --> Config Class Initialized
INFO - 2021-06-07 02:56:11 --> Loader Class Initialized
INFO - 2021-06-07 02:56:11 --> Helper loaded: url_helper
INFO - 2021-06-07 02:56:11 --> Helper loaded: file_helper
INFO - 2021-06-07 02:56:11 --> Helper loaded: form_helper
INFO - 2021-06-07 02:56:11 --> Helper loaded: my_helper
INFO - 2021-06-07 02:56:11 --> Database Driver Class Initialized
DEBUG - 2021-06-07 02:56:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 02:56:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 02:56:11 --> Controller Class Initialized
DEBUG - 2021-06-07 02:56:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-07 02:56:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-07 02:56:11 --> Final output sent to browser
DEBUG - 2021-06-07 02:56:11 --> Total execution time: 0.0454
INFO - 2021-06-07 02:56:11 --> Config Class Initialized
INFO - 2021-06-07 02:56:11 --> Hooks Class Initialized
DEBUG - 2021-06-07 02:56:11 --> UTF-8 Support Enabled
INFO - 2021-06-07 02:56:11 --> Utf8 Class Initialized
INFO - 2021-06-07 02:56:11 --> URI Class Initialized
INFO - 2021-06-07 02:56:11 --> Router Class Initialized
INFO - 2021-06-07 02:56:11 --> Output Class Initialized
INFO - 2021-06-07 02:56:11 --> Security Class Initialized
DEBUG - 2021-06-07 02:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 02:56:11 --> Input Class Initialized
INFO - 2021-06-07 02:56:11 --> Language Class Initialized
INFO - 2021-06-07 02:56:11 --> Language Class Initialized
INFO - 2021-06-07 02:56:11 --> Config Class Initialized
INFO - 2021-06-07 02:56:11 --> Loader Class Initialized
INFO - 2021-06-07 02:56:11 --> Helper loaded: url_helper
INFO - 2021-06-07 02:56:11 --> Helper loaded: file_helper
INFO - 2021-06-07 02:56:11 --> Helper loaded: form_helper
INFO - 2021-06-07 02:56:11 --> Helper loaded: my_helper
INFO - 2021-06-07 02:56:11 --> Database Driver Class Initialized
DEBUG - 2021-06-07 02:56:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 02:56:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 02:56:11 --> Controller Class Initialized
INFO - 2021-06-07 02:56:11 --> Final output sent to browser
DEBUG - 2021-06-07 02:56:11 --> Total execution time: 0.0429
INFO - 2021-06-07 02:56:31 --> Config Class Initialized
INFO - 2021-06-07 02:56:31 --> Hooks Class Initialized
DEBUG - 2021-06-07 02:56:31 --> UTF-8 Support Enabled
INFO - 2021-06-07 02:56:31 --> Utf8 Class Initialized
INFO - 2021-06-07 02:56:31 --> URI Class Initialized
INFO - 2021-06-07 02:56:31 --> Router Class Initialized
INFO - 2021-06-07 02:56:31 --> Output Class Initialized
INFO - 2021-06-07 02:56:31 --> Security Class Initialized
DEBUG - 2021-06-07 02:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 02:56:31 --> Input Class Initialized
INFO - 2021-06-07 02:56:31 --> Language Class Initialized
INFO - 2021-06-07 02:56:31 --> Language Class Initialized
INFO - 2021-06-07 02:56:31 --> Config Class Initialized
INFO - 2021-06-07 02:56:31 --> Loader Class Initialized
INFO - 2021-06-07 02:56:31 --> Helper loaded: url_helper
INFO - 2021-06-07 02:56:31 --> Helper loaded: file_helper
INFO - 2021-06-07 02:56:31 --> Helper loaded: form_helper
INFO - 2021-06-07 02:56:31 --> Helper loaded: my_helper
INFO - 2021-06-07 02:56:31 --> Database Driver Class Initialized
DEBUG - 2021-06-07 02:56:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 02:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 02:56:31 --> Controller Class Initialized
INFO - 2021-06-07 02:56:31 --> Final output sent to browser
DEBUG - 2021-06-07 02:56:31 --> Total execution time: 0.0373
INFO - 2021-06-07 02:57:00 --> Config Class Initialized
INFO - 2021-06-07 02:57:00 --> Hooks Class Initialized
DEBUG - 2021-06-07 02:57:00 --> UTF-8 Support Enabled
INFO - 2021-06-07 02:57:00 --> Utf8 Class Initialized
INFO - 2021-06-07 02:57:00 --> URI Class Initialized
INFO - 2021-06-07 02:57:00 --> Router Class Initialized
INFO - 2021-06-07 02:57:00 --> Output Class Initialized
INFO - 2021-06-07 02:57:00 --> Security Class Initialized
DEBUG - 2021-06-07 02:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 02:57:00 --> Input Class Initialized
INFO - 2021-06-07 02:57:00 --> Language Class Initialized
INFO - 2021-06-07 02:57:00 --> Language Class Initialized
INFO - 2021-06-07 02:57:00 --> Config Class Initialized
INFO - 2021-06-07 02:57:00 --> Loader Class Initialized
INFO - 2021-06-07 02:57:00 --> Helper loaded: url_helper
INFO - 2021-06-07 02:57:00 --> Helper loaded: file_helper
INFO - 2021-06-07 02:57:00 --> Helper loaded: form_helper
INFO - 2021-06-07 02:57:00 --> Helper loaded: my_helper
INFO - 2021-06-07 02:57:00 --> Database Driver Class Initialized
DEBUG - 2021-06-07 02:57:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 02:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 02:57:00 --> Controller Class Initialized
INFO - 2021-06-07 02:57:00 --> Final output sent to browser
DEBUG - 2021-06-07 02:57:00 --> Total execution time: 0.0388
INFO - 2021-06-07 02:57:36 --> Config Class Initialized
INFO - 2021-06-07 02:57:36 --> Hooks Class Initialized
DEBUG - 2021-06-07 02:57:36 --> UTF-8 Support Enabled
INFO - 2021-06-07 02:57:36 --> Utf8 Class Initialized
INFO - 2021-06-07 02:57:36 --> URI Class Initialized
INFO - 2021-06-07 02:57:36 --> Router Class Initialized
INFO - 2021-06-07 02:57:36 --> Output Class Initialized
INFO - 2021-06-07 02:57:36 --> Security Class Initialized
DEBUG - 2021-06-07 02:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 02:57:36 --> Input Class Initialized
INFO - 2021-06-07 02:57:36 --> Language Class Initialized
INFO - 2021-06-07 02:57:36 --> Language Class Initialized
INFO - 2021-06-07 02:57:36 --> Config Class Initialized
INFO - 2021-06-07 02:57:36 --> Loader Class Initialized
INFO - 2021-06-07 02:57:36 --> Helper loaded: url_helper
INFO - 2021-06-07 02:57:36 --> Helper loaded: file_helper
INFO - 2021-06-07 02:57:36 --> Helper loaded: form_helper
INFO - 2021-06-07 02:57:36 --> Helper loaded: my_helper
INFO - 2021-06-07 02:57:36 --> Database Driver Class Initialized
DEBUG - 2021-06-07 02:57:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 02:57:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 02:57:36 --> Controller Class Initialized
INFO - 2021-06-07 02:57:36 --> Final output sent to browser
DEBUG - 2021-06-07 02:57:36 --> Total execution time: 0.0488
INFO - 2021-06-07 02:59:02 --> Config Class Initialized
INFO - 2021-06-07 02:59:02 --> Hooks Class Initialized
DEBUG - 2021-06-07 02:59:02 --> UTF-8 Support Enabled
INFO - 2021-06-07 02:59:02 --> Utf8 Class Initialized
INFO - 2021-06-07 02:59:02 --> URI Class Initialized
INFO - 2021-06-07 02:59:02 --> Router Class Initialized
INFO - 2021-06-07 02:59:02 --> Output Class Initialized
INFO - 2021-06-07 02:59:02 --> Security Class Initialized
DEBUG - 2021-06-07 02:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 02:59:02 --> Input Class Initialized
INFO - 2021-06-07 02:59:02 --> Language Class Initialized
INFO - 2021-06-07 02:59:02 --> Language Class Initialized
INFO - 2021-06-07 02:59:02 --> Config Class Initialized
INFO - 2021-06-07 02:59:02 --> Loader Class Initialized
INFO - 2021-06-07 02:59:02 --> Helper loaded: url_helper
INFO - 2021-06-07 02:59:02 --> Helper loaded: file_helper
INFO - 2021-06-07 02:59:02 --> Helper loaded: form_helper
INFO - 2021-06-07 02:59:02 --> Helper loaded: my_helper
INFO - 2021-06-07 02:59:02 --> Database Driver Class Initialized
DEBUG - 2021-06-07 02:59:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 02:59:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 02:59:02 --> Controller Class Initialized
INFO - 2021-06-07 02:59:02 --> Final output sent to browser
DEBUG - 2021-06-07 02:59:02 --> Total execution time: 0.0429
INFO - 2021-06-07 02:59:13 --> Config Class Initialized
INFO - 2021-06-07 02:59:13 --> Hooks Class Initialized
DEBUG - 2021-06-07 02:59:13 --> UTF-8 Support Enabled
INFO - 2021-06-07 02:59:13 --> Utf8 Class Initialized
INFO - 2021-06-07 02:59:13 --> URI Class Initialized
INFO - 2021-06-07 02:59:13 --> Router Class Initialized
INFO - 2021-06-07 02:59:13 --> Output Class Initialized
INFO - 2021-06-07 02:59:13 --> Security Class Initialized
DEBUG - 2021-06-07 02:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 02:59:13 --> Input Class Initialized
INFO - 2021-06-07 02:59:13 --> Language Class Initialized
ERROR - 2021-06-07 02:59:13 --> 404 Page Not Found: /index
INFO - 2021-06-07 02:59:35 --> Config Class Initialized
INFO - 2021-06-07 02:59:35 --> Hooks Class Initialized
DEBUG - 2021-06-07 02:59:35 --> UTF-8 Support Enabled
INFO - 2021-06-07 02:59:35 --> Utf8 Class Initialized
INFO - 2021-06-07 02:59:35 --> URI Class Initialized
INFO - 2021-06-07 02:59:35 --> Router Class Initialized
INFO - 2021-06-07 02:59:35 --> Output Class Initialized
INFO - 2021-06-07 02:59:35 --> Security Class Initialized
DEBUG - 2021-06-07 02:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 02:59:35 --> Input Class Initialized
INFO - 2021-06-07 02:59:35 --> Language Class Initialized
INFO - 2021-06-07 02:59:35 --> Language Class Initialized
INFO - 2021-06-07 02:59:35 --> Config Class Initialized
INFO - 2021-06-07 02:59:35 --> Loader Class Initialized
INFO - 2021-06-07 02:59:35 --> Helper loaded: url_helper
INFO - 2021-06-07 02:59:35 --> Helper loaded: file_helper
INFO - 2021-06-07 02:59:35 --> Helper loaded: form_helper
INFO - 2021-06-07 02:59:35 --> Helper loaded: my_helper
INFO - 2021-06-07 02:59:35 --> Database Driver Class Initialized
DEBUG - 2021-06-07 02:59:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 02:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 02:59:35 --> Controller Class Initialized
DEBUG - 2021-06-07 02:59:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-07 02:59:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-07 02:59:35 --> Final output sent to browser
DEBUG - 2021-06-07 02:59:35 --> Total execution time: 0.0416
INFO - 2021-06-07 03:00:27 --> Config Class Initialized
INFO - 2021-06-07 03:00:27 --> Hooks Class Initialized
DEBUG - 2021-06-07 03:00:27 --> UTF-8 Support Enabled
INFO - 2021-06-07 03:00:27 --> Utf8 Class Initialized
INFO - 2021-06-07 03:00:27 --> URI Class Initialized
INFO - 2021-06-07 03:00:27 --> Router Class Initialized
INFO - 2021-06-07 03:00:27 --> Output Class Initialized
INFO - 2021-06-07 03:00:27 --> Security Class Initialized
DEBUG - 2021-06-07 03:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 03:00:27 --> Input Class Initialized
INFO - 2021-06-07 03:00:27 --> Language Class Initialized
INFO - 2021-06-07 03:00:27 --> Language Class Initialized
INFO - 2021-06-07 03:00:27 --> Config Class Initialized
INFO - 2021-06-07 03:00:27 --> Loader Class Initialized
INFO - 2021-06-07 03:00:27 --> Helper loaded: url_helper
INFO - 2021-06-07 03:00:27 --> Helper loaded: file_helper
INFO - 2021-06-07 03:00:27 --> Helper loaded: form_helper
INFO - 2021-06-07 03:00:27 --> Helper loaded: my_helper
INFO - 2021-06-07 03:00:27 --> Database Driver Class Initialized
DEBUG - 2021-06-07 03:00:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 03:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 03:00:27 --> Controller Class Initialized
INFO - 2021-06-07 03:00:27 --> Final output sent to browser
DEBUG - 2021-06-07 03:00:27 --> Total execution time: 0.0372
INFO - 2021-06-07 04:29:54 --> Config Class Initialized
INFO - 2021-06-07 04:29:54 --> Hooks Class Initialized
DEBUG - 2021-06-07 04:29:54 --> UTF-8 Support Enabled
INFO - 2021-06-07 04:29:54 --> Utf8 Class Initialized
INFO - 2021-06-07 04:29:54 --> URI Class Initialized
DEBUG - 2021-06-07 04:29:54 --> No URI present. Default controller set.
INFO - 2021-06-07 04:29:54 --> Router Class Initialized
INFO - 2021-06-07 04:29:54 --> Output Class Initialized
INFO - 2021-06-07 04:29:54 --> Security Class Initialized
DEBUG - 2021-06-07 04:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 04:29:54 --> Input Class Initialized
INFO - 2021-06-07 04:29:54 --> Language Class Initialized
INFO - 2021-06-07 04:29:54 --> Language Class Initialized
INFO - 2021-06-07 04:29:54 --> Config Class Initialized
INFO - 2021-06-07 04:29:54 --> Loader Class Initialized
INFO - 2021-06-07 04:29:54 --> Helper loaded: url_helper
INFO - 2021-06-07 04:29:54 --> Helper loaded: file_helper
INFO - 2021-06-07 04:29:54 --> Helper loaded: form_helper
INFO - 2021-06-07 04:29:54 --> Helper loaded: my_helper
INFO - 2021-06-07 04:29:54 --> Database Driver Class Initialized
DEBUG - 2021-06-07 04:29:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 04:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 04:29:54 --> Controller Class Initialized
INFO - 2021-06-07 04:29:54 --> Config Class Initialized
INFO - 2021-06-07 04:29:54 --> Hooks Class Initialized
DEBUG - 2021-06-07 04:29:54 --> UTF-8 Support Enabled
INFO - 2021-06-07 04:29:54 --> Utf8 Class Initialized
INFO - 2021-06-07 04:29:54 --> URI Class Initialized
INFO - 2021-06-07 04:29:54 --> Router Class Initialized
INFO - 2021-06-07 04:29:54 --> Output Class Initialized
INFO - 2021-06-07 04:29:54 --> Security Class Initialized
DEBUG - 2021-06-07 04:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 04:29:54 --> Input Class Initialized
INFO - 2021-06-07 04:29:54 --> Language Class Initialized
INFO - 2021-06-07 04:29:54 --> Language Class Initialized
INFO - 2021-06-07 04:29:54 --> Config Class Initialized
INFO - 2021-06-07 04:29:54 --> Loader Class Initialized
INFO - 2021-06-07 04:29:54 --> Helper loaded: url_helper
INFO - 2021-06-07 04:29:54 --> Helper loaded: file_helper
INFO - 2021-06-07 04:29:54 --> Helper loaded: form_helper
INFO - 2021-06-07 04:29:54 --> Helper loaded: my_helper
INFO - 2021-06-07 04:29:54 --> Database Driver Class Initialized
DEBUG - 2021-06-07 04:29:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 04:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 04:29:54 --> Controller Class Initialized
DEBUG - 2021-06-07 04:29:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-07 04:29:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-07 04:29:54 --> Final output sent to browser
DEBUG - 2021-06-07 04:29:54 --> Total execution time: 0.0487
INFO - 2021-06-07 04:33:11 --> Config Class Initialized
INFO - 2021-06-07 04:33:11 --> Hooks Class Initialized
DEBUG - 2021-06-07 04:33:11 --> UTF-8 Support Enabled
INFO - 2021-06-07 04:33:11 --> Utf8 Class Initialized
INFO - 2021-06-07 04:33:11 --> URI Class Initialized
DEBUG - 2021-06-07 04:33:11 --> No URI present. Default controller set.
INFO - 2021-06-07 04:33:11 --> Router Class Initialized
INFO - 2021-06-07 04:33:11 --> Output Class Initialized
INFO - 2021-06-07 04:33:11 --> Security Class Initialized
DEBUG - 2021-06-07 04:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 04:33:11 --> Input Class Initialized
INFO - 2021-06-07 04:33:11 --> Language Class Initialized
INFO - 2021-06-07 04:33:11 --> Language Class Initialized
INFO - 2021-06-07 04:33:11 --> Config Class Initialized
INFO - 2021-06-07 04:33:11 --> Loader Class Initialized
INFO - 2021-06-07 04:33:11 --> Helper loaded: url_helper
INFO - 2021-06-07 04:33:11 --> Helper loaded: file_helper
INFO - 2021-06-07 04:33:11 --> Helper loaded: form_helper
INFO - 2021-06-07 04:33:11 --> Helper loaded: my_helper
INFO - 2021-06-07 04:33:11 --> Database Driver Class Initialized
DEBUG - 2021-06-07 04:33:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 04:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 04:33:11 --> Controller Class Initialized
INFO - 2021-06-07 04:33:11 --> Config Class Initialized
INFO - 2021-06-07 04:33:11 --> Hooks Class Initialized
DEBUG - 2021-06-07 04:33:11 --> UTF-8 Support Enabled
INFO - 2021-06-07 04:33:11 --> Utf8 Class Initialized
INFO - 2021-06-07 04:33:11 --> URI Class Initialized
INFO - 2021-06-07 04:33:11 --> Router Class Initialized
INFO - 2021-06-07 04:33:11 --> Output Class Initialized
INFO - 2021-06-07 04:33:11 --> Security Class Initialized
DEBUG - 2021-06-07 04:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 04:33:11 --> Input Class Initialized
INFO - 2021-06-07 04:33:11 --> Language Class Initialized
INFO - 2021-06-07 04:33:11 --> Language Class Initialized
INFO - 2021-06-07 04:33:11 --> Config Class Initialized
INFO - 2021-06-07 04:33:11 --> Loader Class Initialized
INFO - 2021-06-07 04:33:11 --> Helper loaded: url_helper
INFO - 2021-06-07 04:33:11 --> Helper loaded: file_helper
INFO - 2021-06-07 04:33:11 --> Helper loaded: form_helper
INFO - 2021-06-07 04:33:11 --> Helper loaded: my_helper
INFO - 2021-06-07 04:33:11 --> Database Driver Class Initialized
DEBUG - 2021-06-07 04:33:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 04:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 04:33:11 --> Controller Class Initialized
DEBUG - 2021-06-07 04:33:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-07 04:33:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-07 04:33:11 --> Final output sent to browser
DEBUG - 2021-06-07 04:33:11 --> Total execution time: 0.0462
INFO - 2021-06-07 05:45:24 --> Config Class Initialized
INFO - 2021-06-07 05:45:24 --> Hooks Class Initialized
DEBUG - 2021-06-07 05:45:24 --> UTF-8 Support Enabled
INFO - 2021-06-07 05:45:24 --> Utf8 Class Initialized
INFO - 2021-06-07 05:45:24 --> URI Class Initialized
INFO - 2021-06-07 05:45:24 --> Router Class Initialized
INFO - 2021-06-07 05:45:24 --> Output Class Initialized
INFO - 2021-06-07 05:45:24 --> Security Class Initialized
DEBUG - 2021-06-07 05:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 05:45:24 --> Input Class Initialized
INFO - 2021-06-07 05:45:24 --> Language Class Initialized
INFO - 2021-06-07 05:45:24 --> Language Class Initialized
INFO - 2021-06-07 05:45:24 --> Config Class Initialized
INFO - 2021-06-07 05:45:24 --> Loader Class Initialized
INFO - 2021-06-07 05:45:24 --> Helper loaded: url_helper
INFO - 2021-06-07 05:45:24 --> Helper loaded: file_helper
INFO - 2021-06-07 05:45:24 --> Helper loaded: form_helper
INFO - 2021-06-07 05:45:24 --> Helper loaded: my_helper
INFO - 2021-06-07 05:45:24 --> Database Driver Class Initialized
DEBUG - 2021-06-07 05:45:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 05:45:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 05:45:24 --> Controller Class Initialized
DEBUG - 2021-06-07 05:45:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-07 05:45:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-07 05:45:24 --> Final output sent to browser
DEBUG - 2021-06-07 05:45:24 --> Total execution time: 0.0407
INFO - 2021-06-07 05:46:43 --> Config Class Initialized
INFO - 2021-06-07 05:46:43 --> Hooks Class Initialized
DEBUG - 2021-06-07 05:46:43 --> UTF-8 Support Enabled
INFO - 2021-06-07 05:46:43 --> Utf8 Class Initialized
INFO - 2021-06-07 05:46:43 --> URI Class Initialized
INFO - 2021-06-07 05:46:43 --> Router Class Initialized
INFO - 2021-06-07 05:46:43 --> Output Class Initialized
INFO - 2021-06-07 05:46:43 --> Security Class Initialized
DEBUG - 2021-06-07 05:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 05:46:43 --> Input Class Initialized
INFO - 2021-06-07 05:46:43 --> Language Class Initialized
INFO - 2021-06-07 05:46:43 --> Language Class Initialized
INFO - 2021-06-07 05:46:43 --> Config Class Initialized
INFO - 2021-06-07 05:46:43 --> Loader Class Initialized
INFO - 2021-06-07 05:46:43 --> Helper loaded: url_helper
INFO - 2021-06-07 05:46:43 --> Helper loaded: file_helper
INFO - 2021-06-07 05:46:43 --> Helper loaded: form_helper
INFO - 2021-06-07 05:46:43 --> Helper loaded: my_helper
INFO - 2021-06-07 05:46:43 --> Database Driver Class Initialized
DEBUG - 2021-06-07 05:46:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 05:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 05:46:43 --> Controller Class Initialized
INFO - 2021-06-07 05:46:43 --> Final output sent to browser
DEBUG - 2021-06-07 05:46:43 --> Total execution time: 0.0461
INFO - 2021-06-07 05:47:25 --> Config Class Initialized
INFO - 2021-06-07 05:47:25 --> Hooks Class Initialized
DEBUG - 2021-06-07 05:47:25 --> UTF-8 Support Enabled
INFO - 2021-06-07 05:47:25 --> Utf8 Class Initialized
INFO - 2021-06-07 05:47:25 --> URI Class Initialized
INFO - 2021-06-07 05:47:25 --> Router Class Initialized
INFO - 2021-06-07 05:47:25 --> Output Class Initialized
INFO - 2021-06-07 05:47:25 --> Security Class Initialized
DEBUG - 2021-06-07 05:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 05:47:25 --> Input Class Initialized
INFO - 2021-06-07 05:47:25 --> Language Class Initialized
INFO - 2021-06-07 05:47:25 --> Language Class Initialized
INFO - 2021-06-07 05:47:25 --> Config Class Initialized
INFO - 2021-06-07 05:47:25 --> Loader Class Initialized
INFO - 2021-06-07 05:47:25 --> Helper loaded: url_helper
INFO - 2021-06-07 05:47:25 --> Helper loaded: file_helper
INFO - 2021-06-07 05:47:25 --> Helper loaded: form_helper
INFO - 2021-06-07 05:47:25 --> Helper loaded: my_helper
INFO - 2021-06-07 05:47:25 --> Database Driver Class Initialized
DEBUG - 2021-06-07 05:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 05:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 05:47:25 --> Controller Class Initialized
INFO - 2021-06-07 05:47:25 --> Final output sent to browser
DEBUG - 2021-06-07 05:47:25 --> Total execution time: 0.0370
