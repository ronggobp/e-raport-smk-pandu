<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-06-16 05:05:56 --> Config Class Initialized
INFO - 2021-06-16 05:05:56 --> Hooks Class Initialized
DEBUG - 2021-06-16 05:05:56 --> UTF-8 Support Enabled
INFO - 2021-06-16 05:05:56 --> Utf8 Class Initialized
INFO - 2021-06-16 05:05:56 --> URI Class Initialized
DEBUG - 2021-06-16 05:05:56 --> No URI present. Default controller set.
INFO - 2021-06-16 05:05:56 --> Router Class Initialized
INFO - 2021-06-16 05:05:56 --> Output Class Initialized
INFO - 2021-06-16 05:05:56 --> Security Class Initialized
DEBUG - 2021-06-16 05:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 05:05:56 --> Input Class Initialized
INFO - 2021-06-16 05:05:56 --> Language Class Initialized
INFO - 2021-06-16 05:05:56 --> Language Class Initialized
INFO - 2021-06-16 05:05:56 --> Config Class Initialized
INFO - 2021-06-16 05:05:56 --> Loader Class Initialized
INFO - 2021-06-16 05:05:56 --> Helper loaded: url_helper
INFO - 2021-06-16 05:05:56 --> Helper loaded: file_helper
INFO - 2021-06-16 05:05:56 --> Helper loaded: form_helper
INFO - 2021-06-16 05:05:56 --> Helper loaded: my_helper
INFO - 2021-06-16 05:05:56 --> Database Driver Class Initialized
DEBUG - 2021-06-16 05:05:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 05:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 05:05:56 --> Controller Class Initialized
INFO - 2021-06-16 05:05:56 --> Config Class Initialized
INFO - 2021-06-16 05:05:56 --> Hooks Class Initialized
DEBUG - 2021-06-16 05:05:56 --> UTF-8 Support Enabled
INFO - 2021-06-16 05:05:56 --> Utf8 Class Initialized
INFO - 2021-06-16 05:05:56 --> URI Class Initialized
INFO - 2021-06-16 05:05:56 --> Router Class Initialized
INFO - 2021-06-16 05:05:56 --> Output Class Initialized
INFO - 2021-06-16 05:05:56 --> Security Class Initialized
DEBUG - 2021-06-16 05:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 05:05:56 --> Input Class Initialized
INFO - 2021-06-16 05:05:56 --> Language Class Initialized
INFO - 2021-06-16 05:05:56 --> Language Class Initialized
INFO - 2021-06-16 05:05:56 --> Config Class Initialized
INFO - 2021-06-16 05:05:56 --> Loader Class Initialized
INFO - 2021-06-16 05:05:56 --> Helper loaded: url_helper
INFO - 2021-06-16 05:05:56 --> Helper loaded: file_helper
INFO - 2021-06-16 05:05:56 --> Helper loaded: form_helper
INFO - 2021-06-16 05:05:56 --> Helper loaded: my_helper
INFO - 2021-06-16 05:05:56 --> Database Driver Class Initialized
DEBUG - 2021-06-16 05:05:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 05:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 05:05:56 --> Controller Class Initialized
DEBUG - 2021-06-16 05:05:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-16 05:05:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-16 05:05:56 --> Final output sent to browser
DEBUG - 2021-06-16 05:05:56 --> Total execution time: 0.0415
INFO - 2021-06-16 05:06:07 --> Config Class Initialized
INFO - 2021-06-16 05:06:07 --> Hooks Class Initialized
DEBUG - 2021-06-16 05:06:07 --> UTF-8 Support Enabled
INFO - 2021-06-16 05:06:07 --> Utf8 Class Initialized
INFO - 2021-06-16 05:06:07 --> URI Class Initialized
INFO - 2021-06-16 05:06:07 --> Router Class Initialized
INFO - 2021-06-16 05:06:07 --> Output Class Initialized
INFO - 2021-06-16 05:06:07 --> Security Class Initialized
DEBUG - 2021-06-16 05:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 05:06:07 --> Input Class Initialized
INFO - 2021-06-16 05:06:07 --> Language Class Initialized
INFO - 2021-06-16 05:06:07 --> Language Class Initialized
INFO - 2021-06-16 05:06:07 --> Config Class Initialized
INFO - 2021-06-16 05:06:07 --> Loader Class Initialized
INFO - 2021-06-16 05:06:07 --> Helper loaded: url_helper
INFO - 2021-06-16 05:06:07 --> Helper loaded: file_helper
INFO - 2021-06-16 05:06:07 --> Helper loaded: form_helper
INFO - 2021-06-16 05:06:07 --> Helper loaded: my_helper
INFO - 2021-06-16 05:06:07 --> Database Driver Class Initialized
DEBUG - 2021-06-16 05:06:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 05:06:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 05:06:07 --> Controller Class Initialized
INFO - 2021-06-16 05:06:07 --> Helper loaded: cookie_helper
INFO - 2021-06-16 05:06:07 --> Final output sent to browser
DEBUG - 2021-06-16 05:06:07 --> Total execution time: 0.0601
INFO - 2021-06-16 05:06:07 --> Config Class Initialized
INFO - 2021-06-16 05:06:07 --> Hooks Class Initialized
DEBUG - 2021-06-16 05:06:07 --> UTF-8 Support Enabled
INFO - 2021-06-16 05:06:07 --> Utf8 Class Initialized
INFO - 2021-06-16 05:06:07 --> URI Class Initialized
INFO - 2021-06-16 05:06:07 --> Router Class Initialized
INFO - 2021-06-16 05:06:07 --> Output Class Initialized
INFO - 2021-06-16 05:06:07 --> Security Class Initialized
DEBUG - 2021-06-16 05:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 05:06:07 --> Input Class Initialized
INFO - 2021-06-16 05:06:07 --> Language Class Initialized
INFO - 2021-06-16 05:06:07 --> Language Class Initialized
INFO - 2021-06-16 05:06:07 --> Config Class Initialized
INFO - 2021-06-16 05:06:07 --> Loader Class Initialized
INFO - 2021-06-16 05:06:07 --> Helper loaded: url_helper
INFO - 2021-06-16 05:06:07 --> Helper loaded: file_helper
INFO - 2021-06-16 05:06:07 --> Helper loaded: form_helper
INFO - 2021-06-16 05:06:07 --> Helper loaded: my_helper
INFO - 2021-06-16 05:06:07 --> Database Driver Class Initialized
DEBUG - 2021-06-16 05:06:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 05:06:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 05:06:07 --> Controller Class Initialized
DEBUG - 2021-06-16 05:06:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-16 05:06:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-16 05:06:08 --> Final output sent to browser
DEBUG - 2021-06-16 05:06:08 --> Total execution time: 0.2662
INFO - 2021-06-16 06:06:53 --> Config Class Initialized
INFO - 2021-06-16 06:06:53 --> Hooks Class Initialized
DEBUG - 2021-06-16 06:06:53 --> UTF-8 Support Enabled
INFO - 2021-06-16 06:06:53 --> Utf8 Class Initialized
INFO - 2021-06-16 06:06:53 --> URI Class Initialized
INFO - 2021-06-16 06:06:53 --> Router Class Initialized
INFO - 2021-06-16 06:06:53 --> Output Class Initialized
INFO - 2021-06-16 06:06:53 --> Security Class Initialized
DEBUG - 2021-06-16 06:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 06:06:53 --> Input Class Initialized
INFO - 2021-06-16 06:06:53 --> Language Class Initialized
INFO - 2021-06-16 06:06:53 --> Language Class Initialized
INFO - 2021-06-16 06:06:53 --> Config Class Initialized
INFO - 2021-06-16 06:06:53 --> Loader Class Initialized
INFO - 2021-06-16 06:06:53 --> Helper loaded: url_helper
INFO - 2021-06-16 06:06:53 --> Helper loaded: file_helper
INFO - 2021-06-16 06:06:53 --> Helper loaded: form_helper
INFO - 2021-06-16 06:06:53 --> Helper loaded: my_helper
INFO - 2021-06-16 06:06:54 --> Database Driver Class Initialized
DEBUG - 2021-06-16 06:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 06:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 06:06:54 --> Controller Class Initialized
INFO - 2021-06-16 06:06:54 --> Helper loaded: cookie_helper
INFO - 2021-06-16 06:06:54 --> Config Class Initialized
INFO - 2021-06-16 06:06:54 --> Hooks Class Initialized
DEBUG - 2021-06-16 06:06:54 --> UTF-8 Support Enabled
INFO - 2021-06-16 06:06:54 --> Utf8 Class Initialized
INFO - 2021-06-16 06:06:54 --> URI Class Initialized
INFO - 2021-06-16 06:06:54 --> Router Class Initialized
INFO - 2021-06-16 06:06:54 --> Output Class Initialized
INFO - 2021-06-16 06:06:54 --> Security Class Initialized
DEBUG - 2021-06-16 06:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 06:06:54 --> Input Class Initialized
INFO - 2021-06-16 06:06:54 --> Language Class Initialized
INFO - 2021-06-16 06:06:54 --> Language Class Initialized
INFO - 2021-06-16 06:06:54 --> Config Class Initialized
INFO - 2021-06-16 06:06:54 --> Loader Class Initialized
INFO - 2021-06-16 06:06:54 --> Helper loaded: url_helper
INFO - 2021-06-16 06:06:54 --> Helper loaded: file_helper
INFO - 2021-06-16 06:06:54 --> Helper loaded: form_helper
INFO - 2021-06-16 06:06:54 --> Helper loaded: my_helper
INFO - 2021-06-16 06:06:54 --> Database Driver Class Initialized
DEBUG - 2021-06-16 06:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 06:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 06:06:54 --> Controller Class Initialized
DEBUG - 2021-06-16 06:06:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-16 06:06:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-16 06:06:54 --> Final output sent to browser
DEBUG - 2021-06-16 06:06:54 --> Total execution time: 0.0389
INFO - 2021-06-16 06:06:57 --> Config Class Initialized
INFO - 2021-06-16 06:06:57 --> Hooks Class Initialized
DEBUG - 2021-06-16 06:06:57 --> UTF-8 Support Enabled
INFO - 2021-06-16 06:06:57 --> Utf8 Class Initialized
INFO - 2021-06-16 06:06:57 --> URI Class Initialized
INFO - 2021-06-16 06:06:57 --> Router Class Initialized
INFO - 2021-06-16 06:06:57 --> Output Class Initialized
INFO - 2021-06-16 06:06:57 --> Security Class Initialized
DEBUG - 2021-06-16 06:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 06:06:57 --> Input Class Initialized
INFO - 2021-06-16 06:06:57 --> Language Class Initialized
INFO - 2021-06-16 06:06:57 --> Language Class Initialized
INFO - 2021-06-16 06:06:57 --> Config Class Initialized
INFO - 2021-06-16 06:06:57 --> Loader Class Initialized
INFO - 2021-06-16 06:06:57 --> Helper loaded: url_helper
INFO - 2021-06-16 06:06:57 --> Helper loaded: file_helper
INFO - 2021-06-16 06:06:57 --> Helper loaded: form_helper
INFO - 2021-06-16 06:06:57 --> Helper loaded: my_helper
INFO - 2021-06-16 06:06:57 --> Database Driver Class Initialized
DEBUG - 2021-06-16 06:06:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 06:06:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 06:06:57 --> Controller Class Initialized
DEBUG - 2021-06-16 06:06:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-16 06:06:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-16 06:06:57 --> Final output sent to browser
DEBUG - 2021-06-16 06:06:57 --> Total execution time: 0.0422
INFO - 2021-06-16 06:07:02 --> Config Class Initialized
INFO - 2021-06-16 06:07:02 --> Hooks Class Initialized
DEBUG - 2021-06-16 06:07:02 --> UTF-8 Support Enabled
INFO - 2021-06-16 06:07:02 --> Utf8 Class Initialized
INFO - 2021-06-16 06:07:02 --> URI Class Initialized
INFO - 2021-06-16 06:07:02 --> Router Class Initialized
INFO - 2021-06-16 06:07:02 --> Output Class Initialized
INFO - 2021-06-16 06:07:02 --> Security Class Initialized
DEBUG - 2021-06-16 06:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 06:07:02 --> Input Class Initialized
INFO - 2021-06-16 06:07:02 --> Language Class Initialized
INFO - 2021-06-16 06:07:02 --> Language Class Initialized
INFO - 2021-06-16 06:07:02 --> Config Class Initialized
INFO - 2021-06-16 06:07:02 --> Loader Class Initialized
INFO - 2021-06-16 06:07:02 --> Helper loaded: url_helper
INFO - 2021-06-16 06:07:02 --> Helper loaded: file_helper
INFO - 2021-06-16 06:07:02 --> Helper loaded: form_helper
INFO - 2021-06-16 06:07:02 --> Helper loaded: my_helper
INFO - 2021-06-16 06:07:02 --> Database Driver Class Initialized
DEBUG - 2021-06-16 06:07:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 06:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 06:07:02 --> Controller Class Initialized
INFO - 2021-06-16 06:07:02 --> Helper loaded: cookie_helper
INFO - 2021-06-16 06:07:02 --> Final output sent to browser
DEBUG - 2021-06-16 06:07:02 --> Total execution time: 0.0525
INFO - 2021-06-16 06:07:02 --> Config Class Initialized
INFO - 2021-06-16 06:07:02 --> Hooks Class Initialized
DEBUG - 2021-06-16 06:07:02 --> UTF-8 Support Enabled
INFO - 2021-06-16 06:07:02 --> Utf8 Class Initialized
INFO - 2021-06-16 06:07:02 --> URI Class Initialized
INFO - 2021-06-16 06:07:02 --> Router Class Initialized
INFO - 2021-06-16 06:07:02 --> Output Class Initialized
INFO - 2021-06-16 06:07:02 --> Security Class Initialized
DEBUG - 2021-06-16 06:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 06:07:02 --> Input Class Initialized
INFO - 2021-06-16 06:07:02 --> Language Class Initialized
INFO - 2021-06-16 06:07:02 --> Language Class Initialized
INFO - 2021-06-16 06:07:02 --> Config Class Initialized
INFO - 2021-06-16 06:07:02 --> Loader Class Initialized
INFO - 2021-06-16 06:07:02 --> Helper loaded: url_helper
INFO - 2021-06-16 06:07:02 --> Helper loaded: file_helper
INFO - 2021-06-16 06:07:02 --> Helper loaded: form_helper
INFO - 2021-06-16 06:07:02 --> Helper loaded: my_helper
INFO - 2021-06-16 06:07:02 --> Database Driver Class Initialized
DEBUG - 2021-06-16 06:07:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 06:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 06:07:02 --> Controller Class Initialized
DEBUG - 2021-06-16 06:07:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-16 06:07:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-16 06:07:02 --> Final output sent to browser
DEBUG - 2021-06-16 06:07:02 --> Total execution time: 0.2202
INFO - 2021-06-16 06:07:10 --> Config Class Initialized
INFO - 2021-06-16 06:07:10 --> Hooks Class Initialized
DEBUG - 2021-06-16 06:07:10 --> UTF-8 Support Enabled
INFO - 2021-06-16 06:07:10 --> Utf8 Class Initialized
INFO - 2021-06-16 06:07:10 --> URI Class Initialized
INFO - 2021-06-16 06:07:10 --> Router Class Initialized
INFO - 2021-06-16 06:07:10 --> Output Class Initialized
INFO - 2021-06-16 06:07:10 --> Security Class Initialized
DEBUG - 2021-06-16 06:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 06:07:10 --> Input Class Initialized
INFO - 2021-06-16 06:07:10 --> Language Class Initialized
INFO - 2021-06-16 06:07:10 --> Language Class Initialized
INFO - 2021-06-16 06:07:10 --> Config Class Initialized
INFO - 2021-06-16 06:07:10 --> Loader Class Initialized
INFO - 2021-06-16 06:07:10 --> Helper loaded: url_helper
INFO - 2021-06-16 06:07:10 --> Helper loaded: file_helper
INFO - 2021-06-16 06:07:10 --> Helper loaded: form_helper
INFO - 2021-06-16 06:07:10 --> Helper loaded: my_helper
INFO - 2021-06-16 06:07:10 --> Database Driver Class Initialized
DEBUG - 2021-06-16 06:07:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 06:07:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 06:07:10 --> Controller Class Initialized
DEBUG - 2021-06-16 06:07:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-16 06:07:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-16 06:07:10 --> Final output sent to browser
DEBUG - 2021-06-16 06:07:10 --> Total execution time: 0.0552
INFO - 2021-06-16 06:07:17 --> Config Class Initialized
INFO - 2021-06-16 06:07:17 --> Hooks Class Initialized
DEBUG - 2021-06-16 06:07:17 --> UTF-8 Support Enabled
INFO - 2021-06-16 06:07:17 --> Utf8 Class Initialized
INFO - 2021-06-16 06:07:17 --> URI Class Initialized
INFO - 2021-06-16 06:07:17 --> Router Class Initialized
INFO - 2021-06-16 06:07:17 --> Output Class Initialized
INFO - 2021-06-16 06:07:17 --> Security Class Initialized
DEBUG - 2021-06-16 06:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 06:07:17 --> Input Class Initialized
INFO - 2021-06-16 06:07:17 --> Language Class Initialized
INFO - 2021-06-16 06:07:17 --> Language Class Initialized
INFO - 2021-06-16 06:07:17 --> Config Class Initialized
INFO - 2021-06-16 06:07:17 --> Loader Class Initialized
INFO - 2021-06-16 06:07:17 --> Helper loaded: url_helper
INFO - 2021-06-16 06:07:17 --> Helper loaded: file_helper
INFO - 2021-06-16 06:07:17 --> Helper loaded: form_helper
INFO - 2021-06-16 06:07:17 --> Helper loaded: my_helper
INFO - 2021-06-16 06:07:17 --> Database Driver Class Initialized
DEBUG - 2021-06-16 06:07:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 06:07:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 06:07:17 --> Controller Class Initialized
DEBUG - 2021-06-16 06:07:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-16 06:07:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-16 06:07:17 --> Final output sent to browser
DEBUG - 2021-06-16 06:07:17 --> Total execution time: 0.0593
INFO - 2021-06-16 06:07:18 --> Config Class Initialized
INFO - 2021-06-16 06:07:18 --> Hooks Class Initialized
DEBUG - 2021-06-16 06:07:18 --> UTF-8 Support Enabled
INFO - 2021-06-16 06:07:18 --> Utf8 Class Initialized
INFO - 2021-06-16 06:07:18 --> URI Class Initialized
INFO - 2021-06-16 06:07:18 --> Router Class Initialized
INFO - 2021-06-16 06:07:18 --> Output Class Initialized
INFO - 2021-06-16 06:07:18 --> Security Class Initialized
DEBUG - 2021-06-16 06:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 06:07:18 --> Input Class Initialized
INFO - 2021-06-16 06:07:18 --> Language Class Initialized
INFO - 2021-06-16 06:07:18 --> Language Class Initialized
INFO - 2021-06-16 06:07:18 --> Config Class Initialized
INFO - 2021-06-16 06:07:18 --> Loader Class Initialized
INFO - 2021-06-16 06:07:18 --> Helper loaded: url_helper
INFO - 2021-06-16 06:07:18 --> Helper loaded: file_helper
INFO - 2021-06-16 06:07:18 --> Helper loaded: form_helper
INFO - 2021-06-16 06:07:18 --> Helper loaded: my_helper
INFO - 2021-06-16 06:07:18 --> Database Driver Class Initialized
DEBUG - 2021-06-16 06:07:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 06:07:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 06:07:18 --> Controller Class Initialized
INFO - 2021-06-16 06:07:22 --> Config Class Initialized
INFO - 2021-06-16 06:07:22 --> Hooks Class Initialized
DEBUG - 2021-06-16 06:07:22 --> UTF-8 Support Enabled
INFO - 2021-06-16 06:07:22 --> Utf8 Class Initialized
INFO - 2021-06-16 06:07:22 --> URI Class Initialized
INFO - 2021-06-16 06:07:22 --> Router Class Initialized
INFO - 2021-06-16 06:07:22 --> Output Class Initialized
INFO - 2021-06-16 06:07:22 --> Security Class Initialized
DEBUG - 2021-06-16 06:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 06:07:22 --> Input Class Initialized
INFO - 2021-06-16 06:07:22 --> Language Class Initialized
INFO - 2021-06-16 06:07:22 --> Language Class Initialized
INFO - 2021-06-16 06:07:22 --> Config Class Initialized
INFO - 2021-06-16 06:07:22 --> Loader Class Initialized
INFO - 2021-06-16 06:07:22 --> Helper loaded: url_helper
INFO - 2021-06-16 06:07:22 --> Helper loaded: file_helper
INFO - 2021-06-16 06:07:22 --> Helper loaded: form_helper
INFO - 2021-06-16 06:07:22 --> Helper loaded: my_helper
INFO - 2021-06-16 06:07:22 --> Database Driver Class Initialized
DEBUG - 2021-06-16 06:07:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 06:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 06:07:22 --> Controller Class Initialized
DEBUG - 2021-06-16 06:07:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2021-06-16 06:07:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-16 06:07:22 --> Final output sent to browser
DEBUG - 2021-06-16 06:07:22 --> Total execution time: 0.0528
INFO - 2021-06-16 06:07:27 --> Config Class Initialized
INFO - 2021-06-16 06:07:27 --> Hooks Class Initialized
DEBUG - 2021-06-16 06:07:27 --> UTF-8 Support Enabled
INFO - 2021-06-16 06:07:27 --> Utf8 Class Initialized
INFO - 2021-06-16 06:07:27 --> URI Class Initialized
INFO - 2021-06-16 06:07:27 --> Router Class Initialized
INFO - 2021-06-16 06:07:27 --> Output Class Initialized
INFO - 2021-06-16 06:07:27 --> Security Class Initialized
DEBUG - 2021-06-16 06:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 06:07:27 --> Input Class Initialized
INFO - 2021-06-16 06:07:27 --> Language Class Initialized
INFO - 2021-06-16 06:07:27 --> Language Class Initialized
INFO - 2021-06-16 06:07:27 --> Config Class Initialized
INFO - 2021-06-16 06:07:27 --> Loader Class Initialized
INFO - 2021-06-16 06:07:27 --> Helper loaded: url_helper
INFO - 2021-06-16 06:07:27 --> Helper loaded: file_helper
INFO - 2021-06-16 06:07:27 --> Helper loaded: form_helper
INFO - 2021-06-16 06:07:27 --> Helper loaded: my_helper
INFO - 2021-06-16 06:07:27 --> Database Driver Class Initialized
DEBUG - 2021-06-16 06:07:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 06:07:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 06:07:27 --> Controller Class Initialized
INFO - 2021-06-16 06:07:27 --> Config Class Initialized
INFO - 2021-06-16 06:07:27 --> Hooks Class Initialized
DEBUG - 2021-06-16 06:07:27 --> UTF-8 Support Enabled
INFO - 2021-06-16 06:07:27 --> Utf8 Class Initialized
INFO - 2021-06-16 06:07:27 --> URI Class Initialized
INFO - 2021-06-16 06:07:27 --> Router Class Initialized
INFO - 2021-06-16 06:07:27 --> Output Class Initialized
INFO - 2021-06-16 06:07:27 --> Security Class Initialized
DEBUG - 2021-06-16 06:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 06:07:27 --> Input Class Initialized
INFO - 2021-06-16 06:07:27 --> Language Class Initialized
INFO - 2021-06-16 06:07:27 --> Language Class Initialized
INFO - 2021-06-16 06:07:27 --> Config Class Initialized
INFO - 2021-06-16 06:07:27 --> Loader Class Initialized
INFO - 2021-06-16 06:07:27 --> Helper loaded: url_helper
INFO - 2021-06-16 06:07:27 --> Helper loaded: file_helper
INFO - 2021-06-16 06:07:27 --> Helper loaded: form_helper
INFO - 2021-06-16 06:07:27 --> Helper loaded: my_helper
INFO - 2021-06-16 06:07:27 --> Database Driver Class Initialized
DEBUG - 2021-06-16 06:07:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 06:07:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 06:07:27 --> Controller Class Initialized
DEBUG - 2021-06-16 06:07:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-16 06:07:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-16 06:07:27 --> Final output sent to browser
DEBUG - 2021-06-16 06:07:27 --> Total execution time: 0.0519
INFO - 2021-06-16 06:07:27 --> Config Class Initialized
INFO - 2021-06-16 06:07:27 --> Hooks Class Initialized
DEBUG - 2021-06-16 06:07:27 --> UTF-8 Support Enabled
INFO - 2021-06-16 06:07:27 --> Utf8 Class Initialized
INFO - 2021-06-16 06:07:27 --> URI Class Initialized
INFO - 2021-06-16 06:07:27 --> Router Class Initialized
INFO - 2021-06-16 06:07:27 --> Output Class Initialized
INFO - 2021-06-16 06:07:27 --> Security Class Initialized
DEBUG - 2021-06-16 06:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 06:07:27 --> Input Class Initialized
INFO - 2021-06-16 06:07:27 --> Language Class Initialized
INFO - 2021-06-16 06:07:27 --> Language Class Initialized
INFO - 2021-06-16 06:07:27 --> Config Class Initialized
INFO - 2021-06-16 06:07:27 --> Loader Class Initialized
INFO - 2021-06-16 06:07:27 --> Helper loaded: url_helper
INFO - 2021-06-16 06:07:27 --> Helper loaded: file_helper
INFO - 2021-06-16 06:07:27 --> Helper loaded: form_helper
INFO - 2021-06-16 06:07:27 --> Helper loaded: my_helper
INFO - 2021-06-16 06:07:27 --> Database Driver Class Initialized
DEBUG - 2021-06-16 06:07:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 06:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 06:07:28 --> Controller Class Initialized
INFO - 2021-06-16 06:07:28 --> Config Class Initialized
INFO - 2021-06-16 06:07:28 --> Hooks Class Initialized
DEBUG - 2021-06-16 06:07:28 --> UTF-8 Support Enabled
INFO - 2021-06-16 06:07:28 --> Utf8 Class Initialized
INFO - 2021-06-16 06:07:28 --> URI Class Initialized
INFO - 2021-06-16 06:07:28 --> Router Class Initialized
INFO - 2021-06-16 06:07:28 --> Output Class Initialized
INFO - 2021-06-16 06:07:28 --> Security Class Initialized
DEBUG - 2021-06-16 06:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 06:07:28 --> Input Class Initialized
INFO - 2021-06-16 06:07:28 --> Language Class Initialized
INFO - 2021-06-16 06:07:28 --> Language Class Initialized
INFO - 2021-06-16 06:07:28 --> Config Class Initialized
INFO - 2021-06-16 06:07:28 --> Loader Class Initialized
INFO - 2021-06-16 06:07:28 --> Helper loaded: url_helper
INFO - 2021-06-16 06:07:28 --> Helper loaded: file_helper
INFO - 2021-06-16 06:07:28 --> Helper loaded: form_helper
INFO - 2021-06-16 06:07:28 --> Helper loaded: my_helper
INFO - 2021-06-16 06:07:28 --> Database Driver Class Initialized
DEBUG - 2021-06-16 06:07:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 06:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 06:07:28 --> Controller Class Initialized
DEBUG - 2021-06-16 06:07:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-16 06:07:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-16 06:07:28 --> Final output sent to browser
DEBUG - 2021-06-16 06:07:28 --> Total execution time: 0.0515
INFO - 2021-06-16 06:07:30 --> Config Class Initialized
INFO - 2021-06-16 06:07:30 --> Hooks Class Initialized
DEBUG - 2021-06-16 06:07:30 --> UTF-8 Support Enabled
INFO - 2021-06-16 06:07:30 --> Utf8 Class Initialized
INFO - 2021-06-16 06:07:30 --> URI Class Initialized
INFO - 2021-06-16 06:07:30 --> Router Class Initialized
INFO - 2021-06-16 06:07:30 --> Output Class Initialized
INFO - 2021-06-16 06:07:30 --> Security Class Initialized
DEBUG - 2021-06-16 06:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 06:07:30 --> Input Class Initialized
INFO - 2021-06-16 06:07:30 --> Language Class Initialized
INFO - 2021-06-16 06:07:30 --> Language Class Initialized
INFO - 2021-06-16 06:07:30 --> Config Class Initialized
INFO - 2021-06-16 06:07:30 --> Loader Class Initialized
INFO - 2021-06-16 06:07:30 --> Helper loaded: url_helper
INFO - 2021-06-16 06:07:30 --> Helper loaded: file_helper
INFO - 2021-06-16 06:07:30 --> Helper loaded: form_helper
INFO - 2021-06-16 06:07:30 --> Helper loaded: my_helper
INFO - 2021-06-16 06:07:30 --> Database Driver Class Initialized
DEBUG - 2021-06-16 06:07:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 06:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 06:07:30 --> Controller Class Initialized
DEBUG - 2021-06-16 06:07:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-16 06:07:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-16 06:07:30 --> Final output sent to browser
DEBUG - 2021-06-16 06:07:30 --> Total execution time: 0.0442
INFO - 2021-06-16 06:07:31 --> Config Class Initialized
INFO - 2021-06-16 06:07:31 --> Hooks Class Initialized
DEBUG - 2021-06-16 06:07:31 --> UTF-8 Support Enabled
INFO - 2021-06-16 06:07:31 --> Utf8 Class Initialized
INFO - 2021-06-16 06:07:31 --> URI Class Initialized
INFO - 2021-06-16 06:07:31 --> Router Class Initialized
INFO - 2021-06-16 06:07:31 --> Output Class Initialized
INFO - 2021-06-16 06:07:31 --> Security Class Initialized
DEBUG - 2021-06-16 06:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 06:07:31 --> Input Class Initialized
INFO - 2021-06-16 06:07:31 --> Language Class Initialized
INFO - 2021-06-16 06:07:31 --> Language Class Initialized
INFO - 2021-06-16 06:07:31 --> Config Class Initialized
INFO - 2021-06-16 06:07:31 --> Loader Class Initialized
INFO - 2021-06-16 06:07:31 --> Helper loaded: url_helper
INFO - 2021-06-16 06:07:31 --> Helper loaded: file_helper
INFO - 2021-06-16 06:07:31 --> Helper loaded: form_helper
INFO - 2021-06-16 06:07:31 --> Helper loaded: my_helper
INFO - 2021-06-16 06:07:31 --> Database Driver Class Initialized
DEBUG - 2021-06-16 06:07:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 06:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 06:07:31 --> Controller Class Initialized
DEBUG - 2021-06-16 06:07:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2021-06-16 06:07:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-16 06:07:31 --> Final output sent to browser
DEBUG - 2021-06-16 06:07:31 --> Total execution time: 0.0545
INFO - 2021-06-16 06:07:35 --> Config Class Initialized
INFO - 2021-06-16 06:07:35 --> Hooks Class Initialized
DEBUG - 2021-06-16 06:07:35 --> UTF-8 Support Enabled
INFO - 2021-06-16 06:07:35 --> Utf8 Class Initialized
INFO - 2021-06-16 06:07:35 --> URI Class Initialized
INFO - 2021-06-16 06:07:35 --> Router Class Initialized
INFO - 2021-06-16 06:07:35 --> Output Class Initialized
INFO - 2021-06-16 06:07:35 --> Security Class Initialized
DEBUG - 2021-06-16 06:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 06:07:35 --> Input Class Initialized
INFO - 2021-06-16 06:07:35 --> Language Class Initialized
INFO - 2021-06-16 06:07:35 --> Language Class Initialized
INFO - 2021-06-16 06:07:35 --> Config Class Initialized
INFO - 2021-06-16 06:07:35 --> Loader Class Initialized
INFO - 2021-06-16 06:07:35 --> Helper loaded: url_helper
INFO - 2021-06-16 06:07:35 --> Helper loaded: file_helper
INFO - 2021-06-16 06:07:35 --> Helper loaded: form_helper
INFO - 2021-06-16 06:07:35 --> Helper loaded: my_helper
INFO - 2021-06-16 06:07:35 --> Database Driver Class Initialized
DEBUG - 2021-06-16 06:07:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 06:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 06:07:35 --> Controller Class Initialized
INFO - 2021-06-16 06:07:36 --> Config Class Initialized
INFO - 2021-06-16 06:07:36 --> Hooks Class Initialized
DEBUG - 2021-06-16 06:07:36 --> UTF-8 Support Enabled
INFO - 2021-06-16 06:07:36 --> Utf8 Class Initialized
INFO - 2021-06-16 06:07:36 --> URI Class Initialized
INFO - 2021-06-16 06:07:36 --> Router Class Initialized
INFO - 2021-06-16 06:07:36 --> Output Class Initialized
INFO - 2021-06-16 06:07:36 --> Security Class Initialized
DEBUG - 2021-06-16 06:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 06:07:36 --> Input Class Initialized
INFO - 2021-06-16 06:07:36 --> Language Class Initialized
INFO - 2021-06-16 06:07:36 --> Language Class Initialized
INFO - 2021-06-16 06:07:36 --> Config Class Initialized
INFO - 2021-06-16 06:07:36 --> Loader Class Initialized
INFO - 2021-06-16 06:07:36 --> Helper loaded: url_helper
INFO - 2021-06-16 06:07:36 --> Helper loaded: file_helper
INFO - 2021-06-16 06:07:36 --> Helper loaded: form_helper
INFO - 2021-06-16 06:07:36 --> Helper loaded: my_helper
INFO - 2021-06-16 06:07:36 --> Database Driver Class Initialized
DEBUG - 2021-06-16 06:07:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 06:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 06:07:36 --> Controller Class Initialized
DEBUG - 2021-06-16 06:07:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-16 06:07:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-16 06:07:36 --> Final output sent to browser
DEBUG - 2021-06-16 06:07:36 --> Total execution time: 0.0506
INFO - 2021-06-16 06:07:37 --> Config Class Initialized
INFO - 2021-06-16 06:07:37 --> Hooks Class Initialized
DEBUG - 2021-06-16 06:07:37 --> UTF-8 Support Enabled
INFO - 2021-06-16 06:07:37 --> Utf8 Class Initialized
INFO - 2021-06-16 06:07:37 --> URI Class Initialized
INFO - 2021-06-16 06:07:37 --> Router Class Initialized
INFO - 2021-06-16 06:07:37 --> Output Class Initialized
INFO - 2021-06-16 06:07:37 --> Security Class Initialized
DEBUG - 2021-06-16 06:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 06:07:37 --> Input Class Initialized
INFO - 2021-06-16 06:07:37 --> Language Class Initialized
INFO - 2021-06-16 06:07:37 --> Language Class Initialized
INFO - 2021-06-16 06:07:37 --> Config Class Initialized
INFO - 2021-06-16 06:07:37 --> Loader Class Initialized
INFO - 2021-06-16 06:07:37 --> Helper loaded: url_helper
INFO - 2021-06-16 06:07:37 --> Helper loaded: file_helper
INFO - 2021-06-16 06:07:37 --> Helper loaded: form_helper
INFO - 2021-06-16 06:07:37 --> Helper loaded: my_helper
INFO - 2021-06-16 06:07:37 --> Database Driver Class Initialized
DEBUG - 2021-06-16 06:07:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 06:07:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 06:07:37 --> Controller Class Initialized
DEBUG - 2021-06-16 06:07:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-16 06:07:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-16 06:07:37 --> Final output sent to browser
DEBUG - 2021-06-16 06:07:37 --> Total execution time: 0.0521
INFO - 2021-06-16 06:07:41 --> Config Class Initialized
INFO - 2021-06-16 06:07:41 --> Hooks Class Initialized
DEBUG - 2021-06-16 06:07:41 --> UTF-8 Support Enabled
INFO - 2021-06-16 06:07:41 --> Utf8 Class Initialized
INFO - 2021-06-16 06:07:41 --> URI Class Initialized
INFO - 2021-06-16 06:07:41 --> Router Class Initialized
INFO - 2021-06-16 06:07:41 --> Output Class Initialized
INFO - 2021-06-16 06:07:41 --> Security Class Initialized
DEBUG - 2021-06-16 06:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 06:07:41 --> Input Class Initialized
INFO - 2021-06-16 06:07:41 --> Language Class Initialized
INFO - 2021-06-16 06:07:41 --> Language Class Initialized
INFO - 2021-06-16 06:07:41 --> Config Class Initialized
INFO - 2021-06-16 06:07:41 --> Loader Class Initialized
INFO - 2021-06-16 06:07:41 --> Helper loaded: url_helper
INFO - 2021-06-16 06:07:41 --> Helper loaded: file_helper
INFO - 2021-06-16 06:07:41 --> Helper loaded: form_helper
INFO - 2021-06-16 06:07:41 --> Helper loaded: my_helper
INFO - 2021-06-16 06:07:41 --> Database Driver Class Initialized
DEBUG - 2021-06-16 06:07:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 06:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 06:07:41 --> Controller Class Initialized
INFO - 2021-06-16 06:07:41 --> Helper loaded: cookie_helper
INFO - 2021-06-16 06:07:41 --> Config Class Initialized
INFO - 2021-06-16 06:07:41 --> Hooks Class Initialized
DEBUG - 2021-06-16 06:07:41 --> UTF-8 Support Enabled
INFO - 2021-06-16 06:07:41 --> Utf8 Class Initialized
INFO - 2021-06-16 06:07:41 --> URI Class Initialized
INFO - 2021-06-16 06:07:41 --> Router Class Initialized
INFO - 2021-06-16 06:07:41 --> Output Class Initialized
INFO - 2021-06-16 06:07:41 --> Security Class Initialized
DEBUG - 2021-06-16 06:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 06:07:41 --> Input Class Initialized
INFO - 2021-06-16 06:07:41 --> Language Class Initialized
INFO - 2021-06-16 06:07:41 --> Language Class Initialized
INFO - 2021-06-16 06:07:41 --> Config Class Initialized
INFO - 2021-06-16 06:07:41 --> Loader Class Initialized
INFO - 2021-06-16 06:07:41 --> Helper loaded: url_helper
INFO - 2021-06-16 06:07:41 --> Helper loaded: file_helper
INFO - 2021-06-16 06:07:41 --> Helper loaded: form_helper
INFO - 2021-06-16 06:07:41 --> Helper loaded: my_helper
INFO - 2021-06-16 06:07:41 --> Database Driver Class Initialized
DEBUG - 2021-06-16 06:07:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 06:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 06:07:41 --> Controller Class Initialized
DEBUG - 2021-06-16 06:07:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-16 06:07:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-16 06:07:41 --> Final output sent to browser
DEBUG - 2021-06-16 06:07:41 --> Total execution time: 0.0393
INFO - 2021-06-16 06:07:45 --> Config Class Initialized
INFO - 2021-06-16 06:07:45 --> Hooks Class Initialized
DEBUG - 2021-06-16 06:07:45 --> UTF-8 Support Enabled
INFO - 2021-06-16 06:07:45 --> Utf8 Class Initialized
INFO - 2021-06-16 06:07:45 --> URI Class Initialized
INFO - 2021-06-16 06:07:45 --> Router Class Initialized
INFO - 2021-06-16 06:07:45 --> Output Class Initialized
INFO - 2021-06-16 06:07:45 --> Security Class Initialized
DEBUG - 2021-06-16 06:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 06:07:45 --> Input Class Initialized
INFO - 2021-06-16 06:07:45 --> Language Class Initialized
INFO - 2021-06-16 06:07:45 --> Language Class Initialized
INFO - 2021-06-16 06:07:45 --> Config Class Initialized
INFO - 2021-06-16 06:07:45 --> Loader Class Initialized
INFO - 2021-06-16 06:07:45 --> Helper loaded: url_helper
INFO - 2021-06-16 06:07:45 --> Helper loaded: file_helper
INFO - 2021-06-16 06:07:45 --> Helper loaded: form_helper
INFO - 2021-06-16 06:07:45 --> Helper loaded: my_helper
INFO - 2021-06-16 06:07:45 --> Database Driver Class Initialized
DEBUG - 2021-06-16 06:07:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 06:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 06:07:45 --> Controller Class Initialized
INFO - 2021-06-16 06:07:45 --> Helper loaded: cookie_helper
INFO - 2021-06-16 06:07:45 --> Final output sent to browser
DEBUG - 2021-06-16 06:07:45 --> Total execution time: 0.0505
INFO - 2021-06-16 06:07:45 --> Config Class Initialized
INFO - 2021-06-16 06:07:45 --> Hooks Class Initialized
DEBUG - 2021-06-16 06:07:45 --> UTF-8 Support Enabled
INFO - 2021-06-16 06:07:45 --> Utf8 Class Initialized
INFO - 2021-06-16 06:07:45 --> URI Class Initialized
INFO - 2021-06-16 06:07:45 --> Router Class Initialized
INFO - 2021-06-16 06:07:45 --> Output Class Initialized
INFO - 2021-06-16 06:07:45 --> Security Class Initialized
DEBUG - 2021-06-16 06:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 06:07:45 --> Input Class Initialized
INFO - 2021-06-16 06:07:45 --> Language Class Initialized
INFO - 2021-06-16 06:07:45 --> Language Class Initialized
INFO - 2021-06-16 06:07:45 --> Config Class Initialized
INFO - 2021-06-16 06:07:45 --> Loader Class Initialized
INFO - 2021-06-16 06:07:45 --> Helper loaded: url_helper
INFO - 2021-06-16 06:07:45 --> Helper loaded: file_helper
INFO - 2021-06-16 06:07:45 --> Helper loaded: form_helper
INFO - 2021-06-16 06:07:45 --> Helper loaded: my_helper
INFO - 2021-06-16 06:07:45 --> Database Driver Class Initialized
DEBUG - 2021-06-16 06:07:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 06:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 06:07:45 --> Controller Class Initialized
DEBUG - 2021-06-16 06:07:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-16 06:07:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-16 06:07:45 --> Final output sent to browser
DEBUG - 2021-06-16 06:07:45 --> Total execution time: 0.2007
INFO - 2021-06-16 06:07:49 --> Config Class Initialized
INFO - 2021-06-16 06:07:49 --> Hooks Class Initialized
DEBUG - 2021-06-16 06:07:49 --> UTF-8 Support Enabled
INFO - 2021-06-16 06:07:49 --> Utf8 Class Initialized
INFO - 2021-06-16 06:07:49 --> URI Class Initialized
INFO - 2021-06-16 06:07:49 --> Router Class Initialized
INFO - 2021-06-16 06:07:49 --> Output Class Initialized
INFO - 2021-06-16 06:07:49 --> Security Class Initialized
DEBUG - 2021-06-16 06:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 06:07:49 --> Input Class Initialized
INFO - 2021-06-16 06:07:49 --> Language Class Initialized
INFO - 2021-06-16 06:07:49 --> Language Class Initialized
INFO - 2021-06-16 06:07:49 --> Config Class Initialized
INFO - 2021-06-16 06:07:49 --> Loader Class Initialized
INFO - 2021-06-16 06:07:49 --> Helper loaded: url_helper
INFO - 2021-06-16 06:07:49 --> Helper loaded: file_helper
INFO - 2021-06-16 06:07:49 --> Helper loaded: form_helper
INFO - 2021-06-16 06:07:49 --> Helper loaded: my_helper
INFO - 2021-06-16 06:07:49 --> Database Driver Class Initialized
DEBUG - 2021-06-16 06:07:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 06:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 06:07:49 --> Controller Class Initialized
DEBUG - 2021-06-16 06:07:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-06-16 06:07:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-16 06:07:49 --> Final output sent to browser
DEBUG - 2021-06-16 06:07:49 --> Total execution time: 0.0592
INFO - 2021-06-16 06:07:56 --> Config Class Initialized
INFO - 2021-06-16 06:07:56 --> Hooks Class Initialized
DEBUG - 2021-06-16 06:07:56 --> UTF-8 Support Enabled
INFO - 2021-06-16 06:07:56 --> Utf8 Class Initialized
INFO - 2021-06-16 06:07:56 --> URI Class Initialized
INFO - 2021-06-16 06:07:56 --> Router Class Initialized
INFO - 2021-06-16 06:07:56 --> Output Class Initialized
INFO - 2021-06-16 06:07:56 --> Security Class Initialized
DEBUG - 2021-06-16 06:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 06:07:56 --> Input Class Initialized
INFO - 2021-06-16 06:07:56 --> Language Class Initialized
INFO - 2021-06-16 06:07:56 --> Language Class Initialized
INFO - 2021-06-16 06:07:56 --> Config Class Initialized
INFO - 2021-06-16 06:07:56 --> Loader Class Initialized
INFO - 2021-06-16 06:07:56 --> Helper loaded: url_helper
INFO - 2021-06-16 06:07:56 --> Helper loaded: file_helper
INFO - 2021-06-16 06:07:56 --> Helper loaded: form_helper
INFO - 2021-06-16 06:07:56 --> Helper loaded: my_helper
INFO - 2021-06-16 06:07:56 --> Database Driver Class Initialized
DEBUG - 2021-06-16 06:07:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 06:07:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 06:07:56 --> Controller Class Initialized
DEBUG - 2021-06-16 06:07:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-06-16 06:07:56 --> Final output sent to browser
DEBUG - 2021-06-16 06:07:56 --> Total execution time: 0.1572
INFO - 2021-06-16 06:12:42 --> Config Class Initialized
INFO - 2021-06-16 06:12:42 --> Hooks Class Initialized
DEBUG - 2021-06-16 06:12:42 --> UTF-8 Support Enabled
INFO - 2021-06-16 06:12:42 --> Utf8 Class Initialized
INFO - 2021-06-16 06:12:42 --> URI Class Initialized
INFO - 2021-06-16 06:12:42 --> Router Class Initialized
INFO - 2021-06-16 06:12:42 --> Output Class Initialized
INFO - 2021-06-16 06:12:42 --> Security Class Initialized
DEBUG - 2021-06-16 06:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 06:12:42 --> Input Class Initialized
INFO - 2021-06-16 06:12:42 --> Language Class Initialized
INFO - 2021-06-16 06:12:42 --> Language Class Initialized
INFO - 2021-06-16 06:12:42 --> Config Class Initialized
INFO - 2021-06-16 06:12:42 --> Loader Class Initialized
INFO - 2021-06-16 06:12:42 --> Helper loaded: url_helper
INFO - 2021-06-16 06:12:42 --> Helper loaded: file_helper
INFO - 2021-06-16 06:12:42 --> Helper loaded: form_helper
INFO - 2021-06-16 06:12:42 --> Helper loaded: my_helper
INFO - 2021-06-16 06:12:42 --> Database Driver Class Initialized
DEBUG - 2021-06-16 06:12:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 06:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 06:12:42 --> Controller Class Initialized
DEBUG - 2021-06-16 06:12:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-06-16 06:12:42 --> Final output sent to browser
DEBUG - 2021-06-16 06:12:42 --> Total execution time: 0.0774
INFO - 2021-06-16 10:32:12 --> Config Class Initialized
INFO - 2021-06-16 10:32:12 --> Hooks Class Initialized
DEBUG - 2021-06-16 10:32:12 --> UTF-8 Support Enabled
INFO - 2021-06-16 10:32:12 --> Utf8 Class Initialized
INFO - 2021-06-16 10:32:12 --> URI Class Initialized
DEBUG - 2021-06-16 10:32:12 --> No URI present. Default controller set.
INFO - 2021-06-16 10:32:12 --> Router Class Initialized
INFO - 2021-06-16 10:32:12 --> Output Class Initialized
INFO - 2021-06-16 10:32:12 --> Security Class Initialized
DEBUG - 2021-06-16 10:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 10:32:12 --> Input Class Initialized
INFO - 2021-06-16 10:32:12 --> Language Class Initialized
INFO - 2021-06-16 10:32:12 --> Language Class Initialized
INFO - 2021-06-16 10:32:12 --> Config Class Initialized
INFO - 2021-06-16 10:32:12 --> Loader Class Initialized
INFO - 2021-06-16 10:32:12 --> Helper loaded: url_helper
INFO - 2021-06-16 10:32:12 --> Helper loaded: file_helper
INFO - 2021-06-16 10:32:12 --> Helper loaded: form_helper
INFO - 2021-06-16 10:32:12 --> Helper loaded: my_helper
INFO - 2021-06-16 10:32:12 --> Database Driver Class Initialized
DEBUG - 2021-06-16 10:32:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 10:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 10:32:12 --> Controller Class Initialized
INFO - 2021-06-16 10:32:12 --> Config Class Initialized
INFO - 2021-06-16 10:32:12 --> Hooks Class Initialized
DEBUG - 2021-06-16 10:32:12 --> UTF-8 Support Enabled
INFO - 2021-06-16 10:32:12 --> Utf8 Class Initialized
INFO - 2021-06-16 10:32:12 --> URI Class Initialized
INFO - 2021-06-16 10:32:12 --> Router Class Initialized
INFO - 2021-06-16 10:32:12 --> Output Class Initialized
INFO - 2021-06-16 10:32:12 --> Security Class Initialized
DEBUG - 2021-06-16 10:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 10:32:12 --> Input Class Initialized
INFO - 2021-06-16 10:32:12 --> Language Class Initialized
INFO - 2021-06-16 10:32:12 --> Language Class Initialized
INFO - 2021-06-16 10:32:12 --> Config Class Initialized
INFO - 2021-06-16 10:32:12 --> Loader Class Initialized
INFO - 2021-06-16 10:32:12 --> Helper loaded: url_helper
INFO - 2021-06-16 10:32:12 --> Helper loaded: file_helper
INFO - 2021-06-16 10:32:12 --> Helper loaded: form_helper
INFO - 2021-06-16 10:32:12 --> Helper loaded: my_helper
INFO - 2021-06-16 10:32:12 --> Database Driver Class Initialized
DEBUG - 2021-06-16 10:32:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 10:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 10:32:12 --> Controller Class Initialized
DEBUG - 2021-06-16 10:32:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-16 10:32:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-16 10:32:12 --> Final output sent to browser
DEBUG - 2021-06-16 10:32:12 --> Total execution time: 0.0491
INFO - 2021-06-16 10:32:18 --> Config Class Initialized
INFO - 2021-06-16 10:32:18 --> Hooks Class Initialized
DEBUG - 2021-06-16 10:32:18 --> UTF-8 Support Enabled
INFO - 2021-06-16 10:32:18 --> Utf8 Class Initialized
INFO - 2021-06-16 10:32:18 --> URI Class Initialized
INFO - 2021-06-16 10:32:18 --> Router Class Initialized
INFO - 2021-06-16 10:32:18 --> Output Class Initialized
INFO - 2021-06-16 10:32:18 --> Security Class Initialized
DEBUG - 2021-06-16 10:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 10:32:18 --> Input Class Initialized
INFO - 2021-06-16 10:32:18 --> Language Class Initialized
INFO - 2021-06-16 10:32:18 --> Language Class Initialized
INFO - 2021-06-16 10:32:18 --> Config Class Initialized
INFO - 2021-06-16 10:32:18 --> Loader Class Initialized
INFO - 2021-06-16 10:32:18 --> Helper loaded: url_helper
INFO - 2021-06-16 10:32:18 --> Helper loaded: file_helper
INFO - 2021-06-16 10:32:18 --> Helper loaded: form_helper
INFO - 2021-06-16 10:32:18 --> Helper loaded: my_helper
INFO - 2021-06-16 10:32:18 --> Database Driver Class Initialized
DEBUG - 2021-06-16 10:32:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 10:32:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 10:32:18 --> Controller Class Initialized
INFO - 2021-06-16 10:32:18 --> Helper loaded: cookie_helper
INFO - 2021-06-16 10:32:18 --> Final output sent to browser
DEBUG - 2021-06-16 10:32:18 --> Total execution time: 0.0564
INFO - 2021-06-16 10:32:19 --> Config Class Initialized
INFO - 2021-06-16 10:32:19 --> Hooks Class Initialized
DEBUG - 2021-06-16 10:32:19 --> UTF-8 Support Enabled
INFO - 2021-06-16 10:32:19 --> Utf8 Class Initialized
INFO - 2021-06-16 10:32:19 --> URI Class Initialized
INFO - 2021-06-16 10:32:19 --> Router Class Initialized
INFO - 2021-06-16 10:32:19 --> Output Class Initialized
INFO - 2021-06-16 10:32:19 --> Security Class Initialized
DEBUG - 2021-06-16 10:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 10:32:19 --> Input Class Initialized
INFO - 2021-06-16 10:32:19 --> Language Class Initialized
INFO - 2021-06-16 10:32:19 --> Language Class Initialized
INFO - 2021-06-16 10:32:19 --> Config Class Initialized
INFO - 2021-06-16 10:32:19 --> Loader Class Initialized
INFO - 2021-06-16 10:32:19 --> Helper loaded: url_helper
INFO - 2021-06-16 10:32:19 --> Helper loaded: file_helper
INFO - 2021-06-16 10:32:19 --> Helper loaded: form_helper
INFO - 2021-06-16 10:32:19 --> Helper loaded: my_helper
INFO - 2021-06-16 10:32:19 --> Database Driver Class Initialized
DEBUG - 2021-06-16 10:32:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 10:32:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 10:32:19 --> Controller Class Initialized
DEBUG - 2021-06-16 10:32:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-16 10:32:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-16 10:32:19 --> Final output sent to browser
DEBUG - 2021-06-16 10:32:19 --> Total execution time: 0.2145
INFO - 2021-06-16 10:32:20 --> Config Class Initialized
INFO - 2021-06-16 10:32:20 --> Hooks Class Initialized
DEBUG - 2021-06-16 10:32:20 --> UTF-8 Support Enabled
INFO - 2021-06-16 10:32:20 --> Utf8 Class Initialized
INFO - 2021-06-16 10:32:20 --> URI Class Initialized
INFO - 2021-06-16 10:32:20 --> Router Class Initialized
INFO - 2021-06-16 10:32:20 --> Output Class Initialized
INFO - 2021-06-16 10:32:20 --> Security Class Initialized
DEBUG - 2021-06-16 10:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 10:32:20 --> Input Class Initialized
INFO - 2021-06-16 10:32:20 --> Language Class Initialized
INFO - 2021-06-16 10:32:20 --> Language Class Initialized
INFO - 2021-06-16 10:32:20 --> Config Class Initialized
INFO - 2021-06-16 10:32:20 --> Loader Class Initialized
INFO - 2021-06-16 10:32:20 --> Helper loaded: url_helper
INFO - 2021-06-16 10:32:20 --> Helper loaded: file_helper
INFO - 2021-06-16 10:32:20 --> Helper loaded: form_helper
INFO - 2021-06-16 10:32:20 --> Helper loaded: my_helper
INFO - 2021-06-16 10:32:20 --> Database Driver Class Initialized
DEBUG - 2021-06-16 10:32:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 10:32:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 10:32:20 --> Controller Class Initialized
DEBUG - 2021-06-16 10:32:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-16 10:32:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-16 10:32:20 --> Final output sent to browser
DEBUG - 2021-06-16 10:32:20 --> Total execution time: 0.0509
INFO - 2021-06-16 10:32:39 --> Config Class Initialized
INFO - 2021-06-16 10:32:39 --> Hooks Class Initialized
DEBUG - 2021-06-16 10:32:39 --> UTF-8 Support Enabled
INFO - 2021-06-16 10:32:39 --> Utf8 Class Initialized
INFO - 2021-06-16 10:32:39 --> URI Class Initialized
INFO - 2021-06-16 10:32:39 --> Router Class Initialized
INFO - 2021-06-16 10:32:39 --> Output Class Initialized
INFO - 2021-06-16 10:32:39 --> Security Class Initialized
DEBUG - 2021-06-16 10:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 10:32:39 --> Input Class Initialized
INFO - 2021-06-16 10:32:39 --> Language Class Initialized
INFO - 2021-06-16 10:32:39 --> Language Class Initialized
INFO - 2021-06-16 10:32:39 --> Config Class Initialized
INFO - 2021-06-16 10:32:39 --> Loader Class Initialized
INFO - 2021-06-16 10:32:39 --> Helper loaded: url_helper
INFO - 2021-06-16 10:32:39 --> Helper loaded: file_helper
INFO - 2021-06-16 10:32:39 --> Helper loaded: form_helper
INFO - 2021-06-16 10:32:39 --> Helper loaded: my_helper
INFO - 2021-06-16 10:32:39 --> Database Driver Class Initialized
DEBUG - 2021-06-16 10:32:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 10:32:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 10:32:39 --> Controller Class Initialized
DEBUG - 2021-06-16 10:32:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-16 10:32:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-16 10:32:39 --> Final output sent to browser
DEBUG - 2021-06-16 10:32:39 --> Total execution time: 0.0491
INFO - 2021-06-16 10:32:39 --> Config Class Initialized
INFO - 2021-06-16 10:32:39 --> Hooks Class Initialized
DEBUG - 2021-06-16 10:32:39 --> UTF-8 Support Enabled
INFO - 2021-06-16 10:32:39 --> Utf8 Class Initialized
INFO - 2021-06-16 10:32:39 --> URI Class Initialized
INFO - 2021-06-16 10:32:39 --> Router Class Initialized
INFO - 2021-06-16 10:32:39 --> Output Class Initialized
INFO - 2021-06-16 10:32:39 --> Security Class Initialized
DEBUG - 2021-06-16 10:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 10:32:39 --> Input Class Initialized
INFO - 2021-06-16 10:32:39 --> Language Class Initialized
INFO - 2021-06-16 10:32:39 --> Language Class Initialized
INFO - 2021-06-16 10:32:39 --> Config Class Initialized
INFO - 2021-06-16 10:32:39 --> Loader Class Initialized
INFO - 2021-06-16 10:32:39 --> Helper loaded: url_helper
INFO - 2021-06-16 10:32:39 --> Helper loaded: file_helper
INFO - 2021-06-16 10:32:39 --> Helper loaded: form_helper
INFO - 2021-06-16 10:32:39 --> Helper loaded: my_helper
INFO - 2021-06-16 10:32:39 --> Database Driver Class Initialized
DEBUG - 2021-06-16 10:32:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 10:32:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 10:32:39 --> Controller Class Initialized
INFO - 2021-06-16 10:32:40 --> Config Class Initialized
INFO - 2021-06-16 10:32:40 --> Hooks Class Initialized
DEBUG - 2021-06-16 10:32:40 --> UTF-8 Support Enabled
INFO - 2021-06-16 10:32:40 --> Utf8 Class Initialized
INFO - 2021-06-16 10:32:40 --> URI Class Initialized
INFO - 2021-06-16 10:32:40 --> Router Class Initialized
INFO - 2021-06-16 10:32:40 --> Output Class Initialized
INFO - 2021-06-16 10:32:40 --> Security Class Initialized
DEBUG - 2021-06-16 10:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 10:32:40 --> Input Class Initialized
INFO - 2021-06-16 10:32:40 --> Language Class Initialized
INFO - 2021-06-16 10:32:40 --> Language Class Initialized
INFO - 2021-06-16 10:32:40 --> Config Class Initialized
INFO - 2021-06-16 10:32:40 --> Loader Class Initialized
INFO - 2021-06-16 10:32:40 --> Helper loaded: url_helper
INFO - 2021-06-16 10:32:40 --> Helper loaded: file_helper
INFO - 2021-06-16 10:32:40 --> Helper loaded: form_helper
INFO - 2021-06-16 10:32:40 --> Helper loaded: my_helper
INFO - 2021-06-16 10:32:40 --> Database Driver Class Initialized
DEBUG - 2021-06-16 10:32:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 10:32:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 10:32:40 --> Controller Class Initialized
DEBUG - 2021-06-16 10:32:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-16 10:32:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-16 10:32:40 --> Final output sent to browser
DEBUG - 2021-06-16 10:32:40 --> Total execution time: 0.0537
INFO - 2021-06-16 10:32:41 --> Config Class Initialized
INFO - 2021-06-16 10:32:41 --> Hooks Class Initialized
DEBUG - 2021-06-16 10:32:41 --> UTF-8 Support Enabled
INFO - 2021-06-16 10:32:41 --> Utf8 Class Initialized
INFO - 2021-06-16 10:32:41 --> URI Class Initialized
INFO - 2021-06-16 10:32:41 --> Router Class Initialized
INFO - 2021-06-16 10:32:41 --> Output Class Initialized
INFO - 2021-06-16 10:32:41 --> Security Class Initialized
DEBUG - 2021-06-16 10:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 10:32:41 --> Input Class Initialized
INFO - 2021-06-16 10:32:41 --> Language Class Initialized
INFO - 2021-06-16 10:32:41 --> Language Class Initialized
INFO - 2021-06-16 10:32:41 --> Config Class Initialized
INFO - 2021-06-16 10:32:41 --> Loader Class Initialized
INFO - 2021-06-16 10:32:41 --> Helper loaded: url_helper
INFO - 2021-06-16 10:32:41 --> Helper loaded: file_helper
INFO - 2021-06-16 10:32:41 --> Helper loaded: form_helper
INFO - 2021-06-16 10:32:41 --> Helper loaded: my_helper
INFO - 2021-06-16 10:32:41 --> Database Driver Class Initialized
DEBUG - 2021-06-16 10:32:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 10:32:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 10:32:41 --> Controller Class Initialized
INFO - 2021-06-16 10:32:42 --> Config Class Initialized
INFO - 2021-06-16 10:32:42 --> Hooks Class Initialized
DEBUG - 2021-06-16 10:32:42 --> UTF-8 Support Enabled
INFO - 2021-06-16 10:32:42 --> Utf8 Class Initialized
INFO - 2021-06-16 10:32:42 --> URI Class Initialized
INFO - 2021-06-16 10:32:42 --> Router Class Initialized
INFO - 2021-06-16 10:32:42 --> Output Class Initialized
INFO - 2021-06-16 10:32:42 --> Security Class Initialized
DEBUG - 2021-06-16 10:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 10:32:42 --> Input Class Initialized
INFO - 2021-06-16 10:32:42 --> Language Class Initialized
INFO - 2021-06-16 10:32:42 --> Language Class Initialized
INFO - 2021-06-16 10:32:42 --> Config Class Initialized
INFO - 2021-06-16 10:32:42 --> Loader Class Initialized
INFO - 2021-06-16 10:32:42 --> Helper loaded: url_helper
INFO - 2021-06-16 10:32:42 --> Helper loaded: file_helper
INFO - 2021-06-16 10:32:42 --> Helper loaded: form_helper
INFO - 2021-06-16 10:32:42 --> Helper loaded: my_helper
INFO - 2021-06-16 10:32:42 --> Database Driver Class Initialized
DEBUG - 2021-06-16 10:32:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 10:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 10:32:42 --> Controller Class Initialized
INFO - 2021-06-16 10:32:47 --> Config Class Initialized
INFO - 2021-06-16 10:32:47 --> Hooks Class Initialized
DEBUG - 2021-06-16 10:32:47 --> UTF-8 Support Enabled
INFO - 2021-06-16 10:32:47 --> Utf8 Class Initialized
INFO - 2021-06-16 10:32:47 --> URI Class Initialized
INFO - 2021-06-16 10:32:47 --> Router Class Initialized
INFO - 2021-06-16 10:32:47 --> Output Class Initialized
INFO - 2021-06-16 10:32:47 --> Security Class Initialized
DEBUG - 2021-06-16 10:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 10:32:47 --> Input Class Initialized
INFO - 2021-06-16 10:32:47 --> Language Class Initialized
INFO - 2021-06-16 10:32:47 --> Language Class Initialized
INFO - 2021-06-16 10:32:47 --> Config Class Initialized
INFO - 2021-06-16 10:32:47 --> Loader Class Initialized
INFO - 2021-06-16 10:32:47 --> Helper loaded: url_helper
INFO - 2021-06-16 10:32:47 --> Helper loaded: file_helper
INFO - 2021-06-16 10:32:47 --> Helper loaded: form_helper
INFO - 2021-06-16 10:32:47 --> Helper loaded: my_helper
INFO - 2021-06-16 10:32:47 --> Database Driver Class Initialized
DEBUG - 2021-06-16 10:32:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 10:32:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 10:32:47 --> Controller Class Initialized
DEBUG - 2021-06-16 10:32:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-16 10:32:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-16 10:32:47 --> Final output sent to browser
DEBUG - 2021-06-16 10:32:47 --> Total execution time: 0.0451
INFO - 2021-06-16 10:32:47 --> Config Class Initialized
INFO - 2021-06-16 10:32:47 --> Hooks Class Initialized
DEBUG - 2021-06-16 10:32:47 --> UTF-8 Support Enabled
INFO - 2021-06-16 10:32:47 --> Utf8 Class Initialized
INFO - 2021-06-16 10:32:47 --> URI Class Initialized
INFO - 2021-06-16 10:32:47 --> Router Class Initialized
INFO - 2021-06-16 10:32:47 --> Output Class Initialized
INFO - 2021-06-16 10:32:47 --> Security Class Initialized
DEBUG - 2021-06-16 10:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 10:32:47 --> Input Class Initialized
INFO - 2021-06-16 10:32:47 --> Language Class Initialized
INFO - 2021-06-16 10:32:47 --> Language Class Initialized
INFO - 2021-06-16 10:32:47 --> Config Class Initialized
INFO - 2021-06-16 10:32:47 --> Loader Class Initialized
INFO - 2021-06-16 10:32:47 --> Helper loaded: url_helper
INFO - 2021-06-16 10:32:47 --> Helper loaded: file_helper
INFO - 2021-06-16 10:32:47 --> Helper loaded: form_helper
INFO - 2021-06-16 10:32:47 --> Helper loaded: my_helper
INFO - 2021-06-16 10:32:47 --> Database Driver Class Initialized
DEBUG - 2021-06-16 10:32:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 10:32:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 10:32:47 --> Controller Class Initialized
INFO - 2021-06-16 10:32:48 --> Config Class Initialized
INFO - 2021-06-16 10:32:48 --> Hooks Class Initialized
DEBUG - 2021-06-16 10:32:48 --> UTF-8 Support Enabled
INFO - 2021-06-16 10:32:48 --> Utf8 Class Initialized
INFO - 2021-06-16 10:32:48 --> URI Class Initialized
INFO - 2021-06-16 10:32:48 --> Router Class Initialized
INFO - 2021-06-16 10:32:48 --> Output Class Initialized
INFO - 2021-06-16 10:32:48 --> Security Class Initialized
DEBUG - 2021-06-16 10:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 10:32:48 --> Input Class Initialized
INFO - 2021-06-16 10:32:48 --> Language Class Initialized
INFO - 2021-06-16 10:32:48 --> Language Class Initialized
INFO - 2021-06-16 10:32:48 --> Config Class Initialized
INFO - 2021-06-16 10:32:48 --> Loader Class Initialized
INFO - 2021-06-16 10:32:48 --> Helper loaded: url_helper
INFO - 2021-06-16 10:32:48 --> Helper loaded: file_helper
INFO - 2021-06-16 10:32:48 --> Helper loaded: form_helper
INFO - 2021-06-16 10:32:48 --> Helper loaded: my_helper
INFO - 2021-06-16 10:32:48 --> Database Driver Class Initialized
DEBUG - 2021-06-16 10:32:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 10:32:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 10:32:48 --> Controller Class Initialized
DEBUG - 2021-06-16 10:32:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-16 10:32:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-16 10:32:48 --> Final output sent to browser
DEBUG - 2021-06-16 10:32:48 --> Total execution time: 0.0457
INFO - 2021-06-16 10:32:49 --> Config Class Initialized
INFO - 2021-06-16 10:32:49 --> Hooks Class Initialized
DEBUG - 2021-06-16 10:32:49 --> UTF-8 Support Enabled
INFO - 2021-06-16 10:32:49 --> Utf8 Class Initialized
INFO - 2021-06-16 10:32:49 --> URI Class Initialized
INFO - 2021-06-16 10:32:49 --> Router Class Initialized
INFO - 2021-06-16 10:32:49 --> Output Class Initialized
INFO - 2021-06-16 10:32:49 --> Security Class Initialized
DEBUG - 2021-06-16 10:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 10:32:49 --> Input Class Initialized
INFO - 2021-06-16 10:32:49 --> Language Class Initialized
INFO - 2021-06-16 10:32:49 --> Language Class Initialized
INFO - 2021-06-16 10:32:49 --> Config Class Initialized
INFO - 2021-06-16 10:32:49 --> Loader Class Initialized
INFO - 2021-06-16 10:32:49 --> Helper loaded: url_helper
INFO - 2021-06-16 10:32:49 --> Helper loaded: file_helper
INFO - 2021-06-16 10:32:49 --> Helper loaded: form_helper
INFO - 2021-06-16 10:32:49 --> Helper loaded: my_helper
INFO - 2021-06-16 10:32:49 --> Database Driver Class Initialized
DEBUG - 2021-06-16 10:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 10:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 10:32:49 --> Controller Class Initialized
INFO - 2021-06-16 10:32:52 --> Config Class Initialized
INFO - 2021-06-16 10:32:52 --> Hooks Class Initialized
DEBUG - 2021-06-16 10:32:52 --> UTF-8 Support Enabled
INFO - 2021-06-16 10:32:52 --> Utf8 Class Initialized
INFO - 2021-06-16 10:32:52 --> URI Class Initialized
INFO - 2021-06-16 10:32:52 --> Router Class Initialized
INFO - 2021-06-16 10:32:52 --> Output Class Initialized
INFO - 2021-06-16 10:32:52 --> Security Class Initialized
DEBUG - 2021-06-16 10:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 10:32:52 --> Input Class Initialized
INFO - 2021-06-16 10:32:52 --> Language Class Initialized
INFO - 2021-06-16 10:32:52 --> Language Class Initialized
INFO - 2021-06-16 10:32:52 --> Config Class Initialized
INFO - 2021-06-16 10:32:52 --> Loader Class Initialized
INFO - 2021-06-16 10:32:52 --> Helper loaded: url_helper
INFO - 2021-06-16 10:32:52 --> Helper loaded: file_helper
INFO - 2021-06-16 10:32:52 --> Helper loaded: form_helper
INFO - 2021-06-16 10:32:52 --> Helper loaded: my_helper
INFO - 2021-06-16 10:32:52 --> Database Driver Class Initialized
DEBUG - 2021-06-16 10:32:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 10:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 10:32:52 --> Controller Class Initialized
INFO - 2021-06-16 10:33:04 --> Config Class Initialized
INFO - 2021-06-16 10:33:04 --> Hooks Class Initialized
DEBUG - 2021-06-16 10:33:04 --> UTF-8 Support Enabled
INFO - 2021-06-16 10:33:04 --> Utf8 Class Initialized
INFO - 2021-06-16 10:33:04 --> URI Class Initialized
INFO - 2021-06-16 10:33:04 --> Router Class Initialized
INFO - 2021-06-16 10:33:04 --> Output Class Initialized
INFO - 2021-06-16 10:33:04 --> Security Class Initialized
DEBUG - 2021-06-16 10:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 10:33:04 --> Input Class Initialized
INFO - 2021-06-16 10:33:04 --> Language Class Initialized
INFO - 2021-06-16 10:33:04 --> Language Class Initialized
INFO - 2021-06-16 10:33:04 --> Config Class Initialized
INFO - 2021-06-16 10:33:04 --> Loader Class Initialized
INFO - 2021-06-16 10:33:04 --> Helper loaded: url_helper
INFO - 2021-06-16 10:33:04 --> Helper loaded: file_helper
INFO - 2021-06-16 10:33:04 --> Helper loaded: form_helper
INFO - 2021-06-16 10:33:04 --> Helper loaded: my_helper
INFO - 2021-06-16 10:33:04 --> Database Driver Class Initialized
DEBUG - 2021-06-16 10:33:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 10:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 10:33:04 --> Controller Class Initialized
DEBUG - 2021-06-16 10:33:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-16 10:33:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-16 10:33:04 --> Final output sent to browser
DEBUG - 2021-06-16 10:33:04 --> Total execution time: 0.0457
INFO - 2021-06-16 10:33:04 --> Config Class Initialized
INFO - 2021-06-16 10:33:04 --> Hooks Class Initialized
DEBUG - 2021-06-16 10:33:04 --> UTF-8 Support Enabled
INFO - 2021-06-16 10:33:04 --> Utf8 Class Initialized
INFO - 2021-06-16 10:33:04 --> URI Class Initialized
INFO - 2021-06-16 10:33:04 --> Router Class Initialized
INFO - 2021-06-16 10:33:04 --> Output Class Initialized
INFO - 2021-06-16 10:33:04 --> Security Class Initialized
DEBUG - 2021-06-16 10:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 10:33:04 --> Input Class Initialized
INFO - 2021-06-16 10:33:04 --> Language Class Initialized
INFO - 2021-06-16 10:33:04 --> Language Class Initialized
INFO - 2021-06-16 10:33:04 --> Config Class Initialized
INFO - 2021-06-16 10:33:04 --> Loader Class Initialized
INFO - 2021-06-16 10:33:04 --> Helper loaded: url_helper
INFO - 2021-06-16 10:33:04 --> Helper loaded: file_helper
INFO - 2021-06-16 10:33:04 --> Helper loaded: form_helper
INFO - 2021-06-16 10:33:04 --> Helper loaded: my_helper
INFO - 2021-06-16 10:33:04 --> Database Driver Class Initialized
DEBUG - 2021-06-16 10:33:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 10:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 10:33:04 --> Controller Class Initialized
INFO - 2021-06-16 10:33:05 --> Config Class Initialized
INFO - 2021-06-16 10:33:05 --> Hooks Class Initialized
DEBUG - 2021-06-16 10:33:05 --> UTF-8 Support Enabled
INFO - 2021-06-16 10:33:05 --> Utf8 Class Initialized
INFO - 2021-06-16 10:33:05 --> URI Class Initialized
INFO - 2021-06-16 10:33:05 --> Router Class Initialized
INFO - 2021-06-16 10:33:05 --> Output Class Initialized
INFO - 2021-06-16 10:33:05 --> Security Class Initialized
DEBUG - 2021-06-16 10:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 10:33:05 --> Input Class Initialized
INFO - 2021-06-16 10:33:05 --> Language Class Initialized
INFO - 2021-06-16 10:33:05 --> Language Class Initialized
INFO - 2021-06-16 10:33:05 --> Config Class Initialized
INFO - 2021-06-16 10:33:05 --> Loader Class Initialized
INFO - 2021-06-16 10:33:05 --> Helper loaded: url_helper
INFO - 2021-06-16 10:33:05 --> Helper loaded: file_helper
INFO - 2021-06-16 10:33:05 --> Helper loaded: form_helper
INFO - 2021-06-16 10:33:05 --> Helper loaded: my_helper
INFO - 2021-06-16 10:33:05 --> Database Driver Class Initialized
DEBUG - 2021-06-16 10:33:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 10:33:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 10:33:05 --> Controller Class Initialized
DEBUG - 2021-06-16 10:33:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-16 10:33:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-16 10:33:05 --> Final output sent to browser
DEBUG - 2021-06-16 10:33:05 --> Total execution time: 0.0442
INFO - 2021-06-16 10:33:07 --> Config Class Initialized
INFO - 2021-06-16 10:33:07 --> Hooks Class Initialized
DEBUG - 2021-06-16 10:33:07 --> UTF-8 Support Enabled
INFO - 2021-06-16 10:33:07 --> Utf8 Class Initialized
INFO - 2021-06-16 10:33:07 --> URI Class Initialized
INFO - 2021-06-16 10:33:07 --> Router Class Initialized
INFO - 2021-06-16 10:33:07 --> Output Class Initialized
INFO - 2021-06-16 10:33:07 --> Security Class Initialized
DEBUG - 2021-06-16 10:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 10:33:07 --> Input Class Initialized
INFO - 2021-06-16 10:33:07 --> Language Class Initialized
INFO - 2021-06-16 10:33:07 --> Language Class Initialized
INFO - 2021-06-16 10:33:07 --> Config Class Initialized
INFO - 2021-06-16 10:33:07 --> Loader Class Initialized
INFO - 2021-06-16 10:33:07 --> Helper loaded: url_helper
INFO - 2021-06-16 10:33:07 --> Helper loaded: file_helper
INFO - 2021-06-16 10:33:07 --> Helper loaded: form_helper
INFO - 2021-06-16 10:33:07 --> Helper loaded: my_helper
INFO - 2021-06-16 10:33:07 --> Database Driver Class Initialized
DEBUG - 2021-06-16 10:33:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 10:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 10:33:07 --> Controller Class Initialized
INFO - 2021-06-16 10:33:08 --> Config Class Initialized
INFO - 2021-06-16 10:33:08 --> Hooks Class Initialized
DEBUG - 2021-06-16 10:33:08 --> UTF-8 Support Enabled
INFO - 2021-06-16 10:33:08 --> Utf8 Class Initialized
INFO - 2021-06-16 10:33:08 --> URI Class Initialized
INFO - 2021-06-16 10:33:08 --> Router Class Initialized
INFO - 2021-06-16 10:33:08 --> Output Class Initialized
INFO - 2021-06-16 10:33:08 --> Security Class Initialized
DEBUG - 2021-06-16 10:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 10:33:08 --> Input Class Initialized
INFO - 2021-06-16 10:33:08 --> Language Class Initialized
INFO - 2021-06-16 10:33:08 --> Language Class Initialized
INFO - 2021-06-16 10:33:08 --> Config Class Initialized
INFO - 2021-06-16 10:33:08 --> Loader Class Initialized
INFO - 2021-06-16 10:33:08 --> Helper loaded: url_helper
INFO - 2021-06-16 10:33:08 --> Helper loaded: file_helper
INFO - 2021-06-16 10:33:08 --> Helper loaded: form_helper
INFO - 2021-06-16 10:33:08 --> Helper loaded: my_helper
INFO - 2021-06-16 10:33:08 --> Database Driver Class Initialized
DEBUG - 2021-06-16 10:33:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 10:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 10:33:09 --> Controller Class Initialized
INFO - 2021-06-16 10:33:27 --> Config Class Initialized
INFO - 2021-06-16 10:33:27 --> Hooks Class Initialized
DEBUG - 2021-06-16 10:33:27 --> UTF-8 Support Enabled
INFO - 2021-06-16 10:33:27 --> Utf8 Class Initialized
INFO - 2021-06-16 10:33:27 --> URI Class Initialized
INFO - 2021-06-16 10:33:27 --> Router Class Initialized
INFO - 2021-06-16 10:33:27 --> Output Class Initialized
INFO - 2021-06-16 10:33:27 --> Security Class Initialized
DEBUG - 2021-06-16 10:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 10:33:27 --> Input Class Initialized
INFO - 2021-06-16 10:33:27 --> Language Class Initialized
INFO - 2021-06-16 10:33:27 --> Language Class Initialized
INFO - 2021-06-16 10:33:27 --> Config Class Initialized
INFO - 2021-06-16 10:33:27 --> Loader Class Initialized
INFO - 2021-06-16 10:33:27 --> Helper loaded: url_helper
INFO - 2021-06-16 10:33:27 --> Helper loaded: file_helper
INFO - 2021-06-16 10:33:27 --> Helper loaded: form_helper
INFO - 2021-06-16 10:33:27 --> Helper loaded: my_helper
INFO - 2021-06-16 10:33:27 --> Database Driver Class Initialized
DEBUG - 2021-06-16 10:33:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 10:33:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 10:33:27 --> Controller Class Initialized
DEBUG - 2021-06-16 10:33:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-16 10:33:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-16 10:33:27 --> Final output sent to browser
DEBUG - 2021-06-16 10:33:27 --> Total execution time: 0.0451
INFO - 2021-06-16 10:33:27 --> Config Class Initialized
INFO - 2021-06-16 10:33:27 --> Hooks Class Initialized
DEBUG - 2021-06-16 10:33:27 --> UTF-8 Support Enabled
INFO - 2021-06-16 10:33:27 --> Utf8 Class Initialized
INFO - 2021-06-16 10:33:27 --> URI Class Initialized
INFO - 2021-06-16 10:33:27 --> Router Class Initialized
INFO - 2021-06-16 10:33:27 --> Output Class Initialized
INFO - 2021-06-16 10:33:27 --> Security Class Initialized
DEBUG - 2021-06-16 10:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 10:33:27 --> Input Class Initialized
INFO - 2021-06-16 10:33:27 --> Language Class Initialized
INFO - 2021-06-16 10:33:27 --> Language Class Initialized
INFO - 2021-06-16 10:33:27 --> Config Class Initialized
INFO - 2021-06-16 10:33:27 --> Loader Class Initialized
INFO - 2021-06-16 10:33:27 --> Helper loaded: url_helper
INFO - 2021-06-16 10:33:27 --> Helper loaded: file_helper
INFO - 2021-06-16 10:33:27 --> Helper loaded: form_helper
INFO - 2021-06-16 10:33:27 --> Helper loaded: my_helper
INFO - 2021-06-16 10:33:27 --> Database Driver Class Initialized
DEBUG - 2021-06-16 10:33:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 10:33:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 10:33:27 --> Controller Class Initialized
INFO - 2021-06-16 10:33:29 --> Config Class Initialized
INFO - 2021-06-16 10:33:29 --> Hooks Class Initialized
DEBUG - 2021-06-16 10:33:29 --> UTF-8 Support Enabled
INFO - 2021-06-16 10:33:29 --> Utf8 Class Initialized
INFO - 2021-06-16 10:33:29 --> URI Class Initialized
INFO - 2021-06-16 10:33:29 --> Router Class Initialized
INFO - 2021-06-16 10:33:29 --> Output Class Initialized
INFO - 2021-06-16 10:33:29 --> Security Class Initialized
DEBUG - 2021-06-16 10:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 10:33:29 --> Input Class Initialized
INFO - 2021-06-16 10:33:29 --> Language Class Initialized
INFO - 2021-06-16 10:33:29 --> Language Class Initialized
INFO - 2021-06-16 10:33:29 --> Config Class Initialized
INFO - 2021-06-16 10:33:29 --> Loader Class Initialized
INFO - 2021-06-16 10:33:29 --> Helper loaded: url_helper
INFO - 2021-06-16 10:33:29 --> Helper loaded: file_helper
INFO - 2021-06-16 10:33:29 --> Helper loaded: form_helper
INFO - 2021-06-16 10:33:29 --> Helper loaded: my_helper
INFO - 2021-06-16 10:33:29 --> Database Driver Class Initialized
DEBUG - 2021-06-16 10:33:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 10:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 10:33:29 --> Controller Class Initialized
DEBUG - 2021-06-16 10:33:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-16 10:33:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-16 10:33:29 --> Final output sent to browser
DEBUG - 2021-06-16 10:33:29 --> Total execution time: 0.0441
INFO - 2021-06-16 10:33:31 --> Config Class Initialized
INFO - 2021-06-16 10:33:31 --> Hooks Class Initialized
DEBUG - 2021-06-16 10:33:31 --> UTF-8 Support Enabled
INFO - 2021-06-16 10:33:31 --> Utf8 Class Initialized
INFO - 2021-06-16 10:33:31 --> URI Class Initialized
INFO - 2021-06-16 10:33:31 --> Router Class Initialized
INFO - 2021-06-16 10:33:31 --> Output Class Initialized
INFO - 2021-06-16 10:33:31 --> Security Class Initialized
DEBUG - 2021-06-16 10:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 10:33:31 --> Input Class Initialized
INFO - 2021-06-16 10:33:31 --> Language Class Initialized
INFO - 2021-06-16 10:33:31 --> Language Class Initialized
INFO - 2021-06-16 10:33:31 --> Config Class Initialized
INFO - 2021-06-16 10:33:31 --> Loader Class Initialized
INFO - 2021-06-16 10:33:31 --> Helper loaded: url_helper
INFO - 2021-06-16 10:33:31 --> Helper loaded: file_helper
INFO - 2021-06-16 10:33:31 --> Helper loaded: form_helper
INFO - 2021-06-16 10:33:31 --> Helper loaded: my_helper
INFO - 2021-06-16 10:33:31 --> Database Driver Class Initialized
DEBUG - 2021-06-16 10:33:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 10:33:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 10:33:31 --> Controller Class Initialized
INFO - 2021-06-16 10:33:32 --> Config Class Initialized
INFO - 2021-06-16 10:33:32 --> Hooks Class Initialized
DEBUG - 2021-06-16 10:33:32 --> UTF-8 Support Enabled
INFO - 2021-06-16 10:33:32 --> Utf8 Class Initialized
INFO - 2021-06-16 10:33:32 --> URI Class Initialized
INFO - 2021-06-16 10:33:32 --> Router Class Initialized
INFO - 2021-06-16 10:33:32 --> Output Class Initialized
INFO - 2021-06-16 10:33:32 --> Security Class Initialized
DEBUG - 2021-06-16 10:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 10:33:32 --> Input Class Initialized
INFO - 2021-06-16 10:33:32 --> Language Class Initialized
INFO - 2021-06-16 10:33:32 --> Language Class Initialized
INFO - 2021-06-16 10:33:32 --> Config Class Initialized
INFO - 2021-06-16 10:33:32 --> Loader Class Initialized
INFO - 2021-06-16 10:33:32 --> Helper loaded: url_helper
INFO - 2021-06-16 10:33:32 --> Helper loaded: file_helper
INFO - 2021-06-16 10:33:32 --> Helper loaded: form_helper
INFO - 2021-06-16 10:33:32 --> Helper loaded: my_helper
INFO - 2021-06-16 10:33:32 --> Database Driver Class Initialized
DEBUG - 2021-06-16 10:33:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 10:33:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 10:33:32 --> Controller Class Initialized
INFO - 2021-06-16 10:33:50 --> Config Class Initialized
INFO - 2021-06-16 10:33:50 --> Hooks Class Initialized
DEBUG - 2021-06-16 10:33:50 --> UTF-8 Support Enabled
INFO - 2021-06-16 10:33:50 --> Utf8 Class Initialized
INFO - 2021-06-16 10:33:50 --> URI Class Initialized
INFO - 2021-06-16 10:33:50 --> Router Class Initialized
INFO - 2021-06-16 10:33:50 --> Output Class Initialized
INFO - 2021-06-16 10:33:50 --> Security Class Initialized
DEBUG - 2021-06-16 10:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 10:33:50 --> Input Class Initialized
INFO - 2021-06-16 10:33:50 --> Language Class Initialized
INFO - 2021-06-16 10:33:50 --> Language Class Initialized
INFO - 2021-06-16 10:33:50 --> Config Class Initialized
INFO - 2021-06-16 10:33:50 --> Loader Class Initialized
INFO - 2021-06-16 10:33:50 --> Helper loaded: url_helper
INFO - 2021-06-16 10:33:50 --> Helper loaded: file_helper
INFO - 2021-06-16 10:33:50 --> Helper loaded: form_helper
INFO - 2021-06-16 10:33:50 --> Helper loaded: my_helper
INFO - 2021-06-16 10:33:50 --> Database Driver Class Initialized
DEBUG - 2021-06-16 10:33:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 10:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 10:33:50 --> Controller Class Initialized
DEBUG - 2021-06-16 10:33:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-16 10:33:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-16 10:33:50 --> Final output sent to browser
DEBUG - 2021-06-16 10:33:50 --> Total execution time: 0.0459
INFO - 2021-06-16 10:33:50 --> Config Class Initialized
INFO - 2021-06-16 10:33:50 --> Hooks Class Initialized
DEBUG - 2021-06-16 10:33:50 --> UTF-8 Support Enabled
INFO - 2021-06-16 10:33:50 --> Utf8 Class Initialized
INFO - 2021-06-16 10:33:50 --> URI Class Initialized
INFO - 2021-06-16 10:33:50 --> Router Class Initialized
INFO - 2021-06-16 10:33:50 --> Output Class Initialized
INFO - 2021-06-16 10:33:50 --> Security Class Initialized
DEBUG - 2021-06-16 10:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 10:33:50 --> Input Class Initialized
INFO - 2021-06-16 10:33:50 --> Language Class Initialized
INFO - 2021-06-16 10:33:50 --> Language Class Initialized
INFO - 2021-06-16 10:33:50 --> Config Class Initialized
INFO - 2021-06-16 10:33:50 --> Loader Class Initialized
INFO - 2021-06-16 10:33:50 --> Helper loaded: url_helper
INFO - 2021-06-16 10:33:50 --> Helper loaded: file_helper
INFO - 2021-06-16 10:33:50 --> Helper loaded: form_helper
INFO - 2021-06-16 10:33:50 --> Helper loaded: my_helper
INFO - 2021-06-16 10:33:50 --> Database Driver Class Initialized
DEBUG - 2021-06-16 10:33:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 10:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 10:33:50 --> Controller Class Initialized
INFO - 2021-06-16 10:33:51 --> Config Class Initialized
INFO - 2021-06-16 10:33:51 --> Hooks Class Initialized
DEBUG - 2021-06-16 10:33:51 --> UTF-8 Support Enabled
INFO - 2021-06-16 10:33:51 --> Utf8 Class Initialized
INFO - 2021-06-16 10:33:51 --> URI Class Initialized
INFO - 2021-06-16 10:33:51 --> Router Class Initialized
INFO - 2021-06-16 10:33:51 --> Output Class Initialized
INFO - 2021-06-16 10:33:51 --> Security Class Initialized
DEBUG - 2021-06-16 10:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 10:33:51 --> Input Class Initialized
INFO - 2021-06-16 10:33:51 --> Language Class Initialized
INFO - 2021-06-16 10:33:51 --> Language Class Initialized
INFO - 2021-06-16 10:33:51 --> Config Class Initialized
INFO - 2021-06-16 10:33:51 --> Loader Class Initialized
INFO - 2021-06-16 10:33:51 --> Helper loaded: url_helper
INFO - 2021-06-16 10:33:51 --> Helper loaded: file_helper
INFO - 2021-06-16 10:33:51 --> Helper loaded: form_helper
INFO - 2021-06-16 10:33:51 --> Helper loaded: my_helper
INFO - 2021-06-16 10:33:51 --> Database Driver Class Initialized
DEBUG - 2021-06-16 10:33:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 10:33:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 10:33:51 --> Controller Class Initialized
DEBUG - 2021-06-16 10:33:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-16 10:33:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-16 10:33:51 --> Final output sent to browser
DEBUG - 2021-06-16 10:33:51 --> Total execution time: 0.0450
INFO - 2021-06-16 10:33:52 --> Config Class Initialized
INFO - 2021-06-16 10:33:52 --> Hooks Class Initialized
DEBUG - 2021-06-16 10:33:52 --> UTF-8 Support Enabled
INFO - 2021-06-16 10:33:52 --> Utf8 Class Initialized
INFO - 2021-06-16 10:33:52 --> URI Class Initialized
INFO - 2021-06-16 10:33:52 --> Router Class Initialized
INFO - 2021-06-16 10:33:52 --> Output Class Initialized
INFO - 2021-06-16 10:33:52 --> Security Class Initialized
DEBUG - 2021-06-16 10:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 10:33:52 --> Input Class Initialized
INFO - 2021-06-16 10:33:52 --> Language Class Initialized
INFO - 2021-06-16 10:33:52 --> Language Class Initialized
INFO - 2021-06-16 10:33:52 --> Config Class Initialized
INFO - 2021-06-16 10:33:52 --> Loader Class Initialized
INFO - 2021-06-16 10:33:52 --> Helper loaded: url_helper
INFO - 2021-06-16 10:33:52 --> Helper loaded: file_helper
INFO - 2021-06-16 10:33:52 --> Helper loaded: form_helper
INFO - 2021-06-16 10:33:52 --> Helper loaded: my_helper
INFO - 2021-06-16 10:33:52 --> Database Driver Class Initialized
DEBUG - 2021-06-16 10:33:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 10:33:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 10:33:52 --> Controller Class Initialized
INFO - 2021-06-16 10:33:54 --> Config Class Initialized
INFO - 2021-06-16 10:33:54 --> Hooks Class Initialized
DEBUG - 2021-06-16 10:33:54 --> UTF-8 Support Enabled
INFO - 2021-06-16 10:33:54 --> Utf8 Class Initialized
INFO - 2021-06-16 10:33:54 --> URI Class Initialized
INFO - 2021-06-16 10:33:54 --> Router Class Initialized
INFO - 2021-06-16 10:33:54 --> Output Class Initialized
INFO - 2021-06-16 10:33:54 --> Security Class Initialized
DEBUG - 2021-06-16 10:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 10:33:54 --> Input Class Initialized
INFO - 2021-06-16 10:33:54 --> Language Class Initialized
INFO - 2021-06-16 10:33:54 --> Language Class Initialized
INFO - 2021-06-16 10:33:54 --> Config Class Initialized
INFO - 2021-06-16 10:33:54 --> Loader Class Initialized
INFO - 2021-06-16 10:33:54 --> Helper loaded: url_helper
INFO - 2021-06-16 10:33:54 --> Helper loaded: file_helper
INFO - 2021-06-16 10:33:54 --> Helper loaded: form_helper
INFO - 2021-06-16 10:33:54 --> Helper loaded: my_helper
INFO - 2021-06-16 10:33:54 --> Database Driver Class Initialized
DEBUG - 2021-06-16 10:33:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 10:33:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 10:33:54 --> Controller Class Initialized
INFO - 2021-06-16 10:34:14 --> Config Class Initialized
INFO - 2021-06-16 10:34:14 --> Hooks Class Initialized
DEBUG - 2021-06-16 10:34:14 --> UTF-8 Support Enabled
INFO - 2021-06-16 10:34:14 --> Utf8 Class Initialized
INFO - 2021-06-16 10:34:14 --> URI Class Initialized
INFO - 2021-06-16 10:34:14 --> Router Class Initialized
INFO - 2021-06-16 10:34:14 --> Output Class Initialized
INFO - 2021-06-16 10:34:14 --> Security Class Initialized
DEBUG - 2021-06-16 10:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 10:34:14 --> Input Class Initialized
INFO - 2021-06-16 10:34:14 --> Language Class Initialized
INFO - 2021-06-16 10:34:14 --> Language Class Initialized
INFO - 2021-06-16 10:34:14 --> Config Class Initialized
INFO - 2021-06-16 10:34:14 --> Loader Class Initialized
INFO - 2021-06-16 10:34:14 --> Helper loaded: url_helper
INFO - 2021-06-16 10:34:14 --> Helper loaded: file_helper
INFO - 2021-06-16 10:34:14 --> Helper loaded: form_helper
INFO - 2021-06-16 10:34:14 --> Helper loaded: my_helper
INFO - 2021-06-16 10:34:14 --> Database Driver Class Initialized
DEBUG - 2021-06-16 10:34:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 10:34:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 10:34:14 --> Controller Class Initialized
DEBUG - 2021-06-16 10:34:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-16 10:34:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-16 10:34:14 --> Final output sent to browser
DEBUG - 2021-06-16 10:34:14 --> Total execution time: 0.0464
INFO - 2021-06-16 10:34:14 --> Config Class Initialized
INFO - 2021-06-16 10:34:14 --> Hooks Class Initialized
DEBUG - 2021-06-16 10:34:14 --> UTF-8 Support Enabled
INFO - 2021-06-16 10:34:14 --> Utf8 Class Initialized
INFO - 2021-06-16 10:34:14 --> URI Class Initialized
INFO - 2021-06-16 10:34:14 --> Router Class Initialized
INFO - 2021-06-16 10:34:14 --> Output Class Initialized
INFO - 2021-06-16 10:34:14 --> Security Class Initialized
DEBUG - 2021-06-16 10:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 10:34:14 --> Input Class Initialized
INFO - 2021-06-16 10:34:14 --> Language Class Initialized
INFO - 2021-06-16 10:34:14 --> Language Class Initialized
INFO - 2021-06-16 10:34:14 --> Config Class Initialized
INFO - 2021-06-16 10:34:14 --> Loader Class Initialized
INFO - 2021-06-16 10:34:14 --> Helper loaded: url_helper
INFO - 2021-06-16 10:34:14 --> Helper loaded: file_helper
INFO - 2021-06-16 10:34:14 --> Helper loaded: form_helper
INFO - 2021-06-16 10:34:14 --> Helper loaded: my_helper
INFO - 2021-06-16 10:34:14 --> Database Driver Class Initialized
DEBUG - 2021-06-16 10:34:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 10:34:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 10:34:14 --> Controller Class Initialized
INFO - 2021-06-16 10:34:15 --> Config Class Initialized
INFO - 2021-06-16 10:34:15 --> Hooks Class Initialized
DEBUG - 2021-06-16 10:34:15 --> UTF-8 Support Enabled
INFO - 2021-06-16 10:34:15 --> Utf8 Class Initialized
INFO - 2021-06-16 10:34:15 --> URI Class Initialized
INFO - 2021-06-16 10:34:15 --> Router Class Initialized
INFO - 2021-06-16 10:34:15 --> Output Class Initialized
INFO - 2021-06-16 10:34:15 --> Security Class Initialized
DEBUG - 2021-06-16 10:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 10:34:15 --> Input Class Initialized
INFO - 2021-06-16 10:34:15 --> Language Class Initialized
INFO - 2021-06-16 10:34:15 --> Language Class Initialized
INFO - 2021-06-16 10:34:15 --> Config Class Initialized
INFO - 2021-06-16 10:34:15 --> Loader Class Initialized
INFO - 2021-06-16 10:34:15 --> Helper loaded: url_helper
INFO - 2021-06-16 10:34:15 --> Helper loaded: file_helper
INFO - 2021-06-16 10:34:15 --> Helper loaded: form_helper
INFO - 2021-06-16 10:34:15 --> Helper loaded: my_helper
INFO - 2021-06-16 10:34:15 --> Database Driver Class Initialized
DEBUG - 2021-06-16 10:34:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 10:34:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 10:34:15 --> Controller Class Initialized
DEBUG - 2021-06-16 10:34:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-16 10:34:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-16 10:34:15 --> Final output sent to browser
DEBUG - 2021-06-16 10:34:15 --> Total execution time: 0.0446
INFO - 2021-06-16 10:34:17 --> Config Class Initialized
INFO - 2021-06-16 10:34:17 --> Hooks Class Initialized
DEBUG - 2021-06-16 10:34:17 --> UTF-8 Support Enabled
INFO - 2021-06-16 10:34:17 --> Utf8 Class Initialized
INFO - 2021-06-16 10:34:17 --> URI Class Initialized
INFO - 2021-06-16 10:34:17 --> Router Class Initialized
INFO - 2021-06-16 10:34:17 --> Output Class Initialized
INFO - 2021-06-16 10:34:17 --> Security Class Initialized
DEBUG - 2021-06-16 10:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 10:34:17 --> Input Class Initialized
INFO - 2021-06-16 10:34:17 --> Language Class Initialized
INFO - 2021-06-16 10:34:17 --> Language Class Initialized
INFO - 2021-06-16 10:34:17 --> Config Class Initialized
INFO - 2021-06-16 10:34:17 --> Loader Class Initialized
INFO - 2021-06-16 10:34:17 --> Helper loaded: url_helper
INFO - 2021-06-16 10:34:17 --> Helper loaded: file_helper
INFO - 2021-06-16 10:34:17 --> Helper loaded: form_helper
INFO - 2021-06-16 10:34:17 --> Helper loaded: my_helper
INFO - 2021-06-16 10:34:17 --> Database Driver Class Initialized
DEBUG - 2021-06-16 10:34:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 10:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 10:34:17 --> Controller Class Initialized
INFO - 2021-06-16 10:34:18 --> Config Class Initialized
INFO - 2021-06-16 10:34:18 --> Hooks Class Initialized
DEBUG - 2021-06-16 10:34:18 --> UTF-8 Support Enabled
INFO - 2021-06-16 10:34:18 --> Utf8 Class Initialized
INFO - 2021-06-16 10:34:18 --> URI Class Initialized
INFO - 2021-06-16 10:34:18 --> Router Class Initialized
INFO - 2021-06-16 10:34:18 --> Output Class Initialized
INFO - 2021-06-16 10:34:18 --> Security Class Initialized
DEBUG - 2021-06-16 10:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 10:34:18 --> Input Class Initialized
INFO - 2021-06-16 10:34:18 --> Language Class Initialized
INFO - 2021-06-16 10:34:18 --> Language Class Initialized
INFO - 2021-06-16 10:34:18 --> Config Class Initialized
INFO - 2021-06-16 10:34:18 --> Loader Class Initialized
INFO - 2021-06-16 10:34:18 --> Helper loaded: url_helper
INFO - 2021-06-16 10:34:18 --> Helper loaded: file_helper
INFO - 2021-06-16 10:34:18 --> Helper loaded: form_helper
INFO - 2021-06-16 10:34:18 --> Helper loaded: my_helper
INFO - 2021-06-16 10:34:18 --> Database Driver Class Initialized
DEBUG - 2021-06-16 10:34:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 10:34:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 10:34:18 --> Controller Class Initialized
INFO - 2021-06-16 10:34:33 --> Config Class Initialized
INFO - 2021-06-16 10:34:33 --> Hooks Class Initialized
DEBUG - 2021-06-16 10:34:33 --> UTF-8 Support Enabled
INFO - 2021-06-16 10:34:33 --> Utf8 Class Initialized
INFO - 2021-06-16 10:34:33 --> URI Class Initialized
INFO - 2021-06-16 10:34:33 --> Router Class Initialized
INFO - 2021-06-16 10:34:33 --> Output Class Initialized
INFO - 2021-06-16 10:34:33 --> Security Class Initialized
DEBUG - 2021-06-16 10:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 10:34:33 --> Input Class Initialized
INFO - 2021-06-16 10:34:33 --> Language Class Initialized
INFO - 2021-06-16 10:34:33 --> Language Class Initialized
INFO - 2021-06-16 10:34:33 --> Config Class Initialized
INFO - 2021-06-16 10:34:33 --> Loader Class Initialized
INFO - 2021-06-16 10:34:33 --> Helper loaded: url_helper
INFO - 2021-06-16 10:34:33 --> Helper loaded: file_helper
INFO - 2021-06-16 10:34:33 --> Helper loaded: form_helper
INFO - 2021-06-16 10:34:33 --> Helper loaded: my_helper
INFO - 2021-06-16 10:34:33 --> Database Driver Class Initialized
DEBUG - 2021-06-16 10:34:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 10:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 10:34:33 --> Controller Class Initialized
DEBUG - 2021-06-16 10:34:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-16 10:34:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-16 10:34:33 --> Final output sent to browser
DEBUG - 2021-06-16 10:34:33 --> Total execution time: 0.0452
INFO - 2021-06-16 10:34:33 --> Config Class Initialized
INFO - 2021-06-16 10:34:33 --> Hooks Class Initialized
DEBUG - 2021-06-16 10:34:33 --> UTF-8 Support Enabled
INFO - 2021-06-16 10:34:33 --> Utf8 Class Initialized
INFO - 2021-06-16 10:34:33 --> URI Class Initialized
INFO - 2021-06-16 10:34:33 --> Router Class Initialized
INFO - 2021-06-16 10:34:33 --> Output Class Initialized
INFO - 2021-06-16 10:34:33 --> Security Class Initialized
DEBUG - 2021-06-16 10:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 10:34:33 --> Input Class Initialized
INFO - 2021-06-16 10:34:33 --> Language Class Initialized
INFO - 2021-06-16 10:34:33 --> Language Class Initialized
INFO - 2021-06-16 10:34:33 --> Config Class Initialized
INFO - 2021-06-16 10:34:33 --> Loader Class Initialized
INFO - 2021-06-16 10:34:33 --> Helper loaded: url_helper
INFO - 2021-06-16 10:34:33 --> Helper loaded: file_helper
INFO - 2021-06-16 10:34:33 --> Helper loaded: form_helper
INFO - 2021-06-16 10:34:33 --> Helper loaded: my_helper
INFO - 2021-06-16 10:34:33 --> Database Driver Class Initialized
DEBUG - 2021-06-16 10:34:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 10:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 10:34:33 --> Controller Class Initialized
INFO - 2021-06-16 10:34:35 --> Config Class Initialized
INFO - 2021-06-16 10:34:35 --> Hooks Class Initialized
DEBUG - 2021-06-16 10:34:35 --> UTF-8 Support Enabled
INFO - 2021-06-16 10:34:35 --> Utf8 Class Initialized
INFO - 2021-06-16 10:34:35 --> URI Class Initialized
INFO - 2021-06-16 10:34:35 --> Router Class Initialized
INFO - 2021-06-16 10:34:35 --> Output Class Initialized
INFO - 2021-06-16 10:34:35 --> Security Class Initialized
DEBUG - 2021-06-16 10:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 10:34:35 --> Input Class Initialized
INFO - 2021-06-16 10:34:35 --> Language Class Initialized
INFO - 2021-06-16 10:34:35 --> Language Class Initialized
INFO - 2021-06-16 10:34:35 --> Config Class Initialized
INFO - 2021-06-16 10:34:35 --> Loader Class Initialized
INFO - 2021-06-16 10:34:35 --> Helper loaded: url_helper
INFO - 2021-06-16 10:34:35 --> Helper loaded: file_helper
INFO - 2021-06-16 10:34:35 --> Helper loaded: form_helper
INFO - 2021-06-16 10:34:35 --> Helper loaded: my_helper
INFO - 2021-06-16 10:34:35 --> Database Driver Class Initialized
DEBUG - 2021-06-16 10:34:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 10:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 10:34:35 --> Controller Class Initialized
DEBUG - 2021-06-16 10:34:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-16 10:34:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-16 10:34:35 --> Final output sent to browser
DEBUG - 2021-06-16 10:34:35 --> Total execution time: 0.0456
INFO - 2021-06-16 10:34:37 --> Config Class Initialized
INFO - 2021-06-16 10:34:37 --> Hooks Class Initialized
DEBUG - 2021-06-16 10:34:37 --> UTF-8 Support Enabled
INFO - 2021-06-16 10:34:37 --> Utf8 Class Initialized
INFO - 2021-06-16 10:34:37 --> URI Class Initialized
INFO - 2021-06-16 10:34:37 --> Router Class Initialized
INFO - 2021-06-16 10:34:37 --> Output Class Initialized
INFO - 2021-06-16 10:34:37 --> Security Class Initialized
DEBUG - 2021-06-16 10:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 10:34:37 --> Input Class Initialized
INFO - 2021-06-16 10:34:37 --> Language Class Initialized
INFO - 2021-06-16 10:34:37 --> Language Class Initialized
INFO - 2021-06-16 10:34:37 --> Config Class Initialized
INFO - 2021-06-16 10:34:37 --> Loader Class Initialized
INFO - 2021-06-16 10:34:37 --> Helper loaded: url_helper
INFO - 2021-06-16 10:34:37 --> Helper loaded: file_helper
INFO - 2021-06-16 10:34:37 --> Helper loaded: form_helper
INFO - 2021-06-16 10:34:37 --> Helper loaded: my_helper
INFO - 2021-06-16 10:34:37 --> Database Driver Class Initialized
DEBUG - 2021-06-16 10:34:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 10:34:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 10:34:37 --> Controller Class Initialized
INFO - 2021-06-16 10:34:38 --> Config Class Initialized
INFO - 2021-06-16 10:34:38 --> Hooks Class Initialized
DEBUG - 2021-06-16 10:34:38 --> UTF-8 Support Enabled
INFO - 2021-06-16 10:34:38 --> Utf8 Class Initialized
INFO - 2021-06-16 10:34:38 --> URI Class Initialized
INFO - 2021-06-16 10:34:38 --> Router Class Initialized
INFO - 2021-06-16 10:34:38 --> Output Class Initialized
INFO - 2021-06-16 10:34:38 --> Security Class Initialized
DEBUG - 2021-06-16 10:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 10:34:38 --> Input Class Initialized
INFO - 2021-06-16 10:34:38 --> Language Class Initialized
INFO - 2021-06-16 10:34:38 --> Language Class Initialized
INFO - 2021-06-16 10:34:38 --> Config Class Initialized
INFO - 2021-06-16 10:34:38 --> Loader Class Initialized
INFO - 2021-06-16 10:34:38 --> Helper loaded: url_helper
INFO - 2021-06-16 10:34:38 --> Helper loaded: file_helper
INFO - 2021-06-16 10:34:38 --> Helper loaded: form_helper
INFO - 2021-06-16 10:34:38 --> Helper loaded: my_helper
INFO - 2021-06-16 10:34:38 --> Database Driver Class Initialized
DEBUG - 2021-06-16 10:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 10:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 10:34:38 --> Controller Class Initialized
INFO - 2021-06-16 10:34:57 --> Config Class Initialized
INFO - 2021-06-16 10:34:57 --> Hooks Class Initialized
DEBUG - 2021-06-16 10:34:57 --> UTF-8 Support Enabled
INFO - 2021-06-16 10:34:57 --> Utf8 Class Initialized
INFO - 2021-06-16 10:34:57 --> URI Class Initialized
INFO - 2021-06-16 10:34:57 --> Router Class Initialized
INFO - 2021-06-16 10:34:57 --> Output Class Initialized
INFO - 2021-06-16 10:34:57 --> Security Class Initialized
DEBUG - 2021-06-16 10:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 10:34:57 --> Input Class Initialized
INFO - 2021-06-16 10:34:57 --> Language Class Initialized
INFO - 2021-06-16 10:34:57 --> Language Class Initialized
INFO - 2021-06-16 10:34:57 --> Config Class Initialized
INFO - 2021-06-16 10:34:57 --> Loader Class Initialized
INFO - 2021-06-16 10:34:57 --> Helper loaded: url_helper
INFO - 2021-06-16 10:34:57 --> Helper loaded: file_helper
INFO - 2021-06-16 10:34:57 --> Helper loaded: form_helper
INFO - 2021-06-16 10:34:57 --> Helper loaded: my_helper
INFO - 2021-06-16 10:34:57 --> Database Driver Class Initialized
DEBUG - 2021-06-16 10:34:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 10:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 10:34:57 --> Controller Class Initialized
DEBUG - 2021-06-16 10:34:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-16 10:34:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-16 10:34:57 --> Final output sent to browser
DEBUG - 2021-06-16 10:34:57 --> Total execution time: 0.0458
INFO - 2021-06-16 10:34:57 --> Config Class Initialized
INFO - 2021-06-16 10:34:57 --> Hooks Class Initialized
DEBUG - 2021-06-16 10:34:57 --> UTF-8 Support Enabled
INFO - 2021-06-16 10:34:57 --> Utf8 Class Initialized
INFO - 2021-06-16 10:34:57 --> URI Class Initialized
INFO - 2021-06-16 10:34:57 --> Router Class Initialized
INFO - 2021-06-16 10:34:57 --> Output Class Initialized
INFO - 2021-06-16 10:34:57 --> Security Class Initialized
DEBUG - 2021-06-16 10:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 10:34:57 --> Input Class Initialized
INFO - 2021-06-16 10:34:57 --> Language Class Initialized
INFO - 2021-06-16 10:34:57 --> Language Class Initialized
INFO - 2021-06-16 10:34:57 --> Config Class Initialized
INFO - 2021-06-16 10:34:57 --> Loader Class Initialized
INFO - 2021-06-16 10:34:57 --> Helper loaded: url_helper
INFO - 2021-06-16 10:34:57 --> Helper loaded: file_helper
INFO - 2021-06-16 10:34:57 --> Helper loaded: form_helper
INFO - 2021-06-16 10:34:57 --> Helper loaded: my_helper
INFO - 2021-06-16 10:34:57 --> Database Driver Class Initialized
DEBUG - 2021-06-16 10:34:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 10:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 10:34:57 --> Controller Class Initialized
INFO - 2021-06-16 10:34:58 --> Config Class Initialized
INFO - 2021-06-16 10:34:58 --> Hooks Class Initialized
DEBUG - 2021-06-16 10:34:58 --> UTF-8 Support Enabled
INFO - 2021-06-16 10:34:58 --> Utf8 Class Initialized
INFO - 2021-06-16 10:34:58 --> URI Class Initialized
INFO - 2021-06-16 10:34:58 --> Router Class Initialized
INFO - 2021-06-16 10:34:58 --> Output Class Initialized
INFO - 2021-06-16 10:34:58 --> Security Class Initialized
DEBUG - 2021-06-16 10:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 10:34:58 --> Input Class Initialized
INFO - 2021-06-16 10:34:58 --> Language Class Initialized
INFO - 2021-06-16 10:34:59 --> Language Class Initialized
INFO - 2021-06-16 10:34:59 --> Config Class Initialized
INFO - 2021-06-16 10:34:59 --> Loader Class Initialized
INFO - 2021-06-16 10:34:59 --> Helper loaded: url_helper
INFO - 2021-06-16 10:34:59 --> Helper loaded: file_helper
INFO - 2021-06-16 10:34:59 --> Helper loaded: form_helper
INFO - 2021-06-16 10:34:59 --> Helper loaded: my_helper
INFO - 2021-06-16 10:34:59 --> Database Driver Class Initialized
DEBUG - 2021-06-16 10:34:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 10:34:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 10:34:59 --> Controller Class Initialized
DEBUG - 2021-06-16 10:34:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-16 10:34:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-16 10:34:59 --> Final output sent to browser
DEBUG - 2021-06-16 10:34:59 --> Total execution time: 0.0455
INFO - 2021-06-16 10:35:01 --> Config Class Initialized
INFO - 2021-06-16 10:35:01 --> Hooks Class Initialized
DEBUG - 2021-06-16 10:35:01 --> UTF-8 Support Enabled
INFO - 2021-06-16 10:35:01 --> Utf8 Class Initialized
INFO - 2021-06-16 10:35:01 --> URI Class Initialized
INFO - 2021-06-16 10:35:01 --> Router Class Initialized
INFO - 2021-06-16 10:35:01 --> Output Class Initialized
INFO - 2021-06-16 10:35:01 --> Security Class Initialized
DEBUG - 2021-06-16 10:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 10:35:01 --> Input Class Initialized
INFO - 2021-06-16 10:35:01 --> Language Class Initialized
INFO - 2021-06-16 10:35:01 --> Language Class Initialized
INFO - 2021-06-16 10:35:01 --> Config Class Initialized
INFO - 2021-06-16 10:35:01 --> Loader Class Initialized
INFO - 2021-06-16 10:35:01 --> Helper loaded: url_helper
INFO - 2021-06-16 10:35:01 --> Helper loaded: file_helper
INFO - 2021-06-16 10:35:01 --> Helper loaded: form_helper
INFO - 2021-06-16 10:35:01 --> Helper loaded: my_helper
INFO - 2021-06-16 10:35:01 --> Database Driver Class Initialized
DEBUG - 2021-06-16 10:35:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 10:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 10:35:01 --> Controller Class Initialized
INFO - 2021-06-16 10:35:03 --> Config Class Initialized
INFO - 2021-06-16 10:35:03 --> Hooks Class Initialized
DEBUG - 2021-06-16 10:35:03 --> UTF-8 Support Enabled
INFO - 2021-06-16 10:35:03 --> Utf8 Class Initialized
INFO - 2021-06-16 10:35:03 --> URI Class Initialized
INFO - 2021-06-16 10:35:03 --> Router Class Initialized
INFO - 2021-06-16 10:35:03 --> Output Class Initialized
INFO - 2021-06-16 10:35:03 --> Security Class Initialized
DEBUG - 2021-06-16 10:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 10:35:03 --> Input Class Initialized
INFO - 2021-06-16 10:35:03 --> Language Class Initialized
INFO - 2021-06-16 10:35:03 --> Language Class Initialized
INFO - 2021-06-16 10:35:03 --> Config Class Initialized
INFO - 2021-06-16 10:35:03 --> Loader Class Initialized
INFO - 2021-06-16 10:35:03 --> Helper loaded: url_helper
INFO - 2021-06-16 10:35:03 --> Helper loaded: file_helper
INFO - 2021-06-16 10:35:03 --> Helper loaded: form_helper
INFO - 2021-06-16 10:35:03 --> Helper loaded: my_helper
INFO - 2021-06-16 10:35:03 --> Database Driver Class Initialized
DEBUG - 2021-06-16 10:35:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 10:35:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 10:35:03 --> Controller Class Initialized
