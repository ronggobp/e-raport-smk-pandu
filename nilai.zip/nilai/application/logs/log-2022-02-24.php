<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-02-24 05:14:31 --> Config Class Initialized
INFO - 2022-02-24 05:14:31 --> Hooks Class Initialized
DEBUG - 2022-02-24 05:14:31 --> UTF-8 Support Enabled
INFO - 2022-02-24 05:14:31 --> Utf8 Class Initialized
INFO - 2022-02-24 05:14:31 --> URI Class Initialized
DEBUG - 2022-02-24 05:14:31 --> No URI present. Default controller set.
INFO - 2022-02-24 05:14:31 --> Router Class Initialized
INFO - 2022-02-24 05:14:31 --> Output Class Initialized
INFO - 2022-02-24 05:14:31 --> Security Class Initialized
DEBUG - 2022-02-24 05:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 05:14:31 --> Input Class Initialized
INFO - 2022-02-24 05:14:31 --> Language Class Initialized
INFO - 2022-02-24 05:14:31 --> Language Class Initialized
INFO - 2022-02-24 05:14:31 --> Config Class Initialized
INFO - 2022-02-24 05:14:31 --> Loader Class Initialized
INFO - 2022-02-24 05:14:31 --> Helper loaded: url_helper
INFO - 2022-02-24 05:14:31 --> Helper loaded: file_helper
INFO - 2022-02-24 05:14:31 --> Helper loaded: form_helper
INFO - 2022-02-24 05:14:31 --> Helper loaded: my_helper
INFO - 2022-02-24 05:14:31 --> Database Driver Class Initialized
DEBUG - 2022-02-24 05:14:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-24 05:14:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-24 05:14:31 --> Controller Class Initialized
INFO - 2022-02-24 05:14:31 --> Config Class Initialized
INFO - 2022-02-24 05:14:31 --> Hooks Class Initialized
DEBUG - 2022-02-24 05:14:31 --> UTF-8 Support Enabled
INFO - 2022-02-24 05:14:31 --> Utf8 Class Initialized
INFO - 2022-02-24 05:14:31 --> URI Class Initialized
INFO - 2022-02-24 05:14:31 --> Router Class Initialized
INFO - 2022-02-24 05:14:31 --> Output Class Initialized
INFO - 2022-02-24 05:14:31 --> Security Class Initialized
DEBUG - 2022-02-24 05:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 05:14:31 --> Input Class Initialized
INFO - 2022-02-24 05:14:31 --> Language Class Initialized
INFO - 2022-02-24 05:14:31 --> Language Class Initialized
INFO - 2022-02-24 05:14:31 --> Config Class Initialized
INFO - 2022-02-24 05:14:31 --> Loader Class Initialized
INFO - 2022-02-24 05:14:31 --> Helper loaded: url_helper
INFO - 2022-02-24 05:14:31 --> Helper loaded: file_helper
INFO - 2022-02-24 05:14:31 --> Helper loaded: form_helper
INFO - 2022-02-24 05:14:31 --> Helper loaded: my_helper
INFO - 2022-02-24 05:14:31 --> Database Driver Class Initialized
DEBUG - 2022-02-24 05:14:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-24 05:14:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-24 05:14:31 --> Controller Class Initialized
DEBUG - 2022-02-24 05:14:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-02-24 05:14:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-02-24 05:14:31 --> Final output sent to browser
DEBUG - 2022-02-24 05:14:31 --> Total execution time: 0.0751
INFO - 2022-02-24 05:26:10 --> Config Class Initialized
INFO - 2022-02-24 05:26:10 --> Hooks Class Initialized
DEBUG - 2022-02-24 05:26:10 --> UTF-8 Support Enabled
INFO - 2022-02-24 05:26:10 --> Utf8 Class Initialized
INFO - 2022-02-24 05:26:10 --> URI Class Initialized
INFO - 2022-02-24 05:26:10 --> Router Class Initialized
INFO - 2022-02-24 05:26:10 --> Output Class Initialized
INFO - 2022-02-24 05:26:10 --> Security Class Initialized
DEBUG - 2022-02-24 05:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 05:26:10 --> Input Class Initialized
INFO - 2022-02-24 05:26:10 --> Language Class Initialized
INFO - 2022-02-24 05:26:10 --> Language Class Initialized
INFO - 2022-02-24 05:26:10 --> Config Class Initialized
INFO - 2022-02-24 05:26:10 --> Loader Class Initialized
INFO - 2022-02-24 05:26:10 --> Helper loaded: url_helper
INFO - 2022-02-24 05:26:10 --> Helper loaded: file_helper
INFO - 2022-02-24 05:26:10 --> Helper loaded: form_helper
INFO - 2022-02-24 05:26:10 --> Helper loaded: my_helper
INFO - 2022-02-24 05:26:10 --> Database Driver Class Initialized
DEBUG - 2022-02-24 05:26:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-24 05:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-24 05:26:10 --> Controller Class Initialized
INFO - 2022-02-24 05:26:10 --> Helper loaded: cookie_helper
INFO - 2022-02-24 05:26:10 --> Final output sent to browser
DEBUG - 2022-02-24 05:26:10 --> Total execution time: 0.1961
INFO - 2022-02-24 05:26:11 --> Config Class Initialized
INFO - 2022-02-24 05:26:11 --> Hooks Class Initialized
DEBUG - 2022-02-24 05:26:11 --> UTF-8 Support Enabled
INFO - 2022-02-24 05:26:11 --> Utf8 Class Initialized
INFO - 2022-02-24 05:26:11 --> URI Class Initialized
INFO - 2022-02-24 05:26:11 --> Router Class Initialized
INFO - 2022-02-24 05:26:11 --> Output Class Initialized
INFO - 2022-02-24 05:26:11 --> Security Class Initialized
DEBUG - 2022-02-24 05:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 05:26:11 --> Input Class Initialized
INFO - 2022-02-24 05:26:11 --> Language Class Initialized
INFO - 2022-02-24 05:26:11 --> Language Class Initialized
INFO - 2022-02-24 05:26:11 --> Config Class Initialized
INFO - 2022-02-24 05:26:11 --> Loader Class Initialized
INFO - 2022-02-24 05:26:11 --> Helper loaded: url_helper
INFO - 2022-02-24 05:26:11 --> Helper loaded: file_helper
INFO - 2022-02-24 05:26:11 --> Helper loaded: form_helper
INFO - 2022-02-24 05:26:11 --> Helper loaded: my_helper
INFO - 2022-02-24 05:26:11 --> Database Driver Class Initialized
DEBUG - 2022-02-24 05:26:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-24 05:26:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-24 05:26:11 --> Controller Class Initialized
DEBUG - 2022-02-24 05:26:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-02-24 05:26:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-02-24 05:26:13 --> Final output sent to browser
DEBUG - 2022-02-24 05:26:13 --> Total execution time: 2.6078
INFO - 2022-02-24 05:26:15 --> Config Class Initialized
INFO - 2022-02-24 05:26:15 --> Hooks Class Initialized
DEBUG - 2022-02-24 05:26:15 --> UTF-8 Support Enabled
INFO - 2022-02-24 05:26:15 --> Utf8 Class Initialized
INFO - 2022-02-24 05:26:15 --> URI Class Initialized
INFO - 2022-02-24 05:26:15 --> Router Class Initialized
INFO - 2022-02-24 05:26:15 --> Output Class Initialized
INFO - 2022-02-24 05:26:15 --> Security Class Initialized
DEBUG - 2022-02-24 05:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 05:26:15 --> Input Class Initialized
INFO - 2022-02-24 05:26:15 --> Language Class Initialized
INFO - 2022-02-24 05:26:15 --> Language Class Initialized
INFO - 2022-02-24 05:26:15 --> Config Class Initialized
INFO - 2022-02-24 05:26:15 --> Loader Class Initialized
INFO - 2022-02-24 05:26:15 --> Helper loaded: url_helper
INFO - 2022-02-24 05:26:15 --> Helper loaded: file_helper
INFO - 2022-02-24 05:26:15 --> Helper loaded: form_helper
INFO - 2022-02-24 05:26:15 --> Helper loaded: my_helper
INFO - 2022-02-24 05:26:15 --> Database Driver Class Initialized
DEBUG - 2022-02-24 05:26:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-24 05:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-24 05:26:15 --> Controller Class Initialized
DEBUG - 2022-02-24 05:26:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2022-02-24 05:26:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-02-24 05:26:15 --> Final output sent to browser
DEBUG - 2022-02-24 05:26:15 --> Total execution time: 0.1425
INFO - 2022-02-24 05:34:45 --> Config Class Initialized
INFO - 2022-02-24 05:34:45 --> Hooks Class Initialized
DEBUG - 2022-02-24 05:34:45 --> UTF-8 Support Enabled
INFO - 2022-02-24 05:34:45 --> Utf8 Class Initialized
INFO - 2022-02-24 05:34:45 --> URI Class Initialized
INFO - 2022-02-24 05:34:45 --> Router Class Initialized
INFO - 2022-02-24 05:34:45 --> Output Class Initialized
INFO - 2022-02-24 05:34:45 --> Security Class Initialized
DEBUG - 2022-02-24 05:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 05:34:45 --> Input Class Initialized
INFO - 2022-02-24 05:34:45 --> Language Class Initialized
INFO - 2022-02-24 05:34:45 --> Language Class Initialized
INFO - 2022-02-24 05:34:45 --> Config Class Initialized
INFO - 2022-02-24 05:34:45 --> Loader Class Initialized
INFO - 2022-02-24 05:34:45 --> Helper loaded: url_helper
INFO - 2022-02-24 05:34:45 --> Helper loaded: file_helper
INFO - 2022-02-24 05:34:45 --> Helper loaded: form_helper
INFO - 2022-02-24 05:34:45 --> Helper loaded: my_helper
INFO - 2022-02-24 05:34:45 --> Database Driver Class Initialized
DEBUG - 2022-02-24 05:34:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-24 05:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-24 05:34:45 --> Controller Class Initialized
INFO - 2022-02-24 05:34:45 --> Helper loaded: cookie_helper
INFO - 2022-02-24 05:34:45 --> Config Class Initialized
INFO - 2022-02-24 05:34:45 --> Hooks Class Initialized
DEBUG - 2022-02-24 05:34:45 --> UTF-8 Support Enabled
INFO - 2022-02-24 05:34:45 --> Utf8 Class Initialized
INFO - 2022-02-24 05:34:45 --> URI Class Initialized
INFO - 2022-02-24 05:34:45 --> Router Class Initialized
INFO - 2022-02-24 05:34:45 --> Output Class Initialized
INFO - 2022-02-24 05:34:45 --> Security Class Initialized
DEBUG - 2022-02-24 05:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 05:34:45 --> Input Class Initialized
INFO - 2022-02-24 05:34:45 --> Language Class Initialized
INFO - 2022-02-24 05:34:45 --> Language Class Initialized
INFO - 2022-02-24 05:34:45 --> Config Class Initialized
INFO - 2022-02-24 05:34:45 --> Loader Class Initialized
INFO - 2022-02-24 05:34:45 --> Helper loaded: url_helper
INFO - 2022-02-24 05:34:45 --> Helper loaded: file_helper
INFO - 2022-02-24 05:34:45 --> Helper loaded: form_helper
INFO - 2022-02-24 05:34:45 --> Helper loaded: my_helper
INFO - 2022-02-24 05:34:45 --> Database Driver Class Initialized
DEBUG - 2022-02-24 05:34:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-24 05:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-24 05:34:45 --> Controller Class Initialized
DEBUG - 2022-02-24 05:34:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-02-24 05:34:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-02-24 05:34:45 --> Final output sent to browser
DEBUG - 2022-02-24 05:34:45 --> Total execution time: 0.0638
INFO - 2022-02-24 05:34:49 --> Config Class Initialized
INFO - 2022-02-24 05:34:49 --> Hooks Class Initialized
DEBUG - 2022-02-24 05:34:49 --> UTF-8 Support Enabled
INFO - 2022-02-24 05:34:49 --> Utf8 Class Initialized
INFO - 2022-02-24 05:34:49 --> URI Class Initialized
INFO - 2022-02-24 05:34:49 --> Router Class Initialized
INFO - 2022-02-24 05:34:49 --> Output Class Initialized
INFO - 2022-02-24 05:34:49 --> Security Class Initialized
DEBUG - 2022-02-24 05:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 05:34:49 --> Input Class Initialized
INFO - 2022-02-24 05:34:49 --> Language Class Initialized
INFO - 2022-02-24 05:34:49 --> Language Class Initialized
INFO - 2022-02-24 05:34:49 --> Config Class Initialized
INFO - 2022-02-24 05:34:49 --> Loader Class Initialized
INFO - 2022-02-24 05:34:49 --> Helper loaded: url_helper
INFO - 2022-02-24 05:34:49 --> Helper loaded: file_helper
INFO - 2022-02-24 05:34:49 --> Helper loaded: form_helper
INFO - 2022-02-24 05:34:49 --> Helper loaded: my_helper
INFO - 2022-02-24 05:34:49 --> Database Driver Class Initialized
DEBUG - 2022-02-24 05:34:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-24 05:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-24 05:34:49 --> Controller Class Initialized
INFO - 2022-02-24 05:34:49 --> Helper loaded: cookie_helper
INFO - 2022-02-24 05:34:49 --> Final output sent to browser
DEBUG - 2022-02-24 05:34:49 --> Total execution time: 0.0954
INFO - 2022-02-24 05:34:49 --> Config Class Initialized
INFO - 2022-02-24 05:34:49 --> Hooks Class Initialized
DEBUG - 2022-02-24 05:34:49 --> UTF-8 Support Enabled
INFO - 2022-02-24 05:34:49 --> Utf8 Class Initialized
INFO - 2022-02-24 05:34:49 --> URI Class Initialized
INFO - 2022-02-24 05:34:49 --> Router Class Initialized
INFO - 2022-02-24 05:34:49 --> Output Class Initialized
INFO - 2022-02-24 05:34:49 --> Security Class Initialized
DEBUG - 2022-02-24 05:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 05:34:49 --> Input Class Initialized
INFO - 2022-02-24 05:34:49 --> Language Class Initialized
INFO - 2022-02-24 05:34:49 --> Language Class Initialized
INFO - 2022-02-24 05:34:49 --> Config Class Initialized
INFO - 2022-02-24 05:34:49 --> Loader Class Initialized
INFO - 2022-02-24 05:34:49 --> Helper loaded: url_helper
INFO - 2022-02-24 05:34:49 --> Helper loaded: file_helper
INFO - 2022-02-24 05:34:49 --> Helper loaded: form_helper
INFO - 2022-02-24 05:34:49 --> Helper loaded: my_helper
INFO - 2022-02-24 05:34:49 --> Database Driver Class Initialized
DEBUG - 2022-02-24 05:34:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-24 05:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-24 05:34:49 --> Controller Class Initialized
DEBUG - 2022-02-24 05:34:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-02-24 05:34:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-02-24 05:34:50 --> Final output sent to browser
DEBUG - 2022-02-24 05:34:50 --> Total execution time: 1.0717
INFO - 2022-02-24 05:35:01 --> Config Class Initialized
INFO - 2022-02-24 05:35:01 --> Hooks Class Initialized
DEBUG - 2022-02-24 05:35:01 --> UTF-8 Support Enabled
INFO - 2022-02-24 05:35:01 --> Utf8 Class Initialized
INFO - 2022-02-24 05:35:01 --> URI Class Initialized
INFO - 2022-02-24 05:35:01 --> Router Class Initialized
INFO - 2022-02-24 05:35:01 --> Output Class Initialized
INFO - 2022-02-24 05:35:01 --> Security Class Initialized
DEBUG - 2022-02-24 05:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 05:35:01 --> Input Class Initialized
INFO - 2022-02-24 05:35:01 --> Language Class Initialized
INFO - 2022-02-24 05:35:01 --> Language Class Initialized
INFO - 2022-02-24 05:35:01 --> Config Class Initialized
INFO - 2022-02-24 05:35:01 --> Loader Class Initialized
INFO - 2022-02-24 05:35:01 --> Helper loaded: url_helper
INFO - 2022-02-24 05:35:01 --> Helper loaded: file_helper
INFO - 2022-02-24 05:35:01 --> Helper loaded: form_helper
INFO - 2022-02-24 05:35:01 --> Helper loaded: my_helper
INFO - 2022-02-24 05:35:01 --> Database Driver Class Initialized
DEBUG - 2022-02-24 05:35:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-24 05:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-24 05:35:01 --> Controller Class Initialized
DEBUG - 2022-02-24 05:35:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2022-02-24 05:35:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-02-24 05:35:01 --> Final output sent to browser
DEBUG - 2022-02-24 05:35:01 --> Total execution time: 0.0949
INFO - 2022-02-24 05:35:02 --> Config Class Initialized
INFO - 2022-02-24 05:35:02 --> Hooks Class Initialized
DEBUG - 2022-02-24 05:35:02 --> UTF-8 Support Enabled
INFO - 2022-02-24 05:35:02 --> Utf8 Class Initialized
INFO - 2022-02-24 05:35:02 --> URI Class Initialized
INFO - 2022-02-24 05:35:02 --> Router Class Initialized
INFO - 2022-02-24 05:35:02 --> Output Class Initialized
INFO - 2022-02-24 05:35:02 --> Security Class Initialized
DEBUG - 2022-02-24 05:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 05:35:02 --> Input Class Initialized
INFO - 2022-02-24 05:35:02 --> Language Class Initialized
INFO - 2022-02-24 05:35:02 --> Language Class Initialized
INFO - 2022-02-24 05:35:02 --> Config Class Initialized
INFO - 2022-02-24 05:35:02 --> Loader Class Initialized
INFO - 2022-02-24 05:35:02 --> Helper loaded: url_helper
INFO - 2022-02-24 05:35:02 --> Helper loaded: file_helper
INFO - 2022-02-24 05:35:02 --> Helper loaded: form_helper
INFO - 2022-02-24 05:35:02 --> Helper loaded: my_helper
INFO - 2022-02-24 05:35:02 --> Database Driver Class Initialized
DEBUG - 2022-02-24 05:35:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-24 05:35:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-24 05:35:02 --> Controller Class Initialized
INFO - 2022-02-24 05:35:05 --> Config Class Initialized
INFO - 2022-02-24 05:35:05 --> Hooks Class Initialized
DEBUG - 2022-02-24 05:35:05 --> UTF-8 Support Enabled
INFO - 2022-02-24 05:35:05 --> Utf8 Class Initialized
INFO - 2022-02-24 05:35:05 --> URI Class Initialized
INFO - 2022-02-24 05:35:05 --> Router Class Initialized
INFO - 2022-02-24 05:35:05 --> Output Class Initialized
INFO - 2022-02-24 05:35:05 --> Security Class Initialized
DEBUG - 2022-02-24 05:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 05:35:05 --> Input Class Initialized
INFO - 2022-02-24 05:35:05 --> Language Class Initialized
INFO - 2022-02-24 05:35:05 --> Language Class Initialized
INFO - 2022-02-24 05:35:05 --> Config Class Initialized
INFO - 2022-02-24 05:35:05 --> Loader Class Initialized
INFO - 2022-02-24 05:35:05 --> Helper loaded: url_helper
INFO - 2022-02-24 05:35:05 --> Helper loaded: file_helper
INFO - 2022-02-24 05:35:05 --> Helper loaded: form_helper
INFO - 2022-02-24 05:35:05 --> Helper loaded: my_helper
INFO - 2022-02-24 05:35:05 --> Database Driver Class Initialized
DEBUG - 2022-02-24 05:35:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-24 05:35:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-24 05:35:05 --> Controller Class Initialized
DEBUG - 2022-02-24 05:35:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2022-02-24 05:35:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-02-24 05:35:05 --> Final output sent to browser
DEBUG - 2022-02-24 05:35:05 --> Total execution time: 0.0945
INFO - 2022-02-24 05:35:19 --> Config Class Initialized
INFO - 2022-02-24 05:35:19 --> Hooks Class Initialized
DEBUG - 2022-02-24 05:35:19 --> UTF-8 Support Enabled
INFO - 2022-02-24 05:35:19 --> Utf8 Class Initialized
INFO - 2022-02-24 05:35:19 --> URI Class Initialized
INFO - 2022-02-24 05:35:19 --> Router Class Initialized
INFO - 2022-02-24 05:35:19 --> Output Class Initialized
INFO - 2022-02-24 05:35:19 --> Security Class Initialized
DEBUG - 2022-02-24 05:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 05:35:19 --> Input Class Initialized
INFO - 2022-02-24 05:35:19 --> Language Class Initialized
INFO - 2022-02-24 05:35:19 --> Language Class Initialized
INFO - 2022-02-24 05:35:19 --> Config Class Initialized
INFO - 2022-02-24 05:35:19 --> Loader Class Initialized
INFO - 2022-02-24 05:35:19 --> Helper loaded: url_helper
INFO - 2022-02-24 05:35:19 --> Helper loaded: file_helper
INFO - 2022-02-24 05:35:19 --> Helper loaded: form_helper
INFO - 2022-02-24 05:35:19 --> Helper loaded: my_helper
INFO - 2022-02-24 05:35:19 --> Database Driver Class Initialized
DEBUG - 2022-02-24 05:35:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-24 05:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-24 05:35:19 --> Controller Class Initialized
INFO - 2022-02-24 05:35:19 --> Helper loaded: cookie_helper
INFO - 2022-02-24 05:35:19 --> Config Class Initialized
INFO - 2022-02-24 05:35:19 --> Hooks Class Initialized
DEBUG - 2022-02-24 05:35:19 --> UTF-8 Support Enabled
INFO - 2022-02-24 05:35:19 --> Utf8 Class Initialized
INFO - 2022-02-24 05:35:19 --> URI Class Initialized
INFO - 2022-02-24 05:35:19 --> Router Class Initialized
INFO - 2022-02-24 05:35:19 --> Output Class Initialized
INFO - 2022-02-24 05:35:19 --> Security Class Initialized
DEBUG - 2022-02-24 05:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 05:35:19 --> Input Class Initialized
INFO - 2022-02-24 05:35:19 --> Language Class Initialized
INFO - 2022-02-24 05:35:19 --> Language Class Initialized
INFO - 2022-02-24 05:35:19 --> Config Class Initialized
INFO - 2022-02-24 05:35:19 --> Loader Class Initialized
INFO - 2022-02-24 05:35:19 --> Helper loaded: url_helper
INFO - 2022-02-24 05:35:19 --> Helper loaded: file_helper
INFO - 2022-02-24 05:35:19 --> Helper loaded: form_helper
INFO - 2022-02-24 05:35:19 --> Helper loaded: my_helper
INFO - 2022-02-24 05:35:19 --> Database Driver Class Initialized
DEBUG - 2022-02-24 05:35:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-24 05:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-24 05:35:19 --> Controller Class Initialized
DEBUG - 2022-02-24 05:35:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-02-24 05:35:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-02-24 05:35:19 --> Final output sent to browser
DEBUG - 2022-02-24 05:35:19 --> Total execution time: 0.0682
INFO - 2022-02-24 05:35:23 --> Config Class Initialized
INFO - 2022-02-24 05:35:23 --> Hooks Class Initialized
DEBUG - 2022-02-24 05:35:23 --> UTF-8 Support Enabled
INFO - 2022-02-24 05:35:23 --> Utf8 Class Initialized
INFO - 2022-02-24 05:35:23 --> URI Class Initialized
INFO - 2022-02-24 05:35:23 --> Router Class Initialized
INFO - 2022-02-24 05:35:23 --> Output Class Initialized
INFO - 2022-02-24 05:35:23 --> Security Class Initialized
DEBUG - 2022-02-24 05:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 05:35:23 --> Input Class Initialized
INFO - 2022-02-24 05:35:23 --> Language Class Initialized
INFO - 2022-02-24 05:35:23 --> Language Class Initialized
INFO - 2022-02-24 05:35:23 --> Config Class Initialized
INFO - 2022-02-24 05:35:23 --> Loader Class Initialized
INFO - 2022-02-24 05:35:23 --> Helper loaded: url_helper
INFO - 2022-02-24 05:35:23 --> Helper loaded: file_helper
INFO - 2022-02-24 05:35:23 --> Helper loaded: form_helper
INFO - 2022-02-24 05:35:23 --> Helper loaded: my_helper
INFO - 2022-02-24 05:35:23 --> Database Driver Class Initialized
DEBUG - 2022-02-24 05:35:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-24 05:35:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-24 05:35:23 --> Controller Class Initialized
INFO - 2022-02-24 05:35:23 --> Helper loaded: cookie_helper
INFO - 2022-02-24 05:35:23 --> Final output sent to browser
DEBUG - 2022-02-24 05:35:23 --> Total execution time: 0.0722
INFO - 2022-02-24 05:35:23 --> Config Class Initialized
INFO - 2022-02-24 05:35:23 --> Hooks Class Initialized
DEBUG - 2022-02-24 05:35:23 --> UTF-8 Support Enabled
INFO - 2022-02-24 05:35:23 --> Utf8 Class Initialized
INFO - 2022-02-24 05:35:23 --> URI Class Initialized
INFO - 2022-02-24 05:35:23 --> Router Class Initialized
INFO - 2022-02-24 05:35:23 --> Output Class Initialized
INFO - 2022-02-24 05:35:23 --> Security Class Initialized
DEBUG - 2022-02-24 05:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 05:35:23 --> Input Class Initialized
INFO - 2022-02-24 05:35:23 --> Language Class Initialized
INFO - 2022-02-24 05:35:23 --> Language Class Initialized
INFO - 2022-02-24 05:35:23 --> Config Class Initialized
INFO - 2022-02-24 05:35:23 --> Loader Class Initialized
INFO - 2022-02-24 05:35:23 --> Helper loaded: url_helper
INFO - 2022-02-24 05:35:23 --> Helper loaded: file_helper
INFO - 2022-02-24 05:35:23 --> Helper loaded: form_helper
INFO - 2022-02-24 05:35:23 --> Helper loaded: my_helper
INFO - 2022-02-24 05:35:23 --> Database Driver Class Initialized
DEBUG - 2022-02-24 05:35:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-24 05:35:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-24 05:35:23 --> Controller Class Initialized
DEBUG - 2022-02-24 05:35:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-02-24 05:35:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-02-24 05:35:24 --> Final output sent to browser
DEBUG - 2022-02-24 05:35:24 --> Total execution time: 0.9271
INFO - 2022-02-24 05:35:26 --> Config Class Initialized
INFO - 2022-02-24 05:35:26 --> Hooks Class Initialized
DEBUG - 2022-02-24 05:35:26 --> UTF-8 Support Enabled
INFO - 2022-02-24 05:35:26 --> Utf8 Class Initialized
INFO - 2022-02-24 05:35:26 --> URI Class Initialized
INFO - 2022-02-24 05:35:26 --> Router Class Initialized
INFO - 2022-02-24 05:35:26 --> Output Class Initialized
INFO - 2022-02-24 05:35:26 --> Security Class Initialized
DEBUG - 2022-02-24 05:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 05:35:26 --> Input Class Initialized
INFO - 2022-02-24 05:35:26 --> Language Class Initialized
INFO - 2022-02-24 05:35:26 --> Language Class Initialized
INFO - 2022-02-24 05:35:26 --> Config Class Initialized
INFO - 2022-02-24 05:35:26 --> Loader Class Initialized
INFO - 2022-02-24 05:35:26 --> Helper loaded: url_helper
INFO - 2022-02-24 05:35:26 --> Helper loaded: file_helper
INFO - 2022-02-24 05:35:26 --> Helper loaded: form_helper
INFO - 2022-02-24 05:35:26 --> Helper loaded: my_helper
INFO - 2022-02-24 05:35:26 --> Database Driver Class Initialized
DEBUG - 2022-02-24 05:35:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-24 05:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-24 05:35:26 --> Controller Class Initialized
DEBUG - 2022-02-24 05:35:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2022-02-24 05:35:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-02-24 05:35:26 --> Final output sent to browser
DEBUG - 2022-02-24 05:35:26 --> Total execution time: 0.1350
INFO - 2022-02-24 05:35:28 --> Config Class Initialized
INFO - 2022-02-24 05:35:28 --> Hooks Class Initialized
DEBUG - 2022-02-24 05:35:28 --> UTF-8 Support Enabled
INFO - 2022-02-24 05:35:28 --> Utf8 Class Initialized
INFO - 2022-02-24 05:35:28 --> URI Class Initialized
INFO - 2022-02-24 05:35:28 --> Router Class Initialized
INFO - 2022-02-24 05:35:28 --> Output Class Initialized
INFO - 2022-02-24 05:35:28 --> Security Class Initialized
DEBUG - 2022-02-24 05:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 05:35:28 --> Input Class Initialized
INFO - 2022-02-24 05:35:28 --> Language Class Initialized
INFO - 2022-02-24 05:35:28 --> Language Class Initialized
INFO - 2022-02-24 05:35:28 --> Config Class Initialized
INFO - 2022-02-24 05:35:28 --> Loader Class Initialized
INFO - 2022-02-24 05:35:28 --> Helper loaded: url_helper
INFO - 2022-02-24 05:35:28 --> Helper loaded: file_helper
INFO - 2022-02-24 05:35:28 --> Helper loaded: form_helper
INFO - 2022-02-24 05:35:28 --> Helper loaded: my_helper
INFO - 2022-02-24 05:35:28 --> Database Driver Class Initialized
DEBUG - 2022-02-24 05:35:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-24 05:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-24 05:35:28 --> Controller Class Initialized
DEBUG - 2022-02-24 05:35:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2022-02-24 05:35:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-02-24 05:35:28 --> Final output sent to browser
DEBUG - 2022-02-24 05:35:28 --> Total execution time: 0.0956
INFO - 2022-02-24 05:35:31 --> Config Class Initialized
INFO - 2022-02-24 05:35:31 --> Hooks Class Initialized
DEBUG - 2022-02-24 05:35:31 --> UTF-8 Support Enabled
INFO - 2022-02-24 05:35:31 --> Utf8 Class Initialized
INFO - 2022-02-24 05:35:31 --> URI Class Initialized
INFO - 2022-02-24 05:35:31 --> Router Class Initialized
INFO - 2022-02-24 05:35:31 --> Output Class Initialized
INFO - 2022-02-24 05:35:31 --> Security Class Initialized
DEBUG - 2022-02-24 05:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 05:35:31 --> Input Class Initialized
INFO - 2022-02-24 05:35:31 --> Language Class Initialized
INFO - 2022-02-24 05:35:31 --> Language Class Initialized
INFO - 2022-02-24 05:35:31 --> Config Class Initialized
INFO - 2022-02-24 05:35:31 --> Loader Class Initialized
INFO - 2022-02-24 05:35:31 --> Helper loaded: url_helper
INFO - 2022-02-24 05:35:31 --> Helper loaded: file_helper
INFO - 2022-02-24 05:35:31 --> Helper loaded: form_helper
INFO - 2022-02-24 05:35:31 --> Helper loaded: my_helper
INFO - 2022-02-24 05:35:31 --> Database Driver Class Initialized
DEBUG - 2022-02-24 05:35:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-24 05:35:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-24 05:35:31 --> Controller Class Initialized
DEBUG - 2022-02-24 05:35:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2022-02-24 05:35:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-02-24 05:35:31 --> Final output sent to browser
DEBUG - 2022-02-24 05:35:31 --> Total execution time: 0.1056
INFO - 2022-02-24 05:35:33 --> Config Class Initialized
INFO - 2022-02-24 05:35:33 --> Hooks Class Initialized
DEBUG - 2022-02-24 05:35:33 --> UTF-8 Support Enabled
INFO - 2022-02-24 05:35:33 --> Utf8 Class Initialized
INFO - 2022-02-24 05:35:33 --> URI Class Initialized
INFO - 2022-02-24 05:35:33 --> Router Class Initialized
INFO - 2022-02-24 05:35:33 --> Output Class Initialized
INFO - 2022-02-24 05:35:33 --> Security Class Initialized
DEBUG - 2022-02-24 05:35:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 05:35:33 --> Input Class Initialized
INFO - 2022-02-24 05:35:33 --> Language Class Initialized
INFO - 2022-02-24 05:35:33 --> Language Class Initialized
INFO - 2022-02-24 05:35:33 --> Config Class Initialized
INFO - 2022-02-24 05:35:33 --> Loader Class Initialized
INFO - 2022-02-24 05:35:33 --> Helper loaded: url_helper
INFO - 2022-02-24 05:35:33 --> Helper loaded: file_helper
INFO - 2022-02-24 05:35:33 --> Helper loaded: form_helper
INFO - 2022-02-24 05:35:33 --> Helper loaded: my_helper
INFO - 2022-02-24 05:35:33 --> Database Driver Class Initialized
DEBUG - 2022-02-24 05:35:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-24 05:35:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-24 05:35:33 --> Controller Class Initialized
DEBUG - 2022-02-24 05:35:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2022-02-24 05:35:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-02-24 05:35:33 --> Final output sent to browser
DEBUG - 2022-02-24 05:35:33 --> Total execution time: 0.1612
INFO - 2022-02-24 05:35:35 --> Config Class Initialized
INFO - 2022-02-24 05:35:35 --> Hooks Class Initialized
DEBUG - 2022-02-24 05:35:35 --> UTF-8 Support Enabled
INFO - 2022-02-24 05:35:35 --> Utf8 Class Initialized
INFO - 2022-02-24 05:35:35 --> URI Class Initialized
INFO - 2022-02-24 05:35:35 --> Router Class Initialized
INFO - 2022-02-24 05:35:35 --> Output Class Initialized
INFO - 2022-02-24 05:35:35 --> Security Class Initialized
DEBUG - 2022-02-24 05:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 05:35:35 --> Input Class Initialized
INFO - 2022-02-24 05:35:35 --> Language Class Initialized
INFO - 2022-02-24 05:35:35 --> Language Class Initialized
INFO - 2022-02-24 05:35:35 --> Config Class Initialized
INFO - 2022-02-24 05:35:35 --> Loader Class Initialized
INFO - 2022-02-24 05:35:35 --> Helper loaded: url_helper
INFO - 2022-02-24 05:35:35 --> Helper loaded: file_helper
INFO - 2022-02-24 05:35:35 --> Helper loaded: form_helper
INFO - 2022-02-24 05:35:35 --> Helper loaded: my_helper
INFO - 2022-02-24 05:35:35 --> Database Driver Class Initialized
DEBUG - 2022-02-24 05:35:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-24 05:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-24 05:35:35 --> Controller Class Initialized
DEBUG - 2022-02-24 05:35:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2022-02-24 05:35:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-02-24 05:35:35 --> Final output sent to browser
DEBUG - 2022-02-24 05:35:35 --> Total execution time: 0.0929
INFO - 2022-02-24 05:35:36 --> Config Class Initialized
INFO - 2022-02-24 05:35:36 --> Hooks Class Initialized
DEBUG - 2022-02-24 05:35:36 --> UTF-8 Support Enabled
INFO - 2022-02-24 05:35:36 --> Utf8 Class Initialized
INFO - 2022-02-24 05:35:36 --> URI Class Initialized
INFO - 2022-02-24 05:35:36 --> Router Class Initialized
INFO - 2022-02-24 05:35:36 --> Output Class Initialized
INFO - 2022-02-24 05:35:36 --> Security Class Initialized
DEBUG - 2022-02-24 05:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 05:35:36 --> Input Class Initialized
INFO - 2022-02-24 05:35:36 --> Language Class Initialized
INFO - 2022-02-24 05:35:36 --> Language Class Initialized
INFO - 2022-02-24 05:35:36 --> Config Class Initialized
INFO - 2022-02-24 05:35:36 --> Loader Class Initialized
INFO - 2022-02-24 05:35:36 --> Helper loaded: url_helper
INFO - 2022-02-24 05:35:36 --> Helper loaded: file_helper
INFO - 2022-02-24 05:35:36 --> Helper loaded: form_helper
INFO - 2022-02-24 05:35:36 --> Helper loaded: my_helper
INFO - 2022-02-24 05:35:36 --> Database Driver Class Initialized
DEBUG - 2022-02-24 05:35:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-24 05:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-24 05:35:36 --> Controller Class Initialized
DEBUG - 2022-02-24 05:35:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2022-02-24 05:35:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-02-24 05:35:36 --> Final output sent to browser
DEBUG - 2022-02-24 05:35:36 --> Total execution time: 0.0834
INFO - 2022-02-24 05:35:40 --> Config Class Initialized
INFO - 2022-02-24 05:35:40 --> Hooks Class Initialized
DEBUG - 2022-02-24 05:35:40 --> UTF-8 Support Enabled
INFO - 2022-02-24 05:35:40 --> Utf8 Class Initialized
INFO - 2022-02-24 05:35:40 --> URI Class Initialized
INFO - 2022-02-24 05:35:40 --> Router Class Initialized
INFO - 2022-02-24 05:35:40 --> Output Class Initialized
INFO - 2022-02-24 05:35:40 --> Security Class Initialized
DEBUG - 2022-02-24 05:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 05:35:40 --> Input Class Initialized
INFO - 2022-02-24 05:35:40 --> Language Class Initialized
INFO - 2022-02-24 05:35:40 --> Language Class Initialized
INFO - 2022-02-24 05:35:40 --> Config Class Initialized
INFO - 2022-02-24 05:35:40 --> Loader Class Initialized
INFO - 2022-02-24 05:35:40 --> Helper loaded: url_helper
INFO - 2022-02-24 05:35:40 --> Helper loaded: file_helper
INFO - 2022-02-24 05:35:40 --> Helper loaded: form_helper
INFO - 2022-02-24 05:35:40 --> Helper loaded: my_helper
INFO - 2022-02-24 05:35:40 --> Database Driver Class Initialized
DEBUG - 2022-02-24 05:35:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-24 05:35:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-24 05:35:40 --> Controller Class Initialized
DEBUG - 2022-02-24 05:35:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2022-02-24 05:35:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-02-24 05:35:40 --> Final output sent to browser
DEBUG - 2022-02-24 05:35:40 --> Total execution time: 0.0730
INFO - 2022-02-24 05:35:40 --> Config Class Initialized
INFO - 2022-02-24 05:35:40 --> Hooks Class Initialized
DEBUG - 2022-02-24 05:35:40 --> UTF-8 Support Enabled
INFO - 2022-02-24 05:35:40 --> Utf8 Class Initialized
INFO - 2022-02-24 05:35:40 --> URI Class Initialized
INFO - 2022-02-24 05:35:40 --> Router Class Initialized
INFO - 2022-02-24 05:35:40 --> Output Class Initialized
INFO - 2022-02-24 05:35:40 --> Security Class Initialized
DEBUG - 2022-02-24 05:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 05:35:40 --> Input Class Initialized
INFO - 2022-02-24 05:35:40 --> Language Class Initialized
INFO - 2022-02-24 05:35:40 --> Language Class Initialized
INFO - 2022-02-24 05:35:40 --> Config Class Initialized
INFO - 2022-02-24 05:35:40 --> Loader Class Initialized
INFO - 2022-02-24 05:35:40 --> Helper loaded: url_helper
INFO - 2022-02-24 05:35:40 --> Helper loaded: file_helper
INFO - 2022-02-24 05:35:40 --> Helper loaded: form_helper
INFO - 2022-02-24 05:35:40 --> Helper loaded: my_helper
INFO - 2022-02-24 05:35:40 --> Database Driver Class Initialized
DEBUG - 2022-02-24 05:35:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-24 05:35:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-24 05:35:40 --> Controller Class Initialized
DEBUG - 2022-02-24 05:35:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2022-02-24 05:35:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-02-24 05:35:40 --> Final output sent to browser
DEBUG - 2022-02-24 05:35:40 --> Total execution time: 0.0742
