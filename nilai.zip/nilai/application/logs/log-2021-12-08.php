<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-12-08 03:09:14 --> Config Class Initialized
INFO - 2021-12-08 03:09:14 --> Hooks Class Initialized
DEBUG - 2021-12-08 03:09:14 --> UTF-8 Support Enabled
INFO - 2021-12-08 03:09:14 --> Utf8 Class Initialized
INFO - 2021-12-08 03:09:14 --> URI Class Initialized
DEBUG - 2021-12-08 03:09:14 --> No URI present. Default controller set.
INFO - 2021-12-08 03:09:14 --> Router Class Initialized
INFO - 2021-12-08 03:09:14 --> Output Class Initialized
INFO - 2021-12-08 03:09:14 --> Security Class Initialized
DEBUG - 2021-12-08 03:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 03:09:14 --> Input Class Initialized
INFO - 2021-12-08 03:09:14 --> Language Class Initialized
INFO - 2021-12-08 03:09:14 --> Language Class Initialized
INFO - 2021-12-08 03:09:14 --> Config Class Initialized
INFO - 2021-12-08 03:09:14 --> Loader Class Initialized
INFO - 2021-12-08 03:09:14 --> Helper loaded: url_helper
INFO - 2021-12-08 03:09:14 --> Helper loaded: file_helper
INFO - 2021-12-08 03:09:14 --> Helper loaded: form_helper
INFO - 2021-12-08 03:09:14 --> Helper loaded: my_helper
INFO - 2021-12-08 03:09:14 --> Database Driver Class Initialized
DEBUG - 2021-12-08 03:09:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 03:09:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 03:09:14 --> Controller Class Initialized
INFO - 2021-12-08 03:09:14 --> Config Class Initialized
INFO - 2021-12-08 03:09:14 --> Hooks Class Initialized
DEBUG - 2021-12-08 03:09:14 --> UTF-8 Support Enabled
INFO - 2021-12-08 03:09:14 --> Utf8 Class Initialized
INFO - 2021-12-08 03:09:14 --> URI Class Initialized
INFO - 2021-12-08 03:09:14 --> Router Class Initialized
INFO - 2021-12-08 03:09:14 --> Output Class Initialized
INFO - 2021-12-08 03:09:14 --> Security Class Initialized
DEBUG - 2021-12-08 03:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 03:09:14 --> Input Class Initialized
INFO - 2021-12-08 03:09:14 --> Language Class Initialized
INFO - 2021-12-08 03:09:14 --> Language Class Initialized
INFO - 2021-12-08 03:09:14 --> Config Class Initialized
INFO - 2021-12-08 03:09:14 --> Loader Class Initialized
INFO - 2021-12-08 03:09:14 --> Helper loaded: url_helper
INFO - 2021-12-08 03:09:14 --> Helper loaded: file_helper
INFO - 2021-12-08 03:09:14 --> Helper loaded: form_helper
INFO - 2021-12-08 03:09:14 --> Helper loaded: my_helper
INFO - 2021-12-08 03:09:14 --> Database Driver Class Initialized
DEBUG - 2021-12-08 03:09:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 03:09:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 03:09:14 --> Controller Class Initialized
DEBUG - 2021-12-08 03:09:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-08 03:09:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 03:09:14 --> Final output sent to browser
DEBUG - 2021-12-08 03:09:14 --> Total execution time: 0.0370
INFO - 2021-12-08 03:09:21 --> Config Class Initialized
INFO - 2021-12-08 03:09:21 --> Hooks Class Initialized
DEBUG - 2021-12-08 03:09:21 --> UTF-8 Support Enabled
INFO - 2021-12-08 03:09:21 --> Utf8 Class Initialized
INFO - 2021-12-08 03:09:21 --> URI Class Initialized
INFO - 2021-12-08 03:09:21 --> Router Class Initialized
INFO - 2021-12-08 03:09:21 --> Output Class Initialized
INFO - 2021-12-08 03:09:21 --> Security Class Initialized
DEBUG - 2021-12-08 03:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 03:09:21 --> Input Class Initialized
INFO - 2021-12-08 03:09:21 --> Language Class Initialized
INFO - 2021-12-08 03:09:21 --> Language Class Initialized
INFO - 2021-12-08 03:09:21 --> Config Class Initialized
INFO - 2021-12-08 03:09:21 --> Loader Class Initialized
INFO - 2021-12-08 03:09:21 --> Helper loaded: url_helper
INFO - 2021-12-08 03:09:21 --> Helper loaded: file_helper
INFO - 2021-12-08 03:09:21 --> Helper loaded: form_helper
INFO - 2021-12-08 03:09:21 --> Helper loaded: my_helper
INFO - 2021-12-08 03:09:21 --> Database Driver Class Initialized
DEBUG - 2021-12-08 03:09:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 03:09:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 03:09:21 --> Controller Class Initialized
INFO - 2021-12-08 03:09:21 --> Helper loaded: cookie_helper
INFO - 2021-12-08 03:09:21 --> Final output sent to browser
DEBUG - 2021-12-08 03:09:21 --> Total execution time: 0.0530
INFO - 2021-12-08 03:09:21 --> Config Class Initialized
INFO - 2021-12-08 03:09:21 --> Hooks Class Initialized
DEBUG - 2021-12-08 03:09:21 --> UTF-8 Support Enabled
INFO - 2021-12-08 03:09:21 --> Utf8 Class Initialized
INFO - 2021-12-08 03:09:21 --> URI Class Initialized
INFO - 2021-12-08 03:09:21 --> Router Class Initialized
INFO - 2021-12-08 03:09:21 --> Output Class Initialized
INFO - 2021-12-08 03:09:21 --> Security Class Initialized
DEBUG - 2021-12-08 03:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 03:09:21 --> Input Class Initialized
INFO - 2021-12-08 03:09:21 --> Language Class Initialized
INFO - 2021-12-08 03:09:21 --> Language Class Initialized
INFO - 2021-12-08 03:09:21 --> Config Class Initialized
INFO - 2021-12-08 03:09:21 --> Loader Class Initialized
INFO - 2021-12-08 03:09:21 --> Helper loaded: url_helper
INFO - 2021-12-08 03:09:21 --> Helper loaded: file_helper
INFO - 2021-12-08 03:09:21 --> Helper loaded: form_helper
INFO - 2021-12-08 03:09:21 --> Helper loaded: my_helper
INFO - 2021-12-08 03:09:21 --> Database Driver Class Initialized
DEBUG - 2021-12-08 03:09:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 03:09:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 03:09:21 --> Controller Class Initialized
DEBUG - 2021-12-08 03:09:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-08 03:09:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 03:09:22 --> Final output sent to browser
DEBUG - 2021-12-08 03:09:22 --> Total execution time: 0.2700
INFO - 2021-12-08 03:09:24 --> Config Class Initialized
INFO - 2021-12-08 03:09:24 --> Hooks Class Initialized
DEBUG - 2021-12-08 03:09:24 --> UTF-8 Support Enabled
INFO - 2021-12-08 03:09:24 --> Utf8 Class Initialized
INFO - 2021-12-08 03:09:24 --> URI Class Initialized
INFO - 2021-12-08 03:09:24 --> Router Class Initialized
INFO - 2021-12-08 03:09:24 --> Output Class Initialized
INFO - 2021-12-08 03:09:24 --> Security Class Initialized
DEBUG - 2021-12-08 03:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 03:09:24 --> Input Class Initialized
INFO - 2021-12-08 03:09:24 --> Language Class Initialized
INFO - 2021-12-08 03:09:24 --> Language Class Initialized
INFO - 2021-12-08 03:09:24 --> Config Class Initialized
INFO - 2021-12-08 03:09:24 --> Loader Class Initialized
INFO - 2021-12-08 03:09:24 --> Helper loaded: url_helper
INFO - 2021-12-08 03:09:24 --> Helper loaded: file_helper
INFO - 2021-12-08 03:09:24 --> Helper loaded: form_helper
INFO - 2021-12-08 03:09:24 --> Helper loaded: my_helper
INFO - 2021-12-08 03:09:24 --> Database Driver Class Initialized
DEBUG - 2021-12-08 03:09:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 03:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 03:09:24 --> Controller Class Initialized
DEBUG - 2021-12-08 03:09:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-12-08 03:09:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 03:09:24 --> Final output sent to browser
DEBUG - 2021-12-08 03:09:24 --> Total execution time: 0.0580
INFO - 2021-12-08 03:09:24 --> Config Class Initialized
INFO - 2021-12-08 03:09:24 --> Hooks Class Initialized
DEBUG - 2021-12-08 03:09:24 --> UTF-8 Support Enabled
INFO - 2021-12-08 03:09:24 --> Utf8 Class Initialized
INFO - 2021-12-08 03:09:24 --> URI Class Initialized
INFO - 2021-12-08 03:09:24 --> Router Class Initialized
INFO - 2021-12-08 03:09:24 --> Output Class Initialized
INFO - 2021-12-08 03:09:24 --> Security Class Initialized
DEBUG - 2021-12-08 03:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 03:09:24 --> Input Class Initialized
INFO - 2021-12-08 03:09:24 --> Language Class Initialized
INFO - 2021-12-08 03:09:24 --> Language Class Initialized
INFO - 2021-12-08 03:09:24 --> Config Class Initialized
INFO - 2021-12-08 03:09:24 --> Loader Class Initialized
INFO - 2021-12-08 03:09:24 --> Helper loaded: url_helper
INFO - 2021-12-08 03:09:24 --> Helper loaded: file_helper
INFO - 2021-12-08 03:09:24 --> Helper loaded: form_helper
INFO - 2021-12-08 03:09:24 --> Helper loaded: my_helper
INFO - 2021-12-08 03:09:24 --> Database Driver Class Initialized
DEBUG - 2021-12-08 03:09:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 03:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 03:09:24 --> Controller Class Initialized
INFO - 2021-12-08 03:09:27 --> Config Class Initialized
INFO - 2021-12-08 03:09:27 --> Hooks Class Initialized
DEBUG - 2021-12-08 03:09:27 --> UTF-8 Support Enabled
INFO - 2021-12-08 03:09:27 --> Utf8 Class Initialized
INFO - 2021-12-08 03:09:27 --> URI Class Initialized
INFO - 2021-12-08 03:09:27 --> Router Class Initialized
INFO - 2021-12-08 03:09:27 --> Output Class Initialized
INFO - 2021-12-08 03:09:27 --> Security Class Initialized
DEBUG - 2021-12-08 03:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 03:09:27 --> Input Class Initialized
INFO - 2021-12-08 03:09:27 --> Language Class Initialized
INFO - 2021-12-08 03:09:27 --> Language Class Initialized
INFO - 2021-12-08 03:09:27 --> Config Class Initialized
INFO - 2021-12-08 03:09:27 --> Loader Class Initialized
INFO - 2021-12-08 03:09:27 --> Helper loaded: url_helper
INFO - 2021-12-08 03:09:27 --> Helper loaded: file_helper
INFO - 2021-12-08 03:09:27 --> Helper loaded: form_helper
INFO - 2021-12-08 03:09:27 --> Helper loaded: my_helper
INFO - 2021-12-08 03:09:27 --> Database Driver Class Initialized
DEBUG - 2021-12-08 03:09:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 03:09:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 03:09:27 --> Controller Class Initialized
INFO - 2021-12-08 03:09:27 --> Final output sent to browser
DEBUG - 2021-12-08 03:09:27 --> Total execution time: 0.0650
INFO - 2021-12-08 03:09:27 --> Config Class Initialized
INFO - 2021-12-08 03:09:27 --> Hooks Class Initialized
DEBUG - 2021-12-08 03:09:27 --> UTF-8 Support Enabled
INFO - 2021-12-08 03:09:27 --> Utf8 Class Initialized
INFO - 2021-12-08 03:09:27 --> URI Class Initialized
INFO - 2021-12-08 03:09:27 --> Router Class Initialized
INFO - 2021-12-08 03:09:27 --> Output Class Initialized
INFO - 2021-12-08 03:09:27 --> Security Class Initialized
DEBUG - 2021-12-08 03:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 03:09:27 --> Input Class Initialized
INFO - 2021-12-08 03:09:27 --> Language Class Initialized
INFO - 2021-12-08 03:09:27 --> Language Class Initialized
INFO - 2021-12-08 03:09:27 --> Config Class Initialized
INFO - 2021-12-08 03:09:27 --> Loader Class Initialized
INFO - 2021-12-08 03:09:27 --> Helper loaded: url_helper
INFO - 2021-12-08 03:09:27 --> Helper loaded: file_helper
INFO - 2021-12-08 03:09:27 --> Helper loaded: form_helper
INFO - 2021-12-08 03:09:27 --> Helper loaded: my_helper
INFO - 2021-12-08 03:09:27 --> Database Driver Class Initialized
DEBUG - 2021-12-08 03:09:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 03:09:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 03:09:27 --> Controller Class Initialized
INFO - 2021-12-08 03:09:29 --> Config Class Initialized
INFO - 2021-12-08 03:09:29 --> Hooks Class Initialized
DEBUG - 2021-12-08 03:09:29 --> UTF-8 Support Enabled
INFO - 2021-12-08 03:09:29 --> Utf8 Class Initialized
INFO - 2021-12-08 03:09:29 --> URI Class Initialized
INFO - 2021-12-08 03:09:29 --> Router Class Initialized
INFO - 2021-12-08 03:09:29 --> Output Class Initialized
INFO - 2021-12-08 03:09:29 --> Security Class Initialized
DEBUG - 2021-12-08 03:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 03:09:29 --> Input Class Initialized
INFO - 2021-12-08 03:09:29 --> Language Class Initialized
INFO - 2021-12-08 03:09:29 --> Language Class Initialized
INFO - 2021-12-08 03:09:29 --> Config Class Initialized
INFO - 2021-12-08 03:09:29 --> Loader Class Initialized
INFO - 2021-12-08 03:09:29 --> Helper loaded: url_helper
INFO - 2021-12-08 03:09:29 --> Helper loaded: file_helper
INFO - 2021-12-08 03:09:29 --> Helper loaded: form_helper
INFO - 2021-12-08 03:09:29 --> Helper loaded: my_helper
INFO - 2021-12-08 03:09:29 --> Database Driver Class Initialized
DEBUG - 2021-12-08 03:09:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 03:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 03:09:29 --> Controller Class Initialized
INFO - 2021-12-08 03:09:29 --> Helper loaded: cookie_helper
INFO - 2021-12-08 03:09:29 --> Config Class Initialized
INFO - 2021-12-08 03:09:29 --> Hooks Class Initialized
DEBUG - 2021-12-08 03:09:29 --> UTF-8 Support Enabled
INFO - 2021-12-08 03:09:29 --> Utf8 Class Initialized
INFO - 2021-12-08 03:09:29 --> URI Class Initialized
INFO - 2021-12-08 03:09:29 --> Router Class Initialized
INFO - 2021-12-08 03:09:29 --> Output Class Initialized
INFO - 2021-12-08 03:09:29 --> Security Class Initialized
DEBUG - 2021-12-08 03:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 03:09:29 --> Input Class Initialized
INFO - 2021-12-08 03:09:29 --> Language Class Initialized
INFO - 2021-12-08 03:09:29 --> Language Class Initialized
INFO - 2021-12-08 03:09:29 --> Config Class Initialized
INFO - 2021-12-08 03:09:29 --> Loader Class Initialized
INFO - 2021-12-08 03:09:29 --> Helper loaded: url_helper
INFO - 2021-12-08 03:09:29 --> Helper loaded: file_helper
INFO - 2021-12-08 03:09:29 --> Helper loaded: form_helper
INFO - 2021-12-08 03:09:29 --> Helper loaded: my_helper
INFO - 2021-12-08 03:09:29 --> Database Driver Class Initialized
DEBUG - 2021-12-08 03:09:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 03:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 03:09:29 --> Controller Class Initialized
DEBUG - 2021-12-08 03:09:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-08 03:09:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 03:09:29 --> Final output sent to browser
DEBUG - 2021-12-08 03:09:29 --> Total execution time: 0.0410
INFO - 2021-12-08 03:09:33 --> Config Class Initialized
INFO - 2021-12-08 03:09:33 --> Hooks Class Initialized
DEBUG - 2021-12-08 03:09:33 --> UTF-8 Support Enabled
INFO - 2021-12-08 03:09:33 --> Utf8 Class Initialized
INFO - 2021-12-08 03:09:33 --> URI Class Initialized
INFO - 2021-12-08 03:09:33 --> Router Class Initialized
INFO - 2021-12-08 03:09:33 --> Output Class Initialized
INFO - 2021-12-08 03:09:33 --> Security Class Initialized
DEBUG - 2021-12-08 03:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 03:09:33 --> Input Class Initialized
INFO - 2021-12-08 03:09:33 --> Language Class Initialized
INFO - 2021-12-08 03:09:33 --> Language Class Initialized
INFO - 2021-12-08 03:09:33 --> Config Class Initialized
INFO - 2021-12-08 03:09:33 --> Loader Class Initialized
INFO - 2021-12-08 03:09:33 --> Helper loaded: url_helper
INFO - 2021-12-08 03:09:33 --> Helper loaded: file_helper
INFO - 2021-12-08 03:09:33 --> Helper loaded: form_helper
INFO - 2021-12-08 03:09:33 --> Helper loaded: my_helper
INFO - 2021-12-08 03:09:33 --> Database Driver Class Initialized
DEBUG - 2021-12-08 03:09:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 03:09:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 03:09:33 --> Controller Class Initialized
INFO - 2021-12-08 03:09:33 --> Helper loaded: cookie_helper
INFO - 2021-12-08 03:09:33 --> Final output sent to browser
DEBUG - 2021-12-08 03:09:33 --> Total execution time: 0.0590
INFO - 2021-12-08 03:09:33 --> Config Class Initialized
INFO - 2021-12-08 03:09:33 --> Hooks Class Initialized
DEBUG - 2021-12-08 03:09:33 --> UTF-8 Support Enabled
INFO - 2021-12-08 03:09:33 --> Utf8 Class Initialized
INFO - 2021-12-08 03:09:33 --> URI Class Initialized
INFO - 2021-12-08 03:09:33 --> Router Class Initialized
INFO - 2021-12-08 03:09:33 --> Output Class Initialized
INFO - 2021-12-08 03:09:33 --> Security Class Initialized
DEBUG - 2021-12-08 03:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 03:09:33 --> Input Class Initialized
INFO - 2021-12-08 03:09:33 --> Language Class Initialized
INFO - 2021-12-08 03:09:33 --> Language Class Initialized
INFO - 2021-12-08 03:09:33 --> Config Class Initialized
INFO - 2021-12-08 03:09:33 --> Loader Class Initialized
INFO - 2021-12-08 03:09:33 --> Helper loaded: url_helper
INFO - 2021-12-08 03:09:33 --> Helper loaded: file_helper
INFO - 2021-12-08 03:09:33 --> Helper loaded: form_helper
INFO - 2021-12-08 03:09:33 --> Helper loaded: my_helper
INFO - 2021-12-08 03:09:33 --> Database Driver Class Initialized
DEBUG - 2021-12-08 03:09:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 03:09:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 03:09:33 --> Controller Class Initialized
DEBUG - 2021-12-08 03:09:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-08 03:09:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 03:09:34 --> Final output sent to browser
DEBUG - 2021-12-08 03:09:34 --> Total execution time: 0.6450
INFO - 2021-12-08 03:09:36 --> Config Class Initialized
INFO - 2021-12-08 03:09:36 --> Hooks Class Initialized
DEBUG - 2021-12-08 03:09:36 --> UTF-8 Support Enabled
INFO - 2021-12-08 03:09:36 --> Utf8 Class Initialized
INFO - 2021-12-08 03:09:36 --> URI Class Initialized
INFO - 2021-12-08 03:09:36 --> Router Class Initialized
INFO - 2021-12-08 03:09:36 --> Output Class Initialized
INFO - 2021-12-08 03:09:36 --> Security Class Initialized
DEBUG - 2021-12-08 03:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 03:09:36 --> Input Class Initialized
INFO - 2021-12-08 03:09:36 --> Language Class Initialized
INFO - 2021-12-08 03:09:36 --> Language Class Initialized
INFO - 2021-12-08 03:09:36 --> Config Class Initialized
INFO - 2021-12-08 03:09:36 --> Loader Class Initialized
INFO - 2021-12-08 03:09:36 --> Helper loaded: url_helper
INFO - 2021-12-08 03:09:36 --> Helper loaded: file_helper
INFO - 2021-12-08 03:09:36 --> Helper loaded: form_helper
INFO - 2021-12-08 03:09:36 --> Helper loaded: my_helper
INFO - 2021-12-08 03:09:36 --> Database Driver Class Initialized
DEBUG - 2021-12-08 03:09:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 03:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 03:09:36 --> Controller Class Initialized
DEBUG - 2021-12-08 03:09:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-08 03:09:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 03:09:36 --> Final output sent to browser
DEBUG - 2021-12-08 03:09:36 --> Total execution time: 0.0520
INFO - 2021-12-08 03:09:38 --> Config Class Initialized
INFO - 2021-12-08 03:09:38 --> Hooks Class Initialized
DEBUG - 2021-12-08 03:09:38 --> UTF-8 Support Enabled
INFO - 2021-12-08 03:09:38 --> Utf8 Class Initialized
INFO - 2021-12-08 03:09:38 --> URI Class Initialized
INFO - 2021-12-08 03:09:38 --> Router Class Initialized
INFO - 2021-12-08 03:09:38 --> Output Class Initialized
INFO - 2021-12-08 03:09:38 --> Security Class Initialized
DEBUG - 2021-12-08 03:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 03:09:38 --> Input Class Initialized
INFO - 2021-12-08 03:09:38 --> Language Class Initialized
INFO - 2021-12-08 03:09:38 --> Language Class Initialized
INFO - 2021-12-08 03:09:38 --> Config Class Initialized
INFO - 2021-12-08 03:09:38 --> Loader Class Initialized
INFO - 2021-12-08 03:09:38 --> Helper loaded: url_helper
INFO - 2021-12-08 03:09:38 --> Helper loaded: file_helper
INFO - 2021-12-08 03:09:38 --> Helper loaded: form_helper
INFO - 2021-12-08 03:09:38 --> Helper loaded: my_helper
INFO - 2021-12-08 03:09:38 --> Database Driver Class Initialized
DEBUG - 2021-12-08 03:09:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 03:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 03:09:38 --> Controller Class Initialized
DEBUG - 2021-12-08 03:09:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-08 03:09:38 --> Final output sent to browser
DEBUG - 2021-12-08 03:09:38 --> Total execution time: 0.1900
INFO - 2021-12-08 03:32:00 --> Config Class Initialized
INFO - 2021-12-08 03:32:00 --> Hooks Class Initialized
DEBUG - 2021-12-08 03:32:00 --> UTF-8 Support Enabled
INFO - 2021-12-08 03:32:00 --> Utf8 Class Initialized
INFO - 2021-12-08 03:32:00 --> URI Class Initialized
INFO - 2021-12-08 03:32:00 --> Router Class Initialized
INFO - 2021-12-08 03:32:00 --> Output Class Initialized
INFO - 2021-12-08 03:32:00 --> Security Class Initialized
DEBUG - 2021-12-08 03:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 03:32:00 --> Input Class Initialized
INFO - 2021-12-08 03:32:00 --> Language Class Initialized
INFO - 2021-12-08 03:32:00 --> Language Class Initialized
INFO - 2021-12-08 03:32:00 --> Config Class Initialized
INFO - 2021-12-08 03:32:00 --> Loader Class Initialized
INFO - 2021-12-08 03:32:00 --> Helper loaded: url_helper
INFO - 2021-12-08 03:32:00 --> Helper loaded: file_helper
INFO - 2021-12-08 03:32:00 --> Helper loaded: form_helper
INFO - 2021-12-08 03:32:00 --> Helper loaded: my_helper
INFO - 2021-12-08 03:32:00 --> Database Driver Class Initialized
DEBUG - 2021-12-08 03:32:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 03:32:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 03:32:00 --> Controller Class Initialized
DEBUG - 2021-12-08 03:32:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-08 03:32:00 --> Final output sent to browser
DEBUG - 2021-12-08 03:32:00 --> Total execution time: 0.1620
INFO - 2021-12-08 03:32:19 --> Config Class Initialized
INFO - 2021-12-08 03:32:19 --> Hooks Class Initialized
DEBUG - 2021-12-08 03:32:19 --> UTF-8 Support Enabled
INFO - 2021-12-08 03:32:19 --> Utf8 Class Initialized
INFO - 2021-12-08 03:32:19 --> URI Class Initialized
INFO - 2021-12-08 03:32:19 --> Router Class Initialized
INFO - 2021-12-08 03:32:19 --> Output Class Initialized
INFO - 2021-12-08 03:32:19 --> Security Class Initialized
DEBUG - 2021-12-08 03:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 03:32:19 --> Input Class Initialized
INFO - 2021-12-08 03:32:19 --> Language Class Initialized
INFO - 2021-12-08 03:32:19 --> Language Class Initialized
INFO - 2021-12-08 03:32:19 --> Config Class Initialized
INFO - 2021-12-08 03:32:19 --> Loader Class Initialized
INFO - 2021-12-08 03:32:19 --> Helper loaded: url_helper
INFO - 2021-12-08 03:32:19 --> Helper loaded: file_helper
INFO - 2021-12-08 03:32:19 --> Helper loaded: form_helper
INFO - 2021-12-08 03:32:19 --> Helper loaded: my_helper
INFO - 2021-12-08 03:32:19 --> Database Driver Class Initialized
DEBUG - 2021-12-08 03:32:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 03:32:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 03:32:19 --> Controller Class Initialized
DEBUG - 2021-12-08 03:32:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-08 03:32:19 --> Final output sent to browser
DEBUG - 2021-12-08 03:32:19 --> Total execution time: 0.1350
INFO - 2021-12-08 04:08:26 --> Config Class Initialized
INFO - 2021-12-08 04:08:26 --> Hooks Class Initialized
DEBUG - 2021-12-08 04:08:26 --> UTF-8 Support Enabled
INFO - 2021-12-08 04:08:26 --> Utf8 Class Initialized
INFO - 2021-12-08 04:08:26 --> URI Class Initialized
INFO - 2021-12-08 04:08:26 --> Router Class Initialized
INFO - 2021-12-08 04:08:26 --> Output Class Initialized
INFO - 2021-12-08 04:08:26 --> Security Class Initialized
DEBUG - 2021-12-08 04:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 04:08:26 --> Input Class Initialized
INFO - 2021-12-08 04:08:26 --> Language Class Initialized
INFO - 2021-12-08 04:08:26 --> Language Class Initialized
INFO - 2021-12-08 04:08:26 --> Config Class Initialized
INFO - 2021-12-08 04:08:26 --> Loader Class Initialized
INFO - 2021-12-08 04:08:26 --> Helper loaded: url_helper
INFO - 2021-12-08 04:08:26 --> Helper loaded: file_helper
INFO - 2021-12-08 04:08:26 --> Helper loaded: form_helper
INFO - 2021-12-08 04:08:26 --> Helper loaded: my_helper
INFO - 2021-12-08 04:08:26 --> Database Driver Class Initialized
DEBUG - 2021-12-08 04:08:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 04:08:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 04:08:26 --> Controller Class Initialized
DEBUG - 2021-12-08 04:08:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-08 04:08:26 --> Final output sent to browser
DEBUG - 2021-12-08 04:08:26 --> Total execution time: 0.1250
INFO - 2021-12-08 04:09:22 --> Config Class Initialized
INFO - 2021-12-08 04:09:22 --> Hooks Class Initialized
DEBUG - 2021-12-08 04:09:22 --> UTF-8 Support Enabled
INFO - 2021-12-08 04:09:22 --> Utf8 Class Initialized
INFO - 2021-12-08 04:09:22 --> URI Class Initialized
INFO - 2021-12-08 04:09:22 --> Router Class Initialized
INFO - 2021-12-08 04:09:22 --> Output Class Initialized
INFO - 2021-12-08 04:09:22 --> Security Class Initialized
DEBUG - 2021-12-08 04:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 04:09:22 --> Input Class Initialized
INFO - 2021-12-08 04:09:22 --> Language Class Initialized
INFO - 2021-12-08 04:09:22 --> Language Class Initialized
INFO - 2021-12-08 04:09:22 --> Config Class Initialized
INFO - 2021-12-08 04:09:22 --> Loader Class Initialized
INFO - 2021-12-08 04:09:22 --> Helper loaded: url_helper
INFO - 2021-12-08 04:09:22 --> Helper loaded: file_helper
INFO - 2021-12-08 04:09:22 --> Helper loaded: form_helper
INFO - 2021-12-08 04:09:22 --> Helper loaded: my_helper
INFO - 2021-12-08 04:09:22 --> Database Driver Class Initialized
DEBUG - 2021-12-08 04:09:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 04:09:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 04:09:22 --> Controller Class Initialized
DEBUG - 2021-12-08 04:09:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-08 04:09:22 --> Final output sent to browser
DEBUG - 2021-12-08 04:09:22 --> Total execution time: 0.1400
INFO - 2021-12-08 04:09:38 --> Config Class Initialized
INFO - 2021-12-08 04:09:38 --> Hooks Class Initialized
DEBUG - 2021-12-08 04:09:38 --> UTF-8 Support Enabled
INFO - 2021-12-08 04:09:38 --> Utf8 Class Initialized
INFO - 2021-12-08 04:09:38 --> URI Class Initialized
INFO - 2021-12-08 04:09:38 --> Router Class Initialized
INFO - 2021-12-08 04:09:38 --> Output Class Initialized
INFO - 2021-12-08 04:09:38 --> Security Class Initialized
DEBUG - 2021-12-08 04:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 04:09:38 --> Input Class Initialized
INFO - 2021-12-08 04:09:38 --> Language Class Initialized
INFO - 2021-12-08 04:09:38 --> Language Class Initialized
INFO - 2021-12-08 04:09:38 --> Config Class Initialized
INFO - 2021-12-08 04:09:38 --> Loader Class Initialized
INFO - 2021-12-08 04:09:38 --> Helper loaded: url_helper
INFO - 2021-12-08 04:09:38 --> Helper loaded: file_helper
INFO - 2021-12-08 04:09:38 --> Helper loaded: form_helper
INFO - 2021-12-08 04:09:38 --> Helper loaded: my_helper
INFO - 2021-12-08 04:09:38 --> Database Driver Class Initialized
DEBUG - 2021-12-08 04:09:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 04:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 04:09:38 --> Controller Class Initialized
DEBUG - 2021-12-08 04:09:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-08 04:09:38 --> Final output sent to browser
DEBUG - 2021-12-08 04:09:38 --> Total execution time: 0.1390
INFO - 2021-12-08 04:09:50 --> Config Class Initialized
INFO - 2021-12-08 04:09:50 --> Hooks Class Initialized
DEBUG - 2021-12-08 04:09:50 --> UTF-8 Support Enabled
INFO - 2021-12-08 04:09:50 --> Utf8 Class Initialized
INFO - 2021-12-08 04:09:50 --> URI Class Initialized
INFO - 2021-12-08 04:09:50 --> Router Class Initialized
INFO - 2021-12-08 04:09:50 --> Output Class Initialized
INFO - 2021-12-08 04:09:50 --> Security Class Initialized
DEBUG - 2021-12-08 04:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 04:09:50 --> Input Class Initialized
INFO - 2021-12-08 04:09:50 --> Language Class Initialized
INFO - 2021-12-08 04:09:50 --> Language Class Initialized
INFO - 2021-12-08 04:09:50 --> Config Class Initialized
INFO - 2021-12-08 04:09:50 --> Loader Class Initialized
INFO - 2021-12-08 04:09:50 --> Helper loaded: url_helper
INFO - 2021-12-08 04:09:50 --> Helper loaded: file_helper
INFO - 2021-12-08 04:09:50 --> Helper loaded: form_helper
INFO - 2021-12-08 04:09:50 --> Helper loaded: my_helper
INFO - 2021-12-08 04:09:50 --> Database Driver Class Initialized
DEBUG - 2021-12-08 04:09:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 04:09:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 04:09:50 --> Controller Class Initialized
DEBUG - 2021-12-08 04:09:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-08 04:09:50 --> Final output sent to browser
DEBUG - 2021-12-08 04:09:50 --> Total execution time: 0.1510
INFO - 2021-12-08 04:12:12 --> Config Class Initialized
INFO - 2021-12-08 04:12:12 --> Hooks Class Initialized
DEBUG - 2021-12-08 04:12:12 --> UTF-8 Support Enabled
INFO - 2021-12-08 04:12:12 --> Utf8 Class Initialized
INFO - 2021-12-08 04:12:12 --> URI Class Initialized
INFO - 2021-12-08 04:12:12 --> Router Class Initialized
INFO - 2021-12-08 04:12:12 --> Output Class Initialized
INFO - 2021-12-08 04:12:12 --> Security Class Initialized
DEBUG - 2021-12-08 04:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 04:12:12 --> Input Class Initialized
INFO - 2021-12-08 04:12:12 --> Language Class Initialized
INFO - 2021-12-08 04:12:12 --> Language Class Initialized
INFO - 2021-12-08 04:12:12 --> Config Class Initialized
INFO - 2021-12-08 04:12:12 --> Loader Class Initialized
INFO - 2021-12-08 04:12:12 --> Helper loaded: url_helper
INFO - 2021-12-08 04:12:12 --> Helper loaded: file_helper
INFO - 2021-12-08 04:12:12 --> Helper loaded: form_helper
INFO - 2021-12-08 04:12:12 --> Helper loaded: my_helper
INFO - 2021-12-08 04:12:12 --> Database Driver Class Initialized
DEBUG - 2021-12-08 04:12:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 04:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 04:12:12 --> Controller Class Initialized
DEBUG - 2021-12-08 04:12:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-08 04:12:12 --> Final output sent to browser
DEBUG - 2021-12-08 04:12:12 --> Total execution time: 0.1300
INFO - 2021-12-08 04:12:36 --> Config Class Initialized
INFO - 2021-12-08 04:12:36 --> Hooks Class Initialized
DEBUG - 2021-12-08 04:12:36 --> UTF-8 Support Enabled
INFO - 2021-12-08 04:12:36 --> Utf8 Class Initialized
INFO - 2021-12-08 04:12:36 --> URI Class Initialized
INFO - 2021-12-08 04:12:36 --> Router Class Initialized
INFO - 2021-12-08 04:12:36 --> Output Class Initialized
INFO - 2021-12-08 04:12:36 --> Security Class Initialized
DEBUG - 2021-12-08 04:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 04:12:36 --> Input Class Initialized
INFO - 2021-12-08 04:12:36 --> Language Class Initialized
INFO - 2021-12-08 04:12:36 --> Language Class Initialized
INFO - 2021-12-08 04:12:36 --> Config Class Initialized
INFO - 2021-12-08 04:12:36 --> Loader Class Initialized
INFO - 2021-12-08 04:12:36 --> Helper loaded: url_helper
INFO - 2021-12-08 04:12:36 --> Helper loaded: file_helper
INFO - 2021-12-08 04:12:36 --> Helper loaded: form_helper
INFO - 2021-12-08 04:12:36 --> Helper loaded: my_helper
INFO - 2021-12-08 04:12:36 --> Database Driver Class Initialized
DEBUG - 2021-12-08 04:12:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 04:12:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 04:12:36 --> Controller Class Initialized
DEBUG - 2021-12-08 04:12:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-08 04:12:37 --> Final output sent to browser
DEBUG - 2021-12-08 04:12:37 --> Total execution time: 0.1420
INFO - 2021-12-08 04:13:44 --> Config Class Initialized
INFO - 2021-12-08 04:13:44 --> Hooks Class Initialized
DEBUG - 2021-12-08 04:13:44 --> UTF-8 Support Enabled
INFO - 2021-12-08 04:13:44 --> Utf8 Class Initialized
INFO - 2021-12-08 04:13:44 --> URI Class Initialized
INFO - 2021-12-08 04:13:44 --> Router Class Initialized
INFO - 2021-12-08 04:13:44 --> Output Class Initialized
INFO - 2021-12-08 04:13:44 --> Security Class Initialized
DEBUG - 2021-12-08 04:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 04:13:44 --> Input Class Initialized
INFO - 2021-12-08 04:13:44 --> Language Class Initialized
INFO - 2021-12-08 04:13:44 --> Language Class Initialized
INFO - 2021-12-08 04:13:44 --> Config Class Initialized
INFO - 2021-12-08 04:13:44 --> Loader Class Initialized
INFO - 2021-12-08 04:13:44 --> Helper loaded: url_helper
INFO - 2021-12-08 04:13:44 --> Helper loaded: file_helper
INFO - 2021-12-08 04:13:44 --> Helper loaded: form_helper
INFO - 2021-12-08 04:13:44 --> Helper loaded: my_helper
INFO - 2021-12-08 04:13:44 --> Database Driver Class Initialized
DEBUG - 2021-12-08 04:13:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 04:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 04:13:44 --> Controller Class Initialized
DEBUG - 2021-12-08 04:13:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-08 04:13:44 --> Final output sent to browser
DEBUG - 2021-12-08 04:13:44 --> Total execution time: 0.1190
INFO - 2021-12-08 04:13:57 --> Config Class Initialized
INFO - 2021-12-08 04:13:57 --> Hooks Class Initialized
DEBUG - 2021-12-08 04:13:57 --> UTF-8 Support Enabled
INFO - 2021-12-08 04:13:57 --> Utf8 Class Initialized
INFO - 2021-12-08 04:13:57 --> URI Class Initialized
INFO - 2021-12-08 04:13:57 --> Router Class Initialized
INFO - 2021-12-08 04:13:57 --> Output Class Initialized
INFO - 2021-12-08 04:13:57 --> Security Class Initialized
DEBUG - 2021-12-08 04:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 04:13:57 --> Input Class Initialized
INFO - 2021-12-08 04:13:57 --> Language Class Initialized
INFO - 2021-12-08 04:13:57 --> Language Class Initialized
INFO - 2021-12-08 04:13:57 --> Config Class Initialized
INFO - 2021-12-08 04:13:57 --> Loader Class Initialized
INFO - 2021-12-08 04:13:57 --> Helper loaded: url_helper
INFO - 2021-12-08 04:13:57 --> Helper loaded: file_helper
INFO - 2021-12-08 04:13:57 --> Helper loaded: form_helper
INFO - 2021-12-08 04:13:57 --> Helper loaded: my_helper
INFO - 2021-12-08 04:13:57 --> Database Driver Class Initialized
DEBUG - 2021-12-08 04:13:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 04:13:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 04:13:57 --> Controller Class Initialized
DEBUG - 2021-12-08 04:13:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-08 04:13:58 --> Final output sent to browser
DEBUG - 2021-12-08 04:13:58 --> Total execution time: 0.1440
INFO - 2021-12-08 04:14:11 --> Config Class Initialized
INFO - 2021-12-08 04:14:11 --> Hooks Class Initialized
DEBUG - 2021-12-08 04:14:11 --> UTF-8 Support Enabled
INFO - 2021-12-08 04:14:11 --> Utf8 Class Initialized
INFO - 2021-12-08 04:14:11 --> URI Class Initialized
INFO - 2021-12-08 04:14:11 --> Router Class Initialized
INFO - 2021-12-08 04:14:11 --> Output Class Initialized
INFO - 2021-12-08 04:14:11 --> Security Class Initialized
DEBUG - 2021-12-08 04:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 04:14:11 --> Input Class Initialized
INFO - 2021-12-08 04:14:11 --> Language Class Initialized
INFO - 2021-12-08 04:14:11 --> Language Class Initialized
INFO - 2021-12-08 04:14:11 --> Config Class Initialized
INFO - 2021-12-08 04:14:11 --> Loader Class Initialized
INFO - 2021-12-08 04:14:11 --> Helper loaded: url_helper
INFO - 2021-12-08 04:14:11 --> Helper loaded: file_helper
INFO - 2021-12-08 04:14:11 --> Helper loaded: form_helper
INFO - 2021-12-08 04:14:11 --> Helper loaded: my_helper
INFO - 2021-12-08 04:14:11 --> Database Driver Class Initialized
DEBUG - 2021-12-08 04:14:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 04:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 04:14:11 --> Controller Class Initialized
DEBUG - 2021-12-08 04:14:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-08 04:14:11 --> Final output sent to browser
DEBUG - 2021-12-08 04:14:11 --> Total execution time: 0.1400
INFO - 2021-12-08 04:15:28 --> Config Class Initialized
INFO - 2021-12-08 04:15:28 --> Hooks Class Initialized
DEBUG - 2021-12-08 04:15:28 --> UTF-8 Support Enabled
INFO - 2021-12-08 04:15:28 --> Utf8 Class Initialized
INFO - 2021-12-08 04:15:28 --> URI Class Initialized
INFO - 2021-12-08 04:15:28 --> Router Class Initialized
INFO - 2021-12-08 04:15:28 --> Output Class Initialized
INFO - 2021-12-08 04:15:28 --> Security Class Initialized
DEBUG - 2021-12-08 04:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 04:15:28 --> Input Class Initialized
INFO - 2021-12-08 04:15:28 --> Language Class Initialized
INFO - 2021-12-08 04:15:28 --> Language Class Initialized
INFO - 2021-12-08 04:15:28 --> Config Class Initialized
INFO - 2021-12-08 04:15:28 --> Loader Class Initialized
INFO - 2021-12-08 04:15:28 --> Helper loaded: url_helper
INFO - 2021-12-08 04:15:28 --> Helper loaded: file_helper
INFO - 2021-12-08 04:15:28 --> Helper loaded: form_helper
INFO - 2021-12-08 04:15:28 --> Helper loaded: my_helper
INFO - 2021-12-08 04:15:28 --> Database Driver Class Initialized
DEBUG - 2021-12-08 04:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 04:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 04:15:28 --> Controller Class Initialized
DEBUG - 2021-12-08 04:15:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-08 04:15:28 --> Final output sent to browser
DEBUG - 2021-12-08 04:15:28 --> Total execution time: 0.1470
INFO - 2021-12-08 04:15:42 --> Config Class Initialized
INFO - 2021-12-08 04:15:42 --> Hooks Class Initialized
DEBUG - 2021-12-08 04:15:42 --> UTF-8 Support Enabled
INFO - 2021-12-08 04:15:42 --> Utf8 Class Initialized
INFO - 2021-12-08 04:15:42 --> URI Class Initialized
INFO - 2021-12-08 04:15:42 --> Router Class Initialized
INFO - 2021-12-08 04:15:42 --> Output Class Initialized
INFO - 2021-12-08 04:15:42 --> Security Class Initialized
DEBUG - 2021-12-08 04:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 04:15:42 --> Input Class Initialized
INFO - 2021-12-08 04:15:42 --> Language Class Initialized
INFO - 2021-12-08 04:15:42 --> Language Class Initialized
INFO - 2021-12-08 04:15:42 --> Config Class Initialized
INFO - 2021-12-08 04:15:42 --> Loader Class Initialized
INFO - 2021-12-08 04:15:42 --> Helper loaded: url_helper
INFO - 2021-12-08 04:15:42 --> Helper loaded: file_helper
INFO - 2021-12-08 04:15:42 --> Helper loaded: form_helper
INFO - 2021-12-08 04:15:42 --> Helper loaded: my_helper
INFO - 2021-12-08 04:15:42 --> Database Driver Class Initialized
DEBUG - 2021-12-08 04:15:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 04:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 04:15:42 --> Controller Class Initialized
DEBUG - 2021-12-08 04:15:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-08 04:15:42 --> Final output sent to browser
DEBUG - 2021-12-08 04:15:42 --> Total execution time: 0.1630
INFO - 2021-12-08 08:03:15 --> Config Class Initialized
INFO - 2021-12-08 08:03:15 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:03:15 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:03:15 --> Utf8 Class Initialized
INFO - 2021-12-08 08:03:15 --> URI Class Initialized
INFO - 2021-12-08 08:03:15 --> Router Class Initialized
INFO - 2021-12-08 08:03:15 --> Output Class Initialized
INFO - 2021-12-08 08:03:15 --> Security Class Initialized
DEBUG - 2021-12-08 08:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:03:15 --> Input Class Initialized
INFO - 2021-12-08 08:03:15 --> Language Class Initialized
INFO - 2021-12-08 08:03:15 --> Language Class Initialized
INFO - 2021-12-08 08:03:15 --> Config Class Initialized
INFO - 2021-12-08 08:03:15 --> Loader Class Initialized
INFO - 2021-12-08 08:03:15 --> Helper loaded: url_helper
INFO - 2021-12-08 08:03:15 --> Helper loaded: file_helper
INFO - 2021-12-08 08:03:15 --> Helper loaded: form_helper
INFO - 2021-12-08 08:03:15 --> Helper loaded: my_helper
INFO - 2021-12-08 08:03:15 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:03:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:03:15 --> Controller Class Initialized
INFO - 2021-12-08 08:03:15 --> Helper loaded: cookie_helper
INFO - 2021-12-08 08:03:15 --> Config Class Initialized
INFO - 2021-12-08 08:03:15 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:03:15 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:03:15 --> Utf8 Class Initialized
INFO - 2021-12-08 08:03:15 --> URI Class Initialized
INFO - 2021-12-08 08:03:15 --> Router Class Initialized
INFO - 2021-12-08 08:03:15 --> Output Class Initialized
INFO - 2021-12-08 08:03:15 --> Security Class Initialized
DEBUG - 2021-12-08 08:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:03:15 --> Input Class Initialized
INFO - 2021-12-08 08:03:15 --> Language Class Initialized
INFO - 2021-12-08 08:03:15 --> Language Class Initialized
INFO - 2021-12-08 08:03:15 --> Config Class Initialized
INFO - 2021-12-08 08:03:15 --> Loader Class Initialized
INFO - 2021-12-08 08:03:15 --> Helper loaded: url_helper
INFO - 2021-12-08 08:03:15 --> Helper loaded: file_helper
INFO - 2021-12-08 08:03:15 --> Helper loaded: form_helper
INFO - 2021-12-08 08:03:15 --> Helper loaded: my_helper
INFO - 2021-12-08 08:03:15 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:03:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:03:15 --> Controller Class Initialized
DEBUG - 2021-12-08 08:03:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-08 08:03:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 08:03:15 --> Final output sent to browser
DEBUG - 2021-12-08 08:03:15 --> Total execution time: 0.0350
INFO - 2021-12-08 08:03:55 --> Config Class Initialized
INFO - 2021-12-08 08:03:55 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:03:55 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:03:55 --> Utf8 Class Initialized
INFO - 2021-12-08 08:03:55 --> URI Class Initialized
INFO - 2021-12-08 08:03:55 --> Router Class Initialized
INFO - 2021-12-08 08:03:55 --> Output Class Initialized
INFO - 2021-12-08 08:03:55 --> Security Class Initialized
DEBUG - 2021-12-08 08:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:03:55 --> Input Class Initialized
INFO - 2021-12-08 08:03:55 --> Language Class Initialized
INFO - 2021-12-08 08:03:55 --> Language Class Initialized
INFO - 2021-12-08 08:03:55 --> Config Class Initialized
INFO - 2021-12-08 08:03:55 --> Loader Class Initialized
INFO - 2021-12-08 08:03:55 --> Helper loaded: url_helper
INFO - 2021-12-08 08:03:55 --> Helper loaded: file_helper
INFO - 2021-12-08 08:03:55 --> Helper loaded: form_helper
INFO - 2021-12-08 08:03:55 --> Helper loaded: my_helper
INFO - 2021-12-08 08:03:55 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:03:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:03:55 --> Controller Class Initialized
INFO - 2021-12-08 08:03:55 --> Helper loaded: cookie_helper
INFO - 2021-12-08 08:03:55 --> Final output sent to browser
DEBUG - 2021-12-08 08:03:55 --> Total execution time: 0.0600
INFO - 2021-12-08 08:04:02 --> Config Class Initialized
INFO - 2021-12-08 08:04:02 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:04:02 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:04:02 --> Utf8 Class Initialized
INFO - 2021-12-08 08:04:02 --> URI Class Initialized
INFO - 2021-12-08 08:04:02 --> Router Class Initialized
INFO - 2021-12-08 08:04:02 --> Output Class Initialized
INFO - 2021-12-08 08:04:02 --> Security Class Initialized
DEBUG - 2021-12-08 08:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:04:02 --> Input Class Initialized
INFO - 2021-12-08 08:04:02 --> Language Class Initialized
INFO - 2021-12-08 08:04:02 --> Language Class Initialized
INFO - 2021-12-08 08:04:02 --> Config Class Initialized
INFO - 2021-12-08 08:04:02 --> Loader Class Initialized
INFO - 2021-12-08 08:04:02 --> Helper loaded: url_helper
INFO - 2021-12-08 08:04:02 --> Helper loaded: file_helper
INFO - 2021-12-08 08:04:02 --> Helper loaded: form_helper
INFO - 2021-12-08 08:04:02 --> Helper loaded: my_helper
INFO - 2021-12-08 08:04:02 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:04:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:04:02 --> Controller Class Initialized
DEBUG - 2021-12-08 08:04:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-08 08:04:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 08:04:03 --> Final output sent to browser
DEBUG - 2021-12-08 08:04:03 --> Total execution time: 0.7490
INFO - 2021-12-08 08:04:15 --> Config Class Initialized
INFO - 2021-12-08 08:04:15 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:04:15 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:04:15 --> Utf8 Class Initialized
INFO - 2021-12-08 08:04:15 --> URI Class Initialized
INFO - 2021-12-08 08:04:15 --> Router Class Initialized
INFO - 2021-12-08 08:04:15 --> Output Class Initialized
INFO - 2021-12-08 08:04:15 --> Security Class Initialized
DEBUG - 2021-12-08 08:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:04:15 --> Input Class Initialized
INFO - 2021-12-08 08:04:15 --> Language Class Initialized
INFO - 2021-12-08 08:04:15 --> Language Class Initialized
INFO - 2021-12-08 08:04:15 --> Config Class Initialized
INFO - 2021-12-08 08:04:15 --> Loader Class Initialized
INFO - 2021-12-08 08:04:15 --> Helper loaded: url_helper
INFO - 2021-12-08 08:04:15 --> Helper loaded: file_helper
INFO - 2021-12-08 08:04:15 --> Helper loaded: form_helper
INFO - 2021-12-08 08:04:15 --> Helper loaded: my_helper
INFO - 2021-12-08 08:04:15 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:04:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:04:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:04:15 --> Controller Class Initialized
DEBUG - 2021-12-08 08:04:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-12-08 08:04:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 08:04:15 --> Final output sent to browser
DEBUG - 2021-12-08 08:04:15 --> Total execution time: 0.0460
INFO - 2021-12-08 08:04:15 --> Config Class Initialized
INFO - 2021-12-08 08:04:15 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:04:15 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:04:15 --> Utf8 Class Initialized
INFO - 2021-12-08 08:04:15 --> URI Class Initialized
INFO - 2021-12-08 08:04:15 --> Router Class Initialized
INFO - 2021-12-08 08:04:15 --> Output Class Initialized
INFO - 2021-12-08 08:04:15 --> Security Class Initialized
DEBUG - 2021-12-08 08:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:04:15 --> Input Class Initialized
INFO - 2021-12-08 08:04:15 --> Language Class Initialized
INFO - 2021-12-08 08:04:15 --> Language Class Initialized
INFO - 2021-12-08 08:04:15 --> Config Class Initialized
INFO - 2021-12-08 08:04:15 --> Loader Class Initialized
INFO - 2021-12-08 08:04:15 --> Helper loaded: url_helper
INFO - 2021-12-08 08:04:15 --> Helper loaded: file_helper
INFO - 2021-12-08 08:04:15 --> Helper loaded: form_helper
INFO - 2021-12-08 08:04:15 --> Helper loaded: my_helper
INFO - 2021-12-08 08:04:15 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:04:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:04:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:04:15 --> Controller Class Initialized
INFO - 2021-12-08 08:04:35 --> Config Class Initialized
INFO - 2021-12-08 08:04:35 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:04:35 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:04:35 --> Utf8 Class Initialized
INFO - 2021-12-08 08:04:35 --> URI Class Initialized
INFO - 2021-12-08 08:04:35 --> Router Class Initialized
INFO - 2021-12-08 08:04:35 --> Output Class Initialized
INFO - 2021-12-08 08:04:35 --> Security Class Initialized
DEBUG - 2021-12-08 08:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:04:35 --> Input Class Initialized
INFO - 2021-12-08 08:04:35 --> Language Class Initialized
INFO - 2021-12-08 08:04:35 --> Language Class Initialized
INFO - 2021-12-08 08:04:35 --> Config Class Initialized
INFO - 2021-12-08 08:04:35 --> Loader Class Initialized
INFO - 2021-12-08 08:04:35 --> Helper loaded: url_helper
INFO - 2021-12-08 08:04:35 --> Helper loaded: file_helper
INFO - 2021-12-08 08:04:35 --> Helper loaded: form_helper
INFO - 2021-12-08 08:04:35 --> Helper loaded: my_helper
INFO - 2021-12-08 08:04:35 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:04:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:04:35 --> Controller Class Initialized
INFO - 2021-12-08 08:04:35 --> Final output sent to browser
DEBUG - 2021-12-08 08:04:35 --> Total execution time: 0.0580
INFO - 2021-12-08 08:04:35 --> Config Class Initialized
INFO - 2021-12-08 08:04:35 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:04:35 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:04:35 --> Utf8 Class Initialized
INFO - 2021-12-08 08:04:35 --> URI Class Initialized
INFO - 2021-12-08 08:04:35 --> Router Class Initialized
INFO - 2021-12-08 08:04:35 --> Output Class Initialized
INFO - 2021-12-08 08:04:35 --> Security Class Initialized
DEBUG - 2021-12-08 08:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:04:35 --> Input Class Initialized
INFO - 2021-12-08 08:04:35 --> Language Class Initialized
INFO - 2021-12-08 08:04:35 --> Language Class Initialized
INFO - 2021-12-08 08:04:35 --> Config Class Initialized
INFO - 2021-12-08 08:04:35 --> Loader Class Initialized
INFO - 2021-12-08 08:04:35 --> Helper loaded: url_helper
INFO - 2021-12-08 08:04:35 --> Helper loaded: file_helper
INFO - 2021-12-08 08:04:35 --> Helper loaded: form_helper
INFO - 2021-12-08 08:04:35 --> Helper loaded: my_helper
INFO - 2021-12-08 08:04:35 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:04:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:04:35 --> Controller Class Initialized
INFO - 2021-12-08 08:04:43 --> Config Class Initialized
INFO - 2021-12-08 08:04:43 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:04:43 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:04:43 --> Utf8 Class Initialized
INFO - 2021-12-08 08:04:43 --> URI Class Initialized
INFO - 2021-12-08 08:04:43 --> Router Class Initialized
INFO - 2021-12-08 08:04:43 --> Output Class Initialized
INFO - 2021-12-08 08:04:43 --> Security Class Initialized
DEBUG - 2021-12-08 08:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:04:43 --> Input Class Initialized
INFO - 2021-12-08 08:04:43 --> Language Class Initialized
INFO - 2021-12-08 08:04:43 --> Language Class Initialized
INFO - 2021-12-08 08:04:43 --> Config Class Initialized
INFO - 2021-12-08 08:04:43 --> Loader Class Initialized
INFO - 2021-12-08 08:04:43 --> Helper loaded: url_helper
INFO - 2021-12-08 08:04:43 --> Helper loaded: file_helper
INFO - 2021-12-08 08:04:43 --> Helper loaded: form_helper
INFO - 2021-12-08 08:04:43 --> Helper loaded: my_helper
INFO - 2021-12-08 08:04:43 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:04:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:04:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:04:43 --> Controller Class Initialized
INFO - 2021-12-08 08:04:43 --> Helper loaded: cookie_helper
INFO - 2021-12-08 08:04:43 --> Config Class Initialized
INFO - 2021-12-08 08:04:43 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:04:43 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:04:43 --> Utf8 Class Initialized
INFO - 2021-12-08 08:04:43 --> URI Class Initialized
INFO - 2021-12-08 08:04:43 --> Router Class Initialized
INFO - 2021-12-08 08:04:43 --> Output Class Initialized
INFO - 2021-12-08 08:04:43 --> Security Class Initialized
DEBUG - 2021-12-08 08:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:04:43 --> Input Class Initialized
INFO - 2021-12-08 08:04:43 --> Language Class Initialized
INFO - 2021-12-08 08:04:43 --> Language Class Initialized
INFO - 2021-12-08 08:04:43 --> Config Class Initialized
INFO - 2021-12-08 08:04:43 --> Loader Class Initialized
INFO - 2021-12-08 08:04:43 --> Helper loaded: url_helper
INFO - 2021-12-08 08:04:43 --> Helper loaded: file_helper
INFO - 2021-12-08 08:04:43 --> Helper loaded: form_helper
INFO - 2021-12-08 08:04:43 --> Helper loaded: my_helper
INFO - 2021-12-08 08:04:43 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:04:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:04:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:04:43 --> Controller Class Initialized
DEBUG - 2021-12-08 08:04:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-08 08:04:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 08:04:43 --> Final output sent to browser
DEBUG - 2021-12-08 08:04:43 --> Total execution time: 0.0360
INFO - 2021-12-08 08:05:25 --> Config Class Initialized
INFO - 2021-12-08 08:05:25 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:05:25 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:05:25 --> Utf8 Class Initialized
INFO - 2021-12-08 08:05:25 --> URI Class Initialized
INFO - 2021-12-08 08:05:25 --> Router Class Initialized
INFO - 2021-12-08 08:05:25 --> Output Class Initialized
INFO - 2021-12-08 08:05:25 --> Security Class Initialized
DEBUG - 2021-12-08 08:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:05:25 --> Input Class Initialized
INFO - 2021-12-08 08:05:25 --> Language Class Initialized
INFO - 2021-12-08 08:05:25 --> Language Class Initialized
INFO - 2021-12-08 08:05:25 --> Config Class Initialized
INFO - 2021-12-08 08:05:25 --> Loader Class Initialized
INFO - 2021-12-08 08:05:25 --> Helper loaded: url_helper
INFO - 2021-12-08 08:05:25 --> Helper loaded: file_helper
INFO - 2021-12-08 08:05:25 --> Helper loaded: form_helper
INFO - 2021-12-08 08:05:25 --> Helper loaded: my_helper
INFO - 2021-12-08 08:05:25 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:05:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:05:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:05:25 --> Controller Class Initialized
INFO - 2021-12-08 08:05:25 --> Helper loaded: cookie_helper
INFO - 2021-12-08 08:05:25 --> Final output sent to browser
DEBUG - 2021-12-08 08:05:25 --> Total execution time: 0.0510
INFO - 2021-12-08 08:05:27 --> Config Class Initialized
INFO - 2021-12-08 08:05:27 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:05:27 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:05:27 --> Utf8 Class Initialized
INFO - 2021-12-08 08:05:27 --> URI Class Initialized
INFO - 2021-12-08 08:05:27 --> Router Class Initialized
INFO - 2021-12-08 08:05:27 --> Output Class Initialized
INFO - 2021-12-08 08:05:27 --> Security Class Initialized
DEBUG - 2021-12-08 08:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:05:27 --> Input Class Initialized
INFO - 2021-12-08 08:05:27 --> Language Class Initialized
INFO - 2021-12-08 08:05:27 --> Language Class Initialized
INFO - 2021-12-08 08:05:27 --> Config Class Initialized
INFO - 2021-12-08 08:05:27 --> Loader Class Initialized
INFO - 2021-12-08 08:05:27 --> Helper loaded: url_helper
INFO - 2021-12-08 08:05:27 --> Helper loaded: file_helper
INFO - 2021-12-08 08:05:27 --> Helper loaded: form_helper
INFO - 2021-12-08 08:05:27 --> Helper loaded: my_helper
INFO - 2021-12-08 08:05:27 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:05:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:05:27 --> Controller Class Initialized
DEBUG - 2021-12-08 08:05:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-08 08:05:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 08:05:27 --> Final output sent to browser
DEBUG - 2021-12-08 08:05:27 --> Total execution time: 0.1640
INFO - 2021-12-08 08:05:52 --> Config Class Initialized
INFO - 2021-12-08 08:05:52 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:05:52 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:05:52 --> Utf8 Class Initialized
INFO - 2021-12-08 08:05:52 --> URI Class Initialized
INFO - 2021-12-08 08:05:52 --> Router Class Initialized
INFO - 2021-12-08 08:05:52 --> Output Class Initialized
INFO - 2021-12-08 08:05:52 --> Security Class Initialized
DEBUG - 2021-12-08 08:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:05:52 --> Input Class Initialized
INFO - 2021-12-08 08:05:52 --> Language Class Initialized
INFO - 2021-12-08 08:05:52 --> Language Class Initialized
INFO - 2021-12-08 08:05:52 --> Config Class Initialized
INFO - 2021-12-08 08:05:52 --> Loader Class Initialized
INFO - 2021-12-08 08:05:52 --> Helper loaded: url_helper
INFO - 2021-12-08 08:05:52 --> Helper loaded: file_helper
INFO - 2021-12-08 08:05:52 --> Helper loaded: form_helper
INFO - 2021-12-08 08:05:52 --> Helper loaded: my_helper
INFO - 2021-12-08 08:05:52 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:05:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:05:52 --> Controller Class Initialized
INFO - 2021-12-08 08:05:52 --> Helper loaded: cookie_helper
INFO - 2021-12-08 08:05:52 --> Config Class Initialized
INFO - 2021-12-08 08:05:52 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:05:52 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:05:52 --> Utf8 Class Initialized
INFO - 2021-12-08 08:05:52 --> URI Class Initialized
INFO - 2021-12-08 08:05:52 --> Router Class Initialized
INFO - 2021-12-08 08:05:52 --> Output Class Initialized
INFO - 2021-12-08 08:05:52 --> Security Class Initialized
DEBUG - 2021-12-08 08:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:05:52 --> Input Class Initialized
INFO - 2021-12-08 08:05:52 --> Language Class Initialized
INFO - 2021-12-08 08:05:52 --> Language Class Initialized
INFO - 2021-12-08 08:05:52 --> Config Class Initialized
INFO - 2021-12-08 08:05:52 --> Loader Class Initialized
INFO - 2021-12-08 08:05:52 --> Helper loaded: url_helper
INFO - 2021-12-08 08:05:52 --> Helper loaded: file_helper
INFO - 2021-12-08 08:05:52 --> Helper loaded: form_helper
INFO - 2021-12-08 08:05:52 --> Helper loaded: my_helper
INFO - 2021-12-08 08:05:52 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:05:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:05:52 --> Controller Class Initialized
DEBUG - 2021-12-08 08:05:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-08 08:05:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 08:05:52 --> Final output sent to browser
DEBUG - 2021-12-08 08:05:52 --> Total execution time: 0.0390
INFO - 2021-12-08 08:06:09 --> Config Class Initialized
INFO - 2021-12-08 08:06:09 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:06:09 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:06:09 --> Utf8 Class Initialized
INFO - 2021-12-08 08:06:09 --> URI Class Initialized
INFO - 2021-12-08 08:06:09 --> Router Class Initialized
INFO - 2021-12-08 08:06:09 --> Output Class Initialized
INFO - 2021-12-08 08:06:09 --> Security Class Initialized
DEBUG - 2021-12-08 08:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:06:09 --> Input Class Initialized
INFO - 2021-12-08 08:06:09 --> Language Class Initialized
INFO - 2021-12-08 08:06:09 --> Language Class Initialized
INFO - 2021-12-08 08:06:09 --> Config Class Initialized
INFO - 2021-12-08 08:06:09 --> Loader Class Initialized
INFO - 2021-12-08 08:06:09 --> Helper loaded: url_helper
INFO - 2021-12-08 08:06:09 --> Helper loaded: file_helper
INFO - 2021-12-08 08:06:09 --> Helper loaded: form_helper
INFO - 2021-12-08 08:06:09 --> Helper loaded: my_helper
INFO - 2021-12-08 08:06:09 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:06:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:06:09 --> Controller Class Initialized
INFO - 2021-12-08 08:06:09 --> Helper loaded: cookie_helper
INFO - 2021-12-08 08:06:09 --> Final output sent to browser
DEBUG - 2021-12-08 08:06:09 --> Total execution time: 0.0400
INFO - 2021-12-08 08:06:11 --> Config Class Initialized
INFO - 2021-12-08 08:06:11 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:06:11 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:06:11 --> Utf8 Class Initialized
INFO - 2021-12-08 08:06:11 --> URI Class Initialized
INFO - 2021-12-08 08:06:11 --> Router Class Initialized
INFO - 2021-12-08 08:06:11 --> Output Class Initialized
INFO - 2021-12-08 08:06:11 --> Security Class Initialized
DEBUG - 2021-12-08 08:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:06:11 --> Input Class Initialized
INFO - 2021-12-08 08:06:11 --> Language Class Initialized
INFO - 2021-12-08 08:06:11 --> Language Class Initialized
INFO - 2021-12-08 08:06:11 --> Config Class Initialized
INFO - 2021-12-08 08:06:11 --> Loader Class Initialized
INFO - 2021-12-08 08:06:11 --> Helper loaded: url_helper
INFO - 2021-12-08 08:06:11 --> Helper loaded: file_helper
INFO - 2021-12-08 08:06:11 --> Helper loaded: form_helper
INFO - 2021-12-08 08:06:11 --> Helper loaded: my_helper
INFO - 2021-12-08 08:06:11 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:06:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:06:11 --> Controller Class Initialized
DEBUG - 2021-12-08 08:06:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-08 08:06:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 08:06:11 --> Final output sent to browser
DEBUG - 2021-12-08 08:06:11 --> Total execution time: 0.1620
INFO - 2021-12-08 08:06:30 --> Config Class Initialized
INFO - 2021-12-08 08:06:30 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:06:30 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:06:30 --> Utf8 Class Initialized
INFO - 2021-12-08 08:06:30 --> URI Class Initialized
INFO - 2021-12-08 08:06:30 --> Router Class Initialized
INFO - 2021-12-08 08:06:30 --> Output Class Initialized
INFO - 2021-12-08 08:06:30 --> Security Class Initialized
DEBUG - 2021-12-08 08:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:06:30 --> Input Class Initialized
INFO - 2021-12-08 08:06:30 --> Language Class Initialized
INFO - 2021-12-08 08:06:30 --> Language Class Initialized
INFO - 2021-12-08 08:06:30 --> Config Class Initialized
INFO - 2021-12-08 08:06:30 --> Loader Class Initialized
INFO - 2021-12-08 08:06:30 --> Helper loaded: url_helper
INFO - 2021-12-08 08:06:30 --> Helper loaded: file_helper
INFO - 2021-12-08 08:06:30 --> Helper loaded: form_helper
INFO - 2021-12-08 08:06:30 --> Helper loaded: my_helper
INFO - 2021-12-08 08:06:30 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:06:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:06:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:06:30 --> Controller Class Initialized
DEBUG - 2021-12-08 08:06:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-12-08 08:06:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 08:06:30 --> Final output sent to browser
DEBUG - 2021-12-08 08:06:30 --> Total execution time: 0.0630
INFO - 2021-12-08 08:06:30 --> Config Class Initialized
INFO - 2021-12-08 08:06:30 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:06:30 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:06:30 --> Utf8 Class Initialized
INFO - 2021-12-08 08:06:30 --> URI Class Initialized
INFO - 2021-12-08 08:06:30 --> Router Class Initialized
INFO - 2021-12-08 08:06:30 --> Output Class Initialized
INFO - 2021-12-08 08:06:30 --> Security Class Initialized
DEBUG - 2021-12-08 08:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:06:30 --> Input Class Initialized
INFO - 2021-12-08 08:06:30 --> Language Class Initialized
INFO - 2021-12-08 08:06:30 --> Language Class Initialized
INFO - 2021-12-08 08:06:30 --> Config Class Initialized
INFO - 2021-12-08 08:06:30 --> Loader Class Initialized
INFO - 2021-12-08 08:06:30 --> Helper loaded: url_helper
INFO - 2021-12-08 08:06:30 --> Helper loaded: file_helper
INFO - 2021-12-08 08:06:30 --> Helper loaded: form_helper
INFO - 2021-12-08 08:06:30 --> Helper loaded: my_helper
INFO - 2021-12-08 08:06:30 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:06:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:06:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:06:30 --> Controller Class Initialized
INFO - 2021-12-08 08:06:36 --> Config Class Initialized
INFO - 2021-12-08 08:06:36 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:06:36 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:06:36 --> Utf8 Class Initialized
INFO - 2021-12-08 08:06:36 --> URI Class Initialized
INFO - 2021-12-08 08:06:36 --> Router Class Initialized
INFO - 2021-12-08 08:06:36 --> Output Class Initialized
INFO - 2021-12-08 08:06:36 --> Security Class Initialized
DEBUG - 2021-12-08 08:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:06:36 --> Input Class Initialized
INFO - 2021-12-08 08:06:36 --> Language Class Initialized
INFO - 2021-12-08 08:06:36 --> Language Class Initialized
INFO - 2021-12-08 08:06:36 --> Config Class Initialized
INFO - 2021-12-08 08:06:36 --> Loader Class Initialized
INFO - 2021-12-08 08:06:36 --> Helper loaded: url_helper
INFO - 2021-12-08 08:06:36 --> Helper loaded: file_helper
INFO - 2021-12-08 08:06:36 --> Helper loaded: form_helper
INFO - 2021-12-08 08:06:36 --> Helper loaded: my_helper
INFO - 2021-12-08 08:06:36 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:06:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:06:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:06:36 --> Controller Class Initialized
DEBUG - 2021-12-08 08:06:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2021-12-08 08:06:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 08:06:36 --> Final output sent to browser
DEBUG - 2021-12-08 08:06:36 --> Total execution time: 0.0660
INFO - 2021-12-08 08:06:36 --> Config Class Initialized
INFO - 2021-12-08 08:06:36 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:06:36 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:06:36 --> Utf8 Class Initialized
INFO - 2021-12-08 08:06:36 --> URI Class Initialized
INFO - 2021-12-08 08:06:36 --> Router Class Initialized
INFO - 2021-12-08 08:06:36 --> Output Class Initialized
INFO - 2021-12-08 08:06:36 --> Security Class Initialized
DEBUG - 2021-12-08 08:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:06:36 --> Input Class Initialized
INFO - 2021-12-08 08:06:36 --> Language Class Initialized
INFO - 2021-12-08 08:06:36 --> Language Class Initialized
INFO - 2021-12-08 08:06:36 --> Config Class Initialized
INFO - 2021-12-08 08:06:36 --> Loader Class Initialized
INFO - 2021-12-08 08:06:36 --> Helper loaded: url_helper
INFO - 2021-12-08 08:06:36 --> Helper loaded: file_helper
INFO - 2021-12-08 08:06:36 --> Helper loaded: form_helper
INFO - 2021-12-08 08:06:36 --> Helper loaded: my_helper
INFO - 2021-12-08 08:06:36 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:06:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:06:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:06:36 --> Controller Class Initialized
INFO - 2021-12-08 08:06:55 --> Config Class Initialized
INFO - 2021-12-08 08:06:55 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:06:55 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:06:55 --> Utf8 Class Initialized
INFO - 2021-12-08 08:06:55 --> URI Class Initialized
INFO - 2021-12-08 08:06:55 --> Router Class Initialized
INFO - 2021-12-08 08:06:55 --> Output Class Initialized
INFO - 2021-12-08 08:06:55 --> Security Class Initialized
DEBUG - 2021-12-08 08:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:06:55 --> Input Class Initialized
INFO - 2021-12-08 08:06:55 --> Language Class Initialized
INFO - 2021-12-08 08:06:55 --> Language Class Initialized
INFO - 2021-12-08 08:06:55 --> Config Class Initialized
INFO - 2021-12-08 08:06:55 --> Loader Class Initialized
INFO - 2021-12-08 08:06:55 --> Helper loaded: url_helper
INFO - 2021-12-08 08:06:55 --> Helper loaded: file_helper
INFO - 2021-12-08 08:06:55 --> Helper loaded: form_helper
INFO - 2021-12-08 08:06:55 --> Helper loaded: my_helper
INFO - 2021-12-08 08:06:55 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:06:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:06:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:06:55 --> Controller Class Initialized
INFO - 2021-12-08 08:06:55 --> Helper loaded: cookie_helper
INFO - 2021-12-08 08:06:55 --> Config Class Initialized
INFO - 2021-12-08 08:06:55 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:06:55 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:06:55 --> Utf8 Class Initialized
INFO - 2021-12-08 08:06:55 --> URI Class Initialized
INFO - 2021-12-08 08:06:55 --> Router Class Initialized
INFO - 2021-12-08 08:06:55 --> Output Class Initialized
INFO - 2021-12-08 08:06:55 --> Security Class Initialized
DEBUG - 2021-12-08 08:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:06:55 --> Input Class Initialized
INFO - 2021-12-08 08:06:55 --> Language Class Initialized
INFO - 2021-12-08 08:06:55 --> Language Class Initialized
INFO - 2021-12-08 08:06:55 --> Config Class Initialized
INFO - 2021-12-08 08:06:55 --> Loader Class Initialized
INFO - 2021-12-08 08:06:55 --> Helper loaded: url_helper
INFO - 2021-12-08 08:06:55 --> Helper loaded: file_helper
INFO - 2021-12-08 08:06:55 --> Helper loaded: form_helper
INFO - 2021-12-08 08:06:55 --> Helper loaded: my_helper
INFO - 2021-12-08 08:06:55 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:06:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:06:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:06:55 --> Controller Class Initialized
DEBUG - 2021-12-08 08:06:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-08 08:06:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 08:06:55 --> Final output sent to browser
DEBUG - 2021-12-08 08:06:55 --> Total execution time: 0.0360
INFO - 2021-12-08 08:07:07 --> Config Class Initialized
INFO - 2021-12-08 08:07:07 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:07:07 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:07:07 --> Utf8 Class Initialized
INFO - 2021-12-08 08:07:07 --> URI Class Initialized
INFO - 2021-12-08 08:07:07 --> Router Class Initialized
INFO - 2021-12-08 08:07:07 --> Output Class Initialized
INFO - 2021-12-08 08:07:07 --> Security Class Initialized
DEBUG - 2021-12-08 08:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:07:07 --> Input Class Initialized
INFO - 2021-12-08 08:07:07 --> Language Class Initialized
INFO - 2021-12-08 08:07:07 --> Language Class Initialized
INFO - 2021-12-08 08:07:07 --> Config Class Initialized
INFO - 2021-12-08 08:07:07 --> Loader Class Initialized
INFO - 2021-12-08 08:07:07 --> Helper loaded: url_helper
INFO - 2021-12-08 08:07:07 --> Helper loaded: file_helper
INFO - 2021-12-08 08:07:07 --> Helper loaded: form_helper
INFO - 2021-12-08 08:07:07 --> Helper loaded: my_helper
INFO - 2021-12-08 08:07:07 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:07:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:07:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:07:07 --> Controller Class Initialized
INFO - 2021-12-08 08:07:07 --> Final output sent to browser
DEBUG - 2021-12-08 08:07:07 --> Total execution time: 0.0420
INFO - 2021-12-08 08:07:14 --> Config Class Initialized
INFO - 2021-12-08 08:07:14 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:07:14 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:07:14 --> Utf8 Class Initialized
INFO - 2021-12-08 08:07:14 --> URI Class Initialized
INFO - 2021-12-08 08:07:14 --> Router Class Initialized
INFO - 2021-12-08 08:07:14 --> Output Class Initialized
INFO - 2021-12-08 08:07:14 --> Security Class Initialized
DEBUG - 2021-12-08 08:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:07:14 --> Input Class Initialized
INFO - 2021-12-08 08:07:14 --> Language Class Initialized
INFO - 2021-12-08 08:07:14 --> Language Class Initialized
INFO - 2021-12-08 08:07:14 --> Config Class Initialized
INFO - 2021-12-08 08:07:14 --> Loader Class Initialized
INFO - 2021-12-08 08:07:14 --> Helper loaded: url_helper
INFO - 2021-12-08 08:07:14 --> Helper loaded: file_helper
INFO - 2021-12-08 08:07:14 --> Helper loaded: form_helper
INFO - 2021-12-08 08:07:14 --> Helper loaded: my_helper
INFO - 2021-12-08 08:07:14 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:07:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:07:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:07:14 --> Controller Class Initialized
INFO - 2021-12-08 08:07:14 --> Helper loaded: cookie_helper
INFO - 2021-12-08 08:07:14 --> Final output sent to browser
DEBUG - 2021-12-08 08:07:14 --> Total execution time: 0.0460
INFO - 2021-12-08 08:07:17 --> Config Class Initialized
INFO - 2021-12-08 08:07:17 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:07:17 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:07:17 --> Utf8 Class Initialized
INFO - 2021-12-08 08:07:17 --> URI Class Initialized
INFO - 2021-12-08 08:07:17 --> Router Class Initialized
INFO - 2021-12-08 08:07:17 --> Output Class Initialized
INFO - 2021-12-08 08:07:17 --> Security Class Initialized
DEBUG - 2021-12-08 08:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:07:17 --> Input Class Initialized
INFO - 2021-12-08 08:07:17 --> Language Class Initialized
INFO - 2021-12-08 08:07:17 --> Language Class Initialized
INFO - 2021-12-08 08:07:17 --> Config Class Initialized
INFO - 2021-12-08 08:07:17 --> Loader Class Initialized
INFO - 2021-12-08 08:07:17 --> Helper loaded: url_helper
INFO - 2021-12-08 08:07:17 --> Helper loaded: file_helper
INFO - 2021-12-08 08:07:17 --> Helper loaded: form_helper
INFO - 2021-12-08 08:07:17 --> Helper loaded: my_helper
INFO - 2021-12-08 08:07:17 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:07:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:07:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:07:17 --> Controller Class Initialized
DEBUG - 2021-12-08 08:07:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-08 08:07:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 08:07:17 --> Final output sent to browser
DEBUG - 2021-12-08 08:07:17 --> Total execution time: 0.1570
INFO - 2021-12-08 08:07:24 --> Config Class Initialized
INFO - 2021-12-08 08:07:24 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:07:24 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:07:24 --> Utf8 Class Initialized
INFO - 2021-12-08 08:07:24 --> URI Class Initialized
INFO - 2021-12-08 08:07:24 --> Router Class Initialized
INFO - 2021-12-08 08:07:24 --> Output Class Initialized
INFO - 2021-12-08 08:07:24 --> Security Class Initialized
DEBUG - 2021-12-08 08:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:07:24 --> Input Class Initialized
INFO - 2021-12-08 08:07:24 --> Language Class Initialized
INFO - 2021-12-08 08:07:24 --> Language Class Initialized
INFO - 2021-12-08 08:07:24 --> Config Class Initialized
INFO - 2021-12-08 08:07:24 --> Loader Class Initialized
INFO - 2021-12-08 08:07:24 --> Helper loaded: url_helper
INFO - 2021-12-08 08:07:24 --> Helper loaded: file_helper
INFO - 2021-12-08 08:07:24 --> Helper loaded: form_helper
INFO - 2021-12-08 08:07:24 --> Helper loaded: my_helper
INFO - 2021-12-08 08:07:24 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:07:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:07:24 --> Controller Class Initialized
DEBUG - 2021-12-08 08:07:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-08 08:07:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 08:07:24 --> Final output sent to browser
DEBUG - 2021-12-08 08:07:24 --> Total execution time: 0.1440
INFO - 2021-12-08 08:07:49 --> Config Class Initialized
INFO - 2021-12-08 08:07:49 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:07:49 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:07:49 --> Utf8 Class Initialized
INFO - 2021-12-08 08:07:49 --> URI Class Initialized
INFO - 2021-12-08 08:07:49 --> Router Class Initialized
INFO - 2021-12-08 08:07:49 --> Output Class Initialized
INFO - 2021-12-08 08:07:49 --> Security Class Initialized
DEBUG - 2021-12-08 08:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:07:49 --> Input Class Initialized
INFO - 2021-12-08 08:07:49 --> Language Class Initialized
INFO - 2021-12-08 08:07:49 --> Language Class Initialized
INFO - 2021-12-08 08:07:49 --> Config Class Initialized
INFO - 2021-12-08 08:07:49 --> Loader Class Initialized
INFO - 2021-12-08 08:07:49 --> Helper loaded: url_helper
INFO - 2021-12-08 08:07:49 --> Helper loaded: file_helper
INFO - 2021-12-08 08:07:49 --> Helper loaded: form_helper
INFO - 2021-12-08 08:07:49 --> Helper loaded: my_helper
INFO - 2021-12-08 08:07:49 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:07:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:07:49 --> Controller Class Initialized
DEBUG - 2021-12-08 08:07:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-12-08 08:07:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 08:07:49 --> Final output sent to browser
DEBUG - 2021-12-08 08:07:49 --> Total execution time: 0.0510
INFO - 2021-12-08 08:07:54 --> Config Class Initialized
INFO - 2021-12-08 08:07:54 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:07:54 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:07:54 --> Utf8 Class Initialized
INFO - 2021-12-08 08:07:54 --> URI Class Initialized
INFO - 2021-12-08 08:07:54 --> Router Class Initialized
INFO - 2021-12-08 08:07:54 --> Output Class Initialized
INFO - 2021-12-08 08:07:54 --> Security Class Initialized
DEBUG - 2021-12-08 08:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:07:54 --> Input Class Initialized
INFO - 2021-12-08 08:07:54 --> Language Class Initialized
INFO - 2021-12-08 08:07:54 --> Language Class Initialized
INFO - 2021-12-08 08:07:54 --> Config Class Initialized
INFO - 2021-12-08 08:07:54 --> Loader Class Initialized
INFO - 2021-12-08 08:07:54 --> Helper loaded: url_helper
INFO - 2021-12-08 08:07:54 --> Helper loaded: file_helper
INFO - 2021-12-08 08:07:54 --> Helper loaded: form_helper
INFO - 2021-12-08 08:07:54 --> Helper loaded: my_helper
INFO - 2021-12-08 08:07:54 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:07:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:07:54 --> Controller Class Initialized
DEBUG - 2021-12-08 08:07:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-12-08 08:07:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 08:07:54 --> Final output sent to browser
DEBUG - 2021-12-08 08:07:54 --> Total execution time: 0.0610
INFO - 2021-12-08 08:08:16 --> Config Class Initialized
INFO - 2021-12-08 08:08:16 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:08:16 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:08:16 --> Utf8 Class Initialized
INFO - 2021-12-08 08:08:16 --> URI Class Initialized
INFO - 2021-12-08 08:08:16 --> Router Class Initialized
INFO - 2021-12-08 08:08:16 --> Output Class Initialized
INFO - 2021-12-08 08:08:16 --> Security Class Initialized
DEBUG - 2021-12-08 08:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:08:16 --> Input Class Initialized
INFO - 2021-12-08 08:08:16 --> Language Class Initialized
INFO - 2021-12-08 08:08:16 --> Language Class Initialized
INFO - 2021-12-08 08:08:16 --> Config Class Initialized
INFO - 2021-12-08 08:08:16 --> Loader Class Initialized
INFO - 2021-12-08 08:08:16 --> Helper loaded: url_helper
INFO - 2021-12-08 08:08:16 --> Helper loaded: file_helper
INFO - 2021-12-08 08:08:16 --> Helper loaded: form_helper
INFO - 2021-12-08 08:08:16 --> Helper loaded: my_helper
INFO - 2021-12-08 08:08:16 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:08:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:08:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:08:16 --> Controller Class Initialized
DEBUG - 2021-12-08 08:08:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-08 08:08:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 08:08:16 --> Final output sent to browser
DEBUG - 2021-12-08 08:08:16 --> Total execution time: 0.0770
INFO - 2021-12-08 08:33:08 --> Config Class Initialized
INFO - 2021-12-08 08:33:08 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:33:08 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:33:08 --> Utf8 Class Initialized
INFO - 2021-12-08 08:33:08 --> URI Class Initialized
INFO - 2021-12-08 08:33:08 --> Router Class Initialized
INFO - 2021-12-08 08:33:08 --> Output Class Initialized
INFO - 2021-12-08 08:33:08 --> Security Class Initialized
DEBUG - 2021-12-08 08:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:33:08 --> Input Class Initialized
INFO - 2021-12-08 08:33:08 --> Language Class Initialized
INFO - 2021-12-08 08:33:08 --> Language Class Initialized
INFO - 2021-12-08 08:33:08 --> Config Class Initialized
INFO - 2021-12-08 08:33:08 --> Loader Class Initialized
INFO - 2021-12-08 08:33:08 --> Helper loaded: url_helper
INFO - 2021-12-08 08:33:08 --> Helper loaded: file_helper
INFO - 2021-12-08 08:33:08 --> Helper loaded: form_helper
INFO - 2021-12-08 08:33:08 --> Helper loaded: my_helper
INFO - 2021-12-08 08:33:08 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:33:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:33:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:33:08 --> Controller Class Initialized
INFO - 2021-12-08 08:33:08 --> Final output sent to browser
DEBUG - 2021-12-08 08:33:08 --> Total execution time: 0.0700
INFO - 2021-12-08 08:33:26 --> Config Class Initialized
INFO - 2021-12-08 08:33:26 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:33:26 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:33:26 --> Utf8 Class Initialized
INFO - 2021-12-08 08:33:26 --> URI Class Initialized
INFO - 2021-12-08 08:33:26 --> Router Class Initialized
INFO - 2021-12-08 08:33:26 --> Output Class Initialized
INFO - 2021-12-08 08:33:26 --> Security Class Initialized
DEBUG - 2021-12-08 08:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:33:26 --> Input Class Initialized
INFO - 2021-12-08 08:33:26 --> Language Class Initialized
INFO - 2021-12-08 08:33:26 --> Language Class Initialized
INFO - 2021-12-08 08:33:26 --> Config Class Initialized
INFO - 2021-12-08 08:33:26 --> Loader Class Initialized
INFO - 2021-12-08 08:33:26 --> Helper loaded: url_helper
INFO - 2021-12-08 08:33:26 --> Helper loaded: file_helper
INFO - 2021-12-08 08:33:26 --> Helper loaded: form_helper
INFO - 2021-12-08 08:33:26 --> Helper loaded: my_helper
INFO - 2021-12-08 08:33:26 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:33:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:33:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:33:26 --> Controller Class Initialized
INFO - 2021-12-08 08:33:26 --> Helper loaded: cookie_helper
INFO - 2021-12-08 08:33:26 --> Config Class Initialized
INFO - 2021-12-08 08:33:26 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:33:26 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:33:26 --> Utf8 Class Initialized
INFO - 2021-12-08 08:33:26 --> URI Class Initialized
INFO - 2021-12-08 08:33:26 --> Router Class Initialized
INFO - 2021-12-08 08:33:26 --> Output Class Initialized
INFO - 2021-12-08 08:33:26 --> Security Class Initialized
DEBUG - 2021-12-08 08:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:33:26 --> Input Class Initialized
INFO - 2021-12-08 08:33:26 --> Language Class Initialized
INFO - 2021-12-08 08:33:26 --> Language Class Initialized
INFO - 2021-12-08 08:33:26 --> Config Class Initialized
INFO - 2021-12-08 08:33:26 --> Loader Class Initialized
INFO - 2021-12-08 08:33:26 --> Helper loaded: url_helper
INFO - 2021-12-08 08:33:26 --> Helper loaded: file_helper
INFO - 2021-12-08 08:33:26 --> Helper loaded: form_helper
INFO - 2021-12-08 08:33:26 --> Helper loaded: my_helper
INFO - 2021-12-08 08:33:26 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:33:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:33:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:33:26 --> Controller Class Initialized
DEBUG - 2021-12-08 08:33:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-08 08:33:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 08:33:26 --> Final output sent to browser
DEBUG - 2021-12-08 08:33:26 --> Total execution time: 0.0350
INFO - 2021-12-08 08:33:38 --> Config Class Initialized
INFO - 2021-12-08 08:33:38 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:33:38 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:33:38 --> Utf8 Class Initialized
INFO - 2021-12-08 08:33:38 --> URI Class Initialized
INFO - 2021-12-08 08:33:38 --> Router Class Initialized
INFO - 2021-12-08 08:33:38 --> Output Class Initialized
INFO - 2021-12-08 08:33:38 --> Security Class Initialized
DEBUG - 2021-12-08 08:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:33:38 --> Input Class Initialized
INFO - 2021-12-08 08:33:38 --> Language Class Initialized
INFO - 2021-12-08 08:33:38 --> Language Class Initialized
INFO - 2021-12-08 08:33:38 --> Config Class Initialized
INFO - 2021-12-08 08:33:38 --> Loader Class Initialized
INFO - 2021-12-08 08:33:38 --> Helper loaded: url_helper
INFO - 2021-12-08 08:33:38 --> Helper loaded: file_helper
INFO - 2021-12-08 08:33:38 --> Helper loaded: form_helper
INFO - 2021-12-08 08:33:38 --> Helper loaded: my_helper
INFO - 2021-12-08 08:33:38 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:33:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:33:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:33:38 --> Controller Class Initialized
INFO - 2021-12-08 08:33:38 --> Helper loaded: cookie_helper
INFO - 2021-12-08 08:33:38 --> Final output sent to browser
DEBUG - 2021-12-08 08:33:38 --> Total execution time: 0.0530
INFO - 2021-12-08 08:33:40 --> Config Class Initialized
INFO - 2021-12-08 08:33:40 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:33:40 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:33:40 --> Utf8 Class Initialized
INFO - 2021-12-08 08:33:40 --> URI Class Initialized
INFO - 2021-12-08 08:33:40 --> Router Class Initialized
INFO - 2021-12-08 08:33:40 --> Output Class Initialized
INFO - 2021-12-08 08:33:40 --> Security Class Initialized
DEBUG - 2021-12-08 08:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:33:40 --> Input Class Initialized
INFO - 2021-12-08 08:33:40 --> Language Class Initialized
INFO - 2021-12-08 08:33:40 --> Language Class Initialized
INFO - 2021-12-08 08:33:40 --> Config Class Initialized
INFO - 2021-12-08 08:33:40 --> Loader Class Initialized
INFO - 2021-12-08 08:33:40 --> Helper loaded: url_helper
INFO - 2021-12-08 08:33:40 --> Helper loaded: file_helper
INFO - 2021-12-08 08:33:40 --> Helper loaded: form_helper
INFO - 2021-12-08 08:33:40 --> Helper loaded: my_helper
INFO - 2021-12-08 08:33:40 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:33:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:33:40 --> Controller Class Initialized
DEBUG - 2021-12-08 08:33:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-08 08:33:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 08:33:40 --> Final output sent to browser
DEBUG - 2021-12-08 08:33:40 --> Total execution time: 0.2220
INFO - 2021-12-08 08:33:44 --> Config Class Initialized
INFO - 2021-12-08 08:33:44 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:33:44 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:33:44 --> Utf8 Class Initialized
INFO - 2021-12-08 08:33:44 --> URI Class Initialized
INFO - 2021-12-08 08:33:44 --> Router Class Initialized
INFO - 2021-12-08 08:33:44 --> Output Class Initialized
INFO - 2021-12-08 08:33:44 --> Security Class Initialized
DEBUG - 2021-12-08 08:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:33:44 --> Input Class Initialized
INFO - 2021-12-08 08:33:44 --> Language Class Initialized
INFO - 2021-12-08 08:33:44 --> Language Class Initialized
INFO - 2021-12-08 08:33:44 --> Config Class Initialized
INFO - 2021-12-08 08:33:44 --> Loader Class Initialized
INFO - 2021-12-08 08:33:44 --> Helper loaded: url_helper
INFO - 2021-12-08 08:33:44 --> Helper loaded: file_helper
INFO - 2021-12-08 08:33:44 --> Helper loaded: form_helper
INFO - 2021-12-08 08:33:44 --> Helper loaded: my_helper
INFO - 2021-12-08 08:33:44 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:33:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:33:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:33:44 --> Controller Class Initialized
DEBUG - 2021-12-08 08:33:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-08 08:33:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 08:33:44 --> Final output sent to browser
DEBUG - 2021-12-08 08:33:44 --> Total execution time: 0.1110
INFO - 2021-12-08 08:33:54 --> Config Class Initialized
INFO - 2021-12-08 08:33:54 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:33:54 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:33:54 --> Utf8 Class Initialized
INFO - 2021-12-08 08:33:54 --> URI Class Initialized
INFO - 2021-12-08 08:33:54 --> Router Class Initialized
INFO - 2021-12-08 08:33:54 --> Output Class Initialized
INFO - 2021-12-08 08:33:54 --> Security Class Initialized
DEBUG - 2021-12-08 08:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:33:54 --> Input Class Initialized
INFO - 2021-12-08 08:33:54 --> Language Class Initialized
INFO - 2021-12-08 08:33:54 --> Language Class Initialized
INFO - 2021-12-08 08:33:54 --> Config Class Initialized
INFO - 2021-12-08 08:33:54 --> Loader Class Initialized
INFO - 2021-12-08 08:33:54 --> Helper loaded: url_helper
INFO - 2021-12-08 08:33:54 --> Helper loaded: file_helper
INFO - 2021-12-08 08:33:54 --> Helper loaded: form_helper
INFO - 2021-12-08 08:33:54 --> Helper loaded: my_helper
INFO - 2021-12-08 08:33:54 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:33:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:33:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:33:54 --> Controller Class Initialized
DEBUG - 2021-12-08 08:33:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-12-08 08:33:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 08:33:54 --> Final output sent to browser
DEBUG - 2021-12-08 08:33:54 --> Total execution time: 0.0580
INFO - 2021-12-08 08:34:36 --> Config Class Initialized
INFO - 2021-12-08 08:34:36 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:34:36 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:34:36 --> Utf8 Class Initialized
INFO - 2021-12-08 08:34:36 --> URI Class Initialized
INFO - 2021-12-08 08:34:36 --> Router Class Initialized
INFO - 2021-12-08 08:34:36 --> Output Class Initialized
INFO - 2021-12-08 08:34:36 --> Security Class Initialized
DEBUG - 2021-12-08 08:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:34:36 --> Input Class Initialized
INFO - 2021-12-08 08:34:36 --> Language Class Initialized
INFO - 2021-12-08 08:34:36 --> Language Class Initialized
INFO - 2021-12-08 08:34:36 --> Config Class Initialized
INFO - 2021-12-08 08:34:36 --> Loader Class Initialized
INFO - 2021-12-08 08:34:36 --> Helper loaded: url_helper
INFO - 2021-12-08 08:34:36 --> Helper loaded: file_helper
INFO - 2021-12-08 08:34:36 --> Helper loaded: form_helper
INFO - 2021-12-08 08:34:36 --> Helper loaded: my_helper
INFO - 2021-12-08 08:34:36 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:34:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:34:36 --> Controller Class Initialized
DEBUG - 2021-12-08 08:34:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-08 08:34:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 08:34:36 --> Final output sent to browser
DEBUG - 2021-12-08 08:34:36 --> Total execution time: 0.0840
INFO - 2021-12-08 08:35:18 --> Config Class Initialized
INFO - 2021-12-08 08:35:18 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:35:18 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:35:18 --> Utf8 Class Initialized
INFO - 2021-12-08 08:35:18 --> URI Class Initialized
INFO - 2021-12-08 08:35:18 --> Router Class Initialized
INFO - 2021-12-08 08:35:18 --> Output Class Initialized
INFO - 2021-12-08 08:35:18 --> Security Class Initialized
DEBUG - 2021-12-08 08:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:35:18 --> Input Class Initialized
INFO - 2021-12-08 08:35:18 --> Language Class Initialized
INFO - 2021-12-08 08:35:18 --> Language Class Initialized
INFO - 2021-12-08 08:35:18 --> Config Class Initialized
INFO - 2021-12-08 08:35:18 --> Loader Class Initialized
INFO - 2021-12-08 08:35:18 --> Helper loaded: url_helper
INFO - 2021-12-08 08:35:18 --> Helper loaded: file_helper
INFO - 2021-12-08 08:35:18 --> Helper loaded: form_helper
INFO - 2021-12-08 08:35:18 --> Helper loaded: my_helper
INFO - 2021-12-08 08:35:18 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:35:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:35:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:35:18 --> Controller Class Initialized
INFO - 2021-12-08 08:35:18 --> Final output sent to browser
DEBUG - 2021-12-08 08:35:18 --> Total execution time: 0.1250
INFO - 2021-12-08 08:35:32 --> Config Class Initialized
INFO - 2021-12-08 08:35:32 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:35:32 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:35:32 --> Utf8 Class Initialized
INFO - 2021-12-08 08:35:32 --> URI Class Initialized
INFO - 2021-12-08 08:35:32 --> Router Class Initialized
INFO - 2021-12-08 08:35:32 --> Output Class Initialized
INFO - 2021-12-08 08:35:32 --> Security Class Initialized
DEBUG - 2021-12-08 08:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:35:32 --> Input Class Initialized
INFO - 2021-12-08 08:35:32 --> Language Class Initialized
INFO - 2021-12-08 08:35:32 --> Language Class Initialized
INFO - 2021-12-08 08:35:32 --> Config Class Initialized
INFO - 2021-12-08 08:35:32 --> Loader Class Initialized
INFO - 2021-12-08 08:35:32 --> Helper loaded: url_helper
INFO - 2021-12-08 08:35:32 --> Helper loaded: file_helper
INFO - 2021-12-08 08:35:32 --> Helper loaded: form_helper
INFO - 2021-12-08 08:35:32 --> Helper loaded: my_helper
INFO - 2021-12-08 08:35:32 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:35:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:35:32 --> Controller Class Initialized
DEBUG - 2021-12-08 08:35:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-12-08 08:35:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 08:35:32 --> Final output sent to browser
DEBUG - 2021-12-08 08:35:32 --> Total execution time: 0.0620
INFO - 2021-12-08 08:49:48 --> Config Class Initialized
INFO - 2021-12-08 08:49:48 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:49:48 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:49:48 --> Utf8 Class Initialized
INFO - 2021-12-08 08:49:48 --> URI Class Initialized
INFO - 2021-12-08 08:49:48 --> Router Class Initialized
INFO - 2021-12-08 08:49:48 --> Output Class Initialized
INFO - 2021-12-08 08:49:48 --> Security Class Initialized
DEBUG - 2021-12-08 08:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:49:48 --> Input Class Initialized
INFO - 2021-12-08 08:49:48 --> Language Class Initialized
INFO - 2021-12-08 08:49:48 --> Language Class Initialized
INFO - 2021-12-08 08:49:48 --> Config Class Initialized
INFO - 2021-12-08 08:49:48 --> Loader Class Initialized
INFO - 2021-12-08 08:49:48 --> Helper loaded: url_helper
INFO - 2021-12-08 08:49:48 --> Helper loaded: file_helper
INFO - 2021-12-08 08:49:48 --> Helper loaded: form_helper
INFO - 2021-12-08 08:49:48 --> Helper loaded: my_helper
INFO - 2021-12-08 08:49:48 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:49:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:49:48 --> Controller Class Initialized
INFO - 2021-12-08 08:49:48 --> Final output sent to browser
DEBUG - 2021-12-08 08:49:48 --> Total execution time: 0.0840
INFO - 2021-12-08 08:49:54 --> Config Class Initialized
INFO - 2021-12-08 08:49:54 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:49:54 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:49:54 --> Utf8 Class Initialized
INFO - 2021-12-08 08:49:54 --> URI Class Initialized
INFO - 2021-12-08 08:49:54 --> Router Class Initialized
INFO - 2021-12-08 08:49:54 --> Output Class Initialized
INFO - 2021-12-08 08:49:54 --> Security Class Initialized
DEBUG - 2021-12-08 08:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:49:54 --> Input Class Initialized
INFO - 2021-12-08 08:49:54 --> Language Class Initialized
INFO - 2021-12-08 08:49:54 --> Language Class Initialized
INFO - 2021-12-08 08:49:54 --> Config Class Initialized
INFO - 2021-12-08 08:49:54 --> Loader Class Initialized
INFO - 2021-12-08 08:49:54 --> Helper loaded: url_helper
INFO - 2021-12-08 08:49:54 --> Helper loaded: file_helper
INFO - 2021-12-08 08:49:54 --> Helper loaded: form_helper
INFO - 2021-12-08 08:49:54 --> Helper loaded: my_helper
INFO - 2021-12-08 08:49:54 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:49:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:49:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:49:54 --> Controller Class Initialized
DEBUG - 2021-12-08 08:49:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-08 08:49:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 08:49:54 --> Final output sent to browser
DEBUG - 2021-12-08 08:49:54 --> Total execution time: 0.0970
INFO - 2021-12-08 08:50:00 --> Config Class Initialized
INFO - 2021-12-08 08:50:00 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:50:00 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:50:00 --> Utf8 Class Initialized
INFO - 2021-12-08 08:50:00 --> URI Class Initialized
INFO - 2021-12-08 08:50:00 --> Router Class Initialized
INFO - 2021-12-08 08:50:00 --> Output Class Initialized
INFO - 2021-12-08 08:50:00 --> Security Class Initialized
DEBUG - 2021-12-08 08:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:50:00 --> Input Class Initialized
INFO - 2021-12-08 08:50:00 --> Language Class Initialized
INFO - 2021-12-08 08:50:00 --> Language Class Initialized
INFO - 2021-12-08 08:50:00 --> Config Class Initialized
INFO - 2021-12-08 08:50:00 --> Loader Class Initialized
INFO - 2021-12-08 08:50:00 --> Helper loaded: url_helper
INFO - 2021-12-08 08:50:00 --> Helper loaded: file_helper
INFO - 2021-12-08 08:50:00 --> Helper loaded: form_helper
INFO - 2021-12-08 08:50:00 --> Helper loaded: my_helper
INFO - 2021-12-08 08:50:00 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:50:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:50:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:50:00 --> Controller Class Initialized
DEBUG - 2021-12-08 08:50:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-12-08 08:50:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 08:50:00 --> Final output sent to browser
DEBUG - 2021-12-08 08:50:00 --> Total execution time: 0.0460
INFO - 2021-12-08 08:50:02 --> Config Class Initialized
INFO - 2021-12-08 08:50:02 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:50:02 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:50:02 --> Utf8 Class Initialized
INFO - 2021-12-08 08:50:02 --> URI Class Initialized
INFO - 2021-12-08 08:50:02 --> Router Class Initialized
INFO - 2021-12-08 08:50:02 --> Output Class Initialized
INFO - 2021-12-08 08:50:02 --> Security Class Initialized
DEBUG - 2021-12-08 08:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:50:02 --> Input Class Initialized
INFO - 2021-12-08 08:50:02 --> Language Class Initialized
INFO - 2021-12-08 08:50:02 --> Language Class Initialized
INFO - 2021-12-08 08:50:02 --> Config Class Initialized
INFO - 2021-12-08 08:50:02 --> Loader Class Initialized
INFO - 2021-12-08 08:50:02 --> Helper loaded: url_helper
INFO - 2021-12-08 08:50:02 --> Helper loaded: file_helper
INFO - 2021-12-08 08:50:02 --> Helper loaded: form_helper
INFO - 2021-12-08 08:50:02 --> Helper loaded: my_helper
INFO - 2021-12-08 08:50:02 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:50:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:50:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:50:02 --> Controller Class Initialized
DEBUG - 2021-12-08 08:50:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-12-08 08:50:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 08:50:02 --> Final output sent to browser
DEBUG - 2021-12-08 08:50:02 --> Total execution time: 0.0510
INFO - 2021-12-08 08:50:08 --> Config Class Initialized
INFO - 2021-12-08 08:50:08 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:50:08 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:50:08 --> Utf8 Class Initialized
INFO - 2021-12-08 08:50:08 --> URI Class Initialized
INFO - 2021-12-08 08:50:08 --> Router Class Initialized
INFO - 2021-12-08 08:50:08 --> Output Class Initialized
INFO - 2021-12-08 08:50:08 --> Security Class Initialized
DEBUG - 2021-12-08 08:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:50:08 --> Input Class Initialized
INFO - 2021-12-08 08:50:08 --> Language Class Initialized
INFO - 2021-12-08 08:50:08 --> Language Class Initialized
INFO - 2021-12-08 08:50:08 --> Config Class Initialized
INFO - 2021-12-08 08:50:08 --> Loader Class Initialized
INFO - 2021-12-08 08:50:08 --> Helper loaded: url_helper
INFO - 2021-12-08 08:50:08 --> Helper loaded: file_helper
INFO - 2021-12-08 08:50:08 --> Helper loaded: form_helper
INFO - 2021-12-08 08:50:08 --> Helper loaded: my_helper
INFO - 2021-12-08 08:50:08 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:50:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:50:08 --> Controller Class Initialized
INFO - 2021-12-08 08:50:08 --> Final output sent to browser
DEBUG - 2021-12-08 08:50:08 --> Total execution time: 0.0540
INFO - 2021-12-08 08:50:29 --> Config Class Initialized
INFO - 2021-12-08 08:50:29 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:50:29 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:50:29 --> Utf8 Class Initialized
INFO - 2021-12-08 08:50:29 --> URI Class Initialized
INFO - 2021-12-08 08:50:29 --> Router Class Initialized
INFO - 2021-12-08 08:50:29 --> Output Class Initialized
INFO - 2021-12-08 08:50:29 --> Security Class Initialized
DEBUG - 2021-12-08 08:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:50:29 --> Input Class Initialized
INFO - 2021-12-08 08:50:29 --> Language Class Initialized
INFO - 2021-12-08 08:50:29 --> Language Class Initialized
INFO - 2021-12-08 08:50:29 --> Config Class Initialized
INFO - 2021-12-08 08:50:29 --> Loader Class Initialized
INFO - 2021-12-08 08:50:29 --> Helper loaded: url_helper
INFO - 2021-12-08 08:50:29 --> Helper loaded: file_helper
INFO - 2021-12-08 08:50:29 --> Helper loaded: form_helper
INFO - 2021-12-08 08:50:29 --> Helper loaded: my_helper
INFO - 2021-12-08 08:50:29 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:50:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:50:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:50:29 --> Controller Class Initialized
INFO - 2021-12-08 08:50:29 --> Final output sent to browser
DEBUG - 2021-12-08 08:50:29 --> Total execution time: 0.0480
INFO - 2021-12-08 08:50:31 --> Config Class Initialized
INFO - 2021-12-08 08:50:31 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:50:31 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:50:31 --> Utf8 Class Initialized
INFO - 2021-12-08 08:50:31 --> URI Class Initialized
INFO - 2021-12-08 08:50:31 --> Router Class Initialized
INFO - 2021-12-08 08:50:31 --> Output Class Initialized
INFO - 2021-12-08 08:50:31 --> Security Class Initialized
DEBUG - 2021-12-08 08:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:50:31 --> Input Class Initialized
INFO - 2021-12-08 08:50:31 --> Language Class Initialized
INFO - 2021-12-08 08:50:31 --> Language Class Initialized
INFO - 2021-12-08 08:50:31 --> Config Class Initialized
INFO - 2021-12-08 08:50:31 --> Loader Class Initialized
INFO - 2021-12-08 08:50:31 --> Helper loaded: url_helper
INFO - 2021-12-08 08:50:31 --> Helper loaded: file_helper
INFO - 2021-12-08 08:50:31 --> Helper loaded: form_helper
INFO - 2021-12-08 08:50:31 --> Helper loaded: my_helper
INFO - 2021-12-08 08:50:31 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:50:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:50:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:50:31 --> Controller Class Initialized
INFO - 2021-12-08 08:50:31 --> Final output sent to browser
DEBUG - 2021-12-08 08:50:31 --> Total execution time: 0.0590
INFO - 2021-12-08 08:50:34 --> Config Class Initialized
INFO - 2021-12-08 08:50:34 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:50:34 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:50:34 --> Utf8 Class Initialized
INFO - 2021-12-08 08:50:34 --> URI Class Initialized
INFO - 2021-12-08 08:50:34 --> Router Class Initialized
INFO - 2021-12-08 08:50:34 --> Output Class Initialized
INFO - 2021-12-08 08:50:34 --> Security Class Initialized
DEBUG - 2021-12-08 08:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:50:34 --> Input Class Initialized
INFO - 2021-12-08 08:50:34 --> Language Class Initialized
INFO - 2021-12-08 08:50:34 --> Language Class Initialized
INFO - 2021-12-08 08:50:34 --> Config Class Initialized
INFO - 2021-12-08 08:50:34 --> Loader Class Initialized
INFO - 2021-12-08 08:50:34 --> Helper loaded: url_helper
INFO - 2021-12-08 08:50:34 --> Helper loaded: file_helper
INFO - 2021-12-08 08:50:34 --> Helper loaded: form_helper
INFO - 2021-12-08 08:50:34 --> Helper loaded: my_helper
INFO - 2021-12-08 08:50:34 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:50:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:50:34 --> Controller Class Initialized
INFO - 2021-12-08 08:50:34 --> Final output sent to browser
DEBUG - 2021-12-08 08:50:34 --> Total execution time: 0.0570
INFO - 2021-12-08 08:50:36 --> Config Class Initialized
INFO - 2021-12-08 08:50:36 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:50:36 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:50:36 --> Utf8 Class Initialized
INFO - 2021-12-08 08:50:36 --> URI Class Initialized
INFO - 2021-12-08 08:50:36 --> Router Class Initialized
INFO - 2021-12-08 08:50:36 --> Output Class Initialized
INFO - 2021-12-08 08:50:36 --> Security Class Initialized
DEBUG - 2021-12-08 08:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:50:36 --> Input Class Initialized
INFO - 2021-12-08 08:50:36 --> Language Class Initialized
INFO - 2021-12-08 08:50:36 --> Language Class Initialized
INFO - 2021-12-08 08:50:36 --> Config Class Initialized
INFO - 2021-12-08 08:50:36 --> Loader Class Initialized
INFO - 2021-12-08 08:50:36 --> Helper loaded: url_helper
INFO - 2021-12-08 08:50:36 --> Helper loaded: file_helper
INFO - 2021-12-08 08:50:36 --> Helper loaded: form_helper
INFO - 2021-12-08 08:50:36 --> Helper loaded: my_helper
INFO - 2021-12-08 08:50:36 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:50:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:50:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:50:36 --> Controller Class Initialized
INFO - 2021-12-08 08:50:36 --> Final output sent to browser
DEBUG - 2021-12-08 08:50:36 --> Total execution time: 0.0520
INFO - 2021-12-08 08:50:37 --> Config Class Initialized
INFO - 2021-12-08 08:50:37 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:50:37 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:50:37 --> Utf8 Class Initialized
INFO - 2021-12-08 08:50:37 --> URI Class Initialized
INFO - 2021-12-08 08:50:37 --> Router Class Initialized
INFO - 2021-12-08 08:50:37 --> Output Class Initialized
INFO - 2021-12-08 08:50:37 --> Security Class Initialized
DEBUG - 2021-12-08 08:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:50:37 --> Input Class Initialized
INFO - 2021-12-08 08:50:37 --> Language Class Initialized
INFO - 2021-12-08 08:50:37 --> Language Class Initialized
INFO - 2021-12-08 08:50:37 --> Config Class Initialized
INFO - 2021-12-08 08:50:37 --> Loader Class Initialized
INFO - 2021-12-08 08:50:37 --> Helper loaded: url_helper
INFO - 2021-12-08 08:50:37 --> Helper loaded: file_helper
INFO - 2021-12-08 08:50:37 --> Helper loaded: form_helper
INFO - 2021-12-08 08:50:37 --> Helper loaded: my_helper
INFO - 2021-12-08 08:50:37 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:50:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:50:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:50:37 --> Controller Class Initialized
INFO - 2021-12-08 08:50:37 --> Final output sent to browser
DEBUG - 2021-12-08 08:50:37 --> Total execution time: 0.0470
INFO - 2021-12-08 08:50:38 --> Config Class Initialized
INFO - 2021-12-08 08:50:38 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:50:38 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:50:38 --> Utf8 Class Initialized
INFO - 2021-12-08 08:50:38 --> URI Class Initialized
INFO - 2021-12-08 08:50:38 --> Router Class Initialized
INFO - 2021-12-08 08:50:38 --> Output Class Initialized
INFO - 2021-12-08 08:50:38 --> Security Class Initialized
DEBUG - 2021-12-08 08:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:50:38 --> Input Class Initialized
INFO - 2021-12-08 08:50:38 --> Language Class Initialized
INFO - 2021-12-08 08:50:38 --> Language Class Initialized
INFO - 2021-12-08 08:50:38 --> Config Class Initialized
INFO - 2021-12-08 08:50:38 --> Loader Class Initialized
INFO - 2021-12-08 08:50:38 --> Helper loaded: url_helper
INFO - 2021-12-08 08:50:38 --> Helper loaded: file_helper
INFO - 2021-12-08 08:50:38 --> Helper loaded: form_helper
INFO - 2021-12-08 08:50:38 --> Helper loaded: my_helper
INFO - 2021-12-08 08:50:38 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:50:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:50:38 --> Controller Class Initialized
INFO - 2021-12-08 08:50:38 --> Final output sent to browser
DEBUG - 2021-12-08 08:50:38 --> Total execution time: 0.0630
INFO - 2021-12-08 08:50:40 --> Config Class Initialized
INFO - 2021-12-08 08:50:40 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:50:40 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:50:40 --> Utf8 Class Initialized
INFO - 2021-12-08 08:50:40 --> URI Class Initialized
INFO - 2021-12-08 08:50:40 --> Router Class Initialized
INFO - 2021-12-08 08:50:40 --> Output Class Initialized
INFO - 2021-12-08 08:50:40 --> Security Class Initialized
DEBUG - 2021-12-08 08:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:50:40 --> Input Class Initialized
INFO - 2021-12-08 08:50:40 --> Language Class Initialized
INFO - 2021-12-08 08:50:40 --> Language Class Initialized
INFO - 2021-12-08 08:50:40 --> Config Class Initialized
INFO - 2021-12-08 08:50:40 --> Loader Class Initialized
INFO - 2021-12-08 08:50:40 --> Helper loaded: url_helper
INFO - 2021-12-08 08:50:40 --> Helper loaded: file_helper
INFO - 2021-12-08 08:50:40 --> Helper loaded: form_helper
INFO - 2021-12-08 08:50:40 --> Helper loaded: my_helper
INFO - 2021-12-08 08:50:40 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:50:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:50:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:50:40 --> Controller Class Initialized
INFO - 2021-12-08 08:50:40 --> Final output sent to browser
DEBUG - 2021-12-08 08:50:40 --> Total execution time: 0.0500
INFO - 2021-12-08 08:50:41 --> Config Class Initialized
INFO - 2021-12-08 08:50:41 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:50:41 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:50:41 --> Utf8 Class Initialized
INFO - 2021-12-08 08:50:41 --> URI Class Initialized
INFO - 2021-12-08 08:50:41 --> Router Class Initialized
INFO - 2021-12-08 08:50:41 --> Output Class Initialized
INFO - 2021-12-08 08:50:41 --> Security Class Initialized
DEBUG - 2021-12-08 08:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:50:41 --> Input Class Initialized
INFO - 2021-12-08 08:50:41 --> Language Class Initialized
INFO - 2021-12-08 08:50:41 --> Language Class Initialized
INFO - 2021-12-08 08:50:41 --> Config Class Initialized
INFO - 2021-12-08 08:50:41 --> Loader Class Initialized
INFO - 2021-12-08 08:50:41 --> Helper loaded: url_helper
INFO - 2021-12-08 08:50:41 --> Helper loaded: file_helper
INFO - 2021-12-08 08:50:41 --> Helper loaded: form_helper
INFO - 2021-12-08 08:50:41 --> Helper loaded: my_helper
INFO - 2021-12-08 08:50:41 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:50:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:50:41 --> Controller Class Initialized
INFO - 2021-12-08 08:50:41 --> Final output sent to browser
DEBUG - 2021-12-08 08:50:41 --> Total execution time: 0.0460
INFO - 2021-12-08 08:50:43 --> Config Class Initialized
INFO - 2021-12-08 08:50:43 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:50:43 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:50:43 --> Utf8 Class Initialized
INFO - 2021-12-08 08:50:43 --> URI Class Initialized
INFO - 2021-12-08 08:50:43 --> Router Class Initialized
INFO - 2021-12-08 08:50:43 --> Output Class Initialized
INFO - 2021-12-08 08:50:43 --> Security Class Initialized
DEBUG - 2021-12-08 08:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:50:43 --> Input Class Initialized
INFO - 2021-12-08 08:50:43 --> Language Class Initialized
INFO - 2021-12-08 08:50:43 --> Language Class Initialized
INFO - 2021-12-08 08:50:43 --> Config Class Initialized
INFO - 2021-12-08 08:50:43 --> Loader Class Initialized
INFO - 2021-12-08 08:50:43 --> Helper loaded: url_helper
INFO - 2021-12-08 08:50:43 --> Helper loaded: file_helper
INFO - 2021-12-08 08:50:43 --> Helper loaded: form_helper
INFO - 2021-12-08 08:50:43 --> Helper loaded: my_helper
INFO - 2021-12-08 08:50:43 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:50:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:50:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:50:43 --> Controller Class Initialized
INFO - 2021-12-08 08:50:43 --> Final output sent to browser
DEBUG - 2021-12-08 08:50:43 --> Total execution time: 0.0600
INFO - 2021-12-08 08:50:44 --> Config Class Initialized
INFO - 2021-12-08 08:50:44 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:50:45 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:50:45 --> Utf8 Class Initialized
INFO - 2021-12-08 08:50:45 --> URI Class Initialized
INFO - 2021-12-08 08:50:45 --> Router Class Initialized
INFO - 2021-12-08 08:50:45 --> Output Class Initialized
INFO - 2021-12-08 08:50:45 --> Security Class Initialized
DEBUG - 2021-12-08 08:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:50:45 --> Input Class Initialized
INFO - 2021-12-08 08:50:45 --> Language Class Initialized
INFO - 2021-12-08 08:50:45 --> Language Class Initialized
INFO - 2021-12-08 08:50:45 --> Config Class Initialized
INFO - 2021-12-08 08:50:45 --> Loader Class Initialized
INFO - 2021-12-08 08:50:45 --> Helper loaded: url_helper
INFO - 2021-12-08 08:50:45 --> Helper loaded: file_helper
INFO - 2021-12-08 08:50:45 --> Helper loaded: form_helper
INFO - 2021-12-08 08:50:45 --> Helper loaded: my_helper
INFO - 2021-12-08 08:50:45 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:50:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:50:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:50:45 --> Controller Class Initialized
INFO - 2021-12-08 08:50:45 --> Final output sent to browser
DEBUG - 2021-12-08 08:50:45 --> Total execution time: 0.0530
INFO - 2021-12-08 08:50:58 --> Config Class Initialized
INFO - 2021-12-08 08:50:58 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:50:58 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:50:58 --> Utf8 Class Initialized
INFO - 2021-12-08 08:50:58 --> URI Class Initialized
INFO - 2021-12-08 08:50:58 --> Router Class Initialized
INFO - 2021-12-08 08:50:58 --> Output Class Initialized
INFO - 2021-12-08 08:50:58 --> Security Class Initialized
DEBUG - 2021-12-08 08:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:50:58 --> Input Class Initialized
INFO - 2021-12-08 08:50:58 --> Language Class Initialized
INFO - 2021-12-08 08:50:58 --> Language Class Initialized
INFO - 2021-12-08 08:50:58 --> Config Class Initialized
INFO - 2021-12-08 08:50:58 --> Loader Class Initialized
INFO - 2021-12-08 08:50:58 --> Helper loaded: url_helper
INFO - 2021-12-08 08:50:58 --> Helper loaded: file_helper
INFO - 2021-12-08 08:50:58 --> Helper loaded: form_helper
INFO - 2021-12-08 08:50:58 --> Helper loaded: my_helper
INFO - 2021-12-08 08:50:58 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:50:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:50:58 --> Controller Class Initialized
INFO - 2021-12-08 08:50:58 --> Final output sent to browser
DEBUG - 2021-12-08 08:50:58 --> Total execution time: 0.0510
INFO - 2021-12-08 08:50:59 --> Config Class Initialized
INFO - 2021-12-08 08:50:59 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:50:59 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:50:59 --> Utf8 Class Initialized
INFO - 2021-12-08 08:50:59 --> URI Class Initialized
INFO - 2021-12-08 08:50:59 --> Router Class Initialized
INFO - 2021-12-08 08:50:59 --> Output Class Initialized
INFO - 2021-12-08 08:50:59 --> Security Class Initialized
DEBUG - 2021-12-08 08:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:50:59 --> Input Class Initialized
INFO - 2021-12-08 08:50:59 --> Language Class Initialized
INFO - 2021-12-08 08:50:59 --> Language Class Initialized
INFO - 2021-12-08 08:50:59 --> Config Class Initialized
INFO - 2021-12-08 08:50:59 --> Loader Class Initialized
INFO - 2021-12-08 08:50:59 --> Helper loaded: url_helper
INFO - 2021-12-08 08:50:59 --> Helper loaded: file_helper
INFO - 2021-12-08 08:50:59 --> Helper loaded: form_helper
INFO - 2021-12-08 08:50:59 --> Helper loaded: my_helper
INFO - 2021-12-08 08:50:59 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:50:59 --> Controller Class Initialized
INFO - 2021-12-08 08:50:59 --> Final output sent to browser
DEBUG - 2021-12-08 08:50:59 --> Total execution time: 0.0590
INFO - 2021-12-08 08:52:17 --> Config Class Initialized
INFO - 2021-12-08 08:52:17 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:52:17 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:52:17 --> Utf8 Class Initialized
INFO - 2021-12-08 08:52:17 --> URI Class Initialized
INFO - 2021-12-08 08:52:17 --> Router Class Initialized
INFO - 2021-12-08 08:52:17 --> Output Class Initialized
INFO - 2021-12-08 08:52:17 --> Security Class Initialized
DEBUG - 2021-12-08 08:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:52:17 --> Input Class Initialized
INFO - 2021-12-08 08:52:17 --> Language Class Initialized
INFO - 2021-12-08 08:52:17 --> Language Class Initialized
INFO - 2021-12-08 08:52:17 --> Config Class Initialized
INFO - 2021-12-08 08:52:17 --> Loader Class Initialized
INFO - 2021-12-08 08:52:17 --> Helper loaded: url_helper
INFO - 2021-12-08 08:52:17 --> Helper loaded: file_helper
INFO - 2021-12-08 08:52:17 --> Helper loaded: form_helper
INFO - 2021-12-08 08:52:17 --> Helper loaded: my_helper
INFO - 2021-12-08 08:52:17 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:52:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:52:17 --> Controller Class Initialized
INFO - 2021-12-08 08:52:17 --> Final output sent to browser
DEBUG - 2021-12-08 08:52:17 --> Total execution time: 0.0800
INFO - 2021-12-08 08:52:23 --> Config Class Initialized
INFO - 2021-12-08 08:52:23 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:52:23 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:52:23 --> Utf8 Class Initialized
INFO - 2021-12-08 08:52:23 --> URI Class Initialized
INFO - 2021-12-08 08:52:23 --> Router Class Initialized
INFO - 2021-12-08 08:52:23 --> Output Class Initialized
INFO - 2021-12-08 08:52:23 --> Security Class Initialized
DEBUG - 2021-12-08 08:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:52:23 --> Input Class Initialized
INFO - 2021-12-08 08:52:23 --> Language Class Initialized
INFO - 2021-12-08 08:52:23 --> Language Class Initialized
INFO - 2021-12-08 08:52:23 --> Config Class Initialized
INFO - 2021-12-08 08:52:23 --> Loader Class Initialized
INFO - 2021-12-08 08:52:23 --> Helper loaded: url_helper
INFO - 2021-12-08 08:52:23 --> Helper loaded: file_helper
INFO - 2021-12-08 08:52:23 --> Helper loaded: form_helper
INFO - 2021-12-08 08:52:23 --> Helper loaded: my_helper
INFO - 2021-12-08 08:52:23 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:52:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:52:23 --> Controller Class Initialized
DEBUG - 2021-12-08 08:52:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2021-12-08 08:52:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 08:52:23 --> Final output sent to browser
DEBUG - 2021-12-08 08:52:23 --> Total execution time: 0.0720
INFO - 2021-12-08 08:52:28 --> Config Class Initialized
INFO - 2021-12-08 08:52:28 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:52:28 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:52:28 --> Utf8 Class Initialized
INFO - 2021-12-08 08:52:28 --> URI Class Initialized
INFO - 2021-12-08 08:52:28 --> Router Class Initialized
INFO - 2021-12-08 08:52:28 --> Output Class Initialized
INFO - 2021-12-08 08:52:28 --> Security Class Initialized
DEBUG - 2021-12-08 08:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:52:28 --> Input Class Initialized
INFO - 2021-12-08 08:52:28 --> Language Class Initialized
INFO - 2021-12-08 08:52:28 --> Language Class Initialized
INFO - 2021-12-08 08:52:28 --> Config Class Initialized
INFO - 2021-12-08 08:52:28 --> Loader Class Initialized
INFO - 2021-12-08 08:52:28 --> Helper loaded: url_helper
INFO - 2021-12-08 08:52:28 --> Helper loaded: file_helper
INFO - 2021-12-08 08:52:28 --> Helper loaded: form_helper
INFO - 2021-12-08 08:52:28 --> Helper loaded: my_helper
INFO - 2021-12-08 08:52:28 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:52:28 --> Controller Class Initialized
DEBUG - 2021-12-08 08:52:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-12-08 08:52:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 08:52:28 --> Final output sent to browser
DEBUG - 2021-12-08 08:52:28 --> Total execution time: 0.0730
INFO - 2021-12-08 08:54:10 --> Config Class Initialized
INFO - 2021-12-08 08:54:10 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:54:10 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:54:10 --> Utf8 Class Initialized
INFO - 2021-12-08 08:54:10 --> URI Class Initialized
INFO - 2021-12-08 08:54:10 --> Router Class Initialized
INFO - 2021-12-08 08:54:10 --> Output Class Initialized
INFO - 2021-12-08 08:54:10 --> Security Class Initialized
DEBUG - 2021-12-08 08:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:54:10 --> Input Class Initialized
INFO - 2021-12-08 08:54:10 --> Language Class Initialized
INFO - 2021-12-08 08:54:10 --> Language Class Initialized
INFO - 2021-12-08 08:54:10 --> Config Class Initialized
INFO - 2021-12-08 08:54:10 --> Loader Class Initialized
INFO - 2021-12-08 08:54:10 --> Helper loaded: url_helper
INFO - 2021-12-08 08:54:10 --> Helper loaded: file_helper
INFO - 2021-12-08 08:54:10 --> Helper loaded: form_helper
INFO - 2021-12-08 08:54:10 --> Helper loaded: my_helper
INFO - 2021-12-08 08:54:10 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:54:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:54:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:54:10 --> Controller Class Initialized
INFO - 2021-12-08 08:54:10 --> Final output sent to browser
DEBUG - 2021-12-08 08:54:10 --> Total execution time: 0.0840
INFO - 2021-12-08 08:54:28 --> Config Class Initialized
INFO - 2021-12-08 08:54:28 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:54:28 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:54:28 --> Utf8 Class Initialized
INFO - 2021-12-08 08:54:28 --> URI Class Initialized
INFO - 2021-12-08 08:54:28 --> Router Class Initialized
INFO - 2021-12-08 08:54:28 --> Output Class Initialized
INFO - 2021-12-08 08:54:28 --> Security Class Initialized
DEBUG - 2021-12-08 08:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:54:28 --> Input Class Initialized
INFO - 2021-12-08 08:54:28 --> Language Class Initialized
INFO - 2021-12-08 08:54:28 --> Language Class Initialized
INFO - 2021-12-08 08:54:28 --> Config Class Initialized
INFO - 2021-12-08 08:54:28 --> Loader Class Initialized
INFO - 2021-12-08 08:54:28 --> Helper loaded: url_helper
INFO - 2021-12-08 08:54:28 --> Helper loaded: file_helper
INFO - 2021-12-08 08:54:28 --> Helper loaded: form_helper
INFO - 2021-12-08 08:54:28 --> Helper loaded: my_helper
INFO - 2021-12-08 08:54:28 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:54:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:54:28 --> Controller Class Initialized
INFO - 2021-12-08 08:54:28 --> Final output sent to browser
DEBUG - 2021-12-08 08:54:28 --> Total execution time: 0.0840
INFO - 2021-12-08 08:54:40 --> Config Class Initialized
INFO - 2021-12-08 08:54:40 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:54:40 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:54:40 --> Utf8 Class Initialized
INFO - 2021-12-08 08:54:40 --> URI Class Initialized
INFO - 2021-12-08 08:54:40 --> Router Class Initialized
INFO - 2021-12-08 08:54:40 --> Output Class Initialized
INFO - 2021-12-08 08:54:40 --> Security Class Initialized
DEBUG - 2021-12-08 08:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:54:40 --> Input Class Initialized
INFO - 2021-12-08 08:54:40 --> Language Class Initialized
INFO - 2021-12-08 08:54:40 --> Language Class Initialized
INFO - 2021-12-08 08:54:40 --> Config Class Initialized
INFO - 2021-12-08 08:54:40 --> Loader Class Initialized
INFO - 2021-12-08 08:54:40 --> Helper loaded: url_helper
INFO - 2021-12-08 08:54:40 --> Helper loaded: file_helper
INFO - 2021-12-08 08:54:40 --> Helper loaded: form_helper
INFO - 2021-12-08 08:54:40 --> Helper loaded: my_helper
INFO - 2021-12-08 08:54:40 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:54:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:54:40 --> Controller Class Initialized
INFO - 2021-12-08 08:54:40 --> Helper loaded: cookie_helper
INFO - 2021-12-08 08:54:40 --> Config Class Initialized
INFO - 2021-12-08 08:54:40 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:54:40 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:54:40 --> Utf8 Class Initialized
INFO - 2021-12-08 08:54:40 --> URI Class Initialized
INFO - 2021-12-08 08:54:40 --> Router Class Initialized
INFO - 2021-12-08 08:54:40 --> Output Class Initialized
INFO - 2021-12-08 08:54:40 --> Security Class Initialized
DEBUG - 2021-12-08 08:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:54:40 --> Input Class Initialized
INFO - 2021-12-08 08:54:40 --> Language Class Initialized
INFO - 2021-12-08 08:54:40 --> Language Class Initialized
INFO - 2021-12-08 08:54:40 --> Config Class Initialized
INFO - 2021-12-08 08:54:40 --> Loader Class Initialized
INFO - 2021-12-08 08:54:40 --> Helper loaded: url_helper
INFO - 2021-12-08 08:54:40 --> Helper loaded: file_helper
INFO - 2021-12-08 08:54:40 --> Helper loaded: form_helper
INFO - 2021-12-08 08:54:40 --> Helper loaded: my_helper
INFO - 2021-12-08 08:54:40 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:54:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:54:40 --> Controller Class Initialized
DEBUG - 2021-12-08 08:54:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-08 08:54:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 08:54:40 --> Final output sent to browser
DEBUG - 2021-12-08 08:54:40 --> Total execution time: 0.0270
INFO - 2021-12-08 08:54:49 --> Config Class Initialized
INFO - 2021-12-08 08:54:49 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:54:49 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:54:49 --> Utf8 Class Initialized
INFO - 2021-12-08 08:54:49 --> URI Class Initialized
INFO - 2021-12-08 08:54:49 --> Router Class Initialized
INFO - 2021-12-08 08:54:49 --> Output Class Initialized
INFO - 2021-12-08 08:54:49 --> Security Class Initialized
DEBUG - 2021-12-08 08:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:54:49 --> Input Class Initialized
INFO - 2021-12-08 08:54:49 --> Language Class Initialized
INFO - 2021-12-08 08:54:49 --> Language Class Initialized
INFO - 2021-12-08 08:54:49 --> Config Class Initialized
INFO - 2021-12-08 08:54:49 --> Loader Class Initialized
INFO - 2021-12-08 08:54:49 --> Helper loaded: url_helper
INFO - 2021-12-08 08:54:49 --> Helper loaded: file_helper
INFO - 2021-12-08 08:54:49 --> Helper loaded: form_helper
INFO - 2021-12-08 08:54:49 --> Helper loaded: my_helper
INFO - 2021-12-08 08:54:49 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:54:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:54:49 --> Controller Class Initialized
INFO - 2021-12-08 08:54:49 --> Final output sent to browser
DEBUG - 2021-12-08 08:54:49 --> Total execution time: 0.0410
INFO - 2021-12-08 08:55:09 --> Config Class Initialized
INFO - 2021-12-08 08:55:09 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:55:09 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:55:09 --> Utf8 Class Initialized
INFO - 2021-12-08 08:55:09 --> URI Class Initialized
INFO - 2021-12-08 08:55:09 --> Router Class Initialized
INFO - 2021-12-08 08:55:09 --> Output Class Initialized
INFO - 2021-12-08 08:55:09 --> Security Class Initialized
DEBUG - 2021-12-08 08:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:55:09 --> Input Class Initialized
INFO - 2021-12-08 08:55:09 --> Language Class Initialized
INFO - 2021-12-08 08:55:09 --> Language Class Initialized
INFO - 2021-12-08 08:55:09 --> Config Class Initialized
INFO - 2021-12-08 08:55:09 --> Loader Class Initialized
INFO - 2021-12-08 08:55:09 --> Helper loaded: url_helper
INFO - 2021-12-08 08:55:09 --> Helper loaded: file_helper
INFO - 2021-12-08 08:55:09 --> Helper loaded: form_helper
INFO - 2021-12-08 08:55:09 --> Helper loaded: my_helper
INFO - 2021-12-08 08:55:09 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:55:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:55:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:55:09 --> Controller Class Initialized
INFO - 2021-12-08 08:55:09 --> Final output sent to browser
DEBUG - 2021-12-08 08:55:09 --> Total execution time: 0.0570
INFO - 2021-12-08 08:55:23 --> Config Class Initialized
INFO - 2021-12-08 08:55:23 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:55:23 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:55:23 --> Utf8 Class Initialized
INFO - 2021-12-08 08:55:23 --> URI Class Initialized
INFO - 2021-12-08 08:55:23 --> Router Class Initialized
INFO - 2021-12-08 08:55:23 --> Output Class Initialized
INFO - 2021-12-08 08:55:23 --> Security Class Initialized
DEBUG - 2021-12-08 08:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:55:23 --> Input Class Initialized
INFO - 2021-12-08 08:55:23 --> Language Class Initialized
INFO - 2021-12-08 08:55:23 --> Language Class Initialized
INFO - 2021-12-08 08:55:23 --> Config Class Initialized
INFO - 2021-12-08 08:55:23 --> Loader Class Initialized
INFO - 2021-12-08 08:55:23 --> Helper loaded: url_helper
INFO - 2021-12-08 08:55:23 --> Helper loaded: file_helper
INFO - 2021-12-08 08:55:23 --> Helper loaded: form_helper
INFO - 2021-12-08 08:55:23 --> Helper loaded: my_helper
INFO - 2021-12-08 08:55:23 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:55:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:55:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:55:23 --> Controller Class Initialized
INFO - 2021-12-08 08:55:23 --> Final output sent to browser
DEBUG - 2021-12-08 08:55:23 --> Total execution time: 0.0510
INFO - 2021-12-08 08:55:48 --> Config Class Initialized
INFO - 2021-12-08 08:55:48 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:55:48 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:55:48 --> Utf8 Class Initialized
INFO - 2021-12-08 08:55:48 --> URI Class Initialized
INFO - 2021-12-08 08:55:48 --> Router Class Initialized
INFO - 2021-12-08 08:55:48 --> Output Class Initialized
INFO - 2021-12-08 08:55:48 --> Security Class Initialized
DEBUG - 2021-12-08 08:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:55:48 --> Input Class Initialized
INFO - 2021-12-08 08:55:48 --> Language Class Initialized
INFO - 2021-12-08 08:55:48 --> Language Class Initialized
INFO - 2021-12-08 08:55:48 --> Config Class Initialized
INFO - 2021-12-08 08:55:48 --> Loader Class Initialized
INFO - 2021-12-08 08:55:48 --> Helper loaded: url_helper
INFO - 2021-12-08 08:55:48 --> Helper loaded: file_helper
INFO - 2021-12-08 08:55:48 --> Helper loaded: form_helper
INFO - 2021-12-08 08:55:48 --> Helper loaded: my_helper
INFO - 2021-12-08 08:55:48 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:55:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:55:48 --> Controller Class Initialized
INFO - 2021-12-08 08:55:48 --> Helper loaded: cookie_helper
INFO - 2021-12-08 08:55:48 --> Final output sent to browser
DEBUG - 2021-12-08 08:55:48 --> Total execution time: 0.0490
INFO - 2021-12-08 08:55:50 --> Config Class Initialized
INFO - 2021-12-08 08:55:50 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:55:50 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:55:50 --> Utf8 Class Initialized
INFO - 2021-12-08 08:55:50 --> URI Class Initialized
INFO - 2021-12-08 08:55:50 --> Router Class Initialized
INFO - 2021-12-08 08:55:50 --> Output Class Initialized
INFO - 2021-12-08 08:55:50 --> Security Class Initialized
DEBUG - 2021-12-08 08:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:55:50 --> Input Class Initialized
INFO - 2021-12-08 08:55:50 --> Language Class Initialized
INFO - 2021-12-08 08:55:50 --> Language Class Initialized
INFO - 2021-12-08 08:55:50 --> Config Class Initialized
INFO - 2021-12-08 08:55:50 --> Loader Class Initialized
INFO - 2021-12-08 08:55:50 --> Helper loaded: url_helper
INFO - 2021-12-08 08:55:50 --> Helper loaded: file_helper
INFO - 2021-12-08 08:55:50 --> Helper loaded: form_helper
INFO - 2021-12-08 08:55:50 --> Helper loaded: my_helper
INFO - 2021-12-08 08:55:50 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:55:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:55:50 --> Controller Class Initialized
DEBUG - 2021-12-08 08:55:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-08 08:55:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 08:55:51 --> Final output sent to browser
DEBUG - 2021-12-08 08:55:51 --> Total execution time: 0.2660
INFO - 2021-12-08 08:56:05 --> Config Class Initialized
INFO - 2021-12-08 08:56:05 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:56:05 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:56:05 --> Utf8 Class Initialized
INFO - 2021-12-08 08:56:05 --> URI Class Initialized
INFO - 2021-12-08 08:56:05 --> Router Class Initialized
INFO - 2021-12-08 08:56:05 --> Output Class Initialized
INFO - 2021-12-08 08:56:05 --> Security Class Initialized
DEBUG - 2021-12-08 08:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:56:05 --> Input Class Initialized
INFO - 2021-12-08 08:56:05 --> Language Class Initialized
INFO - 2021-12-08 08:56:05 --> Language Class Initialized
INFO - 2021-12-08 08:56:05 --> Config Class Initialized
INFO - 2021-12-08 08:56:05 --> Loader Class Initialized
INFO - 2021-12-08 08:56:05 --> Helper loaded: url_helper
INFO - 2021-12-08 08:56:05 --> Helper loaded: file_helper
INFO - 2021-12-08 08:56:05 --> Helper loaded: form_helper
INFO - 2021-12-08 08:56:05 --> Helper loaded: my_helper
INFO - 2021-12-08 08:56:05 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:56:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:56:05 --> Controller Class Initialized
DEBUG - 2021-12-08 08:56:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-12-08 08:56:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 08:56:05 --> Final output sent to browser
DEBUG - 2021-12-08 08:56:05 --> Total execution time: 0.0400
INFO - 2021-12-08 08:56:05 --> Config Class Initialized
INFO - 2021-12-08 08:56:05 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:56:05 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:56:05 --> Utf8 Class Initialized
INFO - 2021-12-08 08:56:05 --> URI Class Initialized
INFO - 2021-12-08 08:56:05 --> Router Class Initialized
INFO - 2021-12-08 08:56:05 --> Output Class Initialized
INFO - 2021-12-08 08:56:05 --> Security Class Initialized
DEBUG - 2021-12-08 08:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:56:05 --> Input Class Initialized
INFO - 2021-12-08 08:56:05 --> Language Class Initialized
INFO - 2021-12-08 08:56:05 --> Language Class Initialized
INFO - 2021-12-08 08:56:05 --> Config Class Initialized
INFO - 2021-12-08 08:56:05 --> Loader Class Initialized
INFO - 2021-12-08 08:56:05 --> Helper loaded: url_helper
INFO - 2021-12-08 08:56:05 --> Helper loaded: file_helper
INFO - 2021-12-08 08:56:05 --> Helper loaded: form_helper
INFO - 2021-12-08 08:56:05 --> Helper loaded: my_helper
INFO - 2021-12-08 08:56:05 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:56:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:56:05 --> Controller Class Initialized
INFO - 2021-12-08 08:56:27 --> Config Class Initialized
INFO - 2021-12-08 08:56:27 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:56:27 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:56:27 --> Utf8 Class Initialized
INFO - 2021-12-08 08:56:27 --> URI Class Initialized
INFO - 2021-12-08 08:56:27 --> Router Class Initialized
INFO - 2021-12-08 08:56:27 --> Output Class Initialized
INFO - 2021-12-08 08:56:27 --> Security Class Initialized
DEBUG - 2021-12-08 08:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:56:27 --> Input Class Initialized
INFO - 2021-12-08 08:56:27 --> Language Class Initialized
INFO - 2021-12-08 08:56:27 --> Language Class Initialized
INFO - 2021-12-08 08:56:27 --> Config Class Initialized
INFO - 2021-12-08 08:56:27 --> Loader Class Initialized
INFO - 2021-12-08 08:56:27 --> Helper loaded: url_helper
INFO - 2021-12-08 08:56:27 --> Helper loaded: file_helper
INFO - 2021-12-08 08:56:27 --> Helper loaded: form_helper
INFO - 2021-12-08 08:56:27 --> Helper loaded: my_helper
INFO - 2021-12-08 08:56:27 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:56:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:56:27 --> Controller Class Initialized
INFO - 2021-12-08 08:56:27 --> Final output sent to browser
DEBUG - 2021-12-08 08:56:27 --> Total execution time: 0.0570
INFO - 2021-12-08 08:56:27 --> Config Class Initialized
INFO - 2021-12-08 08:56:27 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:56:27 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:56:27 --> Utf8 Class Initialized
INFO - 2021-12-08 08:56:27 --> URI Class Initialized
INFO - 2021-12-08 08:56:27 --> Router Class Initialized
INFO - 2021-12-08 08:56:27 --> Output Class Initialized
INFO - 2021-12-08 08:56:27 --> Security Class Initialized
DEBUG - 2021-12-08 08:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:56:27 --> Input Class Initialized
INFO - 2021-12-08 08:56:27 --> Language Class Initialized
INFO - 2021-12-08 08:56:27 --> Language Class Initialized
INFO - 2021-12-08 08:56:27 --> Config Class Initialized
INFO - 2021-12-08 08:56:27 --> Loader Class Initialized
INFO - 2021-12-08 08:56:27 --> Helper loaded: url_helper
INFO - 2021-12-08 08:56:27 --> Helper loaded: file_helper
INFO - 2021-12-08 08:56:27 --> Helper loaded: form_helper
INFO - 2021-12-08 08:56:27 --> Helper loaded: my_helper
INFO - 2021-12-08 08:56:27 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:56:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:56:27 --> Controller Class Initialized
INFO - 2021-12-08 08:56:43 --> Config Class Initialized
INFO - 2021-12-08 08:56:43 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:56:43 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:56:43 --> Utf8 Class Initialized
INFO - 2021-12-08 08:56:43 --> URI Class Initialized
INFO - 2021-12-08 08:56:43 --> Router Class Initialized
INFO - 2021-12-08 08:56:43 --> Output Class Initialized
INFO - 2021-12-08 08:56:43 --> Security Class Initialized
DEBUG - 2021-12-08 08:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:56:43 --> Input Class Initialized
INFO - 2021-12-08 08:56:43 --> Language Class Initialized
INFO - 2021-12-08 08:56:43 --> Language Class Initialized
INFO - 2021-12-08 08:56:43 --> Config Class Initialized
INFO - 2021-12-08 08:56:43 --> Loader Class Initialized
INFO - 2021-12-08 08:56:43 --> Helper loaded: url_helper
INFO - 2021-12-08 08:56:43 --> Helper loaded: file_helper
INFO - 2021-12-08 08:56:43 --> Helper loaded: form_helper
INFO - 2021-12-08 08:56:43 --> Helper loaded: my_helper
INFO - 2021-12-08 08:56:43 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:56:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:56:43 --> Controller Class Initialized
INFO - 2021-12-08 08:56:43 --> Final output sent to browser
DEBUG - 2021-12-08 08:56:43 --> Total execution time: 0.0610
INFO - 2021-12-08 08:56:43 --> Config Class Initialized
INFO - 2021-12-08 08:56:43 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:56:43 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:56:43 --> Utf8 Class Initialized
INFO - 2021-12-08 08:56:43 --> URI Class Initialized
INFO - 2021-12-08 08:56:43 --> Router Class Initialized
INFO - 2021-12-08 08:56:43 --> Output Class Initialized
INFO - 2021-12-08 08:56:43 --> Security Class Initialized
DEBUG - 2021-12-08 08:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:56:43 --> Input Class Initialized
INFO - 2021-12-08 08:56:43 --> Language Class Initialized
INFO - 2021-12-08 08:56:43 --> Language Class Initialized
INFO - 2021-12-08 08:56:43 --> Config Class Initialized
INFO - 2021-12-08 08:56:43 --> Loader Class Initialized
INFO - 2021-12-08 08:56:43 --> Helper loaded: url_helper
INFO - 2021-12-08 08:56:43 --> Helper loaded: file_helper
INFO - 2021-12-08 08:56:43 --> Helper loaded: form_helper
INFO - 2021-12-08 08:56:43 --> Helper loaded: my_helper
INFO - 2021-12-08 08:56:43 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:56:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:56:43 --> Controller Class Initialized
INFO - 2021-12-08 08:56:52 --> Config Class Initialized
INFO - 2021-12-08 08:56:52 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:56:52 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:56:52 --> Utf8 Class Initialized
INFO - 2021-12-08 08:56:52 --> URI Class Initialized
INFO - 2021-12-08 08:56:52 --> Router Class Initialized
INFO - 2021-12-08 08:56:52 --> Output Class Initialized
INFO - 2021-12-08 08:56:52 --> Security Class Initialized
DEBUG - 2021-12-08 08:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:56:52 --> Input Class Initialized
INFO - 2021-12-08 08:56:52 --> Language Class Initialized
INFO - 2021-12-08 08:56:52 --> Language Class Initialized
INFO - 2021-12-08 08:56:52 --> Config Class Initialized
INFO - 2021-12-08 08:56:52 --> Loader Class Initialized
INFO - 2021-12-08 08:56:52 --> Helper loaded: url_helper
INFO - 2021-12-08 08:56:52 --> Helper loaded: file_helper
INFO - 2021-12-08 08:56:52 --> Helper loaded: form_helper
INFO - 2021-12-08 08:56:52 --> Helper loaded: my_helper
INFO - 2021-12-08 08:56:52 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:56:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:56:52 --> Controller Class Initialized
INFO - 2021-12-08 08:56:52 --> Helper loaded: cookie_helper
INFO - 2021-12-08 08:56:53 --> Config Class Initialized
INFO - 2021-12-08 08:56:53 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:56:53 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:56:53 --> Utf8 Class Initialized
INFO - 2021-12-08 08:56:53 --> URI Class Initialized
INFO - 2021-12-08 08:56:53 --> Router Class Initialized
INFO - 2021-12-08 08:56:53 --> Output Class Initialized
INFO - 2021-12-08 08:56:53 --> Security Class Initialized
DEBUG - 2021-12-08 08:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:56:53 --> Input Class Initialized
INFO - 2021-12-08 08:56:53 --> Language Class Initialized
INFO - 2021-12-08 08:56:53 --> Language Class Initialized
INFO - 2021-12-08 08:56:53 --> Config Class Initialized
INFO - 2021-12-08 08:56:53 --> Loader Class Initialized
INFO - 2021-12-08 08:56:53 --> Helper loaded: url_helper
INFO - 2021-12-08 08:56:53 --> Helper loaded: file_helper
INFO - 2021-12-08 08:56:53 --> Helper loaded: form_helper
INFO - 2021-12-08 08:56:53 --> Helper loaded: my_helper
INFO - 2021-12-08 08:56:53 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:56:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:56:53 --> Controller Class Initialized
DEBUG - 2021-12-08 08:56:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-08 08:56:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 08:56:53 --> Final output sent to browser
DEBUG - 2021-12-08 08:56:53 --> Total execution time: 0.0360
INFO - 2021-12-08 08:57:09 --> Config Class Initialized
INFO - 2021-12-08 08:57:09 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:57:09 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:57:09 --> Utf8 Class Initialized
INFO - 2021-12-08 08:57:09 --> URI Class Initialized
INFO - 2021-12-08 08:57:09 --> Router Class Initialized
INFO - 2021-12-08 08:57:09 --> Output Class Initialized
INFO - 2021-12-08 08:57:09 --> Security Class Initialized
DEBUG - 2021-12-08 08:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:57:09 --> Input Class Initialized
INFO - 2021-12-08 08:57:09 --> Language Class Initialized
INFO - 2021-12-08 08:57:09 --> Language Class Initialized
INFO - 2021-12-08 08:57:09 --> Config Class Initialized
INFO - 2021-12-08 08:57:09 --> Loader Class Initialized
INFO - 2021-12-08 08:57:09 --> Helper loaded: url_helper
INFO - 2021-12-08 08:57:09 --> Helper loaded: file_helper
INFO - 2021-12-08 08:57:09 --> Helper loaded: form_helper
INFO - 2021-12-08 08:57:09 --> Helper loaded: my_helper
INFO - 2021-12-08 08:57:09 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:57:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:57:09 --> Controller Class Initialized
INFO - 2021-12-08 08:57:09 --> Final output sent to browser
DEBUG - 2021-12-08 08:57:09 --> Total execution time: 0.0470
INFO - 2021-12-08 08:57:24 --> Config Class Initialized
INFO - 2021-12-08 08:57:24 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:57:24 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:57:24 --> Utf8 Class Initialized
INFO - 2021-12-08 08:57:24 --> URI Class Initialized
INFO - 2021-12-08 08:57:24 --> Router Class Initialized
INFO - 2021-12-08 08:57:24 --> Output Class Initialized
INFO - 2021-12-08 08:57:24 --> Security Class Initialized
DEBUG - 2021-12-08 08:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:57:24 --> Input Class Initialized
INFO - 2021-12-08 08:57:24 --> Language Class Initialized
INFO - 2021-12-08 08:57:24 --> Language Class Initialized
INFO - 2021-12-08 08:57:24 --> Config Class Initialized
INFO - 2021-12-08 08:57:24 --> Loader Class Initialized
INFO - 2021-12-08 08:57:24 --> Helper loaded: url_helper
INFO - 2021-12-08 08:57:24 --> Helper loaded: file_helper
INFO - 2021-12-08 08:57:24 --> Helper loaded: form_helper
INFO - 2021-12-08 08:57:24 --> Helper loaded: my_helper
INFO - 2021-12-08 08:57:24 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:57:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:57:24 --> Controller Class Initialized
INFO - 2021-12-08 08:57:24 --> Final output sent to browser
DEBUG - 2021-12-08 08:57:24 --> Total execution time: 0.0510
INFO - 2021-12-08 08:57:32 --> Config Class Initialized
INFO - 2021-12-08 08:57:32 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:57:32 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:57:32 --> Utf8 Class Initialized
INFO - 2021-12-08 08:57:32 --> URI Class Initialized
INFO - 2021-12-08 08:57:32 --> Router Class Initialized
INFO - 2021-12-08 08:57:32 --> Output Class Initialized
INFO - 2021-12-08 08:57:32 --> Security Class Initialized
DEBUG - 2021-12-08 08:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:57:32 --> Input Class Initialized
INFO - 2021-12-08 08:57:32 --> Language Class Initialized
INFO - 2021-12-08 08:57:32 --> Language Class Initialized
INFO - 2021-12-08 08:57:32 --> Config Class Initialized
INFO - 2021-12-08 08:57:32 --> Loader Class Initialized
INFO - 2021-12-08 08:57:32 --> Helper loaded: url_helper
INFO - 2021-12-08 08:57:32 --> Helper loaded: file_helper
INFO - 2021-12-08 08:57:32 --> Helper loaded: form_helper
INFO - 2021-12-08 08:57:32 --> Helper loaded: my_helper
INFO - 2021-12-08 08:57:32 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:57:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:57:32 --> Controller Class Initialized
INFO - 2021-12-08 08:57:32 --> Final output sent to browser
DEBUG - 2021-12-08 08:57:32 --> Total execution time: 0.0530
INFO - 2021-12-08 08:57:52 --> Config Class Initialized
INFO - 2021-12-08 08:57:52 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:57:52 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:57:52 --> Utf8 Class Initialized
INFO - 2021-12-08 08:57:52 --> URI Class Initialized
INFO - 2021-12-08 08:57:52 --> Router Class Initialized
INFO - 2021-12-08 08:57:52 --> Output Class Initialized
INFO - 2021-12-08 08:57:52 --> Security Class Initialized
DEBUG - 2021-12-08 08:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:57:52 --> Input Class Initialized
INFO - 2021-12-08 08:57:52 --> Language Class Initialized
INFO - 2021-12-08 08:57:52 --> Language Class Initialized
INFO - 2021-12-08 08:57:52 --> Config Class Initialized
INFO - 2021-12-08 08:57:52 --> Loader Class Initialized
INFO - 2021-12-08 08:57:52 --> Helper loaded: url_helper
INFO - 2021-12-08 08:57:52 --> Helper loaded: file_helper
INFO - 2021-12-08 08:57:52 --> Helper loaded: form_helper
INFO - 2021-12-08 08:57:52 --> Helper loaded: my_helper
INFO - 2021-12-08 08:57:52 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:57:52 --> Controller Class Initialized
INFO - 2021-12-08 08:57:52 --> Final output sent to browser
DEBUG - 2021-12-08 08:57:52 --> Total execution time: 0.0550
INFO - 2021-12-08 08:58:01 --> Config Class Initialized
INFO - 2021-12-08 08:58:01 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:58:01 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:58:01 --> Utf8 Class Initialized
INFO - 2021-12-08 08:58:01 --> URI Class Initialized
INFO - 2021-12-08 08:58:01 --> Router Class Initialized
INFO - 2021-12-08 08:58:01 --> Output Class Initialized
INFO - 2021-12-08 08:58:01 --> Security Class Initialized
DEBUG - 2021-12-08 08:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:58:01 --> Input Class Initialized
INFO - 2021-12-08 08:58:01 --> Language Class Initialized
INFO - 2021-12-08 08:58:01 --> Language Class Initialized
INFO - 2021-12-08 08:58:01 --> Config Class Initialized
INFO - 2021-12-08 08:58:01 --> Loader Class Initialized
INFO - 2021-12-08 08:58:01 --> Helper loaded: url_helper
INFO - 2021-12-08 08:58:01 --> Helper loaded: file_helper
INFO - 2021-12-08 08:58:01 --> Helper loaded: form_helper
INFO - 2021-12-08 08:58:01 --> Helper loaded: my_helper
INFO - 2021-12-08 08:58:01 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:58:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:58:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:58:01 --> Controller Class Initialized
INFO - 2021-12-08 08:58:01 --> Helper loaded: cookie_helper
INFO - 2021-12-08 08:58:01 --> Final output sent to browser
DEBUG - 2021-12-08 08:58:01 --> Total execution time: 0.0610
INFO - 2021-12-08 08:58:03 --> Config Class Initialized
INFO - 2021-12-08 08:58:03 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:58:03 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:58:03 --> Utf8 Class Initialized
INFO - 2021-12-08 08:58:03 --> URI Class Initialized
INFO - 2021-12-08 08:58:03 --> Router Class Initialized
INFO - 2021-12-08 08:58:03 --> Output Class Initialized
INFO - 2021-12-08 08:58:03 --> Security Class Initialized
DEBUG - 2021-12-08 08:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:58:03 --> Input Class Initialized
INFO - 2021-12-08 08:58:03 --> Language Class Initialized
INFO - 2021-12-08 08:58:03 --> Language Class Initialized
INFO - 2021-12-08 08:58:03 --> Config Class Initialized
INFO - 2021-12-08 08:58:03 --> Loader Class Initialized
INFO - 2021-12-08 08:58:03 --> Helper loaded: url_helper
INFO - 2021-12-08 08:58:03 --> Helper loaded: file_helper
INFO - 2021-12-08 08:58:03 --> Helper loaded: form_helper
INFO - 2021-12-08 08:58:03 --> Helper loaded: my_helper
INFO - 2021-12-08 08:58:03 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:58:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:58:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:58:03 --> Controller Class Initialized
DEBUG - 2021-12-08 08:58:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-08 08:58:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 08:58:03 --> Final output sent to browser
DEBUG - 2021-12-08 08:58:03 --> Total execution time: 0.1670
INFO - 2021-12-08 08:58:13 --> Config Class Initialized
INFO - 2021-12-08 08:58:13 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:58:13 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:58:13 --> Utf8 Class Initialized
INFO - 2021-12-08 08:58:13 --> URI Class Initialized
INFO - 2021-12-08 08:58:13 --> Router Class Initialized
INFO - 2021-12-08 08:58:13 --> Output Class Initialized
INFO - 2021-12-08 08:58:13 --> Security Class Initialized
DEBUG - 2021-12-08 08:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:58:13 --> Input Class Initialized
INFO - 2021-12-08 08:58:13 --> Language Class Initialized
INFO - 2021-12-08 08:58:13 --> Language Class Initialized
INFO - 2021-12-08 08:58:13 --> Config Class Initialized
INFO - 2021-12-08 08:58:13 --> Loader Class Initialized
INFO - 2021-12-08 08:58:13 --> Helper loaded: url_helper
INFO - 2021-12-08 08:58:13 --> Helper loaded: file_helper
INFO - 2021-12-08 08:58:13 --> Helper loaded: form_helper
INFO - 2021-12-08 08:58:13 --> Helper loaded: my_helper
INFO - 2021-12-08 08:58:13 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:58:13 --> Controller Class Initialized
INFO - 2021-12-08 08:58:13 --> Helper loaded: cookie_helper
INFO - 2021-12-08 08:58:13 --> Config Class Initialized
INFO - 2021-12-08 08:58:13 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:58:13 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:58:13 --> Utf8 Class Initialized
INFO - 2021-12-08 08:58:13 --> URI Class Initialized
INFO - 2021-12-08 08:58:13 --> Router Class Initialized
INFO - 2021-12-08 08:58:13 --> Output Class Initialized
INFO - 2021-12-08 08:58:13 --> Security Class Initialized
DEBUG - 2021-12-08 08:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:58:13 --> Input Class Initialized
INFO - 2021-12-08 08:58:13 --> Language Class Initialized
INFO - 2021-12-08 08:58:13 --> Language Class Initialized
INFO - 2021-12-08 08:58:13 --> Config Class Initialized
INFO - 2021-12-08 08:58:13 --> Loader Class Initialized
INFO - 2021-12-08 08:58:13 --> Helper loaded: url_helper
INFO - 2021-12-08 08:58:13 --> Helper loaded: file_helper
INFO - 2021-12-08 08:58:13 --> Helper loaded: form_helper
INFO - 2021-12-08 08:58:13 --> Helper loaded: my_helper
INFO - 2021-12-08 08:58:13 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:58:13 --> Controller Class Initialized
DEBUG - 2021-12-08 08:58:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-08 08:58:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 08:58:13 --> Final output sent to browser
DEBUG - 2021-12-08 08:58:13 --> Total execution time: 0.0360
INFO - 2021-12-08 08:58:48 --> Config Class Initialized
INFO - 2021-12-08 08:58:48 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:58:48 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:58:48 --> Utf8 Class Initialized
INFO - 2021-12-08 08:58:48 --> URI Class Initialized
INFO - 2021-12-08 08:58:48 --> Router Class Initialized
INFO - 2021-12-08 08:58:48 --> Output Class Initialized
INFO - 2021-12-08 08:58:48 --> Security Class Initialized
DEBUG - 2021-12-08 08:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:58:48 --> Input Class Initialized
INFO - 2021-12-08 08:58:48 --> Language Class Initialized
INFO - 2021-12-08 08:58:48 --> Language Class Initialized
INFO - 2021-12-08 08:58:48 --> Config Class Initialized
INFO - 2021-12-08 08:58:48 --> Loader Class Initialized
INFO - 2021-12-08 08:58:48 --> Helper loaded: url_helper
INFO - 2021-12-08 08:58:48 --> Helper loaded: file_helper
INFO - 2021-12-08 08:58:48 --> Helper loaded: form_helper
INFO - 2021-12-08 08:58:48 --> Helper loaded: my_helper
INFO - 2021-12-08 08:58:48 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:58:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:58:48 --> Controller Class Initialized
INFO - 2021-12-08 08:58:48 --> Helper loaded: cookie_helper
INFO - 2021-12-08 08:58:48 --> Final output sent to browser
DEBUG - 2021-12-08 08:58:48 --> Total execution time: 0.0490
INFO - 2021-12-08 08:58:50 --> Config Class Initialized
INFO - 2021-12-08 08:58:50 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:58:50 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:58:50 --> Utf8 Class Initialized
INFO - 2021-12-08 08:58:50 --> URI Class Initialized
INFO - 2021-12-08 08:58:50 --> Router Class Initialized
INFO - 2021-12-08 08:58:50 --> Output Class Initialized
INFO - 2021-12-08 08:58:50 --> Security Class Initialized
DEBUG - 2021-12-08 08:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:58:50 --> Input Class Initialized
INFO - 2021-12-08 08:58:50 --> Language Class Initialized
INFO - 2021-12-08 08:58:50 --> Language Class Initialized
INFO - 2021-12-08 08:58:50 --> Config Class Initialized
INFO - 2021-12-08 08:58:50 --> Loader Class Initialized
INFO - 2021-12-08 08:58:50 --> Helper loaded: url_helper
INFO - 2021-12-08 08:58:50 --> Helper loaded: file_helper
INFO - 2021-12-08 08:58:50 --> Helper loaded: form_helper
INFO - 2021-12-08 08:58:50 --> Helper loaded: my_helper
INFO - 2021-12-08 08:58:50 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:58:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:58:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:58:50 --> Controller Class Initialized
DEBUG - 2021-12-08 08:58:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-08 08:58:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 08:58:50 --> Final output sent to browser
DEBUG - 2021-12-08 08:58:50 --> Total execution time: 0.1570
INFO - 2021-12-08 08:58:54 --> Config Class Initialized
INFO - 2021-12-08 08:58:54 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:58:54 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:58:54 --> Utf8 Class Initialized
INFO - 2021-12-08 08:58:54 --> URI Class Initialized
INFO - 2021-12-08 08:58:54 --> Router Class Initialized
INFO - 2021-12-08 08:58:54 --> Output Class Initialized
INFO - 2021-12-08 08:58:54 --> Security Class Initialized
DEBUG - 2021-12-08 08:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:58:54 --> Input Class Initialized
INFO - 2021-12-08 08:58:54 --> Language Class Initialized
INFO - 2021-12-08 08:58:54 --> Language Class Initialized
INFO - 2021-12-08 08:58:54 --> Config Class Initialized
INFO - 2021-12-08 08:58:54 --> Loader Class Initialized
INFO - 2021-12-08 08:58:54 --> Helper loaded: url_helper
INFO - 2021-12-08 08:58:54 --> Helper loaded: file_helper
INFO - 2021-12-08 08:58:54 --> Helper loaded: form_helper
INFO - 2021-12-08 08:58:54 --> Helper loaded: my_helper
INFO - 2021-12-08 08:58:54 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:58:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:58:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:58:54 --> Controller Class Initialized
DEBUG - 2021-12-08 08:58:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-08 08:58:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 08:58:54 --> Final output sent to browser
DEBUG - 2021-12-08 08:58:54 --> Total execution time: 0.0730
INFO - 2021-12-08 09:02:07 --> Config Class Initialized
INFO - 2021-12-08 09:02:07 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:02:07 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:02:07 --> Utf8 Class Initialized
INFO - 2021-12-08 09:02:07 --> URI Class Initialized
INFO - 2021-12-08 09:02:07 --> Router Class Initialized
INFO - 2021-12-08 09:02:07 --> Output Class Initialized
INFO - 2021-12-08 09:02:07 --> Security Class Initialized
DEBUG - 2021-12-08 09:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:02:07 --> Input Class Initialized
INFO - 2021-12-08 09:02:07 --> Language Class Initialized
INFO - 2021-12-08 09:02:07 --> Language Class Initialized
INFO - 2021-12-08 09:02:07 --> Config Class Initialized
INFO - 2021-12-08 09:02:07 --> Loader Class Initialized
INFO - 2021-12-08 09:02:07 --> Helper loaded: url_helper
INFO - 2021-12-08 09:02:07 --> Helper loaded: file_helper
INFO - 2021-12-08 09:02:07 --> Helper loaded: form_helper
INFO - 2021-12-08 09:02:07 --> Helper loaded: my_helper
INFO - 2021-12-08 09:02:07 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:02:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:02:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:02:07 --> Controller Class Initialized
INFO - 2021-12-08 09:02:07 --> Final output sent to browser
DEBUG - 2021-12-08 09:02:07 --> Total execution time: 0.0470
INFO - 2021-12-08 09:02:12 --> Config Class Initialized
INFO - 2021-12-08 09:02:12 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:02:12 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:02:12 --> Utf8 Class Initialized
INFO - 2021-12-08 09:02:12 --> URI Class Initialized
INFO - 2021-12-08 09:02:12 --> Router Class Initialized
INFO - 2021-12-08 09:02:12 --> Output Class Initialized
INFO - 2021-12-08 09:02:12 --> Security Class Initialized
DEBUG - 2021-12-08 09:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:02:12 --> Input Class Initialized
INFO - 2021-12-08 09:02:12 --> Language Class Initialized
INFO - 2021-12-08 09:02:12 --> Language Class Initialized
INFO - 2021-12-08 09:02:12 --> Config Class Initialized
INFO - 2021-12-08 09:02:12 --> Loader Class Initialized
INFO - 2021-12-08 09:02:12 --> Helper loaded: url_helper
INFO - 2021-12-08 09:02:12 --> Helper loaded: file_helper
INFO - 2021-12-08 09:02:12 --> Helper loaded: form_helper
INFO - 2021-12-08 09:02:12 --> Helper loaded: my_helper
INFO - 2021-12-08 09:02:12 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:02:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:02:12 --> Controller Class Initialized
DEBUG - 2021-12-08 09:02:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-12-08 09:02:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 09:02:12 --> Final output sent to browser
DEBUG - 2021-12-08 09:02:12 --> Total execution time: 0.0580
INFO - 2021-12-08 09:02:51 --> Config Class Initialized
INFO - 2021-12-08 09:02:51 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:02:51 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:02:51 --> Utf8 Class Initialized
INFO - 2021-12-08 09:02:51 --> URI Class Initialized
INFO - 2021-12-08 09:02:51 --> Router Class Initialized
INFO - 2021-12-08 09:02:51 --> Output Class Initialized
INFO - 2021-12-08 09:02:51 --> Security Class Initialized
DEBUG - 2021-12-08 09:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:02:51 --> Input Class Initialized
INFO - 2021-12-08 09:02:51 --> Language Class Initialized
INFO - 2021-12-08 09:02:51 --> Language Class Initialized
INFO - 2021-12-08 09:02:51 --> Config Class Initialized
INFO - 2021-12-08 09:02:51 --> Loader Class Initialized
INFO - 2021-12-08 09:02:51 --> Helper loaded: url_helper
INFO - 2021-12-08 09:02:51 --> Helper loaded: file_helper
INFO - 2021-12-08 09:02:51 --> Helper loaded: form_helper
INFO - 2021-12-08 09:02:51 --> Helper loaded: my_helper
INFO - 2021-12-08 09:02:51 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:02:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:02:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:02:51 --> Controller Class Initialized
INFO - 2021-12-08 09:02:51 --> Final output sent to browser
DEBUG - 2021-12-08 09:02:51 --> Total execution time: 0.0570
INFO - 2021-12-08 09:02:59 --> Config Class Initialized
INFO - 2021-12-08 09:02:59 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:02:59 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:02:59 --> Utf8 Class Initialized
INFO - 2021-12-08 09:02:59 --> URI Class Initialized
INFO - 2021-12-08 09:02:59 --> Router Class Initialized
INFO - 2021-12-08 09:02:59 --> Output Class Initialized
INFO - 2021-12-08 09:02:59 --> Security Class Initialized
DEBUG - 2021-12-08 09:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:02:59 --> Input Class Initialized
INFO - 2021-12-08 09:02:59 --> Language Class Initialized
INFO - 2021-12-08 09:02:59 --> Language Class Initialized
INFO - 2021-12-08 09:02:59 --> Config Class Initialized
INFO - 2021-12-08 09:02:59 --> Loader Class Initialized
INFO - 2021-12-08 09:02:59 --> Helper loaded: url_helper
INFO - 2021-12-08 09:02:59 --> Helper loaded: file_helper
INFO - 2021-12-08 09:02:59 --> Helper loaded: form_helper
INFO - 2021-12-08 09:02:59 --> Helper loaded: my_helper
INFO - 2021-12-08 09:02:59 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:02:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:02:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:02:59 --> Controller Class Initialized
DEBUG - 2021-12-08 09:02:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-12-08 09:02:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 09:02:59 --> Final output sent to browser
DEBUG - 2021-12-08 09:02:59 --> Total execution time: 0.0480
INFO - 2021-12-08 09:03:02 --> Config Class Initialized
INFO - 2021-12-08 09:03:02 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:03:02 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:03:02 --> Utf8 Class Initialized
INFO - 2021-12-08 09:03:02 --> URI Class Initialized
INFO - 2021-12-08 09:03:02 --> Router Class Initialized
INFO - 2021-12-08 09:03:02 --> Output Class Initialized
INFO - 2021-12-08 09:03:02 --> Security Class Initialized
DEBUG - 2021-12-08 09:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:03:02 --> Input Class Initialized
INFO - 2021-12-08 09:03:02 --> Language Class Initialized
INFO - 2021-12-08 09:03:02 --> Language Class Initialized
INFO - 2021-12-08 09:03:02 --> Config Class Initialized
INFO - 2021-12-08 09:03:02 --> Loader Class Initialized
INFO - 2021-12-08 09:03:02 --> Helper loaded: url_helper
INFO - 2021-12-08 09:03:02 --> Helper loaded: file_helper
INFO - 2021-12-08 09:03:02 --> Helper loaded: form_helper
INFO - 2021-12-08 09:03:02 --> Helper loaded: my_helper
INFO - 2021-12-08 09:03:02 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:03:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:03:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:03:02 --> Controller Class Initialized
INFO - 2021-12-08 09:03:02 --> Final output sent to browser
DEBUG - 2021-12-08 09:03:02 --> Total execution time: 0.0550
INFO - 2021-12-08 09:03:06 --> Config Class Initialized
INFO - 2021-12-08 09:03:06 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:03:06 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:03:06 --> Utf8 Class Initialized
INFO - 2021-12-08 09:03:06 --> URI Class Initialized
INFO - 2021-12-08 09:03:06 --> Router Class Initialized
INFO - 2021-12-08 09:03:06 --> Output Class Initialized
INFO - 2021-12-08 09:03:06 --> Security Class Initialized
DEBUG - 2021-12-08 09:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:03:06 --> Input Class Initialized
INFO - 2021-12-08 09:03:06 --> Language Class Initialized
INFO - 2021-12-08 09:03:06 --> Language Class Initialized
INFO - 2021-12-08 09:03:06 --> Config Class Initialized
INFO - 2021-12-08 09:03:06 --> Loader Class Initialized
INFO - 2021-12-08 09:03:06 --> Helper loaded: url_helper
INFO - 2021-12-08 09:03:06 --> Helper loaded: file_helper
INFO - 2021-12-08 09:03:06 --> Helper loaded: form_helper
INFO - 2021-12-08 09:03:06 --> Helper loaded: my_helper
INFO - 2021-12-08 09:03:06 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:03:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:03:06 --> Controller Class Initialized
INFO - 2021-12-08 09:03:06 --> Final output sent to browser
DEBUG - 2021-12-08 09:03:06 --> Total execution time: 0.0550
INFO - 2021-12-08 09:03:07 --> Config Class Initialized
INFO - 2021-12-08 09:03:07 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:03:07 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:03:07 --> Utf8 Class Initialized
INFO - 2021-12-08 09:03:07 --> URI Class Initialized
INFO - 2021-12-08 09:03:07 --> Router Class Initialized
INFO - 2021-12-08 09:03:07 --> Output Class Initialized
INFO - 2021-12-08 09:03:07 --> Security Class Initialized
DEBUG - 2021-12-08 09:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:03:07 --> Input Class Initialized
INFO - 2021-12-08 09:03:07 --> Language Class Initialized
INFO - 2021-12-08 09:03:07 --> Language Class Initialized
INFO - 2021-12-08 09:03:07 --> Config Class Initialized
INFO - 2021-12-08 09:03:07 --> Loader Class Initialized
INFO - 2021-12-08 09:03:07 --> Helper loaded: url_helper
INFO - 2021-12-08 09:03:07 --> Helper loaded: file_helper
INFO - 2021-12-08 09:03:07 --> Helper loaded: form_helper
INFO - 2021-12-08 09:03:07 --> Helper loaded: my_helper
INFO - 2021-12-08 09:03:07 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:03:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:03:07 --> Controller Class Initialized
INFO - 2021-12-08 09:03:07 --> Final output sent to browser
DEBUG - 2021-12-08 09:03:07 --> Total execution time: 0.0560
INFO - 2021-12-08 09:03:34 --> Config Class Initialized
INFO - 2021-12-08 09:03:34 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:03:34 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:03:34 --> Utf8 Class Initialized
INFO - 2021-12-08 09:03:34 --> URI Class Initialized
INFO - 2021-12-08 09:03:34 --> Router Class Initialized
INFO - 2021-12-08 09:03:34 --> Output Class Initialized
INFO - 2021-12-08 09:03:34 --> Security Class Initialized
DEBUG - 2021-12-08 09:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:03:34 --> Input Class Initialized
INFO - 2021-12-08 09:03:34 --> Language Class Initialized
INFO - 2021-12-08 09:03:34 --> Language Class Initialized
INFO - 2021-12-08 09:03:34 --> Config Class Initialized
INFO - 2021-12-08 09:03:34 --> Loader Class Initialized
INFO - 2021-12-08 09:03:34 --> Helper loaded: url_helper
INFO - 2021-12-08 09:03:34 --> Helper loaded: file_helper
INFO - 2021-12-08 09:03:34 --> Helper loaded: form_helper
INFO - 2021-12-08 09:03:34 --> Helper loaded: my_helper
INFO - 2021-12-08 09:03:34 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:03:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:03:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:03:34 --> Controller Class Initialized
INFO - 2021-12-08 09:03:34 --> Final output sent to browser
DEBUG - 2021-12-08 09:03:34 --> Total execution time: 0.0570
INFO - 2021-12-08 09:03:45 --> Config Class Initialized
INFO - 2021-12-08 09:03:45 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:03:45 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:03:45 --> Utf8 Class Initialized
INFO - 2021-12-08 09:03:45 --> URI Class Initialized
INFO - 2021-12-08 09:03:45 --> Router Class Initialized
INFO - 2021-12-08 09:03:45 --> Output Class Initialized
INFO - 2021-12-08 09:03:45 --> Security Class Initialized
DEBUG - 2021-12-08 09:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:03:45 --> Input Class Initialized
INFO - 2021-12-08 09:03:45 --> Language Class Initialized
INFO - 2021-12-08 09:03:45 --> Language Class Initialized
INFO - 2021-12-08 09:03:45 --> Config Class Initialized
INFO - 2021-12-08 09:03:45 --> Loader Class Initialized
INFO - 2021-12-08 09:03:45 --> Helper loaded: url_helper
INFO - 2021-12-08 09:03:45 --> Helper loaded: file_helper
INFO - 2021-12-08 09:03:45 --> Helper loaded: form_helper
INFO - 2021-12-08 09:03:45 --> Helper loaded: my_helper
INFO - 2021-12-08 09:03:45 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:03:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:03:45 --> Controller Class Initialized
DEBUG - 2021-12-08 09:03:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2021-12-08 09:03:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 09:03:45 --> Final output sent to browser
DEBUG - 2021-12-08 09:03:45 --> Total execution time: 0.0560
INFO - 2021-12-08 09:03:46 --> Config Class Initialized
INFO - 2021-12-08 09:03:46 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:03:46 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:03:46 --> Utf8 Class Initialized
INFO - 2021-12-08 09:03:46 --> URI Class Initialized
INFO - 2021-12-08 09:03:46 --> Router Class Initialized
INFO - 2021-12-08 09:03:46 --> Output Class Initialized
INFO - 2021-12-08 09:03:46 --> Security Class Initialized
DEBUG - 2021-12-08 09:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:03:46 --> Input Class Initialized
INFO - 2021-12-08 09:03:46 --> Language Class Initialized
INFO - 2021-12-08 09:03:46 --> Language Class Initialized
INFO - 2021-12-08 09:03:46 --> Config Class Initialized
INFO - 2021-12-08 09:03:46 --> Loader Class Initialized
INFO - 2021-12-08 09:03:46 --> Helper loaded: url_helper
INFO - 2021-12-08 09:03:46 --> Helper loaded: file_helper
INFO - 2021-12-08 09:03:46 --> Helper loaded: form_helper
INFO - 2021-12-08 09:03:46 --> Helper loaded: my_helper
INFO - 2021-12-08 09:03:46 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:03:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:03:46 --> Controller Class Initialized
DEBUG - 2021-12-08 09:03:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-12-08 09:03:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 09:03:46 --> Final output sent to browser
DEBUG - 2021-12-08 09:03:46 --> Total execution time: 0.0710
INFO - 2021-12-08 09:04:06 --> Config Class Initialized
INFO - 2021-12-08 09:04:06 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:04:06 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:04:06 --> Utf8 Class Initialized
INFO - 2021-12-08 09:04:06 --> URI Class Initialized
INFO - 2021-12-08 09:04:06 --> Router Class Initialized
INFO - 2021-12-08 09:04:06 --> Output Class Initialized
INFO - 2021-12-08 09:04:06 --> Security Class Initialized
DEBUG - 2021-12-08 09:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:04:06 --> Input Class Initialized
INFO - 2021-12-08 09:04:06 --> Language Class Initialized
INFO - 2021-12-08 09:04:06 --> Language Class Initialized
INFO - 2021-12-08 09:04:06 --> Config Class Initialized
INFO - 2021-12-08 09:04:06 --> Loader Class Initialized
INFO - 2021-12-08 09:04:06 --> Helper loaded: url_helper
INFO - 2021-12-08 09:04:06 --> Helper loaded: file_helper
INFO - 2021-12-08 09:04:06 --> Helper loaded: form_helper
INFO - 2021-12-08 09:04:07 --> Helper loaded: my_helper
INFO - 2021-12-08 09:04:07 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:04:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:04:07 --> Controller Class Initialized
INFO - 2021-12-08 09:04:07 --> Final output sent to browser
DEBUG - 2021-12-08 09:04:07 --> Total execution time: 0.0500
INFO - 2021-12-08 09:04:11 --> Config Class Initialized
INFO - 2021-12-08 09:04:11 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:04:11 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:04:11 --> Utf8 Class Initialized
INFO - 2021-12-08 09:04:11 --> URI Class Initialized
INFO - 2021-12-08 09:04:11 --> Router Class Initialized
INFO - 2021-12-08 09:04:11 --> Output Class Initialized
INFO - 2021-12-08 09:04:11 --> Security Class Initialized
DEBUG - 2021-12-08 09:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:04:11 --> Input Class Initialized
INFO - 2021-12-08 09:04:11 --> Language Class Initialized
INFO - 2021-12-08 09:04:11 --> Language Class Initialized
INFO - 2021-12-08 09:04:11 --> Config Class Initialized
INFO - 2021-12-08 09:04:11 --> Loader Class Initialized
INFO - 2021-12-08 09:04:11 --> Helper loaded: url_helper
INFO - 2021-12-08 09:04:11 --> Helper loaded: file_helper
INFO - 2021-12-08 09:04:11 --> Helper loaded: form_helper
INFO - 2021-12-08 09:04:11 --> Helper loaded: my_helper
INFO - 2021-12-08 09:04:11 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:04:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:04:11 --> Controller Class Initialized
INFO - 2021-12-08 09:04:11 --> Final output sent to browser
DEBUG - 2021-12-08 09:04:11 --> Total execution time: 0.0530
INFO - 2021-12-08 09:04:20 --> Config Class Initialized
INFO - 2021-12-08 09:04:20 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:04:20 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:04:20 --> Utf8 Class Initialized
INFO - 2021-12-08 09:04:20 --> URI Class Initialized
INFO - 2021-12-08 09:04:20 --> Router Class Initialized
INFO - 2021-12-08 09:04:20 --> Output Class Initialized
INFO - 2021-12-08 09:04:20 --> Security Class Initialized
DEBUG - 2021-12-08 09:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:04:20 --> Input Class Initialized
INFO - 2021-12-08 09:04:20 --> Language Class Initialized
INFO - 2021-12-08 09:04:20 --> Language Class Initialized
INFO - 2021-12-08 09:04:20 --> Config Class Initialized
INFO - 2021-12-08 09:04:20 --> Loader Class Initialized
INFO - 2021-12-08 09:04:20 --> Helper loaded: url_helper
INFO - 2021-12-08 09:04:20 --> Helper loaded: file_helper
INFO - 2021-12-08 09:04:20 --> Helper loaded: form_helper
INFO - 2021-12-08 09:04:20 --> Helper loaded: my_helper
INFO - 2021-12-08 09:04:20 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:04:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:04:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:04:20 --> Controller Class Initialized
INFO - 2021-12-08 09:04:20 --> Helper loaded: cookie_helper
INFO - 2021-12-08 09:04:20 --> Config Class Initialized
INFO - 2021-12-08 09:04:20 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:04:20 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:04:20 --> Utf8 Class Initialized
INFO - 2021-12-08 09:04:20 --> URI Class Initialized
INFO - 2021-12-08 09:04:20 --> Router Class Initialized
INFO - 2021-12-08 09:04:20 --> Output Class Initialized
INFO - 2021-12-08 09:04:20 --> Security Class Initialized
DEBUG - 2021-12-08 09:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:04:20 --> Input Class Initialized
INFO - 2021-12-08 09:04:20 --> Language Class Initialized
INFO - 2021-12-08 09:04:20 --> Language Class Initialized
INFO - 2021-12-08 09:04:20 --> Config Class Initialized
INFO - 2021-12-08 09:04:20 --> Loader Class Initialized
INFO - 2021-12-08 09:04:20 --> Helper loaded: url_helper
INFO - 2021-12-08 09:04:20 --> Helper loaded: file_helper
INFO - 2021-12-08 09:04:20 --> Helper loaded: form_helper
INFO - 2021-12-08 09:04:20 --> Helper loaded: my_helper
INFO - 2021-12-08 09:04:20 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:04:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:04:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:04:20 --> Controller Class Initialized
DEBUG - 2021-12-08 09:04:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-08 09:04:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 09:04:20 --> Final output sent to browser
DEBUG - 2021-12-08 09:04:20 --> Total execution time: 0.0360
INFO - 2021-12-08 09:04:50 --> Config Class Initialized
INFO - 2021-12-08 09:04:50 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:04:50 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:04:50 --> Utf8 Class Initialized
INFO - 2021-12-08 09:04:50 --> URI Class Initialized
INFO - 2021-12-08 09:04:50 --> Router Class Initialized
INFO - 2021-12-08 09:04:50 --> Output Class Initialized
INFO - 2021-12-08 09:04:50 --> Security Class Initialized
DEBUG - 2021-12-08 09:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:04:50 --> Input Class Initialized
INFO - 2021-12-08 09:04:50 --> Language Class Initialized
INFO - 2021-12-08 09:04:50 --> Language Class Initialized
INFO - 2021-12-08 09:04:50 --> Config Class Initialized
INFO - 2021-12-08 09:04:50 --> Loader Class Initialized
INFO - 2021-12-08 09:04:50 --> Helper loaded: url_helper
INFO - 2021-12-08 09:04:50 --> Helper loaded: file_helper
INFO - 2021-12-08 09:04:50 --> Helper loaded: form_helper
INFO - 2021-12-08 09:04:50 --> Helper loaded: my_helper
INFO - 2021-12-08 09:04:50 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:04:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:04:50 --> Controller Class Initialized
INFO - 2021-12-08 09:04:50 --> Helper loaded: cookie_helper
INFO - 2021-12-08 09:04:50 --> Final output sent to browser
DEBUG - 2021-12-08 09:04:50 --> Total execution time: 0.0570
INFO - 2021-12-08 09:04:52 --> Config Class Initialized
INFO - 2021-12-08 09:04:52 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:04:52 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:04:52 --> Utf8 Class Initialized
INFO - 2021-12-08 09:04:52 --> URI Class Initialized
INFO - 2021-12-08 09:04:52 --> Router Class Initialized
INFO - 2021-12-08 09:04:52 --> Output Class Initialized
INFO - 2021-12-08 09:04:52 --> Security Class Initialized
DEBUG - 2021-12-08 09:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:04:52 --> Input Class Initialized
INFO - 2021-12-08 09:04:52 --> Language Class Initialized
INFO - 2021-12-08 09:04:52 --> Language Class Initialized
INFO - 2021-12-08 09:04:52 --> Config Class Initialized
INFO - 2021-12-08 09:04:52 --> Loader Class Initialized
INFO - 2021-12-08 09:04:52 --> Helper loaded: url_helper
INFO - 2021-12-08 09:04:52 --> Helper loaded: file_helper
INFO - 2021-12-08 09:04:52 --> Helper loaded: form_helper
INFO - 2021-12-08 09:04:52 --> Helper loaded: my_helper
INFO - 2021-12-08 09:04:52 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:04:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:04:52 --> Controller Class Initialized
DEBUG - 2021-12-08 09:04:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-08 09:04:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 09:04:52 --> Final output sent to browser
DEBUG - 2021-12-08 09:04:52 --> Total execution time: 0.2270
INFO - 2021-12-08 09:04:59 --> Config Class Initialized
INFO - 2021-12-08 09:04:59 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:04:59 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:04:59 --> Utf8 Class Initialized
INFO - 2021-12-08 09:04:59 --> URI Class Initialized
INFO - 2021-12-08 09:04:59 --> Router Class Initialized
INFO - 2021-12-08 09:04:59 --> Output Class Initialized
INFO - 2021-12-08 09:04:59 --> Security Class Initialized
DEBUG - 2021-12-08 09:04:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:04:59 --> Input Class Initialized
INFO - 2021-12-08 09:04:59 --> Language Class Initialized
INFO - 2021-12-08 09:04:59 --> Language Class Initialized
INFO - 2021-12-08 09:04:59 --> Config Class Initialized
INFO - 2021-12-08 09:04:59 --> Loader Class Initialized
INFO - 2021-12-08 09:04:59 --> Helper loaded: url_helper
INFO - 2021-12-08 09:04:59 --> Helper loaded: file_helper
INFO - 2021-12-08 09:04:59 --> Helper loaded: form_helper
INFO - 2021-12-08 09:04:59 --> Helper loaded: my_helper
INFO - 2021-12-08 09:04:59 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:04:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:04:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:04:59 --> Controller Class Initialized
DEBUG - 2021-12-08 09:04:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-12-08 09:04:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 09:04:59 --> Final output sent to browser
DEBUG - 2021-12-08 09:04:59 --> Total execution time: 0.0460
INFO - 2021-12-08 09:04:59 --> Config Class Initialized
INFO - 2021-12-08 09:04:59 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:04:59 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:04:59 --> Utf8 Class Initialized
INFO - 2021-12-08 09:04:59 --> URI Class Initialized
INFO - 2021-12-08 09:04:59 --> Router Class Initialized
INFO - 2021-12-08 09:04:59 --> Output Class Initialized
INFO - 2021-12-08 09:04:59 --> Security Class Initialized
DEBUG - 2021-12-08 09:04:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:04:59 --> Input Class Initialized
INFO - 2021-12-08 09:04:59 --> Language Class Initialized
INFO - 2021-12-08 09:04:59 --> Language Class Initialized
INFO - 2021-12-08 09:04:59 --> Config Class Initialized
INFO - 2021-12-08 09:04:59 --> Loader Class Initialized
INFO - 2021-12-08 09:04:59 --> Helper loaded: url_helper
INFO - 2021-12-08 09:04:59 --> Helper loaded: file_helper
INFO - 2021-12-08 09:04:59 --> Helper loaded: form_helper
INFO - 2021-12-08 09:04:59 --> Helper loaded: my_helper
INFO - 2021-12-08 09:04:59 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:05:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:05:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:05:00 --> Controller Class Initialized
INFO - 2021-12-08 09:05:09 --> Config Class Initialized
INFO - 2021-12-08 09:05:09 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:05:09 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:05:09 --> Utf8 Class Initialized
INFO - 2021-12-08 09:05:09 --> URI Class Initialized
INFO - 2021-12-08 09:05:09 --> Router Class Initialized
INFO - 2021-12-08 09:05:09 --> Output Class Initialized
INFO - 2021-12-08 09:05:09 --> Security Class Initialized
DEBUG - 2021-12-08 09:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:05:09 --> Input Class Initialized
INFO - 2021-12-08 09:05:09 --> Language Class Initialized
INFO - 2021-12-08 09:05:09 --> Language Class Initialized
INFO - 2021-12-08 09:05:09 --> Config Class Initialized
INFO - 2021-12-08 09:05:09 --> Loader Class Initialized
INFO - 2021-12-08 09:05:09 --> Helper loaded: url_helper
INFO - 2021-12-08 09:05:09 --> Helper loaded: file_helper
INFO - 2021-12-08 09:05:09 --> Helper loaded: form_helper
INFO - 2021-12-08 09:05:09 --> Helper loaded: my_helper
INFO - 2021-12-08 09:05:09 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:05:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:05:09 --> Controller Class Initialized
INFO - 2021-12-08 09:05:09 --> Final output sent to browser
DEBUG - 2021-12-08 09:05:09 --> Total execution time: 0.0560
INFO - 2021-12-08 09:05:09 --> Config Class Initialized
INFO - 2021-12-08 09:05:09 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:05:09 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:05:09 --> Utf8 Class Initialized
INFO - 2021-12-08 09:05:09 --> URI Class Initialized
INFO - 2021-12-08 09:05:09 --> Router Class Initialized
INFO - 2021-12-08 09:05:09 --> Output Class Initialized
INFO - 2021-12-08 09:05:09 --> Security Class Initialized
DEBUG - 2021-12-08 09:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:05:09 --> Input Class Initialized
INFO - 2021-12-08 09:05:09 --> Language Class Initialized
INFO - 2021-12-08 09:05:09 --> Language Class Initialized
INFO - 2021-12-08 09:05:09 --> Config Class Initialized
INFO - 2021-12-08 09:05:09 --> Loader Class Initialized
INFO - 2021-12-08 09:05:09 --> Helper loaded: url_helper
INFO - 2021-12-08 09:05:09 --> Helper loaded: file_helper
INFO - 2021-12-08 09:05:09 --> Helper loaded: form_helper
INFO - 2021-12-08 09:05:09 --> Helper loaded: my_helper
INFO - 2021-12-08 09:05:09 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:05:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:05:09 --> Controller Class Initialized
INFO - 2021-12-08 09:05:28 --> Config Class Initialized
INFO - 2021-12-08 09:05:28 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:05:28 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:05:28 --> Utf8 Class Initialized
INFO - 2021-12-08 09:05:28 --> URI Class Initialized
INFO - 2021-12-08 09:05:28 --> Router Class Initialized
INFO - 2021-12-08 09:05:28 --> Output Class Initialized
INFO - 2021-12-08 09:05:28 --> Security Class Initialized
DEBUG - 2021-12-08 09:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:05:28 --> Input Class Initialized
INFO - 2021-12-08 09:05:28 --> Language Class Initialized
INFO - 2021-12-08 09:05:28 --> Language Class Initialized
INFO - 2021-12-08 09:05:28 --> Config Class Initialized
INFO - 2021-12-08 09:05:28 --> Loader Class Initialized
INFO - 2021-12-08 09:05:28 --> Helper loaded: url_helper
INFO - 2021-12-08 09:05:28 --> Helper loaded: file_helper
INFO - 2021-12-08 09:05:28 --> Helper loaded: form_helper
INFO - 2021-12-08 09:05:28 --> Helper loaded: my_helper
INFO - 2021-12-08 09:05:28 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:05:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:05:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:05:28 --> Controller Class Initialized
INFO - 2021-12-08 09:05:28 --> Helper loaded: cookie_helper
INFO - 2021-12-08 09:05:28 --> Config Class Initialized
INFO - 2021-12-08 09:05:28 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:05:28 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:05:28 --> Utf8 Class Initialized
INFO - 2021-12-08 09:05:28 --> URI Class Initialized
INFO - 2021-12-08 09:05:28 --> Router Class Initialized
INFO - 2021-12-08 09:05:28 --> Output Class Initialized
INFO - 2021-12-08 09:05:28 --> Security Class Initialized
DEBUG - 2021-12-08 09:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:05:28 --> Input Class Initialized
INFO - 2021-12-08 09:05:28 --> Language Class Initialized
INFO - 2021-12-08 09:05:28 --> Language Class Initialized
INFO - 2021-12-08 09:05:28 --> Config Class Initialized
INFO - 2021-12-08 09:05:28 --> Loader Class Initialized
INFO - 2021-12-08 09:05:28 --> Helper loaded: url_helper
INFO - 2021-12-08 09:05:28 --> Helper loaded: file_helper
INFO - 2021-12-08 09:05:28 --> Helper loaded: form_helper
INFO - 2021-12-08 09:05:28 --> Helper loaded: my_helper
INFO - 2021-12-08 09:05:28 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:05:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:05:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:05:28 --> Controller Class Initialized
DEBUG - 2021-12-08 09:05:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-08 09:05:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 09:05:28 --> Final output sent to browser
DEBUG - 2021-12-08 09:05:28 --> Total execution time: 0.0360
INFO - 2021-12-08 09:05:42 --> Config Class Initialized
INFO - 2021-12-08 09:05:42 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:05:42 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:05:42 --> Utf8 Class Initialized
INFO - 2021-12-08 09:05:42 --> URI Class Initialized
INFO - 2021-12-08 09:05:42 --> Router Class Initialized
INFO - 2021-12-08 09:05:42 --> Output Class Initialized
INFO - 2021-12-08 09:05:42 --> Security Class Initialized
DEBUG - 2021-12-08 09:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:05:42 --> Input Class Initialized
INFO - 2021-12-08 09:05:42 --> Language Class Initialized
INFO - 2021-12-08 09:05:42 --> Language Class Initialized
INFO - 2021-12-08 09:05:42 --> Config Class Initialized
INFO - 2021-12-08 09:05:42 --> Loader Class Initialized
INFO - 2021-12-08 09:05:42 --> Helper loaded: url_helper
INFO - 2021-12-08 09:05:42 --> Helper loaded: file_helper
INFO - 2021-12-08 09:05:42 --> Helper loaded: form_helper
INFO - 2021-12-08 09:05:42 --> Helper loaded: my_helper
INFO - 2021-12-08 09:05:42 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:05:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:05:42 --> Controller Class Initialized
INFO - 2021-12-08 09:05:42 --> Helper loaded: cookie_helper
INFO - 2021-12-08 09:05:42 --> Final output sent to browser
DEBUG - 2021-12-08 09:05:42 --> Total execution time: 0.0480
INFO - 2021-12-08 09:05:44 --> Config Class Initialized
INFO - 2021-12-08 09:05:44 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:05:44 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:05:44 --> Utf8 Class Initialized
INFO - 2021-12-08 09:05:44 --> URI Class Initialized
INFO - 2021-12-08 09:05:44 --> Router Class Initialized
INFO - 2021-12-08 09:05:44 --> Output Class Initialized
INFO - 2021-12-08 09:05:44 --> Security Class Initialized
DEBUG - 2021-12-08 09:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:05:44 --> Input Class Initialized
INFO - 2021-12-08 09:05:44 --> Language Class Initialized
INFO - 2021-12-08 09:05:44 --> Language Class Initialized
INFO - 2021-12-08 09:05:44 --> Config Class Initialized
INFO - 2021-12-08 09:05:44 --> Loader Class Initialized
INFO - 2021-12-08 09:05:44 --> Helper loaded: url_helper
INFO - 2021-12-08 09:05:44 --> Helper loaded: file_helper
INFO - 2021-12-08 09:05:44 --> Helper loaded: form_helper
INFO - 2021-12-08 09:05:44 --> Helper loaded: my_helper
INFO - 2021-12-08 09:05:44 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:05:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:05:44 --> Controller Class Initialized
DEBUG - 2021-12-08 09:05:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-08 09:05:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 09:05:44 --> Final output sent to browser
DEBUG - 2021-12-08 09:05:44 --> Total execution time: 0.1790
INFO - 2021-12-08 09:05:47 --> Config Class Initialized
INFO - 2021-12-08 09:05:47 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:05:47 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:05:47 --> Utf8 Class Initialized
INFO - 2021-12-08 09:05:47 --> URI Class Initialized
INFO - 2021-12-08 09:05:47 --> Router Class Initialized
INFO - 2021-12-08 09:05:48 --> Output Class Initialized
INFO - 2021-12-08 09:05:48 --> Security Class Initialized
DEBUG - 2021-12-08 09:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:05:48 --> Input Class Initialized
INFO - 2021-12-08 09:05:48 --> Language Class Initialized
INFO - 2021-12-08 09:05:48 --> Language Class Initialized
INFO - 2021-12-08 09:05:48 --> Config Class Initialized
INFO - 2021-12-08 09:05:48 --> Loader Class Initialized
INFO - 2021-12-08 09:05:48 --> Helper loaded: url_helper
INFO - 2021-12-08 09:05:48 --> Helper loaded: file_helper
INFO - 2021-12-08 09:05:48 --> Helper loaded: form_helper
INFO - 2021-12-08 09:05:48 --> Helper loaded: my_helper
INFO - 2021-12-08 09:05:48 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:05:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:05:48 --> Controller Class Initialized
DEBUG - 2021-12-08 09:05:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-08 09:05:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 09:05:48 --> Final output sent to browser
DEBUG - 2021-12-08 09:05:48 --> Total execution time: 0.1160
INFO - 2021-12-08 09:19:11 --> Config Class Initialized
INFO - 2021-12-08 09:19:11 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:19:11 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:19:11 --> Utf8 Class Initialized
INFO - 2021-12-08 09:19:11 --> URI Class Initialized
INFO - 2021-12-08 09:19:11 --> Router Class Initialized
INFO - 2021-12-08 09:19:11 --> Output Class Initialized
INFO - 2021-12-08 09:19:11 --> Security Class Initialized
DEBUG - 2021-12-08 09:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:19:11 --> Input Class Initialized
INFO - 2021-12-08 09:19:11 --> Language Class Initialized
INFO - 2021-12-08 09:19:11 --> Language Class Initialized
INFO - 2021-12-08 09:19:11 --> Config Class Initialized
INFO - 2021-12-08 09:19:11 --> Loader Class Initialized
INFO - 2021-12-08 09:19:11 --> Helper loaded: url_helper
INFO - 2021-12-08 09:19:11 --> Helper loaded: file_helper
INFO - 2021-12-08 09:19:11 --> Helper loaded: form_helper
INFO - 2021-12-08 09:19:11 --> Helper loaded: my_helper
INFO - 2021-12-08 09:19:11 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:19:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:19:11 --> Controller Class Initialized
INFO - 2021-12-08 09:19:11 --> Final output sent to browser
DEBUG - 2021-12-08 09:19:11 --> Total execution time: 0.0580
INFO - 2021-12-08 09:19:33 --> Config Class Initialized
INFO - 2021-12-08 09:19:33 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:19:33 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:19:33 --> Utf8 Class Initialized
INFO - 2021-12-08 09:19:33 --> URI Class Initialized
INFO - 2021-12-08 09:19:33 --> Router Class Initialized
INFO - 2021-12-08 09:19:33 --> Output Class Initialized
INFO - 2021-12-08 09:19:33 --> Security Class Initialized
DEBUG - 2021-12-08 09:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:19:33 --> Input Class Initialized
INFO - 2021-12-08 09:19:33 --> Language Class Initialized
INFO - 2021-12-08 09:19:33 --> Language Class Initialized
INFO - 2021-12-08 09:19:33 --> Config Class Initialized
INFO - 2021-12-08 09:19:33 --> Loader Class Initialized
INFO - 2021-12-08 09:19:33 --> Helper loaded: url_helper
INFO - 2021-12-08 09:19:33 --> Helper loaded: file_helper
INFO - 2021-12-08 09:19:33 --> Helper loaded: form_helper
INFO - 2021-12-08 09:19:33 --> Helper loaded: my_helper
INFO - 2021-12-08 09:19:33 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:19:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:19:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:19:33 --> Controller Class Initialized
DEBUG - 2021-12-08 09:19:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-12-08 09:19:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 09:19:33 --> Final output sent to browser
DEBUG - 2021-12-08 09:19:33 --> Total execution time: 0.0630
INFO - 2021-12-08 09:19:34 --> Config Class Initialized
INFO - 2021-12-08 09:19:34 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:19:34 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:19:34 --> Utf8 Class Initialized
INFO - 2021-12-08 09:19:34 --> URI Class Initialized
INFO - 2021-12-08 09:19:34 --> Router Class Initialized
INFO - 2021-12-08 09:19:34 --> Output Class Initialized
INFO - 2021-12-08 09:19:34 --> Security Class Initialized
DEBUG - 2021-12-08 09:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:19:34 --> Input Class Initialized
INFO - 2021-12-08 09:19:34 --> Language Class Initialized
INFO - 2021-12-08 09:19:34 --> Language Class Initialized
INFO - 2021-12-08 09:19:34 --> Config Class Initialized
INFO - 2021-12-08 09:19:34 --> Loader Class Initialized
INFO - 2021-12-08 09:19:34 --> Helper loaded: url_helper
INFO - 2021-12-08 09:19:34 --> Helper loaded: file_helper
INFO - 2021-12-08 09:19:34 --> Helper loaded: form_helper
INFO - 2021-12-08 09:19:34 --> Helper loaded: my_helper
INFO - 2021-12-08 09:19:34 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:19:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:19:34 --> Controller Class Initialized
DEBUG - 2021-12-08 09:19:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-08 09:19:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 09:19:35 --> Final output sent to browser
DEBUG - 2021-12-08 09:19:35 --> Total execution time: 0.0940
INFO - 2021-12-08 09:19:36 --> Config Class Initialized
INFO - 2021-12-08 09:19:36 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:19:36 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:19:36 --> Utf8 Class Initialized
INFO - 2021-12-08 09:19:36 --> URI Class Initialized
INFO - 2021-12-08 09:19:36 --> Router Class Initialized
INFO - 2021-12-08 09:19:36 --> Output Class Initialized
INFO - 2021-12-08 09:19:36 --> Security Class Initialized
DEBUG - 2021-12-08 09:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:19:36 --> Input Class Initialized
INFO - 2021-12-08 09:19:36 --> Language Class Initialized
INFO - 2021-12-08 09:19:36 --> Language Class Initialized
INFO - 2021-12-08 09:19:36 --> Config Class Initialized
INFO - 2021-12-08 09:19:36 --> Loader Class Initialized
INFO - 2021-12-08 09:19:36 --> Helper loaded: url_helper
INFO - 2021-12-08 09:19:36 --> Helper loaded: file_helper
INFO - 2021-12-08 09:19:36 --> Helper loaded: form_helper
INFO - 2021-12-08 09:19:36 --> Helper loaded: my_helper
INFO - 2021-12-08 09:19:36 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:19:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:19:36 --> Controller Class Initialized
DEBUG - 2021-12-08 09:19:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-12-08 09:19:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 09:19:36 --> Final output sent to browser
DEBUG - 2021-12-08 09:19:36 --> Total execution time: 0.0670
INFO - 2021-12-08 09:19:38 --> Config Class Initialized
INFO - 2021-12-08 09:19:38 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:19:38 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:19:38 --> Utf8 Class Initialized
INFO - 2021-12-08 09:19:38 --> URI Class Initialized
INFO - 2021-12-08 09:19:38 --> Router Class Initialized
INFO - 2021-12-08 09:19:38 --> Output Class Initialized
INFO - 2021-12-08 09:19:38 --> Security Class Initialized
DEBUG - 2021-12-08 09:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:19:38 --> Input Class Initialized
INFO - 2021-12-08 09:19:38 --> Language Class Initialized
INFO - 2021-12-08 09:19:38 --> Language Class Initialized
INFO - 2021-12-08 09:19:38 --> Config Class Initialized
INFO - 2021-12-08 09:19:38 --> Loader Class Initialized
INFO - 2021-12-08 09:19:38 --> Helper loaded: url_helper
INFO - 2021-12-08 09:19:38 --> Helper loaded: file_helper
INFO - 2021-12-08 09:19:38 --> Helper loaded: form_helper
INFO - 2021-12-08 09:19:38 --> Helper loaded: my_helper
INFO - 2021-12-08 09:19:38 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:19:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:19:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:19:38 --> Controller Class Initialized
DEBUG - 2021-12-08 09:19:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-12-08 09:19:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 09:19:38 --> Final output sent to browser
DEBUG - 2021-12-08 09:19:38 --> Total execution time: 0.0480
INFO - 2021-12-08 09:19:42 --> Config Class Initialized
INFO - 2021-12-08 09:19:42 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:19:42 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:19:42 --> Utf8 Class Initialized
INFO - 2021-12-08 09:19:42 --> URI Class Initialized
INFO - 2021-12-08 09:19:42 --> Router Class Initialized
INFO - 2021-12-08 09:19:42 --> Output Class Initialized
INFO - 2021-12-08 09:19:42 --> Security Class Initialized
DEBUG - 2021-12-08 09:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:19:42 --> Input Class Initialized
INFO - 2021-12-08 09:19:42 --> Language Class Initialized
INFO - 2021-12-08 09:19:42 --> Language Class Initialized
INFO - 2021-12-08 09:19:42 --> Config Class Initialized
INFO - 2021-12-08 09:19:42 --> Loader Class Initialized
INFO - 2021-12-08 09:19:42 --> Helper loaded: url_helper
INFO - 2021-12-08 09:19:42 --> Helper loaded: file_helper
INFO - 2021-12-08 09:19:42 --> Helper loaded: form_helper
INFO - 2021-12-08 09:19:42 --> Helper loaded: my_helper
INFO - 2021-12-08 09:19:42 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:19:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:19:42 --> Controller Class Initialized
INFO - 2021-12-08 09:19:42 --> Final output sent to browser
DEBUG - 2021-12-08 09:19:42 --> Total execution time: 0.0510
INFO - 2021-12-08 09:19:45 --> Config Class Initialized
INFO - 2021-12-08 09:19:45 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:19:45 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:19:45 --> Utf8 Class Initialized
INFO - 2021-12-08 09:19:45 --> URI Class Initialized
INFO - 2021-12-08 09:19:45 --> Router Class Initialized
INFO - 2021-12-08 09:19:45 --> Output Class Initialized
INFO - 2021-12-08 09:19:45 --> Security Class Initialized
DEBUG - 2021-12-08 09:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:19:45 --> Input Class Initialized
INFO - 2021-12-08 09:19:45 --> Language Class Initialized
INFO - 2021-12-08 09:19:45 --> Language Class Initialized
INFO - 2021-12-08 09:19:45 --> Config Class Initialized
INFO - 2021-12-08 09:19:45 --> Loader Class Initialized
INFO - 2021-12-08 09:19:45 --> Helper loaded: url_helper
INFO - 2021-12-08 09:19:45 --> Helper loaded: file_helper
INFO - 2021-12-08 09:19:45 --> Helper loaded: form_helper
INFO - 2021-12-08 09:19:45 --> Helper loaded: my_helper
INFO - 2021-12-08 09:19:45 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:19:45 --> Controller Class Initialized
DEBUG - 2021-12-08 09:19:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-08 09:19:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 09:19:45 --> Final output sent to browser
DEBUG - 2021-12-08 09:19:45 --> Total execution time: 0.0840
INFO - 2021-12-08 09:19:47 --> Config Class Initialized
INFO - 2021-12-08 09:19:47 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:19:47 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:19:47 --> Utf8 Class Initialized
INFO - 2021-12-08 09:19:47 --> URI Class Initialized
INFO - 2021-12-08 09:19:47 --> Router Class Initialized
INFO - 2021-12-08 09:19:47 --> Output Class Initialized
INFO - 2021-12-08 09:19:47 --> Security Class Initialized
DEBUG - 2021-12-08 09:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:19:47 --> Input Class Initialized
INFO - 2021-12-08 09:19:47 --> Language Class Initialized
INFO - 2021-12-08 09:19:47 --> Language Class Initialized
INFO - 2021-12-08 09:19:47 --> Config Class Initialized
INFO - 2021-12-08 09:19:47 --> Loader Class Initialized
INFO - 2021-12-08 09:19:47 --> Helper loaded: url_helper
INFO - 2021-12-08 09:19:47 --> Helper loaded: file_helper
INFO - 2021-12-08 09:19:47 --> Helper loaded: form_helper
INFO - 2021-12-08 09:19:47 --> Helper loaded: my_helper
INFO - 2021-12-08 09:19:47 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:19:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:19:47 --> Controller Class Initialized
DEBUG - 2021-12-08 09:19:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-12-08 09:19:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 09:19:47 --> Final output sent to browser
DEBUG - 2021-12-08 09:19:47 --> Total execution time: 0.0640
INFO - 2021-12-08 09:24:18 --> Config Class Initialized
INFO - 2021-12-08 09:24:18 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:24:18 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:24:18 --> Utf8 Class Initialized
INFO - 2021-12-08 09:24:18 --> URI Class Initialized
INFO - 2021-12-08 09:24:18 --> Router Class Initialized
INFO - 2021-12-08 09:24:18 --> Output Class Initialized
INFO - 2021-12-08 09:24:18 --> Security Class Initialized
DEBUG - 2021-12-08 09:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:24:18 --> Input Class Initialized
INFO - 2021-12-08 09:24:18 --> Language Class Initialized
INFO - 2021-12-08 09:24:18 --> Language Class Initialized
INFO - 2021-12-08 09:24:18 --> Config Class Initialized
INFO - 2021-12-08 09:24:18 --> Loader Class Initialized
INFO - 2021-12-08 09:24:18 --> Helper loaded: url_helper
INFO - 2021-12-08 09:24:18 --> Helper loaded: file_helper
INFO - 2021-12-08 09:24:18 --> Helper loaded: form_helper
INFO - 2021-12-08 09:24:18 --> Helper loaded: my_helper
INFO - 2021-12-08 09:24:18 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:24:18 --> Controller Class Initialized
INFO - 2021-12-08 09:24:18 --> Final output sent to browser
DEBUG - 2021-12-08 09:24:18 --> Total execution time: 0.0880
INFO - 2021-12-08 09:24:29 --> Config Class Initialized
INFO - 2021-12-08 09:24:29 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:24:29 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:24:29 --> Utf8 Class Initialized
INFO - 2021-12-08 09:24:29 --> URI Class Initialized
INFO - 2021-12-08 09:24:29 --> Router Class Initialized
INFO - 2021-12-08 09:24:29 --> Output Class Initialized
INFO - 2021-12-08 09:24:29 --> Security Class Initialized
DEBUG - 2021-12-08 09:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:24:29 --> Input Class Initialized
INFO - 2021-12-08 09:24:29 --> Language Class Initialized
INFO - 2021-12-08 09:24:29 --> Language Class Initialized
INFO - 2021-12-08 09:24:29 --> Config Class Initialized
INFO - 2021-12-08 09:24:29 --> Loader Class Initialized
INFO - 2021-12-08 09:24:29 --> Helper loaded: url_helper
INFO - 2021-12-08 09:24:29 --> Helper loaded: file_helper
INFO - 2021-12-08 09:24:29 --> Helper loaded: form_helper
INFO - 2021-12-08 09:24:29 --> Helper loaded: my_helper
INFO - 2021-12-08 09:24:29 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:24:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:24:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:24:29 --> Controller Class Initialized
INFO - 2021-12-08 09:24:30 --> Final output sent to browser
DEBUG - 2021-12-08 09:24:30 --> Total execution time: 0.0780
INFO - 2021-12-08 09:24:34 --> Config Class Initialized
INFO - 2021-12-08 09:24:34 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:24:34 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:24:34 --> Utf8 Class Initialized
INFO - 2021-12-08 09:24:34 --> URI Class Initialized
INFO - 2021-12-08 09:24:34 --> Router Class Initialized
INFO - 2021-12-08 09:24:34 --> Output Class Initialized
INFO - 2021-12-08 09:24:34 --> Security Class Initialized
DEBUG - 2021-12-08 09:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:24:34 --> Input Class Initialized
INFO - 2021-12-08 09:24:34 --> Language Class Initialized
INFO - 2021-12-08 09:24:34 --> Language Class Initialized
INFO - 2021-12-08 09:24:34 --> Config Class Initialized
INFO - 2021-12-08 09:24:34 --> Loader Class Initialized
INFO - 2021-12-08 09:24:34 --> Helper loaded: url_helper
INFO - 2021-12-08 09:24:34 --> Helper loaded: file_helper
INFO - 2021-12-08 09:24:34 --> Helper loaded: form_helper
INFO - 2021-12-08 09:24:34 --> Helper loaded: my_helper
INFO - 2021-12-08 09:24:34 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:24:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:24:34 --> Controller Class Initialized
DEBUG - 2021-12-08 09:24:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-12-08 09:24:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 09:24:34 --> Final output sent to browser
DEBUG - 2021-12-08 09:24:34 --> Total execution time: 0.0520
INFO - 2021-12-08 09:24:35 --> Config Class Initialized
INFO - 2021-12-08 09:24:35 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:24:35 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:24:35 --> Utf8 Class Initialized
INFO - 2021-12-08 09:24:35 --> URI Class Initialized
INFO - 2021-12-08 09:24:35 --> Router Class Initialized
INFO - 2021-12-08 09:24:35 --> Output Class Initialized
INFO - 2021-12-08 09:24:35 --> Security Class Initialized
DEBUG - 2021-12-08 09:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:24:35 --> Input Class Initialized
INFO - 2021-12-08 09:24:35 --> Language Class Initialized
INFO - 2021-12-08 09:24:35 --> Language Class Initialized
INFO - 2021-12-08 09:24:35 --> Config Class Initialized
INFO - 2021-12-08 09:24:35 --> Loader Class Initialized
INFO - 2021-12-08 09:24:35 --> Helper loaded: url_helper
INFO - 2021-12-08 09:24:35 --> Helper loaded: file_helper
INFO - 2021-12-08 09:24:35 --> Helper loaded: form_helper
INFO - 2021-12-08 09:24:35 --> Helper loaded: my_helper
INFO - 2021-12-08 09:24:35 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:24:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:24:35 --> Controller Class Initialized
INFO - 2021-12-08 09:24:35 --> Final output sent to browser
DEBUG - 2021-12-08 09:24:35 --> Total execution time: 0.0500
INFO - 2021-12-08 09:25:33 --> Config Class Initialized
INFO - 2021-12-08 09:25:33 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:25:33 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:25:33 --> Utf8 Class Initialized
INFO - 2021-12-08 09:25:33 --> URI Class Initialized
INFO - 2021-12-08 09:25:33 --> Router Class Initialized
INFO - 2021-12-08 09:25:33 --> Output Class Initialized
INFO - 2021-12-08 09:25:33 --> Security Class Initialized
DEBUG - 2021-12-08 09:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:25:33 --> Input Class Initialized
INFO - 2021-12-08 09:25:33 --> Language Class Initialized
INFO - 2021-12-08 09:25:33 --> Language Class Initialized
INFO - 2021-12-08 09:25:33 --> Config Class Initialized
INFO - 2021-12-08 09:25:33 --> Loader Class Initialized
INFO - 2021-12-08 09:25:33 --> Helper loaded: url_helper
INFO - 2021-12-08 09:25:33 --> Helper loaded: file_helper
INFO - 2021-12-08 09:25:33 --> Helper loaded: form_helper
INFO - 2021-12-08 09:25:33 --> Helper loaded: my_helper
INFO - 2021-12-08 09:25:33 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:25:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:25:33 --> Controller Class Initialized
INFO - 2021-12-08 09:25:33 --> Final output sent to browser
DEBUG - 2021-12-08 09:25:33 --> Total execution time: 0.0890
INFO - 2021-12-08 09:25:38 --> Config Class Initialized
INFO - 2021-12-08 09:25:38 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:25:38 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:25:38 --> Utf8 Class Initialized
INFO - 2021-12-08 09:25:38 --> URI Class Initialized
INFO - 2021-12-08 09:25:38 --> Router Class Initialized
INFO - 2021-12-08 09:25:38 --> Output Class Initialized
INFO - 2021-12-08 09:25:38 --> Security Class Initialized
DEBUG - 2021-12-08 09:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:25:38 --> Input Class Initialized
INFO - 2021-12-08 09:25:38 --> Language Class Initialized
INFO - 2021-12-08 09:25:38 --> Language Class Initialized
INFO - 2021-12-08 09:25:38 --> Config Class Initialized
INFO - 2021-12-08 09:25:38 --> Loader Class Initialized
INFO - 2021-12-08 09:25:38 --> Helper loaded: url_helper
INFO - 2021-12-08 09:25:38 --> Helper loaded: file_helper
INFO - 2021-12-08 09:25:38 --> Helper loaded: form_helper
INFO - 2021-12-08 09:25:38 --> Helper loaded: my_helper
INFO - 2021-12-08 09:25:38 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:25:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:25:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:25:38 --> Controller Class Initialized
DEBUG - 2021-12-08 09:25:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-08 09:25:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 09:25:38 --> Final output sent to browser
DEBUG - 2021-12-08 09:25:38 --> Total execution time: 0.0790
INFO - 2021-12-08 09:25:45 --> Config Class Initialized
INFO - 2021-12-08 09:25:45 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:25:45 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:25:45 --> Utf8 Class Initialized
INFO - 2021-12-08 09:25:45 --> URI Class Initialized
INFO - 2021-12-08 09:25:45 --> Router Class Initialized
INFO - 2021-12-08 09:25:45 --> Output Class Initialized
INFO - 2021-12-08 09:25:45 --> Security Class Initialized
DEBUG - 2021-12-08 09:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:25:45 --> Input Class Initialized
INFO - 2021-12-08 09:25:45 --> Language Class Initialized
INFO - 2021-12-08 09:25:45 --> Language Class Initialized
INFO - 2021-12-08 09:25:45 --> Config Class Initialized
INFO - 2021-12-08 09:25:45 --> Loader Class Initialized
INFO - 2021-12-08 09:25:45 --> Helper loaded: url_helper
INFO - 2021-12-08 09:25:45 --> Helper loaded: file_helper
INFO - 2021-12-08 09:25:45 --> Helper loaded: form_helper
INFO - 2021-12-08 09:25:45 --> Helper loaded: my_helper
INFO - 2021-12-08 09:25:45 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:25:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:25:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:25:45 --> Controller Class Initialized
DEBUG - 2021-12-08 09:25:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-08 09:25:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 09:25:45 --> Final output sent to browser
DEBUG - 2021-12-08 09:25:45 --> Total execution time: 0.0760
INFO - 2021-12-08 09:25:47 --> Config Class Initialized
INFO - 2021-12-08 09:25:47 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:25:47 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:25:47 --> Utf8 Class Initialized
INFO - 2021-12-08 09:25:47 --> URI Class Initialized
INFO - 2021-12-08 09:25:47 --> Router Class Initialized
INFO - 2021-12-08 09:25:47 --> Output Class Initialized
INFO - 2021-12-08 09:25:47 --> Security Class Initialized
DEBUG - 2021-12-08 09:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:25:47 --> Input Class Initialized
INFO - 2021-12-08 09:25:47 --> Language Class Initialized
INFO - 2021-12-08 09:25:47 --> Language Class Initialized
INFO - 2021-12-08 09:25:47 --> Config Class Initialized
INFO - 2021-12-08 09:25:47 --> Loader Class Initialized
INFO - 2021-12-08 09:25:47 --> Helper loaded: url_helper
INFO - 2021-12-08 09:25:47 --> Helper loaded: file_helper
INFO - 2021-12-08 09:25:47 --> Helper loaded: form_helper
INFO - 2021-12-08 09:25:47 --> Helper loaded: my_helper
INFO - 2021-12-08 09:25:47 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:25:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:25:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:25:47 --> Controller Class Initialized
DEBUG - 2021-12-08 09:25:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-12-08 09:25:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 09:25:47 --> Final output sent to browser
DEBUG - 2021-12-08 09:25:47 --> Total execution time: 0.0510
INFO - 2021-12-08 09:25:48 --> Config Class Initialized
INFO - 2021-12-08 09:25:48 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:25:48 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:25:48 --> Utf8 Class Initialized
INFO - 2021-12-08 09:25:48 --> URI Class Initialized
INFO - 2021-12-08 09:25:48 --> Router Class Initialized
INFO - 2021-12-08 09:25:48 --> Output Class Initialized
INFO - 2021-12-08 09:25:48 --> Security Class Initialized
DEBUG - 2021-12-08 09:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:25:48 --> Input Class Initialized
INFO - 2021-12-08 09:25:48 --> Language Class Initialized
INFO - 2021-12-08 09:25:48 --> Language Class Initialized
INFO - 2021-12-08 09:25:48 --> Config Class Initialized
INFO - 2021-12-08 09:25:48 --> Loader Class Initialized
INFO - 2021-12-08 09:25:48 --> Helper loaded: url_helper
INFO - 2021-12-08 09:25:48 --> Helper loaded: file_helper
INFO - 2021-12-08 09:25:48 --> Helper loaded: form_helper
INFO - 2021-12-08 09:25:48 --> Helper loaded: my_helper
INFO - 2021-12-08 09:25:48 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:25:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:25:48 --> Controller Class Initialized
DEBUG - 2021-12-08 09:25:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-12-08 09:25:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 09:25:48 --> Final output sent to browser
DEBUG - 2021-12-08 09:25:48 --> Total execution time: 0.0590
INFO - 2021-12-08 09:25:50 --> Config Class Initialized
INFO - 2021-12-08 09:25:50 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:25:50 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:25:50 --> Utf8 Class Initialized
INFO - 2021-12-08 09:25:50 --> URI Class Initialized
INFO - 2021-12-08 09:25:50 --> Router Class Initialized
INFO - 2021-12-08 09:25:50 --> Output Class Initialized
INFO - 2021-12-08 09:25:50 --> Security Class Initialized
DEBUG - 2021-12-08 09:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:25:50 --> Input Class Initialized
INFO - 2021-12-08 09:25:50 --> Language Class Initialized
INFO - 2021-12-08 09:25:50 --> Language Class Initialized
INFO - 2021-12-08 09:25:50 --> Config Class Initialized
INFO - 2021-12-08 09:25:50 --> Loader Class Initialized
INFO - 2021-12-08 09:25:50 --> Helper loaded: url_helper
INFO - 2021-12-08 09:25:50 --> Helper loaded: file_helper
INFO - 2021-12-08 09:25:50 --> Helper loaded: form_helper
INFO - 2021-12-08 09:25:50 --> Helper loaded: my_helper
INFO - 2021-12-08 09:25:50 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:25:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:25:50 --> Controller Class Initialized
INFO - 2021-12-08 09:25:50 --> Final output sent to browser
DEBUG - 2021-12-08 09:25:50 --> Total execution time: 0.0460
INFO - 2021-12-08 09:25:54 --> Config Class Initialized
INFO - 2021-12-08 09:25:54 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:25:54 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:25:54 --> Utf8 Class Initialized
INFO - 2021-12-08 09:25:54 --> URI Class Initialized
INFO - 2021-12-08 09:25:54 --> Router Class Initialized
INFO - 2021-12-08 09:25:54 --> Output Class Initialized
INFO - 2021-12-08 09:25:54 --> Security Class Initialized
DEBUG - 2021-12-08 09:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:25:54 --> Input Class Initialized
INFO - 2021-12-08 09:25:54 --> Language Class Initialized
INFO - 2021-12-08 09:25:54 --> Language Class Initialized
INFO - 2021-12-08 09:25:54 --> Config Class Initialized
INFO - 2021-12-08 09:25:54 --> Loader Class Initialized
INFO - 2021-12-08 09:25:54 --> Helper loaded: url_helper
INFO - 2021-12-08 09:25:54 --> Helper loaded: file_helper
INFO - 2021-12-08 09:25:54 --> Helper loaded: form_helper
INFO - 2021-12-08 09:25:54 --> Helper loaded: my_helper
INFO - 2021-12-08 09:25:54 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:25:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:25:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:25:54 --> Controller Class Initialized
INFO - 2021-12-08 09:25:54 --> Final output sent to browser
DEBUG - 2021-12-08 09:25:54 --> Total execution time: 0.0940
INFO - 2021-12-08 09:26:05 --> Config Class Initialized
INFO - 2021-12-08 09:26:05 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:26:05 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:26:05 --> Utf8 Class Initialized
INFO - 2021-12-08 09:26:05 --> URI Class Initialized
INFO - 2021-12-08 09:26:05 --> Router Class Initialized
INFO - 2021-12-08 09:26:05 --> Output Class Initialized
INFO - 2021-12-08 09:26:05 --> Security Class Initialized
DEBUG - 2021-12-08 09:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:26:05 --> Input Class Initialized
INFO - 2021-12-08 09:26:05 --> Language Class Initialized
INFO - 2021-12-08 09:26:05 --> Language Class Initialized
INFO - 2021-12-08 09:26:05 --> Config Class Initialized
INFO - 2021-12-08 09:26:05 --> Loader Class Initialized
INFO - 2021-12-08 09:26:05 --> Helper loaded: url_helper
INFO - 2021-12-08 09:26:05 --> Helper loaded: file_helper
INFO - 2021-12-08 09:26:05 --> Helper loaded: form_helper
INFO - 2021-12-08 09:26:05 --> Helper loaded: my_helper
INFO - 2021-12-08 09:26:05 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:26:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:26:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:26:05 --> Controller Class Initialized
DEBUG - 2021-12-08 09:26:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-12-08 09:26:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 09:26:05 --> Final output sent to browser
DEBUG - 2021-12-08 09:26:05 --> Total execution time: 0.0680
INFO - 2021-12-08 09:27:35 --> Config Class Initialized
INFO - 2021-12-08 09:27:35 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:27:35 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:27:35 --> Utf8 Class Initialized
INFO - 2021-12-08 09:27:35 --> URI Class Initialized
INFO - 2021-12-08 09:27:35 --> Router Class Initialized
INFO - 2021-12-08 09:27:35 --> Output Class Initialized
INFO - 2021-12-08 09:27:35 --> Security Class Initialized
DEBUG - 2021-12-08 09:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:27:35 --> Input Class Initialized
INFO - 2021-12-08 09:27:35 --> Language Class Initialized
INFO - 2021-12-08 09:27:35 --> Language Class Initialized
INFO - 2021-12-08 09:27:35 --> Config Class Initialized
INFO - 2021-12-08 09:27:35 --> Loader Class Initialized
INFO - 2021-12-08 09:27:35 --> Helper loaded: url_helper
INFO - 2021-12-08 09:27:35 --> Helper loaded: file_helper
INFO - 2021-12-08 09:27:35 --> Helper loaded: form_helper
INFO - 2021-12-08 09:27:35 --> Helper loaded: my_helper
INFO - 2021-12-08 09:27:35 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:27:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:27:35 --> Controller Class Initialized
INFO - 2021-12-08 09:27:35 --> Final output sent to browser
DEBUG - 2021-12-08 09:27:35 --> Total execution time: 0.0770
INFO - 2021-12-08 09:27:48 --> Config Class Initialized
INFO - 2021-12-08 09:27:48 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:27:48 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:27:48 --> Utf8 Class Initialized
INFO - 2021-12-08 09:27:48 --> URI Class Initialized
INFO - 2021-12-08 09:27:48 --> Router Class Initialized
INFO - 2021-12-08 09:27:48 --> Output Class Initialized
INFO - 2021-12-08 09:27:48 --> Security Class Initialized
DEBUG - 2021-12-08 09:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:27:48 --> Input Class Initialized
INFO - 2021-12-08 09:27:48 --> Language Class Initialized
INFO - 2021-12-08 09:27:48 --> Language Class Initialized
INFO - 2021-12-08 09:27:48 --> Config Class Initialized
INFO - 2021-12-08 09:27:48 --> Loader Class Initialized
INFO - 2021-12-08 09:27:48 --> Helper loaded: url_helper
INFO - 2021-12-08 09:27:48 --> Helper loaded: file_helper
INFO - 2021-12-08 09:27:48 --> Helper loaded: form_helper
INFO - 2021-12-08 09:27:48 --> Helper loaded: my_helper
INFO - 2021-12-08 09:27:48 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:27:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:27:48 --> Controller Class Initialized
INFO - 2021-12-08 09:27:48 --> Helper loaded: cookie_helper
INFO - 2021-12-08 09:27:48 --> Config Class Initialized
INFO - 2021-12-08 09:27:48 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:27:48 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:27:48 --> Utf8 Class Initialized
INFO - 2021-12-08 09:27:48 --> URI Class Initialized
INFO - 2021-12-08 09:27:48 --> Router Class Initialized
INFO - 2021-12-08 09:27:48 --> Output Class Initialized
INFO - 2021-12-08 09:27:48 --> Security Class Initialized
DEBUG - 2021-12-08 09:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:27:48 --> Input Class Initialized
INFO - 2021-12-08 09:27:48 --> Language Class Initialized
INFO - 2021-12-08 09:27:48 --> Language Class Initialized
INFO - 2021-12-08 09:27:48 --> Config Class Initialized
INFO - 2021-12-08 09:27:48 --> Loader Class Initialized
INFO - 2021-12-08 09:27:48 --> Helper loaded: url_helper
INFO - 2021-12-08 09:27:48 --> Helper loaded: file_helper
INFO - 2021-12-08 09:27:48 --> Helper loaded: form_helper
INFO - 2021-12-08 09:27:48 --> Helper loaded: my_helper
INFO - 2021-12-08 09:27:48 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:27:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:27:48 --> Controller Class Initialized
DEBUG - 2021-12-08 09:27:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-08 09:27:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 09:27:48 --> Final output sent to browser
DEBUG - 2021-12-08 09:27:48 --> Total execution time: 0.0350
INFO - 2021-12-08 09:28:17 --> Config Class Initialized
INFO - 2021-12-08 09:28:17 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:28:17 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:28:17 --> Utf8 Class Initialized
INFO - 2021-12-08 09:28:17 --> URI Class Initialized
INFO - 2021-12-08 09:28:17 --> Router Class Initialized
INFO - 2021-12-08 09:28:17 --> Output Class Initialized
INFO - 2021-12-08 09:28:17 --> Security Class Initialized
DEBUG - 2021-12-08 09:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:28:17 --> Input Class Initialized
INFO - 2021-12-08 09:28:17 --> Language Class Initialized
INFO - 2021-12-08 09:28:17 --> Language Class Initialized
INFO - 2021-12-08 09:28:17 --> Config Class Initialized
INFO - 2021-12-08 09:28:17 --> Loader Class Initialized
INFO - 2021-12-08 09:28:17 --> Helper loaded: url_helper
INFO - 2021-12-08 09:28:17 --> Helper loaded: file_helper
INFO - 2021-12-08 09:28:17 --> Helper loaded: form_helper
INFO - 2021-12-08 09:28:17 --> Helper loaded: my_helper
INFO - 2021-12-08 09:28:17 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:28:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:28:17 --> Controller Class Initialized
INFO - 2021-12-08 09:28:17 --> Helper loaded: cookie_helper
INFO - 2021-12-08 09:28:17 --> Final output sent to browser
DEBUG - 2021-12-08 09:28:17 --> Total execution time: 0.0580
INFO - 2021-12-08 09:28:20 --> Config Class Initialized
INFO - 2021-12-08 09:28:20 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:28:20 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:28:20 --> Utf8 Class Initialized
INFO - 2021-12-08 09:28:20 --> URI Class Initialized
INFO - 2021-12-08 09:28:20 --> Router Class Initialized
INFO - 2021-12-08 09:28:20 --> Output Class Initialized
INFO - 2021-12-08 09:28:20 --> Security Class Initialized
DEBUG - 2021-12-08 09:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:28:20 --> Input Class Initialized
INFO - 2021-12-08 09:28:20 --> Language Class Initialized
INFO - 2021-12-08 09:28:20 --> Language Class Initialized
INFO - 2021-12-08 09:28:20 --> Config Class Initialized
INFO - 2021-12-08 09:28:20 --> Loader Class Initialized
INFO - 2021-12-08 09:28:20 --> Helper loaded: url_helper
INFO - 2021-12-08 09:28:20 --> Helper loaded: file_helper
INFO - 2021-12-08 09:28:20 --> Helper loaded: form_helper
INFO - 2021-12-08 09:28:20 --> Helper loaded: my_helper
INFO - 2021-12-08 09:28:20 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:28:20 --> Controller Class Initialized
DEBUG - 2021-12-08 09:28:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-08 09:28:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 09:28:20 --> Final output sent to browser
DEBUG - 2021-12-08 09:28:20 --> Total execution time: 0.2520
INFO - 2021-12-08 09:28:25 --> Config Class Initialized
INFO - 2021-12-08 09:28:25 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:28:25 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:28:25 --> Utf8 Class Initialized
INFO - 2021-12-08 09:28:25 --> URI Class Initialized
INFO - 2021-12-08 09:28:25 --> Router Class Initialized
INFO - 2021-12-08 09:28:25 --> Output Class Initialized
INFO - 2021-12-08 09:28:25 --> Security Class Initialized
DEBUG - 2021-12-08 09:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:28:25 --> Input Class Initialized
INFO - 2021-12-08 09:28:25 --> Language Class Initialized
INFO - 2021-12-08 09:28:25 --> Language Class Initialized
INFO - 2021-12-08 09:28:25 --> Config Class Initialized
INFO - 2021-12-08 09:28:25 --> Loader Class Initialized
INFO - 2021-12-08 09:28:25 --> Helper loaded: url_helper
INFO - 2021-12-08 09:28:25 --> Helper loaded: file_helper
INFO - 2021-12-08 09:28:25 --> Helper loaded: form_helper
INFO - 2021-12-08 09:28:25 --> Helper loaded: my_helper
INFO - 2021-12-08 09:28:25 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:28:25 --> Controller Class Initialized
DEBUG - 2021-12-08 09:28:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-08 09:28:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 09:28:25 --> Final output sent to browser
DEBUG - 2021-12-08 09:28:25 --> Total execution time: 0.0800
INFO - 2021-12-08 09:30:30 --> Config Class Initialized
INFO - 2021-12-08 09:30:30 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:30:30 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:30:30 --> Utf8 Class Initialized
INFO - 2021-12-08 09:30:30 --> URI Class Initialized
INFO - 2021-12-08 09:30:30 --> Router Class Initialized
INFO - 2021-12-08 09:30:30 --> Output Class Initialized
INFO - 2021-12-08 09:30:30 --> Security Class Initialized
DEBUG - 2021-12-08 09:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:30:30 --> Input Class Initialized
INFO - 2021-12-08 09:30:30 --> Language Class Initialized
INFO - 2021-12-08 09:30:30 --> Language Class Initialized
INFO - 2021-12-08 09:30:30 --> Config Class Initialized
INFO - 2021-12-08 09:30:30 --> Loader Class Initialized
INFO - 2021-12-08 09:30:30 --> Helper loaded: url_helper
INFO - 2021-12-08 09:30:30 --> Helper loaded: file_helper
INFO - 2021-12-08 09:30:30 --> Helper loaded: form_helper
INFO - 2021-12-08 09:30:30 --> Helper loaded: my_helper
INFO - 2021-12-08 09:30:30 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:30:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:30:30 --> Controller Class Initialized
INFO - 2021-12-08 09:30:30 --> Final output sent to browser
DEBUG - 2021-12-08 09:30:30 --> Total execution time: 0.0610
INFO - 2021-12-08 09:30:47 --> Config Class Initialized
INFO - 2021-12-08 09:30:47 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:30:47 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:30:47 --> Utf8 Class Initialized
INFO - 2021-12-08 09:30:47 --> URI Class Initialized
INFO - 2021-12-08 09:30:47 --> Router Class Initialized
INFO - 2021-12-08 09:30:47 --> Output Class Initialized
INFO - 2021-12-08 09:30:47 --> Security Class Initialized
DEBUG - 2021-12-08 09:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:30:47 --> Input Class Initialized
INFO - 2021-12-08 09:30:47 --> Language Class Initialized
INFO - 2021-12-08 09:30:47 --> Language Class Initialized
INFO - 2021-12-08 09:30:47 --> Config Class Initialized
INFO - 2021-12-08 09:30:47 --> Loader Class Initialized
INFO - 2021-12-08 09:30:47 --> Helper loaded: url_helper
INFO - 2021-12-08 09:30:47 --> Helper loaded: file_helper
INFO - 2021-12-08 09:30:47 --> Helper loaded: form_helper
INFO - 2021-12-08 09:30:47 --> Helper loaded: my_helper
INFO - 2021-12-08 09:30:47 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:30:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:30:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:30:47 --> Controller Class Initialized
DEBUG - 2021-12-08 09:30:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-08 09:30:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 09:30:47 --> Final output sent to browser
DEBUG - 2021-12-08 09:30:47 --> Total execution time: 0.0600
INFO - 2021-12-08 09:30:54 --> Config Class Initialized
INFO - 2021-12-08 09:30:54 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:30:54 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:30:54 --> Utf8 Class Initialized
INFO - 2021-12-08 09:30:54 --> URI Class Initialized
INFO - 2021-12-08 09:30:54 --> Router Class Initialized
INFO - 2021-12-08 09:30:54 --> Output Class Initialized
INFO - 2021-12-08 09:30:54 --> Security Class Initialized
DEBUG - 2021-12-08 09:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:30:54 --> Input Class Initialized
INFO - 2021-12-08 09:30:54 --> Language Class Initialized
INFO - 2021-12-08 09:30:54 --> Language Class Initialized
INFO - 2021-12-08 09:30:54 --> Config Class Initialized
INFO - 2021-12-08 09:30:54 --> Loader Class Initialized
INFO - 2021-12-08 09:30:54 --> Helper loaded: url_helper
INFO - 2021-12-08 09:30:54 --> Helper loaded: file_helper
INFO - 2021-12-08 09:30:54 --> Helper loaded: form_helper
INFO - 2021-12-08 09:30:54 --> Helper loaded: my_helper
INFO - 2021-12-08 09:30:54 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:30:54 --> Controller Class Initialized
DEBUG - 2021-12-08 09:30:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-12-08 09:30:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 09:30:54 --> Final output sent to browser
DEBUG - 2021-12-08 09:30:54 --> Total execution time: 0.0510
INFO - 2021-12-08 09:32:06 --> Config Class Initialized
INFO - 2021-12-08 09:32:06 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:32:06 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:32:06 --> Utf8 Class Initialized
INFO - 2021-12-08 09:32:06 --> URI Class Initialized
INFO - 2021-12-08 09:32:06 --> Router Class Initialized
INFO - 2021-12-08 09:32:06 --> Output Class Initialized
INFO - 2021-12-08 09:32:06 --> Security Class Initialized
DEBUG - 2021-12-08 09:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:32:06 --> Input Class Initialized
INFO - 2021-12-08 09:32:06 --> Language Class Initialized
INFO - 2021-12-08 09:32:06 --> Language Class Initialized
INFO - 2021-12-08 09:32:06 --> Config Class Initialized
INFO - 2021-12-08 09:32:06 --> Loader Class Initialized
INFO - 2021-12-08 09:32:06 --> Helper loaded: url_helper
INFO - 2021-12-08 09:32:06 --> Helper loaded: file_helper
INFO - 2021-12-08 09:32:06 --> Helper loaded: form_helper
INFO - 2021-12-08 09:32:06 --> Helper loaded: my_helper
INFO - 2021-12-08 09:32:06 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:32:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:32:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:32:06 --> Controller Class Initialized
INFO - 2021-12-08 09:32:06 --> Final output sent to browser
DEBUG - 2021-12-08 09:32:06 --> Total execution time: 0.0590
INFO - 2021-12-08 09:32:10 --> Config Class Initialized
INFO - 2021-12-08 09:32:10 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:32:10 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:32:10 --> Utf8 Class Initialized
INFO - 2021-12-08 09:32:10 --> URI Class Initialized
INFO - 2021-12-08 09:32:10 --> Router Class Initialized
INFO - 2021-12-08 09:32:10 --> Output Class Initialized
INFO - 2021-12-08 09:32:10 --> Security Class Initialized
DEBUG - 2021-12-08 09:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:32:10 --> Input Class Initialized
INFO - 2021-12-08 09:32:10 --> Language Class Initialized
INFO - 2021-12-08 09:32:10 --> Language Class Initialized
INFO - 2021-12-08 09:32:10 --> Config Class Initialized
INFO - 2021-12-08 09:32:10 --> Loader Class Initialized
INFO - 2021-12-08 09:32:10 --> Helper loaded: url_helper
INFO - 2021-12-08 09:32:10 --> Helper loaded: file_helper
INFO - 2021-12-08 09:32:10 --> Helper loaded: form_helper
INFO - 2021-12-08 09:32:10 --> Helper loaded: my_helper
INFO - 2021-12-08 09:32:10 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:32:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:32:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:32:10 --> Controller Class Initialized
DEBUG - 2021-12-08 09:32:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-08 09:32:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 09:32:10 --> Final output sent to browser
DEBUG - 2021-12-08 09:32:10 --> Total execution time: 0.0590
INFO - 2021-12-08 09:32:12 --> Config Class Initialized
INFO - 2021-12-08 09:32:12 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:32:12 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:32:12 --> Utf8 Class Initialized
INFO - 2021-12-08 09:32:12 --> URI Class Initialized
INFO - 2021-12-08 09:32:12 --> Router Class Initialized
INFO - 2021-12-08 09:32:12 --> Output Class Initialized
INFO - 2021-12-08 09:32:12 --> Security Class Initialized
DEBUG - 2021-12-08 09:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:32:12 --> Input Class Initialized
INFO - 2021-12-08 09:32:12 --> Language Class Initialized
INFO - 2021-12-08 09:32:12 --> Language Class Initialized
INFO - 2021-12-08 09:32:12 --> Config Class Initialized
INFO - 2021-12-08 09:32:12 --> Loader Class Initialized
INFO - 2021-12-08 09:32:12 --> Helper loaded: url_helper
INFO - 2021-12-08 09:32:12 --> Helper loaded: file_helper
INFO - 2021-12-08 09:32:12 --> Helper loaded: form_helper
INFO - 2021-12-08 09:32:12 --> Helper loaded: my_helper
INFO - 2021-12-08 09:32:12 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:32:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:32:12 --> Controller Class Initialized
DEBUG - 2021-12-08 09:32:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-12-08 09:32:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 09:32:12 --> Final output sent to browser
DEBUG - 2021-12-08 09:32:12 --> Total execution time: 0.0460
INFO - 2021-12-08 09:32:15 --> Config Class Initialized
INFO - 2021-12-08 09:32:15 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:32:15 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:32:15 --> Utf8 Class Initialized
INFO - 2021-12-08 09:32:15 --> URI Class Initialized
INFO - 2021-12-08 09:32:15 --> Router Class Initialized
INFO - 2021-12-08 09:32:15 --> Output Class Initialized
INFO - 2021-12-08 09:32:15 --> Security Class Initialized
DEBUG - 2021-12-08 09:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:32:15 --> Input Class Initialized
INFO - 2021-12-08 09:32:15 --> Language Class Initialized
INFO - 2021-12-08 09:32:15 --> Language Class Initialized
INFO - 2021-12-08 09:32:15 --> Config Class Initialized
INFO - 2021-12-08 09:32:15 --> Loader Class Initialized
INFO - 2021-12-08 09:32:15 --> Helper loaded: url_helper
INFO - 2021-12-08 09:32:15 --> Helper loaded: file_helper
INFO - 2021-12-08 09:32:15 --> Helper loaded: form_helper
INFO - 2021-12-08 09:32:15 --> Helper loaded: my_helper
INFO - 2021-12-08 09:32:15 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:32:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:32:15 --> Controller Class Initialized
DEBUG - 2021-12-08 09:32:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-12-08 09:32:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 09:32:15 --> Final output sent to browser
DEBUG - 2021-12-08 09:32:15 --> Total execution time: 0.0450
INFO - 2021-12-08 09:32:17 --> Config Class Initialized
INFO - 2021-12-08 09:32:17 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:32:17 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:32:17 --> Utf8 Class Initialized
INFO - 2021-12-08 09:32:17 --> URI Class Initialized
INFO - 2021-12-08 09:32:17 --> Router Class Initialized
INFO - 2021-12-08 09:32:17 --> Output Class Initialized
INFO - 2021-12-08 09:32:17 --> Security Class Initialized
DEBUG - 2021-12-08 09:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:32:17 --> Input Class Initialized
INFO - 2021-12-08 09:32:17 --> Language Class Initialized
INFO - 2021-12-08 09:32:17 --> Language Class Initialized
INFO - 2021-12-08 09:32:17 --> Config Class Initialized
INFO - 2021-12-08 09:32:17 --> Loader Class Initialized
INFO - 2021-12-08 09:32:17 --> Helper loaded: url_helper
INFO - 2021-12-08 09:32:17 --> Helper loaded: file_helper
INFO - 2021-12-08 09:32:17 --> Helper loaded: form_helper
INFO - 2021-12-08 09:32:17 --> Helper loaded: my_helper
INFO - 2021-12-08 09:32:17 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:32:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:32:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:32:17 --> Controller Class Initialized
INFO - 2021-12-08 09:32:17 --> Final output sent to browser
DEBUG - 2021-12-08 09:32:17 --> Total execution time: 0.0540
INFO - 2021-12-08 09:32:28 --> Config Class Initialized
INFO - 2021-12-08 09:32:28 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:32:28 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:32:28 --> Utf8 Class Initialized
INFO - 2021-12-08 09:32:28 --> URI Class Initialized
INFO - 2021-12-08 09:32:28 --> Router Class Initialized
INFO - 2021-12-08 09:32:28 --> Output Class Initialized
INFO - 2021-12-08 09:32:28 --> Security Class Initialized
DEBUG - 2021-12-08 09:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:32:28 --> Input Class Initialized
INFO - 2021-12-08 09:32:28 --> Language Class Initialized
INFO - 2021-12-08 09:32:28 --> Language Class Initialized
INFO - 2021-12-08 09:32:28 --> Config Class Initialized
INFO - 2021-12-08 09:32:28 --> Loader Class Initialized
INFO - 2021-12-08 09:32:28 --> Helper loaded: url_helper
INFO - 2021-12-08 09:32:28 --> Helper loaded: file_helper
INFO - 2021-12-08 09:32:28 --> Helper loaded: form_helper
INFO - 2021-12-08 09:32:28 --> Helper loaded: my_helper
INFO - 2021-12-08 09:32:28 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:32:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:32:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:32:28 --> Controller Class Initialized
INFO - 2021-12-08 09:32:28 --> Final output sent to browser
DEBUG - 2021-12-08 09:32:28 --> Total execution time: 0.0760
INFO - 2021-12-08 09:32:36 --> Config Class Initialized
INFO - 2021-12-08 09:32:36 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:32:36 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:32:36 --> Utf8 Class Initialized
INFO - 2021-12-08 09:32:36 --> URI Class Initialized
INFO - 2021-12-08 09:32:36 --> Router Class Initialized
INFO - 2021-12-08 09:32:36 --> Output Class Initialized
INFO - 2021-12-08 09:32:36 --> Security Class Initialized
DEBUG - 2021-12-08 09:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:32:36 --> Input Class Initialized
INFO - 2021-12-08 09:32:36 --> Language Class Initialized
INFO - 2021-12-08 09:32:36 --> Language Class Initialized
INFO - 2021-12-08 09:32:36 --> Config Class Initialized
INFO - 2021-12-08 09:32:36 --> Loader Class Initialized
INFO - 2021-12-08 09:32:36 --> Helper loaded: url_helper
INFO - 2021-12-08 09:32:36 --> Helper loaded: file_helper
INFO - 2021-12-08 09:32:36 --> Helper loaded: form_helper
INFO - 2021-12-08 09:32:36 --> Helper loaded: my_helper
INFO - 2021-12-08 09:32:36 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:32:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:32:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:32:36 --> Controller Class Initialized
DEBUG - 2021-12-08 09:32:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-12-08 09:32:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 09:32:36 --> Final output sent to browser
DEBUG - 2021-12-08 09:32:36 --> Total execution time: 0.0590
INFO - 2021-12-08 09:32:47 --> Config Class Initialized
INFO - 2021-12-08 09:32:47 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:32:47 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:32:47 --> Utf8 Class Initialized
INFO - 2021-12-08 09:32:47 --> URI Class Initialized
INFO - 2021-12-08 09:32:47 --> Router Class Initialized
INFO - 2021-12-08 09:32:47 --> Output Class Initialized
INFO - 2021-12-08 09:32:47 --> Security Class Initialized
DEBUG - 2021-12-08 09:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:32:47 --> Input Class Initialized
INFO - 2021-12-08 09:32:47 --> Language Class Initialized
INFO - 2021-12-08 09:32:47 --> Language Class Initialized
INFO - 2021-12-08 09:32:47 --> Config Class Initialized
INFO - 2021-12-08 09:32:47 --> Loader Class Initialized
INFO - 2021-12-08 09:32:47 --> Helper loaded: url_helper
INFO - 2021-12-08 09:32:47 --> Helper loaded: file_helper
INFO - 2021-12-08 09:32:47 --> Helper loaded: form_helper
INFO - 2021-12-08 09:32:47 --> Helper loaded: my_helper
INFO - 2021-12-08 09:32:47 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:32:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:32:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:32:47 --> Controller Class Initialized
INFO - 2021-12-08 09:32:47 --> Final output sent to browser
DEBUG - 2021-12-08 09:32:47 --> Total execution time: 0.0580
INFO - 2021-12-08 09:32:55 --> Config Class Initialized
INFO - 2021-12-08 09:32:55 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:32:55 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:32:55 --> Utf8 Class Initialized
INFO - 2021-12-08 09:32:55 --> URI Class Initialized
INFO - 2021-12-08 09:32:55 --> Router Class Initialized
INFO - 2021-12-08 09:32:55 --> Output Class Initialized
INFO - 2021-12-08 09:32:55 --> Security Class Initialized
DEBUG - 2021-12-08 09:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:32:55 --> Input Class Initialized
INFO - 2021-12-08 09:32:55 --> Language Class Initialized
INFO - 2021-12-08 09:32:55 --> Language Class Initialized
INFO - 2021-12-08 09:32:55 --> Config Class Initialized
INFO - 2021-12-08 09:32:55 --> Loader Class Initialized
INFO - 2021-12-08 09:32:55 --> Helper loaded: url_helper
INFO - 2021-12-08 09:32:55 --> Helper loaded: file_helper
INFO - 2021-12-08 09:32:55 --> Helper loaded: form_helper
INFO - 2021-12-08 09:32:55 --> Helper loaded: my_helper
INFO - 2021-12-08 09:32:55 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:32:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:32:55 --> Controller Class Initialized
INFO - 2021-12-08 09:32:55 --> Helper loaded: cookie_helper
INFO - 2021-12-08 09:32:55 --> Config Class Initialized
INFO - 2021-12-08 09:32:55 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:32:55 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:32:55 --> Utf8 Class Initialized
INFO - 2021-12-08 09:32:55 --> URI Class Initialized
INFO - 2021-12-08 09:32:55 --> Router Class Initialized
INFO - 2021-12-08 09:32:55 --> Output Class Initialized
INFO - 2021-12-08 09:32:55 --> Security Class Initialized
DEBUG - 2021-12-08 09:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:32:55 --> Input Class Initialized
INFO - 2021-12-08 09:32:55 --> Language Class Initialized
INFO - 2021-12-08 09:32:55 --> Language Class Initialized
INFO - 2021-12-08 09:32:55 --> Config Class Initialized
INFO - 2021-12-08 09:32:55 --> Loader Class Initialized
INFO - 2021-12-08 09:32:55 --> Helper loaded: url_helper
INFO - 2021-12-08 09:32:55 --> Helper loaded: file_helper
INFO - 2021-12-08 09:32:55 --> Helper loaded: form_helper
INFO - 2021-12-08 09:32:55 --> Helper loaded: my_helper
INFO - 2021-12-08 09:32:55 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:32:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:32:55 --> Controller Class Initialized
DEBUG - 2021-12-08 09:32:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-08 09:32:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 09:32:55 --> Final output sent to browser
DEBUG - 2021-12-08 09:32:55 --> Total execution time: 0.0350
INFO - 2021-12-08 09:33:10 --> Config Class Initialized
INFO - 2021-12-08 09:33:10 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:33:10 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:33:10 --> Utf8 Class Initialized
INFO - 2021-12-08 09:33:10 --> URI Class Initialized
INFO - 2021-12-08 09:33:10 --> Router Class Initialized
INFO - 2021-12-08 09:33:10 --> Output Class Initialized
INFO - 2021-12-08 09:33:10 --> Security Class Initialized
DEBUG - 2021-12-08 09:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:33:10 --> Input Class Initialized
INFO - 2021-12-08 09:33:10 --> Language Class Initialized
INFO - 2021-12-08 09:33:10 --> Language Class Initialized
INFO - 2021-12-08 09:33:10 --> Config Class Initialized
INFO - 2021-12-08 09:33:10 --> Loader Class Initialized
INFO - 2021-12-08 09:33:10 --> Helper loaded: url_helper
INFO - 2021-12-08 09:33:10 --> Helper loaded: file_helper
INFO - 2021-12-08 09:33:10 --> Helper loaded: form_helper
INFO - 2021-12-08 09:33:10 --> Helper loaded: my_helper
INFO - 2021-12-08 09:33:10 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:33:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:33:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:33:10 --> Controller Class Initialized
INFO - 2021-12-08 09:33:10 --> Helper loaded: cookie_helper
INFO - 2021-12-08 09:33:10 --> Final output sent to browser
DEBUG - 2021-12-08 09:33:10 --> Total execution time: 0.0420
INFO - 2021-12-08 09:33:12 --> Config Class Initialized
INFO - 2021-12-08 09:33:12 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:33:12 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:33:12 --> Utf8 Class Initialized
INFO - 2021-12-08 09:33:12 --> URI Class Initialized
INFO - 2021-12-08 09:33:12 --> Router Class Initialized
INFO - 2021-12-08 09:33:12 --> Output Class Initialized
INFO - 2021-12-08 09:33:12 --> Security Class Initialized
DEBUG - 2021-12-08 09:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:33:12 --> Input Class Initialized
INFO - 2021-12-08 09:33:12 --> Language Class Initialized
INFO - 2021-12-08 09:33:12 --> Language Class Initialized
INFO - 2021-12-08 09:33:12 --> Config Class Initialized
INFO - 2021-12-08 09:33:12 --> Loader Class Initialized
INFO - 2021-12-08 09:33:12 --> Helper loaded: url_helper
INFO - 2021-12-08 09:33:12 --> Helper loaded: file_helper
INFO - 2021-12-08 09:33:12 --> Helper loaded: form_helper
INFO - 2021-12-08 09:33:12 --> Helper loaded: my_helper
INFO - 2021-12-08 09:33:12 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:33:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:33:12 --> Controller Class Initialized
DEBUG - 2021-12-08 09:33:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-08 09:33:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 09:33:13 --> Final output sent to browser
DEBUG - 2021-12-08 09:33:13 --> Total execution time: 0.2260
INFO - 2021-12-08 09:33:21 --> Config Class Initialized
INFO - 2021-12-08 09:33:21 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:33:21 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:33:21 --> Utf8 Class Initialized
INFO - 2021-12-08 09:33:21 --> URI Class Initialized
INFO - 2021-12-08 09:33:21 --> Router Class Initialized
INFO - 2021-12-08 09:33:21 --> Output Class Initialized
INFO - 2021-12-08 09:33:21 --> Security Class Initialized
DEBUG - 2021-12-08 09:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:33:21 --> Input Class Initialized
INFO - 2021-12-08 09:33:21 --> Language Class Initialized
INFO - 2021-12-08 09:33:21 --> Language Class Initialized
INFO - 2021-12-08 09:33:21 --> Config Class Initialized
INFO - 2021-12-08 09:33:21 --> Loader Class Initialized
INFO - 2021-12-08 09:33:21 --> Helper loaded: url_helper
INFO - 2021-12-08 09:33:21 --> Helper loaded: file_helper
INFO - 2021-12-08 09:33:21 --> Helper loaded: form_helper
INFO - 2021-12-08 09:33:21 --> Helper loaded: my_helper
INFO - 2021-12-08 09:33:21 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:33:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:33:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:33:21 --> Controller Class Initialized
DEBUG - 2021-12-08 09:33:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-12-08 09:33:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 09:33:21 --> Final output sent to browser
DEBUG - 2021-12-08 09:33:21 --> Total execution time: 0.0440
INFO - 2021-12-08 09:33:21 --> Config Class Initialized
INFO - 2021-12-08 09:33:21 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:33:21 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:33:21 --> Utf8 Class Initialized
INFO - 2021-12-08 09:33:21 --> URI Class Initialized
INFO - 2021-12-08 09:33:21 --> Router Class Initialized
INFO - 2021-12-08 09:33:21 --> Output Class Initialized
INFO - 2021-12-08 09:33:21 --> Security Class Initialized
DEBUG - 2021-12-08 09:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:33:21 --> Input Class Initialized
INFO - 2021-12-08 09:33:21 --> Language Class Initialized
INFO - 2021-12-08 09:33:21 --> Language Class Initialized
INFO - 2021-12-08 09:33:21 --> Config Class Initialized
INFO - 2021-12-08 09:33:21 --> Loader Class Initialized
INFO - 2021-12-08 09:33:21 --> Helper loaded: url_helper
INFO - 2021-12-08 09:33:21 --> Helper loaded: file_helper
INFO - 2021-12-08 09:33:21 --> Helper loaded: form_helper
INFO - 2021-12-08 09:33:21 --> Helper loaded: my_helper
INFO - 2021-12-08 09:33:21 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:33:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:33:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:33:22 --> Controller Class Initialized
INFO - 2021-12-08 09:33:29 --> Config Class Initialized
INFO - 2021-12-08 09:33:29 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:33:29 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:33:29 --> Utf8 Class Initialized
INFO - 2021-12-08 09:33:29 --> URI Class Initialized
INFO - 2021-12-08 09:33:29 --> Router Class Initialized
INFO - 2021-12-08 09:33:29 --> Output Class Initialized
INFO - 2021-12-08 09:33:29 --> Security Class Initialized
DEBUG - 2021-12-08 09:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:33:29 --> Input Class Initialized
INFO - 2021-12-08 09:33:29 --> Language Class Initialized
INFO - 2021-12-08 09:33:29 --> Language Class Initialized
INFO - 2021-12-08 09:33:29 --> Config Class Initialized
INFO - 2021-12-08 09:33:29 --> Loader Class Initialized
INFO - 2021-12-08 09:33:29 --> Helper loaded: url_helper
INFO - 2021-12-08 09:33:29 --> Helper loaded: file_helper
INFO - 2021-12-08 09:33:29 --> Helper loaded: form_helper
INFO - 2021-12-08 09:33:29 --> Helper loaded: my_helper
INFO - 2021-12-08 09:33:29 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:33:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:33:29 --> Controller Class Initialized
INFO - 2021-12-08 09:33:29 --> Final output sent to browser
DEBUG - 2021-12-08 09:33:29 --> Total execution time: 0.0520
INFO - 2021-12-08 09:33:29 --> Config Class Initialized
INFO - 2021-12-08 09:33:29 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:33:29 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:33:29 --> Utf8 Class Initialized
INFO - 2021-12-08 09:33:29 --> URI Class Initialized
INFO - 2021-12-08 09:33:29 --> Router Class Initialized
INFO - 2021-12-08 09:33:29 --> Output Class Initialized
INFO - 2021-12-08 09:33:29 --> Security Class Initialized
DEBUG - 2021-12-08 09:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:33:29 --> Input Class Initialized
INFO - 2021-12-08 09:33:29 --> Language Class Initialized
INFO - 2021-12-08 09:33:29 --> Language Class Initialized
INFO - 2021-12-08 09:33:29 --> Config Class Initialized
INFO - 2021-12-08 09:33:29 --> Loader Class Initialized
INFO - 2021-12-08 09:33:29 --> Helper loaded: url_helper
INFO - 2021-12-08 09:33:29 --> Helper loaded: file_helper
INFO - 2021-12-08 09:33:29 --> Helper loaded: form_helper
INFO - 2021-12-08 09:33:29 --> Helper loaded: my_helper
INFO - 2021-12-08 09:33:29 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:33:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:33:29 --> Controller Class Initialized
INFO - 2021-12-08 09:33:35 --> Config Class Initialized
INFO - 2021-12-08 09:33:35 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:33:35 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:33:35 --> Utf8 Class Initialized
INFO - 2021-12-08 09:33:35 --> URI Class Initialized
INFO - 2021-12-08 09:33:35 --> Router Class Initialized
INFO - 2021-12-08 09:33:35 --> Output Class Initialized
INFO - 2021-12-08 09:33:35 --> Security Class Initialized
DEBUG - 2021-12-08 09:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:33:35 --> Input Class Initialized
INFO - 2021-12-08 09:33:35 --> Language Class Initialized
INFO - 2021-12-08 09:33:35 --> Language Class Initialized
INFO - 2021-12-08 09:33:35 --> Config Class Initialized
INFO - 2021-12-08 09:33:35 --> Loader Class Initialized
INFO - 2021-12-08 09:33:35 --> Helper loaded: url_helper
INFO - 2021-12-08 09:33:35 --> Helper loaded: file_helper
INFO - 2021-12-08 09:33:35 --> Helper loaded: form_helper
INFO - 2021-12-08 09:33:35 --> Helper loaded: my_helper
INFO - 2021-12-08 09:33:35 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:33:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:33:35 --> Controller Class Initialized
INFO - 2021-12-08 09:33:35 --> Helper loaded: cookie_helper
INFO - 2021-12-08 09:33:35 --> Config Class Initialized
INFO - 2021-12-08 09:33:35 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:33:35 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:33:35 --> Utf8 Class Initialized
INFO - 2021-12-08 09:33:35 --> URI Class Initialized
INFO - 2021-12-08 09:33:35 --> Router Class Initialized
INFO - 2021-12-08 09:33:35 --> Output Class Initialized
INFO - 2021-12-08 09:33:35 --> Security Class Initialized
DEBUG - 2021-12-08 09:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:33:35 --> Input Class Initialized
INFO - 2021-12-08 09:33:35 --> Language Class Initialized
INFO - 2021-12-08 09:33:35 --> Language Class Initialized
INFO - 2021-12-08 09:33:35 --> Config Class Initialized
INFO - 2021-12-08 09:33:35 --> Loader Class Initialized
INFO - 2021-12-08 09:33:35 --> Helper loaded: url_helper
INFO - 2021-12-08 09:33:35 --> Helper loaded: file_helper
INFO - 2021-12-08 09:33:35 --> Helper loaded: form_helper
INFO - 2021-12-08 09:33:35 --> Helper loaded: my_helper
INFO - 2021-12-08 09:33:35 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:33:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:33:35 --> Controller Class Initialized
DEBUG - 2021-12-08 09:33:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-08 09:33:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 09:33:35 --> Final output sent to browser
DEBUG - 2021-12-08 09:33:35 --> Total execution time: 0.0350
INFO - 2021-12-08 09:33:47 --> Config Class Initialized
INFO - 2021-12-08 09:33:47 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:33:47 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:33:47 --> Utf8 Class Initialized
INFO - 2021-12-08 09:33:47 --> URI Class Initialized
INFO - 2021-12-08 09:33:47 --> Router Class Initialized
INFO - 2021-12-08 09:33:47 --> Output Class Initialized
INFO - 2021-12-08 09:33:47 --> Security Class Initialized
DEBUG - 2021-12-08 09:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:33:47 --> Input Class Initialized
INFO - 2021-12-08 09:33:47 --> Language Class Initialized
INFO - 2021-12-08 09:33:47 --> Language Class Initialized
INFO - 2021-12-08 09:33:47 --> Config Class Initialized
INFO - 2021-12-08 09:33:47 --> Loader Class Initialized
INFO - 2021-12-08 09:33:47 --> Helper loaded: url_helper
INFO - 2021-12-08 09:33:47 --> Helper loaded: file_helper
INFO - 2021-12-08 09:33:47 --> Helper loaded: form_helper
INFO - 2021-12-08 09:33:47 --> Helper loaded: my_helper
INFO - 2021-12-08 09:33:47 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:33:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:33:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:33:47 --> Controller Class Initialized
INFO - 2021-12-08 09:33:47 --> Helper loaded: cookie_helper
INFO - 2021-12-08 09:33:47 --> Final output sent to browser
DEBUG - 2021-12-08 09:33:47 --> Total execution time: 0.0510
INFO - 2021-12-08 09:33:48 --> Config Class Initialized
INFO - 2021-12-08 09:33:48 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:33:48 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:33:48 --> Utf8 Class Initialized
INFO - 2021-12-08 09:33:48 --> URI Class Initialized
INFO - 2021-12-08 09:33:48 --> Router Class Initialized
INFO - 2021-12-08 09:33:48 --> Output Class Initialized
INFO - 2021-12-08 09:33:48 --> Security Class Initialized
DEBUG - 2021-12-08 09:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:33:48 --> Input Class Initialized
INFO - 2021-12-08 09:33:48 --> Language Class Initialized
INFO - 2021-12-08 09:33:48 --> Language Class Initialized
INFO - 2021-12-08 09:33:48 --> Config Class Initialized
INFO - 2021-12-08 09:33:48 --> Loader Class Initialized
INFO - 2021-12-08 09:33:48 --> Helper loaded: url_helper
INFO - 2021-12-08 09:33:48 --> Helper loaded: file_helper
INFO - 2021-12-08 09:33:48 --> Helper loaded: form_helper
INFO - 2021-12-08 09:33:48 --> Helper loaded: my_helper
INFO - 2021-12-08 09:33:48 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:33:48 --> Controller Class Initialized
DEBUG - 2021-12-08 09:33:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-08 09:33:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 09:33:48 --> Final output sent to browser
DEBUG - 2021-12-08 09:33:48 --> Total execution time: 0.1420
INFO - 2021-12-08 09:33:55 --> Config Class Initialized
INFO - 2021-12-08 09:33:55 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:33:55 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:33:55 --> Utf8 Class Initialized
INFO - 2021-12-08 09:33:55 --> URI Class Initialized
INFO - 2021-12-08 09:33:55 --> Router Class Initialized
INFO - 2021-12-08 09:33:55 --> Output Class Initialized
INFO - 2021-12-08 09:33:55 --> Security Class Initialized
DEBUG - 2021-12-08 09:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:33:55 --> Input Class Initialized
INFO - 2021-12-08 09:33:55 --> Language Class Initialized
INFO - 2021-12-08 09:33:55 --> Language Class Initialized
INFO - 2021-12-08 09:33:55 --> Config Class Initialized
INFO - 2021-12-08 09:33:55 --> Loader Class Initialized
INFO - 2021-12-08 09:33:55 --> Helper loaded: url_helper
INFO - 2021-12-08 09:33:55 --> Helper loaded: file_helper
INFO - 2021-12-08 09:33:55 --> Helper loaded: form_helper
INFO - 2021-12-08 09:33:55 --> Helper loaded: my_helper
INFO - 2021-12-08 09:33:55 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:33:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:33:55 --> Controller Class Initialized
DEBUG - 2021-12-08 09:33:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-08 09:33:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 09:33:55 --> Final output sent to browser
DEBUG - 2021-12-08 09:33:55 --> Total execution time: 0.1100
INFO - 2021-12-08 09:34:14 --> Config Class Initialized
INFO - 2021-12-08 09:34:14 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:34:14 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:34:14 --> Utf8 Class Initialized
INFO - 2021-12-08 09:34:14 --> URI Class Initialized
INFO - 2021-12-08 09:34:14 --> Router Class Initialized
INFO - 2021-12-08 09:34:14 --> Output Class Initialized
INFO - 2021-12-08 09:34:14 --> Security Class Initialized
DEBUG - 2021-12-08 09:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:34:14 --> Input Class Initialized
INFO - 2021-12-08 09:34:14 --> Language Class Initialized
INFO - 2021-12-08 09:34:14 --> Language Class Initialized
INFO - 2021-12-08 09:34:14 --> Config Class Initialized
INFO - 2021-12-08 09:34:14 --> Loader Class Initialized
INFO - 2021-12-08 09:34:14 --> Helper loaded: url_helper
INFO - 2021-12-08 09:34:14 --> Helper loaded: file_helper
INFO - 2021-12-08 09:34:14 --> Helper loaded: form_helper
INFO - 2021-12-08 09:34:14 --> Helper loaded: my_helper
INFO - 2021-12-08 09:34:14 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:34:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:34:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:34:14 --> Controller Class Initialized
INFO - 2021-12-08 09:34:14 --> Helper loaded: cookie_helper
INFO - 2021-12-08 09:34:14 --> Config Class Initialized
INFO - 2021-12-08 09:34:14 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:34:14 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:34:14 --> Utf8 Class Initialized
INFO - 2021-12-08 09:34:14 --> URI Class Initialized
INFO - 2021-12-08 09:34:14 --> Router Class Initialized
INFO - 2021-12-08 09:34:14 --> Output Class Initialized
INFO - 2021-12-08 09:34:14 --> Security Class Initialized
DEBUG - 2021-12-08 09:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:34:14 --> Input Class Initialized
INFO - 2021-12-08 09:34:14 --> Language Class Initialized
INFO - 2021-12-08 09:34:14 --> Language Class Initialized
INFO - 2021-12-08 09:34:14 --> Config Class Initialized
INFO - 2021-12-08 09:34:14 --> Loader Class Initialized
INFO - 2021-12-08 09:34:14 --> Helper loaded: url_helper
INFO - 2021-12-08 09:34:14 --> Helper loaded: file_helper
INFO - 2021-12-08 09:34:14 --> Helper loaded: form_helper
INFO - 2021-12-08 09:34:14 --> Helper loaded: my_helper
INFO - 2021-12-08 09:34:14 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:34:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:34:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:34:14 --> Controller Class Initialized
DEBUG - 2021-12-08 09:34:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-08 09:34:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 09:34:14 --> Final output sent to browser
DEBUG - 2021-12-08 09:34:14 --> Total execution time: 0.0370
INFO - 2021-12-08 09:34:32 --> Config Class Initialized
INFO - 2021-12-08 09:34:32 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:34:32 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:34:32 --> Utf8 Class Initialized
INFO - 2021-12-08 09:34:32 --> URI Class Initialized
INFO - 2021-12-08 09:34:32 --> Router Class Initialized
INFO - 2021-12-08 09:34:32 --> Output Class Initialized
INFO - 2021-12-08 09:34:32 --> Security Class Initialized
DEBUG - 2021-12-08 09:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:34:32 --> Input Class Initialized
INFO - 2021-12-08 09:34:32 --> Language Class Initialized
INFO - 2021-12-08 09:34:32 --> Language Class Initialized
INFO - 2021-12-08 09:34:32 --> Config Class Initialized
INFO - 2021-12-08 09:34:32 --> Loader Class Initialized
INFO - 2021-12-08 09:34:32 --> Helper loaded: url_helper
INFO - 2021-12-08 09:34:32 --> Helper loaded: file_helper
INFO - 2021-12-08 09:34:32 --> Helper loaded: form_helper
INFO - 2021-12-08 09:34:32 --> Helper loaded: my_helper
INFO - 2021-12-08 09:34:32 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:34:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:34:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:34:32 --> Controller Class Initialized
INFO - 2021-12-08 09:34:32 --> Helper loaded: cookie_helper
INFO - 2021-12-08 09:34:32 --> Final output sent to browser
DEBUG - 2021-12-08 09:34:32 --> Total execution time: 0.0610
INFO - 2021-12-08 09:34:34 --> Config Class Initialized
INFO - 2021-12-08 09:34:34 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:34:34 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:34:34 --> Utf8 Class Initialized
INFO - 2021-12-08 09:34:34 --> URI Class Initialized
INFO - 2021-12-08 09:34:34 --> Router Class Initialized
INFO - 2021-12-08 09:34:34 --> Output Class Initialized
INFO - 2021-12-08 09:34:34 --> Security Class Initialized
DEBUG - 2021-12-08 09:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:34:34 --> Input Class Initialized
INFO - 2021-12-08 09:34:34 --> Language Class Initialized
INFO - 2021-12-08 09:34:34 --> Language Class Initialized
INFO - 2021-12-08 09:34:34 --> Config Class Initialized
INFO - 2021-12-08 09:34:34 --> Loader Class Initialized
INFO - 2021-12-08 09:34:34 --> Helper loaded: url_helper
INFO - 2021-12-08 09:34:34 --> Helper loaded: file_helper
INFO - 2021-12-08 09:34:34 --> Helper loaded: form_helper
INFO - 2021-12-08 09:34:34 --> Helper loaded: my_helper
INFO - 2021-12-08 09:34:34 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:34:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:34:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:34:34 --> Controller Class Initialized
DEBUG - 2021-12-08 09:34:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-08 09:34:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 09:34:34 --> Final output sent to browser
DEBUG - 2021-12-08 09:34:34 --> Total execution time: 0.1880
INFO - 2021-12-08 09:34:39 --> Config Class Initialized
INFO - 2021-12-08 09:34:39 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:34:39 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:34:39 --> Utf8 Class Initialized
INFO - 2021-12-08 09:34:39 --> URI Class Initialized
INFO - 2021-12-08 09:34:39 --> Router Class Initialized
INFO - 2021-12-08 09:34:39 --> Output Class Initialized
INFO - 2021-12-08 09:34:39 --> Security Class Initialized
DEBUG - 2021-12-08 09:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:34:39 --> Input Class Initialized
INFO - 2021-12-08 09:34:39 --> Language Class Initialized
INFO - 2021-12-08 09:34:39 --> Language Class Initialized
INFO - 2021-12-08 09:34:39 --> Config Class Initialized
INFO - 2021-12-08 09:34:39 --> Loader Class Initialized
INFO - 2021-12-08 09:34:39 --> Helper loaded: url_helper
INFO - 2021-12-08 09:34:39 --> Helper loaded: file_helper
INFO - 2021-12-08 09:34:39 --> Helper loaded: form_helper
INFO - 2021-12-08 09:34:39 --> Helper loaded: my_helper
INFO - 2021-12-08 09:34:39 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:34:39 --> Controller Class Initialized
DEBUG - 2021-12-08 09:34:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-12-08 09:34:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 09:34:39 --> Final output sent to browser
DEBUG - 2021-12-08 09:34:39 --> Total execution time: 0.0450
INFO - 2021-12-08 09:34:39 --> Config Class Initialized
INFO - 2021-12-08 09:34:39 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:34:39 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:34:39 --> Utf8 Class Initialized
INFO - 2021-12-08 09:34:39 --> URI Class Initialized
INFO - 2021-12-08 09:34:39 --> Router Class Initialized
INFO - 2021-12-08 09:34:39 --> Output Class Initialized
INFO - 2021-12-08 09:34:39 --> Security Class Initialized
DEBUG - 2021-12-08 09:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:34:39 --> Input Class Initialized
INFO - 2021-12-08 09:34:39 --> Language Class Initialized
INFO - 2021-12-08 09:34:39 --> Language Class Initialized
INFO - 2021-12-08 09:34:39 --> Config Class Initialized
INFO - 2021-12-08 09:34:39 --> Loader Class Initialized
INFO - 2021-12-08 09:34:39 --> Helper loaded: url_helper
INFO - 2021-12-08 09:34:39 --> Helper loaded: file_helper
INFO - 2021-12-08 09:34:39 --> Helper loaded: form_helper
INFO - 2021-12-08 09:34:39 --> Helper loaded: my_helper
INFO - 2021-12-08 09:34:39 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:34:39 --> Controller Class Initialized
INFO - 2021-12-08 09:35:04 --> Config Class Initialized
INFO - 2021-12-08 09:35:04 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:35:04 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:35:04 --> Utf8 Class Initialized
INFO - 2021-12-08 09:35:04 --> URI Class Initialized
INFO - 2021-12-08 09:35:04 --> Router Class Initialized
INFO - 2021-12-08 09:35:04 --> Output Class Initialized
INFO - 2021-12-08 09:35:04 --> Security Class Initialized
DEBUG - 2021-12-08 09:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:35:04 --> Input Class Initialized
INFO - 2021-12-08 09:35:04 --> Language Class Initialized
INFO - 2021-12-08 09:35:04 --> Language Class Initialized
INFO - 2021-12-08 09:35:04 --> Config Class Initialized
INFO - 2021-12-08 09:35:04 --> Loader Class Initialized
INFO - 2021-12-08 09:35:04 --> Helper loaded: url_helper
INFO - 2021-12-08 09:35:04 --> Helper loaded: file_helper
INFO - 2021-12-08 09:35:04 --> Helper loaded: form_helper
INFO - 2021-12-08 09:35:04 --> Helper loaded: my_helper
INFO - 2021-12-08 09:35:04 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:35:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:35:04 --> Controller Class Initialized
INFO - 2021-12-08 09:35:04 --> Helper loaded: cookie_helper
INFO - 2021-12-08 09:35:04 --> Config Class Initialized
INFO - 2021-12-08 09:35:04 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:35:04 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:35:04 --> Utf8 Class Initialized
INFO - 2021-12-08 09:35:04 --> URI Class Initialized
INFO - 2021-12-08 09:35:04 --> Router Class Initialized
INFO - 2021-12-08 09:35:04 --> Output Class Initialized
INFO - 2021-12-08 09:35:04 --> Security Class Initialized
DEBUG - 2021-12-08 09:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:35:04 --> Input Class Initialized
INFO - 2021-12-08 09:35:04 --> Language Class Initialized
INFO - 2021-12-08 09:35:04 --> Language Class Initialized
INFO - 2021-12-08 09:35:04 --> Config Class Initialized
INFO - 2021-12-08 09:35:04 --> Loader Class Initialized
INFO - 2021-12-08 09:35:04 --> Helper loaded: url_helper
INFO - 2021-12-08 09:35:04 --> Helper loaded: file_helper
INFO - 2021-12-08 09:35:04 --> Helper loaded: form_helper
INFO - 2021-12-08 09:35:04 --> Helper loaded: my_helper
INFO - 2021-12-08 09:35:04 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:35:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:35:04 --> Controller Class Initialized
DEBUG - 2021-12-08 09:35:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-08 09:35:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 09:35:04 --> Final output sent to browser
DEBUG - 2021-12-08 09:35:04 --> Total execution time: 0.0350
INFO - 2021-12-08 09:35:39 --> Config Class Initialized
INFO - 2021-12-08 09:35:39 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:35:39 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:35:39 --> Utf8 Class Initialized
INFO - 2021-12-08 09:35:39 --> URI Class Initialized
INFO - 2021-12-08 09:35:39 --> Router Class Initialized
INFO - 2021-12-08 09:35:39 --> Output Class Initialized
INFO - 2021-12-08 09:35:39 --> Security Class Initialized
DEBUG - 2021-12-08 09:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:35:39 --> Input Class Initialized
INFO - 2021-12-08 09:35:39 --> Language Class Initialized
INFO - 2021-12-08 09:35:39 --> Language Class Initialized
INFO - 2021-12-08 09:35:39 --> Config Class Initialized
INFO - 2021-12-08 09:35:39 --> Loader Class Initialized
INFO - 2021-12-08 09:35:39 --> Helper loaded: url_helper
INFO - 2021-12-08 09:35:39 --> Helper loaded: file_helper
INFO - 2021-12-08 09:35:39 --> Helper loaded: form_helper
INFO - 2021-12-08 09:35:39 --> Helper loaded: my_helper
INFO - 2021-12-08 09:35:39 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:35:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:35:39 --> Controller Class Initialized
INFO - 2021-12-08 09:35:39 --> Helper loaded: cookie_helper
INFO - 2021-12-08 09:35:39 --> Final output sent to browser
DEBUG - 2021-12-08 09:35:39 --> Total execution time: 0.0490
INFO - 2021-12-08 09:35:40 --> Config Class Initialized
INFO - 2021-12-08 09:35:40 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:35:40 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:35:40 --> Utf8 Class Initialized
INFO - 2021-12-08 09:35:40 --> URI Class Initialized
INFO - 2021-12-08 09:35:40 --> Router Class Initialized
INFO - 2021-12-08 09:35:40 --> Output Class Initialized
INFO - 2021-12-08 09:35:40 --> Security Class Initialized
DEBUG - 2021-12-08 09:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:35:40 --> Input Class Initialized
INFO - 2021-12-08 09:35:40 --> Language Class Initialized
INFO - 2021-12-08 09:35:40 --> Language Class Initialized
INFO - 2021-12-08 09:35:40 --> Config Class Initialized
INFO - 2021-12-08 09:35:40 --> Loader Class Initialized
INFO - 2021-12-08 09:35:40 --> Helper loaded: url_helper
INFO - 2021-12-08 09:35:40 --> Helper loaded: file_helper
INFO - 2021-12-08 09:35:40 --> Helper loaded: form_helper
INFO - 2021-12-08 09:35:40 --> Helper loaded: my_helper
INFO - 2021-12-08 09:35:40 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:35:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:35:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:35:40 --> Controller Class Initialized
DEBUG - 2021-12-08 09:35:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-08 09:35:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 09:35:41 --> Final output sent to browser
DEBUG - 2021-12-08 09:35:41 --> Total execution time: 0.1790
INFO - 2021-12-08 09:35:44 --> Config Class Initialized
INFO - 2021-12-08 09:35:44 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:35:44 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:35:44 --> Utf8 Class Initialized
INFO - 2021-12-08 09:35:44 --> URI Class Initialized
INFO - 2021-12-08 09:35:44 --> Router Class Initialized
INFO - 2021-12-08 09:35:44 --> Output Class Initialized
INFO - 2021-12-08 09:35:44 --> Security Class Initialized
DEBUG - 2021-12-08 09:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:35:44 --> Input Class Initialized
INFO - 2021-12-08 09:35:44 --> Language Class Initialized
INFO - 2021-12-08 09:35:44 --> Language Class Initialized
INFO - 2021-12-08 09:35:44 --> Config Class Initialized
INFO - 2021-12-08 09:35:44 --> Loader Class Initialized
INFO - 2021-12-08 09:35:44 --> Helper loaded: url_helper
INFO - 2021-12-08 09:35:44 --> Helper loaded: file_helper
INFO - 2021-12-08 09:35:44 --> Helper loaded: form_helper
INFO - 2021-12-08 09:35:44 --> Helper loaded: my_helper
INFO - 2021-12-08 09:35:44 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:35:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:35:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:35:44 --> Controller Class Initialized
DEBUG - 2021-12-08 09:35:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-08 09:35:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 09:35:44 --> Final output sent to browser
DEBUG - 2021-12-08 09:35:44 --> Total execution time: 0.1080
INFO - 2021-12-08 09:52:45 --> Config Class Initialized
INFO - 2021-12-08 09:52:45 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:52:45 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:52:45 --> Utf8 Class Initialized
INFO - 2021-12-08 09:52:45 --> URI Class Initialized
INFO - 2021-12-08 09:52:45 --> Router Class Initialized
INFO - 2021-12-08 09:52:45 --> Output Class Initialized
INFO - 2021-12-08 09:52:45 --> Security Class Initialized
DEBUG - 2021-12-08 09:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:52:45 --> Input Class Initialized
INFO - 2021-12-08 09:52:45 --> Language Class Initialized
INFO - 2021-12-08 09:52:45 --> Language Class Initialized
INFO - 2021-12-08 09:52:45 --> Config Class Initialized
INFO - 2021-12-08 09:52:45 --> Loader Class Initialized
INFO - 2021-12-08 09:52:45 --> Helper loaded: url_helper
INFO - 2021-12-08 09:52:45 --> Helper loaded: file_helper
INFO - 2021-12-08 09:52:45 --> Helper loaded: form_helper
INFO - 2021-12-08 09:52:45 --> Helper loaded: my_helper
INFO - 2021-12-08 09:52:45 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:52:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:52:45 --> Controller Class Initialized
INFO - 2021-12-08 09:52:45 --> Final output sent to browser
DEBUG - 2021-12-08 09:52:45 --> Total execution time: 0.1200
INFO - 2021-12-08 09:52:57 --> Config Class Initialized
INFO - 2021-12-08 09:52:57 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:52:57 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:52:57 --> Utf8 Class Initialized
INFO - 2021-12-08 09:52:57 --> URI Class Initialized
INFO - 2021-12-08 09:52:58 --> Router Class Initialized
INFO - 2021-12-08 09:52:58 --> Output Class Initialized
INFO - 2021-12-08 09:52:58 --> Security Class Initialized
DEBUG - 2021-12-08 09:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:52:58 --> Input Class Initialized
INFO - 2021-12-08 09:52:58 --> Language Class Initialized
INFO - 2021-12-08 09:52:58 --> Language Class Initialized
INFO - 2021-12-08 09:52:58 --> Config Class Initialized
INFO - 2021-12-08 09:52:58 --> Loader Class Initialized
INFO - 2021-12-08 09:52:58 --> Helper loaded: url_helper
INFO - 2021-12-08 09:52:58 --> Helper loaded: file_helper
INFO - 2021-12-08 09:52:58 --> Helper loaded: form_helper
INFO - 2021-12-08 09:52:58 --> Helper loaded: my_helper
INFO - 2021-12-08 09:52:58 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:52:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:52:58 --> Controller Class Initialized
DEBUG - 2021-12-08 09:52:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-08 09:52:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 09:52:58 --> Final output sent to browser
DEBUG - 2021-12-08 09:52:58 --> Total execution time: 0.1060
INFO - 2021-12-08 09:53:01 --> Config Class Initialized
INFO - 2021-12-08 09:53:01 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:53:01 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:53:01 --> Utf8 Class Initialized
INFO - 2021-12-08 09:53:01 --> URI Class Initialized
INFO - 2021-12-08 09:53:01 --> Router Class Initialized
INFO - 2021-12-08 09:53:01 --> Output Class Initialized
INFO - 2021-12-08 09:53:01 --> Security Class Initialized
DEBUG - 2021-12-08 09:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:53:01 --> Input Class Initialized
INFO - 2021-12-08 09:53:01 --> Language Class Initialized
INFO - 2021-12-08 09:53:01 --> Language Class Initialized
INFO - 2021-12-08 09:53:01 --> Config Class Initialized
INFO - 2021-12-08 09:53:01 --> Loader Class Initialized
INFO - 2021-12-08 09:53:01 --> Helper loaded: url_helper
INFO - 2021-12-08 09:53:01 --> Helper loaded: file_helper
INFO - 2021-12-08 09:53:01 --> Helper loaded: form_helper
INFO - 2021-12-08 09:53:01 --> Helper loaded: my_helper
INFO - 2021-12-08 09:53:01 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:53:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:53:01 --> Controller Class Initialized
DEBUG - 2021-12-08 09:53:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-08 09:53:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 09:53:01 --> Final output sent to browser
DEBUG - 2021-12-08 09:53:01 --> Total execution time: 0.0780
INFO - 2021-12-08 09:53:03 --> Config Class Initialized
INFO - 2021-12-08 09:53:03 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:53:03 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:53:03 --> Utf8 Class Initialized
INFO - 2021-12-08 09:53:03 --> URI Class Initialized
INFO - 2021-12-08 09:53:03 --> Router Class Initialized
INFO - 2021-12-08 09:53:03 --> Output Class Initialized
INFO - 2021-12-08 09:53:03 --> Security Class Initialized
DEBUG - 2021-12-08 09:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:53:03 --> Input Class Initialized
INFO - 2021-12-08 09:53:03 --> Language Class Initialized
INFO - 2021-12-08 09:53:03 --> Language Class Initialized
INFO - 2021-12-08 09:53:03 --> Config Class Initialized
INFO - 2021-12-08 09:53:03 --> Loader Class Initialized
INFO - 2021-12-08 09:53:03 --> Helper loaded: url_helper
INFO - 2021-12-08 09:53:03 --> Helper loaded: file_helper
INFO - 2021-12-08 09:53:03 --> Helper loaded: form_helper
INFO - 2021-12-08 09:53:03 --> Helper loaded: my_helper
INFO - 2021-12-08 09:53:03 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:53:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:53:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:53:03 --> Controller Class Initialized
DEBUG - 2021-12-08 09:53:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-12-08 09:53:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 09:53:03 --> Final output sent to browser
DEBUG - 2021-12-08 09:53:03 --> Total execution time: 0.0650
INFO - 2021-12-08 10:00:29 --> Config Class Initialized
INFO - 2021-12-08 10:00:29 --> Hooks Class Initialized
DEBUG - 2021-12-08 10:00:29 --> UTF-8 Support Enabled
INFO - 2021-12-08 10:00:29 --> Utf8 Class Initialized
INFO - 2021-12-08 10:00:29 --> URI Class Initialized
INFO - 2021-12-08 10:00:29 --> Router Class Initialized
INFO - 2021-12-08 10:00:29 --> Output Class Initialized
INFO - 2021-12-08 10:00:29 --> Security Class Initialized
DEBUG - 2021-12-08 10:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 10:00:29 --> Input Class Initialized
INFO - 2021-12-08 10:00:29 --> Language Class Initialized
INFO - 2021-12-08 10:00:29 --> Language Class Initialized
INFO - 2021-12-08 10:00:29 --> Config Class Initialized
INFO - 2021-12-08 10:00:29 --> Loader Class Initialized
INFO - 2021-12-08 10:00:29 --> Helper loaded: url_helper
INFO - 2021-12-08 10:00:29 --> Helper loaded: file_helper
INFO - 2021-12-08 10:00:29 --> Helper loaded: form_helper
INFO - 2021-12-08 10:00:29 --> Helper loaded: my_helper
INFO - 2021-12-08 10:00:29 --> Database Driver Class Initialized
DEBUG - 2021-12-08 10:00:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 10:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 10:00:29 --> Controller Class Initialized
INFO - 2021-12-08 10:00:29 --> Final output sent to browser
DEBUG - 2021-12-08 10:00:29 --> Total execution time: 0.0730
INFO - 2021-12-08 10:00:37 --> Config Class Initialized
INFO - 2021-12-08 10:00:37 --> Hooks Class Initialized
DEBUG - 2021-12-08 10:00:37 --> UTF-8 Support Enabled
INFO - 2021-12-08 10:00:37 --> Utf8 Class Initialized
INFO - 2021-12-08 10:00:37 --> URI Class Initialized
INFO - 2021-12-08 10:00:37 --> Router Class Initialized
INFO - 2021-12-08 10:00:37 --> Output Class Initialized
INFO - 2021-12-08 10:00:37 --> Security Class Initialized
DEBUG - 2021-12-08 10:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 10:00:37 --> Input Class Initialized
INFO - 2021-12-08 10:00:37 --> Language Class Initialized
INFO - 2021-12-08 10:00:37 --> Language Class Initialized
INFO - 2021-12-08 10:00:37 --> Config Class Initialized
INFO - 2021-12-08 10:00:37 --> Loader Class Initialized
INFO - 2021-12-08 10:00:37 --> Helper loaded: url_helper
INFO - 2021-12-08 10:00:37 --> Helper loaded: file_helper
INFO - 2021-12-08 10:00:37 --> Helper loaded: form_helper
INFO - 2021-12-08 10:00:37 --> Helper loaded: my_helper
INFO - 2021-12-08 10:00:37 --> Database Driver Class Initialized
DEBUG - 2021-12-08 10:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 10:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 10:00:37 --> Controller Class Initialized
DEBUG - 2021-12-08 10:00:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-12-08 10:00:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 10:00:37 --> Final output sent to browser
DEBUG - 2021-12-08 10:00:37 --> Total execution time: 0.0630
INFO - 2021-12-08 10:01:27 --> Config Class Initialized
INFO - 2021-12-08 10:01:27 --> Hooks Class Initialized
DEBUG - 2021-12-08 10:01:27 --> UTF-8 Support Enabled
INFO - 2021-12-08 10:01:27 --> Utf8 Class Initialized
INFO - 2021-12-08 10:01:27 --> URI Class Initialized
INFO - 2021-12-08 10:01:27 --> Router Class Initialized
INFO - 2021-12-08 10:01:27 --> Output Class Initialized
INFO - 2021-12-08 10:01:27 --> Security Class Initialized
DEBUG - 2021-12-08 10:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 10:01:27 --> Input Class Initialized
INFO - 2021-12-08 10:01:27 --> Language Class Initialized
INFO - 2021-12-08 10:01:27 --> Language Class Initialized
INFO - 2021-12-08 10:01:27 --> Config Class Initialized
INFO - 2021-12-08 10:01:27 --> Loader Class Initialized
INFO - 2021-12-08 10:01:27 --> Helper loaded: url_helper
INFO - 2021-12-08 10:01:27 --> Helper loaded: file_helper
INFO - 2021-12-08 10:01:27 --> Helper loaded: form_helper
INFO - 2021-12-08 10:01:27 --> Helper loaded: my_helper
INFO - 2021-12-08 10:01:27 --> Database Driver Class Initialized
DEBUG - 2021-12-08 10:01:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 10:01:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 10:01:27 --> Controller Class Initialized
INFO - 2021-12-08 10:01:27 --> Final output sent to browser
DEBUG - 2021-12-08 10:01:27 --> Total execution time: 0.0900
INFO - 2021-12-08 10:01:31 --> Config Class Initialized
INFO - 2021-12-08 10:01:31 --> Hooks Class Initialized
DEBUG - 2021-12-08 10:01:31 --> UTF-8 Support Enabled
INFO - 2021-12-08 10:01:31 --> Utf8 Class Initialized
INFO - 2021-12-08 10:01:31 --> URI Class Initialized
INFO - 2021-12-08 10:01:31 --> Router Class Initialized
INFO - 2021-12-08 10:01:31 --> Output Class Initialized
INFO - 2021-12-08 10:01:31 --> Security Class Initialized
DEBUG - 2021-12-08 10:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 10:01:31 --> Input Class Initialized
INFO - 2021-12-08 10:01:31 --> Language Class Initialized
INFO - 2021-12-08 10:01:31 --> Language Class Initialized
INFO - 2021-12-08 10:01:31 --> Config Class Initialized
INFO - 2021-12-08 10:01:31 --> Loader Class Initialized
INFO - 2021-12-08 10:01:31 --> Helper loaded: url_helper
INFO - 2021-12-08 10:01:31 --> Helper loaded: file_helper
INFO - 2021-12-08 10:01:31 --> Helper loaded: form_helper
INFO - 2021-12-08 10:01:31 --> Helper loaded: my_helper
INFO - 2021-12-08 10:01:31 --> Database Driver Class Initialized
DEBUG - 2021-12-08 10:01:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 10:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 10:01:31 --> Controller Class Initialized
INFO - 2021-12-08 10:01:31 --> Final output sent to browser
DEBUG - 2021-12-08 10:01:31 --> Total execution time: 0.0960
INFO - 2021-12-08 10:01:41 --> Config Class Initialized
INFO - 2021-12-08 10:01:41 --> Hooks Class Initialized
DEBUG - 2021-12-08 10:01:41 --> UTF-8 Support Enabled
INFO - 2021-12-08 10:01:41 --> Utf8 Class Initialized
INFO - 2021-12-08 10:01:41 --> URI Class Initialized
INFO - 2021-12-08 10:01:41 --> Router Class Initialized
INFO - 2021-12-08 10:01:41 --> Output Class Initialized
INFO - 2021-12-08 10:01:41 --> Security Class Initialized
DEBUG - 2021-12-08 10:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 10:01:41 --> Input Class Initialized
INFO - 2021-12-08 10:01:41 --> Language Class Initialized
INFO - 2021-12-08 10:01:41 --> Language Class Initialized
INFO - 2021-12-08 10:01:41 --> Config Class Initialized
INFO - 2021-12-08 10:01:41 --> Loader Class Initialized
INFO - 2021-12-08 10:01:41 --> Helper loaded: url_helper
INFO - 2021-12-08 10:01:41 --> Helper loaded: file_helper
INFO - 2021-12-08 10:01:41 --> Helper loaded: form_helper
INFO - 2021-12-08 10:01:41 --> Helper loaded: my_helper
INFO - 2021-12-08 10:01:41 --> Database Driver Class Initialized
DEBUG - 2021-12-08 10:01:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 10:01:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 10:01:41 --> Controller Class Initialized
DEBUG - 2021-12-08 10:01:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-12-08 10:01:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 10:01:41 --> Final output sent to browser
DEBUG - 2021-12-08 10:01:41 --> Total execution time: 0.0520
INFO - 2021-12-08 10:01:43 --> Config Class Initialized
INFO - 2021-12-08 10:01:43 --> Hooks Class Initialized
DEBUG - 2021-12-08 10:01:43 --> UTF-8 Support Enabled
INFO - 2021-12-08 10:01:43 --> Utf8 Class Initialized
INFO - 2021-12-08 10:01:43 --> URI Class Initialized
INFO - 2021-12-08 10:01:43 --> Router Class Initialized
INFO - 2021-12-08 10:01:43 --> Output Class Initialized
INFO - 2021-12-08 10:01:43 --> Security Class Initialized
DEBUG - 2021-12-08 10:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 10:01:43 --> Input Class Initialized
INFO - 2021-12-08 10:01:43 --> Language Class Initialized
INFO - 2021-12-08 10:01:43 --> Language Class Initialized
INFO - 2021-12-08 10:01:43 --> Config Class Initialized
INFO - 2021-12-08 10:01:43 --> Loader Class Initialized
INFO - 2021-12-08 10:01:43 --> Helper loaded: url_helper
INFO - 2021-12-08 10:01:43 --> Helper loaded: file_helper
INFO - 2021-12-08 10:01:43 --> Helper loaded: form_helper
INFO - 2021-12-08 10:01:43 --> Helper loaded: my_helper
INFO - 2021-12-08 10:01:43 --> Database Driver Class Initialized
DEBUG - 2021-12-08 10:01:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 10:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 10:01:43 --> Controller Class Initialized
INFO - 2021-12-08 10:01:43 --> Final output sent to browser
DEBUG - 2021-12-08 10:01:43 --> Total execution time: 0.0630
INFO - 2021-12-08 10:01:48 --> Config Class Initialized
INFO - 2021-12-08 10:01:48 --> Hooks Class Initialized
DEBUG - 2021-12-08 10:01:48 --> UTF-8 Support Enabled
INFO - 2021-12-08 10:01:48 --> Utf8 Class Initialized
INFO - 2021-12-08 10:01:48 --> URI Class Initialized
INFO - 2021-12-08 10:01:48 --> Router Class Initialized
INFO - 2021-12-08 10:01:48 --> Output Class Initialized
INFO - 2021-12-08 10:01:48 --> Security Class Initialized
DEBUG - 2021-12-08 10:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 10:01:48 --> Input Class Initialized
INFO - 2021-12-08 10:01:48 --> Language Class Initialized
INFO - 2021-12-08 10:01:48 --> Language Class Initialized
INFO - 2021-12-08 10:01:48 --> Config Class Initialized
INFO - 2021-12-08 10:01:48 --> Loader Class Initialized
INFO - 2021-12-08 10:01:48 --> Helper loaded: url_helper
INFO - 2021-12-08 10:01:48 --> Helper loaded: file_helper
INFO - 2021-12-08 10:01:48 --> Helper loaded: form_helper
INFO - 2021-12-08 10:01:48 --> Helper loaded: my_helper
INFO - 2021-12-08 10:01:48 --> Database Driver Class Initialized
DEBUG - 2021-12-08 10:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 10:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 10:01:48 --> Controller Class Initialized
DEBUG - 2021-12-08 10:01:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-12-08 10:01:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 10:01:48 --> Final output sent to browser
DEBUG - 2021-12-08 10:01:48 --> Total execution time: 0.0490
INFO - 2021-12-08 10:01:50 --> Config Class Initialized
INFO - 2021-12-08 10:01:50 --> Hooks Class Initialized
DEBUG - 2021-12-08 10:01:50 --> UTF-8 Support Enabled
INFO - 2021-12-08 10:01:50 --> Utf8 Class Initialized
INFO - 2021-12-08 10:01:50 --> URI Class Initialized
INFO - 2021-12-08 10:01:50 --> Router Class Initialized
INFO - 2021-12-08 10:01:50 --> Output Class Initialized
INFO - 2021-12-08 10:01:50 --> Security Class Initialized
DEBUG - 2021-12-08 10:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 10:01:50 --> Input Class Initialized
INFO - 2021-12-08 10:01:50 --> Language Class Initialized
INFO - 2021-12-08 10:01:50 --> Language Class Initialized
INFO - 2021-12-08 10:01:50 --> Config Class Initialized
INFO - 2021-12-08 10:01:50 --> Loader Class Initialized
INFO - 2021-12-08 10:01:50 --> Helper loaded: url_helper
INFO - 2021-12-08 10:01:50 --> Helper loaded: file_helper
INFO - 2021-12-08 10:01:50 --> Helper loaded: form_helper
INFO - 2021-12-08 10:01:50 --> Helper loaded: my_helper
INFO - 2021-12-08 10:01:50 --> Database Driver Class Initialized
DEBUG - 2021-12-08 10:01:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 10:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 10:01:50 --> Controller Class Initialized
DEBUG - 2021-12-08 10:01:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-08 10:01:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 10:01:50 --> Final output sent to browser
DEBUG - 2021-12-08 10:01:50 --> Total execution time: 0.1040
INFO - 2021-12-08 10:01:51 --> Config Class Initialized
INFO - 2021-12-08 10:01:51 --> Hooks Class Initialized
DEBUG - 2021-12-08 10:01:51 --> UTF-8 Support Enabled
INFO - 2021-12-08 10:01:51 --> Utf8 Class Initialized
INFO - 2021-12-08 10:01:51 --> URI Class Initialized
INFO - 2021-12-08 10:01:51 --> Router Class Initialized
INFO - 2021-12-08 10:01:51 --> Output Class Initialized
INFO - 2021-12-08 10:01:51 --> Security Class Initialized
DEBUG - 2021-12-08 10:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 10:01:51 --> Input Class Initialized
INFO - 2021-12-08 10:01:51 --> Language Class Initialized
INFO - 2021-12-08 10:01:51 --> Language Class Initialized
INFO - 2021-12-08 10:01:51 --> Config Class Initialized
INFO - 2021-12-08 10:01:51 --> Loader Class Initialized
INFO - 2021-12-08 10:01:51 --> Helper loaded: url_helper
INFO - 2021-12-08 10:01:51 --> Helper loaded: file_helper
INFO - 2021-12-08 10:01:51 --> Helper loaded: form_helper
INFO - 2021-12-08 10:01:51 --> Helper loaded: my_helper
INFO - 2021-12-08 10:01:51 --> Database Driver Class Initialized
DEBUG - 2021-12-08 10:01:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 10:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 10:01:51 --> Controller Class Initialized
DEBUG - 2021-12-08 10:01:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-12-08 10:01:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 10:01:51 --> Final output sent to browser
DEBUG - 2021-12-08 10:01:51 --> Total execution time: 0.0480
INFO - 2021-12-08 10:01:52 --> Config Class Initialized
INFO - 2021-12-08 10:01:52 --> Hooks Class Initialized
DEBUG - 2021-12-08 10:01:52 --> UTF-8 Support Enabled
INFO - 2021-12-08 10:01:52 --> Utf8 Class Initialized
INFO - 2021-12-08 10:01:52 --> URI Class Initialized
INFO - 2021-12-08 10:01:52 --> Router Class Initialized
INFO - 2021-12-08 10:01:52 --> Output Class Initialized
INFO - 2021-12-08 10:01:52 --> Security Class Initialized
DEBUG - 2021-12-08 10:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 10:01:52 --> Input Class Initialized
INFO - 2021-12-08 10:01:52 --> Language Class Initialized
INFO - 2021-12-08 10:01:52 --> Language Class Initialized
INFO - 2021-12-08 10:01:52 --> Config Class Initialized
INFO - 2021-12-08 10:01:52 --> Loader Class Initialized
INFO - 2021-12-08 10:01:52 --> Helper loaded: url_helper
INFO - 2021-12-08 10:01:52 --> Helper loaded: file_helper
INFO - 2021-12-08 10:01:52 --> Helper loaded: form_helper
INFO - 2021-12-08 10:01:52 --> Helper loaded: my_helper
INFO - 2021-12-08 10:01:52 --> Database Driver Class Initialized
DEBUG - 2021-12-08 10:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 10:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 10:01:52 --> Controller Class Initialized
DEBUG - 2021-12-08 10:01:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-12-08 10:01:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 10:01:52 --> Final output sent to browser
DEBUG - 2021-12-08 10:01:52 --> Total execution time: 0.0390
INFO - 2021-12-08 10:01:53 --> Config Class Initialized
INFO - 2021-12-08 10:01:53 --> Hooks Class Initialized
DEBUG - 2021-12-08 10:01:53 --> UTF-8 Support Enabled
INFO - 2021-12-08 10:01:53 --> Utf8 Class Initialized
INFO - 2021-12-08 10:01:53 --> URI Class Initialized
INFO - 2021-12-08 10:01:53 --> Router Class Initialized
INFO - 2021-12-08 10:01:53 --> Output Class Initialized
INFO - 2021-12-08 10:01:53 --> Security Class Initialized
DEBUG - 2021-12-08 10:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 10:01:53 --> Input Class Initialized
INFO - 2021-12-08 10:01:53 --> Language Class Initialized
INFO - 2021-12-08 10:01:53 --> Language Class Initialized
INFO - 2021-12-08 10:01:53 --> Config Class Initialized
INFO - 2021-12-08 10:01:53 --> Loader Class Initialized
INFO - 2021-12-08 10:01:53 --> Helper loaded: url_helper
INFO - 2021-12-08 10:01:53 --> Helper loaded: file_helper
INFO - 2021-12-08 10:01:53 --> Helper loaded: form_helper
INFO - 2021-12-08 10:01:53 --> Helper loaded: my_helper
INFO - 2021-12-08 10:01:53 --> Database Driver Class Initialized
DEBUG - 2021-12-08 10:01:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 10:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 10:01:53 --> Controller Class Initialized
INFO - 2021-12-08 10:01:53 --> Final output sent to browser
DEBUG - 2021-12-08 10:01:53 --> Total execution time: 0.0470
INFO - 2021-12-08 10:02:52 --> Config Class Initialized
INFO - 2021-12-08 10:02:52 --> Hooks Class Initialized
DEBUG - 2021-12-08 10:02:52 --> UTF-8 Support Enabled
INFO - 2021-12-08 10:02:52 --> Utf8 Class Initialized
INFO - 2021-12-08 10:02:52 --> URI Class Initialized
INFO - 2021-12-08 10:02:52 --> Router Class Initialized
INFO - 2021-12-08 10:02:52 --> Output Class Initialized
INFO - 2021-12-08 10:02:52 --> Security Class Initialized
DEBUG - 2021-12-08 10:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 10:02:52 --> Input Class Initialized
INFO - 2021-12-08 10:02:52 --> Language Class Initialized
INFO - 2021-12-08 10:02:52 --> Language Class Initialized
INFO - 2021-12-08 10:02:52 --> Config Class Initialized
INFO - 2021-12-08 10:02:52 --> Loader Class Initialized
INFO - 2021-12-08 10:02:52 --> Helper loaded: url_helper
INFO - 2021-12-08 10:02:52 --> Helper loaded: file_helper
INFO - 2021-12-08 10:02:52 --> Helper loaded: form_helper
INFO - 2021-12-08 10:02:52 --> Helper loaded: my_helper
INFO - 2021-12-08 10:02:52 --> Database Driver Class Initialized
DEBUG - 2021-12-08 10:02:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 10:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 10:02:52 --> Controller Class Initialized
INFO - 2021-12-08 10:02:52 --> Final output sent to browser
DEBUG - 2021-12-08 10:02:52 --> Total execution time: 0.0860
INFO - 2021-12-08 10:02:57 --> Config Class Initialized
INFO - 2021-12-08 10:02:57 --> Hooks Class Initialized
DEBUG - 2021-12-08 10:02:57 --> UTF-8 Support Enabled
INFO - 2021-12-08 10:02:57 --> Utf8 Class Initialized
INFO - 2021-12-08 10:02:57 --> URI Class Initialized
INFO - 2021-12-08 10:02:57 --> Router Class Initialized
INFO - 2021-12-08 10:02:57 --> Output Class Initialized
INFO - 2021-12-08 10:02:57 --> Security Class Initialized
DEBUG - 2021-12-08 10:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 10:02:57 --> Input Class Initialized
INFO - 2021-12-08 10:02:57 --> Language Class Initialized
INFO - 2021-12-08 10:02:57 --> Language Class Initialized
INFO - 2021-12-08 10:02:57 --> Config Class Initialized
INFO - 2021-12-08 10:02:57 --> Loader Class Initialized
INFO - 2021-12-08 10:02:57 --> Helper loaded: url_helper
INFO - 2021-12-08 10:02:57 --> Helper loaded: file_helper
INFO - 2021-12-08 10:02:57 --> Helper loaded: form_helper
INFO - 2021-12-08 10:02:57 --> Helper loaded: my_helper
INFO - 2021-12-08 10:02:57 --> Database Driver Class Initialized
DEBUG - 2021-12-08 10:02:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 10:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 10:02:57 --> Controller Class Initialized
DEBUG - 2021-12-08 10:02:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-12-08 10:02:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 10:02:57 --> Final output sent to browser
DEBUG - 2021-12-08 10:02:57 --> Total execution time: 0.0680
INFO - 2021-12-08 10:02:59 --> Config Class Initialized
INFO - 2021-12-08 10:02:59 --> Hooks Class Initialized
DEBUG - 2021-12-08 10:02:59 --> UTF-8 Support Enabled
INFO - 2021-12-08 10:02:59 --> Utf8 Class Initialized
INFO - 2021-12-08 10:02:59 --> URI Class Initialized
INFO - 2021-12-08 10:02:59 --> Router Class Initialized
INFO - 2021-12-08 10:02:59 --> Output Class Initialized
INFO - 2021-12-08 10:02:59 --> Security Class Initialized
DEBUG - 2021-12-08 10:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 10:02:59 --> Input Class Initialized
INFO - 2021-12-08 10:02:59 --> Language Class Initialized
INFO - 2021-12-08 10:02:59 --> Language Class Initialized
INFO - 2021-12-08 10:02:59 --> Config Class Initialized
INFO - 2021-12-08 10:02:59 --> Loader Class Initialized
INFO - 2021-12-08 10:02:59 --> Helper loaded: url_helper
INFO - 2021-12-08 10:02:59 --> Helper loaded: file_helper
INFO - 2021-12-08 10:02:59 --> Helper loaded: form_helper
INFO - 2021-12-08 10:02:59 --> Helper loaded: my_helper
INFO - 2021-12-08 10:02:59 --> Database Driver Class Initialized
DEBUG - 2021-12-08 10:02:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 10:02:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 10:02:59 --> Controller Class Initialized
DEBUG - 2021-12-08 10:02:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-12-08 10:02:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 10:02:59 --> Final output sent to browser
DEBUG - 2021-12-08 10:02:59 --> Total execution time: 0.0460
INFO - 2021-12-08 10:03:08 --> Config Class Initialized
INFO - 2021-12-08 10:03:08 --> Hooks Class Initialized
DEBUG - 2021-12-08 10:03:08 --> UTF-8 Support Enabled
INFO - 2021-12-08 10:03:08 --> Utf8 Class Initialized
INFO - 2021-12-08 10:03:08 --> URI Class Initialized
INFO - 2021-12-08 10:03:08 --> Router Class Initialized
INFO - 2021-12-08 10:03:08 --> Output Class Initialized
INFO - 2021-12-08 10:03:08 --> Security Class Initialized
DEBUG - 2021-12-08 10:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 10:03:08 --> Input Class Initialized
INFO - 2021-12-08 10:03:08 --> Language Class Initialized
INFO - 2021-12-08 10:03:08 --> Language Class Initialized
INFO - 2021-12-08 10:03:08 --> Config Class Initialized
INFO - 2021-12-08 10:03:08 --> Loader Class Initialized
INFO - 2021-12-08 10:03:08 --> Helper loaded: url_helper
INFO - 2021-12-08 10:03:08 --> Helper loaded: file_helper
INFO - 2021-12-08 10:03:08 --> Helper loaded: form_helper
INFO - 2021-12-08 10:03:08 --> Helper loaded: my_helper
INFO - 2021-12-08 10:03:08 --> Database Driver Class Initialized
DEBUG - 2021-12-08 10:03:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 10:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 10:03:08 --> Controller Class Initialized
DEBUG - 2021-12-08 10:03:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-12-08 10:03:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 10:03:08 --> Final output sent to browser
DEBUG - 2021-12-08 10:03:08 --> Total execution time: 0.0460
INFO - 2021-12-08 10:03:16 --> Config Class Initialized
INFO - 2021-12-08 10:03:16 --> Hooks Class Initialized
DEBUG - 2021-12-08 10:03:16 --> UTF-8 Support Enabled
INFO - 2021-12-08 10:03:16 --> Utf8 Class Initialized
INFO - 2021-12-08 10:03:16 --> URI Class Initialized
INFO - 2021-12-08 10:03:16 --> Router Class Initialized
INFO - 2021-12-08 10:03:16 --> Output Class Initialized
INFO - 2021-12-08 10:03:16 --> Security Class Initialized
DEBUG - 2021-12-08 10:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 10:03:16 --> Input Class Initialized
INFO - 2021-12-08 10:03:16 --> Language Class Initialized
INFO - 2021-12-08 10:03:16 --> Language Class Initialized
INFO - 2021-12-08 10:03:16 --> Config Class Initialized
INFO - 2021-12-08 10:03:16 --> Loader Class Initialized
INFO - 2021-12-08 10:03:16 --> Helper loaded: url_helper
INFO - 2021-12-08 10:03:16 --> Helper loaded: file_helper
INFO - 2021-12-08 10:03:16 --> Helper loaded: form_helper
INFO - 2021-12-08 10:03:16 --> Helper loaded: my_helper
INFO - 2021-12-08 10:03:16 --> Database Driver Class Initialized
DEBUG - 2021-12-08 10:03:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 10:03:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 10:03:16 --> Controller Class Initialized
DEBUG - 2021-12-08 10:03:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-08 10:03:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 10:03:16 --> Final output sent to browser
DEBUG - 2021-12-08 10:03:16 --> Total execution time: 0.0850
INFO - 2021-12-08 10:03:19 --> Config Class Initialized
INFO - 2021-12-08 10:03:19 --> Hooks Class Initialized
DEBUG - 2021-12-08 10:03:19 --> UTF-8 Support Enabled
INFO - 2021-12-08 10:03:19 --> Utf8 Class Initialized
INFO - 2021-12-08 10:03:19 --> URI Class Initialized
INFO - 2021-12-08 10:03:19 --> Router Class Initialized
INFO - 2021-12-08 10:03:19 --> Output Class Initialized
INFO - 2021-12-08 10:03:19 --> Security Class Initialized
DEBUG - 2021-12-08 10:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 10:03:19 --> Input Class Initialized
INFO - 2021-12-08 10:03:19 --> Language Class Initialized
INFO - 2021-12-08 10:03:19 --> Language Class Initialized
INFO - 2021-12-08 10:03:19 --> Config Class Initialized
INFO - 2021-12-08 10:03:19 --> Loader Class Initialized
INFO - 2021-12-08 10:03:19 --> Helper loaded: url_helper
INFO - 2021-12-08 10:03:19 --> Helper loaded: file_helper
INFO - 2021-12-08 10:03:19 --> Helper loaded: form_helper
INFO - 2021-12-08 10:03:19 --> Helper loaded: my_helper
INFO - 2021-12-08 10:03:19 --> Database Driver Class Initialized
DEBUG - 2021-12-08 10:03:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 10:03:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 10:03:19 --> Controller Class Initialized
DEBUG - 2021-12-08 10:03:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-12-08 10:03:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 10:03:19 --> Final output sent to browser
DEBUG - 2021-12-08 10:03:19 --> Total execution time: 0.0490
INFO - 2021-12-08 10:03:21 --> Config Class Initialized
INFO - 2021-12-08 10:03:21 --> Hooks Class Initialized
DEBUG - 2021-12-08 10:03:21 --> UTF-8 Support Enabled
INFO - 2021-12-08 10:03:21 --> Utf8 Class Initialized
INFO - 2021-12-08 10:03:21 --> URI Class Initialized
INFO - 2021-12-08 10:03:21 --> Router Class Initialized
INFO - 2021-12-08 10:03:21 --> Output Class Initialized
INFO - 2021-12-08 10:03:21 --> Security Class Initialized
DEBUG - 2021-12-08 10:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 10:03:21 --> Input Class Initialized
INFO - 2021-12-08 10:03:21 --> Language Class Initialized
INFO - 2021-12-08 10:03:21 --> Language Class Initialized
INFO - 2021-12-08 10:03:21 --> Config Class Initialized
INFO - 2021-12-08 10:03:21 --> Loader Class Initialized
INFO - 2021-12-08 10:03:21 --> Helper loaded: url_helper
INFO - 2021-12-08 10:03:21 --> Helper loaded: file_helper
INFO - 2021-12-08 10:03:21 --> Helper loaded: form_helper
INFO - 2021-12-08 10:03:21 --> Helper loaded: my_helper
INFO - 2021-12-08 10:03:21 --> Database Driver Class Initialized
DEBUG - 2021-12-08 10:03:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 10:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 10:03:21 --> Controller Class Initialized
DEBUG - 2021-12-08 10:03:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-08 10:03:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 10:03:21 --> Final output sent to browser
DEBUG - 2021-12-08 10:03:21 --> Total execution time: 0.0880
INFO - 2021-12-08 10:03:22 --> Config Class Initialized
INFO - 2021-12-08 10:03:22 --> Hooks Class Initialized
DEBUG - 2021-12-08 10:03:22 --> UTF-8 Support Enabled
INFO - 2021-12-08 10:03:22 --> Utf8 Class Initialized
INFO - 2021-12-08 10:03:22 --> URI Class Initialized
INFO - 2021-12-08 10:03:22 --> Router Class Initialized
INFO - 2021-12-08 10:03:22 --> Output Class Initialized
INFO - 2021-12-08 10:03:22 --> Security Class Initialized
DEBUG - 2021-12-08 10:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 10:03:22 --> Input Class Initialized
INFO - 2021-12-08 10:03:22 --> Language Class Initialized
INFO - 2021-12-08 10:03:22 --> Language Class Initialized
INFO - 2021-12-08 10:03:22 --> Config Class Initialized
INFO - 2021-12-08 10:03:22 --> Loader Class Initialized
INFO - 2021-12-08 10:03:22 --> Helper loaded: url_helper
INFO - 2021-12-08 10:03:22 --> Helper loaded: file_helper
INFO - 2021-12-08 10:03:22 --> Helper loaded: form_helper
INFO - 2021-12-08 10:03:22 --> Helper loaded: my_helper
INFO - 2021-12-08 10:03:22 --> Database Driver Class Initialized
DEBUG - 2021-12-08 10:03:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 10:03:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 10:03:22 --> Controller Class Initialized
DEBUG - 2021-12-08 10:03:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-12-08 10:03:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 10:03:22 --> Final output sent to browser
DEBUG - 2021-12-08 10:03:22 --> Total execution time: 0.0610
INFO - 2021-12-08 10:03:24 --> Config Class Initialized
INFO - 2021-12-08 10:03:24 --> Hooks Class Initialized
DEBUG - 2021-12-08 10:03:24 --> UTF-8 Support Enabled
INFO - 2021-12-08 10:03:24 --> Utf8 Class Initialized
INFO - 2021-12-08 10:03:24 --> URI Class Initialized
INFO - 2021-12-08 10:03:24 --> Router Class Initialized
INFO - 2021-12-08 10:03:24 --> Output Class Initialized
INFO - 2021-12-08 10:03:24 --> Security Class Initialized
DEBUG - 2021-12-08 10:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 10:03:24 --> Input Class Initialized
INFO - 2021-12-08 10:03:24 --> Language Class Initialized
INFO - 2021-12-08 10:03:24 --> Language Class Initialized
INFO - 2021-12-08 10:03:24 --> Config Class Initialized
INFO - 2021-12-08 10:03:24 --> Loader Class Initialized
INFO - 2021-12-08 10:03:24 --> Helper loaded: url_helper
INFO - 2021-12-08 10:03:24 --> Helper loaded: file_helper
INFO - 2021-12-08 10:03:24 --> Helper loaded: form_helper
INFO - 2021-12-08 10:03:24 --> Helper loaded: my_helper
INFO - 2021-12-08 10:03:24 --> Database Driver Class Initialized
DEBUG - 2021-12-08 10:03:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 10:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 10:03:24 --> Controller Class Initialized
DEBUG - 2021-12-08 10:03:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-12-08 10:03:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 10:03:24 --> Final output sent to browser
DEBUG - 2021-12-08 10:03:24 --> Total execution time: 0.0570
INFO - 2021-12-08 10:03:27 --> Config Class Initialized
INFO - 2021-12-08 10:03:27 --> Hooks Class Initialized
DEBUG - 2021-12-08 10:03:27 --> UTF-8 Support Enabled
INFO - 2021-12-08 10:03:27 --> Utf8 Class Initialized
INFO - 2021-12-08 10:03:27 --> URI Class Initialized
INFO - 2021-12-08 10:03:27 --> Router Class Initialized
INFO - 2021-12-08 10:03:27 --> Output Class Initialized
INFO - 2021-12-08 10:03:27 --> Security Class Initialized
DEBUG - 2021-12-08 10:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 10:03:27 --> Input Class Initialized
INFO - 2021-12-08 10:03:27 --> Language Class Initialized
INFO - 2021-12-08 10:03:27 --> Language Class Initialized
INFO - 2021-12-08 10:03:27 --> Config Class Initialized
INFO - 2021-12-08 10:03:27 --> Loader Class Initialized
INFO - 2021-12-08 10:03:27 --> Helper loaded: url_helper
INFO - 2021-12-08 10:03:27 --> Helper loaded: file_helper
INFO - 2021-12-08 10:03:27 --> Helper loaded: form_helper
INFO - 2021-12-08 10:03:27 --> Helper loaded: my_helper
INFO - 2021-12-08 10:03:27 --> Database Driver Class Initialized
DEBUG - 2021-12-08 10:03:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 10:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 10:03:27 --> Controller Class Initialized
INFO - 2021-12-08 10:03:27 --> Final output sent to browser
DEBUG - 2021-12-08 10:03:27 --> Total execution time: 0.0580
INFO - 2021-12-08 10:03:29 --> Config Class Initialized
INFO - 2021-12-08 10:03:29 --> Hooks Class Initialized
DEBUG - 2021-12-08 10:03:29 --> UTF-8 Support Enabled
INFO - 2021-12-08 10:03:29 --> Utf8 Class Initialized
INFO - 2021-12-08 10:03:29 --> URI Class Initialized
INFO - 2021-12-08 10:03:29 --> Router Class Initialized
INFO - 2021-12-08 10:03:29 --> Output Class Initialized
INFO - 2021-12-08 10:03:29 --> Security Class Initialized
DEBUG - 2021-12-08 10:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 10:03:29 --> Input Class Initialized
INFO - 2021-12-08 10:03:29 --> Language Class Initialized
INFO - 2021-12-08 10:03:29 --> Language Class Initialized
INFO - 2021-12-08 10:03:29 --> Config Class Initialized
INFO - 2021-12-08 10:03:29 --> Loader Class Initialized
INFO - 2021-12-08 10:03:29 --> Helper loaded: url_helper
INFO - 2021-12-08 10:03:29 --> Helper loaded: file_helper
INFO - 2021-12-08 10:03:29 --> Helper loaded: form_helper
INFO - 2021-12-08 10:03:29 --> Helper loaded: my_helper
INFO - 2021-12-08 10:03:29 --> Database Driver Class Initialized
DEBUG - 2021-12-08 10:03:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 10:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 10:03:29 --> Controller Class Initialized
DEBUG - 2021-12-08 10:03:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-12-08 10:03:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 10:03:29 --> Final output sent to browser
DEBUG - 2021-12-08 10:03:29 --> Total execution time: 0.0510
INFO - 2021-12-08 10:03:34 --> Config Class Initialized
INFO - 2021-12-08 10:03:34 --> Hooks Class Initialized
DEBUG - 2021-12-08 10:03:34 --> UTF-8 Support Enabled
INFO - 2021-12-08 10:03:34 --> Utf8 Class Initialized
INFO - 2021-12-08 10:03:34 --> URI Class Initialized
INFO - 2021-12-08 10:03:34 --> Router Class Initialized
INFO - 2021-12-08 10:03:34 --> Output Class Initialized
INFO - 2021-12-08 10:03:34 --> Security Class Initialized
DEBUG - 2021-12-08 10:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 10:03:34 --> Input Class Initialized
INFO - 2021-12-08 10:03:34 --> Language Class Initialized
INFO - 2021-12-08 10:03:34 --> Language Class Initialized
INFO - 2021-12-08 10:03:34 --> Config Class Initialized
INFO - 2021-12-08 10:03:34 --> Loader Class Initialized
INFO - 2021-12-08 10:03:34 --> Helper loaded: url_helper
INFO - 2021-12-08 10:03:34 --> Helper loaded: file_helper
INFO - 2021-12-08 10:03:34 --> Helper loaded: form_helper
INFO - 2021-12-08 10:03:34 --> Helper loaded: my_helper
INFO - 2021-12-08 10:03:34 --> Database Driver Class Initialized
DEBUG - 2021-12-08 10:03:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 10:03:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 10:03:34 --> Controller Class Initialized
INFO - 2021-12-08 10:03:34 --> Helper loaded: cookie_helper
INFO - 2021-12-08 10:03:34 --> Config Class Initialized
INFO - 2021-12-08 10:03:34 --> Hooks Class Initialized
DEBUG - 2021-12-08 10:03:34 --> UTF-8 Support Enabled
INFO - 2021-12-08 10:03:34 --> Utf8 Class Initialized
INFO - 2021-12-08 10:03:34 --> URI Class Initialized
INFO - 2021-12-08 10:03:34 --> Router Class Initialized
INFO - 2021-12-08 10:03:34 --> Output Class Initialized
INFO - 2021-12-08 10:03:34 --> Security Class Initialized
DEBUG - 2021-12-08 10:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 10:03:34 --> Input Class Initialized
INFO - 2021-12-08 10:03:34 --> Language Class Initialized
INFO - 2021-12-08 10:03:34 --> Language Class Initialized
INFO - 2021-12-08 10:03:34 --> Config Class Initialized
INFO - 2021-12-08 10:03:34 --> Loader Class Initialized
INFO - 2021-12-08 10:03:34 --> Helper loaded: url_helper
INFO - 2021-12-08 10:03:34 --> Helper loaded: file_helper
INFO - 2021-12-08 10:03:34 --> Helper loaded: form_helper
INFO - 2021-12-08 10:03:34 --> Helper loaded: my_helper
INFO - 2021-12-08 10:03:34 --> Database Driver Class Initialized
DEBUG - 2021-12-08 10:03:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 10:03:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 10:03:34 --> Controller Class Initialized
DEBUG - 2021-12-08 10:03:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-08 10:03:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 10:03:34 --> Final output sent to browser
DEBUG - 2021-12-08 10:03:34 --> Total execution time: 0.0400
INFO - 2021-12-08 10:03:46 --> Config Class Initialized
INFO - 2021-12-08 10:03:46 --> Hooks Class Initialized
DEBUG - 2021-12-08 10:03:46 --> UTF-8 Support Enabled
INFO - 2021-12-08 10:03:46 --> Utf8 Class Initialized
INFO - 2021-12-08 10:03:46 --> URI Class Initialized
INFO - 2021-12-08 10:03:46 --> Router Class Initialized
INFO - 2021-12-08 10:03:46 --> Output Class Initialized
INFO - 2021-12-08 10:03:46 --> Security Class Initialized
DEBUG - 2021-12-08 10:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 10:03:46 --> Input Class Initialized
INFO - 2021-12-08 10:03:46 --> Language Class Initialized
INFO - 2021-12-08 10:03:46 --> Language Class Initialized
INFO - 2021-12-08 10:03:46 --> Config Class Initialized
INFO - 2021-12-08 10:03:46 --> Loader Class Initialized
INFO - 2021-12-08 10:03:46 --> Helper loaded: url_helper
INFO - 2021-12-08 10:03:46 --> Helper loaded: file_helper
INFO - 2021-12-08 10:03:46 --> Helper loaded: form_helper
INFO - 2021-12-08 10:03:46 --> Helper loaded: my_helper
INFO - 2021-12-08 10:03:46 --> Database Driver Class Initialized
DEBUG - 2021-12-08 10:03:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 10:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 10:03:46 --> Controller Class Initialized
INFO - 2021-12-08 10:03:46 --> Helper loaded: cookie_helper
INFO - 2021-12-08 10:03:46 --> Final output sent to browser
DEBUG - 2021-12-08 10:03:46 --> Total execution time: 0.0490
INFO - 2021-12-08 10:03:47 --> Config Class Initialized
INFO - 2021-12-08 10:03:47 --> Hooks Class Initialized
DEBUG - 2021-12-08 10:03:47 --> UTF-8 Support Enabled
INFO - 2021-12-08 10:03:47 --> Utf8 Class Initialized
INFO - 2021-12-08 10:03:47 --> URI Class Initialized
INFO - 2021-12-08 10:03:47 --> Router Class Initialized
INFO - 2021-12-08 10:03:47 --> Output Class Initialized
INFO - 2021-12-08 10:03:47 --> Security Class Initialized
DEBUG - 2021-12-08 10:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 10:03:47 --> Input Class Initialized
INFO - 2021-12-08 10:03:47 --> Language Class Initialized
INFO - 2021-12-08 10:03:47 --> Language Class Initialized
INFO - 2021-12-08 10:03:47 --> Config Class Initialized
INFO - 2021-12-08 10:03:47 --> Loader Class Initialized
INFO - 2021-12-08 10:03:47 --> Helper loaded: url_helper
INFO - 2021-12-08 10:03:47 --> Helper loaded: file_helper
INFO - 2021-12-08 10:03:47 --> Helper loaded: form_helper
INFO - 2021-12-08 10:03:47 --> Helper loaded: my_helper
INFO - 2021-12-08 10:03:47 --> Database Driver Class Initialized
DEBUG - 2021-12-08 10:03:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 10:03:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 10:03:47 --> Controller Class Initialized
DEBUG - 2021-12-08 10:03:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-08 10:03:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 10:03:48 --> Final output sent to browser
DEBUG - 2021-12-08 10:03:48 --> Total execution time: 0.2460
INFO - 2021-12-08 10:03:51 --> Config Class Initialized
INFO - 2021-12-08 10:03:51 --> Hooks Class Initialized
DEBUG - 2021-12-08 10:03:51 --> UTF-8 Support Enabled
INFO - 2021-12-08 10:03:51 --> Utf8 Class Initialized
INFO - 2021-12-08 10:03:51 --> URI Class Initialized
INFO - 2021-12-08 10:03:51 --> Router Class Initialized
INFO - 2021-12-08 10:03:51 --> Output Class Initialized
INFO - 2021-12-08 10:03:51 --> Security Class Initialized
DEBUG - 2021-12-08 10:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 10:03:51 --> Input Class Initialized
INFO - 2021-12-08 10:03:51 --> Language Class Initialized
INFO - 2021-12-08 10:03:51 --> Language Class Initialized
INFO - 2021-12-08 10:03:51 --> Config Class Initialized
INFO - 2021-12-08 10:03:51 --> Loader Class Initialized
INFO - 2021-12-08 10:03:51 --> Helper loaded: url_helper
INFO - 2021-12-08 10:03:51 --> Helper loaded: file_helper
INFO - 2021-12-08 10:03:51 --> Helper loaded: form_helper
INFO - 2021-12-08 10:03:52 --> Helper loaded: my_helper
INFO - 2021-12-08 10:03:52 --> Database Driver Class Initialized
DEBUG - 2021-12-08 10:03:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 10:03:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 10:03:52 --> Controller Class Initialized
DEBUG - 2021-12-08 10:03:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-12-08 10:03:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 10:03:52 --> Final output sent to browser
DEBUG - 2021-12-08 10:03:52 --> Total execution time: 0.0410
INFO - 2021-12-08 10:03:52 --> Config Class Initialized
INFO - 2021-12-08 10:03:52 --> Hooks Class Initialized
DEBUG - 2021-12-08 10:03:52 --> UTF-8 Support Enabled
INFO - 2021-12-08 10:03:52 --> Utf8 Class Initialized
INFO - 2021-12-08 10:03:52 --> URI Class Initialized
INFO - 2021-12-08 10:03:52 --> Router Class Initialized
INFO - 2021-12-08 10:03:52 --> Output Class Initialized
INFO - 2021-12-08 10:03:52 --> Security Class Initialized
DEBUG - 2021-12-08 10:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 10:03:52 --> Input Class Initialized
INFO - 2021-12-08 10:03:52 --> Language Class Initialized
INFO - 2021-12-08 10:03:52 --> Language Class Initialized
INFO - 2021-12-08 10:03:52 --> Config Class Initialized
INFO - 2021-12-08 10:03:52 --> Loader Class Initialized
INFO - 2021-12-08 10:03:52 --> Helper loaded: url_helper
INFO - 2021-12-08 10:03:52 --> Helper loaded: file_helper
INFO - 2021-12-08 10:03:52 --> Helper loaded: form_helper
INFO - 2021-12-08 10:03:52 --> Helper loaded: my_helper
INFO - 2021-12-08 10:03:52 --> Database Driver Class Initialized
DEBUG - 2021-12-08 10:03:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 10:03:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 10:03:52 --> Controller Class Initialized
INFO - 2021-12-08 10:03:59 --> Config Class Initialized
INFO - 2021-12-08 10:03:59 --> Hooks Class Initialized
DEBUG - 2021-12-08 10:03:59 --> UTF-8 Support Enabled
INFO - 2021-12-08 10:03:59 --> Utf8 Class Initialized
INFO - 2021-12-08 10:03:59 --> URI Class Initialized
INFO - 2021-12-08 10:03:59 --> Router Class Initialized
INFO - 2021-12-08 10:03:59 --> Output Class Initialized
INFO - 2021-12-08 10:03:59 --> Security Class Initialized
DEBUG - 2021-12-08 10:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 10:03:59 --> Input Class Initialized
INFO - 2021-12-08 10:03:59 --> Language Class Initialized
INFO - 2021-12-08 10:03:59 --> Language Class Initialized
INFO - 2021-12-08 10:03:59 --> Config Class Initialized
INFO - 2021-12-08 10:03:59 --> Loader Class Initialized
INFO - 2021-12-08 10:03:59 --> Helper loaded: url_helper
INFO - 2021-12-08 10:03:59 --> Helper loaded: file_helper
INFO - 2021-12-08 10:03:59 --> Helper loaded: form_helper
INFO - 2021-12-08 10:03:59 --> Helper loaded: my_helper
INFO - 2021-12-08 10:03:59 --> Database Driver Class Initialized
DEBUG - 2021-12-08 10:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 10:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 10:03:59 --> Controller Class Initialized
INFO - 2021-12-08 10:03:59 --> Helper loaded: cookie_helper
INFO - 2021-12-08 10:04:00 --> Config Class Initialized
INFO - 2021-12-08 10:04:00 --> Hooks Class Initialized
DEBUG - 2021-12-08 10:04:00 --> UTF-8 Support Enabled
INFO - 2021-12-08 10:04:00 --> Utf8 Class Initialized
INFO - 2021-12-08 10:04:00 --> URI Class Initialized
INFO - 2021-12-08 10:04:00 --> Router Class Initialized
INFO - 2021-12-08 10:04:00 --> Output Class Initialized
INFO - 2021-12-08 10:04:00 --> Security Class Initialized
DEBUG - 2021-12-08 10:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 10:04:00 --> Input Class Initialized
INFO - 2021-12-08 10:04:00 --> Language Class Initialized
INFO - 2021-12-08 10:04:00 --> Language Class Initialized
INFO - 2021-12-08 10:04:00 --> Config Class Initialized
INFO - 2021-12-08 10:04:00 --> Loader Class Initialized
INFO - 2021-12-08 10:04:00 --> Helper loaded: url_helper
INFO - 2021-12-08 10:04:00 --> Helper loaded: file_helper
INFO - 2021-12-08 10:04:00 --> Helper loaded: form_helper
INFO - 2021-12-08 10:04:00 --> Helper loaded: my_helper
INFO - 2021-12-08 10:04:00 --> Database Driver Class Initialized
DEBUG - 2021-12-08 10:04:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 10:04:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 10:04:00 --> Controller Class Initialized
DEBUG - 2021-12-08 10:04:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-08 10:04:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 10:04:00 --> Final output sent to browser
DEBUG - 2021-12-08 10:04:00 --> Total execution time: 0.0350
INFO - 2021-12-08 10:04:14 --> Config Class Initialized
INFO - 2021-12-08 10:04:14 --> Hooks Class Initialized
DEBUG - 2021-12-08 10:04:14 --> UTF-8 Support Enabled
INFO - 2021-12-08 10:04:14 --> Utf8 Class Initialized
INFO - 2021-12-08 10:04:14 --> URI Class Initialized
INFO - 2021-12-08 10:04:14 --> Router Class Initialized
INFO - 2021-12-08 10:04:14 --> Output Class Initialized
INFO - 2021-12-08 10:04:14 --> Security Class Initialized
DEBUG - 2021-12-08 10:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 10:04:14 --> Input Class Initialized
INFO - 2021-12-08 10:04:14 --> Language Class Initialized
INFO - 2021-12-08 10:04:14 --> Language Class Initialized
INFO - 2021-12-08 10:04:14 --> Config Class Initialized
INFO - 2021-12-08 10:04:14 --> Loader Class Initialized
INFO - 2021-12-08 10:04:14 --> Helper loaded: url_helper
INFO - 2021-12-08 10:04:14 --> Helper loaded: file_helper
INFO - 2021-12-08 10:04:14 --> Helper loaded: form_helper
INFO - 2021-12-08 10:04:14 --> Helper loaded: my_helper
INFO - 2021-12-08 10:04:14 --> Database Driver Class Initialized
DEBUG - 2021-12-08 10:04:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 10:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 10:04:14 --> Controller Class Initialized
INFO - 2021-12-08 10:04:14 --> Helper loaded: cookie_helper
INFO - 2021-12-08 10:04:14 --> Final output sent to browser
DEBUG - 2021-12-08 10:04:14 --> Total execution time: 0.0680
INFO - 2021-12-08 10:04:15 --> Config Class Initialized
INFO - 2021-12-08 10:04:15 --> Hooks Class Initialized
DEBUG - 2021-12-08 10:04:15 --> UTF-8 Support Enabled
INFO - 2021-12-08 10:04:15 --> Utf8 Class Initialized
INFO - 2021-12-08 10:04:15 --> URI Class Initialized
INFO - 2021-12-08 10:04:15 --> Router Class Initialized
INFO - 2021-12-08 10:04:15 --> Output Class Initialized
INFO - 2021-12-08 10:04:15 --> Security Class Initialized
DEBUG - 2021-12-08 10:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 10:04:15 --> Input Class Initialized
INFO - 2021-12-08 10:04:15 --> Language Class Initialized
INFO - 2021-12-08 10:04:15 --> Language Class Initialized
INFO - 2021-12-08 10:04:15 --> Config Class Initialized
INFO - 2021-12-08 10:04:15 --> Loader Class Initialized
INFO - 2021-12-08 10:04:15 --> Helper loaded: url_helper
INFO - 2021-12-08 10:04:15 --> Helper loaded: file_helper
INFO - 2021-12-08 10:04:15 --> Helper loaded: form_helper
INFO - 2021-12-08 10:04:15 --> Helper loaded: my_helper
INFO - 2021-12-08 10:04:15 --> Database Driver Class Initialized
DEBUG - 2021-12-08 10:04:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 10:04:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 10:04:15 --> Controller Class Initialized
DEBUG - 2021-12-08 10:04:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-08 10:04:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 10:04:15 --> Final output sent to browser
DEBUG - 2021-12-08 10:04:15 --> Total execution time: 0.1520
INFO - 2021-12-08 10:04:18 --> Config Class Initialized
INFO - 2021-12-08 10:04:18 --> Hooks Class Initialized
DEBUG - 2021-12-08 10:04:18 --> UTF-8 Support Enabled
INFO - 2021-12-08 10:04:18 --> Utf8 Class Initialized
INFO - 2021-12-08 10:04:18 --> URI Class Initialized
INFO - 2021-12-08 10:04:18 --> Router Class Initialized
INFO - 2021-12-08 10:04:18 --> Output Class Initialized
INFO - 2021-12-08 10:04:18 --> Security Class Initialized
DEBUG - 2021-12-08 10:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 10:04:18 --> Input Class Initialized
INFO - 2021-12-08 10:04:18 --> Language Class Initialized
INFO - 2021-12-08 10:04:18 --> Language Class Initialized
INFO - 2021-12-08 10:04:18 --> Config Class Initialized
INFO - 2021-12-08 10:04:18 --> Loader Class Initialized
INFO - 2021-12-08 10:04:18 --> Helper loaded: url_helper
INFO - 2021-12-08 10:04:18 --> Helper loaded: file_helper
INFO - 2021-12-08 10:04:18 --> Helper loaded: form_helper
INFO - 2021-12-08 10:04:18 --> Helper loaded: my_helper
INFO - 2021-12-08 10:04:18 --> Database Driver Class Initialized
DEBUG - 2021-12-08 10:04:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 10:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 10:04:18 --> Controller Class Initialized
DEBUG - 2021-12-08 10:04:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-08 10:04:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 10:04:18 --> Final output sent to browser
DEBUG - 2021-12-08 10:04:18 --> Total execution time: 0.0800
INFO - 2021-12-08 10:06:02 --> Config Class Initialized
INFO - 2021-12-08 10:06:02 --> Hooks Class Initialized
DEBUG - 2021-12-08 10:06:02 --> UTF-8 Support Enabled
INFO - 2021-12-08 10:06:02 --> Utf8 Class Initialized
INFO - 2021-12-08 10:06:02 --> URI Class Initialized
INFO - 2021-12-08 10:06:02 --> Router Class Initialized
INFO - 2021-12-08 10:06:02 --> Output Class Initialized
INFO - 2021-12-08 10:06:02 --> Security Class Initialized
DEBUG - 2021-12-08 10:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 10:06:02 --> Input Class Initialized
INFO - 2021-12-08 10:06:02 --> Language Class Initialized
INFO - 2021-12-08 10:06:02 --> Language Class Initialized
INFO - 2021-12-08 10:06:02 --> Config Class Initialized
INFO - 2021-12-08 10:06:02 --> Loader Class Initialized
INFO - 2021-12-08 10:06:02 --> Helper loaded: url_helper
INFO - 2021-12-08 10:06:02 --> Helper loaded: file_helper
INFO - 2021-12-08 10:06:02 --> Helper loaded: form_helper
INFO - 2021-12-08 10:06:02 --> Helper loaded: my_helper
INFO - 2021-12-08 10:06:02 --> Database Driver Class Initialized
DEBUG - 2021-12-08 10:06:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 10:06:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 10:06:02 --> Controller Class Initialized
INFO - 2021-12-08 10:06:02 --> Final output sent to browser
DEBUG - 2021-12-08 10:06:02 --> Total execution time: 0.0570
INFO - 2021-12-08 10:06:10 --> Config Class Initialized
INFO - 2021-12-08 10:06:10 --> Hooks Class Initialized
DEBUG - 2021-12-08 10:06:10 --> UTF-8 Support Enabled
INFO - 2021-12-08 10:06:10 --> Utf8 Class Initialized
INFO - 2021-12-08 10:06:10 --> URI Class Initialized
INFO - 2021-12-08 10:06:10 --> Router Class Initialized
INFO - 2021-12-08 10:06:10 --> Output Class Initialized
INFO - 2021-12-08 10:06:10 --> Security Class Initialized
DEBUG - 2021-12-08 10:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 10:06:10 --> Input Class Initialized
INFO - 2021-12-08 10:06:10 --> Language Class Initialized
INFO - 2021-12-08 10:06:10 --> Language Class Initialized
INFO - 2021-12-08 10:06:10 --> Config Class Initialized
INFO - 2021-12-08 10:06:10 --> Loader Class Initialized
INFO - 2021-12-08 10:06:10 --> Helper loaded: url_helper
INFO - 2021-12-08 10:06:10 --> Helper loaded: file_helper
INFO - 2021-12-08 10:06:10 --> Helper loaded: form_helper
INFO - 2021-12-08 10:06:10 --> Helper loaded: my_helper
INFO - 2021-12-08 10:06:10 --> Database Driver Class Initialized
DEBUG - 2021-12-08 10:06:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 10:06:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 10:06:10 --> Controller Class Initialized
DEBUG - 2021-12-08 10:06:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-08 10:06:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 10:06:10 --> Final output sent to browser
DEBUG - 2021-12-08 10:06:10 --> Total execution time: 0.0620
INFO - 2021-12-08 10:06:11 --> Config Class Initialized
INFO - 2021-12-08 10:06:11 --> Hooks Class Initialized
DEBUG - 2021-12-08 10:06:11 --> UTF-8 Support Enabled
INFO - 2021-12-08 10:06:11 --> Utf8 Class Initialized
INFO - 2021-12-08 10:06:11 --> URI Class Initialized
INFO - 2021-12-08 10:06:11 --> Router Class Initialized
INFO - 2021-12-08 10:06:11 --> Output Class Initialized
INFO - 2021-12-08 10:06:11 --> Security Class Initialized
DEBUG - 2021-12-08 10:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 10:06:11 --> Input Class Initialized
INFO - 2021-12-08 10:06:11 --> Language Class Initialized
INFO - 2021-12-08 10:06:11 --> Language Class Initialized
INFO - 2021-12-08 10:06:11 --> Config Class Initialized
INFO - 2021-12-08 10:06:11 --> Loader Class Initialized
INFO - 2021-12-08 10:06:11 --> Helper loaded: url_helper
INFO - 2021-12-08 10:06:11 --> Helper loaded: file_helper
INFO - 2021-12-08 10:06:11 --> Helper loaded: form_helper
INFO - 2021-12-08 10:06:11 --> Helper loaded: my_helper
INFO - 2021-12-08 10:06:11 --> Database Driver Class Initialized
DEBUG - 2021-12-08 10:06:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 10:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 10:06:11 --> Controller Class Initialized
DEBUG - 2021-12-08 10:06:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-12-08 10:06:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 10:06:11 --> Final output sent to browser
DEBUG - 2021-12-08 10:06:11 --> Total execution time: 0.0490
INFO - 2021-12-08 10:06:57 --> Config Class Initialized
INFO - 2021-12-08 10:06:57 --> Hooks Class Initialized
DEBUG - 2021-12-08 10:06:57 --> UTF-8 Support Enabled
INFO - 2021-12-08 10:06:57 --> Utf8 Class Initialized
INFO - 2021-12-08 10:06:57 --> URI Class Initialized
INFO - 2021-12-08 10:06:57 --> Router Class Initialized
INFO - 2021-12-08 10:06:57 --> Output Class Initialized
INFO - 2021-12-08 10:06:57 --> Security Class Initialized
DEBUG - 2021-12-08 10:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 10:06:57 --> Input Class Initialized
INFO - 2021-12-08 10:06:57 --> Language Class Initialized
INFO - 2021-12-08 10:06:57 --> Language Class Initialized
INFO - 2021-12-08 10:06:57 --> Config Class Initialized
INFO - 2021-12-08 10:06:57 --> Loader Class Initialized
INFO - 2021-12-08 10:06:57 --> Helper loaded: url_helper
INFO - 2021-12-08 10:06:57 --> Helper loaded: file_helper
INFO - 2021-12-08 10:06:57 --> Helper loaded: form_helper
INFO - 2021-12-08 10:06:57 --> Helper loaded: my_helper
INFO - 2021-12-08 10:06:57 --> Database Driver Class Initialized
DEBUG - 2021-12-08 10:06:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 10:06:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 10:06:57 --> Controller Class Initialized
INFO - 2021-12-08 10:06:57 --> Final output sent to browser
DEBUG - 2021-12-08 10:06:57 --> Total execution time: 0.0590
INFO - 2021-12-08 10:07:02 --> Config Class Initialized
INFO - 2021-12-08 10:07:02 --> Hooks Class Initialized
DEBUG - 2021-12-08 10:07:02 --> UTF-8 Support Enabled
INFO - 2021-12-08 10:07:02 --> Utf8 Class Initialized
INFO - 2021-12-08 10:07:02 --> URI Class Initialized
INFO - 2021-12-08 10:07:02 --> Router Class Initialized
INFO - 2021-12-08 10:07:02 --> Output Class Initialized
INFO - 2021-12-08 10:07:02 --> Security Class Initialized
DEBUG - 2021-12-08 10:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 10:07:02 --> Input Class Initialized
INFO - 2021-12-08 10:07:02 --> Language Class Initialized
INFO - 2021-12-08 10:07:02 --> Language Class Initialized
INFO - 2021-12-08 10:07:02 --> Config Class Initialized
INFO - 2021-12-08 10:07:02 --> Loader Class Initialized
INFO - 2021-12-08 10:07:02 --> Helper loaded: url_helper
INFO - 2021-12-08 10:07:02 --> Helper loaded: file_helper
INFO - 2021-12-08 10:07:02 --> Helper loaded: form_helper
INFO - 2021-12-08 10:07:02 --> Helper loaded: my_helper
INFO - 2021-12-08 10:07:02 --> Database Driver Class Initialized
DEBUG - 2021-12-08 10:07:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 10:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 10:07:02 --> Controller Class Initialized
DEBUG - 2021-12-08 10:07:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-12-08 10:07:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 10:07:02 --> Final output sent to browser
DEBUG - 2021-12-08 10:07:02 --> Total execution time: 0.0490
INFO - 2021-12-08 10:07:03 --> Config Class Initialized
INFO - 2021-12-08 10:07:03 --> Hooks Class Initialized
DEBUG - 2021-12-08 10:07:03 --> UTF-8 Support Enabled
INFO - 2021-12-08 10:07:03 --> Utf8 Class Initialized
INFO - 2021-12-08 10:07:03 --> URI Class Initialized
INFO - 2021-12-08 10:07:03 --> Router Class Initialized
INFO - 2021-12-08 10:07:03 --> Output Class Initialized
INFO - 2021-12-08 10:07:03 --> Security Class Initialized
DEBUG - 2021-12-08 10:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 10:07:03 --> Input Class Initialized
INFO - 2021-12-08 10:07:03 --> Language Class Initialized
INFO - 2021-12-08 10:07:03 --> Language Class Initialized
INFO - 2021-12-08 10:07:03 --> Config Class Initialized
INFO - 2021-12-08 10:07:03 --> Loader Class Initialized
INFO - 2021-12-08 10:07:03 --> Helper loaded: url_helper
INFO - 2021-12-08 10:07:03 --> Helper loaded: file_helper
INFO - 2021-12-08 10:07:03 --> Helper loaded: form_helper
INFO - 2021-12-08 10:07:03 --> Helper loaded: my_helper
INFO - 2021-12-08 10:07:03 --> Database Driver Class Initialized
DEBUG - 2021-12-08 10:07:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 10:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 10:07:03 --> Controller Class Initialized
INFO - 2021-12-08 10:07:03 --> Final output sent to browser
DEBUG - 2021-12-08 10:07:03 --> Total execution time: 0.0590
INFO - 2021-12-08 10:07:13 --> Config Class Initialized
INFO - 2021-12-08 10:07:13 --> Hooks Class Initialized
DEBUG - 2021-12-08 10:07:13 --> UTF-8 Support Enabled
INFO - 2021-12-08 10:07:13 --> Utf8 Class Initialized
INFO - 2021-12-08 10:07:13 --> URI Class Initialized
INFO - 2021-12-08 10:07:13 --> Router Class Initialized
INFO - 2021-12-08 10:07:13 --> Output Class Initialized
INFO - 2021-12-08 10:07:13 --> Security Class Initialized
DEBUG - 2021-12-08 10:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 10:07:13 --> Input Class Initialized
INFO - 2021-12-08 10:07:13 --> Language Class Initialized
INFO - 2021-12-08 10:07:13 --> Language Class Initialized
INFO - 2021-12-08 10:07:13 --> Config Class Initialized
INFO - 2021-12-08 10:07:13 --> Loader Class Initialized
INFO - 2021-12-08 10:07:13 --> Helper loaded: url_helper
INFO - 2021-12-08 10:07:13 --> Helper loaded: file_helper
INFO - 2021-12-08 10:07:13 --> Helper loaded: form_helper
INFO - 2021-12-08 10:07:13 --> Helper loaded: my_helper
INFO - 2021-12-08 10:07:13 --> Database Driver Class Initialized
DEBUG - 2021-12-08 10:07:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 10:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 10:07:13 --> Controller Class Initialized
INFO - 2021-12-08 10:07:13 --> Final output sent to browser
DEBUG - 2021-12-08 10:07:13 --> Total execution time: 0.0650
INFO - 2021-12-08 10:07:17 --> Config Class Initialized
INFO - 2021-12-08 10:07:17 --> Hooks Class Initialized
DEBUG - 2021-12-08 10:07:17 --> UTF-8 Support Enabled
INFO - 2021-12-08 10:07:17 --> Utf8 Class Initialized
INFO - 2021-12-08 10:07:17 --> URI Class Initialized
INFO - 2021-12-08 10:07:17 --> Router Class Initialized
INFO - 2021-12-08 10:07:17 --> Output Class Initialized
INFO - 2021-12-08 10:07:17 --> Security Class Initialized
DEBUG - 2021-12-08 10:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 10:07:17 --> Input Class Initialized
INFO - 2021-12-08 10:07:17 --> Language Class Initialized
INFO - 2021-12-08 10:07:17 --> Language Class Initialized
INFO - 2021-12-08 10:07:17 --> Config Class Initialized
INFO - 2021-12-08 10:07:17 --> Loader Class Initialized
INFO - 2021-12-08 10:07:17 --> Helper loaded: url_helper
INFO - 2021-12-08 10:07:17 --> Helper loaded: file_helper
INFO - 2021-12-08 10:07:17 --> Helper loaded: form_helper
INFO - 2021-12-08 10:07:17 --> Helper loaded: my_helper
INFO - 2021-12-08 10:07:17 --> Database Driver Class Initialized
DEBUG - 2021-12-08 10:07:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 10:07:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 10:07:17 --> Controller Class Initialized
DEBUG - 2021-12-08 10:07:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-12-08 10:07:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 10:07:17 --> Final output sent to browser
DEBUG - 2021-12-08 10:07:17 --> Total execution time: 0.0570
INFO - 2021-12-08 10:07:30 --> Config Class Initialized
INFO - 2021-12-08 10:07:30 --> Hooks Class Initialized
DEBUG - 2021-12-08 10:07:30 --> UTF-8 Support Enabled
INFO - 2021-12-08 10:07:30 --> Utf8 Class Initialized
INFO - 2021-12-08 10:07:30 --> URI Class Initialized
INFO - 2021-12-08 10:07:30 --> Router Class Initialized
INFO - 2021-12-08 10:07:30 --> Output Class Initialized
INFO - 2021-12-08 10:07:30 --> Security Class Initialized
DEBUG - 2021-12-08 10:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 10:07:30 --> Input Class Initialized
INFO - 2021-12-08 10:07:30 --> Language Class Initialized
INFO - 2021-12-08 10:07:30 --> Language Class Initialized
INFO - 2021-12-08 10:07:30 --> Config Class Initialized
INFO - 2021-12-08 10:07:30 --> Loader Class Initialized
INFO - 2021-12-08 10:07:30 --> Helper loaded: url_helper
INFO - 2021-12-08 10:07:30 --> Helper loaded: file_helper
INFO - 2021-12-08 10:07:30 --> Helper loaded: form_helper
INFO - 2021-12-08 10:07:30 --> Helper loaded: my_helper
INFO - 2021-12-08 10:07:30 --> Database Driver Class Initialized
DEBUG - 2021-12-08 10:07:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 10:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 10:07:30 --> Controller Class Initialized
INFO - 2021-12-08 10:07:30 --> Final output sent to browser
DEBUG - 2021-12-08 10:07:30 --> Total execution time: 0.0580
INFO - 2021-12-08 10:07:37 --> Config Class Initialized
INFO - 2021-12-08 10:07:37 --> Hooks Class Initialized
DEBUG - 2021-12-08 10:07:37 --> UTF-8 Support Enabled
INFO - 2021-12-08 10:07:37 --> Utf8 Class Initialized
INFO - 2021-12-08 10:07:37 --> URI Class Initialized
INFO - 2021-12-08 10:07:37 --> Router Class Initialized
INFO - 2021-12-08 10:07:37 --> Output Class Initialized
INFO - 2021-12-08 10:07:37 --> Security Class Initialized
DEBUG - 2021-12-08 10:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 10:07:37 --> Input Class Initialized
INFO - 2021-12-08 10:07:37 --> Language Class Initialized
INFO - 2021-12-08 10:07:37 --> Language Class Initialized
INFO - 2021-12-08 10:07:37 --> Config Class Initialized
INFO - 2021-12-08 10:07:37 --> Loader Class Initialized
INFO - 2021-12-08 10:07:37 --> Helper loaded: url_helper
INFO - 2021-12-08 10:07:37 --> Helper loaded: file_helper
INFO - 2021-12-08 10:07:37 --> Helper loaded: form_helper
INFO - 2021-12-08 10:07:37 --> Helper loaded: my_helper
INFO - 2021-12-08 10:07:37 --> Database Driver Class Initialized
DEBUG - 2021-12-08 10:07:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 10:07:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 10:07:37 --> Controller Class Initialized
INFO - 2021-12-08 10:07:37 --> Helper loaded: cookie_helper
INFO - 2021-12-08 10:07:37 --> Config Class Initialized
INFO - 2021-12-08 10:07:37 --> Hooks Class Initialized
DEBUG - 2021-12-08 10:07:37 --> UTF-8 Support Enabled
INFO - 2021-12-08 10:07:37 --> Utf8 Class Initialized
INFO - 2021-12-08 10:07:37 --> URI Class Initialized
INFO - 2021-12-08 10:07:37 --> Router Class Initialized
INFO - 2021-12-08 10:07:37 --> Output Class Initialized
INFO - 2021-12-08 10:07:37 --> Security Class Initialized
DEBUG - 2021-12-08 10:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 10:07:37 --> Input Class Initialized
INFO - 2021-12-08 10:07:37 --> Language Class Initialized
INFO - 2021-12-08 10:07:37 --> Language Class Initialized
INFO - 2021-12-08 10:07:37 --> Config Class Initialized
INFO - 2021-12-08 10:07:37 --> Loader Class Initialized
INFO - 2021-12-08 10:07:37 --> Helper loaded: url_helper
INFO - 2021-12-08 10:07:37 --> Helper loaded: file_helper
INFO - 2021-12-08 10:07:37 --> Helper loaded: form_helper
INFO - 2021-12-08 10:07:37 --> Helper loaded: my_helper
INFO - 2021-12-08 10:07:37 --> Database Driver Class Initialized
DEBUG - 2021-12-08 10:07:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 10:07:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 10:07:37 --> Controller Class Initialized
DEBUG - 2021-12-08 10:07:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-08 10:07:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-08 10:07:37 --> Final output sent to browser
DEBUG - 2021-12-08 10:07:37 --> Total execution time: 0.0360
