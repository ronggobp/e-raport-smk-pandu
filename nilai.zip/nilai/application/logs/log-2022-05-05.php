<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-05-05 06:49:17 --> Config Class Initialized
INFO - 2022-05-05 06:49:17 --> Hooks Class Initialized
DEBUG - 2022-05-05 06:49:17 --> UTF-8 Support Enabled
INFO - 2022-05-05 06:49:17 --> Utf8 Class Initialized
INFO - 2022-05-05 06:49:17 --> URI Class Initialized
DEBUG - 2022-05-05 06:49:18 --> No URI present. Default controller set.
INFO - 2022-05-05 06:49:18 --> Router Class Initialized
INFO - 2022-05-05 06:49:18 --> Output Class Initialized
INFO - 2022-05-05 06:49:18 --> Security Class Initialized
DEBUG - 2022-05-05 06:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-05 06:49:18 --> Input Class Initialized
INFO - 2022-05-05 06:49:18 --> Language Class Initialized
INFO - 2022-05-05 06:49:18 --> Language Class Initialized
INFO - 2022-05-05 06:49:18 --> Config Class Initialized
INFO - 2022-05-05 06:49:18 --> Loader Class Initialized
INFO - 2022-05-05 06:49:18 --> Helper loaded: url_helper
INFO - 2022-05-05 06:49:18 --> Helper loaded: file_helper
INFO - 2022-05-05 06:49:18 --> Helper loaded: form_helper
INFO - 2022-05-05 06:49:18 --> Helper loaded: my_helper
INFO - 2022-05-05 06:49:18 --> Database Driver Class Initialized
DEBUG - 2022-05-05 06:49:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-05 06:49:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-05 06:49:19 --> Controller Class Initialized
INFO - 2022-05-05 06:49:19 --> Config Class Initialized
INFO - 2022-05-05 06:49:19 --> Hooks Class Initialized
DEBUG - 2022-05-05 06:49:19 --> UTF-8 Support Enabled
INFO - 2022-05-05 06:49:19 --> Utf8 Class Initialized
INFO - 2022-05-05 06:49:19 --> URI Class Initialized
INFO - 2022-05-05 06:49:19 --> Router Class Initialized
INFO - 2022-05-05 06:49:19 --> Output Class Initialized
INFO - 2022-05-05 06:49:19 --> Security Class Initialized
DEBUG - 2022-05-05 06:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-05 06:49:19 --> Input Class Initialized
INFO - 2022-05-05 06:49:19 --> Language Class Initialized
INFO - 2022-05-05 06:49:19 --> Language Class Initialized
INFO - 2022-05-05 06:49:19 --> Config Class Initialized
INFO - 2022-05-05 06:49:19 --> Loader Class Initialized
INFO - 2022-05-05 06:49:19 --> Helper loaded: url_helper
INFO - 2022-05-05 06:49:19 --> Helper loaded: file_helper
INFO - 2022-05-05 06:49:19 --> Helper loaded: form_helper
INFO - 2022-05-05 06:49:19 --> Helper loaded: my_helper
INFO - 2022-05-05 06:49:19 --> Database Driver Class Initialized
DEBUG - 2022-05-05 06:49:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-05 06:49:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-05 06:49:19 --> Controller Class Initialized
DEBUG - 2022-05-05 06:49:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-05-05 06:49:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-05 06:49:19 --> Final output sent to browser
DEBUG - 2022-05-05 06:49:19 --> Total execution time: 0.1942
INFO - 2022-05-05 06:49:24 --> Config Class Initialized
INFO - 2022-05-05 06:49:24 --> Hooks Class Initialized
DEBUG - 2022-05-05 06:49:24 --> UTF-8 Support Enabled
INFO - 2022-05-05 06:49:24 --> Utf8 Class Initialized
INFO - 2022-05-05 06:49:24 --> URI Class Initialized
INFO - 2022-05-05 06:49:24 --> Router Class Initialized
INFO - 2022-05-05 06:49:24 --> Output Class Initialized
INFO - 2022-05-05 06:49:24 --> Security Class Initialized
DEBUG - 2022-05-05 06:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-05 06:49:24 --> Input Class Initialized
INFO - 2022-05-05 06:49:24 --> Language Class Initialized
INFO - 2022-05-05 06:49:24 --> Language Class Initialized
INFO - 2022-05-05 06:49:24 --> Config Class Initialized
INFO - 2022-05-05 06:49:24 --> Loader Class Initialized
INFO - 2022-05-05 06:49:24 --> Helper loaded: url_helper
INFO - 2022-05-05 06:49:24 --> Helper loaded: file_helper
INFO - 2022-05-05 06:49:24 --> Helper loaded: form_helper
INFO - 2022-05-05 06:49:24 --> Helper loaded: my_helper
INFO - 2022-05-05 06:49:24 --> Database Driver Class Initialized
DEBUG - 2022-05-05 06:49:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-05 06:49:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-05 06:49:24 --> Controller Class Initialized
INFO - 2022-05-05 06:49:24 --> Helper loaded: cookie_helper
INFO - 2022-05-05 06:49:24 --> Final output sent to browser
DEBUG - 2022-05-05 06:49:24 --> Total execution time: 0.1237
INFO - 2022-05-05 06:49:24 --> Config Class Initialized
INFO - 2022-05-05 06:49:24 --> Hooks Class Initialized
DEBUG - 2022-05-05 06:49:24 --> UTF-8 Support Enabled
INFO - 2022-05-05 06:49:24 --> Utf8 Class Initialized
INFO - 2022-05-05 06:49:24 --> URI Class Initialized
INFO - 2022-05-05 06:49:24 --> Router Class Initialized
INFO - 2022-05-05 06:49:24 --> Output Class Initialized
INFO - 2022-05-05 06:49:24 --> Security Class Initialized
DEBUG - 2022-05-05 06:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-05 06:49:24 --> Input Class Initialized
INFO - 2022-05-05 06:49:24 --> Language Class Initialized
INFO - 2022-05-05 06:49:24 --> Language Class Initialized
INFO - 2022-05-05 06:49:24 --> Config Class Initialized
INFO - 2022-05-05 06:49:24 --> Loader Class Initialized
INFO - 2022-05-05 06:49:24 --> Helper loaded: url_helper
INFO - 2022-05-05 06:49:24 --> Helper loaded: file_helper
INFO - 2022-05-05 06:49:24 --> Helper loaded: form_helper
INFO - 2022-05-05 06:49:24 --> Helper loaded: my_helper
INFO - 2022-05-05 06:49:24 --> Database Driver Class Initialized
DEBUG - 2022-05-05 06:49:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-05 06:49:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-05 06:49:24 --> Controller Class Initialized
DEBUG - 2022-05-05 06:49:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-05-05 06:49:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-05 06:49:24 --> Final output sent to browser
DEBUG - 2022-05-05 06:49:24 --> Total execution time: 0.2416
INFO - 2022-05-05 06:49:25 --> Config Class Initialized
INFO - 2022-05-05 06:49:25 --> Hooks Class Initialized
DEBUG - 2022-05-05 06:49:25 --> UTF-8 Support Enabled
INFO - 2022-05-05 06:49:25 --> Utf8 Class Initialized
INFO - 2022-05-05 06:49:25 --> URI Class Initialized
INFO - 2022-05-05 06:49:25 --> Router Class Initialized
INFO - 2022-05-05 06:49:25 --> Output Class Initialized
INFO - 2022-05-05 06:49:25 --> Security Class Initialized
DEBUG - 2022-05-05 06:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-05 06:49:25 --> Input Class Initialized
INFO - 2022-05-05 06:49:25 --> Language Class Initialized
INFO - 2022-05-05 06:49:25 --> Language Class Initialized
INFO - 2022-05-05 06:49:25 --> Config Class Initialized
INFO - 2022-05-05 06:49:25 --> Loader Class Initialized
INFO - 2022-05-05 06:49:25 --> Helper loaded: url_helper
INFO - 2022-05-05 06:49:25 --> Helper loaded: file_helper
INFO - 2022-05-05 06:49:25 --> Helper loaded: form_helper
INFO - 2022-05-05 06:49:25 --> Helper loaded: my_helper
INFO - 2022-05-05 06:49:25 --> Database Driver Class Initialized
DEBUG - 2022-05-05 06:49:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-05 06:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-05 06:49:25 --> Controller Class Initialized
DEBUG - 2022-05-05 06:49:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-05-05 06:49:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-05 06:49:26 --> Final output sent to browser
DEBUG - 2022-05-05 06:49:26 --> Total execution time: 0.1966
INFO - 2022-05-05 06:49:26 --> Config Class Initialized
INFO - 2022-05-05 06:49:26 --> Hooks Class Initialized
DEBUG - 2022-05-05 06:49:26 --> UTF-8 Support Enabled
INFO - 2022-05-05 06:49:26 --> Utf8 Class Initialized
INFO - 2022-05-05 06:49:26 --> URI Class Initialized
INFO - 2022-05-05 06:49:26 --> Router Class Initialized
INFO - 2022-05-05 06:49:26 --> Output Class Initialized
INFO - 2022-05-05 06:49:26 --> Security Class Initialized
DEBUG - 2022-05-05 06:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-05 06:49:26 --> Input Class Initialized
INFO - 2022-05-05 06:49:26 --> Language Class Initialized
INFO - 2022-05-05 06:49:26 --> Language Class Initialized
INFO - 2022-05-05 06:49:26 --> Config Class Initialized
INFO - 2022-05-05 06:49:26 --> Loader Class Initialized
INFO - 2022-05-05 06:49:26 --> Helper loaded: url_helper
INFO - 2022-05-05 06:49:26 --> Helper loaded: file_helper
INFO - 2022-05-05 06:49:26 --> Helper loaded: form_helper
INFO - 2022-05-05 06:49:26 --> Helper loaded: my_helper
INFO - 2022-05-05 06:49:26 --> Database Driver Class Initialized
DEBUG - 2022-05-05 06:49:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-05 06:49:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-05 06:49:26 --> Controller Class Initialized
DEBUG - 2022-05-05 06:49:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2022-05-05 06:49:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-05 06:49:26 --> Final output sent to browser
DEBUG - 2022-05-05 06:49:26 --> Total execution time: 0.2274
INFO - 2022-05-05 06:49:33 --> Config Class Initialized
INFO - 2022-05-05 06:49:33 --> Hooks Class Initialized
DEBUG - 2022-05-05 06:49:33 --> UTF-8 Support Enabled
INFO - 2022-05-05 06:49:33 --> Utf8 Class Initialized
INFO - 2022-05-05 06:49:33 --> URI Class Initialized
INFO - 2022-05-05 06:49:33 --> Router Class Initialized
INFO - 2022-05-05 06:49:33 --> Output Class Initialized
INFO - 2022-05-05 06:49:33 --> Security Class Initialized
DEBUG - 2022-05-05 06:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-05 06:49:33 --> Input Class Initialized
INFO - 2022-05-05 06:49:33 --> Language Class Initialized
INFO - 2022-05-05 06:49:33 --> Language Class Initialized
INFO - 2022-05-05 06:49:33 --> Config Class Initialized
INFO - 2022-05-05 06:49:33 --> Loader Class Initialized
INFO - 2022-05-05 06:49:33 --> Helper loaded: url_helper
INFO - 2022-05-05 06:49:33 --> Helper loaded: file_helper
INFO - 2022-05-05 06:49:33 --> Helper loaded: form_helper
INFO - 2022-05-05 06:49:33 --> Helper loaded: my_helper
INFO - 2022-05-05 06:49:33 --> Database Driver Class Initialized
DEBUG - 2022-05-05 06:49:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-05 06:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-05 06:49:33 --> Controller Class Initialized
INFO - 2022-05-05 06:49:33 --> Helper loaded: cookie_helper
INFO - 2022-05-05 06:49:33 --> Config Class Initialized
INFO - 2022-05-05 06:49:33 --> Hooks Class Initialized
DEBUG - 2022-05-05 06:49:33 --> UTF-8 Support Enabled
INFO - 2022-05-05 06:49:33 --> Utf8 Class Initialized
INFO - 2022-05-05 06:49:33 --> URI Class Initialized
INFO - 2022-05-05 06:49:33 --> Router Class Initialized
INFO - 2022-05-05 06:49:33 --> Output Class Initialized
INFO - 2022-05-05 06:49:33 --> Security Class Initialized
DEBUG - 2022-05-05 06:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-05 06:49:33 --> Input Class Initialized
INFO - 2022-05-05 06:49:33 --> Language Class Initialized
INFO - 2022-05-05 06:49:33 --> Language Class Initialized
INFO - 2022-05-05 06:49:33 --> Config Class Initialized
INFO - 2022-05-05 06:49:33 --> Loader Class Initialized
INFO - 2022-05-05 06:49:33 --> Helper loaded: url_helper
INFO - 2022-05-05 06:49:33 --> Helper loaded: file_helper
INFO - 2022-05-05 06:49:33 --> Helper loaded: form_helper
INFO - 2022-05-05 06:49:33 --> Helper loaded: my_helper
INFO - 2022-05-05 06:49:33 --> Database Driver Class Initialized
DEBUG - 2022-05-05 06:49:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-05 06:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-05 06:49:33 --> Controller Class Initialized
DEBUG - 2022-05-05 06:49:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-05-05 06:49:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-05 06:49:33 --> Final output sent to browser
DEBUG - 2022-05-05 06:49:33 --> Total execution time: 0.0858
INFO - 2022-05-05 06:53:53 --> Config Class Initialized
INFO - 2022-05-05 06:53:53 --> Hooks Class Initialized
DEBUG - 2022-05-05 06:53:53 --> UTF-8 Support Enabled
INFO - 2022-05-05 06:53:53 --> Utf8 Class Initialized
INFO - 2022-05-05 06:53:53 --> URI Class Initialized
INFO - 2022-05-05 06:53:53 --> Router Class Initialized
INFO - 2022-05-05 06:53:53 --> Output Class Initialized
INFO - 2022-05-05 06:53:53 --> Security Class Initialized
DEBUG - 2022-05-05 06:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-05 06:53:53 --> Input Class Initialized
INFO - 2022-05-05 06:53:53 --> Language Class Initialized
INFO - 2022-05-05 06:53:53 --> Language Class Initialized
INFO - 2022-05-05 06:53:53 --> Config Class Initialized
INFO - 2022-05-05 06:53:53 --> Loader Class Initialized
INFO - 2022-05-05 06:53:53 --> Helper loaded: url_helper
INFO - 2022-05-05 06:53:53 --> Helper loaded: file_helper
INFO - 2022-05-05 06:53:53 --> Helper loaded: form_helper
INFO - 2022-05-05 06:53:53 --> Helper loaded: my_helper
INFO - 2022-05-05 06:53:53 --> Database Driver Class Initialized
DEBUG - 2022-05-05 06:53:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-05 06:53:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-05 06:53:53 --> Controller Class Initialized
DEBUG - 2022-05-05 06:53:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-05-05 06:53:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-05 06:53:53 --> Final output sent to browser
DEBUG - 2022-05-05 06:53:53 --> Total execution time: 0.1144
INFO - 2022-05-05 06:53:58 --> Config Class Initialized
INFO - 2022-05-05 06:53:58 --> Hooks Class Initialized
DEBUG - 2022-05-05 06:53:58 --> UTF-8 Support Enabled
INFO - 2022-05-05 06:53:58 --> Utf8 Class Initialized
INFO - 2022-05-05 06:53:58 --> URI Class Initialized
INFO - 2022-05-05 06:53:58 --> Router Class Initialized
INFO - 2022-05-05 06:53:58 --> Output Class Initialized
INFO - 2022-05-05 06:53:58 --> Security Class Initialized
DEBUG - 2022-05-05 06:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-05 06:53:58 --> Input Class Initialized
INFO - 2022-05-05 06:53:58 --> Language Class Initialized
INFO - 2022-05-05 06:53:58 --> Language Class Initialized
INFO - 2022-05-05 06:53:58 --> Config Class Initialized
INFO - 2022-05-05 06:53:58 --> Loader Class Initialized
INFO - 2022-05-05 06:53:58 --> Helper loaded: url_helper
INFO - 2022-05-05 06:53:58 --> Helper loaded: file_helper
INFO - 2022-05-05 06:53:58 --> Helper loaded: form_helper
INFO - 2022-05-05 06:53:58 --> Helper loaded: my_helper
INFO - 2022-05-05 06:53:58 --> Database Driver Class Initialized
DEBUG - 2022-05-05 06:53:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-05 06:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-05 06:53:58 --> Controller Class Initialized
INFO - 2022-05-05 06:53:58 --> Helper loaded: cookie_helper
INFO - 2022-05-05 06:53:58 --> Final output sent to browser
DEBUG - 2022-05-05 06:53:58 --> Total execution time: 0.1094
INFO - 2022-05-05 06:53:58 --> Config Class Initialized
INFO - 2022-05-05 06:53:58 --> Hooks Class Initialized
DEBUG - 2022-05-05 06:53:58 --> UTF-8 Support Enabled
INFO - 2022-05-05 06:53:58 --> Utf8 Class Initialized
INFO - 2022-05-05 06:53:58 --> URI Class Initialized
INFO - 2022-05-05 06:53:58 --> Router Class Initialized
INFO - 2022-05-05 06:53:58 --> Output Class Initialized
INFO - 2022-05-05 06:53:58 --> Security Class Initialized
DEBUG - 2022-05-05 06:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-05 06:53:58 --> Input Class Initialized
INFO - 2022-05-05 06:53:58 --> Language Class Initialized
INFO - 2022-05-05 06:53:58 --> Language Class Initialized
INFO - 2022-05-05 06:53:58 --> Config Class Initialized
INFO - 2022-05-05 06:53:58 --> Loader Class Initialized
INFO - 2022-05-05 06:53:58 --> Helper loaded: url_helper
INFO - 2022-05-05 06:53:58 --> Helper loaded: file_helper
INFO - 2022-05-05 06:53:58 --> Helper loaded: form_helper
INFO - 2022-05-05 06:53:58 --> Helper loaded: my_helper
INFO - 2022-05-05 06:53:58 --> Database Driver Class Initialized
DEBUG - 2022-05-05 06:53:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-05 06:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-05 06:53:58 --> Controller Class Initialized
DEBUG - 2022-05-05 06:53:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-05-05 06:53:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-05 06:53:58 --> Final output sent to browser
DEBUG - 2022-05-05 06:53:58 --> Total execution time: 0.1263
INFO - 2022-05-05 06:54:00 --> Config Class Initialized
INFO - 2022-05-05 06:54:00 --> Hooks Class Initialized
DEBUG - 2022-05-05 06:54:00 --> UTF-8 Support Enabled
INFO - 2022-05-05 06:54:00 --> Utf8 Class Initialized
INFO - 2022-05-05 06:54:00 --> URI Class Initialized
INFO - 2022-05-05 06:54:00 --> Router Class Initialized
INFO - 2022-05-05 06:54:00 --> Output Class Initialized
INFO - 2022-05-05 06:54:00 --> Security Class Initialized
DEBUG - 2022-05-05 06:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-05 06:54:00 --> Input Class Initialized
INFO - 2022-05-05 06:54:00 --> Language Class Initialized
INFO - 2022-05-05 06:54:00 --> Language Class Initialized
INFO - 2022-05-05 06:54:00 --> Config Class Initialized
INFO - 2022-05-05 06:54:00 --> Loader Class Initialized
INFO - 2022-05-05 06:54:00 --> Helper loaded: url_helper
INFO - 2022-05-05 06:54:00 --> Helper loaded: file_helper
INFO - 2022-05-05 06:54:00 --> Helper loaded: form_helper
INFO - 2022-05-05 06:54:00 --> Helper loaded: my_helper
INFO - 2022-05-05 06:54:00 --> Database Driver Class Initialized
DEBUG - 2022-05-05 06:54:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-05 06:54:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-05 06:54:00 --> Controller Class Initialized
DEBUG - 2022-05-05 06:54:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2022-05-05 06:54:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-05 06:54:00 --> Final output sent to browser
DEBUG - 2022-05-05 06:54:00 --> Total execution time: 0.2040
INFO - 2022-05-05 06:54:00 --> Config Class Initialized
INFO - 2022-05-05 06:54:00 --> Hooks Class Initialized
DEBUG - 2022-05-05 06:54:00 --> UTF-8 Support Enabled
INFO - 2022-05-05 06:54:00 --> Utf8 Class Initialized
INFO - 2022-05-05 06:54:00 --> URI Class Initialized
INFO - 2022-05-05 06:54:00 --> Router Class Initialized
INFO - 2022-05-05 06:54:00 --> Output Class Initialized
INFO - 2022-05-05 06:54:00 --> Security Class Initialized
DEBUG - 2022-05-05 06:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-05 06:54:00 --> Input Class Initialized
INFO - 2022-05-05 06:54:00 --> Language Class Initialized
INFO - 2022-05-05 06:54:00 --> Language Class Initialized
INFO - 2022-05-05 06:54:00 --> Config Class Initialized
INFO - 2022-05-05 06:54:00 --> Loader Class Initialized
INFO - 2022-05-05 06:54:00 --> Helper loaded: url_helper
INFO - 2022-05-05 06:54:00 --> Helper loaded: file_helper
INFO - 2022-05-05 06:54:00 --> Helper loaded: form_helper
INFO - 2022-05-05 06:54:00 --> Helper loaded: my_helper
INFO - 2022-05-05 06:54:00 --> Database Driver Class Initialized
DEBUG - 2022-05-05 06:54:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-05 06:54:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-05 06:54:01 --> Controller Class Initialized
INFO - 2022-05-05 06:54:02 --> Config Class Initialized
INFO - 2022-05-05 06:54:02 --> Hooks Class Initialized
DEBUG - 2022-05-05 06:54:02 --> UTF-8 Support Enabled
INFO - 2022-05-05 06:54:02 --> Utf8 Class Initialized
INFO - 2022-05-05 06:54:02 --> URI Class Initialized
INFO - 2022-05-05 06:54:02 --> Router Class Initialized
INFO - 2022-05-05 06:54:02 --> Output Class Initialized
INFO - 2022-05-05 06:54:02 --> Security Class Initialized
DEBUG - 2022-05-05 06:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-05 06:54:02 --> Input Class Initialized
INFO - 2022-05-05 06:54:02 --> Language Class Initialized
INFO - 2022-05-05 06:54:02 --> Language Class Initialized
INFO - 2022-05-05 06:54:02 --> Config Class Initialized
INFO - 2022-05-05 06:54:02 --> Loader Class Initialized
INFO - 2022-05-05 06:54:02 --> Helper loaded: url_helper
INFO - 2022-05-05 06:54:02 --> Helper loaded: file_helper
INFO - 2022-05-05 06:54:02 --> Helper loaded: form_helper
INFO - 2022-05-05 06:54:02 --> Helper loaded: my_helper
INFO - 2022-05-05 06:54:02 --> Database Driver Class Initialized
DEBUG - 2022-05-05 06:54:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-05 06:54:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-05 06:54:02 --> Controller Class Initialized
DEBUG - 2022-05-05 06:54:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2022-05-05 06:54:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-05 06:54:02 --> Final output sent to browser
DEBUG - 2022-05-05 06:54:02 --> Total execution time: 0.1481
INFO - 2022-05-05 06:54:03 --> Config Class Initialized
INFO - 2022-05-05 06:54:03 --> Hooks Class Initialized
DEBUG - 2022-05-05 06:54:03 --> UTF-8 Support Enabled
INFO - 2022-05-05 06:54:03 --> Utf8 Class Initialized
INFO - 2022-05-05 06:54:03 --> URI Class Initialized
INFO - 2022-05-05 06:54:03 --> Router Class Initialized
INFO - 2022-05-05 06:54:03 --> Output Class Initialized
INFO - 2022-05-05 06:54:03 --> Security Class Initialized
DEBUG - 2022-05-05 06:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-05 06:54:03 --> Input Class Initialized
INFO - 2022-05-05 06:54:03 --> Language Class Initialized
INFO - 2022-05-05 06:54:03 --> Language Class Initialized
INFO - 2022-05-05 06:54:03 --> Config Class Initialized
INFO - 2022-05-05 06:54:03 --> Loader Class Initialized
INFO - 2022-05-05 06:54:03 --> Helper loaded: url_helper
INFO - 2022-05-05 06:54:03 --> Helper loaded: file_helper
INFO - 2022-05-05 06:54:03 --> Helper loaded: form_helper
INFO - 2022-05-05 06:54:03 --> Helper loaded: my_helper
INFO - 2022-05-05 06:54:03 --> Database Driver Class Initialized
DEBUG - 2022-05-05 06:54:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-05 06:54:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-05 06:54:03 --> Controller Class Initialized
INFO - 2022-05-05 06:54:10 --> Config Class Initialized
INFO - 2022-05-05 06:54:10 --> Hooks Class Initialized
DEBUG - 2022-05-05 06:54:10 --> UTF-8 Support Enabled
INFO - 2022-05-05 06:54:10 --> Utf8 Class Initialized
INFO - 2022-05-05 06:54:10 --> URI Class Initialized
INFO - 2022-05-05 06:54:10 --> Router Class Initialized
INFO - 2022-05-05 06:54:10 --> Output Class Initialized
INFO - 2022-05-05 06:54:10 --> Security Class Initialized
DEBUG - 2022-05-05 06:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-05 06:54:10 --> Input Class Initialized
INFO - 2022-05-05 06:54:10 --> Language Class Initialized
INFO - 2022-05-05 06:54:10 --> Language Class Initialized
INFO - 2022-05-05 06:54:10 --> Config Class Initialized
INFO - 2022-05-05 06:54:10 --> Loader Class Initialized
INFO - 2022-05-05 06:54:10 --> Helper loaded: url_helper
INFO - 2022-05-05 06:54:10 --> Helper loaded: file_helper
INFO - 2022-05-05 06:54:10 --> Helper loaded: form_helper
INFO - 2022-05-05 06:54:10 --> Helper loaded: my_helper
INFO - 2022-05-05 06:54:10 --> Database Driver Class Initialized
DEBUG - 2022-05-05 06:54:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-05 06:54:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-05 06:54:10 --> Controller Class Initialized
INFO - 2022-05-05 06:54:12 --> Config Class Initialized
INFO - 2022-05-05 06:54:12 --> Hooks Class Initialized
DEBUG - 2022-05-05 06:54:12 --> UTF-8 Support Enabled
INFO - 2022-05-05 06:54:12 --> Utf8 Class Initialized
INFO - 2022-05-05 06:54:12 --> URI Class Initialized
INFO - 2022-05-05 06:54:12 --> Router Class Initialized
INFO - 2022-05-05 06:54:12 --> Output Class Initialized
INFO - 2022-05-05 06:54:12 --> Security Class Initialized
DEBUG - 2022-05-05 06:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-05 06:54:12 --> Input Class Initialized
INFO - 2022-05-05 06:54:12 --> Language Class Initialized
INFO - 2022-05-05 06:54:12 --> Language Class Initialized
INFO - 2022-05-05 06:54:12 --> Config Class Initialized
INFO - 2022-05-05 06:54:12 --> Loader Class Initialized
INFO - 2022-05-05 06:54:12 --> Helper loaded: url_helper
INFO - 2022-05-05 06:54:12 --> Helper loaded: file_helper
INFO - 2022-05-05 06:54:12 --> Helper loaded: form_helper
INFO - 2022-05-05 06:54:12 --> Helper loaded: my_helper
INFO - 2022-05-05 06:54:12 --> Database Driver Class Initialized
DEBUG - 2022-05-05 06:54:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-05 06:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-05 06:54:12 --> Controller Class Initialized
INFO - 2022-05-05 06:54:21 --> Config Class Initialized
INFO - 2022-05-05 06:54:21 --> Hooks Class Initialized
DEBUG - 2022-05-05 06:54:21 --> UTF-8 Support Enabled
INFO - 2022-05-05 06:54:21 --> Utf8 Class Initialized
INFO - 2022-05-05 06:54:21 --> URI Class Initialized
INFO - 2022-05-05 06:54:21 --> Router Class Initialized
INFO - 2022-05-05 06:54:21 --> Output Class Initialized
INFO - 2022-05-05 06:54:21 --> Security Class Initialized
DEBUG - 2022-05-05 06:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-05 06:54:21 --> Input Class Initialized
INFO - 2022-05-05 06:54:21 --> Language Class Initialized
INFO - 2022-05-05 06:54:21 --> Language Class Initialized
INFO - 2022-05-05 06:54:21 --> Config Class Initialized
INFO - 2022-05-05 06:54:21 --> Loader Class Initialized
INFO - 2022-05-05 06:54:21 --> Helper loaded: url_helper
INFO - 2022-05-05 06:54:21 --> Helper loaded: file_helper
INFO - 2022-05-05 06:54:21 --> Helper loaded: form_helper
INFO - 2022-05-05 06:54:21 --> Helper loaded: my_helper
INFO - 2022-05-05 06:54:21 --> Database Driver Class Initialized
DEBUG - 2022-05-05 06:54:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-05 06:54:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-05 06:54:21 --> Controller Class Initialized
INFO - 2022-05-05 07:13:24 --> Config Class Initialized
INFO - 2022-05-05 07:13:24 --> Hooks Class Initialized
DEBUG - 2022-05-05 07:13:24 --> UTF-8 Support Enabled
INFO - 2022-05-05 07:13:24 --> Utf8 Class Initialized
INFO - 2022-05-05 07:13:24 --> URI Class Initialized
INFO - 2022-05-05 07:13:24 --> Router Class Initialized
INFO - 2022-05-05 07:13:24 --> Output Class Initialized
INFO - 2022-05-05 07:13:24 --> Security Class Initialized
DEBUG - 2022-05-05 07:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-05 07:13:24 --> Input Class Initialized
INFO - 2022-05-05 07:13:24 --> Language Class Initialized
INFO - 2022-05-05 07:13:24 --> Language Class Initialized
INFO - 2022-05-05 07:13:24 --> Config Class Initialized
INFO - 2022-05-05 07:13:24 --> Loader Class Initialized
INFO - 2022-05-05 07:13:24 --> Helper loaded: url_helper
INFO - 2022-05-05 07:13:24 --> Helper loaded: file_helper
INFO - 2022-05-05 07:13:24 --> Helper loaded: form_helper
INFO - 2022-05-05 07:13:24 --> Helper loaded: my_helper
INFO - 2022-05-05 07:13:24 --> Database Driver Class Initialized
DEBUG - 2022-05-05 07:13:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-05 07:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-05 07:13:24 --> Controller Class Initialized
INFO - 2022-05-05 07:13:24 --> Helper loaded: cookie_helper
INFO - 2022-05-05 07:13:24 --> Config Class Initialized
INFO - 2022-05-05 07:13:24 --> Hooks Class Initialized
DEBUG - 2022-05-05 07:13:24 --> UTF-8 Support Enabled
INFO - 2022-05-05 07:13:24 --> Utf8 Class Initialized
INFO - 2022-05-05 07:13:24 --> URI Class Initialized
INFO - 2022-05-05 07:13:24 --> Router Class Initialized
INFO - 2022-05-05 07:13:24 --> Output Class Initialized
INFO - 2022-05-05 07:13:24 --> Security Class Initialized
DEBUG - 2022-05-05 07:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-05 07:13:24 --> Input Class Initialized
INFO - 2022-05-05 07:13:24 --> Language Class Initialized
INFO - 2022-05-05 07:13:24 --> Language Class Initialized
INFO - 2022-05-05 07:13:24 --> Config Class Initialized
INFO - 2022-05-05 07:13:24 --> Loader Class Initialized
INFO - 2022-05-05 07:13:24 --> Helper loaded: url_helper
INFO - 2022-05-05 07:13:24 --> Helper loaded: file_helper
INFO - 2022-05-05 07:13:24 --> Helper loaded: form_helper
INFO - 2022-05-05 07:13:24 --> Helper loaded: my_helper
INFO - 2022-05-05 07:13:24 --> Database Driver Class Initialized
DEBUG - 2022-05-05 07:13:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-05 07:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-05 07:13:24 --> Controller Class Initialized
DEBUG - 2022-05-05 07:13:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-05-05 07:13:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-05 07:13:24 --> Final output sent to browser
DEBUG - 2022-05-05 07:13:24 --> Total execution time: 0.0709
