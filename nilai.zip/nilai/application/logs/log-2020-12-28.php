<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-12-28 01:15:09 --> Config Class Initialized
INFO - 2020-12-28 01:15:09 --> Hooks Class Initialized
DEBUG - 2020-12-28 01:15:10 --> UTF-8 Support Enabled
INFO - 2020-12-28 01:15:10 --> Utf8 Class Initialized
INFO - 2020-12-28 01:15:10 --> URI Class Initialized
DEBUG - 2020-12-28 01:15:10 --> No URI present. Default controller set.
INFO - 2020-12-28 01:15:10 --> Router Class Initialized
INFO - 2020-12-28 01:15:10 --> Output Class Initialized
INFO - 2020-12-28 01:15:10 --> Security Class Initialized
DEBUG - 2020-12-28 01:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 01:15:10 --> Input Class Initialized
INFO - 2020-12-28 01:15:10 --> Language Class Initialized
INFO - 2020-12-28 01:15:11 --> Language Class Initialized
INFO - 2020-12-28 01:15:11 --> Config Class Initialized
INFO - 2020-12-28 01:15:11 --> Loader Class Initialized
INFO - 2020-12-28 01:15:11 --> Helper loaded: url_helper
INFO - 2020-12-28 01:15:11 --> Helper loaded: file_helper
INFO - 2020-12-28 01:15:11 --> Helper loaded: form_helper
INFO - 2020-12-28 01:15:11 --> Helper loaded: my_helper
INFO - 2020-12-28 01:15:11 --> Database Driver Class Initialized
DEBUG - 2020-12-28 01:15:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 01:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 01:15:11 --> Controller Class Initialized
INFO - 2020-12-28 01:15:11 --> Config Class Initialized
INFO - 2020-12-28 01:15:11 --> Hooks Class Initialized
DEBUG - 2020-12-28 01:15:12 --> UTF-8 Support Enabled
INFO - 2020-12-28 01:15:12 --> Utf8 Class Initialized
INFO - 2020-12-28 01:15:12 --> URI Class Initialized
INFO - 2020-12-28 01:15:12 --> Router Class Initialized
INFO - 2020-12-28 01:15:12 --> Output Class Initialized
INFO - 2020-12-28 01:15:12 --> Security Class Initialized
DEBUG - 2020-12-28 01:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 01:15:12 --> Input Class Initialized
INFO - 2020-12-28 01:15:12 --> Language Class Initialized
INFO - 2020-12-28 01:15:12 --> Language Class Initialized
INFO - 2020-12-28 01:15:12 --> Config Class Initialized
INFO - 2020-12-28 01:15:12 --> Loader Class Initialized
INFO - 2020-12-28 01:15:12 --> Helper loaded: url_helper
INFO - 2020-12-28 01:15:12 --> Helper loaded: file_helper
INFO - 2020-12-28 01:15:12 --> Helper loaded: form_helper
INFO - 2020-12-28 01:15:12 --> Helper loaded: my_helper
INFO - 2020-12-28 01:15:12 --> Database Driver Class Initialized
DEBUG - 2020-12-28 01:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 01:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 01:15:12 --> Controller Class Initialized
DEBUG - 2020-12-28 01:15:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-28 01:15:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-28 01:15:13 --> Final output sent to browser
DEBUG - 2020-12-28 01:15:13 --> Total execution time: 1.0339
INFO - 2020-12-28 01:59:11 --> Config Class Initialized
INFO - 2020-12-28 01:59:11 --> Hooks Class Initialized
DEBUG - 2020-12-28 01:59:11 --> UTF-8 Support Enabled
INFO - 2020-12-28 01:59:11 --> Utf8 Class Initialized
INFO - 2020-12-28 01:59:11 --> URI Class Initialized
INFO - 2020-12-28 01:59:11 --> Router Class Initialized
INFO - 2020-12-28 01:59:11 --> Output Class Initialized
INFO - 2020-12-28 01:59:11 --> Security Class Initialized
DEBUG - 2020-12-28 01:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 01:59:11 --> Input Class Initialized
INFO - 2020-12-28 01:59:12 --> Language Class Initialized
INFO - 2020-12-28 01:59:12 --> Language Class Initialized
INFO - 2020-12-28 01:59:12 --> Config Class Initialized
INFO - 2020-12-28 01:59:12 --> Loader Class Initialized
INFO - 2020-12-28 01:59:12 --> Helper loaded: url_helper
INFO - 2020-12-28 01:59:12 --> Helper loaded: file_helper
INFO - 2020-12-28 01:59:12 --> Helper loaded: form_helper
INFO - 2020-12-28 01:59:12 --> Helper loaded: my_helper
INFO - 2020-12-28 01:59:12 --> Database Driver Class Initialized
DEBUG - 2020-12-28 01:59:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 01:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 01:59:12 --> Controller Class Initialized
INFO - 2020-12-28 01:59:12 --> Helper loaded: cookie_helper
INFO - 2020-12-28 01:59:12 --> Final output sent to browser
DEBUG - 2020-12-28 01:59:12 --> Total execution time: 0.7600
INFO - 2020-12-28 01:59:14 --> Config Class Initialized
INFO - 2020-12-28 01:59:14 --> Hooks Class Initialized
DEBUG - 2020-12-28 01:59:14 --> UTF-8 Support Enabled
INFO - 2020-12-28 01:59:14 --> Utf8 Class Initialized
INFO - 2020-12-28 01:59:14 --> URI Class Initialized
INFO - 2020-12-28 01:59:14 --> Router Class Initialized
INFO - 2020-12-28 01:59:14 --> Output Class Initialized
INFO - 2020-12-28 01:59:14 --> Security Class Initialized
DEBUG - 2020-12-28 01:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 01:59:14 --> Input Class Initialized
INFO - 2020-12-28 01:59:14 --> Language Class Initialized
INFO - 2020-12-28 01:59:14 --> Language Class Initialized
INFO - 2020-12-28 01:59:14 --> Config Class Initialized
INFO - 2020-12-28 01:59:14 --> Loader Class Initialized
INFO - 2020-12-28 01:59:14 --> Helper loaded: url_helper
INFO - 2020-12-28 01:59:14 --> Helper loaded: file_helper
INFO - 2020-12-28 01:59:14 --> Helper loaded: form_helper
INFO - 2020-12-28 01:59:15 --> Helper loaded: my_helper
INFO - 2020-12-28 01:59:15 --> Database Driver Class Initialized
DEBUG - 2020-12-28 01:59:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 01:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 01:59:15 --> Controller Class Initialized
DEBUG - 2020-12-28 01:59:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-28 01:59:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-28 01:59:15 --> Final output sent to browser
DEBUG - 2020-12-28 01:59:15 --> Total execution time: 1.0368
INFO - 2020-12-28 01:59:17 --> Config Class Initialized
INFO - 2020-12-28 01:59:17 --> Hooks Class Initialized
DEBUG - 2020-12-28 01:59:17 --> UTF-8 Support Enabled
INFO - 2020-12-28 01:59:17 --> Utf8 Class Initialized
INFO - 2020-12-28 01:59:17 --> URI Class Initialized
INFO - 2020-12-28 01:59:18 --> Router Class Initialized
INFO - 2020-12-28 01:59:18 --> Output Class Initialized
INFO - 2020-12-28 01:59:18 --> Security Class Initialized
DEBUG - 2020-12-28 01:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 01:59:18 --> Input Class Initialized
INFO - 2020-12-28 01:59:18 --> Language Class Initialized
INFO - 2020-12-28 01:59:18 --> Language Class Initialized
INFO - 2020-12-28 01:59:18 --> Config Class Initialized
INFO - 2020-12-28 01:59:18 --> Loader Class Initialized
INFO - 2020-12-28 01:59:18 --> Helper loaded: url_helper
INFO - 2020-12-28 01:59:18 --> Helper loaded: file_helper
INFO - 2020-12-28 01:59:18 --> Helper loaded: form_helper
INFO - 2020-12-28 01:59:18 --> Helper loaded: my_helper
INFO - 2020-12-28 01:59:18 --> Database Driver Class Initialized
DEBUG - 2020-12-28 01:59:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 01:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 01:59:18 --> Controller Class Initialized
DEBUG - 2020-12-28 01:59:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-28 01:59:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-28 01:59:18 --> Final output sent to browser
DEBUG - 2020-12-28 01:59:18 --> Total execution time: 0.7382
INFO - 2020-12-28 02:15:20 --> Config Class Initialized
INFO - 2020-12-28 02:15:21 --> Hooks Class Initialized
DEBUG - 2020-12-28 02:15:21 --> UTF-8 Support Enabled
INFO - 2020-12-28 02:15:21 --> Utf8 Class Initialized
INFO - 2020-12-28 02:15:21 --> URI Class Initialized
INFO - 2020-12-28 02:15:21 --> Router Class Initialized
INFO - 2020-12-28 02:15:21 --> Output Class Initialized
INFO - 2020-12-28 02:15:21 --> Security Class Initialized
DEBUG - 2020-12-28 02:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 02:15:21 --> Input Class Initialized
INFO - 2020-12-28 02:15:21 --> Language Class Initialized
INFO - 2020-12-28 02:15:21 --> Language Class Initialized
INFO - 2020-12-28 02:15:21 --> Config Class Initialized
INFO - 2020-12-28 02:15:21 --> Loader Class Initialized
INFO - 2020-12-28 02:15:21 --> Helper loaded: url_helper
INFO - 2020-12-28 02:15:21 --> Helper loaded: file_helper
INFO - 2020-12-28 02:15:21 --> Helper loaded: form_helper
INFO - 2020-12-28 02:15:21 --> Helper loaded: my_helper
INFO - 2020-12-28 02:15:21 --> Database Driver Class Initialized
DEBUG - 2020-12-28 02:15:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 02:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 02:15:21 --> Controller Class Initialized
INFO - 2020-12-28 02:15:21 --> Helper loaded: cookie_helper
INFO - 2020-12-28 02:15:21 --> Config Class Initialized
INFO - 2020-12-28 02:15:21 --> Hooks Class Initialized
DEBUG - 2020-12-28 02:15:21 --> UTF-8 Support Enabled
INFO - 2020-12-28 02:15:21 --> Utf8 Class Initialized
INFO - 2020-12-28 02:15:21 --> URI Class Initialized
INFO - 2020-12-28 02:15:21 --> Router Class Initialized
INFO - 2020-12-28 02:15:21 --> Output Class Initialized
INFO - 2020-12-28 02:15:21 --> Security Class Initialized
DEBUG - 2020-12-28 02:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 02:15:21 --> Input Class Initialized
INFO - 2020-12-28 02:15:21 --> Language Class Initialized
INFO - 2020-12-28 02:15:21 --> Language Class Initialized
INFO - 2020-12-28 02:15:21 --> Config Class Initialized
INFO - 2020-12-28 02:15:21 --> Loader Class Initialized
INFO - 2020-12-28 02:15:21 --> Helper loaded: url_helper
INFO - 2020-12-28 02:15:21 --> Helper loaded: file_helper
INFO - 2020-12-28 02:15:21 --> Helper loaded: form_helper
INFO - 2020-12-28 02:15:22 --> Helper loaded: my_helper
INFO - 2020-12-28 02:15:22 --> Database Driver Class Initialized
DEBUG - 2020-12-28 02:15:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 02:15:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 02:15:22 --> Controller Class Initialized
DEBUG - 2020-12-28 02:15:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-28 02:15:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-28 02:15:22 --> Final output sent to browser
DEBUG - 2020-12-28 02:15:22 --> Total execution time: 0.7136
INFO - 2020-12-28 02:16:18 --> Config Class Initialized
INFO - 2020-12-28 02:16:18 --> Hooks Class Initialized
DEBUG - 2020-12-28 02:16:18 --> UTF-8 Support Enabled
INFO - 2020-12-28 02:16:18 --> Utf8 Class Initialized
INFO - 2020-12-28 02:16:18 --> URI Class Initialized
INFO - 2020-12-28 02:16:18 --> Router Class Initialized
INFO - 2020-12-28 02:16:18 --> Output Class Initialized
INFO - 2020-12-28 02:16:18 --> Security Class Initialized
DEBUG - 2020-12-28 02:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 02:16:18 --> Input Class Initialized
INFO - 2020-12-28 02:16:18 --> Language Class Initialized
INFO - 2020-12-28 02:16:18 --> Language Class Initialized
INFO - 2020-12-28 02:16:18 --> Config Class Initialized
INFO - 2020-12-28 02:16:18 --> Loader Class Initialized
INFO - 2020-12-28 02:16:18 --> Helper loaded: url_helper
INFO - 2020-12-28 02:16:18 --> Helper loaded: file_helper
INFO - 2020-12-28 02:16:18 --> Helper loaded: form_helper
INFO - 2020-12-28 02:16:18 --> Helper loaded: my_helper
INFO - 2020-12-28 02:16:18 --> Database Driver Class Initialized
DEBUG - 2020-12-28 02:16:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 02:16:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 02:16:18 --> Controller Class Initialized
INFO - 2020-12-28 02:16:18 --> Helper loaded: cookie_helper
INFO - 2020-12-28 02:16:19 --> Final output sent to browser
DEBUG - 2020-12-28 02:16:19 --> Total execution time: 0.7501
INFO - 2020-12-28 02:16:21 --> Config Class Initialized
INFO - 2020-12-28 02:16:21 --> Hooks Class Initialized
DEBUG - 2020-12-28 02:16:21 --> UTF-8 Support Enabled
INFO - 2020-12-28 02:16:21 --> Utf8 Class Initialized
INFO - 2020-12-28 02:16:21 --> URI Class Initialized
INFO - 2020-12-28 02:16:21 --> Router Class Initialized
INFO - 2020-12-28 02:16:21 --> Output Class Initialized
INFO - 2020-12-28 02:16:21 --> Security Class Initialized
DEBUG - 2020-12-28 02:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 02:16:21 --> Input Class Initialized
INFO - 2020-12-28 02:16:21 --> Language Class Initialized
INFO - 2020-12-28 02:16:22 --> Language Class Initialized
INFO - 2020-12-28 02:16:22 --> Config Class Initialized
INFO - 2020-12-28 02:16:22 --> Loader Class Initialized
INFO - 2020-12-28 02:16:22 --> Helper loaded: url_helper
INFO - 2020-12-28 02:16:22 --> Helper loaded: file_helper
INFO - 2020-12-28 02:16:22 --> Helper loaded: form_helper
INFO - 2020-12-28 02:16:22 --> Helper loaded: my_helper
INFO - 2020-12-28 02:16:22 --> Database Driver Class Initialized
DEBUG - 2020-12-28 02:16:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 02:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 02:16:22 --> Controller Class Initialized
DEBUG - 2020-12-28 02:16:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-28 02:16:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-28 02:16:22 --> Final output sent to browser
DEBUG - 2020-12-28 02:16:22 --> Total execution time: 0.9978
INFO - 2020-12-28 02:21:11 --> Config Class Initialized
INFO - 2020-12-28 02:21:11 --> Hooks Class Initialized
DEBUG - 2020-12-28 02:21:12 --> UTF-8 Support Enabled
INFO - 2020-12-28 02:21:12 --> Utf8 Class Initialized
INFO - 2020-12-28 02:21:12 --> URI Class Initialized
INFO - 2020-12-28 02:21:12 --> Router Class Initialized
INFO - 2020-12-28 02:21:12 --> Output Class Initialized
INFO - 2020-12-28 02:21:12 --> Security Class Initialized
DEBUG - 2020-12-28 02:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 02:21:12 --> Input Class Initialized
INFO - 2020-12-28 02:21:12 --> Language Class Initialized
INFO - 2020-12-28 02:21:12 --> Language Class Initialized
INFO - 2020-12-28 02:21:12 --> Config Class Initialized
INFO - 2020-12-28 02:21:12 --> Loader Class Initialized
INFO - 2020-12-28 02:21:12 --> Helper loaded: url_helper
INFO - 2020-12-28 02:21:12 --> Helper loaded: file_helper
INFO - 2020-12-28 02:21:12 --> Helper loaded: form_helper
INFO - 2020-12-28 02:21:12 --> Helper loaded: my_helper
INFO - 2020-12-28 02:21:12 --> Database Driver Class Initialized
DEBUG - 2020-12-28 02:21:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 02:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 02:21:12 --> Controller Class Initialized
DEBUG - 2020-12-28 02:21:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-12-28 02:21:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-28 02:21:12 --> Final output sent to browser
DEBUG - 2020-12-28 02:21:12 --> Total execution time: 0.9488
INFO - 2020-12-28 02:21:13 --> Config Class Initialized
INFO - 2020-12-28 02:21:13 --> Hooks Class Initialized
DEBUG - 2020-12-28 02:21:13 --> UTF-8 Support Enabled
INFO - 2020-12-28 02:21:13 --> Utf8 Class Initialized
INFO - 2020-12-28 02:21:13 --> URI Class Initialized
INFO - 2020-12-28 02:21:13 --> Router Class Initialized
INFO - 2020-12-28 02:21:13 --> Output Class Initialized
INFO - 2020-12-28 02:21:13 --> Security Class Initialized
DEBUG - 2020-12-28 02:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 02:21:13 --> Input Class Initialized
INFO - 2020-12-28 02:21:13 --> Language Class Initialized
INFO - 2020-12-28 02:21:13 --> Language Class Initialized
INFO - 2020-12-28 02:21:13 --> Config Class Initialized
INFO - 2020-12-28 02:21:13 --> Loader Class Initialized
INFO - 2020-12-28 02:21:13 --> Helper loaded: url_helper
INFO - 2020-12-28 02:21:13 --> Helper loaded: file_helper
INFO - 2020-12-28 02:21:13 --> Helper loaded: form_helper
INFO - 2020-12-28 02:21:13 --> Helper loaded: my_helper
INFO - 2020-12-28 02:21:14 --> Database Driver Class Initialized
DEBUG - 2020-12-28 02:21:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 02:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 02:21:14 --> Controller Class Initialized
INFO - 2020-12-28 02:21:33 --> Config Class Initialized
INFO - 2020-12-28 02:21:33 --> Hooks Class Initialized
DEBUG - 2020-12-28 02:21:33 --> UTF-8 Support Enabled
INFO - 2020-12-28 02:21:33 --> Utf8 Class Initialized
INFO - 2020-12-28 02:21:33 --> URI Class Initialized
INFO - 2020-12-28 02:21:33 --> Router Class Initialized
INFO - 2020-12-28 02:21:33 --> Output Class Initialized
INFO - 2020-12-28 02:21:33 --> Security Class Initialized
DEBUG - 2020-12-28 02:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 02:21:33 --> Input Class Initialized
INFO - 2020-12-28 02:21:33 --> Language Class Initialized
INFO - 2020-12-28 02:21:33 --> Language Class Initialized
INFO - 2020-12-28 02:21:33 --> Config Class Initialized
INFO - 2020-12-28 02:21:33 --> Loader Class Initialized
INFO - 2020-12-28 02:21:33 --> Helper loaded: url_helper
INFO - 2020-12-28 02:21:34 --> Helper loaded: file_helper
INFO - 2020-12-28 02:21:34 --> Helper loaded: form_helper
INFO - 2020-12-28 02:21:34 --> Helper loaded: my_helper
INFO - 2020-12-28 02:21:34 --> Database Driver Class Initialized
DEBUG - 2020-12-28 02:21:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 02:21:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 02:21:34 --> Controller Class Initialized
DEBUG - 2020-12-28 02:21:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-12-28 02:21:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-28 02:21:34 --> Final output sent to browser
DEBUG - 2020-12-28 02:21:34 --> Total execution time: 0.9349
INFO - 2020-12-28 02:21:34 --> Config Class Initialized
INFO - 2020-12-28 02:21:34 --> Hooks Class Initialized
DEBUG - 2020-12-28 02:21:34 --> UTF-8 Support Enabled
INFO - 2020-12-28 02:21:34 --> Utf8 Class Initialized
INFO - 2020-12-28 02:21:34 --> URI Class Initialized
INFO - 2020-12-28 02:21:34 --> Router Class Initialized
INFO - 2020-12-28 02:21:34 --> Output Class Initialized
INFO - 2020-12-28 02:21:34 --> Security Class Initialized
DEBUG - 2020-12-28 02:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 02:21:34 --> Input Class Initialized
INFO - 2020-12-28 02:21:35 --> Language Class Initialized
INFO - 2020-12-28 02:21:35 --> Language Class Initialized
INFO - 2020-12-28 02:21:35 --> Config Class Initialized
INFO - 2020-12-28 02:21:35 --> Loader Class Initialized
INFO - 2020-12-28 02:21:35 --> Helper loaded: url_helper
INFO - 2020-12-28 02:21:35 --> Helper loaded: file_helper
INFO - 2020-12-28 02:21:35 --> Helper loaded: form_helper
INFO - 2020-12-28 02:21:35 --> Helper loaded: my_helper
INFO - 2020-12-28 02:21:35 --> Database Driver Class Initialized
DEBUG - 2020-12-28 02:21:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 02:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 02:21:35 --> Controller Class Initialized
INFO - 2020-12-28 02:22:06 --> Config Class Initialized
INFO - 2020-12-28 02:22:06 --> Hooks Class Initialized
DEBUG - 2020-12-28 02:22:06 --> UTF-8 Support Enabled
INFO - 2020-12-28 02:22:06 --> Utf8 Class Initialized
INFO - 2020-12-28 02:22:06 --> URI Class Initialized
INFO - 2020-12-28 02:22:06 --> Router Class Initialized
INFO - 2020-12-28 02:22:06 --> Output Class Initialized
INFO - 2020-12-28 02:22:06 --> Security Class Initialized
DEBUG - 2020-12-28 02:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 02:22:06 --> Input Class Initialized
INFO - 2020-12-28 02:22:06 --> Language Class Initialized
INFO - 2020-12-28 02:22:06 --> Language Class Initialized
INFO - 2020-12-28 02:22:06 --> Config Class Initialized
INFO - 2020-12-28 02:22:06 --> Loader Class Initialized
INFO - 2020-12-28 02:22:06 --> Helper loaded: url_helper
INFO - 2020-12-28 02:22:06 --> Helper loaded: file_helper
INFO - 2020-12-28 02:22:06 --> Helper loaded: form_helper
INFO - 2020-12-28 02:22:06 --> Helper loaded: my_helper
INFO - 2020-12-28 02:22:06 --> Database Driver Class Initialized
DEBUG - 2020-12-28 02:22:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 02:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 02:22:06 --> Controller Class Initialized
INFO - 2020-12-28 02:22:06 --> Final output sent to browser
DEBUG - 2020-12-28 02:22:06 --> Total execution time: 0.6932
INFO - 2020-12-28 02:30:22 --> Config Class Initialized
INFO - 2020-12-28 02:30:22 --> Hooks Class Initialized
DEBUG - 2020-12-28 02:30:22 --> UTF-8 Support Enabled
INFO - 2020-12-28 02:30:22 --> Utf8 Class Initialized
INFO - 2020-12-28 02:30:22 --> URI Class Initialized
INFO - 2020-12-28 02:30:22 --> Router Class Initialized
INFO - 2020-12-28 02:30:22 --> Output Class Initialized
INFO - 2020-12-28 02:30:22 --> Security Class Initialized
DEBUG - 2020-12-28 02:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 02:30:22 --> Input Class Initialized
INFO - 2020-12-28 02:30:22 --> Language Class Initialized
INFO - 2020-12-28 02:30:22 --> Language Class Initialized
INFO - 2020-12-28 02:30:23 --> Config Class Initialized
INFO - 2020-12-28 02:30:23 --> Loader Class Initialized
INFO - 2020-12-28 02:30:23 --> Helper loaded: url_helper
INFO - 2020-12-28 02:30:23 --> Helper loaded: file_helper
INFO - 2020-12-28 02:30:23 --> Helper loaded: form_helper
INFO - 2020-12-28 02:30:23 --> Helper loaded: my_helper
INFO - 2020-12-28 02:30:23 --> Database Driver Class Initialized
DEBUG - 2020-12-28 02:30:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 02:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 02:30:23 --> Controller Class Initialized
DEBUG - 2020-12-28 02:30:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-12-28 02:30:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-28 02:30:23 --> Final output sent to browser
DEBUG - 2020-12-28 02:30:23 --> Total execution time: 0.8231
INFO - 2020-12-28 02:30:23 --> Config Class Initialized
INFO - 2020-12-28 02:30:23 --> Hooks Class Initialized
DEBUG - 2020-12-28 02:30:23 --> UTF-8 Support Enabled
INFO - 2020-12-28 02:30:23 --> Utf8 Class Initialized
INFO - 2020-12-28 02:30:23 --> URI Class Initialized
INFO - 2020-12-28 02:30:23 --> Router Class Initialized
INFO - 2020-12-28 02:30:23 --> Output Class Initialized
INFO - 2020-12-28 02:30:23 --> Security Class Initialized
DEBUG - 2020-12-28 02:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 02:30:23 --> Input Class Initialized
INFO - 2020-12-28 02:30:23 --> Language Class Initialized
INFO - 2020-12-28 02:30:24 --> Language Class Initialized
INFO - 2020-12-28 02:30:24 --> Config Class Initialized
INFO - 2020-12-28 02:30:24 --> Loader Class Initialized
INFO - 2020-12-28 02:30:24 --> Helper loaded: url_helper
INFO - 2020-12-28 02:30:24 --> Helper loaded: file_helper
INFO - 2020-12-28 02:30:24 --> Helper loaded: form_helper
INFO - 2020-12-28 02:30:24 --> Helper loaded: my_helper
INFO - 2020-12-28 02:30:24 --> Database Driver Class Initialized
DEBUG - 2020-12-28 02:30:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 02:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 02:30:24 --> Controller Class Initialized
INFO - 2020-12-28 02:30:25 --> Config Class Initialized
INFO - 2020-12-28 02:30:25 --> Hooks Class Initialized
DEBUG - 2020-12-28 02:30:25 --> UTF-8 Support Enabled
INFO - 2020-12-28 02:30:25 --> Utf8 Class Initialized
INFO - 2020-12-28 02:30:25 --> URI Class Initialized
INFO - 2020-12-28 02:30:25 --> Router Class Initialized
INFO - 2020-12-28 02:30:26 --> Output Class Initialized
INFO - 2020-12-28 02:30:26 --> Security Class Initialized
DEBUG - 2020-12-28 02:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 02:30:26 --> Input Class Initialized
INFO - 2020-12-28 02:30:26 --> Language Class Initialized
INFO - 2020-12-28 02:30:26 --> Language Class Initialized
INFO - 2020-12-28 02:30:26 --> Config Class Initialized
INFO - 2020-12-28 02:30:26 --> Loader Class Initialized
INFO - 2020-12-28 02:30:26 --> Helper loaded: url_helper
INFO - 2020-12-28 02:30:26 --> Helper loaded: file_helper
INFO - 2020-12-28 02:30:26 --> Helper loaded: form_helper
INFO - 2020-12-28 02:30:26 --> Helper loaded: my_helper
INFO - 2020-12-28 02:30:26 --> Database Driver Class Initialized
DEBUG - 2020-12-28 02:30:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 02:30:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 02:30:26 --> Controller Class Initialized
INFO - 2020-12-28 02:30:26 --> Final output sent to browser
DEBUG - 2020-12-28 02:30:26 --> Total execution time: 0.8030
INFO - 2020-12-28 02:40:43 --> Config Class Initialized
INFO - 2020-12-28 02:40:43 --> Hooks Class Initialized
DEBUG - 2020-12-28 02:40:43 --> UTF-8 Support Enabled
INFO - 2020-12-28 02:40:43 --> Utf8 Class Initialized
INFO - 2020-12-28 02:40:43 --> URI Class Initialized
INFO - 2020-12-28 02:40:43 --> Router Class Initialized
INFO - 2020-12-28 02:40:43 --> Output Class Initialized
INFO - 2020-12-28 02:40:43 --> Security Class Initialized
DEBUG - 2020-12-28 02:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 02:40:43 --> Input Class Initialized
INFO - 2020-12-28 02:40:43 --> Language Class Initialized
INFO - 2020-12-28 02:40:43 --> Language Class Initialized
INFO - 2020-12-28 02:40:43 --> Config Class Initialized
INFO - 2020-12-28 02:40:43 --> Loader Class Initialized
INFO - 2020-12-28 02:40:43 --> Helper loaded: url_helper
INFO - 2020-12-28 02:40:43 --> Helper loaded: file_helper
INFO - 2020-12-28 02:40:43 --> Helper loaded: form_helper
INFO - 2020-12-28 02:40:43 --> Helper loaded: my_helper
INFO - 2020-12-28 02:40:43 --> Database Driver Class Initialized
DEBUG - 2020-12-28 02:40:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 02:40:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 02:40:43 --> Controller Class Initialized
DEBUG - 2020-12-28 02:40:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-12-28 02:40:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-28 02:40:43 --> Final output sent to browser
DEBUG - 2020-12-28 02:40:43 --> Total execution time: 0.7256
INFO - 2020-12-28 02:40:44 --> Config Class Initialized
INFO - 2020-12-28 02:40:44 --> Hooks Class Initialized
DEBUG - 2020-12-28 02:40:44 --> UTF-8 Support Enabled
INFO - 2020-12-28 02:40:44 --> Utf8 Class Initialized
INFO - 2020-12-28 02:40:44 --> URI Class Initialized
INFO - 2020-12-28 02:40:44 --> Router Class Initialized
INFO - 2020-12-28 02:40:44 --> Output Class Initialized
INFO - 2020-12-28 02:40:44 --> Security Class Initialized
DEBUG - 2020-12-28 02:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 02:40:44 --> Input Class Initialized
INFO - 2020-12-28 02:40:44 --> Language Class Initialized
INFO - 2020-12-28 02:40:44 --> Language Class Initialized
INFO - 2020-12-28 02:40:44 --> Config Class Initialized
INFO - 2020-12-28 02:40:44 --> Loader Class Initialized
INFO - 2020-12-28 02:40:44 --> Helper loaded: url_helper
INFO - 2020-12-28 02:40:44 --> Helper loaded: file_helper
INFO - 2020-12-28 02:40:44 --> Helper loaded: form_helper
INFO - 2020-12-28 02:40:44 --> Helper loaded: my_helper
INFO - 2020-12-28 02:40:44 --> Database Driver Class Initialized
DEBUG - 2020-12-28 02:40:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 02:40:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 02:40:44 --> Controller Class Initialized
INFO - 2020-12-28 02:40:46 --> Config Class Initialized
INFO - 2020-12-28 02:40:46 --> Hooks Class Initialized
DEBUG - 2020-12-28 02:40:46 --> UTF-8 Support Enabled
INFO - 2020-12-28 02:40:46 --> Utf8 Class Initialized
INFO - 2020-12-28 02:40:46 --> URI Class Initialized
INFO - 2020-12-28 02:40:46 --> Router Class Initialized
INFO - 2020-12-28 02:40:46 --> Output Class Initialized
INFO - 2020-12-28 02:40:46 --> Security Class Initialized
DEBUG - 2020-12-28 02:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 02:40:46 --> Input Class Initialized
INFO - 2020-12-28 02:40:46 --> Language Class Initialized
INFO - 2020-12-28 02:40:46 --> Language Class Initialized
INFO - 2020-12-28 02:40:46 --> Config Class Initialized
INFO - 2020-12-28 02:40:46 --> Loader Class Initialized
INFO - 2020-12-28 02:40:46 --> Helper loaded: url_helper
INFO - 2020-12-28 02:40:46 --> Helper loaded: file_helper
INFO - 2020-12-28 02:40:46 --> Helper loaded: form_helper
INFO - 2020-12-28 02:40:46 --> Helper loaded: my_helper
INFO - 2020-12-28 02:40:46 --> Database Driver Class Initialized
DEBUG - 2020-12-28 02:40:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 02:40:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 02:40:46 --> Controller Class Initialized
INFO - 2020-12-28 02:40:46 --> Final output sent to browser
DEBUG - 2020-12-28 02:40:46 --> Total execution time: 0.6205
INFO - 2020-12-28 02:42:59 --> Config Class Initialized
INFO - 2020-12-28 02:42:59 --> Hooks Class Initialized
DEBUG - 2020-12-28 02:42:59 --> UTF-8 Support Enabled
INFO - 2020-12-28 02:42:59 --> Utf8 Class Initialized
INFO - 2020-12-28 02:42:59 --> URI Class Initialized
INFO - 2020-12-28 02:43:00 --> Router Class Initialized
INFO - 2020-12-28 02:43:00 --> Output Class Initialized
INFO - 2020-12-28 02:43:00 --> Security Class Initialized
DEBUG - 2020-12-28 02:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 02:43:00 --> Input Class Initialized
INFO - 2020-12-28 02:43:00 --> Language Class Initialized
INFO - 2020-12-28 02:43:00 --> Language Class Initialized
INFO - 2020-12-28 02:43:00 --> Config Class Initialized
INFO - 2020-12-28 02:43:00 --> Loader Class Initialized
INFO - 2020-12-28 02:43:00 --> Helper loaded: url_helper
INFO - 2020-12-28 02:43:00 --> Helper loaded: file_helper
INFO - 2020-12-28 02:43:00 --> Helper loaded: form_helper
INFO - 2020-12-28 02:43:00 --> Helper loaded: my_helper
INFO - 2020-12-28 02:43:00 --> Database Driver Class Initialized
DEBUG - 2020-12-28 02:43:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 02:43:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 02:43:00 --> Controller Class Initialized
DEBUG - 2020-12-28 02:43:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-12-28 02:43:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-28 02:43:00 --> Final output sent to browser
DEBUG - 2020-12-28 02:43:00 --> Total execution time: 0.6379
INFO - 2020-12-28 02:43:00 --> Config Class Initialized
INFO - 2020-12-28 02:43:00 --> Hooks Class Initialized
DEBUG - 2020-12-28 02:43:00 --> UTF-8 Support Enabled
INFO - 2020-12-28 02:43:00 --> Utf8 Class Initialized
INFO - 2020-12-28 02:43:00 --> URI Class Initialized
INFO - 2020-12-28 02:43:01 --> Router Class Initialized
INFO - 2020-12-28 02:43:01 --> Output Class Initialized
INFO - 2020-12-28 02:43:01 --> Security Class Initialized
DEBUG - 2020-12-28 02:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 02:43:01 --> Input Class Initialized
INFO - 2020-12-28 02:43:01 --> Language Class Initialized
INFO - 2020-12-28 02:43:01 --> Language Class Initialized
INFO - 2020-12-28 02:43:01 --> Config Class Initialized
INFO - 2020-12-28 02:43:01 --> Loader Class Initialized
INFO - 2020-12-28 02:43:01 --> Helper loaded: url_helper
INFO - 2020-12-28 02:43:01 --> Helper loaded: file_helper
INFO - 2020-12-28 02:43:01 --> Helper loaded: form_helper
INFO - 2020-12-28 02:43:01 --> Helper loaded: my_helper
INFO - 2020-12-28 02:43:01 --> Database Driver Class Initialized
DEBUG - 2020-12-28 02:43:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 02:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 02:43:01 --> Controller Class Initialized
INFO - 2020-12-28 02:43:01 --> Config Class Initialized
INFO - 2020-12-28 02:43:01 --> Hooks Class Initialized
DEBUG - 2020-12-28 02:43:01 --> UTF-8 Support Enabled
INFO - 2020-12-28 02:43:01 --> Utf8 Class Initialized
INFO - 2020-12-28 02:43:01 --> URI Class Initialized
INFO - 2020-12-28 02:43:01 --> Router Class Initialized
INFO - 2020-12-28 02:43:01 --> Output Class Initialized
INFO - 2020-12-28 02:43:01 --> Security Class Initialized
DEBUG - 2020-12-28 02:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 02:43:01 --> Input Class Initialized
INFO - 2020-12-28 02:43:01 --> Language Class Initialized
INFO - 2020-12-28 02:43:01 --> Language Class Initialized
INFO - 2020-12-28 02:43:01 --> Config Class Initialized
INFO - 2020-12-28 02:43:01 --> Loader Class Initialized
INFO - 2020-12-28 02:43:01 --> Helper loaded: url_helper
INFO - 2020-12-28 02:43:01 --> Helper loaded: file_helper
INFO - 2020-12-28 02:43:02 --> Helper loaded: form_helper
INFO - 2020-12-28 02:43:02 --> Helper loaded: my_helper
INFO - 2020-12-28 02:43:02 --> Database Driver Class Initialized
DEBUG - 2020-12-28 02:43:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 02:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 02:43:02 --> Controller Class Initialized
INFO - 2020-12-28 02:43:02 --> Final output sent to browser
DEBUG - 2020-12-28 02:43:02 --> Total execution time: 0.6211
INFO - 2020-12-28 02:45:41 --> Config Class Initialized
INFO - 2020-12-28 02:45:41 --> Hooks Class Initialized
DEBUG - 2020-12-28 02:45:41 --> UTF-8 Support Enabled
INFO - 2020-12-28 02:45:41 --> Utf8 Class Initialized
INFO - 2020-12-28 02:45:41 --> URI Class Initialized
INFO - 2020-12-28 02:45:41 --> Router Class Initialized
INFO - 2020-12-28 02:45:41 --> Output Class Initialized
INFO - 2020-12-28 02:45:41 --> Security Class Initialized
DEBUG - 2020-12-28 02:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 02:45:41 --> Input Class Initialized
INFO - 2020-12-28 02:45:41 --> Language Class Initialized
INFO - 2020-12-28 02:45:41 --> Language Class Initialized
INFO - 2020-12-28 02:45:41 --> Config Class Initialized
INFO - 2020-12-28 02:45:41 --> Loader Class Initialized
INFO - 2020-12-28 02:45:41 --> Helper loaded: url_helper
INFO - 2020-12-28 02:45:41 --> Helper loaded: file_helper
INFO - 2020-12-28 02:45:41 --> Helper loaded: form_helper
INFO - 2020-12-28 02:45:41 --> Helper loaded: my_helper
INFO - 2020-12-28 02:45:41 --> Database Driver Class Initialized
DEBUG - 2020-12-28 02:45:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 02:45:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 02:45:41 --> Controller Class Initialized
DEBUG - 2020-12-28 02:45:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-12-28 02:45:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-28 02:45:42 --> Final output sent to browser
DEBUG - 2020-12-28 02:45:42 --> Total execution time: 0.7723
INFO - 2020-12-28 02:45:42 --> Config Class Initialized
INFO - 2020-12-28 02:45:42 --> Hooks Class Initialized
DEBUG - 2020-12-28 02:45:42 --> UTF-8 Support Enabled
INFO - 2020-12-28 02:45:42 --> Utf8 Class Initialized
INFO - 2020-12-28 02:45:42 --> URI Class Initialized
INFO - 2020-12-28 02:45:42 --> Router Class Initialized
INFO - 2020-12-28 02:45:42 --> Output Class Initialized
INFO - 2020-12-28 02:45:42 --> Security Class Initialized
DEBUG - 2020-12-28 02:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 02:45:42 --> Input Class Initialized
INFO - 2020-12-28 02:45:42 --> Language Class Initialized
INFO - 2020-12-28 02:45:42 --> Language Class Initialized
INFO - 2020-12-28 02:45:42 --> Config Class Initialized
INFO - 2020-12-28 02:45:42 --> Loader Class Initialized
INFO - 2020-12-28 02:45:42 --> Helper loaded: url_helper
INFO - 2020-12-28 02:45:42 --> Helper loaded: file_helper
INFO - 2020-12-28 02:45:42 --> Helper loaded: form_helper
INFO - 2020-12-28 02:45:42 --> Helper loaded: my_helper
INFO - 2020-12-28 02:45:42 --> Database Driver Class Initialized
DEBUG - 2020-12-28 02:45:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 02:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 02:45:42 --> Controller Class Initialized
INFO - 2020-12-28 02:45:44 --> Config Class Initialized
INFO - 2020-12-28 02:45:44 --> Hooks Class Initialized
DEBUG - 2020-12-28 02:45:44 --> UTF-8 Support Enabled
INFO - 2020-12-28 02:45:44 --> Utf8 Class Initialized
INFO - 2020-12-28 02:45:44 --> URI Class Initialized
INFO - 2020-12-28 02:45:44 --> Router Class Initialized
INFO - 2020-12-28 02:45:44 --> Output Class Initialized
INFO - 2020-12-28 02:45:44 --> Security Class Initialized
DEBUG - 2020-12-28 02:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 02:45:44 --> Input Class Initialized
INFO - 2020-12-28 02:45:44 --> Language Class Initialized
INFO - 2020-12-28 02:45:44 --> Language Class Initialized
INFO - 2020-12-28 02:45:44 --> Config Class Initialized
INFO - 2020-12-28 02:45:44 --> Loader Class Initialized
INFO - 2020-12-28 02:45:44 --> Helper loaded: url_helper
INFO - 2020-12-28 02:45:44 --> Helper loaded: file_helper
INFO - 2020-12-28 02:45:44 --> Helper loaded: form_helper
INFO - 2020-12-28 02:45:44 --> Helper loaded: my_helper
INFO - 2020-12-28 02:45:45 --> Database Driver Class Initialized
DEBUG - 2020-12-28 02:45:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 02:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 02:45:45 --> Controller Class Initialized
INFO - 2020-12-28 02:45:45 --> Final output sent to browser
DEBUG - 2020-12-28 02:45:45 --> Total execution time: 0.7141
INFO - 2020-12-28 02:48:37 --> Config Class Initialized
INFO - 2020-12-28 02:48:37 --> Hooks Class Initialized
DEBUG - 2020-12-28 02:48:37 --> UTF-8 Support Enabled
INFO - 2020-12-28 02:48:37 --> Utf8 Class Initialized
INFO - 2020-12-28 02:48:37 --> URI Class Initialized
INFO - 2020-12-28 02:48:37 --> Router Class Initialized
INFO - 2020-12-28 02:48:37 --> Output Class Initialized
INFO - 2020-12-28 02:48:37 --> Security Class Initialized
DEBUG - 2020-12-28 02:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 02:48:37 --> Input Class Initialized
INFO - 2020-12-28 02:48:37 --> Language Class Initialized
INFO - 2020-12-28 02:48:37 --> Language Class Initialized
INFO - 2020-12-28 02:48:37 --> Config Class Initialized
INFO - 2020-12-28 02:48:37 --> Loader Class Initialized
INFO - 2020-12-28 02:48:37 --> Helper loaded: url_helper
INFO - 2020-12-28 02:48:37 --> Helper loaded: file_helper
INFO - 2020-12-28 02:48:37 --> Helper loaded: form_helper
INFO - 2020-12-28 02:48:37 --> Helper loaded: my_helper
INFO - 2020-12-28 02:48:37 --> Database Driver Class Initialized
DEBUG - 2020-12-28 02:48:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 02:48:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 02:48:38 --> Controller Class Initialized
INFO - 2020-12-28 02:48:38 --> Final output sent to browser
DEBUG - 2020-12-28 02:48:38 --> Total execution time: 0.7366
INFO - 2020-12-28 02:48:38 --> Config Class Initialized
INFO - 2020-12-28 02:48:38 --> Hooks Class Initialized
DEBUG - 2020-12-28 02:48:38 --> UTF-8 Support Enabled
INFO - 2020-12-28 02:48:38 --> Utf8 Class Initialized
INFO - 2020-12-28 02:48:38 --> URI Class Initialized
INFO - 2020-12-28 02:48:38 --> Router Class Initialized
INFO - 2020-12-28 02:48:38 --> Output Class Initialized
INFO - 2020-12-28 02:48:38 --> Security Class Initialized
DEBUG - 2020-12-28 02:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 02:48:38 --> Input Class Initialized
INFO - 2020-12-28 02:48:38 --> Language Class Initialized
INFO - 2020-12-28 02:48:38 --> Language Class Initialized
INFO - 2020-12-28 02:48:38 --> Config Class Initialized
INFO - 2020-12-28 02:48:38 --> Loader Class Initialized
INFO - 2020-12-28 02:48:38 --> Helper loaded: url_helper
INFO - 2020-12-28 02:48:38 --> Helper loaded: file_helper
INFO - 2020-12-28 02:48:39 --> Helper loaded: form_helper
INFO - 2020-12-28 02:48:39 --> Helper loaded: my_helper
INFO - 2020-12-28 02:48:39 --> Database Driver Class Initialized
DEBUG - 2020-12-28 02:48:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 02:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 02:48:39 --> Controller Class Initialized
INFO - 2020-12-28 02:48:45 --> Config Class Initialized
INFO - 2020-12-28 02:48:45 --> Hooks Class Initialized
DEBUG - 2020-12-28 02:48:45 --> UTF-8 Support Enabled
INFO - 2020-12-28 02:48:45 --> Utf8 Class Initialized
INFO - 2020-12-28 02:48:45 --> URI Class Initialized
INFO - 2020-12-28 02:48:45 --> Router Class Initialized
INFO - 2020-12-28 02:48:45 --> Output Class Initialized
INFO - 2020-12-28 02:48:45 --> Security Class Initialized
DEBUG - 2020-12-28 02:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 02:48:45 --> Input Class Initialized
INFO - 2020-12-28 02:48:45 --> Language Class Initialized
INFO - 2020-12-28 02:48:45 --> Language Class Initialized
INFO - 2020-12-28 02:48:45 --> Config Class Initialized
INFO - 2020-12-28 02:48:45 --> Loader Class Initialized
INFO - 2020-12-28 02:48:45 --> Helper loaded: url_helper
INFO - 2020-12-28 02:48:45 --> Helper loaded: file_helper
INFO - 2020-12-28 02:48:45 --> Helper loaded: form_helper
INFO - 2020-12-28 02:48:45 --> Helper loaded: my_helper
INFO - 2020-12-28 02:48:45 --> Database Driver Class Initialized
DEBUG - 2020-12-28 02:48:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 02:48:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 02:48:45 --> Controller Class Initialized
INFO - 2020-12-28 02:48:45 --> Final output sent to browser
DEBUG - 2020-12-28 02:48:45 --> Total execution time: 0.6188
INFO - 2020-12-28 02:49:02 --> Config Class Initialized
INFO - 2020-12-28 02:49:02 --> Hooks Class Initialized
DEBUG - 2020-12-28 02:49:02 --> UTF-8 Support Enabled
INFO - 2020-12-28 02:49:02 --> Utf8 Class Initialized
INFO - 2020-12-28 02:49:02 --> URI Class Initialized
INFO - 2020-12-28 02:49:02 --> Router Class Initialized
INFO - 2020-12-28 02:49:02 --> Output Class Initialized
INFO - 2020-12-28 02:49:02 --> Security Class Initialized
DEBUG - 2020-12-28 02:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 02:49:02 --> Input Class Initialized
INFO - 2020-12-28 02:49:02 --> Language Class Initialized
INFO - 2020-12-28 02:49:02 --> Language Class Initialized
INFO - 2020-12-28 02:49:02 --> Config Class Initialized
INFO - 2020-12-28 02:49:02 --> Loader Class Initialized
INFO - 2020-12-28 02:49:02 --> Helper loaded: url_helper
INFO - 2020-12-28 02:49:02 --> Helper loaded: file_helper
INFO - 2020-12-28 02:49:02 --> Helper loaded: form_helper
INFO - 2020-12-28 02:49:02 --> Helper loaded: my_helper
INFO - 2020-12-28 02:49:02 --> Database Driver Class Initialized
DEBUG - 2020-12-28 02:49:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 02:49:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 02:49:02 --> Controller Class Initialized
INFO - 2020-12-28 02:49:02 --> Final output sent to browser
DEBUG - 2020-12-28 02:49:02 --> Total execution time: 0.7680
INFO - 2020-12-28 02:49:47 --> Config Class Initialized
INFO - 2020-12-28 02:49:47 --> Hooks Class Initialized
DEBUG - 2020-12-28 02:49:47 --> UTF-8 Support Enabled
INFO - 2020-12-28 02:49:47 --> Utf8 Class Initialized
INFO - 2020-12-28 02:49:47 --> URI Class Initialized
INFO - 2020-12-28 02:49:47 --> Router Class Initialized
INFO - 2020-12-28 02:49:47 --> Output Class Initialized
INFO - 2020-12-28 02:49:47 --> Security Class Initialized
DEBUG - 2020-12-28 02:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 02:49:47 --> Input Class Initialized
INFO - 2020-12-28 02:49:47 --> Language Class Initialized
INFO - 2020-12-28 02:49:47 --> Language Class Initialized
INFO - 2020-12-28 02:49:47 --> Config Class Initialized
INFO - 2020-12-28 02:49:47 --> Loader Class Initialized
INFO - 2020-12-28 02:49:47 --> Helper loaded: url_helper
INFO - 2020-12-28 02:49:47 --> Helper loaded: file_helper
INFO - 2020-12-28 02:49:47 --> Helper loaded: form_helper
INFO - 2020-12-28 02:49:47 --> Helper loaded: my_helper
INFO - 2020-12-28 02:49:47 --> Database Driver Class Initialized
DEBUG - 2020-12-28 02:49:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 02:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 02:49:48 --> Controller Class Initialized
INFO - 2020-12-28 02:49:48 --> Final output sent to browser
DEBUG - 2020-12-28 02:49:48 --> Total execution time: 0.7491
INFO - 2020-12-28 02:49:48 --> Config Class Initialized
INFO - 2020-12-28 02:49:48 --> Hooks Class Initialized
DEBUG - 2020-12-28 02:49:48 --> UTF-8 Support Enabled
INFO - 2020-12-28 02:49:48 --> Utf8 Class Initialized
INFO - 2020-12-28 02:49:48 --> URI Class Initialized
INFO - 2020-12-28 02:49:48 --> Router Class Initialized
INFO - 2020-12-28 02:49:48 --> Output Class Initialized
INFO - 2020-12-28 02:49:48 --> Security Class Initialized
DEBUG - 2020-12-28 02:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 02:49:48 --> Input Class Initialized
INFO - 2020-12-28 02:49:48 --> Language Class Initialized
INFO - 2020-12-28 02:49:48 --> Language Class Initialized
INFO - 2020-12-28 02:49:48 --> Config Class Initialized
INFO - 2020-12-28 02:49:48 --> Loader Class Initialized
INFO - 2020-12-28 02:49:49 --> Helper loaded: url_helper
INFO - 2020-12-28 02:49:49 --> Helper loaded: file_helper
INFO - 2020-12-28 02:49:49 --> Helper loaded: form_helper
INFO - 2020-12-28 02:49:49 --> Helper loaded: my_helper
INFO - 2020-12-28 02:49:49 --> Database Driver Class Initialized
DEBUG - 2020-12-28 02:49:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 02:49:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 02:49:49 --> Controller Class Initialized
INFO - 2020-12-28 02:49:52 --> Config Class Initialized
INFO - 2020-12-28 02:49:52 --> Hooks Class Initialized
DEBUG - 2020-12-28 02:49:52 --> UTF-8 Support Enabled
INFO - 2020-12-28 02:49:52 --> Utf8 Class Initialized
INFO - 2020-12-28 02:49:52 --> URI Class Initialized
INFO - 2020-12-28 02:49:52 --> Router Class Initialized
INFO - 2020-12-28 02:49:52 --> Output Class Initialized
INFO - 2020-12-28 02:49:52 --> Security Class Initialized
DEBUG - 2020-12-28 02:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 02:49:52 --> Input Class Initialized
INFO - 2020-12-28 02:49:53 --> Language Class Initialized
INFO - 2020-12-28 02:49:53 --> Language Class Initialized
INFO - 2020-12-28 02:49:53 --> Config Class Initialized
INFO - 2020-12-28 02:49:53 --> Loader Class Initialized
INFO - 2020-12-28 02:49:53 --> Helper loaded: url_helper
INFO - 2020-12-28 02:49:53 --> Helper loaded: file_helper
INFO - 2020-12-28 02:49:53 --> Helper loaded: form_helper
INFO - 2020-12-28 02:49:53 --> Helper loaded: my_helper
INFO - 2020-12-28 02:49:53 --> Database Driver Class Initialized
DEBUG - 2020-12-28 02:49:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 02:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 02:49:53 --> Controller Class Initialized
INFO - 2020-12-28 02:49:53 --> Final output sent to browser
DEBUG - 2020-12-28 02:49:53 --> Total execution time: 0.7460
INFO - 2020-12-28 02:50:19 --> Config Class Initialized
INFO - 2020-12-28 02:50:19 --> Hooks Class Initialized
DEBUG - 2020-12-28 02:50:19 --> UTF-8 Support Enabled
INFO - 2020-12-28 02:50:19 --> Utf8 Class Initialized
INFO - 2020-12-28 02:50:19 --> URI Class Initialized
INFO - 2020-12-28 02:50:20 --> Router Class Initialized
INFO - 2020-12-28 02:50:20 --> Output Class Initialized
INFO - 2020-12-28 02:50:20 --> Security Class Initialized
DEBUG - 2020-12-28 02:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 02:50:20 --> Input Class Initialized
INFO - 2020-12-28 02:50:20 --> Language Class Initialized
INFO - 2020-12-28 02:50:20 --> Language Class Initialized
INFO - 2020-12-28 02:50:20 --> Config Class Initialized
INFO - 2020-12-28 02:50:20 --> Loader Class Initialized
INFO - 2020-12-28 02:50:20 --> Helper loaded: url_helper
INFO - 2020-12-28 02:50:20 --> Helper loaded: file_helper
INFO - 2020-12-28 02:50:20 --> Helper loaded: form_helper
INFO - 2020-12-28 02:50:20 --> Helper loaded: my_helper
INFO - 2020-12-28 02:50:20 --> Database Driver Class Initialized
DEBUG - 2020-12-28 02:50:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 02:50:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 02:50:20 --> Controller Class Initialized
INFO - 2020-12-28 02:50:20 --> Final output sent to browser
DEBUG - 2020-12-28 02:50:20 --> Total execution time: 0.6603
INFO - 2020-12-28 02:50:20 --> Config Class Initialized
INFO - 2020-12-28 02:50:20 --> Hooks Class Initialized
DEBUG - 2020-12-28 02:50:20 --> UTF-8 Support Enabled
INFO - 2020-12-28 02:50:20 --> Utf8 Class Initialized
INFO - 2020-12-28 02:50:20 --> URI Class Initialized
INFO - 2020-12-28 02:50:20 --> Router Class Initialized
INFO - 2020-12-28 02:50:20 --> Output Class Initialized
INFO - 2020-12-28 02:50:20 --> Security Class Initialized
DEBUG - 2020-12-28 02:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 02:50:20 --> Input Class Initialized
INFO - 2020-12-28 02:50:21 --> Language Class Initialized
INFO - 2020-12-28 02:50:21 --> Language Class Initialized
INFO - 2020-12-28 02:50:21 --> Config Class Initialized
INFO - 2020-12-28 02:50:21 --> Loader Class Initialized
INFO - 2020-12-28 02:50:21 --> Helper loaded: url_helper
INFO - 2020-12-28 02:50:21 --> Helper loaded: file_helper
INFO - 2020-12-28 02:50:21 --> Helper loaded: form_helper
INFO - 2020-12-28 02:50:21 --> Helper loaded: my_helper
INFO - 2020-12-28 02:50:21 --> Database Driver Class Initialized
DEBUG - 2020-12-28 02:50:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 02:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 02:50:21 --> Controller Class Initialized
INFO - 2020-12-28 02:50:22 --> Config Class Initialized
INFO - 2020-12-28 02:50:22 --> Hooks Class Initialized
DEBUG - 2020-12-28 02:50:22 --> UTF-8 Support Enabled
INFO - 2020-12-28 02:50:22 --> Utf8 Class Initialized
INFO - 2020-12-28 02:50:22 --> URI Class Initialized
INFO - 2020-12-28 02:50:22 --> Router Class Initialized
INFO - 2020-12-28 02:50:22 --> Output Class Initialized
INFO - 2020-12-28 02:50:22 --> Security Class Initialized
DEBUG - 2020-12-28 02:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 02:50:22 --> Input Class Initialized
INFO - 2020-12-28 02:50:22 --> Language Class Initialized
INFO - 2020-12-28 02:50:22 --> Language Class Initialized
INFO - 2020-12-28 02:50:22 --> Config Class Initialized
INFO - 2020-12-28 02:50:23 --> Loader Class Initialized
INFO - 2020-12-28 02:50:23 --> Helper loaded: url_helper
INFO - 2020-12-28 02:50:23 --> Helper loaded: file_helper
INFO - 2020-12-28 02:50:23 --> Helper loaded: form_helper
INFO - 2020-12-28 02:50:23 --> Helper loaded: my_helper
INFO - 2020-12-28 02:50:23 --> Database Driver Class Initialized
DEBUG - 2020-12-28 02:50:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 02:50:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 02:50:23 --> Controller Class Initialized
INFO - 2020-12-28 02:50:23 --> Final output sent to browser
DEBUG - 2020-12-28 02:50:23 --> Total execution time: 0.7485
INFO - 2020-12-28 02:50:26 --> Config Class Initialized
INFO - 2020-12-28 02:50:26 --> Hooks Class Initialized
DEBUG - 2020-12-28 02:50:26 --> UTF-8 Support Enabled
INFO - 2020-12-28 02:50:26 --> Utf8 Class Initialized
INFO - 2020-12-28 02:50:26 --> URI Class Initialized
INFO - 2020-12-28 02:50:26 --> Router Class Initialized
INFO - 2020-12-28 02:50:26 --> Output Class Initialized
INFO - 2020-12-28 02:50:26 --> Security Class Initialized
DEBUG - 2020-12-28 02:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 02:50:26 --> Input Class Initialized
INFO - 2020-12-28 02:50:26 --> Language Class Initialized
INFO - 2020-12-28 02:50:26 --> Language Class Initialized
INFO - 2020-12-28 02:50:26 --> Config Class Initialized
INFO - 2020-12-28 02:50:26 --> Loader Class Initialized
INFO - 2020-12-28 02:50:26 --> Helper loaded: url_helper
INFO - 2020-12-28 02:50:26 --> Helper loaded: file_helper
INFO - 2020-12-28 02:50:26 --> Helper loaded: form_helper
INFO - 2020-12-28 02:50:26 --> Helper loaded: my_helper
INFO - 2020-12-28 02:50:27 --> Database Driver Class Initialized
DEBUG - 2020-12-28 02:50:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 02:50:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 02:50:27 --> Controller Class Initialized
INFO - 2020-12-28 02:50:27 --> Final output sent to browser
DEBUG - 2020-12-28 02:50:27 --> Total execution time: 0.7713
INFO - 2020-12-28 02:51:06 --> Config Class Initialized
INFO - 2020-12-28 02:51:06 --> Hooks Class Initialized
DEBUG - 2020-12-28 02:51:06 --> UTF-8 Support Enabled
INFO - 2020-12-28 02:51:06 --> Utf8 Class Initialized
INFO - 2020-12-28 02:51:06 --> URI Class Initialized
INFO - 2020-12-28 02:51:06 --> Router Class Initialized
INFO - 2020-12-28 02:51:06 --> Output Class Initialized
INFO - 2020-12-28 02:51:06 --> Security Class Initialized
DEBUG - 2020-12-28 02:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 02:51:06 --> Input Class Initialized
INFO - 2020-12-28 02:51:06 --> Language Class Initialized
INFO - 2020-12-28 02:51:06 --> Language Class Initialized
INFO - 2020-12-28 02:51:06 --> Config Class Initialized
INFO - 2020-12-28 02:51:06 --> Loader Class Initialized
INFO - 2020-12-28 02:51:06 --> Helper loaded: url_helper
INFO - 2020-12-28 02:51:07 --> Helper loaded: file_helper
INFO - 2020-12-28 02:51:07 --> Helper loaded: form_helper
INFO - 2020-12-28 02:51:07 --> Helper loaded: my_helper
INFO - 2020-12-28 02:51:07 --> Database Driver Class Initialized
DEBUG - 2020-12-28 02:51:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 02:51:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 02:51:07 --> Controller Class Initialized
INFO - 2020-12-28 02:51:07 --> Final output sent to browser
DEBUG - 2020-12-28 02:51:07 --> Total execution time: 0.7013
INFO - 2020-12-28 02:51:07 --> Config Class Initialized
INFO - 2020-12-28 02:51:07 --> Hooks Class Initialized
DEBUG - 2020-12-28 02:51:07 --> UTF-8 Support Enabled
INFO - 2020-12-28 02:51:07 --> Utf8 Class Initialized
INFO - 2020-12-28 02:51:07 --> URI Class Initialized
INFO - 2020-12-28 02:51:07 --> Router Class Initialized
INFO - 2020-12-28 02:51:07 --> Output Class Initialized
INFO - 2020-12-28 02:51:07 --> Security Class Initialized
DEBUG - 2020-12-28 02:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 02:51:07 --> Input Class Initialized
INFO - 2020-12-28 02:51:07 --> Language Class Initialized
INFO - 2020-12-28 02:51:07 --> Language Class Initialized
INFO - 2020-12-28 02:51:07 --> Config Class Initialized
INFO - 2020-12-28 02:51:07 --> Loader Class Initialized
INFO - 2020-12-28 02:51:07 --> Helper loaded: url_helper
INFO - 2020-12-28 02:51:08 --> Helper loaded: file_helper
INFO - 2020-12-28 02:51:08 --> Helper loaded: form_helper
INFO - 2020-12-28 02:51:08 --> Helper loaded: my_helper
INFO - 2020-12-28 02:51:08 --> Database Driver Class Initialized
DEBUG - 2020-12-28 02:51:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 02:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 02:51:08 --> Controller Class Initialized
INFO - 2020-12-28 02:51:56 --> Config Class Initialized
INFO - 2020-12-28 02:51:56 --> Hooks Class Initialized
DEBUG - 2020-12-28 02:51:56 --> UTF-8 Support Enabled
INFO - 2020-12-28 02:51:56 --> Utf8 Class Initialized
INFO - 2020-12-28 02:51:56 --> URI Class Initialized
INFO - 2020-12-28 02:51:56 --> Router Class Initialized
INFO - 2020-12-28 02:51:56 --> Output Class Initialized
INFO - 2020-12-28 02:51:56 --> Security Class Initialized
DEBUG - 2020-12-28 02:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 02:51:56 --> Input Class Initialized
INFO - 2020-12-28 02:51:56 --> Language Class Initialized
INFO - 2020-12-28 02:51:56 --> Language Class Initialized
INFO - 2020-12-28 02:51:56 --> Config Class Initialized
INFO - 2020-12-28 02:51:56 --> Loader Class Initialized
INFO - 2020-12-28 02:51:57 --> Helper loaded: url_helper
INFO - 2020-12-28 02:51:57 --> Helper loaded: file_helper
INFO - 2020-12-28 02:51:57 --> Helper loaded: form_helper
INFO - 2020-12-28 02:51:57 --> Helper loaded: my_helper
INFO - 2020-12-28 02:51:57 --> Database Driver Class Initialized
DEBUG - 2020-12-28 02:51:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 02:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 02:51:57 --> Controller Class Initialized
INFO - 2020-12-28 02:51:57 --> Final output sent to browser
DEBUG - 2020-12-28 02:51:57 --> Total execution time: 0.8682
INFO - 2020-12-28 02:52:22 --> Config Class Initialized
INFO - 2020-12-28 02:52:22 --> Hooks Class Initialized
DEBUG - 2020-12-28 02:52:22 --> UTF-8 Support Enabled
INFO - 2020-12-28 02:52:22 --> Utf8 Class Initialized
INFO - 2020-12-28 02:52:22 --> URI Class Initialized
INFO - 2020-12-28 02:52:22 --> Router Class Initialized
INFO - 2020-12-28 02:52:22 --> Output Class Initialized
INFO - 2020-12-28 02:52:23 --> Security Class Initialized
DEBUG - 2020-12-28 02:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 02:52:23 --> Input Class Initialized
INFO - 2020-12-28 02:52:23 --> Language Class Initialized
INFO - 2020-12-28 02:52:23 --> Language Class Initialized
INFO - 2020-12-28 02:52:23 --> Config Class Initialized
INFO - 2020-12-28 02:52:23 --> Loader Class Initialized
INFO - 2020-12-28 02:52:23 --> Helper loaded: url_helper
INFO - 2020-12-28 02:52:23 --> Helper loaded: file_helper
INFO - 2020-12-28 02:52:23 --> Helper loaded: form_helper
INFO - 2020-12-28 02:52:23 --> Helper loaded: my_helper
INFO - 2020-12-28 02:52:23 --> Database Driver Class Initialized
DEBUG - 2020-12-28 02:52:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 02:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 02:52:23 --> Controller Class Initialized
INFO - 2020-12-28 02:52:23 --> Final output sent to browser
DEBUG - 2020-12-28 02:52:23 --> Total execution time: 0.7227
INFO - 2020-12-28 02:52:23 --> Config Class Initialized
INFO - 2020-12-28 02:52:23 --> Hooks Class Initialized
DEBUG - 2020-12-28 02:52:23 --> UTF-8 Support Enabled
INFO - 2020-12-28 02:52:23 --> Utf8 Class Initialized
INFO - 2020-12-28 02:52:23 --> URI Class Initialized
INFO - 2020-12-28 02:52:23 --> Router Class Initialized
INFO - 2020-12-28 02:52:23 --> Output Class Initialized
INFO - 2020-12-28 02:52:24 --> Security Class Initialized
DEBUG - 2020-12-28 02:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 02:52:24 --> Input Class Initialized
INFO - 2020-12-28 02:52:24 --> Language Class Initialized
INFO - 2020-12-28 02:52:24 --> Language Class Initialized
INFO - 2020-12-28 02:52:24 --> Config Class Initialized
INFO - 2020-12-28 02:52:24 --> Loader Class Initialized
INFO - 2020-12-28 02:52:24 --> Helper loaded: url_helper
INFO - 2020-12-28 02:52:24 --> Helper loaded: file_helper
INFO - 2020-12-28 02:52:24 --> Helper loaded: form_helper
INFO - 2020-12-28 02:52:24 --> Helper loaded: my_helper
INFO - 2020-12-28 02:52:24 --> Database Driver Class Initialized
DEBUG - 2020-12-28 02:52:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 02:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 02:52:24 --> Controller Class Initialized
INFO - 2020-12-28 02:52:26 --> Config Class Initialized
INFO - 2020-12-28 02:52:26 --> Hooks Class Initialized
DEBUG - 2020-12-28 02:52:26 --> UTF-8 Support Enabled
INFO - 2020-12-28 02:52:26 --> Utf8 Class Initialized
INFO - 2020-12-28 02:52:26 --> URI Class Initialized
INFO - 2020-12-28 02:52:26 --> Router Class Initialized
INFO - 2020-12-28 02:52:26 --> Output Class Initialized
INFO - 2020-12-28 02:52:26 --> Security Class Initialized
DEBUG - 2020-12-28 02:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 02:52:26 --> Input Class Initialized
INFO - 2020-12-28 02:52:26 --> Language Class Initialized
INFO - 2020-12-28 02:52:26 --> Language Class Initialized
INFO - 2020-12-28 02:52:26 --> Config Class Initialized
INFO - 2020-12-28 02:52:26 --> Loader Class Initialized
INFO - 2020-12-28 02:52:27 --> Helper loaded: url_helper
INFO - 2020-12-28 02:52:27 --> Helper loaded: file_helper
INFO - 2020-12-28 02:52:27 --> Helper loaded: form_helper
INFO - 2020-12-28 02:52:27 --> Helper loaded: my_helper
INFO - 2020-12-28 02:52:27 --> Database Driver Class Initialized
DEBUG - 2020-12-28 02:52:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 02:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 02:52:27 --> Controller Class Initialized
INFO - 2020-12-28 02:52:27 --> Final output sent to browser
DEBUG - 2020-12-28 02:52:27 --> Total execution time: 0.7713
INFO - 2020-12-28 02:52:33 --> Config Class Initialized
INFO - 2020-12-28 02:52:33 --> Hooks Class Initialized
DEBUG - 2020-12-28 02:52:33 --> UTF-8 Support Enabled
INFO - 2020-12-28 02:52:33 --> Utf8 Class Initialized
INFO - 2020-12-28 02:52:33 --> URI Class Initialized
INFO - 2020-12-28 02:52:33 --> Router Class Initialized
INFO - 2020-12-28 02:52:33 --> Output Class Initialized
INFO - 2020-12-28 02:52:33 --> Security Class Initialized
DEBUG - 2020-12-28 02:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 02:52:33 --> Input Class Initialized
INFO - 2020-12-28 02:52:33 --> Language Class Initialized
INFO - 2020-12-28 02:52:33 --> Language Class Initialized
INFO - 2020-12-28 02:52:33 --> Config Class Initialized
INFO - 2020-12-28 02:52:33 --> Loader Class Initialized
INFO - 2020-12-28 02:52:33 --> Helper loaded: url_helper
INFO - 2020-12-28 02:52:33 --> Helper loaded: file_helper
INFO - 2020-12-28 02:52:33 --> Helper loaded: form_helper
INFO - 2020-12-28 02:52:33 --> Helper loaded: my_helper
INFO - 2020-12-28 02:52:33 --> Database Driver Class Initialized
DEBUG - 2020-12-28 02:52:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 02:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 02:52:33 --> Controller Class Initialized
INFO - 2020-12-28 02:52:33 --> Final output sent to browser
DEBUG - 2020-12-28 02:52:33 --> Total execution time: 0.7014
INFO - 2020-12-28 02:52:49 --> Config Class Initialized
INFO - 2020-12-28 02:52:49 --> Hooks Class Initialized
DEBUG - 2020-12-28 02:52:49 --> UTF-8 Support Enabled
INFO - 2020-12-28 02:52:49 --> Utf8 Class Initialized
INFO - 2020-12-28 02:52:49 --> URI Class Initialized
INFO - 2020-12-28 02:52:49 --> Router Class Initialized
INFO - 2020-12-28 02:52:49 --> Output Class Initialized
INFO - 2020-12-28 02:52:49 --> Security Class Initialized
DEBUG - 2020-12-28 02:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 02:52:49 --> Input Class Initialized
INFO - 2020-12-28 02:52:49 --> Language Class Initialized
INFO - 2020-12-28 02:52:49 --> Language Class Initialized
INFO - 2020-12-28 02:52:49 --> Config Class Initialized
INFO - 2020-12-28 02:52:49 --> Loader Class Initialized
INFO - 2020-12-28 02:52:49 --> Helper loaded: url_helper
INFO - 2020-12-28 02:52:49 --> Helper loaded: file_helper
INFO - 2020-12-28 02:52:49 --> Helper loaded: form_helper
INFO - 2020-12-28 02:52:49 --> Helper loaded: my_helper
INFO - 2020-12-28 02:52:49 --> Database Driver Class Initialized
DEBUG - 2020-12-28 02:52:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 02:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 02:52:49 --> Controller Class Initialized
INFO - 2020-12-28 02:52:49 --> Final output sent to browser
DEBUG - 2020-12-28 02:52:49 --> Total execution time: 0.6958
INFO - 2020-12-28 02:52:50 --> Config Class Initialized
INFO - 2020-12-28 02:52:50 --> Hooks Class Initialized
DEBUG - 2020-12-28 02:52:50 --> UTF-8 Support Enabled
INFO - 2020-12-28 02:52:50 --> Utf8 Class Initialized
INFO - 2020-12-28 02:52:50 --> URI Class Initialized
INFO - 2020-12-28 02:52:50 --> Router Class Initialized
INFO - 2020-12-28 02:52:50 --> Output Class Initialized
INFO - 2020-12-28 02:52:50 --> Security Class Initialized
DEBUG - 2020-12-28 02:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 02:52:50 --> Input Class Initialized
INFO - 2020-12-28 02:52:50 --> Language Class Initialized
INFO - 2020-12-28 02:52:50 --> Language Class Initialized
INFO - 2020-12-28 02:52:50 --> Config Class Initialized
INFO - 2020-12-28 02:52:50 --> Loader Class Initialized
INFO - 2020-12-28 02:52:50 --> Helper loaded: url_helper
INFO - 2020-12-28 02:52:50 --> Helper loaded: file_helper
INFO - 2020-12-28 02:52:50 --> Helper loaded: form_helper
INFO - 2020-12-28 02:52:50 --> Helper loaded: my_helper
INFO - 2020-12-28 02:52:50 --> Database Driver Class Initialized
DEBUG - 2020-12-28 02:52:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 02:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 02:52:51 --> Controller Class Initialized
INFO - 2020-12-28 02:52:52 --> Config Class Initialized
INFO - 2020-12-28 02:52:52 --> Hooks Class Initialized
DEBUG - 2020-12-28 02:52:52 --> UTF-8 Support Enabled
INFO - 2020-12-28 02:52:52 --> Utf8 Class Initialized
INFO - 2020-12-28 02:52:52 --> URI Class Initialized
INFO - 2020-12-28 02:52:52 --> Router Class Initialized
INFO - 2020-12-28 02:52:52 --> Output Class Initialized
INFO - 2020-12-28 02:52:52 --> Security Class Initialized
DEBUG - 2020-12-28 02:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 02:52:53 --> Input Class Initialized
INFO - 2020-12-28 02:52:53 --> Language Class Initialized
INFO - 2020-12-28 02:52:53 --> Language Class Initialized
INFO - 2020-12-28 02:52:53 --> Config Class Initialized
INFO - 2020-12-28 02:52:53 --> Loader Class Initialized
INFO - 2020-12-28 02:52:53 --> Helper loaded: url_helper
INFO - 2020-12-28 02:52:53 --> Helper loaded: file_helper
INFO - 2020-12-28 02:52:53 --> Helper loaded: form_helper
INFO - 2020-12-28 02:52:53 --> Helper loaded: my_helper
INFO - 2020-12-28 02:52:53 --> Database Driver Class Initialized
DEBUG - 2020-12-28 02:52:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 02:52:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 02:52:53 --> Controller Class Initialized
INFO - 2020-12-28 02:52:53 --> Final output sent to browser
DEBUG - 2020-12-28 02:52:53 --> Total execution time: 0.7278
INFO - 2020-12-28 02:54:56 --> Config Class Initialized
INFO - 2020-12-28 02:54:56 --> Hooks Class Initialized
DEBUG - 2020-12-28 02:54:56 --> UTF-8 Support Enabled
INFO - 2020-12-28 02:54:56 --> Utf8 Class Initialized
INFO - 2020-12-28 02:54:56 --> URI Class Initialized
INFO - 2020-12-28 02:54:56 --> Router Class Initialized
INFO - 2020-12-28 02:54:56 --> Output Class Initialized
INFO - 2020-12-28 02:54:56 --> Security Class Initialized
DEBUG - 2020-12-28 02:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 02:54:56 --> Input Class Initialized
INFO - 2020-12-28 02:54:57 --> Language Class Initialized
INFO - 2020-12-28 02:54:57 --> Language Class Initialized
INFO - 2020-12-28 02:54:57 --> Config Class Initialized
INFO - 2020-12-28 02:54:57 --> Loader Class Initialized
INFO - 2020-12-28 02:54:57 --> Helper loaded: url_helper
INFO - 2020-12-28 02:54:57 --> Helper loaded: file_helper
INFO - 2020-12-28 02:54:57 --> Helper loaded: form_helper
INFO - 2020-12-28 02:54:57 --> Helper loaded: my_helper
INFO - 2020-12-28 02:54:57 --> Database Driver Class Initialized
DEBUG - 2020-12-28 02:54:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 02:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 02:54:57 --> Controller Class Initialized
INFO - 2020-12-28 02:54:57 --> Final output sent to browser
DEBUG - 2020-12-28 02:54:57 --> Total execution time: 0.7017
INFO - 2020-12-28 02:54:57 --> Config Class Initialized
INFO - 2020-12-28 02:54:57 --> Hooks Class Initialized
DEBUG - 2020-12-28 02:54:57 --> UTF-8 Support Enabled
INFO - 2020-12-28 02:54:57 --> Utf8 Class Initialized
INFO - 2020-12-28 02:54:57 --> URI Class Initialized
INFO - 2020-12-28 02:54:57 --> Router Class Initialized
INFO - 2020-12-28 02:54:57 --> Output Class Initialized
INFO - 2020-12-28 02:54:57 --> Security Class Initialized
DEBUG - 2020-12-28 02:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 02:54:57 --> Input Class Initialized
INFO - 2020-12-28 02:54:57 --> Language Class Initialized
INFO - 2020-12-28 02:54:57 --> Language Class Initialized
INFO - 2020-12-28 02:54:57 --> Config Class Initialized
INFO - 2020-12-28 02:54:58 --> Loader Class Initialized
INFO - 2020-12-28 02:54:58 --> Helper loaded: url_helper
INFO - 2020-12-28 02:54:58 --> Helper loaded: file_helper
INFO - 2020-12-28 02:54:58 --> Helper loaded: form_helper
INFO - 2020-12-28 02:54:58 --> Helper loaded: my_helper
INFO - 2020-12-28 02:54:58 --> Database Driver Class Initialized
DEBUG - 2020-12-28 02:54:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 02:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 02:54:58 --> Controller Class Initialized
INFO - 2020-12-28 02:55:00 --> Config Class Initialized
INFO - 2020-12-28 02:55:00 --> Hooks Class Initialized
DEBUG - 2020-12-28 02:55:00 --> UTF-8 Support Enabled
INFO - 2020-12-28 02:55:00 --> Utf8 Class Initialized
INFO - 2020-12-28 02:55:00 --> URI Class Initialized
INFO - 2020-12-28 02:55:00 --> Router Class Initialized
INFO - 2020-12-28 02:55:00 --> Output Class Initialized
INFO - 2020-12-28 02:55:00 --> Security Class Initialized
DEBUG - 2020-12-28 02:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 02:55:00 --> Input Class Initialized
INFO - 2020-12-28 02:55:00 --> Language Class Initialized
INFO - 2020-12-28 02:55:00 --> Language Class Initialized
INFO - 2020-12-28 02:55:00 --> Config Class Initialized
INFO - 2020-12-28 02:55:00 --> Loader Class Initialized
INFO - 2020-12-28 02:55:00 --> Helper loaded: url_helper
INFO - 2020-12-28 02:55:00 --> Helper loaded: file_helper
INFO - 2020-12-28 02:55:00 --> Helper loaded: form_helper
INFO - 2020-12-28 02:55:00 --> Helper loaded: my_helper
INFO - 2020-12-28 02:55:00 --> Database Driver Class Initialized
DEBUG - 2020-12-28 02:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 02:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 02:55:01 --> Controller Class Initialized
INFO - 2020-12-28 02:55:01 --> Final output sent to browser
DEBUG - 2020-12-28 02:55:01 --> Total execution time: 0.8036
INFO - 2020-12-28 02:55:03 --> Config Class Initialized
INFO - 2020-12-28 02:55:03 --> Hooks Class Initialized
DEBUG - 2020-12-28 02:55:03 --> UTF-8 Support Enabled
INFO - 2020-12-28 02:55:03 --> Utf8 Class Initialized
INFO - 2020-12-28 02:55:03 --> URI Class Initialized
INFO - 2020-12-28 02:55:03 --> Router Class Initialized
INFO - 2020-12-28 02:55:04 --> Output Class Initialized
INFO - 2020-12-28 02:55:04 --> Security Class Initialized
DEBUG - 2020-12-28 02:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 02:55:04 --> Input Class Initialized
INFO - 2020-12-28 02:55:04 --> Language Class Initialized
INFO - 2020-12-28 02:55:04 --> Language Class Initialized
INFO - 2020-12-28 02:55:04 --> Config Class Initialized
INFO - 2020-12-28 02:55:04 --> Loader Class Initialized
INFO - 2020-12-28 02:55:04 --> Helper loaded: url_helper
INFO - 2020-12-28 02:55:04 --> Helper loaded: file_helper
INFO - 2020-12-28 02:55:04 --> Helper loaded: form_helper
INFO - 2020-12-28 02:55:04 --> Helper loaded: my_helper
INFO - 2020-12-28 02:55:04 --> Database Driver Class Initialized
DEBUG - 2020-12-28 02:55:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 02:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 02:55:04 --> Controller Class Initialized
INFO - 2020-12-28 02:55:04 --> Final output sent to browser
DEBUG - 2020-12-28 02:55:04 --> Total execution time: 0.9470
INFO - 2020-12-28 02:55:08 --> Config Class Initialized
INFO - 2020-12-28 02:55:08 --> Hooks Class Initialized
DEBUG - 2020-12-28 02:55:08 --> UTF-8 Support Enabled
INFO - 2020-12-28 02:55:08 --> Utf8 Class Initialized
INFO - 2020-12-28 02:55:08 --> URI Class Initialized
INFO - 2020-12-28 02:55:08 --> Router Class Initialized
INFO - 2020-12-28 02:55:08 --> Output Class Initialized
INFO - 2020-12-28 02:55:08 --> Security Class Initialized
DEBUG - 2020-12-28 02:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 02:55:08 --> Input Class Initialized
INFO - 2020-12-28 02:55:08 --> Language Class Initialized
INFO - 2020-12-28 02:55:09 --> Language Class Initialized
INFO - 2020-12-28 02:55:09 --> Config Class Initialized
INFO - 2020-12-28 02:55:09 --> Loader Class Initialized
INFO - 2020-12-28 02:55:09 --> Helper loaded: url_helper
INFO - 2020-12-28 02:55:09 --> Helper loaded: file_helper
INFO - 2020-12-28 02:55:09 --> Helper loaded: form_helper
INFO - 2020-12-28 02:55:09 --> Helper loaded: my_helper
INFO - 2020-12-28 02:55:09 --> Database Driver Class Initialized
DEBUG - 2020-12-28 02:55:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 02:55:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 02:55:09 --> Controller Class Initialized
INFO - 2020-12-28 02:55:09 --> Final output sent to browser
DEBUG - 2020-12-28 02:55:09 --> Total execution time: 0.8210
INFO - 2020-12-28 02:55:43 --> Config Class Initialized
INFO - 2020-12-28 02:55:43 --> Hooks Class Initialized
DEBUG - 2020-12-28 02:55:43 --> UTF-8 Support Enabled
INFO - 2020-12-28 02:55:43 --> Utf8 Class Initialized
INFO - 2020-12-28 02:55:43 --> URI Class Initialized
INFO - 2020-12-28 02:55:43 --> Router Class Initialized
INFO - 2020-12-28 02:55:43 --> Output Class Initialized
INFO - 2020-12-28 02:55:43 --> Security Class Initialized
DEBUG - 2020-12-28 02:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 02:55:43 --> Input Class Initialized
INFO - 2020-12-28 02:55:43 --> Language Class Initialized
INFO - 2020-12-28 02:55:43 --> Language Class Initialized
INFO - 2020-12-28 02:55:43 --> Config Class Initialized
INFO - 2020-12-28 02:55:44 --> Loader Class Initialized
INFO - 2020-12-28 02:55:44 --> Helper loaded: url_helper
INFO - 2020-12-28 02:55:44 --> Helper loaded: file_helper
INFO - 2020-12-28 02:55:44 --> Helper loaded: form_helper
INFO - 2020-12-28 02:55:44 --> Helper loaded: my_helper
INFO - 2020-12-28 02:55:44 --> Database Driver Class Initialized
DEBUG - 2020-12-28 02:55:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 02:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 02:55:44 --> Controller Class Initialized
INFO - 2020-12-28 02:55:44 --> Final output sent to browser
DEBUG - 2020-12-28 02:55:44 --> Total execution time: 0.7020
INFO - 2020-12-28 02:55:44 --> Config Class Initialized
INFO - 2020-12-28 02:55:44 --> Hooks Class Initialized
DEBUG - 2020-12-28 02:55:44 --> UTF-8 Support Enabled
INFO - 2020-12-28 02:55:44 --> Utf8 Class Initialized
INFO - 2020-12-28 02:55:44 --> URI Class Initialized
INFO - 2020-12-28 02:55:44 --> Router Class Initialized
INFO - 2020-12-28 02:55:44 --> Output Class Initialized
INFO - 2020-12-28 02:55:44 --> Security Class Initialized
DEBUG - 2020-12-28 02:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 02:55:44 --> Input Class Initialized
INFO - 2020-12-28 02:55:44 --> Language Class Initialized
INFO - 2020-12-28 02:55:44 --> Language Class Initialized
INFO - 2020-12-28 02:55:44 --> Config Class Initialized
INFO - 2020-12-28 02:55:44 --> Loader Class Initialized
INFO - 2020-12-28 02:55:44 --> Helper loaded: url_helper
INFO - 2020-12-28 02:55:44 --> Helper loaded: file_helper
INFO - 2020-12-28 02:55:44 --> Helper loaded: form_helper
INFO - 2020-12-28 02:55:44 --> Helper loaded: my_helper
INFO - 2020-12-28 02:55:45 --> Database Driver Class Initialized
DEBUG - 2020-12-28 02:55:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 02:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 02:55:45 --> Controller Class Initialized
INFO - 2020-12-28 02:56:06 --> Config Class Initialized
INFO - 2020-12-28 02:56:06 --> Hooks Class Initialized
DEBUG - 2020-12-28 02:56:06 --> UTF-8 Support Enabled
INFO - 2020-12-28 02:56:06 --> Utf8 Class Initialized
INFO - 2020-12-28 02:56:06 --> URI Class Initialized
INFO - 2020-12-28 02:56:06 --> Router Class Initialized
INFO - 2020-12-28 02:56:06 --> Output Class Initialized
INFO - 2020-12-28 02:56:06 --> Security Class Initialized
DEBUG - 2020-12-28 02:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 02:56:06 --> Input Class Initialized
INFO - 2020-12-28 02:56:06 --> Language Class Initialized
INFO - 2020-12-28 02:56:06 --> Language Class Initialized
INFO - 2020-12-28 02:56:06 --> Config Class Initialized
INFO - 2020-12-28 02:56:06 --> Loader Class Initialized
INFO - 2020-12-28 02:56:06 --> Helper loaded: url_helper
INFO - 2020-12-28 02:56:06 --> Helper loaded: file_helper
INFO - 2020-12-28 02:56:07 --> Helper loaded: form_helper
INFO - 2020-12-28 02:56:07 --> Helper loaded: my_helper
INFO - 2020-12-28 02:56:07 --> Database Driver Class Initialized
DEBUG - 2020-12-28 02:56:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 02:56:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 02:56:07 --> Controller Class Initialized
INFO - 2020-12-28 02:56:07 --> Final output sent to browser
DEBUG - 2020-12-28 02:56:07 --> Total execution time: 0.8936
INFO - 2020-12-28 02:56:20 --> Config Class Initialized
INFO - 2020-12-28 02:56:20 --> Hooks Class Initialized
DEBUG - 2020-12-28 02:56:20 --> UTF-8 Support Enabled
INFO - 2020-12-28 02:56:20 --> Utf8 Class Initialized
INFO - 2020-12-28 02:56:20 --> URI Class Initialized
INFO - 2020-12-28 02:56:20 --> Router Class Initialized
INFO - 2020-12-28 02:56:20 --> Output Class Initialized
INFO - 2020-12-28 02:56:20 --> Security Class Initialized
DEBUG - 2020-12-28 02:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 02:56:20 --> Input Class Initialized
INFO - 2020-12-28 02:56:20 --> Language Class Initialized
INFO - 2020-12-28 02:56:20 --> Language Class Initialized
INFO - 2020-12-28 02:56:20 --> Config Class Initialized
INFO - 2020-12-28 02:56:20 --> Loader Class Initialized
INFO - 2020-12-28 02:56:21 --> Helper loaded: url_helper
INFO - 2020-12-28 02:56:21 --> Helper loaded: file_helper
INFO - 2020-12-28 02:56:21 --> Helper loaded: form_helper
INFO - 2020-12-28 02:56:21 --> Helper loaded: my_helper
INFO - 2020-12-28 02:56:21 --> Database Driver Class Initialized
DEBUG - 2020-12-28 02:56:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 02:56:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 02:56:21 --> Controller Class Initialized
INFO - 2020-12-28 02:56:21 --> Final output sent to browser
DEBUG - 2020-12-28 02:56:21 --> Total execution time: 0.8039
INFO - 2020-12-28 02:56:21 --> Config Class Initialized
INFO - 2020-12-28 02:56:21 --> Hooks Class Initialized
DEBUG - 2020-12-28 02:56:21 --> UTF-8 Support Enabled
INFO - 2020-12-28 02:56:21 --> Utf8 Class Initialized
INFO - 2020-12-28 02:56:21 --> URI Class Initialized
INFO - 2020-12-28 02:56:21 --> Router Class Initialized
INFO - 2020-12-28 02:56:21 --> Output Class Initialized
INFO - 2020-12-28 02:56:21 --> Security Class Initialized
DEBUG - 2020-12-28 02:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 02:56:22 --> Input Class Initialized
INFO - 2020-12-28 02:56:22 --> Language Class Initialized
INFO - 2020-12-28 02:56:22 --> Language Class Initialized
INFO - 2020-12-28 02:56:22 --> Config Class Initialized
INFO - 2020-12-28 02:56:22 --> Loader Class Initialized
INFO - 2020-12-28 02:56:22 --> Helper loaded: url_helper
INFO - 2020-12-28 02:56:22 --> Helper loaded: file_helper
INFO - 2020-12-28 02:56:22 --> Helper loaded: form_helper
INFO - 2020-12-28 02:56:22 --> Helper loaded: my_helper
INFO - 2020-12-28 02:56:22 --> Database Driver Class Initialized
DEBUG - 2020-12-28 02:56:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 02:56:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 02:56:22 --> Controller Class Initialized
INFO - 2020-12-28 02:59:17 --> Config Class Initialized
INFO - 2020-12-28 02:59:17 --> Hooks Class Initialized
DEBUG - 2020-12-28 02:59:17 --> UTF-8 Support Enabled
INFO - 2020-12-28 02:59:17 --> Utf8 Class Initialized
INFO - 2020-12-28 02:59:17 --> URI Class Initialized
INFO - 2020-12-28 02:59:17 --> Router Class Initialized
INFO - 2020-12-28 02:59:17 --> Output Class Initialized
INFO - 2020-12-28 02:59:17 --> Security Class Initialized
DEBUG - 2020-12-28 02:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 02:59:17 --> Input Class Initialized
INFO - 2020-12-28 02:59:17 --> Language Class Initialized
INFO - 2020-12-28 02:59:17 --> Language Class Initialized
INFO - 2020-12-28 02:59:17 --> Config Class Initialized
INFO - 2020-12-28 02:59:17 --> Loader Class Initialized
INFO - 2020-12-28 02:59:17 --> Helper loaded: url_helper
INFO - 2020-12-28 02:59:17 --> Helper loaded: file_helper
INFO - 2020-12-28 02:59:17 --> Helper loaded: form_helper
INFO - 2020-12-28 02:59:17 --> Helper loaded: my_helper
INFO - 2020-12-28 02:59:17 --> Database Driver Class Initialized
DEBUG - 2020-12-28 02:59:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 02:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 02:59:17 --> Controller Class Initialized
INFO - 2020-12-28 02:59:17 --> Final output sent to browser
DEBUG - 2020-12-28 02:59:18 --> Total execution time: 0.7642
INFO - 2020-12-28 02:59:34 --> Config Class Initialized
INFO - 2020-12-28 02:59:34 --> Hooks Class Initialized
DEBUG - 2020-12-28 02:59:34 --> UTF-8 Support Enabled
INFO - 2020-12-28 02:59:34 --> Utf8 Class Initialized
INFO - 2020-12-28 02:59:34 --> URI Class Initialized
INFO - 2020-12-28 02:59:34 --> Router Class Initialized
INFO - 2020-12-28 02:59:34 --> Output Class Initialized
INFO - 2020-12-28 02:59:34 --> Security Class Initialized
DEBUG - 2020-12-28 02:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 02:59:34 --> Input Class Initialized
INFO - 2020-12-28 02:59:34 --> Language Class Initialized
INFO - 2020-12-28 02:59:34 --> Language Class Initialized
INFO - 2020-12-28 02:59:34 --> Config Class Initialized
INFO - 2020-12-28 02:59:34 --> Loader Class Initialized
INFO - 2020-12-28 02:59:34 --> Helper loaded: url_helper
INFO - 2020-12-28 02:59:34 --> Helper loaded: file_helper
INFO - 2020-12-28 02:59:34 --> Helper loaded: form_helper
INFO - 2020-12-28 02:59:34 --> Helper loaded: my_helper
INFO - 2020-12-28 02:59:34 --> Database Driver Class Initialized
DEBUG - 2020-12-28 02:59:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 02:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 02:59:34 --> Controller Class Initialized
INFO - 2020-12-28 02:59:34 --> Final output sent to browser
DEBUG - 2020-12-28 02:59:34 --> Total execution time: 0.8259
INFO - 2020-12-28 02:59:35 --> Config Class Initialized
INFO - 2020-12-28 02:59:35 --> Hooks Class Initialized
DEBUG - 2020-12-28 02:59:35 --> UTF-8 Support Enabled
INFO - 2020-12-28 02:59:35 --> Utf8 Class Initialized
INFO - 2020-12-28 02:59:35 --> URI Class Initialized
INFO - 2020-12-28 02:59:35 --> Router Class Initialized
INFO - 2020-12-28 02:59:35 --> Output Class Initialized
INFO - 2020-12-28 02:59:35 --> Security Class Initialized
DEBUG - 2020-12-28 02:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 02:59:35 --> Input Class Initialized
INFO - 2020-12-28 02:59:35 --> Language Class Initialized
INFO - 2020-12-28 02:59:35 --> Language Class Initialized
INFO - 2020-12-28 02:59:35 --> Config Class Initialized
INFO - 2020-12-28 02:59:35 --> Loader Class Initialized
INFO - 2020-12-28 02:59:35 --> Helper loaded: url_helper
INFO - 2020-12-28 02:59:35 --> Helper loaded: file_helper
INFO - 2020-12-28 02:59:35 --> Helper loaded: form_helper
INFO - 2020-12-28 02:59:35 --> Helper loaded: my_helper
INFO - 2020-12-28 02:59:35 --> Database Driver Class Initialized
DEBUG - 2020-12-28 02:59:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 02:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 02:59:35 --> Controller Class Initialized
INFO - 2020-12-28 02:59:43 --> Config Class Initialized
INFO - 2020-12-28 02:59:43 --> Hooks Class Initialized
DEBUG - 2020-12-28 02:59:43 --> UTF-8 Support Enabled
INFO - 2020-12-28 02:59:43 --> Utf8 Class Initialized
INFO - 2020-12-28 02:59:43 --> URI Class Initialized
INFO - 2020-12-28 02:59:43 --> Router Class Initialized
INFO - 2020-12-28 02:59:43 --> Output Class Initialized
INFO - 2020-12-28 02:59:43 --> Security Class Initialized
DEBUG - 2020-12-28 02:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 02:59:43 --> Input Class Initialized
INFO - 2020-12-28 02:59:43 --> Language Class Initialized
INFO - 2020-12-28 02:59:43 --> Language Class Initialized
INFO - 2020-12-28 02:59:43 --> Config Class Initialized
INFO - 2020-12-28 02:59:43 --> Loader Class Initialized
INFO - 2020-12-28 02:59:43 --> Helper loaded: url_helper
INFO - 2020-12-28 02:59:44 --> Helper loaded: file_helper
INFO - 2020-12-28 02:59:44 --> Helper loaded: form_helper
INFO - 2020-12-28 02:59:44 --> Helper loaded: my_helper
INFO - 2020-12-28 02:59:44 --> Database Driver Class Initialized
DEBUG - 2020-12-28 02:59:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 02:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 02:59:44 --> Controller Class Initialized
INFO - 2020-12-28 02:59:44 --> Final output sent to browser
DEBUG - 2020-12-28 02:59:44 --> Total execution time: 0.7690
INFO - 2020-12-28 02:59:56 --> Config Class Initialized
INFO - 2020-12-28 02:59:56 --> Hooks Class Initialized
DEBUG - 2020-12-28 02:59:56 --> UTF-8 Support Enabled
INFO - 2020-12-28 02:59:56 --> Utf8 Class Initialized
INFO - 2020-12-28 02:59:56 --> URI Class Initialized
INFO - 2020-12-28 02:59:57 --> Router Class Initialized
INFO - 2020-12-28 02:59:57 --> Output Class Initialized
INFO - 2020-12-28 02:59:57 --> Security Class Initialized
DEBUG - 2020-12-28 02:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 02:59:57 --> Input Class Initialized
INFO - 2020-12-28 02:59:57 --> Language Class Initialized
INFO - 2020-12-28 02:59:57 --> Language Class Initialized
INFO - 2020-12-28 02:59:57 --> Config Class Initialized
INFO - 2020-12-28 02:59:57 --> Loader Class Initialized
INFO - 2020-12-28 02:59:57 --> Helper loaded: url_helper
INFO - 2020-12-28 02:59:57 --> Helper loaded: file_helper
INFO - 2020-12-28 02:59:57 --> Helper loaded: form_helper
INFO - 2020-12-28 02:59:57 --> Helper loaded: my_helper
INFO - 2020-12-28 02:59:57 --> Database Driver Class Initialized
DEBUG - 2020-12-28 02:59:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 02:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 02:59:57 --> Controller Class Initialized
INFO - 2020-12-28 02:59:57 --> Final output sent to browser
DEBUG - 2020-12-28 02:59:57 --> Total execution time: 0.8390
INFO - 2020-12-28 02:59:57 --> Config Class Initialized
INFO - 2020-12-28 02:59:57 --> Hooks Class Initialized
DEBUG - 2020-12-28 02:59:57 --> UTF-8 Support Enabled
INFO - 2020-12-28 02:59:58 --> Utf8 Class Initialized
INFO - 2020-12-28 02:59:58 --> URI Class Initialized
INFO - 2020-12-28 02:59:58 --> Router Class Initialized
INFO - 2020-12-28 02:59:58 --> Output Class Initialized
INFO - 2020-12-28 02:59:58 --> Security Class Initialized
DEBUG - 2020-12-28 02:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 02:59:58 --> Input Class Initialized
INFO - 2020-12-28 02:59:58 --> Language Class Initialized
INFO - 2020-12-28 02:59:58 --> Language Class Initialized
INFO - 2020-12-28 02:59:58 --> Config Class Initialized
INFO - 2020-12-28 02:59:58 --> Loader Class Initialized
INFO - 2020-12-28 02:59:58 --> Helper loaded: url_helper
INFO - 2020-12-28 02:59:58 --> Helper loaded: file_helper
INFO - 2020-12-28 02:59:58 --> Helper loaded: form_helper
INFO - 2020-12-28 02:59:58 --> Helper loaded: my_helper
INFO - 2020-12-28 02:59:58 --> Database Driver Class Initialized
DEBUG - 2020-12-28 02:59:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 02:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 02:59:58 --> Controller Class Initialized
INFO - 2020-12-28 03:00:00 --> Config Class Initialized
INFO - 2020-12-28 03:00:00 --> Hooks Class Initialized
DEBUG - 2020-12-28 03:00:00 --> UTF-8 Support Enabled
INFO - 2020-12-28 03:00:00 --> Utf8 Class Initialized
INFO - 2020-12-28 03:00:00 --> URI Class Initialized
INFO - 2020-12-28 03:00:00 --> Router Class Initialized
INFO - 2020-12-28 03:00:00 --> Output Class Initialized
INFO - 2020-12-28 03:00:00 --> Security Class Initialized
DEBUG - 2020-12-28 03:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 03:00:00 --> Input Class Initialized
INFO - 2020-12-28 03:00:00 --> Language Class Initialized
INFO - 2020-12-28 03:00:00 --> Language Class Initialized
INFO - 2020-12-28 03:00:00 --> Config Class Initialized
INFO - 2020-12-28 03:00:00 --> Loader Class Initialized
INFO - 2020-12-28 03:00:00 --> Helper loaded: url_helper
INFO - 2020-12-28 03:00:00 --> Helper loaded: file_helper
INFO - 2020-12-28 03:00:00 --> Helper loaded: form_helper
INFO - 2020-12-28 03:00:00 --> Helper loaded: my_helper
INFO - 2020-12-28 03:00:00 --> Database Driver Class Initialized
DEBUG - 2020-12-28 03:00:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 03:00:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 03:00:01 --> Controller Class Initialized
INFO - 2020-12-28 03:00:01 --> Final output sent to browser
DEBUG - 2020-12-28 03:00:01 --> Total execution time: 0.8512
INFO - 2020-12-28 03:00:05 --> Config Class Initialized
INFO - 2020-12-28 03:00:05 --> Hooks Class Initialized
DEBUG - 2020-12-28 03:00:05 --> UTF-8 Support Enabled
INFO - 2020-12-28 03:00:05 --> Utf8 Class Initialized
INFO - 2020-12-28 03:00:05 --> URI Class Initialized
INFO - 2020-12-28 03:00:05 --> Router Class Initialized
INFO - 2020-12-28 03:00:05 --> Output Class Initialized
INFO - 2020-12-28 03:00:05 --> Security Class Initialized
DEBUG - 2020-12-28 03:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 03:00:05 --> Input Class Initialized
INFO - 2020-12-28 03:00:05 --> Language Class Initialized
INFO - 2020-12-28 03:00:05 --> Language Class Initialized
INFO - 2020-12-28 03:00:05 --> Config Class Initialized
INFO - 2020-12-28 03:00:05 --> Loader Class Initialized
INFO - 2020-12-28 03:00:05 --> Helper loaded: url_helper
INFO - 2020-12-28 03:00:05 --> Helper loaded: file_helper
INFO - 2020-12-28 03:00:05 --> Helper loaded: form_helper
INFO - 2020-12-28 03:00:05 --> Helper loaded: my_helper
INFO - 2020-12-28 03:00:05 --> Database Driver Class Initialized
DEBUG - 2020-12-28 03:00:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 03:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 03:00:05 --> Controller Class Initialized
INFO - 2020-12-28 03:00:06 --> Final output sent to browser
DEBUG - 2020-12-28 03:00:06 --> Total execution time: 0.8494
INFO - 2020-12-28 03:00:45 --> Config Class Initialized
INFO - 2020-12-28 03:00:45 --> Hooks Class Initialized
DEBUG - 2020-12-28 03:00:45 --> UTF-8 Support Enabled
INFO - 2020-12-28 03:00:45 --> Utf8 Class Initialized
INFO - 2020-12-28 03:00:45 --> URI Class Initialized
INFO - 2020-12-28 03:00:45 --> Router Class Initialized
INFO - 2020-12-28 03:00:45 --> Output Class Initialized
INFO - 2020-12-28 03:00:45 --> Security Class Initialized
DEBUG - 2020-12-28 03:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 03:00:45 --> Input Class Initialized
INFO - 2020-12-28 03:00:45 --> Language Class Initialized
INFO - 2020-12-28 03:00:45 --> Language Class Initialized
INFO - 2020-12-28 03:00:45 --> Config Class Initialized
INFO - 2020-12-28 03:00:45 --> Loader Class Initialized
INFO - 2020-12-28 03:00:45 --> Helper loaded: url_helper
INFO - 2020-12-28 03:00:45 --> Helper loaded: file_helper
INFO - 2020-12-28 03:00:45 --> Helper loaded: form_helper
INFO - 2020-12-28 03:00:45 --> Helper loaded: my_helper
INFO - 2020-12-28 03:00:45 --> Database Driver Class Initialized
DEBUG - 2020-12-28 03:00:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 03:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 03:00:46 --> Controller Class Initialized
INFO - 2020-12-28 03:00:46 --> Final output sent to browser
DEBUG - 2020-12-28 03:00:46 --> Total execution time: 0.7758
INFO - 2020-12-28 03:00:46 --> Config Class Initialized
INFO - 2020-12-28 03:00:46 --> Hooks Class Initialized
DEBUG - 2020-12-28 03:00:46 --> UTF-8 Support Enabled
INFO - 2020-12-28 03:00:46 --> Utf8 Class Initialized
INFO - 2020-12-28 03:00:46 --> URI Class Initialized
INFO - 2020-12-28 03:00:46 --> Router Class Initialized
INFO - 2020-12-28 03:00:46 --> Output Class Initialized
INFO - 2020-12-28 03:00:46 --> Security Class Initialized
DEBUG - 2020-12-28 03:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 03:00:46 --> Input Class Initialized
INFO - 2020-12-28 03:00:46 --> Language Class Initialized
INFO - 2020-12-28 03:00:46 --> Language Class Initialized
INFO - 2020-12-28 03:00:46 --> Config Class Initialized
INFO - 2020-12-28 03:00:46 --> Loader Class Initialized
INFO - 2020-12-28 03:00:46 --> Helper loaded: url_helper
INFO - 2020-12-28 03:00:46 --> Helper loaded: file_helper
INFO - 2020-12-28 03:00:46 --> Helper loaded: form_helper
INFO - 2020-12-28 03:00:46 --> Helper loaded: my_helper
INFO - 2020-12-28 03:00:46 --> Database Driver Class Initialized
DEBUG - 2020-12-28 03:00:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 03:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 03:00:47 --> Controller Class Initialized
INFO - 2020-12-28 03:00:53 --> Config Class Initialized
INFO - 2020-12-28 03:00:53 --> Hooks Class Initialized
DEBUG - 2020-12-28 03:00:53 --> UTF-8 Support Enabled
INFO - 2020-12-28 03:00:53 --> Utf8 Class Initialized
INFO - 2020-12-28 03:00:53 --> URI Class Initialized
INFO - 2020-12-28 03:00:53 --> Router Class Initialized
INFO - 2020-12-28 03:00:53 --> Output Class Initialized
INFO - 2020-12-28 03:00:53 --> Security Class Initialized
DEBUG - 2020-12-28 03:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 03:00:53 --> Input Class Initialized
INFO - 2020-12-28 03:00:53 --> Language Class Initialized
INFO - 2020-12-28 03:00:53 --> Language Class Initialized
INFO - 2020-12-28 03:00:53 --> Config Class Initialized
INFO - 2020-12-28 03:00:53 --> Loader Class Initialized
INFO - 2020-12-28 03:00:53 --> Helper loaded: url_helper
INFO - 2020-12-28 03:00:53 --> Helper loaded: file_helper
INFO - 2020-12-28 03:00:53 --> Helper loaded: form_helper
INFO - 2020-12-28 03:00:53 --> Helper loaded: my_helper
INFO - 2020-12-28 03:00:54 --> Database Driver Class Initialized
DEBUG - 2020-12-28 03:00:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 03:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 03:00:54 --> Controller Class Initialized
INFO - 2020-12-28 03:00:54 --> Final output sent to browser
DEBUG - 2020-12-28 03:00:54 --> Total execution time: 0.9132
INFO - 2020-12-28 03:00:56 --> Config Class Initialized
INFO - 2020-12-28 03:00:56 --> Hooks Class Initialized
DEBUG - 2020-12-28 03:00:56 --> UTF-8 Support Enabled
INFO - 2020-12-28 03:00:56 --> Utf8 Class Initialized
INFO - 2020-12-28 03:00:56 --> URI Class Initialized
INFO - 2020-12-28 03:00:56 --> Router Class Initialized
INFO - 2020-12-28 03:00:56 --> Output Class Initialized
INFO - 2020-12-28 03:00:56 --> Security Class Initialized
DEBUG - 2020-12-28 03:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 03:00:56 --> Input Class Initialized
INFO - 2020-12-28 03:00:56 --> Language Class Initialized
INFO - 2020-12-28 03:00:56 --> Language Class Initialized
INFO - 2020-12-28 03:00:56 --> Config Class Initialized
INFO - 2020-12-28 03:00:56 --> Loader Class Initialized
INFO - 2020-12-28 03:00:57 --> Helper loaded: url_helper
INFO - 2020-12-28 03:00:57 --> Helper loaded: file_helper
INFO - 2020-12-28 03:00:57 --> Helper loaded: form_helper
INFO - 2020-12-28 03:00:57 --> Helper loaded: my_helper
INFO - 2020-12-28 03:00:57 --> Database Driver Class Initialized
DEBUG - 2020-12-28 03:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 03:00:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 03:00:57 --> Controller Class Initialized
INFO - 2020-12-28 03:00:57 --> Final output sent to browser
DEBUG - 2020-12-28 03:00:57 --> Total execution time: 0.5918
INFO - 2020-12-28 03:01:51 --> Config Class Initialized
INFO - 2020-12-28 03:01:51 --> Hooks Class Initialized
DEBUG - 2020-12-28 03:01:51 --> UTF-8 Support Enabled
INFO - 2020-12-28 03:01:51 --> Utf8 Class Initialized
INFO - 2020-12-28 03:01:51 --> URI Class Initialized
INFO - 2020-12-28 03:01:51 --> Router Class Initialized
INFO - 2020-12-28 03:01:51 --> Output Class Initialized
INFO - 2020-12-28 03:01:51 --> Security Class Initialized
DEBUG - 2020-12-28 03:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 03:01:51 --> Input Class Initialized
INFO - 2020-12-28 03:01:51 --> Language Class Initialized
INFO - 2020-12-28 03:01:51 --> Language Class Initialized
INFO - 2020-12-28 03:01:51 --> Config Class Initialized
INFO - 2020-12-28 03:01:51 --> Loader Class Initialized
INFO - 2020-12-28 03:01:51 --> Helper loaded: url_helper
INFO - 2020-12-28 03:01:52 --> Helper loaded: file_helper
INFO - 2020-12-28 03:01:52 --> Helper loaded: form_helper
INFO - 2020-12-28 03:01:52 --> Helper loaded: my_helper
INFO - 2020-12-28 03:01:52 --> Database Driver Class Initialized
DEBUG - 2020-12-28 03:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 03:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 03:01:52 --> Controller Class Initialized
INFO - 2020-12-28 03:01:52 --> Final output sent to browser
DEBUG - 2020-12-28 03:01:52 --> Total execution time: 0.8707
INFO - 2020-12-28 03:01:52 --> Config Class Initialized
INFO - 2020-12-28 03:01:52 --> Hooks Class Initialized
DEBUG - 2020-12-28 03:01:52 --> UTF-8 Support Enabled
INFO - 2020-12-28 03:01:52 --> Utf8 Class Initialized
INFO - 2020-12-28 03:01:52 --> URI Class Initialized
INFO - 2020-12-28 03:01:52 --> Router Class Initialized
INFO - 2020-12-28 03:01:52 --> Output Class Initialized
INFO - 2020-12-28 03:01:52 --> Security Class Initialized
DEBUG - 2020-12-28 03:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 03:01:52 --> Input Class Initialized
INFO - 2020-12-28 03:01:52 --> Language Class Initialized
INFO - 2020-12-28 03:01:52 --> Language Class Initialized
INFO - 2020-12-28 03:01:52 --> Config Class Initialized
INFO - 2020-12-28 03:01:52 --> Loader Class Initialized
INFO - 2020-12-28 03:01:53 --> Helper loaded: url_helper
INFO - 2020-12-28 03:01:53 --> Helper loaded: file_helper
INFO - 2020-12-28 03:01:53 --> Helper loaded: form_helper
INFO - 2020-12-28 03:01:53 --> Helper loaded: my_helper
INFO - 2020-12-28 03:01:53 --> Database Driver Class Initialized
DEBUG - 2020-12-28 03:01:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 03:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 03:01:53 --> Controller Class Initialized
INFO - 2020-12-28 03:02:01 --> Config Class Initialized
INFO - 2020-12-28 03:02:01 --> Hooks Class Initialized
DEBUG - 2020-12-28 03:02:01 --> UTF-8 Support Enabled
INFO - 2020-12-28 03:02:01 --> Utf8 Class Initialized
INFO - 2020-12-28 03:02:01 --> URI Class Initialized
INFO - 2020-12-28 03:02:01 --> Router Class Initialized
INFO - 2020-12-28 03:02:01 --> Output Class Initialized
INFO - 2020-12-28 03:02:01 --> Security Class Initialized
DEBUG - 2020-12-28 03:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 03:02:01 --> Input Class Initialized
INFO - 2020-12-28 03:02:02 --> Language Class Initialized
INFO - 2020-12-28 03:02:02 --> Language Class Initialized
INFO - 2020-12-28 03:02:02 --> Config Class Initialized
INFO - 2020-12-28 03:02:02 --> Loader Class Initialized
INFO - 2020-12-28 03:02:02 --> Helper loaded: url_helper
INFO - 2020-12-28 03:02:02 --> Helper loaded: file_helper
INFO - 2020-12-28 03:02:02 --> Helper loaded: form_helper
INFO - 2020-12-28 03:02:02 --> Helper loaded: my_helper
INFO - 2020-12-28 03:02:02 --> Database Driver Class Initialized
DEBUG - 2020-12-28 03:02:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 03:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 03:02:02 --> Controller Class Initialized
INFO - 2020-12-28 03:02:02 --> Final output sent to browser
DEBUG - 2020-12-28 03:02:02 --> Total execution time: 0.8298
INFO - 2020-12-28 03:02:16 --> Config Class Initialized
INFO - 2020-12-28 03:02:16 --> Hooks Class Initialized
DEBUG - 2020-12-28 03:02:16 --> UTF-8 Support Enabled
INFO - 2020-12-28 03:02:16 --> Utf8 Class Initialized
INFO - 2020-12-28 03:02:16 --> URI Class Initialized
INFO - 2020-12-28 03:02:16 --> Router Class Initialized
INFO - 2020-12-28 03:02:16 --> Output Class Initialized
INFO - 2020-12-28 03:02:16 --> Security Class Initialized
DEBUG - 2020-12-28 03:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 03:02:16 --> Input Class Initialized
INFO - 2020-12-28 03:02:16 --> Language Class Initialized
INFO - 2020-12-28 03:02:17 --> Language Class Initialized
INFO - 2020-12-28 03:02:17 --> Config Class Initialized
INFO - 2020-12-28 03:02:17 --> Loader Class Initialized
INFO - 2020-12-28 03:02:17 --> Helper loaded: url_helper
INFO - 2020-12-28 03:02:17 --> Helper loaded: file_helper
INFO - 2020-12-28 03:02:17 --> Helper loaded: form_helper
INFO - 2020-12-28 03:02:17 --> Helper loaded: my_helper
INFO - 2020-12-28 03:02:17 --> Database Driver Class Initialized
DEBUG - 2020-12-28 03:02:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 03:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 03:02:17 --> Controller Class Initialized
INFO - 2020-12-28 03:02:17 --> Final output sent to browser
DEBUG - 2020-12-28 03:02:17 --> Total execution time: 0.8580
INFO - 2020-12-28 03:02:17 --> Config Class Initialized
INFO - 2020-12-28 03:02:17 --> Hooks Class Initialized
DEBUG - 2020-12-28 03:02:17 --> UTF-8 Support Enabled
INFO - 2020-12-28 03:02:17 --> Utf8 Class Initialized
INFO - 2020-12-28 03:02:17 --> URI Class Initialized
INFO - 2020-12-28 03:02:18 --> Router Class Initialized
INFO - 2020-12-28 03:02:18 --> Output Class Initialized
INFO - 2020-12-28 03:02:18 --> Security Class Initialized
DEBUG - 2020-12-28 03:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 03:02:18 --> Input Class Initialized
INFO - 2020-12-28 03:02:18 --> Language Class Initialized
INFO - 2020-12-28 03:02:18 --> Language Class Initialized
INFO - 2020-12-28 03:02:18 --> Config Class Initialized
INFO - 2020-12-28 03:02:18 --> Loader Class Initialized
INFO - 2020-12-28 03:02:18 --> Helper loaded: url_helper
INFO - 2020-12-28 03:02:18 --> Helper loaded: file_helper
INFO - 2020-12-28 03:02:18 --> Helper loaded: form_helper
INFO - 2020-12-28 03:02:18 --> Helper loaded: my_helper
INFO - 2020-12-28 03:02:18 --> Database Driver Class Initialized
DEBUG - 2020-12-28 03:02:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 03:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 03:02:18 --> Controller Class Initialized
INFO - 2020-12-28 03:02:20 --> Config Class Initialized
INFO - 2020-12-28 03:02:21 --> Hooks Class Initialized
DEBUG - 2020-12-28 03:02:21 --> UTF-8 Support Enabled
INFO - 2020-12-28 03:02:21 --> Utf8 Class Initialized
INFO - 2020-12-28 03:02:21 --> URI Class Initialized
INFO - 2020-12-28 03:02:21 --> Router Class Initialized
INFO - 2020-12-28 03:02:21 --> Output Class Initialized
INFO - 2020-12-28 03:02:21 --> Security Class Initialized
DEBUG - 2020-12-28 03:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 03:02:21 --> Input Class Initialized
INFO - 2020-12-28 03:02:21 --> Language Class Initialized
INFO - 2020-12-28 03:02:21 --> Language Class Initialized
INFO - 2020-12-28 03:02:21 --> Config Class Initialized
INFO - 2020-12-28 03:02:21 --> Loader Class Initialized
INFO - 2020-12-28 03:02:21 --> Helper loaded: url_helper
INFO - 2020-12-28 03:02:21 --> Helper loaded: file_helper
INFO - 2020-12-28 03:02:21 --> Helper loaded: form_helper
INFO - 2020-12-28 03:02:21 --> Helper loaded: my_helper
INFO - 2020-12-28 03:02:21 --> Database Driver Class Initialized
DEBUG - 2020-12-28 03:02:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 03:02:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 03:02:21 --> Controller Class Initialized
INFO - 2020-12-28 03:02:21 --> Final output sent to browser
DEBUG - 2020-12-28 03:02:21 --> Total execution time: 0.7075
INFO - 2020-12-28 03:02:23 --> Config Class Initialized
INFO - 2020-12-28 03:02:23 --> Hooks Class Initialized
DEBUG - 2020-12-28 03:02:23 --> UTF-8 Support Enabled
INFO - 2020-12-28 03:02:23 --> Utf8 Class Initialized
INFO - 2020-12-28 03:02:23 --> URI Class Initialized
INFO - 2020-12-28 03:02:23 --> Router Class Initialized
INFO - 2020-12-28 03:02:23 --> Output Class Initialized
INFO - 2020-12-28 03:02:23 --> Security Class Initialized
DEBUG - 2020-12-28 03:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 03:02:23 --> Input Class Initialized
INFO - 2020-12-28 03:02:23 --> Language Class Initialized
INFO - 2020-12-28 03:02:23 --> Language Class Initialized
INFO - 2020-12-28 03:02:23 --> Config Class Initialized
INFO - 2020-12-28 03:02:23 --> Loader Class Initialized
INFO - 2020-12-28 03:02:23 --> Helper loaded: url_helper
INFO - 2020-12-28 03:02:23 --> Helper loaded: file_helper
INFO - 2020-12-28 03:02:23 --> Helper loaded: form_helper
INFO - 2020-12-28 03:02:23 --> Helper loaded: my_helper
INFO - 2020-12-28 03:02:24 --> Database Driver Class Initialized
DEBUG - 2020-12-28 03:02:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 03:02:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 03:02:24 --> Controller Class Initialized
INFO - 2020-12-28 03:02:24 --> Final output sent to browser
DEBUG - 2020-12-28 03:02:24 --> Total execution time: 0.9087
INFO - 2020-12-28 03:02:37 --> Config Class Initialized
INFO - 2020-12-28 03:02:37 --> Hooks Class Initialized
DEBUG - 2020-12-28 03:02:37 --> UTF-8 Support Enabled
INFO - 2020-12-28 03:02:37 --> Utf8 Class Initialized
INFO - 2020-12-28 03:02:37 --> URI Class Initialized
INFO - 2020-12-28 03:02:37 --> Router Class Initialized
INFO - 2020-12-28 03:02:37 --> Output Class Initialized
INFO - 2020-12-28 03:02:37 --> Security Class Initialized
DEBUG - 2020-12-28 03:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 03:02:37 --> Input Class Initialized
INFO - 2020-12-28 03:02:37 --> Language Class Initialized
INFO - 2020-12-28 03:02:37 --> Language Class Initialized
INFO - 2020-12-28 03:02:37 --> Config Class Initialized
INFO - 2020-12-28 03:02:37 --> Loader Class Initialized
INFO - 2020-12-28 03:02:38 --> Helper loaded: url_helper
INFO - 2020-12-28 03:02:38 --> Helper loaded: file_helper
INFO - 2020-12-28 03:02:38 --> Helper loaded: form_helper
INFO - 2020-12-28 03:02:38 --> Helper loaded: my_helper
INFO - 2020-12-28 03:02:38 --> Database Driver Class Initialized
DEBUG - 2020-12-28 03:02:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 03:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 03:02:38 --> Controller Class Initialized
INFO - 2020-12-28 03:02:38 --> Final output sent to browser
DEBUG - 2020-12-28 03:02:38 --> Total execution time: 0.8769
INFO - 2020-12-28 03:02:50 --> Config Class Initialized
INFO - 2020-12-28 03:02:50 --> Hooks Class Initialized
DEBUG - 2020-12-28 03:02:50 --> UTF-8 Support Enabled
INFO - 2020-12-28 03:02:50 --> Utf8 Class Initialized
INFO - 2020-12-28 03:02:50 --> URI Class Initialized
INFO - 2020-12-28 03:02:50 --> Router Class Initialized
INFO - 2020-12-28 03:02:50 --> Output Class Initialized
INFO - 2020-12-28 03:02:50 --> Security Class Initialized
DEBUG - 2020-12-28 03:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 03:02:50 --> Input Class Initialized
INFO - 2020-12-28 03:02:51 --> Language Class Initialized
INFO - 2020-12-28 03:02:51 --> Language Class Initialized
INFO - 2020-12-28 03:02:51 --> Config Class Initialized
INFO - 2020-12-28 03:02:51 --> Loader Class Initialized
INFO - 2020-12-28 03:02:51 --> Helper loaded: url_helper
INFO - 2020-12-28 03:02:51 --> Helper loaded: file_helper
INFO - 2020-12-28 03:02:51 --> Helper loaded: form_helper
INFO - 2020-12-28 03:02:51 --> Helper loaded: my_helper
INFO - 2020-12-28 03:02:51 --> Database Driver Class Initialized
DEBUG - 2020-12-28 03:02:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 03:02:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 03:02:51 --> Controller Class Initialized
INFO - 2020-12-28 03:02:51 --> Final output sent to browser
DEBUG - 2020-12-28 03:02:51 --> Total execution time: 0.7909
INFO - 2020-12-28 03:02:51 --> Config Class Initialized
INFO - 2020-12-28 03:02:51 --> Hooks Class Initialized
DEBUG - 2020-12-28 03:02:51 --> UTF-8 Support Enabled
INFO - 2020-12-28 03:02:51 --> Utf8 Class Initialized
INFO - 2020-12-28 03:02:51 --> URI Class Initialized
INFO - 2020-12-28 03:02:52 --> Router Class Initialized
INFO - 2020-12-28 03:02:52 --> Output Class Initialized
INFO - 2020-12-28 03:02:52 --> Security Class Initialized
DEBUG - 2020-12-28 03:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 03:02:52 --> Input Class Initialized
INFO - 2020-12-28 03:02:52 --> Language Class Initialized
INFO - 2020-12-28 03:02:52 --> Language Class Initialized
INFO - 2020-12-28 03:02:52 --> Config Class Initialized
INFO - 2020-12-28 03:02:52 --> Loader Class Initialized
INFO - 2020-12-28 03:02:52 --> Helper loaded: url_helper
INFO - 2020-12-28 03:02:52 --> Helper loaded: file_helper
INFO - 2020-12-28 03:02:52 --> Helper loaded: form_helper
INFO - 2020-12-28 03:02:52 --> Helper loaded: my_helper
INFO - 2020-12-28 03:02:52 --> Database Driver Class Initialized
DEBUG - 2020-12-28 03:02:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 03:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 03:02:52 --> Controller Class Initialized
INFO - 2020-12-28 03:06:05 --> Config Class Initialized
INFO - 2020-12-28 03:06:05 --> Hooks Class Initialized
DEBUG - 2020-12-28 03:06:05 --> UTF-8 Support Enabled
INFO - 2020-12-28 03:06:05 --> Utf8 Class Initialized
INFO - 2020-12-28 03:06:05 --> URI Class Initialized
INFO - 2020-12-28 03:06:05 --> Router Class Initialized
INFO - 2020-12-28 03:06:05 --> Output Class Initialized
INFO - 2020-12-28 03:06:05 --> Security Class Initialized
DEBUG - 2020-12-28 03:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 03:06:05 --> Input Class Initialized
INFO - 2020-12-28 03:06:05 --> Language Class Initialized
INFO - 2020-12-28 03:06:05 --> Language Class Initialized
INFO - 2020-12-28 03:06:05 --> Config Class Initialized
INFO - 2020-12-28 03:06:05 --> Loader Class Initialized
INFO - 2020-12-28 03:06:05 --> Helper loaded: url_helper
INFO - 2020-12-28 03:06:05 --> Helper loaded: file_helper
INFO - 2020-12-28 03:06:05 --> Helper loaded: form_helper
INFO - 2020-12-28 03:06:05 --> Helper loaded: my_helper
INFO - 2020-12-28 03:06:05 --> Database Driver Class Initialized
DEBUG - 2020-12-28 03:06:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 03:06:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 03:06:05 --> Controller Class Initialized
INFO - 2020-12-28 03:06:05 --> Final output sent to browser
DEBUG - 2020-12-28 03:06:05 --> Total execution time: 0.2922
INFO - 2020-12-28 03:06:47 --> Config Class Initialized
INFO - 2020-12-28 03:06:47 --> Hooks Class Initialized
DEBUG - 2020-12-28 03:06:47 --> UTF-8 Support Enabled
INFO - 2020-12-28 03:06:47 --> Utf8 Class Initialized
INFO - 2020-12-28 03:06:47 --> URI Class Initialized
INFO - 2020-12-28 03:06:47 --> Router Class Initialized
INFO - 2020-12-28 03:06:48 --> Output Class Initialized
INFO - 2020-12-28 03:06:48 --> Security Class Initialized
DEBUG - 2020-12-28 03:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 03:06:48 --> Input Class Initialized
INFO - 2020-12-28 03:06:48 --> Language Class Initialized
INFO - 2020-12-28 03:06:48 --> Language Class Initialized
INFO - 2020-12-28 03:06:48 --> Config Class Initialized
INFO - 2020-12-28 03:06:48 --> Loader Class Initialized
INFO - 2020-12-28 03:06:48 --> Helper loaded: url_helper
INFO - 2020-12-28 03:06:48 --> Helper loaded: file_helper
INFO - 2020-12-28 03:06:48 --> Helper loaded: form_helper
INFO - 2020-12-28 03:06:48 --> Helper loaded: my_helper
INFO - 2020-12-28 03:06:48 --> Database Driver Class Initialized
DEBUG - 2020-12-28 03:06:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 03:06:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 03:06:48 --> Controller Class Initialized
INFO - 2020-12-28 03:06:48 --> Final output sent to browser
DEBUG - 2020-12-28 03:06:48 --> Total execution time: 0.2947
INFO - 2020-12-28 03:06:48 --> Config Class Initialized
INFO - 2020-12-28 03:06:48 --> Hooks Class Initialized
DEBUG - 2020-12-28 03:06:48 --> UTF-8 Support Enabled
INFO - 2020-12-28 03:06:48 --> Utf8 Class Initialized
INFO - 2020-12-28 03:06:48 --> URI Class Initialized
INFO - 2020-12-28 03:06:48 --> Router Class Initialized
INFO - 2020-12-28 03:06:48 --> Output Class Initialized
INFO - 2020-12-28 03:06:48 --> Security Class Initialized
DEBUG - 2020-12-28 03:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 03:06:48 --> Input Class Initialized
INFO - 2020-12-28 03:06:48 --> Language Class Initialized
INFO - 2020-12-28 03:06:48 --> Language Class Initialized
INFO - 2020-12-28 03:06:48 --> Config Class Initialized
INFO - 2020-12-28 03:06:48 --> Loader Class Initialized
INFO - 2020-12-28 03:06:48 --> Helper loaded: url_helper
INFO - 2020-12-28 03:06:48 --> Helper loaded: file_helper
INFO - 2020-12-28 03:06:48 --> Helper loaded: form_helper
INFO - 2020-12-28 03:06:48 --> Helper loaded: my_helper
INFO - 2020-12-28 03:06:48 --> Database Driver Class Initialized
DEBUG - 2020-12-28 03:06:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 03:06:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 03:06:48 --> Controller Class Initialized
INFO - 2020-12-28 03:07:12 --> Config Class Initialized
INFO - 2020-12-28 03:07:12 --> Hooks Class Initialized
DEBUG - 2020-12-28 03:07:12 --> UTF-8 Support Enabled
INFO - 2020-12-28 03:07:12 --> Utf8 Class Initialized
INFO - 2020-12-28 03:07:12 --> URI Class Initialized
INFO - 2020-12-28 03:07:12 --> Router Class Initialized
INFO - 2020-12-28 03:07:12 --> Output Class Initialized
INFO - 2020-12-28 03:07:12 --> Security Class Initialized
DEBUG - 2020-12-28 03:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 03:07:12 --> Input Class Initialized
INFO - 2020-12-28 03:07:12 --> Language Class Initialized
INFO - 2020-12-28 03:07:12 --> Language Class Initialized
INFO - 2020-12-28 03:07:12 --> Config Class Initialized
INFO - 2020-12-28 03:07:12 --> Loader Class Initialized
INFO - 2020-12-28 03:07:12 --> Helper loaded: url_helper
INFO - 2020-12-28 03:07:12 --> Helper loaded: file_helper
INFO - 2020-12-28 03:07:12 --> Helper loaded: form_helper
INFO - 2020-12-28 03:07:12 --> Helper loaded: my_helper
INFO - 2020-12-28 03:07:12 --> Database Driver Class Initialized
DEBUG - 2020-12-28 03:07:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 03:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 03:07:12 --> Controller Class Initialized
INFO - 2020-12-28 03:07:12 --> Final output sent to browser
DEBUG - 2020-12-28 03:07:13 --> Total execution time: 0.2957
INFO - 2020-12-28 03:07:27 --> Config Class Initialized
INFO - 2020-12-28 03:07:27 --> Hooks Class Initialized
DEBUG - 2020-12-28 03:07:27 --> UTF-8 Support Enabled
INFO - 2020-12-28 03:07:27 --> Utf8 Class Initialized
INFO - 2020-12-28 03:07:27 --> URI Class Initialized
INFO - 2020-12-28 03:07:27 --> Router Class Initialized
INFO - 2020-12-28 03:07:27 --> Output Class Initialized
INFO - 2020-12-28 03:07:27 --> Security Class Initialized
DEBUG - 2020-12-28 03:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 03:07:27 --> Input Class Initialized
INFO - 2020-12-28 03:07:27 --> Language Class Initialized
INFO - 2020-12-28 03:07:27 --> Language Class Initialized
INFO - 2020-12-28 03:07:27 --> Config Class Initialized
INFO - 2020-12-28 03:07:27 --> Loader Class Initialized
INFO - 2020-12-28 03:07:27 --> Helper loaded: url_helper
INFO - 2020-12-28 03:07:27 --> Helper loaded: file_helper
INFO - 2020-12-28 03:07:27 --> Helper loaded: form_helper
INFO - 2020-12-28 03:07:27 --> Helper loaded: my_helper
INFO - 2020-12-28 03:07:27 --> Database Driver Class Initialized
DEBUG - 2020-12-28 03:07:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 03:07:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 03:07:27 --> Controller Class Initialized
INFO - 2020-12-28 03:07:27 --> Final output sent to browser
DEBUG - 2020-12-28 03:07:27 --> Total execution time: 0.2970
INFO - 2020-12-28 03:07:27 --> Config Class Initialized
INFO - 2020-12-28 03:07:27 --> Hooks Class Initialized
DEBUG - 2020-12-28 03:07:27 --> UTF-8 Support Enabled
INFO - 2020-12-28 03:07:27 --> Utf8 Class Initialized
INFO - 2020-12-28 03:07:27 --> URI Class Initialized
INFO - 2020-12-28 03:07:27 --> Router Class Initialized
INFO - 2020-12-28 03:07:27 --> Output Class Initialized
INFO - 2020-12-28 03:07:27 --> Security Class Initialized
DEBUG - 2020-12-28 03:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 03:07:27 --> Input Class Initialized
INFO - 2020-12-28 03:07:27 --> Language Class Initialized
INFO - 2020-12-28 03:07:27 --> Language Class Initialized
INFO - 2020-12-28 03:07:27 --> Config Class Initialized
INFO - 2020-12-28 03:07:27 --> Loader Class Initialized
INFO - 2020-12-28 03:07:27 --> Helper loaded: url_helper
INFO - 2020-12-28 03:07:27 --> Helper loaded: file_helper
INFO - 2020-12-28 03:07:27 --> Helper loaded: form_helper
INFO - 2020-12-28 03:07:27 --> Helper loaded: my_helper
INFO - 2020-12-28 03:07:27 --> Database Driver Class Initialized
DEBUG - 2020-12-28 03:07:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 03:07:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 03:07:27 --> Controller Class Initialized
INFO - 2020-12-28 03:07:47 --> Config Class Initialized
INFO - 2020-12-28 03:07:47 --> Hooks Class Initialized
DEBUG - 2020-12-28 03:07:47 --> UTF-8 Support Enabled
INFO - 2020-12-28 03:07:47 --> Utf8 Class Initialized
INFO - 2020-12-28 03:07:47 --> URI Class Initialized
INFO - 2020-12-28 03:07:47 --> Router Class Initialized
INFO - 2020-12-28 03:07:47 --> Output Class Initialized
INFO - 2020-12-28 03:07:47 --> Security Class Initialized
DEBUG - 2020-12-28 03:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 03:07:47 --> Input Class Initialized
INFO - 2020-12-28 03:07:47 --> Language Class Initialized
INFO - 2020-12-28 03:07:47 --> Language Class Initialized
INFO - 2020-12-28 03:07:47 --> Config Class Initialized
INFO - 2020-12-28 03:07:47 --> Loader Class Initialized
INFO - 2020-12-28 03:07:47 --> Helper loaded: url_helper
INFO - 2020-12-28 03:07:47 --> Helper loaded: file_helper
INFO - 2020-12-28 03:07:47 --> Helper loaded: form_helper
INFO - 2020-12-28 03:07:47 --> Helper loaded: my_helper
INFO - 2020-12-28 03:07:47 --> Database Driver Class Initialized
DEBUG - 2020-12-28 03:07:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 03:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 03:07:47 --> Controller Class Initialized
INFO - 2020-12-28 03:07:47 --> Final output sent to browser
DEBUG - 2020-12-28 03:07:47 --> Total execution time: 0.2698
INFO - 2020-12-28 03:08:02 --> Config Class Initialized
INFO - 2020-12-28 03:08:02 --> Hooks Class Initialized
DEBUG - 2020-12-28 03:08:02 --> UTF-8 Support Enabled
INFO - 2020-12-28 03:08:02 --> Utf8 Class Initialized
INFO - 2020-12-28 03:08:02 --> URI Class Initialized
INFO - 2020-12-28 03:08:02 --> Router Class Initialized
INFO - 2020-12-28 03:08:02 --> Output Class Initialized
INFO - 2020-12-28 03:08:02 --> Security Class Initialized
DEBUG - 2020-12-28 03:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 03:08:02 --> Input Class Initialized
INFO - 2020-12-28 03:08:02 --> Language Class Initialized
INFO - 2020-12-28 03:08:02 --> Language Class Initialized
INFO - 2020-12-28 03:08:02 --> Config Class Initialized
INFO - 2020-12-28 03:08:02 --> Loader Class Initialized
INFO - 2020-12-28 03:08:02 --> Helper loaded: url_helper
INFO - 2020-12-28 03:08:02 --> Helper loaded: file_helper
INFO - 2020-12-28 03:08:02 --> Helper loaded: form_helper
INFO - 2020-12-28 03:08:02 --> Helper loaded: my_helper
INFO - 2020-12-28 03:08:02 --> Database Driver Class Initialized
DEBUG - 2020-12-28 03:08:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 03:08:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 03:08:02 --> Controller Class Initialized
INFO - 2020-12-28 03:08:02 --> Final output sent to browser
DEBUG - 2020-12-28 03:08:02 --> Total execution time: 0.3333
INFO - 2020-12-28 03:08:02 --> Config Class Initialized
INFO - 2020-12-28 03:08:02 --> Hooks Class Initialized
DEBUG - 2020-12-28 03:08:02 --> UTF-8 Support Enabled
INFO - 2020-12-28 03:08:02 --> Utf8 Class Initialized
INFO - 2020-12-28 03:08:02 --> URI Class Initialized
INFO - 2020-12-28 03:08:02 --> Router Class Initialized
INFO - 2020-12-28 03:08:02 --> Output Class Initialized
INFO - 2020-12-28 03:08:02 --> Security Class Initialized
DEBUG - 2020-12-28 03:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 03:08:02 --> Input Class Initialized
INFO - 2020-12-28 03:08:02 --> Language Class Initialized
INFO - 2020-12-28 03:08:02 --> Language Class Initialized
INFO - 2020-12-28 03:08:02 --> Config Class Initialized
INFO - 2020-12-28 03:08:02 --> Loader Class Initialized
INFO - 2020-12-28 03:08:02 --> Helper loaded: url_helper
INFO - 2020-12-28 03:08:02 --> Helper loaded: file_helper
INFO - 2020-12-28 03:08:02 --> Helper loaded: form_helper
INFO - 2020-12-28 03:08:02 --> Helper loaded: my_helper
INFO - 2020-12-28 03:08:02 --> Database Driver Class Initialized
DEBUG - 2020-12-28 03:08:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 03:08:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 03:08:02 --> Controller Class Initialized
INFO - 2020-12-28 03:08:11 --> Config Class Initialized
INFO - 2020-12-28 03:08:11 --> Hooks Class Initialized
DEBUG - 2020-12-28 03:08:11 --> UTF-8 Support Enabled
INFO - 2020-12-28 03:08:11 --> Utf8 Class Initialized
INFO - 2020-12-28 03:08:11 --> URI Class Initialized
INFO - 2020-12-28 03:08:11 --> Router Class Initialized
INFO - 2020-12-28 03:08:11 --> Output Class Initialized
INFO - 2020-12-28 03:08:11 --> Security Class Initialized
DEBUG - 2020-12-28 03:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 03:08:11 --> Input Class Initialized
INFO - 2020-12-28 03:08:11 --> Language Class Initialized
INFO - 2020-12-28 03:08:11 --> Language Class Initialized
INFO - 2020-12-28 03:08:11 --> Config Class Initialized
INFO - 2020-12-28 03:08:11 --> Loader Class Initialized
INFO - 2020-12-28 03:08:11 --> Helper loaded: url_helper
INFO - 2020-12-28 03:08:11 --> Helper loaded: file_helper
INFO - 2020-12-28 03:08:11 --> Helper loaded: form_helper
INFO - 2020-12-28 03:08:11 --> Helper loaded: my_helper
INFO - 2020-12-28 03:08:11 --> Database Driver Class Initialized
DEBUG - 2020-12-28 03:08:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 03:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 03:08:11 --> Controller Class Initialized
INFO - 2020-12-28 03:08:11 --> Final output sent to browser
DEBUG - 2020-12-28 03:08:11 --> Total execution time: 0.2878
INFO - 2020-12-28 03:08:21 --> Config Class Initialized
INFO - 2020-12-28 03:08:21 --> Hooks Class Initialized
DEBUG - 2020-12-28 03:08:21 --> UTF-8 Support Enabled
INFO - 2020-12-28 03:08:21 --> Utf8 Class Initialized
INFO - 2020-12-28 03:08:21 --> URI Class Initialized
INFO - 2020-12-28 03:08:21 --> Router Class Initialized
INFO - 2020-12-28 03:08:21 --> Output Class Initialized
INFO - 2020-12-28 03:08:21 --> Security Class Initialized
DEBUG - 2020-12-28 03:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 03:08:21 --> Input Class Initialized
INFO - 2020-12-28 03:08:21 --> Language Class Initialized
INFO - 2020-12-28 03:08:21 --> Language Class Initialized
INFO - 2020-12-28 03:08:21 --> Config Class Initialized
INFO - 2020-12-28 03:08:21 --> Loader Class Initialized
INFO - 2020-12-28 03:08:21 --> Helper loaded: url_helper
INFO - 2020-12-28 03:08:21 --> Helper loaded: file_helper
INFO - 2020-12-28 03:08:21 --> Helper loaded: form_helper
INFO - 2020-12-28 03:08:21 --> Helper loaded: my_helper
INFO - 2020-12-28 03:08:21 --> Database Driver Class Initialized
DEBUG - 2020-12-28 03:08:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 03:08:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 03:08:21 --> Controller Class Initialized
INFO - 2020-12-28 03:08:21 --> Final output sent to browser
DEBUG - 2020-12-28 03:08:21 --> Total execution time: 0.3032
INFO - 2020-12-28 03:08:21 --> Config Class Initialized
INFO - 2020-12-28 03:08:21 --> Hooks Class Initialized
DEBUG - 2020-12-28 03:08:21 --> UTF-8 Support Enabled
INFO - 2020-12-28 03:08:21 --> Utf8 Class Initialized
INFO - 2020-12-28 03:08:21 --> URI Class Initialized
INFO - 2020-12-28 03:08:21 --> Router Class Initialized
INFO - 2020-12-28 03:08:21 --> Output Class Initialized
INFO - 2020-12-28 03:08:21 --> Security Class Initialized
DEBUG - 2020-12-28 03:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 03:08:21 --> Input Class Initialized
INFO - 2020-12-28 03:08:21 --> Language Class Initialized
INFO - 2020-12-28 03:08:21 --> Language Class Initialized
INFO - 2020-12-28 03:08:21 --> Config Class Initialized
INFO - 2020-12-28 03:08:21 --> Loader Class Initialized
INFO - 2020-12-28 03:08:21 --> Helper loaded: url_helper
INFO - 2020-12-28 03:08:21 --> Helper loaded: file_helper
INFO - 2020-12-28 03:08:21 --> Helper loaded: form_helper
INFO - 2020-12-28 03:08:21 --> Helper loaded: my_helper
INFO - 2020-12-28 03:08:21 --> Database Driver Class Initialized
DEBUG - 2020-12-28 03:08:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 03:08:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 03:08:21 --> Controller Class Initialized
INFO - 2020-12-28 03:08:23 --> Config Class Initialized
INFO - 2020-12-28 03:08:23 --> Hooks Class Initialized
DEBUG - 2020-12-28 03:08:23 --> UTF-8 Support Enabled
INFO - 2020-12-28 03:08:23 --> Utf8 Class Initialized
INFO - 2020-12-28 03:08:23 --> URI Class Initialized
INFO - 2020-12-28 03:08:23 --> Router Class Initialized
INFO - 2020-12-28 03:08:23 --> Output Class Initialized
INFO - 2020-12-28 03:08:23 --> Security Class Initialized
DEBUG - 2020-12-28 03:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 03:08:23 --> Input Class Initialized
INFO - 2020-12-28 03:08:23 --> Language Class Initialized
INFO - 2020-12-28 03:08:23 --> Language Class Initialized
INFO - 2020-12-28 03:08:23 --> Config Class Initialized
INFO - 2020-12-28 03:08:23 --> Loader Class Initialized
INFO - 2020-12-28 03:08:23 --> Helper loaded: url_helper
INFO - 2020-12-28 03:08:23 --> Helper loaded: file_helper
INFO - 2020-12-28 03:08:23 --> Helper loaded: form_helper
INFO - 2020-12-28 03:08:23 --> Helper loaded: my_helper
INFO - 2020-12-28 03:08:23 --> Database Driver Class Initialized
DEBUG - 2020-12-28 03:08:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 03:08:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 03:08:23 --> Controller Class Initialized
INFO - 2020-12-28 03:08:23 --> Final output sent to browser
DEBUG - 2020-12-28 03:08:23 --> Total execution time: 0.2904
INFO - 2020-12-28 03:08:43 --> Config Class Initialized
INFO - 2020-12-28 03:08:44 --> Hooks Class Initialized
DEBUG - 2020-12-28 03:08:44 --> UTF-8 Support Enabled
INFO - 2020-12-28 03:08:44 --> Utf8 Class Initialized
INFO - 2020-12-28 03:08:44 --> URI Class Initialized
INFO - 2020-12-28 03:08:44 --> Router Class Initialized
INFO - 2020-12-28 03:08:44 --> Output Class Initialized
INFO - 2020-12-28 03:08:44 --> Security Class Initialized
DEBUG - 2020-12-28 03:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 03:08:44 --> Input Class Initialized
INFO - 2020-12-28 03:08:44 --> Language Class Initialized
INFO - 2020-12-28 03:08:44 --> Language Class Initialized
INFO - 2020-12-28 03:08:44 --> Config Class Initialized
INFO - 2020-12-28 03:08:44 --> Loader Class Initialized
INFO - 2020-12-28 03:08:44 --> Helper loaded: url_helper
INFO - 2020-12-28 03:08:44 --> Helper loaded: file_helper
INFO - 2020-12-28 03:08:44 --> Helper loaded: form_helper
INFO - 2020-12-28 03:08:44 --> Helper loaded: my_helper
INFO - 2020-12-28 03:08:44 --> Database Driver Class Initialized
DEBUG - 2020-12-28 03:08:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 03:08:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 03:08:44 --> Controller Class Initialized
INFO - 2020-12-28 03:08:44 --> Final output sent to browser
DEBUG - 2020-12-28 03:08:44 --> Total execution time: 0.3343
INFO - 2020-12-28 03:08:44 --> Config Class Initialized
INFO - 2020-12-28 03:08:44 --> Hooks Class Initialized
DEBUG - 2020-12-28 03:08:44 --> UTF-8 Support Enabled
INFO - 2020-12-28 03:08:44 --> Utf8 Class Initialized
INFO - 2020-12-28 03:08:44 --> URI Class Initialized
INFO - 2020-12-28 03:08:44 --> Router Class Initialized
INFO - 2020-12-28 03:08:44 --> Output Class Initialized
INFO - 2020-12-28 03:08:44 --> Security Class Initialized
DEBUG - 2020-12-28 03:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 03:08:44 --> Input Class Initialized
INFO - 2020-12-28 03:08:44 --> Language Class Initialized
INFO - 2020-12-28 03:08:44 --> Language Class Initialized
INFO - 2020-12-28 03:08:44 --> Config Class Initialized
INFO - 2020-12-28 03:08:44 --> Loader Class Initialized
INFO - 2020-12-28 03:08:44 --> Helper loaded: url_helper
INFO - 2020-12-28 03:08:44 --> Helper loaded: file_helper
INFO - 2020-12-28 03:08:44 --> Helper loaded: form_helper
INFO - 2020-12-28 03:08:44 --> Helper loaded: my_helper
INFO - 2020-12-28 03:08:44 --> Database Driver Class Initialized
DEBUG - 2020-12-28 03:08:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 03:08:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 03:08:44 --> Controller Class Initialized
INFO - 2020-12-28 03:09:22 --> Config Class Initialized
INFO - 2020-12-28 03:09:22 --> Hooks Class Initialized
DEBUG - 2020-12-28 03:09:22 --> UTF-8 Support Enabled
INFO - 2020-12-28 03:09:22 --> Utf8 Class Initialized
INFO - 2020-12-28 03:09:22 --> URI Class Initialized
INFO - 2020-12-28 03:09:22 --> Router Class Initialized
INFO - 2020-12-28 03:09:22 --> Output Class Initialized
INFO - 2020-12-28 03:09:22 --> Security Class Initialized
DEBUG - 2020-12-28 03:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 03:09:22 --> Input Class Initialized
INFO - 2020-12-28 03:09:22 --> Language Class Initialized
INFO - 2020-12-28 03:09:22 --> Language Class Initialized
INFO - 2020-12-28 03:09:22 --> Config Class Initialized
INFO - 2020-12-28 03:09:22 --> Loader Class Initialized
INFO - 2020-12-28 03:09:22 --> Helper loaded: url_helper
INFO - 2020-12-28 03:09:22 --> Helper loaded: file_helper
INFO - 2020-12-28 03:09:22 --> Helper loaded: form_helper
INFO - 2020-12-28 03:09:22 --> Helper loaded: my_helper
INFO - 2020-12-28 03:09:22 --> Database Driver Class Initialized
DEBUG - 2020-12-28 03:09:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 03:09:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 03:09:22 --> Controller Class Initialized
INFO - 2020-12-28 03:09:24 --> Config Class Initialized
INFO - 2020-12-28 03:09:24 --> Hooks Class Initialized
DEBUG - 2020-12-28 03:09:24 --> UTF-8 Support Enabled
INFO - 2020-12-28 03:09:24 --> Utf8 Class Initialized
INFO - 2020-12-28 03:09:24 --> URI Class Initialized
INFO - 2020-12-28 03:09:24 --> Router Class Initialized
INFO - 2020-12-28 03:09:24 --> Output Class Initialized
INFO - 2020-12-28 03:09:24 --> Security Class Initialized
DEBUG - 2020-12-28 03:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 03:09:24 --> Input Class Initialized
INFO - 2020-12-28 03:09:24 --> Language Class Initialized
INFO - 2020-12-28 03:09:24 --> Language Class Initialized
INFO - 2020-12-28 03:09:24 --> Config Class Initialized
INFO - 2020-12-28 03:09:24 --> Loader Class Initialized
INFO - 2020-12-28 03:09:24 --> Helper loaded: url_helper
INFO - 2020-12-28 03:09:24 --> Helper loaded: file_helper
INFO - 2020-12-28 03:09:24 --> Helper loaded: form_helper
INFO - 2020-12-28 03:09:24 --> Helper loaded: my_helper
INFO - 2020-12-28 03:09:24 --> Database Driver Class Initialized
DEBUG - 2020-12-28 03:09:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 03:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 03:09:25 --> Controller Class Initialized
INFO - 2020-12-28 03:09:25 --> Final output sent to browser
DEBUG - 2020-12-28 03:09:25 --> Total execution time: 0.2972
INFO - 2020-12-28 03:09:28 --> Config Class Initialized
INFO - 2020-12-28 03:09:28 --> Hooks Class Initialized
DEBUG - 2020-12-28 03:09:28 --> UTF-8 Support Enabled
INFO - 2020-12-28 03:09:28 --> Utf8 Class Initialized
INFO - 2020-12-28 03:09:28 --> URI Class Initialized
INFO - 2020-12-28 03:09:28 --> Router Class Initialized
INFO - 2020-12-28 03:09:28 --> Output Class Initialized
INFO - 2020-12-28 03:09:28 --> Security Class Initialized
DEBUG - 2020-12-28 03:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 03:09:28 --> Input Class Initialized
INFO - 2020-12-28 03:09:28 --> Language Class Initialized
INFO - 2020-12-28 03:09:28 --> Language Class Initialized
INFO - 2020-12-28 03:09:28 --> Config Class Initialized
INFO - 2020-12-28 03:09:28 --> Loader Class Initialized
INFO - 2020-12-28 03:09:28 --> Helper loaded: url_helper
INFO - 2020-12-28 03:09:28 --> Helper loaded: file_helper
INFO - 2020-12-28 03:09:28 --> Helper loaded: form_helper
INFO - 2020-12-28 03:09:28 --> Helper loaded: my_helper
INFO - 2020-12-28 03:09:28 --> Database Driver Class Initialized
DEBUG - 2020-12-28 03:09:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 03:09:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 03:09:28 --> Controller Class Initialized
INFO - 2020-12-28 03:09:28 --> Final output sent to browser
DEBUG - 2020-12-28 03:09:28 --> Total execution time: 0.3148
INFO - 2020-12-28 03:09:28 --> Config Class Initialized
INFO - 2020-12-28 03:09:28 --> Hooks Class Initialized
DEBUG - 2020-12-28 03:09:28 --> UTF-8 Support Enabled
INFO - 2020-12-28 03:09:28 --> Utf8 Class Initialized
INFO - 2020-12-28 03:09:28 --> URI Class Initialized
INFO - 2020-12-28 03:09:28 --> Router Class Initialized
INFO - 2020-12-28 03:09:28 --> Output Class Initialized
INFO - 2020-12-28 03:09:28 --> Security Class Initialized
DEBUG - 2020-12-28 03:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 03:09:28 --> Input Class Initialized
INFO - 2020-12-28 03:09:28 --> Language Class Initialized
INFO - 2020-12-28 03:09:28 --> Language Class Initialized
INFO - 2020-12-28 03:09:28 --> Config Class Initialized
INFO - 2020-12-28 03:09:28 --> Loader Class Initialized
INFO - 2020-12-28 03:09:28 --> Helper loaded: url_helper
INFO - 2020-12-28 03:09:28 --> Helper loaded: file_helper
INFO - 2020-12-28 03:09:28 --> Helper loaded: form_helper
INFO - 2020-12-28 03:09:28 --> Helper loaded: my_helper
INFO - 2020-12-28 03:09:28 --> Database Driver Class Initialized
DEBUG - 2020-12-28 03:09:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 03:09:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 03:09:28 --> Controller Class Initialized
INFO - 2020-12-28 03:09:34 --> Config Class Initialized
INFO - 2020-12-28 03:09:34 --> Hooks Class Initialized
DEBUG - 2020-12-28 03:09:34 --> UTF-8 Support Enabled
INFO - 2020-12-28 03:09:34 --> Utf8 Class Initialized
INFO - 2020-12-28 03:09:34 --> URI Class Initialized
INFO - 2020-12-28 03:09:34 --> Router Class Initialized
INFO - 2020-12-28 03:09:34 --> Output Class Initialized
INFO - 2020-12-28 03:09:34 --> Security Class Initialized
DEBUG - 2020-12-28 03:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 03:09:34 --> Input Class Initialized
INFO - 2020-12-28 03:09:34 --> Language Class Initialized
INFO - 2020-12-28 03:09:34 --> Language Class Initialized
INFO - 2020-12-28 03:09:34 --> Config Class Initialized
INFO - 2020-12-28 03:09:34 --> Loader Class Initialized
INFO - 2020-12-28 03:09:34 --> Helper loaded: url_helper
INFO - 2020-12-28 03:09:34 --> Helper loaded: file_helper
INFO - 2020-12-28 03:09:34 --> Helper loaded: form_helper
INFO - 2020-12-28 03:09:34 --> Helper loaded: my_helper
INFO - 2020-12-28 03:09:34 --> Database Driver Class Initialized
DEBUG - 2020-12-28 03:09:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 03:09:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 03:09:34 --> Controller Class Initialized
INFO - 2020-12-28 03:09:37 --> Config Class Initialized
INFO - 2020-12-28 03:09:37 --> Hooks Class Initialized
DEBUG - 2020-12-28 03:09:37 --> UTF-8 Support Enabled
INFO - 2020-12-28 03:09:37 --> Utf8 Class Initialized
INFO - 2020-12-28 03:09:37 --> URI Class Initialized
INFO - 2020-12-28 03:09:37 --> Router Class Initialized
INFO - 2020-12-28 03:09:37 --> Output Class Initialized
INFO - 2020-12-28 03:09:37 --> Security Class Initialized
DEBUG - 2020-12-28 03:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 03:09:37 --> Input Class Initialized
INFO - 2020-12-28 03:09:37 --> Language Class Initialized
INFO - 2020-12-28 03:09:37 --> Language Class Initialized
INFO - 2020-12-28 03:09:37 --> Config Class Initialized
INFO - 2020-12-28 03:09:37 --> Loader Class Initialized
INFO - 2020-12-28 03:09:37 --> Helper loaded: url_helper
INFO - 2020-12-28 03:09:37 --> Helper loaded: file_helper
INFO - 2020-12-28 03:09:37 --> Helper loaded: form_helper
INFO - 2020-12-28 03:09:37 --> Helper loaded: my_helper
INFO - 2020-12-28 03:09:37 --> Database Driver Class Initialized
DEBUG - 2020-12-28 03:09:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 03:09:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 03:09:37 --> Controller Class Initialized
INFO - 2020-12-28 03:09:39 --> Config Class Initialized
INFO - 2020-12-28 03:09:39 --> Hooks Class Initialized
DEBUG - 2020-12-28 03:09:39 --> UTF-8 Support Enabled
INFO - 2020-12-28 03:09:39 --> Utf8 Class Initialized
INFO - 2020-12-28 03:09:39 --> URI Class Initialized
INFO - 2020-12-28 03:09:39 --> Router Class Initialized
INFO - 2020-12-28 03:09:40 --> Output Class Initialized
INFO - 2020-12-28 03:09:40 --> Security Class Initialized
DEBUG - 2020-12-28 03:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 03:09:40 --> Input Class Initialized
INFO - 2020-12-28 03:09:40 --> Language Class Initialized
INFO - 2020-12-28 03:09:40 --> Language Class Initialized
INFO - 2020-12-28 03:09:40 --> Config Class Initialized
INFO - 2020-12-28 03:09:40 --> Loader Class Initialized
INFO - 2020-12-28 03:09:40 --> Helper loaded: url_helper
INFO - 2020-12-28 03:09:40 --> Helper loaded: file_helper
INFO - 2020-12-28 03:09:40 --> Helper loaded: form_helper
INFO - 2020-12-28 03:09:40 --> Helper loaded: my_helper
INFO - 2020-12-28 03:09:40 --> Database Driver Class Initialized
DEBUG - 2020-12-28 03:09:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 03:09:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 03:09:40 --> Controller Class Initialized
INFO - 2020-12-28 03:09:40 --> Final output sent to browser
DEBUG - 2020-12-28 03:09:40 --> Total execution time: 0.2880
INFO - 2020-12-28 03:37:20 --> Config Class Initialized
INFO - 2020-12-28 03:37:20 --> Hooks Class Initialized
DEBUG - 2020-12-28 03:37:20 --> UTF-8 Support Enabled
INFO - 2020-12-28 03:37:20 --> Utf8 Class Initialized
INFO - 2020-12-28 03:37:20 --> URI Class Initialized
INFO - 2020-12-28 03:37:20 --> Router Class Initialized
INFO - 2020-12-28 03:37:20 --> Output Class Initialized
INFO - 2020-12-28 03:37:20 --> Security Class Initialized
DEBUG - 2020-12-28 03:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 03:37:20 --> Input Class Initialized
INFO - 2020-12-28 03:37:20 --> Language Class Initialized
INFO - 2020-12-28 03:37:20 --> Language Class Initialized
INFO - 2020-12-28 03:37:20 --> Config Class Initialized
INFO - 2020-12-28 03:37:20 --> Loader Class Initialized
INFO - 2020-12-28 03:37:20 --> Helper loaded: url_helper
INFO - 2020-12-28 03:37:20 --> Helper loaded: file_helper
INFO - 2020-12-28 03:37:20 --> Helper loaded: form_helper
INFO - 2020-12-28 03:37:20 --> Helper loaded: my_helper
INFO - 2020-12-28 03:37:20 --> Database Driver Class Initialized
DEBUG - 2020-12-28 03:37:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 03:37:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 03:37:21 --> Controller Class Initialized
INFO - 2020-12-28 03:37:21 --> Final output sent to browser
DEBUG - 2020-12-28 03:37:21 --> Total execution time: 0.3419
INFO - 2020-12-28 03:37:21 --> Config Class Initialized
INFO - 2020-12-28 03:37:21 --> Hooks Class Initialized
DEBUG - 2020-12-28 03:37:21 --> UTF-8 Support Enabled
INFO - 2020-12-28 03:37:21 --> Utf8 Class Initialized
INFO - 2020-12-28 03:37:21 --> URI Class Initialized
INFO - 2020-12-28 03:37:21 --> Router Class Initialized
INFO - 2020-12-28 03:37:21 --> Output Class Initialized
INFO - 2020-12-28 03:37:21 --> Security Class Initialized
DEBUG - 2020-12-28 03:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 03:37:21 --> Input Class Initialized
INFO - 2020-12-28 03:37:21 --> Language Class Initialized
INFO - 2020-12-28 03:37:21 --> Language Class Initialized
INFO - 2020-12-28 03:37:21 --> Config Class Initialized
INFO - 2020-12-28 03:37:21 --> Loader Class Initialized
INFO - 2020-12-28 03:37:21 --> Helper loaded: url_helper
INFO - 2020-12-28 03:37:21 --> Helper loaded: file_helper
INFO - 2020-12-28 03:37:21 --> Helper loaded: form_helper
INFO - 2020-12-28 03:37:21 --> Helper loaded: my_helper
INFO - 2020-12-28 03:37:21 --> Database Driver Class Initialized
DEBUG - 2020-12-28 03:37:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 03:37:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 03:37:21 --> Controller Class Initialized
INFO - 2020-12-28 03:39:09 --> Config Class Initialized
INFO - 2020-12-28 03:39:09 --> Hooks Class Initialized
DEBUG - 2020-12-28 03:39:10 --> UTF-8 Support Enabled
INFO - 2020-12-28 03:39:10 --> Utf8 Class Initialized
INFO - 2020-12-28 03:39:10 --> URI Class Initialized
INFO - 2020-12-28 03:39:10 --> Router Class Initialized
INFO - 2020-12-28 03:39:10 --> Output Class Initialized
INFO - 2020-12-28 03:39:10 --> Security Class Initialized
DEBUG - 2020-12-28 03:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 03:39:10 --> Input Class Initialized
INFO - 2020-12-28 03:39:10 --> Language Class Initialized
INFO - 2020-12-28 03:39:10 --> Language Class Initialized
INFO - 2020-12-28 03:39:10 --> Config Class Initialized
INFO - 2020-12-28 03:39:10 --> Loader Class Initialized
INFO - 2020-12-28 03:39:10 --> Helper loaded: url_helper
INFO - 2020-12-28 03:39:10 --> Helper loaded: file_helper
INFO - 2020-12-28 03:39:10 --> Helper loaded: form_helper
INFO - 2020-12-28 03:39:10 --> Helper loaded: my_helper
INFO - 2020-12-28 03:39:10 --> Database Driver Class Initialized
DEBUG - 2020-12-28 03:39:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 03:39:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 03:39:10 --> Controller Class Initialized
INFO - 2020-12-28 03:39:10 --> Final output sent to browser
DEBUG - 2020-12-28 03:39:10 --> Total execution time: 0.2927
INFO - 2020-12-28 04:09:31 --> Config Class Initialized
INFO - 2020-12-28 04:09:31 --> Hooks Class Initialized
DEBUG - 2020-12-28 04:09:31 --> UTF-8 Support Enabled
INFO - 2020-12-28 04:09:31 --> Utf8 Class Initialized
INFO - 2020-12-28 04:09:31 --> URI Class Initialized
INFO - 2020-12-28 04:09:31 --> Router Class Initialized
INFO - 2020-12-28 04:09:31 --> Output Class Initialized
INFO - 2020-12-28 04:09:31 --> Security Class Initialized
DEBUG - 2020-12-28 04:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 04:09:31 --> Input Class Initialized
INFO - 2020-12-28 04:09:31 --> Language Class Initialized
INFO - 2020-12-28 04:09:31 --> Language Class Initialized
INFO - 2020-12-28 04:09:31 --> Config Class Initialized
INFO - 2020-12-28 04:09:32 --> Loader Class Initialized
INFO - 2020-12-28 04:09:32 --> Helper loaded: url_helper
INFO - 2020-12-28 04:09:32 --> Helper loaded: file_helper
INFO - 2020-12-28 04:09:32 --> Helper loaded: form_helper
INFO - 2020-12-28 04:09:32 --> Helper loaded: my_helper
INFO - 2020-12-28 04:09:32 --> Database Driver Class Initialized
DEBUG - 2020-12-28 04:09:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 04:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 04:09:32 --> Controller Class Initialized
INFO - 2020-12-28 04:09:32 --> Final output sent to browser
DEBUG - 2020-12-28 04:09:32 --> Total execution time: 0.2816
INFO - 2020-12-28 04:19:10 --> Config Class Initialized
INFO - 2020-12-28 04:19:10 --> Hooks Class Initialized
DEBUG - 2020-12-28 04:19:10 --> UTF-8 Support Enabled
INFO - 2020-12-28 04:19:10 --> Utf8 Class Initialized
INFO - 2020-12-28 04:19:10 --> URI Class Initialized
INFO - 2020-12-28 04:19:10 --> Router Class Initialized
INFO - 2020-12-28 04:19:10 --> Output Class Initialized
INFO - 2020-12-28 04:19:10 --> Security Class Initialized
DEBUG - 2020-12-28 04:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 04:19:10 --> Input Class Initialized
INFO - 2020-12-28 04:19:10 --> Language Class Initialized
INFO - 2020-12-28 04:19:10 --> Language Class Initialized
INFO - 2020-12-28 04:19:10 --> Config Class Initialized
INFO - 2020-12-28 04:19:10 --> Loader Class Initialized
INFO - 2020-12-28 04:19:10 --> Helper loaded: url_helper
INFO - 2020-12-28 04:19:10 --> Helper loaded: file_helper
INFO - 2020-12-28 04:19:10 --> Helper loaded: form_helper
INFO - 2020-12-28 04:19:10 --> Helper loaded: my_helper
INFO - 2020-12-28 04:19:10 --> Database Driver Class Initialized
DEBUG - 2020-12-28 04:19:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 04:19:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 04:19:10 --> Controller Class Initialized
DEBUG - 2020-12-28 04:19:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-12-28 04:19:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-28 04:19:10 --> Final output sent to browser
DEBUG - 2020-12-28 04:19:10 --> Total execution time: 0.3808
INFO - 2020-12-28 04:19:10 --> Config Class Initialized
INFO - 2020-12-28 04:19:10 --> Hooks Class Initialized
DEBUG - 2020-12-28 04:19:10 --> UTF-8 Support Enabled
INFO - 2020-12-28 04:19:10 --> Utf8 Class Initialized
INFO - 2020-12-28 04:19:10 --> URI Class Initialized
INFO - 2020-12-28 04:19:10 --> Router Class Initialized
INFO - 2020-12-28 04:19:10 --> Output Class Initialized
INFO - 2020-12-28 04:19:10 --> Security Class Initialized
DEBUG - 2020-12-28 04:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 04:19:10 --> Input Class Initialized
INFO - 2020-12-28 04:19:11 --> Language Class Initialized
INFO - 2020-12-28 04:19:11 --> Language Class Initialized
INFO - 2020-12-28 04:19:11 --> Config Class Initialized
INFO - 2020-12-28 04:19:11 --> Loader Class Initialized
INFO - 2020-12-28 04:19:11 --> Helper loaded: url_helper
INFO - 2020-12-28 04:19:11 --> Helper loaded: file_helper
INFO - 2020-12-28 04:19:11 --> Helper loaded: form_helper
INFO - 2020-12-28 04:19:11 --> Helper loaded: my_helper
INFO - 2020-12-28 04:19:11 --> Database Driver Class Initialized
DEBUG - 2020-12-28 04:19:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 04:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 04:19:11 --> Controller Class Initialized
INFO - 2020-12-28 04:19:12 --> Config Class Initialized
INFO - 2020-12-28 04:19:12 --> Hooks Class Initialized
DEBUG - 2020-12-28 04:19:12 --> UTF-8 Support Enabled
INFO - 2020-12-28 04:19:12 --> Utf8 Class Initialized
INFO - 2020-12-28 04:19:12 --> URI Class Initialized
INFO - 2020-12-28 04:19:12 --> Router Class Initialized
INFO - 2020-12-28 04:19:12 --> Output Class Initialized
INFO - 2020-12-28 04:19:12 --> Security Class Initialized
DEBUG - 2020-12-28 04:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-28 04:19:12 --> Input Class Initialized
INFO - 2020-12-28 04:19:12 --> Language Class Initialized
INFO - 2020-12-28 04:19:12 --> Language Class Initialized
INFO - 2020-12-28 04:19:12 --> Config Class Initialized
INFO - 2020-12-28 04:19:12 --> Loader Class Initialized
INFO - 2020-12-28 04:19:12 --> Helper loaded: url_helper
INFO - 2020-12-28 04:19:12 --> Helper loaded: file_helper
INFO - 2020-12-28 04:19:12 --> Helper loaded: form_helper
INFO - 2020-12-28 04:19:12 --> Helper loaded: my_helper
INFO - 2020-12-28 04:19:12 --> Database Driver Class Initialized
DEBUG - 2020-12-28 04:19:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-28 04:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-28 04:19:12 --> Controller Class Initialized
INFO - 2020-12-28 04:19:12 --> Final output sent to browser
DEBUG - 2020-12-28 04:19:12 --> Total execution time: 0.3078
