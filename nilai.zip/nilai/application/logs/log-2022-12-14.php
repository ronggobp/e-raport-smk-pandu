<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-12-14 09:07:32 --> Config Class Initialized
INFO - 2022-12-14 09:07:32 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:07:32 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:07:32 --> Utf8 Class Initialized
INFO - 2022-12-14 09:07:32 --> URI Class Initialized
DEBUG - 2022-12-14 09:07:32 --> No URI present. Default controller set.
INFO - 2022-12-14 09:07:32 --> Router Class Initialized
INFO - 2022-12-14 09:07:32 --> Output Class Initialized
INFO - 2022-12-14 09:07:32 --> Security Class Initialized
DEBUG - 2022-12-14 09:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:07:32 --> Input Class Initialized
INFO - 2022-12-14 09:07:32 --> Language Class Initialized
INFO - 2022-12-14 09:07:32 --> Language Class Initialized
INFO - 2022-12-14 09:07:32 --> Config Class Initialized
INFO - 2022-12-14 09:07:32 --> Loader Class Initialized
INFO - 2022-12-14 09:07:32 --> Helper loaded: url_helper
INFO - 2022-12-14 09:07:32 --> Helper loaded: file_helper
INFO - 2022-12-14 09:07:32 --> Helper loaded: form_helper
INFO - 2022-12-14 09:07:32 --> Helper loaded: my_helper
INFO - 2022-12-14 09:07:32 --> Database Driver Class Initialized
DEBUG - 2022-12-14 09:07:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-14 09:07:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-14 09:07:32 --> Controller Class Initialized
INFO - 2022-12-14 09:16:49 --> Config Class Initialized
INFO - 2022-12-14 09:16:49 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:16:49 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:16:49 --> Utf8 Class Initialized
INFO - 2022-12-14 09:16:49 --> URI Class Initialized
DEBUG - 2022-12-14 09:16:49 --> No URI present. Default controller set.
INFO - 2022-12-14 09:16:49 --> Router Class Initialized
INFO - 2022-12-14 09:16:49 --> Output Class Initialized
INFO - 2022-12-14 09:16:49 --> Security Class Initialized
DEBUG - 2022-12-14 09:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:16:49 --> Input Class Initialized
INFO - 2022-12-14 09:16:49 --> Language Class Initialized
INFO - 2022-12-14 09:16:49 --> Language Class Initialized
INFO - 2022-12-14 09:16:49 --> Config Class Initialized
INFO - 2022-12-14 09:16:49 --> Loader Class Initialized
INFO - 2022-12-14 09:16:49 --> Helper loaded: url_helper
INFO - 2022-12-14 09:16:49 --> Helper loaded: file_helper
INFO - 2022-12-14 09:16:49 --> Helper loaded: form_helper
INFO - 2022-12-14 09:16:49 --> Helper loaded: my_helper
INFO - 2022-12-14 09:16:49 --> Database Driver Class Initialized
DEBUG - 2022-12-14 09:16:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-14 09:16:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-14 09:16:49 --> Controller Class Initialized
INFO - 2022-12-14 09:16:49 --> Config Class Initialized
INFO - 2022-12-14 09:16:49 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:16:49 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:16:49 --> Utf8 Class Initialized
INFO - 2022-12-14 09:16:49 --> URI Class Initialized
INFO - 2022-12-14 09:16:49 --> Router Class Initialized
INFO - 2022-12-14 09:16:49 --> Output Class Initialized
INFO - 2022-12-14 09:16:49 --> Security Class Initialized
DEBUG - 2022-12-14 09:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:16:49 --> Input Class Initialized
INFO - 2022-12-14 09:16:49 --> Language Class Initialized
ERROR - 2022-12-14 09:16:49 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:16:56 --> Config Class Initialized
INFO - 2022-12-14 09:16:56 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:16:56 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:16:56 --> Utf8 Class Initialized
INFO - 2022-12-14 09:16:56 --> URI Class Initialized
DEBUG - 2022-12-14 09:16:56 --> No URI present. Default controller set.
INFO - 2022-12-14 09:16:56 --> Router Class Initialized
INFO - 2022-12-14 09:16:56 --> Output Class Initialized
INFO - 2022-12-14 09:16:56 --> Security Class Initialized
DEBUG - 2022-12-14 09:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:16:56 --> Input Class Initialized
INFO - 2022-12-14 09:16:56 --> Language Class Initialized
INFO - 2022-12-14 09:16:56 --> Language Class Initialized
INFO - 2022-12-14 09:16:56 --> Config Class Initialized
INFO - 2022-12-14 09:16:56 --> Loader Class Initialized
INFO - 2022-12-14 09:16:56 --> Helper loaded: url_helper
INFO - 2022-12-14 09:16:56 --> Helper loaded: file_helper
INFO - 2022-12-14 09:16:56 --> Helper loaded: form_helper
INFO - 2022-12-14 09:16:56 --> Helper loaded: my_helper
INFO - 2022-12-14 09:16:56 --> Database Driver Class Initialized
DEBUG - 2022-12-14 09:16:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-14 09:16:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-14 09:16:56 --> Controller Class Initialized
INFO - 2022-12-14 09:16:56 --> Config Class Initialized
INFO - 2022-12-14 09:16:56 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:16:56 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:16:56 --> Utf8 Class Initialized
INFO - 2022-12-14 09:16:56 --> URI Class Initialized
INFO - 2022-12-14 09:16:56 --> Router Class Initialized
INFO - 2022-12-14 09:16:56 --> Output Class Initialized
INFO - 2022-12-14 09:16:56 --> Security Class Initialized
DEBUG - 2022-12-14 09:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:16:56 --> Input Class Initialized
INFO - 2022-12-14 09:16:56 --> Language Class Initialized
ERROR - 2022-12-14 09:16:56 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:17:20 --> Config Class Initialized
INFO - 2022-12-14 09:17:20 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:17:20 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:17:20 --> Utf8 Class Initialized
INFO - 2022-12-14 09:17:20 --> URI Class Initialized
DEBUG - 2022-12-14 09:17:20 --> No URI present. Default controller set.
INFO - 2022-12-14 09:17:20 --> Router Class Initialized
INFO - 2022-12-14 09:17:20 --> Output Class Initialized
INFO - 2022-12-14 09:17:20 --> Security Class Initialized
DEBUG - 2022-12-14 09:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:17:20 --> Input Class Initialized
INFO - 2022-12-14 09:17:20 --> Language Class Initialized
INFO - 2022-12-14 09:17:20 --> Language Class Initialized
INFO - 2022-12-14 09:17:20 --> Config Class Initialized
INFO - 2022-12-14 09:17:20 --> Loader Class Initialized
INFO - 2022-12-14 09:17:20 --> Helper loaded: url_helper
INFO - 2022-12-14 09:17:20 --> Helper loaded: file_helper
INFO - 2022-12-14 09:17:20 --> Helper loaded: form_helper
INFO - 2022-12-14 09:17:20 --> Helper loaded: my_helper
INFO - 2022-12-14 09:17:20 --> Database Driver Class Initialized
DEBUG - 2022-12-14 09:17:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-14 09:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-14 09:17:20 --> Controller Class Initialized
INFO - 2022-12-14 09:17:20 --> Config Class Initialized
INFO - 2022-12-14 09:17:20 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:17:20 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:17:20 --> Utf8 Class Initialized
INFO - 2022-12-14 09:17:20 --> URI Class Initialized
INFO - 2022-12-14 09:17:20 --> Router Class Initialized
INFO - 2022-12-14 09:17:20 --> Output Class Initialized
INFO - 2022-12-14 09:17:20 --> Security Class Initialized
DEBUG - 2022-12-14 09:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:17:20 --> Input Class Initialized
INFO - 2022-12-14 09:17:20 --> Language Class Initialized
ERROR - 2022-12-14 09:17:20 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:30:29 --> Config Class Initialized
INFO - 2022-12-14 09:30:29 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:30:29 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:30:29 --> Utf8 Class Initialized
INFO - 2022-12-14 09:30:29 --> URI Class Initialized
INFO - 2022-12-14 09:30:29 --> Router Class Initialized
INFO - 2022-12-14 09:30:29 --> Output Class Initialized
INFO - 2022-12-14 09:30:29 --> Security Class Initialized
DEBUG - 2022-12-14 09:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:30:29 --> Input Class Initialized
INFO - 2022-12-14 09:30:29 --> Language Class Initialized
INFO - 2022-12-14 09:30:29 --> Language Class Initialized
INFO - 2022-12-14 09:30:29 --> Config Class Initialized
INFO - 2022-12-14 09:30:29 --> Loader Class Initialized
INFO - 2022-12-14 09:30:29 --> Helper loaded: url_helper
INFO - 2022-12-14 09:30:29 --> Helper loaded: file_helper
INFO - 2022-12-14 09:30:29 --> Helper loaded: form_helper
INFO - 2022-12-14 09:30:29 --> Helper loaded: my_helper
INFO - 2022-12-14 09:30:29 --> Database Driver Class Initialized
DEBUG - 2022-12-14 09:30:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-14 09:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-14 09:30:29 --> Controller Class Initialized
DEBUG - 2022-12-14 09:30:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-12-14 09:30:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-14 09:30:29 --> Final output sent to browser
DEBUG - 2022-12-14 09:30:29 --> Total execution time: 0.0948
INFO - 2022-12-14 09:31:39 --> Config Class Initialized
INFO - 2022-12-14 09:31:39 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:31:39 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:31:39 --> Utf8 Class Initialized
INFO - 2022-12-14 09:31:39 --> URI Class Initialized
INFO - 2022-12-14 09:31:39 --> Router Class Initialized
INFO - 2022-12-14 09:31:39 --> Output Class Initialized
INFO - 2022-12-14 09:31:39 --> Security Class Initialized
DEBUG - 2022-12-14 09:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:31:39 --> Input Class Initialized
INFO - 2022-12-14 09:31:39 --> Language Class Initialized
INFO - 2022-12-14 09:31:39 --> Language Class Initialized
INFO - 2022-12-14 09:31:39 --> Config Class Initialized
INFO - 2022-12-14 09:31:39 --> Loader Class Initialized
INFO - 2022-12-14 09:31:39 --> Helper loaded: url_helper
INFO - 2022-12-14 09:31:39 --> Helper loaded: file_helper
INFO - 2022-12-14 09:31:39 --> Helper loaded: form_helper
INFO - 2022-12-14 09:31:39 --> Helper loaded: my_helper
INFO - 2022-12-14 09:31:39 --> Database Driver Class Initialized
DEBUG - 2022-12-14 09:31:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-14 09:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-14 09:31:39 --> Controller Class Initialized
DEBUG - 2022-12-14 09:31:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-12-14 09:31:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-14 09:31:39 --> Final output sent to browser
DEBUG - 2022-12-14 09:31:39 --> Total execution time: 0.0539
INFO - 2022-12-14 09:32:06 --> Config Class Initialized
INFO - 2022-12-14 09:32:06 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:06 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:06 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:06 --> URI Class Initialized
INFO - 2022-12-14 09:32:06 --> Router Class Initialized
INFO - 2022-12-14 09:32:07 --> Output Class Initialized
INFO - 2022-12-14 09:32:07 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:07 --> Input Class Initialized
INFO - 2022-12-14 09:32:07 --> Language Class Initialized
INFO - 2022-12-14 09:32:07 --> Language Class Initialized
INFO - 2022-12-14 09:32:07 --> Config Class Initialized
INFO - 2022-12-14 09:32:07 --> Loader Class Initialized
INFO - 2022-12-14 09:32:07 --> Helper loaded: url_helper
INFO - 2022-12-14 09:32:07 --> Helper loaded: file_helper
INFO - 2022-12-14 09:32:07 --> Helper loaded: form_helper
INFO - 2022-12-14 09:32:07 --> Helper loaded: my_helper
INFO - 2022-12-14 09:32:07 --> Database Driver Class Initialized
DEBUG - 2022-12-14 09:32:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-14 09:32:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-14 09:32:07 --> Controller Class Initialized
DEBUG - 2022-12-14 09:32:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-12-14 09:32:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-14 09:32:07 --> Final output sent to browser
DEBUG - 2022-12-14 09:32:07 --> Total execution time: 0.0419
INFO - 2022-12-14 09:32:07 --> Config Class Initialized
INFO - 2022-12-14 09:32:07 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:07 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:07 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:07 --> URI Class Initialized
INFO - 2022-12-14 09:32:07 --> Router Class Initialized
INFO - 2022-12-14 09:32:07 --> Output Class Initialized
INFO - 2022-12-14 09:32:07 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:07 --> Input Class Initialized
INFO - 2022-12-14 09:32:07 --> Language Class Initialized
ERROR - 2022-12-14 09:32:07 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:07 --> Config Class Initialized
INFO - 2022-12-14 09:32:07 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:07 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:07 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:07 --> URI Class Initialized
INFO - 2022-12-14 09:32:07 --> Router Class Initialized
INFO - 2022-12-14 09:32:07 --> Output Class Initialized
INFO - 2022-12-14 09:32:07 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:07 --> Input Class Initialized
INFO - 2022-12-14 09:32:07 --> Language Class Initialized
ERROR - 2022-12-14 09:32:07 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:07 --> Config Class Initialized
INFO - 2022-12-14 09:32:07 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:07 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:07 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:07 --> URI Class Initialized
INFO - 2022-12-14 09:32:07 --> Router Class Initialized
INFO - 2022-12-14 09:32:07 --> Output Class Initialized
INFO - 2022-12-14 09:32:07 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:07 --> Input Class Initialized
INFO - 2022-12-14 09:32:07 --> Language Class Initialized
ERROR - 2022-12-14 09:32:07 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:07 --> Config Class Initialized
INFO - 2022-12-14 09:32:07 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:07 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:07 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:07 --> URI Class Initialized
INFO - 2022-12-14 09:32:07 --> Router Class Initialized
INFO - 2022-12-14 09:32:07 --> Output Class Initialized
INFO - 2022-12-14 09:32:07 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:07 --> Input Class Initialized
INFO - 2022-12-14 09:32:07 --> Language Class Initialized
ERROR - 2022-12-14 09:32:07 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:07 --> Config Class Initialized
INFO - 2022-12-14 09:32:07 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:07 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:07 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:07 --> URI Class Initialized
INFO - 2022-12-14 09:32:07 --> Router Class Initialized
INFO - 2022-12-14 09:32:07 --> Output Class Initialized
INFO - 2022-12-14 09:32:07 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:07 --> Input Class Initialized
INFO - 2022-12-14 09:32:07 --> Language Class Initialized
ERROR - 2022-12-14 09:32:07 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:07 --> Config Class Initialized
INFO - 2022-12-14 09:32:07 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:07 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:07 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:07 --> URI Class Initialized
INFO - 2022-12-14 09:32:07 --> Router Class Initialized
INFO - 2022-12-14 09:32:07 --> Output Class Initialized
INFO - 2022-12-14 09:32:07 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:07 --> Input Class Initialized
INFO - 2022-12-14 09:32:07 --> Language Class Initialized
ERROR - 2022-12-14 09:32:07 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:07 --> Config Class Initialized
INFO - 2022-12-14 09:32:07 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:07 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:07 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:07 --> URI Class Initialized
INFO - 2022-12-14 09:32:07 --> Router Class Initialized
INFO - 2022-12-14 09:32:07 --> Output Class Initialized
INFO - 2022-12-14 09:32:07 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:07 --> Input Class Initialized
INFO - 2022-12-14 09:32:07 --> Language Class Initialized
ERROR - 2022-12-14 09:32:07 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:07 --> Config Class Initialized
INFO - 2022-12-14 09:32:07 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:07 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:07 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:07 --> URI Class Initialized
INFO - 2022-12-14 09:32:07 --> Router Class Initialized
INFO - 2022-12-14 09:32:07 --> Output Class Initialized
INFO - 2022-12-14 09:32:07 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:07 --> Input Class Initialized
INFO - 2022-12-14 09:32:07 --> Language Class Initialized
ERROR - 2022-12-14 09:32:07 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:07 --> Config Class Initialized
INFO - 2022-12-14 09:32:07 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:07 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:07 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:07 --> URI Class Initialized
INFO - 2022-12-14 09:32:07 --> Router Class Initialized
INFO - 2022-12-14 09:32:07 --> Output Class Initialized
INFO - 2022-12-14 09:32:07 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:07 --> Input Class Initialized
INFO - 2022-12-14 09:32:07 --> Language Class Initialized
ERROR - 2022-12-14 09:32:07 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:07 --> Config Class Initialized
INFO - 2022-12-14 09:32:07 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:07 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:07 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:07 --> URI Class Initialized
INFO - 2022-12-14 09:32:07 --> Router Class Initialized
INFO - 2022-12-14 09:32:07 --> Output Class Initialized
INFO - 2022-12-14 09:32:07 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:07 --> Input Class Initialized
INFO - 2022-12-14 09:32:07 --> Language Class Initialized
ERROR - 2022-12-14 09:32:07 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:07 --> Config Class Initialized
INFO - 2022-12-14 09:32:07 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:07 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:07 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:07 --> URI Class Initialized
INFO - 2022-12-14 09:32:07 --> Router Class Initialized
INFO - 2022-12-14 09:32:07 --> Output Class Initialized
INFO - 2022-12-14 09:32:07 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:07 --> Input Class Initialized
INFO - 2022-12-14 09:32:07 --> Language Class Initialized
ERROR - 2022-12-14 09:32:07 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:07 --> Config Class Initialized
INFO - 2022-12-14 09:32:07 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:07 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:07 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:07 --> URI Class Initialized
INFO - 2022-12-14 09:32:07 --> Router Class Initialized
INFO - 2022-12-14 09:32:07 --> Output Class Initialized
INFO - 2022-12-14 09:32:07 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:07 --> Input Class Initialized
INFO - 2022-12-14 09:32:07 --> Language Class Initialized
ERROR - 2022-12-14 09:32:07 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:07 --> Config Class Initialized
INFO - 2022-12-14 09:32:07 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:07 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:07 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:07 --> URI Class Initialized
INFO - 2022-12-14 09:32:07 --> Router Class Initialized
INFO - 2022-12-14 09:32:07 --> Output Class Initialized
INFO - 2022-12-14 09:32:07 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:07 --> Input Class Initialized
INFO - 2022-12-14 09:32:07 --> Language Class Initialized
ERROR - 2022-12-14 09:32:07 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:07 --> Config Class Initialized
INFO - 2022-12-14 09:32:07 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:07 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:07 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:07 --> URI Class Initialized
INFO - 2022-12-14 09:32:07 --> Router Class Initialized
INFO - 2022-12-14 09:32:07 --> Output Class Initialized
INFO - 2022-12-14 09:32:07 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:07 --> Input Class Initialized
INFO - 2022-12-14 09:32:07 --> Language Class Initialized
ERROR - 2022-12-14 09:32:07 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:07 --> Config Class Initialized
INFO - 2022-12-14 09:32:07 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:07 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:07 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:07 --> URI Class Initialized
INFO - 2022-12-14 09:32:07 --> Router Class Initialized
INFO - 2022-12-14 09:32:07 --> Output Class Initialized
INFO - 2022-12-14 09:32:07 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:07 --> Input Class Initialized
INFO - 2022-12-14 09:32:07 --> Language Class Initialized
ERROR - 2022-12-14 09:32:07 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:07 --> Config Class Initialized
INFO - 2022-12-14 09:32:07 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:07 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:07 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:07 --> URI Class Initialized
INFO - 2022-12-14 09:32:07 --> Router Class Initialized
INFO - 2022-12-14 09:32:07 --> Output Class Initialized
INFO - 2022-12-14 09:32:07 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:07 --> Input Class Initialized
INFO - 2022-12-14 09:32:07 --> Language Class Initialized
ERROR - 2022-12-14 09:32:07 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:07 --> Config Class Initialized
INFO - 2022-12-14 09:32:07 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:07 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:07 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:07 --> URI Class Initialized
INFO - 2022-12-14 09:32:07 --> Router Class Initialized
INFO - 2022-12-14 09:32:07 --> Output Class Initialized
INFO - 2022-12-14 09:32:07 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:07 --> Input Class Initialized
INFO - 2022-12-14 09:32:07 --> Language Class Initialized
ERROR - 2022-12-14 09:32:07 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:07 --> Config Class Initialized
INFO - 2022-12-14 09:32:07 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:07 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:07 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:07 --> URI Class Initialized
INFO - 2022-12-14 09:32:07 --> Router Class Initialized
INFO - 2022-12-14 09:32:07 --> Output Class Initialized
INFO - 2022-12-14 09:32:07 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:07 --> Input Class Initialized
INFO - 2022-12-14 09:32:07 --> Language Class Initialized
ERROR - 2022-12-14 09:32:07 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:07 --> Config Class Initialized
INFO - 2022-12-14 09:32:07 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:07 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:07 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:07 --> URI Class Initialized
INFO - 2022-12-14 09:32:07 --> Router Class Initialized
INFO - 2022-12-14 09:32:07 --> Output Class Initialized
INFO - 2022-12-14 09:32:07 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:07 --> Input Class Initialized
INFO - 2022-12-14 09:32:07 --> Language Class Initialized
ERROR - 2022-12-14 09:32:07 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:07 --> Config Class Initialized
INFO - 2022-12-14 09:32:07 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:07 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:07 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:07 --> URI Class Initialized
INFO - 2022-12-14 09:32:07 --> Router Class Initialized
INFO - 2022-12-14 09:32:07 --> Output Class Initialized
INFO - 2022-12-14 09:32:07 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:07 --> Input Class Initialized
INFO - 2022-12-14 09:32:07 --> Language Class Initialized
ERROR - 2022-12-14 09:32:07 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:07 --> Config Class Initialized
INFO - 2022-12-14 09:32:07 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:07 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:07 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:07 --> URI Class Initialized
INFO - 2022-12-14 09:32:07 --> Router Class Initialized
INFO - 2022-12-14 09:32:07 --> Output Class Initialized
INFO - 2022-12-14 09:32:07 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:07 --> Input Class Initialized
INFO - 2022-12-14 09:32:07 --> Language Class Initialized
ERROR - 2022-12-14 09:32:07 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:17 --> Config Class Initialized
INFO - 2022-12-14 09:32:17 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:17 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:17 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:17 --> URI Class Initialized
INFO - 2022-12-14 09:32:17 --> Router Class Initialized
INFO - 2022-12-14 09:32:17 --> Output Class Initialized
INFO - 2022-12-14 09:32:17 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:17 --> Input Class Initialized
INFO - 2022-12-14 09:32:17 --> Language Class Initialized
INFO - 2022-12-14 09:32:17 --> Language Class Initialized
INFO - 2022-12-14 09:32:17 --> Config Class Initialized
INFO - 2022-12-14 09:32:17 --> Loader Class Initialized
INFO - 2022-12-14 09:32:17 --> Helper loaded: url_helper
INFO - 2022-12-14 09:32:17 --> Helper loaded: file_helper
INFO - 2022-12-14 09:32:17 --> Helper loaded: form_helper
INFO - 2022-12-14 09:32:17 --> Helper loaded: my_helper
INFO - 2022-12-14 09:32:17 --> Database Driver Class Initialized
DEBUG - 2022-12-14 09:32:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-14 09:32:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-14 09:32:17 --> Controller Class Initialized
DEBUG - 2022-12-14 09:32:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-12-14 09:32:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-14 09:32:17 --> Final output sent to browser
DEBUG - 2022-12-14 09:32:17 --> Total execution time: 0.0522
INFO - 2022-12-14 09:32:17 --> Config Class Initialized
INFO - 2022-12-14 09:32:17 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:17 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:17 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:17 --> URI Class Initialized
INFO - 2022-12-14 09:32:17 --> Router Class Initialized
INFO - 2022-12-14 09:32:17 --> Output Class Initialized
INFO - 2022-12-14 09:32:17 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:17 --> Input Class Initialized
INFO - 2022-12-14 09:32:17 --> Language Class Initialized
ERROR - 2022-12-14 09:32:17 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:17 --> Config Class Initialized
INFO - 2022-12-14 09:32:17 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:17 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:17 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:17 --> URI Class Initialized
INFO - 2022-12-14 09:32:17 --> Router Class Initialized
INFO - 2022-12-14 09:32:17 --> Output Class Initialized
INFO - 2022-12-14 09:32:17 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:17 --> Input Class Initialized
INFO - 2022-12-14 09:32:17 --> Language Class Initialized
ERROR - 2022-12-14 09:32:17 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:17 --> Config Class Initialized
INFO - 2022-12-14 09:32:17 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:17 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:17 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:17 --> URI Class Initialized
INFO - 2022-12-14 09:32:17 --> Router Class Initialized
INFO - 2022-12-14 09:32:17 --> Output Class Initialized
INFO - 2022-12-14 09:32:17 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:17 --> Input Class Initialized
INFO - 2022-12-14 09:32:17 --> Language Class Initialized
ERROR - 2022-12-14 09:32:17 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:17 --> Config Class Initialized
INFO - 2022-12-14 09:32:17 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:17 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:17 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:17 --> URI Class Initialized
INFO - 2022-12-14 09:32:17 --> Router Class Initialized
INFO - 2022-12-14 09:32:17 --> Output Class Initialized
INFO - 2022-12-14 09:32:17 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:17 --> Input Class Initialized
INFO - 2022-12-14 09:32:17 --> Language Class Initialized
ERROR - 2022-12-14 09:32:17 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:18 --> Config Class Initialized
INFO - 2022-12-14 09:32:18 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:18 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:18 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:18 --> URI Class Initialized
INFO - 2022-12-14 09:32:18 --> Router Class Initialized
INFO - 2022-12-14 09:32:18 --> Output Class Initialized
INFO - 2022-12-14 09:32:18 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:18 --> Input Class Initialized
INFO - 2022-12-14 09:32:18 --> Language Class Initialized
ERROR - 2022-12-14 09:32:18 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:18 --> Config Class Initialized
INFO - 2022-12-14 09:32:18 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:18 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:18 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:18 --> URI Class Initialized
INFO - 2022-12-14 09:32:18 --> Router Class Initialized
INFO - 2022-12-14 09:32:18 --> Output Class Initialized
INFO - 2022-12-14 09:32:18 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:18 --> Input Class Initialized
INFO - 2022-12-14 09:32:18 --> Language Class Initialized
ERROR - 2022-12-14 09:32:18 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:18 --> Config Class Initialized
INFO - 2022-12-14 09:32:18 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:18 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:18 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:18 --> URI Class Initialized
INFO - 2022-12-14 09:32:18 --> Router Class Initialized
INFO - 2022-12-14 09:32:18 --> Output Class Initialized
INFO - 2022-12-14 09:32:18 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:18 --> Input Class Initialized
INFO - 2022-12-14 09:32:18 --> Language Class Initialized
ERROR - 2022-12-14 09:32:18 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:18 --> Config Class Initialized
INFO - 2022-12-14 09:32:18 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:18 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:18 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:18 --> URI Class Initialized
INFO - 2022-12-14 09:32:18 --> Router Class Initialized
INFO - 2022-12-14 09:32:18 --> Output Class Initialized
INFO - 2022-12-14 09:32:18 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:18 --> Input Class Initialized
INFO - 2022-12-14 09:32:18 --> Language Class Initialized
ERROR - 2022-12-14 09:32:18 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:18 --> Config Class Initialized
INFO - 2022-12-14 09:32:18 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:18 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:18 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:18 --> URI Class Initialized
INFO - 2022-12-14 09:32:18 --> Router Class Initialized
INFO - 2022-12-14 09:32:18 --> Output Class Initialized
INFO - 2022-12-14 09:32:18 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:18 --> Input Class Initialized
INFO - 2022-12-14 09:32:18 --> Language Class Initialized
ERROR - 2022-12-14 09:32:18 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:18 --> Config Class Initialized
INFO - 2022-12-14 09:32:18 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:18 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:18 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:18 --> URI Class Initialized
INFO - 2022-12-14 09:32:18 --> Router Class Initialized
INFO - 2022-12-14 09:32:18 --> Output Class Initialized
INFO - 2022-12-14 09:32:18 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:18 --> Input Class Initialized
INFO - 2022-12-14 09:32:18 --> Language Class Initialized
ERROR - 2022-12-14 09:32:18 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:18 --> Config Class Initialized
INFO - 2022-12-14 09:32:18 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:18 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:18 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:18 --> URI Class Initialized
INFO - 2022-12-14 09:32:18 --> Router Class Initialized
INFO - 2022-12-14 09:32:18 --> Output Class Initialized
INFO - 2022-12-14 09:32:18 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:18 --> Input Class Initialized
INFO - 2022-12-14 09:32:18 --> Language Class Initialized
ERROR - 2022-12-14 09:32:18 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:18 --> Config Class Initialized
INFO - 2022-12-14 09:32:18 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:18 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:18 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:18 --> URI Class Initialized
INFO - 2022-12-14 09:32:18 --> Router Class Initialized
INFO - 2022-12-14 09:32:18 --> Output Class Initialized
INFO - 2022-12-14 09:32:18 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:18 --> Input Class Initialized
INFO - 2022-12-14 09:32:18 --> Language Class Initialized
ERROR - 2022-12-14 09:32:18 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:18 --> Config Class Initialized
INFO - 2022-12-14 09:32:18 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:18 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:18 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:18 --> URI Class Initialized
INFO - 2022-12-14 09:32:18 --> Router Class Initialized
INFO - 2022-12-14 09:32:18 --> Output Class Initialized
INFO - 2022-12-14 09:32:18 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:18 --> Input Class Initialized
INFO - 2022-12-14 09:32:18 --> Language Class Initialized
ERROR - 2022-12-14 09:32:18 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:18 --> Config Class Initialized
INFO - 2022-12-14 09:32:18 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:18 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:18 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:18 --> URI Class Initialized
INFO - 2022-12-14 09:32:18 --> Router Class Initialized
INFO - 2022-12-14 09:32:18 --> Output Class Initialized
INFO - 2022-12-14 09:32:18 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:18 --> Input Class Initialized
INFO - 2022-12-14 09:32:18 --> Language Class Initialized
ERROR - 2022-12-14 09:32:18 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:18 --> Config Class Initialized
INFO - 2022-12-14 09:32:18 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:18 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:18 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:18 --> URI Class Initialized
INFO - 2022-12-14 09:32:18 --> Router Class Initialized
INFO - 2022-12-14 09:32:18 --> Output Class Initialized
INFO - 2022-12-14 09:32:18 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:18 --> Input Class Initialized
INFO - 2022-12-14 09:32:18 --> Language Class Initialized
ERROR - 2022-12-14 09:32:18 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:18 --> Config Class Initialized
INFO - 2022-12-14 09:32:18 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:18 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:18 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:18 --> URI Class Initialized
INFO - 2022-12-14 09:32:18 --> Router Class Initialized
INFO - 2022-12-14 09:32:18 --> Output Class Initialized
INFO - 2022-12-14 09:32:18 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:18 --> Input Class Initialized
INFO - 2022-12-14 09:32:18 --> Language Class Initialized
ERROR - 2022-12-14 09:32:18 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:18 --> Config Class Initialized
INFO - 2022-12-14 09:32:18 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:18 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:18 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:18 --> URI Class Initialized
INFO - 2022-12-14 09:32:18 --> Router Class Initialized
INFO - 2022-12-14 09:32:18 --> Output Class Initialized
INFO - 2022-12-14 09:32:18 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:18 --> Input Class Initialized
INFO - 2022-12-14 09:32:18 --> Language Class Initialized
ERROR - 2022-12-14 09:32:18 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:18 --> Config Class Initialized
INFO - 2022-12-14 09:32:18 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:18 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:18 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:18 --> URI Class Initialized
INFO - 2022-12-14 09:32:18 --> Router Class Initialized
INFO - 2022-12-14 09:32:18 --> Output Class Initialized
INFO - 2022-12-14 09:32:18 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:18 --> Input Class Initialized
INFO - 2022-12-14 09:32:18 --> Language Class Initialized
ERROR - 2022-12-14 09:32:18 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:18 --> Config Class Initialized
INFO - 2022-12-14 09:32:18 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:18 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:18 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:18 --> URI Class Initialized
INFO - 2022-12-14 09:32:18 --> Router Class Initialized
INFO - 2022-12-14 09:32:18 --> Output Class Initialized
INFO - 2022-12-14 09:32:18 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:18 --> Input Class Initialized
INFO - 2022-12-14 09:32:18 --> Language Class Initialized
ERROR - 2022-12-14 09:32:18 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:18 --> Config Class Initialized
INFO - 2022-12-14 09:32:18 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:18 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:18 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:18 --> URI Class Initialized
INFO - 2022-12-14 09:32:18 --> Router Class Initialized
INFO - 2022-12-14 09:32:18 --> Output Class Initialized
INFO - 2022-12-14 09:32:18 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:18 --> Input Class Initialized
INFO - 2022-12-14 09:32:18 --> Language Class Initialized
ERROR - 2022-12-14 09:32:18 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:21 --> Config Class Initialized
INFO - 2022-12-14 09:32:21 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:21 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:21 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:21 --> URI Class Initialized
INFO - 2022-12-14 09:32:21 --> Router Class Initialized
INFO - 2022-12-14 09:32:21 --> Output Class Initialized
INFO - 2022-12-14 09:32:21 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:21 --> Input Class Initialized
INFO - 2022-12-14 09:32:21 --> Language Class Initialized
INFO - 2022-12-14 09:32:21 --> Language Class Initialized
INFO - 2022-12-14 09:32:21 --> Config Class Initialized
INFO - 2022-12-14 09:32:21 --> Loader Class Initialized
INFO - 2022-12-14 09:32:21 --> Helper loaded: url_helper
INFO - 2022-12-14 09:32:21 --> Helper loaded: file_helper
INFO - 2022-12-14 09:32:21 --> Helper loaded: form_helper
INFO - 2022-12-14 09:32:21 --> Helper loaded: my_helper
INFO - 2022-12-14 09:32:21 --> Database Driver Class Initialized
DEBUG - 2022-12-14 09:32:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-14 09:32:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-14 09:32:21 --> Controller Class Initialized
DEBUG - 2022-12-14 09:32:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-12-14 09:32:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-14 09:32:21 --> Final output sent to browser
DEBUG - 2022-12-14 09:32:21 --> Total execution time: 0.0617
INFO - 2022-12-14 09:32:21 --> Config Class Initialized
INFO - 2022-12-14 09:32:21 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:21 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:21 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:21 --> URI Class Initialized
INFO - 2022-12-14 09:32:21 --> Router Class Initialized
INFO - 2022-12-14 09:32:21 --> Output Class Initialized
INFO - 2022-12-14 09:32:21 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:21 --> Input Class Initialized
INFO - 2022-12-14 09:32:21 --> Language Class Initialized
ERROR - 2022-12-14 09:32:21 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:21 --> Config Class Initialized
INFO - 2022-12-14 09:32:21 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:21 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:21 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:21 --> URI Class Initialized
INFO - 2022-12-14 09:32:21 --> Router Class Initialized
INFO - 2022-12-14 09:32:21 --> Output Class Initialized
INFO - 2022-12-14 09:32:21 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:21 --> Input Class Initialized
INFO - 2022-12-14 09:32:21 --> Language Class Initialized
ERROR - 2022-12-14 09:32:21 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:21 --> Config Class Initialized
INFO - 2022-12-14 09:32:21 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:21 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:21 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:21 --> URI Class Initialized
INFO - 2022-12-14 09:32:21 --> Router Class Initialized
INFO - 2022-12-14 09:32:21 --> Output Class Initialized
INFO - 2022-12-14 09:32:21 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:21 --> Input Class Initialized
INFO - 2022-12-14 09:32:21 --> Language Class Initialized
ERROR - 2022-12-14 09:32:21 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:21 --> Config Class Initialized
INFO - 2022-12-14 09:32:21 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:21 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:21 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:21 --> URI Class Initialized
INFO - 2022-12-14 09:32:21 --> Router Class Initialized
INFO - 2022-12-14 09:32:21 --> Output Class Initialized
INFO - 2022-12-14 09:32:21 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:21 --> Input Class Initialized
INFO - 2022-12-14 09:32:21 --> Language Class Initialized
ERROR - 2022-12-14 09:32:21 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:21 --> Config Class Initialized
INFO - 2022-12-14 09:32:21 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:21 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:21 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:21 --> URI Class Initialized
INFO - 2022-12-14 09:32:21 --> Router Class Initialized
INFO - 2022-12-14 09:32:21 --> Output Class Initialized
INFO - 2022-12-14 09:32:21 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:21 --> Input Class Initialized
INFO - 2022-12-14 09:32:21 --> Language Class Initialized
ERROR - 2022-12-14 09:32:21 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:21 --> Config Class Initialized
INFO - 2022-12-14 09:32:21 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:21 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:21 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:21 --> URI Class Initialized
INFO - 2022-12-14 09:32:21 --> Router Class Initialized
INFO - 2022-12-14 09:32:21 --> Output Class Initialized
INFO - 2022-12-14 09:32:21 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:21 --> Input Class Initialized
INFO - 2022-12-14 09:32:21 --> Language Class Initialized
ERROR - 2022-12-14 09:32:21 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:21 --> Config Class Initialized
INFO - 2022-12-14 09:32:21 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:21 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:21 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:21 --> URI Class Initialized
INFO - 2022-12-14 09:32:21 --> Router Class Initialized
INFO - 2022-12-14 09:32:21 --> Output Class Initialized
INFO - 2022-12-14 09:32:21 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:21 --> Input Class Initialized
INFO - 2022-12-14 09:32:21 --> Language Class Initialized
ERROR - 2022-12-14 09:32:21 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:21 --> Config Class Initialized
INFO - 2022-12-14 09:32:21 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:21 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:21 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:21 --> URI Class Initialized
INFO - 2022-12-14 09:32:21 --> Router Class Initialized
INFO - 2022-12-14 09:32:21 --> Output Class Initialized
INFO - 2022-12-14 09:32:21 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:21 --> Input Class Initialized
INFO - 2022-12-14 09:32:21 --> Language Class Initialized
ERROR - 2022-12-14 09:32:21 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:21 --> Config Class Initialized
INFO - 2022-12-14 09:32:21 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:21 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:21 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:21 --> URI Class Initialized
INFO - 2022-12-14 09:32:21 --> Router Class Initialized
INFO - 2022-12-14 09:32:21 --> Output Class Initialized
INFO - 2022-12-14 09:32:21 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:21 --> Input Class Initialized
INFO - 2022-12-14 09:32:21 --> Language Class Initialized
ERROR - 2022-12-14 09:32:21 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:21 --> Config Class Initialized
INFO - 2022-12-14 09:32:21 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:21 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:21 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:21 --> URI Class Initialized
INFO - 2022-12-14 09:32:21 --> Router Class Initialized
INFO - 2022-12-14 09:32:21 --> Output Class Initialized
INFO - 2022-12-14 09:32:21 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:21 --> Input Class Initialized
INFO - 2022-12-14 09:32:21 --> Language Class Initialized
ERROR - 2022-12-14 09:32:21 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:21 --> Config Class Initialized
INFO - 2022-12-14 09:32:21 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:21 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:21 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:21 --> URI Class Initialized
INFO - 2022-12-14 09:32:21 --> Router Class Initialized
INFO - 2022-12-14 09:32:21 --> Output Class Initialized
INFO - 2022-12-14 09:32:21 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:21 --> Input Class Initialized
INFO - 2022-12-14 09:32:21 --> Language Class Initialized
ERROR - 2022-12-14 09:32:21 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:22 --> Config Class Initialized
INFO - 2022-12-14 09:32:22 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:22 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:22 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:22 --> URI Class Initialized
INFO - 2022-12-14 09:32:22 --> Router Class Initialized
INFO - 2022-12-14 09:32:22 --> Output Class Initialized
INFO - 2022-12-14 09:32:22 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:22 --> Input Class Initialized
INFO - 2022-12-14 09:32:22 --> Language Class Initialized
ERROR - 2022-12-14 09:32:22 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:22 --> Config Class Initialized
INFO - 2022-12-14 09:32:22 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:22 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:22 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:22 --> URI Class Initialized
INFO - 2022-12-14 09:32:22 --> Router Class Initialized
INFO - 2022-12-14 09:32:22 --> Output Class Initialized
INFO - 2022-12-14 09:32:22 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:22 --> Input Class Initialized
INFO - 2022-12-14 09:32:22 --> Language Class Initialized
ERROR - 2022-12-14 09:32:22 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:22 --> Config Class Initialized
INFO - 2022-12-14 09:32:22 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:22 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:22 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:22 --> URI Class Initialized
INFO - 2022-12-14 09:32:22 --> Router Class Initialized
INFO - 2022-12-14 09:32:22 --> Output Class Initialized
INFO - 2022-12-14 09:32:22 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:22 --> Input Class Initialized
INFO - 2022-12-14 09:32:22 --> Language Class Initialized
ERROR - 2022-12-14 09:32:22 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:22 --> Config Class Initialized
INFO - 2022-12-14 09:32:22 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:22 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:22 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:22 --> URI Class Initialized
INFO - 2022-12-14 09:32:22 --> Router Class Initialized
INFO - 2022-12-14 09:32:22 --> Output Class Initialized
INFO - 2022-12-14 09:32:22 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:22 --> Input Class Initialized
INFO - 2022-12-14 09:32:22 --> Language Class Initialized
ERROR - 2022-12-14 09:32:22 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:22 --> Config Class Initialized
INFO - 2022-12-14 09:32:22 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:22 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:22 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:22 --> URI Class Initialized
INFO - 2022-12-14 09:32:22 --> Router Class Initialized
INFO - 2022-12-14 09:32:22 --> Output Class Initialized
INFO - 2022-12-14 09:32:22 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:22 --> Input Class Initialized
INFO - 2022-12-14 09:32:22 --> Language Class Initialized
ERROR - 2022-12-14 09:32:22 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:22 --> Config Class Initialized
INFO - 2022-12-14 09:32:22 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:22 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:22 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:22 --> URI Class Initialized
INFO - 2022-12-14 09:32:22 --> Router Class Initialized
INFO - 2022-12-14 09:32:22 --> Output Class Initialized
INFO - 2022-12-14 09:32:22 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:22 --> Input Class Initialized
INFO - 2022-12-14 09:32:22 --> Language Class Initialized
ERROR - 2022-12-14 09:32:22 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:22 --> Config Class Initialized
INFO - 2022-12-14 09:32:22 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:22 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:22 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:22 --> URI Class Initialized
INFO - 2022-12-14 09:32:22 --> Router Class Initialized
INFO - 2022-12-14 09:32:22 --> Output Class Initialized
INFO - 2022-12-14 09:32:22 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:22 --> Input Class Initialized
INFO - 2022-12-14 09:32:22 --> Language Class Initialized
ERROR - 2022-12-14 09:32:22 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:22 --> Config Class Initialized
INFO - 2022-12-14 09:32:22 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:22 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:22 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:22 --> URI Class Initialized
INFO - 2022-12-14 09:32:22 --> Router Class Initialized
INFO - 2022-12-14 09:32:22 --> Output Class Initialized
INFO - 2022-12-14 09:32:22 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:22 --> Input Class Initialized
INFO - 2022-12-14 09:32:22 --> Language Class Initialized
ERROR - 2022-12-14 09:32:22 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:22 --> Config Class Initialized
INFO - 2022-12-14 09:32:22 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:22 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:22 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:22 --> URI Class Initialized
INFO - 2022-12-14 09:32:22 --> Router Class Initialized
INFO - 2022-12-14 09:32:22 --> Output Class Initialized
INFO - 2022-12-14 09:32:22 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:22 --> Input Class Initialized
INFO - 2022-12-14 09:32:22 --> Language Class Initialized
ERROR - 2022-12-14 09:32:22 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:29 --> Config Class Initialized
INFO - 2022-12-14 09:32:29 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:29 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:29 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:29 --> URI Class Initialized
INFO - 2022-12-14 09:32:29 --> Router Class Initialized
INFO - 2022-12-14 09:32:29 --> Output Class Initialized
INFO - 2022-12-14 09:32:29 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:29 --> Input Class Initialized
INFO - 2022-12-14 09:32:29 --> Language Class Initialized
INFO - 2022-12-14 09:32:29 --> Language Class Initialized
INFO - 2022-12-14 09:32:29 --> Config Class Initialized
INFO - 2022-12-14 09:32:29 --> Loader Class Initialized
INFO - 2022-12-14 09:32:29 --> Helper loaded: url_helper
INFO - 2022-12-14 09:32:29 --> Helper loaded: file_helper
INFO - 2022-12-14 09:32:29 --> Helper loaded: form_helper
INFO - 2022-12-14 09:32:29 --> Helper loaded: my_helper
INFO - 2022-12-14 09:32:29 --> Database Driver Class Initialized
DEBUG - 2022-12-14 09:32:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-14 09:32:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-14 09:32:29 --> Controller Class Initialized
DEBUG - 2022-12-14 09:32:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-12-14 09:32:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-14 09:32:29 --> Final output sent to browser
DEBUG - 2022-12-14 09:32:29 --> Total execution time: 0.0626
INFO - 2022-12-14 09:32:29 --> Config Class Initialized
INFO - 2022-12-14 09:32:29 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:29 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:29 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:29 --> URI Class Initialized
INFO - 2022-12-14 09:32:29 --> Router Class Initialized
INFO - 2022-12-14 09:32:29 --> Output Class Initialized
INFO - 2022-12-14 09:32:29 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:29 --> Input Class Initialized
INFO - 2022-12-14 09:32:29 --> Language Class Initialized
ERROR - 2022-12-14 09:32:29 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:29 --> Config Class Initialized
INFO - 2022-12-14 09:32:29 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:29 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:29 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:29 --> URI Class Initialized
INFO - 2022-12-14 09:32:29 --> Router Class Initialized
INFO - 2022-12-14 09:32:29 --> Output Class Initialized
INFO - 2022-12-14 09:32:29 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:29 --> Input Class Initialized
INFO - 2022-12-14 09:32:29 --> Language Class Initialized
ERROR - 2022-12-14 09:32:29 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:29 --> Config Class Initialized
INFO - 2022-12-14 09:32:29 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:29 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:29 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:29 --> URI Class Initialized
INFO - 2022-12-14 09:32:29 --> Router Class Initialized
INFO - 2022-12-14 09:32:29 --> Output Class Initialized
INFO - 2022-12-14 09:32:29 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:29 --> Input Class Initialized
INFO - 2022-12-14 09:32:29 --> Language Class Initialized
ERROR - 2022-12-14 09:32:29 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:29 --> Config Class Initialized
INFO - 2022-12-14 09:32:29 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:29 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:29 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:29 --> URI Class Initialized
INFO - 2022-12-14 09:32:29 --> Router Class Initialized
INFO - 2022-12-14 09:32:29 --> Output Class Initialized
INFO - 2022-12-14 09:32:29 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:29 --> Input Class Initialized
INFO - 2022-12-14 09:32:29 --> Language Class Initialized
ERROR - 2022-12-14 09:32:29 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:29 --> Config Class Initialized
INFO - 2022-12-14 09:32:29 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:29 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:29 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:29 --> URI Class Initialized
INFO - 2022-12-14 09:32:29 --> Router Class Initialized
INFO - 2022-12-14 09:32:29 --> Output Class Initialized
INFO - 2022-12-14 09:32:29 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:29 --> Input Class Initialized
INFO - 2022-12-14 09:32:29 --> Language Class Initialized
ERROR - 2022-12-14 09:32:29 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:29 --> Config Class Initialized
INFO - 2022-12-14 09:32:29 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:29 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:29 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:29 --> URI Class Initialized
INFO - 2022-12-14 09:32:29 --> Router Class Initialized
INFO - 2022-12-14 09:32:29 --> Output Class Initialized
INFO - 2022-12-14 09:32:29 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:29 --> Input Class Initialized
INFO - 2022-12-14 09:32:29 --> Language Class Initialized
ERROR - 2022-12-14 09:32:29 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:29 --> Config Class Initialized
INFO - 2022-12-14 09:32:29 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:29 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:29 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:29 --> URI Class Initialized
INFO - 2022-12-14 09:32:29 --> Router Class Initialized
INFO - 2022-12-14 09:32:29 --> Output Class Initialized
INFO - 2022-12-14 09:32:29 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:29 --> Input Class Initialized
INFO - 2022-12-14 09:32:29 --> Language Class Initialized
ERROR - 2022-12-14 09:32:29 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:29 --> Config Class Initialized
INFO - 2022-12-14 09:32:29 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:29 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:29 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:29 --> URI Class Initialized
INFO - 2022-12-14 09:32:29 --> Router Class Initialized
INFO - 2022-12-14 09:32:29 --> Output Class Initialized
INFO - 2022-12-14 09:32:29 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:29 --> Input Class Initialized
INFO - 2022-12-14 09:32:29 --> Language Class Initialized
ERROR - 2022-12-14 09:32:29 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:29 --> Config Class Initialized
INFO - 2022-12-14 09:32:29 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:29 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:29 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:29 --> URI Class Initialized
INFO - 2022-12-14 09:32:29 --> Router Class Initialized
INFO - 2022-12-14 09:32:29 --> Output Class Initialized
INFO - 2022-12-14 09:32:29 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:29 --> Input Class Initialized
INFO - 2022-12-14 09:32:29 --> Language Class Initialized
ERROR - 2022-12-14 09:32:29 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:29 --> Config Class Initialized
INFO - 2022-12-14 09:32:29 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:29 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:29 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:29 --> URI Class Initialized
INFO - 2022-12-14 09:32:29 --> Router Class Initialized
INFO - 2022-12-14 09:32:29 --> Output Class Initialized
INFO - 2022-12-14 09:32:29 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:29 --> Input Class Initialized
INFO - 2022-12-14 09:32:29 --> Language Class Initialized
ERROR - 2022-12-14 09:32:29 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:29 --> Config Class Initialized
INFO - 2022-12-14 09:32:29 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:29 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:29 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:29 --> URI Class Initialized
INFO - 2022-12-14 09:32:29 --> Router Class Initialized
INFO - 2022-12-14 09:32:29 --> Output Class Initialized
INFO - 2022-12-14 09:32:29 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:29 --> Input Class Initialized
INFO - 2022-12-14 09:32:29 --> Language Class Initialized
ERROR - 2022-12-14 09:32:29 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:29 --> Config Class Initialized
INFO - 2022-12-14 09:32:29 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:29 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:29 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:29 --> URI Class Initialized
INFO - 2022-12-14 09:32:29 --> Router Class Initialized
INFO - 2022-12-14 09:32:29 --> Output Class Initialized
INFO - 2022-12-14 09:32:29 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:29 --> Input Class Initialized
INFO - 2022-12-14 09:32:29 --> Language Class Initialized
ERROR - 2022-12-14 09:32:29 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:29 --> Config Class Initialized
INFO - 2022-12-14 09:32:29 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:29 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:29 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:29 --> URI Class Initialized
INFO - 2022-12-14 09:32:29 --> Router Class Initialized
INFO - 2022-12-14 09:32:29 --> Output Class Initialized
INFO - 2022-12-14 09:32:29 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:29 --> Input Class Initialized
INFO - 2022-12-14 09:32:29 --> Language Class Initialized
ERROR - 2022-12-14 09:32:29 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:29 --> Config Class Initialized
INFO - 2022-12-14 09:32:29 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:29 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:29 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:29 --> URI Class Initialized
INFO - 2022-12-14 09:32:29 --> Router Class Initialized
INFO - 2022-12-14 09:32:29 --> Output Class Initialized
INFO - 2022-12-14 09:32:29 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:29 --> Input Class Initialized
INFO - 2022-12-14 09:32:29 --> Language Class Initialized
ERROR - 2022-12-14 09:32:29 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:29 --> Config Class Initialized
INFO - 2022-12-14 09:32:29 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:29 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:29 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:29 --> URI Class Initialized
INFO - 2022-12-14 09:32:29 --> Router Class Initialized
INFO - 2022-12-14 09:32:29 --> Output Class Initialized
INFO - 2022-12-14 09:32:29 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:29 --> Input Class Initialized
INFO - 2022-12-14 09:32:29 --> Language Class Initialized
ERROR - 2022-12-14 09:32:29 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:29 --> Config Class Initialized
INFO - 2022-12-14 09:32:29 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:29 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:29 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:29 --> URI Class Initialized
INFO - 2022-12-14 09:32:29 --> Router Class Initialized
INFO - 2022-12-14 09:32:29 --> Output Class Initialized
INFO - 2022-12-14 09:32:29 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:29 --> Input Class Initialized
INFO - 2022-12-14 09:32:29 --> Language Class Initialized
ERROR - 2022-12-14 09:32:29 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:29 --> Config Class Initialized
INFO - 2022-12-14 09:32:29 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:29 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:29 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:29 --> URI Class Initialized
INFO - 2022-12-14 09:32:29 --> Router Class Initialized
INFO - 2022-12-14 09:32:29 --> Output Class Initialized
INFO - 2022-12-14 09:32:29 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:29 --> Input Class Initialized
INFO - 2022-12-14 09:32:29 --> Language Class Initialized
ERROR - 2022-12-14 09:32:29 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:29 --> Config Class Initialized
INFO - 2022-12-14 09:32:29 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:29 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:29 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:29 --> URI Class Initialized
INFO - 2022-12-14 09:32:29 --> Router Class Initialized
INFO - 2022-12-14 09:32:29 --> Output Class Initialized
INFO - 2022-12-14 09:32:29 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:29 --> Input Class Initialized
INFO - 2022-12-14 09:32:29 --> Language Class Initialized
ERROR - 2022-12-14 09:32:29 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:29 --> Config Class Initialized
INFO - 2022-12-14 09:32:29 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:29 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:29 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:29 --> URI Class Initialized
INFO - 2022-12-14 09:32:29 --> Router Class Initialized
INFO - 2022-12-14 09:32:29 --> Output Class Initialized
INFO - 2022-12-14 09:32:29 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:29 --> Input Class Initialized
INFO - 2022-12-14 09:32:29 --> Language Class Initialized
ERROR - 2022-12-14 09:32:29 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:32:29 --> Config Class Initialized
INFO - 2022-12-14 09:32:29 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:32:29 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:32:29 --> Utf8 Class Initialized
INFO - 2022-12-14 09:32:29 --> URI Class Initialized
INFO - 2022-12-14 09:32:29 --> Router Class Initialized
INFO - 2022-12-14 09:32:29 --> Output Class Initialized
INFO - 2022-12-14 09:32:29 --> Security Class Initialized
DEBUG - 2022-12-14 09:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:32:29 --> Input Class Initialized
INFO - 2022-12-14 09:32:29 --> Language Class Initialized
ERROR - 2022-12-14 09:32:29 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:34:01 --> Config Class Initialized
INFO - 2022-12-14 09:34:01 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:34:01 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:34:01 --> Utf8 Class Initialized
INFO - 2022-12-14 09:34:01 --> URI Class Initialized
DEBUG - 2022-12-14 09:34:01 --> No URI present. Default controller set.
INFO - 2022-12-14 09:34:01 --> Router Class Initialized
INFO - 2022-12-14 09:34:01 --> Output Class Initialized
INFO - 2022-12-14 09:34:01 --> Security Class Initialized
DEBUG - 2022-12-14 09:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:34:01 --> Input Class Initialized
INFO - 2022-12-14 09:34:01 --> Language Class Initialized
INFO - 2022-12-14 09:34:01 --> Language Class Initialized
INFO - 2022-12-14 09:34:01 --> Config Class Initialized
INFO - 2022-12-14 09:34:01 --> Loader Class Initialized
INFO - 2022-12-14 09:34:01 --> Helper loaded: url_helper
INFO - 2022-12-14 09:34:01 --> Helper loaded: file_helper
INFO - 2022-12-14 09:34:01 --> Helper loaded: form_helper
INFO - 2022-12-14 09:34:01 --> Helper loaded: my_helper
INFO - 2022-12-14 09:34:01 --> Database Driver Class Initialized
DEBUG - 2022-12-14 09:34:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-14 09:34:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-14 09:34:01 --> Controller Class Initialized
INFO - 2022-12-14 09:34:01 --> Config Class Initialized
INFO - 2022-12-14 09:34:01 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:34:01 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:34:01 --> Utf8 Class Initialized
INFO - 2022-12-14 09:34:01 --> URI Class Initialized
INFO - 2022-12-14 09:34:01 --> Router Class Initialized
INFO - 2022-12-14 09:34:01 --> Output Class Initialized
INFO - 2022-12-14 09:34:01 --> Security Class Initialized
DEBUG - 2022-12-14 09:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:34:01 --> Input Class Initialized
INFO - 2022-12-14 09:34:01 --> Language Class Initialized
ERROR - 2022-12-14 09:34:01 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:34:39 --> Config Class Initialized
INFO - 2022-12-14 09:34:39 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:34:39 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:34:39 --> Utf8 Class Initialized
INFO - 2022-12-14 09:34:39 --> URI Class Initialized
DEBUG - 2022-12-14 09:34:39 --> No URI present. Default controller set.
INFO - 2022-12-14 09:34:39 --> Router Class Initialized
INFO - 2022-12-14 09:34:39 --> Output Class Initialized
INFO - 2022-12-14 09:34:39 --> Security Class Initialized
DEBUG - 2022-12-14 09:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:34:39 --> Input Class Initialized
INFO - 2022-12-14 09:34:39 --> Language Class Initialized
INFO - 2022-12-14 09:34:39 --> Language Class Initialized
INFO - 2022-12-14 09:34:39 --> Config Class Initialized
INFO - 2022-12-14 09:34:39 --> Loader Class Initialized
INFO - 2022-12-14 09:34:39 --> Helper loaded: url_helper
INFO - 2022-12-14 09:34:39 --> Helper loaded: file_helper
INFO - 2022-12-14 09:34:39 --> Helper loaded: form_helper
INFO - 2022-12-14 09:34:39 --> Helper loaded: my_helper
INFO - 2022-12-14 09:34:39 --> Database Driver Class Initialized
DEBUG - 2022-12-14 09:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-14 09:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-14 09:34:39 --> Controller Class Initialized
INFO - 2022-12-14 09:34:39 --> Config Class Initialized
INFO - 2022-12-14 09:34:39 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:34:39 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:34:39 --> Utf8 Class Initialized
INFO - 2022-12-14 09:34:39 --> URI Class Initialized
INFO - 2022-12-14 09:34:39 --> Router Class Initialized
INFO - 2022-12-14 09:34:39 --> Output Class Initialized
INFO - 2022-12-14 09:34:39 --> Security Class Initialized
DEBUG - 2022-12-14 09:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:34:39 --> Input Class Initialized
INFO - 2022-12-14 09:34:39 --> Language Class Initialized
ERROR - 2022-12-14 09:34:39 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:34:54 --> Config Class Initialized
INFO - 2022-12-14 09:34:54 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:34:54 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:34:54 --> Utf8 Class Initialized
INFO - 2022-12-14 09:34:54 --> URI Class Initialized
INFO - 2022-12-14 09:34:54 --> Router Class Initialized
INFO - 2022-12-14 09:34:54 --> Output Class Initialized
INFO - 2022-12-14 09:34:54 --> Security Class Initialized
DEBUG - 2022-12-14 09:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:34:54 --> Input Class Initialized
INFO - 2022-12-14 09:34:54 --> Language Class Initialized
ERROR - 2022-12-14 09:34:54 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:34:57 --> Config Class Initialized
INFO - 2022-12-14 09:34:57 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:34:57 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:34:57 --> Utf8 Class Initialized
INFO - 2022-12-14 09:34:57 --> URI Class Initialized
INFO - 2022-12-14 09:34:57 --> Router Class Initialized
INFO - 2022-12-14 09:34:57 --> Output Class Initialized
INFO - 2022-12-14 09:34:57 --> Security Class Initialized
DEBUG - 2022-12-14 09:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:34:57 --> Input Class Initialized
INFO - 2022-12-14 09:34:57 --> Language Class Initialized
INFO - 2022-12-14 09:34:57 --> Language Class Initialized
INFO - 2022-12-14 09:34:57 --> Config Class Initialized
INFO - 2022-12-14 09:34:57 --> Loader Class Initialized
INFO - 2022-12-14 09:34:57 --> Helper loaded: url_helper
INFO - 2022-12-14 09:34:57 --> Helper loaded: file_helper
INFO - 2022-12-14 09:34:57 --> Helper loaded: form_helper
INFO - 2022-12-14 09:34:57 --> Helper loaded: my_helper
INFO - 2022-12-14 09:34:57 --> Database Driver Class Initialized
DEBUG - 2022-12-14 09:34:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-14 09:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-14 09:34:57 --> Controller Class Initialized
DEBUG - 2022-12-14 09:34:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-12-14 09:34:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-14 09:34:57 --> Final output sent to browser
DEBUG - 2022-12-14 09:34:57 --> Total execution time: 0.0597
INFO - 2022-12-14 09:34:57 --> Config Class Initialized
INFO - 2022-12-14 09:34:57 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:34:57 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:34:57 --> Utf8 Class Initialized
INFO - 2022-12-14 09:34:57 --> URI Class Initialized
INFO - 2022-12-14 09:34:57 --> Router Class Initialized
INFO - 2022-12-14 09:34:57 --> Output Class Initialized
INFO - 2022-12-14 09:34:57 --> Security Class Initialized
DEBUG - 2022-12-14 09:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:34:57 --> Input Class Initialized
INFO - 2022-12-14 09:34:57 --> Language Class Initialized
ERROR - 2022-12-14 09:34:57 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:34:57 --> Config Class Initialized
INFO - 2022-12-14 09:34:57 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:34:57 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:34:57 --> Utf8 Class Initialized
INFO - 2022-12-14 09:34:57 --> URI Class Initialized
INFO - 2022-12-14 09:34:57 --> Router Class Initialized
INFO - 2022-12-14 09:34:57 --> Output Class Initialized
INFO - 2022-12-14 09:34:57 --> Security Class Initialized
DEBUG - 2022-12-14 09:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:34:57 --> Input Class Initialized
INFO - 2022-12-14 09:34:57 --> Language Class Initialized
ERROR - 2022-12-14 09:34:57 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:34:57 --> Config Class Initialized
INFO - 2022-12-14 09:34:57 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:34:57 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:34:57 --> Utf8 Class Initialized
INFO - 2022-12-14 09:34:57 --> URI Class Initialized
INFO - 2022-12-14 09:34:57 --> Router Class Initialized
INFO - 2022-12-14 09:34:57 --> Output Class Initialized
INFO - 2022-12-14 09:34:57 --> Security Class Initialized
DEBUG - 2022-12-14 09:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:34:57 --> Input Class Initialized
INFO - 2022-12-14 09:34:57 --> Language Class Initialized
ERROR - 2022-12-14 09:34:57 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:34:57 --> Config Class Initialized
INFO - 2022-12-14 09:34:57 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:34:57 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:34:57 --> Utf8 Class Initialized
INFO - 2022-12-14 09:34:57 --> URI Class Initialized
INFO - 2022-12-14 09:34:57 --> Router Class Initialized
INFO - 2022-12-14 09:34:57 --> Output Class Initialized
INFO - 2022-12-14 09:34:57 --> Security Class Initialized
DEBUG - 2022-12-14 09:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:34:57 --> Input Class Initialized
INFO - 2022-12-14 09:34:57 --> Language Class Initialized
ERROR - 2022-12-14 09:34:57 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:34:57 --> Config Class Initialized
INFO - 2022-12-14 09:34:57 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:34:57 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:34:57 --> Utf8 Class Initialized
INFO - 2022-12-14 09:34:57 --> URI Class Initialized
INFO - 2022-12-14 09:34:57 --> Router Class Initialized
INFO - 2022-12-14 09:34:57 --> Output Class Initialized
INFO - 2022-12-14 09:34:57 --> Security Class Initialized
DEBUG - 2022-12-14 09:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:34:57 --> Input Class Initialized
INFO - 2022-12-14 09:34:57 --> Language Class Initialized
ERROR - 2022-12-14 09:34:57 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:34:57 --> Config Class Initialized
INFO - 2022-12-14 09:34:57 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:34:57 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:34:57 --> Utf8 Class Initialized
INFO - 2022-12-14 09:34:57 --> URI Class Initialized
INFO - 2022-12-14 09:34:57 --> Router Class Initialized
INFO - 2022-12-14 09:34:57 --> Output Class Initialized
INFO - 2022-12-14 09:34:57 --> Security Class Initialized
DEBUG - 2022-12-14 09:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:34:57 --> Input Class Initialized
INFO - 2022-12-14 09:34:57 --> Language Class Initialized
ERROR - 2022-12-14 09:34:57 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:34:57 --> Config Class Initialized
INFO - 2022-12-14 09:34:57 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:34:57 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:34:57 --> Utf8 Class Initialized
INFO - 2022-12-14 09:34:57 --> URI Class Initialized
INFO - 2022-12-14 09:34:57 --> Router Class Initialized
INFO - 2022-12-14 09:34:57 --> Output Class Initialized
INFO - 2022-12-14 09:34:57 --> Security Class Initialized
DEBUG - 2022-12-14 09:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:34:57 --> Input Class Initialized
INFO - 2022-12-14 09:34:57 --> Language Class Initialized
ERROR - 2022-12-14 09:34:57 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:34:57 --> Config Class Initialized
INFO - 2022-12-14 09:34:57 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:34:57 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:34:57 --> Utf8 Class Initialized
INFO - 2022-12-14 09:34:57 --> URI Class Initialized
INFO - 2022-12-14 09:34:57 --> Router Class Initialized
INFO - 2022-12-14 09:34:57 --> Output Class Initialized
INFO - 2022-12-14 09:34:57 --> Security Class Initialized
DEBUG - 2022-12-14 09:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:34:57 --> Input Class Initialized
INFO - 2022-12-14 09:34:57 --> Language Class Initialized
ERROR - 2022-12-14 09:34:57 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:34:57 --> Config Class Initialized
INFO - 2022-12-14 09:34:57 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:34:57 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:34:57 --> Utf8 Class Initialized
INFO - 2022-12-14 09:34:57 --> URI Class Initialized
INFO - 2022-12-14 09:34:57 --> Router Class Initialized
INFO - 2022-12-14 09:34:57 --> Output Class Initialized
INFO - 2022-12-14 09:34:57 --> Security Class Initialized
DEBUG - 2022-12-14 09:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:34:57 --> Input Class Initialized
INFO - 2022-12-14 09:34:57 --> Language Class Initialized
ERROR - 2022-12-14 09:34:57 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:34:57 --> Config Class Initialized
INFO - 2022-12-14 09:34:57 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:34:57 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:34:57 --> Utf8 Class Initialized
INFO - 2022-12-14 09:34:57 --> URI Class Initialized
INFO - 2022-12-14 09:34:57 --> Router Class Initialized
INFO - 2022-12-14 09:34:57 --> Output Class Initialized
INFO - 2022-12-14 09:34:57 --> Security Class Initialized
DEBUG - 2022-12-14 09:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:34:57 --> Input Class Initialized
INFO - 2022-12-14 09:34:57 --> Language Class Initialized
ERROR - 2022-12-14 09:34:57 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:34:57 --> Config Class Initialized
INFO - 2022-12-14 09:34:57 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:34:57 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:34:57 --> Utf8 Class Initialized
INFO - 2022-12-14 09:34:57 --> URI Class Initialized
INFO - 2022-12-14 09:34:57 --> Router Class Initialized
INFO - 2022-12-14 09:34:57 --> Output Class Initialized
INFO - 2022-12-14 09:34:57 --> Security Class Initialized
DEBUG - 2022-12-14 09:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:34:57 --> Input Class Initialized
INFO - 2022-12-14 09:34:57 --> Language Class Initialized
ERROR - 2022-12-14 09:34:57 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:34:58 --> Config Class Initialized
INFO - 2022-12-14 09:34:58 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:34:58 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:34:58 --> Utf8 Class Initialized
INFO - 2022-12-14 09:34:58 --> URI Class Initialized
INFO - 2022-12-14 09:34:58 --> Router Class Initialized
INFO - 2022-12-14 09:34:58 --> Output Class Initialized
INFO - 2022-12-14 09:34:58 --> Security Class Initialized
DEBUG - 2022-12-14 09:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:34:58 --> Input Class Initialized
INFO - 2022-12-14 09:34:58 --> Language Class Initialized
ERROR - 2022-12-14 09:34:58 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:34:58 --> Config Class Initialized
INFO - 2022-12-14 09:34:58 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:34:58 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:34:58 --> Utf8 Class Initialized
INFO - 2022-12-14 09:34:58 --> URI Class Initialized
INFO - 2022-12-14 09:34:58 --> Router Class Initialized
INFO - 2022-12-14 09:34:58 --> Output Class Initialized
INFO - 2022-12-14 09:34:58 --> Security Class Initialized
DEBUG - 2022-12-14 09:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:34:58 --> Input Class Initialized
INFO - 2022-12-14 09:34:58 --> Language Class Initialized
ERROR - 2022-12-14 09:34:58 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:34:58 --> Config Class Initialized
INFO - 2022-12-14 09:34:58 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:34:58 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:34:58 --> Utf8 Class Initialized
INFO - 2022-12-14 09:34:58 --> URI Class Initialized
INFO - 2022-12-14 09:34:58 --> Router Class Initialized
INFO - 2022-12-14 09:34:58 --> Output Class Initialized
INFO - 2022-12-14 09:34:58 --> Security Class Initialized
DEBUG - 2022-12-14 09:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:34:58 --> Input Class Initialized
INFO - 2022-12-14 09:34:58 --> Language Class Initialized
ERROR - 2022-12-14 09:34:58 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:34:58 --> Config Class Initialized
INFO - 2022-12-14 09:34:58 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:34:58 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:34:58 --> Utf8 Class Initialized
INFO - 2022-12-14 09:34:58 --> URI Class Initialized
INFO - 2022-12-14 09:34:58 --> Router Class Initialized
INFO - 2022-12-14 09:34:58 --> Output Class Initialized
INFO - 2022-12-14 09:34:58 --> Security Class Initialized
DEBUG - 2022-12-14 09:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:34:58 --> Input Class Initialized
INFO - 2022-12-14 09:34:58 --> Language Class Initialized
ERROR - 2022-12-14 09:34:58 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:34:58 --> Config Class Initialized
INFO - 2022-12-14 09:34:58 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:34:58 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:34:58 --> Utf8 Class Initialized
INFO - 2022-12-14 09:34:58 --> URI Class Initialized
INFO - 2022-12-14 09:34:58 --> Router Class Initialized
INFO - 2022-12-14 09:34:58 --> Output Class Initialized
INFO - 2022-12-14 09:34:58 --> Security Class Initialized
DEBUG - 2022-12-14 09:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:34:58 --> Input Class Initialized
INFO - 2022-12-14 09:34:58 --> Language Class Initialized
ERROR - 2022-12-14 09:34:58 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:34:58 --> Config Class Initialized
INFO - 2022-12-14 09:34:58 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:34:58 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:34:58 --> Utf8 Class Initialized
INFO - 2022-12-14 09:34:58 --> URI Class Initialized
INFO - 2022-12-14 09:34:58 --> Router Class Initialized
INFO - 2022-12-14 09:34:58 --> Output Class Initialized
INFO - 2022-12-14 09:34:58 --> Security Class Initialized
DEBUG - 2022-12-14 09:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:34:58 --> Input Class Initialized
INFO - 2022-12-14 09:34:58 --> Language Class Initialized
ERROR - 2022-12-14 09:34:58 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:34:58 --> Config Class Initialized
INFO - 2022-12-14 09:34:58 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:34:58 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:34:58 --> Utf8 Class Initialized
INFO - 2022-12-14 09:34:58 --> URI Class Initialized
INFO - 2022-12-14 09:34:58 --> Router Class Initialized
INFO - 2022-12-14 09:34:58 --> Output Class Initialized
INFO - 2022-12-14 09:34:58 --> Security Class Initialized
DEBUG - 2022-12-14 09:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:34:58 --> Input Class Initialized
INFO - 2022-12-14 09:34:58 --> Language Class Initialized
ERROR - 2022-12-14 09:34:58 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:34:58 --> Config Class Initialized
INFO - 2022-12-14 09:34:58 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:34:58 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:34:58 --> Utf8 Class Initialized
INFO - 2022-12-14 09:34:58 --> URI Class Initialized
INFO - 2022-12-14 09:34:58 --> Router Class Initialized
INFO - 2022-12-14 09:34:58 --> Output Class Initialized
INFO - 2022-12-14 09:34:58 --> Security Class Initialized
DEBUG - 2022-12-14 09:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:34:58 --> Input Class Initialized
INFO - 2022-12-14 09:34:58 --> Language Class Initialized
ERROR - 2022-12-14 09:34:58 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:34:58 --> Config Class Initialized
INFO - 2022-12-14 09:34:58 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:34:58 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:34:58 --> Utf8 Class Initialized
INFO - 2022-12-14 09:34:58 --> URI Class Initialized
INFO - 2022-12-14 09:34:58 --> Router Class Initialized
INFO - 2022-12-14 09:34:58 --> Output Class Initialized
INFO - 2022-12-14 09:34:58 --> Security Class Initialized
DEBUG - 2022-12-14 09:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:34:58 --> Input Class Initialized
INFO - 2022-12-14 09:34:58 --> Language Class Initialized
ERROR - 2022-12-14 09:34:58 --> 404 Page Not Found: /index
INFO - 2022-12-14 09:34:58 --> Config Class Initialized
INFO - 2022-12-14 09:34:58 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:34:58 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:34:58 --> Utf8 Class Initialized
INFO - 2022-12-14 09:34:58 --> URI Class Initialized
INFO - 2022-12-14 09:34:58 --> Router Class Initialized
INFO - 2022-12-14 09:34:58 --> Output Class Initialized
INFO - 2022-12-14 09:34:58 --> Security Class Initialized
DEBUG - 2022-12-14 09:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:34:58 --> Input Class Initialized
INFO - 2022-12-14 09:34:58 --> Language Class Initialized
ERROR - 2022-12-14 09:34:58 --> 404 Page Not Found: /index
