<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-09-30 02:10:15 --> Config Class Initialized
INFO - 2022-09-30 02:10:15 --> Hooks Class Initialized
DEBUG - 2022-09-30 02:10:15 --> UTF-8 Support Enabled
INFO - 2022-09-30 02:10:15 --> Utf8 Class Initialized
INFO - 2022-09-30 02:10:15 --> URI Class Initialized
DEBUG - 2022-09-30 02:10:15 --> No URI present. Default controller set.
INFO - 2022-09-30 02:10:15 --> Router Class Initialized
INFO - 2022-09-30 02:10:15 --> Output Class Initialized
INFO - 2022-09-30 02:10:15 --> Security Class Initialized
DEBUG - 2022-09-30 02:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-30 02:10:15 --> Input Class Initialized
INFO - 2022-09-30 02:10:15 --> Language Class Initialized
INFO - 2022-09-30 02:10:15 --> Language Class Initialized
INFO - 2022-09-30 02:10:15 --> Config Class Initialized
INFO - 2022-09-30 02:10:15 --> Loader Class Initialized
INFO - 2022-09-30 02:10:15 --> Helper loaded: url_helper
INFO - 2022-09-30 02:10:15 --> Helper loaded: file_helper
INFO - 2022-09-30 02:10:15 --> Helper loaded: form_helper
INFO - 2022-09-30 02:10:15 --> Helper loaded: my_helper
INFO - 2022-09-30 02:10:15 --> Database Driver Class Initialized
DEBUG - 2022-09-30 02:10:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-30 02:10:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-30 02:10:15 --> Controller Class Initialized
INFO - 2022-09-30 02:10:16 --> Config Class Initialized
INFO - 2022-09-30 02:10:16 --> Hooks Class Initialized
DEBUG - 2022-09-30 02:10:16 --> UTF-8 Support Enabled
INFO - 2022-09-30 02:10:16 --> Utf8 Class Initialized
INFO - 2022-09-30 02:10:16 --> URI Class Initialized
INFO - 2022-09-30 02:10:16 --> Router Class Initialized
INFO - 2022-09-30 02:10:16 --> Output Class Initialized
INFO - 2022-09-30 02:10:16 --> Security Class Initialized
DEBUG - 2022-09-30 02:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-30 02:10:16 --> Input Class Initialized
INFO - 2022-09-30 02:10:16 --> Language Class Initialized
INFO - 2022-09-30 02:10:16 --> Language Class Initialized
INFO - 2022-09-30 02:10:16 --> Config Class Initialized
INFO - 2022-09-30 02:10:16 --> Loader Class Initialized
INFO - 2022-09-30 02:10:16 --> Helper loaded: url_helper
INFO - 2022-09-30 02:10:16 --> Helper loaded: file_helper
INFO - 2022-09-30 02:10:16 --> Helper loaded: form_helper
INFO - 2022-09-30 02:10:16 --> Helper loaded: my_helper
INFO - 2022-09-30 02:10:16 --> Database Driver Class Initialized
DEBUG - 2022-09-30 02:10:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-30 02:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-30 02:10:16 --> Controller Class Initialized
DEBUG - 2022-09-30 02:10:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-09-30 02:10:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-09-30 02:10:16 --> Final output sent to browser
DEBUG - 2022-09-30 02:10:16 --> Total execution time: 0.0920
INFO - 2022-09-30 07:59:48 --> Config Class Initialized
INFO - 2022-09-30 07:59:48 --> Hooks Class Initialized
DEBUG - 2022-09-30 07:59:48 --> UTF-8 Support Enabled
INFO - 2022-09-30 07:59:48 --> Utf8 Class Initialized
INFO - 2022-09-30 07:59:48 --> URI Class Initialized
DEBUG - 2022-09-30 07:59:48 --> No URI present. Default controller set.
INFO - 2022-09-30 07:59:48 --> Router Class Initialized
INFO - 2022-09-30 07:59:48 --> Output Class Initialized
INFO - 2022-09-30 07:59:48 --> Security Class Initialized
DEBUG - 2022-09-30 07:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-30 07:59:48 --> Input Class Initialized
INFO - 2022-09-30 07:59:48 --> Language Class Initialized
INFO - 2022-09-30 07:59:48 --> Language Class Initialized
INFO - 2022-09-30 07:59:48 --> Config Class Initialized
INFO - 2022-09-30 07:59:48 --> Loader Class Initialized
INFO - 2022-09-30 07:59:48 --> Helper loaded: url_helper
INFO - 2022-09-30 07:59:48 --> Helper loaded: file_helper
INFO - 2022-09-30 07:59:48 --> Helper loaded: form_helper
INFO - 2022-09-30 07:59:48 --> Helper loaded: my_helper
INFO - 2022-09-30 07:59:48 --> Database Driver Class Initialized
DEBUG - 2022-09-30 07:59:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-30 07:59:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-30 07:59:48 --> Controller Class Initialized
INFO - 2022-09-30 07:59:48 --> Config Class Initialized
INFO - 2022-09-30 07:59:48 --> Hooks Class Initialized
DEBUG - 2022-09-30 07:59:48 --> UTF-8 Support Enabled
INFO - 2022-09-30 07:59:48 --> Utf8 Class Initialized
INFO - 2022-09-30 07:59:48 --> URI Class Initialized
INFO - 2022-09-30 07:59:48 --> Router Class Initialized
INFO - 2022-09-30 07:59:48 --> Output Class Initialized
INFO - 2022-09-30 07:59:48 --> Security Class Initialized
DEBUG - 2022-09-30 07:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-30 07:59:48 --> Input Class Initialized
INFO - 2022-09-30 07:59:48 --> Language Class Initialized
INFO - 2022-09-30 07:59:48 --> Language Class Initialized
INFO - 2022-09-30 07:59:48 --> Config Class Initialized
INFO - 2022-09-30 07:59:48 --> Loader Class Initialized
INFO - 2022-09-30 07:59:48 --> Helper loaded: url_helper
INFO - 2022-09-30 07:59:48 --> Helper loaded: file_helper
INFO - 2022-09-30 07:59:48 --> Helper loaded: form_helper
INFO - 2022-09-30 07:59:48 --> Helper loaded: my_helper
INFO - 2022-09-30 07:59:48 --> Database Driver Class Initialized
DEBUG - 2022-09-30 07:59:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-30 07:59:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-30 07:59:48 --> Controller Class Initialized
DEBUG - 2022-09-30 07:59:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-09-30 07:59:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-09-30 07:59:48 --> Final output sent to browser
DEBUG - 2022-09-30 07:59:48 --> Total execution time: 0.0465
INFO - 2022-09-30 08:31:06 --> Config Class Initialized
INFO - 2022-09-30 08:31:06 --> Hooks Class Initialized
DEBUG - 2022-09-30 08:31:06 --> UTF-8 Support Enabled
INFO - 2022-09-30 08:31:06 --> Utf8 Class Initialized
INFO - 2022-09-30 08:31:06 --> URI Class Initialized
DEBUG - 2022-09-30 08:31:07 --> No URI present. Default controller set.
INFO - 2022-09-30 08:31:07 --> Router Class Initialized
INFO - 2022-09-30 08:31:07 --> Output Class Initialized
INFO - 2022-09-30 08:31:07 --> Security Class Initialized
DEBUG - 2022-09-30 08:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-30 08:31:07 --> Input Class Initialized
INFO - 2022-09-30 08:31:07 --> Language Class Initialized
INFO - 2022-09-30 08:31:07 --> Language Class Initialized
INFO - 2022-09-30 08:31:07 --> Config Class Initialized
INFO - 2022-09-30 08:31:07 --> Loader Class Initialized
INFO - 2022-09-30 08:31:07 --> Helper loaded: url_helper
INFO - 2022-09-30 08:31:07 --> Helper loaded: file_helper
INFO - 2022-09-30 08:31:07 --> Helper loaded: form_helper
INFO - 2022-09-30 08:31:07 --> Helper loaded: my_helper
INFO - 2022-09-30 08:31:07 --> Database Driver Class Initialized
DEBUG - 2022-09-30 08:31:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-30 08:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-30 08:31:07 --> Controller Class Initialized
INFO - 2022-09-30 08:31:07 --> Config Class Initialized
INFO - 2022-09-30 08:31:07 --> Hooks Class Initialized
DEBUG - 2022-09-30 08:31:07 --> UTF-8 Support Enabled
INFO - 2022-09-30 08:31:07 --> Utf8 Class Initialized
INFO - 2022-09-30 08:31:07 --> URI Class Initialized
INFO - 2022-09-30 08:31:07 --> Router Class Initialized
INFO - 2022-09-30 08:31:07 --> Output Class Initialized
INFO - 2022-09-30 08:31:07 --> Security Class Initialized
DEBUG - 2022-09-30 08:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-30 08:31:07 --> Input Class Initialized
INFO - 2022-09-30 08:31:07 --> Language Class Initialized
INFO - 2022-09-30 08:31:07 --> Language Class Initialized
INFO - 2022-09-30 08:31:07 --> Config Class Initialized
INFO - 2022-09-30 08:31:07 --> Loader Class Initialized
INFO - 2022-09-30 08:31:07 --> Helper loaded: url_helper
INFO - 2022-09-30 08:31:07 --> Helper loaded: file_helper
INFO - 2022-09-30 08:31:07 --> Helper loaded: form_helper
INFO - 2022-09-30 08:31:07 --> Helper loaded: my_helper
INFO - 2022-09-30 08:31:07 --> Database Driver Class Initialized
DEBUG - 2022-09-30 08:31:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-30 08:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-30 08:31:07 --> Controller Class Initialized
DEBUG - 2022-09-30 08:31:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-09-30 08:31:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-09-30 08:31:07 --> Final output sent to browser
DEBUG - 2022-09-30 08:31:07 --> Total execution time: 0.0824
