<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-12-13 01:46:11 --> Config Class Initialized
INFO - 2021-12-13 01:46:11 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:46:11 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:46:11 --> Utf8 Class Initialized
INFO - 2021-12-13 01:46:11 --> URI Class Initialized
DEBUG - 2021-12-13 01:46:11 --> No URI present. Default controller set.
INFO - 2021-12-13 01:46:11 --> Router Class Initialized
INFO - 2021-12-13 01:46:11 --> Output Class Initialized
INFO - 2021-12-13 01:46:11 --> Security Class Initialized
DEBUG - 2021-12-13 01:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:46:11 --> Input Class Initialized
INFO - 2021-12-13 01:46:11 --> Language Class Initialized
INFO - 2021-12-13 01:46:11 --> Language Class Initialized
INFO - 2021-12-13 01:46:11 --> Config Class Initialized
INFO - 2021-12-13 01:46:11 --> Loader Class Initialized
INFO - 2021-12-13 01:46:11 --> Helper loaded: url_helper
INFO - 2021-12-13 01:46:11 --> Helper loaded: file_helper
INFO - 2021-12-13 01:46:11 --> Helper loaded: form_helper
INFO - 2021-12-13 01:46:11 --> Helper loaded: my_helper
INFO - 2021-12-13 01:46:11 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:46:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:46:11 --> Controller Class Initialized
INFO - 2021-12-13 01:46:11 --> Config Class Initialized
INFO - 2021-12-13 01:46:11 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:46:11 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:46:11 --> Utf8 Class Initialized
INFO - 2021-12-13 01:46:11 --> URI Class Initialized
INFO - 2021-12-13 01:46:11 --> Router Class Initialized
INFO - 2021-12-13 01:46:11 --> Output Class Initialized
INFO - 2021-12-13 01:46:11 --> Security Class Initialized
DEBUG - 2021-12-13 01:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:46:11 --> Input Class Initialized
INFO - 2021-12-13 01:46:11 --> Language Class Initialized
INFO - 2021-12-13 01:46:11 --> Language Class Initialized
INFO - 2021-12-13 01:46:11 --> Config Class Initialized
INFO - 2021-12-13 01:46:11 --> Loader Class Initialized
INFO - 2021-12-13 01:46:11 --> Helper loaded: url_helper
INFO - 2021-12-13 01:46:11 --> Helper loaded: file_helper
INFO - 2021-12-13 01:46:11 --> Helper loaded: form_helper
INFO - 2021-12-13 01:46:11 --> Helper loaded: my_helper
INFO - 2021-12-13 01:46:11 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:46:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:46:11 --> Controller Class Initialized
DEBUG - 2021-12-13 01:46:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-13 01:46:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 01:46:11 --> Final output sent to browser
DEBUG - 2021-12-13 01:46:11 --> Total execution time: 0.0310
INFO - 2021-12-13 01:50:14 --> Config Class Initialized
INFO - 2021-12-13 01:50:14 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:50:14 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:50:14 --> Utf8 Class Initialized
INFO - 2021-12-13 01:50:14 --> URI Class Initialized
INFO - 2021-12-13 01:50:14 --> Router Class Initialized
INFO - 2021-12-13 01:50:14 --> Output Class Initialized
INFO - 2021-12-13 01:50:14 --> Security Class Initialized
DEBUG - 2021-12-13 01:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:50:14 --> Input Class Initialized
INFO - 2021-12-13 01:50:14 --> Language Class Initialized
INFO - 2021-12-13 01:50:14 --> Language Class Initialized
INFO - 2021-12-13 01:50:14 --> Config Class Initialized
INFO - 2021-12-13 01:50:14 --> Loader Class Initialized
INFO - 2021-12-13 01:50:14 --> Helper loaded: url_helper
INFO - 2021-12-13 01:50:14 --> Helper loaded: file_helper
INFO - 2021-12-13 01:50:14 --> Helper loaded: form_helper
INFO - 2021-12-13 01:50:14 --> Helper loaded: my_helper
INFO - 2021-12-13 01:50:14 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:50:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:50:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:50:14 --> Controller Class Initialized
INFO - 2021-12-13 01:50:14 --> Helper loaded: cookie_helper
INFO - 2021-12-13 01:50:14 --> Final output sent to browser
DEBUG - 2021-12-13 01:50:14 --> Total execution time: 0.0640
INFO - 2021-12-13 01:50:14 --> Config Class Initialized
INFO - 2021-12-13 01:50:14 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:50:14 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:50:14 --> Utf8 Class Initialized
INFO - 2021-12-13 01:50:14 --> URI Class Initialized
INFO - 2021-12-13 01:50:14 --> Router Class Initialized
INFO - 2021-12-13 01:50:14 --> Output Class Initialized
INFO - 2021-12-13 01:50:14 --> Security Class Initialized
DEBUG - 2021-12-13 01:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:50:14 --> Input Class Initialized
INFO - 2021-12-13 01:50:14 --> Language Class Initialized
INFO - 2021-12-13 01:50:14 --> Language Class Initialized
INFO - 2021-12-13 01:50:14 --> Config Class Initialized
INFO - 2021-12-13 01:50:14 --> Loader Class Initialized
INFO - 2021-12-13 01:50:14 --> Helper loaded: url_helper
INFO - 2021-12-13 01:50:14 --> Helper loaded: file_helper
INFO - 2021-12-13 01:50:14 --> Helper loaded: form_helper
INFO - 2021-12-13 01:50:14 --> Helper loaded: my_helper
INFO - 2021-12-13 01:50:14 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:50:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:50:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:50:15 --> Controller Class Initialized
DEBUG - 2021-12-13 01:50:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-13 01:50:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 01:50:15 --> Final output sent to browser
DEBUG - 2021-12-13 01:50:15 --> Total execution time: 0.2300
INFO - 2021-12-13 01:50:20 --> Config Class Initialized
INFO - 2021-12-13 01:50:20 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:50:20 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:50:20 --> Utf8 Class Initialized
INFO - 2021-12-13 01:50:20 --> URI Class Initialized
INFO - 2021-12-13 01:50:20 --> Router Class Initialized
INFO - 2021-12-13 01:50:20 --> Output Class Initialized
INFO - 2021-12-13 01:50:20 --> Security Class Initialized
DEBUG - 2021-12-13 01:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:50:20 --> Input Class Initialized
INFO - 2021-12-13 01:50:20 --> Language Class Initialized
INFO - 2021-12-13 01:50:20 --> Language Class Initialized
INFO - 2021-12-13 01:50:20 --> Config Class Initialized
INFO - 2021-12-13 01:50:20 --> Loader Class Initialized
INFO - 2021-12-13 01:50:20 --> Helper loaded: url_helper
INFO - 2021-12-13 01:50:20 --> Helper loaded: file_helper
INFO - 2021-12-13 01:50:20 --> Helper loaded: form_helper
INFO - 2021-12-13 01:50:20 --> Helper loaded: my_helper
INFO - 2021-12-13 01:50:20 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:50:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:50:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:50:20 --> Controller Class Initialized
DEBUG - 2021-12-13 01:50:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-13 01:50:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 01:50:20 --> Final output sent to browser
DEBUG - 2021-12-13 01:50:20 --> Total execution time: 0.0740
INFO - 2021-12-13 01:50:25 --> Config Class Initialized
INFO - 2021-12-13 01:50:25 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:50:25 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:50:25 --> Utf8 Class Initialized
INFO - 2021-12-13 01:50:25 --> URI Class Initialized
INFO - 2021-12-13 01:50:25 --> Router Class Initialized
INFO - 2021-12-13 01:50:25 --> Output Class Initialized
INFO - 2021-12-13 01:50:25 --> Security Class Initialized
DEBUG - 2021-12-13 01:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:50:25 --> Input Class Initialized
INFO - 2021-12-13 01:50:25 --> Language Class Initialized
INFO - 2021-12-13 01:50:25 --> Language Class Initialized
INFO - 2021-12-13 01:50:25 --> Config Class Initialized
INFO - 2021-12-13 01:50:25 --> Loader Class Initialized
INFO - 2021-12-13 01:50:25 --> Helper loaded: url_helper
INFO - 2021-12-13 01:50:25 --> Helper loaded: file_helper
INFO - 2021-12-13 01:50:25 --> Helper loaded: form_helper
INFO - 2021-12-13 01:50:25 --> Helper loaded: my_helper
INFO - 2021-12-13 01:50:25 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:50:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:50:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:50:25 --> Controller Class Initialized
INFO - 2021-12-13 01:50:25 --> Helper loaded: cookie_helper
INFO - 2021-12-13 01:50:25 --> Config Class Initialized
INFO - 2021-12-13 01:50:25 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:50:25 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:50:25 --> Utf8 Class Initialized
INFO - 2021-12-13 01:50:25 --> URI Class Initialized
INFO - 2021-12-13 01:50:25 --> Router Class Initialized
INFO - 2021-12-13 01:50:25 --> Output Class Initialized
INFO - 2021-12-13 01:50:25 --> Security Class Initialized
DEBUG - 2021-12-13 01:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:50:25 --> Input Class Initialized
INFO - 2021-12-13 01:50:25 --> Language Class Initialized
INFO - 2021-12-13 01:50:25 --> Language Class Initialized
INFO - 2021-12-13 01:50:25 --> Config Class Initialized
INFO - 2021-12-13 01:50:25 --> Loader Class Initialized
INFO - 2021-12-13 01:50:25 --> Helper loaded: url_helper
INFO - 2021-12-13 01:50:25 --> Helper loaded: file_helper
INFO - 2021-12-13 01:50:25 --> Helper loaded: form_helper
INFO - 2021-12-13 01:50:25 --> Helper loaded: my_helper
INFO - 2021-12-13 01:50:25 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:50:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:50:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:50:25 --> Controller Class Initialized
DEBUG - 2021-12-13 01:50:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-13 01:50:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 01:50:25 --> Final output sent to browser
DEBUG - 2021-12-13 01:50:25 --> Total execution time: 0.0360
INFO - 2021-12-13 01:50:30 --> Config Class Initialized
INFO - 2021-12-13 01:50:30 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:50:30 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:50:30 --> Utf8 Class Initialized
INFO - 2021-12-13 01:50:30 --> URI Class Initialized
INFO - 2021-12-13 01:50:30 --> Router Class Initialized
INFO - 2021-12-13 01:50:30 --> Output Class Initialized
INFO - 2021-12-13 01:50:30 --> Security Class Initialized
DEBUG - 2021-12-13 01:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:50:30 --> Input Class Initialized
INFO - 2021-12-13 01:50:30 --> Language Class Initialized
INFO - 2021-12-13 01:50:30 --> Language Class Initialized
INFO - 2021-12-13 01:50:30 --> Config Class Initialized
INFO - 2021-12-13 01:50:30 --> Loader Class Initialized
INFO - 2021-12-13 01:50:30 --> Helper loaded: url_helper
INFO - 2021-12-13 01:50:30 --> Helper loaded: file_helper
INFO - 2021-12-13 01:50:30 --> Helper loaded: form_helper
INFO - 2021-12-13 01:50:30 --> Helper loaded: my_helper
INFO - 2021-12-13 01:50:30 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:50:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:50:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:50:30 --> Controller Class Initialized
INFO - 2021-12-13 01:50:30 --> Helper loaded: cookie_helper
INFO - 2021-12-13 01:50:30 --> Final output sent to browser
DEBUG - 2021-12-13 01:50:30 --> Total execution time: 0.0430
INFO - 2021-12-13 01:50:30 --> Config Class Initialized
INFO - 2021-12-13 01:50:30 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:50:30 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:50:30 --> Utf8 Class Initialized
INFO - 2021-12-13 01:50:30 --> URI Class Initialized
INFO - 2021-12-13 01:50:30 --> Router Class Initialized
INFO - 2021-12-13 01:50:30 --> Output Class Initialized
INFO - 2021-12-13 01:50:30 --> Security Class Initialized
DEBUG - 2021-12-13 01:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:50:30 --> Input Class Initialized
INFO - 2021-12-13 01:50:30 --> Language Class Initialized
INFO - 2021-12-13 01:50:30 --> Language Class Initialized
INFO - 2021-12-13 01:50:30 --> Config Class Initialized
INFO - 2021-12-13 01:50:30 --> Loader Class Initialized
INFO - 2021-12-13 01:50:30 --> Helper loaded: url_helper
INFO - 2021-12-13 01:50:30 --> Helper loaded: file_helper
INFO - 2021-12-13 01:50:30 --> Helper loaded: form_helper
INFO - 2021-12-13 01:50:30 --> Helper loaded: my_helper
INFO - 2021-12-13 01:50:30 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:50:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:50:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:50:30 --> Controller Class Initialized
DEBUG - 2021-12-13 01:50:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-13 01:50:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 01:50:30 --> Final output sent to browser
DEBUG - 2021-12-13 01:50:30 --> Total execution time: 0.1460
INFO - 2021-12-13 01:50:34 --> Config Class Initialized
INFO - 2021-12-13 01:50:34 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:50:34 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:50:34 --> Utf8 Class Initialized
INFO - 2021-12-13 01:50:34 --> URI Class Initialized
INFO - 2021-12-13 01:50:34 --> Router Class Initialized
INFO - 2021-12-13 01:50:34 --> Output Class Initialized
INFO - 2021-12-13 01:50:34 --> Security Class Initialized
DEBUG - 2021-12-13 01:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:50:34 --> Input Class Initialized
INFO - 2021-12-13 01:50:34 --> Language Class Initialized
INFO - 2021-12-13 01:50:34 --> Language Class Initialized
INFO - 2021-12-13 01:50:34 --> Config Class Initialized
INFO - 2021-12-13 01:50:34 --> Loader Class Initialized
INFO - 2021-12-13 01:50:34 --> Helper loaded: url_helper
INFO - 2021-12-13 01:50:34 --> Helper loaded: file_helper
INFO - 2021-12-13 01:50:34 --> Helper loaded: form_helper
INFO - 2021-12-13 01:50:34 --> Helper loaded: my_helper
INFO - 2021-12-13 01:50:34 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:50:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:50:34 --> Controller Class Initialized
DEBUG - 2021-12-13 01:50:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-13 01:50:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 01:50:34 --> Final output sent to browser
DEBUG - 2021-12-13 01:50:34 --> Total execution time: 0.0380
INFO - 2021-12-13 01:50:40 --> Config Class Initialized
INFO - 2021-12-13 01:50:40 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:50:40 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:50:40 --> Utf8 Class Initialized
INFO - 2021-12-13 01:50:40 --> URI Class Initialized
INFO - 2021-12-13 01:50:40 --> Router Class Initialized
INFO - 2021-12-13 01:50:40 --> Output Class Initialized
INFO - 2021-12-13 01:50:40 --> Security Class Initialized
DEBUG - 2021-12-13 01:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:50:40 --> Input Class Initialized
INFO - 2021-12-13 01:50:40 --> Language Class Initialized
INFO - 2021-12-13 01:50:40 --> Language Class Initialized
INFO - 2021-12-13 01:50:40 --> Config Class Initialized
INFO - 2021-12-13 01:50:40 --> Loader Class Initialized
INFO - 2021-12-13 01:50:40 --> Helper loaded: url_helper
INFO - 2021-12-13 01:50:40 --> Helper loaded: file_helper
INFO - 2021-12-13 01:50:40 --> Helper loaded: form_helper
INFO - 2021-12-13 01:50:40 --> Helper loaded: my_helper
INFO - 2021-12-13 01:50:40 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:50:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:50:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:50:40 --> Controller Class Initialized
DEBUG - 2021-12-13 01:50:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 01:50:40 --> Final output sent to browser
DEBUG - 2021-12-13 01:50:40 --> Total execution time: 0.1210
INFO - 2021-12-13 01:50:48 --> Config Class Initialized
INFO - 2021-12-13 01:50:48 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:50:48 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:50:48 --> Utf8 Class Initialized
INFO - 2021-12-13 01:50:48 --> URI Class Initialized
INFO - 2021-12-13 01:50:48 --> Router Class Initialized
INFO - 2021-12-13 01:50:48 --> Output Class Initialized
INFO - 2021-12-13 01:50:48 --> Security Class Initialized
DEBUG - 2021-12-13 01:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:50:48 --> Input Class Initialized
INFO - 2021-12-13 01:50:48 --> Language Class Initialized
INFO - 2021-12-13 01:50:48 --> Language Class Initialized
INFO - 2021-12-13 01:50:48 --> Config Class Initialized
INFO - 2021-12-13 01:50:48 --> Loader Class Initialized
INFO - 2021-12-13 01:50:48 --> Helper loaded: url_helper
INFO - 2021-12-13 01:50:48 --> Helper loaded: file_helper
INFO - 2021-12-13 01:50:48 --> Helper loaded: form_helper
INFO - 2021-12-13 01:50:48 --> Helper loaded: my_helper
INFO - 2021-12-13 01:50:48 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:50:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:50:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:50:48 --> Controller Class Initialized
DEBUG - 2021-12-13 01:50:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 01:50:48 --> Final output sent to browser
DEBUG - 2021-12-13 01:50:48 --> Total execution time: 0.0610
INFO - 2021-12-13 01:50:50 --> Config Class Initialized
INFO - 2021-12-13 01:50:50 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:50:50 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:50:50 --> Utf8 Class Initialized
INFO - 2021-12-13 01:50:50 --> URI Class Initialized
INFO - 2021-12-13 01:50:50 --> Router Class Initialized
INFO - 2021-12-13 01:50:50 --> Output Class Initialized
INFO - 2021-12-13 01:50:50 --> Security Class Initialized
DEBUG - 2021-12-13 01:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:50:50 --> Input Class Initialized
INFO - 2021-12-13 01:50:50 --> Language Class Initialized
INFO - 2021-12-13 01:50:50 --> Language Class Initialized
INFO - 2021-12-13 01:50:50 --> Config Class Initialized
INFO - 2021-12-13 01:50:50 --> Loader Class Initialized
INFO - 2021-12-13 01:50:50 --> Helper loaded: url_helper
INFO - 2021-12-13 01:50:50 --> Helper loaded: file_helper
INFO - 2021-12-13 01:50:50 --> Helper loaded: form_helper
INFO - 2021-12-13 01:50:50 --> Helper loaded: my_helper
INFO - 2021-12-13 01:50:50 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:50:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:50:50 --> Controller Class Initialized
DEBUG - 2021-12-13 01:50:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 01:50:50 --> Final output sent to browser
DEBUG - 2021-12-13 01:50:50 --> Total execution time: 0.0610
INFO - 2021-12-13 01:50:51 --> Config Class Initialized
INFO - 2021-12-13 01:50:51 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:50:51 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:50:51 --> Utf8 Class Initialized
INFO - 2021-12-13 01:50:51 --> URI Class Initialized
INFO - 2021-12-13 01:50:51 --> Router Class Initialized
INFO - 2021-12-13 01:50:51 --> Output Class Initialized
INFO - 2021-12-13 01:50:51 --> Security Class Initialized
DEBUG - 2021-12-13 01:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:50:51 --> Input Class Initialized
INFO - 2021-12-13 01:50:51 --> Language Class Initialized
INFO - 2021-12-13 01:50:51 --> Language Class Initialized
INFO - 2021-12-13 01:50:51 --> Config Class Initialized
INFO - 2021-12-13 01:50:51 --> Loader Class Initialized
INFO - 2021-12-13 01:50:51 --> Helper loaded: url_helper
INFO - 2021-12-13 01:50:51 --> Helper loaded: file_helper
INFO - 2021-12-13 01:50:51 --> Helper loaded: form_helper
INFO - 2021-12-13 01:50:51 --> Helper loaded: my_helper
INFO - 2021-12-13 01:50:51 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:50:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:50:51 --> Controller Class Initialized
DEBUG - 2021-12-13 01:50:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 01:50:51 --> Final output sent to browser
DEBUG - 2021-12-13 01:50:51 --> Total execution time: 0.0610
INFO - 2021-12-13 01:50:54 --> Config Class Initialized
INFO - 2021-12-13 01:50:54 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:50:54 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:50:54 --> Utf8 Class Initialized
INFO - 2021-12-13 01:50:54 --> URI Class Initialized
INFO - 2021-12-13 01:50:54 --> Router Class Initialized
INFO - 2021-12-13 01:50:54 --> Output Class Initialized
INFO - 2021-12-13 01:50:54 --> Security Class Initialized
DEBUG - 2021-12-13 01:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:50:54 --> Input Class Initialized
INFO - 2021-12-13 01:50:54 --> Language Class Initialized
INFO - 2021-12-13 01:50:54 --> Language Class Initialized
INFO - 2021-12-13 01:50:54 --> Config Class Initialized
INFO - 2021-12-13 01:50:54 --> Loader Class Initialized
INFO - 2021-12-13 01:50:54 --> Helper loaded: url_helper
INFO - 2021-12-13 01:50:54 --> Helper loaded: file_helper
INFO - 2021-12-13 01:50:54 --> Helper loaded: form_helper
INFO - 2021-12-13 01:50:54 --> Helper loaded: my_helper
INFO - 2021-12-13 01:50:54 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:50:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:50:54 --> Controller Class Initialized
DEBUG - 2021-12-13 01:50:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 01:50:54 --> Final output sent to browser
DEBUG - 2021-12-13 01:50:54 --> Total execution time: 0.0490
INFO - 2021-12-13 01:50:55 --> Config Class Initialized
INFO - 2021-12-13 01:50:55 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:50:55 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:50:55 --> Utf8 Class Initialized
INFO - 2021-12-13 01:50:55 --> URI Class Initialized
INFO - 2021-12-13 01:50:55 --> Router Class Initialized
INFO - 2021-12-13 01:50:55 --> Output Class Initialized
INFO - 2021-12-13 01:50:55 --> Security Class Initialized
DEBUG - 2021-12-13 01:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:50:55 --> Input Class Initialized
INFO - 2021-12-13 01:50:55 --> Language Class Initialized
INFO - 2021-12-13 01:50:55 --> Language Class Initialized
INFO - 2021-12-13 01:50:55 --> Config Class Initialized
INFO - 2021-12-13 01:50:55 --> Loader Class Initialized
INFO - 2021-12-13 01:50:55 --> Helper loaded: url_helper
INFO - 2021-12-13 01:50:55 --> Helper loaded: file_helper
INFO - 2021-12-13 01:50:55 --> Helper loaded: form_helper
INFO - 2021-12-13 01:50:55 --> Helper loaded: my_helper
INFO - 2021-12-13 01:50:55 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:50:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:50:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:50:55 --> Controller Class Initialized
DEBUG - 2021-12-13 01:50:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 01:50:55 --> Final output sent to browser
DEBUG - 2021-12-13 01:50:55 --> Total execution time: 0.0650
INFO - 2021-12-13 01:50:57 --> Config Class Initialized
INFO - 2021-12-13 01:50:57 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:50:57 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:50:57 --> Utf8 Class Initialized
INFO - 2021-12-13 01:50:57 --> URI Class Initialized
INFO - 2021-12-13 01:50:57 --> Router Class Initialized
INFO - 2021-12-13 01:50:57 --> Output Class Initialized
INFO - 2021-12-13 01:50:57 --> Security Class Initialized
DEBUG - 2021-12-13 01:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:50:57 --> Input Class Initialized
INFO - 2021-12-13 01:50:57 --> Language Class Initialized
INFO - 2021-12-13 01:50:57 --> Language Class Initialized
INFO - 2021-12-13 01:50:57 --> Config Class Initialized
INFO - 2021-12-13 01:50:57 --> Loader Class Initialized
INFO - 2021-12-13 01:50:57 --> Helper loaded: url_helper
INFO - 2021-12-13 01:50:57 --> Helper loaded: file_helper
INFO - 2021-12-13 01:50:57 --> Helper loaded: form_helper
INFO - 2021-12-13 01:50:57 --> Helper loaded: my_helper
INFO - 2021-12-13 01:50:57 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:50:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:50:57 --> Controller Class Initialized
DEBUG - 2021-12-13 01:50:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 01:50:57 --> Final output sent to browser
DEBUG - 2021-12-13 01:50:57 --> Total execution time: 0.0530
INFO - 2021-12-13 01:50:59 --> Config Class Initialized
INFO - 2021-12-13 01:50:59 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:50:59 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:50:59 --> Utf8 Class Initialized
INFO - 2021-12-13 01:50:59 --> URI Class Initialized
INFO - 2021-12-13 01:50:59 --> Router Class Initialized
INFO - 2021-12-13 01:50:59 --> Output Class Initialized
INFO - 2021-12-13 01:50:59 --> Security Class Initialized
DEBUG - 2021-12-13 01:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:50:59 --> Input Class Initialized
INFO - 2021-12-13 01:50:59 --> Language Class Initialized
INFO - 2021-12-13 01:50:59 --> Language Class Initialized
INFO - 2021-12-13 01:50:59 --> Config Class Initialized
INFO - 2021-12-13 01:50:59 --> Loader Class Initialized
INFO - 2021-12-13 01:50:59 --> Helper loaded: url_helper
INFO - 2021-12-13 01:50:59 --> Helper loaded: file_helper
INFO - 2021-12-13 01:50:59 --> Helper loaded: form_helper
INFO - 2021-12-13 01:50:59 --> Helper loaded: my_helper
INFO - 2021-12-13 01:50:59 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:50:59 --> Controller Class Initialized
DEBUG - 2021-12-13 01:50:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 01:50:59 --> Final output sent to browser
DEBUG - 2021-12-13 01:50:59 --> Total execution time: 0.0620
INFO - 2021-12-13 01:51:01 --> Config Class Initialized
INFO - 2021-12-13 01:51:01 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:51:01 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:51:01 --> Utf8 Class Initialized
INFO - 2021-12-13 01:51:01 --> URI Class Initialized
INFO - 2021-12-13 01:51:01 --> Router Class Initialized
INFO - 2021-12-13 01:51:01 --> Output Class Initialized
INFO - 2021-12-13 01:51:01 --> Security Class Initialized
DEBUG - 2021-12-13 01:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:51:01 --> Input Class Initialized
INFO - 2021-12-13 01:51:01 --> Language Class Initialized
INFO - 2021-12-13 01:51:01 --> Language Class Initialized
INFO - 2021-12-13 01:51:01 --> Config Class Initialized
INFO - 2021-12-13 01:51:01 --> Loader Class Initialized
INFO - 2021-12-13 01:51:01 --> Helper loaded: url_helper
INFO - 2021-12-13 01:51:01 --> Helper loaded: file_helper
INFO - 2021-12-13 01:51:01 --> Helper loaded: form_helper
INFO - 2021-12-13 01:51:01 --> Helper loaded: my_helper
INFO - 2021-12-13 01:51:01 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:51:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:51:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:51:01 --> Controller Class Initialized
DEBUG - 2021-12-13 01:51:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 01:51:01 --> Final output sent to browser
DEBUG - 2021-12-13 01:51:01 --> Total execution time: 0.0610
INFO - 2021-12-13 01:51:02 --> Config Class Initialized
INFO - 2021-12-13 01:51:02 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:51:02 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:51:02 --> Utf8 Class Initialized
INFO - 2021-12-13 01:51:02 --> URI Class Initialized
INFO - 2021-12-13 01:51:02 --> Router Class Initialized
INFO - 2021-12-13 01:51:02 --> Output Class Initialized
INFO - 2021-12-13 01:51:02 --> Security Class Initialized
DEBUG - 2021-12-13 01:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:51:02 --> Input Class Initialized
INFO - 2021-12-13 01:51:02 --> Language Class Initialized
INFO - 2021-12-13 01:51:02 --> Language Class Initialized
INFO - 2021-12-13 01:51:02 --> Config Class Initialized
INFO - 2021-12-13 01:51:02 --> Loader Class Initialized
INFO - 2021-12-13 01:51:02 --> Helper loaded: url_helper
INFO - 2021-12-13 01:51:02 --> Helper loaded: file_helper
INFO - 2021-12-13 01:51:02 --> Helper loaded: form_helper
INFO - 2021-12-13 01:51:02 --> Helper loaded: my_helper
INFO - 2021-12-13 01:51:02 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:51:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:51:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:51:02 --> Controller Class Initialized
DEBUG - 2021-12-13 01:51:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 01:51:02 --> Final output sent to browser
DEBUG - 2021-12-13 01:51:02 --> Total execution time: 0.0640
INFO - 2021-12-13 01:51:05 --> Config Class Initialized
INFO - 2021-12-13 01:51:05 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:51:05 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:51:05 --> Utf8 Class Initialized
INFO - 2021-12-13 01:51:05 --> URI Class Initialized
INFO - 2021-12-13 01:51:05 --> Router Class Initialized
INFO - 2021-12-13 01:51:05 --> Output Class Initialized
INFO - 2021-12-13 01:51:05 --> Security Class Initialized
DEBUG - 2021-12-13 01:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:51:05 --> Input Class Initialized
INFO - 2021-12-13 01:51:05 --> Language Class Initialized
INFO - 2021-12-13 01:51:05 --> Language Class Initialized
INFO - 2021-12-13 01:51:05 --> Config Class Initialized
INFO - 2021-12-13 01:51:05 --> Loader Class Initialized
INFO - 2021-12-13 01:51:05 --> Helper loaded: url_helper
INFO - 2021-12-13 01:51:05 --> Helper loaded: file_helper
INFO - 2021-12-13 01:51:05 --> Helper loaded: form_helper
INFO - 2021-12-13 01:51:05 --> Helper loaded: my_helper
INFO - 2021-12-13 01:51:05 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:51:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:51:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:51:05 --> Controller Class Initialized
DEBUG - 2021-12-13 01:51:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 01:51:05 --> Final output sent to browser
DEBUG - 2021-12-13 01:51:05 --> Total execution time: 0.0570
INFO - 2021-12-13 01:51:07 --> Config Class Initialized
INFO - 2021-12-13 01:51:07 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:51:07 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:51:07 --> Utf8 Class Initialized
INFO - 2021-12-13 01:51:07 --> URI Class Initialized
INFO - 2021-12-13 01:51:07 --> Router Class Initialized
INFO - 2021-12-13 01:51:07 --> Output Class Initialized
INFO - 2021-12-13 01:51:07 --> Security Class Initialized
DEBUG - 2021-12-13 01:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:51:07 --> Input Class Initialized
INFO - 2021-12-13 01:51:07 --> Language Class Initialized
INFO - 2021-12-13 01:51:07 --> Language Class Initialized
INFO - 2021-12-13 01:51:07 --> Config Class Initialized
INFO - 2021-12-13 01:51:07 --> Loader Class Initialized
INFO - 2021-12-13 01:51:07 --> Helper loaded: url_helper
INFO - 2021-12-13 01:51:07 --> Helper loaded: file_helper
INFO - 2021-12-13 01:51:07 --> Helper loaded: form_helper
INFO - 2021-12-13 01:51:07 --> Helper loaded: my_helper
INFO - 2021-12-13 01:51:07 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:51:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:51:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:51:07 --> Controller Class Initialized
DEBUG - 2021-12-13 01:51:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 01:51:07 --> Final output sent to browser
DEBUG - 2021-12-13 01:51:07 --> Total execution time: 0.0580
INFO - 2021-12-13 01:51:08 --> Config Class Initialized
INFO - 2021-12-13 01:51:08 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:51:08 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:51:08 --> Utf8 Class Initialized
INFO - 2021-12-13 01:51:08 --> URI Class Initialized
INFO - 2021-12-13 01:51:08 --> Router Class Initialized
INFO - 2021-12-13 01:51:08 --> Output Class Initialized
INFO - 2021-12-13 01:51:08 --> Security Class Initialized
DEBUG - 2021-12-13 01:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:51:08 --> Input Class Initialized
INFO - 2021-12-13 01:51:08 --> Language Class Initialized
INFO - 2021-12-13 01:51:08 --> Language Class Initialized
INFO - 2021-12-13 01:51:08 --> Config Class Initialized
INFO - 2021-12-13 01:51:08 --> Loader Class Initialized
INFO - 2021-12-13 01:51:08 --> Helper loaded: url_helper
INFO - 2021-12-13 01:51:08 --> Helper loaded: file_helper
INFO - 2021-12-13 01:51:08 --> Helper loaded: form_helper
INFO - 2021-12-13 01:51:08 --> Helper loaded: my_helper
INFO - 2021-12-13 01:51:08 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:51:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:51:08 --> Controller Class Initialized
DEBUG - 2021-12-13 01:51:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 01:51:08 --> Final output sent to browser
DEBUG - 2021-12-13 01:51:08 --> Total execution time: 0.0560
INFO - 2021-12-13 01:51:10 --> Config Class Initialized
INFO - 2021-12-13 01:51:10 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:51:10 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:51:10 --> Utf8 Class Initialized
INFO - 2021-12-13 01:51:10 --> URI Class Initialized
INFO - 2021-12-13 01:51:10 --> Router Class Initialized
INFO - 2021-12-13 01:51:10 --> Output Class Initialized
INFO - 2021-12-13 01:51:10 --> Security Class Initialized
DEBUG - 2021-12-13 01:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:51:10 --> Input Class Initialized
INFO - 2021-12-13 01:51:10 --> Language Class Initialized
INFO - 2021-12-13 01:51:10 --> Language Class Initialized
INFO - 2021-12-13 01:51:10 --> Config Class Initialized
INFO - 2021-12-13 01:51:10 --> Loader Class Initialized
INFO - 2021-12-13 01:51:10 --> Helper loaded: url_helper
INFO - 2021-12-13 01:51:10 --> Helper loaded: file_helper
INFO - 2021-12-13 01:51:10 --> Helper loaded: form_helper
INFO - 2021-12-13 01:51:10 --> Helper loaded: my_helper
INFO - 2021-12-13 01:51:10 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:51:10 --> Controller Class Initialized
DEBUG - 2021-12-13 01:51:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 01:51:10 --> Final output sent to browser
DEBUG - 2021-12-13 01:51:10 --> Total execution time: 0.0570
INFO - 2021-12-13 01:51:12 --> Config Class Initialized
INFO - 2021-12-13 01:51:12 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:51:13 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:51:13 --> Utf8 Class Initialized
INFO - 2021-12-13 01:51:13 --> URI Class Initialized
INFO - 2021-12-13 01:51:13 --> Router Class Initialized
INFO - 2021-12-13 01:51:13 --> Output Class Initialized
INFO - 2021-12-13 01:51:13 --> Security Class Initialized
DEBUG - 2021-12-13 01:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:51:13 --> Input Class Initialized
INFO - 2021-12-13 01:51:13 --> Language Class Initialized
INFO - 2021-12-13 01:51:13 --> Language Class Initialized
INFO - 2021-12-13 01:51:13 --> Config Class Initialized
INFO - 2021-12-13 01:51:13 --> Loader Class Initialized
INFO - 2021-12-13 01:51:13 --> Helper loaded: url_helper
INFO - 2021-12-13 01:51:13 --> Helper loaded: file_helper
INFO - 2021-12-13 01:51:13 --> Helper loaded: form_helper
INFO - 2021-12-13 01:51:13 --> Helper loaded: my_helper
INFO - 2021-12-13 01:51:13 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:51:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:51:13 --> Controller Class Initialized
DEBUG - 2021-12-13 01:51:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 01:51:13 --> Final output sent to browser
DEBUG - 2021-12-13 01:51:13 --> Total execution time: 0.0530
INFO - 2021-12-13 01:51:14 --> Config Class Initialized
INFO - 2021-12-13 01:51:14 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:51:14 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:51:14 --> Utf8 Class Initialized
INFO - 2021-12-13 01:51:14 --> URI Class Initialized
INFO - 2021-12-13 01:51:14 --> Router Class Initialized
INFO - 2021-12-13 01:51:14 --> Output Class Initialized
INFO - 2021-12-13 01:51:14 --> Security Class Initialized
DEBUG - 2021-12-13 01:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:51:14 --> Input Class Initialized
INFO - 2021-12-13 01:51:14 --> Language Class Initialized
INFO - 2021-12-13 01:51:14 --> Language Class Initialized
INFO - 2021-12-13 01:51:14 --> Config Class Initialized
INFO - 2021-12-13 01:51:14 --> Loader Class Initialized
INFO - 2021-12-13 01:51:14 --> Helper loaded: url_helper
INFO - 2021-12-13 01:51:14 --> Helper loaded: file_helper
INFO - 2021-12-13 01:51:14 --> Helper loaded: form_helper
INFO - 2021-12-13 01:51:14 --> Helper loaded: my_helper
INFO - 2021-12-13 01:51:14 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:51:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:51:14 --> Controller Class Initialized
DEBUG - 2021-12-13 01:51:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 01:51:14 --> Final output sent to browser
DEBUG - 2021-12-13 01:51:14 --> Total execution time: 0.0580
INFO - 2021-12-13 01:51:16 --> Config Class Initialized
INFO - 2021-12-13 01:51:16 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:51:16 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:51:16 --> Utf8 Class Initialized
INFO - 2021-12-13 01:51:16 --> URI Class Initialized
INFO - 2021-12-13 01:51:16 --> Router Class Initialized
INFO - 2021-12-13 01:51:16 --> Output Class Initialized
INFO - 2021-12-13 01:51:16 --> Security Class Initialized
DEBUG - 2021-12-13 01:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:51:16 --> Input Class Initialized
INFO - 2021-12-13 01:51:16 --> Language Class Initialized
INFO - 2021-12-13 01:51:16 --> Language Class Initialized
INFO - 2021-12-13 01:51:16 --> Config Class Initialized
INFO - 2021-12-13 01:51:16 --> Loader Class Initialized
INFO - 2021-12-13 01:51:16 --> Helper loaded: url_helper
INFO - 2021-12-13 01:51:16 --> Helper loaded: file_helper
INFO - 2021-12-13 01:51:16 --> Helper loaded: form_helper
INFO - 2021-12-13 01:51:16 --> Helper loaded: my_helper
INFO - 2021-12-13 01:51:16 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:51:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:51:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:51:16 --> Controller Class Initialized
DEBUG - 2021-12-13 01:51:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 01:51:16 --> Final output sent to browser
DEBUG - 2021-12-13 01:51:16 --> Total execution time: 0.0680
INFO - 2021-12-13 01:51:18 --> Config Class Initialized
INFO - 2021-12-13 01:51:18 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:51:18 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:51:18 --> Utf8 Class Initialized
INFO - 2021-12-13 01:51:18 --> URI Class Initialized
INFO - 2021-12-13 01:51:18 --> Router Class Initialized
INFO - 2021-12-13 01:51:18 --> Output Class Initialized
INFO - 2021-12-13 01:51:18 --> Security Class Initialized
DEBUG - 2021-12-13 01:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:51:18 --> Input Class Initialized
INFO - 2021-12-13 01:51:18 --> Language Class Initialized
INFO - 2021-12-13 01:51:18 --> Language Class Initialized
INFO - 2021-12-13 01:51:18 --> Config Class Initialized
INFO - 2021-12-13 01:51:18 --> Loader Class Initialized
INFO - 2021-12-13 01:51:18 --> Helper loaded: url_helper
INFO - 2021-12-13 01:51:18 --> Helper loaded: file_helper
INFO - 2021-12-13 01:51:18 --> Helper loaded: form_helper
INFO - 2021-12-13 01:51:18 --> Helper loaded: my_helper
INFO - 2021-12-13 01:51:18 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:51:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:51:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:51:18 --> Controller Class Initialized
DEBUG - 2021-12-13 01:51:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 01:51:18 --> Final output sent to browser
DEBUG - 2021-12-13 01:51:18 --> Total execution time: 0.0600
INFO - 2021-12-13 01:51:21 --> Config Class Initialized
INFO - 2021-12-13 01:51:21 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:51:21 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:51:21 --> Utf8 Class Initialized
INFO - 2021-12-13 01:51:21 --> URI Class Initialized
INFO - 2021-12-13 01:51:21 --> Router Class Initialized
INFO - 2021-12-13 01:51:21 --> Output Class Initialized
INFO - 2021-12-13 01:51:21 --> Security Class Initialized
DEBUG - 2021-12-13 01:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:51:21 --> Input Class Initialized
INFO - 2021-12-13 01:51:21 --> Language Class Initialized
INFO - 2021-12-13 01:51:21 --> Language Class Initialized
INFO - 2021-12-13 01:51:21 --> Config Class Initialized
INFO - 2021-12-13 01:51:21 --> Loader Class Initialized
INFO - 2021-12-13 01:51:21 --> Helper loaded: url_helper
INFO - 2021-12-13 01:51:21 --> Helper loaded: file_helper
INFO - 2021-12-13 01:51:21 --> Helper loaded: form_helper
INFO - 2021-12-13 01:51:21 --> Helper loaded: my_helper
INFO - 2021-12-13 01:51:21 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:51:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:51:21 --> Controller Class Initialized
DEBUG - 2021-12-13 01:51:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 01:51:21 --> Final output sent to browser
DEBUG - 2021-12-13 01:51:21 --> Total execution time: 0.0580
INFO - 2021-12-13 01:51:23 --> Config Class Initialized
INFO - 2021-12-13 01:51:23 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:51:23 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:51:23 --> Utf8 Class Initialized
INFO - 2021-12-13 01:51:23 --> URI Class Initialized
INFO - 2021-12-13 01:51:23 --> Router Class Initialized
INFO - 2021-12-13 01:51:23 --> Output Class Initialized
INFO - 2021-12-13 01:51:23 --> Security Class Initialized
DEBUG - 2021-12-13 01:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:51:23 --> Input Class Initialized
INFO - 2021-12-13 01:51:23 --> Language Class Initialized
INFO - 2021-12-13 01:51:23 --> Language Class Initialized
INFO - 2021-12-13 01:51:23 --> Config Class Initialized
INFO - 2021-12-13 01:51:23 --> Loader Class Initialized
INFO - 2021-12-13 01:51:23 --> Helper loaded: url_helper
INFO - 2021-12-13 01:51:23 --> Helper loaded: file_helper
INFO - 2021-12-13 01:51:23 --> Helper loaded: form_helper
INFO - 2021-12-13 01:51:23 --> Helper loaded: my_helper
INFO - 2021-12-13 01:51:23 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:51:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:51:23 --> Controller Class Initialized
DEBUG - 2021-12-13 01:51:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 01:51:23 --> Final output sent to browser
DEBUG - 2021-12-13 01:51:23 --> Total execution time: 0.0560
INFO - 2021-12-13 01:51:24 --> Config Class Initialized
INFO - 2021-12-13 01:51:24 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:51:24 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:51:24 --> Utf8 Class Initialized
INFO - 2021-12-13 01:51:24 --> URI Class Initialized
INFO - 2021-12-13 01:51:24 --> Router Class Initialized
INFO - 2021-12-13 01:51:24 --> Output Class Initialized
INFO - 2021-12-13 01:51:24 --> Security Class Initialized
DEBUG - 2021-12-13 01:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:51:24 --> Input Class Initialized
INFO - 2021-12-13 01:51:24 --> Language Class Initialized
INFO - 2021-12-13 01:51:24 --> Language Class Initialized
INFO - 2021-12-13 01:51:24 --> Config Class Initialized
INFO - 2021-12-13 01:51:24 --> Loader Class Initialized
INFO - 2021-12-13 01:51:24 --> Helper loaded: url_helper
INFO - 2021-12-13 01:51:24 --> Helper loaded: file_helper
INFO - 2021-12-13 01:51:24 --> Helper loaded: form_helper
INFO - 2021-12-13 01:51:24 --> Helper loaded: my_helper
INFO - 2021-12-13 01:51:24 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:51:24 --> Controller Class Initialized
DEBUG - 2021-12-13 01:51:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 01:51:24 --> Final output sent to browser
DEBUG - 2021-12-13 01:51:24 --> Total execution time: 0.0630
INFO - 2021-12-13 01:51:27 --> Config Class Initialized
INFO - 2021-12-13 01:51:27 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:51:27 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:51:27 --> Utf8 Class Initialized
INFO - 2021-12-13 01:51:27 --> URI Class Initialized
INFO - 2021-12-13 01:51:27 --> Router Class Initialized
INFO - 2021-12-13 01:51:27 --> Output Class Initialized
INFO - 2021-12-13 01:51:27 --> Security Class Initialized
DEBUG - 2021-12-13 01:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:51:27 --> Input Class Initialized
INFO - 2021-12-13 01:51:27 --> Language Class Initialized
INFO - 2021-12-13 01:51:27 --> Language Class Initialized
INFO - 2021-12-13 01:51:27 --> Config Class Initialized
INFO - 2021-12-13 01:51:27 --> Loader Class Initialized
INFO - 2021-12-13 01:51:27 --> Helper loaded: url_helper
INFO - 2021-12-13 01:51:27 --> Helper loaded: file_helper
INFO - 2021-12-13 01:51:27 --> Helper loaded: form_helper
INFO - 2021-12-13 01:51:27 --> Helper loaded: my_helper
INFO - 2021-12-13 01:51:27 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:51:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:51:27 --> Controller Class Initialized
DEBUG - 2021-12-13 01:51:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 01:51:27 --> Final output sent to browser
DEBUG - 2021-12-13 01:51:27 --> Total execution time: 0.0490
INFO - 2021-12-13 01:51:29 --> Config Class Initialized
INFO - 2021-12-13 01:51:29 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:51:29 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:51:29 --> Utf8 Class Initialized
INFO - 2021-12-13 01:51:29 --> URI Class Initialized
INFO - 2021-12-13 01:51:29 --> Router Class Initialized
INFO - 2021-12-13 01:51:29 --> Output Class Initialized
INFO - 2021-12-13 01:51:29 --> Security Class Initialized
DEBUG - 2021-12-13 01:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:51:29 --> Input Class Initialized
INFO - 2021-12-13 01:51:29 --> Language Class Initialized
INFO - 2021-12-13 01:51:29 --> Language Class Initialized
INFO - 2021-12-13 01:51:29 --> Config Class Initialized
INFO - 2021-12-13 01:51:29 --> Loader Class Initialized
INFO - 2021-12-13 01:51:29 --> Helper loaded: url_helper
INFO - 2021-12-13 01:51:29 --> Helper loaded: file_helper
INFO - 2021-12-13 01:51:29 --> Helper loaded: form_helper
INFO - 2021-12-13 01:51:29 --> Helper loaded: my_helper
INFO - 2021-12-13 01:51:29 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:51:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:51:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:51:29 --> Controller Class Initialized
DEBUG - 2021-12-13 01:51:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 01:51:29 --> Final output sent to browser
DEBUG - 2021-12-13 01:51:29 --> Total execution time: 0.0650
INFO - 2021-12-13 01:51:30 --> Config Class Initialized
INFO - 2021-12-13 01:51:30 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:51:30 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:51:30 --> Utf8 Class Initialized
INFO - 2021-12-13 01:51:30 --> URI Class Initialized
INFO - 2021-12-13 01:51:30 --> Router Class Initialized
INFO - 2021-12-13 01:51:30 --> Output Class Initialized
INFO - 2021-12-13 01:51:30 --> Security Class Initialized
DEBUG - 2021-12-13 01:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:51:30 --> Input Class Initialized
INFO - 2021-12-13 01:51:30 --> Language Class Initialized
INFO - 2021-12-13 01:51:30 --> Language Class Initialized
INFO - 2021-12-13 01:51:30 --> Config Class Initialized
INFO - 2021-12-13 01:51:30 --> Loader Class Initialized
INFO - 2021-12-13 01:51:30 --> Helper loaded: url_helper
INFO - 2021-12-13 01:51:30 --> Helper loaded: file_helper
INFO - 2021-12-13 01:51:30 --> Helper loaded: form_helper
INFO - 2021-12-13 01:51:30 --> Helper loaded: my_helper
INFO - 2021-12-13 01:51:30 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:51:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:51:30 --> Controller Class Initialized
DEBUG - 2021-12-13 01:51:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 01:51:30 --> Final output sent to browser
DEBUG - 2021-12-13 01:51:30 --> Total execution time: 0.0670
INFO - 2021-12-13 01:51:33 --> Config Class Initialized
INFO - 2021-12-13 01:51:33 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:51:33 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:51:33 --> Utf8 Class Initialized
INFO - 2021-12-13 01:51:33 --> URI Class Initialized
INFO - 2021-12-13 01:51:33 --> Router Class Initialized
INFO - 2021-12-13 01:51:33 --> Output Class Initialized
INFO - 2021-12-13 01:51:33 --> Security Class Initialized
DEBUG - 2021-12-13 01:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:51:33 --> Input Class Initialized
INFO - 2021-12-13 01:51:33 --> Language Class Initialized
INFO - 2021-12-13 01:51:33 --> Language Class Initialized
INFO - 2021-12-13 01:51:33 --> Config Class Initialized
INFO - 2021-12-13 01:51:33 --> Loader Class Initialized
INFO - 2021-12-13 01:51:33 --> Helper loaded: url_helper
INFO - 2021-12-13 01:51:33 --> Helper loaded: file_helper
INFO - 2021-12-13 01:51:33 --> Helper loaded: form_helper
INFO - 2021-12-13 01:51:33 --> Helper loaded: my_helper
INFO - 2021-12-13 01:51:33 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:51:33 --> Controller Class Initialized
DEBUG - 2021-12-13 01:51:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 01:51:33 --> Final output sent to browser
DEBUG - 2021-12-13 01:51:33 --> Total execution time: 0.0670
INFO - 2021-12-13 01:51:35 --> Config Class Initialized
INFO - 2021-12-13 01:51:35 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:51:35 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:51:35 --> Utf8 Class Initialized
INFO - 2021-12-13 01:51:35 --> URI Class Initialized
INFO - 2021-12-13 01:51:35 --> Router Class Initialized
INFO - 2021-12-13 01:51:35 --> Output Class Initialized
INFO - 2021-12-13 01:51:35 --> Security Class Initialized
DEBUG - 2021-12-13 01:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:51:35 --> Input Class Initialized
INFO - 2021-12-13 01:51:35 --> Language Class Initialized
INFO - 2021-12-13 01:51:35 --> Language Class Initialized
INFO - 2021-12-13 01:51:35 --> Config Class Initialized
INFO - 2021-12-13 01:51:35 --> Loader Class Initialized
INFO - 2021-12-13 01:51:35 --> Helper loaded: url_helper
INFO - 2021-12-13 01:51:35 --> Helper loaded: file_helper
INFO - 2021-12-13 01:51:35 --> Helper loaded: form_helper
INFO - 2021-12-13 01:51:35 --> Helper loaded: my_helper
INFO - 2021-12-13 01:51:35 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:51:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:51:35 --> Controller Class Initialized
DEBUG - 2021-12-13 01:51:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 01:51:35 --> Final output sent to browser
DEBUG - 2021-12-13 01:51:35 --> Total execution time: 0.0490
INFO - 2021-12-13 01:51:37 --> Config Class Initialized
INFO - 2021-12-13 01:51:37 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:51:37 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:51:37 --> Utf8 Class Initialized
INFO - 2021-12-13 01:51:37 --> URI Class Initialized
INFO - 2021-12-13 01:51:37 --> Router Class Initialized
INFO - 2021-12-13 01:51:37 --> Output Class Initialized
INFO - 2021-12-13 01:51:37 --> Security Class Initialized
DEBUG - 2021-12-13 01:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:51:37 --> Input Class Initialized
INFO - 2021-12-13 01:51:37 --> Language Class Initialized
INFO - 2021-12-13 01:51:37 --> Language Class Initialized
INFO - 2021-12-13 01:51:37 --> Config Class Initialized
INFO - 2021-12-13 01:51:37 --> Loader Class Initialized
INFO - 2021-12-13 01:51:37 --> Helper loaded: url_helper
INFO - 2021-12-13 01:51:37 --> Helper loaded: file_helper
INFO - 2021-12-13 01:51:37 --> Helper loaded: form_helper
INFO - 2021-12-13 01:51:37 --> Helper loaded: my_helper
INFO - 2021-12-13 01:51:37 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:51:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:51:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:51:37 --> Controller Class Initialized
DEBUG - 2021-12-13 01:51:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 01:51:37 --> Final output sent to browser
DEBUG - 2021-12-13 01:51:37 --> Total execution time: 0.0590
INFO - 2021-12-13 01:55:20 --> Config Class Initialized
INFO - 2021-12-13 01:55:20 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:55:20 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:55:20 --> Utf8 Class Initialized
INFO - 2021-12-13 01:55:20 --> URI Class Initialized
INFO - 2021-12-13 01:55:20 --> Router Class Initialized
INFO - 2021-12-13 01:55:20 --> Output Class Initialized
INFO - 2021-12-13 01:55:20 --> Security Class Initialized
DEBUG - 2021-12-13 01:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:55:20 --> Input Class Initialized
INFO - 2021-12-13 01:55:20 --> Language Class Initialized
INFO - 2021-12-13 01:55:20 --> Language Class Initialized
INFO - 2021-12-13 01:55:20 --> Config Class Initialized
INFO - 2021-12-13 01:55:20 --> Loader Class Initialized
INFO - 2021-12-13 01:55:20 --> Helper loaded: url_helper
INFO - 2021-12-13 01:55:20 --> Helper loaded: file_helper
INFO - 2021-12-13 01:55:20 --> Helper loaded: form_helper
INFO - 2021-12-13 01:55:20 --> Helper loaded: my_helper
INFO - 2021-12-13 01:55:20 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:55:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:55:20 --> Controller Class Initialized
INFO - 2021-12-13 01:55:20 --> Helper loaded: cookie_helper
INFO - 2021-12-13 01:55:20 --> Config Class Initialized
INFO - 2021-12-13 01:55:20 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:55:20 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:55:20 --> Utf8 Class Initialized
INFO - 2021-12-13 01:55:20 --> URI Class Initialized
INFO - 2021-12-13 01:55:20 --> Router Class Initialized
INFO - 2021-12-13 01:55:20 --> Output Class Initialized
INFO - 2021-12-13 01:55:20 --> Security Class Initialized
DEBUG - 2021-12-13 01:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:55:20 --> Input Class Initialized
INFO - 2021-12-13 01:55:20 --> Language Class Initialized
INFO - 2021-12-13 01:55:20 --> Language Class Initialized
INFO - 2021-12-13 01:55:20 --> Config Class Initialized
INFO - 2021-12-13 01:55:20 --> Loader Class Initialized
INFO - 2021-12-13 01:55:20 --> Helper loaded: url_helper
INFO - 2021-12-13 01:55:20 --> Helper loaded: file_helper
INFO - 2021-12-13 01:55:20 --> Helper loaded: form_helper
INFO - 2021-12-13 01:55:20 --> Helper loaded: my_helper
INFO - 2021-12-13 01:55:20 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:55:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:55:20 --> Controller Class Initialized
DEBUG - 2021-12-13 01:55:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-13 01:55:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 01:55:20 --> Final output sent to browser
DEBUG - 2021-12-13 01:55:20 --> Total execution time: 0.0350
INFO - 2021-12-13 01:55:26 --> Config Class Initialized
INFO - 2021-12-13 01:55:26 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:55:26 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:55:26 --> Utf8 Class Initialized
INFO - 2021-12-13 01:55:26 --> URI Class Initialized
INFO - 2021-12-13 01:55:26 --> Router Class Initialized
INFO - 2021-12-13 01:55:26 --> Output Class Initialized
INFO - 2021-12-13 01:55:26 --> Security Class Initialized
DEBUG - 2021-12-13 01:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:55:26 --> Input Class Initialized
INFO - 2021-12-13 01:55:26 --> Language Class Initialized
INFO - 2021-12-13 01:55:26 --> Language Class Initialized
INFO - 2021-12-13 01:55:26 --> Config Class Initialized
INFO - 2021-12-13 01:55:26 --> Loader Class Initialized
INFO - 2021-12-13 01:55:26 --> Helper loaded: url_helper
INFO - 2021-12-13 01:55:26 --> Helper loaded: file_helper
INFO - 2021-12-13 01:55:26 --> Helper loaded: form_helper
INFO - 2021-12-13 01:55:26 --> Helper loaded: my_helper
INFO - 2021-12-13 01:55:26 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:55:26 --> Controller Class Initialized
INFO - 2021-12-13 01:55:26 --> Helper loaded: cookie_helper
INFO - 2021-12-13 01:55:26 --> Final output sent to browser
DEBUG - 2021-12-13 01:55:26 --> Total execution time: 0.0470
INFO - 2021-12-13 01:55:27 --> Config Class Initialized
INFO - 2021-12-13 01:55:27 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:55:27 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:55:27 --> Utf8 Class Initialized
INFO - 2021-12-13 01:55:27 --> URI Class Initialized
INFO - 2021-12-13 01:55:27 --> Router Class Initialized
INFO - 2021-12-13 01:55:27 --> Output Class Initialized
INFO - 2021-12-13 01:55:27 --> Security Class Initialized
DEBUG - 2021-12-13 01:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:55:27 --> Input Class Initialized
INFO - 2021-12-13 01:55:27 --> Language Class Initialized
INFO - 2021-12-13 01:55:27 --> Language Class Initialized
INFO - 2021-12-13 01:55:27 --> Config Class Initialized
INFO - 2021-12-13 01:55:27 --> Loader Class Initialized
INFO - 2021-12-13 01:55:27 --> Helper loaded: url_helper
INFO - 2021-12-13 01:55:27 --> Helper loaded: file_helper
INFO - 2021-12-13 01:55:27 --> Helper loaded: form_helper
INFO - 2021-12-13 01:55:27 --> Helper loaded: my_helper
INFO - 2021-12-13 01:55:27 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:55:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:55:27 --> Controller Class Initialized
DEBUG - 2021-12-13 01:55:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-13 01:55:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 01:55:27 --> Final output sent to browser
DEBUG - 2021-12-13 01:55:27 --> Total execution time: 0.2410
INFO - 2021-12-13 01:55:31 --> Config Class Initialized
INFO - 2021-12-13 01:55:31 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:55:31 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:55:31 --> Utf8 Class Initialized
INFO - 2021-12-13 01:55:31 --> URI Class Initialized
INFO - 2021-12-13 01:55:31 --> Router Class Initialized
INFO - 2021-12-13 01:55:31 --> Output Class Initialized
INFO - 2021-12-13 01:55:31 --> Security Class Initialized
DEBUG - 2021-12-13 01:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:55:31 --> Input Class Initialized
INFO - 2021-12-13 01:55:31 --> Language Class Initialized
INFO - 2021-12-13 01:55:31 --> Language Class Initialized
INFO - 2021-12-13 01:55:31 --> Config Class Initialized
INFO - 2021-12-13 01:55:31 --> Loader Class Initialized
INFO - 2021-12-13 01:55:31 --> Helper loaded: url_helper
INFO - 2021-12-13 01:55:31 --> Helper loaded: file_helper
INFO - 2021-12-13 01:55:31 --> Helper loaded: form_helper
INFO - 2021-12-13 01:55:31 --> Helper loaded: my_helper
INFO - 2021-12-13 01:55:31 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:55:31 --> Controller Class Initialized
DEBUG - 2021-12-13 01:55:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-13 01:55:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 01:55:31 --> Final output sent to browser
DEBUG - 2021-12-13 01:55:31 --> Total execution time: 0.0620
INFO - 2021-12-13 01:55:36 --> Config Class Initialized
INFO - 2021-12-13 01:55:36 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:55:36 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:55:36 --> Utf8 Class Initialized
INFO - 2021-12-13 01:55:36 --> URI Class Initialized
INFO - 2021-12-13 01:55:36 --> Router Class Initialized
INFO - 2021-12-13 01:55:36 --> Output Class Initialized
INFO - 2021-12-13 01:55:36 --> Security Class Initialized
DEBUG - 2021-12-13 01:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:55:36 --> Input Class Initialized
INFO - 2021-12-13 01:55:36 --> Language Class Initialized
INFO - 2021-12-13 01:55:36 --> Language Class Initialized
INFO - 2021-12-13 01:55:36 --> Config Class Initialized
INFO - 2021-12-13 01:55:36 --> Loader Class Initialized
INFO - 2021-12-13 01:55:36 --> Helper loaded: url_helper
INFO - 2021-12-13 01:55:36 --> Helper loaded: file_helper
INFO - 2021-12-13 01:55:36 --> Helper loaded: form_helper
INFO - 2021-12-13 01:55:36 --> Helper loaded: my_helper
INFO - 2021-12-13 01:55:36 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:55:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:55:36 --> Controller Class Initialized
DEBUG - 2021-12-13 01:55:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 01:55:36 --> Final output sent to browser
DEBUG - 2021-12-13 01:55:36 --> Total execution time: 0.1040
INFO - 2021-12-13 01:55:38 --> Config Class Initialized
INFO - 2021-12-13 01:55:38 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:55:38 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:55:38 --> Utf8 Class Initialized
INFO - 2021-12-13 01:55:38 --> URI Class Initialized
INFO - 2021-12-13 01:55:38 --> Router Class Initialized
INFO - 2021-12-13 01:55:38 --> Output Class Initialized
INFO - 2021-12-13 01:55:38 --> Security Class Initialized
DEBUG - 2021-12-13 01:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:55:38 --> Input Class Initialized
INFO - 2021-12-13 01:55:38 --> Language Class Initialized
INFO - 2021-12-13 01:55:38 --> Language Class Initialized
INFO - 2021-12-13 01:55:38 --> Config Class Initialized
INFO - 2021-12-13 01:55:38 --> Loader Class Initialized
INFO - 2021-12-13 01:55:38 --> Helper loaded: url_helper
INFO - 2021-12-13 01:55:38 --> Helper loaded: file_helper
INFO - 2021-12-13 01:55:38 --> Helper loaded: form_helper
INFO - 2021-12-13 01:55:38 --> Helper loaded: my_helper
INFO - 2021-12-13 01:55:38 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:55:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:55:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:55:38 --> Controller Class Initialized
DEBUG - 2021-12-13 01:55:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 01:55:38 --> Final output sent to browser
DEBUG - 2021-12-13 01:55:38 --> Total execution time: 0.0570
INFO - 2021-12-13 01:55:42 --> Config Class Initialized
INFO - 2021-12-13 01:55:42 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:55:42 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:55:42 --> Utf8 Class Initialized
INFO - 2021-12-13 01:55:42 --> URI Class Initialized
INFO - 2021-12-13 01:55:42 --> Router Class Initialized
INFO - 2021-12-13 01:55:42 --> Output Class Initialized
INFO - 2021-12-13 01:55:42 --> Security Class Initialized
DEBUG - 2021-12-13 01:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:55:42 --> Input Class Initialized
INFO - 2021-12-13 01:55:42 --> Language Class Initialized
INFO - 2021-12-13 01:55:42 --> Language Class Initialized
INFO - 2021-12-13 01:55:42 --> Config Class Initialized
INFO - 2021-12-13 01:55:42 --> Loader Class Initialized
INFO - 2021-12-13 01:55:42 --> Helper loaded: url_helper
INFO - 2021-12-13 01:55:42 --> Helper loaded: file_helper
INFO - 2021-12-13 01:55:42 --> Helper loaded: form_helper
INFO - 2021-12-13 01:55:42 --> Helper loaded: my_helper
INFO - 2021-12-13 01:55:42 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:55:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:55:42 --> Controller Class Initialized
DEBUG - 2021-12-13 01:55:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 01:55:42 --> Final output sent to browser
DEBUG - 2021-12-13 01:55:42 --> Total execution time: 0.0570
INFO - 2021-12-13 01:55:44 --> Config Class Initialized
INFO - 2021-12-13 01:55:44 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:55:44 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:55:44 --> Utf8 Class Initialized
INFO - 2021-12-13 01:55:44 --> URI Class Initialized
INFO - 2021-12-13 01:55:44 --> Router Class Initialized
INFO - 2021-12-13 01:55:44 --> Output Class Initialized
INFO - 2021-12-13 01:55:44 --> Security Class Initialized
DEBUG - 2021-12-13 01:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:55:44 --> Input Class Initialized
INFO - 2021-12-13 01:55:44 --> Language Class Initialized
INFO - 2021-12-13 01:55:44 --> Language Class Initialized
INFO - 2021-12-13 01:55:44 --> Config Class Initialized
INFO - 2021-12-13 01:55:44 --> Loader Class Initialized
INFO - 2021-12-13 01:55:44 --> Helper loaded: url_helper
INFO - 2021-12-13 01:55:44 --> Helper loaded: file_helper
INFO - 2021-12-13 01:55:44 --> Helper loaded: form_helper
INFO - 2021-12-13 01:55:44 --> Helper loaded: my_helper
INFO - 2021-12-13 01:55:44 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:55:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:55:44 --> Controller Class Initialized
DEBUG - 2021-12-13 01:55:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 01:55:44 --> Final output sent to browser
DEBUG - 2021-12-13 01:55:44 --> Total execution time: 0.0610
INFO - 2021-12-13 01:55:45 --> Config Class Initialized
INFO - 2021-12-13 01:55:45 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:55:45 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:55:45 --> Utf8 Class Initialized
INFO - 2021-12-13 01:55:45 --> URI Class Initialized
INFO - 2021-12-13 01:55:45 --> Router Class Initialized
INFO - 2021-12-13 01:55:45 --> Output Class Initialized
INFO - 2021-12-13 01:55:45 --> Security Class Initialized
DEBUG - 2021-12-13 01:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:55:45 --> Input Class Initialized
INFO - 2021-12-13 01:55:45 --> Language Class Initialized
INFO - 2021-12-13 01:55:45 --> Language Class Initialized
INFO - 2021-12-13 01:55:45 --> Config Class Initialized
INFO - 2021-12-13 01:55:45 --> Loader Class Initialized
INFO - 2021-12-13 01:55:45 --> Helper loaded: url_helper
INFO - 2021-12-13 01:55:45 --> Helper loaded: file_helper
INFO - 2021-12-13 01:55:45 --> Helper loaded: form_helper
INFO - 2021-12-13 01:55:45 --> Helper loaded: my_helper
INFO - 2021-12-13 01:55:45 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:55:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:55:45 --> Controller Class Initialized
DEBUG - 2021-12-13 01:55:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 01:55:45 --> Final output sent to browser
DEBUG - 2021-12-13 01:55:45 --> Total execution time: 0.0650
INFO - 2021-12-13 01:55:48 --> Config Class Initialized
INFO - 2021-12-13 01:55:48 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:55:48 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:55:48 --> Utf8 Class Initialized
INFO - 2021-12-13 01:55:48 --> URI Class Initialized
INFO - 2021-12-13 01:55:48 --> Router Class Initialized
INFO - 2021-12-13 01:55:48 --> Output Class Initialized
INFO - 2021-12-13 01:55:48 --> Security Class Initialized
DEBUG - 2021-12-13 01:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:55:48 --> Input Class Initialized
INFO - 2021-12-13 01:55:48 --> Language Class Initialized
INFO - 2021-12-13 01:55:48 --> Language Class Initialized
INFO - 2021-12-13 01:55:48 --> Config Class Initialized
INFO - 2021-12-13 01:55:48 --> Loader Class Initialized
INFO - 2021-12-13 01:55:48 --> Helper loaded: url_helper
INFO - 2021-12-13 01:55:48 --> Helper loaded: file_helper
INFO - 2021-12-13 01:55:48 --> Helper loaded: form_helper
INFO - 2021-12-13 01:55:48 --> Helper loaded: my_helper
INFO - 2021-12-13 01:55:48 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:55:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:55:48 --> Controller Class Initialized
DEBUG - 2021-12-13 01:55:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 01:55:48 --> Final output sent to browser
DEBUG - 2021-12-13 01:55:48 --> Total execution time: 0.0640
INFO - 2021-12-13 01:55:49 --> Config Class Initialized
INFO - 2021-12-13 01:55:49 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:55:49 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:55:49 --> Utf8 Class Initialized
INFO - 2021-12-13 01:55:49 --> URI Class Initialized
INFO - 2021-12-13 01:55:49 --> Router Class Initialized
INFO - 2021-12-13 01:55:49 --> Output Class Initialized
INFO - 2021-12-13 01:55:49 --> Security Class Initialized
DEBUG - 2021-12-13 01:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:55:49 --> Input Class Initialized
INFO - 2021-12-13 01:55:49 --> Language Class Initialized
INFO - 2021-12-13 01:55:49 --> Language Class Initialized
INFO - 2021-12-13 01:55:49 --> Config Class Initialized
INFO - 2021-12-13 01:55:49 --> Loader Class Initialized
INFO - 2021-12-13 01:55:49 --> Helper loaded: url_helper
INFO - 2021-12-13 01:55:49 --> Helper loaded: file_helper
INFO - 2021-12-13 01:55:49 --> Helper loaded: form_helper
INFO - 2021-12-13 01:55:49 --> Helper loaded: my_helper
INFO - 2021-12-13 01:55:49 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:55:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:55:50 --> Controller Class Initialized
DEBUG - 2021-12-13 01:55:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 01:55:50 --> Final output sent to browser
DEBUG - 2021-12-13 01:55:50 --> Total execution time: 0.0630
INFO - 2021-12-13 01:55:51 --> Config Class Initialized
INFO - 2021-12-13 01:55:51 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:55:51 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:55:51 --> Utf8 Class Initialized
INFO - 2021-12-13 01:55:51 --> URI Class Initialized
INFO - 2021-12-13 01:55:51 --> Router Class Initialized
INFO - 2021-12-13 01:55:51 --> Output Class Initialized
INFO - 2021-12-13 01:55:51 --> Security Class Initialized
DEBUG - 2021-12-13 01:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:55:51 --> Input Class Initialized
INFO - 2021-12-13 01:55:51 --> Language Class Initialized
INFO - 2021-12-13 01:55:51 --> Language Class Initialized
INFO - 2021-12-13 01:55:51 --> Config Class Initialized
INFO - 2021-12-13 01:55:51 --> Loader Class Initialized
INFO - 2021-12-13 01:55:51 --> Helper loaded: url_helper
INFO - 2021-12-13 01:55:51 --> Helper loaded: file_helper
INFO - 2021-12-13 01:55:51 --> Helper loaded: form_helper
INFO - 2021-12-13 01:55:51 --> Helper loaded: my_helper
INFO - 2021-12-13 01:55:51 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:55:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:55:51 --> Controller Class Initialized
DEBUG - 2021-12-13 01:55:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 01:55:51 --> Final output sent to browser
DEBUG - 2021-12-13 01:55:51 --> Total execution time: 0.0720
INFO - 2021-12-13 01:55:54 --> Config Class Initialized
INFO - 2021-12-13 01:55:54 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:55:54 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:55:54 --> Utf8 Class Initialized
INFO - 2021-12-13 01:55:54 --> URI Class Initialized
INFO - 2021-12-13 01:55:54 --> Router Class Initialized
INFO - 2021-12-13 01:55:54 --> Output Class Initialized
INFO - 2021-12-13 01:55:54 --> Security Class Initialized
DEBUG - 2021-12-13 01:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:55:54 --> Input Class Initialized
INFO - 2021-12-13 01:55:54 --> Language Class Initialized
INFO - 2021-12-13 01:55:54 --> Language Class Initialized
INFO - 2021-12-13 01:55:54 --> Config Class Initialized
INFO - 2021-12-13 01:55:54 --> Loader Class Initialized
INFO - 2021-12-13 01:55:54 --> Helper loaded: url_helper
INFO - 2021-12-13 01:55:54 --> Helper loaded: file_helper
INFO - 2021-12-13 01:55:54 --> Helper loaded: form_helper
INFO - 2021-12-13 01:55:54 --> Helper loaded: my_helper
INFO - 2021-12-13 01:55:54 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:55:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:55:54 --> Controller Class Initialized
DEBUG - 2021-12-13 01:55:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 01:55:54 --> Final output sent to browser
DEBUG - 2021-12-13 01:55:54 --> Total execution time: 0.0670
INFO - 2021-12-13 01:55:55 --> Config Class Initialized
INFO - 2021-12-13 01:55:55 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:55:55 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:55:55 --> Utf8 Class Initialized
INFO - 2021-12-13 01:55:55 --> URI Class Initialized
INFO - 2021-12-13 01:55:55 --> Router Class Initialized
INFO - 2021-12-13 01:55:55 --> Output Class Initialized
INFO - 2021-12-13 01:55:55 --> Security Class Initialized
DEBUG - 2021-12-13 01:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:55:55 --> Input Class Initialized
INFO - 2021-12-13 01:55:55 --> Language Class Initialized
INFO - 2021-12-13 01:55:55 --> Language Class Initialized
INFO - 2021-12-13 01:55:55 --> Config Class Initialized
INFO - 2021-12-13 01:55:55 --> Loader Class Initialized
INFO - 2021-12-13 01:55:55 --> Helper loaded: url_helper
INFO - 2021-12-13 01:55:55 --> Helper loaded: file_helper
INFO - 2021-12-13 01:55:55 --> Helper loaded: form_helper
INFO - 2021-12-13 01:55:55 --> Helper loaded: my_helper
INFO - 2021-12-13 01:55:55 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:55:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:55:55 --> Controller Class Initialized
DEBUG - 2021-12-13 01:55:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 01:55:55 --> Final output sent to browser
DEBUG - 2021-12-13 01:55:55 --> Total execution time: 0.0600
INFO - 2021-12-13 01:55:57 --> Config Class Initialized
INFO - 2021-12-13 01:55:57 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:55:57 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:55:57 --> Utf8 Class Initialized
INFO - 2021-12-13 01:55:57 --> URI Class Initialized
INFO - 2021-12-13 01:55:57 --> Router Class Initialized
INFO - 2021-12-13 01:55:57 --> Output Class Initialized
INFO - 2021-12-13 01:55:57 --> Security Class Initialized
DEBUG - 2021-12-13 01:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:55:57 --> Input Class Initialized
INFO - 2021-12-13 01:55:57 --> Language Class Initialized
INFO - 2021-12-13 01:55:57 --> Language Class Initialized
INFO - 2021-12-13 01:55:57 --> Config Class Initialized
INFO - 2021-12-13 01:55:57 --> Loader Class Initialized
INFO - 2021-12-13 01:55:57 --> Helper loaded: url_helper
INFO - 2021-12-13 01:55:57 --> Helper loaded: file_helper
INFO - 2021-12-13 01:55:57 --> Helper loaded: form_helper
INFO - 2021-12-13 01:55:57 --> Helper loaded: my_helper
INFO - 2021-12-13 01:55:57 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:55:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:55:57 --> Controller Class Initialized
DEBUG - 2021-12-13 01:55:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 01:55:57 --> Final output sent to browser
DEBUG - 2021-12-13 01:55:57 --> Total execution time: 0.0530
INFO - 2021-12-13 01:55:59 --> Config Class Initialized
INFO - 2021-12-13 01:55:59 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:55:59 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:55:59 --> Utf8 Class Initialized
INFO - 2021-12-13 01:55:59 --> URI Class Initialized
INFO - 2021-12-13 01:55:59 --> Router Class Initialized
INFO - 2021-12-13 01:55:59 --> Output Class Initialized
INFO - 2021-12-13 01:55:59 --> Security Class Initialized
DEBUG - 2021-12-13 01:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:55:59 --> Input Class Initialized
INFO - 2021-12-13 01:55:59 --> Language Class Initialized
INFO - 2021-12-13 01:55:59 --> Language Class Initialized
INFO - 2021-12-13 01:55:59 --> Config Class Initialized
INFO - 2021-12-13 01:55:59 --> Loader Class Initialized
INFO - 2021-12-13 01:55:59 --> Helper loaded: url_helper
INFO - 2021-12-13 01:55:59 --> Helper loaded: file_helper
INFO - 2021-12-13 01:55:59 --> Helper loaded: form_helper
INFO - 2021-12-13 01:55:59 --> Helper loaded: my_helper
INFO - 2021-12-13 01:55:59 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:55:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:55:59 --> Controller Class Initialized
DEBUG - 2021-12-13 01:55:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 01:55:59 --> Final output sent to browser
DEBUG - 2021-12-13 01:55:59 --> Total execution time: 0.0580
INFO - 2021-12-13 01:56:02 --> Config Class Initialized
INFO - 2021-12-13 01:56:02 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:56:02 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:56:02 --> Utf8 Class Initialized
INFO - 2021-12-13 01:56:02 --> URI Class Initialized
INFO - 2021-12-13 01:56:02 --> Router Class Initialized
INFO - 2021-12-13 01:56:02 --> Output Class Initialized
INFO - 2021-12-13 01:56:02 --> Security Class Initialized
DEBUG - 2021-12-13 01:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:56:02 --> Input Class Initialized
INFO - 2021-12-13 01:56:02 --> Language Class Initialized
INFO - 2021-12-13 01:56:03 --> Language Class Initialized
INFO - 2021-12-13 01:56:03 --> Config Class Initialized
INFO - 2021-12-13 01:56:03 --> Loader Class Initialized
INFO - 2021-12-13 01:56:03 --> Helper loaded: url_helper
INFO - 2021-12-13 01:56:03 --> Helper loaded: file_helper
INFO - 2021-12-13 01:56:03 --> Helper loaded: form_helper
INFO - 2021-12-13 01:56:03 --> Helper loaded: my_helper
INFO - 2021-12-13 01:56:03 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:56:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:56:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:56:03 --> Controller Class Initialized
DEBUG - 2021-12-13 01:56:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 01:56:03 --> Final output sent to browser
DEBUG - 2021-12-13 01:56:03 --> Total execution time: 0.0600
INFO - 2021-12-13 01:56:05 --> Config Class Initialized
INFO - 2021-12-13 01:56:05 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:56:05 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:56:05 --> Utf8 Class Initialized
INFO - 2021-12-13 01:56:05 --> URI Class Initialized
INFO - 2021-12-13 01:56:05 --> Router Class Initialized
INFO - 2021-12-13 01:56:05 --> Output Class Initialized
INFO - 2021-12-13 01:56:05 --> Security Class Initialized
DEBUG - 2021-12-13 01:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:56:05 --> Input Class Initialized
INFO - 2021-12-13 01:56:05 --> Language Class Initialized
INFO - 2021-12-13 01:56:05 --> Language Class Initialized
INFO - 2021-12-13 01:56:05 --> Config Class Initialized
INFO - 2021-12-13 01:56:05 --> Loader Class Initialized
INFO - 2021-12-13 01:56:05 --> Helper loaded: url_helper
INFO - 2021-12-13 01:56:05 --> Helper loaded: file_helper
INFO - 2021-12-13 01:56:05 --> Helper loaded: form_helper
INFO - 2021-12-13 01:56:05 --> Helper loaded: my_helper
INFO - 2021-12-13 01:56:05 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:56:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:56:05 --> Controller Class Initialized
DEBUG - 2021-12-13 01:56:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 01:56:05 --> Final output sent to browser
DEBUG - 2021-12-13 01:56:05 --> Total execution time: 0.0630
INFO - 2021-12-13 01:56:08 --> Config Class Initialized
INFO - 2021-12-13 01:56:08 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:56:08 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:56:08 --> Utf8 Class Initialized
INFO - 2021-12-13 01:56:08 --> URI Class Initialized
INFO - 2021-12-13 01:56:08 --> Router Class Initialized
INFO - 2021-12-13 01:56:08 --> Output Class Initialized
INFO - 2021-12-13 01:56:08 --> Security Class Initialized
DEBUG - 2021-12-13 01:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:56:08 --> Input Class Initialized
INFO - 2021-12-13 01:56:08 --> Language Class Initialized
INFO - 2021-12-13 01:56:08 --> Language Class Initialized
INFO - 2021-12-13 01:56:08 --> Config Class Initialized
INFO - 2021-12-13 01:56:08 --> Loader Class Initialized
INFO - 2021-12-13 01:56:08 --> Helper loaded: url_helper
INFO - 2021-12-13 01:56:08 --> Helper loaded: file_helper
INFO - 2021-12-13 01:56:08 --> Helper loaded: form_helper
INFO - 2021-12-13 01:56:08 --> Helper loaded: my_helper
INFO - 2021-12-13 01:56:08 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:56:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:56:08 --> Controller Class Initialized
DEBUG - 2021-12-13 01:56:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 01:56:08 --> Final output sent to browser
DEBUG - 2021-12-13 01:56:08 --> Total execution time: 0.0500
INFO - 2021-12-13 01:56:10 --> Config Class Initialized
INFO - 2021-12-13 01:56:10 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:56:10 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:56:10 --> Utf8 Class Initialized
INFO - 2021-12-13 01:56:10 --> URI Class Initialized
INFO - 2021-12-13 01:56:10 --> Router Class Initialized
INFO - 2021-12-13 01:56:10 --> Output Class Initialized
INFO - 2021-12-13 01:56:10 --> Security Class Initialized
DEBUG - 2021-12-13 01:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:56:10 --> Input Class Initialized
INFO - 2021-12-13 01:56:10 --> Language Class Initialized
INFO - 2021-12-13 01:56:10 --> Language Class Initialized
INFO - 2021-12-13 01:56:10 --> Config Class Initialized
INFO - 2021-12-13 01:56:10 --> Loader Class Initialized
INFO - 2021-12-13 01:56:10 --> Helper loaded: url_helper
INFO - 2021-12-13 01:56:10 --> Helper loaded: file_helper
INFO - 2021-12-13 01:56:10 --> Helper loaded: form_helper
INFO - 2021-12-13 01:56:10 --> Helper loaded: my_helper
INFO - 2021-12-13 01:56:10 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:56:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:56:10 --> Controller Class Initialized
DEBUG - 2021-12-13 01:56:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 01:56:10 --> Final output sent to browser
DEBUG - 2021-12-13 01:56:10 --> Total execution time: 0.0600
INFO - 2021-12-13 01:56:13 --> Config Class Initialized
INFO - 2021-12-13 01:56:13 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:56:13 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:56:13 --> Utf8 Class Initialized
INFO - 2021-12-13 01:56:13 --> URI Class Initialized
INFO - 2021-12-13 01:56:13 --> Router Class Initialized
INFO - 2021-12-13 01:56:13 --> Output Class Initialized
INFO - 2021-12-13 01:56:13 --> Security Class Initialized
DEBUG - 2021-12-13 01:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:56:13 --> Input Class Initialized
INFO - 2021-12-13 01:56:13 --> Language Class Initialized
INFO - 2021-12-13 01:56:13 --> Language Class Initialized
INFO - 2021-12-13 01:56:13 --> Config Class Initialized
INFO - 2021-12-13 01:56:13 --> Loader Class Initialized
INFO - 2021-12-13 01:56:13 --> Helper loaded: url_helper
INFO - 2021-12-13 01:56:13 --> Helper loaded: file_helper
INFO - 2021-12-13 01:56:13 --> Helper loaded: form_helper
INFO - 2021-12-13 01:56:13 --> Helper loaded: my_helper
INFO - 2021-12-13 01:56:13 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:56:13 --> Controller Class Initialized
DEBUG - 2021-12-13 01:56:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 01:56:13 --> Final output sent to browser
DEBUG - 2021-12-13 01:56:13 --> Total execution time: 0.0650
INFO - 2021-12-13 01:56:15 --> Config Class Initialized
INFO - 2021-12-13 01:56:15 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:56:15 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:56:15 --> Utf8 Class Initialized
INFO - 2021-12-13 01:56:15 --> URI Class Initialized
INFO - 2021-12-13 01:56:15 --> Router Class Initialized
INFO - 2021-12-13 01:56:15 --> Output Class Initialized
INFO - 2021-12-13 01:56:15 --> Security Class Initialized
DEBUG - 2021-12-13 01:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:56:15 --> Input Class Initialized
INFO - 2021-12-13 01:56:15 --> Language Class Initialized
INFO - 2021-12-13 01:56:15 --> Language Class Initialized
INFO - 2021-12-13 01:56:15 --> Config Class Initialized
INFO - 2021-12-13 01:56:15 --> Loader Class Initialized
INFO - 2021-12-13 01:56:15 --> Helper loaded: url_helper
INFO - 2021-12-13 01:56:15 --> Helper loaded: file_helper
INFO - 2021-12-13 01:56:15 --> Helper loaded: form_helper
INFO - 2021-12-13 01:56:15 --> Helper loaded: my_helper
INFO - 2021-12-13 01:56:15 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:56:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:56:15 --> Controller Class Initialized
DEBUG - 2021-12-13 01:56:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 01:56:16 --> Final output sent to browser
DEBUG - 2021-12-13 01:56:16 --> Total execution time: 0.0500
INFO - 2021-12-13 01:56:20 --> Config Class Initialized
INFO - 2021-12-13 01:56:20 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:56:20 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:56:20 --> Utf8 Class Initialized
INFO - 2021-12-13 01:56:20 --> URI Class Initialized
INFO - 2021-12-13 01:56:20 --> Router Class Initialized
INFO - 2021-12-13 01:56:20 --> Output Class Initialized
INFO - 2021-12-13 01:56:20 --> Security Class Initialized
DEBUG - 2021-12-13 01:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:56:20 --> Input Class Initialized
INFO - 2021-12-13 01:56:20 --> Language Class Initialized
INFO - 2021-12-13 01:56:20 --> Language Class Initialized
INFO - 2021-12-13 01:56:20 --> Config Class Initialized
INFO - 2021-12-13 01:56:20 --> Loader Class Initialized
INFO - 2021-12-13 01:56:20 --> Helper loaded: url_helper
INFO - 2021-12-13 01:56:20 --> Helper loaded: file_helper
INFO - 2021-12-13 01:56:20 --> Helper loaded: form_helper
INFO - 2021-12-13 01:56:20 --> Helper loaded: my_helper
INFO - 2021-12-13 01:56:20 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:56:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:56:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:56:20 --> Controller Class Initialized
DEBUG - 2021-12-13 01:56:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 01:56:20 --> Final output sent to browser
DEBUG - 2021-12-13 01:56:20 --> Total execution time: 0.0610
INFO - 2021-12-13 01:56:22 --> Config Class Initialized
INFO - 2021-12-13 01:56:22 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:56:22 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:56:22 --> Utf8 Class Initialized
INFO - 2021-12-13 01:56:22 --> URI Class Initialized
INFO - 2021-12-13 01:56:22 --> Router Class Initialized
INFO - 2021-12-13 01:56:22 --> Output Class Initialized
INFO - 2021-12-13 01:56:22 --> Security Class Initialized
DEBUG - 2021-12-13 01:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:56:22 --> Input Class Initialized
INFO - 2021-12-13 01:56:22 --> Language Class Initialized
INFO - 2021-12-13 01:56:22 --> Language Class Initialized
INFO - 2021-12-13 01:56:22 --> Config Class Initialized
INFO - 2021-12-13 01:56:22 --> Loader Class Initialized
INFO - 2021-12-13 01:56:22 --> Helper loaded: url_helper
INFO - 2021-12-13 01:56:22 --> Helper loaded: file_helper
INFO - 2021-12-13 01:56:22 --> Helper loaded: form_helper
INFO - 2021-12-13 01:56:22 --> Helper loaded: my_helper
INFO - 2021-12-13 01:56:22 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:56:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:56:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:56:22 --> Controller Class Initialized
DEBUG - 2021-12-13 01:56:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 01:56:22 --> Final output sent to browser
DEBUG - 2021-12-13 01:56:22 --> Total execution time: 0.0500
INFO - 2021-12-13 01:56:24 --> Config Class Initialized
INFO - 2021-12-13 01:56:24 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:56:24 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:56:24 --> Utf8 Class Initialized
INFO - 2021-12-13 01:56:24 --> URI Class Initialized
INFO - 2021-12-13 01:56:24 --> Router Class Initialized
INFO - 2021-12-13 01:56:24 --> Output Class Initialized
INFO - 2021-12-13 01:56:24 --> Security Class Initialized
DEBUG - 2021-12-13 01:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:56:24 --> Input Class Initialized
INFO - 2021-12-13 01:56:24 --> Language Class Initialized
INFO - 2021-12-13 01:56:24 --> Language Class Initialized
INFO - 2021-12-13 01:56:24 --> Config Class Initialized
INFO - 2021-12-13 01:56:24 --> Loader Class Initialized
INFO - 2021-12-13 01:56:24 --> Helper loaded: url_helper
INFO - 2021-12-13 01:56:24 --> Helper loaded: file_helper
INFO - 2021-12-13 01:56:24 --> Helper loaded: form_helper
INFO - 2021-12-13 01:56:24 --> Helper loaded: my_helper
INFO - 2021-12-13 01:56:24 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:56:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:56:24 --> Controller Class Initialized
DEBUG - 2021-12-13 01:56:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 01:56:24 --> Final output sent to browser
DEBUG - 2021-12-13 01:56:24 --> Total execution time: 0.0640
INFO - 2021-12-13 01:56:28 --> Config Class Initialized
INFO - 2021-12-13 01:56:28 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:56:28 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:56:28 --> Utf8 Class Initialized
INFO - 2021-12-13 01:56:28 --> URI Class Initialized
INFO - 2021-12-13 01:56:28 --> Router Class Initialized
INFO - 2021-12-13 01:56:28 --> Output Class Initialized
INFO - 2021-12-13 01:56:28 --> Security Class Initialized
DEBUG - 2021-12-13 01:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:56:28 --> Input Class Initialized
INFO - 2021-12-13 01:56:28 --> Language Class Initialized
INFO - 2021-12-13 01:56:28 --> Language Class Initialized
INFO - 2021-12-13 01:56:28 --> Config Class Initialized
INFO - 2021-12-13 01:56:28 --> Loader Class Initialized
INFO - 2021-12-13 01:56:28 --> Helper loaded: url_helper
INFO - 2021-12-13 01:56:28 --> Helper loaded: file_helper
INFO - 2021-12-13 01:56:28 --> Helper loaded: form_helper
INFO - 2021-12-13 01:56:28 --> Helper loaded: my_helper
INFO - 2021-12-13 01:56:28 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:56:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:56:28 --> Controller Class Initialized
DEBUG - 2021-12-13 01:56:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 01:56:28 --> Final output sent to browser
DEBUG - 2021-12-13 01:56:28 --> Total execution time: 0.0570
INFO - 2021-12-13 01:56:31 --> Config Class Initialized
INFO - 2021-12-13 01:56:31 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:56:31 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:56:31 --> Utf8 Class Initialized
INFO - 2021-12-13 01:56:31 --> URI Class Initialized
INFO - 2021-12-13 01:56:31 --> Router Class Initialized
INFO - 2021-12-13 01:56:31 --> Output Class Initialized
INFO - 2021-12-13 01:56:31 --> Security Class Initialized
DEBUG - 2021-12-13 01:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:56:31 --> Input Class Initialized
INFO - 2021-12-13 01:56:31 --> Language Class Initialized
INFO - 2021-12-13 01:56:31 --> Language Class Initialized
INFO - 2021-12-13 01:56:31 --> Config Class Initialized
INFO - 2021-12-13 01:56:31 --> Loader Class Initialized
INFO - 2021-12-13 01:56:31 --> Helper loaded: url_helper
INFO - 2021-12-13 01:56:31 --> Helper loaded: file_helper
INFO - 2021-12-13 01:56:31 --> Helper loaded: form_helper
INFO - 2021-12-13 01:56:31 --> Helper loaded: my_helper
INFO - 2021-12-13 01:56:31 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:56:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:56:31 --> Controller Class Initialized
DEBUG - 2021-12-13 01:56:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 01:56:31 --> Final output sent to browser
DEBUG - 2021-12-13 01:56:31 --> Total execution time: 0.0500
INFO - 2021-12-13 01:56:33 --> Config Class Initialized
INFO - 2021-12-13 01:56:33 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:56:33 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:56:33 --> Utf8 Class Initialized
INFO - 2021-12-13 01:56:33 --> URI Class Initialized
INFO - 2021-12-13 01:56:33 --> Router Class Initialized
INFO - 2021-12-13 01:56:33 --> Output Class Initialized
INFO - 2021-12-13 01:56:33 --> Security Class Initialized
DEBUG - 2021-12-13 01:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:56:33 --> Input Class Initialized
INFO - 2021-12-13 01:56:33 --> Language Class Initialized
INFO - 2021-12-13 01:56:33 --> Language Class Initialized
INFO - 2021-12-13 01:56:33 --> Config Class Initialized
INFO - 2021-12-13 01:56:33 --> Loader Class Initialized
INFO - 2021-12-13 01:56:33 --> Helper loaded: url_helper
INFO - 2021-12-13 01:56:33 --> Helper loaded: file_helper
INFO - 2021-12-13 01:56:33 --> Helper loaded: form_helper
INFO - 2021-12-13 01:56:33 --> Helper loaded: my_helper
INFO - 2021-12-13 01:56:33 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:56:33 --> Controller Class Initialized
DEBUG - 2021-12-13 01:56:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 01:56:33 --> Final output sent to browser
DEBUG - 2021-12-13 01:56:33 --> Total execution time: 0.0580
INFO - 2021-12-13 01:56:34 --> Config Class Initialized
INFO - 2021-12-13 01:56:34 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:56:34 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:56:34 --> Utf8 Class Initialized
INFO - 2021-12-13 01:56:34 --> URI Class Initialized
INFO - 2021-12-13 01:56:34 --> Router Class Initialized
INFO - 2021-12-13 01:56:34 --> Output Class Initialized
INFO - 2021-12-13 01:56:34 --> Security Class Initialized
DEBUG - 2021-12-13 01:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:56:34 --> Input Class Initialized
INFO - 2021-12-13 01:56:34 --> Language Class Initialized
INFO - 2021-12-13 01:56:34 --> Language Class Initialized
INFO - 2021-12-13 01:56:34 --> Config Class Initialized
INFO - 2021-12-13 01:56:34 --> Loader Class Initialized
INFO - 2021-12-13 01:56:34 --> Helper loaded: url_helper
INFO - 2021-12-13 01:56:34 --> Helper loaded: file_helper
INFO - 2021-12-13 01:56:34 --> Helper loaded: form_helper
INFO - 2021-12-13 01:56:34 --> Helper loaded: my_helper
INFO - 2021-12-13 01:56:34 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:56:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:56:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:56:34 --> Controller Class Initialized
DEBUG - 2021-12-13 01:56:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 01:56:34 --> Final output sent to browser
DEBUG - 2021-12-13 01:56:34 --> Total execution time: 0.0590
INFO - 2021-12-13 02:09:50 --> Config Class Initialized
INFO - 2021-12-13 02:09:50 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:09:50 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:09:50 --> Utf8 Class Initialized
INFO - 2021-12-13 02:09:50 --> URI Class Initialized
INFO - 2021-12-13 02:09:50 --> Router Class Initialized
INFO - 2021-12-13 02:09:50 --> Output Class Initialized
INFO - 2021-12-13 02:09:50 --> Security Class Initialized
DEBUG - 2021-12-13 02:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:09:50 --> Input Class Initialized
INFO - 2021-12-13 02:09:50 --> Language Class Initialized
INFO - 2021-12-13 02:09:50 --> Language Class Initialized
INFO - 2021-12-13 02:09:50 --> Config Class Initialized
INFO - 2021-12-13 02:09:50 --> Loader Class Initialized
INFO - 2021-12-13 02:09:50 --> Helper loaded: url_helper
INFO - 2021-12-13 02:09:50 --> Helper loaded: file_helper
INFO - 2021-12-13 02:09:50 --> Helper loaded: form_helper
INFO - 2021-12-13 02:09:50 --> Helper loaded: my_helper
INFO - 2021-12-13 02:09:50 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:09:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:09:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:09:50 --> Controller Class Initialized
INFO - 2021-12-13 02:09:50 --> Helper loaded: cookie_helper
INFO - 2021-12-13 02:09:50 --> Config Class Initialized
INFO - 2021-12-13 02:09:50 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:09:50 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:09:50 --> Utf8 Class Initialized
INFO - 2021-12-13 02:09:50 --> URI Class Initialized
INFO - 2021-12-13 02:09:50 --> Router Class Initialized
INFO - 2021-12-13 02:09:50 --> Output Class Initialized
INFO - 2021-12-13 02:09:50 --> Security Class Initialized
DEBUG - 2021-12-13 02:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:09:50 --> Input Class Initialized
INFO - 2021-12-13 02:09:50 --> Language Class Initialized
INFO - 2021-12-13 02:09:50 --> Language Class Initialized
INFO - 2021-12-13 02:09:50 --> Config Class Initialized
INFO - 2021-12-13 02:09:50 --> Loader Class Initialized
INFO - 2021-12-13 02:09:50 --> Helper loaded: url_helper
INFO - 2021-12-13 02:09:50 --> Helper loaded: file_helper
INFO - 2021-12-13 02:09:50 --> Helper loaded: form_helper
INFO - 2021-12-13 02:09:50 --> Helper loaded: my_helper
INFO - 2021-12-13 02:09:50 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:09:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:09:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:09:50 --> Controller Class Initialized
DEBUG - 2021-12-13 02:09:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-13 02:09:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 02:09:50 --> Final output sent to browser
DEBUG - 2021-12-13 02:09:50 --> Total execution time: 0.0350
INFO - 2021-12-13 02:09:58 --> Config Class Initialized
INFO - 2021-12-13 02:09:58 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:09:58 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:09:58 --> Utf8 Class Initialized
INFO - 2021-12-13 02:09:58 --> URI Class Initialized
INFO - 2021-12-13 02:09:58 --> Router Class Initialized
INFO - 2021-12-13 02:09:58 --> Output Class Initialized
INFO - 2021-12-13 02:09:58 --> Security Class Initialized
DEBUG - 2021-12-13 02:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:09:58 --> Input Class Initialized
INFO - 2021-12-13 02:09:58 --> Language Class Initialized
INFO - 2021-12-13 02:09:58 --> Language Class Initialized
INFO - 2021-12-13 02:09:58 --> Config Class Initialized
INFO - 2021-12-13 02:09:58 --> Loader Class Initialized
INFO - 2021-12-13 02:09:58 --> Helper loaded: url_helper
INFO - 2021-12-13 02:09:58 --> Helper loaded: file_helper
INFO - 2021-12-13 02:09:58 --> Helper loaded: form_helper
INFO - 2021-12-13 02:09:58 --> Helper loaded: my_helper
INFO - 2021-12-13 02:09:58 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:09:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:09:58 --> Controller Class Initialized
INFO - 2021-12-13 02:09:58 --> Helper loaded: cookie_helper
INFO - 2021-12-13 02:09:58 --> Final output sent to browser
DEBUG - 2021-12-13 02:09:58 --> Total execution time: 0.0540
INFO - 2021-12-13 02:09:58 --> Config Class Initialized
INFO - 2021-12-13 02:09:58 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:09:58 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:09:58 --> Utf8 Class Initialized
INFO - 2021-12-13 02:09:58 --> URI Class Initialized
INFO - 2021-12-13 02:09:58 --> Router Class Initialized
INFO - 2021-12-13 02:09:58 --> Output Class Initialized
INFO - 2021-12-13 02:09:58 --> Security Class Initialized
DEBUG - 2021-12-13 02:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:09:58 --> Input Class Initialized
INFO - 2021-12-13 02:09:58 --> Language Class Initialized
INFO - 2021-12-13 02:09:58 --> Language Class Initialized
INFO - 2021-12-13 02:09:58 --> Config Class Initialized
INFO - 2021-12-13 02:09:58 --> Loader Class Initialized
INFO - 2021-12-13 02:09:58 --> Helper loaded: url_helper
INFO - 2021-12-13 02:09:58 --> Helper loaded: file_helper
INFO - 2021-12-13 02:09:58 --> Helper loaded: form_helper
INFO - 2021-12-13 02:09:58 --> Helper loaded: my_helper
INFO - 2021-12-13 02:09:58 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:09:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:09:58 --> Controller Class Initialized
DEBUG - 2021-12-13 02:09:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-13 02:09:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 02:09:58 --> Final output sent to browser
DEBUG - 2021-12-13 02:09:58 --> Total execution time: 0.2330
INFO - 2021-12-13 02:10:00 --> Config Class Initialized
INFO - 2021-12-13 02:10:00 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:10:01 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:10:01 --> Utf8 Class Initialized
INFO - 2021-12-13 02:10:01 --> URI Class Initialized
INFO - 2021-12-13 02:10:01 --> Router Class Initialized
INFO - 2021-12-13 02:10:01 --> Output Class Initialized
INFO - 2021-12-13 02:10:01 --> Security Class Initialized
DEBUG - 2021-12-13 02:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:10:01 --> Input Class Initialized
INFO - 2021-12-13 02:10:01 --> Language Class Initialized
INFO - 2021-12-13 02:10:01 --> Language Class Initialized
INFO - 2021-12-13 02:10:01 --> Config Class Initialized
INFO - 2021-12-13 02:10:01 --> Loader Class Initialized
INFO - 2021-12-13 02:10:01 --> Helper loaded: url_helper
INFO - 2021-12-13 02:10:01 --> Helper loaded: file_helper
INFO - 2021-12-13 02:10:01 --> Helper loaded: form_helper
INFO - 2021-12-13 02:10:01 --> Helper loaded: my_helper
INFO - 2021-12-13 02:10:01 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:10:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:10:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:10:01 --> Controller Class Initialized
DEBUG - 2021-12-13 02:10:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-13 02:10:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 02:10:01 --> Final output sent to browser
DEBUG - 2021-12-13 02:10:01 --> Total execution time: 0.0630
INFO - 2021-12-13 02:10:21 --> Config Class Initialized
INFO - 2021-12-13 02:10:21 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:10:21 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:10:21 --> Utf8 Class Initialized
INFO - 2021-12-13 02:10:21 --> URI Class Initialized
INFO - 2021-12-13 02:10:21 --> Router Class Initialized
INFO - 2021-12-13 02:10:21 --> Output Class Initialized
INFO - 2021-12-13 02:10:21 --> Security Class Initialized
DEBUG - 2021-12-13 02:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:10:21 --> Input Class Initialized
INFO - 2021-12-13 02:10:21 --> Language Class Initialized
INFO - 2021-12-13 02:10:21 --> Language Class Initialized
INFO - 2021-12-13 02:10:21 --> Config Class Initialized
INFO - 2021-12-13 02:10:21 --> Loader Class Initialized
INFO - 2021-12-13 02:10:21 --> Helper loaded: url_helper
INFO - 2021-12-13 02:10:21 --> Helper loaded: file_helper
INFO - 2021-12-13 02:10:21 --> Helper loaded: form_helper
INFO - 2021-12-13 02:10:21 --> Helper loaded: my_helper
INFO - 2021-12-13 02:10:21 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:10:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:10:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:10:21 --> Controller Class Initialized
DEBUG - 2021-12-13 02:10:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 02:10:21 --> Final output sent to browser
DEBUG - 2021-12-13 02:10:21 --> Total execution time: 0.0980
INFO - 2021-12-13 02:10:24 --> Config Class Initialized
INFO - 2021-12-13 02:10:24 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:10:24 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:10:24 --> Utf8 Class Initialized
INFO - 2021-12-13 02:10:24 --> URI Class Initialized
INFO - 2021-12-13 02:10:24 --> Router Class Initialized
INFO - 2021-12-13 02:10:24 --> Output Class Initialized
INFO - 2021-12-13 02:10:24 --> Security Class Initialized
DEBUG - 2021-12-13 02:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:10:24 --> Input Class Initialized
INFO - 2021-12-13 02:10:24 --> Language Class Initialized
INFO - 2021-12-13 02:10:24 --> Language Class Initialized
INFO - 2021-12-13 02:10:24 --> Config Class Initialized
INFO - 2021-12-13 02:10:24 --> Loader Class Initialized
INFO - 2021-12-13 02:10:24 --> Helper loaded: url_helper
INFO - 2021-12-13 02:10:24 --> Helper loaded: file_helper
INFO - 2021-12-13 02:10:24 --> Helper loaded: form_helper
INFO - 2021-12-13 02:10:24 --> Helper loaded: my_helper
INFO - 2021-12-13 02:10:24 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:10:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:10:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:10:24 --> Controller Class Initialized
DEBUG - 2021-12-13 02:10:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 02:10:24 --> Final output sent to browser
DEBUG - 2021-12-13 02:10:24 --> Total execution time: 0.0600
INFO - 2021-12-13 02:10:26 --> Config Class Initialized
INFO - 2021-12-13 02:10:26 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:10:26 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:10:26 --> Utf8 Class Initialized
INFO - 2021-12-13 02:10:26 --> URI Class Initialized
INFO - 2021-12-13 02:10:26 --> Router Class Initialized
INFO - 2021-12-13 02:10:26 --> Output Class Initialized
INFO - 2021-12-13 02:10:26 --> Security Class Initialized
DEBUG - 2021-12-13 02:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:10:26 --> Input Class Initialized
INFO - 2021-12-13 02:10:26 --> Language Class Initialized
INFO - 2021-12-13 02:10:26 --> Language Class Initialized
INFO - 2021-12-13 02:10:26 --> Config Class Initialized
INFO - 2021-12-13 02:10:26 --> Loader Class Initialized
INFO - 2021-12-13 02:10:26 --> Helper loaded: url_helper
INFO - 2021-12-13 02:10:26 --> Helper loaded: file_helper
INFO - 2021-12-13 02:10:26 --> Helper loaded: form_helper
INFO - 2021-12-13 02:10:26 --> Helper loaded: my_helper
INFO - 2021-12-13 02:10:26 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:10:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:10:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:10:26 --> Controller Class Initialized
DEBUG - 2021-12-13 02:10:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 02:10:26 --> Final output sent to browser
DEBUG - 2021-12-13 02:10:26 --> Total execution time: 0.0620
INFO - 2021-12-13 02:10:29 --> Config Class Initialized
INFO - 2021-12-13 02:10:29 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:10:29 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:10:29 --> Utf8 Class Initialized
INFO - 2021-12-13 02:10:29 --> URI Class Initialized
INFO - 2021-12-13 02:10:29 --> Router Class Initialized
INFO - 2021-12-13 02:10:29 --> Output Class Initialized
INFO - 2021-12-13 02:10:29 --> Security Class Initialized
DEBUG - 2021-12-13 02:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:10:29 --> Input Class Initialized
INFO - 2021-12-13 02:10:29 --> Language Class Initialized
INFO - 2021-12-13 02:10:29 --> Language Class Initialized
INFO - 2021-12-13 02:10:29 --> Config Class Initialized
INFO - 2021-12-13 02:10:29 --> Loader Class Initialized
INFO - 2021-12-13 02:10:29 --> Helper loaded: url_helper
INFO - 2021-12-13 02:10:29 --> Helper loaded: file_helper
INFO - 2021-12-13 02:10:29 --> Helper loaded: form_helper
INFO - 2021-12-13 02:10:29 --> Helper loaded: my_helper
INFO - 2021-12-13 02:10:29 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:10:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:10:29 --> Controller Class Initialized
DEBUG - 2021-12-13 02:10:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 02:10:29 --> Final output sent to browser
DEBUG - 2021-12-13 02:10:29 --> Total execution time: 0.0550
INFO - 2021-12-13 02:10:31 --> Config Class Initialized
INFO - 2021-12-13 02:10:31 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:10:31 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:10:31 --> Utf8 Class Initialized
INFO - 2021-12-13 02:10:31 --> URI Class Initialized
INFO - 2021-12-13 02:10:31 --> Router Class Initialized
INFO - 2021-12-13 02:10:31 --> Output Class Initialized
INFO - 2021-12-13 02:10:31 --> Security Class Initialized
DEBUG - 2021-12-13 02:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:10:31 --> Input Class Initialized
INFO - 2021-12-13 02:10:31 --> Language Class Initialized
INFO - 2021-12-13 02:10:31 --> Language Class Initialized
INFO - 2021-12-13 02:10:31 --> Config Class Initialized
INFO - 2021-12-13 02:10:31 --> Loader Class Initialized
INFO - 2021-12-13 02:10:31 --> Helper loaded: url_helper
INFO - 2021-12-13 02:10:31 --> Helper loaded: file_helper
INFO - 2021-12-13 02:10:31 --> Helper loaded: form_helper
INFO - 2021-12-13 02:10:31 --> Helper loaded: my_helper
INFO - 2021-12-13 02:10:31 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:10:31 --> Controller Class Initialized
DEBUG - 2021-12-13 02:10:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 02:10:31 --> Final output sent to browser
DEBUG - 2021-12-13 02:10:31 --> Total execution time: 0.0490
INFO - 2021-12-13 02:10:33 --> Config Class Initialized
INFO - 2021-12-13 02:10:33 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:10:33 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:10:33 --> Utf8 Class Initialized
INFO - 2021-12-13 02:10:33 --> URI Class Initialized
INFO - 2021-12-13 02:10:33 --> Router Class Initialized
INFO - 2021-12-13 02:10:33 --> Output Class Initialized
INFO - 2021-12-13 02:10:33 --> Security Class Initialized
DEBUG - 2021-12-13 02:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:10:33 --> Input Class Initialized
INFO - 2021-12-13 02:10:33 --> Language Class Initialized
INFO - 2021-12-13 02:10:33 --> Language Class Initialized
INFO - 2021-12-13 02:10:33 --> Config Class Initialized
INFO - 2021-12-13 02:10:33 --> Loader Class Initialized
INFO - 2021-12-13 02:10:33 --> Helper loaded: url_helper
INFO - 2021-12-13 02:10:33 --> Helper loaded: file_helper
INFO - 2021-12-13 02:10:33 --> Helper loaded: form_helper
INFO - 2021-12-13 02:10:33 --> Helper loaded: my_helper
INFO - 2021-12-13 02:10:33 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:10:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:10:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:10:33 --> Controller Class Initialized
DEBUG - 2021-12-13 02:10:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 02:10:33 --> Final output sent to browser
DEBUG - 2021-12-13 02:10:33 --> Total execution time: 0.0600
INFO - 2021-12-13 02:10:35 --> Config Class Initialized
INFO - 2021-12-13 02:10:35 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:10:35 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:10:35 --> Utf8 Class Initialized
INFO - 2021-12-13 02:10:35 --> URI Class Initialized
INFO - 2021-12-13 02:10:35 --> Router Class Initialized
INFO - 2021-12-13 02:10:35 --> Output Class Initialized
INFO - 2021-12-13 02:10:35 --> Security Class Initialized
DEBUG - 2021-12-13 02:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:10:35 --> Input Class Initialized
INFO - 2021-12-13 02:10:35 --> Language Class Initialized
INFO - 2021-12-13 02:10:35 --> Language Class Initialized
INFO - 2021-12-13 02:10:35 --> Config Class Initialized
INFO - 2021-12-13 02:10:35 --> Loader Class Initialized
INFO - 2021-12-13 02:10:35 --> Helper loaded: url_helper
INFO - 2021-12-13 02:10:35 --> Helper loaded: file_helper
INFO - 2021-12-13 02:10:35 --> Helper loaded: form_helper
INFO - 2021-12-13 02:10:35 --> Helper loaded: my_helper
INFO - 2021-12-13 02:10:35 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:10:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:10:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:10:35 --> Controller Class Initialized
DEBUG - 2021-12-13 02:10:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 02:10:35 --> Final output sent to browser
DEBUG - 2021-12-13 02:10:35 --> Total execution time: 0.0620
INFO - 2021-12-13 02:10:37 --> Config Class Initialized
INFO - 2021-12-13 02:10:37 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:10:37 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:10:37 --> Utf8 Class Initialized
INFO - 2021-12-13 02:10:37 --> URI Class Initialized
INFO - 2021-12-13 02:10:37 --> Router Class Initialized
INFO - 2021-12-13 02:10:37 --> Output Class Initialized
INFO - 2021-12-13 02:10:37 --> Security Class Initialized
DEBUG - 2021-12-13 02:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:10:37 --> Input Class Initialized
INFO - 2021-12-13 02:10:37 --> Language Class Initialized
INFO - 2021-12-13 02:10:37 --> Language Class Initialized
INFO - 2021-12-13 02:10:37 --> Config Class Initialized
INFO - 2021-12-13 02:10:37 --> Loader Class Initialized
INFO - 2021-12-13 02:10:37 --> Helper loaded: url_helper
INFO - 2021-12-13 02:10:37 --> Helper loaded: file_helper
INFO - 2021-12-13 02:10:37 --> Helper loaded: form_helper
INFO - 2021-12-13 02:10:37 --> Helper loaded: my_helper
INFO - 2021-12-13 02:10:37 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:10:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:10:37 --> Controller Class Initialized
DEBUG - 2021-12-13 02:10:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 02:10:37 --> Final output sent to browser
DEBUG - 2021-12-13 02:10:37 --> Total execution time: 0.0580
INFO - 2021-12-13 02:10:39 --> Config Class Initialized
INFO - 2021-12-13 02:10:39 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:10:39 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:10:39 --> Utf8 Class Initialized
INFO - 2021-12-13 02:10:39 --> URI Class Initialized
INFO - 2021-12-13 02:10:39 --> Router Class Initialized
INFO - 2021-12-13 02:10:39 --> Output Class Initialized
INFO - 2021-12-13 02:10:39 --> Security Class Initialized
DEBUG - 2021-12-13 02:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:10:39 --> Input Class Initialized
INFO - 2021-12-13 02:10:39 --> Language Class Initialized
INFO - 2021-12-13 02:10:39 --> Language Class Initialized
INFO - 2021-12-13 02:10:39 --> Config Class Initialized
INFO - 2021-12-13 02:10:39 --> Loader Class Initialized
INFO - 2021-12-13 02:10:39 --> Helper loaded: url_helper
INFO - 2021-12-13 02:10:39 --> Helper loaded: file_helper
INFO - 2021-12-13 02:10:39 --> Helper loaded: form_helper
INFO - 2021-12-13 02:10:39 --> Helper loaded: my_helper
INFO - 2021-12-13 02:10:39 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:10:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:10:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:10:39 --> Controller Class Initialized
DEBUG - 2021-12-13 02:10:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 02:10:39 --> Final output sent to browser
DEBUG - 2021-12-13 02:10:39 --> Total execution time: 0.0650
INFO - 2021-12-13 02:10:41 --> Config Class Initialized
INFO - 2021-12-13 02:10:41 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:10:41 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:10:41 --> Utf8 Class Initialized
INFO - 2021-12-13 02:10:41 --> URI Class Initialized
INFO - 2021-12-13 02:10:41 --> Router Class Initialized
INFO - 2021-12-13 02:10:41 --> Output Class Initialized
INFO - 2021-12-13 02:10:41 --> Security Class Initialized
DEBUG - 2021-12-13 02:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:10:41 --> Input Class Initialized
INFO - 2021-12-13 02:10:41 --> Language Class Initialized
INFO - 2021-12-13 02:10:41 --> Language Class Initialized
INFO - 2021-12-13 02:10:41 --> Config Class Initialized
INFO - 2021-12-13 02:10:41 --> Loader Class Initialized
INFO - 2021-12-13 02:10:41 --> Helper loaded: url_helper
INFO - 2021-12-13 02:10:41 --> Helper loaded: file_helper
INFO - 2021-12-13 02:10:41 --> Helper loaded: form_helper
INFO - 2021-12-13 02:10:41 --> Helper loaded: my_helper
INFO - 2021-12-13 02:10:41 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:10:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:10:41 --> Controller Class Initialized
DEBUG - 2021-12-13 02:10:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 02:10:41 --> Final output sent to browser
DEBUG - 2021-12-13 02:10:41 --> Total execution time: 0.0610
INFO - 2021-12-13 02:10:43 --> Config Class Initialized
INFO - 2021-12-13 02:10:43 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:10:43 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:10:43 --> Utf8 Class Initialized
INFO - 2021-12-13 02:10:43 --> URI Class Initialized
INFO - 2021-12-13 02:10:43 --> Router Class Initialized
INFO - 2021-12-13 02:10:43 --> Output Class Initialized
INFO - 2021-12-13 02:10:43 --> Security Class Initialized
DEBUG - 2021-12-13 02:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:10:43 --> Input Class Initialized
INFO - 2021-12-13 02:10:43 --> Language Class Initialized
INFO - 2021-12-13 02:10:43 --> Language Class Initialized
INFO - 2021-12-13 02:10:43 --> Config Class Initialized
INFO - 2021-12-13 02:10:43 --> Loader Class Initialized
INFO - 2021-12-13 02:10:43 --> Helper loaded: url_helper
INFO - 2021-12-13 02:10:43 --> Helper loaded: file_helper
INFO - 2021-12-13 02:10:43 --> Helper loaded: form_helper
INFO - 2021-12-13 02:10:43 --> Helper loaded: my_helper
INFO - 2021-12-13 02:10:43 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:10:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:10:43 --> Controller Class Initialized
DEBUG - 2021-12-13 02:10:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 02:10:43 --> Final output sent to browser
DEBUG - 2021-12-13 02:10:43 --> Total execution time: 0.0570
INFO - 2021-12-13 02:10:45 --> Config Class Initialized
INFO - 2021-12-13 02:10:45 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:10:45 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:10:45 --> Utf8 Class Initialized
INFO - 2021-12-13 02:10:45 --> URI Class Initialized
INFO - 2021-12-13 02:10:45 --> Router Class Initialized
INFO - 2021-12-13 02:10:45 --> Output Class Initialized
INFO - 2021-12-13 02:10:45 --> Security Class Initialized
DEBUG - 2021-12-13 02:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:10:45 --> Input Class Initialized
INFO - 2021-12-13 02:10:45 --> Language Class Initialized
INFO - 2021-12-13 02:10:45 --> Language Class Initialized
INFO - 2021-12-13 02:10:45 --> Config Class Initialized
INFO - 2021-12-13 02:10:45 --> Loader Class Initialized
INFO - 2021-12-13 02:10:45 --> Helper loaded: url_helper
INFO - 2021-12-13 02:10:45 --> Helper loaded: file_helper
INFO - 2021-12-13 02:10:45 --> Helper loaded: form_helper
INFO - 2021-12-13 02:10:45 --> Helper loaded: my_helper
INFO - 2021-12-13 02:10:45 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:10:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:10:45 --> Controller Class Initialized
DEBUG - 2021-12-13 02:10:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 02:10:45 --> Final output sent to browser
DEBUG - 2021-12-13 02:10:45 --> Total execution time: 0.0540
INFO - 2021-12-13 02:10:48 --> Config Class Initialized
INFO - 2021-12-13 02:10:48 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:10:48 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:10:48 --> Utf8 Class Initialized
INFO - 2021-12-13 02:10:48 --> URI Class Initialized
INFO - 2021-12-13 02:10:48 --> Router Class Initialized
INFO - 2021-12-13 02:10:48 --> Output Class Initialized
INFO - 2021-12-13 02:10:48 --> Security Class Initialized
DEBUG - 2021-12-13 02:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:10:48 --> Input Class Initialized
INFO - 2021-12-13 02:10:48 --> Language Class Initialized
INFO - 2021-12-13 02:10:48 --> Language Class Initialized
INFO - 2021-12-13 02:10:48 --> Config Class Initialized
INFO - 2021-12-13 02:10:48 --> Loader Class Initialized
INFO - 2021-12-13 02:10:48 --> Helper loaded: url_helper
INFO - 2021-12-13 02:10:48 --> Helper loaded: file_helper
INFO - 2021-12-13 02:10:48 --> Helper loaded: form_helper
INFO - 2021-12-13 02:10:48 --> Helper loaded: my_helper
INFO - 2021-12-13 02:10:48 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:10:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:10:48 --> Controller Class Initialized
DEBUG - 2021-12-13 02:10:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 02:10:48 --> Final output sent to browser
DEBUG - 2021-12-13 02:10:48 --> Total execution time: 0.0630
INFO - 2021-12-13 02:10:49 --> Config Class Initialized
INFO - 2021-12-13 02:10:49 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:10:49 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:10:49 --> Utf8 Class Initialized
INFO - 2021-12-13 02:10:49 --> URI Class Initialized
INFO - 2021-12-13 02:10:49 --> Router Class Initialized
INFO - 2021-12-13 02:10:49 --> Output Class Initialized
INFO - 2021-12-13 02:10:49 --> Security Class Initialized
DEBUG - 2021-12-13 02:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:10:49 --> Input Class Initialized
INFO - 2021-12-13 02:10:49 --> Language Class Initialized
INFO - 2021-12-13 02:10:49 --> Language Class Initialized
INFO - 2021-12-13 02:10:49 --> Config Class Initialized
INFO - 2021-12-13 02:10:49 --> Loader Class Initialized
INFO - 2021-12-13 02:10:49 --> Helper loaded: url_helper
INFO - 2021-12-13 02:10:49 --> Helper loaded: file_helper
INFO - 2021-12-13 02:10:49 --> Helper loaded: form_helper
INFO - 2021-12-13 02:10:49 --> Helper loaded: my_helper
INFO - 2021-12-13 02:10:49 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:10:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:10:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:10:49 --> Controller Class Initialized
DEBUG - 2021-12-13 02:10:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 02:10:49 --> Final output sent to browser
DEBUG - 2021-12-13 02:10:49 --> Total execution time: 0.0670
INFO - 2021-12-13 02:10:52 --> Config Class Initialized
INFO - 2021-12-13 02:10:52 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:10:52 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:10:52 --> Utf8 Class Initialized
INFO - 2021-12-13 02:10:52 --> URI Class Initialized
INFO - 2021-12-13 02:10:52 --> Router Class Initialized
INFO - 2021-12-13 02:10:52 --> Output Class Initialized
INFO - 2021-12-13 02:10:52 --> Security Class Initialized
DEBUG - 2021-12-13 02:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:10:52 --> Input Class Initialized
INFO - 2021-12-13 02:10:52 --> Language Class Initialized
INFO - 2021-12-13 02:10:52 --> Language Class Initialized
INFO - 2021-12-13 02:10:52 --> Config Class Initialized
INFO - 2021-12-13 02:10:52 --> Loader Class Initialized
INFO - 2021-12-13 02:10:52 --> Helper loaded: url_helper
INFO - 2021-12-13 02:10:52 --> Helper loaded: file_helper
INFO - 2021-12-13 02:10:52 --> Helper loaded: form_helper
INFO - 2021-12-13 02:10:52 --> Helper loaded: my_helper
INFO - 2021-12-13 02:10:52 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:10:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:10:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:10:52 --> Controller Class Initialized
DEBUG - 2021-12-13 02:10:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 02:10:52 --> Final output sent to browser
DEBUG - 2021-12-13 02:10:52 --> Total execution time: 0.0700
INFO - 2021-12-13 02:10:54 --> Config Class Initialized
INFO - 2021-12-13 02:10:54 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:10:54 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:10:54 --> Utf8 Class Initialized
INFO - 2021-12-13 02:10:54 --> URI Class Initialized
INFO - 2021-12-13 02:10:54 --> Router Class Initialized
INFO - 2021-12-13 02:10:54 --> Output Class Initialized
INFO - 2021-12-13 02:10:54 --> Security Class Initialized
DEBUG - 2021-12-13 02:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:10:54 --> Input Class Initialized
INFO - 2021-12-13 02:10:54 --> Language Class Initialized
INFO - 2021-12-13 02:10:54 --> Language Class Initialized
INFO - 2021-12-13 02:10:54 --> Config Class Initialized
INFO - 2021-12-13 02:10:54 --> Loader Class Initialized
INFO - 2021-12-13 02:10:54 --> Helper loaded: url_helper
INFO - 2021-12-13 02:10:54 --> Helper loaded: file_helper
INFO - 2021-12-13 02:10:54 --> Helper loaded: form_helper
INFO - 2021-12-13 02:10:54 --> Helper loaded: my_helper
INFO - 2021-12-13 02:10:54 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:10:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:10:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:10:54 --> Controller Class Initialized
DEBUG - 2021-12-13 02:10:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 02:10:54 --> Final output sent to browser
DEBUG - 2021-12-13 02:10:54 --> Total execution time: 0.0520
INFO - 2021-12-13 02:10:57 --> Config Class Initialized
INFO - 2021-12-13 02:10:57 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:10:57 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:10:57 --> Utf8 Class Initialized
INFO - 2021-12-13 02:10:57 --> URI Class Initialized
INFO - 2021-12-13 02:10:57 --> Router Class Initialized
INFO - 2021-12-13 02:10:57 --> Output Class Initialized
INFO - 2021-12-13 02:10:57 --> Security Class Initialized
DEBUG - 2021-12-13 02:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:10:57 --> Input Class Initialized
INFO - 2021-12-13 02:10:57 --> Language Class Initialized
INFO - 2021-12-13 02:10:57 --> Language Class Initialized
INFO - 2021-12-13 02:10:57 --> Config Class Initialized
INFO - 2021-12-13 02:10:57 --> Loader Class Initialized
INFO - 2021-12-13 02:10:57 --> Helper loaded: url_helper
INFO - 2021-12-13 02:10:57 --> Helper loaded: file_helper
INFO - 2021-12-13 02:10:57 --> Helper loaded: form_helper
INFO - 2021-12-13 02:10:57 --> Helper loaded: my_helper
INFO - 2021-12-13 02:10:57 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:10:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:10:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:10:57 --> Controller Class Initialized
DEBUG - 2021-12-13 02:10:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 02:10:57 --> Final output sent to browser
DEBUG - 2021-12-13 02:10:57 --> Total execution time: 0.0690
INFO - 2021-12-13 02:10:58 --> Config Class Initialized
INFO - 2021-12-13 02:10:58 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:10:58 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:10:58 --> Utf8 Class Initialized
INFO - 2021-12-13 02:10:58 --> URI Class Initialized
INFO - 2021-12-13 02:10:58 --> Router Class Initialized
INFO - 2021-12-13 02:10:58 --> Output Class Initialized
INFO - 2021-12-13 02:10:58 --> Security Class Initialized
DEBUG - 2021-12-13 02:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:10:58 --> Input Class Initialized
INFO - 2021-12-13 02:10:58 --> Language Class Initialized
INFO - 2021-12-13 02:10:58 --> Language Class Initialized
INFO - 2021-12-13 02:10:58 --> Config Class Initialized
INFO - 2021-12-13 02:10:58 --> Loader Class Initialized
INFO - 2021-12-13 02:10:58 --> Helper loaded: url_helper
INFO - 2021-12-13 02:10:58 --> Helper loaded: file_helper
INFO - 2021-12-13 02:10:58 --> Helper loaded: form_helper
INFO - 2021-12-13 02:10:58 --> Helper loaded: my_helper
INFO - 2021-12-13 02:10:58 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:10:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:10:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:10:58 --> Controller Class Initialized
DEBUG - 2021-12-13 02:10:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 02:10:58 --> Final output sent to browser
DEBUG - 2021-12-13 02:10:58 --> Total execution time: 0.0650
INFO - 2021-12-13 02:11:00 --> Config Class Initialized
INFO - 2021-12-13 02:11:00 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:11:00 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:11:00 --> Utf8 Class Initialized
INFO - 2021-12-13 02:11:00 --> URI Class Initialized
INFO - 2021-12-13 02:11:00 --> Router Class Initialized
INFO - 2021-12-13 02:11:00 --> Output Class Initialized
INFO - 2021-12-13 02:11:00 --> Security Class Initialized
DEBUG - 2021-12-13 02:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:11:00 --> Input Class Initialized
INFO - 2021-12-13 02:11:00 --> Language Class Initialized
INFO - 2021-12-13 02:11:00 --> Language Class Initialized
INFO - 2021-12-13 02:11:00 --> Config Class Initialized
INFO - 2021-12-13 02:11:00 --> Loader Class Initialized
INFO - 2021-12-13 02:11:00 --> Helper loaded: url_helper
INFO - 2021-12-13 02:11:00 --> Helper loaded: file_helper
INFO - 2021-12-13 02:11:00 --> Helper loaded: form_helper
INFO - 2021-12-13 02:11:00 --> Helper loaded: my_helper
INFO - 2021-12-13 02:11:00 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:11:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:11:00 --> Controller Class Initialized
DEBUG - 2021-12-13 02:11:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 02:11:00 --> Final output sent to browser
DEBUG - 2021-12-13 02:11:00 --> Total execution time: 0.0630
INFO - 2021-12-13 02:11:04 --> Config Class Initialized
INFO - 2021-12-13 02:11:04 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:11:04 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:11:04 --> Utf8 Class Initialized
INFO - 2021-12-13 02:11:04 --> URI Class Initialized
INFO - 2021-12-13 02:11:04 --> Router Class Initialized
INFO - 2021-12-13 02:11:04 --> Output Class Initialized
INFO - 2021-12-13 02:11:04 --> Security Class Initialized
DEBUG - 2021-12-13 02:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:11:04 --> Input Class Initialized
INFO - 2021-12-13 02:11:04 --> Language Class Initialized
INFO - 2021-12-13 02:11:04 --> Language Class Initialized
INFO - 2021-12-13 02:11:04 --> Config Class Initialized
INFO - 2021-12-13 02:11:04 --> Loader Class Initialized
INFO - 2021-12-13 02:11:04 --> Helper loaded: url_helper
INFO - 2021-12-13 02:11:04 --> Helper loaded: file_helper
INFO - 2021-12-13 02:11:04 --> Helper loaded: form_helper
INFO - 2021-12-13 02:11:04 --> Helper loaded: my_helper
INFO - 2021-12-13 02:11:04 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:11:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:11:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:11:04 --> Controller Class Initialized
DEBUG - 2021-12-13 02:11:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 02:11:04 --> Final output sent to browser
DEBUG - 2021-12-13 02:11:04 --> Total execution time: 0.0700
INFO - 2021-12-13 02:11:05 --> Config Class Initialized
INFO - 2021-12-13 02:11:05 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:11:05 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:11:05 --> Utf8 Class Initialized
INFO - 2021-12-13 02:11:05 --> URI Class Initialized
INFO - 2021-12-13 02:11:05 --> Router Class Initialized
INFO - 2021-12-13 02:11:05 --> Output Class Initialized
INFO - 2021-12-13 02:11:05 --> Security Class Initialized
DEBUG - 2021-12-13 02:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:11:05 --> Input Class Initialized
INFO - 2021-12-13 02:11:05 --> Language Class Initialized
INFO - 2021-12-13 02:11:05 --> Language Class Initialized
INFO - 2021-12-13 02:11:05 --> Config Class Initialized
INFO - 2021-12-13 02:11:05 --> Loader Class Initialized
INFO - 2021-12-13 02:11:05 --> Helper loaded: url_helper
INFO - 2021-12-13 02:11:05 --> Helper loaded: file_helper
INFO - 2021-12-13 02:11:05 --> Helper loaded: form_helper
INFO - 2021-12-13 02:11:05 --> Helper loaded: my_helper
INFO - 2021-12-13 02:11:05 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:11:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:11:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:11:05 --> Controller Class Initialized
DEBUG - 2021-12-13 02:11:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 02:11:05 --> Final output sent to browser
DEBUG - 2021-12-13 02:11:05 --> Total execution time: 0.0490
INFO - 2021-12-13 02:11:08 --> Config Class Initialized
INFO - 2021-12-13 02:11:08 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:11:08 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:11:08 --> Utf8 Class Initialized
INFO - 2021-12-13 02:11:08 --> URI Class Initialized
INFO - 2021-12-13 02:11:08 --> Router Class Initialized
INFO - 2021-12-13 02:11:08 --> Output Class Initialized
INFO - 2021-12-13 02:11:08 --> Security Class Initialized
DEBUG - 2021-12-13 02:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:11:08 --> Input Class Initialized
INFO - 2021-12-13 02:11:08 --> Language Class Initialized
INFO - 2021-12-13 02:11:08 --> Language Class Initialized
INFO - 2021-12-13 02:11:08 --> Config Class Initialized
INFO - 2021-12-13 02:11:08 --> Loader Class Initialized
INFO - 2021-12-13 02:11:08 --> Helper loaded: url_helper
INFO - 2021-12-13 02:11:08 --> Helper loaded: file_helper
INFO - 2021-12-13 02:11:08 --> Helper loaded: form_helper
INFO - 2021-12-13 02:11:08 --> Helper loaded: my_helper
INFO - 2021-12-13 02:11:08 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:11:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:11:08 --> Controller Class Initialized
DEBUG - 2021-12-13 02:11:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 02:11:08 --> Final output sent to browser
DEBUG - 2021-12-13 02:11:08 --> Total execution time: 0.0570
INFO - 2021-12-13 02:11:09 --> Config Class Initialized
INFO - 2021-12-13 02:11:09 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:11:09 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:11:09 --> Utf8 Class Initialized
INFO - 2021-12-13 02:11:09 --> URI Class Initialized
INFO - 2021-12-13 02:11:09 --> Router Class Initialized
INFO - 2021-12-13 02:11:09 --> Output Class Initialized
INFO - 2021-12-13 02:11:10 --> Security Class Initialized
DEBUG - 2021-12-13 02:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:11:10 --> Input Class Initialized
INFO - 2021-12-13 02:11:10 --> Language Class Initialized
INFO - 2021-12-13 02:11:10 --> Language Class Initialized
INFO - 2021-12-13 02:11:10 --> Config Class Initialized
INFO - 2021-12-13 02:11:10 --> Loader Class Initialized
INFO - 2021-12-13 02:11:10 --> Helper loaded: url_helper
INFO - 2021-12-13 02:11:10 --> Helper loaded: file_helper
INFO - 2021-12-13 02:11:10 --> Helper loaded: form_helper
INFO - 2021-12-13 02:11:10 --> Helper loaded: my_helper
INFO - 2021-12-13 02:11:10 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:11:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:11:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:11:10 --> Controller Class Initialized
DEBUG - 2021-12-13 02:11:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 02:11:10 --> Final output sent to browser
DEBUG - 2021-12-13 02:11:10 --> Total execution time: 0.0630
INFO - 2021-12-13 02:13:59 --> Config Class Initialized
INFO - 2021-12-13 02:13:59 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:13:59 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:13:59 --> Utf8 Class Initialized
INFO - 2021-12-13 02:13:59 --> URI Class Initialized
INFO - 2021-12-13 02:13:59 --> Router Class Initialized
INFO - 2021-12-13 02:13:59 --> Output Class Initialized
INFO - 2021-12-13 02:13:59 --> Security Class Initialized
DEBUG - 2021-12-13 02:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:13:59 --> Input Class Initialized
INFO - 2021-12-13 02:13:59 --> Language Class Initialized
INFO - 2021-12-13 02:13:59 --> Language Class Initialized
INFO - 2021-12-13 02:13:59 --> Config Class Initialized
INFO - 2021-12-13 02:13:59 --> Loader Class Initialized
INFO - 2021-12-13 02:13:59 --> Helper loaded: url_helper
INFO - 2021-12-13 02:13:59 --> Helper loaded: file_helper
INFO - 2021-12-13 02:13:59 --> Helper loaded: form_helper
INFO - 2021-12-13 02:13:59 --> Helper loaded: my_helper
INFO - 2021-12-13 02:13:59 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:13:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:13:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:13:59 --> Controller Class Initialized
INFO - 2021-12-13 02:13:59 --> Helper loaded: cookie_helper
INFO - 2021-12-13 02:13:59 --> Config Class Initialized
INFO - 2021-12-13 02:13:59 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:13:59 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:13:59 --> Utf8 Class Initialized
INFO - 2021-12-13 02:13:59 --> URI Class Initialized
INFO - 2021-12-13 02:13:59 --> Router Class Initialized
INFO - 2021-12-13 02:13:59 --> Output Class Initialized
INFO - 2021-12-13 02:13:59 --> Security Class Initialized
DEBUG - 2021-12-13 02:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:13:59 --> Input Class Initialized
INFO - 2021-12-13 02:13:59 --> Language Class Initialized
INFO - 2021-12-13 02:13:59 --> Language Class Initialized
INFO - 2021-12-13 02:13:59 --> Config Class Initialized
INFO - 2021-12-13 02:13:59 --> Loader Class Initialized
INFO - 2021-12-13 02:13:59 --> Helper loaded: url_helper
INFO - 2021-12-13 02:13:59 --> Helper loaded: file_helper
INFO - 2021-12-13 02:13:59 --> Helper loaded: form_helper
INFO - 2021-12-13 02:13:59 --> Helper loaded: my_helper
INFO - 2021-12-13 02:13:59 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:13:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:13:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:13:59 --> Controller Class Initialized
DEBUG - 2021-12-13 02:13:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-13 02:13:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 02:13:59 --> Final output sent to browser
DEBUG - 2021-12-13 02:13:59 --> Total execution time: 0.0350
INFO - 2021-12-13 02:14:06 --> Config Class Initialized
INFO - 2021-12-13 02:14:06 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:14:06 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:14:06 --> Utf8 Class Initialized
INFO - 2021-12-13 02:14:06 --> URI Class Initialized
INFO - 2021-12-13 02:14:06 --> Router Class Initialized
INFO - 2021-12-13 02:14:06 --> Output Class Initialized
INFO - 2021-12-13 02:14:06 --> Security Class Initialized
DEBUG - 2021-12-13 02:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:14:06 --> Input Class Initialized
INFO - 2021-12-13 02:14:06 --> Language Class Initialized
INFO - 2021-12-13 02:14:06 --> Language Class Initialized
INFO - 2021-12-13 02:14:06 --> Config Class Initialized
INFO - 2021-12-13 02:14:06 --> Loader Class Initialized
INFO - 2021-12-13 02:14:06 --> Helper loaded: url_helper
INFO - 2021-12-13 02:14:06 --> Helper loaded: file_helper
INFO - 2021-12-13 02:14:06 --> Helper loaded: form_helper
INFO - 2021-12-13 02:14:06 --> Helper loaded: my_helper
INFO - 2021-12-13 02:14:06 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:14:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:14:06 --> Controller Class Initialized
INFO - 2021-12-13 02:14:06 --> Helper loaded: cookie_helper
INFO - 2021-12-13 02:14:06 --> Final output sent to browser
DEBUG - 2021-12-13 02:14:06 --> Total execution time: 0.0580
INFO - 2021-12-13 02:14:06 --> Config Class Initialized
INFO - 2021-12-13 02:14:06 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:14:06 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:14:06 --> Utf8 Class Initialized
INFO - 2021-12-13 02:14:06 --> URI Class Initialized
INFO - 2021-12-13 02:14:06 --> Router Class Initialized
INFO - 2021-12-13 02:14:06 --> Output Class Initialized
INFO - 2021-12-13 02:14:06 --> Security Class Initialized
DEBUG - 2021-12-13 02:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:14:06 --> Input Class Initialized
INFO - 2021-12-13 02:14:06 --> Language Class Initialized
INFO - 2021-12-13 02:14:06 --> Language Class Initialized
INFO - 2021-12-13 02:14:06 --> Config Class Initialized
INFO - 2021-12-13 02:14:06 --> Loader Class Initialized
INFO - 2021-12-13 02:14:06 --> Helper loaded: url_helper
INFO - 2021-12-13 02:14:06 --> Helper loaded: file_helper
INFO - 2021-12-13 02:14:06 --> Helper loaded: form_helper
INFO - 2021-12-13 02:14:06 --> Helper loaded: my_helper
INFO - 2021-12-13 02:14:06 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:14:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:14:06 --> Controller Class Initialized
DEBUG - 2021-12-13 02:14:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-13 02:14:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 02:14:07 --> Final output sent to browser
DEBUG - 2021-12-13 02:14:07 --> Total execution time: 0.2200
INFO - 2021-12-13 02:14:09 --> Config Class Initialized
INFO - 2021-12-13 02:14:09 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:14:09 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:14:09 --> Utf8 Class Initialized
INFO - 2021-12-13 02:14:09 --> URI Class Initialized
INFO - 2021-12-13 02:14:09 --> Router Class Initialized
INFO - 2021-12-13 02:14:09 --> Output Class Initialized
INFO - 2021-12-13 02:14:09 --> Security Class Initialized
DEBUG - 2021-12-13 02:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:14:09 --> Input Class Initialized
INFO - 2021-12-13 02:14:09 --> Language Class Initialized
INFO - 2021-12-13 02:14:09 --> Language Class Initialized
INFO - 2021-12-13 02:14:09 --> Config Class Initialized
INFO - 2021-12-13 02:14:09 --> Loader Class Initialized
INFO - 2021-12-13 02:14:09 --> Helper loaded: url_helper
INFO - 2021-12-13 02:14:09 --> Helper loaded: file_helper
INFO - 2021-12-13 02:14:09 --> Helper loaded: form_helper
INFO - 2021-12-13 02:14:09 --> Helper loaded: my_helper
INFO - 2021-12-13 02:14:09 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:14:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:14:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:14:09 --> Controller Class Initialized
DEBUG - 2021-12-13 02:14:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-13 02:14:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 02:14:09 --> Final output sent to browser
DEBUG - 2021-12-13 02:14:09 --> Total execution time: 0.0790
INFO - 2021-12-13 02:14:14 --> Config Class Initialized
INFO - 2021-12-13 02:14:14 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:14:14 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:14:14 --> Utf8 Class Initialized
INFO - 2021-12-13 02:14:14 --> URI Class Initialized
INFO - 2021-12-13 02:14:14 --> Router Class Initialized
INFO - 2021-12-13 02:14:14 --> Output Class Initialized
INFO - 2021-12-13 02:14:14 --> Security Class Initialized
DEBUG - 2021-12-13 02:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:14:14 --> Input Class Initialized
INFO - 2021-12-13 02:14:14 --> Language Class Initialized
INFO - 2021-12-13 02:14:14 --> Language Class Initialized
INFO - 2021-12-13 02:14:14 --> Config Class Initialized
INFO - 2021-12-13 02:14:14 --> Loader Class Initialized
INFO - 2021-12-13 02:14:14 --> Helper loaded: url_helper
INFO - 2021-12-13 02:14:14 --> Helper loaded: file_helper
INFO - 2021-12-13 02:14:14 --> Helper loaded: form_helper
INFO - 2021-12-13 02:14:14 --> Helper loaded: my_helper
INFO - 2021-12-13 02:14:14 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:14:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:14:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:14:14 --> Controller Class Initialized
DEBUG - 2021-12-13 02:14:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-12-13 02:14:14 --> Final output sent to browser
DEBUG - 2021-12-13 02:14:14 --> Total execution time: 0.0980
INFO - 2021-12-13 02:14:16 --> Config Class Initialized
INFO - 2021-12-13 02:14:16 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:14:16 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:14:16 --> Utf8 Class Initialized
INFO - 2021-12-13 02:14:16 --> URI Class Initialized
INFO - 2021-12-13 02:14:16 --> Router Class Initialized
INFO - 2021-12-13 02:14:16 --> Output Class Initialized
INFO - 2021-12-13 02:14:16 --> Security Class Initialized
DEBUG - 2021-12-13 02:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:14:16 --> Input Class Initialized
INFO - 2021-12-13 02:14:16 --> Language Class Initialized
INFO - 2021-12-13 02:14:16 --> Language Class Initialized
INFO - 2021-12-13 02:14:16 --> Config Class Initialized
INFO - 2021-12-13 02:14:16 --> Loader Class Initialized
INFO - 2021-12-13 02:14:16 --> Helper loaded: url_helper
INFO - 2021-12-13 02:14:16 --> Helper loaded: file_helper
INFO - 2021-12-13 02:14:16 --> Helper loaded: form_helper
INFO - 2021-12-13 02:14:16 --> Helper loaded: my_helper
INFO - 2021-12-13 02:14:16 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:14:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:14:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:14:16 --> Controller Class Initialized
DEBUG - 2021-12-13 02:14:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-12-13 02:14:16 --> Final output sent to browser
DEBUG - 2021-12-13 02:14:16 --> Total execution time: 0.0570
INFO - 2021-12-13 02:14:18 --> Config Class Initialized
INFO - 2021-12-13 02:14:18 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:14:18 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:14:18 --> Utf8 Class Initialized
INFO - 2021-12-13 02:14:18 --> URI Class Initialized
INFO - 2021-12-13 02:14:18 --> Router Class Initialized
INFO - 2021-12-13 02:14:18 --> Output Class Initialized
INFO - 2021-12-13 02:14:18 --> Security Class Initialized
DEBUG - 2021-12-13 02:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:14:18 --> Input Class Initialized
INFO - 2021-12-13 02:14:18 --> Language Class Initialized
INFO - 2021-12-13 02:14:18 --> Language Class Initialized
INFO - 2021-12-13 02:14:18 --> Config Class Initialized
INFO - 2021-12-13 02:14:18 --> Loader Class Initialized
INFO - 2021-12-13 02:14:18 --> Helper loaded: url_helper
INFO - 2021-12-13 02:14:18 --> Helper loaded: file_helper
INFO - 2021-12-13 02:14:18 --> Helper loaded: form_helper
INFO - 2021-12-13 02:14:18 --> Helper loaded: my_helper
INFO - 2021-12-13 02:14:18 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:14:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:14:18 --> Controller Class Initialized
DEBUG - 2021-12-13 02:14:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-12-13 02:14:18 --> Final output sent to browser
DEBUG - 2021-12-13 02:14:18 --> Total execution time: 0.0640
INFO - 2021-12-13 02:14:19 --> Config Class Initialized
INFO - 2021-12-13 02:14:19 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:14:19 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:14:19 --> Utf8 Class Initialized
INFO - 2021-12-13 02:14:19 --> URI Class Initialized
INFO - 2021-12-13 02:14:19 --> Router Class Initialized
INFO - 2021-12-13 02:14:19 --> Output Class Initialized
INFO - 2021-12-13 02:14:19 --> Security Class Initialized
DEBUG - 2021-12-13 02:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:14:19 --> Input Class Initialized
INFO - 2021-12-13 02:14:19 --> Language Class Initialized
INFO - 2021-12-13 02:14:19 --> Language Class Initialized
INFO - 2021-12-13 02:14:19 --> Config Class Initialized
INFO - 2021-12-13 02:14:19 --> Loader Class Initialized
INFO - 2021-12-13 02:14:19 --> Helper loaded: url_helper
INFO - 2021-12-13 02:14:19 --> Helper loaded: file_helper
INFO - 2021-12-13 02:14:19 --> Helper loaded: form_helper
INFO - 2021-12-13 02:14:19 --> Helper loaded: my_helper
INFO - 2021-12-13 02:14:19 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:14:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:14:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:14:19 --> Controller Class Initialized
DEBUG - 2021-12-13 02:14:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-12-13 02:14:19 --> Final output sent to browser
DEBUG - 2021-12-13 02:14:19 --> Total execution time: 0.0590
INFO - 2021-12-13 02:14:50 --> Config Class Initialized
INFO - 2021-12-13 02:14:50 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:14:50 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:14:50 --> Utf8 Class Initialized
INFO - 2021-12-13 02:14:50 --> URI Class Initialized
INFO - 2021-12-13 02:14:50 --> Router Class Initialized
INFO - 2021-12-13 02:14:50 --> Output Class Initialized
INFO - 2021-12-13 02:14:50 --> Security Class Initialized
DEBUG - 2021-12-13 02:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:14:50 --> Input Class Initialized
INFO - 2021-12-13 02:14:50 --> Language Class Initialized
INFO - 2021-12-13 02:14:50 --> Language Class Initialized
INFO - 2021-12-13 02:14:50 --> Config Class Initialized
INFO - 2021-12-13 02:14:50 --> Loader Class Initialized
INFO - 2021-12-13 02:14:50 --> Helper loaded: url_helper
INFO - 2021-12-13 02:14:50 --> Helper loaded: file_helper
INFO - 2021-12-13 02:14:50 --> Helper loaded: form_helper
INFO - 2021-12-13 02:14:50 --> Helper loaded: my_helper
INFO - 2021-12-13 02:14:50 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:14:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:14:50 --> Controller Class Initialized
INFO - 2021-12-13 02:14:50 --> Helper loaded: cookie_helper
INFO - 2021-12-13 02:14:50 --> Config Class Initialized
INFO - 2021-12-13 02:14:50 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:14:50 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:14:50 --> Utf8 Class Initialized
INFO - 2021-12-13 02:14:50 --> URI Class Initialized
INFO - 2021-12-13 02:14:50 --> Router Class Initialized
INFO - 2021-12-13 02:14:50 --> Output Class Initialized
INFO - 2021-12-13 02:14:50 --> Security Class Initialized
DEBUG - 2021-12-13 02:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:14:50 --> Input Class Initialized
INFO - 2021-12-13 02:14:50 --> Language Class Initialized
INFO - 2021-12-13 02:14:50 --> Language Class Initialized
INFO - 2021-12-13 02:14:50 --> Config Class Initialized
INFO - 2021-12-13 02:14:50 --> Loader Class Initialized
INFO - 2021-12-13 02:14:50 --> Helper loaded: url_helper
INFO - 2021-12-13 02:14:50 --> Helper loaded: file_helper
INFO - 2021-12-13 02:14:50 --> Helper loaded: form_helper
INFO - 2021-12-13 02:14:50 --> Helper loaded: my_helper
INFO - 2021-12-13 02:14:50 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:14:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:14:50 --> Controller Class Initialized
DEBUG - 2021-12-13 02:14:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-13 02:14:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 02:14:50 --> Final output sent to browser
DEBUG - 2021-12-13 02:14:50 --> Total execution time: 0.0460
INFO - 2021-12-13 02:14:54 --> Config Class Initialized
INFO - 2021-12-13 02:14:54 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:14:54 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:14:54 --> Utf8 Class Initialized
INFO - 2021-12-13 02:14:54 --> URI Class Initialized
INFO - 2021-12-13 02:14:54 --> Router Class Initialized
INFO - 2021-12-13 02:14:54 --> Output Class Initialized
INFO - 2021-12-13 02:14:54 --> Security Class Initialized
DEBUG - 2021-12-13 02:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:14:54 --> Input Class Initialized
INFO - 2021-12-13 02:14:54 --> Language Class Initialized
INFO - 2021-12-13 02:14:54 --> Language Class Initialized
INFO - 2021-12-13 02:14:54 --> Config Class Initialized
INFO - 2021-12-13 02:14:54 --> Loader Class Initialized
INFO - 2021-12-13 02:14:54 --> Helper loaded: url_helper
INFO - 2021-12-13 02:14:54 --> Helper loaded: file_helper
INFO - 2021-12-13 02:14:54 --> Helper loaded: form_helper
INFO - 2021-12-13 02:14:54 --> Helper loaded: my_helper
INFO - 2021-12-13 02:14:54 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:14:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:14:54 --> Controller Class Initialized
INFO - 2021-12-13 02:14:54 --> Helper loaded: cookie_helper
INFO - 2021-12-13 02:14:54 --> Final output sent to browser
DEBUG - 2021-12-13 02:14:54 --> Total execution time: 0.0520
INFO - 2021-12-13 02:14:54 --> Config Class Initialized
INFO - 2021-12-13 02:14:54 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:14:54 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:14:54 --> Utf8 Class Initialized
INFO - 2021-12-13 02:14:54 --> URI Class Initialized
INFO - 2021-12-13 02:14:54 --> Router Class Initialized
INFO - 2021-12-13 02:14:54 --> Output Class Initialized
INFO - 2021-12-13 02:14:54 --> Security Class Initialized
DEBUG - 2021-12-13 02:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:14:54 --> Input Class Initialized
INFO - 2021-12-13 02:14:54 --> Language Class Initialized
INFO - 2021-12-13 02:14:54 --> Language Class Initialized
INFO - 2021-12-13 02:14:54 --> Config Class Initialized
INFO - 2021-12-13 02:14:54 --> Loader Class Initialized
INFO - 2021-12-13 02:14:54 --> Helper loaded: url_helper
INFO - 2021-12-13 02:14:54 --> Helper loaded: file_helper
INFO - 2021-12-13 02:14:54 --> Helper loaded: form_helper
INFO - 2021-12-13 02:14:54 --> Helper loaded: my_helper
INFO - 2021-12-13 02:14:54 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:14:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:14:54 --> Controller Class Initialized
DEBUG - 2021-12-13 02:14:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-13 02:14:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 02:14:54 --> Final output sent to browser
DEBUG - 2021-12-13 02:14:54 --> Total execution time: 0.1970
INFO - 2021-12-13 02:15:06 --> Config Class Initialized
INFO - 2021-12-13 02:15:06 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:15:06 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:15:06 --> Utf8 Class Initialized
INFO - 2021-12-13 02:15:06 --> URI Class Initialized
INFO - 2021-12-13 02:15:06 --> Router Class Initialized
INFO - 2021-12-13 02:15:06 --> Output Class Initialized
INFO - 2021-12-13 02:15:06 --> Security Class Initialized
DEBUG - 2021-12-13 02:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:15:06 --> Input Class Initialized
INFO - 2021-12-13 02:15:06 --> Language Class Initialized
INFO - 2021-12-13 02:15:06 --> Language Class Initialized
INFO - 2021-12-13 02:15:06 --> Config Class Initialized
INFO - 2021-12-13 02:15:06 --> Loader Class Initialized
INFO - 2021-12-13 02:15:06 --> Helper loaded: url_helper
INFO - 2021-12-13 02:15:06 --> Helper loaded: file_helper
INFO - 2021-12-13 02:15:06 --> Helper loaded: form_helper
INFO - 2021-12-13 02:15:06 --> Helper loaded: my_helper
INFO - 2021-12-13 02:15:06 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:15:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:15:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:15:06 --> Controller Class Initialized
INFO - 2021-12-13 02:15:06 --> Helper loaded: cookie_helper
INFO - 2021-12-13 02:15:06 --> Config Class Initialized
INFO - 2021-12-13 02:15:06 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:15:06 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:15:06 --> Utf8 Class Initialized
INFO - 2021-12-13 02:15:06 --> URI Class Initialized
INFO - 2021-12-13 02:15:06 --> Router Class Initialized
INFO - 2021-12-13 02:15:06 --> Output Class Initialized
INFO - 2021-12-13 02:15:06 --> Security Class Initialized
DEBUG - 2021-12-13 02:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:15:06 --> Input Class Initialized
INFO - 2021-12-13 02:15:06 --> Language Class Initialized
INFO - 2021-12-13 02:15:06 --> Language Class Initialized
INFO - 2021-12-13 02:15:06 --> Config Class Initialized
INFO - 2021-12-13 02:15:06 --> Loader Class Initialized
INFO - 2021-12-13 02:15:06 --> Helper loaded: url_helper
INFO - 2021-12-13 02:15:06 --> Helper loaded: file_helper
INFO - 2021-12-13 02:15:06 --> Helper loaded: form_helper
INFO - 2021-12-13 02:15:06 --> Helper loaded: my_helper
INFO - 2021-12-13 02:15:06 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:15:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:15:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:15:06 --> Controller Class Initialized
DEBUG - 2021-12-13 02:15:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-13 02:15:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 02:15:06 --> Final output sent to browser
DEBUG - 2021-12-13 02:15:06 --> Total execution time: 0.0390
INFO - 2021-12-13 02:15:12 --> Config Class Initialized
INFO - 2021-12-13 02:15:12 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:15:12 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:15:12 --> Utf8 Class Initialized
INFO - 2021-12-13 02:15:12 --> URI Class Initialized
INFO - 2021-12-13 02:15:12 --> Router Class Initialized
INFO - 2021-12-13 02:15:12 --> Output Class Initialized
INFO - 2021-12-13 02:15:12 --> Security Class Initialized
DEBUG - 2021-12-13 02:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:15:12 --> Input Class Initialized
INFO - 2021-12-13 02:15:12 --> Language Class Initialized
INFO - 2021-12-13 02:15:12 --> Language Class Initialized
INFO - 2021-12-13 02:15:12 --> Config Class Initialized
INFO - 2021-12-13 02:15:12 --> Loader Class Initialized
INFO - 2021-12-13 02:15:12 --> Helper loaded: url_helper
INFO - 2021-12-13 02:15:12 --> Helper loaded: file_helper
INFO - 2021-12-13 02:15:12 --> Helper loaded: form_helper
INFO - 2021-12-13 02:15:12 --> Helper loaded: my_helper
INFO - 2021-12-13 02:15:12 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:15:12 --> Controller Class Initialized
INFO - 2021-12-13 02:15:12 --> Helper loaded: cookie_helper
INFO - 2021-12-13 02:15:12 --> Final output sent to browser
DEBUG - 2021-12-13 02:15:12 --> Total execution time: 0.0590
INFO - 2021-12-13 02:15:12 --> Config Class Initialized
INFO - 2021-12-13 02:15:12 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:15:12 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:15:12 --> Utf8 Class Initialized
INFO - 2021-12-13 02:15:12 --> URI Class Initialized
INFO - 2021-12-13 02:15:12 --> Router Class Initialized
INFO - 2021-12-13 02:15:12 --> Output Class Initialized
INFO - 2021-12-13 02:15:12 --> Security Class Initialized
DEBUG - 2021-12-13 02:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:15:12 --> Input Class Initialized
INFO - 2021-12-13 02:15:12 --> Language Class Initialized
INFO - 2021-12-13 02:15:12 --> Language Class Initialized
INFO - 2021-12-13 02:15:12 --> Config Class Initialized
INFO - 2021-12-13 02:15:12 --> Loader Class Initialized
INFO - 2021-12-13 02:15:12 --> Helper loaded: url_helper
INFO - 2021-12-13 02:15:12 --> Helper loaded: file_helper
INFO - 2021-12-13 02:15:12 --> Helper loaded: form_helper
INFO - 2021-12-13 02:15:12 --> Helper loaded: my_helper
INFO - 2021-12-13 02:15:12 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:15:12 --> Controller Class Initialized
DEBUG - 2021-12-13 02:15:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-13 02:15:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 02:15:12 --> Final output sent to browser
DEBUG - 2021-12-13 02:15:12 --> Total execution time: 0.1390
INFO - 2021-12-13 02:15:14 --> Config Class Initialized
INFO - 2021-12-13 02:15:14 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:15:14 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:15:14 --> Utf8 Class Initialized
INFO - 2021-12-13 02:15:14 --> URI Class Initialized
INFO - 2021-12-13 02:15:14 --> Router Class Initialized
INFO - 2021-12-13 02:15:14 --> Output Class Initialized
INFO - 2021-12-13 02:15:14 --> Security Class Initialized
DEBUG - 2021-12-13 02:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:15:14 --> Input Class Initialized
INFO - 2021-12-13 02:15:14 --> Language Class Initialized
INFO - 2021-12-13 02:15:14 --> Language Class Initialized
INFO - 2021-12-13 02:15:14 --> Config Class Initialized
INFO - 2021-12-13 02:15:14 --> Loader Class Initialized
INFO - 2021-12-13 02:15:14 --> Helper loaded: url_helper
INFO - 2021-12-13 02:15:14 --> Helper loaded: file_helper
INFO - 2021-12-13 02:15:14 --> Helper loaded: form_helper
INFO - 2021-12-13 02:15:14 --> Helper loaded: my_helper
INFO - 2021-12-13 02:15:14 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:15:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:15:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:15:14 --> Controller Class Initialized
DEBUG - 2021-12-13 02:15:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-13 02:15:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 02:15:14 --> Final output sent to browser
DEBUG - 2021-12-13 02:15:14 --> Total execution time: 0.0550
INFO - 2021-12-13 02:15:36 --> Config Class Initialized
INFO - 2021-12-13 02:15:36 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:15:36 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:15:36 --> Utf8 Class Initialized
INFO - 2021-12-13 02:15:36 --> URI Class Initialized
INFO - 2021-12-13 02:15:36 --> Router Class Initialized
INFO - 2021-12-13 02:15:36 --> Output Class Initialized
INFO - 2021-12-13 02:15:36 --> Security Class Initialized
DEBUG - 2021-12-13 02:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:15:36 --> Input Class Initialized
INFO - 2021-12-13 02:15:36 --> Language Class Initialized
INFO - 2021-12-13 02:15:37 --> Language Class Initialized
INFO - 2021-12-13 02:15:37 --> Config Class Initialized
INFO - 2021-12-13 02:15:37 --> Loader Class Initialized
INFO - 2021-12-13 02:15:37 --> Helper loaded: url_helper
INFO - 2021-12-13 02:15:37 --> Helper loaded: file_helper
INFO - 2021-12-13 02:15:37 --> Helper loaded: form_helper
INFO - 2021-12-13 02:15:37 --> Helper loaded: my_helper
INFO - 2021-12-13 02:15:37 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:15:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:15:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:15:37 --> Controller Class Initialized
INFO - 2021-12-13 02:15:37 --> Helper loaded: cookie_helper
INFO - 2021-12-13 02:15:37 --> Config Class Initialized
INFO - 2021-12-13 02:15:37 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:15:37 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:15:37 --> Utf8 Class Initialized
INFO - 2021-12-13 02:15:37 --> URI Class Initialized
INFO - 2021-12-13 02:15:37 --> Router Class Initialized
INFO - 2021-12-13 02:15:37 --> Output Class Initialized
INFO - 2021-12-13 02:15:37 --> Security Class Initialized
DEBUG - 2021-12-13 02:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:15:37 --> Input Class Initialized
INFO - 2021-12-13 02:15:37 --> Language Class Initialized
INFO - 2021-12-13 02:15:37 --> Language Class Initialized
INFO - 2021-12-13 02:15:37 --> Config Class Initialized
INFO - 2021-12-13 02:15:37 --> Loader Class Initialized
INFO - 2021-12-13 02:15:37 --> Helper loaded: url_helper
INFO - 2021-12-13 02:15:37 --> Helper loaded: file_helper
INFO - 2021-12-13 02:15:37 --> Helper loaded: form_helper
INFO - 2021-12-13 02:15:37 --> Helper loaded: my_helper
INFO - 2021-12-13 02:15:37 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:15:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:15:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:15:37 --> Controller Class Initialized
DEBUG - 2021-12-13 02:15:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-13 02:15:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 02:15:37 --> Final output sent to browser
DEBUG - 2021-12-13 02:15:37 --> Total execution time: 0.0360
INFO - 2021-12-13 02:15:40 --> Config Class Initialized
INFO - 2021-12-13 02:15:40 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:15:40 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:15:40 --> Utf8 Class Initialized
INFO - 2021-12-13 02:15:40 --> URI Class Initialized
INFO - 2021-12-13 02:15:40 --> Router Class Initialized
INFO - 2021-12-13 02:15:40 --> Output Class Initialized
INFO - 2021-12-13 02:15:40 --> Security Class Initialized
DEBUG - 2021-12-13 02:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:15:40 --> Input Class Initialized
INFO - 2021-12-13 02:15:40 --> Language Class Initialized
INFO - 2021-12-13 02:15:40 --> Language Class Initialized
INFO - 2021-12-13 02:15:40 --> Config Class Initialized
INFO - 2021-12-13 02:15:40 --> Loader Class Initialized
INFO - 2021-12-13 02:15:40 --> Helper loaded: url_helper
INFO - 2021-12-13 02:15:40 --> Helper loaded: file_helper
INFO - 2021-12-13 02:15:40 --> Helper loaded: form_helper
INFO - 2021-12-13 02:15:40 --> Helper loaded: my_helper
INFO - 2021-12-13 02:15:40 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:15:40 --> Controller Class Initialized
INFO - 2021-12-13 02:15:40 --> Helper loaded: cookie_helper
INFO - 2021-12-13 02:15:40 --> Final output sent to browser
DEBUG - 2021-12-13 02:15:40 --> Total execution time: 0.0530
INFO - 2021-12-13 02:15:41 --> Config Class Initialized
INFO - 2021-12-13 02:15:41 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:15:41 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:15:41 --> Utf8 Class Initialized
INFO - 2021-12-13 02:15:41 --> URI Class Initialized
INFO - 2021-12-13 02:15:41 --> Router Class Initialized
INFO - 2021-12-13 02:15:41 --> Output Class Initialized
INFO - 2021-12-13 02:15:41 --> Security Class Initialized
DEBUG - 2021-12-13 02:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:15:41 --> Input Class Initialized
INFO - 2021-12-13 02:15:41 --> Language Class Initialized
INFO - 2021-12-13 02:15:41 --> Language Class Initialized
INFO - 2021-12-13 02:15:41 --> Config Class Initialized
INFO - 2021-12-13 02:15:41 --> Loader Class Initialized
INFO - 2021-12-13 02:15:41 --> Helper loaded: url_helper
INFO - 2021-12-13 02:15:41 --> Helper loaded: file_helper
INFO - 2021-12-13 02:15:41 --> Helper loaded: form_helper
INFO - 2021-12-13 02:15:41 --> Helper loaded: my_helper
INFO - 2021-12-13 02:15:41 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:15:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:15:41 --> Controller Class Initialized
DEBUG - 2021-12-13 02:15:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-13 02:15:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 02:15:41 --> Final output sent to browser
DEBUG - 2021-12-13 02:15:41 --> Total execution time: 0.1370
INFO - 2021-12-13 02:15:43 --> Config Class Initialized
INFO - 2021-12-13 02:15:43 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:15:43 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:15:43 --> Utf8 Class Initialized
INFO - 2021-12-13 02:15:43 --> URI Class Initialized
INFO - 2021-12-13 02:15:43 --> Router Class Initialized
INFO - 2021-12-13 02:15:43 --> Output Class Initialized
INFO - 2021-12-13 02:15:43 --> Security Class Initialized
DEBUG - 2021-12-13 02:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:15:43 --> Input Class Initialized
INFO - 2021-12-13 02:15:43 --> Language Class Initialized
INFO - 2021-12-13 02:15:43 --> Language Class Initialized
INFO - 2021-12-13 02:15:43 --> Config Class Initialized
INFO - 2021-12-13 02:15:43 --> Loader Class Initialized
INFO - 2021-12-13 02:15:43 --> Helper loaded: url_helper
INFO - 2021-12-13 02:15:43 --> Helper loaded: file_helper
INFO - 2021-12-13 02:15:43 --> Helper loaded: form_helper
INFO - 2021-12-13 02:15:43 --> Helper loaded: my_helper
INFO - 2021-12-13 02:15:43 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:15:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:15:43 --> Controller Class Initialized
DEBUG - 2021-12-13 02:15:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-13 02:15:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 02:15:43 --> Final output sent to browser
DEBUG - 2021-12-13 02:15:43 --> Total execution time: 0.0630
INFO - 2021-12-13 02:15:48 --> Config Class Initialized
INFO - 2021-12-13 02:15:48 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:15:48 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:15:48 --> Utf8 Class Initialized
INFO - 2021-12-13 02:15:48 --> URI Class Initialized
INFO - 2021-12-13 02:15:48 --> Router Class Initialized
INFO - 2021-12-13 02:15:48 --> Output Class Initialized
INFO - 2021-12-13 02:15:48 --> Security Class Initialized
DEBUG - 2021-12-13 02:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:15:48 --> Input Class Initialized
INFO - 2021-12-13 02:15:48 --> Language Class Initialized
INFO - 2021-12-13 02:15:48 --> Language Class Initialized
INFO - 2021-12-13 02:15:48 --> Config Class Initialized
INFO - 2021-12-13 02:15:48 --> Loader Class Initialized
INFO - 2021-12-13 02:15:48 --> Helper loaded: url_helper
INFO - 2021-12-13 02:15:48 --> Helper loaded: file_helper
INFO - 2021-12-13 02:15:48 --> Helper loaded: form_helper
INFO - 2021-12-13 02:15:48 --> Helper loaded: my_helper
INFO - 2021-12-13 02:15:48 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:15:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:15:48 --> Controller Class Initialized
DEBUG - 2021-12-13 02:15:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-13 02:15:48 --> Final output sent to browser
DEBUG - 2021-12-13 02:15:48 --> Total execution time: 0.1080
INFO - 2021-12-13 02:15:49 --> Config Class Initialized
INFO - 2021-12-13 02:15:49 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:15:49 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:15:49 --> Utf8 Class Initialized
INFO - 2021-12-13 02:15:49 --> URI Class Initialized
INFO - 2021-12-13 02:15:49 --> Router Class Initialized
INFO - 2021-12-13 02:15:49 --> Output Class Initialized
INFO - 2021-12-13 02:15:49 --> Security Class Initialized
DEBUG - 2021-12-13 02:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:15:49 --> Input Class Initialized
INFO - 2021-12-13 02:15:49 --> Language Class Initialized
INFO - 2021-12-13 02:15:49 --> Language Class Initialized
INFO - 2021-12-13 02:15:49 --> Config Class Initialized
INFO - 2021-12-13 02:15:49 --> Loader Class Initialized
INFO - 2021-12-13 02:15:49 --> Helper loaded: url_helper
INFO - 2021-12-13 02:15:49 --> Helper loaded: file_helper
INFO - 2021-12-13 02:15:49 --> Helper loaded: form_helper
INFO - 2021-12-13 02:15:49 --> Helper loaded: my_helper
INFO - 2021-12-13 02:15:49 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:15:49 --> Controller Class Initialized
DEBUG - 2021-12-13 02:15:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-13 02:15:49 --> Final output sent to browser
DEBUG - 2021-12-13 02:15:49 --> Total execution time: 0.0590
INFO - 2021-12-13 02:15:51 --> Config Class Initialized
INFO - 2021-12-13 02:15:51 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:15:51 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:15:51 --> Utf8 Class Initialized
INFO - 2021-12-13 02:15:51 --> URI Class Initialized
INFO - 2021-12-13 02:15:51 --> Router Class Initialized
INFO - 2021-12-13 02:15:51 --> Output Class Initialized
INFO - 2021-12-13 02:15:51 --> Security Class Initialized
DEBUG - 2021-12-13 02:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:15:51 --> Input Class Initialized
INFO - 2021-12-13 02:15:51 --> Language Class Initialized
INFO - 2021-12-13 02:15:51 --> Language Class Initialized
INFO - 2021-12-13 02:15:51 --> Config Class Initialized
INFO - 2021-12-13 02:15:51 --> Loader Class Initialized
INFO - 2021-12-13 02:15:51 --> Helper loaded: url_helper
INFO - 2021-12-13 02:15:51 --> Helper loaded: file_helper
INFO - 2021-12-13 02:15:51 --> Helper loaded: form_helper
INFO - 2021-12-13 02:15:51 --> Helper loaded: my_helper
INFO - 2021-12-13 02:15:51 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:15:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:15:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:15:51 --> Controller Class Initialized
DEBUG - 2021-12-13 02:15:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-13 02:15:51 --> Final output sent to browser
DEBUG - 2021-12-13 02:15:51 --> Total execution time: 0.0520
INFO - 2021-12-13 02:15:52 --> Config Class Initialized
INFO - 2021-12-13 02:15:52 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:15:52 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:15:52 --> Utf8 Class Initialized
INFO - 2021-12-13 02:15:52 --> URI Class Initialized
INFO - 2021-12-13 02:15:52 --> Router Class Initialized
INFO - 2021-12-13 02:15:52 --> Output Class Initialized
INFO - 2021-12-13 02:15:52 --> Security Class Initialized
DEBUG - 2021-12-13 02:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:15:52 --> Input Class Initialized
INFO - 2021-12-13 02:15:52 --> Language Class Initialized
INFO - 2021-12-13 02:15:52 --> Language Class Initialized
INFO - 2021-12-13 02:15:52 --> Config Class Initialized
INFO - 2021-12-13 02:15:52 --> Loader Class Initialized
INFO - 2021-12-13 02:15:52 --> Helper loaded: url_helper
INFO - 2021-12-13 02:15:52 --> Helper loaded: file_helper
INFO - 2021-12-13 02:15:52 --> Helper loaded: form_helper
INFO - 2021-12-13 02:15:52 --> Helper loaded: my_helper
INFO - 2021-12-13 02:15:52 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:15:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:15:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:15:52 --> Controller Class Initialized
DEBUG - 2021-12-13 02:15:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-13 02:15:52 --> Final output sent to browser
DEBUG - 2021-12-13 02:15:52 --> Total execution time: 0.0590
INFO - 2021-12-13 02:15:54 --> Config Class Initialized
INFO - 2021-12-13 02:15:54 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:15:54 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:15:54 --> Utf8 Class Initialized
INFO - 2021-12-13 02:15:54 --> URI Class Initialized
INFO - 2021-12-13 02:15:54 --> Router Class Initialized
INFO - 2021-12-13 02:15:54 --> Output Class Initialized
INFO - 2021-12-13 02:15:54 --> Security Class Initialized
DEBUG - 2021-12-13 02:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:15:54 --> Input Class Initialized
INFO - 2021-12-13 02:15:54 --> Language Class Initialized
INFO - 2021-12-13 02:15:54 --> Language Class Initialized
INFO - 2021-12-13 02:15:54 --> Config Class Initialized
INFO - 2021-12-13 02:15:54 --> Loader Class Initialized
INFO - 2021-12-13 02:15:54 --> Helper loaded: url_helper
INFO - 2021-12-13 02:15:54 --> Helper loaded: file_helper
INFO - 2021-12-13 02:15:54 --> Helper loaded: form_helper
INFO - 2021-12-13 02:15:54 --> Helper loaded: my_helper
INFO - 2021-12-13 02:15:54 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:15:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:15:54 --> Controller Class Initialized
DEBUG - 2021-12-13 02:15:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-13 02:15:54 --> Final output sent to browser
DEBUG - 2021-12-13 02:15:54 --> Total execution time: 0.0540
INFO - 2021-12-13 02:15:56 --> Config Class Initialized
INFO - 2021-12-13 02:15:56 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:15:56 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:15:56 --> Utf8 Class Initialized
INFO - 2021-12-13 02:15:56 --> URI Class Initialized
INFO - 2021-12-13 02:15:56 --> Router Class Initialized
INFO - 2021-12-13 02:15:56 --> Output Class Initialized
INFO - 2021-12-13 02:15:56 --> Security Class Initialized
DEBUG - 2021-12-13 02:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:15:56 --> Input Class Initialized
INFO - 2021-12-13 02:15:56 --> Language Class Initialized
INFO - 2021-12-13 02:15:56 --> Language Class Initialized
INFO - 2021-12-13 02:15:56 --> Config Class Initialized
INFO - 2021-12-13 02:15:56 --> Loader Class Initialized
INFO - 2021-12-13 02:15:56 --> Helper loaded: url_helper
INFO - 2021-12-13 02:15:56 --> Helper loaded: file_helper
INFO - 2021-12-13 02:15:56 --> Helper loaded: form_helper
INFO - 2021-12-13 02:15:56 --> Helper loaded: my_helper
INFO - 2021-12-13 02:15:56 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:15:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:15:56 --> Controller Class Initialized
DEBUG - 2021-12-13 02:15:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-13 02:15:56 --> Final output sent to browser
DEBUG - 2021-12-13 02:15:56 --> Total execution time: 0.0520
INFO - 2021-12-13 02:15:58 --> Config Class Initialized
INFO - 2021-12-13 02:15:58 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:15:58 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:15:58 --> Utf8 Class Initialized
INFO - 2021-12-13 02:15:58 --> URI Class Initialized
INFO - 2021-12-13 02:15:58 --> Router Class Initialized
INFO - 2021-12-13 02:15:58 --> Output Class Initialized
INFO - 2021-12-13 02:15:58 --> Security Class Initialized
DEBUG - 2021-12-13 02:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:15:58 --> Input Class Initialized
INFO - 2021-12-13 02:15:58 --> Language Class Initialized
INFO - 2021-12-13 02:15:58 --> Language Class Initialized
INFO - 2021-12-13 02:15:58 --> Config Class Initialized
INFO - 2021-12-13 02:15:58 --> Loader Class Initialized
INFO - 2021-12-13 02:15:58 --> Helper loaded: url_helper
INFO - 2021-12-13 02:15:58 --> Helper loaded: file_helper
INFO - 2021-12-13 02:15:58 --> Helper loaded: form_helper
INFO - 2021-12-13 02:15:58 --> Helper loaded: my_helper
INFO - 2021-12-13 02:15:58 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:15:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:15:58 --> Controller Class Initialized
DEBUG - 2021-12-13 02:15:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-13 02:15:58 --> Final output sent to browser
DEBUG - 2021-12-13 02:15:58 --> Total execution time: 0.0580
INFO - 2021-12-13 02:16:00 --> Config Class Initialized
INFO - 2021-12-13 02:16:00 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:16:00 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:16:00 --> Utf8 Class Initialized
INFO - 2021-12-13 02:16:00 --> URI Class Initialized
INFO - 2021-12-13 02:16:00 --> Router Class Initialized
INFO - 2021-12-13 02:16:00 --> Output Class Initialized
INFO - 2021-12-13 02:16:00 --> Security Class Initialized
DEBUG - 2021-12-13 02:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:16:00 --> Input Class Initialized
INFO - 2021-12-13 02:16:00 --> Language Class Initialized
INFO - 2021-12-13 02:16:00 --> Language Class Initialized
INFO - 2021-12-13 02:16:00 --> Config Class Initialized
INFO - 2021-12-13 02:16:00 --> Loader Class Initialized
INFO - 2021-12-13 02:16:00 --> Helper loaded: url_helper
INFO - 2021-12-13 02:16:00 --> Helper loaded: file_helper
INFO - 2021-12-13 02:16:00 --> Helper loaded: form_helper
INFO - 2021-12-13 02:16:00 --> Helper loaded: my_helper
INFO - 2021-12-13 02:16:00 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:16:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:16:00 --> Controller Class Initialized
DEBUG - 2021-12-13 02:16:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-13 02:16:00 --> Final output sent to browser
DEBUG - 2021-12-13 02:16:00 --> Total execution time: 0.0650
INFO - 2021-12-13 02:16:01 --> Config Class Initialized
INFO - 2021-12-13 02:16:01 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:16:01 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:16:01 --> Utf8 Class Initialized
INFO - 2021-12-13 02:16:01 --> URI Class Initialized
INFO - 2021-12-13 02:16:01 --> Router Class Initialized
INFO - 2021-12-13 02:16:01 --> Output Class Initialized
INFO - 2021-12-13 02:16:01 --> Security Class Initialized
DEBUG - 2021-12-13 02:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:16:01 --> Input Class Initialized
INFO - 2021-12-13 02:16:01 --> Language Class Initialized
INFO - 2021-12-13 02:16:01 --> Language Class Initialized
INFO - 2021-12-13 02:16:01 --> Config Class Initialized
INFO - 2021-12-13 02:16:01 --> Loader Class Initialized
INFO - 2021-12-13 02:16:01 --> Helper loaded: url_helper
INFO - 2021-12-13 02:16:01 --> Helper loaded: file_helper
INFO - 2021-12-13 02:16:01 --> Helper loaded: form_helper
INFO - 2021-12-13 02:16:01 --> Helper loaded: my_helper
INFO - 2021-12-13 02:16:02 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:16:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:16:02 --> Controller Class Initialized
DEBUG - 2021-12-13 02:16:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-13 02:16:02 --> Final output sent to browser
DEBUG - 2021-12-13 02:16:02 --> Total execution time: 0.0660
INFO - 2021-12-13 02:16:05 --> Config Class Initialized
INFO - 2021-12-13 02:16:05 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:16:05 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:16:05 --> Utf8 Class Initialized
INFO - 2021-12-13 02:16:05 --> URI Class Initialized
INFO - 2021-12-13 02:16:05 --> Router Class Initialized
INFO - 2021-12-13 02:16:05 --> Output Class Initialized
INFO - 2021-12-13 02:16:05 --> Security Class Initialized
DEBUG - 2021-12-13 02:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:16:05 --> Input Class Initialized
INFO - 2021-12-13 02:16:05 --> Language Class Initialized
INFO - 2021-12-13 02:16:05 --> Language Class Initialized
INFO - 2021-12-13 02:16:05 --> Config Class Initialized
INFO - 2021-12-13 02:16:05 --> Loader Class Initialized
INFO - 2021-12-13 02:16:05 --> Helper loaded: url_helper
INFO - 2021-12-13 02:16:05 --> Helper loaded: file_helper
INFO - 2021-12-13 02:16:05 --> Helper loaded: form_helper
INFO - 2021-12-13 02:16:05 --> Helper loaded: my_helper
INFO - 2021-12-13 02:16:05 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:16:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:16:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:16:05 --> Controller Class Initialized
DEBUG - 2021-12-13 02:16:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-13 02:16:05 --> Final output sent to browser
DEBUG - 2021-12-13 02:16:05 --> Total execution time: 0.0490
INFO - 2021-12-13 02:16:07 --> Config Class Initialized
INFO - 2021-12-13 02:16:07 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:16:07 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:16:07 --> Utf8 Class Initialized
INFO - 2021-12-13 02:16:07 --> URI Class Initialized
INFO - 2021-12-13 02:16:07 --> Router Class Initialized
INFO - 2021-12-13 02:16:07 --> Output Class Initialized
INFO - 2021-12-13 02:16:07 --> Security Class Initialized
DEBUG - 2021-12-13 02:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:16:07 --> Input Class Initialized
INFO - 2021-12-13 02:16:07 --> Language Class Initialized
INFO - 2021-12-13 02:16:07 --> Language Class Initialized
INFO - 2021-12-13 02:16:07 --> Config Class Initialized
INFO - 2021-12-13 02:16:07 --> Loader Class Initialized
INFO - 2021-12-13 02:16:07 --> Helper loaded: url_helper
INFO - 2021-12-13 02:16:07 --> Helper loaded: file_helper
INFO - 2021-12-13 02:16:07 --> Helper loaded: form_helper
INFO - 2021-12-13 02:16:07 --> Helper loaded: my_helper
INFO - 2021-12-13 02:16:07 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:16:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:16:07 --> Controller Class Initialized
DEBUG - 2021-12-13 02:16:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-13 02:16:07 --> Final output sent to browser
DEBUG - 2021-12-13 02:16:07 --> Total execution time: 0.0610
INFO - 2021-12-13 02:16:08 --> Config Class Initialized
INFO - 2021-12-13 02:16:08 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:16:08 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:16:08 --> Utf8 Class Initialized
INFO - 2021-12-13 02:16:08 --> URI Class Initialized
INFO - 2021-12-13 02:16:08 --> Router Class Initialized
INFO - 2021-12-13 02:16:08 --> Output Class Initialized
INFO - 2021-12-13 02:16:08 --> Security Class Initialized
DEBUG - 2021-12-13 02:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:16:08 --> Input Class Initialized
INFO - 2021-12-13 02:16:08 --> Language Class Initialized
INFO - 2021-12-13 02:16:08 --> Language Class Initialized
INFO - 2021-12-13 02:16:08 --> Config Class Initialized
INFO - 2021-12-13 02:16:08 --> Loader Class Initialized
INFO - 2021-12-13 02:16:08 --> Helper loaded: url_helper
INFO - 2021-12-13 02:16:08 --> Helper loaded: file_helper
INFO - 2021-12-13 02:16:08 --> Helper loaded: form_helper
INFO - 2021-12-13 02:16:08 --> Helper loaded: my_helper
INFO - 2021-12-13 02:16:08 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:16:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:16:08 --> Controller Class Initialized
DEBUG - 2021-12-13 02:16:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-13 02:16:08 --> Final output sent to browser
DEBUG - 2021-12-13 02:16:08 --> Total execution time: 0.0600
INFO - 2021-12-13 02:16:12 --> Config Class Initialized
INFO - 2021-12-13 02:16:12 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:16:12 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:16:12 --> Utf8 Class Initialized
INFO - 2021-12-13 02:16:12 --> URI Class Initialized
INFO - 2021-12-13 02:16:12 --> Router Class Initialized
INFO - 2021-12-13 02:16:12 --> Output Class Initialized
INFO - 2021-12-13 02:16:12 --> Security Class Initialized
DEBUG - 2021-12-13 02:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:16:12 --> Input Class Initialized
INFO - 2021-12-13 02:16:12 --> Language Class Initialized
INFO - 2021-12-13 02:16:12 --> Language Class Initialized
INFO - 2021-12-13 02:16:12 --> Config Class Initialized
INFO - 2021-12-13 02:16:12 --> Loader Class Initialized
INFO - 2021-12-13 02:16:12 --> Helper loaded: url_helper
INFO - 2021-12-13 02:16:12 --> Helper loaded: file_helper
INFO - 2021-12-13 02:16:12 --> Helper loaded: form_helper
INFO - 2021-12-13 02:16:12 --> Helper loaded: my_helper
INFO - 2021-12-13 02:16:12 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:16:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:16:12 --> Controller Class Initialized
DEBUG - 2021-12-13 02:16:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-13 02:16:12 --> Final output sent to browser
DEBUG - 2021-12-13 02:16:12 --> Total execution time: 0.0660
INFO - 2021-12-13 02:16:15 --> Config Class Initialized
INFO - 2021-12-13 02:16:15 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:16:15 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:16:15 --> Utf8 Class Initialized
INFO - 2021-12-13 02:16:15 --> URI Class Initialized
INFO - 2021-12-13 02:16:15 --> Router Class Initialized
INFO - 2021-12-13 02:16:15 --> Output Class Initialized
INFO - 2021-12-13 02:16:15 --> Security Class Initialized
DEBUG - 2021-12-13 02:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:16:15 --> Input Class Initialized
INFO - 2021-12-13 02:16:15 --> Language Class Initialized
INFO - 2021-12-13 02:16:15 --> Language Class Initialized
INFO - 2021-12-13 02:16:15 --> Config Class Initialized
INFO - 2021-12-13 02:16:15 --> Loader Class Initialized
INFO - 2021-12-13 02:16:15 --> Helper loaded: url_helper
INFO - 2021-12-13 02:16:15 --> Helper loaded: file_helper
INFO - 2021-12-13 02:16:15 --> Helper loaded: form_helper
INFO - 2021-12-13 02:16:15 --> Helper loaded: my_helper
INFO - 2021-12-13 02:16:15 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:16:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:16:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:16:15 --> Controller Class Initialized
DEBUG - 2021-12-13 02:16:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-13 02:16:15 --> Final output sent to browser
DEBUG - 2021-12-13 02:16:15 --> Total execution time: 0.0610
INFO - 2021-12-13 02:16:17 --> Config Class Initialized
INFO - 2021-12-13 02:16:17 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:16:17 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:16:17 --> Utf8 Class Initialized
INFO - 2021-12-13 02:16:17 --> URI Class Initialized
INFO - 2021-12-13 02:16:17 --> Router Class Initialized
INFO - 2021-12-13 02:16:17 --> Output Class Initialized
INFO - 2021-12-13 02:16:17 --> Security Class Initialized
DEBUG - 2021-12-13 02:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:16:17 --> Input Class Initialized
INFO - 2021-12-13 02:16:17 --> Language Class Initialized
INFO - 2021-12-13 02:16:17 --> Language Class Initialized
INFO - 2021-12-13 02:16:17 --> Config Class Initialized
INFO - 2021-12-13 02:16:17 --> Loader Class Initialized
INFO - 2021-12-13 02:16:17 --> Helper loaded: url_helper
INFO - 2021-12-13 02:16:17 --> Helper loaded: file_helper
INFO - 2021-12-13 02:16:17 --> Helper loaded: form_helper
INFO - 2021-12-13 02:16:17 --> Helper loaded: my_helper
INFO - 2021-12-13 02:16:17 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:16:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:16:17 --> Controller Class Initialized
DEBUG - 2021-12-13 02:16:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-13 02:16:17 --> Final output sent to browser
DEBUG - 2021-12-13 02:16:17 --> Total execution time: 0.0560
INFO - 2021-12-13 02:16:19 --> Config Class Initialized
INFO - 2021-12-13 02:16:19 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:16:19 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:16:19 --> Utf8 Class Initialized
INFO - 2021-12-13 02:16:19 --> URI Class Initialized
INFO - 2021-12-13 02:16:19 --> Router Class Initialized
INFO - 2021-12-13 02:16:19 --> Output Class Initialized
INFO - 2021-12-13 02:16:19 --> Security Class Initialized
DEBUG - 2021-12-13 02:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:16:19 --> Input Class Initialized
INFO - 2021-12-13 02:16:19 --> Language Class Initialized
INFO - 2021-12-13 02:16:19 --> Language Class Initialized
INFO - 2021-12-13 02:16:19 --> Config Class Initialized
INFO - 2021-12-13 02:16:19 --> Loader Class Initialized
INFO - 2021-12-13 02:16:19 --> Helper loaded: url_helper
INFO - 2021-12-13 02:16:19 --> Helper loaded: file_helper
INFO - 2021-12-13 02:16:19 --> Helper loaded: form_helper
INFO - 2021-12-13 02:16:19 --> Helper loaded: my_helper
INFO - 2021-12-13 02:16:19 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:16:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:16:19 --> Controller Class Initialized
DEBUG - 2021-12-13 02:16:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-13 02:16:19 --> Final output sent to browser
DEBUG - 2021-12-13 02:16:19 --> Total execution time: 0.0620
INFO - 2021-12-13 02:19:29 --> Config Class Initialized
INFO - 2021-12-13 02:19:29 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:19:29 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:19:29 --> Utf8 Class Initialized
INFO - 2021-12-13 02:19:29 --> URI Class Initialized
INFO - 2021-12-13 02:19:29 --> Router Class Initialized
INFO - 2021-12-13 02:19:29 --> Output Class Initialized
INFO - 2021-12-13 02:19:29 --> Security Class Initialized
DEBUG - 2021-12-13 02:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:19:29 --> Input Class Initialized
INFO - 2021-12-13 02:19:29 --> Language Class Initialized
INFO - 2021-12-13 02:19:29 --> Language Class Initialized
INFO - 2021-12-13 02:19:29 --> Config Class Initialized
INFO - 2021-12-13 02:19:29 --> Loader Class Initialized
INFO - 2021-12-13 02:19:29 --> Helper loaded: url_helper
INFO - 2021-12-13 02:19:29 --> Helper loaded: file_helper
INFO - 2021-12-13 02:19:29 --> Helper loaded: form_helper
INFO - 2021-12-13 02:19:29 --> Helper loaded: my_helper
INFO - 2021-12-13 02:19:29 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:19:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:19:29 --> Controller Class Initialized
INFO - 2021-12-13 02:19:29 --> Helper loaded: cookie_helper
INFO - 2021-12-13 02:19:29 --> Config Class Initialized
INFO - 2021-12-13 02:19:29 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:19:29 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:19:29 --> Utf8 Class Initialized
INFO - 2021-12-13 02:19:29 --> URI Class Initialized
INFO - 2021-12-13 02:19:29 --> Router Class Initialized
INFO - 2021-12-13 02:19:29 --> Output Class Initialized
INFO - 2021-12-13 02:19:29 --> Security Class Initialized
DEBUG - 2021-12-13 02:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:19:29 --> Input Class Initialized
INFO - 2021-12-13 02:19:29 --> Language Class Initialized
INFO - 2021-12-13 02:19:29 --> Language Class Initialized
INFO - 2021-12-13 02:19:29 --> Config Class Initialized
INFO - 2021-12-13 02:19:29 --> Loader Class Initialized
INFO - 2021-12-13 02:19:29 --> Helper loaded: url_helper
INFO - 2021-12-13 02:19:29 --> Helper loaded: file_helper
INFO - 2021-12-13 02:19:29 --> Helper loaded: form_helper
INFO - 2021-12-13 02:19:29 --> Helper loaded: my_helper
INFO - 2021-12-13 02:19:29 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:19:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:19:29 --> Controller Class Initialized
DEBUG - 2021-12-13 02:19:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-13 02:19:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 02:19:29 --> Final output sent to browser
DEBUG - 2021-12-13 02:19:29 --> Total execution time: 0.0460
INFO - 2021-12-13 02:19:36 --> Config Class Initialized
INFO - 2021-12-13 02:19:36 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:19:36 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:19:36 --> Utf8 Class Initialized
INFO - 2021-12-13 02:19:36 --> URI Class Initialized
INFO - 2021-12-13 02:19:36 --> Router Class Initialized
INFO - 2021-12-13 02:19:36 --> Output Class Initialized
INFO - 2021-12-13 02:19:36 --> Security Class Initialized
DEBUG - 2021-12-13 02:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:19:36 --> Input Class Initialized
INFO - 2021-12-13 02:19:36 --> Language Class Initialized
INFO - 2021-12-13 02:19:36 --> Language Class Initialized
INFO - 2021-12-13 02:19:36 --> Config Class Initialized
INFO - 2021-12-13 02:19:36 --> Loader Class Initialized
INFO - 2021-12-13 02:19:36 --> Helper loaded: url_helper
INFO - 2021-12-13 02:19:36 --> Helper loaded: file_helper
INFO - 2021-12-13 02:19:36 --> Helper loaded: form_helper
INFO - 2021-12-13 02:19:36 --> Helper loaded: my_helper
INFO - 2021-12-13 02:19:36 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:19:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:19:36 --> Controller Class Initialized
INFO - 2021-12-13 02:19:36 --> Helper loaded: cookie_helper
INFO - 2021-12-13 02:19:36 --> Final output sent to browser
DEBUG - 2021-12-13 02:19:36 --> Total execution time: 0.0520
INFO - 2021-12-13 02:19:36 --> Config Class Initialized
INFO - 2021-12-13 02:19:36 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:19:36 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:19:36 --> Utf8 Class Initialized
INFO - 2021-12-13 02:19:36 --> URI Class Initialized
INFO - 2021-12-13 02:19:36 --> Router Class Initialized
INFO - 2021-12-13 02:19:36 --> Output Class Initialized
INFO - 2021-12-13 02:19:36 --> Security Class Initialized
DEBUG - 2021-12-13 02:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:19:36 --> Input Class Initialized
INFO - 2021-12-13 02:19:36 --> Language Class Initialized
INFO - 2021-12-13 02:19:36 --> Language Class Initialized
INFO - 2021-12-13 02:19:36 --> Config Class Initialized
INFO - 2021-12-13 02:19:36 --> Loader Class Initialized
INFO - 2021-12-13 02:19:36 --> Helper loaded: url_helper
INFO - 2021-12-13 02:19:36 --> Helper loaded: file_helper
INFO - 2021-12-13 02:19:36 --> Helper loaded: form_helper
INFO - 2021-12-13 02:19:36 --> Helper loaded: my_helper
INFO - 2021-12-13 02:19:36 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:19:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:19:36 --> Controller Class Initialized
DEBUG - 2021-12-13 02:19:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-13 02:19:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 02:19:37 --> Final output sent to browser
DEBUG - 2021-12-13 02:19:37 --> Total execution time: 0.2280
INFO - 2021-12-13 02:19:38 --> Config Class Initialized
INFO - 2021-12-13 02:19:38 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:19:38 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:19:38 --> Utf8 Class Initialized
INFO - 2021-12-13 02:19:38 --> URI Class Initialized
INFO - 2021-12-13 02:19:38 --> Router Class Initialized
INFO - 2021-12-13 02:19:38 --> Output Class Initialized
INFO - 2021-12-13 02:19:38 --> Security Class Initialized
DEBUG - 2021-12-13 02:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:19:38 --> Input Class Initialized
INFO - 2021-12-13 02:19:38 --> Language Class Initialized
INFO - 2021-12-13 02:19:38 --> Language Class Initialized
INFO - 2021-12-13 02:19:38 --> Config Class Initialized
INFO - 2021-12-13 02:19:38 --> Loader Class Initialized
INFO - 2021-12-13 02:19:38 --> Helper loaded: url_helper
INFO - 2021-12-13 02:19:38 --> Helper loaded: file_helper
INFO - 2021-12-13 02:19:38 --> Helper loaded: form_helper
INFO - 2021-12-13 02:19:38 --> Helper loaded: my_helper
INFO - 2021-12-13 02:19:38 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:19:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:19:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:19:38 --> Controller Class Initialized
DEBUG - 2021-12-13 02:19:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-12-13 02:19:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 02:19:38 --> Final output sent to browser
DEBUG - 2021-12-13 02:19:38 --> Total execution time: 0.0490
INFO - 2021-12-13 02:19:38 --> Config Class Initialized
INFO - 2021-12-13 02:19:38 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:19:38 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:19:38 --> Utf8 Class Initialized
INFO - 2021-12-13 02:19:38 --> URI Class Initialized
INFO - 2021-12-13 02:19:38 --> Router Class Initialized
INFO - 2021-12-13 02:19:38 --> Output Class Initialized
INFO - 2021-12-13 02:19:38 --> Security Class Initialized
DEBUG - 2021-12-13 02:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:19:38 --> Input Class Initialized
INFO - 2021-12-13 02:19:38 --> Language Class Initialized
INFO - 2021-12-13 02:19:38 --> Language Class Initialized
INFO - 2021-12-13 02:19:38 --> Config Class Initialized
INFO - 2021-12-13 02:19:38 --> Loader Class Initialized
INFO - 2021-12-13 02:19:38 --> Helper loaded: url_helper
INFO - 2021-12-13 02:19:38 --> Helper loaded: file_helper
INFO - 2021-12-13 02:19:38 --> Helper loaded: form_helper
INFO - 2021-12-13 02:19:38 --> Helper loaded: my_helper
INFO - 2021-12-13 02:19:38 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:19:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:19:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:19:38 --> Controller Class Initialized
INFO - 2021-12-13 02:19:40 --> Config Class Initialized
INFO - 2021-12-13 02:19:40 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:19:40 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:19:40 --> Utf8 Class Initialized
INFO - 2021-12-13 02:19:40 --> URI Class Initialized
INFO - 2021-12-13 02:19:40 --> Router Class Initialized
INFO - 2021-12-13 02:19:40 --> Output Class Initialized
INFO - 2021-12-13 02:19:40 --> Security Class Initialized
DEBUG - 2021-12-13 02:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:19:40 --> Input Class Initialized
INFO - 2021-12-13 02:19:40 --> Language Class Initialized
INFO - 2021-12-13 02:19:40 --> Language Class Initialized
INFO - 2021-12-13 02:19:40 --> Config Class Initialized
INFO - 2021-12-13 02:19:40 --> Loader Class Initialized
INFO - 2021-12-13 02:19:40 --> Helper loaded: url_helper
INFO - 2021-12-13 02:19:40 --> Helper loaded: file_helper
INFO - 2021-12-13 02:19:40 --> Helper loaded: form_helper
INFO - 2021-12-13 02:19:40 --> Helper loaded: my_helper
INFO - 2021-12-13 02:19:40 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:19:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:19:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:19:40 --> Controller Class Initialized
INFO - 2021-12-13 02:19:40 --> Final output sent to browser
DEBUG - 2021-12-13 02:19:40 --> Total execution time: 0.0660
INFO - 2021-12-13 02:19:40 --> Config Class Initialized
INFO - 2021-12-13 02:19:40 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:19:40 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:19:40 --> Utf8 Class Initialized
INFO - 2021-12-13 02:19:40 --> URI Class Initialized
INFO - 2021-12-13 02:19:40 --> Router Class Initialized
INFO - 2021-12-13 02:19:40 --> Output Class Initialized
INFO - 2021-12-13 02:19:40 --> Security Class Initialized
DEBUG - 2021-12-13 02:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:19:40 --> Input Class Initialized
INFO - 2021-12-13 02:19:40 --> Language Class Initialized
INFO - 2021-12-13 02:19:40 --> Language Class Initialized
INFO - 2021-12-13 02:19:40 --> Config Class Initialized
INFO - 2021-12-13 02:19:40 --> Loader Class Initialized
INFO - 2021-12-13 02:19:40 --> Helper loaded: url_helper
INFO - 2021-12-13 02:19:40 --> Helper loaded: file_helper
INFO - 2021-12-13 02:19:40 --> Helper loaded: form_helper
INFO - 2021-12-13 02:19:40 --> Helper loaded: my_helper
INFO - 2021-12-13 02:19:40 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:19:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:19:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:19:40 --> Controller Class Initialized
INFO - 2021-12-13 02:19:43 --> Config Class Initialized
INFO - 2021-12-13 02:19:43 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:19:43 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:19:43 --> Utf8 Class Initialized
INFO - 2021-12-13 02:19:43 --> URI Class Initialized
INFO - 2021-12-13 02:19:43 --> Router Class Initialized
INFO - 2021-12-13 02:19:43 --> Output Class Initialized
INFO - 2021-12-13 02:19:43 --> Security Class Initialized
DEBUG - 2021-12-13 02:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:19:43 --> Input Class Initialized
INFO - 2021-12-13 02:19:43 --> Language Class Initialized
INFO - 2021-12-13 02:19:43 --> Language Class Initialized
INFO - 2021-12-13 02:19:43 --> Config Class Initialized
INFO - 2021-12-13 02:19:43 --> Loader Class Initialized
INFO - 2021-12-13 02:19:43 --> Helper loaded: url_helper
INFO - 2021-12-13 02:19:43 --> Helper loaded: file_helper
INFO - 2021-12-13 02:19:43 --> Helper loaded: form_helper
INFO - 2021-12-13 02:19:43 --> Helper loaded: my_helper
INFO - 2021-12-13 02:19:43 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:19:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:19:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:19:43 --> Controller Class Initialized
INFO - 2021-12-13 02:19:43 --> Helper loaded: cookie_helper
INFO - 2021-12-13 02:19:43 --> Config Class Initialized
INFO - 2021-12-13 02:19:43 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:19:43 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:19:43 --> Utf8 Class Initialized
INFO - 2021-12-13 02:19:43 --> URI Class Initialized
INFO - 2021-12-13 02:19:43 --> Router Class Initialized
INFO - 2021-12-13 02:19:43 --> Output Class Initialized
INFO - 2021-12-13 02:19:43 --> Security Class Initialized
DEBUG - 2021-12-13 02:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:19:43 --> Input Class Initialized
INFO - 2021-12-13 02:19:43 --> Language Class Initialized
INFO - 2021-12-13 02:19:43 --> Language Class Initialized
INFO - 2021-12-13 02:19:43 --> Config Class Initialized
INFO - 2021-12-13 02:19:43 --> Loader Class Initialized
INFO - 2021-12-13 02:19:43 --> Helper loaded: url_helper
INFO - 2021-12-13 02:19:43 --> Helper loaded: file_helper
INFO - 2021-12-13 02:19:43 --> Helper loaded: form_helper
INFO - 2021-12-13 02:19:43 --> Helper loaded: my_helper
INFO - 2021-12-13 02:19:43 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:19:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:19:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:19:43 --> Controller Class Initialized
DEBUG - 2021-12-13 02:19:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-13 02:19:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 02:19:43 --> Final output sent to browser
DEBUG - 2021-12-13 02:19:43 --> Total execution time: 0.0360
INFO - 2021-12-13 02:24:00 --> Config Class Initialized
INFO - 2021-12-13 02:24:00 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:24:00 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:24:00 --> Utf8 Class Initialized
INFO - 2021-12-13 02:24:00 --> URI Class Initialized
INFO - 2021-12-13 02:24:00 --> Router Class Initialized
INFO - 2021-12-13 02:24:00 --> Output Class Initialized
INFO - 2021-12-13 02:24:00 --> Security Class Initialized
DEBUG - 2021-12-13 02:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:24:00 --> Input Class Initialized
INFO - 2021-12-13 02:24:00 --> Language Class Initialized
INFO - 2021-12-13 02:24:00 --> Language Class Initialized
INFO - 2021-12-13 02:24:00 --> Config Class Initialized
INFO - 2021-12-13 02:24:00 --> Loader Class Initialized
INFO - 2021-12-13 02:24:00 --> Helper loaded: url_helper
INFO - 2021-12-13 02:24:00 --> Helper loaded: file_helper
INFO - 2021-12-13 02:24:00 --> Helper loaded: form_helper
INFO - 2021-12-13 02:24:00 --> Helper loaded: my_helper
INFO - 2021-12-13 02:24:00 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:24:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:24:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:24:00 --> Controller Class Initialized
INFO - 2021-12-13 02:24:00 --> Helper loaded: cookie_helper
INFO - 2021-12-13 02:24:00 --> Final output sent to browser
DEBUG - 2021-12-13 02:24:00 --> Total execution time: 0.0700
INFO - 2021-12-13 02:24:01 --> Config Class Initialized
INFO - 2021-12-13 02:24:01 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:24:01 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:24:01 --> Utf8 Class Initialized
INFO - 2021-12-13 02:24:01 --> URI Class Initialized
INFO - 2021-12-13 02:24:01 --> Router Class Initialized
INFO - 2021-12-13 02:24:01 --> Output Class Initialized
INFO - 2021-12-13 02:24:01 --> Security Class Initialized
DEBUG - 2021-12-13 02:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:24:01 --> Input Class Initialized
INFO - 2021-12-13 02:24:01 --> Language Class Initialized
INFO - 2021-12-13 02:24:01 --> Language Class Initialized
INFO - 2021-12-13 02:24:01 --> Config Class Initialized
INFO - 2021-12-13 02:24:01 --> Loader Class Initialized
INFO - 2021-12-13 02:24:01 --> Helper loaded: url_helper
INFO - 2021-12-13 02:24:01 --> Helper loaded: file_helper
INFO - 2021-12-13 02:24:01 --> Helper loaded: form_helper
INFO - 2021-12-13 02:24:01 --> Helper loaded: my_helper
INFO - 2021-12-13 02:24:01 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:24:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:24:01 --> Controller Class Initialized
DEBUG - 2021-12-13 02:24:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-13 02:24:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 02:24:01 --> Final output sent to browser
DEBUG - 2021-12-13 02:24:01 --> Total execution time: 0.1690
INFO - 2021-12-13 02:24:15 --> Config Class Initialized
INFO - 2021-12-13 02:24:15 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:24:15 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:24:15 --> Utf8 Class Initialized
INFO - 2021-12-13 02:24:15 --> URI Class Initialized
INFO - 2021-12-13 02:24:15 --> Router Class Initialized
INFO - 2021-12-13 02:24:15 --> Output Class Initialized
INFO - 2021-12-13 02:24:15 --> Security Class Initialized
DEBUG - 2021-12-13 02:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:24:15 --> Input Class Initialized
INFO - 2021-12-13 02:24:15 --> Language Class Initialized
INFO - 2021-12-13 02:24:15 --> Language Class Initialized
INFO - 2021-12-13 02:24:15 --> Config Class Initialized
INFO - 2021-12-13 02:24:15 --> Loader Class Initialized
INFO - 2021-12-13 02:24:15 --> Helper loaded: url_helper
INFO - 2021-12-13 02:24:15 --> Helper loaded: file_helper
INFO - 2021-12-13 02:24:15 --> Helper loaded: form_helper
INFO - 2021-12-13 02:24:15 --> Helper loaded: my_helper
INFO - 2021-12-13 02:24:15 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:24:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:24:15 --> Controller Class Initialized
DEBUG - 2021-12-13 02:24:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-13 02:24:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 02:24:15 --> Final output sent to browser
DEBUG - 2021-12-13 02:24:15 --> Total execution time: 0.0470
INFO - 2021-12-13 02:24:20 --> Config Class Initialized
INFO - 2021-12-13 02:24:20 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:24:20 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:24:20 --> Utf8 Class Initialized
INFO - 2021-12-13 02:24:20 --> URI Class Initialized
INFO - 2021-12-13 02:24:20 --> Router Class Initialized
INFO - 2021-12-13 02:24:20 --> Output Class Initialized
INFO - 2021-12-13 02:24:20 --> Security Class Initialized
DEBUG - 2021-12-13 02:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:24:20 --> Input Class Initialized
INFO - 2021-12-13 02:24:20 --> Language Class Initialized
INFO - 2021-12-13 02:24:20 --> Language Class Initialized
INFO - 2021-12-13 02:24:20 --> Config Class Initialized
INFO - 2021-12-13 02:24:20 --> Loader Class Initialized
INFO - 2021-12-13 02:24:20 --> Helper loaded: url_helper
INFO - 2021-12-13 02:24:20 --> Helper loaded: file_helper
INFO - 2021-12-13 02:24:20 --> Helper loaded: form_helper
INFO - 2021-12-13 02:24:20 --> Helper loaded: my_helper
INFO - 2021-12-13 02:24:20 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:24:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:24:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:24:20 --> Controller Class Initialized
DEBUG - 2021-12-13 02:24:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:24:20 --> Final output sent to browser
DEBUG - 2021-12-13 02:24:20 --> Total execution time: 0.0940
INFO - 2021-12-13 02:24:22 --> Config Class Initialized
INFO - 2021-12-13 02:24:22 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:24:22 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:24:22 --> Utf8 Class Initialized
INFO - 2021-12-13 02:24:22 --> URI Class Initialized
INFO - 2021-12-13 02:24:22 --> Router Class Initialized
INFO - 2021-12-13 02:24:22 --> Output Class Initialized
INFO - 2021-12-13 02:24:22 --> Security Class Initialized
DEBUG - 2021-12-13 02:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:24:22 --> Input Class Initialized
INFO - 2021-12-13 02:24:22 --> Language Class Initialized
INFO - 2021-12-13 02:24:22 --> Language Class Initialized
INFO - 2021-12-13 02:24:22 --> Config Class Initialized
INFO - 2021-12-13 02:24:22 --> Loader Class Initialized
INFO - 2021-12-13 02:24:22 --> Helper loaded: url_helper
INFO - 2021-12-13 02:24:22 --> Helper loaded: file_helper
INFO - 2021-12-13 02:24:22 --> Helper loaded: form_helper
INFO - 2021-12-13 02:24:22 --> Helper loaded: my_helper
INFO - 2021-12-13 02:24:22 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:24:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:24:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:24:22 --> Controller Class Initialized
DEBUG - 2021-12-13 02:24:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:24:22 --> Final output sent to browser
DEBUG - 2021-12-13 02:24:22 --> Total execution time: 0.0650
INFO - 2021-12-13 02:24:23 --> Config Class Initialized
INFO - 2021-12-13 02:24:23 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:24:23 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:24:23 --> Utf8 Class Initialized
INFO - 2021-12-13 02:24:23 --> URI Class Initialized
INFO - 2021-12-13 02:24:23 --> Router Class Initialized
INFO - 2021-12-13 02:24:23 --> Output Class Initialized
INFO - 2021-12-13 02:24:23 --> Security Class Initialized
DEBUG - 2021-12-13 02:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:24:23 --> Input Class Initialized
INFO - 2021-12-13 02:24:23 --> Language Class Initialized
INFO - 2021-12-13 02:24:23 --> Language Class Initialized
INFO - 2021-12-13 02:24:23 --> Config Class Initialized
INFO - 2021-12-13 02:24:23 --> Loader Class Initialized
INFO - 2021-12-13 02:24:23 --> Helper loaded: url_helper
INFO - 2021-12-13 02:24:23 --> Helper loaded: file_helper
INFO - 2021-12-13 02:24:23 --> Helper loaded: form_helper
INFO - 2021-12-13 02:24:23 --> Helper loaded: my_helper
INFO - 2021-12-13 02:24:23 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:24:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:24:23 --> Controller Class Initialized
DEBUG - 2021-12-13 02:24:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:24:23 --> Final output sent to browser
DEBUG - 2021-12-13 02:24:23 --> Total execution time: 0.0610
INFO - 2021-12-13 02:24:26 --> Config Class Initialized
INFO - 2021-12-13 02:24:26 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:24:26 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:24:26 --> Utf8 Class Initialized
INFO - 2021-12-13 02:24:26 --> URI Class Initialized
INFO - 2021-12-13 02:24:26 --> Router Class Initialized
INFO - 2021-12-13 02:24:26 --> Output Class Initialized
INFO - 2021-12-13 02:24:26 --> Security Class Initialized
DEBUG - 2021-12-13 02:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:24:26 --> Input Class Initialized
INFO - 2021-12-13 02:24:26 --> Language Class Initialized
INFO - 2021-12-13 02:24:26 --> Language Class Initialized
INFO - 2021-12-13 02:24:26 --> Config Class Initialized
INFO - 2021-12-13 02:24:26 --> Loader Class Initialized
INFO - 2021-12-13 02:24:26 --> Helper loaded: url_helper
INFO - 2021-12-13 02:24:26 --> Helper loaded: file_helper
INFO - 2021-12-13 02:24:26 --> Helper loaded: form_helper
INFO - 2021-12-13 02:24:26 --> Helper loaded: my_helper
INFO - 2021-12-13 02:24:26 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:24:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:24:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:24:26 --> Controller Class Initialized
DEBUG - 2021-12-13 02:24:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:24:26 --> Final output sent to browser
DEBUG - 2021-12-13 02:24:26 --> Total execution time: 0.0650
INFO - 2021-12-13 02:24:27 --> Config Class Initialized
INFO - 2021-12-13 02:24:27 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:24:27 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:24:27 --> Utf8 Class Initialized
INFO - 2021-12-13 02:24:27 --> URI Class Initialized
INFO - 2021-12-13 02:24:27 --> Router Class Initialized
INFO - 2021-12-13 02:24:27 --> Output Class Initialized
INFO - 2021-12-13 02:24:27 --> Security Class Initialized
DEBUG - 2021-12-13 02:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:24:27 --> Input Class Initialized
INFO - 2021-12-13 02:24:27 --> Language Class Initialized
INFO - 2021-12-13 02:24:27 --> Language Class Initialized
INFO - 2021-12-13 02:24:27 --> Config Class Initialized
INFO - 2021-12-13 02:24:27 --> Loader Class Initialized
INFO - 2021-12-13 02:24:27 --> Helper loaded: url_helper
INFO - 2021-12-13 02:24:27 --> Helper loaded: file_helper
INFO - 2021-12-13 02:24:27 --> Helper loaded: form_helper
INFO - 2021-12-13 02:24:27 --> Helper loaded: my_helper
INFO - 2021-12-13 02:24:27 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:24:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:24:27 --> Controller Class Initialized
DEBUG - 2021-12-13 02:24:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:24:27 --> Final output sent to browser
DEBUG - 2021-12-13 02:24:27 --> Total execution time: 0.0690
INFO - 2021-12-13 02:24:31 --> Config Class Initialized
INFO - 2021-12-13 02:24:31 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:24:31 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:24:31 --> Utf8 Class Initialized
INFO - 2021-12-13 02:24:31 --> URI Class Initialized
INFO - 2021-12-13 02:24:31 --> Router Class Initialized
INFO - 2021-12-13 02:24:31 --> Output Class Initialized
INFO - 2021-12-13 02:24:31 --> Security Class Initialized
DEBUG - 2021-12-13 02:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:24:31 --> Input Class Initialized
INFO - 2021-12-13 02:24:31 --> Language Class Initialized
INFO - 2021-12-13 02:24:31 --> Language Class Initialized
INFO - 2021-12-13 02:24:31 --> Config Class Initialized
INFO - 2021-12-13 02:24:31 --> Loader Class Initialized
INFO - 2021-12-13 02:24:31 --> Helper loaded: url_helper
INFO - 2021-12-13 02:24:31 --> Helper loaded: file_helper
INFO - 2021-12-13 02:24:31 --> Helper loaded: form_helper
INFO - 2021-12-13 02:24:31 --> Helper loaded: my_helper
INFO - 2021-12-13 02:24:31 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:24:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:24:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:24:31 --> Controller Class Initialized
DEBUG - 2021-12-13 02:24:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:24:31 --> Final output sent to browser
DEBUG - 2021-12-13 02:24:31 --> Total execution time: 0.0600
INFO - 2021-12-13 02:24:32 --> Config Class Initialized
INFO - 2021-12-13 02:24:32 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:24:32 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:24:32 --> Utf8 Class Initialized
INFO - 2021-12-13 02:24:32 --> URI Class Initialized
INFO - 2021-12-13 02:24:32 --> Router Class Initialized
INFO - 2021-12-13 02:24:32 --> Output Class Initialized
INFO - 2021-12-13 02:24:32 --> Security Class Initialized
DEBUG - 2021-12-13 02:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:24:32 --> Input Class Initialized
INFO - 2021-12-13 02:24:32 --> Language Class Initialized
INFO - 2021-12-13 02:24:32 --> Language Class Initialized
INFO - 2021-12-13 02:24:32 --> Config Class Initialized
INFO - 2021-12-13 02:24:32 --> Loader Class Initialized
INFO - 2021-12-13 02:24:32 --> Helper loaded: url_helper
INFO - 2021-12-13 02:24:32 --> Helper loaded: file_helper
INFO - 2021-12-13 02:24:32 --> Helper loaded: form_helper
INFO - 2021-12-13 02:24:32 --> Helper loaded: my_helper
INFO - 2021-12-13 02:24:32 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:24:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:24:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:24:32 --> Controller Class Initialized
DEBUG - 2021-12-13 02:24:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:24:32 --> Final output sent to browser
DEBUG - 2021-12-13 02:24:32 --> Total execution time: 0.0660
INFO - 2021-12-13 02:24:33 --> Config Class Initialized
INFO - 2021-12-13 02:24:33 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:24:33 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:24:33 --> Utf8 Class Initialized
INFO - 2021-12-13 02:24:33 --> URI Class Initialized
INFO - 2021-12-13 02:24:33 --> Router Class Initialized
INFO - 2021-12-13 02:24:33 --> Output Class Initialized
INFO - 2021-12-13 02:24:33 --> Security Class Initialized
DEBUG - 2021-12-13 02:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:24:33 --> Input Class Initialized
INFO - 2021-12-13 02:24:33 --> Language Class Initialized
INFO - 2021-12-13 02:24:33 --> Language Class Initialized
INFO - 2021-12-13 02:24:33 --> Config Class Initialized
INFO - 2021-12-13 02:24:33 --> Loader Class Initialized
INFO - 2021-12-13 02:24:33 --> Helper loaded: url_helper
INFO - 2021-12-13 02:24:33 --> Helper loaded: file_helper
INFO - 2021-12-13 02:24:33 --> Helper loaded: form_helper
INFO - 2021-12-13 02:24:33 --> Helper loaded: my_helper
INFO - 2021-12-13 02:24:33 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:24:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:24:33 --> Controller Class Initialized
DEBUG - 2021-12-13 02:24:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:24:33 --> Final output sent to browser
DEBUG - 2021-12-13 02:24:33 --> Total execution time: 0.0690
INFO - 2021-12-13 02:24:36 --> Config Class Initialized
INFO - 2021-12-13 02:24:36 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:24:36 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:24:36 --> Utf8 Class Initialized
INFO - 2021-12-13 02:24:36 --> URI Class Initialized
INFO - 2021-12-13 02:24:36 --> Router Class Initialized
INFO - 2021-12-13 02:24:36 --> Output Class Initialized
INFO - 2021-12-13 02:24:36 --> Security Class Initialized
DEBUG - 2021-12-13 02:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:24:36 --> Input Class Initialized
INFO - 2021-12-13 02:24:36 --> Language Class Initialized
INFO - 2021-12-13 02:24:36 --> Language Class Initialized
INFO - 2021-12-13 02:24:36 --> Config Class Initialized
INFO - 2021-12-13 02:24:36 --> Loader Class Initialized
INFO - 2021-12-13 02:24:36 --> Helper loaded: url_helper
INFO - 2021-12-13 02:24:36 --> Helper loaded: file_helper
INFO - 2021-12-13 02:24:36 --> Helper loaded: form_helper
INFO - 2021-12-13 02:24:36 --> Helper loaded: my_helper
INFO - 2021-12-13 02:24:36 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:24:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:24:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:24:36 --> Controller Class Initialized
DEBUG - 2021-12-13 02:24:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:24:36 --> Final output sent to browser
DEBUG - 2021-12-13 02:24:36 --> Total execution time: 0.0690
INFO - 2021-12-13 02:24:37 --> Config Class Initialized
INFO - 2021-12-13 02:24:37 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:24:37 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:24:37 --> Utf8 Class Initialized
INFO - 2021-12-13 02:24:37 --> URI Class Initialized
INFO - 2021-12-13 02:24:37 --> Router Class Initialized
INFO - 2021-12-13 02:24:37 --> Output Class Initialized
INFO - 2021-12-13 02:24:37 --> Security Class Initialized
DEBUG - 2021-12-13 02:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:24:37 --> Input Class Initialized
INFO - 2021-12-13 02:24:37 --> Language Class Initialized
INFO - 2021-12-13 02:24:37 --> Language Class Initialized
INFO - 2021-12-13 02:24:37 --> Config Class Initialized
INFO - 2021-12-13 02:24:37 --> Loader Class Initialized
INFO - 2021-12-13 02:24:37 --> Helper loaded: url_helper
INFO - 2021-12-13 02:24:37 --> Helper loaded: file_helper
INFO - 2021-12-13 02:24:37 --> Helper loaded: form_helper
INFO - 2021-12-13 02:24:37 --> Helper loaded: my_helper
INFO - 2021-12-13 02:24:37 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:24:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:24:37 --> Controller Class Initialized
DEBUG - 2021-12-13 02:24:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:24:37 --> Final output sent to browser
DEBUG - 2021-12-13 02:24:37 --> Total execution time: 0.0700
INFO - 2021-12-13 02:25:12 --> Config Class Initialized
INFO - 2021-12-13 02:25:12 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:25:12 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:25:12 --> Utf8 Class Initialized
INFO - 2021-12-13 02:25:12 --> URI Class Initialized
INFO - 2021-12-13 02:25:12 --> Router Class Initialized
INFO - 2021-12-13 02:25:12 --> Output Class Initialized
INFO - 2021-12-13 02:25:12 --> Security Class Initialized
DEBUG - 2021-12-13 02:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:25:12 --> Input Class Initialized
INFO - 2021-12-13 02:25:12 --> Language Class Initialized
INFO - 2021-12-13 02:25:12 --> Language Class Initialized
INFO - 2021-12-13 02:25:12 --> Config Class Initialized
INFO - 2021-12-13 02:25:12 --> Loader Class Initialized
INFO - 2021-12-13 02:25:12 --> Helper loaded: url_helper
INFO - 2021-12-13 02:25:12 --> Helper loaded: file_helper
INFO - 2021-12-13 02:25:12 --> Helper loaded: form_helper
INFO - 2021-12-13 02:25:12 --> Helper loaded: my_helper
INFO - 2021-12-13 02:25:12 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:25:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:25:12 --> Controller Class Initialized
DEBUG - 2021-12-13 02:25:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:25:12 --> Final output sent to browser
DEBUG - 2021-12-13 02:25:12 --> Total execution time: 0.0720
INFO - 2021-12-13 02:25:14 --> Config Class Initialized
INFO - 2021-12-13 02:25:14 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:25:14 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:25:14 --> Utf8 Class Initialized
INFO - 2021-12-13 02:25:14 --> URI Class Initialized
INFO - 2021-12-13 02:25:14 --> Router Class Initialized
INFO - 2021-12-13 02:25:14 --> Output Class Initialized
INFO - 2021-12-13 02:25:14 --> Security Class Initialized
DEBUG - 2021-12-13 02:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:25:14 --> Input Class Initialized
INFO - 2021-12-13 02:25:14 --> Language Class Initialized
INFO - 2021-12-13 02:25:14 --> Language Class Initialized
INFO - 2021-12-13 02:25:14 --> Config Class Initialized
INFO - 2021-12-13 02:25:14 --> Loader Class Initialized
INFO - 2021-12-13 02:25:14 --> Helper loaded: url_helper
INFO - 2021-12-13 02:25:14 --> Helper loaded: file_helper
INFO - 2021-12-13 02:25:14 --> Helper loaded: form_helper
INFO - 2021-12-13 02:25:14 --> Helper loaded: my_helper
INFO - 2021-12-13 02:25:14 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:25:14 --> Controller Class Initialized
DEBUG - 2021-12-13 02:25:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:25:14 --> Final output sent to browser
DEBUG - 2021-12-13 02:25:14 --> Total execution time: 0.0600
INFO - 2021-12-13 02:25:18 --> Config Class Initialized
INFO - 2021-12-13 02:25:18 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:25:18 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:25:18 --> Utf8 Class Initialized
INFO - 2021-12-13 02:25:18 --> URI Class Initialized
INFO - 2021-12-13 02:25:18 --> Router Class Initialized
INFO - 2021-12-13 02:25:18 --> Output Class Initialized
INFO - 2021-12-13 02:25:18 --> Security Class Initialized
DEBUG - 2021-12-13 02:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:25:18 --> Input Class Initialized
INFO - 2021-12-13 02:25:18 --> Language Class Initialized
INFO - 2021-12-13 02:25:18 --> Language Class Initialized
INFO - 2021-12-13 02:25:18 --> Config Class Initialized
INFO - 2021-12-13 02:25:18 --> Loader Class Initialized
INFO - 2021-12-13 02:25:18 --> Helper loaded: url_helper
INFO - 2021-12-13 02:25:18 --> Helper loaded: file_helper
INFO - 2021-12-13 02:25:18 --> Helper loaded: form_helper
INFO - 2021-12-13 02:25:18 --> Helper loaded: my_helper
INFO - 2021-12-13 02:25:18 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:25:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:25:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:25:18 --> Controller Class Initialized
DEBUG - 2021-12-13 02:25:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:25:18 --> Final output sent to browser
DEBUG - 2021-12-13 02:25:18 --> Total execution time: 0.0650
INFO - 2021-12-13 02:25:23 --> Config Class Initialized
INFO - 2021-12-13 02:25:23 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:25:23 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:25:23 --> Utf8 Class Initialized
INFO - 2021-12-13 02:25:23 --> URI Class Initialized
INFO - 2021-12-13 02:25:23 --> Router Class Initialized
INFO - 2021-12-13 02:25:23 --> Output Class Initialized
INFO - 2021-12-13 02:25:23 --> Security Class Initialized
DEBUG - 2021-12-13 02:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:25:23 --> Input Class Initialized
INFO - 2021-12-13 02:25:23 --> Language Class Initialized
INFO - 2021-12-13 02:25:23 --> Language Class Initialized
INFO - 2021-12-13 02:25:23 --> Config Class Initialized
INFO - 2021-12-13 02:25:23 --> Loader Class Initialized
INFO - 2021-12-13 02:25:23 --> Helper loaded: url_helper
INFO - 2021-12-13 02:25:23 --> Helper loaded: file_helper
INFO - 2021-12-13 02:25:23 --> Helper loaded: form_helper
INFO - 2021-12-13 02:25:23 --> Helper loaded: my_helper
INFO - 2021-12-13 02:25:23 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:25:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:25:24 --> Controller Class Initialized
DEBUG - 2021-12-13 02:25:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:25:24 --> Final output sent to browser
DEBUG - 2021-12-13 02:25:24 --> Total execution time: 0.0710
INFO - 2021-12-13 02:25:25 --> Config Class Initialized
INFO - 2021-12-13 02:25:25 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:25:25 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:25:25 --> Utf8 Class Initialized
INFO - 2021-12-13 02:25:25 --> URI Class Initialized
INFO - 2021-12-13 02:25:25 --> Router Class Initialized
INFO - 2021-12-13 02:25:25 --> Output Class Initialized
INFO - 2021-12-13 02:25:25 --> Security Class Initialized
DEBUG - 2021-12-13 02:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:25:25 --> Input Class Initialized
INFO - 2021-12-13 02:25:25 --> Language Class Initialized
INFO - 2021-12-13 02:25:25 --> Language Class Initialized
INFO - 2021-12-13 02:25:25 --> Config Class Initialized
INFO - 2021-12-13 02:25:25 --> Loader Class Initialized
INFO - 2021-12-13 02:25:25 --> Helper loaded: url_helper
INFO - 2021-12-13 02:25:25 --> Helper loaded: file_helper
INFO - 2021-12-13 02:25:25 --> Helper loaded: form_helper
INFO - 2021-12-13 02:25:25 --> Helper loaded: my_helper
INFO - 2021-12-13 02:25:25 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:25:25 --> Controller Class Initialized
DEBUG - 2021-12-13 02:25:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:25:26 --> Final output sent to browser
DEBUG - 2021-12-13 02:25:26 --> Total execution time: 0.0560
INFO - 2021-12-13 02:25:27 --> Config Class Initialized
INFO - 2021-12-13 02:25:27 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:25:27 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:25:27 --> Utf8 Class Initialized
INFO - 2021-12-13 02:25:27 --> URI Class Initialized
INFO - 2021-12-13 02:25:27 --> Router Class Initialized
INFO - 2021-12-13 02:25:27 --> Output Class Initialized
INFO - 2021-12-13 02:25:27 --> Security Class Initialized
DEBUG - 2021-12-13 02:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:25:27 --> Input Class Initialized
INFO - 2021-12-13 02:25:27 --> Language Class Initialized
INFO - 2021-12-13 02:25:27 --> Language Class Initialized
INFO - 2021-12-13 02:25:27 --> Config Class Initialized
INFO - 2021-12-13 02:25:27 --> Loader Class Initialized
INFO - 2021-12-13 02:25:27 --> Helper loaded: url_helper
INFO - 2021-12-13 02:25:27 --> Helper loaded: file_helper
INFO - 2021-12-13 02:25:27 --> Helper loaded: form_helper
INFO - 2021-12-13 02:25:27 --> Helper loaded: my_helper
INFO - 2021-12-13 02:25:27 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:25:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:25:27 --> Controller Class Initialized
DEBUG - 2021-12-13 02:25:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:25:27 --> Final output sent to browser
DEBUG - 2021-12-13 02:25:27 --> Total execution time: 0.0570
INFO - 2021-12-13 02:25:30 --> Config Class Initialized
INFO - 2021-12-13 02:25:30 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:25:30 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:25:30 --> Utf8 Class Initialized
INFO - 2021-12-13 02:25:30 --> URI Class Initialized
INFO - 2021-12-13 02:25:30 --> Router Class Initialized
INFO - 2021-12-13 02:25:30 --> Output Class Initialized
INFO - 2021-12-13 02:25:30 --> Security Class Initialized
DEBUG - 2021-12-13 02:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:25:30 --> Input Class Initialized
INFO - 2021-12-13 02:25:30 --> Language Class Initialized
INFO - 2021-12-13 02:25:30 --> Language Class Initialized
INFO - 2021-12-13 02:25:30 --> Config Class Initialized
INFO - 2021-12-13 02:25:30 --> Loader Class Initialized
INFO - 2021-12-13 02:25:30 --> Helper loaded: url_helper
INFO - 2021-12-13 02:25:30 --> Helper loaded: file_helper
INFO - 2021-12-13 02:25:30 --> Helper loaded: form_helper
INFO - 2021-12-13 02:25:30 --> Helper loaded: my_helper
INFO - 2021-12-13 02:25:30 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:25:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:25:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:25:30 --> Controller Class Initialized
DEBUG - 2021-12-13 02:25:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:25:30 --> Final output sent to browser
DEBUG - 2021-12-13 02:25:30 --> Total execution time: 0.0680
INFO - 2021-12-13 02:25:32 --> Config Class Initialized
INFO - 2021-12-13 02:25:32 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:25:32 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:25:32 --> Utf8 Class Initialized
INFO - 2021-12-13 02:25:32 --> URI Class Initialized
INFO - 2021-12-13 02:25:32 --> Router Class Initialized
INFO - 2021-12-13 02:25:32 --> Output Class Initialized
INFO - 2021-12-13 02:25:32 --> Security Class Initialized
DEBUG - 2021-12-13 02:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:25:32 --> Input Class Initialized
INFO - 2021-12-13 02:25:32 --> Language Class Initialized
INFO - 2021-12-13 02:25:32 --> Language Class Initialized
INFO - 2021-12-13 02:25:32 --> Config Class Initialized
INFO - 2021-12-13 02:25:32 --> Loader Class Initialized
INFO - 2021-12-13 02:25:32 --> Helper loaded: url_helper
INFO - 2021-12-13 02:25:32 --> Helper loaded: file_helper
INFO - 2021-12-13 02:25:32 --> Helper loaded: form_helper
INFO - 2021-12-13 02:25:32 --> Helper loaded: my_helper
INFO - 2021-12-13 02:25:32 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:25:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:25:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:25:32 --> Controller Class Initialized
DEBUG - 2021-12-13 02:25:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:25:32 --> Final output sent to browser
DEBUG - 2021-12-13 02:25:32 --> Total execution time: 0.0640
INFO - 2021-12-13 02:25:34 --> Config Class Initialized
INFO - 2021-12-13 02:25:34 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:25:34 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:25:34 --> Utf8 Class Initialized
INFO - 2021-12-13 02:25:34 --> URI Class Initialized
INFO - 2021-12-13 02:25:34 --> Router Class Initialized
INFO - 2021-12-13 02:25:34 --> Output Class Initialized
INFO - 2021-12-13 02:25:34 --> Security Class Initialized
DEBUG - 2021-12-13 02:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:25:34 --> Input Class Initialized
INFO - 2021-12-13 02:25:34 --> Language Class Initialized
INFO - 2021-12-13 02:25:34 --> Language Class Initialized
INFO - 2021-12-13 02:25:34 --> Config Class Initialized
INFO - 2021-12-13 02:25:34 --> Loader Class Initialized
INFO - 2021-12-13 02:25:34 --> Helper loaded: url_helper
INFO - 2021-12-13 02:25:34 --> Helper loaded: file_helper
INFO - 2021-12-13 02:25:34 --> Helper loaded: form_helper
INFO - 2021-12-13 02:25:34 --> Helper loaded: my_helper
INFO - 2021-12-13 02:25:34 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:25:34 --> Controller Class Initialized
DEBUG - 2021-12-13 02:25:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:25:34 --> Final output sent to browser
DEBUG - 2021-12-13 02:25:34 --> Total execution time: 0.0730
INFO - 2021-12-13 02:25:37 --> Config Class Initialized
INFO - 2021-12-13 02:25:37 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:25:37 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:25:37 --> Utf8 Class Initialized
INFO - 2021-12-13 02:25:37 --> URI Class Initialized
INFO - 2021-12-13 02:25:37 --> Router Class Initialized
INFO - 2021-12-13 02:25:37 --> Output Class Initialized
INFO - 2021-12-13 02:25:37 --> Security Class Initialized
DEBUG - 2021-12-13 02:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:25:37 --> Input Class Initialized
INFO - 2021-12-13 02:25:37 --> Language Class Initialized
INFO - 2021-12-13 02:25:37 --> Language Class Initialized
INFO - 2021-12-13 02:25:37 --> Config Class Initialized
INFO - 2021-12-13 02:25:37 --> Loader Class Initialized
INFO - 2021-12-13 02:25:37 --> Helper loaded: url_helper
INFO - 2021-12-13 02:25:37 --> Helper loaded: file_helper
INFO - 2021-12-13 02:25:37 --> Helper loaded: form_helper
INFO - 2021-12-13 02:25:37 --> Helper loaded: my_helper
INFO - 2021-12-13 02:25:37 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:25:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:25:37 --> Controller Class Initialized
DEBUG - 2021-12-13 02:25:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:25:37 --> Final output sent to browser
DEBUG - 2021-12-13 02:25:37 --> Total execution time: 0.0610
INFO - 2021-12-13 02:25:39 --> Config Class Initialized
INFO - 2021-12-13 02:25:39 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:25:39 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:25:39 --> Utf8 Class Initialized
INFO - 2021-12-13 02:25:39 --> URI Class Initialized
INFO - 2021-12-13 02:25:39 --> Router Class Initialized
INFO - 2021-12-13 02:25:39 --> Output Class Initialized
INFO - 2021-12-13 02:25:39 --> Security Class Initialized
DEBUG - 2021-12-13 02:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:25:39 --> Input Class Initialized
INFO - 2021-12-13 02:25:39 --> Language Class Initialized
INFO - 2021-12-13 02:25:39 --> Language Class Initialized
INFO - 2021-12-13 02:25:39 --> Config Class Initialized
INFO - 2021-12-13 02:25:39 --> Loader Class Initialized
INFO - 2021-12-13 02:25:39 --> Helper loaded: url_helper
INFO - 2021-12-13 02:25:39 --> Helper loaded: file_helper
INFO - 2021-12-13 02:25:39 --> Helper loaded: form_helper
INFO - 2021-12-13 02:25:39 --> Helper loaded: my_helper
INFO - 2021-12-13 02:25:39 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:25:39 --> Controller Class Initialized
DEBUG - 2021-12-13 02:25:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:25:39 --> Final output sent to browser
DEBUG - 2021-12-13 02:25:39 --> Total execution time: 0.0570
INFO - 2021-12-13 02:25:41 --> Config Class Initialized
INFO - 2021-12-13 02:25:41 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:25:41 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:25:41 --> Utf8 Class Initialized
INFO - 2021-12-13 02:25:41 --> URI Class Initialized
INFO - 2021-12-13 02:25:41 --> Router Class Initialized
INFO - 2021-12-13 02:25:41 --> Output Class Initialized
INFO - 2021-12-13 02:25:41 --> Security Class Initialized
DEBUG - 2021-12-13 02:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:25:41 --> Input Class Initialized
INFO - 2021-12-13 02:25:41 --> Language Class Initialized
INFO - 2021-12-13 02:25:41 --> Language Class Initialized
INFO - 2021-12-13 02:25:41 --> Config Class Initialized
INFO - 2021-12-13 02:25:41 --> Loader Class Initialized
INFO - 2021-12-13 02:25:41 --> Helper loaded: url_helper
INFO - 2021-12-13 02:25:41 --> Helper loaded: file_helper
INFO - 2021-12-13 02:25:41 --> Helper loaded: form_helper
INFO - 2021-12-13 02:25:41 --> Helper loaded: my_helper
INFO - 2021-12-13 02:25:41 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:25:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:25:41 --> Controller Class Initialized
DEBUG - 2021-12-13 02:25:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:25:41 --> Final output sent to browser
DEBUG - 2021-12-13 02:25:41 --> Total execution time: 0.0690
INFO - 2021-12-13 02:25:43 --> Config Class Initialized
INFO - 2021-12-13 02:25:43 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:25:43 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:25:43 --> Utf8 Class Initialized
INFO - 2021-12-13 02:25:43 --> URI Class Initialized
INFO - 2021-12-13 02:25:43 --> Router Class Initialized
INFO - 2021-12-13 02:25:43 --> Output Class Initialized
INFO - 2021-12-13 02:25:43 --> Security Class Initialized
DEBUG - 2021-12-13 02:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:25:43 --> Input Class Initialized
INFO - 2021-12-13 02:25:43 --> Language Class Initialized
INFO - 2021-12-13 02:25:43 --> Language Class Initialized
INFO - 2021-12-13 02:25:43 --> Config Class Initialized
INFO - 2021-12-13 02:25:43 --> Loader Class Initialized
INFO - 2021-12-13 02:25:43 --> Helper loaded: url_helper
INFO - 2021-12-13 02:25:43 --> Helper loaded: file_helper
INFO - 2021-12-13 02:25:43 --> Helper loaded: form_helper
INFO - 2021-12-13 02:25:43 --> Helper loaded: my_helper
INFO - 2021-12-13 02:25:43 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:25:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:25:43 --> Controller Class Initialized
DEBUG - 2021-12-13 02:25:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:25:43 --> Final output sent to browser
DEBUG - 2021-12-13 02:25:43 --> Total execution time: 0.0610
INFO - 2021-12-13 02:25:46 --> Config Class Initialized
INFO - 2021-12-13 02:25:46 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:25:46 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:25:46 --> Utf8 Class Initialized
INFO - 2021-12-13 02:25:46 --> URI Class Initialized
INFO - 2021-12-13 02:25:46 --> Router Class Initialized
INFO - 2021-12-13 02:25:46 --> Output Class Initialized
INFO - 2021-12-13 02:25:46 --> Security Class Initialized
DEBUG - 2021-12-13 02:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:25:46 --> Input Class Initialized
INFO - 2021-12-13 02:25:46 --> Language Class Initialized
INFO - 2021-12-13 02:25:46 --> Language Class Initialized
INFO - 2021-12-13 02:25:46 --> Config Class Initialized
INFO - 2021-12-13 02:25:46 --> Loader Class Initialized
INFO - 2021-12-13 02:25:46 --> Helper loaded: url_helper
INFO - 2021-12-13 02:25:46 --> Helper loaded: file_helper
INFO - 2021-12-13 02:25:46 --> Helper loaded: form_helper
INFO - 2021-12-13 02:25:46 --> Helper loaded: my_helper
INFO - 2021-12-13 02:25:46 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:25:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:25:46 --> Controller Class Initialized
DEBUG - 2021-12-13 02:25:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:25:46 --> Final output sent to browser
DEBUG - 2021-12-13 02:25:46 --> Total execution time: 0.0690
INFO - 2021-12-13 02:25:48 --> Config Class Initialized
INFO - 2021-12-13 02:25:48 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:25:48 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:25:48 --> Utf8 Class Initialized
INFO - 2021-12-13 02:25:48 --> URI Class Initialized
INFO - 2021-12-13 02:25:48 --> Router Class Initialized
INFO - 2021-12-13 02:25:48 --> Output Class Initialized
INFO - 2021-12-13 02:25:48 --> Security Class Initialized
DEBUG - 2021-12-13 02:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:25:48 --> Input Class Initialized
INFO - 2021-12-13 02:25:48 --> Language Class Initialized
INFO - 2021-12-13 02:25:48 --> Language Class Initialized
INFO - 2021-12-13 02:25:48 --> Config Class Initialized
INFO - 2021-12-13 02:25:48 --> Loader Class Initialized
INFO - 2021-12-13 02:25:48 --> Helper loaded: url_helper
INFO - 2021-12-13 02:25:48 --> Helper loaded: file_helper
INFO - 2021-12-13 02:25:48 --> Helper loaded: form_helper
INFO - 2021-12-13 02:25:48 --> Helper loaded: my_helper
INFO - 2021-12-13 02:25:48 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:25:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:25:48 --> Controller Class Initialized
DEBUG - 2021-12-13 02:25:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:25:48 --> Final output sent to browser
DEBUG - 2021-12-13 02:25:48 --> Total execution time: 0.0690
INFO - 2021-12-13 02:25:49 --> Config Class Initialized
INFO - 2021-12-13 02:25:49 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:25:49 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:25:49 --> Utf8 Class Initialized
INFO - 2021-12-13 02:25:49 --> URI Class Initialized
INFO - 2021-12-13 02:25:49 --> Router Class Initialized
INFO - 2021-12-13 02:25:49 --> Output Class Initialized
INFO - 2021-12-13 02:25:49 --> Security Class Initialized
DEBUG - 2021-12-13 02:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:25:49 --> Input Class Initialized
INFO - 2021-12-13 02:25:49 --> Language Class Initialized
INFO - 2021-12-13 02:25:49 --> Language Class Initialized
INFO - 2021-12-13 02:25:49 --> Config Class Initialized
INFO - 2021-12-13 02:25:49 --> Loader Class Initialized
INFO - 2021-12-13 02:25:49 --> Helper loaded: url_helper
INFO - 2021-12-13 02:25:49 --> Helper loaded: file_helper
INFO - 2021-12-13 02:25:49 --> Helper loaded: form_helper
INFO - 2021-12-13 02:25:49 --> Helper loaded: my_helper
INFO - 2021-12-13 02:25:49 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:25:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:25:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:25:49 --> Controller Class Initialized
DEBUG - 2021-12-13 02:25:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:25:49 --> Final output sent to browser
DEBUG - 2021-12-13 02:25:49 --> Total execution time: 0.0630
INFO - 2021-12-13 02:38:51 --> Config Class Initialized
INFO - 2021-12-13 02:38:51 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:38:51 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:38:51 --> Utf8 Class Initialized
INFO - 2021-12-13 02:38:51 --> URI Class Initialized
DEBUG - 2021-12-13 02:38:51 --> No URI present. Default controller set.
INFO - 2021-12-13 02:38:51 --> Router Class Initialized
INFO - 2021-12-13 02:38:51 --> Output Class Initialized
INFO - 2021-12-13 02:38:51 --> Security Class Initialized
DEBUG - 2021-12-13 02:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:38:51 --> Input Class Initialized
INFO - 2021-12-13 02:38:51 --> Language Class Initialized
INFO - 2021-12-13 02:38:51 --> Language Class Initialized
INFO - 2021-12-13 02:38:51 --> Config Class Initialized
INFO - 2021-12-13 02:38:51 --> Loader Class Initialized
INFO - 2021-12-13 02:38:51 --> Helper loaded: url_helper
INFO - 2021-12-13 02:38:51 --> Helper loaded: file_helper
INFO - 2021-12-13 02:38:51 --> Helper loaded: form_helper
INFO - 2021-12-13 02:38:51 --> Helper loaded: my_helper
INFO - 2021-12-13 02:38:51 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:38:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:38:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:38:51 --> Controller Class Initialized
DEBUG - 2021-12-13 02:38:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-13 02:38:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 02:38:52 --> Final output sent to browser
DEBUG - 2021-12-13 02:38:52 --> Total execution time: 0.2920
INFO - 2021-12-13 02:38:53 --> Config Class Initialized
INFO - 2021-12-13 02:38:53 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:38:53 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:38:53 --> Utf8 Class Initialized
INFO - 2021-12-13 02:38:53 --> URI Class Initialized
INFO - 2021-12-13 02:38:53 --> Router Class Initialized
INFO - 2021-12-13 02:38:53 --> Output Class Initialized
INFO - 2021-12-13 02:38:53 --> Security Class Initialized
DEBUG - 2021-12-13 02:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:38:53 --> Input Class Initialized
INFO - 2021-12-13 02:38:53 --> Language Class Initialized
INFO - 2021-12-13 02:38:53 --> Language Class Initialized
INFO - 2021-12-13 02:38:53 --> Config Class Initialized
INFO - 2021-12-13 02:38:53 --> Loader Class Initialized
INFO - 2021-12-13 02:38:53 --> Helper loaded: url_helper
INFO - 2021-12-13 02:38:53 --> Helper loaded: file_helper
INFO - 2021-12-13 02:38:53 --> Helper loaded: form_helper
INFO - 2021-12-13 02:38:53 --> Helper loaded: my_helper
INFO - 2021-12-13 02:38:53 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:38:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:38:53 --> Controller Class Initialized
INFO - 2021-12-13 02:38:53 --> Helper loaded: cookie_helper
INFO - 2021-12-13 02:38:53 --> Config Class Initialized
INFO - 2021-12-13 02:38:53 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:38:53 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:38:53 --> Utf8 Class Initialized
INFO - 2021-12-13 02:38:53 --> URI Class Initialized
INFO - 2021-12-13 02:38:53 --> Router Class Initialized
INFO - 2021-12-13 02:38:53 --> Output Class Initialized
INFO - 2021-12-13 02:38:53 --> Security Class Initialized
DEBUG - 2021-12-13 02:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:38:53 --> Input Class Initialized
INFO - 2021-12-13 02:38:53 --> Language Class Initialized
INFO - 2021-12-13 02:38:53 --> Language Class Initialized
INFO - 2021-12-13 02:38:53 --> Config Class Initialized
INFO - 2021-12-13 02:38:53 --> Loader Class Initialized
INFO - 2021-12-13 02:38:53 --> Helper loaded: url_helper
INFO - 2021-12-13 02:38:53 --> Helper loaded: file_helper
INFO - 2021-12-13 02:38:53 --> Helper loaded: form_helper
INFO - 2021-12-13 02:38:53 --> Helper loaded: my_helper
INFO - 2021-12-13 02:38:53 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:38:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:38:54 --> Controller Class Initialized
DEBUG - 2021-12-13 02:38:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-13 02:38:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 02:38:54 --> Final output sent to browser
DEBUG - 2021-12-13 02:38:54 --> Total execution time: 0.0370
INFO - 2021-12-13 02:39:13 --> Config Class Initialized
INFO - 2021-12-13 02:39:13 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:39:13 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:39:13 --> Utf8 Class Initialized
INFO - 2021-12-13 02:39:13 --> URI Class Initialized
INFO - 2021-12-13 02:39:13 --> Router Class Initialized
INFO - 2021-12-13 02:39:13 --> Output Class Initialized
INFO - 2021-12-13 02:39:13 --> Security Class Initialized
DEBUG - 2021-12-13 02:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:39:13 --> Input Class Initialized
INFO - 2021-12-13 02:39:13 --> Language Class Initialized
INFO - 2021-12-13 02:39:13 --> Language Class Initialized
INFO - 2021-12-13 02:39:13 --> Config Class Initialized
INFO - 2021-12-13 02:39:13 --> Loader Class Initialized
INFO - 2021-12-13 02:39:13 --> Helper loaded: url_helper
INFO - 2021-12-13 02:39:13 --> Helper loaded: file_helper
INFO - 2021-12-13 02:39:13 --> Helper loaded: form_helper
INFO - 2021-12-13 02:39:13 --> Helper loaded: my_helper
INFO - 2021-12-13 02:39:13 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:39:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:39:13 --> Controller Class Initialized
INFO - 2021-12-13 02:39:13 --> Helper loaded: cookie_helper
INFO - 2021-12-13 02:39:13 --> Final output sent to browser
DEBUG - 2021-12-13 02:39:13 --> Total execution time: 0.0490
INFO - 2021-12-13 02:39:14 --> Config Class Initialized
INFO - 2021-12-13 02:39:14 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:39:14 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:39:14 --> Utf8 Class Initialized
INFO - 2021-12-13 02:39:14 --> URI Class Initialized
INFO - 2021-12-13 02:39:14 --> Router Class Initialized
INFO - 2021-12-13 02:39:14 --> Output Class Initialized
INFO - 2021-12-13 02:39:14 --> Security Class Initialized
DEBUG - 2021-12-13 02:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:39:14 --> Input Class Initialized
INFO - 2021-12-13 02:39:14 --> Language Class Initialized
INFO - 2021-12-13 02:39:14 --> Language Class Initialized
INFO - 2021-12-13 02:39:14 --> Config Class Initialized
INFO - 2021-12-13 02:39:14 --> Loader Class Initialized
INFO - 2021-12-13 02:39:14 --> Helper loaded: url_helper
INFO - 2021-12-13 02:39:14 --> Helper loaded: file_helper
INFO - 2021-12-13 02:39:14 --> Helper loaded: form_helper
INFO - 2021-12-13 02:39:14 --> Helper loaded: my_helper
INFO - 2021-12-13 02:39:14 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:39:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:39:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:39:14 --> Controller Class Initialized
DEBUG - 2021-12-13 02:39:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-13 02:39:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 02:39:14 --> Final output sent to browser
DEBUG - 2021-12-13 02:39:14 --> Total execution time: 0.1590
INFO - 2021-12-13 02:39:15 --> Config Class Initialized
INFO - 2021-12-13 02:39:15 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:39:15 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:39:15 --> Utf8 Class Initialized
INFO - 2021-12-13 02:39:15 --> URI Class Initialized
INFO - 2021-12-13 02:39:15 --> Router Class Initialized
INFO - 2021-12-13 02:39:15 --> Output Class Initialized
INFO - 2021-12-13 02:39:15 --> Security Class Initialized
DEBUG - 2021-12-13 02:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:39:15 --> Input Class Initialized
INFO - 2021-12-13 02:39:15 --> Language Class Initialized
INFO - 2021-12-13 02:39:15 --> Language Class Initialized
INFO - 2021-12-13 02:39:15 --> Config Class Initialized
INFO - 2021-12-13 02:39:15 --> Loader Class Initialized
INFO - 2021-12-13 02:39:15 --> Helper loaded: url_helper
INFO - 2021-12-13 02:39:15 --> Helper loaded: file_helper
INFO - 2021-12-13 02:39:15 --> Helper loaded: form_helper
INFO - 2021-12-13 02:39:15 --> Helper loaded: my_helper
INFO - 2021-12-13 02:39:15 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:39:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:39:15 --> Controller Class Initialized
DEBUG - 2021-12-13 02:39:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-13 02:39:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 02:39:15 --> Final output sent to browser
DEBUG - 2021-12-13 02:39:15 --> Total execution time: 0.0610
INFO - 2021-12-13 02:39:20 --> Config Class Initialized
INFO - 2021-12-13 02:39:20 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:39:20 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:39:20 --> Utf8 Class Initialized
INFO - 2021-12-13 02:39:20 --> URI Class Initialized
INFO - 2021-12-13 02:39:20 --> Router Class Initialized
INFO - 2021-12-13 02:39:20 --> Output Class Initialized
INFO - 2021-12-13 02:39:20 --> Security Class Initialized
DEBUG - 2021-12-13 02:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:39:20 --> Input Class Initialized
INFO - 2021-12-13 02:39:20 --> Language Class Initialized
INFO - 2021-12-13 02:39:20 --> Language Class Initialized
INFO - 2021-12-13 02:39:20 --> Config Class Initialized
INFO - 2021-12-13 02:39:20 --> Loader Class Initialized
INFO - 2021-12-13 02:39:20 --> Helper loaded: url_helper
INFO - 2021-12-13 02:39:20 --> Helper loaded: file_helper
INFO - 2021-12-13 02:39:20 --> Helper loaded: form_helper
INFO - 2021-12-13 02:39:20 --> Helper loaded: my_helper
INFO - 2021-12-13 02:39:20 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:39:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:39:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:39:20 --> Controller Class Initialized
DEBUG - 2021-12-13 02:39:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:39:20 --> Final output sent to browser
DEBUG - 2021-12-13 02:39:20 --> Total execution time: 0.1100
INFO - 2021-12-13 02:39:25 --> Config Class Initialized
INFO - 2021-12-13 02:39:25 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:39:25 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:39:25 --> Utf8 Class Initialized
INFO - 2021-12-13 02:39:25 --> URI Class Initialized
INFO - 2021-12-13 02:39:25 --> Router Class Initialized
INFO - 2021-12-13 02:39:25 --> Output Class Initialized
INFO - 2021-12-13 02:39:25 --> Security Class Initialized
DEBUG - 2021-12-13 02:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:39:25 --> Input Class Initialized
INFO - 2021-12-13 02:39:25 --> Language Class Initialized
INFO - 2021-12-13 02:39:25 --> Language Class Initialized
INFO - 2021-12-13 02:39:25 --> Config Class Initialized
INFO - 2021-12-13 02:39:25 --> Loader Class Initialized
INFO - 2021-12-13 02:39:25 --> Helper loaded: url_helper
INFO - 2021-12-13 02:39:25 --> Helper loaded: file_helper
INFO - 2021-12-13 02:39:25 --> Helper loaded: form_helper
INFO - 2021-12-13 02:39:25 --> Helper loaded: my_helper
INFO - 2021-12-13 02:39:25 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:39:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:39:25 --> Controller Class Initialized
DEBUG - 2021-12-13 02:39:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:39:25 --> Final output sent to browser
DEBUG - 2021-12-13 02:39:25 --> Total execution time: 0.0620
INFO - 2021-12-13 02:39:27 --> Config Class Initialized
INFO - 2021-12-13 02:39:27 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:39:27 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:39:27 --> Utf8 Class Initialized
INFO - 2021-12-13 02:39:27 --> URI Class Initialized
INFO - 2021-12-13 02:39:27 --> Router Class Initialized
INFO - 2021-12-13 02:39:27 --> Output Class Initialized
INFO - 2021-12-13 02:39:27 --> Security Class Initialized
DEBUG - 2021-12-13 02:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:39:27 --> Input Class Initialized
INFO - 2021-12-13 02:39:27 --> Language Class Initialized
INFO - 2021-12-13 02:39:27 --> Language Class Initialized
INFO - 2021-12-13 02:39:27 --> Config Class Initialized
INFO - 2021-12-13 02:39:27 --> Loader Class Initialized
INFO - 2021-12-13 02:39:27 --> Helper loaded: url_helper
INFO - 2021-12-13 02:39:27 --> Helper loaded: file_helper
INFO - 2021-12-13 02:39:27 --> Helper loaded: form_helper
INFO - 2021-12-13 02:39:27 --> Helper loaded: my_helper
INFO - 2021-12-13 02:39:27 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:39:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:39:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:39:27 --> Controller Class Initialized
DEBUG - 2021-12-13 02:39:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:39:27 --> Final output sent to browser
DEBUG - 2021-12-13 02:39:27 --> Total execution time: 0.0710
INFO - 2021-12-13 02:39:29 --> Config Class Initialized
INFO - 2021-12-13 02:39:29 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:39:29 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:39:29 --> Utf8 Class Initialized
INFO - 2021-12-13 02:39:29 --> URI Class Initialized
INFO - 2021-12-13 02:39:29 --> Router Class Initialized
INFO - 2021-12-13 02:39:29 --> Output Class Initialized
INFO - 2021-12-13 02:39:29 --> Security Class Initialized
DEBUG - 2021-12-13 02:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:39:29 --> Input Class Initialized
INFO - 2021-12-13 02:39:29 --> Language Class Initialized
INFO - 2021-12-13 02:39:29 --> Language Class Initialized
INFO - 2021-12-13 02:39:29 --> Config Class Initialized
INFO - 2021-12-13 02:39:29 --> Loader Class Initialized
INFO - 2021-12-13 02:39:29 --> Helper loaded: url_helper
INFO - 2021-12-13 02:39:29 --> Helper loaded: file_helper
INFO - 2021-12-13 02:39:29 --> Helper loaded: form_helper
INFO - 2021-12-13 02:39:29 --> Helper loaded: my_helper
INFO - 2021-12-13 02:39:29 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:39:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:39:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:39:29 --> Controller Class Initialized
DEBUG - 2021-12-13 02:39:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:39:29 --> Final output sent to browser
DEBUG - 2021-12-13 02:39:29 --> Total execution time: 0.0590
INFO - 2021-12-13 02:39:31 --> Config Class Initialized
INFO - 2021-12-13 02:39:31 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:39:31 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:39:31 --> Utf8 Class Initialized
INFO - 2021-12-13 02:39:31 --> URI Class Initialized
INFO - 2021-12-13 02:39:31 --> Router Class Initialized
INFO - 2021-12-13 02:39:31 --> Output Class Initialized
INFO - 2021-12-13 02:39:31 --> Security Class Initialized
DEBUG - 2021-12-13 02:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:39:31 --> Input Class Initialized
INFO - 2021-12-13 02:39:31 --> Language Class Initialized
INFO - 2021-12-13 02:39:31 --> Language Class Initialized
INFO - 2021-12-13 02:39:31 --> Config Class Initialized
INFO - 2021-12-13 02:39:31 --> Loader Class Initialized
INFO - 2021-12-13 02:39:31 --> Helper loaded: url_helper
INFO - 2021-12-13 02:39:31 --> Helper loaded: file_helper
INFO - 2021-12-13 02:39:31 --> Helper loaded: form_helper
INFO - 2021-12-13 02:39:31 --> Helper loaded: my_helper
INFO - 2021-12-13 02:39:31 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:39:31 --> Controller Class Initialized
DEBUG - 2021-12-13 02:39:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:39:31 --> Final output sent to browser
DEBUG - 2021-12-13 02:39:31 --> Total execution time: 0.0600
INFO - 2021-12-13 02:39:33 --> Config Class Initialized
INFO - 2021-12-13 02:39:33 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:39:33 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:39:33 --> Utf8 Class Initialized
INFO - 2021-12-13 02:39:33 --> URI Class Initialized
INFO - 2021-12-13 02:39:33 --> Router Class Initialized
INFO - 2021-12-13 02:39:33 --> Output Class Initialized
INFO - 2021-12-13 02:39:33 --> Security Class Initialized
DEBUG - 2021-12-13 02:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:39:33 --> Input Class Initialized
INFO - 2021-12-13 02:39:33 --> Language Class Initialized
INFO - 2021-12-13 02:39:33 --> Language Class Initialized
INFO - 2021-12-13 02:39:33 --> Config Class Initialized
INFO - 2021-12-13 02:39:33 --> Loader Class Initialized
INFO - 2021-12-13 02:39:33 --> Helper loaded: url_helper
INFO - 2021-12-13 02:39:33 --> Helper loaded: file_helper
INFO - 2021-12-13 02:39:33 --> Helper loaded: form_helper
INFO - 2021-12-13 02:39:33 --> Helper loaded: my_helper
INFO - 2021-12-13 02:39:33 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:39:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:39:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:39:33 --> Controller Class Initialized
DEBUG - 2021-12-13 02:39:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:39:33 --> Final output sent to browser
DEBUG - 2021-12-13 02:39:33 --> Total execution time: 0.0640
INFO - 2021-12-13 02:39:36 --> Config Class Initialized
INFO - 2021-12-13 02:39:36 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:39:36 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:39:36 --> Utf8 Class Initialized
INFO - 2021-12-13 02:39:36 --> URI Class Initialized
INFO - 2021-12-13 02:39:36 --> Router Class Initialized
INFO - 2021-12-13 02:39:36 --> Output Class Initialized
INFO - 2021-12-13 02:39:36 --> Security Class Initialized
DEBUG - 2021-12-13 02:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:39:36 --> Input Class Initialized
INFO - 2021-12-13 02:39:36 --> Language Class Initialized
INFO - 2021-12-13 02:39:36 --> Language Class Initialized
INFO - 2021-12-13 02:39:36 --> Config Class Initialized
INFO - 2021-12-13 02:39:36 --> Loader Class Initialized
INFO - 2021-12-13 02:39:36 --> Helper loaded: url_helper
INFO - 2021-12-13 02:39:36 --> Helper loaded: file_helper
INFO - 2021-12-13 02:39:36 --> Helper loaded: form_helper
INFO - 2021-12-13 02:39:36 --> Helper loaded: my_helper
INFO - 2021-12-13 02:39:36 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:39:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:39:36 --> Controller Class Initialized
DEBUG - 2021-12-13 02:39:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:39:36 --> Final output sent to browser
DEBUG - 2021-12-13 02:39:36 --> Total execution time: 0.0680
INFO - 2021-12-13 02:39:38 --> Config Class Initialized
INFO - 2021-12-13 02:39:38 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:39:38 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:39:38 --> Utf8 Class Initialized
INFO - 2021-12-13 02:39:38 --> URI Class Initialized
INFO - 2021-12-13 02:39:38 --> Router Class Initialized
INFO - 2021-12-13 02:39:38 --> Output Class Initialized
INFO - 2021-12-13 02:39:38 --> Security Class Initialized
DEBUG - 2021-12-13 02:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:39:38 --> Input Class Initialized
INFO - 2021-12-13 02:39:38 --> Language Class Initialized
INFO - 2021-12-13 02:39:38 --> Language Class Initialized
INFO - 2021-12-13 02:39:38 --> Config Class Initialized
INFO - 2021-12-13 02:39:38 --> Loader Class Initialized
INFO - 2021-12-13 02:39:38 --> Helper loaded: url_helper
INFO - 2021-12-13 02:39:38 --> Helper loaded: file_helper
INFO - 2021-12-13 02:39:38 --> Helper loaded: form_helper
INFO - 2021-12-13 02:39:38 --> Helper loaded: my_helper
INFO - 2021-12-13 02:39:38 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:39:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:39:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:39:38 --> Controller Class Initialized
DEBUG - 2021-12-13 02:39:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:39:38 --> Final output sent to browser
DEBUG - 2021-12-13 02:39:38 --> Total execution time: 0.0690
INFO - 2021-12-13 02:39:40 --> Config Class Initialized
INFO - 2021-12-13 02:39:40 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:39:40 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:39:40 --> Utf8 Class Initialized
INFO - 2021-12-13 02:39:40 --> URI Class Initialized
INFO - 2021-12-13 02:39:40 --> Router Class Initialized
INFO - 2021-12-13 02:39:40 --> Output Class Initialized
INFO - 2021-12-13 02:39:40 --> Security Class Initialized
DEBUG - 2021-12-13 02:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:39:40 --> Input Class Initialized
INFO - 2021-12-13 02:39:40 --> Language Class Initialized
INFO - 2021-12-13 02:39:40 --> Language Class Initialized
INFO - 2021-12-13 02:39:40 --> Config Class Initialized
INFO - 2021-12-13 02:39:40 --> Loader Class Initialized
INFO - 2021-12-13 02:39:40 --> Helper loaded: url_helper
INFO - 2021-12-13 02:39:40 --> Helper loaded: file_helper
INFO - 2021-12-13 02:39:40 --> Helper loaded: form_helper
INFO - 2021-12-13 02:39:40 --> Helper loaded: my_helper
INFO - 2021-12-13 02:39:40 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:39:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:39:40 --> Controller Class Initialized
DEBUG - 2021-12-13 02:39:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:39:40 --> Final output sent to browser
DEBUG - 2021-12-13 02:39:40 --> Total execution time: 0.0560
INFO - 2021-12-13 02:39:42 --> Config Class Initialized
INFO - 2021-12-13 02:39:42 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:39:42 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:39:42 --> Utf8 Class Initialized
INFO - 2021-12-13 02:39:42 --> URI Class Initialized
INFO - 2021-12-13 02:39:42 --> Router Class Initialized
INFO - 2021-12-13 02:39:42 --> Output Class Initialized
INFO - 2021-12-13 02:39:42 --> Security Class Initialized
DEBUG - 2021-12-13 02:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:39:42 --> Input Class Initialized
INFO - 2021-12-13 02:39:42 --> Language Class Initialized
INFO - 2021-12-13 02:39:42 --> Language Class Initialized
INFO - 2021-12-13 02:39:42 --> Config Class Initialized
INFO - 2021-12-13 02:39:42 --> Loader Class Initialized
INFO - 2021-12-13 02:39:42 --> Helper loaded: url_helper
INFO - 2021-12-13 02:39:42 --> Helper loaded: file_helper
INFO - 2021-12-13 02:39:42 --> Helper loaded: form_helper
INFO - 2021-12-13 02:39:42 --> Helper loaded: my_helper
INFO - 2021-12-13 02:39:42 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:39:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:39:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:39:42 --> Controller Class Initialized
DEBUG - 2021-12-13 02:39:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:39:42 --> Final output sent to browser
DEBUG - 2021-12-13 02:39:42 --> Total execution time: 0.0630
INFO - 2021-12-13 02:39:44 --> Config Class Initialized
INFO - 2021-12-13 02:39:44 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:39:44 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:39:44 --> Utf8 Class Initialized
INFO - 2021-12-13 02:39:44 --> URI Class Initialized
INFO - 2021-12-13 02:39:44 --> Router Class Initialized
INFO - 2021-12-13 02:39:44 --> Output Class Initialized
INFO - 2021-12-13 02:39:44 --> Security Class Initialized
DEBUG - 2021-12-13 02:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:39:44 --> Input Class Initialized
INFO - 2021-12-13 02:39:44 --> Language Class Initialized
INFO - 2021-12-13 02:39:44 --> Language Class Initialized
INFO - 2021-12-13 02:39:44 --> Config Class Initialized
INFO - 2021-12-13 02:39:44 --> Loader Class Initialized
INFO - 2021-12-13 02:39:44 --> Helper loaded: url_helper
INFO - 2021-12-13 02:39:44 --> Helper loaded: file_helper
INFO - 2021-12-13 02:39:44 --> Helper loaded: form_helper
INFO - 2021-12-13 02:39:44 --> Helper loaded: my_helper
INFO - 2021-12-13 02:39:44 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:39:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:39:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:39:44 --> Controller Class Initialized
DEBUG - 2021-12-13 02:39:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:39:44 --> Final output sent to browser
DEBUG - 2021-12-13 02:39:44 --> Total execution time: 0.0630
INFO - 2021-12-13 02:39:45 --> Config Class Initialized
INFO - 2021-12-13 02:39:45 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:39:45 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:39:45 --> Utf8 Class Initialized
INFO - 2021-12-13 02:39:45 --> URI Class Initialized
INFO - 2021-12-13 02:39:45 --> Router Class Initialized
INFO - 2021-12-13 02:39:45 --> Output Class Initialized
INFO - 2021-12-13 02:39:45 --> Security Class Initialized
DEBUG - 2021-12-13 02:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:39:45 --> Input Class Initialized
INFO - 2021-12-13 02:39:45 --> Language Class Initialized
INFO - 2021-12-13 02:39:45 --> Language Class Initialized
INFO - 2021-12-13 02:39:45 --> Config Class Initialized
INFO - 2021-12-13 02:39:45 --> Loader Class Initialized
INFO - 2021-12-13 02:39:45 --> Helper loaded: url_helper
INFO - 2021-12-13 02:39:45 --> Helper loaded: file_helper
INFO - 2021-12-13 02:39:45 --> Helper loaded: form_helper
INFO - 2021-12-13 02:39:45 --> Helper loaded: my_helper
INFO - 2021-12-13 02:39:45 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:39:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:39:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:39:45 --> Controller Class Initialized
DEBUG - 2021-12-13 02:39:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:39:45 --> Final output sent to browser
DEBUG - 2021-12-13 02:39:45 --> Total execution time: 0.0560
INFO - 2021-12-13 02:39:47 --> Config Class Initialized
INFO - 2021-12-13 02:39:47 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:39:47 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:39:47 --> Utf8 Class Initialized
INFO - 2021-12-13 02:39:47 --> URI Class Initialized
INFO - 2021-12-13 02:39:47 --> Router Class Initialized
INFO - 2021-12-13 02:39:47 --> Output Class Initialized
INFO - 2021-12-13 02:39:47 --> Security Class Initialized
DEBUG - 2021-12-13 02:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:39:47 --> Input Class Initialized
INFO - 2021-12-13 02:39:47 --> Language Class Initialized
INFO - 2021-12-13 02:39:47 --> Language Class Initialized
INFO - 2021-12-13 02:39:47 --> Config Class Initialized
INFO - 2021-12-13 02:39:47 --> Loader Class Initialized
INFO - 2021-12-13 02:39:47 --> Helper loaded: url_helper
INFO - 2021-12-13 02:39:47 --> Helper loaded: file_helper
INFO - 2021-12-13 02:39:47 --> Helper loaded: form_helper
INFO - 2021-12-13 02:39:47 --> Helper loaded: my_helper
INFO - 2021-12-13 02:39:47 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:39:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:39:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:39:47 --> Controller Class Initialized
DEBUG - 2021-12-13 02:39:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:39:47 --> Final output sent to browser
DEBUG - 2021-12-13 02:39:47 --> Total execution time: 0.0630
INFO - 2021-12-13 02:39:50 --> Config Class Initialized
INFO - 2021-12-13 02:39:50 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:39:50 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:39:50 --> Utf8 Class Initialized
INFO - 2021-12-13 02:39:50 --> URI Class Initialized
INFO - 2021-12-13 02:39:50 --> Router Class Initialized
INFO - 2021-12-13 02:39:50 --> Output Class Initialized
INFO - 2021-12-13 02:39:50 --> Security Class Initialized
DEBUG - 2021-12-13 02:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:39:50 --> Input Class Initialized
INFO - 2021-12-13 02:39:50 --> Language Class Initialized
INFO - 2021-12-13 02:39:50 --> Language Class Initialized
INFO - 2021-12-13 02:39:50 --> Config Class Initialized
INFO - 2021-12-13 02:39:50 --> Loader Class Initialized
INFO - 2021-12-13 02:39:50 --> Helper loaded: url_helper
INFO - 2021-12-13 02:39:50 --> Helper loaded: file_helper
INFO - 2021-12-13 02:39:50 --> Helper loaded: form_helper
INFO - 2021-12-13 02:39:50 --> Helper loaded: my_helper
INFO - 2021-12-13 02:39:50 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:39:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:39:50 --> Controller Class Initialized
DEBUG - 2021-12-13 02:39:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:39:50 --> Final output sent to browser
DEBUG - 2021-12-13 02:39:50 --> Total execution time: 0.0550
INFO - 2021-12-13 02:39:51 --> Config Class Initialized
INFO - 2021-12-13 02:39:51 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:39:51 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:39:51 --> Utf8 Class Initialized
INFO - 2021-12-13 02:39:51 --> URI Class Initialized
INFO - 2021-12-13 02:39:51 --> Router Class Initialized
INFO - 2021-12-13 02:39:51 --> Output Class Initialized
INFO - 2021-12-13 02:39:51 --> Security Class Initialized
DEBUG - 2021-12-13 02:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:39:51 --> Input Class Initialized
INFO - 2021-12-13 02:39:51 --> Language Class Initialized
INFO - 2021-12-13 02:39:51 --> Language Class Initialized
INFO - 2021-12-13 02:39:51 --> Config Class Initialized
INFO - 2021-12-13 02:39:51 --> Loader Class Initialized
INFO - 2021-12-13 02:39:51 --> Helper loaded: url_helper
INFO - 2021-12-13 02:39:51 --> Helper loaded: file_helper
INFO - 2021-12-13 02:39:51 --> Helper loaded: form_helper
INFO - 2021-12-13 02:39:51 --> Helper loaded: my_helper
INFO - 2021-12-13 02:39:51 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:39:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:39:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:39:51 --> Controller Class Initialized
DEBUG - 2021-12-13 02:39:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:39:51 --> Final output sent to browser
DEBUG - 2021-12-13 02:39:51 --> Total execution time: 0.0700
INFO - 2021-12-13 02:39:53 --> Config Class Initialized
INFO - 2021-12-13 02:39:53 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:39:53 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:39:53 --> Utf8 Class Initialized
INFO - 2021-12-13 02:39:53 --> URI Class Initialized
INFO - 2021-12-13 02:39:53 --> Router Class Initialized
INFO - 2021-12-13 02:39:53 --> Output Class Initialized
INFO - 2021-12-13 02:39:53 --> Security Class Initialized
DEBUG - 2021-12-13 02:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:39:53 --> Input Class Initialized
INFO - 2021-12-13 02:39:53 --> Language Class Initialized
INFO - 2021-12-13 02:39:53 --> Language Class Initialized
INFO - 2021-12-13 02:39:53 --> Config Class Initialized
INFO - 2021-12-13 02:39:53 --> Loader Class Initialized
INFO - 2021-12-13 02:39:53 --> Helper loaded: url_helper
INFO - 2021-12-13 02:39:53 --> Helper loaded: file_helper
INFO - 2021-12-13 02:39:53 --> Helper loaded: form_helper
INFO - 2021-12-13 02:39:53 --> Helper loaded: my_helper
INFO - 2021-12-13 02:39:53 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:39:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:39:53 --> Controller Class Initialized
DEBUG - 2021-12-13 02:39:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:39:53 --> Final output sent to browser
DEBUG - 2021-12-13 02:39:53 --> Total execution time: 0.0570
INFO - 2021-12-13 02:39:55 --> Config Class Initialized
INFO - 2021-12-13 02:39:55 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:39:55 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:39:55 --> Utf8 Class Initialized
INFO - 2021-12-13 02:39:55 --> URI Class Initialized
INFO - 2021-12-13 02:39:55 --> Router Class Initialized
INFO - 2021-12-13 02:39:55 --> Output Class Initialized
INFO - 2021-12-13 02:39:55 --> Security Class Initialized
DEBUG - 2021-12-13 02:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:39:55 --> Input Class Initialized
INFO - 2021-12-13 02:39:55 --> Language Class Initialized
INFO - 2021-12-13 02:39:55 --> Language Class Initialized
INFO - 2021-12-13 02:39:55 --> Config Class Initialized
INFO - 2021-12-13 02:39:55 --> Loader Class Initialized
INFO - 2021-12-13 02:39:55 --> Helper loaded: url_helper
INFO - 2021-12-13 02:39:55 --> Helper loaded: file_helper
INFO - 2021-12-13 02:39:55 --> Helper loaded: form_helper
INFO - 2021-12-13 02:39:55 --> Helper loaded: my_helper
INFO - 2021-12-13 02:39:55 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:39:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:39:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:39:55 --> Controller Class Initialized
DEBUG - 2021-12-13 02:39:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:39:55 --> Final output sent to browser
DEBUG - 2021-12-13 02:39:55 --> Total execution time: 0.0650
INFO - 2021-12-13 02:39:57 --> Config Class Initialized
INFO - 2021-12-13 02:39:57 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:39:57 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:39:57 --> Utf8 Class Initialized
INFO - 2021-12-13 02:39:57 --> URI Class Initialized
INFO - 2021-12-13 02:39:57 --> Router Class Initialized
INFO - 2021-12-13 02:39:57 --> Output Class Initialized
INFO - 2021-12-13 02:39:57 --> Security Class Initialized
DEBUG - 2021-12-13 02:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:39:57 --> Input Class Initialized
INFO - 2021-12-13 02:39:57 --> Language Class Initialized
INFO - 2021-12-13 02:39:57 --> Language Class Initialized
INFO - 2021-12-13 02:39:57 --> Config Class Initialized
INFO - 2021-12-13 02:39:57 --> Loader Class Initialized
INFO - 2021-12-13 02:39:57 --> Helper loaded: url_helper
INFO - 2021-12-13 02:39:57 --> Helper loaded: file_helper
INFO - 2021-12-13 02:39:57 --> Helper loaded: form_helper
INFO - 2021-12-13 02:39:57 --> Helper loaded: my_helper
INFO - 2021-12-13 02:39:57 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:39:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:39:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:39:57 --> Controller Class Initialized
DEBUG - 2021-12-13 02:39:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:39:57 --> Final output sent to browser
DEBUG - 2021-12-13 02:39:57 --> Total execution time: 0.0660
INFO - 2021-12-13 02:39:59 --> Config Class Initialized
INFO - 2021-12-13 02:39:59 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:39:59 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:39:59 --> Utf8 Class Initialized
INFO - 2021-12-13 02:39:59 --> URI Class Initialized
INFO - 2021-12-13 02:39:59 --> Router Class Initialized
INFO - 2021-12-13 02:39:59 --> Output Class Initialized
INFO - 2021-12-13 02:39:59 --> Security Class Initialized
DEBUG - 2021-12-13 02:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:39:59 --> Input Class Initialized
INFO - 2021-12-13 02:39:59 --> Language Class Initialized
INFO - 2021-12-13 02:39:59 --> Language Class Initialized
INFO - 2021-12-13 02:39:59 --> Config Class Initialized
INFO - 2021-12-13 02:39:59 --> Loader Class Initialized
INFO - 2021-12-13 02:39:59 --> Helper loaded: url_helper
INFO - 2021-12-13 02:39:59 --> Helper loaded: file_helper
INFO - 2021-12-13 02:39:59 --> Helper loaded: form_helper
INFO - 2021-12-13 02:39:59 --> Helper loaded: my_helper
INFO - 2021-12-13 02:39:59 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:39:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:39:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:39:59 --> Controller Class Initialized
DEBUG - 2021-12-13 02:39:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:39:59 --> Final output sent to browser
DEBUG - 2021-12-13 02:39:59 --> Total execution time: 0.0630
INFO - 2021-12-13 02:40:03 --> Config Class Initialized
INFO - 2021-12-13 02:40:03 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:40:03 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:40:03 --> Utf8 Class Initialized
INFO - 2021-12-13 02:40:03 --> URI Class Initialized
INFO - 2021-12-13 02:40:03 --> Router Class Initialized
INFO - 2021-12-13 02:40:03 --> Output Class Initialized
INFO - 2021-12-13 02:40:03 --> Security Class Initialized
DEBUG - 2021-12-13 02:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:40:03 --> Input Class Initialized
INFO - 2021-12-13 02:40:03 --> Language Class Initialized
INFO - 2021-12-13 02:40:03 --> Language Class Initialized
INFO - 2021-12-13 02:40:03 --> Config Class Initialized
INFO - 2021-12-13 02:40:03 --> Loader Class Initialized
INFO - 2021-12-13 02:40:03 --> Helper loaded: url_helper
INFO - 2021-12-13 02:40:03 --> Helper loaded: file_helper
INFO - 2021-12-13 02:40:03 --> Helper loaded: form_helper
INFO - 2021-12-13 02:40:03 --> Helper loaded: my_helper
INFO - 2021-12-13 02:40:03 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:40:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:40:03 --> Controller Class Initialized
DEBUG - 2021-12-13 02:40:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:40:03 --> Final output sent to browser
DEBUG - 2021-12-13 02:40:03 --> Total execution time: 0.0620
INFO - 2021-12-13 02:40:05 --> Config Class Initialized
INFO - 2021-12-13 02:40:05 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:40:05 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:40:05 --> Utf8 Class Initialized
INFO - 2021-12-13 02:40:05 --> URI Class Initialized
INFO - 2021-12-13 02:40:05 --> Router Class Initialized
INFO - 2021-12-13 02:40:05 --> Output Class Initialized
INFO - 2021-12-13 02:40:05 --> Security Class Initialized
DEBUG - 2021-12-13 02:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:40:05 --> Input Class Initialized
INFO - 2021-12-13 02:40:05 --> Language Class Initialized
INFO - 2021-12-13 02:40:05 --> Language Class Initialized
INFO - 2021-12-13 02:40:05 --> Config Class Initialized
INFO - 2021-12-13 02:40:05 --> Loader Class Initialized
INFO - 2021-12-13 02:40:05 --> Helper loaded: url_helper
INFO - 2021-12-13 02:40:05 --> Helper loaded: file_helper
INFO - 2021-12-13 02:40:05 --> Helper loaded: form_helper
INFO - 2021-12-13 02:40:05 --> Helper loaded: my_helper
INFO - 2021-12-13 02:40:05 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:40:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:40:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:40:05 --> Controller Class Initialized
DEBUG - 2021-12-13 02:40:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:40:05 --> Final output sent to browser
DEBUG - 2021-12-13 02:40:05 --> Total execution time: 0.0620
INFO - 2021-12-13 02:40:07 --> Config Class Initialized
INFO - 2021-12-13 02:40:07 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:40:07 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:40:07 --> Utf8 Class Initialized
INFO - 2021-12-13 02:40:07 --> URI Class Initialized
INFO - 2021-12-13 02:40:07 --> Router Class Initialized
INFO - 2021-12-13 02:40:07 --> Output Class Initialized
INFO - 2021-12-13 02:40:07 --> Security Class Initialized
DEBUG - 2021-12-13 02:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:40:07 --> Input Class Initialized
INFO - 2021-12-13 02:40:07 --> Language Class Initialized
INFO - 2021-12-13 02:40:07 --> Language Class Initialized
INFO - 2021-12-13 02:40:07 --> Config Class Initialized
INFO - 2021-12-13 02:40:07 --> Loader Class Initialized
INFO - 2021-12-13 02:40:07 --> Helper loaded: url_helper
INFO - 2021-12-13 02:40:07 --> Helper loaded: file_helper
INFO - 2021-12-13 02:40:07 --> Helper loaded: form_helper
INFO - 2021-12-13 02:40:07 --> Helper loaded: my_helper
INFO - 2021-12-13 02:40:07 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:40:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:40:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:40:07 --> Controller Class Initialized
DEBUG - 2021-12-13 02:40:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:40:07 --> Final output sent to browser
DEBUG - 2021-12-13 02:40:07 --> Total execution time: 0.0610
INFO - 2021-12-13 02:40:10 --> Config Class Initialized
INFO - 2021-12-13 02:40:10 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:40:10 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:40:10 --> Utf8 Class Initialized
INFO - 2021-12-13 02:40:10 --> URI Class Initialized
INFO - 2021-12-13 02:40:10 --> Router Class Initialized
INFO - 2021-12-13 02:40:10 --> Output Class Initialized
INFO - 2021-12-13 02:40:10 --> Security Class Initialized
DEBUG - 2021-12-13 02:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:40:10 --> Input Class Initialized
INFO - 2021-12-13 02:40:10 --> Language Class Initialized
INFO - 2021-12-13 02:40:10 --> Language Class Initialized
INFO - 2021-12-13 02:40:10 --> Config Class Initialized
INFO - 2021-12-13 02:40:10 --> Loader Class Initialized
INFO - 2021-12-13 02:40:10 --> Helper loaded: url_helper
INFO - 2021-12-13 02:40:10 --> Helper loaded: file_helper
INFO - 2021-12-13 02:40:10 --> Helper loaded: form_helper
INFO - 2021-12-13 02:40:10 --> Helper loaded: my_helper
INFO - 2021-12-13 02:40:10 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:40:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:40:10 --> Controller Class Initialized
DEBUG - 2021-12-13 02:40:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:40:10 --> Final output sent to browser
DEBUG - 2021-12-13 02:40:10 --> Total execution time: 0.0600
INFO - 2021-12-13 02:40:12 --> Config Class Initialized
INFO - 2021-12-13 02:40:12 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:40:12 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:40:12 --> Utf8 Class Initialized
INFO - 2021-12-13 02:40:12 --> URI Class Initialized
INFO - 2021-12-13 02:40:12 --> Router Class Initialized
INFO - 2021-12-13 02:40:12 --> Output Class Initialized
INFO - 2021-12-13 02:40:12 --> Security Class Initialized
DEBUG - 2021-12-13 02:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:40:12 --> Input Class Initialized
INFO - 2021-12-13 02:40:12 --> Language Class Initialized
INFO - 2021-12-13 02:40:12 --> Language Class Initialized
INFO - 2021-12-13 02:40:12 --> Config Class Initialized
INFO - 2021-12-13 02:40:12 --> Loader Class Initialized
INFO - 2021-12-13 02:40:12 --> Helper loaded: url_helper
INFO - 2021-12-13 02:40:12 --> Helper loaded: file_helper
INFO - 2021-12-13 02:40:12 --> Helper loaded: form_helper
INFO - 2021-12-13 02:40:12 --> Helper loaded: my_helper
INFO - 2021-12-13 02:40:12 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:40:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:40:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:40:12 --> Controller Class Initialized
DEBUG - 2021-12-13 02:40:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:40:12 --> Final output sent to browser
DEBUG - 2021-12-13 02:40:12 --> Total execution time: 0.0560
INFO - 2021-12-13 02:40:14 --> Config Class Initialized
INFO - 2021-12-13 02:40:14 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:40:14 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:40:14 --> Utf8 Class Initialized
INFO - 2021-12-13 02:40:14 --> URI Class Initialized
INFO - 2021-12-13 02:40:14 --> Router Class Initialized
INFO - 2021-12-13 02:40:14 --> Output Class Initialized
INFO - 2021-12-13 02:40:14 --> Security Class Initialized
DEBUG - 2021-12-13 02:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:40:14 --> Input Class Initialized
INFO - 2021-12-13 02:40:14 --> Language Class Initialized
INFO - 2021-12-13 02:40:14 --> Language Class Initialized
INFO - 2021-12-13 02:40:14 --> Config Class Initialized
INFO - 2021-12-13 02:40:14 --> Loader Class Initialized
INFO - 2021-12-13 02:40:14 --> Helper loaded: url_helper
INFO - 2021-12-13 02:40:14 --> Helper loaded: file_helper
INFO - 2021-12-13 02:40:14 --> Helper loaded: form_helper
INFO - 2021-12-13 02:40:14 --> Helper loaded: my_helper
INFO - 2021-12-13 02:40:14 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:40:14 --> Controller Class Initialized
DEBUG - 2021-12-13 02:40:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:40:14 --> Final output sent to browser
DEBUG - 2021-12-13 02:40:14 --> Total execution time: 0.0600
INFO - 2021-12-13 02:40:17 --> Config Class Initialized
INFO - 2021-12-13 02:40:17 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:40:17 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:40:17 --> Utf8 Class Initialized
INFO - 2021-12-13 02:40:17 --> URI Class Initialized
INFO - 2021-12-13 02:40:17 --> Router Class Initialized
INFO - 2021-12-13 02:40:17 --> Output Class Initialized
INFO - 2021-12-13 02:40:17 --> Security Class Initialized
DEBUG - 2021-12-13 02:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:40:17 --> Input Class Initialized
INFO - 2021-12-13 02:40:17 --> Language Class Initialized
INFO - 2021-12-13 02:40:17 --> Language Class Initialized
INFO - 2021-12-13 02:40:17 --> Config Class Initialized
INFO - 2021-12-13 02:40:17 --> Loader Class Initialized
INFO - 2021-12-13 02:40:17 --> Helper loaded: url_helper
INFO - 2021-12-13 02:40:17 --> Helper loaded: file_helper
INFO - 2021-12-13 02:40:17 --> Helper loaded: form_helper
INFO - 2021-12-13 02:40:17 --> Helper loaded: my_helper
INFO - 2021-12-13 02:40:17 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:40:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:40:17 --> Controller Class Initialized
DEBUG - 2021-12-13 02:40:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:40:17 --> Final output sent to browser
DEBUG - 2021-12-13 02:40:17 --> Total execution time: 0.0650
INFO - 2021-12-13 02:40:18 --> Config Class Initialized
INFO - 2021-12-13 02:40:18 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:40:18 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:40:18 --> Utf8 Class Initialized
INFO - 2021-12-13 02:40:18 --> URI Class Initialized
INFO - 2021-12-13 02:40:18 --> Router Class Initialized
INFO - 2021-12-13 02:40:18 --> Output Class Initialized
INFO - 2021-12-13 02:40:18 --> Security Class Initialized
DEBUG - 2021-12-13 02:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:40:18 --> Input Class Initialized
INFO - 2021-12-13 02:40:18 --> Language Class Initialized
INFO - 2021-12-13 02:40:18 --> Language Class Initialized
INFO - 2021-12-13 02:40:18 --> Config Class Initialized
INFO - 2021-12-13 02:40:18 --> Loader Class Initialized
INFO - 2021-12-13 02:40:18 --> Helper loaded: url_helper
INFO - 2021-12-13 02:40:18 --> Helper loaded: file_helper
INFO - 2021-12-13 02:40:18 --> Helper loaded: form_helper
INFO - 2021-12-13 02:40:18 --> Helper loaded: my_helper
INFO - 2021-12-13 02:40:18 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:40:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:40:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:40:18 --> Controller Class Initialized
DEBUG - 2021-12-13 02:40:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:40:18 --> Final output sent to browser
DEBUG - 2021-12-13 02:40:18 --> Total execution time: 0.0610
INFO - 2021-12-13 02:43:41 --> Config Class Initialized
INFO - 2021-12-13 02:43:41 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:43:41 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:43:41 --> Utf8 Class Initialized
INFO - 2021-12-13 02:43:41 --> URI Class Initialized
INFO - 2021-12-13 02:43:41 --> Router Class Initialized
INFO - 2021-12-13 02:43:41 --> Output Class Initialized
INFO - 2021-12-13 02:43:41 --> Security Class Initialized
DEBUG - 2021-12-13 02:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:43:41 --> Input Class Initialized
INFO - 2021-12-13 02:43:41 --> Language Class Initialized
INFO - 2021-12-13 02:43:41 --> Language Class Initialized
INFO - 2021-12-13 02:43:41 --> Config Class Initialized
INFO - 2021-12-13 02:43:41 --> Loader Class Initialized
INFO - 2021-12-13 02:43:41 --> Helper loaded: url_helper
INFO - 2021-12-13 02:43:41 --> Helper loaded: file_helper
INFO - 2021-12-13 02:43:41 --> Helper loaded: form_helper
INFO - 2021-12-13 02:43:41 --> Helper loaded: my_helper
INFO - 2021-12-13 02:43:41 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:43:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:43:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:43:41 --> Controller Class Initialized
INFO - 2021-12-13 02:43:41 --> Helper loaded: cookie_helper
INFO - 2021-12-13 02:43:41 --> Config Class Initialized
INFO - 2021-12-13 02:43:41 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:43:41 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:43:41 --> Utf8 Class Initialized
INFO - 2021-12-13 02:43:41 --> URI Class Initialized
INFO - 2021-12-13 02:43:41 --> Router Class Initialized
INFO - 2021-12-13 02:43:41 --> Output Class Initialized
INFO - 2021-12-13 02:43:41 --> Security Class Initialized
DEBUG - 2021-12-13 02:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:43:41 --> Input Class Initialized
INFO - 2021-12-13 02:43:41 --> Language Class Initialized
INFO - 2021-12-13 02:43:41 --> Language Class Initialized
INFO - 2021-12-13 02:43:41 --> Config Class Initialized
INFO - 2021-12-13 02:43:41 --> Loader Class Initialized
INFO - 2021-12-13 02:43:41 --> Helper loaded: url_helper
INFO - 2021-12-13 02:43:41 --> Helper loaded: file_helper
INFO - 2021-12-13 02:43:41 --> Helper loaded: form_helper
INFO - 2021-12-13 02:43:41 --> Helper loaded: my_helper
INFO - 2021-12-13 02:43:41 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:43:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:43:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:43:41 --> Controller Class Initialized
DEBUG - 2021-12-13 02:43:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-13 02:43:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 02:43:41 --> Final output sent to browser
DEBUG - 2021-12-13 02:43:41 --> Total execution time: 0.0340
INFO - 2021-12-13 02:43:47 --> Config Class Initialized
INFO - 2021-12-13 02:43:47 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:43:47 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:43:47 --> Utf8 Class Initialized
INFO - 2021-12-13 02:43:47 --> URI Class Initialized
INFO - 2021-12-13 02:43:47 --> Router Class Initialized
INFO - 2021-12-13 02:43:47 --> Output Class Initialized
INFO - 2021-12-13 02:43:47 --> Security Class Initialized
DEBUG - 2021-12-13 02:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:43:47 --> Input Class Initialized
INFO - 2021-12-13 02:43:47 --> Language Class Initialized
INFO - 2021-12-13 02:43:47 --> Language Class Initialized
INFO - 2021-12-13 02:43:47 --> Config Class Initialized
INFO - 2021-12-13 02:43:47 --> Loader Class Initialized
INFO - 2021-12-13 02:43:47 --> Helper loaded: url_helper
INFO - 2021-12-13 02:43:47 --> Helper loaded: file_helper
INFO - 2021-12-13 02:43:47 --> Helper loaded: form_helper
INFO - 2021-12-13 02:43:47 --> Helper loaded: my_helper
INFO - 2021-12-13 02:43:47 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:43:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:43:47 --> Controller Class Initialized
INFO - 2021-12-13 02:43:47 --> Helper loaded: cookie_helper
INFO - 2021-12-13 02:43:47 --> Final output sent to browser
DEBUG - 2021-12-13 02:43:47 --> Total execution time: 0.0610
INFO - 2021-12-13 02:43:47 --> Config Class Initialized
INFO - 2021-12-13 02:43:47 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:43:47 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:43:47 --> Utf8 Class Initialized
INFO - 2021-12-13 02:43:47 --> URI Class Initialized
INFO - 2021-12-13 02:43:47 --> Router Class Initialized
INFO - 2021-12-13 02:43:47 --> Output Class Initialized
INFO - 2021-12-13 02:43:47 --> Security Class Initialized
DEBUG - 2021-12-13 02:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:43:47 --> Input Class Initialized
INFO - 2021-12-13 02:43:47 --> Language Class Initialized
INFO - 2021-12-13 02:43:47 --> Language Class Initialized
INFO - 2021-12-13 02:43:47 --> Config Class Initialized
INFO - 2021-12-13 02:43:47 --> Loader Class Initialized
INFO - 2021-12-13 02:43:47 --> Helper loaded: url_helper
INFO - 2021-12-13 02:43:47 --> Helper loaded: file_helper
INFO - 2021-12-13 02:43:47 --> Helper loaded: form_helper
INFO - 2021-12-13 02:43:47 --> Helper loaded: my_helper
INFO - 2021-12-13 02:43:47 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:43:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:43:47 --> Controller Class Initialized
DEBUG - 2021-12-13 02:43:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-13 02:43:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 02:43:47 --> Final output sent to browser
DEBUG - 2021-12-13 02:43:47 --> Total execution time: 0.2170
INFO - 2021-12-13 02:43:51 --> Config Class Initialized
INFO - 2021-12-13 02:43:51 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:43:51 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:43:51 --> Utf8 Class Initialized
INFO - 2021-12-13 02:43:51 --> URI Class Initialized
INFO - 2021-12-13 02:43:51 --> Router Class Initialized
INFO - 2021-12-13 02:43:51 --> Output Class Initialized
INFO - 2021-12-13 02:43:51 --> Security Class Initialized
DEBUG - 2021-12-13 02:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:43:51 --> Input Class Initialized
INFO - 2021-12-13 02:43:51 --> Language Class Initialized
INFO - 2021-12-13 02:43:51 --> Language Class Initialized
INFO - 2021-12-13 02:43:51 --> Config Class Initialized
INFO - 2021-12-13 02:43:51 --> Loader Class Initialized
INFO - 2021-12-13 02:43:51 --> Helper loaded: url_helper
INFO - 2021-12-13 02:43:51 --> Helper loaded: file_helper
INFO - 2021-12-13 02:43:51 --> Helper loaded: form_helper
INFO - 2021-12-13 02:43:51 --> Helper loaded: my_helper
INFO - 2021-12-13 02:43:51 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:43:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:43:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:43:51 --> Controller Class Initialized
DEBUG - 2021-12-13 02:43:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-12-13 02:43:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 02:43:51 --> Final output sent to browser
DEBUG - 2021-12-13 02:43:51 --> Total execution time: 0.0760
INFO - 2021-12-13 02:43:53 --> Config Class Initialized
INFO - 2021-12-13 02:43:53 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:43:53 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:43:53 --> Utf8 Class Initialized
INFO - 2021-12-13 02:43:53 --> URI Class Initialized
INFO - 2021-12-13 02:43:53 --> Router Class Initialized
INFO - 2021-12-13 02:43:53 --> Output Class Initialized
INFO - 2021-12-13 02:43:53 --> Security Class Initialized
DEBUG - 2021-12-13 02:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:43:53 --> Input Class Initialized
INFO - 2021-12-13 02:43:53 --> Language Class Initialized
INFO - 2021-12-13 02:43:53 --> Language Class Initialized
INFO - 2021-12-13 02:43:53 --> Config Class Initialized
INFO - 2021-12-13 02:43:53 --> Loader Class Initialized
INFO - 2021-12-13 02:43:53 --> Helper loaded: url_helper
INFO - 2021-12-13 02:43:53 --> Helper loaded: file_helper
INFO - 2021-12-13 02:43:53 --> Helper loaded: form_helper
INFO - 2021-12-13 02:43:53 --> Helper loaded: my_helper
INFO - 2021-12-13 02:43:53 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:43:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:43:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:43:53 --> Controller Class Initialized
DEBUG - 2021-12-13 02:43:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-13 02:43:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 02:43:53 --> Final output sent to browser
DEBUG - 2021-12-13 02:43:53 --> Total execution time: 0.0740
INFO - 2021-12-13 02:43:57 --> Config Class Initialized
INFO - 2021-12-13 02:43:57 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:43:57 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:43:57 --> Utf8 Class Initialized
INFO - 2021-12-13 02:43:57 --> URI Class Initialized
INFO - 2021-12-13 02:43:57 --> Router Class Initialized
INFO - 2021-12-13 02:43:57 --> Output Class Initialized
INFO - 2021-12-13 02:43:57 --> Security Class Initialized
DEBUG - 2021-12-13 02:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:43:57 --> Input Class Initialized
INFO - 2021-12-13 02:43:57 --> Language Class Initialized
INFO - 2021-12-13 02:43:57 --> Language Class Initialized
INFO - 2021-12-13 02:43:57 --> Config Class Initialized
INFO - 2021-12-13 02:43:57 --> Loader Class Initialized
INFO - 2021-12-13 02:43:57 --> Helper loaded: url_helper
INFO - 2021-12-13 02:43:57 --> Helper loaded: file_helper
INFO - 2021-12-13 02:43:57 --> Helper loaded: form_helper
INFO - 2021-12-13 02:43:57 --> Helper loaded: my_helper
INFO - 2021-12-13 02:43:57 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:43:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:43:57 --> Controller Class Initialized
DEBUG - 2021-12-13 02:43:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:43:57 --> Final output sent to browser
DEBUG - 2021-12-13 02:43:57 --> Total execution time: 0.1100
INFO - 2021-12-13 02:44:03 --> Config Class Initialized
INFO - 2021-12-13 02:44:03 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:44:03 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:44:03 --> Utf8 Class Initialized
INFO - 2021-12-13 02:44:03 --> URI Class Initialized
INFO - 2021-12-13 02:44:03 --> Router Class Initialized
INFO - 2021-12-13 02:44:03 --> Output Class Initialized
INFO - 2021-12-13 02:44:03 --> Security Class Initialized
DEBUG - 2021-12-13 02:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:44:03 --> Input Class Initialized
INFO - 2021-12-13 02:44:03 --> Language Class Initialized
INFO - 2021-12-13 02:44:03 --> Language Class Initialized
INFO - 2021-12-13 02:44:03 --> Config Class Initialized
INFO - 2021-12-13 02:44:03 --> Loader Class Initialized
INFO - 2021-12-13 02:44:03 --> Helper loaded: url_helper
INFO - 2021-12-13 02:44:03 --> Helper loaded: file_helper
INFO - 2021-12-13 02:44:03 --> Helper loaded: form_helper
INFO - 2021-12-13 02:44:03 --> Helper loaded: my_helper
INFO - 2021-12-13 02:44:03 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:44:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:44:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:44:03 --> Controller Class Initialized
DEBUG - 2021-12-13 02:44:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:44:03 --> Final output sent to browser
DEBUG - 2021-12-13 02:44:03 --> Total execution time: 0.0650
INFO - 2021-12-13 02:44:04 --> Config Class Initialized
INFO - 2021-12-13 02:44:04 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:44:04 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:44:04 --> Utf8 Class Initialized
INFO - 2021-12-13 02:44:04 --> URI Class Initialized
INFO - 2021-12-13 02:44:04 --> Router Class Initialized
INFO - 2021-12-13 02:44:04 --> Output Class Initialized
INFO - 2021-12-13 02:44:04 --> Security Class Initialized
DEBUG - 2021-12-13 02:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:44:04 --> Input Class Initialized
INFO - 2021-12-13 02:44:04 --> Language Class Initialized
INFO - 2021-12-13 02:44:04 --> Language Class Initialized
INFO - 2021-12-13 02:44:04 --> Config Class Initialized
INFO - 2021-12-13 02:44:04 --> Loader Class Initialized
INFO - 2021-12-13 02:44:04 --> Helper loaded: url_helper
INFO - 2021-12-13 02:44:04 --> Helper loaded: file_helper
INFO - 2021-12-13 02:44:04 --> Helper loaded: form_helper
INFO - 2021-12-13 02:44:04 --> Helper loaded: my_helper
INFO - 2021-12-13 02:44:04 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:44:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:44:04 --> Controller Class Initialized
DEBUG - 2021-12-13 02:44:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:44:04 --> Final output sent to browser
DEBUG - 2021-12-13 02:44:04 --> Total execution time: 0.0660
INFO - 2021-12-13 02:44:06 --> Config Class Initialized
INFO - 2021-12-13 02:44:06 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:44:06 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:44:06 --> Utf8 Class Initialized
INFO - 2021-12-13 02:44:06 --> URI Class Initialized
INFO - 2021-12-13 02:44:06 --> Router Class Initialized
INFO - 2021-12-13 02:44:06 --> Output Class Initialized
INFO - 2021-12-13 02:44:06 --> Security Class Initialized
DEBUG - 2021-12-13 02:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:44:06 --> Input Class Initialized
INFO - 2021-12-13 02:44:06 --> Language Class Initialized
INFO - 2021-12-13 02:44:06 --> Language Class Initialized
INFO - 2021-12-13 02:44:06 --> Config Class Initialized
INFO - 2021-12-13 02:44:06 --> Loader Class Initialized
INFO - 2021-12-13 02:44:06 --> Helper loaded: url_helper
INFO - 2021-12-13 02:44:06 --> Helper loaded: file_helper
INFO - 2021-12-13 02:44:06 --> Helper loaded: form_helper
INFO - 2021-12-13 02:44:06 --> Helper loaded: my_helper
INFO - 2021-12-13 02:44:06 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:44:06 --> Controller Class Initialized
DEBUG - 2021-12-13 02:44:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:44:06 --> Final output sent to browser
DEBUG - 2021-12-13 02:44:06 --> Total execution time: 0.0650
INFO - 2021-12-13 02:44:07 --> Config Class Initialized
INFO - 2021-12-13 02:44:07 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:44:07 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:44:07 --> Utf8 Class Initialized
INFO - 2021-12-13 02:44:07 --> URI Class Initialized
INFO - 2021-12-13 02:44:07 --> Router Class Initialized
INFO - 2021-12-13 02:44:07 --> Output Class Initialized
INFO - 2021-12-13 02:44:07 --> Security Class Initialized
DEBUG - 2021-12-13 02:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:44:07 --> Input Class Initialized
INFO - 2021-12-13 02:44:07 --> Language Class Initialized
INFO - 2021-12-13 02:44:07 --> Language Class Initialized
INFO - 2021-12-13 02:44:07 --> Config Class Initialized
INFO - 2021-12-13 02:44:07 --> Loader Class Initialized
INFO - 2021-12-13 02:44:07 --> Helper loaded: url_helper
INFO - 2021-12-13 02:44:07 --> Helper loaded: file_helper
INFO - 2021-12-13 02:44:07 --> Helper loaded: form_helper
INFO - 2021-12-13 02:44:07 --> Helper loaded: my_helper
INFO - 2021-12-13 02:44:07 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:44:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:44:07 --> Controller Class Initialized
DEBUG - 2021-12-13 02:44:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:44:07 --> Final output sent to browser
DEBUG - 2021-12-13 02:44:07 --> Total execution time: 0.0680
INFO - 2021-12-13 02:44:10 --> Config Class Initialized
INFO - 2021-12-13 02:44:10 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:44:10 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:44:10 --> Utf8 Class Initialized
INFO - 2021-12-13 02:44:10 --> URI Class Initialized
INFO - 2021-12-13 02:44:10 --> Router Class Initialized
INFO - 2021-12-13 02:44:10 --> Output Class Initialized
INFO - 2021-12-13 02:44:10 --> Security Class Initialized
DEBUG - 2021-12-13 02:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:44:10 --> Input Class Initialized
INFO - 2021-12-13 02:44:10 --> Language Class Initialized
INFO - 2021-12-13 02:44:10 --> Language Class Initialized
INFO - 2021-12-13 02:44:10 --> Config Class Initialized
INFO - 2021-12-13 02:44:10 --> Loader Class Initialized
INFO - 2021-12-13 02:44:10 --> Helper loaded: url_helper
INFO - 2021-12-13 02:44:10 --> Helper loaded: file_helper
INFO - 2021-12-13 02:44:10 --> Helper loaded: form_helper
INFO - 2021-12-13 02:44:10 --> Helper loaded: my_helper
INFO - 2021-12-13 02:44:10 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:44:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:44:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:44:10 --> Controller Class Initialized
DEBUG - 2021-12-13 02:44:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:44:10 --> Final output sent to browser
DEBUG - 2021-12-13 02:44:10 --> Total execution time: 0.0640
INFO - 2021-12-13 02:44:11 --> Config Class Initialized
INFO - 2021-12-13 02:44:11 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:44:11 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:44:11 --> Utf8 Class Initialized
INFO - 2021-12-13 02:44:11 --> URI Class Initialized
INFO - 2021-12-13 02:44:11 --> Router Class Initialized
INFO - 2021-12-13 02:44:11 --> Output Class Initialized
INFO - 2021-12-13 02:44:11 --> Security Class Initialized
DEBUG - 2021-12-13 02:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:44:11 --> Input Class Initialized
INFO - 2021-12-13 02:44:11 --> Language Class Initialized
INFO - 2021-12-13 02:44:11 --> Language Class Initialized
INFO - 2021-12-13 02:44:11 --> Config Class Initialized
INFO - 2021-12-13 02:44:11 --> Loader Class Initialized
INFO - 2021-12-13 02:44:11 --> Helper loaded: url_helper
INFO - 2021-12-13 02:44:11 --> Helper loaded: file_helper
INFO - 2021-12-13 02:44:11 --> Helper loaded: form_helper
INFO - 2021-12-13 02:44:11 --> Helper loaded: my_helper
INFO - 2021-12-13 02:44:11 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:44:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:44:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:44:11 --> Controller Class Initialized
DEBUG - 2021-12-13 02:44:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:44:11 --> Final output sent to browser
DEBUG - 2021-12-13 02:44:11 --> Total execution time: 0.0640
INFO - 2021-12-13 02:44:14 --> Config Class Initialized
INFO - 2021-12-13 02:44:14 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:44:14 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:44:14 --> Utf8 Class Initialized
INFO - 2021-12-13 02:44:14 --> URI Class Initialized
INFO - 2021-12-13 02:44:14 --> Router Class Initialized
INFO - 2021-12-13 02:44:14 --> Output Class Initialized
INFO - 2021-12-13 02:44:14 --> Security Class Initialized
DEBUG - 2021-12-13 02:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:44:14 --> Input Class Initialized
INFO - 2021-12-13 02:44:14 --> Language Class Initialized
INFO - 2021-12-13 02:44:14 --> Language Class Initialized
INFO - 2021-12-13 02:44:14 --> Config Class Initialized
INFO - 2021-12-13 02:44:14 --> Loader Class Initialized
INFO - 2021-12-13 02:44:14 --> Helper loaded: url_helper
INFO - 2021-12-13 02:44:14 --> Helper loaded: file_helper
INFO - 2021-12-13 02:44:14 --> Helper loaded: form_helper
INFO - 2021-12-13 02:44:14 --> Helper loaded: my_helper
INFO - 2021-12-13 02:44:14 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:44:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:44:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:44:14 --> Controller Class Initialized
DEBUG - 2021-12-13 02:44:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:44:14 --> Final output sent to browser
DEBUG - 2021-12-13 02:44:14 --> Total execution time: 0.0680
INFO - 2021-12-13 02:44:16 --> Config Class Initialized
INFO - 2021-12-13 02:44:16 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:44:16 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:44:16 --> Utf8 Class Initialized
INFO - 2021-12-13 02:44:16 --> URI Class Initialized
INFO - 2021-12-13 02:44:16 --> Router Class Initialized
INFO - 2021-12-13 02:44:16 --> Output Class Initialized
INFO - 2021-12-13 02:44:16 --> Security Class Initialized
DEBUG - 2021-12-13 02:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:44:16 --> Input Class Initialized
INFO - 2021-12-13 02:44:16 --> Language Class Initialized
INFO - 2021-12-13 02:44:16 --> Language Class Initialized
INFO - 2021-12-13 02:44:16 --> Config Class Initialized
INFO - 2021-12-13 02:44:16 --> Loader Class Initialized
INFO - 2021-12-13 02:44:16 --> Helper loaded: url_helper
INFO - 2021-12-13 02:44:16 --> Helper loaded: file_helper
INFO - 2021-12-13 02:44:16 --> Helper loaded: form_helper
INFO - 2021-12-13 02:44:16 --> Helper loaded: my_helper
INFO - 2021-12-13 02:44:16 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:44:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:44:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:44:16 --> Controller Class Initialized
DEBUG - 2021-12-13 02:44:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:44:16 --> Final output sent to browser
DEBUG - 2021-12-13 02:44:16 --> Total execution time: 0.0600
INFO - 2021-12-13 02:44:17 --> Config Class Initialized
INFO - 2021-12-13 02:44:17 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:44:17 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:44:17 --> Utf8 Class Initialized
INFO - 2021-12-13 02:44:17 --> URI Class Initialized
INFO - 2021-12-13 02:44:17 --> Router Class Initialized
INFO - 2021-12-13 02:44:17 --> Output Class Initialized
INFO - 2021-12-13 02:44:17 --> Security Class Initialized
DEBUG - 2021-12-13 02:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:44:17 --> Input Class Initialized
INFO - 2021-12-13 02:44:17 --> Language Class Initialized
INFO - 2021-12-13 02:44:17 --> Language Class Initialized
INFO - 2021-12-13 02:44:17 --> Config Class Initialized
INFO - 2021-12-13 02:44:17 --> Loader Class Initialized
INFO - 2021-12-13 02:44:17 --> Helper loaded: url_helper
INFO - 2021-12-13 02:44:17 --> Helper loaded: file_helper
INFO - 2021-12-13 02:44:17 --> Helper loaded: form_helper
INFO - 2021-12-13 02:44:17 --> Helper loaded: my_helper
INFO - 2021-12-13 02:44:17 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:44:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:44:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:44:17 --> Controller Class Initialized
DEBUG - 2021-12-13 02:44:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:44:17 --> Final output sent to browser
DEBUG - 2021-12-13 02:44:17 --> Total execution time: 0.0670
INFO - 2021-12-13 02:44:20 --> Config Class Initialized
INFO - 2021-12-13 02:44:20 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:44:20 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:44:20 --> Utf8 Class Initialized
INFO - 2021-12-13 02:44:20 --> URI Class Initialized
INFO - 2021-12-13 02:44:20 --> Router Class Initialized
INFO - 2021-12-13 02:44:20 --> Output Class Initialized
INFO - 2021-12-13 02:44:20 --> Security Class Initialized
DEBUG - 2021-12-13 02:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:44:20 --> Input Class Initialized
INFO - 2021-12-13 02:44:20 --> Language Class Initialized
INFO - 2021-12-13 02:44:20 --> Language Class Initialized
INFO - 2021-12-13 02:44:20 --> Config Class Initialized
INFO - 2021-12-13 02:44:20 --> Loader Class Initialized
INFO - 2021-12-13 02:44:20 --> Helper loaded: url_helper
INFO - 2021-12-13 02:44:20 --> Helper loaded: file_helper
INFO - 2021-12-13 02:44:20 --> Helper loaded: form_helper
INFO - 2021-12-13 02:44:20 --> Helper loaded: my_helper
INFO - 2021-12-13 02:44:20 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:44:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:44:20 --> Controller Class Initialized
DEBUG - 2021-12-13 02:44:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:44:20 --> Final output sent to browser
DEBUG - 2021-12-13 02:44:20 --> Total execution time: 0.0540
INFO - 2021-12-13 02:44:22 --> Config Class Initialized
INFO - 2021-12-13 02:44:22 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:44:22 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:44:22 --> Utf8 Class Initialized
INFO - 2021-12-13 02:44:22 --> URI Class Initialized
INFO - 2021-12-13 02:44:22 --> Router Class Initialized
INFO - 2021-12-13 02:44:22 --> Output Class Initialized
INFO - 2021-12-13 02:44:22 --> Security Class Initialized
DEBUG - 2021-12-13 02:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:44:22 --> Input Class Initialized
INFO - 2021-12-13 02:44:22 --> Language Class Initialized
INFO - 2021-12-13 02:44:22 --> Language Class Initialized
INFO - 2021-12-13 02:44:22 --> Config Class Initialized
INFO - 2021-12-13 02:44:22 --> Loader Class Initialized
INFO - 2021-12-13 02:44:22 --> Helper loaded: url_helper
INFO - 2021-12-13 02:44:22 --> Helper loaded: file_helper
INFO - 2021-12-13 02:44:22 --> Helper loaded: form_helper
INFO - 2021-12-13 02:44:22 --> Helper loaded: my_helper
INFO - 2021-12-13 02:44:22 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:44:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:44:22 --> Controller Class Initialized
DEBUG - 2021-12-13 02:44:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:44:22 --> Final output sent to browser
DEBUG - 2021-12-13 02:44:22 --> Total execution time: 0.0580
INFO - 2021-12-13 02:44:24 --> Config Class Initialized
INFO - 2021-12-13 02:44:24 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:44:24 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:44:24 --> Utf8 Class Initialized
INFO - 2021-12-13 02:44:24 --> URI Class Initialized
INFO - 2021-12-13 02:44:24 --> Router Class Initialized
INFO - 2021-12-13 02:44:24 --> Output Class Initialized
INFO - 2021-12-13 02:44:24 --> Security Class Initialized
DEBUG - 2021-12-13 02:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:44:24 --> Input Class Initialized
INFO - 2021-12-13 02:44:24 --> Language Class Initialized
INFO - 2021-12-13 02:44:24 --> Language Class Initialized
INFO - 2021-12-13 02:44:24 --> Config Class Initialized
INFO - 2021-12-13 02:44:24 --> Loader Class Initialized
INFO - 2021-12-13 02:44:24 --> Helper loaded: url_helper
INFO - 2021-12-13 02:44:24 --> Helper loaded: file_helper
INFO - 2021-12-13 02:44:24 --> Helper loaded: form_helper
INFO - 2021-12-13 02:44:24 --> Helper loaded: my_helper
INFO - 2021-12-13 02:44:24 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:44:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:44:24 --> Controller Class Initialized
DEBUG - 2021-12-13 02:44:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:44:24 --> Final output sent to browser
DEBUG - 2021-12-13 02:44:24 --> Total execution time: 0.0620
INFO - 2021-12-13 02:44:27 --> Config Class Initialized
INFO - 2021-12-13 02:44:27 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:44:27 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:44:27 --> Utf8 Class Initialized
INFO - 2021-12-13 02:44:27 --> URI Class Initialized
INFO - 2021-12-13 02:44:27 --> Router Class Initialized
INFO - 2021-12-13 02:44:28 --> Output Class Initialized
INFO - 2021-12-13 02:44:28 --> Security Class Initialized
DEBUG - 2021-12-13 02:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:44:28 --> Input Class Initialized
INFO - 2021-12-13 02:44:28 --> Language Class Initialized
INFO - 2021-12-13 02:44:28 --> Language Class Initialized
INFO - 2021-12-13 02:44:28 --> Config Class Initialized
INFO - 2021-12-13 02:44:28 --> Loader Class Initialized
INFO - 2021-12-13 02:44:28 --> Helper loaded: url_helper
INFO - 2021-12-13 02:44:28 --> Helper loaded: file_helper
INFO - 2021-12-13 02:44:28 --> Helper loaded: form_helper
INFO - 2021-12-13 02:44:28 --> Helper loaded: my_helper
INFO - 2021-12-13 02:44:28 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:44:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:44:28 --> Controller Class Initialized
DEBUG - 2021-12-13 02:44:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:44:28 --> Final output sent to browser
DEBUG - 2021-12-13 02:44:28 --> Total execution time: 0.0640
INFO - 2021-12-13 02:44:29 --> Config Class Initialized
INFO - 2021-12-13 02:44:29 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:44:29 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:44:29 --> Utf8 Class Initialized
INFO - 2021-12-13 02:44:29 --> URI Class Initialized
INFO - 2021-12-13 02:44:29 --> Router Class Initialized
INFO - 2021-12-13 02:44:29 --> Output Class Initialized
INFO - 2021-12-13 02:44:29 --> Security Class Initialized
DEBUG - 2021-12-13 02:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:44:29 --> Input Class Initialized
INFO - 2021-12-13 02:44:29 --> Language Class Initialized
INFO - 2021-12-13 02:44:29 --> Language Class Initialized
INFO - 2021-12-13 02:44:29 --> Config Class Initialized
INFO - 2021-12-13 02:44:29 --> Loader Class Initialized
INFO - 2021-12-13 02:44:29 --> Helper loaded: url_helper
INFO - 2021-12-13 02:44:29 --> Helper loaded: file_helper
INFO - 2021-12-13 02:44:29 --> Helper loaded: form_helper
INFO - 2021-12-13 02:44:29 --> Helper loaded: my_helper
INFO - 2021-12-13 02:44:29 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:44:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:44:29 --> Controller Class Initialized
DEBUG - 2021-12-13 02:44:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:44:29 --> Final output sent to browser
DEBUG - 2021-12-13 02:44:29 --> Total execution time: 0.0670
INFO - 2021-12-13 02:44:31 --> Config Class Initialized
INFO - 2021-12-13 02:44:31 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:44:31 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:44:31 --> Utf8 Class Initialized
INFO - 2021-12-13 02:44:31 --> URI Class Initialized
INFO - 2021-12-13 02:44:31 --> Router Class Initialized
INFO - 2021-12-13 02:44:31 --> Output Class Initialized
INFO - 2021-12-13 02:44:31 --> Security Class Initialized
DEBUG - 2021-12-13 02:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:44:31 --> Input Class Initialized
INFO - 2021-12-13 02:44:31 --> Language Class Initialized
INFO - 2021-12-13 02:44:31 --> Language Class Initialized
INFO - 2021-12-13 02:44:31 --> Config Class Initialized
INFO - 2021-12-13 02:44:31 --> Loader Class Initialized
INFO - 2021-12-13 02:44:31 --> Helper loaded: url_helper
INFO - 2021-12-13 02:44:31 --> Helper loaded: file_helper
INFO - 2021-12-13 02:44:31 --> Helper loaded: form_helper
INFO - 2021-12-13 02:44:31 --> Helper loaded: my_helper
INFO - 2021-12-13 02:44:31 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:44:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:44:31 --> Controller Class Initialized
DEBUG - 2021-12-13 02:44:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:44:31 --> Final output sent to browser
DEBUG - 2021-12-13 02:44:31 --> Total execution time: 0.0640
INFO - 2021-12-13 02:44:33 --> Config Class Initialized
INFO - 2021-12-13 02:44:33 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:44:33 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:44:33 --> Utf8 Class Initialized
INFO - 2021-12-13 02:44:33 --> URI Class Initialized
INFO - 2021-12-13 02:44:33 --> Router Class Initialized
INFO - 2021-12-13 02:44:33 --> Output Class Initialized
INFO - 2021-12-13 02:44:33 --> Security Class Initialized
DEBUG - 2021-12-13 02:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:44:33 --> Input Class Initialized
INFO - 2021-12-13 02:44:33 --> Language Class Initialized
INFO - 2021-12-13 02:44:33 --> Language Class Initialized
INFO - 2021-12-13 02:44:33 --> Config Class Initialized
INFO - 2021-12-13 02:44:33 --> Loader Class Initialized
INFO - 2021-12-13 02:44:33 --> Helper loaded: url_helper
INFO - 2021-12-13 02:44:33 --> Helper loaded: file_helper
INFO - 2021-12-13 02:44:33 --> Helper loaded: form_helper
INFO - 2021-12-13 02:44:33 --> Helper loaded: my_helper
INFO - 2021-12-13 02:44:33 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:44:33 --> Controller Class Initialized
DEBUG - 2021-12-13 02:44:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:44:33 --> Final output sent to browser
DEBUG - 2021-12-13 02:44:33 --> Total execution time: 0.0630
INFO - 2021-12-13 02:44:36 --> Config Class Initialized
INFO - 2021-12-13 02:44:36 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:44:36 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:44:36 --> Utf8 Class Initialized
INFO - 2021-12-13 02:44:36 --> URI Class Initialized
INFO - 2021-12-13 02:44:36 --> Router Class Initialized
INFO - 2021-12-13 02:44:36 --> Output Class Initialized
INFO - 2021-12-13 02:44:36 --> Security Class Initialized
DEBUG - 2021-12-13 02:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:44:36 --> Input Class Initialized
INFO - 2021-12-13 02:44:36 --> Language Class Initialized
INFO - 2021-12-13 02:44:36 --> Language Class Initialized
INFO - 2021-12-13 02:44:36 --> Config Class Initialized
INFO - 2021-12-13 02:44:36 --> Loader Class Initialized
INFO - 2021-12-13 02:44:36 --> Helper loaded: url_helper
INFO - 2021-12-13 02:44:36 --> Helper loaded: file_helper
INFO - 2021-12-13 02:44:36 --> Helper loaded: form_helper
INFO - 2021-12-13 02:44:36 --> Helper loaded: my_helper
INFO - 2021-12-13 02:44:36 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:44:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:44:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:44:36 --> Controller Class Initialized
DEBUG - 2021-12-13 02:44:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:44:36 --> Final output sent to browser
DEBUG - 2021-12-13 02:44:36 --> Total execution time: 0.0600
INFO - 2021-12-13 02:44:37 --> Config Class Initialized
INFO - 2021-12-13 02:44:37 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:44:37 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:44:37 --> Utf8 Class Initialized
INFO - 2021-12-13 02:44:37 --> URI Class Initialized
INFO - 2021-12-13 02:44:37 --> Router Class Initialized
INFO - 2021-12-13 02:44:37 --> Output Class Initialized
INFO - 2021-12-13 02:44:37 --> Security Class Initialized
DEBUG - 2021-12-13 02:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:44:37 --> Input Class Initialized
INFO - 2021-12-13 02:44:37 --> Language Class Initialized
INFO - 2021-12-13 02:44:37 --> Language Class Initialized
INFO - 2021-12-13 02:44:37 --> Config Class Initialized
INFO - 2021-12-13 02:44:37 --> Loader Class Initialized
INFO - 2021-12-13 02:44:37 --> Helper loaded: url_helper
INFO - 2021-12-13 02:44:37 --> Helper loaded: file_helper
INFO - 2021-12-13 02:44:37 --> Helper loaded: form_helper
INFO - 2021-12-13 02:44:37 --> Helper loaded: my_helper
INFO - 2021-12-13 02:44:37 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:44:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:44:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:44:37 --> Controller Class Initialized
DEBUG - 2021-12-13 02:44:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:44:37 --> Final output sent to browser
DEBUG - 2021-12-13 02:44:37 --> Total execution time: 0.0650
INFO - 2021-12-13 02:44:40 --> Config Class Initialized
INFO - 2021-12-13 02:44:40 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:44:40 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:44:40 --> Utf8 Class Initialized
INFO - 2021-12-13 02:44:40 --> URI Class Initialized
INFO - 2021-12-13 02:44:40 --> Router Class Initialized
INFO - 2021-12-13 02:44:40 --> Output Class Initialized
INFO - 2021-12-13 02:44:40 --> Security Class Initialized
DEBUG - 2021-12-13 02:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:44:40 --> Input Class Initialized
INFO - 2021-12-13 02:44:40 --> Language Class Initialized
INFO - 2021-12-13 02:44:40 --> Language Class Initialized
INFO - 2021-12-13 02:44:40 --> Config Class Initialized
INFO - 2021-12-13 02:44:40 --> Loader Class Initialized
INFO - 2021-12-13 02:44:40 --> Helper loaded: url_helper
INFO - 2021-12-13 02:44:40 --> Helper loaded: file_helper
INFO - 2021-12-13 02:44:40 --> Helper loaded: form_helper
INFO - 2021-12-13 02:44:40 --> Helper loaded: my_helper
INFO - 2021-12-13 02:44:40 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:44:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:44:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:44:40 --> Controller Class Initialized
DEBUG - 2021-12-13 02:44:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:44:40 --> Final output sent to browser
DEBUG - 2021-12-13 02:44:40 --> Total execution time: 0.0610
INFO - 2021-12-13 02:44:42 --> Config Class Initialized
INFO - 2021-12-13 02:44:42 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:44:42 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:44:42 --> Utf8 Class Initialized
INFO - 2021-12-13 02:44:42 --> URI Class Initialized
INFO - 2021-12-13 02:44:42 --> Router Class Initialized
INFO - 2021-12-13 02:44:42 --> Output Class Initialized
INFO - 2021-12-13 02:44:42 --> Security Class Initialized
DEBUG - 2021-12-13 02:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:44:42 --> Input Class Initialized
INFO - 2021-12-13 02:44:42 --> Language Class Initialized
INFO - 2021-12-13 02:44:42 --> Language Class Initialized
INFO - 2021-12-13 02:44:42 --> Config Class Initialized
INFO - 2021-12-13 02:44:42 --> Loader Class Initialized
INFO - 2021-12-13 02:44:42 --> Helper loaded: url_helper
INFO - 2021-12-13 02:44:42 --> Helper loaded: file_helper
INFO - 2021-12-13 02:44:42 --> Helper loaded: form_helper
INFO - 2021-12-13 02:44:42 --> Helper loaded: my_helper
INFO - 2021-12-13 02:44:42 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:44:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:44:42 --> Controller Class Initialized
DEBUG - 2021-12-13 02:44:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:44:42 --> Final output sent to browser
DEBUG - 2021-12-13 02:44:42 --> Total execution time: 0.0680
INFO - 2021-12-13 02:44:44 --> Config Class Initialized
INFO - 2021-12-13 02:44:44 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:44:44 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:44:44 --> Utf8 Class Initialized
INFO - 2021-12-13 02:44:44 --> URI Class Initialized
INFO - 2021-12-13 02:44:44 --> Router Class Initialized
INFO - 2021-12-13 02:44:44 --> Output Class Initialized
INFO - 2021-12-13 02:44:44 --> Security Class Initialized
DEBUG - 2021-12-13 02:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:44:44 --> Input Class Initialized
INFO - 2021-12-13 02:44:44 --> Language Class Initialized
INFO - 2021-12-13 02:44:44 --> Language Class Initialized
INFO - 2021-12-13 02:44:44 --> Config Class Initialized
INFO - 2021-12-13 02:44:44 --> Loader Class Initialized
INFO - 2021-12-13 02:44:44 --> Helper loaded: url_helper
INFO - 2021-12-13 02:44:44 --> Helper loaded: file_helper
INFO - 2021-12-13 02:44:44 --> Helper loaded: form_helper
INFO - 2021-12-13 02:44:44 --> Helper loaded: my_helper
INFO - 2021-12-13 02:44:44 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:44:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:44:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:44:44 --> Controller Class Initialized
DEBUG - 2021-12-13 02:44:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:44:44 --> Final output sent to browser
DEBUG - 2021-12-13 02:44:44 --> Total execution time: 0.0530
INFO - 2021-12-13 02:44:46 --> Config Class Initialized
INFO - 2021-12-13 02:44:46 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:44:46 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:44:46 --> Utf8 Class Initialized
INFO - 2021-12-13 02:44:46 --> URI Class Initialized
INFO - 2021-12-13 02:44:46 --> Router Class Initialized
INFO - 2021-12-13 02:44:46 --> Output Class Initialized
INFO - 2021-12-13 02:44:46 --> Security Class Initialized
DEBUG - 2021-12-13 02:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:44:46 --> Input Class Initialized
INFO - 2021-12-13 02:44:46 --> Language Class Initialized
INFO - 2021-12-13 02:44:46 --> Language Class Initialized
INFO - 2021-12-13 02:44:46 --> Config Class Initialized
INFO - 2021-12-13 02:44:46 --> Loader Class Initialized
INFO - 2021-12-13 02:44:46 --> Helper loaded: url_helper
INFO - 2021-12-13 02:44:46 --> Helper loaded: file_helper
INFO - 2021-12-13 02:44:46 --> Helper loaded: form_helper
INFO - 2021-12-13 02:44:46 --> Helper loaded: my_helper
INFO - 2021-12-13 02:44:46 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:44:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:44:46 --> Controller Class Initialized
DEBUG - 2021-12-13 02:44:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:44:46 --> Final output sent to browser
DEBUG - 2021-12-13 02:44:46 --> Total execution time: 0.0610
INFO - 2021-12-13 02:44:49 --> Config Class Initialized
INFO - 2021-12-13 02:44:49 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:44:49 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:44:49 --> Utf8 Class Initialized
INFO - 2021-12-13 02:44:49 --> URI Class Initialized
INFO - 2021-12-13 02:44:49 --> Router Class Initialized
INFO - 2021-12-13 02:44:49 --> Output Class Initialized
INFO - 2021-12-13 02:44:49 --> Security Class Initialized
DEBUG - 2021-12-13 02:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:44:49 --> Input Class Initialized
INFO - 2021-12-13 02:44:49 --> Language Class Initialized
INFO - 2021-12-13 02:44:49 --> Language Class Initialized
INFO - 2021-12-13 02:44:49 --> Config Class Initialized
INFO - 2021-12-13 02:44:49 --> Loader Class Initialized
INFO - 2021-12-13 02:44:49 --> Helper loaded: url_helper
INFO - 2021-12-13 02:44:49 --> Helper loaded: file_helper
INFO - 2021-12-13 02:44:49 --> Helper loaded: form_helper
INFO - 2021-12-13 02:44:49 --> Helper loaded: my_helper
INFO - 2021-12-13 02:44:49 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:44:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:44:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:44:49 --> Controller Class Initialized
DEBUG - 2021-12-13 02:44:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:44:49 --> Final output sent to browser
DEBUG - 2021-12-13 02:44:49 --> Total execution time: 0.0700
INFO - 2021-12-13 02:44:51 --> Config Class Initialized
INFO - 2021-12-13 02:44:51 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:44:51 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:44:51 --> Utf8 Class Initialized
INFO - 2021-12-13 02:44:51 --> URI Class Initialized
INFO - 2021-12-13 02:44:51 --> Router Class Initialized
INFO - 2021-12-13 02:44:51 --> Output Class Initialized
INFO - 2021-12-13 02:44:51 --> Security Class Initialized
DEBUG - 2021-12-13 02:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:44:51 --> Input Class Initialized
INFO - 2021-12-13 02:44:51 --> Language Class Initialized
INFO - 2021-12-13 02:44:51 --> Language Class Initialized
INFO - 2021-12-13 02:44:51 --> Config Class Initialized
INFO - 2021-12-13 02:44:51 --> Loader Class Initialized
INFO - 2021-12-13 02:44:51 --> Helper loaded: url_helper
INFO - 2021-12-13 02:44:51 --> Helper loaded: file_helper
INFO - 2021-12-13 02:44:51 --> Helper loaded: form_helper
INFO - 2021-12-13 02:44:51 --> Helper loaded: my_helper
INFO - 2021-12-13 02:44:51 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:44:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:44:51 --> Controller Class Initialized
DEBUG - 2021-12-13 02:44:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:44:51 --> Final output sent to browser
DEBUG - 2021-12-13 02:44:51 --> Total execution time: 0.0640
INFO - 2021-12-13 02:48:07 --> Config Class Initialized
INFO - 2021-12-13 02:48:07 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:48:07 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:48:07 --> Utf8 Class Initialized
INFO - 2021-12-13 02:48:07 --> URI Class Initialized
INFO - 2021-12-13 02:48:07 --> Router Class Initialized
INFO - 2021-12-13 02:48:07 --> Output Class Initialized
INFO - 2021-12-13 02:48:07 --> Security Class Initialized
DEBUG - 2021-12-13 02:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:48:07 --> Input Class Initialized
INFO - 2021-12-13 02:48:07 --> Language Class Initialized
INFO - 2021-12-13 02:48:07 --> Language Class Initialized
INFO - 2021-12-13 02:48:07 --> Config Class Initialized
INFO - 2021-12-13 02:48:07 --> Loader Class Initialized
INFO - 2021-12-13 02:48:07 --> Helper loaded: url_helper
INFO - 2021-12-13 02:48:07 --> Helper loaded: file_helper
INFO - 2021-12-13 02:48:07 --> Helper loaded: form_helper
INFO - 2021-12-13 02:48:07 --> Helper loaded: my_helper
INFO - 2021-12-13 02:48:07 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:48:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:48:07 --> Controller Class Initialized
INFO - 2021-12-13 02:48:07 --> Helper loaded: cookie_helper
INFO - 2021-12-13 02:48:07 --> Config Class Initialized
INFO - 2021-12-13 02:48:07 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:48:07 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:48:07 --> Utf8 Class Initialized
INFO - 2021-12-13 02:48:07 --> URI Class Initialized
INFO - 2021-12-13 02:48:07 --> Router Class Initialized
INFO - 2021-12-13 02:48:07 --> Output Class Initialized
INFO - 2021-12-13 02:48:07 --> Security Class Initialized
DEBUG - 2021-12-13 02:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:48:07 --> Input Class Initialized
INFO - 2021-12-13 02:48:07 --> Language Class Initialized
INFO - 2021-12-13 02:48:07 --> Language Class Initialized
INFO - 2021-12-13 02:48:07 --> Config Class Initialized
INFO - 2021-12-13 02:48:07 --> Loader Class Initialized
INFO - 2021-12-13 02:48:07 --> Helper loaded: url_helper
INFO - 2021-12-13 02:48:07 --> Helper loaded: file_helper
INFO - 2021-12-13 02:48:07 --> Helper loaded: form_helper
INFO - 2021-12-13 02:48:07 --> Helper loaded: my_helper
INFO - 2021-12-13 02:48:07 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:48:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:48:07 --> Controller Class Initialized
DEBUG - 2021-12-13 02:48:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-13 02:48:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 02:48:07 --> Final output sent to browser
DEBUG - 2021-12-13 02:48:07 --> Total execution time: 0.0360
INFO - 2021-12-13 02:48:12 --> Config Class Initialized
INFO - 2021-12-13 02:48:12 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:48:12 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:48:12 --> Utf8 Class Initialized
INFO - 2021-12-13 02:48:12 --> URI Class Initialized
INFO - 2021-12-13 02:48:12 --> Router Class Initialized
INFO - 2021-12-13 02:48:12 --> Output Class Initialized
INFO - 2021-12-13 02:48:12 --> Security Class Initialized
DEBUG - 2021-12-13 02:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:48:12 --> Input Class Initialized
INFO - 2021-12-13 02:48:12 --> Language Class Initialized
INFO - 2021-12-13 02:48:12 --> Language Class Initialized
INFO - 2021-12-13 02:48:12 --> Config Class Initialized
INFO - 2021-12-13 02:48:12 --> Loader Class Initialized
INFO - 2021-12-13 02:48:12 --> Helper loaded: url_helper
INFO - 2021-12-13 02:48:12 --> Helper loaded: file_helper
INFO - 2021-12-13 02:48:12 --> Helper loaded: form_helper
INFO - 2021-12-13 02:48:12 --> Helper loaded: my_helper
INFO - 2021-12-13 02:48:12 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:48:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:48:12 --> Controller Class Initialized
INFO - 2021-12-13 02:48:12 --> Helper loaded: cookie_helper
INFO - 2021-12-13 02:48:12 --> Final output sent to browser
DEBUG - 2021-12-13 02:48:12 --> Total execution time: 0.0650
INFO - 2021-12-13 02:48:12 --> Config Class Initialized
INFO - 2021-12-13 02:48:12 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:48:12 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:48:12 --> Utf8 Class Initialized
INFO - 2021-12-13 02:48:12 --> URI Class Initialized
INFO - 2021-12-13 02:48:12 --> Router Class Initialized
INFO - 2021-12-13 02:48:12 --> Output Class Initialized
INFO - 2021-12-13 02:48:12 --> Security Class Initialized
DEBUG - 2021-12-13 02:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:48:12 --> Input Class Initialized
INFO - 2021-12-13 02:48:12 --> Language Class Initialized
INFO - 2021-12-13 02:48:12 --> Language Class Initialized
INFO - 2021-12-13 02:48:12 --> Config Class Initialized
INFO - 2021-12-13 02:48:12 --> Loader Class Initialized
INFO - 2021-12-13 02:48:12 --> Helper loaded: url_helper
INFO - 2021-12-13 02:48:12 --> Helper loaded: file_helper
INFO - 2021-12-13 02:48:12 --> Helper loaded: form_helper
INFO - 2021-12-13 02:48:12 --> Helper loaded: my_helper
INFO - 2021-12-13 02:48:12 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:48:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:48:12 --> Controller Class Initialized
DEBUG - 2021-12-13 02:48:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-13 02:48:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 02:48:12 --> Final output sent to browser
DEBUG - 2021-12-13 02:48:12 --> Total execution time: 0.2660
INFO - 2021-12-13 02:48:14 --> Config Class Initialized
INFO - 2021-12-13 02:48:14 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:48:14 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:48:14 --> Utf8 Class Initialized
INFO - 2021-12-13 02:48:14 --> URI Class Initialized
INFO - 2021-12-13 02:48:14 --> Router Class Initialized
INFO - 2021-12-13 02:48:14 --> Output Class Initialized
INFO - 2021-12-13 02:48:14 --> Security Class Initialized
DEBUG - 2021-12-13 02:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:48:14 --> Input Class Initialized
INFO - 2021-12-13 02:48:14 --> Language Class Initialized
INFO - 2021-12-13 02:48:14 --> Language Class Initialized
INFO - 2021-12-13 02:48:14 --> Config Class Initialized
INFO - 2021-12-13 02:48:14 --> Loader Class Initialized
INFO - 2021-12-13 02:48:14 --> Helper loaded: url_helper
INFO - 2021-12-13 02:48:14 --> Helper loaded: file_helper
INFO - 2021-12-13 02:48:14 --> Helper loaded: form_helper
INFO - 2021-12-13 02:48:14 --> Helper loaded: my_helper
INFO - 2021-12-13 02:48:14 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:48:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:48:14 --> Controller Class Initialized
DEBUG - 2021-12-13 02:48:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-13 02:48:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 02:48:14 --> Final output sent to browser
DEBUG - 2021-12-13 02:48:14 --> Total execution time: 0.0610
INFO - 2021-12-13 02:48:17 --> Config Class Initialized
INFO - 2021-12-13 02:48:17 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:48:17 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:48:17 --> Utf8 Class Initialized
INFO - 2021-12-13 02:48:17 --> URI Class Initialized
INFO - 2021-12-13 02:48:17 --> Router Class Initialized
INFO - 2021-12-13 02:48:17 --> Output Class Initialized
INFO - 2021-12-13 02:48:17 --> Security Class Initialized
DEBUG - 2021-12-13 02:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:48:17 --> Input Class Initialized
INFO - 2021-12-13 02:48:17 --> Language Class Initialized
INFO - 2021-12-13 02:48:17 --> Language Class Initialized
INFO - 2021-12-13 02:48:17 --> Config Class Initialized
INFO - 2021-12-13 02:48:17 --> Loader Class Initialized
INFO - 2021-12-13 02:48:17 --> Helper loaded: url_helper
INFO - 2021-12-13 02:48:17 --> Helper loaded: file_helper
INFO - 2021-12-13 02:48:17 --> Helper loaded: form_helper
INFO - 2021-12-13 02:48:17 --> Helper loaded: my_helper
INFO - 2021-12-13 02:48:17 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:48:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:48:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:48:17 --> Controller Class Initialized
DEBUG - 2021-12-13 02:48:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:48:17 --> Final output sent to browser
DEBUG - 2021-12-13 02:48:17 --> Total execution time: 0.1080
INFO - 2021-12-13 02:48:19 --> Config Class Initialized
INFO - 2021-12-13 02:48:19 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:48:19 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:48:19 --> Utf8 Class Initialized
INFO - 2021-12-13 02:48:19 --> URI Class Initialized
INFO - 2021-12-13 02:48:19 --> Router Class Initialized
INFO - 2021-12-13 02:48:19 --> Output Class Initialized
INFO - 2021-12-13 02:48:19 --> Security Class Initialized
DEBUG - 2021-12-13 02:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:48:19 --> Input Class Initialized
INFO - 2021-12-13 02:48:19 --> Language Class Initialized
INFO - 2021-12-13 02:48:19 --> Language Class Initialized
INFO - 2021-12-13 02:48:19 --> Config Class Initialized
INFO - 2021-12-13 02:48:19 --> Loader Class Initialized
INFO - 2021-12-13 02:48:19 --> Helper loaded: url_helper
INFO - 2021-12-13 02:48:19 --> Helper loaded: file_helper
INFO - 2021-12-13 02:48:19 --> Helper loaded: form_helper
INFO - 2021-12-13 02:48:19 --> Helper loaded: my_helper
INFO - 2021-12-13 02:48:19 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:48:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:48:19 --> Controller Class Initialized
DEBUG - 2021-12-13 02:48:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:48:19 --> Final output sent to browser
DEBUG - 2021-12-13 02:48:19 --> Total execution time: 0.0610
INFO - 2021-12-13 02:48:21 --> Config Class Initialized
INFO - 2021-12-13 02:48:21 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:48:21 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:48:21 --> Utf8 Class Initialized
INFO - 2021-12-13 02:48:21 --> URI Class Initialized
INFO - 2021-12-13 02:48:21 --> Router Class Initialized
INFO - 2021-12-13 02:48:21 --> Output Class Initialized
INFO - 2021-12-13 02:48:21 --> Security Class Initialized
DEBUG - 2021-12-13 02:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:48:21 --> Input Class Initialized
INFO - 2021-12-13 02:48:21 --> Language Class Initialized
INFO - 2021-12-13 02:48:21 --> Language Class Initialized
INFO - 2021-12-13 02:48:21 --> Config Class Initialized
INFO - 2021-12-13 02:48:21 --> Loader Class Initialized
INFO - 2021-12-13 02:48:21 --> Helper loaded: url_helper
INFO - 2021-12-13 02:48:21 --> Helper loaded: file_helper
INFO - 2021-12-13 02:48:21 --> Helper loaded: form_helper
INFO - 2021-12-13 02:48:21 --> Helper loaded: my_helper
INFO - 2021-12-13 02:48:21 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:48:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:48:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:48:21 --> Controller Class Initialized
DEBUG - 2021-12-13 02:48:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:48:21 --> Final output sent to browser
DEBUG - 2021-12-13 02:48:21 --> Total execution time: 0.0670
INFO - 2021-12-13 02:48:22 --> Config Class Initialized
INFO - 2021-12-13 02:48:22 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:48:22 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:48:22 --> Utf8 Class Initialized
INFO - 2021-12-13 02:48:22 --> URI Class Initialized
INFO - 2021-12-13 02:48:22 --> Router Class Initialized
INFO - 2021-12-13 02:48:22 --> Output Class Initialized
INFO - 2021-12-13 02:48:22 --> Security Class Initialized
DEBUG - 2021-12-13 02:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:48:22 --> Input Class Initialized
INFO - 2021-12-13 02:48:22 --> Language Class Initialized
INFO - 2021-12-13 02:48:22 --> Language Class Initialized
INFO - 2021-12-13 02:48:22 --> Config Class Initialized
INFO - 2021-12-13 02:48:22 --> Loader Class Initialized
INFO - 2021-12-13 02:48:22 --> Helper loaded: url_helper
INFO - 2021-12-13 02:48:22 --> Helper loaded: file_helper
INFO - 2021-12-13 02:48:22 --> Helper loaded: form_helper
INFO - 2021-12-13 02:48:22 --> Helper loaded: my_helper
INFO - 2021-12-13 02:48:22 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:48:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:48:22 --> Controller Class Initialized
DEBUG - 2021-12-13 02:48:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:48:22 --> Final output sent to browser
DEBUG - 2021-12-13 02:48:22 --> Total execution time: 0.0710
INFO - 2021-12-13 02:48:26 --> Config Class Initialized
INFO - 2021-12-13 02:48:26 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:48:26 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:48:26 --> Utf8 Class Initialized
INFO - 2021-12-13 02:48:26 --> URI Class Initialized
INFO - 2021-12-13 02:48:26 --> Router Class Initialized
INFO - 2021-12-13 02:48:26 --> Output Class Initialized
INFO - 2021-12-13 02:48:26 --> Security Class Initialized
DEBUG - 2021-12-13 02:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:48:26 --> Input Class Initialized
INFO - 2021-12-13 02:48:26 --> Language Class Initialized
INFO - 2021-12-13 02:48:26 --> Language Class Initialized
INFO - 2021-12-13 02:48:26 --> Config Class Initialized
INFO - 2021-12-13 02:48:26 --> Loader Class Initialized
INFO - 2021-12-13 02:48:26 --> Helper loaded: url_helper
INFO - 2021-12-13 02:48:26 --> Helper loaded: file_helper
INFO - 2021-12-13 02:48:26 --> Helper loaded: form_helper
INFO - 2021-12-13 02:48:26 --> Helper loaded: my_helper
INFO - 2021-12-13 02:48:26 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:48:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:48:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:48:26 --> Controller Class Initialized
DEBUG - 2021-12-13 02:48:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:48:26 --> Final output sent to browser
DEBUG - 2021-12-13 02:48:26 --> Total execution time: 0.0660
INFO - 2021-12-13 02:48:27 --> Config Class Initialized
INFO - 2021-12-13 02:48:27 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:48:27 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:48:27 --> Utf8 Class Initialized
INFO - 2021-12-13 02:48:27 --> URI Class Initialized
INFO - 2021-12-13 02:48:27 --> Router Class Initialized
INFO - 2021-12-13 02:48:27 --> Output Class Initialized
INFO - 2021-12-13 02:48:27 --> Security Class Initialized
DEBUG - 2021-12-13 02:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:48:27 --> Input Class Initialized
INFO - 2021-12-13 02:48:27 --> Language Class Initialized
INFO - 2021-12-13 02:48:27 --> Language Class Initialized
INFO - 2021-12-13 02:48:27 --> Config Class Initialized
INFO - 2021-12-13 02:48:27 --> Loader Class Initialized
INFO - 2021-12-13 02:48:27 --> Helper loaded: url_helper
INFO - 2021-12-13 02:48:27 --> Helper loaded: file_helper
INFO - 2021-12-13 02:48:27 --> Helper loaded: form_helper
INFO - 2021-12-13 02:48:27 --> Helper loaded: my_helper
INFO - 2021-12-13 02:48:27 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:48:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:48:27 --> Controller Class Initialized
DEBUG - 2021-12-13 02:48:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:48:27 --> Final output sent to browser
DEBUG - 2021-12-13 02:48:27 --> Total execution time: 0.0610
INFO - 2021-12-13 02:48:30 --> Config Class Initialized
INFO - 2021-12-13 02:48:30 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:48:30 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:48:30 --> Utf8 Class Initialized
INFO - 2021-12-13 02:48:30 --> URI Class Initialized
INFO - 2021-12-13 02:48:30 --> Router Class Initialized
INFO - 2021-12-13 02:48:30 --> Output Class Initialized
INFO - 2021-12-13 02:48:30 --> Security Class Initialized
DEBUG - 2021-12-13 02:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:48:30 --> Input Class Initialized
INFO - 2021-12-13 02:48:30 --> Language Class Initialized
INFO - 2021-12-13 02:48:30 --> Language Class Initialized
INFO - 2021-12-13 02:48:30 --> Config Class Initialized
INFO - 2021-12-13 02:48:30 --> Loader Class Initialized
INFO - 2021-12-13 02:48:30 --> Helper loaded: url_helper
INFO - 2021-12-13 02:48:30 --> Helper loaded: file_helper
INFO - 2021-12-13 02:48:30 --> Helper loaded: form_helper
INFO - 2021-12-13 02:48:30 --> Helper loaded: my_helper
INFO - 2021-12-13 02:48:30 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:48:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:48:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:48:30 --> Controller Class Initialized
DEBUG - 2021-12-13 02:48:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:48:30 --> Final output sent to browser
DEBUG - 2021-12-13 02:48:30 --> Total execution time: 0.0670
INFO - 2021-12-13 02:48:32 --> Config Class Initialized
INFO - 2021-12-13 02:48:32 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:48:32 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:48:32 --> Utf8 Class Initialized
INFO - 2021-12-13 02:48:32 --> URI Class Initialized
INFO - 2021-12-13 02:48:32 --> Router Class Initialized
INFO - 2021-12-13 02:48:32 --> Output Class Initialized
INFO - 2021-12-13 02:48:32 --> Security Class Initialized
DEBUG - 2021-12-13 02:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:48:32 --> Input Class Initialized
INFO - 2021-12-13 02:48:32 --> Language Class Initialized
INFO - 2021-12-13 02:48:32 --> Language Class Initialized
INFO - 2021-12-13 02:48:32 --> Config Class Initialized
INFO - 2021-12-13 02:48:32 --> Loader Class Initialized
INFO - 2021-12-13 02:48:32 --> Helper loaded: url_helper
INFO - 2021-12-13 02:48:32 --> Helper loaded: file_helper
INFO - 2021-12-13 02:48:32 --> Helper loaded: form_helper
INFO - 2021-12-13 02:48:32 --> Helper loaded: my_helper
INFO - 2021-12-13 02:48:32 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:48:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:48:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:48:32 --> Controller Class Initialized
DEBUG - 2021-12-13 02:48:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:48:32 --> Final output sent to browser
DEBUG - 2021-12-13 02:48:32 --> Total execution time: 0.0620
INFO - 2021-12-13 02:48:33 --> Config Class Initialized
INFO - 2021-12-13 02:48:33 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:48:33 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:48:33 --> Utf8 Class Initialized
INFO - 2021-12-13 02:48:33 --> URI Class Initialized
INFO - 2021-12-13 02:48:33 --> Router Class Initialized
INFO - 2021-12-13 02:48:33 --> Output Class Initialized
INFO - 2021-12-13 02:48:33 --> Security Class Initialized
DEBUG - 2021-12-13 02:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:48:33 --> Input Class Initialized
INFO - 2021-12-13 02:48:33 --> Language Class Initialized
INFO - 2021-12-13 02:48:33 --> Language Class Initialized
INFO - 2021-12-13 02:48:33 --> Config Class Initialized
INFO - 2021-12-13 02:48:33 --> Loader Class Initialized
INFO - 2021-12-13 02:48:33 --> Helper loaded: url_helper
INFO - 2021-12-13 02:48:33 --> Helper loaded: file_helper
INFO - 2021-12-13 02:48:33 --> Helper loaded: form_helper
INFO - 2021-12-13 02:48:33 --> Helper loaded: my_helper
INFO - 2021-12-13 02:48:33 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:48:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:48:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:48:33 --> Controller Class Initialized
DEBUG - 2021-12-13 02:48:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:48:33 --> Final output sent to browser
DEBUG - 2021-12-13 02:48:33 --> Total execution time: 0.0620
INFO - 2021-12-13 02:48:35 --> Config Class Initialized
INFO - 2021-12-13 02:48:35 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:48:35 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:48:35 --> Utf8 Class Initialized
INFO - 2021-12-13 02:48:35 --> URI Class Initialized
INFO - 2021-12-13 02:48:35 --> Router Class Initialized
INFO - 2021-12-13 02:48:35 --> Output Class Initialized
INFO - 2021-12-13 02:48:35 --> Security Class Initialized
DEBUG - 2021-12-13 02:48:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:48:35 --> Input Class Initialized
INFO - 2021-12-13 02:48:35 --> Language Class Initialized
INFO - 2021-12-13 02:48:35 --> Language Class Initialized
INFO - 2021-12-13 02:48:35 --> Config Class Initialized
INFO - 2021-12-13 02:48:35 --> Loader Class Initialized
INFO - 2021-12-13 02:48:35 --> Helper loaded: url_helper
INFO - 2021-12-13 02:48:35 --> Helper loaded: file_helper
INFO - 2021-12-13 02:48:35 --> Helper loaded: form_helper
INFO - 2021-12-13 02:48:35 --> Helper loaded: my_helper
INFO - 2021-12-13 02:48:35 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:48:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:48:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:48:35 --> Controller Class Initialized
DEBUG - 2021-12-13 02:48:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:48:35 --> Final output sent to browser
DEBUG - 2021-12-13 02:48:35 --> Total execution time: 0.0600
INFO - 2021-12-13 02:48:39 --> Config Class Initialized
INFO - 2021-12-13 02:48:39 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:48:39 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:48:39 --> Utf8 Class Initialized
INFO - 2021-12-13 02:48:39 --> URI Class Initialized
INFO - 2021-12-13 02:48:39 --> Router Class Initialized
INFO - 2021-12-13 02:48:39 --> Output Class Initialized
INFO - 2021-12-13 02:48:39 --> Security Class Initialized
DEBUG - 2021-12-13 02:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:48:39 --> Input Class Initialized
INFO - 2021-12-13 02:48:39 --> Language Class Initialized
INFO - 2021-12-13 02:48:39 --> Language Class Initialized
INFO - 2021-12-13 02:48:39 --> Config Class Initialized
INFO - 2021-12-13 02:48:39 --> Loader Class Initialized
INFO - 2021-12-13 02:48:39 --> Helper loaded: url_helper
INFO - 2021-12-13 02:48:39 --> Helper loaded: file_helper
INFO - 2021-12-13 02:48:39 --> Helper loaded: form_helper
INFO - 2021-12-13 02:48:39 --> Helper loaded: my_helper
INFO - 2021-12-13 02:48:39 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:48:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:48:39 --> Controller Class Initialized
DEBUG - 2021-12-13 02:48:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:48:39 --> Final output sent to browser
DEBUG - 2021-12-13 02:48:39 --> Total execution time: 0.0660
INFO - 2021-12-13 02:48:40 --> Config Class Initialized
INFO - 2021-12-13 02:48:40 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:48:40 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:48:40 --> Utf8 Class Initialized
INFO - 2021-12-13 02:48:40 --> URI Class Initialized
INFO - 2021-12-13 02:48:40 --> Router Class Initialized
INFO - 2021-12-13 02:48:40 --> Output Class Initialized
INFO - 2021-12-13 02:48:40 --> Security Class Initialized
DEBUG - 2021-12-13 02:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:48:40 --> Input Class Initialized
INFO - 2021-12-13 02:48:40 --> Language Class Initialized
INFO - 2021-12-13 02:48:40 --> Language Class Initialized
INFO - 2021-12-13 02:48:40 --> Config Class Initialized
INFO - 2021-12-13 02:48:40 --> Loader Class Initialized
INFO - 2021-12-13 02:48:40 --> Helper loaded: url_helper
INFO - 2021-12-13 02:48:40 --> Helper loaded: file_helper
INFO - 2021-12-13 02:48:40 --> Helper loaded: form_helper
INFO - 2021-12-13 02:48:40 --> Helper loaded: my_helper
INFO - 2021-12-13 02:48:40 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:48:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:48:40 --> Controller Class Initialized
DEBUG - 2021-12-13 02:48:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:48:40 --> Final output sent to browser
DEBUG - 2021-12-13 02:48:40 --> Total execution time: 0.0690
INFO - 2021-12-13 02:48:42 --> Config Class Initialized
INFO - 2021-12-13 02:48:42 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:48:42 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:48:42 --> Utf8 Class Initialized
INFO - 2021-12-13 02:48:42 --> URI Class Initialized
INFO - 2021-12-13 02:48:42 --> Router Class Initialized
INFO - 2021-12-13 02:48:42 --> Output Class Initialized
INFO - 2021-12-13 02:48:42 --> Security Class Initialized
DEBUG - 2021-12-13 02:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:48:42 --> Input Class Initialized
INFO - 2021-12-13 02:48:42 --> Language Class Initialized
INFO - 2021-12-13 02:48:42 --> Language Class Initialized
INFO - 2021-12-13 02:48:42 --> Config Class Initialized
INFO - 2021-12-13 02:48:42 --> Loader Class Initialized
INFO - 2021-12-13 02:48:42 --> Helper loaded: url_helper
INFO - 2021-12-13 02:48:42 --> Helper loaded: file_helper
INFO - 2021-12-13 02:48:42 --> Helper loaded: form_helper
INFO - 2021-12-13 02:48:42 --> Helper loaded: my_helper
INFO - 2021-12-13 02:48:42 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:48:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:48:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:48:42 --> Controller Class Initialized
DEBUG - 2021-12-13 02:48:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:48:42 --> Final output sent to browser
DEBUG - 2021-12-13 02:48:42 --> Total execution time: 0.0520
INFO - 2021-12-13 02:48:43 --> Config Class Initialized
INFO - 2021-12-13 02:48:43 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:48:43 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:48:43 --> Utf8 Class Initialized
INFO - 2021-12-13 02:48:43 --> URI Class Initialized
INFO - 2021-12-13 02:48:43 --> Router Class Initialized
INFO - 2021-12-13 02:48:43 --> Output Class Initialized
INFO - 2021-12-13 02:48:43 --> Security Class Initialized
DEBUG - 2021-12-13 02:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:48:43 --> Input Class Initialized
INFO - 2021-12-13 02:48:43 --> Language Class Initialized
INFO - 2021-12-13 02:48:43 --> Language Class Initialized
INFO - 2021-12-13 02:48:43 --> Config Class Initialized
INFO - 2021-12-13 02:48:43 --> Loader Class Initialized
INFO - 2021-12-13 02:48:43 --> Helper loaded: url_helper
INFO - 2021-12-13 02:48:43 --> Helper loaded: file_helper
INFO - 2021-12-13 02:48:44 --> Helper loaded: form_helper
INFO - 2021-12-13 02:48:44 --> Helper loaded: my_helper
INFO - 2021-12-13 02:48:44 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:48:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:48:44 --> Controller Class Initialized
DEBUG - 2021-12-13 02:48:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:48:44 --> Final output sent to browser
DEBUG - 2021-12-13 02:48:44 --> Total execution time: 0.0580
INFO - 2021-12-13 02:48:49 --> Config Class Initialized
INFO - 2021-12-13 02:48:49 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:48:49 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:48:49 --> Utf8 Class Initialized
INFO - 2021-12-13 02:48:49 --> URI Class Initialized
INFO - 2021-12-13 02:48:49 --> Router Class Initialized
INFO - 2021-12-13 02:48:49 --> Output Class Initialized
INFO - 2021-12-13 02:48:49 --> Security Class Initialized
DEBUG - 2021-12-13 02:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:48:49 --> Input Class Initialized
INFO - 2021-12-13 02:48:49 --> Language Class Initialized
INFO - 2021-12-13 02:48:49 --> Language Class Initialized
INFO - 2021-12-13 02:48:49 --> Config Class Initialized
INFO - 2021-12-13 02:48:49 --> Loader Class Initialized
INFO - 2021-12-13 02:48:49 --> Helper loaded: url_helper
INFO - 2021-12-13 02:48:49 --> Helper loaded: file_helper
INFO - 2021-12-13 02:48:49 --> Helper loaded: form_helper
INFO - 2021-12-13 02:48:49 --> Helper loaded: my_helper
INFO - 2021-12-13 02:48:49 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:48:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:48:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:48:49 --> Controller Class Initialized
DEBUG - 2021-12-13 02:48:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:48:49 --> Final output sent to browser
DEBUG - 2021-12-13 02:48:49 --> Total execution time: 0.0660
INFO - 2021-12-13 02:48:50 --> Config Class Initialized
INFO - 2021-12-13 02:48:50 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:48:50 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:48:50 --> Utf8 Class Initialized
INFO - 2021-12-13 02:48:50 --> URI Class Initialized
INFO - 2021-12-13 02:48:50 --> Router Class Initialized
INFO - 2021-12-13 02:48:50 --> Output Class Initialized
INFO - 2021-12-13 02:48:50 --> Security Class Initialized
DEBUG - 2021-12-13 02:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:48:50 --> Input Class Initialized
INFO - 2021-12-13 02:48:50 --> Language Class Initialized
INFO - 2021-12-13 02:48:50 --> Language Class Initialized
INFO - 2021-12-13 02:48:50 --> Config Class Initialized
INFO - 2021-12-13 02:48:50 --> Loader Class Initialized
INFO - 2021-12-13 02:48:50 --> Helper loaded: url_helper
INFO - 2021-12-13 02:48:50 --> Helper loaded: file_helper
INFO - 2021-12-13 02:48:50 --> Helper loaded: form_helper
INFO - 2021-12-13 02:48:50 --> Helper loaded: my_helper
INFO - 2021-12-13 02:48:50 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:48:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:48:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:48:50 --> Controller Class Initialized
DEBUG - 2021-12-13 02:48:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:48:50 --> Final output sent to browser
DEBUG - 2021-12-13 02:48:50 --> Total execution time: 0.0560
INFO - 2021-12-13 02:48:52 --> Config Class Initialized
INFO - 2021-12-13 02:48:52 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:48:52 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:48:52 --> Utf8 Class Initialized
INFO - 2021-12-13 02:48:52 --> URI Class Initialized
INFO - 2021-12-13 02:48:52 --> Router Class Initialized
INFO - 2021-12-13 02:48:52 --> Output Class Initialized
INFO - 2021-12-13 02:48:52 --> Security Class Initialized
DEBUG - 2021-12-13 02:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:48:52 --> Input Class Initialized
INFO - 2021-12-13 02:48:52 --> Language Class Initialized
INFO - 2021-12-13 02:48:52 --> Language Class Initialized
INFO - 2021-12-13 02:48:52 --> Config Class Initialized
INFO - 2021-12-13 02:48:52 --> Loader Class Initialized
INFO - 2021-12-13 02:48:52 --> Helper loaded: url_helper
INFO - 2021-12-13 02:48:52 --> Helper loaded: file_helper
INFO - 2021-12-13 02:48:52 --> Helper loaded: form_helper
INFO - 2021-12-13 02:48:52 --> Helper loaded: my_helper
INFO - 2021-12-13 02:48:52 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:48:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:48:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:48:52 --> Controller Class Initialized
DEBUG - 2021-12-13 02:48:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:48:52 --> Final output sent to browser
DEBUG - 2021-12-13 02:48:52 --> Total execution time: 0.0620
INFO - 2021-12-13 02:48:55 --> Config Class Initialized
INFO - 2021-12-13 02:48:55 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:48:55 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:48:55 --> Utf8 Class Initialized
INFO - 2021-12-13 02:48:55 --> URI Class Initialized
INFO - 2021-12-13 02:48:55 --> Router Class Initialized
INFO - 2021-12-13 02:48:55 --> Output Class Initialized
INFO - 2021-12-13 02:48:55 --> Security Class Initialized
DEBUG - 2021-12-13 02:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:48:55 --> Input Class Initialized
INFO - 2021-12-13 02:48:55 --> Language Class Initialized
INFO - 2021-12-13 02:48:55 --> Language Class Initialized
INFO - 2021-12-13 02:48:55 --> Config Class Initialized
INFO - 2021-12-13 02:48:55 --> Loader Class Initialized
INFO - 2021-12-13 02:48:55 --> Helper loaded: url_helper
INFO - 2021-12-13 02:48:55 --> Helper loaded: file_helper
INFO - 2021-12-13 02:48:55 --> Helper loaded: form_helper
INFO - 2021-12-13 02:48:55 --> Helper loaded: my_helper
INFO - 2021-12-13 02:48:55 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:48:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:48:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:48:55 --> Controller Class Initialized
DEBUG - 2021-12-13 02:48:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:48:55 --> Final output sent to browser
DEBUG - 2021-12-13 02:48:55 --> Total execution time: 0.0700
INFO - 2021-12-13 02:48:57 --> Config Class Initialized
INFO - 2021-12-13 02:48:57 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:48:57 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:48:57 --> Utf8 Class Initialized
INFO - 2021-12-13 02:48:57 --> URI Class Initialized
INFO - 2021-12-13 02:48:57 --> Router Class Initialized
INFO - 2021-12-13 02:48:57 --> Output Class Initialized
INFO - 2021-12-13 02:48:57 --> Security Class Initialized
DEBUG - 2021-12-13 02:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:48:57 --> Input Class Initialized
INFO - 2021-12-13 02:48:57 --> Language Class Initialized
INFO - 2021-12-13 02:48:57 --> Language Class Initialized
INFO - 2021-12-13 02:48:57 --> Config Class Initialized
INFO - 2021-12-13 02:48:57 --> Loader Class Initialized
INFO - 2021-12-13 02:48:57 --> Helper loaded: url_helper
INFO - 2021-12-13 02:48:57 --> Helper loaded: file_helper
INFO - 2021-12-13 02:48:57 --> Helper loaded: form_helper
INFO - 2021-12-13 02:48:57 --> Helper loaded: my_helper
INFO - 2021-12-13 02:48:57 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:48:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:48:57 --> Controller Class Initialized
DEBUG - 2021-12-13 02:48:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:48:57 --> Final output sent to browser
DEBUG - 2021-12-13 02:48:57 --> Total execution time: 0.0560
INFO - 2021-12-13 02:48:59 --> Config Class Initialized
INFO - 2021-12-13 02:48:59 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:48:59 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:48:59 --> Utf8 Class Initialized
INFO - 2021-12-13 02:48:59 --> URI Class Initialized
INFO - 2021-12-13 02:48:59 --> Router Class Initialized
INFO - 2021-12-13 02:48:59 --> Output Class Initialized
INFO - 2021-12-13 02:48:59 --> Security Class Initialized
DEBUG - 2021-12-13 02:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:48:59 --> Input Class Initialized
INFO - 2021-12-13 02:48:59 --> Language Class Initialized
INFO - 2021-12-13 02:48:59 --> Language Class Initialized
INFO - 2021-12-13 02:48:59 --> Config Class Initialized
INFO - 2021-12-13 02:48:59 --> Loader Class Initialized
INFO - 2021-12-13 02:48:59 --> Helper loaded: url_helper
INFO - 2021-12-13 02:48:59 --> Helper loaded: file_helper
INFO - 2021-12-13 02:48:59 --> Helper loaded: form_helper
INFO - 2021-12-13 02:48:59 --> Helper loaded: my_helper
INFO - 2021-12-13 02:48:59 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:48:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:48:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:48:59 --> Controller Class Initialized
DEBUG - 2021-12-13 02:48:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:48:59 --> Final output sent to browser
DEBUG - 2021-12-13 02:48:59 --> Total execution time: 0.0640
INFO - 2021-12-13 02:49:01 --> Config Class Initialized
INFO - 2021-12-13 02:49:01 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:49:01 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:49:01 --> Utf8 Class Initialized
INFO - 2021-12-13 02:49:01 --> URI Class Initialized
INFO - 2021-12-13 02:49:01 --> Router Class Initialized
INFO - 2021-12-13 02:49:01 --> Output Class Initialized
INFO - 2021-12-13 02:49:01 --> Security Class Initialized
DEBUG - 2021-12-13 02:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:49:01 --> Input Class Initialized
INFO - 2021-12-13 02:49:01 --> Language Class Initialized
INFO - 2021-12-13 02:49:01 --> Language Class Initialized
INFO - 2021-12-13 02:49:01 --> Config Class Initialized
INFO - 2021-12-13 02:49:01 --> Loader Class Initialized
INFO - 2021-12-13 02:49:01 --> Helper loaded: url_helper
INFO - 2021-12-13 02:49:01 --> Helper loaded: file_helper
INFO - 2021-12-13 02:49:01 --> Helper loaded: form_helper
INFO - 2021-12-13 02:49:01 --> Helper loaded: my_helper
INFO - 2021-12-13 02:49:01 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:49:01 --> Controller Class Initialized
DEBUG - 2021-12-13 02:49:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:49:01 --> Final output sent to browser
DEBUG - 2021-12-13 02:49:01 --> Total execution time: 0.0640
INFO - 2021-12-13 02:49:04 --> Config Class Initialized
INFO - 2021-12-13 02:49:04 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:49:04 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:49:04 --> Utf8 Class Initialized
INFO - 2021-12-13 02:49:04 --> URI Class Initialized
INFO - 2021-12-13 02:49:04 --> Router Class Initialized
INFO - 2021-12-13 02:49:04 --> Output Class Initialized
INFO - 2021-12-13 02:49:04 --> Security Class Initialized
DEBUG - 2021-12-13 02:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:49:04 --> Input Class Initialized
INFO - 2021-12-13 02:49:04 --> Language Class Initialized
INFO - 2021-12-13 02:49:04 --> Language Class Initialized
INFO - 2021-12-13 02:49:04 --> Config Class Initialized
INFO - 2021-12-13 02:49:04 --> Loader Class Initialized
INFO - 2021-12-13 02:49:04 --> Helper loaded: url_helper
INFO - 2021-12-13 02:49:04 --> Helper loaded: file_helper
INFO - 2021-12-13 02:49:04 --> Helper loaded: form_helper
INFO - 2021-12-13 02:49:04 --> Helper loaded: my_helper
INFO - 2021-12-13 02:49:04 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:49:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:49:04 --> Controller Class Initialized
DEBUG - 2021-12-13 02:49:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:49:04 --> Final output sent to browser
DEBUG - 2021-12-13 02:49:04 --> Total execution time: 0.0660
INFO - 2021-12-13 02:49:06 --> Config Class Initialized
INFO - 2021-12-13 02:49:06 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:49:06 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:49:06 --> Utf8 Class Initialized
INFO - 2021-12-13 02:49:06 --> URI Class Initialized
INFO - 2021-12-13 02:49:06 --> Router Class Initialized
INFO - 2021-12-13 02:49:06 --> Output Class Initialized
INFO - 2021-12-13 02:49:06 --> Security Class Initialized
DEBUG - 2021-12-13 02:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:49:06 --> Input Class Initialized
INFO - 2021-12-13 02:49:06 --> Language Class Initialized
INFO - 2021-12-13 02:49:06 --> Language Class Initialized
INFO - 2021-12-13 02:49:06 --> Config Class Initialized
INFO - 2021-12-13 02:49:06 --> Loader Class Initialized
INFO - 2021-12-13 02:49:06 --> Helper loaded: url_helper
INFO - 2021-12-13 02:49:06 --> Helper loaded: file_helper
INFO - 2021-12-13 02:49:06 --> Helper loaded: form_helper
INFO - 2021-12-13 02:49:06 --> Helper loaded: my_helper
INFO - 2021-12-13 02:49:06 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:49:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:49:06 --> Controller Class Initialized
DEBUG - 2021-12-13 02:49:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:49:06 --> Final output sent to browser
DEBUG - 2021-12-13 02:49:06 --> Total execution time: 0.0660
INFO - 2021-12-13 02:52:16 --> Config Class Initialized
INFO - 2021-12-13 02:52:16 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:52:16 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:52:16 --> Utf8 Class Initialized
INFO - 2021-12-13 02:52:16 --> URI Class Initialized
INFO - 2021-12-13 02:52:16 --> Router Class Initialized
INFO - 2021-12-13 02:52:16 --> Output Class Initialized
INFO - 2021-12-13 02:52:16 --> Security Class Initialized
DEBUG - 2021-12-13 02:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:52:16 --> Input Class Initialized
INFO - 2021-12-13 02:52:16 --> Language Class Initialized
INFO - 2021-12-13 02:52:16 --> Language Class Initialized
INFO - 2021-12-13 02:52:16 --> Config Class Initialized
INFO - 2021-12-13 02:52:16 --> Loader Class Initialized
INFO - 2021-12-13 02:52:16 --> Helper loaded: url_helper
INFO - 2021-12-13 02:52:16 --> Helper loaded: file_helper
INFO - 2021-12-13 02:52:16 --> Helper loaded: form_helper
INFO - 2021-12-13 02:52:16 --> Helper loaded: my_helper
INFO - 2021-12-13 02:52:16 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:52:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:52:16 --> Controller Class Initialized
INFO - 2021-12-13 02:52:16 --> Helper loaded: cookie_helper
INFO - 2021-12-13 02:52:16 --> Config Class Initialized
INFO - 2021-12-13 02:52:16 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:52:16 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:52:16 --> Utf8 Class Initialized
INFO - 2021-12-13 02:52:16 --> URI Class Initialized
INFO - 2021-12-13 02:52:16 --> Router Class Initialized
INFO - 2021-12-13 02:52:16 --> Output Class Initialized
INFO - 2021-12-13 02:52:16 --> Security Class Initialized
DEBUG - 2021-12-13 02:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:52:16 --> Input Class Initialized
INFO - 2021-12-13 02:52:16 --> Language Class Initialized
INFO - 2021-12-13 02:52:16 --> Language Class Initialized
INFO - 2021-12-13 02:52:16 --> Config Class Initialized
INFO - 2021-12-13 02:52:16 --> Loader Class Initialized
INFO - 2021-12-13 02:52:16 --> Helper loaded: url_helper
INFO - 2021-12-13 02:52:16 --> Helper loaded: file_helper
INFO - 2021-12-13 02:52:16 --> Helper loaded: form_helper
INFO - 2021-12-13 02:52:16 --> Helper loaded: my_helper
INFO - 2021-12-13 02:52:16 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:52:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:52:16 --> Controller Class Initialized
DEBUG - 2021-12-13 02:52:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-13 02:52:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 02:52:16 --> Final output sent to browser
DEBUG - 2021-12-13 02:52:16 --> Total execution time: 0.0380
INFO - 2021-12-13 02:52:22 --> Config Class Initialized
INFO - 2021-12-13 02:52:22 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:52:22 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:52:22 --> Utf8 Class Initialized
INFO - 2021-12-13 02:52:22 --> URI Class Initialized
INFO - 2021-12-13 02:52:22 --> Router Class Initialized
INFO - 2021-12-13 02:52:22 --> Output Class Initialized
INFO - 2021-12-13 02:52:22 --> Security Class Initialized
DEBUG - 2021-12-13 02:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:52:22 --> Input Class Initialized
INFO - 2021-12-13 02:52:22 --> Language Class Initialized
INFO - 2021-12-13 02:52:22 --> Language Class Initialized
INFO - 2021-12-13 02:52:22 --> Config Class Initialized
INFO - 2021-12-13 02:52:22 --> Loader Class Initialized
INFO - 2021-12-13 02:52:22 --> Helper loaded: url_helper
INFO - 2021-12-13 02:52:22 --> Helper loaded: file_helper
INFO - 2021-12-13 02:52:22 --> Helper loaded: form_helper
INFO - 2021-12-13 02:52:22 --> Helper loaded: my_helper
INFO - 2021-12-13 02:52:22 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:52:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:52:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:52:22 --> Controller Class Initialized
INFO - 2021-12-13 02:52:22 --> Helper loaded: cookie_helper
INFO - 2021-12-13 02:52:22 --> Final output sent to browser
DEBUG - 2021-12-13 02:52:22 --> Total execution time: 0.0610
INFO - 2021-12-13 02:52:22 --> Config Class Initialized
INFO - 2021-12-13 02:52:22 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:52:22 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:52:22 --> Utf8 Class Initialized
INFO - 2021-12-13 02:52:22 --> URI Class Initialized
INFO - 2021-12-13 02:52:22 --> Router Class Initialized
INFO - 2021-12-13 02:52:22 --> Output Class Initialized
INFO - 2021-12-13 02:52:22 --> Security Class Initialized
DEBUG - 2021-12-13 02:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:52:22 --> Input Class Initialized
INFO - 2021-12-13 02:52:22 --> Language Class Initialized
INFO - 2021-12-13 02:52:22 --> Language Class Initialized
INFO - 2021-12-13 02:52:22 --> Config Class Initialized
INFO - 2021-12-13 02:52:22 --> Loader Class Initialized
INFO - 2021-12-13 02:52:22 --> Helper loaded: url_helper
INFO - 2021-12-13 02:52:22 --> Helper loaded: file_helper
INFO - 2021-12-13 02:52:22 --> Helper loaded: form_helper
INFO - 2021-12-13 02:52:22 --> Helper loaded: my_helper
INFO - 2021-12-13 02:52:22 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:52:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:52:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:52:22 --> Controller Class Initialized
DEBUG - 2021-12-13 02:52:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-13 02:52:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 02:52:22 --> Final output sent to browser
DEBUG - 2021-12-13 02:52:22 --> Total execution time: 0.2290
INFO - 2021-12-13 02:52:24 --> Config Class Initialized
INFO - 2021-12-13 02:52:24 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:52:24 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:52:24 --> Utf8 Class Initialized
INFO - 2021-12-13 02:52:24 --> URI Class Initialized
INFO - 2021-12-13 02:52:24 --> Router Class Initialized
INFO - 2021-12-13 02:52:24 --> Output Class Initialized
INFO - 2021-12-13 02:52:24 --> Security Class Initialized
DEBUG - 2021-12-13 02:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:52:24 --> Input Class Initialized
INFO - 2021-12-13 02:52:24 --> Language Class Initialized
INFO - 2021-12-13 02:52:24 --> Language Class Initialized
INFO - 2021-12-13 02:52:24 --> Config Class Initialized
INFO - 2021-12-13 02:52:24 --> Loader Class Initialized
INFO - 2021-12-13 02:52:24 --> Helper loaded: url_helper
INFO - 2021-12-13 02:52:24 --> Helper loaded: file_helper
INFO - 2021-12-13 02:52:24 --> Helper loaded: form_helper
INFO - 2021-12-13 02:52:24 --> Helper loaded: my_helper
INFO - 2021-12-13 02:52:24 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:52:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:52:24 --> Controller Class Initialized
DEBUG - 2021-12-13 02:52:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-13 02:52:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 02:52:24 --> Final output sent to browser
DEBUG - 2021-12-13 02:52:24 --> Total execution time: 0.0550
INFO - 2021-12-13 02:52:28 --> Config Class Initialized
INFO - 2021-12-13 02:52:28 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:52:28 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:52:28 --> Utf8 Class Initialized
INFO - 2021-12-13 02:52:28 --> URI Class Initialized
INFO - 2021-12-13 02:52:28 --> Router Class Initialized
INFO - 2021-12-13 02:52:28 --> Output Class Initialized
INFO - 2021-12-13 02:52:28 --> Security Class Initialized
DEBUG - 2021-12-13 02:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:52:28 --> Input Class Initialized
INFO - 2021-12-13 02:52:28 --> Language Class Initialized
INFO - 2021-12-13 02:52:28 --> Language Class Initialized
INFO - 2021-12-13 02:52:28 --> Config Class Initialized
INFO - 2021-12-13 02:52:28 --> Loader Class Initialized
INFO - 2021-12-13 02:52:28 --> Helper loaded: url_helper
INFO - 2021-12-13 02:52:28 --> Helper loaded: file_helper
INFO - 2021-12-13 02:52:28 --> Helper loaded: form_helper
INFO - 2021-12-13 02:52:28 --> Helper loaded: my_helper
INFO - 2021-12-13 02:52:28 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:52:28 --> Controller Class Initialized
DEBUG - 2021-12-13 02:52:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:52:28 --> Final output sent to browser
DEBUG - 2021-12-13 02:52:28 --> Total execution time: 0.1010
INFO - 2021-12-13 02:52:30 --> Config Class Initialized
INFO - 2021-12-13 02:52:30 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:52:30 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:52:30 --> Utf8 Class Initialized
INFO - 2021-12-13 02:52:30 --> URI Class Initialized
INFO - 2021-12-13 02:52:30 --> Router Class Initialized
INFO - 2021-12-13 02:52:30 --> Output Class Initialized
INFO - 2021-12-13 02:52:30 --> Security Class Initialized
DEBUG - 2021-12-13 02:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:52:30 --> Input Class Initialized
INFO - 2021-12-13 02:52:30 --> Language Class Initialized
INFO - 2021-12-13 02:52:30 --> Language Class Initialized
INFO - 2021-12-13 02:52:30 --> Config Class Initialized
INFO - 2021-12-13 02:52:30 --> Loader Class Initialized
INFO - 2021-12-13 02:52:30 --> Helper loaded: url_helper
INFO - 2021-12-13 02:52:30 --> Helper loaded: file_helper
INFO - 2021-12-13 02:52:30 --> Helper loaded: form_helper
INFO - 2021-12-13 02:52:30 --> Helper loaded: my_helper
INFO - 2021-12-13 02:52:30 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:52:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:52:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:52:30 --> Controller Class Initialized
DEBUG - 2021-12-13 02:52:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:52:30 --> Final output sent to browser
DEBUG - 2021-12-13 02:52:30 --> Total execution time: 0.0580
INFO - 2021-12-13 02:52:31 --> Config Class Initialized
INFO - 2021-12-13 02:52:31 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:52:31 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:52:31 --> Utf8 Class Initialized
INFO - 2021-12-13 02:52:31 --> URI Class Initialized
INFO - 2021-12-13 02:52:31 --> Router Class Initialized
INFO - 2021-12-13 02:52:31 --> Output Class Initialized
INFO - 2021-12-13 02:52:31 --> Security Class Initialized
DEBUG - 2021-12-13 02:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:52:31 --> Input Class Initialized
INFO - 2021-12-13 02:52:31 --> Language Class Initialized
INFO - 2021-12-13 02:52:31 --> Language Class Initialized
INFO - 2021-12-13 02:52:31 --> Config Class Initialized
INFO - 2021-12-13 02:52:31 --> Loader Class Initialized
INFO - 2021-12-13 02:52:31 --> Helper loaded: url_helper
INFO - 2021-12-13 02:52:31 --> Helper loaded: file_helper
INFO - 2021-12-13 02:52:31 --> Helper loaded: form_helper
INFO - 2021-12-13 02:52:31 --> Helper loaded: my_helper
INFO - 2021-12-13 02:52:31 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:52:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:52:31 --> Controller Class Initialized
DEBUG - 2021-12-13 02:52:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:52:31 --> Final output sent to browser
DEBUG - 2021-12-13 02:52:31 --> Total execution time: 0.0670
INFO - 2021-12-13 02:52:32 --> Config Class Initialized
INFO - 2021-12-13 02:52:32 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:52:32 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:52:32 --> Utf8 Class Initialized
INFO - 2021-12-13 02:52:32 --> URI Class Initialized
INFO - 2021-12-13 02:52:32 --> Router Class Initialized
INFO - 2021-12-13 02:52:32 --> Output Class Initialized
INFO - 2021-12-13 02:52:32 --> Security Class Initialized
DEBUG - 2021-12-13 02:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:52:32 --> Input Class Initialized
INFO - 2021-12-13 02:52:32 --> Language Class Initialized
INFO - 2021-12-13 02:52:32 --> Language Class Initialized
INFO - 2021-12-13 02:52:32 --> Config Class Initialized
INFO - 2021-12-13 02:52:32 --> Loader Class Initialized
INFO - 2021-12-13 02:52:32 --> Helper loaded: url_helper
INFO - 2021-12-13 02:52:32 --> Helper loaded: file_helper
INFO - 2021-12-13 02:52:32 --> Helper loaded: form_helper
INFO - 2021-12-13 02:52:32 --> Helper loaded: my_helper
INFO - 2021-12-13 02:52:32 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:52:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:52:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:52:32 --> Controller Class Initialized
DEBUG - 2021-12-13 02:52:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:52:32 --> Final output sent to browser
DEBUG - 2021-12-13 02:52:32 --> Total execution time: 0.0620
INFO - 2021-12-13 02:52:36 --> Config Class Initialized
INFO - 2021-12-13 02:52:36 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:52:36 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:52:36 --> Utf8 Class Initialized
INFO - 2021-12-13 02:52:36 --> URI Class Initialized
INFO - 2021-12-13 02:52:36 --> Router Class Initialized
INFO - 2021-12-13 02:52:36 --> Output Class Initialized
INFO - 2021-12-13 02:52:36 --> Security Class Initialized
DEBUG - 2021-12-13 02:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:52:36 --> Input Class Initialized
INFO - 2021-12-13 02:52:36 --> Language Class Initialized
INFO - 2021-12-13 02:52:36 --> Language Class Initialized
INFO - 2021-12-13 02:52:36 --> Config Class Initialized
INFO - 2021-12-13 02:52:36 --> Loader Class Initialized
INFO - 2021-12-13 02:52:36 --> Helper loaded: url_helper
INFO - 2021-12-13 02:52:36 --> Helper loaded: file_helper
INFO - 2021-12-13 02:52:36 --> Helper loaded: form_helper
INFO - 2021-12-13 02:52:36 --> Helper loaded: my_helper
INFO - 2021-12-13 02:52:36 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:52:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:52:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:52:36 --> Controller Class Initialized
DEBUG - 2021-12-13 02:52:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-13 02:52:36 --> Final output sent to browser
DEBUG - 2021-12-13 02:52:36 --> Total execution time: 0.0570
INFO - 2021-12-13 02:53:14 --> Config Class Initialized
INFO - 2021-12-13 02:53:14 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:53:14 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:53:14 --> Utf8 Class Initialized
INFO - 2021-12-13 02:53:14 --> URI Class Initialized
INFO - 2021-12-13 02:53:14 --> Router Class Initialized
INFO - 2021-12-13 02:53:14 --> Output Class Initialized
INFO - 2021-12-13 02:53:14 --> Security Class Initialized
DEBUG - 2021-12-13 02:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:53:14 --> Input Class Initialized
INFO - 2021-12-13 02:53:14 --> Language Class Initialized
INFO - 2021-12-13 02:53:14 --> Language Class Initialized
INFO - 2021-12-13 02:53:14 --> Config Class Initialized
INFO - 2021-12-13 02:53:14 --> Loader Class Initialized
INFO - 2021-12-13 02:53:14 --> Helper loaded: url_helper
INFO - 2021-12-13 02:53:14 --> Helper loaded: file_helper
INFO - 2021-12-13 02:53:14 --> Helper loaded: form_helper
INFO - 2021-12-13 02:53:14 --> Helper loaded: my_helper
INFO - 2021-12-13 02:53:14 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:53:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:53:14 --> Controller Class Initialized
INFO - 2021-12-13 02:53:14 --> Helper loaded: cookie_helper
INFO - 2021-12-13 02:53:14 --> Config Class Initialized
INFO - 2021-12-13 02:53:14 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:53:14 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:53:14 --> Utf8 Class Initialized
INFO - 2021-12-13 02:53:14 --> URI Class Initialized
INFO - 2021-12-13 02:53:14 --> Router Class Initialized
INFO - 2021-12-13 02:53:14 --> Output Class Initialized
INFO - 2021-12-13 02:53:14 --> Security Class Initialized
DEBUG - 2021-12-13 02:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:53:14 --> Input Class Initialized
INFO - 2021-12-13 02:53:14 --> Language Class Initialized
INFO - 2021-12-13 02:53:14 --> Language Class Initialized
INFO - 2021-12-13 02:53:14 --> Config Class Initialized
INFO - 2021-12-13 02:53:14 --> Loader Class Initialized
INFO - 2021-12-13 02:53:14 --> Helper loaded: url_helper
INFO - 2021-12-13 02:53:14 --> Helper loaded: file_helper
INFO - 2021-12-13 02:53:14 --> Helper loaded: form_helper
INFO - 2021-12-13 02:53:14 --> Helper loaded: my_helper
INFO - 2021-12-13 02:53:14 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:53:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:53:14 --> Controller Class Initialized
DEBUG - 2021-12-13 02:53:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-13 02:53:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 02:53:14 --> Final output sent to browser
DEBUG - 2021-12-13 02:53:14 --> Total execution time: 0.0440
INFO - 2021-12-13 02:53:18 --> Config Class Initialized
INFO - 2021-12-13 02:53:18 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:53:18 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:53:18 --> Utf8 Class Initialized
INFO - 2021-12-13 02:53:18 --> URI Class Initialized
INFO - 2021-12-13 02:53:18 --> Router Class Initialized
INFO - 2021-12-13 02:53:18 --> Output Class Initialized
INFO - 2021-12-13 02:53:18 --> Security Class Initialized
DEBUG - 2021-12-13 02:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:53:18 --> Input Class Initialized
INFO - 2021-12-13 02:53:18 --> Language Class Initialized
INFO - 2021-12-13 02:53:18 --> Language Class Initialized
INFO - 2021-12-13 02:53:18 --> Config Class Initialized
INFO - 2021-12-13 02:53:18 --> Loader Class Initialized
INFO - 2021-12-13 02:53:18 --> Helper loaded: url_helper
INFO - 2021-12-13 02:53:18 --> Helper loaded: file_helper
INFO - 2021-12-13 02:53:18 --> Helper loaded: form_helper
INFO - 2021-12-13 02:53:18 --> Helper loaded: my_helper
INFO - 2021-12-13 02:53:18 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:53:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:53:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:53:18 --> Controller Class Initialized
INFO - 2021-12-13 02:53:18 --> Helper loaded: cookie_helper
INFO - 2021-12-13 02:53:18 --> Final output sent to browser
DEBUG - 2021-12-13 02:53:18 --> Total execution time: 0.0590
INFO - 2021-12-13 02:53:18 --> Config Class Initialized
INFO - 2021-12-13 02:53:18 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:53:18 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:53:18 --> Utf8 Class Initialized
INFO - 2021-12-13 02:53:18 --> URI Class Initialized
INFO - 2021-12-13 02:53:18 --> Router Class Initialized
INFO - 2021-12-13 02:53:18 --> Output Class Initialized
INFO - 2021-12-13 02:53:18 --> Security Class Initialized
DEBUG - 2021-12-13 02:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:53:18 --> Input Class Initialized
INFO - 2021-12-13 02:53:18 --> Language Class Initialized
INFO - 2021-12-13 02:53:18 --> Language Class Initialized
INFO - 2021-12-13 02:53:18 --> Config Class Initialized
INFO - 2021-12-13 02:53:18 --> Loader Class Initialized
INFO - 2021-12-13 02:53:18 --> Helper loaded: url_helper
INFO - 2021-12-13 02:53:18 --> Helper loaded: file_helper
INFO - 2021-12-13 02:53:18 --> Helper loaded: form_helper
INFO - 2021-12-13 02:53:18 --> Helper loaded: my_helper
INFO - 2021-12-13 02:53:18 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:53:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:53:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:53:18 --> Controller Class Initialized
DEBUG - 2021-12-13 02:53:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-13 02:53:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 02:53:18 --> Final output sent to browser
DEBUG - 2021-12-13 02:53:18 --> Total execution time: 0.2290
INFO - 2021-12-13 02:53:22 --> Config Class Initialized
INFO - 2021-12-13 02:53:22 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:53:22 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:53:22 --> Utf8 Class Initialized
INFO - 2021-12-13 02:53:22 --> URI Class Initialized
INFO - 2021-12-13 02:53:22 --> Router Class Initialized
INFO - 2021-12-13 02:53:22 --> Output Class Initialized
INFO - 2021-12-13 02:53:22 --> Security Class Initialized
DEBUG - 2021-12-13 02:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:53:22 --> Input Class Initialized
INFO - 2021-12-13 02:53:22 --> Language Class Initialized
INFO - 2021-12-13 02:53:22 --> Language Class Initialized
INFO - 2021-12-13 02:53:22 --> Config Class Initialized
INFO - 2021-12-13 02:53:22 --> Loader Class Initialized
INFO - 2021-12-13 02:53:22 --> Helper loaded: url_helper
INFO - 2021-12-13 02:53:22 --> Helper loaded: file_helper
INFO - 2021-12-13 02:53:22 --> Helper loaded: form_helper
INFO - 2021-12-13 02:53:22 --> Helper loaded: my_helper
INFO - 2021-12-13 02:53:22 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:53:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:53:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:53:22 --> Controller Class Initialized
DEBUG - 2021-12-13 02:53:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-13 02:53:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 02:53:22 --> Final output sent to browser
DEBUG - 2021-12-13 02:53:22 --> Total execution time: 0.0600
INFO - 2021-12-13 02:53:27 --> Config Class Initialized
INFO - 2021-12-13 02:53:27 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:53:27 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:53:27 --> Utf8 Class Initialized
INFO - 2021-12-13 02:53:27 --> URI Class Initialized
INFO - 2021-12-13 02:53:27 --> Router Class Initialized
INFO - 2021-12-13 02:53:27 --> Output Class Initialized
INFO - 2021-12-13 02:53:27 --> Security Class Initialized
DEBUG - 2021-12-13 02:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:53:27 --> Input Class Initialized
INFO - 2021-12-13 02:53:27 --> Language Class Initialized
INFO - 2021-12-13 02:53:27 --> Language Class Initialized
INFO - 2021-12-13 02:53:27 --> Config Class Initialized
INFO - 2021-12-13 02:53:27 --> Loader Class Initialized
INFO - 2021-12-13 02:53:27 --> Helper loaded: url_helper
INFO - 2021-12-13 02:53:27 --> Helper loaded: file_helper
INFO - 2021-12-13 02:53:27 --> Helper loaded: form_helper
INFO - 2021-12-13 02:53:27 --> Helper loaded: my_helper
INFO - 2021-12-13 02:53:27 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:53:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:53:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:53:27 --> Controller Class Initialized
DEBUG - 2021-12-13 02:53:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-12-13 02:53:27 --> Final output sent to browser
DEBUG - 2021-12-13 02:53:27 --> Total execution time: 0.1110
INFO - 2021-12-13 02:53:33 --> Config Class Initialized
INFO - 2021-12-13 02:53:33 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:53:33 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:53:33 --> Utf8 Class Initialized
INFO - 2021-12-13 02:53:33 --> URI Class Initialized
INFO - 2021-12-13 02:53:33 --> Router Class Initialized
INFO - 2021-12-13 02:53:33 --> Output Class Initialized
INFO - 2021-12-13 02:53:33 --> Security Class Initialized
DEBUG - 2021-12-13 02:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:53:33 --> Input Class Initialized
INFO - 2021-12-13 02:53:33 --> Language Class Initialized
INFO - 2021-12-13 02:53:33 --> Language Class Initialized
INFO - 2021-12-13 02:53:33 --> Config Class Initialized
INFO - 2021-12-13 02:53:33 --> Loader Class Initialized
INFO - 2021-12-13 02:53:33 --> Helper loaded: url_helper
INFO - 2021-12-13 02:53:33 --> Helper loaded: file_helper
INFO - 2021-12-13 02:53:33 --> Helper loaded: form_helper
INFO - 2021-12-13 02:53:33 --> Helper loaded: my_helper
INFO - 2021-12-13 02:53:33 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:53:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:53:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:53:33 --> Controller Class Initialized
DEBUG - 2021-12-13 02:53:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-12-13 02:53:33 --> Final output sent to browser
DEBUG - 2021-12-13 02:53:33 --> Total execution time: 0.0680
INFO - 2021-12-13 02:53:35 --> Config Class Initialized
INFO - 2021-12-13 02:53:35 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:53:35 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:53:35 --> Utf8 Class Initialized
INFO - 2021-12-13 02:53:35 --> URI Class Initialized
INFO - 2021-12-13 02:53:35 --> Router Class Initialized
INFO - 2021-12-13 02:53:35 --> Output Class Initialized
INFO - 2021-12-13 02:53:35 --> Security Class Initialized
DEBUG - 2021-12-13 02:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:53:35 --> Input Class Initialized
INFO - 2021-12-13 02:53:35 --> Language Class Initialized
INFO - 2021-12-13 02:53:35 --> Language Class Initialized
INFO - 2021-12-13 02:53:35 --> Config Class Initialized
INFO - 2021-12-13 02:53:35 --> Loader Class Initialized
INFO - 2021-12-13 02:53:35 --> Helper loaded: url_helper
INFO - 2021-12-13 02:53:35 --> Helper loaded: file_helper
INFO - 2021-12-13 02:53:35 --> Helper loaded: form_helper
INFO - 2021-12-13 02:53:35 --> Helper loaded: my_helper
INFO - 2021-12-13 02:53:35 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:53:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:53:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:53:36 --> Controller Class Initialized
DEBUG - 2021-12-13 02:53:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-12-13 02:53:36 --> Final output sent to browser
DEBUG - 2021-12-13 02:53:36 --> Total execution time: 0.0730
INFO - 2021-12-13 02:53:39 --> Config Class Initialized
INFO - 2021-12-13 02:53:39 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:53:39 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:53:39 --> Utf8 Class Initialized
INFO - 2021-12-13 02:53:39 --> URI Class Initialized
INFO - 2021-12-13 02:53:39 --> Router Class Initialized
INFO - 2021-12-13 02:53:39 --> Output Class Initialized
INFO - 2021-12-13 02:53:39 --> Security Class Initialized
DEBUG - 2021-12-13 02:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:53:39 --> Input Class Initialized
INFO - 2021-12-13 02:53:39 --> Language Class Initialized
INFO - 2021-12-13 02:53:39 --> Language Class Initialized
INFO - 2021-12-13 02:53:39 --> Config Class Initialized
INFO - 2021-12-13 02:53:39 --> Loader Class Initialized
INFO - 2021-12-13 02:53:39 --> Helper loaded: url_helper
INFO - 2021-12-13 02:53:39 --> Helper loaded: file_helper
INFO - 2021-12-13 02:53:39 --> Helper loaded: form_helper
INFO - 2021-12-13 02:53:39 --> Helper loaded: my_helper
INFO - 2021-12-13 02:53:39 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:53:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:53:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:53:39 --> Controller Class Initialized
DEBUG - 2021-12-13 02:53:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-12-13 02:53:39 --> Final output sent to browser
DEBUG - 2021-12-13 02:53:39 --> Total execution time: 0.0620
INFO - 2021-12-13 02:53:41 --> Config Class Initialized
INFO - 2021-12-13 02:53:41 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:53:41 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:53:41 --> Utf8 Class Initialized
INFO - 2021-12-13 02:53:41 --> URI Class Initialized
INFO - 2021-12-13 02:53:41 --> Router Class Initialized
INFO - 2021-12-13 02:53:41 --> Output Class Initialized
INFO - 2021-12-13 02:53:41 --> Security Class Initialized
DEBUG - 2021-12-13 02:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:53:41 --> Input Class Initialized
INFO - 2021-12-13 02:53:41 --> Language Class Initialized
INFO - 2021-12-13 02:53:41 --> Language Class Initialized
INFO - 2021-12-13 02:53:41 --> Config Class Initialized
INFO - 2021-12-13 02:53:41 --> Loader Class Initialized
INFO - 2021-12-13 02:53:41 --> Helper loaded: url_helper
INFO - 2021-12-13 02:53:41 --> Helper loaded: file_helper
INFO - 2021-12-13 02:53:41 --> Helper loaded: form_helper
INFO - 2021-12-13 02:53:41 --> Helper loaded: my_helper
INFO - 2021-12-13 02:53:41 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:53:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:53:41 --> Controller Class Initialized
DEBUG - 2021-12-13 02:53:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-12-13 02:53:41 --> Final output sent to browser
DEBUG - 2021-12-13 02:53:41 --> Total execution time: 0.0650
INFO - 2021-12-13 02:53:43 --> Config Class Initialized
INFO - 2021-12-13 02:53:43 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:53:43 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:53:43 --> Utf8 Class Initialized
INFO - 2021-12-13 02:53:43 --> URI Class Initialized
INFO - 2021-12-13 02:53:43 --> Router Class Initialized
INFO - 2021-12-13 02:53:43 --> Output Class Initialized
INFO - 2021-12-13 02:53:43 --> Security Class Initialized
DEBUG - 2021-12-13 02:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:53:43 --> Input Class Initialized
INFO - 2021-12-13 02:53:43 --> Language Class Initialized
INFO - 2021-12-13 02:53:43 --> Language Class Initialized
INFO - 2021-12-13 02:53:43 --> Config Class Initialized
INFO - 2021-12-13 02:53:43 --> Loader Class Initialized
INFO - 2021-12-13 02:53:43 --> Helper loaded: url_helper
INFO - 2021-12-13 02:53:43 --> Helper loaded: file_helper
INFO - 2021-12-13 02:53:43 --> Helper loaded: form_helper
INFO - 2021-12-13 02:53:43 --> Helper loaded: my_helper
INFO - 2021-12-13 02:53:43 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:53:43 --> Controller Class Initialized
DEBUG - 2021-12-13 02:53:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-12-13 02:53:43 --> Final output sent to browser
DEBUG - 2021-12-13 02:53:43 --> Total execution time: 0.0620
INFO - 2021-12-13 02:53:47 --> Config Class Initialized
INFO - 2021-12-13 02:53:47 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:53:47 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:53:47 --> Utf8 Class Initialized
INFO - 2021-12-13 02:53:47 --> URI Class Initialized
INFO - 2021-12-13 02:53:47 --> Router Class Initialized
INFO - 2021-12-13 02:53:47 --> Output Class Initialized
INFO - 2021-12-13 02:53:47 --> Security Class Initialized
DEBUG - 2021-12-13 02:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:53:47 --> Input Class Initialized
INFO - 2021-12-13 02:53:47 --> Language Class Initialized
INFO - 2021-12-13 02:53:47 --> Language Class Initialized
INFO - 2021-12-13 02:53:47 --> Config Class Initialized
INFO - 2021-12-13 02:53:47 --> Loader Class Initialized
INFO - 2021-12-13 02:53:47 --> Helper loaded: url_helper
INFO - 2021-12-13 02:53:47 --> Helper loaded: file_helper
INFO - 2021-12-13 02:53:47 --> Helper loaded: form_helper
INFO - 2021-12-13 02:53:47 --> Helper loaded: my_helper
INFO - 2021-12-13 02:53:47 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:53:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:53:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:53:47 --> Controller Class Initialized
DEBUG - 2021-12-13 02:53:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-12-13 02:53:47 --> Final output sent to browser
DEBUG - 2021-12-13 02:53:47 --> Total execution time: 0.0670
INFO - 2021-12-13 02:53:49 --> Config Class Initialized
INFO - 2021-12-13 02:53:49 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:53:49 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:53:49 --> Utf8 Class Initialized
INFO - 2021-12-13 02:53:49 --> URI Class Initialized
INFO - 2021-12-13 02:53:49 --> Router Class Initialized
INFO - 2021-12-13 02:53:49 --> Output Class Initialized
INFO - 2021-12-13 02:53:49 --> Security Class Initialized
DEBUG - 2021-12-13 02:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:53:49 --> Input Class Initialized
INFO - 2021-12-13 02:53:49 --> Language Class Initialized
INFO - 2021-12-13 02:53:49 --> Language Class Initialized
INFO - 2021-12-13 02:53:49 --> Config Class Initialized
INFO - 2021-12-13 02:53:49 --> Loader Class Initialized
INFO - 2021-12-13 02:53:49 --> Helper loaded: url_helper
INFO - 2021-12-13 02:53:49 --> Helper loaded: file_helper
INFO - 2021-12-13 02:53:49 --> Helper loaded: form_helper
INFO - 2021-12-13 02:53:49 --> Helper loaded: my_helper
INFO - 2021-12-13 02:53:49 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:53:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:53:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:53:49 --> Controller Class Initialized
DEBUG - 2021-12-13 02:53:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-12-13 02:53:49 --> Final output sent to browser
DEBUG - 2021-12-13 02:53:49 --> Total execution time: 0.0650
INFO - 2021-12-13 02:53:51 --> Config Class Initialized
INFO - 2021-12-13 02:53:51 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:53:51 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:53:51 --> Utf8 Class Initialized
INFO - 2021-12-13 02:53:51 --> URI Class Initialized
INFO - 2021-12-13 02:53:51 --> Router Class Initialized
INFO - 2021-12-13 02:53:51 --> Output Class Initialized
INFO - 2021-12-13 02:53:51 --> Security Class Initialized
DEBUG - 2021-12-13 02:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:53:51 --> Input Class Initialized
INFO - 2021-12-13 02:53:51 --> Language Class Initialized
INFO - 2021-12-13 02:53:51 --> Language Class Initialized
INFO - 2021-12-13 02:53:51 --> Config Class Initialized
INFO - 2021-12-13 02:53:51 --> Loader Class Initialized
INFO - 2021-12-13 02:53:51 --> Helper loaded: url_helper
INFO - 2021-12-13 02:53:51 --> Helper loaded: file_helper
INFO - 2021-12-13 02:53:51 --> Helper loaded: form_helper
INFO - 2021-12-13 02:53:51 --> Helper loaded: my_helper
INFO - 2021-12-13 02:53:51 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:53:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:53:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:53:51 --> Controller Class Initialized
DEBUG - 2021-12-13 02:53:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-12-13 02:53:51 --> Final output sent to browser
DEBUG - 2021-12-13 02:53:51 --> Total execution time: 0.0670
INFO - 2021-12-13 02:53:54 --> Config Class Initialized
INFO - 2021-12-13 02:53:54 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:53:54 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:53:54 --> Utf8 Class Initialized
INFO - 2021-12-13 02:53:54 --> URI Class Initialized
INFO - 2021-12-13 02:53:54 --> Router Class Initialized
INFO - 2021-12-13 02:53:54 --> Output Class Initialized
INFO - 2021-12-13 02:53:54 --> Security Class Initialized
DEBUG - 2021-12-13 02:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:53:54 --> Input Class Initialized
INFO - 2021-12-13 02:53:54 --> Language Class Initialized
INFO - 2021-12-13 02:53:54 --> Language Class Initialized
INFO - 2021-12-13 02:53:54 --> Config Class Initialized
INFO - 2021-12-13 02:53:54 --> Loader Class Initialized
INFO - 2021-12-13 02:53:54 --> Helper loaded: url_helper
INFO - 2021-12-13 02:53:54 --> Helper loaded: file_helper
INFO - 2021-12-13 02:53:54 --> Helper loaded: form_helper
INFO - 2021-12-13 02:53:54 --> Helper loaded: my_helper
INFO - 2021-12-13 02:53:54 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:53:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:53:54 --> Controller Class Initialized
DEBUG - 2021-12-13 02:53:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-12-13 02:53:54 --> Final output sent to browser
DEBUG - 2021-12-13 02:53:54 --> Total execution time: 0.0650
INFO - 2021-12-13 02:53:56 --> Config Class Initialized
INFO - 2021-12-13 02:53:56 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:53:56 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:53:56 --> Utf8 Class Initialized
INFO - 2021-12-13 02:53:56 --> URI Class Initialized
INFO - 2021-12-13 02:53:56 --> Router Class Initialized
INFO - 2021-12-13 02:53:56 --> Output Class Initialized
INFO - 2021-12-13 02:53:56 --> Security Class Initialized
DEBUG - 2021-12-13 02:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:53:56 --> Input Class Initialized
INFO - 2021-12-13 02:53:56 --> Language Class Initialized
INFO - 2021-12-13 02:53:56 --> Language Class Initialized
INFO - 2021-12-13 02:53:56 --> Config Class Initialized
INFO - 2021-12-13 02:53:56 --> Loader Class Initialized
INFO - 2021-12-13 02:53:56 --> Helper loaded: url_helper
INFO - 2021-12-13 02:53:56 --> Helper loaded: file_helper
INFO - 2021-12-13 02:53:56 --> Helper loaded: form_helper
INFO - 2021-12-13 02:53:56 --> Helper loaded: my_helper
INFO - 2021-12-13 02:53:56 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:53:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:53:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:53:56 --> Controller Class Initialized
DEBUG - 2021-12-13 02:53:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-12-13 02:53:56 --> Final output sent to browser
DEBUG - 2021-12-13 02:53:56 --> Total execution time: 0.0620
INFO - 2021-12-13 02:53:58 --> Config Class Initialized
INFO - 2021-12-13 02:53:58 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:53:58 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:53:58 --> Utf8 Class Initialized
INFO - 2021-12-13 02:53:58 --> URI Class Initialized
INFO - 2021-12-13 02:53:58 --> Router Class Initialized
INFO - 2021-12-13 02:53:58 --> Output Class Initialized
INFO - 2021-12-13 02:53:58 --> Security Class Initialized
DEBUG - 2021-12-13 02:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:53:58 --> Input Class Initialized
INFO - 2021-12-13 02:53:58 --> Language Class Initialized
INFO - 2021-12-13 02:53:58 --> Language Class Initialized
INFO - 2021-12-13 02:53:58 --> Config Class Initialized
INFO - 2021-12-13 02:53:58 --> Loader Class Initialized
INFO - 2021-12-13 02:53:58 --> Helper loaded: url_helper
INFO - 2021-12-13 02:53:58 --> Helper loaded: file_helper
INFO - 2021-12-13 02:53:58 --> Helper loaded: form_helper
INFO - 2021-12-13 02:53:58 --> Helper loaded: my_helper
INFO - 2021-12-13 02:53:58 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:53:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:53:58 --> Controller Class Initialized
DEBUG - 2021-12-13 02:53:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-12-13 02:53:58 --> Final output sent to browser
DEBUG - 2021-12-13 02:53:58 --> Total execution time: 0.0630
INFO - 2021-12-13 02:54:01 --> Config Class Initialized
INFO - 2021-12-13 02:54:01 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:54:01 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:54:01 --> Utf8 Class Initialized
INFO - 2021-12-13 02:54:01 --> URI Class Initialized
INFO - 2021-12-13 02:54:01 --> Router Class Initialized
INFO - 2021-12-13 02:54:01 --> Output Class Initialized
INFO - 2021-12-13 02:54:01 --> Security Class Initialized
DEBUG - 2021-12-13 02:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:54:01 --> Input Class Initialized
INFO - 2021-12-13 02:54:01 --> Language Class Initialized
INFO - 2021-12-13 02:54:01 --> Language Class Initialized
INFO - 2021-12-13 02:54:01 --> Config Class Initialized
INFO - 2021-12-13 02:54:01 --> Loader Class Initialized
INFO - 2021-12-13 02:54:01 --> Helper loaded: url_helper
INFO - 2021-12-13 02:54:01 --> Helper loaded: file_helper
INFO - 2021-12-13 02:54:01 --> Helper loaded: form_helper
INFO - 2021-12-13 02:54:01 --> Helper loaded: my_helper
INFO - 2021-12-13 02:54:01 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:54:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:54:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:54:01 --> Controller Class Initialized
DEBUG - 2021-12-13 02:54:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-12-13 02:54:01 --> Final output sent to browser
DEBUG - 2021-12-13 02:54:01 --> Total execution time: 0.0540
INFO - 2021-12-13 02:54:03 --> Config Class Initialized
INFO - 2021-12-13 02:54:03 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:54:03 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:54:03 --> Utf8 Class Initialized
INFO - 2021-12-13 02:54:03 --> URI Class Initialized
INFO - 2021-12-13 02:54:03 --> Router Class Initialized
INFO - 2021-12-13 02:54:03 --> Output Class Initialized
INFO - 2021-12-13 02:54:03 --> Security Class Initialized
DEBUG - 2021-12-13 02:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:54:03 --> Input Class Initialized
INFO - 2021-12-13 02:54:03 --> Language Class Initialized
INFO - 2021-12-13 02:54:03 --> Language Class Initialized
INFO - 2021-12-13 02:54:03 --> Config Class Initialized
INFO - 2021-12-13 02:54:03 --> Loader Class Initialized
INFO - 2021-12-13 02:54:03 --> Helper loaded: url_helper
INFO - 2021-12-13 02:54:03 --> Helper loaded: file_helper
INFO - 2021-12-13 02:54:03 --> Helper loaded: form_helper
INFO - 2021-12-13 02:54:03 --> Helper loaded: my_helper
INFO - 2021-12-13 02:54:03 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:54:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:54:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:54:03 --> Controller Class Initialized
DEBUG - 2021-12-13 02:54:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-12-13 02:54:03 --> Final output sent to browser
DEBUG - 2021-12-13 02:54:03 --> Total execution time: 0.0650
INFO - 2021-12-13 02:54:05 --> Config Class Initialized
INFO - 2021-12-13 02:54:05 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:54:05 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:54:05 --> Utf8 Class Initialized
INFO - 2021-12-13 02:54:05 --> URI Class Initialized
INFO - 2021-12-13 02:54:05 --> Router Class Initialized
INFO - 2021-12-13 02:54:05 --> Output Class Initialized
INFO - 2021-12-13 02:54:05 --> Security Class Initialized
DEBUG - 2021-12-13 02:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:54:05 --> Input Class Initialized
INFO - 2021-12-13 02:54:05 --> Language Class Initialized
INFO - 2021-12-13 02:54:05 --> Language Class Initialized
INFO - 2021-12-13 02:54:05 --> Config Class Initialized
INFO - 2021-12-13 02:54:05 --> Loader Class Initialized
INFO - 2021-12-13 02:54:05 --> Helper loaded: url_helper
INFO - 2021-12-13 02:54:05 --> Helper loaded: file_helper
INFO - 2021-12-13 02:54:05 --> Helper loaded: form_helper
INFO - 2021-12-13 02:54:05 --> Helper loaded: my_helper
INFO - 2021-12-13 02:54:05 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:54:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:54:05 --> Controller Class Initialized
DEBUG - 2021-12-13 02:54:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-12-13 02:54:05 --> Final output sent to browser
DEBUG - 2021-12-13 02:54:05 --> Total execution time: 0.0730
INFO - 2021-12-13 02:54:08 --> Config Class Initialized
INFO - 2021-12-13 02:54:08 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:54:08 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:54:08 --> Utf8 Class Initialized
INFO - 2021-12-13 02:54:08 --> URI Class Initialized
INFO - 2021-12-13 02:54:08 --> Router Class Initialized
INFO - 2021-12-13 02:54:08 --> Output Class Initialized
INFO - 2021-12-13 02:54:08 --> Security Class Initialized
DEBUG - 2021-12-13 02:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:54:08 --> Input Class Initialized
INFO - 2021-12-13 02:54:08 --> Language Class Initialized
INFO - 2021-12-13 02:54:08 --> Language Class Initialized
INFO - 2021-12-13 02:54:08 --> Config Class Initialized
INFO - 2021-12-13 02:54:08 --> Loader Class Initialized
INFO - 2021-12-13 02:54:08 --> Helper loaded: url_helper
INFO - 2021-12-13 02:54:08 --> Helper loaded: file_helper
INFO - 2021-12-13 02:54:08 --> Helper loaded: form_helper
INFO - 2021-12-13 02:54:08 --> Helper loaded: my_helper
INFO - 2021-12-13 02:54:08 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:54:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:54:08 --> Controller Class Initialized
DEBUG - 2021-12-13 02:54:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-12-13 02:54:08 --> Final output sent to browser
DEBUG - 2021-12-13 02:54:08 --> Total execution time: 0.0670
INFO - 2021-12-13 02:56:25 --> Config Class Initialized
INFO - 2021-12-13 02:56:25 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:56:25 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:56:25 --> Utf8 Class Initialized
INFO - 2021-12-13 02:56:25 --> URI Class Initialized
INFO - 2021-12-13 02:56:25 --> Router Class Initialized
INFO - 2021-12-13 02:56:25 --> Output Class Initialized
INFO - 2021-12-13 02:56:25 --> Security Class Initialized
DEBUG - 2021-12-13 02:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:56:25 --> Input Class Initialized
INFO - 2021-12-13 02:56:25 --> Language Class Initialized
INFO - 2021-12-13 02:56:25 --> Language Class Initialized
INFO - 2021-12-13 02:56:25 --> Config Class Initialized
INFO - 2021-12-13 02:56:25 --> Loader Class Initialized
INFO - 2021-12-13 02:56:25 --> Helper loaded: url_helper
INFO - 2021-12-13 02:56:25 --> Helper loaded: file_helper
INFO - 2021-12-13 02:56:25 --> Helper loaded: form_helper
INFO - 2021-12-13 02:56:25 --> Helper loaded: my_helper
INFO - 2021-12-13 02:56:25 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:56:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:56:25 --> Controller Class Initialized
INFO - 2021-12-13 02:56:25 --> Helper loaded: cookie_helper
INFO - 2021-12-13 02:56:25 --> Config Class Initialized
INFO - 2021-12-13 02:56:25 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:56:25 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:56:25 --> Utf8 Class Initialized
INFO - 2021-12-13 02:56:25 --> URI Class Initialized
INFO - 2021-12-13 02:56:25 --> Router Class Initialized
INFO - 2021-12-13 02:56:25 --> Output Class Initialized
INFO - 2021-12-13 02:56:25 --> Security Class Initialized
DEBUG - 2021-12-13 02:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:56:25 --> Input Class Initialized
INFO - 2021-12-13 02:56:25 --> Language Class Initialized
INFO - 2021-12-13 02:56:25 --> Language Class Initialized
INFO - 2021-12-13 02:56:25 --> Config Class Initialized
INFO - 2021-12-13 02:56:25 --> Loader Class Initialized
INFO - 2021-12-13 02:56:25 --> Helper loaded: url_helper
INFO - 2021-12-13 02:56:25 --> Helper loaded: file_helper
INFO - 2021-12-13 02:56:25 --> Helper loaded: form_helper
INFO - 2021-12-13 02:56:25 --> Helper loaded: my_helper
INFO - 2021-12-13 02:56:25 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:56:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:56:25 --> Controller Class Initialized
DEBUG - 2021-12-13 02:56:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-13 02:56:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 02:56:25 --> Final output sent to browser
DEBUG - 2021-12-13 02:56:25 --> Total execution time: 0.0370
INFO - 2021-12-13 02:56:31 --> Config Class Initialized
INFO - 2021-12-13 02:56:31 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:56:31 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:56:31 --> Utf8 Class Initialized
INFO - 2021-12-13 02:56:31 --> URI Class Initialized
INFO - 2021-12-13 02:56:31 --> Router Class Initialized
INFO - 2021-12-13 02:56:31 --> Output Class Initialized
INFO - 2021-12-13 02:56:31 --> Security Class Initialized
DEBUG - 2021-12-13 02:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:56:31 --> Input Class Initialized
INFO - 2021-12-13 02:56:31 --> Language Class Initialized
INFO - 2021-12-13 02:56:31 --> Language Class Initialized
INFO - 2021-12-13 02:56:31 --> Config Class Initialized
INFO - 2021-12-13 02:56:31 --> Loader Class Initialized
INFO - 2021-12-13 02:56:31 --> Helper loaded: url_helper
INFO - 2021-12-13 02:56:31 --> Helper loaded: file_helper
INFO - 2021-12-13 02:56:31 --> Helper loaded: form_helper
INFO - 2021-12-13 02:56:31 --> Helper loaded: my_helper
INFO - 2021-12-13 02:56:31 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:56:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:56:31 --> Controller Class Initialized
INFO - 2021-12-13 02:56:31 --> Helper loaded: cookie_helper
INFO - 2021-12-13 02:56:31 --> Final output sent to browser
DEBUG - 2021-12-13 02:56:31 --> Total execution time: 0.0510
INFO - 2021-12-13 02:56:31 --> Config Class Initialized
INFO - 2021-12-13 02:56:31 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:56:31 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:56:31 --> Utf8 Class Initialized
INFO - 2021-12-13 02:56:31 --> URI Class Initialized
INFO - 2021-12-13 02:56:31 --> Router Class Initialized
INFO - 2021-12-13 02:56:31 --> Output Class Initialized
INFO - 2021-12-13 02:56:31 --> Security Class Initialized
DEBUG - 2021-12-13 02:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:56:31 --> Input Class Initialized
INFO - 2021-12-13 02:56:31 --> Language Class Initialized
INFO - 2021-12-13 02:56:31 --> Language Class Initialized
INFO - 2021-12-13 02:56:31 --> Config Class Initialized
INFO - 2021-12-13 02:56:31 --> Loader Class Initialized
INFO - 2021-12-13 02:56:31 --> Helper loaded: url_helper
INFO - 2021-12-13 02:56:31 --> Helper loaded: file_helper
INFO - 2021-12-13 02:56:31 --> Helper loaded: form_helper
INFO - 2021-12-13 02:56:31 --> Helper loaded: my_helper
INFO - 2021-12-13 02:56:31 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:56:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:56:31 --> Controller Class Initialized
DEBUG - 2021-12-13 02:56:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-13 02:56:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 02:56:31 --> Final output sent to browser
DEBUG - 2021-12-13 02:56:31 --> Total execution time: 0.2150
INFO - 2021-12-13 02:56:55 --> Config Class Initialized
INFO - 2021-12-13 02:56:55 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:56:55 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:56:55 --> Utf8 Class Initialized
INFO - 2021-12-13 02:56:55 --> URI Class Initialized
INFO - 2021-12-13 02:56:55 --> Router Class Initialized
INFO - 2021-12-13 02:56:55 --> Output Class Initialized
INFO - 2021-12-13 02:56:55 --> Security Class Initialized
DEBUG - 2021-12-13 02:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:56:55 --> Input Class Initialized
INFO - 2021-12-13 02:56:55 --> Language Class Initialized
INFO - 2021-12-13 02:56:55 --> Language Class Initialized
INFO - 2021-12-13 02:56:55 --> Config Class Initialized
INFO - 2021-12-13 02:56:55 --> Loader Class Initialized
INFO - 2021-12-13 02:56:55 --> Helper loaded: url_helper
INFO - 2021-12-13 02:56:55 --> Helper loaded: file_helper
INFO - 2021-12-13 02:56:55 --> Helper loaded: form_helper
INFO - 2021-12-13 02:56:55 --> Helper loaded: my_helper
INFO - 2021-12-13 02:56:55 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:56:55 --> Controller Class Initialized
DEBUG - 2021-12-13 02:56:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-12-13 02:56:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 02:56:55 --> Final output sent to browser
DEBUG - 2021-12-13 02:56:55 --> Total execution time: 0.0420
INFO - 2021-12-13 02:56:55 --> Config Class Initialized
INFO - 2021-12-13 02:56:55 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:56:55 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:56:55 --> Utf8 Class Initialized
INFO - 2021-12-13 02:56:55 --> URI Class Initialized
INFO - 2021-12-13 02:56:55 --> Router Class Initialized
INFO - 2021-12-13 02:56:55 --> Output Class Initialized
INFO - 2021-12-13 02:56:55 --> Security Class Initialized
DEBUG - 2021-12-13 02:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:56:55 --> Input Class Initialized
INFO - 2021-12-13 02:56:55 --> Language Class Initialized
INFO - 2021-12-13 02:56:55 --> Language Class Initialized
INFO - 2021-12-13 02:56:55 --> Config Class Initialized
INFO - 2021-12-13 02:56:55 --> Loader Class Initialized
INFO - 2021-12-13 02:56:55 --> Helper loaded: url_helper
INFO - 2021-12-13 02:56:55 --> Helper loaded: file_helper
INFO - 2021-12-13 02:56:55 --> Helper loaded: form_helper
INFO - 2021-12-13 02:56:55 --> Helper loaded: my_helper
INFO - 2021-12-13 02:56:55 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:56:55 --> Controller Class Initialized
INFO - 2021-12-13 02:56:57 --> Config Class Initialized
INFO - 2021-12-13 02:56:57 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:56:57 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:56:57 --> Utf8 Class Initialized
INFO - 2021-12-13 02:56:57 --> URI Class Initialized
INFO - 2021-12-13 02:56:57 --> Router Class Initialized
INFO - 2021-12-13 02:56:57 --> Output Class Initialized
INFO - 2021-12-13 02:56:57 --> Security Class Initialized
DEBUG - 2021-12-13 02:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:56:57 --> Input Class Initialized
INFO - 2021-12-13 02:56:57 --> Language Class Initialized
INFO - 2021-12-13 02:56:57 --> Language Class Initialized
INFO - 2021-12-13 02:56:57 --> Config Class Initialized
INFO - 2021-12-13 02:56:57 --> Loader Class Initialized
INFO - 2021-12-13 02:56:57 --> Helper loaded: url_helper
INFO - 2021-12-13 02:56:57 --> Helper loaded: file_helper
INFO - 2021-12-13 02:56:57 --> Helper loaded: form_helper
INFO - 2021-12-13 02:56:57 --> Helper loaded: my_helper
INFO - 2021-12-13 02:56:57 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:56:57 --> Controller Class Initialized
INFO - 2021-12-13 02:56:57 --> Final output sent to browser
DEBUG - 2021-12-13 02:56:57 --> Total execution time: 0.0600
INFO - 2021-12-13 02:56:57 --> Config Class Initialized
INFO - 2021-12-13 02:56:57 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:56:57 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:56:57 --> Utf8 Class Initialized
INFO - 2021-12-13 02:56:57 --> URI Class Initialized
INFO - 2021-12-13 02:56:57 --> Router Class Initialized
INFO - 2021-12-13 02:56:57 --> Output Class Initialized
INFO - 2021-12-13 02:56:57 --> Security Class Initialized
DEBUG - 2021-12-13 02:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:56:57 --> Input Class Initialized
INFO - 2021-12-13 02:56:57 --> Language Class Initialized
INFO - 2021-12-13 02:56:57 --> Language Class Initialized
INFO - 2021-12-13 02:56:57 --> Config Class Initialized
INFO - 2021-12-13 02:56:57 --> Loader Class Initialized
INFO - 2021-12-13 02:56:57 --> Helper loaded: url_helper
INFO - 2021-12-13 02:56:57 --> Helper loaded: file_helper
INFO - 2021-12-13 02:56:57 --> Helper loaded: form_helper
INFO - 2021-12-13 02:56:57 --> Helper loaded: my_helper
INFO - 2021-12-13 02:56:57 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:56:57 --> Controller Class Initialized
INFO - 2021-12-13 02:56:59 --> Config Class Initialized
INFO - 2021-12-13 02:56:59 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:56:59 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:56:59 --> Utf8 Class Initialized
INFO - 2021-12-13 02:56:59 --> URI Class Initialized
INFO - 2021-12-13 02:56:59 --> Router Class Initialized
INFO - 2021-12-13 02:56:59 --> Output Class Initialized
INFO - 2021-12-13 02:56:59 --> Security Class Initialized
DEBUG - 2021-12-13 02:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:56:59 --> Input Class Initialized
INFO - 2021-12-13 02:56:59 --> Language Class Initialized
INFO - 2021-12-13 02:56:59 --> Language Class Initialized
INFO - 2021-12-13 02:56:59 --> Config Class Initialized
INFO - 2021-12-13 02:56:59 --> Loader Class Initialized
INFO - 2021-12-13 02:56:59 --> Helper loaded: url_helper
INFO - 2021-12-13 02:56:59 --> Helper loaded: file_helper
INFO - 2021-12-13 02:56:59 --> Helper loaded: form_helper
INFO - 2021-12-13 02:56:59 --> Helper loaded: my_helper
INFO - 2021-12-13 02:56:59 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:56:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:56:59 --> Controller Class Initialized
INFO - 2021-12-13 02:56:59 --> Helper loaded: cookie_helper
INFO - 2021-12-13 02:56:59 --> Config Class Initialized
INFO - 2021-12-13 02:56:59 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:56:59 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:56:59 --> Utf8 Class Initialized
INFO - 2021-12-13 02:56:59 --> URI Class Initialized
INFO - 2021-12-13 02:56:59 --> Router Class Initialized
INFO - 2021-12-13 02:56:59 --> Output Class Initialized
INFO - 2021-12-13 02:56:59 --> Security Class Initialized
DEBUG - 2021-12-13 02:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:56:59 --> Input Class Initialized
INFO - 2021-12-13 02:56:59 --> Language Class Initialized
INFO - 2021-12-13 02:56:59 --> Language Class Initialized
INFO - 2021-12-13 02:56:59 --> Config Class Initialized
INFO - 2021-12-13 02:56:59 --> Loader Class Initialized
INFO - 2021-12-13 02:56:59 --> Helper loaded: url_helper
INFO - 2021-12-13 02:56:59 --> Helper loaded: file_helper
INFO - 2021-12-13 02:56:59 --> Helper loaded: form_helper
INFO - 2021-12-13 02:56:59 --> Helper loaded: my_helper
INFO - 2021-12-13 02:56:59 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:56:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:56:59 --> Controller Class Initialized
DEBUG - 2021-12-13 02:56:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-13 02:56:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 02:56:59 --> Final output sent to browser
DEBUG - 2021-12-13 02:56:59 --> Total execution time: 0.0360
INFO - 2021-12-13 02:57:04 --> Config Class Initialized
INFO - 2021-12-13 02:57:04 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:57:04 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:57:04 --> Utf8 Class Initialized
INFO - 2021-12-13 02:57:04 --> URI Class Initialized
INFO - 2021-12-13 02:57:04 --> Router Class Initialized
INFO - 2021-12-13 02:57:04 --> Output Class Initialized
INFO - 2021-12-13 02:57:04 --> Security Class Initialized
DEBUG - 2021-12-13 02:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:57:04 --> Input Class Initialized
INFO - 2021-12-13 02:57:04 --> Language Class Initialized
INFO - 2021-12-13 02:57:04 --> Language Class Initialized
INFO - 2021-12-13 02:57:04 --> Config Class Initialized
INFO - 2021-12-13 02:57:04 --> Loader Class Initialized
INFO - 2021-12-13 02:57:04 --> Helper loaded: url_helper
INFO - 2021-12-13 02:57:04 --> Helper loaded: file_helper
INFO - 2021-12-13 02:57:04 --> Helper loaded: form_helper
INFO - 2021-12-13 02:57:05 --> Helper loaded: my_helper
INFO - 2021-12-13 02:57:05 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:57:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:57:05 --> Controller Class Initialized
INFO - 2021-12-13 02:57:05 --> Helper loaded: cookie_helper
INFO - 2021-12-13 02:57:05 --> Final output sent to browser
DEBUG - 2021-12-13 02:57:05 --> Total execution time: 0.0530
INFO - 2021-12-13 02:57:05 --> Config Class Initialized
INFO - 2021-12-13 02:57:05 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:57:05 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:57:05 --> Utf8 Class Initialized
INFO - 2021-12-13 02:57:05 --> URI Class Initialized
INFO - 2021-12-13 02:57:05 --> Router Class Initialized
INFO - 2021-12-13 02:57:05 --> Output Class Initialized
INFO - 2021-12-13 02:57:05 --> Security Class Initialized
DEBUG - 2021-12-13 02:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:57:05 --> Input Class Initialized
INFO - 2021-12-13 02:57:05 --> Language Class Initialized
INFO - 2021-12-13 02:57:05 --> Language Class Initialized
INFO - 2021-12-13 02:57:05 --> Config Class Initialized
INFO - 2021-12-13 02:57:05 --> Loader Class Initialized
INFO - 2021-12-13 02:57:05 --> Helper loaded: url_helper
INFO - 2021-12-13 02:57:05 --> Helper loaded: file_helper
INFO - 2021-12-13 02:57:05 --> Helper loaded: form_helper
INFO - 2021-12-13 02:57:05 --> Helper loaded: my_helper
INFO - 2021-12-13 02:57:05 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:57:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:57:05 --> Controller Class Initialized
DEBUG - 2021-12-13 02:57:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-13 02:57:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 02:57:05 --> Final output sent to browser
DEBUG - 2021-12-13 02:57:05 --> Total execution time: 0.6510
INFO - 2021-12-13 02:57:07 --> Config Class Initialized
INFO - 2021-12-13 02:57:07 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:57:07 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:57:07 --> Utf8 Class Initialized
INFO - 2021-12-13 02:57:07 --> URI Class Initialized
INFO - 2021-12-13 02:57:07 --> Router Class Initialized
INFO - 2021-12-13 02:57:07 --> Output Class Initialized
INFO - 2021-12-13 02:57:07 --> Security Class Initialized
DEBUG - 2021-12-13 02:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:57:07 --> Input Class Initialized
INFO - 2021-12-13 02:57:07 --> Language Class Initialized
INFO - 2021-12-13 02:57:07 --> Language Class Initialized
INFO - 2021-12-13 02:57:07 --> Config Class Initialized
INFO - 2021-12-13 02:57:07 --> Loader Class Initialized
INFO - 2021-12-13 02:57:07 --> Helper loaded: url_helper
INFO - 2021-12-13 02:57:07 --> Helper loaded: file_helper
INFO - 2021-12-13 02:57:07 --> Helper loaded: form_helper
INFO - 2021-12-13 02:57:07 --> Helper loaded: my_helper
INFO - 2021-12-13 02:57:07 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:57:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:57:07 --> Controller Class Initialized
DEBUG - 2021-12-13 02:57:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-13 02:57:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 02:57:07 --> Final output sent to browser
DEBUG - 2021-12-13 02:57:07 --> Total execution time: 0.0660
INFO - 2021-12-13 02:57:10 --> Config Class Initialized
INFO - 2021-12-13 02:57:10 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:57:10 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:57:10 --> Utf8 Class Initialized
INFO - 2021-12-13 02:57:10 --> URI Class Initialized
INFO - 2021-12-13 02:57:10 --> Router Class Initialized
INFO - 2021-12-13 02:57:10 --> Output Class Initialized
INFO - 2021-12-13 02:57:10 --> Security Class Initialized
DEBUG - 2021-12-13 02:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:57:10 --> Input Class Initialized
INFO - 2021-12-13 02:57:10 --> Language Class Initialized
INFO - 2021-12-13 02:57:10 --> Language Class Initialized
INFO - 2021-12-13 02:57:10 --> Config Class Initialized
INFO - 2021-12-13 02:57:10 --> Loader Class Initialized
INFO - 2021-12-13 02:57:10 --> Helper loaded: url_helper
INFO - 2021-12-13 02:57:10 --> Helper loaded: file_helper
INFO - 2021-12-13 02:57:10 --> Helper loaded: form_helper
INFO - 2021-12-13 02:57:10 --> Helper loaded: my_helper
INFO - 2021-12-13 02:57:10 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:57:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:57:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:57:10 --> Controller Class Initialized
DEBUG - 2021-12-13 02:57:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 02:57:11 --> Final output sent to browser
DEBUG - 2021-12-13 02:57:11 --> Total execution time: 0.2010
INFO - 2021-12-13 02:57:17 --> Config Class Initialized
INFO - 2021-12-13 02:57:17 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:57:17 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:57:17 --> Utf8 Class Initialized
INFO - 2021-12-13 02:57:17 --> URI Class Initialized
INFO - 2021-12-13 02:57:17 --> Router Class Initialized
INFO - 2021-12-13 02:57:17 --> Output Class Initialized
INFO - 2021-12-13 02:57:17 --> Security Class Initialized
DEBUG - 2021-12-13 02:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:57:17 --> Input Class Initialized
INFO - 2021-12-13 02:57:17 --> Language Class Initialized
INFO - 2021-12-13 02:57:17 --> Language Class Initialized
INFO - 2021-12-13 02:57:17 --> Config Class Initialized
INFO - 2021-12-13 02:57:17 --> Loader Class Initialized
INFO - 2021-12-13 02:57:17 --> Helper loaded: url_helper
INFO - 2021-12-13 02:57:17 --> Helper loaded: file_helper
INFO - 2021-12-13 02:57:17 --> Helper loaded: form_helper
INFO - 2021-12-13 02:57:17 --> Helper loaded: my_helper
INFO - 2021-12-13 02:57:17 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:57:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:57:17 --> Controller Class Initialized
DEBUG - 2021-12-13 02:57:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 02:57:17 --> Final output sent to browser
DEBUG - 2021-12-13 02:57:17 --> Total execution time: 0.1530
INFO - 2021-12-13 02:57:18 --> Config Class Initialized
INFO - 2021-12-13 02:57:18 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:57:18 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:57:18 --> Utf8 Class Initialized
INFO - 2021-12-13 02:57:18 --> URI Class Initialized
INFO - 2021-12-13 02:57:18 --> Router Class Initialized
INFO - 2021-12-13 02:57:18 --> Output Class Initialized
INFO - 2021-12-13 02:57:18 --> Security Class Initialized
DEBUG - 2021-12-13 02:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:57:18 --> Input Class Initialized
INFO - 2021-12-13 02:57:18 --> Language Class Initialized
INFO - 2021-12-13 02:57:19 --> Language Class Initialized
INFO - 2021-12-13 02:57:19 --> Config Class Initialized
INFO - 2021-12-13 02:57:19 --> Loader Class Initialized
INFO - 2021-12-13 02:57:19 --> Helper loaded: url_helper
INFO - 2021-12-13 02:57:19 --> Helper loaded: file_helper
INFO - 2021-12-13 02:57:19 --> Helper loaded: form_helper
INFO - 2021-12-13 02:57:19 --> Helper loaded: my_helper
INFO - 2021-12-13 02:57:19 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:57:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:57:19 --> Controller Class Initialized
DEBUG - 2021-12-13 02:57:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 02:57:19 --> Final output sent to browser
DEBUG - 2021-12-13 02:57:19 --> Total execution time: 0.1330
INFO - 2021-12-13 02:57:20 --> Config Class Initialized
INFO - 2021-12-13 02:57:20 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:57:20 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:57:20 --> Utf8 Class Initialized
INFO - 2021-12-13 02:57:20 --> URI Class Initialized
INFO - 2021-12-13 02:57:20 --> Router Class Initialized
INFO - 2021-12-13 02:57:20 --> Output Class Initialized
INFO - 2021-12-13 02:57:20 --> Security Class Initialized
DEBUG - 2021-12-13 02:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:57:20 --> Input Class Initialized
INFO - 2021-12-13 02:57:20 --> Language Class Initialized
INFO - 2021-12-13 02:57:20 --> Language Class Initialized
INFO - 2021-12-13 02:57:20 --> Config Class Initialized
INFO - 2021-12-13 02:57:20 --> Loader Class Initialized
INFO - 2021-12-13 02:57:20 --> Helper loaded: url_helper
INFO - 2021-12-13 02:57:20 --> Helper loaded: file_helper
INFO - 2021-12-13 02:57:20 --> Helper loaded: form_helper
INFO - 2021-12-13 02:57:20 --> Helper loaded: my_helper
INFO - 2021-12-13 02:57:20 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:57:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:57:20 --> Controller Class Initialized
DEBUG - 2021-12-13 02:57:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 02:57:20 --> Final output sent to browser
DEBUG - 2021-12-13 02:57:20 --> Total execution time: 0.1180
INFO - 2021-12-13 02:57:22 --> Config Class Initialized
INFO - 2021-12-13 02:57:22 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:57:22 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:57:22 --> Utf8 Class Initialized
INFO - 2021-12-13 02:57:22 --> URI Class Initialized
INFO - 2021-12-13 02:57:22 --> Router Class Initialized
INFO - 2021-12-13 02:57:22 --> Output Class Initialized
INFO - 2021-12-13 02:57:22 --> Security Class Initialized
DEBUG - 2021-12-13 02:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:57:22 --> Input Class Initialized
INFO - 2021-12-13 02:57:22 --> Language Class Initialized
INFO - 2021-12-13 02:57:22 --> Language Class Initialized
INFO - 2021-12-13 02:57:22 --> Config Class Initialized
INFO - 2021-12-13 02:57:22 --> Loader Class Initialized
INFO - 2021-12-13 02:57:22 --> Helper loaded: url_helper
INFO - 2021-12-13 02:57:22 --> Helper loaded: file_helper
INFO - 2021-12-13 02:57:22 --> Helper loaded: form_helper
INFO - 2021-12-13 02:57:22 --> Helper loaded: my_helper
INFO - 2021-12-13 02:57:22 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:57:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:57:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:57:22 --> Controller Class Initialized
DEBUG - 2021-12-13 02:57:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 02:57:22 --> Final output sent to browser
DEBUG - 2021-12-13 02:57:22 --> Total execution time: 0.1170
INFO - 2021-12-13 02:57:26 --> Config Class Initialized
INFO - 2021-12-13 02:57:26 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:57:26 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:57:26 --> Utf8 Class Initialized
INFO - 2021-12-13 02:57:26 --> URI Class Initialized
INFO - 2021-12-13 02:57:26 --> Router Class Initialized
INFO - 2021-12-13 02:57:26 --> Output Class Initialized
INFO - 2021-12-13 02:57:26 --> Security Class Initialized
DEBUG - 2021-12-13 02:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:57:26 --> Input Class Initialized
INFO - 2021-12-13 02:57:26 --> Language Class Initialized
INFO - 2021-12-13 02:57:26 --> Language Class Initialized
INFO - 2021-12-13 02:57:26 --> Config Class Initialized
INFO - 2021-12-13 02:57:26 --> Loader Class Initialized
INFO - 2021-12-13 02:57:26 --> Helper loaded: url_helper
INFO - 2021-12-13 02:57:26 --> Helper loaded: file_helper
INFO - 2021-12-13 02:57:26 --> Helper loaded: form_helper
INFO - 2021-12-13 02:57:26 --> Helper loaded: my_helper
INFO - 2021-12-13 02:57:26 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:57:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:57:26 --> Controller Class Initialized
DEBUG - 2021-12-13 02:57:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 02:57:26 --> Final output sent to browser
DEBUG - 2021-12-13 02:57:26 --> Total execution time: 0.1220
INFO - 2021-12-13 02:57:27 --> Config Class Initialized
INFO - 2021-12-13 02:57:27 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:57:27 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:57:27 --> Utf8 Class Initialized
INFO - 2021-12-13 02:57:27 --> URI Class Initialized
INFO - 2021-12-13 02:57:27 --> Router Class Initialized
INFO - 2021-12-13 02:57:27 --> Output Class Initialized
INFO - 2021-12-13 02:57:27 --> Security Class Initialized
DEBUG - 2021-12-13 02:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:57:27 --> Input Class Initialized
INFO - 2021-12-13 02:57:27 --> Language Class Initialized
INFO - 2021-12-13 02:57:27 --> Language Class Initialized
INFO - 2021-12-13 02:57:27 --> Config Class Initialized
INFO - 2021-12-13 02:57:27 --> Loader Class Initialized
INFO - 2021-12-13 02:57:27 --> Helper loaded: url_helper
INFO - 2021-12-13 02:57:27 --> Helper loaded: file_helper
INFO - 2021-12-13 02:57:27 --> Helper loaded: form_helper
INFO - 2021-12-13 02:57:27 --> Helper loaded: my_helper
INFO - 2021-12-13 02:57:27 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:57:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:57:28 --> Controller Class Initialized
DEBUG - 2021-12-13 02:57:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 02:57:28 --> Final output sent to browser
DEBUG - 2021-12-13 02:57:28 --> Total execution time: 0.1270
INFO - 2021-12-13 02:57:29 --> Config Class Initialized
INFO - 2021-12-13 02:57:29 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:57:29 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:57:29 --> Utf8 Class Initialized
INFO - 2021-12-13 02:57:29 --> URI Class Initialized
INFO - 2021-12-13 02:57:29 --> Router Class Initialized
INFO - 2021-12-13 02:57:29 --> Output Class Initialized
INFO - 2021-12-13 02:57:29 --> Security Class Initialized
DEBUG - 2021-12-13 02:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:57:29 --> Input Class Initialized
INFO - 2021-12-13 02:57:29 --> Language Class Initialized
INFO - 2021-12-13 02:57:29 --> Language Class Initialized
INFO - 2021-12-13 02:57:29 --> Config Class Initialized
INFO - 2021-12-13 02:57:29 --> Loader Class Initialized
INFO - 2021-12-13 02:57:29 --> Helper loaded: url_helper
INFO - 2021-12-13 02:57:29 --> Helper loaded: file_helper
INFO - 2021-12-13 02:57:29 --> Helper loaded: form_helper
INFO - 2021-12-13 02:57:29 --> Helper loaded: my_helper
INFO - 2021-12-13 02:57:29 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:57:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:57:29 --> Controller Class Initialized
DEBUG - 2021-12-13 02:57:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 02:57:29 --> Final output sent to browser
DEBUG - 2021-12-13 02:57:29 --> Total execution time: 0.1220
INFO - 2021-12-13 02:57:31 --> Config Class Initialized
INFO - 2021-12-13 02:57:31 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:57:31 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:57:31 --> Utf8 Class Initialized
INFO - 2021-12-13 02:57:31 --> URI Class Initialized
INFO - 2021-12-13 02:57:31 --> Router Class Initialized
INFO - 2021-12-13 02:57:31 --> Output Class Initialized
INFO - 2021-12-13 02:57:31 --> Security Class Initialized
DEBUG - 2021-12-13 02:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:57:31 --> Input Class Initialized
INFO - 2021-12-13 02:57:31 --> Language Class Initialized
INFO - 2021-12-13 02:57:31 --> Language Class Initialized
INFO - 2021-12-13 02:57:31 --> Config Class Initialized
INFO - 2021-12-13 02:57:31 --> Loader Class Initialized
INFO - 2021-12-13 02:57:31 --> Helper loaded: url_helper
INFO - 2021-12-13 02:57:31 --> Helper loaded: file_helper
INFO - 2021-12-13 02:57:31 --> Helper loaded: form_helper
INFO - 2021-12-13 02:57:31 --> Helper loaded: my_helper
INFO - 2021-12-13 02:57:31 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:57:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:57:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:57:31 --> Controller Class Initialized
DEBUG - 2021-12-13 02:57:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 02:57:31 --> Final output sent to browser
DEBUG - 2021-12-13 02:57:31 --> Total execution time: 0.1350
INFO - 2021-12-13 02:57:34 --> Config Class Initialized
INFO - 2021-12-13 02:57:34 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:57:34 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:57:34 --> Utf8 Class Initialized
INFO - 2021-12-13 02:57:34 --> URI Class Initialized
INFO - 2021-12-13 02:57:34 --> Router Class Initialized
INFO - 2021-12-13 02:57:34 --> Output Class Initialized
INFO - 2021-12-13 02:57:34 --> Security Class Initialized
DEBUG - 2021-12-13 02:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:57:34 --> Input Class Initialized
INFO - 2021-12-13 02:57:34 --> Language Class Initialized
INFO - 2021-12-13 02:57:34 --> Language Class Initialized
INFO - 2021-12-13 02:57:34 --> Config Class Initialized
INFO - 2021-12-13 02:57:34 --> Loader Class Initialized
INFO - 2021-12-13 02:57:34 --> Helper loaded: url_helper
INFO - 2021-12-13 02:57:34 --> Helper loaded: file_helper
INFO - 2021-12-13 02:57:34 --> Helper loaded: form_helper
INFO - 2021-12-13 02:57:34 --> Helper loaded: my_helper
INFO - 2021-12-13 02:57:34 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:57:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:57:34 --> Controller Class Initialized
DEBUG - 2021-12-13 02:57:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 02:57:34 --> Final output sent to browser
DEBUG - 2021-12-13 02:57:34 --> Total execution time: 0.1130
INFO - 2021-12-13 02:57:36 --> Config Class Initialized
INFO - 2021-12-13 02:57:36 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:57:36 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:57:36 --> Utf8 Class Initialized
INFO - 2021-12-13 02:57:36 --> URI Class Initialized
INFO - 2021-12-13 02:57:36 --> Router Class Initialized
INFO - 2021-12-13 02:57:36 --> Output Class Initialized
INFO - 2021-12-13 02:57:36 --> Security Class Initialized
DEBUG - 2021-12-13 02:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:57:36 --> Input Class Initialized
INFO - 2021-12-13 02:57:36 --> Language Class Initialized
INFO - 2021-12-13 02:57:36 --> Language Class Initialized
INFO - 2021-12-13 02:57:36 --> Config Class Initialized
INFO - 2021-12-13 02:57:36 --> Loader Class Initialized
INFO - 2021-12-13 02:57:36 --> Helper loaded: url_helper
INFO - 2021-12-13 02:57:36 --> Helper loaded: file_helper
INFO - 2021-12-13 02:57:36 --> Helper loaded: form_helper
INFO - 2021-12-13 02:57:36 --> Helper loaded: my_helper
INFO - 2021-12-13 02:57:36 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:57:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:57:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:57:36 --> Controller Class Initialized
DEBUG - 2021-12-13 02:57:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 02:57:36 --> Final output sent to browser
DEBUG - 2021-12-13 02:57:36 --> Total execution time: 0.1260
INFO - 2021-12-13 02:57:39 --> Config Class Initialized
INFO - 2021-12-13 02:57:39 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:57:39 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:57:39 --> Utf8 Class Initialized
INFO - 2021-12-13 02:57:39 --> URI Class Initialized
INFO - 2021-12-13 02:57:39 --> Router Class Initialized
INFO - 2021-12-13 02:57:39 --> Output Class Initialized
INFO - 2021-12-13 02:57:39 --> Security Class Initialized
DEBUG - 2021-12-13 02:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:57:39 --> Input Class Initialized
INFO - 2021-12-13 02:57:39 --> Language Class Initialized
INFO - 2021-12-13 02:57:39 --> Language Class Initialized
INFO - 2021-12-13 02:57:39 --> Config Class Initialized
INFO - 2021-12-13 02:57:39 --> Loader Class Initialized
INFO - 2021-12-13 02:57:39 --> Helper loaded: url_helper
INFO - 2021-12-13 02:57:39 --> Helper loaded: file_helper
INFO - 2021-12-13 02:57:39 --> Helper loaded: form_helper
INFO - 2021-12-13 02:57:39 --> Helper loaded: my_helper
INFO - 2021-12-13 02:57:39 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:57:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:57:39 --> Controller Class Initialized
DEBUG - 2021-12-13 02:57:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 02:57:39 --> Final output sent to browser
DEBUG - 2021-12-13 02:57:39 --> Total execution time: 0.1590
INFO - 2021-12-13 02:57:40 --> Config Class Initialized
INFO - 2021-12-13 02:57:40 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:57:40 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:57:40 --> Utf8 Class Initialized
INFO - 2021-12-13 02:57:40 --> URI Class Initialized
INFO - 2021-12-13 02:57:40 --> Router Class Initialized
INFO - 2021-12-13 02:57:40 --> Output Class Initialized
INFO - 2021-12-13 02:57:40 --> Security Class Initialized
DEBUG - 2021-12-13 02:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:57:40 --> Input Class Initialized
INFO - 2021-12-13 02:57:40 --> Language Class Initialized
INFO - 2021-12-13 02:57:40 --> Language Class Initialized
INFO - 2021-12-13 02:57:40 --> Config Class Initialized
INFO - 2021-12-13 02:57:40 --> Loader Class Initialized
INFO - 2021-12-13 02:57:40 --> Helper loaded: url_helper
INFO - 2021-12-13 02:57:40 --> Helper loaded: file_helper
INFO - 2021-12-13 02:57:40 --> Helper loaded: form_helper
INFO - 2021-12-13 02:57:40 --> Helper loaded: my_helper
INFO - 2021-12-13 02:57:40 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:57:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:57:40 --> Controller Class Initialized
DEBUG - 2021-12-13 02:57:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 02:57:40 --> Final output sent to browser
DEBUG - 2021-12-13 02:57:40 --> Total execution time: 0.1410
INFO - 2021-12-13 02:57:45 --> Config Class Initialized
INFO - 2021-12-13 02:57:45 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:57:45 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:57:45 --> Utf8 Class Initialized
INFO - 2021-12-13 02:57:45 --> URI Class Initialized
INFO - 2021-12-13 02:57:45 --> Router Class Initialized
INFO - 2021-12-13 02:57:45 --> Output Class Initialized
INFO - 2021-12-13 02:57:45 --> Security Class Initialized
DEBUG - 2021-12-13 02:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:57:45 --> Input Class Initialized
INFO - 2021-12-13 02:57:45 --> Language Class Initialized
INFO - 2021-12-13 02:57:45 --> Language Class Initialized
INFO - 2021-12-13 02:57:45 --> Config Class Initialized
INFO - 2021-12-13 02:57:45 --> Loader Class Initialized
INFO - 2021-12-13 02:57:45 --> Helper loaded: url_helper
INFO - 2021-12-13 02:57:45 --> Helper loaded: file_helper
INFO - 2021-12-13 02:57:45 --> Helper loaded: form_helper
INFO - 2021-12-13 02:57:45 --> Helper loaded: my_helper
INFO - 2021-12-13 02:57:45 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:57:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:57:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:57:45 --> Controller Class Initialized
DEBUG - 2021-12-13 02:57:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 02:57:45 --> Final output sent to browser
DEBUG - 2021-12-13 02:57:45 --> Total execution time: 0.1490
INFO - 2021-12-13 02:57:46 --> Config Class Initialized
INFO - 2021-12-13 02:57:46 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:57:46 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:57:46 --> Utf8 Class Initialized
INFO - 2021-12-13 02:57:46 --> URI Class Initialized
INFO - 2021-12-13 02:57:46 --> Router Class Initialized
INFO - 2021-12-13 02:57:46 --> Output Class Initialized
INFO - 2021-12-13 02:57:46 --> Security Class Initialized
DEBUG - 2021-12-13 02:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:57:46 --> Input Class Initialized
INFO - 2021-12-13 02:57:46 --> Language Class Initialized
INFO - 2021-12-13 02:57:46 --> Language Class Initialized
INFO - 2021-12-13 02:57:46 --> Config Class Initialized
INFO - 2021-12-13 02:57:46 --> Loader Class Initialized
INFO - 2021-12-13 02:57:46 --> Helper loaded: url_helper
INFO - 2021-12-13 02:57:46 --> Helper loaded: file_helper
INFO - 2021-12-13 02:57:46 --> Helper loaded: form_helper
INFO - 2021-12-13 02:57:46 --> Helper loaded: my_helper
INFO - 2021-12-13 02:57:46 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:57:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:57:46 --> Controller Class Initialized
DEBUG - 2021-12-13 02:57:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 02:57:46 --> Final output sent to browser
DEBUG - 2021-12-13 02:57:46 --> Total execution time: 0.1250
INFO - 2021-12-13 02:57:50 --> Config Class Initialized
INFO - 2021-12-13 02:57:50 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:57:50 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:57:50 --> Utf8 Class Initialized
INFO - 2021-12-13 02:57:50 --> URI Class Initialized
INFO - 2021-12-13 02:57:50 --> Router Class Initialized
INFO - 2021-12-13 02:57:50 --> Output Class Initialized
INFO - 2021-12-13 02:57:50 --> Security Class Initialized
DEBUG - 2021-12-13 02:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:57:50 --> Input Class Initialized
INFO - 2021-12-13 02:57:50 --> Language Class Initialized
INFO - 2021-12-13 02:57:50 --> Language Class Initialized
INFO - 2021-12-13 02:57:50 --> Config Class Initialized
INFO - 2021-12-13 02:57:50 --> Loader Class Initialized
INFO - 2021-12-13 02:57:50 --> Helper loaded: url_helper
INFO - 2021-12-13 02:57:50 --> Helper loaded: file_helper
INFO - 2021-12-13 02:57:50 --> Helper loaded: form_helper
INFO - 2021-12-13 02:57:50 --> Helper loaded: my_helper
INFO - 2021-12-13 02:57:50 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:57:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:57:50 --> Controller Class Initialized
DEBUG - 2021-12-13 02:57:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 02:57:50 --> Final output sent to browser
DEBUG - 2021-12-13 02:57:50 --> Total execution time: 0.1260
INFO - 2021-12-13 02:57:51 --> Config Class Initialized
INFO - 2021-12-13 02:57:51 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:57:51 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:57:51 --> Utf8 Class Initialized
INFO - 2021-12-13 02:57:51 --> URI Class Initialized
INFO - 2021-12-13 02:57:52 --> Router Class Initialized
INFO - 2021-12-13 02:57:52 --> Output Class Initialized
INFO - 2021-12-13 02:57:52 --> Security Class Initialized
DEBUG - 2021-12-13 02:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:57:52 --> Input Class Initialized
INFO - 2021-12-13 02:57:52 --> Language Class Initialized
INFO - 2021-12-13 02:57:52 --> Language Class Initialized
INFO - 2021-12-13 02:57:52 --> Config Class Initialized
INFO - 2021-12-13 02:57:52 --> Loader Class Initialized
INFO - 2021-12-13 02:57:52 --> Helper loaded: url_helper
INFO - 2021-12-13 02:57:52 --> Helper loaded: file_helper
INFO - 2021-12-13 02:57:52 --> Helper loaded: form_helper
INFO - 2021-12-13 02:57:52 --> Helper loaded: my_helper
INFO - 2021-12-13 02:57:52 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:57:52 --> Controller Class Initialized
DEBUG - 2021-12-13 02:57:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 02:57:52 --> Final output sent to browser
DEBUG - 2021-12-13 02:57:52 --> Total execution time: 0.1270
INFO - 2021-12-13 02:57:53 --> Config Class Initialized
INFO - 2021-12-13 02:57:53 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:57:53 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:57:53 --> Utf8 Class Initialized
INFO - 2021-12-13 02:57:53 --> URI Class Initialized
INFO - 2021-12-13 02:57:53 --> Router Class Initialized
INFO - 2021-12-13 02:57:53 --> Output Class Initialized
INFO - 2021-12-13 02:57:53 --> Security Class Initialized
DEBUG - 2021-12-13 02:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:57:53 --> Input Class Initialized
INFO - 2021-12-13 02:57:53 --> Language Class Initialized
INFO - 2021-12-13 02:57:53 --> Language Class Initialized
INFO - 2021-12-13 02:57:53 --> Config Class Initialized
INFO - 2021-12-13 02:57:53 --> Loader Class Initialized
INFO - 2021-12-13 02:57:53 --> Helper loaded: url_helper
INFO - 2021-12-13 02:57:53 --> Helper loaded: file_helper
INFO - 2021-12-13 02:57:53 --> Helper loaded: form_helper
INFO - 2021-12-13 02:57:53 --> Helper loaded: my_helper
INFO - 2021-12-13 02:57:53 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:57:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:57:53 --> Controller Class Initialized
DEBUG - 2021-12-13 02:57:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 02:57:53 --> Final output sent to browser
DEBUG - 2021-12-13 02:57:53 --> Total execution time: 0.1210
INFO - 2021-12-13 02:57:56 --> Config Class Initialized
INFO - 2021-12-13 02:57:56 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:57:56 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:57:56 --> Utf8 Class Initialized
INFO - 2021-12-13 02:57:56 --> URI Class Initialized
INFO - 2021-12-13 02:57:56 --> Router Class Initialized
INFO - 2021-12-13 02:57:56 --> Output Class Initialized
INFO - 2021-12-13 02:57:56 --> Security Class Initialized
DEBUG - 2021-12-13 02:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:57:56 --> Input Class Initialized
INFO - 2021-12-13 02:57:56 --> Language Class Initialized
INFO - 2021-12-13 02:57:56 --> Language Class Initialized
INFO - 2021-12-13 02:57:56 --> Config Class Initialized
INFO - 2021-12-13 02:57:56 --> Loader Class Initialized
INFO - 2021-12-13 02:57:56 --> Helper loaded: url_helper
INFO - 2021-12-13 02:57:56 --> Helper loaded: file_helper
INFO - 2021-12-13 02:57:56 --> Helper loaded: form_helper
INFO - 2021-12-13 02:57:56 --> Helper loaded: my_helper
INFO - 2021-12-13 02:57:56 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:57:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:57:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:57:56 --> Controller Class Initialized
DEBUG - 2021-12-13 02:57:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 02:57:56 --> Final output sent to browser
DEBUG - 2021-12-13 02:57:56 --> Total execution time: 0.1270
INFO - 2021-12-13 02:57:57 --> Config Class Initialized
INFO - 2021-12-13 02:57:57 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:57:57 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:57:57 --> Utf8 Class Initialized
INFO - 2021-12-13 02:57:57 --> URI Class Initialized
INFO - 2021-12-13 02:57:57 --> Router Class Initialized
INFO - 2021-12-13 02:57:57 --> Output Class Initialized
INFO - 2021-12-13 02:57:57 --> Security Class Initialized
DEBUG - 2021-12-13 02:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:57:57 --> Input Class Initialized
INFO - 2021-12-13 02:57:57 --> Language Class Initialized
INFO - 2021-12-13 02:57:57 --> Language Class Initialized
INFO - 2021-12-13 02:57:57 --> Config Class Initialized
INFO - 2021-12-13 02:57:57 --> Loader Class Initialized
INFO - 2021-12-13 02:57:57 --> Helper loaded: url_helper
INFO - 2021-12-13 02:57:57 --> Helper loaded: file_helper
INFO - 2021-12-13 02:57:57 --> Helper loaded: form_helper
INFO - 2021-12-13 02:57:57 --> Helper loaded: my_helper
INFO - 2021-12-13 02:57:57 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:57:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:57:57 --> Controller Class Initialized
DEBUG - 2021-12-13 02:57:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 02:57:57 --> Final output sent to browser
DEBUG - 2021-12-13 02:57:57 --> Total execution time: 0.1180
INFO - 2021-12-13 02:57:59 --> Config Class Initialized
INFO - 2021-12-13 02:57:59 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:57:59 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:57:59 --> Utf8 Class Initialized
INFO - 2021-12-13 02:57:59 --> URI Class Initialized
INFO - 2021-12-13 02:57:59 --> Router Class Initialized
INFO - 2021-12-13 02:57:59 --> Output Class Initialized
INFO - 2021-12-13 02:57:59 --> Security Class Initialized
DEBUG - 2021-12-13 02:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:57:59 --> Input Class Initialized
INFO - 2021-12-13 02:57:59 --> Language Class Initialized
INFO - 2021-12-13 02:57:59 --> Language Class Initialized
INFO - 2021-12-13 02:57:59 --> Config Class Initialized
INFO - 2021-12-13 02:57:59 --> Loader Class Initialized
INFO - 2021-12-13 02:57:59 --> Helper loaded: url_helper
INFO - 2021-12-13 02:57:59 --> Helper loaded: file_helper
INFO - 2021-12-13 02:57:59 --> Helper loaded: form_helper
INFO - 2021-12-13 02:57:59 --> Helper loaded: my_helper
INFO - 2021-12-13 02:57:59 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:57:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:57:59 --> Controller Class Initialized
DEBUG - 2021-12-13 02:57:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 02:57:59 --> Final output sent to browser
DEBUG - 2021-12-13 02:57:59 --> Total execution time: 0.1360
INFO - 2021-12-13 02:58:05 --> Config Class Initialized
INFO - 2021-12-13 02:58:05 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:58:05 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:58:05 --> Utf8 Class Initialized
INFO - 2021-12-13 02:58:05 --> URI Class Initialized
INFO - 2021-12-13 02:58:05 --> Router Class Initialized
INFO - 2021-12-13 02:58:05 --> Output Class Initialized
INFO - 2021-12-13 02:58:05 --> Security Class Initialized
DEBUG - 2021-12-13 02:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:58:05 --> Input Class Initialized
INFO - 2021-12-13 02:58:05 --> Language Class Initialized
INFO - 2021-12-13 02:58:05 --> Language Class Initialized
INFO - 2021-12-13 02:58:05 --> Config Class Initialized
INFO - 2021-12-13 02:58:05 --> Loader Class Initialized
INFO - 2021-12-13 02:58:05 --> Helper loaded: url_helper
INFO - 2021-12-13 02:58:05 --> Helper loaded: file_helper
INFO - 2021-12-13 02:58:05 --> Helper loaded: form_helper
INFO - 2021-12-13 02:58:05 --> Helper loaded: my_helper
INFO - 2021-12-13 02:58:05 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:58:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:58:05 --> Controller Class Initialized
DEBUG - 2021-12-13 02:58:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 02:58:05 --> Final output sent to browser
DEBUG - 2021-12-13 02:58:05 --> Total execution time: 0.1150
INFO - 2021-12-13 02:58:07 --> Config Class Initialized
INFO - 2021-12-13 02:58:07 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:58:07 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:58:07 --> Utf8 Class Initialized
INFO - 2021-12-13 02:58:07 --> URI Class Initialized
INFO - 2021-12-13 02:58:07 --> Router Class Initialized
INFO - 2021-12-13 02:58:07 --> Output Class Initialized
INFO - 2021-12-13 02:58:07 --> Security Class Initialized
DEBUG - 2021-12-13 02:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:58:07 --> Input Class Initialized
INFO - 2021-12-13 02:58:07 --> Language Class Initialized
INFO - 2021-12-13 02:58:07 --> Language Class Initialized
INFO - 2021-12-13 02:58:07 --> Config Class Initialized
INFO - 2021-12-13 02:58:07 --> Loader Class Initialized
INFO - 2021-12-13 02:58:07 --> Helper loaded: url_helper
INFO - 2021-12-13 02:58:07 --> Helper loaded: file_helper
INFO - 2021-12-13 02:58:07 --> Helper loaded: form_helper
INFO - 2021-12-13 02:58:07 --> Helper loaded: my_helper
INFO - 2021-12-13 02:58:07 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:58:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:58:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:58:07 --> Controller Class Initialized
DEBUG - 2021-12-13 02:58:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 02:58:07 --> Final output sent to browser
DEBUG - 2021-12-13 02:58:07 --> Total execution time: 0.1300
INFO - 2021-12-13 02:58:09 --> Config Class Initialized
INFO - 2021-12-13 02:58:09 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:58:09 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:58:09 --> Utf8 Class Initialized
INFO - 2021-12-13 02:58:09 --> URI Class Initialized
INFO - 2021-12-13 02:58:09 --> Router Class Initialized
INFO - 2021-12-13 02:58:09 --> Output Class Initialized
INFO - 2021-12-13 02:58:09 --> Security Class Initialized
DEBUG - 2021-12-13 02:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:58:09 --> Input Class Initialized
INFO - 2021-12-13 02:58:09 --> Language Class Initialized
INFO - 2021-12-13 02:58:09 --> Language Class Initialized
INFO - 2021-12-13 02:58:09 --> Config Class Initialized
INFO - 2021-12-13 02:58:09 --> Loader Class Initialized
INFO - 2021-12-13 02:58:09 --> Helper loaded: url_helper
INFO - 2021-12-13 02:58:09 --> Helper loaded: file_helper
INFO - 2021-12-13 02:58:09 --> Helper loaded: form_helper
INFO - 2021-12-13 02:58:09 --> Helper loaded: my_helper
INFO - 2021-12-13 02:58:09 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:58:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:58:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:58:09 --> Controller Class Initialized
DEBUG - 2021-12-13 02:58:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 02:58:09 --> Final output sent to browser
DEBUG - 2021-12-13 02:58:09 --> Total execution time: 0.1060
INFO - 2021-12-13 02:58:12 --> Config Class Initialized
INFO - 2021-12-13 02:58:12 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:58:12 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:58:12 --> Utf8 Class Initialized
INFO - 2021-12-13 02:58:12 --> URI Class Initialized
INFO - 2021-12-13 02:58:12 --> Router Class Initialized
INFO - 2021-12-13 02:58:12 --> Output Class Initialized
INFO - 2021-12-13 02:58:12 --> Security Class Initialized
DEBUG - 2021-12-13 02:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:58:12 --> Input Class Initialized
INFO - 2021-12-13 02:58:12 --> Language Class Initialized
INFO - 2021-12-13 02:58:12 --> Language Class Initialized
INFO - 2021-12-13 02:58:12 --> Config Class Initialized
INFO - 2021-12-13 02:58:12 --> Loader Class Initialized
INFO - 2021-12-13 02:58:12 --> Helper loaded: url_helper
INFO - 2021-12-13 02:58:12 --> Helper loaded: file_helper
INFO - 2021-12-13 02:58:12 --> Helper loaded: form_helper
INFO - 2021-12-13 02:58:12 --> Helper loaded: my_helper
INFO - 2021-12-13 02:58:12 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:58:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:58:12 --> Controller Class Initialized
DEBUG - 2021-12-13 02:58:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 02:58:12 --> Final output sent to browser
DEBUG - 2021-12-13 02:58:12 --> Total execution time: 0.1360
INFO - 2021-12-13 02:58:13 --> Config Class Initialized
INFO - 2021-12-13 02:58:13 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:58:13 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:58:13 --> Utf8 Class Initialized
INFO - 2021-12-13 02:58:13 --> URI Class Initialized
INFO - 2021-12-13 02:58:13 --> Router Class Initialized
INFO - 2021-12-13 02:58:13 --> Output Class Initialized
INFO - 2021-12-13 02:58:13 --> Security Class Initialized
DEBUG - 2021-12-13 02:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:58:13 --> Input Class Initialized
INFO - 2021-12-13 02:58:13 --> Language Class Initialized
INFO - 2021-12-13 02:58:13 --> Language Class Initialized
INFO - 2021-12-13 02:58:13 --> Config Class Initialized
INFO - 2021-12-13 02:58:13 --> Loader Class Initialized
INFO - 2021-12-13 02:58:13 --> Helper loaded: url_helper
INFO - 2021-12-13 02:58:13 --> Helper loaded: file_helper
INFO - 2021-12-13 02:58:13 --> Helper loaded: form_helper
INFO - 2021-12-13 02:58:13 --> Helper loaded: my_helper
INFO - 2021-12-13 02:58:13 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:58:13 --> Controller Class Initialized
DEBUG - 2021-12-13 02:58:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 02:58:13 --> Final output sent to browser
DEBUG - 2021-12-13 02:58:13 --> Total execution time: 0.1310
INFO - 2021-12-13 02:59:21 --> Config Class Initialized
INFO - 2021-12-13 02:59:21 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:59:21 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:59:21 --> Utf8 Class Initialized
INFO - 2021-12-13 02:59:21 --> URI Class Initialized
INFO - 2021-12-13 02:59:21 --> Router Class Initialized
INFO - 2021-12-13 02:59:21 --> Output Class Initialized
INFO - 2021-12-13 02:59:21 --> Security Class Initialized
DEBUG - 2021-12-13 02:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:59:21 --> Input Class Initialized
INFO - 2021-12-13 02:59:21 --> Language Class Initialized
INFO - 2021-12-13 02:59:21 --> Language Class Initialized
INFO - 2021-12-13 02:59:21 --> Config Class Initialized
INFO - 2021-12-13 02:59:21 --> Loader Class Initialized
INFO - 2021-12-13 02:59:21 --> Helper loaded: url_helper
INFO - 2021-12-13 02:59:21 --> Helper loaded: file_helper
INFO - 2021-12-13 02:59:21 --> Helper loaded: form_helper
INFO - 2021-12-13 02:59:21 --> Helper loaded: my_helper
INFO - 2021-12-13 02:59:21 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:59:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:59:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:59:21 --> Controller Class Initialized
DEBUG - 2021-12-13 02:59:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 02:59:21 --> Final output sent to browser
DEBUG - 2021-12-13 02:59:21 --> Total execution time: 0.1380
INFO - 2021-12-13 02:59:38 --> Config Class Initialized
INFO - 2021-12-13 02:59:38 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:59:38 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:59:38 --> Utf8 Class Initialized
INFO - 2021-12-13 02:59:38 --> URI Class Initialized
INFO - 2021-12-13 02:59:38 --> Router Class Initialized
INFO - 2021-12-13 02:59:38 --> Output Class Initialized
INFO - 2021-12-13 02:59:38 --> Security Class Initialized
DEBUG - 2021-12-13 02:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:59:38 --> Input Class Initialized
INFO - 2021-12-13 02:59:38 --> Language Class Initialized
INFO - 2021-12-13 02:59:38 --> Language Class Initialized
INFO - 2021-12-13 02:59:38 --> Config Class Initialized
INFO - 2021-12-13 02:59:38 --> Loader Class Initialized
INFO - 2021-12-13 02:59:38 --> Helper loaded: url_helper
INFO - 2021-12-13 02:59:38 --> Helper loaded: file_helper
INFO - 2021-12-13 02:59:38 --> Helper loaded: form_helper
INFO - 2021-12-13 02:59:38 --> Helper loaded: my_helper
INFO - 2021-12-13 02:59:38 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:59:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:59:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:59:38 --> Controller Class Initialized
DEBUG - 2021-12-13 02:59:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 02:59:38 --> Final output sent to browser
DEBUG - 2021-12-13 02:59:38 --> Total execution time: 0.1350
INFO - 2021-12-13 02:59:39 --> Config Class Initialized
INFO - 2021-12-13 02:59:39 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:59:39 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:59:39 --> Utf8 Class Initialized
INFO - 2021-12-13 02:59:39 --> URI Class Initialized
INFO - 2021-12-13 02:59:39 --> Router Class Initialized
INFO - 2021-12-13 02:59:39 --> Output Class Initialized
INFO - 2021-12-13 02:59:39 --> Security Class Initialized
DEBUG - 2021-12-13 02:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:59:39 --> Input Class Initialized
INFO - 2021-12-13 02:59:39 --> Language Class Initialized
INFO - 2021-12-13 02:59:39 --> Language Class Initialized
INFO - 2021-12-13 02:59:39 --> Config Class Initialized
INFO - 2021-12-13 02:59:39 --> Loader Class Initialized
INFO - 2021-12-13 02:59:39 --> Helper loaded: url_helper
INFO - 2021-12-13 02:59:39 --> Helper loaded: file_helper
INFO - 2021-12-13 02:59:39 --> Helper loaded: form_helper
INFO - 2021-12-13 02:59:39 --> Helper loaded: my_helper
INFO - 2021-12-13 02:59:39 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:59:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:59:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:59:39 --> Controller Class Initialized
DEBUG - 2021-12-13 02:59:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 02:59:39 --> Final output sent to browser
DEBUG - 2021-12-13 02:59:39 --> Total execution time: 0.1440
INFO - 2021-12-13 02:59:40 --> Config Class Initialized
INFO - 2021-12-13 02:59:40 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:59:40 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:59:40 --> Utf8 Class Initialized
INFO - 2021-12-13 02:59:40 --> URI Class Initialized
INFO - 2021-12-13 02:59:40 --> Router Class Initialized
INFO - 2021-12-13 02:59:40 --> Output Class Initialized
INFO - 2021-12-13 02:59:40 --> Security Class Initialized
DEBUG - 2021-12-13 02:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:59:40 --> Input Class Initialized
INFO - 2021-12-13 02:59:40 --> Language Class Initialized
INFO - 2021-12-13 02:59:40 --> Language Class Initialized
INFO - 2021-12-13 02:59:40 --> Config Class Initialized
INFO - 2021-12-13 02:59:40 --> Loader Class Initialized
INFO - 2021-12-13 02:59:40 --> Helper loaded: url_helper
INFO - 2021-12-13 02:59:40 --> Helper loaded: file_helper
INFO - 2021-12-13 02:59:40 --> Helper loaded: form_helper
INFO - 2021-12-13 02:59:40 --> Helper loaded: my_helper
INFO - 2021-12-13 02:59:40 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:59:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:59:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:59:40 --> Controller Class Initialized
DEBUG - 2021-12-13 02:59:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 02:59:40 --> Final output sent to browser
DEBUG - 2021-12-13 02:59:40 --> Total execution time: 0.1110
INFO - 2021-12-13 02:59:41 --> Config Class Initialized
INFO - 2021-12-13 02:59:41 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:59:41 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:59:41 --> Utf8 Class Initialized
INFO - 2021-12-13 02:59:41 --> URI Class Initialized
INFO - 2021-12-13 02:59:41 --> Router Class Initialized
INFO - 2021-12-13 02:59:41 --> Output Class Initialized
INFO - 2021-12-13 02:59:41 --> Security Class Initialized
DEBUG - 2021-12-13 02:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:59:41 --> Input Class Initialized
INFO - 2021-12-13 02:59:41 --> Language Class Initialized
INFO - 2021-12-13 02:59:41 --> Language Class Initialized
INFO - 2021-12-13 02:59:41 --> Config Class Initialized
INFO - 2021-12-13 02:59:41 --> Loader Class Initialized
INFO - 2021-12-13 02:59:41 --> Helper loaded: url_helper
INFO - 2021-12-13 02:59:41 --> Helper loaded: file_helper
INFO - 2021-12-13 02:59:41 --> Helper loaded: form_helper
INFO - 2021-12-13 02:59:41 --> Helper loaded: my_helper
INFO - 2021-12-13 02:59:41 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:59:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:59:41 --> Controller Class Initialized
DEBUG - 2021-12-13 02:59:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 02:59:41 --> Final output sent to browser
DEBUG - 2021-12-13 02:59:41 --> Total execution time: 0.1330
INFO - 2021-12-13 02:59:41 --> Config Class Initialized
INFO - 2021-12-13 02:59:41 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:59:41 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:59:41 --> Utf8 Class Initialized
INFO - 2021-12-13 02:59:41 --> URI Class Initialized
INFO - 2021-12-13 02:59:41 --> Router Class Initialized
INFO - 2021-12-13 02:59:41 --> Output Class Initialized
INFO - 2021-12-13 02:59:41 --> Security Class Initialized
DEBUG - 2021-12-13 02:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:59:41 --> Input Class Initialized
INFO - 2021-12-13 02:59:41 --> Language Class Initialized
INFO - 2021-12-13 02:59:41 --> Language Class Initialized
INFO - 2021-12-13 02:59:41 --> Config Class Initialized
INFO - 2021-12-13 02:59:41 --> Loader Class Initialized
INFO - 2021-12-13 02:59:41 --> Helper loaded: url_helper
INFO - 2021-12-13 02:59:41 --> Helper loaded: file_helper
INFO - 2021-12-13 02:59:41 --> Helper loaded: form_helper
INFO - 2021-12-13 02:59:41 --> Helper loaded: my_helper
INFO - 2021-12-13 02:59:41 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:59:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:59:41 --> Controller Class Initialized
DEBUG - 2021-12-13 02:59:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 02:59:42 --> Final output sent to browser
DEBUG - 2021-12-13 02:59:42 --> Total execution time: 0.1510
INFO - 2021-12-13 02:59:43 --> Config Class Initialized
INFO - 2021-12-13 02:59:43 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:59:43 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:59:43 --> Utf8 Class Initialized
INFO - 2021-12-13 02:59:43 --> URI Class Initialized
INFO - 2021-12-13 02:59:43 --> Router Class Initialized
INFO - 2021-12-13 02:59:43 --> Output Class Initialized
INFO - 2021-12-13 02:59:43 --> Security Class Initialized
DEBUG - 2021-12-13 02:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:59:43 --> Input Class Initialized
INFO - 2021-12-13 02:59:43 --> Language Class Initialized
INFO - 2021-12-13 02:59:43 --> Language Class Initialized
INFO - 2021-12-13 02:59:43 --> Config Class Initialized
INFO - 2021-12-13 02:59:43 --> Loader Class Initialized
INFO - 2021-12-13 02:59:43 --> Helper loaded: url_helper
INFO - 2021-12-13 02:59:43 --> Helper loaded: file_helper
INFO - 2021-12-13 02:59:43 --> Helper loaded: form_helper
INFO - 2021-12-13 02:59:43 --> Helper loaded: my_helper
INFO - 2021-12-13 02:59:43 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:59:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:59:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:59:43 --> Controller Class Initialized
DEBUG - 2021-12-13 02:59:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 02:59:44 --> Final output sent to browser
DEBUG - 2021-12-13 02:59:44 --> Total execution time: 0.1410
INFO - 2021-12-13 02:59:44 --> Config Class Initialized
INFO - 2021-12-13 02:59:44 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:59:44 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:59:44 --> Utf8 Class Initialized
INFO - 2021-12-13 02:59:44 --> URI Class Initialized
INFO - 2021-12-13 02:59:44 --> Router Class Initialized
INFO - 2021-12-13 02:59:44 --> Output Class Initialized
INFO - 2021-12-13 02:59:44 --> Security Class Initialized
DEBUG - 2021-12-13 02:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:59:44 --> Input Class Initialized
INFO - 2021-12-13 02:59:44 --> Language Class Initialized
INFO - 2021-12-13 02:59:44 --> Language Class Initialized
INFO - 2021-12-13 02:59:44 --> Config Class Initialized
INFO - 2021-12-13 02:59:44 --> Loader Class Initialized
INFO - 2021-12-13 02:59:44 --> Helper loaded: url_helper
INFO - 2021-12-13 02:59:44 --> Helper loaded: file_helper
INFO - 2021-12-13 02:59:44 --> Helper loaded: form_helper
INFO - 2021-12-13 02:59:44 --> Helper loaded: my_helper
INFO - 2021-12-13 02:59:44 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:59:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:59:44 --> Controller Class Initialized
DEBUG - 2021-12-13 02:59:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 02:59:44 --> Final output sent to browser
DEBUG - 2021-12-13 02:59:44 --> Total execution time: 0.1410
INFO - 2021-12-13 02:59:45 --> Config Class Initialized
INFO - 2021-12-13 02:59:45 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:59:45 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:59:45 --> Utf8 Class Initialized
INFO - 2021-12-13 02:59:45 --> URI Class Initialized
INFO - 2021-12-13 02:59:45 --> Router Class Initialized
INFO - 2021-12-13 02:59:45 --> Output Class Initialized
INFO - 2021-12-13 02:59:45 --> Security Class Initialized
DEBUG - 2021-12-13 02:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:59:45 --> Input Class Initialized
INFO - 2021-12-13 02:59:45 --> Language Class Initialized
INFO - 2021-12-13 02:59:45 --> Language Class Initialized
INFO - 2021-12-13 02:59:45 --> Config Class Initialized
INFO - 2021-12-13 02:59:45 --> Loader Class Initialized
INFO - 2021-12-13 02:59:45 --> Helper loaded: url_helper
INFO - 2021-12-13 02:59:45 --> Helper loaded: file_helper
INFO - 2021-12-13 02:59:45 --> Helper loaded: form_helper
INFO - 2021-12-13 02:59:45 --> Helper loaded: my_helper
INFO - 2021-12-13 02:59:45 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:59:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:59:45 --> Controller Class Initialized
DEBUG - 2021-12-13 02:59:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 02:59:45 --> Final output sent to browser
DEBUG - 2021-12-13 02:59:45 --> Total execution time: 0.1440
INFO - 2021-12-13 02:59:46 --> Config Class Initialized
INFO - 2021-12-13 02:59:46 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:59:46 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:59:46 --> Utf8 Class Initialized
INFO - 2021-12-13 02:59:46 --> URI Class Initialized
INFO - 2021-12-13 02:59:46 --> Router Class Initialized
INFO - 2021-12-13 02:59:46 --> Output Class Initialized
INFO - 2021-12-13 02:59:46 --> Security Class Initialized
DEBUG - 2021-12-13 02:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:59:46 --> Input Class Initialized
INFO - 2021-12-13 02:59:46 --> Language Class Initialized
INFO - 2021-12-13 02:59:46 --> Language Class Initialized
INFO - 2021-12-13 02:59:46 --> Config Class Initialized
INFO - 2021-12-13 02:59:46 --> Loader Class Initialized
INFO - 2021-12-13 02:59:46 --> Helper loaded: url_helper
INFO - 2021-12-13 02:59:46 --> Helper loaded: file_helper
INFO - 2021-12-13 02:59:46 --> Helper loaded: form_helper
INFO - 2021-12-13 02:59:46 --> Helper loaded: my_helper
INFO - 2021-12-13 02:59:46 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:59:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:59:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:59:46 --> Controller Class Initialized
DEBUG - 2021-12-13 02:59:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 02:59:46 --> Final output sent to browser
DEBUG - 2021-12-13 02:59:46 --> Total execution time: 0.1510
INFO - 2021-12-13 02:59:47 --> Config Class Initialized
INFO - 2021-12-13 02:59:47 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:59:47 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:59:47 --> Utf8 Class Initialized
INFO - 2021-12-13 02:59:47 --> URI Class Initialized
INFO - 2021-12-13 02:59:47 --> Router Class Initialized
INFO - 2021-12-13 02:59:47 --> Output Class Initialized
INFO - 2021-12-13 02:59:47 --> Security Class Initialized
DEBUG - 2021-12-13 02:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:59:47 --> Input Class Initialized
INFO - 2021-12-13 02:59:47 --> Language Class Initialized
INFO - 2021-12-13 02:59:47 --> Language Class Initialized
INFO - 2021-12-13 02:59:47 --> Config Class Initialized
INFO - 2021-12-13 02:59:47 --> Loader Class Initialized
INFO - 2021-12-13 02:59:47 --> Helper loaded: url_helper
INFO - 2021-12-13 02:59:47 --> Helper loaded: file_helper
INFO - 2021-12-13 02:59:47 --> Helper loaded: form_helper
INFO - 2021-12-13 02:59:47 --> Helper loaded: my_helper
INFO - 2021-12-13 02:59:47 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:59:47 --> Controller Class Initialized
DEBUG - 2021-12-13 02:59:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 02:59:47 --> Final output sent to browser
DEBUG - 2021-12-13 02:59:47 --> Total execution time: 0.1200
INFO - 2021-12-13 02:59:48 --> Config Class Initialized
INFO - 2021-12-13 02:59:48 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:59:48 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:59:48 --> Utf8 Class Initialized
INFO - 2021-12-13 02:59:48 --> URI Class Initialized
INFO - 2021-12-13 02:59:48 --> Router Class Initialized
INFO - 2021-12-13 02:59:48 --> Output Class Initialized
INFO - 2021-12-13 02:59:48 --> Security Class Initialized
DEBUG - 2021-12-13 02:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:59:48 --> Input Class Initialized
INFO - 2021-12-13 02:59:48 --> Language Class Initialized
INFO - 2021-12-13 02:59:48 --> Language Class Initialized
INFO - 2021-12-13 02:59:48 --> Config Class Initialized
INFO - 2021-12-13 02:59:48 --> Loader Class Initialized
INFO - 2021-12-13 02:59:48 --> Helper loaded: url_helper
INFO - 2021-12-13 02:59:48 --> Helper loaded: file_helper
INFO - 2021-12-13 02:59:48 --> Helper loaded: form_helper
INFO - 2021-12-13 02:59:48 --> Helper loaded: my_helper
INFO - 2021-12-13 02:59:48 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:59:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:59:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:59:48 --> Controller Class Initialized
DEBUG - 2021-12-13 02:59:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 02:59:48 --> Final output sent to browser
DEBUG - 2021-12-13 02:59:48 --> Total execution time: 0.1390
INFO - 2021-12-13 02:59:48 --> Config Class Initialized
INFO - 2021-12-13 02:59:48 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:59:48 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:59:48 --> Utf8 Class Initialized
INFO - 2021-12-13 02:59:48 --> URI Class Initialized
INFO - 2021-12-13 02:59:48 --> Router Class Initialized
INFO - 2021-12-13 02:59:48 --> Output Class Initialized
INFO - 2021-12-13 02:59:48 --> Security Class Initialized
DEBUG - 2021-12-13 02:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:59:48 --> Input Class Initialized
INFO - 2021-12-13 02:59:48 --> Language Class Initialized
INFO - 2021-12-13 02:59:48 --> Language Class Initialized
INFO - 2021-12-13 02:59:48 --> Config Class Initialized
INFO - 2021-12-13 02:59:48 --> Loader Class Initialized
INFO - 2021-12-13 02:59:48 --> Helper loaded: url_helper
INFO - 2021-12-13 02:59:48 --> Helper loaded: file_helper
INFO - 2021-12-13 02:59:48 --> Helper loaded: form_helper
INFO - 2021-12-13 02:59:48 --> Helper loaded: my_helper
INFO - 2021-12-13 02:59:48 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:59:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:59:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:59:48 --> Controller Class Initialized
DEBUG - 2021-12-13 02:59:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 02:59:49 --> Final output sent to browser
DEBUG - 2021-12-13 02:59:49 --> Total execution time: 0.1460
INFO - 2021-12-13 02:59:49 --> Config Class Initialized
INFO - 2021-12-13 02:59:49 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:59:49 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:59:49 --> Utf8 Class Initialized
INFO - 2021-12-13 02:59:49 --> URI Class Initialized
INFO - 2021-12-13 02:59:49 --> Router Class Initialized
INFO - 2021-12-13 02:59:49 --> Output Class Initialized
INFO - 2021-12-13 02:59:49 --> Security Class Initialized
DEBUG - 2021-12-13 02:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:59:49 --> Input Class Initialized
INFO - 2021-12-13 02:59:49 --> Language Class Initialized
INFO - 2021-12-13 02:59:49 --> Language Class Initialized
INFO - 2021-12-13 02:59:49 --> Config Class Initialized
INFO - 2021-12-13 02:59:49 --> Loader Class Initialized
INFO - 2021-12-13 02:59:49 --> Helper loaded: url_helper
INFO - 2021-12-13 02:59:49 --> Helper loaded: file_helper
INFO - 2021-12-13 02:59:49 --> Helper loaded: form_helper
INFO - 2021-12-13 02:59:49 --> Helper loaded: my_helper
INFO - 2021-12-13 02:59:49 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:59:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:59:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:59:49 --> Controller Class Initialized
DEBUG - 2021-12-13 02:59:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 02:59:49 --> Final output sent to browser
DEBUG - 2021-12-13 02:59:49 --> Total execution time: 0.1450
INFO - 2021-12-13 02:59:50 --> Config Class Initialized
INFO - 2021-12-13 02:59:50 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:59:50 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:59:50 --> Utf8 Class Initialized
INFO - 2021-12-13 02:59:50 --> URI Class Initialized
INFO - 2021-12-13 02:59:50 --> Router Class Initialized
INFO - 2021-12-13 02:59:50 --> Output Class Initialized
INFO - 2021-12-13 02:59:50 --> Security Class Initialized
DEBUG - 2021-12-13 02:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:59:50 --> Input Class Initialized
INFO - 2021-12-13 02:59:50 --> Language Class Initialized
INFO - 2021-12-13 02:59:50 --> Language Class Initialized
INFO - 2021-12-13 02:59:50 --> Config Class Initialized
INFO - 2021-12-13 02:59:50 --> Loader Class Initialized
INFO - 2021-12-13 02:59:50 --> Helper loaded: url_helper
INFO - 2021-12-13 02:59:50 --> Helper loaded: file_helper
INFO - 2021-12-13 02:59:50 --> Helper loaded: form_helper
INFO - 2021-12-13 02:59:50 --> Helper loaded: my_helper
INFO - 2021-12-13 02:59:50 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:59:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:59:50 --> Controller Class Initialized
DEBUG - 2021-12-13 02:59:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 02:59:50 --> Final output sent to browser
DEBUG - 2021-12-13 02:59:50 --> Total execution time: 0.1410
INFO - 2021-12-13 02:59:51 --> Config Class Initialized
INFO - 2021-12-13 02:59:51 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:59:51 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:59:51 --> Utf8 Class Initialized
INFO - 2021-12-13 02:59:51 --> URI Class Initialized
INFO - 2021-12-13 02:59:51 --> Router Class Initialized
INFO - 2021-12-13 02:59:51 --> Output Class Initialized
INFO - 2021-12-13 02:59:51 --> Security Class Initialized
DEBUG - 2021-12-13 02:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:59:51 --> Input Class Initialized
INFO - 2021-12-13 02:59:51 --> Language Class Initialized
INFO - 2021-12-13 02:59:51 --> Language Class Initialized
INFO - 2021-12-13 02:59:51 --> Config Class Initialized
INFO - 2021-12-13 02:59:51 --> Loader Class Initialized
INFO - 2021-12-13 02:59:51 --> Helper loaded: url_helper
INFO - 2021-12-13 02:59:51 --> Helper loaded: file_helper
INFO - 2021-12-13 02:59:51 --> Helper loaded: form_helper
INFO - 2021-12-13 02:59:51 --> Helper loaded: my_helper
INFO - 2021-12-13 02:59:51 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:59:51 --> Controller Class Initialized
DEBUG - 2021-12-13 02:59:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 02:59:51 --> Final output sent to browser
DEBUG - 2021-12-13 02:59:51 --> Total execution time: 0.1140
INFO - 2021-12-13 02:59:51 --> Config Class Initialized
INFO - 2021-12-13 02:59:51 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:59:51 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:59:51 --> Utf8 Class Initialized
INFO - 2021-12-13 02:59:51 --> URI Class Initialized
INFO - 2021-12-13 02:59:51 --> Router Class Initialized
INFO - 2021-12-13 02:59:52 --> Output Class Initialized
INFO - 2021-12-13 02:59:52 --> Security Class Initialized
DEBUG - 2021-12-13 02:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:59:52 --> Input Class Initialized
INFO - 2021-12-13 02:59:52 --> Language Class Initialized
INFO - 2021-12-13 02:59:52 --> Language Class Initialized
INFO - 2021-12-13 02:59:52 --> Config Class Initialized
INFO - 2021-12-13 02:59:52 --> Loader Class Initialized
INFO - 2021-12-13 02:59:52 --> Helper loaded: url_helper
INFO - 2021-12-13 02:59:52 --> Helper loaded: file_helper
INFO - 2021-12-13 02:59:52 --> Helper loaded: form_helper
INFO - 2021-12-13 02:59:52 --> Helper loaded: my_helper
INFO - 2021-12-13 02:59:52 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:59:52 --> Controller Class Initialized
DEBUG - 2021-12-13 02:59:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 02:59:52 --> Final output sent to browser
DEBUG - 2021-12-13 02:59:52 --> Total execution time: 0.1420
INFO - 2021-12-13 02:59:52 --> Config Class Initialized
INFO - 2021-12-13 02:59:52 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:59:52 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:59:52 --> Utf8 Class Initialized
INFO - 2021-12-13 02:59:52 --> URI Class Initialized
INFO - 2021-12-13 02:59:52 --> Router Class Initialized
INFO - 2021-12-13 02:59:52 --> Output Class Initialized
INFO - 2021-12-13 02:59:52 --> Security Class Initialized
DEBUG - 2021-12-13 02:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:59:52 --> Input Class Initialized
INFO - 2021-12-13 02:59:52 --> Language Class Initialized
INFO - 2021-12-13 02:59:52 --> Language Class Initialized
INFO - 2021-12-13 02:59:52 --> Config Class Initialized
INFO - 2021-12-13 02:59:52 --> Loader Class Initialized
INFO - 2021-12-13 02:59:52 --> Helper loaded: url_helper
INFO - 2021-12-13 02:59:52 --> Helper loaded: file_helper
INFO - 2021-12-13 02:59:52 --> Helper loaded: form_helper
INFO - 2021-12-13 02:59:52 --> Helper loaded: my_helper
INFO - 2021-12-13 02:59:52 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:59:52 --> Controller Class Initialized
DEBUG - 2021-12-13 02:59:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 02:59:52 --> Final output sent to browser
DEBUG - 2021-12-13 02:59:52 --> Total execution time: 0.1430
INFO - 2021-12-13 02:59:53 --> Config Class Initialized
INFO - 2021-12-13 02:59:53 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:59:53 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:59:53 --> Utf8 Class Initialized
INFO - 2021-12-13 02:59:53 --> URI Class Initialized
INFO - 2021-12-13 02:59:53 --> Router Class Initialized
INFO - 2021-12-13 02:59:53 --> Output Class Initialized
INFO - 2021-12-13 02:59:53 --> Security Class Initialized
DEBUG - 2021-12-13 02:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:59:53 --> Input Class Initialized
INFO - 2021-12-13 02:59:53 --> Language Class Initialized
INFO - 2021-12-13 02:59:53 --> Language Class Initialized
INFO - 2021-12-13 02:59:53 --> Config Class Initialized
INFO - 2021-12-13 02:59:53 --> Loader Class Initialized
INFO - 2021-12-13 02:59:53 --> Helper loaded: url_helper
INFO - 2021-12-13 02:59:53 --> Helper loaded: file_helper
INFO - 2021-12-13 02:59:53 --> Helper loaded: form_helper
INFO - 2021-12-13 02:59:53 --> Helper loaded: my_helper
INFO - 2021-12-13 02:59:53 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:59:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:59:53 --> Controller Class Initialized
DEBUG - 2021-12-13 02:59:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 02:59:53 --> Final output sent to browser
DEBUG - 2021-12-13 02:59:53 --> Total execution time: 0.1470
INFO - 2021-12-13 02:59:54 --> Config Class Initialized
INFO - 2021-12-13 02:59:54 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:59:54 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:59:54 --> Utf8 Class Initialized
INFO - 2021-12-13 02:59:54 --> URI Class Initialized
INFO - 2021-12-13 02:59:54 --> Router Class Initialized
INFO - 2021-12-13 02:59:54 --> Output Class Initialized
INFO - 2021-12-13 02:59:54 --> Security Class Initialized
DEBUG - 2021-12-13 02:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:59:54 --> Input Class Initialized
INFO - 2021-12-13 02:59:54 --> Language Class Initialized
INFO - 2021-12-13 02:59:54 --> Language Class Initialized
INFO - 2021-12-13 02:59:54 --> Config Class Initialized
INFO - 2021-12-13 02:59:54 --> Loader Class Initialized
INFO - 2021-12-13 02:59:54 --> Helper loaded: url_helper
INFO - 2021-12-13 02:59:54 --> Helper loaded: file_helper
INFO - 2021-12-13 02:59:54 --> Helper loaded: form_helper
INFO - 2021-12-13 02:59:54 --> Helper loaded: my_helper
INFO - 2021-12-13 02:59:54 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:59:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:59:54 --> Controller Class Initialized
DEBUG - 2021-12-13 02:59:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 02:59:54 --> Final output sent to browser
DEBUG - 2021-12-13 02:59:54 --> Total execution time: 0.1450
INFO - 2021-12-13 02:59:55 --> Config Class Initialized
INFO - 2021-12-13 02:59:55 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:59:55 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:59:55 --> Utf8 Class Initialized
INFO - 2021-12-13 02:59:55 --> URI Class Initialized
INFO - 2021-12-13 02:59:55 --> Router Class Initialized
INFO - 2021-12-13 02:59:55 --> Output Class Initialized
INFO - 2021-12-13 02:59:55 --> Security Class Initialized
DEBUG - 2021-12-13 02:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:59:55 --> Input Class Initialized
INFO - 2021-12-13 02:59:55 --> Language Class Initialized
INFO - 2021-12-13 02:59:55 --> Language Class Initialized
INFO - 2021-12-13 02:59:55 --> Config Class Initialized
INFO - 2021-12-13 02:59:55 --> Loader Class Initialized
INFO - 2021-12-13 02:59:55 --> Helper loaded: url_helper
INFO - 2021-12-13 02:59:55 --> Helper loaded: file_helper
INFO - 2021-12-13 02:59:55 --> Helper loaded: form_helper
INFO - 2021-12-13 02:59:55 --> Helper loaded: my_helper
INFO - 2021-12-13 02:59:55 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:59:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:59:55 --> Controller Class Initialized
DEBUG - 2021-12-13 02:59:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 02:59:55 --> Final output sent to browser
DEBUG - 2021-12-13 02:59:55 --> Total execution time: 0.1150
INFO - 2021-12-13 02:59:56 --> Config Class Initialized
INFO - 2021-12-13 02:59:56 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:59:56 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:59:56 --> Utf8 Class Initialized
INFO - 2021-12-13 02:59:56 --> URI Class Initialized
INFO - 2021-12-13 02:59:56 --> Router Class Initialized
INFO - 2021-12-13 02:59:56 --> Output Class Initialized
INFO - 2021-12-13 02:59:56 --> Security Class Initialized
DEBUG - 2021-12-13 02:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:59:56 --> Input Class Initialized
INFO - 2021-12-13 02:59:56 --> Language Class Initialized
INFO - 2021-12-13 02:59:56 --> Language Class Initialized
INFO - 2021-12-13 02:59:56 --> Config Class Initialized
INFO - 2021-12-13 02:59:56 --> Loader Class Initialized
INFO - 2021-12-13 02:59:56 --> Helper loaded: url_helper
INFO - 2021-12-13 02:59:56 --> Helper loaded: file_helper
INFO - 2021-12-13 02:59:56 --> Helper loaded: form_helper
INFO - 2021-12-13 02:59:56 --> Helper loaded: my_helper
INFO - 2021-12-13 02:59:56 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:59:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:59:56 --> Controller Class Initialized
DEBUG - 2021-12-13 02:59:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 02:59:56 --> Final output sent to browser
DEBUG - 2021-12-13 02:59:56 --> Total execution time: 0.1390
INFO - 2021-12-13 02:59:56 --> Config Class Initialized
INFO - 2021-12-13 02:59:56 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:59:56 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:59:56 --> Utf8 Class Initialized
INFO - 2021-12-13 02:59:56 --> URI Class Initialized
INFO - 2021-12-13 02:59:56 --> Router Class Initialized
INFO - 2021-12-13 02:59:56 --> Output Class Initialized
INFO - 2021-12-13 02:59:56 --> Security Class Initialized
DEBUG - 2021-12-13 02:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:59:56 --> Input Class Initialized
INFO - 2021-12-13 02:59:56 --> Language Class Initialized
INFO - 2021-12-13 02:59:56 --> Language Class Initialized
INFO - 2021-12-13 02:59:56 --> Config Class Initialized
INFO - 2021-12-13 02:59:56 --> Loader Class Initialized
INFO - 2021-12-13 02:59:56 --> Helper loaded: url_helper
INFO - 2021-12-13 02:59:56 --> Helper loaded: file_helper
INFO - 2021-12-13 02:59:56 --> Helper loaded: form_helper
INFO - 2021-12-13 02:59:56 --> Helper loaded: my_helper
INFO - 2021-12-13 02:59:56 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:59:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:59:56 --> Controller Class Initialized
DEBUG - 2021-12-13 02:59:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 02:59:56 --> Final output sent to browser
DEBUG - 2021-12-13 02:59:56 --> Total execution time: 0.1420
INFO - 2021-12-13 02:59:57 --> Config Class Initialized
INFO - 2021-12-13 02:59:57 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:59:57 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:59:57 --> Utf8 Class Initialized
INFO - 2021-12-13 02:59:57 --> URI Class Initialized
INFO - 2021-12-13 02:59:57 --> Router Class Initialized
INFO - 2021-12-13 02:59:57 --> Output Class Initialized
INFO - 2021-12-13 02:59:57 --> Security Class Initialized
DEBUG - 2021-12-13 02:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:59:57 --> Input Class Initialized
INFO - 2021-12-13 02:59:57 --> Language Class Initialized
INFO - 2021-12-13 02:59:57 --> Language Class Initialized
INFO - 2021-12-13 02:59:57 --> Config Class Initialized
INFO - 2021-12-13 02:59:57 --> Loader Class Initialized
INFO - 2021-12-13 02:59:57 --> Helper loaded: url_helper
INFO - 2021-12-13 02:59:57 --> Helper loaded: file_helper
INFO - 2021-12-13 02:59:57 --> Helper loaded: form_helper
INFO - 2021-12-13 02:59:57 --> Helper loaded: my_helper
INFO - 2021-12-13 02:59:57 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:59:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:59:57 --> Controller Class Initialized
DEBUG - 2021-12-13 02:59:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 02:59:57 --> Final output sent to browser
DEBUG - 2021-12-13 02:59:57 --> Total execution time: 0.1410
INFO - 2021-12-13 02:59:58 --> Config Class Initialized
INFO - 2021-12-13 02:59:58 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:59:58 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:59:58 --> Utf8 Class Initialized
INFO - 2021-12-13 02:59:58 --> URI Class Initialized
INFO - 2021-12-13 02:59:58 --> Router Class Initialized
INFO - 2021-12-13 02:59:58 --> Output Class Initialized
INFO - 2021-12-13 02:59:58 --> Security Class Initialized
DEBUG - 2021-12-13 02:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:59:58 --> Input Class Initialized
INFO - 2021-12-13 02:59:58 --> Language Class Initialized
INFO - 2021-12-13 02:59:58 --> Language Class Initialized
INFO - 2021-12-13 02:59:58 --> Config Class Initialized
INFO - 2021-12-13 02:59:58 --> Loader Class Initialized
INFO - 2021-12-13 02:59:58 --> Helper loaded: url_helper
INFO - 2021-12-13 02:59:58 --> Helper loaded: file_helper
INFO - 2021-12-13 02:59:58 --> Helper loaded: form_helper
INFO - 2021-12-13 02:59:58 --> Helper loaded: my_helper
INFO - 2021-12-13 02:59:58 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:59:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:59:58 --> Controller Class Initialized
DEBUG - 2021-12-13 02:59:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 02:59:58 --> Final output sent to browser
DEBUG - 2021-12-13 02:59:58 --> Total execution time: 0.1390
INFO - 2021-12-13 02:59:59 --> Config Class Initialized
INFO - 2021-12-13 02:59:59 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:59:59 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:59:59 --> Utf8 Class Initialized
INFO - 2021-12-13 02:59:59 --> URI Class Initialized
INFO - 2021-12-13 02:59:59 --> Router Class Initialized
INFO - 2021-12-13 02:59:59 --> Output Class Initialized
INFO - 2021-12-13 02:59:59 --> Security Class Initialized
DEBUG - 2021-12-13 02:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:59:59 --> Input Class Initialized
INFO - 2021-12-13 02:59:59 --> Language Class Initialized
INFO - 2021-12-13 02:59:59 --> Language Class Initialized
INFO - 2021-12-13 02:59:59 --> Config Class Initialized
INFO - 2021-12-13 02:59:59 --> Loader Class Initialized
INFO - 2021-12-13 02:59:59 --> Helper loaded: url_helper
INFO - 2021-12-13 02:59:59 --> Helper loaded: file_helper
INFO - 2021-12-13 02:59:59 --> Helper loaded: form_helper
INFO - 2021-12-13 02:59:59 --> Helper loaded: my_helper
INFO - 2021-12-13 02:59:59 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:59:59 --> Controller Class Initialized
DEBUG - 2021-12-13 02:59:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 02:59:59 --> Final output sent to browser
DEBUG - 2021-12-13 02:59:59 --> Total execution time: 0.1470
INFO - 2021-12-13 03:10:25 --> Config Class Initialized
INFO - 2021-12-13 03:10:25 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:10:25 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:10:25 --> Utf8 Class Initialized
INFO - 2021-12-13 03:10:25 --> URI Class Initialized
INFO - 2021-12-13 03:10:25 --> Router Class Initialized
INFO - 2021-12-13 03:10:25 --> Output Class Initialized
INFO - 2021-12-13 03:10:25 --> Security Class Initialized
DEBUG - 2021-12-13 03:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:10:25 --> Input Class Initialized
INFO - 2021-12-13 03:10:25 --> Language Class Initialized
INFO - 2021-12-13 03:10:25 --> Language Class Initialized
INFO - 2021-12-13 03:10:25 --> Config Class Initialized
INFO - 2021-12-13 03:10:25 --> Loader Class Initialized
INFO - 2021-12-13 03:10:25 --> Helper loaded: url_helper
INFO - 2021-12-13 03:10:25 --> Helper loaded: file_helper
INFO - 2021-12-13 03:10:25 --> Helper loaded: form_helper
INFO - 2021-12-13 03:10:25 --> Helper loaded: my_helper
INFO - 2021-12-13 03:10:25 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:10:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:10:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:10:25 --> Controller Class Initialized
DEBUG - 2021-12-13 03:10:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-13 03:10:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 03:10:26 --> Final output sent to browser
DEBUG - 2021-12-13 03:10:26 --> Total execution time: 0.0890
INFO - 2021-12-13 03:10:37 --> Config Class Initialized
INFO - 2021-12-13 03:10:37 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:10:37 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:10:37 --> Utf8 Class Initialized
INFO - 2021-12-13 03:10:37 --> URI Class Initialized
INFO - 2021-12-13 03:10:37 --> Router Class Initialized
INFO - 2021-12-13 03:10:37 --> Output Class Initialized
INFO - 2021-12-13 03:10:37 --> Security Class Initialized
DEBUG - 2021-12-13 03:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:10:37 --> Input Class Initialized
INFO - 2021-12-13 03:10:37 --> Language Class Initialized
INFO - 2021-12-13 03:10:37 --> Language Class Initialized
INFO - 2021-12-13 03:10:37 --> Config Class Initialized
INFO - 2021-12-13 03:10:37 --> Loader Class Initialized
INFO - 2021-12-13 03:10:37 --> Helper loaded: url_helper
INFO - 2021-12-13 03:10:37 --> Helper loaded: file_helper
INFO - 2021-12-13 03:10:37 --> Helper loaded: form_helper
INFO - 2021-12-13 03:10:37 --> Helper loaded: my_helper
INFO - 2021-12-13 03:10:37 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:10:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:10:37 --> Controller Class Initialized
DEBUG - 2021-12-13 03:10:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-13 03:10:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 03:10:37 --> Final output sent to browser
DEBUG - 2021-12-13 03:10:37 --> Total execution time: 0.0560
INFO - 2021-12-13 03:11:27 --> Config Class Initialized
INFO - 2021-12-13 03:11:27 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:11:27 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:11:27 --> Utf8 Class Initialized
INFO - 2021-12-13 03:11:27 --> URI Class Initialized
INFO - 2021-12-13 03:11:27 --> Router Class Initialized
INFO - 2021-12-13 03:11:27 --> Output Class Initialized
INFO - 2021-12-13 03:11:27 --> Security Class Initialized
DEBUG - 2021-12-13 03:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:11:27 --> Input Class Initialized
INFO - 2021-12-13 03:11:27 --> Language Class Initialized
INFO - 2021-12-13 03:11:27 --> Language Class Initialized
INFO - 2021-12-13 03:11:27 --> Config Class Initialized
INFO - 2021-12-13 03:11:27 --> Loader Class Initialized
INFO - 2021-12-13 03:11:27 --> Helper loaded: url_helper
INFO - 2021-12-13 03:11:27 --> Helper loaded: file_helper
INFO - 2021-12-13 03:11:27 --> Helper loaded: form_helper
INFO - 2021-12-13 03:11:27 --> Helper loaded: my_helper
INFO - 2021-12-13 03:11:27 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:11:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:11:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:11:27 --> Controller Class Initialized
DEBUG - 2021-12-13 03:11:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 03:11:27 --> Final output sent to browser
DEBUG - 2021-12-13 03:11:27 --> Total execution time: 0.1440
INFO - 2021-12-13 03:11:38 --> Config Class Initialized
INFO - 2021-12-13 03:11:38 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:11:38 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:11:38 --> Utf8 Class Initialized
INFO - 2021-12-13 03:11:38 --> URI Class Initialized
INFO - 2021-12-13 03:11:38 --> Router Class Initialized
INFO - 2021-12-13 03:11:38 --> Output Class Initialized
INFO - 2021-12-13 03:11:38 --> Security Class Initialized
DEBUG - 2021-12-13 03:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:11:38 --> Input Class Initialized
INFO - 2021-12-13 03:11:38 --> Language Class Initialized
INFO - 2021-12-13 03:11:38 --> Language Class Initialized
INFO - 2021-12-13 03:11:38 --> Config Class Initialized
INFO - 2021-12-13 03:11:38 --> Loader Class Initialized
INFO - 2021-12-13 03:11:38 --> Helper loaded: url_helper
INFO - 2021-12-13 03:11:38 --> Helper loaded: file_helper
INFO - 2021-12-13 03:11:38 --> Helper loaded: form_helper
INFO - 2021-12-13 03:11:38 --> Helper loaded: my_helper
INFO - 2021-12-13 03:11:38 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:11:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:11:38 --> Controller Class Initialized
DEBUG - 2021-12-13 03:11:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 03:11:38 --> Final output sent to browser
DEBUG - 2021-12-13 03:11:38 --> Total execution time: 0.1320
INFO - 2021-12-13 03:11:59 --> Config Class Initialized
INFO - 2021-12-13 03:11:59 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:11:59 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:11:59 --> Utf8 Class Initialized
INFO - 2021-12-13 03:11:59 --> URI Class Initialized
INFO - 2021-12-13 03:11:59 --> Router Class Initialized
INFO - 2021-12-13 03:11:59 --> Output Class Initialized
INFO - 2021-12-13 03:11:59 --> Security Class Initialized
DEBUG - 2021-12-13 03:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:11:59 --> Input Class Initialized
INFO - 2021-12-13 03:11:59 --> Language Class Initialized
INFO - 2021-12-13 03:11:59 --> Language Class Initialized
INFO - 2021-12-13 03:11:59 --> Config Class Initialized
INFO - 2021-12-13 03:11:59 --> Loader Class Initialized
INFO - 2021-12-13 03:11:59 --> Helper loaded: url_helper
INFO - 2021-12-13 03:11:59 --> Helper loaded: file_helper
INFO - 2021-12-13 03:11:59 --> Helper loaded: form_helper
INFO - 2021-12-13 03:11:59 --> Helper loaded: my_helper
INFO - 2021-12-13 03:11:59 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:11:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:11:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:11:59 --> Controller Class Initialized
DEBUG - 2021-12-13 03:11:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2021-12-13 03:11:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 03:11:59 --> Final output sent to browser
DEBUG - 2021-12-13 03:11:59 --> Total execution time: 0.0740
INFO - 2021-12-13 03:13:48 --> Config Class Initialized
INFO - 2021-12-13 03:13:48 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:13:48 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:13:48 --> Utf8 Class Initialized
INFO - 2021-12-13 03:13:48 --> URI Class Initialized
INFO - 2021-12-13 03:13:48 --> Router Class Initialized
INFO - 2021-12-13 03:13:48 --> Output Class Initialized
INFO - 2021-12-13 03:13:48 --> Security Class Initialized
DEBUG - 2021-12-13 03:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:13:48 --> Input Class Initialized
INFO - 2021-12-13 03:13:48 --> Language Class Initialized
INFO - 2021-12-13 03:13:48 --> Language Class Initialized
INFO - 2021-12-13 03:13:48 --> Config Class Initialized
INFO - 2021-12-13 03:13:48 --> Loader Class Initialized
INFO - 2021-12-13 03:13:48 --> Helper loaded: url_helper
INFO - 2021-12-13 03:13:48 --> Helper loaded: file_helper
INFO - 2021-12-13 03:13:48 --> Helper loaded: form_helper
INFO - 2021-12-13 03:13:48 --> Helper loaded: my_helper
INFO - 2021-12-13 03:13:48 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:13:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:13:48 --> Controller Class Initialized
INFO - 2021-12-13 03:13:48 --> Final output sent to browser
DEBUG - 2021-12-13 03:13:48 --> Total execution time: 0.1530
INFO - 2021-12-13 03:14:28 --> Config Class Initialized
INFO - 2021-12-13 03:14:28 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:14:28 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:14:28 --> Utf8 Class Initialized
INFO - 2021-12-13 03:14:28 --> URI Class Initialized
INFO - 2021-12-13 03:14:28 --> Router Class Initialized
INFO - 2021-12-13 03:14:28 --> Output Class Initialized
INFO - 2021-12-13 03:14:28 --> Security Class Initialized
DEBUG - 2021-12-13 03:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:14:28 --> Input Class Initialized
INFO - 2021-12-13 03:14:28 --> Language Class Initialized
INFO - 2021-12-13 03:14:28 --> Language Class Initialized
INFO - 2021-12-13 03:14:28 --> Config Class Initialized
INFO - 2021-12-13 03:14:28 --> Loader Class Initialized
INFO - 2021-12-13 03:14:28 --> Helper loaded: url_helper
INFO - 2021-12-13 03:14:28 --> Helper loaded: file_helper
INFO - 2021-12-13 03:14:28 --> Helper loaded: form_helper
INFO - 2021-12-13 03:14:28 --> Helper loaded: my_helper
INFO - 2021-12-13 03:14:28 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:14:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:14:29 --> Controller Class Initialized
INFO - 2021-12-13 03:14:29 --> Final output sent to browser
DEBUG - 2021-12-13 03:14:29 --> Total execution time: 0.1180
INFO - 2021-12-13 03:14:49 --> Config Class Initialized
INFO - 2021-12-13 03:14:49 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:14:49 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:14:49 --> Utf8 Class Initialized
INFO - 2021-12-13 03:14:49 --> URI Class Initialized
INFO - 2021-12-13 03:14:49 --> Router Class Initialized
INFO - 2021-12-13 03:14:49 --> Output Class Initialized
INFO - 2021-12-13 03:14:49 --> Security Class Initialized
DEBUG - 2021-12-13 03:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:14:49 --> Input Class Initialized
INFO - 2021-12-13 03:14:49 --> Language Class Initialized
INFO - 2021-12-13 03:14:49 --> Language Class Initialized
INFO - 2021-12-13 03:14:49 --> Config Class Initialized
INFO - 2021-12-13 03:14:49 --> Loader Class Initialized
INFO - 2021-12-13 03:14:49 --> Helper loaded: url_helper
INFO - 2021-12-13 03:14:49 --> Helper loaded: file_helper
INFO - 2021-12-13 03:14:49 --> Helper loaded: form_helper
INFO - 2021-12-13 03:14:49 --> Helper loaded: my_helper
INFO - 2021-12-13 03:14:49 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:14:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:14:49 --> Controller Class Initialized
DEBUG - 2021-12-13 03:14:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-13 03:14:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 03:14:49 --> Final output sent to browser
DEBUG - 2021-12-13 03:14:49 --> Total execution time: 0.0660
INFO - 2021-12-13 03:14:54 --> Config Class Initialized
INFO - 2021-12-13 03:14:54 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:14:54 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:14:54 --> Utf8 Class Initialized
INFO - 2021-12-13 03:14:54 --> URI Class Initialized
INFO - 2021-12-13 03:14:54 --> Router Class Initialized
INFO - 2021-12-13 03:14:54 --> Output Class Initialized
INFO - 2021-12-13 03:14:54 --> Security Class Initialized
DEBUG - 2021-12-13 03:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:14:54 --> Input Class Initialized
INFO - 2021-12-13 03:14:54 --> Language Class Initialized
INFO - 2021-12-13 03:14:54 --> Language Class Initialized
INFO - 2021-12-13 03:14:54 --> Config Class Initialized
INFO - 2021-12-13 03:14:54 --> Loader Class Initialized
INFO - 2021-12-13 03:14:54 --> Helper loaded: url_helper
INFO - 2021-12-13 03:14:54 --> Helper loaded: file_helper
INFO - 2021-12-13 03:14:54 --> Helper loaded: form_helper
INFO - 2021-12-13 03:14:54 --> Helper loaded: my_helper
INFO - 2021-12-13 03:14:54 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:14:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:14:54 --> Controller Class Initialized
DEBUG - 2021-12-13 03:14:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 03:14:54 --> Final output sent to browser
DEBUG - 2021-12-13 03:14:54 --> Total execution time: 0.1880
INFO - 2021-12-13 03:15:04 --> Config Class Initialized
INFO - 2021-12-13 03:15:04 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:15:04 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:15:04 --> Utf8 Class Initialized
INFO - 2021-12-13 03:15:04 --> URI Class Initialized
INFO - 2021-12-13 03:15:04 --> Router Class Initialized
INFO - 2021-12-13 03:15:04 --> Output Class Initialized
INFO - 2021-12-13 03:15:04 --> Security Class Initialized
DEBUG - 2021-12-13 03:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:15:04 --> Input Class Initialized
INFO - 2021-12-13 03:15:04 --> Language Class Initialized
INFO - 2021-12-13 03:15:04 --> Language Class Initialized
INFO - 2021-12-13 03:15:04 --> Config Class Initialized
INFO - 2021-12-13 03:15:04 --> Loader Class Initialized
INFO - 2021-12-13 03:15:04 --> Helper loaded: url_helper
INFO - 2021-12-13 03:15:04 --> Helper loaded: file_helper
INFO - 2021-12-13 03:15:04 --> Helper loaded: form_helper
INFO - 2021-12-13 03:15:04 --> Helper loaded: my_helper
INFO - 2021-12-13 03:15:04 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:15:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:15:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:15:04 --> Controller Class Initialized
DEBUG - 2021-12-13 03:15:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 03:15:04 --> Final output sent to browser
DEBUG - 2021-12-13 03:15:04 --> Total execution time: 0.1600
INFO - 2021-12-13 03:15:21 --> Config Class Initialized
INFO - 2021-12-13 03:15:21 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:15:21 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:15:21 --> Utf8 Class Initialized
INFO - 2021-12-13 03:15:21 --> URI Class Initialized
INFO - 2021-12-13 03:15:21 --> Router Class Initialized
INFO - 2021-12-13 03:15:21 --> Output Class Initialized
INFO - 2021-12-13 03:15:21 --> Security Class Initialized
DEBUG - 2021-12-13 03:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:15:21 --> Input Class Initialized
INFO - 2021-12-13 03:15:21 --> Language Class Initialized
INFO - 2021-12-13 03:15:21 --> Language Class Initialized
INFO - 2021-12-13 03:15:21 --> Config Class Initialized
INFO - 2021-12-13 03:15:21 --> Loader Class Initialized
INFO - 2021-12-13 03:15:21 --> Helper loaded: url_helper
INFO - 2021-12-13 03:15:21 --> Helper loaded: file_helper
INFO - 2021-12-13 03:15:21 --> Helper loaded: form_helper
INFO - 2021-12-13 03:15:21 --> Helper loaded: my_helper
INFO - 2021-12-13 03:15:21 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:15:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:15:21 --> Controller Class Initialized
DEBUG - 2021-12-13 03:15:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2021-12-13 03:15:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 03:15:21 --> Final output sent to browser
DEBUG - 2021-12-13 03:15:21 --> Total execution time: 0.0710
INFO - 2021-12-13 03:15:39 --> Config Class Initialized
INFO - 2021-12-13 03:15:39 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:15:39 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:15:39 --> Utf8 Class Initialized
INFO - 2021-12-13 03:15:39 --> URI Class Initialized
INFO - 2021-12-13 03:15:39 --> Router Class Initialized
INFO - 2021-12-13 03:15:39 --> Output Class Initialized
INFO - 2021-12-13 03:15:39 --> Security Class Initialized
DEBUG - 2021-12-13 03:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:15:39 --> Input Class Initialized
INFO - 2021-12-13 03:15:39 --> Language Class Initialized
INFO - 2021-12-13 03:15:39 --> Language Class Initialized
INFO - 2021-12-13 03:15:39 --> Config Class Initialized
INFO - 2021-12-13 03:15:39 --> Loader Class Initialized
INFO - 2021-12-13 03:15:39 --> Helper loaded: url_helper
INFO - 2021-12-13 03:15:39 --> Helper loaded: file_helper
INFO - 2021-12-13 03:15:39 --> Helper loaded: form_helper
INFO - 2021-12-13 03:15:39 --> Helper loaded: my_helper
INFO - 2021-12-13 03:15:39 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:15:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:15:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:15:39 --> Controller Class Initialized
INFO - 2021-12-13 03:15:40 --> Final output sent to browser
DEBUG - 2021-12-13 03:15:40 --> Total execution time: 0.1690
INFO - 2021-12-13 03:15:42 --> Config Class Initialized
INFO - 2021-12-13 03:15:42 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:15:42 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:15:42 --> Utf8 Class Initialized
INFO - 2021-12-13 03:15:42 --> URI Class Initialized
INFO - 2021-12-13 03:15:42 --> Router Class Initialized
INFO - 2021-12-13 03:15:42 --> Output Class Initialized
INFO - 2021-12-13 03:15:42 --> Security Class Initialized
DEBUG - 2021-12-13 03:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:15:42 --> Input Class Initialized
INFO - 2021-12-13 03:15:42 --> Language Class Initialized
INFO - 2021-12-13 03:15:42 --> Language Class Initialized
INFO - 2021-12-13 03:15:42 --> Config Class Initialized
INFO - 2021-12-13 03:15:42 --> Loader Class Initialized
INFO - 2021-12-13 03:15:42 --> Helper loaded: url_helper
INFO - 2021-12-13 03:15:42 --> Helper loaded: file_helper
INFO - 2021-12-13 03:15:42 --> Helper loaded: form_helper
INFO - 2021-12-13 03:15:42 --> Helper loaded: my_helper
INFO - 2021-12-13 03:15:42 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:15:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:15:42 --> Controller Class Initialized
DEBUG - 2021-12-13 03:15:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 03:15:42 --> Final output sent to browser
DEBUG - 2021-12-13 03:15:42 --> Total execution time: 0.1660
INFO - 2021-12-13 03:16:22 --> Config Class Initialized
INFO - 2021-12-13 03:16:22 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:16:22 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:16:22 --> Utf8 Class Initialized
INFO - 2021-12-13 03:16:22 --> URI Class Initialized
INFO - 2021-12-13 03:16:22 --> Router Class Initialized
INFO - 2021-12-13 03:16:22 --> Output Class Initialized
INFO - 2021-12-13 03:16:22 --> Security Class Initialized
DEBUG - 2021-12-13 03:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:16:22 --> Input Class Initialized
INFO - 2021-12-13 03:16:22 --> Language Class Initialized
INFO - 2021-12-13 03:16:22 --> Language Class Initialized
INFO - 2021-12-13 03:16:22 --> Config Class Initialized
INFO - 2021-12-13 03:16:22 --> Loader Class Initialized
INFO - 2021-12-13 03:16:22 --> Helper loaded: url_helper
INFO - 2021-12-13 03:16:22 --> Helper loaded: file_helper
INFO - 2021-12-13 03:16:22 --> Helper loaded: form_helper
INFO - 2021-12-13 03:16:22 --> Helper loaded: my_helper
INFO - 2021-12-13 03:16:22 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:16:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:16:22 --> Controller Class Initialized
INFO - 2021-12-13 03:16:22 --> Helper loaded: cookie_helper
INFO - 2021-12-13 03:16:22 --> Config Class Initialized
INFO - 2021-12-13 03:16:22 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:16:22 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:16:22 --> Utf8 Class Initialized
INFO - 2021-12-13 03:16:22 --> URI Class Initialized
INFO - 2021-12-13 03:16:22 --> Router Class Initialized
INFO - 2021-12-13 03:16:22 --> Output Class Initialized
INFO - 2021-12-13 03:16:22 --> Security Class Initialized
DEBUG - 2021-12-13 03:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:16:22 --> Input Class Initialized
INFO - 2021-12-13 03:16:22 --> Language Class Initialized
INFO - 2021-12-13 03:16:22 --> Language Class Initialized
INFO - 2021-12-13 03:16:22 --> Config Class Initialized
INFO - 2021-12-13 03:16:22 --> Loader Class Initialized
INFO - 2021-12-13 03:16:22 --> Helper loaded: url_helper
INFO - 2021-12-13 03:16:22 --> Helper loaded: file_helper
INFO - 2021-12-13 03:16:22 --> Helper loaded: form_helper
INFO - 2021-12-13 03:16:22 --> Helper loaded: my_helper
INFO - 2021-12-13 03:16:22 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:16:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:16:22 --> Controller Class Initialized
DEBUG - 2021-12-13 03:16:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-13 03:16:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 03:16:22 --> Final output sent to browser
DEBUG - 2021-12-13 03:16:22 --> Total execution time: 0.0360
INFO - 2021-12-13 03:16:29 --> Config Class Initialized
INFO - 2021-12-13 03:16:29 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:16:29 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:16:29 --> Utf8 Class Initialized
INFO - 2021-12-13 03:16:29 --> URI Class Initialized
INFO - 2021-12-13 03:16:29 --> Router Class Initialized
INFO - 2021-12-13 03:16:29 --> Output Class Initialized
INFO - 2021-12-13 03:16:29 --> Security Class Initialized
DEBUG - 2021-12-13 03:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:16:29 --> Input Class Initialized
INFO - 2021-12-13 03:16:29 --> Language Class Initialized
INFO - 2021-12-13 03:16:29 --> Language Class Initialized
INFO - 2021-12-13 03:16:29 --> Config Class Initialized
INFO - 2021-12-13 03:16:29 --> Loader Class Initialized
INFO - 2021-12-13 03:16:29 --> Helper loaded: url_helper
INFO - 2021-12-13 03:16:29 --> Helper loaded: file_helper
INFO - 2021-12-13 03:16:29 --> Helper loaded: form_helper
INFO - 2021-12-13 03:16:29 --> Helper loaded: my_helper
INFO - 2021-12-13 03:16:29 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:16:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:16:29 --> Controller Class Initialized
INFO - 2021-12-13 03:16:30 --> Helper loaded: cookie_helper
INFO - 2021-12-13 03:16:30 --> Final output sent to browser
DEBUG - 2021-12-13 03:16:30 --> Total execution time: 0.0530
INFO - 2021-12-13 03:16:30 --> Config Class Initialized
INFO - 2021-12-13 03:16:30 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:16:30 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:16:30 --> Utf8 Class Initialized
INFO - 2021-12-13 03:16:30 --> URI Class Initialized
INFO - 2021-12-13 03:16:30 --> Router Class Initialized
INFO - 2021-12-13 03:16:30 --> Output Class Initialized
INFO - 2021-12-13 03:16:30 --> Security Class Initialized
DEBUG - 2021-12-13 03:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:16:30 --> Input Class Initialized
INFO - 2021-12-13 03:16:30 --> Language Class Initialized
INFO - 2021-12-13 03:16:30 --> Language Class Initialized
INFO - 2021-12-13 03:16:30 --> Config Class Initialized
INFO - 2021-12-13 03:16:30 --> Loader Class Initialized
INFO - 2021-12-13 03:16:30 --> Helper loaded: url_helper
INFO - 2021-12-13 03:16:30 --> Helper loaded: file_helper
INFO - 2021-12-13 03:16:30 --> Helper loaded: form_helper
INFO - 2021-12-13 03:16:30 --> Helper loaded: my_helper
INFO - 2021-12-13 03:16:30 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:16:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:16:30 --> Controller Class Initialized
DEBUG - 2021-12-13 03:16:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-13 03:16:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 03:16:31 --> Final output sent to browser
DEBUG - 2021-12-13 03:16:31 --> Total execution time: 0.7680
INFO - 2021-12-13 03:19:16 --> Config Class Initialized
INFO - 2021-12-13 03:19:16 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:19:16 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:19:16 --> Utf8 Class Initialized
INFO - 2021-12-13 03:19:16 --> URI Class Initialized
INFO - 2021-12-13 03:19:17 --> Router Class Initialized
INFO - 2021-12-13 03:19:17 --> Output Class Initialized
INFO - 2021-12-13 03:19:17 --> Security Class Initialized
DEBUG - 2021-12-13 03:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:19:17 --> Input Class Initialized
INFO - 2021-12-13 03:19:17 --> Language Class Initialized
INFO - 2021-12-13 03:19:17 --> Language Class Initialized
INFO - 2021-12-13 03:19:17 --> Config Class Initialized
INFO - 2021-12-13 03:19:17 --> Loader Class Initialized
INFO - 2021-12-13 03:19:17 --> Helper loaded: url_helper
INFO - 2021-12-13 03:19:17 --> Helper loaded: file_helper
INFO - 2021-12-13 03:19:17 --> Helper loaded: form_helper
INFO - 2021-12-13 03:19:17 --> Helper loaded: my_helper
INFO - 2021-12-13 03:19:17 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:19:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:19:17 --> Controller Class Initialized
DEBUG - 2021-12-13 03:19:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-13 03:19:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 03:19:17 --> Final output sent to browser
DEBUG - 2021-12-13 03:19:17 --> Total execution time: 0.0580
INFO - 2021-12-13 03:19:19 --> Config Class Initialized
INFO - 2021-12-13 03:19:19 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:19:19 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:19:19 --> Utf8 Class Initialized
INFO - 2021-12-13 03:19:19 --> URI Class Initialized
INFO - 2021-12-13 03:19:19 --> Router Class Initialized
INFO - 2021-12-13 03:19:19 --> Output Class Initialized
INFO - 2021-12-13 03:19:19 --> Security Class Initialized
DEBUG - 2021-12-13 03:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:19:19 --> Input Class Initialized
INFO - 2021-12-13 03:19:19 --> Language Class Initialized
INFO - 2021-12-13 03:19:19 --> Language Class Initialized
INFO - 2021-12-13 03:19:19 --> Config Class Initialized
INFO - 2021-12-13 03:19:19 --> Loader Class Initialized
INFO - 2021-12-13 03:19:19 --> Helper loaded: url_helper
INFO - 2021-12-13 03:19:19 --> Helper loaded: file_helper
INFO - 2021-12-13 03:19:19 --> Helper loaded: form_helper
INFO - 2021-12-13 03:19:19 --> Helper loaded: my_helper
INFO - 2021-12-13 03:19:19 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:19:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:19:19 --> Controller Class Initialized
DEBUG - 2021-12-13 03:19:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 03:19:19 --> Final output sent to browser
DEBUG - 2021-12-13 03:19:19 --> Total execution time: 0.2050
INFO - 2021-12-13 03:19:27 --> Config Class Initialized
INFO - 2021-12-13 03:19:27 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:19:27 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:19:27 --> Utf8 Class Initialized
INFO - 2021-12-13 03:19:27 --> URI Class Initialized
INFO - 2021-12-13 03:19:27 --> Router Class Initialized
INFO - 2021-12-13 03:19:27 --> Output Class Initialized
INFO - 2021-12-13 03:19:27 --> Security Class Initialized
DEBUG - 2021-12-13 03:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:19:27 --> Input Class Initialized
INFO - 2021-12-13 03:19:27 --> Language Class Initialized
INFO - 2021-12-13 03:19:27 --> Language Class Initialized
INFO - 2021-12-13 03:19:27 --> Config Class Initialized
INFO - 2021-12-13 03:19:27 --> Loader Class Initialized
INFO - 2021-12-13 03:19:27 --> Helper loaded: url_helper
INFO - 2021-12-13 03:19:27 --> Helper loaded: file_helper
INFO - 2021-12-13 03:19:27 --> Helper loaded: form_helper
INFO - 2021-12-13 03:19:27 --> Helper loaded: my_helper
INFO - 2021-12-13 03:19:27 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:19:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:19:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:19:27 --> Controller Class Initialized
DEBUG - 2021-12-13 03:19:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 03:19:27 --> Final output sent to browser
DEBUG - 2021-12-13 03:19:27 --> Total execution time: 0.1430
INFO - 2021-12-13 03:19:29 --> Config Class Initialized
INFO - 2021-12-13 03:19:29 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:19:29 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:19:29 --> Utf8 Class Initialized
INFO - 2021-12-13 03:19:29 --> URI Class Initialized
INFO - 2021-12-13 03:19:29 --> Router Class Initialized
INFO - 2021-12-13 03:19:29 --> Output Class Initialized
INFO - 2021-12-13 03:19:29 --> Security Class Initialized
DEBUG - 2021-12-13 03:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:19:29 --> Input Class Initialized
INFO - 2021-12-13 03:19:29 --> Language Class Initialized
INFO - 2021-12-13 03:19:29 --> Language Class Initialized
INFO - 2021-12-13 03:19:29 --> Config Class Initialized
INFO - 2021-12-13 03:19:29 --> Loader Class Initialized
INFO - 2021-12-13 03:19:29 --> Helper loaded: url_helper
INFO - 2021-12-13 03:19:29 --> Helper loaded: file_helper
INFO - 2021-12-13 03:19:29 --> Helper loaded: form_helper
INFO - 2021-12-13 03:19:29 --> Helper loaded: my_helper
INFO - 2021-12-13 03:19:29 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:19:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:19:29 --> Controller Class Initialized
DEBUG - 2021-12-13 03:19:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 03:19:29 --> Final output sent to browser
DEBUG - 2021-12-13 03:19:29 --> Total execution time: 0.1130
INFO - 2021-12-13 03:19:31 --> Config Class Initialized
INFO - 2021-12-13 03:19:31 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:19:31 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:19:31 --> Utf8 Class Initialized
INFO - 2021-12-13 03:19:31 --> URI Class Initialized
INFO - 2021-12-13 03:19:31 --> Router Class Initialized
INFO - 2021-12-13 03:19:31 --> Output Class Initialized
INFO - 2021-12-13 03:19:31 --> Security Class Initialized
DEBUG - 2021-12-13 03:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:19:31 --> Input Class Initialized
INFO - 2021-12-13 03:19:31 --> Language Class Initialized
INFO - 2021-12-13 03:19:31 --> Language Class Initialized
INFO - 2021-12-13 03:19:31 --> Config Class Initialized
INFO - 2021-12-13 03:19:31 --> Loader Class Initialized
INFO - 2021-12-13 03:19:31 --> Helper loaded: url_helper
INFO - 2021-12-13 03:19:31 --> Helper loaded: file_helper
INFO - 2021-12-13 03:19:31 --> Helper loaded: form_helper
INFO - 2021-12-13 03:19:31 --> Helper loaded: my_helper
INFO - 2021-12-13 03:19:31 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:19:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:19:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:19:31 --> Controller Class Initialized
DEBUG - 2021-12-13 03:19:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 03:19:31 --> Final output sent to browser
DEBUG - 2021-12-13 03:19:31 --> Total execution time: 0.1230
INFO - 2021-12-13 03:19:33 --> Config Class Initialized
INFO - 2021-12-13 03:19:33 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:19:33 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:19:33 --> Utf8 Class Initialized
INFO - 2021-12-13 03:19:33 --> URI Class Initialized
INFO - 2021-12-13 03:19:33 --> Router Class Initialized
INFO - 2021-12-13 03:19:33 --> Output Class Initialized
INFO - 2021-12-13 03:19:33 --> Security Class Initialized
DEBUG - 2021-12-13 03:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:19:33 --> Input Class Initialized
INFO - 2021-12-13 03:19:33 --> Language Class Initialized
INFO - 2021-12-13 03:19:33 --> Language Class Initialized
INFO - 2021-12-13 03:19:33 --> Config Class Initialized
INFO - 2021-12-13 03:19:33 --> Loader Class Initialized
INFO - 2021-12-13 03:19:33 --> Helper loaded: url_helper
INFO - 2021-12-13 03:19:33 --> Helper loaded: file_helper
INFO - 2021-12-13 03:19:33 --> Helper loaded: form_helper
INFO - 2021-12-13 03:19:33 --> Helper loaded: my_helper
INFO - 2021-12-13 03:19:33 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:19:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:19:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:19:33 --> Controller Class Initialized
DEBUG - 2021-12-13 03:19:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 03:19:33 --> Final output sent to browser
DEBUG - 2021-12-13 03:19:33 --> Total execution time: 0.1350
INFO - 2021-12-13 03:19:34 --> Config Class Initialized
INFO - 2021-12-13 03:19:34 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:19:34 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:19:34 --> Utf8 Class Initialized
INFO - 2021-12-13 03:19:34 --> URI Class Initialized
INFO - 2021-12-13 03:19:34 --> Router Class Initialized
INFO - 2021-12-13 03:19:34 --> Output Class Initialized
INFO - 2021-12-13 03:19:34 --> Security Class Initialized
DEBUG - 2021-12-13 03:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:19:34 --> Input Class Initialized
INFO - 2021-12-13 03:19:34 --> Language Class Initialized
INFO - 2021-12-13 03:19:34 --> Language Class Initialized
INFO - 2021-12-13 03:19:34 --> Config Class Initialized
INFO - 2021-12-13 03:19:34 --> Loader Class Initialized
INFO - 2021-12-13 03:19:34 --> Helper loaded: url_helper
INFO - 2021-12-13 03:19:34 --> Helper loaded: file_helper
INFO - 2021-12-13 03:19:34 --> Helper loaded: form_helper
INFO - 2021-12-13 03:19:34 --> Helper loaded: my_helper
INFO - 2021-12-13 03:19:34 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:19:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:19:34 --> Controller Class Initialized
DEBUG - 2021-12-13 03:19:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 03:19:34 --> Final output sent to browser
DEBUG - 2021-12-13 03:19:34 --> Total execution time: 0.1340
INFO - 2021-12-13 03:19:37 --> Config Class Initialized
INFO - 2021-12-13 03:19:37 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:19:37 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:19:37 --> Utf8 Class Initialized
INFO - 2021-12-13 03:19:37 --> URI Class Initialized
INFO - 2021-12-13 03:19:37 --> Router Class Initialized
INFO - 2021-12-13 03:19:37 --> Output Class Initialized
INFO - 2021-12-13 03:19:37 --> Security Class Initialized
DEBUG - 2021-12-13 03:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:19:37 --> Input Class Initialized
INFO - 2021-12-13 03:19:37 --> Language Class Initialized
INFO - 2021-12-13 03:19:37 --> Language Class Initialized
INFO - 2021-12-13 03:19:37 --> Config Class Initialized
INFO - 2021-12-13 03:19:37 --> Loader Class Initialized
INFO - 2021-12-13 03:19:37 --> Helper loaded: url_helper
INFO - 2021-12-13 03:19:37 --> Helper loaded: file_helper
INFO - 2021-12-13 03:19:37 --> Helper loaded: form_helper
INFO - 2021-12-13 03:19:37 --> Helper loaded: my_helper
INFO - 2021-12-13 03:19:37 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:19:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:19:37 --> Controller Class Initialized
DEBUG - 2021-12-13 03:19:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 03:19:37 --> Final output sent to browser
DEBUG - 2021-12-13 03:19:37 --> Total execution time: 0.1450
INFO - 2021-12-13 03:19:38 --> Config Class Initialized
INFO - 2021-12-13 03:19:38 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:19:38 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:19:38 --> Utf8 Class Initialized
INFO - 2021-12-13 03:19:38 --> URI Class Initialized
INFO - 2021-12-13 03:19:38 --> Router Class Initialized
INFO - 2021-12-13 03:19:38 --> Output Class Initialized
INFO - 2021-12-13 03:19:38 --> Security Class Initialized
DEBUG - 2021-12-13 03:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:19:38 --> Input Class Initialized
INFO - 2021-12-13 03:19:38 --> Language Class Initialized
INFO - 2021-12-13 03:19:38 --> Language Class Initialized
INFO - 2021-12-13 03:19:38 --> Config Class Initialized
INFO - 2021-12-13 03:19:38 --> Loader Class Initialized
INFO - 2021-12-13 03:19:38 --> Helper loaded: url_helper
INFO - 2021-12-13 03:19:38 --> Helper loaded: file_helper
INFO - 2021-12-13 03:19:38 --> Helper loaded: form_helper
INFO - 2021-12-13 03:19:38 --> Helper loaded: my_helper
INFO - 2021-12-13 03:19:38 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:19:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:19:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:19:38 --> Controller Class Initialized
DEBUG - 2021-12-13 03:19:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 03:19:38 --> Final output sent to browser
DEBUG - 2021-12-13 03:19:38 --> Total execution time: 0.1470
INFO - 2021-12-13 03:19:40 --> Config Class Initialized
INFO - 2021-12-13 03:19:40 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:19:40 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:19:40 --> Utf8 Class Initialized
INFO - 2021-12-13 03:19:40 --> URI Class Initialized
INFO - 2021-12-13 03:19:40 --> Router Class Initialized
INFO - 2021-12-13 03:19:40 --> Output Class Initialized
INFO - 2021-12-13 03:19:40 --> Security Class Initialized
DEBUG - 2021-12-13 03:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:19:40 --> Input Class Initialized
INFO - 2021-12-13 03:19:40 --> Language Class Initialized
INFO - 2021-12-13 03:19:40 --> Language Class Initialized
INFO - 2021-12-13 03:19:40 --> Config Class Initialized
INFO - 2021-12-13 03:19:40 --> Loader Class Initialized
INFO - 2021-12-13 03:19:40 --> Helper loaded: url_helper
INFO - 2021-12-13 03:19:40 --> Helper loaded: file_helper
INFO - 2021-12-13 03:19:40 --> Helper loaded: form_helper
INFO - 2021-12-13 03:19:40 --> Helper loaded: my_helper
INFO - 2021-12-13 03:19:40 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:19:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:19:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:19:40 --> Controller Class Initialized
DEBUG - 2021-12-13 03:19:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 03:19:40 --> Final output sent to browser
DEBUG - 2021-12-13 03:19:40 --> Total execution time: 0.1290
INFO - 2021-12-13 03:19:42 --> Config Class Initialized
INFO - 2021-12-13 03:19:42 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:19:42 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:19:42 --> Utf8 Class Initialized
INFO - 2021-12-13 03:19:42 --> URI Class Initialized
INFO - 2021-12-13 03:19:42 --> Router Class Initialized
INFO - 2021-12-13 03:19:42 --> Output Class Initialized
INFO - 2021-12-13 03:19:42 --> Security Class Initialized
DEBUG - 2021-12-13 03:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:19:42 --> Input Class Initialized
INFO - 2021-12-13 03:19:42 --> Language Class Initialized
INFO - 2021-12-13 03:19:42 --> Language Class Initialized
INFO - 2021-12-13 03:19:42 --> Config Class Initialized
INFO - 2021-12-13 03:19:42 --> Loader Class Initialized
INFO - 2021-12-13 03:19:42 --> Helper loaded: url_helper
INFO - 2021-12-13 03:19:42 --> Helper loaded: file_helper
INFO - 2021-12-13 03:19:42 --> Helper loaded: form_helper
INFO - 2021-12-13 03:19:42 --> Helper loaded: my_helper
INFO - 2021-12-13 03:19:42 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:19:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:19:42 --> Controller Class Initialized
DEBUG - 2021-12-13 03:19:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 03:19:42 --> Final output sent to browser
DEBUG - 2021-12-13 03:19:42 --> Total execution time: 0.1300
INFO - 2021-12-13 03:19:45 --> Config Class Initialized
INFO - 2021-12-13 03:19:45 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:19:45 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:19:45 --> Utf8 Class Initialized
INFO - 2021-12-13 03:19:45 --> URI Class Initialized
INFO - 2021-12-13 03:19:45 --> Router Class Initialized
INFO - 2021-12-13 03:19:45 --> Output Class Initialized
INFO - 2021-12-13 03:19:45 --> Security Class Initialized
DEBUG - 2021-12-13 03:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:19:45 --> Input Class Initialized
INFO - 2021-12-13 03:19:45 --> Language Class Initialized
INFO - 2021-12-13 03:19:45 --> Language Class Initialized
INFO - 2021-12-13 03:19:45 --> Config Class Initialized
INFO - 2021-12-13 03:19:45 --> Loader Class Initialized
INFO - 2021-12-13 03:19:45 --> Helper loaded: url_helper
INFO - 2021-12-13 03:19:45 --> Helper loaded: file_helper
INFO - 2021-12-13 03:19:45 --> Helper loaded: form_helper
INFO - 2021-12-13 03:19:45 --> Helper loaded: my_helper
INFO - 2021-12-13 03:19:45 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:19:45 --> Controller Class Initialized
DEBUG - 2021-12-13 03:19:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 03:19:45 --> Final output sent to browser
DEBUG - 2021-12-13 03:19:45 --> Total execution time: 0.1250
INFO - 2021-12-13 03:19:46 --> Config Class Initialized
INFO - 2021-12-13 03:19:46 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:19:46 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:19:46 --> Utf8 Class Initialized
INFO - 2021-12-13 03:19:46 --> URI Class Initialized
INFO - 2021-12-13 03:19:46 --> Router Class Initialized
INFO - 2021-12-13 03:19:46 --> Output Class Initialized
INFO - 2021-12-13 03:19:46 --> Security Class Initialized
DEBUG - 2021-12-13 03:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:19:46 --> Input Class Initialized
INFO - 2021-12-13 03:19:46 --> Language Class Initialized
INFO - 2021-12-13 03:19:46 --> Language Class Initialized
INFO - 2021-12-13 03:19:46 --> Config Class Initialized
INFO - 2021-12-13 03:19:46 --> Loader Class Initialized
INFO - 2021-12-13 03:19:46 --> Helper loaded: url_helper
INFO - 2021-12-13 03:19:46 --> Helper loaded: file_helper
INFO - 2021-12-13 03:19:46 --> Helper loaded: form_helper
INFO - 2021-12-13 03:19:46 --> Helper loaded: my_helper
INFO - 2021-12-13 03:19:46 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:19:46 --> Controller Class Initialized
DEBUG - 2021-12-13 03:19:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 03:19:46 --> Final output sent to browser
DEBUG - 2021-12-13 03:19:46 --> Total execution time: 0.1160
INFO - 2021-12-13 03:19:48 --> Config Class Initialized
INFO - 2021-12-13 03:19:48 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:19:48 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:19:48 --> Utf8 Class Initialized
INFO - 2021-12-13 03:19:48 --> URI Class Initialized
INFO - 2021-12-13 03:19:48 --> Router Class Initialized
INFO - 2021-12-13 03:19:48 --> Output Class Initialized
INFO - 2021-12-13 03:19:48 --> Security Class Initialized
DEBUG - 2021-12-13 03:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:19:48 --> Input Class Initialized
INFO - 2021-12-13 03:19:48 --> Language Class Initialized
INFO - 2021-12-13 03:19:48 --> Language Class Initialized
INFO - 2021-12-13 03:19:48 --> Config Class Initialized
INFO - 2021-12-13 03:19:48 --> Loader Class Initialized
INFO - 2021-12-13 03:19:48 --> Helper loaded: url_helper
INFO - 2021-12-13 03:19:48 --> Helper loaded: file_helper
INFO - 2021-12-13 03:19:48 --> Helper loaded: form_helper
INFO - 2021-12-13 03:19:48 --> Helper loaded: my_helper
INFO - 2021-12-13 03:19:48 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:19:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:19:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:19:48 --> Controller Class Initialized
DEBUG - 2021-12-13 03:19:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 03:19:48 --> Final output sent to browser
DEBUG - 2021-12-13 03:19:48 --> Total execution time: 0.1260
INFO - 2021-12-13 03:19:51 --> Config Class Initialized
INFO - 2021-12-13 03:19:51 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:19:51 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:19:51 --> Utf8 Class Initialized
INFO - 2021-12-13 03:19:51 --> URI Class Initialized
INFO - 2021-12-13 03:19:51 --> Router Class Initialized
INFO - 2021-12-13 03:19:51 --> Output Class Initialized
INFO - 2021-12-13 03:19:51 --> Security Class Initialized
DEBUG - 2021-12-13 03:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:19:51 --> Input Class Initialized
INFO - 2021-12-13 03:19:51 --> Language Class Initialized
INFO - 2021-12-13 03:19:51 --> Language Class Initialized
INFO - 2021-12-13 03:19:51 --> Config Class Initialized
INFO - 2021-12-13 03:19:51 --> Loader Class Initialized
INFO - 2021-12-13 03:19:51 --> Helper loaded: url_helper
INFO - 2021-12-13 03:19:51 --> Helper loaded: file_helper
INFO - 2021-12-13 03:19:51 --> Helper loaded: form_helper
INFO - 2021-12-13 03:19:51 --> Helper loaded: my_helper
INFO - 2021-12-13 03:19:51 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:19:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:19:51 --> Controller Class Initialized
DEBUG - 2021-12-13 03:19:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 03:19:51 --> Final output sent to browser
DEBUG - 2021-12-13 03:19:51 --> Total execution time: 0.1220
INFO - 2021-12-13 03:20:03 --> Config Class Initialized
INFO - 2021-12-13 03:20:03 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:20:03 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:20:03 --> Utf8 Class Initialized
INFO - 2021-12-13 03:20:03 --> URI Class Initialized
INFO - 2021-12-13 03:20:03 --> Router Class Initialized
INFO - 2021-12-13 03:20:03 --> Output Class Initialized
INFO - 2021-12-13 03:20:03 --> Security Class Initialized
DEBUG - 2021-12-13 03:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:20:03 --> Input Class Initialized
INFO - 2021-12-13 03:20:03 --> Language Class Initialized
INFO - 2021-12-13 03:20:03 --> Language Class Initialized
INFO - 2021-12-13 03:20:03 --> Config Class Initialized
INFO - 2021-12-13 03:20:03 --> Loader Class Initialized
INFO - 2021-12-13 03:20:03 --> Helper loaded: url_helper
INFO - 2021-12-13 03:20:03 --> Helper loaded: file_helper
INFO - 2021-12-13 03:20:03 --> Helper loaded: form_helper
INFO - 2021-12-13 03:20:03 --> Helper loaded: my_helper
INFO - 2021-12-13 03:20:03 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:20:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:20:03 --> Controller Class Initialized
DEBUG - 2021-12-13 03:20:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 03:20:03 --> Final output sent to browser
DEBUG - 2021-12-13 03:20:03 --> Total execution time: 0.1260
INFO - 2021-12-13 03:20:05 --> Config Class Initialized
INFO - 2021-12-13 03:20:05 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:20:05 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:20:05 --> Utf8 Class Initialized
INFO - 2021-12-13 03:20:05 --> URI Class Initialized
INFO - 2021-12-13 03:20:05 --> Router Class Initialized
INFO - 2021-12-13 03:20:05 --> Output Class Initialized
INFO - 2021-12-13 03:20:05 --> Security Class Initialized
DEBUG - 2021-12-13 03:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:20:05 --> Input Class Initialized
INFO - 2021-12-13 03:20:05 --> Language Class Initialized
INFO - 2021-12-13 03:20:05 --> Language Class Initialized
INFO - 2021-12-13 03:20:05 --> Config Class Initialized
INFO - 2021-12-13 03:20:05 --> Loader Class Initialized
INFO - 2021-12-13 03:20:05 --> Helper loaded: url_helper
INFO - 2021-12-13 03:20:05 --> Helper loaded: file_helper
INFO - 2021-12-13 03:20:05 --> Helper loaded: form_helper
INFO - 2021-12-13 03:20:05 --> Helper loaded: my_helper
INFO - 2021-12-13 03:20:05 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:20:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:20:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:20:05 --> Controller Class Initialized
DEBUG - 2021-12-13 03:20:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 03:20:05 --> Final output sent to browser
DEBUG - 2021-12-13 03:20:05 --> Total execution time: 0.1570
INFO - 2021-12-13 03:20:07 --> Config Class Initialized
INFO - 2021-12-13 03:20:07 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:20:07 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:20:07 --> Utf8 Class Initialized
INFO - 2021-12-13 03:20:07 --> URI Class Initialized
INFO - 2021-12-13 03:20:07 --> Router Class Initialized
INFO - 2021-12-13 03:20:07 --> Output Class Initialized
INFO - 2021-12-13 03:20:07 --> Security Class Initialized
DEBUG - 2021-12-13 03:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:20:07 --> Input Class Initialized
INFO - 2021-12-13 03:20:07 --> Language Class Initialized
INFO - 2021-12-13 03:20:07 --> Language Class Initialized
INFO - 2021-12-13 03:20:07 --> Config Class Initialized
INFO - 2021-12-13 03:20:07 --> Loader Class Initialized
INFO - 2021-12-13 03:20:07 --> Helper loaded: url_helper
INFO - 2021-12-13 03:20:07 --> Helper loaded: file_helper
INFO - 2021-12-13 03:20:07 --> Helper loaded: form_helper
INFO - 2021-12-13 03:20:07 --> Helper loaded: my_helper
INFO - 2021-12-13 03:20:07 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:20:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:20:07 --> Controller Class Initialized
DEBUG - 2021-12-13 03:20:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 03:20:07 --> Final output sent to browser
DEBUG - 2021-12-13 03:20:07 --> Total execution time: 0.1320
INFO - 2021-12-13 03:20:09 --> Config Class Initialized
INFO - 2021-12-13 03:20:09 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:20:09 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:20:09 --> Utf8 Class Initialized
INFO - 2021-12-13 03:20:09 --> URI Class Initialized
INFO - 2021-12-13 03:20:09 --> Router Class Initialized
INFO - 2021-12-13 03:20:09 --> Output Class Initialized
INFO - 2021-12-13 03:20:09 --> Security Class Initialized
DEBUG - 2021-12-13 03:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:20:09 --> Input Class Initialized
INFO - 2021-12-13 03:20:09 --> Language Class Initialized
INFO - 2021-12-13 03:20:09 --> Language Class Initialized
INFO - 2021-12-13 03:20:09 --> Config Class Initialized
INFO - 2021-12-13 03:20:09 --> Loader Class Initialized
INFO - 2021-12-13 03:20:09 --> Helper loaded: url_helper
INFO - 2021-12-13 03:20:09 --> Helper loaded: file_helper
INFO - 2021-12-13 03:20:09 --> Helper loaded: form_helper
INFO - 2021-12-13 03:20:09 --> Helper loaded: my_helper
INFO - 2021-12-13 03:20:09 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:20:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:20:09 --> Controller Class Initialized
DEBUG - 2021-12-13 03:20:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 03:20:09 --> Final output sent to browser
DEBUG - 2021-12-13 03:20:09 --> Total execution time: 0.1240
INFO - 2021-12-13 03:20:13 --> Config Class Initialized
INFO - 2021-12-13 03:20:13 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:20:13 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:20:13 --> Utf8 Class Initialized
INFO - 2021-12-13 03:20:13 --> URI Class Initialized
INFO - 2021-12-13 03:20:13 --> Router Class Initialized
INFO - 2021-12-13 03:20:13 --> Output Class Initialized
INFO - 2021-12-13 03:20:13 --> Security Class Initialized
DEBUG - 2021-12-13 03:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:20:13 --> Input Class Initialized
INFO - 2021-12-13 03:20:13 --> Language Class Initialized
INFO - 2021-12-13 03:20:13 --> Language Class Initialized
INFO - 2021-12-13 03:20:13 --> Config Class Initialized
INFO - 2021-12-13 03:20:13 --> Loader Class Initialized
INFO - 2021-12-13 03:20:13 --> Helper loaded: url_helper
INFO - 2021-12-13 03:20:13 --> Helper loaded: file_helper
INFO - 2021-12-13 03:20:13 --> Helper loaded: form_helper
INFO - 2021-12-13 03:20:13 --> Helper loaded: my_helper
INFO - 2021-12-13 03:20:13 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:20:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:20:13 --> Controller Class Initialized
DEBUG - 2021-12-13 03:20:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 03:20:13 --> Final output sent to browser
DEBUG - 2021-12-13 03:20:13 --> Total execution time: 0.1280
INFO - 2021-12-13 03:20:14 --> Config Class Initialized
INFO - 2021-12-13 03:20:14 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:20:14 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:20:14 --> Utf8 Class Initialized
INFO - 2021-12-13 03:20:14 --> URI Class Initialized
INFO - 2021-12-13 03:20:14 --> Router Class Initialized
INFO - 2021-12-13 03:20:14 --> Output Class Initialized
INFO - 2021-12-13 03:20:14 --> Security Class Initialized
DEBUG - 2021-12-13 03:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:20:14 --> Input Class Initialized
INFO - 2021-12-13 03:20:14 --> Language Class Initialized
INFO - 2021-12-13 03:20:14 --> Language Class Initialized
INFO - 2021-12-13 03:20:14 --> Config Class Initialized
INFO - 2021-12-13 03:20:14 --> Loader Class Initialized
INFO - 2021-12-13 03:20:14 --> Helper loaded: url_helper
INFO - 2021-12-13 03:20:14 --> Helper loaded: file_helper
INFO - 2021-12-13 03:20:14 --> Helper loaded: form_helper
INFO - 2021-12-13 03:20:14 --> Helper loaded: my_helper
INFO - 2021-12-13 03:20:14 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:20:14 --> Controller Class Initialized
DEBUG - 2021-12-13 03:20:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 03:20:14 --> Final output sent to browser
DEBUG - 2021-12-13 03:20:14 --> Total execution time: 0.1260
INFO - 2021-12-13 03:20:16 --> Config Class Initialized
INFO - 2021-12-13 03:20:16 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:20:16 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:20:16 --> Utf8 Class Initialized
INFO - 2021-12-13 03:20:16 --> URI Class Initialized
INFO - 2021-12-13 03:20:16 --> Router Class Initialized
INFO - 2021-12-13 03:20:16 --> Output Class Initialized
INFO - 2021-12-13 03:20:16 --> Security Class Initialized
DEBUG - 2021-12-13 03:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:20:16 --> Input Class Initialized
INFO - 2021-12-13 03:20:16 --> Language Class Initialized
INFO - 2021-12-13 03:20:16 --> Language Class Initialized
INFO - 2021-12-13 03:20:16 --> Config Class Initialized
INFO - 2021-12-13 03:20:16 --> Loader Class Initialized
INFO - 2021-12-13 03:20:16 --> Helper loaded: url_helper
INFO - 2021-12-13 03:20:16 --> Helper loaded: file_helper
INFO - 2021-12-13 03:20:16 --> Helper loaded: form_helper
INFO - 2021-12-13 03:20:16 --> Helper loaded: my_helper
INFO - 2021-12-13 03:20:16 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:20:16 --> Controller Class Initialized
DEBUG - 2021-12-13 03:20:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 03:20:16 --> Final output sent to browser
DEBUG - 2021-12-13 03:20:16 --> Total execution time: 0.1210
INFO - 2021-12-13 03:20:20 --> Config Class Initialized
INFO - 2021-12-13 03:20:20 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:20:20 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:20:20 --> Utf8 Class Initialized
INFO - 2021-12-13 03:20:20 --> URI Class Initialized
INFO - 2021-12-13 03:20:20 --> Router Class Initialized
INFO - 2021-12-13 03:20:20 --> Output Class Initialized
INFO - 2021-12-13 03:20:20 --> Security Class Initialized
DEBUG - 2021-12-13 03:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:20:20 --> Input Class Initialized
INFO - 2021-12-13 03:20:20 --> Language Class Initialized
INFO - 2021-12-13 03:20:20 --> Language Class Initialized
INFO - 2021-12-13 03:20:20 --> Config Class Initialized
INFO - 2021-12-13 03:20:20 --> Loader Class Initialized
INFO - 2021-12-13 03:20:20 --> Helper loaded: url_helper
INFO - 2021-12-13 03:20:20 --> Helper loaded: file_helper
INFO - 2021-12-13 03:20:20 --> Helper loaded: form_helper
INFO - 2021-12-13 03:20:20 --> Helper loaded: my_helper
INFO - 2021-12-13 03:20:21 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:20:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:20:21 --> Controller Class Initialized
DEBUG - 2021-12-13 03:20:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 03:20:21 --> Final output sent to browser
DEBUG - 2021-12-13 03:20:21 --> Total execution time: 0.1250
INFO - 2021-12-13 03:20:22 --> Config Class Initialized
INFO - 2021-12-13 03:20:22 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:20:22 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:20:22 --> Utf8 Class Initialized
INFO - 2021-12-13 03:20:22 --> URI Class Initialized
INFO - 2021-12-13 03:20:22 --> Router Class Initialized
INFO - 2021-12-13 03:20:22 --> Output Class Initialized
INFO - 2021-12-13 03:20:22 --> Security Class Initialized
DEBUG - 2021-12-13 03:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:20:22 --> Input Class Initialized
INFO - 2021-12-13 03:20:22 --> Language Class Initialized
INFO - 2021-12-13 03:20:22 --> Language Class Initialized
INFO - 2021-12-13 03:20:22 --> Config Class Initialized
INFO - 2021-12-13 03:20:22 --> Loader Class Initialized
INFO - 2021-12-13 03:20:22 --> Helper loaded: url_helper
INFO - 2021-12-13 03:20:22 --> Helper loaded: file_helper
INFO - 2021-12-13 03:20:22 --> Helper loaded: form_helper
INFO - 2021-12-13 03:20:22 --> Helper loaded: my_helper
INFO - 2021-12-13 03:20:22 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:20:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:20:22 --> Controller Class Initialized
DEBUG - 2021-12-13 03:20:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 03:20:22 --> Final output sent to browser
DEBUG - 2021-12-13 03:20:22 --> Total execution time: 0.1390
INFO - 2021-12-13 03:20:24 --> Config Class Initialized
INFO - 2021-12-13 03:20:24 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:20:24 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:20:24 --> Utf8 Class Initialized
INFO - 2021-12-13 03:20:24 --> URI Class Initialized
INFO - 2021-12-13 03:20:24 --> Router Class Initialized
INFO - 2021-12-13 03:20:24 --> Output Class Initialized
INFO - 2021-12-13 03:20:24 --> Security Class Initialized
DEBUG - 2021-12-13 03:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:20:24 --> Input Class Initialized
INFO - 2021-12-13 03:20:24 --> Language Class Initialized
INFO - 2021-12-13 03:20:24 --> Language Class Initialized
INFO - 2021-12-13 03:20:24 --> Config Class Initialized
INFO - 2021-12-13 03:20:24 --> Loader Class Initialized
INFO - 2021-12-13 03:20:24 --> Helper loaded: url_helper
INFO - 2021-12-13 03:20:24 --> Helper loaded: file_helper
INFO - 2021-12-13 03:20:24 --> Helper loaded: form_helper
INFO - 2021-12-13 03:20:24 --> Helper loaded: my_helper
INFO - 2021-12-13 03:20:24 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:20:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:20:24 --> Controller Class Initialized
DEBUG - 2021-12-13 03:20:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 03:20:24 --> Final output sent to browser
DEBUG - 2021-12-13 03:20:24 --> Total execution time: 0.1360
INFO - 2021-12-13 03:20:26 --> Config Class Initialized
INFO - 2021-12-13 03:20:26 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:20:26 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:20:26 --> Utf8 Class Initialized
INFO - 2021-12-13 03:20:26 --> URI Class Initialized
INFO - 2021-12-13 03:20:26 --> Router Class Initialized
INFO - 2021-12-13 03:20:26 --> Output Class Initialized
INFO - 2021-12-13 03:20:26 --> Security Class Initialized
DEBUG - 2021-12-13 03:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:20:26 --> Input Class Initialized
INFO - 2021-12-13 03:20:26 --> Language Class Initialized
INFO - 2021-12-13 03:20:26 --> Language Class Initialized
INFO - 2021-12-13 03:20:26 --> Config Class Initialized
INFO - 2021-12-13 03:20:26 --> Loader Class Initialized
INFO - 2021-12-13 03:20:26 --> Helper loaded: url_helper
INFO - 2021-12-13 03:20:26 --> Helper loaded: file_helper
INFO - 2021-12-13 03:20:26 --> Helper loaded: form_helper
INFO - 2021-12-13 03:20:26 --> Helper loaded: my_helper
INFO - 2021-12-13 03:20:26 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:20:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:20:26 --> Controller Class Initialized
DEBUG - 2021-12-13 03:20:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 03:20:26 --> Final output sent to browser
DEBUG - 2021-12-13 03:20:26 --> Total execution time: 0.1520
INFO - 2021-12-13 03:20:28 --> Config Class Initialized
INFO - 2021-12-13 03:20:28 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:20:28 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:20:28 --> Utf8 Class Initialized
INFO - 2021-12-13 03:20:28 --> URI Class Initialized
INFO - 2021-12-13 03:20:28 --> Router Class Initialized
INFO - 2021-12-13 03:20:28 --> Output Class Initialized
INFO - 2021-12-13 03:20:28 --> Security Class Initialized
DEBUG - 2021-12-13 03:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:20:28 --> Input Class Initialized
INFO - 2021-12-13 03:20:28 --> Language Class Initialized
INFO - 2021-12-13 03:20:28 --> Language Class Initialized
INFO - 2021-12-13 03:20:28 --> Config Class Initialized
INFO - 2021-12-13 03:20:28 --> Loader Class Initialized
INFO - 2021-12-13 03:20:28 --> Helper loaded: url_helper
INFO - 2021-12-13 03:20:28 --> Helper loaded: file_helper
INFO - 2021-12-13 03:20:28 --> Helper loaded: form_helper
INFO - 2021-12-13 03:20:28 --> Helper loaded: my_helper
INFO - 2021-12-13 03:20:28 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:20:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:20:28 --> Controller Class Initialized
DEBUG - 2021-12-13 03:20:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 03:20:28 --> Final output sent to browser
DEBUG - 2021-12-13 03:20:28 --> Total execution time: 0.1240
INFO - 2021-12-13 03:20:28 --> Config Class Initialized
INFO - 2021-12-13 03:20:28 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:20:28 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:20:28 --> Utf8 Class Initialized
INFO - 2021-12-13 03:20:28 --> URI Class Initialized
INFO - 2021-12-13 03:20:28 --> Router Class Initialized
INFO - 2021-12-13 03:20:28 --> Output Class Initialized
INFO - 2021-12-13 03:20:28 --> Security Class Initialized
DEBUG - 2021-12-13 03:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:20:28 --> Input Class Initialized
INFO - 2021-12-13 03:20:28 --> Language Class Initialized
INFO - 2021-12-13 03:20:28 --> Language Class Initialized
INFO - 2021-12-13 03:20:28 --> Config Class Initialized
INFO - 2021-12-13 03:20:28 --> Loader Class Initialized
INFO - 2021-12-13 03:20:28 --> Helper loaded: url_helper
INFO - 2021-12-13 03:20:28 --> Helper loaded: file_helper
INFO - 2021-12-13 03:20:28 --> Helper loaded: form_helper
INFO - 2021-12-13 03:20:28 --> Helper loaded: my_helper
INFO - 2021-12-13 03:20:28 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:20:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:20:28 --> Controller Class Initialized
DEBUG - 2021-12-13 03:20:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 03:20:28 --> Final output sent to browser
DEBUG - 2021-12-13 03:20:28 --> Total execution time: 0.1110
INFO - 2021-12-13 03:20:43 --> Config Class Initialized
INFO - 2021-12-13 03:20:43 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:20:43 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:20:43 --> Utf8 Class Initialized
INFO - 2021-12-13 03:20:43 --> URI Class Initialized
INFO - 2021-12-13 03:20:43 --> Router Class Initialized
INFO - 2021-12-13 03:20:43 --> Output Class Initialized
INFO - 2021-12-13 03:20:43 --> Security Class Initialized
DEBUG - 2021-12-13 03:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:20:43 --> Input Class Initialized
INFO - 2021-12-13 03:20:43 --> Language Class Initialized
INFO - 2021-12-13 03:20:43 --> Language Class Initialized
INFO - 2021-12-13 03:20:43 --> Config Class Initialized
INFO - 2021-12-13 03:20:43 --> Loader Class Initialized
INFO - 2021-12-13 03:20:43 --> Helper loaded: url_helper
INFO - 2021-12-13 03:20:43 --> Helper loaded: file_helper
INFO - 2021-12-13 03:20:43 --> Helper loaded: form_helper
INFO - 2021-12-13 03:20:43 --> Helper loaded: my_helper
INFO - 2021-12-13 03:20:43 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:20:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:20:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:20:43 --> Controller Class Initialized
DEBUG - 2021-12-13 03:20:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 03:20:43 --> Final output sent to browser
DEBUG - 2021-12-13 03:20:43 --> Total execution time: 0.1260
INFO - 2021-12-13 03:25:33 --> Config Class Initialized
INFO - 2021-12-13 03:25:33 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:25:33 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:25:33 --> Utf8 Class Initialized
INFO - 2021-12-13 03:25:33 --> URI Class Initialized
INFO - 2021-12-13 03:25:33 --> Router Class Initialized
INFO - 2021-12-13 03:25:33 --> Output Class Initialized
INFO - 2021-12-13 03:25:33 --> Security Class Initialized
DEBUG - 2021-12-13 03:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:25:33 --> Input Class Initialized
INFO - 2021-12-13 03:25:33 --> Language Class Initialized
INFO - 2021-12-13 03:25:33 --> Language Class Initialized
INFO - 2021-12-13 03:25:33 --> Config Class Initialized
INFO - 2021-12-13 03:25:33 --> Loader Class Initialized
INFO - 2021-12-13 03:25:33 --> Helper loaded: url_helper
INFO - 2021-12-13 03:25:33 --> Helper loaded: file_helper
INFO - 2021-12-13 03:25:33 --> Helper loaded: form_helper
INFO - 2021-12-13 03:25:33 --> Helper loaded: my_helper
INFO - 2021-12-13 03:25:33 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:25:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:25:33 --> Controller Class Initialized
DEBUG - 2021-12-13 03:25:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2021-12-13 03:25:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 03:25:33 --> Final output sent to browser
DEBUG - 2021-12-13 03:25:33 --> Total execution time: 0.0740
INFO - 2021-12-13 03:25:45 --> Config Class Initialized
INFO - 2021-12-13 03:25:45 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:25:45 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:25:45 --> Utf8 Class Initialized
INFO - 2021-12-13 03:25:45 --> URI Class Initialized
INFO - 2021-12-13 03:25:45 --> Router Class Initialized
INFO - 2021-12-13 03:25:45 --> Output Class Initialized
INFO - 2021-12-13 03:25:45 --> Security Class Initialized
DEBUG - 2021-12-13 03:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:25:45 --> Input Class Initialized
INFO - 2021-12-13 03:25:45 --> Language Class Initialized
INFO - 2021-12-13 03:25:45 --> Language Class Initialized
INFO - 2021-12-13 03:25:45 --> Config Class Initialized
INFO - 2021-12-13 03:25:45 --> Loader Class Initialized
INFO - 2021-12-13 03:25:45 --> Helper loaded: url_helper
INFO - 2021-12-13 03:25:45 --> Helper loaded: file_helper
INFO - 2021-12-13 03:25:45 --> Helper loaded: form_helper
INFO - 2021-12-13 03:25:45 --> Helper loaded: my_helper
INFO - 2021-12-13 03:25:45 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:25:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:25:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:25:45 --> Controller Class Initialized
INFO - 2021-12-13 03:25:46 --> Final output sent to browser
DEBUG - 2021-12-13 03:25:46 --> Total execution time: 0.2170
INFO - 2021-12-13 03:26:16 --> Config Class Initialized
INFO - 2021-12-13 03:26:16 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:26:16 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:26:16 --> Utf8 Class Initialized
INFO - 2021-12-13 03:26:16 --> URI Class Initialized
INFO - 2021-12-13 03:26:16 --> Router Class Initialized
INFO - 2021-12-13 03:26:16 --> Output Class Initialized
INFO - 2021-12-13 03:26:16 --> Security Class Initialized
DEBUG - 2021-12-13 03:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:26:16 --> Input Class Initialized
INFO - 2021-12-13 03:26:16 --> Language Class Initialized
INFO - 2021-12-13 03:26:16 --> Language Class Initialized
INFO - 2021-12-13 03:26:16 --> Config Class Initialized
INFO - 2021-12-13 03:26:16 --> Loader Class Initialized
INFO - 2021-12-13 03:26:16 --> Helper loaded: url_helper
INFO - 2021-12-13 03:26:16 --> Helper loaded: file_helper
INFO - 2021-12-13 03:26:16 --> Helper loaded: form_helper
INFO - 2021-12-13 03:26:16 --> Helper loaded: my_helper
INFO - 2021-12-13 03:26:16 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:26:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:26:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:26:16 --> Controller Class Initialized
INFO - 2021-12-13 03:26:16 --> Final output sent to browser
DEBUG - 2021-12-13 03:26:16 --> Total execution time: 0.2060
INFO - 2021-12-13 03:26:17 --> Config Class Initialized
INFO - 2021-12-13 03:26:17 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:26:17 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:26:17 --> Utf8 Class Initialized
INFO - 2021-12-13 03:26:17 --> URI Class Initialized
INFO - 2021-12-13 03:26:17 --> Router Class Initialized
INFO - 2021-12-13 03:26:17 --> Output Class Initialized
INFO - 2021-12-13 03:26:17 --> Security Class Initialized
DEBUG - 2021-12-13 03:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:26:17 --> Input Class Initialized
INFO - 2021-12-13 03:26:17 --> Language Class Initialized
INFO - 2021-12-13 03:26:17 --> Language Class Initialized
INFO - 2021-12-13 03:26:17 --> Config Class Initialized
INFO - 2021-12-13 03:26:17 --> Loader Class Initialized
INFO - 2021-12-13 03:26:17 --> Helper loaded: url_helper
INFO - 2021-12-13 03:26:17 --> Helper loaded: file_helper
INFO - 2021-12-13 03:26:17 --> Helper loaded: form_helper
INFO - 2021-12-13 03:26:17 --> Helper loaded: my_helper
INFO - 2021-12-13 03:26:17 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:26:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:26:17 --> Controller Class Initialized
DEBUG - 2021-12-13 03:26:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-13 03:26:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 03:26:17 --> Final output sent to browser
DEBUG - 2021-12-13 03:26:17 --> Total execution time: 0.0630
INFO - 2021-12-13 03:26:21 --> Config Class Initialized
INFO - 2021-12-13 03:26:21 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:26:21 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:26:21 --> Utf8 Class Initialized
INFO - 2021-12-13 03:26:21 --> URI Class Initialized
INFO - 2021-12-13 03:26:21 --> Router Class Initialized
INFO - 2021-12-13 03:26:21 --> Output Class Initialized
INFO - 2021-12-13 03:26:21 --> Security Class Initialized
DEBUG - 2021-12-13 03:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:26:21 --> Input Class Initialized
INFO - 2021-12-13 03:26:21 --> Language Class Initialized
INFO - 2021-12-13 03:26:21 --> Language Class Initialized
INFO - 2021-12-13 03:26:21 --> Config Class Initialized
INFO - 2021-12-13 03:26:21 --> Loader Class Initialized
INFO - 2021-12-13 03:26:21 --> Helper loaded: url_helper
INFO - 2021-12-13 03:26:21 --> Helper loaded: file_helper
INFO - 2021-12-13 03:26:21 --> Helper loaded: form_helper
INFO - 2021-12-13 03:26:21 --> Helper loaded: my_helper
INFO - 2021-12-13 03:26:21 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:26:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:26:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:26:22 --> Controller Class Initialized
DEBUG - 2021-12-13 03:26:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-13 03:26:22 --> Final output sent to browser
DEBUG - 2021-12-13 03:26:22 --> Total execution time: 0.1930
INFO - 2021-12-13 03:26:41 --> Config Class Initialized
INFO - 2021-12-13 03:26:41 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:26:41 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:26:41 --> Utf8 Class Initialized
INFO - 2021-12-13 03:26:41 --> URI Class Initialized
INFO - 2021-12-13 03:26:41 --> Router Class Initialized
INFO - 2021-12-13 03:26:41 --> Output Class Initialized
INFO - 2021-12-13 03:26:41 --> Security Class Initialized
DEBUG - 2021-12-13 03:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:26:41 --> Input Class Initialized
INFO - 2021-12-13 03:26:41 --> Language Class Initialized
INFO - 2021-12-13 03:26:41 --> Language Class Initialized
INFO - 2021-12-13 03:26:41 --> Config Class Initialized
INFO - 2021-12-13 03:26:41 --> Loader Class Initialized
INFO - 2021-12-13 03:26:41 --> Helper loaded: url_helper
INFO - 2021-12-13 03:26:41 --> Helper loaded: file_helper
INFO - 2021-12-13 03:26:41 --> Helper loaded: form_helper
INFO - 2021-12-13 03:26:41 --> Helper loaded: my_helper
INFO - 2021-12-13 03:26:41 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:26:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:26:41 --> Controller Class Initialized
INFO - 2021-12-13 03:26:41 --> Helper loaded: cookie_helper
INFO - 2021-12-13 03:26:41 --> Config Class Initialized
INFO - 2021-12-13 03:26:41 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:26:41 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:26:41 --> Utf8 Class Initialized
INFO - 2021-12-13 03:26:41 --> URI Class Initialized
INFO - 2021-12-13 03:26:41 --> Router Class Initialized
INFO - 2021-12-13 03:26:41 --> Output Class Initialized
INFO - 2021-12-13 03:26:41 --> Security Class Initialized
DEBUG - 2021-12-13 03:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:26:41 --> Input Class Initialized
INFO - 2021-12-13 03:26:41 --> Language Class Initialized
INFO - 2021-12-13 03:26:41 --> Language Class Initialized
INFO - 2021-12-13 03:26:41 --> Config Class Initialized
INFO - 2021-12-13 03:26:41 --> Loader Class Initialized
INFO - 2021-12-13 03:26:41 --> Helper loaded: url_helper
INFO - 2021-12-13 03:26:41 --> Helper loaded: file_helper
INFO - 2021-12-13 03:26:41 --> Helper loaded: form_helper
INFO - 2021-12-13 03:26:41 --> Helper loaded: my_helper
INFO - 2021-12-13 03:26:41 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:26:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:26:41 --> Controller Class Initialized
DEBUG - 2021-12-13 03:26:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-13 03:26:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 03:26:41 --> Final output sent to browser
DEBUG - 2021-12-13 03:26:41 --> Total execution time: 0.0430
INFO - 2021-12-13 03:26:46 --> Config Class Initialized
INFO - 2021-12-13 03:26:46 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:26:46 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:26:46 --> Utf8 Class Initialized
INFO - 2021-12-13 03:26:46 --> URI Class Initialized
INFO - 2021-12-13 03:26:46 --> Router Class Initialized
INFO - 2021-12-13 03:26:46 --> Output Class Initialized
INFO - 2021-12-13 03:26:46 --> Security Class Initialized
DEBUG - 2021-12-13 03:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:26:46 --> Input Class Initialized
INFO - 2021-12-13 03:26:46 --> Language Class Initialized
INFO - 2021-12-13 03:26:46 --> Language Class Initialized
INFO - 2021-12-13 03:26:46 --> Config Class Initialized
INFO - 2021-12-13 03:26:46 --> Loader Class Initialized
INFO - 2021-12-13 03:26:46 --> Helper loaded: url_helper
INFO - 2021-12-13 03:26:46 --> Helper loaded: file_helper
INFO - 2021-12-13 03:26:46 --> Helper loaded: form_helper
INFO - 2021-12-13 03:26:46 --> Helper loaded: my_helper
INFO - 2021-12-13 03:26:46 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:26:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:26:46 --> Controller Class Initialized
INFO - 2021-12-13 03:26:46 --> Helper loaded: cookie_helper
INFO - 2021-12-13 03:26:46 --> Final output sent to browser
DEBUG - 2021-12-13 03:26:46 --> Total execution time: 0.0410
INFO - 2021-12-13 03:26:46 --> Config Class Initialized
INFO - 2021-12-13 03:26:46 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:26:46 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:26:46 --> Utf8 Class Initialized
INFO - 2021-12-13 03:26:46 --> URI Class Initialized
INFO - 2021-12-13 03:26:46 --> Router Class Initialized
INFO - 2021-12-13 03:26:46 --> Output Class Initialized
INFO - 2021-12-13 03:26:46 --> Security Class Initialized
DEBUG - 2021-12-13 03:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:26:46 --> Input Class Initialized
INFO - 2021-12-13 03:26:46 --> Language Class Initialized
INFO - 2021-12-13 03:26:46 --> Language Class Initialized
INFO - 2021-12-13 03:26:46 --> Config Class Initialized
INFO - 2021-12-13 03:26:46 --> Loader Class Initialized
INFO - 2021-12-13 03:26:46 --> Helper loaded: url_helper
INFO - 2021-12-13 03:26:46 --> Helper loaded: file_helper
INFO - 2021-12-13 03:26:46 --> Helper loaded: form_helper
INFO - 2021-12-13 03:26:46 --> Helper loaded: my_helper
INFO - 2021-12-13 03:26:46 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:26:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:26:46 --> Controller Class Initialized
DEBUG - 2021-12-13 03:26:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-13 03:26:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 03:26:47 --> Final output sent to browser
DEBUG - 2021-12-13 03:26:47 --> Total execution time: 0.7290
INFO - 2021-12-13 03:27:18 --> Config Class Initialized
INFO - 2021-12-13 03:27:18 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:27:18 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:27:18 --> Utf8 Class Initialized
INFO - 2021-12-13 03:27:18 --> URI Class Initialized
INFO - 2021-12-13 03:27:18 --> Router Class Initialized
INFO - 2021-12-13 03:27:18 --> Output Class Initialized
INFO - 2021-12-13 03:27:18 --> Security Class Initialized
DEBUG - 2021-12-13 03:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:27:18 --> Input Class Initialized
INFO - 2021-12-13 03:27:18 --> Language Class Initialized
INFO - 2021-12-13 03:27:18 --> Language Class Initialized
INFO - 2021-12-13 03:27:18 --> Config Class Initialized
INFO - 2021-12-13 03:27:18 --> Loader Class Initialized
INFO - 2021-12-13 03:27:18 --> Helper loaded: url_helper
INFO - 2021-12-13 03:27:18 --> Helper loaded: file_helper
INFO - 2021-12-13 03:27:18 --> Helper loaded: form_helper
INFO - 2021-12-13 03:27:18 --> Helper loaded: my_helper
INFO - 2021-12-13 03:27:18 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:27:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:27:18 --> Controller Class Initialized
DEBUG - 2021-12-13 03:27:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-13 03:27:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 03:27:18 --> Final output sent to browser
DEBUG - 2021-12-13 03:27:18 --> Total execution time: 0.0660
INFO - 2021-12-13 03:27:23 --> Config Class Initialized
INFO - 2021-12-13 03:27:23 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:27:23 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:27:23 --> Utf8 Class Initialized
INFO - 2021-12-13 03:27:23 --> URI Class Initialized
INFO - 2021-12-13 03:27:23 --> Router Class Initialized
INFO - 2021-12-13 03:27:23 --> Output Class Initialized
INFO - 2021-12-13 03:27:23 --> Security Class Initialized
DEBUG - 2021-12-13 03:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:27:23 --> Input Class Initialized
INFO - 2021-12-13 03:27:23 --> Language Class Initialized
INFO - 2021-12-13 03:27:23 --> Language Class Initialized
INFO - 2021-12-13 03:27:23 --> Config Class Initialized
INFO - 2021-12-13 03:27:23 --> Loader Class Initialized
INFO - 2021-12-13 03:27:23 --> Helper loaded: url_helper
INFO - 2021-12-13 03:27:23 --> Helper loaded: file_helper
INFO - 2021-12-13 03:27:23 --> Helper loaded: form_helper
INFO - 2021-12-13 03:27:23 --> Helper loaded: my_helper
INFO - 2021-12-13 03:27:23 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:27:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:27:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:27:23 --> Controller Class Initialized
DEBUG - 2021-12-13 03:27:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 03:27:23 --> Final output sent to browser
DEBUG - 2021-12-13 03:27:23 --> Total execution time: 0.1980
INFO - 2021-12-13 03:27:29 --> Config Class Initialized
INFO - 2021-12-13 03:27:29 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:27:29 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:27:29 --> Utf8 Class Initialized
INFO - 2021-12-13 03:27:29 --> URI Class Initialized
INFO - 2021-12-13 03:27:29 --> Router Class Initialized
INFO - 2021-12-13 03:27:29 --> Output Class Initialized
INFO - 2021-12-13 03:27:29 --> Security Class Initialized
DEBUG - 2021-12-13 03:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:27:29 --> Input Class Initialized
INFO - 2021-12-13 03:27:29 --> Language Class Initialized
INFO - 2021-12-13 03:27:29 --> Language Class Initialized
INFO - 2021-12-13 03:27:29 --> Config Class Initialized
INFO - 2021-12-13 03:27:29 --> Loader Class Initialized
INFO - 2021-12-13 03:27:29 --> Helper loaded: url_helper
INFO - 2021-12-13 03:27:29 --> Helper loaded: file_helper
INFO - 2021-12-13 03:27:29 --> Helper loaded: form_helper
INFO - 2021-12-13 03:27:29 --> Helper loaded: my_helper
INFO - 2021-12-13 03:27:29 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:27:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:27:29 --> Controller Class Initialized
DEBUG - 2021-12-13 03:27:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 03:27:29 --> Final output sent to browser
DEBUG - 2021-12-13 03:27:29 --> Total execution time: 0.1470
INFO - 2021-12-13 03:27:30 --> Config Class Initialized
INFO - 2021-12-13 03:27:30 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:27:30 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:27:30 --> Utf8 Class Initialized
INFO - 2021-12-13 03:27:30 --> URI Class Initialized
INFO - 2021-12-13 03:27:30 --> Router Class Initialized
INFO - 2021-12-13 03:27:30 --> Output Class Initialized
INFO - 2021-12-13 03:27:30 --> Security Class Initialized
DEBUG - 2021-12-13 03:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:27:30 --> Input Class Initialized
INFO - 2021-12-13 03:27:30 --> Language Class Initialized
INFO - 2021-12-13 03:27:30 --> Language Class Initialized
INFO - 2021-12-13 03:27:30 --> Config Class Initialized
INFO - 2021-12-13 03:27:30 --> Loader Class Initialized
INFO - 2021-12-13 03:27:30 --> Helper loaded: url_helper
INFO - 2021-12-13 03:27:30 --> Helper loaded: file_helper
INFO - 2021-12-13 03:27:30 --> Helper loaded: form_helper
INFO - 2021-12-13 03:27:30 --> Helper loaded: my_helper
INFO - 2021-12-13 03:27:30 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:27:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:27:30 --> Controller Class Initialized
DEBUG - 2021-12-13 03:27:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 03:27:31 --> Final output sent to browser
DEBUG - 2021-12-13 03:27:31 --> Total execution time: 0.1210
INFO - 2021-12-13 03:27:33 --> Config Class Initialized
INFO - 2021-12-13 03:27:33 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:27:33 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:27:33 --> Utf8 Class Initialized
INFO - 2021-12-13 03:27:33 --> URI Class Initialized
INFO - 2021-12-13 03:27:33 --> Router Class Initialized
INFO - 2021-12-13 03:27:33 --> Output Class Initialized
INFO - 2021-12-13 03:27:33 --> Security Class Initialized
DEBUG - 2021-12-13 03:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:27:33 --> Input Class Initialized
INFO - 2021-12-13 03:27:33 --> Language Class Initialized
INFO - 2021-12-13 03:27:33 --> Language Class Initialized
INFO - 2021-12-13 03:27:33 --> Config Class Initialized
INFO - 2021-12-13 03:27:33 --> Loader Class Initialized
INFO - 2021-12-13 03:27:33 --> Helper loaded: url_helper
INFO - 2021-12-13 03:27:33 --> Helper loaded: file_helper
INFO - 2021-12-13 03:27:33 --> Helper loaded: form_helper
INFO - 2021-12-13 03:27:33 --> Helper loaded: my_helper
INFO - 2021-12-13 03:27:33 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:27:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:27:33 --> Controller Class Initialized
DEBUG - 2021-12-13 03:27:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 03:27:33 --> Final output sent to browser
DEBUG - 2021-12-13 03:27:33 --> Total execution time: 0.1410
INFO - 2021-12-13 03:27:34 --> Config Class Initialized
INFO - 2021-12-13 03:27:34 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:27:34 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:27:34 --> Utf8 Class Initialized
INFO - 2021-12-13 03:27:34 --> URI Class Initialized
INFO - 2021-12-13 03:27:34 --> Router Class Initialized
INFO - 2021-12-13 03:27:34 --> Output Class Initialized
INFO - 2021-12-13 03:27:34 --> Security Class Initialized
DEBUG - 2021-12-13 03:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:27:34 --> Input Class Initialized
INFO - 2021-12-13 03:27:34 --> Language Class Initialized
INFO - 2021-12-13 03:27:34 --> Language Class Initialized
INFO - 2021-12-13 03:27:34 --> Config Class Initialized
INFO - 2021-12-13 03:27:34 --> Loader Class Initialized
INFO - 2021-12-13 03:27:34 --> Helper loaded: url_helper
INFO - 2021-12-13 03:27:34 --> Helper loaded: file_helper
INFO - 2021-12-13 03:27:34 --> Helper loaded: form_helper
INFO - 2021-12-13 03:27:34 --> Helper loaded: my_helper
INFO - 2021-12-13 03:27:34 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:27:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:27:34 --> Controller Class Initialized
DEBUG - 2021-12-13 03:27:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 03:27:34 --> Final output sent to browser
DEBUG - 2021-12-13 03:27:34 --> Total execution time: 0.1190
INFO - 2021-12-13 03:27:36 --> Config Class Initialized
INFO - 2021-12-13 03:27:36 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:27:36 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:27:36 --> Utf8 Class Initialized
INFO - 2021-12-13 03:27:36 --> URI Class Initialized
INFO - 2021-12-13 03:27:36 --> Router Class Initialized
INFO - 2021-12-13 03:27:36 --> Output Class Initialized
INFO - 2021-12-13 03:27:36 --> Security Class Initialized
DEBUG - 2021-12-13 03:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:27:36 --> Input Class Initialized
INFO - 2021-12-13 03:27:36 --> Language Class Initialized
INFO - 2021-12-13 03:27:36 --> Language Class Initialized
INFO - 2021-12-13 03:27:36 --> Config Class Initialized
INFO - 2021-12-13 03:27:36 --> Loader Class Initialized
INFO - 2021-12-13 03:27:36 --> Helper loaded: url_helper
INFO - 2021-12-13 03:27:36 --> Helper loaded: file_helper
INFO - 2021-12-13 03:27:36 --> Helper loaded: form_helper
INFO - 2021-12-13 03:27:36 --> Helper loaded: my_helper
INFO - 2021-12-13 03:27:36 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:27:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:27:36 --> Controller Class Initialized
DEBUG - 2021-12-13 03:27:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 03:27:37 --> Final output sent to browser
DEBUG - 2021-12-13 03:27:37 --> Total execution time: 0.1190
INFO - 2021-12-13 03:27:38 --> Config Class Initialized
INFO - 2021-12-13 03:27:38 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:27:38 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:27:38 --> Utf8 Class Initialized
INFO - 2021-12-13 03:27:38 --> URI Class Initialized
INFO - 2021-12-13 03:27:38 --> Router Class Initialized
INFO - 2021-12-13 03:27:38 --> Output Class Initialized
INFO - 2021-12-13 03:27:38 --> Security Class Initialized
DEBUG - 2021-12-13 03:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:27:38 --> Input Class Initialized
INFO - 2021-12-13 03:27:38 --> Language Class Initialized
INFO - 2021-12-13 03:27:38 --> Language Class Initialized
INFO - 2021-12-13 03:27:38 --> Config Class Initialized
INFO - 2021-12-13 03:27:38 --> Loader Class Initialized
INFO - 2021-12-13 03:27:38 --> Helper loaded: url_helper
INFO - 2021-12-13 03:27:38 --> Helper loaded: file_helper
INFO - 2021-12-13 03:27:38 --> Helper loaded: form_helper
INFO - 2021-12-13 03:27:38 --> Helper loaded: my_helper
INFO - 2021-12-13 03:27:38 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:27:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:27:38 --> Controller Class Initialized
DEBUG - 2021-12-13 03:27:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 03:27:38 --> Final output sent to browser
DEBUG - 2021-12-13 03:27:38 --> Total execution time: 0.1270
INFO - 2021-12-13 03:27:40 --> Config Class Initialized
INFO - 2021-12-13 03:27:40 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:27:40 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:27:40 --> Utf8 Class Initialized
INFO - 2021-12-13 03:27:40 --> URI Class Initialized
INFO - 2021-12-13 03:27:40 --> Router Class Initialized
INFO - 2021-12-13 03:27:40 --> Output Class Initialized
INFO - 2021-12-13 03:27:40 --> Security Class Initialized
DEBUG - 2021-12-13 03:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:27:40 --> Input Class Initialized
INFO - 2021-12-13 03:27:40 --> Language Class Initialized
INFO - 2021-12-13 03:27:40 --> Language Class Initialized
INFO - 2021-12-13 03:27:40 --> Config Class Initialized
INFO - 2021-12-13 03:27:40 --> Loader Class Initialized
INFO - 2021-12-13 03:27:40 --> Helper loaded: url_helper
INFO - 2021-12-13 03:27:40 --> Helper loaded: file_helper
INFO - 2021-12-13 03:27:40 --> Helper loaded: form_helper
INFO - 2021-12-13 03:27:40 --> Helper loaded: my_helper
INFO - 2021-12-13 03:27:40 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:27:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:27:40 --> Controller Class Initialized
DEBUG - 2021-12-13 03:27:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 03:27:40 --> Final output sent to browser
DEBUG - 2021-12-13 03:27:40 --> Total execution time: 0.1230
INFO - 2021-12-13 03:27:42 --> Config Class Initialized
INFO - 2021-12-13 03:27:42 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:27:42 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:27:42 --> Utf8 Class Initialized
INFO - 2021-12-13 03:27:42 --> URI Class Initialized
INFO - 2021-12-13 03:27:42 --> Router Class Initialized
INFO - 2021-12-13 03:27:42 --> Output Class Initialized
INFO - 2021-12-13 03:27:42 --> Security Class Initialized
DEBUG - 2021-12-13 03:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:27:42 --> Input Class Initialized
INFO - 2021-12-13 03:27:42 --> Language Class Initialized
INFO - 2021-12-13 03:27:42 --> Language Class Initialized
INFO - 2021-12-13 03:27:42 --> Config Class Initialized
INFO - 2021-12-13 03:27:42 --> Loader Class Initialized
INFO - 2021-12-13 03:27:42 --> Helper loaded: url_helper
INFO - 2021-12-13 03:27:42 --> Helper loaded: file_helper
INFO - 2021-12-13 03:27:42 --> Helper loaded: form_helper
INFO - 2021-12-13 03:27:42 --> Helper loaded: my_helper
INFO - 2021-12-13 03:27:42 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:27:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:27:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:27:42 --> Controller Class Initialized
DEBUG - 2021-12-13 03:27:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 03:27:42 --> Final output sent to browser
DEBUG - 2021-12-13 03:27:42 --> Total execution time: 0.1340
INFO - 2021-12-13 03:28:34 --> Config Class Initialized
INFO - 2021-12-13 03:28:34 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:28:34 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:28:34 --> Utf8 Class Initialized
INFO - 2021-12-13 03:28:34 --> URI Class Initialized
INFO - 2021-12-13 03:28:34 --> Router Class Initialized
INFO - 2021-12-13 03:28:34 --> Output Class Initialized
INFO - 2021-12-13 03:28:34 --> Security Class Initialized
DEBUG - 2021-12-13 03:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:28:34 --> Input Class Initialized
INFO - 2021-12-13 03:28:34 --> Language Class Initialized
INFO - 2021-12-13 03:28:34 --> Language Class Initialized
INFO - 2021-12-13 03:28:34 --> Config Class Initialized
INFO - 2021-12-13 03:28:34 --> Loader Class Initialized
INFO - 2021-12-13 03:28:34 --> Helper loaded: url_helper
INFO - 2021-12-13 03:28:34 --> Helper loaded: file_helper
INFO - 2021-12-13 03:28:34 --> Helper loaded: form_helper
INFO - 2021-12-13 03:28:34 --> Helper loaded: my_helper
INFO - 2021-12-13 03:28:34 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:28:34 --> Controller Class Initialized
DEBUG - 2021-12-13 03:28:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 03:28:34 --> Final output sent to browser
DEBUG - 2021-12-13 03:28:34 --> Total execution time: 0.1240
INFO - 2021-12-13 03:28:36 --> Config Class Initialized
INFO - 2021-12-13 03:28:36 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:28:36 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:28:36 --> Utf8 Class Initialized
INFO - 2021-12-13 03:28:36 --> URI Class Initialized
INFO - 2021-12-13 03:28:36 --> Router Class Initialized
INFO - 2021-12-13 03:28:36 --> Output Class Initialized
INFO - 2021-12-13 03:28:36 --> Security Class Initialized
DEBUG - 2021-12-13 03:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:28:36 --> Input Class Initialized
INFO - 2021-12-13 03:28:36 --> Language Class Initialized
INFO - 2021-12-13 03:28:37 --> Language Class Initialized
INFO - 2021-12-13 03:28:37 --> Config Class Initialized
INFO - 2021-12-13 03:28:37 --> Loader Class Initialized
INFO - 2021-12-13 03:28:37 --> Helper loaded: url_helper
INFO - 2021-12-13 03:28:37 --> Helper loaded: file_helper
INFO - 2021-12-13 03:28:37 --> Helper loaded: form_helper
INFO - 2021-12-13 03:28:37 --> Helper loaded: my_helper
INFO - 2021-12-13 03:28:37 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:28:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:28:37 --> Controller Class Initialized
DEBUG - 2021-12-13 03:28:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 03:28:37 --> Final output sent to browser
DEBUG - 2021-12-13 03:28:37 --> Total execution time: 0.1280
INFO - 2021-12-13 03:28:39 --> Config Class Initialized
INFO - 2021-12-13 03:28:39 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:28:39 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:28:39 --> Utf8 Class Initialized
INFO - 2021-12-13 03:28:39 --> URI Class Initialized
INFO - 2021-12-13 03:28:39 --> Router Class Initialized
INFO - 2021-12-13 03:28:39 --> Output Class Initialized
INFO - 2021-12-13 03:28:39 --> Security Class Initialized
DEBUG - 2021-12-13 03:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:28:39 --> Input Class Initialized
INFO - 2021-12-13 03:28:39 --> Language Class Initialized
INFO - 2021-12-13 03:28:39 --> Language Class Initialized
INFO - 2021-12-13 03:28:39 --> Config Class Initialized
INFO - 2021-12-13 03:28:39 --> Loader Class Initialized
INFO - 2021-12-13 03:28:39 --> Helper loaded: url_helper
INFO - 2021-12-13 03:28:39 --> Helper loaded: file_helper
INFO - 2021-12-13 03:28:39 --> Helper loaded: form_helper
INFO - 2021-12-13 03:28:39 --> Helper loaded: my_helper
INFO - 2021-12-13 03:28:39 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:28:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:28:39 --> Controller Class Initialized
DEBUG - 2021-12-13 03:28:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 03:28:40 --> Final output sent to browser
DEBUG - 2021-12-13 03:28:40 --> Total execution time: 0.1290
INFO - 2021-12-13 03:28:41 --> Config Class Initialized
INFO - 2021-12-13 03:28:41 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:28:41 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:28:41 --> Utf8 Class Initialized
INFO - 2021-12-13 03:28:41 --> URI Class Initialized
INFO - 2021-12-13 03:28:41 --> Router Class Initialized
INFO - 2021-12-13 03:28:41 --> Output Class Initialized
INFO - 2021-12-13 03:28:41 --> Security Class Initialized
DEBUG - 2021-12-13 03:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:28:41 --> Input Class Initialized
INFO - 2021-12-13 03:28:41 --> Language Class Initialized
INFO - 2021-12-13 03:28:41 --> Language Class Initialized
INFO - 2021-12-13 03:28:41 --> Config Class Initialized
INFO - 2021-12-13 03:28:41 --> Loader Class Initialized
INFO - 2021-12-13 03:28:41 --> Helper loaded: url_helper
INFO - 2021-12-13 03:28:41 --> Helper loaded: file_helper
INFO - 2021-12-13 03:28:41 --> Helper loaded: form_helper
INFO - 2021-12-13 03:28:41 --> Helper loaded: my_helper
INFO - 2021-12-13 03:28:41 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:28:41 --> Controller Class Initialized
DEBUG - 2021-12-13 03:28:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 03:28:41 --> Final output sent to browser
DEBUG - 2021-12-13 03:28:41 --> Total execution time: 0.1210
INFO - 2021-12-13 03:28:43 --> Config Class Initialized
INFO - 2021-12-13 03:28:43 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:28:43 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:28:43 --> Utf8 Class Initialized
INFO - 2021-12-13 03:28:43 --> URI Class Initialized
INFO - 2021-12-13 03:28:43 --> Router Class Initialized
INFO - 2021-12-13 03:28:43 --> Output Class Initialized
INFO - 2021-12-13 03:28:43 --> Security Class Initialized
DEBUG - 2021-12-13 03:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:28:43 --> Input Class Initialized
INFO - 2021-12-13 03:28:43 --> Language Class Initialized
INFO - 2021-12-13 03:28:43 --> Language Class Initialized
INFO - 2021-12-13 03:28:43 --> Config Class Initialized
INFO - 2021-12-13 03:28:43 --> Loader Class Initialized
INFO - 2021-12-13 03:28:43 --> Helper loaded: url_helper
INFO - 2021-12-13 03:28:43 --> Helper loaded: file_helper
INFO - 2021-12-13 03:28:43 --> Helper loaded: form_helper
INFO - 2021-12-13 03:28:43 --> Helper loaded: my_helper
INFO - 2021-12-13 03:28:43 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:28:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:28:43 --> Controller Class Initialized
DEBUG - 2021-12-13 03:28:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 03:28:43 --> Final output sent to browser
DEBUG - 2021-12-13 03:28:43 --> Total execution time: 0.1220
INFO - 2021-12-13 03:28:46 --> Config Class Initialized
INFO - 2021-12-13 03:28:46 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:28:46 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:28:46 --> Utf8 Class Initialized
INFO - 2021-12-13 03:28:46 --> URI Class Initialized
INFO - 2021-12-13 03:28:46 --> Router Class Initialized
INFO - 2021-12-13 03:28:46 --> Output Class Initialized
INFO - 2021-12-13 03:28:46 --> Security Class Initialized
DEBUG - 2021-12-13 03:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:28:46 --> Input Class Initialized
INFO - 2021-12-13 03:28:46 --> Language Class Initialized
INFO - 2021-12-13 03:28:46 --> Language Class Initialized
INFO - 2021-12-13 03:28:46 --> Config Class Initialized
INFO - 2021-12-13 03:28:46 --> Loader Class Initialized
INFO - 2021-12-13 03:28:46 --> Helper loaded: url_helper
INFO - 2021-12-13 03:28:46 --> Helper loaded: file_helper
INFO - 2021-12-13 03:28:46 --> Helper loaded: form_helper
INFO - 2021-12-13 03:28:46 --> Helper loaded: my_helper
INFO - 2021-12-13 03:28:46 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:28:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:28:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:28:46 --> Controller Class Initialized
DEBUG - 2021-12-13 03:28:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 03:28:46 --> Final output sent to browser
DEBUG - 2021-12-13 03:28:46 --> Total execution time: 0.1490
INFO - 2021-12-13 03:28:47 --> Config Class Initialized
INFO - 2021-12-13 03:28:47 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:28:47 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:28:47 --> Utf8 Class Initialized
INFO - 2021-12-13 03:28:47 --> URI Class Initialized
INFO - 2021-12-13 03:28:47 --> Router Class Initialized
INFO - 2021-12-13 03:28:47 --> Output Class Initialized
INFO - 2021-12-13 03:28:47 --> Security Class Initialized
DEBUG - 2021-12-13 03:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:28:47 --> Input Class Initialized
INFO - 2021-12-13 03:28:47 --> Language Class Initialized
INFO - 2021-12-13 03:28:47 --> Language Class Initialized
INFO - 2021-12-13 03:28:47 --> Config Class Initialized
INFO - 2021-12-13 03:28:47 --> Loader Class Initialized
INFO - 2021-12-13 03:28:48 --> Helper loaded: url_helper
INFO - 2021-12-13 03:28:48 --> Helper loaded: file_helper
INFO - 2021-12-13 03:28:48 --> Helper loaded: form_helper
INFO - 2021-12-13 03:28:48 --> Helper loaded: my_helper
INFO - 2021-12-13 03:28:48 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:28:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:28:48 --> Controller Class Initialized
DEBUG - 2021-12-13 03:28:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 03:28:48 --> Final output sent to browser
DEBUG - 2021-12-13 03:28:48 --> Total execution time: 0.1180
INFO - 2021-12-13 03:28:49 --> Config Class Initialized
INFO - 2021-12-13 03:28:49 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:28:49 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:28:49 --> Utf8 Class Initialized
INFO - 2021-12-13 03:28:49 --> URI Class Initialized
INFO - 2021-12-13 03:28:49 --> Router Class Initialized
INFO - 2021-12-13 03:28:49 --> Output Class Initialized
INFO - 2021-12-13 03:28:49 --> Security Class Initialized
DEBUG - 2021-12-13 03:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:28:49 --> Input Class Initialized
INFO - 2021-12-13 03:28:49 --> Language Class Initialized
INFO - 2021-12-13 03:28:49 --> Language Class Initialized
INFO - 2021-12-13 03:28:49 --> Config Class Initialized
INFO - 2021-12-13 03:28:49 --> Loader Class Initialized
INFO - 2021-12-13 03:28:49 --> Helper loaded: url_helper
INFO - 2021-12-13 03:28:49 --> Helper loaded: file_helper
INFO - 2021-12-13 03:28:49 --> Helper loaded: form_helper
INFO - 2021-12-13 03:28:49 --> Helper loaded: my_helper
INFO - 2021-12-13 03:28:49 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:28:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:28:49 --> Controller Class Initialized
DEBUG - 2021-12-13 03:28:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 03:28:49 --> Final output sent to browser
DEBUG - 2021-12-13 03:28:49 --> Total execution time: 0.1560
INFO - 2021-12-13 03:28:51 --> Config Class Initialized
INFO - 2021-12-13 03:28:51 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:28:51 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:28:51 --> Utf8 Class Initialized
INFO - 2021-12-13 03:28:51 --> URI Class Initialized
INFO - 2021-12-13 03:28:51 --> Router Class Initialized
INFO - 2021-12-13 03:28:51 --> Output Class Initialized
INFO - 2021-12-13 03:28:51 --> Security Class Initialized
DEBUG - 2021-12-13 03:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:28:51 --> Input Class Initialized
INFO - 2021-12-13 03:28:51 --> Language Class Initialized
INFO - 2021-12-13 03:28:51 --> Language Class Initialized
INFO - 2021-12-13 03:28:51 --> Config Class Initialized
INFO - 2021-12-13 03:28:51 --> Loader Class Initialized
INFO - 2021-12-13 03:28:51 --> Helper loaded: url_helper
INFO - 2021-12-13 03:28:51 --> Helper loaded: file_helper
INFO - 2021-12-13 03:28:51 --> Helper loaded: form_helper
INFO - 2021-12-13 03:28:51 --> Helper loaded: my_helper
INFO - 2021-12-13 03:28:51 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:28:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:28:51 --> Controller Class Initialized
DEBUG - 2021-12-13 03:28:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 03:28:51 --> Final output sent to browser
DEBUG - 2021-12-13 03:28:51 --> Total execution time: 0.1170
INFO - 2021-12-13 03:28:55 --> Config Class Initialized
INFO - 2021-12-13 03:28:55 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:28:55 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:28:55 --> Utf8 Class Initialized
INFO - 2021-12-13 03:28:55 --> URI Class Initialized
INFO - 2021-12-13 03:28:55 --> Router Class Initialized
INFO - 2021-12-13 03:28:55 --> Output Class Initialized
INFO - 2021-12-13 03:28:55 --> Security Class Initialized
DEBUG - 2021-12-13 03:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:28:55 --> Input Class Initialized
INFO - 2021-12-13 03:28:55 --> Language Class Initialized
INFO - 2021-12-13 03:28:55 --> Language Class Initialized
INFO - 2021-12-13 03:28:55 --> Config Class Initialized
INFO - 2021-12-13 03:28:55 --> Loader Class Initialized
INFO - 2021-12-13 03:28:55 --> Helper loaded: url_helper
INFO - 2021-12-13 03:28:55 --> Helper loaded: file_helper
INFO - 2021-12-13 03:28:55 --> Helper loaded: form_helper
INFO - 2021-12-13 03:28:55 --> Helper loaded: my_helper
INFO - 2021-12-13 03:28:55 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:28:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:28:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:28:55 --> Controller Class Initialized
DEBUG - 2021-12-13 03:28:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 03:28:55 --> Final output sent to browser
DEBUG - 2021-12-13 03:28:55 --> Total execution time: 0.1360
INFO - 2021-12-13 03:28:57 --> Config Class Initialized
INFO - 2021-12-13 03:28:57 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:28:57 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:28:57 --> Utf8 Class Initialized
INFO - 2021-12-13 03:28:57 --> URI Class Initialized
INFO - 2021-12-13 03:28:57 --> Router Class Initialized
INFO - 2021-12-13 03:28:57 --> Output Class Initialized
INFO - 2021-12-13 03:28:57 --> Security Class Initialized
DEBUG - 2021-12-13 03:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:28:57 --> Input Class Initialized
INFO - 2021-12-13 03:28:57 --> Language Class Initialized
INFO - 2021-12-13 03:28:57 --> Language Class Initialized
INFO - 2021-12-13 03:28:57 --> Config Class Initialized
INFO - 2021-12-13 03:28:57 --> Loader Class Initialized
INFO - 2021-12-13 03:28:57 --> Helper loaded: url_helper
INFO - 2021-12-13 03:28:57 --> Helper loaded: file_helper
INFO - 2021-12-13 03:28:57 --> Helper loaded: form_helper
INFO - 2021-12-13 03:28:57 --> Helper loaded: my_helper
INFO - 2021-12-13 03:28:57 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:28:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:28:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:28:57 --> Controller Class Initialized
DEBUG - 2021-12-13 03:28:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 03:28:57 --> Final output sent to browser
DEBUG - 2021-12-13 03:28:57 --> Total execution time: 0.1190
INFO - 2021-12-13 03:28:58 --> Config Class Initialized
INFO - 2021-12-13 03:28:58 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:28:58 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:28:58 --> Utf8 Class Initialized
INFO - 2021-12-13 03:28:58 --> URI Class Initialized
INFO - 2021-12-13 03:28:58 --> Router Class Initialized
INFO - 2021-12-13 03:28:58 --> Output Class Initialized
INFO - 2021-12-13 03:28:58 --> Security Class Initialized
DEBUG - 2021-12-13 03:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:28:58 --> Input Class Initialized
INFO - 2021-12-13 03:28:58 --> Language Class Initialized
INFO - 2021-12-13 03:28:58 --> Language Class Initialized
INFO - 2021-12-13 03:28:58 --> Config Class Initialized
INFO - 2021-12-13 03:28:58 --> Loader Class Initialized
INFO - 2021-12-13 03:28:58 --> Helper loaded: url_helper
INFO - 2021-12-13 03:28:58 --> Helper loaded: file_helper
INFO - 2021-12-13 03:28:58 --> Helper loaded: form_helper
INFO - 2021-12-13 03:28:58 --> Helper loaded: my_helper
INFO - 2021-12-13 03:28:58 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:28:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:28:58 --> Controller Class Initialized
DEBUG - 2021-12-13 03:28:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 03:28:58 --> Final output sent to browser
DEBUG - 2021-12-13 03:28:58 --> Total execution time: 0.1520
INFO - 2021-12-13 03:29:02 --> Config Class Initialized
INFO - 2021-12-13 03:29:02 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:29:02 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:29:02 --> Utf8 Class Initialized
INFO - 2021-12-13 03:29:02 --> URI Class Initialized
INFO - 2021-12-13 03:29:02 --> Router Class Initialized
INFO - 2021-12-13 03:29:02 --> Output Class Initialized
INFO - 2021-12-13 03:29:02 --> Security Class Initialized
DEBUG - 2021-12-13 03:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:29:02 --> Input Class Initialized
INFO - 2021-12-13 03:29:02 --> Language Class Initialized
INFO - 2021-12-13 03:29:02 --> Language Class Initialized
INFO - 2021-12-13 03:29:02 --> Config Class Initialized
INFO - 2021-12-13 03:29:02 --> Loader Class Initialized
INFO - 2021-12-13 03:29:02 --> Helper loaded: url_helper
INFO - 2021-12-13 03:29:02 --> Helper loaded: file_helper
INFO - 2021-12-13 03:29:02 --> Helper loaded: form_helper
INFO - 2021-12-13 03:29:02 --> Helper loaded: my_helper
INFO - 2021-12-13 03:29:02 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:29:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:29:02 --> Controller Class Initialized
DEBUG - 2021-12-13 03:29:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 03:29:02 --> Final output sent to browser
DEBUG - 2021-12-13 03:29:02 --> Total execution time: 0.1170
INFO - 2021-12-13 03:29:03 --> Config Class Initialized
INFO - 2021-12-13 03:29:03 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:29:03 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:29:03 --> Utf8 Class Initialized
INFO - 2021-12-13 03:29:03 --> URI Class Initialized
INFO - 2021-12-13 03:29:03 --> Router Class Initialized
INFO - 2021-12-13 03:29:03 --> Output Class Initialized
INFO - 2021-12-13 03:29:03 --> Security Class Initialized
DEBUG - 2021-12-13 03:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:29:03 --> Input Class Initialized
INFO - 2021-12-13 03:29:03 --> Language Class Initialized
INFO - 2021-12-13 03:29:03 --> Language Class Initialized
INFO - 2021-12-13 03:29:03 --> Config Class Initialized
INFO - 2021-12-13 03:29:03 --> Loader Class Initialized
INFO - 2021-12-13 03:29:03 --> Helper loaded: url_helper
INFO - 2021-12-13 03:29:03 --> Helper loaded: file_helper
INFO - 2021-12-13 03:29:03 --> Helper loaded: form_helper
INFO - 2021-12-13 03:29:03 --> Helper loaded: my_helper
INFO - 2021-12-13 03:29:03 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:29:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:29:03 --> Controller Class Initialized
DEBUG - 2021-12-13 03:29:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 03:29:03 --> Final output sent to browser
DEBUG - 2021-12-13 03:29:03 --> Total execution time: 0.1390
INFO - 2021-12-13 03:29:05 --> Config Class Initialized
INFO - 2021-12-13 03:29:05 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:29:05 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:29:05 --> Utf8 Class Initialized
INFO - 2021-12-13 03:29:05 --> URI Class Initialized
INFO - 2021-12-13 03:29:05 --> Router Class Initialized
INFO - 2021-12-13 03:29:05 --> Output Class Initialized
INFO - 2021-12-13 03:29:05 --> Security Class Initialized
DEBUG - 2021-12-13 03:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:29:05 --> Input Class Initialized
INFO - 2021-12-13 03:29:05 --> Language Class Initialized
INFO - 2021-12-13 03:29:05 --> Language Class Initialized
INFO - 2021-12-13 03:29:05 --> Config Class Initialized
INFO - 2021-12-13 03:29:05 --> Loader Class Initialized
INFO - 2021-12-13 03:29:05 --> Helper loaded: url_helper
INFO - 2021-12-13 03:29:05 --> Helper loaded: file_helper
INFO - 2021-12-13 03:29:05 --> Helper loaded: form_helper
INFO - 2021-12-13 03:29:05 --> Helper loaded: my_helper
INFO - 2021-12-13 03:29:05 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:29:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:29:05 --> Controller Class Initialized
DEBUG - 2021-12-13 03:29:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 03:29:05 --> Final output sent to browser
DEBUG - 2021-12-13 03:29:05 --> Total execution time: 0.1160
INFO - 2021-12-13 03:29:06 --> Config Class Initialized
INFO - 2021-12-13 03:29:06 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:29:06 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:29:06 --> Utf8 Class Initialized
INFO - 2021-12-13 03:29:06 --> URI Class Initialized
INFO - 2021-12-13 03:29:06 --> Router Class Initialized
INFO - 2021-12-13 03:29:06 --> Output Class Initialized
INFO - 2021-12-13 03:29:06 --> Security Class Initialized
DEBUG - 2021-12-13 03:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:29:06 --> Input Class Initialized
INFO - 2021-12-13 03:29:06 --> Language Class Initialized
INFO - 2021-12-13 03:29:06 --> Language Class Initialized
INFO - 2021-12-13 03:29:06 --> Config Class Initialized
INFO - 2021-12-13 03:29:06 --> Loader Class Initialized
INFO - 2021-12-13 03:29:06 --> Helper loaded: url_helper
INFO - 2021-12-13 03:29:06 --> Helper loaded: file_helper
INFO - 2021-12-13 03:29:06 --> Helper loaded: form_helper
INFO - 2021-12-13 03:29:06 --> Helper loaded: my_helper
INFO - 2021-12-13 03:29:06 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:29:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:29:06 --> Controller Class Initialized
DEBUG - 2021-12-13 03:29:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 03:29:07 --> Final output sent to browser
DEBUG - 2021-12-13 03:29:07 --> Total execution time: 0.1450
INFO - 2021-12-13 03:45:15 --> Config Class Initialized
INFO - 2021-12-13 03:45:15 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:45:15 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:45:15 --> Utf8 Class Initialized
INFO - 2021-12-13 03:45:15 --> URI Class Initialized
INFO - 2021-12-13 03:45:15 --> Router Class Initialized
INFO - 2021-12-13 03:45:15 --> Output Class Initialized
INFO - 2021-12-13 03:45:15 --> Security Class Initialized
DEBUG - 2021-12-13 03:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:45:15 --> Input Class Initialized
INFO - 2021-12-13 03:45:15 --> Language Class Initialized
INFO - 2021-12-13 03:45:15 --> Language Class Initialized
INFO - 2021-12-13 03:45:15 --> Config Class Initialized
INFO - 2021-12-13 03:45:15 --> Loader Class Initialized
INFO - 2021-12-13 03:45:15 --> Helper loaded: url_helper
INFO - 2021-12-13 03:45:15 --> Helper loaded: file_helper
INFO - 2021-12-13 03:45:15 --> Helper loaded: form_helper
INFO - 2021-12-13 03:45:15 --> Helper loaded: my_helper
INFO - 2021-12-13 03:45:15 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:45:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:45:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:45:15 --> Controller Class Initialized
INFO - 2021-12-13 03:45:15 --> Helper loaded: cookie_helper
INFO - 2021-12-13 03:45:15 --> Config Class Initialized
INFO - 2021-12-13 03:45:15 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:45:15 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:45:15 --> Utf8 Class Initialized
INFO - 2021-12-13 03:45:15 --> URI Class Initialized
INFO - 2021-12-13 03:45:15 --> Router Class Initialized
INFO - 2021-12-13 03:45:15 --> Output Class Initialized
INFO - 2021-12-13 03:45:15 --> Security Class Initialized
DEBUG - 2021-12-13 03:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:45:15 --> Input Class Initialized
INFO - 2021-12-13 03:45:15 --> Language Class Initialized
INFO - 2021-12-13 03:45:15 --> Language Class Initialized
INFO - 2021-12-13 03:45:15 --> Config Class Initialized
INFO - 2021-12-13 03:45:15 --> Loader Class Initialized
INFO - 2021-12-13 03:45:15 --> Helper loaded: url_helper
INFO - 2021-12-13 03:45:15 --> Helper loaded: file_helper
INFO - 2021-12-13 03:45:15 --> Helper loaded: form_helper
INFO - 2021-12-13 03:45:15 --> Helper loaded: my_helper
INFO - 2021-12-13 03:45:15 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:45:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:45:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:45:15 --> Controller Class Initialized
DEBUG - 2021-12-13 03:45:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-13 03:45:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 03:45:15 --> Final output sent to browser
DEBUG - 2021-12-13 03:45:15 --> Total execution time: 0.0280
INFO - 2021-12-13 03:45:21 --> Config Class Initialized
INFO - 2021-12-13 03:45:21 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:45:21 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:45:21 --> Utf8 Class Initialized
INFO - 2021-12-13 03:45:21 --> URI Class Initialized
INFO - 2021-12-13 03:45:21 --> Router Class Initialized
INFO - 2021-12-13 03:45:21 --> Output Class Initialized
INFO - 2021-12-13 03:45:21 --> Security Class Initialized
DEBUG - 2021-12-13 03:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:45:21 --> Input Class Initialized
INFO - 2021-12-13 03:45:21 --> Language Class Initialized
INFO - 2021-12-13 03:45:21 --> Language Class Initialized
INFO - 2021-12-13 03:45:21 --> Config Class Initialized
INFO - 2021-12-13 03:45:21 --> Loader Class Initialized
INFO - 2021-12-13 03:45:21 --> Helper loaded: url_helper
INFO - 2021-12-13 03:45:21 --> Helper loaded: file_helper
INFO - 2021-12-13 03:45:21 --> Helper loaded: form_helper
INFO - 2021-12-13 03:45:21 --> Helper loaded: my_helper
INFO - 2021-12-13 03:45:21 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:45:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:45:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:45:21 --> Controller Class Initialized
INFO - 2021-12-13 03:45:21 --> Helper loaded: cookie_helper
INFO - 2021-12-13 03:45:21 --> Final output sent to browser
DEBUG - 2021-12-13 03:45:21 --> Total execution time: 0.0510
INFO - 2021-12-13 03:45:22 --> Config Class Initialized
INFO - 2021-12-13 03:45:22 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:45:22 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:45:22 --> Utf8 Class Initialized
INFO - 2021-12-13 03:45:22 --> URI Class Initialized
INFO - 2021-12-13 03:45:22 --> Router Class Initialized
INFO - 2021-12-13 03:45:22 --> Output Class Initialized
INFO - 2021-12-13 03:45:22 --> Security Class Initialized
DEBUG - 2021-12-13 03:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:45:22 --> Input Class Initialized
INFO - 2021-12-13 03:45:22 --> Language Class Initialized
INFO - 2021-12-13 03:45:22 --> Language Class Initialized
INFO - 2021-12-13 03:45:22 --> Config Class Initialized
INFO - 2021-12-13 03:45:22 --> Loader Class Initialized
INFO - 2021-12-13 03:45:22 --> Helper loaded: url_helper
INFO - 2021-12-13 03:45:22 --> Helper loaded: file_helper
INFO - 2021-12-13 03:45:22 --> Helper loaded: form_helper
INFO - 2021-12-13 03:45:22 --> Helper loaded: my_helper
INFO - 2021-12-13 03:45:22 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:45:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:45:22 --> Controller Class Initialized
DEBUG - 2021-12-13 03:45:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-13 03:45:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 03:45:22 --> Final output sent to browser
DEBUG - 2021-12-13 03:45:22 --> Total execution time: 0.7270
INFO - 2021-12-13 03:45:27 --> Config Class Initialized
INFO - 2021-12-13 03:45:27 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:45:27 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:45:27 --> Utf8 Class Initialized
INFO - 2021-12-13 03:45:27 --> URI Class Initialized
INFO - 2021-12-13 03:45:27 --> Router Class Initialized
INFO - 2021-12-13 03:45:27 --> Output Class Initialized
INFO - 2021-12-13 03:45:27 --> Security Class Initialized
DEBUG - 2021-12-13 03:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:45:27 --> Input Class Initialized
INFO - 2021-12-13 03:45:27 --> Language Class Initialized
INFO - 2021-12-13 03:45:27 --> Language Class Initialized
INFO - 2021-12-13 03:45:27 --> Config Class Initialized
INFO - 2021-12-13 03:45:27 --> Loader Class Initialized
INFO - 2021-12-13 03:45:27 --> Helper loaded: url_helper
INFO - 2021-12-13 03:45:27 --> Helper loaded: file_helper
INFO - 2021-12-13 03:45:27 --> Helper loaded: form_helper
INFO - 2021-12-13 03:45:27 --> Helper loaded: my_helper
INFO - 2021-12-13 03:45:27 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:45:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:45:27 --> Controller Class Initialized
DEBUG - 2021-12-13 03:45:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-13 03:45:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 03:45:27 --> Final output sent to browser
DEBUG - 2021-12-13 03:45:27 --> Total execution time: 0.0600
INFO - 2021-12-13 03:45:32 --> Config Class Initialized
INFO - 2021-12-13 03:45:32 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:45:32 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:45:32 --> Utf8 Class Initialized
INFO - 2021-12-13 03:45:32 --> URI Class Initialized
INFO - 2021-12-13 03:45:32 --> Router Class Initialized
INFO - 2021-12-13 03:45:32 --> Output Class Initialized
INFO - 2021-12-13 03:45:32 --> Security Class Initialized
DEBUG - 2021-12-13 03:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:45:32 --> Input Class Initialized
INFO - 2021-12-13 03:45:32 --> Language Class Initialized
INFO - 2021-12-13 03:45:32 --> Language Class Initialized
INFO - 2021-12-13 03:45:33 --> Config Class Initialized
INFO - 2021-12-13 03:45:33 --> Loader Class Initialized
INFO - 2021-12-13 03:45:33 --> Helper loaded: url_helper
INFO - 2021-12-13 03:45:33 --> Helper loaded: file_helper
INFO - 2021-12-13 03:45:33 --> Helper loaded: form_helper
INFO - 2021-12-13 03:45:33 --> Helper loaded: my_helper
INFO - 2021-12-13 03:45:33 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:45:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:45:33 --> Controller Class Initialized
DEBUG - 2021-12-13 03:45:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 03:45:33 --> Final output sent to browser
DEBUG - 2021-12-13 03:45:33 --> Total execution time: 0.2000
INFO - 2021-12-13 03:45:39 --> Config Class Initialized
INFO - 2021-12-13 03:45:39 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:45:39 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:45:39 --> Utf8 Class Initialized
INFO - 2021-12-13 03:45:39 --> URI Class Initialized
INFO - 2021-12-13 03:45:39 --> Router Class Initialized
INFO - 2021-12-13 03:45:39 --> Output Class Initialized
INFO - 2021-12-13 03:45:39 --> Security Class Initialized
DEBUG - 2021-12-13 03:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:45:39 --> Input Class Initialized
INFO - 2021-12-13 03:45:39 --> Language Class Initialized
INFO - 2021-12-13 03:45:39 --> Language Class Initialized
INFO - 2021-12-13 03:45:39 --> Config Class Initialized
INFO - 2021-12-13 03:45:39 --> Loader Class Initialized
INFO - 2021-12-13 03:45:39 --> Helper loaded: url_helper
INFO - 2021-12-13 03:45:39 --> Helper loaded: file_helper
INFO - 2021-12-13 03:45:39 --> Helper loaded: form_helper
INFO - 2021-12-13 03:45:39 --> Helper loaded: my_helper
INFO - 2021-12-13 03:45:39 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:45:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:45:39 --> Controller Class Initialized
DEBUG - 2021-12-13 03:45:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 03:45:40 --> Final output sent to browser
DEBUG - 2021-12-13 03:45:40 --> Total execution time: 0.1590
INFO - 2021-12-13 03:45:41 --> Config Class Initialized
INFO - 2021-12-13 03:45:41 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:45:41 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:45:41 --> Utf8 Class Initialized
INFO - 2021-12-13 03:45:41 --> URI Class Initialized
INFO - 2021-12-13 03:45:41 --> Router Class Initialized
INFO - 2021-12-13 03:45:41 --> Output Class Initialized
INFO - 2021-12-13 03:45:41 --> Security Class Initialized
DEBUG - 2021-12-13 03:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:45:41 --> Input Class Initialized
INFO - 2021-12-13 03:45:41 --> Language Class Initialized
INFO - 2021-12-13 03:45:41 --> Language Class Initialized
INFO - 2021-12-13 03:45:41 --> Config Class Initialized
INFO - 2021-12-13 03:45:41 --> Loader Class Initialized
INFO - 2021-12-13 03:45:41 --> Helper loaded: url_helper
INFO - 2021-12-13 03:45:41 --> Helper loaded: file_helper
INFO - 2021-12-13 03:45:41 --> Helper loaded: form_helper
INFO - 2021-12-13 03:45:41 --> Helper loaded: my_helper
INFO - 2021-12-13 03:45:41 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:45:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:45:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:45:41 --> Controller Class Initialized
DEBUG - 2021-12-13 03:45:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 03:45:41 --> Final output sent to browser
DEBUG - 2021-12-13 03:45:41 --> Total execution time: 0.1230
INFO - 2021-12-13 03:45:44 --> Config Class Initialized
INFO - 2021-12-13 03:45:44 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:45:44 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:45:44 --> Utf8 Class Initialized
INFO - 2021-12-13 03:45:44 --> URI Class Initialized
INFO - 2021-12-13 03:45:44 --> Router Class Initialized
INFO - 2021-12-13 03:45:44 --> Output Class Initialized
INFO - 2021-12-13 03:45:44 --> Security Class Initialized
DEBUG - 2021-12-13 03:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:45:44 --> Input Class Initialized
INFO - 2021-12-13 03:45:44 --> Language Class Initialized
INFO - 2021-12-13 03:45:44 --> Language Class Initialized
INFO - 2021-12-13 03:45:44 --> Config Class Initialized
INFO - 2021-12-13 03:45:44 --> Loader Class Initialized
INFO - 2021-12-13 03:45:44 --> Helper loaded: url_helper
INFO - 2021-12-13 03:45:44 --> Helper loaded: file_helper
INFO - 2021-12-13 03:45:44 --> Helper loaded: form_helper
INFO - 2021-12-13 03:45:44 --> Helper loaded: my_helper
INFO - 2021-12-13 03:45:44 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:45:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:45:44 --> Controller Class Initialized
DEBUG - 2021-12-13 03:45:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 03:45:44 --> Final output sent to browser
DEBUG - 2021-12-13 03:45:44 --> Total execution time: 0.1170
INFO - 2021-12-13 03:45:45 --> Config Class Initialized
INFO - 2021-12-13 03:45:45 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:45:45 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:45:45 --> Utf8 Class Initialized
INFO - 2021-12-13 03:45:45 --> URI Class Initialized
INFO - 2021-12-13 03:45:45 --> Router Class Initialized
INFO - 2021-12-13 03:45:45 --> Output Class Initialized
INFO - 2021-12-13 03:45:45 --> Security Class Initialized
DEBUG - 2021-12-13 03:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:45:45 --> Input Class Initialized
INFO - 2021-12-13 03:45:45 --> Language Class Initialized
INFO - 2021-12-13 03:45:45 --> Language Class Initialized
INFO - 2021-12-13 03:45:45 --> Config Class Initialized
INFO - 2021-12-13 03:45:45 --> Loader Class Initialized
INFO - 2021-12-13 03:45:45 --> Helper loaded: url_helper
INFO - 2021-12-13 03:45:45 --> Helper loaded: file_helper
INFO - 2021-12-13 03:45:45 --> Helper loaded: form_helper
INFO - 2021-12-13 03:45:45 --> Helper loaded: my_helper
INFO - 2021-12-13 03:45:45 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:45:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:45:45 --> Controller Class Initialized
DEBUG - 2021-12-13 03:45:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 03:45:45 --> Final output sent to browser
DEBUG - 2021-12-13 03:45:45 --> Total execution time: 0.1350
INFO - 2021-12-13 03:45:46 --> Config Class Initialized
INFO - 2021-12-13 03:45:46 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:45:46 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:45:46 --> Utf8 Class Initialized
INFO - 2021-12-13 03:45:46 --> URI Class Initialized
INFO - 2021-12-13 03:45:46 --> Router Class Initialized
INFO - 2021-12-13 03:45:46 --> Output Class Initialized
INFO - 2021-12-13 03:45:46 --> Security Class Initialized
DEBUG - 2021-12-13 03:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:45:46 --> Input Class Initialized
INFO - 2021-12-13 03:45:46 --> Language Class Initialized
INFO - 2021-12-13 03:45:46 --> Language Class Initialized
INFO - 2021-12-13 03:45:46 --> Config Class Initialized
INFO - 2021-12-13 03:45:46 --> Loader Class Initialized
INFO - 2021-12-13 03:45:46 --> Helper loaded: url_helper
INFO - 2021-12-13 03:45:46 --> Helper loaded: file_helper
INFO - 2021-12-13 03:45:46 --> Helper loaded: form_helper
INFO - 2021-12-13 03:45:46 --> Helper loaded: my_helper
INFO - 2021-12-13 03:45:46 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:45:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:45:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:45:46 --> Controller Class Initialized
DEBUG - 2021-12-13 03:45:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 03:45:46 --> Final output sent to browser
DEBUG - 2021-12-13 03:45:46 --> Total execution time: 0.1290
INFO - 2021-12-13 03:45:51 --> Config Class Initialized
INFO - 2021-12-13 03:45:51 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:45:51 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:45:51 --> Utf8 Class Initialized
INFO - 2021-12-13 03:45:51 --> URI Class Initialized
INFO - 2021-12-13 03:45:51 --> Router Class Initialized
INFO - 2021-12-13 03:45:51 --> Output Class Initialized
INFO - 2021-12-13 03:45:51 --> Security Class Initialized
DEBUG - 2021-12-13 03:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:45:51 --> Input Class Initialized
INFO - 2021-12-13 03:45:51 --> Language Class Initialized
INFO - 2021-12-13 03:45:51 --> Language Class Initialized
INFO - 2021-12-13 03:45:51 --> Config Class Initialized
INFO - 2021-12-13 03:45:51 --> Loader Class Initialized
INFO - 2021-12-13 03:45:51 --> Helper loaded: url_helper
INFO - 2021-12-13 03:45:51 --> Helper loaded: file_helper
INFO - 2021-12-13 03:45:51 --> Helper loaded: form_helper
INFO - 2021-12-13 03:45:51 --> Helper loaded: my_helper
INFO - 2021-12-13 03:45:51 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:45:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:45:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:45:51 --> Controller Class Initialized
DEBUG - 2021-12-13 03:45:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 03:45:51 --> Final output sent to browser
DEBUG - 2021-12-13 03:45:51 --> Total execution time: 0.1380
INFO - 2021-12-13 03:45:53 --> Config Class Initialized
INFO - 2021-12-13 03:45:53 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:45:53 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:45:53 --> Utf8 Class Initialized
INFO - 2021-12-13 03:45:53 --> URI Class Initialized
INFO - 2021-12-13 03:45:53 --> Router Class Initialized
INFO - 2021-12-13 03:45:53 --> Output Class Initialized
INFO - 2021-12-13 03:45:53 --> Security Class Initialized
DEBUG - 2021-12-13 03:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:45:53 --> Input Class Initialized
INFO - 2021-12-13 03:45:53 --> Language Class Initialized
INFO - 2021-12-13 03:45:53 --> Language Class Initialized
INFO - 2021-12-13 03:45:53 --> Config Class Initialized
INFO - 2021-12-13 03:45:53 --> Loader Class Initialized
INFO - 2021-12-13 03:45:53 --> Helper loaded: url_helper
INFO - 2021-12-13 03:45:53 --> Helper loaded: file_helper
INFO - 2021-12-13 03:45:53 --> Helper loaded: form_helper
INFO - 2021-12-13 03:45:53 --> Helper loaded: my_helper
INFO - 2021-12-13 03:45:53 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:45:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:45:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:45:53 --> Controller Class Initialized
DEBUG - 2021-12-13 03:45:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 03:45:53 --> Final output sent to browser
DEBUG - 2021-12-13 03:45:53 --> Total execution time: 0.1320
INFO - 2021-12-13 03:45:56 --> Config Class Initialized
INFO - 2021-12-13 03:45:56 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:45:56 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:45:56 --> Utf8 Class Initialized
INFO - 2021-12-13 03:45:56 --> URI Class Initialized
INFO - 2021-12-13 03:45:56 --> Router Class Initialized
INFO - 2021-12-13 03:45:56 --> Output Class Initialized
INFO - 2021-12-13 03:45:56 --> Security Class Initialized
DEBUG - 2021-12-13 03:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:45:56 --> Input Class Initialized
INFO - 2021-12-13 03:45:56 --> Language Class Initialized
INFO - 2021-12-13 03:45:56 --> Language Class Initialized
INFO - 2021-12-13 03:45:56 --> Config Class Initialized
INFO - 2021-12-13 03:45:56 --> Loader Class Initialized
INFO - 2021-12-13 03:45:56 --> Helper loaded: url_helper
INFO - 2021-12-13 03:45:56 --> Helper loaded: file_helper
INFO - 2021-12-13 03:45:56 --> Helper loaded: form_helper
INFO - 2021-12-13 03:45:56 --> Helper loaded: my_helper
INFO - 2021-12-13 03:45:56 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:45:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:45:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:45:56 --> Controller Class Initialized
DEBUG - 2021-12-13 03:45:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 03:45:57 --> Final output sent to browser
DEBUG - 2021-12-13 03:45:57 --> Total execution time: 0.1330
INFO - 2021-12-13 03:45:58 --> Config Class Initialized
INFO - 2021-12-13 03:45:58 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:45:58 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:45:58 --> Utf8 Class Initialized
INFO - 2021-12-13 03:45:58 --> URI Class Initialized
INFO - 2021-12-13 03:45:58 --> Router Class Initialized
INFO - 2021-12-13 03:45:58 --> Output Class Initialized
INFO - 2021-12-13 03:45:58 --> Security Class Initialized
DEBUG - 2021-12-13 03:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:45:58 --> Input Class Initialized
INFO - 2021-12-13 03:45:58 --> Language Class Initialized
INFO - 2021-12-13 03:45:58 --> Language Class Initialized
INFO - 2021-12-13 03:45:58 --> Config Class Initialized
INFO - 2021-12-13 03:45:58 --> Loader Class Initialized
INFO - 2021-12-13 03:45:58 --> Helper loaded: url_helper
INFO - 2021-12-13 03:45:58 --> Helper loaded: file_helper
INFO - 2021-12-13 03:45:58 --> Helper loaded: form_helper
INFO - 2021-12-13 03:45:58 --> Helper loaded: my_helper
INFO - 2021-12-13 03:45:58 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:45:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:45:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:45:58 --> Controller Class Initialized
DEBUG - 2021-12-13 03:45:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 03:45:58 --> Final output sent to browser
DEBUG - 2021-12-13 03:45:58 --> Total execution time: 0.1260
INFO - 2021-12-13 03:46:00 --> Config Class Initialized
INFO - 2021-12-13 03:46:00 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:46:00 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:46:00 --> Utf8 Class Initialized
INFO - 2021-12-13 03:46:00 --> URI Class Initialized
INFO - 2021-12-13 03:46:00 --> Router Class Initialized
INFO - 2021-12-13 03:46:00 --> Output Class Initialized
INFO - 2021-12-13 03:46:00 --> Security Class Initialized
DEBUG - 2021-12-13 03:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:46:00 --> Input Class Initialized
INFO - 2021-12-13 03:46:00 --> Language Class Initialized
INFO - 2021-12-13 03:46:00 --> Language Class Initialized
INFO - 2021-12-13 03:46:00 --> Config Class Initialized
INFO - 2021-12-13 03:46:00 --> Loader Class Initialized
INFO - 2021-12-13 03:46:00 --> Helper loaded: url_helper
INFO - 2021-12-13 03:46:00 --> Helper loaded: file_helper
INFO - 2021-12-13 03:46:00 --> Helper loaded: form_helper
INFO - 2021-12-13 03:46:00 --> Helper loaded: my_helper
INFO - 2021-12-13 03:46:00 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:46:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:46:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:46:00 --> Controller Class Initialized
DEBUG - 2021-12-13 03:46:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 03:46:00 --> Final output sent to browser
DEBUG - 2021-12-13 03:46:00 --> Total execution time: 0.1380
INFO - 2021-12-13 03:46:03 --> Config Class Initialized
INFO - 2021-12-13 03:46:03 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:46:03 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:46:03 --> Utf8 Class Initialized
INFO - 2021-12-13 03:46:03 --> URI Class Initialized
INFO - 2021-12-13 03:46:03 --> Router Class Initialized
INFO - 2021-12-13 03:46:03 --> Output Class Initialized
INFO - 2021-12-13 03:46:03 --> Security Class Initialized
DEBUG - 2021-12-13 03:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:46:03 --> Input Class Initialized
INFO - 2021-12-13 03:46:03 --> Language Class Initialized
INFO - 2021-12-13 03:46:03 --> Language Class Initialized
INFO - 2021-12-13 03:46:03 --> Config Class Initialized
INFO - 2021-12-13 03:46:03 --> Loader Class Initialized
INFO - 2021-12-13 03:46:03 --> Helper loaded: url_helper
INFO - 2021-12-13 03:46:03 --> Helper loaded: file_helper
INFO - 2021-12-13 03:46:03 --> Helper loaded: form_helper
INFO - 2021-12-13 03:46:03 --> Helper loaded: my_helper
INFO - 2021-12-13 03:46:03 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:46:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:46:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:46:03 --> Controller Class Initialized
DEBUG - 2021-12-13 03:46:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 03:46:03 --> Final output sent to browser
DEBUG - 2021-12-13 03:46:03 --> Total execution time: 0.1260
INFO - 2021-12-13 03:46:04 --> Config Class Initialized
INFO - 2021-12-13 03:46:04 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:46:04 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:46:04 --> Utf8 Class Initialized
INFO - 2021-12-13 03:46:04 --> URI Class Initialized
INFO - 2021-12-13 03:46:04 --> Router Class Initialized
INFO - 2021-12-13 03:46:04 --> Output Class Initialized
INFO - 2021-12-13 03:46:04 --> Security Class Initialized
DEBUG - 2021-12-13 03:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:46:04 --> Input Class Initialized
INFO - 2021-12-13 03:46:04 --> Language Class Initialized
INFO - 2021-12-13 03:46:04 --> Language Class Initialized
INFO - 2021-12-13 03:46:04 --> Config Class Initialized
INFO - 2021-12-13 03:46:04 --> Loader Class Initialized
INFO - 2021-12-13 03:46:04 --> Helper loaded: url_helper
INFO - 2021-12-13 03:46:04 --> Helper loaded: file_helper
INFO - 2021-12-13 03:46:04 --> Helper loaded: form_helper
INFO - 2021-12-13 03:46:04 --> Helper loaded: my_helper
INFO - 2021-12-13 03:46:04 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:46:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:46:04 --> Controller Class Initialized
DEBUG - 2021-12-13 03:46:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 03:46:04 --> Final output sent to browser
DEBUG - 2021-12-13 03:46:04 --> Total execution time: 0.1360
INFO - 2021-12-13 03:46:07 --> Config Class Initialized
INFO - 2021-12-13 03:46:07 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:46:07 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:46:07 --> Utf8 Class Initialized
INFO - 2021-12-13 03:46:07 --> URI Class Initialized
INFO - 2021-12-13 03:46:07 --> Router Class Initialized
INFO - 2021-12-13 03:46:07 --> Output Class Initialized
INFO - 2021-12-13 03:46:07 --> Security Class Initialized
DEBUG - 2021-12-13 03:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:46:07 --> Input Class Initialized
INFO - 2021-12-13 03:46:07 --> Language Class Initialized
INFO - 2021-12-13 03:46:07 --> Language Class Initialized
INFO - 2021-12-13 03:46:07 --> Config Class Initialized
INFO - 2021-12-13 03:46:07 --> Loader Class Initialized
INFO - 2021-12-13 03:46:07 --> Helper loaded: url_helper
INFO - 2021-12-13 03:46:07 --> Helper loaded: file_helper
INFO - 2021-12-13 03:46:07 --> Helper loaded: form_helper
INFO - 2021-12-13 03:46:07 --> Helper loaded: my_helper
INFO - 2021-12-13 03:46:07 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:46:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:46:07 --> Controller Class Initialized
DEBUG - 2021-12-13 03:46:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 03:46:07 --> Final output sent to browser
DEBUG - 2021-12-13 03:46:07 --> Total execution time: 0.1250
INFO - 2021-12-13 03:46:10 --> Config Class Initialized
INFO - 2021-12-13 03:46:10 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:46:10 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:46:10 --> Utf8 Class Initialized
INFO - 2021-12-13 03:46:10 --> URI Class Initialized
INFO - 2021-12-13 03:46:10 --> Router Class Initialized
INFO - 2021-12-13 03:46:10 --> Output Class Initialized
INFO - 2021-12-13 03:46:10 --> Security Class Initialized
DEBUG - 2021-12-13 03:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:46:10 --> Input Class Initialized
INFO - 2021-12-13 03:46:10 --> Language Class Initialized
INFO - 2021-12-13 03:46:10 --> Language Class Initialized
INFO - 2021-12-13 03:46:10 --> Config Class Initialized
INFO - 2021-12-13 03:46:10 --> Loader Class Initialized
INFO - 2021-12-13 03:46:10 --> Helper loaded: url_helper
INFO - 2021-12-13 03:46:10 --> Helper loaded: file_helper
INFO - 2021-12-13 03:46:10 --> Helper loaded: form_helper
INFO - 2021-12-13 03:46:10 --> Helper loaded: my_helper
INFO - 2021-12-13 03:46:10 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:46:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:46:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:46:10 --> Controller Class Initialized
DEBUG - 2021-12-13 03:46:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 03:46:10 --> Final output sent to browser
DEBUG - 2021-12-13 03:46:10 --> Total execution time: 0.1240
INFO - 2021-12-13 03:46:11 --> Config Class Initialized
INFO - 2021-12-13 03:46:11 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:46:11 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:46:11 --> Utf8 Class Initialized
INFO - 2021-12-13 03:46:11 --> URI Class Initialized
INFO - 2021-12-13 03:46:11 --> Router Class Initialized
INFO - 2021-12-13 03:46:11 --> Output Class Initialized
INFO - 2021-12-13 03:46:11 --> Security Class Initialized
DEBUG - 2021-12-13 03:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:46:11 --> Input Class Initialized
INFO - 2021-12-13 03:46:11 --> Language Class Initialized
INFO - 2021-12-13 03:46:11 --> Language Class Initialized
INFO - 2021-12-13 03:46:11 --> Config Class Initialized
INFO - 2021-12-13 03:46:11 --> Loader Class Initialized
INFO - 2021-12-13 03:46:11 --> Helper loaded: url_helper
INFO - 2021-12-13 03:46:11 --> Helper loaded: file_helper
INFO - 2021-12-13 03:46:11 --> Helper loaded: form_helper
INFO - 2021-12-13 03:46:11 --> Helper loaded: my_helper
INFO - 2021-12-13 03:46:11 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:46:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:46:11 --> Controller Class Initialized
DEBUG - 2021-12-13 03:46:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 03:46:11 --> Final output sent to browser
DEBUG - 2021-12-13 03:46:11 --> Total execution time: 0.1350
INFO - 2021-12-13 03:46:13 --> Config Class Initialized
INFO - 2021-12-13 03:46:13 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:46:13 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:46:13 --> Utf8 Class Initialized
INFO - 2021-12-13 03:46:13 --> URI Class Initialized
INFO - 2021-12-13 03:46:13 --> Router Class Initialized
INFO - 2021-12-13 03:46:13 --> Output Class Initialized
INFO - 2021-12-13 03:46:13 --> Security Class Initialized
DEBUG - 2021-12-13 03:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:46:13 --> Input Class Initialized
INFO - 2021-12-13 03:46:13 --> Language Class Initialized
INFO - 2021-12-13 03:46:13 --> Language Class Initialized
INFO - 2021-12-13 03:46:13 --> Config Class Initialized
INFO - 2021-12-13 03:46:13 --> Loader Class Initialized
INFO - 2021-12-13 03:46:13 --> Helper loaded: url_helper
INFO - 2021-12-13 03:46:13 --> Helper loaded: file_helper
INFO - 2021-12-13 03:46:13 --> Helper loaded: form_helper
INFO - 2021-12-13 03:46:13 --> Helper loaded: my_helper
INFO - 2021-12-13 03:46:13 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:46:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:46:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:46:13 --> Controller Class Initialized
DEBUG - 2021-12-13 03:46:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 03:46:13 --> Final output sent to browser
DEBUG - 2021-12-13 03:46:13 --> Total execution time: 0.1370
INFO - 2021-12-13 03:46:15 --> Config Class Initialized
INFO - 2021-12-13 03:46:15 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:46:15 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:46:15 --> Utf8 Class Initialized
INFO - 2021-12-13 03:46:15 --> URI Class Initialized
INFO - 2021-12-13 03:46:15 --> Router Class Initialized
INFO - 2021-12-13 03:46:15 --> Output Class Initialized
INFO - 2021-12-13 03:46:15 --> Security Class Initialized
DEBUG - 2021-12-13 03:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:46:15 --> Input Class Initialized
INFO - 2021-12-13 03:46:15 --> Language Class Initialized
INFO - 2021-12-13 03:46:15 --> Language Class Initialized
INFO - 2021-12-13 03:46:15 --> Config Class Initialized
INFO - 2021-12-13 03:46:15 --> Loader Class Initialized
INFO - 2021-12-13 03:46:15 --> Helper loaded: url_helper
INFO - 2021-12-13 03:46:15 --> Helper loaded: file_helper
INFO - 2021-12-13 03:46:15 --> Helper loaded: form_helper
INFO - 2021-12-13 03:46:15 --> Helper loaded: my_helper
INFO - 2021-12-13 03:46:15 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:46:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:46:15 --> Controller Class Initialized
DEBUG - 2021-12-13 03:46:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 03:46:16 --> Final output sent to browser
DEBUG - 2021-12-13 03:46:16 --> Total execution time: 0.1270
INFO - 2021-12-13 03:46:17 --> Config Class Initialized
INFO - 2021-12-13 03:46:17 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:46:17 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:46:17 --> Utf8 Class Initialized
INFO - 2021-12-13 03:46:17 --> URI Class Initialized
INFO - 2021-12-13 03:46:17 --> Router Class Initialized
INFO - 2021-12-13 03:46:17 --> Output Class Initialized
INFO - 2021-12-13 03:46:17 --> Security Class Initialized
DEBUG - 2021-12-13 03:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:46:17 --> Input Class Initialized
INFO - 2021-12-13 03:46:17 --> Language Class Initialized
INFO - 2021-12-13 03:46:17 --> Language Class Initialized
INFO - 2021-12-13 03:46:17 --> Config Class Initialized
INFO - 2021-12-13 03:46:17 --> Loader Class Initialized
INFO - 2021-12-13 03:46:17 --> Helper loaded: url_helper
INFO - 2021-12-13 03:46:17 --> Helper loaded: file_helper
INFO - 2021-12-13 03:46:17 --> Helper loaded: form_helper
INFO - 2021-12-13 03:46:17 --> Helper loaded: my_helper
INFO - 2021-12-13 03:46:17 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:46:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:46:17 --> Controller Class Initialized
DEBUG - 2021-12-13 03:46:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 03:46:17 --> Final output sent to browser
DEBUG - 2021-12-13 03:46:17 --> Total execution time: 0.1310
INFO - 2021-12-13 03:46:18 --> Config Class Initialized
INFO - 2021-12-13 03:46:18 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:46:18 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:46:18 --> Utf8 Class Initialized
INFO - 2021-12-13 03:46:18 --> URI Class Initialized
INFO - 2021-12-13 03:46:18 --> Router Class Initialized
INFO - 2021-12-13 03:46:18 --> Output Class Initialized
INFO - 2021-12-13 03:46:18 --> Security Class Initialized
DEBUG - 2021-12-13 03:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:46:18 --> Input Class Initialized
INFO - 2021-12-13 03:46:18 --> Language Class Initialized
INFO - 2021-12-13 03:46:18 --> Language Class Initialized
INFO - 2021-12-13 03:46:18 --> Config Class Initialized
INFO - 2021-12-13 03:46:18 --> Loader Class Initialized
INFO - 2021-12-13 03:46:18 --> Helper loaded: url_helper
INFO - 2021-12-13 03:46:18 --> Helper loaded: file_helper
INFO - 2021-12-13 03:46:18 --> Helper loaded: form_helper
INFO - 2021-12-13 03:46:18 --> Helper loaded: my_helper
INFO - 2021-12-13 03:46:18 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:46:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:46:18 --> Controller Class Initialized
DEBUG - 2021-12-13 03:46:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 03:46:18 --> Final output sent to browser
DEBUG - 2021-12-13 03:46:18 --> Total execution time: 0.1390
INFO - 2021-12-13 03:46:20 --> Config Class Initialized
INFO - 2021-12-13 03:46:20 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:46:20 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:46:20 --> Utf8 Class Initialized
INFO - 2021-12-13 03:46:20 --> URI Class Initialized
INFO - 2021-12-13 03:46:20 --> Router Class Initialized
INFO - 2021-12-13 03:46:20 --> Output Class Initialized
INFO - 2021-12-13 03:46:20 --> Security Class Initialized
DEBUG - 2021-12-13 03:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:46:20 --> Input Class Initialized
INFO - 2021-12-13 03:46:20 --> Language Class Initialized
INFO - 2021-12-13 03:46:20 --> Language Class Initialized
INFO - 2021-12-13 03:46:20 --> Config Class Initialized
INFO - 2021-12-13 03:46:20 --> Loader Class Initialized
INFO - 2021-12-13 03:46:20 --> Helper loaded: url_helper
INFO - 2021-12-13 03:46:20 --> Helper loaded: file_helper
INFO - 2021-12-13 03:46:20 --> Helper loaded: form_helper
INFO - 2021-12-13 03:46:20 --> Helper loaded: my_helper
INFO - 2021-12-13 03:46:20 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:46:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:46:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:46:20 --> Controller Class Initialized
DEBUG - 2021-12-13 03:46:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 03:46:20 --> Final output sent to browser
DEBUG - 2021-12-13 03:46:20 --> Total execution time: 0.1390
INFO - 2021-12-13 03:46:24 --> Config Class Initialized
INFO - 2021-12-13 03:46:24 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:46:24 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:46:24 --> Utf8 Class Initialized
INFO - 2021-12-13 03:46:24 --> URI Class Initialized
INFO - 2021-12-13 03:46:24 --> Router Class Initialized
INFO - 2021-12-13 03:46:24 --> Output Class Initialized
INFO - 2021-12-13 03:46:24 --> Security Class Initialized
DEBUG - 2021-12-13 03:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:46:24 --> Input Class Initialized
INFO - 2021-12-13 03:46:24 --> Language Class Initialized
INFO - 2021-12-13 03:46:24 --> Language Class Initialized
INFO - 2021-12-13 03:46:24 --> Config Class Initialized
INFO - 2021-12-13 03:46:24 --> Loader Class Initialized
INFO - 2021-12-13 03:46:24 --> Helper loaded: url_helper
INFO - 2021-12-13 03:46:24 --> Helper loaded: file_helper
INFO - 2021-12-13 03:46:24 --> Helper loaded: form_helper
INFO - 2021-12-13 03:46:24 --> Helper loaded: my_helper
INFO - 2021-12-13 03:46:24 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:46:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:46:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:46:24 --> Controller Class Initialized
DEBUG - 2021-12-13 03:46:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 03:46:24 --> Final output sent to browser
DEBUG - 2021-12-13 03:46:24 --> Total execution time: 0.1330
INFO - 2021-12-13 03:46:25 --> Config Class Initialized
INFO - 2021-12-13 03:46:25 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:46:25 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:46:25 --> Utf8 Class Initialized
INFO - 2021-12-13 03:46:25 --> URI Class Initialized
INFO - 2021-12-13 03:46:25 --> Router Class Initialized
INFO - 2021-12-13 03:46:25 --> Output Class Initialized
INFO - 2021-12-13 03:46:25 --> Security Class Initialized
DEBUG - 2021-12-13 03:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:46:25 --> Input Class Initialized
INFO - 2021-12-13 03:46:25 --> Language Class Initialized
INFO - 2021-12-13 03:46:25 --> Language Class Initialized
INFO - 2021-12-13 03:46:25 --> Config Class Initialized
INFO - 2021-12-13 03:46:25 --> Loader Class Initialized
INFO - 2021-12-13 03:46:25 --> Helper loaded: url_helper
INFO - 2021-12-13 03:46:25 --> Helper loaded: file_helper
INFO - 2021-12-13 03:46:25 --> Helper loaded: form_helper
INFO - 2021-12-13 03:46:25 --> Helper loaded: my_helper
INFO - 2021-12-13 03:46:25 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:46:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:46:25 --> Controller Class Initialized
DEBUG - 2021-12-13 03:46:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 03:46:25 --> Final output sent to browser
DEBUG - 2021-12-13 03:46:25 --> Total execution time: 0.1370
INFO - 2021-12-13 03:51:02 --> Config Class Initialized
INFO - 2021-12-13 03:51:02 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:51:02 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:51:02 --> Utf8 Class Initialized
INFO - 2021-12-13 03:51:02 --> URI Class Initialized
INFO - 2021-12-13 03:51:02 --> Router Class Initialized
INFO - 2021-12-13 03:51:02 --> Output Class Initialized
INFO - 2021-12-13 03:51:02 --> Security Class Initialized
DEBUG - 2021-12-13 03:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:51:02 --> Input Class Initialized
INFO - 2021-12-13 03:51:02 --> Language Class Initialized
INFO - 2021-12-13 03:51:02 --> Language Class Initialized
INFO - 2021-12-13 03:51:02 --> Config Class Initialized
INFO - 2021-12-13 03:51:02 --> Loader Class Initialized
INFO - 2021-12-13 03:51:02 --> Helper loaded: url_helper
INFO - 2021-12-13 03:51:02 --> Helper loaded: file_helper
INFO - 2021-12-13 03:51:02 --> Helper loaded: form_helper
INFO - 2021-12-13 03:51:02 --> Helper loaded: my_helper
INFO - 2021-12-13 03:51:02 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:51:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:51:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:51:02 --> Controller Class Initialized
DEBUG - 2021-12-13 03:51:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-12-13 03:51:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 03:51:02 --> Final output sent to browser
DEBUG - 2021-12-13 03:51:02 --> Total execution time: 0.0780
INFO - 2021-12-13 03:51:33 --> Config Class Initialized
INFO - 2021-12-13 03:51:33 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:51:33 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:51:33 --> Utf8 Class Initialized
INFO - 2021-12-13 03:51:33 --> URI Class Initialized
INFO - 2021-12-13 03:51:33 --> Router Class Initialized
INFO - 2021-12-13 03:51:33 --> Output Class Initialized
INFO - 2021-12-13 03:51:33 --> Security Class Initialized
DEBUG - 2021-12-13 03:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:51:33 --> Input Class Initialized
INFO - 2021-12-13 03:51:33 --> Language Class Initialized
INFO - 2021-12-13 03:51:33 --> Language Class Initialized
INFO - 2021-12-13 03:51:33 --> Config Class Initialized
INFO - 2021-12-13 03:51:33 --> Loader Class Initialized
INFO - 2021-12-13 03:51:33 --> Helper loaded: url_helper
INFO - 2021-12-13 03:51:33 --> Helper loaded: file_helper
INFO - 2021-12-13 03:51:33 --> Helper loaded: form_helper
INFO - 2021-12-13 03:51:33 --> Helper loaded: my_helper
INFO - 2021-12-13 03:51:33 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:51:33 --> Controller Class Initialized
INFO - 2021-12-13 03:51:33 --> Final output sent to browser
DEBUG - 2021-12-13 03:51:33 --> Total execution time: 0.0970
INFO - 2021-12-13 03:51:42 --> Config Class Initialized
INFO - 2021-12-13 03:51:42 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:51:42 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:51:42 --> Utf8 Class Initialized
INFO - 2021-12-13 03:51:42 --> URI Class Initialized
INFO - 2021-12-13 03:51:42 --> Router Class Initialized
INFO - 2021-12-13 03:51:42 --> Output Class Initialized
INFO - 2021-12-13 03:51:42 --> Security Class Initialized
DEBUG - 2021-12-13 03:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:51:42 --> Input Class Initialized
INFO - 2021-12-13 03:51:42 --> Language Class Initialized
INFO - 2021-12-13 03:51:42 --> Language Class Initialized
INFO - 2021-12-13 03:51:42 --> Config Class Initialized
INFO - 2021-12-13 03:51:42 --> Loader Class Initialized
INFO - 2021-12-13 03:51:42 --> Helper loaded: url_helper
INFO - 2021-12-13 03:51:42 --> Helper loaded: file_helper
INFO - 2021-12-13 03:51:42 --> Helper loaded: form_helper
INFO - 2021-12-13 03:51:42 --> Helper loaded: my_helper
INFO - 2021-12-13 03:51:42 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:51:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:51:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:51:42 --> Controller Class Initialized
DEBUG - 2021-12-13 03:51:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2021-12-13 03:51:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 03:51:42 --> Final output sent to browser
DEBUG - 2021-12-13 03:51:42 --> Total execution time: 0.0570
INFO - 2021-12-13 03:52:08 --> Config Class Initialized
INFO - 2021-12-13 03:52:08 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:52:08 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:52:08 --> Utf8 Class Initialized
INFO - 2021-12-13 03:52:08 --> URI Class Initialized
INFO - 2021-12-13 03:52:08 --> Router Class Initialized
INFO - 2021-12-13 03:52:08 --> Output Class Initialized
INFO - 2021-12-13 03:52:08 --> Security Class Initialized
DEBUG - 2021-12-13 03:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:52:08 --> Input Class Initialized
INFO - 2021-12-13 03:52:08 --> Language Class Initialized
INFO - 2021-12-13 03:52:08 --> Language Class Initialized
INFO - 2021-12-13 03:52:08 --> Config Class Initialized
INFO - 2021-12-13 03:52:08 --> Loader Class Initialized
INFO - 2021-12-13 03:52:08 --> Helper loaded: url_helper
INFO - 2021-12-13 03:52:09 --> Helper loaded: file_helper
INFO - 2021-12-13 03:52:09 --> Helper loaded: form_helper
INFO - 2021-12-13 03:52:09 --> Helper loaded: my_helper
INFO - 2021-12-13 03:52:09 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:52:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:52:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:52:09 --> Controller Class Initialized
INFO - 2021-12-13 03:52:09 --> Final output sent to browser
DEBUG - 2021-12-13 03:52:09 --> Total execution time: 0.1110
INFO - 2021-12-13 03:52:10 --> Config Class Initialized
INFO - 2021-12-13 03:52:10 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:52:10 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:52:10 --> Utf8 Class Initialized
INFO - 2021-12-13 03:52:10 --> URI Class Initialized
INFO - 2021-12-13 03:52:10 --> Router Class Initialized
INFO - 2021-12-13 03:52:10 --> Output Class Initialized
INFO - 2021-12-13 03:52:10 --> Security Class Initialized
DEBUG - 2021-12-13 03:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:52:10 --> Input Class Initialized
INFO - 2021-12-13 03:52:10 --> Language Class Initialized
INFO - 2021-12-13 03:52:10 --> Language Class Initialized
INFO - 2021-12-13 03:52:10 --> Config Class Initialized
INFO - 2021-12-13 03:52:10 --> Loader Class Initialized
INFO - 2021-12-13 03:52:10 --> Helper loaded: url_helper
INFO - 2021-12-13 03:52:10 --> Helper loaded: file_helper
INFO - 2021-12-13 03:52:10 --> Helper loaded: form_helper
INFO - 2021-12-13 03:52:10 --> Helper loaded: my_helper
INFO - 2021-12-13 03:52:10 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:52:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:52:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:52:10 --> Controller Class Initialized
DEBUG - 2021-12-13 03:52:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-13 03:52:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 03:52:10 --> Final output sent to browser
DEBUG - 2021-12-13 03:52:10 --> Total execution time: 0.0570
INFO - 2021-12-13 03:52:15 --> Config Class Initialized
INFO - 2021-12-13 03:52:15 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:52:15 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:52:15 --> Utf8 Class Initialized
INFO - 2021-12-13 03:52:15 --> URI Class Initialized
INFO - 2021-12-13 03:52:15 --> Router Class Initialized
INFO - 2021-12-13 03:52:15 --> Output Class Initialized
INFO - 2021-12-13 03:52:15 --> Security Class Initialized
DEBUG - 2021-12-13 03:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:52:15 --> Input Class Initialized
INFO - 2021-12-13 03:52:15 --> Language Class Initialized
INFO - 2021-12-13 03:52:15 --> Language Class Initialized
INFO - 2021-12-13 03:52:15 --> Config Class Initialized
INFO - 2021-12-13 03:52:15 --> Loader Class Initialized
INFO - 2021-12-13 03:52:15 --> Helper loaded: url_helper
INFO - 2021-12-13 03:52:15 --> Helper loaded: file_helper
INFO - 2021-12-13 03:52:15 --> Helper loaded: form_helper
INFO - 2021-12-13 03:52:15 --> Helper loaded: my_helper
INFO - 2021-12-13 03:52:15 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:52:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:52:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:52:15 --> Controller Class Initialized
DEBUG - 2021-12-13 03:52:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 03:52:15 --> Final output sent to browser
DEBUG - 2021-12-13 03:52:15 --> Total execution time: 0.2060
INFO - 2021-12-13 03:52:23 --> Config Class Initialized
INFO - 2021-12-13 03:52:23 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:52:23 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:52:23 --> Utf8 Class Initialized
INFO - 2021-12-13 03:52:23 --> URI Class Initialized
INFO - 2021-12-13 03:52:23 --> Router Class Initialized
INFO - 2021-12-13 03:52:23 --> Output Class Initialized
INFO - 2021-12-13 03:52:23 --> Security Class Initialized
DEBUG - 2021-12-13 03:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:52:23 --> Input Class Initialized
INFO - 2021-12-13 03:52:23 --> Language Class Initialized
INFO - 2021-12-13 03:52:23 --> Language Class Initialized
INFO - 2021-12-13 03:52:23 --> Config Class Initialized
INFO - 2021-12-13 03:52:23 --> Loader Class Initialized
INFO - 2021-12-13 03:52:23 --> Helper loaded: url_helper
INFO - 2021-12-13 03:52:23 --> Helper loaded: file_helper
INFO - 2021-12-13 03:52:23 --> Helper loaded: form_helper
INFO - 2021-12-13 03:52:23 --> Helper loaded: my_helper
INFO - 2021-12-13 03:52:23 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:52:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:52:23 --> Controller Class Initialized
DEBUG - 2021-12-13 03:52:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-12-13 03:52:23 --> Final output sent to browser
DEBUG - 2021-12-13 03:52:23 --> Total execution time: 0.1450
INFO - 2021-12-13 03:53:25 --> Config Class Initialized
INFO - 2021-12-13 03:53:25 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:53:25 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:53:25 --> Utf8 Class Initialized
INFO - 2021-12-13 03:53:25 --> URI Class Initialized
INFO - 2021-12-13 03:53:25 --> Router Class Initialized
INFO - 2021-12-13 03:53:25 --> Output Class Initialized
INFO - 2021-12-13 03:53:25 --> Security Class Initialized
DEBUG - 2021-12-13 03:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:53:25 --> Input Class Initialized
INFO - 2021-12-13 03:53:25 --> Language Class Initialized
INFO - 2021-12-13 03:53:25 --> Language Class Initialized
INFO - 2021-12-13 03:53:25 --> Config Class Initialized
INFO - 2021-12-13 03:53:25 --> Loader Class Initialized
INFO - 2021-12-13 03:53:25 --> Helper loaded: url_helper
INFO - 2021-12-13 03:53:25 --> Helper loaded: file_helper
INFO - 2021-12-13 03:53:25 --> Helper loaded: form_helper
INFO - 2021-12-13 03:53:25 --> Helper loaded: my_helper
INFO - 2021-12-13 03:53:25 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:53:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:53:25 --> Controller Class Initialized
INFO - 2021-12-13 03:53:25 --> Helper loaded: cookie_helper
INFO - 2021-12-13 03:53:25 --> Config Class Initialized
INFO - 2021-12-13 03:53:25 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:53:25 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:53:25 --> Utf8 Class Initialized
INFO - 2021-12-13 03:53:25 --> URI Class Initialized
INFO - 2021-12-13 03:53:25 --> Router Class Initialized
INFO - 2021-12-13 03:53:25 --> Output Class Initialized
INFO - 2021-12-13 03:53:25 --> Security Class Initialized
DEBUG - 2021-12-13 03:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:53:25 --> Input Class Initialized
INFO - 2021-12-13 03:53:25 --> Language Class Initialized
INFO - 2021-12-13 03:53:25 --> Language Class Initialized
INFO - 2021-12-13 03:53:25 --> Config Class Initialized
INFO - 2021-12-13 03:53:25 --> Loader Class Initialized
INFO - 2021-12-13 03:53:25 --> Helper loaded: url_helper
INFO - 2021-12-13 03:53:25 --> Helper loaded: file_helper
INFO - 2021-12-13 03:53:25 --> Helper loaded: form_helper
INFO - 2021-12-13 03:53:25 --> Helper loaded: my_helper
INFO - 2021-12-13 03:53:25 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:53:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:53:25 --> Controller Class Initialized
DEBUG - 2021-12-13 03:53:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-13 03:53:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 03:53:25 --> Final output sent to browser
DEBUG - 2021-12-13 03:53:25 --> Total execution time: 0.0350
INFO - 2021-12-13 03:53:30 --> Config Class Initialized
INFO - 2021-12-13 03:53:30 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:53:30 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:53:30 --> Utf8 Class Initialized
INFO - 2021-12-13 03:53:30 --> URI Class Initialized
INFO - 2021-12-13 03:53:30 --> Router Class Initialized
INFO - 2021-12-13 03:53:30 --> Output Class Initialized
INFO - 2021-12-13 03:53:30 --> Security Class Initialized
DEBUG - 2021-12-13 03:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:53:30 --> Input Class Initialized
INFO - 2021-12-13 03:53:30 --> Language Class Initialized
INFO - 2021-12-13 03:53:30 --> Language Class Initialized
INFO - 2021-12-13 03:53:30 --> Config Class Initialized
INFO - 2021-12-13 03:53:30 --> Loader Class Initialized
INFO - 2021-12-13 03:53:30 --> Helper loaded: url_helper
INFO - 2021-12-13 03:53:30 --> Helper loaded: file_helper
INFO - 2021-12-13 03:53:30 --> Helper loaded: form_helper
INFO - 2021-12-13 03:53:30 --> Helper loaded: my_helper
INFO - 2021-12-13 03:53:30 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:53:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:53:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:53:30 --> Controller Class Initialized
INFO - 2021-12-13 03:53:30 --> Helper loaded: cookie_helper
INFO - 2021-12-13 03:53:30 --> Final output sent to browser
DEBUG - 2021-12-13 03:53:30 --> Total execution time: 0.0420
INFO - 2021-12-13 03:53:30 --> Config Class Initialized
INFO - 2021-12-13 03:53:30 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:53:30 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:53:30 --> Utf8 Class Initialized
INFO - 2021-12-13 03:53:30 --> URI Class Initialized
INFO - 2021-12-13 03:53:30 --> Router Class Initialized
INFO - 2021-12-13 03:53:30 --> Output Class Initialized
INFO - 2021-12-13 03:53:30 --> Security Class Initialized
DEBUG - 2021-12-13 03:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:53:30 --> Input Class Initialized
INFO - 2021-12-13 03:53:30 --> Language Class Initialized
INFO - 2021-12-13 03:53:30 --> Language Class Initialized
INFO - 2021-12-13 03:53:30 --> Config Class Initialized
INFO - 2021-12-13 03:53:30 --> Loader Class Initialized
INFO - 2021-12-13 03:53:30 --> Helper loaded: url_helper
INFO - 2021-12-13 03:53:30 --> Helper loaded: file_helper
INFO - 2021-12-13 03:53:30 --> Helper loaded: form_helper
INFO - 2021-12-13 03:53:30 --> Helper loaded: my_helper
INFO - 2021-12-13 03:53:30 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:53:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:53:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:53:30 --> Controller Class Initialized
DEBUG - 2021-12-13 03:53:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-13 03:53:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 03:53:31 --> Final output sent to browser
DEBUG - 2021-12-13 03:53:31 --> Total execution time: 0.7490
INFO - 2021-12-13 03:53:38 --> Config Class Initialized
INFO - 2021-12-13 03:53:38 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:53:38 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:53:38 --> Utf8 Class Initialized
INFO - 2021-12-13 03:53:38 --> URI Class Initialized
INFO - 2021-12-13 03:53:38 --> Router Class Initialized
INFO - 2021-12-13 03:53:38 --> Output Class Initialized
INFO - 2021-12-13 03:53:38 --> Security Class Initialized
DEBUG - 2021-12-13 03:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:53:38 --> Input Class Initialized
INFO - 2021-12-13 03:53:38 --> Language Class Initialized
INFO - 2021-12-13 03:53:38 --> Language Class Initialized
INFO - 2021-12-13 03:53:38 --> Config Class Initialized
INFO - 2021-12-13 03:53:38 --> Loader Class Initialized
INFO - 2021-12-13 03:53:38 --> Helper loaded: url_helper
INFO - 2021-12-13 03:53:38 --> Helper loaded: file_helper
INFO - 2021-12-13 03:53:38 --> Helper loaded: form_helper
INFO - 2021-12-13 03:53:38 --> Helper loaded: my_helper
INFO - 2021-12-13 03:53:38 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:53:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:53:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:53:38 --> Controller Class Initialized
DEBUG - 2021-12-13 03:53:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-13 03:53:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 03:53:38 --> Final output sent to browser
DEBUG - 2021-12-13 03:53:38 --> Total execution time: 0.0600
INFO - 2021-12-13 03:53:42 --> Config Class Initialized
INFO - 2021-12-13 03:53:42 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:53:42 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:53:42 --> Utf8 Class Initialized
INFO - 2021-12-13 03:53:42 --> URI Class Initialized
INFO - 2021-12-13 03:53:42 --> Router Class Initialized
INFO - 2021-12-13 03:53:42 --> Output Class Initialized
INFO - 2021-12-13 03:53:42 --> Security Class Initialized
DEBUG - 2021-12-13 03:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:53:42 --> Input Class Initialized
INFO - 2021-12-13 03:53:42 --> Language Class Initialized
INFO - 2021-12-13 03:53:42 --> Language Class Initialized
INFO - 2021-12-13 03:53:42 --> Config Class Initialized
INFO - 2021-12-13 03:53:42 --> Loader Class Initialized
INFO - 2021-12-13 03:53:42 --> Helper loaded: url_helper
INFO - 2021-12-13 03:53:42 --> Helper loaded: file_helper
INFO - 2021-12-13 03:53:42 --> Helper loaded: form_helper
INFO - 2021-12-13 03:53:42 --> Helper loaded: my_helper
INFO - 2021-12-13 03:53:42 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:53:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:53:42 --> Controller Class Initialized
DEBUG - 2021-12-13 03:53:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-12-13 03:53:42 --> Final output sent to browser
DEBUG - 2021-12-13 03:53:42 --> Total execution time: 0.1970
INFO - 2021-12-13 03:53:44 --> Config Class Initialized
INFO - 2021-12-13 03:53:44 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:53:44 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:53:44 --> Utf8 Class Initialized
INFO - 2021-12-13 03:53:44 --> URI Class Initialized
INFO - 2021-12-13 03:53:44 --> Router Class Initialized
INFO - 2021-12-13 03:53:44 --> Output Class Initialized
INFO - 2021-12-13 03:53:44 --> Security Class Initialized
DEBUG - 2021-12-13 03:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:53:44 --> Input Class Initialized
INFO - 2021-12-13 03:53:44 --> Language Class Initialized
INFO - 2021-12-13 03:53:44 --> Language Class Initialized
INFO - 2021-12-13 03:53:44 --> Config Class Initialized
INFO - 2021-12-13 03:53:44 --> Loader Class Initialized
INFO - 2021-12-13 03:53:44 --> Helper loaded: url_helper
INFO - 2021-12-13 03:53:44 --> Helper loaded: file_helper
INFO - 2021-12-13 03:53:44 --> Helper loaded: form_helper
INFO - 2021-12-13 03:53:44 --> Helper loaded: my_helper
INFO - 2021-12-13 03:53:44 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:53:44 --> Controller Class Initialized
DEBUG - 2021-12-13 03:53:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-12-13 03:53:44 --> Final output sent to browser
DEBUG - 2021-12-13 03:53:44 --> Total execution time: 0.1580
INFO - 2021-12-13 03:53:45 --> Config Class Initialized
INFO - 2021-12-13 03:53:45 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:53:45 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:53:45 --> Utf8 Class Initialized
INFO - 2021-12-13 03:53:45 --> URI Class Initialized
INFO - 2021-12-13 03:53:45 --> Router Class Initialized
INFO - 2021-12-13 03:53:45 --> Output Class Initialized
INFO - 2021-12-13 03:53:45 --> Security Class Initialized
DEBUG - 2021-12-13 03:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:53:45 --> Input Class Initialized
INFO - 2021-12-13 03:53:45 --> Language Class Initialized
INFO - 2021-12-13 03:53:45 --> Language Class Initialized
INFO - 2021-12-13 03:53:45 --> Config Class Initialized
INFO - 2021-12-13 03:53:45 --> Loader Class Initialized
INFO - 2021-12-13 03:53:45 --> Helper loaded: url_helper
INFO - 2021-12-13 03:53:45 --> Helper loaded: file_helper
INFO - 2021-12-13 03:53:45 --> Helper loaded: form_helper
INFO - 2021-12-13 03:53:45 --> Helper loaded: my_helper
INFO - 2021-12-13 03:53:45 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:53:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:53:45 --> Controller Class Initialized
DEBUG - 2021-12-13 03:53:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-12-13 03:53:46 --> Final output sent to browser
DEBUG - 2021-12-13 03:53:46 --> Total execution time: 0.1330
INFO - 2021-12-13 03:53:47 --> Config Class Initialized
INFO - 2021-12-13 03:53:47 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:53:47 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:53:47 --> Utf8 Class Initialized
INFO - 2021-12-13 03:53:47 --> URI Class Initialized
INFO - 2021-12-13 03:53:47 --> Router Class Initialized
INFO - 2021-12-13 03:53:47 --> Output Class Initialized
INFO - 2021-12-13 03:53:47 --> Security Class Initialized
DEBUG - 2021-12-13 03:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:53:47 --> Input Class Initialized
INFO - 2021-12-13 03:53:47 --> Language Class Initialized
INFO - 2021-12-13 03:53:47 --> Language Class Initialized
INFO - 2021-12-13 03:53:47 --> Config Class Initialized
INFO - 2021-12-13 03:53:47 --> Loader Class Initialized
INFO - 2021-12-13 03:53:47 --> Helper loaded: url_helper
INFO - 2021-12-13 03:53:47 --> Helper loaded: file_helper
INFO - 2021-12-13 03:53:47 --> Helper loaded: form_helper
INFO - 2021-12-13 03:53:47 --> Helper loaded: my_helper
INFO - 2021-12-13 03:53:47 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:53:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:53:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:53:47 --> Controller Class Initialized
DEBUG - 2021-12-13 03:53:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-12-13 03:53:48 --> Final output sent to browser
DEBUG - 2021-12-13 03:53:48 --> Total execution time: 0.1180
INFO - 2021-12-13 03:54:49 --> Config Class Initialized
INFO - 2021-12-13 03:54:49 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:54:49 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:54:49 --> Utf8 Class Initialized
INFO - 2021-12-13 03:54:49 --> URI Class Initialized
INFO - 2021-12-13 03:54:49 --> Router Class Initialized
INFO - 2021-12-13 03:54:49 --> Output Class Initialized
INFO - 2021-12-13 03:54:49 --> Security Class Initialized
DEBUG - 2021-12-13 03:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:54:49 --> Input Class Initialized
INFO - 2021-12-13 03:54:49 --> Language Class Initialized
INFO - 2021-12-13 03:54:49 --> Language Class Initialized
INFO - 2021-12-13 03:54:49 --> Config Class Initialized
INFO - 2021-12-13 03:54:49 --> Loader Class Initialized
INFO - 2021-12-13 03:54:49 --> Helper loaded: url_helper
INFO - 2021-12-13 03:54:49 --> Helper loaded: file_helper
INFO - 2021-12-13 03:54:49 --> Helper loaded: form_helper
INFO - 2021-12-13 03:54:49 --> Helper loaded: my_helper
INFO - 2021-12-13 03:54:49 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:54:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:54:49 --> Controller Class Initialized
INFO - 2021-12-13 03:54:49 --> Helper loaded: cookie_helper
INFO - 2021-12-13 03:54:49 --> Config Class Initialized
INFO - 2021-12-13 03:54:49 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:54:49 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:54:49 --> Utf8 Class Initialized
INFO - 2021-12-13 03:54:49 --> URI Class Initialized
INFO - 2021-12-13 03:54:49 --> Router Class Initialized
INFO - 2021-12-13 03:54:49 --> Output Class Initialized
INFO - 2021-12-13 03:54:49 --> Security Class Initialized
DEBUG - 2021-12-13 03:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:54:49 --> Input Class Initialized
INFO - 2021-12-13 03:54:49 --> Language Class Initialized
INFO - 2021-12-13 03:54:49 --> Language Class Initialized
INFO - 2021-12-13 03:54:49 --> Config Class Initialized
INFO - 2021-12-13 03:54:49 --> Loader Class Initialized
INFO - 2021-12-13 03:54:49 --> Helper loaded: url_helper
INFO - 2021-12-13 03:54:49 --> Helper loaded: file_helper
INFO - 2021-12-13 03:54:49 --> Helper loaded: form_helper
INFO - 2021-12-13 03:54:49 --> Helper loaded: my_helper
INFO - 2021-12-13 03:54:49 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:54:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:54:49 --> Controller Class Initialized
DEBUG - 2021-12-13 03:54:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-13 03:54:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 03:54:49 --> Final output sent to browser
DEBUG - 2021-12-13 03:54:49 --> Total execution time: 0.0390
INFO - 2021-12-13 03:54:54 --> Config Class Initialized
INFO - 2021-12-13 03:54:54 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:54:54 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:54:54 --> Utf8 Class Initialized
INFO - 2021-12-13 03:54:54 --> URI Class Initialized
INFO - 2021-12-13 03:54:54 --> Router Class Initialized
INFO - 2021-12-13 03:54:54 --> Output Class Initialized
INFO - 2021-12-13 03:54:54 --> Security Class Initialized
DEBUG - 2021-12-13 03:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:54:54 --> Input Class Initialized
INFO - 2021-12-13 03:54:54 --> Language Class Initialized
INFO - 2021-12-13 03:54:54 --> Language Class Initialized
INFO - 2021-12-13 03:54:54 --> Config Class Initialized
INFO - 2021-12-13 03:54:54 --> Loader Class Initialized
INFO - 2021-12-13 03:54:54 --> Helper loaded: url_helper
INFO - 2021-12-13 03:54:54 --> Helper loaded: file_helper
INFO - 2021-12-13 03:54:54 --> Helper loaded: form_helper
INFO - 2021-12-13 03:54:54 --> Helper loaded: my_helper
INFO - 2021-12-13 03:54:54 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:54:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:54:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:54:54 --> Controller Class Initialized
INFO - 2021-12-13 03:54:54 --> Helper loaded: cookie_helper
INFO - 2021-12-13 03:54:54 --> Final output sent to browser
DEBUG - 2021-12-13 03:54:54 --> Total execution time: 0.0610
INFO - 2021-12-13 03:54:54 --> Config Class Initialized
INFO - 2021-12-13 03:54:54 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:54:54 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:54:54 --> Utf8 Class Initialized
INFO - 2021-12-13 03:54:54 --> URI Class Initialized
INFO - 2021-12-13 03:54:54 --> Router Class Initialized
INFO - 2021-12-13 03:54:54 --> Output Class Initialized
INFO - 2021-12-13 03:54:54 --> Security Class Initialized
DEBUG - 2021-12-13 03:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:54:54 --> Input Class Initialized
INFO - 2021-12-13 03:54:54 --> Language Class Initialized
INFO - 2021-12-13 03:54:54 --> Language Class Initialized
INFO - 2021-12-13 03:54:54 --> Config Class Initialized
INFO - 2021-12-13 03:54:54 --> Loader Class Initialized
INFO - 2021-12-13 03:54:54 --> Helper loaded: url_helper
INFO - 2021-12-13 03:54:54 --> Helper loaded: file_helper
INFO - 2021-12-13 03:54:54 --> Helper loaded: form_helper
INFO - 2021-12-13 03:54:54 --> Helper loaded: my_helper
INFO - 2021-12-13 03:54:54 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:54:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:54:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:54:54 --> Controller Class Initialized
DEBUG - 2021-12-13 03:54:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-13 03:54:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 03:54:55 --> Final output sent to browser
DEBUG - 2021-12-13 03:54:55 --> Total execution time: 0.7400
INFO - 2021-12-13 03:55:00 --> Config Class Initialized
INFO - 2021-12-13 03:55:00 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:55:00 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:55:00 --> Utf8 Class Initialized
INFO - 2021-12-13 03:55:00 --> URI Class Initialized
INFO - 2021-12-13 03:55:00 --> Router Class Initialized
INFO - 2021-12-13 03:55:00 --> Output Class Initialized
INFO - 2021-12-13 03:55:00 --> Security Class Initialized
DEBUG - 2021-12-13 03:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:55:00 --> Input Class Initialized
INFO - 2021-12-13 03:55:00 --> Language Class Initialized
INFO - 2021-12-13 03:55:00 --> Language Class Initialized
INFO - 2021-12-13 03:55:00 --> Config Class Initialized
INFO - 2021-12-13 03:55:00 --> Loader Class Initialized
INFO - 2021-12-13 03:55:00 --> Helper loaded: url_helper
INFO - 2021-12-13 03:55:00 --> Helper loaded: file_helper
INFO - 2021-12-13 03:55:00 --> Helper loaded: form_helper
INFO - 2021-12-13 03:55:00 --> Helper loaded: my_helper
INFO - 2021-12-13 03:55:00 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:55:00 --> Controller Class Initialized
DEBUG - 2021-12-13 03:55:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-13 03:55:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 03:55:00 --> Final output sent to browser
DEBUG - 2021-12-13 03:55:00 --> Total execution time: 0.0580
INFO - 2021-12-13 03:55:20 --> Config Class Initialized
INFO - 2021-12-13 03:55:20 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:55:20 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:55:20 --> Utf8 Class Initialized
INFO - 2021-12-13 03:55:20 --> URI Class Initialized
INFO - 2021-12-13 03:55:20 --> Router Class Initialized
INFO - 2021-12-13 03:55:20 --> Output Class Initialized
INFO - 2021-12-13 03:55:20 --> Security Class Initialized
DEBUG - 2021-12-13 03:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:55:20 --> Input Class Initialized
INFO - 2021-12-13 03:55:20 --> Language Class Initialized
INFO - 2021-12-13 03:55:20 --> Language Class Initialized
INFO - 2021-12-13 03:55:20 --> Config Class Initialized
INFO - 2021-12-13 03:55:20 --> Loader Class Initialized
INFO - 2021-12-13 03:55:20 --> Helper loaded: url_helper
INFO - 2021-12-13 03:55:20 --> Helper loaded: file_helper
INFO - 2021-12-13 03:55:20 --> Helper loaded: form_helper
INFO - 2021-12-13 03:55:20 --> Helper loaded: my_helper
INFO - 2021-12-13 03:55:20 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:55:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:55:20 --> Controller Class Initialized
DEBUG - 2021-12-13 03:55:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-13 03:55:20 --> Final output sent to browser
DEBUG - 2021-12-13 03:55:20 --> Total execution time: 0.1940
INFO - 2021-12-13 03:55:26 --> Config Class Initialized
INFO - 2021-12-13 03:55:26 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:55:26 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:55:26 --> Utf8 Class Initialized
INFO - 2021-12-13 03:55:26 --> URI Class Initialized
INFO - 2021-12-13 03:55:26 --> Router Class Initialized
INFO - 2021-12-13 03:55:26 --> Output Class Initialized
INFO - 2021-12-13 03:55:26 --> Security Class Initialized
DEBUG - 2021-12-13 03:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:55:26 --> Input Class Initialized
INFO - 2021-12-13 03:55:26 --> Language Class Initialized
INFO - 2021-12-13 03:55:26 --> Language Class Initialized
INFO - 2021-12-13 03:55:26 --> Config Class Initialized
INFO - 2021-12-13 03:55:26 --> Loader Class Initialized
INFO - 2021-12-13 03:55:26 --> Helper loaded: url_helper
INFO - 2021-12-13 03:55:26 --> Helper loaded: file_helper
INFO - 2021-12-13 03:55:26 --> Helper loaded: form_helper
INFO - 2021-12-13 03:55:26 --> Helper loaded: my_helper
INFO - 2021-12-13 03:55:26 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:55:26 --> Controller Class Initialized
DEBUG - 2021-12-13 03:55:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-13 03:55:26 --> Final output sent to browser
DEBUG - 2021-12-13 03:55:26 --> Total execution time: 0.1510
INFO - 2021-12-13 03:55:30 --> Config Class Initialized
INFO - 2021-12-13 03:55:30 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:55:30 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:55:30 --> Utf8 Class Initialized
INFO - 2021-12-13 03:55:30 --> URI Class Initialized
INFO - 2021-12-13 03:55:30 --> Router Class Initialized
INFO - 2021-12-13 03:55:30 --> Output Class Initialized
INFO - 2021-12-13 03:55:30 --> Security Class Initialized
DEBUG - 2021-12-13 03:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:55:30 --> Input Class Initialized
INFO - 2021-12-13 03:55:30 --> Language Class Initialized
INFO - 2021-12-13 03:55:30 --> Language Class Initialized
INFO - 2021-12-13 03:55:30 --> Config Class Initialized
INFO - 2021-12-13 03:55:30 --> Loader Class Initialized
INFO - 2021-12-13 03:55:30 --> Helper loaded: url_helper
INFO - 2021-12-13 03:55:30 --> Helper loaded: file_helper
INFO - 2021-12-13 03:55:30 --> Helper loaded: form_helper
INFO - 2021-12-13 03:55:30 --> Helper loaded: my_helper
INFO - 2021-12-13 03:55:30 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:55:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:55:30 --> Controller Class Initialized
DEBUG - 2021-12-13 03:55:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-13 03:55:30 --> Final output sent to browser
DEBUG - 2021-12-13 03:55:30 --> Total execution time: 0.1230
INFO - 2021-12-13 03:55:31 --> Config Class Initialized
INFO - 2021-12-13 03:55:31 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:55:31 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:55:31 --> Utf8 Class Initialized
INFO - 2021-12-13 03:55:31 --> URI Class Initialized
INFO - 2021-12-13 03:55:31 --> Router Class Initialized
INFO - 2021-12-13 03:55:31 --> Output Class Initialized
INFO - 2021-12-13 03:55:31 --> Security Class Initialized
DEBUG - 2021-12-13 03:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:55:31 --> Input Class Initialized
INFO - 2021-12-13 03:55:31 --> Language Class Initialized
INFO - 2021-12-13 03:55:31 --> Language Class Initialized
INFO - 2021-12-13 03:55:31 --> Config Class Initialized
INFO - 2021-12-13 03:55:31 --> Loader Class Initialized
INFO - 2021-12-13 03:55:31 --> Helper loaded: url_helper
INFO - 2021-12-13 03:55:31 --> Helper loaded: file_helper
INFO - 2021-12-13 03:55:31 --> Helper loaded: form_helper
INFO - 2021-12-13 03:55:31 --> Helper loaded: my_helper
INFO - 2021-12-13 03:55:31 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:55:31 --> Controller Class Initialized
DEBUG - 2021-12-13 03:55:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-13 03:55:32 --> Final output sent to browser
DEBUG - 2021-12-13 03:55:32 --> Total execution time: 0.1380
INFO - 2021-12-13 03:55:34 --> Config Class Initialized
INFO - 2021-12-13 03:55:34 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:55:34 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:55:34 --> Utf8 Class Initialized
INFO - 2021-12-13 03:55:34 --> URI Class Initialized
INFO - 2021-12-13 03:55:34 --> Router Class Initialized
INFO - 2021-12-13 03:55:34 --> Output Class Initialized
INFO - 2021-12-13 03:55:34 --> Security Class Initialized
DEBUG - 2021-12-13 03:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:55:34 --> Input Class Initialized
INFO - 2021-12-13 03:55:34 --> Language Class Initialized
INFO - 2021-12-13 03:55:34 --> Language Class Initialized
INFO - 2021-12-13 03:55:34 --> Config Class Initialized
INFO - 2021-12-13 03:55:34 --> Loader Class Initialized
INFO - 2021-12-13 03:55:34 --> Helper loaded: url_helper
INFO - 2021-12-13 03:55:34 --> Helper loaded: file_helper
INFO - 2021-12-13 03:55:34 --> Helper loaded: form_helper
INFO - 2021-12-13 03:55:34 --> Helper loaded: my_helper
INFO - 2021-12-13 03:55:34 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:55:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:55:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:55:34 --> Controller Class Initialized
DEBUG - 2021-12-13 03:55:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-13 03:55:34 --> Final output sent to browser
DEBUG - 2021-12-13 03:55:34 --> Total execution time: 0.1180
INFO - 2021-12-13 03:55:35 --> Config Class Initialized
INFO - 2021-12-13 03:55:35 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:55:35 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:55:35 --> Utf8 Class Initialized
INFO - 2021-12-13 03:55:35 --> URI Class Initialized
INFO - 2021-12-13 03:55:35 --> Router Class Initialized
INFO - 2021-12-13 03:55:35 --> Output Class Initialized
INFO - 2021-12-13 03:55:35 --> Security Class Initialized
DEBUG - 2021-12-13 03:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:55:35 --> Input Class Initialized
INFO - 2021-12-13 03:55:35 --> Language Class Initialized
INFO - 2021-12-13 03:55:35 --> Language Class Initialized
INFO - 2021-12-13 03:55:35 --> Config Class Initialized
INFO - 2021-12-13 03:55:35 --> Loader Class Initialized
INFO - 2021-12-13 03:55:35 --> Helper loaded: url_helper
INFO - 2021-12-13 03:55:35 --> Helper loaded: file_helper
INFO - 2021-12-13 03:55:35 --> Helper loaded: form_helper
INFO - 2021-12-13 03:55:35 --> Helper loaded: my_helper
INFO - 2021-12-13 03:55:35 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:55:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:55:35 --> Controller Class Initialized
DEBUG - 2021-12-13 03:55:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-13 03:55:35 --> Final output sent to browser
DEBUG - 2021-12-13 03:55:35 --> Total execution time: 0.1140
INFO - 2021-12-13 03:55:37 --> Config Class Initialized
INFO - 2021-12-13 03:55:37 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:55:37 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:55:37 --> Utf8 Class Initialized
INFO - 2021-12-13 03:55:37 --> URI Class Initialized
INFO - 2021-12-13 03:55:37 --> Router Class Initialized
INFO - 2021-12-13 03:55:37 --> Output Class Initialized
INFO - 2021-12-13 03:55:37 --> Security Class Initialized
DEBUG - 2021-12-13 03:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:55:37 --> Input Class Initialized
INFO - 2021-12-13 03:55:37 --> Language Class Initialized
INFO - 2021-12-13 03:55:37 --> Language Class Initialized
INFO - 2021-12-13 03:55:37 --> Config Class Initialized
INFO - 2021-12-13 03:55:37 --> Loader Class Initialized
INFO - 2021-12-13 03:55:37 --> Helper loaded: url_helper
INFO - 2021-12-13 03:55:37 --> Helper loaded: file_helper
INFO - 2021-12-13 03:55:37 --> Helper loaded: form_helper
INFO - 2021-12-13 03:55:37 --> Helper loaded: my_helper
INFO - 2021-12-13 03:55:37 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:55:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:55:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:55:37 --> Controller Class Initialized
DEBUG - 2021-12-13 03:55:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-13 03:55:37 --> Final output sent to browser
DEBUG - 2021-12-13 03:55:37 --> Total execution time: 0.1240
INFO - 2021-12-13 03:55:39 --> Config Class Initialized
INFO - 2021-12-13 03:55:39 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:55:39 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:55:39 --> Utf8 Class Initialized
INFO - 2021-12-13 03:55:39 --> URI Class Initialized
INFO - 2021-12-13 03:55:39 --> Router Class Initialized
INFO - 2021-12-13 03:55:39 --> Output Class Initialized
INFO - 2021-12-13 03:55:39 --> Security Class Initialized
DEBUG - 2021-12-13 03:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:55:39 --> Input Class Initialized
INFO - 2021-12-13 03:55:39 --> Language Class Initialized
INFO - 2021-12-13 03:55:39 --> Language Class Initialized
INFO - 2021-12-13 03:55:39 --> Config Class Initialized
INFO - 2021-12-13 03:55:39 --> Loader Class Initialized
INFO - 2021-12-13 03:55:39 --> Helper loaded: url_helper
INFO - 2021-12-13 03:55:39 --> Helper loaded: file_helper
INFO - 2021-12-13 03:55:39 --> Helper loaded: form_helper
INFO - 2021-12-13 03:55:39 --> Helper loaded: my_helper
INFO - 2021-12-13 03:55:39 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:55:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:55:39 --> Controller Class Initialized
DEBUG - 2021-12-13 03:55:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-13 03:55:39 --> Final output sent to browser
DEBUG - 2021-12-13 03:55:39 --> Total execution time: 0.1250
INFO - 2021-12-13 03:55:40 --> Config Class Initialized
INFO - 2021-12-13 03:55:40 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:55:40 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:55:40 --> Utf8 Class Initialized
INFO - 2021-12-13 03:55:40 --> URI Class Initialized
INFO - 2021-12-13 03:55:40 --> Router Class Initialized
INFO - 2021-12-13 03:55:40 --> Output Class Initialized
INFO - 2021-12-13 03:55:40 --> Security Class Initialized
DEBUG - 2021-12-13 03:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:55:40 --> Input Class Initialized
INFO - 2021-12-13 03:55:40 --> Language Class Initialized
INFO - 2021-12-13 03:55:40 --> Language Class Initialized
INFO - 2021-12-13 03:55:40 --> Config Class Initialized
INFO - 2021-12-13 03:55:40 --> Loader Class Initialized
INFO - 2021-12-13 03:55:40 --> Helper loaded: url_helper
INFO - 2021-12-13 03:55:40 --> Helper loaded: file_helper
INFO - 2021-12-13 03:55:40 --> Helper loaded: form_helper
INFO - 2021-12-13 03:55:40 --> Helper loaded: my_helper
INFO - 2021-12-13 03:55:40 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:55:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:55:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:55:40 --> Controller Class Initialized
DEBUG - 2021-12-13 03:55:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-13 03:55:40 --> Final output sent to browser
DEBUG - 2021-12-13 03:55:40 --> Total execution time: 0.1280
INFO - 2021-12-13 03:55:43 --> Config Class Initialized
INFO - 2021-12-13 03:55:43 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:55:43 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:55:43 --> Utf8 Class Initialized
INFO - 2021-12-13 03:55:43 --> URI Class Initialized
INFO - 2021-12-13 03:55:43 --> Router Class Initialized
INFO - 2021-12-13 03:55:43 --> Output Class Initialized
INFO - 2021-12-13 03:55:43 --> Security Class Initialized
DEBUG - 2021-12-13 03:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:55:43 --> Input Class Initialized
INFO - 2021-12-13 03:55:43 --> Language Class Initialized
INFO - 2021-12-13 03:55:43 --> Language Class Initialized
INFO - 2021-12-13 03:55:43 --> Config Class Initialized
INFO - 2021-12-13 03:55:43 --> Loader Class Initialized
INFO - 2021-12-13 03:55:43 --> Helper loaded: url_helper
INFO - 2021-12-13 03:55:43 --> Helper loaded: file_helper
INFO - 2021-12-13 03:55:43 --> Helper loaded: form_helper
INFO - 2021-12-13 03:55:43 --> Helper loaded: my_helper
INFO - 2021-12-13 03:55:43 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:55:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:55:43 --> Controller Class Initialized
DEBUG - 2021-12-13 03:55:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-13 03:55:43 --> Final output sent to browser
DEBUG - 2021-12-13 03:55:43 --> Total execution time: 0.1250
INFO - 2021-12-13 03:55:45 --> Config Class Initialized
INFO - 2021-12-13 03:55:45 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:55:45 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:55:45 --> Utf8 Class Initialized
INFO - 2021-12-13 03:55:45 --> URI Class Initialized
INFO - 2021-12-13 03:55:45 --> Router Class Initialized
INFO - 2021-12-13 03:55:45 --> Output Class Initialized
INFO - 2021-12-13 03:55:45 --> Security Class Initialized
DEBUG - 2021-12-13 03:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:55:45 --> Input Class Initialized
INFO - 2021-12-13 03:55:45 --> Language Class Initialized
INFO - 2021-12-13 03:55:45 --> Language Class Initialized
INFO - 2021-12-13 03:55:45 --> Config Class Initialized
INFO - 2021-12-13 03:55:45 --> Loader Class Initialized
INFO - 2021-12-13 03:55:45 --> Helper loaded: url_helper
INFO - 2021-12-13 03:55:45 --> Helper loaded: file_helper
INFO - 2021-12-13 03:55:45 --> Helper loaded: form_helper
INFO - 2021-12-13 03:55:45 --> Helper loaded: my_helper
INFO - 2021-12-13 03:55:45 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:55:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:55:45 --> Controller Class Initialized
DEBUG - 2021-12-13 03:55:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-13 03:55:45 --> Final output sent to browser
DEBUG - 2021-12-13 03:55:45 --> Total execution time: 0.1380
INFO - 2021-12-13 03:55:47 --> Config Class Initialized
INFO - 2021-12-13 03:55:47 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:55:47 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:55:47 --> Utf8 Class Initialized
INFO - 2021-12-13 03:55:47 --> URI Class Initialized
INFO - 2021-12-13 03:55:47 --> Router Class Initialized
INFO - 2021-12-13 03:55:47 --> Output Class Initialized
INFO - 2021-12-13 03:55:47 --> Security Class Initialized
DEBUG - 2021-12-13 03:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:55:47 --> Input Class Initialized
INFO - 2021-12-13 03:55:47 --> Language Class Initialized
INFO - 2021-12-13 03:55:47 --> Language Class Initialized
INFO - 2021-12-13 03:55:47 --> Config Class Initialized
INFO - 2021-12-13 03:55:47 --> Loader Class Initialized
INFO - 2021-12-13 03:55:47 --> Helper loaded: url_helper
INFO - 2021-12-13 03:55:47 --> Helper loaded: file_helper
INFO - 2021-12-13 03:55:47 --> Helper loaded: form_helper
INFO - 2021-12-13 03:55:47 --> Helper loaded: my_helper
INFO - 2021-12-13 03:55:47 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:55:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:55:47 --> Controller Class Initialized
DEBUG - 2021-12-13 03:55:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-13 03:55:47 --> Final output sent to browser
DEBUG - 2021-12-13 03:55:47 --> Total execution time: 0.1280
INFO - 2021-12-13 03:55:50 --> Config Class Initialized
INFO - 2021-12-13 03:55:50 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:55:50 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:55:50 --> Utf8 Class Initialized
INFO - 2021-12-13 03:55:50 --> URI Class Initialized
INFO - 2021-12-13 03:55:50 --> Router Class Initialized
INFO - 2021-12-13 03:55:50 --> Output Class Initialized
INFO - 2021-12-13 03:55:50 --> Security Class Initialized
DEBUG - 2021-12-13 03:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:55:50 --> Input Class Initialized
INFO - 2021-12-13 03:55:50 --> Language Class Initialized
INFO - 2021-12-13 03:55:50 --> Language Class Initialized
INFO - 2021-12-13 03:55:50 --> Config Class Initialized
INFO - 2021-12-13 03:55:50 --> Loader Class Initialized
INFO - 2021-12-13 03:55:50 --> Helper loaded: url_helper
INFO - 2021-12-13 03:55:50 --> Helper loaded: file_helper
INFO - 2021-12-13 03:55:50 --> Helper loaded: form_helper
INFO - 2021-12-13 03:55:50 --> Helper loaded: my_helper
INFO - 2021-12-13 03:55:50 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:55:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:55:50 --> Controller Class Initialized
DEBUG - 2021-12-13 03:55:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-13 03:55:50 --> Final output sent to browser
DEBUG - 2021-12-13 03:55:50 --> Total execution time: 0.1280
INFO - 2021-12-13 03:55:51 --> Config Class Initialized
INFO - 2021-12-13 03:55:51 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:55:51 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:55:51 --> Utf8 Class Initialized
INFO - 2021-12-13 03:55:51 --> URI Class Initialized
INFO - 2021-12-13 03:55:51 --> Router Class Initialized
INFO - 2021-12-13 03:55:51 --> Output Class Initialized
INFO - 2021-12-13 03:55:51 --> Security Class Initialized
DEBUG - 2021-12-13 03:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:55:51 --> Input Class Initialized
INFO - 2021-12-13 03:55:51 --> Language Class Initialized
INFO - 2021-12-13 03:55:51 --> Language Class Initialized
INFO - 2021-12-13 03:55:51 --> Config Class Initialized
INFO - 2021-12-13 03:55:51 --> Loader Class Initialized
INFO - 2021-12-13 03:55:51 --> Helper loaded: url_helper
INFO - 2021-12-13 03:55:51 --> Helper loaded: file_helper
INFO - 2021-12-13 03:55:51 --> Helper loaded: form_helper
INFO - 2021-12-13 03:55:51 --> Helper loaded: my_helper
INFO - 2021-12-13 03:55:51 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:55:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:55:51 --> Controller Class Initialized
DEBUG - 2021-12-13 03:55:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-13 03:55:51 --> Final output sent to browser
DEBUG - 2021-12-13 03:55:51 --> Total execution time: 0.1330
INFO - 2021-12-13 03:55:53 --> Config Class Initialized
INFO - 2021-12-13 03:55:53 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:55:53 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:55:53 --> Utf8 Class Initialized
INFO - 2021-12-13 03:55:53 --> URI Class Initialized
INFO - 2021-12-13 03:55:53 --> Router Class Initialized
INFO - 2021-12-13 03:55:53 --> Output Class Initialized
INFO - 2021-12-13 03:55:53 --> Security Class Initialized
DEBUG - 2021-12-13 03:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:55:53 --> Input Class Initialized
INFO - 2021-12-13 03:55:53 --> Language Class Initialized
INFO - 2021-12-13 03:55:53 --> Language Class Initialized
INFO - 2021-12-13 03:55:53 --> Config Class Initialized
INFO - 2021-12-13 03:55:53 --> Loader Class Initialized
INFO - 2021-12-13 03:55:53 --> Helper loaded: url_helper
INFO - 2021-12-13 03:55:53 --> Helper loaded: file_helper
INFO - 2021-12-13 03:55:53 --> Helper loaded: form_helper
INFO - 2021-12-13 03:55:53 --> Helper loaded: my_helper
INFO - 2021-12-13 03:55:53 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:55:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:55:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:55:53 --> Controller Class Initialized
DEBUG - 2021-12-13 03:55:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-13 03:55:53 --> Final output sent to browser
DEBUG - 2021-12-13 03:55:53 --> Total execution time: 0.1270
INFO - 2021-12-13 03:55:55 --> Config Class Initialized
INFO - 2021-12-13 03:55:55 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:55:55 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:55:55 --> Utf8 Class Initialized
INFO - 2021-12-13 03:55:55 --> URI Class Initialized
INFO - 2021-12-13 03:55:55 --> Router Class Initialized
INFO - 2021-12-13 03:55:55 --> Output Class Initialized
INFO - 2021-12-13 03:55:55 --> Security Class Initialized
DEBUG - 2021-12-13 03:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:55:55 --> Input Class Initialized
INFO - 2021-12-13 03:55:55 --> Language Class Initialized
INFO - 2021-12-13 03:55:55 --> Language Class Initialized
INFO - 2021-12-13 03:55:55 --> Config Class Initialized
INFO - 2021-12-13 03:55:55 --> Loader Class Initialized
INFO - 2021-12-13 03:55:55 --> Helper loaded: url_helper
INFO - 2021-12-13 03:55:55 --> Helper loaded: file_helper
INFO - 2021-12-13 03:55:55 --> Helper loaded: form_helper
INFO - 2021-12-13 03:55:55 --> Helper loaded: my_helper
INFO - 2021-12-13 03:55:55 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:55:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:55:55 --> Controller Class Initialized
DEBUG - 2021-12-13 03:55:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-13 03:55:56 --> Final output sent to browser
DEBUG - 2021-12-13 03:55:56 --> Total execution time: 0.1360
INFO - 2021-12-13 03:56:40 --> Config Class Initialized
INFO - 2021-12-13 03:56:40 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:56:40 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:56:40 --> Utf8 Class Initialized
INFO - 2021-12-13 03:56:40 --> URI Class Initialized
INFO - 2021-12-13 03:56:40 --> Router Class Initialized
INFO - 2021-12-13 03:56:40 --> Output Class Initialized
INFO - 2021-12-13 03:56:40 --> Security Class Initialized
DEBUG - 2021-12-13 03:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:56:40 --> Input Class Initialized
INFO - 2021-12-13 03:56:40 --> Language Class Initialized
INFO - 2021-12-13 03:56:40 --> Language Class Initialized
INFO - 2021-12-13 03:56:40 --> Config Class Initialized
INFO - 2021-12-13 03:56:40 --> Loader Class Initialized
INFO - 2021-12-13 03:56:40 --> Helper loaded: url_helper
INFO - 2021-12-13 03:56:40 --> Helper loaded: file_helper
INFO - 2021-12-13 03:56:40 --> Helper loaded: form_helper
INFO - 2021-12-13 03:56:40 --> Helper loaded: my_helper
INFO - 2021-12-13 03:56:40 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:56:40 --> Controller Class Initialized
DEBUG - 2021-12-13 03:56:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-13 03:56:40 --> Final output sent to browser
DEBUG - 2021-12-13 03:56:40 --> Total execution time: 0.1360
INFO - 2021-12-13 03:57:03 --> Config Class Initialized
INFO - 2021-12-13 03:57:03 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:57:03 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:57:03 --> Utf8 Class Initialized
INFO - 2021-12-13 03:57:03 --> URI Class Initialized
INFO - 2021-12-13 03:57:03 --> Router Class Initialized
INFO - 2021-12-13 03:57:03 --> Output Class Initialized
INFO - 2021-12-13 03:57:03 --> Security Class Initialized
DEBUG - 2021-12-13 03:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:57:03 --> Input Class Initialized
INFO - 2021-12-13 03:57:03 --> Language Class Initialized
INFO - 2021-12-13 03:57:03 --> Language Class Initialized
INFO - 2021-12-13 03:57:03 --> Config Class Initialized
INFO - 2021-12-13 03:57:03 --> Loader Class Initialized
INFO - 2021-12-13 03:57:03 --> Helper loaded: url_helper
INFO - 2021-12-13 03:57:03 --> Helper loaded: file_helper
INFO - 2021-12-13 03:57:03 --> Helper loaded: form_helper
INFO - 2021-12-13 03:57:03 --> Helper loaded: my_helper
INFO - 2021-12-13 03:57:03 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:57:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:57:03 --> Controller Class Initialized
DEBUG - 2021-12-13 03:57:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-13 03:57:03 --> Final output sent to browser
DEBUG - 2021-12-13 03:57:03 --> Total execution time: 0.1360
INFO - 2021-12-13 03:59:51 --> Config Class Initialized
INFO - 2021-12-13 03:59:51 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:59:51 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:59:51 --> Utf8 Class Initialized
INFO - 2021-12-13 03:59:51 --> URI Class Initialized
INFO - 2021-12-13 03:59:51 --> Router Class Initialized
INFO - 2021-12-13 03:59:51 --> Output Class Initialized
INFO - 2021-12-13 03:59:51 --> Security Class Initialized
DEBUG - 2021-12-13 03:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:59:51 --> Input Class Initialized
INFO - 2021-12-13 03:59:51 --> Language Class Initialized
INFO - 2021-12-13 03:59:51 --> Language Class Initialized
INFO - 2021-12-13 03:59:51 --> Config Class Initialized
INFO - 2021-12-13 03:59:51 --> Loader Class Initialized
INFO - 2021-12-13 03:59:51 --> Helper loaded: url_helper
INFO - 2021-12-13 03:59:51 --> Helper loaded: file_helper
INFO - 2021-12-13 03:59:51 --> Helper loaded: form_helper
INFO - 2021-12-13 03:59:51 --> Helper loaded: my_helper
INFO - 2021-12-13 03:59:51 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:59:51 --> Controller Class Initialized
INFO - 2021-12-13 03:59:51 --> Helper loaded: cookie_helper
INFO - 2021-12-13 03:59:51 --> Config Class Initialized
INFO - 2021-12-13 03:59:51 --> Hooks Class Initialized
DEBUG - 2021-12-13 03:59:51 --> UTF-8 Support Enabled
INFO - 2021-12-13 03:59:51 --> Utf8 Class Initialized
INFO - 2021-12-13 03:59:51 --> URI Class Initialized
INFO - 2021-12-13 03:59:51 --> Router Class Initialized
INFO - 2021-12-13 03:59:51 --> Output Class Initialized
INFO - 2021-12-13 03:59:51 --> Security Class Initialized
DEBUG - 2021-12-13 03:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 03:59:51 --> Input Class Initialized
INFO - 2021-12-13 03:59:51 --> Language Class Initialized
INFO - 2021-12-13 03:59:51 --> Language Class Initialized
INFO - 2021-12-13 03:59:51 --> Config Class Initialized
INFO - 2021-12-13 03:59:51 --> Loader Class Initialized
INFO - 2021-12-13 03:59:51 --> Helper loaded: url_helper
INFO - 2021-12-13 03:59:51 --> Helper loaded: file_helper
INFO - 2021-12-13 03:59:51 --> Helper loaded: form_helper
INFO - 2021-12-13 03:59:51 --> Helper loaded: my_helper
INFO - 2021-12-13 03:59:51 --> Database Driver Class Initialized
DEBUG - 2021-12-13 03:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 03:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 03:59:51 --> Controller Class Initialized
DEBUG - 2021-12-13 03:59:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-13 03:59:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-13 03:59:51 --> Final output sent to browser
DEBUG - 2021-12-13 03:59:51 --> Total execution time: 0.0340
