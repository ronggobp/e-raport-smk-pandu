<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-08-11 09:43:48 --> Config Class Initialized
INFO - 2021-08-11 09:43:48 --> Hooks Class Initialized
DEBUG - 2021-08-11 09:43:48 --> UTF-8 Support Enabled
INFO - 2021-08-11 09:43:48 --> Utf8 Class Initialized
INFO - 2021-08-11 09:43:48 --> URI Class Initialized
INFO - 2021-08-11 09:43:48 --> Router Class Initialized
INFO - 2021-08-11 09:43:48 --> Output Class Initialized
INFO - 2021-08-11 09:43:48 --> Security Class Initialized
DEBUG - 2021-08-11 09:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-11 09:43:48 --> Input Class Initialized
INFO - 2021-08-11 09:43:48 --> Language Class Initialized
INFO - 2021-08-11 09:43:48 --> Language Class Initialized
INFO - 2021-08-11 09:43:48 --> Config Class Initialized
INFO - 2021-08-11 09:43:48 --> Loader Class Initialized
INFO - 2021-08-11 09:43:48 --> Helper loaded: url_helper
INFO - 2021-08-11 09:43:48 --> Helper loaded: file_helper
INFO - 2021-08-11 09:43:48 --> Helper loaded: form_helper
INFO - 2021-08-11 09:43:48 --> Helper loaded: my_helper
INFO - 2021-08-11 09:43:48 --> Database Driver Class Initialized
DEBUG - 2021-08-11 09:43:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-11 09:43:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-11 09:43:48 --> Controller Class Initialized
DEBUG - 2021-08-11 09:43:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-08-11 09:43:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-11 09:43:48 --> Final output sent to browser
DEBUG - 2021-08-11 09:43:48 --> Total execution time: 0.0660
INFO - 2021-08-11 09:43:48 --> Config Class Initialized
INFO - 2021-08-11 09:43:48 --> Hooks Class Initialized
DEBUG - 2021-08-11 09:43:48 --> UTF-8 Support Enabled
INFO - 2021-08-11 09:43:48 --> Utf8 Class Initialized
INFO - 2021-08-11 09:43:48 --> URI Class Initialized
INFO - 2021-08-11 09:43:48 --> Router Class Initialized
INFO - 2021-08-11 09:43:48 --> Output Class Initialized
INFO - 2021-08-11 09:43:48 --> Security Class Initialized
DEBUG - 2021-08-11 09:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-11 09:43:48 --> Input Class Initialized
INFO - 2021-08-11 09:43:48 --> Language Class Initialized
INFO - 2021-08-11 09:43:48 --> Language Class Initialized
INFO - 2021-08-11 09:43:48 --> Config Class Initialized
INFO - 2021-08-11 09:43:48 --> Loader Class Initialized
INFO - 2021-08-11 09:43:48 --> Helper loaded: url_helper
INFO - 2021-08-11 09:43:48 --> Helper loaded: file_helper
INFO - 2021-08-11 09:43:48 --> Helper loaded: form_helper
INFO - 2021-08-11 09:43:48 --> Helper loaded: my_helper
INFO - 2021-08-11 09:43:48 --> Database Driver Class Initialized
DEBUG - 2021-08-11 09:43:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-11 09:43:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-11 09:43:48 --> Controller Class Initialized
INFO - 2021-08-11 09:43:55 --> Config Class Initialized
INFO - 2021-08-11 09:43:55 --> Hooks Class Initialized
DEBUG - 2021-08-11 09:43:55 --> UTF-8 Support Enabled
INFO - 2021-08-11 09:43:55 --> Utf8 Class Initialized
INFO - 2021-08-11 09:43:55 --> URI Class Initialized
INFO - 2021-08-11 09:43:55 --> Router Class Initialized
INFO - 2021-08-11 09:43:55 --> Output Class Initialized
INFO - 2021-08-11 09:43:55 --> Security Class Initialized
DEBUG - 2021-08-11 09:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-11 09:43:55 --> Input Class Initialized
INFO - 2021-08-11 09:43:55 --> Language Class Initialized
INFO - 2021-08-11 09:43:55 --> Language Class Initialized
INFO - 2021-08-11 09:43:55 --> Config Class Initialized
INFO - 2021-08-11 09:43:55 --> Loader Class Initialized
INFO - 2021-08-11 09:43:55 --> Helper loaded: url_helper
INFO - 2021-08-11 09:43:55 --> Helper loaded: file_helper
INFO - 2021-08-11 09:43:55 --> Helper loaded: form_helper
INFO - 2021-08-11 09:43:55 --> Helper loaded: my_helper
INFO - 2021-08-11 09:43:55 --> Database Driver Class Initialized
DEBUG - 2021-08-11 09:43:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-11 09:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-11 09:43:55 --> Controller Class Initialized
ERROR - 2021-08-11 09:43:55 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2021-08-11 09:43:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-08-11 09:43:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-11 09:43:55 --> Final output sent to browser
DEBUG - 2021-08-11 09:43:55 --> Total execution time: 0.1340
INFO - 2021-08-11 09:44:31 --> Config Class Initialized
INFO - 2021-08-11 09:44:31 --> Hooks Class Initialized
DEBUG - 2021-08-11 09:44:31 --> UTF-8 Support Enabled
INFO - 2021-08-11 09:44:31 --> Utf8 Class Initialized
INFO - 2021-08-11 09:44:31 --> URI Class Initialized
INFO - 2021-08-11 09:44:31 --> Router Class Initialized
INFO - 2021-08-11 09:44:31 --> Output Class Initialized
INFO - 2021-08-11 09:44:31 --> Security Class Initialized
DEBUG - 2021-08-11 09:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-11 09:44:31 --> Input Class Initialized
INFO - 2021-08-11 09:44:31 --> Language Class Initialized
INFO - 2021-08-11 09:44:31 --> Language Class Initialized
INFO - 2021-08-11 09:44:31 --> Config Class Initialized
INFO - 2021-08-11 09:44:31 --> Loader Class Initialized
INFO - 2021-08-11 09:44:31 --> Helper loaded: url_helper
INFO - 2021-08-11 09:44:31 --> Helper loaded: file_helper
INFO - 2021-08-11 09:44:31 --> Helper loaded: form_helper
INFO - 2021-08-11 09:44:31 --> Helper loaded: my_helper
INFO - 2021-08-11 09:44:31 --> Database Driver Class Initialized
DEBUG - 2021-08-11 09:44:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-11 09:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-11 09:44:31 --> Controller Class Initialized
INFO - 2021-08-11 09:44:32 --> Upload Class Initialized
INFO - 2021-08-11 09:44:32 --> Language file loaded: language/english/upload_lang.php
ERROR - 2021-08-11 09:44:32 --> The upload path does not appear to be valid.
INFO - 2021-08-11 09:44:32 --> Config Class Initialized
INFO - 2021-08-11 09:44:32 --> Hooks Class Initialized
DEBUG - 2021-08-11 09:44:32 --> UTF-8 Support Enabled
INFO - 2021-08-11 09:44:32 --> Utf8 Class Initialized
INFO - 2021-08-11 09:44:32 --> URI Class Initialized
INFO - 2021-08-11 09:44:32 --> Router Class Initialized
INFO - 2021-08-11 09:44:32 --> Output Class Initialized
INFO - 2021-08-11 09:44:32 --> Security Class Initialized
DEBUG - 2021-08-11 09:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-11 09:44:32 --> Input Class Initialized
INFO - 2021-08-11 09:44:32 --> Language Class Initialized
INFO - 2021-08-11 09:44:32 --> Language Class Initialized
INFO - 2021-08-11 09:44:32 --> Config Class Initialized
INFO - 2021-08-11 09:44:32 --> Loader Class Initialized
INFO - 2021-08-11 09:44:32 --> Helper loaded: url_helper
INFO - 2021-08-11 09:44:32 --> Helper loaded: file_helper
INFO - 2021-08-11 09:44:32 --> Helper loaded: form_helper
INFO - 2021-08-11 09:44:32 --> Helper loaded: my_helper
INFO - 2021-08-11 09:44:32 --> Database Driver Class Initialized
DEBUG - 2021-08-11 09:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-11 09:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-11 09:44:32 --> Controller Class Initialized
DEBUG - 2021-08-11 09:44:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-08-11 09:44:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-11 09:44:32 --> Final output sent to browser
DEBUG - 2021-08-11 09:44:32 --> Total execution time: 0.0864
INFO - 2021-08-11 09:44:32 --> Config Class Initialized
INFO - 2021-08-11 09:44:32 --> Hooks Class Initialized
DEBUG - 2021-08-11 09:44:32 --> UTF-8 Support Enabled
INFO - 2021-08-11 09:44:32 --> Utf8 Class Initialized
INFO - 2021-08-11 09:44:32 --> URI Class Initialized
INFO - 2021-08-11 09:44:32 --> Router Class Initialized
INFO - 2021-08-11 09:44:32 --> Output Class Initialized
INFO - 2021-08-11 09:44:32 --> Security Class Initialized
DEBUG - 2021-08-11 09:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-11 09:44:32 --> Input Class Initialized
INFO - 2021-08-11 09:44:32 --> Language Class Initialized
INFO - 2021-08-11 09:44:32 --> Language Class Initialized
INFO - 2021-08-11 09:44:32 --> Config Class Initialized
INFO - 2021-08-11 09:44:32 --> Loader Class Initialized
INFO - 2021-08-11 09:44:32 --> Helper loaded: url_helper
INFO - 2021-08-11 09:44:32 --> Helper loaded: file_helper
INFO - 2021-08-11 09:44:32 --> Helper loaded: form_helper
INFO - 2021-08-11 09:44:32 --> Helper loaded: my_helper
INFO - 2021-08-11 09:44:32 --> Database Driver Class Initialized
DEBUG - 2021-08-11 09:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-11 09:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-11 09:44:32 --> Controller Class Initialized
INFO - 2021-08-11 09:44:35 --> Config Class Initialized
INFO - 2021-08-11 09:44:35 --> Hooks Class Initialized
DEBUG - 2021-08-11 09:44:35 --> UTF-8 Support Enabled
INFO - 2021-08-11 09:44:35 --> Utf8 Class Initialized
INFO - 2021-08-11 09:44:35 --> URI Class Initialized
INFO - 2021-08-11 09:44:35 --> Router Class Initialized
INFO - 2021-08-11 09:44:35 --> Output Class Initialized
INFO - 2021-08-11 09:44:35 --> Security Class Initialized
DEBUG - 2021-08-11 09:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-11 09:44:35 --> Input Class Initialized
INFO - 2021-08-11 09:44:35 --> Language Class Initialized
INFO - 2021-08-11 09:44:35 --> Language Class Initialized
INFO - 2021-08-11 09:44:35 --> Config Class Initialized
INFO - 2021-08-11 09:44:35 --> Loader Class Initialized
INFO - 2021-08-11 09:44:35 --> Helper loaded: url_helper
INFO - 2021-08-11 09:44:35 --> Helper loaded: file_helper
INFO - 2021-08-11 09:44:35 --> Helper loaded: form_helper
INFO - 2021-08-11 09:44:35 --> Helper loaded: my_helper
INFO - 2021-08-11 09:44:35 --> Database Driver Class Initialized
DEBUG - 2021-08-11 09:44:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-11 09:44:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-11 09:44:35 --> Controller Class Initialized
DEBUG - 2021-08-11 09:44:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-08-11 09:44:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-11 09:44:35 --> Final output sent to browser
DEBUG - 2021-08-11 09:44:35 --> Total execution time: 0.0858
INFO - 2021-08-11 09:44:36 --> Config Class Initialized
INFO - 2021-08-11 09:44:36 --> Hooks Class Initialized
DEBUG - 2021-08-11 09:44:36 --> UTF-8 Support Enabled
INFO - 2021-08-11 09:44:36 --> Utf8 Class Initialized
INFO - 2021-08-11 09:44:36 --> URI Class Initialized
INFO - 2021-08-11 09:44:36 --> Router Class Initialized
INFO - 2021-08-11 09:44:36 --> Output Class Initialized
INFO - 2021-08-11 09:44:36 --> Security Class Initialized
DEBUG - 2021-08-11 09:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-11 09:44:36 --> Input Class Initialized
INFO - 2021-08-11 09:44:36 --> Language Class Initialized
INFO - 2021-08-11 09:44:36 --> Language Class Initialized
INFO - 2021-08-11 09:44:36 --> Config Class Initialized
INFO - 2021-08-11 09:44:36 --> Loader Class Initialized
INFO - 2021-08-11 09:44:36 --> Helper loaded: url_helper
INFO - 2021-08-11 09:44:36 --> Helper loaded: file_helper
INFO - 2021-08-11 09:44:36 --> Helper loaded: form_helper
INFO - 2021-08-11 09:44:36 --> Helper loaded: my_helper
INFO - 2021-08-11 09:44:36 --> Database Driver Class Initialized
DEBUG - 2021-08-11 09:44:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-11 09:44:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-11 09:44:36 --> Controller Class Initialized
DEBUG - 2021-08-11 09:44:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-08-11 09:44:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-11 09:44:36 --> Final output sent to browser
DEBUG - 2021-08-11 09:44:36 --> Total execution time: 0.0920
INFO - 2021-08-11 09:44:41 --> Config Class Initialized
INFO - 2021-08-11 09:44:41 --> Hooks Class Initialized
DEBUG - 2021-08-11 09:44:41 --> UTF-8 Support Enabled
INFO - 2021-08-11 09:44:41 --> Utf8 Class Initialized
INFO - 2021-08-11 09:44:41 --> URI Class Initialized
INFO - 2021-08-11 09:44:41 --> Router Class Initialized
INFO - 2021-08-11 09:44:41 --> Output Class Initialized
INFO - 2021-08-11 09:44:41 --> Security Class Initialized
DEBUG - 2021-08-11 09:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-11 09:44:41 --> Input Class Initialized
INFO - 2021-08-11 09:44:41 --> Language Class Initialized
INFO - 2021-08-11 09:44:41 --> Language Class Initialized
INFO - 2021-08-11 09:44:41 --> Config Class Initialized
INFO - 2021-08-11 09:44:41 --> Loader Class Initialized
INFO - 2021-08-11 09:44:41 --> Helper loaded: url_helper
INFO - 2021-08-11 09:44:41 --> Helper loaded: file_helper
INFO - 2021-08-11 09:44:41 --> Helper loaded: form_helper
INFO - 2021-08-11 09:44:41 --> Helper loaded: my_helper
INFO - 2021-08-11 09:44:41 --> Database Driver Class Initialized
DEBUG - 2021-08-11 09:44:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-11 09:44:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-11 09:44:41 --> Controller Class Initialized
INFO - 2021-08-11 09:44:41 --> Config Class Initialized
INFO - 2021-08-11 09:44:41 --> Hooks Class Initialized
DEBUG - 2021-08-11 09:44:41 --> UTF-8 Support Enabled
INFO - 2021-08-11 09:44:41 --> Utf8 Class Initialized
INFO - 2021-08-11 09:44:41 --> URI Class Initialized
INFO - 2021-08-11 09:44:41 --> Router Class Initialized
INFO - 2021-08-11 09:44:41 --> Output Class Initialized
INFO - 2021-08-11 09:44:41 --> Security Class Initialized
DEBUG - 2021-08-11 09:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-11 09:44:41 --> Input Class Initialized
INFO - 2021-08-11 09:44:41 --> Language Class Initialized
INFO - 2021-08-11 09:44:41 --> Language Class Initialized
INFO - 2021-08-11 09:44:41 --> Config Class Initialized
INFO - 2021-08-11 09:44:41 --> Loader Class Initialized
INFO - 2021-08-11 09:44:41 --> Helper loaded: url_helper
INFO - 2021-08-11 09:44:41 --> Helper loaded: file_helper
INFO - 2021-08-11 09:44:41 --> Helper loaded: form_helper
INFO - 2021-08-11 09:44:41 --> Helper loaded: my_helper
INFO - 2021-08-11 09:44:41 --> Database Driver Class Initialized
DEBUG - 2021-08-11 09:44:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-11 09:44:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-11 09:44:41 --> Controller Class Initialized
DEBUG - 2021-08-11 09:44:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-08-11 09:44:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-11 09:44:41 --> Final output sent to browser
DEBUG - 2021-08-11 09:44:41 --> Total execution time: 0.0651
INFO - 2021-08-11 09:44:42 --> Config Class Initialized
INFO - 2021-08-11 09:44:42 --> Hooks Class Initialized
DEBUG - 2021-08-11 09:44:42 --> UTF-8 Support Enabled
INFO - 2021-08-11 09:44:42 --> Utf8 Class Initialized
INFO - 2021-08-11 09:44:42 --> URI Class Initialized
INFO - 2021-08-11 09:44:42 --> Router Class Initialized
INFO - 2021-08-11 09:44:42 --> Output Class Initialized
INFO - 2021-08-11 09:44:42 --> Security Class Initialized
DEBUG - 2021-08-11 09:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-11 09:44:42 --> Input Class Initialized
INFO - 2021-08-11 09:44:42 --> Language Class Initialized
INFO - 2021-08-11 09:44:42 --> Language Class Initialized
INFO - 2021-08-11 09:44:42 --> Config Class Initialized
INFO - 2021-08-11 09:44:42 --> Loader Class Initialized
INFO - 2021-08-11 09:44:42 --> Helper loaded: url_helper
INFO - 2021-08-11 09:44:42 --> Helper loaded: file_helper
INFO - 2021-08-11 09:44:42 --> Helper loaded: form_helper
INFO - 2021-08-11 09:44:42 --> Helper loaded: my_helper
INFO - 2021-08-11 09:44:42 --> Database Driver Class Initialized
DEBUG - 2021-08-11 09:44:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-11 09:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-11 09:44:42 --> Controller Class Initialized
INFO - 2021-08-11 09:44:42 --> Helper loaded: cookie_helper
INFO - 2021-08-11 09:44:42 --> Config Class Initialized
INFO - 2021-08-11 09:44:42 --> Hooks Class Initialized
DEBUG - 2021-08-11 09:44:42 --> UTF-8 Support Enabled
INFO - 2021-08-11 09:44:42 --> Utf8 Class Initialized
INFO - 2021-08-11 09:44:42 --> URI Class Initialized
INFO - 2021-08-11 09:44:42 --> Router Class Initialized
INFO - 2021-08-11 09:44:42 --> Output Class Initialized
INFO - 2021-08-11 09:44:42 --> Security Class Initialized
DEBUG - 2021-08-11 09:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-11 09:44:42 --> Input Class Initialized
INFO - 2021-08-11 09:44:42 --> Language Class Initialized
INFO - 2021-08-11 09:44:42 --> Language Class Initialized
INFO - 2021-08-11 09:44:42 --> Config Class Initialized
INFO - 2021-08-11 09:44:42 --> Loader Class Initialized
INFO - 2021-08-11 09:44:42 --> Helper loaded: url_helper
INFO - 2021-08-11 09:44:42 --> Helper loaded: file_helper
INFO - 2021-08-11 09:44:42 --> Helper loaded: form_helper
INFO - 2021-08-11 09:44:42 --> Helper loaded: my_helper
INFO - 2021-08-11 09:44:42 --> Database Driver Class Initialized
DEBUG - 2021-08-11 09:44:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-11 09:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-11 09:44:42 --> Controller Class Initialized
DEBUG - 2021-08-11 09:44:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-08-11 09:44:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-11 09:44:42 --> Final output sent to browser
DEBUG - 2021-08-11 09:44:42 --> Total execution time: 0.0684
INFO - 2021-08-11 09:44:48 --> Config Class Initialized
INFO - 2021-08-11 09:44:48 --> Hooks Class Initialized
DEBUG - 2021-08-11 09:44:48 --> UTF-8 Support Enabled
INFO - 2021-08-11 09:44:48 --> Utf8 Class Initialized
INFO - 2021-08-11 09:44:48 --> URI Class Initialized
INFO - 2021-08-11 09:44:48 --> Router Class Initialized
INFO - 2021-08-11 09:44:48 --> Output Class Initialized
INFO - 2021-08-11 09:44:48 --> Security Class Initialized
DEBUG - 2021-08-11 09:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-11 09:44:48 --> Input Class Initialized
INFO - 2021-08-11 09:44:48 --> Language Class Initialized
INFO - 2021-08-11 09:44:48 --> Language Class Initialized
INFO - 2021-08-11 09:44:48 --> Config Class Initialized
INFO - 2021-08-11 09:44:48 --> Loader Class Initialized
INFO - 2021-08-11 09:44:48 --> Helper loaded: url_helper
INFO - 2021-08-11 09:44:48 --> Helper loaded: file_helper
INFO - 2021-08-11 09:44:48 --> Helper loaded: form_helper
INFO - 2021-08-11 09:44:48 --> Helper loaded: my_helper
INFO - 2021-08-11 09:44:48 --> Database Driver Class Initialized
DEBUG - 2021-08-11 09:44:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-11 09:44:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-11 09:44:48 --> Controller Class Initialized
INFO - 2021-08-11 09:44:48 --> Helper loaded: cookie_helper
INFO - 2021-08-11 09:44:48 --> Final output sent to browser
DEBUG - 2021-08-11 09:44:48 --> Total execution time: 0.0800
INFO - 2021-08-11 09:44:48 --> Config Class Initialized
INFO - 2021-08-11 09:44:48 --> Hooks Class Initialized
DEBUG - 2021-08-11 09:44:48 --> UTF-8 Support Enabled
INFO - 2021-08-11 09:44:48 --> Utf8 Class Initialized
INFO - 2021-08-11 09:44:48 --> URI Class Initialized
INFO - 2021-08-11 09:44:48 --> Router Class Initialized
INFO - 2021-08-11 09:44:48 --> Output Class Initialized
INFO - 2021-08-11 09:44:48 --> Security Class Initialized
DEBUG - 2021-08-11 09:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-11 09:44:48 --> Input Class Initialized
INFO - 2021-08-11 09:44:48 --> Language Class Initialized
INFO - 2021-08-11 09:44:49 --> Language Class Initialized
INFO - 2021-08-11 09:44:49 --> Config Class Initialized
INFO - 2021-08-11 09:44:49 --> Loader Class Initialized
INFO - 2021-08-11 09:44:49 --> Helper loaded: url_helper
INFO - 2021-08-11 09:44:49 --> Helper loaded: file_helper
INFO - 2021-08-11 09:44:49 --> Helper loaded: form_helper
INFO - 2021-08-11 09:44:49 --> Helper loaded: my_helper
INFO - 2021-08-11 09:44:49 --> Database Driver Class Initialized
DEBUG - 2021-08-11 09:44:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-11 09:44:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-11 09:44:49 --> Controller Class Initialized
DEBUG - 2021-08-11 09:44:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-08-11 09:44:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-11 09:44:49 --> Final output sent to browser
DEBUG - 2021-08-11 09:44:49 --> Total execution time: 0.0988
INFO - 2021-08-11 09:44:51 --> Config Class Initialized
INFO - 2021-08-11 09:44:51 --> Hooks Class Initialized
DEBUG - 2021-08-11 09:44:51 --> UTF-8 Support Enabled
INFO - 2021-08-11 09:44:51 --> Utf8 Class Initialized
INFO - 2021-08-11 09:44:51 --> URI Class Initialized
INFO - 2021-08-11 09:44:51 --> Router Class Initialized
INFO - 2021-08-11 09:44:51 --> Output Class Initialized
INFO - 2021-08-11 09:44:51 --> Security Class Initialized
DEBUG - 2021-08-11 09:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-11 09:44:51 --> Input Class Initialized
INFO - 2021-08-11 09:44:51 --> Language Class Initialized
INFO - 2021-08-11 09:44:51 --> Language Class Initialized
INFO - 2021-08-11 09:44:51 --> Config Class Initialized
INFO - 2021-08-11 09:44:51 --> Loader Class Initialized
INFO - 2021-08-11 09:44:51 --> Helper loaded: url_helper
INFO - 2021-08-11 09:44:51 --> Helper loaded: file_helper
INFO - 2021-08-11 09:44:51 --> Helper loaded: form_helper
INFO - 2021-08-11 09:44:51 --> Helper loaded: my_helper
INFO - 2021-08-11 09:44:51 --> Database Driver Class Initialized
DEBUG - 2021-08-11 09:44:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-11 09:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-11 09:44:51 --> Controller Class Initialized
DEBUG - 2021-08-11 09:44:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-08-11 09:44:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-11 09:44:51 --> Final output sent to browser
DEBUG - 2021-08-11 09:44:51 --> Total execution time: 0.0822
INFO - 2021-08-11 09:44:55 --> Config Class Initialized
INFO - 2021-08-11 09:44:55 --> Hooks Class Initialized
DEBUG - 2021-08-11 09:44:55 --> UTF-8 Support Enabled
INFO - 2021-08-11 09:44:55 --> Utf8 Class Initialized
INFO - 2021-08-11 09:44:55 --> URI Class Initialized
INFO - 2021-08-11 09:44:55 --> Router Class Initialized
INFO - 2021-08-11 09:44:55 --> Output Class Initialized
INFO - 2021-08-11 09:44:55 --> Security Class Initialized
DEBUG - 2021-08-11 09:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-11 09:44:55 --> Input Class Initialized
INFO - 2021-08-11 09:44:55 --> Language Class Initialized
INFO - 2021-08-11 09:44:55 --> Language Class Initialized
INFO - 2021-08-11 09:44:55 --> Config Class Initialized
INFO - 2021-08-11 09:44:55 --> Loader Class Initialized
INFO - 2021-08-11 09:44:55 --> Helper loaded: url_helper
INFO - 2021-08-11 09:44:55 --> Helper loaded: file_helper
INFO - 2021-08-11 09:44:55 --> Helper loaded: form_helper
INFO - 2021-08-11 09:44:55 --> Helper loaded: my_helper
INFO - 2021-08-11 09:44:55 --> Database Driver Class Initialized
DEBUG - 2021-08-11 09:44:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-11 09:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-11 09:44:55 --> Controller Class Initialized
DEBUG - 2021-08-11 09:44:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-08-11 09:44:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-11 09:44:55 --> Final output sent to browser
DEBUG - 2021-08-11 09:44:55 --> Total execution time: 0.0930
INFO - 2021-08-11 09:44:57 --> Config Class Initialized
INFO - 2021-08-11 09:44:57 --> Hooks Class Initialized
DEBUG - 2021-08-11 09:44:57 --> UTF-8 Support Enabled
INFO - 2021-08-11 09:44:57 --> Utf8 Class Initialized
INFO - 2021-08-11 09:44:57 --> URI Class Initialized
INFO - 2021-08-11 09:44:57 --> Router Class Initialized
INFO - 2021-08-11 09:44:57 --> Output Class Initialized
INFO - 2021-08-11 09:44:57 --> Security Class Initialized
DEBUG - 2021-08-11 09:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-11 09:44:57 --> Input Class Initialized
INFO - 2021-08-11 09:44:57 --> Language Class Initialized
INFO - 2021-08-11 09:44:57 --> Language Class Initialized
INFO - 2021-08-11 09:44:57 --> Config Class Initialized
INFO - 2021-08-11 09:44:57 --> Loader Class Initialized
INFO - 2021-08-11 09:44:57 --> Helper loaded: url_helper
INFO - 2021-08-11 09:44:57 --> Helper loaded: file_helper
INFO - 2021-08-11 09:44:57 --> Helper loaded: form_helper
INFO - 2021-08-11 09:44:57 --> Helper loaded: my_helper
INFO - 2021-08-11 09:44:57 --> Database Driver Class Initialized
DEBUG - 2021-08-11 09:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-11 09:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-11 09:44:57 --> Controller Class Initialized
DEBUG - 2021-08-11 09:44:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2021-08-11 09:44:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-11 09:44:57 --> Final output sent to browser
DEBUG - 2021-08-11 09:44:57 --> Total execution time: 0.0923
INFO - 2021-08-11 09:45:00 --> Config Class Initialized
INFO - 2021-08-11 09:45:00 --> Hooks Class Initialized
DEBUG - 2021-08-11 09:45:00 --> UTF-8 Support Enabled
INFO - 2021-08-11 09:45:00 --> Utf8 Class Initialized
INFO - 2021-08-11 09:45:00 --> URI Class Initialized
INFO - 2021-08-11 09:45:00 --> Router Class Initialized
INFO - 2021-08-11 09:45:00 --> Output Class Initialized
INFO - 2021-08-11 09:45:00 --> Security Class Initialized
DEBUG - 2021-08-11 09:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-11 09:45:00 --> Input Class Initialized
INFO - 2021-08-11 09:45:00 --> Language Class Initialized
INFO - 2021-08-11 09:45:01 --> Language Class Initialized
INFO - 2021-08-11 09:45:01 --> Config Class Initialized
INFO - 2021-08-11 09:45:01 --> Loader Class Initialized
INFO - 2021-08-11 09:45:01 --> Helper loaded: url_helper
INFO - 2021-08-11 09:45:01 --> Helper loaded: file_helper
INFO - 2021-08-11 09:45:01 --> Helper loaded: form_helper
INFO - 2021-08-11 09:45:01 --> Helper loaded: my_helper
INFO - 2021-08-11 09:45:01 --> Database Driver Class Initialized
DEBUG - 2021-08-11 09:45:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-11 09:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-11 09:45:01 --> Controller Class Initialized
ERROR - 2021-08-11 09:45:01 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 38
ERROR - 2021-08-11 09:45:01 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 41
ERROR - 2021-08-11 09:45:01 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 45
ERROR - 2021-08-11 09:45:01 --> Severity: Notice --> Undefined index: keterangan C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 50
DEBUG - 2021-08-11 09:45:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-08-11 09:45:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-11 09:45:01 --> Final output sent to browser
DEBUG - 2021-08-11 09:45:01 --> Total execution time: 0.0928
INFO - 2021-08-11 09:45:03 --> Config Class Initialized
INFO - 2021-08-11 09:45:03 --> Hooks Class Initialized
DEBUG - 2021-08-11 09:45:03 --> UTF-8 Support Enabled
INFO - 2021-08-11 09:45:03 --> Utf8 Class Initialized
INFO - 2021-08-11 09:45:03 --> URI Class Initialized
INFO - 2021-08-11 09:45:03 --> Router Class Initialized
INFO - 2021-08-11 09:45:03 --> Output Class Initialized
INFO - 2021-08-11 09:45:03 --> Security Class Initialized
DEBUG - 2021-08-11 09:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-11 09:45:03 --> Input Class Initialized
INFO - 2021-08-11 09:45:03 --> Language Class Initialized
INFO - 2021-08-11 09:45:03 --> Language Class Initialized
INFO - 2021-08-11 09:45:03 --> Config Class Initialized
INFO - 2021-08-11 09:45:03 --> Loader Class Initialized
INFO - 2021-08-11 09:45:03 --> Helper loaded: url_helper
INFO - 2021-08-11 09:45:03 --> Helper loaded: file_helper
INFO - 2021-08-11 09:45:03 --> Helper loaded: form_helper
INFO - 2021-08-11 09:45:03 --> Helper loaded: my_helper
INFO - 2021-08-11 09:45:03 --> Database Driver Class Initialized
DEBUG - 2021-08-11 09:45:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-11 09:45:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-11 09:45:03 --> Controller Class Initialized
ERROR - 2021-08-11 09:45:03 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 38
ERROR - 2021-08-11 09:45:03 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 41
ERROR - 2021-08-11 09:45:03 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 45
ERROR - 2021-08-11 09:45:03 --> Severity: Notice --> Undefined index: keterangan C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 50
DEBUG - 2021-08-11 09:45:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-08-11 09:45:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-11 09:45:03 --> Final output sent to browser
DEBUG - 2021-08-11 09:45:03 --> Total execution time: 0.0901
INFO - 2021-08-11 10:01:51 --> Config Class Initialized
INFO - 2021-08-11 10:01:51 --> Hooks Class Initialized
DEBUG - 2021-08-11 10:01:51 --> UTF-8 Support Enabled
INFO - 2021-08-11 10:01:51 --> Utf8 Class Initialized
INFO - 2021-08-11 10:01:51 --> URI Class Initialized
INFO - 2021-08-11 10:01:51 --> Router Class Initialized
INFO - 2021-08-11 10:01:51 --> Output Class Initialized
INFO - 2021-08-11 10:01:51 --> Security Class Initialized
DEBUG - 2021-08-11 10:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-11 10:01:51 --> Input Class Initialized
INFO - 2021-08-11 10:01:51 --> Language Class Initialized
INFO - 2021-08-11 10:01:51 --> Language Class Initialized
INFO - 2021-08-11 10:01:51 --> Config Class Initialized
INFO - 2021-08-11 10:01:51 --> Loader Class Initialized
INFO - 2021-08-11 10:01:51 --> Helper loaded: url_helper
INFO - 2021-08-11 10:01:51 --> Helper loaded: file_helper
INFO - 2021-08-11 10:01:51 --> Helper loaded: form_helper
INFO - 2021-08-11 10:01:51 --> Helper loaded: my_helper
INFO - 2021-08-11 10:01:51 --> Database Driver Class Initialized
DEBUG - 2021-08-11 10:01:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-11 10:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-11 10:01:51 --> Controller Class Initialized
DEBUG - 2021-08-11 10:01:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-08-11 10:01:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-11 10:01:51 --> Final output sent to browser
DEBUG - 2021-08-11 10:01:51 --> Total execution time: 0.0812
INFO - 2021-08-11 10:01:54 --> Config Class Initialized
INFO - 2021-08-11 10:01:54 --> Hooks Class Initialized
DEBUG - 2021-08-11 10:01:54 --> UTF-8 Support Enabled
INFO - 2021-08-11 10:01:54 --> Utf8 Class Initialized
INFO - 2021-08-11 10:01:54 --> URI Class Initialized
INFO - 2021-08-11 10:01:54 --> Router Class Initialized
INFO - 2021-08-11 10:01:54 --> Output Class Initialized
INFO - 2021-08-11 10:01:54 --> Security Class Initialized
DEBUG - 2021-08-11 10:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-11 10:01:54 --> Input Class Initialized
INFO - 2021-08-11 10:01:54 --> Language Class Initialized
INFO - 2021-08-11 10:01:54 --> Language Class Initialized
INFO - 2021-08-11 10:01:54 --> Config Class Initialized
INFO - 2021-08-11 10:01:54 --> Loader Class Initialized
INFO - 2021-08-11 10:01:54 --> Helper loaded: url_helper
INFO - 2021-08-11 10:01:54 --> Helper loaded: file_helper
INFO - 2021-08-11 10:01:54 --> Helper loaded: form_helper
INFO - 2021-08-11 10:01:54 --> Helper loaded: my_helper
INFO - 2021-08-11 10:01:54 --> Database Driver Class Initialized
DEBUG - 2021-08-11 10:01:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-11 10:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-11 10:01:54 --> Controller Class Initialized
DEBUG - 2021-08-11 10:01:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-08-11 10:01:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-11 10:01:54 --> Final output sent to browser
DEBUG - 2021-08-11 10:01:54 --> Total execution time: 0.1434
INFO - 2021-08-11 10:01:57 --> Config Class Initialized
INFO - 2021-08-11 10:01:57 --> Hooks Class Initialized
DEBUG - 2021-08-11 10:01:57 --> UTF-8 Support Enabled
INFO - 2021-08-11 10:01:57 --> Utf8 Class Initialized
INFO - 2021-08-11 10:01:57 --> URI Class Initialized
INFO - 2021-08-11 10:01:57 --> Router Class Initialized
INFO - 2021-08-11 10:01:57 --> Output Class Initialized
INFO - 2021-08-11 10:01:57 --> Security Class Initialized
DEBUG - 2021-08-11 10:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-11 10:01:57 --> Input Class Initialized
INFO - 2021-08-11 10:01:57 --> Language Class Initialized
INFO - 2021-08-11 10:01:57 --> Language Class Initialized
INFO - 2021-08-11 10:01:57 --> Config Class Initialized
INFO - 2021-08-11 10:01:57 --> Loader Class Initialized
INFO - 2021-08-11 10:01:57 --> Helper loaded: url_helper
INFO - 2021-08-11 10:01:57 --> Helper loaded: file_helper
INFO - 2021-08-11 10:01:57 --> Helper loaded: form_helper
INFO - 2021-08-11 10:01:57 --> Helper loaded: my_helper
INFO - 2021-08-11 10:01:57 --> Database Driver Class Initialized
DEBUG - 2021-08-11 10:01:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-11 10:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-11 10:01:57 --> Controller Class Initialized
DEBUG - 2021-08-11 10:01:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-08-11 10:01:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-11 10:01:57 --> Final output sent to browser
DEBUG - 2021-08-11 10:01:57 --> Total execution time: 0.1205
INFO - 2021-08-11 10:13:56 --> Config Class Initialized
INFO - 2021-08-11 10:13:56 --> Hooks Class Initialized
DEBUG - 2021-08-11 10:13:56 --> UTF-8 Support Enabled
INFO - 2021-08-11 10:13:56 --> Utf8 Class Initialized
INFO - 2021-08-11 10:13:56 --> URI Class Initialized
INFO - 2021-08-11 10:13:56 --> Router Class Initialized
INFO - 2021-08-11 10:13:56 --> Output Class Initialized
INFO - 2021-08-11 10:13:56 --> Security Class Initialized
DEBUG - 2021-08-11 10:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-11 10:13:56 --> Input Class Initialized
INFO - 2021-08-11 10:13:56 --> Language Class Initialized
INFO - 2021-08-11 10:13:56 --> Language Class Initialized
INFO - 2021-08-11 10:13:56 --> Config Class Initialized
INFO - 2021-08-11 10:13:56 --> Loader Class Initialized
INFO - 2021-08-11 10:13:56 --> Helper loaded: url_helper
INFO - 2021-08-11 10:13:56 --> Helper loaded: file_helper
INFO - 2021-08-11 10:13:56 --> Helper loaded: form_helper
INFO - 2021-08-11 10:13:56 --> Helper loaded: my_helper
INFO - 2021-08-11 10:13:56 --> Database Driver Class Initialized
DEBUG - 2021-08-11 10:13:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-11 10:13:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-11 10:13:56 --> Controller Class Initialized
ERROR - 2021-08-11 10:13:56 --> Query error: Unknown column 'a.id_ekstra' in 'field list' - Invalid query: SELECT 
                                                    a.*, b.nama, a.id_ekstra, a.nilai, a.id_ekstra2, a.nilai2
                                                    FROM t_nilai_ekstra a
                                                    INNER JOIN m_siswa b ON a.id_siswa = b.id
                                                    INNER JOIN t_kelas_siswa c ON CONCAT(c.ta,c.id_kelas,c.id_siswa) = CONCAT('20212','1',b.id)
                                                    WHERE c.id_kelas = '1' AND a.tasm = '20212'
INFO - 2021-08-11 10:13:56 --> Language file loaded: language/english/db_lang.php
INFO - 2021-08-11 10:13:57 --> Config Class Initialized
INFO - 2021-08-11 10:13:57 --> Hooks Class Initialized
DEBUG - 2021-08-11 10:13:57 --> UTF-8 Support Enabled
INFO - 2021-08-11 10:13:57 --> Utf8 Class Initialized
INFO - 2021-08-11 10:13:57 --> URI Class Initialized
INFO - 2021-08-11 10:13:57 --> Router Class Initialized
INFO - 2021-08-11 10:13:57 --> Output Class Initialized
INFO - 2021-08-11 10:13:57 --> Security Class Initialized
DEBUG - 2021-08-11 10:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-11 10:13:57 --> Input Class Initialized
INFO - 2021-08-11 10:13:57 --> Language Class Initialized
INFO - 2021-08-11 10:13:57 --> Language Class Initialized
INFO - 2021-08-11 10:13:57 --> Config Class Initialized
INFO - 2021-08-11 10:13:57 --> Loader Class Initialized
INFO - 2021-08-11 10:13:57 --> Helper loaded: url_helper
INFO - 2021-08-11 10:13:57 --> Helper loaded: file_helper
INFO - 2021-08-11 10:13:57 --> Helper loaded: form_helper
INFO - 2021-08-11 10:13:57 --> Helper loaded: my_helper
INFO - 2021-08-11 10:13:57 --> Database Driver Class Initialized
DEBUG - 2021-08-11 10:13:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-11 10:13:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-11 10:13:57 --> Controller Class Initialized
ERROR - 2021-08-11 10:13:57 --> Query error: Unknown column 'a.id_ekstra' in 'field list' - Invalid query: SELECT 
                                                    a.*, b.nama, a.id_ekstra, a.nilai, a.id_ekstra2, a.nilai2
                                                    FROM t_nilai_ekstra a
                                                    INNER JOIN m_siswa b ON a.id_siswa = b.id
                                                    INNER JOIN t_kelas_siswa c ON CONCAT(c.ta,c.id_kelas,c.id_siswa) = CONCAT('20212','1',b.id)
                                                    WHERE c.id_kelas = '1' AND a.tasm = '20212'
INFO - 2021-08-11 10:13:57 --> Language file loaded: language/english/db_lang.php
INFO - 2021-08-11 10:18:37 --> Config Class Initialized
INFO - 2021-08-11 10:18:37 --> Hooks Class Initialized
DEBUG - 2021-08-11 10:18:37 --> UTF-8 Support Enabled
INFO - 2021-08-11 10:18:37 --> Utf8 Class Initialized
INFO - 2021-08-11 10:18:37 --> URI Class Initialized
INFO - 2021-08-11 10:18:37 --> Router Class Initialized
INFO - 2021-08-11 10:18:37 --> Output Class Initialized
INFO - 2021-08-11 10:18:37 --> Security Class Initialized
DEBUG - 2021-08-11 10:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-11 10:18:37 --> Input Class Initialized
INFO - 2021-08-11 10:18:37 --> Language Class Initialized
INFO - 2021-08-11 10:18:37 --> Language Class Initialized
INFO - 2021-08-11 10:18:37 --> Config Class Initialized
INFO - 2021-08-11 10:18:37 --> Loader Class Initialized
INFO - 2021-08-11 10:18:37 --> Helper loaded: url_helper
INFO - 2021-08-11 10:18:37 --> Helper loaded: file_helper
INFO - 2021-08-11 10:18:37 --> Helper loaded: form_helper
INFO - 2021-08-11 10:18:37 --> Helper loaded: my_helper
INFO - 2021-08-11 10:18:37 --> Database Driver Class Initialized
DEBUG - 2021-08-11 10:18:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-11 10:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-11 10:18:37 --> Controller Class Initialized
ERROR - 2021-08-11 10:18:37 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 38
ERROR - 2021-08-11 10:18:37 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 41
ERROR - 2021-08-11 10:18:37 --> Severity: Notice --> Undefined variable: p_ekstra2 C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 55
ERROR - 2021-08-11 10:18:37 --> Severity: Notice --> Undefined index: keterangan C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 55
ERROR - 2021-08-11 10:18:37 --> Severity: Notice --> Undefined variable: p_nilai2 C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 60
DEBUG - 2021-08-11 10:18:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-08-11 10:18:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-11 10:18:37 --> Final output sent to browser
DEBUG - 2021-08-11 10:18:37 --> Total execution time: 0.0840
INFO - 2021-08-11 10:19:10 --> Config Class Initialized
INFO - 2021-08-11 10:19:10 --> Hooks Class Initialized
DEBUG - 2021-08-11 10:19:10 --> UTF-8 Support Enabled
INFO - 2021-08-11 10:19:10 --> Utf8 Class Initialized
INFO - 2021-08-11 10:19:10 --> URI Class Initialized
INFO - 2021-08-11 10:19:10 --> Router Class Initialized
INFO - 2021-08-11 10:19:10 --> Output Class Initialized
INFO - 2021-08-11 10:19:10 --> Security Class Initialized
DEBUG - 2021-08-11 10:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-11 10:19:10 --> Input Class Initialized
INFO - 2021-08-11 10:19:10 --> Language Class Initialized
INFO - 2021-08-11 10:19:10 --> Language Class Initialized
INFO - 2021-08-11 10:19:10 --> Config Class Initialized
INFO - 2021-08-11 10:19:10 --> Loader Class Initialized
INFO - 2021-08-11 10:19:10 --> Helper loaded: url_helper
INFO - 2021-08-11 10:19:10 --> Helper loaded: file_helper
INFO - 2021-08-11 10:19:10 --> Helper loaded: form_helper
INFO - 2021-08-11 10:19:10 --> Helper loaded: my_helper
INFO - 2021-08-11 10:19:10 --> Database Driver Class Initialized
DEBUG - 2021-08-11 10:19:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-11 10:19:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-11 10:19:10 --> Controller Class Initialized
ERROR - 2021-08-11 10:19:10 --> Severity: Notice --> Undefined variable: p_ekstra2 C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 49
ERROR - 2021-08-11 10:19:10 --> Severity: Notice --> Undefined index: keterangan C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 49
ERROR - 2021-08-11 10:19:10 --> Severity: Notice --> Undefined variable: p_nilai2 C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 54
DEBUG - 2021-08-11 10:19:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-08-11 10:19:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-11 10:19:10 --> Final output sent to browser
DEBUG - 2021-08-11 10:19:10 --> Total execution time: 0.0649
INFO - 2021-08-11 10:19:49 --> Config Class Initialized
INFO - 2021-08-11 10:19:49 --> Hooks Class Initialized
DEBUG - 2021-08-11 10:19:49 --> UTF-8 Support Enabled
INFO - 2021-08-11 10:19:49 --> Utf8 Class Initialized
INFO - 2021-08-11 10:19:49 --> URI Class Initialized
INFO - 2021-08-11 10:19:49 --> Router Class Initialized
INFO - 2021-08-11 10:19:49 --> Output Class Initialized
INFO - 2021-08-11 10:19:49 --> Security Class Initialized
DEBUG - 2021-08-11 10:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-11 10:19:49 --> Input Class Initialized
INFO - 2021-08-11 10:19:49 --> Language Class Initialized
INFO - 2021-08-11 10:19:49 --> Language Class Initialized
INFO - 2021-08-11 10:19:49 --> Config Class Initialized
INFO - 2021-08-11 10:19:49 --> Loader Class Initialized
INFO - 2021-08-11 10:19:49 --> Helper loaded: url_helper
INFO - 2021-08-11 10:19:49 --> Helper loaded: file_helper
INFO - 2021-08-11 10:19:49 --> Helper loaded: form_helper
INFO - 2021-08-11 10:19:49 --> Helper loaded: my_helper
INFO - 2021-08-11 10:19:49 --> Database Driver Class Initialized
DEBUG - 2021-08-11 10:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-11 10:19:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-11 10:19:49 --> Controller Class Initialized
ERROR - 2021-08-11 10:19:49 --> Severity: Notice --> Undefined variable: p_ekstra2 C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 49
ERROR - 2021-08-11 10:19:49 --> Severity: Notice --> Undefined variable: p_nilai2 C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 54
DEBUG - 2021-08-11 10:19:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-08-11 10:19:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-11 10:19:49 --> Final output sent to browser
DEBUG - 2021-08-11 10:19:49 --> Total execution time: 0.0734
INFO - 2021-08-11 10:20:26 --> Config Class Initialized
INFO - 2021-08-11 10:20:26 --> Hooks Class Initialized
DEBUG - 2021-08-11 10:20:26 --> UTF-8 Support Enabled
INFO - 2021-08-11 10:20:26 --> Utf8 Class Initialized
INFO - 2021-08-11 10:20:26 --> URI Class Initialized
INFO - 2021-08-11 10:20:26 --> Router Class Initialized
INFO - 2021-08-11 10:20:26 --> Output Class Initialized
INFO - 2021-08-11 10:20:26 --> Security Class Initialized
DEBUG - 2021-08-11 10:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-11 10:20:26 --> Input Class Initialized
INFO - 2021-08-11 10:20:26 --> Language Class Initialized
INFO - 2021-08-11 10:20:26 --> Language Class Initialized
INFO - 2021-08-11 10:20:26 --> Config Class Initialized
INFO - 2021-08-11 10:20:26 --> Loader Class Initialized
INFO - 2021-08-11 10:20:26 --> Helper loaded: url_helper
INFO - 2021-08-11 10:20:26 --> Helper loaded: file_helper
INFO - 2021-08-11 10:20:26 --> Helper loaded: form_helper
INFO - 2021-08-11 10:20:26 --> Helper loaded: my_helper
INFO - 2021-08-11 10:20:26 --> Database Driver Class Initialized
DEBUG - 2021-08-11 10:20:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-11 10:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-11 10:20:26 --> Controller Class Initialized
DEBUG - 2021-08-11 10:20:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-08-11 10:20:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-11 10:20:26 --> Final output sent to browser
DEBUG - 2021-08-11 10:20:26 --> Total execution time: 0.0656
INFO - 2021-08-11 10:21:22 --> Config Class Initialized
INFO - 2021-08-11 10:21:22 --> Hooks Class Initialized
DEBUG - 2021-08-11 10:21:22 --> UTF-8 Support Enabled
INFO - 2021-08-11 10:21:22 --> Utf8 Class Initialized
INFO - 2021-08-11 10:21:22 --> URI Class Initialized
INFO - 2021-08-11 10:21:22 --> Router Class Initialized
INFO - 2021-08-11 10:21:22 --> Output Class Initialized
INFO - 2021-08-11 10:21:22 --> Security Class Initialized
DEBUG - 2021-08-11 10:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-11 10:21:22 --> Input Class Initialized
INFO - 2021-08-11 10:21:22 --> Language Class Initialized
INFO - 2021-08-11 10:21:22 --> Language Class Initialized
INFO - 2021-08-11 10:21:22 --> Config Class Initialized
INFO - 2021-08-11 10:21:22 --> Loader Class Initialized
INFO - 2021-08-11 10:21:22 --> Helper loaded: url_helper
INFO - 2021-08-11 10:21:22 --> Helper loaded: file_helper
INFO - 2021-08-11 10:21:22 --> Helper loaded: form_helper
INFO - 2021-08-11 10:21:22 --> Helper loaded: my_helper
INFO - 2021-08-11 10:21:22 --> Database Driver Class Initialized
DEBUG - 2021-08-11 10:21:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-11 10:21:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-11 10:21:22 --> Controller Class Initialized
DEBUG - 2021-08-11 10:21:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-08-11 10:21:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-11 10:21:22 --> Final output sent to browser
DEBUG - 2021-08-11 10:21:22 --> Total execution time: 0.0739
INFO - 2021-08-11 10:21:23 --> Config Class Initialized
INFO - 2021-08-11 10:21:23 --> Hooks Class Initialized
DEBUG - 2021-08-11 10:21:23 --> UTF-8 Support Enabled
INFO - 2021-08-11 10:21:23 --> Utf8 Class Initialized
INFO - 2021-08-11 10:21:23 --> URI Class Initialized
INFO - 2021-08-11 10:21:23 --> Router Class Initialized
INFO - 2021-08-11 10:21:23 --> Output Class Initialized
INFO - 2021-08-11 10:21:23 --> Security Class Initialized
DEBUG - 2021-08-11 10:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-11 10:21:23 --> Input Class Initialized
INFO - 2021-08-11 10:21:23 --> Language Class Initialized
INFO - 2021-08-11 10:21:23 --> Language Class Initialized
INFO - 2021-08-11 10:21:23 --> Config Class Initialized
INFO - 2021-08-11 10:21:23 --> Loader Class Initialized
INFO - 2021-08-11 10:21:23 --> Helper loaded: url_helper
INFO - 2021-08-11 10:21:23 --> Helper loaded: file_helper
INFO - 2021-08-11 10:21:23 --> Helper loaded: form_helper
INFO - 2021-08-11 10:21:23 --> Helper loaded: my_helper
INFO - 2021-08-11 10:21:23 --> Database Driver Class Initialized
DEBUG - 2021-08-11 10:21:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-11 10:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-11 10:21:23 --> Controller Class Initialized
DEBUG - 2021-08-11 10:21:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-08-11 10:21:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-11 10:21:23 --> Final output sent to browser
DEBUG - 2021-08-11 10:21:23 --> Total execution time: 0.0644
INFO - 2021-08-11 10:22:07 --> Config Class Initialized
INFO - 2021-08-11 10:22:07 --> Hooks Class Initialized
DEBUG - 2021-08-11 10:22:07 --> UTF-8 Support Enabled
INFO - 2021-08-11 10:22:07 --> Utf8 Class Initialized
INFO - 2021-08-11 10:22:07 --> URI Class Initialized
INFO - 2021-08-11 10:22:07 --> Router Class Initialized
INFO - 2021-08-11 10:22:07 --> Output Class Initialized
INFO - 2021-08-11 10:22:07 --> Security Class Initialized
DEBUG - 2021-08-11 10:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-11 10:22:07 --> Input Class Initialized
INFO - 2021-08-11 10:22:07 --> Language Class Initialized
INFO - 2021-08-11 10:22:07 --> Language Class Initialized
INFO - 2021-08-11 10:22:07 --> Config Class Initialized
INFO - 2021-08-11 10:22:07 --> Loader Class Initialized
INFO - 2021-08-11 10:22:07 --> Helper loaded: url_helper
INFO - 2021-08-11 10:22:07 --> Helper loaded: file_helper
INFO - 2021-08-11 10:22:07 --> Helper loaded: form_helper
INFO - 2021-08-11 10:22:07 --> Helper loaded: my_helper
INFO - 2021-08-11 10:22:07 --> Database Driver Class Initialized
DEBUG - 2021-08-11 10:22:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-11 10:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-11 10:22:07 --> Controller Class Initialized
DEBUG - 2021-08-11 10:22:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-08-11 10:22:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-11 10:22:07 --> Final output sent to browser
DEBUG - 2021-08-11 10:22:07 --> Total execution time: 0.0680
INFO - 2021-08-11 10:25:03 --> Config Class Initialized
INFO - 2021-08-11 10:25:03 --> Hooks Class Initialized
DEBUG - 2021-08-11 10:25:04 --> UTF-8 Support Enabled
INFO - 2021-08-11 10:25:04 --> Utf8 Class Initialized
INFO - 2021-08-11 10:25:04 --> URI Class Initialized
INFO - 2021-08-11 10:25:04 --> Router Class Initialized
INFO - 2021-08-11 10:25:04 --> Output Class Initialized
INFO - 2021-08-11 10:25:04 --> Security Class Initialized
DEBUG - 2021-08-11 10:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-11 10:25:04 --> Input Class Initialized
INFO - 2021-08-11 10:25:04 --> Language Class Initialized
INFO - 2021-08-11 10:25:04 --> Language Class Initialized
INFO - 2021-08-11 10:25:04 --> Config Class Initialized
INFO - 2021-08-11 10:25:04 --> Loader Class Initialized
INFO - 2021-08-11 10:25:04 --> Helper loaded: url_helper
INFO - 2021-08-11 10:25:04 --> Helper loaded: file_helper
INFO - 2021-08-11 10:25:04 --> Helper loaded: form_helper
INFO - 2021-08-11 10:25:04 --> Helper loaded: my_helper
INFO - 2021-08-11 10:25:04 --> Database Driver Class Initialized
DEBUG - 2021-08-11 10:25:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-11 10:25:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-11 10:25:04 --> Controller Class Initialized
DEBUG - 2021-08-11 10:25:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-08-11 10:25:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-11 10:25:04 --> Final output sent to browser
DEBUG - 2021-08-11 10:25:04 --> Total execution time: 0.0967
INFO - 2021-08-11 10:25:05 --> Config Class Initialized
INFO - 2021-08-11 10:25:05 --> Hooks Class Initialized
DEBUG - 2021-08-11 10:25:05 --> UTF-8 Support Enabled
INFO - 2021-08-11 10:25:05 --> Utf8 Class Initialized
INFO - 2021-08-11 10:25:05 --> URI Class Initialized
INFO - 2021-08-11 10:25:05 --> Router Class Initialized
INFO - 2021-08-11 10:25:05 --> Output Class Initialized
INFO - 2021-08-11 10:25:05 --> Security Class Initialized
DEBUG - 2021-08-11 10:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-11 10:25:05 --> Input Class Initialized
INFO - 2021-08-11 10:25:05 --> Language Class Initialized
INFO - 2021-08-11 10:25:05 --> Language Class Initialized
INFO - 2021-08-11 10:25:05 --> Config Class Initialized
INFO - 2021-08-11 10:25:05 --> Loader Class Initialized
INFO - 2021-08-11 10:25:05 --> Helper loaded: url_helper
INFO - 2021-08-11 10:25:05 --> Helper loaded: file_helper
INFO - 2021-08-11 10:25:05 --> Helper loaded: form_helper
INFO - 2021-08-11 10:25:05 --> Helper loaded: my_helper
INFO - 2021-08-11 10:25:05 --> Database Driver Class Initialized
DEBUG - 2021-08-11 10:25:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-11 10:25:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-11 10:25:05 --> Controller Class Initialized
ERROR - 2021-08-11 10:25:05 --> Query error: Unknown column 'ta' in 'where clause' - Invalid query: SELECT 
                                    		ekstra, nilai, ekstra2, nilai2
                                    		FROM t_nilai_ekstra
                                    		WHERE id_siswa = 1 AND ta = '20212'
INFO - 2021-08-11 10:25:05 --> Language file loaded: language/english/db_lang.php
INFO - 2021-08-11 10:31:21 --> Config Class Initialized
INFO - 2021-08-11 10:31:21 --> Hooks Class Initialized
DEBUG - 2021-08-11 10:31:21 --> UTF-8 Support Enabled
INFO - 2021-08-11 10:31:21 --> Utf8 Class Initialized
INFO - 2021-08-11 10:31:21 --> URI Class Initialized
INFO - 2021-08-11 10:31:21 --> Router Class Initialized
INFO - 2021-08-11 10:31:21 --> Output Class Initialized
INFO - 2021-08-11 10:31:21 --> Security Class Initialized
DEBUG - 2021-08-11 10:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-11 10:31:21 --> Input Class Initialized
INFO - 2021-08-11 10:31:21 --> Language Class Initialized
INFO - 2021-08-11 10:31:21 --> Language Class Initialized
INFO - 2021-08-11 10:31:21 --> Config Class Initialized
INFO - 2021-08-11 10:31:21 --> Loader Class Initialized
INFO - 2021-08-11 10:31:21 --> Helper loaded: url_helper
INFO - 2021-08-11 10:31:21 --> Helper loaded: file_helper
INFO - 2021-08-11 10:31:21 --> Helper loaded: form_helper
INFO - 2021-08-11 10:31:21 --> Helper loaded: my_helper
INFO - 2021-08-11 10:31:21 --> Database Driver Class Initialized
DEBUG - 2021-08-11 10:31:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-11 10:31:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-11 10:31:21 --> Controller Class Initialized
DEBUG - 2021-08-11 10:31:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-08-11 10:31:21 --> Final output sent to browser
DEBUG - 2021-08-11 10:31:21 --> Total execution time: 0.0685
INFO - 2021-08-11 10:31:32 --> Config Class Initialized
INFO - 2021-08-11 10:31:32 --> Hooks Class Initialized
DEBUG - 2021-08-11 10:31:32 --> UTF-8 Support Enabled
INFO - 2021-08-11 10:31:32 --> Utf8 Class Initialized
INFO - 2021-08-11 10:31:32 --> URI Class Initialized
INFO - 2021-08-11 10:31:32 --> Router Class Initialized
INFO - 2021-08-11 10:31:32 --> Output Class Initialized
INFO - 2021-08-11 10:31:32 --> Security Class Initialized
DEBUG - 2021-08-11 10:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-11 10:31:32 --> Input Class Initialized
INFO - 2021-08-11 10:31:32 --> Language Class Initialized
INFO - 2021-08-11 10:31:32 --> Language Class Initialized
INFO - 2021-08-11 10:31:32 --> Config Class Initialized
INFO - 2021-08-11 10:31:32 --> Loader Class Initialized
INFO - 2021-08-11 10:31:32 --> Helper loaded: url_helper
INFO - 2021-08-11 10:31:32 --> Helper loaded: file_helper
INFO - 2021-08-11 10:31:32 --> Helper loaded: form_helper
INFO - 2021-08-11 10:31:32 --> Helper loaded: my_helper
INFO - 2021-08-11 10:31:32 --> Database Driver Class Initialized
DEBUG - 2021-08-11 10:31:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-11 10:31:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-11 10:31:32 --> Controller Class Initialized
DEBUG - 2021-08-11 10:31:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-08-11 10:31:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-11 10:31:32 --> Final output sent to browser
DEBUG - 2021-08-11 10:31:32 --> Total execution time: 0.0814
INFO - 2021-08-11 10:31:36 --> Config Class Initialized
INFO - 2021-08-11 10:31:36 --> Hooks Class Initialized
DEBUG - 2021-08-11 10:31:36 --> UTF-8 Support Enabled
INFO - 2021-08-11 10:31:36 --> Utf8 Class Initialized
INFO - 2021-08-11 10:31:36 --> URI Class Initialized
INFO - 2021-08-11 10:31:36 --> Router Class Initialized
INFO - 2021-08-11 10:31:36 --> Output Class Initialized
INFO - 2021-08-11 10:31:36 --> Security Class Initialized
DEBUG - 2021-08-11 10:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-11 10:31:36 --> Input Class Initialized
INFO - 2021-08-11 10:31:36 --> Language Class Initialized
INFO - 2021-08-11 10:31:36 --> Language Class Initialized
INFO - 2021-08-11 10:31:36 --> Config Class Initialized
INFO - 2021-08-11 10:31:36 --> Loader Class Initialized
INFO - 2021-08-11 10:31:36 --> Helper loaded: url_helper
INFO - 2021-08-11 10:31:36 --> Helper loaded: file_helper
INFO - 2021-08-11 10:31:36 --> Helper loaded: form_helper
INFO - 2021-08-11 10:31:36 --> Helper loaded: my_helper
INFO - 2021-08-11 10:31:36 --> Database Driver Class Initialized
DEBUG - 2021-08-11 10:31:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-11 10:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-11 10:31:37 --> Controller Class Initialized
ERROR - 2021-08-11 10:31:37 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`db_nilai`.`t_nilai_ekstra`, CONSTRAINT `t_nilai_ekstra_ibfk_1` FOREIGN KEY (`ekstra`) REFERENCES `m_ekstra` (`id`)) - Invalid query: INSERT INTO t_nilai_ekstra (id_siswa,tasm,ekstra,nilai,ekstra2,nilai2) VALUES ('1','20212','1','A','-','-')
INFO - 2021-08-11 10:31:37 --> Language file loaded: language/english/db_lang.php
INFO - 2021-08-11 10:31:48 --> Config Class Initialized
INFO - 2021-08-11 10:31:48 --> Hooks Class Initialized
DEBUG - 2021-08-11 10:31:48 --> UTF-8 Support Enabled
INFO - 2021-08-11 10:31:48 --> Utf8 Class Initialized
INFO - 2021-08-11 10:31:48 --> URI Class Initialized
INFO - 2021-08-11 10:31:48 --> Router Class Initialized
INFO - 2021-08-11 10:31:48 --> Output Class Initialized
INFO - 2021-08-11 10:31:48 --> Security Class Initialized
DEBUG - 2021-08-11 10:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-11 10:31:48 --> Input Class Initialized
INFO - 2021-08-11 10:31:48 --> Language Class Initialized
INFO - 2021-08-11 10:31:48 --> Language Class Initialized
INFO - 2021-08-11 10:31:48 --> Config Class Initialized
INFO - 2021-08-11 10:31:48 --> Loader Class Initialized
INFO - 2021-08-11 10:31:48 --> Helper loaded: url_helper
INFO - 2021-08-11 10:31:48 --> Helper loaded: file_helper
INFO - 2021-08-11 10:31:48 --> Helper loaded: form_helper
INFO - 2021-08-11 10:31:48 --> Helper loaded: my_helper
INFO - 2021-08-11 10:31:48 --> Database Driver Class Initialized
DEBUG - 2021-08-11 10:31:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-11 10:31:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-11 10:31:48 --> Controller Class Initialized
DEBUG - 2021-08-11 10:31:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-08-11 10:31:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-11 10:31:48 --> Final output sent to browser
DEBUG - 2021-08-11 10:31:48 --> Total execution time: 0.0682
INFO - 2021-08-11 10:31:59 --> Config Class Initialized
INFO - 2021-08-11 10:31:59 --> Hooks Class Initialized
DEBUG - 2021-08-11 10:31:59 --> UTF-8 Support Enabled
INFO - 2021-08-11 10:31:59 --> Utf8 Class Initialized
INFO - 2021-08-11 10:31:59 --> URI Class Initialized
INFO - 2021-08-11 10:31:59 --> Router Class Initialized
INFO - 2021-08-11 10:31:59 --> Output Class Initialized
INFO - 2021-08-11 10:31:59 --> Security Class Initialized
DEBUG - 2021-08-11 10:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-11 10:31:59 --> Input Class Initialized
INFO - 2021-08-11 10:31:59 --> Language Class Initialized
INFO - 2021-08-11 10:31:59 --> Language Class Initialized
INFO - 2021-08-11 10:31:59 --> Config Class Initialized
INFO - 2021-08-11 10:31:59 --> Loader Class Initialized
INFO - 2021-08-11 10:31:59 --> Helper loaded: url_helper
INFO - 2021-08-11 10:31:59 --> Helper loaded: file_helper
INFO - 2021-08-11 10:31:59 --> Helper loaded: form_helper
INFO - 2021-08-11 10:31:59 --> Helper loaded: my_helper
INFO - 2021-08-11 10:31:59 --> Database Driver Class Initialized
DEBUG - 2021-08-11 10:31:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-11 10:31:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-11 10:31:59 --> Controller Class Initialized
DEBUG - 2021-08-11 10:31:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-08-11 10:31:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-11 10:31:59 --> Final output sent to browser
DEBUG - 2021-08-11 10:31:59 --> Total execution time: 0.0720
INFO - 2021-08-11 10:32:03 --> Config Class Initialized
INFO - 2021-08-11 10:32:03 --> Hooks Class Initialized
DEBUG - 2021-08-11 10:32:03 --> UTF-8 Support Enabled
INFO - 2021-08-11 10:32:03 --> Utf8 Class Initialized
INFO - 2021-08-11 10:32:03 --> URI Class Initialized
INFO - 2021-08-11 10:32:03 --> Router Class Initialized
INFO - 2021-08-11 10:32:03 --> Output Class Initialized
INFO - 2021-08-11 10:32:03 --> Security Class Initialized
DEBUG - 2021-08-11 10:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-11 10:32:03 --> Input Class Initialized
INFO - 2021-08-11 10:32:03 --> Language Class Initialized
INFO - 2021-08-11 10:32:03 --> Language Class Initialized
INFO - 2021-08-11 10:32:03 --> Config Class Initialized
INFO - 2021-08-11 10:32:03 --> Loader Class Initialized
INFO - 2021-08-11 10:32:03 --> Helper loaded: url_helper
INFO - 2021-08-11 10:32:03 --> Helper loaded: file_helper
INFO - 2021-08-11 10:32:03 --> Helper loaded: form_helper
INFO - 2021-08-11 10:32:03 --> Helper loaded: my_helper
INFO - 2021-08-11 10:32:03 --> Database Driver Class Initialized
DEBUG - 2021-08-11 10:32:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-11 10:32:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-11 10:32:03 --> Controller Class Initialized
DEBUG - 2021-08-11 10:32:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-08-11 10:32:03 --> Final output sent to browser
DEBUG - 2021-08-11 10:32:03 --> Total execution time: 0.0863
INFO - 2021-08-11 03:54:54 --> Config Class Initialized
INFO - 2021-08-11 03:54:54 --> Hooks Class Initialized
DEBUG - 2021-08-11 03:54:54 --> UTF-8 Support Enabled
INFO - 2021-08-11 03:54:54 --> Utf8 Class Initialized
INFO - 2021-08-11 03:54:54 --> URI Class Initialized
DEBUG - 2021-08-11 03:54:54 --> No URI present. Default controller set.
INFO - 2021-08-11 03:54:54 --> Router Class Initialized
INFO - 2021-08-11 03:54:54 --> Output Class Initialized
INFO - 2021-08-11 03:54:54 --> Security Class Initialized
DEBUG - 2021-08-11 03:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-11 03:54:54 --> Input Class Initialized
INFO - 2021-08-11 03:54:54 --> Language Class Initialized
INFO - 2021-08-11 03:54:55 --> Language Class Initialized
INFO - 2021-08-11 03:54:55 --> Config Class Initialized
INFO - 2021-08-11 03:54:55 --> Loader Class Initialized
INFO - 2021-08-11 03:54:55 --> Helper loaded: url_helper
INFO - 2021-08-11 03:54:55 --> Helper loaded: file_helper
INFO - 2021-08-11 03:54:55 --> Helper loaded: form_helper
INFO - 2021-08-11 03:54:55 --> Helper loaded: my_helper
INFO - 2021-08-11 03:54:55 --> Database Driver Class Initialized
DEBUG - 2021-08-11 03:54:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-11 03:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-11 03:54:55 --> Controller Class Initialized
INFO - 2021-08-11 03:54:55 --> Config Class Initialized
INFO - 2021-08-11 03:54:55 --> Hooks Class Initialized
DEBUG - 2021-08-11 03:54:55 --> UTF-8 Support Enabled
INFO - 2021-08-11 03:54:55 --> Utf8 Class Initialized
INFO - 2021-08-11 03:54:55 --> URI Class Initialized
INFO - 2021-08-11 03:54:55 --> Router Class Initialized
INFO - 2021-08-11 03:54:55 --> Output Class Initialized
INFO - 2021-08-11 03:54:55 --> Security Class Initialized
DEBUG - 2021-08-11 03:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-11 03:54:55 --> Input Class Initialized
INFO - 2021-08-11 03:54:55 --> Language Class Initialized
INFO - 2021-08-11 03:54:55 --> Language Class Initialized
INFO - 2021-08-11 03:54:55 --> Config Class Initialized
INFO - 2021-08-11 03:54:55 --> Loader Class Initialized
INFO - 2021-08-11 03:54:55 --> Helper loaded: url_helper
INFO - 2021-08-11 03:54:55 --> Helper loaded: file_helper
INFO - 2021-08-11 03:54:55 --> Helper loaded: form_helper
INFO - 2021-08-11 03:54:55 --> Helper loaded: my_helper
INFO - 2021-08-11 03:54:55 --> Database Driver Class Initialized
DEBUG - 2021-08-11 03:54:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-11 03:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-11 03:54:55 --> Controller Class Initialized
DEBUG - 2021-08-11 03:54:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-08-11 03:54:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-11 03:54:55 --> Final output sent to browser
DEBUG - 2021-08-11 03:54:55 --> Total execution time: 0.2286
INFO - 2021-08-11 04:12:01 --> Config Class Initialized
INFO - 2021-08-11 04:12:01 --> Hooks Class Initialized
DEBUG - 2021-08-11 04:12:01 --> UTF-8 Support Enabled
INFO - 2021-08-11 04:12:01 --> Utf8 Class Initialized
INFO - 2021-08-11 04:12:01 --> URI Class Initialized
INFO - 2021-08-11 04:12:01 --> Router Class Initialized
INFO - 2021-08-11 04:12:01 --> Output Class Initialized
INFO - 2021-08-11 04:12:01 --> Security Class Initialized
DEBUG - 2021-08-11 04:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-11 04:12:01 --> Input Class Initialized
INFO - 2021-08-11 04:12:01 --> Language Class Initialized
INFO - 2021-08-11 04:12:01 --> Language Class Initialized
INFO - 2021-08-11 04:12:01 --> Config Class Initialized
INFO - 2021-08-11 04:12:01 --> Loader Class Initialized
INFO - 2021-08-11 04:12:01 --> Helper loaded: url_helper
INFO - 2021-08-11 04:12:01 --> Helper loaded: file_helper
INFO - 2021-08-11 04:12:01 --> Helper loaded: form_helper
INFO - 2021-08-11 04:12:01 --> Helper loaded: my_helper
INFO - 2021-08-11 04:12:01 --> Database Driver Class Initialized
DEBUG - 2021-08-11 04:12:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-11 04:12:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-11 04:12:01 --> Controller Class Initialized
INFO - 2021-08-11 04:12:01 --> Helper loaded: cookie_helper
INFO - 2021-08-11 04:12:01 --> Final output sent to browser
DEBUG - 2021-08-11 04:12:01 --> Total execution time: 0.0938
INFO - 2021-08-11 04:12:01 --> Config Class Initialized
INFO - 2021-08-11 04:12:01 --> Hooks Class Initialized
DEBUG - 2021-08-11 04:12:01 --> UTF-8 Support Enabled
INFO - 2021-08-11 04:12:01 --> Utf8 Class Initialized
INFO - 2021-08-11 04:12:01 --> URI Class Initialized
INFO - 2021-08-11 04:12:01 --> Router Class Initialized
INFO - 2021-08-11 04:12:01 --> Output Class Initialized
INFO - 2021-08-11 04:12:01 --> Security Class Initialized
DEBUG - 2021-08-11 04:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-11 04:12:01 --> Input Class Initialized
INFO - 2021-08-11 04:12:01 --> Language Class Initialized
INFO - 2021-08-11 04:12:01 --> Language Class Initialized
INFO - 2021-08-11 04:12:01 --> Config Class Initialized
INFO - 2021-08-11 04:12:01 --> Loader Class Initialized
INFO - 2021-08-11 04:12:01 --> Helper loaded: url_helper
INFO - 2021-08-11 04:12:01 --> Helper loaded: file_helper
INFO - 2021-08-11 04:12:01 --> Helper loaded: form_helper
INFO - 2021-08-11 04:12:01 --> Helper loaded: my_helper
INFO - 2021-08-11 04:12:01 --> Database Driver Class Initialized
DEBUG - 2021-08-11 04:12:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-11 04:12:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-11 04:12:01 --> Controller Class Initialized
DEBUG - 2021-08-11 04:12:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-08-11 04:12:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-11 04:12:01 --> Final output sent to browser
DEBUG - 2021-08-11 04:12:01 --> Total execution time: 0.1338
INFO - 2021-08-11 04:12:04 --> Config Class Initialized
INFO - 2021-08-11 04:12:04 --> Hooks Class Initialized
DEBUG - 2021-08-11 04:12:04 --> UTF-8 Support Enabled
INFO - 2021-08-11 04:12:04 --> Utf8 Class Initialized
INFO - 2021-08-11 04:12:04 --> URI Class Initialized
INFO - 2021-08-11 04:12:04 --> Router Class Initialized
INFO - 2021-08-11 04:12:04 --> Output Class Initialized
INFO - 2021-08-11 04:12:04 --> Security Class Initialized
DEBUG - 2021-08-11 04:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-11 04:12:04 --> Input Class Initialized
INFO - 2021-08-11 04:12:04 --> Language Class Initialized
INFO - 2021-08-11 04:12:04 --> Language Class Initialized
INFO - 2021-08-11 04:12:04 --> Config Class Initialized
INFO - 2021-08-11 04:12:04 --> Loader Class Initialized
INFO - 2021-08-11 04:12:04 --> Helper loaded: url_helper
INFO - 2021-08-11 04:12:04 --> Helper loaded: file_helper
INFO - 2021-08-11 04:12:04 --> Helper loaded: form_helper
INFO - 2021-08-11 04:12:04 --> Helper loaded: my_helper
INFO - 2021-08-11 04:12:04 --> Database Driver Class Initialized
DEBUG - 2021-08-11 04:12:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-11 04:12:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-11 04:12:04 --> Controller Class Initialized
DEBUG - 2021-08-11 04:12:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_ekstra/views/list.php
DEBUG - 2021-08-11 04:12:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-11 04:12:04 --> Final output sent to browser
DEBUG - 2021-08-11 04:12:04 --> Total execution time: 0.0929
INFO - 2021-08-11 04:12:04 --> Config Class Initialized
INFO - 2021-08-11 04:12:04 --> Hooks Class Initialized
DEBUG - 2021-08-11 04:12:04 --> UTF-8 Support Enabled
INFO - 2021-08-11 04:12:04 --> Utf8 Class Initialized
INFO - 2021-08-11 04:12:04 --> URI Class Initialized
INFO - 2021-08-11 04:12:04 --> Router Class Initialized
INFO - 2021-08-11 04:12:04 --> Output Class Initialized
INFO - 2021-08-11 04:12:04 --> Security Class Initialized
DEBUG - 2021-08-11 04:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-11 04:12:04 --> Input Class Initialized
INFO - 2021-08-11 04:12:04 --> Language Class Initialized
INFO - 2021-08-11 04:12:04 --> Language Class Initialized
INFO - 2021-08-11 04:12:04 --> Config Class Initialized
INFO - 2021-08-11 04:12:04 --> Loader Class Initialized
INFO - 2021-08-11 04:12:04 --> Helper loaded: url_helper
INFO - 2021-08-11 04:12:04 --> Helper loaded: file_helper
INFO - 2021-08-11 04:12:04 --> Helper loaded: form_helper
INFO - 2021-08-11 04:12:04 --> Helper loaded: my_helper
INFO - 2021-08-11 04:12:04 --> Database Driver Class Initialized
DEBUG - 2021-08-11 04:12:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-11 04:12:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-11 04:12:04 --> Controller Class Initialized
INFO - 2021-08-11 04:12:06 --> Config Class Initialized
INFO - 2021-08-11 04:12:06 --> Hooks Class Initialized
DEBUG - 2021-08-11 04:12:06 --> UTF-8 Support Enabled
INFO - 2021-08-11 04:12:06 --> Utf8 Class Initialized
INFO - 2021-08-11 04:12:06 --> URI Class Initialized
INFO - 2021-08-11 04:12:06 --> Router Class Initialized
INFO - 2021-08-11 04:12:06 --> Output Class Initialized
INFO - 2021-08-11 04:12:06 --> Security Class Initialized
DEBUG - 2021-08-11 04:12:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-11 04:12:06 --> Input Class Initialized
INFO - 2021-08-11 04:12:06 --> Language Class Initialized
INFO - 2021-08-11 04:12:06 --> Language Class Initialized
INFO - 2021-08-11 04:12:06 --> Config Class Initialized
INFO - 2021-08-11 04:12:06 --> Loader Class Initialized
INFO - 2021-08-11 04:12:06 --> Helper loaded: url_helper
INFO - 2021-08-11 04:12:06 --> Helper loaded: file_helper
INFO - 2021-08-11 04:12:06 --> Helper loaded: form_helper
INFO - 2021-08-11 04:12:06 --> Helper loaded: my_helper
INFO - 2021-08-11 04:12:06 --> Database Driver Class Initialized
DEBUG - 2021-08-11 04:12:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-11 04:12:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-11 04:12:06 --> Controller Class Initialized
INFO - 2021-08-11 04:12:06 --> Final output sent to browser
DEBUG - 2021-08-11 04:12:06 --> Total execution time: 0.0552
INFO - 2021-08-11 04:12:20 --> Config Class Initialized
INFO - 2021-08-11 04:12:20 --> Hooks Class Initialized
DEBUG - 2021-08-11 04:12:20 --> UTF-8 Support Enabled
INFO - 2021-08-11 04:12:20 --> Utf8 Class Initialized
INFO - 2021-08-11 04:12:20 --> URI Class Initialized
INFO - 2021-08-11 04:12:20 --> Router Class Initialized
INFO - 2021-08-11 04:12:20 --> Output Class Initialized
INFO - 2021-08-11 04:12:20 --> Security Class Initialized
DEBUG - 2021-08-11 04:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-11 04:12:20 --> Input Class Initialized
INFO - 2021-08-11 04:12:20 --> Language Class Initialized
INFO - 2021-08-11 04:12:20 --> Language Class Initialized
INFO - 2021-08-11 04:12:20 --> Config Class Initialized
INFO - 2021-08-11 04:12:20 --> Loader Class Initialized
INFO - 2021-08-11 04:12:20 --> Helper loaded: url_helper
INFO - 2021-08-11 04:12:20 --> Helper loaded: file_helper
INFO - 2021-08-11 04:12:20 --> Helper loaded: form_helper
INFO - 2021-08-11 04:12:20 --> Helper loaded: my_helper
INFO - 2021-08-11 04:12:20 --> Database Driver Class Initialized
DEBUG - 2021-08-11 04:12:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-11 04:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-11 04:12:20 --> Controller Class Initialized
INFO - 2021-08-11 04:12:20 --> Final output sent to browser
DEBUG - 2021-08-11 04:12:20 --> Total execution time: 0.0708
INFO - 2021-08-11 04:12:20 --> Config Class Initialized
INFO - 2021-08-11 04:12:20 --> Hooks Class Initialized
DEBUG - 2021-08-11 04:12:20 --> UTF-8 Support Enabled
INFO - 2021-08-11 04:12:20 --> Utf8 Class Initialized
INFO - 2021-08-11 04:12:20 --> URI Class Initialized
INFO - 2021-08-11 04:12:20 --> Router Class Initialized
INFO - 2021-08-11 04:12:20 --> Output Class Initialized
INFO - 2021-08-11 04:12:20 --> Security Class Initialized
DEBUG - 2021-08-11 04:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-11 04:12:20 --> Input Class Initialized
INFO - 2021-08-11 04:12:20 --> Language Class Initialized
INFO - 2021-08-11 04:12:20 --> Language Class Initialized
INFO - 2021-08-11 04:12:20 --> Config Class Initialized
INFO - 2021-08-11 04:12:20 --> Loader Class Initialized
INFO - 2021-08-11 04:12:20 --> Helper loaded: url_helper
INFO - 2021-08-11 04:12:20 --> Helper loaded: file_helper
INFO - 2021-08-11 04:12:20 --> Helper loaded: form_helper
INFO - 2021-08-11 04:12:20 --> Helper loaded: my_helper
INFO - 2021-08-11 04:12:20 --> Database Driver Class Initialized
DEBUG - 2021-08-11 04:12:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-11 04:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-11 04:12:20 --> Controller Class Initialized
INFO - 2021-08-11 04:12:24 --> Config Class Initialized
INFO - 2021-08-11 04:12:24 --> Hooks Class Initialized
DEBUG - 2021-08-11 04:12:24 --> UTF-8 Support Enabled
INFO - 2021-08-11 04:12:24 --> Utf8 Class Initialized
INFO - 2021-08-11 04:12:24 --> URI Class Initialized
INFO - 2021-08-11 04:12:24 --> Router Class Initialized
INFO - 2021-08-11 04:12:24 --> Output Class Initialized
INFO - 2021-08-11 04:12:24 --> Security Class Initialized
DEBUG - 2021-08-11 04:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-11 04:12:24 --> Input Class Initialized
INFO - 2021-08-11 04:12:24 --> Language Class Initialized
INFO - 2021-08-11 04:12:24 --> Language Class Initialized
INFO - 2021-08-11 04:12:24 --> Config Class Initialized
INFO - 2021-08-11 04:12:24 --> Loader Class Initialized
INFO - 2021-08-11 04:12:24 --> Helper loaded: url_helper
INFO - 2021-08-11 04:12:24 --> Helper loaded: file_helper
INFO - 2021-08-11 04:12:24 --> Helper loaded: form_helper
INFO - 2021-08-11 04:12:24 --> Helper loaded: my_helper
INFO - 2021-08-11 04:12:24 --> Database Driver Class Initialized
DEBUG - 2021-08-11 04:12:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-11 04:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-11 04:12:24 --> Controller Class Initialized
INFO - 2021-08-11 04:12:24 --> Helper loaded: cookie_helper
INFO - 2021-08-11 04:12:24 --> Config Class Initialized
INFO - 2021-08-11 04:12:24 --> Hooks Class Initialized
DEBUG - 2021-08-11 04:12:24 --> UTF-8 Support Enabled
INFO - 2021-08-11 04:12:24 --> Utf8 Class Initialized
INFO - 2021-08-11 04:12:24 --> URI Class Initialized
INFO - 2021-08-11 04:12:24 --> Router Class Initialized
INFO - 2021-08-11 04:12:24 --> Output Class Initialized
INFO - 2021-08-11 04:12:24 --> Security Class Initialized
DEBUG - 2021-08-11 04:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-11 04:12:24 --> Input Class Initialized
INFO - 2021-08-11 04:12:24 --> Language Class Initialized
INFO - 2021-08-11 04:12:24 --> Language Class Initialized
INFO - 2021-08-11 04:12:24 --> Config Class Initialized
INFO - 2021-08-11 04:12:24 --> Loader Class Initialized
INFO - 2021-08-11 04:12:24 --> Helper loaded: url_helper
INFO - 2021-08-11 04:12:24 --> Helper loaded: file_helper
INFO - 2021-08-11 04:12:24 --> Helper loaded: form_helper
INFO - 2021-08-11 04:12:24 --> Helper loaded: my_helper
INFO - 2021-08-11 04:12:24 --> Database Driver Class Initialized
DEBUG - 2021-08-11 04:12:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-11 04:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-11 04:12:24 --> Controller Class Initialized
DEBUG - 2021-08-11 04:12:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-08-11 04:12:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-11 04:12:24 --> Final output sent to browser
DEBUG - 2021-08-11 04:12:24 --> Total execution time: 0.0693
INFO - 2021-08-11 04:12:29 --> Config Class Initialized
INFO - 2021-08-11 04:12:29 --> Hooks Class Initialized
DEBUG - 2021-08-11 04:12:29 --> UTF-8 Support Enabled
INFO - 2021-08-11 04:12:29 --> Utf8 Class Initialized
INFO - 2021-08-11 04:12:29 --> URI Class Initialized
INFO - 2021-08-11 04:12:29 --> Router Class Initialized
INFO - 2021-08-11 04:12:29 --> Output Class Initialized
INFO - 2021-08-11 04:12:29 --> Security Class Initialized
DEBUG - 2021-08-11 04:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-11 04:12:29 --> Input Class Initialized
INFO - 2021-08-11 04:12:29 --> Language Class Initialized
INFO - 2021-08-11 04:12:29 --> Language Class Initialized
INFO - 2021-08-11 04:12:29 --> Config Class Initialized
INFO - 2021-08-11 04:12:29 --> Loader Class Initialized
INFO - 2021-08-11 04:12:29 --> Helper loaded: url_helper
INFO - 2021-08-11 04:12:29 --> Helper loaded: file_helper
INFO - 2021-08-11 04:12:29 --> Helper loaded: form_helper
INFO - 2021-08-11 04:12:29 --> Helper loaded: my_helper
INFO - 2021-08-11 04:12:29 --> Database Driver Class Initialized
DEBUG - 2021-08-11 04:12:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-11 04:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-11 04:12:29 --> Controller Class Initialized
INFO - 2021-08-11 04:12:29 --> Helper loaded: cookie_helper
INFO - 2021-08-11 04:12:29 --> Final output sent to browser
DEBUG - 2021-08-11 04:12:29 --> Total execution time: 0.0589
INFO - 2021-08-11 04:12:29 --> Config Class Initialized
INFO - 2021-08-11 04:12:29 --> Hooks Class Initialized
DEBUG - 2021-08-11 04:12:29 --> UTF-8 Support Enabled
INFO - 2021-08-11 04:12:29 --> Utf8 Class Initialized
INFO - 2021-08-11 04:12:29 --> URI Class Initialized
INFO - 2021-08-11 04:12:29 --> Router Class Initialized
INFO - 2021-08-11 04:12:29 --> Output Class Initialized
INFO - 2021-08-11 04:12:29 --> Security Class Initialized
DEBUG - 2021-08-11 04:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-11 04:12:29 --> Input Class Initialized
INFO - 2021-08-11 04:12:29 --> Language Class Initialized
INFO - 2021-08-11 04:12:29 --> Language Class Initialized
INFO - 2021-08-11 04:12:29 --> Config Class Initialized
INFO - 2021-08-11 04:12:29 --> Loader Class Initialized
INFO - 2021-08-11 04:12:29 --> Helper loaded: url_helper
INFO - 2021-08-11 04:12:29 --> Helper loaded: file_helper
INFO - 2021-08-11 04:12:29 --> Helper loaded: form_helper
INFO - 2021-08-11 04:12:29 --> Helper loaded: my_helper
INFO - 2021-08-11 04:12:29 --> Database Driver Class Initialized
DEBUG - 2021-08-11 04:12:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-11 04:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-11 04:12:29 --> Controller Class Initialized
DEBUG - 2021-08-11 04:12:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-08-11 04:12:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-11 04:12:29 --> Final output sent to browser
DEBUG - 2021-08-11 04:12:29 --> Total execution time: 0.0945
INFO - 2021-08-11 04:12:31 --> Config Class Initialized
INFO - 2021-08-11 04:12:31 --> Hooks Class Initialized
DEBUG - 2021-08-11 04:12:31 --> UTF-8 Support Enabled
INFO - 2021-08-11 04:12:31 --> Utf8 Class Initialized
INFO - 2021-08-11 04:12:31 --> URI Class Initialized
INFO - 2021-08-11 04:12:31 --> Router Class Initialized
INFO - 2021-08-11 04:12:31 --> Output Class Initialized
INFO - 2021-08-11 04:12:31 --> Security Class Initialized
DEBUG - 2021-08-11 04:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-11 04:12:31 --> Input Class Initialized
INFO - 2021-08-11 04:12:31 --> Language Class Initialized
INFO - 2021-08-11 04:12:31 --> Language Class Initialized
INFO - 2021-08-11 04:12:31 --> Config Class Initialized
INFO - 2021-08-11 04:12:31 --> Loader Class Initialized
INFO - 2021-08-11 04:12:31 --> Helper loaded: url_helper
INFO - 2021-08-11 04:12:31 --> Helper loaded: file_helper
INFO - 2021-08-11 04:12:31 --> Helper loaded: form_helper
INFO - 2021-08-11 04:12:31 --> Helper loaded: my_helper
INFO - 2021-08-11 04:12:31 --> Database Driver Class Initialized
DEBUG - 2021-08-11 04:12:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-11 04:12:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-11 04:12:31 --> Controller Class Initialized
DEBUG - 2021-08-11 04:12:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2021-08-11 04:12:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-11 04:12:31 --> Final output sent to browser
DEBUG - 2021-08-11 04:12:31 --> Total execution time: 0.1320
INFO - 2021-08-11 04:12:32 --> Config Class Initialized
INFO - 2021-08-11 04:12:32 --> Hooks Class Initialized
DEBUG - 2021-08-11 04:12:32 --> UTF-8 Support Enabled
INFO - 2021-08-11 04:12:32 --> Utf8 Class Initialized
INFO - 2021-08-11 04:12:32 --> URI Class Initialized
INFO - 2021-08-11 04:12:32 --> Router Class Initialized
INFO - 2021-08-11 04:12:32 --> Output Class Initialized
INFO - 2021-08-11 04:12:32 --> Security Class Initialized
DEBUG - 2021-08-11 04:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-11 04:12:32 --> Input Class Initialized
INFO - 2021-08-11 04:12:32 --> Language Class Initialized
INFO - 2021-08-11 04:12:32 --> Language Class Initialized
INFO - 2021-08-11 04:12:32 --> Config Class Initialized
INFO - 2021-08-11 04:12:32 --> Loader Class Initialized
INFO - 2021-08-11 04:12:32 --> Helper loaded: url_helper
INFO - 2021-08-11 04:12:32 --> Helper loaded: file_helper
INFO - 2021-08-11 04:12:32 --> Helper loaded: form_helper
INFO - 2021-08-11 04:12:32 --> Helper loaded: my_helper
INFO - 2021-08-11 04:12:32 --> Database Driver Class Initialized
DEBUG - 2021-08-11 04:12:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-11 04:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-11 04:12:32 --> Controller Class Initialized
ERROR - 2021-08-11 04:12:32 --> Query error: Unknown column 'a.ekstra' in 'field list' - Invalid query: SELECT 
                                                    a.*, b.nama, a.ekstra, a.nilai, a.ekstra2, a.nilai2
                                                    FROM t_nilai_ekstra a
                                                    INNER JOIN m_siswa b ON a.id_siswa = b.id
                                                    INNER JOIN t_kelas_siswa c ON CONCAT(c.ta,c.id_kelas,c.id_siswa) = CONCAT('2021','1',b.id)
                                                    WHERE c.id_kelas = '1' AND a.ta = '20212'
INFO - 2021-08-11 04:12:32 --> Language file loaded: language/english/db_lang.php
INFO - 2021-08-11 04:13:14 --> Config Class Initialized
INFO - 2021-08-11 04:13:14 --> Hooks Class Initialized
DEBUG - 2021-08-11 04:13:14 --> UTF-8 Support Enabled
INFO - 2021-08-11 04:13:14 --> Utf8 Class Initialized
INFO - 2021-08-11 04:13:14 --> URI Class Initialized
INFO - 2021-08-11 04:13:14 --> Router Class Initialized
INFO - 2021-08-11 04:13:14 --> Output Class Initialized
INFO - 2021-08-11 04:13:14 --> Security Class Initialized
DEBUG - 2021-08-11 04:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-11 04:13:14 --> Input Class Initialized
INFO - 2021-08-11 04:13:14 --> Language Class Initialized
INFO - 2021-08-11 04:13:14 --> Language Class Initialized
INFO - 2021-08-11 04:13:14 --> Config Class Initialized
INFO - 2021-08-11 04:13:14 --> Loader Class Initialized
INFO - 2021-08-11 04:13:14 --> Helper loaded: url_helper
INFO - 2021-08-11 04:13:14 --> Helper loaded: file_helper
INFO - 2021-08-11 04:13:14 --> Helper loaded: form_helper
INFO - 2021-08-11 04:13:14 --> Helper loaded: my_helper
INFO - 2021-08-11 04:13:14 --> Database Driver Class Initialized
DEBUG - 2021-08-11 04:13:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-11 04:13:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-11 04:13:14 --> Controller Class Initialized
ERROR - 2021-08-11 04:13:14 --> Query error: Unknown column 'a.ekstra' in 'field list' - Invalid query: SELECT 
                                                    a.*, b.nama, a.ekstra, a.nilai, a.ekstra2, a.nilai2
                                                    FROM t_nilai_ekstra a
                                                    INNER JOIN m_siswa b ON a.id_siswa = b.id
                                                    INNER JOIN t_kelas_siswa c ON CONCAT(c.ta,c.id_kelas,c.id_siswa) = CONCAT('2021','1',b.id)
                                                    WHERE c.id_kelas = '1' AND a.ta = '20212'
INFO - 2021-08-11 04:13:14 --> Language file loaded: language/english/db_lang.php
INFO - 2021-08-11 04:13:15 --> Config Class Initialized
INFO - 2021-08-11 04:13:15 --> Hooks Class Initialized
DEBUG - 2021-08-11 04:13:15 --> UTF-8 Support Enabled
INFO - 2021-08-11 04:13:15 --> Utf8 Class Initialized
INFO - 2021-08-11 04:13:15 --> URI Class Initialized
INFO - 2021-08-11 04:13:15 --> Router Class Initialized
INFO - 2021-08-11 04:13:15 --> Output Class Initialized
INFO - 2021-08-11 04:13:15 --> Security Class Initialized
DEBUG - 2021-08-11 04:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-11 04:13:15 --> Input Class Initialized
INFO - 2021-08-11 04:13:15 --> Language Class Initialized
INFO - 2021-08-11 04:13:15 --> Language Class Initialized
INFO - 2021-08-11 04:13:15 --> Config Class Initialized
INFO - 2021-08-11 04:13:15 --> Loader Class Initialized
INFO - 2021-08-11 04:13:15 --> Helper loaded: url_helper
INFO - 2021-08-11 04:13:15 --> Helper loaded: file_helper
INFO - 2021-08-11 04:13:15 --> Helper loaded: form_helper
INFO - 2021-08-11 04:13:15 --> Helper loaded: my_helper
INFO - 2021-08-11 04:13:15 --> Database Driver Class Initialized
DEBUG - 2021-08-11 04:13:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-11 04:13:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-11 04:13:15 --> Controller Class Initialized
ERROR - 2021-08-11 04:13:15 --> Query error: Unknown column 'a.ekstra' in 'field list' - Invalid query: SELECT 
                                                    a.*, b.nama, a.ekstra, a.nilai, a.ekstra2, a.nilai2
                                                    FROM t_nilai_ekstra a
                                                    INNER JOIN m_siswa b ON a.id_siswa = b.id
                                                    INNER JOIN t_kelas_siswa c ON CONCAT(c.ta,c.id_kelas,c.id_siswa) = CONCAT('2021','1',b.id)
                                                    WHERE c.id_kelas = '1' AND a.ta = '20212'
INFO - 2021-08-11 04:13:15 --> Language file loaded: language/english/db_lang.php
