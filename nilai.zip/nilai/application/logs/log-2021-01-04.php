<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-01-04 01:18:21 --> Config Class Initialized
INFO - 2021-01-04 01:18:21 --> Hooks Class Initialized
DEBUG - 2021-01-04 01:18:21 --> UTF-8 Support Enabled
INFO - 2021-01-04 01:18:21 --> Utf8 Class Initialized
INFO - 2021-01-04 01:18:21 --> URI Class Initialized
DEBUG - 2021-01-04 01:18:22 --> No URI present. Default controller set.
INFO - 2021-01-04 01:18:22 --> Router Class Initialized
INFO - 2021-01-04 01:18:22 --> Output Class Initialized
INFO - 2021-01-04 01:18:22 --> Security Class Initialized
DEBUG - 2021-01-04 01:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 01:18:22 --> Input Class Initialized
INFO - 2021-01-04 01:18:22 --> Language Class Initialized
INFO - 2021-01-04 01:18:23 --> Language Class Initialized
INFO - 2021-01-04 01:18:23 --> Config Class Initialized
INFO - 2021-01-04 01:18:23 --> Loader Class Initialized
INFO - 2021-01-04 01:18:23 --> Helper loaded: url_helper
INFO - 2021-01-04 01:18:23 --> Helper loaded: file_helper
INFO - 2021-01-04 01:18:23 --> Helper loaded: form_helper
INFO - 2021-01-04 01:18:23 --> Helper loaded: my_helper
INFO - 2021-01-04 01:18:23 --> Database Driver Class Initialized
DEBUG - 2021-01-04 01:18:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 01:18:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 01:18:24 --> Controller Class Initialized
INFO - 2021-01-04 01:18:24 --> Config Class Initialized
INFO - 2021-01-04 01:18:24 --> Hooks Class Initialized
DEBUG - 2021-01-04 01:18:24 --> UTF-8 Support Enabled
INFO - 2021-01-04 01:18:24 --> Utf8 Class Initialized
INFO - 2021-01-04 01:18:24 --> URI Class Initialized
INFO - 2021-01-04 01:18:24 --> Router Class Initialized
INFO - 2021-01-04 01:18:24 --> Output Class Initialized
INFO - 2021-01-04 01:18:24 --> Security Class Initialized
DEBUG - 2021-01-04 01:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 01:18:24 --> Input Class Initialized
INFO - 2021-01-04 01:18:24 --> Language Class Initialized
INFO - 2021-01-04 01:18:24 --> Language Class Initialized
INFO - 2021-01-04 01:18:24 --> Config Class Initialized
INFO - 2021-01-04 01:18:24 --> Loader Class Initialized
INFO - 2021-01-04 01:18:24 --> Helper loaded: url_helper
INFO - 2021-01-04 01:18:24 --> Helper loaded: file_helper
INFO - 2021-01-04 01:18:24 --> Helper loaded: form_helper
INFO - 2021-01-04 01:18:24 --> Helper loaded: my_helper
INFO - 2021-01-04 01:18:24 --> Database Driver Class Initialized
DEBUG - 2021-01-04 01:18:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 01:18:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 01:18:25 --> Controller Class Initialized
DEBUG - 2021-01-04 01:18:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-04 01:18:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-04 01:18:25 --> Final output sent to browser
DEBUG - 2021-01-04 01:18:25 --> Total execution time: 0.9941
INFO - 2021-01-04 01:18:34 --> Config Class Initialized
INFO - 2021-01-04 01:18:34 --> Hooks Class Initialized
DEBUG - 2021-01-04 01:18:34 --> UTF-8 Support Enabled
INFO - 2021-01-04 01:18:34 --> Utf8 Class Initialized
INFO - 2021-01-04 01:18:34 --> URI Class Initialized
INFO - 2021-01-04 01:18:34 --> Router Class Initialized
INFO - 2021-01-04 01:18:34 --> Output Class Initialized
INFO - 2021-01-04 01:18:34 --> Security Class Initialized
DEBUG - 2021-01-04 01:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 01:18:34 --> Input Class Initialized
INFO - 2021-01-04 01:18:34 --> Language Class Initialized
INFO - 2021-01-04 01:18:34 --> Language Class Initialized
INFO - 2021-01-04 01:18:34 --> Config Class Initialized
INFO - 2021-01-04 01:18:34 --> Loader Class Initialized
INFO - 2021-01-04 01:18:34 --> Helper loaded: url_helper
INFO - 2021-01-04 01:18:34 --> Helper loaded: file_helper
INFO - 2021-01-04 01:18:35 --> Helper loaded: form_helper
INFO - 2021-01-04 01:18:35 --> Helper loaded: my_helper
INFO - 2021-01-04 01:18:35 --> Database Driver Class Initialized
DEBUG - 2021-01-04 01:18:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 01:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 01:18:35 --> Controller Class Initialized
INFO - 2021-01-04 01:18:35 --> Helper loaded: cookie_helper
INFO - 2021-01-04 01:18:35 --> Final output sent to browser
DEBUG - 2021-01-04 01:18:35 --> Total execution time: 1.5049
INFO - 2021-01-04 01:18:36 --> Config Class Initialized
INFO - 2021-01-04 01:18:36 --> Hooks Class Initialized
DEBUG - 2021-01-04 01:18:36 --> UTF-8 Support Enabled
INFO - 2021-01-04 01:18:36 --> Utf8 Class Initialized
INFO - 2021-01-04 01:18:36 --> URI Class Initialized
INFO - 2021-01-04 01:18:36 --> Router Class Initialized
INFO - 2021-01-04 01:18:36 --> Output Class Initialized
INFO - 2021-01-04 01:18:36 --> Security Class Initialized
DEBUG - 2021-01-04 01:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 01:18:36 --> Input Class Initialized
INFO - 2021-01-04 01:18:36 --> Language Class Initialized
INFO - 2021-01-04 01:18:36 --> Language Class Initialized
INFO - 2021-01-04 01:18:36 --> Config Class Initialized
INFO - 2021-01-04 01:18:36 --> Loader Class Initialized
INFO - 2021-01-04 01:18:36 --> Helper loaded: url_helper
INFO - 2021-01-04 01:18:36 --> Helper loaded: file_helper
INFO - 2021-01-04 01:18:37 --> Helper loaded: form_helper
INFO - 2021-01-04 01:18:37 --> Helper loaded: my_helper
INFO - 2021-01-04 01:18:37 --> Database Driver Class Initialized
DEBUG - 2021-01-04 01:18:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 01:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 01:18:37 --> Controller Class Initialized
DEBUG - 2021-01-04 01:18:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-04 01:18:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-04 01:18:37 --> Final output sent to browser
DEBUG - 2021-01-04 01:18:38 --> Total execution time: 1.6735
INFO - 2021-01-04 02:11:28 --> Config Class Initialized
INFO - 2021-01-04 02:11:28 --> Hooks Class Initialized
DEBUG - 2021-01-04 02:11:28 --> UTF-8 Support Enabled
INFO - 2021-01-04 02:11:28 --> Utf8 Class Initialized
INFO - 2021-01-04 02:11:28 --> URI Class Initialized
INFO - 2021-01-04 02:11:28 --> Router Class Initialized
INFO - 2021-01-04 02:11:28 --> Output Class Initialized
INFO - 2021-01-04 02:11:28 --> Security Class Initialized
DEBUG - 2021-01-04 02:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 02:11:28 --> Input Class Initialized
INFO - 2021-01-04 02:11:28 --> Language Class Initialized
INFO - 2021-01-04 02:11:28 --> Language Class Initialized
INFO - 2021-01-04 02:11:28 --> Config Class Initialized
INFO - 2021-01-04 02:11:28 --> Loader Class Initialized
INFO - 2021-01-04 02:11:28 --> Helper loaded: url_helper
INFO - 2021-01-04 02:11:28 --> Helper loaded: file_helper
INFO - 2021-01-04 02:11:28 --> Helper loaded: form_helper
INFO - 2021-01-04 02:11:28 --> Helper loaded: my_helper
INFO - 2021-01-04 02:11:28 --> Database Driver Class Initialized
DEBUG - 2021-01-04 02:11:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 02:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 02:11:29 --> Controller Class Initialized
DEBUG - 2021-01-04 02:11:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-04 02:11:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-04 02:11:29 --> Final output sent to browser
DEBUG - 2021-01-04 02:11:29 --> Total execution time: 1.2591
INFO - 2021-01-04 02:11:30 --> Config Class Initialized
INFO - 2021-01-04 02:11:30 --> Hooks Class Initialized
DEBUG - 2021-01-04 02:11:30 --> UTF-8 Support Enabled
INFO - 2021-01-04 02:11:30 --> Utf8 Class Initialized
INFO - 2021-01-04 02:11:30 --> URI Class Initialized
INFO - 2021-01-04 02:11:30 --> Router Class Initialized
INFO - 2021-01-04 02:11:30 --> Output Class Initialized
INFO - 2021-01-04 02:11:30 --> Security Class Initialized
DEBUG - 2021-01-04 02:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 02:11:30 --> Input Class Initialized
INFO - 2021-01-04 02:11:30 --> Language Class Initialized
INFO - 2021-01-04 02:11:30 --> Language Class Initialized
INFO - 2021-01-04 02:11:31 --> Config Class Initialized
INFO - 2021-01-04 02:11:31 --> Loader Class Initialized
INFO - 2021-01-04 02:11:31 --> Helper loaded: url_helper
INFO - 2021-01-04 02:11:31 --> Helper loaded: file_helper
INFO - 2021-01-04 02:11:31 --> Helper loaded: form_helper
INFO - 2021-01-04 02:11:31 --> Helper loaded: my_helper
INFO - 2021-01-04 02:11:31 --> Database Driver Class Initialized
DEBUG - 2021-01-04 02:11:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 02:11:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 02:11:31 --> Controller Class Initialized
ERROR - 2021-01-04 02:11:32 --> Severity: Notice --> Undefined variable: _nilai_final C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 265
DEBUG - 2021-01-04 02:11:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 02:11:32 --> Final output sent to browser
DEBUG - 2021-01-04 02:11:32 --> Total execution time: 1.8114
INFO - 2021-01-04 02:15:17 --> Config Class Initialized
INFO - 2021-01-04 02:15:17 --> Hooks Class Initialized
DEBUG - 2021-01-04 02:15:17 --> UTF-8 Support Enabled
INFO - 2021-01-04 02:15:17 --> Utf8 Class Initialized
INFO - 2021-01-04 02:15:17 --> URI Class Initialized
INFO - 2021-01-04 02:15:17 --> Router Class Initialized
INFO - 2021-01-04 02:15:17 --> Output Class Initialized
INFO - 2021-01-04 02:15:17 --> Security Class Initialized
DEBUG - 2021-01-04 02:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 02:15:17 --> Input Class Initialized
INFO - 2021-01-04 02:15:17 --> Language Class Initialized
ERROR - 2021-01-04 02:15:17 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 531
INFO - 2021-01-04 02:20:09 --> Config Class Initialized
INFO - 2021-01-04 02:20:09 --> Hooks Class Initialized
DEBUG - 2021-01-04 02:20:10 --> UTF-8 Support Enabled
INFO - 2021-01-04 02:20:10 --> Utf8 Class Initialized
INFO - 2021-01-04 02:20:10 --> URI Class Initialized
INFO - 2021-01-04 02:20:10 --> Router Class Initialized
INFO - 2021-01-04 02:20:10 --> Output Class Initialized
INFO - 2021-01-04 02:20:10 --> Security Class Initialized
DEBUG - 2021-01-04 02:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 02:20:10 --> Input Class Initialized
INFO - 2021-01-04 02:20:10 --> Language Class Initialized
ERROR - 2021-01-04 02:20:10 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 531
INFO - 2021-01-04 02:27:07 --> Config Class Initialized
INFO - 2021-01-04 02:27:07 --> Hooks Class Initialized
DEBUG - 2021-01-04 02:27:07 --> UTF-8 Support Enabled
INFO - 2021-01-04 02:27:07 --> Utf8 Class Initialized
INFO - 2021-01-04 02:27:07 --> URI Class Initialized
INFO - 2021-01-04 02:27:07 --> Router Class Initialized
INFO - 2021-01-04 02:27:07 --> Output Class Initialized
INFO - 2021-01-04 02:27:07 --> Security Class Initialized
DEBUG - 2021-01-04 02:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 02:27:08 --> Input Class Initialized
INFO - 2021-01-04 02:27:08 --> Language Class Initialized
ERROR - 2021-01-04 02:27:08 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 550
INFO - 2021-01-04 02:28:17 --> Config Class Initialized
INFO - 2021-01-04 02:28:17 --> Hooks Class Initialized
DEBUG - 2021-01-04 02:28:17 --> UTF-8 Support Enabled
INFO - 2021-01-04 02:28:17 --> Utf8 Class Initialized
INFO - 2021-01-04 02:28:17 --> URI Class Initialized
INFO - 2021-01-04 02:28:17 --> Router Class Initialized
INFO - 2021-01-04 02:28:17 --> Output Class Initialized
INFO - 2021-01-04 02:28:17 --> Security Class Initialized
DEBUG - 2021-01-04 02:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 02:28:17 --> Input Class Initialized
INFO - 2021-01-04 02:28:17 --> Language Class Initialized
INFO - 2021-01-04 02:28:17 --> Language Class Initialized
INFO - 2021-01-04 02:28:17 --> Config Class Initialized
INFO - 2021-01-04 02:28:17 --> Loader Class Initialized
INFO - 2021-01-04 02:28:17 --> Helper loaded: url_helper
INFO - 2021-01-04 02:28:17 --> Helper loaded: file_helper
INFO - 2021-01-04 02:28:17 --> Helper loaded: form_helper
INFO - 2021-01-04 02:28:17 --> Helper loaded: my_helper
INFO - 2021-01-04 02:28:17 --> Database Driver Class Initialized
DEBUG - 2021-01-04 02:28:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 02:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 02:28:18 --> Controller Class Initialized
DEBUG - 2021-01-04 02:28:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 02:28:18 --> Final output sent to browser
DEBUG - 2021-01-04 02:28:18 --> Total execution time: 0.8298
INFO - 2021-01-04 02:34:39 --> Config Class Initialized
INFO - 2021-01-04 02:34:39 --> Hooks Class Initialized
DEBUG - 2021-01-04 02:34:39 --> UTF-8 Support Enabled
INFO - 2021-01-04 02:34:39 --> Utf8 Class Initialized
INFO - 2021-01-04 02:34:39 --> URI Class Initialized
INFO - 2021-01-04 02:34:39 --> Router Class Initialized
INFO - 2021-01-04 02:34:39 --> Output Class Initialized
INFO - 2021-01-04 02:34:39 --> Security Class Initialized
DEBUG - 2021-01-04 02:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 02:34:39 --> Input Class Initialized
INFO - 2021-01-04 02:34:39 --> Language Class Initialized
INFO - 2021-01-04 02:34:39 --> Language Class Initialized
INFO - 2021-01-04 02:34:39 --> Config Class Initialized
INFO - 2021-01-04 02:34:40 --> Loader Class Initialized
INFO - 2021-01-04 02:34:40 --> Helper loaded: url_helper
INFO - 2021-01-04 02:34:40 --> Helper loaded: file_helper
INFO - 2021-01-04 02:34:40 --> Helper loaded: form_helper
INFO - 2021-01-04 02:34:40 --> Helper loaded: my_helper
INFO - 2021-01-04 02:34:40 --> Database Driver Class Initialized
DEBUG - 2021-01-04 02:34:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 02:34:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 02:34:40 --> Controller Class Initialized
DEBUG - 2021-01-04 02:34:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 02:34:40 --> Final output sent to browser
DEBUG - 2021-01-04 02:34:40 --> Total execution time: 0.9556
INFO - 2021-01-04 02:36:45 --> Config Class Initialized
INFO - 2021-01-04 02:36:45 --> Hooks Class Initialized
DEBUG - 2021-01-04 02:36:45 --> UTF-8 Support Enabled
INFO - 2021-01-04 02:36:45 --> Utf8 Class Initialized
INFO - 2021-01-04 02:36:45 --> URI Class Initialized
INFO - 2021-01-04 02:36:45 --> Router Class Initialized
INFO - 2021-01-04 02:36:46 --> Output Class Initialized
INFO - 2021-01-04 02:36:46 --> Security Class Initialized
DEBUG - 2021-01-04 02:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 02:36:46 --> Input Class Initialized
INFO - 2021-01-04 02:36:46 --> Language Class Initialized
INFO - 2021-01-04 02:36:46 --> Language Class Initialized
INFO - 2021-01-04 02:36:46 --> Config Class Initialized
INFO - 2021-01-04 02:36:46 --> Loader Class Initialized
INFO - 2021-01-04 02:36:46 --> Helper loaded: url_helper
INFO - 2021-01-04 02:36:46 --> Helper loaded: file_helper
INFO - 2021-01-04 02:36:46 --> Helper loaded: form_helper
INFO - 2021-01-04 02:36:46 --> Helper loaded: my_helper
INFO - 2021-01-04 02:36:46 --> Database Driver Class Initialized
DEBUG - 2021-01-04 02:36:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 02:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 02:36:46 --> Controller Class Initialized
DEBUG - 2021-01-04 02:36:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 02:36:46 --> Final output sent to browser
DEBUG - 2021-01-04 02:36:46 --> Total execution time: 0.8409
INFO - 2021-01-04 02:45:56 --> Config Class Initialized
INFO - 2021-01-04 02:45:56 --> Hooks Class Initialized
DEBUG - 2021-01-04 02:45:56 --> UTF-8 Support Enabled
INFO - 2021-01-04 02:45:56 --> Utf8 Class Initialized
INFO - 2021-01-04 02:45:56 --> URI Class Initialized
INFO - 2021-01-04 02:45:56 --> Router Class Initialized
INFO - 2021-01-04 02:45:56 --> Output Class Initialized
INFO - 2021-01-04 02:45:56 --> Security Class Initialized
DEBUG - 2021-01-04 02:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 02:45:56 --> Input Class Initialized
INFO - 2021-01-04 02:45:56 --> Language Class Initialized
INFO - 2021-01-04 02:45:56 --> Language Class Initialized
INFO - 2021-01-04 02:45:56 --> Config Class Initialized
INFO - 2021-01-04 02:45:56 --> Loader Class Initialized
INFO - 2021-01-04 02:45:56 --> Helper loaded: url_helper
INFO - 2021-01-04 02:45:56 --> Helper loaded: file_helper
INFO - 2021-01-04 02:45:56 --> Helper loaded: form_helper
INFO - 2021-01-04 02:45:56 --> Helper loaded: my_helper
INFO - 2021-01-04 02:45:56 --> Database Driver Class Initialized
DEBUG - 2021-01-04 02:45:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 02:45:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 02:45:56 --> Controller Class Initialized
DEBUG - 2021-01-04 02:45:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 02:45:57 --> Final output sent to browser
DEBUG - 2021-01-04 02:45:57 --> Total execution time: 0.5512
INFO - 2021-01-04 02:46:00 --> Config Class Initialized
INFO - 2021-01-04 02:46:00 --> Hooks Class Initialized
DEBUG - 2021-01-04 02:46:00 --> UTF-8 Support Enabled
INFO - 2021-01-04 02:46:00 --> Utf8 Class Initialized
INFO - 2021-01-04 02:46:00 --> URI Class Initialized
INFO - 2021-01-04 02:46:00 --> Router Class Initialized
INFO - 2021-01-04 02:46:00 --> Output Class Initialized
INFO - 2021-01-04 02:46:00 --> Security Class Initialized
DEBUG - 2021-01-04 02:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 02:46:00 --> Input Class Initialized
INFO - 2021-01-04 02:46:00 --> Language Class Initialized
INFO - 2021-01-04 02:46:00 --> Language Class Initialized
INFO - 2021-01-04 02:46:00 --> Config Class Initialized
INFO - 2021-01-04 02:46:00 --> Loader Class Initialized
INFO - 2021-01-04 02:46:00 --> Helper loaded: url_helper
INFO - 2021-01-04 02:46:00 --> Helper loaded: file_helper
INFO - 2021-01-04 02:46:00 --> Helper loaded: form_helper
INFO - 2021-01-04 02:46:01 --> Helper loaded: my_helper
INFO - 2021-01-04 02:46:01 --> Database Driver Class Initialized
DEBUG - 2021-01-04 02:46:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 02:46:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 02:46:01 --> Controller Class Initialized
DEBUG - 2021-01-04 02:46:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 02:46:01 --> Final output sent to browser
DEBUG - 2021-01-04 02:46:01 --> Total execution time: 0.3545
INFO - 2021-01-04 02:46:25 --> Config Class Initialized
INFO - 2021-01-04 02:46:25 --> Hooks Class Initialized
DEBUG - 2021-01-04 02:46:25 --> UTF-8 Support Enabled
INFO - 2021-01-04 02:46:25 --> Utf8 Class Initialized
INFO - 2021-01-04 02:46:25 --> URI Class Initialized
INFO - 2021-01-04 02:46:25 --> Router Class Initialized
INFO - 2021-01-04 02:46:25 --> Output Class Initialized
INFO - 2021-01-04 02:46:25 --> Security Class Initialized
DEBUG - 2021-01-04 02:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 02:46:25 --> Input Class Initialized
INFO - 2021-01-04 02:46:25 --> Language Class Initialized
INFO - 2021-01-04 02:46:25 --> Language Class Initialized
INFO - 2021-01-04 02:46:25 --> Config Class Initialized
INFO - 2021-01-04 02:46:25 --> Loader Class Initialized
INFO - 2021-01-04 02:46:25 --> Helper loaded: url_helper
INFO - 2021-01-04 02:46:25 --> Helper loaded: file_helper
INFO - 2021-01-04 02:46:25 --> Helper loaded: form_helper
INFO - 2021-01-04 02:46:25 --> Helper loaded: my_helper
INFO - 2021-01-04 02:46:26 --> Database Driver Class Initialized
DEBUG - 2021-01-04 02:46:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 02:46:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 02:46:26 --> Controller Class Initialized
DEBUG - 2021-01-04 02:46:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-01-04 02:46:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-04 02:46:26 --> Final output sent to browser
DEBUG - 2021-01-04 02:46:26 --> Total execution time: 0.3803
INFO - 2021-01-04 02:46:27 --> Config Class Initialized
INFO - 2021-01-04 02:46:27 --> Hooks Class Initialized
DEBUG - 2021-01-04 02:46:27 --> UTF-8 Support Enabled
INFO - 2021-01-04 02:46:27 --> Utf8 Class Initialized
INFO - 2021-01-04 02:46:27 --> URI Class Initialized
INFO - 2021-01-04 02:46:27 --> Router Class Initialized
INFO - 2021-01-04 02:46:27 --> Output Class Initialized
INFO - 2021-01-04 02:46:27 --> Security Class Initialized
DEBUG - 2021-01-04 02:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 02:46:27 --> Input Class Initialized
INFO - 2021-01-04 02:46:27 --> Language Class Initialized
INFO - 2021-01-04 02:46:27 --> Language Class Initialized
INFO - 2021-01-04 02:46:27 --> Config Class Initialized
INFO - 2021-01-04 02:46:27 --> Loader Class Initialized
INFO - 2021-01-04 02:46:27 --> Helper loaded: url_helper
INFO - 2021-01-04 02:46:27 --> Helper loaded: file_helper
INFO - 2021-01-04 02:46:27 --> Helper loaded: form_helper
INFO - 2021-01-04 02:46:27 --> Helper loaded: my_helper
INFO - 2021-01-04 02:46:27 --> Database Driver Class Initialized
DEBUG - 2021-01-04 02:46:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 02:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 02:46:27 --> Controller Class Initialized
INFO - 2021-01-04 02:46:27 --> Final output sent to browser
DEBUG - 2021-01-04 02:46:28 --> Total execution time: 0.3764
INFO - 2021-01-04 02:48:00 --> Config Class Initialized
INFO - 2021-01-04 02:48:00 --> Hooks Class Initialized
DEBUG - 2021-01-04 02:48:00 --> UTF-8 Support Enabled
INFO - 2021-01-04 02:48:00 --> Utf8 Class Initialized
INFO - 2021-01-04 02:48:00 --> URI Class Initialized
INFO - 2021-01-04 02:48:00 --> Router Class Initialized
INFO - 2021-01-04 02:48:00 --> Output Class Initialized
INFO - 2021-01-04 02:48:00 --> Security Class Initialized
DEBUG - 2021-01-04 02:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 02:48:00 --> Input Class Initialized
INFO - 2021-01-04 02:48:00 --> Language Class Initialized
INFO - 2021-01-04 02:48:00 --> Language Class Initialized
INFO - 2021-01-04 02:48:00 --> Config Class Initialized
INFO - 2021-01-04 02:48:00 --> Loader Class Initialized
INFO - 2021-01-04 02:48:00 --> Helper loaded: url_helper
INFO - 2021-01-04 02:48:01 --> Helper loaded: file_helper
INFO - 2021-01-04 02:48:01 --> Helper loaded: form_helper
INFO - 2021-01-04 02:48:01 --> Helper loaded: my_helper
INFO - 2021-01-04 02:48:01 --> Database Driver Class Initialized
DEBUG - 2021-01-04 02:48:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 02:48:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 02:48:01 --> Controller Class Initialized
DEBUG - 2021-01-04 02:48:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-01-04 02:48:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-04 02:48:01 --> Final output sent to browser
DEBUG - 2021-01-04 02:48:01 --> Total execution time: 1.1320
INFO - 2021-01-04 02:48:02 --> Config Class Initialized
INFO - 2021-01-04 02:48:02 --> Hooks Class Initialized
DEBUG - 2021-01-04 02:48:02 --> UTF-8 Support Enabled
INFO - 2021-01-04 02:48:02 --> Utf8 Class Initialized
INFO - 2021-01-04 02:48:02 --> URI Class Initialized
INFO - 2021-01-04 02:48:02 --> Router Class Initialized
INFO - 2021-01-04 02:48:02 --> Output Class Initialized
INFO - 2021-01-04 02:48:02 --> Security Class Initialized
DEBUG - 2021-01-04 02:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 02:48:02 --> Input Class Initialized
INFO - 2021-01-04 02:48:03 --> Language Class Initialized
INFO - 2021-01-04 02:48:03 --> Language Class Initialized
INFO - 2021-01-04 02:48:03 --> Config Class Initialized
INFO - 2021-01-04 02:48:03 --> Loader Class Initialized
INFO - 2021-01-04 02:48:03 --> Helper loaded: url_helper
INFO - 2021-01-04 02:48:03 --> Helper loaded: file_helper
INFO - 2021-01-04 02:48:03 --> Helper loaded: form_helper
INFO - 2021-01-04 02:48:03 --> Helper loaded: my_helper
INFO - 2021-01-04 02:48:03 --> Database Driver Class Initialized
DEBUG - 2021-01-04 02:48:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 02:48:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 02:48:03 --> Controller Class Initialized
INFO - 2021-01-04 02:48:03 --> Final output sent to browser
DEBUG - 2021-01-04 02:48:03 --> Total execution time: 0.9589
INFO - 2021-01-04 02:48:24 --> Config Class Initialized
INFO - 2021-01-04 02:48:25 --> Hooks Class Initialized
DEBUG - 2021-01-04 02:48:25 --> UTF-8 Support Enabled
INFO - 2021-01-04 02:48:25 --> Utf8 Class Initialized
INFO - 2021-01-04 02:48:25 --> URI Class Initialized
INFO - 2021-01-04 02:48:25 --> Router Class Initialized
INFO - 2021-01-04 02:48:25 --> Output Class Initialized
INFO - 2021-01-04 02:48:25 --> Security Class Initialized
DEBUG - 2021-01-04 02:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 02:48:25 --> Input Class Initialized
INFO - 2021-01-04 02:48:25 --> Language Class Initialized
INFO - 2021-01-04 02:48:25 --> Language Class Initialized
INFO - 2021-01-04 02:48:25 --> Config Class Initialized
INFO - 2021-01-04 02:48:25 --> Loader Class Initialized
INFO - 2021-01-04 02:48:25 --> Helper loaded: url_helper
INFO - 2021-01-04 02:48:25 --> Helper loaded: file_helper
INFO - 2021-01-04 02:48:25 --> Helper loaded: form_helper
INFO - 2021-01-04 02:48:25 --> Helper loaded: my_helper
INFO - 2021-01-04 02:48:25 --> Database Driver Class Initialized
DEBUG - 2021-01-04 02:48:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 02:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 02:48:25 --> Controller Class Initialized
INFO - 2021-01-04 02:48:25 --> Final output sent to browser
DEBUG - 2021-01-04 02:48:25 --> Total execution time: 0.5722
INFO - 2021-01-04 02:48:28 --> Config Class Initialized
INFO - 2021-01-04 02:48:28 --> Hooks Class Initialized
DEBUG - 2021-01-04 02:48:28 --> UTF-8 Support Enabled
INFO - 2021-01-04 02:48:28 --> Utf8 Class Initialized
INFO - 2021-01-04 02:48:28 --> URI Class Initialized
INFO - 2021-01-04 02:48:28 --> Router Class Initialized
INFO - 2021-01-04 02:48:28 --> Output Class Initialized
INFO - 2021-01-04 02:48:28 --> Security Class Initialized
DEBUG - 2021-01-04 02:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 02:48:28 --> Input Class Initialized
INFO - 2021-01-04 02:48:28 --> Language Class Initialized
INFO - 2021-01-04 02:48:28 --> Language Class Initialized
INFO - 2021-01-04 02:48:28 --> Config Class Initialized
INFO - 2021-01-04 02:48:28 --> Loader Class Initialized
INFO - 2021-01-04 02:48:28 --> Helper loaded: url_helper
INFO - 2021-01-04 02:48:28 --> Helper loaded: file_helper
INFO - 2021-01-04 02:48:28 --> Helper loaded: form_helper
INFO - 2021-01-04 02:48:28 --> Helper loaded: my_helper
INFO - 2021-01-04 02:48:28 --> Database Driver Class Initialized
DEBUG - 2021-01-04 02:48:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 02:48:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 02:48:28 --> Controller Class Initialized
DEBUG - 2021-01-04 02:48:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 02:48:28 --> Final output sent to browser
DEBUG - 2021-01-04 02:48:28 --> Total execution time: 0.4901
INFO - 2021-01-04 02:53:38 --> Config Class Initialized
INFO - 2021-01-04 02:53:38 --> Hooks Class Initialized
DEBUG - 2021-01-04 02:53:38 --> UTF-8 Support Enabled
INFO - 2021-01-04 02:53:38 --> Utf8 Class Initialized
INFO - 2021-01-04 02:53:38 --> URI Class Initialized
INFO - 2021-01-04 02:53:38 --> Router Class Initialized
INFO - 2021-01-04 02:53:38 --> Output Class Initialized
INFO - 2021-01-04 02:53:38 --> Security Class Initialized
DEBUG - 2021-01-04 02:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 02:53:38 --> Input Class Initialized
INFO - 2021-01-04 02:53:38 --> Language Class Initialized
INFO - 2021-01-04 02:53:38 --> Language Class Initialized
INFO - 2021-01-04 02:53:39 --> Config Class Initialized
INFO - 2021-01-04 02:53:39 --> Loader Class Initialized
INFO - 2021-01-04 02:53:39 --> Helper loaded: url_helper
INFO - 2021-01-04 02:53:39 --> Helper loaded: file_helper
INFO - 2021-01-04 02:53:39 --> Helper loaded: form_helper
INFO - 2021-01-04 02:53:39 --> Helper loaded: my_helper
INFO - 2021-01-04 02:53:39 --> Database Driver Class Initialized
DEBUG - 2021-01-04 02:53:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 02:53:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 02:53:39 --> Controller Class Initialized
INFO - 2021-01-04 02:53:39 --> Helper loaded: cookie_helper
INFO - 2021-01-04 02:53:39 --> Config Class Initialized
INFO - 2021-01-04 02:53:39 --> Hooks Class Initialized
DEBUG - 2021-01-04 02:53:39 --> UTF-8 Support Enabled
INFO - 2021-01-04 02:53:39 --> Utf8 Class Initialized
INFO - 2021-01-04 02:53:39 --> URI Class Initialized
INFO - 2021-01-04 02:53:39 --> Router Class Initialized
INFO - 2021-01-04 02:53:39 --> Output Class Initialized
INFO - 2021-01-04 02:53:39 --> Security Class Initialized
DEBUG - 2021-01-04 02:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 02:53:39 --> Input Class Initialized
INFO - 2021-01-04 02:53:39 --> Language Class Initialized
INFO - 2021-01-04 02:53:39 --> Language Class Initialized
INFO - 2021-01-04 02:53:39 --> Config Class Initialized
INFO - 2021-01-04 02:53:39 --> Loader Class Initialized
INFO - 2021-01-04 02:53:39 --> Helper loaded: url_helper
INFO - 2021-01-04 02:53:39 --> Helper loaded: file_helper
INFO - 2021-01-04 02:53:39 --> Helper loaded: form_helper
INFO - 2021-01-04 02:53:39 --> Helper loaded: my_helper
INFO - 2021-01-04 02:53:39 --> Database Driver Class Initialized
DEBUG - 2021-01-04 02:53:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 02:53:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 02:53:39 --> Controller Class Initialized
DEBUG - 2021-01-04 02:53:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-04 02:53:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-04 02:53:39 --> Final output sent to browser
DEBUG - 2021-01-04 02:53:39 --> Total execution time: 0.6044
INFO - 2021-01-04 02:53:44 --> Config Class Initialized
INFO - 2021-01-04 02:53:44 --> Hooks Class Initialized
DEBUG - 2021-01-04 02:53:44 --> UTF-8 Support Enabled
INFO - 2021-01-04 02:53:44 --> Utf8 Class Initialized
INFO - 2021-01-04 02:53:44 --> URI Class Initialized
INFO - 2021-01-04 02:53:44 --> Router Class Initialized
INFO - 2021-01-04 02:53:44 --> Output Class Initialized
INFO - 2021-01-04 02:53:45 --> Security Class Initialized
DEBUG - 2021-01-04 02:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 02:53:45 --> Input Class Initialized
INFO - 2021-01-04 02:53:45 --> Language Class Initialized
INFO - 2021-01-04 02:53:45 --> Language Class Initialized
INFO - 2021-01-04 02:53:45 --> Config Class Initialized
INFO - 2021-01-04 02:53:45 --> Loader Class Initialized
INFO - 2021-01-04 02:53:45 --> Helper loaded: url_helper
INFO - 2021-01-04 02:53:45 --> Helper loaded: file_helper
INFO - 2021-01-04 02:53:45 --> Helper loaded: form_helper
INFO - 2021-01-04 02:53:45 --> Helper loaded: my_helper
INFO - 2021-01-04 02:53:45 --> Database Driver Class Initialized
DEBUG - 2021-01-04 02:53:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 02:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 02:53:45 --> Controller Class Initialized
INFO - 2021-01-04 02:53:45 --> Helper loaded: cookie_helper
INFO - 2021-01-04 02:53:45 --> Final output sent to browser
DEBUG - 2021-01-04 02:53:45 --> Total execution time: 0.6131
INFO - 2021-01-04 02:53:46 --> Config Class Initialized
INFO - 2021-01-04 02:53:46 --> Hooks Class Initialized
DEBUG - 2021-01-04 02:53:46 --> UTF-8 Support Enabled
INFO - 2021-01-04 02:53:46 --> Utf8 Class Initialized
INFO - 2021-01-04 02:53:46 --> URI Class Initialized
INFO - 2021-01-04 02:53:46 --> Router Class Initialized
INFO - 2021-01-04 02:53:46 --> Output Class Initialized
INFO - 2021-01-04 02:53:46 --> Security Class Initialized
DEBUG - 2021-01-04 02:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 02:53:46 --> Input Class Initialized
INFO - 2021-01-04 02:53:46 --> Language Class Initialized
INFO - 2021-01-04 02:53:46 --> Language Class Initialized
INFO - 2021-01-04 02:53:46 --> Config Class Initialized
INFO - 2021-01-04 02:53:46 --> Loader Class Initialized
INFO - 2021-01-04 02:53:46 --> Helper loaded: url_helper
INFO - 2021-01-04 02:53:46 --> Helper loaded: file_helper
INFO - 2021-01-04 02:53:46 --> Helper loaded: form_helper
INFO - 2021-01-04 02:53:46 --> Helper loaded: my_helper
INFO - 2021-01-04 02:53:46 --> Database Driver Class Initialized
DEBUG - 2021-01-04 02:53:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 02:53:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 02:53:46 --> Controller Class Initialized
DEBUG - 2021-01-04 02:53:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-04 02:53:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-04 02:53:46 --> Final output sent to browser
DEBUG - 2021-01-04 02:53:46 --> Total execution time: 0.7196
INFO - 2021-01-04 02:53:51 --> Config Class Initialized
INFO - 2021-01-04 02:53:51 --> Hooks Class Initialized
DEBUG - 2021-01-04 02:53:51 --> UTF-8 Support Enabled
INFO - 2021-01-04 02:53:51 --> Utf8 Class Initialized
INFO - 2021-01-04 02:53:51 --> URI Class Initialized
INFO - 2021-01-04 02:53:51 --> Router Class Initialized
INFO - 2021-01-04 02:53:51 --> Output Class Initialized
INFO - 2021-01-04 02:53:51 --> Security Class Initialized
DEBUG - 2021-01-04 02:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 02:53:51 --> Input Class Initialized
INFO - 2021-01-04 02:53:51 --> Language Class Initialized
INFO - 2021-01-04 02:53:51 --> Language Class Initialized
INFO - 2021-01-04 02:53:51 --> Config Class Initialized
INFO - 2021-01-04 02:53:51 --> Loader Class Initialized
INFO - 2021-01-04 02:53:51 --> Helper loaded: url_helper
INFO - 2021-01-04 02:53:51 --> Helper loaded: file_helper
INFO - 2021-01-04 02:53:51 --> Helper loaded: form_helper
INFO - 2021-01-04 02:53:51 --> Helper loaded: my_helper
INFO - 2021-01-04 02:53:51 --> Database Driver Class Initialized
DEBUG - 2021-01-04 02:53:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 02:53:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 02:53:51 --> Controller Class Initialized
DEBUG - 2021-01-04 02:53:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-01-04 02:53:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-04 02:53:51 --> Final output sent to browser
DEBUG - 2021-01-04 02:53:51 --> Total execution time: 0.5042
INFO - 2021-01-04 02:53:52 --> Config Class Initialized
INFO - 2021-01-04 02:53:52 --> Hooks Class Initialized
DEBUG - 2021-01-04 02:53:52 --> UTF-8 Support Enabled
INFO - 2021-01-04 02:53:52 --> Utf8 Class Initialized
INFO - 2021-01-04 02:53:52 --> URI Class Initialized
INFO - 2021-01-04 02:53:52 --> Router Class Initialized
INFO - 2021-01-04 02:53:52 --> Output Class Initialized
INFO - 2021-01-04 02:53:52 --> Security Class Initialized
DEBUG - 2021-01-04 02:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 02:53:52 --> Input Class Initialized
INFO - 2021-01-04 02:53:52 --> Language Class Initialized
INFO - 2021-01-04 02:53:52 --> Language Class Initialized
INFO - 2021-01-04 02:53:52 --> Config Class Initialized
INFO - 2021-01-04 02:53:52 --> Loader Class Initialized
INFO - 2021-01-04 02:53:52 --> Helper loaded: url_helper
INFO - 2021-01-04 02:53:52 --> Helper loaded: file_helper
INFO - 2021-01-04 02:53:52 --> Helper loaded: form_helper
INFO - 2021-01-04 02:53:52 --> Helper loaded: my_helper
INFO - 2021-01-04 02:53:52 --> Database Driver Class Initialized
DEBUG - 2021-01-04 02:53:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 02:53:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 02:53:52 --> Controller Class Initialized
INFO - 2021-01-04 02:53:55 --> Config Class Initialized
INFO - 2021-01-04 02:53:55 --> Hooks Class Initialized
DEBUG - 2021-01-04 02:53:55 --> UTF-8 Support Enabled
INFO - 2021-01-04 02:53:55 --> Utf8 Class Initialized
INFO - 2021-01-04 02:53:55 --> URI Class Initialized
INFO - 2021-01-04 02:53:55 --> Router Class Initialized
INFO - 2021-01-04 02:53:55 --> Output Class Initialized
INFO - 2021-01-04 02:53:55 --> Security Class Initialized
DEBUG - 2021-01-04 02:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 02:53:55 --> Input Class Initialized
INFO - 2021-01-04 02:53:55 --> Language Class Initialized
INFO - 2021-01-04 02:53:55 --> Language Class Initialized
INFO - 2021-01-04 02:53:55 --> Config Class Initialized
INFO - 2021-01-04 02:53:55 --> Loader Class Initialized
INFO - 2021-01-04 02:53:55 --> Helper loaded: url_helper
INFO - 2021-01-04 02:53:55 --> Helper loaded: file_helper
INFO - 2021-01-04 02:53:55 --> Helper loaded: form_helper
INFO - 2021-01-04 02:53:55 --> Helper loaded: my_helper
INFO - 2021-01-04 02:53:55 --> Database Driver Class Initialized
DEBUG - 2021-01-04 02:53:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 02:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 02:53:55 --> Controller Class Initialized
INFO - 2021-01-04 02:53:55 --> Final output sent to browser
DEBUG - 2021-01-04 02:53:55 --> Total execution time: 0.5594
INFO - 2021-01-04 02:54:07 --> Config Class Initialized
INFO - 2021-01-04 02:54:07 --> Hooks Class Initialized
DEBUG - 2021-01-04 02:54:07 --> UTF-8 Support Enabled
INFO - 2021-01-04 02:54:07 --> Utf8 Class Initialized
INFO - 2021-01-04 02:54:07 --> URI Class Initialized
INFO - 2021-01-04 02:54:07 --> Router Class Initialized
INFO - 2021-01-04 02:54:07 --> Output Class Initialized
INFO - 2021-01-04 02:54:07 --> Security Class Initialized
DEBUG - 2021-01-04 02:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 02:54:07 --> Input Class Initialized
INFO - 2021-01-04 02:54:07 --> Language Class Initialized
INFO - 2021-01-04 02:54:07 --> Language Class Initialized
INFO - 2021-01-04 02:54:07 --> Config Class Initialized
INFO - 2021-01-04 02:54:07 --> Loader Class Initialized
INFO - 2021-01-04 02:54:07 --> Helper loaded: url_helper
INFO - 2021-01-04 02:54:07 --> Helper loaded: file_helper
INFO - 2021-01-04 02:54:07 --> Helper loaded: form_helper
INFO - 2021-01-04 02:54:07 --> Helper loaded: my_helper
INFO - 2021-01-04 02:54:07 --> Database Driver Class Initialized
DEBUG - 2021-01-04 02:54:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 02:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 02:54:08 --> Controller Class Initialized
INFO - 2021-01-04 02:54:08 --> Final output sent to browser
DEBUG - 2021-01-04 02:54:08 --> Total execution time: 0.6071
INFO - 2021-01-04 02:54:08 --> Config Class Initialized
INFO - 2021-01-04 02:54:08 --> Hooks Class Initialized
DEBUG - 2021-01-04 02:54:08 --> UTF-8 Support Enabled
INFO - 2021-01-04 02:54:08 --> Utf8 Class Initialized
INFO - 2021-01-04 02:54:08 --> URI Class Initialized
INFO - 2021-01-04 02:54:08 --> Router Class Initialized
INFO - 2021-01-04 02:54:08 --> Output Class Initialized
INFO - 2021-01-04 02:54:08 --> Security Class Initialized
DEBUG - 2021-01-04 02:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 02:54:08 --> Input Class Initialized
INFO - 2021-01-04 02:54:08 --> Language Class Initialized
INFO - 2021-01-04 02:54:08 --> Language Class Initialized
INFO - 2021-01-04 02:54:08 --> Config Class Initialized
INFO - 2021-01-04 02:54:08 --> Loader Class Initialized
INFO - 2021-01-04 02:54:08 --> Helper loaded: url_helper
INFO - 2021-01-04 02:54:08 --> Helper loaded: file_helper
INFO - 2021-01-04 02:54:08 --> Helper loaded: form_helper
INFO - 2021-01-04 02:54:08 --> Helper loaded: my_helper
INFO - 2021-01-04 02:54:08 --> Database Driver Class Initialized
DEBUG - 2021-01-04 02:54:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 02:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 02:54:08 --> Controller Class Initialized
INFO - 2021-01-04 02:54:10 --> Config Class Initialized
INFO - 2021-01-04 02:54:10 --> Hooks Class Initialized
DEBUG - 2021-01-04 02:54:10 --> UTF-8 Support Enabled
INFO - 2021-01-04 02:54:10 --> Utf8 Class Initialized
INFO - 2021-01-04 02:54:10 --> URI Class Initialized
INFO - 2021-01-04 02:54:10 --> Router Class Initialized
INFO - 2021-01-04 02:54:10 --> Output Class Initialized
INFO - 2021-01-04 02:54:10 --> Security Class Initialized
DEBUG - 2021-01-04 02:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 02:54:11 --> Input Class Initialized
INFO - 2021-01-04 02:54:11 --> Language Class Initialized
INFO - 2021-01-04 02:54:11 --> Language Class Initialized
INFO - 2021-01-04 02:54:11 --> Config Class Initialized
INFO - 2021-01-04 02:54:11 --> Loader Class Initialized
INFO - 2021-01-04 02:54:11 --> Helper loaded: url_helper
INFO - 2021-01-04 02:54:11 --> Helper loaded: file_helper
INFO - 2021-01-04 02:54:11 --> Helper loaded: form_helper
INFO - 2021-01-04 02:54:11 --> Helper loaded: my_helper
INFO - 2021-01-04 02:54:11 --> Database Driver Class Initialized
DEBUG - 2021-01-04 02:54:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 02:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 02:54:11 --> Controller Class Initialized
INFO - 2021-01-04 02:54:11 --> Final output sent to browser
DEBUG - 2021-01-04 02:54:11 --> Total execution time: 0.6098
INFO - 2021-01-04 02:54:17 --> Config Class Initialized
INFO - 2021-01-04 02:54:17 --> Hooks Class Initialized
DEBUG - 2021-01-04 02:54:17 --> UTF-8 Support Enabled
INFO - 2021-01-04 02:54:17 --> Utf8 Class Initialized
INFO - 2021-01-04 02:54:17 --> URI Class Initialized
INFO - 2021-01-04 02:54:17 --> Router Class Initialized
INFO - 2021-01-04 02:54:17 --> Output Class Initialized
INFO - 2021-01-04 02:54:17 --> Security Class Initialized
DEBUG - 2021-01-04 02:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 02:54:18 --> Input Class Initialized
INFO - 2021-01-04 02:54:18 --> Language Class Initialized
INFO - 2021-01-04 02:54:18 --> Language Class Initialized
INFO - 2021-01-04 02:54:18 --> Config Class Initialized
INFO - 2021-01-04 02:54:18 --> Loader Class Initialized
INFO - 2021-01-04 02:54:18 --> Helper loaded: url_helper
INFO - 2021-01-04 02:54:18 --> Helper loaded: file_helper
INFO - 2021-01-04 02:54:18 --> Helper loaded: form_helper
INFO - 2021-01-04 02:54:18 --> Helper loaded: my_helper
INFO - 2021-01-04 02:54:18 --> Database Driver Class Initialized
DEBUG - 2021-01-04 02:54:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 02:54:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 02:54:18 --> Controller Class Initialized
INFO - 2021-01-04 02:54:18 --> Final output sent to browser
DEBUG - 2021-01-04 02:54:18 --> Total execution time: 0.7243
INFO - 2021-01-04 02:54:18 --> Config Class Initialized
INFO - 2021-01-04 02:54:18 --> Hooks Class Initialized
DEBUG - 2021-01-04 02:54:18 --> UTF-8 Support Enabled
INFO - 2021-01-04 02:54:18 --> Utf8 Class Initialized
INFO - 2021-01-04 02:54:18 --> URI Class Initialized
INFO - 2021-01-04 02:54:18 --> Router Class Initialized
INFO - 2021-01-04 02:54:18 --> Output Class Initialized
INFO - 2021-01-04 02:54:18 --> Security Class Initialized
DEBUG - 2021-01-04 02:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 02:54:18 --> Input Class Initialized
INFO - 2021-01-04 02:54:18 --> Language Class Initialized
INFO - 2021-01-04 02:54:19 --> Language Class Initialized
INFO - 2021-01-04 02:54:19 --> Config Class Initialized
INFO - 2021-01-04 02:54:19 --> Loader Class Initialized
INFO - 2021-01-04 02:54:19 --> Helper loaded: url_helper
INFO - 2021-01-04 02:54:19 --> Helper loaded: file_helper
INFO - 2021-01-04 02:54:19 --> Helper loaded: form_helper
INFO - 2021-01-04 02:54:19 --> Helper loaded: my_helper
INFO - 2021-01-04 02:54:19 --> Database Driver Class Initialized
DEBUG - 2021-01-04 02:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 02:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 02:54:19 --> Controller Class Initialized
INFO - 2021-01-04 02:54:22 --> Config Class Initialized
INFO - 2021-01-04 02:54:22 --> Hooks Class Initialized
DEBUG - 2021-01-04 02:54:22 --> UTF-8 Support Enabled
INFO - 2021-01-04 02:54:22 --> Utf8 Class Initialized
INFO - 2021-01-04 02:54:22 --> URI Class Initialized
INFO - 2021-01-04 02:54:22 --> Router Class Initialized
INFO - 2021-01-04 02:54:22 --> Output Class Initialized
INFO - 2021-01-04 02:54:22 --> Security Class Initialized
DEBUG - 2021-01-04 02:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 02:54:22 --> Input Class Initialized
INFO - 2021-01-04 02:54:22 --> Language Class Initialized
INFO - 2021-01-04 02:54:22 --> Language Class Initialized
INFO - 2021-01-04 02:54:22 --> Config Class Initialized
INFO - 2021-01-04 02:54:22 --> Loader Class Initialized
INFO - 2021-01-04 02:54:22 --> Helper loaded: url_helper
INFO - 2021-01-04 02:54:22 --> Helper loaded: file_helper
INFO - 2021-01-04 02:54:22 --> Helper loaded: form_helper
INFO - 2021-01-04 02:54:22 --> Helper loaded: my_helper
INFO - 2021-01-04 02:54:22 --> Database Driver Class Initialized
DEBUG - 2021-01-04 02:54:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 02:54:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 02:54:22 --> Controller Class Initialized
DEBUG - 2021-01-04 02:54:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 02:54:22 --> Final output sent to browser
DEBUG - 2021-01-04 02:54:22 --> Total execution time: 0.5810
INFO - 2021-01-04 02:57:09 --> Config Class Initialized
INFO - 2021-01-04 02:57:09 --> Hooks Class Initialized
DEBUG - 2021-01-04 02:57:09 --> UTF-8 Support Enabled
INFO - 2021-01-04 02:57:09 --> Utf8 Class Initialized
INFO - 2021-01-04 02:57:09 --> URI Class Initialized
INFO - 2021-01-04 02:57:09 --> Router Class Initialized
INFO - 2021-01-04 02:57:09 --> Output Class Initialized
INFO - 2021-01-04 02:57:09 --> Security Class Initialized
DEBUG - 2021-01-04 02:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 02:57:09 --> Input Class Initialized
INFO - 2021-01-04 02:57:09 --> Language Class Initialized
INFO - 2021-01-04 02:57:09 --> Language Class Initialized
INFO - 2021-01-04 02:57:09 --> Config Class Initialized
INFO - 2021-01-04 02:57:09 --> Loader Class Initialized
INFO - 2021-01-04 02:57:09 --> Helper loaded: url_helper
INFO - 2021-01-04 02:57:10 --> Helper loaded: file_helper
INFO - 2021-01-04 02:57:10 --> Helper loaded: form_helper
INFO - 2021-01-04 02:57:10 --> Helper loaded: my_helper
INFO - 2021-01-04 02:57:10 --> Database Driver Class Initialized
DEBUG - 2021-01-04 02:57:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 02:57:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 02:57:10 --> Controller Class Initialized
DEBUG - 2021-01-04 02:57:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 02:57:10 --> Final output sent to browser
DEBUG - 2021-01-04 02:57:10 --> Total execution time: 1.3933
INFO - 2021-01-04 02:57:22 --> Config Class Initialized
INFO - 2021-01-04 02:57:22 --> Hooks Class Initialized
DEBUG - 2021-01-04 02:57:22 --> UTF-8 Support Enabled
INFO - 2021-01-04 02:57:22 --> Utf8 Class Initialized
INFO - 2021-01-04 02:57:22 --> URI Class Initialized
INFO - 2021-01-04 02:57:22 --> Router Class Initialized
INFO - 2021-01-04 02:57:22 --> Output Class Initialized
INFO - 2021-01-04 02:57:22 --> Security Class Initialized
DEBUG - 2021-01-04 02:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 02:57:22 --> Input Class Initialized
INFO - 2021-01-04 02:57:22 --> Language Class Initialized
INFO - 2021-01-04 02:57:22 --> Language Class Initialized
INFO - 2021-01-04 02:57:22 --> Config Class Initialized
INFO - 2021-01-04 02:57:22 --> Loader Class Initialized
INFO - 2021-01-04 02:57:22 --> Helper loaded: url_helper
INFO - 2021-01-04 02:57:22 --> Helper loaded: file_helper
INFO - 2021-01-04 02:57:22 --> Helper loaded: form_helper
INFO - 2021-01-04 02:57:22 --> Helper loaded: my_helper
INFO - 2021-01-04 02:57:22 --> Database Driver Class Initialized
DEBUG - 2021-01-04 02:57:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 02:57:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 02:57:22 --> Controller Class Initialized
DEBUG - 2021-01-04 02:57:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 02:57:23 --> Final output sent to browser
DEBUG - 2021-01-04 02:57:23 --> Total execution time: 1.0258
INFO - 2021-01-04 02:58:06 --> Config Class Initialized
INFO - 2021-01-04 02:58:06 --> Hooks Class Initialized
DEBUG - 2021-01-04 02:58:06 --> UTF-8 Support Enabled
INFO - 2021-01-04 02:58:06 --> Utf8 Class Initialized
INFO - 2021-01-04 02:58:06 --> URI Class Initialized
INFO - 2021-01-04 02:58:06 --> Router Class Initialized
INFO - 2021-01-04 02:58:06 --> Output Class Initialized
INFO - 2021-01-04 02:58:07 --> Security Class Initialized
DEBUG - 2021-01-04 02:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 02:58:07 --> Input Class Initialized
INFO - 2021-01-04 02:58:07 --> Language Class Initialized
INFO - 2021-01-04 02:58:07 --> Language Class Initialized
INFO - 2021-01-04 02:58:07 --> Config Class Initialized
INFO - 2021-01-04 02:58:07 --> Loader Class Initialized
INFO - 2021-01-04 02:58:07 --> Helper loaded: url_helper
INFO - 2021-01-04 02:58:07 --> Helper loaded: file_helper
INFO - 2021-01-04 02:58:07 --> Helper loaded: form_helper
INFO - 2021-01-04 02:58:07 --> Helper loaded: my_helper
INFO - 2021-01-04 02:58:07 --> Database Driver Class Initialized
DEBUG - 2021-01-04 02:58:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 02:58:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 02:58:07 --> Controller Class Initialized
DEBUG - 2021-01-04 02:58:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 02:58:07 --> Final output sent to browser
DEBUG - 2021-01-04 02:58:07 --> Total execution time: 1.3789
INFO - 2021-01-04 02:58:33 --> Config Class Initialized
INFO - 2021-01-04 02:58:33 --> Hooks Class Initialized
DEBUG - 2021-01-04 02:58:33 --> UTF-8 Support Enabled
INFO - 2021-01-04 02:58:33 --> Utf8 Class Initialized
INFO - 2021-01-04 02:58:33 --> URI Class Initialized
INFO - 2021-01-04 02:58:33 --> Router Class Initialized
INFO - 2021-01-04 02:58:33 --> Output Class Initialized
INFO - 2021-01-04 02:58:33 --> Security Class Initialized
DEBUG - 2021-01-04 02:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 02:58:33 --> Input Class Initialized
INFO - 2021-01-04 02:58:33 --> Language Class Initialized
INFO - 2021-01-04 02:58:33 --> Language Class Initialized
INFO - 2021-01-04 02:58:33 --> Config Class Initialized
INFO - 2021-01-04 02:58:33 --> Loader Class Initialized
INFO - 2021-01-04 02:58:33 --> Helper loaded: url_helper
INFO - 2021-01-04 02:58:34 --> Helper loaded: file_helper
INFO - 2021-01-04 02:58:34 --> Helper loaded: form_helper
INFO - 2021-01-04 02:58:34 --> Helper loaded: my_helper
INFO - 2021-01-04 02:58:34 --> Database Driver Class Initialized
DEBUG - 2021-01-04 02:58:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 02:58:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 02:58:34 --> Controller Class Initialized
DEBUG - 2021-01-04 02:58:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 02:58:34 --> Final output sent to browser
DEBUG - 2021-01-04 02:58:34 --> Total execution time: 1.5678
INFO - 2021-01-04 02:59:25 --> Config Class Initialized
INFO - 2021-01-04 02:59:25 --> Hooks Class Initialized
DEBUG - 2021-01-04 02:59:25 --> UTF-8 Support Enabled
INFO - 2021-01-04 02:59:25 --> Utf8 Class Initialized
INFO - 2021-01-04 02:59:25 --> URI Class Initialized
INFO - 2021-01-04 02:59:25 --> Router Class Initialized
INFO - 2021-01-04 02:59:25 --> Output Class Initialized
INFO - 2021-01-04 02:59:25 --> Security Class Initialized
DEBUG - 2021-01-04 02:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 02:59:25 --> Input Class Initialized
INFO - 2021-01-04 02:59:25 --> Language Class Initialized
INFO - 2021-01-04 02:59:25 --> Language Class Initialized
INFO - 2021-01-04 02:59:25 --> Config Class Initialized
INFO - 2021-01-04 02:59:25 --> Loader Class Initialized
INFO - 2021-01-04 02:59:25 --> Helper loaded: url_helper
INFO - 2021-01-04 02:59:25 --> Helper loaded: file_helper
INFO - 2021-01-04 02:59:25 --> Helper loaded: form_helper
INFO - 2021-01-04 02:59:25 --> Helper loaded: my_helper
INFO - 2021-01-04 02:59:25 --> Database Driver Class Initialized
DEBUG - 2021-01-04 02:59:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 02:59:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 02:59:26 --> Controller Class Initialized
DEBUG - 2021-01-04 02:59:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 02:59:26 --> Final output sent to browser
DEBUG - 2021-01-04 02:59:26 --> Total execution time: 1.0578
INFO - 2021-01-04 03:07:14 --> Config Class Initialized
INFO - 2021-01-04 03:07:14 --> Hooks Class Initialized
DEBUG - 2021-01-04 03:07:14 --> UTF-8 Support Enabled
INFO - 2021-01-04 03:07:14 --> Utf8 Class Initialized
INFO - 2021-01-04 03:07:14 --> URI Class Initialized
INFO - 2021-01-04 03:07:14 --> Router Class Initialized
INFO - 2021-01-04 03:07:14 --> Output Class Initialized
INFO - 2021-01-04 03:07:14 --> Security Class Initialized
DEBUG - 2021-01-04 03:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 03:07:14 --> Input Class Initialized
INFO - 2021-01-04 03:07:14 --> Language Class Initialized
INFO - 2021-01-04 03:07:14 --> Language Class Initialized
INFO - 2021-01-04 03:07:14 --> Config Class Initialized
INFO - 2021-01-04 03:07:14 --> Loader Class Initialized
INFO - 2021-01-04 03:07:14 --> Helper loaded: url_helper
INFO - 2021-01-04 03:07:14 --> Helper loaded: file_helper
INFO - 2021-01-04 03:07:14 --> Helper loaded: form_helper
INFO - 2021-01-04 03:07:14 --> Helper loaded: my_helper
INFO - 2021-01-04 03:07:14 --> Database Driver Class Initialized
DEBUG - 2021-01-04 03:07:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 03:07:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 03:07:15 --> Controller Class Initialized
DEBUG - 2021-01-04 03:07:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 03:07:15 --> Final output sent to browser
DEBUG - 2021-01-04 03:07:15 --> Total execution time: 1.2514
INFO - 2021-01-04 03:07:38 --> Config Class Initialized
INFO - 2021-01-04 03:07:38 --> Hooks Class Initialized
DEBUG - 2021-01-04 03:07:38 --> UTF-8 Support Enabled
INFO - 2021-01-04 03:07:38 --> Utf8 Class Initialized
INFO - 2021-01-04 03:07:39 --> URI Class Initialized
INFO - 2021-01-04 03:07:39 --> Router Class Initialized
INFO - 2021-01-04 03:07:39 --> Output Class Initialized
INFO - 2021-01-04 03:07:39 --> Security Class Initialized
DEBUG - 2021-01-04 03:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 03:07:39 --> Input Class Initialized
INFO - 2021-01-04 03:07:39 --> Language Class Initialized
INFO - 2021-01-04 03:07:39 --> Language Class Initialized
INFO - 2021-01-04 03:07:39 --> Config Class Initialized
INFO - 2021-01-04 03:07:39 --> Loader Class Initialized
INFO - 2021-01-04 03:07:39 --> Helper loaded: url_helper
INFO - 2021-01-04 03:07:39 --> Helper loaded: file_helper
INFO - 2021-01-04 03:07:39 --> Helper loaded: form_helper
INFO - 2021-01-04 03:07:39 --> Helper loaded: my_helper
INFO - 2021-01-04 03:07:39 --> Database Driver Class Initialized
DEBUG - 2021-01-04 03:07:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 03:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 03:07:39 --> Controller Class Initialized
DEBUG - 2021-01-04 03:07:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 03:07:39 --> Final output sent to browser
DEBUG - 2021-01-04 03:07:39 --> Total execution time: 0.9109
INFO - 2021-01-04 03:08:06 --> Config Class Initialized
INFO - 2021-01-04 03:08:06 --> Hooks Class Initialized
DEBUG - 2021-01-04 03:08:06 --> UTF-8 Support Enabled
INFO - 2021-01-04 03:08:06 --> Utf8 Class Initialized
INFO - 2021-01-04 03:08:06 --> URI Class Initialized
INFO - 2021-01-04 03:08:06 --> Router Class Initialized
INFO - 2021-01-04 03:08:06 --> Output Class Initialized
INFO - 2021-01-04 03:08:06 --> Security Class Initialized
DEBUG - 2021-01-04 03:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 03:08:06 --> Input Class Initialized
INFO - 2021-01-04 03:08:06 --> Language Class Initialized
INFO - 2021-01-04 03:08:06 --> Language Class Initialized
INFO - 2021-01-04 03:08:06 --> Config Class Initialized
INFO - 2021-01-04 03:08:06 --> Loader Class Initialized
INFO - 2021-01-04 03:08:06 --> Helper loaded: url_helper
INFO - 2021-01-04 03:08:06 --> Helper loaded: file_helper
INFO - 2021-01-04 03:08:06 --> Helper loaded: form_helper
INFO - 2021-01-04 03:08:07 --> Helper loaded: my_helper
INFO - 2021-01-04 03:08:07 --> Database Driver Class Initialized
DEBUG - 2021-01-04 03:08:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 03:08:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 03:08:07 --> Controller Class Initialized
DEBUG - 2021-01-04 03:08:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 03:08:07 --> Final output sent to browser
DEBUG - 2021-01-04 03:08:07 --> Total execution time: 0.4416
INFO - 2021-01-04 03:08:33 --> Config Class Initialized
INFO - 2021-01-04 03:08:33 --> Hooks Class Initialized
DEBUG - 2021-01-04 03:08:33 --> UTF-8 Support Enabled
INFO - 2021-01-04 03:08:33 --> Utf8 Class Initialized
INFO - 2021-01-04 03:08:33 --> URI Class Initialized
INFO - 2021-01-04 03:08:33 --> Router Class Initialized
INFO - 2021-01-04 03:08:33 --> Output Class Initialized
INFO - 2021-01-04 03:08:33 --> Security Class Initialized
DEBUG - 2021-01-04 03:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 03:08:33 --> Input Class Initialized
INFO - 2021-01-04 03:08:33 --> Language Class Initialized
INFO - 2021-01-04 03:08:33 --> Language Class Initialized
INFO - 2021-01-04 03:08:33 --> Config Class Initialized
INFO - 2021-01-04 03:08:33 --> Loader Class Initialized
INFO - 2021-01-04 03:08:33 --> Helper loaded: url_helper
INFO - 2021-01-04 03:08:33 --> Helper loaded: file_helper
INFO - 2021-01-04 03:08:33 --> Helper loaded: form_helper
INFO - 2021-01-04 03:08:33 --> Helper loaded: my_helper
INFO - 2021-01-04 03:08:33 --> Database Driver Class Initialized
DEBUG - 2021-01-04 03:08:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 03:08:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 03:08:33 --> Controller Class Initialized
DEBUG - 2021-01-04 03:08:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 03:08:33 --> Final output sent to browser
DEBUG - 2021-01-04 03:08:33 --> Total execution time: 0.4444
INFO - 2021-01-04 03:10:05 --> Config Class Initialized
INFO - 2021-01-04 03:10:06 --> Hooks Class Initialized
DEBUG - 2021-01-04 03:10:06 --> UTF-8 Support Enabled
INFO - 2021-01-04 03:10:06 --> Utf8 Class Initialized
INFO - 2021-01-04 03:10:06 --> URI Class Initialized
INFO - 2021-01-04 03:10:06 --> Router Class Initialized
INFO - 2021-01-04 03:10:06 --> Output Class Initialized
INFO - 2021-01-04 03:10:06 --> Security Class Initialized
DEBUG - 2021-01-04 03:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 03:10:06 --> Input Class Initialized
INFO - 2021-01-04 03:10:06 --> Language Class Initialized
INFO - 2021-01-04 03:10:06 --> Language Class Initialized
INFO - 2021-01-04 03:10:06 --> Config Class Initialized
INFO - 2021-01-04 03:10:06 --> Loader Class Initialized
INFO - 2021-01-04 03:10:06 --> Helper loaded: url_helper
INFO - 2021-01-04 03:10:06 --> Helper loaded: file_helper
INFO - 2021-01-04 03:10:06 --> Helper loaded: form_helper
INFO - 2021-01-04 03:10:06 --> Helper loaded: my_helper
INFO - 2021-01-04 03:10:07 --> Database Driver Class Initialized
DEBUG - 2021-01-04 03:10:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 03:10:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 03:10:07 --> Controller Class Initialized
DEBUG - 2021-01-04 03:10:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 03:10:07 --> Final output sent to browser
DEBUG - 2021-01-04 03:10:07 --> Total execution time: 1.8365
INFO - 2021-01-04 03:12:10 --> Config Class Initialized
INFO - 2021-01-04 03:12:11 --> Hooks Class Initialized
DEBUG - 2021-01-04 03:12:11 --> UTF-8 Support Enabled
INFO - 2021-01-04 03:12:11 --> Utf8 Class Initialized
INFO - 2021-01-04 03:12:11 --> URI Class Initialized
INFO - 2021-01-04 03:12:11 --> Router Class Initialized
INFO - 2021-01-04 03:12:11 --> Output Class Initialized
INFO - 2021-01-04 03:12:11 --> Security Class Initialized
DEBUG - 2021-01-04 03:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 03:12:11 --> Input Class Initialized
INFO - 2021-01-04 03:12:11 --> Language Class Initialized
INFO - 2021-01-04 03:12:11 --> Language Class Initialized
INFO - 2021-01-04 03:12:11 --> Config Class Initialized
INFO - 2021-01-04 03:12:11 --> Loader Class Initialized
INFO - 2021-01-04 03:12:11 --> Helper loaded: url_helper
INFO - 2021-01-04 03:12:11 --> Helper loaded: file_helper
INFO - 2021-01-04 03:12:11 --> Helper loaded: form_helper
INFO - 2021-01-04 03:12:11 --> Helper loaded: my_helper
INFO - 2021-01-04 03:12:11 --> Database Driver Class Initialized
DEBUG - 2021-01-04 03:12:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 03:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 03:12:11 --> Controller Class Initialized
DEBUG - 2021-01-04 03:12:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 03:12:11 --> Final output sent to browser
DEBUG - 2021-01-04 03:12:11 --> Total execution time: 0.8259
INFO - 2021-01-04 03:12:27 --> Config Class Initialized
INFO - 2021-01-04 03:12:27 --> Hooks Class Initialized
DEBUG - 2021-01-04 03:12:27 --> UTF-8 Support Enabled
INFO - 2021-01-04 03:12:27 --> Utf8 Class Initialized
INFO - 2021-01-04 03:12:27 --> URI Class Initialized
INFO - 2021-01-04 03:12:27 --> Router Class Initialized
INFO - 2021-01-04 03:12:27 --> Output Class Initialized
INFO - 2021-01-04 03:12:27 --> Security Class Initialized
DEBUG - 2021-01-04 03:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 03:12:27 --> Input Class Initialized
INFO - 2021-01-04 03:12:27 --> Language Class Initialized
INFO - 2021-01-04 03:12:27 --> Language Class Initialized
INFO - 2021-01-04 03:12:27 --> Config Class Initialized
INFO - 2021-01-04 03:12:27 --> Loader Class Initialized
INFO - 2021-01-04 03:12:27 --> Helper loaded: url_helper
INFO - 2021-01-04 03:12:27 --> Helper loaded: file_helper
INFO - 2021-01-04 03:12:27 --> Helper loaded: form_helper
INFO - 2021-01-04 03:12:27 --> Helper loaded: my_helper
INFO - 2021-01-04 03:12:27 --> Database Driver Class Initialized
DEBUG - 2021-01-04 03:12:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 03:12:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 03:12:27 --> Controller Class Initialized
DEBUG - 2021-01-04 03:12:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 03:12:28 --> Final output sent to browser
DEBUG - 2021-01-04 03:12:28 --> Total execution time: 0.6210
INFO - 2021-01-04 03:13:13 --> Config Class Initialized
INFO - 2021-01-04 03:13:13 --> Hooks Class Initialized
DEBUG - 2021-01-04 03:13:13 --> UTF-8 Support Enabled
INFO - 2021-01-04 03:13:13 --> Utf8 Class Initialized
INFO - 2021-01-04 03:13:13 --> URI Class Initialized
INFO - 2021-01-04 03:13:13 --> Router Class Initialized
INFO - 2021-01-04 03:13:13 --> Output Class Initialized
INFO - 2021-01-04 03:13:13 --> Security Class Initialized
DEBUG - 2021-01-04 03:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 03:13:13 --> Input Class Initialized
INFO - 2021-01-04 03:13:13 --> Language Class Initialized
INFO - 2021-01-04 03:13:13 --> Language Class Initialized
INFO - 2021-01-04 03:13:13 --> Config Class Initialized
INFO - 2021-01-04 03:13:13 --> Loader Class Initialized
INFO - 2021-01-04 03:13:13 --> Helper loaded: url_helper
INFO - 2021-01-04 03:13:13 --> Helper loaded: file_helper
INFO - 2021-01-04 03:13:13 --> Helper loaded: form_helper
INFO - 2021-01-04 03:13:13 --> Helper loaded: my_helper
INFO - 2021-01-04 03:13:13 --> Database Driver Class Initialized
DEBUG - 2021-01-04 03:13:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 03:13:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 03:13:14 --> Controller Class Initialized
DEBUG - 2021-01-04 03:13:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 03:13:14 --> Final output sent to browser
DEBUG - 2021-01-04 03:13:14 --> Total execution time: 1.0269
INFO - 2021-01-04 03:13:47 --> Config Class Initialized
INFO - 2021-01-04 03:13:47 --> Hooks Class Initialized
DEBUG - 2021-01-04 03:13:47 --> UTF-8 Support Enabled
INFO - 2021-01-04 03:13:47 --> Utf8 Class Initialized
INFO - 2021-01-04 03:13:47 --> URI Class Initialized
INFO - 2021-01-04 03:13:47 --> Router Class Initialized
INFO - 2021-01-04 03:13:47 --> Output Class Initialized
INFO - 2021-01-04 03:13:47 --> Security Class Initialized
DEBUG - 2021-01-04 03:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 03:13:47 --> Input Class Initialized
INFO - 2021-01-04 03:13:47 --> Language Class Initialized
INFO - 2021-01-04 03:13:47 --> Language Class Initialized
INFO - 2021-01-04 03:13:47 --> Config Class Initialized
INFO - 2021-01-04 03:13:47 --> Loader Class Initialized
INFO - 2021-01-04 03:13:48 --> Helper loaded: url_helper
INFO - 2021-01-04 03:13:48 --> Helper loaded: file_helper
INFO - 2021-01-04 03:13:48 --> Helper loaded: form_helper
INFO - 2021-01-04 03:13:48 --> Helper loaded: my_helper
INFO - 2021-01-04 03:13:48 --> Database Driver Class Initialized
DEBUG - 2021-01-04 03:13:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 03:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 03:13:48 --> Controller Class Initialized
DEBUG - 2021-01-04 03:13:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 03:13:48 --> Final output sent to browser
DEBUG - 2021-01-04 03:13:48 --> Total execution time: 0.6351
INFO - 2021-01-04 03:16:46 --> Config Class Initialized
INFO - 2021-01-04 03:16:46 --> Hooks Class Initialized
DEBUG - 2021-01-04 03:16:46 --> UTF-8 Support Enabled
INFO - 2021-01-04 03:16:46 --> Utf8 Class Initialized
INFO - 2021-01-04 03:16:46 --> URI Class Initialized
INFO - 2021-01-04 03:16:46 --> Router Class Initialized
INFO - 2021-01-04 03:16:46 --> Output Class Initialized
INFO - 2021-01-04 03:16:46 --> Security Class Initialized
DEBUG - 2021-01-04 03:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 03:16:46 --> Input Class Initialized
INFO - 2021-01-04 03:16:46 --> Language Class Initialized
INFO - 2021-01-04 03:16:46 --> Language Class Initialized
INFO - 2021-01-04 03:16:46 --> Config Class Initialized
INFO - 2021-01-04 03:16:46 --> Loader Class Initialized
INFO - 2021-01-04 03:16:46 --> Helper loaded: url_helper
INFO - 2021-01-04 03:16:46 --> Helper loaded: file_helper
INFO - 2021-01-04 03:16:46 --> Helper loaded: form_helper
INFO - 2021-01-04 03:16:46 --> Helper loaded: my_helper
INFO - 2021-01-04 03:16:46 --> Database Driver Class Initialized
DEBUG - 2021-01-04 03:16:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 03:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 03:16:46 --> Controller Class Initialized
DEBUG - 2021-01-04 03:16:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 03:16:46 --> Final output sent to browser
DEBUG - 2021-01-04 03:16:46 --> Total execution time: 0.5735
INFO - 2021-01-04 03:21:08 --> Config Class Initialized
INFO - 2021-01-04 03:21:08 --> Hooks Class Initialized
DEBUG - 2021-01-04 03:21:08 --> UTF-8 Support Enabled
INFO - 2021-01-04 03:21:08 --> Utf8 Class Initialized
INFO - 2021-01-04 03:21:08 --> URI Class Initialized
INFO - 2021-01-04 03:21:08 --> Router Class Initialized
INFO - 2021-01-04 03:21:08 --> Output Class Initialized
INFO - 2021-01-04 03:21:08 --> Security Class Initialized
DEBUG - 2021-01-04 03:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 03:21:08 --> Input Class Initialized
INFO - 2021-01-04 03:21:08 --> Language Class Initialized
INFO - 2021-01-04 03:21:08 --> Language Class Initialized
INFO - 2021-01-04 03:21:08 --> Config Class Initialized
INFO - 2021-01-04 03:21:08 --> Loader Class Initialized
INFO - 2021-01-04 03:21:08 --> Helper loaded: url_helper
INFO - 2021-01-04 03:21:08 --> Helper loaded: file_helper
INFO - 2021-01-04 03:21:08 --> Helper loaded: form_helper
INFO - 2021-01-04 03:21:08 --> Helper loaded: my_helper
INFO - 2021-01-04 03:21:08 --> Database Driver Class Initialized
DEBUG - 2021-01-04 03:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 03:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 03:21:08 --> Controller Class Initialized
DEBUG - 2021-01-04 03:21:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 03:21:09 --> Final output sent to browser
DEBUG - 2021-01-04 03:21:09 --> Total execution time: 1.1277
INFO - 2021-01-04 03:22:05 --> Config Class Initialized
INFO - 2021-01-04 03:22:05 --> Hooks Class Initialized
DEBUG - 2021-01-04 03:22:05 --> UTF-8 Support Enabled
INFO - 2021-01-04 03:22:05 --> Utf8 Class Initialized
INFO - 2021-01-04 03:22:05 --> URI Class Initialized
INFO - 2021-01-04 03:22:05 --> Router Class Initialized
INFO - 2021-01-04 03:22:05 --> Output Class Initialized
INFO - 2021-01-04 03:22:05 --> Security Class Initialized
DEBUG - 2021-01-04 03:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 03:22:05 --> Input Class Initialized
INFO - 2021-01-04 03:22:05 --> Language Class Initialized
INFO - 2021-01-04 03:22:05 --> Language Class Initialized
INFO - 2021-01-04 03:22:06 --> Config Class Initialized
INFO - 2021-01-04 03:22:06 --> Loader Class Initialized
INFO - 2021-01-04 03:22:06 --> Helper loaded: url_helper
INFO - 2021-01-04 03:22:06 --> Helper loaded: file_helper
INFO - 2021-01-04 03:22:06 --> Helper loaded: form_helper
INFO - 2021-01-04 03:22:06 --> Helper loaded: my_helper
INFO - 2021-01-04 03:22:06 --> Database Driver Class Initialized
DEBUG - 2021-01-04 03:22:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 03:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 03:22:06 --> Controller Class Initialized
DEBUG - 2021-01-04 03:22:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 03:22:06 --> Final output sent to browser
DEBUG - 2021-01-04 03:22:06 --> Total execution time: 1.2241
INFO - 2021-01-04 03:22:35 --> Config Class Initialized
INFO - 2021-01-04 03:22:35 --> Hooks Class Initialized
DEBUG - 2021-01-04 03:22:35 --> UTF-8 Support Enabled
INFO - 2021-01-04 03:22:35 --> Utf8 Class Initialized
INFO - 2021-01-04 03:22:35 --> URI Class Initialized
INFO - 2021-01-04 03:22:35 --> Router Class Initialized
INFO - 2021-01-04 03:22:35 --> Output Class Initialized
INFO - 2021-01-04 03:22:35 --> Security Class Initialized
DEBUG - 2021-01-04 03:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 03:22:35 --> Input Class Initialized
INFO - 2021-01-04 03:22:35 --> Language Class Initialized
INFO - 2021-01-04 03:22:35 --> Language Class Initialized
INFO - 2021-01-04 03:22:35 --> Config Class Initialized
INFO - 2021-01-04 03:22:35 --> Loader Class Initialized
INFO - 2021-01-04 03:22:35 --> Helper loaded: url_helper
INFO - 2021-01-04 03:22:35 --> Helper loaded: file_helper
INFO - 2021-01-04 03:22:36 --> Helper loaded: form_helper
INFO - 2021-01-04 03:22:36 --> Helper loaded: my_helper
INFO - 2021-01-04 03:22:36 --> Database Driver Class Initialized
DEBUG - 2021-01-04 03:22:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 03:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 03:22:36 --> Controller Class Initialized
DEBUG - 2021-01-04 03:22:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 03:22:36 --> Final output sent to browser
DEBUG - 2021-01-04 03:22:36 --> Total execution time: 1.1979
INFO - 2021-01-04 03:25:27 --> Config Class Initialized
INFO - 2021-01-04 03:25:27 --> Hooks Class Initialized
DEBUG - 2021-01-04 03:25:28 --> UTF-8 Support Enabled
INFO - 2021-01-04 03:25:28 --> Utf8 Class Initialized
INFO - 2021-01-04 03:25:28 --> URI Class Initialized
INFO - 2021-01-04 03:25:28 --> Router Class Initialized
INFO - 2021-01-04 03:25:28 --> Output Class Initialized
INFO - 2021-01-04 03:25:28 --> Security Class Initialized
DEBUG - 2021-01-04 03:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 03:25:28 --> Input Class Initialized
INFO - 2021-01-04 03:25:28 --> Language Class Initialized
INFO - 2021-01-04 03:25:28 --> Language Class Initialized
INFO - 2021-01-04 03:25:28 --> Config Class Initialized
INFO - 2021-01-04 03:25:28 --> Loader Class Initialized
INFO - 2021-01-04 03:25:28 --> Helper loaded: url_helper
INFO - 2021-01-04 03:25:28 --> Helper loaded: file_helper
INFO - 2021-01-04 03:25:28 --> Helper loaded: form_helper
INFO - 2021-01-04 03:25:28 --> Helper loaded: my_helper
INFO - 2021-01-04 03:25:28 --> Database Driver Class Initialized
DEBUG - 2021-01-04 03:25:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 03:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 03:25:28 --> Controller Class Initialized
DEBUG - 2021-01-04 03:25:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 03:25:29 --> Final output sent to browser
DEBUG - 2021-01-04 03:25:29 --> Total execution time: 1.3171
INFO - 2021-01-04 03:25:53 --> Config Class Initialized
INFO - 2021-01-04 03:25:53 --> Hooks Class Initialized
DEBUG - 2021-01-04 03:25:53 --> UTF-8 Support Enabled
INFO - 2021-01-04 03:25:53 --> Utf8 Class Initialized
INFO - 2021-01-04 03:25:53 --> URI Class Initialized
INFO - 2021-01-04 03:25:53 --> Router Class Initialized
INFO - 2021-01-04 03:25:53 --> Output Class Initialized
INFO - 2021-01-04 03:25:53 --> Security Class Initialized
DEBUG - 2021-01-04 03:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 03:25:54 --> Input Class Initialized
INFO - 2021-01-04 03:25:54 --> Language Class Initialized
INFO - 2021-01-04 03:25:54 --> Language Class Initialized
INFO - 2021-01-04 03:25:54 --> Config Class Initialized
INFO - 2021-01-04 03:25:54 --> Loader Class Initialized
INFO - 2021-01-04 03:25:54 --> Helper loaded: url_helper
INFO - 2021-01-04 03:25:54 --> Helper loaded: file_helper
INFO - 2021-01-04 03:25:54 --> Helper loaded: form_helper
INFO - 2021-01-04 03:25:54 --> Helper loaded: my_helper
INFO - 2021-01-04 03:25:54 --> Database Driver Class Initialized
DEBUG - 2021-01-04 03:25:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 03:25:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 03:25:54 --> Controller Class Initialized
DEBUG - 2021-01-04 03:25:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 03:25:54 --> Final output sent to browser
DEBUG - 2021-01-04 03:25:54 --> Total execution time: 1.2623
INFO - 2021-01-04 03:27:48 --> Config Class Initialized
INFO - 2021-01-04 03:27:48 --> Hooks Class Initialized
DEBUG - 2021-01-04 03:27:48 --> UTF-8 Support Enabled
INFO - 2021-01-04 03:27:48 --> Utf8 Class Initialized
INFO - 2021-01-04 03:27:48 --> URI Class Initialized
INFO - 2021-01-04 03:27:48 --> Router Class Initialized
INFO - 2021-01-04 03:27:48 --> Output Class Initialized
INFO - 2021-01-04 03:27:48 --> Security Class Initialized
DEBUG - 2021-01-04 03:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 03:27:48 --> Input Class Initialized
INFO - 2021-01-04 03:27:48 --> Language Class Initialized
INFO - 2021-01-04 03:27:48 --> Language Class Initialized
INFO - 2021-01-04 03:27:48 --> Config Class Initialized
INFO - 2021-01-04 03:27:48 --> Loader Class Initialized
INFO - 2021-01-04 03:27:48 --> Helper loaded: url_helper
INFO - 2021-01-04 03:27:48 --> Helper loaded: file_helper
INFO - 2021-01-04 03:27:49 --> Helper loaded: form_helper
INFO - 2021-01-04 03:27:49 --> Helper loaded: my_helper
INFO - 2021-01-04 03:27:49 --> Database Driver Class Initialized
DEBUG - 2021-01-04 03:27:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 03:27:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 03:27:49 --> Controller Class Initialized
DEBUG - 2021-01-04 03:27:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 03:27:49 --> Final output sent to browser
DEBUG - 2021-01-04 03:27:49 --> Total execution time: 1.2997
INFO - 2021-01-04 03:28:17 --> Config Class Initialized
INFO - 2021-01-04 03:28:17 --> Hooks Class Initialized
DEBUG - 2021-01-04 03:28:17 --> UTF-8 Support Enabled
INFO - 2021-01-04 03:28:17 --> Utf8 Class Initialized
INFO - 2021-01-04 03:28:17 --> URI Class Initialized
INFO - 2021-01-04 03:28:17 --> Router Class Initialized
INFO - 2021-01-04 03:28:17 --> Output Class Initialized
INFO - 2021-01-04 03:28:18 --> Security Class Initialized
DEBUG - 2021-01-04 03:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 03:28:18 --> Input Class Initialized
INFO - 2021-01-04 03:28:18 --> Language Class Initialized
INFO - 2021-01-04 03:28:18 --> Language Class Initialized
INFO - 2021-01-04 03:28:18 --> Config Class Initialized
INFO - 2021-01-04 03:28:18 --> Loader Class Initialized
INFO - 2021-01-04 03:28:18 --> Helper loaded: url_helper
INFO - 2021-01-04 03:28:18 --> Helper loaded: file_helper
INFO - 2021-01-04 03:28:18 --> Helper loaded: form_helper
INFO - 2021-01-04 03:28:18 --> Helper loaded: my_helper
INFO - 2021-01-04 03:28:18 --> Database Driver Class Initialized
DEBUG - 2021-01-04 03:28:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 03:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 03:28:18 --> Controller Class Initialized
DEBUG - 2021-01-04 03:28:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 03:28:19 --> Final output sent to browser
DEBUG - 2021-01-04 03:28:19 --> Total execution time: 1.3498
INFO - 2021-01-04 03:29:00 --> Config Class Initialized
INFO - 2021-01-04 03:29:00 --> Hooks Class Initialized
DEBUG - 2021-01-04 03:29:00 --> UTF-8 Support Enabled
INFO - 2021-01-04 03:29:00 --> Utf8 Class Initialized
INFO - 2021-01-04 03:29:00 --> URI Class Initialized
INFO - 2021-01-04 03:29:00 --> Router Class Initialized
INFO - 2021-01-04 03:29:00 --> Output Class Initialized
INFO - 2021-01-04 03:29:00 --> Security Class Initialized
DEBUG - 2021-01-04 03:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 03:29:00 --> Input Class Initialized
INFO - 2021-01-04 03:29:00 --> Language Class Initialized
INFO - 2021-01-04 03:29:00 --> Language Class Initialized
INFO - 2021-01-04 03:29:00 --> Config Class Initialized
INFO - 2021-01-04 03:29:00 --> Loader Class Initialized
INFO - 2021-01-04 03:29:00 --> Helper loaded: url_helper
INFO - 2021-01-04 03:29:00 --> Helper loaded: file_helper
INFO - 2021-01-04 03:29:00 --> Helper loaded: form_helper
INFO - 2021-01-04 03:29:00 --> Helper loaded: my_helper
INFO - 2021-01-04 03:29:00 --> Database Driver Class Initialized
DEBUG - 2021-01-04 03:29:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 03:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 03:29:01 --> Controller Class Initialized
DEBUG - 2021-01-04 03:29:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 03:29:01 --> Final output sent to browser
DEBUG - 2021-01-04 03:29:01 --> Total execution time: 1.3672
INFO - 2021-01-04 03:29:13 --> Config Class Initialized
INFO - 2021-01-04 03:29:13 --> Hooks Class Initialized
DEBUG - 2021-01-04 03:29:13 --> UTF-8 Support Enabled
INFO - 2021-01-04 03:29:13 --> Utf8 Class Initialized
INFO - 2021-01-04 03:29:13 --> URI Class Initialized
INFO - 2021-01-04 03:29:13 --> Router Class Initialized
INFO - 2021-01-04 03:29:13 --> Output Class Initialized
INFO - 2021-01-04 03:29:13 --> Security Class Initialized
DEBUG - 2021-01-04 03:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 03:29:13 --> Input Class Initialized
INFO - 2021-01-04 03:29:13 --> Language Class Initialized
INFO - 2021-01-04 03:29:13 --> Language Class Initialized
INFO - 2021-01-04 03:29:13 --> Config Class Initialized
INFO - 2021-01-04 03:29:13 --> Loader Class Initialized
INFO - 2021-01-04 03:29:13 --> Helper loaded: url_helper
INFO - 2021-01-04 03:29:13 --> Helper loaded: file_helper
INFO - 2021-01-04 03:29:13 --> Helper loaded: form_helper
INFO - 2021-01-04 03:29:13 --> Helper loaded: my_helper
INFO - 2021-01-04 03:29:13 --> Database Driver Class Initialized
DEBUG - 2021-01-04 03:29:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 03:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 03:29:13 --> Controller Class Initialized
DEBUG - 2021-01-04 03:29:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 03:29:14 --> Final output sent to browser
DEBUG - 2021-01-04 03:29:14 --> Total execution time: 1.2633
INFO - 2021-01-04 03:29:33 --> Config Class Initialized
INFO - 2021-01-04 03:29:33 --> Hooks Class Initialized
DEBUG - 2021-01-04 03:29:33 --> UTF-8 Support Enabled
INFO - 2021-01-04 03:29:33 --> Utf8 Class Initialized
INFO - 2021-01-04 03:29:33 --> URI Class Initialized
INFO - 2021-01-04 03:29:33 --> Router Class Initialized
INFO - 2021-01-04 03:29:33 --> Output Class Initialized
INFO - 2021-01-04 03:29:33 --> Security Class Initialized
DEBUG - 2021-01-04 03:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 03:29:33 --> Input Class Initialized
INFO - 2021-01-04 03:29:33 --> Language Class Initialized
INFO - 2021-01-04 03:29:33 --> Language Class Initialized
INFO - 2021-01-04 03:29:33 --> Config Class Initialized
INFO - 2021-01-04 03:29:34 --> Loader Class Initialized
INFO - 2021-01-04 03:29:34 --> Helper loaded: url_helper
INFO - 2021-01-04 03:29:34 --> Helper loaded: file_helper
INFO - 2021-01-04 03:29:34 --> Helper loaded: form_helper
INFO - 2021-01-04 03:29:34 --> Helper loaded: my_helper
INFO - 2021-01-04 03:29:34 --> Database Driver Class Initialized
DEBUG - 2021-01-04 03:29:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 03:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 03:29:34 --> Controller Class Initialized
DEBUG - 2021-01-04 03:29:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 03:29:34 --> Final output sent to browser
DEBUG - 2021-01-04 03:29:34 --> Total execution time: 1.3769
INFO - 2021-01-04 03:30:00 --> Config Class Initialized
INFO - 2021-01-04 03:30:00 --> Hooks Class Initialized
DEBUG - 2021-01-04 03:30:00 --> UTF-8 Support Enabled
INFO - 2021-01-04 03:30:00 --> Utf8 Class Initialized
INFO - 2021-01-04 03:30:00 --> URI Class Initialized
INFO - 2021-01-04 03:30:00 --> Router Class Initialized
INFO - 2021-01-04 03:30:00 --> Output Class Initialized
INFO - 2021-01-04 03:30:00 --> Security Class Initialized
DEBUG - 2021-01-04 03:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 03:30:00 --> Input Class Initialized
INFO - 2021-01-04 03:30:00 --> Language Class Initialized
INFO - 2021-01-04 03:30:00 --> Language Class Initialized
INFO - 2021-01-04 03:30:00 --> Config Class Initialized
INFO - 2021-01-04 03:30:00 --> Loader Class Initialized
INFO - 2021-01-04 03:30:01 --> Helper loaded: url_helper
INFO - 2021-01-04 03:30:01 --> Helper loaded: file_helper
INFO - 2021-01-04 03:30:01 --> Helper loaded: form_helper
INFO - 2021-01-04 03:30:01 --> Helper loaded: my_helper
INFO - 2021-01-04 03:30:01 --> Database Driver Class Initialized
DEBUG - 2021-01-04 03:30:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 03:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 03:30:01 --> Controller Class Initialized
DEBUG - 2021-01-04 03:30:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 03:30:01 --> Final output sent to browser
DEBUG - 2021-01-04 03:30:01 --> Total execution time: 1.1504
INFO - 2021-01-04 03:30:14 --> Config Class Initialized
INFO - 2021-01-04 03:30:14 --> Hooks Class Initialized
DEBUG - 2021-01-04 03:30:14 --> UTF-8 Support Enabled
INFO - 2021-01-04 03:30:14 --> Utf8 Class Initialized
INFO - 2021-01-04 03:30:14 --> URI Class Initialized
INFO - 2021-01-04 03:30:14 --> Router Class Initialized
INFO - 2021-01-04 03:30:14 --> Output Class Initialized
INFO - 2021-01-04 03:30:14 --> Security Class Initialized
DEBUG - 2021-01-04 03:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 03:30:14 --> Input Class Initialized
INFO - 2021-01-04 03:30:14 --> Language Class Initialized
INFO - 2021-01-04 03:30:14 --> Language Class Initialized
INFO - 2021-01-04 03:30:14 --> Config Class Initialized
INFO - 2021-01-04 03:30:14 --> Loader Class Initialized
INFO - 2021-01-04 03:30:14 --> Helper loaded: url_helper
INFO - 2021-01-04 03:30:14 --> Helper loaded: file_helper
INFO - 2021-01-04 03:30:14 --> Helper loaded: form_helper
INFO - 2021-01-04 03:30:14 --> Helper loaded: my_helper
INFO - 2021-01-04 03:30:15 --> Database Driver Class Initialized
DEBUG - 2021-01-04 03:30:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 03:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 03:30:15 --> Controller Class Initialized
DEBUG - 2021-01-04 03:30:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 03:30:15 --> Final output sent to browser
DEBUG - 2021-01-04 03:30:15 --> Total execution time: 1.0798
INFO - 2021-01-04 03:32:12 --> Config Class Initialized
INFO - 2021-01-04 03:32:12 --> Hooks Class Initialized
DEBUG - 2021-01-04 03:32:13 --> UTF-8 Support Enabled
INFO - 2021-01-04 03:32:13 --> Utf8 Class Initialized
INFO - 2021-01-04 03:32:13 --> URI Class Initialized
INFO - 2021-01-04 03:32:13 --> Router Class Initialized
INFO - 2021-01-04 03:32:13 --> Output Class Initialized
INFO - 2021-01-04 03:32:13 --> Security Class Initialized
DEBUG - 2021-01-04 03:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 03:32:13 --> Input Class Initialized
INFO - 2021-01-04 03:32:13 --> Language Class Initialized
INFO - 2021-01-04 03:32:13 --> Language Class Initialized
INFO - 2021-01-04 03:32:13 --> Config Class Initialized
INFO - 2021-01-04 03:32:13 --> Loader Class Initialized
INFO - 2021-01-04 03:32:13 --> Helper loaded: url_helper
INFO - 2021-01-04 03:32:13 --> Helper loaded: file_helper
INFO - 2021-01-04 03:32:13 --> Helper loaded: form_helper
INFO - 2021-01-04 03:32:13 --> Helper loaded: my_helper
INFO - 2021-01-04 03:32:13 --> Database Driver Class Initialized
DEBUG - 2021-01-04 03:32:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 03:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 03:32:13 --> Controller Class Initialized
DEBUG - 2021-01-04 03:32:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 03:32:14 --> Final output sent to browser
DEBUG - 2021-01-04 03:32:14 --> Total execution time: 1.2651
INFO - 2021-01-04 03:32:32 --> Config Class Initialized
INFO - 2021-01-04 03:32:32 --> Hooks Class Initialized
DEBUG - 2021-01-04 03:32:32 --> UTF-8 Support Enabled
INFO - 2021-01-04 03:32:32 --> Utf8 Class Initialized
INFO - 2021-01-04 03:32:32 --> URI Class Initialized
INFO - 2021-01-04 03:32:32 --> Router Class Initialized
INFO - 2021-01-04 03:32:32 --> Output Class Initialized
INFO - 2021-01-04 03:32:32 --> Security Class Initialized
DEBUG - 2021-01-04 03:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 03:32:32 --> Input Class Initialized
INFO - 2021-01-04 03:32:33 --> Language Class Initialized
INFO - 2021-01-04 03:32:33 --> Language Class Initialized
INFO - 2021-01-04 03:32:33 --> Config Class Initialized
INFO - 2021-01-04 03:32:33 --> Loader Class Initialized
INFO - 2021-01-04 03:32:33 --> Helper loaded: url_helper
INFO - 2021-01-04 03:32:33 --> Helper loaded: file_helper
INFO - 2021-01-04 03:32:33 --> Helper loaded: form_helper
INFO - 2021-01-04 03:32:33 --> Helper loaded: my_helper
INFO - 2021-01-04 03:32:33 --> Database Driver Class Initialized
DEBUG - 2021-01-04 03:32:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 03:32:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 03:32:33 --> Controller Class Initialized
DEBUG - 2021-01-04 03:32:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 03:32:33 --> Final output sent to browser
DEBUG - 2021-01-04 03:32:33 --> Total execution time: 1.1773
INFO - 2021-01-04 03:33:19 --> Config Class Initialized
INFO - 2021-01-04 03:33:19 --> Hooks Class Initialized
DEBUG - 2021-01-04 03:33:20 --> UTF-8 Support Enabled
INFO - 2021-01-04 03:33:20 --> Utf8 Class Initialized
INFO - 2021-01-04 03:33:20 --> URI Class Initialized
INFO - 2021-01-04 03:33:20 --> Router Class Initialized
INFO - 2021-01-04 03:33:20 --> Output Class Initialized
INFO - 2021-01-04 03:33:20 --> Security Class Initialized
DEBUG - 2021-01-04 03:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 03:33:20 --> Input Class Initialized
INFO - 2021-01-04 03:33:20 --> Language Class Initialized
INFO - 2021-01-04 03:33:20 --> Language Class Initialized
INFO - 2021-01-04 03:33:20 --> Config Class Initialized
INFO - 2021-01-04 03:33:20 --> Loader Class Initialized
INFO - 2021-01-04 03:33:20 --> Helper loaded: url_helper
INFO - 2021-01-04 03:33:20 --> Helper loaded: file_helper
INFO - 2021-01-04 03:33:20 --> Helper loaded: form_helper
INFO - 2021-01-04 03:33:20 --> Helper loaded: my_helper
INFO - 2021-01-04 03:33:20 --> Database Driver Class Initialized
DEBUG - 2021-01-04 03:33:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 03:33:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 03:33:20 --> Controller Class Initialized
DEBUG - 2021-01-04 03:33:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 03:33:21 --> Final output sent to browser
DEBUG - 2021-01-04 03:33:21 --> Total execution time: 1.1560
INFO - 2021-01-04 03:35:41 --> Config Class Initialized
INFO - 2021-01-04 03:35:41 --> Hooks Class Initialized
DEBUG - 2021-01-04 03:35:41 --> UTF-8 Support Enabled
INFO - 2021-01-04 03:35:41 --> Utf8 Class Initialized
INFO - 2021-01-04 03:35:41 --> URI Class Initialized
INFO - 2021-01-04 03:35:41 --> Router Class Initialized
INFO - 2021-01-04 03:35:42 --> Output Class Initialized
INFO - 2021-01-04 03:35:42 --> Security Class Initialized
DEBUG - 2021-01-04 03:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 03:35:42 --> Input Class Initialized
INFO - 2021-01-04 03:35:42 --> Language Class Initialized
INFO - 2021-01-04 03:35:42 --> Language Class Initialized
INFO - 2021-01-04 03:35:42 --> Config Class Initialized
INFO - 2021-01-04 03:35:42 --> Loader Class Initialized
INFO - 2021-01-04 03:35:42 --> Helper loaded: url_helper
INFO - 2021-01-04 03:35:42 --> Helper loaded: file_helper
INFO - 2021-01-04 03:35:42 --> Helper loaded: form_helper
INFO - 2021-01-04 03:35:42 --> Helper loaded: my_helper
INFO - 2021-01-04 03:35:42 --> Database Driver Class Initialized
DEBUG - 2021-01-04 03:35:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 03:35:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 03:35:42 --> Controller Class Initialized
DEBUG - 2021-01-04 03:35:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 03:35:43 --> Final output sent to browser
DEBUG - 2021-01-04 03:35:43 --> Total execution time: 1.5149
INFO - 2021-01-04 03:36:37 --> Config Class Initialized
INFO - 2021-01-04 03:36:37 --> Hooks Class Initialized
DEBUG - 2021-01-04 03:36:37 --> UTF-8 Support Enabled
INFO - 2021-01-04 03:36:37 --> Utf8 Class Initialized
INFO - 2021-01-04 03:36:37 --> URI Class Initialized
INFO - 2021-01-04 03:36:37 --> Router Class Initialized
INFO - 2021-01-04 03:36:37 --> Output Class Initialized
INFO - 2021-01-04 03:36:37 --> Security Class Initialized
DEBUG - 2021-01-04 03:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 03:36:37 --> Input Class Initialized
INFO - 2021-01-04 03:36:37 --> Language Class Initialized
INFO - 2021-01-04 03:36:37 --> Language Class Initialized
INFO - 2021-01-04 03:36:37 --> Config Class Initialized
INFO - 2021-01-04 03:36:37 --> Loader Class Initialized
INFO - 2021-01-04 03:36:37 --> Helper loaded: url_helper
INFO - 2021-01-04 03:36:37 --> Helper loaded: file_helper
INFO - 2021-01-04 03:36:37 --> Helper loaded: form_helper
INFO - 2021-01-04 03:36:37 --> Helper loaded: my_helper
INFO - 2021-01-04 03:36:37 --> Database Driver Class Initialized
DEBUG - 2021-01-04 03:36:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 03:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 03:36:38 --> Controller Class Initialized
DEBUG - 2021-01-04 03:36:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 03:36:38 --> Final output sent to browser
DEBUG - 2021-01-04 03:36:38 --> Total execution time: 1.1981
INFO - 2021-01-04 03:37:06 --> Config Class Initialized
INFO - 2021-01-04 03:37:06 --> Hooks Class Initialized
DEBUG - 2021-01-04 03:37:06 --> UTF-8 Support Enabled
INFO - 2021-01-04 03:37:07 --> Utf8 Class Initialized
INFO - 2021-01-04 03:37:07 --> URI Class Initialized
INFO - 2021-01-04 03:37:07 --> Router Class Initialized
INFO - 2021-01-04 03:37:07 --> Output Class Initialized
INFO - 2021-01-04 03:37:07 --> Security Class Initialized
DEBUG - 2021-01-04 03:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 03:37:07 --> Input Class Initialized
INFO - 2021-01-04 03:37:07 --> Language Class Initialized
INFO - 2021-01-04 03:37:07 --> Language Class Initialized
INFO - 2021-01-04 03:37:07 --> Config Class Initialized
INFO - 2021-01-04 03:37:07 --> Loader Class Initialized
INFO - 2021-01-04 03:37:07 --> Helper loaded: url_helper
INFO - 2021-01-04 03:37:07 --> Helper loaded: file_helper
INFO - 2021-01-04 03:37:07 --> Helper loaded: form_helper
INFO - 2021-01-04 03:37:07 --> Helper loaded: my_helper
INFO - 2021-01-04 03:37:07 --> Database Driver Class Initialized
DEBUG - 2021-01-04 03:37:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 03:37:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 03:37:07 --> Controller Class Initialized
DEBUG - 2021-01-04 03:37:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 03:37:08 --> Final output sent to browser
DEBUG - 2021-01-04 03:37:08 --> Total execution time: 1.3879
INFO - 2021-01-04 03:37:40 --> Config Class Initialized
INFO - 2021-01-04 03:37:40 --> Hooks Class Initialized
DEBUG - 2021-01-04 03:37:40 --> UTF-8 Support Enabled
INFO - 2021-01-04 03:37:40 --> Utf8 Class Initialized
INFO - 2021-01-04 03:37:40 --> URI Class Initialized
INFO - 2021-01-04 03:37:40 --> Router Class Initialized
INFO - 2021-01-04 03:37:40 --> Output Class Initialized
INFO - 2021-01-04 03:37:40 --> Security Class Initialized
DEBUG - 2021-01-04 03:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 03:37:40 --> Input Class Initialized
INFO - 2021-01-04 03:37:41 --> Language Class Initialized
INFO - 2021-01-04 03:37:41 --> Language Class Initialized
INFO - 2021-01-04 03:37:41 --> Config Class Initialized
INFO - 2021-01-04 03:37:41 --> Loader Class Initialized
INFO - 2021-01-04 03:37:41 --> Helper loaded: url_helper
INFO - 2021-01-04 03:37:41 --> Helper loaded: file_helper
INFO - 2021-01-04 03:37:41 --> Helper loaded: form_helper
INFO - 2021-01-04 03:37:41 --> Helper loaded: my_helper
INFO - 2021-01-04 03:37:41 --> Database Driver Class Initialized
DEBUG - 2021-01-04 03:37:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 03:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 03:37:41 --> Controller Class Initialized
DEBUG - 2021-01-04 03:37:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 03:37:41 --> Final output sent to browser
DEBUG - 2021-01-04 03:37:41 --> Total execution time: 1.2357
INFO - 2021-01-04 03:38:40 --> Config Class Initialized
INFO - 2021-01-04 03:38:40 --> Hooks Class Initialized
DEBUG - 2021-01-04 03:38:40 --> UTF-8 Support Enabled
INFO - 2021-01-04 03:38:40 --> Utf8 Class Initialized
INFO - 2021-01-04 03:38:40 --> URI Class Initialized
INFO - 2021-01-04 03:38:40 --> Router Class Initialized
INFO - 2021-01-04 03:38:40 --> Output Class Initialized
INFO - 2021-01-04 03:38:41 --> Security Class Initialized
DEBUG - 2021-01-04 03:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 03:38:41 --> Input Class Initialized
INFO - 2021-01-04 03:38:41 --> Language Class Initialized
INFO - 2021-01-04 03:38:41 --> Language Class Initialized
INFO - 2021-01-04 03:38:41 --> Config Class Initialized
INFO - 2021-01-04 03:38:41 --> Loader Class Initialized
INFO - 2021-01-04 03:38:41 --> Helper loaded: url_helper
INFO - 2021-01-04 03:38:41 --> Helper loaded: file_helper
INFO - 2021-01-04 03:38:41 --> Helper loaded: form_helper
INFO - 2021-01-04 03:38:41 --> Helper loaded: my_helper
INFO - 2021-01-04 03:38:41 --> Database Driver Class Initialized
DEBUG - 2021-01-04 03:38:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 03:38:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 03:38:41 --> Controller Class Initialized
DEBUG - 2021-01-04 03:38:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 03:38:41 --> Final output sent to browser
DEBUG - 2021-01-04 03:38:41 --> Total execution time: 1.2015
INFO - 2021-01-04 03:38:59 --> Config Class Initialized
INFO - 2021-01-04 03:38:59 --> Hooks Class Initialized
DEBUG - 2021-01-04 03:38:59 --> UTF-8 Support Enabled
INFO - 2021-01-04 03:38:59 --> Utf8 Class Initialized
INFO - 2021-01-04 03:38:59 --> URI Class Initialized
INFO - 2021-01-04 03:38:59 --> Router Class Initialized
INFO - 2021-01-04 03:38:59 --> Output Class Initialized
INFO - 2021-01-04 03:38:59 --> Security Class Initialized
DEBUG - 2021-01-04 03:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 03:38:59 --> Input Class Initialized
INFO - 2021-01-04 03:38:59 --> Language Class Initialized
INFO - 2021-01-04 03:38:59 --> Language Class Initialized
INFO - 2021-01-04 03:38:59 --> Config Class Initialized
INFO - 2021-01-04 03:38:59 --> Loader Class Initialized
INFO - 2021-01-04 03:38:59 --> Helper loaded: url_helper
INFO - 2021-01-04 03:38:59 --> Helper loaded: file_helper
INFO - 2021-01-04 03:39:00 --> Helper loaded: form_helper
INFO - 2021-01-04 03:39:00 --> Helper loaded: my_helper
INFO - 2021-01-04 03:39:00 --> Database Driver Class Initialized
DEBUG - 2021-01-04 03:39:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 03:39:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 03:39:00 --> Controller Class Initialized
DEBUG - 2021-01-04 03:39:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 03:39:00 --> Final output sent to browser
DEBUG - 2021-01-04 03:39:00 --> Total execution time: 1.2307
INFO - 2021-01-04 03:39:24 --> Config Class Initialized
INFO - 2021-01-04 03:39:24 --> Hooks Class Initialized
DEBUG - 2021-01-04 03:39:24 --> UTF-8 Support Enabled
INFO - 2021-01-04 03:39:24 --> Utf8 Class Initialized
INFO - 2021-01-04 03:39:24 --> URI Class Initialized
INFO - 2021-01-04 03:39:24 --> Router Class Initialized
INFO - 2021-01-04 03:39:24 --> Output Class Initialized
INFO - 2021-01-04 03:39:24 --> Security Class Initialized
DEBUG - 2021-01-04 03:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 03:39:25 --> Input Class Initialized
INFO - 2021-01-04 03:39:25 --> Language Class Initialized
INFO - 2021-01-04 03:39:25 --> Language Class Initialized
INFO - 2021-01-04 03:39:25 --> Config Class Initialized
INFO - 2021-01-04 03:39:25 --> Loader Class Initialized
INFO - 2021-01-04 03:39:25 --> Helper loaded: url_helper
INFO - 2021-01-04 03:39:25 --> Helper loaded: file_helper
INFO - 2021-01-04 03:39:25 --> Helper loaded: form_helper
INFO - 2021-01-04 03:39:25 --> Helper loaded: my_helper
INFO - 2021-01-04 03:39:25 --> Database Driver Class Initialized
DEBUG - 2021-01-04 03:39:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 03:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 03:39:25 --> Controller Class Initialized
DEBUG - 2021-01-04 03:39:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 03:39:26 --> Final output sent to browser
DEBUG - 2021-01-04 03:39:26 --> Total execution time: 1.3415
INFO - 2021-01-04 03:39:35 --> Config Class Initialized
INFO - 2021-01-04 03:39:35 --> Hooks Class Initialized
DEBUG - 2021-01-04 03:39:35 --> UTF-8 Support Enabled
INFO - 2021-01-04 03:39:35 --> Utf8 Class Initialized
INFO - 2021-01-04 03:39:36 --> URI Class Initialized
INFO - 2021-01-04 03:39:36 --> Router Class Initialized
INFO - 2021-01-04 03:39:36 --> Output Class Initialized
INFO - 2021-01-04 03:39:36 --> Security Class Initialized
DEBUG - 2021-01-04 03:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 03:39:36 --> Input Class Initialized
INFO - 2021-01-04 03:39:36 --> Language Class Initialized
INFO - 2021-01-04 03:39:36 --> Language Class Initialized
INFO - 2021-01-04 03:39:36 --> Config Class Initialized
INFO - 2021-01-04 03:39:36 --> Loader Class Initialized
INFO - 2021-01-04 03:39:36 --> Helper loaded: url_helper
INFO - 2021-01-04 03:39:36 --> Helper loaded: file_helper
INFO - 2021-01-04 03:39:36 --> Helper loaded: form_helper
INFO - 2021-01-04 03:39:36 --> Helper loaded: my_helper
INFO - 2021-01-04 03:39:36 --> Database Driver Class Initialized
DEBUG - 2021-01-04 03:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 03:39:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 03:39:36 --> Controller Class Initialized
DEBUG - 2021-01-04 03:39:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 03:39:37 --> Final output sent to browser
DEBUG - 2021-01-04 03:39:37 --> Total execution time: 1.5456
INFO - 2021-01-04 03:39:43 --> Config Class Initialized
INFO - 2021-01-04 03:39:43 --> Hooks Class Initialized
DEBUG - 2021-01-04 03:39:43 --> UTF-8 Support Enabled
INFO - 2021-01-04 03:39:43 --> Utf8 Class Initialized
INFO - 2021-01-04 03:39:43 --> URI Class Initialized
INFO - 2021-01-04 03:39:43 --> Router Class Initialized
INFO - 2021-01-04 03:39:43 --> Output Class Initialized
INFO - 2021-01-04 03:39:43 --> Security Class Initialized
DEBUG - 2021-01-04 03:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 03:39:43 --> Input Class Initialized
INFO - 2021-01-04 03:39:44 --> Language Class Initialized
INFO - 2021-01-04 03:39:44 --> Language Class Initialized
INFO - 2021-01-04 03:39:44 --> Config Class Initialized
INFO - 2021-01-04 03:39:44 --> Loader Class Initialized
INFO - 2021-01-04 03:39:44 --> Helper loaded: url_helper
INFO - 2021-01-04 03:39:44 --> Helper loaded: file_helper
INFO - 2021-01-04 03:39:44 --> Helper loaded: form_helper
INFO - 2021-01-04 03:39:44 --> Helper loaded: my_helper
INFO - 2021-01-04 03:39:44 --> Database Driver Class Initialized
DEBUG - 2021-01-04 03:39:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 03:39:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 03:39:44 --> Controller Class Initialized
DEBUG - 2021-01-04 03:39:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 03:39:44 --> Final output sent to browser
DEBUG - 2021-01-04 03:39:44 --> Total execution time: 1.3536
INFO - 2021-01-04 03:40:26 --> Config Class Initialized
INFO - 2021-01-04 03:40:26 --> Hooks Class Initialized
DEBUG - 2021-01-04 03:40:26 --> UTF-8 Support Enabled
INFO - 2021-01-04 03:40:27 --> Utf8 Class Initialized
INFO - 2021-01-04 03:40:27 --> URI Class Initialized
INFO - 2021-01-04 03:40:27 --> Router Class Initialized
INFO - 2021-01-04 03:40:27 --> Output Class Initialized
INFO - 2021-01-04 03:40:27 --> Security Class Initialized
DEBUG - 2021-01-04 03:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 03:40:27 --> Input Class Initialized
INFO - 2021-01-04 03:40:27 --> Language Class Initialized
INFO - 2021-01-04 03:40:27 --> Language Class Initialized
INFO - 2021-01-04 03:40:27 --> Config Class Initialized
INFO - 2021-01-04 03:40:27 --> Loader Class Initialized
INFO - 2021-01-04 03:40:27 --> Helper loaded: url_helper
INFO - 2021-01-04 03:40:27 --> Helper loaded: file_helper
INFO - 2021-01-04 03:40:27 --> Helper loaded: form_helper
INFO - 2021-01-04 03:40:27 --> Helper loaded: my_helper
INFO - 2021-01-04 03:40:27 --> Database Driver Class Initialized
DEBUG - 2021-01-04 03:40:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 03:40:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 03:40:27 --> Controller Class Initialized
DEBUG - 2021-01-04 03:40:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 03:40:28 --> Final output sent to browser
DEBUG - 2021-01-04 03:40:28 --> Total execution time: 1.2644
INFO - 2021-01-04 03:40:38 --> Config Class Initialized
INFO - 2021-01-04 03:40:38 --> Hooks Class Initialized
DEBUG - 2021-01-04 03:40:38 --> UTF-8 Support Enabled
INFO - 2021-01-04 03:40:38 --> Utf8 Class Initialized
INFO - 2021-01-04 03:40:38 --> URI Class Initialized
INFO - 2021-01-04 03:40:38 --> Router Class Initialized
INFO - 2021-01-04 03:40:38 --> Output Class Initialized
INFO - 2021-01-04 03:40:39 --> Security Class Initialized
DEBUG - 2021-01-04 03:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 03:40:39 --> Input Class Initialized
INFO - 2021-01-04 03:40:39 --> Language Class Initialized
INFO - 2021-01-04 03:40:39 --> Language Class Initialized
INFO - 2021-01-04 03:40:39 --> Config Class Initialized
INFO - 2021-01-04 03:40:39 --> Loader Class Initialized
INFO - 2021-01-04 03:40:39 --> Helper loaded: url_helper
INFO - 2021-01-04 03:40:39 --> Helper loaded: file_helper
INFO - 2021-01-04 03:40:39 --> Helper loaded: form_helper
INFO - 2021-01-04 03:40:39 --> Helper loaded: my_helper
INFO - 2021-01-04 03:40:39 --> Database Driver Class Initialized
DEBUG - 2021-01-04 03:40:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 03:40:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 03:40:39 --> Controller Class Initialized
DEBUG - 2021-01-04 03:40:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 03:40:40 --> Final output sent to browser
DEBUG - 2021-01-04 03:40:40 --> Total execution time: 1.3670
INFO - 2021-01-04 03:41:55 --> Config Class Initialized
INFO - 2021-01-04 03:41:55 --> Hooks Class Initialized
DEBUG - 2021-01-04 03:41:55 --> UTF-8 Support Enabled
INFO - 2021-01-04 03:41:55 --> Utf8 Class Initialized
INFO - 2021-01-04 03:41:55 --> URI Class Initialized
INFO - 2021-01-04 03:41:55 --> Router Class Initialized
INFO - 2021-01-04 03:41:55 --> Output Class Initialized
INFO - 2021-01-04 03:41:55 --> Security Class Initialized
DEBUG - 2021-01-04 03:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 03:41:55 --> Input Class Initialized
INFO - 2021-01-04 03:41:55 --> Language Class Initialized
INFO - 2021-01-04 03:41:55 --> Language Class Initialized
INFO - 2021-01-04 03:41:55 --> Config Class Initialized
INFO - 2021-01-04 03:41:55 --> Loader Class Initialized
INFO - 2021-01-04 03:41:55 --> Helper loaded: url_helper
INFO - 2021-01-04 03:41:55 --> Helper loaded: file_helper
INFO - 2021-01-04 03:41:55 --> Helper loaded: form_helper
INFO - 2021-01-04 03:41:55 --> Helper loaded: my_helper
INFO - 2021-01-04 03:41:55 --> Database Driver Class Initialized
DEBUG - 2021-01-04 03:41:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 03:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 03:41:56 --> Controller Class Initialized
DEBUG - 2021-01-04 03:41:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 03:41:56 --> Final output sent to browser
DEBUG - 2021-01-04 03:41:56 --> Total execution time: 1.2398
INFO - 2021-01-04 03:42:13 --> Config Class Initialized
INFO - 2021-01-04 03:42:13 --> Hooks Class Initialized
DEBUG - 2021-01-04 03:42:13 --> UTF-8 Support Enabled
INFO - 2021-01-04 03:42:13 --> Utf8 Class Initialized
INFO - 2021-01-04 03:42:13 --> URI Class Initialized
INFO - 2021-01-04 03:42:13 --> Router Class Initialized
INFO - 2021-01-04 03:42:13 --> Output Class Initialized
INFO - 2021-01-04 03:42:14 --> Security Class Initialized
DEBUG - 2021-01-04 03:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 03:42:14 --> Input Class Initialized
INFO - 2021-01-04 03:42:14 --> Language Class Initialized
INFO - 2021-01-04 03:42:14 --> Language Class Initialized
INFO - 2021-01-04 03:42:14 --> Config Class Initialized
INFO - 2021-01-04 03:42:14 --> Loader Class Initialized
INFO - 2021-01-04 03:42:14 --> Helper loaded: url_helper
INFO - 2021-01-04 03:42:14 --> Helper loaded: file_helper
INFO - 2021-01-04 03:42:14 --> Helper loaded: form_helper
INFO - 2021-01-04 03:42:14 --> Helper loaded: my_helper
INFO - 2021-01-04 03:42:14 --> Database Driver Class Initialized
DEBUG - 2021-01-04 03:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 03:42:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 03:42:14 --> Controller Class Initialized
DEBUG - 2021-01-04 03:42:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 03:42:15 --> Final output sent to browser
DEBUG - 2021-01-04 03:42:15 --> Total execution time: 1.3630
INFO - 2021-01-04 03:42:25 --> Config Class Initialized
INFO - 2021-01-04 03:42:25 --> Hooks Class Initialized
DEBUG - 2021-01-04 03:42:25 --> UTF-8 Support Enabled
INFO - 2021-01-04 03:42:25 --> Utf8 Class Initialized
INFO - 2021-01-04 03:42:25 --> URI Class Initialized
INFO - 2021-01-04 03:42:25 --> Router Class Initialized
INFO - 2021-01-04 03:42:26 --> Output Class Initialized
INFO - 2021-01-04 03:42:26 --> Security Class Initialized
DEBUG - 2021-01-04 03:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 03:42:26 --> Input Class Initialized
INFO - 2021-01-04 03:42:26 --> Language Class Initialized
INFO - 2021-01-04 03:42:26 --> Language Class Initialized
INFO - 2021-01-04 03:42:26 --> Config Class Initialized
INFO - 2021-01-04 03:42:26 --> Loader Class Initialized
INFO - 2021-01-04 03:42:26 --> Helper loaded: url_helper
INFO - 2021-01-04 03:42:26 --> Helper loaded: file_helper
INFO - 2021-01-04 03:42:26 --> Helper loaded: form_helper
INFO - 2021-01-04 03:42:26 --> Helper loaded: my_helper
INFO - 2021-01-04 03:42:26 --> Database Driver Class Initialized
DEBUG - 2021-01-04 03:42:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 03:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 03:42:26 --> Controller Class Initialized
DEBUG - 2021-01-04 03:42:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 03:42:27 --> Final output sent to browser
DEBUG - 2021-01-04 03:42:27 --> Total execution time: 1.3046
INFO - 2021-01-04 03:42:45 --> Config Class Initialized
INFO - 2021-01-04 03:42:45 --> Hooks Class Initialized
DEBUG - 2021-01-04 03:42:45 --> UTF-8 Support Enabled
INFO - 2021-01-04 03:42:45 --> Utf8 Class Initialized
INFO - 2021-01-04 03:42:45 --> URI Class Initialized
INFO - 2021-01-04 03:42:45 --> Router Class Initialized
INFO - 2021-01-04 03:42:45 --> Output Class Initialized
INFO - 2021-01-04 03:42:45 --> Security Class Initialized
DEBUG - 2021-01-04 03:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 03:42:46 --> Input Class Initialized
INFO - 2021-01-04 03:42:46 --> Language Class Initialized
INFO - 2021-01-04 03:42:46 --> Language Class Initialized
INFO - 2021-01-04 03:42:46 --> Config Class Initialized
INFO - 2021-01-04 03:42:46 --> Loader Class Initialized
INFO - 2021-01-04 03:42:46 --> Helper loaded: url_helper
INFO - 2021-01-04 03:42:46 --> Helper loaded: file_helper
INFO - 2021-01-04 03:42:46 --> Helper loaded: form_helper
INFO - 2021-01-04 03:42:46 --> Helper loaded: my_helper
INFO - 2021-01-04 03:42:46 --> Database Driver Class Initialized
DEBUG - 2021-01-04 03:42:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 03:42:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 03:42:46 --> Controller Class Initialized
DEBUG - 2021-01-04 03:42:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 03:42:47 --> Final output sent to browser
DEBUG - 2021-01-04 03:42:47 --> Total execution time: 1.4564
INFO - 2021-01-04 03:43:09 --> Config Class Initialized
INFO - 2021-01-04 03:43:09 --> Hooks Class Initialized
DEBUG - 2021-01-04 03:43:09 --> UTF-8 Support Enabled
INFO - 2021-01-04 03:43:09 --> Utf8 Class Initialized
INFO - 2021-01-04 03:43:09 --> URI Class Initialized
INFO - 2021-01-04 03:43:09 --> Router Class Initialized
INFO - 2021-01-04 03:43:09 --> Output Class Initialized
INFO - 2021-01-04 03:43:09 --> Security Class Initialized
DEBUG - 2021-01-04 03:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 03:43:09 --> Input Class Initialized
INFO - 2021-01-04 03:43:09 --> Language Class Initialized
INFO - 2021-01-04 03:43:10 --> Language Class Initialized
INFO - 2021-01-04 03:43:10 --> Config Class Initialized
INFO - 2021-01-04 03:43:10 --> Loader Class Initialized
INFO - 2021-01-04 03:43:10 --> Helper loaded: url_helper
INFO - 2021-01-04 03:43:10 --> Helper loaded: file_helper
INFO - 2021-01-04 03:43:10 --> Helper loaded: form_helper
INFO - 2021-01-04 03:43:10 --> Helper loaded: my_helper
INFO - 2021-01-04 03:43:10 --> Database Driver Class Initialized
DEBUG - 2021-01-04 03:43:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 03:43:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 03:43:10 --> Controller Class Initialized
DEBUG - 2021-01-04 03:43:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 03:43:10 --> Final output sent to browser
DEBUG - 2021-01-04 03:43:10 --> Total execution time: 1.4211
INFO - 2021-01-04 03:44:29 --> Config Class Initialized
INFO - 2021-01-04 03:44:29 --> Hooks Class Initialized
DEBUG - 2021-01-04 03:44:29 --> UTF-8 Support Enabled
INFO - 2021-01-04 03:44:29 --> Utf8 Class Initialized
INFO - 2021-01-04 03:44:29 --> URI Class Initialized
INFO - 2021-01-04 03:44:29 --> Router Class Initialized
INFO - 2021-01-04 03:44:29 --> Output Class Initialized
INFO - 2021-01-04 03:44:30 --> Security Class Initialized
DEBUG - 2021-01-04 03:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 03:44:30 --> Input Class Initialized
INFO - 2021-01-04 03:44:30 --> Language Class Initialized
INFO - 2021-01-04 03:44:30 --> Language Class Initialized
INFO - 2021-01-04 03:44:30 --> Config Class Initialized
INFO - 2021-01-04 03:44:30 --> Loader Class Initialized
INFO - 2021-01-04 03:44:30 --> Helper loaded: url_helper
INFO - 2021-01-04 03:44:30 --> Helper loaded: file_helper
INFO - 2021-01-04 03:44:30 --> Helper loaded: form_helper
INFO - 2021-01-04 03:44:30 --> Helper loaded: my_helper
INFO - 2021-01-04 03:44:30 --> Database Driver Class Initialized
DEBUG - 2021-01-04 03:44:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 03:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 03:44:30 --> Controller Class Initialized
DEBUG - 2021-01-04 03:44:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 03:44:30 --> Final output sent to browser
DEBUG - 2021-01-04 03:44:31 --> Total execution time: 1.2645
INFO - 2021-01-04 03:44:39 --> Config Class Initialized
INFO - 2021-01-04 03:44:39 --> Hooks Class Initialized
DEBUG - 2021-01-04 03:44:40 --> UTF-8 Support Enabled
INFO - 2021-01-04 03:44:40 --> Utf8 Class Initialized
INFO - 2021-01-04 03:44:40 --> URI Class Initialized
INFO - 2021-01-04 03:44:40 --> Router Class Initialized
INFO - 2021-01-04 03:44:40 --> Output Class Initialized
INFO - 2021-01-04 03:44:40 --> Security Class Initialized
DEBUG - 2021-01-04 03:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 03:44:40 --> Input Class Initialized
INFO - 2021-01-04 03:44:40 --> Language Class Initialized
INFO - 2021-01-04 03:44:40 --> Language Class Initialized
INFO - 2021-01-04 03:44:40 --> Config Class Initialized
INFO - 2021-01-04 03:44:40 --> Loader Class Initialized
INFO - 2021-01-04 03:44:40 --> Helper loaded: url_helper
INFO - 2021-01-04 03:44:40 --> Helper loaded: file_helper
INFO - 2021-01-04 03:44:40 --> Helper loaded: form_helper
INFO - 2021-01-04 03:44:40 --> Helper loaded: my_helper
INFO - 2021-01-04 03:44:40 --> Database Driver Class Initialized
DEBUG - 2021-01-04 03:44:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 03:44:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 03:44:40 --> Controller Class Initialized
DEBUG - 2021-01-04 03:44:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 03:44:41 --> Final output sent to browser
DEBUG - 2021-01-04 03:44:41 --> Total execution time: 1.1213
INFO - 2021-01-04 03:44:42 --> Config Class Initialized
INFO - 2021-01-04 03:44:42 --> Hooks Class Initialized
DEBUG - 2021-01-04 03:44:42 --> UTF-8 Support Enabled
INFO - 2021-01-04 03:44:42 --> Utf8 Class Initialized
INFO - 2021-01-04 03:44:43 --> URI Class Initialized
INFO - 2021-01-04 03:44:43 --> Router Class Initialized
INFO - 2021-01-04 03:44:43 --> Output Class Initialized
INFO - 2021-01-04 03:44:43 --> Security Class Initialized
DEBUG - 2021-01-04 03:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 03:44:43 --> Input Class Initialized
INFO - 2021-01-04 03:44:43 --> Language Class Initialized
INFO - 2021-01-04 03:44:43 --> Language Class Initialized
INFO - 2021-01-04 03:44:43 --> Config Class Initialized
INFO - 2021-01-04 03:44:43 --> Loader Class Initialized
INFO - 2021-01-04 03:44:43 --> Helper loaded: url_helper
INFO - 2021-01-04 03:44:43 --> Helper loaded: file_helper
INFO - 2021-01-04 03:44:43 --> Helper loaded: form_helper
INFO - 2021-01-04 03:44:43 --> Helper loaded: my_helper
INFO - 2021-01-04 03:44:43 --> Database Driver Class Initialized
DEBUG - 2021-01-04 03:44:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 03:44:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 03:44:43 --> Controller Class Initialized
DEBUG - 2021-01-04 03:44:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 03:44:43 --> Final output sent to browser
DEBUG - 2021-01-04 03:44:43 --> Total execution time: 0.9514
INFO - 2021-01-04 03:45:06 --> Config Class Initialized
INFO - 2021-01-04 03:45:06 --> Hooks Class Initialized
DEBUG - 2021-01-04 03:45:06 --> UTF-8 Support Enabled
INFO - 2021-01-04 03:45:06 --> Utf8 Class Initialized
INFO - 2021-01-04 03:45:06 --> URI Class Initialized
INFO - 2021-01-04 03:45:06 --> Router Class Initialized
INFO - 2021-01-04 03:45:06 --> Output Class Initialized
INFO - 2021-01-04 03:45:06 --> Security Class Initialized
DEBUG - 2021-01-04 03:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 03:45:06 --> Input Class Initialized
INFO - 2021-01-04 03:45:06 --> Language Class Initialized
INFO - 2021-01-04 03:45:06 --> Language Class Initialized
INFO - 2021-01-04 03:45:06 --> Config Class Initialized
INFO - 2021-01-04 03:45:06 --> Loader Class Initialized
INFO - 2021-01-04 03:45:06 --> Helper loaded: url_helper
INFO - 2021-01-04 03:45:06 --> Helper loaded: file_helper
INFO - 2021-01-04 03:45:06 --> Helper loaded: form_helper
INFO - 2021-01-04 03:45:06 --> Helper loaded: my_helper
INFO - 2021-01-04 03:45:06 --> Database Driver Class Initialized
DEBUG - 2021-01-04 03:45:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 03:45:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 03:45:07 --> Controller Class Initialized
DEBUG - 2021-01-04 03:45:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 03:45:07 --> Final output sent to browser
DEBUG - 2021-01-04 03:45:07 --> Total execution time: 1.1254
INFO - 2021-01-04 03:45:40 --> Config Class Initialized
INFO - 2021-01-04 03:45:40 --> Hooks Class Initialized
DEBUG - 2021-01-04 03:45:40 --> UTF-8 Support Enabled
INFO - 2021-01-04 03:45:40 --> Utf8 Class Initialized
INFO - 2021-01-04 03:45:40 --> URI Class Initialized
INFO - 2021-01-04 03:45:40 --> Router Class Initialized
INFO - 2021-01-04 03:45:40 --> Output Class Initialized
INFO - 2021-01-04 03:45:41 --> Security Class Initialized
DEBUG - 2021-01-04 03:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 03:45:41 --> Input Class Initialized
INFO - 2021-01-04 03:45:41 --> Language Class Initialized
INFO - 2021-01-04 03:45:41 --> Language Class Initialized
INFO - 2021-01-04 03:45:41 --> Config Class Initialized
INFO - 2021-01-04 03:45:41 --> Loader Class Initialized
INFO - 2021-01-04 03:45:41 --> Helper loaded: url_helper
INFO - 2021-01-04 03:45:41 --> Helper loaded: file_helper
INFO - 2021-01-04 03:45:41 --> Helper loaded: form_helper
INFO - 2021-01-04 03:45:41 --> Helper loaded: my_helper
INFO - 2021-01-04 03:45:41 --> Database Driver Class Initialized
DEBUG - 2021-01-04 03:45:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 03:45:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 03:45:41 --> Controller Class Initialized
DEBUG - 2021-01-04 03:45:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 03:45:41 --> Final output sent to browser
DEBUG - 2021-01-04 03:45:41 --> Total execution time: 1.2135
INFO - 2021-01-04 03:46:05 --> Config Class Initialized
INFO - 2021-01-04 03:46:05 --> Hooks Class Initialized
DEBUG - 2021-01-04 03:46:05 --> UTF-8 Support Enabled
INFO - 2021-01-04 03:46:05 --> Utf8 Class Initialized
INFO - 2021-01-04 03:46:05 --> URI Class Initialized
INFO - 2021-01-04 03:46:05 --> Router Class Initialized
INFO - 2021-01-04 03:46:05 --> Output Class Initialized
INFO - 2021-01-04 03:46:05 --> Security Class Initialized
DEBUG - 2021-01-04 03:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 03:46:05 --> Input Class Initialized
INFO - 2021-01-04 03:46:06 --> Language Class Initialized
INFO - 2021-01-04 03:46:06 --> Language Class Initialized
INFO - 2021-01-04 03:46:06 --> Config Class Initialized
INFO - 2021-01-04 03:46:06 --> Loader Class Initialized
INFO - 2021-01-04 03:46:06 --> Helper loaded: url_helper
INFO - 2021-01-04 03:46:06 --> Helper loaded: file_helper
INFO - 2021-01-04 03:46:06 --> Helper loaded: form_helper
INFO - 2021-01-04 03:46:06 --> Helper loaded: my_helper
INFO - 2021-01-04 03:46:06 --> Database Driver Class Initialized
DEBUG - 2021-01-04 03:46:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 03:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 03:46:06 --> Controller Class Initialized
DEBUG - 2021-01-04 03:46:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 03:46:06 --> Final output sent to browser
DEBUG - 2021-01-04 03:46:06 --> Total execution time: 1.2637
INFO - 2021-01-04 03:48:25 --> Config Class Initialized
INFO - 2021-01-04 03:48:25 --> Hooks Class Initialized
DEBUG - 2021-01-04 03:48:25 --> UTF-8 Support Enabled
INFO - 2021-01-04 03:48:25 --> Utf8 Class Initialized
INFO - 2021-01-04 03:48:25 --> URI Class Initialized
INFO - 2021-01-04 03:48:25 --> Router Class Initialized
INFO - 2021-01-04 03:48:25 --> Output Class Initialized
INFO - 2021-01-04 03:48:25 --> Security Class Initialized
DEBUG - 2021-01-04 03:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 03:48:25 --> Input Class Initialized
INFO - 2021-01-04 03:48:25 --> Language Class Initialized
INFO - 2021-01-04 03:48:25 --> Language Class Initialized
INFO - 2021-01-04 03:48:25 --> Config Class Initialized
INFO - 2021-01-04 03:48:25 --> Loader Class Initialized
INFO - 2021-01-04 03:48:25 --> Helper loaded: url_helper
INFO - 2021-01-04 03:48:25 --> Helper loaded: file_helper
INFO - 2021-01-04 03:48:26 --> Helper loaded: form_helper
INFO - 2021-01-04 03:48:26 --> Helper loaded: my_helper
INFO - 2021-01-04 03:48:26 --> Database Driver Class Initialized
DEBUG - 2021-01-04 03:48:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 03:48:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 03:48:26 --> Controller Class Initialized
DEBUG - 2021-01-04 03:48:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 03:48:26 --> Final output sent to browser
DEBUG - 2021-01-04 03:48:26 --> Total execution time: 1.4611
INFO - 2021-01-04 03:57:17 --> Config Class Initialized
INFO - 2021-01-04 03:57:18 --> Hooks Class Initialized
DEBUG - 2021-01-04 03:57:18 --> UTF-8 Support Enabled
INFO - 2021-01-04 03:57:18 --> Utf8 Class Initialized
INFO - 2021-01-04 03:57:18 --> URI Class Initialized
INFO - 2021-01-04 03:57:18 --> Router Class Initialized
INFO - 2021-01-04 03:57:18 --> Output Class Initialized
INFO - 2021-01-04 03:57:18 --> Security Class Initialized
DEBUG - 2021-01-04 03:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 03:57:18 --> Input Class Initialized
INFO - 2021-01-04 03:57:18 --> Language Class Initialized
INFO - 2021-01-04 03:57:18 --> Language Class Initialized
INFO - 2021-01-04 03:57:18 --> Config Class Initialized
INFO - 2021-01-04 03:57:18 --> Loader Class Initialized
INFO - 2021-01-04 03:57:18 --> Helper loaded: url_helper
INFO - 2021-01-04 03:57:18 --> Helper loaded: file_helper
INFO - 2021-01-04 03:57:18 --> Helper loaded: form_helper
INFO - 2021-01-04 03:57:18 --> Helper loaded: my_helper
INFO - 2021-01-04 03:57:18 --> Database Driver Class Initialized
DEBUG - 2021-01-04 03:57:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 03:57:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 03:57:18 --> Controller Class Initialized
DEBUG - 2021-01-04 03:57:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 03:57:18 --> Final output sent to browser
DEBUG - 2021-01-04 03:57:18 --> Total execution time: 0.8398
INFO - 2021-01-04 03:57:31 --> Config Class Initialized
INFO - 2021-01-04 03:57:31 --> Hooks Class Initialized
DEBUG - 2021-01-04 03:57:31 --> UTF-8 Support Enabled
INFO - 2021-01-04 03:57:31 --> Utf8 Class Initialized
INFO - 2021-01-04 03:57:31 --> URI Class Initialized
INFO - 2021-01-04 03:57:31 --> Router Class Initialized
INFO - 2021-01-04 03:57:31 --> Output Class Initialized
INFO - 2021-01-04 03:57:31 --> Security Class Initialized
DEBUG - 2021-01-04 03:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 03:57:31 --> Input Class Initialized
INFO - 2021-01-04 03:57:31 --> Language Class Initialized
INFO - 2021-01-04 03:57:31 --> Language Class Initialized
INFO - 2021-01-04 03:57:31 --> Config Class Initialized
INFO - 2021-01-04 03:57:31 --> Loader Class Initialized
INFO - 2021-01-04 03:57:31 --> Helper loaded: url_helper
INFO - 2021-01-04 03:57:31 --> Helper loaded: file_helper
INFO - 2021-01-04 03:57:31 --> Helper loaded: form_helper
INFO - 2021-01-04 03:57:31 --> Helper loaded: my_helper
INFO - 2021-01-04 03:57:31 --> Database Driver Class Initialized
DEBUG - 2021-01-04 03:57:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 03:57:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 03:57:31 --> Controller Class Initialized
DEBUG - 2021-01-04 03:57:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 03:57:31 --> Final output sent to browser
DEBUG - 2021-01-04 03:57:31 --> Total execution time: 0.7639
INFO - 2021-01-04 03:57:46 --> Config Class Initialized
INFO - 2021-01-04 03:57:46 --> Hooks Class Initialized
DEBUG - 2021-01-04 03:57:46 --> UTF-8 Support Enabled
INFO - 2021-01-04 03:57:46 --> Utf8 Class Initialized
INFO - 2021-01-04 03:57:46 --> URI Class Initialized
INFO - 2021-01-04 03:57:46 --> Router Class Initialized
INFO - 2021-01-04 03:57:46 --> Output Class Initialized
INFO - 2021-01-04 03:57:46 --> Security Class Initialized
DEBUG - 2021-01-04 03:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 03:57:46 --> Input Class Initialized
INFO - 2021-01-04 03:57:46 --> Language Class Initialized
INFO - 2021-01-04 03:57:46 --> Language Class Initialized
INFO - 2021-01-04 03:57:46 --> Config Class Initialized
INFO - 2021-01-04 03:57:46 --> Loader Class Initialized
INFO - 2021-01-04 03:57:46 --> Helper loaded: url_helper
INFO - 2021-01-04 03:57:46 --> Helper loaded: file_helper
INFO - 2021-01-04 03:57:46 --> Helper loaded: form_helper
INFO - 2021-01-04 03:57:46 --> Helper loaded: my_helper
INFO - 2021-01-04 03:57:46 --> Database Driver Class Initialized
DEBUG - 2021-01-04 03:57:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 03:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 03:57:46 --> Controller Class Initialized
DEBUG - 2021-01-04 03:57:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 03:57:47 --> Final output sent to browser
DEBUG - 2021-01-04 03:57:47 --> Total execution time: 1.0637
INFO - 2021-01-04 03:58:15 --> Config Class Initialized
INFO - 2021-01-04 03:58:15 --> Hooks Class Initialized
DEBUG - 2021-01-04 03:58:15 --> UTF-8 Support Enabled
INFO - 2021-01-04 03:58:15 --> Utf8 Class Initialized
INFO - 2021-01-04 03:58:15 --> URI Class Initialized
INFO - 2021-01-04 03:58:15 --> Router Class Initialized
INFO - 2021-01-04 03:58:15 --> Output Class Initialized
INFO - 2021-01-04 03:58:16 --> Security Class Initialized
DEBUG - 2021-01-04 03:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 03:58:16 --> Input Class Initialized
INFO - 2021-01-04 03:58:16 --> Language Class Initialized
INFO - 2021-01-04 03:58:16 --> Language Class Initialized
INFO - 2021-01-04 03:58:16 --> Config Class Initialized
INFO - 2021-01-04 03:58:16 --> Loader Class Initialized
INFO - 2021-01-04 03:58:16 --> Helper loaded: url_helper
INFO - 2021-01-04 03:58:16 --> Helper loaded: file_helper
INFO - 2021-01-04 03:58:16 --> Helper loaded: form_helper
INFO - 2021-01-04 03:58:16 --> Helper loaded: my_helper
INFO - 2021-01-04 03:58:16 --> Database Driver Class Initialized
DEBUG - 2021-01-04 03:58:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 03:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 03:58:16 --> Controller Class Initialized
DEBUG - 2021-01-04 03:58:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 03:58:16 --> Final output sent to browser
DEBUG - 2021-01-04 03:58:16 --> Total execution time: 1.1014
INFO - 2021-01-04 03:59:56 --> Config Class Initialized
INFO - 2021-01-04 03:59:56 --> Hooks Class Initialized
DEBUG - 2021-01-04 03:59:56 --> UTF-8 Support Enabled
INFO - 2021-01-04 03:59:56 --> Utf8 Class Initialized
INFO - 2021-01-04 03:59:56 --> URI Class Initialized
INFO - 2021-01-04 03:59:56 --> Router Class Initialized
INFO - 2021-01-04 03:59:56 --> Output Class Initialized
INFO - 2021-01-04 03:59:56 --> Security Class Initialized
DEBUG - 2021-01-04 03:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 03:59:56 --> Input Class Initialized
INFO - 2021-01-04 03:59:56 --> Language Class Initialized
INFO - 2021-01-04 03:59:56 --> Language Class Initialized
INFO - 2021-01-04 03:59:56 --> Config Class Initialized
INFO - 2021-01-04 03:59:56 --> Loader Class Initialized
INFO - 2021-01-04 03:59:56 --> Helper loaded: url_helper
INFO - 2021-01-04 03:59:56 --> Helper loaded: file_helper
INFO - 2021-01-04 03:59:56 --> Helper loaded: form_helper
INFO - 2021-01-04 03:59:57 --> Helper loaded: my_helper
INFO - 2021-01-04 03:59:57 --> Database Driver Class Initialized
DEBUG - 2021-01-04 03:59:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 03:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 03:59:57 --> Controller Class Initialized
DEBUG - 2021-01-04 03:59:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 03:59:57 --> Final output sent to browser
DEBUG - 2021-01-04 03:59:57 --> Total execution time: 1.1835
INFO - 2021-01-04 04:00:51 --> Config Class Initialized
INFO - 2021-01-04 04:00:51 --> Hooks Class Initialized
DEBUG - 2021-01-04 04:00:51 --> UTF-8 Support Enabled
INFO - 2021-01-04 04:00:51 --> Utf8 Class Initialized
INFO - 2021-01-04 04:00:51 --> URI Class Initialized
INFO - 2021-01-04 04:00:51 --> Router Class Initialized
INFO - 2021-01-04 04:00:51 --> Output Class Initialized
INFO - 2021-01-04 04:00:51 --> Security Class Initialized
DEBUG - 2021-01-04 04:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 04:00:51 --> Input Class Initialized
INFO - 2021-01-04 04:00:51 --> Language Class Initialized
INFO - 2021-01-04 04:00:51 --> Language Class Initialized
INFO - 2021-01-04 04:00:51 --> Config Class Initialized
INFO - 2021-01-04 04:00:51 --> Loader Class Initialized
INFO - 2021-01-04 04:00:51 --> Helper loaded: url_helper
INFO - 2021-01-04 04:00:51 --> Helper loaded: file_helper
INFO - 2021-01-04 04:00:51 --> Helper loaded: form_helper
INFO - 2021-01-04 04:00:52 --> Helper loaded: my_helper
INFO - 2021-01-04 04:00:52 --> Database Driver Class Initialized
DEBUG - 2021-01-04 04:00:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 04:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 04:00:52 --> Controller Class Initialized
DEBUG - 2021-01-04 04:00:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 04:00:52 --> Final output sent to browser
DEBUG - 2021-01-04 04:00:52 --> Total execution time: 1.0334
INFO - 2021-01-04 04:02:20 --> Config Class Initialized
INFO - 2021-01-04 04:02:20 --> Hooks Class Initialized
DEBUG - 2021-01-04 04:02:20 --> UTF-8 Support Enabled
INFO - 2021-01-04 04:02:20 --> Utf8 Class Initialized
INFO - 2021-01-04 04:02:20 --> URI Class Initialized
INFO - 2021-01-04 04:02:20 --> Router Class Initialized
INFO - 2021-01-04 04:02:20 --> Output Class Initialized
INFO - 2021-01-04 04:02:21 --> Security Class Initialized
DEBUG - 2021-01-04 04:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 04:02:21 --> Input Class Initialized
INFO - 2021-01-04 04:02:21 --> Language Class Initialized
INFO - 2021-01-04 04:02:21 --> Language Class Initialized
INFO - 2021-01-04 04:02:21 --> Config Class Initialized
INFO - 2021-01-04 04:02:21 --> Loader Class Initialized
INFO - 2021-01-04 04:02:21 --> Helper loaded: url_helper
INFO - 2021-01-04 04:02:21 --> Helper loaded: file_helper
INFO - 2021-01-04 04:02:21 --> Helper loaded: form_helper
INFO - 2021-01-04 04:02:21 --> Helper loaded: my_helper
INFO - 2021-01-04 04:02:21 --> Database Driver Class Initialized
DEBUG - 2021-01-04 04:02:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 04:02:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 04:02:21 --> Controller Class Initialized
ERROR - 2021-01-04 04:02:21 --> Severity: Notice --> Undefined variable: no C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_rapot.php 74
DEBUG - 2021-01-04 04:02:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 04:02:21 --> Final output sent to browser
DEBUG - 2021-01-04 04:02:21 --> Total execution time: 0.7022
INFO - 2021-01-04 04:03:24 --> Config Class Initialized
INFO - 2021-01-04 04:03:24 --> Hooks Class Initialized
DEBUG - 2021-01-04 04:03:24 --> UTF-8 Support Enabled
INFO - 2021-01-04 04:03:24 --> Utf8 Class Initialized
INFO - 2021-01-04 04:03:24 --> URI Class Initialized
INFO - 2021-01-04 04:03:24 --> Router Class Initialized
INFO - 2021-01-04 04:03:24 --> Output Class Initialized
INFO - 2021-01-04 04:03:24 --> Security Class Initialized
DEBUG - 2021-01-04 04:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 04:03:25 --> Input Class Initialized
INFO - 2021-01-04 04:03:25 --> Language Class Initialized
INFO - 2021-01-04 04:03:25 --> Language Class Initialized
INFO - 2021-01-04 04:03:25 --> Config Class Initialized
INFO - 2021-01-04 04:03:25 --> Loader Class Initialized
INFO - 2021-01-04 04:03:25 --> Helper loaded: url_helper
INFO - 2021-01-04 04:03:25 --> Helper loaded: file_helper
INFO - 2021-01-04 04:03:25 --> Helper loaded: form_helper
INFO - 2021-01-04 04:03:25 --> Helper loaded: my_helper
INFO - 2021-01-04 04:03:25 --> Database Driver Class Initialized
DEBUG - 2021-01-04 04:03:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 04:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 04:03:25 --> Controller Class Initialized
DEBUG - 2021-01-04 04:03:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 04:03:25 --> Final output sent to browser
DEBUG - 2021-01-04 04:03:25 --> Total execution time: 1.3347
INFO - 2021-01-04 04:03:41 --> Config Class Initialized
INFO - 2021-01-04 04:03:41 --> Hooks Class Initialized
DEBUG - 2021-01-04 04:03:41 --> UTF-8 Support Enabled
INFO - 2021-01-04 04:03:41 --> Utf8 Class Initialized
INFO - 2021-01-04 04:03:41 --> URI Class Initialized
INFO - 2021-01-04 04:03:41 --> Router Class Initialized
INFO - 2021-01-04 04:03:41 --> Output Class Initialized
INFO - 2021-01-04 04:03:41 --> Security Class Initialized
DEBUG - 2021-01-04 04:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 04:03:41 --> Input Class Initialized
INFO - 2021-01-04 04:03:41 --> Language Class Initialized
INFO - 2021-01-04 04:03:41 --> Language Class Initialized
INFO - 2021-01-04 04:03:41 --> Config Class Initialized
INFO - 2021-01-04 04:03:41 --> Loader Class Initialized
INFO - 2021-01-04 04:03:41 --> Helper loaded: url_helper
INFO - 2021-01-04 04:03:42 --> Helper loaded: file_helper
INFO - 2021-01-04 04:03:42 --> Helper loaded: form_helper
INFO - 2021-01-04 04:03:42 --> Helper loaded: my_helper
INFO - 2021-01-04 04:03:42 --> Database Driver Class Initialized
DEBUG - 2021-01-04 04:03:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 04:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 04:03:42 --> Controller Class Initialized
DEBUG - 2021-01-04 04:03:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 04:03:42 --> Final output sent to browser
DEBUG - 2021-01-04 04:03:42 --> Total execution time: 1.0272
INFO - 2021-01-04 04:07:18 --> Config Class Initialized
INFO - 2021-01-04 04:07:19 --> Hooks Class Initialized
DEBUG - 2021-01-04 04:07:19 --> UTF-8 Support Enabled
INFO - 2021-01-04 04:07:19 --> Utf8 Class Initialized
INFO - 2021-01-04 04:07:19 --> URI Class Initialized
INFO - 2021-01-04 04:07:19 --> Router Class Initialized
INFO - 2021-01-04 04:07:19 --> Output Class Initialized
INFO - 2021-01-04 04:07:19 --> Security Class Initialized
DEBUG - 2021-01-04 04:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 04:07:19 --> Input Class Initialized
INFO - 2021-01-04 04:07:19 --> Language Class Initialized
INFO - 2021-01-04 04:07:19 --> Language Class Initialized
INFO - 2021-01-04 04:07:19 --> Config Class Initialized
INFO - 2021-01-04 04:07:19 --> Loader Class Initialized
INFO - 2021-01-04 04:07:19 --> Helper loaded: url_helper
INFO - 2021-01-04 04:07:19 --> Helper loaded: file_helper
INFO - 2021-01-04 04:07:19 --> Helper loaded: form_helper
INFO - 2021-01-04 04:07:19 --> Helper loaded: my_helper
INFO - 2021-01-04 04:07:19 --> Database Driver Class Initialized
DEBUG - 2021-01-04 04:07:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 04:07:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 04:07:19 --> Controller Class Initialized
DEBUG - 2021-01-04 04:07:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 04:07:20 --> Final output sent to browser
DEBUG - 2021-01-04 04:07:20 --> Total execution time: 1.2558
INFO - 2021-01-04 04:08:11 --> Config Class Initialized
INFO - 2021-01-04 04:08:11 --> Hooks Class Initialized
DEBUG - 2021-01-04 04:08:11 --> UTF-8 Support Enabled
INFO - 2021-01-04 04:08:11 --> Utf8 Class Initialized
INFO - 2021-01-04 04:08:11 --> URI Class Initialized
INFO - 2021-01-04 04:08:11 --> Router Class Initialized
INFO - 2021-01-04 04:08:11 --> Output Class Initialized
INFO - 2021-01-04 04:08:11 --> Security Class Initialized
DEBUG - 2021-01-04 04:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 04:08:11 --> Input Class Initialized
INFO - 2021-01-04 04:08:11 --> Language Class Initialized
INFO - 2021-01-04 04:08:11 --> Language Class Initialized
INFO - 2021-01-04 04:08:11 --> Config Class Initialized
INFO - 2021-01-04 04:08:11 --> Loader Class Initialized
INFO - 2021-01-04 04:08:11 --> Helper loaded: url_helper
INFO - 2021-01-04 04:08:11 --> Helper loaded: file_helper
INFO - 2021-01-04 04:08:12 --> Helper loaded: form_helper
INFO - 2021-01-04 04:08:12 --> Helper loaded: my_helper
INFO - 2021-01-04 04:08:12 --> Database Driver Class Initialized
DEBUG - 2021-01-04 04:08:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 04:08:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 04:08:12 --> Controller Class Initialized
DEBUG - 2021-01-04 04:08:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 04:08:12 --> Final output sent to browser
DEBUG - 2021-01-04 04:08:12 --> Total execution time: 1.4200
INFO - 2021-01-04 04:08:32 --> Config Class Initialized
INFO - 2021-01-04 04:08:32 --> Hooks Class Initialized
DEBUG - 2021-01-04 04:08:32 --> UTF-8 Support Enabled
INFO - 2021-01-04 04:08:32 --> Utf8 Class Initialized
INFO - 2021-01-04 04:08:32 --> URI Class Initialized
INFO - 2021-01-04 04:08:32 --> Router Class Initialized
INFO - 2021-01-04 04:08:32 --> Output Class Initialized
INFO - 2021-01-04 04:08:32 --> Security Class Initialized
DEBUG - 2021-01-04 04:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 04:08:32 --> Input Class Initialized
INFO - 2021-01-04 04:08:32 --> Language Class Initialized
INFO - 2021-01-04 04:08:32 --> Language Class Initialized
INFO - 2021-01-04 04:08:32 --> Config Class Initialized
INFO - 2021-01-04 04:08:32 --> Loader Class Initialized
INFO - 2021-01-04 04:08:32 --> Helper loaded: url_helper
INFO - 2021-01-04 04:08:32 --> Helper loaded: file_helper
INFO - 2021-01-04 04:08:33 --> Helper loaded: form_helper
INFO - 2021-01-04 04:08:33 --> Helper loaded: my_helper
INFO - 2021-01-04 04:08:33 --> Database Driver Class Initialized
DEBUG - 2021-01-04 04:08:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 04:08:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 04:08:33 --> Controller Class Initialized
DEBUG - 2021-01-04 04:08:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 04:08:33 --> Final output sent to browser
DEBUG - 2021-01-04 04:08:33 --> Total execution time: 1.5905
INFO - 2021-01-04 04:09:12 --> Config Class Initialized
INFO - 2021-01-04 04:09:12 --> Hooks Class Initialized
DEBUG - 2021-01-04 04:09:12 --> UTF-8 Support Enabled
INFO - 2021-01-04 04:09:12 --> Utf8 Class Initialized
INFO - 2021-01-04 04:09:12 --> URI Class Initialized
INFO - 2021-01-04 04:09:12 --> Router Class Initialized
INFO - 2021-01-04 04:09:13 --> Output Class Initialized
INFO - 2021-01-04 04:09:13 --> Security Class Initialized
DEBUG - 2021-01-04 04:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 04:09:13 --> Input Class Initialized
INFO - 2021-01-04 04:09:13 --> Language Class Initialized
INFO - 2021-01-04 04:09:13 --> Language Class Initialized
INFO - 2021-01-04 04:09:13 --> Config Class Initialized
INFO - 2021-01-04 04:09:13 --> Loader Class Initialized
INFO - 2021-01-04 04:09:13 --> Helper loaded: url_helper
INFO - 2021-01-04 04:09:13 --> Helper loaded: file_helper
INFO - 2021-01-04 04:09:13 --> Helper loaded: form_helper
INFO - 2021-01-04 04:09:13 --> Helper loaded: my_helper
INFO - 2021-01-04 04:09:13 --> Database Driver Class Initialized
DEBUG - 2021-01-04 04:09:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 04:09:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 04:09:13 --> Controller Class Initialized
DEBUG - 2021-01-04 04:09:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 04:09:14 --> Final output sent to browser
DEBUG - 2021-01-04 04:09:14 --> Total execution time: 1.4316
INFO - 2021-01-04 04:10:19 --> Config Class Initialized
INFO - 2021-01-04 04:10:19 --> Hooks Class Initialized
DEBUG - 2021-01-04 04:10:19 --> UTF-8 Support Enabled
INFO - 2021-01-04 04:10:19 --> Utf8 Class Initialized
INFO - 2021-01-04 04:10:19 --> URI Class Initialized
INFO - 2021-01-04 04:10:19 --> Router Class Initialized
INFO - 2021-01-04 04:10:19 --> Output Class Initialized
INFO - 2021-01-04 04:10:19 --> Security Class Initialized
DEBUG - 2021-01-04 04:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 04:10:19 --> Input Class Initialized
INFO - 2021-01-04 04:10:19 --> Language Class Initialized
INFO - 2021-01-04 04:10:19 --> Language Class Initialized
INFO - 2021-01-04 04:10:19 --> Config Class Initialized
INFO - 2021-01-04 04:10:19 --> Loader Class Initialized
INFO - 2021-01-04 04:10:19 --> Helper loaded: url_helper
INFO - 2021-01-04 04:10:19 --> Helper loaded: file_helper
INFO - 2021-01-04 04:10:19 --> Helper loaded: form_helper
INFO - 2021-01-04 04:10:19 --> Helper loaded: my_helper
INFO - 2021-01-04 04:10:19 --> Database Driver Class Initialized
DEBUG - 2021-01-04 04:10:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 04:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 04:10:20 --> Controller Class Initialized
DEBUG - 2021-01-04 04:10:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 04:10:20 --> Final output sent to browser
DEBUG - 2021-01-04 04:10:20 --> Total execution time: 1.3405
INFO - 2021-01-04 04:10:54 --> Config Class Initialized
INFO - 2021-01-04 04:10:54 --> Hooks Class Initialized
DEBUG - 2021-01-04 04:10:54 --> UTF-8 Support Enabled
INFO - 2021-01-04 04:10:54 --> Utf8 Class Initialized
INFO - 2021-01-04 04:10:54 --> URI Class Initialized
INFO - 2021-01-04 04:10:54 --> Router Class Initialized
INFO - 2021-01-04 04:10:54 --> Output Class Initialized
INFO - 2021-01-04 04:10:54 --> Security Class Initialized
DEBUG - 2021-01-04 04:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 04:10:54 --> Input Class Initialized
INFO - 2021-01-04 04:10:54 --> Language Class Initialized
INFO - 2021-01-04 04:10:55 --> Language Class Initialized
INFO - 2021-01-04 04:10:55 --> Config Class Initialized
INFO - 2021-01-04 04:10:55 --> Loader Class Initialized
INFO - 2021-01-04 04:10:55 --> Helper loaded: url_helper
INFO - 2021-01-04 04:10:55 --> Helper loaded: file_helper
INFO - 2021-01-04 04:10:55 --> Helper loaded: form_helper
INFO - 2021-01-04 04:10:55 --> Helper loaded: my_helper
INFO - 2021-01-04 04:10:55 --> Database Driver Class Initialized
DEBUG - 2021-01-04 04:10:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 04:10:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 04:10:55 --> Controller Class Initialized
DEBUG - 2021-01-04 04:10:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 04:10:55 --> Final output sent to browser
DEBUG - 2021-01-04 04:10:55 --> Total execution time: 1.3872
INFO - 2021-01-04 04:11:54 --> Config Class Initialized
INFO - 2021-01-04 04:11:54 --> Hooks Class Initialized
DEBUG - 2021-01-04 04:11:54 --> UTF-8 Support Enabled
INFO - 2021-01-04 04:11:54 --> Utf8 Class Initialized
INFO - 2021-01-04 04:11:54 --> URI Class Initialized
INFO - 2021-01-04 04:11:55 --> Router Class Initialized
INFO - 2021-01-04 04:11:55 --> Output Class Initialized
INFO - 2021-01-04 04:11:55 --> Security Class Initialized
DEBUG - 2021-01-04 04:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 04:11:55 --> Input Class Initialized
INFO - 2021-01-04 04:11:55 --> Language Class Initialized
INFO - 2021-01-04 04:11:55 --> Language Class Initialized
INFO - 2021-01-04 04:11:55 --> Config Class Initialized
INFO - 2021-01-04 04:11:55 --> Loader Class Initialized
INFO - 2021-01-04 04:11:55 --> Helper loaded: url_helper
INFO - 2021-01-04 04:11:55 --> Helper loaded: file_helper
INFO - 2021-01-04 04:11:55 --> Helper loaded: form_helper
INFO - 2021-01-04 04:11:55 --> Helper loaded: my_helper
INFO - 2021-01-04 04:11:55 --> Database Driver Class Initialized
DEBUG - 2021-01-04 04:11:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 04:11:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 04:11:55 --> Controller Class Initialized
DEBUG - 2021-01-04 04:11:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 04:11:56 --> Final output sent to browser
DEBUG - 2021-01-04 04:11:56 --> Total execution time: 1.4197
INFO - 2021-01-04 04:12:39 --> Config Class Initialized
INFO - 2021-01-04 04:12:39 --> Hooks Class Initialized
DEBUG - 2021-01-04 04:12:39 --> UTF-8 Support Enabled
INFO - 2021-01-04 04:12:40 --> Utf8 Class Initialized
INFO - 2021-01-04 04:12:40 --> URI Class Initialized
INFO - 2021-01-04 04:12:40 --> Router Class Initialized
INFO - 2021-01-04 04:12:40 --> Output Class Initialized
INFO - 2021-01-04 04:12:40 --> Security Class Initialized
DEBUG - 2021-01-04 04:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 04:12:40 --> Input Class Initialized
INFO - 2021-01-04 04:12:40 --> Language Class Initialized
INFO - 2021-01-04 04:12:40 --> Language Class Initialized
INFO - 2021-01-04 04:12:40 --> Config Class Initialized
INFO - 2021-01-04 04:12:40 --> Loader Class Initialized
INFO - 2021-01-04 04:12:40 --> Helper loaded: url_helper
INFO - 2021-01-04 04:12:40 --> Helper loaded: file_helper
INFO - 2021-01-04 04:12:40 --> Helper loaded: form_helper
INFO - 2021-01-04 04:12:40 --> Helper loaded: my_helper
INFO - 2021-01-04 04:12:40 --> Database Driver Class Initialized
DEBUG - 2021-01-04 04:12:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 04:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 04:12:40 --> Controller Class Initialized
DEBUG - 2021-01-04 04:12:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 04:12:41 --> Final output sent to browser
DEBUG - 2021-01-04 04:12:41 --> Total execution time: 1.2797
INFO - 2021-01-04 04:12:59 --> Config Class Initialized
INFO - 2021-01-04 04:12:59 --> Hooks Class Initialized
DEBUG - 2021-01-04 04:12:59 --> UTF-8 Support Enabled
INFO - 2021-01-04 04:12:59 --> Utf8 Class Initialized
INFO - 2021-01-04 04:12:59 --> URI Class Initialized
INFO - 2021-01-04 04:12:59 --> Router Class Initialized
INFO - 2021-01-04 04:12:59 --> Output Class Initialized
INFO - 2021-01-04 04:12:59 --> Security Class Initialized
DEBUG - 2021-01-04 04:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 04:12:59 --> Input Class Initialized
INFO - 2021-01-04 04:12:59 --> Language Class Initialized
INFO - 2021-01-04 04:12:59 --> Language Class Initialized
INFO - 2021-01-04 04:12:59 --> Config Class Initialized
INFO - 2021-01-04 04:12:59 --> Loader Class Initialized
INFO - 2021-01-04 04:12:59 --> Helper loaded: url_helper
INFO - 2021-01-04 04:12:59 --> Helper loaded: file_helper
INFO - 2021-01-04 04:12:59 --> Helper loaded: form_helper
INFO - 2021-01-04 04:12:59 --> Helper loaded: my_helper
INFO - 2021-01-04 04:12:59 --> Database Driver Class Initialized
DEBUG - 2021-01-04 04:12:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 04:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 04:13:00 --> Controller Class Initialized
DEBUG - 2021-01-04 04:13:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 04:13:00 --> Final output sent to browser
DEBUG - 2021-01-04 04:13:00 --> Total execution time: 1.3366
INFO - 2021-01-04 04:14:07 --> Config Class Initialized
INFO - 2021-01-04 04:14:07 --> Hooks Class Initialized
DEBUG - 2021-01-04 04:14:07 --> UTF-8 Support Enabled
INFO - 2021-01-04 04:14:07 --> Utf8 Class Initialized
INFO - 2021-01-04 04:14:07 --> URI Class Initialized
INFO - 2021-01-04 04:14:07 --> Router Class Initialized
INFO - 2021-01-04 04:14:07 --> Output Class Initialized
INFO - 2021-01-04 04:14:07 --> Security Class Initialized
DEBUG - 2021-01-04 04:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 04:14:08 --> Input Class Initialized
INFO - 2021-01-04 04:14:08 --> Language Class Initialized
INFO - 2021-01-04 04:14:08 --> Language Class Initialized
INFO - 2021-01-04 04:14:08 --> Config Class Initialized
INFO - 2021-01-04 04:14:08 --> Loader Class Initialized
INFO - 2021-01-04 04:14:08 --> Helper loaded: url_helper
INFO - 2021-01-04 04:14:08 --> Helper loaded: file_helper
INFO - 2021-01-04 04:14:08 --> Helper loaded: form_helper
INFO - 2021-01-04 04:14:08 --> Helper loaded: my_helper
INFO - 2021-01-04 04:14:08 --> Database Driver Class Initialized
DEBUG - 2021-01-04 04:14:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 04:14:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 04:14:08 --> Controller Class Initialized
DEBUG - 2021-01-04 04:14:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 04:14:08 --> Final output sent to browser
DEBUG - 2021-01-04 04:14:08 --> Total execution time: 0.9857
INFO - 2021-01-04 04:15:57 --> Config Class Initialized
INFO - 2021-01-04 04:15:57 --> Hooks Class Initialized
DEBUG - 2021-01-04 04:15:57 --> UTF-8 Support Enabled
INFO - 2021-01-04 04:15:58 --> Utf8 Class Initialized
INFO - 2021-01-04 04:15:58 --> URI Class Initialized
INFO - 2021-01-04 04:15:58 --> Router Class Initialized
INFO - 2021-01-04 04:15:58 --> Output Class Initialized
INFO - 2021-01-04 04:15:58 --> Security Class Initialized
DEBUG - 2021-01-04 04:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 04:15:58 --> Input Class Initialized
INFO - 2021-01-04 04:15:58 --> Language Class Initialized
INFO - 2021-01-04 04:15:58 --> Language Class Initialized
INFO - 2021-01-04 04:15:58 --> Config Class Initialized
INFO - 2021-01-04 04:15:58 --> Loader Class Initialized
INFO - 2021-01-04 04:15:58 --> Helper loaded: url_helper
INFO - 2021-01-04 04:15:58 --> Helper loaded: file_helper
INFO - 2021-01-04 04:15:58 --> Helper loaded: form_helper
INFO - 2021-01-04 04:15:58 --> Helper loaded: my_helper
INFO - 2021-01-04 04:15:58 --> Database Driver Class Initialized
DEBUG - 2021-01-04 04:15:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 04:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 04:15:58 --> Controller Class Initialized
DEBUG - 2021-01-04 04:15:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 04:15:59 --> Final output sent to browser
DEBUG - 2021-01-04 04:15:59 --> Total execution time: 1.2670
INFO - 2021-01-04 04:16:13 --> Config Class Initialized
INFO - 2021-01-04 04:16:13 --> Hooks Class Initialized
DEBUG - 2021-01-04 04:16:13 --> UTF-8 Support Enabled
INFO - 2021-01-04 04:16:13 --> Utf8 Class Initialized
INFO - 2021-01-04 04:16:13 --> URI Class Initialized
INFO - 2021-01-04 04:16:13 --> Router Class Initialized
INFO - 2021-01-04 04:16:13 --> Output Class Initialized
INFO - 2021-01-04 04:16:13 --> Security Class Initialized
DEBUG - 2021-01-04 04:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 04:16:13 --> Input Class Initialized
INFO - 2021-01-04 04:16:13 --> Language Class Initialized
INFO - 2021-01-04 04:16:13 --> Language Class Initialized
INFO - 2021-01-04 04:16:13 --> Config Class Initialized
INFO - 2021-01-04 04:16:13 --> Loader Class Initialized
INFO - 2021-01-04 04:16:13 --> Helper loaded: url_helper
INFO - 2021-01-04 04:16:13 --> Helper loaded: file_helper
INFO - 2021-01-04 04:16:13 --> Helper loaded: form_helper
INFO - 2021-01-04 04:16:13 --> Helper loaded: my_helper
INFO - 2021-01-04 04:16:13 --> Database Driver Class Initialized
DEBUG - 2021-01-04 04:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 04:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 04:16:14 --> Controller Class Initialized
DEBUG - 2021-01-04 04:16:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 04:16:14 --> Final output sent to browser
DEBUG - 2021-01-04 04:16:14 --> Total execution time: 1.3864
INFO - 2021-01-04 04:17:08 --> Config Class Initialized
INFO - 2021-01-04 04:17:08 --> Hooks Class Initialized
DEBUG - 2021-01-04 04:17:08 --> UTF-8 Support Enabled
INFO - 2021-01-04 04:17:09 --> Utf8 Class Initialized
INFO - 2021-01-04 04:17:09 --> URI Class Initialized
INFO - 2021-01-04 04:17:09 --> Router Class Initialized
INFO - 2021-01-04 04:17:09 --> Output Class Initialized
INFO - 2021-01-04 04:17:09 --> Security Class Initialized
DEBUG - 2021-01-04 04:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 04:17:09 --> Input Class Initialized
INFO - 2021-01-04 04:17:09 --> Language Class Initialized
INFO - 2021-01-04 04:17:09 --> Language Class Initialized
INFO - 2021-01-04 04:17:09 --> Config Class Initialized
INFO - 2021-01-04 04:17:09 --> Loader Class Initialized
INFO - 2021-01-04 04:17:09 --> Helper loaded: url_helper
INFO - 2021-01-04 04:17:09 --> Helper loaded: file_helper
INFO - 2021-01-04 04:17:09 --> Helper loaded: form_helper
INFO - 2021-01-04 04:17:09 --> Helper loaded: my_helper
INFO - 2021-01-04 04:17:09 --> Database Driver Class Initialized
DEBUG - 2021-01-04 04:17:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 04:17:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 04:17:09 --> Controller Class Initialized
DEBUG - 2021-01-04 04:17:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 04:17:10 --> Final output sent to browser
DEBUG - 2021-01-04 04:17:10 --> Total execution time: 1.3173
INFO - 2021-01-04 04:17:17 --> Config Class Initialized
INFO - 2021-01-04 04:17:18 --> Hooks Class Initialized
DEBUG - 2021-01-04 04:17:18 --> UTF-8 Support Enabled
INFO - 2021-01-04 04:17:18 --> Utf8 Class Initialized
INFO - 2021-01-04 04:17:18 --> URI Class Initialized
INFO - 2021-01-04 04:17:18 --> Router Class Initialized
INFO - 2021-01-04 04:17:18 --> Output Class Initialized
INFO - 2021-01-04 04:17:18 --> Security Class Initialized
DEBUG - 2021-01-04 04:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 04:17:18 --> Input Class Initialized
INFO - 2021-01-04 04:17:18 --> Language Class Initialized
INFO - 2021-01-04 04:17:18 --> Language Class Initialized
INFO - 2021-01-04 04:17:18 --> Config Class Initialized
INFO - 2021-01-04 04:17:18 --> Loader Class Initialized
INFO - 2021-01-04 04:17:18 --> Helper loaded: url_helper
INFO - 2021-01-04 04:17:18 --> Helper loaded: file_helper
INFO - 2021-01-04 04:17:18 --> Helper loaded: form_helper
INFO - 2021-01-04 04:17:18 --> Helper loaded: my_helper
INFO - 2021-01-04 04:17:18 --> Database Driver Class Initialized
DEBUG - 2021-01-04 04:17:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 04:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 04:17:18 --> Controller Class Initialized
DEBUG - 2021-01-04 04:17:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 04:17:19 --> Final output sent to browser
DEBUG - 2021-01-04 04:17:19 --> Total execution time: 1.2188
INFO - 2021-01-04 04:17:28 --> Config Class Initialized
INFO - 2021-01-04 04:17:28 --> Hooks Class Initialized
DEBUG - 2021-01-04 04:17:28 --> UTF-8 Support Enabled
INFO - 2021-01-04 04:17:28 --> Utf8 Class Initialized
INFO - 2021-01-04 04:17:28 --> URI Class Initialized
INFO - 2021-01-04 04:17:28 --> Router Class Initialized
INFO - 2021-01-04 04:17:28 --> Output Class Initialized
INFO - 2021-01-04 04:17:28 --> Security Class Initialized
DEBUG - 2021-01-04 04:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 04:17:29 --> Input Class Initialized
INFO - 2021-01-04 04:17:29 --> Language Class Initialized
INFO - 2021-01-04 04:17:29 --> Language Class Initialized
INFO - 2021-01-04 04:17:29 --> Config Class Initialized
INFO - 2021-01-04 04:17:29 --> Loader Class Initialized
INFO - 2021-01-04 04:17:29 --> Helper loaded: url_helper
INFO - 2021-01-04 04:17:29 --> Helper loaded: file_helper
INFO - 2021-01-04 04:17:29 --> Helper loaded: form_helper
INFO - 2021-01-04 04:17:29 --> Helper loaded: my_helper
INFO - 2021-01-04 04:17:29 --> Database Driver Class Initialized
DEBUG - 2021-01-04 04:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 04:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 04:17:29 --> Controller Class Initialized
DEBUG - 2021-01-04 04:17:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 04:17:29 --> Final output sent to browser
DEBUG - 2021-01-04 04:17:30 --> Total execution time: 1.2967
INFO - 2021-01-04 04:20:17 --> Config Class Initialized
INFO - 2021-01-04 04:20:17 --> Hooks Class Initialized
DEBUG - 2021-01-04 04:20:17 --> UTF-8 Support Enabled
INFO - 2021-01-04 04:20:17 --> Utf8 Class Initialized
INFO - 2021-01-04 04:20:17 --> URI Class Initialized
INFO - 2021-01-04 04:20:17 --> Router Class Initialized
INFO - 2021-01-04 04:20:18 --> Output Class Initialized
INFO - 2021-01-04 04:20:18 --> Security Class Initialized
DEBUG - 2021-01-04 04:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 04:20:18 --> Input Class Initialized
INFO - 2021-01-04 04:20:18 --> Language Class Initialized
INFO - 2021-01-04 04:20:18 --> Language Class Initialized
INFO - 2021-01-04 04:20:18 --> Config Class Initialized
INFO - 2021-01-04 04:20:18 --> Loader Class Initialized
INFO - 2021-01-04 04:20:18 --> Helper loaded: url_helper
INFO - 2021-01-04 04:20:18 --> Helper loaded: file_helper
INFO - 2021-01-04 04:20:18 --> Helper loaded: form_helper
INFO - 2021-01-04 04:20:18 --> Helper loaded: my_helper
INFO - 2021-01-04 04:20:18 --> Database Driver Class Initialized
DEBUG - 2021-01-04 04:20:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 04:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 04:20:18 --> Controller Class Initialized
DEBUG - 2021-01-04 04:20:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 04:20:19 --> Final output sent to browser
DEBUG - 2021-01-04 04:20:19 --> Total execution time: 1.3087
INFO - 2021-01-04 04:22:08 --> Config Class Initialized
INFO - 2021-01-04 04:22:08 --> Hooks Class Initialized
DEBUG - 2021-01-04 04:22:08 --> UTF-8 Support Enabled
INFO - 2021-01-04 04:22:08 --> Utf8 Class Initialized
INFO - 2021-01-04 04:22:08 --> URI Class Initialized
INFO - 2021-01-04 04:22:08 --> Router Class Initialized
INFO - 2021-01-04 04:22:09 --> Output Class Initialized
INFO - 2021-01-04 04:22:09 --> Security Class Initialized
DEBUG - 2021-01-04 04:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 04:22:09 --> Input Class Initialized
INFO - 2021-01-04 04:22:09 --> Language Class Initialized
INFO - 2021-01-04 04:22:09 --> Language Class Initialized
INFO - 2021-01-04 04:22:09 --> Config Class Initialized
INFO - 2021-01-04 04:22:09 --> Loader Class Initialized
INFO - 2021-01-04 04:22:09 --> Helper loaded: url_helper
INFO - 2021-01-04 04:22:09 --> Helper loaded: file_helper
INFO - 2021-01-04 04:22:09 --> Helper loaded: form_helper
INFO - 2021-01-04 04:22:09 --> Helper loaded: my_helper
INFO - 2021-01-04 04:22:09 --> Database Driver Class Initialized
DEBUG - 2021-01-04 04:22:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 04:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 04:22:09 --> Controller Class Initialized
DEBUG - 2021-01-04 04:22:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 04:22:10 --> Final output sent to browser
DEBUG - 2021-01-04 04:22:10 --> Total execution time: 1.4343
INFO - 2021-01-04 04:25:46 --> Config Class Initialized
INFO - 2021-01-04 04:25:46 --> Hooks Class Initialized
DEBUG - 2021-01-04 04:25:46 --> UTF-8 Support Enabled
INFO - 2021-01-04 04:25:46 --> Utf8 Class Initialized
INFO - 2021-01-04 04:25:46 --> URI Class Initialized
INFO - 2021-01-04 04:25:46 --> Router Class Initialized
INFO - 2021-01-04 04:25:46 --> Output Class Initialized
INFO - 2021-01-04 04:25:46 --> Security Class Initialized
DEBUG - 2021-01-04 04:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 04:25:46 --> Input Class Initialized
INFO - 2021-01-04 04:25:46 --> Language Class Initialized
INFO - 2021-01-04 04:25:46 --> Language Class Initialized
INFO - 2021-01-04 04:25:46 --> Config Class Initialized
INFO - 2021-01-04 04:25:46 --> Loader Class Initialized
INFO - 2021-01-04 04:25:46 --> Helper loaded: url_helper
INFO - 2021-01-04 04:25:47 --> Helper loaded: file_helper
INFO - 2021-01-04 04:25:47 --> Helper loaded: form_helper
INFO - 2021-01-04 04:25:47 --> Helper loaded: my_helper
INFO - 2021-01-04 04:25:47 --> Database Driver Class Initialized
DEBUG - 2021-01-04 04:25:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 04:25:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 04:25:47 --> Controller Class Initialized
DEBUG - 2021-01-04 04:25:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 04:25:47 --> Final output sent to browser
DEBUG - 2021-01-04 04:25:47 --> Total execution time: 1.2470
INFO - 2021-01-04 04:26:27 --> Config Class Initialized
INFO - 2021-01-04 04:26:27 --> Hooks Class Initialized
DEBUG - 2021-01-04 04:26:27 --> UTF-8 Support Enabled
INFO - 2021-01-04 04:26:28 --> Utf8 Class Initialized
INFO - 2021-01-04 04:26:28 --> URI Class Initialized
INFO - 2021-01-04 04:26:28 --> Router Class Initialized
INFO - 2021-01-04 04:26:28 --> Output Class Initialized
INFO - 2021-01-04 04:26:28 --> Security Class Initialized
DEBUG - 2021-01-04 04:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 04:26:28 --> Input Class Initialized
INFO - 2021-01-04 04:26:28 --> Language Class Initialized
INFO - 2021-01-04 04:26:28 --> Language Class Initialized
INFO - 2021-01-04 04:26:28 --> Config Class Initialized
INFO - 2021-01-04 04:26:28 --> Loader Class Initialized
INFO - 2021-01-04 04:26:28 --> Helper loaded: url_helper
INFO - 2021-01-04 04:26:28 --> Helper loaded: file_helper
INFO - 2021-01-04 04:26:28 --> Helper loaded: form_helper
INFO - 2021-01-04 04:26:28 --> Helper loaded: my_helper
INFO - 2021-01-04 04:26:28 --> Database Driver Class Initialized
DEBUG - 2021-01-04 04:26:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 04:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 04:26:29 --> Controller Class Initialized
DEBUG - 2021-01-04 04:26:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 04:26:29 --> Final output sent to browser
DEBUG - 2021-01-04 04:26:29 --> Total execution time: 1.2774
INFO - 2021-01-04 04:29:46 --> Config Class Initialized
INFO - 2021-01-04 04:29:46 --> Hooks Class Initialized
DEBUG - 2021-01-04 04:29:46 --> UTF-8 Support Enabled
INFO - 2021-01-04 04:29:46 --> Utf8 Class Initialized
INFO - 2021-01-04 04:29:46 --> URI Class Initialized
INFO - 2021-01-04 04:29:46 --> Router Class Initialized
INFO - 2021-01-04 04:29:46 --> Output Class Initialized
INFO - 2021-01-04 04:29:46 --> Security Class Initialized
DEBUG - 2021-01-04 04:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 04:29:46 --> Input Class Initialized
INFO - 2021-01-04 04:29:46 --> Language Class Initialized
INFO - 2021-01-04 04:29:46 --> Language Class Initialized
INFO - 2021-01-04 04:29:46 --> Config Class Initialized
INFO - 2021-01-04 04:29:46 --> Loader Class Initialized
INFO - 2021-01-04 04:29:46 --> Helper loaded: url_helper
INFO - 2021-01-04 04:29:46 --> Helper loaded: file_helper
INFO - 2021-01-04 04:29:46 --> Helper loaded: form_helper
INFO - 2021-01-04 04:29:46 --> Helper loaded: my_helper
INFO - 2021-01-04 04:29:46 --> Database Driver Class Initialized
DEBUG - 2021-01-04 04:29:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 04:29:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 04:29:46 --> Controller Class Initialized
DEBUG - 2021-01-04 04:29:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 04:29:46 --> Final output sent to browser
DEBUG - 2021-01-04 04:29:47 --> Total execution time: 0.9357
INFO - 2021-01-04 04:30:09 --> Config Class Initialized
INFO - 2021-01-04 04:30:09 --> Hooks Class Initialized
DEBUG - 2021-01-04 04:30:09 --> UTF-8 Support Enabled
INFO - 2021-01-04 04:30:09 --> Utf8 Class Initialized
INFO - 2021-01-04 04:30:09 --> URI Class Initialized
INFO - 2021-01-04 04:30:09 --> Router Class Initialized
INFO - 2021-01-04 04:30:09 --> Output Class Initialized
INFO - 2021-01-04 04:30:09 --> Security Class Initialized
DEBUG - 2021-01-04 04:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 04:30:09 --> Input Class Initialized
INFO - 2021-01-04 04:30:09 --> Language Class Initialized
INFO - 2021-01-04 04:30:09 --> Language Class Initialized
INFO - 2021-01-04 04:30:09 --> Config Class Initialized
INFO - 2021-01-04 04:30:09 --> Loader Class Initialized
INFO - 2021-01-04 04:30:09 --> Helper loaded: url_helper
INFO - 2021-01-04 04:30:09 --> Helper loaded: file_helper
INFO - 2021-01-04 04:30:10 --> Helper loaded: form_helper
INFO - 2021-01-04 04:30:10 --> Helper loaded: my_helper
INFO - 2021-01-04 04:30:10 --> Database Driver Class Initialized
DEBUG - 2021-01-04 04:30:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 04:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 04:30:10 --> Controller Class Initialized
DEBUG - 2021-01-04 04:30:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 04:30:10 --> Final output sent to browser
DEBUG - 2021-01-04 04:30:10 --> Total execution time: 1.0825
INFO - 2021-01-04 04:31:38 --> Config Class Initialized
INFO - 2021-01-04 04:31:38 --> Hooks Class Initialized
DEBUG - 2021-01-04 04:31:38 --> UTF-8 Support Enabled
INFO - 2021-01-04 04:31:38 --> Utf8 Class Initialized
INFO - 2021-01-04 04:31:38 --> URI Class Initialized
INFO - 2021-01-04 04:31:38 --> Router Class Initialized
INFO - 2021-01-04 04:31:38 --> Output Class Initialized
INFO - 2021-01-04 04:31:38 --> Security Class Initialized
DEBUG - 2021-01-04 04:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 04:31:38 --> Input Class Initialized
INFO - 2021-01-04 04:31:38 --> Language Class Initialized
INFO - 2021-01-04 04:31:38 --> Language Class Initialized
INFO - 2021-01-04 04:31:38 --> Config Class Initialized
INFO - 2021-01-04 04:31:38 --> Loader Class Initialized
INFO - 2021-01-04 04:31:39 --> Helper loaded: url_helper
INFO - 2021-01-04 04:31:39 --> Helper loaded: file_helper
INFO - 2021-01-04 04:31:39 --> Helper loaded: form_helper
INFO - 2021-01-04 04:31:39 --> Helper loaded: my_helper
INFO - 2021-01-04 04:31:39 --> Database Driver Class Initialized
DEBUG - 2021-01-04 04:31:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 04:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 04:31:39 --> Controller Class Initialized
DEBUG - 2021-01-04 04:31:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 04:31:39 --> Final output sent to browser
DEBUG - 2021-01-04 04:31:39 --> Total execution time: 0.9588
INFO - 2021-01-04 04:32:31 --> Config Class Initialized
INFO - 2021-01-04 04:32:31 --> Hooks Class Initialized
DEBUG - 2021-01-04 04:32:31 --> UTF-8 Support Enabled
INFO - 2021-01-04 04:32:31 --> Utf8 Class Initialized
INFO - 2021-01-04 04:32:31 --> URI Class Initialized
INFO - 2021-01-04 04:32:31 --> Router Class Initialized
INFO - 2021-01-04 04:32:31 --> Output Class Initialized
INFO - 2021-01-04 04:32:31 --> Security Class Initialized
DEBUG - 2021-01-04 04:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 04:32:31 --> Input Class Initialized
INFO - 2021-01-04 04:32:31 --> Language Class Initialized
INFO - 2021-01-04 04:32:31 --> Language Class Initialized
INFO - 2021-01-04 04:32:31 --> Config Class Initialized
INFO - 2021-01-04 04:32:31 --> Loader Class Initialized
INFO - 2021-01-04 04:32:31 --> Helper loaded: url_helper
INFO - 2021-01-04 04:32:31 --> Helper loaded: file_helper
INFO - 2021-01-04 04:32:31 --> Helper loaded: form_helper
INFO - 2021-01-04 04:32:31 --> Helper loaded: my_helper
INFO - 2021-01-04 04:32:31 --> Database Driver Class Initialized
DEBUG - 2021-01-04 04:32:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 04:32:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 04:32:32 --> Controller Class Initialized
DEBUG - 2021-01-04 04:32:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 04:32:32 --> Final output sent to browser
DEBUG - 2021-01-04 04:32:32 --> Total execution time: 0.9734
INFO - 2021-01-04 04:33:22 --> Config Class Initialized
INFO - 2021-01-04 04:33:22 --> Hooks Class Initialized
DEBUG - 2021-01-04 04:33:22 --> UTF-8 Support Enabled
INFO - 2021-01-04 04:33:22 --> Utf8 Class Initialized
INFO - 2021-01-04 04:33:22 --> URI Class Initialized
INFO - 2021-01-04 04:33:22 --> Router Class Initialized
INFO - 2021-01-04 04:33:22 --> Output Class Initialized
INFO - 2021-01-04 04:33:22 --> Security Class Initialized
DEBUG - 2021-01-04 04:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 04:33:22 --> Input Class Initialized
INFO - 2021-01-04 04:33:22 --> Language Class Initialized
INFO - 2021-01-04 04:33:23 --> Language Class Initialized
INFO - 2021-01-04 04:33:23 --> Config Class Initialized
INFO - 2021-01-04 04:33:23 --> Loader Class Initialized
INFO - 2021-01-04 04:33:23 --> Helper loaded: url_helper
INFO - 2021-01-04 04:33:23 --> Helper loaded: file_helper
INFO - 2021-01-04 04:33:23 --> Helper loaded: form_helper
INFO - 2021-01-04 04:33:23 --> Helper loaded: my_helper
INFO - 2021-01-04 04:33:23 --> Database Driver Class Initialized
DEBUG - 2021-01-04 04:33:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 04:33:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 04:33:23 --> Controller Class Initialized
DEBUG - 2021-01-04 04:33:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 04:33:23 --> Final output sent to browser
DEBUG - 2021-01-04 04:33:23 --> Total execution time: 0.9864
INFO - 2021-01-04 05:24:54 --> Config Class Initialized
INFO - 2021-01-04 05:24:54 --> Hooks Class Initialized
DEBUG - 2021-01-04 05:24:54 --> UTF-8 Support Enabled
INFO - 2021-01-04 05:24:54 --> Utf8 Class Initialized
INFO - 2021-01-04 05:24:54 --> URI Class Initialized
INFO - 2021-01-04 05:24:54 --> Router Class Initialized
INFO - 2021-01-04 05:24:54 --> Output Class Initialized
INFO - 2021-01-04 05:24:54 --> Security Class Initialized
DEBUG - 2021-01-04 05:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 05:24:54 --> Input Class Initialized
INFO - 2021-01-04 05:24:54 --> Language Class Initialized
INFO - 2021-01-04 05:24:54 --> Language Class Initialized
INFO - 2021-01-04 05:24:54 --> Config Class Initialized
INFO - 2021-01-04 05:24:54 --> Loader Class Initialized
INFO - 2021-01-04 05:24:54 --> Helper loaded: url_helper
INFO - 2021-01-04 05:24:54 --> Helper loaded: file_helper
INFO - 2021-01-04 05:24:54 --> Helper loaded: form_helper
INFO - 2021-01-04 05:24:54 --> Helper loaded: my_helper
INFO - 2021-01-04 05:24:54 --> Database Driver Class Initialized
DEBUG - 2021-01-04 05:24:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 05:24:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 05:24:55 --> Controller Class Initialized
DEBUG - 2021-01-04 05:24:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 05:24:55 --> Final output sent to browser
DEBUG - 2021-01-04 05:24:55 --> Total execution time: 1.1108
INFO - 2021-01-04 05:27:56 --> Config Class Initialized
INFO - 2021-01-04 05:27:56 --> Hooks Class Initialized
DEBUG - 2021-01-04 05:27:56 --> UTF-8 Support Enabled
INFO - 2021-01-04 05:27:56 --> Utf8 Class Initialized
INFO - 2021-01-04 05:27:56 --> URI Class Initialized
INFO - 2021-01-04 05:27:56 --> Router Class Initialized
INFO - 2021-01-04 05:27:56 --> Output Class Initialized
INFO - 2021-01-04 05:27:56 --> Security Class Initialized
DEBUG - 2021-01-04 05:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 05:27:57 --> Input Class Initialized
INFO - 2021-01-04 05:27:57 --> Language Class Initialized
INFO - 2021-01-04 05:27:57 --> Language Class Initialized
INFO - 2021-01-04 05:27:57 --> Config Class Initialized
INFO - 2021-01-04 05:27:57 --> Loader Class Initialized
INFO - 2021-01-04 05:27:57 --> Helper loaded: url_helper
INFO - 2021-01-04 05:27:57 --> Helper loaded: file_helper
INFO - 2021-01-04 05:27:57 --> Helper loaded: form_helper
INFO - 2021-01-04 05:27:57 --> Helper loaded: my_helper
INFO - 2021-01-04 05:27:57 --> Database Driver Class Initialized
DEBUG - 2021-01-04 05:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 05:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 05:27:57 --> Controller Class Initialized
DEBUG - 2021-01-04 05:27:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 05:27:57 --> Final output sent to browser
DEBUG - 2021-01-04 05:27:57 --> Total execution time: 1.1905
INFO - 2021-01-04 05:42:21 --> Config Class Initialized
INFO - 2021-01-04 05:42:21 --> Hooks Class Initialized
DEBUG - 2021-01-04 05:42:21 --> UTF-8 Support Enabled
INFO - 2021-01-04 05:42:21 --> Utf8 Class Initialized
INFO - 2021-01-04 05:42:21 --> URI Class Initialized
INFO - 2021-01-04 05:42:22 --> Router Class Initialized
INFO - 2021-01-04 05:42:22 --> Output Class Initialized
INFO - 2021-01-04 05:42:22 --> Security Class Initialized
DEBUG - 2021-01-04 05:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 05:42:22 --> Input Class Initialized
INFO - 2021-01-04 05:42:22 --> Language Class Initialized
INFO - 2021-01-04 05:42:22 --> Language Class Initialized
INFO - 2021-01-04 05:42:22 --> Config Class Initialized
INFO - 2021-01-04 05:42:22 --> Loader Class Initialized
INFO - 2021-01-04 05:42:22 --> Helper loaded: url_helper
INFO - 2021-01-04 05:42:22 --> Helper loaded: file_helper
INFO - 2021-01-04 05:42:22 --> Helper loaded: form_helper
INFO - 2021-01-04 05:42:22 --> Helper loaded: my_helper
INFO - 2021-01-04 05:42:22 --> Database Driver Class Initialized
DEBUG - 2021-01-04 05:42:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 05:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 05:42:22 --> Controller Class Initialized
ERROR - 2021-01-04 05:42:22 --> Severity: Notice --> Undefined index: id_kelas C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 410
ERROR - 2021-01-04 05:42:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LEFT JOIN m_siswa c ON b.id_siswa = c.id
										WHERE b.id_kelas = '' AND a.' at line 2 - Invalid query: SELECT * FROM m_mapel WHERE kelompok = 'B' AND tambahan_sub = 'NASIONAL'
										LEFT JOIN m_siswa c ON b.id_siswa = c.id
										WHERE b.id_kelas = '' AND a.tasm = '20201'
INFO - 2021-01-04 05:42:23 --> Language file loaded: language/english/db_lang.php
INFO - 2021-01-04 05:47:41 --> Config Class Initialized
INFO - 2021-01-04 05:47:41 --> Hooks Class Initialized
DEBUG - 2021-01-04 05:47:41 --> UTF-8 Support Enabled
INFO - 2021-01-04 05:47:41 --> Utf8 Class Initialized
INFO - 2021-01-04 05:47:41 --> URI Class Initialized
INFO - 2021-01-04 05:47:41 --> Router Class Initialized
INFO - 2021-01-04 05:47:41 --> Output Class Initialized
INFO - 2021-01-04 05:47:41 --> Security Class Initialized
DEBUG - 2021-01-04 05:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 05:47:42 --> Input Class Initialized
INFO - 2021-01-04 05:47:42 --> Language Class Initialized
INFO - 2021-01-04 05:47:42 --> Language Class Initialized
INFO - 2021-01-04 05:47:42 --> Config Class Initialized
INFO - 2021-01-04 05:47:42 --> Loader Class Initialized
INFO - 2021-01-04 05:47:42 --> Helper loaded: url_helper
INFO - 2021-01-04 05:47:42 --> Helper loaded: file_helper
INFO - 2021-01-04 05:47:42 --> Helper loaded: form_helper
INFO - 2021-01-04 05:47:42 --> Helper loaded: my_helper
INFO - 2021-01-04 05:47:42 --> Database Driver Class Initialized
DEBUG - 2021-01-04 05:47:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 05:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 05:47:42 --> Controller Class Initialized
DEBUG - 2021-01-04 05:47:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 05:47:42 --> Final output sent to browser
DEBUG - 2021-01-04 05:47:42 --> Total execution time: 1.1710
INFO - 2021-01-04 05:48:17 --> Config Class Initialized
INFO - 2021-01-04 05:48:17 --> Hooks Class Initialized
DEBUG - 2021-01-04 05:48:17 --> UTF-8 Support Enabled
INFO - 2021-01-04 05:48:17 --> Utf8 Class Initialized
INFO - 2021-01-04 05:48:17 --> URI Class Initialized
INFO - 2021-01-04 05:48:17 --> Router Class Initialized
INFO - 2021-01-04 05:48:17 --> Output Class Initialized
INFO - 2021-01-04 05:48:17 --> Security Class Initialized
DEBUG - 2021-01-04 05:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 05:48:17 --> Input Class Initialized
INFO - 2021-01-04 05:48:17 --> Language Class Initialized
INFO - 2021-01-04 05:48:17 --> Language Class Initialized
INFO - 2021-01-04 05:48:17 --> Config Class Initialized
INFO - 2021-01-04 05:48:17 --> Loader Class Initialized
INFO - 2021-01-04 05:48:17 --> Helper loaded: url_helper
INFO - 2021-01-04 05:48:17 --> Helper loaded: file_helper
INFO - 2021-01-04 05:48:17 --> Helper loaded: form_helper
INFO - 2021-01-04 05:48:17 --> Helper loaded: my_helper
INFO - 2021-01-04 05:48:17 --> Database Driver Class Initialized
DEBUG - 2021-01-04 05:48:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 05:48:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 05:48:17 --> Controller Class Initialized
DEBUG - 2021-01-04 05:48:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 05:48:18 --> Final output sent to browser
DEBUG - 2021-01-04 05:48:18 --> Total execution time: 1.0767
INFO - 2021-01-04 05:51:10 --> Config Class Initialized
INFO - 2021-01-04 05:51:10 --> Hooks Class Initialized
DEBUG - 2021-01-04 05:51:10 --> UTF-8 Support Enabled
INFO - 2021-01-04 05:51:11 --> Utf8 Class Initialized
INFO - 2021-01-04 05:51:11 --> URI Class Initialized
INFO - 2021-01-04 05:51:11 --> Router Class Initialized
INFO - 2021-01-04 05:51:11 --> Output Class Initialized
INFO - 2021-01-04 05:51:11 --> Security Class Initialized
DEBUG - 2021-01-04 05:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 05:51:11 --> Input Class Initialized
INFO - 2021-01-04 05:51:11 --> Language Class Initialized
INFO - 2021-01-04 05:51:11 --> Language Class Initialized
INFO - 2021-01-04 05:51:11 --> Config Class Initialized
INFO - 2021-01-04 05:51:11 --> Loader Class Initialized
INFO - 2021-01-04 05:51:11 --> Helper loaded: url_helper
INFO - 2021-01-04 05:51:11 --> Helper loaded: file_helper
INFO - 2021-01-04 05:51:11 --> Helper loaded: form_helper
INFO - 2021-01-04 05:51:11 --> Helper loaded: my_helper
INFO - 2021-01-04 05:51:11 --> Database Driver Class Initialized
DEBUG - 2021-01-04 05:51:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 05:51:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 05:51:11 --> Controller Class Initialized
DEBUG - 2021-01-04 05:51:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 05:51:12 --> Final output sent to browser
DEBUG - 2021-01-04 05:51:12 --> Total execution time: 1.1077
INFO - 2021-01-04 07:18:04 --> Config Class Initialized
INFO - 2021-01-04 07:18:04 --> Hooks Class Initialized
DEBUG - 2021-01-04 07:18:04 --> UTF-8 Support Enabled
INFO - 2021-01-04 07:18:04 --> Utf8 Class Initialized
INFO - 2021-01-04 07:18:04 --> URI Class Initialized
INFO - 2021-01-04 07:18:04 --> Router Class Initialized
INFO - 2021-01-04 07:18:04 --> Output Class Initialized
INFO - 2021-01-04 07:18:04 --> Security Class Initialized
DEBUG - 2021-01-04 07:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 07:18:04 --> Input Class Initialized
INFO - 2021-01-04 07:18:04 --> Language Class Initialized
INFO - 2021-01-04 07:18:04 --> Language Class Initialized
INFO - 2021-01-04 07:18:04 --> Config Class Initialized
INFO - 2021-01-04 07:18:04 --> Loader Class Initialized
INFO - 2021-01-04 07:18:04 --> Helper loaded: url_helper
INFO - 2021-01-04 07:18:04 --> Helper loaded: file_helper
INFO - 2021-01-04 07:18:04 --> Helper loaded: form_helper
INFO - 2021-01-04 07:18:04 --> Helper loaded: my_helper
INFO - 2021-01-04 07:18:04 --> Database Driver Class Initialized
DEBUG - 2021-01-04 07:18:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 07:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 07:18:04 --> Controller Class Initialized
DEBUG - 2021-01-04 07:18:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-04 07:18:04 --> Final output sent to browser
DEBUG - 2021-01-04 07:18:04 --> Total execution time: 0.4190
INFO - 2021-01-04 07:20:43 --> Config Class Initialized
INFO - 2021-01-04 07:20:43 --> Hooks Class Initialized
DEBUG - 2021-01-04 07:20:43 --> UTF-8 Support Enabled
INFO - 2021-01-04 07:20:43 --> Utf8 Class Initialized
INFO - 2021-01-04 07:20:43 --> URI Class Initialized
INFO - 2021-01-04 07:20:43 --> Router Class Initialized
INFO - 2021-01-04 07:20:43 --> Output Class Initialized
INFO - 2021-01-04 07:20:43 --> Security Class Initialized
DEBUG - 2021-01-04 07:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 07:20:43 --> Input Class Initialized
INFO - 2021-01-04 07:20:43 --> Language Class Initialized
INFO - 2021-01-04 07:20:43 --> Language Class Initialized
INFO - 2021-01-04 07:20:43 --> Config Class Initialized
INFO - 2021-01-04 07:20:44 --> Loader Class Initialized
INFO - 2021-01-04 07:20:44 --> Helper loaded: url_helper
INFO - 2021-01-04 07:20:44 --> Helper loaded: file_helper
INFO - 2021-01-04 07:20:44 --> Helper loaded: form_helper
INFO - 2021-01-04 07:20:44 --> Helper loaded: my_helper
INFO - 2021-01-04 07:20:44 --> Database Driver Class Initialized
DEBUG - 2021-01-04 07:20:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 07:20:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 07:20:44 --> Controller Class Initialized
INFO - 2021-01-04 07:20:44 --> Helper loaded: cookie_helper
INFO - 2021-01-04 07:20:44 --> Config Class Initialized
INFO - 2021-01-04 07:20:44 --> Hooks Class Initialized
DEBUG - 2021-01-04 07:20:44 --> UTF-8 Support Enabled
INFO - 2021-01-04 07:20:44 --> Utf8 Class Initialized
INFO - 2021-01-04 07:20:44 --> URI Class Initialized
INFO - 2021-01-04 07:20:44 --> Router Class Initialized
INFO - 2021-01-04 07:20:44 --> Output Class Initialized
INFO - 2021-01-04 07:20:44 --> Security Class Initialized
DEBUG - 2021-01-04 07:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 07:20:44 --> Input Class Initialized
INFO - 2021-01-04 07:20:44 --> Language Class Initialized
INFO - 2021-01-04 07:20:44 --> Language Class Initialized
INFO - 2021-01-04 07:20:44 --> Config Class Initialized
INFO - 2021-01-04 07:20:44 --> Loader Class Initialized
INFO - 2021-01-04 07:20:44 --> Helper loaded: url_helper
INFO - 2021-01-04 07:20:44 --> Helper loaded: file_helper
INFO - 2021-01-04 07:20:44 --> Helper loaded: form_helper
INFO - 2021-01-04 07:20:44 --> Helper loaded: my_helper
INFO - 2021-01-04 07:20:44 --> Database Driver Class Initialized
DEBUG - 2021-01-04 07:20:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 07:20:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 07:20:44 --> Controller Class Initialized
DEBUG - 2021-01-04 07:20:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-04 07:20:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-04 07:20:44 --> Final output sent to browser
DEBUG - 2021-01-04 07:20:44 --> Total execution time: 0.4532
INFO - 2021-01-04 07:20:49 --> Config Class Initialized
INFO - 2021-01-04 07:20:49 --> Hooks Class Initialized
DEBUG - 2021-01-04 07:20:49 --> UTF-8 Support Enabled
INFO - 2021-01-04 07:20:49 --> Utf8 Class Initialized
INFO - 2021-01-04 07:20:49 --> URI Class Initialized
INFO - 2021-01-04 07:20:49 --> Router Class Initialized
INFO - 2021-01-04 07:20:49 --> Output Class Initialized
INFO - 2021-01-04 07:20:49 --> Security Class Initialized
DEBUG - 2021-01-04 07:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 07:20:49 --> Input Class Initialized
INFO - 2021-01-04 07:20:50 --> Language Class Initialized
INFO - 2021-01-04 07:20:50 --> Language Class Initialized
INFO - 2021-01-04 07:20:50 --> Config Class Initialized
INFO - 2021-01-04 07:20:50 --> Loader Class Initialized
INFO - 2021-01-04 07:20:50 --> Helper loaded: url_helper
INFO - 2021-01-04 07:20:50 --> Helper loaded: file_helper
INFO - 2021-01-04 07:20:50 --> Helper loaded: form_helper
INFO - 2021-01-04 07:20:50 --> Helper loaded: my_helper
INFO - 2021-01-04 07:20:50 --> Database Driver Class Initialized
DEBUG - 2021-01-04 07:20:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 07:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 07:20:50 --> Controller Class Initialized
INFO - 2021-01-04 07:20:50 --> Helper loaded: cookie_helper
INFO - 2021-01-04 07:20:50 --> Final output sent to browser
DEBUG - 2021-01-04 07:20:50 --> Total execution time: 0.5602
INFO - 2021-01-04 07:20:50 --> Config Class Initialized
INFO - 2021-01-04 07:20:50 --> Hooks Class Initialized
DEBUG - 2021-01-04 07:20:50 --> UTF-8 Support Enabled
INFO - 2021-01-04 07:20:51 --> Utf8 Class Initialized
INFO - 2021-01-04 07:20:51 --> URI Class Initialized
INFO - 2021-01-04 07:20:51 --> Router Class Initialized
INFO - 2021-01-04 07:20:51 --> Output Class Initialized
INFO - 2021-01-04 07:20:51 --> Security Class Initialized
DEBUG - 2021-01-04 07:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 07:20:51 --> Input Class Initialized
INFO - 2021-01-04 07:20:51 --> Language Class Initialized
INFO - 2021-01-04 07:20:51 --> Language Class Initialized
INFO - 2021-01-04 07:20:51 --> Config Class Initialized
INFO - 2021-01-04 07:20:51 --> Loader Class Initialized
INFO - 2021-01-04 07:20:51 --> Helper loaded: url_helper
INFO - 2021-01-04 07:20:51 --> Helper loaded: file_helper
INFO - 2021-01-04 07:20:51 --> Helper loaded: form_helper
INFO - 2021-01-04 07:20:51 --> Helper loaded: my_helper
INFO - 2021-01-04 07:20:51 --> Database Driver Class Initialized
DEBUG - 2021-01-04 07:20:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 07:20:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 07:20:51 --> Controller Class Initialized
DEBUG - 2021-01-04 07:20:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-04 07:20:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-04 07:20:51 --> Final output sent to browser
DEBUG - 2021-01-04 07:20:51 --> Total execution time: 0.6326
INFO - 2021-01-04 07:20:58 --> Config Class Initialized
INFO - 2021-01-04 07:20:58 --> Hooks Class Initialized
DEBUG - 2021-01-04 07:20:58 --> UTF-8 Support Enabled
INFO - 2021-01-04 07:20:58 --> Utf8 Class Initialized
INFO - 2021-01-04 07:20:58 --> URI Class Initialized
INFO - 2021-01-04 07:20:58 --> Router Class Initialized
INFO - 2021-01-04 07:20:58 --> Output Class Initialized
INFO - 2021-01-04 07:20:58 --> Security Class Initialized
DEBUG - 2021-01-04 07:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 07:20:58 --> Input Class Initialized
INFO - 2021-01-04 07:20:58 --> Language Class Initialized
INFO - 2021-01-04 07:20:58 --> Language Class Initialized
INFO - 2021-01-04 07:20:58 --> Config Class Initialized
INFO - 2021-01-04 07:20:58 --> Loader Class Initialized
INFO - 2021-01-04 07:20:58 --> Helper loaded: url_helper
INFO - 2021-01-04 07:20:58 --> Helper loaded: file_helper
INFO - 2021-01-04 07:20:58 --> Helper loaded: form_helper
INFO - 2021-01-04 07:20:58 --> Helper loaded: my_helper
INFO - 2021-01-04 07:20:58 --> Database Driver Class Initialized
DEBUG - 2021-01-04 07:20:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 07:20:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 07:20:58 --> Controller Class Initialized
DEBUG - 2021-01-04 07:20:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_catatan/views/list.php
DEBUG - 2021-01-04 07:20:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-04 07:20:59 --> Final output sent to browser
DEBUG - 2021-01-04 07:20:59 --> Total execution time: 0.5430
INFO - 2021-01-04 07:22:47 --> Config Class Initialized
INFO - 2021-01-04 07:22:47 --> Hooks Class Initialized
DEBUG - 2021-01-04 07:22:47 --> UTF-8 Support Enabled
INFO - 2021-01-04 07:22:47 --> Utf8 Class Initialized
INFO - 2021-01-04 07:22:47 --> URI Class Initialized
INFO - 2021-01-04 07:22:47 --> Router Class Initialized
INFO - 2021-01-04 07:22:47 --> Output Class Initialized
INFO - 2021-01-04 07:22:47 --> Security Class Initialized
DEBUG - 2021-01-04 07:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 07:22:47 --> Input Class Initialized
INFO - 2021-01-04 07:22:47 --> Language Class Initialized
INFO - 2021-01-04 07:22:47 --> Language Class Initialized
INFO - 2021-01-04 07:22:47 --> Config Class Initialized
INFO - 2021-01-04 07:22:47 --> Loader Class Initialized
INFO - 2021-01-04 07:22:47 --> Helper loaded: url_helper
INFO - 2021-01-04 07:22:47 --> Helper loaded: file_helper
INFO - 2021-01-04 07:22:47 --> Helper loaded: form_helper
INFO - 2021-01-04 07:22:47 --> Helper loaded: my_helper
INFO - 2021-01-04 07:22:47 --> Database Driver Class Initialized
DEBUG - 2021-01-04 07:22:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 07:22:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 07:22:47 --> Controller Class Initialized
DEBUG - 2021-01-04 07:22:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_catatan/views/list.php
DEBUG - 2021-01-04 07:22:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-04 07:22:47 --> Final output sent to browser
DEBUG - 2021-01-04 07:22:47 --> Total execution time: 0.4421
INFO - 2021-01-04 07:25:24 --> Config Class Initialized
INFO - 2021-01-04 07:25:24 --> Hooks Class Initialized
DEBUG - 2021-01-04 07:25:25 --> UTF-8 Support Enabled
INFO - 2021-01-04 07:25:25 --> Utf8 Class Initialized
INFO - 2021-01-04 07:25:25 --> URI Class Initialized
INFO - 2021-01-04 07:25:25 --> Router Class Initialized
INFO - 2021-01-04 07:25:25 --> Output Class Initialized
INFO - 2021-01-04 07:25:25 --> Security Class Initialized
DEBUG - 2021-01-04 07:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 07:25:25 --> Input Class Initialized
INFO - 2021-01-04 07:25:25 --> Language Class Initialized
INFO - 2021-01-04 07:25:25 --> Language Class Initialized
INFO - 2021-01-04 07:25:25 --> Config Class Initialized
INFO - 2021-01-04 07:25:25 --> Loader Class Initialized
INFO - 2021-01-04 07:25:25 --> Helper loaded: url_helper
INFO - 2021-01-04 07:25:25 --> Helper loaded: file_helper
INFO - 2021-01-04 07:25:25 --> Helper loaded: form_helper
INFO - 2021-01-04 07:25:25 --> Helper loaded: my_helper
INFO - 2021-01-04 07:25:25 --> Database Driver Class Initialized
DEBUG - 2021-01-04 07:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 07:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 07:25:25 --> Controller Class Initialized
DEBUG - 2021-01-04 07:25:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_catatan/views/list.php
DEBUG - 2021-01-04 07:25:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-04 07:25:25 --> Final output sent to browser
DEBUG - 2021-01-04 07:25:25 --> Total execution time: 0.4415
INFO - 2021-01-04 07:27:11 --> Config Class Initialized
INFO - 2021-01-04 07:27:11 --> Hooks Class Initialized
DEBUG - 2021-01-04 07:27:11 --> UTF-8 Support Enabled
INFO - 2021-01-04 07:27:11 --> Utf8 Class Initialized
INFO - 2021-01-04 07:27:11 --> URI Class Initialized
INFO - 2021-01-04 07:27:11 --> Router Class Initialized
INFO - 2021-01-04 07:27:11 --> Output Class Initialized
INFO - 2021-01-04 07:27:11 --> Security Class Initialized
DEBUG - 2021-01-04 07:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 07:27:11 --> Input Class Initialized
INFO - 2021-01-04 07:27:11 --> Language Class Initialized
INFO - 2021-01-04 07:27:11 --> Language Class Initialized
INFO - 2021-01-04 07:27:11 --> Config Class Initialized
INFO - 2021-01-04 07:27:11 --> Loader Class Initialized
INFO - 2021-01-04 07:27:11 --> Helper loaded: url_helper
INFO - 2021-01-04 07:27:11 --> Helper loaded: file_helper
INFO - 2021-01-04 07:27:11 --> Helper loaded: form_helper
INFO - 2021-01-04 07:27:12 --> Helper loaded: my_helper
INFO - 2021-01-04 07:27:12 --> Database Driver Class Initialized
DEBUG - 2021-01-04 07:27:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 07:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 07:27:12 --> Controller Class Initialized
DEBUG - 2021-01-04 07:27:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-01-04 07:27:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-04 07:27:12 --> Final output sent to browser
DEBUG - 2021-01-04 07:27:12 --> Total execution time: 0.4716
INFO - 2021-01-04 07:27:15 --> Config Class Initialized
INFO - 2021-01-04 07:27:15 --> Hooks Class Initialized
DEBUG - 2021-01-04 07:27:15 --> UTF-8 Support Enabled
INFO - 2021-01-04 07:27:15 --> Utf8 Class Initialized
INFO - 2021-01-04 07:27:15 --> URI Class Initialized
INFO - 2021-01-04 07:27:15 --> Router Class Initialized
INFO - 2021-01-04 07:27:15 --> Output Class Initialized
INFO - 2021-01-04 07:27:15 --> Security Class Initialized
DEBUG - 2021-01-04 07:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 07:27:15 --> Input Class Initialized
INFO - 2021-01-04 07:27:15 --> Language Class Initialized
INFO - 2021-01-04 07:27:15 --> Language Class Initialized
INFO - 2021-01-04 07:27:15 --> Config Class Initialized
INFO - 2021-01-04 07:27:15 --> Loader Class Initialized
INFO - 2021-01-04 07:27:15 --> Helper loaded: url_helper
INFO - 2021-01-04 07:27:15 --> Helper loaded: file_helper
INFO - 2021-01-04 07:27:15 --> Helper loaded: form_helper
INFO - 2021-01-04 07:27:15 --> Helper loaded: my_helper
INFO - 2021-01-04 07:27:15 --> Database Driver Class Initialized
DEBUG - 2021-01-04 07:27:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 07:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 07:27:15 --> Controller Class Initialized
DEBUG - 2021-01-04 07:27:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_ekstra.php
INFO - 2021-01-04 07:27:15 --> Final output sent to browser
DEBUG - 2021-01-04 07:27:16 --> Total execution time: 0.4431
INFO - 2021-01-04 07:30:33 --> Config Class Initialized
INFO - 2021-01-04 07:30:33 --> Hooks Class Initialized
DEBUG - 2021-01-04 07:30:33 --> UTF-8 Support Enabled
INFO - 2021-01-04 07:30:33 --> Utf8 Class Initialized
INFO - 2021-01-04 07:30:33 --> URI Class Initialized
INFO - 2021-01-04 07:30:34 --> Router Class Initialized
INFO - 2021-01-04 07:30:34 --> Output Class Initialized
INFO - 2021-01-04 07:30:34 --> Security Class Initialized
DEBUG - 2021-01-04 07:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 07:30:34 --> Input Class Initialized
INFO - 2021-01-04 07:30:34 --> Language Class Initialized
INFO - 2021-01-04 07:30:34 --> Language Class Initialized
INFO - 2021-01-04 07:30:34 --> Config Class Initialized
INFO - 2021-01-04 07:30:34 --> Loader Class Initialized
INFO - 2021-01-04 07:30:34 --> Helper loaded: url_helper
INFO - 2021-01-04 07:30:34 --> Helper loaded: file_helper
INFO - 2021-01-04 07:30:34 --> Helper loaded: form_helper
INFO - 2021-01-04 07:30:34 --> Helper loaded: my_helper
INFO - 2021-01-04 07:30:34 --> Database Driver Class Initialized
DEBUG - 2021-01-04 07:30:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 07:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 07:30:34 --> Controller Class Initialized
DEBUG - 2021-01-04 07:30:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_ekstra.php
INFO - 2021-01-04 07:30:34 --> Final output sent to browser
DEBUG - 2021-01-04 07:30:34 --> Total execution time: 0.3839
INFO - 2021-01-04 07:31:10 --> Config Class Initialized
INFO - 2021-01-04 07:31:10 --> Hooks Class Initialized
DEBUG - 2021-01-04 07:31:10 --> UTF-8 Support Enabled
INFO - 2021-01-04 07:31:10 --> Utf8 Class Initialized
INFO - 2021-01-04 07:31:10 --> URI Class Initialized
INFO - 2021-01-04 07:31:10 --> Router Class Initialized
INFO - 2021-01-04 07:31:10 --> Output Class Initialized
INFO - 2021-01-04 07:31:10 --> Security Class Initialized
DEBUG - 2021-01-04 07:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 07:31:10 --> Input Class Initialized
INFO - 2021-01-04 07:31:10 --> Language Class Initialized
INFO - 2021-01-04 07:31:10 --> Language Class Initialized
INFO - 2021-01-04 07:31:10 --> Config Class Initialized
INFO - 2021-01-04 07:31:10 --> Loader Class Initialized
INFO - 2021-01-04 07:31:10 --> Helper loaded: url_helper
INFO - 2021-01-04 07:31:10 --> Helper loaded: file_helper
INFO - 2021-01-04 07:31:10 --> Helper loaded: form_helper
INFO - 2021-01-04 07:31:10 --> Helper loaded: my_helper
INFO - 2021-01-04 07:31:10 --> Database Driver Class Initialized
DEBUG - 2021-01-04 07:31:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 07:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 07:31:10 --> Controller Class Initialized
DEBUG - 2021-01-04 07:31:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-04 07:31:10 --> Final output sent to browser
DEBUG - 2021-01-04 07:31:10 --> Total execution time: 0.4668
INFO - 2021-01-04 08:12:21 --> Config Class Initialized
INFO - 2021-01-04 08:12:21 --> Hooks Class Initialized
DEBUG - 2021-01-04 08:12:21 --> UTF-8 Support Enabled
INFO - 2021-01-04 08:12:21 --> Utf8 Class Initialized
INFO - 2021-01-04 08:12:21 --> URI Class Initialized
INFO - 2021-01-04 08:12:21 --> Router Class Initialized
INFO - 2021-01-04 08:12:21 --> Output Class Initialized
INFO - 2021-01-04 08:12:21 --> Security Class Initialized
DEBUG - 2021-01-04 08:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 08:12:21 --> Input Class Initialized
INFO - 2021-01-04 08:12:21 --> Language Class Initialized
INFO - 2021-01-04 08:12:21 --> Language Class Initialized
INFO - 2021-01-04 08:12:21 --> Config Class Initialized
INFO - 2021-01-04 08:12:21 --> Loader Class Initialized
INFO - 2021-01-04 08:12:21 --> Helper loaded: url_helper
INFO - 2021-01-04 08:12:21 --> Helper loaded: file_helper
INFO - 2021-01-04 08:12:21 --> Helper loaded: form_helper
INFO - 2021-01-04 08:12:21 --> Helper loaded: my_helper
INFO - 2021-01-04 08:12:21 --> Database Driver Class Initialized
DEBUG - 2021-01-04 08:12:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 08:12:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 08:12:21 --> Controller Class Initialized
DEBUG - 2021-01-04 08:12:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-01-04 08:12:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-04 08:12:21 --> Final output sent to browser
DEBUG - 2021-01-04 08:12:21 --> Total execution time: 0.5152
INFO - 2021-01-04 08:12:23 --> Config Class Initialized
INFO - 2021-01-04 08:12:23 --> Hooks Class Initialized
DEBUG - 2021-01-04 08:12:23 --> UTF-8 Support Enabled
INFO - 2021-01-04 08:12:23 --> Utf8 Class Initialized
INFO - 2021-01-04 08:12:23 --> URI Class Initialized
INFO - 2021-01-04 08:12:23 --> Router Class Initialized
INFO - 2021-01-04 08:12:23 --> Output Class Initialized
INFO - 2021-01-04 08:12:23 --> Security Class Initialized
DEBUG - 2021-01-04 08:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 08:12:23 --> Input Class Initialized
INFO - 2021-01-04 08:12:23 --> Language Class Initialized
INFO - 2021-01-04 08:12:23 --> Language Class Initialized
INFO - 2021-01-04 08:12:23 --> Config Class Initialized
INFO - 2021-01-04 08:12:23 --> Loader Class Initialized
INFO - 2021-01-04 08:12:23 --> Helper loaded: url_helper
INFO - 2021-01-04 08:12:23 --> Helper loaded: file_helper
INFO - 2021-01-04 08:12:23 --> Helper loaded: form_helper
INFO - 2021-01-04 08:12:23 --> Helper loaded: my_helper
INFO - 2021-01-04 08:12:23 --> Database Driver Class Initialized
DEBUG - 2021-01-04 08:12:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 08:12:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 08:12:23 --> Controller Class Initialized
ERROR - 2021-01-04 08:12:23 --> Query error: Unknown column 'a.naik' in 'field list' - Invalid query: SELECT 
                                                    a.*, b.nama, a.naik, a.catatan_akademik
                                                    FROM t_c_akademik a
                                                    INNER JOIN m_siswa b ON a.id_siswa = b.id
                                                    INNER JOIN t_kelas_siswa c ON CONCAT(c.ta,c.id_kelas,c.id_siswa) = CONCAT('2020','41',b.id)
                                                    WHERE c.id_kelas = '41' AND a.ta = '20201'
INFO - 2021-01-04 08:12:23 --> Language file loaded: language/english/db_lang.php
INFO - 2021-01-04 08:20:09 --> Config Class Initialized
INFO - 2021-01-04 08:20:09 --> Hooks Class Initialized
DEBUG - 2021-01-04 08:20:09 --> UTF-8 Support Enabled
INFO - 2021-01-04 08:20:09 --> Utf8 Class Initialized
INFO - 2021-01-04 08:20:09 --> URI Class Initialized
INFO - 2021-01-04 08:20:09 --> Router Class Initialized
INFO - 2021-01-04 08:20:09 --> Output Class Initialized
INFO - 2021-01-04 08:20:09 --> Security Class Initialized
DEBUG - 2021-01-04 08:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 08:20:09 --> Input Class Initialized
INFO - 2021-01-04 08:20:09 --> Language Class Initialized
INFO - 2021-01-04 08:20:09 --> Language Class Initialized
INFO - 2021-01-04 08:20:09 --> Config Class Initialized
INFO - 2021-01-04 08:20:09 --> Loader Class Initialized
INFO - 2021-01-04 08:20:09 --> Helper loaded: url_helper
INFO - 2021-01-04 08:20:09 --> Helper loaded: file_helper
INFO - 2021-01-04 08:20:09 --> Helper loaded: form_helper
INFO - 2021-01-04 08:20:09 --> Helper loaded: my_helper
INFO - 2021-01-04 08:20:09 --> Database Driver Class Initialized
DEBUG - 2021-01-04 08:20:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 08:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 08:20:09 --> Controller Class Initialized
ERROR - 2021-01-04 08:20:09 --> Query error: Unknown column 'a.naik' in 'field list' - Invalid query: SELECT 
                                                    a.*, b.nama, a.naik, a.catatan_akademik
                                                    FROM t_c_akademik a
                                                    INNER JOIN m_siswa b ON a.id_siswa = b.id
                                                    INNER JOIN t_kelas_siswa c ON CONCAT(c.ta,c.id_kelas,c.id_siswa) = CONCAT('2020','41',b.id)
                                                    WHERE c.id_kelas = '41' AND a.ta = '20201'
INFO - 2021-01-04 08:20:09 --> Language file loaded: language/english/db_lang.php
INFO - 2021-01-04 08:20:37 --> Config Class Initialized
INFO - 2021-01-04 08:20:37 --> Hooks Class Initialized
DEBUG - 2021-01-04 08:20:37 --> UTF-8 Support Enabled
INFO - 2021-01-04 08:20:37 --> Utf8 Class Initialized
INFO - 2021-01-04 08:20:37 --> URI Class Initialized
INFO - 2021-01-04 08:20:37 --> Router Class Initialized
INFO - 2021-01-04 08:20:37 --> Output Class Initialized
INFO - 2021-01-04 08:20:37 --> Security Class Initialized
DEBUG - 2021-01-04 08:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 08:20:38 --> Input Class Initialized
INFO - 2021-01-04 08:20:38 --> Language Class Initialized
INFO - 2021-01-04 08:20:38 --> Language Class Initialized
INFO - 2021-01-04 08:20:38 --> Config Class Initialized
INFO - 2021-01-04 08:20:38 --> Loader Class Initialized
INFO - 2021-01-04 08:20:38 --> Helper loaded: url_helper
INFO - 2021-01-04 08:20:38 --> Helper loaded: file_helper
INFO - 2021-01-04 08:20:38 --> Helper loaded: form_helper
INFO - 2021-01-04 08:20:38 --> Helper loaded: my_helper
INFO - 2021-01-04 08:20:38 --> Database Driver Class Initialized
DEBUG - 2021-01-04 08:20:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 08:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 08:20:38 --> Controller Class Initialized
ERROR - 2021-01-04 08:20:38 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 102
INFO - 2021-01-04 08:20:57 --> Config Class Initialized
INFO - 2021-01-04 08:20:57 --> Hooks Class Initialized
DEBUG - 2021-01-04 08:20:57 --> UTF-8 Support Enabled
INFO - 2021-01-04 08:20:57 --> Utf8 Class Initialized
INFO - 2021-01-04 08:20:57 --> URI Class Initialized
INFO - 2021-01-04 08:20:57 --> Router Class Initialized
INFO - 2021-01-04 08:20:57 --> Output Class Initialized
INFO - 2021-01-04 08:20:57 --> Security Class Initialized
DEBUG - 2021-01-04 08:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 08:20:57 --> Input Class Initialized
INFO - 2021-01-04 08:20:57 --> Language Class Initialized
INFO - 2021-01-04 08:20:57 --> Language Class Initialized
INFO - 2021-01-04 08:20:57 --> Config Class Initialized
INFO - 2021-01-04 08:20:57 --> Loader Class Initialized
INFO - 2021-01-04 08:20:57 --> Helper loaded: url_helper
INFO - 2021-01-04 08:20:57 --> Helper loaded: file_helper
INFO - 2021-01-04 08:20:57 --> Helper loaded: form_helper
INFO - 2021-01-04 08:20:57 --> Helper loaded: my_helper
INFO - 2021-01-04 08:20:57 --> Database Driver Class Initialized
DEBUG - 2021-01-04 08:20:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 08:20:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 08:20:58 --> Controller Class Initialized
ERROR - 2021-01-04 08:20:58 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 102
INFO - 2021-01-04 08:25:16 --> Config Class Initialized
INFO - 2021-01-04 08:25:16 --> Hooks Class Initialized
DEBUG - 2021-01-04 08:25:16 --> UTF-8 Support Enabled
INFO - 2021-01-04 08:25:16 --> Utf8 Class Initialized
INFO - 2021-01-04 08:25:16 --> URI Class Initialized
INFO - 2021-01-04 08:25:16 --> Router Class Initialized
INFO - 2021-01-04 08:25:17 --> Output Class Initialized
INFO - 2021-01-04 08:25:17 --> Security Class Initialized
DEBUG - 2021-01-04 08:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 08:25:17 --> Input Class Initialized
INFO - 2021-01-04 08:25:17 --> Language Class Initialized
INFO - 2021-01-04 08:25:17 --> Language Class Initialized
INFO - 2021-01-04 08:25:17 --> Config Class Initialized
INFO - 2021-01-04 08:25:17 --> Loader Class Initialized
INFO - 2021-01-04 08:25:17 --> Helper loaded: url_helper
INFO - 2021-01-04 08:25:17 --> Helper loaded: file_helper
INFO - 2021-01-04 08:25:17 --> Helper loaded: form_helper
INFO - 2021-01-04 08:25:17 --> Helper loaded: my_helper
INFO - 2021-01-04 08:25:17 --> Database Driver Class Initialized
DEBUG - 2021-01-04 08:25:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 08:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 08:25:17 --> Controller Class Initialized
ERROR - 2021-01-04 08:25:17 --> Severity: Notice --> Undefined variable: p_naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:17 --> Severity: Notice --> Undefined index: naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:17 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 41
ERROR - 2021-01-04 08:25:17 --> Severity: Notice --> Undefined variable: p_naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:17 --> Severity: Notice --> Undefined index: naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:17 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 41
ERROR - 2021-01-04 08:25:17 --> Severity: Notice --> Undefined variable: p_naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:17 --> Severity: Notice --> Undefined index: naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:17 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 41
ERROR - 2021-01-04 08:25:17 --> Severity: Notice --> Undefined variable: p_naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:17 --> Severity: Notice --> Undefined index: naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:17 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 41
ERROR - 2021-01-04 08:25:17 --> Severity: Notice --> Undefined variable: p_naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:17 --> Severity: Notice --> Undefined index: naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:17 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 41
ERROR - 2021-01-04 08:25:17 --> Severity: Notice --> Undefined variable: p_naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:17 --> Severity: Notice --> Undefined index: naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:17 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 41
ERROR - 2021-01-04 08:25:17 --> Severity: Notice --> Undefined variable: p_naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:17 --> Severity: Notice --> Undefined index: naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:17 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 41
ERROR - 2021-01-04 08:25:17 --> Severity: Notice --> Undefined variable: p_naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:17 --> Severity: Notice --> Undefined index: naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:17 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 41
ERROR - 2021-01-04 08:25:17 --> Severity: Notice --> Undefined variable: p_naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:17 --> Severity: Notice --> Undefined index: naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:17 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 41
ERROR - 2021-01-04 08:25:17 --> Severity: Notice --> Undefined variable: p_naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:17 --> Severity: Notice --> Undefined index: naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:17 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 41
ERROR - 2021-01-04 08:25:17 --> Severity: Notice --> Undefined variable: p_naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:17 --> Severity: Notice --> Undefined index: naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:17 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 41
ERROR - 2021-01-04 08:25:17 --> Severity: Notice --> Undefined variable: p_naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:17 --> Severity: Notice --> Undefined index: naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:17 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 41
ERROR - 2021-01-04 08:25:17 --> Severity: Notice --> Undefined variable: p_naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:17 --> Severity: Notice --> Undefined index: naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:18 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 41
ERROR - 2021-01-04 08:25:18 --> Severity: Notice --> Undefined variable: p_naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:18 --> Severity: Notice --> Undefined index: naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:18 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 41
ERROR - 2021-01-04 08:25:18 --> Severity: Notice --> Undefined variable: p_naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:18 --> Severity: Notice --> Undefined index: naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:18 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 41
ERROR - 2021-01-04 08:25:18 --> Severity: Notice --> Undefined variable: p_naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:18 --> Severity: Notice --> Undefined index: naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:18 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 41
ERROR - 2021-01-04 08:25:18 --> Severity: Notice --> Undefined variable: p_naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:18 --> Severity: Notice --> Undefined index: naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:18 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 41
ERROR - 2021-01-04 08:25:18 --> Severity: Notice --> Undefined variable: p_naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:18 --> Severity: Notice --> Undefined index: naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:18 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 41
ERROR - 2021-01-04 08:25:18 --> Severity: Notice --> Undefined variable: p_naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:18 --> Severity: Notice --> Undefined index: naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:18 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 41
ERROR - 2021-01-04 08:25:18 --> Severity: Notice --> Undefined variable: p_naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:18 --> Severity: Notice --> Undefined index: naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:18 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 41
ERROR - 2021-01-04 08:25:18 --> Severity: Notice --> Undefined variable: p_naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:18 --> Severity: Notice --> Undefined index: naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:18 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 41
ERROR - 2021-01-04 08:25:18 --> Severity: Notice --> Undefined variable: p_naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:18 --> Severity: Notice --> Undefined index: naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:18 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 41
ERROR - 2021-01-04 08:25:18 --> Severity: Notice --> Undefined variable: p_naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:18 --> Severity: Notice --> Undefined index: naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:18 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 41
ERROR - 2021-01-04 08:25:18 --> Severity: Notice --> Undefined variable: p_naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:18 --> Severity: Notice --> Undefined index: naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:18 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 41
ERROR - 2021-01-04 08:25:18 --> Severity: Notice --> Undefined variable: p_naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:18 --> Severity: Notice --> Undefined index: naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:18 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 41
ERROR - 2021-01-04 08:25:18 --> Severity: Notice --> Undefined variable: p_naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:18 --> Severity: Notice --> Undefined index: naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:18 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 41
ERROR - 2021-01-04 08:25:18 --> Severity: Notice --> Undefined variable: p_naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:18 --> Severity: Notice --> Undefined index: naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:18 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 41
ERROR - 2021-01-04 08:25:18 --> Severity: Notice --> Undefined variable: p_naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:18 --> Severity: Notice --> Undefined index: naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:18 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 41
ERROR - 2021-01-04 08:25:18 --> Severity: Notice --> Undefined variable: p_naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:18 --> Severity: Notice --> Undefined index: naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:18 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 41
ERROR - 2021-01-04 08:25:18 --> Severity: Notice --> Undefined variable: p_naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:18 --> Severity: Notice --> Undefined index: naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:18 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 41
ERROR - 2021-01-04 08:25:18 --> Severity: Notice --> Undefined variable: p_naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:18 --> Severity: Notice --> Undefined index: naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:18 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 41
ERROR - 2021-01-04 08:25:18 --> Severity: Notice --> Undefined variable: p_naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:18 --> Severity: Notice --> Undefined index: naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:18 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 41
ERROR - 2021-01-04 08:25:18 --> Severity: Notice --> Undefined variable: p_naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:18 --> Severity: Notice --> Undefined index: naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:19 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 41
ERROR - 2021-01-04 08:25:19 --> Severity: Notice --> Undefined variable: p_naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:19 --> Severity: Notice --> Undefined index: naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:19 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 41
ERROR - 2021-01-04 08:25:19 --> Severity: Notice --> Undefined variable: p_naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:19 --> Severity: Notice --> Undefined index: naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:19 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 41
ERROR - 2021-01-04 08:25:19 --> Severity: Notice --> Undefined variable: p_naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:19 --> Severity: Notice --> Undefined index: naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:19 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 41
ERROR - 2021-01-04 08:25:19 --> Severity: Notice --> Undefined variable: p_naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:19 --> Severity: Notice --> Undefined index: naik C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 37
ERROR - 2021-01-04 08:25:19 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 41
DEBUG - 2021-01-04 08:25:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-01-04 08:25:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-04 08:25:19 --> Final output sent to browser
DEBUG - 2021-01-04 08:25:19 --> Total execution time: 2.4618
INFO - 2021-01-04 08:25:58 --> Config Class Initialized
INFO - 2021-01-04 08:25:58 --> Hooks Class Initialized
DEBUG - 2021-01-04 08:25:58 --> UTF-8 Support Enabled
INFO - 2021-01-04 08:25:58 --> Utf8 Class Initialized
INFO - 2021-01-04 08:25:58 --> URI Class Initialized
INFO - 2021-01-04 08:25:58 --> Router Class Initialized
INFO - 2021-01-04 08:25:58 --> Output Class Initialized
INFO - 2021-01-04 08:25:58 --> Security Class Initialized
DEBUG - 2021-01-04 08:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 08:25:58 --> Input Class Initialized
INFO - 2021-01-04 08:25:58 --> Language Class Initialized
INFO - 2021-01-04 08:25:58 --> Language Class Initialized
INFO - 2021-01-04 08:25:58 --> Config Class Initialized
INFO - 2021-01-04 08:25:58 --> Loader Class Initialized
INFO - 2021-01-04 08:25:58 --> Helper loaded: url_helper
INFO - 2021-01-04 08:25:58 --> Helper loaded: file_helper
INFO - 2021-01-04 08:25:58 --> Helper loaded: form_helper
INFO - 2021-01-04 08:25:58 --> Helper loaded: my_helper
INFO - 2021-01-04 08:25:58 --> Database Driver Class Initialized
DEBUG - 2021-01-04 08:25:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 08:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 08:25:58 --> Controller Class Initialized
ERROR - 2021-01-04 08:25:58 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 35
ERROR - 2021-01-04 08:25:58 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 35
ERROR - 2021-01-04 08:25:58 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 35
ERROR - 2021-01-04 08:25:59 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 35
ERROR - 2021-01-04 08:25:59 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 35
ERROR - 2021-01-04 08:25:59 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 35
ERROR - 2021-01-04 08:25:59 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 35
ERROR - 2021-01-04 08:25:59 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 35
ERROR - 2021-01-04 08:25:59 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 35
ERROR - 2021-01-04 08:25:59 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 35
ERROR - 2021-01-04 08:25:59 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 35
ERROR - 2021-01-04 08:25:59 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 35
ERROR - 2021-01-04 08:25:59 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 35
ERROR - 2021-01-04 08:25:59 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 35
ERROR - 2021-01-04 08:25:59 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 35
ERROR - 2021-01-04 08:25:59 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 35
ERROR - 2021-01-04 08:25:59 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 35
ERROR - 2021-01-04 08:25:59 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 35
ERROR - 2021-01-04 08:25:59 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 35
ERROR - 2021-01-04 08:25:59 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 35
ERROR - 2021-01-04 08:25:59 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 35
ERROR - 2021-01-04 08:25:59 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 35
ERROR - 2021-01-04 08:25:59 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 35
ERROR - 2021-01-04 08:25:59 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 35
ERROR - 2021-01-04 08:25:59 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 35
ERROR - 2021-01-04 08:25:59 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 35
ERROR - 2021-01-04 08:25:59 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 35
ERROR - 2021-01-04 08:25:59 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 35
ERROR - 2021-01-04 08:25:59 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 35
ERROR - 2021-01-04 08:25:59 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 35
ERROR - 2021-01-04 08:25:59 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 35
ERROR - 2021-01-04 08:25:59 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 35
ERROR - 2021-01-04 08:25:59 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 35
ERROR - 2021-01-04 08:25:59 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 35
ERROR - 2021-01-04 08:25:59 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 35
ERROR - 2021-01-04 08:25:59 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 35
ERROR - 2021-01-04 08:25:59 --> Severity: Notice --> Undefined index: catatan_wali C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 35
DEBUG - 2021-01-04 08:25:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-01-04 08:25:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-04 08:25:59 --> Final output sent to browser
DEBUG - 2021-01-04 08:25:59 --> Total execution time: 1.1315
INFO - 2021-01-04 08:26:16 --> Config Class Initialized
INFO - 2021-01-04 08:26:16 --> Hooks Class Initialized
DEBUG - 2021-01-04 08:26:16 --> UTF-8 Support Enabled
INFO - 2021-01-04 08:26:16 --> Utf8 Class Initialized
INFO - 2021-01-04 08:26:16 --> URI Class Initialized
INFO - 2021-01-04 08:26:16 --> Router Class Initialized
INFO - 2021-01-04 08:26:16 --> Output Class Initialized
INFO - 2021-01-04 08:26:16 --> Security Class Initialized
DEBUG - 2021-01-04 08:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 08:26:16 --> Input Class Initialized
INFO - 2021-01-04 08:26:16 --> Language Class Initialized
INFO - 2021-01-04 08:26:16 --> Language Class Initialized
INFO - 2021-01-04 08:26:16 --> Config Class Initialized
INFO - 2021-01-04 08:26:16 --> Loader Class Initialized
INFO - 2021-01-04 08:26:16 --> Helper loaded: url_helper
INFO - 2021-01-04 08:26:16 --> Helper loaded: file_helper
INFO - 2021-01-04 08:26:16 --> Helper loaded: form_helper
INFO - 2021-01-04 08:26:16 --> Helper loaded: my_helper
INFO - 2021-01-04 08:26:16 --> Database Driver Class Initialized
DEBUG - 2021-01-04 08:26:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 08:26:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 08:26:16 --> Controller Class Initialized
DEBUG - 2021-01-04 08:26:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-01-04 08:26:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-04 08:26:16 --> Final output sent to browser
DEBUG - 2021-01-04 08:26:16 --> Total execution time: 0.4128
INFO - 2021-01-04 08:26:35 --> Config Class Initialized
INFO - 2021-01-04 08:26:35 --> Hooks Class Initialized
DEBUG - 2021-01-04 08:26:35 --> UTF-8 Support Enabled
INFO - 2021-01-04 08:26:35 --> Utf8 Class Initialized
INFO - 2021-01-04 08:26:35 --> URI Class Initialized
INFO - 2021-01-04 08:26:35 --> Router Class Initialized
INFO - 2021-01-04 08:26:35 --> Output Class Initialized
INFO - 2021-01-04 08:26:35 --> Security Class Initialized
DEBUG - 2021-01-04 08:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 08:26:35 --> Input Class Initialized
INFO - 2021-01-04 08:26:35 --> Language Class Initialized
INFO - 2021-01-04 08:26:35 --> Language Class Initialized
INFO - 2021-01-04 08:26:35 --> Config Class Initialized
INFO - 2021-01-04 08:26:35 --> Loader Class Initialized
INFO - 2021-01-04 08:26:35 --> Helper loaded: url_helper
INFO - 2021-01-04 08:26:35 --> Helper loaded: file_helper
INFO - 2021-01-04 08:26:35 --> Helper loaded: form_helper
INFO - 2021-01-04 08:26:35 --> Helper loaded: my_helper
INFO - 2021-01-04 08:26:35 --> Database Driver Class Initialized
DEBUG - 2021-01-04 08:26:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 08:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 08:26:35 --> Controller Class Initialized
ERROR - 2021-01-04 08:26:35 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 102
INFO - 2021-01-04 08:26:42 --> Config Class Initialized
INFO - 2021-01-04 08:26:42 --> Hooks Class Initialized
DEBUG - 2021-01-04 08:26:42 --> UTF-8 Support Enabled
INFO - 2021-01-04 08:26:42 --> Utf8 Class Initialized
INFO - 2021-01-04 08:26:42 --> URI Class Initialized
INFO - 2021-01-04 08:26:42 --> Router Class Initialized
INFO - 2021-01-04 08:26:42 --> Output Class Initialized
INFO - 2021-01-04 08:26:42 --> Security Class Initialized
DEBUG - 2021-01-04 08:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 08:26:42 --> Input Class Initialized
INFO - 2021-01-04 08:26:42 --> Language Class Initialized
INFO - 2021-01-04 08:26:42 --> Language Class Initialized
INFO - 2021-01-04 08:26:42 --> Config Class Initialized
INFO - 2021-01-04 08:26:42 --> Loader Class Initialized
INFO - 2021-01-04 08:26:42 --> Helper loaded: url_helper
INFO - 2021-01-04 08:26:42 --> Helper loaded: file_helper
INFO - 2021-01-04 08:26:42 --> Helper loaded: form_helper
INFO - 2021-01-04 08:26:42 --> Helper loaded: my_helper
INFO - 2021-01-04 08:26:42 --> Database Driver Class Initialized
DEBUG - 2021-01-04 08:26:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 08:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 08:26:42 --> Controller Class Initialized
ERROR - 2021-01-04 08:26:42 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 102
INFO - 2021-01-04 08:28:09 --> Config Class Initialized
INFO - 2021-01-04 08:28:09 --> Hooks Class Initialized
DEBUG - 2021-01-04 08:28:09 --> UTF-8 Support Enabled
INFO - 2021-01-04 08:28:09 --> Utf8 Class Initialized
INFO - 2021-01-04 08:28:09 --> URI Class Initialized
INFO - 2021-01-04 08:28:09 --> Router Class Initialized
INFO - 2021-01-04 08:28:09 --> Output Class Initialized
INFO - 2021-01-04 08:28:09 --> Security Class Initialized
DEBUG - 2021-01-04 08:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 08:28:09 --> Input Class Initialized
INFO - 2021-01-04 08:28:09 --> Language Class Initialized
INFO - 2021-01-04 08:28:09 --> Language Class Initialized
INFO - 2021-01-04 08:28:09 --> Config Class Initialized
INFO - 2021-01-04 08:28:09 --> Loader Class Initialized
INFO - 2021-01-04 08:28:09 --> Helper loaded: url_helper
INFO - 2021-01-04 08:28:09 --> Helper loaded: file_helper
INFO - 2021-01-04 08:28:09 --> Helper loaded: form_helper
INFO - 2021-01-04 08:28:09 --> Helper loaded: my_helper
INFO - 2021-01-04 08:28:09 --> Database Driver Class Initialized
DEBUG - 2021-01-04 08:28:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 08:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 08:28:09 --> Controller Class Initialized
DEBUG - 2021-01-04 08:28:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-01-04 08:28:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-04 08:28:09 --> Final output sent to browser
DEBUG - 2021-01-04 08:28:10 --> Total execution time: 0.5146
INFO - 2021-01-04 08:28:35 --> Config Class Initialized
INFO - 2021-01-04 08:28:35 --> Hooks Class Initialized
DEBUG - 2021-01-04 08:28:35 --> UTF-8 Support Enabled
INFO - 2021-01-04 08:28:35 --> Utf8 Class Initialized
INFO - 2021-01-04 08:28:35 --> URI Class Initialized
INFO - 2021-01-04 08:28:35 --> Router Class Initialized
INFO - 2021-01-04 08:28:35 --> Output Class Initialized
INFO - 2021-01-04 08:28:35 --> Security Class Initialized
DEBUG - 2021-01-04 08:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 08:28:35 --> Input Class Initialized
INFO - 2021-01-04 08:28:35 --> Language Class Initialized
INFO - 2021-01-04 08:28:35 --> Language Class Initialized
INFO - 2021-01-04 08:28:35 --> Config Class Initialized
INFO - 2021-01-04 08:28:35 --> Loader Class Initialized
INFO - 2021-01-04 08:28:35 --> Helper loaded: url_helper
INFO - 2021-01-04 08:28:35 --> Helper loaded: file_helper
INFO - 2021-01-04 08:28:35 --> Helper loaded: form_helper
INFO - 2021-01-04 08:28:35 --> Helper loaded: my_helper
INFO - 2021-01-04 08:28:35 --> Database Driver Class Initialized
DEBUG - 2021-01-04 08:28:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 08:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 08:28:35 --> Controller Class Initialized
DEBUG - 2021-01-04 08:28:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-01-04 08:28:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-04 08:28:35 --> Final output sent to browser
DEBUG - 2021-01-04 08:28:35 --> Total execution time: 0.5054
INFO - 2021-01-04 08:33:07 --> Config Class Initialized
INFO - 2021-01-04 08:33:07 --> Hooks Class Initialized
DEBUG - 2021-01-04 08:33:07 --> UTF-8 Support Enabled
INFO - 2021-01-04 08:33:07 --> Utf8 Class Initialized
INFO - 2021-01-04 08:33:07 --> URI Class Initialized
INFO - 2021-01-04 08:33:07 --> Router Class Initialized
INFO - 2021-01-04 08:33:07 --> Output Class Initialized
INFO - 2021-01-04 08:33:07 --> Security Class Initialized
DEBUG - 2021-01-04 08:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 08:33:07 --> Input Class Initialized
INFO - 2021-01-04 08:33:07 --> Language Class Initialized
INFO - 2021-01-04 08:33:07 --> Language Class Initialized
INFO - 2021-01-04 08:33:07 --> Config Class Initialized
INFO - 2021-01-04 08:33:07 --> Loader Class Initialized
INFO - 2021-01-04 08:33:07 --> Helper loaded: url_helper
INFO - 2021-01-04 08:33:07 --> Helper loaded: file_helper
INFO - 2021-01-04 08:33:07 --> Helper loaded: form_helper
INFO - 2021-01-04 08:33:07 --> Helper loaded: my_helper
INFO - 2021-01-04 08:33:07 --> Database Driver Class Initialized
DEBUG - 2021-01-04 08:33:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 08:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 08:33:07 --> Controller Class Initialized
DEBUG - 2021-01-04 08:33:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-01-04 08:33:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-04 08:33:08 --> Final output sent to browser
DEBUG - 2021-01-04 08:33:08 --> Total execution time: 0.4226
INFO - 2021-01-04 08:33:30 --> Config Class Initialized
INFO - 2021-01-04 08:33:30 --> Hooks Class Initialized
DEBUG - 2021-01-04 08:33:30 --> UTF-8 Support Enabled
INFO - 2021-01-04 08:33:30 --> Utf8 Class Initialized
INFO - 2021-01-04 08:33:30 --> URI Class Initialized
INFO - 2021-01-04 08:33:30 --> Router Class Initialized
INFO - 2021-01-04 08:33:30 --> Output Class Initialized
INFO - 2021-01-04 08:33:30 --> Security Class Initialized
DEBUG - 2021-01-04 08:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 08:33:30 --> Input Class Initialized
INFO - 2021-01-04 08:33:30 --> Language Class Initialized
INFO - 2021-01-04 08:33:30 --> Language Class Initialized
INFO - 2021-01-04 08:33:31 --> Config Class Initialized
INFO - 2021-01-04 08:33:31 --> Loader Class Initialized
INFO - 2021-01-04 08:33:31 --> Helper loaded: url_helper
INFO - 2021-01-04 08:33:31 --> Helper loaded: file_helper
INFO - 2021-01-04 08:33:31 --> Helper loaded: form_helper
INFO - 2021-01-04 08:33:31 --> Helper loaded: my_helper
INFO - 2021-01-04 08:33:31 --> Database Driver Class Initialized
DEBUG - 2021-01-04 08:33:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 08:33:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 08:33:31 --> Controller Class Initialized
DEBUG - 2021-01-04 08:33:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-01-04 08:33:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-04 08:33:31 --> Final output sent to browser
DEBUG - 2021-01-04 08:33:31 --> Total execution time: 0.4152
INFO - 2021-01-04 08:34:25 --> Config Class Initialized
INFO - 2021-01-04 08:34:25 --> Hooks Class Initialized
DEBUG - 2021-01-04 08:34:25 --> UTF-8 Support Enabled
INFO - 2021-01-04 08:34:25 --> Utf8 Class Initialized
INFO - 2021-01-04 08:34:25 --> URI Class Initialized
INFO - 2021-01-04 08:34:25 --> Router Class Initialized
INFO - 2021-01-04 08:34:25 --> Output Class Initialized
INFO - 2021-01-04 08:34:25 --> Security Class Initialized
DEBUG - 2021-01-04 08:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 08:34:25 --> Input Class Initialized
INFO - 2021-01-04 08:34:25 --> Language Class Initialized
INFO - 2021-01-04 08:34:25 --> Language Class Initialized
INFO - 2021-01-04 08:34:25 --> Config Class Initialized
INFO - 2021-01-04 08:34:25 --> Loader Class Initialized
INFO - 2021-01-04 08:34:25 --> Helper loaded: url_helper
INFO - 2021-01-04 08:34:25 --> Helper loaded: file_helper
INFO - 2021-01-04 08:34:25 --> Helper loaded: form_helper
INFO - 2021-01-04 08:34:25 --> Helper loaded: my_helper
INFO - 2021-01-04 08:34:25 --> Database Driver Class Initialized
DEBUG - 2021-01-04 08:34:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 08:34:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 08:34:25 --> Controller Class Initialized
DEBUG - 2021-01-04 08:34:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-01-04 08:34:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-04 08:34:25 --> Final output sent to browser
DEBUG - 2021-01-04 08:34:25 --> Total execution time: 0.5005
INFO - 2021-01-04 08:34:27 --> Config Class Initialized
INFO - 2021-01-04 08:34:27 --> Hooks Class Initialized
DEBUG - 2021-01-04 08:34:27 --> UTF-8 Support Enabled
INFO - 2021-01-04 08:34:27 --> Utf8 Class Initialized
INFO - 2021-01-04 08:34:27 --> URI Class Initialized
INFO - 2021-01-04 08:34:27 --> Router Class Initialized
INFO - 2021-01-04 08:34:28 --> Output Class Initialized
INFO - 2021-01-04 08:34:28 --> Security Class Initialized
DEBUG - 2021-01-04 08:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 08:34:28 --> Input Class Initialized
INFO - 2021-01-04 08:34:28 --> Language Class Initialized
INFO - 2021-01-04 08:34:28 --> Language Class Initialized
INFO - 2021-01-04 08:34:28 --> Config Class Initialized
INFO - 2021-01-04 08:34:28 --> Loader Class Initialized
INFO - 2021-01-04 08:34:28 --> Helper loaded: url_helper
INFO - 2021-01-04 08:34:28 --> Helper loaded: file_helper
INFO - 2021-01-04 08:34:28 --> Helper loaded: form_helper
INFO - 2021-01-04 08:34:28 --> Helper loaded: my_helper
INFO - 2021-01-04 08:34:28 --> Database Driver Class Initialized
DEBUG - 2021-01-04 08:34:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 08:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 08:34:28 --> Controller Class Initialized
DEBUG - 2021-01-04 08:34:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_catatan/views/list.php
DEBUG - 2021-01-04 08:34:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-04 08:34:28 --> Final output sent to browser
DEBUG - 2021-01-04 08:34:28 --> Total execution time: 0.5461
INFO - 2021-01-04 08:34:30 --> Config Class Initialized
INFO - 2021-01-04 08:34:30 --> Hooks Class Initialized
DEBUG - 2021-01-04 08:34:30 --> UTF-8 Support Enabled
INFO - 2021-01-04 08:34:30 --> Utf8 Class Initialized
INFO - 2021-01-04 08:34:30 --> URI Class Initialized
INFO - 2021-01-04 08:34:30 --> Router Class Initialized
INFO - 2021-01-04 08:34:30 --> Output Class Initialized
INFO - 2021-01-04 08:34:30 --> Security Class Initialized
DEBUG - 2021-01-04 08:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 08:34:30 --> Input Class Initialized
INFO - 2021-01-04 08:34:30 --> Language Class Initialized
INFO - 2021-01-04 08:34:30 --> Language Class Initialized
INFO - 2021-01-04 08:34:30 --> Config Class Initialized
INFO - 2021-01-04 08:34:30 --> Loader Class Initialized
INFO - 2021-01-04 08:34:30 --> Helper loaded: url_helper
INFO - 2021-01-04 08:34:30 --> Helper loaded: file_helper
INFO - 2021-01-04 08:34:30 --> Helper loaded: form_helper
INFO - 2021-01-04 08:34:30 --> Helper loaded: my_helper
INFO - 2021-01-04 08:34:30 --> Database Driver Class Initialized
DEBUG - 2021-01-04 08:34:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 08:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 08:34:30 --> Controller Class Initialized
DEBUG - 2021-01-04 08:34:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-01-04 08:34:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-04 08:34:30 --> Final output sent to browser
DEBUG - 2021-01-04 08:34:30 --> Total execution time: 0.4314
INFO - 2021-01-04 08:34:33 --> Config Class Initialized
INFO - 2021-01-04 08:34:33 --> Hooks Class Initialized
DEBUG - 2021-01-04 08:34:33 --> UTF-8 Support Enabled
INFO - 2021-01-04 08:34:33 --> Utf8 Class Initialized
INFO - 2021-01-04 08:34:33 --> URI Class Initialized
INFO - 2021-01-04 08:34:33 --> Router Class Initialized
INFO - 2021-01-04 08:34:33 --> Output Class Initialized
INFO - 2021-01-04 08:34:33 --> Security Class Initialized
DEBUG - 2021-01-04 08:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 08:34:33 --> Input Class Initialized
INFO - 2021-01-04 08:34:33 --> Language Class Initialized
INFO - 2021-01-04 08:34:33 --> Language Class Initialized
INFO - 2021-01-04 08:34:33 --> Config Class Initialized
INFO - 2021-01-04 08:34:33 --> Loader Class Initialized
INFO - 2021-01-04 08:34:33 --> Helper loaded: url_helper
INFO - 2021-01-04 08:34:33 --> Helper loaded: file_helper
INFO - 2021-01-04 08:34:33 --> Helper loaded: form_helper
INFO - 2021-01-04 08:34:33 --> Helper loaded: my_helper
INFO - 2021-01-04 08:34:33 --> Database Driver Class Initialized
DEBUG - 2021-01-04 08:34:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 08:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 08:34:33 --> Controller Class Initialized
DEBUG - 2021-01-04 08:34:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_catatan/views/list.php
DEBUG - 2021-01-04 08:34:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-04 08:34:33 --> Final output sent to browser
DEBUG - 2021-01-04 08:34:33 --> Total execution time: 0.4498
INFO - 2021-01-04 08:34:36 --> Config Class Initialized
INFO - 2021-01-04 08:34:36 --> Hooks Class Initialized
DEBUG - 2021-01-04 08:34:36 --> UTF-8 Support Enabled
INFO - 2021-01-04 08:34:36 --> Utf8 Class Initialized
INFO - 2021-01-04 08:34:36 --> URI Class Initialized
INFO - 2021-01-04 08:34:36 --> Router Class Initialized
INFO - 2021-01-04 08:34:36 --> Output Class Initialized
INFO - 2021-01-04 08:34:36 --> Security Class Initialized
DEBUG - 2021-01-04 08:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 08:34:36 --> Input Class Initialized
INFO - 2021-01-04 08:34:36 --> Language Class Initialized
INFO - 2021-01-04 08:34:36 --> Language Class Initialized
INFO - 2021-01-04 08:34:36 --> Config Class Initialized
INFO - 2021-01-04 08:34:36 --> Loader Class Initialized
INFO - 2021-01-04 08:34:36 --> Helper loaded: url_helper
INFO - 2021-01-04 08:34:36 --> Helper loaded: file_helper
INFO - 2021-01-04 08:34:36 --> Helper loaded: form_helper
INFO - 2021-01-04 08:34:36 --> Helper loaded: my_helper
INFO - 2021-01-04 08:34:36 --> Database Driver Class Initialized
DEBUG - 2021-01-04 08:34:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 08:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 08:34:36 --> Controller Class Initialized
DEBUG - 2021-01-04 08:34:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-01-04 08:34:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-04 08:34:36 --> Final output sent to browser
DEBUG - 2021-01-04 08:34:36 --> Total execution time: 0.4569
INFO - 2021-01-04 08:34:59 --> Config Class Initialized
INFO - 2021-01-04 08:34:59 --> Hooks Class Initialized
DEBUG - 2021-01-04 08:34:59 --> UTF-8 Support Enabled
INFO - 2021-01-04 08:34:59 --> Utf8 Class Initialized
INFO - 2021-01-04 08:34:59 --> URI Class Initialized
INFO - 2021-01-04 08:34:59 --> Router Class Initialized
INFO - 2021-01-04 08:34:59 --> Output Class Initialized
INFO - 2021-01-04 08:34:59 --> Security Class Initialized
DEBUG - 2021-01-04 08:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 08:34:59 --> Input Class Initialized
INFO - 2021-01-04 08:34:59 --> Language Class Initialized
INFO - 2021-01-04 08:34:59 --> Language Class Initialized
INFO - 2021-01-04 08:34:59 --> Config Class Initialized
INFO - 2021-01-04 08:34:59 --> Loader Class Initialized
INFO - 2021-01-04 08:34:59 --> Helper loaded: url_helper
INFO - 2021-01-04 08:34:59 --> Helper loaded: file_helper
INFO - 2021-01-04 08:34:59 --> Helper loaded: form_helper
INFO - 2021-01-04 08:34:59 --> Helper loaded: my_helper
INFO - 2021-01-04 08:34:59 --> Database Driver Class Initialized
DEBUG - 2021-01-04 08:34:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 08:34:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 08:34:59 --> Controller Class Initialized
ERROR - 2021-01-04 08:34:59 --> Severity: Notice --> Undefined index: naik_1 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:34:59 --> Severity: Notice --> Undefined index: catatan_1 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:34:59 --> Severity: Notice --> Undefined index: naik_2 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:34:59 --> Severity: Notice --> Undefined index: catatan_2 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:34:59 --> Severity: Notice --> Undefined index: naik_3 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:34:59 --> Severity: Notice --> Undefined index: catatan_3 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:34:59 --> Severity: Notice --> Undefined index: naik_4 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:34:59 --> Severity: Notice --> Undefined index: catatan_4 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:34:59 --> Severity: Notice --> Undefined index: naik_5 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:34:59 --> Severity: Notice --> Undefined index: catatan_5 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:34:59 --> Severity: Notice --> Undefined index: naik_6 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:34:59 --> Severity: Notice --> Undefined index: catatan_6 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:34:59 --> Severity: Notice --> Undefined index: naik_7 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:34:59 --> Severity: Notice --> Undefined index: catatan_7 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:34:59 --> Severity: Notice --> Undefined index: naik_8 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:34:59 --> Severity: Notice --> Undefined index: catatan_8 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:34:59 --> Severity: Notice --> Undefined index: naik_9 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:34:59 --> Severity: Notice --> Undefined index: catatan_9 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:34:59 --> Severity: Notice --> Undefined index: naik_10 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:34:59 --> Severity: Notice --> Undefined index: catatan_10 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:34:59 --> Severity: Notice --> Undefined index: naik_11 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:34:59 --> Severity: Notice --> Undefined index: catatan_11 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:34:59 --> Severity: Notice --> Undefined index: naik_12 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:34:59 --> Severity: Notice --> Undefined index: catatan_12 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:34:59 --> Severity: Notice --> Undefined index: naik_13 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:34:59 --> Severity: Notice --> Undefined index: catatan_13 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:34:59 --> Severity: Notice --> Undefined index: naik_14 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:35:00 --> Severity: Notice --> Undefined index: catatan_14 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:35:00 --> Severity: Notice --> Undefined index: naik_15 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:35:00 --> Severity: Notice --> Undefined index: catatan_15 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:35:00 --> Severity: Notice --> Undefined index: naik_16 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:35:00 --> Severity: Notice --> Undefined index: catatan_16 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:35:00 --> Severity: Notice --> Undefined index: naik_17 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:35:00 --> Severity: Notice --> Undefined index: catatan_17 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:35:00 --> Severity: Notice --> Undefined index: naik_18 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:35:00 --> Severity: Notice --> Undefined index: catatan_18 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:35:00 --> Severity: Notice --> Undefined index: naik_19 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:35:00 --> Severity: Notice --> Undefined index: catatan_19 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:35:00 --> Severity: Notice --> Undefined index: naik_20 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:35:00 --> Severity: Notice --> Undefined index: catatan_20 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:35:00 --> Severity: Notice --> Undefined index: naik_21 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:35:00 --> Severity: Notice --> Undefined index: catatan_21 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:35:00 --> Severity: Notice --> Undefined index: naik_22 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:35:00 --> Severity: Notice --> Undefined index: catatan_22 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:35:00 --> Severity: Notice --> Undefined index: naik_23 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:35:00 --> Severity: Notice --> Undefined index: catatan_23 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:35:00 --> Severity: Notice --> Undefined index: naik_24 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:35:00 --> Severity: Notice --> Undefined index: catatan_24 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:35:00 --> Severity: Notice --> Undefined index: naik_25 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:35:00 --> Severity: Notice --> Undefined index: catatan_25 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:35:00 --> Severity: Notice --> Undefined index: naik_26 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:35:00 --> Severity: Notice --> Undefined index: catatan_26 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:35:00 --> Severity: Notice --> Undefined index: naik_27 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:35:00 --> Severity: Notice --> Undefined index: catatan_27 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:35:00 --> Severity: Notice --> Undefined index: naik_28 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:35:00 --> Severity: Notice --> Undefined index: catatan_28 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:35:00 --> Severity: Notice --> Undefined index: naik_29 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:35:00 --> Severity: Notice --> Undefined index: catatan_29 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:35:00 --> Severity: Notice --> Undefined index: naik_30 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:35:00 --> Severity: Notice --> Undefined index: catatan_30 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:35:00 --> Severity: Notice --> Undefined index: naik_31 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:35:00 --> Severity: Notice --> Undefined index: catatan_31 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:35:00 --> Severity: Notice --> Undefined index: naik_32 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:35:00 --> Severity: Notice --> Undefined index: catatan_32 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:35:00 --> Severity: Notice --> Undefined index: naik_33 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:35:00 --> Severity: Notice --> Undefined index: catatan_33 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:35:00 --> Severity: Notice --> Undefined index: naik_34 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:35:00 --> Severity: Notice --> Undefined index: catatan_34 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:35:00 --> Severity: Notice --> Undefined index: naik_35 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:35:00 --> Severity: Notice --> Undefined index: catatan_35 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:35:00 --> Severity: Notice --> Undefined index: naik_36 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:35:00 --> Severity: Notice --> Undefined index: catatan_36 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:35:00 --> Severity: Notice --> Undefined index: naik_37 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:35:00 --> Severity: Notice --> Undefined index: catatan_37 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:35:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\nilai\system\core\Exceptions.php:272) C:\xampp\htdocs\nilai\application\helpers\my_helper.php 120
INFO - 2021-01-04 08:35:00 --> Final output sent to browser
DEBUG - 2021-01-04 08:35:00 --> Total execution time: 1.7523
INFO - 2021-01-04 08:35:48 --> Config Class Initialized
INFO - 2021-01-04 08:35:48 --> Hooks Class Initialized
DEBUG - 2021-01-04 08:35:48 --> UTF-8 Support Enabled
INFO - 2021-01-04 08:35:48 --> Utf8 Class Initialized
INFO - 2021-01-04 08:35:48 --> URI Class Initialized
INFO - 2021-01-04 08:35:48 --> Router Class Initialized
INFO - 2021-01-04 08:35:48 --> Output Class Initialized
INFO - 2021-01-04 08:35:48 --> Security Class Initialized
DEBUG - 2021-01-04 08:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 08:35:48 --> Input Class Initialized
INFO - 2021-01-04 08:35:48 --> Language Class Initialized
INFO - 2021-01-04 08:35:48 --> Language Class Initialized
INFO - 2021-01-04 08:35:48 --> Config Class Initialized
INFO - 2021-01-04 08:35:48 --> Loader Class Initialized
INFO - 2021-01-04 08:35:48 --> Helper loaded: url_helper
INFO - 2021-01-04 08:35:48 --> Helper loaded: file_helper
INFO - 2021-01-04 08:35:48 --> Helper loaded: form_helper
INFO - 2021-01-04 08:35:48 --> Helper loaded: my_helper
INFO - 2021-01-04 08:35:48 --> Database Driver Class Initialized
DEBUG - 2021-01-04 08:35:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 08:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 08:35:48 --> Controller Class Initialized
DEBUG - 2021-01-04 08:35:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-01-04 08:35:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-04 08:35:48 --> Final output sent to browser
DEBUG - 2021-01-04 08:35:48 --> Total execution time: 0.5292
INFO - 2021-01-04 08:35:52 --> Config Class Initialized
INFO - 2021-01-04 08:35:52 --> Hooks Class Initialized
DEBUG - 2021-01-04 08:35:52 --> UTF-8 Support Enabled
INFO - 2021-01-04 08:35:52 --> Utf8 Class Initialized
INFO - 2021-01-04 08:35:52 --> URI Class Initialized
INFO - 2021-01-04 08:35:52 --> Router Class Initialized
INFO - 2021-01-04 08:35:52 --> Output Class Initialized
INFO - 2021-01-04 08:35:53 --> Security Class Initialized
DEBUG - 2021-01-04 08:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 08:35:53 --> Input Class Initialized
INFO - 2021-01-04 08:35:53 --> Language Class Initialized
INFO - 2021-01-04 08:35:53 --> Language Class Initialized
INFO - 2021-01-04 08:35:53 --> Config Class Initialized
INFO - 2021-01-04 08:35:53 --> Loader Class Initialized
INFO - 2021-01-04 08:35:53 --> Helper loaded: url_helper
INFO - 2021-01-04 08:35:53 --> Helper loaded: file_helper
INFO - 2021-01-04 08:35:53 --> Helper loaded: form_helper
INFO - 2021-01-04 08:35:53 --> Helper loaded: my_helper
INFO - 2021-01-04 08:35:53 --> Database Driver Class Initialized
DEBUG - 2021-01-04 08:35:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 08:35:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 08:35:53 --> Controller Class Initialized
ERROR - 2021-01-04 08:35:53 --> Severity: Notice --> Undefined index: naik_1 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:35:53 --> Severity: Notice --> Undefined index: catatan_1 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:35:53 --> Severity: Notice --> Undefined index: naik_2 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:35:53 --> Severity: Notice --> Undefined index: catatan_2 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:35:53 --> Severity: Notice --> Undefined index: naik_3 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:35:53 --> Severity: Notice --> Undefined index: catatan_3 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:35:53 --> Severity: Notice --> Undefined index: naik_4 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:35:53 --> Severity: Notice --> Undefined index: catatan_4 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:35:53 --> Severity: Notice --> Undefined index: naik_5 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:35:53 --> Severity: Notice --> Undefined index: catatan_5 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:35:53 --> Severity: Notice --> Undefined index: naik_6 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:35:53 --> Severity: Notice --> Undefined index: catatan_6 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:35:53 --> Severity: Notice --> Undefined index: naik_7 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:35:53 --> Severity: Notice --> Undefined index: catatan_7 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:35:53 --> Severity: Notice --> Undefined index: naik_8 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:35:53 --> Severity: Notice --> Undefined index: catatan_8 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:35:53 --> Severity: Notice --> Undefined index: naik_9 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:35:53 --> Severity: Notice --> Undefined index: catatan_9 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:35:53 --> Severity: Notice --> Undefined index: naik_10 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:35:53 --> Severity: Notice --> Undefined index: catatan_10 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:35:53 --> Severity: Notice --> Undefined index: naik_11 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:35:53 --> Severity: Notice --> Undefined index: catatan_11 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:35:53 --> Severity: Notice --> Undefined index: naik_12 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:35:53 --> Severity: Notice --> Undefined index: catatan_12 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:35:53 --> Severity: Notice --> Undefined index: naik_13 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:35:53 --> Severity: Notice --> Undefined index: catatan_13 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:35:53 --> Severity: Notice --> Undefined index: naik_14 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:35:53 --> Severity: Notice --> Undefined index: catatan_14 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:35:53 --> Severity: Notice --> Undefined index: naik_15 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:35:53 --> Severity: Notice --> Undefined index: catatan_15 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:35:53 --> Severity: Notice --> Undefined index: naik_16 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:35:53 --> Severity: Notice --> Undefined index: catatan_16 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:35:53 --> Severity: Notice --> Undefined index: naik_17 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:35:53 --> Severity: Notice --> Undefined index: catatan_17 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:35:53 --> Severity: Notice --> Undefined index: naik_18 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:35:53 --> Severity: Notice --> Undefined index: catatan_18 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:35:53 --> Severity: Notice --> Undefined index: naik_19 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:35:53 --> Severity: Notice --> Undefined index: catatan_19 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:35:53 --> Severity: Notice --> Undefined index: naik_20 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:35:53 --> Severity: Notice --> Undefined index: catatan_20 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:35:54 --> Severity: Notice --> Undefined index: naik_21 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:35:54 --> Severity: Notice --> Undefined index: catatan_21 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:35:54 --> Severity: Notice --> Undefined index: naik_22 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:35:54 --> Severity: Notice --> Undefined index: catatan_22 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:35:54 --> Severity: Notice --> Undefined index: naik_23 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:35:54 --> Severity: Notice --> Undefined index: catatan_23 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:35:54 --> Severity: Notice --> Undefined index: naik_24 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:35:54 --> Severity: Notice --> Undefined index: catatan_24 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:35:54 --> Severity: Notice --> Undefined index: naik_25 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:35:54 --> Severity: Notice --> Undefined index: catatan_25 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:35:54 --> Severity: Notice --> Undefined index: naik_26 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:35:54 --> Severity: Notice --> Undefined index: catatan_26 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:35:54 --> Severity: Notice --> Undefined index: naik_27 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:35:54 --> Severity: Notice --> Undefined index: catatan_27 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:35:54 --> Severity: Notice --> Undefined index: naik_28 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:35:54 --> Severity: Notice --> Undefined index: catatan_28 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:35:54 --> Severity: Notice --> Undefined index: naik_29 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:35:54 --> Severity: Notice --> Undefined index: catatan_29 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:35:54 --> Severity: Notice --> Undefined index: naik_30 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:35:54 --> Severity: Notice --> Undefined index: catatan_30 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:35:54 --> Severity: Notice --> Undefined index: naik_31 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:35:54 --> Severity: Notice --> Undefined index: catatan_31 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:35:54 --> Severity: Notice --> Undefined index: naik_32 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:35:54 --> Severity: Notice --> Undefined index: catatan_32 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:35:54 --> Severity: Notice --> Undefined index: naik_33 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:35:54 --> Severity: Notice --> Undefined index: catatan_33 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:35:54 --> Severity: Notice --> Undefined index: naik_34 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:35:54 --> Severity: Notice --> Undefined index: catatan_34 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:35:54 --> Severity: Notice --> Undefined index: naik_35 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:35:54 --> Severity: Notice --> Undefined index: catatan_35 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:35:54 --> Severity: Notice --> Undefined index: naik_36 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:35:54 --> Severity: Notice --> Undefined index: catatan_36 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:35:54 --> Severity: Notice --> Undefined index: naik_37 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:35:54 --> Severity: Notice --> Undefined index: catatan_37 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:35:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\nilai\system\core\Exceptions.php:272) C:\xampp\htdocs\nilai\application\helpers\my_helper.php 120
INFO - 2021-01-04 08:35:54 --> Final output sent to browser
DEBUG - 2021-01-04 08:35:54 --> Total execution time: 1.7826
INFO - 2021-01-04 08:37:22 --> Config Class Initialized
INFO - 2021-01-04 08:37:22 --> Hooks Class Initialized
DEBUG - 2021-01-04 08:37:22 --> UTF-8 Support Enabled
INFO - 2021-01-04 08:37:22 --> Utf8 Class Initialized
INFO - 2021-01-04 08:37:22 --> URI Class Initialized
INFO - 2021-01-04 08:37:22 --> Router Class Initialized
INFO - 2021-01-04 08:37:22 --> Output Class Initialized
INFO - 2021-01-04 08:37:22 --> Security Class Initialized
DEBUG - 2021-01-04 08:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 08:37:22 --> Input Class Initialized
INFO - 2021-01-04 08:37:22 --> Language Class Initialized
INFO - 2021-01-04 08:37:22 --> Language Class Initialized
INFO - 2021-01-04 08:37:22 --> Config Class Initialized
INFO - 2021-01-04 08:37:22 --> Loader Class Initialized
INFO - 2021-01-04 08:37:22 --> Helper loaded: url_helper
INFO - 2021-01-04 08:37:22 --> Helper loaded: file_helper
INFO - 2021-01-04 08:37:22 --> Helper loaded: form_helper
INFO - 2021-01-04 08:37:22 --> Helper loaded: my_helper
INFO - 2021-01-04 08:37:22 --> Database Driver Class Initialized
DEBUG - 2021-01-04 08:37:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 08:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 08:37:22 --> Controller Class Initialized
DEBUG - 2021-01-04 08:37:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-01-04 08:37:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-04 08:37:22 --> Final output sent to browser
DEBUG - 2021-01-04 08:37:22 --> Total execution time: 0.5752
INFO - 2021-01-04 08:37:26 --> Config Class Initialized
INFO - 2021-01-04 08:37:26 --> Hooks Class Initialized
DEBUG - 2021-01-04 08:37:26 --> UTF-8 Support Enabled
INFO - 2021-01-04 08:37:27 --> Utf8 Class Initialized
INFO - 2021-01-04 08:37:27 --> URI Class Initialized
INFO - 2021-01-04 08:37:27 --> Router Class Initialized
INFO - 2021-01-04 08:37:27 --> Output Class Initialized
INFO - 2021-01-04 08:37:27 --> Security Class Initialized
DEBUG - 2021-01-04 08:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 08:37:27 --> Input Class Initialized
INFO - 2021-01-04 08:37:27 --> Language Class Initialized
INFO - 2021-01-04 08:37:27 --> Language Class Initialized
INFO - 2021-01-04 08:37:27 --> Config Class Initialized
INFO - 2021-01-04 08:37:27 --> Loader Class Initialized
INFO - 2021-01-04 08:37:27 --> Helper loaded: url_helper
INFO - 2021-01-04 08:37:27 --> Helper loaded: file_helper
INFO - 2021-01-04 08:37:27 --> Helper loaded: form_helper
INFO - 2021-01-04 08:37:27 --> Helper loaded: my_helper
INFO - 2021-01-04 08:37:27 --> Database Driver Class Initialized
DEBUG - 2021-01-04 08:37:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 08:37:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 08:37:27 --> Controller Class Initialized
ERROR - 2021-01-04 08:37:27 --> Severity: Notice --> Undefined index: naik_1 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:37:27 --> Severity: Notice --> Undefined index: catatan_1 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:37:27 --> Severity: Notice --> Undefined index: naik_2 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:37:27 --> Severity: Notice --> Undefined index: catatan_2 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:37:27 --> Severity: Notice --> Undefined index: naik_3 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:37:27 --> Severity: Notice --> Undefined index: catatan_3 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:37:27 --> Severity: Notice --> Undefined index: naik_4 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:37:27 --> Severity: Notice --> Undefined index: catatan_4 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:37:27 --> Severity: Notice --> Undefined index: naik_5 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:37:27 --> Severity: Notice --> Undefined index: catatan_5 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:37:27 --> Severity: Notice --> Undefined index: naik_6 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:37:27 --> Severity: Notice --> Undefined index: catatan_6 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:37:27 --> Severity: Notice --> Undefined index: naik_7 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:37:27 --> Severity: Notice --> Undefined index: catatan_7 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:37:27 --> Severity: Notice --> Undefined index: naik_8 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:37:27 --> Severity: Notice --> Undefined index: catatan_8 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:37:27 --> Severity: Notice --> Undefined index: naik_9 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:37:27 --> Severity: Notice --> Undefined index: catatan_9 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:37:27 --> Severity: Notice --> Undefined index: naik_10 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:37:27 --> Severity: Notice --> Undefined index: catatan_10 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:37:27 --> Severity: Notice --> Undefined index: naik_11 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:37:27 --> Severity: Notice --> Undefined index: catatan_11 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:37:27 --> Severity: Notice --> Undefined index: naik_12 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:37:27 --> Severity: Notice --> Undefined index: catatan_12 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:37:27 --> Severity: Notice --> Undefined index: naik_13 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:37:27 --> Severity: Notice --> Undefined index: catatan_13 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:37:27 --> Severity: Notice --> Undefined index: naik_14 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:37:27 --> Severity: Notice --> Undefined index: catatan_14 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:37:27 --> Severity: Notice --> Undefined index: naik_15 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:37:27 --> Severity: Notice --> Undefined index: catatan_15 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:37:27 --> Severity: Notice --> Undefined index: naik_16 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:37:27 --> Severity: Notice --> Undefined index: catatan_16 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:37:27 --> Severity: Notice --> Undefined index: naik_17 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:37:27 --> Severity: Notice --> Undefined index: catatan_17 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:37:27 --> Severity: Notice --> Undefined index: naik_18 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:37:27 --> Severity: Notice --> Undefined index: catatan_18 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:37:27 --> Severity: Notice --> Undefined index: naik_19 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:37:27 --> Severity: Notice --> Undefined index: catatan_19 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:37:27 --> Severity: Notice --> Undefined index: naik_20 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:37:27 --> Severity: Notice --> Undefined index: catatan_20 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:37:27 --> Severity: Notice --> Undefined index: naik_21 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:37:27 --> Severity: Notice --> Undefined index: catatan_21 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:37:28 --> Severity: Notice --> Undefined index: naik_22 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:37:28 --> Severity: Notice --> Undefined index: catatan_22 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:37:28 --> Severity: Notice --> Undefined index: naik_23 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:37:28 --> Severity: Notice --> Undefined index: catatan_23 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:37:28 --> Severity: Notice --> Undefined index: naik_24 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:37:28 --> Severity: Notice --> Undefined index: catatan_24 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:37:28 --> Severity: Notice --> Undefined index: naik_25 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:37:28 --> Severity: Notice --> Undefined index: catatan_25 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:37:28 --> Severity: Notice --> Undefined index: naik_26 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:37:28 --> Severity: Notice --> Undefined index: catatan_26 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:37:28 --> Severity: Notice --> Undefined index: naik_27 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:37:28 --> Severity: Notice --> Undefined index: catatan_27 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:37:28 --> Severity: Notice --> Undefined index: naik_28 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:37:28 --> Severity: Notice --> Undefined index: catatan_28 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:37:28 --> Severity: Notice --> Undefined index: naik_29 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:37:28 --> Severity: Notice --> Undefined index: catatan_29 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:37:28 --> Severity: Notice --> Undefined index: naik_30 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:37:28 --> Severity: Notice --> Undefined index: catatan_30 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:37:28 --> Severity: Notice --> Undefined index: naik_31 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:37:28 --> Severity: Notice --> Undefined index: catatan_31 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:37:28 --> Severity: Notice --> Undefined index: naik_32 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:37:28 --> Severity: Notice --> Undefined index: catatan_32 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:37:28 --> Severity: Notice --> Undefined index: naik_33 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:37:28 --> Severity: Notice --> Undefined index: catatan_33 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:37:28 --> Severity: Notice --> Undefined index: naik_34 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:37:28 --> Severity: Notice --> Undefined index: catatan_34 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:37:28 --> Severity: Notice --> Undefined index: naik_35 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:37:28 --> Severity: Notice --> Undefined index: catatan_35 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:37:28 --> Severity: Notice --> Undefined index: naik_36 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:37:28 --> Severity: Notice --> Undefined index: catatan_36 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:37:28 --> Severity: Notice --> Undefined index: naik_37 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:37:28 --> Severity: Notice --> Undefined index: catatan_37 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:37:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\nilai\system\core\Exceptions.php:272) C:\xampp\htdocs\nilai\application\helpers\my_helper.php 120
INFO - 2021-01-04 08:37:28 --> Final output sent to browser
DEBUG - 2021-01-04 08:37:28 --> Total execution time: 1.5949
INFO - 2021-01-04 08:39:10 --> Config Class Initialized
INFO - 2021-01-04 08:39:10 --> Hooks Class Initialized
DEBUG - 2021-01-04 08:39:10 --> UTF-8 Support Enabled
INFO - 2021-01-04 08:39:10 --> Utf8 Class Initialized
INFO - 2021-01-04 08:39:10 --> URI Class Initialized
INFO - 2021-01-04 08:39:10 --> Router Class Initialized
INFO - 2021-01-04 08:39:10 --> Output Class Initialized
INFO - 2021-01-04 08:39:10 --> Security Class Initialized
DEBUG - 2021-01-04 08:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 08:39:10 --> Input Class Initialized
INFO - 2021-01-04 08:39:10 --> Language Class Initialized
INFO - 2021-01-04 08:39:10 --> Language Class Initialized
INFO - 2021-01-04 08:39:10 --> Config Class Initialized
INFO - 2021-01-04 08:39:10 --> Loader Class Initialized
INFO - 2021-01-04 08:39:10 --> Helper loaded: url_helper
INFO - 2021-01-04 08:39:10 --> Helper loaded: file_helper
INFO - 2021-01-04 08:39:10 --> Helper loaded: form_helper
INFO - 2021-01-04 08:39:10 --> Helper loaded: my_helper
INFO - 2021-01-04 08:39:10 --> Database Driver Class Initialized
DEBUG - 2021-01-04 08:39:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 08:39:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 08:39:10 --> Controller Class Initialized
DEBUG - 2021-01-04 08:39:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-01-04 08:39:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-04 08:39:10 --> Final output sent to browser
DEBUG - 2021-01-04 08:39:10 --> Total execution time: 0.5605
INFO - 2021-01-04 08:39:14 --> Config Class Initialized
INFO - 2021-01-04 08:39:14 --> Hooks Class Initialized
DEBUG - 2021-01-04 08:39:14 --> UTF-8 Support Enabled
INFO - 2021-01-04 08:39:14 --> Utf8 Class Initialized
INFO - 2021-01-04 08:39:14 --> URI Class Initialized
INFO - 2021-01-04 08:39:14 --> Router Class Initialized
INFO - 2021-01-04 08:39:14 --> Output Class Initialized
INFO - 2021-01-04 08:39:14 --> Security Class Initialized
DEBUG - 2021-01-04 08:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 08:39:14 --> Input Class Initialized
INFO - 2021-01-04 08:39:14 --> Language Class Initialized
INFO - 2021-01-04 08:39:14 --> Language Class Initialized
INFO - 2021-01-04 08:39:14 --> Config Class Initialized
INFO - 2021-01-04 08:39:14 --> Loader Class Initialized
INFO - 2021-01-04 08:39:14 --> Helper loaded: url_helper
INFO - 2021-01-04 08:39:14 --> Helper loaded: file_helper
INFO - 2021-01-04 08:39:14 --> Helper loaded: form_helper
INFO - 2021-01-04 08:39:14 --> Helper loaded: my_helper
INFO - 2021-01-04 08:39:14 --> Database Driver Class Initialized
DEBUG - 2021-01-04 08:39:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 08:39:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 08:39:14 --> Controller Class Initialized
ERROR - 2021-01-04 08:39:14 --> Severity: Notice --> Undefined index: naik_1 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:39:14 --> Severity: Notice --> Undefined index: catatan_1 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:39:14 --> Severity: Notice --> Undefined index: naik_2 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:39:14 --> Severity: Notice --> Undefined index: catatan_2 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:39:14 --> Severity: Notice --> Undefined index: naik_3 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:39:14 --> Severity: Notice --> Undefined index: catatan_3 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:39:14 --> Severity: Notice --> Undefined index: naik_4 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:39:14 --> Severity: Notice --> Undefined index: catatan_4 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:39:14 --> Severity: Notice --> Undefined index: naik_5 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:39:14 --> Severity: Notice --> Undefined index: catatan_5 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:39:15 --> Severity: Notice --> Undefined index: naik_6 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:39:15 --> Severity: Notice --> Undefined index: catatan_6 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:39:15 --> Severity: Notice --> Undefined index: naik_7 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:39:15 --> Severity: Notice --> Undefined index: catatan_7 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:39:15 --> Severity: Notice --> Undefined index: naik_8 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:39:15 --> Severity: Notice --> Undefined index: catatan_8 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:39:15 --> Severity: Notice --> Undefined index: naik_9 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:39:15 --> Severity: Notice --> Undefined index: catatan_9 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:39:15 --> Severity: Notice --> Undefined index: naik_10 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:39:15 --> Severity: Notice --> Undefined index: catatan_10 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:39:15 --> Severity: Notice --> Undefined index: naik_11 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:39:15 --> Severity: Notice --> Undefined index: catatan_11 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:39:15 --> Severity: Notice --> Undefined index: naik_12 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:39:15 --> Severity: Notice --> Undefined index: catatan_12 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:39:15 --> Severity: Notice --> Undefined index: naik_13 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:39:15 --> Severity: Notice --> Undefined index: catatan_13 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:39:15 --> Severity: Notice --> Undefined index: naik_14 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:39:15 --> Severity: Notice --> Undefined index: catatan_14 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:39:15 --> Severity: Notice --> Undefined index: naik_15 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:39:15 --> Severity: Notice --> Undefined index: catatan_15 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:39:15 --> Severity: Notice --> Undefined index: naik_16 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:39:15 --> Severity: Notice --> Undefined index: catatan_16 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:39:15 --> Severity: Notice --> Undefined index: naik_17 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:39:15 --> Severity: Notice --> Undefined index: catatan_17 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:39:15 --> Severity: Notice --> Undefined index: naik_18 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:39:15 --> Severity: Notice --> Undefined index: catatan_18 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:39:15 --> Severity: Notice --> Undefined index: naik_19 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:39:15 --> Severity: Notice --> Undefined index: catatan_19 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:39:15 --> Severity: Notice --> Undefined index: naik_20 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:39:15 --> Severity: Notice --> Undefined index: catatan_20 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:39:15 --> Severity: Notice --> Undefined index: naik_21 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:39:15 --> Severity: Notice --> Undefined index: catatan_21 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:39:15 --> Severity: Notice --> Undefined index: naik_22 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:39:15 --> Severity: Notice --> Undefined index: catatan_22 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:39:15 --> Severity: Notice --> Undefined index: naik_23 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:39:15 --> Severity: Notice --> Undefined index: catatan_23 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:39:15 --> Severity: Notice --> Undefined index: naik_24 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:39:15 --> Severity: Notice --> Undefined index: catatan_24 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:39:15 --> Severity: Notice --> Undefined index: naik_25 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:39:15 --> Severity: Notice --> Undefined index: catatan_25 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:39:15 --> Severity: Notice --> Undefined index: naik_26 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:39:15 --> Severity: Notice --> Undefined index: catatan_26 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:39:15 --> Severity: Notice --> Undefined index: naik_27 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:39:15 --> Severity: Notice --> Undefined index: catatan_27 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:39:15 --> Severity: Notice --> Undefined index: naik_28 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:39:15 --> Severity: Notice --> Undefined index: catatan_28 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:39:15 --> Severity: Notice --> Undefined index: naik_29 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:39:15 --> Severity: Notice --> Undefined index: catatan_29 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:39:15 --> Severity: Notice --> Undefined index: naik_30 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:39:15 --> Severity: Notice --> Undefined index: catatan_30 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:39:15 --> Severity: Notice --> Undefined index: naik_31 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:39:15 --> Severity: Notice --> Undefined index: catatan_31 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:39:15 --> Severity: Notice --> Undefined index: naik_32 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:39:15 --> Severity: Notice --> Undefined index: catatan_32 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:39:15 --> Severity: Notice --> Undefined index: naik_33 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:39:15 --> Severity: Notice --> Undefined index: catatan_33 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:39:15 --> Severity: Notice --> Undefined index: naik_34 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:39:15 --> Severity: Notice --> Undefined index: catatan_34 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:39:15 --> Severity: Notice --> Undefined index: naik_35 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:39:15 --> Severity: Notice --> Undefined index: catatan_35 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:39:15 --> Severity: Notice --> Undefined index: naik_36 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:39:15 --> Severity: Notice --> Undefined index: catatan_36 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:39:15 --> Severity: Notice --> Undefined index: naik_37 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:39:16 --> Severity: Notice --> Undefined index: catatan_37 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:39:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\nilai\system\core\Exceptions.php:272) C:\xampp\htdocs\nilai\application\helpers\my_helper.php 120
INFO - 2021-01-04 08:39:16 --> Final output sent to browser
DEBUG - 2021-01-04 08:39:16 --> Total execution time: 1.6872
INFO - 2021-01-04 08:40:36 --> Config Class Initialized
INFO - 2021-01-04 08:40:36 --> Hooks Class Initialized
DEBUG - 2021-01-04 08:40:36 --> UTF-8 Support Enabled
INFO - 2021-01-04 08:40:36 --> Utf8 Class Initialized
INFO - 2021-01-04 08:40:36 --> URI Class Initialized
INFO - 2021-01-04 08:40:36 --> Router Class Initialized
INFO - 2021-01-04 08:40:36 --> Output Class Initialized
INFO - 2021-01-04 08:40:36 --> Security Class Initialized
DEBUG - 2021-01-04 08:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 08:40:36 --> Input Class Initialized
INFO - 2021-01-04 08:40:36 --> Language Class Initialized
INFO - 2021-01-04 08:40:36 --> Language Class Initialized
INFO - 2021-01-04 08:40:36 --> Config Class Initialized
INFO - 2021-01-04 08:40:36 --> Loader Class Initialized
INFO - 2021-01-04 08:40:36 --> Helper loaded: url_helper
INFO - 2021-01-04 08:40:36 --> Helper loaded: file_helper
INFO - 2021-01-04 08:40:36 --> Helper loaded: form_helper
INFO - 2021-01-04 08:40:36 --> Helper loaded: my_helper
INFO - 2021-01-04 08:40:36 --> Database Driver Class Initialized
DEBUG - 2021-01-04 08:40:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 08:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 08:40:36 --> Controller Class Initialized
DEBUG - 2021-01-04 08:40:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-01-04 08:40:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-04 08:40:36 --> Final output sent to browser
DEBUG - 2021-01-04 08:40:36 --> Total execution time: 0.5667
INFO - 2021-01-04 08:40:40 --> Config Class Initialized
INFO - 2021-01-04 08:40:40 --> Hooks Class Initialized
DEBUG - 2021-01-04 08:40:40 --> UTF-8 Support Enabled
INFO - 2021-01-04 08:40:40 --> Utf8 Class Initialized
INFO - 2021-01-04 08:40:40 --> URI Class Initialized
INFO - 2021-01-04 08:40:40 --> Router Class Initialized
INFO - 2021-01-04 08:40:40 --> Output Class Initialized
INFO - 2021-01-04 08:40:40 --> Security Class Initialized
DEBUG - 2021-01-04 08:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 08:40:40 --> Input Class Initialized
INFO - 2021-01-04 08:40:40 --> Language Class Initialized
INFO - 2021-01-04 08:40:40 --> Language Class Initialized
INFO - 2021-01-04 08:40:40 --> Config Class Initialized
INFO - 2021-01-04 08:40:40 --> Loader Class Initialized
INFO - 2021-01-04 08:40:40 --> Helper loaded: url_helper
INFO - 2021-01-04 08:40:40 --> Helper loaded: file_helper
INFO - 2021-01-04 08:40:40 --> Helper loaded: form_helper
INFO - 2021-01-04 08:40:40 --> Helper loaded: my_helper
INFO - 2021-01-04 08:40:40 --> Database Driver Class Initialized
DEBUG - 2021-01-04 08:40:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 08:40:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 08:40:40 --> Controller Class Initialized
ERROR - 2021-01-04 08:40:40 --> Severity: Notice --> Undefined index: naik_1 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:40:40 --> Severity: Notice --> Undefined index: catatan_1 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:40:41 --> Severity: Notice --> Undefined index: naik_2 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:40:41 --> Severity: Notice --> Undefined index: catatan_2 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:40:41 --> Severity: Notice --> Undefined index: naik_3 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:40:41 --> Severity: Notice --> Undefined index: catatan_3 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:40:41 --> Severity: Notice --> Undefined index: naik_4 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:40:41 --> Severity: Notice --> Undefined index: catatan_4 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:40:41 --> Severity: Notice --> Undefined index: naik_5 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:40:41 --> Severity: Notice --> Undefined index: catatan_5 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:40:41 --> Severity: Notice --> Undefined index: naik_6 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:40:41 --> Severity: Notice --> Undefined index: catatan_6 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:40:41 --> Severity: Notice --> Undefined index: naik_7 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:40:41 --> Severity: Notice --> Undefined index: catatan_7 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:40:41 --> Severity: Notice --> Undefined index: naik_8 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:40:41 --> Severity: Notice --> Undefined index: catatan_8 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:40:41 --> Severity: Notice --> Undefined index: naik_9 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:40:41 --> Severity: Notice --> Undefined index: catatan_9 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:40:41 --> Severity: Notice --> Undefined index: naik_10 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:40:41 --> Severity: Notice --> Undefined index: catatan_10 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:40:41 --> Severity: Notice --> Undefined index: naik_11 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:40:41 --> Severity: Notice --> Undefined index: catatan_11 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:40:41 --> Severity: Notice --> Undefined index: naik_12 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:40:41 --> Severity: Notice --> Undefined index: catatan_12 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:40:41 --> Severity: Notice --> Undefined index: naik_13 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:40:41 --> Severity: Notice --> Undefined index: catatan_13 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:40:41 --> Severity: Notice --> Undefined index: naik_14 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:40:41 --> Severity: Notice --> Undefined index: catatan_14 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:40:41 --> Severity: Notice --> Undefined index: naik_15 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:40:41 --> Severity: Notice --> Undefined index: catatan_15 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:40:41 --> Severity: Notice --> Undefined index: naik_16 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:40:41 --> Severity: Notice --> Undefined index: catatan_16 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:40:41 --> Severity: Notice --> Undefined index: naik_17 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:40:41 --> Severity: Notice --> Undefined index: catatan_17 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:40:41 --> Severity: Notice --> Undefined index: naik_18 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:40:41 --> Severity: Notice --> Undefined index: catatan_18 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:40:41 --> Severity: Notice --> Undefined index: naik_19 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:40:41 --> Severity: Notice --> Undefined index: catatan_19 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:40:41 --> Severity: Notice --> Undefined index: naik_20 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:40:41 --> Severity: Notice --> Undefined index: catatan_20 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:40:41 --> Severity: Notice --> Undefined index: naik_21 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:40:41 --> Severity: Notice --> Undefined index: catatan_21 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:40:41 --> Severity: Notice --> Undefined index: naik_22 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:40:41 --> Severity: Notice --> Undefined index: catatan_22 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:40:41 --> Severity: Notice --> Undefined index: naik_23 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:40:41 --> Severity: Notice --> Undefined index: catatan_23 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:40:41 --> Severity: Notice --> Undefined index: naik_24 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:40:41 --> Severity: Notice --> Undefined index: catatan_24 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:40:41 --> Severity: Notice --> Undefined index: naik_25 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:40:41 --> Severity: Notice --> Undefined index: catatan_25 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:40:41 --> Severity: Notice --> Undefined index: naik_26 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:40:41 --> Severity: Notice --> Undefined index: catatan_26 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:40:41 --> Severity: Notice --> Undefined index: naik_27 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:40:41 --> Severity: Notice --> Undefined index: catatan_27 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:40:41 --> Severity: Notice --> Undefined index: naik_28 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:40:41 --> Severity: Notice --> Undefined index: catatan_28 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:40:41 --> Severity: Notice --> Undefined index: naik_29 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:40:41 --> Severity: Notice --> Undefined index: catatan_29 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:40:41 --> Severity: Notice --> Undefined index: naik_30 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:40:41 --> Severity: Notice --> Undefined index: catatan_30 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:40:41 --> Severity: Notice --> Undefined index: naik_31 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:40:41 --> Severity: Notice --> Undefined index: catatan_31 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:40:41 --> Severity: Notice --> Undefined index: naik_32 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:40:41 --> Severity: Notice --> Undefined index: catatan_32 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:40:41 --> Severity: Notice --> Undefined index: naik_33 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:40:42 --> Severity: Notice --> Undefined index: catatan_33 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:40:42 --> Severity: Notice --> Undefined index: naik_34 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:40:42 --> Severity: Notice --> Undefined index: catatan_34 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:40:42 --> Severity: Notice --> Undefined index: naik_35 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:40:42 --> Severity: Notice --> Undefined index: catatan_35 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:40:42 --> Severity: Notice --> Undefined index: naik_36 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:40:42 --> Severity: Notice --> Undefined index: catatan_36 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:40:42 --> Severity: Notice --> Undefined index: naik_37 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:40:42 --> Severity: Notice --> Undefined index: catatan_37 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:40:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\nilai\system\core\Exceptions.php:272) C:\xampp\htdocs\nilai\application\helpers\my_helper.php 120
INFO - 2021-01-04 08:40:42 --> Final output sent to browser
DEBUG - 2021-01-04 08:40:42 --> Total execution time: 1.5982
INFO - 2021-01-04 08:41:09 --> Config Class Initialized
INFO - 2021-01-04 08:41:09 --> Hooks Class Initialized
DEBUG - 2021-01-04 08:41:09 --> UTF-8 Support Enabled
INFO - 2021-01-04 08:41:09 --> Utf8 Class Initialized
INFO - 2021-01-04 08:41:09 --> URI Class Initialized
INFO - 2021-01-04 08:41:09 --> Router Class Initialized
INFO - 2021-01-04 08:41:09 --> Output Class Initialized
INFO - 2021-01-04 08:41:09 --> Security Class Initialized
DEBUG - 2021-01-04 08:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 08:41:09 --> Input Class Initialized
INFO - 2021-01-04 08:41:09 --> Language Class Initialized
INFO - 2021-01-04 08:41:09 --> Language Class Initialized
INFO - 2021-01-04 08:41:09 --> Config Class Initialized
INFO - 2021-01-04 08:41:09 --> Loader Class Initialized
INFO - 2021-01-04 08:41:09 --> Helper loaded: url_helper
INFO - 2021-01-04 08:41:09 --> Helper loaded: file_helper
INFO - 2021-01-04 08:41:09 --> Helper loaded: form_helper
INFO - 2021-01-04 08:41:09 --> Helper loaded: my_helper
INFO - 2021-01-04 08:41:09 --> Database Driver Class Initialized
DEBUG - 2021-01-04 08:41:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 08:41:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 08:41:09 --> Controller Class Initialized
DEBUG - 2021-01-04 08:41:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-01-04 08:41:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-04 08:41:09 --> Final output sent to browser
DEBUG - 2021-01-04 08:41:09 --> Total execution time: 0.5710
INFO - 2021-01-04 08:41:17 --> Config Class Initialized
INFO - 2021-01-04 08:41:17 --> Hooks Class Initialized
DEBUG - 2021-01-04 08:41:17 --> UTF-8 Support Enabled
INFO - 2021-01-04 08:41:17 --> Utf8 Class Initialized
INFO - 2021-01-04 08:41:17 --> URI Class Initialized
INFO - 2021-01-04 08:41:17 --> Router Class Initialized
INFO - 2021-01-04 08:41:17 --> Output Class Initialized
INFO - 2021-01-04 08:41:17 --> Security Class Initialized
DEBUG - 2021-01-04 08:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 08:41:17 --> Input Class Initialized
INFO - 2021-01-04 08:41:17 --> Language Class Initialized
INFO - 2021-01-04 08:41:17 --> Language Class Initialized
INFO - 2021-01-04 08:41:17 --> Config Class Initialized
INFO - 2021-01-04 08:41:17 --> Loader Class Initialized
INFO - 2021-01-04 08:41:17 --> Helper loaded: url_helper
INFO - 2021-01-04 08:41:17 --> Helper loaded: file_helper
INFO - 2021-01-04 08:41:17 --> Helper loaded: form_helper
INFO - 2021-01-04 08:41:17 --> Helper loaded: my_helper
INFO - 2021-01-04 08:41:17 --> Database Driver Class Initialized
DEBUG - 2021-01-04 08:41:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 08:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 08:41:17 --> Controller Class Initialized
ERROR - 2021-01-04 08:41:17 --> Severity: Notice --> Undefined index: naik_1 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:41:17 --> Severity: Notice --> Undefined index: catatan_1 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:41:17 --> Severity: Notice --> Undefined index: naik_2 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:41:17 --> Severity: Notice --> Undefined index: catatan_2 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:41:17 --> Severity: Notice --> Undefined index: naik_3 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:41:17 --> Severity: Notice --> Undefined index: catatan_3 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:41:17 --> Severity: Notice --> Undefined index: naik_4 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:41:17 --> Severity: Notice --> Undefined index: catatan_4 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:41:17 --> Severity: Notice --> Undefined index: naik_5 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:41:17 --> Severity: Notice --> Undefined index: catatan_5 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:41:17 --> Severity: Notice --> Undefined index: naik_6 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:41:17 --> Severity: Notice --> Undefined index: catatan_6 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:41:17 --> Severity: Notice --> Undefined index: naik_7 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:41:17 --> Severity: Notice --> Undefined index: catatan_7 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:41:17 --> Severity: Notice --> Undefined index: naik_8 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:41:17 --> Severity: Notice --> Undefined index: catatan_8 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:41:17 --> Severity: Notice --> Undefined index: naik_9 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:41:17 --> Severity: Notice --> Undefined index: catatan_9 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:41:17 --> Severity: Notice --> Undefined index: naik_10 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:41:17 --> Severity: Notice --> Undefined index: catatan_10 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:41:17 --> Severity: Notice --> Undefined index: naik_11 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:41:17 --> Severity: Notice --> Undefined index: catatan_11 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:41:17 --> Severity: Notice --> Undefined index: naik_12 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:41:17 --> Severity: Notice --> Undefined index: catatan_12 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:41:18 --> Severity: Notice --> Undefined index: naik_13 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:41:18 --> Severity: Notice --> Undefined index: catatan_13 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:41:18 --> Severity: Notice --> Undefined index: naik_14 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:41:18 --> Severity: Notice --> Undefined index: catatan_14 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:41:18 --> Severity: Notice --> Undefined index: naik_15 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:41:18 --> Severity: Notice --> Undefined index: catatan_15 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:41:18 --> Severity: Notice --> Undefined index: naik_16 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:41:18 --> Severity: Notice --> Undefined index: catatan_16 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:41:18 --> Severity: Notice --> Undefined index: naik_17 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:41:18 --> Severity: Notice --> Undefined index: catatan_17 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:41:18 --> Severity: Notice --> Undefined index: naik_18 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:41:18 --> Severity: Notice --> Undefined index: catatan_18 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:41:18 --> Severity: Notice --> Undefined index: naik_19 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:41:18 --> Severity: Notice --> Undefined index: catatan_19 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:41:18 --> Severity: Notice --> Undefined index: naik_20 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:41:18 --> Severity: Notice --> Undefined index: catatan_20 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:41:18 --> Severity: Notice --> Undefined index: naik_21 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:41:18 --> Severity: Notice --> Undefined index: catatan_21 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:41:18 --> Severity: Notice --> Undefined index: naik_22 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:41:18 --> Severity: Notice --> Undefined index: catatan_22 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:41:18 --> Severity: Notice --> Undefined index: naik_23 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:41:18 --> Severity: Notice --> Undefined index: catatan_23 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:41:18 --> Severity: Notice --> Undefined index: naik_24 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:41:18 --> Severity: Notice --> Undefined index: catatan_24 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:41:18 --> Severity: Notice --> Undefined index: naik_25 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:41:18 --> Severity: Notice --> Undefined index: catatan_25 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:41:18 --> Severity: Notice --> Undefined index: naik_26 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:41:18 --> Severity: Notice --> Undefined index: catatan_26 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:41:18 --> Severity: Notice --> Undefined index: naik_27 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:41:18 --> Severity: Notice --> Undefined index: catatan_27 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:41:18 --> Severity: Notice --> Undefined index: naik_28 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:41:18 --> Severity: Notice --> Undefined index: catatan_28 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:41:18 --> Severity: Notice --> Undefined index: naik_29 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:41:18 --> Severity: Notice --> Undefined index: catatan_29 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:41:18 --> Severity: Notice --> Undefined index: naik_30 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:41:18 --> Severity: Notice --> Undefined index: catatan_30 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:41:18 --> Severity: Notice --> Undefined index: naik_31 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:41:18 --> Severity: Notice --> Undefined index: catatan_31 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:41:18 --> Severity: Notice --> Undefined index: naik_32 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:41:18 --> Severity: Notice --> Undefined index: catatan_32 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:41:18 --> Severity: Notice --> Undefined index: naik_33 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:41:18 --> Severity: Notice --> Undefined index: catatan_33 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:41:18 --> Severity: Notice --> Undefined index: naik_34 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:41:18 --> Severity: Notice --> Undefined index: catatan_34 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:41:18 --> Severity: Notice --> Undefined index: naik_35 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:41:18 --> Severity: Notice --> Undefined index: catatan_35 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:41:18 --> Severity: Notice --> Undefined index: naik_36 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:41:18 --> Severity: Notice --> Undefined index: catatan_36 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:41:18 --> Severity: Notice --> Undefined index: naik_37 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 43
ERROR - 2021-01-04 08:41:18 --> Severity: Notice --> Undefined index: catatan_37 C:\xampp\htdocs\nilai\application\modules\n_catatan\controllers\N_catatan.php 44
ERROR - 2021-01-04 08:41:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\nilai\system\core\Exceptions.php:272) C:\xampp\htdocs\nilai\application\helpers\my_helper.php 120
INFO - 2021-01-04 08:41:18 --> Final output sent to browser
DEBUG - 2021-01-04 08:41:18 --> Total execution time: 1.8819
INFO - 2021-01-04 08:45:09 --> Config Class Initialized
INFO - 2021-01-04 08:45:09 --> Hooks Class Initialized
DEBUG - 2021-01-04 08:45:09 --> UTF-8 Support Enabled
INFO - 2021-01-04 08:45:09 --> Utf8 Class Initialized
INFO - 2021-01-04 08:45:09 --> URI Class Initialized
INFO - 2021-01-04 08:45:09 --> Router Class Initialized
INFO - 2021-01-04 08:45:09 --> Output Class Initialized
INFO - 2021-01-04 08:45:09 --> Security Class Initialized
DEBUG - 2021-01-04 08:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 08:45:10 --> Input Class Initialized
INFO - 2021-01-04 08:45:10 --> Language Class Initialized
INFO - 2021-01-04 08:45:10 --> Language Class Initialized
INFO - 2021-01-04 08:45:10 --> Config Class Initialized
INFO - 2021-01-04 08:45:10 --> Loader Class Initialized
INFO - 2021-01-04 08:45:10 --> Helper loaded: url_helper
INFO - 2021-01-04 08:45:10 --> Helper loaded: file_helper
INFO - 2021-01-04 08:45:10 --> Helper loaded: form_helper
INFO - 2021-01-04 08:45:10 --> Helper loaded: my_helper
INFO - 2021-01-04 08:45:10 --> Database Driver Class Initialized
DEBUG - 2021-01-04 08:45:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 08:45:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 08:45:10 --> Controller Class Initialized
DEBUG - 2021-01-04 08:45:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-01-04 08:45:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-04 08:45:10 --> Final output sent to browser
DEBUG - 2021-01-04 08:45:10 --> Total execution time: 0.5469
INFO - 2021-01-04 08:45:14 --> Config Class Initialized
INFO - 2021-01-04 08:45:14 --> Hooks Class Initialized
DEBUG - 2021-01-04 08:45:14 --> UTF-8 Support Enabled
INFO - 2021-01-04 08:45:14 --> Utf8 Class Initialized
INFO - 2021-01-04 08:45:14 --> URI Class Initialized
INFO - 2021-01-04 08:45:14 --> Router Class Initialized
INFO - 2021-01-04 08:45:14 --> Output Class Initialized
INFO - 2021-01-04 08:45:14 --> Security Class Initialized
DEBUG - 2021-01-04 08:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 08:45:14 --> Input Class Initialized
INFO - 2021-01-04 08:45:14 --> Language Class Initialized
INFO - 2021-01-04 08:45:14 --> Language Class Initialized
INFO - 2021-01-04 08:45:14 --> Config Class Initialized
INFO - 2021-01-04 08:45:14 --> Loader Class Initialized
INFO - 2021-01-04 08:45:14 --> Helper loaded: url_helper
INFO - 2021-01-04 08:45:14 --> Helper loaded: file_helper
INFO - 2021-01-04 08:45:14 --> Helper loaded: form_helper
INFO - 2021-01-04 08:45:14 --> Helper loaded: my_helper
INFO - 2021-01-04 08:45:14 --> Database Driver Class Initialized
DEBUG - 2021-01-04 08:45:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 08:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 08:45:14 --> Controller Class Initialized
INFO - 2021-01-04 08:45:14 --> Final output sent to browser
DEBUG - 2021-01-04 08:45:14 --> Total execution time: 0.5853
INFO - 2021-01-04 08:49:35 --> Config Class Initialized
INFO - 2021-01-04 08:49:35 --> Hooks Class Initialized
DEBUG - 2021-01-04 08:49:35 --> UTF-8 Support Enabled
INFO - 2021-01-04 08:49:35 --> Utf8 Class Initialized
INFO - 2021-01-04 08:49:35 --> URI Class Initialized
INFO - 2021-01-04 08:49:35 --> Router Class Initialized
INFO - 2021-01-04 08:49:35 --> Output Class Initialized
INFO - 2021-01-04 08:49:35 --> Security Class Initialized
DEBUG - 2021-01-04 08:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 08:49:35 --> Input Class Initialized
INFO - 2021-01-04 08:49:35 --> Language Class Initialized
INFO - 2021-01-04 08:49:35 --> Language Class Initialized
INFO - 2021-01-04 08:49:35 --> Config Class Initialized
INFO - 2021-01-04 08:49:35 --> Loader Class Initialized
INFO - 2021-01-04 08:49:35 --> Helper loaded: url_helper
INFO - 2021-01-04 08:49:35 --> Helper loaded: file_helper
INFO - 2021-01-04 08:49:35 --> Helper loaded: form_helper
INFO - 2021-01-04 08:49:35 --> Helper loaded: my_helper
INFO - 2021-01-04 08:49:35 --> Database Driver Class Initialized
DEBUG - 2021-01-04 08:49:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 08:49:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 08:49:35 --> Controller Class Initialized
ERROR - 2021-01-04 08:49:35 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\nilai\application\modules\n_c_akademik\views\list.php 108
INFO - 2021-01-04 08:51:27 --> Config Class Initialized
INFO - 2021-01-04 08:51:27 --> Hooks Class Initialized
DEBUG - 2021-01-04 08:51:27 --> UTF-8 Support Enabled
INFO - 2021-01-04 08:51:27 --> Utf8 Class Initialized
INFO - 2021-01-04 08:51:27 --> URI Class Initialized
INFO - 2021-01-04 08:51:27 --> Router Class Initialized
INFO - 2021-01-04 08:51:27 --> Output Class Initialized
INFO - 2021-01-04 08:51:27 --> Security Class Initialized
DEBUG - 2021-01-04 08:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 08:51:27 --> Input Class Initialized
INFO - 2021-01-04 08:51:27 --> Language Class Initialized
INFO - 2021-01-04 08:51:27 --> Language Class Initialized
INFO - 2021-01-04 08:51:27 --> Config Class Initialized
INFO - 2021-01-04 08:51:27 --> Loader Class Initialized
INFO - 2021-01-04 08:51:27 --> Helper loaded: url_helper
INFO - 2021-01-04 08:51:27 --> Helper loaded: file_helper
INFO - 2021-01-04 08:51:27 --> Helper loaded: form_helper
INFO - 2021-01-04 08:51:27 --> Helper loaded: my_helper
INFO - 2021-01-04 08:51:27 --> Database Driver Class Initialized
DEBUG - 2021-01-04 08:51:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 08:51:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 08:51:28 --> Controller Class Initialized
DEBUG - 2021-01-04 08:51:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-01-04 08:51:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-04 08:51:28 --> Final output sent to browser
DEBUG - 2021-01-04 08:51:28 --> Total execution time: 0.5335
INFO - 2021-01-04 08:51:32 --> Config Class Initialized
INFO - 2021-01-04 08:51:32 --> Hooks Class Initialized
DEBUG - 2021-01-04 08:51:32 --> UTF-8 Support Enabled
INFO - 2021-01-04 08:51:32 --> Utf8 Class Initialized
INFO - 2021-01-04 08:51:32 --> URI Class Initialized
INFO - 2021-01-04 08:51:32 --> Router Class Initialized
INFO - 2021-01-04 08:51:32 --> Output Class Initialized
INFO - 2021-01-04 08:51:32 --> Security Class Initialized
DEBUG - 2021-01-04 08:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 08:51:32 --> Input Class Initialized
INFO - 2021-01-04 08:51:32 --> Language Class Initialized
INFO - 2021-01-04 08:51:32 --> Language Class Initialized
INFO - 2021-01-04 08:51:32 --> Config Class Initialized
INFO - 2021-01-04 08:51:32 --> Loader Class Initialized
INFO - 2021-01-04 08:51:32 --> Helper loaded: url_helper
INFO - 2021-01-04 08:51:32 --> Helper loaded: file_helper
INFO - 2021-01-04 08:51:32 --> Helper loaded: form_helper
INFO - 2021-01-04 08:51:32 --> Helper loaded: my_helper
INFO - 2021-01-04 08:51:32 --> Database Driver Class Initialized
DEBUG - 2021-01-04 08:51:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 08:51:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 08:51:32 --> Controller Class Initialized
INFO - 2021-01-04 08:51:32 --> Final output sent to browser
DEBUG - 2021-01-04 08:51:32 --> Total execution time: 0.5790
INFO - 2021-01-04 08:54:24 --> Config Class Initialized
INFO - 2021-01-04 08:54:24 --> Hooks Class Initialized
DEBUG - 2021-01-04 08:54:24 --> UTF-8 Support Enabled
INFO - 2021-01-04 08:54:24 --> Utf8 Class Initialized
INFO - 2021-01-04 08:54:24 --> URI Class Initialized
INFO - 2021-01-04 08:54:24 --> Router Class Initialized
INFO - 2021-01-04 08:54:24 --> Output Class Initialized
INFO - 2021-01-04 08:54:24 --> Security Class Initialized
DEBUG - 2021-01-04 08:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 08:54:24 --> Input Class Initialized
INFO - 2021-01-04 08:54:24 --> Language Class Initialized
INFO - 2021-01-04 08:54:24 --> Language Class Initialized
INFO - 2021-01-04 08:54:24 --> Config Class Initialized
INFO - 2021-01-04 08:54:24 --> Loader Class Initialized
INFO - 2021-01-04 08:54:24 --> Helper loaded: url_helper
INFO - 2021-01-04 08:54:24 --> Helper loaded: file_helper
INFO - 2021-01-04 08:54:24 --> Helper loaded: form_helper
INFO - 2021-01-04 08:54:24 --> Helper loaded: my_helper
INFO - 2021-01-04 08:54:24 --> Database Driver Class Initialized
DEBUG - 2021-01-04 08:54:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 08:54:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 08:54:24 --> Controller Class Initialized
DEBUG - 2021-01-04 08:54:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-01-04 08:54:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-04 08:54:24 --> Final output sent to browser
DEBUG - 2021-01-04 08:54:24 --> Total execution time: 0.5367
INFO - 2021-01-04 08:59:19 --> Config Class Initialized
INFO - 2021-01-04 08:59:19 --> Hooks Class Initialized
DEBUG - 2021-01-04 08:59:19 --> UTF-8 Support Enabled
INFO - 2021-01-04 08:59:19 --> Utf8 Class Initialized
INFO - 2021-01-04 08:59:19 --> URI Class Initialized
INFO - 2021-01-04 08:59:19 --> Router Class Initialized
INFO - 2021-01-04 08:59:19 --> Output Class Initialized
INFO - 2021-01-04 08:59:19 --> Security Class Initialized
DEBUG - 2021-01-04 08:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 08:59:19 --> Input Class Initialized
INFO - 2021-01-04 08:59:19 --> Language Class Initialized
INFO - 2021-01-04 08:59:19 --> Language Class Initialized
INFO - 2021-01-04 08:59:19 --> Config Class Initialized
INFO - 2021-01-04 08:59:19 --> Loader Class Initialized
INFO - 2021-01-04 08:59:19 --> Helper loaded: url_helper
INFO - 2021-01-04 08:59:19 --> Helper loaded: file_helper
INFO - 2021-01-04 08:59:19 --> Helper loaded: form_helper
INFO - 2021-01-04 08:59:19 --> Helper loaded: my_helper
INFO - 2021-01-04 08:59:19 --> Database Driver Class Initialized
DEBUG - 2021-01-04 08:59:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 08:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 08:59:19 --> Controller Class Initialized
INFO - 2021-01-04 08:59:20 --> Final output sent to browser
DEBUG - 2021-01-04 08:59:20 --> Total execution time: 0.5849
INFO - 2021-01-04 09:06:40 --> Config Class Initialized
INFO - 2021-01-04 09:06:40 --> Hooks Class Initialized
DEBUG - 2021-01-04 09:06:40 --> UTF-8 Support Enabled
INFO - 2021-01-04 09:06:40 --> Utf8 Class Initialized
INFO - 2021-01-04 09:06:40 --> URI Class Initialized
INFO - 2021-01-04 09:06:41 --> Router Class Initialized
INFO - 2021-01-04 09:06:41 --> Output Class Initialized
INFO - 2021-01-04 09:06:41 --> Security Class Initialized
DEBUG - 2021-01-04 09:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 09:06:41 --> Input Class Initialized
INFO - 2021-01-04 09:06:41 --> Language Class Initialized
INFO - 2021-01-04 09:06:41 --> Language Class Initialized
INFO - 2021-01-04 09:06:41 --> Config Class Initialized
INFO - 2021-01-04 09:06:41 --> Loader Class Initialized
INFO - 2021-01-04 09:06:41 --> Helper loaded: url_helper
INFO - 2021-01-04 09:06:41 --> Helper loaded: file_helper
INFO - 2021-01-04 09:06:41 --> Helper loaded: form_helper
INFO - 2021-01-04 09:06:41 --> Helper loaded: my_helper
INFO - 2021-01-04 09:06:41 --> Database Driver Class Initialized
DEBUG - 2021-01-04 09:06:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 09:06:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 09:06:41 --> Controller Class Initialized
DEBUG - 2021-01-04 09:06:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2021-01-04 09:06:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-04 09:06:41 --> Final output sent to browser
DEBUG - 2021-01-04 09:06:41 --> Total execution time: 0.5211
INFO - 2021-01-04 09:06:47 --> Config Class Initialized
INFO - 2021-01-04 09:06:47 --> Hooks Class Initialized
DEBUG - 2021-01-04 09:06:47 --> UTF-8 Support Enabled
INFO - 2021-01-04 09:06:47 --> Utf8 Class Initialized
INFO - 2021-01-04 09:06:47 --> URI Class Initialized
INFO - 2021-01-04 09:06:47 --> Router Class Initialized
INFO - 2021-01-04 09:06:47 --> Output Class Initialized
INFO - 2021-01-04 09:06:47 --> Security Class Initialized
DEBUG - 2021-01-04 09:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 09:06:47 --> Input Class Initialized
INFO - 2021-01-04 09:06:47 --> Language Class Initialized
INFO - 2021-01-04 09:06:47 --> Language Class Initialized
INFO - 2021-01-04 09:06:47 --> Config Class Initialized
INFO - 2021-01-04 09:06:47 --> Loader Class Initialized
INFO - 2021-01-04 09:06:47 --> Helper loaded: url_helper
INFO - 2021-01-04 09:06:47 --> Helper loaded: file_helper
INFO - 2021-01-04 09:06:47 --> Helper loaded: form_helper
INFO - 2021-01-04 09:06:47 --> Helper loaded: my_helper
INFO - 2021-01-04 09:06:47 --> Database Driver Class Initialized
DEBUG - 2021-01-04 09:06:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 09:06:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 09:06:47 --> Controller Class Initialized
DEBUG - 2021-01-04 09:06:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2021-01-04 09:06:47 --> Final output sent to browser
DEBUG - 2021-01-04 09:06:47 --> Total execution time: 0.4871
INFO - 2021-01-04 09:07:27 --> Config Class Initialized
INFO - 2021-01-04 09:07:27 --> Hooks Class Initialized
DEBUG - 2021-01-04 09:07:27 --> UTF-8 Support Enabled
INFO - 2021-01-04 09:07:27 --> Utf8 Class Initialized
INFO - 2021-01-04 09:07:27 --> URI Class Initialized
DEBUG - 2021-01-04 09:07:27 --> No URI present. Default controller set.
INFO - 2021-01-04 09:07:27 --> Router Class Initialized
INFO - 2021-01-04 09:07:27 --> Output Class Initialized
INFO - 2021-01-04 09:07:27 --> Security Class Initialized
DEBUG - 2021-01-04 09:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 09:07:27 --> Input Class Initialized
INFO - 2021-01-04 09:07:27 --> Language Class Initialized
INFO - 2021-01-04 09:07:27 --> Language Class Initialized
INFO - 2021-01-04 09:07:27 --> Config Class Initialized
INFO - 2021-01-04 09:07:27 --> Loader Class Initialized
INFO - 2021-01-04 09:07:27 --> Helper loaded: url_helper
INFO - 2021-01-04 09:07:27 --> Helper loaded: file_helper
INFO - 2021-01-04 09:07:27 --> Helper loaded: form_helper
INFO - 2021-01-04 09:07:27 --> Helper loaded: my_helper
INFO - 2021-01-04 09:07:27 --> Database Driver Class Initialized
DEBUG - 2021-01-04 09:07:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 09:07:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 09:07:27 --> Controller Class Initialized
DEBUG - 2021-01-04 09:07:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-04 09:07:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-04 09:07:27 --> Final output sent to browser
DEBUG - 2021-01-04 09:07:27 --> Total execution time: 0.4762
INFO - 2021-01-04 09:10:14 --> Config Class Initialized
INFO - 2021-01-04 09:10:14 --> Hooks Class Initialized
DEBUG - 2021-01-04 09:10:14 --> UTF-8 Support Enabled
INFO - 2021-01-04 09:10:14 --> Utf8 Class Initialized
INFO - 2021-01-04 09:10:14 --> URI Class Initialized
INFO - 2021-01-04 09:10:14 --> Router Class Initialized
INFO - 2021-01-04 09:10:14 --> Output Class Initialized
INFO - 2021-01-04 09:10:14 --> Security Class Initialized
DEBUG - 2021-01-04 09:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-04 09:10:14 --> Input Class Initialized
INFO - 2021-01-04 09:10:14 --> Language Class Initialized
INFO - 2021-01-04 09:10:14 --> Language Class Initialized
INFO - 2021-01-04 09:10:14 --> Config Class Initialized
INFO - 2021-01-04 09:10:14 --> Loader Class Initialized
INFO - 2021-01-04 09:10:14 --> Helper loaded: url_helper
INFO - 2021-01-04 09:10:14 --> Helper loaded: file_helper
INFO - 2021-01-04 09:10:14 --> Helper loaded: form_helper
INFO - 2021-01-04 09:10:14 --> Helper loaded: my_helper
INFO - 2021-01-04 09:10:14 --> Database Driver Class Initialized
DEBUG - 2021-01-04 09:10:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-04 09:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-04 09:10:15 --> Controller Class Initialized
DEBUG - 2021-01-04 09:10:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-01-04 09:10:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-04 09:10:15 --> Final output sent to browser
DEBUG - 2021-01-04 09:10:15 --> Total execution time: 0.4301
