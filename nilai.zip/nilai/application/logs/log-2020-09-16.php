<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-09-16 05:07:16 --> Config Class Initialized
INFO - 2020-09-16 05:07:16 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:07:16 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:07:16 --> Utf8 Class Initialized
INFO - 2020-09-16 05:07:16 --> URI Class Initialized
INFO - 2020-09-16 05:07:16 --> Router Class Initialized
INFO - 2020-09-16 05:07:16 --> Output Class Initialized
INFO - 2020-09-16 05:07:16 --> Security Class Initialized
DEBUG - 2020-09-16 05:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:07:16 --> Input Class Initialized
INFO - 2020-09-16 05:07:16 --> Language Class Initialized
INFO - 2020-09-16 05:07:16 --> Language Class Initialized
INFO - 2020-09-16 05:07:16 --> Config Class Initialized
INFO - 2020-09-16 05:07:16 --> Loader Class Initialized
INFO - 2020-09-16 05:07:16 --> Helper loaded: url_helper
INFO - 2020-09-16 05:07:16 --> Helper loaded: file_helper
INFO - 2020-09-16 05:07:16 --> Helper loaded: form_helper
INFO - 2020-09-16 05:07:16 --> Helper loaded: my_helper
INFO - 2020-09-16 05:07:16 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:07:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:07:16 --> Controller Class Initialized
DEBUG - 2020-09-16 05:07:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-09-16 05:07:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-16 05:07:17 --> Final output sent to browser
DEBUG - 2020-09-16 05:07:17 --> Total execution time: 0.1912
INFO - 2020-09-16 05:07:28 --> Config Class Initialized
INFO - 2020-09-16 05:07:28 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:07:28 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:07:28 --> Utf8 Class Initialized
INFO - 2020-09-16 05:07:28 --> URI Class Initialized
INFO - 2020-09-16 05:07:28 --> Router Class Initialized
INFO - 2020-09-16 05:07:28 --> Output Class Initialized
INFO - 2020-09-16 05:07:28 --> Security Class Initialized
DEBUG - 2020-09-16 05:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:07:28 --> Input Class Initialized
INFO - 2020-09-16 05:07:28 --> Language Class Initialized
INFO - 2020-09-16 05:07:28 --> Language Class Initialized
INFO - 2020-09-16 05:07:28 --> Config Class Initialized
INFO - 2020-09-16 05:07:28 --> Loader Class Initialized
INFO - 2020-09-16 05:07:28 --> Helper loaded: url_helper
INFO - 2020-09-16 05:07:28 --> Helper loaded: file_helper
INFO - 2020-09-16 05:07:28 --> Helper loaded: form_helper
INFO - 2020-09-16 05:07:28 --> Helper loaded: my_helper
INFO - 2020-09-16 05:07:28 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:07:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:07:28 --> Controller Class Initialized
DEBUG - 2020-09-16 05:07:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-09-16 05:07:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-16 05:07:28 --> Final output sent to browser
DEBUG - 2020-09-16 05:07:28 --> Total execution time: 0.0841
INFO - 2020-09-16 05:11:00 --> Config Class Initialized
INFO - 2020-09-16 05:11:00 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:11:00 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:11:00 --> Utf8 Class Initialized
INFO - 2020-09-16 05:11:00 --> URI Class Initialized
INFO - 2020-09-16 05:11:00 --> Router Class Initialized
INFO - 2020-09-16 05:11:00 --> Output Class Initialized
INFO - 2020-09-16 05:11:00 --> Security Class Initialized
DEBUG - 2020-09-16 05:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:11:00 --> Input Class Initialized
INFO - 2020-09-16 05:11:00 --> Language Class Initialized
INFO - 2020-09-16 05:11:00 --> Language Class Initialized
INFO - 2020-09-16 05:11:00 --> Config Class Initialized
INFO - 2020-09-16 05:11:00 --> Loader Class Initialized
INFO - 2020-09-16 05:11:00 --> Helper loaded: url_helper
INFO - 2020-09-16 05:11:00 --> Helper loaded: file_helper
INFO - 2020-09-16 05:11:00 --> Helper loaded: form_helper
INFO - 2020-09-16 05:11:00 --> Helper loaded: my_helper
INFO - 2020-09-16 05:11:00 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:11:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:11:00 --> Controller Class Initialized
DEBUG - 2020-09-16 05:11:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-09-16 05:11:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-16 05:11:00 --> Final output sent to browser
DEBUG - 2020-09-16 05:11:00 --> Total execution time: 0.0618
INFO - 2020-09-16 05:11:02 --> Config Class Initialized
INFO - 2020-09-16 05:11:02 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:11:02 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:11:02 --> Utf8 Class Initialized
INFO - 2020-09-16 05:11:02 --> URI Class Initialized
INFO - 2020-09-16 05:11:02 --> Router Class Initialized
INFO - 2020-09-16 05:11:02 --> Output Class Initialized
INFO - 2020-09-16 05:11:02 --> Security Class Initialized
DEBUG - 2020-09-16 05:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:11:02 --> Input Class Initialized
INFO - 2020-09-16 05:11:02 --> Language Class Initialized
INFO - 2020-09-16 05:11:02 --> Language Class Initialized
INFO - 2020-09-16 05:11:02 --> Config Class Initialized
INFO - 2020-09-16 05:11:02 --> Loader Class Initialized
INFO - 2020-09-16 05:11:02 --> Helper loaded: url_helper
INFO - 2020-09-16 05:11:02 --> Helper loaded: file_helper
INFO - 2020-09-16 05:11:02 --> Helper loaded: form_helper
INFO - 2020-09-16 05:11:02 --> Helper loaded: my_helper
INFO - 2020-09-16 05:11:02 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:11:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:11:02 --> Controller Class Initialized
DEBUG - 2020-09-16 05:11:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-09-16 05:11:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-16 05:11:02 --> Final output sent to browser
DEBUG - 2020-09-16 05:11:02 --> Total execution time: 0.0640
INFO - 2020-09-16 05:11:09 --> Config Class Initialized
INFO - 2020-09-16 05:11:09 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:11:09 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:11:09 --> Utf8 Class Initialized
INFO - 2020-09-16 05:11:09 --> URI Class Initialized
INFO - 2020-09-16 05:11:09 --> Router Class Initialized
INFO - 2020-09-16 05:11:09 --> Output Class Initialized
INFO - 2020-09-16 05:11:09 --> Security Class Initialized
DEBUG - 2020-09-16 05:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:11:09 --> Input Class Initialized
INFO - 2020-09-16 05:11:09 --> Language Class Initialized
INFO - 2020-09-16 05:11:09 --> Language Class Initialized
INFO - 2020-09-16 05:11:09 --> Config Class Initialized
INFO - 2020-09-16 05:11:09 --> Loader Class Initialized
INFO - 2020-09-16 05:11:09 --> Helper loaded: url_helper
INFO - 2020-09-16 05:11:09 --> Helper loaded: file_helper
INFO - 2020-09-16 05:11:09 --> Helper loaded: form_helper
INFO - 2020-09-16 05:11:09 --> Helper loaded: my_helper
INFO - 2020-09-16 05:11:09 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:11:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:11:09 --> Controller Class Initialized
INFO - 2020-09-16 05:11:09 --> Final output sent to browser
DEBUG - 2020-09-16 05:11:09 --> Total execution time: 0.1347
INFO - 2020-09-16 05:11:12 --> Config Class Initialized
INFO - 2020-09-16 05:11:12 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:11:12 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:11:12 --> Utf8 Class Initialized
INFO - 2020-09-16 05:11:12 --> URI Class Initialized
INFO - 2020-09-16 05:11:12 --> Router Class Initialized
INFO - 2020-09-16 05:11:12 --> Output Class Initialized
INFO - 2020-09-16 05:11:12 --> Security Class Initialized
DEBUG - 2020-09-16 05:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:11:12 --> Input Class Initialized
INFO - 2020-09-16 05:11:12 --> Language Class Initialized
INFO - 2020-09-16 05:11:12 --> Language Class Initialized
INFO - 2020-09-16 05:11:12 --> Config Class Initialized
INFO - 2020-09-16 05:11:12 --> Loader Class Initialized
INFO - 2020-09-16 05:11:12 --> Helper loaded: url_helper
INFO - 2020-09-16 05:11:12 --> Helper loaded: file_helper
INFO - 2020-09-16 05:11:12 --> Helper loaded: form_helper
INFO - 2020-09-16 05:11:12 --> Helper loaded: my_helper
INFO - 2020-09-16 05:11:12 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:11:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:11:12 --> Controller Class Initialized
DEBUG - 2020-09-16 05:11:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-09-16 05:11:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-16 05:11:12 --> Final output sent to browser
DEBUG - 2020-09-16 05:11:12 --> Total execution time: 0.0626
INFO - 2020-09-16 05:11:13 --> Config Class Initialized
INFO - 2020-09-16 05:11:13 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:11:13 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:11:13 --> Utf8 Class Initialized
INFO - 2020-09-16 05:11:13 --> URI Class Initialized
INFO - 2020-09-16 05:11:13 --> Router Class Initialized
INFO - 2020-09-16 05:11:13 --> Output Class Initialized
INFO - 2020-09-16 05:11:13 --> Security Class Initialized
DEBUG - 2020-09-16 05:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:11:13 --> Input Class Initialized
INFO - 2020-09-16 05:11:13 --> Language Class Initialized
INFO - 2020-09-16 05:11:13 --> Language Class Initialized
INFO - 2020-09-16 05:11:13 --> Config Class Initialized
INFO - 2020-09-16 05:11:13 --> Loader Class Initialized
INFO - 2020-09-16 05:11:13 --> Helper loaded: url_helper
INFO - 2020-09-16 05:11:13 --> Helper loaded: file_helper
INFO - 2020-09-16 05:11:13 --> Helper loaded: form_helper
INFO - 2020-09-16 05:11:13 --> Helper loaded: my_helper
INFO - 2020-09-16 05:11:13 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:11:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:11:13 --> Controller Class Initialized
DEBUG - 2020-09-16 05:11:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-09-16 05:11:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-16 05:11:13 --> Final output sent to browser
DEBUG - 2020-09-16 05:11:13 --> Total execution time: 0.0508
INFO - 2020-09-16 05:14:19 --> Config Class Initialized
INFO - 2020-09-16 05:14:19 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:14:19 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:14:19 --> Utf8 Class Initialized
INFO - 2020-09-16 05:14:19 --> URI Class Initialized
INFO - 2020-09-16 05:14:19 --> Router Class Initialized
INFO - 2020-09-16 05:14:19 --> Output Class Initialized
INFO - 2020-09-16 05:14:19 --> Security Class Initialized
DEBUG - 2020-09-16 05:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:14:19 --> Input Class Initialized
INFO - 2020-09-16 05:14:19 --> Language Class Initialized
INFO - 2020-09-16 05:14:19 --> Language Class Initialized
INFO - 2020-09-16 05:14:19 --> Config Class Initialized
INFO - 2020-09-16 05:14:19 --> Loader Class Initialized
INFO - 2020-09-16 05:14:19 --> Helper loaded: url_helper
INFO - 2020-09-16 05:14:19 --> Helper loaded: file_helper
INFO - 2020-09-16 05:14:19 --> Helper loaded: form_helper
INFO - 2020-09-16 05:14:19 --> Helper loaded: my_helper
INFO - 2020-09-16 05:14:19 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:14:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:14:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:14:19 --> Controller Class Initialized
DEBUG - 2020-09-16 05:14:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-09-16 05:14:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-16 05:14:19 --> Final output sent to browser
DEBUG - 2020-09-16 05:14:19 --> Total execution time: 0.0795
INFO - 2020-09-16 05:39:02 --> Config Class Initialized
INFO - 2020-09-16 05:39:02 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:39:02 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:39:02 --> Utf8 Class Initialized
INFO - 2020-09-16 05:39:02 --> URI Class Initialized
INFO - 2020-09-16 05:39:02 --> Router Class Initialized
INFO - 2020-09-16 05:39:02 --> Output Class Initialized
INFO - 2020-09-16 05:39:02 --> Security Class Initialized
DEBUG - 2020-09-16 05:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:39:02 --> Input Class Initialized
INFO - 2020-09-16 05:39:02 --> Language Class Initialized
INFO - 2020-09-16 05:39:02 --> Language Class Initialized
INFO - 2020-09-16 05:39:02 --> Config Class Initialized
INFO - 2020-09-16 05:39:02 --> Loader Class Initialized
INFO - 2020-09-16 05:39:02 --> Helper loaded: url_helper
INFO - 2020-09-16 05:39:02 --> Helper loaded: file_helper
INFO - 2020-09-16 05:39:02 --> Helper loaded: form_helper
INFO - 2020-09-16 05:39:02 --> Helper loaded: my_helper
INFO - 2020-09-16 05:39:02 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:39:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:39:02 --> Controller Class Initialized
DEBUG - 2020-09-16 05:39:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-09-16 05:39:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-16 05:39:02 --> Final output sent to browser
DEBUG - 2020-09-16 05:39:02 --> Total execution time: 0.0565
INFO - 2020-09-16 05:39:02 --> Config Class Initialized
INFO - 2020-09-16 05:39:02 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:39:02 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:39:02 --> Utf8 Class Initialized
INFO - 2020-09-16 05:39:02 --> URI Class Initialized
INFO - 2020-09-16 05:39:02 --> Router Class Initialized
INFO - 2020-09-16 05:39:02 --> Output Class Initialized
INFO - 2020-09-16 05:39:02 --> Security Class Initialized
DEBUG - 2020-09-16 05:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:39:02 --> Input Class Initialized
INFO - 2020-09-16 05:39:02 --> Language Class Initialized
INFO - 2020-09-16 05:39:02 --> Language Class Initialized
INFO - 2020-09-16 05:39:02 --> Config Class Initialized
INFO - 2020-09-16 05:39:02 --> Loader Class Initialized
INFO - 2020-09-16 05:39:02 --> Helper loaded: url_helper
INFO - 2020-09-16 05:39:02 --> Helper loaded: file_helper
INFO - 2020-09-16 05:39:02 --> Helper loaded: form_helper
INFO - 2020-09-16 05:39:02 --> Helper loaded: my_helper
INFO - 2020-09-16 05:39:02 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:39:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:39:02 --> Controller Class Initialized
INFO - 2020-09-16 05:39:03 --> Config Class Initialized
INFO - 2020-09-16 05:39:03 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:39:03 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:39:03 --> Utf8 Class Initialized
INFO - 2020-09-16 05:39:03 --> URI Class Initialized
INFO - 2020-09-16 05:39:03 --> Router Class Initialized
INFO - 2020-09-16 05:39:03 --> Output Class Initialized
INFO - 2020-09-16 05:39:03 --> Security Class Initialized
DEBUG - 2020-09-16 05:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:39:03 --> Input Class Initialized
INFO - 2020-09-16 05:39:03 --> Language Class Initialized
INFO - 2020-09-16 05:39:03 --> Language Class Initialized
INFO - 2020-09-16 05:39:03 --> Config Class Initialized
INFO - 2020-09-16 05:39:03 --> Loader Class Initialized
INFO - 2020-09-16 05:39:03 --> Helper loaded: url_helper
INFO - 2020-09-16 05:39:03 --> Helper loaded: file_helper
INFO - 2020-09-16 05:39:03 --> Helper loaded: form_helper
INFO - 2020-09-16 05:39:03 --> Helper loaded: my_helper
INFO - 2020-09-16 05:39:03 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:39:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:39:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:39:03 --> Controller Class Initialized
ERROR - 2020-09-16 05:39:03 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 241
DEBUG - 2020-09-16 05:39:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2020-09-16 05:39:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-16 05:39:03 --> Final output sent to browser
DEBUG - 2020-09-16 05:39:03 --> Total execution time: 0.0933
INFO - 2020-09-16 05:41:02 --> Config Class Initialized
INFO - 2020-09-16 05:41:02 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:41:02 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:41:02 --> Utf8 Class Initialized
INFO - 2020-09-16 05:41:02 --> URI Class Initialized
INFO - 2020-09-16 05:41:02 --> Router Class Initialized
INFO - 2020-09-16 05:41:02 --> Output Class Initialized
INFO - 2020-09-16 05:41:02 --> Security Class Initialized
DEBUG - 2020-09-16 05:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:41:02 --> Input Class Initialized
INFO - 2020-09-16 05:41:02 --> Language Class Initialized
INFO - 2020-09-16 05:41:02 --> Language Class Initialized
INFO - 2020-09-16 05:41:02 --> Config Class Initialized
INFO - 2020-09-16 05:41:02 --> Loader Class Initialized
INFO - 2020-09-16 05:41:02 --> Helper loaded: url_helper
INFO - 2020-09-16 05:41:02 --> Helper loaded: file_helper
INFO - 2020-09-16 05:41:02 --> Helper loaded: form_helper
INFO - 2020-09-16 05:41:02 --> Helper loaded: my_helper
INFO - 2020-09-16 05:41:02 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:41:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:41:02 --> Controller Class Initialized
INFO - 2020-09-16 05:41:03 --> Upload Class Initialized
INFO - 2020-09-16 05:41:03 --> Language file loaded: language/english/upload_lang.php
ERROR - 2020-09-16 05:41:03 --> The upload path does not appear to be valid.
INFO - 2020-09-16 05:41:03 --> Config Class Initialized
INFO - 2020-09-16 05:41:03 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:41:03 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:41:03 --> Utf8 Class Initialized
INFO - 2020-09-16 05:41:03 --> URI Class Initialized
INFO - 2020-09-16 05:41:03 --> Router Class Initialized
INFO - 2020-09-16 05:41:03 --> Output Class Initialized
INFO - 2020-09-16 05:41:03 --> Security Class Initialized
DEBUG - 2020-09-16 05:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:41:03 --> Input Class Initialized
INFO - 2020-09-16 05:41:03 --> Language Class Initialized
INFO - 2020-09-16 05:41:03 --> Language Class Initialized
INFO - 2020-09-16 05:41:03 --> Config Class Initialized
INFO - 2020-09-16 05:41:03 --> Loader Class Initialized
INFO - 2020-09-16 05:41:03 --> Helper loaded: url_helper
INFO - 2020-09-16 05:41:03 --> Helper loaded: file_helper
INFO - 2020-09-16 05:41:03 --> Helper loaded: form_helper
INFO - 2020-09-16 05:41:03 --> Helper loaded: my_helper
INFO - 2020-09-16 05:41:03 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:41:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:41:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:41:03 --> Controller Class Initialized
DEBUG - 2020-09-16 05:41:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-09-16 05:41:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-16 05:41:03 --> Final output sent to browser
DEBUG - 2020-09-16 05:41:03 --> Total execution time: 0.0485
INFO - 2020-09-16 05:41:03 --> Config Class Initialized
INFO - 2020-09-16 05:41:03 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:41:03 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:41:03 --> Utf8 Class Initialized
INFO - 2020-09-16 05:41:03 --> URI Class Initialized
INFO - 2020-09-16 05:41:03 --> Router Class Initialized
INFO - 2020-09-16 05:41:03 --> Output Class Initialized
INFO - 2020-09-16 05:41:03 --> Security Class Initialized
DEBUG - 2020-09-16 05:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:41:03 --> Input Class Initialized
INFO - 2020-09-16 05:41:03 --> Language Class Initialized
INFO - 2020-09-16 05:41:03 --> Language Class Initialized
INFO - 2020-09-16 05:41:03 --> Config Class Initialized
INFO - 2020-09-16 05:41:03 --> Loader Class Initialized
INFO - 2020-09-16 05:41:03 --> Helper loaded: url_helper
INFO - 2020-09-16 05:41:03 --> Helper loaded: file_helper
INFO - 2020-09-16 05:41:03 --> Helper loaded: form_helper
INFO - 2020-09-16 05:41:03 --> Helper loaded: my_helper
INFO - 2020-09-16 05:41:03 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:41:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:41:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:41:03 --> Controller Class Initialized
INFO - 2020-09-16 05:41:09 --> Config Class Initialized
INFO - 2020-09-16 05:41:09 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:41:09 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:41:09 --> Utf8 Class Initialized
INFO - 2020-09-16 05:41:09 --> URI Class Initialized
INFO - 2020-09-16 05:41:09 --> Router Class Initialized
INFO - 2020-09-16 05:41:09 --> Output Class Initialized
INFO - 2020-09-16 05:41:09 --> Security Class Initialized
DEBUG - 2020-09-16 05:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:41:09 --> Input Class Initialized
INFO - 2020-09-16 05:41:09 --> Language Class Initialized
INFO - 2020-09-16 05:41:09 --> Language Class Initialized
INFO - 2020-09-16 05:41:09 --> Config Class Initialized
INFO - 2020-09-16 05:41:09 --> Loader Class Initialized
INFO - 2020-09-16 05:41:09 --> Helper loaded: url_helper
INFO - 2020-09-16 05:41:09 --> Helper loaded: file_helper
INFO - 2020-09-16 05:41:09 --> Helper loaded: form_helper
INFO - 2020-09-16 05:41:09 --> Helper loaded: my_helper
INFO - 2020-09-16 05:41:09 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:41:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:41:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:41:09 --> Controller Class Initialized
DEBUG - 2020-09-16 05:41:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-09-16 05:41:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-16 05:41:09 --> Final output sent to browser
DEBUG - 2020-09-16 05:41:09 --> Total execution time: 0.0643
INFO - 2020-09-16 05:41:28 --> Config Class Initialized
INFO - 2020-09-16 05:41:28 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:41:28 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:41:28 --> Utf8 Class Initialized
INFO - 2020-09-16 05:41:28 --> URI Class Initialized
INFO - 2020-09-16 05:41:28 --> Router Class Initialized
INFO - 2020-09-16 05:41:28 --> Output Class Initialized
INFO - 2020-09-16 05:41:28 --> Security Class Initialized
DEBUG - 2020-09-16 05:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:41:28 --> Input Class Initialized
INFO - 2020-09-16 05:41:28 --> Language Class Initialized
INFO - 2020-09-16 05:41:28 --> Language Class Initialized
INFO - 2020-09-16 05:41:28 --> Config Class Initialized
INFO - 2020-09-16 05:41:28 --> Loader Class Initialized
INFO - 2020-09-16 05:41:28 --> Helper loaded: url_helper
INFO - 2020-09-16 05:41:28 --> Helper loaded: file_helper
INFO - 2020-09-16 05:41:28 --> Helper loaded: form_helper
INFO - 2020-09-16 05:41:28 --> Helper loaded: my_helper
INFO - 2020-09-16 05:41:28 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:41:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:41:28 --> Controller Class Initialized
DEBUG - 2020-09-16 05:41:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-09-16 05:41:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-16 05:41:28 --> Final output sent to browser
DEBUG - 2020-09-16 05:41:28 --> Total execution time: 0.0533
INFO - 2020-09-16 05:41:34 --> Config Class Initialized
INFO - 2020-09-16 05:41:34 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:41:34 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:41:34 --> Utf8 Class Initialized
INFO - 2020-09-16 05:41:34 --> URI Class Initialized
INFO - 2020-09-16 05:41:34 --> Router Class Initialized
INFO - 2020-09-16 05:41:34 --> Output Class Initialized
INFO - 2020-09-16 05:41:34 --> Security Class Initialized
DEBUG - 2020-09-16 05:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:41:34 --> Input Class Initialized
INFO - 2020-09-16 05:41:34 --> Language Class Initialized
INFO - 2020-09-16 05:41:34 --> Language Class Initialized
INFO - 2020-09-16 05:41:34 --> Config Class Initialized
INFO - 2020-09-16 05:41:34 --> Loader Class Initialized
INFO - 2020-09-16 05:41:34 --> Helper loaded: url_helper
INFO - 2020-09-16 05:41:34 --> Helper loaded: file_helper
INFO - 2020-09-16 05:41:34 --> Helper loaded: form_helper
INFO - 2020-09-16 05:41:34 --> Helper loaded: my_helper
INFO - 2020-09-16 05:41:34 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:41:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:41:34 --> Controller Class Initialized
INFO - 2020-09-16 05:41:34 --> Config Class Initialized
INFO - 2020-09-16 05:41:34 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:41:34 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:41:34 --> Utf8 Class Initialized
INFO - 2020-09-16 05:41:34 --> URI Class Initialized
INFO - 2020-09-16 05:41:34 --> Router Class Initialized
INFO - 2020-09-16 05:41:34 --> Output Class Initialized
INFO - 2020-09-16 05:41:34 --> Security Class Initialized
DEBUG - 2020-09-16 05:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:41:34 --> Input Class Initialized
INFO - 2020-09-16 05:41:34 --> Language Class Initialized
INFO - 2020-09-16 05:41:34 --> Language Class Initialized
INFO - 2020-09-16 05:41:34 --> Config Class Initialized
INFO - 2020-09-16 05:41:34 --> Loader Class Initialized
INFO - 2020-09-16 05:41:34 --> Helper loaded: url_helper
INFO - 2020-09-16 05:41:34 --> Helper loaded: file_helper
INFO - 2020-09-16 05:41:34 --> Helper loaded: form_helper
INFO - 2020-09-16 05:41:34 --> Helper loaded: my_helper
INFO - 2020-09-16 05:41:34 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:41:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:41:34 --> Controller Class Initialized
DEBUG - 2020-09-16 05:41:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-09-16 05:41:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-16 05:41:34 --> Final output sent to browser
DEBUG - 2020-09-16 05:41:34 --> Total execution time: 0.0542
INFO - 2020-09-16 05:41:35 --> Config Class Initialized
INFO - 2020-09-16 05:41:35 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:41:35 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:41:35 --> Utf8 Class Initialized
INFO - 2020-09-16 05:41:35 --> URI Class Initialized
INFO - 2020-09-16 05:41:35 --> Router Class Initialized
INFO - 2020-09-16 05:41:35 --> Output Class Initialized
INFO - 2020-09-16 05:41:35 --> Security Class Initialized
DEBUG - 2020-09-16 05:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:41:35 --> Input Class Initialized
INFO - 2020-09-16 05:41:35 --> Language Class Initialized
INFO - 2020-09-16 05:41:35 --> Language Class Initialized
INFO - 2020-09-16 05:41:35 --> Config Class Initialized
INFO - 2020-09-16 05:41:35 --> Loader Class Initialized
INFO - 2020-09-16 05:41:35 --> Helper loaded: url_helper
INFO - 2020-09-16 05:41:35 --> Helper loaded: file_helper
INFO - 2020-09-16 05:41:35 --> Helper loaded: form_helper
INFO - 2020-09-16 05:41:35 --> Helper loaded: my_helper
INFO - 2020-09-16 05:41:35 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:41:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:41:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:41:35 --> Controller Class Initialized
DEBUG - 2020-09-16 05:41:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-09-16 05:41:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-16 05:41:35 --> Final output sent to browser
DEBUG - 2020-09-16 05:41:35 --> Total execution time: 0.0441
INFO - 2020-09-16 05:41:40 --> Config Class Initialized
INFO - 2020-09-16 05:41:40 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:41:40 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:41:40 --> Utf8 Class Initialized
INFO - 2020-09-16 05:41:40 --> URI Class Initialized
INFO - 2020-09-16 05:41:40 --> Router Class Initialized
INFO - 2020-09-16 05:41:40 --> Output Class Initialized
INFO - 2020-09-16 05:41:40 --> Security Class Initialized
DEBUG - 2020-09-16 05:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:41:40 --> Input Class Initialized
INFO - 2020-09-16 05:41:40 --> Language Class Initialized
INFO - 2020-09-16 05:41:40 --> Language Class Initialized
INFO - 2020-09-16 05:41:40 --> Config Class Initialized
INFO - 2020-09-16 05:41:40 --> Loader Class Initialized
INFO - 2020-09-16 05:41:40 --> Helper loaded: url_helper
INFO - 2020-09-16 05:41:40 --> Helper loaded: file_helper
INFO - 2020-09-16 05:41:40 --> Helper loaded: form_helper
INFO - 2020-09-16 05:41:40 --> Helper loaded: my_helper
INFO - 2020-09-16 05:41:40 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:41:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:41:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:41:40 --> Controller Class Initialized
INFO - 2020-09-16 05:41:40 --> Config Class Initialized
INFO - 2020-09-16 05:41:40 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:41:40 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:41:40 --> Utf8 Class Initialized
INFO - 2020-09-16 05:41:40 --> URI Class Initialized
INFO - 2020-09-16 05:41:40 --> Router Class Initialized
INFO - 2020-09-16 05:41:40 --> Output Class Initialized
INFO - 2020-09-16 05:41:40 --> Security Class Initialized
DEBUG - 2020-09-16 05:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:41:40 --> Input Class Initialized
INFO - 2020-09-16 05:41:40 --> Language Class Initialized
INFO - 2020-09-16 05:41:40 --> Language Class Initialized
INFO - 2020-09-16 05:41:40 --> Config Class Initialized
INFO - 2020-09-16 05:41:40 --> Loader Class Initialized
INFO - 2020-09-16 05:41:40 --> Helper loaded: url_helper
INFO - 2020-09-16 05:41:40 --> Helper loaded: file_helper
INFO - 2020-09-16 05:41:40 --> Helper loaded: form_helper
INFO - 2020-09-16 05:41:40 --> Helper loaded: my_helper
INFO - 2020-09-16 05:41:40 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:41:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:41:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:41:40 --> Controller Class Initialized
DEBUG - 2020-09-16 05:41:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-09-16 05:41:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-16 05:41:40 --> Final output sent to browser
DEBUG - 2020-09-16 05:41:40 --> Total execution time: 0.0617
INFO - 2020-09-16 05:47:28 --> Config Class Initialized
INFO - 2020-09-16 05:47:28 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:47:28 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:47:28 --> Utf8 Class Initialized
INFO - 2020-09-16 05:47:28 --> URI Class Initialized
INFO - 2020-09-16 05:47:28 --> Router Class Initialized
INFO - 2020-09-16 05:47:28 --> Output Class Initialized
INFO - 2020-09-16 05:47:28 --> Security Class Initialized
DEBUG - 2020-09-16 05:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:47:28 --> Input Class Initialized
INFO - 2020-09-16 05:47:28 --> Language Class Initialized
INFO - 2020-09-16 05:47:28 --> Language Class Initialized
INFO - 2020-09-16 05:47:28 --> Config Class Initialized
INFO - 2020-09-16 05:47:28 --> Loader Class Initialized
INFO - 2020-09-16 05:47:28 --> Helper loaded: url_helper
INFO - 2020-09-16 05:47:28 --> Helper loaded: file_helper
INFO - 2020-09-16 05:47:28 --> Helper loaded: form_helper
INFO - 2020-09-16 05:47:28 --> Helper loaded: my_helper
INFO - 2020-09-16 05:47:28 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:47:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:47:28 --> Controller Class Initialized
INFO - 2020-09-16 05:47:28 --> Helper loaded: cookie_helper
INFO - 2020-09-16 05:47:28 --> Config Class Initialized
INFO - 2020-09-16 05:47:28 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:47:28 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:47:28 --> Utf8 Class Initialized
INFO - 2020-09-16 05:47:28 --> URI Class Initialized
INFO - 2020-09-16 05:47:28 --> Router Class Initialized
INFO - 2020-09-16 05:47:28 --> Output Class Initialized
INFO - 2020-09-16 05:47:28 --> Security Class Initialized
DEBUG - 2020-09-16 05:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:47:28 --> Input Class Initialized
INFO - 2020-09-16 05:47:28 --> Language Class Initialized
INFO - 2020-09-16 05:47:28 --> Language Class Initialized
INFO - 2020-09-16 05:47:28 --> Config Class Initialized
INFO - 2020-09-16 05:47:28 --> Loader Class Initialized
INFO - 2020-09-16 05:47:28 --> Helper loaded: url_helper
INFO - 2020-09-16 05:47:28 --> Helper loaded: file_helper
INFO - 2020-09-16 05:47:28 --> Helper loaded: form_helper
INFO - 2020-09-16 05:47:28 --> Helper loaded: my_helper
INFO - 2020-09-16 05:47:28 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:47:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:47:28 --> Controller Class Initialized
DEBUG - 2020-09-16 05:47:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-09-16 05:47:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-16 05:47:28 --> Final output sent to browser
DEBUG - 2020-09-16 05:47:28 --> Total execution time: 0.0391
INFO - 2020-09-16 05:47:39 --> Config Class Initialized
INFO - 2020-09-16 05:47:39 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:47:39 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:47:39 --> Utf8 Class Initialized
INFO - 2020-09-16 05:47:39 --> URI Class Initialized
INFO - 2020-09-16 05:47:39 --> Router Class Initialized
INFO - 2020-09-16 05:47:39 --> Output Class Initialized
INFO - 2020-09-16 05:47:39 --> Security Class Initialized
DEBUG - 2020-09-16 05:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:47:39 --> Input Class Initialized
INFO - 2020-09-16 05:47:39 --> Language Class Initialized
INFO - 2020-09-16 05:47:39 --> Language Class Initialized
INFO - 2020-09-16 05:47:39 --> Config Class Initialized
INFO - 2020-09-16 05:47:39 --> Loader Class Initialized
INFO - 2020-09-16 05:47:39 --> Helper loaded: url_helper
INFO - 2020-09-16 05:47:39 --> Helper loaded: file_helper
INFO - 2020-09-16 05:47:39 --> Helper loaded: form_helper
INFO - 2020-09-16 05:47:39 --> Helper loaded: my_helper
INFO - 2020-09-16 05:47:39 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:47:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:47:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:47:39 --> Controller Class Initialized
INFO - 2020-09-16 05:47:39 --> Helper loaded: cookie_helper
INFO - 2020-09-16 05:47:39 --> Final output sent to browser
DEBUG - 2020-09-16 05:47:39 --> Total execution time: 0.0559
INFO - 2020-09-16 05:47:40 --> Config Class Initialized
INFO - 2020-09-16 05:47:40 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:47:40 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:47:40 --> Utf8 Class Initialized
INFO - 2020-09-16 05:47:40 --> URI Class Initialized
INFO - 2020-09-16 05:47:40 --> Router Class Initialized
INFO - 2020-09-16 05:47:40 --> Output Class Initialized
INFO - 2020-09-16 05:47:40 --> Security Class Initialized
DEBUG - 2020-09-16 05:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:47:40 --> Input Class Initialized
INFO - 2020-09-16 05:47:40 --> Language Class Initialized
INFO - 2020-09-16 05:47:40 --> Language Class Initialized
INFO - 2020-09-16 05:47:40 --> Config Class Initialized
INFO - 2020-09-16 05:47:40 --> Loader Class Initialized
INFO - 2020-09-16 05:47:40 --> Helper loaded: url_helper
INFO - 2020-09-16 05:47:40 --> Helper loaded: file_helper
INFO - 2020-09-16 05:47:40 --> Helper loaded: form_helper
INFO - 2020-09-16 05:47:40 --> Helper loaded: my_helper
INFO - 2020-09-16 05:47:40 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:47:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:47:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:47:40 --> Controller Class Initialized
DEBUG - 2020-09-16 05:47:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-09-16 05:47:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-16 05:47:41 --> Final output sent to browser
DEBUG - 2020-09-16 05:47:41 --> Total execution time: 0.1979
INFO - 2020-09-16 05:47:45 --> Config Class Initialized
INFO - 2020-09-16 05:47:45 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:47:45 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:47:45 --> Utf8 Class Initialized
INFO - 2020-09-16 05:47:45 --> URI Class Initialized
INFO - 2020-09-16 05:47:45 --> Router Class Initialized
INFO - 2020-09-16 05:47:45 --> Output Class Initialized
INFO - 2020-09-16 05:47:45 --> Security Class Initialized
DEBUG - 2020-09-16 05:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:47:45 --> Input Class Initialized
INFO - 2020-09-16 05:47:45 --> Language Class Initialized
INFO - 2020-09-16 05:47:45 --> Language Class Initialized
INFO - 2020-09-16 05:47:45 --> Config Class Initialized
INFO - 2020-09-16 05:47:45 --> Loader Class Initialized
INFO - 2020-09-16 05:47:45 --> Helper loaded: url_helper
INFO - 2020-09-16 05:47:45 --> Helper loaded: file_helper
INFO - 2020-09-16 05:47:45 --> Helper loaded: form_helper
INFO - 2020-09-16 05:47:45 --> Helper loaded: my_helper
INFO - 2020-09-16 05:47:45 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:47:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:47:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:47:46 --> Controller Class Initialized
DEBUG - 2020-09-16 05:47:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2020-09-16 05:47:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-16 05:47:46 --> Final output sent to browser
DEBUG - 2020-09-16 05:47:46 --> Total execution time: 0.0655
INFO - 2020-09-16 05:47:50 --> Config Class Initialized
INFO - 2020-09-16 05:47:50 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:47:50 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:47:50 --> Utf8 Class Initialized
INFO - 2020-09-16 05:47:50 --> URI Class Initialized
INFO - 2020-09-16 05:47:50 --> Router Class Initialized
INFO - 2020-09-16 05:47:50 --> Output Class Initialized
INFO - 2020-09-16 05:47:50 --> Security Class Initialized
DEBUG - 2020-09-16 05:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:47:50 --> Input Class Initialized
INFO - 2020-09-16 05:47:50 --> Language Class Initialized
INFO - 2020-09-16 05:47:50 --> Language Class Initialized
INFO - 2020-09-16 05:47:50 --> Config Class Initialized
INFO - 2020-09-16 05:47:50 --> Loader Class Initialized
INFO - 2020-09-16 05:47:50 --> Helper loaded: url_helper
INFO - 2020-09-16 05:47:50 --> Helper loaded: file_helper
INFO - 2020-09-16 05:47:50 --> Helper loaded: form_helper
INFO - 2020-09-16 05:47:50 --> Helper loaded: my_helper
INFO - 2020-09-16 05:47:50 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:47:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:47:50 --> Controller Class Initialized
INFO - 2020-09-16 05:47:50 --> Helper loaded: cookie_helper
INFO - 2020-09-16 05:47:50 --> Config Class Initialized
INFO - 2020-09-16 05:47:50 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:47:50 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:47:50 --> Utf8 Class Initialized
INFO - 2020-09-16 05:47:50 --> URI Class Initialized
INFO - 2020-09-16 05:47:50 --> Router Class Initialized
INFO - 2020-09-16 05:47:50 --> Output Class Initialized
INFO - 2020-09-16 05:47:50 --> Security Class Initialized
DEBUG - 2020-09-16 05:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:47:50 --> Input Class Initialized
INFO - 2020-09-16 05:47:50 --> Language Class Initialized
INFO - 2020-09-16 05:47:50 --> Language Class Initialized
INFO - 2020-09-16 05:47:50 --> Config Class Initialized
INFO - 2020-09-16 05:47:50 --> Loader Class Initialized
INFO - 2020-09-16 05:47:50 --> Helper loaded: url_helper
INFO - 2020-09-16 05:47:50 --> Helper loaded: file_helper
INFO - 2020-09-16 05:47:50 --> Helper loaded: form_helper
INFO - 2020-09-16 05:47:50 --> Helper loaded: my_helper
INFO - 2020-09-16 05:47:50 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:47:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:47:50 --> Controller Class Initialized
DEBUG - 2020-09-16 05:47:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-09-16 05:47:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-16 05:47:50 --> Final output sent to browser
DEBUG - 2020-09-16 05:47:50 --> Total execution time: 0.0483
INFO - 2020-09-16 05:48:13 --> Config Class Initialized
INFO - 2020-09-16 05:48:13 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:48:13 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:48:13 --> Utf8 Class Initialized
INFO - 2020-09-16 05:48:13 --> URI Class Initialized
INFO - 2020-09-16 05:48:13 --> Router Class Initialized
INFO - 2020-09-16 05:48:13 --> Output Class Initialized
INFO - 2020-09-16 05:48:13 --> Security Class Initialized
DEBUG - 2020-09-16 05:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:48:13 --> Input Class Initialized
INFO - 2020-09-16 05:48:13 --> Language Class Initialized
INFO - 2020-09-16 05:48:13 --> Language Class Initialized
INFO - 2020-09-16 05:48:13 --> Config Class Initialized
INFO - 2020-09-16 05:48:13 --> Loader Class Initialized
INFO - 2020-09-16 05:48:13 --> Helper loaded: url_helper
INFO - 2020-09-16 05:48:13 --> Helper loaded: file_helper
INFO - 2020-09-16 05:48:13 --> Helper loaded: form_helper
INFO - 2020-09-16 05:48:13 --> Helper loaded: my_helper
INFO - 2020-09-16 05:48:13 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:48:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:48:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:48:13 --> Controller Class Initialized
INFO - 2020-09-16 05:48:13 --> Helper loaded: cookie_helper
INFO - 2020-09-16 05:48:13 --> Final output sent to browser
DEBUG - 2020-09-16 05:48:13 --> Total execution time: 0.0563
INFO - 2020-09-16 05:48:14 --> Config Class Initialized
INFO - 2020-09-16 05:48:14 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:48:14 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:48:14 --> Utf8 Class Initialized
INFO - 2020-09-16 05:48:14 --> URI Class Initialized
INFO - 2020-09-16 05:48:14 --> Router Class Initialized
INFO - 2020-09-16 05:48:14 --> Output Class Initialized
INFO - 2020-09-16 05:48:14 --> Security Class Initialized
DEBUG - 2020-09-16 05:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:48:14 --> Input Class Initialized
INFO - 2020-09-16 05:48:14 --> Language Class Initialized
INFO - 2020-09-16 05:48:14 --> Language Class Initialized
INFO - 2020-09-16 05:48:14 --> Config Class Initialized
INFO - 2020-09-16 05:48:14 --> Loader Class Initialized
INFO - 2020-09-16 05:48:14 --> Helper loaded: url_helper
INFO - 2020-09-16 05:48:14 --> Helper loaded: file_helper
INFO - 2020-09-16 05:48:14 --> Helper loaded: form_helper
INFO - 2020-09-16 05:48:14 --> Helper loaded: my_helper
INFO - 2020-09-16 05:48:14 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:48:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:48:14 --> Controller Class Initialized
DEBUG - 2020-09-16 05:48:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-09-16 05:48:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-16 05:48:14 --> Final output sent to browser
DEBUG - 2020-09-16 05:48:14 --> Total execution time: 0.2011
INFO - 2020-09-16 05:48:16 --> Config Class Initialized
INFO - 2020-09-16 05:48:16 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:48:16 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:48:16 --> Utf8 Class Initialized
INFO - 2020-09-16 05:48:16 --> URI Class Initialized
INFO - 2020-09-16 05:48:16 --> Router Class Initialized
INFO - 2020-09-16 05:48:16 --> Output Class Initialized
INFO - 2020-09-16 05:48:16 --> Security Class Initialized
DEBUG - 2020-09-16 05:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:48:16 --> Input Class Initialized
INFO - 2020-09-16 05:48:16 --> Language Class Initialized
INFO - 2020-09-16 05:48:16 --> Language Class Initialized
INFO - 2020-09-16 05:48:16 --> Config Class Initialized
INFO - 2020-09-16 05:48:16 --> Loader Class Initialized
INFO - 2020-09-16 05:48:16 --> Helper loaded: url_helper
INFO - 2020-09-16 05:48:16 --> Helper loaded: file_helper
INFO - 2020-09-16 05:48:16 --> Helper loaded: form_helper
INFO - 2020-09-16 05:48:16 --> Helper loaded: my_helper
INFO - 2020-09-16 05:48:16 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:48:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:48:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:48:16 --> Controller Class Initialized
DEBUG - 2020-09-16 05:48:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2020-09-16 05:48:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-16 05:48:16 --> Final output sent to browser
DEBUG - 2020-09-16 05:48:16 --> Total execution time: 0.0489
INFO - 2020-09-16 05:48:27 --> Config Class Initialized
INFO - 2020-09-16 05:48:27 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:48:27 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:48:27 --> Utf8 Class Initialized
INFO - 2020-09-16 05:48:27 --> URI Class Initialized
INFO - 2020-09-16 05:48:27 --> Router Class Initialized
INFO - 2020-09-16 05:48:27 --> Output Class Initialized
INFO - 2020-09-16 05:48:27 --> Security Class Initialized
DEBUG - 2020-09-16 05:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:48:27 --> Input Class Initialized
INFO - 2020-09-16 05:48:27 --> Language Class Initialized
INFO - 2020-09-16 05:48:27 --> Language Class Initialized
INFO - 2020-09-16 05:48:27 --> Config Class Initialized
INFO - 2020-09-16 05:48:27 --> Loader Class Initialized
INFO - 2020-09-16 05:48:27 --> Helper loaded: url_helper
INFO - 2020-09-16 05:48:27 --> Helper loaded: file_helper
INFO - 2020-09-16 05:48:27 --> Helper loaded: form_helper
INFO - 2020-09-16 05:48:27 --> Helper loaded: my_helper
INFO - 2020-09-16 05:48:27 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:48:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:48:27 --> Controller Class Initialized
DEBUG - 2020-09-16 05:48:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2020-09-16 05:48:27 --> Final output sent to browser
DEBUG - 2020-09-16 05:48:27 --> Total execution time: 0.0813
INFO - 2020-09-16 05:50:49 --> Config Class Initialized
INFO - 2020-09-16 05:50:49 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:50:49 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:50:49 --> Utf8 Class Initialized
INFO - 2020-09-16 05:50:49 --> URI Class Initialized
INFO - 2020-09-16 05:50:49 --> Router Class Initialized
INFO - 2020-09-16 05:50:49 --> Output Class Initialized
INFO - 2020-09-16 05:50:49 --> Security Class Initialized
DEBUG - 2020-09-16 05:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:50:49 --> Input Class Initialized
INFO - 2020-09-16 05:50:49 --> Language Class Initialized
INFO - 2020-09-16 05:50:49 --> Language Class Initialized
INFO - 2020-09-16 05:50:49 --> Config Class Initialized
INFO - 2020-09-16 05:50:49 --> Loader Class Initialized
INFO - 2020-09-16 05:50:49 --> Helper loaded: url_helper
INFO - 2020-09-16 05:50:49 --> Helper loaded: file_helper
INFO - 2020-09-16 05:50:49 --> Helper loaded: form_helper
INFO - 2020-09-16 05:50:49 --> Helper loaded: my_helper
INFO - 2020-09-16 05:50:49 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:50:49 --> Controller Class Initialized
INFO - 2020-09-16 05:50:49 --> Helper loaded: cookie_helper
INFO - 2020-09-16 05:50:49 --> Config Class Initialized
INFO - 2020-09-16 05:50:49 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:50:49 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:50:49 --> Utf8 Class Initialized
INFO - 2020-09-16 05:50:49 --> URI Class Initialized
INFO - 2020-09-16 05:50:49 --> Router Class Initialized
INFO - 2020-09-16 05:50:49 --> Output Class Initialized
INFO - 2020-09-16 05:50:49 --> Security Class Initialized
DEBUG - 2020-09-16 05:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:50:49 --> Input Class Initialized
INFO - 2020-09-16 05:50:49 --> Language Class Initialized
INFO - 2020-09-16 05:50:49 --> Language Class Initialized
INFO - 2020-09-16 05:50:49 --> Config Class Initialized
INFO - 2020-09-16 05:50:49 --> Loader Class Initialized
INFO - 2020-09-16 05:50:49 --> Helper loaded: url_helper
INFO - 2020-09-16 05:50:49 --> Helper loaded: file_helper
INFO - 2020-09-16 05:50:49 --> Helper loaded: form_helper
INFO - 2020-09-16 05:50:49 --> Helper loaded: my_helper
INFO - 2020-09-16 05:50:49 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:50:49 --> Controller Class Initialized
DEBUG - 2020-09-16 05:50:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-09-16 05:50:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-16 05:50:49 --> Final output sent to browser
DEBUG - 2020-09-16 05:50:49 --> Total execution time: 0.0491
INFO - 2020-09-16 05:50:54 --> Config Class Initialized
INFO - 2020-09-16 05:50:54 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:50:54 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:50:54 --> Utf8 Class Initialized
INFO - 2020-09-16 05:50:54 --> URI Class Initialized
INFO - 2020-09-16 05:50:54 --> Router Class Initialized
INFO - 2020-09-16 05:50:54 --> Output Class Initialized
INFO - 2020-09-16 05:50:54 --> Security Class Initialized
DEBUG - 2020-09-16 05:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:50:54 --> Input Class Initialized
INFO - 2020-09-16 05:50:54 --> Language Class Initialized
INFO - 2020-09-16 05:50:54 --> Language Class Initialized
INFO - 2020-09-16 05:50:54 --> Config Class Initialized
INFO - 2020-09-16 05:50:54 --> Loader Class Initialized
INFO - 2020-09-16 05:50:54 --> Helper loaded: url_helper
INFO - 2020-09-16 05:50:54 --> Helper loaded: file_helper
INFO - 2020-09-16 05:50:54 --> Helper loaded: form_helper
INFO - 2020-09-16 05:50:54 --> Helper loaded: my_helper
INFO - 2020-09-16 05:50:54 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:50:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:50:54 --> Controller Class Initialized
INFO - 2020-09-16 05:50:54 --> Helper loaded: cookie_helper
INFO - 2020-09-16 05:50:54 --> Final output sent to browser
DEBUG - 2020-09-16 05:50:54 --> Total execution time: 0.0508
INFO - 2020-09-16 05:50:55 --> Config Class Initialized
INFO - 2020-09-16 05:50:55 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:50:55 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:50:55 --> Utf8 Class Initialized
INFO - 2020-09-16 05:50:55 --> URI Class Initialized
INFO - 2020-09-16 05:50:55 --> Router Class Initialized
INFO - 2020-09-16 05:50:55 --> Output Class Initialized
INFO - 2020-09-16 05:50:55 --> Security Class Initialized
DEBUG - 2020-09-16 05:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:50:55 --> Input Class Initialized
INFO - 2020-09-16 05:50:55 --> Language Class Initialized
INFO - 2020-09-16 05:50:55 --> Language Class Initialized
INFO - 2020-09-16 05:50:55 --> Config Class Initialized
INFO - 2020-09-16 05:50:55 --> Loader Class Initialized
INFO - 2020-09-16 05:50:55 --> Helper loaded: url_helper
INFO - 2020-09-16 05:50:55 --> Helper loaded: file_helper
INFO - 2020-09-16 05:50:55 --> Helper loaded: form_helper
INFO - 2020-09-16 05:50:55 --> Helper loaded: my_helper
INFO - 2020-09-16 05:50:55 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:50:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:50:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:50:55 --> Controller Class Initialized
DEBUG - 2020-09-16 05:50:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-09-16 05:50:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-16 05:50:55 --> Final output sent to browser
DEBUG - 2020-09-16 05:50:55 --> Total execution time: 0.2021
INFO - 2020-09-16 05:51:24 --> Config Class Initialized
INFO - 2020-09-16 05:51:24 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:51:24 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:51:24 --> Utf8 Class Initialized
INFO - 2020-09-16 05:51:24 --> URI Class Initialized
INFO - 2020-09-16 05:51:24 --> Router Class Initialized
INFO - 2020-09-16 05:51:24 --> Output Class Initialized
INFO - 2020-09-16 05:51:24 --> Security Class Initialized
DEBUG - 2020-09-16 05:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:51:24 --> Input Class Initialized
INFO - 2020-09-16 05:51:24 --> Language Class Initialized
INFO - 2020-09-16 05:51:24 --> Language Class Initialized
INFO - 2020-09-16 05:51:24 --> Config Class Initialized
INFO - 2020-09-16 05:51:24 --> Loader Class Initialized
INFO - 2020-09-16 05:51:24 --> Helper loaded: url_helper
INFO - 2020-09-16 05:51:24 --> Helper loaded: file_helper
INFO - 2020-09-16 05:51:24 --> Helper loaded: form_helper
INFO - 2020-09-16 05:51:24 --> Helper loaded: my_helper
INFO - 2020-09-16 05:51:24 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:51:24 --> Controller Class Initialized
DEBUG - 2020-09-16 05:51:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-09-16 05:51:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-16 05:51:24 --> Final output sent to browser
DEBUG - 2020-09-16 05:51:24 --> Total execution time: 0.0543
INFO - 2020-09-16 05:51:30 --> Config Class Initialized
INFO - 2020-09-16 05:51:30 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:51:30 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:51:30 --> Utf8 Class Initialized
INFO - 2020-09-16 05:51:30 --> URI Class Initialized
INFO - 2020-09-16 05:51:30 --> Router Class Initialized
INFO - 2020-09-16 05:51:30 --> Output Class Initialized
INFO - 2020-09-16 05:51:30 --> Security Class Initialized
DEBUG - 2020-09-16 05:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:51:30 --> Input Class Initialized
INFO - 2020-09-16 05:51:30 --> Language Class Initialized
INFO - 2020-09-16 05:51:30 --> Language Class Initialized
INFO - 2020-09-16 05:51:30 --> Config Class Initialized
INFO - 2020-09-16 05:51:30 --> Loader Class Initialized
INFO - 2020-09-16 05:51:30 --> Helper loaded: url_helper
INFO - 2020-09-16 05:51:30 --> Helper loaded: file_helper
INFO - 2020-09-16 05:51:30 --> Helper loaded: form_helper
INFO - 2020-09-16 05:51:30 --> Helper loaded: my_helper
INFO - 2020-09-16 05:51:30 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:51:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:51:30 --> Controller Class Initialized
INFO - 2020-09-16 05:51:30 --> Final output sent to browser
DEBUG - 2020-09-16 05:51:30 --> Total execution time: 0.0718
INFO - 2020-09-16 05:51:35 --> Config Class Initialized
INFO - 2020-09-16 05:51:35 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:51:35 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:51:35 --> Utf8 Class Initialized
INFO - 2020-09-16 05:51:35 --> URI Class Initialized
INFO - 2020-09-16 05:51:35 --> Router Class Initialized
INFO - 2020-09-16 05:51:35 --> Output Class Initialized
INFO - 2020-09-16 05:51:35 --> Security Class Initialized
DEBUG - 2020-09-16 05:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:51:35 --> Input Class Initialized
INFO - 2020-09-16 05:51:35 --> Language Class Initialized
INFO - 2020-09-16 05:51:35 --> Language Class Initialized
INFO - 2020-09-16 05:51:35 --> Config Class Initialized
INFO - 2020-09-16 05:51:35 --> Loader Class Initialized
INFO - 2020-09-16 05:51:35 --> Helper loaded: url_helper
INFO - 2020-09-16 05:51:35 --> Helper loaded: file_helper
INFO - 2020-09-16 05:51:35 --> Helper loaded: form_helper
INFO - 2020-09-16 05:51:35 --> Helper loaded: my_helper
INFO - 2020-09-16 05:51:35 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:51:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:51:35 --> Controller Class Initialized
DEBUG - 2020-09-16 05:51:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-09-16 05:51:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-16 05:51:35 --> Final output sent to browser
DEBUG - 2020-09-16 05:51:35 --> Total execution time: 0.0631
INFO - 2020-09-16 05:51:37 --> Config Class Initialized
INFO - 2020-09-16 05:51:37 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:51:37 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:51:37 --> Utf8 Class Initialized
INFO - 2020-09-16 05:51:37 --> URI Class Initialized
INFO - 2020-09-16 05:51:37 --> Router Class Initialized
INFO - 2020-09-16 05:51:37 --> Output Class Initialized
INFO - 2020-09-16 05:51:37 --> Security Class Initialized
DEBUG - 2020-09-16 05:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:51:37 --> Input Class Initialized
INFO - 2020-09-16 05:51:37 --> Language Class Initialized
INFO - 2020-09-16 05:51:37 --> Language Class Initialized
INFO - 2020-09-16 05:51:37 --> Config Class Initialized
INFO - 2020-09-16 05:51:37 --> Loader Class Initialized
INFO - 2020-09-16 05:51:37 --> Helper loaded: url_helper
INFO - 2020-09-16 05:51:37 --> Helper loaded: file_helper
INFO - 2020-09-16 05:51:37 --> Helper loaded: form_helper
INFO - 2020-09-16 05:51:37 --> Helper loaded: my_helper
INFO - 2020-09-16 05:51:37 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:51:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:51:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:51:37 --> Controller Class Initialized
INFO - 2020-09-16 05:51:37 --> Final output sent to browser
DEBUG - 2020-09-16 05:51:37 --> Total execution time: 0.0731
INFO - 2020-09-16 05:51:39 --> Config Class Initialized
INFO - 2020-09-16 05:51:39 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:51:39 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:51:39 --> Utf8 Class Initialized
INFO - 2020-09-16 05:51:39 --> URI Class Initialized
INFO - 2020-09-16 05:51:39 --> Router Class Initialized
INFO - 2020-09-16 05:51:39 --> Output Class Initialized
INFO - 2020-09-16 05:51:39 --> Security Class Initialized
DEBUG - 2020-09-16 05:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:51:39 --> Input Class Initialized
INFO - 2020-09-16 05:51:39 --> Language Class Initialized
INFO - 2020-09-16 05:51:39 --> Language Class Initialized
INFO - 2020-09-16 05:51:39 --> Config Class Initialized
INFO - 2020-09-16 05:51:39 --> Loader Class Initialized
INFO - 2020-09-16 05:51:39 --> Helper loaded: url_helper
INFO - 2020-09-16 05:51:39 --> Helper loaded: file_helper
INFO - 2020-09-16 05:51:39 --> Helper loaded: form_helper
INFO - 2020-09-16 05:51:39 --> Helper loaded: my_helper
INFO - 2020-09-16 05:51:39 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:51:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:51:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:51:39 --> Controller Class Initialized
INFO - 2020-09-16 05:51:39 --> Final output sent to browser
DEBUG - 2020-09-16 05:51:39 --> Total execution time: 0.0745
INFO - 2020-09-16 05:51:41 --> Config Class Initialized
INFO - 2020-09-16 05:51:41 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:51:41 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:51:41 --> Utf8 Class Initialized
INFO - 2020-09-16 05:51:41 --> URI Class Initialized
INFO - 2020-09-16 05:51:41 --> Router Class Initialized
INFO - 2020-09-16 05:51:41 --> Output Class Initialized
INFO - 2020-09-16 05:51:41 --> Security Class Initialized
DEBUG - 2020-09-16 05:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:51:41 --> Input Class Initialized
INFO - 2020-09-16 05:51:41 --> Language Class Initialized
INFO - 2020-09-16 05:51:41 --> Language Class Initialized
INFO - 2020-09-16 05:51:41 --> Config Class Initialized
INFO - 2020-09-16 05:51:41 --> Loader Class Initialized
INFO - 2020-09-16 05:51:41 --> Helper loaded: url_helper
INFO - 2020-09-16 05:51:41 --> Helper loaded: file_helper
INFO - 2020-09-16 05:51:41 --> Helper loaded: form_helper
INFO - 2020-09-16 05:51:41 --> Helper loaded: my_helper
INFO - 2020-09-16 05:51:41 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:51:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:51:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:51:41 --> Controller Class Initialized
INFO - 2020-09-16 05:51:41 --> Final output sent to browser
DEBUG - 2020-09-16 05:51:41 --> Total execution time: 0.0713
INFO - 2020-09-16 05:51:42 --> Config Class Initialized
INFO - 2020-09-16 05:51:42 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:51:42 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:51:42 --> Utf8 Class Initialized
INFO - 2020-09-16 05:51:42 --> URI Class Initialized
INFO - 2020-09-16 05:51:42 --> Router Class Initialized
INFO - 2020-09-16 05:51:42 --> Output Class Initialized
INFO - 2020-09-16 05:51:42 --> Security Class Initialized
DEBUG - 2020-09-16 05:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:51:42 --> Input Class Initialized
INFO - 2020-09-16 05:51:42 --> Language Class Initialized
INFO - 2020-09-16 05:51:42 --> Language Class Initialized
INFO - 2020-09-16 05:51:42 --> Config Class Initialized
INFO - 2020-09-16 05:51:42 --> Loader Class Initialized
INFO - 2020-09-16 05:51:42 --> Helper loaded: url_helper
INFO - 2020-09-16 05:51:42 --> Helper loaded: file_helper
INFO - 2020-09-16 05:51:42 --> Helper loaded: form_helper
INFO - 2020-09-16 05:51:42 --> Helper loaded: my_helper
INFO - 2020-09-16 05:51:42 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:51:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:51:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:51:42 --> Controller Class Initialized
INFO - 2020-09-16 05:51:43 --> Final output sent to browser
DEBUG - 2020-09-16 05:51:43 --> Total execution time: 0.0615
INFO - 2020-09-16 05:51:44 --> Config Class Initialized
INFO - 2020-09-16 05:51:44 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:51:44 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:51:44 --> Utf8 Class Initialized
INFO - 2020-09-16 05:51:44 --> URI Class Initialized
INFO - 2020-09-16 05:51:44 --> Router Class Initialized
INFO - 2020-09-16 05:51:44 --> Output Class Initialized
INFO - 2020-09-16 05:51:44 --> Security Class Initialized
DEBUG - 2020-09-16 05:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:51:44 --> Input Class Initialized
INFO - 2020-09-16 05:51:44 --> Language Class Initialized
INFO - 2020-09-16 05:51:44 --> Language Class Initialized
INFO - 2020-09-16 05:51:44 --> Config Class Initialized
INFO - 2020-09-16 05:51:44 --> Loader Class Initialized
INFO - 2020-09-16 05:51:44 --> Helper loaded: url_helper
INFO - 2020-09-16 05:51:44 --> Helper loaded: file_helper
INFO - 2020-09-16 05:51:44 --> Helper loaded: form_helper
INFO - 2020-09-16 05:51:44 --> Helper loaded: my_helper
INFO - 2020-09-16 05:51:44 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:51:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:51:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:51:44 --> Controller Class Initialized
INFO - 2020-09-16 05:51:44 --> Final output sent to browser
DEBUG - 2020-09-16 05:51:44 --> Total execution time: 0.0744
INFO - 2020-09-16 05:51:46 --> Config Class Initialized
INFO - 2020-09-16 05:51:46 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:51:46 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:51:46 --> Utf8 Class Initialized
INFO - 2020-09-16 05:51:46 --> URI Class Initialized
INFO - 2020-09-16 05:51:46 --> Router Class Initialized
INFO - 2020-09-16 05:51:46 --> Output Class Initialized
INFO - 2020-09-16 05:51:46 --> Security Class Initialized
DEBUG - 2020-09-16 05:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:51:46 --> Input Class Initialized
INFO - 2020-09-16 05:51:46 --> Language Class Initialized
INFO - 2020-09-16 05:51:46 --> Language Class Initialized
INFO - 2020-09-16 05:51:46 --> Config Class Initialized
INFO - 2020-09-16 05:51:46 --> Loader Class Initialized
INFO - 2020-09-16 05:51:46 --> Helper loaded: url_helper
INFO - 2020-09-16 05:51:46 --> Helper loaded: file_helper
INFO - 2020-09-16 05:51:46 --> Helper loaded: form_helper
INFO - 2020-09-16 05:51:46 --> Helper loaded: my_helper
INFO - 2020-09-16 05:51:46 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:51:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:51:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:51:46 --> Controller Class Initialized
INFO - 2020-09-16 05:51:46 --> Final output sent to browser
DEBUG - 2020-09-16 05:51:46 --> Total execution time: 0.0713
INFO - 2020-09-16 05:51:47 --> Config Class Initialized
INFO - 2020-09-16 05:51:47 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:51:47 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:51:47 --> Utf8 Class Initialized
INFO - 2020-09-16 05:51:47 --> URI Class Initialized
INFO - 2020-09-16 05:51:47 --> Router Class Initialized
INFO - 2020-09-16 05:51:47 --> Output Class Initialized
INFO - 2020-09-16 05:51:47 --> Security Class Initialized
DEBUG - 2020-09-16 05:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:51:47 --> Input Class Initialized
INFO - 2020-09-16 05:51:47 --> Language Class Initialized
INFO - 2020-09-16 05:51:47 --> Language Class Initialized
INFO - 2020-09-16 05:51:47 --> Config Class Initialized
INFO - 2020-09-16 05:51:47 --> Loader Class Initialized
INFO - 2020-09-16 05:51:47 --> Helper loaded: url_helper
INFO - 2020-09-16 05:51:47 --> Helper loaded: file_helper
INFO - 2020-09-16 05:51:47 --> Helper loaded: form_helper
INFO - 2020-09-16 05:51:47 --> Helper loaded: my_helper
INFO - 2020-09-16 05:51:47 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:51:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:51:47 --> Controller Class Initialized
DEBUG - 2020-09-16 05:51:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-09-16 05:51:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-16 05:51:47 --> Final output sent to browser
DEBUG - 2020-09-16 05:51:47 --> Total execution time: 0.0644
INFO - 2020-09-16 05:51:49 --> Config Class Initialized
INFO - 2020-09-16 05:51:49 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:51:49 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:51:49 --> Utf8 Class Initialized
INFO - 2020-09-16 05:51:49 --> URI Class Initialized
INFO - 2020-09-16 05:51:49 --> Router Class Initialized
INFO - 2020-09-16 05:51:49 --> Output Class Initialized
INFO - 2020-09-16 05:51:49 --> Security Class Initialized
DEBUG - 2020-09-16 05:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:51:49 --> Input Class Initialized
INFO - 2020-09-16 05:51:49 --> Language Class Initialized
INFO - 2020-09-16 05:51:49 --> Language Class Initialized
INFO - 2020-09-16 05:51:49 --> Config Class Initialized
INFO - 2020-09-16 05:51:49 --> Loader Class Initialized
INFO - 2020-09-16 05:51:49 --> Helper loaded: url_helper
INFO - 2020-09-16 05:51:49 --> Helper loaded: file_helper
INFO - 2020-09-16 05:51:49 --> Helper loaded: form_helper
INFO - 2020-09-16 05:51:49 --> Helper loaded: my_helper
INFO - 2020-09-16 05:51:49 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:51:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:51:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:51:49 --> Controller Class Initialized
INFO - 2020-09-16 05:51:49 --> Final output sent to browser
DEBUG - 2020-09-16 05:51:49 --> Total execution time: 0.0716
INFO - 2020-09-16 05:51:51 --> Config Class Initialized
INFO - 2020-09-16 05:51:51 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:51:51 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:51:51 --> Utf8 Class Initialized
INFO - 2020-09-16 05:51:51 --> URI Class Initialized
INFO - 2020-09-16 05:51:51 --> Router Class Initialized
INFO - 2020-09-16 05:51:51 --> Output Class Initialized
INFO - 2020-09-16 05:51:51 --> Security Class Initialized
DEBUG - 2020-09-16 05:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:51:51 --> Input Class Initialized
INFO - 2020-09-16 05:51:51 --> Language Class Initialized
INFO - 2020-09-16 05:51:51 --> Language Class Initialized
INFO - 2020-09-16 05:51:51 --> Config Class Initialized
INFO - 2020-09-16 05:51:51 --> Loader Class Initialized
INFO - 2020-09-16 05:51:51 --> Helper loaded: url_helper
INFO - 2020-09-16 05:51:51 --> Helper loaded: file_helper
INFO - 2020-09-16 05:51:51 --> Helper loaded: form_helper
INFO - 2020-09-16 05:51:51 --> Helper loaded: my_helper
INFO - 2020-09-16 05:51:51 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:51:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:51:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:51:51 --> Controller Class Initialized
INFO - 2020-09-16 05:51:51 --> Final output sent to browser
DEBUG - 2020-09-16 05:51:51 --> Total execution time: 0.0724
INFO - 2020-09-16 05:51:53 --> Config Class Initialized
INFO - 2020-09-16 05:51:53 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:51:53 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:51:53 --> Utf8 Class Initialized
INFO - 2020-09-16 05:51:53 --> URI Class Initialized
INFO - 2020-09-16 05:51:53 --> Router Class Initialized
INFO - 2020-09-16 05:51:53 --> Output Class Initialized
INFO - 2020-09-16 05:51:53 --> Security Class Initialized
DEBUG - 2020-09-16 05:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:51:53 --> Input Class Initialized
INFO - 2020-09-16 05:51:53 --> Language Class Initialized
INFO - 2020-09-16 05:51:53 --> Language Class Initialized
INFO - 2020-09-16 05:51:53 --> Config Class Initialized
INFO - 2020-09-16 05:51:53 --> Loader Class Initialized
INFO - 2020-09-16 05:51:53 --> Helper loaded: url_helper
INFO - 2020-09-16 05:51:53 --> Helper loaded: file_helper
INFO - 2020-09-16 05:51:53 --> Helper loaded: form_helper
INFO - 2020-09-16 05:51:53 --> Helper loaded: my_helper
INFO - 2020-09-16 05:51:53 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:51:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:51:53 --> Controller Class Initialized
INFO - 2020-09-16 05:51:53 --> Final output sent to browser
DEBUG - 2020-09-16 05:51:53 --> Total execution time: 0.0628
INFO - 2020-09-16 05:51:55 --> Config Class Initialized
INFO - 2020-09-16 05:51:55 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:51:55 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:51:55 --> Utf8 Class Initialized
INFO - 2020-09-16 05:51:55 --> URI Class Initialized
INFO - 2020-09-16 05:51:55 --> Router Class Initialized
INFO - 2020-09-16 05:51:55 --> Output Class Initialized
INFO - 2020-09-16 05:51:55 --> Security Class Initialized
DEBUG - 2020-09-16 05:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:51:55 --> Input Class Initialized
INFO - 2020-09-16 05:51:55 --> Language Class Initialized
INFO - 2020-09-16 05:51:55 --> Language Class Initialized
INFO - 2020-09-16 05:51:55 --> Config Class Initialized
INFO - 2020-09-16 05:51:55 --> Loader Class Initialized
INFO - 2020-09-16 05:51:55 --> Helper loaded: url_helper
INFO - 2020-09-16 05:51:55 --> Helper loaded: file_helper
INFO - 2020-09-16 05:51:55 --> Helper loaded: form_helper
INFO - 2020-09-16 05:51:55 --> Helper loaded: my_helper
INFO - 2020-09-16 05:51:55 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:51:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:51:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:51:55 --> Controller Class Initialized
INFO - 2020-09-16 05:51:55 --> Final output sent to browser
DEBUG - 2020-09-16 05:51:55 --> Total execution time: 0.0607
INFO - 2020-09-16 05:51:57 --> Config Class Initialized
INFO - 2020-09-16 05:51:57 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:51:57 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:51:57 --> Utf8 Class Initialized
INFO - 2020-09-16 05:51:57 --> URI Class Initialized
INFO - 2020-09-16 05:51:57 --> Router Class Initialized
INFO - 2020-09-16 05:51:57 --> Output Class Initialized
INFO - 2020-09-16 05:51:57 --> Security Class Initialized
DEBUG - 2020-09-16 05:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:51:57 --> Input Class Initialized
INFO - 2020-09-16 05:51:57 --> Language Class Initialized
INFO - 2020-09-16 05:51:57 --> Language Class Initialized
INFO - 2020-09-16 05:51:57 --> Config Class Initialized
INFO - 2020-09-16 05:51:57 --> Loader Class Initialized
INFO - 2020-09-16 05:51:57 --> Helper loaded: url_helper
INFO - 2020-09-16 05:51:57 --> Helper loaded: file_helper
INFO - 2020-09-16 05:51:57 --> Helper loaded: form_helper
INFO - 2020-09-16 05:51:57 --> Helper loaded: my_helper
INFO - 2020-09-16 05:51:57 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:51:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:51:57 --> Controller Class Initialized
INFO - 2020-09-16 05:51:57 --> Final output sent to browser
DEBUG - 2020-09-16 05:51:57 --> Total execution time: 0.0730
INFO - 2020-09-16 05:51:58 --> Config Class Initialized
INFO - 2020-09-16 05:51:58 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:51:58 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:51:58 --> Utf8 Class Initialized
INFO - 2020-09-16 05:51:58 --> URI Class Initialized
INFO - 2020-09-16 05:51:58 --> Router Class Initialized
INFO - 2020-09-16 05:51:58 --> Output Class Initialized
INFO - 2020-09-16 05:51:58 --> Security Class Initialized
DEBUG - 2020-09-16 05:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:51:58 --> Input Class Initialized
INFO - 2020-09-16 05:51:58 --> Language Class Initialized
INFO - 2020-09-16 05:51:58 --> Language Class Initialized
INFO - 2020-09-16 05:51:58 --> Config Class Initialized
INFO - 2020-09-16 05:51:58 --> Loader Class Initialized
INFO - 2020-09-16 05:51:58 --> Helper loaded: url_helper
INFO - 2020-09-16 05:51:58 --> Helper loaded: file_helper
INFO - 2020-09-16 05:51:58 --> Helper loaded: form_helper
INFO - 2020-09-16 05:51:58 --> Helper loaded: my_helper
INFO - 2020-09-16 05:51:58 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:51:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:51:58 --> Controller Class Initialized
DEBUG - 2020-09-16 05:51:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-09-16 05:51:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-16 05:51:58 --> Final output sent to browser
DEBUG - 2020-09-16 05:51:58 --> Total execution time: 0.0620
INFO - 2020-09-16 05:52:01 --> Config Class Initialized
INFO - 2020-09-16 05:52:01 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:52:01 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:52:01 --> Utf8 Class Initialized
INFO - 2020-09-16 05:52:01 --> URI Class Initialized
INFO - 2020-09-16 05:52:01 --> Router Class Initialized
INFO - 2020-09-16 05:52:01 --> Output Class Initialized
INFO - 2020-09-16 05:52:01 --> Security Class Initialized
DEBUG - 2020-09-16 05:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:52:01 --> Input Class Initialized
INFO - 2020-09-16 05:52:01 --> Language Class Initialized
INFO - 2020-09-16 05:52:01 --> Language Class Initialized
INFO - 2020-09-16 05:52:01 --> Config Class Initialized
INFO - 2020-09-16 05:52:01 --> Loader Class Initialized
INFO - 2020-09-16 05:52:01 --> Helper loaded: url_helper
INFO - 2020-09-16 05:52:01 --> Helper loaded: file_helper
INFO - 2020-09-16 05:52:01 --> Helper loaded: form_helper
INFO - 2020-09-16 05:52:01 --> Helper loaded: my_helper
INFO - 2020-09-16 05:52:01 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:52:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:52:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:52:01 --> Controller Class Initialized
INFO - 2020-09-16 05:52:01 --> Final output sent to browser
DEBUG - 2020-09-16 05:52:01 --> Total execution time: 0.0618
INFO - 2020-09-16 05:52:03 --> Config Class Initialized
INFO - 2020-09-16 05:52:03 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:52:03 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:52:03 --> Utf8 Class Initialized
INFO - 2020-09-16 05:52:03 --> URI Class Initialized
INFO - 2020-09-16 05:52:03 --> Router Class Initialized
INFO - 2020-09-16 05:52:03 --> Output Class Initialized
INFO - 2020-09-16 05:52:03 --> Security Class Initialized
DEBUG - 2020-09-16 05:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:52:03 --> Input Class Initialized
INFO - 2020-09-16 05:52:03 --> Language Class Initialized
INFO - 2020-09-16 05:52:03 --> Language Class Initialized
INFO - 2020-09-16 05:52:03 --> Config Class Initialized
INFO - 2020-09-16 05:52:03 --> Loader Class Initialized
INFO - 2020-09-16 05:52:03 --> Helper loaded: url_helper
INFO - 2020-09-16 05:52:03 --> Helper loaded: file_helper
INFO - 2020-09-16 05:52:03 --> Helper loaded: form_helper
INFO - 2020-09-16 05:52:03 --> Helper loaded: my_helper
INFO - 2020-09-16 05:52:03 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:52:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:52:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:52:03 --> Controller Class Initialized
INFO - 2020-09-16 05:52:03 --> Final output sent to browser
DEBUG - 2020-09-16 05:52:03 --> Total execution time: 0.0730
INFO - 2020-09-16 05:52:05 --> Config Class Initialized
INFO - 2020-09-16 05:52:05 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:52:05 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:52:05 --> Utf8 Class Initialized
INFO - 2020-09-16 05:52:05 --> URI Class Initialized
INFO - 2020-09-16 05:52:05 --> Router Class Initialized
INFO - 2020-09-16 05:52:05 --> Output Class Initialized
INFO - 2020-09-16 05:52:05 --> Security Class Initialized
DEBUG - 2020-09-16 05:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:52:05 --> Input Class Initialized
INFO - 2020-09-16 05:52:05 --> Language Class Initialized
INFO - 2020-09-16 05:52:05 --> Language Class Initialized
INFO - 2020-09-16 05:52:05 --> Config Class Initialized
INFO - 2020-09-16 05:52:05 --> Loader Class Initialized
INFO - 2020-09-16 05:52:05 --> Helper loaded: url_helper
INFO - 2020-09-16 05:52:05 --> Helper loaded: file_helper
INFO - 2020-09-16 05:52:05 --> Helper loaded: form_helper
INFO - 2020-09-16 05:52:05 --> Helper loaded: my_helper
INFO - 2020-09-16 05:52:05 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:52:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:52:05 --> Controller Class Initialized
INFO - 2020-09-16 05:52:05 --> Final output sent to browser
DEBUG - 2020-09-16 05:52:05 --> Total execution time: 0.0639
INFO - 2020-09-16 05:52:07 --> Config Class Initialized
INFO - 2020-09-16 05:52:07 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:52:07 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:52:07 --> Utf8 Class Initialized
INFO - 2020-09-16 05:52:07 --> URI Class Initialized
INFO - 2020-09-16 05:52:07 --> Router Class Initialized
INFO - 2020-09-16 05:52:07 --> Output Class Initialized
INFO - 2020-09-16 05:52:07 --> Security Class Initialized
DEBUG - 2020-09-16 05:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:52:07 --> Input Class Initialized
INFO - 2020-09-16 05:52:07 --> Language Class Initialized
INFO - 2020-09-16 05:52:07 --> Language Class Initialized
INFO - 2020-09-16 05:52:07 --> Config Class Initialized
INFO - 2020-09-16 05:52:07 --> Loader Class Initialized
INFO - 2020-09-16 05:52:07 --> Helper loaded: url_helper
INFO - 2020-09-16 05:52:07 --> Helper loaded: file_helper
INFO - 2020-09-16 05:52:07 --> Helper loaded: form_helper
INFO - 2020-09-16 05:52:07 --> Helper loaded: my_helper
INFO - 2020-09-16 05:52:07 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:52:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:52:07 --> Controller Class Initialized
INFO - 2020-09-16 05:52:07 --> Final output sent to browser
DEBUG - 2020-09-16 05:52:07 --> Total execution time: 0.0718
INFO - 2020-09-16 05:52:08 --> Config Class Initialized
INFO - 2020-09-16 05:52:08 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:52:08 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:52:08 --> Utf8 Class Initialized
INFO - 2020-09-16 05:52:08 --> URI Class Initialized
INFO - 2020-09-16 05:52:08 --> Router Class Initialized
INFO - 2020-09-16 05:52:08 --> Output Class Initialized
INFO - 2020-09-16 05:52:08 --> Security Class Initialized
DEBUG - 2020-09-16 05:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:52:08 --> Input Class Initialized
INFO - 2020-09-16 05:52:08 --> Language Class Initialized
INFO - 2020-09-16 05:52:08 --> Language Class Initialized
INFO - 2020-09-16 05:52:08 --> Config Class Initialized
INFO - 2020-09-16 05:52:08 --> Loader Class Initialized
INFO - 2020-09-16 05:52:08 --> Helper loaded: url_helper
INFO - 2020-09-16 05:52:08 --> Helper loaded: file_helper
INFO - 2020-09-16 05:52:08 --> Helper loaded: form_helper
INFO - 2020-09-16 05:52:08 --> Helper loaded: my_helper
INFO - 2020-09-16 05:52:08 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:52:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:52:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:52:08 --> Controller Class Initialized
INFO - 2020-09-16 05:52:08 --> Final output sent to browser
DEBUG - 2020-09-16 05:52:08 --> Total execution time: 0.0764
INFO - 2020-09-16 05:52:10 --> Config Class Initialized
INFO - 2020-09-16 05:52:10 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:52:10 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:52:10 --> Utf8 Class Initialized
INFO - 2020-09-16 05:52:10 --> URI Class Initialized
INFO - 2020-09-16 05:52:10 --> Router Class Initialized
INFO - 2020-09-16 05:52:10 --> Output Class Initialized
INFO - 2020-09-16 05:52:10 --> Security Class Initialized
DEBUG - 2020-09-16 05:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:52:10 --> Input Class Initialized
INFO - 2020-09-16 05:52:10 --> Language Class Initialized
INFO - 2020-09-16 05:52:10 --> Language Class Initialized
INFO - 2020-09-16 05:52:10 --> Config Class Initialized
INFO - 2020-09-16 05:52:10 --> Loader Class Initialized
INFO - 2020-09-16 05:52:10 --> Helper loaded: url_helper
INFO - 2020-09-16 05:52:10 --> Helper loaded: file_helper
INFO - 2020-09-16 05:52:10 --> Helper loaded: form_helper
INFO - 2020-09-16 05:52:10 --> Helper loaded: my_helper
INFO - 2020-09-16 05:52:10 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:52:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:52:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:52:10 --> Controller Class Initialized
INFO - 2020-09-16 05:52:10 --> Final output sent to browser
DEBUG - 2020-09-16 05:52:10 --> Total execution time: 0.0717
INFO - 2020-09-16 05:52:11 --> Config Class Initialized
INFO - 2020-09-16 05:52:11 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:52:11 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:52:11 --> Utf8 Class Initialized
INFO - 2020-09-16 05:52:11 --> URI Class Initialized
INFO - 2020-09-16 05:52:11 --> Router Class Initialized
INFO - 2020-09-16 05:52:11 --> Output Class Initialized
INFO - 2020-09-16 05:52:11 --> Security Class Initialized
DEBUG - 2020-09-16 05:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:52:11 --> Input Class Initialized
INFO - 2020-09-16 05:52:11 --> Language Class Initialized
INFO - 2020-09-16 05:52:11 --> Language Class Initialized
INFO - 2020-09-16 05:52:11 --> Config Class Initialized
INFO - 2020-09-16 05:52:11 --> Loader Class Initialized
INFO - 2020-09-16 05:52:11 --> Helper loaded: url_helper
INFO - 2020-09-16 05:52:11 --> Helper loaded: file_helper
INFO - 2020-09-16 05:52:11 --> Helper loaded: form_helper
INFO - 2020-09-16 05:52:11 --> Helper loaded: my_helper
INFO - 2020-09-16 05:52:11 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:52:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:52:11 --> Controller Class Initialized
DEBUG - 2020-09-16 05:52:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-09-16 05:52:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-16 05:52:11 --> Final output sent to browser
DEBUG - 2020-09-16 05:52:11 --> Total execution time: 0.0570
INFO - 2020-09-16 05:52:13 --> Config Class Initialized
INFO - 2020-09-16 05:52:13 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:52:13 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:52:13 --> Utf8 Class Initialized
INFO - 2020-09-16 05:52:13 --> URI Class Initialized
INFO - 2020-09-16 05:52:13 --> Router Class Initialized
INFO - 2020-09-16 05:52:13 --> Output Class Initialized
INFO - 2020-09-16 05:52:13 --> Security Class Initialized
DEBUG - 2020-09-16 05:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:52:13 --> Input Class Initialized
INFO - 2020-09-16 05:52:13 --> Language Class Initialized
INFO - 2020-09-16 05:52:13 --> Language Class Initialized
INFO - 2020-09-16 05:52:13 --> Config Class Initialized
INFO - 2020-09-16 05:52:13 --> Loader Class Initialized
INFO - 2020-09-16 05:52:13 --> Helper loaded: url_helper
INFO - 2020-09-16 05:52:13 --> Helper loaded: file_helper
INFO - 2020-09-16 05:52:13 --> Helper loaded: form_helper
INFO - 2020-09-16 05:52:13 --> Helper loaded: my_helper
INFO - 2020-09-16 05:52:13 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:52:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:52:13 --> Controller Class Initialized
INFO - 2020-09-16 05:52:13 --> Final output sent to browser
DEBUG - 2020-09-16 05:52:13 --> Total execution time: 0.0631
INFO - 2020-09-16 05:52:15 --> Config Class Initialized
INFO - 2020-09-16 05:52:15 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:52:15 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:52:15 --> Utf8 Class Initialized
INFO - 2020-09-16 05:52:15 --> URI Class Initialized
INFO - 2020-09-16 05:52:15 --> Router Class Initialized
INFO - 2020-09-16 05:52:15 --> Output Class Initialized
INFO - 2020-09-16 05:52:15 --> Security Class Initialized
DEBUG - 2020-09-16 05:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:52:15 --> Input Class Initialized
INFO - 2020-09-16 05:52:15 --> Language Class Initialized
INFO - 2020-09-16 05:52:15 --> Language Class Initialized
INFO - 2020-09-16 05:52:15 --> Config Class Initialized
INFO - 2020-09-16 05:52:15 --> Loader Class Initialized
INFO - 2020-09-16 05:52:15 --> Helper loaded: url_helper
INFO - 2020-09-16 05:52:15 --> Helper loaded: file_helper
INFO - 2020-09-16 05:52:15 --> Helper loaded: form_helper
INFO - 2020-09-16 05:52:15 --> Helper loaded: my_helper
INFO - 2020-09-16 05:52:15 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:52:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:52:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:52:15 --> Controller Class Initialized
INFO - 2020-09-16 05:52:15 --> Final output sent to browser
DEBUG - 2020-09-16 05:52:15 --> Total execution time: 0.0721
INFO - 2020-09-16 05:52:17 --> Config Class Initialized
INFO - 2020-09-16 05:52:17 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:52:17 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:52:17 --> Utf8 Class Initialized
INFO - 2020-09-16 05:52:17 --> URI Class Initialized
INFO - 2020-09-16 05:52:17 --> Router Class Initialized
INFO - 2020-09-16 05:52:17 --> Output Class Initialized
INFO - 2020-09-16 05:52:17 --> Security Class Initialized
DEBUG - 2020-09-16 05:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:52:17 --> Input Class Initialized
INFO - 2020-09-16 05:52:17 --> Language Class Initialized
INFO - 2020-09-16 05:52:17 --> Language Class Initialized
INFO - 2020-09-16 05:52:17 --> Config Class Initialized
INFO - 2020-09-16 05:52:17 --> Loader Class Initialized
INFO - 2020-09-16 05:52:17 --> Helper loaded: url_helper
INFO - 2020-09-16 05:52:17 --> Helper loaded: file_helper
INFO - 2020-09-16 05:52:17 --> Helper loaded: form_helper
INFO - 2020-09-16 05:52:17 --> Helper loaded: my_helper
INFO - 2020-09-16 05:52:17 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:52:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:52:17 --> Controller Class Initialized
INFO - 2020-09-16 05:52:17 --> Final output sent to browser
DEBUG - 2020-09-16 05:52:17 --> Total execution time: 0.0621
INFO - 2020-09-16 05:52:19 --> Config Class Initialized
INFO - 2020-09-16 05:52:19 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:52:19 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:52:19 --> Utf8 Class Initialized
INFO - 2020-09-16 05:52:19 --> URI Class Initialized
INFO - 2020-09-16 05:52:19 --> Router Class Initialized
INFO - 2020-09-16 05:52:19 --> Output Class Initialized
INFO - 2020-09-16 05:52:19 --> Security Class Initialized
DEBUG - 2020-09-16 05:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:52:19 --> Input Class Initialized
INFO - 2020-09-16 05:52:19 --> Language Class Initialized
INFO - 2020-09-16 05:52:19 --> Language Class Initialized
INFO - 2020-09-16 05:52:19 --> Config Class Initialized
INFO - 2020-09-16 05:52:19 --> Loader Class Initialized
INFO - 2020-09-16 05:52:19 --> Helper loaded: url_helper
INFO - 2020-09-16 05:52:19 --> Helper loaded: file_helper
INFO - 2020-09-16 05:52:19 --> Helper loaded: form_helper
INFO - 2020-09-16 05:52:19 --> Helper loaded: my_helper
INFO - 2020-09-16 05:52:19 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:52:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:52:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:52:19 --> Controller Class Initialized
INFO - 2020-09-16 05:52:19 --> Final output sent to browser
DEBUG - 2020-09-16 05:52:19 --> Total execution time: 0.0619
INFO - 2020-09-16 05:52:21 --> Config Class Initialized
INFO - 2020-09-16 05:52:21 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:52:21 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:52:21 --> Utf8 Class Initialized
INFO - 2020-09-16 05:52:21 --> URI Class Initialized
INFO - 2020-09-16 05:52:21 --> Router Class Initialized
INFO - 2020-09-16 05:52:21 --> Output Class Initialized
INFO - 2020-09-16 05:52:21 --> Security Class Initialized
DEBUG - 2020-09-16 05:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:52:21 --> Input Class Initialized
INFO - 2020-09-16 05:52:21 --> Language Class Initialized
INFO - 2020-09-16 05:52:21 --> Language Class Initialized
INFO - 2020-09-16 05:52:21 --> Config Class Initialized
INFO - 2020-09-16 05:52:21 --> Loader Class Initialized
INFO - 2020-09-16 05:52:21 --> Helper loaded: url_helper
INFO - 2020-09-16 05:52:21 --> Helper loaded: file_helper
INFO - 2020-09-16 05:52:21 --> Helper loaded: form_helper
INFO - 2020-09-16 05:52:21 --> Helper loaded: my_helper
INFO - 2020-09-16 05:52:21 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:52:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:52:21 --> Controller Class Initialized
INFO - 2020-09-16 05:52:21 --> Final output sent to browser
DEBUG - 2020-09-16 05:52:21 --> Total execution time: 0.0770
INFO - 2020-09-16 05:52:22 --> Config Class Initialized
INFO - 2020-09-16 05:52:22 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:52:22 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:52:22 --> Utf8 Class Initialized
INFO - 2020-09-16 05:52:22 --> URI Class Initialized
INFO - 2020-09-16 05:52:22 --> Router Class Initialized
INFO - 2020-09-16 05:52:22 --> Output Class Initialized
INFO - 2020-09-16 05:52:22 --> Security Class Initialized
DEBUG - 2020-09-16 05:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:52:22 --> Input Class Initialized
INFO - 2020-09-16 05:52:22 --> Language Class Initialized
INFO - 2020-09-16 05:52:22 --> Language Class Initialized
INFO - 2020-09-16 05:52:22 --> Config Class Initialized
INFO - 2020-09-16 05:52:22 --> Loader Class Initialized
INFO - 2020-09-16 05:52:22 --> Helper loaded: url_helper
INFO - 2020-09-16 05:52:22 --> Helper loaded: file_helper
INFO - 2020-09-16 05:52:22 --> Helper loaded: form_helper
INFO - 2020-09-16 05:52:22 --> Helper loaded: my_helper
INFO - 2020-09-16 05:52:22 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:52:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:52:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:52:22 --> Controller Class Initialized
DEBUG - 2020-09-16 05:52:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-09-16 05:52:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-16 05:52:22 --> Final output sent to browser
DEBUG - 2020-09-16 05:52:22 --> Total execution time: 0.0529
INFO - 2020-09-16 05:52:25 --> Config Class Initialized
INFO - 2020-09-16 05:52:25 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:52:25 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:52:25 --> Utf8 Class Initialized
INFO - 2020-09-16 05:52:25 --> URI Class Initialized
INFO - 2020-09-16 05:52:25 --> Router Class Initialized
INFO - 2020-09-16 05:52:25 --> Output Class Initialized
INFO - 2020-09-16 05:52:25 --> Security Class Initialized
DEBUG - 2020-09-16 05:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:52:25 --> Input Class Initialized
INFO - 2020-09-16 05:52:25 --> Language Class Initialized
INFO - 2020-09-16 05:52:25 --> Language Class Initialized
INFO - 2020-09-16 05:52:25 --> Config Class Initialized
INFO - 2020-09-16 05:52:25 --> Loader Class Initialized
INFO - 2020-09-16 05:52:25 --> Helper loaded: url_helper
INFO - 2020-09-16 05:52:25 --> Helper loaded: file_helper
INFO - 2020-09-16 05:52:25 --> Helper loaded: form_helper
INFO - 2020-09-16 05:52:25 --> Helper loaded: my_helper
INFO - 2020-09-16 05:52:25 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:52:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:52:25 --> Controller Class Initialized
INFO - 2020-09-16 05:52:25 --> Final output sent to browser
DEBUG - 2020-09-16 05:52:25 --> Total execution time: 0.0628
INFO - 2020-09-16 05:52:26 --> Config Class Initialized
INFO - 2020-09-16 05:52:26 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:52:26 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:52:26 --> Utf8 Class Initialized
INFO - 2020-09-16 05:52:26 --> URI Class Initialized
INFO - 2020-09-16 05:52:26 --> Router Class Initialized
INFO - 2020-09-16 05:52:26 --> Output Class Initialized
INFO - 2020-09-16 05:52:26 --> Security Class Initialized
DEBUG - 2020-09-16 05:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:52:26 --> Input Class Initialized
INFO - 2020-09-16 05:52:26 --> Language Class Initialized
INFO - 2020-09-16 05:52:26 --> Language Class Initialized
INFO - 2020-09-16 05:52:26 --> Config Class Initialized
INFO - 2020-09-16 05:52:26 --> Loader Class Initialized
INFO - 2020-09-16 05:52:26 --> Helper loaded: url_helper
INFO - 2020-09-16 05:52:26 --> Helper loaded: file_helper
INFO - 2020-09-16 05:52:26 --> Helper loaded: form_helper
INFO - 2020-09-16 05:52:26 --> Helper loaded: my_helper
INFO - 2020-09-16 05:52:26 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:52:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:52:26 --> Controller Class Initialized
INFO - 2020-09-16 05:52:26 --> Final output sent to browser
DEBUG - 2020-09-16 05:52:26 --> Total execution time: 0.0626
INFO - 2020-09-16 05:52:28 --> Config Class Initialized
INFO - 2020-09-16 05:52:28 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:52:28 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:52:28 --> Utf8 Class Initialized
INFO - 2020-09-16 05:52:28 --> URI Class Initialized
INFO - 2020-09-16 05:52:28 --> Router Class Initialized
INFO - 2020-09-16 05:52:28 --> Output Class Initialized
INFO - 2020-09-16 05:52:28 --> Security Class Initialized
DEBUG - 2020-09-16 05:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:52:28 --> Input Class Initialized
INFO - 2020-09-16 05:52:28 --> Language Class Initialized
INFO - 2020-09-16 05:52:28 --> Language Class Initialized
INFO - 2020-09-16 05:52:28 --> Config Class Initialized
INFO - 2020-09-16 05:52:28 --> Loader Class Initialized
INFO - 2020-09-16 05:52:28 --> Helper loaded: url_helper
INFO - 2020-09-16 05:52:28 --> Helper loaded: file_helper
INFO - 2020-09-16 05:52:28 --> Helper loaded: form_helper
INFO - 2020-09-16 05:52:28 --> Helper loaded: my_helper
INFO - 2020-09-16 05:52:28 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:52:28 --> Controller Class Initialized
INFO - 2020-09-16 05:52:28 --> Final output sent to browser
DEBUG - 2020-09-16 05:52:28 --> Total execution time: 0.0712
INFO - 2020-09-16 05:52:29 --> Config Class Initialized
INFO - 2020-09-16 05:52:29 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:52:29 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:52:29 --> Utf8 Class Initialized
INFO - 2020-09-16 05:52:29 --> URI Class Initialized
INFO - 2020-09-16 05:52:29 --> Router Class Initialized
INFO - 2020-09-16 05:52:29 --> Output Class Initialized
INFO - 2020-09-16 05:52:29 --> Security Class Initialized
DEBUG - 2020-09-16 05:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:52:29 --> Input Class Initialized
INFO - 2020-09-16 05:52:29 --> Language Class Initialized
INFO - 2020-09-16 05:52:29 --> Language Class Initialized
INFO - 2020-09-16 05:52:29 --> Config Class Initialized
INFO - 2020-09-16 05:52:29 --> Loader Class Initialized
INFO - 2020-09-16 05:52:29 --> Helper loaded: url_helper
INFO - 2020-09-16 05:52:29 --> Helper loaded: file_helper
INFO - 2020-09-16 05:52:29 --> Helper loaded: form_helper
INFO - 2020-09-16 05:52:29 --> Helper loaded: my_helper
INFO - 2020-09-16 05:52:29 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:52:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:52:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:52:30 --> Controller Class Initialized
INFO - 2020-09-16 05:52:30 --> Final output sent to browser
DEBUG - 2020-09-16 05:52:30 --> Total execution time: 0.0729
INFO - 2020-09-16 05:52:31 --> Config Class Initialized
INFO - 2020-09-16 05:52:31 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:52:31 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:52:31 --> Utf8 Class Initialized
INFO - 2020-09-16 05:52:31 --> URI Class Initialized
INFO - 2020-09-16 05:52:31 --> Router Class Initialized
INFO - 2020-09-16 05:52:31 --> Output Class Initialized
INFO - 2020-09-16 05:52:31 --> Security Class Initialized
DEBUG - 2020-09-16 05:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:52:31 --> Input Class Initialized
INFO - 2020-09-16 05:52:31 --> Language Class Initialized
INFO - 2020-09-16 05:52:31 --> Language Class Initialized
INFO - 2020-09-16 05:52:31 --> Config Class Initialized
INFO - 2020-09-16 05:52:31 --> Loader Class Initialized
INFO - 2020-09-16 05:52:31 --> Helper loaded: url_helper
INFO - 2020-09-16 05:52:31 --> Helper loaded: file_helper
INFO - 2020-09-16 05:52:31 --> Helper loaded: form_helper
INFO - 2020-09-16 05:52:31 --> Helper loaded: my_helper
INFO - 2020-09-16 05:52:31 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:52:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:52:31 --> Controller Class Initialized
INFO - 2020-09-16 05:52:31 --> Final output sent to browser
DEBUG - 2020-09-16 05:52:31 --> Total execution time: 0.0743
INFO - 2020-09-16 05:52:33 --> Config Class Initialized
INFO - 2020-09-16 05:52:33 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:52:33 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:52:33 --> Utf8 Class Initialized
INFO - 2020-09-16 05:52:33 --> URI Class Initialized
INFO - 2020-09-16 05:52:33 --> Router Class Initialized
INFO - 2020-09-16 05:52:33 --> Output Class Initialized
INFO - 2020-09-16 05:52:33 --> Security Class Initialized
DEBUG - 2020-09-16 05:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:52:33 --> Input Class Initialized
INFO - 2020-09-16 05:52:33 --> Language Class Initialized
INFO - 2020-09-16 05:52:33 --> Language Class Initialized
INFO - 2020-09-16 05:52:33 --> Config Class Initialized
INFO - 2020-09-16 05:52:33 --> Loader Class Initialized
INFO - 2020-09-16 05:52:33 --> Helper loaded: url_helper
INFO - 2020-09-16 05:52:33 --> Helper loaded: file_helper
INFO - 2020-09-16 05:52:33 --> Helper loaded: form_helper
INFO - 2020-09-16 05:52:33 --> Helper loaded: my_helper
INFO - 2020-09-16 05:52:33 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:52:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:52:33 --> Controller Class Initialized
INFO - 2020-09-16 05:52:33 --> Final output sent to browser
DEBUG - 2020-09-16 05:52:33 --> Total execution time: 0.0741
INFO - 2020-09-16 05:52:34 --> Config Class Initialized
INFO - 2020-09-16 05:52:34 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:52:34 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:52:34 --> Utf8 Class Initialized
INFO - 2020-09-16 05:52:34 --> URI Class Initialized
INFO - 2020-09-16 05:52:34 --> Router Class Initialized
INFO - 2020-09-16 05:52:34 --> Output Class Initialized
INFO - 2020-09-16 05:52:34 --> Security Class Initialized
DEBUG - 2020-09-16 05:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:52:34 --> Input Class Initialized
INFO - 2020-09-16 05:52:34 --> Language Class Initialized
INFO - 2020-09-16 05:52:34 --> Language Class Initialized
INFO - 2020-09-16 05:52:34 --> Config Class Initialized
INFO - 2020-09-16 05:52:34 --> Loader Class Initialized
INFO - 2020-09-16 05:52:34 --> Helper loaded: url_helper
INFO - 2020-09-16 05:52:34 --> Helper loaded: file_helper
INFO - 2020-09-16 05:52:34 --> Helper loaded: form_helper
INFO - 2020-09-16 05:52:34 --> Helper loaded: my_helper
INFO - 2020-09-16 05:52:34 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:52:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:52:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:52:34 --> Controller Class Initialized
DEBUG - 2020-09-16 05:52:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-09-16 05:52:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-16 05:52:34 --> Final output sent to browser
DEBUG - 2020-09-16 05:52:34 --> Total execution time: 0.0651
INFO - 2020-09-16 05:52:37 --> Config Class Initialized
INFO - 2020-09-16 05:52:37 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:52:37 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:52:37 --> Utf8 Class Initialized
INFO - 2020-09-16 05:52:37 --> URI Class Initialized
INFO - 2020-09-16 05:52:37 --> Router Class Initialized
INFO - 2020-09-16 05:52:37 --> Output Class Initialized
INFO - 2020-09-16 05:52:37 --> Security Class Initialized
DEBUG - 2020-09-16 05:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:52:37 --> Input Class Initialized
INFO - 2020-09-16 05:52:37 --> Language Class Initialized
INFO - 2020-09-16 05:52:37 --> Language Class Initialized
INFO - 2020-09-16 05:52:37 --> Config Class Initialized
INFO - 2020-09-16 05:52:37 --> Loader Class Initialized
INFO - 2020-09-16 05:52:37 --> Helper loaded: url_helper
INFO - 2020-09-16 05:52:37 --> Helper loaded: file_helper
INFO - 2020-09-16 05:52:37 --> Helper loaded: form_helper
INFO - 2020-09-16 05:52:37 --> Helper loaded: my_helper
INFO - 2020-09-16 05:52:37 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:52:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:52:37 --> Controller Class Initialized
INFO - 2020-09-16 05:52:37 --> Final output sent to browser
DEBUG - 2020-09-16 05:52:37 --> Total execution time: 0.0715
INFO - 2020-09-16 05:52:38 --> Config Class Initialized
INFO - 2020-09-16 05:52:38 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:52:38 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:52:38 --> Utf8 Class Initialized
INFO - 2020-09-16 05:52:38 --> URI Class Initialized
INFO - 2020-09-16 05:52:38 --> Router Class Initialized
INFO - 2020-09-16 05:52:38 --> Output Class Initialized
INFO - 2020-09-16 05:52:38 --> Security Class Initialized
DEBUG - 2020-09-16 05:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:52:38 --> Input Class Initialized
INFO - 2020-09-16 05:52:38 --> Language Class Initialized
INFO - 2020-09-16 05:52:38 --> Language Class Initialized
INFO - 2020-09-16 05:52:38 --> Config Class Initialized
INFO - 2020-09-16 05:52:38 --> Loader Class Initialized
INFO - 2020-09-16 05:52:38 --> Helper loaded: url_helper
INFO - 2020-09-16 05:52:38 --> Helper loaded: file_helper
INFO - 2020-09-16 05:52:38 --> Helper loaded: form_helper
INFO - 2020-09-16 05:52:38 --> Helper loaded: my_helper
INFO - 2020-09-16 05:52:38 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:52:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:52:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:52:38 --> Controller Class Initialized
INFO - 2020-09-16 05:52:38 --> Final output sent to browser
DEBUG - 2020-09-16 05:52:38 --> Total execution time: 0.0734
INFO - 2020-09-16 05:52:40 --> Config Class Initialized
INFO - 2020-09-16 05:52:40 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:52:40 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:52:40 --> Utf8 Class Initialized
INFO - 2020-09-16 05:52:40 --> URI Class Initialized
INFO - 2020-09-16 05:52:40 --> Router Class Initialized
INFO - 2020-09-16 05:52:40 --> Output Class Initialized
INFO - 2020-09-16 05:52:40 --> Security Class Initialized
DEBUG - 2020-09-16 05:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:52:40 --> Input Class Initialized
INFO - 2020-09-16 05:52:40 --> Language Class Initialized
INFO - 2020-09-16 05:52:40 --> Language Class Initialized
INFO - 2020-09-16 05:52:40 --> Config Class Initialized
INFO - 2020-09-16 05:52:40 --> Loader Class Initialized
INFO - 2020-09-16 05:52:40 --> Helper loaded: url_helper
INFO - 2020-09-16 05:52:40 --> Helper loaded: file_helper
INFO - 2020-09-16 05:52:40 --> Helper loaded: form_helper
INFO - 2020-09-16 05:52:40 --> Helper loaded: my_helper
INFO - 2020-09-16 05:52:40 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:52:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:52:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:52:40 --> Controller Class Initialized
INFO - 2020-09-16 05:52:40 --> Final output sent to browser
DEBUG - 2020-09-16 05:52:40 --> Total execution time: 0.0715
INFO - 2020-09-16 05:52:42 --> Config Class Initialized
INFO - 2020-09-16 05:52:42 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:52:42 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:52:42 --> Utf8 Class Initialized
INFO - 2020-09-16 05:52:42 --> URI Class Initialized
INFO - 2020-09-16 05:52:42 --> Router Class Initialized
INFO - 2020-09-16 05:52:42 --> Output Class Initialized
INFO - 2020-09-16 05:52:42 --> Security Class Initialized
DEBUG - 2020-09-16 05:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:52:42 --> Input Class Initialized
INFO - 2020-09-16 05:52:42 --> Language Class Initialized
INFO - 2020-09-16 05:52:42 --> Language Class Initialized
INFO - 2020-09-16 05:52:42 --> Config Class Initialized
INFO - 2020-09-16 05:52:42 --> Loader Class Initialized
INFO - 2020-09-16 05:52:42 --> Helper loaded: url_helper
INFO - 2020-09-16 05:52:42 --> Helper loaded: file_helper
INFO - 2020-09-16 05:52:42 --> Helper loaded: form_helper
INFO - 2020-09-16 05:52:42 --> Helper loaded: my_helper
INFO - 2020-09-16 05:52:42 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:52:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:52:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:52:42 --> Controller Class Initialized
INFO - 2020-09-16 05:52:42 --> Final output sent to browser
DEBUG - 2020-09-16 05:52:42 --> Total execution time: 0.0623
INFO - 2020-09-16 05:52:43 --> Config Class Initialized
INFO - 2020-09-16 05:52:43 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:52:43 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:52:43 --> Utf8 Class Initialized
INFO - 2020-09-16 05:52:43 --> URI Class Initialized
INFO - 2020-09-16 05:52:43 --> Router Class Initialized
INFO - 2020-09-16 05:52:43 --> Output Class Initialized
INFO - 2020-09-16 05:52:43 --> Security Class Initialized
DEBUG - 2020-09-16 05:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:52:43 --> Input Class Initialized
INFO - 2020-09-16 05:52:43 --> Language Class Initialized
INFO - 2020-09-16 05:52:43 --> Language Class Initialized
INFO - 2020-09-16 05:52:43 --> Config Class Initialized
INFO - 2020-09-16 05:52:43 --> Loader Class Initialized
INFO - 2020-09-16 05:52:43 --> Helper loaded: url_helper
INFO - 2020-09-16 05:52:43 --> Helper loaded: file_helper
INFO - 2020-09-16 05:52:43 --> Helper loaded: form_helper
INFO - 2020-09-16 05:52:43 --> Helper loaded: my_helper
INFO - 2020-09-16 05:52:43 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:52:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:52:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:52:43 --> Controller Class Initialized
INFO - 2020-09-16 05:52:43 --> Final output sent to browser
DEBUG - 2020-09-16 05:52:43 --> Total execution time: 0.0744
INFO - 2020-09-16 05:52:45 --> Config Class Initialized
INFO - 2020-09-16 05:52:45 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:52:45 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:52:45 --> Utf8 Class Initialized
INFO - 2020-09-16 05:52:45 --> URI Class Initialized
INFO - 2020-09-16 05:52:45 --> Router Class Initialized
INFO - 2020-09-16 05:52:45 --> Output Class Initialized
INFO - 2020-09-16 05:52:45 --> Security Class Initialized
DEBUG - 2020-09-16 05:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:52:45 --> Input Class Initialized
INFO - 2020-09-16 05:52:45 --> Language Class Initialized
INFO - 2020-09-16 05:52:45 --> Language Class Initialized
INFO - 2020-09-16 05:52:45 --> Config Class Initialized
INFO - 2020-09-16 05:52:45 --> Loader Class Initialized
INFO - 2020-09-16 05:52:45 --> Helper loaded: url_helper
INFO - 2020-09-16 05:52:45 --> Helper loaded: file_helper
INFO - 2020-09-16 05:52:45 --> Helper loaded: form_helper
INFO - 2020-09-16 05:52:45 --> Helper loaded: my_helper
INFO - 2020-09-16 05:52:45 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:52:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:52:45 --> Controller Class Initialized
INFO - 2020-09-16 05:52:45 --> Final output sent to browser
DEBUG - 2020-09-16 05:52:45 --> Total execution time: 0.0623
INFO - 2020-09-16 05:52:47 --> Config Class Initialized
INFO - 2020-09-16 05:52:47 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:52:47 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:52:47 --> Utf8 Class Initialized
INFO - 2020-09-16 05:52:47 --> URI Class Initialized
INFO - 2020-09-16 05:52:47 --> Router Class Initialized
INFO - 2020-09-16 05:52:47 --> Output Class Initialized
INFO - 2020-09-16 05:52:47 --> Security Class Initialized
DEBUG - 2020-09-16 05:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:52:47 --> Input Class Initialized
INFO - 2020-09-16 05:52:47 --> Language Class Initialized
INFO - 2020-09-16 05:52:47 --> Language Class Initialized
INFO - 2020-09-16 05:52:47 --> Config Class Initialized
INFO - 2020-09-16 05:52:47 --> Loader Class Initialized
INFO - 2020-09-16 05:52:47 --> Helper loaded: url_helper
INFO - 2020-09-16 05:52:47 --> Helper loaded: file_helper
INFO - 2020-09-16 05:52:47 --> Helper loaded: form_helper
INFO - 2020-09-16 05:52:47 --> Helper loaded: my_helper
INFO - 2020-09-16 05:52:47 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:52:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:52:47 --> Controller Class Initialized
DEBUG - 2020-09-16 05:52:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-09-16 05:52:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-16 05:52:47 --> Final output sent to browser
DEBUG - 2020-09-16 05:52:47 --> Total execution time: 0.0630
INFO - 2020-09-16 05:52:49 --> Config Class Initialized
INFO - 2020-09-16 05:52:49 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:52:49 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:52:49 --> Utf8 Class Initialized
INFO - 2020-09-16 05:52:49 --> URI Class Initialized
INFO - 2020-09-16 05:52:49 --> Router Class Initialized
INFO - 2020-09-16 05:52:49 --> Output Class Initialized
INFO - 2020-09-16 05:52:49 --> Security Class Initialized
DEBUG - 2020-09-16 05:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:52:49 --> Input Class Initialized
INFO - 2020-09-16 05:52:49 --> Language Class Initialized
INFO - 2020-09-16 05:52:49 --> Language Class Initialized
INFO - 2020-09-16 05:52:49 --> Config Class Initialized
INFO - 2020-09-16 05:52:49 --> Loader Class Initialized
INFO - 2020-09-16 05:52:49 --> Helper loaded: url_helper
INFO - 2020-09-16 05:52:49 --> Helper loaded: file_helper
INFO - 2020-09-16 05:52:49 --> Helper loaded: form_helper
INFO - 2020-09-16 05:52:49 --> Helper loaded: my_helper
INFO - 2020-09-16 05:52:49 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:52:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:52:49 --> Controller Class Initialized
INFO - 2020-09-16 05:52:49 --> Final output sent to browser
DEBUG - 2020-09-16 05:52:49 --> Total execution time: 0.0705
INFO - 2020-09-16 05:52:50 --> Config Class Initialized
INFO - 2020-09-16 05:52:50 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:52:50 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:52:50 --> Utf8 Class Initialized
INFO - 2020-09-16 05:52:50 --> URI Class Initialized
INFO - 2020-09-16 05:52:50 --> Router Class Initialized
INFO - 2020-09-16 05:52:51 --> Output Class Initialized
INFO - 2020-09-16 05:52:51 --> Security Class Initialized
DEBUG - 2020-09-16 05:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:52:51 --> Input Class Initialized
INFO - 2020-09-16 05:52:51 --> Language Class Initialized
INFO - 2020-09-16 05:52:51 --> Language Class Initialized
INFO - 2020-09-16 05:52:51 --> Config Class Initialized
INFO - 2020-09-16 05:52:51 --> Loader Class Initialized
INFO - 2020-09-16 05:52:51 --> Helper loaded: url_helper
INFO - 2020-09-16 05:52:51 --> Helper loaded: file_helper
INFO - 2020-09-16 05:52:51 --> Helper loaded: form_helper
INFO - 2020-09-16 05:52:51 --> Helper loaded: my_helper
INFO - 2020-09-16 05:52:51 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:52:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:52:51 --> Controller Class Initialized
INFO - 2020-09-16 05:52:51 --> Final output sent to browser
DEBUG - 2020-09-16 05:52:51 --> Total execution time: 0.1218
INFO - 2020-09-16 05:52:52 --> Config Class Initialized
INFO - 2020-09-16 05:52:52 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:52:52 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:52:52 --> Utf8 Class Initialized
INFO - 2020-09-16 05:52:52 --> URI Class Initialized
INFO - 2020-09-16 05:52:52 --> Router Class Initialized
INFO - 2020-09-16 05:52:52 --> Output Class Initialized
INFO - 2020-09-16 05:52:52 --> Security Class Initialized
DEBUG - 2020-09-16 05:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:52:52 --> Input Class Initialized
INFO - 2020-09-16 05:52:52 --> Language Class Initialized
INFO - 2020-09-16 05:52:52 --> Language Class Initialized
INFO - 2020-09-16 05:52:52 --> Config Class Initialized
INFO - 2020-09-16 05:52:52 --> Loader Class Initialized
INFO - 2020-09-16 05:52:52 --> Helper loaded: url_helper
INFO - 2020-09-16 05:52:52 --> Helper loaded: file_helper
INFO - 2020-09-16 05:52:52 --> Helper loaded: form_helper
INFO - 2020-09-16 05:52:52 --> Helper loaded: my_helper
INFO - 2020-09-16 05:52:52 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:52:52 --> Controller Class Initialized
DEBUG - 2020-09-16 05:52:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-09-16 05:52:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-16 05:52:52 --> Final output sent to browser
DEBUG - 2020-09-16 05:52:52 --> Total execution time: 0.0529
INFO - 2020-09-16 05:52:53 --> Config Class Initialized
INFO - 2020-09-16 05:52:53 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:52:53 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:52:53 --> Utf8 Class Initialized
INFO - 2020-09-16 05:52:53 --> URI Class Initialized
INFO - 2020-09-16 05:52:53 --> Router Class Initialized
INFO - 2020-09-16 05:52:53 --> Output Class Initialized
INFO - 2020-09-16 05:52:53 --> Security Class Initialized
DEBUG - 2020-09-16 05:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:52:53 --> Input Class Initialized
INFO - 2020-09-16 05:52:53 --> Language Class Initialized
INFO - 2020-09-16 05:52:53 --> Language Class Initialized
INFO - 2020-09-16 05:52:53 --> Config Class Initialized
INFO - 2020-09-16 05:52:53 --> Loader Class Initialized
INFO - 2020-09-16 05:52:53 --> Helper loaded: url_helper
INFO - 2020-09-16 05:52:53 --> Helper loaded: file_helper
INFO - 2020-09-16 05:52:53 --> Helper loaded: form_helper
INFO - 2020-09-16 05:52:53 --> Helper loaded: my_helper
INFO - 2020-09-16 05:52:53 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:52:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:52:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:52:53 --> Controller Class Initialized
DEBUG - 2020-09-16 05:52:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-09-16 05:52:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-16 05:52:54 --> Final output sent to browser
DEBUG - 2020-09-16 05:52:54 --> Total execution time: 0.0524
INFO - 2020-09-16 05:58:16 --> Config Class Initialized
INFO - 2020-09-16 05:58:16 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:58:16 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:58:16 --> Utf8 Class Initialized
INFO - 2020-09-16 05:58:16 --> URI Class Initialized
INFO - 2020-09-16 05:58:16 --> Router Class Initialized
INFO - 2020-09-16 05:58:16 --> Output Class Initialized
INFO - 2020-09-16 05:58:16 --> Security Class Initialized
DEBUG - 2020-09-16 05:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:58:16 --> Input Class Initialized
INFO - 2020-09-16 05:58:16 --> Language Class Initialized
INFO - 2020-09-16 05:58:16 --> Language Class Initialized
INFO - 2020-09-16 05:58:16 --> Config Class Initialized
INFO - 2020-09-16 05:58:16 --> Loader Class Initialized
INFO - 2020-09-16 05:58:16 --> Helper loaded: url_helper
INFO - 2020-09-16 05:58:16 --> Helper loaded: file_helper
INFO - 2020-09-16 05:58:16 --> Helper loaded: form_helper
INFO - 2020-09-16 05:58:16 --> Helper loaded: my_helper
INFO - 2020-09-16 05:58:16 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:58:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:58:16 --> Controller Class Initialized
INFO - 2020-09-16 05:58:16 --> Config Class Initialized
INFO - 2020-09-16 05:58:16 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:58:16 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:58:16 --> Utf8 Class Initialized
INFO - 2020-09-16 05:58:16 --> URI Class Initialized
INFO - 2020-09-16 05:58:16 --> Router Class Initialized
INFO - 2020-09-16 05:58:16 --> Output Class Initialized
INFO - 2020-09-16 05:58:16 --> Security Class Initialized
DEBUG - 2020-09-16 05:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:58:16 --> Input Class Initialized
INFO - 2020-09-16 05:58:16 --> Language Class Initialized
INFO - 2020-09-16 05:58:16 --> Language Class Initialized
INFO - 2020-09-16 05:58:16 --> Config Class Initialized
INFO - 2020-09-16 05:58:16 --> Loader Class Initialized
INFO - 2020-09-16 05:58:16 --> Helper loaded: url_helper
INFO - 2020-09-16 05:58:16 --> Helper loaded: file_helper
INFO - 2020-09-16 05:58:16 --> Helper loaded: form_helper
INFO - 2020-09-16 05:58:16 --> Helper loaded: my_helper
INFO - 2020-09-16 05:58:16 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:58:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:58:16 --> Controller Class Initialized
DEBUG - 2020-09-16 05:58:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-09-16 05:58:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-16 05:58:16 --> Final output sent to browser
DEBUG - 2020-09-16 05:58:16 --> Total execution time: 0.0632
INFO - 2020-09-16 05:58:22 --> Config Class Initialized
INFO - 2020-09-16 05:58:22 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:58:22 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:58:22 --> Utf8 Class Initialized
INFO - 2020-09-16 05:58:22 --> URI Class Initialized
INFO - 2020-09-16 05:58:22 --> Router Class Initialized
INFO - 2020-09-16 05:58:22 --> Output Class Initialized
INFO - 2020-09-16 05:58:22 --> Security Class Initialized
DEBUG - 2020-09-16 05:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:58:22 --> Input Class Initialized
INFO - 2020-09-16 05:58:22 --> Language Class Initialized
INFO - 2020-09-16 05:58:22 --> Language Class Initialized
INFO - 2020-09-16 05:58:22 --> Config Class Initialized
INFO - 2020-09-16 05:58:22 --> Loader Class Initialized
INFO - 2020-09-16 05:58:22 --> Helper loaded: url_helper
INFO - 2020-09-16 05:58:22 --> Helper loaded: file_helper
INFO - 2020-09-16 05:58:22 --> Helper loaded: form_helper
INFO - 2020-09-16 05:58:22 --> Helper loaded: my_helper
INFO - 2020-09-16 05:58:22 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:58:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:58:22 --> Controller Class Initialized
DEBUG - 2020-09-16 05:58:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-09-16 05:58:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-16 05:58:22 --> Final output sent to browser
DEBUG - 2020-09-16 05:58:22 --> Total execution time: 0.0535
INFO - 2020-09-16 05:58:27 --> Config Class Initialized
INFO - 2020-09-16 05:58:27 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:58:27 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:58:27 --> Utf8 Class Initialized
INFO - 2020-09-16 05:58:27 --> URI Class Initialized
INFO - 2020-09-16 05:58:27 --> Router Class Initialized
INFO - 2020-09-16 05:58:27 --> Output Class Initialized
INFO - 2020-09-16 05:58:27 --> Security Class Initialized
DEBUG - 2020-09-16 05:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:58:27 --> Input Class Initialized
INFO - 2020-09-16 05:58:27 --> Language Class Initialized
INFO - 2020-09-16 05:58:27 --> Language Class Initialized
INFO - 2020-09-16 05:58:27 --> Config Class Initialized
INFO - 2020-09-16 05:58:27 --> Loader Class Initialized
INFO - 2020-09-16 05:58:27 --> Helper loaded: url_helper
INFO - 2020-09-16 05:58:27 --> Helper loaded: file_helper
INFO - 2020-09-16 05:58:27 --> Helper loaded: form_helper
INFO - 2020-09-16 05:58:27 --> Helper loaded: my_helper
INFO - 2020-09-16 05:58:27 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:58:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:58:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:58:27 --> Controller Class Initialized
INFO - 2020-09-16 05:58:27 --> Config Class Initialized
INFO - 2020-09-16 05:58:27 --> Hooks Class Initialized
DEBUG - 2020-09-16 05:58:27 --> UTF-8 Support Enabled
INFO - 2020-09-16 05:58:27 --> Utf8 Class Initialized
INFO - 2020-09-16 05:58:27 --> URI Class Initialized
INFO - 2020-09-16 05:58:27 --> Router Class Initialized
INFO - 2020-09-16 05:58:27 --> Output Class Initialized
INFO - 2020-09-16 05:58:27 --> Security Class Initialized
DEBUG - 2020-09-16 05:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 05:58:27 --> Input Class Initialized
INFO - 2020-09-16 05:58:27 --> Language Class Initialized
INFO - 2020-09-16 05:58:27 --> Language Class Initialized
INFO - 2020-09-16 05:58:27 --> Config Class Initialized
INFO - 2020-09-16 05:58:27 --> Loader Class Initialized
INFO - 2020-09-16 05:58:27 --> Helper loaded: url_helper
INFO - 2020-09-16 05:58:27 --> Helper loaded: file_helper
INFO - 2020-09-16 05:58:27 --> Helper loaded: form_helper
INFO - 2020-09-16 05:58:27 --> Helper loaded: my_helper
INFO - 2020-09-16 05:58:27 --> Database Driver Class Initialized
DEBUG - 2020-09-16 05:58:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-16 05:58:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 05:58:27 --> Controller Class Initialized
DEBUG - 2020-09-16 05:58:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-09-16 05:58:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-16 05:58:27 --> Final output sent to browser
DEBUG - 2020-09-16 05:58:27 --> Total execution time: 0.0634
