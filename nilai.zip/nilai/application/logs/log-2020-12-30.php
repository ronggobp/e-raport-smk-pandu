<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-12-30 01:23:21 --> Config Class Initialized
INFO - 2020-12-30 01:23:21 --> Hooks Class Initialized
DEBUG - 2020-12-30 01:23:21 --> UTF-8 Support Enabled
INFO - 2020-12-30 01:23:21 --> Utf8 Class Initialized
INFO - 2020-12-30 01:23:21 --> URI Class Initialized
DEBUG - 2020-12-30 01:23:21 --> No URI present. Default controller set.
INFO - 2020-12-30 01:23:21 --> Router Class Initialized
INFO - 2020-12-30 01:23:21 --> Output Class Initialized
INFO - 2020-12-30 01:23:22 --> Security Class Initialized
DEBUG - 2020-12-30 01:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 01:23:22 --> Input Class Initialized
INFO - 2020-12-30 01:23:22 --> Language Class Initialized
INFO - 2020-12-30 01:23:22 --> Language Class Initialized
INFO - 2020-12-30 01:23:22 --> Config Class Initialized
INFO - 2020-12-30 01:23:22 --> Loader Class Initialized
INFO - 2020-12-30 01:23:22 --> Helper loaded: url_helper
INFO - 2020-12-30 01:23:22 --> Helper loaded: file_helper
INFO - 2020-12-30 01:23:22 --> Helper loaded: form_helper
INFO - 2020-12-30 01:23:22 --> Helper loaded: my_helper
INFO - 2020-12-30 01:23:23 --> Database Driver Class Initialized
DEBUG - 2020-12-30 01:23:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 01:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 01:23:23 --> Controller Class Initialized
INFO - 2020-12-30 01:23:23 --> Config Class Initialized
INFO - 2020-12-30 01:23:23 --> Hooks Class Initialized
DEBUG - 2020-12-30 01:23:23 --> UTF-8 Support Enabled
INFO - 2020-12-30 01:23:23 --> Utf8 Class Initialized
INFO - 2020-12-30 01:23:23 --> URI Class Initialized
INFO - 2020-12-30 01:23:23 --> Router Class Initialized
INFO - 2020-12-30 01:23:23 --> Output Class Initialized
INFO - 2020-12-30 01:23:23 --> Security Class Initialized
DEBUG - 2020-12-30 01:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 01:23:23 --> Input Class Initialized
INFO - 2020-12-30 01:23:23 --> Language Class Initialized
INFO - 2020-12-30 01:23:23 --> Language Class Initialized
INFO - 2020-12-30 01:23:23 --> Config Class Initialized
INFO - 2020-12-30 01:23:24 --> Loader Class Initialized
INFO - 2020-12-30 01:23:24 --> Helper loaded: url_helper
INFO - 2020-12-30 01:23:24 --> Helper loaded: file_helper
INFO - 2020-12-30 01:23:24 --> Helper loaded: form_helper
INFO - 2020-12-30 01:23:24 --> Helper loaded: my_helper
INFO - 2020-12-30 01:23:24 --> Database Driver Class Initialized
DEBUG - 2020-12-30 01:23:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 01:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 01:23:24 --> Controller Class Initialized
DEBUG - 2020-12-30 01:23:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-30 01:23:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 01:23:24 --> Final output sent to browser
DEBUG - 2020-12-30 01:23:24 --> Total execution time: 0.6499
INFO - 2020-12-30 01:38:32 --> Config Class Initialized
INFO - 2020-12-30 01:38:32 --> Hooks Class Initialized
DEBUG - 2020-12-30 01:38:32 --> UTF-8 Support Enabled
INFO - 2020-12-30 01:38:32 --> Utf8 Class Initialized
INFO - 2020-12-30 01:38:32 --> URI Class Initialized
INFO - 2020-12-30 01:38:32 --> Router Class Initialized
INFO - 2020-12-30 01:38:32 --> Output Class Initialized
INFO - 2020-12-30 01:38:32 --> Security Class Initialized
DEBUG - 2020-12-30 01:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 01:38:32 --> Input Class Initialized
INFO - 2020-12-30 01:38:32 --> Language Class Initialized
INFO - 2020-12-30 01:38:32 --> Language Class Initialized
INFO - 2020-12-30 01:38:32 --> Config Class Initialized
INFO - 2020-12-30 01:38:32 --> Loader Class Initialized
INFO - 2020-12-30 01:38:32 --> Helper loaded: url_helper
INFO - 2020-12-30 01:38:32 --> Helper loaded: file_helper
INFO - 2020-12-30 01:38:32 --> Helper loaded: form_helper
INFO - 2020-12-30 01:38:32 --> Helper loaded: my_helper
INFO - 2020-12-30 01:38:32 --> Database Driver Class Initialized
DEBUG - 2020-12-30 01:38:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 01:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 01:38:32 --> Controller Class Initialized
INFO - 2020-12-30 01:38:32 --> Helper loaded: cookie_helper
INFO - 2020-12-30 01:38:32 --> Final output sent to browser
DEBUG - 2020-12-30 01:38:32 --> Total execution time: 0.5917
INFO - 2020-12-30 01:38:34 --> Config Class Initialized
INFO - 2020-12-30 01:38:34 --> Hooks Class Initialized
DEBUG - 2020-12-30 01:38:34 --> UTF-8 Support Enabled
INFO - 2020-12-30 01:38:34 --> Utf8 Class Initialized
INFO - 2020-12-30 01:38:34 --> URI Class Initialized
INFO - 2020-12-30 01:38:34 --> Router Class Initialized
INFO - 2020-12-30 01:38:34 --> Output Class Initialized
INFO - 2020-12-30 01:38:34 --> Security Class Initialized
DEBUG - 2020-12-30 01:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 01:38:34 --> Input Class Initialized
INFO - 2020-12-30 01:38:34 --> Language Class Initialized
INFO - 2020-12-30 01:38:34 --> Language Class Initialized
INFO - 2020-12-30 01:38:35 --> Config Class Initialized
INFO - 2020-12-30 01:38:35 --> Loader Class Initialized
INFO - 2020-12-30 01:38:35 --> Helper loaded: url_helper
INFO - 2020-12-30 01:38:35 --> Helper loaded: file_helper
INFO - 2020-12-30 01:38:35 --> Helper loaded: form_helper
INFO - 2020-12-30 01:38:35 --> Helper loaded: my_helper
INFO - 2020-12-30 01:38:35 --> Database Driver Class Initialized
DEBUG - 2020-12-30 01:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 01:38:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 01:38:35 --> Controller Class Initialized
DEBUG - 2020-12-30 01:38:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-30 01:38:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 01:38:35 --> Final output sent to browser
DEBUG - 2020-12-30 01:38:35 --> Total execution time: 0.7504
INFO - 2020-12-30 01:49:34 --> Config Class Initialized
INFO - 2020-12-30 01:49:34 --> Hooks Class Initialized
DEBUG - 2020-12-30 01:49:34 --> UTF-8 Support Enabled
INFO - 2020-12-30 01:49:34 --> Utf8 Class Initialized
INFO - 2020-12-30 01:49:34 --> URI Class Initialized
INFO - 2020-12-30 01:49:34 --> Router Class Initialized
INFO - 2020-12-30 01:49:34 --> Output Class Initialized
INFO - 2020-12-30 01:49:34 --> Security Class Initialized
DEBUG - 2020-12-30 01:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 01:49:34 --> Input Class Initialized
INFO - 2020-12-30 01:49:34 --> Language Class Initialized
INFO - 2020-12-30 01:49:34 --> Language Class Initialized
INFO - 2020-12-30 01:49:34 --> Config Class Initialized
INFO - 2020-12-30 01:49:34 --> Loader Class Initialized
INFO - 2020-12-30 01:49:34 --> Helper loaded: url_helper
INFO - 2020-12-30 01:49:34 --> Helper loaded: file_helper
INFO - 2020-12-30 01:49:34 --> Helper loaded: form_helper
INFO - 2020-12-30 01:49:35 --> Helper loaded: my_helper
INFO - 2020-12-30 01:49:35 --> Database Driver Class Initialized
DEBUG - 2020-12-30 01:49:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 01:49:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 01:49:35 --> Controller Class Initialized
DEBUG - 2020-12-30 01:49:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-12-30 01:49:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 01:49:35 --> Final output sent to browser
DEBUG - 2020-12-30 01:49:35 --> Total execution time: 0.8863
INFO - 2020-12-30 01:50:27 --> Config Class Initialized
INFO - 2020-12-30 01:50:27 --> Hooks Class Initialized
DEBUG - 2020-12-30 01:50:27 --> UTF-8 Support Enabled
INFO - 2020-12-30 01:50:27 --> Utf8 Class Initialized
INFO - 2020-12-30 01:50:27 --> URI Class Initialized
INFO - 2020-12-30 01:50:27 --> Router Class Initialized
INFO - 2020-12-30 01:50:27 --> Output Class Initialized
INFO - 2020-12-30 01:50:27 --> Security Class Initialized
DEBUG - 2020-12-30 01:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 01:50:27 --> Input Class Initialized
INFO - 2020-12-30 01:50:27 --> Language Class Initialized
INFO - 2020-12-30 01:50:27 --> Language Class Initialized
INFO - 2020-12-30 01:50:27 --> Config Class Initialized
INFO - 2020-12-30 01:50:27 --> Loader Class Initialized
INFO - 2020-12-30 01:50:27 --> Helper loaded: url_helper
INFO - 2020-12-30 01:50:27 --> Helper loaded: file_helper
INFO - 2020-12-30 01:50:27 --> Helper loaded: form_helper
INFO - 2020-12-30 01:50:27 --> Helper loaded: my_helper
INFO - 2020-12-30 01:50:27 --> Database Driver Class Initialized
DEBUG - 2020-12-30 01:50:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 01:50:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 01:50:27 --> Controller Class Initialized
INFO - 2020-12-30 01:50:27 --> Helper loaded: cookie_helper
INFO - 2020-12-30 01:50:27 --> Config Class Initialized
INFO - 2020-12-30 01:50:27 --> Hooks Class Initialized
DEBUG - 2020-12-30 01:50:27 --> UTF-8 Support Enabled
INFO - 2020-12-30 01:50:27 --> Utf8 Class Initialized
INFO - 2020-12-30 01:50:27 --> URI Class Initialized
INFO - 2020-12-30 01:50:27 --> Router Class Initialized
INFO - 2020-12-30 01:50:27 --> Output Class Initialized
INFO - 2020-12-30 01:50:27 --> Security Class Initialized
DEBUG - 2020-12-30 01:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 01:50:27 --> Input Class Initialized
INFO - 2020-12-30 01:50:27 --> Language Class Initialized
INFO - 2020-12-30 01:50:28 --> Language Class Initialized
INFO - 2020-12-30 01:50:28 --> Config Class Initialized
INFO - 2020-12-30 01:50:28 --> Loader Class Initialized
INFO - 2020-12-30 01:50:28 --> Helper loaded: url_helper
INFO - 2020-12-30 01:50:28 --> Helper loaded: file_helper
INFO - 2020-12-30 01:50:28 --> Helper loaded: form_helper
INFO - 2020-12-30 01:50:28 --> Helper loaded: my_helper
INFO - 2020-12-30 01:50:28 --> Database Driver Class Initialized
DEBUG - 2020-12-30 01:50:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 01:50:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 01:50:28 --> Controller Class Initialized
DEBUG - 2020-12-30 01:50:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-30 01:50:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 01:50:28 --> Final output sent to browser
DEBUG - 2020-12-30 01:50:28 --> Total execution time: 0.8001
INFO - 2020-12-30 01:50:32 --> Config Class Initialized
INFO - 2020-12-30 01:50:32 --> Hooks Class Initialized
DEBUG - 2020-12-30 01:50:32 --> UTF-8 Support Enabled
INFO - 2020-12-30 01:50:32 --> Utf8 Class Initialized
INFO - 2020-12-30 01:50:32 --> URI Class Initialized
INFO - 2020-12-30 01:50:32 --> Router Class Initialized
INFO - 2020-12-30 01:50:32 --> Output Class Initialized
INFO - 2020-12-30 01:50:32 --> Security Class Initialized
DEBUG - 2020-12-30 01:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 01:50:32 --> Input Class Initialized
INFO - 2020-12-30 01:50:32 --> Language Class Initialized
INFO - 2020-12-30 01:50:32 --> Language Class Initialized
INFO - 2020-12-30 01:50:32 --> Config Class Initialized
INFO - 2020-12-30 01:50:32 --> Loader Class Initialized
INFO - 2020-12-30 01:50:32 --> Helper loaded: url_helper
INFO - 2020-12-30 01:50:32 --> Helper loaded: file_helper
INFO - 2020-12-30 01:50:32 --> Helper loaded: form_helper
INFO - 2020-12-30 01:50:32 --> Helper loaded: my_helper
INFO - 2020-12-30 01:50:32 --> Database Driver Class Initialized
DEBUG - 2020-12-30 01:50:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 01:50:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 01:50:32 --> Controller Class Initialized
INFO - 2020-12-30 01:50:33 --> Helper loaded: cookie_helper
INFO - 2020-12-30 01:50:33 --> Final output sent to browser
DEBUG - 2020-12-30 01:50:33 --> Total execution time: 0.7348
INFO - 2020-12-30 01:50:33 --> Config Class Initialized
INFO - 2020-12-30 01:50:33 --> Hooks Class Initialized
DEBUG - 2020-12-30 01:50:33 --> UTF-8 Support Enabled
INFO - 2020-12-30 01:50:33 --> Utf8 Class Initialized
INFO - 2020-12-30 01:50:33 --> URI Class Initialized
INFO - 2020-12-30 01:50:33 --> Router Class Initialized
INFO - 2020-12-30 01:50:33 --> Output Class Initialized
INFO - 2020-12-30 01:50:33 --> Security Class Initialized
DEBUG - 2020-12-30 01:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 01:50:33 --> Input Class Initialized
INFO - 2020-12-30 01:50:33 --> Language Class Initialized
INFO - 2020-12-30 01:50:33 --> Language Class Initialized
INFO - 2020-12-30 01:50:33 --> Config Class Initialized
INFO - 2020-12-30 01:50:33 --> Loader Class Initialized
INFO - 2020-12-30 01:50:33 --> Helper loaded: url_helper
INFO - 2020-12-30 01:50:33 --> Helper loaded: file_helper
INFO - 2020-12-30 01:50:33 --> Helper loaded: form_helper
INFO - 2020-12-30 01:50:33 --> Helper loaded: my_helper
INFO - 2020-12-30 01:50:34 --> Database Driver Class Initialized
DEBUG - 2020-12-30 01:50:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 01:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 01:50:34 --> Controller Class Initialized
DEBUG - 2020-12-30 01:50:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-30 01:50:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 01:50:34 --> Final output sent to browser
DEBUG - 2020-12-30 01:50:34 --> Total execution time: 0.7035
INFO - 2020-12-30 01:50:35 --> Config Class Initialized
INFO - 2020-12-30 01:50:35 --> Hooks Class Initialized
DEBUG - 2020-12-30 01:50:35 --> UTF-8 Support Enabled
INFO - 2020-12-30 01:50:35 --> Utf8 Class Initialized
INFO - 2020-12-30 01:50:35 --> URI Class Initialized
INFO - 2020-12-30 01:50:35 --> Router Class Initialized
INFO - 2020-12-30 01:50:35 --> Output Class Initialized
INFO - 2020-12-30 01:50:35 --> Security Class Initialized
DEBUG - 2020-12-30 01:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 01:50:35 --> Input Class Initialized
INFO - 2020-12-30 01:50:35 --> Language Class Initialized
INFO - 2020-12-30 01:50:35 --> Language Class Initialized
INFO - 2020-12-30 01:50:35 --> Config Class Initialized
INFO - 2020-12-30 01:50:35 --> Loader Class Initialized
INFO - 2020-12-30 01:50:35 --> Helper loaded: url_helper
INFO - 2020-12-30 01:50:35 --> Helper loaded: file_helper
INFO - 2020-12-30 01:50:35 --> Helper loaded: form_helper
INFO - 2020-12-30 01:50:36 --> Helper loaded: my_helper
INFO - 2020-12-30 01:50:36 --> Database Driver Class Initialized
DEBUG - 2020-12-30 01:50:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 01:50:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 01:50:36 --> Controller Class Initialized
DEBUG - 2020-12-30 01:50:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-12-30 01:50:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 01:50:36 --> Final output sent to browser
DEBUG - 2020-12-30 01:50:36 --> Total execution time: 0.7947
INFO - 2020-12-30 01:50:38 --> Config Class Initialized
INFO - 2020-12-30 01:50:38 --> Hooks Class Initialized
DEBUG - 2020-12-30 01:50:38 --> UTF-8 Support Enabled
INFO - 2020-12-30 01:50:38 --> Utf8 Class Initialized
INFO - 2020-12-30 01:50:38 --> URI Class Initialized
INFO - 2020-12-30 01:50:38 --> Router Class Initialized
INFO - 2020-12-30 01:50:38 --> Output Class Initialized
INFO - 2020-12-30 01:50:38 --> Security Class Initialized
DEBUG - 2020-12-30 01:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 01:50:38 --> Input Class Initialized
INFO - 2020-12-30 01:50:38 --> Language Class Initialized
INFO - 2020-12-30 01:50:38 --> Language Class Initialized
INFO - 2020-12-30 01:50:38 --> Config Class Initialized
INFO - 2020-12-30 01:50:38 --> Loader Class Initialized
INFO - 2020-12-30 01:50:38 --> Helper loaded: url_helper
INFO - 2020-12-30 01:50:39 --> Helper loaded: file_helper
INFO - 2020-12-30 01:50:39 --> Helper loaded: form_helper
INFO - 2020-12-30 01:50:39 --> Helper loaded: my_helper
INFO - 2020-12-30 01:50:39 --> Database Driver Class Initialized
DEBUG - 2020-12-30 01:50:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 01:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 01:50:39 --> Controller Class Initialized
INFO - 2020-12-30 01:50:39 --> Helper loaded: cookie_helper
INFO - 2020-12-30 01:50:39 --> Config Class Initialized
INFO - 2020-12-30 01:50:39 --> Hooks Class Initialized
DEBUG - 2020-12-30 01:50:39 --> UTF-8 Support Enabled
INFO - 2020-12-30 01:50:39 --> Utf8 Class Initialized
INFO - 2020-12-30 01:50:39 --> URI Class Initialized
INFO - 2020-12-30 01:50:39 --> Router Class Initialized
INFO - 2020-12-30 01:50:39 --> Output Class Initialized
INFO - 2020-12-30 01:50:39 --> Security Class Initialized
DEBUG - 2020-12-30 01:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 01:50:39 --> Input Class Initialized
INFO - 2020-12-30 01:50:39 --> Language Class Initialized
INFO - 2020-12-30 01:50:39 --> Language Class Initialized
INFO - 2020-12-30 01:50:39 --> Config Class Initialized
INFO - 2020-12-30 01:50:39 --> Loader Class Initialized
INFO - 2020-12-30 01:50:39 --> Helper loaded: url_helper
INFO - 2020-12-30 01:50:39 --> Helper loaded: file_helper
INFO - 2020-12-30 01:50:40 --> Helper loaded: form_helper
INFO - 2020-12-30 01:50:40 --> Helper loaded: my_helper
INFO - 2020-12-30 01:50:40 --> Database Driver Class Initialized
DEBUG - 2020-12-30 01:50:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 01:50:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 01:50:40 --> Controller Class Initialized
DEBUG - 2020-12-30 01:50:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-30 01:50:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 01:50:40 --> Final output sent to browser
DEBUG - 2020-12-30 01:50:40 --> Total execution time: 0.8908
INFO - 2020-12-30 01:50:46 --> Config Class Initialized
INFO - 2020-12-30 01:50:46 --> Hooks Class Initialized
DEBUG - 2020-12-30 01:50:46 --> UTF-8 Support Enabled
INFO - 2020-12-30 01:50:46 --> Utf8 Class Initialized
INFO - 2020-12-30 01:50:46 --> URI Class Initialized
INFO - 2020-12-30 01:50:46 --> Router Class Initialized
INFO - 2020-12-30 01:50:47 --> Output Class Initialized
INFO - 2020-12-30 01:50:47 --> Security Class Initialized
DEBUG - 2020-12-30 01:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 01:50:47 --> Input Class Initialized
INFO - 2020-12-30 01:50:47 --> Language Class Initialized
INFO - 2020-12-30 01:50:47 --> Language Class Initialized
INFO - 2020-12-30 01:50:47 --> Config Class Initialized
INFO - 2020-12-30 01:50:47 --> Loader Class Initialized
INFO - 2020-12-30 01:50:47 --> Helper loaded: url_helper
INFO - 2020-12-30 01:50:47 --> Helper loaded: file_helper
INFO - 2020-12-30 01:50:47 --> Helper loaded: form_helper
INFO - 2020-12-30 01:50:47 --> Helper loaded: my_helper
INFO - 2020-12-30 01:50:47 --> Database Driver Class Initialized
DEBUG - 2020-12-30 01:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 01:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 01:50:47 --> Controller Class Initialized
INFO - 2020-12-30 01:50:47 --> Helper loaded: cookie_helper
INFO - 2020-12-30 01:50:47 --> Final output sent to browser
DEBUG - 2020-12-30 01:50:47 --> Total execution time: 0.7115
INFO - 2020-12-30 01:50:48 --> Config Class Initialized
INFO - 2020-12-30 01:50:48 --> Hooks Class Initialized
DEBUG - 2020-12-30 01:50:48 --> UTF-8 Support Enabled
INFO - 2020-12-30 01:50:48 --> Utf8 Class Initialized
INFO - 2020-12-30 01:50:48 --> URI Class Initialized
INFO - 2020-12-30 01:50:48 --> Router Class Initialized
INFO - 2020-12-30 01:50:48 --> Output Class Initialized
INFO - 2020-12-30 01:50:48 --> Security Class Initialized
DEBUG - 2020-12-30 01:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 01:50:48 --> Input Class Initialized
INFO - 2020-12-30 01:50:48 --> Language Class Initialized
INFO - 2020-12-30 01:50:48 --> Language Class Initialized
INFO - 2020-12-30 01:50:48 --> Config Class Initialized
INFO - 2020-12-30 01:50:48 --> Loader Class Initialized
INFO - 2020-12-30 01:50:48 --> Helper loaded: url_helper
INFO - 2020-12-30 01:50:48 --> Helper loaded: file_helper
INFO - 2020-12-30 01:50:48 --> Helper loaded: form_helper
INFO - 2020-12-30 01:50:48 --> Helper loaded: my_helper
INFO - 2020-12-30 01:50:48 --> Database Driver Class Initialized
DEBUG - 2020-12-30 01:50:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 01:50:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 01:50:48 --> Controller Class Initialized
DEBUG - 2020-12-30 01:50:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-30 01:50:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 01:50:48 --> Final output sent to browser
DEBUG - 2020-12-30 01:50:48 --> Total execution time: 0.6957
INFO - 2020-12-30 01:50:55 --> Config Class Initialized
INFO - 2020-12-30 01:50:55 --> Hooks Class Initialized
DEBUG - 2020-12-30 01:50:55 --> UTF-8 Support Enabled
INFO - 2020-12-30 01:50:55 --> Utf8 Class Initialized
INFO - 2020-12-30 01:50:55 --> URI Class Initialized
INFO - 2020-12-30 01:50:55 --> Router Class Initialized
INFO - 2020-12-30 01:50:55 --> Output Class Initialized
INFO - 2020-12-30 01:50:55 --> Security Class Initialized
DEBUG - 2020-12-30 01:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 01:50:55 --> Input Class Initialized
INFO - 2020-12-30 01:50:55 --> Language Class Initialized
INFO - 2020-12-30 01:50:55 --> Language Class Initialized
INFO - 2020-12-30 01:50:55 --> Config Class Initialized
INFO - 2020-12-30 01:50:55 --> Loader Class Initialized
INFO - 2020-12-30 01:50:55 --> Helper loaded: url_helper
INFO - 2020-12-30 01:50:55 --> Helper loaded: file_helper
INFO - 2020-12-30 01:50:55 --> Helper loaded: form_helper
INFO - 2020-12-30 01:50:56 --> Helper loaded: my_helper
INFO - 2020-12-30 01:50:56 --> Database Driver Class Initialized
DEBUG - 2020-12-30 01:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 01:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 01:50:56 --> Controller Class Initialized
DEBUG - 2020-12-30 01:50:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-12-30 01:50:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 01:50:56 --> Final output sent to browser
DEBUG - 2020-12-30 01:50:56 --> Total execution time: 0.9839
INFO - 2020-12-30 01:50:56 --> Config Class Initialized
INFO - 2020-12-30 01:50:56 --> Hooks Class Initialized
DEBUG - 2020-12-30 01:50:56 --> UTF-8 Support Enabled
INFO - 2020-12-30 01:50:56 --> Utf8 Class Initialized
INFO - 2020-12-30 01:50:56 --> URI Class Initialized
INFO - 2020-12-30 01:50:56 --> Router Class Initialized
INFO - 2020-12-30 01:50:56 --> Output Class Initialized
INFO - 2020-12-30 01:50:57 --> Security Class Initialized
DEBUG - 2020-12-30 01:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 01:50:57 --> Input Class Initialized
INFO - 2020-12-30 01:50:57 --> Language Class Initialized
INFO - 2020-12-30 01:50:57 --> Language Class Initialized
INFO - 2020-12-30 01:50:57 --> Config Class Initialized
INFO - 2020-12-30 01:50:57 --> Loader Class Initialized
INFO - 2020-12-30 01:50:57 --> Helper loaded: url_helper
INFO - 2020-12-30 01:50:57 --> Helper loaded: file_helper
INFO - 2020-12-30 01:50:57 --> Helper loaded: form_helper
INFO - 2020-12-30 01:50:57 --> Helper loaded: my_helper
INFO - 2020-12-30 01:50:57 --> Database Driver Class Initialized
DEBUG - 2020-12-30 01:50:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 01:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 01:50:57 --> Controller Class Initialized
INFO - 2020-12-30 01:50:58 --> Config Class Initialized
INFO - 2020-12-30 01:50:58 --> Hooks Class Initialized
DEBUG - 2020-12-30 01:50:58 --> UTF-8 Support Enabled
INFO - 2020-12-30 01:50:58 --> Utf8 Class Initialized
INFO - 2020-12-30 01:50:58 --> URI Class Initialized
INFO - 2020-12-30 01:50:58 --> Router Class Initialized
INFO - 2020-12-30 01:50:58 --> Output Class Initialized
INFO - 2020-12-30 01:50:58 --> Security Class Initialized
DEBUG - 2020-12-30 01:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 01:50:58 --> Input Class Initialized
INFO - 2020-12-30 01:50:58 --> Language Class Initialized
INFO - 2020-12-30 01:50:58 --> Language Class Initialized
INFO - 2020-12-30 01:50:58 --> Config Class Initialized
INFO - 2020-12-30 01:50:58 --> Loader Class Initialized
INFO - 2020-12-30 01:50:58 --> Helper loaded: url_helper
INFO - 2020-12-30 01:50:58 --> Helper loaded: file_helper
INFO - 2020-12-30 01:50:58 --> Helper loaded: form_helper
INFO - 2020-12-30 01:50:58 --> Helper loaded: my_helper
INFO - 2020-12-30 01:50:59 --> Database Driver Class Initialized
DEBUG - 2020-12-30 01:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 01:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 01:50:59 --> Controller Class Initialized
DEBUG - 2020-12-30 01:50:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2020-12-30 01:50:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 01:50:59 --> Final output sent to browser
DEBUG - 2020-12-30 01:50:59 --> Total execution time: 0.7959
INFO - 2020-12-30 01:51:17 --> Config Class Initialized
INFO - 2020-12-30 01:51:17 --> Hooks Class Initialized
DEBUG - 2020-12-30 01:51:17 --> UTF-8 Support Enabled
INFO - 2020-12-30 01:51:17 --> Utf8 Class Initialized
INFO - 2020-12-30 01:51:17 --> URI Class Initialized
INFO - 2020-12-30 01:51:17 --> Router Class Initialized
INFO - 2020-12-30 01:51:17 --> Output Class Initialized
INFO - 2020-12-30 01:51:17 --> Security Class Initialized
DEBUG - 2020-12-30 01:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 01:51:17 --> Input Class Initialized
INFO - 2020-12-30 01:51:17 --> Language Class Initialized
INFO - 2020-12-30 01:51:17 --> Language Class Initialized
INFO - 2020-12-30 01:51:17 --> Config Class Initialized
INFO - 2020-12-30 01:51:17 --> Loader Class Initialized
INFO - 2020-12-30 01:51:17 --> Helper loaded: url_helper
INFO - 2020-12-30 01:51:17 --> Helper loaded: file_helper
INFO - 2020-12-30 01:51:17 --> Helper loaded: form_helper
INFO - 2020-12-30 01:51:17 --> Helper loaded: my_helper
INFO - 2020-12-30 01:51:17 --> Database Driver Class Initialized
DEBUG - 2020-12-30 01:51:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 01:51:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 01:51:17 --> Controller Class Initialized
INFO - 2020-12-30 01:51:18 --> Config Class Initialized
INFO - 2020-12-30 01:51:18 --> Hooks Class Initialized
DEBUG - 2020-12-30 01:51:18 --> UTF-8 Support Enabled
INFO - 2020-12-30 01:51:18 --> Utf8 Class Initialized
INFO - 2020-12-30 01:51:18 --> URI Class Initialized
INFO - 2020-12-30 01:51:18 --> Router Class Initialized
INFO - 2020-12-30 01:51:18 --> Output Class Initialized
INFO - 2020-12-30 01:51:18 --> Security Class Initialized
DEBUG - 2020-12-30 01:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 01:51:18 --> Input Class Initialized
INFO - 2020-12-30 01:51:18 --> Language Class Initialized
INFO - 2020-12-30 01:51:18 --> Language Class Initialized
INFO - 2020-12-30 01:51:18 --> Config Class Initialized
INFO - 2020-12-30 01:51:18 --> Loader Class Initialized
INFO - 2020-12-30 01:51:18 --> Helper loaded: url_helper
INFO - 2020-12-30 01:51:18 --> Helper loaded: file_helper
INFO - 2020-12-30 01:51:18 --> Helper loaded: form_helper
INFO - 2020-12-30 01:51:18 --> Helper loaded: my_helper
INFO - 2020-12-30 01:51:18 --> Database Driver Class Initialized
DEBUG - 2020-12-30 01:51:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 01:51:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 01:51:18 --> Controller Class Initialized
DEBUG - 2020-12-30 01:51:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-12-30 01:51:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 01:51:18 --> Final output sent to browser
DEBUG - 2020-12-30 01:51:18 --> Total execution time: 0.8928
INFO - 2020-12-30 01:51:19 --> Config Class Initialized
INFO - 2020-12-30 01:51:19 --> Hooks Class Initialized
DEBUG - 2020-12-30 01:51:19 --> UTF-8 Support Enabled
INFO - 2020-12-30 01:51:19 --> Utf8 Class Initialized
INFO - 2020-12-30 01:51:19 --> URI Class Initialized
INFO - 2020-12-30 01:51:19 --> Router Class Initialized
INFO - 2020-12-30 01:51:19 --> Output Class Initialized
INFO - 2020-12-30 01:51:19 --> Security Class Initialized
DEBUG - 2020-12-30 01:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 01:51:19 --> Input Class Initialized
INFO - 2020-12-30 01:51:19 --> Language Class Initialized
INFO - 2020-12-30 01:51:19 --> Language Class Initialized
INFO - 2020-12-30 01:51:19 --> Config Class Initialized
INFO - 2020-12-30 01:51:19 --> Loader Class Initialized
INFO - 2020-12-30 01:51:19 --> Helper loaded: url_helper
INFO - 2020-12-30 01:51:19 --> Helper loaded: file_helper
INFO - 2020-12-30 01:51:19 --> Helper loaded: form_helper
INFO - 2020-12-30 01:51:19 --> Helper loaded: my_helper
INFO - 2020-12-30 01:51:19 --> Database Driver Class Initialized
DEBUG - 2020-12-30 01:51:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 01:51:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 01:51:19 --> Controller Class Initialized
INFO - 2020-12-30 01:51:22 --> Config Class Initialized
INFO - 2020-12-30 01:51:22 --> Hooks Class Initialized
DEBUG - 2020-12-30 01:51:22 --> UTF-8 Support Enabled
INFO - 2020-12-30 01:51:22 --> Utf8 Class Initialized
INFO - 2020-12-30 01:51:22 --> URI Class Initialized
INFO - 2020-12-30 01:51:22 --> Router Class Initialized
INFO - 2020-12-30 01:51:22 --> Output Class Initialized
INFO - 2020-12-30 01:51:22 --> Security Class Initialized
DEBUG - 2020-12-30 01:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 01:51:22 --> Input Class Initialized
INFO - 2020-12-30 01:51:22 --> Language Class Initialized
INFO - 2020-12-30 01:51:22 --> Language Class Initialized
INFO - 2020-12-30 01:51:22 --> Config Class Initialized
INFO - 2020-12-30 01:51:22 --> Loader Class Initialized
INFO - 2020-12-30 01:51:22 --> Helper loaded: url_helper
INFO - 2020-12-30 01:51:22 --> Helper loaded: file_helper
INFO - 2020-12-30 01:51:22 --> Helper loaded: form_helper
INFO - 2020-12-30 01:51:22 --> Helper loaded: my_helper
INFO - 2020-12-30 01:51:23 --> Database Driver Class Initialized
DEBUG - 2020-12-30 01:51:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 01:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 01:51:23 --> Controller Class Initialized
DEBUG - 2020-12-30 01:51:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2020-12-30 01:51:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 01:51:23 --> Final output sent to browser
DEBUG - 2020-12-30 01:51:23 --> Total execution time: 0.8120
INFO - 2020-12-30 01:51:23 --> Config Class Initialized
INFO - 2020-12-30 01:51:23 --> Hooks Class Initialized
DEBUG - 2020-12-30 01:51:23 --> UTF-8 Support Enabled
INFO - 2020-12-30 01:51:23 --> Utf8 Class Initialized
INFO - 2020-12-30 01:51:23 --> URI Class Initialized
INFO - 2020-12-30 01:51:23 --> Router Class Initialized
INFO - 2020-12-30 01:51:23 --> Output Class Initialized
INFO - 2020-12-30 01:51:23 --> Security Class Initialized
DEBUG - 2020-12-30 01:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 01:51:23 --> Input Class Initialized
INFO - 2020-12-30 01:51:23 --> Language Class Initialized
INFO - 2020-12-30 01:51:23 --> Language Class Initialized
INFO - 2020-12-30 01:51:23 --> Config Class Initialized
INFO - 2020-12-30 01:51:23 --> Loader Class Initialized
INFO - 2020-12-30 01:51:23 --> Helper loaded: url_helper
INFO - 2020-12-30 01:51:23 --> Helper loaded: file_helper
INFO - 2020-12-30 01:51:24 --> Helper loaded: form_helper
INFO - 2020-12-30 01:51:24 --> Helper loaded: my_helper
INFO - 2020-12-30 01:51:24 --> Database Driver Class Initialized
DEBUG - 2020-12-30 01:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 01:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 01:51:24 --> Controller Class Initialized
INFO - 2020-12-30 01:51:28 --> Config Class Initialized
INFO - 2020-12-30 01:51:28 --> Hooks Class Initialized
DEBUG - 2020-12-30 01:51:28 --> UTF-8 Support Enabled
INFO - 2020-12-30 01:51:28 --> Utf8 Class Initialized
INFO - 2020-12-30 01:51:28 --> URI Class Initialized
INFO - 2020-12-30 01:51:28 --> Router Class Initialized
INFO - 2020-12-30 01:51:28 --> Output Class Initialized
INFO - 2020-12-30 01:51:28 --> Security Class Initialized
DEBUG - 2020-12-30 01:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 01:51:28 --> Input Class Initialized
INFO - 2020-12-30 01:51:28 --> Language Class Initialized
INFO - 2020-12-30 01:51:28 --> Language Class Initialized
INFO - 2020-12-30 01:51:28 --> Config Class Initialized
INFO - 2020-12-30 01:51:28 --> Loader Class Initialized
INFO - 2020-12-30 01:51:28 --> Helper loaded: url_helper
INFO - 2020-12-30 01:51:28 --> Helper loaded: file_helper
INFO - 2020-12-30 01:51:28 --> Helper loaded: form_helper
INFO - 2020-12-30 01:51:28 --> Helper loaded: my_helper
INFO - 2020-12-30 01:51:28 --> Database Driver Class Initialized
DEBUG - 2020-12-30 01:51:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 01:51:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 01:51:29 --> Controller Class Initialized
INFO - 2020-12-30 01:51:29 --> Helper loaded: cookie_helper
INFO - 2020-12-30 01:51:29 --> Config Class Initialized
INFO - 2020-12-30 01:51:29 --> Hooks Class Initialized
DEBUG - 2020-12-30 01:51:29 --> UTF-8 Support Enabled
INFO - 2020-12-30 01:51:29 --> Utf8 Class Initialized
INFO - 2020-12-30 01:51:29 --> URI Class Initialized
INFO - 2020-12-30 01:51:29 --> Router Class Initialized
INFO - 2020-12-30 01:51:29 --> Output Class Initialized
INFO - 2020-12-30 01:51:29 --> Security Class Initialized
DEBUG - 2020-12-30 01:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 01:51:29 --> Input Class Initialized
INFO - 2020-12-30 01:51:29 --> Language Class Initialized
INFO - 2020-12-30 01:51:29 --> Language Class Initialized
INFO - 2020-12-30 01:51:29 --> Config Class Initialized
INFO - 2020-12-30 01:51:29 --> Loader Class Initialized
INFO - 2020-12-30 01:51:29 --> Helper loaded: url_helper
INFO - 2020-12-30 01:51:29 --> Helper loaded: file_helper
INFO - 2020-12-30 01:51:29 --> Helper loaded: form_helper
INFO - 2020-12-30 01:51:29 --> Helper loaded: my_helper
INFO - 2020-12-30 01:51:29 --> Database Driver Class Initialized
DEBUG - 2020-12-30 01:51:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 01:51:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 01:51:29 --> Controller Class Initialized
DEBUG - 2020-12-30 01:51:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-30 01:51:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 01:51:29 --> Final output sent to browser
DEBUG - 2020-12-30 01:51:29 --> Total execution time: 0.7716
INFO - 2020-12-30 01:51:33 --> Config Class Initialized
INFO - 2020-12-30 01:51:33 --> Hooks Class Initialized
DEBUG - 2020-12-30 01:51:33 --> UTF-8 Support Enabled
INFO - 2020-12-30 01:51:33 --> Utf8 Class Initialized
INFO - 2020-12-30 01:51:33 --> URI Class Initialized
INFO - 2020-12-30 01:51:33 --> Router Class Initialized
INFO - 2020-12-30 01:51:33 --> Output Class Initialized
INFO - 2020-12-30 01:51:33 --> Security Class Initialized
DEBUG - 2020-12-30 01:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 01:51:34 --> Input Class Initialized
INFO - 2020-12-30 01:51:34 --> Language Class Initialized
INFO - 2020-12-30 01:51:34 --> Language Class Initialized
INFO - 2020-12-30 01:51:34 --> Config Class Initialized
INFO - 2020-12-30 01:51:34 --> Loader Class Initialized
INFO - 2020-12-30 01:51:34 --> Helper loaded: url_helper
INFO - 2020-12-30 01:51:34 --> Helper loaded: file_helper
INFO - 2020-12-30 01:51:34 --> Helper loaded: form_helper
INFO - 2020-12-30 01:51:34 --> Helper loaded: my_helper
INFO - 2020-12-30 01:51:34 --> Database Driver Class Initialized
DEBUG - 2020-12-30 01:51:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 01:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 01:51:34 --> Controller Class Initialized
INFO - 2020-12-30 01:51:34 --> Helper loaded: cookie_helper
INFO - 2020-12-30 01:51:34 --> Final output sent to browser
DEBUG - 2020-12-30 01:51:34 --> Total execution time: 0.7521
INFO - 2020-12-30 01:51:35 --> Config Class Initialized
INFO - 2020-12-30 01:51:35 --> Hooks Class Initialized
DEBUG - 2020-12-30 01:51:35 --> UTF-8 Support Enabled
INFO - 2020-12-30 01:51:35 --> Utf8 Class Initialized
INFO - 2020-12-30 01:51:35 --> URI Class Initialized
INFO - 2020-12-30 01:51:35 --> Router Class Initialized
INFO - 2020-12-30 01:51:35 --> Output Class Initialized
INFO - 2020-12-30 01:51:35 --> Security Class Initialized
DEBUG - 2020-12-30 01:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 01:51:35 --> Input Class Initialized
INFO - 2020-12-30 01:51:35 --> Language Class Initialized
INFO - 2020-12-30 01:51:35 --> Language Class Initialized
INFO - 2020-12-30 01:51:35 --> Config Class Initialized
INFO - 2020-12-30 01:51:35 --> Loader Class Initialized
INFO - 2020-12-30 01:51:35 --> Helper loaded: url_helper
INFO - 2020-12-30 01:51:35 --> Helper loaded: file_helper
INFO - 2020-12-30 01:51:35 --> Helper loaded: form_helper
INFO - 2020-12-30 01:51:35 --> Helper loaded: my_helper
INFO - 2020-12-30 01:51:35 --> Database Driver Class Initialized
DEBUG - 2020-12-30 01:51:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 01:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 01:51:35 --> Controller Class Initialized
DEBUG - 2020-12-30 01:51:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-30 01:51:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 01:51:35 --> Final output sent to browser
DEBUG - 2020-12-30 01:51:35 --> Total execution time: 0.7225
INFO - 2020-12-30 02:05:54 --> Config Class Initialized
INFO - 2020-12-30 02:05:54 --> Hooks Class Initialized
DEBUG - 2020-12-30 02:05:54 --> UTF-8 Support Enabled
INFO - 2020-12-30 02:05:54 --> Utf8 Class Initialized
INFO - 2020-12-30 02:05:55 --> URI Class Initialized
INFO - 2020-12-30 02:05:55 --> Router Class Initialized
INFO - 2020-12-30 02:05:55 --> Output Class Initialized
INFO - 2020-12-30 02:05:55 --> Security Class Initialized
DEBUG - 2020-12-30 02:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 02:05:55 --> Input Class Initialized
INFO - 2020-12-30 02:05:55 --> Language Class Initialized
INFO - 2020-12-30 02:05:55 --> Language Class Initialized
INFO - 2020-12-30 02:05:55 --> Config Class Initialized
INFO - 2020-12-30 02:05:55 --> Loader Class Initialized
INFO - 2020-12-30 02:05:55 --> Helper loaded: url_helper
INFO - 2020-12-30 02:05:55 --> Helper loaded: file_helper
INFO - 2020-12-30 02:05:55 --> Helper loaded: form_helper
INFO - 2020-12-30 02:05:55 --> Helper loaded: my_helper
INFO - 2020-12-30 02:05:55 --> Database Driver Class Initialized
DEBUG - 2020-12-30 02:05:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 02:05:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 02:05:55 --> Controller Class Initialized
DEBUG - 2020-12-30 02:05:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2020-12-30 02:05:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 02:05:55 --> Final output sent to browser
DEBUG - 2020-12-30 02:05:55 --> Total execution time: 0.3626
INFO - 2020-12-30 02:05:56 --> Config Class Initialized
INFO - 2020-12-30 02:05:56 --> Hooks Class Initialized
DEBUG - 2020-12-30 02:05:56 --> UTF-8 Support Enabled
INFO - 2020-12-30 02:05:56 --> Utf8 Class Initialized
INFO - 2020-12-30 02:05:56 --> URI Class Initialized
INFO - 2020-12-30 02:05:56 --> Router Class Initialized
INFO - 2020-12-30 02:05:56 --> Output Class Initialized
INFO - 2020-12-30 02:05:56 --> Security Class Initialized
DEBUG - 2020-12-30 02:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 02:05:56 --> Input Class Initialized
INFO - 2020-12-30 02:05:56 --> Language Class Initialized
INFO - 2020-12-30 02:05:56 --> Language Class Initialized
INFO - 2020-12-30 02:05:56 --> Config Class Initialized
INFO - 2020-12-30 02:05:56 --> Loader Class Initialized
INFO - 2020-12-30 02:05:56 --> Helper loaded: url_helper
INFO - 2020-12-30 02:05:56 --> Helper loaded: file_helper
INFO - 2020-12-30 02:05:56 --> Helper loaded: form_helper
INFO - 2020-12-30 02:05:56 --> Helper loaded: my_helper
INFO - 2020-12-30 02:05:56 --> Database Driver Class Initialized
DEBUG - 2020-12-30 02:05:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 02:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 02:05:56 --> Controller Class Initialized
DEBUG - 2020-12-30 02:05:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/cetak.php
INFO - 2020-12-30 02:05:56 --> Final output sent to browser
DEBUG - 2020-12-30 02:05:56 --> Total execution time: 0.3014
INFO - 2020-12-30 02:06:02 --> Config Class Initialized
INFO - 2020-12-30 02:06:02 --> Hooks Class Initialized
DEBUG - 2020-12-30 02:06:02 --> UTF-8 Support Enabled
INFO - 2020-12-30 02:06:02 --> Utf8 Class Initialized
INFO - 2020-12-30 02:06:02 --> URI Class Initialized
INFO - 2020-12-30 02:06:02 --> Router Class Initialized
INFO - 2020-12-30 02:06:02 --> Output Class Initialized
INFO - 2020-12-30 02:06:02 --> Security Class Initialized
DEBUG - 2020-12-30 02:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 02:06:02 --> Input Class Initialized
INFO - 2020-12-30 02:06:02 --> Language Class Initialized
INFO - 2020-12-30 02:06:02 --> Language Class Initialized
INFO - 2020-12-30 02:06:02 --> Config Class Initialized
INFO - 2020-12-30 02:06:02 --> Loader Class Initialized
INFO - 2020-12-30 02:06:02 --> Helper loaded: url_helper
INFO - 2020-12-30 02:06:02 --> Helper loaded: file_helper
INFO - 2020-12-30 02:06:02 --> Helper loaded: form_helper
INFO - 2020-12-30 02:06:02 --> Helper loaded: my_helper
INFO - 2020-12-30 02:06:02 --> Database Driver Class Initialized
DEBUG - 2020-12-30 02:06:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 02:06:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 02:06:02 --> Controller Class Initialized
DEBUG - 2020-12-30 02:06:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-12-30 02:06:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 02:06:02 --> Final output sent to browser
DEBUG - 2020-12-30 02:06:02 --> Total execution time: 0.2424
INFO - 2020-12-30 02:06:25 --> Config Class Initialized
INFO - 2020-12-30 02:06:25 --> Hooks Class Initialized
DEBUG - 2020-12-30 02:06:25 --> UTF-8 Support Enabled
INFO - 2020-12-30 02:06:25 --> Utf8 Class Initialized
INFO - 2020-12-30 02:06:25 --> URI Class Initialized
INFO - 2020-12-30 02:06:25 --> Router Class Initialized
INFO - 2020-12-30 02:06:25 --> Output Class Initialized
INFO - 2020-12-30 02:06:25 --> Security Class Initialized
DEBUG - 2020-12-30 02:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 02:06:25 --> Input Class Initialized
INFO - 2020-12-30 02:06:25 --> Language Class Initialized
INFO - 2020-12-30 02:06:25 --> Language Class Initialized
INFO - 2020-12-30 02:06:25 --> Config Class Initialized
INFO - 2020-12-30 02:06:25 --> Loader Class Initialized
INFO - 2020-12-30 02:06:25 --> Helper loaded: url_helper
INFO - 2020-12-30 02:06:25 --> Helper loaded: file_helper
INFO - 2020-12-30 02:06:25 --> Helper loaded: form_helper
INFO - 2020-12-30 02:06:25 --> Helper loaded: my_helper
INFO - 2020-12-30 02:06:25 --> Database Driver Class Initialized
DEBUG - 2020-12-30 02:06:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 02:06:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 02:06:25 --> Controller Class Initialized
DEBUG - 2020-12-30 02:06:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-12-30 02:06:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 02:06:25 --> Final output sent to browser
DEBUG - 2020-12-30 02:06:25 --> Total execution time: 0.3246
INFO - 2020-12-30 02:06:25 --> Config Class Initialized
INFO - 2020-12-30 02:06:25 --> Hooks Class Initialized
DEBUG - 2020-12-30 02:06:25 --> UTF-8 Support Enabled
INFO - 2020-12-30 02:06:25 --> Utf8 Class Initialized
INFO - 2020-12-30 02:06:25 --> URI Class Initialized
INFO - 2020-12-30 02:06:25 --> Router Class Initialized
INFO - 2020-12-30 02:06:25 --> Output Class Initialized
INFO - 2020-12-30 02:06:25 --> Security Class Initialized
DEBUG - 2020-12-30 02:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 02:06:25 --> Input Class Initialized
INFO - 2020-12-30 02:06:25 --> Language Class Initialized
INFO - 2020-12-30 02:06:25 --> Language Class Initialized
INFO - 2020-12-30 02:06:25 --> Config Class Initialized
INFO - 2020-12-30 02:06:25 --> Loader Class Initialized
INFO - 2020-12-30 02:06:25 --> Helper loaded: url_helper
INFO - 2020-12-30 02:06:25 --> Helper loaded: file_helper
INFO - 2020-12-30 02:06:25 --> Helper loaded: form_helper
INFO - 2020-12-30 02:06:25 --> Helper loaded: my_helper
INFO - 2020-12-30 02:06:25 --> Database Driver Class Initialized
DEBUG - 2020-12-30 02:06:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 02:06:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 02:06:25 --> Controller Class Initialized
INFO - 2020-12-30 02:06:26 --> Config Class Initialized
INFO - 2020-12-30 02:06:26 --> Hooks Class Initialized
DEBUG - 2020-12-30 02:06:26 --> UTF-8 Support Enabled
INFO - 2020-12-30 02:06:26 --> Utf8 Class Initialized
INFO - 2020-12-30 02:06:26 --> URI Class Initialized
INFO - 2020-12-30 02:06:26 --> Router Class Initialized
INFO - 2020-12-30 02:06:26 --> Output Class Initialized
INFO - 2020-12-30 02:06:26 --> Security Class Initialized
DEBUG - 2020-12-30 02:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 02:06:26 --> Input Class Initialized
INFO - 2020-12-30 02:06:26 --> Language Class Initialized
INFO - 2020-12-30 02:06:26 --> Language Class Initialized
INFO - 2020-12-30 02:06:26 --> Config Class Initialized
INFO - 2020-12-30 02:06:26 --> Loader Class Initialized
INFO - 2020-12-30 02:06:26 --> Helper loaded: url_helper
INFO - 2020-12-30 02:06:26 --> Helper loaded: file_helper
INFO - 2020-12-30 02:06:26 --> Helper loaded: form_helper
INFO - 2020-12-30 02:06:26 --> Helper loaded: my_helper
INFO - 2020-12-30 02:06:26 --> Database Driver Class Initialized
DEBUG - 2020-12-30 02:06:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 02:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 02:06:26 --> Controller Class Initialized
DEBUG - 2020-12-30 02:06:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2020-12-30 02:06:26 --> Final output sent to browser
DEBUG - 2020-12-30 02:06:26 --> Total execution time: 0.3653
INFO - 2020-12-30 02:07:09 --> Config Class Initialized
INFO - 2020-12-30 02:07:09 --> Hooks Class Initialized
DEBUG - 2020-12-30 02:07:09 --> UTF-8 Support Enabled
INFO - 2020-12-30 02:07:09 --> Utf8 Class Initialized
INFO - 2020-12-30 02:07:09 --> URI Class Initialized
INFO - 2020-12-30 02:07:09 --> Router Class Initialized
INFO - 2020-12-30 02:07:09 --> Output Class Initialized
INFO - 2020-12-30 02:07:09 --> Security Class Initialized
DEBUG - 2020-12-30 02:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 02:07:09 --> Input Class Initialized
INFO - 2020-12-30 02:07:09 --> Language Class Initialized
INFO - 2020-12-30 02:07:09 --> Language Class Initialized
INFO - 2020-12-30 02:07:09 --> Config Class Initialized
INFO - 2020-12-30 02:07:09 --> Loader Class Initialized
INFO - 2020-12-30 02:07:09 --> Helper loaded: url_helper
INFO - 2020-12-30 02:07:09 --> Helper loaded: file_helper
INFO - 2020-12-30 02:07:09 --> Helper loaded: form_helper
INFO - 2020-12-30 02:07:09 --> Helper loaded: my_helper
INFO - 2020-12-30 02:07:09 --> Database Driver Class Initialized
DEBUG - 2020-12-30 02:07:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 02:07:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 02:07:09 --> Controller Class Initialized
DEBUG - 2020-12-30 02:07:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-12-30 02:07:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 02:07:09 --> Final output sent to browser
DEBUG - 2020-12-30 02:07:09 --> Total execution time: 0.2488
INFO - 2020-12-30 02:07:14 --> Config Class Initialized
INFO - 2020-12-30 02:07:14 --> Hooks Class Initialized
DEBUG - 2020-12-30 02:07:14 --> UTF-8 Support Enabled
INFO - 2020-12-30 02:07:14 --> Utf8 Class Initialized
INFO - 2020-12-30 02:07:14 --> URI Class Initialized
INFO - 2020-12-30 02:07:14 --> Router Class Initialized
INFO - 2020-12-30 02:07:14 --> Output Class Initialized
INFO - 2020-12-30 02:07:14 --> Security Class Initialized
DEBUG - 2020-12-30 02:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 02:07:14 --> Input Class Initialized
INFO - 2020-12-30 02:07:14 --> Language Class Initialized
INFO - 2020-12-30 02:07:14 --> Language Class Initialized
INFO - 2020-12-30 02:07:14 --> Config Class Initialized
INFO - 2020-12-30 02:07:14 --> Loader Class Initialized
INFO - 2020-12-30 02:07:14 --> Helper loaded: url_helper
INFO - 2020-12-30 02:07:14 --> Helper loaded: file_helper
INFO - 2020-12-30 02:07:14 --> Helper loaded: form_helper
INFO - 2020-12-30 02:07:14 --> Helper loaded: my_helper
INFO - 2020-12-30 02:07:14 --> Database Driver Class Initialized
DEBUG - 2020-12-30 02:07:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 02:07:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 02:07:14 --> Controller Class Initialized
DEBUG - 2020-12-30 02:07:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2020-12-30 02:07:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 02:07:14 --> Final output sent to browser
DEBUG - 2020-12-30 02:07:14 --> Total execution time: 0.3365
INFO - 2020-12-30 02:07:15 --> Config Class Initialized
INFO - 2020-12-30 02:07:15 --> Hooks Class Initialized
DEBUG - 2020-12-30 02:07:15 --> UTF-8 Support Enabled
INFO - 2020-12-30 02:07:15 --> Utf8 Class Initialized
INFO - 2020-12-30 02:07:15 --> URI Class Initialized
INFO - 2020-12-30 02:07:15 --> Router Class Initialized
INFO - 2020-12-30 02:07:15 --> Output Class Initialized
INFO - 2020-12-30 02:07:15 --> Security Class Initialized
DEBUG - 2020-12-30 02:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 02:07:15 --> Input Class Initialized
INFO - 2020-12-30 02:07:15 --> Language Class Initialized
INFO - 2020-12-30 02:07:15 --> Language Class Initialized
INFO - 2020-12-30 02:07:15 --> Config Class Initialized
INFO - 2020-12-30 02:07:15 --> Loader Class Initialized
INFO - 2020-12-30 02:07:15 --> Helper loaded: url_helper
INFO - 2020-12-30 02:07:15 --> Helper loaded: file_helper
INFO - 2020-12-30 02:07:15 --> Helper loaded: form_helper
INFO - 2020-12-30 02:07:15 --> Helper loaded: my_helper
INFO - 2020-12-30 02:07:15 --> Database Driver Class Initialized
DEBUG - 2020-12-30 02:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 02:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 02:07:15 --> Controller Class Initialized
DEBUG - 2020-12-30 02:07:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2020-12-30 02:07:15 --> Final output sent to browser
DEBUG - 2020-12-30 02:07:15 --> Total execution time: 0.2978
INFO - 2020-12-30 02:07:21 --> Config Class Initialized
INFO - 2020-12-30 02:07:21 --> Hooks Class Initialized
DEBUG - 2020-12-30 02:07:21 --> UTF-8 Support Enabled
INFO - 2020-12-30 02:07:21 --> Utf8 Class Initialized
INFO - 2020-12-30 02:07:21 --> URI Class Initialized
INFO - 2020-12-30 02:07:21 --> Router Class Initialized
INFO - 2020-12-30 02:07:21 --> Output Class Initialized
INFO - 2020-12-30 02:07:21 --> Security Class Initialized
DEBUG - 2020-12-30 02:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 02:07:21 --> Input Class Initialized
INFO - 2020-12-30 02:07:21 --> Language Class Initialized
INFO - 2020-12-30 02:07:21 --> Language Class Initialized
INFO - 2020-12-30 02:07:21 --> Config Class Initialized
INFO - 2020-12-30 02:07:21 --> Loader Class Initialized
INFO - 2020-12-30 02:07:21 --> Helper loaded: url_helper
INFO - 2020-12-30 02:07:21 --> Helper loaded: file_helper
INFO - 2020-12-30 02:07:21 --> Helper loaded: form_helper
INFO - 2020-12-30 02:07:21 --> Helper loaded: my_helper
INFO - 2020-12-30 02:07:21 --> Database Driver Class Initialized
DEBUG - 2020-12-30 02:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 02:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 02:07:21 --> Controller Class Initialized
DEBUG - 2020-12-30 02:07:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_ekstra.php
INFO - 2020-12-30 02:07:21 --> Final output sent to browser
DEBUG - 2020-12-30 02:07:22 --> Total execution time: 0.2847
INFO - 2020-12-30 02:07:30 --> Config Class Initialized
INFO - 2020-12-30 02:07:30 --> Hooks Class Initialized
DEBUG - 2020-12-30 02:07:30 --> UTF-8 Support Enabled
INFO - 2020-12-30 02:07:30 --> Utf8 Class Initialized
INFO - 2020-12-30 02:07:30 --> URI Class Initialized
INFO - 2020-12-30 02:07:30 --> Router Class Initialized
INFO - 2020-12-30 02:07:30 --> Output Class Initialized
INFO - 2020-12-30 02:07:30 --> Security Class Initialized
DEBUG - 2020-12-30 02:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 02:07:30 --> Input Class Initialized
INFO - 2020-12-30 02:07:30 --> Language Class Initialized
INFO - 2020-12-30 02:07:30 --> Language Class Initialized
INFO - 2020-12-30 02:07:30 --> Config Class Initialized
INFO - 2020-12-30 02:07:30 --> Loader Class Initialized
INFO - 2020-12-30 02:07:30 --> Helper loaded: url_helper
INFO - 2020-12-30 02:07:30 --> Helper loaded: file_helper
INFO - 2020-12-30 02:07:30 --> Helper loaded: form_helper
INFO - 2020-12-30 02:07:30 --> Helper loaded: my_helper
INFO - 2020-12-30 02:07:30 --> Database Driver Class Initialized
DEBUG - 2020-12-30 02:07:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 02:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 02:07:30 --> Controller Class Initialized
DEBUG - 2020-12-30 02:07:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2020-12-30 02:07:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 02:07:30 --> Final output sent to browser
DEBUG - 2020-12-30 02:07:30 --> Total execution time: 0.3434
INFO - 2020-12-30 02:07:34 --> Config Class Initialized
INFO - 2020-12-30 02:07:34 --> Hooks Class Initialized
DEBUG - 2020-12-30 02:07:34 --> UTF-8 Support Enabled
INFO - 2020-12-30 02:07:34 --> Utf8 Class Initialized
INFO - 2020-12-30 02:07:34 --> URI Class Initialized
INFO - 2020-12-30 02:07:34 --> Router Class Initialized
INFO - 2020-12-30 02:07:34 --> Output Class Initialized
INFO - 2020-12-30 02:07:34 --> Security Class Initialized
DEBUG - 2020-12-30 02:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 02:07:34 --> Input Class Initialized
INFO - 2020-12-30 02:07:34 --> Language Class Initialized
INFO - 2020-12-30 02:07:34 --> Language Class Initialized
INFO - 2020-12-30 02:07:34 --> Config Class Initialized
INFO - 2020-12-30 02:07:34 --> Loader Class Initialized
INFO - 2020-12-30 02:07:34 --> Helper loaded: url_helper
INFO - 2020-12-30 02:07:34 --> Helper loaded: file_helper
INFO - 2020-12-30 02:07:34 --> Helper loaded: form_helper
INFO - 2020-12-30 02:07:34 --> Helper loaded: my_helper
INFO - 2020-12-30 02:07:34 --> Database Driver Class Initialized
DEBUG - 2020-12-30 02:07:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 02:07:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 02:07:34 --> Controller Class Initialized
DEBUG - 2020-12-30 02:07:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul1.php
INFO - 2020-12-30 02:07:34 --> Final output sent to browser
DEBUG - 2020-12-30 02:07:34 --> Total execution time: 0.3248
INFO - 2020-12-30 02:07:39 --> Config Class Initialized
INFO - 2020-12-30 02:07:39 --> Hooks Class Initialized
DEBUG - 2020-12-30 02:07:39 --> UTF-8 Support Enabled
INFO - 2020-12-30 02:07:39 --> Utf8 Class Initialized
INFO - 2020-12-30 02:07:39 --> URI Class Initialized
INFO - 2020-12-30 02:07:39 --> Router Class Initialized
INFO - 2020-12-30 02:07:39 --> Output Class Initialized
INFO - 2020-12-30 02:07:39 --> Security Class Initialized
DEBUG - 2020-12-30 02:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 02:07:39 --> Input Class Initialized
INFO - 2020-12-30 02:07:39 --> Language Class Initialized
INFO - 2020-12-30 02:07:39 --> Language Class Initialized
INFO - 2020-12-30 02:07:39 --> Config Class Initialized
INFO - 2020-12-30 02:07:39 --> Loader Class Initialized
INFO - 2020-12-30 02:07:39 --> Helper loaded: url_helper
INFO - 2020-12-30 02:07:39 --> Helper loaded: file_helper
INFO - 2020-12-30 02:07:39 --> Helper loaded: form_helper
INFO - 2020-12-30 02:07:39 --> Helper loaded: my_helper
INFO - 2020-12-30 02:07:39 --> Database Driver Class Initialized
DEBUG - 2020-12-30 02:07:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 02:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 02:07:39 --> Controller Class Initialized
DEBUG - 2020-12-30 02:07:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_catatan/views/list.php
DEBUG - 2020-12-30 02:07:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 02:07:39 --> Final output sent to browser
DEBUG - 2020-12-30 02:07:39 --> Total execution time: 0.2991
INFO - 2020-12-30 02:07:41 --> Config Class Initialized
INFO - 2020-12-30 02:07:41 --> Hooks Class Initialized
DEBUG - 2020-12-30 02:07:41 --> UTF-8 Support Enabled
INFO - 2020-12-30 02:07:41 --> Utf8 Class Initialized
INFO - 2020-12-30 02:07:41 --> URI Class Initialized
INFO - 2020-12-30 02:07:41 --> Router Class Initialized
INFO - 2020-12-30 02:07:41 --> Output Class Initialized
INFO - 2020-12-30 02:07:41 --> Security Class Initialized
DEBUG - 2020-12-30 02:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 02:07:41 --> Input Class Initialized
INFO - 2020-12-30 02:07:41 --> Language Class Initialized
INFO - 2020-12-30 02:07:41 --> Language Class Initialized
INFO - 2020-12-30 02:07:41 --> Config Class Initialized
INFO - 2020-12-30 02:07:41 --> Loader Class Initialized
INFO - 2020-12-30 02:07:41 --> Helper loaded: url_helper
INFO - 2020-12-30 02:07:41 --> Helper loaded: file_helper
INFO - 2020-12-30 02:07:42 --> Helper loaded: form_helper
INFO - 2020-12-30 02:07:42 --> Helper loaded: my_helper
INFO - 2020-12-30 02:07:42 --> Database Driver Class Initialized
DEBUG - 2020-12-30 02:07:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 02:07:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 02:07:42 --> Controller Class Initialized
DEBUG - 2020-12-30 02:07:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2020-12-30 02:07:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 02:07:42 --> Final output sent to browser
DEBUG - 2020-12-30 02:07:42 --> Total execution time: 0.3157
INFO - 2020-12-30 02:07:46 --> Config Class Initialized
INFO - 2020-12-30 02:07:46 --> Hooks Class Initialized
DEBUG - 2020-12-30 02:07:46 --> UTF-8 Support Enabled
INFO - 2020-12-30 02:07:46 --> Utf8 Class Initialized
INFO - 2020-12-30 02:07:46 --> URI Class Initialized
INFO - 2020-12-30 02:07:46 --> Router Class Initialized
INFO - 2020-12-30 02:07:46 --> Output Class Initialized
INFO - 2020-12-30 02:07:46 --> Security Class Initialized
DEBUG - 2020-12-30 02:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 02:07:46 --> Input Class Initialized
INFO - 2020-12-30 02:07:46 --> Language Class Initialized
INFO - 2020-12-30 02:07:46 --> Language Class Initialized
INFO - 2020-12-30 02:07:46 --> Config Class Initialized
INFO - 2020-12-30 02:07:46 --> Loader Class Initialized
INFO - 2020-12-30 02:07:46 --> Helper loaded: url_helper
INFO - 2020-12-30 02:07:46 --> Helper loaded: file_helper
INFO - 2020-12-30 02:07:47 --> Helper loaded: form_helper
INFO - 2020-12-30 02:07:47 --> Helper loaded: my_helper
INFO - 2020-12-30 02:07:47 --> Database Driver Class Initialized
DEBUG - 2020-12-30 02:07:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 02:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 02:07:47 --> Controller Class Initialized
DEBUG - 2020-12-30 02:07:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-12-30 02:07:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 02:07:47 --> Final output sent to browser
DEBUG - 2020-12-30 02:07:47 --> Total execution time: 0.3070
INFO - 2020-12-30 02:07:49 --> Config Class Initialized
INFO - 2020-12-30 02:07:49 --> Hooks Class Initialized
DEBUG - 2020-12-30 02:07:49 --> UTF-8 Support Enabled
INFO - 2020-12-30 02:07:49 --> Utf8 Class Initialized
INFO - 2020-12-30 02:07:49 --> URI Class Initialized
INFO - 2020-12-30 02:07:49 --> Router Class Initialized
INFO - 2020-12-30 02:07:49 --> Output Class Initialized
INFO - 2020-12-30 02:07:49 --> Security Class Initialized
DEBUG - 2020-12-30 02:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 02:07:49 --> Input Class Initialized
INFO - 2020-12-30 02:07:49 --> Language Class Initialized
INFO - 2020-12-30 02:07:49 --> Language Class Initialized
INFO - 2020-12-30 02:07:49 --> Config Class Initialized
INFO - 2020-12-30 02:07:49 --> Loader Class Initialized
INFO - 2020-12-30 02:07:49 --> Helper loaded: url_helper
INFO - 2020-12-30 02:07:49 --> Helper loaded: file_helper
INFO - 2020-12-30 02:07:49 --> Helper loaded: form_helper
INFO - 2020-12-30 02:07:49 --> Helper loaded: my_helper
INFO - 2020-12-30 02:07:49 --> Database Driver Class Initialized
DEBUG - 2020-12-30 02:07:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 02:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 02:07:49 --> Controller Class Initialized
INFO - 2020-12-30 02:07:49 --> Final output sent to browser
DEBUG - 2020-12-30 02:07:49 --> Total execution time: 0.1935
INFO - 2020-12-30 02:07:51 --> Config Class Initialized
INFO - 2020-12-30 02:07:51 --> Hooks Class Initialized
DEBUG - 2020-12-30 02:07:51 --> UTF-8 Support Enabled
INFO - 2020-12-30 02:07:51 --> Utf8 Class Initialized
INFO - 2020-12-30 02:07:51 --> URI Class Initialized
INFO - 2020-12-30 02:07:51 --> Router Class Initialized
INFO - 2020-12-30 02:07:51 --> Output Class Initialized
INFO - 2020-12-30 02:07:51 --> Security Class Initialized
DEBUG - 2020-12-30 02:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 02:07:51 --> Input Class Initialized
INFO - 2020-12-30 02:07:51 --> Language Class Initialized
INFO - 2020-12-30 02:07:51 --> Language Class Initialized
INFO - 2020-12-30 02:07:51 --> Config Class Initialized
INFO - 2020-12-30 02:07:51 --> Loader Class Initialized
INFO - 2020-12-30 02:07:51 --> Helper loaded: url_helper
INFO - 2020-12-30 02:07:51 --> Helper loaded: file_helper
INFO - 2020-12-30 02:07:51 --> Helper loaded: form_helper
INFO - 2020-12-30 02:07:51 --> Helper loaded: my_helper
INFO - 2020-12-30 02:07:51 --> Database Driver Class Initialized
DEBUG - 2020-12-30 02:07:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 02:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 02:07:51 --> Controller Class Initialized
INFO - 2020-12-30 02:07:51 --> Final output sent to browser
DEBUG - 2020-12-30 02:07:51 --> Total execution time: 0.2148
INFO - 2020-12-30 02:07:59 --> Config Class Initialized
INFO - 2020-12-30 02:07:59 --> Hooks Class Initialized
DEBUG - 2020-12-30 02:07:59 --> UTF-8 Support Enabled
INFO - 2020-12-30 02:07:59 --> Utf8 Class Initialized
INFO - 2020-12-30 02:07:59 --> URI Class Initialized
INFO - 2020-12-30 02:07:59 --> Router Class Initialized
INFO - 2020-12-30 02:07:59 --> Output Class Initialized
INFO - 2020-12-30 02:07:59 --> Security Class Initialized
DEBUG - 2020-12-30 02:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 02:07:59 --> Input Class Initialized
INFO - 2020-12-30 02:07:59 --> Language Class Initialized
INFO - 2020-12-30 02:07:59 --> Language Class Initialized
INFO - 2020-12-30 02:07:59 --> Config Class Initialized
INFO - 2020-12-30 02:07:59 --> Loader Class Initialized
INFO - 2020-12-30 02:07:59 --> Helper loaded: url_helper
INFO - 2020-12-30 02:07:59 --> Helper loaded: file_helper
INFO - 2020-12-30 02:07:59 --> Helper loaded: form_helper
INFO - 2020-12-30 02:07:59 --> Helper loaded: my_helper
INFO - 2020-12-30 02:07:59 --> Database Driver Class Initialized
DEBUG - 2020-12-30 02:07:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 02:07:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 02:07:59 --> Controller Class Initialized
DEBUG - 2020-12-30 02:07:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2020-12-30 02:07:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 02:07:59 --> Final output sent to browser
DEBUG - 2020-12-30 02:07:59 --> Total execution time: 0.2972
INFO - 2020-12-30 02:08:01 --> Config Class Initialized
INFO - 2020-12-30 02:08:01 --> Hooks Class Initialized
DEBUG - 2020-12-30 02:08:01 --> UTF-8 Support Enabled
INFO - 2020-12-30 02:08:01 --> Utf8 Class Initialized
INFO - 2020-12-30 02:08:01 --> URI Class Initialized
INFO - 2020-12-30 02:08:01 --> Router Class Initialized
INFO - 2020-12-30 02:08:01 --> Output Class Initialized
INFO - 2020-12-30 02:08:01 --> Security Class Initialized
DEBUG - 2020-12-30 02:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 02:08:01 --> Input Class Initialized
INFO - 2020-12-30 02:08:01 --> Language Class Initialized
INFO - 2020-12-30 02:08:01 --> Language Class Initialized
INFO - 2020-12-30 02:08:01 --> Config Class Initialized
INFO - 2020-12-30 02:08:01 --> Loader Class Initialized
INFO - 2020-12-30 02:08:01 --> Helper loaded: url_helper
INFO - 2020-12-30 02:08:01 --> Helper loaded: file_helper
INFO - 2020-12-30 02:08:01 --> Helper loaded: form_helper
INFO - 2020-12-30 02:08:01 --> Helper loaded: my_helper
INFO - 2020-12-30 02:08:01 --> Database Driver Class Initialized
DEBUG - 2020-12-30 02:08:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 02:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 02:08:01 --> Controller Class Initialized
DEBUG - 2020-12-30 02:08:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/cetak.php
INFO - 2020-12-30 02:08:01 --> Final output sent to browser
DEBUG - 2020-12-30 02:08:01 --> Total execution time: 0.2946
INFO - 2020-12-30 02:08:09 --> Config Class Initialized
INFO - 2020-12-30 02:08:09 --> Hooks Class Initialized
DEBUG - 2020-12-30 02:08:09 --> UTF-8 Support Enabled
INFO - 2020-12-30 02:08:09 --> Utf8 Class Initialized
INFO - 2020-12-30 02:08:09 --> URI Class Initialized
INFO - 2020-12-30 02:08:09 --> Router Class Initialized
INFO - 2020-12-30 02:08:09 --> Output Class Initialized
INFO - 2020-12-30 02:08:09 --> Security Class Initialized
DEBUG - 2020-12-30 02:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 02:08:09 --> Input Class Initialized
INFO - 2020-12-30 02:08:09 --> Language Class Initialized
INFO - 2020-12-30 02:08:09 --> Language Class Initialized
INFO - 2020-12-30 02:08:09 --> Config Class Initialized
INFO - 2020-12-30 02:08:09 --> Loader Class Initialized
INFO - 2020-12-30 02:08:09 --> Helper loaded: url_helper
INFO - 2020-12-30 02:08:09 --> Helper loaded: file_helper
INFO - 2020-12-30 02:08:09 --> Helper loaded: form_helper
INFO - 2020-12-30 02:08:09 --> Helper loaded: my_helper
INFO - 2020-12-30 02:08:09 --> Database Driver Class Initialized
DEBUG - 2020-12-30 02:08:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 02:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 02:08:09 --> Controller Class Initialized
DEBUG - 2020-12-30 02:08:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-12-30 02:08:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 02:08:10 --> Final output sent to browser
DEBUG - 2020-12-30 02:08:10 --> Total execution time: 0.2842
INFO - 2020-12-30 02:08:11 --> Config Class Initialized
INFO - 2020-12-30 02:08:11 --> Hooks Class Initialized
DEBUG - 2020-12-30 02:08:11 --> UTF-8 Support Enabled
INFO - 2020-12-30 02:08:11 --> Utf8 Class Initialized
INFO - 2020-12-30 02:08:11 --> URI Class Initialized
INFO - 2020-12-30 02:08:11 --> Router Class Initialized
INFO - 2020-12-30 02:08:11 --> Output Class Initialized
INFO - 2020-12-30 02:08:11 --> Security Class Initialized
DEBUG - 2020-12-30 02:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 02:08:11 --> Input Class Initialized
INFO - 2020-12-30 02:08:11 --> Language Class Initialized
INFO - 2020-12-30 02:08:11 --> Language Class Initialized
INFO - 2020-12-30 02:08:11 --> Config Class Initialized
INFO - 2020-12-30 02:08:11 --> Loader Class Initialized
INFO - 2020-12-30 02:08:11 --> Helper loaded: url_helper
INFO - 2020-12-30 02:08:11 --> Helper loaded: file_helper
INFO - 2020-12-30 02:08:11 --> Helper loaded: form_helper
INFO - 2020-12-30 02:08:11 --> Helper loaded: my_helper
INFO - 2020-12-30 02:08:11 --> Database Driver Class Initialized
DEBUG - 2020-12-30 02:08:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 02:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 02:08:11 --> Controller Class Initialized
DEBUG - 2020-12-30 02:08:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-30 02:08:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 02:08:11 --> Final output sent to browser
DEBUG - 2020-12-30 02:08:11 --> Total execution time: 0.3252
INFO - 2020-12-30 02:08:24 --> Config Class Initialized
INFO - 2020-12-30 02:08:24 --> Hooks Class Initialized
DEBUG - 2020-12-30 02:08:24 --> UTF-8 Support Enabled
INFO - 2020-12-30 02:08:24 --> Utf8 Class Initialized
INFO - 2020-12-30 02:08:24 --> URI Class Initialized
DEBUG - 2020-12-30 02:08:24 --> No URI present. Default controller set.
INFO - 2020-12-30 02:08:24 --> Router Class Initialized
INFO - 2020-12-30 02:08:24 --> Output Class Initialized
INFO - 2020-12-30 02:08:24 --> Security Class Initialized
DEBUG - 2020-12-30 02:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 02:08:24 --> Input Class Initialized
INFO - 2020-12-30 02:08:24 --> Language Class Initialized
INFO - 2020-12-30 02:08:24 --> Language Class Initialized
INFO - 2020-12-30 02:08:24 --> Config Class Initialized
INFO - 2020-12-30 02:08:24 --> Loader Class Initialized
INFO - 2020-12-30 02:08:24 --> Helper loaded: url_helper
INFO - 2020-12-30 02:08:24 --> Helper loaded: file_helper
INFO - 2020-12-30 02:08:24 --> Helper loaded: form_helper
INFO - 2020-12-30 02:08:24 --> Helper loaded: my_helper
INFO - 2020-12-30 02:08:24 --> Database Driver Class Initialized
DEBUG - 2020-12-30 02:08:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 02:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 02:08:24 --> Controller Class Initialized
DEBUG - 2020-12-30 02:08:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-30 02:08:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 02:08:24 --> Final output sent to browser
DEBUG - 2020-12-30 02:08:24 --> Total execution time: 0.2520
INFO - 2020-12-30 02:09:27 --> Config Class Initialized
INFO - 2020-12-30 02:09:27 --> Hooks Class Initialized
DEBUG - 2020-12-30 02:09:27 --> UTF-8 Support Enabled
INFO - 2020-12-30 02:09:27 --> Utf8 Class Initialized
INFO - 2020-12-30 02:09:27 --> URI Class Initialized
DEBUG - 2020-12-30 02:09:27 --> No URI present. Default controller set.
INFO - 2020-12-30 02:09:27 --> Router Class Initialized
INFO - 2020-12-30 02:09:27 --> Output Class Initialized
INFO - 2020-12-30 02:09:27 --> Security Class Initialized
DEBUG - 2020-12-30 02:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 02:09:27 --> Input Class Initialized
INFO - 2020-12-30 02:09:27 --> Language Class Initialized
INFO - 2020-12-30 02:09:27 --> Language Class Initialized
INFO - 2020-12-30 02:09:27 --> Config Class Initialized
INFO - 2020-12-30 02:09:27 --> Loader Class Initialized
INFO - 2020-12-30 02:09:27 --> Helper loaded: url_helper
INFO - 2020-12-30 02:09:27 --> Helper loaded: file_helper
INFO - 2020-12-30 02:09:27 --> Helper loaded: form_helper
INFO - 2020-12-30 02:09:27 --> Helper loaded: my_helper
INFO - 2020-12-30 02:09:27 --> Database Driver Class Initialized
DEBUG - 2020-12-30 02:09:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 02:09:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 02:09:27 --> Controller Class Initialized
DEBUG - 2020-12-30 02:09:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-30 02:09:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 02:09:27 --> Final output sent to browser
DEBUG - 2020-12-30 02:09:27 --> Total execution time: 0.2555
INFO - 2020-12-30 03:19:48 --> Config Class Initialized
INFO - 2020-12-30 03:19:48 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:19:48 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:19:48 --> Utf8 Class Initialized
INFO - 2020-12-30 03:19:48 --> URI Class Initialized
INFO - 2020-12-30 03:19:48 --> Router Class Initialized
INFO - 2020-12-30 03:19:48 --> Output Class Initialized
INFO - 2020-12-30 03:19:48 --> Security Class Initialized
DEBUG - 2020-12-30 03:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:19:48 --> Input Class Initialized
INFO - 2020-12-30 03:19:48 --> Language Class Initialized
INFO - 2020-12-30 03:19:48 --> Language Class Initialized
INFO - 2020-12-30 03:19:48 --> Config Class Initialized
INFO - 2020-12-30 03:19:48 --> Loader Class Initialized
INFO - 2020-12-30 03:19:48 --> Helper loaded: url_helper
INFO - 2020-12-30 03:19:48 --> Helper loaded: file_helper
INFO - 2020-12-30 03:19:48 --> Helper loaded: form_helper
INFO - 2020-12-30 03:19:48 --> Helper loaded: my_helper
INFO - 2020-12-30 03:19:48 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:19:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:19:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:19:48 --> Controller Class Initialized
DEBUG - 2020-12-30 03:19:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2020-12-30 03:19:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 03:19:48 --> Final output sent to browser
DEBUG - 2020-12-30 03:19:48 --> Total execution time: 0.3627
INFO - 2020-12-30 03:19:49 --> Config Class Initialized
INFO - 2020-12-30 03:19:49 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:19:49 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:19:49 --> Utf8 Class Initialized
INFO - 2020-12-30 03:19:49 --> URI Class Initialized
INFO - 2020-12-30 03:19:49 --> Router Class Initialized
INFO - 2020-12-30 03:19:49 --> Output Class Initialized
INFO - 2020-12-30 03:19:49 --> Security Class Initialized
DEBUG - 2020-12-30 03:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:19:49 --> Input Class Initialized
INFO - 2020-12-30 03:19:49 --> Language Class Initialized
INFO - 2020-12-30 03:19:49 --> Language Class Initialized
INFO - 2020-12-30 03:19:49 --> Config Class Initialized
INFO - 2020-12-30 03:19:49 --> Loader Class Initialized
INFO - 2020-12-30 03:19:49 --> Helper loaded: url_helper
INFO - 2020-12-30 03:19:49 --> Helper loaded: file_helper
INFO - 2020-12-30 03:19:49 --> Helper loaded: form_helper
INFO - 2020-12-30 03:19:49 --> Helper loaded: my_helper
INFO - 2020-12-30 03:19:49 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:19:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:19:49 --> Controller Class Initialized
DEBUG - 2020-12-30 03:19:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-12-30 03:19:49 --> Final output sent to browser
DEBUG - 2020-12-30 03:19:49 --> Total execution time: 0.3333
INFO - 2020-12-30 03:20:42 --> Config Class Initialized
INFO - 2020-12-30 03:20:42 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:20:42 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:20:42 --> Utf8 Class Initialized
INFO - 2020-12-30 03:20:42 --> URI Class Initialized
INFO - 2020-12-30 03:20:42 --> Router Class Initialized
INFO - 2020-12-30 03:20:42 --> Output Class Initialized
INFO - 2020-12-30 03:20:42 --> Security Class Initialized
DEBUG - 2020-12-30 03:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:20:42 --> Input Class Initialized
INFO - 2020-12-30 03:20:42 --> Language Class Initialized
INFO - 2020-12-30 03:20:42 --> Language Class Initialized
INFO - 2020-12-30 03:20:42 --> Config Class Initialized
INFO - 2020-12-30 03:20:42 --> Loader Class Initialized
INFO - 2020-12-30 03:20:42 --> Helper loaded: url_helper
INFO - 2020-12-30 03:20:42 --> Helper loaded: file_helper
INFO - 2020-12-30 03:20:42 --> Helper loaded: form_helper
INFO - 2020-12-30 03:20:42 --> Helper loaded: my_helper
INFO - 2020-12-30 03:20:42 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:20:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:20:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:20:42 --> Controller Class Initialized
DEBUG - 2020-12-30 03:20:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-12-30 03:20:42 --> Final output sent to browser
DEBUG - 2020-12-30 03:20:42 --> Total execution time: 0.3295
INFO - 2020-12-30 03:32:38 --> Config Class Initialized
INFO - 2020-12-30 03:32:38 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:32:38 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:32:38 --> Utf8 Class Initialized
INFO - 2020-12-30 03:32:38 --> URI Class Initialized
INFO - 2020-12-30 03:32:38 --> Router Class Initialized
INFO - 2020-12-30 03:32:38 --> Output Class Initialized
INFO - 2020-12-30 03:32:38 --> Security Class Initialized
DEBUG - 2020-12-30 03:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:32:38 --> Input Class Initialized
INFO - 2020-12-30 03:32:38 --> Language Class Initialized
INFO - 2020-12-30 03:32:38 --> Language Class Initialized
INFO - 2020-12-30 03:32:38 --> Config Class Initialized
INFO - 2020-12-30 03:32:38 --> Loader Class Initialized
INFO - 2020-12-30 03:32:38 --> Helper loaded: url_helper
INFO - 2020-12-30 03:32:38 --> Helper loaded: file_helper
INFO - 2020-12-30 03:32:38 --> Helper loaded: form_helper
INFO - 2020-12-30 03:32:38 --> Helper loaded: my_helper
INFO - 2020-12-30 03:32:38 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:32:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:32:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:32:39 --> Controller Class Initialized
INFO - 2020-12-30 03:32:39 --> Helper loaded: cookie_helper
INFO - 2020-12-30 03:32:39 --> Config Class Initialized
INFO - 2020-12-30 03:32:39 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:32:39 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:32:39 --> Utf8 Class Initialized
INFO - 2020-12-30 03:32:39 --> URI Class Initialized
INFO - 2020-12-30 03:32:39 --> Router Class Initialized
INFO - 2020-12-30 03:32:39 --> Output Class Initialized
INFO - 2020-12-30 03:32:39 --> Security Class Initialized
DEBUG - 2020-12-30 03:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:32:39 --> Input Class Initialized
INFO - 2020-12-30 03:32:39 --> Language Class Initialized
INFO - 2020-12-30 03:32:39 --> Language Class Initialized
INFO - 2020-12-30 03:32:39 --> Config Class Initialized
INFO - 2020-12-30 03:32:39 --> Loader Class Initialized
INFO - 2020-12-30 03:32:39 --> Helper loaded: url_helper
INFO - 2020-12-30 03:32:39 --> Helper loaded: file_helper
INFO - 2020-12-30 03:32:39 --> Helper loaded: form_helper
INFO - 2020-12-30 03:32:39 --> Helper loaded: my_helper
INFO - 2020-12-30 03:32:39 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:32:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:32:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:32:39 --> Controller Class Initialized
DEBUG - 2020-12-30 03:32:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-30 03:32:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 03:32:39 --> Final output sent to browser
DEBUG - 2020-12-30 03:32:39 --> Total execution time: 0.3187
INFO - 2020-12-30 03:32:48 --> Config Class Initialized
INFO - 2020-12-30 03:32:48 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:32:48 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:32:48 --> Utf8 Class Initialized
INFO - 2020-12-30 03:32:48 --> URI Class Initialized
INFO - 2020-12-30 03:32:48 --> Router Class Initialized
INFO - 2020-12-30 03:32:48 --> Output Class Initialized
INFO - 2020-12-30 03:32:48 --> Security Class Initialized
DEBUG - 2020-12-30 03:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:32:48 --> Input Class Initialized
INFO - 2020-12-30 03:32:48 --> Language Class Initialized
INFO - 2020-12-30 03:32:48 --> Language Class Initialized
INFO - 2020-12-30 03:32:48 --> Config Class Initialized
INFO - 2020-12-30 03:32:48 --> Loader Class Initialized
INFO - 2020-12-30 03:32:48 --> Helper loaded: url_helper
INFO - 2020-12-30 03:32:48 --> Helper loaded: file_helper
INFO - 2020-12-30 03:32:48 --> Helper loaded: form_helper
INFO - 2020-12-30 03:32:48 --> Helper loaded: my_helper
INFO - 2020-12-30 03:32:48 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:32:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:32:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:32:48 --> Controller Class Initialized
INFO - 2020-12-30 03:32:48 --> Helper loaded: cookie_helper
INFO - 2020-12-30 03:32:48 --> Final output sent to browser
DEBUG - 2020-12-30 03:32:48 --> Total execution time: 0.3400
INFO - 2020-12-30 03:32:50 --> Config Class Initialized
INFO - 2020-12-30 03:32:50 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:32:51 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:32:51 --> Utf8 Class Initialized
INFO - 2020-12-30 03:32:51 --> URI Class Initialized
INFO - 2020-12-30 03:32:51 --> Router Class Initialized
INFO - 2020-12-30 03:32:51 --> Output Class Initialized
INFO - 2020-12-30 03:32:51 --> Security Class Initialized
DEBUG - 2020-12-30 03:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:32:51 --> Input Class Initialized
INFO - 2020-12-30 03:32:51 --> Language Class Initialized
INFO - 2020-12-30 03:32:51 --> Language Class Initialized
INFO - 2020-12-30 03:32:51 --> Config Class Initialized
INFO - 2020-12-30 03:32:51 --> Loader Class Initialized
INFO - 2020-12-30 03:32:51 --> Helper loaded: url_helper
INFO - 2020-12-30 03:32:51 --> Helper loaded: file_helper
INFO - 2020-12-30 03:32:51 --> Helper loaded: form_helper
INFO - 2020-12-30 03:32:51 --> Helper loaded: my_helper
INFO - 2020-12-30 03:32:51 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:32:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:32:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:32:51 --> Controller Class Initialized
DEBUG - 2020-12-30 03:32:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-30 03:32:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 03:32:51 --> Final output sent to browser
DEBUG - 2020-12-30 03:32:51 --> Total execution time: 0.4419
INFO - 2020-12-30 03:32:53 --> Config Class Initialized
INFO - 2020-12-30 03:32:53 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:32:53 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:32:53 --> Utf8 Class Initialized
INFO - 2020-12-30 03:32:53 --> URI Class Initialized
INFO - 2020-12-30 03:32:53 --> Router Class Initialized
INFO - 2020-12-30 03:32:53 --> Output Class Initialized
INFO - 2020-12-30 03:32:53 --> Security Class Initialized
DEBUG - 2020-12-30 03:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:32:53 --> Input Class Initialized
INFO - 2020-12-30 03:32:53 --> Language Class Initialized
INFO - 2020-12-30 03:32:53 --> Language Class Initialized
INFO - 2020-12-30 03:32:53 --> Config Class Initialized
INFO - 2020-12-30 03:32:53 --> Loader Class Initialized
INFO - 2020-12-30 03:32:53 --> Helper loaded: url_helper
INFO - 2020-12-30 03:32:53 --> Helper loaded: file_helper
INFO - 2020-12-30 03:32:53 --> Helper loaded: form_helper
INFO - 2020-12-30 03:32:53 --> Helper loaded: my_helper
INFO - 2020-12-30 03:32:53 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:32:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:32:53 --> Controller Class Initialized
DEBUG - 2020-12-30 03:32:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2020-12-30 03:32:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 03:32:53 --> Final output sent to browser
DEBUG - 2020-12-30 03:32:53 --> Total execution time: 0.3281
INFO - 2020-12-30 03:32:53 --> Config Class Initialized
INFO - 2020-12-30 03:32:54 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:32:54 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:32:54 --> Utf8 Class Initialized
INFO - 2020-12-30 03:32:54 --> URI Class Initialized
INFO - 2020-12-30 03:32:54 --> Router Class Initialized
INFO - 2020-12-30 03:32:54 --> Output Class Initialized
INFO - 2020-12-30 03:32:54 --> Security Class Initialized
DEBUG - 2020-12-30 03:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:32:54 --> Input Class Initialized
INFO - 2020-12-30 03:32:54 --> Language Class Initialized
INFO - 2020-12-30 03:32:54 --> Language Class Initialized
INFO - 2020-12-30 03:32:54 --> Config Class Initialized
INFO - 2020-12-30 03:32:54 --> Loader Class Initialized
INFO - 2020-12-30 03:32:54 --> Helper loaded: url_helper
INFO - 2020-12-30 03:32:54 --> Helper loaded: file_helper
INFO - 2020-12-30 03:32:54 --> Helper loaded: form_helper
INFO - 2020-12-30 03:32:54 --> Helper loaded: my_helper
INFO - 2020-12-30 03:32:54 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:32:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:32:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:32:54 --> Controller Class Initialized
INFO - 2020-12-30 03:32:54 --> Config Class Initialized
INFO - 2020-12-30 03:32:54 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:32:54 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:32:54 --> Utf8 Class Initialized
INFO - 2020-12-30 03:32:54 --> URI Class Initialized
INFO - 2020-12-30 03:32:54 --> Router Class Initialized
INFO - 2020-12-30 03:32:54 --> Output Class Initialized
INFO - 2020-12-30 03:32:54 --> Security Class Initialized
DEBUG - 2020-12-30 03:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:32:54 --> Input Class Initialized
INFO - 2020-12-30 03:32:54 --> Language Class Initialized
INFO - 2020-12-30 03:32:54 --> Language Class Initialized
INFO - 2020-12-30 03:32:55 --> Config Class Initialized
INFO - 2020-12-30 03:32:55 --> Loader Class Initialized
INFO - 2020-12-30 03:32:55 --> Helper loaded: url_helper
INFO - 2020-12-30 03:32:55 --> Helper loaded: file_helper
INFO - 2020-12-30 03:32:55 --> Helper loaded: form_helper
INFO - 2020-12-30 03:32:55 --> Helper loaded: my_helper
INFO - 2020-12-30 03:32:55 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:32:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:32:55 --> Controller Class Initialized
INFO - 2020-12-30 03:32:55 --> Final output sent to browser
DEBUG - 2020-12-30 03:32:55 --> Total execution time: 0.2786
INFO - 2020-12-30 03:33:06 --> Config Class Initialized
INFO - 2020-12-30 03:33:06 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:33:06 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:33:06 --> Utf8 Class Initialized
INFO - 2020-12-30 03:33:06 --> URI Class Initialized
INFO - 2020-12-30 03:33:06 --> Router Class Initialized
INFO - 2020-12-30 03:33:06 --> Output Class Initialized
INFO - 2020-12-30 03:33:06 --> Security Class Initialized
DEBUG - 2020-12-30 03:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:33:06 --> Input Class Initialized
INFO - 2020-12-30 03:33:06 --> Language Class Initialized
INFO - 2020-12-30 03:33:06 --> Language Class Initialized
INFO - 2020-12-30 03:33:06 --> Config Class Initialized
INFO - 2020-12-30 03:33:06 --> Loader Class Initialized
INFO - 2020-12-30 03:33:06 --> Helper loaded: url_helper
INFO - 2020-12-30 03:33:06 --> Helper loaded: file_helper
INFO - 2020-12-30 03:33:06 --> Helper loaded: form_helper
INFO - 2020-12-30 03:33:06 --> Helper loaded: my_helper
INFO - 2020-12-30 03:33:06 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:33:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:33:06 --> Controller Class Initialized
INFO - 2020-12-30 03:33:06 --> Final output sent to browser
DEBUG - 2020-12-30 03:33:06 --> Total execution time: 0.2816
INFO - 2020-12-30 03:33:06 --> Config Class Initialized
INFO - 2020-12-30 03:33:06 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:33:06 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:33:06 --> Utf8 Class Initialized
INFO - 2020-12-30 03:33:06 --> URI Class Initialized
INFO - 2020-12-30 03:33:06 --> Router Class Initialized
INFO - 2020-12-30 03:33:06 --> Output Class Initialized
INFO - 2020-12-30 03:33:06 --> Security Class Initialized
DEBUG - 2020-12-30 03:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:33:06 --> Input Class Initialized
INFO - 2020-12-30 03:33:06 --> Language Class Initialized
INFO - 2020-12-30 03:33:06 --> Language Class Initialized
INFO - 2020-12-30 03:33:06 --> Config Class Initialized
INFO - 2020-12-30 03:33:06 --> Loader Class Initialized
INFO - 2020-12-30 03:33:06 --> Helper loaded: url_helper
INFO - 2020-12-30 03:33:06 --> Helper loaded: file_helper
INFO - 2020-12-30 03:33:06 --> Helper loaded: form_helper
INFO - 2020-12-30 03:33:06 --> Helper loaded: my_helper
INFO - 2020-12-30 03:33:06 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:33:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:33:06 --> Controller Class Initialized
INFO - 2020-12-30 03:33:07 --> Config Class Initialized
INFO - 2020-12-30 03:33:07 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:33:07 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:33:07 --> Utf8 Class Initialized
INFO - 2020-12-30 03:33:07 --> URI Class Initialized
INFO - 2020-12-30 03:33:07 --> Router Class Initialized
INFO - 2020-12-30 03:33:07 --> Output Class Initialized
INFO - 2020-12-30 03:33:07 --> Security Class Initialized
DEBUG - 2020-12-30 03:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:33:08 --> Input Class Initialized
INFO - 2020-12-30 03:33:08 --> Language Class Initialized
INFO - 2020-12-30 03:33:08 --> Language Class Initialized
INFO - 2020-12-30 03:33:08 --> Config Class Initialized
INFO - 2020-12-30 03:33:08 --> Loader Class Initialized
INFO - 2020-12-30 03:33:08 --> Helper loaded: url_helper
INFO - 2020-12-30 03:33:08 --> Helper loaded: file_helper
INFO - 2020-12-30 03:33:08 --> Helper loaded: form_helper
INFO - 2020-12-30 03:33:08 --> Helper loaded: my_helper
INFO - 2020-12-30 03:33:08 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:33:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:33:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:33:08 --> Controller Class Initialized
INFO - 2020-12-30 03:33:08 --> Final output sent to browser
DEBUG - 2020-12-30 03:33:08 --> Total execution time: 0.2817
INFO - 2020-12-30 03:33:16 --> Config Class Initialized
INFO - 2020-12-30 03:33:16 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:33:16 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:33:16 --> Utf8 Class Initialized
INFO - 2020-12-30 03:33:16 --> URI Class Initialized
INFO - 2020-12-30 03:33:16 --> Router Class Initialized
INFO - 2020-12-30 03:33:16 --> Output Class Initialized
INFO - 2020-12-30 03:33:16 --> Security Class Initialized
DEBUG - 2020-12-30 03:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:33:16 --> Input Class Initialized
INFO - 2020-12-30 03:33:16 --> Language Class Initialized
INFO - 2020-12-30 03:33:16 --> Language Class Initialized
INFO - 2020-12-30 03:33:16 --> Config Class Initialized
INFO - 2020-12-30 03:33:16 --> Loader Class Initialized
INFO - 2020-12-30 03:33:16 --> Helper loaded: url_helper
INFO - 2020-12-30 03:33:16 --> Helper loaded: file_helper
INFO - 2020-12-30 03:33:16 --> Helper loaded: form_helper
INFO - 2020-12-30 03:33:16 --> Helper loaded: my_helper
INFO - 2020-12-30 03:33:16 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:33:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:33:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:33:16 --> Controller Class Initialized
INFO - 2020-12-30 03:33:16 --> Final output sent to browser
DEBUG - 2020-12-30 03:33:16 --> Total execution time: 0.3185
INFO - 2020-12-30 03:33:16 --> Config Class Initialized
INFO - 2020-12-30 03:33:16 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:33:16 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:33:16 --> Utf8 Class Initialized
INFO - 2020-12-30 03:33:16 --> URI Class Initialized
INFO - 2020-12-30 03:33:16 --> Router Class Initialized
INFO - 2020-12-30 03:33:16 --> Output Class Initialized
INFO - 2020-12-30 03:33:16 --> Security Class Initialized
DEBUG - 2020-12-30 03:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:33:16 --> Input Class Initialized
INFO - 2020-12-30 03:33:16 --> Language Class Initialized
INFO - 2020-12-30 03:33:16 --> Language Class Initialized
INFO - 2020-12-30 03:33:16 --> Config Class Initialized
INFO - 2020-12-30 03:33:16 --> Loader Class Initialized
INFO - 2020-12-30 03:33:16 --> Helper loaded: url_helper
INFO - 2020-12-30 03:33:16 --> Helper loaded: file_helper
INFO - 2020-12-30 03:33:16 --> Helper loaded: form_helper
INFO - 2020-12-30 03:33:16 --> Helper loaded: my_helper
INFO - 2020-12-30 03:33:16 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:33:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:33:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:33:16 --> Controller Class Initialized
INFO - 2020-12-30 03:33:19 --> Config Class Initialized
INFO - 2020-12-30 03:33:19 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:33:19 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:33:19 --> Utf8 Class Initialized
INFO - 2020-12-30 03:33:19 --> URI Class Initialized
INFO - 2020-12-30 03:33:19 --> Router Class Initialized
INFO - 2020-12-30 03:33:19 --> Output Class Initialized
INFO - 2020-12-30 03:33:19 --> Security Class Initialized
DEBUG - 2020-12-30 03:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:33:19 --> Input Class Initialized
INFO - 2020-12-30 03:33:19 --> Language Class Initialized
INFO - 2020-12-30 03:33:19 --> Language Class Initialized
INFO - 2020-12-30 03:33:19 --> Config Class Initialized
INFO - 2020-12-30 03:33:19 --> Loader Class Initialized
INFO - 2020-12-30 03:33:19 --> Helper loaded: url_helper
INFO - 2020-12-30 03:33:19 --> Helper loaded: file_helper
INFO - 2020-12-30 03:33:19 --> Helper loaded: form_helper
INFO - 2020-12-30 03:33:19 --> Helper loaded: my_helper
INFO - 2020-12-30 03:33:19 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:33:19 --> Controller Class Initialized
INFO - 2020-12-30 03:33:19 --> Helper loaded: cookie_helper
INFO - 2020-12-30 03:33:19 --> Config Class Initialized
INFO - 2020-12-30 03:33:19 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:33:19 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:33:19 --> Utf8 Class Initialized
INFO - 2020-12-30 03:33:19 --> URI Class Initialized
INFO - 2020-12-30 03:33:19 --> Router Class Initialized
INFO - 2020-12-30 03:33:19 --> Output Class Initialized
INFO - 2020-12-30 03:33:19 --> Security Class Initialized
DEBUG - 2020-12-30 03:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:33:19 --> Input Class Initialized
INFO - 2020-12-30 03:33:19 --> Language Class Initialized
INFO - 2020-12-30 03:33:19 --> Language Class Initialized
INFO - 2020-12-30 03:33:19 --> Config Class Initialized
INFO - 2020-12-30 03:33:19 --> Loader Class Initialized
INFO - 2020-12-30 03:33:19 --> Helper loaded: url_helper
INFO - 2020-12-30 03:33:19 --> Helper loaded: file_helper
INFO - 2020-12-30 03:33:19 --> Helper loaded: form_helper
INFO - 2020-12-30 03:33:19 --> Helper loaded: my_helper
INFO - 2020-12-30 03:33:19 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:33:19 --> Controller Class Initialized
DEBUG - 2020-12-30 03:33:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-30 03:33:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 03:33:19 --> Final output sent to browser
DEBUG - 2020-12-30 03:33:19 --> Total execution time: 0.3100
INFO - 2020-12-30 03:33:25 --> Config Class Initialized
INFO - 2020-12-30 03:33:25 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:33:25 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:33:25 --> Utf8 Class Initialized
INFO - 2020-12-30 03:33:25 --> URI Class Initialized
INFO - 2020-12-30 03:33:25 --> Router Class Initialized
INFO - 2020-12-30 03:33:25 --> Output Class Initialized
INFO - 2020-12-30 03:33:25 --> Security Class Initialized
DEBUG - 2020-12-30 03:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:33:25 --> Input Class Initialized
INFO - 2020-12-30 03:33:25 --> Language Class Initialized
INFO - 2020-12-30 03:33:25 --> Language Class Initialized
INFO - 2020-12-30 03:33:25 --> Config Class Initialized
INFO - 2020-12-30 03:33:25 --> Loader Class Initialized
INFO - 2020-12-30 03:33:25 --> Helper loaded: url_helper
INFO - 2020-12-30 03:33:25 --> Helper loaded: file_helper
INFO - 2020-12-30 03:33:25 --> Helper loaded: form_helper
INFO - 2020-12-30 03:33:25 --> Helper loaded: my_helper
INFO - 2020-12-30 03:33:25 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:33:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:33:25 --> Controller Class Initialized
INFO - 2020-12-30 03:33:25 --> Helper loaded: cookie_helper
INFO - 2020-12-30 03:33:25 --> Final output sent to browser
DEBUG - 2020-12-30 03:33:26 --> Total execution time: 0.3590
INFO - 2020-12-30 03:33:26 --> Config Class Initialized
INFO - 2020-12-30 03:33:26 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:33:26 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:33:26 --> Utf8 Class Initialized
INFO - 2020-12-30 03:33:26 --> URI Class Initialized
INFO - 2020-12-30 03:33:26 --> Router Class Initialized
INFO - 2020-12-30 03:33:26 --> Output Class Initialized
INFO - 2020-12-30 03:33:26 --> Security Class Initialized
DEBUG - 2020-12-30 03:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:33:26 --> Input Class Initialized
INFO - 2020-12-30 03:33:26 --> Language Class Initialized
INFO - 2020-12-30 03:33:26 --> Language Class Initialized
INFO - 2020-12-30 03:33:26 --> Config Class Initialized
INFO - 2020-12-30 03:33:26 --> Loader Class Initialized
INFO - 2020-12-30 03:33:26 --> Helper loaded: url_helper
INFO - 2020-12-30 03:33:26 --> Helper loaded: file_helper
INFO - 2020-12-30 03:33:26 --> Helper loaded: form_helper
INFO - 2020-12-30 03:33:26 --> Helper loaded: my_helper
INFO - 2020-12-30 03:33:26 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:33:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:33:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:33:26 --> Controller Class Initialized
DEBUG - 2020-12-30 03:33:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-30 03:33:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 03:33:27 --> Final output sent to browser
DEBUG - 2020-12-30 03:33:27 --> Total execution time: 0.3700
INFO - 2020-12-30 03:33:28 --> Config Class Initialized
INFO - 2020-12-30 03:33:28 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:33:28 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:33:28 --> Utf8 Class Initialized
INFO - 2020-12-30 03:33:28 --> URI Class Initialized
INFO - 2020-12-30 03:33:28 --> Router Class Initialized
INFO - 2020-12-30 03:33:28 --> Output Class Initialized
INFO - 2020-12-30 03:33:28 --> Security Class Initialized
DEBUG - 2020-12-30 03:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:33:28 --> Input Class Initialized
INFO - 2020-12-30 03:33:28 --> Language Class Initialized
INFO - 2020-12-30 03:33:28 --> Language Class Initialized
INFO - 2020-12-30 03:33:28 --> Config Class Initialized
INFO - 2020-12-30 03:33:28 --> Loader Class Initialized
INFO - 2020-12-30 03:33:28 --> Helper loaded: url_helper
INFO - 2020-12-30 03:33:28 --> Helper loaded: file_helper
INFO - 2020-12-30 03:33:28 --> Helper loaded: form_helper
INFO - 2020-12-30 03:33:28 --> Helper loaded: my_helper
INFO - 2020-12-30 03:33:28 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:33:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:33:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:33:28 --> Controller Class Initialized
DEBUG - 2020-12-30 03:33:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2020-12-30 03:33:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 03:33:28 --> Final output sent to browser
DEBUG - 2020-12-30 03:33:28 --> Total execution time: 0.3800
INFO - 2020-12-30 03:33:29 --> Config Class Initialized
INFO - 2020-12-30 03:33:29 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:33:29 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:33:29 --> Utf8 Class Initialized
INFO - 2020-12-30 03:33:29 --> URI Class Initialized
INFO - 2020-12-30 03:33:29 --> Router Class Initialized
INFO - 2020-12-30 03:33:29 --> Output Class Initialized
INFO - 2020-12-30 03:33:29 --> Security Class Initialized
DEBUG - 2020-12-30 03:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:33:29 --> Input Class Initialized
INFO - 2020-12-30 03:33:29 --> Language Class Initialized
INFO - 2020-12-30 03:33:29 --> Language Class Initialized
INFO - 2020-12-30 03:33:29 --> Config Class Initialized
INFO - 2020-12-30 03:33:29 --> Loader Class Initialized
INFO - 2020-12-30 03:33:29 --> Helper loaded: url_helper
INFO - 2020-12-30 03:33:29 --> Helper loaded: file_helper
INFO - 2020-12-30 03:33:29 --> Helper loaded: form_helper
INFO - 2020-12-30 03:33:29 --> Helper loaded: my_helper
INFO - 2020-12-30 03:33:29 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:33:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:33:29 --> Controller Class Initialized
DEBUG - 2020-12-30 03:33:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-12-30 03:33:29 --> Final output sent to browser
DEBUG - 2020-12-30 03:33:29 --> Total execution time: 0.2976
INFO - 2020-12-30 03:34:20 --> Config Class Initialized
INFO - 2020-12-30 03:34:20 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:34:20 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:34:20 --> Utf8 Class Initialized
INFO - 2020-12-30 03:34:20 --> URI Class Initialized
INFO - 2020-12-30 03:34:20 --> Router Class Initialized
INFO - 2020-12-30 03:34:20 --> Output Class Initialized
INFO - 2020-12-30 03:34:20 --> Security Class Initialized
DEBUG - 2020-12-30 03:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:34:20 --> Input Class Initialized
INFO - 2020-12-30 03:34:20 --> Language Class Initialized
INFO - 2020-12-30 03:34:20 --> Language Class Initialized
INFO - 2020-12-30 03:34:20 --> Config Class Initialized
INFO - 2020-12-30 03:34:20 --> Loader Class Initialized
INFO - 2020-12-30 03:34:20 --> Helper loaded: url_helper
INFO - 2020-12-30 03:34:20 --> Helper loaded: file_helper
INFO - 2020-12-30 03:34:20 --> Helper loaded: form_helper
INFO - 2020-12-30 03:34:20 --> Helper loaded: my_helper
INFO - 2020-12-30 03:34:20 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:34:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:34:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:34:21 --> Controller Class Initialized
INFO - 2020-12-30 03:34:21 --> Helper loaded: cookie_helper
INFO - 2020-12-30 03:34:21 --> Config Class Initialized
INFO - 2020-12-30 03:34:21 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:34:21 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:34:21 --> Utf8 Class Initialized
INFO - 2020-12-30 03:34:21 --> URI Class Initialized
INFO - 2020-12-30 03:34:21 --> Router Class Initialized
INFO - 2020-12-30 03:34:21 --> Output Class Initialized
INFO - 2020-12-30 03:34:21 --> Security Class Initialized
DEBUG - 2020-12-30 03:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:34:21 --> Input Class Initialized
INFO - 2020-12-30 03:34:21 --> Language Class Initialized
INFO - 2020-12-30 03:34:21 --> Language Class Initialized
INFO - 2020-12-30 03:34:21 --> Config Class Initialized
INFO - 2020-12-30 03:34:21 --> Loader Class Initialized
INFO - 2020-12-30 03:34:21 --> Helper loaded: url_helper
INFO - 2020-12-30 03:34:21 --> Helper loaded: file_helper
INFO - 2020-12-30 03:34:21 --> Helper loaded: form_helper
INFO - 2020-12-30 03:34:21 --> Helper loaded: my_helper
INFO - 2020-12-30 03:34:21 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:34:21 --> Controller Class Initialized
DEBUG - 2020-12-30 03:34:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-30 03:34:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 03:34:21 --> Final output sent to browser
DEBUG - 2020-12-30 03:34:21 --> Total execution time: 0.3347
INFO - 2020-12-30 03:34:26 --> Config Class Initialized
INFO - 2020-12-30 03:34:26 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:34:26 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:34:26 --> Utf8 Class Initialized
INFO - 2020-12-30 03:34:26 --> URI Class Initialized
INFO - 2020-12-30 03:34:26 --> Router Class Initialized
INFO - 2020-12-30 03:34:26 --> Output Class Initialized
INFO - 2020-12-30 03:34:26 --> Security Class Initialized
DEBUG - 2020-12-30 03:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:34:26 --> Input Class Initialized
INFO - 2020-12-30 03:34:26 --> Language Class Initialized
INFO - 2020-12-30 03:34:26 --> Language Class Initialized
INFO - 2020-12-30 03:34:26 --> Config Class Initialized
INFO - 2020-12-30 03:34:26 --> Loader Class Initialized
INFO - 2020-12-30 03:34:26 --> Helper loaded: url_helper
INFO - 2020-12-30 03:34:26 --> Helper loaded: file_helper
INFO - 2020-12-30 03:34:26 --> Helper loaded: form_helper
INFO - 2020-12-30 03:34:26 --> Helper loaded: my_helper
INFO - 2020-12-30 03:34:26 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:34:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:34:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:34:26 --> Controller Class Initialized
INFO - 2020-12-30 03:34:26 --> Final output sent to browser
DEBUG - 2020-12-30 03:34:26 --> Total execution time: 0.3222
INFO - 2020-12-30 03:34:30 --> Config Class Initialized
INFO - 2020-12-30 03:34:30 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:34:30 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:34:30 --> Utf8 Class Initialized
INFO - 2020-12-30 03:34:30 --> URI Class Initialized
INFO - 2020-12-30 03:34:30 --> Router Class Initialized
INFO - 2020-12-30 03:34:30 --> Output Class Initialized
INFO - 2020-12-30 03:34:30 --> Security Class Initialized
DEBUG - 2020-12-30 03:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:34:30 --> Input Class Initialized
INFO - 2020-12-30 03:34:30 --> Language Class Initialized
INFO - 2020-12-30 03:34:30 --> Language Class Initialized
INFO - 2020-12-30 03:34:30 --> Config Class Initialized
INFO - 2020-12-30 03:34:30 --> Loader Class Initialized
INFO - 2020-12-30 03:34:30 --> Helper loaded: url_helper
INFO - 2020-12-30 03:34:30 --> Helper loaded: file_helper
INFO - 2020-12-30 03:34:30 --> Helper loaded: form_helper
INFO - 2020-12-30 03:34:30 --> Helper loaded: my_helper
INFO - 2020-12-30 03:34:30 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:34:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:34:30 --> Controller Class Initialized
INFO - 2020-12-30 03:34:30 --> Helper loaded: cookie_helper
INFO - 2020-12-30 03:34:30 --> Final output sent to browser
DEBUG - 2020-12-30 03:34:30 --> Total execution time: 0.3662
INFO - 2020-12-30 03:34:31 --> Config Class Initialized
INFO - 2020-12-30 03:34:31 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:34:31 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:34:31 --> Utf8 Class Initialized
INFO - 2020-12-30 03:34:31 --> URI Class Initialized
INFO - 2020-12-30 03:34:31 --> Router Class Initialized
INFO - 2020-12-30 03:34:31 --> Output Class Initialized
INFO - 2020-12-30 03:34:31 --> Security Class Initialized
DEBUG - 2020-12-30 03:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:34:31 --> Input Class Initialized
INFO - 2020-12-30 03:34:31 --> Language Class Initialized
INFO - 2020-12-30 03:34:31 --> Language Class Initialized
INFO - 2020-12-30 03:34:31 --> Config Class Initialized
INFO - 2020-12-30 03:34:31 --> Loader Class Initialized
INFO - 2020-12-30 03:34:31 --> Helper loaded: url_helper
INFO - 2020-12-30 03:34:31 --> Helper loaded: file_helper
INFO - 2020-12-30 03:34:31 --> Helper loaded: form_helper
INFO - 2020-12-30 03:34:31 --> Helper loaded: my_helper
INFO - 2020-12-30 03:34:31 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:34:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:34:31 --> Controller Class Initialized
DEBUG - 2020-12-30 03:34:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-30 03:34:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 03:34:31 --> Final output sent to browser
DEBUG - 2020-12-30 03:34:31 --> Total execution time: 0.4620
INFO - 2020-12-30 03:34:34 --> Config Class Initialized
INFO - 2020-12-30 03:34:34 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:34:34 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:34:34 --> Utf8 Class Initialized
INFO - 2020-12-30 03:34:34 --> URI Class Initialized
INFO - 2020-12-30 03:34:34 --> Router Class Initialized
INFO - 2020-12-30 03:34:34 --> Output Class Initialized
INFO - 2020-12-30 03:34:34 --> Security Class Initialized
DEBUG - 2020-12-30 03:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:34:34 --> Input Class Initialized
INFO - 2020-12-30 03:34:34 --> Language Class Initialized
INFO - 2020-12-30 03:34:34 --> Language Class Initialized
INFO - 2020-12-30 03:34:34 --> Config Class Initialized
INFO - 2020-12-30 03:34:34 --> Loader Class Initialized
INFO - 2020-12-30 03:34:34 --> Helper loaded: url_helper
INFO - 2020-12-30 03:34:34 --> Helper loaded: file_helper
INFO - 2020-12-30 03:34:34 --> Helper loaded: form_helper
INFO - 2020-12-30 03:34:34 --> Helper loaded: my_helper
INFO - 2020-12-30 03:34:34 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:34:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:34:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:34:34 --> Controller Class Initialized
DEBUG - 2020-12-30 03:34:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2020-12-30 03:34:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 03:34:34 --> Final output sent to browser
DEBUG - 2020-12-30 03:34:34 --> Total execution time: 0.3085
INFO - 2020-12-30 03:34:34 --> Config Class Initialized
INFO - 2020-12-30 03:34:34 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:34:34 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:34:34 --> Utf8 Class Initialized
INFO - 2020-12-30 03:34:34 --> URI Class Initialized
INFO - 2020-12-30 03:34:34 --> Router Class Initialized
INFO - 2020-12-30 03:34:34 --> Output Class Initialized
INFO - 2020-12-30 03:34:34 --> Security Class Initialized
DEBUG - 2020-12-30 03:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:34:34 --> Input Class Initialized
INFO - 2020-12-30 03:34:34 --> Language Class Initialized
INFO - 2020-12-30 03:34:34 --> Language Class Initialized
INFO - 2020-12-30 03:34:34 --> Config Class Initialized
INFO - 2020-12-30 03:34:34 --> Loader Class Initialized
INFO - 2020-12-30 03:34:34 --> Helper loaded: url_helper
INFO - 2020-12-30 03:34:34 --> Helper loaded: file_helper
INFO - 2020-12-30 03:34:34 --> Helper loaded: form_helper
INFO - 2020-12-30 03:34:35 --> Helper loaded: my_helper
INFO - 2020-12-30 03:34:35 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:34:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:34:35 --> Controller Class Initialized
INFO - 2020-12-30 03:34:39 --> Config Class Initialized
INFO - 2020-12-30 03:34:39 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:34:39 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:34:39 --> Utf8 Class Initialized
INFO - 2020-12-30 03:34:39 --> URI Class Initialized
INFO - 2020-12-30 03:34:39 --> Router Class Initialized
INFO - 2020-12-30 03:34:39 --> Output Class Initialized
INFO - 2020-12-30 03:34:39 --> Security Class Initialized
DEBUG - 2020-12-30 03:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:34:39 --> Input Class Initialized
INFO - 2020-12-30 03:34:39 --> Language Class Initialized
INFO - 2020-12-30 03:34:39 --> Language Class Initialized
INFO - 2020-12-30 03:34:39 --> Config Class Initialized
INFO - 2020-12-30 03:34:39 --> Loader Class Initialized
INFO - 2020-12-30 03:34:39 --> Helper loaded: url_helper
INFO - 2020-12-30 03:34:39 --> Helper loaded: file_helper
INFO - 2020-12-30 03:34:40 --> Helper loaded: form_helper
INFO - 2020-12-30 03:34:40 --> Helper loaded: my_helper
INFO - 2020-12-30 03:34:40 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:34:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:34:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:34:40 --> Controller Class Initialized
INFO - 2020-12-30 03:34:40 --> Final output sent to browser
DEBUG - 2020-12-30 03:34:40 --> Total execution time: 0.3596
INFO - 2020-12-30 03:34:45 --> Config Class Initialized
INFO - 2020-12-30 03:34:45 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:34:45 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:34:45 --> Utf8 Class Initialized
INFO - 2020-12-30 03:34:45 --> URI Class Initialized
INFO - 2020-12-30 03:34:45 --> Router Class Initialized
INFO - 2020-12-30 03:34:45 --> Output Class Initialized
INFO - 2020-12-30 03:34:45 --> Security Class Initialized
DEBUG - 2020-12-30 03:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:34:45 --> Input Class Initialized
INFO - 2020-12-30 03:34:45 --> Language Class Initialized
INFO - 2020-12-30 03:34:45 --> Language Class Initialized
INFO - 2020-12-30 03:34:45 --> Config Class Initialized
INFO - 2020-12-30 03:34:45 --> Loader Class Initialized
INFO - 2020-12-30 03:34:45 --> Helper loaded: url_helper
INFO - 2020-12-30 03:34:45 --> Helper loaded: file_helper
INFO - 2020-12-30 03:34:45 --> Helper loaded: form_helper
INFO - 2020-12-30 03:34:45 --> Helper loaded: my_helper
INFO - 2020-12-30 03:34:45 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:34:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:34:45 --> Controller Class Initialized
INFO - 2020-12-30 03:34:45 --> Helper loaded: cookie_helper
INFO - 2020-12-30 03:34:45 --> Config Class Initialized
INFO - 2020-12-30 03:34:45 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:34:45 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:34:45 --> Utf8 Class Initialized
INFO - 2020-12-30 03:34:45 --> URI Class Initialized
INFO - 2020-12-30 03:34:45 --> Router Class Initialized
INFO - 2020-12-30 03:34:45 --> Output Class Initialized
INFO - 2020-12-30 03:34:45 --> Security Class Initialized
DEBUG - 2020-12-30 03:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:34:45 --> Input Class Initialized
INFO - 2020-12-30 03:34:45 --> Language Class Initialized
INFO - 2020-12-30 03:34:45 --> Language Class Initialized
INFO - 2020-12-30 03:34:45 --> Config Class Initialized
INFO - 2020-12-30 03:34:45 --> Loader Class Initialized
INFO - 2020-12-30 03:34:45 --> Helper loaded: url_helper
INFO - 2020-12-30 03:34:45 --> Helper loaded: file_helper
INFO - 2020-12-30 03:34:45 --> Helper loaded: form_helper
INFO - 2020-12-30 03:34:45 --> Helper loaded: my_helper
INFO - 2020-12-30 03:34:45 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:34:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:34:45 --> Controller Class Initialized
DEBUG - 2020-12-30 03:34:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-30 03:34:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 03:34:46 --> Final output sent to browser
DEBUG - 2020-12-30 03:34:46 --> Total execution time: 0.2985
INFO - 2020-12-30 03:34:49 --> Config Class Initialized
INFO - 2020-12-30 03:34:49 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:34:49 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:34:50 --> Utf8 Class Initialized
INFO - 2020-12-30 03:34:50 --> URI Class Initialized
INFO - 2020-12-30 03:34:50 --> Router Class Initialized
INFO - 2020-12-30 03:34:50 --> Output Class Initialized
INFO - 2020-12-30 03:34:50 --> Security Class Initialized
DEBUG - 2020-12-30 03:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:34:50 --> Input Class Initialized
INFO - 2020-12-30 03:34:50 --> Language Class Initialized
INFO - 2020-12-30 03:34:50 --> Language Class Initialized
INFO - 2020-12-30 03:34:50 --> Config Class Initialized
INFO - 2020-12-30 03:34:50 --> Loader Class Initialized
INFO - 2020-12-30 03:34:50 --> Helper loaded: url_helper
INFO - 2020-12-30 03:34:50 --> Helper loaded: file_helper
INFO - 2020-12-30 03:34:50 --> Helper loaded: form_helper
INFO - 2020-12-30 03:34:50 --> Helper loaded: my_helper
INFO - 2020-12-30 03:34:50 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:34:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:34:50 --> Controller Class Initialized
INFO - 2020-12-30 03:34:50 --> Helper loaded: cookie_helper
INFO - 2020-12-30 03:34:50 --> Final output sent to browser
DEBUG - 2020-12-30 03:34:50 --> Total execution time: 0.3661
INFO - 2020-12-30 03:34:50 --> Config Class Initialized
INFO - 2020-12-30 03:34:50 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:34:50 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:34:50 --> Utf8 Class Initialized
INFO - 2020-12-30 03:34:50 --> URI Class Initialized
INFO - 2020-12-30 03:34:50 --> Router Class Initialized
INFO - 2020-12-30 03:34:50 --> Output Class Initialized
INFO - 2020-12-30 03:34:50 --> Security Class Initialized
DEBUG - 2020-12-30 03:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:34:51 --> Input Class Initialized
INFO - 2020-12-30 03:34:51 --> Language Class Initialized
INFO - 2020-12-30 03:34:51 --> Language Class Initialized
INFO - 2020-12-30 03:34:51 --> Config Class Initialized
INFO - 2020-12-30 03:34:51 --> Loader Class Initialized
INFO - 2020-12-30 03:34:51 --> Helper loaded: url_helper
INFO - 2020-12-30 03:34:51 --> Helper loaded: file_helper
INFO - 2020-12-30 03:34:51 --> Helper loaded: form_helper
INFO - 2020-12-30 03:34:51 --> Helper loaded: my_helper
INFO - 2020-12-30 03:34:51 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:34:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:34:51 --> Controller Class Initialized
DEBUG - 2020-12-30 03:34:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-30 03:34:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 03:34:51 --> Final output sent to browser
DEBUG - 2020-12-30 03:34:51 --> Total execution time: 0.4592
INFO - 2020-12-30 03:36:59 --> Config Class Initialized
INFO - 2020-12-30 03:36:59 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:36:59 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:36:59 --> Utf8 Class Initialized
INFO - 2020-12-30 03:36:59 --> URI Class Initialized
INFO - 2020-12-30 03:36:59 --> Router Class Initialized
INFO - 2020-12-30 03:36:59 --> Output Class Initialized
INFO - 2020-12-30 03:36:59 --> Security Class Initialized
DEBUG - 2020-12-30 03:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:36:59 --> Input Class Initialized
INFO - 2020-12-30 03:36:59 --> Language Class Initialized
INFO - 2020-12-30 03:36:59 --> Language Class Initialized
INFO - 2020-12-30 03:36:59 --> Config Class Initialized
INFO - 2020-12-30 03:36:59 --> Loader Class Initialized
INFO - 2020-12-30 03:36:59 --> Helper loaded: url_helper
INFO - 2020-12-30 03:36:59 --> Helper loaded: file_helper
INFO - 2020-12-30 03:36:59 --> Helper loaded: form_helper
INFO - 2020-12-30 03:36:59 --> Helper loaded: my_helper
INFO - 2020-12-30 03:36:59 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:36:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:36:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:36:59 --> Controller Class Initialized
DEBUG - 2020-12-30 03:36:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2020-12-30 03:36:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 03:36:59 --> Final output sent to browser
DEBUG - 2020-12-30 03:36:59 --> Total execution time: 0.3912
INFO - 2020-12-30 03:37:00 --> Config Class Initialized
INFO - 2020-12-30 03:37:00 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:37:00 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:37:00 --> Utf8 Class Initialized
INFO - 2020-12-30 03:37:00 --> URI Class Initialized
INFO - 2020-12-30 03:37:00 --> Router Class Initialized
INFO - 2020-12-30 03:37:00 --> Output Class Initialized
INFO - 2020-12-30 03:37:00 --> Security Class Initialized
DEBUG - 2020-12-30 03:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:37:00 --> Input Class Initialized
INFO - 2020-12-30 03:37:00 --> Language Class Initialized
INFO - 2020-12-30 03:37:00 --> Language Class Initialized
INFO - 2020-12-30 03:37:00 --> Config Class Initialized
INFO - 2020-12-30 03:37:00 --> Loader Class Initialized
INFO - 2020-12-30 03:37:00 --> Helper loaded: url_helper
INFO - 2020-12-30 03:37:00 --> Helper loaded: file_helper
INFO - 2020-12-30 03:37:00 --> Helper loaded: form_helper
INFO - 2020-12-30 03:37:00 --> Helper loaded: my_helper
INFO - 2020-12-30 03:37:00 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:37:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:37:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:37:01 --> Controller Class Initialized
DEBUG - 2020-12-30 03:37:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-12-30 03:37:01 --> Final output sent to browser
DEBUG - 2020-12-30 03:37:01 --> Total execution time: 0.3206
INFO - 2020-12-30 03:49:56 --> Config Class Initialized
INFO - 2020-12-30 03:49:56 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:49:56 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:49:56 --> Utf8 Class Initialized
INFO - 2020-12-30 03:49:56 --> URI Class Initialized
INFO - 2020-12-30 03:49:56 --> Router Class Initialized
INFO - 2020-12-30 03:49:56 --> Output Class Initialized
INFO - 2020-12-30 03:49:56 --> Security Class Initialized
DEBUG - 2020-12-30 03:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:49:56 --> Input Class Initialized
INFO - 2020-12-30 03:49:56 --> Language Class Initialized
INFO - 2020-12-30 03:49:56 --> Language Class Initialized
INFO - 2020-12-30 03:49:56 --> Config Class Initialized
INFO - 2020-12-30 03:49:56 --> Loader Class Initialized
INFO - 2020-12-30 03:49:57 --> Helper loaded: url_helper
INFO - 2020-12-30 03:49:57 --> Helper loaded: file_helper
INFO - 2020-12-30 03:49:57 --> Helper loaded: form_helper
INFO - 2020-12-30 03:49:57 --> Helper loaded: my_helper
INFO - 2020-12-30 03:49:57 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:49:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:49:57 --> Controller Class Initialized
DEBUG - 2020-12-30 03:49:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2020-12-30 03:49:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 03:49:57 --> Final output sent to browser
DEBUG - 2020-12-30 03:49:57 --> Total execution time: 0.7460
INFO - 2020-12-30 03:49:58 --> Config Class Initialized
INFO - 2020-12-30 03:49:58 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:49:58 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:49:58 --> Utf8 Class Initialized
INFO - 2020-12-30 03:49:59 --> URI Class Initialized
INFO - 2020-12-30 03:49:59 --> Router Class Initialized
INFO - 2020-12-30 03:49:59 --> Output Class Initialized
INFO - 2020-12-30 03:49:59 --> Security Class Initialized
DEBUG - 2020-12-30 03:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:49:59 --> Input Class Initialized
INFO - 2020-12-30 03:49:59 --> Language Class Initialized
INFO - 2020-12-30 03:49:59 --> Language Class Initialized
INFO - 2020-12-30 03:49:59 --> Config Class Initialized
INFO - 2020-12-30 03:49:59 --> Loader Class Initialized
INFO - 2020-12-30 03:49:59 --> Helper loaded: url_helper
INFO - 2020-12-30 03:49:59 --> Helper loaded: file_helper
INFO - 2020-12-30 03:49:59 --> Helper loaded: form_helper
INFO - 2020-12-30 03:49:59 --> Helper loaded: my_helper
INFO - 2020-12-30 03:49:59 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:49:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:49:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:49:59 --> Controller Class Initialized
DEBUG - 2020-12-30 03:49:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-12-30 03:49:59 --> Final output sent to browser
DEBUG - 2020-12-30 03:49:59 --> Total execution time: 0.7651
INFO - 2020-12-30 03:50:57 --> Config Class Initialized
INFO - 2020-12-30 03:50:57 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:50:57 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:50:57 --> Utf8 Class Initialized
INFO - 2020-12-30 03:50:57 --> URI Class Initialized
INFO - 2020-12-30 03:50:57 --> Router Class Initialized
INFO - 2020-12-30 03:50:57 --> Output Class Initialized
INFO - 2020-12-30 03:50:57 --> Security Class Initialized
DEBUG - 2020-12-30 03:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:50:57 --> Input Class Initialized
INFO - 2020-12-30 03:50:57 --> Language Class Initialized
INFO - 2020-12-30 03:50:57 --> Language Class Initialized
INFO - 2020-12-30 03:50:57 --> Config Class Initialized
INFO - 2020-12-30 03:50:57 --> Loader Class Initialized
INFO - 2020-12-30 03:50:57 --> Helper loaded: url_helper
INFO - 2020-12-30 03:50:57 --> Helper loaded: file_helper
INFO - 2020-12-30 03:50:57 --> Helper loaded: form_helper
INFO - 2020-12-30 03:50:57 --> Helper loaded: my_helper
INFO - 2020-12-30 03:50:57 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:50:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:50:57 --> Controller Class Initialized
DEBUG - 2020-12-30 03:50:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2020-12-30 03:50:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 03:50:58 --> Final output sent to browser
DEBUG - 2020-12-30 03:50:58 --> Total execution time: 0.7179
INFO - 2020-12-30 03:50:59 --> Config Class Initialized
INFO - 2020-12-30 03:50:59 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:50:59 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:50:59 --> Utf8 Class Initialized
INFO - 2020-12-30 03:50:59 --> URI Class Initialized
INFO - 2020-12-30 03:50:59 --> Router Class Initialized
INFO - 2020-12-30 03:50:59 --> Output Class Initialized
INFO - 2020-12-30 03:50:59 --> Security Class Initialized
DEBUG - 2020-12-30 03:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:50:59 --> Input Class Initialized
INFO - 2020-12-30 03:50:59 --> Language Class Initialized
INFO - 2020-12-30 03:50:59 --> Language Class Initialized
INFO - 2020-12-30 03:50:59 --> Config Class Initialized
INFO - 2020-12-30 03:50:59 --> Loader Class Initialized
INFO - 2020-12-30 03:50:59 --> Helper loaded: url_helper
INFO - 2020-12-30 03:50:59 --> Helper loaded: file_helper
INFO - 2020-12-30 03:50:59 --> Helper loaded: form_helper
INFO - 2020-12-30 03:50:59 --> Helper loaded: my_helper
INFO - 2020-12-30 03:50:59 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:50:59 --> Controller Class Initialized
DEBUG - 2020-12-30 03:51:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-12-30 03:51:00 --> Final output sent to browser
DEBUG - 2020-12-30 03:51:00 --> Total execution time: 0.7581
INFO - 2020-12-30 03:51:16 --> Config Class Initialized
INFO - 2020-12-30 03:51:16 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:51:16 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:51:16 --> Utf8 Class Initialized
INFO - 2020-12-30 03:51:16 --> URI Class Initialized
INFO - 2020-12-30 03:51:16 --> Router Class Initialized
INFO - 2020-12-30 03:51:16 --> Output Class Initialized
INFO - 2020-12-30 03:51:16 --> Security Class Initialized
DEBUG - 2020-12-30 03:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:51:16 --> Input Class Initialized
INFO - 2020-12-30 03:51:16 --> Language Class Initialized
INFO - 2020-12-30 03:51:16 --> Language Class Initialized
INFO - 2020-12-30 03:51:16 --> Config Class Initialized
INFO - 2020-12-30 03:51:16 --> Loader Class Initialized
INFO - 2020-12-30 03:51:17 --> Helper loaded: url_helper
INFO - 2020-12-30 03:51:17 --> Helper loaded: file_helper
INFO - 2020-12-30 03:51:17 --> Helper loaded: form_helper
INFO - 2020-12-30 03:51:17 --> Helper loaded: my_helper
INFO - 2020-12-30 03:51:17 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:51:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:51:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:51:17 --> Controller Class Initialized
DEBUG - 2020-12-30 03:51:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2020-12-30 03:51:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 03:51:17 --> Final output sent to browser
DEBUG - 2020-12-30 03:51:17 --> Total execution time: 0.8225
INFO - 2020-12-30 03:51:20 --> Config Class Initialized
INFO - 2020-12-30 03:51:20 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:51:20 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:51:20 --> Utf8 Class Initialized
INFO - 2020-12-30 03:51:20 --> URI Class Initialized
INFO - 2020-12-30 03:51:20 --> Router Class Initialized
INFO - 2020-12-30 03:51:20 --> Output Class Initialized
INFO - 2020-12-30 03:51:20 --> Security Class Initialized
DEBUG - 2020-12-30 03:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:51:20 --> Input Class Initialized
INFO - 2020-12-30 03:51:20 --> Language Class Initialized
INFO - 2020-12-30 03:51:20 --> Language Class Initialized
INFO - 2020-12-30 03:51:20 --> Config Class Initialized
INFO - 2020-12-30 03:51:20 --> Loader Class Initialized
INFO - 2020-12-30 03:51:20 --> Helper loaded: url_helper
INFO - 2020-12-30 03:51:20 --> Helper loaded: file_helper
INFO - 2020-12-30 03:51:20 --> Helper loaded: form_helper
INFO - 2020-12-30 03:51:21 --> Helper loaded: my_helper
INFO - 2020-12-30 03:51:21 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:51:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:51:21 --> Controller Class Initialized
INFO - 2020-12-30 03:51:21 --> Helper loaded: cookie_helper
INFO - 2020-12-30 03:51:21 --> Config Class Initialized
INFO - 2020-12-30 03:51:21 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:51:21 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:51:21 --> Utf8 Class Initialized
INFO - 2020-12-30 03:51:21 --> URI Class Initialized
INFO - 2020-12-30 03:51:21 --> Router Class Initialized
INFO - 2020-12-30 03:51:21 --> Output Class Initialized
INFO - 2020-12-30 03:51:21 --> Security Class Initialized
DEBUG - 2020-12-30 03:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:51:21 --> Input Class Initialized
INFO - 2020-12-30 03:51:21 --> Language Class Initialized
INFO - 2020-12-30 03:51:21 --> Language Class Initialized
INFO - 2020-12-30 03:51:21 --> Config Class Initialized
INFO - 2020-12-30 03:51:21 --> Loader Class Initialized
INFO - 2020-12-30 03:51:21 --> Helper loaded: url_helper
INFO - 2020-12-30 03:51:21 --> Helper loaded: file_helper
INFO - 2020-12-30 03:51:21 --> Helper loaded: form_helper
INFO - 2020-12-30 03:51:21 --> Helper loaded: my_helper
INFO - 2020-12-30 03:51:22 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:51:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:51:22 --> Controller Class Initialized
DEBUG - 2020-12-30 03:51:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-30 03:51:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 03:51:22 --> Final output sent to browser
DEBUG - 2020-12-30 03:51:22 --> Total execution time: 1.1730
INFO - 2020-12-30 03:51:27 --> Config Class Initialized
INFO - 2020-12-30 03:51:27 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:51:27 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:51:27 --> Utf8 Class Initialized
INFO - 2020-12-30 03:51:27 --> URI Class Initialized
INFO - 2020-12-30 03:51:27 --> Router Class Initialized
INFO - 2020-12-30 03:51:27 --> Output Class Initialized
INFO - 2020-12-30 03:51:27 --> Security Class Initialized
DEBUG - 2020-12-30 03:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:51:27 --> Input Class Initialized
INFO - 2020-12-30 03:51:27 --> Language Class Initialized
INFO - 2020-12-30 03:51:27 --> Language Class Initialized
INFO - 2020-12-30 03:51:27 --> Config Class Initialized
INFO - 2020-12-30 03:51:28 --> Loader Class Initialized
INFO - 2020-12-30 03:51:28 --> Helper loaded: url_helper
INFO - 2020-12-30 03:51:28 --> Helper loaded: file_helper
INFO - 2020-12-30 03:51:28 --> Helper loaded: form_helper
INFO - 2020-12-30 03:51:28 --> Helper loaded: my_helper
INFO - 2020-12-30 03:51:28 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:51:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:51:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:51:28 --> Controller Class Initialized
INFO - 2020-12-30 03:51:28 --> Helper loaded: cookie_helper
INFO - 2020-12-30 03:51:28 --> Final output sent to browser
DEBUG - 2020-12-30 03:51:28 --> Total execution time: 1.1437
INFO - 2020-12-30 03:51:29 --> Config Class Initialized
INFO - 2020-12-30 03:51:29 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:51:29 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:51:29 --> Utf8 Class Initialized
INFO - 2020-12-30 03:51:29 --> URI Class Initialized
INFO - 2020-12-30 03:51:29 --> Router Class Initialized
INFO - 2020-12-30 03:51:29 --> Output Class Initialized
INFO - 2020-12-30 03:51:29 --> Security Class Initialized
DEBUG - 2020-12-30 03:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:51:29 --> Input Class Initialized
INFO - 2020-12-30 03:51:29 --> Language Class Initialized
INFO - 2020-12-30 03:51:29 --> Language Class Initialized
INFO - 2020-12-30 03:51:29 --> Config Class Initialized
INFO - 2020-12-30 03:51:29 --> Loader Class Initialized
INFO - 2020-12-30 03:51:29 --> Helper loaded: url_helper
INFO - 2020-12-30 03:51:29 --> Helper loaded: file_helper
INFO - 2020-12-30 03:51:29 --> Helper loaded: form_helper
INFO - 2020-12-30 03:51:29 --> Helper loaded: my_helper
INFO - 2020-12-30 03:51:29 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:51:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:51:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:51:29 --> Controller Class Initialized
DEBUG - 2020-12-30 03:51:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-30 03:51:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 03:51:30 --> Final output sent to browser
DEBUG - 2020-12-30 03:51:30 --> Total execution time: 1.0246
INFO - 2020-12-30 03:51:31 --> Config Class Initialized
INFO - 2020-12-30 03:51:31 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:51:31 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:51:31 --> Utf8 Class Initialized
INFO - 2020-12-30 03:51:31 --> URI Class Initialized
INFO - 2020-12-30 03:51:31 --> Router Class Initialized
INFO - 2020-12-30 03:51:31 --> Output Class Initialized
INFO - 2020-12-30 03:51:31 --> Security Class Initialized
DEBUG - 2020-12-30 03:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:51:31 --> Input Class Initialized
INFO - 2020-12-30 03:51:31 --> Language Class Initialized
INFO - 2020-12-30 03:51:31 --> Language Class Initialized
INFO - 2020-12-30 03:51:31 --> Config Class Initialized
INFO - 2020-12-30 03:51:31 --> Loader Class Initialized
INFO - 2020-12-30 03:51:31 --> Helper loaded: url_helper
INFO - 2020-12-30 03:51:31 --> Helper loaded: file_helper
INFO - 2020-12-30 03:51:31 --> Helper loaded: form_helper
INFO - 2020-12-30 03:51:31 --> Helper loaded: my_helper
INFO - 2020-12-30 03:51:31 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:51:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:51:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:51:31 --> Controller Class Initialized
DEBUG - 2020-12-30 03:51:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2020-12-30 03:51:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 03:51:31 --> Final output sent to browser
DEBUG - 2020-12-30 03:51:32 --> Total execution time: 0.8902
INFO - 2020-12-30 03:51:32 --> Config Class Initialized
INFO - 2020-12-30 03:51:32 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:51:32 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:51:32 --> Utf8 Class Initialized
INFO - 2020-12-30 03:51:32 --> URI Class Initialized
INFO - 2020-12-30 03:51:32 --> Router Class Initialized
INFO - 2020-12-30 03:51:32 --> Output Class Initialized
INFO - 2020-12-30 03:51:32 --> Security Class Initialized
DEBUG - 2020-12-30 03:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:51:32 --> Input Class Initialized
INFO - 2020-12-30 03:51:32 --> Language Class Initialized
INFO - 2020-12-30 03:51:32 --> Language Class Initialized
INFO - 2020-12-30 03:51:32 --> Config Class Initialized
INFO - 2020-12-30 03:51:32 --> Loader Class Initialized
INFO - 2020-12-30 03:51:32 --> Helper loaded: url_helper
INFO - 2020-12-30 03:51:32 --> Helper loaded: file_helper
INFO - 2020-12-30 03:51:32 --> Helper loaded: form_helper
INFO - 2020-12-30 03:51:32 --> Helper loaded: my_helper
INFO - 2020-12-30 03:51:32 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:51:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:51:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:51:32 --> Controller Class Initialized
INFO - 2020-12-30 03:52:43 --> Config Class Initialized
INFO - 2020-12-30 03:52:43 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:52:43 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:52:43 --> Utf8 Class Initialized
INFO - 2020-12-30 03:52:43 --> URI Class Initialized
INFO - 2020-12-30 03:52:43 --> Router Class Initialized
INFO - 2020-12-30 03:52:43 --> Output Class Initialized
INFO - 2020-12-30 03:52:43 --> Security Class Initialized
DEBUG - 2020-12-30 03:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:52:43 --> Input Class Initialized
INFO - 2020-12-30 03:52:43 --> Language Class Initialized
INFO - 2020-12-30 03:52:43 --> Language Class Initialized
INFO - 2020-12-30 03:52:43 --> Config Class Initialized
INFO - 2020-12-30 03:52:43 --> Loader Class Initialized
INFO - 2020-12-30 03:52:43 --> Helper loaded: url_helper
INFO - 2020-12-30 03:52:43 --> Helper loaded: file_helper
INFO - 2020-12-30 03:52:43 --> Helper loaded: form_helper
INFO - 2020-12-30 03:52:44 --> Helper loaded: my_helper
INFO - 2020-12-30 03:52:44 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:52:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:52:44 --> Controller Class Initialized
INFO - 2020-12-30 03:52:44 --> Helper loaded: cookie_helper
INFO - 2020-12-30 03:52:44 --> Config Class Initialized
INFO - 2020-12-30 03:52:44 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:52:44 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:52:44 --> Utf8 Class Initialized
INFO - 2020-12-30 03:52:44 --> URI Class Initialized
INFO - 2020-12-30 03:52:44 --> Router Class Initialized
INFO - 2020-12-30 03:52:44 --> Output Class Initialized
INFO - 2020-12-30 03:52:44 --> Security Class Initialized
DEBUG - 2020-12-30 03:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:52:44 --> Input Class Initialized
INFO - 2020-12-30 03:52:44 --> Language Class Initialized
INFO - 2020-12-30 03:52:44 --> Language Class Initialized
INFO - 2020-12-30 03:52:44 --> Config Class Initialized
INFO - 2020-12-30 03:52:44 --> Loader Class Initialized
INFO - 2020-12-30 03:52:44 --> Helper loaded: url_helper
INFO - 2020-12-30 03:52:44 --> Helper loaded: file_helper
INFO - 2020-12-30 03:52:44 --> Helper loaded: form_helper
INFO - 2020-12-30 03:52:44 --> Helper loaded: my_helper
INFO - 2020-12-30 03:52:44 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:52:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:52:44 --> Controller Class Initialized
DEBUG - 2020-12-30 03:52:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-30 03:52:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 03:52:44 --> Final output sent to browser
DEBUG - 2020-12-30 03:52:44 --> Total execution time: 0.7447
INFO - 2020-12-30 03:52:49 --> Config Class Initialized
INFO - 2020-12-30 03:52:49 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:52:49 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:52:49 --> Utf8 Class Initialized
INFO - 2020-12-30 03:52:49 --> URI Class Initialized
INFO - 2020-12-30 03:52:49 --> Router Class Initialized
INFO - 2020-12-30 03:52:49 --> Output Class Initialized
INFO - 2020-12-30 03:52:49 --> Security Class Initialized
DEBUG - 2020-12-30 03:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:52:49 --> Input Class Initialized
INFO - 2020-12-30 03:52:49 --> Language Class Initialized
INFO - 2020-12-30 03:52:49 --> Language Class Initialized
INFO - 2020-12-30 03:52:49 --> Config Class Initialized
INFO - 2020-12-30 03:52:49 --> Loader Class Initialized
INFO - 2020-12-30 03:52:49 --> Helper loaded: url_helper
INFO - 2020-12-30 03:52:49 --> Helper loaded: file_helper
INFO - 2020-12-30 03:52:49 --> Helper loaded: form_helper
INFO - 2020-12-30 03:52:49 --> Helper loaded: my_helper
INFO - 2020-12-30 03:52:49 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:52:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:52:50 --> Controller Class Initialized
INFO - 2020-12-30 03:52:50 --> Helper loaded: cookie_helper
INFO - 2020-12-30 03:52:50 --> Final output sent to browser
DEBUG - 2020-12-30 03:52:50 --> Total execution time: 0.8586
INFO - 2020-12-30 03:52:50 --> Config Class Initialized
INFO - 2020-12-30 03:52:50 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:52:50 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:52:50 --> Utf8 Class Initialized
INFO - 2020-12-30 03:52:50 --> URI Class Initialized
INFO - 2020-12-30 03:52:50 --> Router Class Initialized
INFO - 2020-12-30 03:52:50 --> Output Class Initialized
INFO - 2020-12-30 03:52:50 --> Security Class Initialized
DEBUG - 2020-12-30 03:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:52:50 --> Input Class Initialized
INFO - 2020-12-30 03:52:50 --> Language Class Initialized
INFO - 2020-12-30 03:52:50 --> Language Class Initialized
INFO - 2020-12-30 03:52:50 --> Config Class Initialized
INFO - 2020-12-30 03:52:51 --> Loader Class Initialized
INFO - 2020-12-30 03:52:51 --> Helper loaded: url_helper
INFO - 2020-12-30 03:52:51 --> Helper loaded: file_helper
INFO - 2020-12-30 03:52:51 --> Helper loaded: form_helper
INFO - 2020-12-30 03:52:51 --> Helper loaded: my_helper
INFO - 2020-12-30 03:52:51 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:52:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:52:51 --> Controller Class Initialized
DEBUG - 2020-12-30 03:52:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-30 03:52:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 03:52:51 --> Final output sent to browser
DEBUG - 2020-12-30 03:52:51 --> Total execution time: 0.8270
INFO - 2020-12-30 03:52:52 --> Config Class Initialized
INFO - 2020-12-30 03:52:52 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:52:52 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:52:52 --> Utf8 Class Initialized
INFO - 2020-12-30 03:52:52 --> URI Class Initialized
INFO - 2020-12-30 03:52:52 --> Router Class Initialized
INFO - 2020-12-30 03:52:52 --> Output Class Initialized
INFO - 2020-12-30 03:52:52 --> Security Class Initialized
DEBUG - 2020-12-30 03:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:52:52 --> Input Class Initialized
INFO - 2020-12-30 03:52:52 --> Language Class Initialized
INFO - 2020-12-30 03:52:52 --> Language Class Initialized
INFO - 2020-12-30 03:52:52 --> Config Class Initialized
INFO - 2020-12-30 03:52:52 --> Loader Class Initialized
INFO - 2020-12-30 03:52:52 --> Helper loaded: url_helper
INFO - 2020-12-30 03:52:53 --> Helper loaded: file_helper
INFO - 2020-12-30 03:52:53 --> Helper loaded: form_helper
INFO - 2020-12-30 03:52:53 --> Helper loaded: my_helper
INFO - 2020-12-30 03:52:53 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:52:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:52:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:52:53 --> Controller Class Initialized
DEBUG - 2020-12-30 03:52:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2020-12-30 03:52:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 03:52:53 --> Final output sent to browser
DEBUG - 2020-12-30 03:52:53 --> Total execution time: 0.7719
INFO - 2020-12-30 03:52:54 --> Config Class Initialized
INFO - 2020-12-30 03:52:54 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:52:54 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:52:54 --> Utf8 Class Initialized
INFO - 2020-12-30 03:52:54 --> URI Class Initialized
INFO - 2020-12-30 03:52:54 --> Router Class Initialized
INFO - 2020-12-30 03:52:54 --> Output Class Initialized
INFO - 2020-12-30 03:52:54 --> Security Class Initialized
DEBUG - 2020-12-30 03:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:52:54 --> Input Class Initialized
INFO - 2020-12-30 03:52:54 --> Language Class Initialized
INFO - 2020-12-30 03:52:54 --> Language Class Initialized
INFO - 2020-12-30 03:52:54 --> Config Class Initialized
INFO - 2020-12-30 03:52:54 --> Loader Class Initialized
INFO - 2020-12-30 03:52:54 --> Helper loaded: url_helper
INFO - 2020-12-30 03:52:54 --> Helper loaded: file_helper
INFO - 2020-12-30 03:52:54 --> Helper loaded: form_helper
INFO - 2020-12-30 03:52:54 --> Helper loaded: my_helper
INFO - 2020-12-30 03:52:54 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:52:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:52:54 --> Controller Class Initialized
DEBUG - 2020-12-30 03:52:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-12-30 03:52:55 --> Final output sent to browser
DEBUG - 2020-12-30 03:52:55 --> Total execution time: 0.7535
INFO - 2020-12-30 03:53:13 --> Config Class Initialized
INFO - 2020-12-30 03:53:13 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:53:13 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:53:13 --> Utf8 Class Initialized
INFO - 2020-12-30 03:53:13 --> URI Class Initialized
INFO - 2020-12-30 03:53:13 --> Router Class Initialized
INFO - 2020-12-30 03:53:13 --> Output Class Initialized
INFO - 2020-12-30 03:53:13 --> Security Class Initialized
DEBUG - 2020-12-30 03:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:53:13 --> Input Class Initialized
INFO - 2020-12-30 03:53:13 --> Language Class Initialized
INFO - 2020-12-30 03:53:13 --> Language Class Initialized
INFO - 2020-12-30 03:53:13 --> Config Class Initialized
INFO - 2020-12-30 03:53:13 --> Loader Class Initialized
INFO - 2020-12-30 03:53:13 --> Helper loaded: url_helper
INFO - 2020-12-30 03:53:13 --> Helper loaded: file_helper
INFO - 2020-12-30 03:53:13 --> Helper loaded: form_helper
INFO - 2020-12-30 03:53:13 --> Helper loaded: my_helper
INFO - 2020-12-30 03:53:13 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:53:13 --> Controller Class Initialized
INFO - 2020-12-30 03:53:13 --> Helper loaded: cookie_helper
INFO - 2020-12-30 03:53:13 --> Config Class Initialized
INFO - 2020-12-30 03:53:14 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:53:14 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:53:14 --> Utf8 Class Initialized
INFO - 2020-12-30 03:53:14 --> URI Class Initialized
INFO - 2020-12-30 03:53:14 --> Router Class Initialized
INFO - 2020-12-30 03:53:14 --> Output Class Initialized
INFO - 2020-12-30 03:53:14 --> Security Class Initialized
DEBUG - 2020-12-30 03:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:53:14 --> Input Class Initialized
INFO - 2020-12-30 03:53:14 --> Language Class Initialized
INFO - 2020-12-30 03:53:14 --> Language Class Initialized
INFO - 2020-12-30 03:53:14 --> Config Class Initialized
INFO - 2020-12-30 03:53:14 --> Loader Class Initialized
INFO - 2020-12-30 03:53:14 --> Helper loaded: url_helper
INFO - 2020-12-30 03:53:14 --> Helper loaded: file_helper
INFO - 2020-12-30 03:53:14 --> Helper loaded: form_helper
INFO - 2020-12-30 03:53:14 --> Helper loaded: my_helper
INFO - 2020-12-30 03:53:14 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:53:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:53:14 --> Controller Class Initialized
DEBUG - 2020-12-30 03:53:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-30 03:53:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 03:53:14 --> Final output sent to browser
DEBUG - 2020-12-30 03:53:14 --> Total execution time: 0.7492
INFO - 2020-12-30 03:53:20 --> Config Class Initialized
INFO - 2020-12-30 03:53:20 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:53:20 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:53:20 --> Utf8 Class Initialized
INFO - 2020-12-30 03:53:20 --> URI Class Initialized
INFO - 2020-12-30 03:53:20 --> Router Class Initialized
INFO - 2020-12-30 03:53:20 --> Output Class Initialized
INFO - 2020-12-30 03:53:20 --> Security Class Initialized
DEBUG - 2020-12-30 03:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:53:20 --> Input Class Initialized
INFO - 2020-12-30 03:53:20 --> Language Class Initialized
INFO - 2020-12-30 03:53:20 --> Language Class Initialized
INFO - 2020-12-30 03:53:20 --> Config Class Initialized
INFO - 2020-12-30 03:53:20 --> Loader Class Initialized
INFO - 2020-12-30 03:53:21 --> Helper loaded: url_helper
INFO - 2020-12-30 03:53:21 --> Helper loaded: file_helper
INFO - 2020-12-30 03:53:21 --> Helper loaded: form_helper
INFO - 2020-12-30 03:53:21 --> Helper loaded: my_helper
INFO - 2020-12-30 03:53:21 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:53:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:53:21 --> Controller Class Initialized
INFO - 2020-12-30 03:53:21 --> Helper loaded: cookie_helper
INFO - 2020-12-30 03:53:21 --> Final output sent to browser
DEBUG - 2020-12-30 03:53:21 --> Total execution time: 0.9033
INFO - 2020-12-30 03:53:21 --> Config Class Initialized
INFO - 2020-12-30 03:53:21 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:53:22 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:53:22 --> Utf8 Class Initialized
INFO - 2020-12-30 03:53:22 --> URI Class Initialized
INFO - 2020-12-30 03:53:22 --> Router Class Initialized
INFO - 2020-12-30 03:53:22 --> Output Class Initialized
INFO - 2020-12-30 03:53:22 --> Security Class Initialized
DEBUG - 2020-12-30 03:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:53:22 --> Input Class Initialized
INFO - 2020-12-30 03:53:22 --> Language Class Initialized
INFO - 2020-12-30 03:53:22 --> Language Class Initialized
INFO - 2020-12-30 03:53:22 --> Config Class Initialized
INFO - 2020-12-30 03:53:22 --> Loader Class Initialized
INFO - 2020-12-30 03:53:22 --> Helper loaded: url_helper
INFO - 2020-12-30 03:53:22 --> Helper loaded: file_helper
INFO - 2020-12-30 03:53:22 --> Helper loaded: form_helper
INFO - 2020-12-30 03:53:22 --> Helper loaded: my_helper
INFO - 2020-12-30 03:53:22 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:53:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:53:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:53:22 --> Controller Class Initialized
DEBUG - 2020-12-30 03:53:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-30 03:53:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 03:53:22 --> Final output sent to browser
DEBUG - 2020-12-30 03:53:22 --> Total execution time: 1.0345
INFO - 2020-12-30 03:53:24 --> Config Class Initialized
INFO - 2020-12-30 03:53:24 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:53:24 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:53:24 --> Utf8 Class Initialized
INFO - 2020-12-30 03:53:24 --> URI Class Initialized
INFO - 2020-12-30 03:53:24 --> Router Class Initialized
INFO - 2020-12-30 03:53:24 --> Output Class Initialized
INFO - 2020-12-30 03:53:24 --> Security Class Initialized
DEBUG - 2020-12-30 03:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:53:24 --> Input Class Initialized
INFO - 2020-12-30 03:53:24 --> Language Class Initialized
INFO - 2020-12-30 03:53:24 --> Language Class Initialized
INFO - 2020-12-30 03:53:24 --> Config Class Initialized
INFO - 2020-12-30 03:53:24 --> Loader Class Initialized
INFO - 2020-12-30 03:53:24 --> Helper loaded: url_helper
INFO - 2020-12-30 03:53:24 --> Helper loaded: file_helper
INFO - 2020-12-30 03:53:24 --> Helper loaded: form_helper
INFO - 2020-12-30 03:53:24 --> Helper loaded: my_helper
INFO - 2020-12-30 03:53:24 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:53:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:53:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:53:24 --> Controller Class Initialized
DEBUG - 2020-12-30 03:53:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2020-12-30 03:53:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 03:53:24 --> Final output sent to browser
DEBUG - 2020-12-30 03:53:24 --> Total execution time: 0.7607
INFO - 2020-12-30 03:53:24 --> Config Class Initialized
INFO - 2020-12-30 03:53:24 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:53:25 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:53:25 --> Utf8 Class Initialized
INFO - 2020-12-30 03:53:25 --> URI Class Initialized
INFO - 2020-12-30 03:53:25 --> Router Class Initialized
INFO - 2020-12-30 03:53:25 --> Output Class Initialized
INFO - 2020-12-30 03:53:25 --> Security Class Initialized
DEBUG - 2020-12-30 03:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:53:25 --> Input Class Initialized
INFO - 2020-12-30 03:53:25 --> Language Class Initialized
INFO - 2020-12-30 03:53:25 --> Language Class Initialized
INFO - 2020-12-30 03:53:25 --> Config Class Initialized
INFO - 2020-12-30 03:53:25 --> Loader Class Initialized
INFO - 2020-12-30 03:53:25 --> Helper loaded: url_helper
INFO - 2020-12-30 03:53:25 --> Helper loaded: file_helper
INFO - 2020-12-30 03:53:25 --> Helper loaded: form_helper
INFO - 2020-12-30 03:53:25 --> Helper loaded: my_helper
INFO - 2020-12-30 03:53:25 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:53:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:53:25 --> Controller Class Initialized
INFO - 2020-12-30 03:53:27 --> Config Class Initialized
INFO - 2020-12-30 03:53:27 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:53:27 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:53:27 --> Utf8 Class Initialized
INFO - 2020-12-30 03:53:27 --> URI Class Initialized
INFO - 2020-12-30 03:53:27 --> Router Class Initialized
INFO - 2020-12-30 03:53:27 --> Output Class Initialized
INFO - 2020-12-30 03:53:27 --> Security Class Initialized
DEBUG - 2020-12-30 03:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:53:27 --> Input Class Initialized
INFO - 2020-12-30 03:53:27 --> Language Class Initialized
INFO - 2020-12-30 03:53:27 --> Language Class Initialized
INFO - 2020-12-30 03:53:27 --> Config Class Initialized
INFO - 2020-12-30 03:53:27 --> Loader Class Initialized
INFO - 2020-12-30 03:53:27 --> Helper loaded: url_helper
INFO - 2020-12-30 03:53:27 --> Helper loaded: file_helper
INFO - 2020-12-30 03:53:27 --> Helper loaded: form_helper
INFO - 2020-12-30 03:53:27 --> Helper loaded: my_helper
INFO - 2020-12-30 03:53:27 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:53:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:53:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:53:27 --> Controller Class Initialized
INFO - 2020-12-30 03:53:27 --> Final output sent to browser
DEBUG - 2020-12-30 03:53:27 --> Total execution time: 0.7798
INFO - 2020-12-30 03:53:36 --> Config Class Initialized
INFO - 2020-12-30 03:53:36 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:53:36 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:53:36 --> Utf8 Class Initialized
INFO - 2020-12-30 03:53:36 --> URI Class Initialized
INFO - 2020-12-30 03:53:36 --> Router Class Initialized
INFO - 2020-12-30 03:53:36 --> Output Class Initialized
INFO - 2020-12-30 03:53:36 --> Security Class Initialized
DEBUG - 2020-12-30 03:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:53:36 --> Input Class Initialized
INFO - 2020-12-30 03:53:36 --> Language Class Initialized
INFO - 2020-12-30 03:53:36 --> Language Class Initialized
INFO - 2020-12-30 03:53:36 --> Config Class Initialized
INFO - 2020-12-30 03:53:36 --> Loader Class Initialized
INFO - 2020-12-30 03:53:36 --> Helper loaded: url_helper
INFO - 2020-12-30 03:53:36 --> Helper loaded: file_helper
INFO - 2020-12-30 03:53:37 --> Helper loaded: form_helper
INFO - 2020-12-30 03:53:37 --> Helper loaded: my_helper
INFO - 2020-12-30 03:53:37 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:53:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:53:37 --> Controller Class Initialized
INFO - 2020-12-30 03:53:37 --> Final output sent to browser
DEBUG - 2020-12-30 03:53:37 --> Total execution time: 0.7389
INFO - 2020-12-30 03:53:37 --> Config Class Initialized
INFO - 2020-12-30 03:53:37 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:53:37 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:53:37 --> Utf8 Class Initialized
INFO - 2020-12-30 03:53:37 --> URI Class Initialized
INFO - 2020-12-30 03:53:37 --> Router Class Initialized
INFO - 2020-12-30 03:53:37 --> Output Class Initialized
INFO - 2020-12-30 03:53:37 --> Security Class Initialized
DEBUG - 2020-12-30 03:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:53:37 --> Input Class Initialized
INFO - 2020-12-30 03:53:37 --> Language Class Initialized
INFO - 2020-12-30 03:53:37 --> Language Class Initialized
INFO - 2020-12-30 03:53:37 --> Config Class Initialized
INFO - 2020-12-30 03:53:37 --> Loader Class Initialized
INFO - 2020-12-30 03:53:37 --> Helper loaded: url_helper
INFO - 2020-12-30 03:53:37 --> Helper loaded: file_helper
INFO - 2020-12-30 03:53:38 --> Helper loaded: form_helper
INFO - 2020-12-30 03:53:38 --> Helper loaded: my_helper
INFO - 2020-12-30 03:53:38 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:53:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:53:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:53:38 --> Controller Class Initialized
INFO - 2020-12-30 03:53:40 --> Config Class Initialized
INFO - 2020-12-30 03:53:40 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:53:40 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:53:40 --> Utf8 Class Initialized
INFO - 2020-12-30 03:53:40 --> URI Class Initialized
INFO - 2020-12-30 03:53:40 --> Router Class Initialized
INFO - 2020-12-30 03:53:40 --> Output Class Initialized
INFO - 2020-12-30 03:53:40 --> Security Class Initialized
DEBUG - 2020-12-30 03:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:53:40 --> Input Class Initialized
INFO - 2020-12-30 03:53:40 --> Language Class Initialized
INFO - 2020-12-30 03:53:40 --> Language Class Initialized
INFO - 2020-12-30 03:53:40 --> Config Class Initialized
INFO - 2020-12-30 03:53:40 --> Loader Class Initialized
INFO - 2020-12-30 03:53:40 --> Helper loaded: url_helper
INFO - 2020-12-30 03:53:40 --> Helper loaded: file_helper
INFO - 2020-12-30 03:53:40 --> Helper loaded: form_helper
INFO - 2020-12-30 03:53:40 --> Helper loaded: my_helper
INFO - 2020-12-30 03:53:40 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:53:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:53:41 --> Controller Class Initialized
INFO - 2020-12-30 03:53:41 --> Final output sent to browser
DEBUG - 2020-12-30 03:53:41 --> Total execution time: 0.7392
INFO - 2020-12-30 03:53:43 --> Config Class Initialized
INFO - 2020-12-30 03:53:43 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:53:43 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:53:43 --> Utf8 Class Initialized
INFO - 2020-12-30 03:53:43 --> URI Class Initialized
INFO - 2020-12-30 03:53:43 --> Router Class Initialized
INFO - 2020-12-30 03:53:43 --> Output Class Initialized
INFO - 2020-12-30 03:53:43 --> Security Class Initialized
DEBUG - 2020-12-30 03:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:53:43 --> Input Class Initialized
INFO - 2020-12-30 03:53:44 --> Language Class Initialized
INFO - 2020-12-30 03:53:44 --> Language Class Initialized
INFO - 2020-12-30 03:53:44 --> Config Class Initialized
INFO - 2020-12-30 03:53:44 --> Loader Class Initialized
INFO - 2020-12-30 03:53:44 --> Helper loaded: url_helper
INFO - 2020-12-30 03:53:44 --> Helper loaded: file_helper
INFO - 2020-12-30 03:53:44 --> Helper loaded: form_helper
INFO - 2020-12-30 03:53:44 --> Helper loaded: my_helper
INFO - 2020-12-30 03:53:44 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:53:44 --> Controller Class Initialized
INFO - 2020-12-30 03:53:44 --> Final output sent to browser
DEBUG - 2020-12-30 03:53:44 --> Total execution time: 0.8464
INFO - 2020-12-30 03:53:44 --> Config Class Initialized
INFO - 2020-12-30 03:53:44 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:53:44 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:53:44 --> Utf8 Class Initialized
INFO - 2020-12-30 03:53:44 --> URI Class Initialized
INFO - 2020-12-30 03:53:44 --> Router Class Initialized
INFO - 2020-12-30 03:53:44 --> Output Class Initialized
INFO - 2020-12-30 03:53:44 --> Security Class Initialized
DEBUG - 2020-12-30 03:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:53:44 --> Input Class Initialized
INFO - 2020-12-30 03:53:44 --> Language Class Initialized
INFO - 2020-12-30 03:53:44 --> Language Class Initialized
INFO - 2020-12-30 03:53:44 --> Config Class Initialized
INFO - 2020-12-30 03:53:45 --> Loader Class Initialized
INFO - 2020-12-30 03:53:45 --> Helper loaded: url_helper
INFO - 2020-12-30 03:53:45 --> Helper loaded: file_helper
INFO - 2020-12-30 03:53:45 --> Helper loaded: form_helper
INFO - 2020-12-30 03:53:45 --> Helper loaded: my_helper
INFO - 2020-12-30 03:53:45 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:53:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:53:45 --> Controller Class Initialized
INFO - 2020-12-30 03:53:47 --> Config Class Initialized
INFO - 2020-12-30 03:53:47 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:53:47 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:53:47 --> Utf8 Class Initialized
INFO - 2020-12-30 03:53:47 --> URI Class Initialized
INFO - 2020-12-30 03:53:47 --> Router Class Initialized
INFO - 2020-12-30 03:53:47 --> Output Class Initialized
INFO - 2020-12-30 03:53:47 --> Security Class Initialized
DEBUG - 2020-12-30 03:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:53:47 --> Input Class Initialized
INFO - 2020-12-30 03:53:47 --> Language Class Initialized
INFO - 2020-12-30 03:53:47 --> Language Class Initialized
INFO - 2020-12-30 03:53:47 --> Config Class Initialized
INFO - 2020-12-30 03:53:47 --> Loader Class Initialized
INFO - 2020-12-30 03:53:47 --> Helper loaded: url_helper
INFO - 2020-12-30 03:53:47 --> Helper loaded: file_helper
INFO - 2020-12-30 03:53:47 --> Helper loaded: form_helper
INFO - 2020-12-30 03:53:47 --> Helper loaded: my_helper
INFO - 2020-12-30 03:53:48 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:53:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:53:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:53:48 --> Controller Class Initialized
INFO - 2020-12-30 03:53:48 --> Helper loaded: cookie_helper
INFO - 2020-12-30 03:53:48 --> Config Class Initialized
INFO - 2020-12-30 03:53:48 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:53:48 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:53:48 --> Utf8 Class Initialized
INFO - 2020-12-30 03:53:48 --> URI Class Initialized
INFO - 2020-12-30 03:53:48 --> Router Class Initialized
INFO - 2020-12-30 03:53:48 --> Output Class Initialized
INFO - 2020-12-30 03:53:48 --> Security Class Initialized
DEBUG - 2020-12-30 03:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:53:48 --> Input Class Initialized
INFO - 2020-12-30 03:53:48 --> Language Class Initialized
INFO - 2020-12-30 03:53:48 --> Language Class Initialized
INFO - 2020-12-30 03:53:48 --> Config Class Initialized
INFO - 2020-12-30 03:53:48 --> Loader Class Initialized
INFO - 2020-12-30 03:53:48 --> Helper loaded: url_helper
INFO - 2020-12-30 03:53:48 --> Helper loaded: file_helper
INFO - 2020-12-30 03:53:48 --> Helper loaded: form_helper
INFO - 2020-12-30 03:53:48 --> Helper loaded: my_helper
INFO - 2020-12-30 03:53:48 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:53:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:53:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:53:48 --> Controller Class Initialized
DEBUG - 2020-12-30 03:53:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-30 03:53:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 03:53:48 --> Final output sent to browser
DEBUG - 2020-12-30 03:53:48 --> Total execution time: 0.7161
INFO - 2020-12-30 03:53:53 --> Config Class Initialized
INFO - 2020-12-30 03:53:53 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:53:53 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:53:53 --> Utf8 Class Initialized
INFO - 2020-12-30 03:53:53 --> URI Class Initialized
INFO - 2020-12-30 03:53:53 --> Router Class Initialized
INFO - 2020-12-30 03:53:53 --> Output Class Initialized
INFO - 2020-12-30 03:53:53 --> Security Class Initialized
DEBUG - 2020-12-30 03:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:53:53 --> Input Class Initialized
INFO - 2020-12-30 03:53:53 --> Language Class Initialized
INFO - 2020-12-30 03:53:53 --> Language Class Initialized
INFO - 2020-12-30 03:53:53 --> Config Class Initialized
INFO - 2020-12-30 03:53:53 --> Loader Class Initialized
INFO - 2020-12-30 03:53:53 --> Helper loaded: url_helper
INFO - 2020-12-30 03:53:53 --> Helper loaded: file_helper
INFO - 2020-12-30 03:53:53 --> Helper loaded: form_helper
INFO - 2020-12-30 03:53:53 --> Helper loaded: my_helper
INFO - 2020-12-30 03:53:53 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:53:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:53:54 --> Controller Class Initialized
INFO - 2020-12-30 03:53:54 --> Helper loaded: cookie_helper
INFO - 2020-12-30 03:53:54 --> Final output sent to browser
DEBUG - 2020-12-30 03:53:54 --> Total execution time: 0.9406
INFO - 2020-12-30 03:53:54 --> Config Class Initialized
INFO - 2020-12-30 03:53:54 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:53:54 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:53:54 --> Utf8 Class Initialized
INFO - 2020-12-30 03:53:54 --> URI Class Initialized
INFO - 2020-12-30 03:53:55 --> Router Class Initialized
INFO - 2020-12-30 03:53:55 --> Output Class Initialized
INFO - 2020-12-30 03:53:55 --> Security Class Initialized
DEBUG - 2020-12-30 03:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:53:55 --> Input Class Initialized
INFO - 2020-12-30 03:53:55 --> Language Class Initialized
INFO - 2020-12-30 03:53:55 --> Language Class Initialized
INFO - 2020-12-30 03:53:55 --> Config Class Initialized
INFO - 2020-12-30 03:53:55 --> Loader Class Initialized
INFO - 2020-12-30 03:53:55 --> Helper loaded: url_helper
INFO - 2020-12-30 03:53:55 --> Helper loaded: file_helper
INFO - 2020-12-30 03:53:55 --> Helper loaded: form_helper
INFO - 2020-12-30 03:53:55 --> Helper loaded: my_helper
INFO - 2020-12-30 03:53:55 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:53:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:53:55 --> Controller Class Initialized
DEBUG - 2020-12-30 03:53:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-30 03:53:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 03:53:55 --> Final output sent to browser
DEBUG - 2020-12-30 03:53:55 --> Total execution time: 0.9860
INFO - 2020-12-30 03:53:58 --> Config Class Initialized
INFO - 2020-12-30 03:53:58 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:53:58 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:53:59 --> Utf8 Class Initialized
INFO - 2020-12-30 03:53:59 --> URI Class Initialized
INFO - 2020-12-30 03:53:59 --> Router Class Initialized
INFO - 2020-12-30 03:53:59 --> Output Class Initialized
INFO - 2020-12-30 03:53:59 --> Security Class Initialized
DEBUG - 2020-12-30 03:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:53:59 --> Input Class Initialized
INFO - 2020-12-30 03:53:59 --> Language Class Initialized
INFO - 2020-12-30 03:53:59 --> Language Class Initialized
INFO - 2020-12-30 03:53:59 --> Config Class Initialized
INFO - 2020-12-30 03:53:59 --> Loader Class Initialized
INFO - 2020-12-30 03:53:59 --> Helper loaded: url_helper
INFO - 2020-12-30 03:53:59 --> Helper loaded: file_helper
INFO - 2020-12-30 03:53:59 --> Helper loaded: form_helper
INFO - 2020-12-30 03:53:59 --> Helper loaded: my_helper
INFO - 2020-12-30 03:53:59 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:53:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:53:59 --> Controller Class Initialized
DEBUG - 2020-12-30 03:53:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2020-12-30 03:53:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 03:53:59 --> Final output sent to browser
DEBUG - 2020-12-30 03:53:59 --> Total execution time: 0.7570
INFO - 2020-12-30 03:54:00 --> Config Class Initialized
INFO - 2020-12-30 03:54:00 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:54:00 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:54:00 --> Utf8 Class Initialized
INFO - 2020-12-30 03:54:00 --> URI Class Initialized
INFO - 2020-12-30 03:54:00 --> Router Class Initialized
INFO - 2020-12-30 03:54:00 --> Output Class Initialized
INFO - 2020-12-30 03:54:00 --> Security Class Initialized
DEBUG - 2020-12-30 03:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:54:00 --> Input Class Initialized
INFO - 2020-12-30 03:54:01 --> Language Class Initialized
INFO - 2020-12-30 03:54:01 --> Language Class Initialized
INFO - 2020-12-30 03:54:01 --> Config Class Initialized
INFO - 2020-12-30 03:54:01 --> Loader Class Initialized
INFO - 2020-12-30 03:54:01 --> Helper loaded: url_helper
INFO - 2020-12-30 03:54:01 --> Helper loaded: file_helper
INFO - 2020-12-30 03:54:01 --> Helper loaded: form_helper
INFO - 2020-12-30 03:54:01 --> Helper loaded: my_helper
INFO - 2020-12-30 03:54:01 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:54:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:54:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:54:01 --> Controller Class Initialized
DEBUG - 2020-12-30 03:54:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-12-30 03:54:01 --> Final output sent to browser
DEBUG - 2020-12-30 03:54:01 --> Total execution time: 0.6655
INFO - 2020-12-30 03:56:33 --> Config Class Initialized
INFO - 2020-12-30 03:56:33 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:56:33 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:56:34 --> Utf8 Class Initialized
INFO - 2020-12-30 03:56:34 --> URI Class Initialized
INFO - 2020-12-30 03:56:34 --> Router Class Initialized
INFO - 2020-12-30 03:56:34 --> Output Class Initialized
INFO - 2020-12-30 03:56:34 --> Security Class Initialized
DEBUG - 2020-12-30 03:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:56:34 --> Input Class Initialized
INFO - 2020-12-30 03:56:34 --> Language Class Initialized
INFO - 2020-12-30 03:56:34 --> Language Class Initialized
INFO - 2020-12-30 03:56:34 --> Config Class Initialized
INFO - 2020-12-30 03:56:34 --> Loader Class Initialized
INFO - 2020-12-30 03:56:34 --> Helper loaded: url_helper
INFO - 2020-12-30 03:56:34 --> Helper loaded: file_helper
INFO - 2020-12-30 03:56:34 --> Helper loaded: form_helper
INFO - 2020-12-30 03:56:34 --> Helper loaded: my_helper
INFO - 2020-12-30 03:56:34 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:56:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:56:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:56:34 --> Controller Class Initialized
INFO - 2020-12-30 03:56:34 --> Helper loaded: cookie_helper
INFO - 2020-12-30 03:56:34 --> Config Class Initialized
INFO - 2020-12-30 03:56:34 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:56:34 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:56:34 --> Utf8 Class Initialized
INFO - 2020-12-30 03:56:34 --> URI Class Initialized
INFO - 2020-12-30 03:56:34 --> Router Class Initialized
INFO - 2020-12-30 03:56:34 --> Output Class Initialized
INFO - 2020-12-30 03:56:34 --> Security Class Initialized
DEBUG - 2020-12-30 03:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:56:34 --> Input Class Initialized
INFO - 2020-12-30 03:56:34 --> Language Class Initialized
INFO - 2020-12-30 03:56:34 --> Language Class Initialized
INFO - 2020-12-30 03:56:34 --> Config Class Initialized
INFO - 2020-12-30 03:56:34 --> Loader Class Initialized
INFO - 2020-12-30 03:56:35 --> Helper loaded: url_helper
INFO - 2020-12-30 03:56:35 --> Helper loaded: file_helper
INFO - 2020-12-30 03:56:35 --> Helper loaded: form_helper
INFO - 2020-12-30 03:56:35 --> Helper loaded: my_helper
INFO - 2020-12-30 03:56:35 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:56:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:56:35 --> Controller Class Initialized
DEBUG - 2020-12-30 03:56:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-30 03:56:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 03:56:35 --> Final output sent to browser
DEBUG - 2020-12-30 03:56:35 --> Total execution time: 0.6493
INFO - 2020-12-30 03:56:43 --> Config Class Initialized
INFO - 2020-12-30 03:56:43 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:56:43 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:56:43 --> Utf8 Class Initialized
INFO - 2020-12-30 03:56:43 --> URI Class Initialized
INFO - 2020-12-30 03:56:43 --> Router Class Initialized
INFO - 2020-12-30 03:56:43 --> Output Class Initialized
INFO - 2020-12-30 03:56:43 --> Security Class Initialized
DEBUG - 2020-12-30 03:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:56:43 --> Input Class Initialized
INFO - 2020-12-30 03:56:43 --> Language Class Initialized
INFO - 2020-12-30 03:56:43 --> Language Class Initialized
INFO - 2020-12-30 03:56:43 --> Config Class Initialized
INFO - 2020-12-30 03:56:43 --> Loader Class Initialized
INFO - 2020-12-30 03:56:43 --> Helper loaded: url_helper
INFO - 2020-12-30 03:56:43 --> Helper loaded: file_helper
INFO - 2020-12-30 03:56:43 --> Helper loaded: form_helper
INFO - 2020-12-30 03:56:43 --> Helper loaded: my_helper
INFO - 2020-12-30 03:56:43 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:56:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:56:43 --> Controller Class Initialized
INFO - 2020-12-30 03:56:43 --> Helper loaded: cookie_helper
INFO - 2020-12-30 03:56:43 --> Final output sent to browser
DEBUG - 2020-12-30 03:56:43 --> Total execution time: 0.8418
INFO - 2020-12-30 03:56:44 --> Config Class Initialized
INFO - 2020-12-30 03:56:44 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:56:44 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:56:44 --> Utf8 Class Initialized
INFO - 2020-12-30 03:56:44 --> URI Class Initialized
INFO - 2020-12-30 03:56:45 --> Router Class Initialized
INFO - 2020-12-30 03:56:45 --> Output Class Initialized
INFO - 2020-12-30 03:56:45 --> Security Class Initialized
DEBUG - 2020-12-30 03:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:56:45 --> Input Class Initialized
INFO - 2020-12-30 03:56:45 --> Language Class Initialized
INFO - 2020-12-30 03:56:45 --> Language Class Initialized
INFO - 2020-12-30 03:56:45 --> Config Class Initialized
INFO - 2020-12-30 03:56:45 --> Loader Class Initialized
INFO - 2020-12-30 03:56:45 --> Helper loaded: url_helper
INFO - 2020-12-30 03:56:45 --> Helper loaded: file_helper
INFO - 2020-12-30 03:56:45 --> Helper loaded: form_helper
INFO - 2020-12-30 03:56:45 --> Helper loaded: my_helper
INFO - 2020-12-30 03:56:45 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:56:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:56:45 --> Controller Class Initialized
DEBUG - 2020-12-30 03:56:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-30 03:56:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 03:56:45 --> Final output sent to browser
DEBUG - 2020-12-30 03:56:45 --> Total execution time: 0.9746
INFO - 2020-12-30 03:56:48 --> Config Class Initialized
INFO - 2020-12-30 03:56:48 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:56:48 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:56:48 --> Utf8 Class Initialized
INFO - 2020-12-30 03:56:48 --> URI Class Initialized
INFO - 2020-12-30 03:56:48 --> Router Class Initialized
INFO - 2020-12-30 03:56:48 --> Output Class Initialized
INFO - 2020-12-30 03:56:48 --> Security Class Initialized
DEBUG - 2020-12-30 03:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:56:48 --> Input Class Initialized
INFO - 2020-12-30 03:56:48 --> Language Class Initialized
INFO - 2020-12-30 03:56:48 --> Language Class Initialized
INFO - 2020-12-30 03:56:48 --> Config Class Initialized
INFO - 2020-12-30 03:56:48 --> Loader Class Initialized
INFO - 2020-12-30 03:56:48 --> Helper loaded: url_helper
INFO - 2020-12-30 03:56:48 --> Helper loaded: file_helper
INFO - 2020-12-30 03:56:48 --> Helper loaded: form_helper
INFO - 2020-12-30 03:56:48 --> Helper loaded: my_helper
INFO - 2020-12-30 03:56:48 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:56:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:56:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:56:49 --> Controller Class Initialized
DEBUG - 2020-12-30 03:56:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2020-12-30 03:56:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 03:56:49 --> Final output sent to browser
DEBUG - 2020-12-30 03:56:49 --> Total execution time: 0.9234
INFO - 2020-12-30 03:56:49 --> Config Class Initialized
INFO - 2020-12-30 03:56:49 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:56:49 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:56:49 --> Utf8 Class Initialized
INFO - 2020-12-30 03:56:49 --> URI Class Initialized
INFO - 2020-12-30 03:56:49 --> Router Class Initialized
INFO - 2020-12-30 03:56:49 --> Output Class Initialized
INFO - 2020-12-30 03:56:49 --> Security Class Initialized
DEBUG - 2020-12-30 03:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:56:49 --> Input Class Initialized
INFO - 2020-12-30 03:56:49 --> Language Class Initialized
INFO - 2020-12-30 03:56:49 --> Language Class Initialized
INFO - 2020-12-30 03:56:49 --> Config Class Initialized
INFO - 2020-12-30 03:56:49 --> Loader Class Initialized
INFO - 2020-12-30 03:56:49 --> Helper loaded: url_helper
INFO - 2020-12-30 03:56:49 --> Helper loaded: file_helper
INFO - 2020-12-30 03:56:49 --> Helper loaded: form_helper
INFO - 2020-12-30 03:56:49 --> Helper loaded: my_helper
INFO - 2020-12-30 03:56:49 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:56:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:56:50 --> Controller Class Initialized
INFO - 2020-12-30 03:56:51 --> Config Class Initialized
INFO - 2020-12-30 03:56:51 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:56:51 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:56:51 --> Utf8 Class Initialized
INFO - 2020-12-30 03:56:51 --> URI Class Initialized
INFO - 2020-12-30 03:56:51 --> Router Class Initialized
INFO - 2020-12-30 03:56:52 --> Output Class Initialized
INFO - 2020-12-30 03:56:52 --> Security Class Initialized
DEBUG - 2020-12-30 03:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:56:52 --> Input Class Initialized
INFO - 2020-12-30 03:56:52 --> Language Class Initialized
INFO - 2020-12-30 03:56:52 --> Language Class Initialized
INFO - 2020-12-30 03:56:52 --> Config Class Initialized
INFO - 2020-12-30 03:56:52 --> Loader Class Initialized
INFO - 2020-12-30 03:56:52 --> Helper loaded: url_helper
INFO - 2020-12-30 03:56:52 --> Helper loaded: file_helper
INFO - 2020-12-30 03:56:52 --> Helper loaded: form_helper
INFO - 2020-12-30 03:56:52 --> Helper loaded: my_helper
INFO - 2020-12-30 03:56:52 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:56:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:56:52 --> Controller Class Initialized
INFO - 2020-12-30 03:56:52 --> Final output sent to browser
DEBUG - 2020-12-30 03:56:52 --> Total execution time: 0.7104
INFO - 2020-12-30 03:56:55 --> Config Class Initialized
INFO - 2020-12-30 03:56:55 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:56:55 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:56:55 --> Utf8 Class Initialized
INFO - 2020-12-30 03:56:55 --> URI Class Initialized
INFO - 2020-12-30 03:56:55 --> Router Class Initialized
INFO - 2020-12-30 03:56:55 --> Output Class Initialized
INFO - 2020-12-30 03:56:55 --> Security Class Initialized
DEBUG - 2020-12-30 03:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:56:55 --> Input Class Initialized
INFO - 2020-12-30 03:56:56 --> Language Class Initialized
INFO - 2020-12-30 03:56:56 --> Language Class Initialized
INFO - 2020-12-30 03:56:56 --> Config Class Initialized
INFO - 2020-12-30 03:56:56 --> Loader Class Initialized
INFO - 2020-12-30 03:56:56 --> Helper loaded: url_helper
INFO - 2020-12-30 03:56:56 --> Helper loaded: file_helper
INFO - 2020-12-30 03:56:56 --> Helper loaded: form_helper
INFO - 2020-12-30 03:56:56 --> Helper loaded: my_helper
INFO - 2020-12-30 03:56:56 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:56:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:56:56 --> Controller Class Initialized
INFO - 2020-12-30 03:56:56 --> Final output sent to browser
DEBUG - 2020-12-30 03:56:56 --> Total execution time: 0.6804
INFO - 2020-12-30 03:56:56 --> Config Class Initialized
INFO - 2020-12-30 03:56:56 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:56:56 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:56:56 --> Utf8 Class Initialized
INFO - 2020-12-30 03:56:56 --> URI Class Initialized
INFO - 2020-12-30 03:56:56 --> Router Class Initialized
INFO - 2020-12-30 03:56:56 --> Output Class Initialized
INFO - 2020-12-30 03:56:56 --> Security Class Initialized
DEBUG - 2020-12-30 03:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:56:56 --> Input Class Initialized
INFO - 2020-12-30 03:56:56 --> Language Class Initialized
INFO - 2020-12-30 03:56:56 --> Language Class Initialized
INFO - 2020-12-30 03:56:56 --> Config Class Initialized
INFO - 2020-12-30 03:56:56 --> Loader Class Initialized
INFO - 2020-12-30 03:56:56 --> Helper loaded: url_helper
INFO - 2020-12-30 03:56:56 --> Helper loaded: file_helper
INFO - 2020-12-30 03:56:57 --> Helper loaded: form_helper
INFO - 2020-12-30 03:56:57 --> Helper loaded: my_helper
INFO - 2020-12-30 03:56:57 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:56:57 --> Controller Class Initialized
INFO - 2020-12-30 03:56:58 --> Config Class Initialized
INFO - 2020-12-30 03:56:58 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:56:58 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:56:58 --> Utf8 Class Initialized
INFO - 2020-12-30 03:56:58 --> URI Class Initialized
INFO - 2020-12-30 03:56:58 --> Router Class Initialized
INFO - 2020-12-30 03:56:58 --> Output Class Initialized
INFO - 2020-12-30 03:56:58 --> Security Class Initialized
DEBUG - 2020-12-30 03:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:56:59 --> Input Class Initialized
INFO - 2020-12-30 03:56:59 --> Language Class Initialized
INFO - 2020-12-30 03:56:59 --> Language Class Initialized
INFO - 2020-12-30 03:56:59 --> Config Class Initialized
INFO - 2020-12-30 03:56:59 --> Loader Class Initialized
INFO - 2020-12-30 03:56:59 --> Helper loaded: url_helper
INFO - 2020-12-30 03:56:59 --> Helper loaded: file_helper
INFO - 2020-12-30 03:56:59 --> Helper loaded: form_helper
INFO - 2020-12-30 03:56:59 --> Helper loaded: my_helper
INFO - 2020-12-30 03:56:59 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:56:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:56:59 --> Controller Class Initialized
INFO - 2020-12-30 03:56:59 --> Final output sent to browser
DEBUG - 2020-12-30 03:56:59 --> Total execution time: 0.6758
INFO - 2020-12-30 03:57:01 --> Config Class Initialized
INFO - 2020-12-30 03:57:01 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:57:01 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:57:01 --> Utf8 Class Initialized
INFO - 2020-12-30 03:57:01 --> URI Class Initialized
INFO - 2020-12-30 03:57:01 --> Router Class Initialized
INFO - 2020-12-30 03:57:01 --> Output Class Initialized
INFO - 2020-12-30 03:57:01 --> Security Class Initialized
DEBUG - 2020-12-30 03:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:57:01 --> Input Class Initialized
INFO - 2020-12-30 03:57:01 --> Language Class Initialized
INFO - 2020-12-30 03:57:01 --> Language Class Initialized
INFO - 2020-12-30 03:57:01 --> Config Class Initialized
INFO - 2020-12-30 03:57:01 --> Loader Class Initialized
INFO - 2020-12-30 03:57:01 --> Helper loaded: url_helper
INFO - 2020-12-30 03:57:01 --> Helper loaded: file_helper
INFO - 2020-12-30 03:57:01 --> Helper loaded: form_helper
INFO - 2020-12-30 03:57:01 --> Helper loaded: my_helper
INFO - 2020-12-30 03:57:01 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:57:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:57:01 --> Controller Class Initialized
INFO - 2020-12-30 03:57:01 --> Final output sent to browser
DEBUG - 2020-12-30 03:57:01 --> Total execution time: 0.6486
INFO - 2020-12-30 03:57:02 --> Config Class Initialized
INFO - 2020-12-30 03:57:02 --> Hooks Class Initialized
DEBUG - 2020-12-30 03:57:02 --> UTF-8 Support Enabled
INFO - 2020-12-30 03:57:02 --> Utf8 Class Initialized
INFO - 2020-12-30 03:57:02 --> URI Class Initialized
INFO - 2020-12-30 03:57:02 --> Router Class Initialized
INFO - 2020-12-30 03:57:02 --> Output Class Initialized
INFO - 2020-12-30 03:57:02 --> Security Class Initialized
DEBUG - 2020-12-30 03:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 03:57:02 --> Input Class Initialized
INFO - 2020-12-30 03:57:02 --> Language Class Initialized
INFO - 2020-12-30 03:57:02 --> Language Class Initialized
INFO - 2020-12-30 03:57:02 --> Config Class Initialized
INFO - 2020-12-30 03:57:02 --> Loader Class Initialized
INFO - 2020-12-30 03:57:02 --> Helper loaded: url_helper
INFO - 2020-12-30 03:57:02 --> Helper loaded: file_helper
INFO - 2020-12-30 03:57:02 --> Helper loaded: form_helper
INFO - 2020-12-30 03:57:02 --> Helper loaded: my_helper
INFO - 2020-12-30 03:57:03 --> Database Driver Class Initialized
DEBUG - 2020-12-30 03:57:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 03:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 03:57:03 --> Controller Class Initialized
INFO - 2020-12-30 04:00:59 --> Config Class Initialized
INFO - 2020-12-30 04:00:59 --> Hooks Class Initialized
DEBUG - 2020-12-30 04:00:59 --> UTF-8 Support Enabled
INFO - 2020-12-30 04:00:59 --> Utf8 Class Initialized
INFO - 2020-12-30 04:00:59 --> URI Class Initialized
INFO - 2020-12-30 04:00:59 --> Router Class Initialized
INFO - 2020-12-30 04:00:59 --> Output Class Initialized
INFO - 2020-12-30 04:00:59 --> Security Class Initialized
DEBUG - 2020-12-30 04:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 04:00:59 --> Input Class Initialized
INFO - 2020-12-30 04:00:59 --> Language Class Initialized
INFO - 2020-12-30 04:00:59 --> Language Class Initialized
INFO - 2020-12-30 04:00:59 --> Config Class Initialized
INFO - 2020-12-30 04:00:59 --> Loader Class Initialized
INFO - 2020-12-30 04:00:59 --> Helper loaded: url_helper
INFO - 2020-12-30 04:00:59 --> Helper loaded: file_helper
INFO - 2020-12-30 04:01:00 --> Helper loaded: form_helper
INFO - 2020-12-30 04:01:00 --> Helper loaded: my_helper
INFO - 2020-12-30 04:01:00 --> Database Driver Class Initialized
DEBUG - 2020-12-30 04:01:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 04:01:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 04:01:00 --> Controller Class Initialized
DEBUG - 2020-12-30 04:01:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-12-30 04:01:00 --> Final output sent to browser
DEBUG - 2020-12-30 04:01:00 --> Total execution time: 1.2867
INFO - 2020-12-30 04:01:36 --> Config Class Initialized
INFO - 2020-12-30 04:01:36 --> Hooks Class Initialized
DEBUG - 2020-12-30 04:01:36 --> UTF-8 Support Enabled
INFO - 2020-12-30 04:01:36 --> Utf8 Class Initialized
INFO - 2020-12-30 04:01:36 --> URI Class Initialized
INFO - 2020-12-30 04:01:36 --> Router Class Initialized
INFO - 2020-12-30 04:01:36 --> Output Class Initialized
INFO - 2020-12-30 04:01:36 --> Security Class Initialized
DEBUG - 2020-12-30 04:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 04:01:36 --> Input Class Initialized
INFO - 2020-12-30 04:01:36 --> Language Class Initialized
INFO - 2020-12-30 04:01:37 --> Language Class Initialized
INFO - 2020-12-30 04:01:37 --> Config Class Initialized
INFO - 2020-12-30 04:01:37 --> Loader Class Initialized
INFO - 2020-12-30 04:01:37 --> Helper loaded: url_helper
INFO - 2020-12-30 04:01:37 --> Helper loaded: file_helper
INFO - 2020-12-30 04:01:37 --> Helper loaded: form_helper
INFO - 2020-12-30 04:01:37 --> Helper loaded: my_helper
INFO - 2020-12-30 04:01:37 --> Database Driver Class Initialized
DEBUG - 2020-12-30 04:01:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 04:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 04:01:37 --> Controller Class Initialized
DEBUG - 2020-12-30 04:01:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-12-30 04:01:37 --> Final output sent to browser
DEBUG - 2020-12-30 04:01:37 --> Total execution time: 0.8387
INFO - 2020-12-30 04:04:02 --> Config Class Initialized
INFO - 2020-12-30 04:04:02 --> Hooks Class Initialized
DEBUG - 2020-12-30 04:04:02 --> UTF-8 Support Enabled
INFO - 2020-12-30 04:04:02 --> Utf8 Class Initialized
INFO - 2020-12-30 04:04:02 --> URI Class Initialized
INFO - 2020-12-30 04:04:03 --> Router Class Initialized
INFO - 2020-12-30 04:04:03 --> Output Class Initialized
INFO - 2020-12-30 04:04:03 --> Security Class Initialized
DEBUG - 2020-12-30 04:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 04:04:03 --> Input Class Initialized
INFO - 2020-12-30 04:04:03 --> Language Class Initialized
INFO - 2020-12-30 04:04:03 --> Language Class Initialized
INFO - 2020-12-30 04:04:03 --> Config Class Initialized
INFO - 2020-12-30 04:04:03 --> Loader Class Initialized
INFO - 2020-12-30 04:04:03 --> Helper loaded: url_helper
INFO - 2020-12-30 04:04:03 --> Helper loaded: file_helper
INFO - 2020-12-30 04:04:03 --> Helper loaded: form_helper
INFO - 2020-12-30 04:04:03 --> Helper loaded: my_helper
INFO - 2020-12-30 04:04:03 --> Database Driver Class Initialized
DEBUG - 2020-12-30 04:04:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 04:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 04:04:03 --> Controller Class Initialized
DEBUG - 2020-12-30 04:04:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-12-30 04:04:03 --> Final output sent to browser
DEBUG - 2020-12-30 04:04:03 --> Total execution time: 0.9580
INFO - 2020-12-30 04:05:59 --> Config Class Initialized
INFO - 2020-12-30 04:05:59 --> Hooks Class Initialized
DEBUG - 2020-12-30 04:05:59 --> UTF-8 Support Enabled
INFO - 2020-12-30 04:05:59 --> Utf8 Class Initialized
INFO - 2020-12-30 04:05:59 --> URI Class Initialized
INFO - 2020-12-30 04:05:59 --> Router Class Initialized
INFO - 2020-12-30 04:05:59 --> Output Class Initialized
INFO - 2020-12-30 04:05:59 --> Security Class Initialized
DEBUG - 2020-12-30 04:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 04:06:00 --> Input Class Initialized
INFO - 2020-12-30 04:06:00 --> Language Class Initialized
INFO - 2020-12-30 04:06:00 --> Language Class Initialized
INFO - 2020-12-30 04:06:00 --> Config Class Initialized
INFO - 2020-12-30 04:06:00 --> Loader Class Initialized
INFO - 2020-12-30 04:06:00 --> Helper loaded: url_helper
INFO - 2020-12-30 04:06:00 --> Helper loaded: file_helper
INFO - 2020-12-30 04:06:00 --> Helper loaded: form_helper
INFO - 2020-12-30 04:06:00 --> Helper loaded: my_helper
INFO - 2020-12-30 04:06:00 --> Database Driver Class Initialized
DEBUG - 2020-12-30 04:06:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 04:06:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 04:06:00 --> Controller Class Initialized
DEBUG - 2020-12-30 04:06:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-12-30 04:06:00 --> Final output sent to browser
DEBUG - 2020-12-30 04:06:00 --> Total execution time: 1.1995
INFO - 2020-12-30 04:07:41 --> Config Class Initialized
INFO - 2020-12-30 04:07:41 --> Hooks Class Initialized
DEBUG - 2020-12-30 04:07:41 --> UTF-8 Support Enabled
INFO - 2020-12-30 04:07:41 --> Utf8 Class Initialized
INFO - 2020-12-30 04:07:41 --> URI Class Initialized
INFO - 2020-12-30 04:07:41 --> Router Class Initialized
INFO - 2020-12-30 04:07:41 --> Output Class Initialized
INFO - 2020-12-30 04:07:41 --> Security Class Initialized
DEBUG - 2020-12-30 04:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 04:07:41 --> Input Class Initialized
INFO - 2020-12-30 04:07:41 --> Language Class Initialized
INFO - 2020-12-30 04:07:41 --> Language Class Initialized
INFO - 2020-12-30 04:07:41 --> Config Class Initialized
INFO - 2020-12-30 04:07:41 --> Loader Class Initialized
INFO - 2020-12-30 04:07:41 --> Helper loaded: url_helper
INFO - 2020-12-30 04:07:41 --> Helper loaded: file_helper
INFO - 2020-12-30 04:07:41 --> Helper loaded: form_helper
INFO - 2020-12-30 04:07:41 --> Helper loaded: my_helper
INFO - 2020-12-30 04:07:41 --> Database Driver Class Initialized
DEBUG - 2020-12-30 04:07:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 04:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 04:07:41 --> Controller Class Initialized
DEBUG - 2020-12-30 04:07:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-12-30 04:07:42 --> Final output sent to browser
DEBUG - 2020-12-30 04:07:42 --> Total execution time: 0.8175
INFO - 2020-12-30 04:08:58 --> Config Class Initialized
INFO - 2020-12-30 04:08:58 --> Hooks Class Initialized
DEBUG - 2020-12-30 04:08:59 --> UTF-8 Support Enabled
INFO - 2020-12-30 04:08:59 --> Utf8 Class Initialized
INFO - 2020-12-30 04:08:59 --> URI Class Initialized
INFO - 2020-12-30 04:08:59 --> Router Class Initialized
INFO - 2020-12-30 04:08:59 --> Output Class Initialized
INFO - 2020-12-30 04:08:59 --> Security Class Initialized
DEBUG - 2020-12-30 04:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 04:08:59 --> Input Class Initialized
INFO - 2020-12-30 04:08:59 --> Language Class Initialized
INFO - 2020-12-30 04:08:59 --> Language Class Initialized
INFO - 2020-12-30 04:08:59 --> Config Class Initialized
INFO - 2020-12-30 04:08:59 --> Loader Class Initialized
INFO - 2020-12-30 04:08:59 --> Helper loaded: url_helper
INFO - 2020-12-30 04:08:59 --> Helper loaded: file_helper
INFO - 2020-12-30 04:08:59 --> Helper loaded: form_helper
INFO - 2020-12-30 04:08:59 --> Helper loaded: my_helper
INFO - 2020-12-30 04:08:59 --> Database Driver Class Initialized
DEBUG - 2020-12-30 04:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 04:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 04:08:59 --> Controller Class Initialized
DEBUG - 2020-12-30 04:08:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-12-30 04:08:59 --> Final output sent to browser
DEBUG - 2020-12-30 04:08:59 --> Total execution time: 0.9755
INFO - 2020-12-30 04:09:42 --> Config Class Initialized
INFO - 2020-12-30 04:09:42 --> Hooks Class Initialized
DEBUG - 2020-12-30 04:09:42 --> UTF-8 Support Enabled
INFO - 2020-12-30 04:09:42 --> Utf8 Class Initialized
INFO - 2020-12-30 04:09:42 --> URI Class Initialized
INFO - 2020-12-30 04:09:42 --> Router Class Initialized
INFO - 2020-12-30 04:09:42 --> Output Class Initialized
INFO - 2020-12-30 04:09:42 --> Security Class Initialized
DEBUG - 2020-12-30 04:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 04:09:42 --> Input Class Initialized
INFO - 2020-12-30 04:09:42 --> Language Class Initialized
INFO - 2020-12-30 04:09:42 --> Language Class Initialized
INFO - 2020-12-30 04:09:42 --> Config Class Initialized
INFO - 2020-12-30 04:09:42 --> Loader Class Initialized
INFO - 2020-12-30 04:09:42 --> Helper loaded: url_helper
INFO - 2020-12-30 04:09:42 --> Helper loaded: file_helper
INFO - 2020-12-30 04:09:42 --> Helper loaded: form_helper
INFO - 2020-12-30 04:09:43 --> Helper loaded: my_helper
INFO - 2020-12-30 04:09:43 --> Database Driver Class Initialized
DEBUG - 2020-12-30 04:09:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 04:09:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 04:09:43 --> Controller Class Initialized
DEBUG - 2020-12-30 04:09:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-12-30 04:09:43 --> Final output sent to browser
DEBUG - 2020-12-30 04:09:43 --> Total execution time: 1.0024
INFO - 2020-12-30 04:10:06 --> Config Class Initialized
INFO - 2020-12-30 04:10:06 --> Hooks Class Initialized
DEBUG - 2020-12-30 04:10:06 --> UTF-8 Support Enabled
INFO - 2020-12-30 04:10:06 --> Utf8 Class Initialized
INFO - 2020-12-30 04:10:06 --> URI Class Initialized
INFO - 2020-12-30 04:10:06 --> Router Class Initialized
INFO - 2020-12-30 04:10:06 --> Output Class Initialized
INFO - 2020-12-30 04:10:06 --> Security Class Initialized
DEBUG - 2020-12-30 04:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 04:10:06 --> Input Class Initialized
INFO - 2020-12-30 04:10:06 --> Language Class Initialized
INFO - 2020-12-30 04:10:06 --> Language Class Initialized
INFO - 2020-12-30 04:10:06 --> Config Class Initialized
INFO - 2020-12-30 04:10:06 --> Loader Class Initialized
INFO - 2020-12-30 04:10:06 --> Helper loaded: url_helper
INFO - 2020-12-30 04:10:06 --> Helper loaded: file_helper
INFO - 2020-12-30 04:10:06 --> Helper loaded: form_helper
INFO - 2020-12-30 04:10:06 --> Helper loaded: my_helper
INFO - 2020-12-30 04:10:06 --> Database Driver Class Initialized
DEBUG - 2020-12-30 04:10:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 04:10:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 04:10:06 --> Controller Class Initialized
DEBUG - 2020-12-30 04:10:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-12-30 04:10:07 --> Final output sent to browser
DEBUG - 2020-12-30 04:10:07 --> Total execution time: 0.9886
INFO - 2020-12-30 04:10:52 --> Config Class Initialized
INFO - 2020-12-30 04:10:52 --> Hooks Class Initialized
DEBUG - 2020-12-30 04:10:52 --> UTF-8 Support Enabled
INFO - 2020-12-30 04:10:52 --> Utf8 Class Initialized
INFO - 2020-12-30 04:10:52 --> URI Class Initialized
INFO - 2020-12-30 04:10:52 --> Router Class Initialized
INFO - 2020-12-30 04:10:52 --> Output Class Initialized
INFO - 2020-12-30 04:10:52 --> Security Class Initialized
DEBUG - 2020-12-30 04:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 04:10:52 --> Input Class Initialized
INFO - 2020-12-30 04:10:52 --> Language Class Initialized
INFO - 2020-12-30 04:10:52 --> Language Class Initialized
INFO - 2020-12-30 04:10:52 --> Config Class Initialized
INFO - 2020-12-30 04:10:52 --> Loader Class Initialized
INFO - 2020-12-30 04:10:52 --> Helper loaded: url_helper
INFO - 2020-12-30 04:10:52 --> Helper loaded: file_helper
INFO - 2020-12-30 04:10:52 --> Helper loaded: form_helper
INFO - 2020-12-30 04:10:52 --> Helper loaded: my_helper
INFO - 2020-12-30 04:10:52 --> Database Driver Class Initialized
DEBUG - 2020-12-30 04:10:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 04:10:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 04:10:52 --> Controller Class Initialized
DEBUG - 2020-12-30 04:10:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-12-30 04:10:53 --> Final output sent to browser
DEBUG - 2020-12-30 04:10:53 --> Total execution time: 0.9602
INFO - 2020-12-30 04:11:57 --> Config Class Initialized
INFO - 2020-12-30 04:11:57 --> Hooks Class Initialized
DEBUG - 2020-12-30 04:11:57 --> UTF-8 Support Enabled
INFO - 2020-12-30 04:11:57 --> Utf8 Class Initialized
INFO - 2020-12-30 04:11:57 --> URI Class Initialized
INFO - 2020-12-30 04:11:57 --> Router Class Initialized
INFO - 2020-12-30 04:11:57 --> Output Class Initialized
INFO - 2020-12-30 04:11:57 --> Security Class Initialized
DEBUG - 2020-12-30 04:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 04:11:57 --> Input Class Initialized
INFO - 2020-12-30 04:11:57 --> Language Class Initialized
INFO - 2020-12-30 04:11:57 --> Language Class Initialized
INFO - 2020-12-30 04:11:57 --> Config Class Initialized
INFO - 2020-12-30 04:11:58 --> Loader Class Initialized
INFO - 2020-12-30 04:11:58 --> Helper loaded: url_helper
INFO - 2020-12-30 04:11:58 --> Helper loaded: file_helper
INFO - 2020-12-30 04:11:58 --> Helper loaded: form_helper
INFO - 2020-12-30 04:11:58 --> Helper loaded: my_helper
INFO - 2020-12-30 04:11:58 --> Database Driver Class Initialized
DEBUG - 2020-12-30 04:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 04:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 04:11:58 --> Controller Class Initialized
DEBUG - 2020-12-30 04:11:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-12-30 04:11:58 --> Final output sent to browser
DEBUG - 2020-12-30 04:11:58 --> Total execution time: 1.0102
INFO - 2020-12-30 04:12:32 --> Config Class Initialized
INFO - 2020-12-30 04:12:32 --> Hooks Class Initialized
DEBUG - 2020-12-30 04:12:32 --> UTF-8 Support Enabled
INFO - 2020-12-30 04:12:32 --> Utf8 Class Initialized
INFO - 2020-12-30 04:12:32 --> URI Class Initialized
INFO - 2020-12-30 04:12:32 --> Router Class Initialized
INFO - 2020-12-30 04:12:32 --> Output Class Initialized
INFO - 2020-12-30 04:12:32 --> Security Class Initialized
DEBUG - 2020-12-30 04:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 04:12:32 --> Input Class Initialized
INFO - 2020-12-30 04:12:32 --> Language Class Initialized
INFO - 2020-12-30 04:12:32 --> Language Class Initialized
INFO - 2020-12-30 04:12:32 --> Config Class Initialized
INFO - 2020-12-30 04:12:32 --> Loader Class Initialized
INFO - 2020-12-30 04:12:32 --> Helper loaded: url_helper
INFO - 2020-12-30 04:12:32 --> Helper loaded: file_helper
INFO - 2020-12-30 04:12:32 --> Helper loaded: form_helper
INFO - 2020-12-30 04:12:32 --> Helper loaded: my_helper
INFO - 2020-12-30 04:12:32 --> Database Driver Class Initialized
DEBUG - 2020-12-30 04:12:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 04:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 04:12:33 --> Controller Class Initialized
DEBUG - 2020-12-30 04:12:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-12-30 04:12:33 --> Final output sent to browser
DEBUG - 2020-12-30 04:12:33 --> Total execution time: 1.0126
INFO - 2020-12-30 05:07:43 --> Config Class Initialized
INFO - 2020-12-30 05:07:43 --> Hooks Class Initialized
DEBUG - 2020-12-30 05:07:43 --> UTF-8 Support Enabled
INFO - 2020-12-30 05:07:43 --> Utf8 Class Initialized
INFO - 2020-12-30 05:07:43 --> URI Class Initialized
INFO - 2020-12-30 05:07:43 --> Router Class Initialized
INFO - 2020-12-30 05:07:44 --> Output Class Initialized
INFO - 2020-12-30 05:07:44 --> Security Class Initialized
DEBUG - 2020-12-30 05:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 05:07:44 --> Input Class Initialized
INFO - 2020-12-30 05:07:44 --> Language Class Initialized
INFO - 2020-12-30 05:07:44 --> Language Class Initialized
INFO - 2020-12-30 05:07:44 --> Config Class Initialized
INFO - 2020-12-30 05:07:44 --> Loader Class Initialized
INFO - 2020-12-30 05:07:44 --> Helper loaded: url_helper
INFO - 2020-12-30 05:07:44 --> Helper loaded: file_helper
INFO - 2020-12-30 05:07:44 --> Helper loaded: form_helper
INFO - 2020-12-30 05:07:44 --> Helper loaded: my_helper
INFO - 2020-12-30 05:07:44 --> Database Driver Class Initialized
DEBUG - 2020-12-30 05:07:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 05:07:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 05:07:44 --> Controller Class Initialized
INFO - 2020-12-30 05:07:44 --> Helper loaded: cookie_helper
INFO - 2020-12-30 05:07:44 --> Config Class Initialized
INFO - 2020-12-30 05:07:44 --> Hooks Class Initialized
DEBUG - 2020-12-30 05:07:44 --> UTF-8 Support Enabled
INFO - 2020-12-30 05:07:44 --> Utf8 Class Initialized
INFO - 2020-12-30 05:07:44 --> URI Class Initialized
INFO - 2020-12-30 05:07:44 --> Router Class Initialized
INFO - 2020-12-30 05:07:44 --> Output Class Initialized
INFO - 2020-12-30 05:07:44 --> Security Class Initialized
DEBUG - 2020-12-30 05:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 05:07:44 --> Input Class Initialized
INFO - 2020-12-30 05:07:44 --> Language Class Initialized
INFO - 2020-12-30 05:07:44 --> Language Class Initialized
INFO - 2020-12-30 05:07:44 --> Config Class Initialized
INFO - 2020-12-30 05:07:44 --> Loader Class Initialized
INFO - 2020-12-30 05:07:44 --> Helper loaded: url_helper
INFO - 2020-12-30 05:07:44 --> Helper loaded: file_helper
INFO - 2020-12-30 05:07:44 --> Helper loaded: form_helper
INFO - 2020-12-30 05:07:44 --> Helper loaded: my_helper
INFO - 2020-12-30 05:07:44 --> Database Driver Class Initialized
DEBUG - 2020-12-30 05:07:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 05:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 05:07:45 --> Controller Class Initialized
DEBUG - 2020-12-30 05:07:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-30 05:07:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 05:07:45 --> Final output sent to browser
DEBUG - 2020-12-30 05:07:45 --> Total execution time: 0.4110
INFO - 2020-12-30 05:07:48 --> Config Class Initialized
INFO - 2020-12-30 05:07:48 --> Hooks Class Initialized
DEBUG - 2020-12-30 05:07:48 --> UTF-8 Support Enabled
INFO - 2020-12-30 05:07:48 --> Utf8 Class Initialized
INFO - 2020-12-30 05:07:48 --> URI Class Initialized
INFO - 2020-12-30 05:07:48 --> Router Class Initialized
INFO - 2020-12-30 05:07:48 --> Output Class Initialized
INFO - 2020-12-30 05:07:49 --> Security Class Initialized
DEBUG - 2020-12-30 05:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 05:07:49 --> Input Class Initialized
INFO - 2020-12-30 05:07:49 --> Language Class Initialized
INFO - 2020-12-30 05:07:49 --> Language Class Initialized
INFO - 2020-12-30 05:07:49 --> Config Class Initialized
INFO - 2020-12-30 05:07:49 --> Loader Class Initialized
INFO - 2020-12-30 05:07:49 --> Helper loaded: url_helper
INFO - 2020-12-30 05:07:49 --> Helper loaded: file_helper
INFO - 2020-12-30 05:07:49 --> Helper loaded: form_helper
INFO - 2020-12-30 05:07:49 --> Helper loaded: my_helper
INFO - 2020-12-30 05:07:49 --> Database Driver Class Initialized
DEBUG - 2020-12-30 05:07:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 05:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 05:07:49 --> Controller Class Initialized
INFO - 2020-12-30 05:07:49 --> Helper loaded: cookie_helper
INFO - 2020-12-30 05:07:49 --> Final output sent to browser
DEBUG - 2020-12-30 05:07:49 --> Total execution time: 0.5806
INFO - 2020-12-30 05:07:49 --> Config Class Initialized
INFO - 2020-12-30 05:07:49 --> Hooks Class Initialized
DEBUG - 2020-12-30 05:07:49 --> UTF-8 Support Enabled
INFO - 2020-12-30 05:07:49 --> Utf8 Class Initialized
INFO - 2020-12-30 05:07:49 --> URI Class Initialized
INFO - 2020-12-30 05:07:50 --> Router Class Initialized
INFO - 2020-12-30 05:07:50 --> Output Class Initialized
INFO - 2020-12-30 05:07:50 --> Security Class Initialized
DEBUG - 2020-12-30 05:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 05:07:50 --> Input Class Initialized
INFO - 2020-12-30 05:07:50 --> Language Class Initialized
INFO - 2020-12-30 05:07:50 --> Language Class Initialized
INFO - 2020-12-30 05:07:50 --> Config Class Initialized
INFO - 2020-12-30 05:07:50 --> Loader Class Initialized
INFO - 2020-12-30 05:07:50 --> Helper loaded: url_helper
INFO - 2020-12-30 05:07:50 --> Helper loaded: file_helper
INFO - 2020-12-30 05:07:50 --> Helper loaded: form_helper
INFO - 2020-12-30 05:07:50 --> Helper loaded: my_helper
INFO - 2020-12-30 05:07:50 --> Database Driver Class Initialized
DEBUG - 2020-12-30 05:07:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 05:07:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 05:07:50 --> Controller Class Initialized
DEBUG - 2020-12-30 05:07:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-30 05:07:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 05:07:50 --> Final output sent to browser
DEBUG - 2020-12-30 05:07:50 --> Total execution time: 0.6748
INFO - 2020-12-30 05:07:52 --> Config Class Initialized
INFO - 2020-12-30 05:07:52 --> Hooks Class Initialized
DEBUG - 2020-12-30 05:07:52 --> UTF-8 Support Enabled
INFO - 2020-12-30 05:07:52 --> Utf8 Class Initialized
INFO - 2020-12-30 05:07:52 --> URI Class Initialized
INFO - 2020-12-30 05:07:52 --> Router Class Initialized
INFO - 2020-12-30 05:07:52 --> Output Class Initialized
INFO - 2020-12-30 05:07:52 --> Security Class Initialized
DEBUG - 2020-12-30 05:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 05:07:52 --> Input Class Initialized
INFO - 2020-12-30 05:07:52 --> Language Class Initialized
INFO - 2020-12-30 05:07:52 --> Language Class Initialized
INFO - 2020-12-30 05:07:52 --> Config Class Initialized
INFO - 2020-12-30 05:07:52 --> Loader Class Initialized
INFO - 2020-12-30 05:07:52 --> Helper loaded: url_helper
INFO - 2020-12-30 05:07:52 --> Helper loaded: file_helper
INFO - 2020-12-30 05:07:52 --> Helper loaded: form_helper
INFO - 2020-12-30 05:07:52 --> Helper loaded: my_helper
INFO - 2020-12-30 05:07:53 --> Database Driver Class Initialized
DEBUG - 2020-12-30 05:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 05:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 05:07:53 --> Controller Class Initialized
DEBUG - 2020-12-30 05:07:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2020-12-30 05:07:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 05:07:53 --> Final output sent to browser
DEBUG - 2020-12-30 05:07:53 --> Total execution time: 0.6041
INFO - 2020-12-30 05:07:55 --> Config Class Initialized
INFO - 2020-12-30 05:07:55 --> Hooks Class Initialized
DEBUG - 2020-12-30 05:07:55 --> UTF-8 Support Enabled
INFO - 2020-12-30 05:07:55 --> Utf8 Class Initialized
INFO - 2020-12-30 05:07:55 --> URI Class Initialized
INFO - 2020-12-30 05:07:55 --> Router Class Initialized
INFO - 2020-12-30 05:07:55 --> Output Class Initialized
INFO - 2020-12-30 05:07:55 --> Security Class Initialized
DEBUG - 2020-12-30 05:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 05:07:55 --> Input Class Initialized
INFO - 2020-12-30 05:07:55 --> Language Class Initialized
INFO - 2020-12-30 05:07:55 --> Language Class Initialized
INFO - 2020-12-30 05:07:55 --> Config Class Initialized
INFO - 2020-12-30 05:07:55 --> Loader Class Initialized
INFO - 2020-12-30 05:07:56 --> Helper loaded: url_helper
INFO - 2020-12-30 05:07:56 --> Helper loaded: file_helper
INFO - 2020-12-30 05:07:56 --> Helper loaded: form_helper
INFO - 2020-12-30 05:07:56 --> Helper loaded: my_helper
INFO - 2020-12-30 05:07:56 --> Database Driver Class Initialized
DEBUG - 2020-12-30 05:07:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 05:07:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 05:07:56 --> Controller Class Initialized
DEBUG - 2020-12-30 05:07:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-12-30 05:07:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 05:07:56 --> Final output sent to browser
DEBUG - 2020-12-30 05:07:56 --> Total execution time: 0.5552
INFO - 2020-12-30 05:07:57 --> Config Class Initialized
INFO - 2020-12-30 05:07:57 --> Hooks Class Initialized
DEBUG - 2020-12-30 05:07:57 --> UTF-8 Support Enabled
INFO - 2020-12-30 05:07:57 --> Utf8 Class Initialized
INFO - 2020-12-30 05:07:57 --> URI Class Initialized
INFO - 2020-12-30 05:07:57 --> Router Class Initialized
INFO - 2020-12-30 05:07:57 --> Output Class Initialized
INFO - 2020-12-30 05:07:57 --> Security Class Initialized
DEBUG - 2020-12-30 05:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 05:07:57 --> Input Class Initialized
INFO - 2020-12-30 05:07:57 --> Language Class Initialized
INFO - 2020-12-30 05:07:57 --> Language Class Initialized
INFO - 2020-12-30 05:07:57 --> Config Class Initialized
INFO - 2020-12-30 05:07:57 --> Loader Class Initialized
INFO - 2020-12-30 05:07:57 --> Helper loaded: url_helper
INFO - 2020-12-30 05:07:57 --> Helper loaded: file_helper
INFO - 2020-12-30 05:07:57 --> Helper loaded: form_helper
INFO - 2020-12-30 05:07:57 --> Helper loaded: my_helper
INFO - 2020-12-30 05:07:57 --> Database Driver Class Initialized
DEBUG - 2020-12-30 05:07:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 05:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 05:07:57 --> Controller Class Initialized
DEBUG - 2020-12-30 05:07:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-12-30 05:07:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 05:07:57 --> Final output sent to browser
DEBUG - 2020-12-30 05:07:57 --> Total execution time: 0.5832
INFO - 2020-12-30 05:07:57 --> Config Class Initialized
INFO - 2020-12-30 05:07:57 --> Hooks Class Initialized
DEBUG - 2020-12-30 05:07:57 --> UTF-8 Support Enabled
INFO - 2020-12-30 05:07:57 --> Utf8 Class Initialized
INFO - 2020-12-30 05:07:57 --> URI Class Initialized
INFO - 2020-12-30 05:07:57 --> Router Class Initialized
INFO - 2020-12-30 05:07:58 --> Output Class Initialized
INFO - 2020-12-30 05:07:58 --> Security Class Initialized
DEBUG - 2020-12-30 05:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 05:07:58 --> Input Class Initialized
INFO - 2020-12-30 05:07:58 --> Language Class Initialized
INFO - 2020-12-30 05:07:58 --> Language Class Initialized
INFO - 2020-12-30 05:07:58 --> Config Class Initialized
INFO - 2020-12-30 05:07:58 --> Loader Class Initialized
INFO - 2020-12-30 05:07:58 --> Helper loaded: url_helper
INFO - 2020-12-30 05:07:58 --> Helper loaded: file_helper
INFO - 2020-12-30 05:07:58 --> Helper loaded: form_helper
INFO - 2020-12-30 05:07:58 --> Helper loaded: my_helper
INFO - 2020-12-30 05:07:58 --> Database Driver Class Initialized
DEBUG - 2020-12-30 05:07:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 05:07:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 05:07:58 --> Controller Class Initialized
INFO - 2020-12-30 05:07:59 --> Config Class Initialized
INFO - 2020-12-30 05:07:59 --> Hooks Class Initialized
DEBUG - 2020-12-30 05:07:59 --> UTF-8 Support Enabled
INFO - 2020-12-30 05:07:59 --> Utf8 Class Initialized
INFO - 2020-12-30 05:07:59 --> URI Class Initialized
INFO - 2020-12-30 05:07:59 --> Router Class Initialized
INFO - 2020-12-30 05:07:59 --> Output Class Initialized
INFO - 2020-12-30 05:07:59 --> Security Class Initialized
DEBUG - 2020-12-30 05:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 05:07:59 --> Input Class Initialized
INFO - 2020-12-30 05:07:59 --> Language Class Initialized
INFO - 2020-12-30 05:07:59 --> Language Class Initialized
INFO - 2020-12-30 05:07:59 --> Config Class Initialized
INFO - 2020-12-30 05:07:59 --> Loader Class Initialized
INFO - 2020-12-30 05:07:59 --> Helper loaded: url_helper
INFO - 2020-12-30 05:07:59 --> Helper loaded: file_helper
INFO - 2020-12-30 05:07:59 --> Helper loaded: form_helper
INFO - 2020-12-30 05:07:59 --> Helper loaded: my_helper
INFO - 2020-12-30 05:07:59 --> Database Driver Class Initialized
DEBUG - 2020-12-30 05:07:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 05:07:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 05:07:59 --> Controller Class Initialized
INFO - 2020-12-30 05:08:03 --> Config Class Initialized
INFO - 2020-12-30 05:08:03 --> Hooks Class Initialized
DEBUG - 2020-12-30 05:08:03 --> UTF-8 Support Enabled
INFO - 2020-12-30 05:08:03 --> Utf8 Class Initialized
INFO - 2020-12-30 05:08:03 --> URI Class Initialized
INFO - 2020-12-30 05:08:03 --> Router Class Initialized
INFO - 2020-12-30 05:08:03 --> Output Class Initialized
INFO - 2020-12-30 05:08:03 --> Security Class Initialized
DEBUG - 2020-12-30 05:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 05:08:03 --> Input Class Initialized
INFO - 2020-12-30 05:08:03 --> Language Class Initialized
INFO - 2020-12-30 05:08:03 --> Language Class Initialized
INFO - 2020-12-30 05:08:03 --> Config Class Initialized
INFO - 2020-12-30 05:08:03 --> Loader Class Initialized
INFO - 2020-12-30 05:08:03 --> Helper loaded: url_helper
INFO - 2020-12-30 05:08:03 --> Helper loaded: file_helper
INFO - 2020-12-30 05:08:03 --> Helper loaded: form_helper
INFO - 2020-12-30 05:08:03 --> Helper loaded: my_helper
INFO - 2020-12-30 05:08:03 --> Database Driver Class Initialized
DEBUG - 2020-12-30 05:08:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 05:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 05:08:03 --> Controller Class Initialized
DEBUG - 2020-12-30 05:08:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-12-30 05:08:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 05:08:04 --> Final output sent to browser
DEBUG - 2020-12-30 05:08:04 --> Total execution time: 0.4120
INFO - 2020-12-30 05:08:04 --> Config Class Initialized
INFO - 2020-12-30 05:08:04 --> Hooks Class Initialized
DEBUG - 2020-12-30 05:08:04 --> UTF-8 Support Enabled
INFO - 2020-12-30 05:08:04 --> Utf8 Class Initialized
INFO - 2020-12-30 05:08:04 --> URI Class Initialized
INFO - 2020-12-30 05:08:04 --> Router Class Initialized
INFO - 2020-12-30 05:08:04 --> Output Class Initialized
INFO - 2020-12-30 05:08:04 --> Security Class Initialized
DEBUG - 2020-12-30 05:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 05:08:04 --> Input Class Initialized
INFO - 2020-12-30 05:08:04 --> Language Class Initialized
INFO - 2020-12-30 05:08:04 --> Language Class Initialized
INFO - 2020-12-30 05:08:04 --> Config Class Initialized
INFO - 2020-12-30 05:08:04 --> Loader Class Initialized
INFO - 2020-12-30 05:08:04 --> Helper loaded: url_helper
INFO - 2020-12-30 05:08:04 --> Helper loaded: file_helper
INFO - 2020-12-30 05:08:04 --> Helper loaded: form_helper
INFO - 2020-12-30 05:08:04 --> Helper loaded: my_helper
INFO - 2020-12-30 05:08:04 --> Database Driver Class Initialized
DEBUG - 2020-12-30 05:08:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 05:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 05:08:04 --> Controller Class Initialized
INFO - 2020-12-30 05:08:14 --> Config Class Initialized
INFO - 2020-12-30 05:08:14 --> Hooks Class Initialized
DEBUG - 2020-12-30 05:08:14 --> UTF-8 Support Enabled
INFO - 2020-12-30 05:08:14 --> Utf8 Class Initialized
INFO - 2020-12-30 05:08:14 --> URI Class Initialized
INFO - 2020-12-30 05:08:14 --> Router Class Initialized
INFO - 2020-12-30 05:08:14 --> Output Class Initialized
INFO - 2020-12-30 05:08:14 --> Security Class Initialized
DEBUG - 2020-12-30 05:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 05:08:14 --> Input Class Initialized
INFO - 2020-12-30 05:08:14 --> Language Class Initialized
INFO - 2020-12-30 05:08:14 --> Language Class Initialized
INFO - 2020-12-30 05:08:14 --> Config Class Initialized
INFO - 2020-12-30 05:08:14 --> Loader Class Initialized
INFO - 2020-12-30 05:08:14 --> Helper loaded: url_helper
INFO - 2020-12-30 05:08:14 --> Helper loaded: file_helper
INFO - 2020-12-30 05:08:14 --> Helper loaded: form_helper
INFO - 2020-12-30 05:08:14 --> Helper loaded: my_helper
INFO - 2020-12-30 05:08:14 --> Database Driver Class Initialized
DEBUG - 2020-12-30 05:08:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 05:08:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 05:08:14 --> Controller Class Initialized
INFO - 2020-12-30 05:08:14 --> Final output sent to browser
DEBUG - 2020-12-30 05:08:14 --> Total execution time: 0.4722
INFO - 2020-12-30 05:08:24 --> Config Class Initialized
INFO - 2020-12-30 05:08:24 --> Hooks Class Initialized
DEBUG - 2020-12-30 05:08:24 --> UTF-8 Support Enabled
INFO - 2020-12-30 05:08:24 --> Utf8 Class Initialized
INFO - 2020-12-30 05:08:24 --> URI Class Initialized
INFO - 2020-12-30 05:08:24 --> Router Class Initialized
INFO - 2020-12-30 05:08:24 --> Output Class Initialized
INFO - 2020-12-30 05:08:24 --> Security Class Initialized
DEBUG - 2020-12-30 05:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 05:08:24 --> Input Class Initialized
INFO - 2020-12-30 05:08:24 --> Language Class Initialized
INFO - 2020-12-30 05:08:24 --> Language Class Initialized
INFO - 2020-12-30 05:08:24 --> Config Class Initialized
INFO - 2020-12-30 05:08:24 --> Loader Class Initialized
INFO - 2020-12-30 05:08:24 --> Helper loaded: url_helper
INFO - 2020-12-30 05:08:24 --> Helper loaded: file_helper
INFO - 2020-12-30 05:08:24 --> Helper loaded: form_helper
INFO - 2020-12-30 05:08:24 --> Helper loaded: my_helper
INFO - 2020-12-30 05:08:24 --> Database Driver Class Initialized
DEBUG - 2020-12-30 05:08:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 05:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 05:08:24 --> Controller Class Initialized
INFO - 2020-12-30 05:08:25 --> Final output sent to browser
DEBUG - 2020-12-30 05:08:25 --> Total execution time: 0.4481
INFO - 2020-12-30 05:08:25 --> Config Class Initialized
INFO - 2020-12-30 05:08:25 --> Hooks Class Initialized
DEBUG - 2020-12-30 05:08:25 --> UTF-8 Support Enabled
INFO - 2020-12-30 05:08:25 --> Utf8 Class Initialized
INFO - 2020-12-30 05:08:25 --> URI Class Initialized
INFO - 2020-12-30 05:08:25 --> Router Class Initialized
INFO - 2020-12-30 05:08:25 --> Output Class Initialized
INFO - 2020-12-30 05:08:25 --> Security Class Initialized
DEBUG - 2020-12-30 05:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 05:08:25 --> Input Class Initialized
INFO - 2020-12-30 05:08:25 --> Language Class Initialized
INFO - 2020-12-30 05:08:25 --> Language Class Initialized
INFO - 2020-12-30 05:08:25 --> Config Class Initialized
INFO - 2020-12-30 05:08:25 --> Loader Class Initialized
INFO - 2020-12-30 05:08:25 --> Helper loaded: url_helper
INFO - 2020-12-30 05:08:25 --> Helper loaded: file_helper
INFO - 2020-12-30 05:08:25 --> Helper loaded: form_helper
INFO - 2020-12-30 05:08:25 --> Helper loaded: my_helper
INFO - 2020-12-30 05:08:25 --> Database Driver Class Initialized
DEBUG - 2020-12-30 05:08:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 05:08:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 05:08:25 --> Controller Class Initialized
INFO - 2020-12-30 05:08:27 --> Config Class Initialized
INFO - 2020-12-30 05:08:27 --> Hooks Class Initialized
DEBUG - 2020-12-30 05:08:27 --> UTF-8 Support Enabled
INFO - 2020-12-30 05:08:27 --> Utf8 Class Initialized
INFO - 2020-12-30 05:08:27 --> URI Class Initialized
INFO - 2020-12-30 05:08:27 --> Router Class Initialized
INFO - 2020-12-30 05:08:27 --> Output Class Initialized
INFO - 2020-12-30 05:08:27 --> Security Class Initialized
DEBUG - 2020-12-30 05:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 05:08:28 --> Input Class Initialized
INFO - 2020-12-30 05:08:28 --> Language Class Initialized
INFO - 2020-12-30 05:08:28 --> Language Class Initialized
INFO - 2020-12-30 05:08:28 --> Config Class Initialized
INFO - 2020-12-30 05:08:28 --> Loader Class Initialized
INFO - 2020-12-30 05:08:28 --> Helper loaded: url_helper
INFO - 2020-12-30 05:08:28 --> Helper loaded: file_helper
INFO - 2020-12-30 05:08:28 --> Helper loaded: form_helper
INFO - 2020-12-30 05:08:28 --> Helper loaded: my_helper
INFO - 2020-12-30 05:08:28 --> Database Driver Class Initialized
DEBUG - 2020-12-30 05:08:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 05:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 05:08:28 --> Controller Class Initialized
INFO - 2020-12-30 05:21:05 --> Config Class Initialized
INFO - 2020-12-30 05:21:05 --> Hooks Class Initialized
DEBUG - 2020-12-30 05:21:06 --> UTF-8 Support Enabled
INFO - 2020-12-30 05:21:06 --> Utf8 Class Initialized
INFO - 2020-12-30 05:21:06 --> URI Class Initialized
INFO - 2020-12-30 05:21:06 --> Router Class Initialized
INFO - 2020-12-30 05:21:06 --> Output Class Initialized
INFO - 2020-12-30 05:21:06 --> Security Class Initialized
DEBUG - 2020-12-30 05:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 05:21:06 --> Input Class Initialized
INFO - 2020-12-30 05:21:06 --> Language Class Initialized
INFO - 2020-12-30 05:21:07 --> Language Class Initialized
INFO - 2020-12-30 05:21:07 --> Config Class Initialized
INFO - 2020-12-30 05:21:07 --> Loader Class Initialized
INFO - 2020-12-30 05:21:07 --> Helper loaded: url_helper
INFO - 2020-12-30 05:21:07 --> Helper loaded: file_helper
INFO - 2020-12-30 05:21:07 --> Helper loaded: form_helper
INFO - 2020-12-30 05:21:07 --> Helper loaded: my_helper
INFO - 2020-12-30 05:21:07 --> Database Driver Class Initialized
DEBUG - 2020-12-30 05:21:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 05:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 05:21:08 --> Controller Class Initialized
DEBUG - 2020-12-30 05:21:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2020-12-30 05:21:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 05:21:08 --> Final output sent to browser
DEBUG - 2020-12-30 05:21:08 --> Total execution time: 2.7341
INFO - 2020-12-30 05:36:02 --> Config Class Initialized
INFO - 2020-12-30 05:36:02 --> Hooks Class Initialized
DEBUG - 2020-12-30 05:36:02 --> UTF-8 Support Enabled
INFO - 2020-12-30 05:36:02 --> Utf8 Class Initialized
INFO - 2020-12-30 05:36:02 --> URI Class Initialized
INFO - 2020-12-30 05:36:02 --> Router Class Initialized
INFO - 2020-12-30 05:36:02 --> Output Class Initialized
INFO - 2020-12-30 05:36:02 --> Security Class Initialized
DEBUG - 2020-12-30 05:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 05:36:02 --> Input Class Initialized
INFO - 2020-12-30 05:36:02 --> Language Class Initialized
INFO - 2020-12-30 05:36:02 --> Language Class Initialized
INFO - 2020-12-30 05:36:02 --> Config Class Initialized
INFO - 2020-12-30 05:36:03 --> Loader Class Initialized
INFO - 2020-12-30 05:36:03 --> Helper loaded: url_helper
INFO - 2020-12-30 05:36:03 --> Helper loaded: file_helper
INFO - 2020-12-30 05:36:03 --> Helper loaded: form_helper
INFO - 2020-12-30 05:36:03 --> Helper loaded: my_helper
INFO - 2020-12-30 05:36:03 --> Database Driver Class Initialized
DEBUG - 2020-12-30 05:36:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 05:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 05:36:03 --> Controller Class Initialized
DEBUG - 2020-12-30 05:36:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-12-30 05:36:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 05:36:03 --> Final output sent to browser
DEBUG - 2020-12-30 05:36:03 --> Total execution time: 1.3538
INFO - 2020-12-30 05:36:04 --> Config Class Initialized
INFO - 2020-12-30 05:36:04 --> Hooks Class Initialized
DEBUG - 2020-12-30 05:36:04 --> UTF-8 Support Enabled
INFO - 2020-12-30 05:36:04 --> Utf8 Class Initialized
INFO - 2020-12-30 05:36:04 --> URI Class Initialized
INFO - 2020-12-30 05:36:04 --> Router Class Initialized
INFO - 2020-12-30 05:36:04 --> Output Class Initialized
INFO - 2020-12-30 05:36:04 --> Security Class Initialized
DEBUG - 2020-12-30 05:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 05:36:04 --> Input Class Initialized
INFO - 2020-12-30 05:36:04 --> Language Class Initialized
INFO - 2020-12-30 05:36:04 --> Language Class Initialized
INFO - 2020-12-30 05:36:04 --> Config Class Initialized
INFO - 2020-12-30 05:36:04 --> Loader Class Initialized
INFO - 2020-12-30 05:36:04 --> Helper loaded: url_helper
INFO - 2020-12-30 05:36:04 --> Helper loaded: file_helper
INFO - 2020-12-30 05:36:04 --> Helper loaded: form_helper
INFO - 2020-12-30 05:36:04 --> Helper loaded: my_helper
INFO - 2020-12-30 05:36:04 --> Database Driver Class Initialized
DEBUG - 2020-12-30 05:36:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 05:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 05:36:05 --> Controller Class Initialized
DEBUG - 2020-12-30 05:36:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-12-30 05:36:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-30 05:36:05 --> Final output sent to browser
DEBUG - 2020-12-30 05:36:05 --> Total execution time: 0.4687
INFO - 2020-12-30 05:36:05 --> Config Class Initialized
INFO - 2020-12-30 05:36:05 --> Hooks Class Initialized
DEBUG - 2020-12-30 05:36:05 --> UTF-8 Support Enabled
INFO - 2020-12-30 05:36:05 --> Utf8 Class Initialized
INFO - 2020-12-30 05:36:05 --> URI Class Initialized
INFO - 2020-12-30 05:36:05 --> Router Class Initialized
INFO - 2020-12-30 05:36:05 --> Output Class Initialized
INFO - 2020-12-30 05:36:05 --> Security Class Initialized
DEBUG - 2020-12-30 05:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 05:36:05 --> Input Class Initialized
INFO - 2020-12-30 05:36:05 --> Language Class Initialized
INFO - 2020-12-30 05:36:05 --> Language Class Initialized
INFO - 2020-12-30 05:36:05 --> Config Class Initialized
INFO - 2020-12-30 05:36:05 --> Loader Class Initialized
INFO - 2020-12-30 05:36:05 --> Helper loaded: url_helper
INFO - 2020-12-30 05:36:05 --> Helper loaded: file_helper
INFO - 2020-12-30 05:36:05 --> Helper loaded: form_helper
INFO - 2020-12-30 05:36:05 --> Helper loaded: my_helper
INFO - 2020-12-30 05:36:05 --> Database Driver Class Initialized
DEBUG - 2020-12-30 05:36:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 05:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 05:36:05 --> Controller Class Initialized
INFO - 2020-12-30 05:36:06 --> Config Class Initialized
INFO - 2020-12-30 05:36:06 --> Hooks Class Initialized
DEBUG - 2020-12-30 05:36:06 --> UTF-8 Support Enabled
INFO - 2020-12-30 05:36:06 --> Utf8 Class Initialized
INFO - 2020-12-30 05:36:06 --> URI Class Initialized
INFO - 2020-12-30 05:36:06 --> Router Class Initialized
INFO - 2020-12-30 05:36:06 --> Output Class Initialized
INFO - 2020-12-30 05:36:06 --> Security Class Initialized
DEBUG - 2020-12-30 05:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-30 05:36:06 --> Input Class Initialized
INFO - 2020-12-30 05:36:06 --> Language Class Initialized
INFO - 2020-12-30 05:36:06 --> Language Class Initialized
INFO - 2020-12-30 05:36:06 --> Config Class Initialized
INFO - 2020-12-30 05:36:06 --> Loader Class Initialized
INFO - 2020-12-30 05:36:06 --> Helper loaded: url_helper
INFO - 2020-12-30 05:36:06 --> Helper loaded: file_helper
INFO - 2020-12-30 05:36:06 --> Helper loaded: form_helper
INFO - 2020-12-30 05:36:06 --> Helper loaded: my_helper
INFO - 2020-12-30 05:36:06 --> Database Driver Class Initialized
DEBUG - 2020-12-30 05:36:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-30 05:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-30 05:36:06 --> Controller Class Initialized
DEBUG - 2020-12-30 05:36:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2020-12-30 05:36:06 --> Final output sent to browser
DEBUG - 2020-12-30 05:36:06 --> Total execution time: 0.4566
