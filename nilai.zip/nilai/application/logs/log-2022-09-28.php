<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-09-28 08:05:33 --> Config Class Initialized
INFO - 2022-09-28 08:05:33 --> Hooks Class Initialized
DEBUG - 2022-09-28 08:05:33 --> UTF-8 Support Enabled
INFO - 2022-09-28 08:05:33 --> Utf8 Class Initialized
INFO - 2022-09-28 08:05:33 --> URI Class Initialized
DEBUG - 2022-09-28 08:05:33 --> No URI present. Default controller set.
INFO - 2022-09-28 08:05:33 --> Router Class Initialized
INFO - 2022-09-28 08:05:33 --> Output Class Initialized
INFO - 2022-09-28 08:05:33 --> Security Class Initialized
DEBUG - 2022-09-28 08:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-28 08:05:33 --> Input Class Initialized
INFO - 2022-09-28 08:05:33 --> Language Class Initialized
INFO - 2022-09-28 08:05:34 --> Language Class Initialized
INFO - 2022-09-28 08:05:34 --> Config Class Initialized
INFO - 2022-09-28 08:05:34 --> Loader Class Initialized
INFO - 2022-09-28 08:05:34 --> Helper loaded: url_helper
INFO - 2022-09-28 08:05:34 --> Helper loaded: file_helper
INFO - 2022-09-28 08:05:34 --> Helper loaded: form_helper
INFO - 2022-09-28 08:05:34 --> Helper loaded: my_helper
INFO - 2022-09-28 08:05:34 --> Database Driver Class Initialized
DEBUG - 2022-09-28 08:05:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-28 08:05:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-28 08:05:34 --> Controller Class Initialized
INFO - 2022-09-28 08:05:34 --> Config Class Initialized
INFO - 2022-09-28 08:05:34 --> Hooks Class Initialized
DEBUG - 2022-09-28 08:05:34 --> UTF-8 Support Enabled
INFO - 2022-09-28 08:05:34 --> Utf8 Class Initialized
INFO - 2022-09-28 08:05:34 --> URI Class Initialized
INFO - 2022-09-28 08:05:34 --> Router Class Initialized
INFO - 2022-09-28 08:05:34 --> Output Class Initialized
INFO - 2022-09-28 08:05:34 --> Security Class Initialized
DEBUG - 2022-09-28 08:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-28 08:05:34 --> Input Class Initialized
INFO - 2022-09-28 08:05:34 --> Language Class Initialized
INFO - 2022-09-28 08:05:34 --> Language Class Initialized
INFO - 2022-09-28 08:05:34 --> Config Class Initialized
INFO - 2022-09-28 08:05:34 --> Loader Class Initialized
INFO - 2022-09-28 08:05:34 --> Helper loaded: url_helper
INFO - 2022-09-28 08:05:34 --> Helper loaded: file_helper
INFO - 2022-09-28 08:05:34 --> Helper loaded: form_helper
INFO - 2022-09-28 08:05:34 --> Helper loaded: my_helper
INFO - 2022-09-28 08:05:34 --> Database Driver Class Initialized
DEBUG - 2022-09-28 08:05:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-28 08:05:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-28 08:05:34 --> Controller Class Initialized
DEBUG - 2022-09-28 08:05:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-09-28 08:05:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-09-28 08:05:34 --> Final output sent to browser
DEBUG - 2022-09-28 08:05:34 --> Total execution time: 0.1098
INFO - 2022-09-28 08:05:39 --> Config Class Initialized
INFO - 2022-09-28 08:05:39 --> Hooks Class Initialized
DEBUG - 2022-09-28 08:05:39 --> UTF-8 Support Enabled
INFO - 2022-09-28 08:05:39 --> Utf8 Class Initialized
INFO - 2022-09-28 08:05:39 --> URI Class Initialized
DEBUG - 2022-09-28 08:05:39 --> No URI present. Default controller set.
INFO - 2022-09-28 08:05:39 --> Router Class Initialized
INFO - 2022-09-28 08:05:39 --> Output Class Initialized
INFO - 2022-09-28 08:05:39 --> Security Class Initialized
DEBUG - 2022-09-28 08:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-28 08:05:39 --> Input Class Initialized
INFO - 2022-09-28 08:05:39 --> Language Class Initialized
INFO - 2022-09-28 08:05:39 --> Language Class Initialized
INFO - 2022-09-28 08:05:39 --> Config Class Initialized
INFO - 2022-09-28 08:05:39 --> Loader Class Initialized
INFO - 2022-09-28 08:05:39 --> Helper loaded: url_helper
INFO - 2022-09-28 08:05:39 --> Helper loaded: file_helper
INFO - 2022-09-28 08:05:39 --> Helper loaded: form_helper
INFO - 2022-09-28 08:05:39 --> Helper loaded: my_helper
INFO - 2022-09-28 08:05:39 --> Database Driver Class Initialized
DEBUG - 2022-09-28 08:05:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-28 08:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-28 08:05:39 --> Controller Class Initialized
INFO - 2022-09-28 08:05:39 --> Config Class Initialized
INFO - 2022-09-28 08:05:39 --> Hooks Class Initialized
DEBUG - 2022-09-28 08:05:39 --> UTF-8 Support Enabled
INFO - 2022-09-28 08:05:39 --> Utf8 Class Initialized
INFO - 2022-09-28 08:05:39 --> URI Class Initialized
INFO - 2022-09-28 08:05:39 --> Router Class Initialized
INFO - 2022-09-28 08:05:39 --> Output Class Initialized
INFO - 2022-09-28 08:05:39 --> Security Class Initialized
DEBUG - 2022-09-28 08:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-28 08:05:39 --> Input Class Initialized
INFO - 2022-09-28 08:05:39 --> Language Class Initialized
INFO - 2022-09-28 08:05:39 --> Language Class Initialized
INFO - 2022-09-28 08:05:39 --> Config Class Initialized
INFO - 2022-09-28 08:05:39 --> Loader Class Initialized
INFO - 2022-09-28 08:05:39 --> Helper loaded: url_helper
INFO - 2022-09-28 08:05:39 --> Helper loaded: file_helper
INFO - 2022-09-28 08:05:39 --> Helper loaded: form_helper
INFO - 2022-09-28 08:05:39 --> Helper loaded: my_helper
INFO - 2022-09-28 08:05:39 --> Database Driver Class Initialized
DEBUG - 2022-09-28 08:05:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-28 08:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-28 08:05:39 --> Controller Class Initialized
DEBUG - 2022-09-28 08:05:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-09-28 08:05:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-09-28 08:05:39 --> Final output sent to browser
DEBUG - 2022-09-28 08:05:39 --> Total execution time: 0.0559
