<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-04-26 03:05:04 --> Config Class Initialized
INFO - 2022-04-26 03:05:04 --> Hooks Class Initialized
DEBUG - 2022-04-26 03:05:05 --> UTF-8 Support Enabled
INFO - 2022-04-26 03:05:05 --> Utf8 Class Initialized
INFO - 2022-04-26 03:05:05 --> URI Class Initialized
DEBUG - 2022-04-26 03:05:05 --> No URI present. Default controller set.
INFO - 2022-04-26 03:05:05 --> Router Class Initialized
INFO - 2022-04-26 03:05:05 --> Output Class Initialized
INFO - 2022-04-26 03:05:05 --> Security Class Initialized
DEBUG - 2022-04-26 03:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-26 03:05:05 --> Input Class Initialized
INFO - 2022-04-26 03:05:05 --> Language Class Initialized
INFO - 2022-04-26 03:05:06 --> Language Class Initialized
INFO - 2022-04-26 03:05:06 --> Config Class Initialized
INFO - 2022-04-26 03:05:06 --> Loader Class Initialized
INFO - 2022-04-26 03:05:06 --> Helper loaded: url_helper
INFO - 2022-04-26 03:05:06 --> Helper loaded: file_helper
INFO - 2022-04-26 03:05:06 --> Helper loaded: form_helper
INFO - 2022-04-26 03:05:06 --> Helper loaded: my_helper
INFO - 2022-04-26 03:05:06 --> Database Driver Class Initialized
DEBUG - 2022-04-26 03:05:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-26 03:05:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-26 03:05:06 --> Controller Class Initialized
INFO - 2022-04-26 03:05:06 --> Config Class Initialized
INFO - 2022-04-26 03:05:06 --> Hooks Class Initialized
DEBUG - 2022-04-26 03:05:06 --> UTF-8 Support Enabled
INFO - 2022-04-26 03:05:06 --> Utf8 Class Initialized
INFO - 2022-04-26 03:05:06 --> URI Class Initialized
INFO - 2022-04-26 03:05:06 --> Router Class Initialized
INFO - 2022-04-26 03:05:06 --> Output Class Initialized
INFO - 2022-04-26 03:05:06 --> Security Class Initialized
DEBUG - 2022-04-26 03:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-26 03:05:06 --> Input Class Initialized
INFO - 2022-04-26 03:05:06 --> Language Class Initialized
INFO - 2022-04-26 03:05:06 --> Language Class Initialized
INFO - 2022-04-26 03:05:06 --> Config Class Initialized
INFO - 2022-04-26 03:05:06 --> Loader Class Initialized
INFO - 2022-04-26 03:05:06 --> Helper loaded: url_helper
INFO - 2022-04-26 03:05:06 --> Helper loaded: file_helper
INFO - 2022-04-26 03:05:06 --> Helper loaded: form_helper
INFO - 2022-04-26 03:05:06 --> Helper loaded: my_helper
INFO - 2022-04-26 03:05:06 --> Database Driver Class Initialized
DEBUG - 2022-04-26 03:05:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-26 03:05:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-26 03:05:06 --> Controller Class Initialized
DEBUG - 2022-04-26 03:05:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-04-26 03:05:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-04-26 03:05:06 --> Final output sent to browser
DEBUG - 2022-04-26 03:05:06 --> Total execution time: 0.2382
