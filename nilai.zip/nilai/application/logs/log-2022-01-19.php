<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-01-19 05:42:38 --> Config Class Initialized
INFO - 2022-01-19 05:42:38 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:42:38 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:42:38 --> Utf8 Class Initialized
INFO - 2022-01-19 05:42:38 --> URI Class Initialized
DEBUG - 2022-01-19 05:42:38 --> No URI present. Default controller set.
INFO - 2022-01-19 05:42:38 --> Router Class Initialized
INFO - 2022-01-19 05:42:38 --> Output Class Initialized
INFO - 2022-01-19 05:42:38 --> Security Class Initialized
DEBUG - 2022-01-19 05:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:42:38 --> Input Class Initialized
INFO - 2022-01-19 05:42:38 --> Language Class Initialized
INFO - 2022-01-19 05:42:38 --> Language Class Initialized
INFO - 2022-01-19 05:42:38 --> Config Class Initialized
INFO - 2022-01-19 05:42:38 --> Loader Class Initialized
INFO - 2022-01-19 05:42:38 --> Helper loaded: url_helper
INFO - 2022-01-19 05:42:38 --> Helper loaded: file_helper
INFO - 2022-01-19 05:42:38 --> Helper loaded: form_helper
INFO - 2022-01-19 05:42:38 --> Helper loaded: my_helper
INFO - 2022-01-19 05:42:38 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:42:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:42:38 --> Controller Class Initialized
INFO - 2022-01-19 05:42:38 --> Config Class Initialized
INFO - 2022-01-19 05:42:38 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:42:38 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:42:38 --> Utf8 Class Initialized
INFO - 2022-01-19 05:42:38 --> URI Class Initialized
INFO - 2022-01-19 05:42:38 --> Router Class Initialized
INFO - 2022-01-19 05:42:38 --> Output Class Initialized
INFO - 2022-01-19 05:42:38 --> Security Class Initialized
DEBUG - 2022-01-19 05:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:42:38 --> Input Class Initialized
INFO - 2022-01-19 05:42:38 --> Language Class Initialized
INFO - 2022-01-19 05:42:38 --> Language Class Initialized
INFO - 2022-01-19 05:42:38 --> Config Class Initialized
INFO - 2022-01-19 05:42:38 --> Loader Class Initialized
INFO - 2022-01-19 05:42:38 --> Helper loaded: url_helper
INFO - 2022-01-19 05:42:38 --> Helper loaded: file_helper
INFO - 2022-01-19 05:42:38 --> Helper loaded: form_helper
INFO - 2022-01-19 05:42:38 --> Helper loaded: my_helper
INFO - 2022-01-19 05:42:38 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:42:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:42:38 --> Controller Class Initialized
DEBUG - 2022-01-19 05:42:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-01-19 05:42:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-19 05:42:38 --> Final output sent to browser
DEBUG - 2022-01-19 05:42:38 --> Total execution time: 0.0390
INFO - 2022-01-19 05:42:49 --> Config Class Initialized
INFO - 2022-01-19 05:42:49 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:42:49 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:42:49 --> Utf8 Class Initialized
INFO - 2022-01-19 05:42:49 --> URI Class Initialized
INFO - 2022-01-19 05:42:49 --> Router Class Initialized
INFO - 2022-01-19 05:42:49 --> Output Class Initialized
INFO - 2022-01-19 05:42:49 --> Security Class Initialized
DEBUG - 2022-01-19 05:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:42:49 --> Input Class Initialized
INFO - 2022-01-19 05:42:49 --> Language Class Initialized
INFO - 2022-01-19 05:42:49 --> Language Class Initialized
INFO - 2022-01-19 05:42:49 --> Config Class Initialized
INFO - 2022-01-19 05:42:49 --> Loader Class Initialized
INFO - 2022-01-19 05:42:49 --> Helper loaded: url_helper
INFO - 2022-01-19 05:42:49 --> Helper loaded: file_helper
INFO - 2022-01-19 05:42:49 --> Helper loaded: form_helper
INFO - 2022-01-19 05:42:49 --> Helper loaded: my_helper
INFO - 2022-01-19 05:42:49 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:42:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:42:49 --> Controller Class Initialized
INFO - 2022-01-19 05:42:49 --> Helper loaded: cookie_helper
INFO - 2022-01-19 05:42:49 --> Final output sent to browser
DEBUG - 2022-01-19 05:42:49 --> Total execution time: 0.0530
INFO - 2022-01-19 05:42:49 --> Config Class Initialized
INFO - 2022-01-19 05:42:49 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:42:49 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:42:49 --> Utf8 Class Initialized
INFO - 2022-01-19 05:42:49 --> URI Class Initialized
INFO - 2022-01-19 05:42:49 --> Router Class Initialized
INFO - 2022-01-19 05:42:49 --> Output Class Initialized
INFO - 2022-01-19 05:42:49 --> Security Class Initialized
DEBUG - 2022-01-19 05:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:42:49 --> Input Class Initialized
INFO - 2022-01-19 05:42:49 --> Language Class Initialized
INFO - 2022-01-19 05:42:49 --> Language Class Initialized
INFO - 2022-01-19 05:42:49 --> Config Class Initialized
INFO - 2022-01-19 05:42:49 --> Loader Class Initialized
INFO - 2022-01-19 05:42:49 --> Helper loaded: url_helper
INFO - 2022-01-19 05:42:49 --> Helper loaded: file_helper
INFO - 2022-01-19 05:42:49 --> Helper loaded: form_helper
INFO - 2022-01-19 05:42:49 --> Helper loaded: my_helper
INFO - 2022-01-19 05:42:49 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:42:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:42:49 --> Controller Class Initialized
DEBUG - 2022-01-19 05:42:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-01-19 05:42:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-19 05:42:50 --> Final output sent to browser
DEBUG - 2022-01-19 05:42:50 --> Total execution time: 0.8100
INFO - 2022-01-19 05:43:17 --> Config Class Initialized
INFO - 2022-01-19 05:43:17 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:43:17 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:43:17 --> Utf8 Class Initialized
INFO - 2022-01-19 05:43:17 --> URI Class Initialized
INFO - 2022-01-19 05:43:17 --> Router Class Initialized
INFO - 2022-01-19 05:43:17 --> Output Class Initialized
INFO - 2022-01-19 05:43:17 --> Security Class Initialized
DEBUG - 2022-01-19 05:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:43:17 --> Input Class Initialized
INFO - 2022-01-19 05:43:17 --> Language Class Initialized
INFO - 2022-01-19 05:43:17 --> Language Class Initialized
INFO - 2022-01-19 05:43:17 --> Config Class Initialized
INFO - 2022-01-19 05:43:17 --> Loader Class Initialized
INFO - 2022-01-19 05:43:17 --> Helper loaded: url_helper
INFO - 2022-01-19 05:43:17 --> Helper loaded: file_helper
INFO - 2022-01-19 05:43:17 --> Helper loaded: form_helper
INFO - 2022-01-19 05:43:17 --> Helper loaded: my_helper
INFO - 2022-01-19 05:43:17 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:43:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:43:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:43:17 --> Controller Class Initialized
DEBUG - 2022-01-19 05:43:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2022-01-19 05:43:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-19 05:43:17 --> Final output sent to browser
DEBUG - 2022-01-19 05:43:17 --> Total execution time: 0.0500
INFO - 2022-01-19 05:43:17 --> Config Class Initialized
INFO - 2022-01-19 05:43:17 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:43:17 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:43:17 --> Utf8 Class Initialized
INFO - 2022-01-19 05:43:17 --> URI Class Initialized
INFO - 2022-01-19 05:43:17 --> Router Class Initialized
INFO - 2022-01-19 05:43:17 --> Output Class Initialized
INFO - 2022-01-19 05:43:17 --> Security Class Initialized
DEBUG - 2022-01-19 05:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:43:17 --> Input Class Initialized
INFO - 2022-01-19 05:43:17 --> Language Class Initialized
INFO - 2022-01-19 05:43:17 --> Language Class Initialized
INFO - 2022-01-19 05:43:17 --> Config Class Initialized
INFO - 2022-01-19 05:43:17 --> Loader Class Initialized
INFO - 2022-01-19 05:43:17 --> Helper loaded: url_helper
INFO - 2022-01-19 05:43:17 --> Helper loaded: file_helper
INFO - 2022-01-19 05:43:17 --> Helper loaded: form_helper
INFO - 2022-01-19 05:43:17 --> Helper loaded: my_helper
INFO - 2022-01-19 05:43:17 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:43:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:43:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:43:17 --> Controller Class Initialized
INFO - 2022-01-19 05:43:19 --> Config Class Initialized
INFO - 2022-01-19 05:43:19 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:43:19 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:43:19 --> Utf8 Class Initialized
INFO - 2022-01-19 05:43:19 --> URI Class Initialized
INFO - 2022-01-19 05:43:19 --> Router Class Initialized
INFO - 2022-01-19 05:43:19 --> Output Class Initialized
INFO - 2022-01-19 05:43:19 --> Security Class Initialized
DEBUG - 2022-01-19 05:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:43:19 --> Input Class Initialized
INFO - 2022-01-19 05:43:19 --> Language Class Initialized
INFO - 2022-01-19 05:43:19 --> Language Class Initialized
INFO - 2022-01-19 05:43:19 --> Config Class Initialized
INFO - 2022-01-19 05:43:19 --> Loader Class Initialized
INFO - 2022-01-19 05:43:19 --> Helper loaded: url_helper
INFO - 2022-01-19 05:43:19 --> Helper loaded: file_helper
INFO - 2022-01-19 05:43:19 --> Helper loaded: form_helper
INFO - 2022-01-19 05:43:19 --> Helper loaded: my_helper
INFO - 2022-01-19 05:43:19 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:43:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:43:19 --> Controller Class Initialized
INFO - 2022-01-19 05:43:19 --> Final output sent to browser
DEBUG - 2022-01-19 05:43:19 --> Total execution time: 0.0560
INFO - 2022-01-19 05:43:19 --> Config Class Initialized
INFO - 2022-01-19 05:43:19 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:43:19 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:43:19 --> Utf8 Class Initialized
INFO - 2022-01-19 05:43:19 --> URI Class Initialized
INFO - 2022-01-19 05:43:19 --> Router Class Initialized
INFO - 2022-01-19 05:43:19 --> Output Class Initialized
INFO - 2022-01-19 05:43:19 --> Security Class Initialized
DEBUG - 2022-01-19 05:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:43:19 --> Input Class Initialized
INFO - 2022-01-19 05:43:19 --> Language Class Initialized
INFO - 2022-01-19 05:43:19 --> Language Class Initialized
INFO - 2022-01-19 05:43:19 --> Config Class Initialized
INFO - 2022-01-19 05:43:19 --> Loader Class Initialized
INFO - 2022-01-19 05:43:19 --> Helper loaded: url_helper
INFO - 2022-01-19 05:43:19 --> Helper loaded: file_helper
INFO - 2022-01-19 05:43:19 --> Helper loaded: form_helper
INFO - 2022-01-19 05:43:19 --> Helper loaded: my_helper
INFO - 2022-01-19 05:43:19 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:43:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:43:19 --> Controller Class Initialized
INFO - 2022-01-19 05:43:21 --> Config Class Initialized
INFO - 2022-01-19 05:43:21 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:43:21 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:43:21 --> Utf8 Class Initialized
INFO - 2022-01-19 05:43:21 --> URI Class Initialized
INFO - 2022-01-19 05:43:21 --> Router Class Initialized
INFO - 2022-01-19 05:43:21 --> Output Class Initialized
INFO - 2022-01-19 05:43:21 --> Security Class Initialized
DEBUG - 2022-01-19 05:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:43:21 --> Input Class Initialized
INFO - 2022-01-19 05:43:21 --> Language Class Initialized
INFO - 2022-01-19 05:43:21 --> Language Class Initialized
INFO - 2022-01-19 05:43:21 --> Config Class Initialized
INFO - 2022-01-19 05:43:21 --> Loader Class Initialized
INFO - 2022-01-19 05:43:21 --> Helper loaded: url_helper
INFO - 2022-01-19 05:43:21 --> Helper loaded: file_helper
INFO - 2022-01-19 05:43:21 --> Helper loaded: form_helper
INFO - 2022-01-19 05:43:21 --> Helper loaded: my_helper
INFO - 2022-01-19 05:43:21 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:43:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:43:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:43:21 --> Controller Class Initialized
INFO - 2022-01-19 05:43:21 --> Helper loaded: cookie_helper
INFO - 2022-01-19 05:43:21 --> Config Class Initialized
INFO - 2022-01-19 05:43:21 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:43:21 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:43:21 --> Utf8 Class Initialized
INFO - 2022-01-19 05:43:21 --> URI Class Initialized
INFO - 2022-01-19 05:43:21 --> Router Class Initialized
INFO - 2022-01-19 05:43:21 --> Output Class Initialized
INFO - 2022-01-19 05:43:21 --> Security Class Initialized
DEBUG - 2022-01-19 05:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:43:21 --> Input Class Initialized
INFO - 2022-01-19 05:43:21 --> Language Class Initialized
INFO - 2022-01-19 05:43:21 --> Language Class Initialized
INFO - 2022-01-19 05:43:21 --> Config Class Initialized
INFO - 2022-01-19 05:43:21 --> Loader Class Initialized
INFO - 2022-01-19 05:43:21 --> Helper loaded: url_helper
INFO - 2022-01-19 05:43:21 --> Helper loaded: file_helper
INFO - 2022-01-19 05:43:21 --> Helper loaded: form_helper
INFO - 2022-01-19 05:43:21 --> Helper loaded: my_helper
INFO - 2022-01-19 05:43:21 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:43:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:43:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:43:21 --> Controller Class Initialized
DEBUG - 2022-01-19 05:43:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-01-19 05:43:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-19 05:43:21 --> Final output sent to browser
DEBUG - 2022-01-19 05:43:21 --> Total execution time: 0.0360
INFO - 2022-01-19 05:43:56 --> Config Class Initialized
INFO - 2022-01-19 05:43:56 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:43:56 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:43:56 --> Utf8 Class Initialized
INFO - 2022-01-19 05:43:56 --> URI Class Initialized
INFO - 2022-01-19 05:43:56 --> Router Class Initialized
INFO - 2022-01-19 05:43:56 --> Output Class Initialized
INFO - 2022-01-19 05:43:56 --> Security Class Initialized
DEBUG - 2022-01-19 05:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:43:56 --> Input Class Initialized
INFO - 2022-01-19 05:43:56 --> Language Class Initialized
INFO - 2022-01-19 05:43:56 --> Language Class Initialized
INFO - 2022-01-19 05:43:56 --> Config Class Initialized
INFO - 2022-01-19 05:43:56 --> Loader Class Initialized
INFO - 2022-01-19 05:43:56 --> Helper loaded: url_helper
INFO - 2022-01-19 05:43:56 --> Helper loaded: file_helper
INFO - 2022-01-19 05:43:56 --> Helper loaded: form_helper
INFO - 2022-01-19 05:43:56 --> Helper loaded: my_helper
INFO - 2022-01-19 05:43:56 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:43:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:43:56 --> Controller Class Initialized
INFO - 2022-01-19 05:43:56 --> Helper loaded: cookie_helper
INFO - 2022-01-19 05:43:56 --> Final output sent to browser
DEBUG - 2022-01-19 05:43:56 --> Total execution time: 0.0730
INFO - 2022-01-19 05:43:56 --> Config Class Initialized
INFO - 2022-01-19 05:43:56 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:43:56 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:43:56 --> Utf8 Class Initialized
INFO - 2022-01-19 05:43:56 --> URI Class Initialized
INFO - 2022-01-19 05:43:56 --> Router Class Initialized
INFO - 2022-01-19 05:43:56 --> Output Class Initialized
INFO - 2022-01-19 05:43:56 --> Security Class Initialized
DEBUG - 2022-01-19 05:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:43:56 --> Input Class Initialized
INFO - 2022-01-19 05:43:56 --> Language Class Initialized
INFO - 2022-01-19 05:43:56 --> Language Class Initialized
INFO - 2022-01-19 05:43:56 --> Config Class Initialized
INFO - 2022-01-19 05:43:56 --> Loader Class Initialized
INFO - 2022-01-19 05:43:56 --> Helper loaded: url_helper
INFO - 2022-01-19 05:43:56 --> Helper loaded: file_helper
INFO - 2022-01-19 05:43:56 --> Helper loaded: form_helper
INFO - 2022-01-19 05:43:56 --> Helper loaded: my_helper
INFO - 2022-01-19 05:43:56 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:43:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:43:56 --> Controller Class Initialized
DEBUG - 2022-01-19 05:43:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-01-19 05:43:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-19 05:43:56 --> Final output sent to browser
DEBUG - 2022-01-19 05:43:56 --> Total execution time: 0.2650
INFO - 2022-01-19 05:44:32 --> Config Class Initialized
INFO - 2022-01-19 05:44:32 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:44:32 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:44:32 --> Utf8 Class Initialized
INFO - 2022-01-19 05:44:32 --> URI Class Initialized
INFO - 2022-01-19 05:44:32 --> Router Class Initialized
INFO - 2022-01-19 05:44:32 --> Output Class Initialized
INFO - 2022-01-19 05:44:32 --> Security Class Initialized
DEBUG - 2022-01-19 05:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:44:32 --> Input Class Initialized
INFO - 2022-01-19 05:44:32 --> Language Class Initialized
INFO - 2022-01-19 05:44:32 --> Language Class Initialized
INFO - 2022-01-19 05:44:32 --> Config Class Initialized
INFO - 2022-01-19 05:44:32 --> Loader Class Initialized
INFO - 2022-01-19 05:44:32 --> Helper loaded: url_helper
INFO - 2022-01-19 05:44:32 --> Helper loaded: file_helper
INFO - 2022-01-19 05:44:32 --> Helper loaded: form_helper
INFO - 2022-01-19 05:44:32 --> Helper loaded: my_helper
INFO - 2022-01-19 05:44:32 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:44:32 --> Controller Class Initialized
DEBUG - 2022-01-19 05:44:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2022-01-19 05:44:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-19 05:44:32 --> Final output sent to browser
DEBUG - 2022-01-19 05:44:32 --> Total execution time: 0.0610
INFO - 2022-01-19 05:44:34 --> Config Class Initialized
INFO - 2022-01-19 05:44:34 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:44:34 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:44:34 --> Utf8 Class Initialized
INFO - 2022-01-19 05:44:34 --> URI Class Initialized
INFO - 2022-01-19 05:44:34 --> Router Class Initialized
INFO - 2022-01-19 05:44:34 --> Output Class Initialized
INFO - 2022-01-19 05:44:34 --> Security Class Initialized
DEBUG - 2022-01-19 05:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:44:34 --> Input Class Initialized
INFO - 2022-01-19 05:44:34 --> Language Class Initialized
INFO - 2022-01-19 05:44:34 --> Language Class Initialized
INFO - 2022-01-19 05:44:34 --> Config Class Initialized
INFO - 2022-01-19 05:44:34 --> Loader Class Initialized
INFO - 2022-01-19 05:44:34 --> Helper loaded: url_helper
INFO - 2022-01-19 05:44:34 --> Helper loaded: file_helper
INFO - 2022-01-19 05:44:34 --> Helper loaded: form_helper
INFO - 2022-01-19 05:44:34 --> Helper loaded: my_helper
INFO - 2022-01-19 05:44:34 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:44:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:44:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:44:35 --> Controller Class Initialized
DEBUG - 2022-01-19 05:44:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tki.php
INFO - 2022-01-19 05:44:35 --> Final output sent to browser
DEBUG - 2022-01-19 05:44:35 --> Total execution time: 0.1090
INFO - 2022-01-19 05:44:55 --> Config Class Initialized
INFO - 2022-01-19 05:44:55 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:44:55 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:44:55 --> Utf8 Class Initialized
INFO - 2022-01-19 05:44:55 --> URI Class Initialized
INFO - 2022-01-19 05:44:55 --> Router Class Initialized
INFO - 2022-01-19 05:44:55 --> Output Class Initialized
INFO - 2022-01-19 05:44:55 --> Security Class Initialized
DEBUG - 2022-01-19 05:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:44:55 --> Input Class Initialized
INFO - 2022-01-19 05:44:55 --> Language Class Initialized
INFO - 2022-01-19 05:44:55 --> Language Class Initialized
INFO - 2022-01-19 05:44:55 --> Config Class Initialized
INFO - 2022-01-19 05:44:55 --> Loader Class Initialized
INFO - 2022-01-19 05:44:55 --> Helper loaded: url_helper
INFO - 2022-01-19 05:44:55 --> Helper loaded: file_helper
INFO - 2022-01-19 05:44:55 --> Helper loaded: form_helper
INFO - 2022-01-19 05:44:55 --> Helper loaded: my_helper
INFO - 2022-01-19 05:44:55 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:44:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:44:55 --> Controller Class Initialized
DEBUG - 2022-01-19 05:44:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-01-19 05:44:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-19 05:44:55 --> Final output sent to browser
DEBUG - 2022-01-19 05:44:55 --> Total execution time: 0.0560
INFO - 2022-01-19 05:44:58 --> Config Class Initialized
INFO - 2022-01-19 05:44:58 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:44:58 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:44:58 --> Utf8 Class Initialized
INFO - 2022-01-19 05:44:58 --> URI Class Initialized
INFO - 2022-01-19 05:44:58 --> Router Class Initialized
INFO - 2022-01-19 05:44:58 --> Output Class Initialized
INFO - 2022-01-19 05:44:58 --> Security Class Initialized
DEBUG - 2022-01-19 05:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:44:58 --> Input Class Initialized
INFO - 2022-01-19 05:44:58 --> Language Class Initialized
INFO - 2022-01-19 05:44:58 --> Language Class Initialized
INFO - 2022-01-19 05:44:58 --> Config Class Initialized
INFO - 2022-01-19 05:44:58 --> Loader Class Initialized
INFO - 2022-01-19 05:44:58 --> Helper loaded: url_helper
INFO - 2022-01-19 05:44:58 --> Helper loaded: file_helper
INFO - 2022-01-19 05:44:58 --> Helper loaded: form_helper
INFO - 2022-01-19 05:44:58 --> Helper loaded: my_helper
INFO - 2022-01-19 05:44:58 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:44:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:44:58 --> Controller Class Initialized
DEBUG - 2022-01-19 05:44:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-19 05:44:58 --> Final output sent to browser
DEBUG - 2022-01-19 05:44:58 --> Total execution time: 0.1190
INFO - 2022-01-19 05:45:42 --> Config Class Initialized
INFO - 2022-01-19 05:45:42 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:45:42 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:45:42 --> Utf8 Class Initialized
INFO - 2022-01-19 05:45:42 --> URI Class Initialized
INFO - 2022-01-19 05:45:42 --> Router Class Initialized
INFO - 2022-01-19 05:45:42 --> Output Class Initialized
INFO - 2022-01-19 05:45:42 --> Security Class Initialized
DEBUG - 2022-01-19 05:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:45:42 --> Input Class Initialized
INFO - 2022-01-19 05:45:42 --> Language Class Initialized
INFO - 2022-01-19 05:45:42 --> Language Class Initialized
INFO - 2022-01-19 05:45:42 --> Config Class Initialized
INFO - 2022-01-19 05:45:42 --> Loader Class Initialized
INFO - 2022-01-19 05:45:42 --> Helper loaded: url_helper
INFO - 2022-01-19 05:45:42 --> Helper loaded: file_helper
INFO - 2022-01-19 05:45:42 --> Helper loaded: form_helper
INFO - 2022-01-19 05:45:42 --> Helper loaded: my_helper
INFO - 2022-01-19 05:45:42 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:45:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:45:42 --> Controller Class Initialized
DEBUG - 2022-01-19 05:45:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-19 05:45:42 --> Final output sent to browser
DEBUG - 2022-01-19 05:45:42 --> Total execution time: 0.0720
INFO - 2022-01-19 05:45:44 --> Config Class Initialized
INFO - 2022-01-19 05:45:44 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:45:44 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:45:44 --> Utf8 Class Initialized
INFO - 2022-01-19 05:45:44 --> URI Class Initialized
INFO - 2022-01-19 05:45:44 --> Router Class Initialized
INFO - 2022-01-19 05:45:44 --> Output Class Initialized
INFO - 2022-01-19 05:45:44 --> Security Class Initialized
DEBUG - 2022-01-19 05:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:45:44 --> Input Class Initialized
INFO - 2022-01-19 05:45:44 --> Language Class Initialized
INFO - 2022-01-19 05:45:44 --> Language Class Initialized
INFO - 2022-01-19 05:45:44 --> Config Class Initialized
INFO - 2022-01-19 05:45:44 --> Loader Class Initialized
INFO - 2022-01-19 05:45:44 --> Helper loaded: url_helper
INFO - 2022-01-19 05:45:44 --> Helper loaded: file_helper
INFO - 2022-01-19 05:45:44 --> Helper loaded: form_helper
INFO - 2022-01-19 05:45:44 --> Helper loaded: my_helper
INFO - 2022-01-19 05:45:44 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:45:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:45:44 --> Controller Class Initialized
DEBUG - 2022-01-19 05:45:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-19 05:45:44 --> Final output sent to browser
DEBUG - 2022-01-19 05:45:44 --> Total execution time: 0.0710
INFO - 2022-01-19 05:45:46 --> Config Class Initialized
INFO - 2022-01-19 05:45:46 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:45:46 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:45:46 --> Utf8 Class Initialized
INFO - 2022-01-19 05:45:46 --> URI Class Initialized
INFO - 2022-01-19 05:45:46 --> Router Class Initialized
INFO - 2022-01-19 05:45:46 --> Output Class Initialized
INFO - 2022-01-19 05:45:46 --> Security Class Initialized
DEBUG - 2022-01-19 05:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:45:46 --> Input Class Initialized
INFO - 2022-01-19 05:45:46 --> Language Class Initialized
INFO - 2022-01-19 05:45:46 --> Language Class Initialized
INFO - 2022-01-19 05:45:46 --> Config Class Initialized
INFO - 2022-01-19 05:45:46 --> Loader Class Initialized
INFO - 2022-01-19 05:45:46 --> Helper loaded: url_helper
INFO - 2022-01-19 05:45:46 --> Helper loaded: file_helper
INFO - 2022-01-19 05:45:46 --> Helper loaded: form_helper
INFO - 2022-01-19 05:45:46 --> Helper loaded: my_helper
INFO - 2022-01-19 05:45:46 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:45:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:45:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:45:46 --> Controller Class Initialized
DEBUG - 2022-01-19 05:45:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-19 05:45:46 --> Final output sent to browser
DEBUG - 2022-01-19 05:45:46 --> Total execution time: 0.0720
INFO - 2022-01-19 05:45:48 --> Config Class Initialized
INFO - 2022-01-19 05:45:48 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:45:48 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:45:48 --> Utf8 Class Initialized
INFO - 2022-01-19 05:45:48 --> URI Class Initialized
INFO - 2022-01-19 05:45:48 --> Router Class Initialized
INFO - 2022-01-19 05:45:48 --> Output Class Initialized
INFO - 2022-01-19 05:45:48 --> Security Class Initialized
DEBUG - 2022-01-19 05:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:45:48 --> Input Class Initialized
INFO - 2022-01-19 05:45:48 --> Language Class Initialized
INFO - 2022-01-19 05:45:48 --> Language Class Initialized
INFO - 2022-01-19 05:45:48 --> Config Class Initialized
INFO - 2022-01-19 05:45:48 --> Loader Class Initialized
INFO - 2022-01-19 05:45:48 --> Helper loaded: url_helper
INFO - 2022-01-19 05:45:48 --> Helper loaded: file_helper
INFO - 2022-01-19 05:45:48 --> Helper loaded: form_helper
INFO - 2022-01-19 05:45:48 --> Helper loaded: my_helper
INFO - 2022-01-19 05:45:48 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:45:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:45:48 --> Controller Class Initialized
DEBUG - 2022-01-19 05:45:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-19 05:45:48 --> Final output sent to browser
DEBUG - 2022-01-19 05:45:48 --> Total execution time: 0.0540
INFO - 2022-01-19 05:45:49 --> Config Class Initialized
INFO - 2022-01-19 05:45:49 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:45:49 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:45:49 --> Utf8 Class Initialized
INFO - 2022-01-19 05:45:49 --> URI Class Initialized
INFO - 2022-01-19 05:45:49 --> Router Class Initialized
INFO - 2022-01-19 05:45:49 --> Output Class Initialized
INFO - 2022-01-19 05:45:49 --> Security Class Initialized
DEBUG - 2022-01-19 05:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:45:49 --> Input Class Initialized
INFO - 2022-01-19 05:45:49 --> Language Class Initialized
INFO - 2022-01-19 05:45:49 --> Language Class Initialized
INFO - 2022-01-19 05:45:49 --> Config Class Initialized
INFO - 2022-01-19 05:45:49 --> Loader Class Initialized
INFO - 2022-01-19 05:45:49 --> Helper loaded: url_helper
INFO - 2022-01-19 05:45:49 --> Helper loaded: file_helper
INFO - 2022-01-19 05:45:49 --> Helper loaded: form_helper
INFO - 2022-01-19 05:45:49 --> Helper loaded: my_helper
INFO - 2022-01-19 05:45:49 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:45:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:45:49 --> Controller Class Initialized
DEBUG - 2022-01-19 05:45:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-19 05:45:49 --> Final output sent to browser
DEBUG - 2022-01-19 05:45:49 --> Total execution time: 0.0670
INFO - 2022-01-19 05:45:51 --> Config Class Initialized
INFO - 2022-01-19 05:45:51 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:45:51 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:45:51 --> Utf8 Class Initialized
INFO - 2022-01-19 05:45:51 --> URI Class Initialized
INFO - 2022-01-19 05:45:51 --> Router Class Initialized
INFO - 2022-01-19 05:45:51 --> Output Class Initialized
INFO - 2022-01-19 05:45:51 --> Security Class Initialized
DEBUG - 2022-01-19 05:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:45:51 --> Input Class Initialized
INFO - 2022-01-19 05:45:51 --> Language Class Initialized
INFO - 2022-01-19 05:45:51 --> Language Class Initialized
INFO - 2022-01-19 05:45:51 --> Config Class Initialized
INFO - 2022-01-19 05:45:51 --> Loader Class Initialized
INFO - 2022-01-19 05:45:51 --> Helper loaded: url_helper
INFO - 2022-01-19 05:45:51 --> Helper loaded: file_helper
INFO - 2022-01-19 05:45:51 --> Helper loaded: form_helper
INFO - 2022-01-19 05:45:51 --> Helper loaded: my_helper
INFO - 2022-01-19 05:45:51 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:45:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:45:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:45:51 --> Controller Class Initialized
DEBUG - 2022-01-19 05:45:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-19 05:45:51 --> Final output sent to browser
DEBUG - 2022-01-19 05:45:51 --> Total execution time: 0.0660
INFO - 2022-01-19 05:45:54 --> Config Class Initialized
INFO - 2022-01-19 05:45:54 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:45:54 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:45:54 --> Utf8 Class Initialized
INFO - 2022-01-19 05:45:54 --> URI Class Initialized
INFO - 2022-01-19 05:45:54 --> Router Class Initialized
INFO - 2022-01-19 05:45:54 --> Output Class Initialized
INFO - 2022-01-19 05:45:54 --> Security Class Initialized
DEBUG - 2022-01-19 05:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:45:54 --> Input Class Initialized
INFO - 2022-01-19 05:45:54 --> Language Class Initialized
INFO - 2022-01-19 05:45:54 --> Language Class Initialized
INFO - 2022-01-19 05:45:54 --> Config Class Initialized
INFO - 2022-01-19 05:45:54 --> Loader Class Initialized
INFO - 2022-01-19 05:45:54 --> Helper loaded: url_helper
INFO - 2022-01-19 05:45:54 --> Helper loaded: file_helper
INFO - 2022-01-19 05:45:54 --> Helper loaded: form_helper
INFO - 2022-01-19 05:45:54 --> Helper loaded: my_helper
INFO - 2022-01-19 05:45:54 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:45:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:45:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:45:54 --> Controller Class Initialized
DEBUG - 2022-01-19 05:45:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-19 05:45:54 --> Final output sent to browser
DEBUG - 2022-01-19 05:45:54 --> Total execution time: 0.0650
INFO - 2022-01-19 05:45:55 --> Config Class Initialized
INFO - 2022-01-19 05:45:55 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:45:55 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:45:55 --> Utf8 Class Initialized
INFO - 2022-01-19 05:45:55 --> URI Class Initialized
INFO - 2022-01-19 05:45:55 --> Router Class Initialized
INFO - 2022-01-19 05:45:55 --> Output Class Initialized
INFO - 2022-01-19 05:45:55 --> Security Class Initialized
DEBUG - 2022-01-19 05:45:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:45:55 --> Input Class Initialized
INFO - 2022-01-19 05:45:55 --> Language Class Initialized
INFO - 2022-01-19 05:45:56 --> Language Class Initialized
INFO - 2022-01-19 05:45:56 --> Config Class Initialized
INFO - 2022-01-19 05:45:56 --> Loader Class Initialized
INFO - 2022-01-19 05:45:56 --> Helper loaded: url_helper
INFO - 2022-01-19 05:45:56 --> Helper loaded: file_helper
INFO - 2022-01-19 05:45:56 --> Helper loaded: form_helper
INFO - 2022-01-19 05:45:56 --> Helper loaded: my_helper
INFO - 2022-01-19 05:45:56 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:45:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:45:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:45:56 --> Controller Class Initialized
DEBUG - 2022-01-19 05:45:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-19 05:45:56 --> Final output sent to browser
DEBUG - 2022-01-19 05:45:56 --> Total execution time: 0.0680
INFO - 2022-01-19 05:45:58 --> Config Class Initialized
INFO - 2022-01-19 05:45:58 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:45:58 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:45:58 --> Utf8 Class Initialized
INFO - 2022-01-19 05:45:58 --> URI Class Initialized
INFO - 2022-01-19 05:45:58 --> Router Class Initialized
INFO - 2022-01-19 05:45:58 --> Output Class Initialized
INFO - 2022-01-19 05:45:58 --> Security Class Initialized
DEBUG - 2022-01-19 05:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:45:58 --> Input Class Initialized
INFO - 2022-01-19 05:45:58 --> Language Class Initialized
INFO - 2022-01-19 05:45:58 --> Language Class Initialized
INFO - 2022-01-19 05:45:58 --> Config Class Initialized
INFO - 2022-01-19 05:45:58 --> Loader Class Initialized
INFO - 2022-01-19 05:45:58 --> Helper loaded: url_helper
INFO - 2022-01-19 05:45:58 --> Helper loaded: file_helper
INFO - 2022-01-19 05:45:58 --> Helper loaded: form_helper
INFO - 2022-01-19 05:45:58 --> Helper loaded: my_helper
INFO - 2022-01-19 05:45:58 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:45:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:45:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:45:58 --> Controller Class Initialized
DEBUG - 2022-01-19 05:45:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-19 05:45:58 --> Final output sent to browser
DEBUG - 2022-01-19 05:45:58 --> Total execution time: 0.0580
INFO - 2022-01-19 05:46:01 --> Config Class Initialized
INFO - 2022-01-19 05:46:01 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:46:01 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:46:01 --> Utf8 Class Initialized
INFO - 2022-01-19 05:46:01 --> URI Class Initialized
INFO - 2022-01-19 05:46:01 --> Router Class Initialized
INFO - 2022-01-19 05:46:01 --> Output Class Initialized
INFO - 2022-01-19 05:46:01 --> Security Class Initialized
DEBUG - 2022-01-19 05:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:46:01 --> Input Class Initialized
INFO - 2022-01-19 05:46:01 --> Language Class Initialized
INFO - 2022-01-19 05:46:01 --> Language Class Initialized
INFO - 2022-01-19 05:46:01 --> Config Class Initialized
INFO - 2022-01-19 05:46:01 --> Loader Class Initialized
INFO - 2022-01-19 05:46:01 --> Helper loaded: url_helper
INFO - 2022-01-19 05:46:01 --> Helper loaded: file_helper
INFO - 2022-01-19 05:46:01 --> Helper loaded: form_helper
INFO - 2022-01-19 05:46:01 --> Helper loaded: my_helper
INFO - 2022-01-19 05:46:01 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:46:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:46:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:46:01 --> Controller Class Initialized
DEBUG - 2022-01-19 05:46:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-19 05:46:01 --> Final output sent to browser
DEBUG - 2022-01-19 05:46:01 --> Total execution time: 0.0690
INFO - 2022-01-19 05:46:03 --> Config Class Initialized
INFO - 2022-01-19 05:46:03 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:46:03 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:46:03 --> Utf8 Class Initialized
INFO - 2022-01-19 05:46:03 --> URI Class Initialized
INFO - 2022-01-19 05:46:03 --> Router Class Initialized
INFO - 2022-01-19 05:46:03 --> Output Class Initialized
INFO - 2022-01-19 05:46:03 --> Security Class Initialized
DEBUG - 2022-01-19 05:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:46:03 --> Input Class Initialized
INFO - 2022-01-19 05:46:03 --> Language Class Initialized
INFO - 2022-01-19 05:46:03 --> Language Class Initialized
INFO - 2022-01-19 05:46:03 --> Config Class Initialized
INFO - 2022-01-19 05:46:03 --> Loader Class Initialized
INFO - 2022-01-19 05:46:03 --> Helper loaded: url_helper
INFO - 2022-01-19 05:46:03 --> Helper loaded: file_helper
INFO - 2022-01-19 05:46:03 --> Helper loaded: form_helper
INFO - 2022-01-19 05:46:03 --> Helper loaded: my_helper
INFO - 2022-01-19 05:46:03 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:46:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:46:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:46:03 --> Controller Class Initialized
DEBUG - 2022-01-19 05:46:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-19 05:46:03 --> Final output sent to browser
DEBUG - 2022-01-19 05:46:03 --> Total execution time: 0.0660
INFO - 2022-01-19 05:46:05 --> Config Class Initialized
INFO - 2022-01-19 05:46:05 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:46:05 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:46:05 --> Utf8 Class Initialized
INFO - 2022-01-19 05:46:05 --> URI Class Initialized
INFO - 2022-01-19 05:46:05 --> Router Class Initialized
INFO - 2022-01-19 05:46:05 --> Output Class Initialized
INFO - 2022-01-19 05:46:05 --> Security Class Initialized
DEBUG - 2022-01-19 05:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:46:05 --> Input Class Initialized
INFO - 2022-01-19 05:46:05 --> Language Class Initialized
INFO - 2022-01-19 05:46:05 --> Language Class Initialized
INFO - 2022-01-19 05:46:05 --> Config Class Initialized
INFO - 2022-01-19 05:46:05 --> Loader Class Initialized
INFO - 2022-01-19 05:46:05 --> Helper loaded: url_helper
INFO - 2022-01-19 05:46:05 --> Helper loaded: file_helper
INFO - 2022-01-19 05:46:05 --> Helper loaded: form_helper
INFO - 2022-01-19 05:46:05 --> Helper loaded: my_helper
INFO - 2022-01-19 05:46:05 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:46:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:46:05 --> Controller Class Initialized
DEBUG - 2022-01-19 05:46:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-19 05:46:05 --> Final output sent to browser
DEBUG - 2022-01-19 05:46:05 --> Total execution time: 0.0590
INFO - 2022-01-19 05:46:08 --> Config Class Initialized
INFO - 2022-01-19 05:46:08 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:46:08 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:46:08 --> Utf8 Class Initialized
INFO - 2022-01-19 05:46:08 --> URI Class Initialized
INFO - 2022-01-19 05:46:08 --> Router Class Initialized
INFO - 2022-01-19 05:46:08 --> Output Class Initialized
INFO - 2022-01-19 05:46:08 --> Security Class Initialized
DEBUG - 2022-01-19 05:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:46:08 --> Input Class Initialized
INFO - 2022-01-19 05:46:08 --> Language Class Initialized
INFO - 2022-01-19 05:46:08 --> Language Class Initialized
INFO - 2022-01-19 05:46:08 --> Config Class Initialized
INFO - 2022-01-19 05:46:08 --> Loader Class Initialized
INFO - 2022-01-19 05:46:08 --> Helper loaded: url_helper
INFO - 2022-01-19 05:46:08 --> Helper loaded: file_helper
INFO - 2022-01-19 05:46:08 --> Helper loaded: form_helper
INFO - 2022-01-19 05:46:08 --> Helper loaded: my_helper
INFO - 2022-01-19 05:46:08 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:46:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:46:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:46:08 --> Controller Class Initialized
DEBUG - 2022-01-19 05:46:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-19 05:46:08 --> Final output sent to browser
DEBUG - 2022-01-19 05:46:08 --> Total execution time: 0.0580
INFO - 2022-01-19 05:46:11 --> Config Class Initialized
INFO - 2022-01-19 05:46:11 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:46:11 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:46:11 --> Utf8 Class Initialized
INFO - 2022-01-19 05:46:11 --> URI Class Initialized
INFO - 2022-01-19 05:46:11 --> Router Class Initialized
INFO - 2022-01-19 05:46:11 --> Output Class Initialized
INFO - 2022-01-19 05:46:11 --> Security Class Initialized
DEBUG - 2022-01-19 05:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:46:11 --> Input Class Initialized
INFO - 2022-01-19 05:46:11 --> Language Class Initialized
INFO - 2022-01-19 05:46:11 --> Language Class Initialized
INFO - 2022-01-19 05:46:11 --> Config Class Initialized
INFO - 2022-01-19 05:46:11 --> Loader Class Initialized
INFO - 2022-01-19 05:46:11 --> Helper loaded: url_helper
INFO - 2022-01-19 05:46:11 --> Helper loaded: file_helper
INFO - 2022-01-19 05:46:11 --> Helper loaded: form_helper
INFO - 2022-01-19 05:46:11 --> Helper loaded: my_helper
INFO - 2022-01-19 05:46:11 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:46:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:46:11 --> Controller Class Initialized
DEBUG - 2022-01-19 05:46:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-19 05:46:11 --> Final output sent to browser
DEBUG - 2022-01-19 05:46:11 --> Total execution time: 0.0670
INFO - 2022-01-19 05:46:13 --> Config Class Initialized
INFO - 2022-01-19 05:46:13 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:46:13 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:46:13 --> Utf8 Class Initialized
INFO - 2022-01-19 05:46:13 --> URI Class Initialized
INFO - 2022-01-19 05:46:13 --> Router Class Initialized
INFO - 2022-01-19 05:46:13 --> Output Class Initialized
INFO - 2022-01-19 05:46:13 --> Security Class Initialized
DEBUG - 2022-01-19 05:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:46:13 --> Input Class Initialized
INFO - 2022-01-19 05:46:13 --> Language Class Initialized
INFO - 2022-01-19 05:46:13 --> Language Class Initialized
INFO - 2022-01-19 05:46:13 --> Config Class Initialized
INFO - 2022-01-19 05:46:13 --> Loader Class Initialized
INFO - 2022-01-19 05:46:13 --> Helper loaded: url_helper
INFO - 2022-01-19 05:46:13 --> Helper loaded: file_helper
INFO - 2022-01-19 05:46:13 --> Helper loaded: form_helper
INFO - 2022-01-19 05:46:13 --> Helper loaded: my_helper
INFO - 2022-01-19 05:46:13 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:46:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:46:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:46:13 --> Controller Class Initialized
DEBUG - 2022-01-19 05:46:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-19 05:46:13 --> Final output sent to browser
DEBUG - 2022-01-19 05:46:13 --> Total execution time: 0.0670
INFO - 2022-01-19 05:48:14 --> Config Class Initialized
INFO - 2022-01-19 05:48:14 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:48:14 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:48:14 --> Utf8 Class Initialized
INFO - 2022-01-19 05:48:14 --> URI Class Initialized
INFO - 2022-01-19 05:48:14 --> Router Class Initialized
INFO - 2022-01-19 05:48:14 --> Output Class Initialized
INFO - 2022-01-19 05:48:14 --> Security Class Initialized
DEBUG - 2022-01-19 05:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:48:14 --> Input Class Initialized
INFO - 2022-01-19 05:48:14 --> Language Class Initialized
INFO - 2022-01-19 05:48:14 --> Language Class Initialized
INFO - 2022-01-19 05:48:14 --> Config Class Initialized
INFO - 2022-01-19 05:48:14 --> Loader Class Initialized
INFO - 2022-01-19 05:48:14 --> Helper loaded: url_helper
INFO - 2022-01-19 05:48:14 --> Helper loaded: file_helper
INFO - 2022-01-19 05:48:14 --> Helper loaded: form_helper
INFO - 2022-01-19 05:48:14 --> Helper loaded: my_helper
INFO - 2022-01-19 05:48:14 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:48:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:48:14 --> Controller Class Initialized
INFO - 2022-01-19 05:48:14 --> Helper loaded: cookie_helper
INFO - 2022-01-19 05:48:14 --> Config Class Initialized
INFO - 2022-01-19 05:48:14 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:48:14 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:48:14 --> Utf8 Class Initialized
INFO - 2022-01-19 05:48:14 --> URI Class Initialized
INFO - 2022-01-19 05:48:14 --> Router Class Initialized
INFO - 2022-01-19 05:48:14 --> Output Class Initialized
INFO - 2022-01-19 05:48:14 --> Security Class Initialized
DEBUG - 2022-01-19 05:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:48:14 --> Input Class Initialized
INFO - 2022-01-19 05:48:14 --> Language Class Initialized
INFO - 2022-01-19 05:48:14 --> Language Class Initialized
INFO - 2022-01-19 05:48:14 --> Config Class Initialized
INFO - 2022-01-19 05:48:14 --> Loader Class Initialized
INFO - 2022-01-19 05:48:14 --> Helper loaded: url_helper
INFO - 2022-01-19 05:48:14 --> Helper loaded: file_helper
INFO - 2022-01-19 05:48:14 --> Helper loaded: form_helper
INFO - 2022-01-19 05:48:14 --> Helper loaded: my_helper
INFO - 2022-01-19 05:48:14 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:48:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:48:14 --> Controller Class Initialized
DEBUG - 2022-01-19 05:48:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-01-19 05:48:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-19 05:48:14 --> Final output sent to browser
DEBUG - 2022-01-19 05:48:14 --> Total execution time: 0.0350
INFO - 2022-01-19 05:48:23 --> Config Class Initialized
INFO - 2022-01-19 05:48:23 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:48:23 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:48:23 --> Utf8 Class Initialized
INFO - 2022-01-19 05:48:23 --> URI Class Initialized
INFO - 2022-01-19 05:48:23 --> Router Class Initialized
INFO - 2022-01-19 05:48:23 --> Output Class Initialized
INFO - 2022-01-19 05:48:23 --> Security Class Initialized
DEBUG - 2022-01-19 05:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:48:23 --> Input Class Initialized
INFO - 2022-01-19 05:48:23 --> Language Class Initialized
INFO - 2022-01-19 05:48:23 --> Language Class Initialized
INFO - 2022-01-19 05:48:23 --> Config Class Initialized
INFO - 2022-01-19 05:48:23 --> Loader Class Initialized
INFO - 2022-01-19 05:48:23 --> Helper loaded: url_helper
INFO - 2022-01-19 05:48:23 --> Helper loaded: file_helper
INFO - 2022-01-19 05:48:23 --> Helper loaded: form_helper
INFO - 2022-01-19 05:48:23 --> Helper loaded: my_helper
INFO - 2022-01-19 05:48:23 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:48:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:48:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:48:23 --> Controller Class Initialized
INFO - 2022-01-19 05:48:23 --> Helper loaded: cookie_helper
INFO - 2022-01-19 05:48:23 --> Final output sent to browser
DEBUG - 2022-01-19 05:48:23 --> Total execution time: 0.0390
INFO - 2022-01-19 05:48:23 --> Config Class Initialized
INFO - 2022-01-19 05:48:23 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:48:23 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:48:23 --> Utf8 Class Initialized
INFO - 2022-01-19 05:48:23 --> URI Class Initialized
INFO - 2022-01-19 05:48:23 --> Router Class Initialized
INFO - 2022-01-19 05:48:23 --> Output Class Initialized
INFO - 2022-01-19 05:48:23 --> Security Class Initialized
DEBUG - 2022-01-19 05:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:48:23 --> Input Class Initialized
INFO - 2022-01-19 05:48:23 --> Language Class Initialized
INFO - 2022-01-19 05:48:23 --> Language Class Initialized
INFO - 2022-01-19 05:48:23 --> Config Class Initialized
INFO - 2022-01-19 05:48:23 --> Loader Class Initialized
INFO - 2022-01-19 05:48:23 --> Helper loaded: url_helper
INFO - 2022-01-19 05:48:23 --> Helper loaded: file_helper
INFO - 2022-01-19 05:48:23 --> Helper loaded: form_helper
INFO - 2022-01-19 05:48:23 --> Helper loaded: my_helper
INFO - 2022-01-19 05:48:23 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:48:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:48:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:48:23 --> Controller Class Initialized
DEBUG - 2022-01-19 05:48:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-01-19 05:48:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-19 05:48:23 --> Final output sent to browser
DEBUG - 2022-01-19 05:48:23 --> Total execution time: 0.4030
INFO - 2022-01-19 05:49:04 --> Config Class Initialized
INFO - 2022-01-19 05:49:04 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:49:04 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:49:04 --> Utf8 Class Initialized
INFO - 2022-01-19 05:49:04 --> URI Class Initialized
INFO - 2022-01-19 05:49:04 --> Router Class Initialized
INFO - 2022-01-19 05:49:04 --> Output Class Initialized
INFO - 2022-01-19 05:49:04 --> Security Class Initialized
DEBUG - 2022-01-19 05:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:49:04 --> Input Class Initialized
INFO - 2022-01-19 05:49:04 --> Language Class Initialized
INFO - 2022-01-19 05:49:04 --> Language Class Initialized
INFO - 2022-01-19 05:49:04 --> Config Class Initialized
INFO - 2022-01-19 05:49:04 --> Loader Class Initialized
INFO - 2022-01-19 05:49:04 --> Helper loaded: url_helper
INFO - 2022-01-19 05:49:04 --> Helper loaded: file_helper
INFO - 2022-01-19 05:49:04 --> Helper loaded: form_helper
INFO - 2022-01-19 05:49:04 --> Helper loaded: my_helper
INFO - 2022-01-19 05:49:04 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:49:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:49:04 --> Controller Class Initialized
DEBUG - 2022-01-19 05:49:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2022-01-19 05:49:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-19 05:49:04 --> Final output sent to browser
DEBUG - 2022-01-19 05:49:04 --> Total execution time: 0.0460
INFO - 2022-01-19 05:49:04 --> Config Class Initialized
INFO - 2022-01-19 05:49:04 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:49:04 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:49:04 --> Utf8 Class Initialized
INFO - 2022-01-19 05:49:04 --> URI Class Initialized
INFO - 2022-01-19 05:49:04 --> Router Class Initialized
INFO - 2022-01-19 05:49:04 --> Output Class Initialized
INFO - 2022-01-19 05:49:04 --> Security Class Initialized
DEBUG - 2022-01-19 05:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:49:04 --> Input Class Initialized
INFO - 2022-01-19 05:49:04 --> Language Class Initialized
INFO - 2022-01-19 05:49:04 --> Language Class Initialized
INFO - 2022-01-19 05:49:04 --> Config Class Initialized
INFO - 2022-01-19 05:49:04 --> Loader Class Initialized
INFO - 2022-01-19 05:49:04 --> Helper loaded: url_helper
INFO - 2022-01-19 05:49:04 --> Helper loaded: file_helper
INFO - 2022-01-19 05:49:04 --> Helper loaded: form_helper
INFO - 2022-01-19 05:49:04 --> Helper loaded: my_helper
INFO - 2022-01-19 05:49:04 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:49:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:49:04 --> Controller Class Initialized
INFO - 2022-01-19 05:49:05 --> Config Class Initialized
INFO - 2022-01-19 05:49:05 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:49:05 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:49:05 --> Utf8 Class Initialized
INFO - 2022-01-19 05:49:05 --> URI Class Initialized
INFO - 2022-01-19 05:49:05 --> Router Class Initialized
INFO - 2022-01-19 05:49:05 --> Output Class Initialized
INFO - 2022-01-19 05:49:05 --> Security Class Initialized
DEBUG - 2022-01-19 05:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:49:05 --> Input Class Initialized
INFO - 2022-01-19 05:49:05 --> Language Class Initialized
INFO - 2022-01-19 05:49:05 --> Language Class Initialized
INFO - 2022-01-19 05:49:05 --> Config Class Initialized
INFO - 2022-01-19 05:49:05 --> Loader Class Initialized
INFO - 2022-01-19 05:49:05 --> Helper loaded: url_helper
INFO - 2022-01-19 05:49:05 --> Helper loaded: file_helper
INFO - 2022-01-19 05:49:05 --> Helper loaded: form_helper
INFO - 2022-01-19 05:49:05 --> Helper loaded: my_helper
INFO - 2022-01-19 05:49:05 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:49:05 --> Controller Class Initialized
INFO - 2022-01-19 05:49:05 --> Final output sent to browser
DEBUG - 2022-01-19 05:49:05 --> Total execution time: 0.0620
INFO - 2022-01-19 05:49:05 --> Config Class Initialized
INFO - 2022-01-19 05:49:05 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:49:05 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:49:05 --> Utf8 Class Initialized
INFO - 2022-01-19 05:49:05 --> URI Class Initialized
INFO - 2022-01-19 05:49:05 --> Router Class Initialized
INFO - 2022-01-19 05:49:05 --> Output Class Initialized
INFO - 2022-01-19 05:49:05 --> Security Class Initialized
DEBUG - 2022-01-19 05:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:49:05 --> Input Class Initialized
INFO - 2022-01-19 05:49:05 --> Language Class Initialized
INFO - 2022-01-19 05:49:05 --> Language Class Initialized
INFO - 2022-01-19 05:49:05 --> Config Class Initialized
INFO - 2022-01-19 05:49:05 --> Loader Class Initialized
INFO - 2022-01-19 05:49:05 --> Helper loaded: url_helper
INFO - 2022-01-19 05:49:05 --> Helper loaded: file_helper
INFO - 2022-01-19 05:49:05 --> Helper loaded: form_helper
INFO - 2022-01-19 05:49:05 --> Helper loaded: my_helper
INFO - 2022-01-19 05:49:05 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:49:05 --> Controller Class Initialized
INFO - 2022-01-19 05:49:08 --> Config Class Initialized
INFO - 2022-01-19 05:49:08 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:49:08 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:49:08 --> Utf8 Class Initialized
INFO - 2022-01-19 05:49:08 --> URI Class Initialized
INFO - 2022-01-19 05:49:08 --> Router Class Initialized
INFO - 2022-01-19 05:49:08 --> Output Class Initialized
INFO - 2022-01-19 05:49:08 --> Security Class Initialized
DEBUG - 2022-01-19 05:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:49:08 --> Input Class Initialized
INFO - 2022-01-19 05:49:08 --> Language Class Initialized
INFO - 2022-01-19 05:49:08 --> Language Class Initialized
INFO - 2022-01-19 05:49:08 --> Config Class Initialized
INFO - 2022-01-19 05:49:08 --> Loader Class Initialized
INFO - 2022-01-19 05:49:08 --> Helper loaded: url_helper
INFO - 2022-01-19 05:49:08 --> Helper loaded: file_helper
INFO - 2022-01-19 05:49:08 --> Helper loaded: form_helper
INFO - 2022-01-19 05:49:08 --> Helper loaded: my_helper
INFO - 2022-01-19 05:49:08 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:49:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:49:08 --> Controller Class Initialized
INFO - 2022-01-19 05:49:08 --> Helper loaded: cookie_helper
INFO - 2022-01-19 05:49:08 --> Config Class Initialized
INFO - 2022-01-19 05:49:08 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:49:08 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:49:08 --> Utf8 Class Initialized
INFO - 2022-01-19 05:49:08 --> URI Class Initialized
INFO - 2022-01-19 05:49:08 --> Router Class Initialized
INFO - 2022-01-19 05:49:08 --> Output Class Initialized
INFO - 2022-01-19 05:49:08 --> Security Class Initialized
DEBUG - 2022-01-19 05:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:49:08 --> Input Class Initialized
INFO - 2022-01-19 05:49:08 --> Language Class Initialized
INFO - 2022-01-19 05:49:08 --> Language Class Initialized
INFO - 2022-01-19 05:49:08 --> Config Class Initialized
INFO - 2022-01-19 05:49:08 --> Loader Class Initialized
INFO - 2022-01-19 05:49:08 --> Helper loaded: url_helper
INFO - 2022-01-19 05:49:08 --> Helper loaded: file_helper
INFO - 2022-01-19 05:49:08 --> Helper loaded: form_helper
INFO - 2022-01-19 05:49:08 --> Helper loaded: my_helper
INFO - 2022-01-19 05:49:08 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:49:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:49:08 --> Controller Class Initialized
DEBUG - 2022-01-19 05:49:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-01-19 05:49:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-19 05:49:08 --> Final output sent to browser
DEBUG - 2022-01-19 05:49:08 --> Total execution time: 0.0360
INFO - 2022-01-19 05:49:12 --> Config Class Initialized
INFO - 2022-01-19 05:49:12 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:49:12 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:49:12 --> Utf8 Class Initialized
INFO - 2022-01-19 05:49:12 --> URI Class Initialized
INFO - 2022-01-19 05:49:12 --> Router Class Initialized
INFO - 2022-01-19 05:49:12 --> Output Class Initialized
INFO - 2022-01-19 05:49:12 --> Security Class Initialized
DEBUG - 2022-01-19 05:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:49:12 --> Input Class Initialized
INFO - 2022-01-19 05:49:12 --> Language Class Initialized
INFO - 2022-01-19 05:49:12 --> Language Class Initialized
INFO - 2022-01-19 05:49:12 --> Config Class Initialized
INFO - 2022-01-19 05:49:12 --> Loader Class Initialized
INFO - 2022-01-19 05:49:12 --> Helper loaded: url_helper
INFO - 2022-01-19 05:49:12 --> Helper loaded: file_helper
INFO - 2022-01-19 05:49:12 --> Helper loaded: form_helper
INFO - 2022-01-19 05:49:12 --> Helper loaded: my_helper
INFO - 2022-01-19 05:49:12 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:49:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:49:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:49:12 --> Controller Class Initialized
INFO - 2022-01-19 05:49:12 --> Helper loaded: cookie_helper
INFO - 2022-01-19 05:49:12 --> Final output sent to browser
DEBUG - 2022-01-19 05:49:12 --> Total execution time: 0.0490
INFO - 2022-01-19 05:49:13 --> Config Class Initialized
INFO - 2022-01-19 05:49:13 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:49:13 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:49:13 --> Utf8 Class Initialized
INFO - 2022-01-19 05:49:13 --> URI Class Initialized
INFO - 2022-01-19 05:49:13 --> Router Class Initialized
INFO - 2022-01-19 05:49:13 --> Output Class Initialized
INFO - 2022-01-19 05:49:13 --> Security Class Initialized
DEBUG - 2022-01-19 05:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:49:13 --> Input Class Initialized
INFO - 2022-01-19 05:49:13 --> Language Class Initialized
INFO - 2022-01-19 05:49:13 --> Language Class Initialized
INFO - 2022-01-19 05:49:13 --> Config Class Initialized
INFO - 2022-01-19 05:49:13 --> Loader Class Initialized
INFO - 2022-01-19 05:49:13 --> Helper loaded: url_helper
INFO - 2022-01-19 05:49:13 --> Helper loaded: file_helper
INFO - 2022-01-19 05:49:13 --> Helper loaded: form_helper
INFO - 2022-01-19 05:49:13 --> Helper loaded: my_helper
INFO - 2022-01-19 05:49:13 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:49:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:49:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:49:13 --> Controller Class Initialized
DEBUG - 2022-01-19 05:49:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-01-19 05:49:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-19 05:49:13 --> Final output sent to browser
DEBUG - 2022-01-19 05:49:13 --> Total execution time: 0.2520
INFO - 2022-01-19 05:49:16 --> Config Class Initialized
INFO - 2022-01-19 05:49:16 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:49:16 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:49:16 --> Utf8 Class Initialized
INFO - 2022-01-19 05:49:16 --> URI Class Initialized
INFO - 2022-01-19 05:49:16 --> Router Class Initialized
INFO - 2022-01-19 05:49:16 --> Output Class Initialized
INFO - 2022-01-19 05:49:16 --> Security Class Initialized
DEBUG - 2022-01-19 05:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:49:16 --> Input Class Initialized
INFO - 2022-01-19 05:49:16 --> Language Class Initialized
INFO - 2022-01-19 05:49:16 --> Language Class Initialized
INFO - 2022-01-19 05:49:16 --> Config Class Initialized
INFO - 2022-01-19 05:49:16 --> Loader Class Initialized
INFO - 2022-01-19 05:49:16 --> Helper loaded: url_helper
INFO - 2022-01-19 05:49:16 --> Helper loaded: file_helper
INFO - 2022-01-19 05:49:16 --> Helper loaded: form_helper
INFO - 2022-01-19 05:49:16 --> Helper loaded: my_helper
INFO - 2022-01-19 05:49:16 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:49:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:49:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:49:16 --> Controller Class Initialized
DEBUG - 2022-01-19 05:49:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2022-01-19 05:49:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-19 05:49:16 --> Final output sent to browser
DEBUG - 2022-01-19 05:49:16 --> Total execution time: 0.0560
INFO - 2022-01-19 05:49:19 --> Config Class Initialized
INFO - 2022-01-19 05:49:19 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:49:19 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:49:19 --> Utf8 Class Initialized
INFO - 2022-01-19 05:49:19 --> URI Class Initialized
INFO - 2022-01-19 05:49:19 --> Router Class Initialized
INFO - 2022-01-19 05:49:19 --> Output Class Initialized
INFO - 2022-01-19 05:49:19 --> Security Class Initialized
DEBUG - 2022-01-19 05:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:49:19 --> Input Class Initialized
INFO - 2022-01-19 05:49:19 --> Language Class Initialized
INFO - 2022-01-19 05:49:19 --> Language Class Initialized
INFO - 2022-01-19 05:49:19 --> Config Class Initialized
INFO - 2022-01-19 05:49:19 --> Loader Class Initialized
INFO - 2022-01-19 05:49:19 --> Helper loaded: url_helper
INFO - 2022-01-19 05:49:19 --> Helper loaded: file_helper
INFO - 2022-01-19 05:49:19 --> Helper loaded: form_helper
INFO - 2022-01-19 05:49:19 --> Helper loaded: my_helper
INFO - 2022-01-19 05:49:19 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:49:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:49:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:49:19 --> Controller Class Initialized
DEBUG - 2022-01-19 05:49:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_mm_xi.php
INFO - 2022-01-19 05:49:19 --> Final output sent to browser
DEBUG - 2022-01-19 05:49:19 --> Total execution time: 0.0770
INFO - 2022-01-19 05:50:06 --> Config Class Initialized
INFO - 2022-01-19 05:50:06 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:50:06 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:50:06 --> Utf8 Class Initialized
INFO - 2022-01-19 05:50:06 --> URI Class Initialized
INFO - 2022-01-19 05:50:06 --> Router Class Initialized
INFO - 2022-01-19 05:50:06 --> Output Class Initialized
INFO - 2022-01-19 05:50:06 --> Security Class Initialized
DEBUG - 2022-01-19 05:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:50:06 --> Input Class Initialized
INFO - 2022-01-19 05:50:06 --> Language Class Initialized
INFO - 2022-01-19 05:50:06 --> Language Class Initialized
INFO - 2022-01-19 05:50:06 --> Config Class Initialized
INFO - 2022-01-19 05:50:06 --> Loader Class Initialized
INFO - 2022-01-19 05:50:06 --> Helper loaded: url_helper
INFO - 2022-01-19 05:50:06 --> Helper loaded: file_helper
INFO - 2022-01-19 05:50:06 --> Helper loaded: form_helper
INFO - 2022-01-19 05:50:06 --> Helper loaded: my_helper
INFO - 2022-01-19 05:50:06 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:50:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:50:06 --> Controller Class Initialized
DEBUG - 2022-01-19 05:50:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_mm_xi.php
INFO - 2022-01-19 05:50:06 --> Final output sent to browser
DEBUG - 2022-01-19 05:50:06 --> Total execution time: 0.0640
INFO - 2022-01-19 05:50:17 --> Config Class Initialized
INFO - 2022-01-19 05:50:17 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:50:17 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:50:17 --> Utf8 Class Initialized
INFO - 2022-01-19 05:50:17 --> URI Class Initialized
INFO - 2022-01-19 05:50:17 --> Router Class Initialized
INFO - 2022-01-19 05:50:17 --> Output Class Initialized
INFO - 2022-01-19 05:50:17 --> Security Class Initialized
DEBUG - 2022-01-19 05:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:50:17 --> Input Class Initialized
INFO - 2022-01-19 05:50:17 --> Language Class Initialized
INFO - 2022-01-19 05:50:17 --> Language Class Initialized
INFO - 2022-01-19 05:50:17 --> Config Class Initialized
INFO - 2022-01-19 05:50:17 --> Loader Class Initialized
INFO - 2022-01-19 05:50:17 --> Helper loaded: url_helper
INFO - 2022-01-19 05:50:17 --> Helper loaded: file_helper
INFO - 2022-01-19 05:50:17 --> Helper loaded: form_helper
INFO - 2022-01-19 05:50:17 --> Helper loaded: my_helper
INFO - 2022-01-19 05:50:17 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:50:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:50:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:50:17 --> Controller Class Initialized
INFO - 2022-01-19 05:50:17 --> Helper loaded: cookie_helper
INFO - 2022-01-19 05:50:17 --> Config Class Initialized
INFO - 2022-01-19 05:50:17 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:50:17 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:50:17 --> Utf8 Class Initialized
INFO - 2022-01-19 05:50:17 --> URI Class Initialized
INFO - 2022-01-19 05:50:17 --> Router Class Initialized
INFO - 2022-01-19 05:50:17 --> Output Class Initialized
INFO - 2022-01-19 05:50:17 --> Security Class Initialized
DEBUG - 2022-01-19 05:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:50:17 --> Input Class Initialized
INFO - 2022-01-19 05:50:17 --> Language Class Initialized
INFO - 2022-01-19 05:50:17 --> Language Class Initialized
INFO - 2022-01-19 05:50:17 --> Config Class Initialized
INFO - 2022-01-19 05:50:17 --> Loader Class Initialized
INFO - 2022-01-19 05:50:17 --> Helper loaded: url_helper
INFO - 2022-01-19 05:50:17 --> Helper loaded: file_helper
INFO - 2022-01-19 05:50:17 --> Helper loaded: form_helper
INFO - 2022-01-19 05:50:17 --> Helper loaded: my_helper
INFO - 2022-01-19 05:50:17 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:50:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:50:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:50:17 --> Controller Class Initialized
DEBUG - 2022-01-19 05:50:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-01-19 05:50:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-19 05:50:17 --> Final output sent to browser
DEBUG - 2022-01-19 05:50:17 --> Total execution time: 0.0350
INFO - 2022-01-19 05:50:20 --> Config Class Initialized
INFO - 2022-01-19 05:50:20 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:50:20 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:50:20 --> Utf8 Class Initialized
INFO - 2022-01-19 05:50:20 --> URI Class Initialized
INFO - 2022-01-19 05:50:20 --> Router Class Initialized
INFO - 2022-01-19 05:50:20 --> Output Class Initialized
INFO - 2022-01-19 05:50:20 --> Security Class Initialized
DEBUG - 2022-01-19 05:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:50:20 --> Input Class Initialized
INFO - 2022-01-19 05:50:20 --> Language Class Initialized
INFO - 2022-01-19 05:50:20 --> Language Class Initialized
INFO - 2022-01-19 05:50:20 --> Config Class Initialized
INFO - 2022-01-19 05:50:20 --> Loader Class Initialized
INFO - 2022-01-19 05:50:20 --> Helper loaded: url_helper
INFO - 2022-01-19 05:50:20 --> Helper loaded: file_helper
INFO - 2022-01-19 05:50:20 --> Helper loaded: form_helper
INFO - 2022-01-19 05:50:20 --> Helper loaded: my_helper
INFO - 2022-01-19 05:50:20 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:50:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:50:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:50:20 --> Controller Class Initialized
INFO - 2022-01-19 05:50:20 --> Helper loaded: cookie_helper
INFO - 2022-01-19 05:50:20 --> Final output sent to browser
DEBUG - 2022-01-19 05:50:20 --> Total execution time: 0.0450
INFO - 2022-01-19 05:50:20 --> Config Class Initialized
INFO - 2022-01-19 05:50:20 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:50:20 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:50:20 --> Utf8 Class Initialized
INFO - 2022-01-19 05:50:20 --> URI Class Initialized
INFO - 2022-01-19 05:50:20 --> Router Class Initialized
INFO - 2022-01-19 05:50:20 --> Output Class Initialized
INFO - 2022-01-19 05:50:20 --> Security Class Initialized
DEBUG - 2022-01-19 05:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:50:20 --> Input Class Initialized
INFO - 2022-01-19 05:50:20 --> Language Class Initialized
INFO - 2022-01-19 05:50:20 --> Language Class Initialized
INFO - 2022-01-19 05:50:20 --> Config Class Initialized
INFO - 2022-01-19 05:50:20 --> Loader Class Initialized
INFO - 2022-01-19 05:50:20 --> Helper loaded: url_helper
INFO - 2022-01-19 05:50:20 --> Helper loaded: file_helper
INFO - 2022-01-19 05:50:20 --> Helper loaded: form_helper
INFO - 2022-01-19 05:50:20 --> Helper loaded: my_helper
INFO - 2022-01-19 05:50:20 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:50:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:50:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:50:20 --> Controller Class Initialized
DEBUG - 2022-01-19 05:50:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-01-19 05:50:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-19 05:50:20 --> Final output sent to browser
DEBUG - 2022-01-19 05:50:20 --> Total execution time: 0.2680
INFO - 2022-01-19 05:50:22 --> Config Class Initialized
INFO - 2022-01-19 05:50:22 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:50:22 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:50:22 --> Utf8 Class Initialized
INFO - 2022-01-19 05:50:22 --> URI Class Initialized
INFO - 2022-01-19 05:50:22 --> Router Class Initialized
INFO - 2022-01-19 05:50:22 --> Output Class Initialized
INFO - 2022-01-19 05:50:22 --> Security Class Initialized
DEBUG - 2022-01-19 05:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:50:22 --> Input Class Initialized
INFO - 2022-01-19 05:50:22 --> Language Class Initialized
INFO - 2022-01-19 05:50:22 --> Language Class Initialized
INFO - 2022-01-19 05:50:22 --> Config Class Initialized
INFO - 2022-01-19 05:50:22 --> Loader Class Initialized
INFO - 2022-01-19 05:50:22 --> Helper loaded: url_helper
INFO - 2022-01-19 05:50:22 --> Helper loaded: file_helper
INFO - 2022-01-19 05:50:22 --> Helper loaded: form_helper
INFO - 2022-01-19 05:50:22 --> Helper loaded: my_helper
INFO - 2022-01-19 05:50:22 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:50:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:50:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:50:22 --> Controller Class Initialized
DEBUG - 2022-01-19 05:50:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-01-19 05:50:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-19 05:50:22 --> Final output sent to browser
DEBUG - 2022-01-19 05:50:22 --> Total execution time: 0.0540
INFO - 2022-01-19 05:50:55 --> Config Class Initialized
INFO - 2022-01-19 05:50:55 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:50:55 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:50:55 --> Utf8 Class Initialized
INFO - 2022-01-19 05:50:55 --> URI Class Initialized
INFO - 2022-01-19 05:50:55 --> Router Class Initialized
INFO - 2022-01-19 05:50:55 --> Output Class Initialized
INFO - 2022-01-19 05:50:55 --> Security Class Initialized
DEBUG - 2022-01-19 05:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:50:55 --> Input Class Initialized
INFO - 2022-01-19 05:50:55 --> Language Class Initialized
INFO - 2022-01-19 05:50:55 --> Language Class Initialized
INFO - 2022-01-19 05:50:55 --> Config Class Initialized
INFO - 2022-01-19 05:50:55 --> Loader Class Initialized
INFO - 2022-01-19 05:50:55 --> Helper loaded: url_helper
INFO - 2022-01-19 05:50:55 --> Helper loaded: file_helper
INFO - 2022-01-19 05:50:55 --> Helper loaded: form_helper
INFO - 2022-01-19 05:50:55 --> Helper loaded: my_helper
INFO - 2022-01-19 05:50:55 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:50:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:50:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:50:55 --> Controller Class Initialized
DEBUG - 2022-01-19 05:50:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-01-19 05:50:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-19 05:50:55 --> Final output sent to browser
DEBUG - 2022-01-19 05:50:55 --> Total execution time: 0.0610
INFO - 2022-01-19 05:50:55 --> Config Class Initialized
INFO - 2022-01-19 05:50:55 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:50:55 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:50:55 --> Utf8 Class Initialized
INFO - 2022-01-19 05:50:55 --> URI Class Initialized
INFO - 2022-01-19 05:50:55 --> Router Class Initialized
INFO - 2022-01-19 05:50:55 --> Output Class Initialized
INFO - 2022-01-19 05:50:55 --> Security Class Initialized
DEBUG - 2022-01-19 05:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:50:55 --> Input Class Initialized
INFO - 2022-01-19 05:50:55 --> Language Class Initialized
INFO - 2022-01-19 05:50:55 --> Language Class Initialized
INFO - 2022-01-19 05:50:55 --> Config Class Initialized
INFO - 2022-01-19 05:50:55 --> Loader Class Initialized
INFO - 2022-01-19 05:50:55 --> Helper loaded: url_helper
INFO - 2022-01-19 05:50:55 --> Helper loaded: file_helper
INFO - 2022-01-19 05:50:55 --> Helper loaded: form_helper
INFO - 2022-01-19 05:50:55 --> Helper loaded: my_helper
INFO - 2022-01-19 05:50:55 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:50:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:50:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:50:55 --> Controller Class Initialized
INFO - 2022-01-19 05:50:56 --> Config Class Initialized
INFO - 2022-01-19 05:50:56 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:50:56 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:50:56 --> Utf8 Class Initialized
INFO - 2022-01-19 05:50:56 --> URI Class Initialized
INFO - 2022-01-19 05:50:56 --> Router Class Initialized
INFO - 2022-01-19 05:50:56 --> Output Class Initialized
INFO - 2022-01-19 05:50:56 --> Security Class Initialized
DEBUG - 2022-01-19 05:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:50:56 --> Input Class Initialized
INFO - 2022-01-19 05:50:56 --> Language Class Initialized
INFO - 2022-01-19 05:50:56 --> Language Class Initialized
INFO - 2022-01-19 05:50:56 --> Config Class Initialized
INFO - 2022-01-19 05:50:56 --> Loader Class Initialized
INFO - 2022-01-19 05:50:56 --> Helper loaded: url_helper
INFO - 2022-01-19 05:50:56 --> Helper loaded: file_helper
INFO - 2022-01-19 05:50:56 --> Helper loaded: form_helper
INFO - 2022-01-19 05:50:56 --> Helper loaded: my_helper
INFO - 2022-01-19 05:50:56 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:50:56 --> Controller Class Initialized
DEBUG - 2022-01-19 05:50:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-01-19 05:50:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-19 05:50:56 --> Final output sent to browser
DEBUG - 2022-01-19 05:50:56 --> Total execution time: 0.0510
INFO - 2022-01-19 05:50:58 --> Config Class Initialized
INFO - 2022-01-19 05:50:58 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:50:58 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:50:58 --> Utf8 Class Initialized
INFO - 2022-01-19 05:50:58 --> URI Class Initialized
INFO - 2022-01-19 05:50:58 --> Router Class Initialized
INFO - 2022-01-19 05:50:58 --> Output Class Initialized
INFO - 2022-01-19 05:50:58 --> Security Class Initialized
DEBUG - 2022-01-19 05:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:50:58 --> Input Class Initialized
INFO - 2022-01-19 05:50:58 --> Language Class Initialized
INFO - 2022-01-19 05:50:58 --> Language Class Initialized
INFO - 2022-01-19 05:50:58 --> Config Class Initialized
INFO - 2022-01-19 05:50:58 --> Loader Class Initialized
INFO - 2022-01-19 05:50:58 --> Helper loaded: url_helper
INFO - 2022-01-19 05:50:58 --> Helper loaded: file_helper
INFO - 2022-01-19 05:50:58 --> Helper loaded: form_helper
INFO - 2022-01-19 05:50:58 --> Helper loaded: my_helper
INFO - 2022-01-19 05:50:58 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:50:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:50:58 --> Controller Class Initialized
INFO - 2022-01-19 05:50:59 --> Config Class Initialized
INFO - 2022-01-19 05:50:59 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:50:59 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:50:59 --> Utf8 Class Initialized
INFO - 2022-01-19 05:50:59 --> URI Class Initialized
INFO - 2022-01-19 05:50:59 --> Router Class Initialized
INFO - 2022-01-19 05:50:59 --> Output Class Initialized
INFO - 2022-01-19 05:50:59 --> Security Class Initialized
DEBUG - 2022-01-19 05:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:50:59 --> Input Class Initialized
INFO - 2022-01-19 05:50:59 --> Language Class Initialized
INFO - 2022-01-19 05:50:59 --> Language Class Initialized
INFO - 2022-01-19 05:50:59 --> Config Class Initialized
INFO - 2022-01-19 05:50:59 --> Loader Class Initialized
INFO - 2022-01-19 05:50:59 --> Helper loaded: url_helper
INFO - 2022-01-19 05:50:59 --> Helper loaded: file_helper
INFO - 2022-01-19 05:50:59 --> Helper loaded: form_helper
INFO - 2022-01-19 05:50:59 --> Helper loaded: my_helper
INFO - 2022-01-19 05:50:59 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:50:59 --> Controller Class Initialized
INFO - 2022-01-19 05:51:16 --> Config Class Initialized
INFO - 2022-01-19 05:51:16 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:51:16 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:51:16 --> Utf8 Class Initialized
INFO - 2022-01-19 05:51:16 --> URI Class Initialized
INFO - 2022-01-19 05:51:16 --> Router Class Initialized
INFO - 2022-01-19 05:51:16 --> Output Class Initialized
INFO - 2022-01-19 05:51:16 --> Security Class Initialized
DEBUG - 2022-01-19 05:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:51:16 --> Input Class Initialized
INFO - 2022-01-19 05:51:16 --> Language Class Initialized
INFO - 2022-01-19 05:51:16 --> Language Class Initialized
INFO - 2022-01-19 05:51:16 --> Config Class Initialized
INFO - 2022-01-19 05:51:16 --> Loader Class Initialized
INFO - 2022-01-19 05:51:16 --> Helper loaded: url_helper
INFO - 2022-01-19 05:51:16 --> Helper loaded: file_helper
INFO - 2022-01-19 05:51:16 --> Helper loaded: form_helper
INFO - 2022-01-19 05:51:16 --> Helper loaded: my_helper
INFO - 2022-01-19 05:51:17 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:51:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:51:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:51:17 --> Controller Class Initialized
DEBUG - 2022-01-19 05:51:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-01-19 05:51:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-19 05:51:17 --> Final output sent to browser
DEBUG - 2022-01-19 05:51:17 --> Total execution time: 0.0520
INFO - 2022-01-19 05:51:17 --> Config Class Initialized
INFO - 2022-01-19 05:51:17 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:51:17 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:51:17 --> Utf8 Class Initialized
INFO - 2022-01-19 05:51:17 --> URI Class Initialized
INFO - 2022-01-19 05:51:17 --> Router Class Initialized
INFO - 2022-01-19 05:51:17 --> Output Class Initialized
INFO - 2022-01-19 05:51:17 --> Security Class Initialized
DEBUG - 2022-01-19 05:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:51:17 --> Input Class Initialized
INFO - 2022-01-19 05:51:17 --> Language Class Initialized
INFO - 2022-01-19 05:51:17 --> Language Class Initialized
INFO - 2022-01-19 05:51:17 --> Config Class Initialized
INFO - 2022-01-19 05:51:17 --> Loader Class Initialized
INFO - 2022-01-19 05:51:17 --> Helper loaded: url_helper
INFO - 2022-01-19 05:51:17 --> Helper loaded: file_helper
INFO - 2022-01-19 05:51:17 --> Helper loaded: form_helper
INFO - 2022-01-19 05:51:17 --> Helper loaded: my_helper
INFO - 2022-01-19 05:51:17 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:51:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:51:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:51:17 --> Controller Class Initialized
INFO - 2022-01-19 05:51:18 --> Config Class Initialized
INFO - 2022-01-19 05:51:18 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:51:18 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:51:18 --> Utf8 Class Initialized
INFO - 2022-01-19 05:51:18 --> URI Class Initialized
INFO - 2022-01-19 05:51:18 --> Router Class Initialized
INFO - 2022-01-19 05:51:18 --> Output Class Initialized
INFO - 2022-01-19 05:51:18 --> Security Class Initialized
DEBUG - 2022-01-19 05:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:51:18 --> Input Class Initialized
INFO - 2022-01-19 05:51:18 --> Language Class Initialized
INFO - 2022-01-19 05:51:18 --> Language Class Initialized
INFO - 2022-01-19 05:51:18 --> Config Class Initialized
INFO - 2022-01-19 05:51:18 --> Loader Class Initialized
INFO - 2022-01-19 05:51:18 --> Helper loaded: url_helper
INFO - 2022-01-19 05:51:18 --> Helper loaded: file_helper
INFO - 2022-01-19 05:51:18 --> Helper loaded: form_helper
INFO - 2022-01-19 05:51:18 --> Helper loaded: my_helper
INFO - 2022-01-19 05:51:18 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:51:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:51:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:51:18 --> Controller Class Initialized
DEBUG - 2022-01-19 05:51:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-01-19 05:51:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-19 05:51:18 --> Final output sent to browser
DEBUG - 2022-01-19 05:51:18 --> Total execution time: 0.0400
INFO - 2022-01-19 05:51:22 --> Config Class Initialized
INFO - 2022-01-19 05:51:22 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:51:22 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:51:22 --> Utf8 Class Initialized
INFO - 2022-01-19 05:51:22 --> URI Class Initialized
INFO - 2022-01-19 05:51:22 --> Router Class Initialized
INFO - 2022-01-19 05:51:22 --> Output Class Initialized
INFO - 2022-01-19 05:51:22 --> Security Class Initialized
DEBUG - 2022-01-19 05:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:51:22 --> Input Class Initialized
INFO - 2022-01-19 05:51:22 --> Language Class Initialized
INFO - 2022-01-19 05:51:22 --> Language Class Initialized
INFO - 2022-01-19 05:51:22 --> Config Class Initialized
INFO - 2022-01-19 05:51:22 --> Loader Class Initialized
INFO - 2022-01-19 05:51:22 --> Helper loaded: url_helper
INFO - 2022-01-19 05:51:22 --> Helper loaded: file_helper
INFO - 2022-01-19 05:51:22 --> Helper loaded: form_helper
INFO - 2022-01-19 05:51:22 --> Helper loaded: my_helper
INFO - 2022-01-19 05:51:22 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:51:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:51:22 --> Controller Class Initialized
INFO - 2022-01-19 05:51:24 --> Config Class Initialized
INFO - 2022-01-19 05:51:24 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:51:24 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:51:24 --> Utf8 Class Initialized
INFO - 2022-01-19 05:51:24 --> URI Class Initialized
INFO - 2022-01-19 05:51:24 --> Router Class Initialized
INFO - 2022-01-19 05:51:24 --> Output Class Initialized
INFO - 2022-01-19 05:51:24 --> Security Class Initialized
DEBUG - 2022-01-19 05:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:51:24 --> Input Class Initialized
INFO - 2022-01-19 05:51:24 --> Language Class Initialized
INFO - 2022-01-19 05:51:24 --> Language Class Initialized
INFO - 2022-01-19 05:51:24 --> Config Class Initialized
INFO - 2022-01-19 05:51:24 --> Loader Class Initialized
INFO - 2022-01-19 05:51:24 --> Helper loaded: url_helper
INFO - 2022-01-19 05:51:24 --> Helper loaded: file_helper
INFO - 2022-01-19 05:51:24 --> Helper loaded: form_helper
INFO - 2022-01-19 05:51:24 --> Helper loaded: my_helper
INFO - 2022-01-19 05:51:24 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:51:24 --> Controller Class Initialized
INFO - 2022-01-19 05:52:52 --> Config Class Initialized
INFO - 2022-01-19 05:52:52 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:52:52 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:52:52 --> Utf8 Class Initialized
INFO - 2022-01-19 05:52:52 --> URI Class Initialized
INFO - 2022-01-19 05:52:52 --> Router Class Initialized
INFO - 2022-01-19 05:52:52 --> Output Class Initialized
INFO - 2022-01-19 05:52:52 --> Security Class Initialized
DEBUG - 2022-01-19 05:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:52:52 --> Input Class Initialized
INFO - 2022-01-19 05:52:52 --> Language Class Initialized
INFO - 2022-01-19 05:52:52 --> Language Class Initialized
INFO - 2022-01-19 05:52:52 --> Config Class Initialized
INFO - 2022-01-19 05:52:52 --> Loader Class Initialized
INFO - 2022-01-19 05:52:52 --> Helper loaded: url_helper
INFO - 2022-01-19 05:52:52 --> Helper loaded: file_helper
INFO - 2022-01-19 05:52:52 --> Helper loaded: form_helper
INFO - 2022-01-19 05:52:52 --> Helper loaded: my_helper
INFO - 2022-01-19 05:52:52 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:52:52 --> Controller Class Initialized
DEBUG - 2022-01-19 05:52:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2022-01-19 05:52:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-19 05:52:52 --> Final output sent to browser
DEBUG - 2022-01-19 05:52:52 --> Total execution time: 0.0490
INFO - 2022-01-19 05:52:57 --> Config Class Initialized
INFO - 2022-01-19 05:52:57 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:52:57 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:52:57 --> Utf8 Class Initialized
INFO - 2022-01-19 05:52:57 --> URI Class Initialized
INFO - 2022-01-19 05:52:57 --> Router Class Initialized
INFO - 2022-01-19 05:52:57 --> Output Class Initialized
INFO - 2022-01-19 05:52:57 --> Security Class Initialized
DEBUG - 2022-01-19 05:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:52:57 --> Input Class Initialized
INFO - 2022-01-19 05:52:57 --> Language Class Initialized
INFO - 2022-01-19 05:52:57 --> Language Class Initialized
INFO - 2022-01-19 05:52:57 --> Config Class Initialized
INFO - 2022-01-19 05:52:57 --> Loader Class Initialized
INFO - 2022-01-19 05:52:57 --> Helper loaded: url_helper
INFO - 2022-01-19 05:52:57 --> Helper loaded: file_helper
INFO - 2022-01-19 05:52:57 --> Helper loaded: form_helper
INFO - 2022-01-19 05:52:57 --> Helper loaded: my_helper
INFO - 2022-01-19 05:52:57 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:52:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:52:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:52:57 --> Controller Class Initialized
INFO - 2022-01-19 05:52:58 --> Config Class Initialized
INFO - 2022-01-19 05:52:58 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:52:58 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:52:58 --> Utf8 Class Initialized
INFO - 2022-01-19 05:52:58 --> URI Class Initialized
INFO - 2022-01-19 05:52:58 --> Router Class Initialized
INFO - 2022-01-19 05:52:58 --> Output Class Initialized
INFO - 2022-01-19 05:52:58 --> Security Class Initialized
DEBUG - 2022-01-19 05:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:52:58 --> Input Class Initialized
INFO - 2022-01-19 05:52:58 --> Language Class Initialized
INFO - 2022-01-19 05:52:58 --> Language Class Initialized
INFO - 2022-01-19 05:52:58 --> Config Class Initialized
INFO - 2022-01-19 05:52:58 --> Loader Class Initialized
INFO - 2022-01-19 05:52:58 --> Helper loaded: url_helper
INFO - 2022-01-19 05:52:58 --> Helper loaded: file_helper
INFO - 2022-01-19 05:52:58 --> Helper loaded: form_helper
INFO - 2022-01-19 05:52:58 --> Helper loaded: my_helper
INFO - 2022-01-19 05:52:58 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:52:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:52:58 --> Controller Class Initialized
DEBUG - 2022-01-19 05:52:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-01-19 05:52:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-19 05:52:58 --> Final output sent to browser
DEBUG - 2022-01-19 05:52:58 --> Total execution time: 0.0370
INFO - 2022-01-19 05:52:58 --> Config Class Initialized
INFO - 2022-01-19 05:52:58 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:52:58 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:52:58 --> Utf8 Class Initialized
INFO - 2022-01-19 05:52:58 --> URI Class Initialized
INFO - 2022-01-19 05:52:58 --> Router Class Initialized
INFO - 2022-01-19 05:52:58 --> Output Class Initialized
INFO - 2022-01-19 05:52:58 --> Security Class Initialized
DEBUG - 2022-01-19 05:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:52:58 --> Input Class Initialized
INFO - 2022-01-19 05:52:58 --> Language Class Initialized
INFO - 2022-01-19 05:52:58 --> Language Class Initialized
INFO - 2022-01-19 05:52:58 --> Config Class Initialized
INFO - 2022-01-19 05:52:58 --> Loader Class Initialized
INFO - 2022-01-19 05:52:58 --> Helper loaded: url_helper
INFO - 2022-01-19 05:52:58 --> Helper loaded: file_helper
INFO - 2022-01-19 05:52:58 --> Helper loaded: form_helper
INFO - 2022-01-19 05:52:58 --> Helper loaded: my_helper
INFO - 2022-01-19 05:52:58 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:52:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:52:58 --> Controller Class Initialized
INFO - 2022-01-19 05:53:00 --> Config Class Initialized
INFO - 2022-01-19 05:53:00 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:53:00 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:53:00 --> Utf8 Class Initialized
INFO - 2022-01-19 05:53:00 --> URI Class Initialized
INFO - 2022-01-19 05:53:00 --> Router Class Initialized
INFO - 2022-01-19 05:53:00 --> Output Class Initialized
INFO - 2022-01-19 05:53:00 --> Security Class Initialized
DEBUG - 2022-01-19 05:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:53:00 --> Input Class Initialized
INFO - 2022-01-19 05:53:00 --> Language Class Initialized
INFO - 2022-01-19 05:53:01 --> Language Class Initialized
INFO - 2022-01-19 05:53:01 --> Config Class Initialized
INFO - 2022-01-19 05:53:01 --> Loader Class Initialized
INFO - 2022-01-19 05:53:01 --> Helper loaded: url_helper
INFO - 2022-01-19 05:53:01 --> Helper loaded: file_helper
INFO - 2022-01-19 05:53:01 --> Helper loaded: form_helper
INFO - 2022-01-19 05:53:01 --> Helper loaded: my_helper
INFO - 2022-01-19 05:53:01 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:53:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:53:01 --> Controller Class Initialized
DEBUG - 2022-01-19 05:53:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2022-01-19 05:53:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-19 05:53:01 --> Final output sent to browser
DEBUG - 2022-01-19 05:53:01 --> Total execution time: 0.0490
INFO - 2022-01-19 05:53:04 --> Config Class Initialized
INFO - 2022-01-19 05:53:04 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:53:04 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:53:04 --> Utf8 Class Initialized
INFO - 2022-01-19 05:53:04 --> URI Class Initialized
INFO - 2022-01-19 05:53:04 --> Router Class Initialized
INFO - 2022-01-19 05:53:04 --> Output Class Initialized
INFO - 2022-01-19 05:53:04 --> Security Class Initialized
DEBUG - 2022-01-19 05:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:53:04 --> Input Class Initialized
INFO - 2022-01-19 05:53:04 --> Language Class Initialized
INFO - 2022-01-19 05:53:04 --> Language Class Initialized
INFO - 2022-01-19 05:53:04 --> Config Class Initialized
INFO - 2022-01-19 05:53:04 --> Loader Class Initialized
INFO - 2022-01-19 05:53:04 --> Helper loaded: url_helper
INFO - 2022-01-19 05:53:04 --> Helper loaded: file_helper
INFO - 2022-01-19 05:53:04 --> Helper loaded: form_helper
INFO - 2022-01-19 05:53:04 --> Helper loaded: my_helper
INFO - 2022-01-19 05:53:04 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:53:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:53:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:53:04 --> Controller Class Initialized
INFO - 2022-01-19 05:53:04 --> Config Class Initialized
INFO - 2022-01-19 05:53:04 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:53:04 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:53:04 --> Utf8 Class Initialized
INFO - 2022-01-19 05:53:04 --> URI Class Initialized
INFO - 2022-01-19 05:53:04 --> Router Class Initialized
INFO - 2022-01-19 05:53:04 --> Output Class Initialized
INFO - 2022-01-19 05:53:04 --> Security Class Initialized
DEBUG - 2022-01-19 05:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:53:04 --> Input Class Initialized
INFO - 2022-01-19 05:53:04 --> Language Class Initialized
INFO - 2022-01-19 05:53:04 --> Language Class Initialized
INFO - 2022-01-19 05:53:04 --> Config Class Initialized
INFO - 2022-01-19 05:53:04 --> Loader Class Initialized
INFO - 2022-01-19 05:53:04 --> Helper loaded: url_helper
INFO - 2022-01-19 05:53:04 --> Helper loaded: file_helper
INFO - 2022-01-19 05:53:04 --> Helper loaded: form_helper
INFO - 2022-01-19 05:53:04 --> Helper loaded: my_helper
INFO - 2022-01-19 05:53:04 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:53:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:53:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:53:04 --> Controller Class Initialized
DEBUG - 2022-01-19 05:53:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-01-19 05:53:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-19 05:53:04 --> Final output sent to browser
DEBUG - 2022-01-19 05:53:04 --> Total execution time: 0.0380
INFO - 2022-01-19 05:53:08 --> Config Class Initialized
INFO - 2022-01-19 05:53:08 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:53:08 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:53:08 --> Utf8 Class Initialized
INFO - 2022-01-19 05:53:08 --> URI Class Initialized
INFO - 2022-01-19 05:53:08 --> Router Class Initialized
INFO - 2022-01-19 05:53:08 --> Output Class Initialized
INFO - 2022-01-19 05:53:08 --> Security Class Initialized
DEBUG - 2022-01-19 05:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:53:08 --> Input Class Initialized
INFO - 2022-01-19 05:53:08 --> Language Class Initialized
INFO - 2022-01-19 05:53:08 --> Language Class Initialized
INFO - 2022-01-19 05:53:08 --> Config Class Initialized
INFO - 2022-01-19 05:53:08 --> Loader Class Initialized
INFO - 2022-01-19 05:53:08 --> Helper loaded: url_helper
INFO - 2022-01-19 05:53:08 --> Helper loaded: file_helper
INFO - 2022-01-19 05:53:08 --> Helper loaded: form_helper
INFO - 2022-01-19 05:53:08 --> Helper loaded: my_helper
INFO - 2022-01-19 05:53:08 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:53:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:53:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:53:08 --> Controller Class Initialized
INFO - 2022-01-19 05:53:08 --> Helper loaded: cookie_helper
INFO - 2022-01-19 05:53:08 --> Config Class Initialized
INFO - 2022-01-19 05:53:08 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:53:08 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:53:08 --> Utf8 Class Initialized
INFO - 2022-01-19 05:53:08 --> URI Class Initialized
INFO - 2022-01-19 05:53:08 --> Router Class Initialized
INFO - 2022-01-19 05:53:08 --> Output Class Initialized
INFO - 2022-01-19 05:53:08 --> Security Class Initialized
DEBUG - 2022-01-19 05:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:53:08 --> Input Class Initialized
INFO - 2022-01-19 05:53:08 --> Language Class Initialized
INFO - 2022-01-19 05:53:08 --> Language Class Initialized
INFO - 2022-01-19 05:53:08 --> Config Class Initialized
INFO - 2022-01-19 05:53:08 --> Loader Class Initialized
INFO - 2022-01-19 05:53:08 --> Helper loaded: url_helper
INFO - 2022-01-19 05:53:08 --> Helper loaded: file_helper
INFO - 2022-01-19 05:53:08 --> Helper loaded: form_helper
INFO - 2022-01-19 05:53:08 --> Helper loaded: my_helper
INFO - 2022-01-19 05:53:08 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:53:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:53:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:53:08 --> Controller Class Initialized
DEBUG - 2022-01-19 05:53:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-01-19 05:53:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-19 05:53:08 --> Final output sent to browser
DEBUG - 2022-01-19 05:53:08 --> Total execution time: 0.0350
INFO - 2022-01-19 05:53:12 --> Config Class Initialized
INFO - 2022-01-19 05:53:12 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:53:12 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:53:12 --> Utf8 Class Initialized
INFO - 2022-01-19 05:53:12 --> URI Class Initialized
INFO - 2022-01-19 05:53:12 --> Router Class Initialized
INFO - 2022-01-19 05:53:12 --> Output Class Initialized
INFO - 2022-01-19 05:53:12 --> Security Class Initialized
DEBUG - 2022-01-19 05:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:53:12 --> Input Class Initialized
INFO - 2022-01-19 05:53:12 --> Language Class Initialized
INFO - 2022-01-19 05:53:12 --> Language Class Initialized
INFO - 2022-01-19 05:53:12 --> Config Class Initialized
INFO - 2022-01-19 05:53:12 --> Loader Class Initialized
INFO - 2022-01-19 05:53:12 --> Helper loaded: url_helper
INFO - 2022-01-19 05:53:12 --> Helper loaded: file_helper
INFO - 2022-01-19 05:53:12 --> Helper loaded: form_helper
INFO - 2022-01-19 05:53:12 --> Helper loaded: my_helper
INFO - 2022-01-19 05:53:12 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:53:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:53:12 --> Controller Class Initialized
INFO - 2022-01-19 05:53:12 --> Helper loaded: cookie_helper
INFO - 2022-01-19 05:53:12 --> Final output sent to browser
DEBUG - 2022-01-19 05:53:12 --> Total execution time: 0.0510
INFO - 2022-01-19 05:53:12 --> Config Class Initialized
INFO - 2022-01-19 05:53:12 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:53:12 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:53:12 --> Utf8 Class Initialized
INFO - 2022-01-19 05:53:12 --> URI Class Initialized
INFO - 2022-01-19 05:53:12 --> Router Class Initialized
INFO - 2022-01-19 05:53:12 --> Output Class Initialized
INFO - 2022-01-19 05:53:12 --> Security Class Initialized
DEBUG - 2022-01-19 05:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:53:12 --> Input Class Initialized
INFO - 2022-01-19 05:53:12 --> Language Class Initialized
INFO - 2022-01-19 05:53:12 --> Language Class Initialized
INFO - 2022-01-19 05:53:12 --> Config Class Initialized
INFO - 2022-01-19 05:53:12 --> Loader Class Initialized
INFO - 2022-01-19 05:53:12 --> Helper loaded: url_helper
INFO - 2022-01-19 05:53:12 --> Helper loaded: file_helper
INFO - 2022-01-19 05:53:12 --> Helper loaded: form_helper
INFO - 2022-01-19 05:53:12 --> Helper loaded: my_helper
INFO - 2022-01-19 05:53:12 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:53:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:53:12 --> Controller Class Initialized
DEBUG - 2022-01-19 05:53:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-01-19 05:53:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-19 05:53:12 --> Final output sent to browser
DEBUG - 2022-01-19 05:53:12 --> Total execution time: 0.2950
INFO - 2022-01-19 05:53:16 --> Config Class Initialized
INFO - 2022-01-19 05:53:16 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:53:16 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:53:16 --> Utf8 Class Initialized
INFO - 2022-01-19 05:53:16 --> URI Class Initialized
INFO - 2022-01-19 05:53:16 --> Router Class Initialized
INFO - 2022-01-19 05:53:16 --> Output Class Initialized
INFO - 2022-01-19 05:53:16 --> Security Class Initialized
DEBUG - 2022-01-19 05:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:53:16 --> Input Class Initialized
INFO - 2022-01-19 05:53:16 --> Language Class Initialized
INFO - 2022-01-19 05:53:16 --> Language Class Initialized
INFO - 2022-01-19 05:53:16 --> Config Class Initialized
INFO - 2022-01-19 05:53:16 --> Loader Class Initialized
INFO - 2022-01-19 05:53:16 --> Helper loaded: url_helper
INFO - 2022-01-19 05:53:16 --> Helper loaded: file_helper
INFO - 2022-01-19 05:53:16 --> Helper loaded: form_helper
INFO - 2022-01-19 05:53:16 --> Helper loaded: my_helper
INFO - 2022-01-19 05:53:16 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:53:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:53:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:53:16 --> Controller Class Initialized
DEBUG - 2022-01-19 05:53:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2022-01-19 05:53:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-19 05:53:17 --> Final output sent to browser
DEBUG - 2022-01-19 05:53:17 --> Total execution time: 0.0570
INFO - 2022-01-19 05:53:18 --> Config Class Initialized
INFO - 2022-01-19 05:53:18 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:53:18 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:53:18 --> Utf8 Class Initialized
INFO - 2022-01-19 05:53:18 --> URI Class Initialized
INFO - 2022-01-19 05:53:18 --> Router Class Initialized
INFO - 2022-01-19 05:53:18 --> Output Class Initialized
INFO - 2022-01-19 05:53:18 --> Security Class Initialized
DEBUG - 2022-01-19 05:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:53:18 --> Input Class Initialized
INFO - 2022-01-19 05:53:18 --> Language Class Initialized
INFO - 2022-01-19 05:53:18 --> Language Class Initialized
INFO - 2022-01-19 05:53:18 --> Config Class Initialized
INFO - 2022-01-19 05:53:18 --> Loader Class Initialized
INFO - 2022-01-19 05:53:18 --> Helper loaded: url_helper
INFO - 2022-01-19 05:53:18 --> Helper loaded: file_helper
INFO - 2022-01-19 05:53:18 --> Helper loaded: form_helper
INFO - 2022-01-19 05:53:18 --> Helper loaded: my_helper
INFO - 2022-01-19 05:53:18 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:53:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:53:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:53:18 --> Controller Class Initialized
DEBUG - 2022-01-19 05:53:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_mm_xi.php
INFO - 2022-01-19 05:53:18 --> Final output sent to browser
DEBUG - 2022-01-19 05:53:18 --> Total execution time: 0.0890
INFO - 2022-01-19 05:54:28 --> Config Class Initialized
INFO - 2022-01-19 05:54:28 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:54:28 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:54:28 --> Utf8 Class Initialized
INFO - 2022-01-19 05:54:28 --> URI Class Initialized
INFO - 2022-01-19 05:54:28 --> Router Class Initialized
INFO - 2022-01-19 05:54:28 --> Output Class Initialized
INFO - 2022-01-19 05:54:28 --> Security Class Initialized
DEBUG - 2022-01-19 05:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:54:28 --> Input Class Initialized
INFO - 2022-01-19 05:54:28 --> Language Class Initialized
INFO - 2022-01-19 05:54:28 --> Language Class Initialized
INFO - 2022-01-19 05:54:28 --> Config Class Initialized
INFO - 2022-01-19 05:54:28 --> Loader Class Initialized
INFO - 2022-01-19 05:54:28 --> Helper loaded: url_helper
INFO - 2022-01-19 05:54:28 --> Helper loaded: file_helper
INFO - 2022-01-19 05:54:28 --> Helper loaded: form_helper
INFO - 2022-01-19 05:54:28 --> Helper loaded: my_helper
INFO - 2022-01-19 05:54:28 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:54:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:54:28 --> Controller Class Initialized
DEBUG - 2022-01-19 05:54:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-01-19 05:54:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-19 05:54:28 --> Final output sent to browser
DEBUG - 2022-01-19 05:54:28 --> Total execution time: 0.0510
INFO - 2022-01-19 05:54:33 --> Config Class Initialized
INFO - 2022-01-19 05:54:33 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:54:33 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:54:33 --> Utf8 Class Initialized
INFO - 2022-01-19 05:54:33 --> URI Class Initialized
INFO - 2022-01-19 05:54:33 --> Router Class Initialized
INFO - 2022-01-19 05:54:33 --> Output Class Initialized
INFO - 2022-01-19 05:54:33 --> Security Class Initialized
DEBUG - 2022-01-19 05:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:54:33 --> Input Class Initialized
INFO - 2022-01-19 05:54:33 --> Language Class Initialized
INFO - 2022-01-19 05:54:33 --> Language Class Initialized
INFO - 2022-01-19 05:54:33 --> Config Class Initialized
INFO - 2022-01-19 05:54:33 --> Loader Class Initialized
INFO - 2022-01-19 05:54:33 --> Helper loaded: url_helper
INFO - 2022-01-19 05:54:33 --> Helper loaded: file_helper
INFO - 2022-01-19 05:54:33 --> Helper loaded: form_helper
INFO - 2022-01-19 05:54:33 --> Helper loaded: my_helper
INFO - 2022-01-19 05:54:33 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:54:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:54:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:54:33 --> Controller Class Initialized
DEBUG - 2022-01-19 05:54:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2022-01-19 05:54:33 --> Final output sent to browser
DEBUG - 2022-01-19 05:54:33 --> Total execution time: 0.0990
INFO - 2022-01-19 05:54:38 --> Config Class Initialized
INFO - 2022-01-19 05:54:38 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:54:38 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:54:38 --> Utf8 Class Initialized
INFO - 2022-01-19 05:54:38 --> URI Class Initialized
INFO - 2022-01-19 05:54:38 --> Router Class Initialized
INFO - 2022-01-19 05:54:38 --> Output Class Initialized
INFO - 2022-01-19 05:54:38 --> Security Class Initialized
DEBUG - 2022-01-19 05:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:54:38 --> Input Class Initialized
INFO - 2022-01-19 05:54:38 --> Language Class Initialized
INFO - 2022-01-19 05:54:38 --> Language Class Initialized
INFO - 2022-01-19 05:54:38 --> Config Class Initialized
INFO - 2022-01-19 05:54:38 --> Loader Class Initialized
INFO - 2022-01-19 05:54:38 --> Helper loaded: url_helper
INFO - 2022-01-19 05:54:38 --> Helper loaded: file_helper
INFO - 2022-01-19 05:54:38 --> Helper loaded: form_helper
INFO - 2022-01-19 05:54:38 --> Helper loaded: my_helper
INFO - 2022-01-19 05:54:39 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:54:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:54:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:54:39 --> Controller Class Initialized
DEBUG - 2022-01-19 05:54:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2022-01-19 05:54:39 --> Final output sent to browser
DEBUG - 2022-01-19 05:54:39 --> Total execution time: 0.0670
INFO - 2022-01-19 05:54:40 --> Config Class Initialized
INFO - 2022-01-19 05:54:40 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:54:40 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:54:40 --> Utf8 Class Initialized
INFO - 2022-01-19 05:54:40 --> URI Class Initialized
INFO - 2022-01-19 05:54:40 --> Router Class Initialized
INFO - 2022-01-19 05:54:40 --> Output Class Initialized
INFO - 2022-01-19 05:54:40 --> Security Class Initialized
DEBUG - 2022-01-19 05:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:54:40 --> Input Class Initialized
INFO - 2022-01-19 05:54:40 --> Language Class Initialized
INFO - 2022-01-19 05:54:40 --> Language Class Initialized
INFO - 2022-01-19 05:54:40 --> Config Class Initialized
INFO - 2022-01-19 05:54:40 --> Loader Class Initialized
INFO - 2022-01-19 05:54:40 --> Helper loaded: url_helper
INFO - 2022-01-19 05:54:40 --> Helper loaded: file_helper
INFO - 2022-01-19 05:54:40 --> Helper loaded: form_helper
INFO - 2022-01-19 05:54:40 --> Helper loaded: my_helper
INFO - 2022-01-19 05:54:40 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:54:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:54:40 --> Controller Class Initialized
DEBUG - 2022-01-19 05:54:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2022-01-19 05:54:40 --> Final output sent to browser
DEBUG - 2022-01-19 05:54:40 --> Total execution time: 0.0650
INFO - 2022-01-19 05:54:42 --> Config Class Initialized
INFO - 2022-01-19 05:54:42 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:54:42 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:54:42 --> Utf8 Class Initialized
INFO - 2022-01-19 05:54:42 --> URI Class Initialized
INFO - 2022-01-19 05:54:42 --> Router Class Initialized
INFO - 2022-01-19 05:54:42 --> Output Class Initialized
INFO - 2022-01-19 05:54:42 --> Security Class Initialized
DEBUG - 2022-01-19 05:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:54:42 --> Input Class Initialized
INFO - 2022-01-19 05:54:42 --> Language Class Initialized
INFO - 2022-01-19 05:54:42 --> Language Class Initialized
INFO - 2022-01-19 05:54:42 --> Config Class Initialized
INFO - 2022-01-19 05:54:42 --> Loader Class Initialized
INFO - 2022-01-19 05:54:42 --> Helper loaded: url_helper
INFO - 2022-01-19 05:54:42 --> Helper loaded: file_helper
INFO - 2022-01-19 05:54:42 --> Helper loaded: form_helper
INFO - 2022-01-19 05:54:42 --> Helper loaded: my_helper
INFO - 2022-01-19 05:54:42 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:54:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:54:42 --> Controller Class Initialized
DEBUG - 2022-01-19 05:54:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2022-01-19 05:54:42 --> Final output sent to browser
DEBUG - 2022-01-19 05:54:42 --> Total execution time: 0.0660
INFO - 2022-01-19 05:54:44 --> Config Class Initialized
INFO - 2022-01-19 05:54:44 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:54:44 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:54:44 --> Utf8 Class Initialized
INFO - 2022-01-19 05:54:44 --> URI Class Initialized
INFO - 2022-01-19 05:54:44 --> Router Class Initialized
INFO - 2022-01-19 05:54:44 --> Output Class Initialized
INFO - 2022-01-19 05:54:44 --> Security Class Initialized
DEBUG - 2022-01-19 05:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:54:44 --> Input Class Initialized
INFO - 2022-01-19 05:54:44 --> Language Class Initialized
INFO - 2022-01-19 05:54:44 --> Language Class Initialized
INFO - 2022-01-19 05:54:44 --> Config Class Initialized
INFO - 2022-01-19 05:54:44 --> Loader Class Initialized
INFO - 2022-01-19 05:54:44 --> Helper loaded: url_helper
INFO - 2022-01-19 05:54:44 --> Helper loaded: file_helper
INFO - 2022-01-19 05:54:44 --> Helper loaded: form_helper
INFO - 2022-01-19 05:54:44 --> Helper loaded: my_helper
INFO - 2022-01-19 05:54:44 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:54:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:54:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:54:44 --> Controller Class Initialized
DEBUG - 2022-01-19 05:54:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2022-01-19 05:54:44 --> Final output sent to browser
DEBUG - 2022-01-19 05:54:44 --> Total execution time: 0.0560
INFO - 2022-01-19 05:54:46 --> Config Class Initialized
INFO - 2022-01-19 05:54:46 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:54:46 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:54:46 --> Utf8 Class Initialized
INFO - 2022-01-19 05:54:46 --> URI Class Initialized
INFO - 2022-01-19 05:54:46 --> Router Class Initialized
INFO - 2022-01-19 05:54:46 --> Output Class Initialized
INFO - 2022-01-19 05:54:46 --> Security Class Initialized
DEBUG - 2022-01-19 05:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:54:46 --> Input Class Initialized
INFO - 2022-01-19 05:54:46 --> Language Class Initialized
INFO - 2022-01-19 05:54:46 --> Language Class Initialized
INFO - 2022-01-19 05:54:46 --> Config Class Initialized
INFO - 2022-01-19 05:54:46 --> Loader Class Initialized
INFO - 2022-01-19 05:54:46 --> Helper loaded: url_helper
INFO - 2022-01-19 05:54:46 --> Helper loaded: file_helper
INFO - 2022-01-19 05:54:46 --> Helper loaded: form_helper
INFO - 2022-01-19 05:54:46 --> Helper loaded: my_helper
INFO - 2022-01-19 05:54:46 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:54:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:54:46 --> Controller Class Initialized
DEBUG - 2022-01-19 05:54:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2022-01-19 05:54:46 --> Final output sent to browser
DEBUG - 2022-01-19 05:54:46 --> Total execution time: 0.0630
INFO - 2022-01-19 05:54:48 --> Config Class Initialized
INFO - 2022-01-19 05:54:48 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:54:48 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:54:48 --> Utf8 Class Initialized
INFO - 2022-01-19 05:54:48 --> URI Class Initialized
INFO - 2022-01-19 05:54:48 --> Router Class Initialized
INFO - 2022-01-19 05:54:48 --> Output Class Initialized
INFO - 2022-01-19 05:54:48 --> Security Class Initialized
DEBUG - 2022-01-19 05:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:54:48 --> Input Class Initialized
INFO - 2022-01-19 05:54:48 --> Language Class Initialized
INFO - 2022-01-19 05:54:48 --> Language Class Initialized
INFO - 2022-01-19 05:54:48 --> Config Class Initialized
INFO - 2022-01-19 05:54:48 --> Loader Class Initialized
INFO - 2022-01-19 05:54:48 --> Helper loaded: url_helper
INFO - 2022-01-19 05:54:48 --> Helper loaded: file_helper
INFO - 2022-01-19 05:54:48 --> Helper loaded: form_helper
INFO - 2022-01-19 05:54:48 --> Helper loaded: my_helper
INFO - 2022-01-19 05:54:48 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:54:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:54:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:54:48 --> Controller Class Initialized
DEBUG - 2022-01-19 05:54:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2022-01-19 05:54:48 --> Final output sent to browser
DEBUG - 2022-01-19 05:54:48 --> Total execution time: 0.0560
INFO - 2022-01-19 05:54:50 --> Config Class Initialized
INFO - 2022-01-19 05:54:50 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:54:50 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:54:50 --> Utf8 Class Initialized
INFO - 2022-01-19 05:54:50 --> URI Class Initialized
INFO - 2022-01-19 05:54:50 --> Router Class Initialized
INFO - 2022-01-19 05:54:50 --> Output Class Initialized
INFO - 2022-01-19 05:54:50 --> Security Class Initialized
DEBUG - 2022-01-19 05:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:54:50 --> Input Class Initialized
INFO - 2022-01-19 05:54:50 --> Language Class Initialized
INFO - 2022-01-19 05:54:50 --> Language Class Initialized
INFO - 2022-01-19 05:54:50 --> Config Class Initialized
INFO - 2022-01-19 05:54:50 --> Loader Class Initialized
INFO - 2022-01-19 05:54:50 --> Helper loaded: url_helper
INFO - 2022-01-19 05:54:50 --> Helper loaded: file_helper
INFO - 2022-01-19 05:54:50 --> Helper loaded: form_helper
INFO - 2022-01-19 05:54:50 --> Helper loaded: my_helper
INFO - 2022-01-19 05:54:50 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:54:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:54:50 --> Controller Class Initialized
DEBUG - 2022-01-19 05:54:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2022-01-19 05:54:50 --> Final output sent to browser
DEBUG - 2022-01-19 05:54:50 --> Total execution time: 0.0640
INFO - 2022-01-19 05:54:52 --> Config Class Initialized
INFO - 2022-01-19 05:54:52 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:54:52 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:54:52 --> Utf8 Class Initialized
INFO - 2022-01-19 05:54:52 --> URI Class Initialized
INFO - 2022-01-19 05:54:52 --> Router Class Initialized
INFO - 2022-01-19 05:54:52 --> Output Class Initialized
INFO - 2022-01-19 05:54:52 --> Security Class Initialized
DEBUG - 2022-01-19 05:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:54:52 --> Input Class Initialized
INFO - 2022-01-19 05:54:52 --> Language Class Initialized
INFO - 2022-01-19 05:54:52 --> Language Class Initialized
INFO - 2022-01-19 05:54:52 --> Config Class Initialized
INFO - 2022-01-19 05:54:52 --> Loader Class Initialized
INFO - 2022-01-19 05:54:52 --> Helper loaded: url_helper
INFO - 2022-01-19 05:54:52 --> Helper loaded: file_helper
INFO - 2022-01-19 05:54:52 --> Helper loaded: form_helper
INFO - 2022-01-19 05:54:52 --> Helper loaded: my_helper
INFO - 2022-01-19 05:54:52 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:54:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:54:52 --> Controller Class Initialized
DEBUG - 2022-01-19 05:54:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2022-01-19 05:54:52 --> Final output sent to browser
DEBUG - 2022-01-19 05:54:52 --> Total execution time: 0.0680
INFO - 2022-01-19 05:54:54 --> Config Class Initialized
INFO - 2022-01-19 05:54:54 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:54:54 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:54:54 --> Utf8 Class Initialized
INFO - 2022-01-19 05:54:54 --> URI Class Initialized
INFO - 2022-01-19 05:54:54 --> Router Class Initialized
INFO - 2022-01-19 05:54:54 --> Output Class Initialized
INFO - 2022-01-19 05:54:54 --> Security Class Initialized
DEBUG - 2022-01-19 05:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:54:54 --> Input Class Initialized
INFO - 2022-01-19 05:54:54 --> Language Class Initialized
INFO - 2022-01-19 05:54:54 --> Language Class Initialized
INFO - 2022-01-19 05:54:54 --> Config Class Initialized
INFO - 2022-01-19 05:54:54 --> Loader Class Initialized
INFO - 2022-01-19 05:54:54 --> Helper loaded: url_helper
INFO - 2022-01-19 05:54:54 --> Helper loaded: file_helper
INFO - 2022-01-19 05:54:54 --> Helper loaded: form_helper
INFO - 2022-01-19 05:54:54 --> Helper loaded: my_helper
INFO - 2022-01-19 05:54:54 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:54:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:54:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:54:54 --> Controller Class Initialized
DEBUG - 2022-01-19 05:54:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2022-01-19 05:54:54 --> Final output sent to browser
DEBUG - 2022-01-19 05:54:54 --> Total execution time: 0.0610
INFO - 2022-01-19 05:54:56 --> Config Class Initialized
INFO - 2022-01-19 05:54:56 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:54:56 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:54:56 --> Utf8 Class Initialized
INFO - 2022-01-19 05:54:56 --> URI Class Initialized
INFO - 2022-01-19 05:54:56 --> Router Class Initialized
INFO - 2022-01-19 05:54:56 --> Output Class Initialized
INFO - 2022-01-19 05:54:56 --> Security Class Initialized
DEBUG - 2022-01-19 05:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:54:56 --> Input Class Initialized
INFO - 2022-01-19 05:54:56 --> Language Class Initialized
INFO - 2022-01-19 05:54:56 --> Language Class Initialized
INFO - 2022-01-19 05:54:56 --> Config Class Initialized
INFO - 2022-01-19 05:54:56 --> Loader Class Initialized
INFO - 2022-01-19 05:54:56 --> Helper loaded: url_helper
INFO - 2022-01-19 05:54:56 --> Helper loaded: file_helper
INFO - 2022-01-19 05:54:56 --> Helper loaded: form_helper
INFO - 2022-01-19 05:54:56 --> Helper loaded: my_helper
INFO - 2022-01-19 05:54:56 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:54:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:54:56 --> Controller Class Initialized
DEBUG - 2022-01-19 05:54:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2022-01-19 05:54:56 --> Final output sent to browser
DEBUG - 2022-01-19 05:54:56 --> Total execution time: 0.0680
INFO - 2022-01-19 05:54:59 --> Config Class Initialized
INFO - 2022-01-19 05:54:59 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:54:59 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:54:59 --> Utf8 Class Initialized
INFO - 2022-01-19 05:54:59 --> URI Class Initialized
INFO - 2022-01-19 05:54:59 --> Router Class Initialized
INFO - 2022-01-19 05:54:59 --> Output Class Initialized
INFO - 2022-01-19 05:54:59 --> Security Class Initialized
DEBUG - 2022-01-19 05:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:54:59 --> Input Class Initialized
INFO - 2022-01-19 05:54:59 --> Language Class Initialized
INFO - 2022-01-19 05:54:59 --> Language Class Initialized
INFO - 2022-01-19 05:54:59 --> Config Class Initialized
INFO - 2022-01-19 05:54:59 --> Loader Class Initialized
INFO - 2022-01-19 05:54:59 --> Helper loaded: url_helper
INFO - 2022-01-19 05:54:59 --> Helper loaded: file_helper
INFO - 2022-01-19 05:54:59 --> Helper loaded: form_helper
INFO - 2022-01-19 05:54:59 --> Helper loaded: my_helper
INFO - 2022-01-19 05:54:59 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:54:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:54:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:54:59 --> Controller Class Initialized
DEBUG - 2022-01-19 05:54:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2022-01-19 05:54:59 --> Final output sent to browser
DEBUG - 2022-01-19 05:54:59 --> Total execution time: 0.0690
INFO - 2022-01-19 05:55:00 --> Config Class Initialized
INFO - 2022-01-19 05:55:00 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:55:00 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:55:00 --> Utf8 Class Initialized
INFO - 2022-01-19 05:55:00 --> URI Class Initialized
INFO - 2022-01-19 05:55:00 --> Router Class Initialized
INFO - 2022-01-19 05:55:00 --> Output Class Initialized
INFO - 2022-01-19 05:55:00 --> Security Class Initialized
DEBUG - 2022-01-19 05:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:55:00 --> Input Class Initialized
INFO - 2022-01-19 05:55:00 --> Language Class Initialized
INFO - 2022-01-19 05:55:00 --> Language Class Initialized
INFO - 2022-01-19 05:55:00 --> Config Class Initialized
INFO - 2022-01-19 05:55:00 --> Loader Class Initialized
INFO - 2022-01-19 05:55:00 --> Helper loaded: url_helper
INFO - 2022-01-19 05:55:00 --> Helper loaded: file_helper
INFO - 2022-01-19 05:55:00 --> Helper loaded: form_helper
INFO - 2022-01-19 05:55:00 --> Helper loaded: my_helper
INFO - 2022-01-19 05:55:00 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:55:00 --> Controller Class Initialized
DEBUG - 2022-01-19 05:55:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2022-01-19 05:55:00 --> Final output sent to browser
DEBUG - 2022-01-19 05:55:00 --> Total execution time: 0.0720
INFO - 2022-01-19 05:55:03 --> Config Class Initialized
INFO - 2022-01-19 05:55:03 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:55:03 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:55:03 --> Utf8 Class Initialized
INFO - 2022-01-19 05:55:03 --> URI Class Initialized
INFO - 2022-01-19 05:55:03 --> Router Class Initialized
INFO - 2022-01-19 05:55:03 --> Output Class Initialized
INFO - 2022-01-19 05:55:03 --> Security Class Initialized
DEBUG - 2022-01-19 05:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:55:03 --> Input Class Initialized
INFO - 2022-01-19 05:55:03 --> Language Class Initialized
INFO - 2022-01-19 05:55:03 --> Language Class Initialized
INFO - 2022-01-19 05:55:03 --> Config Class Initialized
INFO - 2022-01-19 05:55:03 --> Loader Class Initialized
INFO - 2022-01-19 05:55:03 --> Helper loaded: url_helper
INFO - 2022-01-19 05:55:03 --> Helper loaded: file_helper
INFO - 2022-01-19 05:55:03 --> Helper loaded: form_helper
INFO - 2022-01-19 05:55:03 --> Helper loaded: my_helper
INFO - 2022-01-19 05:55:03 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:55:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:55:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:55:03 --> Controller Class Initialized
DEBUG - 2022-01-19 05:55:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2022-01-19 05:55:04 --> Final output sent to browser
DEBUG - 2022-01-19 05:55:04 --> Total execution time: 0.0570
INFO - 2022-01-19 05:55:06 --> Config Class Initialized
INFO - 2022-01-19 05:55:06 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:55:06 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:55:06 --> Utf8 Class Initialized
INFO - 2022-01-19 05:55:06 --> URI Class Initialized
INFO - 2022-01-19 05:55:06 --> Router Class Initialized
INFO - 2022-01-19 05:55:06 --> Output Class Initialized
INFO - 2022-01-19 05:55:06 --> Security Class Initialized
DEBUG - 2022-01-19 05:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:55:06 --> Input Class Initialized
INFO - 2022-01-19 05:55:06 --> Language Class Initialized
INFO - 2022-01-19 05:55:06 --> Language Class Initialized
INFO - 2022-01-19 05:55:06 --> Config Class Initialized
INFO - 2022-01-19 05:55:06 --> Loader Class Initialized
INFO - 2022-01-19 05:55:06 --> Helper loaded: url_helper
INFO - 2022-01-19 05:55:06 --> Helper loaded: file_helper
INFO - 2022-01-19 05:55:06 --> Helper loaded: form_helper
INFO - 2022-01-19 05:55:06 --> Helper loaded: my_helper
INFO - 2022-01-19 05:55:06 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:55:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:55:06 --> Controller Class Initialized
DEBUG - 2022-01-19 05:55:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2022-01-19 05:55:06 --> Final output sent to browser
DEBUG - 2022-01-19 05:55:06 --> Total execution time: 0.0570
INFO - 2022-01-19 05:55:07 --> Config Class Initialized
INFO - 2022-01-19 05:55:07 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:55:07 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:55:07 --> Utf8 Class Initialized
INFO - 2022-01-19 05:55:07 --> URI Class Initialized
INFO - 2022-01-19 05:55:07 --> Router Class Initialized
INFO - 2022-01-19 05:55:07 --> Output Class Initialized
INFO - 2022-01-19 05:55:07 --> Security Class Initialized
DEBUG - 2022-01-19 05:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:55:07 --> Input Class Initialized
INFO - 2022-01-19 05:55:07 --> Language Class Initialized
INFO - 2022-01-19 05:55:08 --> Language Class Initialized
INFO - 2022-01-19 05:55:08 --> Config Class Initialized
INFO - 2022-01-19 05:55:08 --> Loader Class Initialized
INFO - 2022-01-19 05:55:08 --> Helper loaded: url_helper
INFO - 2022-01-19 05:55:08 --> Helper loaded: file_helper
INFO - 2022-01-19 05:55:08 --> Helper loaded: form_helper
INFO - 2022-01-19 05:55:08 --> Helper loaded: my_helper
INFO - 2022-01-19 05:55:08 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:55:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:55:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:55:08 --> Controller Class Initialized
DEBUG - 2022-01-19 05:55:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2022-01-19 05:55:08 --> Final output sent to browser
DEBUG - 2022-01-19 05:55:08 --> Total execution time: 0.0630
INFO - 2022-01-19 05:57:46 --> Config Class Initialized
INFO - 2022-01-19 05:57:46 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:57:46 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:57:46 --> Utf8 Class Initialized
INFO - 2022-01-19 05:57:46 --> URI Class Initialized
INFO - 2022-01-19 05:57:46 --> Router Class Initialized
INFO - 2022-01-19 05:57:46 --> Output Class Initialized
INFO - 2022-01-19 05:57:46 --> Security Class Initialized
DEBUG - 2022-01-19 05:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:57:46 --> Input Class Initialized
INFO - 2022-01-19 05:57:46 --> Language Class Initialized
INFO - 2022-01-19 05:57:46 --> Language Class Initialized
INFO - 2022-01-19 05:57:46 --> Config Class Initialized
INFO - 2022-01-19 05:57:46 --> Loader Class Initialized
INFO - 2022-01-19 05:57:46 --> Helper loaded: url_helper
INFO - 2022-01-19 05:57:46 --> Helper loaded: file_helper
INFO - 2022-01-19 05:57:46 --> Helper loaded: form_helper
INFO - 2022-01-19 05:57:46 --> Helper loaded: my_helper
INFO - 2022-01-19 05:57:46 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:57:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:57:46 --> Controller Class Initialized
INFO - 2022-01-19 05:57:46 --> Helper loaded: cookie_helper
INFO - 2022-01-19 05:57:46 --> Config Class Initialized
INFO - 2022-01-19 05:57:46 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:57:46 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:57:46 --> Utf8 Class Initialized
INFO - 2022-01-19 05:57:46 --> URI Class Initialized
INFO - 2022-01-19 05:57:46 --> Router Class Initialized
INFO - 2022-01-19 05:57:46 --> Output Class Initialized
INFO - 2022-01-19 05:57:46 --> Security Class Initialized
DEBUG - 2022-01-19 05:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:57:46 --> Input Class Initialized
INFO - 2022-01-19 05:57:46 --> Language Class Initialized
INFO - 2022-01-19 05:57:46 --> Language Class Initialized
INFO - 2022-01-19 05:57:46 --> Config Class Initialized
INFO - 2022-01-19 05:57:46 --> Loader Class Initialized
INFO - 2022-01-19 05:57:46 --> Helper loaded: url_helper
INFO - 2022-01-19 05:57:46 --> Helper loaded: file_helper
INFO - 2022-01-19 05:57:46 --> Helper loaded: form_helper
INFO - 2022-01-19 05:57:46 --> Helper loaded: my_helper
INFO - 2022-01-19 05:57:46 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:57:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:57:46 --> Controller Class Initialized
DEBUG - 2022-01-19 05:57:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-01-19 05:57:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-19 05:57:46 --> Final output sent to browser
DEBUG - 2022-01-19 05:57:46 --> Total execution time: 0.0350
INFO - 2022-01-19 05:57:51 --> Config Class Initialized
INFO - 2022-01-19 05:57:51 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:57:51 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:57:51 --> Utf8 Class Initialized
INFO - 2022-01-19 05:57:51 --> URI Class Initialized
INFO - 2022-01-19 05:57:51 --> Router Class Initialized
INFO - 2022-01-19 05:57:51 --> Output Class Initialized
INFO - 2022-01-19 05:57:51 --> Security Class Initialized
DEBUG - 2022-01-19 05:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:57:51 --> Input Class Initialized
INFO - 2022-01-19 05:57:51 --> Language Class Initialized
INFO - 2022-01-19 05:57:51 --> Language Class Initialized
INFO - 2022-01-19 05:57:51 --> Config Class Initialized
INFO - 2022-01-19 05:57:51 --> Loader Class Initialized
INFO - 2022-01-19 05:57:51 --> Helper loaded: url_helper
INFO - 2022-01-19 05:57:51 --> Helper loaded: file_helper
INFO - 2022-01-19 05:57:51 --> Helper loaded: form_helper
INFO - 2022-01-19 05:57:51 --> Helper loaded: my_helper
INFO - 2022-01-19 05:57:51 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:57:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:57:51 --> Controller Class Initialized
INFO - 2022-01-19 05:57:51 --> Helper loaded: cookie_helper
INFO - 2022-01-19 05:57:51 --> Final output sent to browser
DEBUG - 2022-01-19 05:57:51 --> Total execution time: 0.0510
INFO - 2022-01-19 05:57:52 --> Config Class Initialized
INFO - 2022-01-19 05:57:52 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:57:52 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:57:52 --> Utf8 Class Initialized
INFO - 2022-01-19 05:57:52 --> URI Class Initialized
INFO - 2022-01-19 05:57:52 --> Router Class Initialized
INFO - 2022-01-19 05:57:52 --> Output Class Initialized
INFO - 2022-01-19 05:57:52 --> Security Class Initialized
DEBUG - 2022-01-19 05:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:57:52 --> Input Class Initialized
INFO - 2022-01-19 05:57:52 --> Language Class Initialized
INFO - 2022-01-19 05:57:52 --> Language Class Initialized
INFO - 2022-01-19 05:57:52 --> Config Class Initialized
INFO - 2022-01-19 05:57:52 --> Loader Class Initialized
INFO - 2022-01-19 05:57:52 --> Helper loaded: url_helper
INFO - 2022-01-19 05:57:52 --> Helper loaded: file_helper
INFO - 2022-01-19 05:57:52 --> Helper loaded: form_helper
INFO - 2022-01-19 05:57:52 --> Helper loaded: my_helper
INFO - 2022-01-19 05:57:52 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:57:52 --> Controller Class Initialized
DEBUG - 2022-01-19 05:57:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-01-19 05:57:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-19 05:57:52 --> Final output sent to browser
DEBUG - 2022-01-19 05:57:52 --> Total execution time: 0.3530
INFO - 2022-01-19 05:57:53 --> Config Class Initialized
INFO - 2022-01-19 05:57:53 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:57:53 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:57:53 --> Utf8 Class Initialized
INFO - 2022-01-19 05:57:53 --> URI Class Initialized
INFO - 2022-01-19 05:57:53 --> Router Class Initialized
INFO - 2022-01-19 05:57:53 --> Output Class Initialized
INFO - 2022-01-19 05:57:53 --> Security Class Initialized
DEBUG - 2022-01-19 05:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:57:53 --> Input Class Initialized
INFO - 2022-01-19 05:57:53 --> Language Class Initialized
INFO - 2022-01-19 05:57:53 --> Language Class Initialized
INFO - 2022-01-19 05:57:53 --> Config Class Initialized
INFO - 2022-01-19 05:57:53 --> Loader Class Initialized
INFO - 2022-01-19 05:57:53 --> Helper loaded: url_helper
INFO - 2022-01-19 05:57:53 --> Helper loaded: file_helper
INFO - 2022-01-19 05:57:53 --> Helper loaded: form_helper
INFO - 2022-01-19 05:57:53 --> Helper loaded: my_helper
INFO - 2022-01-19 05:57:53 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:57:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:57:53 --> Controller Class Initialized
DEBUG - 2022-01-19 05:57:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2022-01-19 05:57:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-19 05:57:53 --> Final output sent to browser
DEBUG - 2022-01-19 05:57:53 --> Total execution time: 0.0480
INFO - 2022-01-19 05:57:53 --> Config Class Initialized
INFO - 2022-01-19 05:57:53 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:57:53 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:57:53 --> Utf8 Class Initialized
INFO - 2022-01-19 05:57:53 --> URI Class Initialized
INFO - 2022-01-19 05:57:53 --> Router Class Initialized
INFO - 2022-01-19 05:57:53 --> Output Class Initialized
INFO - 2022-01-19 05:57:53 --> Security Class Initialized
DEBUG - 2022-01-19 05:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:57:53 --> Input Class Initialized
INFO - 2022-01-19 05:57:53 --> Language Class Initialized
INFO - 2022-01-19 05:57:53 --> Language Class Initialized
INFO - 2022-01-19 05:57:53 --> Config Class Initialized
INFO - 2022-01-19 05:57:53 --> Loader Class Initialized
INFO - 2022-01-19 05:57:53 --> Helper loaded: url_helper
INFO - 2022-01-19 05:57:53 --> Helper loaded: file_helper
INFO - 2022-01-19 05:57:53 --> Helper loaded: form_helper
INFO - 2022-01-19 05:57:53 --> Helper loaded: my_helper
INFO - 2022-01-19 05:57:53 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:57:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:57:53 --> Controller Class Initialized
INFO - 2022-01-19 05:57:55 --> Config Class Initialized
INFO - 2022-01-19 05:57:55 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:57:55 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:57:55 --> Utf8 Class Initialized
INFO - 2022-01-19 05:57:55 --> URI Class Initialized
INFO - 2022-01-19 05:57:55 --> Router Class Initialized
INFO - 2022-01-19 05:57:55 --> Output Class Initialized
INFO - 2022-01-19 05:57:55 --> Security Class Initialized
DEBUG - 2022-01-19 05:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:57:55 --> Input Class Initialized
INFO - 2022-01-19 05:57:55 --> Language Class Initialized
INFO - 2022-01-19 05:57:55 --> Language Class Initialized
INFO - 2022-01-19 05:57:55 --> Config Class Initialized
INFO - 2022-01-19 05:57:55 --> Loader Class Initialized
INFO - 2022-01-19 05:57:55 --> Helper loaded: url_helper
INFO - 2022-01-19 05:57:55 --> Helper loaded: file_helper
INFO - 2022-01-19 05:57:55 --> Helper loaded: form_helper
INFO - 2022-01-19 05:57:55 --> Helper loaded: my_helper
INFO - 2022-01-19 05:57:55 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:57:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:57:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:57:55 --> Controller Class Initialized
INFO - 2022-01-19 05:57:55 --> Final output sent to browser
DEBUG - 2022-01-19 05:57:55 --> Total execution time: 0.0560
INFO - 2022-01-19 05:57:55 --> Config Class Initialized
INFO - 2022-01-19 05:57:55 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:57:55 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:57:55 --> Utf8 Class Initialized
INFO - 2022-01-19 05:57:55 --> URI Class Initialized
INFO - 2022-01-19 05:57:55 --> Router Class Initialized
INFO - 2022-01-19 05:57:55 --> Output Class Initialized
INFO - 2022-01-19 05:57:55 --> Security Class Initialized
DEBUG - 2022-01-19 05:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:57:55 --> Input Class Initialized
INFO - 2022-01-19 05:57:55 --> Language Class Initialized
INFO - 2022-01-19 05:57:55 --> Language Class Initialized
INFO - 2022-01-19 05:57:55 --> Config Class Initialized
INFO - 2022-01-19 05:57:55 --> Loader Class Initialized
INFO - 2022-01-19 05:57:55 --> Helper loaded: url_helper
INFO - 2022-01-19 05:57:55 --> Helper loaded: file_helper
INFO - 2022-01-19 05:57:55 --> Helper loaded: form_helper
INFO - 2022-01-19 05:57:55 --> Helper loaded: my_helper
INFO - 2022-01-19 05:57:55 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:57:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:57:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:57:55 --> Controller Class Initialized
INFO - 2022-01-19 05:57:57 --> Config Class Initialized
INFO - 2022-01-19 05:57:57 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:57:57 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:57:57 --> Utf8 Class Initialized
INFO - 2022-01-19 05:57:57 --> URI Class Initialized
INFO - 2022-01-19 05:57:57 --> Router Class Initialized
INFO - 2022-01-19 05:57:57 --> Output Class Initialized
INFO - 2022-01-19 05:57:57 --> Security Class Initialized
DEBUG - 2022-01-19 05:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:57:57 --> Input Class Initialized
INFO - 2022-01-19 05:57:57 --> Language Class Initialized
INFO - 2022-01-19 05:57:57 --> Language Class Initialized
INFO - 2022-01-19 05:57:57 --> Config Class Initialized
INFO - 2022-01-19 05:57:57 --> Loader Class Initialized
INFO - 2022-01-19 05:57:57 --> Helper loaded: url_helper
INFO - 2022-01-19 05:57:57 --> Helper loaded: file_helper
INFO - 2022-01-19 05:57:57 --> Helper loaded: form_helper
INFO - 2022-01-19 05:57:57 --> Helper loaded: my_helper
INFO - 2022-01-19 05:57:57 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:57:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:57:57 --> Controller Class Initialized
INFO - 2022-01-19 05:57:57 --> Helper loaded: cookie_helper
INFO - 2022-01-19 05:57:57 --> Config Class Initialized
INFO - 2022-01-19 05:57:57 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:57:57 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:57:57 --> Utf8 Class Initialized
INFO - 2022-01-19 05:57:57 --> URI Class Initialized
INFO - 2022-01-19 05:57:57 --> Router Class Initialized
INFO - 2022-01-19 05:57:57 --> Output Class Initialized
INFO - 2022-01-19 05:57:57 --> Security Class Initialized
DEBUG - 2022-01-19 05:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:57:57 --> Input Class Initialized
INFO - 2022-01-19 05:57:57 --> Language Class Initialized
INFO - 2022-01-19 05:57:57 --> Language Class Initialized
INFO - 2022-01-19 05:57:57 --> Config Class Initialized
INFO - 2022-01-19 05:57:57 --> Loader Class Initialized
INFO - 2022-01-19 05:57:57 --> Helper loaded: url_helper
INFO - 2022-01-19 05:57:57 --> Helper loaded: file_helper
INFO - 2022-01-19 05:57:57 --> Helper loaded: form_helper
INFO - 2022-01-19 05:57:57 --> Helper loaded: my_helper
INFO - 2022-01-19 05:57:57 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:57:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:57:57 --> Controller Class Initialized
DEBUG - 2022-01-19 05:57:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-01-19 05:57:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-19 05:57:57 --> Final output sent to browser
DEBUG - 2022-01-19 05:57:57 --> Total execution time: 0.0390
INFO - 2022-01-19 05:58:25 --> Config Class Initialized
INFO - 2022-01-19 05:58:25 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:58:25 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:58:25 --> Utf8 Class Initialized
INFO - 2022-01-19 05:58:25 --> URI Class Initialized
INFO - 2022-01-19 05:58:25 --> Router Class Initialized
INFO - 2022-01-19 05:58:25 --> Output Class Initialized
INFO - 2022-01-19 05:58:25 --> Security Class Initialized
DEBUG - 2022-01-19 05:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:58:25 --> Input Class Initialized
INFO - 2022-01-19 05:58:25 --> Language Class Initialized
INFO - 2022-01-19 05:58:25 --> Language Class Initialized
INFO - 2022-01-19 05:58:25 --> Config Class Initialized
INFO - 2022-01-19 05:58:25 --> Loader Class Initialized
INFO - 2022-01-19 05:58:25 --> Helper loaded: url_helper
INFO - 2022-01-19 05:58:25 --> Helper loaded: file_helper
INFO - 2022-01-19 05:58:25 --> Helper loaded: form_helper
INFO - 2022-01-19 05:58:25 --> Helper loaded: my_helper
INFO - 2022-01-19 05:58:25 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:58:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:58:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:58:25 --> Controller Class Initialized
INFO - 2022-01-19 05:58:25 --> Helper loaded: cookie_helper
INFO - 2022-01-19 05:58:25 --> Final output sent to browser
DEBUG - 2022-01-19 05:58:25 --> Total execution time: 0.0520
INFO - 2022-01-19 05:58:25 --> Config Class Initialized
INFO - 2022-01-19 05:58:25 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:58:25 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:58:25 --> Utf8 Class Initialized
INFO - 2022-01-19 05:58:25 --> URI Class Initialized
INFO - 2022-01-19 05:58:25 --> Router Class Initialized
INFO - 2022-01-19 05:58:25 --> Output Class Initialized
INFO - 2022-01-19 05:58:25 --> Security Class Initialized
DEBUG - 2022-01-19 05:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:58:25 --> Input Class Initialized
INFO - 2022-01-19 05:58:25 --> Language Class Initialized
INFO - 2022-01-19 05:58:25 --> Language Class Initialized
INFO - 2022-01-19 05:58:25 --> Config Class Initialized
INFO - 2022-01-19 05:58:25 --> Loader Class Initialized
INFO - 2022-01-19 05:58:25 --> Helper loaded: url_helper
INFO - 2022-01-19 05:58:25 --> Helper loaded: file_helper
INFO - 2022-01-19 05:58:25 --> Helper loaded: form_helper
INFO - 2022-01-19 05:58:25 --> Helper loaded: my_helper
INFO - 2022-01-19 05:58:25 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:58:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:58:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:58:25 --> Controller Class Initialized
DEBUG - 2022-01-19 05:58:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-01-19 05:58:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-19 05:58:25 --> Final output sent to browser
DEBUG - 2022-01-19 05:58:25 --> Total execution time: 0.2670
INFO - 2022-01-19 05:58:41 --> Config Class Initialized
INFO - 2022-01-19 05:58:41 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:58:41 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:58:41 --> Utf8 Class Initialized
INFO - 2022-01-19 05:58:41 --> URI Class Initialized
INFO - 2022-01-19 05:58:41 --> Router Class Initialized
INFO - 2022-01-19 05:58:41 --> Output Class Initialized
INFO - 2022-01-19 05:58:41 --> Security Class Initialized
DEBUG - 2022-01-19 05:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:58:41 --> Input Class Initialized
INFO - 2022-01-19 05:58:41 --> Language Class Initialized
INFO - 2022-01-19 05:58:41 --> Language Class Initialized
INFO - 2022-01-19 05:58:41 --> Config Class Initialized
INFO - 2022-01-19 05:58:41 --> Loader Class Initialized
INFO - 2022-01-19 05:58:41 --> Helper loaded: url_helper
INFO - 2022-01-19 05:58:41 --> Helper loaded: file_helper
INFO - 2022-01-19 05:58:41 --> Helper loaded: form_helper
INFO - 2022-01-19 05:58:41 --> Helper loaded: my_helper
INFO - 2022-01-19 05:58:41 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:58:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:58:41 --> Controller Class Initialized
DEBUG - 2022-01-19 05:58:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-01-19 05:58:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-19 05:58:41 --> Final output sent to browser
DEBUG - 2022-01-19 05:58:41 --> Total execution time: 0.0630
INFO - 2022-01-19 05:58:42 --> Config Class Initialized
INFO - 2022-01-19 05:58:42 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:58:42 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:58:42 --> Utf8 Class Initialized
INFO - 2022-01-19 05:58:42 --> URI Class Initialized
INFO - 2022-01-19 05:58:42 --> Router Class Initialized
INFO - 2022-01-19 05:58:42 --> Output Class Initialized
INFO - 2022-01-19 05:58:42 --> Security Class Initialized
DEBUG - 2022-01-19 05:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:58:42 --> Input Class Initialized
INFO - 2022-01-19 05:58:42 --> Language Class Initialized
INFO - 2022-01-19 05:58:42 --> Language Class Initialized
INFO - 2022-01-19 05:58:42 --> Config Class Initialized
INFO - 2022-01-19 05:58:42 --> Loader Class Initialized
INFO - 2022-01-19 05:58:42 --> Helper loaded: url_helper
INFO - 2022-01-19 05:58:42 --> Helper loaded: file_helper
INFO - 2022-01-19 05:58:42 --> Helper loaded: form_helper
INFO - 2022-01-19 05:58:42 --> Helper loaded: my_helper
INFO - 2022-01-19 05:58:42 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:58:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:58:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:58:42 --> Controller Class Initialized
DEBUG - 2022-01-19 05:58:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2022-01-19 05:58:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-19 05:58:42 --> Final output sent to browser
DEBUG - 2022-01-19 05:58:42 --> Total execution time: 0.0540
INFO - 2022-01-19 05:58:43 --> Config Class Initialized
INFO - 2022-01-19 05:58:43 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:58:43 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:58:43 --> Utf8 Class Initialized
INFO - 2022-01-19 05:58:43 --> URI Class Initialized
INFO - 2022-01-19 05:58:43 --> Router Class Initialized
INFO - 2022-01-19 05:58:43 --> Output Class Initialized
INFO - 2022-01-19 05:58:43 --> Security Class Initialized
DEBUG - 2022-01-19 05:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:58:43 --> Input Class Initialized
INFO - 2022-01-19 05:58:43 --> Language Class Initialized
INFO - 2022-01-19 05:58:43 --> Language Class Initialized
INFO - 2022-01-19 05:58:43 --> Config Class Initialized
INFO - 2022-01-19 05:58:43 --> Loader Class Initialized
INFO - 2022-01-19 05:58:43 --> Helper loaded: url_helper
INFO - 2022-01-19 05:58:43 --> Helper loaded: file_helper
INFO - 2022-01-19 05:58:43 --> Helper loaded: form_helper
INFO - 2022-01-19 05:58:43 --> Helper loaded: my_helper
INFO - 2022-01-19 05:58:43 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:58:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:58:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:58:43 --> Controller Class Initialized
DEBUG - 2022-01-19 05:58:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tki.php
INFO - 2022-01-19 05:58:44 --> Final output sent to browser
DEBUG - 2022-01-19 05:58:44 --> Total execution time: 0.0950
INFO - 2022-01-19 05:58:58 --> Config Class Initialized
INFO - 2022-01-19 05:58:58 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:58:58 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:58:58 --> Utf8 Class Initialized
INFO - 2022-01-19 05:58:58 --> URI Class Initialized
INFO - 2022-01-19 05:58:58 --> Router Class Initialized
INFO - 2022-01-19 05:58:58 --> Output Class Initialized
INFO - 2022-01-19 05:58:58 --> Security Class Initialized
DEBUG - 2022-01-19 05:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:58:58 --> Input Class Initialized
INFO - 2022-01-19 05:58:58 --> Language Class Initialized
INFO - 2022-01-19 05:58:58 --> Language Class Initialized
INFO - 2022-01-19 05:58:58 --> Config Class Initialized
INFO - 2022-01-19 05:58:58 --> Loader Class Initialized
INFO - 2022-01-19 05:58:58 --> Helper loaded: url_helper
INFO - 2022-01-19 05:58:58 --> Helper loaded: file_helper
INFO - 2022-01-19 05:58:58 --> Helper loaded: form_helper
INFO - 2022-01-19 05:58:58 --> Helper loaded: my_helper
INFO - 2022-01-19 05:58:58 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:58:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:58:58 --> Controller Class Initialized
DEBUG - 2022-01-19 05:58:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-01-19 05:58:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-19 05:58:58 --> Final output sent to browser
DEBUG - 2022-01-19 05:58:58 --> Total execution time: 0.0650
INFO - 2022-01-19 05:59:02 --> Config Class Initialized
INFO - 2022-01-19 05:59:02 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:59:02 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:59:02 --> Utf8 Class Initialized
INFO - 2022-01-19 05:59:02 --> URI Class Initialized
INFO - 2022-01-19 05:59:02 --> Router Class Initialized
INFO - 2022-01-19 05:59:02 --> Output Class Initialized
INFO - 2022-01-19 05:59:02 --> Security Class Initialized
DEBUG - 2022-01-19 05:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:59:02 --> Input Class Initialized
INFO - 2022-01-19 05:59:02 --> Language Class Initialized
INFO - 2022-01-19 05:59:02 --> Language Class Initialized
INFO - 2022-01-19 05:59:02 --> Config Class Initialized
INFO - 2022-01-19 05:59:02 --> Loader Class Initialized
INFO - 2022-01-19 05:59:02 --> Helper loaded: url_helper
INFO - 2022-01-19 05:59:02 --> Helper loaded: file_helper
INFO - 2022-01-19 05:59:02 --> Helper loaded: form_helper
INFO - 2022-01-19 05:59:02 --> Helper loaded: my_helper
INFO - 2022-01-19 05:59:02 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:59:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:59:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:59:02 --> Controller Class Initialized
DEBUG - 2022-01-19 05:59:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-19 05:59:02 --> Final output sent to browser
DEBUG - 2022-01-19 05:59:02 --> Total execution time: 0.1010
INFO - 2022-01-19 05:59:04 --> Config Class Initialized
INFO - 2022-01-19 05:59:04 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:59:04 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:59:04 --> Utf8 Class Initialized
INFO - 2022-01-19 05:59:04 --> URI Class Initialized
INFO - 2022-01-19 05:59:04 --> Router Class Initialized
INFO - 2022-01-19 05:59:04 --> Output Class Initialized
INFO - 2022-01-19 05:59:04 --> Security Class Initialized
DEBUG - 2022-01-19 05:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:59:04 --> Input Class Initialized
INFO - 2022-01-19 05:59:04 --> Language Class Initialized
INFO - 2022-01-19 05:59:04 --> Language Class Initialized
INFO - 2022-01-19 05:59:04 --> Config Class Initialized
INFO - 2022-01-19 05:59:04 --> Loader Class Initialized
INFO - 2022-01-19 05:59:04 --> Helper loaded: url_helper
INFO - 2022-01-19 05:59:04 --> Helper loaded: file_helper
INFO - 2022-01-19 05:59:04 --> Helper loaded: form_helper
INFO - 2022-01-19 05:59:04 --> Helper loaded: my_helper
INFO - 2022-01-19 05:59:04 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:59:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:59:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:59:04 --> Controller Class Initialized
DEBUG - 2022-01-19 05:59:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-19 05:59:04 --> Final output sent to browser
DEBUG - 2022-01-19 05:59:04 --> Total execution time: 0.0640
INFO - 2022-01-19 05:59:06 --> Config Class Initialized
INFO - 2022-01-19 05:59:06 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:59:06 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:59:06 --> Utf8 Class Initialized
INFO - 2022-01-19 05:59:06 --> URI Class Initialized
INFO - 2022-01-19 05:59:06 --> Router Class Initialized
INFO - 2022-01-19 05:59:06 --> Output Class Initialized
INFO - 2022-01-19 05:59:06 --> Security Class Initialized
DEBUG - 2022-01-19 05:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:59:06 --> Input Class Initialized
INFO - 2022-01-19 05:59:06 --> Language Class Initialized
INFO - 2022-01-19 05:59:06 --> Language Class Initialized
INFO - 2022-01-19 05:59:06 --> Config Class Initialized
INFO - 2022-01-19 05:59:06 --> Loader Class Initialized
INFO - 2022-01-19 05:59:06 --> Helper loaded: url_helper
INFO - 2022-01-19 05:59:06 --> Helper loaded: file_helper
INFO - 2022-01-19 05:59:06 --> Helper loaded: form_helper
INFO - 2022-01-19 05:59:06 --> Helper loaded: my_helper
INFO - 2022-01-19 05:59:06 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:59:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:59:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:59:06 --> Controller Class Initialized
DEBUG - 2022-01-19 05:59:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-19 05:59:06 --> Final output sent to browser
DEBUG - 2022-01-19 05:59:06 --> Total execution time: 0.0730
INFO - 2022-01-19 05:59:08 --> Config Class Initialized
INFO - 2022-01-19 05:59:08 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:59:08 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:59:08 --> Utf8 Class Initialized
INFO - 2022-01-19 05:59:08 --> URI Class Initialized
INFO - 2022-01-19 05:59:08 --> Router Class Initialized
INFO - 2022-01-19 05:59:08 --> Output Class Initialized
INFO - 2022-01-19 05:59:08 --> Security Class Initialized
DEBUG - 2022-01-19 05:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:59:08 --> Input Class Initialized
INFO - 2022-01-19 05:59:08 --> Language Class Initialized
INFO - 2022-01-19 05:59:08 --> Language Class Initialized
INFO - 2022-01-19 05:59:08 --> Config Class Initialized
INFO - 2022-01-19 05:59:08 --> Loader Class Initialized
INFO - 2022-01-19 05:59:08 --> Helper loaded: url_helper
INFO - 2022-01-19 05:59:08 --> Helper loaded: file_helper
INFO - 2022-01-19 05:59:08 --> Helper loaded: form_helper
INFO - 2022-01-19 05:59:08 --> Helper loaded: my_helper
INFO - 2022-01-19 05:59:08 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:59:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:59:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:59:08 --> Controller Class Initialized
DEBUG - 2022-01-19 05:59:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-19 05:59:08 --> Final output sent to browser
DEBUG - 2022-01-19 05:59:08 --> Total execution time: 0.0630
INFO - 2022-01-19 05:59:12 --> Config Class Initialized
INFO - 2022-01-19 05:59:12 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:59:12 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:59:12 --> Utf8 Class Initialized
INFO - 2022-01-19 05:59:12 --> URI Class Initialized
INFO - 2022-01-19 05:59:12 --> Router Class Initialized
INFO - 2022-01-19 05:59:12 --> Output Class Initialized
INFO - 2022-01-19 05:59:12 --> Security Class Initialized
DEBUG - 2022-01-19 05:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:59:12 --> Input Class Initialized
INFO - 2022-01-19 05:59:12 --> Language Class Initialized
INFO - 2022-01-19 05:59:12 --> Language Class Initialized
INFO - 2022-01-19 05:59:12 --> Config Class Initialized
INFO - 2022-01-19 05:59:12 --> Loader Class Initialized
INFO - 2022-01-19 05:59:12 --> Helper loaded: url_helper
INFO - 2022-01-19 05:59:12 --> Helper loaded: file_helper
INFO - 2022-01-19 05:59:12 --> Helper loaded: form_helper
INFO - 2022-01-19 05:59:12 --> Helper loaded: my_helper
INFO - 2022-01-19 05:59:12 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:59:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:59:12 --> Controller Class Initialized
DEBUG - 2022-01-19 05:59:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-19 05:59:12 --> Final output sent to browser
DEBUG - 2022-01-19 05:59:12 --> Total execution time: 0.0540
INFO - 2022-01-19 05:59:14 --> Config Class Initialized
INFO - 2022-01-19 05:59:14 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:59:14 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:59:14 --> Utf8 Class Initialized
INFO - 2022-01-19 05:59:14 --> URI Class Initialized
INFO - 2022-01-19 05:59:14 --> Router Class Initialized
INFO - 2022-01-19 05:59:14 --> Output Class Initialized
INFO - 2022-01-19 05:59:14 --> Security Class Initialized
DEBUG - 2022-01-19 05:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:59:14 --> Input Class Initialized
INFO - 2022-01-19 05:59:14 --> Language Class Initialized
INFO - 2022-01-19 05:59:14 --> Language Class Initialized
INFO - 2022-01-19 05:59:14 --> Config Class Initialized
INFO - 2022-01-19 05:59:14 --> Loader Class Initialized
INFO - 2022-01-19 05:59:14 --> Helper loaded: url_helper
INFO - 2022-01-19 05:59:14 --> Helper loaded: file_helper
INFO - 2022-01-19 05:59:14 --> Helper loaded: form_helper
INFO - 2022-01-19 05:59:14 --> Helper loaded: my_helper
INFO - 2022-01-19 05:59:14 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:59:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:59:14 --> Controller Class Initialized
DEBUG - 2022-01-19 05:59:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-19 05:59:14 --> Final output sent to browser
DEBUG - 2022-01-19 05:59:14 --> Total execution time: 0.0650
INFO - 2022-01-19 05:59:16 --> Config Class Initialized
INFO - 2022-01-19 05:59:16 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:59:16 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:59:16 --> Utf8 Class Initialized
INFO - 2022-01-19 05:59:16 --> URI Class Initialized
INFO - 2022-01-19 05:59:16 --> Router Class Initialized
INFO - 2022-01-19 05:59:16 --> Output Class Initialized
INFO - 2022-01-19 05:59:16 --> Security Class Initialized
DEBUG - 2022-01-19 05:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:59:16 --> Input Class Initialized
INFO - 2022-01-19 05:59:16 --> Language Class Initialized
INFO - 2022-01-19 05:59:16 --> Language Class Initialized
INFO - 2022-01-19 05:59:16 --> Config Class Initialized
INFO - 2022-01-19 05:59:16 --> Loader Class Initialized
INFO - 2022-01-19 05:59:16 --> Helper loaded: url_helper
INFO - 2022-01-19 05:59:16 --> Helper loaded: file_helper
INFO - 2022-01-19 05:59:16 --> Helper loaded: form_helper
INFO - 2022-01-19 05:59:16 --> Helper loaded: my_helper
INFO - 2022-01-19 05:59:16 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:59:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:59:16 --> Controller Class Initialized
DEBUG - 2022-01-19 05:59:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-19 05:59:16 --> Final output sent to browser
DEBUG - 2022-01-19 05:59:16 --> Total execution time: 0.0620
INFO - 2022-01-19 05:59:19 --> Config Class Initialized
INFO - 2022-01-19 05:59:19 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:59:19 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:59:19 --> Utf8 Class Initialized
INFO - 2022-01-19 05:59:19 --> URI Class Initialized
INFO - 2022-01-19 05:59:19 --> Router Class Initialized
INFO - 2022-01-19 05:59:19 --> Output Class Initialized
INFO - 2022-01-19 05:59:19 --> Security Class Initialized
DEBUG - 2022-01-19 05:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:59:19 --> Input Class Initialized
INFO - 2022-01-19 05:59:19 --> Language Class Initialized
INFO - 2022-01-19 05:59:19 --> Language Class Initialized
INFO - 2022-01-19 05:59:19 --> Config Class Initialized
INFO - 2022-01-19 05:59:19 --> Loader Class Initialized
INFO - 2022-01-19 05:59:19 --> Helper loaded: url_helper
INFO - 2022-01-19 05:59:19 --> Helper loaded: file_helper
INFO - 2022-01-19 05:59:19 --> Helper loaded: form_helper
INFO - 2022-01-19 05:59:19 --> Helper loaded: my_helper
INFO - 2022-01-19 05:59:19 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:59:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:59:19 --> Controller Class Initialized
DEBUG - 2022-01-19 05:59:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-19 05:59:19 --> Final output sent to browser
DEBUG - 2022-01-19 05:59:19 --> Total execution time: 0.0560
INFO - 2022-01-19 05:59:22 --> Config Class Initialized
INFO - 2022-01-19 05:59:22 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:59:22 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:59:22 --> Utf8 Class Initialized
INFO - 2022-01-19 05:59:22 --> URI Class Initialized
INFO - 2022-01-19 05:59:22 --> Router Class Initialized
INFO - 2022-01-19 05:59:22 --> Output Class Initialized
INFO - 2022-01-19 05:59:22 --> Security Class Initialized
DEBUG - 2022-01-19 05:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:59:22 --> Input Class Initialized
INFO - 2022-01-19 05:59:22 --> Language Class Initialized
INFO - 2022-01-19 05:59:22 --> Language Class Initialized
INFO - 2022-01-19 05:59:22 --> Config Class Initialized
INFO - 2022-01-19 05:59:22 --> Loader Class Initialized
INFO - 2022-01-19 05:59:22 --> Helper loaded: url_helper
INFO - 2022-01-19 05:59:22 --> Helper loaded: file_helper
INFO - 2022-01-19 05:59:22 --> Helper loaded: form_helper
INFO - 2022-01-19 05:59:22 --> Helper loaded: my_helper
INFO - 2022-01-19 05:59:22 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:59:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:59:22 --> Controller Class Initialized
DEBUG - 2022-01-19 05:59:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-19 05:59:22 --> Final output sent to browser
DEBUG - 2022-01-19 05:59:22 --> Total execution time: 0.0620
INFO - 2022-01-19 05:59:24 --> Config Class Initialized
INFO - 2022-01-19 05:59:24 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:59:24 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:59:24 --> Utf8 Class Initialized
INFO - 2022-01-19 05:59:24 --> URI Class Initialized
INFO - 2022-01-19 05:59:24 --> Router Class Initialized
INFO - 2022-01-19 05:59:24 --> Output Class Initialized
INFO - 2022-01-19 05:59:24 --> Security Class Initialized
DEBUG - 2022-01-19 05:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:59:24 --> Input Class Initialized
INFO - 2022-01-19 05:59:24 --> Language Class Initialized
INFO - 2022-01-19 05:59:24 --> Language Class Initialized
INFO - 2022-01-19 05:59:24 --> Config Class Initialized
INFO - 2022-01-19 05:59:24 --> Loader Class Initialized
INFO - 2022-01-19 05:59:24 --> Helper loaded: url_helper
INFO - 2022-01-19 05:59:24 --> Helper loaded: file_helper
INFO - 2022-01-19 05:59:24 --> Helper loaded: form_helper
INFO - 2022-01-19 05:59:24 --> Helper loaded: my_helper
INFO - 2022-01-19 05:59:24 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:59:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:59:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:59:24 --> Controller Class Initialized
DEBUG - 2022-01-19 05:59:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-19 05:59:24 --> Final output sent to browser
DEBUG - 2022-01-19 05:59:24 --> Total execution time: 0.0710
INFO - 2022-01-19 05:59:29 --> Config Class Initialized
INFO - 2022-01-19 05:59:29 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:59:29 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:59:29 --> Utf8 Class Initialized
INFO - 2022-01-19 05:59:29 --> URI Class Initialized
INFO - 2022-01-19 05:59:29 --> Router Class Initialized
INFO - 2022-01-19 05:59:29 --> Output Class Initialized
INFO - 2022-01-19 05:59:29 --> Security Class Initialized
DEBUG - 2022-01-19 05:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:59:29 --> Input Class Initialized
INFO - 2022-01-19 05:59:29 --> Language Class Initialized
INFO - 2022-01-19 05:59:29 --> Language Class Initialized
INFO - 2022-01-19 05:59:29 --> Config Class Initialized
INFO - 2022-01-19 05:59:29 --> Loader Class Initialized
INFO - 2022-01-19 05:59:29 --> Helper loaded: url_helper
INFO - 2022-01-19 05:59:29 --> Helper loaded: file_helper
INFO - 2022-01-19 05:59:29 --> Helper loaded: form_helper
INFO - 2022-01-19 05:59:29 --> Helper loaded: my_helper
INFO - 2022-01-19 05:59:29 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:59:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:59:29 --> Controller Class Initialized
DEBUG - 2022-01-19 05:59:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-19 05:59:29 --> Final output sent to browser
DEBUG - 2022-01-19 05:59:29 --> Total execution time: 0.0680
INFO - 2022-01-19 05:59:32 --> Config Class Initialized
INFO - 2022-01-19 05:59:32 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:59:32 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:59:32 --> Utf8 Class Initialized
INFO - 2022-01-19 05:59:32 --> URI Class Initialized
INFO - 2022-01-19 05:59:32 --> Router Class Initialized
INFO - 2022-01-19 05:59:32 --> Output Class Initialized
INFO - 2022-01-19 05:59:32 --> Security Class Initialized
DEBUG - 2022-01-19 05:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:59:32 --> Input Class Initialized
INFO - 2022-01-19 05:59:32 --> Language Class Initialized
INFO - 2022-01-19 05:59:32 --> Language Class Initialized
INFO - 2022-01-19 05:59:32 --> Config Class Initialized
INFO - 2022-01-19 05:59:32 --> Loader Class Initialized
INFO - 2022-01-19 05:59:32 --> Helper loaded: url_helper
INFO - 2022-01-19 05:59:32 --> Helper loaded: file_helper
INFO - 2022-01-19 05:59:32 --> Helper loaded: form_helper
INFO - 2022-01-19 05:59:32 --> Helper loaded: my_helper
INFO - 2022-01-19 05:59:32 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:59:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:59:32 --> Controller Class Initialized
DEBUG - 2022-01-19 05:59:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-19 05:59:32 --> Final output sent to browser
DEBUG - 2022-01-19 05:59:32 --> Total execution time: 0.0740
INFO - 2022-01-19 05:59:35 --> Config Class Initialized
INFO - 2022-01-19 05:59:35 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:59:35 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:59:35 --> Utf8 Class Initialized
INFO - 2022-01-19 05:59:35 --> URI Class Initialized
INFO - 2022-01-19 05:59:35 --> Router Class Initialized
INFO - 2022-01-19 05:59:35 --> Output Class Initialized
INFO - 2022-01-19 05:59:35 --> Security Class Initialized
DEBUG - 2022-01-19 05:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:59:35 --> Input Class Initialized
INFO - 2022-01-19 05:59:35 --> Language Class Initialized
INFO - 2022-01-19 05:59:35 --> Language Class Initialized
INFO - 2022-01-19 05:59:35 --> Config Class Initialized
INFO - 2022-01-19 05:59:35 --> Loader Class Initialized
INFO - 2022-01-19 05:59:35 --> Helper loaded: url_helper
INFO - 2022-01-19 05:59:35 --> Helper loaded: file_helper
INFO - 2022-01-19 05:59:35 --> Helper loaded: form_helper
INFO - 2022-01-19 05:59:35 --> Helper loaded: my_helper
INFO - 2022-01-19 05:59:35 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:59:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:59:35 --> Controller Class Initialized
DEBUG - 2022-01-19 05:59:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-19 05:59:35 --> Final output sent to browser
DEBUG - 2022-01-19 05:59:35 --> Total execution time: 0.0720
INFO - 2022-01-19 05:59:37 --> Config Class Initialized
INFO - 2022-01-19 05:59:37 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:59:37 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:59:37 --> Utf8 Class Initialized
INFO - 2022-01-19 05:59:37 --> URI Class Initialized
INFO - 2022-01-19 05:59:37 --> Router Class Initialized
INFO - 2022-01-19 05:59:37 --> Output Class Initialized
INFO - 2022-01-19 05:59:37 --> Security Class Initialized
DEBUG - 2022-01-19 05:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:59:37 --> Input Class Initialized
INFO - 2022-01-19 05:59:37 --> Language Class Initialized
INFO - 2022-01-19 05:59:37 --> Language Class Initialized
INFO - 2022-01-19 05:59:37 --> Config Class Initialized
INFO - 2022-01-19 05:59:37 --> Loader Class Initialized
INFO - 2022-01-19 05:59:37 --> Helper loaded: url_helper
INFO - 2022-01-19 05:59:37 --> Helper loaded: file_helper
INFO - 2022-01-19 05:59:37 --> Helper loaded: form_helper
INFO - 2022-01-19 05:59:37 --> Helper loaded: my_helper
INFO - 2022-01-19 05:59:37 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:59:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:59:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:59:37 --> Controller Class Initialized
DEBUG - 2022-01-19 05:59:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-19 05:59:37 --> Final output sent to browser
DEBUG - 2022-01-19 05:59:37 --> Total execution time: 0.0660
INFO - 2022-01-19 05:59:40 --> Config Class Initialized
INFO - 2022-01-19 05:59:40 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:59:40 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:59:40 --> Utf8 Class Initialized
INFO - 2022-01-19 05:59:40 --> URI Class Initialized
INFO - 2022-01-19 05:59:40 --> Router Class Initialized
INFO - 2022-01-19 05:59:40 --> Output Class Initialized
INFO - 2022-01-19 05:59:40 --> Security Class Initialized
DEBUG - 2022-01-19 05:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:59:40 --> Input Class Initialized
INFO - 2022-01-19 05:59:40 --> Language Class Initialized
INFO - 2022-01-19 05:59:40 --> Language Class Initialized
INFO - 2022-01-19 05:59:40 --> Config Class Initialized
INFO - 2022-01-19 05:59:40 --> Loader Class Initialized
INFO - 2022-01-19 05:59:40 --> Helper loaded: url_helper
INFO - 2022-01-19 05:59:40 --> Helper loaded: file_helper
INFO - 2022-01-19 05:59:40 --> Helper loaded: form_helper
INFO - 2022-01-19 05:59:40 --> Helper loaded: my_helper
INFO - 2022-01-19 05:59:40 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:59:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:59:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:59:40 --> Controller Class Initialized
DEBUG - 2022-01-19 05:59:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-19 05:59:40 --> Final output sent to browser
DEBUG - 2022-01-19 05:59:40 --> Total execution time: 0.0650
INFO - 2022-01-19 05:59:42 --> Config Class Initialized
INFO - 2022-01-19 05:59:42 --> Hooks Class Initialized
DEBUG - 2022-01-19 05:59:42 --> UTF-8 Support Enabled
INFO - 2022-01-19 05:59:42 --> Utf8 Class Initialized
INFO - 2022-01-19 05:59:42 --> URI Class Initialized
INFO - 2022-01-19 05:59:42 --> Router Class Initialized
INFO - 2022-01-19 05:59:42 --> Output Class Initialized
INFO - 2022-01-19 05:59:42 --> Security Class Initialized
DEBUG - 2022-01-19 05:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 05:59:42 --> Input Class Initialized
INFO - 2022-01-19 05:59:42 --> Language Class Initialized
INFO - 2022-01-19 05:59:42 --> Language Class Initialized
INFO - 2022-01-19 05:59:42 --> Config Class Initialized
INFO - 2022-01-19 05:59:42 --> Loader Class Initialized
INFO - 2022-01-19 05:59:42 --> Helper loaded: url_helper
INFO - 2022-01-19 05:59:42 --> Helper loaded: file_helper
INFO - 2022-01-19 05:59:42 --> Helper loaded: form_helper
INFO - 2022-01-19 05:59:42 --> Helper loaded: my_helper
INFO - 2022-01-19 05:59:42 --> Database Driver Class Initialized
DEBUG - 2022-01-19 05:59:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 05:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 05:59:42 --> Controller Class Initialized
DEBUG - 2022-01-19 05:59:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-19 05:59:42 --> Final output sent to browser
DEBUG - 2022-01-19 05:59:42 --> Total execution time: 0.0560
INFO - 2022-01-19 06:02:02 --> Config Class Initialized
INFO - 2022-01-19 06:02:02 --> Hooks Class Initialized
DEBUG - 2022-01-19 06:02:02 --> UTF-8 Support Enabled
INFO - 2022-01-19 06:02:02 --> Utf8 Class Initialized
INFO - 2022-01-19 06:02:02 --> URI Class Initialized
INFO - 2022-01-19 06:02:02 --> Router Class Initialized
INFO - 2022-01-19 06:02:02 --> Output Class Initialized
INFO - 2022-01-19 06:02:02 --> Security Class Initialized
DEBUG - 2022-01-19 06:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 06:02:02 --> Input Class Initialized
INFO - 2022-01-19 06:02:02 --> Language Class Initialized
INFO - 2022-01-19 06:02:02 --> Language Class Initialized
INFO - 2022-01-19 06:02:02 --> Config Class Initialized
INFO - 2022-01-19 06:02:02 --> Loader Class Initialized
INFO - 2022-01-19 06:02:02 --> Helper loaded: url_helper
INFO - 2022-01-19 06:02:02 --> Helper loaded: file_helper
INFO - 2022-01-19 06:02:02 --> Helper loaded: form_helper
INFO - 2022-01-19 06:02:02 --> Helper loaded: my_helper
INFO - 2022-01-19 06:02:02 --> Database Driver Class Initialized
DEBUG - 2022-01-19 06:02:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 06:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 06:02:02 --> Controller Class Initialized
INFO - 2022-01-19 06:02:02 --> Helper loaded: cookie_helper
INFO - 2022-01-19 06:02:02 --> Config Class Initialized
INFO - 2022-01-19 06:02:02 --> Hooks Class Initialized
DEBUG - 2022-01-19 06:02:02 --> UTF-8 Support Enabled
INFO - 2022-01-19 06:02:02 --> Utf8 Class Initialized
INFO - 2022-01-19 06:02:02 --> URI Class Initialized
INFO - 2022-01-19 06:02:02 --> Router Class Initialized
INFO - 2022-01-19 06:02:02 --> Output Class Initialized
INFO - 2022-01-19 06:02:02 --> Security Class Initialized
DEBUG - 2022-01-19 06:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 06:02:02 --> Input Class Initialized
INFO - 2022-01-19 06:02:02 --> Language Class Initialized
INFO - 2022-01-19 06:02:02 --> Language Class Initialized
INFO - 2022-01-19 06:02:02 --> Config Class Initialized
INFO - 2022-01-19 06:02:02 --> Loader Class Initialized
INFO - 2022-01-19 06:02:02 --> Helper loaded: url_helper
INFO - 2022-01-19 06:02:02 --> Helper loaded: file_helper
INFO - 2022-01-19 06:02:02 --> Helper loaded: form_helper
INFO - 2022-01-19 06:02:02 --> Helper loaded: my_helper
INFO - 2022-01-19 06:02:02 --> Database Driver Class Initialized
DEBUG - 2022-01-19 06:02:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 06:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 06:02:02 --> Controller Class Initialized
DEBUG - 2022-01-19 06:02:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-01-19 06:02:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-19 06:02:02 --> Final output sent to browser
DEBUG - 2022-01-19 06:02:02 --> Total execution time: 0.0390
INFO - 2022-01-19 06:02:12 --> Config Class Initialized
INFO - 2022-01-19 06:02:12 --> Hooks Class Initialized
DEBUG - 2022-01-19 06:02:12 --> UTF-8 Support Enabled
INFO - 2022-01-19 06:02:12 --> Utf8 Class Initialized
INFO - 2022-01-19 06:02:12 --> URI Class Initialized
INFO - 2022-01-19 06:02:12 --> Router Class Initialized
INFO - 2022-01-19 06:02:12 --> Output Class Initialized
INFO - 2022-01-19 06:02:12 --> Security Class Initialized
DEBUG - 2022-01-19 06:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 06:02:12 --> Input Class Initialized
INFO - 2022-01-19 06:02:12 --> Language Class Initialized
INFO - 2022-01-19 06:02:12 --> Language Class Initialized
INFO - 2022-01-19 06:02:12 --> Config Class Initialized
INFO - 2022-01-19 06:02:12 --> Loader Class Initialized
INFO - 2022-01-19 06:02:12 --> Helper loaded: url_helper
INFO - 2022-01-19 06:02:12 --> Helper loaded: file_helper
INFO - 2022-01-19 06:02:12 --> Helper loaded: form_helper
INFO - 2022-01-19 06:02:12 --> Helper loaded: my_helper
INFO - 2022-01-19 06:02:12 --> Database Driver Class Initialized
DEBUG - 2022-01-19 06:02:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 06:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 06:02:12 --> Controller Class Initialized
INFO - 2022-01-19 06:02:12 --> Helper loaded: cookie_helper
INFO - 2022-01-19 06:02:12 --> Final output sent to browser
DEBUG - 2022-01-19 06:02:12 --> Total execution time: 0.0440
INFO - 2022-01-19 06:02:13 --> Config Class Initialized
INFO - 2022-01-19 06:02:13 --> Hooks Class Initialized
DEBUG - 2022-01-19 06:02:13 --> UTF-8 Support Enabled
INFO - 2022-01-19 06:02:13 --> Utf8 Class Initialized
INFO - 2022-01-19 06:02:13 --> URI Class Initialized
INFO - 2022-01-19 06:02:13 --> Router Class Initialized
INFO - 2022-01-19 06:02:13 --> Output Class Initialized
INFO - 2022-01-19 06:02:13 --> Security Class Initialized
DEBUG - 2022-01-19 06:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 06:02:13 --> Input Class Initialized
INFO - 2022-01-19 06:02:13 --> Language Class Initialized
INFO - 2022-01-19 06:02:13 --> Language Class Initialized
INFO - 2022-01-19 06:02:13 --> Config Class Initialized
INFO - 2022-01-19 06:02:13 --> Loader Class Initialized
INFO - 2022-01-19 06:02:13 --> Helper loaded: url_helper
INFO - 2022-01-19 06:02:13 --> Helper loaded: file_helper
INFO - 2022-01-19 06:02:13 --> Helper loaded: form_helper
INFO - 2022-01-19 06:02:13 --> Helper loaded: my_helper
INFO - 2022-01-19 06:02:13 --> Database Driver Class Initialized
DEBUG - 2022-01-19 06:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 06:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 06:02:13 --> Controller Class Initialized
DEBUG - 2022-01-19 06:02:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-01-19 06:02:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-19 06:02:13 --> Final output sent to browser
DEBUG - 2022-01-19 06:02:13 --> Total execution time: 0.3730
INFO - 2022-01-19 06:02:18 --> Config Class Initialized
INFO - 2022-01-19 06:02:18 --> Hooks Class Initialized
DEBUG - 2022-01-19 06:02:18 --> UTF-8 Support Enabled
INFO - 2022-01-19 06:02:18 --> Utf8 Class Initialized
INFO - 2022-01-19 06:02:18 --> URI Class Initialized
INFO - 2022-01-19 06:02:18 --> Router Class Initialized
INFO - 2022-01-19 06:02:18 --> Output Class Initialized
INFO - 2022-01-19 06:02:18 --> Security Class Initialized
DEBUG - 2022-01-19 06:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 06:02:18 --> Input Class Initialized
INFO - 2022-01-19 06:02:18 --> Language Class Initialized
INFO - 2022-01-19 06:02:18 --> Language Class Initialized
INFO - 2022-01-19 06:02:18 --> Config Class Initialized
INFO - 2022-01-19 06:02:18 --> Loader Class Initialized
INFO - 2022-01-19 06:02:18 --> Helper loaded: url_helper
INFO - 2022-01-19 06:02:18 --> Helper loaded: file_helper
INFO - 2022-01-19 06:02:18 --> Helper loaded: form_helper
INFO - 2022-01-19 06:02:18 --> Helper loaded: my_helper
INFO - 2022-01-19 06:02:18 --> Database Driver Class Initialized
DEBUG - 2022-01-19 06:02:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 06:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 06:02:18 --> Controller Class Initialized
DEBUG - 2022-01-19 06:02:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2022-01-19 06:02:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-19 06:02:18 --> Final output sent to browser
DEBUG - 2022-01-19 06:02:18 --> Total execution time: 0.0520
INFO - 2022-01-19 06:02:18 --> Config Class Initialized
INFO - 2022-01-19 06:02:18 --> Hooks Class Initialized
DEBUG - 2022-01-19 06:02:18 --> UTF-8 Support Enabled
INFO - 2022-01-19 06:02:18 --> Utf8 Class Initialized
INFO - 2022-01-19 06:02:18 --> URI Class Initialized
INFO - 2022-01-19 06:02:18 --> Router Class Initialized
INFO - 2022-01-19 06:02:18 --> Output Class Initialized
INFO - 2022-01-19 06:02:18 --> Security Class Initialized
DEBUG - 2022-01-19 06:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 06:02:18 --> Input Class Initialized
INFO - 2022-01-19 06:02:18 --> Language Class Initialized
INFO - 2022-01-19 06:02:18 --> Language Class Initialized
INFO - 2022-01-19 06:02:18 --> Config Class Initialized
INFO - 2022-01-19 06:02:18 --> Loader Class Initialized
INFO - 2022-01-19 06:02:18 --> Helper loaded: url_helper
INFO - 2022-01-19 06:02:18 --> Helper loaded: file_helper
INFO - 2022-01-19 06:02:18 --> Helper loaded: form_helper
INFO - 2022-01-19 06:02:18 --> Helper loaded: my_helper
INFO - 2022-01-19 06:02:18 --> Database Driver Class Initialized
DEBUG - 2022-01-19 06:02:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 06:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 06:02:18 --> Controller Class Initialized
INFO - 2022-01-19 06:02:19 --> Config Class Initialized
INFO - 2022-01-19 06:02:19 --> Hooks Class Initialized
DEBUG - 2022-01-19 06:02:19 --> UTF-8 Support Enabled
INFO - 2022-01-19 06:02:19 --> Utf8 Class Initialized
INFO - 2022-01-19 06:02:19 --> URI Class Initialized
INFO - 2022-01-19 06:02:19 --> Router Class Initialized
INFO - 2022-01-19 06:02:19 --> Output Class Initialized
INFO - 2022-01-19 06:02:19 --> Security Class Initialized
DEBUG - 2022-01-19 06:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 06:02:19 --> Input Class Initialized
INFO - 2022-01-19 06:02:19 --> Language Class Initialized
INFO - 2022-01-19 06:02:19 --> Language Class Initialized
INFO - 2022-01-19 06:02:19 --> Config Class Initialized
INFO - 2022-01-19 06:02:19 --> Loader Class Initialized
INFO - 2022-01-19 06:02:19 --> Helper loaded: url_helper
INFO - 2022-01-19 06:02:19 --> Helper loaded: file_helper
INFO - 2022-01-19 06:02:19 --> Helper loaded: form_helper
INFO - 2022-01-19 06:02:19 --> Helper loaded: my_helper
INFO - 2022-01-19 06:02:19 --> Database Driver Class Initialized
DEBUG - 2022-01-19 06:02:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 06:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 06:02:19 --> Controller Class Initialized
INFO - 2022-01-19 06:02:19 --> Final output sent to browser
DEBUG - 2022-01-19 06:02:19 --> Total execution time: 0.0660
INFO - 2022-01-19 06:02:19 --> Config Class Initialized
INFO - 2022-01-19 06:02:19 --> Hooks Class Initialized
DEBUG - 2022-01-19 06:02:19 --> UTF-8 Support Enabled
INFO - 2022-01-19 06:02:19 --> Utf8 Class Initialized
INFO - 2022-01-19 06:02:19 --> URI Class Initialized
INFO - 2022-01-19 06:02:19 --> Router Class Initialized
INFO - 2022-01-19 06:02:19 --> Output Class Initialized
INFO - 2022-01-19 06:02:19 --> Security Class Initialized
DEBUG - 2022-01-19 06:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 06:02:19 --> Input Class Initialized
INFO - 2022-01-19 06:02:19 --> Language Class Initialized
INFO - 2022-01-19 06:02:19 --> Language Class Initialized
INFO - 2022-01-19 06:02:19 --> Config Class Initialized
INFO - 2022-01-19 06:02:19 --> Loader Class Initialized
INFO - 2022-01-19 06:02:19 --> Helper loaded: url_helper
INFO - 2022-01-19 06:02:19 --> Helper loaded: file_helper
INFO - 2022-01-19 06:02:19 --> Helper loaded: form_helper
INFO - 2022-01-19 06:02:19 --> Helper loaded: my_helper
INFO - 2022-01-19 06:02:19 --> Database Driver Class Initialized
DEBUG - 2022-01-19 06:02:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 06:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 06:02:20 --> Controller Class Initialized
INFO - 2022-01-19 06:02:22 --> Config Class Initialized
INFO - 2022-01-19 06:02:22 --> Hooks Class Initialized
DEBUG - 2022-01-19 06:02:22 --> UTF-8 Support Enabled
INFO - 2022-01-19 06:02:22 --> Utf8 Class Initialized
INFO - 2022-01-19 06:02:22 --> URI Class Initialized
INFO - 2022-01-19 06:02:22 --> Router Class Initialized
INFO - 2022-01-19 06:02:22 --> Output Class Initialized
INFO - 2022-01-19 06:02:22 --> Security Class Initialized
DEBUG - 2022-01-19 06:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 06:02:22 --> Input Class Initialized
INFO - 2022-01-19 06:02:22 --> Language Class Initialized
INFO - 2022-01-19 06:02:22 --> Language Class Initialized
INFO - 2022-01-19 06:02:22 --> Config Class Initialized
INFO - 2022-01-19 06:02:22 --> Loader Class Initialized
INFO - 2022-01-19 06:02:22 --> Helper loaded: url_helper
INFO - 2022-01-19 06:02:22 --> Helper loaded: file_helper
INFO - 2022-01-19 06:02:22 --> Helper loaded: form_helper
INFO - 2022-01-19 06:02:22 --> Helper loaded: my_helper
INFO - 2022-01-19 06:02:22 --> Database Driver Class Initialized
DEBUG - 2022-01-19 06:02:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 06:02:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 06:02:22 --> Controller Class Initialized
INFO - 2022-01-19 06:02:22 --> Helper loaded: cookie_helper
INFO - 2022-01-19 06:02:22 --> Config Class Initialized
INFO - 2022-01-19 06:02:22 --> Hooks Class Initialized
DEBUG - 2022-01-19 06:02:22 --> UTF-8 Support Enabled
INFO - 2022-01-19 06:02:22 --> Utf8 Class Initialized
INFO - 2022-01-19 06:02:22 --> URI Class Initialized
INFO - 2022-01-19 06:02:22 --> Router Class Initialized
INFO - 2022-01-19 06:02:22 --> Output Class Initialized
INFO - 2022-01-19 06:02:22 --> Security Class Initialized
DEBUG - 2022-01-19 06:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 06:02:22 --> Input Class Initialized
INFO - 2022-01-19 06:02:22 --> Language Class Initialized
INFO - 2022-01-19 06:02:22 --> Language Class Initialized
INFO - 2022-01-19 06:02:22 --> Config Class Initialized
INFO - 2022-01-19 06:02:22 --> Loader Class Initialized
INFO - 2022-01-19 06:02:22 --> Helper loaded: url_helper
INFO - 2022-01-19 06:02:22 --> Helper loaded: file_helper
INFO - 2022-01-19 06:02:22 --> Helper loaded: form_helper
INFO - 2022-01-19 06:02:22 --> Helper loaded: my_helper
INFO - 2022-01-19 06:02:22 --> Database Driver Class Initialized
DEBUG - 2022-01-19 06:02:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 06:02:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 06:02:22 --> Controller Class Initialized
DEBUG - 2022-01-19 06:02:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-01-19 06:02:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-19 06:02:22 --> Final output sent to browser
DEBUG - 2022-01-19 06:02:22 --> Total execution time: 0.0390
INFO - 2022-01-19 06:02:25 --> Config Class Initialized
INFO - 2022-01-19 06:02:25 --> Hooks Class Initialized
DEBUG - 2022-01-19 06:02:25 --> UTF-8 Support Enabled
INFO - 2022-01-19 06:02:25 --> Utf8 Class Initialized
INFO - 2022-01-19 06:02:25 --> URI Class Initialized
INFO - 2022-01-19 06:02:25 --> Router Class Initialized
INFO - 2022-01-19 06:02:25 --> Output Class Initialized
INFO - 2022-01-19 06:02:25 --> Security Class Initialized
DEBUG - 2022-01-19 06:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 06:02:25 --> Input Class Initialized
INFO - 2022-01-19 06:02:25 --> Language Class Initialized
INFO - 2022-01-19 06:02:25 --> Language Class Initialized
INFO - 2022-01-19 06:02:25 --> Config Class Initialized
INFO - 2022-01-19 06:02:25 --> Loader Class Initialized
INFO - 2022-01-19 06:02:25 --> Helper loaded: url_helper
INFO - 2022-01-19 06:02:25 --> Helper loaded: file_helper
INFO - 2022-01-19 06:02:25 --> Helper loaded: form_helper
INFO - 2022-01-19 06:02:25 --> Helper loaded: my_helper
INFO - 2022-01-19 06:02:25 --> Database Driver Class Initialized
DEBUG - 2022-01-19 06:02:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 06:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 06:02:25 --> Controller Class Initialized
INFO - 2022-01-19 06:02:25 --> Helper loaded: cookie_helper
INFO - 2022-01-19 06:02:25 --> Final output sent to browser
DEBUG - 2022-01-19 06:02:25 --> Total execution time: 0.0610
INFO - 2022-01-19 06:02:25 --> Config Class Initialized
INFO - 2022-01-19 06:02:25 --> Hooks Class Initialized
DEBUG - 2022-01-19 06:02:25 --> UTF-8 Support Enabled
INFO - 2022-01-19 06:02:25 --> Utf8 Class Initialized
INFO - 2022-01-19 06:02:25 --> URI Class Initialized
INFO - 2022-01-19 06:02:25 --> Router Class Initialized
INFO - 2022-01-19 06:02:25 --> Output Class Initialized
INFO - 2022-01-19 06:02:25 --> Security Class Initialized
DEBUG - 2022-01-19 06:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 06:02:25 --> Input Class Initialized
INFO - 2022-01-19 06:02:25 --> Language Class Initialized
INFO - 2022-01-19 06:02:25 --> Language Class Initialized
INFO - 2022-01-19 06:02:25 --> Config Class Initialized
INFO - 2022-01-19 06:02:25 --> Loader Class Initialized
INFO - 2022-01-19 06:02:25 --> Helper loaded: url_helper
INFO - 2022-01-19 06:02:25 --> Helper loaded: file_helper
INFO - 2022-01-19 06:02:25 --> Helper loaded: form_helper
INFO - 2022-01-19 06:02:25 --> Helper loaded: my_helper
INFO - 2022-01-19 06:02:25 --> Database Driver Class Initialized
DEBUG - 2022-01-19 06:02:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 06:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 06:02:25 --> Controller Class Initialized
DEBUG - 2022-01-19 06:02:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-01-19 06:02:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-19 06:02:26 --> Final output sent to browser
DEBUG - 2022-01-19 06:02:26 --> Total execution time: 0.7600
INFO - 2022-01-19 06:02:28 --> Config Class Initialized
INFO - 2022-01-19 06:02:28 --> Hooks Class Initialized
DEBUG - 2022-01-19 06:02:28 --> UTF-8 Support Enabled
INFO - 2022-01-19 06:02:28 --> Utf8 Class Initialized
INFO - 2022-01-19 06:02:28 --> URI Class Initialized
INFO - 2022-01-19 06:02:28 --> Router Class Initialized
INFO - 2022-01-19 06:02:28 --> Output Class Initialized
INFO - 2022-01-19 06:02:28 --> Security Class Initialized
DEBUG - 2022-01-19 06:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 06:02:28 --> Input Class Initialized
INFO - 2022-01-19 06:02:28 --> Language Class Initialized
INFO - 2022-01-19 06:02:28 --> Language Class Initialized
INFO - 2022-01-19 06:02:28 --> Config Class Initialized
INFO - 2022-01-19 06:02:28 --> Loader Class Initialized
INFO - 2022-01-19 06:02:28 --> Helper loaded: url_helper
INFO - 2022-01-19 06:02:28 --> Helper loaded: file_helper
INFO - 2022-01-19 06:02:28 --> Helper loaded: form_helper
INFO - 2022-01-19 06:02:28 --> Helper loaded: my_helper
INFO - 2022-01-19 06:02:28 --> Database Driver Class Initialized
DEBUG - 2022-01-19 06:02:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 06:02:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 06:02:28 --> Controller Class Initialized
DEBUG - 2022-01-19 06:02:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2022-01-19 06:02:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-19 06:02:28 --> Final output sent to browser
DEBUG - 2022-01-19 06:02:28 --> Total execution time: 0.0790
INFO - 2022-01-19 06:02:29 --> Config Class Initialized
INFO - 2022-01-19 06:02:29 --> Hooks Class Initialized
DEBUG - 2022-01-19 06:02:29 --> UTF-8 Support Enabled
INFO - 2022-01-19 06:02:29 --> Utf8 Class Initialized
INFO - 2022-01-19 06:02:29 --> URI Class Initialized
INFO - 2022-01-19 06:02:29 --> Router Class Initialized
INFO - 2022-01-19 06:02:29 --> Output Class Initialized
INFO - 2022-01-19 06:02:29 --> Security Class Initialized
DEBUG - 2022-01-19 06:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 06:02:29 --> Input Class Initialized
INFO - 2022-01-19 06:02:29 --> Language Class Initialized
INFO - 2022-01-19 06:02:29 --> Language Class Initialized
INFO - 2022-01-19 06:02:29 --> Config Class Initialized
INFO - 2022-01-19 06:02:29 --> Loader Class Initialized
INFO - 2022-01-19 06:02:29 --> Helper loaded: url_helper
INFO - 2022-01-19 06:02:29 --> Helper loaded: file_helper
INFO - 2022-01-19 06:02:30 --> Helper loaded: form_helper
INFO - 2022-01-19 06:02:30 --> Helper loaded: my_helper
INFO - 2022-01-19 06:02:30 --> Database Driver Class Initialized
DEBUG - 2022-01-19 06:02:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 06:02:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 06:02:30 --> Controller Class Initialized
DEBUG - 2022-01-19 06:02:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_mm_xi.php
INFO - 2022-01-19 06:02:30 --> Final output sent to browser
DEBUG - 2022-01-19 06:02:30 --> Total execution time: 0.2460
INFO - 2022-01-19 06:02:46 --> Config Class Initialized
INFO - 2022-01-19 06:02:46 --> Hooks Class Initialized
DEBUG - 2022-01-19 06:02:46 --> UTF-8 Support Enabled
INFO - 2022-01-19 06:02:46 --> Utf8 Class Initialized
INFO - 2022-01-19 06:02:46 --> URI Class Initialized
INFO - 2022-01-19 06:02:46 --> Router Class Initialized
INFO - 2022-01-19 06:02:46 --> Output Class Initialized
INFO - 2022-01-19 06:02:46 --> Security Class Initialized
DEBUG - 2022-01-19 06:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 06:02:46 --> Input Class Initialized
INFO - 2022-01-19 06:02:46 --> Language Class Initialized
INFO - 2022-01-19 06:02:46 --> Language Class Initialized
INFO - 2022-01-19 06:02:46 --> Config Class Initialized
INFO - 2022-01-19 06:02:46 --> Loader Class Initialized
INFO - 2022-01-19 06:02:46 --> Helper loaded: url_helper
INFO - 2022-01-19 06:02:46 --> Helper loaded: file_helper
INFO - 2022-01-19 06:02:46 --> Helper loaded: form_helper
INFO - 2022-01-19 06:02:46 --> Helper loaded: my_helper
INFO - 2022-01-19 06:02:46 --> Database Driver Class Initialized
DEBUG - 2022-01-19 06:02:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 06:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 06:02:46 --> Controller Class Initialized
DEBUG - 2022-01-19 06:02:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-01-19 06:02:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-19 06:02:46 --> Final output sent to browser
DEBUG - 2022-01-19 06:02:46 --> Total execution time: 0.0590
INFO - 2022-01-19 06:02:50 --> Config Class Initialized
INFO - 2022-01-19 06:02:50 --> Hooks Class Initialized
DEBUG - 2022-01-19 06:02:50 --> UTF-8 Support Enabled
INFO - 2022-01-19 06:02:50 --> Utf8 Class Initialized
INFO - 2022-01-19 06:02:50 --> URI Class Initialized
INFO - 2022-01-19 06:02:50 --> Router Class Initialized
INFO - 2022-01-19 06:02:50 --> Output Class Initialized
INFO - 2022-01-19 06:02:50 --> Security Class Initialized
DEBUG - 2022-01-19 06:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 06:02:50 --> Input Class Initialized
INFO - 2022-01-19 06:02:50 --> Language Class Initialized
INFO - 2022-01-19 06:02:50 --> Language Class Initialized
INFO - 2022-01-19 06:02:50 --> Config Class Initialized
INFO - 2022-01-19 06:02:50 --> Loader Class Initialized
INFO - 2022-01-19 06:02:50 --> Helper loaded: url_helper
INFO - 2022-01-19 06:02:50 --> Helper loaded: file_helper
INFO - 2022-01-19 06:02:50 --> Helper loaded: form_helper
INFO - 2022-01-19 06:02:50 --> Helper loaded: my_helper
INFO - 2022-01-19 06:02:50 --> Database Driver Class Initialized
DEBUG - 2022-01-19 06:02:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 06:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 06:02:50 --> Controller Class Initialized
DEBUG - 2022-01-19 06:02:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2022-01-19 06:02:50 --> Final output sent to browser
DEBUG - 2022-01-19 06:02:50 --> Total execution time: 0.1680
INFO - 2022-01-19 06:02:52 --> Config Class Initialized
INFO - 2022-01-19 06:02:52 --> Hooks Class Initialized
DEBUG - 2022-01-19 06:02:52 --> UTF-8 Support Enabled
INFO - 2022-01-19 06:02:52 --> Utf8 Class Initialized
INFO - 2022-01-19 06:02:52 --> URI Class Initialized
INFO - 2022-01-19 06:02:52 --> Router Class Initialized
INFO - 2022-01-19 06:02:52 --> Output Class Initialized
INFO - 2022-01-19 06:02:52 --> Security Class Initialized
DEBUG - 2022-01-19 06:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 06:02:52 --> Input Class Initialized
INFO - 2022-01-19 06:02:52 --> Language Class Initialized
INFO - 2022-01-19 06:02:52 --> Language Class Initialized
INFO - 2022-01-19 06:02:52 --> Config Class Initialized
INFO - 2022-01-19 06:02:52 --> Loader Class Initialized
INFO - 2022-01-19 06:02:52 --> Helper loaded: url_helper
INFO - 2022-01-19 06:02:52 --> Helper loaded: file_helper
INFO - 2022-01-19 06:02:52 --> Helper loaded: form_helper
INFO - 2022-01-19 06:02:52 --> Helper loaded: my_helper
INFO - 2022-01-19 06:02:52 --> Database Driver Class Initialized
DEBUG - 2022-01-19 06:02:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 06:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 06:02:52 --> Controller Class Initialized
DEBUG - 2022-01-19 06:02:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2022-01-19 06:02:52 --> Final output sent to browser
DEBUG - 2022-01-19 06:02:52 --> Total execution time: 0.1260
INFO - 2022-01-19 06:02:54 --> Config Class Initialized
INFO - 2022-01-19 06:02:54 --> Hooks Class Initialized
DEBUG - 2022-01-19 06:02:54 --> UTF-8 Support Enabled
INFO - 2022-01-19 06:02:54 --> Utf8 Class Initialized
INFO - 2022-01-19 06:02:54 --> URI Class Initialized
INFO - 2022-01-19 06:02:54 --> Router Class Initialized
INFO - 2022-01-19 06:02:54 --> Output Class Initialized
INFO - 2022-01-19 06:02:54 --> Security Class Initialized
DEBUG - 2022-01-19 06:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 06:02:54 --> Input Class Initialized
INFO - 2022-01-19 06:02:54 --> Language Class Initialized
INFO - 2022-01-19 06:02:54 --> Language Class Initialized
INFO - 2022-01-19 06:02:54 --> Config Class Initialized
INFO - 2022-01-19 06:02:54 --> Loader Class Initialized
INFO - 2022-01-19 06:02:54 --> Helper loaded: url_helper
INFO - 2022-01-19 06:02:54 --> Helper loaded: file_helper
INFO - 2022-01-19 06:02:54 --> Helper loaded: form_helper
INFO - 2022-01-19 06:02:54 --> Helper loaded: my_helper
INFO - 2022-01-19 06:02:54 --> Database Driver Class Initialized
DEBUG - 2022-01-19 06:02:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 06:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 06:02:54 --> Controller Class Initialized
DEBUG - 2022-01-19 06:02:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2022-01-19 06:02:54 --> Final output sent to browser
DEBUG - 2022-01-19 06:02:54 --> Total execution time: 0.1340
INFO - 2022-01-19 06:02:56 --> Config Class Initialized
INFO - 2022-01-19 06:02:56 --> Hooks Class Initialized
DEBUG - 2022-01-19 06:02:56 --> UTF-8 Support Enabled
INFO - 2022-01-19 06:02:56 --> Utf8 Class Initialized
INFO - 2022-01-19 06:02:56 --> URI Class Initialized
INFO - 2022-01-19 06:02:56 --> Router Class Initialized
INFO - 2022-01-19 06:02:56 --> Output Class Initialized
INFO - 2022-01-19 06:02:56 --> Security Class Initialized
DEBUG - 2022-01-19 06:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 06:02:56 --> Input Class Initialized
INFO - 2022-01-19 06:02:56 --> Language Class Initialized
INFO - 2022-01-19 06:02:56 --> Language Class Initialized
INFO - 2022-01-19 06:02:56 --> Config Class Initialized
INFO - 2022-01-19 06:02:56 --> Loader Class Initialized
INFO - 2022-01-19 06:02:56 --> Helper loaded: url_helper
INFO - 2022-01-19 06:02:56 --> Helper loaded: file_helper
INFO - 2022-01-19 06:02:56 --> Helper loaded: form_helper
INFO - 2022-01-19 06:02:56 --> Helper loaded: my_helper
INFO - 2022-01-19 06:02:56 --> Database Driver Class Initialized
DEBUG - 2022-01-19 06:02:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 06:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 06:02:56 --> Controller Class Initialized
DEBUG - 2022-01-19 06:02:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2022-01-19 06:02:56 --> Final output sent to browser
DEBUG - 2022-01-19 06:02:56 --> Total execution time: 0.1340
INFO - 2022-01-19 06:02:59 --> Config Class Initialized
INFO - 2022-01-19 06:02:59 --> Hooks Class Initialized
DEBUG - 2022-01-19 06:02:59 --> UTF-8 Support Enabled
INFO - 2022-01-19 06:02:59 --> Utf8 Class Initialized
INFO - 2022-01-19 06:02:59 --> URI Class Initialized
INFO - 2022-01-19 06:02:59 --> Router Class Initialized
INFO - 2022-01-19 06:02:59 --> Output Class Initialized
INFO - 2022-01-19 06:02:59 --> Security Class Initialized
DEBUG - 2022-01-19 06:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 06:02:59 --> Input Class Initialized
INFO - 2022-01-19 06:02:59 --> Language Class Initialized
INFO - 2022-01-19 06:02:59 --> Language Class Initialized
INFO - 2022-01-19 06:02:59 --> Config Class Initialized
INFO - 2022-01-19 06:02:59 --> Loader Class Initialized
INFO - 2022-01-19 06:02:59 --> Helper loaded: url_helper
INFO - 2022-01-19 06:02:59 --> Helper loaded: file_helper
INFO - 2022-01-19 06:02:59 --> Helper loaded: form_helper
INFO - 2022-01-19 06:02:59 --> Helper loaded: my_helper
INFO - 2022-01-19 06:02:59 --> Database Driver Class Initialized
DEBUG - 2022-01-19 06:02:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 06:02:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 06:02:59 --> Controller Class Initialized
DEBUG - 2022-01-19 06:02:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2022-01-19 06:02:59 --> Final output sent to browser
DEBUG - 2022-01-19 06:02:59 --> Total execution time: 0.1400
INFO - 2022-01-19 06:03:01 --> Config Class Initialized
INFO - 2022-01-19 06:03:01 --> Hooks Class Initialized
DEBUG - 2022-01-19 06:03:01 --> UTF-8 Support Enabled
INFO - 2022-01-19 06:03:01 --> Utf8 Class Initialized
INFO - 2022-01-19 06:03:01 --> URI Class Initialized
INFO - 2022-01-19 06:03:01 --> Router Class Initialized
INFO - 2022-01-19 06:03:01 --> Output Class Initialized
INFO - 2022-01-19 06:03:01 --> Security Class Initialized
DEBUG - 2022-01-19 06:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 06:03:01 --> Input Class Initialized
INFO - 2022-01-19 06:03:01 --> Language Class Initialized
INFO - 2022-01-19 06:03:01 --> Language Class Initialized
INFO - 2022-01-19 06:03:01 --> Config Class Initialized
INFO - 2022-01-19 06:03:01 --> Loader Class Initialized
INFO - 2022-01-19 06:03:01 --> Helper loaded: url_helper
INFO - 2022-01-19 06:03:01 --> Helper loaded: file_helper
INFO - 2022-01-19 06:03:01 --> Helper loaded: form_helper
INFO - 2022-01-19 06:03:01 --> Helper loaded: my_helper
INFO - 2022-01-19 06:03:01 --> Database Driver Class Initialized
DEBUG - 2022-01-19 06:03:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 06:03:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 06:03:01 --> Controller Class Initialized
DEBUG - 2022-01-19 06:03:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2022-01-19 06:03:01 --> Final output sent to browser
DEBUG - 2022-01-19 06:03:01 --> Total execution time: 0.1420
INFO - 2022-01-19 06:03:04 --> Config Class Initialized
INFO - 2022-01-19 06:03:04 --> Hooks Class Initialized
DEBUG - 2022-01-19 06:03:04 --> UTF-8 Support Enabled
INFO - 2022-01-19 06:03:04 --> Utf8 Class Initialized
INFO - 2022-01-19 06:03:04 --> URI Class Initialized
INFO - 2022-01-19 06:03:04 --> Router Class Initialized
INFO - 2022-01-19 06:03:04 --> Output Class Initialized
INFO - 2022-01-19 06:03:04 --> Security Class Initialized
DEBUG - 2022-01-19 06:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 06:03:04 --> Input Class Initialized
INFO - 2022-01-19 06:03:04 --> Language Class Initialized
INFO - 2022-01-19 06:03:04 --> Language Class Initialized
INFO - 2022-01-19 06:03:04 --> Config Class Initialized
INFO - 2022-01-19 06:03:04 --> Loader Class Initialized
INFO - 2022-01-19 06:03:04 --> Helper loaded: url_helper
INFO - 2022-01-19 06:03:04 --> Helper loaded: file_helper
INFO - 2022-01-19 06:03:04 --> Helper loaded: form_helper
INFO - 2022-01-19 06:03:04 --> Helper loaded: my_helper
INFO - 2022-01-19 06:03:04 --> Database Driver Class Initialized
DEBUG - 2022-01-19 06:03:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 06:03:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 06:03:04 --> Controller Class Initialized
DEBUG - 2022-01-19 06:03:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2022-01-19 06:03:04 --> Final output sent to browser
DEBUG - 2022-01-19 06:03:04 --> Total execution time: 0.1790
INFO - 2022-01-19 06:03:06 --> Config Class Initialized
INFO - 2022-01-19 06:03:06 --> Hooks Class Initialized
DEBUG - 2022-01-19 06:03:06 --> UTF-8 Support Enabled
INFO - 2022-01-19 06:03:06 --> Utf8 Class Initialized
INFO - 2022-01-19 06:03:06 --> URI Class Initialized
INFO - 2022-01-19 06:03:06 --> Router Class Initialized
INFO - 2022-01-19 06:03:06 --> Output Class Initialized
INFO - 2022-01-19 06:03:06 --> Security Class Initialized
DEBUG - 2022-01-19 06:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 06:03:06 --> Input Class Initialized
INFO - 2022-01-19 06:03:06 --> Language Class Initialized
INFO - 2022-01-19 06:03:06 --> Language Class Initialized
INFO - 2022-01-19 06:03:06 --> Config Class Initialized
INFO - 2022-01-19 06:03:06 --> Loader Class Initialized
INFO - 2022-01-19 06:03:06 --> Helper loaded: url_helper
INFO - 2022-01-19 06:03:06 --> Helper loaded: file_helper
INFO - 2022-01-19 06:03:06 --> Helper loaded: form_helper
INFO - 2022-01-19 06:03:06 --> Helper loaded: my_helper
INFO - 2022-01-19 06:03:06 --> Database Driver Class Initialized
DEBUG - 2022-01-19 06:03:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 06:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 06:03:06 --> Controller Class Initialized
DEBUG - 2022-01-19 06:03:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2022-01-19 06:03:06 --> Final output sent to browser
DEBUG - 2022-01-19 06:03:06 --> Total execution time: 0.1360
INFO - 2022-01-19 06:03:08 --> Config Class Initialized
INFO - 2022-01-19 06:03:08 --> Hooks Class Initialized
DEBUG - 2022-01-19 06:03:08 --> UTF-8 Support Enabled
INFO - 2022-01-19 06:03:08 --> Utf8 Class Initialized
INFO - 2022-01-19 06:03:08 --> URI Class Initialized
INFO - 2022-01-19 06:03:08 --> Router Class Initialized
INFO - 2022-01-19 06:03:08 --> Output Class Initialized
INFO - 2022-01-19 06:03:08 --> Security Class Initialized
DEBUG - 2022-01-19 06:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 06:03:08 --> Input Class Initialized
INFO - 2022-01-19 06:03:08 --> Language Class Initialized
INFO - 2022-01-19 06:03:08 --> Language Class Initialized
INFO - 2022-01-19 06:03:08 --> Config Class Initialized
INFO - 2022-01-19 06:03:08 --> Loader Class Initialized
INFO - 2022-01-19 06:03:08 --> Helper loaded: url_helper
INFO - 2022-01-19 06:03:08 --> Helper loaded: file_helper
INFO - 2022-01-19 06:03:08 --> Helper loaded: form_helper
INFO - 2022-01-19 06:03:08 --> Helper loaded: my_helper
INFO - 2022-01-19 06:03:08 --> Database Driver Class Initialized
DEBUG - 2022-01-19 06:03:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 06:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 06:03:08 --> Controller Class Initialized
DEBUG - 2022-01-19 06:03:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2022-01-19 06:03:09 --> Final output sent to browser
DEBUG - 2022-01-19 06:03:09 --> Total execution time: 0.1730
INFO - 2022-01-19 06:03:11 --> Config Class Initialized
INFO - 2022-01-19 06:03:11 --> Hooks Class Initialized
DEBUG - 2022-01-19 06:03:11 --> UTF-8 Support Enabled
INFO - 2022-01-19 06:03:11 --> Utf8 Class Initialized
INFO - 2022-01-19 06:03:11 --> URI Class Initialized
INFO - 2022-01-19 06:03:11 --> Router Class Initialized
INFO - 2022-01-19 06:03:11 --> Output Class Initialized
INFO - 2022-01-19 06:03:11 --> Security Class Initialized
DEBUG - 2022-01-19 06:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 06:03:11 --> Input Class Initialized
INFO - 2022-01-19 06:03:11 --> Language Class Initialized
INFO - 2022-01-19 06:03:11 --> Language Class Initialized
INFO - 2022-01-19 06:03:11 --> Config Class Initialized
INFO - 2022-01-19 06:03:11 --> Loader Class Initialized
INFO - 2022-01-19 06:03:11 --> Helper loaded: url_helper
INFO - 2022-01-19 06:03:11 --> Helper loaded: file_helper
INFO - 2022-01-19 06:03:11 --> Helper loaded: form_helper
INFO - 2022-01-19 06:03:11 --> Helper loaded: my_helper
INFO - 2022-01-19 06:03:11 --> Database Driver Class Initialized
DEBUG - 2022-01-19 06:03:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 06:03:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 06:03:11 --> Controller Class Initialized
DEBUG - 2022-01-19 06:03:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2022-01-19 06:03:11 --> Final output sent to browser
DEBUG - 2022-01-19 06:03:11 --> Total execution time: 0.1420
INFO - 2022-01-19 06:03:13 --> Config Class Initialized
INFO - 2022-01-19 06:03:13 --> Hooks Class Initialized
DEBUG - 2022-01-19 06:03:13 --> UTF-8 Support Enabled
INFO - 2022-01-19 06:03:13 --> Utf8 Class Initialized
INFO - 2022-01-19 06:03:13 --> URI Class Initialized
INFO - 2022-01-19 06:03:13 --> Router Class Initialized
INFO - 2022-01-19 06:03:13 --> Output Class Initialized
INFO - 2022-01-19 06:03:13 --> Security Class Initialized
DEBUG - 2022-01-19 06:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 06:03:13 --> Input Class Initialized
INFO - 2022-01-19 06:03:13 --> Language Class Initialized
INFO - 2022-01-19 06:03:13 --> Language Class Initialized
INFO - 2022-01-19 06:03:13 --> Config Class Initialized
INFO - 2022-01-19 06:03:13 --> Loader Class Initialized
INFO - 2022-01-19 06:03:13 --> Helper loaded: url_helper
INFO - 2022-01-19 06:03:13 --> Helper loaded: file_helper
INFO - 2022-01-19 06:03:13 --> Helper loaded: form_helper
INFO - 2022-01-19 06:03:13 --> Helper loaded: my_helper
INFO - 2022-01-19 06:03:13 --> Database Driver Class Initialized
DEBUG - 2022-01-19 06:03:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 06:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 06:03:13 --> Controller Class Initialized
DEBUG - 2022-01-19 06:03:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2022-01-19 06:03:13 --> Final output sent to browser
DEBUG - 2022-01-19 06:03:13 --> Total execution time: 0.1640
INFO - 2022-01-19 06:03:15 --> Config Class Initialized
INFO - 2022-01-19 06:03:15 --> Hooks Class Initialized
DEBUG - 2022-01-19 06:03:15 --> UTF-8 Support Enabled
INFO - 2022-01-19 06:03:15 --> Utf8 Class Initialized
INFO - 2022-01-19 06:03:15 --> URI Class Initialized
INFO - 2022-01-19 06:03:15 --> Router Class Initialized
INFO - 2022-01-19 06:03:15 --> Output Class Initialized
INFO - 2022-01-19 06:03:15 --> Security Class Initialized
DEBUG - 2022-01-19 06:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 06:03:15 --> Input Class Initialized
INFO - 2022-01-19 06:03:15 --> Language Class Initialized
INFO - 2022-01-19 06:03:15 --> Language Class Initialized
INFO - 2022-01-19 06:03:15 --> Config Class Initialized
INFO - 2022-01-19 06:03:15 --> Loader Class Initialized
INFO - 2022-01-19 06:03:15 --> Helper loaded: url_helper
INFO - 2022-01-19 06:03:15 --> Helper loaded: file_helper
INFO - 2022-01-19 06:03:15 --> Helper loaded: form_helper
INFO - 2022-01-19 06:03:15 --> Helper loaded: my_helper
INFO - 2022-01-19 06:03:15 --> Database Driver Class Initialized
DEBUG - 2022-01-19 06:03:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 06:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 06:03:15 --> Controller Class Initialized
DEBUG - 2022-01-19 06:03:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2022-01-19 06:03:15 --> Final output sent to browser
DEBUG - 2022-01-19 06:03:15 --> Total execution time: 0.1380
INFO - 2022-01-19 06:03:18 --> Config Class Initialized
INFO - 2022-01-19 06:03:18 --> Hooks Class Initialized
DEBUG - 2022-01-19 06:03:18 --> UTF-8 Support Enabled
INFO - 2022-01-19 06:03:18 --> Utf8 Class Initialized
INFO - 2022-01-19 06:03:18 --> URI Class Initialized
INFO - 2022-01-19 06:03:18 --> Router Class Initialized
INFO - 2022-01-19 06:03:18 --> Output Class Initialized
INFO - 2022-01-19 06:03:18 --> Security Class Initialized
DEBUG - 2022-01-19 06:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 06:03:18 --> Input Class Initialized
INFO - 2022-01-19 06:03:18 --> Language Class Initialized
INFO - 2022-01-19 06:03:18 --> Language Class Initialized
INFO - 2022-01-19 06:03:18 --> Config Class Initialized
INFO - 2022-01-19 06:03:18 --> Loader Class Initialized
INFO - 2022-01-19 06:03:18 --> Helper loaded: url_helper
INFO - 2022-01-19 06:03:18 --> Helper loaded: file_helper
INFO - 2022-01-19 06:03:18 --> Helper loaded: form_helper
INFO - 2022-01-19 06:03:18 --> Helper loaded: my_helper
INFO - 2022-01-19 06:03:18 --> Database Driver Class Initialized
DEBUG - 2022-01-19 06:03:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 06:03:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 06:03:18 --> Controller Class Initialized
DEBUG - 2022-01-19 06:03:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2022-01-19 06:03:18 --> Final output sent to browser
DEBUG - 2022-01-19 06:03:18 --> Total execution time: 0.1310
INFO - 2022-01-19 06:03:20 --> Config Class Initialized
INFO - 2022-01-19 06:03:20 --> Hooks Class Initialized
DEBUG - 2022-01-19 06:03:20 --> UTF-8 Support Enabled
INFO - 2022-01-19 06:03:20 --> Utf8 Class Initialized
INFO - 2022-01-19 06:03:20 --> URI Class Initialized
INFO - 2022-01-19 06:03:20 --> Router Class Initialized
INFO - 2022-01-19 06:03:20 --> Output Class Initialized
INFO - 2022-01-19 06:03:20 --> Security Class Initialized
DEBUG - 2022-01-19 06:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 06:03:20 --> Input Class Initialized
INFO - 2022-01-19 06:03:20 --> Language Class Initialized
INFO - 2022-01-19 06:03:20 --> Language Class Initialized
INFO - 2022-01-19 06:03:20 --> Config Class Initialized
INFO - 2022-01-19 06:03:20 --> Loader Class Initialized
INFO - 2022-01-19 06:03:20 --> Helper loaded: url_helper
INFO - 2022-01-19 06:03:20 --> Helper loaded: file_helper
INFO - 2022-01-19 06:03:20 --> Helper loaded: form_helper
INFO - 2022-01-19 06:03:20 --> Helper loaded: my_helper
INFO - 2022-01-19 06:03:20 --> Database Driver Class Initialized
DEBUG - 2022-01-19 06:03:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 06:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 06:03:20 --> Controller Class Initialized
DEBUG - 2022-01-19 06:03:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2022-01-19 06:03:20 --> Final output sent to browser
DEBUG - 2022-01-19 06:03:20 --> Total execution time: 0.1400
INFO - 2022-01-19 06:03:23 --> Config Class Initialized
INFO - 2022-01-19 06:03:23 --> Hooks Class Initialized
DEBUG - 2022-01-19 06:03:23 --> UTF-8 Support Enabled
INFO - 2022-01-19 06:03:23 --> Utf8 Class Initialized
INFO - 2022-01-19 06:03:23 --> URI Class Initialized
INFO - 2022-01-19 06:03:23 --> Router Class Initialized
INFO - 2022-01-19 06:03:23 --> Output Class Initialized
INFO - 2022-01-19 06:03:23 --> Security Class Initialized
DEBUG - 2022-01-19 06:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 06:03:23 --> Input Class Initialized
INFO - 2022-01-19 06:03:23 --> Language Class Initialized
INFO - 2022-01-19 06:03:23 --> Language Class Initialized
INFO - 2022-01-19 06:03:23 --> Config Class Initialized
INFO - 2022-01-19 06:03:23 --> Loader Class Initialized
INFO - 2022-01-19 06:03:23 --> Helper loaded: url_helper
INFO - 2022-01-19 06:03:23 --> Helper loaded: file_helper
INFO - 2022-01-19 06:03:23 --> Helper loaded: form_helper
INFO - 2022-01-19 06:03:23 --> Helper loaded: my_helper
INFO - 2022-01-19 06:03:23 --> Database Driver Class Initialized
DEBUG - 2022-01-19 06:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 06:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 06:03:23 --> Controller Class Initialized
DEBUG - 2022-01-19 06:03:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2022-01-19 06:03:23 --> Final output sent to browser
DEBUG - 2022-01-19 06:03:23 --> Total execution time: 0.1530
INFO - 2022-01-19 06:03:26 --> Config Class Initialized
INFO - 2022-01-19 06:03:26 --> Hooks Class Initialized
DEBUG - 2022-01-19 06:03:26 --> UTF-8 Support Enabled
INFO - 2022-01-19 06:03:26 --> Utf8 Class Initialized
INFO - 2022-01-19 06:03:26 --> URI Class Initialized
INFO - 2022-01-19 06:03:26 --> Router Class Initialized
INFO - 2022-01-19 06:03:26 --> Output Class Initialized
INFO - 2022-01-19 06:03:26 --> Security Class Initialized
DEBUG - 2022-01-19 06:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 06:03:26 --> Input Class Initialized
INFO - 2022-01-19 06:03:26 --> Language Class Initialized
INFO - 2022-01-19 06:03:26 --> Language Class Initialized
INFO - 2022-01-19 06:03:26 --> Config Class Initialized
INFO - 2022-01-19 06:03:26 --> Loader Class Initialized
INFO - 2022-01-19 06:03:26 --> Helper loaded: url_helper
INFO - 2022-01-19 06:03:26 --> Helper loaded: file_helper
INFO - 2022-01-19 06:03:26 --> Helper loaded: form_helper
INFO - 2022-01-19 06:03:26 --> Helper loaded: my_helper
INFO - 2022-01-19 06:03:26 --> Database Driver Class Initialized
DEBUG - 2022-01-19 06:03:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 06:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 06:03:26 --> Controller Class Initialized
DEBUG - 2022-01-19 06:03:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2022-01-19 06:03:26 --> Final output sent to browser
DEBUG - 2022-01-19 06:03:26 --> Total execution time: 0.1320
