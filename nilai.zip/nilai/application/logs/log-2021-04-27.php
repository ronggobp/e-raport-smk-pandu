<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-04-27 06:28:25 --> Config Class Initialized
INFO - 2021-04-27 06:28:25 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:28:25 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:28:25 --> Utf8 Class Initialized
INFO - 2021-04-27 06:28:25 --> URI Class Initialized
DEBUG - 2021-04-27 06:28:25 --> No URI present. Default controller set.
INFO - 2021-04-27 06:28:25 --> Router Class Initialized
INFO - 2021-04-27 06:28:25 --> Output Class Initialized
INFO - 2021-04-27 06:28:25 --> Security Class Initialized
DEBUG - 2021-04-27 06:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:28:25 --> Input Class Initialized
INFO - 2021-04-27 06:28:25 --> Language Class Initialized
INFO - 2021-04-27 06:28:25 --> Language Class Initialized
INFO - 2021-04-27 06:28:25 --> Config Class Initialized
INFO - 2021-04-27 06:28:25 --> Loader Class Initialized
INFO - 2021-04-27 06:28:25 --> Helper loaded: url_helper
INFO - 2021-04-27 06:28:25 --> Helper loaded: file_helper
INFO - 2021-04-27 06:28:25 --> Helper loaded: form_helper
INFO - 2021-04-27 06:28:25 --> Helper loaded: my_helper
INFO - 2021-04-27 06:28:25 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:28:25 --> Controller Class Initialized
INFO - 2021-04-27 06:28:25 --> Config Class Initialized
INFO - 2021-04-27 06:28:25 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:28:25 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:28:25 --> Utf8 Class Initialized
INFO - 2021-04-27 06:28:25 --> URI Class Initialized
INFO - 2021-04-27 06:28:25 --> Router Class Initialized
INFO - 2021-04-27 06:28:25 --> Output Class Initialized
INFO - 2021-04-27 06:28:25 --> Security Class Initialized
DEBUG - 2021-04-27 06:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:28:25 --> Input Class Initialized
INFO - 2021-04-27 06:28:25 --> Language Class Initialized
INFO - 2021-04-27 06:28:25 --> Language Class Initialized
INFO - 2021-04-27 06:28:25 --> Config Class Initialized
INFO - 2021-04-27 06:28:25 --> Loader Class Initialized
INFO - 2021-04-27 06:28:25 --> Helper loaded: url_helper
INFO - 2021-04-27 06:28:25 --> Helper loaded: file_helper
INFO - 2021-04-27 06:28:25 --> Helper loaded: form_helper
INFO - 2021-04-27 06:28:25 --> Helper loaded: my_helper
INFO - 2021-04-27 06:28:25 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:28:25 --> Controller Class Initialized
DEBUG - 2021-04-27 06:28:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-04-27 06:28:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 06:28:25 --> Final output sent to browser
DEBUG - 2021-04-27 06:28:25 --> Total execution time: 0.1002
INFO - 2021-04-27 06:28:31 --> Config Class Initialized
INFO - 2021-04-27 06:28:31 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:28:31 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:28:31 --> Utf8 Class Initialized
INFO - 2021-04-27 06:28:31 --> URI Class Initialized
INFO - 2021-04-27 06:28:31 --> Router Class Initialized
INFO - 2021-04-27 06:28:31 --> Output Class Initialized
INFO - 2021-04-27 06:28:31 --> Security Class Initialized
DEBUG - 2021-04-27 06:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:28:31 --> Input Class Initialized
INFO - 2021-04-27 06:28:31 --> Language Class Initialized
INFO - 2021-04-27 06:28:31 --> Language Class Initialized
INFO - 2021-04-27 06:28:31 --> Config Class Initialized
INFO - 2021-04-27 06:28:31 --> Loader Class Initialized
INFO - 2021-04-27 06:28:31 --> Helper loaded: url_helper
INFO - 2021-04-27 06:28:31 --> Helper loaded: file_helper
INFO - 2021-04-27 06:28:31 --> Helper loaded: form_helper
INFO - 2021-04-27 06:28:31 --> Helper loaded: my_helper
INFO - 2021-04-27 06:28:31 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:28:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:28:31 --> Controller Class Initialized
INFO - 2021-04-27 06:28:31 --> Helper loaded: cookie_helper
INFO - 2021-04-27 06:28:31 --> Final output sent to browser
DEBUG - 2021-04-27 06:28:31 --> Total execution time: 0.1672
INFO - 2021-04-27 06:28:32 --> Config Class Initialized
INFO - 2021-04-27 06:28:32 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:28:32 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:28:32 --> Utf8 Class Initialized
INFO - 2021-04-27 06:28:32 --> URI Class Initialized
INFO - 2021-04-27 06:28:32 --> Router Class Initialized
INFO - 2021-04-27 06:28:32 --> Output Class Initialized
INFO - 2021-04-27 06:28:32 --> Security Class Initialized
DEBUG - 2021-04-27 06:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:28:32 --> Input Class Initialized
INFO - 2021-04-27 06:28:32 --> Language Class Initialized
INFO - 2021-04-27 06:28:32 --> Language Class Initialized
INFO - 2021-04-27 06:28:32 --> Config Class Initialized
INFO - 2021-04-27 06:28:32 --> Loader Class Initialized
INFO - 2021-04-27 06:28:32 --> Helper loaded: url_helper
INFO - 2021-04-27 06:28:32 --> Helper loaded: file_helper
INFO - 2021-04-27 06:28:32 --> Helper loaded: form_helper
INFO - 2021-04-27 06:28:32 --> Helper loaded: my_helper
INFO - 2021-04-27 06:28:32 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:28:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:28:32 --> Controller Class Initialized
DEBUG - 2021-04-27 06:28:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-04-27 06:28:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 06:28:32 --> Final output sent to browser
DEBUG - 2021-04-27 06:28:32 --> Total execution time: 0.2056
INFO - 2021-04-27 06:28:53 --> Config Class Initialized
INFO - 2021-04-27 06:28:53 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:28:53 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:28:53 --> Utf8 Class Initialized
INFO - 2021-04-27 06:28:53 --> URI Class Initialized
INFO - 2021-04-27 06:28:53 --> Router Class Initialized
INFO - 2021-04-27 06:28:53 --> Output Class Initialized
INFO - 2021-04-27 06:28:53 --> Security Class Initialized
DEBUG - 2021-04-27 06:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:28:53 --> Input Class Initialized
INFO - 2021-04-27 06:28:53 --> Language Class Initialized
INFO - 2021-04-27 06:28:53 --> Language Class Initialized
INFO - 2021-04-27 06:28:53 --> Config Class Initialized
INFO - 2021-04-27 06:28:53 --> Loader Class Initialized
INFO - 2021-04-27 06:28:53 --> Helper loaded: url_helper
INFO - 2021-04-27 06:28:53 --> Helper loaded: file_helper
INFO - 2021-04-27 06:28:53 --> Helper loaded: form_helper
INFO - 2021-04-27 06:28:53 --> Helper loaded: my_helper
INFO - 2021-04-27 06:28:53 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:28:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:28:53 --> Controller Class Initialized
DEBUG - 2021-04-27 06:28:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-27 06:28:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 06:28:53 --> Final output sent to browser
DEBUG - 2021-04-27 06:28:53 --> Total execution time: 0.1272
INFO - 2021-04-27 06:28:55 --> Config Class Initialized
INFO - 2021-04-27 06:28:55 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:28:55 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:28:55 --> Utf8 Class Initialized
INFO - 2021-04-27 06:28:55 --> URI Class Initialized
INFO - 2021-04-27 06:28:55 --> Router Class Initialized
INFO - 2021-04-27 06:28:55 --> Output Class Initialized
INFO - 2021-04-27 06:28:55 --> Security Class Initialized
DEBUG - 2021-04-27 06:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:28:55 --> Input Class Initialized
INFO - 2021-04-27 06:28:55 --> Language Class Initialized
INFO - 2021-04-27 06:28:55 --> Language Class Initialized
INFO - 2021-04-27 06:28:55 --> Config Class Initialized
INFO - 2021-04-27 06:28:55 --> Loader Class Initialized
INFO - 2021-04-27 06:28:55 --> Helper loaded: url_helper
INFO - 2021-04-27 06:28:55 --> Helper loaded: file_helper
INFO - 2021-04-27 06:28:55 --> Helper loaded: form_helper
INFO - 2021-04-27 06:28:55 --> Helper loaded: my_helper
INFO - 2021-04-27 06:28:55 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:28:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:28:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:28:55 --> Controller Class Initialized
DEBUG - 2021-04-27 06:28:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-04-27 06:28:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 06:28:55 --> Final output sent to browser
DEBUG - 2021-04-27 06:28:55 --> Total execution time: 0.1956
INFO - 2021-04-27 06:29:00 --> Config Class Initialized
INFO - 2021-04-27 06:29:00 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:29:00 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:29:00 --> Utf8 Class Initialized
INFO - 2021-04-27 06:29:00 --> URI Class Initialized
INFO - 2021-04-27 06:29:00 --> Router Class Initialized
INFO - 2021-04-27 06:29:00 --> Output Class Initialized
INFO - 2021-04-27 06:29:00 --> Security Class Initialized
DEBUG - 2021-04-27 06:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:29:00 --> Input Class Initialized
INFO - 2021-04-27 06:29:00 --> Language Class Initialized
INFO - 2021-04-27 06:29:00 --> Language Class Initialized
INFO - 2021-04-27 06:29:00 --> Config Class Initialized
INFO - 2021-04-27 06:29:00 --> Loader Class Initialized
INFO - 2021-04-27 06:29:00 --> Helper loaded: url_helper
INFO - 2021-04-27 06:29:00 --> Helper loaded: file_helper
INFO - 2021-04-27 06:29:00 --> Helper loaded: form_helper
INFO - 2021-04-27 06:29:00 --> Helper loaded: my_helper
INFO - 2021-04-27 06:29:00 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:29:00 --> Controller Class Initialized
DEBUG - 2021-04-27 06:29:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2021-04-27 06:29:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 06:29:00 --> Final output sent to browser
DEBUG - 2021-04-27 06:29:00 --> Total execution time: 0.1299
INFO - 2021-04-27 06:29:00 --> Config Class Initialized
INFO - 2021-04-27 06:29:00 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:29:00 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:29:00 --> Utf8 Class Initialized
INFO - 2021-04-27 06:29:00 --> URI Class Initialized
INFO - 2021-04-27 06:29:00 --> Router Class Initialized
INFO - 2021-04-27 06:29:00 --> Output Class Initialized
INFO - 2021-04-27 06:29:00 --> Security Class Initialized
DEBUG - 2021-04-27 06:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:29:00 --> Input Class Initialized
INFO - 2021-04-27 06:29:00 --> Language Class Initialized
INFO - 2021-04-27 06:29:00 --> Language Class Initialized
INFO - 2021-04-27 06:29:00 --> Config Class Initialized
INFO - 2021-04-27 06:29:00 --> Loader Class Initialized
INFO - 2021-04-27 06:29:00 --> Helper loaded: url_helper
INFO - 2021-04-27 06:29:00 --> Helper loaded: file_helper
INFO - 2021-04-27 06:29:00 --> Helper loaded: form_helper
INFO - 2021-04-27 06:29:00 --> Helper loaded: my_helper
INFO - 2021-04-27 06:29:00 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:29:00 --> Controller Class Initialized
INFO - 2021-04-27 06:29:01 --> Config Class Initialized
INFO - 2021-04-27 06:29:01 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:29:01 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:29:01 --> Utf8 Class Initialized
INFO - 2021-04-27 06:29:01 --> URI Class Initialized
INFO - 2021-04-27 06:29:01 --> Router Class Initialized
INFO - 2021-04-27 06:29:01 --> Output Class Initialized
INFO - 2021-04-27 06:29:01 --> Security Class Initialized
DEBUG - 2021-04-27 06:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:29:01 --> Input Class Initialized
INFO - 2021-04-27 06:29:01 --> Language Class Initialized
INFO - 2021-04-27 06:29:01 --> Language Class Initialized
INFO - 2021-04-27 06:29:01 --> Config Class Initialized
INFO - 2021-04-27 06:29:01 --> Loader Class Initialized
INFO - 2021-04-27 06:29:01 --> Helper loaded: url_helper
INFO - 2021-04-27 06:29:01 --> Helper loaded: file_helper
INFO - 2021-04-27 06:29:01 --> Helper loaded: form_helper
INFO - 2021-04-27 06:29:01 --> Helper loaded: my_helper
INFO - 2021-04-27 06:29:01 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:29:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:29:01 --> Controller Class Initialized
INFO - 2021-04-27 06:29:01 --> Final output sent to browser
DEBUG - 2021-04-27 06:29:01 --> Total execution time: 0.1125
INFO - 2021-04-27 06:29:07 --> Config Class Initialized
INFO - 2021-04-27 06:29:07 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:29:07 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:29:07 --> Utf8 Class Initialized
INFO - 2021-04-27 06:29:07 --> URI Class Initialized
INFO - 2021-04-27 06:29:07 --> Router Class Initialized
INFO - 2021-04-27 06:29:07 --> Output Class Initialized
INFO - 2021-04-27 06:29:07 --> Security Class Initialized
DEBUG - 2021-04-27 06:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:29:07 --> Input Class Initialized
INFO - 2021-04-27 06:29:07 --> Language Class Initialized
INFO - 2021-04-27 06:29:07 --> Language Class Initialized
INFO - 2021-04-27 06:29:07 --> Config Class Initialized
INFO - 2021-04-27 06:29:07 --> Loader Class Initialized
INFO - 2021-04-27 06:29:07 --> Helper loaded: url_helper
INFO - 2021-04-27 06:29:07 --> Helper loaded: file_helper
INFO - 2021-04-27 06:29:07 --> Helper loaded: form_helper
INFO - 2021-04-27 06:29:07 --> Helper loaded: my_helper
INFO - 2021-04-27 06:29:07 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:29:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:29:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:29:07 --> Controller Class Initialized
INFO - 2021-04-27 06:29:07 --> Final output sent to browser
DEBUG - 2021-04-27 06:29:07 --> Total execution time: 0.0941
INFO - 2021-04-27 06:29:07 --> Config Class Initialized
INFO - 2021-04-27 06:29:07 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:29:07 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:29:07 --> Utf8 Class Initialized
INFO - 2021-04-27 06:29:07 --> URI Class Initialized
INFO - 2021-04-27 06:29:07 --> Router Class Initialized
INFO - 2021-04-27 06:29:07 --> Output Class Initialized
INFO - 2021-04-27 06:29:07 --> Security Class Initialized
DEBUG - 2021-04-27 06:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:29:07 --> Input Class Initialized
INFO - 2021-04-27 06:29:07 --> Language Class Initialized
INFO - 2021-04-27 06:29:07 --> Language Class Initialized
INFO - 2021-04-27 06:29:07 --> Config Class Initialized
INFO - 2021-04-27 06:29:07 --> Loader Class Initialized
INFO - 2021-04-27 06:29:07 --> Helper loaded: url_helper
INFO - 2021-04-27 06:29:07 --> Helper loaded: file_helper
INFO - 2021-04-27 06:29:07 --> Helper loaded: form_helper
INFO - 2021-04-27 06:29:07 --> Helper loaded: my_helper
INFO - 2021-04-27 06:29:07 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:29:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:29:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:29:07 --> Controller Class Initialized
INFO - 2021-04-27 06:29:08 --> Config Class Initialized
INFO - 2021-04-27 06:29:08 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:29:08 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:29:08 --> Utf8 Class Initialized
INFO - 2021-04-27 06:29:08 --> URI Class Initialized
INFO - 2021-04-27 06:29:08 --> Router Class Initialized
INFO - 2021-04-27 06:29:08 --> Output Class Initialized
INFO - 2021-04-27 06:29:08 --> Security Class Initialized
DEBUG - 2021-04-27 06:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:29:08 --> Input Class Initialized
INFO - 2021-04-27 06:29:08 --> Language Class Initialized
INFO - 2021-04-27 06:29:08 --> Language Class Initialized
INFO - 2021-04-27 06:29:08 --> Config Class Initialized
INFO - 2021-04-27 06:29:08 --> Loader Class Initialized
INFO - 2021-04-27 06:29:08 --> Helper loaded: url_helper
INFO - 2021-04-27 06:29:08 --> Helper loaded: file_helper
INFO - 2021-04-27 06:29:08 --> Helper loaded: form_helper
INFO - 2021-04-27 06:29:08 --> Helper loaded: my_helper
INFO - 2021-04-27 06:29:08 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:29:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:29:08 --> Controller Class Initialized
INFO - 2021-04-27 06:29:08 --> Final output sent to browser
DEBUG - 2021-04-27 06:29:08 --> Total execution time: 0.1064
INFO - 2021-04-27 06:29:16 --> Config Class Initialized
INFO - 2021-04-27 06:29:16 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:29:16 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:29:16 --> Utf8 Class Initialized
INFO - 2021-04-27 06:29:16 --> URI Class Initialized
INFO - 2021-04-27 06:29:16 --> Router Class Initialized
INFO - 2021-04-27 06:29:16 --> Output Class Initialized
INFO - 2021-04-27 06:29:16 --> Security Class Initialized
DEBUG - 2021-04-27 06:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:29:16 --> Input Class Initialized
INFO - 2021-04-27 06:29:16 --> Language Class Initialized
INFO - 2021-04-27 06:29:16 --> Language Class Initialized
INFO - 2021-04-27 06:29:16 --> Config Class Initialized
INFO - 2021-04-27 06:29:16 --> Loader Class Initialized
INFO - 2021-04-27 06:29:16 --> Helper loaded: url_helper
INFO - 2021-04-27 06:29:16 --> Helper loaded: file_helper
INFO - 2021-04-27 06:29:16 --> Helper loaded: form_helper
INFO - 2021-04-27 06:29:16 --> Helper loaded: my_helper
INFO - 2021-04-27 06:29:16 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:29:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:29:16 --> Controller Class Initialized
INFO - 2021-04-27 06:29:16 --> Final output sent to browser
DEBUG - 2021-04-27 06:29:16 --> Total execution time: 0.1437
INFO - 2021-04-27 06:29:16 --> Config Class Initialized
INFO - 2021-04-27 06:29:16 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:29:16 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:29:16 --> Utf8 Class Initialized
INFO - 2021-04-27 06:29:16 --> URI Class Initialized
INFO - 2021-04-27 06:29:16 --> Router Class Initialized
INFO - 2021-04-27 06:29:16 --> Output Class Initialized
INFO - 2021-04-27 06:29:16 --> Security Class Initialized
DEBUG - 2021-04-27 06:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:29:16 --> Input Class Initialized
INFO - 2021-04-27 06:29:16 --> Language Class Initialized
INFO - 2021-04-27 06:29:16 --> Language Class Initialized
INFO - 2021-04-27 06:29:16 --> Config Class Initialized
INFO - 2021-04-27 06:29:16 --> Loader Class Initialized
INFO - 2021-04-27 06:29:16 --> Helper loaded: url_helper
INFO - 2021-04-27 06:29:16 --> Helper loaded: file_helper
INFO - 2021-04-27 06:29:16 --> Helper loaded: form_helper
INFO - 2021-04-27 06:29:16 --> Helper loaded: my_helper
INFO - 2021-04-27 06:29:16 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:29:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:29:16 --> Controller Class Initialized
INFO - 2021-04-27 06:29:18 --> Config Class Initialized
INFO - 2021-04-27 06:29:18 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:29:18 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:29:18 --> Utf8 Class Initialized
INFO - 2021-04-27 06:29:18 --> URI Class Initialized
INFO - 2021-04-27 06:29:18 --> Router Class Initialized
INFO - 2021-04-27 06:29:18 --> Output Class Initialized
INFO - 2021-04-27 06:29:18 --> Security Class Initialized
DEBUG - 2021-04-27 06:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:29:18 --> Input Class Initialized
INFO - 2021-04-27 06:29:18 --> Language Class Initialized
INFO - 2021-04-27 06:29:18 --> Language Class Initialized
INFO - 2021-04-27 06:29:18 --> Config Class Initialized
INFO - 2021-04-27 06:29:18 --> Loader Class Initialized
INFO - 2021-04-27 06:29:18 --> Helper loaded: url_helper
INFO - 2021-04-27 06:29:18 --> Helper loaded: file_helper
INFO - 2021-04-27 06:29:18 --> Helper loaded: form_helper
INFO - 2021-04-27 06:29:18 --> Helper loaded: my_helper
INFO - 2021-04-27 06:29:18 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:29:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:29:18 --> Controller Class Initialized
INFO - 2021-04-27 06:29:18 --> Final output sent to browser
DEBUG - 2021-04-27 06:29:18 --> Total execution time: 0.1244
INFO - 2021-04-27 06:29:26 --> Config Class Initialized
INFO - 2021-04-27 06:29:26 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:29:26 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:29:26 --> Utf8 Class Initialized
INFO - 2021-04-27 06:29:26 --> URI Class Initialized
INFO - 2021-04-27 06:29:26 --> Router Class Initialized
INFO - 2021-04-27 06:29:26 --> Output Class Initialized
INFO - 2021-04-27 06:29:26 --> Security Class Initialized
DEBUG - 2021-04-27 06:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:29:26 --> Input Class Initialized
INFO - 2021-04-27 06:29:26 --> Language Class Initialized
INFO - 2021-04-27 06:29:26 --> Language Class Initialized
INFO - 2021-04-27 06:29:26 --> Config Class Initialized
INFO - 2021-04-27 06:29:26 --> Loader Class Initialized
INFO - 2021-04-27 06:29:26 --> Helper loaded: url_helper
INFO - 2021-04-27 06:29:26 --> Helper loaded: file_helper
INFO - 2021-04-27 06:29:26 --> Helper loaded: form_helper
INFO - 2021-04-27 06:29:26 --> Helper loaded: my_helper
INFO - 2021-04-27 06:29:26 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:29:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:29:26 --> Controller Class Initialized
INFO - 2021-04-27 06:29:26 --> Final output sent to browser
DEBUG - 2021-04-27 06:29:26 --> Total execution time: 0.1397
INFO - 2021-04-27 06:29:26 --> Config Class Initialized
INFO - 2021-04-27 06:29:26 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:29:26 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:29:26 --> Utf8 Class Initialized
INFO - 2021-04-27 06:29:26 --> URI Class Initialized
INFO - 2021-04-27 06:29:26 --> Router Class Initialized
INFO - 2021-04-27 06:29:26 --> Output Class Initialized
INFO - 2021-04-27 06:29:26 --> Security Class Initialized
DEBUG - 2021-04-27 06:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:29:26 --> Input Class Initialized
INFO - 2021-04-27 06:29:26 --> Language Class Initialized
INFO - 2021-04-27 06:29:26 --> Language Class Initialized
INFO - 2021-04-27 06:29:26 --> Config Class Initialized
INFO - 2021-04-27 06:29:26 --> Loader Class Initialized
INFO - 2021-04-27 06:29:26 --> Helper loaded: url_helper
INFO - 2021-04-27 06:29:26 --> Helper loaded: file_helper
INFO - 2021-04-27 06:29:26 --> Helper loaded: form_helper
INFO - 2021-04-27 06:29:26 --> Helper loaded: my_helper
INFO - 2021-04-27 06:29:26 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:29:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:29:26 --> Controller Class Initialized
INFO - 2021-04-27 06:29:28 --> Config Class Initialized
INFO - 2021-04-27 06:29:28 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:29:28 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:29:28 --> Utf8 Class Initialized
INFO - 2021-04-27 06:29:28 --> URI Class Initialized
INFO - 2021-04-27 06:29:28 --> Router Class Initialized
INFO - 2021-04-27 06:29:28 --> Output Class Initialized
INFO - 2021-04-27 06:29:28 --> Security Class Initialized
DEBUG - 2021-04-27 06:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:29:28 --> Input Class Initialized
INFO - 2021-04-27 06:29:28 --> Language Class Initialized
INFO - 2021-04-27 06:29:28 --> Language Class Initialized
INFO - 2021-04-27 06:29:28 --> Config Class Initialized
INFO - 2021-04-27 06:29:28 --> Loader Class Initialized
INFO - 2021-04-27 06:29:28 --> Helper loaded: url_helper
INFO - 2021-04-27 06:29:28 --> Helper loaded: file_helper
INFO - 2021-04-27 06:29:28 --> Helper loaded: form_helper
INFO - 2021-04-27 06:29:28 --> Helper loaded: my_helper
INFO - 2021-04-27 06:29:28 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:29:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:29:28 --> Controller Class Initialized
INFO - 2021-04-27 06:29:28 --> Final output sent to browser
DEBUG - 2021-04-27 06:29:28 --> Total execution time: 0.1196
INFO - 2021-04-27 06:29:32 --> Config Class Initialized
INFO - 2021-04-27 06:29:32 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:29:32 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:29:32 --> Utf8 Class Initialized
INFO - 2021-04-27 06:29:32 --> URI Class Initialized
INFO - 2021-04-27 06:29:32 --> Router Class Initialized
INFO - 2021-04-27 06:29:32 --> Output Class Initialized
INFO - 2021-04-27 06:29:32 --> Security Class Initialized
DEBUG - 2021-04-27 06:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:29:32 --> Input Class Initialized
INFO - 2021-04-27 06:29:32 --> Language Class Initialized
INFO - 2021-04-27 06:29:32 --> Language Class Initialized
INFO - 2021-04-27 06:29:32 --> Config Class Initialized
INFO - 2021-04-27 06:29:32 --> Loader Class Initialized
INFO - 2021-04-27 06:29:32 --> Helper loaded: url_helper
INFO - 2021-04-27 06:29:32 --> Helper loaded: file_helper
INFO - 2021-04-27 06:29:32 --> Helper loaded: form_helper
INFO - 2021-04-27 06:29:32 --> Helper loaded: my_helper
INFO - 2021-04-27 06:29:32 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:29:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:29:32 --> Controller Class Initialized
INFO - 2021-04-27 06:29:32 --> Final output sent to browser
DEBUG - 2021-04-27 06:29:32 --> Total execution time: 0.1370
INFO - 2021-04-27 06:29:32 --> Config Class Initialized
INFO - 2021-04-27 06:29:32 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:29:32 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:29:32 --> Utf8 Class Initialized
INFO - 2021-04-27 06:29:32 --> URI Class Initialized
INFO - 2021-04-27 06:29:32 --> Router Class Initialized
INFO - 2021-04-27 06:29:32 --> Output Class Initialized
INFO - 2021-04-27 06:29:32 --> Security Class Initialized
DEBUG - 2021-04-27 06:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:29:32 --> Input Class Initialized
INFO - 2021-04-27 06:29:32 --> Language Class Initialized
INFO - 2021-04-27 06:29:32 --> Language Class Initialized
INFO - 2021-04-27 06:29:32 --> Config Class Initialized
INFO - 2021-04-27 06:29:32 --> Loader Class Initialized
INFO - 2021-04-27 06:29:32 --> Helper loaded: url_helper
INFO - 2021-04-27 06:29:32 --> Helper loaded: file_helper
INFO - 2021-04-27 06:29:32 --> Helper loaded: form_helper
INFO - 2021-04-27 06:29:32 --> Helper loaded: my_helper
INFO - 2021-04-27 06:29:32 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:29:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:29:32 --> Controller Class Initialized
INFO - 2021-04-27 06:29:34 --> Config Class Initialized
INFO - 2021-04-27 06:29:34 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:29:34 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:29:34 --> Utf8 Class Initialized
INFO - 2021-04-27 06:29:34 --> URI Class Initialized
INFO - 2021-04-27 06:29:34 --> Router Class Initialized
INFO - 2021-04-27 06:29:34 --> Output Class Initialized
INFO - 2021-04-27 06:29:34 --> Security Class Initialized
DEBUG - 2021-04-27 06:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:29:34 --> Input Class Initialized
INFO - 2021-04-27 06:29:34 --> Language Class Initialized
INFO - 2021-04-27 06:29:34 --> Language Class Initialized
INFO - 2021-04-27 06:29:34 --> Config Class Initialized
INFO - 2021-04-27 06:29:34 --> Loader Class Initialized
INFO - 2021-04-27 06:29:34 --> Helper loaded: url_helper
INFO - 2021-04-27 06:29:34 --> Helper loaded: file_helper
INFO - 2021-04-27 06:29:34 --> Helper loaded: form_helper
INFO - 2021-04-27 06:29:34 --> Helper loaded: my_helper
INFO - 2021-04-27 06:29:34 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:29:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:29:34 --> Controller Class Initialized
INFO - 2021-04-27 06:29:34 --> Final output sent to browser
DEBUG - 2021-04-27 06:29:34 --> Total execution time: 0.1256
INFO - 2021-04-27 06:29:38 --> Config Class Initialized
INFO - 2021-04-27 06:29:38 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:29:38 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:29:38 --> Utf8 Class Initialized
INFO - 2021-04-27 06:29:38 --> URI Class Initialized
INFO - 2021-04-27 06:29:38 --> Router Class Initialized
INFO - 2021-04-27 06:29:38 --> Output Class Initialized
INFO - 2021-04-27 06:29:38 --> Security Class Initialized
DEBUG - 2021-04-27 06:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:29:38 --> Input Class Initialized
INFO - 2021-04-27 06:29:38 --> Language Class Initialized
INFO - 2021-04-27 06:29:38 --> Language Class Initialized
INFO - 2021-04-27 06:29:38 --> Config Class Initialized
INFO - 2021-04-27 06:29:38 --> Loader Class Initialized
INFO - 2021-04-27 06:29:38 --> Helper loaded: url_helper
INFO - 2021-04-27 06:29:38 --> Helper loaded: file_helper
INFO - 2021-04-27 06:29:38 --> Helper loaded: form_helper
INFO - 2021-04-27 06:29:38 --> Helper loaded: my_helper
INFO - 2021-04-27 06:29:38 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:29:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:29:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:29:38 --> Controller Class Initialized
INFO - 2021-04-27 06:29:38 --> Final output sent to browser
DEBUG - 2021-04-27 06:29:38 --> Total execution time: 0.1398
INFO - 2021-04-27 06:29:38 --> Config Class Initialized
INFO - 2021-04-27 06:29:38 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:29:38 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:29:38 --> Utf8 Class Initialized
INFO - 2021-04-27 06:29:38 --> URI Class Initialized
INFO - 2021-04-27 06:29:38 --> Router Class Initialized
INFO - 2021-04-27 06:29:38 --> Output Class Initialized
INFO - 2021-04-27 06:29:38 --> Security Class Initialized
DEBUG - 2021-04-27 06:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:29:38 --> Input Class Initialized
INFO - 2021-04-27 06:29:38 --> Language Class Initialized
INFO - 2021-04-27 06:29:38 --> Language Class Initialized
INFO - 2021-04-27 06:29:38 --> Config Class Initialized
INFO - 2021-04-27 06:29:38 --> Loader Class Initialized
INFO - 2021-04-27 06:29:38 --> Helper loaded: url_helper
INFO - 2021-04-27 06:29:38 --> Helper loaded: file_helper
INFO - 2021-04-27 06:29:38 --> Helper loaded: form_helper
INFO - 2021-04-27 06:29:38 --> Helper loaded: my_helper
INFO - 2021-04-27 06:29:38 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:29:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:29:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:29:38 --> Controller Class Initialized
INFO - 2021-04-27 06:29:39 --> Config Class Initialized
INFO - 2021-04-27 06:29:39 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:29:39 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:29:39 --> Utf8 Class Initialized
INFO - 2021-04-27 06:29:39 --> URI Class Initialized
INFO - 2021-04-27 06:29:39 --> Router Class Initialized
INFO - 2021-04-27 06:29:39 --> Output Class Initialized
INFO - 2021-04-27 06:29:39 --> Security Class Initialized
DEBUG - 2021-04-27 06:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:29:39 --> Input Class Initialized
INFO - 2021-04-27 06:29:39 --> Language Class Initialized
INFO - 2021-04-27 06:29:39 --> Language Class Initialized
INFO - 2021-04-27 06:29:39 --> Config Class Initialized
INFO - 2021-04-27 06:29:39 --> Loader Class Initialized
INFO - 2021-04-27 06:29:39 --> Helper loaded: url_helper
INFO - 2021-04-27 06:29:39 --> Helper loaded: file_helper
INFO - 2021-04-27 06:29:39 --> Helper loaded: form_helper
INFO - 2021-04-27 06:29:39 --> Helper loaded: my_helper
INFO - 2021-04-27 06:29:39 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:29:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:29:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:29:39 --> Controller Class Initialized
INFO - 2021-04-27 06:29:39 --> Final output sent to browser
DEBUG - 2021-04-27 06:29:39 --> Total execution time: 0.1647
INFO - 2021-04-27 06:29:45 --> Config Class Initialized
INFO - 2021-04-27 06:29:45 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:29:45 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:29:45 --> Utf8 Class Initialized
INFO - 2021-04-27 06:29:45 --> URI Class Initialized
INFO - 2021-04-27 06:29:45 --> Router Class Initialized
INFO - 2021-04-27 06:29:45 --> Output Class Initialized
INFO - 2021-04-27 06:29:45 --> Security Class Initialized
DEBUG - 2021-04-27 06:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:29:45 --> Input Class Initialized
INFO - 2021-04-27 06:29:45 --> Language Class Initialized
INFO - 2021-04-27 06:29:45 --> Language Class Initialized
INFO - 2021-04-27 06:29:45 --> Config Class Initialized
INFO - 2021-04-27 06:29:45 --> Loader Class Initialized
INFO - 2021-04-27 06:29:45 --> Helper loaded: url_helper
INFO - 2021-04-27 06:29:45 --> Helper loaded: file_helper
INFO - 2021-04-27 06:29:45 --> Helper loaded: form_helper
INFO - 2021-04-27 06:29:45 --> Helper loaded: my_helper
INFO - 2021-04-27 06:29:45 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:29:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:29:45 --> Controller Class Initialized
INFO - 2021-04-27 06:29:45 --> Final output sent to browser
DEBUG - 2021-04-27 06:29:45 --> Total execution time: 0.1340
INFO - 2021-04-27 06:29:45 --> Config Class Initialized
INFO - 2021-04-27 06:29:45 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:29:45 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:29:45 --> Utf8 Class Initialized
INFO - 2021-04-27 06:29:45 --> URI Class Initialized
INFO - 2021-04-27 06:29:45 --> Router Class Initialized
INFO - 2021-04-27 06:29:45 --> Output Class Initialized
INFO - 2021-04-27 06:29:45 --> Security Class Initialized
DEBUG - 2021-04-27 06:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:29:45 --> Input Class Initialized
INFO - 2021-04-27 06:29:45 --> Language Class Initialized
INFO - 2021-04-27 06:29:45 --> Language Class Initialized
INFO - 2021-04-27 06:29:45 --> Config Class Initialized
INFO - 2021-04-27 06:29:45 --> Loader Class Initialized
INFO - 2021-04-27 06:29:45 --> Helper loaded: url_helper
INFO - 2021-04-27 06:29:45 --> Helper loaded: file_helper
INFO - 2021-04-27 06:29:45 --> Helper loaded: form_helper
INFO - 2021-04-27 06:29:45 --> Helper loaded: my_helper
INFO - 2021-04-27 06:29:45 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:29:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:29:45 --> Controller Class Initialized
INFO - 2021-04-27 06:29:46 --> Config Class Initialized
INFO - 2021-04-27 06:29:46 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:29:47 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:29:47 --> Utf8 Class Initialized
INFO - 2021-04-27 06:29:47 --> URI Class Initialized
INFO - 2021-04-27 06:29:47 --> Router Class Initialized
INFO - 2021-04-27 06:29:47 --> Output Class Initialized
INFO - 2021-04-27 06:29:47 --> Security Class Initialized
DEBUG - 2021-04-27 06:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:29:47 --> Input Class Initialized
INFO - 2021-04-27 06:29:47 --> Language Class Initialized
INFO - 2021-04-27 06:29:47 --> Language Class Initialized
INFO - 2021-04-27 06:29:47 --> Config Class Initialized
INFO - 2021-04-27 06:29:47 --> Loader Class Initialized
INFO - 2021-04-27 06:29:47 --> Helper loaded: url_helper
INFO - 2021-04-27 06:29:47 --> Helper loaded: file_helper
INFO - 2021-04-27 06:29:47 --> Helper loaded: form_helper
INFO - 2021-04-27 06:29:47 --> Helper loaded: my_helper
INFO - 2021-04-27 06:29:47 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:29:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:29:47 --> Controller Class Initialized
INFO - 2021-04-27 06:29:47 --> Final output sent to browser
DEBUG - 2021-04-27 06:29:47 --> Total execution time: 0.1029
INFO - 2021-04-27 06:29:52 --> Config Class Initialized
INFO - 2021-04-27 06:29:52 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:29:52 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:29:52 --> Utf8 Class Initialized
INFO - 2021-04-27 06:29:52 --> URI Class Initialized
INFO - 2021-04-27 06:29:52 --> Router Class Initialized
INFO - 2021-04-27 06:29:52 --> Output Class Initialized
INFO - 2021-04-27 06:29:52 --> Security Class Initialized
DEBUG - 2021-04-27 06:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:29:52 --> Input Class Initialized
INFO - 2021-04-27 06:29:52 --> Language Class Initialized
INFO - 2021-04-27 06:29:52 --> Language Class Initialized
INFO - 2021-04-27 06:29:52 --> Config Class Initialized
INFO - 2021-04-27 06:29:52 --> Loader Class Initialized
INFO - 2021-04-27 06:29:52 --> Helper loaded: url_helper
INFO - 2021-04-27 06:29:52 --> Helper loaded: file_helper
INFO - 2021-04-27 06:29:52 --> Helper loaded: form_helper
INFO - 2021-04-27 06:29:52 --> Helper loaded: my_helper
INFO - 2021-04-27 06:29:52 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:29:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:29:52 --> Controller Class Initialized
INFO - 2021-04-27 06:29:52 --> Final output sent to browser
DEBUG - 2021-04-27 06:29:52 --> Total execution time: 0.1390
INFO - 2021-04-27 06:29:52 --> Config Class Initialized
INFO - 2021-04-27 06:29:52 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:29:52 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:29:52 --> Utf8 Class Initialized
INFO - 2021-04-27 06:29:52 --> URI Class Initialized
INFO - 2021-04-27 06:29:52 --> Router Class Initialized
INFO - 2021-04-27 06:29:52 --> Output Class Initialized
INFO - 2021-04-27 06:29:52 --> Security Class Initialized
DEBUG - 2021-04-27 06:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:29:52 --> Input Class Initialized
INFO - 2021-04-27 06:29:52 --> Language Class Initialized
INFO - 2021-04-27 06:29:52 --> Language Class Initialized
INFO - 2021-04-27 06:29:52 --> Config Class Initialized
INFO - 2021-04-27 06:29:52 --> Loader Class Initialized
INFO - 2021-04-27 06:29:52 --> Helper loaded: url_helper
INFO - 2021-04-27 06:29:52 --> Helper loaded: file_helper
INFO - 2021-04-27 06:29:52 --> Helper loaded: form_helper
INFO - 2021-04-27 06:29:52 --> Helper loaded: my_helper
INFO - 2021-04-27 06:29:52 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:29:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:29:52 --> Controller Class Initialized
INFO - 2021-04-27 06:29:53 --> Config Class Initialized
INFO - 2021-04-27 06:29:53 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:29:53 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:29:53 --> Utf8 Class Initialized
INFO - 2021-04-27 06:29:53 --> URI Class Initialized
INFO - 2021-04-27 06:29:53 --> Router Class Initialized
INFO - 2021-04-27 06:29:53 --> Output Class Initialized
INFO - 2021-04-27 06:29:53 --> Security Class Initialized
DEBUG - 2021-04-27 06:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:29:53 --> Input Class Initialized
INFO - 2021-04-27 06:29:53 --> Language Class Initialized
INFO - 2021-04-27 06:29:53 --> Language Class Initialized
INFO - 2021-04-27 06:29:53 --> Config Class Initialized
INFO - 2021-04-27 06:29:53 --> Loader Class Initialized
INFO - 2021-04-27 06:29:53 --> Helper loaded: url_helper
INFO - 2021-04-27 06:29:53 --> Helper loaded: file_helper
INFO - 2021-04-27 06:29:53 --> Helper loaded: form_helper
INFO - 2021-04-27 06:29:53 --> Helper loaded: my_helper
INFO - 2021-04-27 06:29:53 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:29:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:29:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:29:53 --> Controller Class Initialized
INFO - 2021-04-27 06:29:53 --> Final output sent to browser
DEBUG - 2021-04-27 06:29:53 --> Total execution time: 0.1245
INFO - 2021-04-27 06:29:58 --> Config Class Initialized
INFO - 2021-04-27 06:29:58 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:29:58 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:29:58 --> Utf8 Class Initialized
INFO - 2021-04-27 06:29:58 --> URI Class Initialized
INFO - 2021-04-27 06:29:58 --> Router Class Initialized
INFO - 2021-04-27 06:29:58 --> Output Class Initialized
INFO - 2021-04-27 06:29:58 --> Security Class Initialized
DEBUG - 2021-04-27 06:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:29:58 --> Input Class Initialized
INFO - 2021-04-27 06:29:58 --> Language Class Initialized
INFO - 2021-04-27 06:29:58 --> Language Class Initialized
INFO - 2021-04-27 06:29:58 --> Config Class Initialized
INFO - 2021-04-27 06:29:58 --> Loader Class Initialized
INFO - 2021-04-27 06:29:58 --> Helper loaded: url_helper
INFO - 2021-04-27 06:29:58 --> Helper loaded: file_helper
INFO - 2021-04-27 06:29:58 --> Helper loaded: form_helper
INFO - 2021-04-27 06:29:58 --> Helper loaded: my_helper
INFO - 2021-04-27 06:29:58 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:29:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:29:58 --> Controller Class Initialized
INFO - 2021-04-27 06:29:58 --> Final output sent to browser
DEBUG - 2021-04-27 06:29:58 --> Total execution time: 0.1341
INFO - 2021-04-27 06:29:58 --> Config Class Initialized
INFO - 2021-04-27 06:29:58 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:29:58 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:29:58 --> Utf8 Class Initialized
INFO - 2021-04-27 06:29:58 --> URI Class Initialized
INFO - 2021-04-27 06:29:58 --> Router Class Initialized
INFO - 2021-04-27 06:29:58 --> Output Class Initialized
INFO - 2021-04-27 06:29:58 --> Security Class Initialized
DEBUG - 2021-04-27 06:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:29:58 --> Input Class Initialized
INFO - 2021-04-27 06:29:58 --> Language Class Initialized
INFO - 2021-04-27 06:29:58 --> Language Class Initialized
INFO - 2021-04-27 06:29:58 --> Config Class Initialized
INFO - 2021-04-27 06:29:58 --> Loader Class Initialized
INFO - 2021-04-27 06:29:58 --> Helper loaded: url_helper
INFO - 2021-04-27 06:29:58 --> Helper loaded: file_helper
INFO - 2021-04-27 06:29:58 --> Helper loaded: form_helper
INFO - 2021-04-27 06:29:58 --> Helper loaded: my_helper
INFO - 2021-04-27 06:29:58 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:29:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:29:58 --> Controller Class Initialized
INFO - 2021-04-27 06:29:59 --> Config Class Initialized
INFO - 2021-04-27 06:29:59 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:29:59 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:29:59 --> Utf8 Class Initialized
INFO - 2021-04-27 06:29:59 --> URI Class Initialized
INFO - 2021-04-27 06:29:59 --> Router Class Initialized
INFO - 2021-04-27 06:29:59 --> Output Class Initialized
INFO - 2021-04-27 06:29:59 --> Security Class Initialized
DEBUG - 2021-04-27 06:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:29:59 --> Input Class Initialized
INFO - 2021-04-27 06:29:59 --> Language Class Initialized
INFO - 2021-04-27 06:29:59 --> Language Class Initialized
INFO - 2021-04-27 06:29:59 --> Config Class Initialized
INFO - 2021-04-27 06:29:59 --> Loader Class Initialized
INFO - 2021-04-27 06:29:59 --> Helper loaded: url_helper
INFO - 2021-04-27 06:29:59 --> Helper loaded: file_helper
INFO - 2021-04-27 06:29:59 --> Helper loaded: form_helper
INFO - 2021-04-27 06:29:59 --> Helper loaded: my_helper
INFO - 2021-04-27 06:29:59 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:29:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:29:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:29:59 --> Controller Class Initialized
INFO - 2021-04-27 06:29:59 --> Final output sent to browser
DEBUG - 2021-04-27 06:29:59 --> Total execution time: 0.1339
INFO - 2021-04-27 06:30:04 --> Config Class Initialized
INFO - 2021-04-27 06:30:04 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:30:04 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:30:04 --> Utf8 Class Initialized
INFO - 2021-04-27 06:30:04 --> URI Class Initialized
INFO - 2021-04-27 06:30:04 --> Router Class Initialized
INFO - 2021-04-27 06:30:04 --> Output Class Initialized
INFO - 2021-04-27 06:30:04 --> Security Class Initialized
DEBUG - 2021-04-27 06:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:30:04 --> Input Class Initialized
INFO - 2021-04-27 06:30:04 --> Language Class Initialized
INFO - 2021-04-27 06:30:04 --> Language Class Initialized
INFO - 2021-04-27 06:30:04 --> Config Class Initialized
INFO - 2021-04-27 06:30:04 --> Loader Class Initialized
INFO - 2021-04-27 06:30:04 --> Helper loaded: url_helper
INFO - 2021-04-27 06:30:04 --> Helper loaded: file_helper
INFO - 2021-04-27 06:30:04 --> Helper loaded: form_helper
INFO - 2021-04-27 06:30:04 --> Helper loaded: my_helper
INFO - 2021-04-27 06:30:04 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:30:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:30:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:30:04 --> Controller Class Initialized
INFO - 2021-04-27 06:30:04 --> Final output sent to browser
DEBUG - 2021-04-27 06:30:04 --> Total execution time: 0.1101
INFO - 2021-04-27 06:30:04 --> Config Class Initialized
INFO - 2021-04-27 06:30:04 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:30:04 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:30:04 --> Utf8 Class Initialized
INFO - 2021-04-27 06:30:04 --> URI Class Initialized
INFO - 2021-04-27 06:30:04 --> Router Class Initialized
INFO - 2021-04-27 06:30:04 --> Output Class Initialized
INFO - 2021-04-27 06:30:04 --> Security Class Initialized
DEBUG - 2021-04-27 06:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:30:04 --> Input Class Initialized
INFO - 2021-04-27 06:30:04 --> Language Class Initialized
INFO - 2021-04-27 06:30:04 --> Language Class Initialized
INFO - 2021-04-27 06:30:04 --> Config Class Initialized
INFO - 2021-04-27 06:30:04 --> Loader Class Initialized
INFO - 2021-04-27 06:30:04 --> Helper loaded: url_helper
INFO - 2021-04-27 06:30:04 --> Helper loaded: file_helper
INFO - 2021-04-27 06:30:04 --> Helper loaded: form_helper
INFO - 2021-04-27 06:30:04 --> Helper loaded: my_helper
INFO - 2021-04-27 06:30:04 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:30:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:30:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:30:04 --> Controller Class Initialized
INFO - 2021-04-27 06:30:10 --> Config Class Initialized
INFO - 2021-04-27 06:30:10 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:30:10 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:30:10 --> Utf8 Class Initialized
INFO - 2021-04-27 06:30:10 --> URI Class Initialized
INFO - 2021-04-27 06:30:10 --> Router Class Initialized
INFO - 2021-04-27 06:30:10 --> Output Class Initialized
INFO - 2021-04-27 06:30:10 --> Security Class Initialized
DEBUG - 2021-04-27 06:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:30:10 --> Input Class Initialized
INFO - 2021-04-27 06:30:10 --> Language Class Initialized
INFO - 2021-04-27 06:30:10 --> Language Class Initialized
INFO - 2021-04-27 06:30:10 --> Config Class Initialized
INFO - 2021-04-27 06:30:10 --> Loader Class Initialized
INFO - 2021-04-27 06:30:10 --> Helper loaded: url_helper
INFO - 2021-04-27 06:30:10 --> Helper loaded: file_helper
INFO - 2021-04-27 06:30:10 --> Helper loaded: form_helper
INFO - 2021-04-27 06:30:10 --> Helper loaded: my_helper
INFO - 2021-04-27 06:30:10 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:30:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:30:10 --> Controller Class Initialized
INFO - 2021-04-27 06:30:10 --> Final output sent to browser
DEBUG - 2021-04-27 06:30:10 --> Total execution time: 0.1329
INFO - 2021-04-27 06:30:14 --> Config Class Initialized
INFO - 2021-04-27 06:30:14 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:30:14 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:30:14 --> Utf8 Class Initialized
INFO - 2021-04-27 06:30:14 --> URI Class Initialized
INFO - 2021-04-27 06:30:14 --> Router Class Initialized
INFO - 2021-04-27 06:30:14 --> Output Class Initialized
INFO - 2021-04-27 06:30:14 --> Security Class Initialized
DEBUG - 2021-04-27 06:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:30:14 --> Input Class Initialized
INFO - 2021-04-27 06:30:14 --> Language Class Initialized
INFO - 2021-04-27 06:30:14 --> Language Class Initialized
INFO - 2021-04-27 06:30:14 --> Config Class Initialized
INFO - 2021-04-27 06:30:14 --> Loader Class Initialized
INFO - 2021-04-27 06:30:14 --> Helper loaded: url_helper
INFO - 2021-04-27 06:30:14 --> Helper loaded: file_helper
INFO - 2021-04-27 06:30:14 --> Helper loaded: form_helper
INFO - 2021-04-27 06:30:14 --> Helper loaded: my_helper
INFO - 2021-04-27 06:30:14 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:30:14 --> Controller Class Initialized
INFO - 2021-04-27 06:30:14 --> Final output sent to browser
DEBUG - 2021-04-27 06:30:14 --> Total execution time: 0.1021
INFO - 2021-04-27 06:30:14 --> Config Class Initialized
INFO - 2021-04-27 06:30:14 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:30:14 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:30:14 --> Utf8 Class Initialized
INFO - 2021-04-27 06:30:14 --> URI Class Initialized
INFO - 2021-04-27 06:30:15 --> Router Class Initialized
INFO - 2021-04-27 06:30:15 --> Output Class Initialized
INFO - 2021-04-27 06:30:15 --> Security Class Initialized
DEBUG - 2021-04-27 06:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:30:15 --> Input Class Initialized
INFO - 2021-04-27 06:30:15 --> Language Class Initialized
INFO - 2021-04-27 06:30:15 --> Language Class Initialized
INFO - 2021-04-27 06:30:15 --> Config Class Initialized
INFO - 2021-04-27 06:30:15 --> Loader Class Initialized
INFO - 2021-04-27 06:30:15 --> Helper loaded: url_helper
INFO - 2021-04-27 06:30:15 --> Helper loaded: file_helper
INFO - 2021-04-27 06:30:15 --> Helper loaded: form_helper
INFO - 2021-04-27 06:30:15 --> Helper loaded: my_helper
INFO - 2021-04-27 06:30:15 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:30:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:30:15 --> Controller Class Initialized
INFO - 2021-04-27 06:30:17 --> Config Class Initialized
INFO - 2021-04-27 06:30:17 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:30:17 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:30:17 --> Utf8 Class Initialized
INFO - 2021-04-27 06:30:17 --> URI Class Initialized
INFO - 2021-04-27 06:30:17 --> Router Class Initialized
INFO - 2021-04-27 06:30:17 --> Output Class Initialized
INFO - 2021-04-27 06:30:17 --> Security Class Initialized
DEBUG - 2021-04-27 06:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:30:17 --> Input Class Initialized
INFO - 2021-04-27 06:30:17 --> Language Class Initialized
INFO - 2021-04-27 06:30:17 --> Language Class Initialized
INFO - 2021-04-27 06:30:17 --> Config Class Initialized
INFO - 2021-04-27 06:30:17 --> Loader Class Initialized
INFO - 2021-04-27 06:30:17 --> Helper loaded: url_helper
INFO - 2021-04-27 06:30:17 --> Helper loaded: file_helper
INFO - 2021-04-27 06:30:17 --> Helper loaded: form_helper
INFO - 2021-04-27 06:30:17 --> Helper loaded: my_helper
INFO - 2021-04-27 06:30:17 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:30:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:30:17 --> Controller Class Initialized
INFO - 2021-04-27 06:30:17 --> Final output sent to browser
DEBUG - 2021-04-27 06:30:17 --> Total execution time: 0.1042
INFO - 2021-04-27 06:30:20 --> Config Class Initialized
INFO - 2021-04-27 06:30:20 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:30:20 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:30:20 --> Utf8 Class Initialized
INFO - 2021-04-27 06:30:20 --> URI Class Initialized
INFO - 2021-04-27 06:30:20 --> Router Class Initialized
INFO - 2021-04-27 06:30:20 --> Output Class Initialized
INFO - 2021-04-27 06:30:20 --> Security Class Initialized
DEBUG - 2021-04-27 06:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:30:20 --> Input Class Initialized
INFO - 2021-04-27 06:30:20 --> Language Class Initialized
INFO - 2021-04-27 06:30:20 --> Language Class Initialized
INFO - 2021-04-27 06:30:20 --> Config Class Initialized
INFO - 2021-04-27 06:30:20 --> Loader Class Initialized
INFO - 2021-04-27 06:30:20 --> Helper loaded: url_helper
INFO - 2021-04-27 06:30:20 --> Helper loaded: file_helper
INFO - 2021-04-27 06:30:20 --> Helper loaded: form_helper
INFO - 2021-04-27 06:30:20 --> Helper loaded: my_helper
INFO - 2021-04-27 06:30:20 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:30:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:30:20 --> Controller Class Initialized
INFO - 2021-04-27 06:30:20 --> Final output sent to browser
DEBUG - 2021-04-27 06:30:20 --> Total execution time: 0.1368
INFO - 2021-04-27 06:30:20 --> Config Class Initialized
INFO - 2021-04-27 06:30:20 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:30:20 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:30:20 --> Utf8 Class Initialized
INFO - 2021-04-27 06:30:20 --> URI Class Initialized
INFO - 2021-04-27 06:30:20 --> Router Class Initialized
INFO - 2021-04-27 06:30:20 --> Output Class Initialized
INFO - 2021-04-27 06:30:20 --> Security Class Initialized
DEBUG - 2021-04-27 06:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:30:21 --> Input Class Initialized
INFO - 2021-04-27 06:30:21 --> Language Class Initialized
INFO - 2021-04-27 06:30:21 --> Language Class Initialized
INFO - 2021-04-27 06:30:21 --> Config Class Initialized
INFO - 2021-04-27 06:30:21 --> Loader Class Initialized
INFO - 2021-04-27 06:30:21 --> Helper loaded: url_helper
INFO - 2021-04-27 06:30:21 --> Helper loaded: file_helper
INFO - 2021-04-27 06:30:21 --> Helper loaded: form_helper
INFO - 2021-04-27 06:30:21 --> Helper loaded: my_helper
INFO - 2021-04-27 06:30:21 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:30:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:30:21 --> Controller Class Initialized
INFO - 2021-04-27 06:30:22 --> Config Class Initialized
INFO - 2021-04-27 06:30:22 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:30:22 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:30:22 --> Utf8 Class Initialized
INFO - 2021-04-27 06:30:22 --> URI Class Initialized
INFO - 2021-04-27 06:30:22 --> Router Class Initialized
INFO - 2021-04-27 06:30:22 --> Output Class Initialized
INFO - 2021-04-27 06:30:22 --> Security Class Initialized
DEBUG - 2021-04-27 06:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:30:22 --> Input Class Initialized
INFO - 2021-04-27 06:30:22 --> Language Class Initialized
INFO - 2021-04-27 06:30:22 --> Language Class Initialized
INFO - 2021-04-27 06:30:22 --> Config Class Initialized
INFO - 2021-04-27 06:30:22 --> Loader Class Initialized
INFO - 2021-04-27 06:30:22 --> Helper loaded: url_helper
INFO - 2021-04-27 06:30:22 --> Helper loaded: file_helper
INFO - 2021-04-27 06:30:22 --> Helper loaded: form_helper
INFO - 2021-04-27 06:30:22 --> Helper loaded: my_helper
INFO - 2021-04-27 06:30:22 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:30:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:30:22 --> Controller Class Initialized
INFO - 2021-04-27 06:30:22 --> Final output sent to browser
DEBUG - 2021-04-27 06:30:22 --> Total execution time: 0.0952
INFO - 2021-04-27 06:30:27 --> Config Class Initialized
INFO - 2021-04-27 06:30:27 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:30:27 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:30:27 --> Utf8 Class Initialized
INFO - 2021-04-27 06:30:27 --> URI Class Initialized
INFO - 2021-04-27 06:30:27 --> Router Class Initialized
INFO - 2021-04-27 06:30:27 --> Output Class Initialized
INFO - 2021-04-27 06:30:27 --> Security Class Initialized
DEBUG - 2021-04-27 06:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:30:27 --> Input Class Initialized
INFO - 2021-04-27 06:30:27 --> Language Class Initialized
INFO - 2021-04-27 06:30:27 --> Language Class Initialized
INFO - 2021-04-27 06:30:27 --> Config Class Initialized
INFO - 2021-04-27 06:30:27 --> Loader Class Initialized
INFO - 2021-04-27 06:30:27 --> Helper loaded: url_helper
INFO - 2021-04-27 06:30:27 --> Helper loaded: file_helper
INFO - 2021-04-27 06:30:27 --> Helper loaded: form_helper
INFO - 2021-04-27 06:30:27 --> Helper loaded: my_helper
INFO - 2021-04-27 06:30:27 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:30:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:30:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:30:27 --> Controller Class Initialized
INFO - 2021-04-27 06:30:27 --> Final output sent to browser
DEBUG - 2021-04-27 06:30:27 --> Total execution time: 0.1353
INFO - 2021-04-27 06:30:28 --> Config Class Initialized
INFO - 2021-04-27 06:30:28 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:30:28 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:30:28 --> Utf8 Class Initialized
INFO - 2021-04-27 06:30:28 --> URI Class Initialized
INFO - 2021-04-27 06:30:28 --> Router Class Initialized
INFO - 2021-04-27 06:30:28 --> Output Class Initialized
INFO - 2021-04-27 06:30:28 --> Security Class Initialized
DEBUG - 2021-04-27 06:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:30:28 --> Input Class Initialized
INFO - 2021-04-27 06:30:28 --> Language Class Initialized
INFO - 2021-04-27 06:30:28 --> Language Class Initialized
INFO - 2021-04-27 06:30:28 --> Config Class Initialized
INFO - 2021-04-27 06:30:28 --> Loader Class Initialized
INFO - 2021-04-27 06:30:28 --> Helper loaded: url_helper
INFO - 2021-04-27 06:30:28 --> Helper loaded: file_helper
INFO - 2021-04-27 06:30:28 --> Helper loaded: form_helper
INFO - 2021-04-27 06:30:28 --> Helper loaded: my_helper
INFO - 2021-04-27 06:30:28 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:30:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:30:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:30:28 --> Controller Class Initialized
INFO - 2021-04-27 06:30:29 --> Config Class Initialized
INFO - 2021-04-27 06:30:29 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:30:29 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:30:29 --> Utf8 Class Initialized
INFO - 2021-04-27 06:30:29 --> URI Class Initialized
INFO - 2021-04-27 06:30:29 --> Router Class Initialized
INFO - 2021-04-27 06:30:29 --> Output Class Initialized
INFO - 2021-04-27 06:30:29 --> Security Class Initialized
DEBUG - 2021-04-27 06:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:30:29 --> Input Class Initialized
INFO - 2021-04-27 06:30:29 --> Language Class Initialized
INFO - 2021-04-27 06:30:29 --> Language Class Initialized
INFO - 2021-04-27 06:30:29 --> Config Class Initialized
INFO - 2021-04-27 06:30:29 --> Loader Class Initialized
INFO - 2021-04-27 06:30:29 --> Helper loaded: url_helper
INFO - 2021-04-27 06:30:29 --> Helper loaded: file_helper
INFO - 2021-04-27 06:30:29 --> Helper loaded: form_helper
INFO - 2021-04-27 06:30:29 --> Helper loaded: my_helper
INFO - 2021-04-27 06:30:29 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:30:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:30:29 --> Controller Class Initialized
INFO - 2021-04-27 06:30:29 --> Final output sent to browser
DEBUG - 2021-04-27 06:30:29 --> Total execution time: 0.1029
INFO - 2021-04-27 06:30:33 --> Config Class Initialized
INFO - 2021-04-27 06:30:33 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:30:33 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:30:33 --> Utf8 Class Initialized
INFO - 2021-04-27 06:30:33 --> URI Class Initialized
INFO - 2021-04-27 06:30:33 --> Router Class Initialized
INFO - 2021-04-27 06:30:33 --> Output Class Initialized
INFO - 2021-04-27 06:30:33 --> Security Class Initialized
DEBUG - 2021-04-27 06:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:30:33 --> Input Class Initialized
INFO - 2021-04-27 06:30:33 --> Language Class Initialized
INFO - 2021-04-27 06:30:33 --> Language Class Initialized
INFO - 2021-04-27 06:30:33 --> Config Class Initialized
INFO - 2021-04-27 06:30:33 --> Loader Class Initialized
INFO - 2021-04-27 06:30:33 --> Helper loaded: url_helper
INFO - 2021-04-27 06:30:33 --> Helper loaded: file_helper
INFO - 2021-04-27 06:30:33 --> Helper loaded: form_helper
INFO - 2021-04-27 06:30:33 --> Helper loaded: my_helper
INFO - 2021-04-27 06:30:33 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:30:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:30:33 --> Controller Class Initialized
INFO - 2021-04-27 06:30:33 --> Final output sent to browser
DEBUG - 2021-04-27 06:30:33 --> Total execution time: 0.1395
INFO - 2021-04-27 06:30:33 --> Config Class Initialized
INFO - 2021-04-27 06:30:33 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:30:33 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:30:33 --> Utf8 Class Initialized
INFO - 2021-04-27 06:30:33 --> URI Class Initialized
INFO - 2021-04-27 06:30:33 --> Router Class Initialized
INFO - 2021-04-27 06:30:33 --> Output Class Initialized
INFO - 2021-04-27 06:30:33 --> Security Class Initialized
DEBUG - 2021-04-27 06:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:30:33 --> Input Class Initialized
INFO - 2021-04-27 06:30:33 --> Language Class Initialized
INFO - 2021-04-27 06:30:33 --> Language Class Initialized
INFO - 2021-04-27 06:30:33 --> Config Class Initialized
INFO - 2021-04-27 06:30:33 --> Loader Class Initialized
INFO - 2021-04-27 06:30:33 --> Helper loaded: url_helper
INFO - 2021-04-27 06:30:33 --> Helper loaded: file_helper
INFO - 2021-04-27 06:30:33 --> Helper loaded: form_helper
INFO - 2021-04-27 06:30:33 --> Helper loaded: my_helper
INFO - 2021-04-27 06:30:33 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:30:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:30:33 --> Controller Class Initialized
INFO - 2021-04-27 06:30:35 --> Config Class Initialized
INFO - 2021-04-27 06:30:35 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:30:35 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:30:35 --> Utf8 Class Initialized
INFO - 2021-04-27 06:30:35 --> URI Class Initialized
INFO - 2021-04-27 06:30:35 --> Router Class Initialized
INFO - 2021-04-27 06:30:35 --> Output Class Initialized
INFO - 2021-04-27 06:30:35 --> Security Class Initialized
DEBUG - 2021-04-27 06:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:30:35 --> Input Class Initialized
INFO - 2021-04-27 06:30:35 --> Language Class Initialized
INFO - 2021-04-27 06:30:35 --> Language Class Initialized
INFO - 2021-04-27 06:30:35 --> Config Class Initialized
INFO - 2021-04-27 06:30:35 --> Loader Class Initialized
INFO - 2021-04-27 06:30:35 --> Helper loaded: url_helper
INFO - 2021-04-27 06:30:35 --> Helper loaded: file_helper
INFO - 2021-04-27 06:30:35 --> Helper loaded: form_helper
INFO - 2021-04-27 06:30:35 --> Helper loaded: my_helper
INFO - 2021-04-27 06:30:35 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:30:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:30:35 --> Controller Class Initialized
INFO - 2021-04-27 06:30:35 --> Final output sent to browser
DEBUG - 2021-04-27 06:30:35 --> Total execution time: 0.1391
INFO - 2021-04-27 06:30:38 --> Config Class Initialized
INFO - 2021-04-27 06:30:38 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:30:38 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:30:38 --> Utf8 Class Initialized
INFO - 2021-04-27 06:30:38 --> URI Class Initialized
INFO - 2021-04-27 06:30:38 --> Router Class Initialized
INFO - 2021-04-27 06:30:38 --> Output Class Initialized
INFO - 2021-04-27 06:30:38 --> Security Class Initialized
DEBUG - 2021-04-27 06:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:30:38 --> Input Class Initialized
INFO - 2021-04-27 06:30:38 --> Language Class Initialized
INFO - 2021-04-27 06:30:38 --> Language Class Initialized
INFO - 2021-04-27 06:30:38 --> Config Class Initialized
INFO - 2021-04-27 06:30:38 --> Loader Class Initialized
INFO - 2021-04-27 06:30:38 --> Helper loaded: url_helper
INFO - 2021-04-27 06:30:38 --> Helper loaded: file_helper
INFO - 2021-04-27 06:30:38 --> Helper loaded: form_helper
INFO - 2021-04-27 06:30:38 --> Helper loaded: my_helper
INFO - 2021-04-27 06:30:38 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:30:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:30:38 --> Controller Class Initialized
INFO - 2021-04-27 06:30:38 --> Final output sent to browser
DEBUG - 2021-04-27 06:30:38 --> Total execution time: 0.1380
INFO - 2021-04-27 06:30:38 --> Config Class Initialized
INFO - 2021-04-27 06:30:38 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:30:38 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:30:38 --> Utf8 Class Initialized
INFO - 2021-04-27 06:30:38 --> URI Class Initialized
INFO - 2021-04-27 06:30:38 --> Router Class Initialized
INFO - 2021-04-27 06:30:38 --> Output Class Initialized
INFO - 2021-04-27 06:30:38 --> Security Class Initialized
DEBUG - 2021-04-27 06:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:30:38 --> Input Class Initialized
INFO - 2021-04-27 06:30:38 --> Language Class Initialized
INFO - 2021-04-27 06:30:38 --> Language Class Initialized
INFO - 2021-04-27 06:30:38 --> Config Class Initialized
INFO - 2021-04-27 06:30:38 --> Loader Class Initialized
INFO - 2021-04-27 06:30:38 --> Helper loaded: url_helper
INFO - 2021-04-27 06:30:38 --> Helper loaded: file_helper
INFO - 2021-04-27 06:30:38 --> Helper loaded: form_helper
INFO - 2021-04-27 06:30:38 --> Helper loaded: my_helper
INFO - 2021-04-27 06:30:38 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:30:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:30:38 --> Controller Class Initialized
INFO - 2021-04-27 06:30:40 --> Config Class Initialized
INFO - 2021-04-27 06:30:40 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:30:40 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:30:40 --> Utf8 Class Initialized
INFO - 2021-04-27 06:30:40 --> URI Class Initialized
INFO - 2021-04-27 06:30:40 --> Router Class Initialized
INFO - 2021-04-27 06:30:40 --> Output Class Initialized
INFO - 2021-04-27 06:30:40 --> Security Class Initialized
DEBUG - 2021-04-27 06:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:30:40 --> Input Class Initialized
INFO - 2021-04-27 06:30:40 --> Language Class Initialized
INFO - 2021-04-27 06:30:40 --> Language Class Initialized
INFO - 2021-04-27 06:30:40 --> Config Class Initialized
INFO - 2021-04-27 06:30:40 --> Loader Class Initialized
INFO - 2021-04-27 06:30:40 --> Helper loaded: url_helper
INFO - 2021-04-27 06:30:40 --> Helper loaded: file_helper
INFO - 2021-04-27 06:30:40 --> Helper loaded: form_helper
INFO - 2021-04-27 06:30:40 --> Helper loaded: my_helper
INFO - 2021-04-27 06:30:40 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:30:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:30:40 --> Controller Class Initialized
DEBUG - 2021-04-27 06:30:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-27 06:30:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 06:30:40 --> Final output sent to browser
DEBUG - 2021-04-27 06:30:40 --> Total execution time: 0.1577
INFO - 2021-04-27 06:30:41 --> Config Class Initialized
INFO - 2021-04-27 06:30:41 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:30:41 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:30:41 --> Utf8 Class Initialized
INFO - 2021-04-27 06:30:41 --> URI Class Initialized
INFO - 2021-04-27 06:30:41 --> Router Class Initialized
INFO - 2021-04-27 06:30:41 --> Output Class Initialized
INFO - 2021-04-27 06:30:41 --> Security Class Initialized
DEBUG - 2021-04-27 06:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:30:42 --> Input Class Initialized
INFO - 2021-04-27 06:30:42 --> Language Class Initialized
INFO - 2021-04-27 06:30:42 --> Language Class Initialized
INFO - 2021-04-27 06:30:42 --> Config Class Initialized
INFO - 2021-04-27 06:30:42 --> Loader Class Initialized
INFO - 2021-04-27 06:30:42 --> Helper loaded: url_helper
INFO - 2021-04-27 06:30:42 --> Helper loaded: file_helper
INFO - 2021-04-27 06:30:42 --> Helper loaded: form_helper
INFO - 2021-04-27 06:30:42 --> Helper loaded: my_helper
INFO - 2021-04-27 06:30:42 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:30:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:30:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:30:42 --> Controller Class Initialized
DEBUG - 2021-04-27 06:30:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-04-27 06:30:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 06:30:42 --> Final output sent to browser
DEBUG - 2021-04-27 06:30:42 --> Total execution time: 0.1509
INFO - 2021-04-27 06:30:51 --> Config Class Initialized
INFO - 2021-04-27 06:30:51 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:30:51 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:30:51 --> Utf8 Class Initialized
INFO - 2021-04-27 06:30:51 --> URI Class Initialized
INFO - 2021-04-27 06:30:51 --> Router Class Initialized
INFO - 2021-04-27 06:30:51 --> Output Class Initialized
INFO - 2021-04-27 06:30:51 --> Security Class Initialized
DEBUG - 2021-04-27 06:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:30:51 --> Input Class Initialized
INFO - 2021-04-27 06:30:51 --> Language Class Initialized
INFO - 2021-04-27 06:30:51 --> Language Class Initialized
INFO - 2021-04-27 06:30:51 --> Config Class Initialized
INFO - 2021-04-27 06:30:51 --> Loader Class Initialized
INFO - 2021-04-27 06:30:51 --> Helper loaded: url_helper
INFO - 2021-04-27 06:30:51 --> Helper loaded: file_helper
INFO - 2021-04-27 06:30:51 --> Helper loaded: form_helper
INFO - 2021-04-27 06:30:51 --> Helper loaded: my_helper
INFO - 2021-04-27 06:30:51 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:30:51 --> Controller Class Initialized
INFO - 2021-04-27 06:30:51 --> Config Class Initialized
INFO - 2021-04-27 06:30:51 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:30:51 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:30:51 --> Utf8 Class Initialized
INFO - 2021-04-27 06:30:51 --> URI Class Initialized
INFO - 2021-04-27 06:30:51 --> Router Class Initialized
INFO - 2021-04-27 06:30:51 --> Output Class Initialized
INFO - 2021-04-27 06:30:51 --> Security Class Initialized
DEBUG - 2021-04-27 06:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:30:51 --> Input Class Initialized
INFO - 2021-04-27 06:30:51 --> Language Class Initialized
INFO - 2021-04-27 06:30:51 --> Language Class Initialized
INFO - 2021-04-27 06:30:51 --> Config Class Initialized
INFO - 2021-04-27 06:30:51 --> Loader Class Initialized
INFO - 2021-04-27 06:30:51 --> Helper loaded: url_helper
INFO - 2021-04-27 06:30:51 --> Helper loaded: file_helper
INFO - 2021-04-27 06:30:51 --> Helper loaded: form_helper
INFO - 2021-04-27 06:30:51 --> Helper loaded: my_helper
INFO - 2021-04-27 06:30:51 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:30:51 --> Controller Class Initialized
DEBUG - 2021-04-27 06:30:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-27 06:30:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 06:30:51 --> Final output sent to browser
DEBUG - 2021-04-27 06:30:51 --> Total execution time: 0.1559
INFO - 2021-04-27 06:38:49 --> Config Class Initialized
INFO - 2021-04-27 06:38:49 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:38:49 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:38:49 --> Utf8 Class Initialized
INFO - 2021-04-27 06:38:49 --> URI Class Initialized
INFO - 2021-04-27 06:38:49 --> Router Class Initialized
INFO - 2021-04-27 06:38:49 --> Output Class Initialized
INFO - 2021-04-27 06:38:49 --> Security Class Initialized
DEBUG - 2021-04-27 06:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:38:49 --> Input Class Initialized
INFO - 2021-04-27 06:38:49 --> Language Class Initialized
INFO - 2021-04-27 06:38:49 --> Language Class Initialized
INFO - 2021-04-27 06:38:49 --> Config Class Initialized
INFO - 2021-04-27 06:38:49 --> Loader Class Initialized
INFO - 2021-04-27 06:38:49 --> Helper loaded: url_helper
INFO - 2021-04-27 06:38:49 --> Helper loaded: file_helper
INFO - 2021-04-27 06:38:49 --> Helper loaded: form_helper
INFO - 2021-04-27 06:38:49 --> Helper loaded: my_helper
INFO - 2021-04-27 06:38:50 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:38:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:38:50 --> Controller Class Initialized
DEBUG - 2021-04-27 06:38:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-04-27 06:38:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 06:38:50 --> Final output sent to browser
DEBUG - 2021-04-27 06:38:50 --> Total execution time: 0.6776
INFO - 2021-04-27 06:38:50 --> Config Class Initialized
INFO - 2021-04-27 06:38:50 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:38:50 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:38:50 --> Utf8 Class Initialized
INFO - 2021-04-27 06:38:50 --> URI Class Initialized
INFO - 2021-04-27 06:38:50 --> Router Class Initialized
INFO - 2021-04-27 06:38:50 --> Output Class Initialized
INFO - 2021-04-27 06:38:50 --> Security Class Initialized
DEBUG - 2021-04-27 06:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:38:50 --> Input Class Initialized
INFO - 2021-04-27 06:38:50 --> Language Class Initialized
INFO - 2021-04-27 06:38:50 --> Language Class Initialized
INFO - 2021-04-27 06:38:50 --> Config Class Initialized
INFO - 2021-04-27 06:38:50 --> Loader Class Initialized
INFO - 2021-04-27 06:38:50 --> Helper loaded: url_helper
INFO - 2021-04-27 06:38:50 --> Helper loaded: file_helper
INFO - 2021-04-27 06:38:50 --> Helper loaded: form_helper
INFO - 2021-04-27 06:38:50 --> Helper loaded: my_helper
INFO - 2021-04-27 06:38:50 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:38:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:38:50 --> Controller Class Initialized
INFO - 2021-04-27 06:38:52 --> Config Class Initialized
INFO - 2021-04-27 06:38:52 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:38:52 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:38:52 --> Utf8 Class Initialized
INFO - 2021-04-27 06:38:52 --> URI Class Initialized
INFO - 2021-04-27 06:38:52 --> Router Class Initialized
INFO - 2021-04-27 06:38:52 --> Output Class Initialized
INFO - 2021-04-27 06:38:52 --> Security Class Initialized
DEBUG - 2021-04-27 06:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:38:52 --> Input Class Initialized
INFO - 2021-04-27 06:38:52 --> Language Class Initialized
INFO - 2021-04-27 06:38:52 --> Language Class Initialized
INFO - 2021-04-27 06:38:52 --> Config Class Initialized
INFO - 2021-04-27 06:38:52 --> Loader Class Initialized
INFO - 2021-04-27 06:38:52 --> Helper loaded: url_helper
INFO - 2021-04-27 06:38:52 --> Helper loaded: file_helper
INFO - 2021-04-27 06:38:52 --> Helper loaded: form_helper
INFO - 2021-04-27 06:38:52 --> Helper loaded: my_helper
INFO - 2021-04-27 06:38:52 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:38:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:38:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:38:52 --> Controller Class Initialized
DEBUG - 2021-04-27 06:38:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-27 06:38:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 06:38:52 --> Final output sent to browser
DEBUG - 2021-04-27 06:38:52 --> Total execution time: 0.1056
INFO - 2021-04-27 06:39:22 --> Config Class Initialized
INFO - 2021-04-27 06:39:22 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:39:22 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:39:22 --> Utf8 Class Initialized
INFO - 2021-04-27 06:39:22 --> URI Class Initialized
INFO - 2021-04-27 06:39:22 --> Router Class Initialized
INFO - 2021-04-27 06:39:22 --> Output Class Initialized
INFO - 2021-04-27 06:39:22 --> Security Class Initialized
DEBUG - 2021-04-27 06:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:39:22 --> Input Class Initialized
INFO - 2021-04-27 06:39:22 --> Language Class Initialized
INFO - 2021-04-27 06:39:22 --> Language Class Initialized
INFO - 2021-04-27 06:39:22 --> Config Class Initialized
INFO - 2021-04-27 06:39:22 --> Loader Class Initialized
INFO - 2021-04-27 06:39:22 --> Helper loaded: url_helper
INFO - 2021-04-27 06:39:22 --> Helper loaded: file_helper
INFO - 2021-04-27 06:39:22 --> Helper loaded: form_helper
INFO - 2021-04-27 06:39:22 --> Helper loaded: my_helper
INFO - 2021-04-27 06:39:22 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:39:22 --> Controller Class Initialized
DEBUG - 2021-04-27 06:39:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2021-04-27 06:39:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 06:39:22 --> Final output sent to browser
DEBUG - 2021-04-27 06:39:22 --> Total execution time: 0.1066
INFO - 2021-04-27 06:39:22 --> Config Class Initialized
INFO - 2021-04-27 06:39:22 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:39:22 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:39:22 --> Utf8 Class Initialized
INFO - 2021-04-27 06:39:22 --> URI Class Initialized
INFO - 2021-04-27 06:39:22 --> Router Class Initialized
INFO - 2021-04-27 06:39:22 --> Output Class Initialized
INFO - 2021-04-27 06:39:22 --> Security Class Initialized
DEBUG - 2021-04-27 06:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:39:22 --> Input Class Initialized
INFO - 2021-04-27 06:39:22 --> Language Class Initialized
INFO - 2021-04-27 06:39:22 --> Language Class Initialized
INFO - 2021-04-27 06:39:22 --> Config Class Initialized
INFO - 2021-04-27 06:39:22 --> Loader Class Initialized
INFO - 2021-04-27 06:39:22 --> Helper loaded: url_helper
INFO - 2021-04-27 06:39:22 --> Helper loaded: file_helper
INFO - 2021-04-27 06:39:22 --> Helper loaded: form_helper
INFO - 2021-04-27 06:39:22 --> Helper loaded: my_helper
INFO - 2021-04-27 06:39:22 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:39:22 --> Controller Class Initialized
INFO - 2021-04-27 06:39:23 --> Config Class Initialized
INFO - 2021-04-27 06:39:23 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:39:23 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:39:23 --> Utf8 Class Initialized
INFO - 2021-04-27 06:39:23 --> URI Class Initialized
INFO - 2021-04-27 06:39:23 --> Router Class Initialized
INFO - 2021-04-27 06:39:23 --> Output Class Initialized
INFO - 2021-04-27 06:39:23 --> Security Class Initialized
DEBUG - 2021-04-27 06:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:39:23 --> Input Class Initialized
INFO - 2021-04-27 06:39:23 --> Language Class Initialized
INFO - 2021-04-27 06:39:23 --> Language Class Initialized
INFO - 2021-04-27 06:39:23 --> Config Class Initialized
INFO - 2021-04-27 06:39:23 --> Loader Class Initialized
INFO - 2021-04-27 06:39:23 --> Helper loaded: url_helper
INFO - 2021-04-27 06:39:23 --> Helper loaded: file_helper
INFO - 2021-04-27 06:39:23 --> Helper loaded: form_helper
INFO - 2021-04-27 06:39:23 --> Helper loaded: my_helper
INFO - 2021-04-27 06:39:23 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:39:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:39:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:39:23 --> Controller Class Initialized
DEBUG - 2021-04-27 06:39:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-04-27 06:39:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 06:39:23 --> Final output sent to browser
DEBUG - 2021-04-27 06:39:23 --> Total execution time: 0.0707
INFO - 2021-04-27 06:39:23 --> Config Class Initialized
INFO - 2021-04-27 06:39:23 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:39:23 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:39:23 --> Utf8 Class Initialized
INFO - 2021-04-27 06:39:23 --> URI Class Initialized
INFO - 2021-04-27 06:39:23 --> Router Class Initialized
INFO - 2021-04-27 06:39:23 --> Output Class Initialized
INFO - 2021-04-27 06:39:23 --> Security Class Initialized
DEBUG - 2021-04-27 06:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:39:23 --> Input Class Initialized
INFO - 2021-04-27 06:39:23 --> Language Class Initialized
INFO - 2021-04-27 06:39:23 --> Language Class Initialized
INFO - 2021-04-27 06:39:23 --> Config Class Initialized
INFO - 2021-04-27 06:39:23 --> Loader Class Initialized
INFO - 2021-04-27 06:39:23 --> Helper loaded: url_helper
INFO - 2021-04-27 06:39:23 --> Helper loaded: file_helper
INFO - 2021-04-27 06:39:23 --> Helper loaded: form_helper
INFO - 2021-04-27 06:39:23 --> Helper loaded: my_helper
INFO - 2021-04-27 06:39:23 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:39:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:39:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:39:23 --> Controller Class Initialized
INFO - 2021-04-27 06:39:24 --> Config Class Initialized
INFO - 2021-04-27 06:39:24 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:39:24 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:39:24 --> Utf8 Class Initialized
INFO - 2021-04-27 06:39:24 --> URI Class Initialized
INFO - 2021-04-27 06:39:24 --> Router Class Initialized
INFO - 2021-04-27 06:39:24 --> Output Class Initialized
INFO - 2021-04-27 06:39:24 --> Security Class Initialized
DEBUG - 2021-04-27 06:39:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:39:24 --> Input Class Initialized
INFO - 2021-04-27 06:39:24 --> Language Class Initialized
INFO - 2021-04-27 06:39:24 --> Language Class Initialized
INFO - 2021-04-27 06:39:24 --> Config Class Initialized
INFO - 2021-04-27 06:39:24 --> Loader Class Initialized
INFO - 2021-04-27 06:39:24 --> Helper loaded: url_helper
INFO - 2021-04-27 06:39:24 --> Helper loaded: file_helper
INFO - 2021-04-27 06:39:24 --> Helper loaded: form_helper
INFO - 2021-04-27 06:39:24 --> Helper loaded: my_helper
INFO - 2021-04-27 06:39:24 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:39:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:39:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:39:24 --> Controller Class Initialized
DEBUG - 2021-04-27 06:39:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-04-27 06:39:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 06:39:24 --> Final output sent to browser
DEBUG - 2021-04-27 06:39:24 --> Total execution time: 0.1073
INFO - 2021-04-27 06:39:24 --> Config Class Initialized
INFO - 2021-04-27 06:39:24 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:39:24 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:39:24 --> Utf8 Class Initialized
INFO - 2021-04-27 06:39:24 --> URI Class Initialized
INFO - 2021-04-27 06:39:24 --> Router Class Initialized
INFO - 2021-04-27 06:39:24 --> Output Class Initialized
INFO - 2021-04-27 06:39:24 --> Security Class Initialized
DEBUG - 2021-04-27 06:39:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:39:24 --> Input Class Initialized
INFO - 2021-04-27 06:39:24 --> Language Class Initialized
INFO - 2021-04-27 06:39:24 --> Language Class Initialized
INFO - 2021-04-27 06:39:24 --> Config Class Initialized
INFO - 2021-04-27 06:39:24 --> Loader Class Initialized
INFO - 2021-04-27 06:39:24 --> Helper loaded: url_helper
INFO - 2021-04-27 06:39:24 --> Helper loaded: file_helper
INFO - 2021-04-27 06:39:24 --> Helper loaded: form_helper
INFO - 2021-04-27 06:39:24 --> Helper loaded: my_helper
INFO - 2021-04-27 06:39:24 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:39:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:39:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:39:24 --> Controller Class Initialized
INFO - 2021-04-27 06:39:25 --> Config Class Initialized
INFO - 2021-04-27 06:39:25 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:39:25 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:39:25 --> Utf8 Class Initialized
INFO - 2021-04-27 06:39:25 --> URI Class Initialized
INFO - 2021-04-27 06:39:25 --> Router Class Initialized
INFO - 2021-04-27 06:39:25 --> Output Class Initialized
INFO - 2021-04-27 06:39:25 --> Security Class Initialized
DEBUG - 2021-04-27 06:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:39:25 --> Input Class Initialized
INFO - 2021-04-27 06:39:25 --> Language Class Initialized
INFO - 2021-04-27 06:39:25 --> Language Class Initialized
INFO - 2021-04-27 06:39:25 --> Config Class Initialized
INFO - 2021-04-27 06:39:25 --> Loader Class Initialized
INFO - 2021-04-27 06:39:25 --> Helper loaded: url_helper
INFO - 2021-04-27 06:39:25 --> Helper loaded: file_helper
INFO - 2021-04-27 06:39:25 --> Helper loaded: form_helper
INFO - 2021-04-27 06:39:25 --> Helper loaded: my_helper
INFO - 2021-04-27 06:39:25 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:39:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:39:25 --> Controller Class Initialized
DEBUG - 2021-04-27 06:39:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_ekstra/views/list.php
DEBUG - 2021-04-27 06:39:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 06:39:25 --> Final output sent to browser
DEBUG - 2021-04-27 06:39:25 --> Total execution time: 0.1008
INFO - 2021-04-27 06:39:25 --> Config Class Initialized
INFO - 2021-04-27 06:39:25 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:39:25 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:39:25 --> Utf8 Class Initialized
INFO - 2021-04-27 06:39:25 --> URI Class Initialized
INFO - 2021-04-27 06:39:25 --> Router Class Initialized
INFO - 2021-04-27 06:39:25 --> Output Class Initialized
INFO - 2021-04-27 06:39:25 --> Security Class Initialized
DEBUG - 2021-04-27 06:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:39:25 --> Input Class Initialized
INFO - 2021-04-27 06:39:25 --> Language Class Initialized
INFO - 2021-04-27 06:39:25 --> Language Class Initialized
INFO - 2021-04-27 06:39:25 --> Config Class Initialized
INFO - 2021-04-27 06:39:25 --> Loader Class Initialized
INFO - 2021-04-27 06:39:25 --> Helper loaded: url_helper
INFO - 2021-04-27 06:39:25 --> Helper loaded: file_helper
INFO - 2021-04-27 06:39:25 --> Helper loaded: form_helper
INFO - 2021-04-27 06:39:25 --> Helper loaded: my_helper
INFO - 2021-04-27 06:39:25 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:39:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:39:25 --> Controller Class Initialized
INFO - 2021-04-27 06:39:26 --> Config Class Initialized
INFO - 2021-04-27 06:39:26 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:39:26 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:39:26 --> Utf8 Class Initialized
INFO - 2021-04-27 06:39:26 --> URI Class Initialized
INFO - 2021-04-27 06:39:26 --> Router Class Initialized
INFO - 2021-04-27 06:39:26 --> Output Class Initialized
INFO - 2021-04-27 06:39:26 --> Security Class Initialized
DEBUG - 2021-04-27 06:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:39:26 --> Input Class Initialized
INFO - 2021-04-27 06:39:26 --> Language Class Initialized
INFO - 2021-04-27 06:39:26 --> Language Class Initialized
INFO - 2021-04-27 06:39:26 --> Config Class Initialized
INFO - 2021-04-27 06:39:26 --> Loader Class Initialized
INFO - 2021-04-27 06:39:26 --> Helper loaded: url_helper
INFO - 2021-04-27 06:39:26 --> Helper loaded: file_helper
INFO - 2021-04-27 06:39:26 --> Helper loaded: form_helper
INFO - 2021-04-27 06:39:26 --> Helper loaded: my_helper
INFO - 2021-04-27 06:39:26 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:39:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:39:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:39:26 --> Controller Class Initialized
DEBUG - 2021-04-27 06:39:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2021-04-27 06:39:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 06:39:26 --> Final output sent to browser
DEBUG - 2021-04-27 06:39:26 --> Total execution time: 0.1008
INFO - 2021-04-27 06:39:26 --> Config Class Initialized
INFO - 2021-04-27 06:39:26 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:39:26 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:39:26 --> Utf8 Class Initialized
INFO - 2021-04-27 06:39:26 --> URI Class Initialized
INFO - 2021-04-27 06:39:26 --> Router Class Initialized
INFO - 2021-04-27 06:39:26 --> Output Class Initialized
INFO - 2021-04-27 06:39:26 --> Security Class Initialized
DEBUG - 2021-04-27 06:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:39:26 --> Input Class Initialized
INFO - 2021-04-27 06:39:26 --> Language Class Initialized
INFO - 2021-04-27 06:39:26 --> Language Class Initialized
INFO - 2021-04-27 06:39:26 --> Config Class Initialized
INFO - 2021-04-27 06:39:26 --> Loader Class Initialized
INFO - 2021-04-27 06:39:26 --> Helper loaded: url_helper
INFO - 2021-04-27 06:39:26 --> Helper loaded: file_helper
INFO - 2021-04-27 06:39:26 --> Helper loaded: form_helper
INFO - 2021-04-27 06:39:26 --> Helper loaded: my_helper
INFO - 2021-04-27 06:39:26 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:39:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:39:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:39:26 --> Controller Class Initialized
INFO - 2021-04-27 06:39:27 --> Config Class Initialized
INFO - 2021-04-27 06:39:27 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:39:27 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:39:27 --> Utf8 Class Initialized
INFO - 2021-04-27 06:39:27 --> URI Class Initialized
INFO - 2021-04-27 06:39:27 --> Router Class Initialized
INFO - 2021-04-27 06:39:27 --> Output Class Initialized
INFO - 2021-04-27 06:39:27 --> Security Class Initialized
DEBUG - 2021-04-27 06:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:39:27 --> Input Class Initialized
INFO - 2021-04-27 06:39:27 --> Language Class Initialized
INFO - 2021-04-27 06:39:27 --> Language Class Initialized
INFO - 2021-04-27 06:39:27 --> Config Class Initialized
INFO - 2021-04-27 06:39:27 --> Loader Class Initialized
INFO - 2021-04-27 06:39:27 --> Helper loaded: url_helper
INFO - 2021-04-27 06:39:27 --> Helper loaded: file_helper
INFO - 2021-04-27 06:39:27 --> Helper loaded: form_helper
INFO - 2021-04-27 06:39:27 --> Helper loaded: my_helper
INFO - 2021-04-27 06:39:27 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:39:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:39:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:39:27 --> Controller Class Initialized
DEBUG - 2021-04-27 06:39:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2021-04-27 06:39:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 06:39:27 --> Final output sent to browser
DEBUG - 2021-04-27 06:39:27 --> Total execution time: 0.1090
INFO - 2021-04-27 06:39:27 --> Config Class Initialized
INFO - 2021-04-27 06:39:27 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:39:27 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:39:27 --> Utf8 Class Initialized
INFO - 2021-04-27 06:39:27 --> URI Class Initialized
INFO - 2021-04-27 06:39:27 --> Router Class Initialized
INFO - 2021-04-27 06:39:27 --> Output Class Initialized
INFO - 2021-04-27 06:39:27 --> Security Class Initialized
DEBUG - 2021-04-27 06:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:39:27 --> Input Class Initialized
INFO - 2021-04-27 06:39:27 --> Language Class Initialized
INFO - 2021-04-27 06:39:27 --> Language Class Initialized
INFO - 2021-04-27 06:39:27 --> Config Class Initialized
INFO - 2021-04-27 06:39:27 --> Loader Class Initialized
INFO - 2021-04-27 06:39:27 --> Helper loaded: url_helper
INFO - 2021-04-27 06:39:27 --> Helper loaded: file_helper
INFO - 2021-04-27 06:39:27 --> Helper loaded: form_helper
INFO - 2021-04-27 06:39:27 --> Helper loaded: my_helper
INFO - 2021-04-27 06:39:27 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:39:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:39:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:39:27 --> Controller Class Initialized
INFO - 2021-04-27 06:39:28 --> Config Class Initialized
INFO - 2021-04-27 06:39:28 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:39:28 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:39:28 --> Utf8 Class Initialized
INFO - 2021-04-27 06:39:28 --> URI Class Initialized
INFO - 2021-04-27 06:39:28 --> Router Class Initialized
INFO - 2021-04-27 06:39:28 --> Output Class Initialized
INFO - 2021-04-27 06:39:28 --> Security Class Initialized
DEBUG - 2021-04-27 06:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:39:28 --> Input Class Initialized
INFO - 2021-04-27 06:39:28 --> Language Class Initialized
INFO - 2021-04-27 06:39:28 --> Language Class Initialized
INFO - 2021-04-27 06:39:28 --> Config Class Initialized
INFO - 2021-04-27 06:39:28 --> Loader Class Initialized
INFO - 2021-04-27 06:39:28 --> Helper loaded: url_helper
INFO - 2021-04-27 06:39:28 --> Helper loaded: file_helper
INFO - 2021-04-27 06:39:28 --> Helper loaded: form_helper
INFO - 2021-04-27 06:39:28 --> Helper loaded: my_helper
INFO - 2021-04-27 06:39:28 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:39:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:39:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:39:28 --> Controller Class Initialized
DEBUG - 2021-04-27 06:39:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-04-27 06:39:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 06:39:28 --> Final output sent to browser
DEBUG - 2021-04-27 06:39:28 --> Total execution time: 0.0849
INFO - 2021-04-27 06:39:28 --> Config Class Initialized
INFO - 2021-04-27 06:39:28 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:39:28 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:39:28 --> Utf8 Class Initialized
INFO - 2021-04-27 06:39:28 --> URI Class Initialized
INFO - 2021-04-27 06:39:28 --> Router Class Initialized
INFO - 2021-04-27 06:39:28 --> Output Class Initialized
INFO - 2021-04-27 06:39:28 --> Security Class Initialized
DEBUG - 2021-04-27 06:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:39:28 --> Input Class Initialized
INFO - 2021-04-27 06:39:28 --> Language Class Initialized
INFO - 2021-04-27 06:39:28 --> Language Class Initialized
INFO - 2021-04-27 06:39:28 --> Config Class Initialized
INFO - 2021-04-27 06:39:28 --> Loader Class Initialized
INFO - 2021-04-27 06:39:28 --> Helper loaded: url_helper
INFO - 2021-04-27 06:39:28 --> Helper loaded: file_helper
INFO - 2021-04-27 06:39:28 --> Helper loaded: form_helper
INFO - 2021-04-27 06:39:28 --> Helper loaded: my_helper
INFO - 2021-04-27 06:39:28 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:39:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:39:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:39:28 --> Controller Class Initialized
INFO - 2021-04-27 06:39:29 --> Config Class Initialized
INFO - 2021-04-27 06:39:29 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:39:29 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:39:29 --> Utf8 Class Initialized
INFO - 2021-04-27 06:39:29 --> URI Class Initialized
INFO - 2021-04-27 06:39:29 --> Router Class Initialized
INFO - 2021-04-27 06:39:29 --> Output Class Initialized
INFO - 2021-04-27 06:39:29 --> Security Class Initialized
DEBUG - 2021-04-27 06:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:39:29 --> Input Class Initialized
INFO - 2021-04-27 06:39:29 --> Language Class Initialized
INFO - 2021-04-27 06:39:29 --> Language Class Initialized
INFO - 2021-04-27 06:39:29 --> Config Class Initialized
INFO - 2021-04-27 06:39:29 --> Loader Class Initialized
INFO - 2021-04-27 06:39:29 --> Helper loaded: url_helper
INFO - 2021-04-27 06:39:29 --> Helper loaded: file_helper
INFO - 2021-04-27 06:39:29 --> Helper loaded: form_helper
INFO - 2021-04-27 06:39:29 --> Helper loaded: my_helper
INFO - 2021-04-27 06:39:29 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:39:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:39:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:39:29 --> Controller Class Initialized
DEBUG - 2021-04-27 06:39:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2021-04-27 06:39:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 06:39:29 --> Final output sent to browser
DEBUG - 2021-04-27 06:39:29 --> Total execution time: 0.0709
INFO - 2021-04-27 06:39:29 --> Config Class Initialized
INFO - 2021-04-27 06:39:29 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:39:29 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:39:29 --> Utf8 Class Initialized
INFO - 2021-04-27 06:39:29 --> URI Class Initialized
INFO - 2021-04-27 06:39:29 --> Router Class Initialized
INFO - 2021-04-27 06:39:29 --> Output Class Initialized
INFO - 2021-04-27 06:39:29 --> Security Class Initialized
DEBUG - 2021-04-27 06:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:39:29 --> Input Class Initialized
INFO - 2021-04-27 06:39:29 --> Language Class Initialized
INFO - 2021-04-27 06:39:29 --> Language Class Initialized
INFO - 2021-04-27 06:39:29 --> Config Class Initialized
INFO - 2021-04-27 06:39:29 --> Loader Class Initialized
INFO - 2021-04-27 06:39:29 --> Helper loaded: url_helper
INFO - 2021-04-27 06:39:29 --> Helper loaded: file_helper
INFO - 2021-04-27 06:39:29 --> Helper loaded: form_helper
INFO - 2021-04-27 06:39:29 --> Helper loaded: my_helper
INFO - 2021-04-27 06:39:29 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:39:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:39:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:39:29 --> Controller Class Initialized
INFO - 2021-04-27 06:40:36 --> Config Class Initialized
INFO - 2021-04-27 06:40:36 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:40:36 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:40:36 --> Utf8 Class Initialized
INFO - 2021-04-27 06:40:36 --> URI Class Initialized
INFO - 2021-04-27 06:40:36 --> Router Class Initialized
INFO - 2021-04-27 06:40:36 --> Output Class Initialized
INFO - 2021-04-27 06:40:36 --> Security Class Initialized
DEBUG - 2021-04-27 06:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:40:36 --> Input Class Initialized
INFO - 2021-04-27 06:40:36 --> Language Class Initialized
INFO - 2021-04-27 06:40:36 --> Language Class Initialized
INFO - 2021-04-27 06:40:36 --> Config Class Initialized
INFO - 2021-04-27 06:40:36 --> Loader Class Initialized
INFO - 2021-04-27 06:40:36 --> Helper loaded: url_helper
INFO - 2021-04-27 06:40:36 --> Helper loaded: file_helper
INFO - 2021-04-27 06:40:36 --> Helper loaded: form_helper
INFO - 2021-04-27 06:40:36 --> Helper loaded: my_helper
INFO - 2021-04-27 06:40:36 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:40:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:40:36 --> Controller Class Initialized
DEBUG - 2021-04-27 06:40:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-04-27 06:40:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 06:40:36 --> Final output sent to browser
DEBUG - 2021-04-27 06:40:36 --> Total execution time: 0.0670
INFO - 2021-04-27 06:40:37 --> Config Class Initialized
INFO - 2021-04-27 06:40:37 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:40:37 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:40:37 --> Utf8 Class Initialized
INFO - 2021-04-27 06:40:37 --> URI Class Initialized
INFO - 2021-04-27 06:40:37 --> Router Class Initialized
INFO - 2021-04-27 06:40:37 --> Output Class Initialized
INFO - 2021-04-27 06:40:37 --> Security Class Initialized
DEBUG - 2021-04-27 06:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:40:37 --> Input Class Initialized
INFO - 2021-04-27 06:40:37 --> Language Class Initialized
INFO - 2021-04-27 06:40:37 --> Language Class Initialized
INFO - 2021-04-27 06:40:37 --> Config Class Initialized
INFO - 2021-04-27 06:40:37 --> Loader Class Initialized
INFO - 2021-04-27 06:40:37 --> Helper loaded: url_helper
INFO - 2021-04-27 06:40:37 --> Helper loaded: file_helper
INFO - 2021-04-27 06:40:37 --> Helper loaded: form_helper
INFO - 2021-04-27 06:40:37 --> Helper loaded: my_helper
INFO - 2021-04-27 06:40:37 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:40:37 --> Controller Class Initialized
INFO - 2021-04-27 06:50:47 --> Config Class Initialized
INFO - 2021-04-27 06:50:47 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:50:47 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:50:47 --> Utf8 Class Initialized
INFO - 2021-04-27 06:50:47 --> URI Class Initialized
INFO - 2021-04-27 06:50:47 --> Router Class Initialized
INFO - 2021-04-27 06:50:47 --> Output Class Initialized
INFO - 2021-04-27 06:50:47 --> Security Class Initialized
DEBUG - 2021-04-27 06:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:50:47 --> Input Class Initialized
INFO - 2021-04-27 06:50:47 --> Language Class Initialized
INFO - 2021-04-27 06:50:47 --> Language Class Initialized
INFO - 2021-04-27 06:50:47 --> Config Class Initialized
INFO - 2021-04-27 06:50:47 --> Loader Class Initialized
INFO - 2021-04-27 06:50:47 --> Helper loaded: url_helper
INFO - 2021-04-27 06:50:47 --> Helper loaded: file_helper
INFO - 2021-04-27 06:50:47 --> Helper loaded: form_helper
INFO - 2021-04-27 06:50:47 --> Helper loaded: my_helper
INFO - 2021-04-27 06:50:47 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:50:47 --> Controller Class Initialized
DEBUG - 2021-04-27 06:50:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-27 06:50:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 06:50:47 --> Final output sent to browser
DEBUG - 2021-04-27 06:50:47 --> Total execution time: 0.0980
INFO - 2021-04-27 06:51:09 --> Config Class Initialized
INFO - 2021-04-27 06:51:09 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:51:09 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:51:09 --> Utf8 Class Initialized
INFO - 2021-04-27 06:51:09 --> URI Class Initialized
DEBUG - 2021-04-27 06:51:09 --> No URI present. Default controller set.
INFO - 2021-04-27 06:51:09 --> Router Class Initialized
INFO - 2021-04-27 06:51:09 --> Output Class Initialized
INFO - 2021-04-27 06:51:09 --> Security Class Initialized
DEBUG - 2021-04-27 06:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:51:09 --> Input Class Initialized
INFO - 2021-04-27 06:51:09 --> Language Class Initialized
INFO - 2021-04-27 06:51:09 --> Language Class Initialized
INFO - 2021-04-27 06:51:09 --> Config Class Initialized
INFO - 2021-04-27 06:51:09 --> Loader Class Initialized
INFO - 2021-04-27 06:51:09 --> Helper loaded: url_helper
INFO - 2021-04-27 06:51:09 --> Helper loaded: file_helper
INFO - 2021-04-27 06:51:09 --> Helper loaded: form_helper
INFO - 2021-04-27 06:51:09 --> Helper loaded: my_helper
INFO - 2021-04-27 06:51:09 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:51:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:51:09 --> Controller Class Initialized
INFO - 2021-04-27 06:51:09 --> Config Class Initialized
INFO - 2021-04-27 06:51:09 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:51:09 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:51:09 --> Utf8 Class Initialized
INFO - 2021-04-27 06:51:09 --> URI Class Initialized
INFO - 2021-04-27 06:51:09 --> Router Class Initialized
INFO - 2021-04-27 06:51:09 --> Output Class Initialized
INFO - 2021-04-27 06:51:09 --> Security Class Initialized
DEBUG - 2021-04-27 06:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:51:09 --> Input Class Initialized
INFO - 2021-04-27 06:51:09 --> Language Class Initialized
INFO - 2021-04-27 06:51:09 --> Language Class Initialized
INFO - 2021-04-27 06:51:09 --> Config Class Initialized
INFO - 2021-04-27 06:51:09 --> Loader Class Initialized
INFO - 2021-04-27 06:51:09 --> Helper loaded: url_helper
INFO - 2021-04-27 06:51:09 --> Helper loaded: file_helper
INFO - 2021-04-27 06:51:09 --> Helper loaded: form_helper
INFO - 2021-04-27 06:51:09 --> Helper loaded: my_helper
INFO - 2021-04-27 06:51:09 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:51:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:51:09 --> Controller Class Initialized
DEBUG - 2021-04-27 06:51:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-04-27 06:51:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 06:51:09 --> Final output sent to browser
DEBUG - 2021-04-27 06:51:09 --> Total execution time: 0.0812
INFO - 2021-04-27 06:51:14 --> Config Class Initialized
INFO - 2021-04-27 06:51:14 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:51:14 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:51:14 --> Utf8 Class Initialized
INFO - 2021-04-27 06:51:14 --> URI Class Initialized
INFO - 2021-04-27 06:51:14 --> Router Class Initialized
INFO - 2021-04-27 06:51:14 --> Output Class Initialized
INFO - 2021-04-27 06:51:14 --> Security Class Initialized
DEBUG - 2021-04-27 06:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:51:14 --> Input Class Initialized
INFO - 2021-04-27 06:51:14 --> Language Class Initialized
INFO - 2021-04-27 06:51:14 --> Language Class Initialized
INFO - 2021-04-27 06:51:14 --> Config Class Initialized
INFO - 2021-04-27 06:51:14 --> Loader Class Initialized
INFO - 2021-04-27 06:51:14 --> Helper loaded: url_helper
INFO - 2021-04-27 06:51:14 --> Helper loaded: file_helper
INFO - 2021-04-27 06:51:14 --> Helper loaded: form_helper
INFO - 2021-04-27 06:51:14 --> Helper loaded: my_helper
INFO - 2021-04-27 06:51:14 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:51:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:51:14 --> Controller Class Initialized
INFO - 2021-04-27 06:51:14 --> Helper loaded: cookie_helper
INFO - 2021-04-27 06:51:14 --> Final output sent to browser
DEBUG - 2021-04-27 06:51:14 --> Total execution time: 0.0918
INFO - 2021-04-27 06:51:15 --> Config Class Initialized
INFO - 2021-04-27 06:51:15 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:51:15 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:51:15 --> Utf8 Class Initialized
INFO - 2021-04-27 06:51:15 --> URI Class Initialized
INFO - 2021-04-27 06:51:15 --> Router Class Initialized
INFO - 2021-04-27 06:51:15 --> Output Class Initialized
INFO - 2021-04-27 06:51:15 --> Security Class Initialized
DEBUG - 2021-04-27 06:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:51:15 --> Input Class Initialized
INFO - 2021-04-27 06:51:15 --> Language Class Initialized
INFO - 2021-04-27 06:51:15 --> Language Class Initialized
INFO - 2021-04-27 06:51:15 --> Config Class Initialized
INFO - 2021-04-27 06:51:15 --> Loader Class Initialized
INFO - 2021-04-27 06:51:15 --> Helper loaded: url_helper
INFO - 2021-04-27 06:51:15 --> Helper loaded: file_helper
INFO - 2021-04-27 06:51:15 --> Helper loaded: form_helper
INFO - 2021-04-27 06:51:15 --> Helper loaded: my_helper
INFO - 2021-04-27 06:51:15 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:51:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:51:15 --> Controller Class Initialized
DEBUG - 2021-04-27 06:51:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-04-27 06:51:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 06:51:15 --> Final output sent to browser
DEBUG - 2021-04-27 06:51:15 --> Total execution time: 0.1439
INFO - 2021-04-27 06:51:17 --> Config Class Initialized
INFO - 2021-04-27 06:51:17 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:51:17 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:51:17 --> Utf8 Class Initialized
INFO - 2021-04-27 06:51:17 --> URI Class Initialized
INFO - 2021-04-27 06:51:17 --> Router Class Initialized
INFO - 2021-04-27 06:51:17 --> Output Class Initialized
INFO - 2021-04-27 06:51:17 --> Security Class Initialized
DEBUG - 2021-04-27 06:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:51:17 --> Input Class Initialized
INFO - 2021-04-27 06:51:17 --> Language Class Initialized
INFO - 2021-04-27 06:51:17 --> Language Class Initialized
INFO - 2021-04-27 06:51:17 --> Config Class Initialized
INFO - 2021-04-27 06:51:17 --> Loader Class Initialized
INFO - 2021-04-27 06:51:17 --> Helper loaded: url_helper
INFO - 2021-04-27 06:51:17 --> Helper loaded: file_helper
INFO - 2021-04-27 06:51:17 --> Helper loaded: form_helper
INFO - 2021-04-27 06:51:17 --> Helper loaded: my_helper
INFO - 2021-04-27 06:51:17 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:51:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:51:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:51:17 --> Controller Class Initialized
DEBUG - 2021-04-27 06:51:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-27 06:51:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 06:51:17 --> Final output sent to browser
DEBUG - 2021-04-27 06:51:17 --> Total execution time: 0.0813
INFO - 2021-04-27 06:51:18 --> Config Class Initialized
INFO - 2021-04-27 06:51:18 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:51:18 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:51:18 --> Utf8 Class Initialized
INFO - 2021-04-27 06:51:18 --> URI Class Initialized
INFO - 2021-04-27 06:51:18 --> Router Class Initialized
INFO - 2021-04-27 06:51:18 --> Output Class Initialized
INFO - 2021-04-27 06:51:18 --> Security Class Initialized
DEBUG - 2021-04-27 06:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:51:18 --> Input Class Initialized
INFO - 2021-04-27 06:51:18 --> Language Class Initialized
INFO - 2021-04-27 06:51:18 --> Language Class Initialized
INFO - 2021-04-27 06:51:18 --> Config Class Initialized
INFO - 2021-04-27 06:51:18 --> Loader Class Initialized
INFO - 2021-04-27 06:51:18 --> Helper loaded: url_helper
INFO - 2021-04-27 06:51:18 --> Helper loaded: file_helper
INFO - 2021-04-27 06:51:18 --> Helper loaded: form_helper
INFO - 2021-04-27 06:51:18 --> Helper loaded: my_helper
INFO - 2021-04-27 06:51:18 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:51:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:51:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:51:18 --> Controller Class Initialized
DEBUG - 2021-04-27 06:51:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-04-27 06:51:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 06:51:18 --> Final output sent to browser
DEBUG - 2021-04-27 06:51:18 --> Total execution time: 0.0981
INFO - 2021-04-27 06:51:23 --> Config Class Initialized
INFO - 2021-04-27 06:51:23 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:51:23 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:51:23 --> Utf8 Class Initialized
INFO - 2021-04-27 06:51:23 --> URI Class Initialized
INFO - 2021-04-27 06:51:23 --> Router Class Initialized
INFO - 2021-04-27 06:51:23 --> Output Class Initialized
INFO - 2021-04-27 06:51:23 --> Security Class Initialized
DEBUG - 2021-04-27 06:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:51:23 --> Input Class Initialized
INFO - 2021-04-27 06:51:23 --> Language Class Initialized
INFO - 2021-04-27 06:51:23 --> Language Class Initialized
INFO - 2021-04-27 06:51:23 --> Config Class Initialized
INFO - 2021-04-27 06:51:23 --> Loader Class Initialized
INFO - 2021-04-27 06:51:23 --> Helper loaded: url_helper
INFO - 2021-04-27 06:51:23 --> Helper loaded: file_helper
INFO - 2021-04-27 06:51:23 --> Helper loaded: form_helper
INFO - 2021-04-27 06:51:23 --> Helper loaded: my_helper
INFO - 2021-04-27 06:51:23 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:51:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:51:23 --> Controller Class Initialized
INFO - 2021-04-27 06:51:23 --> Config Class Initialized
INFO - 2021-04-27 06:51:23 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:51:23 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:51:23 --> Utf8 Class Initialized
INFO - 2021-04-27 06:51:23 --> URI Class Initialized
INFO - 2021-04-27 06:51:23 --> Router Class Initialized
INFO - 2021-04-27 06:51:23 --> Output Class Initialized
INFO - 2021-04-27 06:51:23 --> Security Class Initialized
DEBUG - 2021-04-27 06:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:51:23 --> Input Class Initialized
INFO - 2021-04-27 06:51:23 --> Language Class Initialized
INFO - 2021-04-27 06:51:23 --> Language Class Initialized
INFO - 2021-04-27 06:51:23 --> Config Class Initialized
INFO - 2021-04-27 06:51:23 --> Loader Class Initialized
INFO - 2021-04-27 06:51:23 --> Helper loaded: url_helper
INFO - 2021-04-27 06:51:23 --> Helper loaded: file_helper
INFO - 2021-04-27 06:51:23 --> Helper loaded: form_helper
INFO - 2021-04-27 06:51:23 --> Helper loaded: my_helper
INFO - 2021-04-27 06:51:23 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:51:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:51:23 --> Controller Class Initialized
DEBUG - 2021-04-27 06:51:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-27 06:51:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 06:51:23 --> Final output sent to browser
DEBUG - 2021-04-27 06:51:23 --> Total execution time: 0.0767
INFO - 2021-04-27 06:52:04 --> Config Class Initialized
INFO - 2021-04-27 06:52:04 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:52:04 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:52:04 --> Utf8 Class Initialized
INFO - 2021-04-27 06:52:04 --> URI Class Initialized
DEBUG - 2021-04-27 06:52:04 --> No URI present. Default controller set.
INFO - 2021-04-27 06:52:04 --> Router Class Initialized
INFO - 2021-04-27 06:52:04 --> Output Class Initialized
INFO - 2021-04-27 06:52:04 --> Security Class Initialized
DEBUG - 2021-04-27 06:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:52:04 --> Input Class Initialized
INFO - 2021-04-27 06:52:04 --> Language Class Initialized
INFO - 2021-04-27 06:52:04 --> Language Class Initialized
INFO - 2021-04-27 06:52:04 --> Config Class Initialized
INFO - 2021-04-27 06:52:04 --> Loader Class Initialized
INFO - 2021-04-27 06:52:04 --> Helper loaded: url_helper
INFO - 2021-04-27 06:52:04 --> Helper loaded: file_helper
INFO - 2021-04-27 06:52:04 --> Helper loaded: form_helper
INFO - 2021-04-27 06:52:04 --> Helper loaded: my_helper
INFO - 2021-04-27 06:52:04 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:52:04 --> Controller Class Initialized
INFO - 2021-04-27 06:52:04 --> Config Class Initialized
INFO - 2021-04-27 06:52:04 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:52:04 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:52:04 --> Utf8 Class Initialized
INFO - 2021-04-27 06:52:04 --> URI Class Initialized
INFO - 2021-04-27 06:52:04 --> Router Class Initialized
INFO - 2021-04-27 06:52:04 --> Output Class Initialized
INFO - 2021-04-27 06:52:04 --> Security Class Initialized
DEBUG - 2021-04-27 06:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:52:04 --> Input Class Initialized
INFO - 2021-04-27 06:52:04 --> Language Class Initialized
INFO - 2021-04-27 06:52:04 --> Language Class Initialized
INFO - 2021-04-27 06:52:04 --> Config Class Initialized
INFO - 2021-04-27 06:52:04 --> Loader Class Initialized
INFO - 2021-04-27 06:52:04 --> Helper loaded: url_helper
INFO - 2021-04-27 06:52:04 --> Helper loaded: file_helper
INFO - 2021-04-27 06:52:04 --> Helper loaded: form_helper
INFO - 2021-04-27 06:52:04 --> Helper loaded: my_helper
INFO - 2021-04-27 06:52:04 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:52:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:52:05 --> Controller Class Initialized
DEBUG - 2021-04-27 06:52:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-04-27 06:52:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 06:52:05 --> Final output sent to browser
DEBUG - 2021-04-27 06:52:05 --> Total execution time: 0.0659
INFO - 2021-04-27 06:52:22 --> Config Class Initialized
INFO - 2021-04-27 06:52:22 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:52:22 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:52:22 --> Utf8 Class Initialized
INFO - 2021-04-27 06:52:22 --> URI Class Initialized
INFO - 2021-04-27 06:52:22 --> Router Class Initialized
INFO - 2021-04-27 06:52:22 --> Output Class Initialized
INFO - 2021-04-27 06:52:22 --> Security Class Initialized
DEBUG - 2021-04-27 06:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:52:22 --> Input Class Initialized
INFO - 2021-04-27 06:52:22 --> Language Class Initialized
INFO - 2021-04-27 06:52:22 --> Language Class Initialized
INFO - 2021-04-27 06:52:22 --> Config Class Initialized
INFO - 2021-04-27 06:52:22 --> Loader Class Initialized
INFO - 2021-04-27 06:52:22 --> Helper loaded: url_helper
INFO - 2021-04-27 06:52:22 --> Helper loaded: file_helper
INFO - 2021-04-27 06:52:22 --> Helper loaded: form_helper
INFO - 2021-04-27 06:52:22 --> Helper loaded: my_helper
INFO - 2021-04-27 06:52:22 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:52:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:52:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:52:22 --> Controller Class Initialized
INFO - 2021-04-27 06:52:22 --> Helper loaded: cookie_helper
INFO - 2021-04-27 06:52:22 --> Final output sent to browser
DEBUG - 2021-04-27 06:52:22 --> Total execution time: 0.0828
INFO - 2021-04-27 06:52:25 --> Config Class Initialized
INFO - 2021-04-27 06:52:25 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:52:25 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:52:25 --> Utf8 Class Initialized
INFO - 2021-04-27 06:52:25 --> URI Class Initialized
INFO - 2021-04-27 06:52:25 --> Router Class Initialized
INFO - 2021-04-27 06:52:25 --> Output Class Initialized
INFO - 2021-04-27 06:52:25 --> Security Class Initialized
DEBUG - 2021-04-27 06:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:52:25 --> Input Class Initialized
INFO - 2021-04-27 06:52:25 --> Language Class Initialized
INFO - 2021-04-27 06:52:25 --> Language Class Initialized
INFO - 2021-04-27 06:52:25 --> Config Class Initialized
INFO - 2021-04-27 06:52:25 --> Loader Class Initialized
INFO - 2021-04-27 06:52:25 --> Helper loaded: url_helper
INFO - 2021-04-27 06:52:25 --> Helper loaded: file_helper
INFO - 2021-04-27 06:52:25 --> Helper loaded: form_helper
INFO - 2021-04-27 06:52:25 --> Helper loaded: my_helper
INFO - 2021-04-27 06:52:25 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:52:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:52:25 --> Controller Class Initialized
DEBUG - 2021-04-27 06:52:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-04-27 06:52:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 06:52:25 --> Final output sent to browser
DEBUG - 2021-04-27 06:52:25 --> Total execution time: 0.0767
INFO - 2021-04-27 06:52:27 --> Config Class Initialized
INFO - 2021-04-27 06:52:27 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:52:27 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:52:27 --> Utf8 Class Initialized
INFO - 2021-04-27 06:52:27 --> URI Class Initialized
INFO - 2021-04-27 06:52:27 --> Router Class Initialized
INFO - 2021-04-27 06:52:27 --> Output Class Initialized
INFO - 2021-04-27 06:52:27 --> Security Class Initialized
DEBUG - 2021-04-27 06:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:52:27 --> Input Class Initialized
INFO - 2021-04-27 06:52:27 --> Language Class Initialized
INFO - 2021-04-27 06:52:27 --> Language Class Initialized
INFO - 2021-04-27 06:52:27 --> Config Class Initialized
INFO - 2021-04-27 06:52:27 --> Loader Class Initialized
INFO - 2021-04-27 06:52:27 --> Helper loaded: url_helper
INFO - 2021-04-27 06:52:27 --> Helper loaded: file_helper
INFO - 2021-04-27 06:52:27 --> Helper loaded: form_helper
INFO - 2021-04-27 06:52:27 --> Helper loaded: my_helper
INFO - 2021-04-27 06:52:27 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:52:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:52:27 --> Controller Class Initialized
DEBUG - 2021-04-27 06:52:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-27 06:52:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 06:52:27 --> Final output sent to browser
DEBUG - 2021-04-27 06:52:27 --> Total execution time: 0.0642
INFO - 2021-04-27 06:55:49 --> Config Class Initialized
INFO - 2021-04-27 06:55:49 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:55:49 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:55:49 --> Utf8 Class Initialized
INFO - 2021-04-27 06:55:49 --> URI Class Initialized
INFO - 2021-04-27 06:55:49 --> Router Class Initialized
INFO - 2021-04-27 06:55:49 --> Output Class Initialized
INFO - 2021-04-27 06:55:49 --> Security Class Initialized
DEBUG - 2021-04-27 06:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:55:49 --> Input Class Initialized
INFO - 2021-04-27 06:55:49 --> Language Class Initialized
INFO - 2021-04-27 06:55:49 --> Language Class Initialized
INFO - 2021-04-27 06:55:49 --> Config Class Initialized
INFO - 2021-04-27 06:55:49 --> Loader Class Initialized
INFO - 2021-04-27 06:55:49 --> Helper loaded: url_helper
INFO - 2021-04-27 06:55:49 --> Helper loaded: file_helper
INFO - 2021-04-27 06:55:49 --> Helper loaded: form_helper
INFO - 2021-04-27 06:55:49 --> Helper loaded: my_helper
INFO - 2021-04-27 06:55:49 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:55:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:55:49 --> Controller Class Initialized
DEBUG - 2021-04-27 06:55:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-27 06:55:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 06:55:49 --> Final output sent to browser
DEBUG - 2021-04-27 06:55:49 --> Total execution time: 0.0653
INFO - 2021-04-27 06:55:57 --> Config Class Initialized
INFO - 2021-04-27 06:55:57 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:55:57 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:55:57 --> Utf8 Class Initialized
INFO - 2021-04-27 06:55:57 --> URI Class Initialized
INFO - 2021-04-27 06:55:57 --> Router Class Initialized
INFO - 2021-04-27 06:55:57 --> Output Class Initialized
INFO - 2021-04-27 06:55:57 --> Security Class Initialized
DEBUG - 2021-04-27 06:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:55:57 --> Input Class Initialized
INFO - 2021-04-27 06:55:57 --> Language Class Initialized
INFO - 2021-04-27 06:55:57 --> Language Class Initialized
INFO - 2021-04-27 06:55:57 --> Config Class Initialized
INFO - 2021-04-27 06:55:57 --> Loader Class Initialized
INFO - 2021-04-27 06:55:57 --> Helper loaded: url_helper
INFO - 2021-04-27 06:55:57 --> Helper loaded: file_helper
INFO - 2021-04-27 06:55:57 --> Helper loaded: form_helper
INFO - 2021-04-27 06:55:57 --> Helper loaded: my_helper
INFO - 2021-04-27 06:55:57 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:55:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:55:57 --> Controller Class Initialized
DEBUG - 2021-04-27 06:55:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-27 06:55:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 06:55:57 --> Final output sent to browser
DEBUG - 2021-04-27 06:55:57 --> Total execution time: 0.0722
INFO - 2021-04-27 06:58:55 --> Config Class Initialized
INFO - 2021-04-27 06:58:55 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:58:55 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:58:55 --> Utf8 Class Initialized
INFO - 2021-04-27 06:58:55 --> URI Class Initialized
INFO - 2021-04-27 06:58:55 --> Router Class Initialized
INFO - 2021-04-27 06:58:55 --> Output Class Initialized
INFO - 2021-04-27 06:58:55 --> Security Class Initialized
DEBUG - 2021-04-27 06:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:58:55 --> Input Class Initialized
INFO - 2021-04-27 06:58:55 --> Language Class Initialized
ERROR - 2021-04-27 06:58:55 --> Severity: Parsing Error --> syntax error, unexpected ';' C:\xampp\htdocs\nilai\application\modules\set_kelas\controllers\Set_kelas.php 110
INFO - 2021-04-27 06:59:04 --> Config Class Initialized
INFO - 2021-04-27 06:59:04 --> Hooks Class Initialized
DEBUG - 2021-04-27 06:59:04 --> UTF-8 Support Enabled
INFO - 2021-04-27 06:59:04 --> Utf8 Class Initialized
INFO - 2021-04-27 06:59:04 --> URI Class Initialized
INFO - 2021-04-27 06:59:04 --> Router Class Initialized
INFO - 2021-04-27 06:59:04 --> Output Class Initialized
INFO - 2021-04-27 06:59:04 --> Security Class Initialized
DEBUG - 2021-04-27 06:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 06:59:04 --> Input Class Initialized
INFO - 2021-04-27 06:59:04 --> Language Class Initialized
INFO - 2021-04-27 06:59:04 --> Language Class Initialized
INFO - 2021-04-27 06:59:04 --> Config Class Initialized
INFO - 2021-04-27 06:59:04 --> Loader Class Initialized
INFO - 2021-04-27 06:59:04 --> Helper loaded: url_helper
INFO - 2021-04-27 06:59:04 --> Helper loaded: file_helper
INFO - 2021-04-27 06:59:04 --> Helper loaded: form_helper
INFO - 2021-04-27 06:59:04 --> Helper loaded: my_helper
INFO - 2021-04-27 06:59:04 --> Database Driver Class Initialized
DEBUG - 2021-04-27 06:59:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 06:59:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 06:59:04 --> Controller Class Initialized
DEBUG - 2021-04-27 06:59:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-27 06:59:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 06:59:04 --> Final output sent to browser
DEBUG - 2021-04-27 06:59:04 --> Total execution time: 0.0644
INFO - 2021-04-27 07:04:37 --> Config Class Initialized
INFO - 2021-04-27 07:04:37 --> Hooks Class Initialized
DEBUG - 2021-04-27 07:04:37 --> UTF-8 Support Enabled
INFO - 2021-04-27 07:04:37 --> Utf8 Class Initialized
INFO - 2021-04-27 07:04:37 --> URI Class Initialized
INFO - 2021-04-27 07:04:37 --> Router Class Initialized
INFO - 2021-04-27 07:04:37 --> Output Class Initialized
INFO - 2021-04-27 07:04:37 --> Security Class Initialized
DEBUG - 2021-04-27 07:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 07:04:37 --> Input Class Initialized
INFO - 2021-04-27 07:04:37 --> Language Class Initialized
INFO - 2021-04-27 07:04:37 --> Language Class Initialized
INFO - 2021-04-27 07:04:37 --> Config Class Initialized
INFO - 2021-04-27 07:04:37 --> Loader Class Initialized
INFO - 2021-04-27 07:04:37 --> Helper loaded: url_helper
INFO - 2021-04-27 07:04:37 --> Helper loaded: file_helper
INFO - 2021-04-27 07:04:37 --> Helper loaded: form_helper
INFO - 2021-04-27 07:04:37 --> Helper loaded: my_helper
INFO - 2021-04-27 07:04:37 --> Database Driver Class Initialized
DEBUG - 2021-04-27 07:04:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 07:04:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 07:04:37 --> Controller Class Initialized
DEBUG - 2021-04-27 07:04:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-04-27 07:04:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 07:04:37 --> Final output sent to browser
DEBUG - 2021-04-27 07:04:37 --> Total execution time: 0.0503
INFO - 2021-04-27 07:04:37 --> Config Class Initialized
INFO - 2021-04-27 07:04:37 --> Hooks Class Initialized
DEBUG - 2021-04-27 07:04:37 --> UTF-8 Support Enabled
INFO - 2021-04-27 07:04:37 --> Utf8 Class Initialized
INFO - 2021-04-27 07:04:37 --> URI Class Initialized
INFO - 2021-04-27 07:04:37 --> Router Class Initialized
INFO - 2021-04-27 07:04:37 --> Output Class Initialized
INFO - 2021-04-27 07:04:37 --> Security Class Initialized
DEBUG - 2021-04-27 07:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 07:04:37 --> Input Class Initialized
INFO - 2021-04-27 07:04:37 --> Language Class Initialized
INFO - 2021-04-27 07:04:37 --> Language Class Initialized
INFO - 2021-04-27 07:04:37 --> Config Class Initialized
INFO - 2021-04-27 07:04:37 --> Loader Class Initialized
INFO - 2021-04-27 07:04:37 --> Helper loaded: url_helper
INFO - 2021-04-27 07:04:37 --> Helper loaded: file_helper
INFO - 2021-04-27 07:04:37 --> Helper loaded: form_helper
INFO - 2021-04-27 07:04:37 --> Helper loaded: my_helper
INFO - 2021-04-27 07:04:37 --> Database Driver Class Initialized
DEBUG - 2021-04-27 07:04:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 07:04:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 07:04:37 --> Controller Class Initialized
INFO - 2021-04-27 07:06:45 --> Config Class Initialized
INFO - 2021-04-27 07:06:45 --> Hooks Class Initialized
DEBUG - 2021-04-27 07:06:45 --> UTF-8 Support Enabled
INFO - 2021-04-27 07:06:45 --> Utf8 Class Initialized
INFO - 2021-04-27 07:06:45 --> URI Class Initialized
INFO - 2021-04-27 07:06:45 --> Router Class Initialized
INFO - 2021-04-27 07:06:46 --> Output Class Initialized
INFO - 2021-04-27 07:06:46 --> Security Class Initialized
DEBUG - 2021-04-27 07:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 07:06:46 --> Input Class Initialized
INFO - 2021-04-27 07:06:46 --> Language Class Initialized
ERROR - 2021-04-27 07:06:46 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\xampp\htdocs\nilai\application\modules\set_kelas\controllers\Set_kelas.php 128
INFO - 2021-04-27 07:07:10 --> Config Class Initialized
INFO - 2021-04-27 07:07:10 --> Hooks Class Initialized
DEBUG - 2021-04-27 07:07:10 --> UTF-8 Support Enabled
INFO - 2021-04-27 07:07:10 --> Utf8 Class Initialized
INFO - 2021-04-27 07:07:10 --> URI Class Initialized
INFO - 2021-04-27 07:07:10 --> Router Class Initialized
INFO - 2021-04-27 07:07:10 --> Output Class Initialized
INFO - 2021-04-27 07:07:10 --> Security Class Initialized
DEBUG - 2021-04-27 07:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 07:07:10 --> Input Class Initialized
INFO - 2021-04-27 07:07:10 --> Language Class Initialized
INFO - 2021-04-27 07:07:10 --> Language Class Initialized
INFO - 2021-04-27 07:07:10 --> Config Class Initialized
INFO - 2021-04-27 07:07:10 --> Loader Class Initialized
INFO - 2021-04-27 07:07:10 --> Helper loaded: url_helper
INFO - 2021-04-27 07:07:10 --> Helper loaded: file_helper
INFO - 2021-04-27 07:07:10 --> Helper loaded: form_helper
INFO - 2021-04-27 07:07:10 --> Helper loaded: my_helper
INFO - 2021-04-27 07:07:10 --> Database Driver Class Initialized
DEBUG - 2021-04-27 07:07:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 07:07:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 07:07:10 --> Controller Class Initialized
DEBUG - 2021-04-27 07:07:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-27 07:07:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 07:07:10 --> Final output sent to browser
DEBUG - 2021-04-27 07:07:10 --> Total execution time: 0.0589
INFO - 2021-04-27 07:26:02 --> Config Class Initialized
INFO - 2021-04-27 07:26:02 --> Hooks Class Initialized
DEBUG - 2021-04-27 07:26:02 --> UTF-8 Support Enabled
INFO - 2021-04-27 07:26:02 --> Utf8 Class Initialized
INFO - 2021-04-27 07:26:02 --> URI Class Initialized
INFO - 2021-04-27 07:26:02 --> Router Class Initialized
INFO - 2021-04-27 07:26:02 --> Output Class Initialized
INFO - 2021-04-27 07:26:02 --> Security Class Initialized
DEBUG - 2021-04-27 07:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 07:26:02 --> Input Class Initialized
INFO - 2021-04-27 07:26:02 --> Language Class Initialized
INFO - 2021-04-27 07:26:02 --> Language Class Initialized
INFO - 2021-04-27 07:26:02 --> Config Class Initialized
INFO - 2021-04-27 07:26:02 --> Loader Class Initialized
INFO - 2021-04-27 07:26:02 --> Helper loaded: url_helper
INFO - 2021-04-27 07:26:02 --> Helper loaded: file_helper
INFO - 2021-04-27 07:26:02 --> Helper loaded: form_helper
INFO - 2021-04-27 07:26:02 --> Helper loaded: my_helper
INFO - 2021-04-27 07:26:02 --> Database Driver Class Initialized
DEBUG - 2021-04-27 07:26:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 07:26:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 07:26:02 --> Controller Class Initialized
DEBUG - 2021-04-27 07:26:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-27 07:26:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 07:26:02 --> Final output sent to browser
DEBUG - 2021-04-27 07:26:02 --> Total execution time: 0.0562
INFO - 2021-04-27 07:26:03 --> Config Class Initialized
INFO - 2021-04-27 07:26:03 --> Hooks Class Initialized
DEBUG - 2021-04-27 07:26:03 --> UTF-8 Support Enabled
INFO - 2021-04-27 07:26:03 --> Utf8 Class Initialized
INFO - 2021-04-27 07:26:03 --> URI Class Initialized
INFO - 2021-04-27 07:26:03 --> Router Class Initialized
INFO - 2021-04-27 07:26:03 --> Output Class Initialized
INFO - 2021-04-27 07:26:03 --> Security Class Initialized
DEBUG - 2021-04-27 07:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 07:26:03 --> Input Class Initialized
INFO - 2021-04-27 07:26:03 --> Language Class Initialized
INFO - 2021-04-27 07:26:03 --> Language Class Initialized
INFO - 2021-04-27 07:26:03 --> Config Class Initialized
INFO - 2021-04-27 07:26:03 --> Loader Class Initialized
INFO - 2021-04-27 07:26:03 --> Helper loaded: url_helper
INFO - 2021-04-27 07:26:03 --> Helper loaded: file_helper
INFO - 2021-04-27 07:26:03 --> Helper loaded: form_helper
INFO - 2021-04-27 07:26:03 --> Helper loaded: my_helper
INFO - 2021-04-27 07:26:03 --> Database Driver Class Initialized
DEBUG - 2021-04-27 07:26:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 07:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 07:26:03 --> Controller Class Initialized
DEBUG - 2021-04-27 07:26:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-27 07:26:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 07:26:03 --> Final output sent to browser
DEBUG - 2021-04-27 07:26:03 --> Total execution time: 0.0716
INFO - 2021-04-27 07:26:13 --> Config Class Initialized
INFO - 2021-04-27 07:26:13 --> Hooks Class Initialized
DEBUG - 2021-04-27 07:26:13 --> UTF-8 Support Enabled
INFO - 2021-04-27 07:26:13 --> Utf8 Class Initialized
INFO - 2021-04-27 07:26:13 --> URI Class Initialized
INFO - 2021-04-27 07:26:13 --> Router Class Initialized
INFO - 2021-04-27 07:26:13 --> Output Class Initialized
INFO - 2021-04-27 07:26:13 --> Security Class Initialized
DEBUG - 2021-04-27 07:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 07:26:13 --> Input Class Initialized
INFO - 2021-04-27 07:26:13 --> Language Class Initialized
INFO - 2021-04-27 07:26:13 --> Language Class Initialized
INFO - 2021-04-27 07:26:13 --> Config Class Initialized
INFO - 2021-04-27 07:26:13 --> Loader Class Initialized
INFO - 2021-04-27 07:26:13 --> Helper loaded: url_helper
INFO - 2021-04-27 07:26:13 --> Helper loaded: file_helper
INFO - 2021-04-27 07:26:13 --> Helper loaded: form_helper
INFO - 2021-04-27 07:26:13 --> Helper loaded: my_helper
INFO - 2021-04-27 07:26:13 --> Database Driver Class Initialized
DEBUG - 2021-04-27 07:26:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 07:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 07:26:13 --> Controller Class Initialized
ERROR - 2021-04-27 07:26:13 --> Query error: Unknown column 'b.nmsiswa' in 'field list' - Invalid query: SELECT 
                                                        a.id, a.id_kelas, b.nmsiswa
                                                        FROM t_kelas_siswa a
                                                        INNER JOIN m_siswa b ON a.id_siswa = b.id
                                                        WHERE a.id_kelas = '12' 
                                                        AND a.ta = '2020'
                                                        ORDER BY b.nama ASC, b.nis ASC
INFO - 2021-04-27 07:26:13 --> Language file loaded: language/english/db_lang.php
INFO - 2021-04-27 07:26:46 --> Config Class Initialized
INFO - 2021-04-27 07:26:46 --> Hooks Class Initialized
DEBUG - 2021-04-27 07:26:46 --> UTF-8 Support Enabled
INFO - 2021-04-27 07:26:46 --> Utf8 Class Initialized
INFO - 2021-04-27 07:26:46 --> URI Class Initialized
INFO - 2021-04-27 07:26:46 --> Router Class Initialized
INFO - 2021-04-27 07:26:46 --> Output Class Initialized
INFO - 2021-04-27 07:26:46 --> Security Class Initialized
DEBUG - 2021-04-27 07:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 07:26:46 --> Input Class Initialized
INFO - 2021-04-27 07:26:46 --> Language Class Initialized
INFO - 2021-04-27 07:26:46 --> Language Class Initialized
INFO - 2021-04-27 07:26:46 --> Config Class Initialized
INFO - 2021-04-27 07:26:46 --> Loader Class Initialized
INFO - 2021-04-27 07:26:46 --> Helper loaded: url_helper
INFO - 2021-04-27 07:26:46 --> Helper loaded: file_helper
INFO - 2021-04-27 07:26:46 --> Helper loaded: form_helper
INFO - 2021-04-27 07:26:46 --> Helper loaded: my_helper
INFO - 2021-04-27 07:26:46 --> Database Driver Class Initialized
DEBUG - 2021-04-27 07:26:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 07:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 07:26:46 --> Controller Class Initialized
DEBUG - 2021-04-27 07:26:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-27 07:26:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 07:26:46 --> Final output sent to browser
DEBUG - 2021-04-27 07:26:46 --> Total execution time: 0.0692
INFO - 2021-04-27 07:26:55 --> Config Class Initialized
INFO - 2021-04-27 07:26:55 --> Hooks Class Initialized
DEBUG - 2021-04-27 07:26:55 --> UTF-8 Support Enabled
INFO - 2021-04-27 07:26:55 --> Utf8 Class Initialized
INFO - 2021-04-27 07:26:55 --> URI Class Initialized
INFO - 2021-04-27 07:26:55 --> Router Class Initialized
INFO - 2021-04-27 07:26:55 --> Output Class Initialized
INFO - 2021-04-27 07:26:55 --> Security Class Initialized
DEBUG - 2021-04-27 07:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 07:26:55 --> Input Class Initialized
INFO - 2021-04-27 07:26:55 --> Language Class Initialized
INFO - 2021-04-27 07:26:55 --> Language Class Initialized
INFO - 2021-04-27 07:26:55 --> Config Class Initialized
INFO - 2021-04-27 07:26:55 --> Loader Class Initialized
INFO - 2021-04-27 07:26:55 --> Helper loaded: url_helper
INFO - 2021-04-27 07:26:55 --> Helper loaded: file_helper
INFO - 2021-04-27 07:26:55 --> Helper loaded: form_helper
INFO - 2021-04-27 07:26:55 --> Helper loaded: my_helper
INFO - 2021-04-27 07:26:55 --> Database Driver Class Initialized
DEBUG - 2021-04-27 07:26:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 07:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 07:26:55 --> Controller Class Initialized
DEBUG - 2021-04-27 07:26:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-27 07:26:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 07:26:55 --> Final output sent to browser
DEBUG - 2021-04-27 07:26:55 --> Total execution time: 0.0452
INFO - 2021-04-27 07:28:30 --> Config Class Initialized
INFO - 2021-04-27 07:28:30 --> Hooks Class Initialized
DEBUG - 2021-04-27 07:28:30 --> UTF-8 Support Enabled
INFO - 2021-04-27 07:28:30 --> Utf8 Class Initialized
INFO - 2021-04-27 07:28:30 --> URI Class Initialized
INFO - 2021-04-27 07:28:30 --> Router Class Initialized
INFO - 2021-04-27 07:28:30 --> Output Class Initialized
INFO - 2021-04-27 07:28:30 --> Security Class Initialized
DEBUG - 2021-04-27 07:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 07:28:30 --> Input Class Initialized
INFO - 2021-04-27 07:28:30 --> Language Class Initialized
INFO - 2021-04-27 07:28:30 --> Language Class Initialized
INFO - 2021-04-27 07:28:30 --> Config Class Initialized
INFO - 2021-04-27 07:28:30 --> Loader Class Initialized
INFO - 2021-04-27 07:28:30 --> Helper loaded: url_helper
INFO - 2021-04-27 07:28:30 --> Helper loaded: file_helper
INFO - 2021-04-27 07:28:30 --> Helper loaded: form_helper
INFO - 2021-04-27 07:28:30 --> Helper loaded: my_helper
INFO - 2021-04-27 07:28:30 --> Database Driver Class Initialized
DEBUG - 2021-04-27 07:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 07:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 07:28:30 --> Controller Class Initialized
DEBUG - 2021-04-27 07:28:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-27 07:28:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 07:28:30 --> Final output sent to browser
DEBUG - 2021-04-27 07:28:30 --> Total execution time: 0.0759
INFO - 2021-04-27 07:28:38 --> Config Class Initialized
INFO - 2021-04-27 07:28:38 --> Hooks Class Initialized
DEBUG - 2021-04-27 07:28:38 --> UTF-8 Support Enabled
INFO - 2021-04-27 07:28:38 --> Utf8 Class Initialized
INFO - 2021-04-27 07:28:38 --> URI Class Initialized
INFO - 2021-04-27 07:28:38 --> Router Class Initialized
INFO - 2021-04-27 07:28:38 --> Output Class Initialized
INFO - 2021-04-27 07:28:38 --> Security Class Initialized
DEBUG - 2021-04-27 07:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 07:28:38 --> Input Class Initialized
INFO - 2021-04-27 07:28:38 --> Language Class Initialized
INFO - 2021-04-27 07:28:38 --> Language Class Initialized
INFO - 2021-04-27 07:28:38 --> Config Class Initialized
INFO - 2021-04-27 07:28:38 --> Loader Class Initialized
INFO - 2021-04-27 07:28:38 --> Helper loaded: url_helper
INFO - 2021-04-27 07:28:38 --> Helper loaded: file_helper
INFO - 2021-04-27 07:28:38 --> Helper loaded: form_helper
INFO - 2021-04-27 07:28:38 --> Helper loaded: my_helper
INFO - 2021-04-27 07:28:38 --> Database Driver Class Initialized
DEBUG - 2021-04-27 07:28:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 07:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 07:28:38 --> Controller Class Initialized
DEBUG - 2021-04-27 07:28:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-27 07:28:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 07:28:38 --> Final output sent to browser
DEBUG - 2021-04-27 07:28:38 --> Total execution time: 0.0533
INFO - 2021-04-27 07:31:57 --> Config Class Initialized
INFO - 2021-04-27 07:31:57 --> Hooks Class Initialized
DEBUG - 2021-04-27 07:31:57 --> UTF-8 Support Enabled
INFO - 2021-04-27 07:31:57 --> Utf8 Class Initialized
INFO - 2021-04-27 07:31:57 --> URI Class Initialized
INFO - 2021-04-27 07:31:57 --> Router Class Initialized
INFO - 2021-04-27 07:31:57 --> Output Class Initialized
INFO - 2021-04-27 07:31:57 --> Security Class Initialized
DEBUG - 2021-04-27 07:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 07:31:57 --> Input Class Initialized
INFO - 2021-04-27 07:31:57 --> Language Class Initialized
INFO - 2021-04-27 07:31:57 --> Language Class Initialized
INFO - 2021-04-27 07:31:57 --> Config Class Initialized
INFO - 2021-04-27 07:31:57 --> Loader Class Initialized
INFO - 2021-04-27 07:31:57 --> Helper loaded: url_helper
INFO - 2021-04-27 07:31:57 --> Helper loaded: file_helper
INFO - 2021-04-27 07:31:57 --> Helper loaded: form_helper
INFO - 2021-04-27 07:31:57 --> Helper loaded: my_helper
INFO - 2021-04-27 07:31:57 --> Database Driver Class Initialized
DEBUG - 2021-04-27 07:31:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 07:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 07:31:57 --> Controller Class Initialized
ERROR - 2021-04-27 07:31:57 --> Query error: Unknown column 'b.nmsiswa' in 'field list' - Invalid query: SELECT 
                                                        a.id, a.id_kelas, b.nmsiswa
                                                        FROM t_kelas_siswa a
                                                        INNER JOIN m_siswa b ON a.id_siswa = b.id
                                                        WHERE a.id_kelas = '12' 
                                                        AND a.ta = '2020'
                                                        ORDER BY b.nama ASC, b.nis ASC
INFO - 2021-04-27 07:31:57 --> Language file loaded: language/english/db_lang.php
INFO - 2021-04-27 07:32:18 --> Config Class Initialized
INFO - 2021-04-27 07:32:18 --> Hooks Class Initialized
DEBUG - 2021-04-27 07:32:18 --> UTF-8 Support Enabled
INFO - 2021-04-27 07:32:18 --> Utf8 Class Initialized
INFO - 2021-04-27 07:32:18 --> URI Class Initialized
INFO - 2021-04-27 07:32:18 --> Router Class Initialized
INFO - 2021-04-27 07:32:18 --> Output Class Initialized
INFO - 2021-04-27 07:32:18 --> Security Class Initialized
DEBUG - 2021-04-27 07:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 07:32:18 --> Input Class Initialized
INFO - 2021-04-27 07:32:18 --> Language Class Initialized
INFO - 2021-04-27 07:32:18 --> Language Class Initialized
INFO - 2021-04-27 07:32:18 --> Config Class Initialized
INFO - 2021-04-27 07:32:18 --> Loader Class Initialized
INFO - 2021-04-27 07:32:18 --> Helper loaded: url_helper
INFO - 2021-04-27 07:32:18 --> Helper loaded: file_helper
INFO - 2021-04-27 07:32:18 --> Helper loaded: form_helper
INFO - 2021-04-27 07:32:18 --> Helper loaded: my_helper
INFO - 2021-04-27 07:32:18 --> Database Driver Class Initialized
DEBUG - 2021-04-27 07:32:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 07:32:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 07:32:18 --> Controller Class Initialized
DEBUG - 2021-04-27 07:32:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-27 07:32:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 07:32:18 --> Final output sent to browser
DEBUG - 2021-04-27 07:32:18 --> Total execution time: 0.0637
INFO - 2021-04-27 07:34:43 --> Config Class Initialized
INFO - 2021-04-27 07:34:43 --> Hooks Class Initialized
DEBUG - 2021-04-27 07:34:43 --> UTF-8 Support Enabled
INFO - 2021-04-27 07:34:43 --> Utf8 Class Initialized
INFO - 2021-04-27 07:34:43 --> URI Class Initialized
INFO - 2021-04-27 07:34:43 --> Router Class Initialized
INFO - 2021-04-27 07:34:43 --> Output Class Initialized
INFO - 2021-04-27 07:34:43 --> Security Class Initialized
DEBUG - 2021-04-27 07:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 07:34:44 --> Input Class Initialized
INFO - 2021-04-27 07:34:44 --> Language Class Initialized
INFO - 2021-04-27 07:34:44 --> Language Class Initialized
INFO - 2021-04-27 07:34:44 --> Config Class Initialized
INFO - 2021-04-27 07:34:44 --> Loader Class Initialized
INFO - 2021-04-27 07:34:44 --> Helper loaded: url_helper
INFO - 2021-04-27 07:34:44 --> Helper loaded: file_helper
INFO - 2021-04-27 07:34:44 --> Helper loaded: form_helper
INFO - 2021-04-27 07:34:44 --> Helper loaded: my_helper
INFO - 2021-04-27 07:34:44 --> Database Driver Class Initialized
DEBUG - 2021-04-27 07:34:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 07:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 07:34:44 --> Controller Class Initialized
DEBUG - 2021-04-27 07:34:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-27 07:34:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 07:34:44 --> Final output sent to browser
DEBUG - 2021-04-27 07:34:44 --> Total execution time: 0.0555
INFO - 2021-04-27 07:36:03 --> Config Class Initialized
INFO - 2021-04-27 07:36:03 --> Hooks Class Initialized
DEBUG - 2021-04-27 07:36:03 --> UTF-8 Support Enabled
INFO - 2021-04-27 07:36:03 --> Utf8 Class Initialized
INFO - 2021-04-27 07:36:03 --> URI Class Initialized
INFO - 2021-04-27 07:36:03 --> Router Class Initialized
INFO - 2021-04-27 07:36:03 --> Output Class Initialized
INFO - 2021-04-27 07:36:03 --> Security Class Initialized
DEBUG - 2021-04-27 07:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 07:36:03 --> Input Class Initialized
INFO - 2021-04-27 07:36:03 --> Language Class Initialized
INFO - 2021-04-27 07:36:03 --> Language Class Initialized
INFO - 2021-04-27 07:36:03 --> Config Class Initialized
INFO - 2021-04-27 07:36:03 --> Loader Class Initialized
INFO - 2021-04-27 07:36:03 --> Helper loaded: url_helper
INFO - 2021-04-27 07:36:03 --> Helper loaded: file_helper
INFO - 2021-04-27 07:36:03 --> Helper loaded: form_helper
INFO - 2021-04-27 07:36:03 --> Helper loaded: my_helper
INFO - 2021-04-27 07:36:03 --> Database Driver Class Initialized
DEBUG - 2021-04-27 07:36:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 07:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 07:36:03 --> Controller Class Initialized
DEBUG - 2021-04-27 07:36:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-04-27 07:36:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 07:36:03 --> Final output sent to browser
DEBUG - 2021-04-27 07:36:03 --> Total execution time: 0.0701
INFO - 2021-04-27 07:36:04 --> Config Class Initialized
INFO - 2021-04-27 07:36:04 --> Hooks Class Initialized
DEBUG - 2021-04-27 07:36:04 --> UTF-8 Support Enabled
INFO - 2021-04-27 07:36:04 --> Utf8 Class Initialized
INFO - 2021-04-27 07:36:04 --> URI Class Initialized
INFO - 2021-04-27 07:36:04 --> Router Class Initialized
INFO - 2021-04-27 07:36:04 --> Output Class Initialized
INFO - 2021-04-27 07:36:04 --> Security Class Initialized
DEBUG - 2021-04-27 07:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 07:36:04 --> Input Class Initialized
INFO - 2021-04-27 07:36:04 --> Language Class Initialized
INFO - 2021-04-27 07:36:04 --> Language Class Initialized
INFO - 2021-04-27 07:36:04 --> Config Class Initialized
INFO - 2021-04-27 07:36:04 --> Loader Class Initialized
INFO - 2021-04-27 07:36:04 --> Helper loaded: url_helper
INFO - 2021-04-27 07:36:04 --> Helper loaded: file_helper
INFO - 2021-04-27 07:36:04 --> Helper loaded: form_helper
INFO - 2021-04-27 07:36:04 --> Helper loaded: my_helper
INFO - 2021-04-27 07:36:04 --> Database Driver Class Initialized
DEBUG - 2021-04-27 07:36:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 07:36:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 07:36:04 --> Controller Class Initialized
INFO - 2021-04-27 07:36:16 --> Config Class Initialized
INFO - 2021-04-27 07:36:16 --> Hooks Class Initialized
DEBUG - 2021-04-27 07:36:16 --> UTF-8 Support Enabled
INFO - 2021-04-27 07:36:16 --> Utf8 Class Initialized
INFO - 2021-04-27 07:36:16 --> URI Class Initialized
INFO - 2021-04-27 07:36:16 --> Router Class Initialized
INFO - 2021-04-27 07:36:16 --> Output Class Initialized
INFO - 2021-04-27 07:36:16 --> Security Class Initialized
DEBUG - 2021-04-27 07:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 07:36:16 --> Input Class Initialized
INFO - 2021-04-27 07:36:16 --> Language Class Initialized
INFO - 2021-04-27 07:36:16 --> Language Class Initialized
INFO - 2021-04-27 07:36:16 --> Config Class Initialized
INFO - 2021-04-27 07:36:16 --> Loader Class Initialized
INFO - 2021-04-27 07:36:16 --> Helper loaded: url_helper
INFO - 2021-04-27 07:36:16 --> Helper loaded: file_helper
INFO - 2021-04-27 07:36:16 --> Helper loaded: form_helper
INFO - 2021-04-27 07:36:16 --> Helper loaded: my_helper
INFO - 2021-04-27 07:36:16 --> Database Driver Class Initialized
DEBUG - 2021-04-27 07:36:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 07:36:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 07:36:16 --> Controller Class Initialized
DEBUG - 2021-04-27 07:36:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-04-27 07:36:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 07:36:16 --> Final output sent to browser
DEBUG - 2021-04-27 07:36:16 --> Total execution time: 0.0661
INFO - 2021-04-27 07:36:16 --> Config Class Initialized
INFO - 2021-04-27 07:36:16 --> Hooks Class Initialized
DEBUG - 2021-04-27 07:36:16 --> UTF-8 Support Enabled
INFO - 2021-04-27 07:36:16 --> Utf8 Class Initialized
INFO - 2021-04-27 07:36:16 --> URI Class Initialized
INFO - 2021-04-27 07:36:16 --> Router Class Initialized
INFO - 2021-04-27 07:36:16 --> Output Class Initialized
INFO - 2021-04-27 07:36:16 --> Security Class Initialized
DEBUG - 2021-04-27 07:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 07:36:16 --> Input Class Initialized
INFO - 2021-04-27 07:36:16 --> Language Class Initialized
INFO - 2021-04-27 07:36:16 --> Language Class Initialized
INFO - 2021-04-27 07:36:16 --> Config Class Initialized
INFO - 2021-04-27 07:36:16 --> Loader Class Initialized
INFO - 2021-04-27 07:36:16 --> Helper loaded: url_helper
INFO - 2021-04-27 07:36:16 --> Helper loaded: file_helper
INFO - 2021-04-27 07:36:16 --> Helper loaded: form_helper
INFO - 2021-04-27 07:36:16 --> Helper loaded: my_helper
INFO - 2021-04-27 07:36:16 --> Database Driver Class Initialized
DEBUG - 2021-04-27 07:36:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 07:36:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 07:36:16 --> Controller Class Initialized
INFO - 2021-04-27 07:36:17 --> Config Class Initialized
INFO - 2021-04-27 07:36:17 --> Hooks Class Initialized
DEBUG - 2021-04-27 07:36:17 --> UTF-8 Support Enabled
INFO - 2021-04-27 07:36:17 --> Utf8 Class Initialized
INFO - 2021-04-27 07:36:17 --> URI Class Initialized
INFO - 2021-04-27 07:36:17 --> Router Class Initialized
INFO - 2021-04-27 07:36:17 --> Output Class Initialized
INFO - 2021-04-27 07:36:17 --> Security Class Initialized
DEBUG - 2021-04-27 07:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 07:36:17 --> Input Class Initialized
INFO - 2021-04-27 07:36:17 --> Language Class Initialized
INFO - 2021-04-27 07:36:17 --> Language Class Initialized
INFO - 2021-04-27 07:36:17 --> Config Class Initialized
INFO - 2021-04-27 07:36:17 --> Loader Class Initialized
INFO - 2021-04-27 07:36:17 --> Helper loaded: url_helper
INFO - 2021-04-27 07:36:17 --> Helper loaded: file_helper
INFO - 2021-04-27 07:36:17 --> Helper loaded: form_helper
INFO - 2021-04-27 07:36:17 --> Helper loaded: my_helper
INFO - 2021-04-27 07:36:17 --> Database Driver Class Initialized
DEBUG - 2021-04-27 07:36:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 07:36:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 07:36:17 --> Controller Class Initialized
DEBUG - 2021-04-27 07:36:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2021-04-27 07:36:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 07:36:17 --> Final output sent to browser
DEBUG - 2021-04-27 07:36:17 --> Total execution time: 0.0623
INFO - 2021-04-27 07:36:17 --> Config Class Initialized
INFO - 2021-04-27 07:36:17 --> Hooks Class Initialized
DEBUG - 2021-04-27 07:36:17 --> UTF-8 Support Enabled
INFO - 2021-04-27 07:36:17 --> Utf8 Class Initialized
INFO - 2021-04-27 07:36:17 --> URI Class Initialized
INFO - 2021-04-27 07:36:17 --> Router Class Initialized
INFO - 2021-04-27 07:36:17 --> Output Class Initialized
INFO - 2021-04-27 07:36:17 --> Security Class Initialized
DEBUG - 2021-04-27 07:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 07:36:17 --> Input Class Initialized
INFO - 2021-04-27 07:36:17 --> Language Class Initialized
INFO - 2021-04-27 07:36:17 --> Language Class Initialized
INFO - 2021-04-27 07:36:17 --> Config Class Initialized
INFO - 2021-04-27 07:36:17 --> Loader Class Initialized
INFO - 2021-04-27 07:36:17 --> Helper loaded: url_helper
INFO - 2021-04-27 07:36:17 --> Helper loaded: file_helper
INFO - 2021-04-27 07:36:17 --> Helper loaded: form_helper
INFO - 2021-04-27 07:36:17 --> Helper loaded: my_helper
INFO - 2021-04-27 07:36:17 --> Database Driver Class Initialized
DEBUG - 2021-04-27 07:36:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 07:36:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 07:36:17 --> Controller Class Initialized
INFO - 2021-04-27 07:36:19 --> Config Class Initialized
INFO - 2021-04-27 07:36:19 --> Hooks Class Initialized
DEBUG - 2021-04-27 07:36:19 --> UTF-8 Support Enabled
INFO - 2021-04-27 07:36:19 --> Utf8 Class Initialized
INFO - 2021-04-27 07:36:19 --> URI Class Initialized
INFO - 2021-04-27 07:36:19 --> Router Class Initialized
INFO - 2021-04-27 07:36:19 --> Output Class Initialized
INFO - 2021-04-27 07:36:19 --> Security Class Initialized
DEBUG - 2021-04-27 07:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 07:36:19 --> Input Class Initialized
INFO - 2021-04-27 07:36:19 --> Language Class Initialized
INFO - 2021-04-27 07:36:19 --> Language Class Initialized
INFO - 2021-04-27 07:36:19 --> Config Class Initialized
INFO - 2021-04-27 07:36:19 --> Loader Class Initialized
INFO - 2021-04-27 07:36:19 --> Helper loaded: url_helper
INFO - 2021-04-27 07:36:19 --> Helper loaded: file_helper
INFO - 2021-04-27 07:36:19 --> Helper loaded: form_helper
INFO - 2021-04-27 07:36:19 --> Helper loaded: my_helper
INFO - 2021-04-27 07:36:19 --> Database Driver Class Initialized
DEBUG - 2021-04-27 07:36:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 07:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 07:36:19 --> Controller Class Initialized
INFO - 2021-04-27 07:36:19 --> Final output sent to browser
DEBUG - 2021-04-27 07:36:19 --> Total execution time: 0.0764
INFO - 2021-04-27 07:36:26 --> Config Class Initialized
INFO - 2021-04-27 07:36:26 --> Hooks Class Initialized
DEBUG - 2021-04-27 07:36:26 --> UTF-8 Support Enabled
INFO - 2021-04-27 07:36:26 --> Utf8 Class Initialized
INFO - 2021-04-27 07:36:26 --> URI Class Initialized
INFO - 2021-04-27 07:36:26 --> Router Class Initialized
INFO - 2021-04-27 07:36:26 --> Output Class Initialized
INFO - 2021-04-27 07:36:26 --> Security Class Initialized
DEBUG - 2021-04-27 07:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 07:36:26 --> Input Class Initialized
INFO - 2021-04-27 07:36:26 --> Language Class Initialized
INFO - 2021-04-27 07:36:26 --> Language Class Initialized
INFO - 2021-04-27 07:36:26 --> Config Class Initialized
INFO - 2021-04-27 07:36:26 --> Loader Class Initialized
INFO - 2021-04-27 07:36:26 --> Helper loaded: url_helper
INFO - 2021-04-27 07:36:26 --> Helper loaded: file_helper
INFO - 2021-04-27 07:36:26 --> Helper loaded: form_helper
INFO - 2021-04-27 07:36:26 --> Helper loaded: my_helper
INFO - 2021-04-27 07:36:26 --> Database Driver Class Initialized
DEBUG - 2021-04-27 07:36:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 07:36:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 07:36:26 --> Controller Class Initialized
INFO - 2021-04-27 07:36:26 --> Final output sent to browser
DEBUG - 2021-04-27 07:36:26 --> Total execution time: 0.0819
INFO - 2021-04-27 07:36:26 --> Config Class Initialized
INFO - 2021-04-27 07:36:26 --> Hooks Class Initialized
DEBUG - 2021-04-27 07:36:26 --> UTF-8 Support Enabled
INFO - 2021-04-27 07:36:26 --> Utf8 Class Initialized
INFO - 2021-04-27 07:36:26 --> URI Class Initialized
INFO - 2021-04-27 07:36:26 --> Router Class Initialized
INFO - 2021-04-27 07:36:26 --> Output Class Initialized
INFO - 2021-04-27 07:36:26 --> Security Class Initialized
DEBUG - 2021-04-27 07:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 07:36:26 --> Input Class Initialized
INFO - 2021-04-27 07:36:26 --> Language Class Initialized
INFO - 2021-04-27 07:36:26 --> Language Class Initialized
INFO - 2021-04-27 07:36:26 --> Config Class Initialized
INFO - 2021-04-27 07:36:26 --> Loader Class Initialized
INFO - 2021-04-27 07:36:26 --> Helper loaded: url_helper
INFO - 2021-04-27 07:36:26 --> Helper loaded: file_helper
INFO - 2021-04-27 07:36:26 --> Helper loaded: form_helper
INFO - 2021-04-27 07:36:26 --> Helper loaded: my_helper
INFO - 2021-04-27 07:36:26 --> Database Driver Class Initialized
DEBUG - 2021-04-27 07:36:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 07:36:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 07:36:26 --> Controller Class Initialized
INFO - 2021-04-27 07:36:30 --> Config Class Initialized
INFO - 2021-04-27 07:36:30 --> Hooks Class Initialized
DEBUG - 2021-04-27 07:36:30 --> UTF-8 Support Enabled
INFO - 2021-04-27 07:36:30 --> Utf8 Class Initialized
INFO - 2021-04-27 07:36:30 --> URI Class Initialized
INFO - 2021-04-27 07:36:30 --> Router Class Initialized
INFO - 2021-04-27 07:36:30 --> Output Class Initialized
INFO - 2021-04-27 07:36:30 --> Security Class Initialized
DEBUG - 2021-04-27 07:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 07:36:30 --> Input Class Initialized
INFO - 2021-04-27 07:36:30 --> Language Class Initialized
INFO - 2021-04-27 07:36:30 --> Language Class Initialized
INFO - 2021-04-27 07:36:30 --> Config Class Initialized
INFO - 2021-04-27 07:36:30 --> Loader Class Initialized
INFO - 2021-04-27 07:36:30 --> Helper loaded: url_helper
INFO - 2021-04-27 07:36:30 --> Helper loaded: file_helper
INFO - 2021-04-27 07:36:30 --> Helper loaded: form_helper
INFO - 2021-04-27 07:36:30 --> Helper loaded: my_helper
INFO - 2021-04-27 07:36:30 --> Database Driver Class Initialized
DEBUG - 2021-04-27 07:36:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 07:36:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 07:36:30 --> Controller Class Initialized
DEBUG - 2021-04-27 07:36:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-27 07:36:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 07:36:30 --> Final output sent to browser
DEBUG - 2021-04-27 07:36:30 --> Total execution time: 0.0616
INFO - 2021-04-27 07:36:33 --> Config Class Initialized
INFO - 2021-04-27 07:36:33 --> Hooks Class Initialized
DEBUG - 2021-04-27 07:36:33 --> UTF-8 Support Enabled
INFO - 2021-04-27 07:36:33 --> Utf8 Class Initialized
INFO - 2021-04-27 07:36:33 --> URI Class Initialized
INFO - 2021-04-27 07:36:33 --> Router Class Initialized
INFO - 2021-04-27 07:36:33 --> Output Class Initialized
INFO - 2021-04-27 07:36:33 --> Security Class Initialized
DEBUG - 2021-04-27 07:36:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 07:36:33 --> Input Class Initialized
INFO - 2021-04-27 07:36:33 --> Language Class Initialized
INFO - 2021-04-27 07:36:33 --> Language Class Initialized
INFO - 2021-04-27 07:36:33 --> Config Class Initialized
INFO - 2021-04-27 07:36:33 --> Loader Class Initialized
INFO - 2021-04-27 07:36:33 --> Helper loaded: url_helper
INFO - 2021-04-27 07:36:33 --> Helper loaded: file_helper
INFO - 2021-04-27 07:36:33 --> Helper loaded: form_helper
INFO - 2021-04-27 07:36:33 --> Helper loaded: my_helper
INFO - 2021-04-27 07:36:33 --> Database Driver Class Initialized
DEBUG - 2021-04-27 07:36:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 07:36:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 07:36:33 --> Controller Class Initialized
DEBUG - 2021-04-27 07:36:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-04-27 07:36:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 07:36:33 --> Final output sent to browser
DEBUG - 2021-04-27 07:36:33 --> Total execution time: 0.0723
INFO - 2021-04-27 07:36:37 --> Config Class Initialized
INFO - 2021-04-27 07:36:37 --> Hooks Class Initialized
DEBUG - 2021-04-27 07:36:37 --> UTF-8 Support Enabled
INFO - 2021-04-27 07:36:37 --> Utf8 Class Initialized
INFO - 2021-04-27 07:36:37 --> URI Class Initialized
INFO - 2021-04-27 07:36:37 --> Router Class Initialized
INFO - 2021-04-27 07:36:37 --> Output Class Initialized
INFO - 2021-04-27 07:36:37 --> Security Class Initialized
DEBUG - 2021-04-27 07:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 07:36:37 --> Input Class Initialized
INFO - 2021-04-27 07:36:37 --> Language Class Initialized
INFO - 2021-04-27 07:36:37 --> Language Class Initialized
INFO - 2021-04-27 07:36:37 --> Config Class Initialized
INFO - 2021-04-27 07:36:37 --> Loader Class Initialized
INFO - 2021-04-27 07:36:37 --> Helper loaded: url_helper
INFO - 2021-04-27 07:36:37 --> Helper loaded: file_helper
INFO - 2021-04-27 07:36:37 --> Helper loaded: form_helper
INFO - 2021-04-27 07:36:37 --> Helper loaded: my_helper
INFO - 2021-04-27 07:36:37 --> Database Driver Class Initialized
DEBUG - 2021-04-27 07:36:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 07:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 07:36:37 --> Controller Class Initialized
INFO - 2021-04-27 07:36:37 --> Config Class Initialized
INFO - 2021-04-27 07:36:37 --> Hooks Class Initialized
DEBUG - 2021-04-27 07:36:37 --> UTF-8 Support Enabled
INFO - 2021-04-27 07:36:37 --> Utf8 Class Initialized
INFO - 2021-04-27 07:36:37 --> URI Class Initialized
INFO - 2021-04-27 07:36:37 --> Router Class Initialized
INFO - 2021-04-27 07:36:37 --> Output Class Initialized
INFO - 2021-04-27 07:36:37 --> Security Class Initialized
DEBUG - 2021-04-27 07:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 07:36:37 --> Input Class Initialized
INFO - 2021-04-27 07:36:37 --> Language Class Initialized
INFO - 2021-04-27 07:36:37 --> Language Class Initialized
INFO - 2021-04-27 07:36:37 --> Config Class Initialized
INFO - 2021-04-27 07:36:37 --> Loader Class Initialized
INFO - 2021-04-27 07:36:37 --> Helper loaded: url_helper
INFO - 2021-04-27 07:36:37 --> Helper loaded: file_helper
INFO - 2021-04-27 07:36:37 --> Helper loaded: form_helper
INFO - 2021-04-27 07:36:37 --> Helper loaded: my_helper
INFO - 2021-04-27 07:36:37 --> Database Driver Class Initialized
DEBUG - 2021-04-27 07:36:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 07:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 07:36:37 --> Controller Class Initialized
DEBUG - 2021-04-27 07:36:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-27 07:36:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 07:36:37 --> Final output sent to browser
DEBUG - 2021-04-27 07:36:37 --> Total execution time: 0.0780
INFO - 2021-04-27 08:05:17 --> Config Class Initialized
INFO - 2021-04-27 08:05:17 --> Hooks Class Initialized
DEBUG - 2021-04-27 08:05:17 --> UTF-8 Support Enabled
INFO - 2021-04-27 08:05:17 --> Utf8 Class Initialized
INFO - 2021-04-27 08:05:17 --> URI Class Initialized
INFO - 2021-04-27 08:05:17 --> Router Class Initialized
INFO - 2021-04-27 08:05:17 --> Output Class Initialized
INFO - 2021-04-27 08:05:17 --> Security Class Initialized
DEBUG - 2021-04-27 08:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 08:05:17 --> Input Class Initialized
INFO - 2021-04-27 08:05:17 --> Language Class Initialized
INFO - 2021-04-27 08:05:17 --> Language Class Initialized
INFO - 2021-04-27 08:05:17 --> Config Class Initialized
INFO - 2021-04-27 08:05:17 --> Loader Class Initialized
INFO - 2021-04-27 08:05:17 --> Helper loaded: url_helper
INFO - 2021-04-27 08:05:17 --> Helper loaded: file_helper
INFO - 2021-04-27 08:05:17 --> Helper loaded: form_helper
INFO - 2021-04-27 08:05:17 --> Helper loaded: my_helper
INFO - 2021-04-27 08:05:17 --> Database Driver Class Initialized
DEBUG - 2021-04-27 08:05:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 08:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 08:05:17 --> Controller Class Initialized
DEBUG - 2021-04-27 08:05:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2021-04-27 08:05:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 08:05:17 --> Final output sent to browser
DEBUG - 2021-04-27 08:05:17 --> Total execution time: 0.0781
INFO - 2021-04-27 08:05:17 --> Config Class Initialized
INFO - 2021-04-27 08:05:17 --> Hooks Class Initialized
DEBUG - 2021-04-27 08:05:17 --> UTF-8 Support Enabled
INFO - 2021-04-27 08:05:17 --> Utf8 Class Initialized
INFO - 2021-04-27 08:05:17 --> URI Class Initialized
INFO - 2021-04-27 08:05:17 --> Router Class Initialized
INFO - 2021-04-27 08:05:17 --> Output Class Initialized
INFO - 2021-04-27 08:05:17 --> Security Class Initialized
DEBUG - 2021-04-27 08:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 08:05:17 --> Input Class Initialized
INFO - 2021-04-27 08:05:17 --> Language Class Initialized
INFO - 2021-04-27 08:05:17 --> Language Class Initialized
INFO - 2021-04-27 08:05:17 --> Config Class Initialized
INFO - 2021-04-27 08:05:17 --> Loader Class Initialized
INFO - 2021-04-27 08:05:17 --> Helper loaded: url_helper
INFO - 2021-04-27 08:05:17 --> Helper loaded: file_helper
INFO - 2021-04-27 08:05:17 --> Helper loaded: form_helper
INFO - 2021-04-27 08:05:17 --> Helper loaded: my_helper
INFO - 2021-04-27 08:05:17 --> Database Driver Class Initialized
DEBUG - 2021-04-27 08:05:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 08:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 08:05:17 --> Controller Class Initialized
INFO - 2021-04-27 08:05:56 --> Config Class Initialized
INFO - 2021-04-27 08:05:56 --> Hooks Class Initialized
DEBUG - 2021-04-27 08:05:56 --> UTF-8 Support Enabled
INFO - 2021-04-27 08:05:56 --> Utf8 Class Initialized
INFO - 2021-04-27 08:05:56 --> URI Class Initialized
INFO - 2021-04-27 08:05:56 --> Router Class Initialized
INFO - 2021-04-27 08:05:56 --> Output Class Initialized
INFO - 2021-04-27 08:05:56 --> Security Class Initialized
DEBUG - 2021-04-27 08:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 08:05:56 --> Input Class Initialized
INFO - 2021-04-27 08:05:56 --> Language Class Initialized
INFO - 2021-04-27 08:05:56 --> Language Class Initialized
INFO - 2021-04-27 08:05:56 --> Config Class Initialized
INFO - 2021-04-27 08:05:56 --> Loader Class Initialized
INFO - 2021-04-27 08:05:56 --> Helper loaded: url_helper
INFO - 2021-04-27 08:05:56 --> Helper loaded: file_helper
INFO - 2021-04-27 08:05:56 --> Helper loaded: form_helper
INFO - 2021-04-27 08:05:56 --> Helper loaded: my_helper
INFO - 2021-04-27 08:05:56 --> Database Driver Class Initialized
DEBUG - 2021-04-27 08:05:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 08:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 08:05:56 --> Controller Class Initialized
INFO - 2021-04-27 08:05:57 --> Final output sent to browser
DEBUG - 2021-04-27 08:05:57 --> Total execution time: 0.0986
INFO - 2021-04-27 08:05:57 --> Config Class Initialized
INFO - 2021-04-27 08:05:57 --> Hooks Class Initialized
DEBUG - 2021-04-27 08:05:57 --> UTF-8 Support Enabled
INFO - 2021-04-27 08:05:57 --> Utf8 Class Initialized
INFO - 2021-04-27 08:05:57 --> URI Class Initialized
INFO - 2021-04-27 08:05:57 --> Router Class Initialized
INFO - 2021-04-27 08:05:57 --> Output Class Initialized
INFO - 2021-04-27 08:05:57 --> Security Class Initialized
DEBUG - 2021-04-27 08:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 08:05:57 --> Input Class Initialized
INFO - 2021-04-27 08:05:57 --> Language Class Initialized
INFO - 2021-04-27 08:05:57 --> Language Class Initialized
INFO - 2021-04-27 08:05:57 --> Config Class Initialized
INFO - 2021-04-27 08:05:57 --> Loader Class Initialized
INFO - 2021-04-27 08:05:57 --> Helper loaded: url_helper
INFO - 2021-04-27 08:05:57 --> Helper loaded: file_helper
INFO - 2021-04-27 08:05:57 --> Helper loaded: form_helper
INFO - 2021-04-27 08:05:57 --> Helper loaded: my_helper
INFO - 2021-04-27 08:05:57 --> Database Driver Class Initialized
DEBUG - 2021-04-27 08:05:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 08:05:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 08:05:57 --> Controller Class Initialized
INFO - 2021-04-27 08:06:09 --> Config Class Initialized
INFO - 2021-04-27 08:06:09 --> Hooks Class Initialized
DEBUG - 2021-04-27 08:06:09 --> UTF-8 Support Enabled
INFO - 2021-04-27 08:06:09 --> Utf8 Class Initialized
INFO - 2021-04-27 08:06:09 --> URI Class Initialized
INFO - 2021-04-27 08:06:09 --> Router Class Initialized
INFO - 2021-04-27 08:06:09 --> Output Class Initialized
INFO - 2021-04-27 08:06:09 --> Security Class Initialized
DEBUG - 2021-04-27 08:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 08:06:09 --> Input Class Initialized
INFO - 2021-04-27 08:06:09 --> Language Class Initialized
INFO - 2021-04-27 08:06:09 --> Language Class Initialized
INFO - 2021-04-27 08:06:09 --> Config Class Initialized
INFO - 2021-04-27 08:06:09 --> Loader Class Initialized
INFO - 2021-04-27 08:06:09 --> Helper loaded: url_helper
INFO - 2021-04-27 08:06:09 --> Helper loaded: file_helper
INFO - 2021-04-27 08:06:09 --> Helper loaded: form_helper
INFO - 2021-04-27 08:06:09 --> Helper loaded: my_helper
INFO - 2021-04-27 08:06:09 --> Database Driver Class Initialized
DEBUG - 2021-04-27 08:06:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 08:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 08:06:09 --> Controller Class Initialized
DEBUG - 2021-04-27 08:06:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-27 08:06:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 08:06:09 --> Final output sent to browser
DEBUG - 2021-04-27 08:06:09 --> Total execution time: 0.0861
INFO - 2021-04-27 08:06:11 --> Config Class Initialized
INFO - 2021-04-27 08:06:11 --> Hooks Class Initialized
DEBUG - 2021-04-27 08:06:11 --> UTF-8 Support Enabled
INFO - 2021-04-27 08:06:11 --> Utf8 Class Initialized
INFO - 2021-04-27 08:06:11 --> URI Class Initialized
INFO - 2021-04-27 08:06:11 --> Router Class Initialized
INFO - 2021-04-27 08:06:11 --> Output Class Initialized
INFO - 2021-04-27 08:06:11 --> Security Class Initialized
DEBUG - 2021-04-27 08:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 08:06:11 --> Input Class Initialized
INFO - 2021-04-27 08:06:11 --> Language Class Initialized
INFO - 2021-04-27 08:06:11 --> Language Class Initialized
INFO - 2021-04-27 08:06:11 --> Config Class Initialized
INFO - 2021-04-27 08:06:11 --> Loader Class Initialized
INFO - 2021-04-27 08:06:11 --> Helper loaded: url_helper
INFO - 2021-04-27 08:06:11 --> Helper loaded: file_helper
INFO - 2021-04-27 08:06:11 --> Helper loaded: form_helper
INFO - 2021-04-27 08:06:11 --> Helper loaded: my_helper
INFO - 2021-04-27 08:06:11 --> Database Driver Class Initialized
DEBUG - 2021-04-27 08:06:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 08:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 08:06:11 --> Controller Class Initialized
DEBUG - 2021-04-27 08:06:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2021-04-27 08:06:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 08:06:11 --> Final output sent to browser
DEBUG - 2021-04-27 08:06:11 --> Total execution time: 0.1165
INFO - 2021-04-27 08:06:11 --> Config Class Initialized
INFO - 2021-04-27 08:06:11 --> Hooks Class Initialized
DEBUG - 2021-04-27 08:06:11 --> UTF-8 Support Enabled
INFO - 2021-04-27 08:06:11 --> Utf8 Class Initialized
INFO - 2021-04-27 08:06:11 --> URI Class Initialized
INFO - 2021-04-27 08:06:11 --> Router Class Initialized
INFO - 2021-04-27 08:06:11 --> Output Class Initialized
INFO - 2021-04-27 08:06:11 --> Security Class Initialized
DEBUG - 2021-04-27 08:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 08:06:11 --> Input Class Initialized
INFO - 2021-04-27 08:06:11 --> Language Class Initialized
INFO - 2021-04-27 08:06:11 --> Language Class Initialized
INFO - 2021-04-27 08:06:11 --> Config Class Initialized
INFO - 2021-04-27 08:06:11 --> Loader Class Initialized
INFO - 2021-04-27 08:06:11 --> Helper loaded: url_helper
INFO - 2021-04-27 08:06:11 --> Helper loaded: file_helper
INFO - 2021-04-27 08:06:11 --> Helper loaded: form_helper
INFO - 2021-04-27 08:06:11 --> Helper loaded: my_helper
INFO - 2021-04-27 08:06:11 --> Database Driver Class Initialized
DEBUG - 2021-04-27 08:06:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 08:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 08:06:11 --> Controller Class Initialized
INFO - 2021-04-27 08:06:14 --> Config Class Initialized
INFO - 2021-04-27 08:06:14 --> Hooks Class Initialized
DEBUG - 2021-04-27 08:06:14 --> UTF-8 Support Enabled
INFO - 2021-04-27 08:06:14 --> Utf8 Class Initialized
INFO - 2021-04-27 08:06:14 --> URI Class Initialized
INFO - 2021-04-27 08:06:14 --> Router Class Initialized
INFO - 2021-04-27 08:06:14 --> Output Class Initialized
INFO - 2021-04-27 08:06:14 --> Security Class Initialized
DEBUG - 2021-04-27 08:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 08:06:14 --> Input Class Initialized
INFO - 2021-04-27 08:06:14 --> Language Class Initialized
INFO - 2021-04-27 08:06:14 --> Language Class Initialized
INFO - 2021-04-27 08:06:14 --> Config Class Initialized
INFO - 2021-04-27 08:06:14 --> Loader Class Initialized
INFO - 2021-04-27 08:06:14 --> Helper loaded: url_helper
INFO - 2021-04-27 08:06:14 --> Helper loaded: file_helper
INFO - 2021-04-27 08:06:14 --> Helper loaded: form_helper
INFO - 2021-04-27 08:06:14 --> Helper loaded: my_helper
INFO - 2021-04-27 08:06:14 --> Database Driver Class Initialized
DEBUG - 2021-04-27 08:06:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 08:06:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 08:06:14 --> Controller Class Initialized
INFO - 2021-04-27 08:06:14 --> Final output sent to browser
DEBUG - 2021-04-27 08:06:14 --> Total execution time: 0.1113
INFO - 2021-04-27 08:06:14 --> Config Class Initialized
INFO - 2021-04-27 08:06:14 --> Hooks Class Initialized
DEBUG - 2021-04-27 08:06:14 --> UTF-8 Support Enabled
INFO - 2021-04-27 08:06:14 --> Utf8 Class Initialized
INFO - 2021-04-27 08:06:14 --> URI Class Initialized
INFO - 2021-04-27 08:06:14 --> Router Class Initialized
INFO - 2021-04-27 08:06:14 --> Output Class Initialized
INFO - 2021-04-27 08:06:14 --> Security Class Initialized
DEBUG - 2021-04-27 08:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 08:06:14 --> Input Class Initialized
INFO - 2021-04-27 08:06:14 --> Language Class Initialized
INFO - 2021-04-27 08:06:14 --> Language Class Initialized
INFO - 2021-04-27 08:06:14 --> Config Class Initialized
INFO - 2021-04-27 08:06:14 --> Loader Class Initialized
INFO - 2021-04-27 08:06:14 --> Helper loaded: url_helper
INFO - 2021-04-27 08:06:14 --> Helper loaded: file_helper
INFO - 2021-04-27 08:06:14 --> Helper loaded: form_helper
INFO - 2021-04-27 08:06:14 --> Helper loaded: my_helper
INFO - 2021-04-27 08:06:14 --> Database Driver Class Initialized
DEBUG - 2021-04-27 08:06:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 08:06:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 08:06:14 --> Controller Class Initialized
INFO - 2021-04-27 08:06:16 --> Config Class Initialized
INFO - 2021-04-27 08:06:16 --> Hooks Class Initialized
DEBUG - 2021-04-27 08:06:16 --> UTF-8 Support Enabled
INFO - 2021-04-27 08:06:16 --> Utf8 Class Initialized
INFO - 2021-04-27 08:06:16 --> URI Class Initialized
INFO - 2021-04-27 08:06:16 --> Router Class Initialized
INFO - 2021-04-27 08:06:16 --> Output Class Initialized
INFO - 2021-04-27 08:06:16 --> Security Class Initialized
DEBUG - 2021-04-27 08:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 08:06:16 --> Input Class Initialized
INFO - 2021-04-27 08:06:16 --> Language Class Initialized
INFO - 2021-04-27 08:06:16 --> Language Class Initialized
INFO - 2021-04-27 08:06:16 --> Config Class Initialized
INFO - 2021-04-27 08:06:16 --> Loader Class Initialized
INFO - 2021-04-27 08:06:16 --> Helper loaded: url_helper
INFO - 2021-04-27 08:06:16 --> Helper loaded: file_helper
INFO - 2021-04-27 08:06:16 --> Helper loaded: form_helper
INFO - 2021-04-27 08:06:16 --> Helper loaded: my_helper
INFO - 2021-04-27 08:06:16 --> Database Driver Class Initialized
DEBUG - 2021-04-27 08:06:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 08:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 08:06:16 --> Controller Class Initialized
INFO - 2021-04-27 08:06:16 --> Final output sent to browser
DEBUG - 2021-04-27 08:06:16 --> Total execution time: 0.1290
INFO - 2021-04-27 08:06:16 --> Config Class Initialized
INFO - 2021-04-27 08:06:16 --> Hooks Class Initialized
DEBUG - 2021-04-27 08:06:16 --> UTF-8 Support Enabled
INFO - 2021-04-27 08:06:16 --> Utf8 Class Initialized
INFO - 2021-04-27 08:06:16 --> URI Class Initialized
INFO - 2021-04-27 08:06:16 --> Router Class Initialized
INFO - 2021-04-27 08:06:16 --> Output Class Initialized
INFO - 2021-04-27 08:06:16 --> Security Class Initialized
DEBUG - 2021-04-27 08:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 08:06:16 --> Input Class Initialized
INFO - 2021-04-27 08:06:16 --> Language Class Initialized
INFO - 2021-04-27 08:06:16 --> Language Class Initialized
INFO - 2021-04-27 08:06:16 --> Config Class Initialized
INFO - 2021-04-27 08:06:16 --> Loader Class Initialized
INFO - 2021-04-27 08:06:16 --> Helper loaded: url_helper
INFO - 2021-04-27 08:06:16 --> Helper loaded: file_helper
INFO - 2021-04-27 08:06:16 --> Helper loaded: form_helper
INFO - 2021-04-27 08:06:16 --> Helper loaded: my_helper
INFO - 2021-04-27 08:06:16 --> Database Driver Class Initialized
DEBUG - 2021-04-27 08:06:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 08:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 08:06:16 --> Controller Class Initialized
INFO - 2021-04-27 08:06:20 --> Config Class Initialized
INFO - 2021-04-27 08:06:20 --> Hooks Class Initialized
DEBUG - 2021-04-27 08:06:20 --> UTF-8 Support Enabled
INFO - 2021-04-27 08:06:20 --> Utf8 Class Initialized
INFO - 2021-04-27 08:06:20 --> URI Class Initialized
INFO - 2021-04-27 08:06:20 --> Router Class Initialized
INFO - 2021-04-27 08:06:20 --> Output Class Initialized
INFO - 2021-04-27 08:06:20 --> Security Class Initialized
DEBUG - 2021-04-27 08:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 08:06:20 --> Input Class Initialized
INFO - 2021-04-27 08:06:20 --> Language Class Initialized
INFO - 2021-04-27 08:06:20 --> Language Class Initialized
INFO - 2021-04-27 08:06:20 --> Config Class Initialized
INFO - 2021-04-27 08:06:20 --> Loader Class Initialized
INFO - 2021-04-27 08:06:20 --> Helper loaded: url_helper
INFO - 2021-04-27 08:06:20 --> Helper loaded: file_helper
INFO - 2021-04-27 08:06:20 --> Helper loaded: form_helper
INFO - 2021-04-27 08:06:20 --> Helper loaded: my_helper
INFO - 2021-04-27 08:06:20 --> Database Driver Class Initialized
DEBUG - 2021-04-27 08:06:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 08:06:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 08:06:20 --> Controller Class Initialized
INFO - 2021-04-27 08:06:20 --> Final output sent to browser
DEBUG - 2021-04-27 08:06:20 --> Total execution time: 0.1046
INFO - 2021-04-27 08:06:20 --> Config Class Initialized
INFO - 2021-04-27 08:06:20 --> Hooks Class Initialized
DEBUG - 2021-04-27 08:06:20 --> UTF-8 Support Enabled
INFO - 2021-04-27 08:06:20 --> Utf8 Class Initialized
INFO - 2021-04-27 08:06:20 --> URI Class Initialized
INFO - 2021-04-27 08:06:20 --> Router Class Initialized
INFO - 2021-04-27 08:06:20 --> Output Class Initialized
INFO - 2021-04-27 08:06:20 --> Security Class Initialized
DEBUG - 2021-04-27 08:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 08:06:20 --> Input Class Initialized
INFO - 2021-04-27 08:06:20 --> Language Class Initialized
INFO - 2021-04-27 08:06:20 --> Language Class Initialized
INFO - 2021-04-27 08:06:20 --> Config Class Initialized
INFO - 2021-04-27 08:06:20 --> Loader Class Initialized
INFO - 2021-04-27 08:06:20 --> Helper loaded: url_helper
INFO - 2021-04-27 08:06:20 --> Helper loaded: file_helper
INFO - 2021-04-27 08:06:20 --> Helper loaded: form_helper
INFO - 2021-04-27 08:06:20 --> Helper loaded: my_helper
INFO - 2021-04-27 08:06:20 --> Database Driver Class Initialized
DEBUG - 2021-04-27 08:06:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 08:06:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 08:06:20 --> Controller Class Initialized
INFO - 2021-04-27 08:06:22 --> Config Class Initialized
INFO - 2021-04-27 08:06:22 --> Hooks Class Initialized
DEBUG - 2021-04-27 08:06:22 --> UTF-8 Support Enabled
INFO - 2021-04-27 08:06:22 --> Utf8 Class Initialized
INFO - 2021-04-27 08:06:22 --> URI Class Initialized
INFO - 2021-04-27 08:06:22 --> Router Class Initialized
INFO - 2021-04-27 08:06:22 --> Output Class Initialized
INFO - 2021-04-27 08:06:22 --> Security Class Initialized
DEBUG - 2021-04-27 08:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 08:06:22 --> Input Class Initialized
INFO - 2021-04-27 08:06:22 --> Language Class Initialized
INFO - 2021-04-27 08:06:22 --> Language Class Initialized
INFO - 2021-04-27 08:06:22 --> Config Class Initialized
INFO - 2021-04-27 08:06:22 --> Loader Class Initialized
INFO - 2021-04-27 08:06:22 --> Helper loaded: url_helper
INFO - 2021-04-27 08:06:22 --> Helper loaded: file_helper
INFO - 2021-04-27 08:06:22 --> Helper loaded: form_helper
INFO - 2021-04-27 08:06:22 --> Helper loaded: my_helper
INFO - 2021-04-27 08:06:22 --> Database Driver Class Initialized
DEBUG - 2021-04-27 08:06:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 08:06:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 08:06:22 --> Controller Class Initialized
INFO - 2021-04-27 08:06:22 --> Final output sent to browser
DEBUG - 2021-04-27 08:06:22 --> Total execution time: 0.0882
INFO - 2021-04-27 08:06:22 --> Config Class Initialized
INFO - 2021-04-27 08:06:22 --> Hooks Class Initialized
DEBUG - 2021-04-27 08:06:22 --> UTF-8 Support Enabled
INFO - 2021-04-27 08:06:22 --> Utf8 Class Initialized
INFO - 2021-04-27 08:06:22 --> URI Class Initialized
INFO - 2021-04-27 08:06:22 --> Router Class Initialized
INFO - 2021-04-27 08:06:22 --> Output Class Initialized
INFO - 2021-04-27 08:06:22 --> Security Class Initialized
DEBUG - 2021-04-27 08:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 08:06:22 --> Input Class Initialized
INFO - 2021-04-27 08:06:22 --> Language Class Initialized
INFO - 2021-04-27 08:06:22 --> Language Class Initialized
INFO - 2021-04-27 08:06:22 --> Config Class Initialized
INFO - 2021-04-27 08:06:22 --> Loader Class Initialized
INFO - 2021-04-27 08:06:22 --> Helper loaded: url_helper
INFO - 2021-04-27 08:06:22 --> Helper loaded: file_helper
INFO - 2021-04-27 08:06:22 --> Helper loaded: form_helper
INFO - 2021-04-27 08:06:22 --> Helper loaded: my_helper
INFO - 2021-04-27 08:06:22 --> Database Driver Class Initialized
DEBUG - 2021-04-27 08:06:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 08:06:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 08:06:22 --> Controller Class Initialized
INFO - 2021-04-27 08:07:06 --> Config Class Initialized
INFO - 2021-04-27 08:07:06 --> Hooks Class Initialized
DEBUG - 2021-04-27 08:07:06 --> UTF-8 Support Enabled
INFO - 2021-04-27 08:07:06 --> Utf8 Class Initialized
INFO - 2021-04-27 08:07:06 --> URI Class Initialized
INFO - 2021-04-27 08:07:06 --> Router Class Initialized
INFO - 2021-04-27 08:07:06 --> Output Class Initialized
INFO - 2021-04-27 08:07:06 --> Security Class Initialized
DEBUG - 2021-04-27 08:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 08:07:06 --> Input Class Initialized
INFO - 2021-04-27 08:07:06 --> Language Class Initialized
INFO - 2021-04-27 08:07:06 --> Language Class Initialized
INFO - 2021-04-27 08:07:06 --> Config Class Initialized
INFO - 2021-04-27 08:07:06 --> Loader Class Initialized
INFO - 2021-04-27 08:07:06 --> Helper loaded: url_helper
INFO - 2021-04-27 08:07:06 --> Helper loaded: file_helper
INFO - 2021-04-27 08:07:06 --> Helper loaded: form_helper
INFO - 2021-04-27 08:07:06 --> Helper loaded: my_helper
INFO - 2021-04-27 08:07:06 --> Database Driver Class Initialized
DEBUG - 2021-04-27 08:07:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 08:07:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 08:07:06 --> Controller Class Initialized
DEBUG - 2021-04-27 08:07:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2021-04-27 08:07:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 08:07:06 --> Final output sent to browser
DEBUG - 2021-04-27 08:07:06 --> Total execution time: 0.0701
INFO - 2021-04-27 08:07:06 --> Config Class Initialized
INFO - 2021-04-27 08:07:06 --> Hooks Class Initialized
DEBUG - 2021-04-27 08:07:06 --> UTF-8 Support Enabled
INFO - 2021-04-27 08:07:06 --> Utf8 Class Initialized
INFO - 2021-04-27 08:07:06 --> URI Class Initialized
INFO - 2021-04-27 08:07:06 --> Router Class Initialized
INFO - 2021-04-27 08:07:06 --> Output Class Initialized
INFO - 2021-04-27 08:07:06 --> Security Class Initialized
DEBUG - 2021-04-27 08:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 08:07:06 --> Input Class Initialized
INFO - 2021-04-27 08:07:06 --> Language Class Initialized
INFO - 2021-04-27 08:07:06 --> Language Class Initialized
INFO - 2021-04-27 08:07:06 --> Config Class Initialized
INFO - 2021-04-27 08:07:06 --> Loader Class Initialized
INFO - 2021-04-27 08:07:06 --> Helper loaded: url_helper
INFO - 2021-04-27 08:07:06 --> Helper loaded: file_helper
INFO - 2021-04-27 08:07:06 --> Helper loaded: form_helper
INFO - 2021-04-27 08:07:06 --> Helper loaded: my_helper
INFO - 2021-04-27 08:07:06 --> Database Driver Class Initialized
DEBUG - 2021-04-27 08:07:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 08:07:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 08:07:06 --> Controller Class Initialized
INFO - 2021-04-27 08:07:37 --> Config Class Initialized
INFO - 2021-04-27 08:07:37 --> Hooks Class Initialized
DEBUG - 2021-04-27 08:07:37 --> UTF-8 Support Enabled
INFO - 2021-04-27 08:07:37 --> Utf8 Class Initialized
INFO - 2021-04-27 08:07:37 --> URI Class Initialized
INFO - 2021-04-27 08:07:37 --> Router Class Initialized
INFO - 2021-04-27 08:07:37 --> Output Class Initialized
INFO - 2021-04-27 08:07:37 --> Security Class Initialized
DEBUG - 2021-04-27 08:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 08:07:37 --> Input Class Initialized
INFO - 2021-04-27 08:07:37 --> Language Class Initialized
INFO - 2021-04-27 08:07:37 --> Language Class Initialized
INFO - 2021-04-27 08:07:37 --> Config Class Initialized
INFO - 2021-04-27 08:07:37 --> Loader Class Initialized
INFO - 2021-04-27 08:07:37 --> Helper loaded: url_helper
INFO - 2021-04-27 08:07:37 --> Helper loaded: file_helper
INFO - 2021-04-27 08:07:37 --> Helper loaded: form_helper
INFO - 2021-04-27 08:07:37 --> Helper loaded: my_helper
INFO - 2021-04-27 08:07:37 --> Database Driver Class Initialized
DEBUG - 2021-04-27 08:07:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 08:07:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 08:07:37 --> Controller Class Initialized
INFO - 2021-04-27 08:07:37 --> Final output sent to browser
DEBUG - 2021-04-27 08:07:37 --> Total execution time: 0.0906
INFO - 2021-04-27 08:07:47 --> Config Class Initialized
INFO - 2021-04-27 08:07:47 --> Hooks Class Initialized
DEBUG - 2021-04-27 08:07:47 --> UTF-8 Support Enabled
INFO - 2021-04-27 08:07:47 --> Utf8 Class Initialized
INFO - 2021-04-27 08:07:47 --> URI Class Initialized
INFO - 2021-04-27 08:07:47 --> Router Class Initialized
INFO - 2021-04-27 08:07:47 --> Output Class Initialized
INFO - 2021-04-27 08:07:47 --> Security Class Initialized
DEBUG - 2021-04-27 08:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 08:07:47 --> Input Class Initialized
INFO - 2021-04-27 08:07:47 --> Language Class Initialized
INFO - 2021-04-27 08:07:47 --> Language Class Initialized
INFO - 2021-04-27 08:07:47 --> Config Class Initialized
INFO - 2021-04-27 08:07:47 --> Loader Class Initialized
INFO - 2021-04-27 08:07:47 --> Helper loaded: url_helper
INFO - 2021-04-27 08:07:47 --> Helper loaded: file_helper
INFO - 2021-04-27 08:07:47 --> Helper loaded: form_helper
INFO - 2021-04-27 08:07:47 --> Helper loaded: my_helper
INFO - 2021-04-27 08:07:47 --> Database Driver Class Initialized
DEBUG - 2021-04-27 08:07:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 08:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 08:07:47 --> Controller Class Initialized
INFO - 2021-04-27 08:07:47 --> Final output sent to browser
DEBUG - 2021-04-27 08:07:47 --> Total execution time: 0.0770
INFO - 2021-04-27 08:07:47 --> Config Class Initialized
INFO - 2021-04-27 08:07:47 --> Hooks Class Initialized
DEBUG - 2021-04-27 08:07:48 --> UTF-8 Support Enabled
INFO - 2021-04-27 08:07:48 --> Utf8 Class Initialized
INFO - 2021-04-27 08:07:48 --> URI Class Initialized
INFO - 2021-04-27 08:07:48 --> Router Class Initialized
INFO - 2021-04-27 08:07:48 --> Output Class Initialized
INFO - 2021-04-27 08:07:48 --> Security Class Initialized
DEBUG - 2021-04-27 08:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 08:07:48 --> Input Class Initialized
INFO - 2021-04-27 08:07:48 --> Language Class Initialized
INFO - 2021-04-27 08:07:48 --> Language Class Initialized
INFO - 2021-04-27 08:07:48 --> Config Class Initialized
INFO - 2021-04-27 08:07:48 --> Loader Class Initialized
INFO - 2021-04-27 08:07:48 --> Helper loaded: url_helper
INFO - 2021-04-27 08:07:48 --> Helper loaded: file_helper
INFO - 2021-04-27 08:07:48 --> Helper loaded: form_helper
INFO - 2021-04-27 08:07:48 --> Helper loaded: my_helper
INFO - 2021-04-27 08:07:48 --> Database Driver Class Initialized
DEBUG - 2021-04-27 08:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 08:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 08:07:48 --> Controller Class Initialized
INFO - 2021-04-27 08:07:49 --> Config Class Initialized
INFO - 2021-04-27 08:07:49 --> Hooks Class Initialized
DEBUG - 2021-04-27 08:07:50 --> UTF-8 Support Enabled
INFO - 2021-04-27 08:07:50 --> Utf8 Class Initialized
INFO - 2021-04-27 08:07:50 --> URI Class Initialized
INFO - 2021-04-27 08:07:50 --> Router Class Initialized
INFO - 2021-04-27 08:07:50 --> Output Class Initialized
INFO - 2021-04-27 08:07:50 --> Security Class Initialized
DEBUG - 2021-04-27 08:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 08:07:50 --> Input Class Initialized
INFO - 2021-04-27 08:07:50 --> Language Class Initialized
INFO - 2021-04-27 08:07:50 --> Language Class Initialized
INFO - 2021-04-27 08:07:50 --> Config Class Initialized
INFO - 2021-04-27 08:07:50 --> Loader Class Initialized
INFO - 2021-04-27 08:07:50 --> Helper loaded: url_helper
INFO - 2021-04-27 08:07:50 --> Helper loaded: file_helper
INFO - 2021-04-27 08:07:50 --> Helper loaded: form_helper
INFO - 2021-04-27 08:07:50 --> Helper loaded: my_helper
INFO - 2021-04-27 08:07:50 --> Database Driver Class Initialized
DEBUG - 2021-04-27 08:07:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 08:07:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 08:07:50 --> Controller Class Initialized
DEBUG - 2021-04-27 08:07:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-27 08:07:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 08:07:50 --> Final output sent to browser
DEBUG - 2021-04-27 08:07:50 --> Total execution time: 0.1239
INFO - 2021-04-27 08:07:51 --> Config Class Initialized
INFO - 2021-04-27 08:07:51 --> Hooks Class Initialized
DEBUG - 2021-04-27 08:07:51 --> UTF-8 Support Enabled
INFO - 2021-04-27 08:07:51 --> Utf8 Class Initialized
INFO - 2021-04-27 08:07:51 --> URI Class Initialized
INFO - 2021-04-27 08:07:51 --> Router Class Initialized
INFO - 2021-04-27 08:07:51 --> Output Class Initialized
INFO - 2021-04-27 08:07:51 --> Security Class Initialized
DEBUG - 2021-04-27 08:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 08:07:51 --> Input Class Initialized
INFO - 2021-04-27 08:07:51 --> Language Class Initialized
INFO - 2021-04-27 08:07:51 --> Language Class Initialized
INFO - 2021-04-27 08:07:51 --> Config Class Initialized
INFO - 2021-04-27 08:07:51 --> Loader Class Initialized
INFO - 2021-04-27 08:07:51 --> Helper loaded: url_helper
INFO - 2021-04-27 08:07:51 --> Helper loaded: file_helper
INFO - 2021-04-27 08:07:51 --> Helper loaded: form_helper
INFO - 2021-04-27 08:07:51 --> Helper loaded: my_helper
INFO - 2021-04-27 08:07:51 --> Database Driver Class Initialized
DEBUG - 2021-04-27 08:07:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 08:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 08:07:51 --> Controller Class Initialized
DEBUG - 2021-04-27 08:07:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-04-27 08:07:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 08:07:51 --> Final output sent to browser
DEBUG - 2021-04-27 08:07:51 --> Total execution time: 0.1442
INFO - 2021-04-27 08:07:55 --> Config Class Initialized
INFO - 2021-04-27 08:07:55 --> Hooks Class Initialized
DEBUG - 2021-04-27 08:07:55 --> UTF-8 Support Enabled
INFO - 2021-04-27 08:07:55 --> Utf8 Class Initialized
INFO - 2021-04-27 08:07:55 --> URI Class Initialized
INFO - 2021-04-27 08:07:55 --> Router Class Initialized
INFO - 2021-04-27 08:07:55 --> Output Class Initialized
INFO - 2021-04-27 08:07:55 --> Security Class Initialized
DEBUG - 2021-04-27 08:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 08:07:55 --> Input Class Initialized
INFO - 2021-04-27 08:07:55 --> Language Class Initialized
INFO - 2021-04-27 08:07:55 --> Language Class Initialized
INFO - 2021-04-27 08:07:55 --> Config Class Initialized
INFO - 2021-04-27 08:07:55 --> Loader Class Initialized
INFO - 2021-04-27 08:07:55 --> Helper loaded: url_helper
INFO - 2021-04-27 08:07:55 --> Helper loaded: file_helper
INFO - 2021-04-27 08:07:55 --> Helper loaded: form_helper
INFO - 2021-04-27 08:07:55 --> Helper loaded: my_helper
INFO - 2021-04-27 08:07:55 --> Database Driver Class Initialized
DEBUG - 2021-04-27 08:07:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 08:07:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 08:07:55 --> Controller Class Initialized
INFO - 2021-04-27 08:07:55 --> Config Class Initialized
INFO - 2021-04-27 08:07:55 --> Hooks Class Initialized
DEBUG - 2021-04-27 08:07:55 --> UTF-8 Support Enabled
INFO - 2021-04-27 08:07:55 --> Utf8 Class Initialized
INFO - 2021-04-27 08:07:55 --> URI Class Initialized
INFO - 2021-04-27 08:07:55 --> Router Class Initialized
INFO - 2021-04-27 08:07:55 --> Output Class Initialized
INFO - 2021-04-27 08:07:55 --> Security Class Initialized
DEBUG - 2021-04-27 08:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 08:07:55 --> Input Class Initialized
INFO - 2021-04-27 08:07:55 --> Language Class Initialized
INFO - 2021-04-27 08:07:55 --> Language Class Initialized
INFO - 2021-04-27 08:07:55 --> Config Class Initialized
INFO - 2021-04-27 08:07:55 --> Loader Class Initialized
INFO - 2021-04-27 08:07:55 --> Helper loaded: url_helper
INFO - 2021-04-27 08:07:55 --> Helper loaded: file_helper
INFO - 2021-04-27 08:07:55 --> Helper loaded: form_helper
INFO - 2021-04-27 08:07:55 --> Helper loaded: my_helper
INFO - 2021-04-27 08:07:55 --> Database Driver Class Initialized
DEBUG - 2021-04-27 08:07:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 08:07:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 08:07:55 --> Controller Class Initialized
DEBUG - 2021-04-27 08:07:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-27 08:07:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 08:07:55 --> Final output sent to browser
DEBUG - 2021-04-27 08:07:55 --> Total execution time: 0.1185
INFO - 2021-04-27 08:08:44 --> Config Class Initialized
INFO - 2021-04-27 08:08:44 --> Hooks Class Initialized
DEBUG - 2021-04-27 08:08:44 --> UTF-8 Support Enabled
INFO - 2021-04-27 08:08:44 --> Utf8 Class Initialized
INFO - 2021-04-27 08:08:44 --> URI Class Initialized
INFO - 2021-04-27 08:08:44 --> Router Class Initialized
INFO - 2021-04-27 08:08:44 --> Output Class Initialized
INFO - 2021-04-27 08:08:44 --> Security Class Initialized
DEBUG - 2021-04-27 08:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 08:08:44 --> Input Class Initialized
INFO - 2021-04-27 08:08:44 --> Language Class Initialized
INFO - 2021-04-27 08:08:44 --> Language Class Initialized
INFO - 2021-04-27 08:08:44 --> Config Class Initialized
INFO - 2021-04-27 08:08:44 --> Loader Class Initialized
INFO - 2021-04-27 08:08:44 --> Helper loaded: url_helper
INFO - 2021-04-27 08:08:44 --> Helper loaded: file_helper
INFO - 2021-04-27 08:08:44 --> Helper loaded: form_helper
INFO - 2021-04-27 08:08:44 --> Helper loaded: my_helper
INFO - 2021-04-27 08:08:44 --> Database Driver Class Initialized
DEBUG - 2021-04-27 08:08:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 08:08:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 08:08:44 --> Controller Class Initialized
DEBUG - 2021-04-27 08:08:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2021-04-27 08:08:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 08:08:44 --> Final output sent to browser
DEBUG - 2021-04-27 08:08:44 --> Total execution time: 0.0972
INFO - 2021-04-27 08:08:45 --> Config Class Initialized
INFO - 2021-04-27 08:08:45 --> Hooks Class Initialized
DEBUG - 2021-04-27 08:08:45 --> UTF-8 Support Enabled
INFO - 2021-04-27 08:08:45 --> Utf8 Class Initialized
INFO - 2021-04-27 08:08:45 --> URI Class Initialized
INFO - 2021-04-27 08:08:45 --> Router Class Initialized
INFO - 2021-04-27 08:08:45 --> Output Class Initialized
INFO - 2021-04-27 08:08:45 --> Security Class Initialized
DEBUG - 2021-04-27 08:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 08:08:45 --> Input Class Initialized
INFO - 2021-04-27 08:08:45 --> Language Class Initialized
INFO - 2021-04-27 08:08:45 --> Language Class Initialized
INFO - 2021-04-27 08:08:45 --> Config Class Initialized
INFO - 2021-04-27 08:08:45 --> Loader Class Initialized
INFO - 2021-04-27 08:08:45 --> Helper loaded: url_helper
INFO - 2021-04-27 08:08:45 --> Helper loaded: file_helper
INFO - 2021-04-27 08:08:45 --> Helper loaded: form_helper
INFO - 2021-04-27 08:08:45 --> Helper loaded: my_helper
INFO - 2021-04-27 08:08:45 --> Database Driver Class Initialized
DEBUG - 2021-04-27 08:08:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 08:08:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 08:08:45 --> Controller Class Initialized
INFO - 2021-04-27 08:09:33 --> Config Class Initialized
INFO - 2021-04-27 08:09:33 --> Hooks Class Initialized
DEBUG - 2021-04-27 08:09:33 --> UTF-8 Support Enabled
INFO - 2021-04-27 08:09:33 --> Utf8 Class Initialized
INFO - 2021-04-27 08:09:33 --> URI Class Initialized
INFO - 2021-04-27 08:09:33 --> Router Class Initialized
INFO - 2021-04-27 08:09:33 --> Output Class Initialized
INFO - 2021-04-27 08:09:33 --> Security Class Initialized
DEBUG - 2021-04-27 08:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 08:09:33 --> Input Class Initialized
INFO - 2021-04-27 08:09:33 --> Language Class Initialized
INFO - 2021-04-27 08:09:33 --> Language Class Initialized
INFO - 2021-04-27 08:09:33 --> Config Class Initialized
INFO - 2021-04-27 08:09:33 --> Loader Class Initialized
INFO - 2021-04-27 08:09:33 --> Helper loaded: url_helper
INFO - 2021-04-27 08:09:33 --> Helper loaded: file_helper
INFO - 2021-04-27 08:09:33 --> Helper loaded: form_helper
INFO - 2021-04-27 08:09:33 --> Helper loaded: my_helper
INFO - 2021-04-27 08:09:33 --> Database Driver Class Initialized
DEBUG - 2021-04-27 08:09:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 08:09:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 08:09:33 --> Controller Class Initialized
DEBUG - 2021-04-27 08:09:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2021-04-27 08:09:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 08:09:33 --> Final output sent to browser
DEBUG - 2021-04-27 08:09:33 --> Total execution time: 0.0825
INFO - 2021-04-27 08:09:33 --> Config Class Initialized
INFO - 2021-04-27 08:09:33 --> Hooks Class Initialized
DEBUG - 2021-04-27 08:09:33 --> UTF-8 Support Enabled
INFO - 2021-04-27 08:09:33 --> Utf8 Class Initialized
INFO - 2021-04-27 08:09:33 --> URI Class Initialized
INFO - 2021-04-27 08:09:33 --> Router Class Initialized
INFO - 2021-04-27 08:09:33 --> Output Class Initialized
INFO - 2021-04-27 08:09:33 --> Security Class Initialized
DEBUG - 2021-04-27 08:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 08:09:33 --> Input Class Initialized
INFO - 2021-04-27 08:09:33 --> Language Class Initialized
INFO - 2021-04-27 08:09:33 --> Language Class Initialized
INFO - 2021-04-27 08:09:33 --> Config Class Initialized
INFO - 2021-04-27 08:09:33 --> Loader Class Initialized
INFO - 2021-04-27 08:09:33 --> Helper loaded: url_helper
INFO - 2021-04-27 08:09:33 --> Helper loaded: file_helper
INFO - 2021-04-27 08:09:33 --> Helper loaded: form_helper
INFO - 2021-04-27 08:09:33 --> Helper loaded: my_helper
INFO - 2021-04-27 08:09:33 --> Database Driver Class Initialized
DEBUG - 2021-04-27 08:09:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 08:09:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 08:09:33 --> Controller Class Initialized
INFO - 2021-04-27 08:09:35 --> Config Class Initialized
INFO - 2021-04-27 08:09:35 --> Hooks Class Initialized
DEBUG - 2021-04-27 08:09:35 --> UTF-8 Support Enabled
INFO - 2021-04-27 08:09:35 --> Utf8 Class Initialized
INFO - 2021-04-27 08:09:35 --> URI Class Initialized
INFO - 2021-04-27 08:09:35 --> Router Class Initialized
INFO - 2021-04-27 08:09:35 --> Output Class Initialized
INFO - 2021-04-27 08:09:35 --> Security Class Initialized
DEBUG - 2021-04-27 08:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 08:09:35 --> Input Class Initialized
INFO - 2021-04-27 08:09:35 --> Language Class Initialized
INFO - 2021-04-27 08:09:35 --> Language Class Initialized
INFO - 2021-04-27 08:09:35 --> Config Class Initialized
INFO - 2021-04-27 08:09:35 --> Loader Class Initialized
INFO - 2021-04-27 08:09:35 --> Helper loaded: url_helper
INFO - 2021-04-27 08:09:35 --> Helper loaded: file_helper
INFO - 2021-04-27 08:09:35 --> Helper loaded: form_helper
INFO - 2021-04-27 08:09:35 --> Helper loaded: my_helper
INFO - 2021-04-27 08:09:35 --> Database Driver Class Initialized
DEBUG - 2021-04-27 08:09:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 08:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 08:09:35 --> Controller Class Initialized
INFO - 2021-04-27 08:09:35 --> Final output sent to browser
DEBUG - 2021-04-27 08:09:35 --> Total execution time: 0.0840
INFO - 2021-04-27 08:09:40 --> Config Class Initialized
INFO - 2021-04-27 08:09:40 --> Hooks Class Initialized
DEBUG - 2021-04-27 08:09:40 --> UTF-8 Support Enabled
INFO - 2021-04-27 08:09:40 --> Utf8 Class Initialized
INFO - 2021-04-27 08:09:40 --> URI Class Initialized
INFO - 2021-04-27 08:09:40 --> Router Class Initialized
INFO - 2021-04-27 08:09:40 --> Output Class Initialized
INFO - 2021-04-27 08:09:40 --> Security Class Initialized
DEBUG - 2021-04-27 08:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 08:09:40 --> Input Class Initialized
INFO - 2021-04-27 08:09:40 --> Language Class Initialized
INFO - 2021-04-27 08:09:40 --> Language Class Initialized
INFO - 2021-04-27 08:09:40 --> Config Class Initialized
INFO - 2021-04-27 08:09:40 --> Loader Class Initialized
INFO - 2021-04-27 08:09:40 --> Helper loaded: url_helper
INFO - 2021-04-27 08:09:40 --> Helper loaded: file_helper
INFO - 2021-04-27 08:09:40 --> Helper loaded: form_helper
INFO - 2021-04-27 08:09:40 --> Helper loaded: my_helper
INFO - 2021-04-27 08:09:40 --> Database Driver Class Initialized
DEBUG - 2021-04-27 08:09:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 08:09:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 08:09:40 --> Controller Class Initialized
INFO - 2021-04-27 08:09:40 --> Final output sent to browser
DEBUG - 2021-04-27 08:09:40 --> Total execution time: 0.0946
INFO - 2021-04-27 08:09:40 --> Config Class Initialized
INFO - 2021-04-27 08:09:40 --> Hooks Class Initialized
DEBUG - 2021-04-27 08:09:40 --> UTF-8 Support Enabled
INFO - 2021-04-27 08:09:40 --> Utf8 Class Initialized
INFO - 2021-04-27 08:09:40 --> URI Class Initialized
INFO - 2021-04-27 08:09:40 --> Router Class Initialized
INFO - 2021-04-27 08:09:40 --> Output Class Initialized
INFO - 2021-04-27 08:09:40 --> Security Class Initialized
DEBUG - 2021-04-27 08:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 08:09:40 --> Input Class Initialized
INFO - 2021-04-27 08:09:40 --> Language Class Initialized
INFO - 2021-04-27 08:09:40 --> Language Class Initialized
INFO - 2021-04-27 08:09:40 --> Config Class Initialized
INFO - 2021-04-27 08:09:40 --> Loader Class Initialized
INFO - 2021-04-27 08:09:40 --> Helper loaded: url_helper
INFO - 2021-04-27 08:09:40 --> Helper loaded: file_helper
INFO - 2021-04-27 08:09:40 --> Helper loaded: form_helper
INFO - 2021-04-27 08:09:40 --> Helper loaded: my_helper
INFO - 2021-04-27 08:09:40 --> Database Driver Class Initialized
DEBUG - 2021-04-27 08:09:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 08:09:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 08:09:40 --> Controller Class Initialized
INFO - 2021-04-27 08:09:42 --> Config Class Initialized
INFO - 2021-04-27 08:09:42 --> Hooks Class Initialized
DEBUG - 2021-04-27 08:09:42 --> UTF-8 Support Enabled
INFO - 2021-04-27 08:09:42 --> Utf8 Class Initialized
INFO - 2021-04-27 08:09:42 --> URI Class Initialized
INFO - 2021-04-27 08:09:42 --> Router Class Initialized
INFO - 2021-04-27 08:09:42 --> Output Class Initialized
INFO - 2021-04-27 08:09:42 --> Security Class Initialized
DEBUG - 2021-04-27 08:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 08:09:42 --> Input Class Initialized
INFO - 2021-04-27 08:09:42 --> Language Class Initialized
INFO - 2021-04-27 08:09:42 --> Language Class Initialized
INFO - 2021-04-27 08:09:42 --> Config Class Initialized
INFO - 2021-04-27 08:09:42 --> Loader Class Initialized
INFO - 2021-04-27 08:09:42 --> Helper loaded: url_helper
INFO - 2021-04-27 08:09:42 --> Helper loaded: file_helper
INFO - 2021-04-27 08:09:42 --> Helper loaded: form_helper
INFO - 2021-04-27 08:09:42 --> Helper loaded: my_helper
INFO - 2021-04-27 08:09:42 --> Database Driver Class Initialized
DEBUG - 2021-04-27 08:09:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 08:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 08:09:42 --> Controller Class Initialized
DEBUG - 2021-04-27 08:09:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-27 08:09:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 08:09:42 --> Final output sent to browser
DEBUG - 2021-04-27 08:09:42 --> Total execution time: 0.0934
INFO - 2021-04-27 08:09:44 --> Config Class Initialized
INFO - 2021-04-27 08:09:44 --> Hooks Class Initialized
DEBUG - 2021-04-27 08:09:44 --> UTF-8 Support Enabled
INFO - 2021-04-27 08:09:44 --> Utf8 Class Initialized
INFO - 2021-04-27 08:09:44 --> URI Class Initialized
INFO - 2021-04-27 08:09:44 --> Router Class Initialized
INFO - 2021-04-27 08:09:44 --> Output Class Initialized
INFO - 2021-04-27 08:09:44 --> Security Class Initialized
DEBUG - 2021-04-27 08:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 08:09:44 --> Input Class Initialized
INFO - 2021-04-27 08:09:44 --> Language Class Initialized
INFO - 2021-04-27 08:09:44 --> Language Class Initialized
INFO - 2021-04-27 08:09:44 --> Config Class Initialized
INFO - 2021-04-27 08:09:44 --> Loader Class Initialized
INFO - 2021-04-27 08:09:44 --> Helper loaded: url_helper
INFO - 2021-04-27 08:09:44 --> Helper loaded: file_helper
INFO - 2021-04-27 08:09:44 --> Helper loaded: form_helper
INFO - 2021-04-27 08:09:44 --> Helper loaded: my_helper
INFO - 2021-04-27 08:09:44 --> Database Driver Class Initialized
DEBUG - 2021-04-27 08:09:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 08:09:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 08:09:44 --> Controller Class Initialized
DEBUG - 2021-04-27 08:09:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-04-27 08:09:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 08:09:44 --> Final output sent to browser
DEBUG - 2021-04-27 08:09:44 --> Total execution time: 0.0906
INFO - 2021-04-27 08:09:48 --> Config Class Initialized
INFO - 2021-04-27 08:09:48 --> Hooks Class Initialized
DEBUG - 2021-04-27 08:09:48 --> UTF-8 Support Enabled
INFO - 2021-04-27 08:09:48 --> Utf8 Class Initialized
INFO - 2021-04-27 08:09:48 --> URI Class Initialized
INFO - 2021-04-27 08:09:48 --> Router Class Initialized
INFO - 2021-04-27 08:09:48 --> Output Class Initialized
INFO - 2021-04-27 08:09:48 --> Security Class Initialized
DEBUG - 2021-04-27 08:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 08:09:48 --> Input Class Initialized
INFO - 2021-04-27 08:09:48 --> Language Class Initialized
INFO - 2021-04-27 08:09:48 --> Language Class Initialized
INFO - 2021-04-27 08:09:48 --> Config Class Initialized
INFO - 2021-04-27 08:09:48 --> Loader Class Initialized
INFO - 2021-04-27 08:09:48 --> Helper loaded: url_helper
INFO - 2021-04-27 08:09:48 --> Helper loaded: file_helper
INFO - 2021-04-27 08:09:48 --> Helper loaded: form_helper
INFO - 2021-04-27 08:09:48 --> Helper loaded: my_helper
INFO - 2021-04-27 08:09:48 --> Database Driver Class Initialized
DEBUG - 2021-04-27 08:09:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 08:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 08:09:48 --> Controller Class Initialized
INFO - 2021-04-27 08:09:48 --> Config Class Initialized
INFO - 2021-04-27 08:09:48 --> Hooks Class Initialized
DEBUG - 2021-04-27 08:09:48 --> UTF-8 Support Enabled
INFO - 2021-04-27 08:09:48 --> Utf8 Class Initialized
INFO - 2021-04-27 08:09:48 --> URI Class Initialized
INFO - 2021-04-27 08:09:48 --> Router Class Initialized
INFO - 2021-04-27 08:09:48 --> Output Class Initialized
INFO - 2021-04-27 08:09:48 --> Security Class Initialized
DEBUG - 2021-04-27 08:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 08:09:48 --> Input Class Initialized
INFO - 2021-04-27 08:09:48 --> Language Class Initialized
INFO - 2021-04-27 08:09:48 --> Language Class Initialized
INFO - 2021-04-27 08:09:48 --> Config Class Initialized
INFO - 2021-04-27 08:09:48 --> Loader Class Initialized
INFO - 2021-04-27 08:09:48 --> Helper loaded: url_helper
INFO - 2021-04-27 08:09:48 --> Helper loaded: file_helper
INFO - 2021-04-27 08:09:48 --> Helper loaded: form_helper
INFO - 2021-04-27 08:09:48 --> Helper loaded: my_helper
INFO - 2021-04-27 08:09:48 --> Database Driver Class Initialized
DEBUG - 2021-04-27 08:09:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 08:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 08:09:48 --> Controller Class Initialized
DEBUG - 2021-04-27 08:09:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-27 08:09:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 08:09:48 --> Final output sent to browser
DEBUG - 2021-04-27 08:09:48 --> Total execution time: 0.1122
INFO - 2021-04-27 08:15:28 --> Config Class Initialized
INFO - 2021-04-27 08:15:28 --> Hooks Class Initialized
DEBUG - 2021-04-27 08:15:28 --> UTF-8 Support Enabled
INFO - 2021-04-27 08:15:28 --> Utf8 Class Initialized
INFO - 2021-04-27 08:15:28 --> URI Class Initialized
INFO - 2021-04-27 08:15:28 --> Router Class Initialized
INFO - 2021-04-27 08:15:28 --> Output Class Initialized
INFO - 2021-04-27 08:15:28 --> Security Class Initialized
DEBUG - 2021-04-27 08:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 08:15:28 --> Input Class Initialized
INFO - 2021-04-27 08:15:28 --> Language Class Initialized
INFO - 2021-04-27 08:15:28 --> Language Class Initialized
INFO - 2021-04-27 08:15:28 --> Config Class Initialized
INFO - 2021-04-27 08:15:28 --> Loader Class Initialized
INFO - 2021-04-27 08:15:28 --> Helper loaded: url_helper
INFO - 2021-04-27 08:15:28 --> Helper loaded: file_helper
INFO - 2021-04-27 08:15:28 --> Helper loaded: form_helper
INFO - 2021-04-27 08:15:28 --> Helper loaded: my_helper
INFO - 2021-04-27 08:15:28 --> Database Driver Class Initialized
DEBUG - 2021-04-27 08:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 08:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 08:15:28 --> Controller Class Initialized
DEBUG - 2021-04-27 08:15:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-27 08:15:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 08:15:28 --> Final output sent to browser
DEBUG - 2021-04-27 08:15:28 --> Total execution time: 0.0985
INFO - 2021-04-27 08:15:29 --> Config Class Initialized
INFO - 2021-04-27 08:15:29 --> Hooks Class Initialized
DEBUG - 2021-04-27 08:15:29 --> UTF-8 Support Enabled
INFO - 2021-04-27 08:15:29 --> Utf8 Class Initialized
INFO - 2021-04-27 08:15:29 --> URI Class Initialized
INFO - 2021-04-27 08:15:29 --> Router Class Initialized
INFO - 2021-04-27 08:15:29 --> Output Class Initialized
INFO - 2021-04-27 08:15:29 --> Security Class Initialized
DEBUG - 2021-04-27 08:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 08:15:29 --> Input Class Initialized
INFO - 2021-04-27 08:15:29 --> Language Class Initialized
INFO - 2021-04-27 08:15:29 --> Language Class Initialized
INFO - 2021-04-27 08:15:29 --> Config Class Initialized
INFO - 2021-04-27 08:15:29 --> Loader Class Initialized
INFO - 2021-04-27 08:15:29 --> Helper loaded: url_helper
INFO - 2021-04-27 08:15:29 --> Helper loaded: file_helper
INFO - 2021-04-27 08:15:29 --> Helper loaded: form_helper
INFO - 2021-04-27 08:15:29 --> Helper loaded: my_helper
INFO - 2021-04-27 08:15:29 --> Database Driver Class Initialized
DEBUG - 2021-04-27 08:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 08:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 08:15:29 --> Controller Class Initialized
DEBUG - 2021-04-27 08:15:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-27 08:15:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 08:15:29 --> Final output sent to browser
DEBUG - 2021-04-27 08:15:29 --> Total execution time: 0.1000
INFO - 2021-04-27 08:16:41 --> Config Class Initialized
INFO - 2021-04-27 08:16:41 --> Hooks Class Initialized
DEBUG - 2021-04-27 08:16:41 --> UTF-8 Support Enabled
INFO - 2021-04-27 08:16:41 --> Utf8 Class Initialized
INFO - 2021-04-27 08:16:41 --> URI Class Initialized
INFO - 2021-04-27 08:16:41 --> Router Class Initialized
INFO - 2021-04-27 08:16:41 --> Output Class Initialized
INFO - 2021-04-27 08:16:41 --> Security Class Initialized
DEBUG - 2021-04-27 08:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 08:16:41 --> Input Class Initialized
INFO - 2021-04-27 08:16:41 --> Language Class Initialized
INFO - 2021-04-27 08:16:41 --> Language Class Initialized
INFO - 2021-04-27 08:16:41 --> Config Class Initialized
INFO - 2021-04-27 08:16:41 --> Loader Class Initialized
INFO - 2021-04-27 08:16:41 --> Helper loaded: url_helper
INFO - 2021-04-27 08:16:41 --> Helper loaded: file_helper
INFO - 2021-04-27 08:16:41 --> Helper loaded: form_helper
INFO - 2021-04-27 08:16:41 --> Helper loaded: my_helper
INFO - 2021-04-27 08:16:41 --> Database Driver Class Initialized
DEBUG - 2021-04-27 08:16:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 08:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 08:16:41 --> Controller Class Initialized
ERROR - 2021-04-27 08:16:41 --> Severity: Notice --> Undefined variable: q_siswa_per_kelas C:\xampp\htdocs\nilai\application\modules\set_kelas\views\list.php 17
DEBUG - 2021-04-27 08:16:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-27 08:16:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 08:16:41 --> Final output sent to browser
DEBUG - 2021-04-27 08:16:41 --> Total execution time: 0.0970
INFO - 2021-04-27 08:17:21 --> Config Class Initialized
INFO - 2021-04-27 08:17:21 --> Hooks Class Initialized
DEBUG - 2021-04-27 08:17:21 --> UTF-8 Support Enabled
INFO - 2021-04-27 08:17:21 --> Utf8 Class Initialized
INFO - 2021-04-27 08:17:21 --> URI Class Initialized
INFO - 2021-04-27 08:17:21 --> Router Class Initialized
INFO - 2021-04-27 08:17:21 --> Output Class Initialized
INFO - 2021-04-27 08:17:21 --> Security Class Initialized
DEBUG - 2021-04-27 08:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 08:17:21 --> Input Class Initialized
INFO - 2021-04-27 08:17:21 --> Language Class Initialized
INFO - 2021-04-27 08:17:21 --> Language Class Initialized
INFO - 2021-04-27 08:17:21 --> Config Class Initialized
INFO - 2021-04-27 08:17:21 --> Loader Class Initialized
INFO - 2021-04-27 08:17:21 --> Helper loaded: url_helper
INFO - 2021-04-27 08:17:21 --> Helper loaded: file_helper
INFO - 2021-04-27 08:17:21 --> Helper loaded: form_helper
INFO - 2021-04-27 08:17:21 --> Helper loaded: my_helper
INFO - 2021-04-27 08:17:21 --> Database Driver Class Initialized
DEBUG - 2021-04-27 08:17:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 08:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 08:17:21 --> Controller Class Initialized
ERROR - 2021-04-27 08:17:21 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\set_kelas\views\list.php 17
DEBUG - 2021-04-27 08:17:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-27 08:17:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 08:17:21 --> Final output sent to browser
DEBUG - 2021-04-27 08:17:21 --> Total execution time: 0.1084
INFO - 2021-04-27 08:17:24 --> Config Class Initialized
INFO - 2021-04-27 08:17:24 --> Hooks Class Initialized
DEBUG - 2021-04-27 08:17:24 --> UTF-8 Support Enabled
INFO - 2021-04-27 08:17:24 --> Utf8 Class Initialized
INFO - 2021-04-27 08:17:24 --> URI Class Initialized
INFO - 2021-04-27 08:17:24 --> Router Class Initialized
INFO - 2021-04-27 08:17:24 --> Output Class Initialized
INFO - 2021-04-27 08:17:24 --> Security Class Initialized
DEBUG - 2021-04-27 08:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 08:17:24 --> Input Class Initialized
INFO - 2021-04-27 08:17:24 --> Language Class Initialized
INFO - 2021-04-27 08:17:24 --> Language Class Initialized
INFO - 2021-04-27 08:17:24 --> Config Class Initialized
INFO - 2021-04-27 08:17:24 --> Loader Class Initialized
INFO - 2021-04-27 08:17:24 --> Helper loaded: url_helper
INFO - 2021-04-27 08:17:24 --> Helper loaded: file_helper
INFO - 2021-04-27 08:17:24 --> Helper loaded: form_helper
INFO - 2021-04-27 08:17:24 --> Helper loaded: my_helper
INFO - 2021-04-27 08:17:24 --> Database Driver Class Initialized
DEBUG - 2021-04-27 08:17:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 08:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 08:17:24 --> Controller Class Initialized
ERROR - 2021-04-27 08:17:24 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\set_kelas\views\list.php 17
DEBUG - 2021-04-27 08:17:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-27 08:17:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 08:17:24 --> Final output sent to browser
DEBUG - 2021-04-27 08:17:24 --> Total execution time: 0.0815
INFO - 2021-04-27 08:17:43 --> Config Class Initialized
INFO - 2021-04-27 08:17:43 --> Hooks Class Initialized
DEBUG - 2021-04-27 08:17:43 --> UTF-8 Support Enabled
INFO - 2021-04-27 08:17:43 --> Utf8 Class Initialized
INFO - 2021-04-27 08:17:43 --> URI Class Initialized
INFO - 2021-04-27 08:17:43 --> Router Class Initialized
INFO - 2021-04-27 08:17:43 --> Output Class Initialized
INFO - 2021-04-27 08:17:43 --> Security Class Initialized
DEBUG - 2021-04-27 08:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 08:17:43 --> Input Class Initialized
INFO - 2021-04-27 08:17:43 --> Language Class Initialized
INFO - 2021-04-27 08:17:43 --> Language Class Initialized
INFO - 2021-04-27 08:17:43 --> Config Class Initialized
INFO - 2021-04-27 08:17:43 --> Loader Class Initialized
INFO - 2021-04-27 08:17:43 --> Helper loaded: url_helper
INFO - 2021-04-27 08:17:43 --> Helper loaded: file_helper
INFO - 2021-04-27 08:17:43 --> Helper loaded: form_helper
INFO - 2021-04-27 08:17:43 --> Helper loaded: my_helper
INFO - 2021-04-27 08:17:43 --> Database Driver Class Initialized
DEBUG - 2021-04-27 08:17:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 08:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 08:17:43 --> Controller Class Initialized
DEBUG - 2021-04-27 08:17:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-27 08:17:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 08:17:44 --> Final output sent to browser
DEBUG - 2021-04-27 08:17:44 --> Total execution time: 0.0967
INFO - 2021-04-27 08:17:56 --> Config Class Initialized
INFO - 2021-04-27 08:17:56 --> Hooks Class Initialized
DEBUG - 2021-04-27 08:17:56 --> UTF-8 Support Enabled
INFO - 2021-04-27 08:17:56 --> Utf8 Class Initialized
INFO - 2021-04-27 08:17:56 --> URI Class Initialized
INFO - 2021-04-27 08:17:56 --> Router Class Initialized
INFO - 2021-04-27 08:17:56 --> Output Class Initialized
INFO - 2021-04-27 08:17:56 --> Security Class Initialized
DEBUG - 2021-04-27 08:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 08:17:56 --> Input Class Initialized
INFO - 2021-04-27 08:17:56 --> Language Class Initialized
INFO - 2021-04-27 08:17:56 --> Language Class Initialized
INFO - 2021-04-27 08:17:56 --> Config Class Initialized
INFO - 2021-04-27 08:17:56 --> Loader Class Initialized
INFO - 2021-04-27 08:17:56 --> Helper loaded: url_helper
INFO - 2021-04-27 08:17:56 --> Helper loaded: file_helper
INFO - 2021-04-27 08:17:56 --> Helper loaded: form_helper
INFO - 2021-04-27 08:17:56 --> Helper loaded: my_helper
INFO - 2021-04-27 08:17:56 --> Database Driver Class Initialized
DEBUG - 2021-04-27 08:17:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 08:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 08:17:56 --> Controller Class Initialized
DEBUG - 2021-04-27 08:17:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-27 08:17:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 08:17:56 --> Final output sent to browser
DEBUG - 2021-04-27 08:17:56 --> Total execution time: 0.0996
INFO - 2021-04-27 08:19:41 --> Config Class Initialized
INFO - 2021-04-27 08:19:41 --> Hooks Class Initialized
DEBUG - 2021-04-27 08:19:41 --> UTF-8 Support Enabled
INFO - 2021-04-27 08:19:41 --> Utf8 Class Initialized
INFO - 2021-04-27 08:19:41 --> URI Class Initialized
INFO - 2021-04-27 08:19:41 --> Router Class Initialized
INFO - 2021-04-27 08:19:41 --> Output Class Initialized
INFO - 2021-04-27 08:19:41 --> Security Class Initialized
DEBUG - 2021-04-27 08:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 08:19:41 --> Input Class Initialized
INFO - 2021-04-27 08:19:41 --> Language Class Initialized
INFO - 2021-04-27 08:19:41 --> Language Class Initialized
INFO - 2021-04-27 08:19:41 --> Config Class Initialized
INFO - 2021-04-27 08:19:41 --> Loader Class Initialized
INFO - 2021-04-27 08:19:41 --> Helper loaded: url_helper
INFO - 2021-04-27 08:19:41 --> Helper loaded: file_helper
INFO - 2021-04-27 08:19:41 --> Helper loaded: form_helper
INFO - 2021-04-27 08:19:41 --> Helper loaded: my_helper
INFO - 2021-04-27 08:19:41 --> Database Driver Class Initialized
DEBUG - 2021-04-27 08:19:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 08:19:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 08:19:41 --> Controller Class Initialized
DEBUG - 2021-04-27 08:19:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-27 08:19:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 08:19:41 --> Final output sent to browser
DEBUG - 2021-04-27 08:19:41 --> Total execution time: 0.1103
INFO - 2021-04-27 08:22:41 --> Config Class Initialized
INFO - 2021-04-27 08:22:41 --> Hooks Class Initialized
DEBUG - 2021-04-27 08:22:41 --> UTF-8 Support Enabled
INFO - 2021-04-27 08:22:41 --> Utf8 Class Initialized
INFO - 2021-04-27 08:22:41 --> URI Class Initialized
INFO - 2021-04-27 08:22:41 --> Router Class Initialized
INFO - 2021-04-27 08:22:41 --> Output Class Initialized
INFO - 2021-04-27 08:22:41 --> Security Class Initialized
DEBUG - 2021-04-27 08:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 08:22:41 --> Input Class Initialized
INFO - 2021-04-27 08:22:41 --> Language Class Initialized
INFO - 2021-04-27 08:22:41 --> Language Class Initialized
INFO - 2021-04-27 08:22:41 --> Config Class Initialized
INFO - 2021-04-27 08:22:41 --> Loader Class Initialized
INFO - 2021-04-27 08:22:41 --> Helper loaded: url_helper
INFO - 2021-04-27 08:22:41 --> Helper loaded: file_helper
INFO - 2021-04-27 08:22:41 --> Helper loaded: form_helper
INFO - 2021-04-27 08:22:41 --> Helper loaded: my_helper
INFO - 2021-04-27 08:22:41 --> Database Driver Class Initialized
DEBUG - 2021-04-27 08:22:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 08:22:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 08:22:41 --> Controller Class Initialized
DEBUG - 2021-04-27 08:22:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-27 08:22:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 08:22:41 --> Final output sent to browser
DEBUG - 2021-04-27 08:22:41 --> Total execution time: 0.1083
INFO - 2021-04-27 08:22:54 --> Config Class Initialized
INFO - 2021-04-27 08:22:54 --> Hooks Class Initialized
DEBUG - 2021-04-27 08:22:54 --> UTF-8 Support Enabled
INFO - 2021-04-27 08:22:54 --> Utf8 Class Initialized
INFO - 2021-04-27 08:22:54 --> URI Class Initialized
INFO - 2021-04-27 08:22:54 --> Router Class Initialized
INFO - 2021-04-27 08:22:54 --> Output Class Initialized
INFO - 2021-04-27 08:22:54 --> Security Class Initialized
DEBUG - 2021-04-27 08:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 08:22:54 --> Input Class Initialized
INFO - 2021-04-27 08:22:54 --> Language Class Initialized
INFO - 2021-04-27 08:22:54 --> Language Class Initialized
INFO - 2021-04-27 08:22:54 --> Config Class Initialized
INFO - 2021-04-27 08:22:54 --> Loader Class Initialized
INFO - 2021-04-27 08:22:54 --> Helper loaded: url_helper
INFO - 2021-04-27 08:22:54 --> Helper loaded: file_helper
INFO - 2021-04-27 08:22:54 --> Helper loaded: form_helper
INFO - 2021-04-27 08:22:54 --> Helper loaded: my_helper
INFO - 2021-04-27 08:22:54 --> Database Driver Class Initialized
DEBUG - 2021-04-27 08:22:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 08:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 08:22:54 --> Controller Class Initialized
DEBUG - 2021-04-27 08:22:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-27 08:22:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 08:22:54 --> Final output sent to browser
DEBUG - 2021-04-27 08:22:54 --> Total execution time: 0.0968
INFO - 2021-04-27 08:22:55 --> Config Class Initialized
INFO - 2021-04-27 08:22:55 --> Hooks Class Initialized
DEBUG - 2021-04-27 08:22:55 --> UTF-8 Support Enabled
INFO - 2021-04-27 08:22:55 --> Utf8 Class Initialized
INFO - 2021-04-27 08:22:55 --> URI Class Initialized
INFO - 2021-04-27 08:22:55 --> Router Class Initialized
INFO - 2021-04-27 08:22:55 --> Output Class Initialized
INFO - 2021-04-27 08:22:55 --> Security Class Initialized
DEBUG - 2021-04-27 08:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 08:22:55 --> Input Class Initialized
INFO - 2021-04-27 08:22:55 --> Language Class Initialized
INFO - 2021-04-27 08:22:55 --> Language Class Initialized
INFO - 2021-04-27 08:22:55 --> Config Class Initialized
INFO - 2021-04-27 08:22:55 --> Loader Class Initialized
INFO - 2021-04-27 08:22:55 --> Helper loaded: url_helper
INFO - 2021-04-27 08:22:55 --> Helper loaded: file_helper
INFO - 2021-04-27 08:22:55 --> Helper loaded: form_helper
INFO - 2021-04-27 08:22:55 --> Helper loaded: my_helper
INFO - 2021-04-27 08:22:55 --> Database Driver Class Initialized
DEBUG - 2021-04-27 08:22:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 08:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 08:22:55 --> Controller Class Initialized
DEBUG - 2021-04-27 08:22:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-27 08:22:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 08:22:55 --> Final output sent to browser
DEBUG - 2021-04-27 08:22:55 --> Total execution time: 0.0987
INFO - 2021-04-27 08:23:13 --> Config Class Initialized
INFO - 2021-04-27 08:23:13 --> Hooks Class Initialized
DEBUG - 2021-04-27 08:23:13 --> UTF-8 Support Enabled
INFO - 2021-04-27 08:23:13 --> Utf8 Class Initialized
INFO - 2021-04-27 08:23:13 --> URI Class Initialized
INFO - 2021-04-27 08:23:13 --> Router Class Initialized
INFO - 2021-04-27 08:23:13 --> Output Class Initialized
INFO - 2021-04-27 08:23:13 --> Security Class Initialized
DEBUG - 2021-04-27 08:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 08:23:13 --> Input Class Initialized
INFO - 2021-04-27 08:23:13 --> Language Class Initialized
INFO - 2021-04-27 08:23:13 --> Language Class Initialized
INFO - 2021-04-27 08:23:13 --> Config Class Initialized
INFO - 2021-04-27 08:23:13 --> Loader Class Initialized
INFO - 2021-04-27 08:23:13 --> Helper loaded: url_helper
INFO - 2021-04-27 08:23:13 --> Helper loaded: file_helper
INFO - 2021-04-27 08:23:13 --> Helper loaded: form_helper
INFO - 2021-04-27 08:23:13 --> Helper loaded: my_helper
INFO - 2021-04-27 08:23:13 --> Database Driver Class Initialized
DEBUG - 2021-04-27 08:23:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 08:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 08:23:13 --> Controller Class Initialized
DEBUG - 2021-04-27 08:23:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-04-27 08:23:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 08:23:13 --> Final output sent to browser
DEBUG - 2021-04-27 08:23:13 --> Total execution time: 0.0966
INFO - 2021-04-27 08:23:13 --> Config Class Initialized
INFO - 2021-04-27 08:23:13 --> Hooks Class Initialized
DEBUG - 2021-04-27 08:23:13 --> UTF-8 Support Enabled
INFO - 2021-04-27 08:23:13 --> Utf8 Class Initialized
INFO - 2021-04-27 08:23:13 --> URI Class Initialized
INFO - 2021-04-27 08:23:13 --> Router Class Initialized
INFO - 2021-04-27 08:23:13 --> Output Class Initialized
INFO - 2021-04-27 08:23:13 --> Security Class Initialized
DEBUG - 2021-04-27 08:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 08:23:13 --> Input Class Initialized
INFO - 2021-04-27 08:23:13 --> Language Class Initialized
INFO - 2021-04-27 08:23:13 --> Language Class Initialized
INFO - 2021-04-27 08:23:13 --> Config Class Initialized
INFO - 2021-04-27 08:23:13 --> Loader Class Initialized
INFO - 2021-04-27 08:23:13 --> Helper loaded: url_helper
INFO - 2021-04-27 08:23:13 --> Helper loaded: file_helper
INFO - 2021-04-27 08:23:13 --> Helper loaded: form_helper
INFO - 2021-04-27 08:23:13 --> Helper loaded: my_helper
INFO - 2021-04-27 08:23:13 --> Database Driver Class Initialized
DEBUG - 2021-04-27 08:23:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 08:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 08:23:13 --> Controller Class Initialized
INFO - 2021-04-27 08:26:16 --> Config Class Initialized
INFO - 2021-04-27 08:26:16 --> Hooks Class Initialized
DEBUG - 2021-04-27 08:26:16 --> UTF-8 Support Enabled
INFO - 2021-04-27 08:26:16 --> Utf8 Class Initialized
INFO - 2021-04-27 08:26:16 --> URI Class Initialized
DEBUG - 2021-04-27 08:26:16 --> No URI present. Default controller set.
INFO - 2021-04-27 08:26:16 --> Router Class Initialized
INFO - 2021-04-27 08:26:16 --> Output Class Initialized
INFO - 2021-04-27 08:26:16 --> Security Class Initialized
DEBUG - 2021-04-27 08:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 08:26:16 --> Input Class Initialized
INFO - 2021-04-27 08:26:16 --> Language Class Initialized
INFO - 2021-04-27 08:26:16 --> Language Class Initialized
INFO - 2021-04-27 08:26:16 --> Config Class Initialized
INFO - 2021-04-27 08:26:16 --> Loader Class Initialized
INFO - 2021-04-27 08:26:16 --> Helper loaded: url_helper
INFO - 2021-04-27 08:26:16 --> Helper loaded: file_helper
INFO - 2021-04-27 08:26:16 --> Helper loaded: form_helper
INFO - 2021-04-27 08:26:16 --> Helper loaded: my_helper
INFO - 2021-04-27 08:26:16 --> Database Driver Class Initialized
DEBUG - 2021-04-27 08:26:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 08:26:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 08:26:16 --> Controller Class Initialized
DEBUG - 2021-04-27 08:26:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-04-27 08:26:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 08:26:16 --> Final output sent to browser
DEBUG - 2021-04-27 08:26:16 --> Total execution time: 0.1200
INFO - 2021-04-27 08:31:47 --> Config Class Initialized
INFO - 2021-04-27 08:31:47 --> Hooks Class Initialized
DEBUG - 2021-04-27 08:31:47 --> UTF-8 Support Enabled
INFO - 2021-04-27 08:31:47 --> Utf8 Class Initialized
INFO - 2021-04-27 08:31:47 --> URI Class Initialized
INFO - 2021-04-27 08:31:47 --> Router Class Initialized
INFO - 2021-04-27 08:31:47 --> Output Class Initialized
INFO - 2021-04-27 08:31:47 --> Security Class Initialized
DEBUG - 2021-04-27 08:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 08:31:47 --> Input Class Initialized
INFO - 2021-04-27 08:31:47 --> Language Class Initialized
INFO - 2021-04-27 08:31:48 --> Language Class Initialized
INFO - 2021-04-27 08:31:48 --> Config Class Initialized
INFO - 2021-04-27 08:31:48 --> Loader Class Initialized
INFO - 2021-04-27 08:31:48 --> Helper loaded: url_helper
INFO - 2021-04-27 08:31:48 --> Helper loaded: file_helper
INFO - 2021-04-27 08:31:48 --> Helper loaded: form_helper
INFO - 2021-04-27 08:31:48 --> Helper loaded: my_helper
INFO - 2021-04-27 08:31:48 --> Database Driver Class Initialized
DEBUG - 2021-04-27 08:31:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 08:31:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 08:31:48 --> Controller Class Initialized
DEBUG - 2021-04-27 08:31:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-04-27 08:31:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 08:31:48 --> Final output sent to browser
DEBUG - 2021-04-27 08:31:48 --> Total execution time: 0.0983
INFO - 2021-04-27 08:31:48 --> Config Class Initialized
INFO - 2021-04-27 08:31:48 --> Hooks Class Initialized
DEBUG - 2021-04-27 08:31:48 --> UTF-8 Support Enabled
INFO - 2021-04-27 08:31:48 --> Utf8 Class Initialized
INFO - 2021-04-27 08:31:48 --> URI Class Initialized
INFO - 2021-04-27 08:31:48 --> Router Class Initialized
INFO - 2021-04-27 08:31:48 --> Output Class Initialized
INFO - 2021-04-27 08:31:48 --> Security Class Initialized
DEBUG - 2021-04-27 08:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 08:31:48 --> Input Class Initialized
INFO - 2021-04-27 08:31:48 --> Language Class Initialized
INFO - 2021-04-27 08:31:48 --> Language Class Initialized
INFO - 2021-04-27 08:31:48 --> Config Class Initialized
INFO - 2021-04-27 08:31:48 --> Loader Class Initialized
INFO - 2021-04-27 08:31:48 --> Helper loaded: url_helper
INFO - 2021-04-27 08:31:48 --> Helper loaded: file_helper
INFO - 2021-04-27 08:31:48 --> Helper loaded: form_helper
INFO - 2021-04-27 08:31:48 --> Helper loaded: my_helper
INFO - 2021-04-27 08:31:48 --> Database Driver Class Initialized
DEBUG - 2021-04-27 08:31:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 08:31:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 08:31:48 --> Controller Class Initialized
INFO - 2021-04-27 08:31:54 --> Config Class Initialized
INFO - 2021-04-27 08:31:54 --> Hooks Class Initialized
DEBUG - 2021-04-27 08:31:54 --> UTF-8 Support Enabled
INFO - 2021-04-27 08:31:54 --> Utf8 Class Initialized
INFO - 2021-04-27 08:31:54 --> URI Class Initialized
INFO - 2021-04-27 08:31:54 --> Router Class Initialized
INFO - 2021-04-27 08:31:54 --> Output Class Initialized
INFO - 2021-04-27 08:31:54 --> Security Class Initialized
DEBUG - 2021-04-27 08:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 08:31:54 --> Input Class Initialized
INFO - 2021-04-27 08:31:54 --> Language Class Initialized
INFO - 2021-04-27 08:31:54 --> Language Class Initialized
INFO - 2021-04-27 08:31:54 --> Config Class Initialized
INFO - 2021-04-27 08:31:54 --> Loader Class Initialized
INFO - 2021-04-27 08:31:54 --> Helper loaded: url_helper
INFO - 2021-04-27 08:31:54 --> Helper loaded: file_helper
INFO - 2021-04-27 08:31:54 --> Helper loaded: form_helper
INFO - 2021-04-27 08:31:54 --> Helper loaded: my_helper
INFO - 2021-04-27 08:31:54 --> Database Driver Class Initialized
DEBUG - 2021-04-27 08:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 08:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 08:31:54 --> Controller Class Initialized
INFO - 2021-04-27 08:31:56 --> Config Class Initialized
INFO - 2021-04-27 08:31:56 --> Hooks Class Initialized
DEBUG - 2021-04-27 08:31:56 --> UTF-8 Support Enabled
INFO - 2021-04-27 08:31:56 --> Utf8 Class Initialized
INFO - 2021-04-27 08:31:56 --> URI Class Initialized
INFO - 2021-04-27 08:31:56 --> Router Class Initialized
INFO - 2021-04-27 08:31:56 --> Output Class Initialized
INFO - 2021-04-27 08:31:56 --> Security Class Initialized
DEBUG - 2021-04-27 08:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 08:31:56 --> Input Class Initialized
INFO - 2021-04-27 08:31:56 --> Language Class Initialized
INFO - 2021-04-27 08:31:56 --> Language Class Initialized
INFO - 2021-04-27 08:31:56 --> Config Class Initialized
INFO - 2021-04-27 08:31:56 --> Loader Class Initialized
INFO - 2021-04-27 08:31:56 --> Helper loaded: url_helper
INFO - 2021-04-27 08:31:56 --> Helper loaded: file_helper
INFO - 2021-04-27 08:31:56 --> Helper loaded: form_helper
INFO - 2021-04-27 08:31:56 --> Helper loaded: my_helper
INFO - 2021-04-27 08:31:56 --> Database Driver Class Initialized
DEBUG - 2021-04-27 08:31:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 08:31:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 08:31:56 --> Controller Class Initialized
DEBUG - 2021-04-27 08:31:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2021-04-27 08:31:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 08:31:56 --> Final output sent to browser
DEBUG - 2021-04-27 08:31:56 --> Total execution time: 0.0803
INFO - 2021-04-27 08:31:56 --> Config Class Initialized
INFO - 2021-04-27 08:31:56 --> Hooks Class Initialized
DEBUG - 2021-04-27 08:31:56 --> UTF-8 Support Enabled
INFO - 2021-04-27 08:31:56 --> Utf8 Class Initialized
INFO - 2021-04-27 08:31:56 --> URI Class Initialized
INFO - 2021-04-27 08:31:56 --> Router Class Initialized
INFO - 2021-04-27 08:31:56 --> Output Class Initialized
INFO - 2021-04-27 08:31:56 --> Security Class Initialized
DEBUG - 2021-04-27 08:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 08:31:56 --> Input Class Initialized
INFO - 2021-04-27 08:31:56 --> Language Class Initialized
INFO - 2021-04-27 08:31:56 --> Language Class Initialized
INFO - 2021-04-27 08:31:56 --> Config Class Initialized
INFO - 2021-04-27 08:31:56 --> Loader Class Initialized
INFO - 2021-04-27 08:31:56 --> Helper loaded: url_helper
INFO - 2021-04-27 08:31:56 --> Helper loaded: file_helper
INFO - 2021-04-27 08:31:56 --> Helper loaded: form_helper
INFO - 2021-04-27 08:31:56 --> Helper loaded: my_helper
INFO - 2021-04-27 08:31:56 --> Database Driver Class Initialized
DEBUG - 2021-04-27 08:31:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 08:31:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 08:31:56 --> Controller Class Initialized
INFO - 2021-04-27 08:32:21 --> Config Class Initialized
INFO - 2021-04-27 08:32:21 --> Hooks Class Initialized
DEBUG - 2021-04-27 08:32:21 --> UTF-8 Support Enabled
INFO - 2021-04-27 08:32:21 --> Utf8 Class Initialized
INFO - 2021-04-27 08:32:21 --> URI Class Initialized
INFO - 2021-04-27 08:32:21 --> Router Class Initialized
INFO - 2021-04-27 08:32:21 --> Output Class Initialized
INFO - 2021-04-27 08:32:21 --> Security Class Initialized
DEBUG - 2021-04-27 08:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 08:32:21 --> Input Class Initialized
INFO - 2021-04-27 08:32:21 --> Language Class Initialized
INFO - 2021-04-27 08:32:21 --> Language Class Initialized
INFO - 2021-04-27 08:32:21 --> Config Class Initialized
INFO - 2021-04-27 08:32:21 --> Loader Class Initialized
INFO - 2021-04-27 08:32:21 --> Helper loaded: url_helper
INFO - 2021-04-27 08:32:21 --> Helper loaded: file_helper
INFO - 2021-04-27 08:32:21 --> Helper loaded: form_helper
INFO - 2021-04-27 08:32:21 --> Helper loaded: my_helper
INFO - 2021-04-27 08:32:21 --> Database Driver Class Initialized
DEBUG - 2021-04-27 08:32:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 08:32:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 08:32:21 --> Controller Class Initialized
DEBUG - 2021-04-27 08:32:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-04-27 08:32:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 08:32:21 --> Final output sent to browser
DEBUG - 2021-04-27 08:32:21 --> Total execution time: 0.2257
INFO - 2021-04-27 08:38:34 --> Config Class Initialized
INFO - 2021-04-27 08:38:34 --> Hooks Class Initialized
DEBUG - 2021-04-27 08:38:34 --> UTF-8 Support Enabled
INFO - 2021-04-27 08:38:34 --> Utf8 Class Initialized
INFO - 2021-04-27 08:38:34 --> URI Class Initialized
DEBUG - 2021-04-27 08:38:34 --> No URI present. Default controller set.
INFO - 2021-04-27 08:38:34 --> Router Class Initialized
INFO - 2021-04-27 08:38:34 --> Output Class Initialized
INFO - 2021-04-27 08:38:34 --> Security Class Initialized
DEBUG - 2021-04-27 08:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 08:38:34 --> Input Class Initialized
INFO - 2021-04-27 08:38:34 --> Language Class Initialized
INFO - 2021-04-27 08:38:34 --> Language Class Initialized
INFO - 2021-04-27 08:38:34 --> Config Class Initialized
INFO - 2021-04-27 08:38:34 --> Loader Class Initialized
INFO - 2021-04-27 08:38:34 --> Helper loaded: url_helper
INFO - 2021-04-27 08:38:34 --> Helper loaded: file_helper
INFO - 2021-04-27 08:38:34 --> Helper loaded: form_helper
INFO - 2021-04-27 08:38:34 --> Helper loaded: my_helper
INFO - 2021-04-27 08:38:34 --> Database Driver Class Initialized
DEBUG - 2021-04-27 08:38:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 08:38:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 08:38:34 --> Controller Class Initialized
DEBUG - 2021-04-27 08:38:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-04-27 08:38:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 08:38:34 --> Final output sent to browser
DEBUG - 2021-04-27 08:38:34 --> Total execution time: 0.2780
INFO - 2021-04-27 08:39:28 --> Config Class Initialized
INFO - 2021-04-27 08:39:28 --> Hooks Class Initialized
DEBUG - 2021-04-27 08:39:28 --> UTF-8 Support Enabled
INFO - 2021-04-27 08:39:28 --> Utf8 Class Initialized
INFO - 2021-04-27 08:39:28 --> URI Class Initialized
INFO - 2021-04-27 08:39:28 --> Router Class Initialized
INFO - 2021-04-27 08:39:28 --> Output Class Initialized
INFO - 2021-04-27 08:39:28 --> Security Class Initialized
DEBUG - 2021-04-27 08:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 08:39:28 --> Input Class Initialized
INFO - 2021-04-27 08:39:28 --> Language Class Initialized
INFO - 2021-04-27 08:39:28 --> Language Class Initialized
INFO - 2021-04-27 08:39:28 --> Config Class Initialized
INFO - 2021-04-27 08:39:28 --> Loader Class Initialized
INFO - 2021-04-27 08:39:28 --> Helper loaded: url_helper
INFO - 2021-04-27 08:39:28 --> Helper loaded: file_helper
INFO - 2021-04-27 08:39:28 --> Helper loaded: form_helper
INFO - 2021-04-27 08:39:28 --> Helper loaded: my_helper
INFO - 2021-04-27 08:39:28 --> Database Driver Class Initialized
DEBUG - 2021-04-27 08:39:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 08:39:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 08:39:28 --> Controller Class Initialized
DEBUG - 2021-04-27 08:39:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-27 08:39:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 08:39:29 --> Final output sent to browser
DEBUG - 2021-04-27 08:39:29 --> Total execution time: 0.1605
INFO - 2021-04-27 09:38:10 --> Config Class Initialized
INFO - 2021-04-27 09:38:10 --> Hooks Class Initialized
DEBUG - 2021-04-27 09:38:10 --> UTF-8 Support Enabled
INFO - 2021-04-27 09:38:10 --> Utf8 Class Initialized
INFO - 2021-04-27 09:38:10 --> URI Class Initialized
DEBUG - 2021-04-27 09:38:10 --> No URI present. Default controller set.
INFO - 2021-04-27 09:38:10 --> Router Class Initialized
INFO - 2021-04-27 09:38:10 --> Output Class Initialized
INFO - 2021-04-27 09:38:10 --> Security Class Initialized
DEBUG - 2021-04-27 09:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 09:38:10 --> Input Class Initialized
INFO - 2021-04-27 09:38:10 --> Language Class Initialized
INFO - 2021-04-27 09:38:10 --> Language Class Initialized
INFO - 2021-04-27 09:38:10 --> Config Class Initialized
INFO - 2021-04-27 09:38:10 --> Loader Class Initialized
INFO - 2021-04-27 09:38:10 --> Helper loaded: url_helper
INFO - 2021-04-27 09:38:10 --> Helper loaded: file_helper
INFO - 2021-04-27 09:38:10 --> Helper loaded: form_helper
INFO - 2021-04-27 09:38:10 --> Helper loaded: my_helper
INFO - 2021-04-27 09:38:10 --> Database Driver Class Initialized
DEBUG - 2021-04-27 09:38:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 09:38:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 09:38:10 --> Controller Class Initialized
INFO - 2021-04-27 09:38:10 --> Config Class Initialized
INFO - 2021-04-27 09:38:10 --> Hooks Class Initialized
DEBUG - 2021-04-27 09:38:10 --> UTF-8 Support Enabled
INFO - 2021-04-27 09:38:10 --> Utf8 Class Initialized
INFO - 2021-04-27 09:38:10 --> URI Class Initialized
INFO - 2021-04-27 09:38:10 --> Router Class Initialized
INFO - 2021-04-27 09:38:10 --> Output Class Initialized
INFO - 2021-04-27 09:38:10 --> Security Class Initialized
DEBUG - 2021-04-27 09:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 09:38:10 --> Input Class Initialized
INFO - 2021-04-27 09:38:10 --> Language Class Initialized
INFO - 2021-04-27 09:38:10 --> Language Class Initialized
INFO - 2021-04-27 09:38:10 --> Config Class Initialized
INFO - 2021-04-27 09:38:10 --> Loader Class Initialized
INFO - 2021-04-27 09:38:10 --> Helper loaded: url_helper
INFO - 2021-04-27 09:38:10 --> Helper loaded: file_helper
INFO - 2021-04-27 09:38:10 --> Helper loaded: form_helper
INFO - 2021-04-27 09:38:10 --> Helper loaded: my_helper
INFO - 2021-04-27 09:38:10 --> Database Driver Class Initialized
DEBUG - 2021-04-27 09:38:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 09:38:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 09:38:10 --> Controller Class Initialized
DEBUG - 2021-04-27 09:38:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-04-27 09:38:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 09:38:10 --> Final output sent to browser
DEBUG - 2021-04-27 09:38:10 --> Total execution time: 0.1505
INFO - 2021-04-27 09:38:17 --> Config Class Initialized
INFO - 2021-04-27 09:38:17 --> Hooks Class Initialized
DEBUG - 2021-04-27 09:38:17 --> UTF-8 Support Enabled
INFO - 2021-04-27 09:38:17 --> Utf8 Class Initialized
INFO - 2021-04-27 09:38:17 --> URI Class Initialized
INFO - 2021-04-27 09:38:17 --> Router Class Initialized
INFO - 2021-04-27 09:38:17 --> Output Class Initialized
INFO - 2021-04-27 09:38:17 --> Security Class Initialized
DEBUG - 2021-04-27 09:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 09:38:17 --> Input Class Initialized
INFO - 2021-04-27 09:38:17 --> Language Class Initialized
INFO - 2021-04-27 09:38:17 --> Language Class Initialized
INFO - 2021-04-27 09:38:17 --> Config Class Initialized
INFO - 2021-04-27 09:38:17 --> Loader Class Initialized
INFO - 2021-04-27 09:38:17 --> Helper loaded: url_helper
INFO - 2021-04-27 09:38:17 --> Helper loaded: file_helper
INFO - 2021-04-27 09:38:17 --> Helper loaded: form_helper
INFO - 2021-04-27 09:38:17 --> Helper loaded: my_helper
INFO - 2021-04-27 09:38:17 --> Database Driver Class Initialized
DEBUG - 2021-04-27 09:38:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 09:38:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 09:38:18 --> Controller Class Initialized
INFO - 2021-04-27 09:38:18 --> Helper loaded: cookie_helper
INFO - 2021-04-27 09:38:18 --> Final output sent to browser
DEBUG - 2021-04-27 09:38:18 --> Total execution time: 0.1729
INFO - 2021-04-27 09:38:18 --> Config Class Initialized
INFO - 2021-04-27 09:38:18 --> Hooks Class Initialized
DEBUG - 2021-04-27 09:38:18 --> UTF-8 Support Enabled
INFO - 2021-04-27 09:38:18 --> Utf8 Class Initialized
INFO - 2021-04-27 09:38:18 --> URI Class Initialized
INFO - 2021-04-27 09:38:18 --> Router Class Initialized
INFO - 2021-04-27 09:38:18 --> Output Class Initialized
INFO - 2021-04-27 09:38:18 --> Security Class Initialized
DEBUG - 2021-04-27 09:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 09:38:18 --> Input Class Initialized
INFO - 2021-04-27 09:38:18 --> Language Class Initialized
INFO - 2021-04-27 09:38:18 --> Language Class Initialized
INFO - 2021-04-27 09:38:18 --> Config Class Initialized
INFO - 2021-04-27 09:38:18 --> Loader Class Initialized
INFO - 2021-04-27 09:38:18 --> Helper loaded: url_helper
INFO - 2021-04-27 09:38:18 --> Helper loaded: file_helper
INFO - 2021-04-27 09:38:18 --> Helper loaded: form_helper
INFO - 2021-04-27 09:38:18 --> Helper loaded: my_helper
INFO - 2021-04-27 09:38:18 --> Database Driver Class Initialized
DEBUG - 2021-04-27 09:38:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 09:38:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 09:38:18 --> Controller Class Initialized
DEBUG - 2021-04-27 09:38:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-04-27 09:38:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 09:38:18 --> Final output sent to browser
DEBUG - 2021-04-27 09:38:18 --> Total execution time: 0.1654
INFO - 2021-04-27 09:54:40 --> Config Class Initialized
INFO - 2021-04-27 09:54:40 --> Hooks Class Initialized
DEBUG - 2021-04-27 09:54:40 --> UTF-8 Support Enabled
INFO - 2021-04-27 09:54:40 --> Utf8 Class Initialized
INFO - 2021-04-27 09:54:40 --> URI Class Initialized
INFO - 2021-04-27 09:54:40 --> Router Class Initialized
INFO - 2021-04-27 09:54:40 --> Output Class Initialized
INFO - 2021-04-27 09:54:40 --> Security Class Initialized
DEBUG - 2021-04-27 09:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 09:54:40 --> Input Class Initialized
INFO - 2021-04-27 09:54:40 --> Language Class Initialized
INFO - 2021-04-27 09:54:40 --> Language Class Initialized
INFO - 2021-04-27 09:54:40 --> Config Class Initialized
INFO - 2021-04-27 09:54:40 --> Loader Class Initialized
INFO - 2021-04-27 09:54:40 --> Helper loaded: url_helper
INFO - 2021-04-27 09:54:40 --> Helper loaded: file_helper
INFO - 2021-04-27 09:54:40 --> Helper loaded: form_helper
INFO - 2021-04-27 09:54:40 --> Helper loaded: my_helper
INFO - 2021-04-27 09:54:40 --> Database Driver Class Initialized
DEBUG - 2021-04-27 09:54:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 09:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 09:54:40 --> Controller Class Initialized
DEBUG - 2021-04-27 09:54:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-27 09:54:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 09:54:40 --> Final output sent to browser
DEBUG - 2021-04-27 09:54:40 --> Total execution time: 0.1187
INFO - 2021-04-27 09:54:52 --> Config Class Initialized
INFO - 2021-04-27 09:54:52 --> Hooks Class Initialized
DEBUG - 2021-04-27 09:54:52 --> UTF-8 Support Enabled
INFO - 2021-04-27 09:54:52 --> Utf8 Class Initialized
INFO - 2021-04-27 09:54:52 --> URI Class Initialized
INFO - 2021-04-27 09:54:52 --> Router Class Initialized
INFO - 2021-04-27 09:54:52 --> Output Class Initialized
INFO - 2021-04-27 09:54:52 --> Security Class Initialized
DEBUG - 2021-04-27 09:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 09:54:52 --> Input Class Initialized
INFO - 2021-04-27 09:54:52 --> Language Class Initialized
INFO - 2021-04-27 09:54:52 --> Language Class Initialized
INFO - 2021-04-27 09:54:52 --> Config Class Initialized
INFO - 2021-04-27 09:54:52 --> Loader Class Initialized
INFO - 2021-04-27 09:54:52 --> Helper loaded: url_helper
INFO - 2021-04-27 09:54:52 --> Helper loaded: file_helper
INFO - 2021-04-27 09:54:52 --> Helper loaded: form_helper
INFO - 2021-04-27 09:54:52 --> Helper loaded: my_helper
INFO - 2021-04-27 09:54:52 --> Database Driver Class Initialized
DEBUG - 2021-04-27 09:54:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 09:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 09:54:52 --> Controller Class Initialized
DEBUG - 2021-04-27 09:54:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-04-27 09:54:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 09:54:52 --> Final output sent to browser
DEBUG - 2021-04-27 09:54:52 --> Total execution time: 0.1469
INFO - 2021-04-27 10:00:45 --> Config Class Initialized
INFO - 2021-04-27 10:00:45 --> Hooks Class Initialized
DEBUG - 2021-04-27 10:00:45 --> UTF-8 Support Enabled
INFO - 2021-04-27 10:00:45 --> Utf8 Class Initialized
INFO - 2021-04-27 10:00:45 --> URI Class Initialized
INFO - 2021-04-27 10:00:45 --> Router Class Initialized
INFO - 2021-04-27 10:00:45 --> Output Class Initialized
INFO - 2021-04-27 10:00:45 --> Security Class Initialized
DEBUG - 2021-04-27 10:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 10:00:45 --> Input Class Initialized
INFO - 2021-04-27 10:00:45 --> Language Class Initialized
INFO - 2021-04-27 10:00:45 --> Language Class Initialized
INFO - 2021-04-27 10:00:45 --> Config Class Initialized
INFO - 2021-04-27 10:00:45 --> Loader Class Initialized
INFO - 2021-04-27 10:00:45 --> Helper loaded: url_helper
INFO - 2021-04-27 10:00:45 --> Helper loaded: file_helper
INFO - 2021-04-27 10:00:45 --> Helper loaded: form_helper
INFO - 2021-04-27 10:00:45 --> Helper loaded: my_helper
INFO - 2021-04-27 10:00:45 --> Database Driver Class Initialized
DEBUG - 2021-04-27 10:00:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 10:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 10:00:45 --> Controller Class Initialized
DEBUG - 2021-04-27 10:00:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-27 10:00:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 10:00:45 --> Final output sent to browser
DEBUG - 2021-04-27 10:00:45 --> Total execution time: 0.1436
INFO - 2021-04-27 10:03:06 --> Config Class Initialized
INFO - 2021-04-27 10:03:06 --> Hooks Class Initialized
DEBUG - 2021-04-27 10:03:06 --> UTF-8 Support Enabled
INFO - 2021-04-27 10:03:06 --> Utf8 Class Initialized
INFO - 2021-04-27 10:03:06 --> URI Class Initialized
INFO - 2021-04-27 10:03:06 --> Router Class Initialized
INFO - 2021-04-27 10:03:06 --> Output Class Initialized
INFO - 2021-04-27 10:03:06 --> Security Class Initialized
DEBUG - 2021-04-27 10:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 10:03:06 --> Input Class Initialized
INFO - 2021-04-27 10:03:06 --> Language Class Initialized
INFO - 2021-04-27 10:03:06 --> Language Class Initialized
INFO - 2021-04-27 10:03:06 --> Config Class Initialized
INFO - 2021-04-27 10:03:06 --> Loader Class Initialized
INFO - 2021-04-27 10:03:06 --> Helper loaded: url_helper
INFO - 2021-04-27 10:03:06 --> Helper loaded: file_helper
INFO - 2021-04-27 10:03:06 --> Helper loaded: form_helper
INFO - 2021-04-27 10:03:06 --> Helper loaded: my_helper
INFO - 2021-04-27 10:03:06 --> Database Driver Class Initialized
DEBUG - 2021-04-27 10:03:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 10:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 10:03:06 --> Controller Class Initialized
DEBUG - 2021-04-27 10:03:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-27 10:03:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 10:03:06 --> Final output sent to browser
DEBUG - 2021-04-27 10:03:06 --> Total execution time: 0.1777
INFO - 2021-04-27 10:41:54 --> Config Class Initialized
INFO - 2021-04-27 10:41:54 --> Hooks Class Initialized
DEBUG - 2021-04-27 10:41:54 --> UTF-8 Support Enabled
INFO - 2021-04-27 10:41:54 --> Utf8 Class Initialized
INFO - 2021-04-27 10:41:54 --> URI Class Initialized
INFO - 2021-04-27 10:41:54 --> Router Class Initialized
INFO - 2021-04-27 10:41:54 --> Output Class Initialized
INFO - 2021-04-27 10:41:54 --> Security Class Initialized
DEBUG - 2021-04-27 10:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 10:41:54 --> Input Class Initialized
INFO - 2021-04-27 10:41:54 --> Language Class Initialized
INFO - 2021-04-27 10:41:54 --> Language Class Initialized
INFO - 2021-04-27 10:41:54 --> Config Class Initialized
INFO - 2021-04-27 10:41:54 --> Loader Class Initialized
INFO - 2021-04-27 10:41:54 --> Helper loaded: url_helper
INFO - 2021-04-27 10:41:54 --> Helper loaded: file_helper
INFO - 2021-04-27 10:41:54 --> Helper loaded: form_helper
INFO - 2021-04-27 10:41:54 --> Helper loaded: my_helper
INFO - 2021-04-27 10:41:54 --> Database Driver Class Initialized
DEBUG - 2021-04-27 10:41:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 10:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 10:41:54 --> Controller Class Initialized
DEBUG - 2021-04-27 10:41:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-27 10:41:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 10:41:54 --> Final output sent to browser
DEBUG - 2021-04-27 10:41:54 --> Total execution time: 0.1109
INFO - 2021-04-27 10:42:02 --> Config Class Initialized
INFO - 2021-04-27 10:42:02 --> Hooks Class Initialized
DEBUG - 2021-04-27 10:42:02 --> UTF-8 Support Enabled
INFO - 2021-04-27 10:42:02 --> Utf8 Class Initialized
INFO - 2021-04-27 10:42:02 --> URI Class Initialized
INFO - 2021-04-27 10:42:02 --> Router Class Initialized
INFO - 2021-04-27 10:42:02 --> Output Class Initialized
INFO - 2021-04-27 10:42:02 --> Security Class Initialized
DEBUG - 2021-04-27 10:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 10:42:02 --> Input Class Initialized
INFO - 2021-04-27 10:42:02 --> Language Class Initialized
INFO - 2021-04-27 10:42:02 --> Language Class Initialized
INFO - 2021-04-27 10:42:02 --> Config Class Initialized
INFO - 2021-04-27 10:42:02 --> Loader Class Initialized
INFO - 2021-04-27 10:42:02 --> Helper loaded: url_helper
INFO - 2021-04-27 10:42:02 --> Helper loaded: file_helper
INFO - 2021-04-27 10:42:02 --> Helper loaded: form_helper
INFO - 2021-04-27 10:42:02 --> Helper loaded: my_helper
INFO - 2021-04-27 10:42:02 --> Database Driver Class Initialized
DEBUG - 2021-04-27 10:42:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 10:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 10:42:02 --> Controller Class Initialized
DEBUG - 2021-04-27 10:42:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-27 10:42:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 10:42:02 --> Final output sent to browser
DEBUG - 2021-04-27 10:42:02 --> Total execution time: 0.1281
INFO - 2021-04-27 10:42:04 --> Config Class Initialized
INFO - 2021-04-27 10:42:04 --> Hooks Class Initialized
DEBUG - 2021-04-27 10:42:04 --> UTF-8 Support Enabled
INFO - 2021-04-27 10:42:04 --> Utf8 Class Initialized
INFO - 2021-04-27 10:42:04 --> URI Class Initialized
DEBUG - 2021-04-27 10:42:04 --> No URI present. Default controller set.
INFO - 2021-04-27 10:42:04 --> Router Class Initialized
INFO - 2021-04-27 10:42:04 --> Output Class Initialized
INFO - 2021-04-27 10:42:04 --> Security Class Initialized
DEBUG - 2021-04-27 10:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 10:42:04 --> Input Class Initialized
INFO - 2021-04-27 10:42:04 --> Language Class Initialized
INFO - 2021-04-27 10:42:04 --> Language Class Initialized
INFO - 2021-04-27 10:42:04 --> Config Class Initialized
INFO - 2021-04-27 10:42:04 --> Loader Class Initialized
INFO - 2021-04-27 10:42:04 --> Helper loaded: url_helper
INFO - 2021-04-27 10:42:04 --> Helper loaded: file_helper
INFO - 2021-04-27 10:42:04 --> Helper loaded: form_helper
INFO - 2021-04-27 10:42:04 --> Helper loaded: my_helper
INFO - 2021-04-27 10:42:04 --> Database Driver Class Initialized
DEBUG - 2021-04-27 10:42:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 10:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 10:42:04 --> Controller Class Initialized
INFO - 2021-04-27 10:42:04 --> Config Class Initialized
INFO - 2021-04-27 10:42:04 --> Hooks Class Initialized
DEBUG - 2021-04-27 10:42:04 --> UTF-8 Support Enabled
INFO - 2021-04-27 10:42:04 --> Utf8 Class Initialized
INFO - 2021-04-27 10:42:04 --> URI Class Initialized
INFO - 2021-04-27 10:42:04 --> Router Class Initialized
INFO - 2021-04-27 10:42:04 --> Output Class Initialized
INFO - 2021-04-27 10:42:04 --> Security Class Initialized
DEBUG - 2021-04-27 10:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 10:42:04 --> Input Class Initialized
INFO - 2021-04-27 10:42:04 --> Language Class Initialized
INFO - 2021-04-27 10:42:04 --> Language Class Initialized
INFO - 2021-04-27 10:42:04 --> Config Class Initialized
INFO - 2021-04-27 10:42:04 --> Loader Class Initialized
INFO - 2021-04-27 10:42:04 --> Helper loaded: url_helper
INFO - 2021-04-27 10:42:04 --> Helper loaded: file_helper
INFO - 2021-04-27 10:42:04 --> Helper loaded: form_helper
INFO - 2021-04-27 10:42:04 --> Helper loaded: my_helper
INFO - 2021-04-27 10:42:04 --> Database Driver Class Initialized
DEBUG - 2021-04-27 10:42:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 10:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 10:42:04 --> Controller Class Initialized
DEBUG - 2021-04-27 10:42:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-04-27 10:42:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 10:42:04 --> Final output sent to browser
DEBUG - 2021-04-27 10:42:04 --> Total execution time: 0.1742
INFO - 2021-04-27 10:42:13 --> Config Class Initialized
INFO - 2021-04-27 10:42:13 --> Hooks Class Initialized
DEBUG - 2021-04-27 10:42:13 --> UTF-8 Support Enabled
INFO - 2021-04-27 10:42:13 --> Utf8 Class Initialized
INFO - 2021-04-27 10:42:13 --> URI Class Initialized
INFO - 2021-04-27 10:42:13 --> Router Class Initialized
INFO - 2021-04-27 10:42:13 --> Output Class Initialized
INFO - 2021-04-27 10:42:13 --> Security Class Initialized
DEBUG - 2021-04-27 10:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 10:42:13 --> Input Class Initialized
INFO - 2021-04-27 10:42:13 --> Language Class Initialized
INFO - 2021-04-27 10:42:13 --> Language Class Initialized
INFO - 2021-04-27 10:42:13 --> Config Class Initialized
INFO - 2021-04-27 10:42:13 --> Loader Class Initialized
INFO - 2021-04-27 10:42:13 --> Helper loaded: url_helper
INFO - 2021-04-27 10:42:13 --> Helper loaded: file_helper
INFO - 2021-04-27 10:42:13 --> Helper loaded: form_helper
INFO - 2021-04-27 10:42:13 --> Helper loaded: my_helper
INFO - 2021-04-27 10:42:13 --> Database Driver Class Initialized
DEBUG - 2021-04-27 10:42:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 10:42:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 10:42:13 --> Controller Class Initialized
INFO - 2021-04-27 10:42:13 --> Helper loaded: cookie_helper
INFO - 2021-04-27 10:42:13 --> Final output sent to browser
DEBUG - 2021-04-27 10:42:13 --> Total execution time: 0.1462
INFO - 2021-04-27 10:42:13 --> Config Class Initialized
INFO - 2021-04-27 10:42:13 --> Hooks Class Initialized
DEBUG - 2021-04-27 10:42:13 --> UTF-8 Support Enabled
INFO - 2021-04-27 10:42:13 --> Utf8 Class Initialized
INFO - 2021-04-27 10:42:13 --> URI Class Initialized
INFO - 2021-04-27 10:42:13 --> Router Class Initialized
INFO - 2021-04-27 10:42:13 --> Output Class Initialized
INFO - 2021-04-27 10:42:13 --> Security Class Initialized
DEBUG - 2021-04-27 10:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 10:42:13 --> Input Class Initialized
INFO - 2021-04-27 10:42:13 --> Language Class Initialized
INFO - 2021-04-27 10:42:13 --> Language Class Initialized
INFO - 2021-04-27 10:42:13 --> Config Class Initialized
INFO - 2021-04-27 10:42:13 --> Loader Class Initialized
INFO - 2021-04-27 10:42:13 --> Helper loaded: url_helper
INFO - 2021-04-27 10:42:13 --> Helper loaded: file_helper
INFO - 2021-04-27 10:42:13 --> Helper loaded: form_helper
INFO - 2021-04-27 10:42:14 --> Helper loaded: my_helper
INFO - 2021-04-27 10:42:14 --> Database Driver Class Initialized
DEBUG - 2021-04-27 10:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 10:42:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 10:42:14 --> Controller Class Initialized
DEBUG - 2021-04-27 10:42:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-04-27 10:42:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 10:42:14 --> Final output sent to browser
DEBUG - 2021-04-27 10:42:14 --> Total execution time: 0.1306
INFO - 2021-04-27 10:42:16 --> Config Class Initialized
INFO - 2021-04-27 10:42:17 --> Hooks Class Initialized
DEBUG - 2021-04-27 10:42:17 --> UTF-8 Support Enabled
INFO - 2021-04-27 10:42:17 --> Utf8 Class Initialized
INFO - 2021-04-27 10:42:17 --> URI Class Initialized
INFO - 2021-04-27 10:42:17 --> Router Class Initialized
INFO - 2021-04-27 10:42:17 --> Output Class Initialized
INFO - 2021-04-27 10:42:17 --> Security Class Initialized
DEBUG - 2021-04-27 10:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 10:42:17 --> Input Class Initialized
INFO - 2021-04-27 10:42:17 --> Language Class Initialized
INFO - 2021-04-27 10:42:17 --> Language Class Initialized
INFO - 2021-04-27 10:42:17 --> Config Class Initialized
INFO - 2021-04-27 10:42:17 --> Loader Class Initialized
INFO - 2021-04-27 10:42:17 --> Helper loaded: url_helper
INFO - 2021-04-27 10:42:17 --> Helper loaded: file_helper
INFO - 2021-04-27 10:42:17 --> Helper loaded: form_helper
INFO - 2021-04-27 10:42:17 --> Helper loaded: my_helper
INFO - 2021-04-27 10:42:17 --> Database Driver Class Initialized
DEBUG - 2021-04-27 10:42:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 10:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 10:42:17 --> Controller Class Initialized
DEBUG - 2021-04-27 10:42:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-27 10:42:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 10:42:17 --> Final output sent to browser
DEBUG - 2021-04-27 10:42:17 --> Total execution time: 0.1161
INFO - 2021-04-27 10:42:46 --> Config Class Initialized
INFO - 2021-04-27 10:42:46 --> Hooks Class Initialized
DEBUG - 2021-04-27 10:42:46 --> UTF-8 Support Enabled
INFO - 2021-04-27 10:42:46 --> Utf8 Class Initialized
INFO - 2021-04-27 10:42:46 --> URI Class Initialized
INFO - 2021-04-27 10:42:46 --> Router Class Initialized
INFO - 2021-04-27 10:42:46 --> Output Class Initialized
INFO - 2021-04-27 10:42:46 --> Security Class Initialized
DEBUG - 2021-04-27 10:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 10:42:46 --> Input Class Initialized
INFO - 2021-04-27 10:42:46 --> Language Class Initialized
INFO - 2021-04-27 10:42:46 --> Language Class Initialized
INFO - 2021-04-27 10:42:46 --> Config Class Initialized
INFO - 2021-04-27 10:42:46 --> Loader Class Initialized
INFO - 2021-04-27 10:42:46 --> Helper loaded: url_helper
INFO - 2021-04-27 10:42:46 --> Helper loaded: file_helper
INFO - 2021-04-27 10:42:46 --> Helper loaded: form_helper
INFO - 2021-04-27 10:42:46 --> Helper loaded: my_helper
INFO - 2021-04-27 10:42:46 --> Database Driver Class Initialized
DEBUG - 2021-04-27 10:42:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 10:42:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 10:42:46 --> Controller Class Initialized
DEBUG - 2021-04-27 10:42:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-27 10:42:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 10:42:46 --> Final output sent to browser
DEBUG - 2021-04-27 10:42:46 --> Total execution time: 0.1396
INFO - 2021-04-27 10:42:47 --> Config Class Initialized
INFO - 2021-04-27 10:42:47 --> Hooks Class Initialized
DEBUG - 2021-04-27 10:42:47 --> UTF-8 Support Enabled
INFO - 2021-04-27 10:42:47 --> Utf8 Class Initialized
INFO - 2021-04-27 10:42:47 --> URI Class Initialized
INFO - 2021-04-27 10:42:47 --> Router Class Initialized
INFO - 2021-04-27 10:42:47 --> Output Class Initialized
INFO - 2021-04-27 10:42:47 --> Security Class Initialized
DEBUG - 2021-04-27 10:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 10:42:47 --> Input Class Initialized
INFO - 2021-04-27 10:42:47 --> Language Class Initialized
INFO - 2021-04-27 10:42:47 --> Language Class Initialized
INFO - 2021-04-27 10:42:47 --> Config Class Initialized
INFO - 2021-04-27 10:42:47 --> Loader Class Initialized
INFO - 2021-04-27 10:42:47 --> Helper loaded: url_helper
INFO - 2021-04-27 10:42:47 --> Helper loaded: file_helper
INFO - 2021-04-27 10:42:47 --> Helper loaded: form_helper
INFO - 2021-04-27 10:42:47 --> Helper loaded: my_helper
INFO - 2021-04-27 10:42:47 --> Database Driver Class Initialized
DEBUG - 2021-04-27 10:42:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 10:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 10:42:47 --> Controller Class Initialized
DEBUG - 2021-04-27 10:42:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-27 10:42:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 10:42:47 --> Final output sent to browser
DEBUG - 2021-04-27 10:42:47 --> Total execution time: 0.1337
INFO - 2021-04-27 10:42:48 --> Config Class Initialized
INFO - 2021-04-27 10:42:48 --> Hooks Class Initialized
DEBUG - 2021-04-27 10:42:48 --> UTF-8 Support Enabled
INFO - 2021-04-27 10:42:48 --> Utf8 Class Initialized
INFO - 2021-04-27 10:42:48 --> URI Class Initialized
INFO - 2021-04-27 10:42:48 --> Router Class Initialized
INFO - 2021-04-27 10:42:48 --> Output Class Initialized
INFO - 2021-04-27 10:42:48 --> Security Class Initialized
DEBUG - 2021-04-27 10:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 10:42:48 --> Input Class Initialized
INFO - 2021-04-27 10:42:48 --> Language Class Initialized
INFO - 2021-04-27 10:42:48 --> Language Class Initialized
INFO - 2021-04-27 10:42:48 --> Config Class Initialized
INFO - 2021-04-27 10:42:48 --> Loader Class Initialized
INFO - 2021-04-27 10:42:48 --> Helper loaded: url_helper
INFO - 2021-04-27 10:42:48 --> Helper loaded: file_helper
INFO - 2021-04-27 10:42:48 --> Helper loaded: form_helper
INFO - 2021-04-27 10:42:48 --> Helper loaded: my_helper
INFO - 2021-04-27 10:42:48 --> Database Driver Class Initialized
DEBUG - 2021-04-27 10:42:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 10:42:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 10:42:48 --> Controller Class Initialized
DEBUG - 2021-04-27 10:42:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-27 10:42:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 10:42:48 --> Final output sent to browser
DEBUG - 2021-04-27 10:42:48 --> Total execution time: 0.1541
INFO - 2021-04-27 10:42:49 --> Config Class Initialized
INFO - 2021-04-27 10:42:49 --> Hooks Class Initialized
DEBUG - 2021-04-27 10:42:49 --> UTF-8 Support Enabled
INFO - 2021-04-27 10:42:49 --> Utf8 Class Initialized
INFO - 2021-04-27 10:42:49 --> URI Class Initialized
INFO - 2021-04-27 10:42:49 --> Router Class Initialized
INFO - 2021-04-27 10:42:49 --> Output Class Initialized
INFO - 2021-04-27 10:42:49 --> Security Class Initialized
DEBUG - 2021-04-27 10:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 10:42:49 --> Input Class Initialized
INFO - 2021-04-27 10:42:49 --> Language Class Initialized
INFO - 2021-04-27 10:42:49 --> Language Class Initialized
INFO - 2021-04-27 10:42:49 --> Config Class Initialized
INFO - 2021-04-27 10:42:49 --> Loader Class Initialized
INFO - 2021-04-27 10:42:49 --> Helper loaded: url_helper
INFO - 2021-04-27 10:42:49 --> Helper loaded: file_helper
INFO - 2021-04-27 10:42:49 --> Helper loaded: form_helper
INFO - 2021-04-27 10:42:49 --> Helper loaded: my_helper
INFO - 2021-04-27 10:42:49 --> Database Driver Class Initialized
DEBUG - 2021-04-27 10:42:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 10:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 10:42:49 --> Controller Class Initialized
DEBUG - 2021-04-27 10:42:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-27 10:42:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 10:42:49 --> Final output sent to browser
DEBUG - 2021-04-27 10:42:49 --> Total execution time: 0.1011
INFO - 2021-04-27 10:46:24 --> Config Class Initialized
INFO - 2021-04-27 10:46:24 --> Hooks Class Initialized
DEBUG - 2021-04-27 10:46:24 --> UTF-8 Support Enabled
INFO - 2021-04-27 10:46:24 --> Utf8 Class Initialized
INFO - 2021-04-27 10:46:24 --> URI Class Initialized
INFO - 2021-04-27 10:46:24 --> Router Class Initialized
INFO - 2021-04-27 10:46:24 --> Output Class Initialized
INFO - 2021-04-27 10:46:24 --> Security Class Initialized
DEBUG - 2021-04-27 10:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 10:46:24 --> Input Class Initialized
INFO - 2021-04-27 10:46:24 --> Language Class Initialized
INFO - 2021-04-27 10:46:24 --> Language Class Initialized
INFO - 2021-04-27 10:46:24 --> Config Class Initialized
INFO - 2021-04-27 10:46:24 --> Loader Class Initialized
INFO - 2021-04-27 10:46:24 --> Helper loaded: url_helper
INFO - 2021-04-27 10:46:24 --> Helper loaded: file_helper
INFO - 2021-04-27 10:46:24 --> Helper loaded: form_helper
INFO - 2021-04-27 10:46:24 --> Helper loaded: my_helper
INFO - 2021-04-27 10:46:24 --> Database Driver Class Initialized
DEBUG - 2021-04-27 10:46:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 10:46:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 10:46:24 --> Controller Class Initialized
DEBUG - 2021-04-27 10:46:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-27 10:46:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 10:46:24 --> Final output sent to browser
DEBUG - 2021-04-27 10:46:24 --> Total execution time: 0.1223
INFO - 2021-04-27 10:46:25 --> Config Class Initialized
INFO - 2021-04-27 10:46:25 --> Hooks Class Initialized
DEBUG - 2021-04-27 10:46:25 --> UTF-8 Support Enabled
INFO - 2021-04-27 10:46:25 --> Utf8 Class Initialized
INFO - 2021-04-27 10:46:25 --> URI Class Initialized
INFO - 2021-04-27 10:46:25 --> Router Class Initialized
INFO - 2021-04-27 10:46:25 --> Output Class Initialized
INFO - 2021-04-27 10:46:25 --> Security Class Initialized
DEBUG - 2021-04-27 10:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-27 10:46:25 --> Input Class Initialized
INFO - 2021-04-27 10:46:25 --> Language Class Initialized
INFO - 2021-04-27 10:46:25 --> Language Class Initialized
INFO - 2021-04-27 10:46:25 --> Config Class Initialized
INFO - 2021-04-27 10:46:25 --> Loader Class Initialized
INFO - 2021-04-27 10:46:25 --> Helper loaded: url_helper
INFO - 2021-04-27 10:46:25 --> Helper loaded: file_helper
INFO - 2021-04-27 10:46:25 --> Helper loaded: form_helper
INFO - 2021-04-27 10:46:25 --> Helper loaded: my_helper
INFO - 2021-04-27 10:46:25 --> Database Driver Class Initialized
DEBUG - 2021-04-27 10:46:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-27 10:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-27 10:46:25 --> Controller Class Initialized
DEBUG - 2021-04-27 10:46:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-27 10:46:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-27 10:46:25 --> Final output sent to browser
DEBUG - 2021-04-27 10:46:25 --> Total execution time: 0.1114
