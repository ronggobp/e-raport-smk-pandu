<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-02-23 06:13:25 --> Config Class Initialized
INFO - 2022-02-23 06:13:25 --> Hooks Class Initialized
DEBUG - 2022-02-23 06:13:25 --> UTF-8 Support Enabled
INFO - 2022-02-23 06:13:25 --> Utf8 Class Initialized
INFO - 2022-02-23 06:13:25 --> URI Class Initialized
DEBUG - 2022-02-23 06:13:25 --> No URI present. Default controller set.
INFO - 2022-02-23 06:13:25 --> Router Class Initialized
INFO - 2022-02-23 06:13:25 --> Output Class Initialized
INFO - 2022-02-23 06:13:25 --> Security Class Initialized
DEBUG - 2022-02-23 06:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-23 06:13:26 --> Input Class Initialized
INFO - 2022-02-23 06:13:26 --> Language Class Initialized
INFO - 2022-02-23 06:13:26 --> Language Class Initialized
INFO - 2022-02-23 06:13:26 --> Config Class Initialized
INFO - 2022-02-23 06:13:26 --> Loader Class Initialized
INFO - 2022-02-23 06:13:26 --> Helper loaded: url_helper
INFO - 2022-02-23 06:13:26 --> Helper loaded: file_helper
INFO - 2022-02-23 06:13:26 --> Helper loaded: form_helper
INFO - 2022-02-23 06:13:26 --> Helper loaded: my_helper
INFO - 2022-02-23 06:13:26 --> Database Driver Class Initialized
DEBUG - 2022-02-23 06:13:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-23 06:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-23 06:13:26 --> Controller Class Initialized
INFO - 2022-02-23 06:13:26 --> Config Class Initialized
INFO - 2022-02-23 06:13:26 --> Hooks Class Initialized
DEBUG - 2022-02-23 06:13:26 --> UTF-8 Support Enabled
INFO - 2022-02-23 06:13:26 --> Utf8 Class Initialized
INFO - 2022-02-23 06:13:26 --> URI Class Initialized
INFO - 2022-02-23 06:13:26 --> Router Class Initialized
INFO - 2022-02-23 06:13:26 --> Output Class Initialized
INFO - 2022-02-23 06:13:26 --> Security Class Initialized
DEBUG - 2022-02-23 06:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-23 06:13:26 --> Input Class Initialized
INFO - 2022-02-23 06:13:26 --> Language Class Initialized
INFO - 2022-02-23 06:13:26 --> Language Class Initialized
INFO - 2022-02-23 06:13:26 --> Config Class Initialized
INFO - 2022-02-23 06:13:26 --> Loader Class Initialized
INFO - 2022-02-23 06:13:26 --> Helper loaded: url_helper
INFO - 2022-02-23 06:13:26 --> Helper loaded: file_helper
INFO - 2022-02-23 06:13:26 --> Helper loaded: form_helper
INFO - 2022-02-23 06:13:26 --> Helper loaded: my_helper
INFO - 2022-02-23 06:13:26 --> Database Driver Class Initialized
DEBUG - 2022-02-23 06:13:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-23 06:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-23 06:13:26 --> Controller Class Initialized
DEBUG - 2022-02-23 06:13:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-02-23 06:13:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-02-23 06:13:26 --> Final output sent to browser
DEBUG - 2022-02-23 06:13:26 --> Total execution time: 0.1086
INFO - 2022-02-23 06:13:45 --> Config Class Initialized
INFO - 2022-02-23 06:13:45 --> Hooks Class Initialized
DEBUG - 2022-02-23 06:13:45 --> UTF-8 Support Enabled
INFO - 2022-02-23 06:13:45 --> Utf8 Class Initialized
INFO - 2022-02-23 06:13:45 --> URI Class Initialized
INFO - 2022-02-23 06:13:45 --> Router Class Initialized
INFO - 2022-02-23 06:13:45 --> Output Class Initialized
INFO - 2022-02-23 06:13:45 --> Security Class Initialized
DEBUG - 2022-02-23 06:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-23 06:13:45 --> Input Class Initialized
INFO - 2022-02-23 06:13:45 --> Language Class Initialized
INFO - 2022-02-23 06:13:45 --> Language Class Initialized
INFO - 2022-02-23 06:13:45 --> Config Class Initialized
INFO - 2022-02-23 06:13:45 --> Loader Class Initialized
INFO - 2022-02-23 06:13:45 --> Helper loaded: url_helper
INFO - 2022-02-23 06:13:45 --> Helper loaded: file_helper
INFO - 2022-02-23 06:13:45 --> Helper loaded: form_helper
INFO - 2022-02-23 06:13:45 --> Helper loaded: my_helper
INFO - 2022-02-23 06:13:45 --> Database Driver Class Initialized
DEBUG - 2022-02-23 06:13:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-23 06:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-23 06:13:45 --> Controller Class Initialized
INFO - 2022-02-23 06:13:45 --> Helper loaded: cookie_helper
INFO - 2022-02-23 06:13:45 --> Final output sent to browser
DEBUG - 2022-02-23 06:13:45 --> Total execution time: 0.1371
INFO - 2022-02-23 06:13:46 --> Config Class Initialized
INFO - 2022-02-23 06:13:46 --> Hooks Class Initialized
DEBUG - 2022-02-23 06:13:46 --> UTF-8 Support Enabled
INFO - 2022-02-23 06:13:46 --> Utf8 Class Initialized
INFO - 2022-02-23 06:13:46 --> URI Class Initialized
INFO - 2022-02-23 06:13:46 --> Router Class Initialized
INFO - 2022-02-23 06:13:46 --> Output Class Initialized
INFO - 2022-02-23 06:13:46 --> Security Class Initialized
DEBUG - 2022-02-23 06:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-23 06:13:46 --> Input Class Initialized
INFO - 2022-02-23 06:13:46 --> Language Class Initialized
INFO - 2022-02-23 06:13:46 --> Language Class Initialized
INFO - 2022-02-23 06:13:46 --> Config Class Initialized
INFO - 2022-02-23 06:13:46 --> Loader Class Initialized
INFO - 2022-02-23 06:13:46 --> Helper loaded: url_helper
INFO - 2022-02-23 06:13:46 --> Helper loaded: file_helper
INFO - 2022-02-23 06:13:46 --> Helper loaded: form_helper
INFO - 2022-02-23 06:13:46 --> Helper loaded: my_helper
INFO - 2022-02-23 06:13:46 --> Database Driver Class Initialized
DEBUG - 2022-02-23 06:13:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-23 06:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-23 06:13:46 --> Controller Class Initialized
DEBUG - 2022-02-23 06:13:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-02-23 06:13:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-02-23 06:13:47 --> Final output sent to browser
DEBUG - 2022-02-23 06:13:47 --> Total execution time: 1.1073
INFO - 2022-02-23 06:14:25 --> Config Class Initialized
INFO - 2022-02-23 06:14:25 --> Hooks Class Initialized
DEBUG - 2022-02-23 06:14:25 --> UTF-8 Support Enabled
INFO - 2022-02-23 06:14:25 --> Utf8 Class Initialized
INFO - 2022-02-23 06:14:25 --> URI Class Initialized
INFO - 2022-02-23 06:14:25 --> Router Class Initialized
INFO - 2022-02-23 06:14:25 --> Output Class Initialized
INFO - 2022-02-23 06:14:25 --> Security Class Initialized
DEBUG - 2022-02-23 06:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-23 06:14:25 --> Input Class Initialized
INFO - 2022-02-23 06:14:25 --> Language Class Initialized
INFO - 2022-02-23 06:14:25 --> Language Class Initialized
INFO - 2022-02-23 06:14:25 --> Config Class Initialized
INFO - 2022-02-23 06:14:25 --> Loader Class Initialized
INFO - 2022-02-23 06:14:25 --> Helper loaded: url_helper
INFO - 2022-02-23 06:14:25 --> Helper loaded: file_helper
INFO - 2022-02-23 06:14:25 --> Helper loaded: form_helper
INFO - 2022-02-23 06:14:25 --> Helper loaded: my_helper
INFO - 2022-02-23 06:14:25 --> Database Driver Class Initialized
DEBUG - 2022-02-23 06:14:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-23 06:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-23 06:14:25 --> Controller Class Initialized
INFO - 2022-02-23 06:14:25 --> Helper loaded: cookie_helper
INFO - 2022-02-23 06:14:25 --> Config Class Initialized
INFO - 2022-02-23 06:14:25 --> Hooks Class Initialized
DEBUG - 2022-02-23 06:14:25 --> UTF-8 Support Enabled
INFO - 2022-02-23 06:14:25 --> Utf8 Class Initialized
INFO - 2022-02-23 06:14:25 --> URI Class Initialized
INFO - 2022-02-23 06:14:25 --> Router Class Initialized
INFO - 2022-02-23 06:14:25 --> Output Class Initialized
INFO - 2022-02-23 06:14:25 --> Security Class Initialized
DEBUG - 2022-02-23 06:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-23 06:14:25 --> Input Class Initialized
INFO - 2022-02-23 06:14:25 --> Language Class Initialized
INFO - 2022-02-23 06:14:25 --> Language Class Initialized
INFO - 2022-02-23 06:14:25 --> Config Class Initialized
INFO - 2022-02-23 06:14:25 --> Loader Class Initialized
INFO - 2022-02-23 06:14:25 --> Helper loaded: url_helper
INFO - 2022-02-23 06:14:25 --> Helper loaded: file_helper
INFO - 2022-02-23 06:14:25 --> Helper loaded: form_helper
INFO - 2022-02-23 06:14:25 --> Helper loaded: my_helper
INFO - 2022-02-23 06:14:25 --> Database Driver Class Initialized
DEBUG - 2022-02-23 06:14:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-23 06:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-23 06:14:25 --> Controller Class Initialized
DEBUG - 2022-02-23 06:14:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-02-23 06:14:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-02-23 06:14:25 --> Final output sent to browser
DEBUG - 2022-02-23 06:14:25 --> Total execution time: 0.0622
INFO - 2022-02-23 06:14:33 --> Config Class Initialized
INFO - 2022-02-23 06:14:33 --> Hooks Class Initialized
DEBUG - 2022-02-23 06:14:33 --> UTF-8 Support Enabled
INFO - 2022-02-23 06:14:33 --> Utf8 Class Initialized
INFO - 2022-02-23 06:14:33 --> URI Class Initialized
INFO - 2022-02-23 06:14:33 --> Router Class Initialized
INFO - 2022-02-23 06:14:33 --> Output Class Initialized
INFO - 2022-02-23 06:14:33 --> Security Class Initialized
DEBUG - 2022-02-23 06:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-23 06:14:33 --> Input Class Initialized
INFO - 2022-02-23 06:14:33 --> Language Class Initialized
INFO - 2022-02-23 06:14:33 --> Language Class Initialized
INFO - 2022-02-23 06:14:33 --> Config Class Initialized
INFO - 2022-02-23 06:14:33 --> Loader Class Initialized
INFO - 2022-02-23 06:14:33 --> Helper loaded: url_helper
INFO - 2022-02-23 06:14:33 --> Helper loaded: file_helper
INFO - 2022-02-23 06:14:33 --> Helper loaded: form_helper
INFO - 2022-02-23 06:14:33 --> Helper loaded: my_helper
INFO - 2022-02-23 06:14:33 --> Database Driver Class Initialized
DEBUG - 2022-02-23 06:14:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-23 06:14:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-23 06:14:33 --> Controller Class Initialized
INFO - 2022-02-23 06:14:33 --> Helper loaded: cookie_helper
INFO - 2022-02-23 06:14:33 --> Final output sent to browser
DEBUG - 2022-02-23 06:14:33 --> Total execution time: 0.0849
INFO - 2022-02-23 06:14:33 --> Config Class Initialized
INFO - 2022-02-23 06:14:33 --> Hooks Class Initialized
DEBUG - 2022-02-23 06:14:33 --> UTF-8 Support Enabled
INFO - 2022-02-23 06:14:33 --> Utf8 Class Initialized
INFO - 2022-02-23 06:14:33 --> URI Class Initialized
INFO - 2022-02-23 06:14:33 --> Router Class Initialized
INFO - 2022-02-23 06:14:33 --> Output Class Initialized
INFO - 2022-02-23 06:14:33 --> Security Class Initialized
DEBUG - 2022-02-23 06:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-23 06:14:33 --> Input Class Initialized
INFO - 2022-02-23 06:14:33 --> Language Class Initialized
INFO - 2022-02-23 06:14:33 --> Language Class Initialized
INFO - 2022-02-23 06:14:33 --> Config Class Initialized
INFO - 2022-02-23 06:14:33 --> Loader Class Initialized
INFO - 2022-02-23 06:14:33 --> Helper loaded: url_helper
INFO - 2022-02-23 06:14:33 --> Helper loaded: file_helper
INFO - 2022-02-23 06:14:33 --> Helper loaded: form_helper
INFO - 2022-02-23 06:14:33 --> Helper loaded: my_helper
INFO - 2022-02-23 06:14:33 --> Database Driver Class Initialized
DEBUG - 2022-02-23 06:14:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-23 06:14:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-23 06:14:33 --> Controller Class Initialized
DEBUG - 2022-02-23 06:14:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-02-23 06:14:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-02-23 06:14:34 --> Final output sent to browser
DEBUG - 2022-02-23 06:14:34 --> Total execution time: 0.9627
INFO - 2022-02-23 06:14:38 --> Config Class Initialized
INFO - 2022-02-23 06:14:38 --> Hooks Class Initialized
DEBUG - 2022-02-23 06:14:38 --> UTF-8 Support Enabled
INFO - 2022-02-23 06:14:38 --> Utf8 Class Initialized
INFO - 2022-02-23 06:14:38 --> URI Class Initialized
INFO - 2022-02-23 06:14:38 --> Router Class Initialized
INFO - 2022-02-23 06:14:38 --> Output Class Initialized
INFO - 2022-02-23 06:14:38 --> Security Class Initialized
DEBUG - 2022-02-23 06:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-23 06:14:38 --> Input Class Initialized
INFO - 2022-02-23 06:14:38 --> Language Class Initialized
INFO - 2022-02-23 06:14:38 --> Language Class Initialized
INFO - 2022-02-23 06:14:38 --> Config Class Initialized
INFO - 2022-02-23 06:14:38 --> Loader Class Initialized
INFO - 2022-02-23 06:14:38 --> Helper loaded: url_helper
INFO - 2022-02-23 06:14:38 --> Helper loaded: file_helper
INFO - 2022-02-23 06:14:38 --> Helper loaded: form_helper
INFO - 2022-02-23 06:14:38 --> Helper loaded: my_helper
INFO - 2022-02-23 06:14:38 --> Database Driver Class Initialized
DEBUG - 2022-02-23 06:14:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-23 06:14:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-23 06:14:38 --> Controller Class Initialized
DEBUG - 2022-02-23 06:14:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2022-02-23 06:14:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-02-23 06:14:38 --> Final output sent to browser
DEBUG - 2022-02-23 06:14:38 --> Total execution time: 0.1499
INFO - 2022-02-23 06:14:41 --> Config Class Initialized
INFO - 2022-02-23 06:14:41 --> Hooks Class Initialized
DEBUG - 2022-02-23 06:14:41 --> UTF-8 Support Enabled
INFO - 2022-02-23 06:14:41 --> Utf8 Class Initialized
INFO - 2022-02-23 06:14:41 --> URI Class Initialized
INFO - 2022-02-23 06:14:41 --> Router Class Initialized
INFO - 2022-02-23 06:14:41 --> Output Class Initialized
INFO - 2022-02-23 06:14:41 --> Security Class Initialized
DEBUG - 2022-02-23 06:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-23 06:14:41 --> Input Class Initialized
INFO - 2022-02-23 06:14:41 --> Language Class Initialized
INFO - 2022-02-23 06:14:42 --> Language Class Initialized
INFO - 2022-02-23 06:14:42 --> Config Class Initialized
INFO - 2022-02-23 06:14:42 --> Loader Class Initialized
INFO - 2022-02-23 06:14:42 --> Helper loaded: url_helper
INFO - 2022-02-23 06:14:42 --> Helper loaded: file_helper
INFO - 2022-02-23 06:14:42 --> Helper loaded: form_helper
INFO - 2022-02-23 06:14:42 --> Helper loaded: my_helper
INFO - 2022-02-23 06:14:42 --> Database Driver Class Initialized
DEBUG - 2022-02-23 06:14:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-23 06:14:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-23 06:14:42 --> Controller Class Initialized
DEBUG - 2022-02-23 06:14:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2022-02-23 06:14:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-02-23 06:14:42 --> Final output sent to browser
DEBUG - 2022-02-23 06:14:42 --> Total execution time: 0.0946
INFO - 2022-02-23 06:14:42 --> Config Class Initialized
INFO - 2022-02-23 06:14:42 --> Hooks Class Initialized
DEBUG - 2022-02-23 06:14:42 --> UTF-8 Support Enabled
INFO - 2022-02-23 06:14:42 --> Utf8 Class Initialized
INFO - 2022-02-23 06:14:42 --> URI Class Initialized
INFO - 2022-02-23 06:14:42 --> Router Class Initialized
INFO - 2022-02-23 06:14:42 --> Output Class Initialized
INFO - 2022-02-23 06:14:42 --> Security Class Initialized
DEBUG - 2022-02-23 06:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-23 06:14:42 --> Input Class Initialized
INFO - 2022-02-23 06:14:42 --> Language Class Initialized
INFO - 2022-02-23 06:14:42 --> Language Class Initialized
INFO - 2022-02-23 06:14:42 --> Config Class Initialized
INFO - 2022-02-23 06:14:42 --> Loader Class Initialized
INFO - 2022-02-23 06:14:42 --> Helper loaded: url_helper
INFO - 2022-02-23 06:14:42 --> Helper loaded: file_helper
INFO - 2022-02-23 06:14:42 --> Helper loaded: form_helper
INFO - 2022-02-23 06:14:42 --> Helper loaded: my_helper
INFO - 2022-02-23 06:14:42 --> Database Driver Class Initialized
DEBUG - 2022-02-23 06:14:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-23 06:14:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-23 06:14:42 --> Controller Class Initialized
INFO - 2022-02-23 06:14:53 --> Config Class Initialized
INFO - 2022-02-23 06:14:53 --> Hooks Class Initialized
DEBUG - 2022-02-23 06:14:53 --> UTF-8 Support Enabled
INFO - 2022-02-23 06:14:53 --> Utf8 Class Initialized
INFO - 2022-02-23 06:14:53 --> URI Class Initialized
INFO - 2022-02-23 06:14:53 --> Router Class Initialized
INFO - 2022-02-23 06:14:53 --> Output Class Initialized
INFO - 2022-02-23 06:14:53 --> Security Class Initialized
DEBUG - 2022-02-23 06:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-23 06:14:53 --> Input Class Initialized
INFO - 2022-02-23 06:14:53 --> Language Class Initialized
INFO - 2022-02-23 06:14:53 --> Language Class Initialized
INFO - 2022-02-23 06:14:53 --> Config Class Initialized
INFO - 2022-02-23 06:14:53 --> Loader Class Initialized
INFO - 2022-02-23 06:14:53 --> Helper loaded: url_helper
INFO - 2022-02-23 06:14:53 --> Helper loaded: file_helper
INFO - 2022-02-23 06:14:53 --> Helper loaded: form_helper
INFO - 2022-02-23 06:14:53 --> Helper loaded: my_helper
INFO - 2022-02-23 06:14:53 --> Database Driver Class Initialized
DEBUG - 2022-02-23 06:14:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-23 06:14:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-23 06:14:53 --> Controller Class Initialized
INFO - 2022-02-23 06:14:53 --> Final output sent to browser
DEBUG - 2022-02-23 06:14:53 --> Total execution time: 0.0787
INFO - 2022-02-23 06:14:53 --> Config Class Initialized
INFO - 2022-02-23 06:14:53 --> Hooks Class Initialized
DEBUG - 2022-02-23 06:14:53 --> UTF-8 Support Enabled
INFO - 2022-02-23 06:14:53 --> Utf8 Class Initialized
INFO - 2022-02-23 06:14:53 --> URI Class Initialized
INFO - 2022-02-23 06:14:53 --> Router Class Initialized
INFO - 2022-02-23 06:14:53 --> Output Class Initialized
INFO - 2022-02-23 06:14:53 --> Security Class Initialized
DEBUG - 2022-02-23 06:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-23 06:14:53 --> Input Class Initialized
INFO - 2022-02-23 06:14:53 --> Language Class Initialized
INFO - 2022-02-23 06:14:53 --> Language Class Initialized
INFO - 2022-02-23 06:14:53 --> Config Class Initialized
INFO - 2022-02-23 06:14:53 --> Loader Class Initialized
INFO - 2022-02-23 06:14:53 --> Helper loaded: url_helper
INFO - 2022-02-23 06:14:53 --> Helper loaded: file_helper
INFO - 2022-02-23 06:14:53 --> Helper loaded: form_helper
INFO - 2022-02-23 06:14:53 --> Helper loaded: my_helper
INFO - 2022-02-23 06:14:53 --> Database Driver Class Initialized
DEBUG - 2022-02-23 06:14:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-23 06:14:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-23 06:14:53 --> Controller Class Initialized
INFO - 2022-02-23 06:14:58 --> Config Class Initialized
INFO - 2022-02-23 06:14:58 --> Hooks Class Initialized
DEBUG - 2022-02-23 06:14:58 --> UTF-8 Support Enabled
INFO - 2022-02-23 06:14:58 --> Utf8 Class Initialized
INFO - 2022-02-23 06:14:58 --> URI Class Initialized
INFO - 2022-02-23 06:14:58 --> Router Class Initialized
INFO - 2022-02-23 06:14:58 --> Output Class Initialized
INFO - 2022-02-23 06:14:58 --> Security Class Initialized
DEBUG - 2022-02-23 06:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-23 06:14:58 --> Input Class Initialized
INFO - 2022-02-23 06:14:58 --> Language Class Initialized
INFO - 2022-02-23 06:14:58 --> Language Class Initialized
INFO - 2022-02-23 06:14:58 --> Config Class Initialized
INFO - 2022-02-23 06:14:58 --> Loader Class Initialized
INFO - 2022-02-23 06:14:58 --> Helper loaded: url_helper
INFO - 2022-02-23 06:14:58 --> Helper loaded: file_helper
INFO - 2022-02-23 06:14:58 --> Helper loaded: form_helper
INFO - 2022-02-23 06:14:58 --> Helper loaded: my_helper
INFO - 2022-02-23 06:14:58 --> Database Driver Class Initialized
DEBUG - 2022-02-23 06:14:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-23 06:14:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-23 06:14:58 --> Controller Class Initialized
INFO - 2022-02-23 06:14:58 --> Helper loaded: cookie_helper
INFO - 2022-02-23 06:14:58 --> Config Class Initialized
INFO - 2022-02-23 06:14:58 --> Hooks Class Initialized
DEBUG - 2022-02-23 06:14:58 --> UTF-8 Support Enabled
INFO - 2022-02-23 06:14:58 --> Utf8 Class Initialized
INFO - 2022-02-23 06:14:58 --> URI Class Initialized
INFO - 2022-02-23 06:14:58 --> Router Class Initialized
INFO - 2022-02-23 06:14:58 --> Output Class Initialized
INFO - 2022-02-23 06:14:58 --> Security Class Initialized
DEBUG - 2022-02-23 06:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-23 06:14:58 --> Input Class Initialized
INFO - 2022-02-23 06:14:58 --> Language Class Initialized
INFO - 2022-02-23 06:14:58 --> Language Class Initialized
INFO - 2022-02-23 06:14:58 --> Config Class Initialized
INFO - 2022-02-23 06:14:58 --> Loader Class Initialized
INFO - 2022-02-23 06:14:58 --> Helper loaded: url_helper
INFO - 2022-02-23 06:14:58 --> Helper loaded: file_helper
INFO - 2022-02-23 06:14:58 --> Helper loaded: form_helper
INFO - 2022-02-23 06:14:58 --> Helper loaded: my_helper
INFO - 2022-02-23 06:14:58 --> Database Driver Class Initialized
DEBUG - 2022-02-23 06:14:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-23 06:14:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-23 06:14:58 --> Controller Class Initialized
DEBUG - 2022-02-23 06:14:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-02-23 06:14:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-02-23 06:14:58 --> Final output sent to browser
DEBUG - 2022-02-23 06:14:58 --> Total execution time: 0.0693
INFO - 2022-02-23 06:15:03 --> Config Class Initialized
INFO - 2022-02-23 06:15:03 --> Hooks Class Initialized
DEBUG - 2022-02-23 06:15:03 --> UTF-8 Support Enabled
INFO - 2022-02-23 06:15:03 --> Utf8 Class Initialized
INFO - 2022-02-23 06:15:03 --> URI Class Initialized
INFO - 2022-02-23 06:15:03 --> Router Class Initialized
INFO - 2022-02-23 06:15:03 --> Output Class Initialized
INFO - 2022-02-23 06:15:03 --> Security Class Initialized
DEBUG - 2022-02-23 06:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-23 06:15:03 --> Input Class Initialized
INFO - 2022-02-23 06:15:03 --> Language Class Initialized
INFO - 2022-02-23 06:15:03 --> Language Class Initialized
INFO - 2022-02-23 06:15:03 --> Config Class Initialized
INFO - 2022-02-23 06:15:03 --> Loader Class Initialized
INFO - 2022-02-23 06:15:03 --> Helper loaded: url_helper
INFO - 2022-02-23 06:15:03 --> Helper loaded: file_helper
INFO - 2022-02-23 06:15:03 --> Helper loaded: form_helper
INFO - 2022-02-23 06:15:03 --> Helper loaded: my_helper
INFO - 2022-02-23 06:15:03 --> Database Driver Class Initialized
DEBUG - 2022-02-23 06:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-23 06:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-23 06:15:03 --> Controller Class Initialized
INFO - 2022-02-23 06:15:03 --> Helper loaded: cookie_helper
INFO - 2022-02-23 06:15:03 --> Final output sent to browser
DEBUG - 2022-02-23 06:15:03 --> Total execution time: 0.0668
INFO - 2022-02-23 06:15:04 --> Config Class Initialized
INFO - 2022-02-23 06:15:04 --> Hooks Class Initialized
DEBUG - 2022-02-23 06:15:04 --> UTF-8 Support Enabled
INFO - 2022-02-23 06:15:04 --> Utf8 Class Initialized
INFO - 2022-02-23 06:15:04 --> URI Class Initialized
INFO - 2022-02-23 06:15:04 --> Router Class Initialized
INFO - 2022-02-23 06:15:04 --> Output Class Initialized
INFO - 2022-02-23 06:15:04 --> Security Class Initialized
DEBUG - 2022-02-23 06:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-23 06:15:04 --> Input Class Initialized
INFO - 2022-02-23 06:15:04 --> Language Class Initialized
INFO - 2022-02-23 06:15:04 --> Language Class Initialized
INFO - 2022-02-23 06:15:04 --> Config Class Initialized
INFO - 2022-02-23 06:15:04 --> Loader Class Initialized
INFO - 2022-02-23 06:15:04 --> Helper loaded: url_helper
INFO - 2022-02-23 06:15:04 --> Helper loaded: file_helper
INFO - 2022-02-23 06:15:04 --> Helper loaded: form_helper
INFO - 2022-02-23 06:15:04 --> Helper loaded: my_helper
INFO - 2022-02-23 06:15:04 --> Database Driver Class Initialized
DEBUG - 2022-02-23 06:15:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-23 06:15:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-23 06:15:04 --> Controller Class Initialized
DEBUG - 2022-02-23 06:15:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-02-23 06:15:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-02-23 06:15:04 --> Final output sent to browser
DEBUG - 2022-02-23 06:15:04 --> Total execution time: 0.8563
INFO - 2022-02-23 06:15:06 --> Config Class Initialized
INFO - 2022-02-23 06:15:06 --> Hooks Class Initialized
DEBUG - 2022-02-23 06:15:06 --> UTF-8 Support Enabled
INFO - 2022-02-23 06:15:06 --> Utf8 Class Initialized
INFO - 2022-02-23 06:15:06 --> URI Class Initialized
INFO - 2022-02-23 06:15:06 --> Router Class Initialized
INFO - 2022-02-23 06:15:06 --> Output Class Initialized
INFO - 2022-02-23 06:15:06 --> Security Class Initialized
DEBUG - 2022-02-23 06:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-23 06:15:06 --> Input Class Initialized
INFO - 2022-02-23 06:15:06 --> Language Class Initialized
INFO - 2022-02-23 06:15:06 --> Language Class Initialized
INFO - 2022-02-23 06:15:06 --> Config Class Initialized
INFO - 2022-02-23 06:15:06 --> Loader Class Initialized
INFO - 2022-02-23 06:15:06 --> Helper loaded: url_helper
INFO - 2022-02-23 06:15:06 --> Helper loaded: file_helper
INFO - 2022-02-23 06:15:06 --> Helper loaded: form_helper
INFO - 2022-02-23 06:15:06 --> Helper loaded: my_helper
INFO - 2022-02-23 06:15:06 --> Database Driver Class Initialized
DEBUG - 2022-02-23 06:15:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-23 06:15:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-23 06:15:06 --> Controller Class Initialized
DEBUG - 2022-02-23 06:15:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-02-23 06:15:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-02-23 06:15:07 --> Final output sent to browser
DEBUG - 2022-02-23 06:15:07 --> Total execution time: 0.1532
INFO - 2022-02-23 06:15:17 --> Config Class Initialized
INFO - 2022-02-23 06:15:17 --> Hooks Class Initialized
DEBUG - 2022-02-23 06:15:17 --> UTF-8 Support Enabled
INFO - 2022-02-23 06:15:17 --> Utf8 Class Initialized
INFO - 2022-02-23 06:15:17 --> URI Class Initialized
INFO - 2022-02-23 06:15:17 --> Router Class Initialized
INFO - 2022-02-23 06:15:17 --> Output Class Initialized
INFO - 2022-02-23 06:15:17 --> Security Class Initialized
DEBUG - 2022-02-23 06:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-23 06:15:17 --> Input Class Initialized
INFO - 2022-02-23 06:15:17 --> Language Class Initialized
INFO - 2022-02-23 06:15:17 --> Language Class Initialized
INFO - 2022-02-23 06:15:17 --> Config Class Initialized
INFO - 2022-02-23 06:15:17 --> Loader Class Initialized
INFO - 2022-02-23 06:15:17 --> Helper loaded: url_helper
INFO - 2022-02-23 06:15:17 --> Helper loaded: file_helper
INFO - 2022-02-23 06:15:17 --> Helper loaded: form_helper
INFO - 2022-02-23 06:15:17 --> Helper loaded: my_helper
INFO - 2022-02-23 06:15:17 --> Database Driver Class Initialized
DEBUG - 2022-02-23 06:15:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-23 06:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-23 06:15:17 --> Controller Class Initialized
ERROR - 2022-02-23 06:15:17 --> Query error: Unknown column 'a.desk' in 'field list' - Invalid query: SELECT 
                                            b.nama, a.nilai, a.desk
                                            FROM t_nilai_ekstra a
                                            INNER JOIN m_ekstra b ON a.id_ekstra = b.id
                                            WHERE a.id_siswa = 2544 AND a.nilai != '0' AND a.tasm = '20211'
INFO - 2022-02-23 06:15:17 --> Language file loaded: language/english/db_lang.php
