<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-02-26 08:10:09 --> Config Class Initialized
INFO - 2021-02-26 08:10:10 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:10:10 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:10:10 --> Utf8 Class Initialized
INFO - 2021-02-26 08:10:10 --> URI Class Initialized
DEBUG - 2021-02-26 08:10:10 --> No URI present. Default controller set.
INFO - 2021-02-26 08:10:10 --> Router Class Initialized
INFO - 2021-02-26 08:10:10 --> Output Class Initialized
INFO - 2021-02-26 08:10:10 --> Security Class Initialized
DEBUG - 2021-02-26 08:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:10:10 --> Input Class Initialized
INFO - 2021-02-26 08:10:10 --> Language Class Initialized
INFO - 2021-02-26 08:10:10 --> Language Class Initialized
INFO - 2021-02-26 08:10:10 --> Config Class Initialized
INFO - 2021-02-26 08:10:10 --> Loader Class Initialized
INFO - 2021-02-26 08:10:10 --> Helper loaded: url_helper
INFO - 2021-02-26 08:10:10 --> Helper loaded: file_helper
INFO - 2021-02-26 08:10:10 --> Helper loaded: form_helper
INFO - 2021-02-26 08:10:10 --> Helper loaded: my_helper
INFO - 2021-02-26 08:10:10 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:10:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:10:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:10:10 --> Controller Class Initialized
INFO - 2021-02-26 08:10:10 --> Config Class Initialized
INFO - 2021-02-26 08:10:10 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:10:10 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:10:10 --> Utf8 Class Initialized
INFO - 2021-02-26 08:10:10 --> URI Class Initialized
INFO - 2021-02-26 08:10:10 --> Router Class Initialized
INFO - 2021-02-26 08:10:10 --> Output Class Initialized
INFO - 2021-02-26 08:10:10 --> Security Class Initialized
DEBUG - 2021-02-26 08:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:10:10 --> Input Class Initialized
INFO - 2021-02-26 08:10:10 --> Language Class Initialized
INFO - 2021-02-26 08:10:10 --> Language Class Initialized
INFO - 2021-02-26 08:10:10 --> Config Class Initialized
INFO - 2021-02-26 08:10:10 --> Loader Class Initialized
INFO - 2021-02-26 08:10:10 --> Helper loaded: url_helper
INFO - 2021-02-26 08:10:10 --> Helper loaded: file_helper
INFO - 2021-02-26 08:10:10 --> Helper loaded: form_helper
INFO - 2021-02-26 08:10:10 --> Helper loaded: my_helper
INFO - 2021-02-26 08:10:10 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:10:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:10:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:10:10 --> Controller Class Initialized
DEBUG - 2021-02-26 08:10:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-02-26 08:10:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 08:10:11 --> Final output sent to browser
DEBUG - 2021-02-26 08:10:11 --> Total execution time: 0.2998
INFO - 2021-02-26 08:10:28 --> Config Class Initialized
INFO - 2021-02-26 08:10:28 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:10:28 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:10:28 --> Utf8 Class Initialized
INFO - 2021-02-26 08:10:28 --> URI Class Initialized
INFO - 2021-02-26 08:10:28 --> Router Class Initialized
INFO - 2021-02-26 08:10:28 --> Output Class Initialized
INFO - 2021-02-26 08:10:28 --> Security Class Initialized
DEBUG - 2021-02-26 08:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:10:28 --> Input Class Initialized
INFO - 2021-02-26 08:10:28 --> Language Class Initialized
INFO - 2021-02-26 08:10:28 --> Language Class Initialized
INFO - 2021-02-26 08:10:28 --> Config Class Initialized
INFO - 2021-02-26 08:10:28 --> Loader Class Initialized
INFO - 2021-02-26 08:10:28 --> Helper loaded: url_helper
INFO - 2021-02-26 08:10:28 --> Helper loaded: file_helper
INFO - 2021-02-26 08:10:28 --> Helper loaded: form_helper
INFO - 2021-02-26 08:10:28 --> Helper loaded: my_helper
INFO - 2021-02-26 08:10:28 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:10:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:10:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:10:28 --> Controller Class Initialized
INFO - 2021-02-26 08:10:28 --> Helper loaded: cookie_helper
INFO - 2021-02-26 08:10:28 --> Final output sent to browser
DEBUG - 2021-02-26 08:10:28 --> Total execution time: 0.3286
INFO - 2021-02-26 08:10:29 --> Config Class Initialized
INFO - 2021-02-26 08:10:29 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:10:29 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:10:29 --> Utf8 Class Initialized
INFO - 2021-02-26 08:10:29 --> URI Class Initialized
INFO - 2021-02-26 08:10:29 --> Router Class Initialized
INFO - 2021-02-26 08:10:29 --> Output Class Initialized
INFO - 2021-02-26 08:10:29 --> Security Class Initialized
DEBUG - 2021-02-26 08:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:10:29 --> Input Class Initialized
INFO - 2021-02-26 08:10:29 --> Language Class Initialized
INFO - 2021-02-26 08:10:29 --> Language Class Initialized
INFO - 2021-02-26 08:10:29 --> Config Class Initialized
INFO - 2021-02-26 08:10:29 --> Loader Class Initialized
INFO - 2021-02-26 08:10:29 --> Helper loaded: url_helper
INFO - 2021-02-26 08:10:29 --> Helper loaded: file_helper
INFO - 2021-02-26 08:10:29 --> Helper loaded: form_helper
INFO - 2021-02-26 08:10:29 --> Helper loaded: my_helper
INFO - 2021-02-26 08:10:29 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:10:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:10:29 --> Controller Class Initialized
DEBUG - 2021-02-26 08:10:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-02-26 08:10:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 08:10:29 --> Final output sent to browser
DEBUG - 2021-02-26 08:10:29 --> Total execution time: 0.5000
INFO - 2021-02-26 08:10:36 --> Config Class Initialized
INFO - 2021-02-26 08:10:36 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:10:36 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:10:36 --> Utf8 Class Initialized
INFO - 2021-02-26 08:10:37 --> URI Class Initialized
INFO - 2021-02-26 08:10:37 --> Router Class Initialized
INFO - 2021-02-26 08:10:37 --> Output Class Initialized
INFO - 2021-02-26 08:10:37 --> Security Class Initialized
DEBUG - 2021-02-26 08:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:10:37 --> Input Class Initialized
INFO - 2021-02-26 08:10:37 --> Language Class Initialized
INFO - 2021-02-26 08:10:37 --> Language Class Initialized
INFO - 2021-02-26 08:10:37 --> Config Class Initialized
INFO - 2021-02-26 08:10:37 --> Loader Class Initialized
INFO - 2021-02-26 08:10:37 --> Helper loaded: url_helper
INFO - 2021-02-26 08:10:37 --> Helper loaded: file_helper
INFO - 2021-02-26 08:10:37 --> Helper loaded: form_helper
INFO - 2021-02-26 08:10:37 --> Helper loaded: my_helper
INFO - 2021-02-26 08:10:37 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:10:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:10:37 --> Controller Class Initialized
DEBUG - 2021-02-26 08:10:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-02-26 08:10:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 08:10:37 --> Final output sent to browser
DEBUG - 2021-02-26 08:10:37 --> Total execution time: 0.2913
INFO - 2021-02-26 08:10:37 --> Config Class Initialized
INFO - 2021-02-26 08:10:37 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:10:37 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:10:37 --> Utf8 Class Initialized
INFO - 2021-02-26 08:10:37 --> URI Class Initialized
INFO - 2021-02-26 08:10:37 --> Router Class Initialized
INFO - 2021-02-26 08:10:37 --> Output Class Initialized
INFO - 2021-02-26 08:10:37 --> Security Class Initialized
DEBUG - 2021-02-26 08:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:10:37 --> Input Class Initialized
INFO - 2021-02-26 08:10:37 --> Language Class Initialized
INFO - 2021-02-26 08:10:37 --> Language Class Initialized
INFO - 2021-02-26 08:10:37 --> Config Class Initialized
INFO - 2021-02-26 08:10:37 --> Loader Class Initialized
INFO - 2021-02-26 08:10:37 --> Helper loaded: url_helper
INFO - 2021-02-26 08:10:37 --> Helper loaded: file_helper
INFO - 2021-02-26 08:10:37 --> Helper loaded: form_helper
INFO - 2021-02-26 08:10:37 --> Helper loaded: my_helper
INFO - 2021-02-26 08:10:37 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:10:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:10:37 --> Controller Class Initialized
INFO - 2021-02-26 08:10:38 --> Config Class Initialized
INFO - 2021-02-26 08:10:38 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:10:38 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:10:38 --> Utf8 Class Initialized
INFO - 2021-02-26 08:10:38 --> URI Class Initialized
INFO - 2021-02-26 08:10:38 --> Router Class Initialized
INFO - 2021-02-26 08:10:38 --> Output Class Initialized
INFO - 2021-02-26 08:10:38 --> Security Class Initialized
DEBUG - 2021-02-26 08:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:10:38 --> Input Class Initialized
INFO - 2021-02-26 08:10:38 --> Language Class Initialized
INFO - 2021-02-26 08:10:38 --> Language Class Initialized
INFO - 2021-02-26 08:10:38 --> Config Class Initialized
INFO - 2021-02-26 08:10:38 --> Loader Class Initialized
INFO - 2021-02-26 08:10:38 --> Helper loaded: url_helper
INFO - 2021-02-26 08:10:38 --> Helper loaded: file_helper
INFO - 2021-02-26 08:10:38 --> Helper loaded: form_helper
INFO - 2021-02-26 08:10:38 --> Helper loaded: my_helper
INFO - 2021-02-26 08:10:38 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:10:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:10:38 --> Controller Class Initialized
DEBUG - 2021-02-26 08:10:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-02-26 08:10:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 08:10:38 --> Final output sent to browser
DEBUG - 2021-02-26 08:10:38 --> Total execution time: 0.2525
INFO - 2021-02-26 08:10:38 --> Config Class Initialized
INFO - 2021-02-26 08:10:38 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:10:38 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:10:38 --> Utf8 Class Initialized
INFO - 2021-02-26 08:10:38 --> URI Class Initialized
INFO - 2021-02-26 08:10:38 --> Router Class Initialized
INFO - 2021-02-26 08:10:38 --> Output Class Initialized
INFO - 2021-02-26 08:10:38 --> Security Class Initialized
DEBUG - 2021-02-26 08:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:10:38 --> Input Class Initialized
INFO - 2021-02-26 08:10:38 --> Language Class Initialized
INFO - 2021-02-26 08:10:38 --> Language Class Initialized
INFO - 2021-02-26 08:10:38 --> Config Class Initialized
INFO - 2021-02-26 08:10:38 --> Loader Class Initialized
INFO - 2021-02-26 08:10:38 --> Helper loaded: url_helper
INFO - 2021-02-26 08:10:38 --> Helper loaded: file_helper
INFO - 2021-02-26 08:10:38 --> Helper loaded: form_helper
INFO - 2021-02-26 08:10:38 --> Helper loaded: my_helper
INFO - 2021-02-26 08:10:38 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:10:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:10:38 --> Controller Class Initialized
INFO - 2021-02-26 08:10:44 --> Config Class Initialized
INFO - 2021-02-26 08:10:44 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:10:44 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:10:44 --> Utf8 Class Initialized
INFO - 2021-02-26 08:10:44 --> URI Class Initialized
INFO - 2021-02-26 08:10:44 --> Router Class Initialized
INFO - 2021-02-26 08:10:44 --> Output Class Initialized
INFO - 2021-02-26 08:10:44 --> Security Class Initialized
DEBUG - 2021-02-26 08:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:10:44 --> Input Class Initialized
INFO - 2021-02-26 08:10:44 --> Language Class Initialized
INFO - 2021-02-26 08:10:44 --> Language Class Initialized
INFO - 2021-02-26 08:10:44 --> Config Class Initialized
INFO - 2021-02-26 08:10:44 --> Loader Class Initialized
INFO - 2021-02-26 08:10:44 --> Helper loaded: url_helper
INFO - 2021-02-26 08:10:44 --> Helper loaded: file_helper
INFO - 2021-02-26 08:10:44 --> Helper loaded: form_helper
INFO - 2021-02-26 08:10:44 --> Helper loaded: my_helper
INFO - 2021-02-26 08:10:44 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:10:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:10:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:10:44 --> Controller Class Initialized
INFO - 2021-02-26 08:10:44 --> Final output sent to browser
DEBUG - 2021-02-26 08:10:44 --> Total execution time: 0.3400
INFO - 2021-02-26 08:10:54 --> Config Class Initialized
INFO - 2021-02-26 08:10:54 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:10:54 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:10:54 --> Utf8 Class Initialized
INFO - 2021-02-26 08:10:54 --> URI Class Initialized
INFO - 2021-02-26 08:10:54 --> Router Class Initialized
INFO - 2021-02-26 08:10:54 --> Output Class Initialized
INFO - 2021-02-26 08:10:54 --> Security Class Initialized
DEBUG - 2021-02-26 08:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:10:54 --> Input Class Initialized
INFO - 2021-02-26 08:10:54 --> Language Class Initialized
INFO - 2021-02-26 08:10:54 --> Language Class Initialized
INFO - 2021-02-26 08:10:54 --> Config Class Initialized
INFO - 2021-02-26 08:10:54 --> Loader Class Initialized
INFO - 2021-02-26 08:10:54 --> Helper loaded: url_helper
INFO - 2021-02-26 08:10:54 --> Helper loaded: file_helper
INFO - 2021-02-26 08:10:54 --> Helper loaded: form_helper
INFO - 2021-02-26 08:10:54 --> Helper loaded: my_helper
INFO - 2021-02-26 08:10:54 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:10:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:10:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:10:54 --> Controller Class Initialized
INFO - 2021-02-26 08:10:54 --> Final output sent to browser
DEBUG - 2021-02-26 08:10:54 --> Total execution time: 0.2449
INFO - 2021-02-26 08:10:54 --> Config Class Initialized
INFO - 2021-02-26 08:10:54 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:10:54 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:10:54 --> Utf8 Class Initialized
INFO - 2021-02-26 08:10:54 --> URI Class Initialized
INFO - 2021-02-26 08:10:54 --> Router Class Initialized
INFO - 2021-02-26 08:10:54 --> Output Class Initialized
INFO - 2021-02-26 08:10:54 --> Security Class Initialized
DEBUG - 2021-02-26 08:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:10:54 --> Input Class Initialized
INFO - 2021-02-26 08:10:54 --> Language Class Initialized
INFO - 2021-02-26 08:10:54 --> Language Class Initialized
INFO - 2021-02-26 08:10:54 --> Config Class Initialized
INFO - 2021-02-26 08:10:54 --> Loader Class Initialized
INFO - 2021-02-26 08:10:54 --> Helper loaded: url_helper
INFO - 2021-02-26 08:10:54 --> Helper loaded: file_helper
INFO - 2021-02-26 08:10:54 --> Helper loaded: form_helper
INFO - 2021-02-26 08:10:55 --> Helper loaded: my_helper
INFO - 2021-02-26 08:10:55 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:10:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:10:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:10:55 --> Controller Class Initialized
INFO - 2021-02-26 08:10:59 --> Config Class Initialized
INFO - 2021-02-26 08:10:59 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:10:59 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:10:59 --> Utf8 Class Initialized
INFO - 2021-02-26 08:10:59 --> URI Class Initialized
INFO - 2021-02-26 08:10:59 --> Router Class Initialized
INFO - 2021-02-26 08:10:59 --> Output Class Initialized
INFO - 2021-02-26 08:10:59 --> Security Class Initialized
DEBUG - 2021-02-26 08:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:10:59 --> Input Class Initialized
INFO - 2021-02-26 08:10:59 --> Language Class Initialized
INFO - 2021-02-26 08:10:59 --> Language Class Initialized
INFO - 2021-02-26 08:10:59 --> Config Class Initialized
INFO - 2021-02-26 08:10:59 --> Loader Class Initialized
INFO - 2021-02-26 08:10:59 --> Helper loaded: url_helper
INFO - 2021-02-26 08:10:59 --> Helper loaded: file_helper
INFO - 2021-02-26 08:10:59 --> Helper loaded: form_helper
INFO - 2021-02-26 08:10:59 --> Helper loaded: my_helper
INFO - 2021-02-26 08:10:59 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:10:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:10:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:10:59 --> Controller Class Initialized
INFO - 2021-02-26 08:10:59 --> Helper loaded: cookie_helper
INFO - 2021-02-26 08:10:59 --> Config Class Initialized
INFO - 2021-02-26 08:10:59 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:10:59 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:10:59 --> Utf8 Class Initialized
INFO - 2021-02-26 08:10:59 --> URI Class Initialized
INFO - 2021-02-26 08:10:59 --> Router Class Initialized
INFO - 2021-02-26 08:10:59 --> Output Class Initialized
INFO - 2021-02-26 08:10:59 --> Security Class Initialized
DEBUG - 2021-02-26 08:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:10:59 --> Input Class Initialized
INFO - 2021-02-26 08:10:59 --> Language Class Initialized
INFO - 2021-02-26 08:10:59 --> Language Class Initialized
INFO - 2021-02-26 08:10:59 --> Config Class Initialized
INFO - 2021-02-26 08:10:59 --> Loader Class Initialized
INFO - 2021-02-26 08:10:59 --> Helper loaded: url_helper
INFO - 2021-02-26 08:10:59 --> Helper loaded: file_helper
INFO - 2021-02-26 08:10:59 --> Helper loaded: form_helper
INFO - 2021-02-26 08:10:59 --> Helper loaded: my_helper
INFO - 2021-02-26 08:10:59 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:10:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:10:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:10:59 --> Controller Class Initialized
DEBUG - 2021-02-26 08:10:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-02-26 08:10:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 08:10:59 --> Final output sent to browser
DEBUG - 2021-02-26 08:10:59 --> Total execution time: 0.2390
INFO - 2021-02-26 08:11:09 --> Config Class Initialized
INFO - 2021-02-26 08:11:09 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:11:09 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:11:09 --> Utf8 Class Initialized
INFO - 2021-02-26 08:11:09 --> URI Class Initialized
INFO - 2021-02-26 08:11:09 --> Router Class Initialized
INFO - 2021-02-26 08:11:09 --> Output Class Initialized
INFO - 2021-02-26 08:11:09 --> Security Class Initialized
DEBUG - 2021-02-26 08:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:11:09 --> Input Class Initialized
INFO - 2021-02-26 08:11:09 --> Language Class Initialized
INFO - 2021-02-26 08:11:09 --> Language Class Initialized
INFO - 2021-02-26 08:11:09 --> Config Class Initialized
INFO - 2021-02-26 08:11:09 --> Loader Class Initialized
INFO - 2021-02-26 08:11:09 --> Helper loaded: url_helper
INFO - 2021-02-26 08:11:09 --> Helper loaded: file_helper
INFO - 2021-02-26 08:11:09 --> Helper loaded: form_helper
INFO - 2021-02-26 08:11:09 --> Helper loaded: my_helper
INFO - 2021-02-26 08:11:09 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:11:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:11:09 --> Controller Class Initialized
INFO - 2021-02-26 08:11:09 --> Helper loaded: cookie_helper
INFO - 2021-02-26 08:11:09 --> Final output sent to browser
DEBUG - 2021-02-26 08:11:09 --> Total execution time: 0.3510
INFO - 2021-02-26 08:11:10 --> Config Class Initialized
INFO - 2021-02-26 08:11:10 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:11:10 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:11:10 --> Utf8 Class Initialized
INFO - 2021-02-26 08:11:10 --> URI Class Initialized
INFO - 2021-02-26 08:11:10 --> Router Class Initialized
INFO - 2021-02-26 08:11:10 --> Output Class Initialized
INFO - 2021-02-26 08:11:10 --> Security Class Initialized
DEBUG - 2021-02-26 08:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:11:10 --> Input Class Initialized
INFO - 2021-02-26 08:11:10 --> Language Class Initialized
INFO - 2021-02-26 08:11:10 --> Language Class Initialized
INFO - 2021-02-26 08:11:10 --> Config Class Initialized
INFO - 2021-02-26 08:11:10 --> Loader Class Initialized
INFO - 2021-02-26 08:11:10 --> Helper loaded: url_helper
INFO - 2021-02-26 08:11:10 --> Helper loaded: file_helper
INFO - 2021-02-26 08:11:10 --> Helper loaded: form_helper
INFO - 2021-02-26 08:11:10 --> Helper loaded: my_helper
INFO - 2021-02-26 08:11:10 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:11:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:11:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:11:10 --> Controller Class Initialized
DEBUG - 2021-02-26 08:11:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-02-26 08:11:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 08:11:10 --> Final output sent to browser
DEBUG - 2021-02-26 08:11:10 --> Total execution time: 0.3667
INFO - 2021-02-26 08:11:13 --> Config Class Initialized
INFO - 2021-02-26 08:11:13 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:11:13 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:11:13 --> Utf8 Class Initialized
INFO - 2021-02-26 08:11:13 --> URI Class Initialized
INFO - 2021-02-26 08:11:13 --> Router Class Initialized
INFO - 2021-02-26 08:11:13 --> Output Class Initialized
INFO - 2021-02-26 08:11:13 --> Security Class Initialized
DEBUG - 2021-02-26 08:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:11:13 --> Input Class Initialized
INFO - 2021-02-26 08:11:13 --> Language Class Initialized
INFO - 2021-02-26 08:11:13 --> Language Class Initialized
INFO - 2021-02-26 08:11:13 --> Config Class Initialized
INFO - 2021-02-26 08:11:13 --> Loader Class Initialized
INFO - 2021-02-26 08:11:13 --> Helper loaded: url_helper
INFO - 2021-02-26 08:11:13 --> Helper loaded: file_helper
INFO - 2021-02-26 08:11:13 --> Helper loaded: form_helper
INFO - 2021-02-26 08:11:13 --> Helper loaded: my_helper
INFO - 2021-02-26 08:11:13 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:11:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:11:13 --> Controller Class Initialized
DEBUG - 2021-02-26 08:11:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-02-26 08:11:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 08:11:13 --> Final output sent to browser
DEBUG - 2021-02-26 08:11:13 --> Total execution time: 0.3058
INFO - 2021-02-26 08:11:15 --> Config Class Initialized
INFO - 2021-02-26 08:11:15 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:11:15 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:11:15 --> Utf8 Class Initialized
INFO - 2021-02-26 08:11:15 --> URI Class Initialized
INFO - 2021-02-26 08:11:15 --> Router Class Initialized
INFO - 2021-02-26 08:11:15 --> Output Class Initialized
INFO - 2021-02-26 08:11:15 --> Security Class Initialized
DEBUG - 2021-02-26 08:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:11:15 --> Input Class Initialized
INFO - 2021-02-26 08:11:15 --> Language Class Initialized
INFO - 2021-02-26 08:11:15 --> Language Class Initialized
INFO - 2021-02-26 08:11:15 --> Config Class Initialized
INFO - 2021-02-26 08:11:15 --> Loader Class Initialized
INFO - 2021-02-26 08:11:15 --> Helper loaded: url_helper
INFO - 2021-02-26 08:11:15 --> Helper loaded: file_helper
INFO - 2021-02-26 08:11:15 --> Helper loaded: form_helper
INFO - 2021-02-26 08:11:15 --> Helper loaded: my_helper
INFO - 2021-02-26 08:11:15 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:11:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:11:15 --> Controller Class Initialized
INFO - 2021-02-26 08:11:15 --> Helper loaded: cookie_helper
INFO - 2021-02-26 08:11:16 --> Config Class Initialized
INFO - 2021-02-26 08:11:16 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:11:16 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:11:16 --> Utf8 Class Initialized
INFO - 2021-02-26 08:11:16 --> URI Class Initialized
INFO - 2021-02-26 08:11:16 --> Router Class Initialized
INFO - 2021-02-26 08:11:16 --> Output Class Initialized
INFO - 2021-02-26 08:11:16 --> Security Class Initialized
DEBUG - 2021-02-26 08:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:11:16 --> Input Class Initialized
INFO - 2021-02-26 08:11:16 --> Language Class Initialized
INFO - 2021-02-26 08:11:16 --> Language Class Initialized
INFO - 2021-02-26 08:11:16 --> Config Class Initialized
INFO - 2021-02-26 08:11:16 --> Loader Class Initialized
INFO - 2021-02-26 08:11:16 --> Helper loaded: url_helper
INFO - 2021-02-26 08:11:16 --> Helper loaded: file_helper
INFO - 2021-02-26 08:11:16 --> Helper loaded: form_helper
INFO - 2021-02-26 08:11:16 --> Helper loaded: my_helper
INFO - 2021-02-26 08:11:16 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:11:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:11:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:11:16 --> Controller Class Initialized
DEBUG - 2021-02-26 08:11:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-02-26 08:11:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 08:11:16 --> Final output sent to browser
DEBUG - 2021-02-26 08:11:16 --> Total execution time: 0.2403
INFO - 2021-02-26 08:11:26 --> Config Class Initialized
INFO - 2021-02-26 08:11:26 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:11:26 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:11:26 --> Utf8 Class Initialized
INFO - 2021-02-26 08:11:26 --> URI Class Initialized
INFO - 2021-02-26 08:11:26 --> Router Class Initialized
INFO - 2021-02-26 08:11:26 --> Output Class Initialized
INFO - 2021-02-26 08:11:26 --> Security Class Initialized
DEBUG - 2021-02-26 08:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:11:26 --> Input Class Initialized
INFO - 2021-02-26 08:11:26 --> Language Class Initialized
INFO - 2021-02-26 08:11:26 --> Language Class Initialized
INFO - 2021-02-26 08:11:26 --> Config Class Initialized
INFO - 2021-02-26 08:11:26 --> Loader Class Initialized
INFO - 2021-02-26 08:11:26 --> Helper loaded: url_helper
INFO - 2021-02-26 08:11:26 --> Helper loaded: file_helper
INFO - 2021-02-26 08:11:26 --> Helper loaded: form_helper
INFO - 2021-02-26 08:11:26 --> Helper loaded: my_helper
INFO - 2021-02-26 08:11:26 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:11:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:11:26 --> Controller Class Initialized
INFO - 2021-02-26 08:11:26 --> Helper loaded: cookie_helper
INFO - 2021-02-26 08:11:26 --> Final output sent to browser
DEBUG - 2021-02-26 08:11:26 --> Total execution time: 0.3006
INFO - 2021-02-26 08:11:28 --> Config Class Initialized
INFO - 2021-02-26 08:11:28 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:11:28 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:11:28 --> Utf8 Class Initialized
INFO - 2021-02-26 08:11:28 --> URI Class Initialized
INFO - 2021-02-26 08:11:28 --> Router Class Initialized
INFO - 2021-02-26 08:11:28 --> Output Class Initialized
INFO - 2021-02-26 08:11:28 --> Security Class Initialized
DEBUG - 2021-02-26 08:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:11:28 --> Input Class Initialized
INFO - 2021-02-26 08:11:28 --> Language Class Initialized
INFO - 2021-02-26 08:11:28 --> Language Class Initialized
INFO - 2021-02-26 08:11:28 --> Config Class Initialized
INFO - 2021-02-26 08:11:28 --> Loader Class Initialized
INFO - 2021-02-26 08:11:28 --> Helper loaded: url_helper
INFO - 2021-02-26 08:11:28 --> Helper loaded: file_helper
INFO - 2021-02-26 08:11:28 --> Helper loaded: form_helper
INFO - 2021-02-26 08:11:28 --> Helper loaded: my_helper
INFO - 2021-02-26 08:11:28 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:11:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:11:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:11:28 --> Controller Class Initialized
DEBUG - 2021-02-26 08:11:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-02-26 08:11:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 08:11:28 --> Final output sent to browser
DEBUG - 2021-02-26 08:11:28 --> Total execution time: 0.3709
INFO - 2021-02-26 08:11:39 --> Config Class Initialized
INFO - 2021-02-26 08:11:39 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:11:39 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:11:39 --> Utf8 Class Initialized
INFO - 2021-02-26 08:11:39 --> URI Class Initialized
INFO - 2021-02-26 08:11:39 --> Router Class Initialized
INFO - 2021-02-26 08:11:39 --> Output Class Initialized
INFO - 2021-02-26 08:11:39 --> Security Class Initialized
DEBUG - 2021-02-26 08:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:11:39 --> Input Class Initialized
INFO - 2021-02-26 08:11:39 --> Language Class Initialized
INFO - 2021-02-26 08:11:39 --> Language Class Initialized
INFO - 2021-02-26 08:11:39 --> Config Class Initialized
INFO - 2021-02-26 08:11:39 --> Loader Class Initialized
INFO - 2021-02-26 08:11:39 --> Helper loaded: url_helper
INFO - 2021-02-26 08:11:39 --> Helper loaded: file_helper
INFO - 2021-02-26 08:11:39 --> Helper loaded: form_helper
INFO - 2021-02-26 08:11:39 --> Helper loaded: my_helper
INFO - 2021-02-26 08:11:39 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:11:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:11:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:11:39 --> Controller Class Initialized
DEBUG - 2021-02-26 08:11:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-02-26 08:11:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 08:11:39 --> Final output sent to browser
DEBUG - 2021-02-26 08:11:39 --> Total execution time: 0.2616
INFO - 2021-02-26 08:11:39 --> Config Class Initialized
INFO - 2021-02-26 08:11:39 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:11:39 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:11:39 --> Utf8 Class Initialized
INFO - 2021-02-26 08:11:39 --> URI Class Initialized
INFO - 2021-02-26 08:11:39 --> Router Class Initialized
INFO - 2021-02-26 08:11:39 --> Output Class Initialized
INFO - 2021-02-26 08:11:39 --> Security Class Initialized
DEBUG - 2021-02-26 08:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:11:39 --> Input Class Initialized
INFO - 2021-02-26 08:11:39 --> Language Class Initialized
INFO - 2021-02-26 08:11:39 --> Language Class Initialized
INFO - 2021-02-26 08:11:39 --> Config Class Initialized
INFO - 2021-02-26 08:11:39 --> Loader Class Initialized
INFO - 2021-02-26 08:11:39 --> Helper loaded: url_helper
INFO - 2021-02-26 08:11:39 --> Helper loaded: file_helper
INFO - 2021-02-26 08:11:39 --> Helper loaded: form_helper
INFO - 2021-02-26 08:11:39 --> Helper loaded: my_helper
INFO - 2021-02-26 08:11:40 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:11:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:11:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:11:40 --> Controller Class Initialized
INFO - 2021-02-26 08:11:43 --> Config Class Initialized
INFO - 2021-02-26 08:11:43 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:11:43 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:11:43 --> Utf8 Class Initialized
INFO - 2021-02-26 08:11:43 --> URI Class Initialized
INFO - 2021-02-26 08:11:43 --> Router Class Initialized
INFO - 2021-02-26 08:11:43 --> Output Class Initialized
INFO - 2021-02-26 08:11:43 --> Security Class Initialized
DEBUG - 2021-02-26 08:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:11:43 --> Input Class Initialized
INFO - 2021-02-26 08:11:43 --> Language Class Initialized
INFO - 2021-02-26 08:11:43 --> Language Class Initialized
INFO - 2021-02-26 08:11:43 --> Config Class Initialized
INFO - 2021-02-26 08:11:43 --> Loader Class Initialized
INFO - 2021-02-26 08:11:43 --> Helper loaded: url_helper
INFO - 2021-02-26 08:11:43 --> Helper loaded: file_helper
INFO - 2021-02-26 08:11:43 --> Helper loaded: form_helper
INFO - 2021-02-26 08:11:43 --> Helper loaded: my_helper
INFO - 2021-02-26 08:11:43 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:11:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:11:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:11:43 --> Controller Class Initialized
DEBUG - 2021-02-26 08:11:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-02-26 08:11:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 08:11:43 --> Final output sent to browser
DEBUG - 2021-02-26 08:11:43 --> Total execution time: 0.2586
INFO - 2021-02-26 08:11:57 --> Config Class Initialized
INFO - 2021-02-26 08:11:57 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:11:57 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:11:57 --> Utf8 Class Initialized
INFO - 2021-02-26 08:11:57 --> URI Class Initialized
INFO - 2021-02-26 08:11:57 --> Router Class Initialized
INFO - 2021-02-26 08:11:57 --> Output Class Initialized
INFO - 2021-02-26 08:11:57 --> Security Class Initialized
DEBUG - 2021-02-26 08:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:11:57 --> Input Class Initialized
INFO - 2021-02-26 08:11:57 --> Language Class Initialized
INFO - 2021-02-26 08:11:57 --> Language Class Initialized
INFO - 2021-02-26 08:11:57 --> Config Class Initialized
INFO - 2021-02-26 08:11:57 --> Loader Class Initialized
INFO - 2021-02-26 08:11:57 --> Helper loaded: url_helper
INFO - 2021-02-26 08:11:57 --> Helper loaded: file_helper
INFO - 2021-02-26 08:11:57 --> Helper loaded: form_helper
INFO - 2021-02-26 08:11:57 --> Helper loaded: my_helper
INFO - 2021-02-26 08:11:57 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:11:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:11:57 --> Controller Class Initialized
INFO - 2021-02-26 08:11:57 --> Config Class Initialized
INFO - 2021-02-26 08:11:57 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:11:57 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:11:57 --> Utf8 Class Initialized
INFO - 2021-02-26 08:11:57 --> URI Class Initialized
INFO - 2021-02-26 08:11:57 --> Router Class Initialized
INFO - 2021-02-26 08:11:57 --> Output Class Initialized
INFO - 2021-02-26 08:11:57 --> Security Class Initialized
DEBUG - 2021-02-26 08:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:11:57 --> Input Class Initialized
INFO - 2021-02-26 08:11:57 --> Language Class Initialized
INFO - 2021-02-26 08:11:57 --> Language Class Initialized
INFO - 2021-02-26 08:11:57 --> Config Class Initialized
INFO - 2021-02-26 08:11:57 --> Loader Class Initialized
INFO - 2021-02-26 08:11:57 --> Helper loaded: url_helper
INFO - 2021-02-26 08:11:57 --> Helper loaded: file_helper
INFO - 2021-02-26 08:11:57 --> Helper loaded: form_helper
INFO - 2021-02-26 08:11:57 --> Helper loaded: my_helper
INFO - 2021-02-26 08:11:57 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:11:58 --> Controller Class Initialized
DEBUG - 2021-02-26 08:11:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-02-26 08:11:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 08:11:58 --> Final output sent to browser
DEBUG - 2021-02-26 08:11:58 --> Total execution time: 0.2257
INFO - 2021-02-26 08:11:58 --> Config Class Initialized
INFO - 2021-02-26 08:11:58 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:11:58 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:11:58 --> Utf8 Class Initialized
INFO - 2021-02-26 08:11:58 --> URI Class Initialized
INFO - 2021-02-26 08:11:58 --> Router Class Initialized
INFO - 2021-02-26 08:11:58 --> Output Class Initialized
INFO - 2021-02-26 08:11:58 --> Security Class Initialized
DEBUG - 2021-02-26 08:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:11:58 --> Input Class Initialized
INFO - 2021-02-26 08:11:58 --> Language Class Initialized
INFO - 2021-02-26 08:11:58 --> Language Class Initialized
INFO - 2021-02-26 08:11:58 --> Config Class Initialized
INFO - 2021-02-26 08:11:58 --> Loader Class Initialized
INFO - 2021-02-26 08:11:58 --> Helper loaded: url_helper
INFO - 2021-02-26 08:11:58 --> Helper loaded: file_helper
INFO - 2021-02-26 08:11:58 --> Helper loaded: form_helper
INFO - 2021-02-26 08:11:58 --> Helper loaded: my_helper
INFO - 2021-02-26 08:11:58 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:11:58 --> Controller Class Initialized
INFO - 2021-02-26 08:12:14 --> Config Class Initialized
INFO - 2021-02-26 08:12:14 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:12:14 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:12:14 --> Utf8 Class Initialized
INFO - 2021-02-26 08:12:14 --> URI Class Initialized
INFO - 2021-02-26 08:12:14 --> Router Class Initialized
INFO - 2021-02-26 08:12:14 --> Output Class Initialized
INFO - 2021-02-26 08:12:14 --> Security Class Initialized
DEBUG - 2021-02-26 08:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:12:14 --> Input Class Initialized
INFO - 2021-02-26 08:12:14 --> Language Class Initialized
INFO - 2021-02-26 08:12:14 --> Language Class Initialized
INFO - 2021-02-26 08:12:15 --> Config Class Initialized
INFO - 2021-02-26 08:12:15 --> Loader Class Initialized
INFO - 2021-02-26 08:12:15 --> Helper loaded: url_helper
INFO - 2021-02-26 08:12:15 --> Helper loaded: file_helper
INFO - 2021-02-26 08:12:15 --> Helper loaded: form_helper
INFO - 2021-02-26 08:12:15 --> Helper loaded: my_helper
INFO - 2021-02-26 08:12:15 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:12:15 --> Controller Class Initialized
INFO - 2021-02-26 08:12:15 --> Helper loaded: cookie_helper
INFO - 2021-02-26 08:12:15 --> Config Class Initialized
INFO - 2021-02-26 08:12:15 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:12:15 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:12:15 --> Utf8 Class Initialized
INFO - 2021-02-26 08:12:15 --> URI Class Initialized
INFO - 2021-02-26 08:12:15 --> Router Class Initialized
INFO - 2021-02-26 08:12:15 --> Output Class Initialized
INFO - 2021-02-26 08:12:15 --> Security Class Initialized
DEBUG - 2021-02-26 08:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:12:15 --> Input Class Initialized
INFO - 2021-02-26 08:12:15 --> Language Class Initialized
INFO - 2021-02-26 08:12:15 --> Language Class Initialized
INFO - 2021-02-26 08:12:15 --> Config Class Initialized
INFO - 2021-02-26 08:12:15 --> Loader Class Initialized
INFO - 2021-02-26 08:12:15 --> Helper loaded: url_helper
INFO - 2021-02-26 08:12:15 --> Helper loaded: file_helper
INFO - 2021-02-26 08:12:15 --> Helper loaded: form_helper
INFO - 2021-02-26 08:12:15 --> Helper loaded: my_helper
INFO - 2021-02-26 08:12:15 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:12:15 --> Controller Class Initialized
DEBUG - 2021-02-26 08:12:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-02-26 08:12:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 08:12:15 --> Final output sent to browser
DEBUG - 2021-02-26 08:12:15 --> Total execution time: 0.2122
INFO - 2021-02-26 08:12:22 --> Config Class Initialized
INFO - 2021-02-26 08:12:22 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:12:22 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:12:22 --> Utf8 Class Initialized
INFO - 2021-02-26 08:12:22 --> URI Class Initialized
INFO - 2021-02-26 08:12:22 --> Router Class Initialized
INFO - 2021-02-26 08:12:22 --> Output Class Initialized
INFO - 2021-02-26 08:12:22 --> Security Class Initialized
DEBUG - 2021-02-26 08:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:12:22 --> Input Class Initialized
INFO - 2021-02-26 08:12:22 --> Language Class Initialized
INFO - 2021-02-26 08:12:22 --> Language Class Initialized
INFO - 2021-02-26 08:12:22 --> Config Class Initialized
INFO - 2021-02-26 08:12:22 --> Loader Class Initialized
INFO - 2021-02-26 08:12:22 --> Helper loaded: url_helper
INFO - 2021-02-26 08:12:22 --> Helper loaded: file_helper
INFO - 2021-02-26 08:12:22 --> Helper loaded: form_helper
INFO - 2021-02-26 08:12:22 --> Helper loaded: my_helper
INFO - 2021-02-26 08:12:22 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:12:22 --> Controller Class Initialized
INFO - 2021-02-26 08:12:22 --> Helper loaded: cookie_helper
INFO - 2021-02-26 08:12:22 --> Final output sent to browser
DEBUG - 2021-02-26 08:12:22 --> Total execution time: 0.3156
INFO - 2021-02-26 08:12:22 --> Config Class Initialized
INFO - 2021-02-26 08:12:22 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:12:22 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:12:22 --> Utf8 Class Initialized
INFO - 2021-02-26 08:12:22 --> URI Class Initialized
INFO - 2021-02-26 08:12:22 --> Router Class Initialized
INFO - 2021-02-26 08:12:22 --> Output Class Initialized
INFO - 2021-02-26 08:12:22 --> Security Class Initialized
DEBUG - 2021-02-26 08:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:12:22 --> Input Class Initialized
INFO - 2021-02-26 08:12:22 --> Language Class Initialized
INFO - 2021-02-26 08:12:22 --> Language Class Initialized
INFO - 2021-02-26 08:12:23 --> Config Class Initialized
INFO - 2021-02-26 08:12:23 --> Loader Class Initialized
INFO - 2021-02-26 08:12:23 --> Helper loaded: url_helper
INFO - 2021-02-26 08:12:23 --> Helper loaded: file_helper
INFO - 2021-02-26 08:12:23 --> Helper loaded: form_helper
INFO - 2021-02-26 08:12:23 --> Helper loaded: my_helper
INFO - 2021-02-26 08:12:23 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:12:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:12:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:12:23 --> Controller Class Initialized
DEBUG - 2021-02-26 08:12:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-02-26 08:12:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 08:12:23 --> Final output sent to browser
DEBUG - 2021-02-26 08:12:23 --> Total execution time: 0.3719
INFO - 2021-02-26 08:12:34 --> Config Class Initialized
INFO - 2021-02-26 08:12:34 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:12:34 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:12:34 --> Utf8 Class Initialized
INFO - 2021-02-26 08:12:34 --> URI Class Initialized
INFO - 2021-02-26 08:12:34 --> Router Class Initialized
INFO - 2021-02-26 08:12:34 --> Output Class Initialized
INFO - 2021-02-26 08:12:34 --> Security Class Initialized
DEBUG - 2021-02-26 08:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:12:34 --> Input Class Initialized
INFO - 2021-02-26 08:12:34 --> Language Class Initialized
INFO - 2021-02-26 08:12:34 --> Language Class Initialized
INFO - 2021-02-26 08:12:34 --> Config Class Initialized
INFO - 2021-02-26 08:12:34 --> Loader Class Initialized
INFO - 2021-02-26 08:12:34 --> Helper loaded: url_helper
INFO - 2021-02-26 08:12:34 --> Helper loaded: file_helper
INFO - 2021-02-26 08:12:34 --> Helper loaded: form_helper
INFO - 2021-02-26 08:12:34 --> Helper loaded: my_helper
INFO - 2021-02-26 08:12:34 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:12:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:12:34 --> Controller Class Initialized
INFO - 2021-02-26 08:12:34 --> Helper loaded: cookie_helper
INFO - 2021-02-26 08:12:34 --> Config Class Initialized
INFO - 2021-02-26 08:12:34 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:12:34 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:12:34 --> Utf8 Class Initialized
INFO - 2021-02-26 08:12:34 --> URI Class Initialized
INFO - 2021-02-26 08:12:34 --> Router Class Initialized
INFO - 2021-02-26 08:12:34 --> Output Class Initialized
INFO - 2021-02-26 08:12:34 --> Security Class Initialized
DEBUG - 2021-02-26 08:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:12:34 --> Input Class Initialized
INFO - 2021-02-26 08:12:34 --> Language Class Initialized
INFO - 2021-02-26 08:12:34 --> Language Class Initialized
INFO - 2021-02-26 08:12:34 --> Config Class Initialized
INFO - 2021-02-26 08:12:34 --> Loader Class Initialized
INFO - 2021-02-26 08:12:34 --> Helper loaded: url_helper
INFO - 2021-02-26 08:12:34 --> Helper loaded: file_helper
INFO - 2021-02-26 08:12:34 --> Helper loaded: form_helper
INFO - 2021-02-26 08:12:34 --> Helper loaded: my_helper
INFO - 2021-02-26 08:12:35 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:12:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:12:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:12:35 --> Controller Class Initialized
DEBUG - 2021-02-26 08:12:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-02-26 08:12:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 08:12:35 --> Final output sent to browser
DEBUG - 2021-02-26 08:12:35 --> Total execution time: 0.2504
INFO - 2021-02-26 08:12:38 --> Config Class Initialized
INFO - 2021-02-26 08:12:38 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:12:38 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:12:38 --> Utf8 Class Initialized
INFO - 2021-02-26 08:12:38 --> URI Class Initialized
INFO - 2021-02-26 08:12:38 --> Router Class Initialized
INFO - 2021-02-26 08:12:38 --> Output Class Initialized
INFO - 2021-02-26 08:12:38 --> Security Class Initialized
DEBUG - 2021-02-26 08:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:12:38 --> Input Class Initialized
INFO - 2021-02-26 08:12:38 --> Language Class Initialized
INFO - 2021-02-26 08:12:38 --> Language Class Initialized
INFO - 2021-02-26 08:12:38 --> Config Class Initialized
INFO - 2021-02-26 08:12:38 --> Loader Class Initialized
INFO - 2021-02-26 08:12:38 --> Helper loaded: url_helper
INFO - 2021-02-26 08:12:38 --> Helper loaded: file_helper
INFO - 2021-02-26 08:12:38 --> Helper loaded: form_helper
INFO - 2021-02-26 08:12:38 --> Helper loaded: my_helper
INFO - 2021-02-26 08:12:39 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:12:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:12:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:12:39 --> Controller Class Initialized
INFO - 2021-02-26 08:12:39 --> Helper loaded: cookie_helper
INFO - 2021-02-26 08:12:39 --> Final output sent to browser
DEBUG - 2021-02-26 08:12:39 --> Total execution time: 0.3091
INFO - 2021-02-26 08:12:39 --> Config Class Initialized
INFO - 2021-02-26 08:12:39 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:12:39 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:12:39 --> Utf8 Class Initialized
INFO - 2021-02-26 08:12:39 --> URI Class Initialized
INFO - 2021-02-26 08:12:39 --> Router Class Initialized
INFO - 2021-02-26 08:12:39 --> Output Class Initialized
INFO - 2021-02-26 08:12:39 --> Security Class Initialized
DEBUG - 2021-02-26 08:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:12:39 --> Input Class Initialized
INFO - 2021-02-26 08:12:39 --> Language Class Initialized
INFO - 2021-02-26 08:12:39 --> Language Class Initialized
INFO - 2021-02-26 08:12:39 --> Config Class Initialized
INFO - 2021-02-26 08:12:39 --> Loader Class Initialized
INFO - 2021-02-26 08:12:39 --> Helper loaded: url_helper
INFO - 2021-02-26 08:12:39 --> Helper loaded: file_helper
INFO - 2021-02-26 08:12:39 --> Helper loaded: form_helper
INFO - 2021-02-26 08:12:39 --> Helper loaded: my_helper
INFO - 2021-02-26 08:12:39 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:12:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:12:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:12:39 --> Controller Class Initialized
DEBUG - 2021-02-26 08:12:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-02-26 08:12:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 08:12:39 --> Final output sent to browser
DEBUG - 2021-02-26 08:12:39 --> Total execution time: 0.4045
INFO - 2021-02-26 08:12:43 --> Config Class Initialized
INFO - 2021-02-26 08:12:43 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:12:43 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:12:43 --> Utf8 Class Initialized
INFO - 2021-02-26 08:12:43 --> URI Class Initialized
INFO - 2021-02-26 08:12:43 --> Router Class Initialized
INFO - 2021-02-26 08:12:43 --> Output Class Initialized
INFO - 2021-02-26 08:12:43 --> Security Class Initialized
DEBUG - 2021-02-26 08:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:12:43 --> Input Class Initialized
INFO - 2021-02-26 08:12:43 --> Language Class Initialized
INFO - 2021-02-26 08:12:43 --> Language Class Initialized
INFO - 2021-02-26 08:12:43 --> Config Class Initialized
INFO - 2021-02-26 08:12:43 --> Loader Class Initialized
INFO - 2021-02-26 08:12:43 --> Helper loaded: url_helper
INFO - 2021-02-26 08:12:43 --> Helper loaded: file_helper
INFO - 2021-02-26 08:12:43 --> Helper loaded: form_helper
INFO - 2021-02-26 08:12:43 --> Helper loaded: my_helper
INFO - 2021-02-26 08:12:43 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:12:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:12:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:12:43 --> Controller Class Initialized
DEBUG - 2021-02-26 08:12:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-02-26 08:12:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 08:12:43 --> Final output sent to browser
DEBUG - 2021-02-26 08:12:43 --> Total execution time: 0.4040
INFO - 2021-02-26 08:12:47 --> Config Class Initialized
INFO - 2021-02-26 08:12:47 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:12:47 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:12:47 --> Utf8 Class Initialized
INFO - 2021-02-26 08:12:47 --> URI Class Initialized
INFO - 2021-02-26 08:12:47 --> Router Class Initialized
INFO - 2021-02-26 08:12:47 --> Output Class Initialized
INFO - 2021-02-26 08:12:47 --> Security Class Initialized
DEBUG - 2021-02-26 08:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:12:47 --> Input Class Initialized
INFO - 2021-02-26 08:12:47 --> Language Class Initialized
INFO - 2021-02-26 08:12:47 --> Language Class Initialized
INFO - 2021-02-26 08:12:47 --> Config Class Initialized
INFO - 2021-02-26 08:12:47 --> Loader Class Initialized
INFO - 2021-02-26 08:12:47 --> Helper loaded: url_helper
INFO - 2021-02-26 08:12:47 --> Helper loaded: file_helper
INFO - 2021-02-26 08:12:47 --> Helper loaded: form_helper
INFO - 2021-02-26 08:12:47 --> Helper loaded: my_helper
INFO - 2021-02-26 08:12:47 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:12:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:12:47 --> Controller Class Initialized
DEBUG - 2021-02-26 08:12:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-02-26 08:12:47 --> Final output sent to browser
DEBUG - 2021-02-26 08:12:47 --> Total execution time: 0.4214
INFO - 2021-02-26 08:13:11 --> Config Class Initialized
INFO - 2021-02-26 08:13:11 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:13:11 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:13:11 --> Utf8 Class Initialized
INFO - 2021-02-26 08:13:11 --> URI Class Initialized
INFO - 2021-02-26 08:13:11 --> Router Class Initialized
INFO - 2021-02-26 08:13:11 --> Output Class Initialized
INFO - 2021-02-26 08:13:11 --> Security Class Initialized
DEBUG - 2021-02-26 08:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:13:11 --> Input Class Initialized
INFO - 2021-02-26 08:13:11 --> Language Class Initialized
INFO - 2021-02-26 08:13:11 --> Language Class Initialized
INFO - 2021-02-26 08:13:11 --> Config Class Initialized
INFO - 2021-02-26 08:13:11 --> Loader Class Initialized
INFO - 2021-02-26 08:13:11 --> Helper loaded: url_helper
INFO - 2021-02-26 08:13:11 --> Helper loaded: file_helper
INFO - 2021-02-26 08:13:11 --> Helper loaded: form_helper
INFO - 2021-02-26 08:13:11 --> Helper loaded: my_helper
INFO - 2021-02-26 08:13:11 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:13:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:13:11 --> Controller Class Initialized
INFO - 2021-02-26 08:13:11 --> Helper loaded: cookie_helper
INFO - 2021-02-26 08:13:11 --> Config Class Initialized
INFO - 2021-02-26 08:13:11 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:13:11 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:13:11 --> Utf8 Class Initialized
INFO - 2021-02-26 08:13:11 --> URI Class Initialized
INFO - 2021-02-26 08:13:11 --> Router Class Initialized
INFO - 2021-02-26 08:13:11 --> Output Class Initialized
INFO - 2021-02-26 08:13:11 --> Security Class Initialized
DEBUG - 2021-02-26 08:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:13:11 --> Input Class Initialized
INFO - 2021-02-26 08:13:11 --> Language Class Initialized
INFO - 2021-02-26 08:13:11 --> Language Class Initialized
INFO - 2021-02-26 08:13:11 --> Config Class Initialized
INFO - 2021-02-26 08:13:11 --> Loader Class Initialized
INFO - 2021-02-26 08:13:11 --> Helper loaded: url_helper
INFO - 2021-02-26 08:13:11 --> Helper loaded: file_helper
INFO - 2021-02-26 08:13:11 --> Helper loaded: form_helper
INFO - 2021-02-26 08:13:11 --> Helper loaded: my_helper
INFO - 2021-02-26 08:13:11 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:13:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:13:11 --> Controller Class Initialized
DEBUG - 2021-02-26 08:13:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-02-26 08:13:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 08:13:11 --> Final output sent to browser
DEBUG - 2021-02-26 08:13:11 --> Total execution time: 0.3112
INFO - 2021-02-26 08:13:17 --> Config Class Initialized
INFO - 2021-02-26 08:13:17 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:13:17 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:13:17 --> Utf8 Class Initialized
INFO - 2021-02-26 08:13:17 --> URI Class Initialized
INFO - 2021-02-26 08:13:17 --> Router Class Initialized
INFO - 2021-02-26 08:13:17 --> Output Class Initialized
INFO - 2021-02-26 08:13:17 --> Security Class Initialized
DEBUG - 2021-02-26 08:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:13:17 --> Input Class Initialized
INFO - 2021-02-26 08:13:17 --> Language Class Initialized
INFO - 2021-02-26 08:13:17 --> Language Class Initialized
INFO - 2021-02-26 08:13:17 --> Config Class Initialized
INFO - 2021-02-26 08:13:17 --> Loader Class Initialized
INFO - 2021-02-26 08:13:17 --> Helper loaded: url_helper
INFO - 2021-02-26 08:13:17 --> Helper loaded: file_helper
INFO - 2021-02-26 08:13:17 --> Helper loaded: form_helper
INFO - 2021-02-26 08:13:17 --> Helper loaded: my_helper
INFO - 2021-02-26 08:13:17 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:13:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:13:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:13:17 --> Controller Class Initialized
INFO - 2021-02-26 08:13:17 --> Helper loaded: cookie_helper
INFO - 2021-02-26 08:13:17 --> Final output sent to browser
DEBUG - 2021-02-26 08:13:17 --> Total execution time: 0.3147
INFO - 2021-02-26 08:13:17 --> Config Class Initialized
INFO - 2021-02-26 08:13:17 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:13:17 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:13:17 --> Utf8 Class Initialized
INFO - 2021-02-26 08:13:18 --> URI Class Initialized
INFO - 2021-02-26 08:13:18 --> Router Class Initialized
INFO - 2021-02-26 08:13:18 --> Output Class Initialized
INFO - 2021-02-26 08:13:18 --> Security Class Initialized
DEBUG - 2021-02-26 08:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:13:18 --> Input Class Initialized
INFO - 2021-02-26 08:13:18 --> Language Class Initialized
INFO - 2021-02-26 08:13:18 --> Language Class Initialized
INFO - 2021-02-26 08:13:18 --> Config Class Initialized
INFO - 2021-02-26 08:13:18 --> Loader Class Initialized
INFO - 2021-02-26 08:13:18 --> Helper loaded: url_helper
INFO - 2021-02-26 08:13:18 --> Helper loaded: file_helper
INFO - 2021-02-26 08:13:18 --> Helper loaded: form_helper
INFO - 2021-02-26 08:13:18 --> Helper loaded: my_helper
INFO - 2021-02-26 08:13:18 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:13:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:13:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:13:18 --> Controller Class Initialized
DEBUG - 2021-02-26 08:13:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-02-26 08:13:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 08:13:18 --> Final output sent to browser
DEBUG - 2021-02-26 08:13:18 --> Total execution time: 0.3701
INFO - 2021-02-26 08:13:20 --> Config Class Initialized
INFO - 2021-02-26 08:13:20 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:13:20 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:13:20 --> Utf8 Class Initialized
INFO - 2021-02-26 08:13:20 --> URI Class Initialized
INFO - 2021-02-26 08:13:20 --> Router Class Initialized
INFO - 2021-02-26 08:13:20 --> Output Class Initialized
INFO - 2021-02-26 08:13:20 --> Security Class Initialized
DEBUG - 2021-02-26 08:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:13:20 --> Input Class Initialized
INFO - 2021-02-26 08:13:20 --> Language Class Initialized
INFO - 2021-02-26 08:13:20 --> Language Class Initialized
INFO - 2021-02-26 08:13:20 --> Config Class Initialized
INFO - 2021-02-26 08:13:20 --> Loader Class Initialized
INFO - 2021-02-26 08:13:20 --> Helper loaded: url_helper
INFO - 2021-02-26 08:13:20 --> Helper loaded: file_helper
INFO - 2021-02-26 08:13:20 --> Helper loaded: form_helper
INFO - 2021-02-26 08:13:20 --> Helper loaded: my_helper
INFO - 2021-02-26 08:13:20 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:13:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:13:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:13:20 --> Controller Class Initialized
DEBUG - 2021-02-26 08:13:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-02-26 08:13:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 08:13:20 --> Final output sent to browser
DEBUG - 2021-02-26 08:13:21 --> Total execution time: 0.2469
INFO - 2021-02-26 08:13:21 --> Config Class Initialized
INFO - 2021-02-26 08:13:21 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:13:21 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:13:21 --> Utf8 Class Initialized
INFO - 2021-02-26 08:13:21 --> URI Class Initialized
INFO - 2021-02-26 08:13:21 --> Router Class Initialized
INFO - 2021-02-26 08:13:21 --> Output Class Initialized
INFO - 2021-02-26 08:13:21 --> Security Class Initialized
DEBUG - 2021-02-26 08:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:13:21 --> Input Class Initialized
INFO - 2021-02-26 08:13:21 --> Language Class Initialized
INFO - 2021-02-26 08:13:21 --> Language Class Initialized
INFO - 2021-02-26 08:13:21 --> Config Class Initialized
INFO - 2021-02-26 08:13:21 --> Loader Class Initialized
INFO - 2021-02-26 08:13:21 --> Helper loaded: url_helper
INFO - 2021-02-26 08:13:21 --> Helper loaded: file_helper
INFO - 2021-02-26 08:13:21 --> Helper loaded: form_helper
INFO - 2021-02-26 08:13:21 --> Helper loaded: my_helper
INFO - 2021-02-26 08:13:21 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:13:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:13:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:13:21 --> Controller Class Initialized
INFO - 2021-02-26 08:13:24 --> Config Class Initialized
INFO - 2021-02-26 08:13:24 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:13:24 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:13:24 --> Utf8 Class Initialized
INFO - 2021-02-26 08:13:24 --> URI Class Initialized
INFO - 2021-02-26 08:13:24 --> Router Class Initialized
INFO - 2021-02-26 08:13:24 --> Output Class Initialized
INFO - 2021-02-26 08:13:24 --> Security Class Initialized
DEBUG - 2021-02-26 08:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:13:24 --> Input Class Initialized
INFO - 2021-02-26 08:13:24 --> Language Class Initialized
INFO - 2021-02-26 08:13:24 --> Language Class Initialized
INFO - 2021-02-26 08:13:24 --> Config Class Initialized
INFO - 2021-02-26 08:13:24 --> Loader Class Initialized
INFO - 2021-02-26 08:13:24 --> Helper loaded: url_helper
INFO - 2021-02-26 08:13:24 --> Helper loaded: file_helper
INFO - 2021-02-26 08:13:24 --> Helper loaded: form_helper
INFO - 2021-02-26 08:13:24 --> Helper loaded: my_helper
INFO - 2021-02-26 08:13:24 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:13:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:13:24 --> Controller Class Initialized
INFO - 2021-02-26 08:13:24 --> Final output sent to browser
DEBUG - 2021-02-26 08:13:24 --> Total execution time: 0.2760
INFO - 2021-02-26 08:13:24 --> Config Class Initialized
INFO - 2021-02-26 08:13:24 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:13:24 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:13:24 --> Utf8 Class Initialized
INFO - 2021-02-26 08:13:24 --> URI Class Initialized
INFO - 2021-02-26 08:13:24 --> Router Class Initialized
INFO - 2021-02-26 08:13:24 --> Output Class Initialized
INFO - 2021-02-26 08:13:24 --> Security Class Initialized
DEBUG - 2021-02-26 08:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:13:24 --> Input Class Initialized
INFO - 2021-02-26 08:13:24 --> Language Class Initialized
INFO - 2021-02-26 08:13:24 --> Language Class Initialized
INFO - 2021-02-26 08:13:24 --> Config Class Initialized
INFO - 2021-02-26 08:13:24 --> Loader Class Initialized
INFO - 2021-02-26 08:13:24 --> Helper loaded: url_helper
INFO - 2021-02-26 08:13:25 --> Helper loaded: file_helper
INFO - 2021-02-26 08:13:25 --> Helper loaded: form_helper
INFO - 2021-02-26 08:13:25 --> Helper loaded: my_helper
INFO - 2021-02-26 08:13:25 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:13:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:13:25 --> Controller Class Initialized
INFO - 2021-02-26 08:13:27 --> Config Class Initialized
INFO - 2021-02-26 08:13:27 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:13:27 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:13:27 --> Utf8 Class Initialized
INFO - 2021-02-26 08:13:27 --> URI Class Initialized
INFO - 2021-02-26 08:13:27 --> Router Class Initialized
INFO - 2021-02-26 08:13:27 --> Output Class Initialized
INFO - 2021-02-26 08:13:27 --> Security Class Initialized
DEBUG - 2021-02-26 08:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:13:27 --> Input Class Initialized
INFO - 2021-02-26 08:13:27 --> Language Class Initialized
INFO - 2021-02-26 08:13:27 --> Language Class Initialized
INFO - 2021-02-26 08:13:27 --> Config Class Initialized
INFO - 2021-02-26 08:13:27 --> Loader Class Initialized
INFO - 2021-02-26 08:13:27 --> Helper loaded: url_helper
INFO - 2021-02-26 08:13:27 --> Helper loaded: file_helper
INFO - 2021-02-26 08:13:27 --> Helper loaded: form_helper
INFO - 2021-02-26 08:13:27 --> Helper loaded: my_helper
INFO - 2021-02-26 08:13:27 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:13:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:13:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:13:27 --> Controller Class Initialized
INFO - 2021-02-26 08:13:27 --> Helper loaded: cookie_helper
INFO - 2021-02-26 08:13:27 --> Config Class Initialized
INFO - 2021-02-26 08:13:27 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:13:27 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:13:27 --> Utf8 Class Initialized
INFO - 2021-02-26 08:13:27 --> URI Class Initialized
INFO - 2021-02-26 08:13:27 --> Router Class Initialized
INFO - 2021-02-26 08:13:27 --> Output Class Initialized
INFO - 2021-02-26 08:13:27 --> Security Class Initialized
DEBUG - 2021-02-26 08:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:13:27 --> Input Class Initialized
INFO - 2021-02-26 08:13:27 --> Language Class Initialized
INFO - 2021-02-26 08:13:27 --> Language Class Initialized
INFO - 2021-02-26 08:13:27 --> Config Class Initialized
INFO - 2021-02-26 08:13:27 --> Loader Class Initialized
INFO - 2021-02-26 08:13:27 --> Helper loaded: url_helper
INFO - 2021-02-26 08:13:27 --> Helper loaded: file_helper
INFO - 2021-02-26 08:13:27 --> Helper loaded: form_helper
INFO - 2021-02-26 08:13:27 --> Helper loaded: my_helper
INFO - 2021-02-26 08:13:27 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:13:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:13:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:13:28 --> Controller Class Initialized
DEBUG - 2021-02-26 08:13:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-02-26 08:13:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 08:13:28 --> Final output sent to browser
DEBUG - 2021-02-26 08:13:28 --> Total execution time: 0.2780
INFO - 2021-02-26 08:13:31 --> Config Class Initialized
INFO - 2021-02-26 08:13:31 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:13:31 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:13:31 --> Utf8 Class Initialized
INFO - 2021-02-26 08:13:31 --> URI Class Initialized
INFO - 2021-02-26 08:13:31 --> Router Class Initialized
INFO - 2021-02-26 08:13:31 --> Output Class Initialized
INFO - 2021-02-26 08:13:31 --> Security Class Initialized
DEBUG - 2021-02-26 08:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:13:31 --> Input Class Initialized
INFO - 2021-02-26 08:13:31 --> Language Class Initialized
INFO - 2021-02-26 08:13:31 --> Language Class Initialized
INFO - 2021-02-26 08:13:32 --> Config Class Initialized
INFO - 2021-02-26 08:13:32 --> Loader Class Initialized
INFO - 2021-02-26 08:13:32 --> Helper loaded: url_helper
INFO - 2021-02-26 08:13:32 --> Helper loaded: file_helper
INFO - 2021-02-26 08:13:32 --> Helper loaded: form_helper
INFO - 2021-02-26 08:13:32 --> Helper loaded: my_helper
INFO - 2021-02-26 08:13:32 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:13:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:13:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:13:32 --> Controller Class Initialized
INFO - 2021-02-26 08:13:32 --> Helper loaded: cookie_helper
INFO - 2021-02-26 08:13:32 --> Final output sent to browser
DEBUG - 2021-02-26 08:13:32 --> Total execution time: 0.3177
INFO - 2021-02-26 08:13:32 --> Config Class Initialized
INFO - 2021-02-26 08:13:32 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:13:32 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:13:32 --> Utf8 Class Initialized
INFO - 2021-02-26 08:13:32 --> URI Class Initialized
INFO - 2021-02-26 08:13:32 --> Router Class Initialized
INFO - 2021-02-26 08:13:32 --> Output Class Initialized
INFO - 2021-02-26 08:13:32 --> Security Class Initialized
DEBUG - 2021-02-26 08:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:13:32 --> Input Class Initialized
INFO - 2021-02-26 08:13:32 --> Language Class Initialized
INFO - 2021-02-26 08:13:32 --> Language Class Initialized
INFO - 2021-02-26 08:13:32 --> Config Class Initialized
INFO - 2021-02-26 08:13:32 --> Loader Class Initialized
INFO - 2021-02-26 08:13:32 --> Helper loaded: url_helper
INFO - 2021-02-26 08:13:32 --> Helper loaded: file_helper
INFO - 2021-02-26 08:13:32 --> Helper loaded: form_helper
INFO - 2021-02-26 08:13:32 --> Helper loaded: my_helper
INFO - 2021-02-26 08:13:32 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:13:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:13:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:13:32 --> Controller Class Initialized
DEBUG - 2021-02-26 08:13:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-02-26 08:13:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 08:13:32 --> Final output sent to browser
DEBUG - 2021-02-26 08:13:33 --> Total execution time: 0.4069
INFO - 2021-02-26 08:13:38 --> Config Class Initialized
INFO - 2021-02-26 08:13:38 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:13:38 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:13:38 --> Utf8 Class Initialized
INFO - 2021-02-26 08:13:38 --> URI Class Initialized
INFO - 2021-02-26 08:13:38 --> Router Class Initialized
INFO - 2021-02-26 08:13:38 --> Output Class Initialized
INFO - 2021-02-26 08:13:38 --> Security Class Initialized
DEBUG - 2021-02-26 08:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:13:38 --> Input Class Initialized
INFO - 2021-02-26 08:13:38 --> Language Class Initialized
INFO - 2021-02-26 08:13:38 --> Language Class Initialized
INFO - 2021-02-26 08:13:38 --> Config Class Initialized
INFO - 2021-02-26 08:13:38 --> Loader Class Initialized
INFO - 2021-02-26 08:13:38 --> Helper loaded: url_helper
INFO - 2021-02-26 08:13:38 --> Helper loaded: file_helper
INFO - 2021-02-26 08:13:38 --> Helper loaded: form_helper
INFO - 2021-02-26 08:13:38 --> Helper loaded: my_helper
INFO - 2021-02-26 08:13:38 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:13:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:13:38 --> Controller Class Initialized
DEBUG - 2021-02-26 08:13:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-02-26 08:13:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 08:13:39 --> Final output sent to browser
DEBUG - 2021-02-26 08:13:39 --> Total execution time: 0.2861
INFO - 2021-02-26 08:13:40 --> Config Class Initialized
INFO - 2021-02-26 08:13:40 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:13:40 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:13:40 --> Utf8 Class Initialized
INFO - 2021-02-26 08:13:40 --> URI Class Initialized
INFO - 2021-02-26 08:13:40 --> Router Class Initialized
INFO - 2021-02-26 08:13:40 --> Output Class Initialized
INFO - 2021-02-26 08:13:40 --> Security Class Initialized
DEBUG - 2021-02-26 08:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:13:40 --> Input Class Initialized
INFO - 2021-02-26 08:13:40 --> Language Class Initialized
INFO - 2021-02-26 08:13:40 --> Language Class Initialized
INFO - 2021-02-26 08:13:40 --> Config Class Initialized
INFO - 2021-02-26 08:13:40 --> Loader Class Initialized
INFO - 2021-02-26 08:13:40 --> Helper loaded: url_helper
INFO - 2021-02-26 08:13:40 --> Helper loaded: file_helper
INFO - 2021-02-26 08:13:40 --> Helper loaded: form_helper
INFO - 2021-02-26 08:13:40 --> Helper loaded: my_helper
INFO - 2021-02-26 08:13:40 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:13:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:13:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:13:40 --> Controller Class Initialized
DEBUG - 2021-02-26 08:13:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-02-26 08:13:40 --> Final output sent to browser
DEBUG - 2021-02-26 08:13:40 --> Total execution time: 0.2963
INFO - 2021-02-26 08:46:07 --> Config Class Initialized
INFO - 2021-02-26 08:46:07 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:46:07 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:46:07 --> Utf8 Class Initialized
INFO - 2021-02-26 08:46:07 --> URI Class Initialized
INFO - 2021-02-26 08:46:07 --> Router Class Initialized
INFO - 2021-02-26 08:46:07 --> Output Class Initialized
INFO - 2021-02-26 08:46:07 --> Security Class Initialized
DEBUG - 2021-02-26 08:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:46:07 --> Input Class Initialized
INFO - 2021-02-26 08:46:07 --> Language Class Initialized
INFO - 2021-02-26 08:46:07 --> Language Class Initialized
INFO - 2021-02-26 08:46:07 --> Config Class Initialized
INFO - 2021-02-26 08:46:07 --> Loader Class Initialized
INFO - 2021-02-26 08:46:07 --> Helper loaded: url_helper
INFO - 2021-02-26 08:46:07 --> Helper loaded: file_helper
INFO - 2021-02-26 08:46:07 --> Helper loaded: form_helper
INFO - 2021-02-26 08:46:07 --> Helper loaded: my_helper
INFO - 2021-02-26 08:46:07 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:46:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:46:07 --> Controller Class Initialized
DEBUG - 2021-02-26 08:46:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-02-26 08:46:08 --> Final output sent to browser
DEBUG - 2021-02-26 08:46:08 --> Total execution time: 0.5427
INFO - 2021-02-26 08:46:08 --> Config Class Initialized
INFO - 2021-02-26 08:46:08 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:46:08 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:46:08 --> Utf8 Class Initialized
INFO - 2021-02-26 08:46:08 --> URI Class Initialized
INFO - 2021-02-26 08:46:08 --> Router Class Initialized
INFO - 2021-02-26 08:46:08 --> Output Class Initialized
INFO - 2021-02-26 08:46:08 --> Security Class Initialized
DEBUG - 2021-02-26 08:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:46:08 --> Input Class Initialized
INFO - 2021-02-26 08:46:08 --> Language Class Initialized
INFO - 2021-02-26 08:46:08 --> Language Class Initialized
INFO - 2021-02-26 08:46:08 --> Config Class Initialized
INFO - 2021-02-26 08:46:08 --> Loader Class Initialized
INFO - 2021-02-26 08:46:08 --> Helper loaded: url_helper
INFO - 2021-02-26 08:46:08 --> Helper loaded: file_helper
INFO - 2021-02-26 08:46:08 --> Helper loaded: form_helper
INFO - 2021-02-26 08:46:08 --> Helper loaded: my_helper
INFO - 2021-02-26 08:46:08 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:46:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:46:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:46:08 --> Controller Class Initialized
DEBUG - 2021-02-26 08:46:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-02-26 08:46:08 --> Final output sent to browser
DEBUG - 2021-02-26 08:46:08 --> Total execution time: 0.3848
INFO - 2021-02-26 08:46:09 --> Config Class Initialized
INFO - 2021-02-26 08:46:09 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:46:09 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:46:09 --> Utf8 Class Initialized
INFO - 2021-02-26 08:46:09 --> URI Class Initialized
INFO - 2021-02-26 08:46:09 --> Router Class Initialized
INFO - 2021-02-26 08:46:09 --> Output Class Initialized
INFO - 2021-02-26 08:46:09 --> Security Class Initialized
DEBUG - 2021-02-26 08:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:46:09 --> Input Class Initialized
INFO - 2021-02-26 08:46:09 --> Language Class Initialized
INFO - 2021-02-26 08:46:09 --> Language Class Initialized
INFO - 2021-02-26 08:46:09 --> Config Class Initialized
INFO - 2021-02-26 08:46:09 --> Loader Class Initialized
INFO - 2021-02-26 08:46:09 --> Helper loaded: url_helper
INFO - 2021-02-26 08:46:09 --> Helper loaded: file_helper
INFO - 2021-02-26 08:46:09 --> Helper loaded: form_helper
INFO - 2021-02-26 08:46:09 --> Helper loaded: my_helper
INFO - 2021-02-26 08:46:09 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:46:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:46:09 --> Controller Class Initialized
DEBUG - 2021-02-26 08:46:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-02-26 08:46:09 --> Final output sent to browser
DEBUG - 2021-02-26 08:46:09 --> Total execution time: 0.4365
INFO - 2021-02-26 08:46:10 --> Config Class Initialized
INFO - 2021-02-26 08:46:10 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:46:10 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:46:10 --> Utf8 Class Initialized
INFO - 2021-02-26 08:46:10 --> URI Class Initialized
INFO - 2021-02-26 08:46:10 --> Router Class Initialized
INFO - 2021-02-26 08:46:10 --> Output Class Initialized
INFO - 2021-02-26 08:46:10 --> Security Class Initialized
DEBUG - 2021-02-26 08:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:46:10 --> Input Class Initialized
INFO - 2021-02-26 08:46:10 --> Language Class Initialized
INFO - 2021-02-26 08:46:10 --> Language Class Initialized
INFO - 2021-02-26 08:46:10 --> Config Class Initialized
INFO - 2021-02-26 08:46:10 --> Loader Class Initialized
INFO - 2021-02-26 08:46:10 --> Helper loaded: url_helper
INFO - 2021-02-26 08:46:10 --> Helper loaded: file_helper
INFO - 2021-02-26 08:46:10 --> Helper loaded: form_helper
INFO - 2021-02-26 08:46:10 --> Helper loaded: my_helper
INFO - 2021-02-26 08:46:10 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:46:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:46:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:46:10 --> Controller Class Initialized
DEBUG - 2021-02-26 08:46:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-02-26 08:46:10 --> Final output sent to browser
DEBUG - 2021-02-26 08:46:10 --> Total execution time: 0.4148
INFO - 2021-02-26 08:46:11 --> Config Class Initialized
INFO - 2021-02-26 08:46:12 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:46:12 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:46:12 --> Utf8 Class Initialized
INFO - 2021-02-26 08:46:12 --> URI Class Initialized
INFO - 2021-02-26 08:46:12 --> Router Class Initialized
INFO - 2021-02-26 08:46:12 --> Output Class Initialized
INFO - 2021-02-26 08:46:12 --> Security Class Initialized
DEBUG - 2021-02-26 08:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:46:12 --> Input Class Initialized
INFO - 2021-02-26 08:46:12 --> Language Class Initialized
INFO - 2021-02-26 08:46:12 --> Language Class Initialized
INFO - 2021-02-26 08:46:12 --> Config Class Initialized
INFO - 2021-02-26 08:46:12 --> Loader Class Initialized
INFO - 2021-02-26 08:46:12 --> Helper loaded: url_helper
INFO - 2021-02-26 08:46:12 --> Helper loaded: file_helper
INFO - 2021-02-26 08:46:12 --> Helper loaded: form_helper
INFO - 2021-02-26 08:46:12 --> Helper loaded: my_helper
INFO - 2021-02-26 08:46:12 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:46:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:46:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:46:12 --> Controller Class Initialized
DEBUG - 2021-02-26 08:46:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-02-26 08:46:12 --> Final output sent to browser
DEBUG - 2021-02-26 08:46:12 --> Total execution time: 0.4590
INFO - 2021-02-26 08:46:13 --> Config Class Initialized
INFO - 2021-02-26 08:46:13 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:46:13 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:46:13 --> Utf8 Class Initialized
INFO - 2021-02-26 08:46:13 --> URI Class Initialized
INFO - 2021-02-26 08:46:13 --> Router Class Initialized
INFO - 2021-02-26 08:46:13 --> Output Class Initialized
INFO - 2021-02-26 08:46:13 --> Security Class Initialized
DEBUG - 2021-02-26 08:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:46:13 --> Input Class Initialized
INFO - 2021-02-26 08:46:13 --> Language Class Initialized
INFO - 2021-02-26 08:46:13 --> Language Class Initialized
INFO - 2021-02-26 08:46:13 --> Config Class Initialized
INFO - 2021-02-26 08:46:13 --> Loader Class Initialized
INFO - 2021-02-26 08:46:13 --> Helper loaded: url_helper
INFO - 2021-02-26 08:46:13 --> Helper loaded: file_helper
INFO - 2021-02-26 08:46:13 --> Helper loaded: form_helper
INFO - 2021-02-26 08:46:13 --> Helper loaded: my_helper
INFO - 2021-02-26 08:46:13 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:46:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:46:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:46:13 --> Controller Class Initialized
DEBUG - 2021-02-26 08:46:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2021-02-26 08:46:13 --> Final output sent to browser
DEBUG - 2021-02-26 08:46:13 --> Total execution time: 0.5274
INFO - 2021-02-26 08:46:14 --> Config Class Initialized
INFO - 2021-02-26 08:46:14 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:46:14 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:46:14 --> Utf8 Class Initialized
INFO - 2021-02-26 08:46:14 --> URI Class Initialized
INFO - 2021-02-26 08:46:14 --> Router Class Initialized
INFO - 2021-02-26 08:46:14 --> Output Class Initialized
INFO - 2021-02-26 08:46:14 --> Security Class Initialized
DEBUG - 2021-02-26 08:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:46:14 --> Input Class Initialized
INFO - 2021-02-26 08:46:14 --> Language Class Initialized
INFO - 2021-02-26 08:46:14 --> Language Class Initialized
INFO - 2021-02-26 08:46:14 --> Config Class Initialized
INFO - 2021-02-26 08:46:14 --> Loader Class Initialized
INFO - 2021-02-26 08:46:14 --> Helper loaded: url_helper
INFO - 2021-02-26 08:46:14 --> Helper loaded: file_helper
INFO - 2021-02-26 08:46:14 --> Helper loaded: form_helper
INFO - 2021-02-26 08:46:14 --> Helper loaded: my_helper
INFO - 2021-02-26 08:46:14 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:46:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:46:14 --> Controller Class Initialized
DEBUG - 2021-02-26 08:46:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-02-26 08:46:14 --> Final output sent to browser
DEBUG - 2021-02-26 08:46:14 --> Total execution time: 0.4314
INFO - 2021-02-26 08:46:15 --> Config Class Initialized
INFO - 2021-02-26 08:46:15 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:46:15 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:46:15 --> Utf8 Class Initialized
INFO - 2021-02-26 08:46:15 --> URI Class Initialized
INFO - 2021-02-26 08:46:15 --> Router Class Initialized
INFO - 2021-02-26 08:46:15 --> Output Class Initialized
INFO - 2021-02-26 08:46:15 --> Security Class Initialized
DEBUG - 2021-02-26 08:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:46:15 --> Input Class Initialized
INFO - 2021-02-26 08:46:15 --> Language Class Initialized
INFO - 2021-02-26 08:46:15 --> Language Class Initialized
INFO - 2021-02-26 08:46:15 --> Config Class Initialized
INFO - 2021-02-26 08:46:15 --> Loader Class Initialized
INFO - 2021-02-26 08:46:15 --> Helper loaded: url_helper
INFO - 2021-02-26 08:46:15 --> Helper loaded: file_helper
INFO - 2021-02-26 08:46:15 --> Helper loaded: form_helper
INFO - 2021-02-26 08:46:15 --> Helper loaded: my_helper
INFO - 2021-02-26 08:46:15 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:46:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:46:15 --> Controller Class Initialized
DEBUG - 2021-02-26 08:46:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-02-26 08:46:15 --> Final output sent to browser
DEBUG - 2021-02-26 08:46:15 --> Total execution time: 0.4709
INFO - 2021-02-26 08:46:16 --> Config Class Initialized
INFO - 2021-02-26 08:46:16 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:46:16 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:46:16 --> Utf8 Class Initialized
INFO - 2021-02-26 08:46:16 --> URI Class Initialized
INFO - 2021-02-26 08:46:16 --> Router Class Initialized
INFO - 2021-02-26 08:46:16 --> Output Class Initialized
INFO - 2021-02-26 08:46:16 --> Security Class Initialized
DEBUG - 2021-02-26 08:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:46:16 --> Input Class Initialized
INFO - 2021-02-26 08:46:16 --> Language Class Initialized
INFO - 2021-02-26 08:46:16 --> Language Class Initialized
INFO - 2021-02-26 08:46:16 --> Config Class Initialized
INFO - 2021-02-26 08:46:16 --> Loader Class Initialized
INFO - 2021-02-26 08:46:16 --> Helper loaded: url_helper
INFO - 2021-02-26 08:46:16 --> Helper loaded: file_helper
INFO - 2021-02-26 08:46:16 --> Helper loaded: form_helper
INFO - 2021-02-26 08:46:16 --> Helper loaded: my_helper
INFO - 2021-02-26 08:46:16 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:46:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:46:16 --> Controller Class Initialized
DEBUG - 2021-02-26 08:46:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-02-26 08:46:16 --> Final output sent to browser
DEBUG - 2021-02-26 08:46:16 --> Total execution time: 0.4736
INFO - 2021-02-26 08:46:17 --> Config Class Initialized
INFO - 2021-02-26 08:46:17 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:46:17 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:46:17 --> Utf8 Class Initialized
INFO - 2021-02-26 08:46:17 --> URI Class Initialized
INFO - 2021-02-26 08:46:17 --> Router Class Initialized
INFO - 2021-02-26 08:46:17 --> Output Class Initialized
INFO - 2021-02-26 08:46:17 --> Security Class Initialized
DEBUG - 2021-02-26 08:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:46:17 --> Input Class Initialized
INFO - 2021-02-26 08:46:17 --> Language Class Initialized
INFO - 2021-02-26 08:46:17 --> Language Class Initialized
INFO - 2021-02-26 08:46:17 --> Config Class Initialized
INFO - 2021-02-26 08:46:17 --> Loader Class Initialized
INFO - 2021-02-26 08:46:17 --> Helper loaded: url_helper
INFO - 2021-02-26 08:46:17 --> Helper loaded: file_helper
INFO - 2021-02-26 08:46:17 --> Helper loaded: form_helper
INFO - 2021-02-26 08:46:17 --> Helper loaded: my_helper
INFO - 2021-02-26 08:46:17 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:46:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:46:17 --> Controller Class Initialized
DEBUG - 2021-02-26 08:46:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-02-26 08:46:17 --> Final output sent to browser
DEBUG - 2021-02-26 08:46:17 --> Total execution time: 0.4390
INFO - 2021-02-26 08:46:18 --> Config Class Initialized
INFO - 2021-02-26 08:46:18 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:46:18 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:46:18 --> Utf8 Class Initialized
INFO - 2021-02-26 08:46:18 --> URI Class Initialized
INFO - 2021-02-26 08:46:18 --> Router Class Initialized
INFO - 2021-02-26 08:46:18 --> Output Class Initialized
INFO - 2021-02-26 08:46:18 --> Security Class Initialized
DEBUG - 2021-02-26 08:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:46:18 --> Input Class Initialized
INFO - 2021-02-26 08:46:18 --> Language Class Initialized
INFO - 2021-02-26 08:46:18 --> Language Class Initialized
INFO - 2021-02-26 08:46:18 --> Config Class Initialized
INFO - 2021-02-26 08:46:18 --> Loader Class Initialized
INFO - 2021-02-26 08:46:18 --> Helper loaded: url_helper
INFO - 2021-02-26 08:46:18 --> Helper loaded: file_helper
INFO - 2021-02-26 08:46:18 --> Helper loaded: form_helper
INFO - 2021-02-26 08:46:18 --> Helper loaded: my_helper
INFO - 2021-02-26 08:46:18 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:46:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:46:18 --> Controller Class Initialized
DEBUG - 2021-02-26 08:46:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-02-26 08:46:18 --> Final output sent to browser
DEBUG - 2021-02-26 08:46:18 --> Total execution time: 0.4824
INFO - 2021-02-26 08:46:19 --> Config Class Initialized
INFO - 2021-02-26 08:46:19 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:46:19 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:46:19 --> Utf8 Class Initialized
INFO - 2021-02-26 08:46:19 --> URI Class Initialized
INFO - 2021-02-26 08:46:19 --> Router Class Initialized
INFO - 2021-02-26 08:46:19 --> Output Class Initialized
INFO - 2021-02-26 08:46:19 --> Security Class Initialized
DEBUG - 2021-02-26 08:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:46:19 --> Input Class Initialized
INFO - 2021-02-26 08:46:19 --> Language Class Initialized
INFO - 2021-02-26 08:46:19 --> Language Class Initialized
INFO - 2021-02-26 08:46:19 --> Config Class Initialized
INFO - 2021-02-26 08:46:19 --> Loader Class Initialized
INFO - 2021-02-26 08:46:19 --> Helper loaded: url_helper
INFO - 2021-02-26 08:46:19 --> Helper loaded: file_helper
INFO - 2021-02-26 08:46:19 --> Helper loaded: form_helper
INFO - 2021-02-26 08:46:19 --> Helper loaded: my_helper
INFO - 2021-02-26 08:46:19 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:46:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:46:19 --> Controller Class Initialized
DEBUG - 2021-02-26 08:46:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-02-26 08:46:19 --> Final output sent to browser
DEBUG - 2021-02-26 08:46:19 --> Total execution time: 0.4518
INFO - 2021-02-26 08:48:28 --> Config Class Initialized
INFO - 2021-02-26 08:48:28 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:48:28 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:48:28 --> Utf8 Class Initialized
INFO - 2021-02-26 08:48:28 --> URI Class Initialized
INFO - 2021-02-26 08:48:28 --> Router Class Initialized
INFO - 2021-02-26 08:48:28 --> Output Class Initialized
INFO - 2021-02-26 08:48:28 --> Security Class Initialized
DEBUG - 2021-02-26 08:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:48:28 --> Input Class Initialized
INFO - 2021-02-26 08:48:28 --> Language Class Initialized
INFO - 2021-02-26 08:48:28 --> Language Class Initialized
INFO - 2021-02-26 08:48:28 --> Config Class Initialized
INFO - 2021-02-26 08:48:28 --> Loader Class Initialized
INFO - 2021-02-26 08:48:28 --> Helper loaded: url_helper
INFO - 2021-02-26 08:48:28 --> Helper loaded: file_helper
INFO - 2021-02-26 08:48:28 --> Helper loaded: form_helper
INFO - 2021-02-26 08:48:28 --> Helper loaded: my_helper
INFO - 2021-02-26 08:48:28 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:48:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:48:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:48:28 --> Controller Class Initialized
DEBUG - 2021-02-26 08:48:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-02-26 08:48:29 --> Final output sent to browser
DEBUG - 2021-02-26 08:48:29 --> Total execution time: 0.3234
INFO - 2021-02-26 08:49:01 --> Config Class Initialized
INFO - 2021-02-26 08:49:01 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:49:01 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:49:01 --> Utf8 Class Initialized
INFO - 2021-02-26 08:49:01 --> URI Class Initialized
INFO - 2021-02-26 08:49:01 --> Router Class Initialized
INFO - 2021-02-26 08:49:01 --> Output Class Initialized
INFO - 2021-02-26 08:49:01 --> Security Class Initialized
DEBUG - 2021-02-26 08:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:49:01 --> Input Class Initialized
INFO - 2021-02-26 08:49:01 --> Language Class Initialized
INFO - 2021-02-26 08:49:01 --> Language Class Initialized
INFO - 2021-02-26 08:49:01 --> Config Class Initialized
INFO - 2021-02-26 08:49:02 --> Loader Class Initialized
INFO - 2021-02-26 08:49:02 --> Helper loaded: url_helper
INFO - 2021-02-26 08:49:02 --> Helper loaded: file_helper
INFO - 2021-02-26 08:49:02 --> Helper loaded: form_helper
INFO - 2021-02-26 08:49:02 --> Helper loaded: my_helper
INFO - 2021-02-26 08:49:02 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:49:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:49:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:49:02 --> Controller Class Initialized
DEBUG - 2021-02-26 08:49:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-02-26 08:49:02 --> Final output sent to browser
DEBUG - 2021-02-26 08:49:02 --> Total execution time: 0.3358
INFO - 2021-02-26 08:49:19 --> Config Class Initialized
INFO - 2021-02-26 08:49:19 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:49:19 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:49:19 --> Utf8 Class Initialized
INFO - 2021-02-26 08:49:19 --> URI Class Initialized
INFO - 2021-02-26 08:49:19 --> Router Class Initialized
INFO - 2021-02-26 08:49:19 --> Output Class Initialized
INFO - 2021-02-26 08:49:19 --> Security Class Initialized
DEBUG - 2021-02-26 08:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:49:19 --> Input Class Initialized
INFO - 2021-02-26 08:49:19 --> Language Class Initialized
INFO - 2021-02-26 08:49:19 --> Language Class Initialized
INFO - 2021-02-26 08:49:19 --> Config Class Initialized
INFO - 2021-02-26 08:49:19 --> Loader Class Initialized
INFO - 2021-02-26 08:49:19 --> Helper loaded: url_helper
INFO - 2021-02-26 08:49:19 --> Helper loaded: file_helper
INFO - 2021-02-26 08:49:19 --> Helper loaded: form_helper
INFO - 2021-02-26 08:49:19 --> Helper loaded: my_helper
INFO - 2021-02-26 08:49:19 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:49:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:49:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:49:19 --> Controller Class Initialized
DEBUG - 2021-02-26 08:49:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-02-26 08:49:19 --> Final output sent to browser
DEBUG - 2021-02-26 08:49:19 --> Total execution time: 0.4062
INFO - 2021-02-26 08:49:34 --> Config Class Initialized
INFO - 2021-02-26 08:49:34 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:49:34 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:49:34 --> Utf8 Class Initialized
INFO - 2021-02-26 08:49:34 --> URI Class Initialized
INFO - 2021-02-26 08:49:34 --> Router Class Initialized
INFO - 2021-02-26 08:49:34 --> Output Class Initialized
INFO - 2021-02-26 08:49:34 --> Security Class Initialized
DEBUG - 2021-02-26 08:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:49:34 --> Input Class Initialized
INFO - 2021-02-26 08:49:34 --> Language Class Initialized
INFO - 2021-02-26 08:49:34 --> Language Class Initialized
INFO - 2021-02-26 08:49:34 --> Config Class Initialized
INFO - 2021-02-26 08:49:34 --> Loader Class Initialized
INFO - 2021-02-26 08:49:34 --> Helper loaded: url_helper
INFO - 2021-02-26 08:49:34 --> Helper loaded: file_helper
INFO - 2021-02-26 08:49:34 --> Helper loaded: form_helper
INFO - 2021-02-26 08:49:34 --> Helper loaded: my_helper
INFO - 2021-02-26 08:49:34 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:49:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:49:34 --> Controller Class Initialized
DEBUG - 2021-02-26 08:49:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-02-26 08:49:34 --> Final output sent to browser
DEBUG - 2021-02-26 08:49:34 --> Total execution time: 0.3293
INFO - 2021-02-26 08:49:45 --> Config Class Initialized
INFO - 2021-02-26 08:49:45 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:49:45 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:49:45 --> Utf8 Class Initialized
INFO - 2021-02-26 08:49:45 --> URI Class Initialized
INFO - 2021-02-26 08:49:45 --> Router Class Initialized
INFO - 2021-02-26 08:49:45 --> Output Class Initialized
INFO - 2021-02-26 08:49:45 --> Security Class Initialized
DEBUG - 2021-02-26 08:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:49:45 --> Input Class Initialized
INFO - 2021-02-26 08:49:45 --> Language Class Initialized
INFO - 2021-02-26 08:49:45 --> Language Class Initialized
INFO - 2021-02-26 08:49:45 --> Config Class Initialized
INFO - 2021-02-26 08:49:45 --> Loader Class Initialized
INFO - 2021-02-26 08:49:45 --> Helper loaded: url_helper
INFO - 2021-02-26 08:49:45 --> Helper loaded: file_helper
INFO - 2021-02-26 08:49:45 --> Helper loaded: form_helper
INFO - 2021-02-26 08:49:45 --> Helper loaded: my_helper
INFO - 2021-02-26 08:49:45 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:49:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:49:45 --> Controller Class Initialized
DEBUG - 2021-02-26 08:49:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-02-26 08:49:46 --> Final output sent to browser
DEBUG - 2021-02-26 08:49:46 --> Total execution time: 0.3756
INFO - 2021-02-26 08:49:53 --> Config Class Initialized
INFO - 2021-02-26 08:49:53 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:49:53 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:49:53 --> Utf8 Class Initialized
INFO - 2021-02-26 08:49:53 --> URI Class Initialized
INFO - 2021-02-26 08:49:53 --> Router Class Initialized
INFO - 2021-02-26 08:49:53 --> Output Class Initialized
INFO - 2021-02-26 08:49:53 --> Security Class Initialized
DEBUG - 2021-02-26 08:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:49:53 --> Input Class Initialized
INFO - 2021-02-26 08:49:53 --> Language Class Initialized
INFO - 2021-02-26 08:49:53 --> Language Class Initialized
INFO - 2021-02-26 08:49:53 --> Config Class Initialized
INFO - 2021-02-26 08:49:53 --> Loader Class Initialized
INFO - 2021-02-26 08:49:53 --> Helper loaded: url_helper
INFO - 2021-02-26 08:49:53 --> Helper loaded: file_helper
INFO - 2021-02-26 08:49:53 --> Helper loaded: form_helper
INFO - 2021-02-26 08:49:53 --> Helper loaded: my_helper
INFO - 2021-02-26 08:49:53 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:49:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:49:53 --> Controller Class Initialized
DEBUG - 2021-02-26 08:49:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-02-26 08:49:53 --> Final output sent to browser
DEBUG - 2021-02-26 08:49:53 --> Total execution time: 0.3864
INFO - 2021-02-26 08:50:24 --> Config Class Initialized
INFO - 2021-02-26 08:50:24 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:50:24 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:50:24 --> Utf8 Class Initialized
INFO - 2021-02-26 08:50:24 --> URI Class Initialized
INFO - 2021-02-26 08:50:24 --> Router Class Initialized
INFO - 2021-02-26 08:50:24 --> Output Class Initialized
INFO - 2021-02-26 08:50:24 --> Security Class Initialized
DEBUG - 2021-02-26 08:50:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:50:24 --> Input Class Initialized
INFO - 2021-02-26 08:50:24 --> Language Class Initialized
INFO - 2021-02-26 08:50:24 --> Language Class Initialized
INFO - 2021-02-26 08:50:24 --> Config Class Initialized
INFO - 2021-02-26 08:50:24 --> Loader Class Initialized
INFO - 2021-02-26 08:50:24 --> Helper loaded: url_helper
INFO - 2021-02-26 08:50:25 --> Helper loaded: file_helper
INFO - 2021-02-26 08:50:25 --> Helper loaded: form_helper
INFO - 2021-02-26 08:50:25 --> Helper loaded: my_helper
INFO - 2021-02-26 08:50:25 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:50:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:50:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:50:25 --> Controller Class Initialized
DEBUG - 2021-02-26 08:50:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-02-26 08:50:25 --> Final output sent to browser
DEBUG - 2021-02-26 08:50:25 --> Total execution time: 0.3741
INFO - 2021-02-26 08:50:43 --> Config Class Initialized
INFO - 2021-02-26 08:50:43 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:50:43 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:50:43 --> Utf8 Class Initialized
INFO - 2021-02-26 08:50:43 --> URI Class Initialized
INFO - 2021-02-26 08:50:43 --> Router Class Initialized
INFO - 2021-02-26 08:50:43 --> Output Class Initialized
INFO - 2021-02-26 08:50:43 --> Security Class Initialized
DEBUG - 2021-02-26 08:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:50:43 --> Input Class Initialized
INFO - 2021-02-26 08:50:43 --> Language Class Initialized
INFO - 2021-02-26 08:50:43 --> Language Class Initialized
INFO - 2021-02-26 08:50:43 --> Config Class Initialized
INFO - 2021-02-26 08:50:43 --> Loader Class Initialized
INFO - 2021-02-26 08:50:43 --> Helper loaded: url_helper
INFO - 2021-02-26 08:50:43 --> Helper loaded: file_helper
INFO - 2021-02-26 08:50:43 --> Helper loaded: form_helper
INFO - 2021-02-26 08:50:43 --> Helper loaded: my_helper
INFO - 2021-02-26 08:50:43 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:50:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:50:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:50:43 --> Controller Class Initialized
DEBUG - 2021-02-26 08:50:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-02-26 08:50:44 --> Final output sent to browser
DEBUG - 2021-02-26 08:50:44 --> Total execution time: 0.4121
INFO - 2021-02-26 08:50:58 --> Config Class Initialized
INFO - 2021-02-26 08:50:58 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:50:58 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:50:58 --> Utf8 Class Initialized
INFO - 2021-02-26 08:50:58 --> URI Class Initialized
INFO - 2021-02-26 08:50:58 --> Router Class Initialized
INFO - 2021-02-26 08:50:58 --> Output Class Initialized
INFO - 2021-02-26 08:50:58 --> Security Class Initialized
DEBUG - 2021-02-26 08:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:50:58 --> Input Class Initialized
INFO - 2021-02-26 08:50:58 --> Language Class Initialized
INFO - 2021-02-26 08:50:58 --> Language Class Initialized
INFO - 2021-02-26 08:50:58 --> Config Class Initialized
INFO - 2021-02-26 08:50:58 --> Loader Class Initialized
INFO - 2021-02-26 08:50:58 --> Helper loaded: url_helper
INFO - 2021-02-26 08:50:58 --> Helper loaded: file_helper
INFO - 2021-02-26 08:50:58 --> Helper loaded: form_helper
INFO - 2021-02-26 08:50:58 --> Helper loaded: my_helper
INFO - 2021-02-26 08:50:58 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:50:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:50:58 --> Controller Class Initialized
DEBUG - 2021-02-26 08:50:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-02-26 08:50:58 --> Final output sent to browser
DEBUG - 2021-02-26 08:50:58 --> Total execution time: 0.4226
INFO - 2021-02-26 08:51:40 --> Config Class Initialized
INFO - 2021-02-26 08:51:40 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:51:40 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:51:40 --> Utf8 Class Initialized
INFO - 2021-02-26 08:51:40 --> URI Class Initialized
INFO - 2021-02-26 08:51:40 --> Router Class Initialized
INFO - 2021-02-26 08:51:40 --> Output Class Initialized
INFO - 2021-02-26 08:51:40 --> Security Class Initialized
DEBUG - 2021-02-26 08:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:51:40 --> Input Class Initialized
INFO - 2021-02-26 08:51:40 --> Language Class Initialized
INFO - 2021-02-26 08:51:40 --> Language Class Initialized
INFO - 2021-02-26 08:51:40 --> Config Class Initialized
INFO - 2021-02-26 08:51:41 --> Loader Class Initialized
INFO - 2021-02-26 08:51:41 --> Helper loaded: url_helper
INFO - 2021-02-26 08:51:41 --> Helper loaded: file_helper
INFO - 2021-02-26 08:51:41 --> Helper loaded: form_helper
INFO - 2021-02-26 08:51:41 --> Helper loaded: my_helper
INFO - 2021-02-26 08:51:41 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:51:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:51:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:51:41 --> Controller Class Initialized
DEBUG - 2021-02-26 08:51:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-02-26 08:51:41 --> Final output sent to browser
DEBUG - 2021-02-26 08:51:41 --> Total execution time: 0.3623
INFO - 2021-02-26 08:51:50 --> Config Class Initialized
INFO - 2021-02-26 08:51:50 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:51:50 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:51:50 --> Utf8 Class Initialized
INFO - 2021-02-26 08:51:50 --> URI Class Initialized
INFO - 2021-02-26 08:51:50 --> Router Class Initialized
INFO - 2021-02-26 08:51:50 --> Output Class Initialized
INFO - 2021-02-26 08:51:50 --> Security Class Initialized
DEBUG - 2021-02-26 08:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:51:50 --> Input Class Initialized
INFO - 2021-02-26 08:51:50 --> Language Class Initialized
INFO - 2021-02-26 08:51:50 --> Language Class Initialized
INFO - 2021-02-26 08:51:50 --> Config Class Initialized
INFO - 2021-02-26 08:51:50 --> Loader Class Initialized
INFO - 2021-02-26 08:51:50 --> Helper loaded: url_helper
INFO - 2021-02-26 08:51:50 --> Helper loaded: file_helper
INFO - 2021-02-26 08:51:50 --> Helper loaded: form_helper
INFO - 2021-02-26 08:51:50 --> Helper loaded: my_helper
INFO - 2021-02-26 08:51:50 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:51:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:51:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:51:50 --> Controller Class Initialized
DEBUG - 2021-02-26 08:51:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-02-26 08:51:50 --> Final output sent to browser
DEBUG - 2021-02-26 08:51:50 --> Total execution time: 0.3204
INFO - 2021-02-26 08:52:00 --> Config Class Initialized
INFO - 2021-02-26 08:52:00 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:52:00 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:52:00 --> Utf8 Class Initialized
INFO - 2021-02-26 08:52:00 --> URI Class Initialized
INFO - 2021-02-26 08:52:00 --> Router Class Initialized
INFO - 2021-02-26 08:52:00 --> Output Class Initialized
INFO - 2021-02-26 08:52:00 --> Security Class Initialized
DEBUG - 2021-02-26 08:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:52:00 --> Input Class Initialized
INFO - 2021-02-26 08:52:00 --> Language Class Initialized
INFO - 2021-02-26 08:52:00 --> Language Class Initialized
INFO - 2021-02-26 08:52:00 --> Config Class Initialized
INFO - 2021-02-26 08:52:00 --> Loader Class Initialized
INFO - 2021-02-26 08:52:00 --> Helper loaded: url_helper
INFO - 2021-02-26 08:52:00 --> Helper loaded: file_helper
INFO - 2021-02-26 08:52:00 --> Helper loaded: form_helper
INFO - 2021-02-26 08:52:00 --> Helper loaded: my_helper
INFO - 2021-02-26 08:52:00 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:52:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:52:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:52:00 --> Controller Class Initialized
DEBUG - 2021-02-26 08:52:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-02-26 08:52:00 --> Final output sent to browser
DEBUG - 2021-02-26 08:52:00 --> Total execution time: 0.3107
INFO - 2021-02-26 08:52:18 --> Config Class Initialized
INFO - 2021-02-26 08:52:18 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:52:18 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:52:18 --> Utf8 Class Initialized
INFO - 2021-02-26 08:52:18 --> URI Class Initialized
INFO - 2021-02-26 08:52:19 --> Router Class Initialized
INFO - 2021-02-26 08:52:19 --> Output Class Initialized
INFO - 2021-02-26 08:52:19 --> Security Class Initialized
DEBUG - 2021-02-26 08:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:52:19 --> Input Class Initialized
INFO - 2021-02-26 08:52:19 --> Language Class Initialized
INFO - 2021-02-26 08:52:19 --> Language Class Initialized
INFO - 2021-02-26 08:52:19 --> Config Class Initialized
INFO - 2021-02-26 08:52:19 --> Loader Class Initialized
INFO - 2021-02-26 08:52:19 --> Helper loaded: url_helper
INFO - 2021-02-26 08:52:19 --> Helper loaded: file_helper
INFO - 2021-02-26 08:52:19 --> Helper loaded: form_helper
INFO - 2021-02-26 08:52:19 --> Helper loaded: my_helper
INFO - 2021-02-26 08:52:19 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:52:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:52:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:52:19 --> Controller Class Initialized
DEBUG - 2021-02-26 08:52:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-02-26 08:52:19 --> Final output sent to browser
DEBUG - 2021-02-26 08:52:19 --> Total execution time: 0.3541
INFO - 2021-02-26 08:53:06 --> Config Class Initialized
INFO - 2021-02-26 08:53:06 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:53:06 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:53:06 --> Utf8 Class Initialized
INFO - 2021-02-26 08:53:06 --> URI Class Initialized
INFO - 2021-02-26 08:53:06 --> Router Class Initialized
INFO - 2021-02-26 08:53:06 --> Output Class Initialized
INFO - 2021-02-26 08:53:06 --> Security Class Initialized
DEBUG - 2021-02-26 08:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:53:06 --> Input Class Initialized
INFO - 2021-02-26 08:53:06 --> Language Class Initialized
INFO - 2021-02-26 08:53:06 --> Language Class Initialized
INFO - 2021-02-26 08:53:06 --> Config Class Initialized
INFO - 2021-02-26 08:53:06 --> Loader Class Initialized
INFO - 2021-02-26 08:53:06 --> Helper loaded: url_helper
INFO - 2021-02-26 08:53:06 --> Helper loaded: file_helper
INFO - 2021-02-26 08:53:06 --> Helper loaded: form_helper
INFO - 2021-02-26 08:53:06 --> Helper loaded: my_helper
INFO - 2021-02-26 08:53:06 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:53:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:53:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:53:06 --> Controller Class Initialized
DEBUG - 2021-02-26 08:53:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-02-26 08:53:07 --> Final output sent to browser
DEBUG - 2021-02-26 08:53:07 --> Total execution time: 0.3201
INFO - 2021-02-26 08:53:16 --> Config Class Initialized
INFO - 2021-02-26 08:53:16 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:53:16 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:53:16 --> Utf8 Class Initialized
INFO - 2021-02-26 08:53:16 --> URI Class Initialized
INFO - 2021-02-26 08:53:16 --> Router Class Initialized
INFO - 2021-02-26 08:53:16 --> Output Class Initialized
INFO - 2021-02-26 08:53:16 --> Security Class Initialized
DEBUG - 2021-02-26 08:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:53:16 --> Input Class Initialized
INFO - 2021-02-26 08:53:16 --> Language Class Initialized
INFO - 2021-02-26 08:53:17 --> Language Class Initialized
INFO - 2021-02-26 08:53:17 --> Config Class Initialized
INFO - 2021-02-26 08:53:17 --> Loader Class Initialized
INFO - 2021-02-26 08:53:17 --> Helper loaded: url_helper
INFO - 2021-02-26 08:53:17 --> Helper loaded: file_helper
INFO - 2021-02-26 08:53:17 --> Helper loaded: form_helper
INFO - 2021-02-26 08:53:17 --> Helper loaded: my_helper
INFO - 2021-02-26 08:53:17 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:53:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:53:17 --> Controller Class Initialized
DEBUG - 2021-02-26 08:53:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-02-26 08:53:17 --> Final output sent to browser
DEBUG - 2021-02-26 08:53:17 --> Total execution time: 0.3039
INFO - 2021-02-26 08:53:32 --> Config Class Initialized
INFO - 2021-02-26 08:53:32 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:53:32 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:53:32 --> Utf8 Class Initialized
INFO - 2021-02-26 08:53:32 --> URI Class Initialized
INFO - 2021-02-26 08:53:32 --> Router Class Initialized
INFO - 2021-02-26 08:53:32 --> Output Class Initialized
INFO - 2021-02-26 08:53:32 --> Security Class Initialized
DEBUG - 2021-02-26 08:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:53:32 --> Input Class Initialized
INFO - 2021-02-26 08:53:32 --> Language Class Initialized
INFO - 2021-02-26 08:53:32 --> Language Class Initialized
INFO - 2021-02-26 08:53:32 --> Config Class Initialized
INFO - 2021-02-26 08:53:32 --> Loader Class Initialized
INFO - 2021-02-26 08:53:32 --> Helper loaded: url_helper
INFO - 2021-02-26 08:53:32 --> Helper loaded: file_helper
INFO - 2021-02-26 08:53:32 --> Helper loaded: form_helper
INFO - 2021-02-26 08:53:32 --> Helper loaded: my_helper
INFO - 2021-02-26 08:53:32 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:53:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:53:32 --> Controller Class Initialized
DEBUG - 2021-02-26 08:53:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-02-26 08:53:32 --> Final output sent to browser
DEBUG - 2021-02-26 08:53:32 --> Total execution time: 0.3297
INFO - 2021-02-26 08:54:08 --> Config Class Initialized
INFO - 2021-02-26 08:54:08 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:54:08 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:54:08 --> Utf8 Class Initialized
INFO - 2021-02-26 08:54:08 --> URI Class Initialized
INFO - 2021-02-26 08:54:08 --> Router Class Initialized
INFO - 2021-02-26 08:54:08 --> Output Class Initialized
INFO - 2021-02-26 08:54:08 --> Security Class Initialized
DEBUG - 2021-02-26 08:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:54:08 --> Input Class Initialized
INFO - 2021-02-26 08:54:08 --> Language Class Initialized
INFO - 2021-02-26 08:54:08 --> Language Class Initialized
INFO - 2021-02-26 08:54:08 --> Config Class Initialized
INFO - 2021-02-26 08:54:08 --> Loader Class Initialized
INFO - 2021-02-26 08:54:08 --> Helper loaded: url_helper
INFO - 2021-02-26 08:54:08 --> Helper loaded: file_helper
INFO - 2021-02-26 08:54:08 --> Helper loaded: form_helper
INFO - 2021-02-26 08:54:08 --> Helper loaded: my_helper
INFO - 2021-02-26 08:54:08 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:54:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:54:08 --> Controller Class Initialized
DEBUG - 2021-02-26 08:54:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-02-26 08:54:08 --> Final output sent to browser
DEBUG - 2021-02-26 08:54:08 --> Total execution time: 0.3347
INFO - 2021-02-26 08:54:21 --> Config Class Initialized
INFO - 2021-02-26 08:54:21 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:54:21 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:54:21 --> Utf8 Class Initialized
INFO - 2021-02-26 08:54:21 --> URI Class Initialized
INFO - 2021-02-26 08:54:21 --> Router Class Initialized
INFO - 2021-02-26 08:54:21 --> Output Class Initialized
INFO - 2021-02-26 08:54:21 --> Security Class Initialized
DEBUG - 2021-02-26 08:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:54:21 --> Input Class Initialized
INFO - 2021-02-26 08:54:21 --> Language Class Initialized
INFO - 2021-02-26 08:54:21 --> Language Class Initialized
INFO - 2021-02-26 08:54:21 --> Config Class Initialized
INFO - 2021-02-26 08:54:21 --> Loader Class Initialized
INFO - 2021-02-26 08:54:21 --> Helper loaded: url_helper
INFO - 2021-02-26 08:54:21 --> Helper loaded: file_helper
INFO - 2021-02-26 08:54:21 --> Helper loaded: form_helper
INFO - 2021-02-26 08:54:21 --> Helper loaded: my_helper
INFO - 2021-02-26 08:54:21 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:54:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:54:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:54:21 --> Controller Class Initialized
DEBUG - 2021-02-26 08:54:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-02-26 08:54:21 --> Final output sent to browser
DEBUG - 2021-02-26 08:54:21 --> Total execution time: 0.3302
INFO - 2021-02-26 08:54:31 --> Config Class Initialized
INFO - 2021-02-26 08:54:31 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:54:31 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:54:31 --> Utf8 Class Initialized
INFO - 2021-02-26 08:54:31 --> URI Class Initialized
INFO - 2021-02-26 08:54:31 --> Router Class Initialized
INFO - 2021-02-26 08:54:31 --> Output Class Initialized
INFO - 2021-02-26 08:54:31 --> Security Class Initialized
DEBUG - 2021-02-26 08:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:54:31 --> Input Class Initialized
INFO - 2021-02-26 08:54:32 --> Language Class Initialized
INFO - 2021-02-26 08:54:32 --> Language Class Initialized
INFO - 2021-02-26 08:54:32 --> Config Class Initialized
INFO - 2021-02-26 08:54:32 --> Loader Class Initialized
INFO - 2021-02-26 08:54:32 --> Helper loaded: url_helper
INFO - 2021-02-26 08:54:32 --> Helper loaded: file_helper
INFO - 2021-02-26 08:54:32 --> Helper loaded: form_helper
INFO - 2021-02-26 08:54:32 --> Helper loaded: my_helper
INFO - 2021-02-26 08:54:32 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:54:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:54:32 --> Controller Class Initialized
DEBUG - 2021-02-26 08:54:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-02-26 08:54:32 --> Final output sent to browser
DEBUG - 2021-02-26 08:54:32 --> Total execution time: 0.3280
INFO - 2021-02-26 08:55:08 --> Config Class Initialized
INFO - 2021-02-26 08:55:08 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:55:08 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:55:08 --> Utf8 Class Initialized
INFO - 2021-02-26 08:55:08 --> URI Class Initialized
INFO - 2021-02-26 08:55:08 --> Router Class Initialized
INFO - 2021-02-26 08:55:08 --> Output Class Initialized
INFO - 2021-02-26 08:55:08 --> Security Class Initialized
DEBUG - 2021-02-26 08:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:55:08 --> Input Class Initialized
INFO - 2021-02-26 08:55:08 --> Language Class Initialized
INFO - 2021-02-26 08:55:08 --> Language Class Initialized
INFO - 2021-02-26 08:55:08 --> Config Class Initialized
INFO - 2021-02-26 08:55:08 --> Loader Class Initialized
INFO - 2021-02-26 08:55:08 --> Helper loaded: url_helper
INFO - 2021-02-26 08:55:08 --> Helper loaded: file_helper
INFO - 2021-02-26 08:55:08 --> Helper loaded: form_helper
INFO - 2021-02-26 08:55:08 --> Helper loaded: my_helper
INFO - 2021-02-26 08:55:08 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:55:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:55:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:55:08 --> Controller Class Initialized
DEBUG - 2021-02-26 08:55:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-02-26 08:55:08 --> Final output sent to browser
DEBUG - 2021-02-26 08:55:08 --> Total execution time: 0.3838
INFO - 2021-02-26 08:56:22 --> Config Class Initialized
INFO - 2021-02-26 08:56:22 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:56:22 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:56:22 --> Utf8 Class Initialized
INFO - 2021-02-26 08:56:22 --> URI Class Initialized
INFO - 2021-02-26 08:56:22 --> Router Class Initialized
INFO - 2021-02-26 08:56:22 --> Output Class Initialized
INFO - 2021-02-26 08:56:22 --> Security Class Initialized
DEBUG - 2021-02-26 08:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:56:22 --> Input Class Initialized
INFO - 2021-02-26 08:56:22 --> Language Class Initialized
INFO - 2021-02-26 08:56:22 --> Language Class Initialized
INFO - 2021-02-26 08:56:22 --> Config Class Initialized
INFO - 2021-02-26 08:56:22 --> Loader Class Initialized
INFO - 2021-02-26 08:56:22 --> Helper loaded: url_helper
INFO - 2021-02-26 08:56:22 --> Helper loaded: file_helper
INFO - 2021-02-26 08:56:22 --> Helper loaded: form_helper
INFO - 2021-02-26 08:56:22 --> Helper loaded: my_helper
INFO - 2021-02-26 08:56:22 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:56:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:56:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:56:22 --> Controller Class Initialized
DEBUG - 2021-02-26 08:56:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-02-26 08:56:22 --> Final output sent to browser
DEBUG - 2021-02-26 08:56:22 --> Total execution time: 0.3155
INFO - 2021-02-26 08:56:43 --> Config Class Initialized
INFO - 2021-02-26 08:56:43 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:56:43 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:56:43 --> Utf8 Class Initialized
INFO - 2021-02-26 08:56:43 --> URI Class Initialized
INFO - 2021-02-26 08:56:43 --> Router Class Initialized
INFO - 2021-02-26 08:56:44 --> Output Class Initialized
INFO - 2021-02-26 08:56:44 --> Security Class Initialized
DEBUG - 2021-02-26 08:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:56:44 --> Input Class Initialized
INFO - 2021-02-26 08:56:44 --> Language Class Initialized
INFO - 2021-02-26 08:56:44 --> Language Class Initialized
INFO - 2021-02-26 08:56:44 --> Config Class Initialized
INFO - 2021-02-26 08:56:44 --> Loader Class Initialized
INFO - 2021-02-26 08:56:44 --> Helper loaded: url_helper
INFO - 2021-02-26 08:56:44 --> Helper loaded: file_helper
INFO - 2021-02-26 08:56:44 --> Helper loaded: form_helper
INFO - 2021-02-26 08:56:44 --> Helper loaded: my_helper
INFO - 2021-02-26 08:56:44 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:56:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:56:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:56:44 --> Controller Class Initialized
DEBUG - 2021-02-26 08:56:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-02-26 08:56:44 --> Final output sent to browser
DEBUG - 2021-02-26 08:56:44 --> Total execution time: 0.3010
INFO - 2021-02-26 08:57:15 --> Config Class Initialized
INFO - 2021-02-26 08:57:15 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:57:15 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:57:15 --> Utf8 Class Initialized
INFO - 2021-02-26 08:57:15 --> URI Class Initialized
INFO - 2021-02-26 08:57:15 --> Router Class Initialized
INFO - 2021-02-26 08:57:15 --> Output Class Initialized
INFO - 2021-02-26 08:57:15 --> Security Class Initialized
DEBUG - 2021-02-26 08:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:57:15 --> Input Class Initialized
INFO - 2021-02-26 08:57:15 --> Language Class Initialized
INFO - 2021-02-26 08:57:15 --> Language Class Initialized
INFO - 2021-02-26 08:57:15 --> Config Class Initialized
INFO - 2021-02-26 08:57:15 --> Loader Class Initialized
INFO - 2021-02-26 08:57:15 --> Helper loaded: url_helper
INFO - 2021-02-26 08:57:15 --> Helper loaded: file_helper
INFO - 2021-02-26 08:57:15 --> Helper loaded: form_helper
INFO - 2021-02-26 08:57:15 --> Helper loaded: my_helper
INFO - 2021-02-26 08:57:15 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:57:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:57:15 --> Controller Class Initialized
DEBUG - 2021-02-26 08:57:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-02-26 08:57:15 --> Final output sent to browser
DEBUG - 2021-02-26 08:57:15 --> Total execution time: 0.3924
INFO - 2021-02-26 08:57:55 --> Config Class Initialized
INFO - 2021-02-26 08:57:55 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:57:55 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:57:55 --> Utf8 Class Initialized
INFO - 2021-02-26 08:57:55 --> URI Class Initialized
INFO - 2021-02-26 08:57:55 --> Router Class Initialized
INFO - 2021-02-26 08:57:55 --> Output Class Initialized
INFO - 2021-02-26 08:57:55 --> Security Class Initialized
DEBUG - 2021-02-26 08:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:57:55 --> Input Class Initialized
INFO - 2021-02-26 08:57:55 --> Language Class Initialized
INFO - 2021-02-26 08:57:55 --> Language Class Initialized
INFO - 2021-02-26 08:57:55 --> Config Class Initialized
INFO - 2021-02-26 08:57:55 --> Loader Class Initialized
INFO - 2021-02-26 08:57:55 --> Helper loaded: url_helper
INFO - 2021-02-26 08:57:55 --> Helper loaded: file_helper
INFO - 2021-02-26 08:57:55 --> Helper loaded: form_helper
INFO - 2021-02-26 08:57:55 --> Helper loaded: my_helper
INFO - 2021-02-26 08:57:55 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:57:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:57:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:57:55 --> Controller Class Initialized
DEBUG - 2021-02-26 08:57:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-02-26 08:57:55 --> Final output sent to browser
DEBUG - 2021-02-26 08:57:55 --> Total execution time: 0.3256
INFO - 2021-02-26 08:58:47 --> Config Class Initialized
INFO - 2021-02-26 08:58:47 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:58:48 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:58:48 --> Utf8 Class Initialized
INFO - 2021-02-26 08:58:48 --> URI Class Initialized
INFO - 2021-02-26 08:58:48 --> Router Class Initialized
INFO - 2021-02-26 08:58:48 --> Output Class Initialized
INFO - 2021-02-26 08:58:48 --> Security Class Initialized
DEBUG - 2021-02-26 08:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:58:48 --> Input Class Initialized
INFO - 2021-02-26 08:58:48 --> Language Class Initialized
INFO - 2021-02-26 08:58:48 --> Language Class Initialized
INFO - 2021-02-26 08:58:48 --> Config Class Initialized
INFO - 2021-02-26 08:58:48 --> Loader Class Initialized
INFO - 2021-02-26 08:58:48 --> Helper loaded: url_helper
INFO - 2021-02-26 08:58:48 --> Helper loaded: file_helper
INFO - 2021-02-26 08:58:48 --> Helper loaded: form_helper
INFO - 2021-02-26 08:58:48 --> Helper loaded: my_helper
INFO - 2021-02-26 08:58:48 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:58:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:58:48 --> Controller Class Initialized
DEBUG - 2021-02-26 08:58:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-02-26 08:58:48 --> Final output sent to browser
DEBUG - 2021-02-26 08:58:48 --> Total execution time: 0.4082
INFO - 2021-02-26 08:59:01 --> Config Class Initialized
INFO - 2021-02-26 08:59:01 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:59:01 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:59:01 --> Utf8 Class Initialized
INFO - 2021-02-26 08:59:01 --> URI Class Initialized
INFO - 2021-02-26 08:59:01 --> Router Class Initialized
INFO - 2021-02-26 08:59:01 --> Output Class Initialized
INFO - 2021-02-26 08:59:01 --> Security Class Initialized
DEBUG - 2021-02-26 08:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:59:01 --> Input Class Initialized
INFO - 2021-02-26 08:59:01 --> Language Class Initialized
INFO - 2021-02-26 08:59:01 --> Language Class Initialized
INFO - 2021-02-26 08:59:01 --> Config Class Initialized
INFO - 2021-02-26 08:59:01 --> Loader Class Initialized
INFO - 2021-02-26 08:59:01 --> Helper loaded: url_helper
INFO - 2021-02-26 08:59:01 --> Helper loaded: file_helper
INFO - 2021-02-26 08:59:01 --> Helper loaded: form_helper
INFO - 2021-02-26 08:59:01 --> Helper loaded: my_helper
INFO - 2021-02-26 08:59:01 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:59:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:59:01 --> Controller Class Initialized
DEBUG - 2021-02-26 08:59:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-02-26 08:59:01 --> Final output sent to browser
DEBUG - 2021-02-26 08:59:01 --> Total execution time: 0.3113
INFO - 2021-02-26 08:59:22 --> Config Class Initialized
INFO - 2021-02-26 08:59:22 --> Hooks Class Initialized
DEBUG - 2021-02-26 08:59:22 --> UTF-8 Support Enabled
INFO - 2021-02-26 08:59:22 --> Utf8 Class Initialized
INFO - 2021-02-26 08:59:22 --> URI Class Initialized
INFO - 2021-02-26 08:59:22 --> Router Class Initialized
INFO - 2021-02-26 08:59:22 --> Output Class Initialized
INFO - 2021-02-26 08:59:22 --> Security Class Initialized
DEBUG - 2021-02-26 08:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 08:59:22 --> Input Class Initialized
INFO - 2021-02-26 08:59:22 --> Language Class Initialized
INFO - 2021-02-26 08:59:22 --> Language Class Initialized
INFO - 2021-02-26 08:59:22 --> Config Class Initialized
INFO - 2021-02-26 08:59:22 --> Loader Class Initialized
INFO - 2021-02-26 08:59:22 --> Helper loaded: url_helper
INFO - 2021-02-26 08:59:22 --> Helper loaded: file_helper
INFO - 2021-02-26 08:59:22 --> Helper loaded: form_helper
INFO - 2021-02-26 08:59:22 --> Helper loaded: my_helper
INFO - 2021-02-26 08:59:22 --> Database Driver Class Initialized
DEBUG - 2021-02-26 08:59:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 08:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 08:59:22 --> Controller Class Initialized
DEBUG - 2021-02-26 08:59:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-02-26 08:59:22 --> Final output sent to browser
DEBUG - 2021-02-26 08:59:23 --> Total execution time: 0.3198
INFO - 2021-02-26 09:00:03 --> Config Class Initialized
INFO - 2021-02-26 09:00:03 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:00:03 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:00:03 --> Utf8 Class Initialized
INFO - 2021-02-26 09:00:03 --> URI Class Initialized
INFO - 2021-02-26 09:00:03 --> Router Class Initialized
INFO - 2021-02-26 09:00:03 --> Output Class Initialized
INFO - 2021-02-26 09:00:03 --> Security Class Initialized
DEBUG - 2021-02-26 09:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:00:03 --> Input Class Initialized
INFO - 2021-02-26 09:00:03 --> Language Class Initialized
INFO - 2021-02-26 09:00:03 --> Language Class Initialized
INFO - 2021-02-26 09:00:03 --> Config Class Initialized
INFO - 2021-02-26 09:00:03 --> Loader Class Initialized
INFO - 2021-02-26 09:00:03 --> Helper loaded: url_helper
INFO - 2021-02-26 09:00:03 --> Helper loaded: file_helper
INFO - 2021-02-26 09:00:03 --> Helper loaded: form_helper
INFO - 2021-02-26 09:00:03 --> Helper loaded: my_helper
INFO - 2021-02-26 09:00:03 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:00:03 --> Controller Class Initialized
DEBUG - 2021-02-26 09:00:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-02-26 09:00:03 --> Final output sent to browser
DEBUG - 2021-02-26 09:00:03 --> Total execution time: 0.3156
INFO - 2021-02-26 09:00:29 --> Config Class Initialized
INFO - 2021-02-26 09:00:29 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:00:29 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:00:29 --> Utf8 Class Initialized
INFO - 2021-02-26 09:00:29 --> URI Class Initialized
INFO - 2021-02-26 09:00:29 --> Router Class Initialized
INFO - 2021-02-26 09:00:29 --> Output Class Initialized
INFO - 2021-02-26 09:00:29 --> Security Class Initialized
DEBUG - 2021-02-26 09:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:00:29 --> Input Class Initialized
INFO - 2021-02-26 09:00:29 --> Language Class Initialized
INFO - 2021-02-26 09:00:29 --> Language Class Initialized
INFO - 2021-02-26 09:00:29 --> Config Class Initialized
INFO - 2021-02-26 09:00:29 --> Loader Class Initialized
INFO - 2021-02-26 09:00:29 --> Helper loaded: url_helper
INFO - 2021-02-26 09:00:29 --> Helper loaded: file_helper
INFO - 2021-02-26 09:00:29 --> Helper loaded: form_helper
INFO - 2021-02-26 09:00:29 --> Helper loaded: my_helper
INFO - 2021-02-26 09:00:29 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:00:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:00:29 --> Controller Class Initialized
DEBUG - 2021-02-26 09:00:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-02-26 09:00:29 --> Final output sent to browser
DEBUG - 2021-02-26 09:00:29 --> Total execution time: 0.3287
INFO - 2021-02-26 09:00:45 --> Config Class Initialized
INFO - 2021-02-26 09:00:45 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:00:45 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:00:45 --> Utf8 Class Initialized
INFO - 2021-02-26 09:00:45 --> URI Class Initialized
INFO - 2021-02-26 09:00:45 --> Router Class Initialized
INFO - 2021-02-26 09:00:45 --> Output Class Initialized
INFO - 2021-02-26 09:00:45 --> Security Class Initialized
DEBUG - 2021-02-26 09:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:00:45 --> Input Class Initialized
INFO - 2021-02-26 09:00:45 --> Language Class Initialized
INFO - 2021-02-26 09:00:45 --> Language Class Initialized
INFO - 2021-02-26 09:00:45 --> Config Class Initialized
INFO - 2021-02-26 09:00:45 --> Loader Class Initialized
INFO - 2021-02-26 09:00:45 --> Helper loaded: url_helper
INFO - 2021-02-26 09:00:45 --> Helper loaded: file_helper
INFO - 2021-02-26 09:00:45 --> Helper loaded: form_helper
INFO - 2021-02-26 09:00:45 --> Helper loaded: my_helper
INFO - 2021-02-26 09:00:45 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:00:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:00:45 --> Controller Class Initialized
DEBUG - 2021-02-26 09:00:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-02-26 09:00:45 --> Final output sent to browser
DEBUG - 2021-02-26 09:00:45 --> Total execution time: 0.3153
INFO - 2021-02-26 09:02:24 --> Config Class Initialized
INFO - 2021-02-26 09:02:24 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:02:24 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:02:24 --> Utf8 Class Initialized
INFO - 2021-02-26 09:02:24 --> URI Class Initialized
INFO - 2021-02-26 09:02:24 --> Router Class Initialized
INFO - 2021-02-26 09:02:24 --> Output Class Initialized
INFO - 2021-02-26 09:02:24 --> Security Class Initialized
DEBUG - 2021-02-26 09:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:02:24 --> Input Class Initialized
INFO - 2021-02-26 09:02:24 --> Language Class Initialized
INFO - 2021-02-26 09:02:24 --> Language Class Initialized
INFO - 2021-02-26 09:02:24 --> Config Class Initialized
INFO - 2021-02-26 09:02:24 --> Loader Class Initialized
INFO - 2021-02-26 09:02:24 --> Helper loaded: url_helper
INFO - 2021-02-26 09:02:24 --> Helper loaded: file_helper
INFO - 2021-02-26 09:02:24 --> Helper loaded: form_helper
INFO - 2021-02-26 09:02:24 --> Helper loaded: my_helper
INFO - 2021-02-26 09:02:24 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:02:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:02:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:02:24 --> Controller Class Initialized
DEBUG - 2021-02-26 09:02:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-02-26 09:02:24 --> Final output sent to browser
DEBUG - 2021-02-26 09:02:24 --> Total execution time: 0.3349
INFO - 2021-02-26 09:03:04 --> Config Class Initialized
INFO - 2021-02-26 09:03:04 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:03:04 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:03:04 --> Utf8 Class Initialized
INFO - 2021-02-26 09:03:04 --> URI Class Initialized
INFO - 2021-02-26 09:03:04 --> Router Class Initialized
INFO - 2021-02-26 09:03:04 --> Output Class Initialized
INFO - 2021-02-26 09:03:04 --> Security Class Initialized
DEBUG - 2021-02-26 09:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:03:04 --> Input Class Initialized
INFO - 2021-02-26 09:03:04 --> Language Class Initialized
INFO - 2021-02-26 09:03:04 --> Language Class Initialized
INFO - 2021-02-26 09:03:04 --> Config Class Initialized
INFO - 2021-02-26 09:03:04 --> Loader Class Initialized
INFO - 2021-02-26 09:03:04 --> Helper loaded: url_helper
INFO - 2021-02-26 09:03:04 --> Helper loaded: file_helper
INFO - 2021-02-26 09:03:05 --> Helper loaded: form_helper
INFO - 2021-02-26 09:03:05 --> Helper loaded: my_helper
INFO - 2021-02-26 09:03:05 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:03:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:03:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:03:05 --> Controller Class Initialized
DEBUG - 2021-02-26 09:03:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-02-26 09:03:05 --> Final output sent to browser
DEBUG - 2021-02-26 09:03:05 --> Total execution time: 0.3208
INFO - 2021-02-26 09:03:20 --> Config Class Initialized
INFO - 2021-02-26 09:03:20 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:03:21 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:03:21 --> Utf8 Class Initialized
INFO - 2021-02-26 09:03:21 --> URI Class Initialized
INFO - 2021-02-26 09:03:21 --> Router Class Initialized
INFO - 2021-02-26 09:03:21 --> Output Class Initialized
INFO - 2021-02-26 09:03:21 --> Security Class Initialized
DEBUG - 2021-02-26 09:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:03:21 --> Input Class Initialized
INFO - 2021-02-26 09:03:21 --> Language Class Initialized
INFO - 2021-02-26 09:03:21 --> Language Class Initialized
INFO - 2021-02-26 09:03:21 --> Config Class Initialized
INFO - 2021-02-26 09:03:21 --> Loader Class Initialized
INFO - 2021-02-26 09:03:21 --> Helper loaded: url_helper
INFO - 2021-02-26 09:03:21 --> Helper loaded: file_helper
INFO - 2021-02-26 09:03:21 --> Helper loaded: form_helper
INFO - 2021-02-26 09:03:21 --> Helper loaded: my_helper
INFO - 2021-02-26 09:03:21 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:03:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:03:21 --> Controller Class Initialized
DEBUG - 2021-02-26 09:03:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-02-26 09:03:21 --> Final output sent to browser
DEBUG - 2021-02-26 09:03:21 --> Total execution time: 0.3026
INFO - 2021-02-26 09:04:24 --> Config Class Initialized
INFO - 2021-02-26 09:04:24 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:04:24 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:04:24 --> Utf8 Class Initialized
INFO - 2021-02-26 09:04:24 --> URI Class Initialized
INFO - 2021-02-26 09:04:24 --> Router Class Initialized
INFO - 2021-02-26 09:04:24 --> Output Class Initialized
INFO - 2021-02-26 09:04:24 --> Security Class Initialized
DEBUG - 2021-02-26 09:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:04:24 --> Input Class Initialized
INFO - 2021-02-26 09:04:24 --> Language Class Initialized
INFO - 2021-02-26 09:04:24 --> Language Class Initialized
INFO - 2021-02-26 09:04:24 --> Config Class Initialized
INFO - 2021-02-26 09:04:24 --> Loader Class Initialized
INFO - 2021-02-26 09:04:24 --> Helper loaded: url_helper
INFO - 2021-02-26 09:04:24 --> Helper loaded: file_helper
INFO - 2021-02-26 09:04:24 --> Helper loaded: form_helper
INFO - 2021-02-26 09:04:24 --> Helper loaded: my_helper
INFO - 2021-02-26 09:04:24 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:04:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:04:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:04:24 --> Controller Class Initialized
DEBUG - 2021-02-26 09:04:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-02-26 09:04:24 --> Final output sent to browser
DEBUG - 2021-02-26 09:04:24 --> Total execution time: 0.2879
INFO - 2021-02-26 09:04:39 --> Config Class Initialized
INFO - 2021-02-26 09:04:39 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:04:39 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:04:39 --> Utf8 Class Initialized
INFO - 2021-02-26 09:04:39 --> URI Class Initialized
INFO - 2021-02-26 09:04:39 --> Router Class Initialized
INFO - 2021-02-26 09:04:39 --> Output Class Initialized
INFO - 2021-02-26 09:04:39 --> Security Class Initialized
DEBUG - 2021-02-26 09:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:04:39 --> Input Class Initialized
INFO - 2021-02-26 09:04:39 --> Language Class Initialized
INFO - 2021-02-26 09:04:39 --> Language Class Initialized
INFO - 2021-02-26 09:04:39 --> Config Class Initialized
INFO - 2021-02-26 09:04:39 --> Loader Class Initialized
INFO - 2021-02-26 09:04:40 --> Helper loaded: url_helper
INFO - 2021-02-26 09:04:40 --> Helper loaded: file_helper
INFO - 2021-02-26 09:04:40 --> Helper loaded: form_helper
INFO - 2021-02-26 09:04:40 --> Helper loaded: my_helper
INFO - 2021-02-26 09:04:40 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:04:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:04:40 --> Controller Class Initialized
DEBUG - 2021-02-26 09:04:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-02-26 09:04:40 --> Final output sent to browser
DEBUG - 2021-02-26 09:04:40 --> Total execution time: 0.2892
INFO - 2021-02-26 09:05:13 --> Config Class Initialized
INFO - 2021-02-26 09:05:13 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:05:13 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:05:13 --> Utf8 Class Initialized
INFO - 2021-02-26 09:05:13 --> URI Class Initialized
INFO - 2021-02-26 09:05:13 --> Router Class Initialized
INFO - 2021-02-26 09:05:13 --> Output Class Initialized
INFO - 2021-02-26 09:05:13 --> Security Class Initialized
DEBUG - 2021-02-26 09:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:05:13 --> Input Class Initialized
INFO - 2021-02-26 09:05:13 --> Language Class Initialized
INFO - 2021-02-26 09:05:14 --> Language Class Initialized
INFO - 2021-02-26 09:05:14 --> Config Class Initialized
INFO - 2021-02-26 09:05:14 --> Loader Class Initialized
INFO - 2021-02-26 09:05:14 --> Helper loaded: url_helper
INFO - 2021-02-26 09:05:14 --> Helper loaded: file_helper
INFO - 2021-02-26 09:05:14 --> Helper loaded: form_helper
INFO - 2021-02-26 09:05:14 --> Helper loaded: my_helper
INFO - 2021-02-26 09:05:14 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:05:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:05:14 --> Controller Class Initialized
DEBUG - 2021-02-26 09:05:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-02-26 09:05:14 --> Final output sent to browser
DEBUG - 2021-02-26 09:05:14 --> Total execution time: 0.3327
INFO - 2021-02-26 09:05:31 --> Config Class Initialized
INFO - 2021-02-26 09:05:31 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:05:31 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:05:31 --> Utf8 Class Initialized
INFO - 2021-02-26 09:05:31 --> URI Class Initialized
INFO - 2021-02-26 09:05:31 --> Router Class Initialized
INFO - 2021-02-26 09:05:31 --> Output Class Initialized
INFO - 2021-02-26 09:05:31 --> Security Class Initialized
DEBUG - 2021-02-26 09:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:05:31 --> Input Class Initialized
INFO - 2021-02-26 09:05:31 --> Language Class Initialized
INFO - 2021-02-26 09:05:31 --> Language Class Initialized
INFO - 2021-02-26 09:05:31 --> Config Class Initialized
INFO - 2021-02-26 09:05:31 --> Loader Class Initialized
INFO - 2021-02-26 09:05:31 --> Helper loaded: url_helper
INFO - 2021-02-26 09:05:31 --> Helper loaded: file_helper
INFO - 2021-02-26 09:05:31 --> Helper loaded: form_helper
INFO - 2021-02-26 09:05:31 --> Helper loaded: my_helper
INFO - 2021-02-26 09:05:31 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:05:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:05:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:05:31 --> Controller Class Initialized
DEBUG - 2021-02-26 09:05:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-02-26 09:05:31 --> Final output sent to browser
DEBUG - 2021-02-26 09:05:31 --> Total execution time: 0.3132
INFO - 2021-02-26 09:05:43 --> Config Class Initialized
INFO - 2021-02-26 09:05:43 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:05:43 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:05:43 --> Utf8 Class Initialized
INFO - 2021-02-26 09:05:43 --> URI Class Initialized
INFO - 2021-02-26 09:05:43 --> Router Class Initialized
INFO - 2021-02-26 09:05:43 --> Output Class Initialized
INFO - 2021-02-26 09:05:43 --> Security Class Initialized
DEBUG - 2021-02-26 09:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:05:43 --> Input Class Initialized
INFO - 2021-02-26 09:05:43 --> Language Class Initialized
INFO - 2021-02-26 09:05:43 --> Language Class Initialized
INFO - 2021-02-26 09:05:43 --> Config Class Initialized
INFO - 2021-02-26 09:05:43 --> Loader Class Initialized
INFO - 2021-02-26 09:05:43 --> Helper loaded: url_helper
INFO - 2021-02-26 09:05:43 --> Helper loaded: file_helper
INFO - 2021-02-26 09:05:43 --> Helper loaded: form_helper
INFO - 2021-02-26 09:05:43 --> Helper loaded: my_helper
INFO - 2021-02-26 09:05:43 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:05:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:05:43 --> Controller Class Initialized
DEBUG - 2021-02-26 09:05:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-02-26 09:05:43 --> Final output sent to browser
DEBUG - 2021-02-26 09:05:43 --> Total execution time: 0.3130
INFO - 2021-02-26 09:06:11 --> Config Class Initialized
INFO - 2021-02-26 09:06:11 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:06:11 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:06:11 --> Utf8 Class Initialized
INFO - 2021-02-26 09:06:11 --> URI Class Initialized
INFO - 2021-02-26 09:06:11 --> Router Class Initialized
INFO - 2021-02-26 09:06:11 --> Output Class Initialized
INFO - 2021-02-26 09:06:11 --> Security Class Initialized
DEBUG - 2021-02-26 09:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:06:11 --> Input Class Initialized
INFO - 2021-02-26 09:06:11 --> Language Class Initialized
INFO - 2021-02-26 09:06:11 --> Language Class Initialized
INFO - 2021-02-26 09:06:11 --> Config Class Initialized
INFO - 2021-02-26 09:06:11 --> Loader Class Initialized
INFO - 2021-02-26 09:06:11 --> Helper loaded: url_helper
INFO - 2021-02-26 09:06:11 --> Helper loaded: file_helper
INFO - 2021-02-26 09:06:11 --> Helper loaded: form_helper
INFO - 2021-02-26 09:06:11 --> Helper loaded: my_helper
INFO - 2021-02-26 09:06:11 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:06:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:06:11 --> Controller Class Initialized
DEBUG - 2021-02-26 09:06:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-02-26 09:06:11 --> Final output sent to browser
DEBUG - 2021-02-26 09:06:11 --> Total execution time: 0.3153
INFO - 2021-02-26 09:06:23 --> Config Class Initialized
INFO - 2021-02-26 09:06:23 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:06:23 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:06:23 --> Utf8 Class Initialized
INFO - 2021-02-26 09:06:23 --> URI Class Initialized
INFO - 2021-02-26 09:06:23 --> Router Class Initialized
INFO - 2021-02-26 09:06:23 --> Output Class Initialized
INFO - 2021-02-26 09:06:24 --> Security Class Initialized
DEBUG - 2021-02-26 09:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:06:24 --> Input Class Initialized
INFO - 2021-02-26 09:06:24 --> Language Class Initialized
INFO - 2021-02-26 09:06:24 --> Language Class Initialized
INFO - 2021-02-26 09:06:24 --> Config Class Initialized
INFO - 2021-02-26 09:06:24 --> Loader Class Initialized
INFO - 2021-02-26 09:06:24 --> Helper loaded: url_helper
INFO - 2021-02-26 09:06:24 --> Helper loaded: file_helper
INFO - 2021-02-26 09:06:24 --> Helper loaded: form_helper
INFO - 2021-02-26 09:06:24 --> Helper loaded: my_helper
INFO - 2021-02-26 09:06:24 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:06:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:06:24 --> Controller Class Initialized
DEBUG - 2021-02-26 09:06:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-02-26 09:06:24 --> Final output sent to browser
DEBUG - 2021-02-26 09:06:24 --> Total execution time: 0.2950
INFO - 2021-02-26 09:06:33 --> Config Class Initialized
INFO - 2021-02-26 09:06:34 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:06:34 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:06:34 --> Utf8 Class Initialized
INFO - 2021-02-26 09:06:34 --> URI Class Initialized
INFO - 2021-02-26 09:06:34 --> Router Class Initialized
INFO - 2021-02-26 09:06:34 --> Output Class Initialized
INFO - 2021-02-26 09:06:34 --> Security Class Initialized
DEBUG - 2021-02-26 09:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:06:34 --> Input Class Initialized
INFO - 2021-02-26 09:06:34 --> Language Class Initialized
INFO - 2021-02-26 09:06:34 --> Language Class Initialized
INFO - 2021-02-26 09:06:34 --> Config Class Initialized
INFO - 2021-02-26 09:06:34 --> Loader Class Initialized
INFO - 2021-02-26 09:06:34 --> Helper loaded: url_helper
INFO - 2021-02-26 09:06:34 --> Helper loaded: file_helper
INFO - 2021-02-26 09:06:34 --> Helper loaded: form_helper
INFO - 2021-02-26 09:06:34 --> Helper loaded: my_helper
INFO - 2021-02-26 09:06:34 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:06:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:06:34 --> Controller Class Initialized
DEBUG - 2021-02-26 09:06:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-02-26 09:06:34 --> Final output sent to browser
DEBUG - 2021-02-26 09:06:34 --> Total execution time: 0.3032
INFO - 2021-02-26 09:06:44 --> Config Class Initialized
INFO - 2021-02-26 09:06:44 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:06:44 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:06:44 --> Utf8 Class Initialized
INFO - 2021-02-26 09:06:44 --> URI Class Initialized
INFO - 2021-02-26 09:06:44 --> Router Class Initialized
INFO - 2021-02-26 09:06:44 --> Output Class Initialized
INFO - 2021-02-26 09:06:44 --> Security Class Initialized
DEBUG - 2021-02-26 09:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:06:44 --> Input Class Initialized
INFO - 2021-02-26 09:06:44 --> Language Class Initialized
INFO - 2021-02-26 09:06:44 --> Language Class Initialized
INFO - 2021-02-26 09:06:44 --> Config Class Initialized
INFO - 2021-02-26 09:06:44 --> Loader Class Initialized
INFO - 2021-02-26 09:06:44 --> Helper loaded: url_helper
INFO - 2021-02-26 09:06:44 --> Helper loaded: file_helper
INFO - 2021-02-26 09:06:44 --> Helper loaded: form_helper
INFO - 2021-02-26 09:06:44 --> Helper loaded: my_helper
INFO - 2021-02-26 09:06:44 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:06:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:06:44 --> Controller Class Initialized
DEBUG - 2021-02-26 09:06:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-02-26 09:06:44 --> Final output sent to browser
DEBUG - 2021-02-26 09:06:44 --> Total execution time: 0.3122
INFO - 2021-02-26 09:06:54 --> Config Class Initialized
INFO - 2021-02-26 09:06:54 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:06:54 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:06:54 --> Utf8 Class Initialized
INFO - 2021-02-26 09:06:54 --> URI Class Initialized
INFO - 2021-02-26 09:06:54 --> Router Class Initialized
INFO - 2021-02-26 09:06:54 --> Output Class Initialized
INFO - 2021-02-26 09:06:54 --> Security Class Initialized
DEBUG - 2021-02-26 09:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:06:54 --> Input Class Initialized
INFO - 2021-02-26 09:06:54 --> Language Class Initialized
INFO - 2021-02-26 09:06:54 --> Language Class Initialized
INFO - 2021-02-26 09:06:54 --> Config Class Initialized
INFO - 2021-02-26 09:06:54 --> Loader Class Initialized
INFO - 2021-02-26 09:06:54 --> Helper loaded: url_helper
INFO - 2021-02-26 09:06:54 --> Helper loaded: file_helper
INFO - 2021-02-26 09:06:54 --> Helper loaded: form_helper
INFO - 2021-02-26 09:06:54 --> Helper loaded: my_helper
INFO - 2021-02-26 09:06:54 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:06:54 --> Controller Class Initialized
DEBUG - 2021-02-26 09:06:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-02-26 09:06:54 --> Final output sent to browser
DEBUG - 2021-02-26 09:06:54 --> Total execution time: 0.3050
INFO - 2021-02-26 09:07:06 --> Config Class Initialized
INFO - 2021-02-26 09:07:06 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:07:06 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:07:06 --> Utf8 Class Initialized
INFO - 2021-02-26 09:07:06 --> URI Class Initialized
INFO - 2021-02-26 09:07:06 --> Router Class Initialized
INFO - 2021-02-26 09:07:06 --> Output Class Initialized
INFO - 2021-02-26 09:07:06 --> Security Class Initialized
DEBUG - 2021-02-26 09:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:07:06 --> Input Class Initialized
INFO - 2021-02-26 09:07:06 --> Language Class Initialized
INFO - 2021-02-26 09:07:06 --> Language Class Initialized
INFO - 2021-02-26 09:07:06 --> Config Class Initialized
INFO - 2021-02-26 09:07:06 --> Loader Class Initialized
INFO - 2021-02-26 09:07:06 --> Helper loaded: url_helper
INFO - 2021-02-26 09:07:06 --> Helper loaded: file_helper
INFO - 2021-02-26 09:07:06 --> Helper loaded: form_helper
INFO - 2021-02-26 09:07:06 --> Helper loaded: my_helper
INFO - 2021-02-26 09:07:06 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:07:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:07:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:07:06 --> Controller Class Initialized
DEBUG - 2021-02-26 09:07:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-02-26 09:07:06 --> Final output sent to browser
DEBUG - 2021-02-26 09:07:06 --> Total execution time: 0.2922
INFO - 2021-02-26 09:08:13 --> Config Class Initialized
INFO - 2021-02-26 09:08:13 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:08:13 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:08:13 --> Utf8 Class Initialized
INFO - 2021-02-26 09:08:13 --> URI Class Initialized
INFO - 2021-02-26 09:08:13 --> Router Class Initialized
INFO - 2021-02-26 09:08:13 --> Output Class Initialized
INFO - 2021-02-26 09:08:13 --> Security Class Initialized
DEBUG - 2021-02-26 09:08:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:08:13 --> Input Class Initialized
INFO - 2021-02-26 09:08:13 --> Language Class Initialized
INFO - 2021-02-26 09:08:13 --> Language Class Initialized
INFO - 2021-02-26 09:08:13 --> Config Class Initialized
INFO - 2021-02-26 09:08:13 --> Loader Class Initialized
INFO - 2021-02-26 09:08:13 --> Helper loaded: url_helper
INFO - 2021-02-26 09:08:13 --> Helper loaded: file_helper
INFO - 2021-02-26 09:08:13 --> Helper loaded: form_helper
INFO - 2021-02-26 09:08:13 --> Helper loaded: my_helper
INFO - 2021-02-26 09:08:13 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:08:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:08:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:08:13 --> Controller Class Initialized
DEBUG - 2021-02-26 09:08:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2021-02-26 09:08:13 --> Final output sent to browser
DEBUG - 2021-02-26 09:08:13 --> Total execution time: 0.3118
INFO - 2021-02-26 09:08:30 --> Config Class Initialized
INFO - 2021-02-26 09:08:30 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:08:30 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:08:30 --> Utf8 Class Initialized
INFO - 2021-02-26 09:08:30 --> URI Class Initialized
INFO - 2021-02-26 09:08:30 --> Router Class Initialized
INFO - 2021-02-26 09:08:30 --> Output Class Initialized
INFO - 2021-02-26 09:08:30 --> Security Class Initialized
DEBUG - 2021-02-26 09:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:08:30 --> Input Class Initialized
INFO - 2021-02-26 09:08:30 --> Language Class Initialized
INFO - 2021-02-26 09:08:31 --> Language Class Initialized
INFO - 2021-02-26 09:08:31 --> Config Class Initialized
INFO - 2021-02-26 09:08:31 --> Loader Class Initialized
INFO - 2021-02-26 09:08:31 --> Helper loaded: url_helper
INFO - 2021-02-26 09:08:31 --> Helper loaded: file_helper
INFO - 2021-02-26 09:08:31 --> Helper loaded: form_helper
INFO - 2021-02-26 09:08:31 --> Helper loaded: my_helper
INFO - 2021-02-26 09:08:31 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:08:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:08:31 --> Controller Class Initialized
DEBUG - 2021-02-26 09:08:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2021-02-26 09:08:31 --> Final output sent to browser
DEBUG - 2021-02-26 09:08:31 --> Total execution time: 0.2948
INFO - 2021-02-26 09:08:41 --> Config Class Initialized
INFO - 2021-02-26 09:08:41 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:08:41 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:08:41 --> Utf8 Class Initialized
INFO - 2021-02-26 09:08:41 --> URI Class Initialized
INFO - 2021-02-26 09:08:42 --> Router Class Initialized
INFO - 2021-02-26 09:08:42 --> Output Class Initialized
INFO - 2021-02-26 09:08:42 --> Security Class Initialized
DEBUG - 2021-02-26 09:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:08:42 --> Input Class Initialized
INFO - 2021-02-26 09:08:42 --> Language Class Initialized
INFO - 2021-02-26 09:08:42 --> Language Class Initialized
INFO - 2021-02-26 09:08:42 --> Config Class Initialized
INFO - 2021-02-26 09:08:42 --> Loader Class Initialized
INFO - 2021-02-26 09:08:42 --> Helper loaded: url_helper
INFO - 2021-02-26 09:08:42 --> Helper loaded: file_helper
INFO - 2021-02-26 09:08:42 --> Helper loaded: form_helper
INFO - 2021-02-26 09:08:42 --> Helper loaded: my_helper
INFO - 2021-02-26 09:08:42 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:08:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:08:42 --> Controller Class Initialized
DEBUG - 2021-02-26 09:08:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2021-02-26 09:08:42 --> Final output sent to browser
DEBUG - 2021-02-26 09:08:42 --> Total execution time: 0.3010
INFO - 2021-02-26 09:09:17 --> Config Class Initialized
INFO - 2021-02-26 09:09:17 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:09:17 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:09:17 --> Utf8 Class Initialized
INFO - 2021-02-26 09:09:17 --> URI Class Initialized
INFO - 2021-02-26 09:09:17 --> Router Class Initialized
INFO - 2021-02-26 09:09:17 --> Output Class Initialized
INFO - 2021-02-26 09:09:17 --> Security Class Initialized
DEBUG - 2021-02-26 09:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:09:17 --> Input Class Initialized
INFO - 2021-02-26 09:09:17 --> Language Class Initialized
INFO - 2021-02-26 09:09:18 --> Language Class Initialized
INFO - 2021-02-26 09:09:18 --> Config Class Initialized
INFO - 2021-02-26 09:09:18 --> Loader Class Initialized
INFO - 2021-02-26 09:09:18 --> Helper loaded: url_helper
INFO - 2021-02-26 09:09:18 --> Helper loaded: file_helper
INFO - 2021-02-26 09:09:18 --> Helper loaded: form_helper
INFO - 2021-02-26 09:09:18 --> Helper loaded: my_helper
INFO - 2021-02-26 09:09:18 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:09:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:09:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:09:18 --> Controller Class Initialized
DEBUG - 2021-02-26 09:09:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-02-26 09:09:18 --> Final output sent to browser
DEBUG - 2021-02-26 09:09:18 --> Total execution time: 0.2968
INFO - 2021-02-26 09:09:47 --> Config Class Initialized
INFO - 2021-02-26 09:09:47 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:09:47 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:09:47 --> Utf8 Class Initialized
INFO - 2021-02-26 09:09:47 --> URI Class Initialized
INFO - 2021-02-26 09:09:47 --> Router Class Initialized
INFO - 2021-02-26 09:09:47 --> Output Class Initialized
INFO - 2021-02-26 09:09:47 --> Security Class Initialized
DEBUG - 2021-02-26 09:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:09:47 --> Input Class Initialized
INFO - 2021-02-26 09:09:47 --> Language Class Initialized
INFO - 2021-02-26 09:09:47 --> Language Class Initialized
INFO - 2021-02-26 09:09:47 --> Config Class Initialized
INFO - 2021-02-26 09:09:47 --> Loader Class Initialized
INFO - 2021-02-26 09:09:47 --> Helper loaded: url_helper
INFO - 2021-02-26 09:09:47 --> Helper loaded: file_helper
INFO - 2021-02-26 09:09:47 --> Helper loaded: form_helper
INFO - 2021-02-26 09:09:47 --> Helper loaded: my_helper
INFO - 2021-02-26 09:09:47 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:09:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:09:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:09:47 --> Controller Class Initialized
DEBUG - 2021-02-26 09:09:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-02-26 09:09:47 --> Final output sent to browser
DEBUG - 2021-02-26 09:09:47 --> Total execution time: 0.3230
INFO - 2021-02-26 09:10:59 --> Config Class Initialized
INFO - 2021-02-26 09:10:59 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:10:59 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:10:59 --> Utf8 Class Initialized
INFO - 2021-02-26 09:10:59 --> URI Class Initialized
INFO - 2021-02-26 09:10:59 --> Router Class Initialized
INFO - 2021-02-26 09:10:59 --> Output Class Initialized
INFO - 2021-02-26 09:10:59 --> Security Class Initialized
DEBUG - 2021-02-26 09:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:10:59 --> Input Class Initialized
INFO - 2021-02-26 09:10:59 --> Language Class Initialized
INFO - 2021-02-26 09:10:59 --> Language Class Initialized
INFO - 2021-02-26 09:10:59 --> Config Class Initialized
INFO - 2021-02-26 09:10:59 --> Loader Class Initialized
INFO - 2021-02-26 09:10:59 --> Helper loaded: url_helper
INFO - 2021-02-26 09:10:59 --> Helper loaded: file_helper
INFO - 2021-02-26 09:10:59 --> Helper loaded: form_helper
INFO - 2021-02-26 09:10:59 --> Helper loaded: my_helper
INFO - 2021-02-26 09:10:59 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:10:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:10:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:10:59 --> Controller Class Initialized
DEBUG - 2021-02-26 09:10:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-02-26 09:10:59 --> Final output sent to browser
DEBUG - 2021-02-26 09:10:59 --> Total execution time: 0.3319
INFO - 2021-02-26 09:15:55 --> Config Class Initialized
INFO - 2021-02-26 09:15:55 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:15:55 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:15:55 --> Utf8 Class Initialized
INFO - 2021-02-26 09:15:55 --> URI Class Initialized
INFO - 2021-02-26 09:15:56 --> Router Class Initialized
INFO - 2021-02-26 09:15:56 --> Output Class Initialized
INFO - 2021-02-26 09:15:56 --> Security Class Initialized
DEBUG - 2021-02-26 09:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:15:56 --> Input Class Initialized
INFO - 2021-02-26 09:15:56 --> Language Class Initialized
INFO - 2021-02-26 09:15:56 --> Language Class Initialized
INFO - 2021-02-26 09:15:56 --> Config Class Initialized
INFO - 2021-02-26 09:15:56 --> Loader Class Initialized
INFO - 2021-02-26 09:15:56 --> Helper loaded: url_helper
INFO - 2021-02-26 09:15:56 --> Helper loaded: file_helper
INFO - 2021-02-26 09:15:56 --> Helper loaded: form_helper
INFO - 2021-02-26 09:15:56 --> Helper loaded: my_helper
INFO - 2021-02-26 09:15:56 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:15:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:15:56 --> Controller Class Initialized
DEBUG - 2021-02-26 09:15:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-02-26 09:15:56 --> Final output sent to browser
DEBUG - 2021-02-26 09:15:56 --> Total execution time: 0.3513
INFO - 2021-02-26 09:16:06 --> Config Class Initialized
INFO - 2021-02-26 09:16:06 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:16:07 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:16:07 --> Utf8 Class Initialized
INFO - 2021-02-26 09:16:07 --> URI Class Initialized
INFO - 2021-02-26 09:16:07 --> Router Class Initialized
INFO - 2021-02-26 09:16:07 --> Output Class Initialized
INFO - 2021-02-26 09:16:07 --> Security Class Initialized
DEBUG - 2021-02-26 09:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:16:07 --> Input Class Initialized
INFO - 2021-02-26 09:16:07 --> Language Class Initialized
INFO - 2021-02-26 09:16:07 --> Language Class Initialized
INFO - 2021-02-26 09:16:07 --> Config Class Initialized
INFO - 2021-02-26 09:16:07 --> Loader Class Initialized
INFO - 2021-02-26 09:16:07 --> Helper loaded: url_helper
INFO - 2021-02-26 09:16:07 --> Helper loaded: file_helper
INFO - 2021-02-26 09:16:07 --> Helper loaded: form_helper
INFO - 2021-02-26 09:16:07 --> Helper loaded: my_helper
INFO - 2021-02-26 09:16:07 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:16:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:16:07 --> Controller Class Initialized
INFO - 2021-02-26 09:16:07 --> Helper loaded: cookie_helper
INFO - 2021-02-26 09:16:07 --> Config Class Initialized
INFO - 2021-02-26 09:16:07 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:16:07 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:16:07 --> Utf8 Class Initialized
INFO - 2021-02-26 09:16:07 --> URI Class Initialized
INFO - 2021-02-26 09:16:07 --> Router Class Initialized
INFO - 2021-02-26 09:16:07 --> Output Class Initialized
INFO - 2021-02-26 09:16:07 --> Security Class Initialized
DEBUG - 2021-02-26 09:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:16:07 --> Input Class Initialized
INFO - 2021-02-26 09:16:07 --> Language Class Initialized
INFO - 2021-02-26 09:16:07 --> Language Class Initialized
INFO - 2021-02-26 09:16:07 --> Config Class Initialized
INFO - 2021-02-26 09:16:07 --> Loader Class Initialized
INFO - 2021-02-26 09:16:07 --> Helper loaded: url_helper
INFO - 2021-02-26 09:16:07 --> Helper loaded: file_helper
INFO - 2021-02-26 09:16:07 --> Helper loaded: form_helper
INFO - 2021-02-26 09:16:07 --> Helper loaded: my_helper
INFO - 2021-02-26 09:16:07 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:16:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:16:07 --> Controller Class Initialized
DEBUG - 2021-02-26 09:16:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-02-26 09:16:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 09:16:07 --> Final output sent to browser
DEBUG - 2021-02-26 09:16:07 --> Total execution time: 0.2856
INFO - 2021-02-26 09:16:14 --> Config Class Initialized
INFO - 2021-02-26 09:16:14 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:16:14 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:16:15 --> Utf8 Class Initialized
INFO - 2021-02-26 09:16:15 --> URI Class Initialized
INFO - 2021-02-26 09:16:15 --> Router Class Initialized
INFO - 2021-02-26 09:16:15 --> Output Class Initialized
INFO - 2021-02-26 09:16:15 --> Security Class Initialized
DEBUG - 2021-02-26 09:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:16:15 --> Input Class Initialized
INFO - 2021-02-26 09:16:15 --> Language Class Initialized
INFO - 2021-02-26 09:16:15 --> Language Class Initialized
INFO - 2021-02-26 09:16:15 --> Config Class Initialized
INFO - 2021-02-26 09:16:15 --> Loader Class Initialized
INFO - 2021-02-26 09:16:15 --> Helper loaded: url_helper
INFO - 2021-02-26 09:16:15 --> Helper loaded: file_helper
INFO - 2021-02-26 09:16:15 --> Helper loaded: form_helper
INFO - 2021-02-26 09:16:15 --> Helper loaded: my_helper
INFO - 2021-02-26 09:16:15 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:16:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:16:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:16:15 --> Controller Class Initialized
INFO - 2021-02-26 09:16:15 --> Helper loaded: cookie_helper
INFO - 2021-02-26 09:16:15 --> Final output sent to browser
DEBUG - 2021-02-26 09:16:15 --> Total execution time: 0.3497
INFO - 2021-02-26 09:16:15 --> Config Class Initialized
INFO - 2021-02-26 09:16:15 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:16:15 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:16:15 --> Utf8 Class Initialized
INFO - 2021-02-26 09:16:15 --> URI Class Initialized
INFO - 2021-02-26 09:16:15 --> Router Class Initialized
INFO - 2021-02-26 09:16:15 --> Output Class Initialized
INFO - 2021-02-26 09:16:15 --> Security Class Initialized
DEBUG - 2021-02-26 09:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:16:15 --> Input Class Initialized
INFO - 2021-02-26 09:16:15 --> Language Class Initialized
INFO - 2021-02-26 09:16:15 --> Language Class Initialized
INFO - 2021-02-26 09:16:15 --> Config Class Initialized
INFO - 2021-02-26 09:16:15 --> Loader Class Initialized
INFO - 2021-02-26 09:16:16 --> Helper loaded: url_helper
INFO - 2021-02-26 09:16:16 --> Helper loaded: file_helper
INFO - 2021-02-26 09:16:16 --> Helper loaded: form_helper
INFO - 2021-02-26 09:16:16 --> Helper loaded: my_helper
INFO - 2021-02-26 09:16:16 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:16:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:16:16 --> Controller Class Initialized
DEBUG - 2021-02-26 09:16:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-02-26 09:16:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 09:16:16 --> Final output sent to browser
DEBUG - 2021-02-26 09:16:16 --> Total execution time: 0.4326
INFO - 2021-02-26 09:16:23 --> Config Class Initialized
INFO - 2021-02-26 09:16:23 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:16:23 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:16:23 --> Utf8 Class Initialized
INFO - 2021-02-26 09:16:23 --> URI Class Initialized
INFO - 2021-02-26 09:16:23 --> Router Class Initialized
INFO - 2021-02-26 09:16:23 --> Output Class Initialized
INFO - 2021-02-26 09:16:23 --> Security Class Initialized
DEBUG - 2021-02-26 09:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:16:23 --> Input Class Initialized
INFO - 2021-02-26 09:16:23 --> Language Class Initialized
INFO - 2021-02-26 09:16:23 --> Language Class Initialized
INFO - 2021-02-26 09:16:23 --> Config Class Initialized
INFO - 2021-02-26 09:16:23 --> Loader Class Initialized
INFO - 2021-02-26 09:16:23 --> Helper loaded: url_helper
INFO - 2021-02-26 09:16:23 --> Helper loaded: file_helper
INFO - 2021-02-26 09:16:23 --> Helper loaded: form_helper
INFO - 2021-02-26 09:16:23 --> Helper loaded: my_helper
INFO - 2021-02-26 09:16:23 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:16:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:16:23 --> Controller Class Initialized
DEBUG - 2021-02-26 09:16:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2021-02-26 09:16:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 09:16:23 --> Final output sent to browser
DEBUG - 2021-02-26 09:16:23 --> Total execution time: 0.3601
INFO - 2021-02-26 09:16:23 --> Config Class Initialized
INFO - 2021-02-26 09:16:23 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:16:23 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:16:23 --> Utf8 Class Initialized
INFO - 2021-02-26 09:16:23 --> URI Class Initialized
INFO - 2021-02-26 09:16:23 --> Router Class Initialized
INFO - 2021-02-26 09:16:23 --> Output Class Initialized
INFO - 2021-02-26 09:16:23 --> Security Class Initialized
DEBUG - 2021-02-26 09:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:16:23 --> Input Class Initialized
INFO - 2021-02-26 09:16:23 --> Language Class Initialized
INFO - 2021-02-26 09:16:23 --> Language Class Initialized
INFO - 2021-02-26 09:16:23 --> Config Class Initialized
INFO - 2021-02-26 09:16:23 --> Loader Class Initialized
INFO - 2021-02-26 09:16:23 --> Helper loaded: url_helper
INFO - 2021-02-26 09:16:23 --> Helper loaded: file_helper
INFO - 2021-02-26 09:16:23 --> Helper loaded: form_helper
INFO - 2021-02-26 09:16:23 --> Helper loaded: my_helper
INFO - 2021-02-26 09:16:23 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:16:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:16:23 --> Controller Class Initialized
INFO - 2021-02-26 09:16:48 --> Config Class Initialized
INFO - 2021-02-26 09:16:48 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:16:48 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:16:48 --> Utf8 Class Initialized
INFO - 2021-02-26 09:16:48 --> URI Class Initialized
INFO - 2021-02-26 09:16:48 --> Router Class Initialized
INFO - 2021-02-26 09:16:48 --> Output Class Initialized
INFO - 2021-02-26 09:16:48 --> Security Class Initialized
DEBUG - 2021-02-26 09:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:16:48 --> Input Class Initialized
INFO - 2021-02-26 09:16:48 --> Language Class Initialized
INFO - 2021-02-26 09:16:48 --> Language Class Initialized
INFO - 2021-02-26 09:16:48 --> Config Class Initialized
INFO - 2021-02-26 09:16:48 --> Loader Class Initialized
INFO - 2021-02-26 09:16:48 --> Helper loaded: url_helper
INFO - 2021-02-26 09:16:48 --> Helper loaded: file_helper
INFO - 2021-02-26 09:16:48 --> Helper loaded: form_helper
INFO - 2021-02-26 09:16:48 --> Helper loaded: my_helper
INFO - 2021-02-26 09:16:48 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:16:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:16:48 --> Controller Class Initialized
INFO - 2021-02-26 09:17:02 --> Config Class Initialized
INFO - 2021-02-26 09:17:02 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:17:02 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:17:02 --> Utf8 Class Initialized
INFO - 2021-02-26 09:17:02 --> URI Class Initialized
INFO - 2021-02-26 09:17:02 --> Router Class Initialized
INFO - 2021-02-26 09:17:02 --> Output Class Initialized
INFO - 2021-02-26 09:17:02 --> Security Class Initialized
DEBUG - 2021-02-26 09:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:17:02 --> Input Class Initialized
INFO - 2021-02-26 09:17:02 --> Language Class Initialized
INFO - 2021-02-26 09:17:02 --> Language Class Initialized
INFO - 2021-02-26 09:17:02 --> Config Class Initialized
INFO - 2021-02-26 09:17:02 --> Loader Class Initialized
INFO - 2021-02-26 09:17:02 --> Helper loaded: url_helper
INFO - 2021-02-26 09:17:02 --> Helper loaded: file_helper
INFO - 2021-02-26 09:17:02 --> Helper loaded: form_helper
INFO - 2021-02-26 09:17:02 --> Helper loaded: my_helper
INFO - 2021-02-26 09:17:02 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:17:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:17:02 --> Controller Class Initialized
INFO - 2021-02-26 09:17:02 --> Helper loaded: cookie_helper
INFO - 2021-02-26 09:17:03 --> Config Class Initialized
INFO - 2021-02-26 09:17:03 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:17:03 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:17:03 --> Utf8 Class Initialized
INFO - 2021-02-26 09:17:03 --> URI Class Initialized
INFO - 2021-02-26 09:17:03 --> Router Class Initialized
INFO - 2021-02-26 09:17:03 --> Output Class Initialized
INFO - 2021-02-26 09:17:03 --> Security Class Initialized
DEBUG - 2021-02-26 09:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:17:03 --> Input Class Initialized
INFO - 2021-02-26 09:17:03 --> Language Class Initialized
INFO - 2021-02-26 09:17:03 --> Language Class Initialized
INFO - 2021-02-26 09:17:03 --> Config Class Initialized
INFO - 2021-02-26 09:17:03 --> Loader Class Initialized
INFO - 2021-02-26 09:17:03 --> Helper loaded: url_helper
INFO - 2021-02-26 09:17:03 --> Helper loaded: file_helper
INFO - 2021-02-26 09:17:03 --> Helper loaded: form_helper
INFO - 2021-02-26 09:17:03 --> Helper loaded: my_helper
INFO - 2021-02-26 09:17:03 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:17:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:17:03 --> Controller Class Initialized
DEBUG - 2021-02-26 09:17:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-02-26 09:17:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 09:17:03 --> Final output sent to browser
DEBUG - 2021-02-26 09:17:03 --> Total execution time: 0.3059
INFO - 2021-02-26 09:17:18 --> Config Class Initialized
INFO - 2021-02-26 09:17:18 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:17:18 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:17:18 --> Utf8 Class Initialized
INFO - 2021-02-26 09:17:18 --> URI Class Initialized
INFO - 2021-02-26 09:17:18 --> Router Class Initialized
INFO - 2021-02-26 09:17:18 --> Output Class Initialized
INFO - 2021-02-26 09:17:18 --> Security Class Initialized
DEBUG - 2021-02-26 09:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:17:18 --> Input Class Initialized
INFO - 2021-02-26 09:17:18 --> Language Class Initialized
INFO - 2021-02-26 09:17:18 --> Language Class Initialized
INFO - 2021-02-26 09:17:18 --> Config Class Initialized
INFO - 2021-02-26 09:17:18 --> Loader Class Initialized
INFO - 2021-02-26 09:17:18 --> Helper loaded: url_helper
INFO - 2021-02-26 09:17:18 --> Helper loaded: file_helper
INFO - 2021-02-26 09:17:18 --> Helper loaded: form_helper
INFO - 2021-02-26 09:17:18 --> Helper loaded: my_helper
INFO - 2021-02-26 09:17:18 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:17:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:17:18 --> Controller Class Initialized
INFO - 2021-02-26 09:17:18 --> Helper loaded: cookie_helper
INFO - 2021-02-26 09:17:18 --> Final output sent to browser
DEBUG - 2021-02-26 09:17:18 --> Total execution time: 0.3357
INFO - 2021-02-26 09:17:19 --> Config Class Initialized
INFO - 2021-02-26 09:17:19 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:17:19 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:17:19 --> Utf8 Class Initialized
INFO - 2021-02-26 09:17:19 --> URI Class Initialized
INFO - 2021-02-26 09:17:19 --> Router Class Initialized
INFO - 2021-02-26 09:17:19 --> Output Class Initialized
INFO - 2021-02-26 09:17:19 --> Security Class Initialized
DEBUG - 2021-02-26 09:17:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:17:19 --> Input Class Initialized
INFO - 2021-02-26 09:17:19 --> Language Class Initialized
INFO - 2021-02-26 09:17:19 --> Language Class Initialized
INFO - 2021-02-26 09:17:19 --> Config Class Initialized
INFO - 2021-02-26 09:17:19 --> Loader Class Initialized
INFO - 2021-02-26 09:17:19 --> Helper loaded: url_helper
INFO - 2021-02-26 09:17:19 --> Helper loaded: file_helper
INFO - 2021-02-26 09:17:19 --> Helper loaded: form_helper
INFO - 2021-02-26 09:17:19 --> Helper loaded: my_helper
INFO - 2021-02-26 09:17:19 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:17:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:17:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:17:19 --> Controller Class Initialized
DEBUG - 2021-02-26 09:17:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-02-26 09:17:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 09:17:19 --> Final output sent to browser
DEBUG - 2021-02-26 09:17:19 --> Total execution time: 0.4603
INFO - 2021-02-26 09:17:21 --> Config Class Initialized
INFO - 2021-02-26 09:17:21 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:17:21 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:17:21 --> Utf8 Class Initialized
INFO - 2021-02-26 09:17:21 --> URI Class Initialized
INFO - 2021-02-26 09:17:21 --> Router Class Initialized
INFO - 2021-02-26 09:17:21 --> Output Class Initialized
INFO - 2021-02-26 09:17:21 --> Security Class Initialized
DEBUG - 2021-02-26 09:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:17:21 --> Input Class Initialized
INFO - 2021-02-26 09:17:21 --> Language Class Initialized
INFO - 2021-02-26 09:17:21 --> Language Class Initialized
INFO - 2021-02-26 09:17:21 --> Config Class Initialized
INFO - 2021-02-26 09:17:21 --> Loader Class Initialized
INFO - 2021-02-26 09:17:21 --> Helper loaded: url_helper
INFO - 2021-02-26 09:17:21 --> Helper loaded: file_helper
INFO - 2021-02-26 09:17:21 --> Helper loaded: form_helper
INFO - 2021-02-26 09:17:21 --> Helper loaded: my_helper
INFO - 2021-02-26 09:17:21 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:17:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:17:21 --> Controller Class Initialized
DEBUG - 2021-02-26 09:17:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-02-26 09:17:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 09:17:21 --> Final output sent to browser
DEBUG - 2021-02-26 09:17:21 --> Total execution time: 0.3679
INFO - 2021-02-26 09:17:22 --> Config Class Initialized
INFO - 2021-02-26 09:17:22 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:17:22 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:17:22 --> Utf8 Class Initialized
INFO - 2021-02-26 09:17:22 --> URI Class Initialized
INFO - 2021-02-26 09:17:23 --> Router Class Initialized
INFO - 2021-02-26 09:17:23 --> Output Class Initialized
INFO - 2021-02-26 09:17:23 --> Security Class Initialized
DEBUG - 2021-02-26 09:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:17:23 --> Input Class Initialized
INFO - 2021-02-26 09:17:23 --> Language Class Initialized
INFO - 2021-02-26 09:17:23 --> Language Class Initialized
INFO - 2021-02-26 09:17:23 --> Config Class Initialized
INFO - 2021-02-26 09:17:23 --> Loader Class Initialized
INFO - 2021-02-26 09:17:23 --> Helper loaded: url_helper
INFO - 2021-02-26 09:17:23 --> Helper loaded: file_helper
INFO - 2021-02-26 09:17:23 --> Helper loaded: form_helper
INFO - 2021-02-26 09:17:23 --> Helper loaded: my_helper
INFO - 2021-02-26 09:17:23 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:17:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:17:23 --> Controller Class Initialized
DEBUG - 2021-02-26 09:17:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-02-26 09:17:23 --> Final output sent to browser
DEBUG - 2021-02-26 09:17:23 --> Total execution time: 0.3773
INFO - 2021-02-26 09:17:42 --> Config Class Initialized
INFO - 2021-02-26 09:17:42 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:17:42 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:17:42 --> Utf8 Class Initialized
INFO - 2021-02-26 09:17:42 --> URI Class Initialized
INFO - 2021-02-26 09:17:42 --> Router Class Initialized
INFO - 2021-02-26 09:17:42 --> Output Class Initialized
INFO - 2021-02-26 09:17:42 --> Security Class Initialized
DEBUG - 2021-02-26 09:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:17:42 --> Input Class Initialized
INFO - 2021-02-26 09:17:42 --> Language Class Initialized
INFO - 2021-02-26 09:17:42 --> Language Class Initialized
INFO - 2021-02-26 09:17:42 --> Config Class Initialized
INFO - 2021-02-26 09:17:42 --> Loader Class Initialized
INFO - 2021-02-26 09:17:42 --> Helper loaded: url_helper
INFO - 2021-02-26 09:17:42 --> Helper loaded: file_helper
INFO - 2021-02-26 09:17:42 --> Helper loaded: form_helper
INFO - 2021-02-26 09:17:42 --> Helper loaded: my_helper
INFO - 2021-02-26 09:17:42 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:17:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:17:43 --> Controller Class Initialized
DEBUG - 2021-02-26 09:17:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-02-26 09:17:43 --> Final output sent to browser
DEBUG - 2021-02-26 09:17:43 --> Total execution time: 0.3589
INFO - 2021-02-26 09:18:01 --> Config Class Initialized
INFO - 2021-02-26 09:18:01 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:18:01 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:18:01 --> Utf8 Class Initialized
INFO - 2021-02-26 09:18:01 --> URI Class Initialized
INFO - 2021-02-26 09:18:01 --> Router Class Initialized
INFO - 2021-02-26 09:18:01 --> Output Class Initialized
INFO - 2021-02-26 09:18:01 --> Security Class Initialized
DEBUG - 2021-02-26 09:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:18:01 --> Input Class Initialized
INFO - 2021-02-26 09:18:01 --> Language Class Initialized
INFO - 2021-02-26 09:18:01 --> Language Class Initialized
INFO - 2021-02-26 09:18:01 --> Config Class Initialized
INFO - 2021-02-26 09:18:01 --> Loader Class Initialized
INFO - 2021-02-26 09:18:01 --> Helper loaded: url_helper
INFO - 2021-02-26 09:18:01 --> Helper loaded: file_helper
INFO - 2021-02-26 09:18:01 --> Helper loaded: form_helper
INFO - 2021-02-26 09:18:01 --> Helper loaded: my_helper
INFO - 2021-02-26 09:18:01 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:18:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:18:01 --> Controller Class Initialized
DEBUG - 2021-02-26 09:18:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-02-26 09:18:01 --> Final output sent to browser
DEBUG - 2021-02-26 09:18:01 --> Total execution time: 0.4212
INFO - 2021-02-26 09:18:30 --> Config Class Initialized
INFO - 2021-02-26 09:18:30 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:18:30 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:18:30 --> Utf8 Class Initialized
INFO - 2021-02-26 09:18:30 --> URI Class Initialized
INFO - 2021-02-26 09:18:30 --> Router Class Initialized
INFO - 2021-02-26 09:18:30 --> Output Class Initialized
INFO - 2021-02-26 09:18:30 --> Security Class Initialized
DEBUG - 2021-02-26 09:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:18:30 --> Input Class Initialized
INFO - 2021-02-26 09:18:30 --> Language Class Initialized
INFO - 2021-02-26 09:18:30 --> Language Class Initialized
INFO - 2021-02-26 09:18:30 --> Config Class Initialized
INFO - 2021-02-26 09:18:30 --> Loader Class Initialized
INFO - 2021-02-26 09:18:30 --> Helper loaded: url_helper
INFO - 2021-02-26 09:18:30 --> Helper loaded: file_helper
INFO - 2021-02-26 09:18:30 --> Helper loaded: form_helper
INFO - 2021-02-26 09:18:30 --> Helper loaded: my_helper
INFO - 2021-02-26 09:18:30 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:18:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:18:30 --> Controller Class Initialized
DEBUG - 2021-02-26 09:18:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-02-26 09:18:30 --> Final output sent to browser
DEBUG - 2021-02-26 09:18:30 --> Total execution time: 0.4122
INFO - 2021-02-26 09:18:43 --> Config Class Initialized
INFO - 2021-02-26 09:18:43 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:18:43 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:18:43 --> Utf8 Class Initialized
INFO - 2021-02-26 09:18:43 --> URI Class Initialized
INFO - 2021-02-26 09:18:43 --> Router Class Initialized
INFO - 2021-02-26 09:18:43 --> Output Class Initialized
INFO - 2021-02-26 09:18:43 --> Security Class Initialized
DEBUG - 2021-02-26 09:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:18:43 --> Input Class Initialized
INFO - 2021-02-26 09:18:43 --> Language Class Initialized
INFO - 2021-02-26 09:18:43 --> Language Class Initialized
INFO - 2021-02-26 09:18:43 --> Config Class Initialized
INFO - 2021-02-26 09:18:43 --> Loader Class Initialized
INFO - 2021-02-26 09:18:43 --> Helper loaded: url_helper
INFO - 2021-02-26 09:18:43 --> Helper loaded: file_helper
INFO - 2021-02-26 09:18:43 --> Helper loaded: form_helper
INFO - 2021-02-26 09:18:43 --> Helper loaded: my_helper
INFO - 2021-02-26 09:18:43 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:18:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:18:43 --> Controller Class Initialized
DEBUG - 2021-02-26 09:18:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-02-26 09:18:43 --> Final output sent to browser
DEBUG - 2021-02-26 09:18:43 --> Total execution time: 0.3798
INFO - 2021-02-26 09:18:51 --> Config Class Initialized
INFO - 2021-02-26 09:18:51 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:18:51 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:18:51 --> Utf8 Class Initialized
INFO - 2021-02-26 09:18:51 --> URI Class Initialized
INFO - 2021-02-26 09:18:51 --> Router Class Initialized
INFO - 2021-02-26 09:18:51 --> Output Class Initialized
INFO - 2021-02-26 09:18:51 --> Security Class Initialized
DEBUG - 2021-02-26 09:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:18:51 --> Input Class Initialized
INFO - 2021-02-26 09:18:51 --> Language Class Initialized
INFO - 2021-02-26 09:18:51 --> Language Class Initialized
INFO - 2021-02-26 09:18:52 --> Config Class Initialized
INFO - 2021-02-26 09:18:52 --> Loader Class Initialized
INFO - 2021-02-26 09:18:52 --> Helper loaded: url_helper
INFO - 2021-02-26 09:18:52 --> Helper loaded: file_helper
INFO - 2021-02-26 09:18:52 --> Helper loaded: form_helper
INFO - 2021-02-26 09:18:52 --> Helper loaded: my_helper
INFO - 2021-02-26 09:18:52 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:18:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:18:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:18:52 --> Controller Class Initialized
DEBUG - 2021-02-26 09:18:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-02-26 09:18:52 --> Final output sent to browser
DEBUG - 2021-02-26 09:18:52 --> Total execution time: 0.3933
INFO - 2021-02-26 09:19:23 --> Config Class Initialized
INFO - 2021-02-26 09:19:23 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:19:23 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:19:23 --> Utf8 Class Initialized
INFO - 2021-02-26 09:19:23 --> URI Class Initialized
INFO - 2021-02-26 09:19:23 --> Router Class Initialized
INFO - 2021-02-26 09:19:23 --> Output Class Initialized
INFO - 2021-02-26 09:19:23 --> Security Class Initialized
DEBUG - 2021-02-26 09:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:19:24 --> Input Class Initialized
INFO - 2021-02-26 09:19:24 --> Language Class Initialized
INFO - 2021-02-26 09:19:24 --> Language Class Initialized
INFO - 2021-02-26 09:19:24 --> Config Class Initialized
INFO - 2021-02-26 09:19:24 --> Loader Class Initialized
INFO - 2021-02-26 09:19:24 --> Helper loaded: url_helper
INFO - 2021-02-26 09:19:24 --> Helper loaded: file_helper
INFO - 2021-02-26 09:19:24 --> Helper loaded: form_helper
INFO - 2021-02-26 09:19:24 --> Helper loaded: my_helper
INFO - 2021-02-26 09:19:24 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:19:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:19:24 --> Controller Class Initialized
INFO - 2021-02-26 09:19:24 --> Helper loaded: cookie_helper
INFO - 2021-02-26 09:19:24 --> Config Class Initialized
INFO - 2021-02-26 09:19:24 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:19:24 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:19:24 --> Utf8 Class Initialized
INFO - 2021-02-26 09:19:24 --> URI Class Initialized
INFO - 2021-02-26 09:19:24 --> Router Class Initialized
INFO - 2021-02-26 09:19:24 --> Output Class Initialized
INFO - 2021-02-26 09:19:24 --> Security Class Initialized
DEBUG - 2021-02-26 09:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:19:24 --> Input Class Initialized
INFO - 2021-02-26 09:19:24 --> Language Class Initialized
INFO - 2021-02-26 09:19:24 --> Language Class Initialized
INFO - 2021-02-26 09:19:24 --> Config Class Initialized
INFO - 2021-02-26 09:19:24 --> Loader Class Initialized
INFO - 2021-02-26 09:19:24 --> Helper loaded: url_helper
INFO - 2021-02-26 09:19:24 --> Helper loaded: file_helper
INFO - 2021-02-26 09:19:24 --> Helper loaded: form_helper
INFO - 2021-02-26 09:19:24 --> Helper loaded: my_helper
INFO - 2021-02-26 09:19:24 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:19:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:19:24 --> Controller Class Initialized
DEBUG - 2021-02-26 09:19:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-02-26 09:19:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 09:19:24 --> Final output sent to browser
DEBUG - 2021-02-26 09:19:24 --> Total execution time: 0.4162
INFO - 2021-02-26 09:19:37 --> Config Class Initialized
INFO - 2021-02-26 09:19:37 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:19:37 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:19:37 --> Utf8 Class Initialized
INFO - 2021-02-26 09:19:37 --> URI Class Initialized
INFO - 2021-02-26 09:19:37 --> Router Class Initialized
INFO - 2021-02-26 09:19:37 --> Output Class Initialized
INFO - 2021-02-26 09:19:37 --> Security Class Initialized
DEBUG - 2021-02-26 09:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:19:37 --> Input Class Initialized
INFO - 2021-02-26 09:19:37 --> Language Class Initialized
INFO - 2021-02-26 09:19:38 --> Language Class Initialized
INFO - 2021-02-26 09:19:38 --> Config Class Initialized
INFO - 2021-02-26 09:19:38 --> Loader Class Initialized
INFO - 2021-02-26 09:19:38 --> Helper loaded: url_helper
INFO - 2021-02-26 09:19:38 --> Helper loaded: file_helper
INFO - 2021-02-26 09:19:38 --> Helper loaded: form_helper
INFO - 2021-02-26 09:19:38 --> Helper loaded: my_helper
INFO - 2021-02-26 09:19:38 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:19:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:19:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:19:38 --> Controller Class Initialized
INFO - 2021-02-26 09:19:38 --> Helper loaded: cookie_helper
INFO - 2021-02-26 09:19:38 --> Final output sent to browser
DEBUG - 2021-02-26 09:19:38 --> Total execution time: 0.4022
INFO - 2021-02-26 09:19:38 --> Config Class Initialized
INFO - 2021-02-26 09:19:38 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:19:38 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:19:38 --> Utf8 Class Initialized
INFO - 2021-02-26 09:19:38 --> URI Class Initialized
INFO - 2021-02-26 09:19:38 --> Router Class Initialized
INFO - 2021-02-26 09:19:38 --> Output Class Initialized
INFO - 2021-02-26 09:19:38 --> Security Class Initialized
DEBUG - 2021-02-26 09:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:19:38 --> Input Class Initialized
INFO - 2021-02-26 09:19:38 --> Language Class Initialized
INFO - 2021-02-26 09:19:38 --> Language Class Initialized
INFO - 2021-02-26 09:19:38 --> Config Class Initialized
INFO - 2021-02-26 09:19:38 --> Loader Class Initialized
INFO - 2021-02-26 09:19:38 --> Helper loaded: url_helper
INFO - 2021-02-26 09:19:38 --> Helper loaded: file_helper
INFO - 2021-02-26 09:19:38 --> Helper loaded: form_helper
INFO - 2021-02-26 09:19:38 --> Helper loaded: my_helper
INFO - 2021-02-26 09:19:38 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:19:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:19:39 --> Controller Class Initialized
DEBUG - 2021-02-26 09:19:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-02-26 09:19:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 09:19:39 --> Final output sent to browser
DEBUG - 2021-02-26 09:19:39 --> Total execution time: 0.4424
INFO - 2021-02-26 09:19:41 --> Config Class Initialized
INFO - 2021-02-26 09:19:41 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:19:41 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:19:41 --> Utf8 Class Initialized
INFO - 2021-02-26 09:19:41 --> URI Class Initialized
INFO - 2021-02-26 09:19:41 --> Router Class Initialized
INFO - 2021-02-26 09:19:41 --> Output Class Initialized
INFO - 2021-02-26 09:19:41 --> Security Class Initialized
DEBUG - 2021-02-26 09:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:19:41 --> Input Class Initialized
INFO - 2021-02-26 09:19:41 --> Language Class Initialized
INFO - 2021-02-26 09:19:41 --> Language Class Initialized
INFO - 2021-02-26 09:19:41 --> Config Class Initialized
INFO - 2021-02-26 09:19:41 --> Loader Class Initialized
INFO - 2021-02-26 09:19:41 --> Helper loaded: url_helper
INFO - 2021-02-26 09:19:42 --> Helper loaded: file_helper
INFO - 2021-02-26 09:19:42 --> Helper loaded: form_helper
INFO - 2021-02-26 09:19:42 --> Helper loaded: my_helper
INFO - 2021-02-26 09:19:42 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:19:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:19:42 --> Controller Class Initialized
DEBUG - 2021-02-26 09:19:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-02-26 09:19:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 09:19:42 --> Final output sent to browser
DEBUG - 2021-02-26 09:19:42 --> Total execution time: 0.4062
INFO - 2021-02-26 09:19:44 --> Config Class Initialized
INFO - 2021-02-26 09:19:44 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:19:44 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:19:44 --> Utf8 Class Initialized
INFO - 2021-02-26 09:19:44 --> URI Class Initialized
INFO - 2021-02-26 09:19:44 --> Router Class Initialized
INFO - 2021-02-26 09:19:44 --> Output Class Initialized
INFO - 2021-02-26 09:19:44 --> Security Class Initialized
DEBUG - 2021-02-26 09:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:19:44 --> Input Class Initialized
INFO - 2021-02-26 09:19:44 --> Language Class Initialized
INFO - 2021-02-26 09:19:44 --> Language Class Initialized
INFO - 2021-02-26 09:19:44 --> Config Class Initialized
INFO - 2021-02-26 09:19:44 --> Loader Class Initialized
INFO - 2021-02-26 09:19:44 --> Helper loaded: url_helper
INFO - 2021-02-26 09:19:44 --> Helper loaded: file_helper
INFO - 2021-02-26 09:19:44 --> Helper loaded: form_helper
INFO - 2021-02-26 09:19:44 --> Helper loaded: my_helper
INFO - 2021-02-26 09:19:44 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:19:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:19:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:19:44 --> Controller Class Initialized
INFO - 2021-02-26 09:19:44 --> Helper loaded: cookie_helper
INFO - 2021-02-26 09:19:44 --> Config Class Initialized
INFO - 2021-02-26 09:19:44 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:19:44 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:19:44 --> Utf8 Class Initialized
INFO - 2021-02-26 09:19:44 --> URI Class Initialized
INFO - 2021-02-26 09:19:44 --> Router Class Initialized
INFO - 2021-02-26 09:19:44 --> Output Class Initialized
INFO - 2021-02-26 09:19:44 --> Security Class Initialized
DEBUG - 2021-02-26 09:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:19:44 --> Input Class Initialized
INFO - 2021-02-26 09:19:44 --> Language Class Initialized
INFO - 2021-02-26 09:19:44 --> Language Class Initialized
INFO - 2021-02-26 09:19:44 --> Config Class Initialized
INFO - 2021-02-26 09:19:44 --> Loader Class Initialized
INFO - 2021-02-26 09:19:45 --> Helper loaded: url_helper
INFO - 2021-02-26 09:19:45 --> Helper loaded: file_helper
INFO - 2021-02-26 09:19:45 --> Helper loaded: form_helper
INFO - 2021-02-26 09:19:45 --> Helper loaded: my_helper
INFO - 2021-02-26 09:19:45 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:19:45 --> Controller Class Initialized
DEBUG - 2021-02-26 09:19:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-02-26 09:19:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 09:19:45 --> Final output sent to browser
DEBUG - 2021-02-26 09:19:45 --> Total execution time: 0.4702
INFO - 2021-02-26 09:19:58 --> Config Class Initialized
INFO - 2021-02-26 09:19:58 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:19:58 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:19:58 --> Utf8 Class Initialized
INFO - 2021-02-26 09:19:58 --> URI Class Initialized
INFO - 2021-02-26 09:19:58 --> Router Class Initialized
INFO - 2021-02-26 09:19:58 --> Output Class Initialized
INFO - 2021-02-26 09:19:58 --> Security Class Initialized
DEBUG - 2021-02-26 09:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:19:58 --> Input Class Initialized
INFO - 2021-02-26 09:19:58 --> Language Class Initialized
INFO - 2021-02-26 09:19:58 --> Language Class Initialized
INFO - 2021-02-26 09:19:58 --> Config Class Initialized
INFO - 2021-02-26 09:19:58 --> Loader Class Initialized
INFO - 2021-02-26 09:19:58 --> Helper loaded: url_helper
INFO - 2021-02-26 09:19:58 --> Helper loaded: file_helper
INFO - 2021-02-26 09:19:58 --> Helper loaded: form_helper
INFO - 2021-02-26 09:19:58 --> Helper loaded: my_helper
INFO - 2021-02-26 09:19:58 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:19:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:19:58 --> Controller Class Initialized
INFO - 2021-02-26 09:19:58 --> Helper loaded: cookie_helper
INFO - 2021-02-26 09:19:58 --> Final output sent to browser
DEBUG - 2021-02-26 09:19:58 --> Total execution time: 0.4047
INFO - 2021-02-26 09:19:59 --> Config Class Initialized
INFO - 2021-02-26 09:19:59 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:19:59 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:19:59 --> Utf8 Class Initialized
INFO - 2021-02-26 09:19:59 --> URI Class Initialized
INFO - 2021-02-26 09:19:59 --> Router Class Initialized
INFO - 2021-02-26 09:19:59 --> Output Class Initialized
INFO - 2021-02-26 09:19:59 --> Security Class Initialized
DEBUG - 2021-02-26 09:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:19:59 --> Input Class Initialized
INFO - 2021-02-26 09:19:59 --> Language Class Initialized
INFO - 2021-02-26 09:19:59 --> Language Class Initialized
INFO - 2021-02-26 09:19:59 --> Config Class Initialized
INFO - 2021-02-26 09:19:59 --> Loader Class Initialized
INFO - 2021-02-26 09:19:59 --> Helper loaded: url_helper
INFO - 2021-02-26 09:19:59 --> Helper loaded: file_helper
INFO - 2021-02-26 09:19:59 --> Helper loaded: form_helper
INFO - 2021-02-26 09:19:59 --> Helper loaded: my_helper
INFO - 2021-02-26 09:19:59 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:19:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:19:59 --> Controller Class Initialized
DEBUG - 2021-02-26 09:19:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-02-26 09:19:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 09:19:59 --> Final output sent to browser
DEBUG - 2021-02-26 09:19:59 --> Total execution time: 0.4732
INFO - 2021-02-26 09:20:01 --> Config Class Initialized
INFO - 2021-02-26 09:20:01 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:20:01 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:20:01 --> Utf8 Class Initialized
INFO - 2021-02-26 09:20:01 --> URI Class Initialized
INFO - 2021-02-26 09:20:01 --> Router Class Initialized
INFO - 2021-02-26 09:20:01 --> Output Class Initialized
INFO - 2021-02-26 09:20:01 --> Security Class Initialized
DEBUG - 2021-02-26 09:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:20:01 --> Input Class Initialized
INFO - 2021-02-26 09:20:01 --> Language Class Initialized
INFO - 2021-02-26 09:20:01 --> Language Class Initialized
INFO - 2021-02-26 09:20:01 --> Config Class Initialized
INFO - 2021-02-26 09:20:01 --> Loader Class Initialized
INFO - 2021-02-26 09:20:01 --> Helper loaded: url_helper
INFO - 2021-02-26 09:20:01 --> Helper loaded: file_helper
INFO - 2021-02-26 09:20:01 --> Helper loaded: form_helper
INFO - 2021-02-26 09:20:01 --> Helper loaded: my_helper
INFO - 2021-02-26 09:20:01 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:20:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:20:01 --> Controller Class Initialized
DEBUG - 2021-02-26 09:20:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-02-26 09:20:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 09:20:01 --> Final output sent to browser
DEBUG - 2021-02-26 09:20:01 --> Total execution time: 0.3430
INFO - 2021-02-26 09:20:04 --> Config Class Initialized
INFO - 2021-02-26 09:20:04 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:20:04 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:20:04 --> Utf8 Class Initialized
INFO - 2021-02-26 09:20:04 --> URI Class Initialized
INFO - 2021-02-26 09:20:04 --> Router Class Initialized
INFO - 2021-02-26 09:20:04 --> Output Class Initialized
INFO - 2021-02-26 09:20:04 --> Security Class Initialized
DEBUG - 2021-02-26 09:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:20:04 --> Input Class Initialized
INFO - 2021-02-26 09:20:04 --> Language Class Initialized
INFO - 2021-02-26 09:20:04 --> Language Class Initialized
INFO - 2021-02-26 09:20:04 --> Config Class Initialized
INFO - 2021-02-26 09:20:04 --> Loader Class Initialized
INFO - 2021-02-26 09:20:04 --> Helper loaded: url_helper
INFO - 2021-02-26 09:20:04 --> Helper loaded: file_helper
INFO - 2021-02-26 09:20:04 --> Helper loaded: form_helper
INFO - 2021-02-26 09:20:04 --> Helper loaded: my_helper
INFO - 2021-02-26 09:20:04 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:20:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:20:04 --> Controller Class Initialized
DEBUG - 2021-02-26 09:20:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-02-26 09:20:04 --> Final output sent to browser
DEBUG - 2021-02-26 09:20:04 --> Total execution time: 0.3310
INFO - 2021-02-26 09:20:22 --> Config Class Initialized
INFO - 2021-02-26 09:20:22 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:20:22 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:20:22 --> Utf8 Class Initialized
INFO - 2021-02-26 09:20:22 --> URI Class Initialized
INFO - 2021-02-26 09:20:22 --> Router Class Initialized
INFO - 2021-02-26 09:20:22 --> Output Class Initialized
INFO - 2021-02-26 09:20:22 --> Security Class Initialized
DEBUG - 2021-02-26 09:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:20:22 --> Input Class Initialized
INFO - 2021-02-26 09:20:22 --> Language Class Initialized
INFO - 2021-02-26 09:20:22 --> Language Class Initialized
INFO - 2021-02-26 09:20:22 --> Config Class Initialized
INFO - 2021-02-26 09:20:22 --> Loader Class Initialized
INFO - 2021-02-26 09:20:22 --> Helper loaded: url_helper
INFO - 2021-02-26 09:20:22 --> Helper loaded: file_helper
INFO - 2021-02-26 09:20:22 --> Helper loaded: form_helper
INFO - 2021-02-26 09:20:22 --> Helper loaded: my_helper
INFO - 2021-02-26 09:20:22 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:20:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:20:22 --> Controller Class Initialized
DEBUG - 2021-02-26 09:20:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-02-26 09:20:22 --> Final output sent to browser
DEBUG - 2021-02-26 09:20:22 --> Total execution time: 0.4257
INFO - 2021-02-26 09:20:41 --> Config Class Initialized
INFO - 2021-02-26 09:20:41 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:20:41 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:20:41 --> Utf8 Class Initialized
INFO - 2021-02-26 09:20:41 --> URI Class Initialized
INFO - 2021-02-26 09:20:41 --> Router Class Initialized
INFO - 2021-02-26 09:20:41 --> Output Class Initialized
INFO - 2021-02-26 09:20:41 --> Security Class Initialized
DEBUG - 2021-02-26 09:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:20:41 --> Input Class Initialized
INFO - 2021-02-26 09:20:41 --> Language Class Initialized
INFO - 2021-02-26 09:20:41 --> Language Class Initialized
INFO - 2021-02-26 09:20:41 --> Config Class Initialized
INFO - 2021-02-26 09:20:41 --> Loader Class Initialized
INFO - 2021-02-26 09:20:41 --> Helper loaded: url_helper
INFO - 2021-02-26 09:20:41 --> Helper loaded: file_helper
INFO - 2021-02-26 09:20:41 --> Helper loaded: form_helper
INFO - 2021-02-26 09:20:41 --> Helper loaded: my_helper
INFO - 2021-02-26 09:20:41 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:20:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:20:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:20:41 --> Controller Class Initialized
DEBUG - 2021-02-26 09:20:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-02-26 09:20:42 --> Final output sent to browser
DEBUG - 2021-02-26 09:20:42 --> Total execution time: 0.3549
INFO - 2021-02-26 09:22:06 --> Config Class Initialized
INFO - 2021-02-26 09:22:06 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:22:06 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:22:06 --> Utf8 Class Initialized
INFO - 2021-02-26 09:22:06 --> URI Class Initialized
INFO - 2021-02-26 09:22:06 --> Router Class Initialized
INFO - 2021-02-26 09:22:06 --> Output Class Initialized
INFO - 2021-02-26 09:22:06 --> Security Class Initialized
DEBUG - 2021-02-26 09:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:22:06 --> Input Class Initialized
INFO - 2021-02-26 09:22:06 --> Language Class Initialized
INFO - 2021-02-26 09:22:06 --> Language Class Initialized
INFO - 2021-02-26 09:22:06 --> Config Class Initialized
INFO - 2021-02-26 09:22:06 --> Loader Class Initialized
INFO - 2021-02-26 09:22:06 --> Helper loaded: url_helper
INFO - 2021-02-26 09:22:06 --> Helper loaded: file_helper
INFO - 2021-02-26 09:22:06 --> Helper loaded: form_helper
INFO - 2021-02-26 09:22:06 --> Helper loaded: my_helper
INFO - 2021-02-26 09:22:06 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:22:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:22:06 --> Controller Class Initialized
INFO - 2021-02-26 09:22:06 --> Helper loaded: cookie_helper
INFO - 2021-02-26 09:22:06 --> Config Class Initialized
INFO - 2021-02-26 09:22:06 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:22:06 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:22:06 --> Utf8 Class Initialized
INFO - 2021-02-26 09:22:06 --> URI Class Initialized
INFO - 2021-02-26 09:22:06 --> Router Class Initialized
INFO - 2021-02-26 09:22:06 --> Output Class Initialized
INFO - 2021-02-26 09:22:06 --> Security Class Initialized
DEBUG - 2021-02-26 09:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:22:06 --> Input Class Initialized
INFO - 2021-02-26 09:22:06 --> Language Class Initialized
INFO - 2021-02-26 09:22:06 --> Language Class Initialized
INFO - 2021-02-26 09:22:06 --> Config Class Initialized
INFO - 2021-02-26 09:22:06 --> Loader Class Initialized
INFO - 2021-02-26 09:22:06 --> Helper loaded: url_helper
INFO - 2021-02-26 09:22:06 --> Helper loaded: file_helper
INFO - 2021-02-26 09:22:06 --> Helper loaded: form_helper
INFO - 2021-02-26 09:22:06 --> Helper loaded: my_helper
INFO - 2021-02-26 09:22:06 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:22:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:22:06 --> Controller Class Initialized
DEBUG - 2021-02-26 09:22:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-02-26 09:22:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 09:22:07 --> Final output sent to browser
DEBUG - 2021-02-26 09:22:07 --> Total execution time: 0.3020
INFO - 2021-02-26 09:22:13 --> Config Class Initialized
INFO - 2021-02-26 09:22:13 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:22:13 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:22:13 --> Utf8 Class Initialized
INFO - 2021-02-26 09:22:13 --> URI Class Initialized
INFO - 2021-02-26 09:22:13 --> Router Class Initialized
INFO - 2021-02-26 09:22:13 --> Output Class Initialized
INFO - 2021-02-26 09:22:13 --> Security Class Initialized
DEBUG - 2021-02-26 09:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:22:13 --> Input Class Initialized
INFO - 2021-02-26 09:22:13 --> Language Class Initialized
INFO - 2021-02-26 09:22:13 --> Language Class Initialized
INFO - 2021-02-26 09:22:13 --> Config Class Initialized
INFO - 2021-02-26 09:22:13 --> Loader Class Initialized
INFO - 2021-02-26 09:22:13 --> Helper loaded: url_helper
INFO - 2021-02-26 09:22:13 --> Helper loaded: file_helper
INFO - 2021-02-26 09:22:13 --> Helper loaded: form_helper
INFO - 2021-02-26 09:22:13 --> Helper loaded: my_helper
INFO - 2021-02-26 09:22:13 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:22:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:22:13 --> Controller Class Initialized
INFO - 2021-02-26 09:22:13 --> Helper loaded: cookie_helper
INFO - 2021-02-26 09:22:13 --> Final output sent to browser
DEBUG - 2021-02-26 09:22:13 --> Total execution time: 0.3877
INFO - 2021-02-26 09:22:13 --> Config Class Initialized
INFO - 2021-02-26 09:22:13 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:22:13 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:22:13 --> Utf8 Class Initialized
INFO - 2021-02-26 09:22:13 --> URI Class Initialized
INFO - 2021-02-26 09:22:13 --> Router Class Initialized
INFO - 2021-02-26 09:22:13 --> Output Class Initialized
INFO - 2021-02-26 09:22:13 --> Security Class Initialized
DEBUG - 2021-02-26 09:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:22:14 --> Input Class Initialized
INFO - 2021-02-26 09:22:14 --> Language Class Initialized
INFO - 2021-02-26 09:22:14 --> Language Class Initialized
INFO - 2021-02-26 09:22:14 --> Config Class Initialized
INFO - 2021-02-26 09:22:14 --> Loader Class Initialized
INFO - 2021-02-26 09:22:14 --> Helper loaded: url_helper
INFO - 2021-02-26 09:22:14 --> Helper loaded: file_helper
INFO - 2021-02-26 09:22:14 --> Helper loaded: form_helper
INFO - 2021-02-26 09:22:14 --> Helper loaded: my_helper
INFO - 2021-02-26 09:22:14 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:22:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:22:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:22:14 --> Controller Class Initialized
DEBUG - 2021-02-26 09:22:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-02-26 09:22:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 09:22:14 --> Final output sent to browser
DEBUG - 2021-02-26 09:22:14 --> Total execution time: 0.4194
INFO - 2021-02-26 09:22:17 --> Config Class Initialized
INFO - 2021-02-26 09:22:17 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:22:17 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:22:17 --> Utf8 Class Initialized
INFO - 2021-02-26 09:22:17 --> URI Class Initialized
INFO - 2021-02-26 09:22:17 --> Router Class Initialized
INFO - 2021-02-26 09:22:17 --> Output Class Initialized
INFO - 2021-02-26 09:22:17 --> Security Class Initialized
DEBUG - 2021-02-26 09:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:22:17 --> Input Class Initialized
INFO - 2021-02-26 09:22:17 --> Language Class Initialized
INFO - 2021-02-26 09:22:17 --> Language Class Initialized
INFO - 2021-02-26 09:22:17 --> Config Class Initialized
INFO - 2021-02-26 09:22:17 --> Loader Class Initialized
INFO - 2021-02-26 09:22:17 --> Helper loaded: url_helper
INFO - 2021-02-26 09:22:17 --> Helper loaded: file_helper
INFO - 2021-02-26 09:22:17 --> Helper loaded: form_helper
INFO - 2021-02-26 09:22:17 --> Helper loaded: my_helper
INFO - 2021-02-26 09:22:17 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:22:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:22:17 --> Controller Class Initialized
DEBUG - 2021-02-26 09:22:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-02-26 09:22:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 09:22:17 --> Final output sent to browser
DEBUG - 2021-02-26 09:22:17 --> Total execution time: 0.3259
INFO - 2021-02-26 09:22:19 --> Config Class Initialized
INFO - 2021-02-26 09:22:19 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:22:19 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:22:19 --> Utf8 Class Initialized
INFO - 2021-02-26 09:22:19 --> URI Class Initialized
INFO - 2021-02-26 09:22:19 --> Router Class Initialized
INFO - 2021-02-26 09:22:19 --> Output Class Initialized
INFO - 2021-02-26 09:22:19 --> Security Class Initialized
DEBUG - 2021-02-26 09:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:22:19 --> Input Class Initialized
INFO - 2021-02-26 09:22:19 --> Language Class Initialized
INFO - 2021-02-26 09:22:19 --> Language Class Initialized
INFO - 2021-02-26 09:22:19 --> Config Class Initialized
INFO - 2021-02-26 09:22:19 --> Loader Class Initialized
INFO - 2021-02-26 09:22:19 --> Helper loaded: url_helper
INFO - 2021-02-26 09:22:19 --> Helper loaded: file_helper
INFO - 2021-02-26 09:22:19 --> Helper loaded: form_helper
INFO - 2021-02-26 09:22:19 --> Helper loaded: my_helper
INFO - 2021-02-26 09:22:19 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:22:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:22:19 --> Controller Class Initialized
DEBUG - 2021-02-26 09:22:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-02-26 09:22:19 --> Final output sent to browser
DEBUG - 2021-02-26 09:22:19 --> Total execution time: 0.3426
INFO - 2021-02-26 09:22:34 --> Config Class Initialized
INFO - 2021-02-26 09:22:34 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:22:34 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:22:34 --> Utf8 Class Initialized
INFO - 2021-02-26 09:22:34 --> URI Class Initialized
INFO - 2021-02-26 09:22:34 --> Router Class Initialized
INFO - 2021-02-26 09:22:34 --> Output Class Initialized
INFO - 2021-02-26 09:22:34 --> Security Class Initialized
DEBUG - 2021-02-26 09:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:22:34 --> Input Class Initialized
INFO - 2021-02-26 09:22:34 --> Language Class Initialized
INFO - 2021-02-26 09:22:34 --> Language Class Initialized
INFO - 2021-02-26 09:22:34 --> Config Class Initialized
INFO - 2021-02-26 09:22:34 --> Loader Class Initialized
INFO - 2021-02-26 09:22:34 --> Helper loaded: url_helper
INFO - 2021-02-26 09:22:34 --> Helper loaded: file_helper
INFO - 2021-02-26 09:22:34 --> Helper loaded: form_helper
INFO - 2021-02-26 09:22:34 --> Helper loaded: my_helper
INFO - 2021-02-26 09:22:34 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:22:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:22:35 --> Controller Class Initialized
DEBUG - 2021-02-26 09:22:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-02-26 09:22:35 --> Final output sent to browser
DEBUG - 2021-02-26 09:22:35 --> Total execution time: 0.3528
INFO - 2021-02-26 09:22:54 --> Config Class Initialized
INFO - 2021-02-26 09:22:54 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:22:54 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:22:54 --> Utf8 Class Initialized
INFO - 2021-02-26 09:22:54 --> URI Class Initialized
INFO - 2021-02-26 09:22:54 --> Router Class Initialized
INFO - 2021-02-26 09:22:54 --> Output Class Initialized
INFO - 2021-02-26 09:22:54 --> Security Class Initialized
DEBUG - 2021-02-26 09:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:22:54 --> Input Class Initialized
INFO - 2021-02-26 09:22:54 --> Language Class Initialized
INFO - 2021-02-26 09:22:54 --> Language Class Initialized
INFO - 2021-02-26 09:22:54 --> Config Class Initialized
INFO - 2021-02-26 09:22:54 --> Loader Class Initialized
INFO - 2021-02-26 09:22:54 --> Helper loaded: url_helper
INFO - 2021-02-26 09:22:54 --> Helper loaded: file_helper
INFO - 2021-02-26 09:22:54 --> Helper loaded: form_helper
INFO - 2021-02-26 09:22:54 --> Helper loaded: my_helper
INFO - 2021-02-26 09:22:54 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:22:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:22:54 --> Controller Class Initialized
DEBUG - 2021-02-26 09:22:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-02-26 09:22:55 --> Final output sent to browser
DEBUG - 2021-02-26 09:22:55 --> Total execution time: 0.3333
INFO - 2021-02-26 09:23:37 --> Config Class Initialized
INFO - 2021-02-26 09:23:37 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:23:37 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:23:37 --> Utf8 Class Initialized
INFO - 2021-02-26 09:23:37 --> URI Class Initialized
INFO - 2021-02-26 09:23:37 --> Router Class Initialized
INFO - 2021-02-26 09:23:37 --> Output Class Initialized
INFO - 2021-02-26 09:23:37 --> Security Class Initialized
DEBUG - 2021-02-26 09:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:23:37 --> Input Class Initialized
INFO - 2021-02-26 09:23:37 --> Language Class Initialized
INFO - 2021-02-26 09:23:37 --> Language Class Initialized
INFO - 2021-02-26 09:23:37 --> Config Class Initialized
INFO - 2021-02-26 09:23:37 --> Loader Class Initialized
INFO - 2021-02-26 09:23:37 --> Helper loaded: url_helper
INFO - 2021-02-26 09:23:37 --> Helper loaded: file_helper
INFO - 2021-02-26 09:23:37 --> Helper loaded: form_helper
INFO - 2021-02-26 09:23:37 --> Helper loaded: my_helper
INFO - 2021-02-26 09:23:37 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:23:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:23:37 --> Controller Class Initialized
INFO - 2021-02-26 09:23:37 --> Helper loaded: cookie_helper
INFO - 2021-02-26 09:23:37 --> Config Class Initialized
INFO - 2021-02-26 09:23:37 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:23:38 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:23:38 --> Utf8 Class Initialized
INFO - 2021-02-26 09:23:38 --> URI Class Initialized
INFO - 2021-02-26 09:23:38 --> Router Class Initialized
INFO - 2021-02-26 09:23:38 --> Output Class Initialized
INFO - 2021-02-26 09:23:38 --> Security Class Initialized
DEBUG - 2021-02-26 09:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:23:38 --> Input Class Initialized
INFO - 2021-02-26 09:23:38 --> Language Class Initialized
INFO - 2021-02-26 09:23:38 --> Language Class Initialized
INFO - 2021-02-26 09:23:38 --> Config Class Initialized
INFO - 2021-02-26 09:23:38 --> Loader Class Initialized
INFO - 2021-02-26 09:23:38 --> Helper loaded: url_helper
INFO - 2021-02-26 09:23:38 --> Helper loaded: file_helper
INFO - 2021-02-26 09:23:38 --> Helper loaded: form_helper
INFO - 2021-02-26 09:23:38 --> Helper loaded: my_helper
INFO - 2021-02-26 09:23:38 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:23:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:23:38 --> Controller Class Initialized
DEBUG - 2021-02-26 09:23:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-02-26 09:23:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 09:23:38 --> Final output sent to browser
DEBUG - 2021-02-26 09:23:38 --> Total execution time: 0.2928
INFO - 2021-02-26 09:23:49 --> Config Class Initialized
INFO - 2021-02-26 09:23:49 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:23:49 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:23:49 --> Utf8 Class Initialized
INFO - 2021-02-26 09:23:50 --> URI Class Initialized
INFO - 2021-02-26 09:23:50 --> Router Class Initialized
INFO - 2021-02-26 09:23:50 --> Output Class Initialized
INFO - 2021-02-26 09:23:50 --> Security Class Initialized
DEBUG - 2021-02-26 09:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:23:50 --> Input Class Initialized
INFO - 2021-02-26 09:23:50 --> Language Class Initialized
INFO - 2021-02-26 09:23:50 --> Language Class Initialized
INFO - 2021-02-26 09:23:50 --> Config Class Initialized
INFO - 2021-02-26 09:23:50 --> Loader Class Initialized
INFO - 2021-02-26 09:23:50 --> Helper loaded: url_helper
INFO - 2021-02-26 09:23:50 --> Helper loaded: file_helper
INFO - 2021-02-26 09:23:50 --> Helper loaded: form_helper
INFO - 2021-02-26 09:23:50 --> Helper loaded: my_helper
INFO - 2021-02-26 09:23:50 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:23:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:23:50 --> Controller Class Initialized
INFO - 2021-02-26 09:23:50 --> Helper loaded: cookie_helper
INFO - 2021-02-26 09:23:50 --> Final output sent to browser
DEBUG - 2021-02-26 09:23:50 --> Total execution time: 0.3875
INFO - 2021-02-26 09:23:50 --> Config Class Initialized
INFO - 2021-02-26 09:23:50 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:23:50 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:23:50 --> Utf8 Class Initialized
INFO - 2021-02-26 09:23:50 --> URI Class Initialized
INFO - 2021-02-26 09:23:50 --> Router Class Initialized
INFO - 2021-02-26 09:23:50 --> Output Class Initialized
INFO - 2021-02-26 09:23:50 --> Security Class Initialized
DEBUG - 2021-02-26 09:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:23:51 --> Input Class Initialized
INFO - 2021-02-26 09:23:51 --> Language Class Initialized
INFO - 2021-02-26 09:23:51 --> Language Class Initialized
INFO - 2021-02-26 09:23:51 --> Config Class Initialized
INFO - 2021-02-26 09:23:51 --> Loader Class Initialized
INFO - 2021-02-26 09:23:51 --> Helper loaded: url_helper
INFO - 2021-02-26 09:23:51 --> Helper loaded: file_helper
INFO - 2021-02-26 09:23:51 --> Helper loaded: form_helper
INFO - 2021-02-26 09:23:51 --> Helper loaded: my_helper
INFO - 2021-02-26 09:23:51 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:23:51 --> Controller Class Initialized
DEBUG - 2021-02-26 09:23:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-02-26 09:23:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 09:23:51 --> Final output sent to browser
DEBUG - 2021-02-26 09:23:51 --> Total execution time: 0.4746
INFO - 2021-02-26 09:23:56 --> Config Class Initialized
INFO - 2021-02-26 09:23:56 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:23:56 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:23:56 --> Utf8 Class Initialized
INFO - 2021-02-26 09:23:56 --> URI Class Initialized
INFO - 2021-02-26 09:23:56 --> Router Class Initialized
INFO - 2021-02-26 09:23:56 --> Output Class Initialized
INFO - 2021-02-26 09:23:56 --> Security Class Initialized
DEBUG - 2021-02-26 09:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:23:56 --> Input Class Initialized
INFO - 2021-02-26 09:23:56 --> Language Class Initialized
INFO - 2021-02-26 09:23:56 --> Language Class Initialized
INFO - 2021-02-26 09:23:56 --> Config Class Initialized
INFO - 2021-02-26 09:23:56 --> Loader Class Initialized
INFO - 2021-02-26 09:23:56 --> Helper loaded: url_helper
INFO - 2021-02-26 09:23:56 --> Helper loaded: file_helper
INFO - 2021-02-26 09:23:56 --> Helper loaded: form_helper
INFO - 2021-02-26 09:23:56 --> Helper loaded: my_helper
INFO - 2021-02-26 09:23:56 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:23:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:23:56 --> Controller Class Initialized
INFO - 2021-02-26 09:23:56 --> Helper loaded: cookie_helper
INFO - 2021-02-26 09:23:56 --> Config Class Initialized
INFO - 2021-02-26 09:23:56 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:23:56 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:23:56 --> Utf8 Class Initialized
INFO - 2021-02-26 09:23:56 --> URI Class Initialized
INFO - 2021-02-26 09:23:56 --> Router Class Initialized
INFO - 2021-02-26 09:23:56 --> Output Class Initialized
INFO - 2021-02-26 09:23:56 --> Security Class Initialized
DEBUG - 2021-02-26 09:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:23:56 --> Input Class Initialized
INFO - 2021-02-26 09:23:56 --> Language Class Initialized
INFO - 2021-02-26 09:23:56 --> Language Class Initialized
INFO - 2021-02-26 09:23:56 --> Config Class Initialized
INFO - 2021-02-26 09:23:56 --> Loader Class Initialized
INFO - 2021-02-26 09:23:56 --> Helper loaded: url_helper
INFO - 2021-02-26 09:23:56 --> Helper loaded: file_helper
INFO - 2021-02-26 09:23:56 --> Helper loaded: form_helper
INFO - 2021-02-26 09:23:56 --> Helper loaded: my_helper
INFO - 2021-02-26 09:23:56 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:23:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:23:56 --> Controller Class Initialized
DEBUG - 2021-02-26 09:23:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-02-26 09:23:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 09:23:57 --> Final output sent to browser
DEBUG - 2021-02-26 09:23:57 --> Total execution time: 0.3707
INFO - 2021-02-26 09:24:10 --> Config Class Initialized
INFO - 2021-02-26 09:24:10 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:24:10 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:24:10 --> Utf8 Class Initialized
INFO - 2021-02-26 09:24:10 --> URI Class Initialized
INFO - 2021-02-26 09:24:10 --> Router Class Initialized
INFO - 2021-02-26 09:24:10 --> Output Class Initialized
INFO - 2021-02-26 09:24:10 --> Security Class Initialized
DEBUG - 2021-02-26 09:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:24:10 --> Input Class Initialized
INFO - 2021-02-26 09:24:10 --> Language Class Initialized
INFO - 2021-02-26 09:24:10 --> Language Class Initialized
INFO - 2021-02-26 09:24:10 --> Config Class Initialized
INFO - 2021-02-26 09:24:10 --> Loader Class Initialized
INFO - 2021-02-26 09:24:10 --> Helper loaded: url_helper
INFO - 2021-02-26 09:24:10 --> Helper loaded: file_helper
INFO - 2021-02-26 09:24:10 --> Helper loaded: form_helper
INFO - 2021-02-26 09:24:10 --> Helper loaded: my_helper
INFO - 2021-02-26 09:24:10 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:24:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:24:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:24:10 --> Controller Class Initialized
INFO - 2021-02-26 09:24:10 --> Helper loaded: cookie_helper
INFO - 2021-02-26 09:24:10 --> Final output sent to browser
DEBUG - 2021-02-26 09:24:10 --> Total execution time: 0.3828
INFO - 2021-02-26 09:24:10 --> Config Class Initialized
INFO - 2021-02-26 09:24:10 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:24:10 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:24:11 --> Utf8 Class Initialized
INFO - 2021-02-26 09:24:11 --> URI Class Initialized
INFO - 2021-02-26 09:24:11 --> Router Class Initialized
INFO - 2021-02-26 09:24:11 --> Output Class Initialized
INFO - 2021-02-26 09:24:11 --> Security Class Initialized
DEBUG - 2021-02-26 09:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:24:11 --> Input Class Initialized
INFO - 2021-02-26 09:24:11 --> Language Class Initialized
INFO - 2021-02-26 09:24:11 --> Language Class Initialized
INFO - 2021-02-26 09:24:11 --> Config Class Initialized
INFO - 2021-02-26 09:24:11 --> Loader Class Initialized
INFO - 2021-02-26 09:24:11 --> Helper loaded: url_helper
INFO - 2021-02-26 09:24:11 --> Helper loaded: file_helper
INFO - 2021-02-26 09:24:11 --> Helper loaded: form_helper
INFO - 2021-02-26 09:24:11 --> Helper loaded: my_helper
INFO - 2021-02-26 09:24:11 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:24:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:24:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:24:11 --> Controller Class Initialized
DEBUG - 2021-02-26 09:24:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-02-26 09:24:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 09:24:11 --> Final output sent to browser
DEBUG - 2021-02-26 09:24:11 --> Total execution time: 0.4468
INFO - 2021-02-26 09:24:13 --> Config Class Initialized
INFO - 2021-02-26 09:24:13 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:24:13 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:24:13 --> Utf8 Class Initialized
INFO - 2021-02-26 09:24:13 --> URI Class Initialized
INFO - 2021-02-26 09:24:13 --> Router Class Initialized
INFO - 2021-02-26 09:24:13 --> Output Class Initialized
INFO - 2021-02-26 09:24:13 --> Security Class Initialized
DEBUG - 2021-02-26 09:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:24:13 --> Input Class Initialized
INFO - 2021-02-26 09:24:13 --> Language Class Initialized
INFO - 2021-02-26 09:24:13 --> Language Class Initialized
INFO - 2021-02-26 09:24:13 --> Config Class Initialized
INFO - 2021-02-26 09:24:13 --> Loader Class Initialized
INFO - 2021-02-26 09:24:13 --> Helper loaded: url_helper
INFO - 2021-02-26 09:24:13 --> Helper loaded: file_helper
INFO - 2021-02-26 09:24:13 --> Helper loaded: form_helper
INFO - 2021-02-26 09:24:13 --> Helper loaded: my_helper
INFO - 2021-02-26 09:24:13 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:24:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:24:13 --> Controller Class Initialized
DEBUG - 2021-02-26 09:24:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-02-26 09:24:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 09:24:13 --> Final output sent to browser
DEBUG - 2021-02-26 09:24:13 --> Total execution time: 0.4388
INFO - 2021-02-26 09:24:14 --> Config Class Initialized
INFO - 2021-02-26 09:24:14 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:24:14 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:24:14 --> Utf8 Class Initialized
INFO - 2021-02-26 09:24:14 --> URI Class Initialized
INFO - 2021-02-26 09:24:14 --> Router Class Initialized
INFO - 2021-02-26 09:24:14 --> Output Class Initialized
INFO - 2021-02-26 09:24:14 --> Security Class Initialized
DEBUG - 2021-02-26 09:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:24:14 --> Input Class Initialized
INFO - 2021-02-26 09:24:14 --> Language Class Initialized
INFO - 2021-02-26 09:24:14 --> Language Class Initialized
INFO - 2021-02-26 09:24:14 --> Config Class Initialized
INFO - 2021-02-26 09:24:14 --> Loader Class Initialized
INFO - 2021-02-26 09:24:14 --> Helper loaded: url_helper
INFO - 2021-02-26 09:24:14 --> Helper loaded: file_helper
INFO - 2021-02-26 09:24:14 --> Helper loaded: form_helper
INFO - 2021-02-26 09:24:14 --> Helper loaded: my_helper
INFO - 2021-02-26 09:24:14 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:24:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:24:14 --> Controller Class Initialized
DEBUG - 2021-02-26 09:24:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-02-26 09:24:14 --> Final output sent to browser
DEBUG - 2021-02-26 09:24:14 --> Total execution time: 0.3609
INFO - 2021-02-26 09:24:24 --> Config Class Initialized
INFO - 2021-02-26 09:24:24 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:24:24 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:24:24 --> Utf8 Class Initialized
INFO - 2021-02-26 09:24:24 --> URI Class Initialized
INFO - 2021-02-26 09:24:24 --> Router Class Initialized
INFO - 2021-02-26 09:24:24 --> Output Class Initialized
INFO - 2021-02-26 09:24:24 --> Security Class Initialized
DEBUG - 2021-02-26 09:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:24:24 --> Input Class Initialized
INFO - 2021-02-26 09:24:24 --> Language Class Initialized
INFO - 2021-02-26 09:24:24 --> Language Class Initialized
INFO - 2021-02-26 09:24:24 --> Config Class Initialized
INFO - 2021-02-26 09:24:24 --> Loader Class Initialized
INFO - 2021-02-26 09:24:24 --> Helper loaded: url_helper
INFO - 2021-02-26 09:24:24 --> Helper loaded: file_helper
INFO - 2021-02-26 09:24:24 --> Helper loaded: form_helper
INFO - 2021-02-26 09:24:24 --> Helper loaded: my_helper
INFO - 2021-02-26 09:24:24 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:24:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:24:24 --> Controller Class Initialized
INFO - 2021-02-26 09:24:24 --> Helper loaded: cookie_helper
INFO - 2021-02-26 09:24:24 --> Config Class Initialized
INFO - 2021-02-26 09:24:24 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:24:24 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:24:24 --> Utf8 Class Initialized
INFO - 2021-02-26 09:24:24 --> URI Class Initialized
INFO - 2021-02-26 09:24:24 --> Router Class Initialized
INFO - 2021-02-26 09:24:25 --> Output Class Initialized
INFO - 2021-02-26 09:24:25 --> Security Class Initialized
DEBUG - 2021-02-26 09:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:24:25 --> Input Class Initialized
INFO - 2021-02-26 09:24:25 --> Language Class Initialized
INFO - 2021-02-26 09:24:25 --> Language Class Initialized
INFO - 2021-02-26 09:24:25 --> Config Class Initialized
INFO - 2021-02-26 09:24:25 --> Loader Class Initialized
INFO - 2021-02-26 09:24:25 --> Helper loaded: url_helper
INFO - 2021-02-26 09:24:25 --> Helper loaded: file_helper
INFO - 2021-02-26 09:24:25 --> Helper loaded: form_helper
INFO - 2021-02-26 09:24:25 --> Helper loaded: my_helper
INFO - 2021-02-26 09:24:25 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:24:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:24:25 --> Controller Class Initialized
DEBUG - 2021-02-26 09:24:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-02-26 09:24:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 09:24:25 --> Final output sent to browser
DEBUG - 2021-02-26 09:24:25 --> Total execution time: 0.3286
INFO - 2021-02-26 09:24:37 --> Config Class Initialized
INFO - 2021-02-26 09:24:37 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:24:37 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:24:37 --> Utf8 Class Initialized
INFO - 2021-02-26 09:24:37 --> URI Class Initialized
INFO - 2021-02-26 09:24:37 --> Router Class Initialized
INFO - 2021-02-26 09:24:37 --> Output Class Initialized
INFO - 2021-02-26 09:24:37 --> Security Class Initialized
DEBUG - 2021-02-26 09:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:24:37 --> Input Class Initialized
INFO - 2021-02-26 09:24:37 --> Language Class Initialized
INFO - 2021-02-26 09:24:37 --> Language Class Initialized
INFO - 2021-02-26 09:24:37 --> Config Class Initialized
INFO - 2021-02-26 09:24:37 --> Loader Class Initialized
INFO - 2021-02-26 09:24:37 --> Helper loaded: url_helper
INFO - 2021-02-26 09:24:37 --> Helper loaded: file_helper
INFO - 2021-02-26 09:24:37 --> Helper loaded: form_helper
INFO - 2021-02-26 09:24:37 --> Helper loaded: my_helper
INFO - 2021-02-26 09:24:37 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:24:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:24:37 --> Controller Class Initialized
INFO - 2021-02-26 09:24:37 --> Helper loaded: cookie_helper
INFO - 2021-02-26 09:24:37 --> Final output sent to browser
DEBUG - 2021-02-26 09:24:37 --> Total execution time: 0.3566
INFO - 2021-02-26 09:24:38 --> Config Class Initialized
INFO - 2021-02-26 09:24:38 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:24:38 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:24:38 --> Utf8 Class Initialized
INFO - 2021-02-26 09:24:38 --> URI Class Initialized
INFO - 2021-02-26 09:24:38 --> Router Class Initialized
INFO - 2021-02-26 09:24:38 --> Output Class Initialized
INFO - 2021-02-26 09:24:38 --> Security Class Initialized
DEBUG - 2021-02-26 09:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:24:38 --> Input Class Initialized
INFO - 2021-02-26 09:24:38 --> Language Class Initialized
INFO - 2021-02-26 09:24:38 --> Language Class Initialized
INFO - 2021-02-26 09:24:38 --> Config Class Initialized
INFO - 2021-02-26 09:24:38 --> Loader Class Initialized
INFO - 2021-02-26 09:24:38 --> Helper loaded: url_helper
INFO - 2021-02-26 09:24:38 --> Helper loaded: file_helper
INFO - 2021-02-26 09:24:38 --> Helper loaded: form_helper
INFO - 2021-02-26 09:24:38 --> Helper loaded: my_helper
INFO - 2021-02-26 09:24:38 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:24:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:24:38 --> Controller Class Initialized
DEBUG - 2021-02-26 09:24:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-02-26 09:24:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 09:24:38 --> Final output sent to browser
DEBUG - 2021-02-26 09:24:38 --> Total execution time: 0.4578
INFO - 2021-02-26 09:24:40 --> Config Class Initialized
INFO - 2021-02-26 09:24:40 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:24:40 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:24:40 --> Utf8 Class Initialized
INFO - 2021-02-26 09:24:40 --> URI Class Initialized
INFO - 2021-02-26 09:24:40 --> Router Class Initialized
INFO - 2021-02-26 09:24:40 --> Output Class Initialized
INFO - 2021-02-26 09:24:40 --> Security Class Initialized
DEBUG - 2021-02-26 09:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:24:40 --> Input Class Initialized
INFO - 2021-02-26 09:24:40 --> Language Class Initialized
INFO - 2021-02-26 09:24:40 --> Language Class Initialized
INFO - 2021-02-26 09:24:40 --> Config Class Initialized
INFO - 2021-02-26 09:24:40 --> Loader Class Initialized
INFO - 2021-02-26 09:24:40 --> Helper loaded: url_helper
INFO - 2021-02-26 09:24:40 --> Helper loaded: file_helper
INFO - 2021-02-26 09:24:40 --> Helper loaded: form_helper
INFO - 2021-02-26 09:24:40 --> Helper loaded: my_helper
INFO - 2021-02-26 09:24:40 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:24:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:24:40 --> Controller Class Initialized
DEBUG - 2021-02-26 09:24:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-02-26 09:24:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 09:24:40 --> Final output sent to browser
DEBUG - 2021-02-26 09:24:41 --> Total execution time: 0.3069
INFO - 2021-02-26 09:24:44 --> Config Class Initialized
INFO - 2021-02-26 09:24:44 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:24:44 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:24:44 --> Utf8 Class Initialized
INFO - 2021-02-26 09:24:44 --> URI Class Initialized
INFO - 2021-02-26 09:24:44 --> Router Class Initialized
INFO - 2021-02-26 09:24:44 --> Output Class Initialized
INFO - 2021-02-26 09:24:44 --> Security Class Initialized
DEBUG - 2021-02-26 09:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:24:44 --> Input Class Initialized
INFO - 2021-02-26 09:24:44 --> Language Class Initialized
INFO - 2021-02-26 09:24:44 --> Language Class Initialized
INFO - 2021-02-26 09:24:44 --> Config Class Initialized
INFO - 2021-02-26 09:24:44 --> Loader Class Initialized
INFO - 2021-02-26 09:24:44 --> Helper loaded: url_helper
INFO - 2021-02-26 09:24:45 --> Helper loaded: file_helper
INFO - 2021-02-26 09:24:45 --> Helper loaded: form_helper
INFO - 2021-02-26 09:24:45 --> Helper loaded: my_helper
INFO - 2021-02-26 09:24:45 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:24:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:24:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:24:45 --> Controller Class Initialized
DEBUG - 2021-02-26 09:24:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-02-26 09:24:45 --> Final output sent to browser
DEBUG - 2021-02-26 09:24:45 --> Total execution time: 0.3283
INFO - 2021-02-26 09:25:03 --> Config Class Initialized
INFO - 2021-02-26 09:25:03 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:25:03 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:25:03 --> Utf8 Class Initialized
INFO - 2021-02-26 09:25:03 --> URI Class Initialized
INFO - 2021-02-26 09:25:03 --> Router Class Initialized
INFO - 2021-02-26 09:25:03 --> Output Class Initialized
INFO - 2021-02-26 09:25:03 --> Security Class Initialized
DEBUG - 2021-02-26 09:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:25:03 --> Input Class Initialized
INFO - 2021-02-26 09:25:03 --> Language Class Initialized
INFO - 2021-02-26 09:25:03 --> Language Class Initialized
INFO - 2021-02-26 09:25:03 --> Config Class Initialized
INFO - 2021-02-26 09:25:03 --> Loader Class Initialized
INFO - 2021-02-26 09:25:03 --> Helper loaded: url_helper
INFO - 2021-02-26 09:25:04 --> Helper loaded: file_helper
INFO - 2021-02-26 09:25:04 --> Helper loaded: form_helper
INFO - 2021-02-26 09:25:04 --> Helper loaded: my_helper
INFO - 2021-02-26 09:25:04 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:25:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:25:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:25:04 --> Controller Class Initialized
INFO - 2021-02-26 09:25:04 --> Helper loaded: cookie_helper
INFO - 2021-02-26 09:25:04 --> Config Class Initialized
INFO - 2021-02-26 09:25:04 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:25:04 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:25:04 --> Utf8 Class Initialized
INFO - 2021-02-26 09:25:04 --> URI Class Initialized
INFO - 2021-02-26 09:25:04 --> Router Class Initialized
INFO - 2021-02-26 09:25:04 --> Output Class Initialized
INFO - 2021-02-26 09:25:04 --> Security Class Initialized
DEBUG - 2021-02-26 09:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:25:04 --> Input Class Initialized
INFO - 2021-02-26 09:25:04 --> Language Class Initialized
INFO - 2021-02-26 09:25:04 --> Language Class Initialized
INFO - 2021-02-26 09:25:04 --> Config Class Initialized
INFO - 2021-02-26 09:25:04 --> Loader Class Initialized
INFO - 2021-02-26 09:25:04 --> Helper loaded: url_helper
INFO - 2021-02-26 09:25:04 --> Helper loaded: file_helper
INFO - 2021-02-26 09:25:04 --> Helper loaded: form_helper
INFO - 2021-02-26 09:25:04 --> Helper loaded: my_helper
INFO - 2021-02-26 09:25:04 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:25:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:25:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:25:04 --> Controller Class Initialized
DEBUG - 2021-02-26 09:25:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-02-26 09:25:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 09:25:04 --> Final output sent to browser
DEBUG - 2021-02-26 09:25:04 --> Total execution time: 0.3093
INFO - 2021-02-26 09:25:12 --> Config Class Initialized
INFO - 2021-02-26 09:25:12 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:25:12 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:25:12 --> Utf8 Class Initialized
INFO - 2021-02-26 09:25:12 --> URI Class Initialized
INFO - 2021-02-26 09:25:12 --> Router Class Initialized
INFO - 2021-02-26 09:25:13 --> Output Class Initialized
INFO - 2021-02-26 09:25:13 --> Security Class Initialized
DEBUG - 2021-02-26 09:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:25:13 --> Input Class Initialized
INFO - 2021-02-26 09:25:13 --> Language Class Initialized
INFO - 2021-02-26 09:25:13 --> Language Class Initialized
INFO - 2021-02-26 09:25:13 --> Config Class Initialized
INFO - 2021-02-26 09:25:13 --> Loader Class Initialized
INFO - 2021-02-26 09:25:13 --> Helper loaded: url_helper
INFO - 2021-02-26 09:25:13 --> Helper loaded: file_helper
INFO - 2021-02-26 09:25:13 --> Helper loaded: form_helper
INFO - 2021-02-26 09:25:13 --> Helper loaded: my_helper
INFO - 2021-02-26 09:25:13 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:25:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:25:13 --> Controller Class Initialized
INFO - 2021-02-26 09:25:13 --> Helper loaded: cookie_helper
INFO - 2021-02-26 09:25:13 --> Final output sent to browser
DEBUG - 2021-02-26 09:25:13 --> Total execution time: 0.3718
INFO - 2021-02-26 09:25:13 --> Config Class Initialized
INFO - 2021-02-26 09:25:13 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:25:13 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:25:13 --> Utf8 Class Initialized
INFO - 2021-02-26 09:25:13 --> URI Class Initialized
INFO - 2021-02-26 09:25:13 --> Router Class Initialized
INFO - 2021-02-26 09:25:13 --> Output Class Initialized
INFO - 2021-02-26 09:25:14 --> Security Class Initialized
DEBUG - 2021-02-26 09:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:25:14 --> Input Class Initialized
INFO - 2021-02-26 09:25:14 --> Language Class Initialized
INFO - 2021-02-26 09:25:14 --> Language Class Initialized
INFO - 2021-02-26 09:25:14 --> Config Class Initialized
INFO - 2021-02-26 09:25:14 --> Loader Class Initialized
INFO - 2021-02-26 09:25:14 --> Helper loaded: url_helper
INFO - 2021-02-26 09:25:14 --> Helper loaded: file_helper
INFO - 2021-02-26 09:25:14 --> Helper loaded: form_helper
INFO - 2021-02-26 09:25:14 --> Helper loaded: my_helper
INFO - 2021-02-26 09:25:14 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:25:14 --> Controller Class Initialized
DEBUG - 2021-02-26 09:25:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-02-26 09:25:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 09:25:14 --> Final output sent to browser
DEBUG - 2021-02-26 09:25:14 --> Total execution time: 0.5076
INFO - 2021-02-26 09:25:15 --> Config Class Initialized
INFO - 2021-02-26 09:25:15 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:25:15 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:25:15 --> Utf8 Class Initialized
INFO - 2021-02-26 09:25:15 --> URI Class Initialized
INFO - 2021-02-26 09:25:15 --> Router Class Initialized
INFO - 2021-02-26 09:25:15 --> Output Class Initialized
INFO - 2021-02-26 09:25:16 --> Security Class Initialized
DEBUG - 2021-02-26 09:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:25:16 --> Input Class Initialized
INFO - 2021-02-26 09:25:16 --> Language Class Initialized
INFO - 2021-02-26 09:25:16 --> Language Class Initialized
INFO - 2021-02-26 09:25:16 --> Config Class Initialized
INFO - 2021-02-26 09:25:16 --> Loader Class Initialized
INFO - 2021-02-26 09:25:16 --> Helper loaded: url_helper
INFO - 2021-02-26 09:25:16 --> Helper loaded: file_helper
INFO - 2021-02-26 09:25:16 --> Helper loaded: form_helper
INFO - 2021-02-26 09:25:16 --> Helper loaded: my_helper
INFO - 2021-02-26 09:25:16 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:25:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:25:16 --> Controller Class Initialized
DEBUG - 2021-02-26 09:25:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-02-26 09:25:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 09:25:16 --> Final output sent to browser
DEBUG - 2021-02-26 09:25:16 --> Total execution time: 0.3853
INFO - 2021-02-26 09:25:17 --> Config Class Initialized
INFO - 2021-02-26 09:25:17 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:25:17 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:25:17 --> Utf8 Class Initialized
INFO - 2021-02-26 09:25:17 --> URI Class Initialized
INFO - 2021-02-26 09:25:17 --> Router Class Initialized
INFO - 2021-02-26 09:25:17 --> Output Class Initialized
INFO - 2021-02-26 09:25:17 --> Security Class Initialized
DEBUG - 2021-02-26 09:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:25:17 --> Input Class Initialized
INFO - 2021-02-26 09:25:17 --> Language Class Initialized
INFO - 2021-02-26 09:25:17 --> Language Class Initialized
INFO - 2021-02-26 09:25:17 --> Config Class Initialized
INFO - 2021-02-26 09:25:17 --> Loader Class Initialized
INFO - 2021-02-26 09:25:17 --> Helper loaded: url_helper
INFO - 2021-02-26 09:25:17 --> Helper loaded: file_helper
INFO - 2021-02-26 09:25:17 --> Helper loaded: form_helper
INFO - 2021-02-26 09:25:18 --> Helper loaded: my_helper
INFO - 2021-02-26 09:25:18 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:25:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:25:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:25:18 --> Controller Class Initialized
DEBUG - 2021-02-26 09:25:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-02-26 09:25:18 --> Final output sent to browser
DEBUG - 2021-02-26 09:25:18 --> Total execution time: 0.3945
INFO - 2021-02-26 09:26:00 --> Config Class Initialized
INFO - 2021-02-26 09:26:00 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:26:00 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:26:00 --> Utf8 Class Initialized
INFO - 2021-02-26 09:26:00 --> URI Class Initialized
INFO - 2021-02-26 09:26:00 --> Router Class Initialized
INFO - 2021-02-26 09:26:00 --> Output Class Initialized
INFO - 2021-02-26 09:26:00 --> Security Class Initialized
DEBUG - 2021-02-26 09:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:26:00 --> Input Class Initialized
INFO - 2021-02-26 09:26:00 --> Language Class Initialized
INFO - 2021-02-26 09:26:00 --> Language Class Initialized
INFO - 2021-02-26 09:26:00 --> Config Class Initialized
INFO - 2021-02-26 09:26:00 --> Loader Class Initialized
INFO - 2021-02-26 09:26:00 --> Helper loaded: url_helper
INFO - 2021-02-26 09:26:00 --> Helper loaded: file_helper
INFO - 2021-02-26 09:26:00 --> Helper loaded: form_helper
INFO - 2021-02-26 09:26:00 --> Helper loaded: my_helper
INFO - 2021-02-26 09:26:00 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:26:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:26:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:26:00 --> Controller Class Initialized
DEBUG - 2021-02-26 09:26:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-02-26 09:26:00 --> Final output sent to browser
DEBUG - 2021-02-26 09:26:00 --> Total execution time: 0.3529
INFO - 2021-02-26 09:26:50 --> Config Class Initialized
INFO - 2021-02-26 09:26:50 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:26:50 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:26:50 --> Utf8 Class Initialized
INFO - 2021-02-26 09:26:50 --> URI Class Initialized
INFO - 2021-02-26 09:26:50 --> Router Class Initialized
INFO - 2021-02-26 09:26:50 --> Output Class Initialized
INFO - 2021-02-26 09:26:50 --> Security Class Initialized
DEBUG - 2021-02-26 09:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:26:50 --> Input Class Initialized
INFO - 2021-02-26 09:26:50 --> Language Class Initialized
INFO - 2021-02-26 09:26:50 --> Language Class Initialized
INFO - 2021-02-26 09:26:50 --> Config Class Initialized
INFO - 2021-02-26 09:26:50 --> Loader Class Initialized
INFO - 2021-02-26 09:26:50 --> Helper loaded: url_helper
INFO - 2021-02-26 09:26:50 --> Helper loaded: file_helper
INFO - 2021-02-26 09:26:50 --> Helper loaded: form_helper
INFO - 2021-02-26 09:26:50 --> Helper loaded: my_helper
INFO - 2021-02-26 09:26:50 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:26:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:26:50 --> Controller Class Initialized
DEBUG - 2021-02-26 09:26:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-02-26 09:26:50 --> Final output sent to browser
DEBUG - 2021-02-26 09:26:50 --> Total execution time: 0.3520
INFO - 2021-02-26 09:28:10 --> Config Class Initialized
INFO - 2021-02-26 09:28:10 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:28:10 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:28:10 --> Utf8 Class Initialized
INFO - 2021-02-26 09:28:10 --> URI Class Initialized
INFO - 2021-02-26 09:28:10 --> Router Class Initialized
INFO - 2021-02-26 09:28:10 --> Output Class Initialized
INFO - 2021-02-26 09:28:10 --> Security Class Initialized
DEBUG - 2021-02-26 09:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:28:10 --> Input Class Initialized
INFO - 2021-02-26 09:28:10 --> Language Class Initialized
INFO - 2021-02-26 09:28:10 --> Language Class Initialized
INFO - 2021-02-26 09:28:10 --> Config Class Initialized
INFO - 2021-02-26 09:28:10 --> Loader Class Initialized
INFO - 2021-02-26 09:28:10 --> Helper loaded: url_helper
INFO - 2021-02-26 09:28:10 --> Helper loaded: file_helper
INFO - 2021-02-26 09:28:10 --> Helper loaded: form_helper
INFO - 2021-02-26 09:28:10 --> Helper loaded: my_helper
INFO - 2021-02-26 09:28:10 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:28:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:28:10 --> Controller Class Initialized
DEBUG - 2021-02-26 09:28:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-02-26 09:28:10 --> Final output sent to browser
DEBUG - 2021-02-26 09:28:10 --> Total execution time: 0.3956
INFO - 2021-02-26 09:28:22 --> Config Class Initialized
INFO - 2021-02-26 09:28:22 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:28:22 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:28:22 --> Utf8 Class Initialized
INFO - 2021-02-26 09:28:22 --> URI Class Initialized
INFO - 2021-02-26 09:28:22 --> Router Class Initialized
INFO - 2021-02-26 09:28:22 --> Output Class Initialized
INFO - 2021-02-26 09:28:22 --> Security Class Initialized
DEBUG - 2021-02-26 09:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:28:22 --> Input Class Initialized
INFO - 2021-02-26 09:28:22 --> Language Class Initialized
INFO - 2021-02-26 09:28:22 --> Language Class Initialized
INFO - 2021-02-26 09:28:22 --> Config Class Initialized
INFO - 2021-02-26 09:28:22 --> Loader Class Initialized
INFO - 2021-02-26 09:28:22 --> Helper loaded: url_helper
INFO - 2021-02-26 09:28:22 --> Helper loaded: file_helper
INFO - 2021-02-26 09:28:22 --> Helper loaded: form_helper
INFO - 2021-02-26 09:28:22 --> Helper loaded: my_helper
INFO - 2021-02-26 09:28:22 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:28:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:28:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:28:22 --> Controller Class Initialized
DEBUG - 2021-02-26 09:28:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-02-26 09:28:22 --> Final output sent to browser
DEBUG - 2021-02-26 09:28:22 --> Total execution time: 0.3645
INFO - 2021-02-26 09:28:36 --> Config Class Initialized
INFO - 2021-02-26 09:28:36 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:28:36 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:28:36 --> Utf8 Class Initialized
INFO - 2021-02-26 09:28:36 --> URI Class Initialized
INFO - 2021-02-26 09:28:36 --> Router Class Initialized
INFO - 2021-02-26 09:28:37 --> Output Class Initialized
INFO - 2021-02-26 09:28:37 --> Security Class Initialized
DEBUG - 2021-02-26 09:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:28:37 --> Input Class Initialized
INFO - 2021-02-26 09:28:37 --> Language Class Initialized
INFO - 2021-02-26 09:28:37 --> Language Class Initialized
INFO - 2021-02-26 09:28:37 --> Config Class Initialized
INFO - 2021-02-26 09:28:37 --> Loader Class Initialized
INFO - 2021-02-26 09:28:37 --> Helper loaded: url_helper
INFO - 2021-02-26 09:28:37 --> Helper loaded: file_helper
INFO - 2021-02-26 09:28:37 --> Helper loaded: form_helper
INFO - 2021-02-26 09:28:37 --> Helper loaded: my_helper
INFO - 2021-02-26 09:28:37 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:28:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:28:37 --> Controller Class Initialized
DEBUG - 2021-02-26 09:28:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-02-26 09:28:37 --> Final output sent to browser
DEBUG - 2021-02-26 09:28:37 --> Total execution time: 0.3467
INFO - 2021-02-26 09:28:45 --> Config Class Initialized
INFO - 2021-02-26 09:28:45 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:28:45 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:28:45 --> Utf8 Class Initialized
INFO - 2021-02-26 09:28:45 --> URI Class Initialized
INFO - 2021-02-26 09:28:45 --> Router Class Initialized
INFO - 2021-02-26 09:28:45 --> Output Class Initialized
INFO - 2021-02-26 09:28:45 --> Security Class Initialized
DEBUG - 2021-02-26 09:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:28:45 --> Input Class Initialized
INFO - 2021-02-26 09:28:45 --> Language Class Initialized
INFO - 2021-02-26 09:28:45 --> Language Class Initialized
INFO - 2021-02-26 09:28:45 --> Config Class Initialized
INFO - 2021-02-26 09:28:45 --> Loader Class Initialized
INFO - 2021-02-26 09:28:45 --> Helper loaded: url_helper
INFO - 2021-02-26 09:28:45 --> Helper loaded: file_helper
INFO - 2021-02-26 09:28:46 --> Helper loaded: form_helper
INFO - 2021-02-26 09:28:46 --> Helper loaded: my_helper
INFO - 2021-02-26 09:28:46 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:28:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:28:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:28:46 --> Controller Class Initialized
DEBUG - 2021-02-26 09:28:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-02-26 09:28:46 --> Final output sent to browser
DEBUG - 2021-02-26 09:28:46 --> Total execution time: 0.3779
INFO - 2021-02-26 09:46:34 --> Config Class Initialized
INFO - 2021-02-26 09:46:34 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:46:34 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:46:34 --> Utf8 Class Initialized
INFO - 2021-02-26 09:46:34 --> URI Class Initialized
INFO - 2021-02-26 09:46:34 --> Router Class Initialized
INFO - 2021-02-26 09:46:34 --> Output Class Initialized
INFO - 2021-02-26 09:46:34 --> Security Class Initialized
DEBUG - 2021-02-26 09:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:46:34 --> Input Class Initialized
INFO - 2021-02-26 09:46:34 --> Language Class Initialized
INFO - 2021-02-26 09:46:34 --> Language Class Initialized
INFO - 2021-02-26 09:46:34 --> Config Class Initialized
INFO - 2021-02-26 09:46:34 --> Loader Class Initialized
INFO - 2021-02-26 09:46:34 --> Helper loaded: url_helper
INFO - 2021-02-26 09:46:34 --> Helper loaded: file_helper
INFO - 2021-02-26 09:46:34 --> Helper loaded: form_helper
INFO - 2021-02-26 09:46:34 --> Helper loaded: my_helper
INFO - 2021-02-26 09:46:34 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:46:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:46:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:46:34 --> Controller Class Initialized
DEBUG - 2021-02-26 09:46:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2021-02-26 09:46:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 09:46:34 --> Final output sent to browser
DEBUG - 2021-02-26 09:46:34 --> Total execution time: 0.3492
INFO - 2021-02-26 09:46:43 --> Config Class Initialized
INFO - 2021-02-26 09:46:43 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:46:43 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:46:43 --> Utf8 Class Initialized
INFO - 2021-02-26 09:46:43 --> URI Class Initialized
INFO - 2021-02-26 09:46:43 --> Router Class Initialized
INFO - 2021-02-26 09:46:43 --> Output Class Initialized
INFO - 2021-02-26 09:46:43 --> Security Class Initialized
DEBUG - 2021-02-26 09:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:46:43 --> Input Class Initialized
INFO - 2021-02-26 09:46:43 --> Language Class Initialized
INFO - 2021-02-26 09:46:43 --> Language Class Initialized
INFO - 2021-02-26 09:46:43 --> Config Class Initialized
INFO - 2021-02-26 09:46:43 --> Loader Class Initialized
INFO - 2021-02-26 09:46:43 --> Helper loaded: url_helper
INFO - 2021-02-26 09:46:43 --> Helper loaded: file_helper
INFO - 2021-02-26 09:46:43 --> Helper loaded: form_helper
INFO - 2021-02-26 09:46:43 --> Helper loaded: my_helper
INFO - 2021-02-26 09:46:43 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:46:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:46:43 --> Controller Class Initialized
INFO - 2021-02-26 09:46:43 --> Final output sent to browser
DEBUG - 2021-02-26 09:46:43 --> Total execution time: 0.3412
INFO - 2021-02-26 09:46:54 --> Config Class Initialized
INFO - 2021-02-26 09:46:54 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:46:54 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:46:54 --> Utf8 Class Initialized
INFO - 2021-02-26 09:46:54 --> URI Class Initialized
INFO - 2021-02-26 09:46:54 --> Router Class Initialized
INFO - 2021-02-26 09:46:54 --> Output Class Initialized
INFO - 2021-02-26 09:46:54 --> Security Class Initialized
DEBUG - 2021-02-26 09:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:46:54 --> Input Class Initialized
INFO - 2021-02-26 09:46:54 --> Language Class Initialized
INFO - 2021-02-26 09:46:54 --> Language Class Initialized
INFO - 2021-02-26 09:46:54 --> Config Class Initialized
INFO - 2021-02-26 09:46:54 --> Loader Class Initialized
INFO - 2021-02-26 09:46:54 --> Helper loaded: url_helper
INFO - 2021-02-26 09:46:54 --> Helper loaded: file_helper
INFO - 2021-02-26 09:46:54 --> Helper loaded: form_helper
INFO - 2021-02-26 09:46:54 --> Helper loaded: my_helper
INFO - 2021-02-26 09:46:54 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:46:54 --> Controller Class Initialized
DEBUG - 2021-02-26 09:46:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-02-26 09:46:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 09:46:54 --> Final output sent to browser
DEBUG - 2021-02-26 09:46:54 --> Total execution time: 0.4487
INFO - 2021-02-26 09:46:58 --> Config Class Initialized
INFO - 2021-02-26 09:46:58 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:46:58 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:46:58 --> Utf8 Class Initialized
INFO - 2021-02-26 09:46:58 --> URI Class Initialized
INFO - 2021-02-26 09:46:58 --> Router Class Initialized
INFO - 2021-02-26 09:46:58 --> Output Class Initialized
INFO - 2021-02-26 09:46:58 --> Security Class Initialized
DEBUG - 2021-02-26 09:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:46:58 --> Input Class Initialized
INFO - 2021-02-26 09:46:58 --> Language Class Initialized
INFO - 2021-02-26 09:46:58 --> Language Class Initialized
INFO - 2021-02-26 09:46:58 --> Config Class Initialized
INFO - 2021-02-26 09:46:58 --> Loader Class Initialized
INFO - 2021-02-26 09:46:58 --> Helper loaded: url_helper
INFO - 2021-02-26 09:46:58 --> Helper loaded: file_helper
INFO - 2021-02-26 09:46:58 --> Helper loaded: form_helper
INFO - 2021-02-26 09:46:58 --> Helper loaded: my_helper
INFO - 2021-02-26 09:46:58 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:46:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:46:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:46:58 --> Controller Class Initialized
INFO - 2021-02-26 09:46:58 --> Final output sent to browser
DEBUG - 2021-02-26 09:46:58 --> Total execution time: 0.2873
INFO - 2021-02-26 09:47:03 --> Config Class Initialized
INFO - 2021-02-26 09:47:03 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:47:03 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:47:03 --> Utf8 Class Initialized
INFO - 2021-02-26 09:47:03 --> URI Class Initialized
INFO - 2021-02-26 09:47:03 --> Router Class Initialized
INFO - 2021-02-26 09:47:03 --> Output Class Initialized
INFO - 2021-02-26 09:47:03 --> Security Class Initialized
DEBUG - 2021-02-26 09:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:47:03 --> Input Class Initialized
INFO - 2021-02-26 09:47:03 --> Language Class Initialized
INFO - 2021-02-26 09:47:03 --> Language Class Initialized
INFO - 2021-02-26 09:47:03 --> Config Class Initialized
INFO - 2021-02-26 09:47:03 --> Loader Class Initialized
INFO - 2021-02-26 09:47:03 --> Helper loaded: url_helper
INFO - 2021-02-26 09:47:03 --> Helper loaded: file_helper
INFO - 2021-02-26 09:47:03 --> Helper loaded: form_helper
INFO - 2021-02-26 09:47:03 --> Helper loaded: my_helper
INFO - 2021-02-26 09:47:03 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:47:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:47:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:47:03 --> Controller Class Initialized
INFO - 2021-02-26 09:47:03 --> Final output sent to browser
DEBUG - 2021-02-26 09:47:03 --> Total execution time: 0.3495
INFO - 2021-02-26 09:47:09 --> Config Class Initialized
INFO - 2021-02-26 09:47:09 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:47:09 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:47:09 --> Utf8 Class Initialized
INFO - 2021-02-26 09:47:09 --> URI Class Initialized
INFO - 2021-02-26 09:47:09 --> Router Class Initialized
INFO - 2021-02-26 09:47:09 --> Output Class Initialized
INFO - 2021-02-26 09:47:09 --> Security Class Initialized
DEBUG - 2021-02-26 09:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:47:09 --> Input Class Initialized
INFO - 2021-02-26 09:47:09 --> Language Class Initialized
INFO - 2021-02-26 09:47:09 --> Language Class Initialized
INFO - 2021-02-26 09:47:09 --> Config Class Initialized
INFO - 2021-02-26 09:47:09 --> Loader Class Initialized
INFO - 2021-02-26 09:47:09 --> Helper loaded: url_helper
INFO - 2021-02-26 09:47:09 --> Helper loaded: file_helper
INFO - 2021-02-26 09:47:09 --> Helper loaded: form_helper
INFO - 2021-02-26 09:47:09 --> Helper loaded: my_helper
INFO - 2021-02-26 09:47:09 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:47:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:47:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:47:09 --> Controller Class Initialized
INFO - 2021-02-26 09:47:09 --> Final output sent to browser
DEBUG - 2021-02-26 09:47:09 --> Total execution time: 0.2749
INFO - 2021-02-26 09:47:13 --> Config Class Initialized
INFO - 2021-02-26 09:47:13 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:47:13 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:47:13 --> Utf8 Class Initialized
INFO - 2021-02-26 09:47:13 --> URI Class Initialized
INFO - 2021-02-26 09:47:13 --> Router Class Initialized
INFO - 2021-02-26 09:47:13 --> Output Class Initialized
INFO - 2021-02-26 09:47:13 --> Security Class Initialized
DEBUG - 2021-02-26 09:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:47:13 --> Input Class Initialized
INFO - 2021-02-26 09:47:13 --> Language Class Initialized
INFO - 2021-02-26 09:47:13 --> Language Class Initialized
INFO - 2021-02-26 09:47:13 --> Config Class Initialized
INFO - 2021-02-26 09:47:13 --> Loader Class Initialized
INFO - 2021-02-26 09:47:13 --> Helper loaded: url_helper
INFO - 2021-02-26 09:47:13 --> Helper loaded: file_helper
INFO - 2021-02-26 09:47:13 --> Helper loaded: form_helper
INFO - 2021-02-26 09:47:13 --> Helper loaded: my_helper
INFO - 2021-02-26 09:47:13 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:47:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:47:13 --> Controller Class Initialized
INFO - 2021-02-26 09:47:13 --> Final output sent to browser
DEBUG - 2021-02-26 09:47:13 --> Total execution time: 0.3528
INFO - 2021-02-26 09:47:26 --> Config Class Initialized
INFO - 2021-02-26 09:47:26 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:47:26 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:47:26 --> Utf8 Class Initialized
INFO - 2021-02-26 09:47:26 --> URI Class Initialized
INFO - 2021-02-26 09:47:26 --> Router Class Initialized
INFO - 2021-02-26 09:47:26 --> Output Class Initialized
INFO - 2021-02-26 09:47:26 --> Security Class Initialized
DEBUG - 2021-02-26 09:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:47:26 --> Input Class Initialized
INFO - 2021-02-26 09:47:26 --> Language Class Initialized
INFO - 2021-02-26 09:47:26 --> Language Class Initialized
INFO - 2021-02-26 09:47:26 --> Config Class Initialized
INFO - 2021-02-26 09:47:26 --> Loader Class Initialized
INFO - 2021-02-26 09:47:26 --> Helper loaded: url_helper
INFO - 2021-02-26 09:47:26 --> Helper loaded: file_helper
INFO - 2021-02-26 09:47:26 --> Helper loaded: form_helper
INFO - 2021-02-26 09:47:26 --> Helper loaded: my_helper
INFO - 2021-02-26 09:47:26 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:47:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:47:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:47:26 --> Controller Class Initialized
DEBUG - 2021-02-26 09:47:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-02-26 09:47:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 09:47:26 --> Final output sent to browser
DEBUG - 2021-02-26 09:47:26 --> Total execution time: 0.3161
INFO - 2021-02-26 09:49:47 --> Config Class Initialized
INFO - 2021-02-26 09:49:47 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:49:47 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:49:47 --> Utf8 Class Initialized
INFO - 2021-02-26 09:49:47 --> URI Class Initialized
INFO - 2021-02-26 09:49:47 --> Router Class Initialized
INFO - 2021-02-26 09:49:47 --> Output Class Initialized
INFO - 2021-02-26 09:49:47 --> Security Class Initialized
DEBUG - 2021-02-26 09:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:49:47 --> Input Class Initialized
INFO - 2021-02-26 09:49:47 --> Language Class Initialized
INFO - 2021-02-26 09:49:47 --> Language Class Initialized
INFO - 2021-02-26 09:49:47 --> Config Class Initialized
INFO - 2021-02-26 09:49:47 --> Loader Class Initialized
INFO - 2021-02-26 09:49:47 --> Helper loaded: url_helper
INFO - 2021-02-26 09:49:47 --> Helper loaded: file_helper
INFO - 2021-02-26 09:49:47 --> Helper loaded: form_helper
INFO - 2021-02-26 09:49:47 --> Helper loaded: my_helper
INFO - 2021-02-26 09:49:47 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:49:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:49:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:49:47 --> Controller Class Initialized
INFO - 2021-02-26 09:49:47 --> Final output sent to browser
DEBUG - 2021-02-26 09:49:47 --> Total execution time: 0.3968
INFO - 2021-02-26 09:49:51 --> Config Class Initialized
INFO - 2021-02-26 09:49:51 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:49:51 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:49:51 --> Utf8 Class Initialized
INFO - 2021-02-26 09:49:51 --> URI Class Initialized
INFO - 2021-02-26 09:49:51 --> Router Class Initialized
INFO - 2021-02-26 09:49:51 --> Output Class Initialized
INFO - 2021-02-26 09:49:51 --> Security Class Initialized
DEBUG - 2021-02-26 09:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:49:51 --> Input Class Initialized
INFO - 2021-02-26 09:49:51 --> Language Class Initialized
INFO - 2021-02-26 09:49:51 --> Language Class Initialized
INFO - 2021-02-26 09:49:51 --> Config Class Initialized
INFO - 2021-02-26 09:49:51 --> Loader Class Initialized
INFO - 2021-02-26 09:49:51 --> Helper loaded: url_helper
INFO - 2021-02-26 09:49:51 --> Helper loaded: file_helper
INFO - 2021-02-26 09:49:51 --> Helper loaded: form_helper
INFO - 2021-02-26 09:49:51 --> Helper loaded: my_helper
INFO - 2021-02-26 09:49:51 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:49:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:49:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:49:51 --> Controller Class Initialized
DEBUG - 2021-02-26 09:49:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-02-26 09:49:51 --> Final output sent to browser
DEBUG - 2021-02-26 09:49:51 --> Total execution time: 0.2925
INFO - 2021-02-26 09:50:21 --> Config Class Initialized
INFO - 2021-02-26 09:50:21 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:50:21 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:50:21 --> Utf8 Class Initialized
INFO - 2021-02-26 09:50:21 --> URI Class Initialized
INFO - 2021-02-26 09:50:21 --> Router Class Initialized
INFO - 2021-02-26 09:50:21 --> Output Class Initialized
INFO - 2021-02-26 09:50:21 --> Security Class Initialized
DEBUG - 2021-02-26 09:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:50:21 --> Input Class Initialized
INFO - 2021-02-26 09:50:21 --> Language Class Initialized
INFO - 2021-02-26 09:50:21 --> Language Class Initialized
INFO - 2021-02-26 09:50:21 --> Config Class Initialized
INFO - 2021-02-26 09:50:21 --> Loader Class Initialized
INFO - 2021-02-26 09:50:21 --> Helper loaded: url_helper
INFO - 2021-02-26 09:50:21 --> Helper loaded: file_helper
INFO - 2021-02-26 09:50:21 --> Helper loaded: form_helper
INFO - 2021-02-26 09:50:21 --> Helper loaded: my_helper
INFO - 2021-02-26 09:50:21 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:50:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:50:21 --> Controller Class Initialized
DEBUG - 2021-02-26 09:50:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-02-26 09:50:21 --> Final output sent to browser
DEBUG - 2021-02-26 09:50:21 --> Total execution time: 0.3583
INFO - 2021-02-26 09:50:47 --> Config Class Initialized
INFO - 2021-02-26 09:50:47 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:50:47 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:50:47 --> Utf8 Class Initialized
INFO - 2021-02-26 09:50:47 --> URI Class Initialized
INFO - 2021-02-26 09:50:47 --> Router Class Initialized
INFO - 2021-02-26 09:50:47 --> Output Class Initialized
INFO - 2021-02-26 09:50:47 --> Security Class Initialized
DEBUG - 2021-02-26 09:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:50:48 --> Input Class Initialized
INFO - 2021-02-26 09:50:48 --> Language Class Initialized
INFO - 2021-02-26 09:50:48 --> Language Class Initialized
INFO - 2021-02-26 09:50:48 --> Config Class Initialized
INFO - 2021-02-26 09:50:48 --> Loader Class Initialized
INFO - 2021-02-26 09:50:48 --> Helper loaded: url_helper
INFO - 2021-02-26 09:50:48 --> Helper loaded: file_helper
INFO - 2021-02-26 09:50:48 --> Helper loaded: form_helper
INFO - 2021-02-26 09:50:48 --> Helper loaded: my_helper
INFO - 2021-02-26 09:50:48 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:50:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:50:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:50:48 --> Controller Class Initialized
DEBUG - 2021-02-26 09:50:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-02-26 09:50:48 --> Final output sent to browser
DEBUG - 2021-02-26 09:50:48 --> Total execution time: 0.4168
INFO - 2021-02-26 09:50:59 --> Config Class Initialized
INFO - 2021-02-26 09:50:59 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:50:59 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:50:59 --> Utf8 Class Initialized
INFO - 2021-02-26 09:50:59 --> URI Class Initialized
INFO - 2021-02-26 09:50:59 --> Router Class Initialized
INFO - 2021-02-26 09:50:59 --> Output Class Initialized
INFO - 2021-02-26 09:50:59 --> Security Class Initialized
DEBUG - 2021-02-26 09:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:50:59 --> Input Class Initialized
INFO - 2021-02-26 09:50:59 --> Language Class Initialized
INFO - 2021-02-26 09:50:59 --> Language Class Initialized
INFO - 2021-02-26 09:50:59 --> Config Class Initialized
INFO - 2021-02-26 09:50:59 --> Loader Class Initialized
INFO - 2021-02-26 09:50:59 --> Helper loaded: url_helper
INFO - 2021-02-26 09:50:59 --> Helper loaded: file_helper
INFO - 2021-02-26 09:50:59 --> Helper loaded: form_helper
INFO - 2021-02-26 09:50:59 --> Helper loaded: my_helper
INFO - 2021-02-26 09:50:59 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:50:59 --> Controller Class Initialized
DEBUG - 2021-02-26 09:50:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-02-26 09:50:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 09:50:59 --> Final output sent to browser
DEBUG - 2021-02-26 09:50:59 --> Total execution time: 0.4191
INFO - 2021-02-26 09:51:23 --> Config Class Initialized
INFO - 2021-02-26 09:51:23 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:51:24 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:51:24 --> Utf8 Class Initialized
INFO - 2021-02-26 09:51:24 --> URI Class Initialized
INFO - 2021-02-26 09:51:24 --> Router Class Initialized
INFO - 2021-02-26 09:51:24 --> Output Class Initialized
INFO - 2021-02-26 09:51:24 --> Security Class Initialized
DEBUG - 2021-02-26 09:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:51:24 --> Input Class Initialized
INFO - 2021-02-26 09:51:24 --> Language Class Initialized
INFO - 2021-02-26 09:51:24 --> Language Class Initialized
INFO - 2021-02-26 09:51:24 --> Config Class Initialized
INFO - 2021-02-26 09:51:24 --> Loader Class Initialized
INFO - 2021-02-26 09:51:24 --> Helper loaded: url_helper
INFO - 2021-02-26 09:51:24 --> Helper loaded: file_helper
INFO - 2021-02-26 09:51:24 --> Helper loaded: form_helper
INFO - 2021-02-26 09:51:24 --> Helper loaded: my_helper
INFO - 2021-02-26 09:51:24 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:51:24 --> Controller Class Initialized
DEBUG - 2021-02-26 09:51:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2021-02-26 09:51:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 09:51:24 --> Final output sent to browser
DEBUG - 2021-02-26 09:51:24 --> Total execution time: 0.3857
INFO - 2021-02-26 09:52:53 --> Config Class Initialized
INFO - 2021-02-26 09:52:53 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:52:53 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:52:53 --> Utf8 Class Initialized
INFO - 2021-02-26 09:52:53 --> URI Class Initialized
INFO - 2021-02-26 09:52:53 --> Router Class Initialized
INFO - 2021-02-26 09:52:53 --> Output Class Initialized
INFO - 2021-02-26 09:52:53 --> Security Class Initialized
DEBUG - 2021-02-26 09:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:52:53 --> Input Class Initialized
INFO - 2021-02-26 09:52:53 --> Language Class Initialized
INFO - 2021-02-26 09:52:53 --> Language Class Initialized
INFO - 2021-02-26 09:52:53 --> Config Class Initialized
INFO - 2021-02-26 09:52:53 --> Loader Class Initialized
INFO - 2021-02-26 09:52:53 --> Helper loaded: url_helper
INFO - 2021-02-26 09:52:53 --> Helper loaded: file_helper
INFO - 2021-02-26 09:52:53 --> Helper loaded: form_helper
INFO - 2021-02-26 09:52:53 --> Helper loaded: my_helper
INFO - 2021-02-26 09:52:53 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:52:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:52:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:52:53 --> Controller Class Initialized
DEBUG - 2021-02-26 09:52:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-02-26 09:52:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 09:52:53 --> Final output sent to browser
DEBUG - 2021-02-26 09:52:53 --> Total execution time: 0.3654
INFO - 2021-02-26 09:54:05 --> Config Class Initialized
INFO - 2021-02-26 09:54:05 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:54:05 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:54:05 --> Utf8 Class Initialized
INFO - 2021-02-26 09:54:05 --> URI Class Initialized
INFO - 2021-02-26 09:54:05 --> Router Class Initialized
INFO - 2021-02-26 09:54:05 --> Output Class Initialized
INFO - 2021-02-26 09:54:05 --> Security Class Initialized
DEBUG - 2021-02-26 09:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:54:05 --> Input Class Initialized
INFO - 2021-02-26 09:54:05 --> Language Class Initialized
INFO - 2021-02-26 09:54:05 --> Language Class Initialized
INFO - 2021-02-26 09:54:05 --> Config Class Initialized
INFO - 2021-02-26 09:54:05 --> Loader Class Initialized
INFO - 2021-02-26 09:54:05 --> Helper loaded: url_helper
INFO - 2021-02-26 09:54:05 --> Helper loaded: file_helper
INFO - 2021-02-26 09:54:05 --> Helper loaded: form_helper
INFO - 2021-02-26 09:54:05 --> Helper loaded: my_helper
INFO - 2021-02-26 09:54:05 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:54:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:54:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:54:06 --> Controller Class Initialized
DEBUG - 2021-02-26 09:54:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-02-26 09:54:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 09:54:06 --> Final output sent to browser
DEBUG - 2021-02-26 09:54:06 --> Total execution time: 0.3945
INFO - 2021-02-26 09:54:11 --> Config Class Initialized
INFO - 2021-02-26 09:54:11 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:54:11 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:54:11 --> Utf8 Class Initialized
INFO - 2021-02-26 09:54:11 --> URI Class Initialized
INFO - 2021-02-26 09:54:11 --> Router Class Initialized
INFO - 2021-02-26 09:54:11 --> Output Class Initialized
INFO - 2021-02-26 09:54:11 --> Security Class Initialized
DEBUG - 2021-02-26 09:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:54:11 --> Input Class Initialized
INFO - 2021-02-26 09:54:11 --> Language Class Initialized
INFO - 2021-02-26 09:54:11 --> Language Class Initialized
INFO - 2021-02-26 09:54:11 --> Config Class Initialized
INFO - 2021-02-26 09:54:11 --> Loader Class Initialized
INFO - 2021-02-26 09:54:11 --> Helper loaded: url_helper
INFO - 2021-02-26 09:54:11 --> Helper loaded: file_helper
INFO - 2021-02-26 09:54:11 --> Helper loaded: form_helper
INFO - 2021-02-26 09:54:11 --> Helper loaded: my_helper
INFO - 2021-02-26 09:54:11 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:54:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:54:11 --> Controller Class Initialized
DEBUG - 2021-02-26 09:54:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-02-26 09:54:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 09:54:12 --> Final output sent to browser
DEBUG - 2021-02-26 09:54:12 --> Total execution time: 0.3627
INFO - 2021-02-26 09:54:12 --> Config Class Initialized
INFO - 2021-02-26 09:54:12 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:54:12 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:54:12 --> Utf8 Class Initialized
INFO - 2021-02-26 09:54:12 --> URI Class Initialized
INFO - 2021-02-26 09:54:12 --> Router Class Initialized
INFO - 2021-02-26 09:54:12 --> Output Class Initialized
INFO - 2021-02-26 09:54:12 --> Security Class Initialized
DEBUG - 2021-02-26 09:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:54:12 --> Input Class Initialized
INFO - 2021-02-26 09:54:12 --> Language Class Initialized
INFO - 2021-02-26 09:54:12 --> Language Class Initialized
INFO - 2021-02-26 09:54:12 --> Config Class Initialized
INFO - 2021-02-26 09:54:12 --> Loader Class Initialized
INFO - 2021-02-26 09:54:12 --> Helper loaded: url_helper
INFO - 2021-02-26 09:54:12 --> Helper loaded: file_helper
INFO - 2021-02-26 09:54:12 --> Helper loaded: form_helper
INFO - 2021-02-26 09:54:13 --> Helper loaded: my_helper
INFO - 2021-02-26 09:54:13 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:54:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:54:13 --> Controller Class Initialized
DEBUG - 2021-02-26 09:54:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-02-26 09:54:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 09:54:13 --> Final output sent to browser
DEBUG - 2021-02-26 09:54:13 --> Total execution time: 0.3934
INFO - 2021-02-26 09:54:55 --> Config Class Initialized
INFO - 2021-02-26 09:54:55 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:54:55 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:54:55 --> Utf8 Class Initialized
INFO - 2021-02-26 09:54:55 --> URI Class Initialized
INFO - 2021-02-26 09:54:55 --> Router Class Initialized
INFO - 2021-02-26 09:54:55 --> Output Class Initialized
INFO - 2021-02-26 09:54:55 --> Security Class Initialized
DEBUG - 2021-02-26 09:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:54:55 --> Input Class Initialized
INFO - 2021-02-26 09:54:55 --> Language Class Initialized
INFO - 2021-02-26 09:54:55 --> Language Class Initialized
INFO - 2021-02-26 09:54:55 --> Config Class Initialized
INFO - 2021-02-26 09:54:55 --> Loader Class Initialized
INFO - 2021-02-26 09:54:55 --> Helper loaded: url_helper
INFO - 2021-02-26 09:54:55 --> Helper loaded: file_helper
INFO - 2021-02-26 09:54:55 --> Helper loaded: form_helper
INFO - 2021-02-26 09:54:55 --> Helper loaded: my_helper
INFO - 2021-02-26 09:54:55 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:54:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:54:55 --> Controller Class Initialized
DEBUG - 2021-02-26 09:54:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-02-26 09:54:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 09:54:55 --> Final output sent to browser
DEBUG - 2021-02-26 09:54:55 --> Total execution time: 0.4079
INFO - 2021-02-26 09:55:28 --> Config Class Initialized
INFO - 2021-02-26 09:55:28 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:55:28 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:55:28 --> Utf8 Class Initialized
INFO - 2021-02-26 09:55:28 --> URI Class Initialized
INFO - 2021-02-26 09:55:28 --> Router Class Initialized
INFO - 2021-02-26 09:55:28 --> Output Class Initialized
INFO - 2021-02-26 09:55:28 --> Security Class Initialized
DEBUG - 2021-02-26 09:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:55:28 --> Input Class Initialized
INFO - 2021-02-26 09:55:28 --> Language Class Initialized
INFO - 2021-02-26 09:55:28 --> Language Class Initialized
INFO - 2021-02-26 09:55:28 --> Config Class Initialized
INFO - 2021-02-26 09:55:28 --> Loader Class Initialized
INFO - 2021-02-26 09:55:28 --> Helper loaded: url_helper
INFO - 2021-02-26 09:55:28 --> Helper loaded: file_helper
INFO - 2021-02-26 09:55:28 --> Helper loaded: form_helper
INFO - 2021-02-26 09:55:28 --> Helper loaded: my_helper
INFO - 2021-02-26 09:55:28 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:55:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:55:28 --> Controller Class Initialized
DEBUG - 2021-02-26 09:55:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-02-26 09:55:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 09:55:28 --> Final output sent to browser
DEBUG - 2021-02-26 09:55:28 --> Total execution time: 0.3628
INFO - 2021-02-26 09:55:46 --> Config Class Initialized
INFO - 2021-02-26 09:55:46 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:55:46 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:55:46 --> Utf8 Class Initialized
INFO - 2021-02-26 09:55:46 --> URI Class Initialized
INFO - 2021-02-26 09:55:46 --> Router Class Initialized
INFO - 2021-02-26 09:55:46 --> Output Class Initialized
INFO - 2021-02-26 09:55:46 --> Security Class Initialized
DEBUG - 2021-02-26 09:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:55:46 --> Input Class Initialized
INFO - 2021-02-26 09:55:46 --> Language Class Initialized
INFO - 2021-02-26 09:55:46 --> Language Class Initialized
INFO - 2021-02-26 09:55:46 --> Config Class Initialized
INFO - 2021-02-26 09:55:46 --> Loader Class Initialized
INFO - 2021-02-26 09:55:46 --> Helper loaded: url_helper
INFO - 2021-02-26 09:55:46 --> Helper loaded: file_helper
INFO - 2021-02-26 09:55:46 --> Helper loaded: form_helper
INFO - 2021-02-26 09:55:46 --> Helper loaded: my_helper
INFO - 2021-02-26 09:55:46 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:55:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:55:46 --> Controller Class Initialized
INFO - 2021-02-26 09:55:46 --> Final output sent to browser
DEBUG - 2021-02-26 09:55:46 --> Total execution time: 0.3816
INFO - 2021-02-26 09:55:48 --> Config Class Initialized
INFO - 2021-02-26 09:55:48 --> Hooks Class Initialized
DEBUG - 2021-02-26 09:55:48 --> UTF-8 Support Enabled
INFO - 2021-02-26 09:55:48 --> Utf8 Class Initialized
INFO - 2021-02-26 09:55:48 --> URI Class Initialized
INFO - 2021-02-26 09:55:48 --> Router Class Initialized
INFO - 2021-02-26 09:55:48 --> Output Class Initialized
INFO - 2021-02-26 09:55:48 --> Security Class Initialized
DEBUG - 2021-02-26 09:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 09:55:48 --> Input Class Initialized
INFO - 2021-02-26 09:55:48 --> Language Class Initialized
INFO - 2021-02-26 09:55:48 --> Language Class Initialized
INFO - 2021-02-26 09:55:48 --> Config Class Initialized
INFO - 2021-02-26 09:55:48 --> Loader Class Initialized
INFO - 2021-02-26 09:55:48 --> Helper loaded: url_helper
INFO - 2021-02-26 09:55:48 --> Helper loaded: file_helper
INFO - 2021-02-26 09:55:48 --> Helper loaded: form_helper
INFO - 2021-02-26 09:55:48 --> Helper loaded: my_helper
INFO - 2021-02-26 09:55:48 --> Database Driver Class Initialized
DEBUG - 2021-02-26 09:55:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 09:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 09:55:48 --> Controller Class Initialized
DEBUG - 2021-02-26 09:55:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-02-26 09:55:49 --> Final output sent to browser
DEBUG - 2021-02-26 09:55:49 --> Total execution time: 0.3420
INFO - 2021-02-26 12:36:43 --> Config Class Initialized
INFO - 2021-02-26 12:36:43 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:36:43 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:36:43 --> Utf8 Class Initialized
INFO - 2021-02-26 12:36:43 --> URI Class Initialized
DEBUG - 2021-02-26 12:36:43 --> No URI present. Default controller set.
INFO - 2021-02-26 12:36:43 --> Router Class Initialized
INFO - 2021-02-26 12:36:43 --> Output Class Initialized
INFO - 2021-02-26 12:36:43 --> Security Class Initialized
DEBUG - 2021-02-26 12:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:36:43 --> Input Class Initialized
INFO - 2021-02-26 12:36:43 --> Language Class Initialized
INFO - 2021-02-26 12:36:43 --> Language Class Initialized
INFO - 2021-02-26 12:36:43 --> Config Class Initialized
INFO - 2021-02-26 12:36:43 --> Loader Class Initialized
INFO - 2021-02-26 12:36:43 --> Helper loaded: url_helper
INFO - 2021-02-26 12:36:43 --> Helper loaded: file_helper
INFO - 2021-02-26 12:36:43 --> Helper loaded: form_helper
INFO - 2021-02-26 12:36:43 --> Helper loaded: my_helper
INFO - 2021-02-26 12:36:43 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:36:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:36:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:36:43 --> Controller Class Initialized
INFO - 2021-02-26 12:36:43 --> Config Class Initialized
INFO - 2021-02-26 12:36:43 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:36:43 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:36:43 --> Utf8 Class Initialized
INFO - 2021-02-26 12:36:43 --> URI Class Initialized
INFO - 2021-02-26 12:36:43 --> Router Class Initialized
INFO - 2021-02-26 12:36:43 --> Output Class Initialized
INFO - 2021-02-26 12:36:43 --> Security Class Initialized
DEBUG - 2021-02-26 12:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:36:44 --> Input Class Initialized
INFO - 2021-02-26 12:36:44 --> Language Class Initialized
INFO - 2021-02-26 12:36:44 --> Language Class Initialized
INFO - 2021-02-26 12:36:44 --> Config Class Initialized
INFO - 2021-02-26 12:36:44 --> Loader Class Initialized
INFO - 2021-02-26 12:36:44 --> Helper loaded: url_helper
INFO - 2021-02-26 12:36:44 --> Helper loaded: file_helper
INFO - 2021-02-26 12:36:44 --> Helper loaded: form_helper
INFO - 2021-02-26 12:36:44 --> Helper loaded: my_helper
INFO - 2021-02-26 12:36:44 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:36:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:36:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:36:44 --> Controller Class Initialized
DEBUG - 2021-02-26 12:36:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-02-26 12:36:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 12:36:44 --> Final output sent to browser
DEBUG - 2021-02-26 12:36:44 --> Total execution time: 0.3935
INFO - 2021-02-26 12:38:20 --> Config Class Initialized
INFO - 2021-02-26 12:38:20 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:38:20 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:38:20 --> Utf8 Class Initialized
INFO - 2021-02-26 12:38:20 --> URI Class Initialized
INFO - 2021-02-26 12:38:20 --> Router Class Initialized
INFO - 2021-02-26 12:38:20 --> Output Class Initialized
INFO - 2021-02-26 12:38:21 --> Security Class Initialized
DEBUG - 2021-02-26 12:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:38:21 --> Input Class Initialized
INFO - 2021-02-26 12:38:21 --> Language Class Initialized
INFO - 2021-02-26 12:38:21 --> Language Class Initialized
INFO - 2021-02-26 12:38:21 --> Config Class Initialized
INFO - 2021-02-26 12:38:21 --> Loader Class Initialized
INFO - 2021-02-26 12:38:21 --> Helper loaded: url_helper
INFO - 2021-02-26 12:38:21 --> Helper loaded: file_helper
INFO - 2021-02-26 12:38:21 --> Helper loaded: form_helper
INFO - 2021-02-26 12:38:21 --> Helper loaded: my_helper
INFO - 2021-02-26 12:38:21 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:38:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:38:21 --> Controller Class Initialized
INFO - 2021-02-26 12:38:21 --> Helper loaded: cookie_helper
INFO - 2021-02-26 12:38:21 --> Final output sent to browser
DEBUG - 2021-02-26 12:38:21 --> Total execution time: 0.6667
INFO - 2021-02-26 12:38:21 --> Config Class Initialized
INFO - 2021-02-26 12:38:21 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:38:21 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:38:22 --> Utf8 Class Initialized
INFO - 2021-02-26 12:38:22 --> URI Class Initialized
INFO - 2021-02-26 12:38:22 --> Router Class Initialized
INFO - 2021-02-26 12:38:22 --> Output Class Initialized
INFO - 2021-02-26 12:38:22 --> Security Class Initialized
DEBUG - 2021-02-26 12:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:38:22 --> Input Class Initialized
INFO - 2021-02-26 12:38:22 --> Language Class Initialized
INFO - 2021-02-26 12:38:22 --> Language Class Initialized
INFO - 2021-02-26 12:38:22 --> Config Class Initialized
INFO - 2021-02-26 12:38:22 --> Loader Class Initialized
INFO - 2021-02-26 12:38:22 --> Helper loaded: url_helper
INFO - 2021-02-26 12:38:22 --> Helper loaded: file_helper
INFO - 2021-02-26 12:38:22 --> Helper loaded: form_helper
INFO - 2021-02-26 12:38:22 --> Helper loaded: my_helper
INFO - 2021-02-26 12:38:22 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:38:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:38:22 --> Controller Class Initialized
DEBUG - 2021-02-26 12:38:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-02-26 12:38:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 12:38:22 --> Final output sent to browser
DEBUG - 2021-02-26 12:38:22 --> Total execution time: 0.8709
INFO - 2021-02-26 12:38:25 --> Config Class Initialized
INFO - 2021-02-26 12:38:25 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:38:25 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:38:25 --> Utf8 Class Initialized
INFO - 2021-02-26 12:38:25 --> URI Class Initialized
INFO - 2021-02-26 12:38:25 --> Router Class Initialized
INFO - 2021-02-26 12:38:25 --> Output Class Initialized
INFO - 2021-02-26 12:38:25 --> Security Class Initialized
DEBUG - 2021-02-26 12:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:38:25 --> Input Class Initialized
INFO - 2021-02-26 12:38:25 --> Language Class Initialized
INFO - 2021-02-26 12:38:25 --> Language Class Initialized
INFO - 2021-02-26 12:38:25 --> Config Class Initialized
INFO - 2021-02-26 12:38:25 --> Loader Class Initialized
INFO - 2021-02-26 12:38:25 --> Helper loaded: url_helper
INFO - 2021-02-26 12:38:25 --> Helper loaded: file_helper
INFO - 2021-02-26 12:38:25 --> Helper loaded: form_helper
INFO - 2021-02-26 12:38:25 --> Helper loaded: my_helper
INFO - 2021-02-26 12:38:25 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:38:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:38:26 --> Controller Class Initialized
DEBUG - 2021-02-26 12:38:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-02-26 12:38:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 12:38:26 --> Final output sent to browser
DEBUG - 2021-02-26 12:38:26 --> Total execution time: 0.8763
INFO - 2021-02-26 12:38:27 --> Config Class Initialized
INFO - 2021-02-26 12:38:27 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:38:27 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:38:27 --> Utf8 Class Initialized
INFO - 2021-02-26 12:38:27 --> URI Class Initialized
INFO - 2021-02-26 12:38:27 --> Router Class Initialized
INFO - 2021-02-26 12:38:27 --> Output Class Initialized
INFO - 2021-02-26 12:38:27 --> Security Class Initialized
DEBUG - 2021-02-26 12:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:38:27 --> Input Class Initialized
INFO - 2021-02-26 12:38:27 --> Language Class Initialized
INFO - 2021-02-26 12:38:27 --> Language Class Initialized
INFO - 2021-02-26 12:38:27 --> Config Class Initialized
INFO - 2021-02-26 12:38:27 --> Loader Class Initialized
INFO - 2021-02-26 12:38:27 --> Helper loaded: url_helper
INFO - 2021-02-26 12:38:27 --> Helper loaded: file_helper
INFO - 2021-02-26 12:38:28 --> Helper loaded: form_helper
INFO - 2021-02-26 12:38:28 --> Helper loaded: my_helper
INFO - 2021-02-26 12:38:28 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:38:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:38:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:38:28 --> Controller Class Initialized
DEBUG - 2021-02-26 12:38:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-02-26 12:38:28 --> Final output sent to browser
DEBUG - 2021-02-26 12:38:28 --> Total execution time: 0.8759
INFO - 2021-02-26 12:40:32 --> Config Class Initialized
INFO - 2021-02-26 12:40:32 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:40:32 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:40:32 --> Utf8 Class Initialized
INFO - 2021-02-26 12:40:32 --> URI Class Initialized
INFO - 2021-02-26 12:40:32 --> Router Class Initialized
INFO - 2021-02-26 12:40:32 --> Output Class Initialized
INFO - 2021-02-26 12:40:32 --> Security Class Initialized
DEBUG - 2021-02-26 12:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:40:32 --> Input Class Initialized
INFO - 2021-02-26 12:40:32 --> Language Class Initialized
INFO - 2021-02-26 12:40:32 --> Language Class Initialized
INFO - 2021-02-26 12:40:32 --> Config Class Initialized
INFO - 2021-02-26 12:40:32 --> Loader Class Initialized
INFO - 2021-02-26 12:40:32 --> Helper loaded: url_helper
INFO - 2021-02-26 12:40:32 --> Helper loaded: file_helper
INFO - 2021-02-26 12:40:32 --> Helper loaded: form_helper
INFO - 2021-02-26 12:40:32 --> Helper loaded: my_helper
INFO - 2021-02-26 12:40:32 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:40:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:40:33 --> Controller Class Initialized
DEBUG - 2021-02-26 12:40:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-02-26 12:40:33 --> Final output sent to browser
DEBUG - 2021-02-26 12:40:33 --> Total execution time: 1.1448
INFO - 2021-02-26 12:40:52 --> Config Class Initialized
INFO - 2021-02-26 12:40:52 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:40:52 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:40:52 --> Utf8 Class Initialized
INFO - 2021-02-26 12:40:52 --> URI Class Initialized
INFO - 2021-02-26 12:40:52 --> Router Class Initialized
INFO - 2021-02-26 12:40:52 --> Output Class Initialized
INFO - 2021-02-26 12:40:52 --> Security Class Initialized
DEBUG - 2021-02-26 12:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:40:52 --> Input Class Initialized
INFO - 2021-02-26 12:40:52 --> Language Class Initialized
INFO - 2021-02-26 12:40:53 --> Language Class Initialized
INFO - 2021-02-26 12:40:53 --> Config Class Initialized
INFO - 2021-02-26 12:40:53 --> Loader Class Initialized
INFO - 2021-02-26 12:40:53 --> Helper loaded: url_helper
INFO - 2021-02-26 12:40:53 --> Helper loaded: file_helper
INFO - 2021-02-26 12:40:53 --> Helper loaded: form_helper
INFO - 2021-02-26 12:40:53 --> Helper loaded: my_helper
INFO - 2021-02-26 12:40:53 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:40:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:40:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:40:53 --> Controller Class Initialized
DEBUG - 2021-02-26 12:40:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-02-26 12:40:53 --> Final output sent to browser
DEBUG - 2021-02-26 12:40:53 --> Total execution time: 1.1705
INFO - 2021-02-26 12:41:26 --> Config Class Initialized
INFO - 2021-02-26 12:41:26 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:41:26 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:41:26 --> Utf8 Class Initialized
INFO - 2021-02-26 12:41:26 --> URI Class Initialized
INFO - 2021-02-26 12:41:26 --> Router Class Initialized
INFO - 2021-02-26 12:41:26 --> Output Class Initialized
INFO - 2021-02-26 12:41:26 --> Security Class Initialized
DEBUG - 2021-02-26 12:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:41:26 --> Input Class Initialized
INFO - 2021-02-26 12:41:26 --> Language Class Initialized
INFO - 2021-02-26 12:41:26 --> Language Class Initialized
INFO - 2021-02-26 12:41:26 --> Config Class Initialized
INFO - 2021-02-26 12:41:26 --> Loader Class Initialized
INFO - 2021-02-26 12:41:26 --> Helper loaded: url_helper
INFO - 2021-02-26 12:41:26 --> Helper loaded: file_helper
INFO - 2021-02-26 12:41:27 --> Helper loaded: form_helper
INFO - 2021-02-26 12:41:27 --> Helper loaded: my_helper
INFO - 2021-02-26 12:41:27 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:41:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:41:27 --> Controller Class Initialized
DEBUG - 2021-02-26 12:41:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-02-26 12:41:27 --> Final output sent to browser
DEBUG - 2021-02-26 12:41:27 --> Total execution time: 1.1542
INFO - 2021-02-26 12:41:43 --> Config Class Initialized
INFO - 2021-02-26 12:41:43 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:41:43 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:41:43 --> Utf8 Class Initialized
INFO - 2021-02-26 12:41:43 --> URI Class Initialized
INFO - 2021-02-26 12:41:44 --> Router Class Initialized
INFO - 2021-02-26 12:41:44 --> Output Class Initialized
INFO - 2021-02-26 12:41:44 --> Security Class Initialized
DEBUG - 2021-02-26 12:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:41:44 --> Input Class Initialized
INFO - 2021-02-26 12:41:44 --> Language Class Initialized
INFO - 2021-02-26 12:41:44 --> Language Class Initialized
INFO - 2021-02-26 12:41:44 --> Config Class Initialized
INFO - 2021-02-26 12:41:44 --> Loader Class Initialized
INFO - 2021-02-26 12:41:44 --> Helper loaded: url_helper
INFO - 2021-02-26 12:41:44 --> Helper loaded: file_helper
INFO - 2021-02-26 12:41:44 --> Helper loaded: form_helper
INFO - 2021-02-26 12:41:44 --> Helper loaded: my_helper
INFO - 2021-02-26 12:41:44 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:41:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:41:44 --> Controller Class Initialized
DEBUG - 2021-02-26 12:41:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-02-26 12:41:45 --> Final output sent to browser
DEBUG - 2021-02-26 12:41:45 --> Total execution time: 1.1656
INFO - 2021-02-26 12:41:58 --> Config Class Initialized
INFO - 2021-02-26 12:41:58 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:41:58 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:41:58 --> Utf8 Class Initialized
INFO - 2021-02-26 12:41:58 --> URI Class Initialized
INFO - 2021-02-26 12:41:58 --> Router Class Initialized
INFO - 2021-02-26 12:41:58 --> Output Class Initialized
INFO - 2021-02-26 12:41:58 --> Security Class Initialized
DEBUG - 2021-02-26 12:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:41:58 --> Input Class Initialized
INFO - 2021-02-26 12:41:58 --> Language Class Initialized
INFO - 2021-02-26 12:41:58 --> Language Class Initialized
INFO - 2021-02-26 12:41:58 --> Config Class Initialized
INFO - 2021-02-26 12:41:58 --> Loader Class Initialized
INFO - 2021-02-26 12:41:59 --> Helper loaded: url_helper
INFO - 2021-02-26 12:41:59 --> Helper loaded: file_helper
INFO - 2021-02-26 12:41:59 --> Helper loaded: form_helper
INFO - 2021-02-26 12:41:59 --> Helper loaded: my_helper
INFO - 2021-02-26 12:41:59 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:41:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:41:59 --> Controller Class Initialized
INFO - 2021-02-26 12:41:59 --> Helper loaded: cookie_helper
INFO - 2021-02-26 12:41:59 --> Config Class Initialized
INFO - 2021-02-26 12:41:59 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:41:59 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:41:59 --> Utf8 Class Initialized
INFO - 2021-02-26 12:41:59 --> URI Class Initialized
INFO - 2021-02-26 12:41:59 --> Router Class Initialized
INFO - 2021-02-26 12:41:59 --> Output Class Initialized
INFO - 2021-02-26 12:41:59 --> Security Class Initialized
DEBUG - 2021-02-26 12:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:41:59 --> Input Class Initialized
INFO - 2021-02-26 12:41:59 --> Language Class Initialized
INFO - 2021-02-26 12:42:00 --> Language Class Initialized
INFO - 2021-02-26 12:42:00 --> Config Class Initialized
INFO - 2021-02-26 12:42:00 --> Loader Class Initialized
INFO - 2021-02-26 12:42:00 --> Helper loaded: url_helper
INFO - 2021-02-26 12:42:00 --> Helper loaded: file_helper
INFO - 2021-02-26 12:42:00 --> Helper loaded: form_helper
INFO - 2021-02-26 12:42:00 --> Helper loaded: my_helper
INFO - 2021-02-26 12:42:00 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:42:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:42:00 --> Controller Class Initialized
DEBUG - 2021-02-26 12:42:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-02-26 12:42:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 12:42:00 --> Final output sent to browser
DEBUG - 2021-02-26 12:42:00 --> Total execution time: 1.2132
INFO - 2021-02-26 12:42:04 --> Config Class Initialized
INFO - 2021-02-26 12:42:04 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:42:04 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:42:04 --> Utf8 Class Initialized
INFO - 2021-02-26 12:42:04 --> URI Class Initialized
INFO - 2021-02-26 12:42:04 --> Router Class Initialized
INFO - 2021-02-26 12:42:04 --> Output Class Initialized
INFO - 2021-02-26 12:42:04 --> Security Class Initialized
DEBUG - 2021-02-26 12:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:42:04 --> Input Class Initialized
INFO - 2021-02-26 12:42:05 --> Language Class Initialized
INFO - 2021-02-26 12:42:05 --> Language Class Initialized
INFO - 2021-02-26 12:42:05 --> Config Class Initialized
INFO - 2021-02-26 12:42:05 --> Loader Class Initialized
INFO - 2021-02-26 12:42:05 --> Helper loaded: url_helper
INFO - 2021-02-26 12:42:05 --> Helper loaded: file_helper
INFO - 2021-02-26 12:42:05 --> Helper loaded: form_helper
INFO - 2021-02-26 12:42:05 --> Helper loaded: my_helper
INFO - 2021-02-26 12:42:05 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:42:05 --> Controller Class Initialized
INFO - 2021-02-26 12:42:05 --> Helper loaded: cookie_helper
INFO - 2021-02-26 12:42:05 --> Final output sent to browser
DEBUG - 2021-02-26 12:42:05 --> Total execution time: 1.0772
INFO - 2021-02-26 12:42:06 --> Config Class Initialized
INFO - 2021-02-26 12:42:06 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:42:06 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:42:06 --> Utf8 Class Initialized
INFO - 2021-02-26 12:42:06 --> URI Class Initialized
INFO - 2021-02-26 12:42:06 --> Router Class Initialized
INFO - 2021-02-26 12:42:06 --> Output Class Initialized
INFO - 2021-02-26 12:42:06 --> Security Class Initialized
DEBUG - 2021-02-26 12:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:42:06 --> Input Class Initialized
INFO - 2021-02-26 12:42:06 --> Language Class Initialized
INFO - 2021-02-26 12:42:06 --> Language Class Initialized
INFO - 2021-02-26 12:42:06 --> Config Class Initialized
INFO - 2021-02-26 12:42:06 --> Loader Class Initialized
INFO - 2021-02-26 12:42:06 --> Helper loaded: url_helper
INFO - 2021-02-26 12:42:06 --> Helper loaded: file_helper
INFO - 2021-02-26 12:42:06 --> Helper loaded: form_helper
INFO - 2021-02-26 12:42:06 --> Helper loaded: my_helper
INFO - 2021-02-26 12:42:06 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:42:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:42:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:42:06 --> Controller Class Initialized
DEBUG - 2021-02-26 12:42:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-02-26 12:42:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 12:42:07 --> Final output sent to browser
DEBUG - 2021-02-26 12:42:07 --> Total execution time: 0.9584
INFO - 2021-02-26 12:42:08 --> Config Class Initialized
INFO - 2021-02-26 12:42:08 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:42:08 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:42:08 --> Utf8 Class Initialized
INFO - 2021-02-26 12:42:08 --> URI Class Initialized
INFO - 2021-02-26 12:42:08 --> Router Class Initialized
INFO - 2021-02-26 12:42:08 --> Output Class Initialized
INFO - 2021-02-26 12:42:08 --> Security Class Initialized
DEBUG - 2021-02-26 12:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:42:08 --> Input Class Initialized
INFO - 2021-02-26 12:42:09 --> Language Class Initialized
INFO - 2021-02-26 12:42:09 --> Language Class Initialized
INFO - 2021-02-26 12:42:09 --> Config Class Initialized
INFO - 2021-02-26 12:42:09 --> Loader Class Initialized
INFO - 2021-02-26 12:42:09 --> Helper loaded: url_helper
INFO - 2021-02-26 12:42:09 --> Helper loaded: file_helper
INFO - 2021-02-26 12:42:09 --> Helper loaded: form_helper
INFO - 2021-02-26 12:42:09 --> Helper loaded: my_helper
INFO - 2021-02-26 12:42:09 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:42:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:42:09 --> Controller Class Initialized
DEBUG - 2021-02-26 12:42:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-02-26 12:42:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 12:42:09 --> Final output sent to browser
DEBUG - 2021-02-26 12:42:09 --> Total execution time: 1.1448
INFO - 2021-02-26 12:42:10 --> Config Class Initialized
INFO - 2021-02-26 12:42:10 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:42:10 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:42:10 --> Utf8 Class Initialized
INFO - 2021-02-26 12:42:10 --> URI Class Initialized
INFO - 2021-02-26 12:42:11 --> Router Class Initialized
INFO - 2021-02-26 12:42:11 --> Output Class Initialized
INFO - 2021-02-26 12:42:11 --> Security Class Initialized
DEBUG - 2021-02-26 12:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:42:11 --> Input Class Initialized
INFO - 2021-02-26 12:42:11 --> Language Class Initialized
INFO - 2021-02-26 12:42:11 --> Language Class Initialized
INFO - 2021-02-26 12:42:11 --> Config Class Initialized
INFO - 2021-02-26 12:42:11 --> Loader Class Initialized
INFO - 2021-02-26 12:42:11 --> Helper loaded: url_helper
INFO - 2021-02-26 12:42:11 --> Helper loaded: file_helper
INFO - 2021-02-26 12:42:11 --> Helper loaded: form_helper
INFO - 2021-02-26 12:42:11 --> Helper loaded: my_helper
INFO - 2021-02-26 12:42:11 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:42:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:42:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:42:11 --> Controller Class Initialized
DEBUG - 2021-02-26 12:42:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-02-26 12:42:11 --> Final output sent to browser
DEBUG - 2021-02-26 12:42:11 --> Total execution time: 0.7801
INFO - 2021-02-26 12:42:27 --> Config Class Initialized
INFO - 2021-02-26 12:42:27 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:42:27 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:42:27 --> Utf8 Class Initialized
INFO - 2021-02-26 12:42:27 --> URI Class Initialized
INFO - 2021-02-26 12:42:27 --> Router Class Initialized
INFO - 2021-02-26 12:42:27 --> Output Class Initialized
INFO - 2021-02-26 12:42:27 --> Security Class Initialized
DEBUG - 2021-02-26 12:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:42:27 --> Input Class Initialized
INFO - 2021-02-26 12:42:27 --> Language Class Initialized
INFO - 2021-02-26 12:42:27 --> Language Class Initialized
INFO - 2021-02-26 12:42:27 --> Config Class Initialized
INFO - 2021-02-26 12:42:27 --> Loader Class Initialized
INFO - 2021-02-26 12:42:27 --> Helper loaded: url_helper
INFO - 2021-02-26 12:42:27 --> Helper loaded: file_helper
INFO - 2021-02-26 12:42:27 --> Helper loaded: form_helper
INFO - 2021-02-26 12:42:27 --> Helper loaded: my_helper
INFO - 2021-02-26 12:42:27 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:42:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:42:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:42:28 --> Controller Class Initialized
DEBUG - 2021-02-26 12:42:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-02-26 12:42:28 --> Final output sent to browser
DEBUG - 2021-02-26 12:42:28 --> Total execution time: 1.0180
INFO - 2021-02-26 12:42:44 --> Config Class Initialized
INFO - 2021-02-26 12:42:44 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:42:44 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:42:44 --> Utf8 Class Initialized
INFO - 2021-02-26 12:42:44 --> URI Class Initialized
INFO - 2021-02-26 12:42:44 --> Router Class Initialized
INFO - 2021-02-26 12:42:44 --> Output Class Initialized
INFO - 2021-02-26 12:42:44 --> Security Class Initialized
DEBUG - 2021-02-26 12:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:42:44 --> Input Class Initialized
INFO - 2021-02-26 12:42:44 --> Language Class Initialized
INFO - 2021-02-26 12:42:44 --> Language Class Initialized
INFO - 2021-02-26 12:42:44 --> Config Class Initialized
INFO - 2021-02-26 12:42:44 --> Loader Class Initialized
INFO - 2021-02-26 12:42:44 --> Helper loaded: url_helper
INFO - 2021-02-26 12:42:44 --> Helper loaded: file_helper
INFO - 2021-02-26 12:42:45 --> Helper loaded: form_helper
INFO - 2021-02-26 12:42:45 --> Helper loaded: my_helper
INFO - 2021-02-26 12:42:45 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:42:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:42:45 --> Controller Class Initialized
INFO - 2021-02-26 12:42:45 --> Helper loaded: cookie_helper
INFO - 2021-02-26 12:42:45 --> Config Class Initialized
INFO - 2021-02-26 12:42:45 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:42:45 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:42:45 --> Utf8 Class Initialized
INFO - 2021-02-26 12:42:45 --> URI Class Initialized
INFO - 2021-02-26 12:42:45 --> Router Class Initialized
INFO - 2021-02-26 12:42:45 --> Output Class Initialized
INFO - 2021-02-26 12:42:45 --> Security Class Initialized
DEBUG - 2021-02-26 12:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:42:45 --> Input Class Initialized
INFO - 2021-02-26 12:42:45 --> Language Class Initialized
INFO - 2021-02-26 12:42:45 --> Language Class Initialized
INFO - 2021-02-26 12:42:45 --> Config Class Initialized
INFO - 2021-02-26 12:42:46 --> Loader Class Initialized
INFO - 2021-02-26 12:42:46 --> Helper loaded: url_helper
INFO - 2021-02-26 12:42:46 --> Helper loaded: file_helper
INFO - 2021-02-26 12:42:46 --> Helper loaded: form_helper
INFO - 2021-02-26 12:42:46 --> Helper loaded: my_helper
INFO - 2021-02-26 12:42:46 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:42:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:42:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:42:46 --> Controller Class Initialized
DEBUG - 2021-02-26 12:42:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-02-26 12:42:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 12:42:46 --> Final output sent to browser
DEBUG - 2021-02-26 12:42:46 --> Total execution time: 1.1523
INFO - 2021-02-26 12:43:14 --> Config Class Initialized
INFO - 2021-02-26 12:43:14 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:43:14 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:43:14 --> Utf8 Class Initialized
INFO - 2021-02-26 12:43:14 --> URI Class Initialized
INFO - 2021-02-26 12:43:14 --> Router Class Initialized
INFO - 2021-02-26 12:43:14 --> Output Class Initialized
INFO - 2021-02-26 12:43:14 --> Security Class Initialized
DEBUG - 2021-02-26 12:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:43:14 --> Input Class Initialized
INFO - 2021-02-26 12:43:14 --> Language Class Initialized
INFO - 2021-02-26 12:43:14 --> Language Class Initialized
INFO - 2021-02-26 12:43:14 --> Config Class Initialized
INFO - 2021-02-26 12:43:14 --> Loader Class Initialized
INFO - 2021-02-26 12:43:14 --> Helper loaded: url_helper
INFO - 2021-02-26 12:43:14 --> Helper loaded: file_helper
INFO - 2021-02-26 12:43:14 --> Helper loaded: form_helper
INFO - 2021-02-26 12:43:14 --> Helper loaded: my_helper
INFO - 2021-02-26 12:43:14 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:43:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:43:15 --> Controller Class Initialized
INFO - 2021-02-26 12:43:15 --> Final output sent to browser
DEBUG - 2021-02-26 12:43:15 --> Total execution time: 1.0097
INFO - 2021-02-26 12:43:18 --> Config Class Initialized
INFO - 2021-02-26 12:43:18 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:43:18 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:43:18 --> Utf8 Class Initialized
INFO - 2021-02-26 12:43:18 --> URI Class Initialized
INFO - 2021-02-26 12:43:18 --> Router Class Initialized
INFO - 2021-02-26 12:43:18 --> Output Class Initialized
INFO - 2021-02-26 12:43:19 --> Security Class Initialized
DEBUG - 2021-02-26 12:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:43:19 --> Input Class Initialized
INFO - 2021-02-26 12:43:19 --> Language Class Initialized
INFO - 2021-02-26 12:43:19 --> Language Class Initialized
INFO - 2021-02-26 12:43:19 --> Config Class Initialized
INFO - 2021-02-26 12:43:19 --> Loader Class Initialized
INFO - 2021-02-26 12:43:19 --> Helper loaded: url_helper
INFO - 2021-02-26 12:43:19 --> Helper loaded: file_helper
INFO - 2021-02-26 12:43:19 --> Helper loaded: form_helper
INFO - 2021-02-26 12:43:19 --> Helper loaded: my_helper
INFO - 2021-02-26 12:43:19 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:43:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:43:19 --> Controller Class Initialized
INFO - 2021-02-26 12:43:19 --> Helper loaded: cookie_helper
INFO - 2021-02-26 12:43:19 --> Final output sent to browser
DEBUG - 2021-02-26 12:43:19 --> Total execution time: 1.0284
INFO - 2021-02-26 12:43:20 --> Config Class Initialized
INFO - 2021-02-26 12:43:20 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:43:20 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:43:20 --> Utf8 Class Initialized
INFO - 2021-02-26 12:43:20 --> URI Class Initialized
INFO - 2021-02-26 12:43:20 --> Router Class Initialized
INFO - 2021-02-26 12:43:20 --> Output Class Initialized
INFO - 2021-02-26 12:43:20 --> Security Class Initialized
DEBUG - 2021-02-26 12:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:43:20 --> Input Class Initialized
INFO - 2021-02-26 12:43:20 --> Language Class Initialized
INFO - 2021-02-26 12:43:20 --> Language Class Initialized
INFO - 2021-02-26 12:43:20 --> Config Class Initialized
INFO - 2021-02-26 12:43:20 --> Loader Class Initialized
INFO - 2021-02-26 12:43:20 --> Helper loaded: url_helper
INFO - 2021-02-26 12:43:20 --> Helper loaded: file_helper
INFO - 2021-02-26 12:43:20 --> Helper loaded: form_helper
INFO - 2021-02-26 12:43:20 --> Helper loaded: my_helper
INFO - 2021-02-26 12:43:20 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:43:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:43:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:43:21 --> Controller Class Initialized
DEBUG - 2021-02-26 12:43:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-02-26 12:43:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 12:43:21 --> Final output sent to browser
DEBUG - 2021-02-26 12:43:21 --> Total execution time: 0.9443
INFO - 2021-02-26 12:44:08 --> Config Class Initialized
INFO - 2021-02-26 12:44:08 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:44:08 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:44:08 --> Utf8 Class Initialized
INFO - 2021-02-26 12:44:08 --> URI Class Initialized
INFO - 2021-02-26 12:44:08 --> Router Class Initialized
INFO - 2021-02-26 12:44:08 --> Output Class Initialized
INFO - 2021-02-26 12:44:08 --> Security Class Initialized
DEBUG - 2021-02-26 12:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:44:08 --> Input Class Initialized
INFO - 2021-02-26 12:44:08 --> Language Class Initialized
INFO - 2021-02-26 12:44:08 --> Language Class Initialized
INFO - 2021-02-26 12:44:08 --> Config Class Initialized
INFO - 2021-02-26 12:44:08 --> Loader Class Initialized
INFO - 2021-02-26 12:44:08 --> Helper loaded: url_helper
INFO - 2021-02-26 12:44:08 --> Helper loaded: file_helper
INFO - 2021-02-26 12:44:08 --> Helper loaded: form_helper
INFO - 2021-02-26 12:44:08 --> Helper loaded: my_helper
INFO - 2021-02-26 12:44:08 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:44:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:44:08 --> Controller Class Initialized
DEBUG - 2021-02-26 12:44:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-02-26 12:44:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 12:44:09 --> Final output sent to browser
DEBUG - 2021-02-26 12:44:09 --> Total execution time: 0.9482
INFO - 2021-02-26 12:44:11 --> Config Class Initialized
INFO - 2021-02-26 12:44:11 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:44:11 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:44:11 --> Utf8 Class Initialized
INFO - 2021-02-26 12:44:11 --> URI Class Initialized
INFO - 2021-02-26 12:44:11 --> Router Class Initialized
INFO - 2021-02-26 12:44:12 --> Output Class Initialized
INFO - 2021-02-26 12:44:12 --> Security Class Initialized
DEBUG - 2021-02-26 12:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:44:12 --> Input Class Initialized
INFO - 2021-02-26 12:44:12 --> Language Class Initialized
INFO - 2021-02-26 12:44:12 --> Language Class Initialized
INFO - 2021-02-26 12:44:12 --> Config Class Initialized
INFO - 2021-02-26 12:44:12 --> Loader Class Initialized
INFO - 2021-02-26 12:44:12 --> Helper loaded: url_helper
INFO - 2021-02-26 12:44:12 --> Helper loaded: file_helper
INFO - 2021-02-26 12:44:12 --> Helper loaded: form_helper
INFO - 2021-02-26 12:44:12 --> Helper loaded: my_helper
INFO - 2021-02-26 12:44:12 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:44:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:44:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:44:12 --> Controller Class Initialized
DEBUG - 2021-02-26 12:44:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-02-26 12:44:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 12:44:12 --> Final output sent to browser
DEBUG - 2021-02-26 12:44:12 --> Total execution time: 0.7759
INFO - 2021-02-26 12:44:14 --> Config Class Initialized
INFO - 2021-02-26 12:44:15 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:44:15 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:44:15 --> Utf8 Class Initialized
INFO - 2021-02-26 12:44:15 --> URI Class Initialized
INFO - 2021-02-26 12:44:15 --> Router Class Initialized
INFO - 2021-02-26 12:44:15 --> Output Class Initialized
INFO - 2021-02-26 12:44:15 --> Security Class Initialized
DEBUG - 2021-02-26 12:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:44:15 --> Input Class Initialized
INFO - 2021-02-26 12:44:15 --> Language Class Initialized
INFO - 2021-02-26 12:44:15 --> Language Class Initialized
INFO - 2021-02-26 12:44:15 --> Config Class Initialized
INFO - 2021-02-26 12:44:15 --> Loader Class Initialized
INFO - 2021-02-26 12:44:15 --> Helper loaded: url_helper
INFO - 2021-02-26 12:44:15 --> Helper loaded: file_helper
INFO - 2021-02-26 12:44:15 --> Helper loaded: form_helper
INFO - 2021-02-26 12:44:15 --> Helper loaded: my_helper
INFO - 2021-02-26 12:44:15 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:44:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:44:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:44:15 --> Controller Class Initialized
DEBUG - 2021-02-26 12:44:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tkro_xii.php
INFO - 2021-02-26 12:44:15 --> Final output sent to browser
DEBUG - 2021-02-26 12:44:16 --> Total execution time: 1.0017
INFO - 2021-02-26 12:44:28 --> Config Class Initialized
INFO - 2021-02-26 12:44:28 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:44:28 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:44:28 --> Utf8 Class Initialized
INFO - 2021-02-26 12:44:28 --> URI Class Initialized
INFO - 2021-02-26 12:44:28 --> Router Class Initialized
INFO - 2021-02-26 12:44:28 --> Output Class Initialized
INFO - 2021-02-26 12:44:28 --> Security Class Initialized
DEBUG - 2021-02-26 12:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:44:28 --> Input Class Initialized
INFO - 2021-02-26 12:44:28 --> Language Class Initialized
INFO - 2021-02-26 12:44:28 --> Language Class Initialized
INFO - 2021-02-26 12:44:28 --> Config Class Initialized
INFO - 2021-02-26 12:44:28 --> Loader Class Initialized
INFO - 2021-02-26 12:44:28 --> Helper loaded: url_helper
INFO - 2021-02-26 12:44:29 --> Helper loaded: file_helper
INFO - 2021-02-26 12:44:29 --> Helper loaded: form_helper
INFO - 2021-02-26 12:44:29 --> Helper loaded: my_helper
INFO - 2021-02-26 12:44:29 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:44:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:44:29 --> Controller Class Initialized
DEBUG - 2021-02-26 12:44:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-02-26 12:44:29 --> Final output sent to browser
DEBUG - 2021-02-26 12:44:29 --> Total execution time: 1.0231
INFO - 2021-02-26 12:46:15 --> Config Class Initialized
INFO - 2021-02-26 12:46:15 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:46:15 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:46:15 --> Utf8 Class Initialized
INFO - 2021-02-26 12:46:15 --> URI Class Initialized
INFO - 2021-02-26 12:46:15 --> Router Class Initialized
INFO - 2021-02-26 12:46:15 --> Output Class Initialized
INFO - 2021-02-26 12:46:15 --> Security Class Initialized
DEBUG - 2021-02-26 12:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:46:15 --> Input Class Initialized
INFO - 2021-02-26 12:46:16 --> Language Class Initialized
INFO - 2021-02-26 12:46:16 --> Language Class Initialized
INFO - 2021-02-26 12:46:16 --> Config Class Initialized
INFO - 2021-02-26 12:46:16 --> Loader Class Initialized
INFO - 2021-02-26 12:46:16 --> Helper loaded: url_helper
INFO - 2021-02-26 12:46:16 --> Helper loaded: file_helper
INFO - 2021-02-26 12:46:16 --> Helper loaded: form_helper
INFO - 2021-02-26 12:46:16 --> Helper loaded: my_helper
INFO - 2021-02-26 12:46:16 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:46:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:46:16 --> Controller Class Initialized
DEBUG - 2021-02-26 12:46:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-02-26 12:46:16 --> Final output sent to browser
DEBUG - 2021-02-26 12:46:16 --> Total execution time: 1.1196
INFO - 2021-02-26 12:46:45 --> Config Class Initialized
INFO - 2021-02-26 12:46:45 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:46:45 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:46:45 --> Utf8 Class Initialized
INFO - 2021-02-26 12:46:45 --> URI Class Initialized
INFO - 2021-02-26 12:46:45 --> Router Class Initialized
INFO - 2021-02-26 12:46:45 --> Output Class Initialized
INFO - 2021-02-26 12:46:45 --> Security Class Initialized
DEBUG - 2021-02-26 12:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:46:45 --> Input Class Initialized
INFO - 2021-02-26 12:46:45 --> Language Class Initialized
INFO - 2021-02-26 12:46:46 --> Language Class Initialized
INFO - 2021-02-26 12:46:46 --> Config Class Initialized
INFO - 2021-02-26 12:46:46 --> Loader Class Initialized
INFO - 2021-02-26 12:46:46 --> Helper loaded: url_helper
INFO - 2021-02-26 12:46:46 --> Helper loaded: file_helper
INFO - 2021-02-26 12:46:46 --> Helper loaded: form_helper
INFO - 2021-02-26 12:46:46 --> Helper loaded: my_helper
INFO - 2021-02-26 12:46:46 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:46:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:46:46 --> Controller Class Initialized
DEBUG - 2021-02-26 12:46:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-02-26 12:46:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 12:46:46 --> Final output sent to browser
DEBUG - 2021-02-26 12:46:46 --> Total execution time: 1.2450
INFO - 2021-02-26 12:46:48 --> Config Class Initialized
INFO - 2021-02-26 12:46:48 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:46:48 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:46:49 --> Utf8 Class Initialized
INFO - 2021-02-26 12:46:49 --> URI Class Initialized
INFO - 2021-02-26 12:46:49 --> Router Class Initialized
INFO - 2021-02-26 12:46:49 --> Output Class Initialized
INFO - 2021-02-26 12:46:49 --> Security Class Initialized
DEBUG - 2021-02-26 12:46:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:46:49 --> Input Class Initialized
INFO - 2021-02-26 12:46:49 --> Language Class Initialized
INFO - 2021-02-26 12:46:49 --> Language Class Initialized
INFO - 2021-02-26 12:46:49 --> Config Class Initialized
INFO - 2021-02-26 12:46:49 --> Loader Class Initialized
INFO - 2021-02-26 12:46:49 --> Helper loaded: url_helper
INFO - 2021-02-26 12:46:49 --> Helper loaded: file_helper
INFO - 2021-02-26 12:46:49 --> Helper loaded: form_helper
INFO - 2021-02-26 12:46:49 --> Helper loaded: my_helper
INFO - 2021-02-26 12:46:49 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:46:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:46:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:46:49 --> Controller Class Initialized
DEBUG - 2021-02-26 12:46:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-02-26 12:46:49 --> Final output sent to browser
DEBUG - 2021-02-26 12:46:49 --> Total execution time: 0.9428
INFO - 2021-02-26 12:47:16 --> Config Class Initialized
INFO - 2021-02-26 12:47:16 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:47:16 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:47:16 --> Utf8 Class Initialized
INFO - 2021-02-26 12:47:16 --> URI Class Initialized
INFO - 2021-02-26 12:47:16 --> Router Class Initialized
INFO - 2021-02-26 12:47:16 --> Output Class Initialized
INFO - 2021-02-26 12:47:16 --> Security Class Initialized
DEBUG - 2021-02-26 12:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:47:16 --> Input Class Initialized
INFO - 2021-02-26 12:47:16 --> Language Class Initialized
INFO - 2021-02-26 12:47:16 --> Language Class Initialized
INFO - 2021-02-26 12:47:16 --> Config Class Initialized
INFO - 2021-02-26 12:47:16 --> Loader Class Initialized
INFO - 2021-02-26 12:47:16 --> Helper loaded: url_helper
INFO - 2021-02-26 12:47:16 --> Helper loaded: file_helper
INFO - 2021-02-26 12:47:16 --> Helper loaded: form_helper
INFO - 2021-02-26 12:47:16 --> Helper loaded: my_helper
INFO - 2021-02-26 12:47:16 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:47:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:47:17 --> Controller Class Initialized
INFO - 2021-02-26 12:47:17 --> Final output sent to browser
DEBUG - 2021-02-26 12:47:17 --> Total execution time: 1.0958
INFO - 2021-02-26 12:47:20 --> Config Class Initialized
INFO - 2021-02-26 12:47:20 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:47:20 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:47:20 --> Utf8 Class Initialized
INFO - 2021-02-26 12:47:20 --> URI Class Initialized
INFO - 2021-02-26 12:47:20 --> Router Class Initialized
INFO - 2021-02-26 12:47:20 --> Output Class Initialized
INFO - 2021-02-26 12:47:20 --> Security Class Initialized
DEBUG - 2021-02-26 12:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:47:21 --> Input Class Initialized
INFO - 2021-02-26 12:47:21 --> Language Class Initialized
INFO - 2021-02-26 12:47:21 --> Language Class Initialized
INFO - 2021-02-26 12:47:21 --> Config Class Initialized
INFO - 2021-02-26 12:47:21 --> Loader Class Initialized
INFO - 2021-02-26 12:47:21 --> Helper loaded: url_helper
INFO - 2021-02-26 12:47:21 --> Helper loaded: file_helper
INFO - 2021-02-26 12:47:21 --> Helper loaded: form_helper
INFO - 2021-02-26 12:47:21 --> Helper loaded: my_helper
INFO - 2021-02-26 12:47:21 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:47:21 --> Controller Class Initialized
DEBUG - 2021-02-26 12:47:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-02-26 12:47:21 --> Final output sent to browser
DEBUG - 2021-02-26 12:47:21 --> Total execution time: 1.1076
INFO - 2021-02-26 12:49:23 --> Config Class Initialized
INFO - 2021-02-26 12:49:23 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:49:24 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:49:24 --> Utf8 Class Initialized
INFO - 2021-02-26 12:49:24 --> URI Class Initialized
INFO - 2021-02-26 12:49:24 --> Router Class Initialized
INFO - 2021-02-26 12:49:24 --> Output Class Initialized
INFO - 2021-02-26 12:49:24 --> Security Class Initialized
DEBUG - 2021-02-26 12:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:49:24 --> Input Class Initialized
INFO - 2021-02-26 12:49:24 --> Language Class Initialized
INFO - 2021-02-26 12:49:24 --> Language Class Initialized
INFO - 2021-02-26 12:49:24 --> Config Class Initialized
INFO - 2021-02-26 12:49:24 --> Loader Class Initialized
INFO - 2021-02-26 12:49:24 --> Helper loaded: url_helper
INFO - 2021-02-26 12:49:24 --> Helper loaded: file_helper
INFO - 2021-02-26 12:49:24 --> Helper loaded: form_helper
INFO - 2021-02-26 12:49:24 --> Helper loaded: my_helper
INFO - 2021-02-26 12:49:24 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:49:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:49:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:49:24 --> Controller Class Initialized
INFO - 2021-02-26 12:49:24 --> Helper loaded: cookie_helper
INFO - 2021-02-26 12:49:24 --> Config Class Initialized
INFO - 2021-02-26 12:49:25 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:49:25 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:49:25 --> Utf8 Class Initialized
INFO - 2021-02-26 12:49:25 --> URI Class Initialized
INFO - 2021-02-26 12:49:25 --> Router Class Initialized
INFO - 2021-02-26 12:49:25 --> Output Class Initialized
INFO - 2021-02-26 12:49:25 --> Security Class Initialized
DEBUG - 2021-02-26 12:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:49:25 --> Input Class Initialized
INFO - 2021-02-26 12:49:25 --> Language Class Initialized
INFO - 2021-02-26 12:49:25 --> Language Class Initialized
INFO - 2021-02-26 12:49:25 --> Config Class Initialized
INFO - 2021-02-26 12:49:25 --> Loader Class Initialized
INFO - 2021-02-26 12:49:25 --> Helper loaded: url_helper
INFO - 2021-02-26 12:49:25 --> Helper loaded: file_helper
INFO - 2021-02-26 12:49:25 --> Helper loaded: form_helper
INFO - 2021-02-26 12:49:25 --> Helper loaded: my_helper
INFO - 2021-02-26 12:49:25 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:49:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:49:25 --> Controller Class Initialized
DEBUG - 2021-02-26 12:49:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-02-26 12:49:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 12:49:26 --> Final output sent to browser
DEBUG - 2021-02-26 12:49:26 --> Total execution time: 1.1447
INFO - 2021-02-26 12:49:35 --> Config Class Initialized
INFO - 2021-02-26 12:49:35 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:49:35 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:49:35 --> Utf8 Class Initialized
INFO - 2021-02-26 12:49:35 --> URI Class Initialized
INFO - 2021-02-26 12:49:35 --> Router Class Initialized
INFO - 2021-02-26 12:49:35 --> Output Class Initialized
INFO - 2021-02-26 12:49:35 --> Security Class Initialized
DEBUG - 2021-02-26 12:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:49:35 --> Input Class Initialized
INFO - 2021-02-26 12:49:35 --> Language Class Initialized
INFO - 2021-02-26 12:49:35 --> Language Class Initialized
INFO - 2021-02-26 12:49:35 --> Config Class Initialized
INFO - 2021-02-26 12:49:35 --> Loader Class Initialized
INFO - 2021-02-26 12:49:35 --> Helper loaded: url_helper
INFO - 2021-02-26 12:49:35 --> Helper loaded: file_helper
INFO - 2021-02-26 12:49:35 --> Helper loaded: form_helper
INFO - 2021-02-26 12:49:35 --> Helper loaded: my_helper
INFO - 2021-02-26 12:49:36 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:49:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:49:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:49:36 --> Controller Class Initialized
INFO - 2021-02-26 12:49:36 --> Helper loaded: cookie_helper
INFO - 2021-02-26 12:49:36 --> Final output sent to browser
DEBUG - 2021-02-26 12:49:36 --> Total execution time: 0.8893
INFO - 2021-02-26 12:49:36 --> Config Class Initialized
INFO - 2021-02-26 12:49:36 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:49:36 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:49:36 --> Utf8 Class Initialized
INFO - 2021-02-26 12:49:36 --> URI Class Initialized
INFO - 2021-02-26 12:49:36 --> Router Class Initialized
INFO - 2021-02-26 12:49:36 --> Output Class Initialized
INFO - 2021-02-26 12:49:37 --> Security Class Initialized
DEBUG - 2021-02-26 12:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:49:37 --> Input Class Initialized
INFO - 2021-02-26 12:49:37 --> Language Class Initialized
INFO - 2021-02-26 12:49:37 --> Language Class Initialized
INFO - 2021-02-26 12:49:37 --> Config Class Initialized
INFO - 2021-02-26 12:49:37 --> Loader Class Initialized
INFO - 2021-02-26 12:49:37 --> Helper loaded: url_helper
INFO - 2021-02-26 12:49:37 --> Helper loaded: file_helper
INFO - 2021-02-26 12:49:37 --> Helper loaded: form_helper
INFO - 2021-02-26 12:49:37 --> Helper loaded: my_helper
INFO - 2021-02-26 12:49:37 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:49:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:49:37 --> Controller Class Initialized
DEBUG - 2021-02-26 12:49:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-02-26 12:49:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 12:49:37 --> Final output sent to browser
DEBUG - 2021-02-26 12:49:37 --> Total execution time: 0.9441
INFO - 2021-02-26 12:49:40 --> Config Class Initialized
INFO - 2021-02-26 12:49:40 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:49:40 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:49:40 --> Utf8 Class Initialized
INFO - 2021-02-26 12:49:40 --> URI Class Initialized
INFO - 2021-02-26 12:49:40 --> Router Class Initialized
INFO - 2021-02-26 12:49:40 --> Output Class Initialized
INFO - 2021-02-26 12:49:40 --> Security Class Initialized
DEBUG - 2021-02-26 12:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:49:40 --> Input Class Initialized
INFO - 2021-02-26 12:49:40 --> Language Class Initialized
INFO - 2021-02-26 12:49:40 --> Language Class Initialized
INFO - 2021-02-26 12:49:40 --> Config Class Initialized
INFO - 2021-02-26 12:49:40 --> Loader Class Initialized
INFO - 2021-02-26 12:49:40 --> Helper loaded: url_helper
INFO - 2021-02-26 12:49:40 --> Helper loaded: file_helper
INFO - 2021-02-26 12:49:40 --> Helper loaded: form_helper
INFO - 2021-02-26 12:49:40 --> Helper loaded: my_helper
INFO - 2021-02-26 12:49:40 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:49:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:49:40 --> Controller Class Initialized
DEBUG - 2021-02-26 12:49:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-02-26 12:49:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 12:49:40 --> Final output sent to browser
DEBUG - 2021-02-26 12:49:40 --> Total execution time: 0.7571
INFO - 2021-02-26 12:49:43 --> Config Class Initialized
INFO - 2021-02-26 12:49:43 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:49:43 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:49:43 --> Utf8 Class Initialized
INFO - 2021-02-26 12:49:43 --> URI Class Initialized
INFO - 2021-02-26 12:49:43 --> Router Class Initialized
INFO - 2021-02-26 12:49:43 --> Output Class Initialized
INFO - 2021-02-26 12:49:43 --> Security Class Initialized
DEBUG - 2021-02-26 12:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:49:43 --> Input Class Initialized
INFO - 2021-02-26 12:49:43 --> Language Class Initialized
INFO - 2021-02-26 12:49:43 --> Language Class Initialized
INFO - 2021-02-26 12:49:43 --> Config Class Initialized
INFO - 2021-02-26 12:49:43 --> Loader Class Initialized
INFO - 2021-02-26 12:49:43 --> Helper loaded: url_helper
INFO - 2021-02-26 12:49:43 --> Helper loaded: file_helper
INFO - 2021-02-26 12:49:43 --> Helper loaded: form_helper
INFO - 2021-02-26 12:49:43 --> Helper loaded: my_helper
INFO - 2021-02-26 12:49:44 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:49:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:49:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:49:44 --> Controller Class Initialized
DEBUG - 2021-02-26 12:49:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-02-26 12:49:44 --> Final output sent to browser
DEBUG - 2021-02-26 12:49:44 --> Total execution time: 0.9547
INFO - 2021-02-26 12:50:26 --> Config Class Initialized
INFO - 2021-02-26 12:50:26 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:50:26 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:50:26 --> Utf8 Class Initialized
INFO - 2021-02-26 12:50:26 --> URI Class Initialized
INFO - 2021-02-26 12:50:26 --> Router Class Initialized
INFO - 2021-02-26 12:50:26 --> Output Class Initialized
INFO - 2021-02-26 12:50:26 --> Security Class Initialized
DEBUG - 2021-02-26 12:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:50:26 --> Input Class Initialized
INFO - 2021-02-26 12:50:26 --> Language Class Initialized
INFO - 2021-02-26 12:50:26 --> Language Class Initialized
INFO - 2021-02-26 12:50:26 --> Config Class Initialized
INFO - 2021-02-26 12:50:26 --> Loader Class Initialized
INFO - 2021-02-26 12:50:26 --> Helper loaded: url_helper
INFO - 2021-02-26 12:50:26 --> Helper loaded: file_helper
INFO - 2021-02-26 12:50:26 --> Helper loaded: form_helper
INFO - 2021-02-26 12:50:26 --> Helper loaded: my_helper
INFO - 2021-02-26 12:50:26 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:50:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:50:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:50:27 --> Controller Class Initialized
DEBUG - 2021-02-26 12:50:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-02-26 12:50:27 --> Final output sent to browser
DEBUG - 2021-02-26 12:50:27 --> Total execution time: 0.8755
INFO - 2021-02-26 12:50:36 --> Config Class Initialized
INFO - 2021-02-26 12:50:36 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:50:36 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:50:36 --> Utf8 Class Initialized
INFO - 2021-02-26 12:50:36 --> URI Class Initialized
INFO - 2021-02-26 12:50:36 --> Router Class Initialized
INFO - 2021-02-26 12:50:36 --> Output Class Initialized
INFO - 2021-02-26 12:50:36 --> Security Class Initialized
DEBUG - 2021-02-26 12:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:50:36 --> Input Class Initialized
INFO - 2021-02-26 12:50:36 --> Language Class Initialized
INFO - 2021-02-26 12:50:36 --> Language Class Initialized
INFO - 2021-02-26 12:50:36 --> Config Class Initialized
INFO - 2021-02-26 12:50:36 --> Loader Class Initialized
INFO - 2021-02-26 12:50:37 --> Helper loaded: url_helper
INFO - 2021-02-26 12:50:37 --> Helper loaded: file_helper
INFO - 2021-02-26 12:50:37 --> Helper loaded: form_helper
INFO - 2021-02-26 12:50:37 --> Helper loaded: my_helper
INFO - 2021-02-26 12:50:37 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:50:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:50:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:50:37 --> Controller Class Initialized
DEBUG - 2021-02-26 12:50:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-02-26 12:50:37 --> Final output sent to browser
DEBUG - 2021-02-26 12:50:37 --> Total execution time: 1.0505
INFO - 2021-02-26 12:51:02 --> Config Class Initialized
INFO - 2021-02-26 12:51:02 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:51:02 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:51:02 --> Utf8 Class Initialized
INFO - 2021-02-26 12:51:02 --> URI Class Initialized
INFO - 2021-02-26 12:51:02 --> Router Class Initialized
INFO - 2021-02-26 12:51:02 --> Output Class Initialized
INFO - 2021-02-26 12:51:02 --> Security Class Initialized
DEBUG - 2021-02-26 12:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:51:02 --> Input Class Initialized
INFO - 2021-02-26 12:51:03 --> Language Class Initialized
INFO - 2021-02-26 12:51:03 --> Language Class Initialized
INFO - 2021-02-26 12:51:03 --> Config Class Initialized
INFO - 2021-02-26 12:51:03 --> Loader Class Initialized
INFO - 2021-02-26 12:51:03 --> Helper loaded: url_helper
INFO - 2021-02-26 12:51:03 --> Helper loaded: file_helper
INFO - 2021-02-26 12:51:03 --> Helper loaded: form_helper
INFO - 2021-02-26 12:51:03 --> Helper loaded: my_helper
INFO - 2021-02-26 12:51:03 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:51:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:51:03 --> Controller Class Initialized
DEBUG - 2021-02-26 12:51:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-02-26 12:51:03 --> Final output sent to browser
DEBUG - 2021-02-26 12:51:03 --> Total execution time: 1.1042
INFO - 2021-02-26 12:51:26 --> Config Class Initialized
INFO - 2021-02-26 12:51:26 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:51:26 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:51:26 --> Utf8 Class Initialized
INFO - 2021-02-26 12:51:26 --> URI Class Initialized
INFO - 2021-02-26 12:51:26 --> Router Class Initialized
INFO - 2021-02-26 12:51:26 --> Output Class Initialized
INFO - 2021-02-26 12:51:26 --> Security Class Initialized
DEBUG - 2021-02-26 12:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:51:27 --> Input Class Initialized
INFO - 2021-02-26 12:51:27 --> Language Class Initialized
INFO - 2021-02-26 12:51:27 --> Language Class Initialized
INFO - 2021-02-26 12:51:27 --> Config Class Initialized
INFO - 2021-02-26 12:51:27 --> Loader Class Initialized
INFO - 2021-02-26 12:51:27 --> Helper loaded: url_helper
INFO - 2021-02-26 12:51:27 --> Helper loaded: file_helper
INFO - 2021-02-26 12:51:27 --> Helper loaded: form_helper
INFO - 2021-02-26 12:51:27 --> Helper loaded: my_helper
INFO - 2021-02-26 12:51:27 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:51:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:51:27 --> Controller Class Initialized
DEBUG - 2021-02-26 12:51:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-02-26 12:51:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 12:51:27 --> Final output sent to browser
DEBUG - 2021-02-26 12:51:27 --> Total execution time: 1.0617
INFO - 2021-02-26 12:51:49 --> Config Class Initialized
INFO - 2021-02-26 12:51:49 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:51:49 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:51:49 --> Utf8 Class Initialized
INFO - 2021-02-26 12:51:49 --> URI Class Initialized
INFO - 2021-02-26 12:51:49 --> Router Class Initialized
INFO - 2021-02-26 12:51:49 --> Output Class Initialized
INFO - 2021-02-26 12:51:49 --> Security Class Initialized
DEBUG - 2021-02-26 12:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:51:49 --> Input Class Initialized
INFO - 2021-02-26 12:51:49 --> Language Class Initialized
INFO - 2021-02-26 12:51:49 --> Language Class Initialized
INFO - 2021-02-26 12:51:49 --> Config Class Initialized
INFO - 2021-02-26 12:51:49 --> Loader Class Initialized
INFO - 2021-02-26 12:51:49 --> Helper loaded: url_helper
INFO - 2021-02-26 12:51:49 --> Helper loaded: file_helper
INFO - 2021-02-26 12:51:49 --> Helper loaded: form_helper
INFO - 2021-02-26 12:51:49 --> Helper loaded: my_helper
INFO - 2021-02-26 12:51:49 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:51:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:51:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:51:49 --> Controller Class Initialized
INFO - 2021-02-26 12:51:50 --> Final output sent to browser
DEBUG - 2021-02-26 12:51:50 --> Total execution time: 0.9261
INFO - 2021-02-26 12:52:09 --> Config Class Initialized
INFO - 2021-02-26 12:52:09 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:52:10 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:52:10 --> Utf8 Class Initialized
INFO - 2021-02-26 12:52:10 --> URI Class Initialized
INFO - 2021-02-26 12:52:10 --> Router Class Initialized
INFO - 2021-02-26 12:52:10 --> Output Class Initialized
INFO - 2021-02-26 12:52:10 --> Security Class Initialized
DEBUG - 2021-02-26 12:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:52:10 --> Input Class Initialized
INFO - 2021-02-26 12:52:10 --> Language Class Initialized
INFO - 2021-02-26 12:52:10 --> Language Class Initialized
INFO - 2021-02-26 12:52:10 --> Config Class Initialized
INFO - 2021-02-26 12:52:10 --> Loader Class Initialized
INFO - 2021-02-26 12:52:10 --> Helper loaded: url_helper
INFO - 2021-02-26 12:52:10 --> Helper loaded: file_helper
INFO - 2021-02-26 12:52:10 --> Helper loaded: form_helper
INFO - 2021-02-26 12:52:10 --> Helper loaded: my_helper
INFO - 2021-02-26 12:52:10 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:52:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:52:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:52:10 --> Controller Class Initialized
DEBUG - 2021-02-26 12:52:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-02-26 12:52:10 --> Final output sent to browser
DEBUG - 2021-02-26 12:52:10 --> Total execution time: 0.8974
INFO - 2021-02-26 12:52:32 --> Config Class Initialized
INFO - 2021-02-26 12:52:32 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:52:32 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:52:32 --> Utf8 Class Initialized
INFO - 2021-02-26 12:52:32 --> URI Class Initialized
INFO - 2021-02-26 12:52:32 --> Router Class Initialized
INFO - 2021-02-26 12:52:32 --> Output Class Initialized
INFO - 2021-02-26 12:52:32 --> Security Class Initialized
DEBUG - 2021-02-26 12:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:52:33 --> Input Class Initialized
INFO - 2021-02-26 12:52:33 --> Language Class Initialized
INFO - 2021-02-26 12:52:33 --> Language Class Initialized
INFO - 2021-02-26 12:52:33 --> Config Class Initialized
INFO - 2021-02-26 12:52:33 --> Loader Class Initialized
INFO - 2021-02-26 12:52:33 --> Helper loaded: url_helper
INFO - 2021-02-26 12:52:33 --> Helper loaded: file_helper
INFO - 2021-02-26 12:52:33 --> Helper loaded: form_helper
INFO - 2021-02-26 12:52:33 --> Helper loaded: my_helper
INFO - 2021-02-26 12:52:33 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:52:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:52:33 --> Controller Class Initialized
INFO - 2021-02-26 12:52:33 --> Helper loaded: cookie_helper
INFO - 2021-02-26 12:52:33 --> Config Class Initialized
INFO - 2021-02-26 12:52:33 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:52:33 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:52:33 --> Utf8 Class Initialized
INFO - 2021-02-26 12:52:33 --> URI Class Initialized
INFO - 2021-02-26 12:52:33 --> Router Class Initialized
INFO - 2021-02-26 12:52:33 --> Output Class Initialized
INFO - 2021-02-26 12:52:33 --> Security Class Initialized
DEBUG - 2021-02-26 12:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:52:34 --> Input Class Initialized
INFO - 2021-02-26 12:52:34 --> Language Class Initialized
INFO - 2021-02-26 12:52:34 --> Language Class Initialized
INFO - 2021-02-26 12:52:34 --> Config Class Initialized
INFO - 2021-02-26 12:52:34 --> Loader Class Initialized
INFO - 2021-02-26 12:52:34 --> Helper loaded: url_helper
INFO - 2021-02-26 12:52:34 --> Helper loaded: file_helper
INFO - 2021-02-26 12:52:34 --> Helper loaded: form_helper
INFO - 2021-02-26 12:52:34 --> Helper loaded: my_helper
INFO - 2021-02-26 12:52:34 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:52:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:52:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:52:34 --> Controller Class Initialized
DEBUG - 2021-02-26 12:52:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-02-26 12:52:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 12:52:34 --> Final output sent to browser
DEBUG - 2021-02-26 12:52:34 --> Total execution time: 1.0530
INFO - 2021-02-26 12:52:42 --> Config Class Initialized
INFO - 2021-02-26 12:52:42 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:52:42 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:52:42 --> Utf8 Class Initialized
INFO - 2021-02-26 12:52:42 --> URI Class Initialized
INFO - 2021-02-26 12:52:42 --> Router Class Initialized
INFO - 2021-02-26 12:52:42 --> Output Class Initialized
INFO - 2021-02-26 12:52:42 --> Security Class Initialized
DEBUG - 2021-02-26 12:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:52:42 --> Input Class Initialized
INFO - 2021-02-26 12:52:42 --> Language Class Initialized
INFO - 2021-02-26 12:52:42 --> Language Class Initialized
INFO - 2021-02-26 12:52:42 --> Config Class Initialized
INFO - 2021-02-26 12:52:42 --> Loader Class Initialized
INFO - 2021-02-26 12:52:42 --> Helper loaded: url_helper
INFO - 2021-02-26 12:52:42 --> Helper loaded: file_helper
INFO - 2021-02-26 12:52:42 --> Helper loaded: form_helper
INFO - 2021-02-26 12:52:42 --> Helper loaded: my_helper
INFO - 2021-02-26 12:52:42 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:52:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:52:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:52:43 --> Controller Class Initialized
INFO - 2021-02-26 12:52:43 --> Helper loaded: cookie_helper
INFO - 2021-02-26 12:52:43 --> Final output sent to browser
DEBUG - 2021-02-26 12:52:43 --> Total execution time: 0.8691
INFO - 2021-02-26 12:52:44 --> Config Class Initialized
INFO - 2021-02-26 12:52:44 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:52:44 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:52:44 --> Utf8 Class Initialized
INFO - 2021-02-26 12:52:44 --> URI Class Initialized
INFO - 2021-02-26 12:52:44 --> Router Class Initialized
INFO - 2021-02-26 12:52:44 --> Output Class Initialized
INFO - 2021-02-26 12:52:44 --> Security Class Initialized
DEBUG - 2021-02-26 12:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:52:44 --> Input Class Initialized
INFO - 2021-02-26 12:52:44 --> Language Class Initialized
INFO - 2021-02-26 12:52:44 --> Language Class Initialized
INFO - 2021-02-26 12:52:44 --> Config Class Initialized
INFO - 2021-02-26 12:52:44 --> Loader Class Initialized
INFO - 2021-02-26 12:52:44 --> Helper loaded: url_helper
INFO - 2021-02-26 12:52:44 --> Helper loaded: file_helper
INFO - 2021-02-26 12:52:44 --> Helper loaded: form_helper
INFO - 2021-02-26 12:52:44 --> Helper loaded: my_helper
INFO - 2021-02-26 12:52:44 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:52:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:52:45 --> Controller Class Initialized
DEBUG - 2021-02-26 12:52:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-02-26 12:52:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 12:52:45 --> Final output sent to browser
DEBUG - 2021-02-26 12:52:45 --> Total execution time: 1.0666
INFO - 2021-02-26 12:53:01 --> Config Class Initialized
INFO - 2021-02-26 12:53:01 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:53:01 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:53:01 --> Utf8 Class Initialized
INFO - 2021-02-26 12:53:01 --> URI Class Initialized
INFO - 2021-02-26 12:53:01 --> Router Class Initialized
INFO - 2021-02-26 12:53:01 --> Output Class Initialized
INFO - 2021-02-26 12:53:02 --> Security Class Initialized
DEBUG - 2021-02-26 12:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:53:02 --> Input Class Initialized
INFO - 2021-02-26 12:53:02 --> Language Class Initialized
INFO - 2021-02-26 12:53:02 --> Language Class Initialized
INFO - 2021-02-26 12:53:02 --> Config Class Initialized
INFO - 2021-02-26 12:53:02 --> Loader Class Initialized
INFO - 2021-02-26 12:53:02 --> Helper loaded: url_helper
INFO - 2021-02-26 12:53:02 --> Helper loaded: file_helper
INFO - 2021-02-26 12:53:02 --> Helper loaded: form_helper
INFO - 2021-02-26 12:53:02 --> Helper loaded: my_helper
INFO - 2021-02-26 12:53:02 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:53:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:53:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:53:02 --> Controller Class Initialized
DEBUG - 2021-02-26 12:53:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-02-26 12:53:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 12:53:02 --> Final output sent to browser
DEBUG - 2021-02-26 12:53:02 --> Total execution time: 1.1369
INFO - 2021-02-26 12:53:06 --> Config Class Initialized
INFO - 2021-02-26 12:53:06 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:53:06 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:53:06 --> Utf8 Class Initialized
INFO - 2021-02-26 12:53:06 --> URI Class Initialized
INFO - 2021-02-26 12:53:06 --> Router Class Initialized
INFO - 2021-02-26 12:53:06 --> Output Class Initialized
INFO - 2021-02-26 12:53:06 --> Security Class Initialized
DEBUG - 2021-02-26 12:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:53:06 --> Input Class Initialized
INFO - 2021-02-26 12:53:06 --> Language Class Initialized
INFO - 2021-02-26 12:53:06 --> Language Class Initialized
INFO - 2021-02-26 12:53:06 --> Config Class Initialized
INFO - 2021-02-26 12:53:06 --> Loader Class Initialized
INFO - 2021-02-26 12:53:06 --> Helper loaded: url_helper
INFO - 2021-02-26 12:53:06 --> Helper loaded: file_helper
INFO - 2021-02-26 12:53:06 --> Helper loaded: form_helper
INFO - 2021-02-26 12:53:06 --> Helper loaded: my_helper
INFO - 2021-02-26 12:53:06 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:53:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:53:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:53:06 --> Controller Class Initialized
DEBUG - 2021-02-26 12:53:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2021-02-26 12:53:07 --> Final output sent to browser
DEBUG - 2021-02-26 12:53:07 --> Total execution time: 1.0162
INFO - 2021-02-26 12:53:52 --> Config Class Initialized
INFO - 2021-02-26 12:53:52 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:53:53 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:53:53 --> Utf8 Class Initialized
INFO - 2021-02-26 12:53:53 --> URI Class Initialized
INFO - 2021-02-26 12:53:53 --> Router Class Initialized
INFO - 2021-02-26 12:53:53 --> Output Class Initialized
INFO - 2021-02-26 12:53:53 --> Security Class Initialized
DEBUG - 2021-02-26 12:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:53:53 --> Input Class Initialized
INFO - 2021-02-26 12:53:53 --> Language Class Initialized
INFO - 2021-02-26 12:53:53 --> Language Class Initialized
INFO - 2021-02-26 12:53:53 --> Config Class Initialized
INFO - 2021-02-26 12:53:53 --> Loader Class Initialized
INFO - 2021-02-26 12:53:53 --> Helper loaded: url_helper
INFO - 2021-02-26 12:53:53 --> Helper loaded: file_helper
INFO - 2021-02-26 12:53:53 --> Helper loaded: form_helper
INFO - 2021-02-26 12:53:53 --> Helper loaded: my_helper
INFO - 2021-02-26 12:53:53 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:53:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:53:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:53:53 --> Controller Class Initialized
DEBUG - 2021-02-26 12:53:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2021-02-26 12:53:54 --> Final output sent to browser
DEBUG - 2021-02-26 12:53:54 --> Total execution time: 1.1944
INFO - 2021-02-26 12:55:01 --> Config Class Initialized
INFO - 2021-02-26 12:55:01 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:55:01 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:55:01 --> Utf8 Class Initialized
INFO - 2021-02-26 12:55:01 --> URI Class Initialized
INFO - 2021-02-26 12:55:01 --> Router Class Initialized
INFO - 2021-02-26 12:55:01 --> Output Class Initialized
INFO - 2021-02-26 12:55:01 --> Security Class Initialized
DEBUG - 2021-02-26 12:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:55:01 --> Input Class Initialized
INFO - 2021-02-26 12:55:01 --> Language Class Initialized
INFO - 2021-02-26 12:55:01 --> Language Class Initialized
INFO - 2021-02-26 12:55:01 --> Config Class Initialized
INFO - 2021-02-26 12:55:01 --> Loader Class Initialized
INFO - 2021-02-26 12:55:01 --> Helper loaded: url_helper
INFO - 2021-02-26 12:55:02 --> Helper loaded: file_helper
INFO - 2021-02-26 12:55:02 --> Helper loaded: form_helper
INFO - 2021-02-26 12:55:02 --> Helper loaded: my_helper
INFO - 2021-02-26 12:55:02 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:55:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:55:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:55:02 --> Controller Class Initialized
DEBUG - 2021-02-26 12:55:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-02-26 12:55:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 12:55:02 --> Final output sent to browser
DEBUG - 2021-02-26 12:55:02 --> Total execution time: 1.1613
INFO - 2021-02-26 12:55:24 --> Config Class Initialized
INFO - 2021-02-26 12:55:24 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:55:24 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:55:24 --> Utf8 Class Initialized
INFO - 2021-02-26 12:55:24 --> URI Class Initialized
INFO - 2021-02-26 12:55:24 --> Router Class Initialized
INFO - 2021-02-26 12:55:24 --> Output Class Initialized
INFO - 2021-02-26 12:55:24 --> Security Class Initialized
DEBUG - 2021-02-26 12:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:55:24 --> Input Class Initialized
INFO - 2021-02-26 12:55:24 --> Language Class Initialized
INFO - 2021-02-26 12:55:24 --> Language Class Initialized
INFO - 2021-02-26 12:55:24 --> Config Class Initialized
INFO - 2021-02-26 12:55:24 --> Loader Class Initialized
INFO - 2021-02-26 12:55:24 --> Helper loaded: url_helper
INFO - 2021-02-26 12:55:25 --> Helper loaded: file_helper
INFO - 2021-02-26 12:55:25 --> Helper loaded: form_helper
INFO - 2021-02-26 12:55:25 --> Helper loaded: my_helper
INFO - 2021-02-26 12:55:25 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:55:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:55:25 --> Controller Class Initialized
INFO - 2021-02-26 12:55:25 --> Final output sent to browser
DEBUG - 2021-02-26 12:55:25 --> Total execution time: 0.9498
INFO - 2021-02-26 12:55:28 --> Config Class Initialized
INFO - 2021-02-26 12:55:28 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:55:28 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:55:28 --> Utf8 Class Initialized
INFO - 2021-02-26 12:55:28 --> URI Class Initialized
INFO - 2021-02-26 12:55:28 --> Router Class Initialized
INFO - 2021-02-26 12:55:28 --> Output Class Initialized
INFO - 2021-02-26 12:55:28 --> Security Class Initialized
DEBUG - 2021-02-26 12:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:55:28 --> Input Class Initialized
INFO - 2021-02-26 12:55:28 --> Language Class Initialized
INFO - 2021-02-26 12:55:28 --> Language Class Initialized
INFO - 2021-02-26 12:55:28 --> Config Class Initialized
INFO - 2021-02-26 12:55:28 --> Loader Class Initialized
INFO - 2021-02-26 12:55:28 --> Helper loaded: url_helper
INFO - 2021-02-26 12:55:28 --> Helper loaded: file_helper
INFO - 2021-02-26 12:55:28 --> Helper loaded: form_helper
INFO - 2021-02-26 12:55:28 --> Helper loaded: my_helper
INFO - 2021-02-26 12:55:29 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:55:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:55:29 --> Controller Class Initialized
DEBUG - 2021-02-26 12:55:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2021-02-26 12:55:29 --> Final output sent to browser
DEBUG - 2021-02-26 12:55:29 --> Total execution time: 1.0079
INFO - 2021-02-26 12:56:29 --> Config Class Initialized
INFO - 2021-02-26 12:56:29 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:56:29 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:56:29 --> Utf8 Class Initialized
INFO - 2021-02-26 12:56:29 --> URI Class Initialized
DEBUG - 2021-02-26 12:56:29 --> No URI present. Default controller set.
INFO - 2021-02-26 12:56:29 --> Router Class Initialized
INFO - 2021-02-26 12:56:29 --> Output Class Initialized
INFO - 2021-02-26 12:56:29 --> Security Class Initialized
DEBUG - 2021-02-26 12:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:56:29 --> Input Class Initialized
INFO - 2021-02-26 12:56:29 --> Language Class Initialized
INFO - 2021-02-26 12:56:29 --> Language Class Initialized
INFO - 2021-02-26 12:56:29 --> Config Class Initialized
INFO - 2021-02-26 12:56:29 --> Loader Class Initialized
INFO - 2021-02-26 12:56:29 --> Helper loaded: url_helper
INFO - 2021-02-26 12:56:30 --> Helper loaded: file_helper
INFO - 2021-02-26 12:56:30 --> Helper loaded: form_helper
INFO - 2021-02-26 12:56:30 --> Helper loaded: my_helper
INFO - 2021-02-26 12:56:30 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:56:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:56:30 --> Controller Class Initialized
DEBUG - 2021-02-26 12:56:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-02-26 12:56:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 12:56:30 --> Final output sent to browser
DEBUG - 2021-02-26 12:56:30 --> Total execution time: 1.0932
INFO - 2021-02-26 12:56:32 --> Config Class Initialized
INFO - 2021-02-26 12:56:32 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:56:32 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:56:32 --> Utf8 Class Initialized
INFO - 2021-02-26 12:56:32 --> URI Class Initialized
INFO - 2021-02-26 12:56:32 --> Router Class Initialized
INFO - 2021-02-26 12:56:32 --> Output Class Initialized
INFO - 2021-02-26 12:56:32 --> Security Class Initialized
DEBUG - 2021-02-26 12:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:56:32 --> Input Class Initialized
INFO - 2021-02-26 12:56:32 --> Language Class Initialized
INFO - 2021-02-26 12:56:32 --> Language Class Initialized
INFO - 2021-02-26 12:56:32 --> Config Class Initialized
INFO - 2021-02-26 12:56:32 --> Loader Class Initialized
INFO - 2021-02-26 12:56:32 --> Helper loaded: url_helper
INFO - 2021-02-26 12:56:32 --> Helper loaded: file_helper
INFO - 2021-02-26 12:56:32 --> Helper loaded: form_helper
INFO - 2021-02-26 12:56:33 --> Helper loaded: my_helper
INFO - 2021-02-26 12:56:33 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:56:33 --> Controller Class Initialized
INFO - 2021-02-26 12:56:33 --> Helper loaded: cookie_helper
INFO - 2021-02-26 12:56:33 --> Config Class Initialized
INFO - 2021-02-26 12:56:33 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:56:33 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:56:33 --> Utf8 Class Initialized
INFO - 2021-02-26 12:56:33 --> URI Class Initialized
INFO - 2021-02-26 12:56:33 --> Router Class Initialized
INFO - 2021-02-26 12:56:33 --> Output Class Initialized
INFO - 2021-02-26 12:56:33 --> Security Class Initialized
DEBUG - 2021-02-26 12:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:56:33 --> Input Class Initialized
INFO - 2021-02-26 12:56:33 --> Language Class Initialized
INFO - 2021-02-26 12:56:33 --> Language Class Initialized
INFO - 2021-02-26 12:56:33 --> Config Class Initialized
INFO - 2021-02-26 12:56:33 --> Loader Class Initialized
INFO - 2021-02-26 12:56:33 --> Helper loaded: url_helper
INFO - 2021-02-26 12:56:33 --> Helper loaded: file_helper
INFO - 2021-02-26 12:56:33 --> Helper loaded: form_helper
INFO - 2021-02-26 12:56:33 --> Helper loaded: my_helper
INFO - 2021-02-26 12:56:33 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:56:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:56:34 --> Controller Class Initialized
DEBUG - 2021-02-26 12:56:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-02-26 12:56:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 12:56:34 --> Final output sent to browser
DEBUG - 2021-02-26 12:56:34 --> Total execution time: 0.9135
INFO - 2021-02-26 12:56:42 --> Config Class Initialized
INFO - 2021-02-26 12:56:42 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:56:42 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:56:42 --> Utf8 Class Initialized
INFO - 2021-02-26 12:56:42 --> URI Class Initialized
INFO - 2021-02-26 12:56:42 --> Router Class Initialized
INFO - 2021-02-26 12:56:42 --> Output Class Initialized
INFO - 2021-02-26 12:56:42 --> Security Class Initialized
DEBUG - 2021-02-26 12:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:56:42 --> Input Class Initialized
INFO - 2021-02-26 12:56:42 --> Language Class Initialized
INFO - 2021-02-26 12:56:42 --> Language Class Initialized
INFO - 2021-02-26 12:56:42 --> Config Class Initialized
INFO - 2021-02-26 12:56:42 --> Loader Class Initialized
INFO - 2021-02-26 12:56:42 --> Helper loaded: url_helper
INFO - 2021-02-26 12:56:42 --> Helper loaded: file_helper
INFO - 2021-02-26 12:56:42 --> Helper loaded: form_helper
INFO - 2021-02-26 12:56:42 --> Helper loaded: my_helper
INFO - 2021-02-26 12:56:43 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:56:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:56:43 --> Controller Class Initialized
INFO - 2021-02-26 12:56:43 --> Helper loaded: cookie_helper
INFO - 2021-02-26 12:56:43 --> Final output sent to browser
DEBUG - 2021-02-26 12:56:43 --> Total execution time: 1.0690
INFO - 2021-02-26 12:56:43 --> Config Class Initialized
INFO - 2021-02-26 12:56:43 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:56:43 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:56:43 --> Utf8 Class Initialized
INFO - 2021-02-26 12:56:43 --> URI Class Initialized
INFO - 2021-02-26 12:56:43 --> Router Class Initialized
INFO - 2021-02-26 12:56:44 --> Output Class Initialized
INFO - 2021-02-26 12:56:44 --> Security Class Initialized
DEBUG - 2021-02-26 12:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:56:44 --> Input Class Initialized
INFO - 2021-02-26 12:56:44 --> Language Class Initialized
INFO - 2021-02-26 12:56:44 --> Language Class Initialized
INFO - 2021-02-26 12:56:44 --> Config Class Initialized
INFO - 2021-02-26 12:56:44 --> Loader Class Initialized
INFO - 2021-02-26 12:56:44 --> Helper loaded: url_helper
INFO - 2021-02-26 12:56:44 --> Helper loaded: file_helper
INFO - 2021-02-26 12:56:44 --> Helper loaded: form_helper
INFO - 2021-02-26 12:56:44 --> Helper loaded: my_helper
INFO - 2021-02-26 12:56:44 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:56:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:56:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:56:44 --> Controller Class Initialized
DEBUG - 2021-02-26 12:56:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-02-26 12:56:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 12:56:44 --> Final output sent to browser
DEBUG - 2021-02-26 12:56:44 --> Total execution time: 1.0955
INFO - 2021-02-26 12:56:47 --> Config Class Initialized
INFO - 2021-02-26 12:56:47 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:56:47 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:56:47 --> Utf8 Class Initialized
INFO - 2021-02-26 12:56:47 --> URI Class Initialized
INFO - 2021-02-26 12:56:47 --> Router Class Initialized
INFO - 2021-02-26 12:56:47 --> Output Class Initialized
INFO - 2021-02-26 12:56:47 --> Security Class Initialized
DEBUG - 2021-02-26 12:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:56:47 --> Input Class Initialized
INFO - 2021-02-26 12:56:47 --> Language Class Initialized
INFO - 2021-02-26 12:56:47 --> Language Class Initialized
INFO - 2021-02-26 12:56:47 --> Config Class Initialized
INFO - 2021-02-26 12:56:47 --> Loader Class Initialized
INFO - 2021-02-26 12:56:47 --> Helper loaded: url_helper
INFO - 2021-02-26 12:56:48 --> Helper loaded: file_helper
INFO - 2021-02-26 12:56:48 --> Helper loaded: form_helper
INFO - 2021-02-26 12:56:48 --> Helper loaded: my_helper
INFO - 2021-02-26 12:56:48 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:56:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:56:48 --> Controller Class Initialized
DEBUG - 2021-02-26 12:56:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-02-26 12:56:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 12:56:48 --> Final output sent to browser
DEBUG - 2021-02-26 12:56:48 --> Total execution time: 0.9366
INFO - 2021-02-26 12:57:06 --> Config Class Initialized
INFO - 2021-02-26 12:57:06 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:57:06 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:57:06 --> Utf8 Class Initialized
INFO - 2021-02-26 12:57:06 --> URI Class Initialized
INFO - 2021-02-26 12:57:06 --> Router Class Initialized
INFO - 2021-02-26 12:57:06 --> Output Class Initialized
INFO - 2021-02-26 12:57:06 --> Security Class Initialized
DEBUG - 2021-02-26 12:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:57:07 --> Input Class Initialized
INFO - 2021-02-26 12:57:07 --> Language Class Initialized
INFO - 2021-02-26 12:57:07 --> Language Class Initialized
INFO - 2021-02-26 12:57:07 --> Config Class Initialized
INFO - 2021-02-26 12:57:07 --> Loader Class Initialized
INFO - 2021-02-26 12:57:07 --> Helper loaded: url_helper
INFO - 2021-02-26 12:57:07 --> Helper loaded: file_helper
INFO - 2021-02-26 12:57:07 --> Helper loaded: form_helper
INFO - 2021-02-26 12:57:07 --> Helper loaded: my_helper
INFO - 2021-02-26 12:57:07 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:57:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:57:07 --> Controller Class Initialized
INFO - 2021-02-26 12:57:07 --> Final output sent to browser
DEBUG - 2021-02-26 12:57:07 --> Total execution time: 0.9014
INFO - 2021-02-26 12:57:09 --> Config Class Initialized
INFO - 2021-02-26 12:57:09 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:57:09 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:57:09 --> Utf8 Class Initialized
INFO - 2021-02-26 12:57:09 --> URI Class Initialized
INFO - 2021-02-26 12:57:09 --> Router Class Initialized
INFO - 2021-02-26 12:57:09 --> Output Class Initialized
INFO - 2021-02-26 12:57:09 --> Security Class Initialized
DEBUG - 2021-02-26 12:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:57:09 --> Input Class Initialized
INFO - 2021-02-26 12:57:09 --> Language Class Initialized
INFO - 2021-02-26 12:57:09 --> Language Class Initialized
INFO - 2021-02-26 12:57:09 --> Config Class Initialized
INFO - 2021-02-26 12:57:10 --> Loader Class Initialized
INFO - 2021-02-26 12:57:10 --> Helper loaded: url_helper
INFO - 2021-02-26 12:57:10 --> Helper loaded: file_helper
INFO - 2021-02-26 12:57:10 --> Helper loaded: form_helper
INFO - 2021-02-26 12:57:10 --> Helper loaded: my_helper
INFO - 2021-02-26 12:57:10 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:57:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:57:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:57:10 --> Controller Class Initialized
DEBUG - 2021-02-26 12:57:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-02-26 12:57:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 12:57:10 --> Final output sent to browser
DEBUG - 2021-02-26 12:57:10 --> Total execution time: 1.0925
INFO - 2021-02-26 12:57:14 --> Config Class Initialized
INFO - 2021-02-26 12:57:14 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:57:14 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:57:14 --> Utf8 Class Initialized
INFO - 2021-02-26 12:57:14 --> URI Class Initialized
INFO - 2021-02-26 12:57:14 --> Router Class Initialized
INFO - 2021-02-26 12:57:14 --> Output Class Initialized
INFO - 2021-02-26 12:57:14 --> Security Class Initialized
DEBUG - 2021-02-26 12:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:57:14 --> Input Class Initialized
INFO - 2021-02-26 12:57:14 --> Language Class Initialized
INFO - 2021-02-26 12:57:14 --> Language Class Initialized
INFO - 2021-02-26 12:57:14 --> Config Class Initialized
INFO - 2021-02-26 12:57:14 --> Loader Class Initialized
INFO - 2021-02-26 12:57:14 --> Helper loaded: url_helper
INFO - 2021-02-26 12:57:15 --> Helper loaded: file_helper
INFO - 2021-02-26 12:57:15 --> Helper loaded: form_helper
INFO - 2021-02-26 12:57:15 --> Helper loaded: my_helper
INFO - 2021-02-26 12:57:15 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:57:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:57:15 --> Controller Class Initialized
DEBUG - 2021-02-26 12:57:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-02-26 12:57:15 --> Final output sent to browser
DEBUG - 2021-02-26 12:57:15 --> Total execution time: 0.9748
INFO - 2021-02-26 12:58:21 --> Config Class Initialized
INFO - 2021-02-26 12:58:21 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:58:21 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:58:21 --> Utf8 Class Initialized
INFO - 2021-02-26 12:58:21 --> URI Class Initialized
INFO - 2021-02-26 12:58:21 --> Router Class Initialized
INFO - 2021-02-26 12:58:21 --> Output Class Initialized
INFO - 2021-02-26 12:58:21 --> Security Class Initialized
DEBUG - 2021-02-26 12:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:58:21 --> Input Class Initialized
INFO - 2021-02-26 12:58:21 --> Language Class Initialized
INFO - 2021-02-26 12:58:21 --> Language Class Initialized
INFO - 2021-02-26 12:58:21 --> Config Class Initialized
INFO - 2021-02-26 12:58:21 --> Loader Class Initialized
INFO - 2021-02-26 12:58:21 --> Helper loaded: url_helper
INFO - 2021-02-26 12:58:21 --> Helper loaded: file_helper
INFO - 2021-02-26 12:58:21 --> Helper loaded: form_helper
INFO - 2021-02-26 12:58:21 --> Helper loaded: my_helper
INFO - 2021-02-26 12:58:22 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:58:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:58:22 --> Controller Class Initialized
DEBUG - 2021-02-26 12:58:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-02-26 12:58:22 --> Final output sent to browser
DEBUG - 2021-02-26 12:58:22 --> Total execution time: 0.9850
INFO - 2021-02-26 12:58:34 --> Config Class Initialized
INFO - 2021-02-26 12:58:34 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:58:34 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:58:34 --> Utf8 Class Initialized
INFO - 2021-02-26 12:58:34 --> URI Class Initialized
INFO - 2021-02-26 12:58:34 --> Router Class Initialized
INFO - 2021-02-26 12:58:34 --> Output Class Initialized
INFO - 2021-02-26 12:58:34 --> Security Class Initialized
DEBUG - 2021-02-26 12:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:58:34 --> Input Class Initialized
INFO - 2021-02-26 12:58:34 --> Language Class Initialized
INFO - 2021-02-26 12:58:34 --> Language Class Initialized
INFO - 2021-02-26 12:58:34 --> Config Class Initialized
INFO - 2021-02-26 12:58:34 --> Loader Class Initialized
INFO - 2021-02-26 12:58:34 --> Helper loaded: url_helper
INFO - 2021-02-26 12:58:35 --> Helper loaded: file_helper
INFO - 2021-02-26 12:58:35 --> Helper loaded: form_helper
INFO - 2021-02-26 12:58:35 --> Helper loaded: my_helper
INFO - 2021-02-26 12:58:35 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:58:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:58:35 --> Controller Class Initialized
DEBUG - 2021-02-26 12:58:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-02-26 12:58:35 --> Final output sent to browser
DEBUG - 2021-02-26 12:58:35 --> Total execution time: 1.3669
INFO - 2021-02-26 12:58:59 --> Config Class Initialized
INFO - 2021-02-26 12:58:59 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:58:59 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:58:59 --> Utf8 Class Initialized
INFO - 2021-02-26 12:58:59 --> URI Class Initialized
INFO - 2021-02-26 12:58:59 --> Router Class Initialized
INFO - 2021-02-26 12:58:59 --> Output Class Initialized
INFO - 2021-02-26 12:58:59 --> Security Class Initialized
DEBUG - 2021-02-26 12:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:58:59 --> Input Class Initialized
INFO - 2021-02-26 12:59:00 --> Language Class Initialized
INFO - 2021-02-26 12:59:00 --> Language Class Initialized
INFO - 2021-02-26 12:59:00 --> Config Class Initialized
INFO - 2021-02-26 12:59:00 --> Loader Class Initialized
INFO - 2021-02-26 12:59:00 --> Helper loaded: url_helper
INFO - 2021-02-26 12:59:00 --> Helper loaded: file_helper
INFO - 2021-02-26 12:59:00 --> Helper loaded: form_helper
INFO - 2021-02-26 12:59:00 --> Helper loaded: my_helper
INFO - 2021-02-26 12:59:00 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:59:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:59:00 --> Controller Class Initialized
DEBUG - 2021-02-26 12:59:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-02-26 12:59:00 --> Final output sent to browser
DEBUG - 2021-02-26 12:59:00 --> Total execution time: 1.3360
INFO - 2021-02-26 12:59:50 --> Config Class Initialized
INFO - 2021-02-26 12:59:50 --> Hooks Class Initialized
DEBUG - 2021-02-26 12:59:50 --> UTF-8 Support Enabled
INFO - 2021-02-26 12:59:50 --> Utf8 Class Initialized
INFO - 2021-02-26 12:59:50 --> URI Class Initialized
INFO - 2021-02-26 12:59:50 --> Router Class Initialized
INFO - 2021-02-26 12:59:50 --> Output Class Initialized
INFO - 2021-02-26 12:59:50 --> Security Class Initialized
DEBUG - 2021-02-26 12:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 12:59:50 --> Input Class Initialized
INFO - 2021-02-26 12:59:50 --> Language Class Initialized
INFO - 2021-02-26 12:59:50 --> Language Class Initialized
INFO - 2021-02-26 12:59:50 --> Config Class Initialized
INFO - 2021-02-26 12:59:50 --> Loader Class Initialized
INFO - 2021-02-26 12:59:50 --> Helper loaded: url_helper
INFO - 2021-02-26 12:59:50 --> Helper loaded: file_helper
INFO - 2021-02-26 12:59:51 --> Helper loaded: form_helper
INFO - 2021-02-26 12:59:51 --> Helper loaded: my_helper
INFO - 2021-02-26 12:59:51 --> Database Driver Class Initialized
DEBUG - 2021-02-26 12:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 12:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 12:59:51 --> Controller Class Initialized
DEBUG - 2021-02-26 12:59:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-02-26 12:59:51 --> Final output sent to browser
DEBUG - 2021-02-26 12:59:51 --> Total execution time: 0.9831
INFO - 2021-02-26 13:00:15 --> Config Class Initialized
INFO - 2021-02-26 13:00:15 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:00:15 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:00:15 --> Utf8 Class Initialized
INFO - 2021-02-26 13:00:15 --> URI Class Initialized
INFO - 2021-02-26 13:00:15 --> Router Class Initialized
INFO - 2021-02-26 13:00:15 --> Output Class Initialized
INFO - 2021-02-26 13:00:16 --> Security Class Initialized
DEBUG - 2021-02-26 13:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:00:16 --> Input Class Initialized
INFO - 2021-02-26 13:00:16 --> Language Class Initialized
INFO - 2021-02-26 13:00:16 --> Language Class Initialized
INFO - 2021-02-26 13:00:16 --> Config Class Initialized
INFO - 2021-02-26 13:00:16 --> Loader Class Initialized
INFO - 2021-02-26 13:00:16 --> Helper loaded: url_helper
INFO - 2021-02-26 13:00:16 --> Helper loaded: file_helper
INFO - 2021-02-26 13:00:16 --> Helper loaded: form_helper
INFO - 2021-02-26 13:00:16 --> Helper loaded: my_helper
INFO - 2021-02-26 13:00:16 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:00:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:00:16 --> Controller Class Initialized
INFO - 2021-02-26 13:00:16 --> Helper loaded: cookie_helper
INFO - 2021-02-26 13:00:16 --> Config Class Initialized
INFO - 2021-02-26 13:00:16 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:00:16 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:00:16 --> Utf8 Class Initialized
INFO - 2021-02-26 13:00:16 --> URI Class Initialized
INFO - 2021-02-26 13:00:16 --> Router Class Initialized
INFO - 2021-02-26 13:00:16 --> Output Class Initialized
INFO - 2021-02-26 13:00:16 --> Security Class Initialized
DEBUG - 2021-02-26 13:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:00:16 --> Input Class Initialized
INFO - 2021-02-26 13:00:17 --> Language Class Initialized
INFO - 2021-02-26 13:00:17 --> Language Class Initialized
INFO - 2021-02-26 13:00:17 --> Config Class Initialized
INFO - 2021-02-26 13:00:17 --> Loader Class Initialized
INFO - 2021-02-26 13:00:17 --> Helper loaded: url_helper
INFO - 2021-02-26 13:00:17 --> Helper loaded: file_helper
INFO - 2021-02-26 13:00:17 --> Helper loaded: form_helper
INFO - 2021-02-26 13:00:17 --> Helper loaded: my_helper
INFO - 2021-02-26 13:00:17 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:00:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:00:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:00:17 --> Controller Class Initialized
DEBUG - 2021-02-26 13:00:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-02-26 13:00:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 13:00:17 --> Final output sent to browser
DEBUG - 2021-02-26 13:00:17 --> Total execution time: 1.1475
INFO - 2021-02-26 13:00:28 --> Config Class Initialized
INFO - 2021-02-26 13:00:28 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:00:28 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:00:28 --> Utf8 Class Initialized
INFO - 2021-02-26 13:00:28 --> URI Class Initialized
INFO - 2021-02-26 13:00:28 --> Router Class Initialized
INFO - 2021-02-26 13:00:28 --> Output Class Initialized
INFO - 2021-02-26 13:00:28 --> Security Class Initialized
DEBUG - 2021-02-26 13:00:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:00:28 --> Input Class Initialized
INFO - 2021-02-26 13:00:28 --> Language Class Initialized
INFO - 2021-02-26 13:00:28 --> Language Class Initialized
INFO - 2021-02-26 13:00:28 --> Config Class Initialized
INFO - 2021-02-26 13:00:28 --> Loader Class Initialized
INFO - 2021-02-26 13:00:28 --> Helper loaded: url_helper
INFO - 2021-02-26 13:00:28 --> Helper loaded: file_helper
INFO - 2021-02-26 13:00:28 --> Helper loaded: form_helper
INFO - 2021-02-26 13:00:28 --> Helper loaded: my_helper
INFO - 2021-02-26 13:00:28 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:00:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:00:29 --> Controller Class Initialized
INFO - 2021-02-26 13:00:29 --> Helper loaded: cookie_helper
INFO - 2021-02-26 13:00:29 --> Final output sent to browser
DEBUG - 2021-02-26 13:00:29 --> Total execution time: 1.0282
INFO - 2021-02-26 13:00:29 --> Config Class Initialized
INFO - 2021-02-26 13:00:29 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:00:29 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:00:29 --> Utf8 Class Initialized
INFO - 2021-02-26 13:00:29 --> URI Class Initialized
INFO - 2021-02-26 13:00:30 --> Router Class Initialized
INFO - 2021-02-26 13:00:30 --> Output Class Initialized
INFO - 2021-02-26 13:00:30 --> Security Class Initialized
DEBUG - 2021-02-26 13:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:00:30 --> Input Class Initialized
INFO - 2021-02-26 13:00:30 --> Language Class Initialized
INFO - 2021-02-26 13:00:30 --> Language Class Initialized
INFO - 2021-02-26 13:00:30 --> Config Class Initialized
INFO - 2021-02-26 13:00:30 --> Loader Class Initialized
INFO - 2021-02-26 13:00:30 --> Helper loaded: url_helper
INFO - 2021-02-26 13:00:30 --> Helper loaded: file_helper
INFO - 2021-02-26 13:00:30 --> Helper loaded: form_helper
INFO - 2021-02-26 13:00:30 --> Helper loaded: my_helper
INFO - 2021-02-26 13:00:30 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:00:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:00:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:00:30 --> Controller Class Initialized
DEBUG - 2021-02-26 13:00:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-02-26 13:00:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 13:00:30 --> Final output sent to browser
DEBUG - 2021-02-26 13:00:30 --> Total execution time: 1.0553
INFO - 2021-02-26 13:00:59 --> Config Class Initialized
INFO - 2021-02-26 13:00:59 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:00:59 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:00:59 --> Utf8 Class Initialized
INFO - 2021-02-26 13:00:59 --> URI Class Initialized
INFO - 2021-02-26 13:00:59 --> Router Class Initialized
INFO - 2021-02-26 13:00:59 --> Output Class Initialized
INFO - 2021-02-26 13:00:59 --> Security Class Initialized
DEBUG - 2021-02-26 13:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:00:59 --> Input Class Initialized
INFO - 2021-02-26 13:01:00 --> Language Class Initialized
INFO - 2021-02-26 13:01:00 --> Language Class Initialized
INFO - 2021-02-26 13:01:00 --> Config Class Initialized
INFO - 2021-02-26 13:01:00 --> Loader Class Initialized
INFO - 2021-02-26 13:01:00 --> Helper loaded: url_helper
INFO - 2021-02-26 13:01:00 --> Helper loaded: file_helper
INFO - 2021-02-26 13:01:00 --> Helper loaded: form_helper
INFO - 2021-02-26 13:01:00 --> Helper loaded: my_helper
INFO - 2021-02-26 13:01:00 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:01:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:01:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:01:00 --> Controller Class Initialized
DEBUG - 2021-02-26 13:01:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-02-26 13:01:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 13:01:00 --> Final output sent to browser
DEBUG - 2021-02-26 13:01:00 --> Total execution time: 1.0152
INFO - 2021-02-26 13:01:09 --> Config Class Initialized
INFO - 2021-02-26 13:01:09 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:01:09 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:01:09 --> Utf8 Class Initialized
INFO - 2021-02-26 13:01:09 --> URI Class Initialized
INFO - 2021-02-26 13:01:09 --> Router Class Initialized
INFO - 2021-02-26 13:01:09 --> Output Class Initialized
INFO - 2021-02-26 13:01:09 --> Security Class Initialized
DEBUG - 2021-02-26 13:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:01:09 --> Input Class Initialized
INFO - 2021-02-26 13:01:09 --> Language Class Initialized
INFO - 2021-02-26 13:01:09 --> Language Class Initialized
INFO - 2021-02-26 13:01:09 --> Config Class Initialized
INFO - 2021-02-26 13:01:09 --> Loader Class Initialized
INFO - 2021-02-26 13:01:09 --> Helper loaded: url_helper
INFO - 2021-02-26 13:01:09 --> Helper loaded: file_helper
INFO - 2021-02-26 13:01:10 --> Helper loaded: form_helper
INFO - 2021-02-26 13:01:10 --> Helper loaded: my_helper
INFO - 2021-02-26 13:01:10 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:01:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:01:10 --> Controller Class Initialized
INFO - 2021-02-26 13:01:10 --> Final output sent to browser
DEBUG - 2021-02-26 13:01:10 --> Total execution time: 1.1119
INFO - 2021-02-26 13:01:13 --> Config Class Initialized
INFO - 2021-02-26 13:01:13 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:01:13 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:01:13 --> Utf8 Class Initialized
INFO - 2021-02-26 13:01:13 --> URI Class Initialized
INFO - 2021-02-26 13:01:14 --> Router Class Initialized
INFO - 2021-02-26 13:01:14 --> Output Class Initialized
INFO - 2021-02-26 13:01:14 --> Security Class Initialized
DEBUG - 2021-02-26 13:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:01:14 --> Input Class Initialized
INFO - 2021-02-26 13:01:14 --> Language Class Initialized
INFO - 2021-02-26 13:01:14 --> Language Class Initialized
INFO - 2021-02-26 13:01:14 --> Config Class Initialized
INFO - 2021-02-26 13:01:14 --> Loader Class Initialized
INFO - 2021-02-26 13:01:14 --> Helper loaded: url_helper
INFO - 2021-02-26 13:01:14 --> Helper loaded: file_helper
INFO - 2021-02-26 13:01:14 --> Helper loaded: form_helper
INFO - 2021-02-26 13:01:14 --> Helper loaded: my_helper
INFO - 2021-02-26 13:01:14 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:01:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:01:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:01:14 --> Controller Class Initialized
DEBUG - 2021-02-26 13:01:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-02-26 13:01:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 13:01:15 --> Final output sent to browser
DEBUG - 2021-02-26 13:01:15 --> Total execution time: 1.2154
INFO - 2021-02-26 13:01:19 --> Config Class Initialized
INFO - 2021-02-26 13:01:19 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:01:19 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:01:19 --> Utf8 Class Initialized
INFO - 2021-02-26 13:01:19 --> URI Class Initialized
INFO - 2021-02-26 13:01:19 --> Router Class Initialized
INFO - 2021-02-26 13:01:19 --> Output Class Initialized
INFO - 2021-02-26 13:01:19 --> Security Class Initialized
DEBUG - 2021-02-26 13:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:01:20 --> Input Class Initialized
INFO - 2021-02-26 13:01:20 --> Language Class Initialized
INFO - 2021-02-26 13:01:20 --> Language Class Initialized
INFO - 2021-02-26 13:01:20 --> Config Class Initialized
INFO - 2021-02-26 13:01:20 --> Loader Class Initialized
INFO - 2021-02-26 13:01:20 --> Helper loaded: url_helper
INFO - 2021-02-26 13:01:20 --> Helper loaded: file_helper
INFO - 2021-02-26 13:01:20 --> Helper loaded: form_helper
INFO - 2021-02-26 13:01:20 --> Helper loaded: my_helper
INFO - 2021-02-26 13:01:20 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:01:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:01:20 --> Controller Class Initialized
DEBUG - 2021-02-26 13:01:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-02-26 13:01:20 --> Final output sent to browser
DEBUG - 2021-02-26 13:01:20 --> Total execution time: 0.8918
INFO - 2021-02-26 13:07:11 --> Config Class Initialized
INFO - 2021-02-26 13:07:11 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:07:11 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:07:11 --> Utf8 Class Initialized
INFO - 2021-02-26 13:07:11 --> URI Class Initialized
INFO - 2021-02-26 13:07:12 --> Router Class Initialized
INFO - 2021-02-26 13:07:12 --> Output Class Initialized
INFO - 2021-02-26 13:07:12 --> Security Class Initialized
DEBUG - 2021-02-26 13:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:07:12 --> Input Class Initialized
INFO - 2021-02-26 13:07:12 --> Language Class Initialized
INFO - 2021-02-26 13:07:12 --> Language Class Initialized
INFO - 2021-02-26 13:07:12 --> Config Class Initialized
INFO - 2021-02-26 13:07:12 --> Loader Class Initialized
INFO - 2021-02-26 13:07:12 --> Helper loaded: url_helper
INFO - 2021-02-26 13:07:12 --> Helper loaded: file_helper
INFO - 2021-02-26 13:07:12 --> Helper loaded: form_helper
INFO - 2021-02-26 13:07:12 --> Helper loaded: my_helper
INFO - 2021-02-26 13:07:12 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:07:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:07:12 --> Controller Class Initialized
DEBUG - 2021-02-26 13:07:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-02-26 13:07:13 --> Final output sent to browser
DEBUG - 2021-02-26 13:07:13 --> Total execution time: 1.2304
INFO - 2021-02-26 13:07:30 --> Config Class Initialized
INFO - 2021-02-26 13:07:30 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:07:30 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:07:30 --> Utf8 Class Initialized
INFO - 2021-02-26 13:07:30 --> URI Class Initialized
INFO - 2021-02-26 13:07:30 --> Router Class Initialized
INFO - 2021-02-26 13:07:30 --> Output Class Initialized
INFO - 2021-02-26 13:07:31 --> Security Class Initialized
DEBUG - 2021-02-26 13:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:07:31 --> Input Class Initialized
INFO - 2021-02-26 13:07:31 --> Language Class Initialized
INFO - 2021-02-26 13:07:31 --> Language Class Initialized
INFO - 2021-02-26 13:07:31 --> Config Class Initialized
INFO - 2021-02-26 13:07:31 --> Loader Class Initialized
INFO - 2021-02-26 13:07:31 --> Helper loaded: url_helper
INFO - 2021-02-26 13:07:31 --> Helper loaded: file_helper
INFO - 2021-02-26 13:07:31 --> Helper loaded: form_helper
INFO - 2021-02-26 13:07:31 --> Helper loaded: my_helper
INFO - 2021-02-26 13:07:31 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:07:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:07:31 --> Controller Class Initialized
INFO - 2021-02-26 13:07:31 --> Helper loaded: cookie_helper
INFO - 2021-02-26 13:07:31 --> Config Class Initialized
INFO - 2021-02-26 13:07:31 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:07:31 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:07:31 --> Utf8 Class Initialized
INFO - 2021-02-26 13:07:31 --> URI Class Initialized
INFO - 2021-02-26 13:07:31 --> Router Class Initialized
INFO - 2021-02-26 13:07:31 --> Output Class Initialized
INFO - 2021-02-26 13:07:31 --> Security Class Initialized
DEBUG - 2021-02-26 13:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:07:31 --> Input Class Initialized
INFO - 2021-02-26 13:07:31 --> Language Class Initialized
INFO - 2021-02-26 13:07:31 --> Language Class Initialized
INFO - 2021-02-26 13:07:32 --> Config Class Initialized
INFO - 2021-02-26 13:07:32 --> Loader Class Initialized
INFO - 2021-02-26 13:07:32 --> Helper loaded: url_helper
INFO - 2021-02-26 13:07:32 --> Helper loaded: file_helper
INFO - 2021-02-26 13:07:32 --> Helper loaded: form_helper
INFO - 2021-02-26 13:07:32 --> Helper loaded: my_helper
INFO - 2021-02-26 13:07:32 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:07:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:07:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:07:32 --> Controller Class Initialized
DEBUG - 2021-02-26 13:07:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-02-26 13:07:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 13:07:32 --> Final output sent to browser
DEBUG - 2021-02-26 13:07:32 --> Total execution time: 1.0567
INFO - 2021-02-26 13:07:38 --> Config Class Initialized
INFO - 2021-02-26 13:07:38 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:07:38 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:07:38 --> Utf8 Class Initialized
INFO - 2021-02-26 13:07:38 --> URI Class Initialized
INFO - 2021-02-26 13:07:38 --> Router Class Initialized
INFO - 2021-02-26 13:07:38 --> Output Class Initialized
INFO - 2021-02-26 13:07:38 --> Security Class Initialized
DEBUG - 2021-02-26 13:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:07:38 --> Input Class Initialized
INFO - 2021-02-26 13:07:38 --> Language Class Initialized
INFO - 2021-02-26 13:07:38 --> Language Class Initialized
INFO - 2021-02-26 13:07:38 --> Config Class Initialized
INFO - 2021-02-26 13:07:38 --> Loader Class Initialized
INFO - 2021-02-26 13:07:38 --> Helper loaded: url_helper
INFO - 2021-02-26 13:07:38 --> Helper loaded: file_helper
INFO - 2021-02-26 13:07:38 --> Helper loaded: form_helper
INFO - 2021-02-26 13:07:38 --> Helper loaded: my_helper
INFO - 2021-02-26 13:07:38 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:07:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:07:39 --> Controller Class Initialized
INFO - 2021-02-26 13:07:39 --> Helper loaded: cookie_helper
INFO - 2021-02-26 13:07:39 --> Final output sent to browser
DEBUG - 2021-02-26 13:07:39 --> Total execution time: 1.0585
INFO - 2021-02-26 13:07:39 --> Config Class Initialized
INFO - 2021-02-26 13:07:39 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:07:39 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:07:39 --> Utf8 Class Initialized
INFO - 2021-02-26 13:07:39 --> URI Class Initialized
INFO - 2021-02-26 13:07:39 --> Router Class Initialized
INFO - 2021-02-26 13:07:39 --> Output Class Initialized
INFO - 2021-02-26 13:07:39 --> Security Class Initialized
DEBUG - 2021-02-26 13:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:07:40 --> Input Class Initialized
INFO - 2021-02-26 13:07:40 --> Language Class Initialized
INFO - 2021-02-26 13:07:40 --> Language Class Initialized
INFO - 2021-02-26 13:07:40 --> Config Class Initialized
INFO - 2021-02-26 13:07:40 --> Loader Class Initialized
INFO - 2021-02-26 13:07:40 --> Helper loaded: url_helper
INFO - 2021-02-26 13:07:40 --> Helper loaded: file_helper
INFO - 2021-02-26 13:07:40 --> Helper loaded: form_helper
INFO - 2021-02-26 13:07:40 --> Helper loaded: my_helper
INFO - 2021-02-26 13:07:40 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:07:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:07:40 --> Controller Class Initialized
DEBUG - 2021-02-26 13:07:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-02-26 13:07:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 13:07:40 --> Final output sent to browser
DEBUG - 2021-02-26 13:07:40 --> Total execution time: 1.1139
INFO - 2021-02-26 13:07:42 --> Config Class Initialized
INFO - 2021-02-26 13:07:42 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:07:42 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:07:42 --> Utf8 Class Initialized
INFO - 2021-02-26 13:07:42 --> URI Class Initialized
INFO - 2021-02-26 13:07:42 --> Router Class Initialized
INFO - 2021-02-26 13:07:42 --> Output Class Initialized
INFO - 2021-02-26 13:07:42 --> Security Class Initialized
DEBUG - 2021-02-26 13:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:07:42 --> Input Class Initialized
INFO - 2021-02-26 13:07:42 --> Language Class Initialized
INFO - 2021-02-26 13:07:42 --> Language Class Initialized
INFO - 2021-02-26 13:07:42 --> Config Class Initialized
INFO - 2021-02-26 13:07:42 --> Loader Class Initialized
INFO - 2021-02-26 13:07:42 --> Helper loaded: url_helper
INFO - 2021-02-26 13:07:42 --> Helper loaded: file_helper
INFO - 2021-02-26 13:07:42 --> Helper loaded: form_helper
INFO - 2021-02-26 13:07:42 --> Helper loaded: my_helper
INFO - 2021-02-26 13:07:42 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:07:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:07:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:07:42 --> Controller Class Initialized
DEBUG - 2021-02-26 13:07:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-02-26 13:07:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 13:07:43 --> Final output sent to browser
DEBUG - 2021-02-26 13:07:43 --> Total execution time: 1.0222
INFO - 2021-02-26 13:07:46 --> Config Class Initialized
INFO - 2021-02-26 13:07:46 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:07:46 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:07:46 --> Utf8 Class Initialized
INFO - 2021-02-26 13:07:46 --> URI Class Initialized
INFO - 2021-02-26 13:07:46 --> Router Class Initialized
INFO - 2021-02-26 13:07:46 --> Output Class Initialized
INFO - 2021-02-26 13:07:46 --> Security Class Initialized
DEBUG - 2021-02-26 13:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:07:46 --> Input Class Initialized
INFO - 2021-02-26 13:07:46 --> Language Class Initialized
INFO - 2021-02-26 13:07:46 --> Language Class Initialized
INFO - 2021-02-26 13:07:46 --> Config Class Initialized
INFO - 2021-02-26 13:07:46 --> Loader Class Initialized
INFO - 2021-02-26 13:07:46 --> Helper loaded: url_helper
INFO - 2021-02-26 13:07:46 --> Helper loaded: file_helper
INFO - 2021-02-26 13:07:46 --> Helper loaded: form_helper
INFO - 2021-02-26 13:07:46 --> Helper loaded: my_helper
INFO - 2021-02-26 13:07:47 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:07:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:07:47 --> Controller Class Initialized
DEBUG - 2021-02-26 13:07:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-02-26 13:07:47 --> Final output sent to browser
DEBUG - 2021-02-26 13:07:47 --> Total execution time: 1.2420
INFO - 2021-02-26 13:08:41 --> Config Class Initialized
INFO - 2021-02-26 13:08:41 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:08:41 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:08:42 --> Utf8 Class Initialized
INFO - 2021-02-26 13:08:42 --> URI Class Initialized
INFO - 2021-02-26 13:08:42 --> Router Class Initialized
INFO - 2021-02-26 13:08:42 --> Output Class Initialized
INFO - 2021-02-26 13:08:42 --> Security Class Initialized
DEBUG - 2021-02-26 13:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:08:42 --> Input Class Initialized
INFO - 2021-02-26 13:08:42 --> Language Class Initialized
INFO - 2021-02-26 13:08:42 --> Language Class Initialized
INFO - 2021-02-26 13:08:42 --> Config Class Initialized
INFO - 2021-02-26 13:08:42 --> Loader Class Initialized
INFO - 2021-02-26 13:08:42 --> Helper loaded: url_helper
INFO - 2021-02-26 13:08:42 --> Helper loaded: file_helper
INFO - 2021-02-26 13:08:42 --> Helper loaded: form_helper
INFO - 2021-02-26 13:08:42 --> Helper loaded: my_helper
INFO - 2021-02-26 13:08:42 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:08:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:08:42 --> Controller Class Initialized
DEBUG - 2021-02-26 13:08:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-02-26 13:08:43 --> Final output sent to browser
DEBUG - 2021-02-26 13:08:43 --> Total execution time: 1.2035
INFO - 2021-02-26 13:08:55 --> Config Class Initialized
INFO - 2021-02-26 13:08:55 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:08:55 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:08:55 --> Utf8 Class Initialized
INFO - 2021-02-26 13:08:55 --> URI Class Initialized
INFO - 2021-02-26 13:08:55 --> Router Class Initialized
INFO - 2021-02-26 13:08:55 --> Output Class Initialized
INFO - 2021-02-26 13:08:55 --> Security Class Initialized
DEBUG - 2021-02-26 13:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:08:55 --> Input Class Initialized
INFO - 2021-02-26 13:08:55 --> Language Class Initialized
INFO - 2021-02-26 13:08:55 --> Language Class Initialized
INFO - 2021-02-26 13:08:55 --> Config Class Initialized
INFO - 2021-02-26 13:08:56 --> Loader Class Initialized
INFO - 2021-02-26 13:08:56 --> Helper loaded: url_helper
INFO - 2021-02-26 13:08:56 --> Helper loaded: file_helper
INFO - 2021-02-26 13:08:56 --> Helper loaded: form_helper
INFO - 2021-02-26 13:08:56 --> Helper loaded: my_helper
INFO - 2021-02-26 13:08:56 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:08:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:08:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:08:56 --> Controller Class Initialized
DEBUG - 2021-02-26 13:08:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-02-26 13:08:56 --> Final output sent to browser
DEBUG - 2021-02-26 13:08:56 --> Total execution time: 1.2776
INFO - 2021-02-26 13:09:06 --> Config Class Initialized
INFO - 2021-02-26 13:09:06 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:09:07 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:09:07 --> Utf8 Class Initialized
INFO - 2021-02-26 13:09:07 --> URI Class Initialized
INFO - 2021-02-26 13:09:07 --> Router Class Initialized
INFO - 2021-02-26 13:09:07 --> Output Class Initialized
INFO - 2021-02-26 13:09:07 --> Security Class Initialized
DEBUG - 2021-02-26 13:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:09:07 --> Input Class Initialized
INFO - 2021-02-26 13:09:07 --> Language Class Initialized
INFO - 2021-02-26 13:09:07 --> Language Class Initialized
INFO - 2021-02-26 13:09:07 --> Config Class Initialized
INFO - 2021-02-26 13:09:07 --> Loader Class Initialized
INFO - 2021-02-26 13:09:07 --> Helper loaded: url_helper
INFO - 2021-02-26 13:09:07 --> Helper loaded: file_helper
INFO - 2021-02-26 13:09:07 --> Helper loaded: form_helper
INFO - 2021-02-26 13:09:07 --> Helper loaded: my_helper
INFO - 2021-02-26 13:09:07 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:09:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:09:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:09:08 --> Controller Class Initialized
DEBUG - 2021-02-26 13:09:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-02-26 13:09:08 --> Final output sent to browser
DEBUG - 2021-02-26 13:09:08 --> Total execution time: 1.4709
INFO - 2021-02-26 13:09:30 --> Config Class Initialized
INFO - 2021-02-26 13:09:30 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:09:30 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:09:30 --> Utf8 Class Initialized
INFO - 2021-02-26 13:09:30 --> URI Class Initialized
DEBUG - 2021-02-26 13:09:30 --> No URI present. Default controller set.
INFO - 2021-02-26 13:09:31 --> Router Class Initialized
INFO - 2021-02-26 13:09:31 --> Output Class Initialized
INFO - 2021-02-26 13:09:31 --> Security Class Initialized
DEBUG - 2021-02-26 13:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:09:31 --> Input Class Initialized
INFO - 2021-02-26 13:09:31 --> Language Class Initialized
INFO - 2021-02-26 13:09:31 --> Language Class Initialized
INFO - 2021-02-26 13:09:31 --> Config Class Initialized
INFO - 2021-02-26 13:09:31 --> Loader Class Initialized
INFO - 2021-02-26 13:09:31 --> Helper loaded: url_helper
INFO - 2021-02-26 13:09:31 --> Helper loaded: file_helper
INFO - 2021-02-26 13:09:31 --> Helper loaded: form_helper
INFO - 2021-02-26 13:09:31 --> Helper loaded: my_helper
INFO - 2021-02-26 13:09:31 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:09:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:09:31 --> Controller Class Initialized
DEBUG - 2021-02-26 13:09:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-02-26 13:09:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 13:09:32 --> Final output sent to browser
DEBUG - 2021-02-26 13:09:32 --> Total execution time: 1.2529
INFO - 2021-02-26 13:09:33 --> Config Class Initialized
INFO - 2021-02-26 13:09:33 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:09:33 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:09:33 --> Utf8 Class Initialized
INFO - 2021-02-26 13:09:33 --> URI Class Initialized
INFO - 2021-02-26 13:09:33 --> Router Class Initialized
INFO - 2021-02-26 13:09:33 --> Output Class Initialized
INFO - 2021-02-26 13:09:33 --> Security Class Initialized
DEBUG - 2021-02-26 13:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:09:33 --> Input Class Initialized
INFO - 2021-02-26 13:09:34 --> Language Class Initialized
INFO - 2021-02-26 13:09:34 --> Language Class Initialized
INFO - 2021-02-26 13:09:34 --> Config Class Initialized
INFO - 2021-02-26 13:09:34 --> Loader Class Initialized
INFO - 2021-02-26 13:09:34 --> Helper loaded: url_helper
INFO - 2021-02-26 13:09:34 --> Helper loaded: file_helper
INFO - 2021-02-26 13:09:34 --> Helper loaded: form_helper
INFO - 2021-02-26 13:09:34 --> Helper loaded: my_helper
INFO - 2021-02-26 13:09:34 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:09:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:09:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:09:34 --> Controller Class Initialized
INFO - 2021-02-26 13:09:34 --> Helper loaded: cookie_helper
INFO - 2021-02-26 13:09:34 --> Config Class Initialized
INFO - 2021-02-26 13:09:34 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:09:34 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:09:34 --> Utf8 Class Initialized
INFO - 2021-02-26 13:09:34 --> URI Class Initialized
INFO - 2021-02-26 13:09:34 --> Router Class Initialized
INFO - 2021-02-26 13:09:34 --> Output Class Initialized
INFO - 2021-02-26 13:09:34 --> Security Class Initialized
DEBUG - 2021-02-26 13:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:09:35 --> Input Class Initialized
INFO - 2021-02-26 13:09:35 --> Language Class Initialized
INFO - 2021-02-26 13:09:35 --> Language Class Initialized
INFO - 2021-02-26 13:09:35 --> Config Class Initialized
INFO - 2021-02-26 13:09:35 --> Loader Class Initialized
INFO - 2021-02-26 13:09:35 --> Helper loaded: url_helper
INFO - 2021-02-26 13:09:35 --> Helper loaded: file_helper
INFO - 2021-02-26 13:09:35 --> Helper loaded: form_helper
INFO - 2021-02-26 13:09:35 --> Helper loaded: my_helper
INFO - 2021-02-26 13:09:35 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:09:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:09:35 --> Controller Class Initialized
DEBUG - 2021-02-26 13:09:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-02-26 13:09:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 13:09:35 --> Final output sent to browser
DEBUG - 2021-02-26 13:09:35 --> Total execution time: 1.0280
INFO - 2021-02-26 13:09:39 --> Config Class Initialized
INFO - 2021-02-26 13:09:39 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:09:40 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:09:40 --> Utf8 Class Initialized
INFO - 2021-02-26 13:09:40 --> URI Class Initialized
INFO - 2021-02-26 13:09:40 --> Router Class Initialized
INFO - 2021-02-26 13:09:40 --> Output Class Initialized
INFO - 2021-02-26 13:09:40 --> Security Class Initialized
DEBUG - 2021-02-26 13:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:09:40 --> Input Class Initialized
INFO - 2021-02-26 13:09:40 --> Language Class Initialized
INFO - 2021-02-26 13:09:40 --> Language Class Initialized
INFO - 2021-02-26 13:09:40 --> Config Class Initialized
INFO - 2021-02-26 13:09:40 --> Loader Class Initialized
INFO - 2021-02-26 13:09:40 --> Helper loaded: url_helper
INFO - 2021-02-26 13:09:40 --> Helper loaded: file_helper
INFO - 2021-02-26 13:09:40 --> Helper loaded: form_helper
INFO - 2021-02-26 13:09:40 --> Helper loaded: my_helper
INFO - 2021-02-26 13:09:40 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:09:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:09:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:09:40 --> Controller Class Initialized
INFO - 2021-02-26 13:09:40 --> Helper loaded: cookie_helper
INFO - 2021-02-26 13:09:41 --> Final output sent to browser
DEBUG - 2021-02-26 13:09:41 --> Total execution time: 1.1150
INFO - 2021-02-26 13:09:41 --> Config Class Initialized
INFO - 2021-02-26 13:09:41 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:09:41 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:09:41 --> Utf8 Class Initialized
INFO - 2021-02-26 13:09:41 --> URI Class Initialized
INFO - 2021-02-26 13:09:41 --> Router Class Initialized
INFO - 2021-02-26 13:09:41 --> Output Class Initialized
INFO - 2021-02-26 13:09:41 --> Security Class Initialized
DEBUG - 2021-02-26 13:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:09:41 --> Input Class Initialized
INFO - 2021-02-26 13:09:41 --> Language Class Initialized
INFO - 2021-02-26 13:09:41 --> Language Class Initialized
INFO - 2021-02-26 13:09:42 --> Config Class Initialized
INFO - 2021-02-26 13:09:42 --> Loader Class Initialized
INFO - 2021-02-26 13:09:42 --> Helper loaded: url_helper
INFO - 2021-02-26 13:09:42 --> Helper loaded: file_helper
INFO - 2021-02-26 13:09:42 --> Helper loaded: form_helper
INFO - 2021-02-26 13:09:42 --> Helper loaded: my_helper
INFO - 2021-02-26 13:09:42 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:09:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:09:42 --> Controller Class Initialized
DEBUG - 2021-02-26 13:09:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-02-26 13:09:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 13:09:42 --> Final output sent to browser
DEBUG - 2021-02-26 13:09:42 --> Total execution time: 1.0655
INFO - 2021-02-26 13:09:57 --> Config Class Initialized
INFO - 2021-02-26 13:09:57 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:09:57 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:09:57 --> Utf8 Class Initialized
INFO - 2021-02-26 13:09:57 --> URI Class Initialized
INFO - 2021-02-26 13:09:57 --> Router Class Initialized
INFO - 2021-02-26 13:09:58 --> Output Class Initialized
INFO - 2021-02-26 13:09:58 --> Security Class Initialized
DEBUG - 2021-02-26 13:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:09:58 --> Input Class Initialized
INFO - 2021-02-26 13:09:58 --> Language Class Initialized
INFO - 2021-02-26 13:09:58 --> Language Class Initialized
INFO - 2021-02-26 13:09:58 --> Config Class Initialized
INFO - 2021-02-26 13:09:58 --> Loader Class Initialized
INFO - 2021-02-26 13:09:58 --> Helper loaded: url_helper
INFO - 2021-02-26 13:09:58 --> Helper loaded: file_helper
INFO - 2021-02-26 13:09:58 --> Helper loaded: form_helper
INFO - 2021-02-26 13:09:58 --> Helper loaded: my_helper
INFO - 2021-02-26 13:09:58 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:09:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:09:58 --> Controller Class Initialized
DEBUG - 2021-02-26 13:09:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-02-26 13:09:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 13:09:58 --> Final output sent to browser
DEBUG - 2021-02-26 13:09:58 --> Total execution time: 1.1585
INFO - 2021-02-26 13:10:01 --> Config Class Initialized
INFO - 2021-02-26 13:10:01 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:10:01 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:10:01 --> Utf8 Class Initialized
INFO - 2021-02-26 13:10:01 --> URI Class Initialized
INFO - 2021-02-26 13:10:01 --> Router Class Initialized
INFO - 2021-02-26 13:10:01 --> Output Class Initialized
INFO - 2021-02-26 13:10:01 --> Security Class Initialized
DEBUG - 2021-02-26 13:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:10:01 --> Input Class Initialized
INFO - 2021-02-26 13:10:01 --> Language Class Initialized
INFO - 2021-02-26 13:10:01 --> Language Class Initialized
INFO - 2021-02-26 13:10:01 --> Config Class Initialized
INFO - 2021-02-26 13:10:01 --> Loader Class Initialized
INFO - 2021-02-26 13:10:01 --> Helper loaded: url_helper
INFO - 2021-02-26 13:10:01 --> Helper loaded: file_helper
INFO - 2021-02-26 13:10:01 --> Helper loaded: form_helper
INFO - 2021-02-26 13:10:02 --> Helper loaded: my_helper
INFO - 2021-02-26 13:10:02 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:10:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:10:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:10:02 --> Controller Class Initialized
DEBUG - 2021-02-26 13:10:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-02-26 13:10:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 13:10:02 --> Final output sent to browser
DEBUG - 2021-02-26 13:10:02 --> Total execution time: 1.0717
INFO - 2021-02-26 13:10:04 --> Config Class Initialized
INFO - 2021-02-26 13:10:04 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:10:04 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:10:04 --> Utf8 Class Initialized
INFO - 2021-02-26 13:10:04 --> URI Class Initialized
INFO - 2021-02-26 13:10:05 --> Router Class Initialized
INFO - 2021-02-26 13:10:05 --> Output Class Initialized
INFO - 2021-02-26 13:10:05 --> Security Class Initialized
DEBUG - 2021-02-26 13:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:10:05 --> Input Class Initialized
INFO - 2021-02-26 13:10:05 --> Language Class Initialized
INFO - 2021-02-26 13:10:05 --> Language Class Initialized
INFO - 2021-02-26 13:10:05 --> Config Class Initialized
INFO - 2021-02-26 13:10:05 --> Loader Class Initialized
INFO - 2021-02-26 13:10:05 --> Helper loaded: url_helper
INFO - 2021-02-26 13:10:05 --> Helper loaded: file_helper
INFO - 2021-02-26 13:10:05 --> Helper loaded: form_helper
INFO - 2021-02-26 13:10:05 --> Helper loaded: my_helper
INFO - 2021-02-26 13:10:05 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:10:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:10:05 --> Controller Class Initialized
DEBUG - 2021-02-26 13:10:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-02-26 13:10:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 13:10:05 --> Final output sent to browser
DEBUG - 2021-02-26 13:10:05 --> Total execution time: 0.8015
INFO - 2021-02-26 13:10:08 --> Config Class Initialized
INFO - 2021-02-26 13:10:08 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:10:08 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:10:08 --> Utf8 Class Initialized
INFO - 2021-02-26 13:10:08 --> URI Class Initialized
INFO - 2021-02-26 13:10:08 --> Router Class Initialized
INFO - 2021-02-26 13:10:08 --> Output Class Initialized
INFO - 2021-02-26 13:10:08 --> Security Class Initialized
DEBUG - 2021-02-26 13:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:10:08 --> Input Class Initialized
INFO - 2021-02-26 13:10:08 --> Language Class Initialized
INFO - 2021-02-26 13:10:08 --> Language Class Initialized
INFO - 2021-02-26 13:10:08 --> Config Class Initialized
INFO - 2021-02-26 13:10:08 --> Loader Class Initialized
INFO - 2021-02-26 13:10:08 --> Helper loaded: url_helper
INFO - 2021-02-26 13:10:08 --> Helper loaded: file_helper
INFO - 2021-02-26 13:10:08 --> Helper loaded: form_helper
INFO - 2021-02-26 13:10:08 --> Helper loaded: my_helper
INFO - 2021-02-26 13:10:08 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:10:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:10:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:10:09 --> Controller Class Initialized
DEBUG - 2021-02-26 13:10:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-02-26 13:10:09 --> Final output sent to browser
DEBUG - 2021-02-26 13:10:09 --> Total execution time: 1.1648
INFO - 2021-02-26 13:11:04 --> Config Class Initialized
INFO - 2021-02-26 13:11:04 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:11:04 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:11:04 --> Utf8 Class Initialized
INFO - 2021-02-26 13:11:04 --> URI Class Initialized
INFO - 2021-02-26 13:11:04 --> Router Class Initialized
INFO - 2021-02-26 13:11:04 --> Output Class Initialized
INFO - 2021-02-26 13:11:04 --> Security Class Initialized
DEBUG - 2021-02-26 13:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:11:04 --> Input Class Initialized
INFO - 2021-02-26 13:11:04 --> Language Class Initialized
INFO - 2021-02-26 13:11:05 --> Language Class Initialized
INFO - 2021-02-26 13:11:05 --> Config Class Initialized
INFO - 2021-02-26 13:11:05 --> Loader Class Initialized
INFO - 2021-02-26 13:11:05 --> Helper loaded: url_helper
INFO - 2021-02-26 13:11:05 --> Helper loaded: file_helper
INFO - 2021-02-26 13:11:05 --> Helper loaded: form_helper
INFO - 2021-02-26 13:11:05 --> Helper loaded: my_helper
INFO - 2021-02-26 13:11:05 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:11:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:11:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:11:05 --> Controller Class Initialized
DEBUG - 2021-02-26 13:11:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-02-26 13:11:05 --> Final output sent to browser
DEBUG - 2021-02-26 13:11:05 --> Total execution time: 1.1789
INFO - 2021-02-26 13:11:19 --> Config Class Initialized
INFO - 2021-02-26 13:11:19 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:11:19 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:11:20 --> Utf8 Class Initialized
INFO - 2021-02-26 13:11:20 --> URI Class Initialized
INFO - 2021-02-26 13:11:20 --> Router Class Initialized
INFO - 2021-02-26 13:11:20 --> Output Class Initialized
INFO - 2021-02-26 13:11:20 --> Security Class Initialized
DEBUG - 2021-02-26 13:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:11:20 --> Input Class Initialized
INFO - 2021-02-26 13:11:20 --> Language Class Initialized
INFO - 2021-02-26 13:11:20 --> Language Class Initialized
INFO - 2021-02-26 13:11:20 --> Config Class Initialized
INFO - 2021-02-26 13:11:20 --> Loader Class Initialized
INFO - 2021-02-26 13:11:20 --> Helper loaded: url_helper
INFO - 2021-02-26 13:11:20 --> Helper loaded: file_helper
INFO - 2021-02-26 13:11:20 --> Helper loaded: form_helper
INFO - 2021-02-26 13:11:20 --> Helper loaded: my_helper
INFO - 2021-02-26 13:11:20 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:11:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:11:20 --> Controller Class Initialized
DEBUG - 2021-02-26 13:11:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-02-26 13:11:21 --> Final output sent to browser
DEBUG - 2021-02-26 13:11:21 --> Total execution time: 1.1726
INFO - 2021-02-26 13:12:07 --> Config Class Initialized
INFO - 2021-02-26 13:12:07 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:12:07 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:12:07 --> Utf8 Class Initialized
INFO - 2021-02-26 13:12:07 --> URI Class Initialized
INFO - 2021-02-26 13:12:07 --> Router Class Initialized
INFO - 2021-02-26 13:12:07 --> Output Class Initialized
INFO - 2021-02-26 13:12:07 --> Security Class Initialized
DEBUG - 2021-02-26 13:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:12:07 --> Input Class Initialized
INFO - 2021-02-26 13:12:07 --> Language Class Initialized
INFO - 2021-02-26 13:12:08 --> Language Class Initialized
INFO - 2021-02-26 13:12:08 --> Config Class Initialized
INFO - 2021-02-26 13:12:08 --> Loader Class Initialized
INFO - 2021-02-26 13:12:08 --> Helper loaded: url_helper
INFO - 2021-02-26 13:12:08 --> Helper loaded: file_helper
INFO - 2021-02-26 13:12:08 --> Helper loaded: form_helper
INFO - 2021-02-26 13:12:08 --> Helper loaded: my_helper
INFO - 2021-02-26 13:12:08 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:12:08 --> Controller Class Initialized
INFO - 2021-02-26 13:12:08 --> Helper loaded: cookie_helper
INFO - 2021-02-26 13:12:08 --> Config Class Initialized
INFO - 2021-02-26 13:12:08 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:12:08 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:12:08 --> Utf8 Class Initialized
INFO - 2021-02-26 13:12:08 --> URI Class Initialized
INFO - 2021-02-26 13:12:08 --> Router Class Initialized
INFO - 2021-02-26 13:12:08 --> Output Class Initialized
INFO - 2021-02-26 13:12:08 --> Security Class Initialized
DEBUG - 2021-02-26 13:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:12:08 --> Input Class Initialized
INFO - 2021-02-26 13:12:08 --> Language Class Initialized
INFO - 2021-02-26 13:12:09 --> Language Class Initialized
INFO - 2021-02-26 13:12:09 --> Config Class Initialized
INFO - 2021-02-26 13:12:09 --> Loader Class Initialized
INFO - 2021-02-26 13:12:09 --> Helper loaded: url_helper
INFO - 2021-02-26 13:12:09 --> Helper loaded: file_helper
INFO - 2021-02-26 13:12:09 --> Helper loaded: form_helper
INFO - 2021-02-26 13:12:09 --> Helper loaded: my_helper
INFO - 2021-02-26 13:12:09 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:12:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:12:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:12:09 --> Controller Class Initialized
DEBUG - 2021-02-26 13:12:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-02-26 13:12:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 13:12:09 --> Final output sent to browser
DEBUG - 2021-02-26 13:12:09 --> Total execution time: 1.1686
INFO - 2021-02-26 13:12:13 --> Config Class Initialized
INFO - 2021-02-26 13:12:13 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:12:14 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:12:14 --> Utf8 Class Initialized
INFO - 2021-02-26 13:12:14 --> URI Class Initialized
INFO - 2021-02-26 13:12:14 --> Router Class Initialized
INFO - 2021-02-26 13:12:14 --> Output Class Initialized
INFO - 2021-02-26 13:12:14 --> Security Class Initialized
DEBUG - 2021-02-26 13:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:12:14 --> Input Class Initialized
INFO - 2021-02-26 13:12:14 --> Language Class Initialized
INFO - 2021-02-26 13:12:14 --> Language Class Initialized
INFO - 2021-02-26 13:12:14 --> Config Class Initialized
INFO - 2021-02-26 13:12:14 --> Loader Class Initialized
INFO - 2021-02-26 13:12:14 --> Helper loaded: url_helper
INFO - 2021-02-26 13:12:14 --> Helper loaded: file_helper
INFO - 2021-02-26 13:12:14 --> Helper loaded: form_helper
INFO - 2021-02-26 13:12:14 --> Helper loaded: my_helper
INFO - 2021-02-26 13:12:14 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:12:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:12:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:12:14 --> Controller Class Initialized
INFO - 2021-02-26 13:12:14 --> Helper loaded: cookie_helper
INFO - 2021-02-26 13:12:14 --> Final output sent to browser
DEBUG - 2021-02-26 13:12:14 --> Total execution time: 0.9015
INFO - 2021-02-26 13:12:15 --> Config Class Initialized
INFO - 2021-02-26 13:12:15 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:12:15 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:12:15 --> Utf8 Class Initialized
INFO - 2021-02-26 13:12:15 --> URI Class Initialized
INFO - 2021-02-26 13:12:15 --> Router Class Initialized
INFO - 2021-02-26 13:12:15 --> Output Class Initialized
INFO - 2021-02-26 13:12:15 --> Security Class Initialized
DEBUG - 2021-02-26 13:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:12:15 --> Input Class Initialized
INFO - 2021-02-26 13:12:15 --> Language Class Initialized
INFO - 2021-02-26 13:12:15 --> Language Class Initialized
INFO - 2021-02-26 13:12:15 --> Config Class Initialized
INFO - 2021-02-26 13:12:15 --> Loader Class Initialized
INFO - 2021-02-26 13:12:15 --> Helper loaded: url_helper
INFO - 2021-02-26 13:12:15 --> Helper loaded: file_helper
INFO - 2021-02-26 13:12:15 --> Helper loaded: form_helper
INFO - 2021-02-26 13:12:16 --> Helper loaded: my_helper
INFO - 2021-02-26 13:12:16 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:12:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:12:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:12:16 --> Controller Class Initialized
DEBUG - 2021-02-26 13:12:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-02-26 13:12:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 13:12:16 --> Final output sent to browser
DEBUG - 2021-02-26 13:12:16 --> Total execution time: 1.1230
INFO - 2021-02-26 13:12:19 --> Config Class Initialized
INFO - 2021-02-26 13:12:19 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:12:19 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:12:19 --> Utf8 Class Initialized
INFO - 2021-02-26 13:12:19 --> URI Class Initialized
INFO - 2021-02-26 13:12:19 --> Router Class Initialized
INFO - 2021-02-26 13:12:19 --> Output Class Initialized
INFO - 2021-02-26 13:12:19 --> Security Class Initialized
DEBUG - 2021-02-26 13:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:12:19 --> Input Class Initialized
INFO - 2021-02-26 13:12:19 --> Language Class Initialized
INFO - 2021-02-26 13:12:19 --> Language Class Initialized
INFO - 2021-02-26 13:12:19 --> Config Class Initialized
INFO - 2021-02-26 13:12:19 --> Loader Class Initialized
INFO - 2021-02-26 13:12:19 --> Helper loaded: url_helper
INFO - 2021-02-26 13:12:19 --> Helper loaded: file_helper
INFO - 2021-02-26 13:12:19 --> Helper loaded: form_helper
INFO - 2021-02-26 13:12:19 --> Helper loaded: my_helper
INFO - 2021-02-26 13:12:20 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:12:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:12:20 --> Controller Class Initialized
DEBUG - 2021-02-26 13:12:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-02-26 13:12:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 13:12:20 --> Final output sent to browser
DEBUG - 2021-02-26 13:12:20 --> Total execution time: 1.0709
INFO - 2021-02-26 13:12:33 --> Config Class Initialized
INFO - 2021-02-26 13:12:33 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:12:33 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:12:33 --> Utf8 Class Initialized
INFO - 2021-02-26 13:12:33 --> URI Class Initialized
INFO - 2021-02-26 13:12:33 --> Router Class Initialized
INFO - 2021-02-26 13:12:33 --> Output Class Initialized
INFO - 2021-02-26 13:12:33 --> Security Class Initialized
DEBUG - 2021-02-26 13:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:12:34 --> Input Class Initialized
INFO - 2021-02-26 13:12:34 --> Language Class Initialized
INFO - 2021-02-26 13:12:34 --> Language Class Initialized
INFO - 2021-02-26 13:12:34 --> Config Class Initialized
INFO - 2021-02-26 13:12:34 --> Loader Class Initialized
INFO - 2021-02-26 13:12:34 --> Helper loaded: url_helper
INFO - 2021-02-26 13:12:34 --> Helper loaded: file_helper
INFO - 2021-02-26 13:12:34 --> Helper loaded: form_helper
INFO - 2021-02-26 13:12:34 --> Helper loaded: my_helper
INFO - 2021-02-26 13:12:34 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:12:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:12:34 --> Controller Class Initialized
INFO - 2021-02-26 13:12:34 --> Final output sent to browser
DEBUG - 2021-02-26 13:12:34 --> Total execution time: 1.0161
INFO - 2021-02-26 13:12:41 --> Config Class Initialized
INFO - 2021-02-26 13:12:41 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:12:41 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:12:41 --> Utf8 Class Initialized
INFO - 2021-02-26 13:12:41 --> URI Class Initialized
INFO - 2021-02-26 13:12:41 --> Router Class Initialized
INFO - 2021-02-26 13:12:41 --> Output Class Initialized
INFO - 2021-02-26 13:12:41 --> Security Class Initialized
DEBUG - 2021-02-26 13:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:12:41 --> Input Class Initialized
INFO - 2021-02-26 13:12:41 --> Language Class Initialized
INFO - 2021-02-26 13:12:41 --> Language Class Initialized
INFO - 2021-02-26 13:12:41 --> Config Class Initialized
INFO - 2021-02-26 13:12:41 --> Loader Class Initialized
INFO - 2021-02-26 13:12:42 --> Helper loaded: url_helper
INFO - 2021-02-26 13:12:42 --> Helper loaded: file_helper
INFO - 2021-02-26 13:12:42 --> Helper loaded: form_helper
INFO - 2021-02-26 13:12:42 --> Helper loaded: my_helper
INFO - 2021-02-26 13:12:42 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:12:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:12:42 --> Controller Class Initialized
DEBUG - 2021-02-26 13:12:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-02-26 13:12:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 13:12:42 --> Final output sent to browser
DEBUG - 2021-02-26 13:12:42 --> Total execution time: 1.0502
INFO - 2021-02-26 13:12:44 --> Config Class Initialized
INFO - 2021-02-26 13:12:44 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:12:44 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:12:44 --> Utf8 Class Initialized
INFO - 2021-02-26 13:12:44 --> URI Class Initialized
INFO - 2021-02-26 13:12:44 --> Router Class Initialized
INFO - 2021-02-26 13:12:44 --> Output Class Initialized
INFO - 2021-02-26 13:12:44 --> Security Class Initialized
DEBUG - 2021-02-26 13:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:12:44 --> Input Class Initialized
INFO - 2021-02-26 13:12:44 --> Language Class Initialized
INFO - 2021-02-26 13:12:44 --> Language Class Initialized
INFO - 2021-02-26 13:12:44 --> Config Class Initialized
INFO - 2021-02-26 13:12:45 --> Loader Class Initialized
INFO - 2021-02-26 13:12:45 --> Helper loaded: url_helper
INFO - 2021-02-26 13:12:45 --> Helper loaded: file_helper
INFO - 2021-02-26 13:12:45 --> Helper loaded: form_helper
INFO - 2021-02-26 13:12:45 --> Helper loaded: my_helper
INFO - 2021-02-26 13:12:45 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:12:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:12:45 --> Controller Class Initialized
DEBUG - 2021-02-26 13:12:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-02-26 13:12:45 --> Final output sent to browser
DEBUG - 2021-02-26 13:12:45 --> Total execution time: 0.8787
INFO - 2021-02-26 13:13:18 --> Config Class Initialized
INFO - 2021-02-26 13:13:18 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:13:18 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:13:18 --> Utf8 Class Initialized
INFO - 2021-02-26 13:13:18 --> URI Class Initialized
INFO - 2021-02-26 13:13:19 --> Router Class Initialized
INFO - 2021-02-26 13:13:19 --> Output Class Initialized
INFO - 2021-02-26 13:13:19 --> Security Class Initialized
DEBUG - 2021-02-26 13:13:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:13:19 --> Input Class Initialized
INFO - 2021-02-26 13:13:19 --> Language Class Initialized
INFO - 2021-02-26 13:13:19 --> Language Class Initialized
INFO - 2021-02-26 13:13:19 --> Config Class Initialized
INFO - 2021-02-26 13:13:19 --> Loader Class Initialized
INFO - 2021-02-26 13:13:19 --> Helper loaded: url_helper
INFO - 2021-02-26 13:13:19 --> Helper loaded: file_helper
INFO - 2021-02-26 13:13:19 --> Helper loaded: form_helper
INFO - 2021-02-26 13:13:19 --> Helper loaded: my_helper
INFO - 2021-02-26 13:13:19 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:13:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:13:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:13:19 --> Controller Class Initialized
DEBUG - 2021-02-26 13:13:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-02-26 13:13:20 --> Final output sent to browser
DEBUG - 2021-02-26 13:13:20 --> Total execution time: 1.2596
INFO - 2021-02-26 13:13:59 --> Config Class Initialized
INFO - 2021-02-26 13:13:59 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:13:59 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:13:59 --> Utf8 Class Initialized
INFO - 2021-02-26 13:13:59 --> URI Class Initialized
INFO - 2021-02-26 13:13:59 --> Router Class Initialized
INFO - 2021-02-26 13:13:59 --> Output Class Initialized
INFO - 2021-02-26 13:13:59 --> Security Class Initialized
DEBUG - 2021-02-26 13:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:13:59 --> Input Class Initialized
INFO - 2021-02-26 13:13:59 --> Language Class Initialized
INFO - 2021-02-26 13:13:59 --> Language Class Initialized
INFO - 2021-02-26 13:13:59 --> Config Class Initialized
INFO - 2021-02-26 13:13:59 --> Loader Class Initialized
INFO - 2021-02-26 13:13:59 --> Helper loaded: url_helper
INFO - 2021-02-26 13:13:59 --> Helper loaded: file_helper
INFO - 2021-02-26 13:13:59 --> Helper loaded: form_helper
INFO - 2021-02-26 13:13:59 --> Helper loaded: my_helper
INFO - 2021-02-26 13:14:00 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:14:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:14:00 --> Controller Class Initialized
DEBUG - 2021-02-26 13:14:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-02-26 13:14:00 --> Final output sent to browser
DEBUG - 2021-02-26 13:14:00 --> Total execution time: 1.3161
INFO - 2021-02-26 13:14:19 --> Config Class Initialized
INFO - 2021-02-26 13:14:19 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:14:19 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:14:19 --> Utf8 Class Initialized
INFO - 2021-02-26 13:14:19 --> URI Class Initialized
INFO - 2021-02-26 13:14:19 --> Router Class Initialized
INFO - 2021-02-26 13:14:19 --> Output Class Initialized
INFO - 2021-02-26 13:14:19 --> Security Class Initialized
DEBUG - 2021-02-26 13:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:14:19 --> Input Class Initialized
INFO - 2021-02-26 13:14:19 --> Language Class Initialized
INFO - 2021-02-26 13:14:19 --> Language Class Initialized
INFO - 2021-02-26 13:14:19 --> Config Class Initialized
INFO - 2021-02-26 13:14:19 --> Loader Class Initialized
INFO - 2021-02-26 13:14:19 --> Helper loaded: url_helper
INFO - 2021-02-26 13:14:19 --> Helper loaded: file_helper
INFO - 2021-02-26 13:14:19 --> Helper loaded: form_helper
INFO - 2021-02-26 13:14:19 --> Helper loaded: my_helper
INFO - 2021-02-26 13:14:19 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:14:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:14:20 --> Controller Class Initialized
DEBUG - 2021-02-26 13:14:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-02-26 13:14:20 --> Final output sent to browser
DEBUG - 2021-02-26 13:14:20 --> Total execution time: 1.2891
INFO - 2021-02-26 13:14:31 --> Config Class Initialized
INFO - 2021-02-26 13:14:31 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:14:31 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:14:31 --> Utf8 Class Initialized
INFO - 2021-02-26 13:14:31 --> URI Class Initialized
INFO - 2021-02-26 13:14:31 --> Router Class Initialized
INFO - 2021-02-26 13:14:31 --> Output Class Initialized
INFO - 2021-02-26 13:14:31 --> Security Class Initialized
DEBUG - 2021-02-26 13:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:14:31 --> Input Class Initialized
INFO - 2021-02-26 13:14:31 --> Language Class Initialized
INFO - 2021-02-26 13:14:31 --> Language Class Initialized
INFO - 2021-02-26 13:14:31 --> Config Class Initialized
INFO - 2021-02-26 13:14:31 --> Loader Class Initialized
INFO - 2021-02-26 13:14:31 --> Helper loaded: url_helper
INFO - 2021-02-26 13:14:31 --> Helper loaded: file_helper
INFO - 2021-02-26 13:14:31 --> Helper loaded: form_helper
INFO - 2021-02-26 13:14:32 --> Helper loaded: my_helper
INFO - 2021-02-26 13:14:32 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:14:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:14:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:14:32 --> Controller Class Initialized
DEBUG - 2021-02-26 13:14:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-02-26 13:14:32 --> Final output sent to browser
DEBUG - 2021-02-26 13:14:32 --> Total execution time: 1.1232
INFO - 2021-02-26 13:15:09 --> Config Class Initialized
INFO - 2021-02-26 13:15:09 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:15:09 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:15:09 --> Utf8 Class Initialized
INFO - 2021-02-26 13:15:09 --> URI Class Initialized
INFO - 2021-02-26 13:15:09 --> Router Class Initialized
INFO - 2021-02-26 13:15:09 --> Output Class Initialized
INFO - 2021-02-26 13:15:09 --> Security Class Initialized
DEBUG - 2021-02-26 13:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:15:09 --> Input Class Initialized
INFO - 2021-02-26 13:15:10 --> Language Class Initialized
INFO - 2021-02-26 13:15:10 --> Language Class Initialized
INFO - 2021-02-26 13:15:10 --> Config Class Initialized
INFO - 2021-02-26 13:15:10 --> Loader Class Initialized
INFO - 2021-02-26 13:15:10 --> Helper loaded: url_helper
INFO - 2021-02-26 13:15:10 --> Helper loaded: file_helper
INFO - 2021-02-26 13:15:10 --> Helper loaded: form_helper
INFO - 2021-02-26 13:15:10 --> Helper loaded: my_helper
INFO - 2021-02-26 13:15:10 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:15:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:15:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:15:10 --> Controller Class Initialized
DEBUG - 2021-02-26 13:15:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-02-26 13:15:10 --> Final output sent to browser
DEBUG - 2021-02-26 13:15:10 --> Total execution time: 1.4096
INFO - 2021-02-26 13:15:35 --> Config Class Initialized
INFO - 2021-02-26 13:15:35 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:15:35 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:15:35 --> Utf8 Class Initialized
INFO - 2021-02-26 13:15:35 --> URI Class Initialized
INFO - 2021-02-26 13:15:35 --> Router Class Initialized
INFO - 2021-02-26 13:15:35 --> Output Class Initialized
INFO - 2021-02-26 13:15:35 --> Security Class Initialized
DEBUG - 2021-02-26 13:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:15:35 --> Input Class Initialized
INFO - 2021-02-26 13:15:35 --> Language Class Initialized
INFO - 2021-02-26 13:15:36 --> Language Class Initialized
INFO - 2021-02-26 13:15:36 --> Config Class Initialized
INFO - 2021-02-26 13:15:36 --> Loader Class Initialized
INFO - 2021-02-26 13:15:36 --> Helper loaded: url_helper
INFO - 2021-02-26 13:15:36 --> Helper loaded: file_helper
INFO - 2021-02-26 13:15:36 --> Helper loaded: form_helper
INFO - 2021-02-26 13:15:36 --> Helper loaded: my_helper
INFO - 2021-02-26 13:15:36 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:15:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:15:36 --> Controller Class Initialized
DEBUG - 2021-02-26 13:15:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-02-26 13:15:36 --> Final output sent to browser
DEBUG - 2021-02-26 13:15:36 --> Total execution time: 1.3034
INFO - 2021-02-26 13:16:10 --> Config Class Initialized
INFO - 2021-02-26 13:16:10 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:16:10 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:16:10 --> Utf8 Class Initialized
INFO - 2021-02-26 13:16:10 --> URI Class Initialized
INFO - 2021-02-26 13:16:10 --> Router Class Initialized
INFO - 2021-02-26 13:16:10 --> Output Class Initialized
INFO - 2021-02-26 13:16:10 --> Security Class Initialized
DEBUG - 2021-02-26 13:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:16:10 --> Input Class Initialized
INFO - 2021-02-26 13:16:10 --> Language Class Initialized
INFO - 2021-02-26 13:16:10 --> Language Class Initialized
INFO - 2021-02-26 13:16:10 --> Config Class Initialized
INFO - 2021-02-26 13:16:10 --> Loader Class Initialized
INFO - 2021-02-26 13:16:10 --> Helper loaded: url_helper
INFO - 2021-02-26 13:16:10 --> Helper loaded: file_helper
INFO - 2021-02-26 13:16:10 --> Helper loaded: form_helper
INFO - 2021-02-26 13:16:10 --> Helper loaded: my_helper
INFO - 2021-02-26 13:16:11 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:16:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:16:11 --> Controller Class Initialized
INFO - 2021-02-26 13:16:11 --> Helper loaded: cookie_helper
INFO - 2021-02-26 13:16:11 --> Config Class Initialized
INFO - 2021-02-26 13:16:11 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:16:11 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:16:11 --> Utf8 Class Initialized
INFO - 2021-02-26 13:16:11 --> URI Class Initialized
INFO - 2021-02-26 13:16:11 --> Router Class Initialized
INFO - 2021-02-26 13:16:11 --> Output Class Initialized
INFO - 2021-02-26 13:16:11 --> Security Class Initialized
DEBUG - 2021-02-26 13:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:16:11 --> Input Class Initialized
INFO - 2021-02-26 13:16:11 --> Language Class Initialized
INFO - 2021-02-26 13:16:11 --> Language Class Initialized
INFO - 2021-02-26 13:16:11 --> Config Class Initialized
INFO - 2021-02-26 13:16:11 --> Loader Class Initialized
INFO - 2021-02-26 13:16:11 --> Helper loaded: url_helper
INFO - 2021-02-26 13:16:11 --> Helper loaded: file_helper
INFO - 2021-02-26 13:16:12 --> Helper loaded: form_helper
INFO - 2021-02-26 13:16:12 --> Helper loaded: my_helper
INFO - 2021-02-26 13:16:12 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:16:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:16:12 --> Controller Class Initialized
DEBUG - 2021-02-26 13:16:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-02-26 13:16:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 13:16:12 --> Final output sent to browser
DEBUG - 2021-02-26 13:16:12 --> Total execution time: 1.2005
INFO - 2021-02-26 13:16:17 --> Config Class Initialized
INFO - 2021-02-26 13:16:17 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:16:17 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:16:17 --> Utf8 Class Initialized
INFO - 2021-02-26 13:16:17 --> URI Class Initialized
INFO - 2021-02-26 13:16:17 --> Router Class Initialized
INFO - 2021-02-26 13:16:17 --> Output Class Initialized
INFO - 2021-02-26 13:16:17 --> Security Class Initialized
DEBUG - 2021-02-26 13:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:16:17 --> Input Class Initialized
INFO - 2021-02-26 13:16:17 --> Language Class Initialized
INFO - 2021-02-26 13:16:17 --> Language Class Initialized
INFO - 2021-02-26 13:16:17 --> Config Class Initialized
INFO - 2021-02-26 13:16:17 --> Loader Class Initialized
INFO - 2021-02-26 13:16:17 --> Helper loaded: url_helper
INFO - 2021-02-26 13:16:17 --> Helper loaded: file_helper
INFO - 2021-02-26 13:16:17 --> Helper loaded: form_helper
INFO - 2021-02-26 13:16:17 --> Helper loaded: my_helper
INFO - 2021-02-26 13:16:17 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:16:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:16:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:16:18 --> Controller Class Initialized
INFO - 2021-02-26 13:16:18 --> Helper loaded: cookie_helper
INFO - 2021-02-26 13:16:18 --> Final output sent to browser
DEBUG - 2021-02-26 13:16:18 --> Total execution time: 0.8519
INFO - 2021-02-26 13:16:18 --> Config Class Initialized
INFO - 2021-02-26 13:16:18 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:16:18 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:16:18 --> Utf8 Class Initialized
INFO - 2021-02-26 13:16:18 --> URI Class Initialized
INFO - 2021-02-26 13:16:19 --> Router Class Initialized
INFO - 2021-02-26 13:16:19 --> Output Class Initialized
INFO - 2021-02-26 13:16:19 --> Security Class Initialized
DEBUG - 2021-02-26 13:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:16:19 --> Input Class Initialized
INFO - 2021-02-26 13:16:19 --> Language Class Initialized
INFO - 2021-02-26 13:16:19 --> Language Class Initialized
INFO - 2021-02-26 13:16:19 --> Config Class Initialized
INFO - 2021-02-26 13:16:19 --> Loader Class Initialized
INFO - 2021-02-26 13:16:19 --> Helper loaded: url_helper
INFO - 2021-02-26 13:16:19 --> Helper loaded: file_helper
INFO - 2021-02-26 13:16:19 --> Helper loaded: form_helper
INFO - 2021-02-26 13:16:19 --> Helper loaded: my_helper
INFO - 2021-02-26 13:16:19 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:16:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:16:19 --> Controller Class Initialized
DEBUG - 2021-02-26 13:16:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-02-26 13:16:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 13:16:19 --> Final output sent to browser
DEBUG - 2021-02-26 13:16:19 --> Total execution time: 1.0106
INFO - 2021-02-26 13:16:22 --> Config Class Initialized
INFO - 2021-02-26 13:16:22 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:16:22 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:16:22 --> Utf8 Class Initialized
INFO - 2021-02-26 13:16:22 --> URI Class Initialized
INFO - 2021-02-26 13:16:22 --> Router Class Initialized
INFO - 2021-02-26 13:16:22 --> Output Class Initialized
INFO - 2021-02-26 13:16:22 --> Security Class Initialized
DEBUG - 2021-02-26 13:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:16:22 --> Input Class Initialized
INFO - 2021-02-26 13:16:22 --> Language Class Initialized
INFO - 2021-02-26 13:16:22 --> Language Class Initialized
INFO - 2021-02-26 13:16:22 --> Config Class Initialized
INFO - 2021-02-26 13:16:22 --> Loader Class Initialized
INFO - 2021-02-26 13:16:23 --> Helper loaded: url_helper
INFO - 2021-02-26 13:16:23 --> Helper loaded: file_helper
INFO - 2021-02-26 13:16:23 --> Helper loaded: form_helper
INFO - 2021-02-26 13:16:23 --> Helper loaded: my_helper
INFO - 2021-02-26 13:16:23 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:16:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:16:23 --> Controller Class Initialized
DEBUG - 2021-02-26 13:16:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-02-26 13:16:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 13:16:23 --> Final output sent to browser
DEBUG - 2021-02-26 13:16:23 --> Total execution time: 0.9866
INFO - 2021-02-26 13:16:38 --> Config Class Initialized
INFO - 2021-02-26 13:16:38 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:16:38 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:16:38 --> Utf8 Class Initialized
INFO - 2021-02-26 13:16:38 --> URI Class Initialized
INFO - 2021-02-26 13:16:38 --> Router Class Initialized
INFO - 2021-02-26 13:16:38 --> Output Class Initialized
INFO - 2021-02-26 13:16:38 --> Security Class Initialized
DEBUG - 2021-02-26 13:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:16:38 --> Input Class Initialized
INFO - 2021-02-26 13:16:38 --> Language Class Initialized
INFO - 2021-02-26 13:16:38 --> Language Class Initialized
INFO - 2021-02-26 13:16:38 --> Config Class Initialized
INFO - 2021-02-26 13:16:38 --> Loader Class Initialized
INFO - 2021-02-26 13:16:39 --> Helper loaded: url_helper
INFO - 2021-02-26 13:16:39 --> Helper loaded: file_helper
INFO - 2021-02-26 13:16:39 --> Helper loaded: form_helper
INFO - 2021-02-26 13:16:39 --> Helper loaded: my_helper
INFO - 2021-02-26 13:16:39 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:16:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:16:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:16:39 --> Controller Class Initialized
INFO - 2021-02-26 13:16:39 --> Final output sent to browser
DEBUG - 2021-02-26 13:16:39 --> Total execution time: 1.1635
INFO - 2021-02-26 13:16:47 --> Config Class Initialized
INFO - 2021-02-26 13:16:47 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:16:47 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:16:47 --> Utf8 Class Initialized
INFO - 2021-02-26 13:16:47 --> URI Class Initialized
INFO - 2021-02-26 13:16:47 --> Router Class Initialized
INFO - 2021-02-26 13:16:47 --> Output Class Initialized
INFO - 2021-02-26 13:16:47 --> Security Class Initialized
DEBUG - 2021-02-26 13:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:16:47 --> Input Class Initialized
INFO - 2021-02-26 13:16:47 --> Language Class Initialized
INFO - 2021-02-26 13:16:47 --> Language Class Initialized
INFO - 2021-02-26 13:16:47 --> Config Class Initialized
INFO - 2021-02-26 13:16:47 --> Loader Class Initialized
INFO - 2021-02-26 13:16:48 --> Helper loaded: url_helper
INFO - 2021-02-26 13:16:48 --> Helper loaded: file_helper
INFO - 2021-02-26 13:16:48 --> Helper loaded: form_helper
INFO - 2021-02-26 13:16:48 --> Helper loaded: my_helper
INFO - 2021-02-26 13:16:48 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:16:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:16:48 --> Controller Class Initialized
DEBUG - 2021-02-26 13:16:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-02-26 13:16:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 13:16:48 --> Final output sent to browser
DEBUG - 2021-02-26 13:16:48 --> Total execution time: 1.0260
INFO - 2021-02-26 13:16:51 --> Config Class Initialized
INFO - 2021-02-26 13:16:51 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:16:51 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:16:51 --> Utf8 Class Initialized
INFO - 2021-02-26 13:16:51 --> URI Class Initialized
INFO - 2021-02-26 13:16:51 --> Router Class Initialized
INFO - 2021-02-26 13:16:51 --> Output Class Initialized
INFO - 2021-02-26 13:16:51 --> Security Class Initialized
DEBUG - 2021-02-26 13:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:16:51 --> Input Class Initialized
INFO - 2021-02-26 13:16:51 --> Language Class Initialized
INFO - 2021-02-26 13:16:51 --> Language Class Initialized
INFO - 2021-02-26 13:16:51 --> Config Class Initialized
INFO - 2021-02-26 13:16:51 --> Loader Class Initialized
INFO - 2021-02-26 13:16:51 --> Helper loaded: url_helper
INFO - 2021-02-26 13:16:51 --> Helper loaded: file_helper
INFO - 2021-02-26 13:16:51 --> Helper loaded: form_helper
INFO - 2021-02-26 13:16:51 --> Helper loaded: my_helper
INFO - 2021-02-26 13:16:52 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:16:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:16:52 --> Controller Class Initialized
DEBUG - 2021-02-26 13:16:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-02-26 13:16:52 --> Final output sent to browser
DEBUG - 2021-02-26 13:16:52 --> Total execution time: 1.2080
INFO - 2021-02-26 13:17:19 --> Config Class Initialized
INFO - 2021-02-26 13:17:20 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:17:20 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:17:20 --> Utf8 Class Initialized
INFO - 2021-02-26 13:17:20 --> URI Class Initialized
INFO - 2021-02-26 13:17:20 --> Router Class Initialized
INFO - 2021-02-26 13:17:20 --> Output Class Initialized
INFO - 2021-02-26 13:17:20 --> Security Class Initialized
DEBUG - 2021-02-26 13:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:17:20 --> Input Class Initialized
INFO - 2021-02-26 13:17:20 --> Language Class Initialized
INFO - 2021-02-26 13:17:20 --> Language Class Initialized
INFO - 2021-02-26 13:17:20 --> Config Class Initialized
INFO - 2021-02-26 13:17:20 --> Loader Class Initialized
INFO - 2021-02-26 13:17:20 --> Helper loaded: url_helper
INFO - 2021-02-26 13:17:20 --> Helper loaded: file_helper
INFO - 2021-02-26 13:17:20 --> Helper loaded: form_helper
INFO - 2021-02-26 13:17:20 --> Helper loaded: my_helper
INFO - 2021-02-26 13:17:20 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:17:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:17:21 --> Controller Class Initialized
DEBUG - 2021-02-26 13:17:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-02-26 13:17:21 --> Final output sent to browser
DEBUG - 2021-02-26 13:17:21 --> Total execution time: 1.3389
INFO - 2021-02-26 13:17:41 --> Config Class Initialized
INFO - 2021-02-26 13:17:41 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:17:41 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:17:41 --> Utf8 Class Initialized
INFO - 2021-02-26 13:17:41 --> URI Class Initialized
INFO - 2021-02-26 13:17:41 --> Router Class Initialized
INFO - 2021-02-26 13:17:41 --> Output Class Initialized
INFO - 2021-02-26 13:17:41 --> Security Class Initialized
DEBUG - 2021-02-26 13:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:17:41 --> Input Class Initialized
INFO - 2021-02-26 13:17:42 --> Language Class Initialized
INFO - 2021-02-26 13:17:42 --> Language Class Initialized
INFO - 2021-02-26 13:17:42 --> Config Class Initialized
INFO - 2021-02-26 13:17:42 --> Loader Class Initialized
INFO - 2021-02-26 13:17:42 --> Helper loaded: url_helper
INFO - 2021-02-26 13:17:42 --> Helper loaded: file_helper
INFO - 2021-02-26 13:17:42 --> Helper loaded: form_helper
INFO - 2021-02-26 13:17:42 --> Helper loaded: my_helper
INFO - 2021-02-26 13:17:42 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:17:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:17:42 --> Controller Class Initialized
DEBUG - 2021-02-26 13:17:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-02-26 13:17:42 --> Final output sent to browser
DEBUG - 2021-02-26 13:17:42 --> Total execution time: 1.0856
INFO - 2021-02-26 13:18:04 --> Config Class Initialized
INFO - 2021-02-26 13:18:04 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:18:04 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:18:04 --> Utf8 Class Initialized
INFO - 2021-02-26 13:18:04 --> URI Class Initialized
INFO - 2021-02-26 13:18:04 --> Router Class Initialized
INFO - 2021-02-26 13:18:04 --> Output Class Initialized
INFO - 2021-02-26 13:18:04 --> Security Class Initialized
DEBUG - 2021-02-26 13:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:18:04 --> Input Class Initialized
INFO - 2021-02-26 13:18:04 --> Language Class Initialized
INFO - 2021-02-26 13:18:04 --> Language Class Initialized
INFO - 2021-02-26 13:18:04 --> Config Class Initialized
INFO - 2021-02-26 13:18:04 --> Loader Class Initialized
INFO - 2021-02-26 13:18:04 --> Helper loaded: url_helper
INFO - 2021-02-26 13:18:05 --> Helper loaded: file_helper
INFO - 2021-02-26 13:18:05 --> Helper loaded: form_helper
INFO - 2021-02-26 13:18:05 --> Helper loaded: my_helper
INFO - 2021-02-26 13:18:05 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:18:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:18:05 --> Controller Class Initialized
DEBUG - 2021-02-26 13:18:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-02-26 13:18:05 --> Final output sent to browser
DEBUG - 2021-02-26 13:18:05 --> Total execution time: 1.3220
INFO - 2021-02-26 13:18:20 --> Config Class Initialized
INFO - 2021-02-26 13:18:20 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:18:20 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:18:20 --> Utf8 Class Initialized
INFO - 2021-02-26 13:18:20 --> URI Class Initialized
INFO - 2021-02-26 13:18:20 --> Router Class Initialized
INFO - 2021-02-26 13:18:21 --> Output Class Initialized
INFO - 2021-02-26 13:18:21 --> Security Class Initialized
DEBUG - 2021-02-26 13:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:18:21 --> Input Class Initialized
INFO - 2021-02-26 13:18:21 --> Language Class Initialized
INFO - 2021-02-26 13:18:21 --> Language Class Initialized
INFO - 2021-02-26 13:18:21 --> Config Class Initialized
INFO - 2021-02-26 13:18:21 --> Loader Class Initialized
INFO - 2021-02-26 13:18:21 --> Helper loaded: url_helper
INFO - 2021-02-26 13:18:21 --> Helper loaded: file_helper
INFO - 2021-02-26 13:18:21 --> Helper loaded: form_helper
INFO - 2021-02-26 13:18:21 --> Helper loaded: my_helper
INFO - 2021-02-26 13:18:21 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:18:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:18:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:18:21 --> Controller Class Initialized
DEBUG - 2021-02-26 13:18:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-02-26 13:18:22 --> Final output sent to browser
DEBUG - 2021-02-26 13:18:22 --> Total execution time: 1.3300
INFO - 2021-02-26 13:18:37 --> Config Class Initialized
INFO - 2021-02-26 13:18:37 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:18:37 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:18:37 --> Utf8 Class Initialized
INFO - 2021-02-26 13:18:37 --> URI Class Initialized
INFO - 2021-02-26 13:18:37 --> Router Class Initialized
INFO - 2021-02-26 13:18:38 --> Output Class Initialized
INFO - 2021-02-26 13:18:38 --> Security Class Initialized
DEBUG - 2021-02-26 13:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:18:38 --> Input Class Initialized
INFO - 2021-02-26 13:18:38 --> Language Class Initialized
INFO - 2021-02-26 13:18:38 --> Language Class Initialized
INFO - 2021-02-26 13:18:38 --> Config Class Initialized
INFO - 2021-02-26 13:18:38 --> Loader Class Initialized
INFO - 2021-02-26 13:18:38 --> Helper loaded: url_helper
INFO - 2021-02-26 13:18:38 --> Helper loaded: file_helper
INFO - 2021-02-26 13:18:38 --> Helper loaded: form_helper
INFO - 2021-02-26 13:18:38 --> Helper loaded: my_helper
INFO - 2021-02-26 13:18:38 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:18:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:18:38 --> Controller Class Initialized
DEBUG - 2021-02-26 13:18:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-02-26 13:18:38 --> Final output sent to browser
DEBUG - 2021-02-26 13:18:39 --> Total execution time: 1.2341
INFO - 2021-02-26 13:19:30 --> Config Class Initialized
INFO - 2021-02-26 13:19:30 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:19:30 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:19:30 --> Utf8 Class Initialized
INFO - 2021-02-26 13:19:30 --> URI Class Initialized
INFO - 2021-02-26 13:19:30 --> Router Class Initialized
INFO - 2021-02-26 13:19:30 --> Output Class Initialized
INFO - 2021-02-26 13:19:30 --> Security Class Initialized
DEBUG - 2021-02-26 13:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:19:30 --> Input Class Initialized
INFO - 2021-02-26 13:19:30 --> Language Class Initialized
INFO - 2021-02-26 13:19:30 --> Language Class Initialized
INFO - 2021-02-26 13:19:30 --> Config Class Initialized
INFO - 2021-02-26 13:19:30 --> Loader Class Initialized
INFO - 2021-02-26 13:19:30 --> Helper loaded: url_helper
INFO - 2021-02-26 13:19:30 --> Helper loaded: file_helper
INFO - 2021-02-26 13:19:30 --> Helper loaded: form_helper
INFO - 2021-02-26 13:19:30 --> Helper loaded: my_helper
INFO - 2021-02-26 13:19:30 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:19:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:19:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:19:31 --> Controller Class Initialized
DEBUG - 2021-02-26 13:19:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-02-26 13:19:31 --> Final output sent to browser
DEBUG - 2021-02-26 13:19:31 --> Total execution time: 1.3426
INFO - 2021-02-26 13:19:51 --> Config Class Initialized
INFO - 2021-02-26 13:19:51 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:19:51 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:19:51 --> Utf8 Class Initialized
INFO - 2021-02-26 13:19:51 --> URI Class Initialized
INFO - 2021-02-26 13:19:51 --> Router Class Initialized
INFO - 2021-02-26 13:19:51 --> Output Class Initialized
INFO - 2021-02-26 13:19:51 --> Security Class Initialized
DEBUG - 2021-02-26 13:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:19:52 --> Input Class Initialized
INFO - 2021-02-26 13:19:52 --> Language Class Initialized
INFO - 2021-02-26 13:19:52 --> Language Class Initialized
INFO - 2021-02-26 13:19:52 --> Config Class Initialized
INFO - 2021-02-26 13:19:52 --> Loader Class Initialized
INFO - 2021-02-26 13:19:52 --> Helper loaded: url_helper
INFO - 2021-02-26 13:19:52 --> Helper loaded: file_helper
INFO - 2021-02-26 13:19:52 --> Helper loaded: form_helper
INFO - 2021-02-26 13:19:52 --> Helper loaded: my_helper
INFO - 2021-02-26 13:19:52 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:19:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:19:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:19:52 --> Controller Class Initialized
DEBUG - 2021-02-26 13:19:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-02-26 13:19:52 --> Final output sent to browser
DEBUG - 2021-02-26 13:19:52 --> Total execution time: 1.1082
INFO - 2021-02-26 13:20:06 --> Config Class Initialized
INFO - 2021-02-26 13:20:06 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:20:06 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:20:06 --> Utf8 Class Initialized
INFO - 2021-02-26 13:20:06 --> URI Class Initialized
INFO - 2021-02-26 13:20:06 --> Router Class Initialized
INFO - 2021-02-26 13:20:06 --> Output Class Initialized
INFO - 2021-02-26 13:20:06 --> Security Class Initialized
DEBUG - 2021-02-26 13:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:20:06 --> Input Class Initialized
INFO - 2021-02-26 13:20:06 --> Language Class Initialized
INFO - 2021-02-26 13:20:06 --> Language Class Initialized
INFO - 2021-02-26 13:20:06 --> Config Class Initialized
INFO - 2021-02-26 13:20:06 --> Loader Class Initialized
INFO - 2021-02-26 13:20:06 --> Helper loaded: url_helper
INFO - 2021-02-26 13:20:06 --> Helper loaded: file_helper
INFO - 2021-02-26 13:20:06 --> Helper loaded: form_helper
INFO - 2021-02-26 13:20:06 --> Helper loaded: my_helper
INFO - 2021-02-26 13:20:06 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:20:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:20:06 --> Controller Class Initialized
INFO - 2021-02-26 13:20:06 --> Helper loaded: cookie_helper
INFO - 2021-02-26 13:20:07 --> Config Class Initialized
INFO - 2021-02-26 13:20:07 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:20:07 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:20:07 --> Utf8 Class Initialized
INFO - 2021-02-26 13:20:07 --> URI Class Initialized
INFO - 2021-02-26 13:20:07 --> Router Class Initialized
INFO - 2021-02-26 13:20:07 --> Output Class Initialized
INFO - 2021-02-26 13:20:07 --> Security Class Initialized
DEBUG - 2021-02-26 13:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:20:07 --> Input Class Initialized
INFO - 2021-02-26 13:20:07 --> Language Class Initialized
INFO - 2021-02-26 13:20:07 --> Language Class Initialized
INFO - 2021-02-26 13:20:07 --> Config Class Initialized
INFO - 2021-02-26 13:20:07 --> Loader Class Initialized
INFO - 2021-02-26 13:20:07 --> Helper loaded: url_helper
INFO - 2021-02-26 13:20:07 --> Helper loaded: file_helper
INFO - 2021-02-26 13:20:07 --> Helper loaded: form_helper
INFO - 2021-02-26 13:20:07 --> Helper loaded: my_helper
INFO - 2021-02-26 13:20:07 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:20:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:20:07 --> Controller Class Initialized
DEBUG - 2021-02-26 13:20:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-02-26 13:20:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 13:20:08 --> Final output sent to browser
DEBUG - 2021-02-26 13:20:08 --> Total execution time: 1.0258
INFO - 2021-02-26 13:20:17 --> Config Class Initialized
INFO - 2021-02-26 13:20:17 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:20:17 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:20:17 --> Utf8 Class Initialized
INFO - 2021-02-26 13:20:17 --> URI Class Initialized
INFO - 2021-02-26 13:20:17 --> Router Class Initialized
INFO - 2021-02-26 13:20:17 --> Output Class Initialized
INFO - 2021-02-26 13:20:17 --> Security Class Initialized
DEBUG - 2021-02-26 13:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:20:17 --> Input Class Initialized
INFO - 2021-02-26 13:20:17 --> Language Class Initialized
INFO - 2021-02-26 13:20:17 --> Language Class Initialized
INFO - 2021-02-26 13:20:17 --> Config Class Initialized
INFO - 2021-02-26 13:20:17 --> Loader Class Initialized
INFO - 2021-02-26 13:20:18 --> Helper loaded: url_helper
INFO - 2021-02-26 13:20:18 --> Helper loaded: file_helper
INFO - 2021-02-26 13:20:18 --> Helper loaded: form_helper
INFO - 2021-02-26 13:20:18 --> Helper loaded: my_helper
INFO - 2021-02-26 13:20:18 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:20:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:20:18 --> Controller Class Initialized
INFO - 2021-02-26 13:20:18 --> Helper loaded: cookie_helper
INFO - 2021-02-26 13:20:18 --> Final output sent to browser
DEBUG - 2021-02-26 13:20:18 --> Total execution time: 1.0412
INFO - 2021-02-26 13:20:19 --> Config Class Initialized
INFO - 2021-02-26 13:20:19 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:20:19 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:20:19 --> Utf8 Class Initialized
INFO - 2021-02-26 13:20:19 --> URI Class Initialized
INFO - 2021-02-26 13:20:19 --> Router Class Initialized
INFO - 2021-02-26 13:20:19 --> Output Class Initialized
INFO - 2021-02-26 13:20:19 --> Security Class Initialized
DEBUG - 2021-02-26 13:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:20:19 --> Input Class Initialized
INFO - 2021-02-26 13:20:19 --> Language Class Initialized
INFO - 2021-02-26 13:20:19 --> Language Class Initialized
INFO - 2021-02-26 13:20:19 --> Config Class Initialized
INFO - 2021-02-26 13:20:19 --> Loader Class Initialized
INFO - 2021-02-26 13:20:19 --> Helper loaded: url_helper
INFO - 2021-02-26 13:20:19 --> Helper loaded: file_helper
INFO - 2021-02-26 13:20:19 --> Helper loaded: form_helper
INFO - 2021-02-26 13:20:19 --> Helper loaded: my_helper
INFO - 2021-02-26 13:20:19 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:20:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:20:19 --> Controller Class Initialized
DEBUG - 2021-02-26 13:20:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-02-26 13:20:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 13:20:20 --> Final output sent to browser
DEBUG - 2021-02-26 13:20:20 --> Total execution time: 1.1341
INFO - 2021-02-26 13:20:23 --> Config Class Initialized
INFO - 2021-02-26 13:20:23 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:20:23 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:20:23 --> Utf8 Class Initialized
INFO - 2021-02-26 13:20:23 --> URI Class Initialized
INFO - 2021-02-26 13:20:23 --> Router Class Initialized
INFO - 2021-02-26 13:20:24 --> Output Class Initialized
INFO - 2021-02-26 13:20:24 --> Security Class Initialized
DEBUG - 2021-02-26 13:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:20:24 --> Input Class Initialized
INFO - 2021-02-26 13:20:24 --> Language Class Initialized
INFO - 2021-02-26 13:20:24 --> Language Class Initialized
INFO - 2021-02-26 13:20:24 --> Config Class Initialized
INFO - 2021-02-26 13:20:24 --> Loader Class Initialized
INFO - 2021-02-26 13:20:24 --> Helper loaded: url_helper
INFO - 2021-02-26 13:20:24 --> Helper loaded: file_helper
INFO - 2021-02-26 13:20:24 --> Helper loaded: form_helper
INFO - 2021-02-26 13:20:24 --> Helper loaded: my_helper
INFO - 2021-02-26 13:20:24 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:20:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:20:24 --> Controller Class Initialized
DEBUG - 2021-02-26 13:20:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-02-26 13:20:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 13:20:24 --> Final output sent to browser
DEBUG - 2021-02-26 13:20:25 --> Total execution time: 1.1858
INFO - 2021-02-26 13:20:51 --> Config Class Initialized
INFO - 2021-02-26 13:20:51 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:20:51 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:20:51 --> Utf8 Class Initialized
INFO - 2021-02-26 13:20:51 --> URI Class Initialized
INFO - 2021-02-26 13:20:51 --> Router Class Initialized
INFO - 2021-02-26 13:20:52 --> Output Class Initialized
INFO - 2021-02-26 13:20:52 --> Security Class Initialized
DEBUG - 2021-02-26 13:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:20:52 --> Input Class Initialized
INFO - 2021-02-26 13:20:52 --> Language Class Initialized
INFO - 2021-02-26 13:20:52 --> Language Class Initialized
INFO - 2021-02-26 13:20:52 --> Config Class Initialized
INFO - 2021-02-26 13:20:52 --> Loader Class Initialized
INFO - 2021-02-26 13:20:52 --> Helper loaded: url_helper
INFO - 2021-02-26 13:20:52 --> Helper loaded: file_helper
INFO - 2021-02-26 13:20:52 --> Helper loaded: form_helper
INFO - 2021-02-26 13:20:52 --> Helper loaded: my_helper
INFO - 2021-02-26 13:20:52 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:20:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:20:52 --> Controller Class Initialized
INFO - 2021-02-26 13:20:52 --> Final output sent to browser
DEBUG - 2021-02-26 13:20:52 --> Total execution time: 0.9346
INFO - 2021-02-26 13:21:01 --> Config Class Initialized
INFO - 2021-02-26 13:21:01 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:21:01 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:21:01 --> Utf8 Class Initialized
INFO - 2021-02-26 13:21:01 --> URI Class Initialized
INFO - 2021-02-26 13:21:01 --> Router Class Initialized
INFO - 2021-02-26 13:21:01 --> Output Class Initialized
INFO - 2021-02-26 13:21:01 --> Security Class Initialized
DEBUG - 2021-02-26 13:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:21:01 --> Input Class Initialized
INFO - 2021-02-26 13:21:01 --> Language Class Initialized
INFO - 2021-02-26 13:21:02 --> Language Class Initialized
INFO - 2021-02-26 13:21:02 --> Config Class Initialized
INFO - 2021-02-26 13:21:02 --> Loader Class Initialized
INFO - 2021-02-26 13:21:02 --> Helper loaded: url_helper
INFO - 2021-02-26 13:21:02 --> Helper loaded: file_helper
INFO - 2021-02-26 13:21:02 --> Helper loaded: form_helper
INFO - 2021-02-26 13:21:02 --> Helper loaded: my_helper
INFO - 2021-02-26 13:21:02 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:21:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:21:02 --> Controller Class Initialized
DEBUG - 2021-02-26 13:21:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-02-26 13:21:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 13:21:02 --> Final output sent to browser
DEBUG - 2021-02-26 13:21:02 --> Total execution time: 1.0432
INFO - 2021-02-26 13:21:04 --> Config Class Initialized
INFO - 2021-02-26 13:21:04 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:21:04 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:21:04 --> Utf8 Class Initialized
INFO - 2021-02-26 13:21:04 --> URI Class Initialized
INFO - 2021-02-26 13:21:04 --> Router Class Initialized
INFO - 2021-02-26 13:21:04 --> Output Class Initialized
INFO - 2021-02-26 13:21:04 --> Security Class Initialized
DEBUG - 2021-02-26 13:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:21:04 --> Input Class Initialized
INFO - 2021-02-26 13:21:04 --> Language Class Initialized
INFO - 2021-02-26 13:21:04 --> Language Class Initialized
INFO - 2021-02-26 13:21:04 --> Config Class Initialized
INFO - 2021-02-26 13:21:04 --> Loader Class Initialized
INFO - 2021-02-26 13:21:04 --> Helper loaded: url_helper
INFO - 2021-02-26 13:21:04 --> Helper loaded: file_helper
INFO - 2021-02-26 13:21:04 --> Helper loaded: form_helper
INFO - 2021-02-26 13:21:05 --> Helper loaded: my_helper
INFO - 2021-02-26 13:21:05 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:21:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:21:05 --> Controller Class Initialized
DEBUG - 2021-02-26 13:21:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-02-26 13:21:05 --> Final output sent to browser
DEBUG - 2021-02-26 13:21:05 --> Total execution time: 0.9955
INFO - 2021-02-26 13:22:04 --> Config Class Initialized
INFO - 2021-02-26 13:22:04 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:22:04 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:22:04 --> Utf8 Class Initialized
INFO - 2021-02-26 13:22:04 --> URI Class Initialized
INFO - 2021-02-26 13:22:05 --> Router Class Initialized
INFO - 2021-02-26 13:22:05 --> Output Class Initialized
INFO - 2021-02-26 13:22:05 --> Security Class Initialized
DEBUG - 2021-02-26 13:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:22:05 --> Input Class Initialized
INFO - 2021-02-26 13:22:05 --> Language Class Initialized
INFO - 2021-02-26 13:22:05 --> Language Class Initialized
INFO - 2021-02-26 13:22:05 --> Config Class Initialized
INFO - 2021-02-26 13:22:05 --> Loader Class Initialized
INFO - 2021-02-26 13:22:05 --> Helper loaded: url_helper
INFO - 2021-02-26 13:22:05 --> Helper loaded: file_helper
INFO - 2021-02-26 13:22:05 --> Helper loaded: form_helper
INFO - 2021-02-26 13:22:05 --> Helper loaded: my_helper
INFO - 2021-02-26 13:22:05 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:22:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:22:05 --> Controller Class Initialized
DEBUG - 2021-02-26 13:22:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-02-26 13:22:06 --> Final output sent to browser
DEBUG - 2021-02-26 13:22:06 --> Total execution time: 1.2803
INFO - 2021-02-26 13:23:10 --> Config Class Initialized
INFO - 2021-02-26 13:23:10 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:23:10 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:23:10 --> Utf8 Class Initialized
INFO - 2021-02-26 13:23:10 --> URI Class Initialized
INFO - 2021-02-26 13:23:10 --> Router Class Initialized
INFO - 2021-02-26 13:23:10 --> Output Class Initialized
INFO - 2021-02-26 13:23:10 --> Security Class Initialized
DEBUG - 2021-02-26 13:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:23:10 --> Input Class Initialized
INFO - 2021-02-26 13:23:10 --> Language Class Initialized
INFO - 2021-02-26 13:23:10 --> Language Class Initialized
INFO - 2021-02-26 13:23:10 --> Config Class Initialized
INFO - 2021-02-26 13:23:10 --> Loader Class Initialized
INFO - 2021-02-26 13:23:10 --> Helper loaded: url_helper
INFO - 2021-02-26 13:23:11 --> Helper loaded: file_helper
INFO - 2021-02-26 13:23:11 --> Helper loaded: form_helper
INFO - 2021-02-26 13:23:11 --> Helper loaded: my_helper
INFO - 2021-02-26 13:23:11 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:23:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:23:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:23:11 --> Controller Class Initialized
DEBUG - 2021-02-26 13:23:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-02-26 13:23:11 --> Final output sent to browser
DEBUG - 2021-02-26 13:23:11 --> Total execution time: 1.2367
INFO - 2021-02-26 13:23:23 --> Config Class Initialized
INFO - 2021-02-26 13:23:23 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:23:23 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:23:23 --> Utf8 Class Initialized
INFO - 2021-02-26 13:23:23 --> URI Class Initialized
INFO - 2021-02-26 13:23:23 --> Router Class Initialized
INFO - 2021-02-26 13:23:23 --> Output Class Initialized
INFO - 2021-02-26 13:23:23 --> Security Class Initialized
DEBUG - 2021-02-26 13:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:23:23 --> Input Class Initialized
INFO - 2021-02-26 13:23:23 --> Language Class Initialized
INFO - 2021-02-26 13:23:23 --> Language Class Initialized
INFO - 2021-02-26 13:23:23 --> Config Class Initialized
INFO - 2021-02-26 13:23:23 --> Loader Class Initialized
INFO - 2021-02-26 13:23:23 --> Helper loaded: url_helper
INFO - 2021-02-26 13:23:23 --> Helper loaded: file_helper
INFO - 2021-02-26 13:23:23 --> Helper loaded: form_helper
INFO - 2021-02-26 13:23:23 --> Helper loaded: my_helper
INFO - 2021-02-26 13:23:23 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:23:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:23:24 --> Controller Class Initialized
DEBUG - 2021-02-26 13:23:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-02-26 13:23:24 --> Final output sent to browser
DEBUG - 2021-02-26 13:23:24 --> Total execution time: 1.3241
INFO - 2021-02-26 13:23:35 --> Config Class Initialized
INFO - 2021-02-26 13:23:35 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:23:35 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:23:35 --> Utf8 Class Initialized
INFO - 2021-02-26 13:23:35 --> URI Class Initialized
INFO - 2021-02-26 13:23:35 --> Router Class Initialized
INFO - 2021-02-26 13:23:35 --> Output Class Initialized
INFO - 2021-02-26 13:23:35 --> Security Class Initialized
DEBUG - 2021-02-26 13:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:23:35 --> Input Class Initialized
INFO - 2021-02-26 13:23:35 --> Language Class Initialized
INFO - 2021-02-26 13:23:35 --> Language Class Initialized
INFO - 2021-02-26 13:23:35 --> Config Class Initialized
INFO - 2021-02-26 13:23:35 --> Loader Class Initialized
INFO - 2021-02-26 13:23:36 --> Helper loaded: url_helper
INFO - 2021-02-26 13:23:36 --> Helper loaded: file_helper
INFO - 2021-02-26 13:23:36 --> Helper loaded: form_helper
INFO - 2021-02-26 13:23:36 --> Helper loaded: my_helper
INFO - 2021-02-26 13:23:36 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:23:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:23:36 --> Controller Class Initialized
DEBUG - 2021-02-26 13:23:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-02-26 13:23:36 --> Final output sent to browser
DEBUG - 2021-02-26 13:23:36 --> Total execution time: 1.3386
INFO - 2021-02-26 13:25:00 --> Config Class Initialized
INFO - 2021-02-26 13:25:00 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:25:00 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:25:00 --> Utf8 Class Initialized
INFO - 2021-02-26 13:25:01 --> URI Class Initialized
INFO - 2021-02-26 13:25:01 --> Router Class Initialized
INFO - 2021-02-26 13:25:01 --> Output Class Initialized
INFO - 2021-02-26 13:25:01 --> Security Class Initialized
DEBUG - 2021-02-26 13:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:25:01 --> Input Class Initialized
INFO - 2021-02-26 13:25:01 --> Language Class Initialized
INFO - 2021-02-26 13:25:01 --> Language Class Initialized
INFO - 2021-02-26 13:25:01 --> Config Class Initialized
INFO - 2021-02-26 13:25:01 --> Loader Class Initialized
INFO - 2021-02-26 13:25:01 --> Helper loaded: url_helper
INFO - 2021-02-26 13:25:01 --> Helper loaded: file_helper
INFO - 2021-02-26 13:25:01 --> Helper loaded: form_helper
INFO - 2021-02-26 13:25:01 --> Helper loaded: my_helper
INFO - 2021-02-26 13:25:01 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:25:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:25:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:25:01 --> Controller Class Initialized
DEBUG - 2021-02-26 13:25:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-02-26 13:25:02 --> Final output sent to browser
DEBUG - 2021-02-26 13:25:02 --> Total execution time: 1.1857
INFO - 2021-02-26 13:25:15 --> Config Class Initialized
INFO - 2021-02-26 13:25:15 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:25:15 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:25:15 --> Utf8 Class Initialized
INFO - 2021-02-26 13:25:15 --> URI Class Initialized
INFO - 2021-02-26 13:25:15 --> Router Class Initialized
INFO - 2021-02-26 13:25:15 --> Output Class Initialized
INFO - 2021-02-26 13:25:15 --> Security Class Initialized
DEBUG - 2021-02-26 13:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:25:15 --> Input Class Initialized
INFO - 2021-02-26 13:25:15 --> Language Class Initialized
INFO - 2021-02-26 13:25:15 --> Language Class Initialized
INFO - 2021-02-26 13:25:15 --> Config Class Initialized
INFO - 2021-02-26 13:25:15 --> Loader Class Initialized
INFO - 2021-02-26 13:25:15 --> Helper loaded: url_helper
INFO - 2021-02-26 13:25:15 --> Helper loaded: file_helper
INFO - 2021-02-26 13:25:15 --> Helper loaded: form_helper
INFO - 2021-02-26 13:25:16 --> Helper loaded: my_helper
INFO - 2021-02-26 13:25:16 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:25:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:25:16 --> Controller Class Initialized
DEBUG - 2021-02-26 13:25:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-02-26 13:25:16 --> Final output sent to browser
DEBUG - 2021-02-26 13:25:16 --> Total execution time: 1.2775
INFO - 2021-02-26 13:25:34 --> Config Class Initialized
INFO - 2021-02-26 13:25:34 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:25:34 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:25:34 --> Utf8 Class Initialized
INFO - 2021-02-26 13:25:34 --> URI Class Initialized
INFO - 2021-02-26 13:25:34 --> Router Class Initialized
INFO - 2021-02-26 13:25:34 --> Output Class Initialized
INFO - 2021-02-26 13:25:34 --> Security Class Initialized
DEBUG - 2021-02-26 13:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:25:34 --> Input Class Initialized
INFO - 2021-02-26 13:25:34 --> Language Class Initialized
INFO - 2021-02-26 13:25:35 --> Language Class Initialized
INFO - 2021-02-26 13:25:35 --> Config Class Initialized
INFO - 2021-02-26 13:25:35 --> Loader Class Initialized
INFO - 2021-02-26 13:25:35 --> Helper loaded: url_helper
INFO - 2021-02-26 13:25:35 --> Helper loaded: file_helper
INFO - 2021-02-26 13:25:35 --> Helper loaded: form_helper
INFO - 2021-02-26 13:25:35 --> Helper loaded: my_helper
INFO - 2021-02-26 13:25:35 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:25:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:25:35 --> Controller Class Initialized
DEBUG - 2021-02-26 13:25:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-02-26 13:25:35 --> Final output sent to browser
DEBUG - 2021-02-26 13:25:35 --> Total execution time: 1.2461
INFO - 2021-02-26 13:25:50 --> Config Class Initialized
INFO - 2021-02-26 13:25:50 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:25:50 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:25:50 --> Utf8 Class Initialized
INFO - 2021-02-26 13:25:50 --> URI Class Initialized
INFO - 2021-02-26 13:25:50 --> Router Class Initialized
INFO - 2021-02-26 13:25:50 --> Output Class Initialized
INFO - 2021-02-26 13:25:50 --> Security Class Initialized
DEBUG - 2021-02-26 13:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:25:50 --> Input Class Initialized
INFO - 2021-02-26 13:25:50 --> Language Class Initialized
INFO - 2021-02-26 13:25:50 --> Language Class Initialized
INFO - 2021-02-26 13:25:50 --> Config Class Initialized
INFO - 2021-02-26 13:25:50 --> Loader Class Initialized
INFO - 2021-02-26 13:25:50 --> Helper loaded: url_helper
INFO - 2021-02-26 13:25:50 --> Helper loaded: file_helper
INFO - 2021-02-26 13:25:50 --> Helper loaded: form_helper
INFO - 2021-02-26 13:25:51 --> Helper loaded: my_helper
INFO - 2021-02-26 13:25:51 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:25:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:25:51 --> Controller Class Initialized
DEBUG - 2021-02-26 13:25:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-02-26 13:25:51 --> Final output sent to browser
DEBUG - 2021-02-26 13:25:51 --> Total execution time: 1.3034
INFO - 2021-02-26 13:26:30 --> Config Class Initialized
INFO - 2021-02-26 13:26:30 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:26:30 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:26:30 --> Utf8 Class Initialized
INFO - 2021-02-26 13:26:30 --> URI Class Initialized
INFO - 2021-02-26 13:26:30 --> Router Class Initialized
INFO - 2021-02-26 13:26:30 --> Output Class Initialized
INFO - 2021-02-26 13:26:30 --> Security Class Initialized
DEBUG - 2021-02-26 13:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:26:30 --> Input Class Initialized
INFO - 2021-02-26 13:26:30 --> Language Class Initialized
INFO - 2021-02-26 13:26:31 --> Language Class Initialized
INFO - 2021-02-26 13:26:31 --> Config Class Initialized
INFO - 2021-02-26 13:26:31 --> Loader Class Initialized
INFO - 2021-02-26 13:26:31 --> Helper loaded: url_helper
INFO - 2021-02-26 13:26:31 --> Helper loaded: file_helper
INFO - 2021-02-26 13:26:31 --> Helper loaded: form_helper
INFO - 2021-02-26 13:26:31 --> Helper loaded: my_helper
INFO - 2021-02-26 13:26:31 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:26:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:26:31 --> Controller Class Initialized
DEBUG - 2021-02-26 13:26:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-02-26 13:26:31 --> Final output sent to browser
DEBUG - 2021-02-26 13:26:31 --> Total execution time: 1.1316
INFO - 2021-02-26 13:26:55 --> Config Class Initialized
INFO - 2021-02-26 13:26:55 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:26:55 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:26:55 --> Utf8 Class Initialized
INFO - 2021-02-26 13:26:55 --> URI Class Initialized
INFO - 2021-02-26 13:26:56 --> Router Class Initialized
INFO - 2021-02-26 13:26:56 --> Output Class Initialized
INFO - 2021-02-26 13:26:56 --> Security Class Initialized
DEBUG - 2021-02-26 13:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:26:56 --> Input Class Initialized
INFO - 2021-02-26 13:26:56 --> Language Class Initialized
INFO - 2021-02-26 13:26:56 --> Language Class Initialized
INFO - 2021-02-26 13:26:56 --> Config Class Initialized
INFO - 2021-02-26 13:26:56 --> Loader Class Initialized
INFO - 2021-02-26 13:26:56 --> Helper loaded: url_helper
INFO - 2021-02-26 13:26:56 --> Helper loaded: file_helper
INFO - 2021-02-26 13:26:56 --> Helper loaded: form_helper
INFO - 2021-02-26 13:26:56 --> Helper loaded: my_helper
INFO - 2021-02-26 13:26:56 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:26:56 --> Controller Class Initialized
DEBUG - 2021-02-26 13:26:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-02-26 13:26:57 --> Final output sent to browser
DEBUG - 2021-02-26 13:26:57 --> Total execution time: 1.2629
INFO - 2021-02-26 13:27:34 --> Config Class Initialized
INFO - 2021-02-26 13:27:34 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:27:34 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:27:34 --> Utf8 Class Initialized
INFO - 2021-02-26 13:27:34 --> URI Class Initialized
INFO - 2021-02-26 13:27:34 --> Router Class Initialized
INFO - 2021-02-26 13:27:34 --> Output Class Initialized
INFO - 2021-02-26 13:27:34 --> Security Class Initialized
DEBUG - 2021-02-26 13:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:27:34 --> Input Class Initialized
INFO - 2021-02-26 13:27:34 --> Language Class Initialized
INFO - 2021-02-26 13:27:34 --> Language Class Initialized
INFO - 2021-02-26 13:27:34 --> Config Class Initialized
INFO - 2021-02-26 13:27:34 --> Loader Class Initialized
INFO - 2021-02-26 13:27:34 --> Helper loaded: url_helper
INFO - 2021-02-26 13:27:34 --> Helper loaded: file_helper
INFO - 2021-02-26 13:27:34 --> Helper loaded: form_helper
INFO - 2021-02-26 13:27:35 --> Helper loaded: my_helper
INFO - 2021-02-26 13:27:35 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:27:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:27:35 --> Controller Class Initialized
INFO - 2021-02-26 13:27:35 --> Helper loaded: cookie_helper
INFO - 2021-02-26 13:27:35 --> Config Class Initialized
INFO - 2021-02-26 13:27:35 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:27:35 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:27:35 --> Utf8 Class Initialized
INFO - 2021-02-26 13:27:35 --> URI Class Initialized
INFO - 2021-02-26 13:27:35 --> Router Class Initialized
INFO - 2021-02-26 13:27:35 --> Output Class Initialized
INFO - 2021-02-26 13:27:35 --> Security Class Initialized
DEBUG - 2021-02-26 13:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:27:35 --> Input Class Initialized
INFO - 2021-02-26 13:27:35 --> Language Class Initialized
INFO - 2021-02-26 13:27:35 --> Language Class Initialized
INFO - 2021-02-26 13:27:35 --> Config Class Initialized
INFO - 2021-02-26 13:27:36 --> Loader Class Initialized
INFO - 2021-02-26 13:27:36 --> Helper loaded: url_helper
INFO - 2021-02-26 13:27:36 --> Helper loaded: file_helper
INFO - 2021-02-26 13:27:36 --> Helper loaded: form_helper
INFO - 2021-02-26 13:27:36 --> Helper loaded: my_helper
INFO - 2021-02-26 13:27:36 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:27:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:27:36 --> Controller Class Initialized
DEBUG - 2021-02-26 13:27:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-02-26 13:27:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 13:27:36 --> Final output sent to browser
DEBUG - 2021-02-26 13:27:36 --> Total execution time: 1.2315
INFO - 2021-02-26 13:27:42 --> Config Class Initialized
INFO - 2021-02-26 13:27:42 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:27:42 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:27:42 --> Utf8 Class Initialized
INFO - 2021-02-26 13:27:42 --> URI Class Initialized
INFO - 2021-02-26 13:27:42 --> Router Class Initialized
INFO - 2021-02-26 13:27:42 --> Output Class Initialized
INFO - 2021-02-26 13:27:42 --> Security Class Initialized
DEBUG - 2021-02-26 13:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:27:42 --> Input Class Initialized
INFO - 2021-02-26 13:27:42 --> Language Class Initialized
INFO - 2021-02-26 13:27:42 --> Language Class Initialized
INFO - 2021-02-26 13:27:42 --> Config Class Initialized
INFO - 2021-02-26 13:27:42 --> Loader Class Initialized
INFO - 2021-02-26 13:27:42 --> Helper loaded: url_helper
INFO - 2021-02-26 13:27:42 --> Helper loaded: file_helper
INFO - 2021-02-26 13:27:42 --> Helper loaded: form_helper
INFO - 2021-02-26 13:27:43 --> Helper loaded: my_helper
INFO - 2021-02-26 13:27:43 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:27:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:27:43 --> Controller Class Initialized
INFO - 2021-02-26 13:27:43 --> Helper loaded: cookie_helper
INFO - 2021-02-26 13:27:43 --> Final output sent to browser
DEBUG - 2021-02-26 13:27:43 --> Total execution time: 1.1519
INFO - 2021-02-26 13:27:43 --> Config Class Initialized
INFO - 2021-02-26 13:27:44 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:27:44 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:27:44 --> Utf8 Class Initialized
INFO - 2021-02-26 13:27:44 --> URI Class Initialized
INFO - 2021-02-26 13:27:44 --> Router Class Initialized
INFO - 2021-02-26 13:27:44 --> Output Class Initialized
INFO - 2021-02-26 13:27:44 --> Security Class Initialized
DEBUG - 2021-02-26 13:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:27:44 --> Input Class Initialized
INFO - 2021-02-26 13:27:44 --> Language Class Initialized
INFO - 2021-02-26 13:27:44 --> Language Class Initialized
INFO - 2021-02-26 13:27:44 --> Config Class Initialized
INFO - 2021-02-26 13:27:44 --> Loader Class Initialized
INFO - 2021-02-26 13:27:44 --> Helper loaded: url_helper
INFO - 2021-02-26 13:27:44 --> Helper loaded: file_helper
INFO - 2021-02-26 13:27:44 --> Helper loaded: form_helper
INFO - 2021-02-26 13:27:44 --> Helper loaded: my_helper
INFO - 2021-02-26 13:27:44 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:27:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:27:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:27:44 --> Controller Class Initialized
DEBUG - 2021-02-26 13:27:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-02-26 13:27:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 13:27:45 --> Final output sent to browser
DEBUG - 2021-02-26 13:27:45 --> Total execution time: 1.0558
INFO - 2021-02-26 13:28:21 --> Config Class Initialized
INFO - 2021-02-26 13:28:21 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:28:21 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:28:21 --> Utf8 Class Initialized
INFO - 2021-02-26 13:28:21 --> URI Class Initialized
INFO - 2021-02-26 13:28:21 --> Router Class Initialized
INFO - 2021-02-26 13:28:21 --> Output Class Initialized
INFO - 2021-02-26 13:28:21 --> Security Class Initialized
DEBUG - 2021-02-26 13:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:28:22 --> Input Class Initialized
INFO - 2021-02-26 13:28:22 --> Language Class Initialized
INFO - 2021-02-26 13:28:22 --> Language Class Initialized
INFO - 2021-02-26 13:28:22 --> Config Class Initialized
INFO - 2021-02-26 13:28:22 --> Loader Class Initialized
INFO - 2021-02-26 13:28:22 --> Helper loaded: url_helper
INFO - 2021-02-26 13:28:22 --> Helper loaded: file_helper
INFO - 2021-02-26 13:28:22 --> Helper loaded: form_helper
INFO - 2021-02-26 13:28:22 --> Helper loaded: my_helper
INFO - 2021-02-26 13:28:22 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:28:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:28:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:28:22 --> Controller Class Initialized
DEBUG - 2021-02-26 13:28:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-02-26 13:28:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 13:28:22 --> Final output sent to browser
DEBUG - 2021-02-26 13:28:22 --> Total execution time: 1.2216
INFO - 2021-02-26 13:28:51 --> Config Class Initialized
INFO - 2021-02-26 13:28:51 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:28:51 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:28:51 --> Utf8 Class Initialized
INFO - 2021-02-26 13:28:51 --> URI Class Initialized
INFO - 2021-02-26 13:28:51 --> Router Class Initialized
INFO - 2021-02-26 13:28:51 --> Output Class Initialized
INFO - 2021-02-26 13:28:51 --> Security Class Initialized
DEBUG - 2021-02-26 13:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:28:51 --> Input Class Initialized
INFO - 2021-02-26 13:28:51 --> Language Class Initialized
INFO - 2021-02-26 13:28:51 --> Language Class Initialized
INFO - 2021-02-26 13:28:52 --> Config Class Initialized
INFO - 2021-02-26 13:28:52 --> Loader Class Initialized
INFO - 2021-02-26 13:28:52 --> Helper loaded: url_helper
INFO - 2021-02-26 13:28:52 --> Helper loaded: file_helper
INFO - 2021-02-26 13:28:52 --> Helper loaded: form_helper
INFO - 2021-02-26 13:28:52 --> Helper loaded: my_helper
INFO - 2021-02-26 13:28:52 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:28:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:28:52 --> Controller Class Initialized
INFO - 2021-02-26 13:28:52 --> Final output sent to browser
DEBUG - 2021-02-26 13:28:52 --> Total execution time: 0.9284
INFO - 2021-02-26 13:28:54 --> Config Class Initialized
INFO - 2021-02-26 13:28:54 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:28:54 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:28:54 --> Utf8 Class Initialized
INFO - 2021-02-26 13:28:54 --> URI Class Initialized
INFO - 2021-02-26 13:28:54 --> Router Class Initialized
INFO - 2021-02-26 13:28:55 --> Output Class Initialized
INFO - 2021-02-26 13:28:55 --> Security Class Initialized
DEBUG - 2021-02-26 13:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:28:55 --> Input Class Initialized
INFO - 2021-02-26 13:28:55 --> Language Class Initialized
INFO - 2021-02-26 13:28:55 --> Language Class Initialized
INFO - 2021-02-26 13:28:55 --> Config Class Initialized
INFO - 2021-02-26 13:28:55 --> Loader Class Initialized
INFO - 2021-02-26 13:28:55 --> Helper loaded: url_helper
INFO - 2021-02-26 13:28:55 --> Helper loaded: file_helper
INFO - 2021-02-26 13:28:55 --> Helper loaded: form_helper
INFO - 2021-02-26 13:28:55 --> Helper loaded: my_helper
INFO - 2021-02-26 13:28:55 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:28:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:28:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:28:55 --> Controller Class Initialized
DEBUG - 2021-02-26 13:28:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-02-26 13:28:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 13:28:55 --> Final output sent to browser
DEBUG - 2021-02-26 13:28:56 --> Total execution time: 1.1700
INFO - 2021-02-26 13:28:58 --> Config Class Initialized
INFO - 2021-02-26 13:28:58 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:28:58 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:28:58 --> Utf8 Class Initialized
INFO - 2021-02-26 13:28:58 --> URI Class Initialized
INFO - 2021-02-26 13:28:58 --> Router Class Initialized
INFO - 2021-02-26 13:28:58 --> Output Class Initialized
INFO - 2021-02-26 13:28:58 --> Security Class Initialized
DEBUG - 2021-02-26 13:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:28:58 --> Input Class Initialized
INFO - 2021-02-26 13:28:58 --> Language Class Initialized
INFO - 2021-02-26 13:28:58 --> Language Class Initialized
INFO - 2021-02-26 13:28:58 --> Config Class Initialized
INFO - 2021-02-26 13:28:58 --> Loader Class Initialized
INFO - 2021-02-26 13:28:58 --> Helper loaded: url_helper
INFO - 2021-02-26 13:28:58 --> Helper loaded: file_helper
INFO - 2021-02-26 13:28:58 --> Helper loaded: form_helper
INFO - 2021-02-26 13:28:58 --> Helper loaded: my_helper
INFO - 2021-02-26 13:28:58 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:28:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:28:58 --> Controller Class Initialized
DEBUG - 2021-02-26 13:28:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-02-26 13:28:59 --> Final output sent to browser
DEBUG - 2021-02-26 13:28:59 --> Total execution time: 1.1563
INFO - 2021-02-26 13:30:28 --> Config Class Initialized
INFO - 2021-02-26 13:30:28 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:30:28 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:30:28 --> Utf8 Class Initialized
INFO - 2021-02-26 13:30:29 --> URI Class Initialized
INFO - 2021-02-26 13:30:29 --> Router Class Initialized
INFO - 2021-02-26 13:30:29 --> Output Class Initialized
INFO - 2021-02-26 13:30:29 --> Security Class Initialized
DEBUG - 2021-02-26 13:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:30:29 --> Input Class Initialized
INFO - 2021-02-26 13:30:29 --> Language Class Initialized
INFO - 2021-02-26 13:30:29 --> Language Class Initialized
INFO - 2021-02-26 13:30:29 --> Config Class Initialized
INFO - 2021-02-26 13:30:29 --> Loader Class Initialized
INFO - 2021-02-26 13:30:29 --> Helper loaded: url_helper
INFO - 2021-02-26 13:30:29 --> Helper loaded: file_helper
INFO - 2021-02-26 13:30:29 --> Helper loaded: form_helper
INFO - 2021-02-26 13:30:29 --> Helper loaded: my_helper
INFO - 2021-02-26 13:30:29 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:30:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:30:29 --> Controller Class Initialized
DEBUG - 2021-02-26 13:30:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-02-26 13:30:30 --> Final output sent to browser
DEBUG - 2021-02-26 13:30:30 --> Total execution time: 1.3288
INFO - 2021-02-26 13:31:03 --> Config Class Initialized
INFO - 2021-02-26 13:31:03 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:31:04 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:31:04 --> Utf8 Class Initialized
INFO - 2021-02-26 13:31:04 --> URI Class Initialized
INFO - 2021-02-26 13:31:04 --> Router Class Initialized
INFO - 2021-02-26 13:31:04 --> Output Class Initialized
INFO - 2021-02-26 13:31:04 --> Security Class Initialized
DEBUG - 2021-02-26 13:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:31:04 --> Input Class Initialized
INFO - 2021-02-26 13:31:04 --> Language Class Initialized
INFO - 2021-02-26 13:31:04 --> Language Class Initialized
INFO - 2021-02-26 13:31:04 --> Config Class Initialized
INFO - 2021-02-26 13:31:04 --> Loader Class Initialized
INFO - 2021-02-26 13:31:04 --> Helper loaded: url_helper
INFO - 2021-02-26 13:31:04 --> Helper loaded: file_helper
INFO - 2021-02-26 13:31:04 --> Helper loaded: form_helper
INFO - 2021-02-26 13:31:04 --> Helper loaded: my_helper
INFO - 2021-02-26 13:31:04 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:31:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:31:04 --> Controller Class Initialized
DEBUG - 2021-02-26 13:31:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-02-26 13:31:05 --> Final output sent to browser
DEBUG - 2021-02-26 13:31:05 --> Total execution time: 1.1389
INFO - 2021-02-26 13:31:30 --> Config Class Initialized
INFO - 2021-02-26 13:31:30 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:31:30 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:31:30 --> Utf8 Class Initialized
INFO - 2021-02-26 13:31:30 --> URI Class Initialized
INFO - 2021-02-26 13:31:30 --> Router Class Initialized
INFO - 2021-02-26 13:31:30 --> Output Class Initialized
INFO - 2021-02-26 13:31:30 --> Security Class Initialized
DEBUG - 2021-02-26 13:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:31:30 --> Input Class Initialized
INFO - 2021-02-26 13:31:30 --> Language Class Initialized
INFO - 2021-02-26 13:31:30 --> Language Class Initialized
INFO - 2021-02-26 13:31:30 --> Config Class Initialized
INFO - 2021-02-26 13:31:30 --> Loader Class Initialized
INFO - 2021-02-26 13:31:30 --> Helper loaded: url_helper
INFO - 2021-02-26 13:31:31 --> Helper loaded: file_helper
INFO - 2021-02-26 13:31:31 --> Helper loaded: form_helper
INFO - 2021-02-26 13:31:31 --> Helper loaded: my_helper
INFO - 2021-02-26 13:31:31 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:31:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:31:31 --> Controller Class Initialized
DEBUG - 2021-02-26 13:31:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-02-26 13:31:31 --> Final output sent to browser
DEBUG - 2021-02-26 13:31:31 --> Total execution time: 1.3952
INFO - 2021-02-26 13:32:18 --> Config Class Initialized
INFO - 2021-02-26 13:32:18 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:32:18 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:32:18 --> Utf8 Class Initialized
INFO - 2021-02-26 13:32:18 --> URI Class Initialized
INFO - 2021-02-26 13:32:18 --> Router Class Initialized
INFO - 2021-02-26 13:32:18 --> Output Class Initialized
INFO - 2021-02-26 13:32:18 --> Security Class Initialized
DEBUG - 2021-02-26 13:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:32:18 --> Input Class Initialized
INFO - 2021-02-26 13:32:18 --> Language Class Initialized
INFO - 2021-02-26 13:32:18 --> Language Class Initialized
INFO - 2021-02-26 13:32:18 --> Config Class Initialized
INFO - 2021-02-26 13:32:18 --> Loader Class Initialized
INFO - 2021-02-26 13:32:18 --> Helper loaded: url_helper
INFO - 2021-02-26 13:32:18 --> Helper loaded: file_helper
INFO - 2021-02-26 13:32:18 --> Helper loaded: form_helper
INFO - 2021-02-26 13:32:18 --> Helper loaded: my_helper
INFO - 2021-02-26 13:32:19 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:32:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:32:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:32:19 --> Controller Class Initialized
DEBUG - 2021-02-26 13:32:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-02-26 13:32:19 --> Final output sent to browser
DEBUG - 2021-02-26 13:32:19 --> Total execution time: 1.2717
INFO - 2021-02-26 13:32:32 --> Config Class Initialized
INFO - 2021-02-26 13:32:32 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:32:32 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:32:32 --> Utf8 Class Initialized
INFO - 2021-02-26 13:32:32 --> URI Class Initialized
INFO - 2021-02-26 13:32:32 --> Router Class Initialized
INFO - 2021-02-26 13:32:32 --> Output Class Initialized
INFO - 2021-02-26 13:32:32 --> Security Class Initialized
DEBUG - 2021-02-26 13:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:32:32 --> Input Class Initialized
INFO - 2021-02-26 13:32:32 --> Language Class Initialized
INFO - 2021-02-26 13:32:33 --> Language Class Initialized
INFO - 2021-02-26 13:32:33 --> Config Class Initialized
INFO - 2021-02-26 13:32:33 --> Loader Class Initialized
INFO - 2021-02-26 13:32:33 --> Helper loaded: url_helper
INFO - 2021-02-26 13:32:33 --> Helper loaded: file_helper
INFO - 2021-02-26 13:32:33 --> Helper loaded: form_helper
INFO - 2021-02-26 13:32:33 --> Helper loaded: my_helper
INFO - 2021-02-26 13:32:33 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:32:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:32:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:32:33 --> Controller Class Initialized
DEBUG - 2021-02-26 13:32:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-02-26 13:32:33 --> Final output sent to browser
DEBUG - 2021-02-26 13:32:33 --> Total execution time: 1.3821
INFO - 2021-02-26 13:32:45 --> Config Class Initialized
INFO - 2021-02-26 13:32:46 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:32:46 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:32:46 --> Utf8 Class Initialized
INFO - 2021-02-26 13:32:46 --> URI Class Initialized
INFO - 2021-02-26 13:32:46 --> Router Class Initialized
INFO - 2021-02-26 13:32:46 --> Output Class Initialized
INFO - 2021-02-26 13:32:46 --> Security Class Initialized
DEBUG - 2021-02-26 13:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:32:46 --> Input Class Initialized
INFO - 2021-02-26 13:32:46 --> Language Class Initialized
INFO - 2021-02-26 13:32:46 --> Language Class Initialized
INFO - 2021-02-26 13:32:46 --> Config Class Initialized
INFO - 2021-02-26 13:32:46 --> Loader Class Initialized
INFO - 2021-02-26 13:32:46 --> Helper loaded: url_helper
INFO - 2021-02-26 13:32:46 --> Helper loaded: file_helper
INFO - 2021-02-26 13:32:46 --> Helper loaded: form_helper
INFO - 2021-02-26 13:32:46 --> Helper loaded: my_helper
INFO - 2021-02-26 13:32:47 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:32:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:32:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:32:47 --> Controller Class Initialized
DEBUG - 2021-02-26 13:32:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-02-26 13:32:47 --> Final output sent to browser
DEBUG - 2021-02-26 13:32:47 --> Total execution time: 1.5513
INFO - 2021-02-26 13:33:00 --> Config Class Initialized
INFO - 2021-02-26 13:33:00 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:33:00 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:33:00 --> Utf8 Class Initialized
INFO - 2021-02-26 13:33:00 --> URI Class Initialized
INFO - 2021-02-26 13:33:00 --> Router Class Initialized
INFO - 2021-02-26 13:33:00 --> Output Class Initialized
INFO - 2021-02-26 13:33:00 --> Security Class Initialized
DEBUG - 2021-02-26 13:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:33:00 --> Input Class Initialized
INFO - 2021-02-26 13:33:00 --> Language Class Initialized
INFO - 2021-02-26 13:33:00 --> Language Class Initialized
INFO - 2021-02-26 13:33:00 --> Config Class Initialized
INFO - 2021-02-26 13:33:00 --> Loader Class Initialized
INFO - 2021-02-26 13:33:00 --> Helper loaded: url_helper
INFO - 2021-02-26 13:33:00 --> Helper loaded: file_helper
INFO - 2021-02-26 13:33:00 --> Helper loaded: form_helper
INFO - 2021-02-26 13:33:00 --> Helper loaded: my_helper
INFO - 2021-02-26 13:33:01 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:33:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:33:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:33:01 --> Controller Class Initialized
INFO - 2021-02-26 13:33:01 --> Helper loaded: cookie_helper
INFO - 2021-02-26 13:33:01 --> Config Class Initialized
INFO - 2021-02-26 13:33:01 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:33:01 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:33:01 --> Utf8 Class Initialized
INFO - 2021-02-26 13:33:01 --> URI Class Initialized
INFO - 2021-02-26 13:33:01 --> Router Class Initialized
INFO - 2021-02-26 13:33:01 --> Output Class Initialized
INFO - 2021-02-26 13:33:01 --> Security Class Initialized
DEBUG - 2021-02-26 13:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:33:01 --> Input Class Initialized
INFO - 2021-02-26 13:33:01 --> Language Class Initialized
INFO - 2021-02-26 13:33:01 --> Language Class Initialized
INFO - 2021-02-26 13:33:01 --> Config Class Initialized
INFO - 2021-02-26 13:33:01 --> Loader Class Initialized
INFO - 2021-02-26 13:33:01 --> Helper loaded: url_helper
INFO - 2021-02-26 13:33:02 --> Helper loaded: file_helper
INFO - 2021-02-26 13:33:02 --> Helper loaded: form_helper
INFO - 2021-02-26 13:33:02 --> Helper loaded: my_helper
INFO - 2021-02-26 13:33:02 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:33:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:33:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:33:02 --> Controller Class Initialized
DEBUG - 2021-02-26 13:33:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-02-26 13:33:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 13:33:02 --> Final output sent to browser
DEBUG - 2021-02-26 13:33:02 --> Total execution time: 1.1687
INFO - 2021-02-26 13:34:14 --> Config Class Initialized
INFO - 2021-02-26 13:34:14 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:34:15 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:34:15 --> Utf8 Class Initialized
INFO - 2021-02-26 13:34:15 --> URI Class Initialized
INFO - 2021-02-26 13:34:15 --> Router Class Initialized
INFO - 2021-02-26 13:34:15 --> Output Class Initialized
INFO - 2021-02-26 13:34:15 --> Security Class Initialized
DEBUG - 2021-02-26 13:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:34:15 --> Input Class Initialized
INFO - 2021-02-26 13:34:15 --> Language Class Initialized
INFO - 2021-02-26 13:34:15 --> Language Class Initialized
INFO - 2021-02-26 13:34:15 --> Config Class Initialized
INFO - 2021-02-26 13:34:15 --> Loader Class Initialized
INFO - 2021-02-26 13:34:15 --> Helper loaded: url_helper
INFO - 2021-02-26 13:34:15 --> Helper loaded: file_helper
INFO - 2021-02-26 13:34:15 --> Helper loaded: form_helper
INFO - 2021-02-26 13:34:15 --> Helper loaded: my_helper
INFO - 2021-02-26 13:34:15 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:34:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:34:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:34:15 --> Controller Class Initialized
INFO - 2021-02-26 13:34:15 --> Helper loaded: cookie_helper
INFO - 2021-02-26 13:34:16 --> Final output sent to browser
DEBUG - 2021-02-26 13:34:16 --> Total execution time: 1.0926
INFO - 2021-02-26 13:34:16 --> Config Class Initialized
INFO - 2021-02-26 13:34:16 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:34:16 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:34:16 --> Utf8 Class Initialized
INFO - 2021-02-26 13:34:16 --> URI Class Initialized
INFO - 2021-02-26 13:34:16 --> Router Class Initialized
INFO - 2021-02-26 13:34:16 --> Output Class Initialized
INFO - 2021-02-26 13:34:16 --> Security Class Initialized
DEBUG - 2021-02-26 13:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:34:16 --> Input Class Initialized
INFO - 2021-02-26 13:34:16 --> Language Class Initialized
INFO - 2021-02-26 13:34:16 --> Language Class Initialized
INFO - 2021-02-26 13:34:16 --> Config Class Initialized
INFO - 2021-02-26 13:34:17 --> Loader Class Initialized
INFO - 2021-02-26 13:34:17 --> Helper loaded: url_helper
INFO - 2021-02-26 13:34:17 --> Helper loaded: file_helper
INFO - 2021-02-26 13:34:17 --> Helper loaded: form_helper
INFO - 2021-02-26 13:34:17 --> Helper loaded: my_helper
INFO - 2021-02-26 13:34:17 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:34:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:34:17 --> Controller Class Initialized
DEBUG - 2021-02-26 13:34:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-02-26 13:34:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 13:34:17 --> Final output sent to browser
DEBUG - 2021-02-26 13:34:17 --> Total execution time: 1.1730
INFO - 2021-02-26 13:34:20 --> Config Class Initialized
INFO - 2021-02-26 13:34:20 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:34:20 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:34:20 --> Utf8 Class Initialized
INFO - 2021-02-26 13:34:20 --> URI Class Initialized
INFO - 2021-02-26 13:34:20 --> Router Class Initialized
INFO - 2021-02-26 13:34:20 --> Output Class Initialized
INFO - 2021-02-26 13:34:20 --> Security Class Initialized
DEBUG - 2021-02-26 13:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:34:20 --> Input Class Initialized
INFO - 2021-02-26 13:34:20 --> Language Class Initialized
INFO - 2021-02-26 13:34:20 --> Language Class Initialized
INFO - 2021-02-26 13:34:20 --> Config Class Initialized
INFO - 2021-02-26 13:34:20 --> Loader Class Initialized
INFO - 2021-02-26 13:34:20 --> Helper loaded: url_helper
INFO - 2021-02-26 13:34:20 --> Helper loaded: file_helper
INFO - 2021-02-26 13:34:20 --> Helper loaded: form_helper
INFO - 2021-02-26 13:34:20 --> Helper loaded: my_helper
INFO - 2021-02-26 13:34:21 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:34:21 --> Controller Class Initialized
DEBUG - 2021-02-26 13:34:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-02-26 13:34:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 13:34:21 --> Final output sent to browser
DEBUG - 2021-02-26 13:34:21 --> Total execution time: 1.2748
INFO - 2021-02-26 13:34:22 --> Config Class Initialized
INFO - 2021-02-26 13:34:22 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:34:22 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:34:23 --> Utf8 Class Initialized
INFO - 2021-02-26 13:34:23 --> URI Class Initialized
INFO - 2021-02-26 13:34:23 --> Router Class Initialized
INFO - 2021-02-26 13:34:23 --> Output Class Initialized
INFO - 2021-02-26 13:34:23 --> Security Class Initialized
DEBUG - 2021-02-26 13:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:34:23 --> Input Class Initialized
INFO - 2021-02-26 13:34:23 --> Language Class Initialized
INFO - 2021-02-26 13:34:23 --> Language Class Initialized
INFO - 2021-02-26 13:34:23 --> Config Class Initialized
INFO - 2021-02-26 13:34:23 --> Loader Class Initialized
INFO - 2021-02-26 13:34:23 --> Helper loaded: url_helper
INFO - 2021-02-26 13:34:23 --> Helper loaded: file_helper
INFO - 2021-02-26 13:34:23 --> Helper loaded: form_helper
INFO - 2021-02-26 13:34:23 --> Helper loaded: my_helper
INFO - 2021-02-26 13:34:23 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:34:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:34:23 --> Controller Class Initialized
DEBUG - 2021-02-26 13:34:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-02-26 13:34:24 --> Final output sent to browser
DEBUG - 2021-02-26 13:34:24 --> Total execution time: 1.1827
INFO - 2021-02-26 13:36:25 --> Config Class Initialized
INFO - 2021-02-26 13:36:25 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:36:25 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:36:25 --> Utf8 Class Initialized
INFO - 2021-02-26 13:36:25 --> URI Class Initialized
INFO - 2021-02-26 13:36:25 --> Router Class Initialized
INFO - 2021-02-26 13:36:25 --> Output Class Initialized
INFO - 2021-02-26 13:36:25 --> Security Class Initialized
DEBUG - 2021-02-26 13:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:36:25 --> Input Class Initialized
INFO - 2021-02-26 13:36:25 --> Language Class Initialized
INFO - 2021-02-26 13:36:25 --> Language Class Initialized
INFO - 2021-02-26 13:36:26 --> Config Class Initialized
INFO - 2021-02-26 13:36:26 --> Loader Class Initialized
INFO - 2021-02-26 13:36:26 --> Helper loaded: url_helper
INFO - 2021-02-26 13:36:26 --> Helper loaded: file_helper
INFO - 2021-02-26 13:36:26 --> Helper loaded: form_helper
INFO - 2021-02-26 13:36:26 --> Helper loaded: my_helper
INFO - 2021-02-26 13:36:26 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:36:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:36:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:36:26 --> Controller Class Initialized
DEBUG - 2021-02-26 13:36:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-02-26 13:36:26 --> Final output sent to browser
DEBUG - 2021-02-26 13:36:26 --> Total execution time: 1.2444
INFO - 2021-02-26 13:37:13 --> Config Class Initialized
INFO - 2021-02-26 13:37:13 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:37:13 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:37:13 --> Utf8 Class Initialized
INFO - 2021-02-26 13:37:13 --> URI Class Initialized
INFO - 2021-02-26 13:37:13 --> Router Class Initialized
INFO - 2021-02-26 13:37:13 --> Output Class Initialized
INFO - 2021-02-26 13:37:13 --> Security Class Initialized
DEBUG - 2021-02-26 13:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:37:13 --> Input Class Initialized
INFO - 2021-02-26 13:37:13 --> Language Class Initialized
INFO - 2021-02-26 13:37:13 --> Language Class Initialized
INFO - 2021-02-26 13:37:13 --> Config Class Initialized
INFO - 2021-02-26 13:37:13 --> Loader Class Initialized
INFO - 2021-02-26 13:37:13 --> Helper loaded: url_helper
INFO - 2021-02-26 13:37:13 --> Helper loaded: file_helper
INFO - 2021-02-26 13:37:13 --> Helper loaded: form_helper
INFO - 2021-02-26 13:37:13 --> Helper loaded: my_helper
INFO - 2021-02-26 13:37:14 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:37:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:37:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:37:14 --> Controller Class Initialized
DEBUG - 2021-02-26 13:37:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-02-26 13:37:14 --> Final output sent to browser
DEBUG - 2021-02-26 13:37:14 --> Total execution time: 1.2419
INFO - 2021-02-26 13:37:38 --> Config Class Initialized
INFO - 2021-02-26 13:37:38 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:37:38 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:37:38 --> Utf8 Class Initialized
INFO - 2021-02-26 13:37:38 --> URI Class Initialized
INFO - 2021-02-26 13:37:38 --> Router Class Initialized
INFO - 2021-02-26 13:37:38 --> Output Class Initialized
INFO - 2021-02-26 13:37:38 --> Security Class Initialized
DEBUG - 2021-02-26 13:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:37:39 --> Input Class Initialized
INFO - 2021-02-26 13:37:39 --> Language Class Initialized
INFO - 2021-02-26 13:37:39 --> Language Class Initialized
INFO - 2021-02-26 13:37:39 --> Config Class Initialized
INFO - 2021-02-26 13:37:39 --> Loader Class Initialized
INFO - 2021-02-26 13:37:39 --> Helper loaded: url_helper
INFO - 2021-02-26 13:37:39 --> Helper loaded: file_helper
INFO - 2021-02-26 13:37:39 --> Helper loaded: form_helper
INFO - 2021-02-26 13:37:39 --> Helper loaded: my_helper
INFO - 2021-02-26 13:37:39 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:37:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:37:39 --> Controller Class Initialized
DEBUG - 2021-02-26 13:37:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-02-26 13:37:39 --> Final output sent to browser
DEBUG - 2021-02-26 13:37:39 --> Total execution time: 1.3238
INFO - 2021-02-26 13:37:58 --> Config Class Initialized
INFO - 2021-02-26 13:37:58 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:37:58 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:37:58 --> Utf8 Class Initialized
INFO - 2021-02-26 13:37:58 --> URI Class Initialized
INFO - 2021-02-26 13:37:58 --> Router Class Initialized
INFO - 2021-02-26 13:37:58 --> Output Class Initialized
INFO - 2021-02-26 13:37:58 --> Security Class Initialized
DEBUG - 2021-02-26 13:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:37:58 --> Input Class Initialized
INFO - 2021-02-26 13:37:58 --> Language Class Initialized
INFO - 2021-02-26 13:37:58 --> Language Class Initialized
INFO - 2021-02-26 13:37:58 --> Config Class Initialized
INFO - 2021-02-26 13:37:58 --> Loader Class Initialized
INFO - 2021-02-26 13:37:58 --> Helper loaded: url_helper
INFO - 2021-02-26 13:37:58 --> Helper loaded: file_helper
INFO - 2021-02-26 13:37:58 --> Helper loaded: form_helper
INFO - 2021-02-26 13:37:58 --> Helper loaded: my_helper
INFO - 2021-02-26 13:37:59 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:37:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:37:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:37:59 --> Controller Class Initialized
DEBUG - 2021-02-26 13:37:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-02-26 13:37:59 --> Final output sent to browser
DEBUG - 2021-02-26 13:37:59 --> Total execution time: 1.3122
INFO - 2021-02-26 13:38:29 --> Config Class Initialized
INFO - 2021-02-26 13:38:29 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:38:29 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:38:29 --> Utf8 Class Initialized
INFO - 2021-02-26 13:38:29 --> URI Class Initialized
INFO - 2021-02-26 13:38:29 --> Router Class Initialized
INFO - 2021-02-26 13:38:29 --> Output Class Initialized
INFO - 2021-02-26 13:38:29 --> Security Class Initialized
DEBUG - 2021-02-26 13:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:38:29 --> Input Class Initialized
INFO - 2021-02-26 13:38:29 --> Language Class Initialized
INFO - 2021-02-26 13:38:29 --> Language Class Initialized
INFO - 2021-02-26 13:38:29 --> Config Class Initialized
INFO - 2021-02-26 13:38:29 --> Loader Class Initialized
INFO - 2021-02-26 13:38:30 --> Helper loaded: url_helper
INFO - 2021-02-26 13:38:30 --> Helper loaded: file_helper
INFO - 2021-02-26 13:38:30 --> Helper loaded: form_helper
INFO - 2021-02-26 13:38:30 --> Helper loaded: my_helper
INFO - 2021-02-26 13:38:30 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:38:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:38:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:38:30 --> Controller Class Initialized
DEBUG - 2021-02-26 13:38:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-02-26 13:38:30 --> Final output sent to browser
DEBUG - 2021-02-26 13:38:30 --> Total execution time: 1.2346
INFO - 2021-02-26 13:39:08 --> Config Class Initialized
INFO - 2021-02-26 13:39:08 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:39:08 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:39:08 --> Utf8 Class Initialized
INFO - 2021-02-26 13:39:08 --> URI Class Initialized
INFO - 2021-02-26 13:39:08 --> Router Class Initialized
INFO - 2021-02-26 13:39:08 --> Output Class Initialized
INFO - 2021-02-26 13:39:08 --> Security Class Initialized
DEBUG - 2021-02-26 13:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:39:09 --> Input Class Initialized
INFO - 2021-02-26 13:39:09 --> Language Class Initialized
INFO - 2021-02-26 13:39:09 --> Language Class Initialized
INFO - 2021-02-26 13:39:09 --> Config Class Initialized
INFO - 2021-02-26 13:39:09 --> Loader Class Initialized
INFO - 2021-02-26 13:39:09 --> Helper loaded: url_helper
INFO - 2021-02-26 13:39:09 --> Helper loaded: file_helper
INFO - 2021-02-26 13:39:09 --> Helper loaded: form_helper
INFO - 2021-02-26 13:39:09 --> Helper loaded: my_helper
INFO - 2021-02-26 13:39:09 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:39:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:39:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:39:09 --> Controller Class Initialized
DEBUG - 2021-02-26 13:39:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-02-26 13:39:09 --> Final output sent to browser
DEBUG - 2021-02-26 13:39:09 --> Total execution time: 1.2549
INFO - 2021-02-26 13:39:22 --> Config Class Initialized
INFO - 2021-02-26 13:39:22 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:39:22 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:39:22 --> Utf8 Class Initialized
INFO - 2021-02-26 13:39:22 --> URI Class Initialized
INFO - 2021-02-26 13:39:22 --> Router Class Initialized
INFO - 2021-02-26 13:39:22 --> Output Class Initialized
INFO - 2021-02-26 13:39:22 --> Security Class Initialized
DEBUG - 2021-02-26 13:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:39:22 --> Input Class Initialized
INFO - 2021-02-26 13:39:22 --> Language Class Initialized
INFO - 2021-02-26 13:39:22 --> Language Class Initialized
INFO - 2021-02-26 13:39:22 --> Config Class Initialized
INFO - 2021-02-26 13:39:23 --> Loader Class Initialized
INFO - 2021-02-26 13:39:23 --> Helper loaded: url_helper
INFO - 2021-02-26 13:39:23 --> Helper loaded: file_helper
INFO - 2021-02-26 13:39:23 --> Helper loaded: form_helper
INFO - 2021-02-26 13:39:23 --> Helper loaded: my_helper
INFO - 2021-02-26 13:39:23 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:39:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:39:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:39:23 --> Controller Class Initialized
DEBUG - 2021-02-26 13:39:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-02-26 13:39:23 --> Final output sent to browser
DEBUG - 2021-02-26 13:39:23 --> Total execution time: 1.3706
INFO - 2021-02-26 13:39:58 --> Config Class Initialized
INFO - 2021-02-26 13:39:58 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:39:58 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:39:58 --> Utf8 Class Initialized
INFO - 2021-02-26 13:39:58 --> URI Class Initialized
INFO - 2021-02-26 13:39:58 --> Router Class Initialized
INFO - 2021-02-26 13:39:58 --> Output Class Initialized
INFO - 2021-02-26 13:39:58 --> Security Class Initialized
DEBUG - 2021-02-26 13:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:39:58 --> Input Class Initialized
INFO - 2021-02-26 13:39:58 --> Language Class Initialized
INFO - 2021-02-26 13:39:58 --> Language Class Initialized
INFO - 2021-02-26 13:39:58 --> Config Class Initialized
INFO - 2021-02-26 13:39:59 --> Loader Class Initialized
INFO - 2021-02-26 13:39:59 --> Helper loaded: url_helper
INFO - 2021-02-26 13:39:59 --> Helper loaded: file_helper
INFO - 2021-02-26 13:39:59 --> Helper loaded: form_helper
INFO - 2021-02-26 13:39:59 --> Helper loaded: my_helper
INFO - 2021-02-26 13:39:59 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:39:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:39:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:39:59 --> Controller Class Initialized
DEBUG - 2021-02-26 13:39:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-02-26 13:39:59 --> Final output sent to browser
DEBUG - 2021-02-26 13:39:59 --> Total execution time: 1.3779
INFO - 2021-02-26 13:40:22 --> Config Class Initialized
INFO - 2021-02-26 13:40:22 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:40:22 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:40:22 --> Utf8 Class Initialized
INFO - 2021-02-26 13:40:23 --> URI Class Initialized
INFO - 2021-02-26 13:40:23 --> Router Class Initialized
INFO - 2021-02-26 13:40:23 --> Output Class Initialized
INFO - 2021-02-26 13:40:23 --> Security Class Initialized
DEBUG - 2021-02-26 13:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:40:23 --> Input Class Initialized
INFO - 2021-02-26 13:40:23 --> Language Class Initialized
INFO - 2021-02-26 13:40:23 --> Language Class Initialized
INFO - 2021-02-26 13:40:23 --> Config Class Initialized
INFO - 2021-02-26 13:40:23 --> Loader Class Initialized
INFO - 2021-02-26 13:40:23 --> Helper loaded: url_helper
INFO - 2021-02-26 13:40:23 --> Helper loaded: file_helper
INFO - 2021-02-26 13:40:23 --> Helper loaded: form_helper
INFO - 2021-02-26 13:40:23 --> Helper loaded: my_helper
INFO - 2021-02-26 13:40:23 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:40:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:40:23 --> Controller Class Initialized
DEBUG - 2021-02-26 13:40:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-02-26 13:40:24 --> Final output sent to browser
DEBUG - 2021-02-26 13:40:24 --> Total execution time: 1.3059
INFO - 2021-02-26 13:41:07 --> Config Class Initialized
INFO - 2021-02-26 13:41:07 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:41:07 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:41:07 --> Utf8 Class Initialized
INFO - 2021-02-26 13:41:07 --> URI Class Initialized
INFO - 2021-02-26 13:41:07 --> Router Class Initialized
INFO - 2021-02-26 13:41:07 --> Output Class Initialized
INFO - 2021-02-26 13:41:07 --> Security Class Initialized
DEBUG - 2021-02-26 13:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:41:07 --> Input Class Initialized
INFO - 2021-02-26 13:41:08 --> Language Class Initialized
INFO - 2021-02-26 13:41:08 --> Language Class Initialized
INFO - 2021-02-26 13:41:08 --> Config Class Initialized
INFO - 2021-02-26 13:41:08 --> Loader Class Initialized
INFO - 2021-02-26 13:41:08 --> Helper loaded: url_helper
INFO - 2021-02-26 13:41:08 --> Helper loaded: file_helper
INFO - 2021-02-26 13:41:08 --> Helper loaded: form_helper
INFO - 2021-02-26 13:41:08 --> Helper loaded: my_helper
INFO - 2021-02-26 13:41:08 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:41:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:41:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:41:08 --> Controller Class Initialized
DEBUG - 2021-02-26 13:41:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-02-26 13:41:08 --> Final output sent to browser
DEBUG - 2021-02-26 13:41:09 --> Total execution time: 1.4104
INFO - 2021-02-26 13:41:42 --> Config Class Initialized
INFO - 2021-02-26 13:41:42 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:41:42 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:41:42 --> Utf8 Class Initialized
INFO - 2021-02-26 13:41:42 --> URI Class Initialized
INFO - 2021-02-26 13:41:42 --> Router Class Initialized
INFO - 2021-02-26 13:41:42 --> Output Class Initialized
INFO - 2021-02-26 13:41:42 --> Security Class Initialized
DEBUG - 2021-02-26 13:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:41:42 --> Input Class Initialized
INFO - 2021-02-26 13:41:42 --> Language Class Initialized
INFO - 2021-02-26 13:41:43 --> Language Class Initialized
INFO - 2021-02-26 13:41:43 --> Config Class Initialized
INFO - 2021-02-26 13:41:43 --> Loader Class Initialized
INFO - 2021-02-26 13:41:43 --> Helper loaded: url_helper
INFO - 2021-02-26 13:41:43 --> Helper loaded: file_helper
INFO - 2021-02-26 13:41:43 --> Helper loaded: form_helper
INFO - 2021-02-26 13:41:43 --> Helper loaded: my_helper
INFO - 2021-02-26 13:41:43 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:41:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:41:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:41:43 --> Controller Class Initialized
DEBUG - 2021-02-26 13:41:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-02-26 13:41:43 --> Final output sent to browser
DEBUG - 2021-02-26 13:41:43 --> Total execution time: 1.3422
INFO - 2021-02-26 13:42:29 --> Config Class Initialized
INFO - 2021-02-26 13:42:29 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:42:29 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:42:29 --> Utf8 Class Initialized
INFO - 2021-02-26 13:42:29 --> URI Class Initialized
INFO - 2021-02-26 13:42:29 --> Router Class Initialized
INFO - 2021-02-26 13:42:29 --> Output Class Initialized
INFO - 2021-02-26 13:42:29 --> Security Class Initialized
DEBUG - 2021-02-26 13:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:42:29 --> Input Class Initialized
INFO - 2021-02-26 13:42:29 --> Language Class Initialized
INFO - 2021-02-26 13:42:29 --> Language Class Initialized
INFO - 2021-02-26 13:42:29 --> Config Class Initialized
INFO - 2021-02-26 13:42:30 --> Loader Class Initialized
INFO - 2021-02-26 13:42:30 --> Helper loaded: url_helper
INFO - 2021-02-26 13:42:30 --> Helper loaded: file_helper
INFO - 2021-02-26 13:42:30 --> Helper loaded: form_helper
INFO - 2021-02-26 13:42:30 --> Helper loaded: my_helper
INFO - 2021-02-26 13:42:30 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:42:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:42:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:42:30 --> Controller Class Initialized
DEBUG - 2021-02-26 13:42:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-02-26 13:42:30 --> Final output sent to browser
DEBUG - 2021-02-26 13:42:30 --> Total execution time: 1.3123
INFO - 2021-02-26 13:42:56 --> Config Class Initialized
INFO - 2021-02-26 13:42:56 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:42:56 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:42:56 --> Utf8 Class Initialized
INFO - 2021-02-26 13:42:56 --> URI Class Initialized
INFO - 2021-02-26 13:42:56 --> Router Class Initialized
INFO - 2021-02-26 13:42:56 --> Output Class Initialized
INFO - 2021-02-26 13:42:56 --> Security Class Initialized
DEBUG - 2021-02-26 13:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:42:57 --> Input Class Initialized
INFO - 2021-02-26 13:42:57 --> Language Class Initialized
INFO - 2021-02-26 13:42:57 --> Language Class Initialized
INFO - 2021-02-26 13:42:57 --> Config Class Initialized
INFO - 2021-02-26 13:42:57 --> Loader Class Initialized
INFO - 2021-02-26 13:42:57 --> Helper loaded: url_helper
INFO - 2021-02-26 13:42:57 --> Helper loaded: file_helper
INFO - 2021-02-26 13:42:57 --> Helper loaded: form_helper
INFO - 2021-02-26 13:42:57 --> Helper loaded: my_helper
INFO - 2021-02-26 13:42:57 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:42:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:42:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:42:57 --> Controller Class Initialized
DEBUG - 2021-02-26 13:42:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-02-26 13:42:57 --> Final output sent to browser
DEBUG - 2021-02-26 13:42:57 --> Total execution time: 1.3962
INFO - 2021-02-26 13:43:11 --> Config Class Initialized
INFO - 2021-02-26 13:43:11 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:43:11 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:43:11 --> Utf8 Class Initialized
INFO - 2021-02-26 13:43:11 --> URI Class Initialized
INFO - 2021-02-26 13:43:11 --> Router Class Initialized
INFO - 2021-02-26 13:43:11 --> Output Class Initialized
INFO - 2021-02-26 13:43:11 --> Security Class Initialized
DEBUG - 2021-02-26 13:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:43:11 --> Input Class Initialized
INFO - 2021-02-26 13:43:11 --> Language Class Initialized
INFO - 2021-02-26 13:43:11 --> Language Class Initialized
INFO - 2021-02-26 13:43:11 --> Config Class Initialized
INFO - 2021-02-26 13:43:11 --> Loader Class Initialized
INFO - 2021-02-26 13:43:12 --> Helper loaded: url_helper
INFO - 2021-02-26 13:43:12 --> Helper loaded: file_helper
INFO - 2021-02-26 13:43:12 --> Helper loaded: form_helper
INFO - 2021-02-26 13:43:12 --> Helper loaded: my_helper
INFO - 2021-02-26 13:43:12 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:43:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:43:12 --> Controller Class Initialized
DEBUG - 2021-02-26 13:43:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-02-26 13:43:12 --> Final output sent to browser
DEBUG - 2021-02-26 13:43:12 --> Total execution time: 1.3395
INFO - 2021-02-26 13:43:45 --> Config Class Initialized
INFO - 2021-02-26 13:43:45 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:43:45 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:43:45 --> Utf8 Class Initialized
INFO - 2021-02-26 13:43:45 --> URI Class Initialized
INFO - 2021-02-26 13:43:46 --> Router Class Initialized
INFO - 2021-02-26 13:43:46 --> Output Class Initialized
INFO - 2021-02-26 13:43:46 --> Security Class Initialized
DEBUG - 2021-02-26 13:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:43:46 --> Input Class Initialized
INFO - 2021-02-26 13:43:46 --> Language Class Initialized
INFO - 2021-02-26 13:43:46 --> Language Class Initialized
INFO - 2021-02-26 13:43:46 --> Config Class Initialized
INFO - 2021-02-26 13:43:46 --> Loader Class Initialized
INFO - 2021-02-26 13:43:46 --> Helper loaded: url_helper
INFO - 2021-02-26 13:43:46 --> Helper loaded: file_helper
INFO - 2021-02-26 13:43:46 --> Helper loaded: form_helper
INFO - 2021-02-26 13:43:46 --> Helper loaded: my_helper
INFO - 2021-02-26 13:43:46 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:43:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:43:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:43:46 --> Controller Class Initialized
DEBUG - 2021-02-26 13:43:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-02-26 13:43:47 --> Final output sent to browser
DEBUG - 2021-02-26 13:43:47 --> Total execution time: 1.2821
INFO - 2021-02-26 13:44:11 --> Config Class Initialized
INFO - 2021-02-26 13:44:11 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:44:11 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:44:11 --> Utf8 Class Initialized
INFO - 2021-02-26 13:44:11 --> URI Class Initialized
INFO - 2021-02-26 13:44:11 --> Router Class Initialized
INFO - 2021-02-26 13:44:11 --> Output Class Initialized
INFO - 2021-02-26 13:44:11 --> Security Class Initialized
DEBUG - 2021-02-26 13:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:44:11 --> Input Class Initialized
INFO - 2021-02-26 13:44:11 --> Language Class Initialized
INFO - 2021-02-26 13:44:12 --> Language Class Initialized
INFO - 2021-02-26 13:44:12 --> Config Class Initialized
INFO - 2021-02-26 13:44:12 --> Loader Class Initialized
INFO - 2021-02-26 13:44:12 --> Helper loaded: url_helper
INFO - 2021-02-26 13:44:12 --> Helper loaded: file_helper
INFO - 2021-02-26 13:44:12 --> Helper loaded: form_helper
INFO - 2021-02-26 13:44:12 --> Helper loaded: my_helper
INFO - 2021-02-26 13:44:12 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:44:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:44:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:44:12 --> Controller Class Initialized
DEBUG - 2021-02-26 13:44:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-02-26 13:44:12 --> Final output sent to browser
DEBUG - 2021-02-26 13:44:12 --> Total execution time: 1.2318
INFO - 2021-02-26 13:44:57 --> Config Class Initialized
INFO - 2021-02-26 13:44:57 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:44:57 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:44:57 --> Utf8 Class Initialized
INFO - 2021-02-26 13:44:57 --> URI Class Initialized
INFO - 2021-02-26 13:44:57 --> Router Class Initialized
INFO - 2021-02-26 13:44:57 --> Output Class Initialized
INFO - 2021-02-26 13:44:57 --> Security Class Initialized
DEBUG - 2021-02-26 13:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:44:57 --> Input Class Initialized
INFO - 2021-02-26 13:44:57 --> Language Class Initialized
INFO - 2021-02-26 13:44:57 --> Language Class Initialized
INFO - 2021-02-26 13:44:57 --> Config Class Initialized
INFO - 2021-02-26 13:44:57 --> Loader Class Initialized
INFO - 2021-02-26 13:44:57 --> Helper loaded: url_helper
INFO - 2021-02-26 13:44:57 --> Helper loaded: file_helper
INFO - 2021-02-26 13:44:58 --> Helper loaded: form_helper
INFO - 2021-02-26 13:44:58 --> Helper loaded: my_helper
INFO - 2021-02-26 13:44:58 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:44:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:44:58 --> Controller Class Initialized
DEBUG - 2021-02-26 13:44:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-02-26 13:44:58 --> Final output sent to browser
DEBUG - 2021-02-26 13:44:58 --> Total execution time: 1.2127
INFO - 2021-02-26 13:45:26 --> Config Class Initialized
INFO - 2021-02-26 13:45:26 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:45:26 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:45:26 --> Utf8 Class Initialized
INFO - 2021-02-26 13:45:26 --> URI Class Initialized
INFO - 2021-02-26 13:45:26 --> Router Class Initialized
INFO - 2021-02-26 13:45:26 --> Output Class Initialized
INFO - 2021-02-26 13:45:26 --> Security Class Initialized
DEBUG - 2021-02-26 13:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:45:26 --> Input Class Initialized
INFO - 2021-02-26 13:45:26 --> Language Class Initialized
INFO - 2021-02-26 13:45:26 --> Language Class Initialized
INFO - 2021-02-26 13:45:27 --> Config Class Initialized
INFO - 2021-02-26 13:45:27 --> Loader Class Initialized
INFO - 2021-02-26 13:45:27 --> Helper loaded: url_helper
INFO - 2021-02-26 13:45:27 --> Helper loaded: file_helper
INFO - 2021-02-26 13:45:27 --> Helper loaded: form_helper
INFO - 2021-02-26 13:45:27 --> Helper loaded: my_helper
INFO - 2021-02-26 13:45:27 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:45:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:45:27 --> Controller Class Initialized
DEBUG - 2021-02-26 13:45:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-02-26 13:45:27 --> Final output sent to browser
DEBUG - 2021-02-26 13:45:27 --> Total execution time: 1.2092
INFO - 2021-02-26 13:46:05 --> Config Class Initialized
INFO - 2021-02-26 13:46:05 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:46:05 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:46:05 --> Utf8 Class Initialized
INFO - 2021-02-26 13:46:05 --> URI Class Initialized
INFO - 2021-02-26 13:46:05 --> Router Class Initialized
INFO - 2021-02-26 13:46:05 --> Output Class Initialized
INFO - 2021-02-26 13:46:05 --> Security Class Initialized
DEBUG - 2021-02-26 13:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:46:05 --> Input Class Initialized
INFO - 2021-02-26 13:46:05 --> Language Class Initialized
INFO - 2021-02-26 13:46:05 --> Language Class Initialized
INFO - 2021-02-26 13:46:05 --> Config Class Initialized
INFO - 2021-02-26 13:46:06 --> Loader Class Initialized
INFO - 2021-02-26 13:46:06 --> Helper loaded: url_helper
INFO - 2021-02-26 13:46:06 --> Helper loaded: file_helper
INFO - 2021-02-26 13:46:06 --> Helper loaded: form_helper
INFO - 2021-02-26 13:46:06 --> Helper loaded: my_helper
INFO - 2021-02-26 13:46:06 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:46:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:46:06 --> Controller Class Initialized
DEBUG - 2021-02-26 13:46:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-02-26 13:46:06 --> Final output sent to browser
DEBUG - 2021-02-26 13:46:06 --> Total execution time: 1.3308
INFO - 2021-02-26 13:47:07 --> Config Class Initialized
INFO - 2021-02-26 13:47:07 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:47:07 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:47:07 --> Utf8 Class Initialized
INFO - 2021-02-26 13:47:07 --> URI Class Initialized
INFO - 2021-02-26 13:47:07 --> Router Class Initialized
INFO - 2021-02-26 13:47:07 --> Output Class Initialized
INFO - 2021-02-26 13:47:07 --> Security Class Initialized
DEBUG - 2021-02-26 13:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:47:07 --> Input Class Initialized
INFO - 2021-02-26 13:47:07 --> Language Class Initialized
INFO - 2021-02-26 13:47:07 --> Language Class Initialized
INFO - 2021-02-26 13:47:07 --> Config Class Initialized
INFO - 2021-02-26 13:47:07 --> Loader Class Initialized
INFO - 2021-02-26 13:47:07 --> Helper loaded: url_helper
INFO - 2021-02-26 13:47:08 --> Helper loaded: file_helper
INFO - 2021-02-26 13:47:08 --> Helper loaded: form_helper
INFO - 2021-02-26 13:47:08 --> Helper loaded: my_helper
INFO - 2021-02-26 13:47:08 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:47:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:47:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:47:08 --> Controller Class Initialized
DEBUG - 2021-02-26 13:47:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-02-26 13:47:08 --> Final output sent to browser
DEBUG - 2021-02-26 13:47:08 --> Total execution time: 1.1142
INFO - 2021-02-26 13:49:06 --> Config Class Initialized
INFO - 2021-02-26 13:49:06 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:49:06 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:49:06 --> Utf8 Class Initialized
INFO - 2021-02-26 13:49:06 --> URI Class Initialized
INFO - 2021-02-26 13:49:06 --> Router Class Initialized
INFO - 2021-02-26 13:49:06 --> Output Class Initialized
INFO - 2021-02-26 13:49:06 --> Security Class Initialized
DEBUG - 2021-02-26 13:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:49:06 --> Input Class Initialized
INFO - 2021-02-26 13:49:06 --> Language Class Initialized
INFO - 2021-02-26 13:49:06 --> Language Class Initialized
INFO - 2021-02-26 13:49:06 --> Config Class Initialized
INFO - 2021-02-26 13:49:06 --> Loader Class Initialized
INFO - 2021-02-26 13:49:06 --> Helper loaded: url_helper
INFO - 2021-02-26 13:49:06 --> Helper loaded: file_helper
INFO - 2021-02-26 13:49:06 --> Helper loaded: form_helper
INFO - 2021-02-26 13:49:07 --> Helper loaded: my_helper
INFO - 2021-02-26 13:49:07 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:49:07 --> Controller Class Initialized
DEBUG - 2021-02-26 13:49:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-02-26 13:49:07 --> Final output sent to browser
DEBUG - 2021-02-26 13:49:07 --> Total execution time: 1.1769
INFO - 2021-02-26 13:49:21 --> Config Class Initialized
INFO - 2021-02-26 13:49:21 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:49:21 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:49:21 --> Utf8 Class Initialized
INFO - 2021-02-26 13:49:21 --> URI Class Initialized
INFO - 2021-02-26 13:49:21 --> Router Class Initialized
INFO - 2021-02-26 13:49:21 --> Output Class Initialized
INFO - 2021-02-26 13:49:21 --> Security Class Initialized
DEBUG - 2021-02-26 13:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:49:22 --> Input Class Initialized
INFO - 2021-02-26 13:49:22 --> Language Class Initialized
INFO - 2021-02-26 13:49:22 --> Language Class Initialized
INFO - 2021-02-26 13:49:22 --> Config Class Initialized
INFO - 2021-02-26 13:49:22 --> Loader Class Initialized
INFO - 2021-02-26 13:49:22 --> Helper loaded: url_helper
INFO - 2021-02-26 13:49:22 --> Helper loaded: file_helper
INFO - 2021-02-26 13:49:22 --> Helper loaded: form_helper
INFO - 2021-02-26 13:49:22 --> Helper loaded: my_helper
INFO - 2021-02-26 13:49:22 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:49:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:49:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:49:22 --> Controller Class Initialized
DEBUG - 2021-02-26 13:49:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-02-26 13:49:23 --> Final output sent to browser
DEBUG - 2021-02-26 13:49:23 --> Total execution time: 1.4086
INFO - 2021-02-26 13:49:40 --> Config Class Initialized
INFO - 2021-02-26 13:49:40 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:49:40 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:49:40 --> Utf8 Class Initialized
INFO - 2021-02-26 13:49:40 --> URI Class Initialized
INFO - 2021-02-26 13:49:40 --> Router Class Initialized
INFO - 2021-02-26 13:49:41 --> Output Class Initialized
INFO - 2021-02-26 13:49:41 --> Security Class Initialized
DEBUG - 2021-02-26 13:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:49:41 --> Input Class Initialized
INFO - 2021-02-26 13:49:41 --> Language Class Initialized
INFO - 2021-02-26 13:49:41 --> Language Class Initialized
INFO - 2021-02-26 13:49:41 --> Config Class Initialized
INFO - 2021-02-26 13:49:41 --> Loader Class Initialized
INFO - 2021-02-26 13:49:41 --> Helper loaded: url_helper
INFO - 2021-02-26 13:49:41 --> Helper loaded: file_helper
INFO - 2021-02-26 13:49:41 --> Helper loaded: form_helper
INFO - 2021-02-26 13:49:41 --> Helper loaded: my_helper
INFO - 2021-02-26 13:49:41 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:49:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:49:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:49:41 --> Controller Class Initialized
INFO - 2021-02-26 13:49:41 --> Helper loaded: cookie_helper
INFO - 2021-02-26 13:49:41 --> Config Class Initialized
INFO - 2021-02-26 13:49:41 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:49:41 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:49:41 --> Utf8 Class Initialized
INFO - 2021-02-26 13:49:41 --> URI Class Initialized
INFO - 2021-02-26 13:49:41 --> Router Class Initialized
INFO - 2021-02-26 13:49:41 --> Output Class Initialized
INFO - 2021-02-26 13:49:41 --> Security Class Initialized
DEBUG - 2021-02-26 13:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:49:41 --> Input Class Initialized
INFO - 2021-02-26 13:49:41 --> Language Class Initialized
INFO - 2021-02-26 13:49:42 --> Language Class Initialized
INFO - 2021-02-26 13:49:42 --> Config Class Initialized
INFO - 2021-02-26 13:49:42 --> Loader Class Initialized
INFO - 2021-02-26 13:49:42 --> Helper loaded: url_helper
INFO - 2021-02-26 13:49:42 --> Helper loaded: file_helper
INFO - 2021-02-26 13:49:42 --> Helper loaded: form_helper
INFO - 2021-02-26 13:49:42 --> Helper loaded: my_helper
INFO - 2021-02-26 13:49:42 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:49:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:49:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:49:42 --> Controller Class Initialized
DEBUG - 2021-02-26 13:49:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-02-26 13:49:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 13:49:42 --> Final output sent to browser
DEBUG - 2021-02-26 13:49:42 --> Total execution time: 0.8124
INFO - 2021-02-26 13:49:52 --> Config Class Initialized
INFO - 2021-02-26 13:49:52 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:49:52 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:49:52 --> Utf8 Class Initialized
INFO - 2021-02-26 13:49:52 --> URI Class Initialized
INFO - 2021-02-26 13:49:53 --> Router Class Initialized
INFO - 2021-02-26 13:49:53 --> Output Class Initialized
INFO - 2021-02-26 13:49:53 --> Security Class Initialized
DEBUG - 2021-02-26 13:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:49:53 --> Input Class Initialized
INFO - 2021-02-26 13:49:53 --> Language Class Initialized
INFO - 2021-02-26 13:49:53 --> Language Class Initialized
INFO - 2021-02-26 13:49:53 --> Config Class Initialized
INFO - 2021-02-26 13:49:53 --> Loader Class Initialized
INFO - 2021-02-26 13:49:53 --> Helper loaded: url_helper
INFO - 2021-02-26 13:49:53 --> Helper loaded: file_helper
INFO - 2021-02-26 13:49:53 --> Helper loaded: form_helper
INFO - 2021-02-26 13:49:53 --> Helper loaded: my_helper
INFO - 2021-02-26 13:49:53 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:49:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:49:53 --> Controller Class Initialized
INFO - 2021-02-26 13:49:53 --> Helper loaded: cookie_helper
INFO - 2021-02-26 13:49:53 --> Final output sent to browser
DEBUG - 2021-02-26 13:49:53 --> Total execution time: 0.9999
INFO - 2021-02-26 13:49:54 --> Config Class Initialized
INFO - 2021-02-26 13:49:54 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:49:54 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:49:54 --> Utf8 Class Initialized
INFO - 2021-02-26 13:49:54 --> URI Class Initialized
INFO - 2021-02-26 13:49:54 --> Router Class Initialized
INFO - 2021-02-26 13:49:54 --> Output Class Initialized
INFO - 2021-02-26 13:49:54 --> Security Class Initialized
DEBUG - 2021-02-26 13:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:49:54 --> Input Class Initialized
INFO - 2021-02-26 13:49:54 --> Language Class Initialized
INFO - 2021-02-26 13:49:54 --> Language Class Initialized
INFO - 2021-02-26 13:49:55 --> Config Class Initialized
INFO - 2021-02-26 13:49:55 --> Loader Class Initialized
INFO - 2021-02-26 13:49:55 --> Helper loaded: url_helper
INFO - 2021-02-26 13:49:55 --> Helper loaded: file_helper
INFO - 2021-02-26 13:49:55 --> Helper loaded: form_helper
INFO - 2021-02-26 13:49:55 --> Helper loaded: my_helper
INFO - 2021-02-26 13:49:55 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:49:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:49:55 --> Controller Class Initialized
DEBUG - 2021-02-26 13:49:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-02-26 13:49:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 13:49:55 --> Final output sent to browser
DEBUG - 2021-02-26 13:49:55 --> Total execution time: 1.1655
INFO - 2021-02-26 13:49:57 --> Config Class Initialized
INFO - 2021-02-26 13:49:57 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:49:57 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:49:57 --> Utf8 Class Initialized
INFO - 2021-02-26 13:49:57 --> URI Class Initialized
INFO - 2021-02-26 13:49:57 --> Router Class Initialized
INFO - 2021-02-26 13:49:57 --> Output Class Initialized
INFO - 2021-02-26 13:49:57 --> Security Class Initialized
DEBUG - 2021-02-26 13:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:49:57 --> Input Class Initialized
INFO - 2021-02-26 13:49:57 --> Language Class Initialized
INFO - 2021-02-26 13:49:57 --> Language Class Initialized
INFO - 2021-02-26 13:49:57 --> Config Class Initialized
INFO - 2021-02-26 13:49:57 --> Loader Class Initialized
INFO - 2021-02-26 13:49:57 --> Helper loaded: url_helper
INFO - 2021-02-26 13:49:57 --> Helper loaded: file_helper
INFO - 2021-02-26 13:49:57 --> Helper loaded: form_helper
INFO - 2021-02-26 13:49:57 --> Helper loaded: my_helper
INFO - 2021-02-26 13:49:57 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:49:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:49:57 --> Controller Class Initialized
DEBUG - 2021-02-26 13:49:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-02-26 13:49:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 13:49:58 --> Final output sent to browser
DEBUG - 2021-02-26 13:49:58 --> Total execution time: 1.1015
INFO - 2021-02-26 13:50:00 --> Config Class Initialized
INFO - 2021-02-26 13:50:00 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:50:00 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:50:00 --> Utf8 Class Initialized
INFO - 2021-02-26 13:50:00 --> URI Class Initialized
INFO - 2021-02-26 13:50:00 --> Router Class Initialized
INFO - 2021-02-26 13:50:00 --> Output Class Initialized
INFO - 2021-02-26 13:50:00 --> Security Class Initialized
DEBUG - 2021-02-26 13:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:50:00 --> Input Class Initialized
INFO - 2021-02-26 13:50:00 --> Language Class Initialized
INFO - 2021-02-26 13:50:00 --> Language Class Initialized
INFO - 2021-02-26 13:50:01 --> Config Class Initialized
INFO - 2021-02-26 13:50:01 --> Loader Class Initialized
INFO - 2021-02-26 13:50:01 --> Helper loaded: url_helper
INFO - 2021-02-26 13:50:01 --> Helper loaded: file_helper
INFO - 2021-02-26 13:50:01 --> Helper loaded: form_helper
INFO - 2021-02-26 13:50:01 --> Helper loaded: my_helper
INFO - 2021-02-26 13:50:01 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:50:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:50:01 --> Controller Class Initialized
DEBUG - 2021-02-26 13:50:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-02-26 13:50:01 --> Final output sent to browser
DEBUG - 2021-02-26 13:50:01 --> Total execution time: 1.0167
INFO - 2021-02-26 13:50:57 --> Config Class Initialized
INFO - 2021-02-26 13:50:57 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:50:57 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:50:57 --> Utf8 Class Initialized
INFO - 2021-02-26 13:50:57 --> URI Class Initialized
INFO - 2021-02-26 13:50:57 --> Router Class Initialized
INFO - 2021-02-26 13:50:57 --> Output Class Initialized
INFO - 2021-02-26 13:50:57 --> Security Class Initialized
DEBUG - 2021-02-26 13:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:50:57 --> Input Class Initialized
INFO - 2021-02-26 13:50:58 --> Language Class Initialized
INFO - 2021-02-26 13:50:58 --> Language Class Initialized
INFO - 2021-02-26 13:50:58 --> Config Class Initialized
INFO - 2021-02-26 13:50:58 --> Loader Class Initialized
INFO - 2021-02-26 13:50:58 --> Helper loaded: url_helper
INFO - 2021-02-26 13:50:58 --> Helper loaded: file_helper
INFO - 2021-02-26 13:50:58 --> Helper loaded: form_helper
INFO - 2021-02-26 13:50:58 --> Helper loaded: my_helper
INFO - 2021-02-26 13:50:58 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:50:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:50:58 --> Controller Class Initialized
DEBUG - 2021-02-26 13:50:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-02-26 13:50:58 --> Final output sent to browser
DEBUG - 2021-02-26 13:50:59 --> Total execution time: 1.5139
INFO - 2021-02-26 13:51:34 --> Config Class Initialized
INFO - 2021-02-26 13:51:34 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:51:34 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:51:34 --> Utf8 Class Initialized
INFO - 2021-02-26 13:51:34 --> URI Class Initialized
INFO - 2021-02-26 13:51:34 --> Router Class Initialized
INFO - 2021-02-26 13:51:34 --> Output Class Initialized
INFO - 2021-02-26 13:51:34 --> Security Class Initialized
DEBUG - 2021-02-26 13:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:51:34 --> Input Class Initialized
INFO - 2021-02-26 13:51:34 --> Language Class Initialized
INFO - 2021-02-26 13:51:34 --> Language Class Initialized
INFO - 2021-02-26 13:51:34 --> Config Class Initialized
INFO - 2021-02-26 13:51:34 --> Loader Class Initialized
INFO - 2021-02-26 13:51:34 --> Helper loaded: url_helper
INFO - 2021-02-26 13:51:34 --> Helper loaded: file_helper
INFO - 2021-02-26 13:51:34 --> Helper loaded: form_helper
INFO - 2021-02-26 13:51:34 --> Helper loaded: my_helper
INFO - 2021-02-26 13:51:35 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:51:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:51:35 --> Controller Class Initialized
DEBUG - 2021-02-26 13:51:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-02-26 13:51:35 --> Final output sent to browser
DEBUG - 2021-02-26 13:51:35 --> Total execution time: 1.3586
INFO - 2021-02-26 13:51:52 --> Config Class Initialized
INFO - 2021-02-26 13:51:52 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:51:52 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:51:52 --> Utf8 Class Initialized
INFO - 2021-02-26 13:51:52 --> URI Class Initialized
INFO - 2021-02-26 13:51:52 --> Router Class Initialized
INFO - 2021-02-26 13:51:52 --> Output Class Initialized
INFO - 2021-02-26 13:51:52 --> Security Class Initialized
DEBUG - 2021-02-26 13:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:51:52 --> Input Class Initialized
INFO - 2021-02-26 13:51:53 --> Language Class Initialized
INFO - 2021-02-26 13:51:53 --> Language Class Initialized
INFO - 2021-02-26 13:51:53 --> Config Class Initialized
INFO - 2021-02-26 13:51:53 --> Loader Class Initialized
INFO - 2021-02-26 13:51:53 --> Helper loaded: url_helper
INFO - 2021-02-26 13:51:53 --> Helper loaded: file_helper
INFO - 2021-02-26 13:51:53 --> Helper loaded: form_helper
INFO - 2021-02-26 13:51:53 --> Helper loaded: my_helper
INFO - 2021-02-26 13:51:53 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:51:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:51:53 --> Controller Class Initialized
DEBUG - 2021-02-26 13:51:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-02-26 13:51:53 --> Final output sent to browser
DEBUG - 2021-02-26 13:51:53 --> Total execution time: 1.3519
INFO - 2021-02-26 13:52:08 --> Config Class Initialized
INFO - 2021-02-26 13:52:08 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:52:08 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:52:09 --> Utf8 Class Initialized
INFO - 2021-02-26 13:52:09 --> URI Class Initialized
INFO - 2021-02-26 13:52:09 --> Router Class Initialized
INFO - 2021-02-26 13:52:09 --> Output Class Initialized
INFO - 2021-02-26 13:52:09 --> Security Class Initialized
DEBUG - 2021-02-26 13:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:52:09 --> Input Class Initialized
INFO - 2021-02-26 13:52:09 --> Language Class Initialized
INFO - 2021-02-26 13:52:09 --> Language Class Initialized
INFO - 2021-02-26 13:52:09 --> Config Class Initialized
INFO - 2021-02-26 13:52:09 --> Loader Class Initialized
INFO - 2021-02-26 13:52:09 --> Helper loaded: url_helper
INFO - 2021-02-26 13:52:09 --> Helper loaded: file_helper
INFO - 2021-02-26 13:52:09 --> Helper loaded: form_helper
INFO - 2021-02-26 13:52:09 --> Helper loaded: my_helper
INFO - 2021-02-26 13:52:09 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:52:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:52:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:52:09 --> Controller Class Initialized
INFO - 2021-02-26 13:52:09 --> Helper loaded: cookie_helper
INFO - 2021-02-26 13:52:09 --> Config Class Initialized
INFO - 2021-02-26 13:52:09 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:52:09 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:52:09 --> Utf8 Class Initialized
INFO - 2021-02-26 13:52:09 --> URI Class Initialized
INFO - 2021-02-26 13:52:09 --> Router Class Initialized
INFO - 2021-02-26 13:52:10 --> Output Class Initialized
INFO - 2021-02-26 13:52:10 --> Security Class Initialized
DEBUG - 2021-02-26 13:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:52:10 --> Input Class Initialized
INFO - 2021-02-26 13:52:10 --> Language Class Initialized
INFO - 2021-02-26 13:52:10 --> Language Class Initialized
INFO - 2021-02-26 13:52:10 --> Config Class Initialized
INFO - 2021-02-26 13:52:10 --> Loader Class Initialized
INFO - 2021-02-26 13:52:10 --> Helper loaded: url_helper
INFO - 2021-02-26 13:52:10 --> Helper loaded: file_helper
INFO - 2021-02-26 13:52:10 --> Helper loaded: form_helper
INFO - 2021-02-26 13:52:10 --> Helper loaded: my_helper
INFO - 2021-02-26 13:52:10 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:52:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:52:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:52:10 --> Controller Class Initialized
DEBUG - 2021-02-26 13:52:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-02-26 13:52:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 13:52:11 --> Final output sent to browser
DEBUG - 2021-02-26 13:52:11 --> Total execution time: 1.2692
INFO - 2021-02-26 13:52:18 --> Config Class Initialized
INFO - 2021-02-26 13:52:18 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:52:19 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:52:19 --> Utf8 Class Initialized
INFO - 2021-02-26 13:52:19 --> URI Class Initialized
INFO - 2021-02-26 13:52:19 --> Router Class Initialized
INFO - 2021-02-26 13:52:19 --> Output Class Initialized
INFO - 2021-02-26 13:52:19 --> Security Class Initialized
DEBUG - 2021-02-26 13:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:52:19 --> Input Class Initialized
INFO - 2021-02-26 13:52:19 --> Language Class Initialized
INFO - 2021-02-26 13:52:19 --> Language Class Initialized
INFO - 2021-02-26 13:52:19 --> Config Class Initialized
INFO - 2021-02-26 13:52:19 --> Loader Class Initialized
INFO - 2021-02-26 13:52:19 --> Helper loaded: url_helper
INFO - 2021-02-26 13:52:19 --> Helper loaded: file_helper
INFO - 2021-02-26 13:52:19 --> Helper loaded: form_helper
INFO - 2021-02-26 13:52:19 --> Helper loaded: my_helper
INFO - 2021-02-26 13:52:19 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:52:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:52:20 --> Controller Class Initialized
INFO - 2021-02-26 13:52:20 --> Helper loaded: cookie_helper
INFO - 2021-02-26 13:52:20 --> Final output sent to browser
DEBUG - 2021-02-26 13:52:20 --> Total execution time: 1.2172
INFO - 2021-02-26 13:52:20 --> Config Class Initialized
INFO - 2021-02-26 13:52:20 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:52:20 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:52:20 --> Utf8 Class Initialized
INFO - 2021-02-26 13:52:20 --> URI Class Initialized
INFO - 2021-02-26 13:52:20 --> Router Class Initialized
INFO - 2021-02-26 13:52:20 --> Output Class Initialized
INFO - 2021-02-26 13:52:20 --> Security Class Initialized
DEBUG - 2021-02-26 13:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:52:21 --> Input Class Initialized
INFO - 2021-02-26 13:52:21 --> Language Class Initialized
INFO - 2021-02-26 13:52:21 --> Language Class Initialized
INFO - 2021-02-26 13:52:21 --> Config Class Initialized
INFO - 2021-02-26 13:52:21 --> Loader Class Initialized
INFO - 2021-02-26 13:52:21 --> Helper loaded: url_helper
INFO - 2021-02-26 13:52:21 --> Helper loaded: file_helper
INFO - 2021-02-26 13:52:21 --> Helper loaded: form_helper
INFO - 2021-02-26 13:52:21 --> Helper loaded: my_helper
INFO - 2021-02-26 13:52:21 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:52:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:52:21 --> Controller Class Initialized
DEBUG - 2021-02-26 13:52:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-02-26 13:52:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 13:52:21 --> Final output sent to browser
DEBUG - 2021-02-26 13:52:21 --> Total execution time: 1.1465
INFO - 2021-02-26 13:52:23 --> Config Class Initialized
INFO - 2021-02-26 13:52:23 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:52:23 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:52:23 --> Utf8 Class Initialized
INFO - 2021-02-26 13:52:24 --> URI Class Initialized
INFO - 2021-02-26 13:52:24 --> Router Class Initialized
INFO - 2021-02-26 13:52:24 --> Output Class Initialized
INFO - 2021-02-26 13:52:24 --> Security Class Initialized
DEBUG - 2021-02-26 13:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:52:24 --> Input Class Initialized
INFO - 2021-02-26 13:52:24 --> Language Class Initialized
INFO - 2021-02-26 13:52:24 --> Language Class Initialized
INFO - 2021-02-26 13:52:24 --> Config Class Initialized
INFO - 2021-02-26 13:52:24 --> Loader Class Initialized
INFO - 2021-02-26 13:52:24 --> Helper loaded: url_helper
INFO - 2021-02-26 13:52:24 --> Helper loaded: file_helper
INFO - 2021-02-26 13:52:24 --> Helper loaded: form_helper
INFO - 2021-02-26 13:52:24 --> Helper loaded: my_helper
INFO - 2021-02-26 13:52:24 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:52:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:52:24 --> Controller Class Initialized
DEBUG - 2021-02-26 13:52:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-02-26 13:52:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 13:52:24 --> Final output sent to browser
DEBUG - 2021-02-26 13:52:25 --> Total execution time: 1.0899
INFO - 2021-02-26 13:52:27 --> Config Class Initialized
INFO - 2021-02-26 13:52:27 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:52:27 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:52:27 --> Utf8 Class Initialized
INFO - 2021-02-26 13:52:27 --> URI Class Initialized
INFO - 2021-02-26 13:52:27 --> Router Class Initialized
INFO - 2021-02-26 13:52:27 --> Output Class Initialized
INFO - 2021-02-26 13:52:27 --> Security Class Initialized
DEBUG - 2021-02-26 13:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:52:27 --> Input Class Initialized
INFO - 2021-02-26 13:52:27 --> Language Class Initialized
INFO - 2021-02-26 13:52:27 --> Language Class Initialized
INFO - 2021-02-26 13:52:27 --> Config Class Initialized
INFO - 2021-02-26 13:52:27 --> Loader Class Initialized
INFO - 2021-02-26 13:52:27 --> Helper loaded: url_helper
INFO - 2021-02-26 13:52:27 --> Helper loaded: file_helper
INFO - 2021-02-26 13:52:28 --> Helper loaded: form_helper
INFO - 2021-02-26 13:52:28 --> Helper loaded: my_helper
INFO - 2021-02-26 13:52:28 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:52:28 --> Controller Class Initialized
DEBUG - 2021-02-26 13:52:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-02-26 13:52:28 --> Final output sent to browser
DEBUG - 2021-02-26 13:52:28 --> Total execution time: 1.2242
INFO - 2021-02-26 13:53:16 --> Config Class Initialized
INFO - 2021-02-26 13:53:16 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:53:16 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:53:16 --> Utf8 Class Initialized
INFO - 2021-02-26 13:53:16 --> URI Class Initialized
INFO - 2021-02-26 13:53:16 --> Router Class Initialized
INFO - 2021-02-26 13:53:16 --> Output Class Initialized
INFO - 2021-02-26 13:53:16 --> Security Class Initialized
DEBUG - 2021-02-26 13:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:53:16 --> Input Class Initialized
INFO - 2021-02-26 13:53:16 --> Language Class Initialized
INFO - 2021-02-26 13:53:16 --> Language Class Initialized
INFO - 2021-02-26 13:53:16 --> Config Class Initialized
INFO - 2021-02-26 13:53:16 --> Loader Class Initialized
INFO - 2021-02-26 13:53:16 --> Helper loaded: url_helper
INFO - 2021-02-26 13:53:16 --> Helper loaded: file_helper
INFO - 2021-02-26 13:53:17 --> Helper loaded: form_helper
INFO - 2021-02-26 13:53:17 --> Helper loaded: my_helper
INFO - 2021-02-26 13:53:17 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:53:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:53:17 --> Controller Class Initialized
DEBUG - 2021-02-26 13:53:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-02-26 13:53:17 --> Final output sent to browser
DEBUG - 2021-02-26 13:53:17 --> Total execution time: 1.4907
INFO - 2021-02-26 13:53:40 --> Config Class Initialized
INFO - 2021-02-26 13:53:40 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:53:40 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:53:41 --> Utf8 Class Initialized
INFO - 2021-02-26 13:53:41 --> URI Class Initialized
INFO - 2021-02-26 13:53:41 --> Router Class Initialized
INFO - 2021-02-26 13:53:41 --> Output Class Initialized
INFO - 2021-02-26 13:53:41 --> Security Class Initialized
DEBUG - 2021-02-26 13:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:53:41 --> Input Class Initialized
INFO - 2021-02-26 13:53:41 --> Language Class Initialized
INFO - 2021-02-26 13:53:41 --> Language Class Initialized
INFO - 2021-02-26 13:53:41 --> Config Class Initialized
INFO - 2021-02-26 13:53:41 --> Loader Class Initialized
INFO - 2021-02-26 13:53:41 --> Helper loaded: url_helper
INFO - 2021-02-26 13:53:41 --> Helper loaded: file_helper
INFO - 2021-02-26 13:53:41 --> Helper loaded: form_helper
INFO - 2021-02-26 13:53:41 --> Helper loaded: my_helper
INFO - 2021-02-26 13:53:41 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:53:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:53:41 --> Controller Class Initialized
DEBUG - 2021-02-26 13:53:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-02-26 13:53:42 --> Final output sent to browser
DEBUG - 2021-02-26 13:53:42 --> Total execution time: 1.3672
INFO - 2021-02-26 13:53:54 --> Config Class Initialized
INFO - 2021-02-26 13:53:54 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:53:54 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:53:54 --> Utf8 Class Initialized
INFO - 2021-02-26 13:53:54 --> URI Class Initialized
INFO - 2021-02-26 13:53:54 --> Router Class Initialized
INFO - 2021-02-26 13:53:55 --> Output Class Initialized
INFO - 2021-02-26 13:53:55 --> Security Class Initialized
DEBUG - 2021-02-26 13:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:53:55 --> Input Class Initialized
INFO - 2021-02-26 13:53:55 --> Language Class Initialized
INFO - 2021-02-26 13:53:55 --> Language Class Initialized
INFO - 2021-02-26 13:53:55 --> Config Class Initialized
INFO - 2021-02-26 13:53:55 --> Loader Class Initialized
INFO - 2021-02-26 13:53:55 --> Helper loaded: url_helper
INFO - 2021-02-26 13:53:55 --> Helper loaded: file_helper
INFO - 2021-02-26 13:53:55 --> Helper loaded: form_helper
INFO - 2021-02-26 13:53:55 --> Helper loaded: my_helper
INFO - 2021-02-26 13:53:55 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:53:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:53:55 --> Controller Class Initialized
DEBUG - 2021-02-26 13:53:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-02-26 13:53:56 --> Final output sent to browser
DEBUG - 2021-02-26 13:53:56 --> Total execution time: 1.4669
INFO - 2021-02-26 13:54:24 --> Config Class Initialized
INFO - 2021-02-26 13:54:24 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:54:24 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:54:24 --> Utf8 Class Initialized
INFO - 2021-02-26 13:54:24 --> URI Class Initialized
INFO - 2021-02-26 13:54:25 --> Router Class Initialized
INFO - 2021-02-26 13:54:25 --> Output Class Initialized
INFO - 2021-02-26 13:54:25 --> Security Class Initialized
DEBUG - 2021-02-26 13:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:54:25 --> Input Class Initialized
INFO - 2021-02-26 13:54:25 --> Language Class Initialized
INFO - 2021-02-26 13:54:25 --> Language Class Initialized
INFO - 2021-02-26 13:54:25 --> Config Class Initialized
INFO - 2021-02-26 13:54:25 --> Loader Class Initialized
INFO - 2021-02-26 13:54:25 --> Helper loaded: url_helper
INFO - 2021-02-26 13:54:25 --> Helper loaded: file_helper
INFO - 2021-02-26 13:54:25 --> Helper loaded: form_helper
INFO - 2021-02-26 13:54:25 --> Helper loaded: my_helper
INFO - 2021-02-26 13:54:25 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:54:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:54:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:54:25 --> Controller Class Initialized
DEBUG - 2021-02-26 13:54:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-02-26 13:54:26 --> Final output sent to browser
DEBUG - 2021-02-26 13:54:26 --> Total execution time: 1.3648
INFO - 2021-02-26 13:54:40 --> Config Class Initialized
INFO - 2021-02-26 13:54:40 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:54:41 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:54:41 --> Utf8 Class Initialized
INFO - 2021-02-26 13:54:41 --> URI Class Initialized
INFO - 2021-02-26 13:54:41 --> Router Class Initialized
INFO - 2021-02-26 13:54:41 --> Output Class Initialized
INFO - 2021-02-26 13:54:41 --> Security Class Initialized
DEBUG - 2021-02-26 13:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:54:41 --> Input Class Initialized
INFO - 2021-02-26 13:54:41 --> Language Class Initialized
INFO - 2021-02-26 13:54:41 --> Language Class Initialized
INFO - 2021-02-26 13:54:41 --> Config Class Initialized
INFO - 2021-02-26 13:54:41 --> Loader Class Initialized
INFO - 2021-02-26 13:54:41 --> Helper loaded: url_helper
INFO - 2021-02-26 13:54:41 --> Helper loaded: file_helper
INFO - 2021-02-26 13:54:41 --> Helper loaded: form_helper
INFO - 2021-02-26 13:54:41 --> Helper loaded: my_helper
INFO - 2021-02-26 13:54:41 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:54:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:54:42 --> Controller Class Initialized
DEBUG - 2021-02-26 13:54:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-02-26 13:54:42 --> Final output sent to browser
DEBUG - 2021-02-26 13:54:42 --> Total execution time: 1.3960
INFO - 2021-02-26 13:55:30 --> Config Class Initialized
INFO - 2021-02-26 13:55:30 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:55:30 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:55:30 --> Utf8 Class Initialized
INFO - 2021-02-26 13:55:31 --> URI Class Initialized
INFO - 2021-02-26 13:55:31 --> Router Class Initialized
INFO - 2021-02-26 13:55:31 --> Output Class Initialized
INFO - 2021-02-26 13:55:31 --> Security Class Initialized
DEBUG - 2021-02-26 13:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:55:31 --> Input Class Initialized
INFO - 2021-02-26 13:55:31 --> Language Class Initialized
INFO - 2021-02-26 13:55:31 --> Language Class Initialized
INFO - 2021-02-26 13:55:31 --> Config Class Initialized
INFO - 2021-02-26 13:55:31 --> Loader Class Initialized
INFO - 2021-02-26 13:55:31 --> Helper loaded: url_helper
INFO - 2021-02-26 13:55:31 --> Helper loaded: file_helper
INFO - 2021-02-26 13:55:31 --> Helper loaded: form_helper
INFO - 2021-02-26 13:55:31 --> Helper loaded: my_helper
INFO - 2021-02-26 13:55:31 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:55:31 --> Controller Class Initialized
INFO - 2021-02-26 13:55:31 --> Helper loaded: cookie_helper
INFO - 2021-02-26 13:55:31 --> Config Class Initialized
INFO - 2021-02-26 13:55:31 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:55:32 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:55:32 --> Utf8 Class Initialized
INFO - 2021-02-26 13:55:32 --> URI Class Initialized
INFO - 2021-02-26 13:55:32 --> Router Class Initialized
INFO - 2021-02-26 13:55:32 --> Output Class Initialized
INFO - 2021-02-26 13:55:32 --> Security Class Initialized
DEBUG - 2021-02-26 13:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:55:32 --> Input Class Initialized
INFO - 2021-02-26 13:55:32 --> Language Class Initialized
INFO - 2021-02-26 13:55:32 --> Language Class Initialized
INFO - 2021-02-26 13:55:32 --> Config Class Initialized
INFO - 2021-02-26 13:55:32 --> Loader Class Initialized
INFO - 2021-02-26 13:55:32 --> Helper loaded: url_helper
INFO - 2021-02-26 13:55:32 --> Helper loaded: file_helper
INFO - 2021-02-26 13:55:32 --> Helper loaded: form_helper
INFO - 2021-02-26 13:55:32 --> Helper loaded: my_helper
INFO - 2021-02-26 13:55:32 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:55:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:55:33 --> Controller Class Initialized
DEBUG - 2021-02-26 13:55:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-02-26 13:55:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 13:55:33 --> Final output sent to browser
DEBUG - 2021-02-26 13:55:33 --> Total execution time: 1.3237
INFO - 2021-02-26 13:55:37 --> Config Class Initialized
INFO - 2021-02-26 13:55:37 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:55:37 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:55:37 --> Utf8 Class Initialized
INFO - 2021-02-26 13:55:38 --> URI Class Initialized
INFO - 2021-02-26 13:55:38 --> Router Class Initialized
INFO - 2021-02-26 13:55:38 --> Output Class Initialized
INFO - 2021-02-26 13:55:38 --> Security Class Initialized
DEBUG - 2021-02-26 13:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:55:38 --> Input Class Initialized
INFO - 2021-02-26 13:55:38 --> Language Class Initialized
INFO - 2021-02-26 13:55:38 --> Language Class Initialized
INFO - 2021-02-26 13:55:38 --> Config Class Initialized
INFO - 2021-02-26 13:55:38 --> Loader Class Initialized
INFO - 2021-02-26 13:55:38 --> Helper loaded: url_helper
INFO - 2021-02-26 13:55:38 --> Helper loaded: file_helper
INFO - 2021-02-26 13:55:38 --> Helper loaded: form_helper
INFO - 2021-02-26 13:55:38 --> Helper loaded: my_helper
INFO - 2021-02-26 13:55:38 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:55:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:55:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:55:38 --> Controller Class Initialized
INFO - 2021-02-26 13:55:38 --> Helper loaded: cookie_helper
INFO - 2021-02-26 13:55:38 --> Final output sent to browser
DEBUG - 2021-02-26 13:55:38 --> Total execution time: 1.0626
INFO - 2021-02-26 13:55:39 --> Config Class Initialized
INFO - 2021-02-26 13:55:39 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:55:39 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:55:39 --> Utf8 Class Initialized
INFO - 2021-02-26 13:55:39 --> URI Class Initialized
INFO - 2021-02-26 13:55:39 --> Router Class Initialized
INFO - 2021-02-26 13:55:39 --> Output Class Initialized
INFO - 2021-02-26 13:55:39 --> Security Class Initialized
DEBUG - 2021-02-26 13:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:55:39 --> Input Class Initialized
INFO - 2021-02-26 13:55:39 --> Language Class Initialized
INFO - 2021-02-26 13:55:39 --> Language Class Initialized
INFO - 2021-02-26 13:55:39 --> Config Class Initialized
INFO - 2021-02-26 13:55:39 --> Loader Class Initialized
INFO - 2021-02-26 13:55:39 --> Helper loaded: url_helper
INFO - 2021-02-26 13:55:40 --> Helper loaded: file_helper
INFO - 2021-02-26 13:55:40 --> Helper loaded: form_helper
INFO - 2021-02-26 13:55:40 --> Helper loaded: my_helper
INFO - 2021-02-26 13:55:40 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:55:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:55:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:55:40 --> Controller Class Initialized
DEBUG - 2021-02-26 13:55:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-02-26 13:55:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 13:55:40 --> Final output sent to browser
DEBUG - 2021-02-26 13:55:40 --> Total execution time: 1.3593
INFO - 2021-02-26 13:55:42 --> Config Class Initialized
INFO - 2021-02-26 13:55:42 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:55:42 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:55:42 --> Utf8 Class Initialized
INFO - 2021-02-26 13:55:42 --> URI Class Initialized
INFO - 2021-02-26 13:55:42 --> Router Class Initialized
INFO - 2021-02-26 13:55:42 --> Output Class Initialized
INFO - 2021-02-26 13:55:42 --> Security Class Initialized
DEBUG - 2021-02-26 13:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:55:42 --> Input Class Initialized
INFO - 2021-02-26 13:55:42 --> Language Class Initialized
INFO - 2021-02-26 13:55:42 --> Language Class Initialized
INFO - 2021-02-26 13:55:42 --> Config Class Initialized
INFO - 2021-02-26 13:55:42 --> Loader Class Initialized
INFO - 2021-02-26 13:55:42 --> Helper loaded: url_helper
INFO - 2021-02-26 13:55:42 --> Helper loaded: file_helper
INFO - 2021-02-26 13:55:42 --> Helper loaded: form_helper
INFO - 2021-02-26 13:55:42 --> Helper loaded: my_helper
INFO - 2021-02-26 13:55:42 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:55:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:55:42 --> Controller Class Initialized
DEBUG - 2021-02-26 13:55:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-02-26 13:55:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 13:55:43 --> Final output sent to browser
DEBUG - 2021-02-26 13:55:43 --> Total execution time: 1.1213
INFO - 2021-02-26 13:55:44 --> Config Class Initialized
INFO - 2021-02-26 13:55:44 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:55:44 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:55:44 --> Utf8 Class Initialized
INFO - 2021-02-26 13:55:44 --> URI Class Initialized
INFO - 2021-02-26 13:55:44 --> Router Class Initialized
INFO - 2021-02-26 13:55:45 --> Output Class Initialized
INFO - 2021-02-26 13:55:45 --> Security Class Initialized
DEBUG - 2021-02-26 13:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:55:45 --> Input Class Initialized
INFO - 2021-02-26 13:55:45 --> Language Class Initialized
INFO - 2021-02-26 13:55:45 --> Language Class Initialized
INFO - 2021-02-26 13:55:45 --> Config Class Initialized
INFO - 2021-02-26 13:55:45 --> Loader Class Initialized
INFO - 2021-02-26 13:55:45 --> Helper loaded: url_helper
INFO - 2021-02-26 13:55:45 --> Helper loaded: file_helper
INFO - 2021-02-26 13:55:45 --> Helper loaded: form_helper
INFO - 2021-02-26 13:55:45 --> Helper loaded: my_helper
INFO - 2021-02-26 13:55:45 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:55:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:55:45 --> Controller Class Initialized
DEBUG - 2021-02-26 13:55:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2021-02-26 13:55:45 --> Final output sent to browser
DEBUG - 2021-02-26 13:55:46 --> Total execution time: 1.1481
INFO - 2021-02-26 13:56:51 --> Config Class Initialized
INFO - 2021-02-26 13:56:51 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:56:51 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:56:51 --> Utf8 Class Initialized
INFO - 2021-02-26 13:56:51 --> URI Class Initialized
INFO - 2021-02-26 13:56:51 --> Router Class Initialized
INFO - 2021-02-26 13:56:51 --> Output Class Initialized
INFO - 2021-02-26 13:56:51 --> Security Class Initialized
DEBUG - 2021-02-26 13:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:56:51 --> Input Class Initialized
INFO - 2021-02-26 13:56:51 --> Language Class Initialized
INFO - 2021-02-26 13:56:51 --> Language Class Initialized
INFO - 2021-02-26 13:56:51 --> Config Class Initialized
INFO - 2021-02-26 13:56:51 --> Loader Class Initialized
INFO - 2021-02-26 13:56:51 --> Helper loaded: url_helper
INFO - 2021-02-26 13:56:51 --> Helper loaded: file_helper
INFO - 2021-02-26 13:56:51 --> Helper loaded: form_helper
INFO - 2021-02-26 13:56:52 --> Helper loaded: my_helper
INFO - 2021-02-26 13:56:52 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:56:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:56:52 --> Controller Class Initialized
DEBUG - 2021-02-26 13:56:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2021-02-26 13:56:52 --> Final output sent to browser
DEBUG - 2021-02-26 13:56:52 --> Total execution time: 1.4738
INFO - 2021-02-26 13:57:36 --> Config Class Initialized
INFO - 2021-02-26 13:57:36 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:57:36 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:57:36 --> Utf8 Class Initialized
INFO - 2021-02-26 13:57:36 --> URI Class Initialized
INFO - 2021-02-26 13:57:36 --> Router Class Initialized
INFO - 2021-02-26 13:57:36 --> Output Class Initialized
INFO - 2021-02-26 13:57:36 --> Security Class Initialized
DEBUG - 2021-02-26 13:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:57:36 --> Input Class Initialized
INFO - 2021-02-26 13:57:36 --> Language Class Initialized
INFO - 2021-02-26 13:57:36 --> Language Class Initialized
INFO - 2021-02-26 13:57:36 --> Config Class Initialized
INFO - 2021-02-26 13:57:36 --> Loader Class Initialized
INFO - 2021-02-26 13:57:36 --> Helper loaded: url_helper
INFO - 2021-02-26 13:57:36 --> Helper loaded: file_helper
INFO - 2021-02-26 13:57:37 --> Helper loaded: form_helper
INFO - 2021-02-26 13:57:37 --> Helper loaded: my_helper
INFO - 2021-02-26 13:57:37 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:57:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:57:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:57:37 --> Controller Class Initialized
DEBUG - 2021-02-26 13:57:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2021-02-26 13:57:37 --> Final output sent to browser
DEBUG - 2021-02-26 13:57:37 --> Total execution time: 1.5017
INFO - 2021-02-26 13:58:25 --> Config Class Initialized
INFO - 2021-02-26 13:58:25 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:58:25 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:58:25 --> Utf8 Class Initialized
INFO - 2021-02-26 13:58:25 --> URI Class Initialized
INFO - 2021-02-26 13:58:25 --> Router Class Initialized
INFO - 2021-02-26 13:58:25 --> Output Class Initialized
INFO - 2021-02-26 13:58:25 --> Security Class Initialized
DEBUG - 2021-02-26 13:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:58:25 --> Input Class Initialized
INFO - 2021-02-26 13:58:25 --> Language Class Initialized
INFO - 2021-02-26 13:58:25 --> Language Class Initialized
INFO - 2021-02-26 13:58:26 --> Config Class Initialized
INFO - 2021-02-26 13:58:26 --> Loader Class Initialized
INFO - 2021-02-26 13:58:26 --> Helper loaded: url_helper
INFO - 2021-02-26 13:58:26 --> Helper loaded: file_helper
INFO - 2021-02-26 13:58:26 --> Helper loaded: form_helper
INFO - 2021-02-26 13:58:26 --> Helper loaded: my_helper
INFO - 2021-02-26 13:58:26 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:58:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:58:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:58:26 --> Controller Class Initialized
DEBUG - 2021-02-26 13:58:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2021-02-26 13:58:26 --> Final output sent to browser
DEBUG - 2021-02-26 13:58:26 --> Total execution time: 1.2867
INFO - 2021-02-26 13:58:52 --> Config Class Initialized
INFO - 2021-02-26 13:58:52 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:58:52 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:58:52 --> Utf8 Class Initialized
INFO - 2021-02-26 13:58:52 --> URI Class Initialized
INFO - 2021-02-26 13:58:52 --> Router Class Initialized
INFO - 2021-02-26 13:58:52 --> Output Class Initialized
INFO - 2021-02-26 13:58:52 --> Security Class Initialized
DEBUG - 2021-02-26 13:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:58:52 --> Input Class Initialized
INFO - 2021-02-26 13:58:52 --> Language Class Initialized
INFO - 2021-02-26 13:58:52 --> Language Class Initialized
INFO - 2021-02-26 13:58:52 --> Config Class Initialized
INFO - 2021-02-26 13:58:52 --> Loader Class Initialized
INFO - 2021-02-26 13:58:53 --> Helper loaded: url_helper
INFO - 2021-02-26 13:58:53 --> Helper loaded: file_helper
INFO - 2021-02-26 13:58:53 --> Helper loaded: form_helper
INFO - 2021-02-26 13:58:53 --> Helper loaded: my_helper
INFO - 2021-02-26 13:58:53 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:58:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:58:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:58:53 --> Controller Class Initialized
DEBUG - 2021-02-26 13:58:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2021-02-26 13:58:53 --> Final output sent to browser
DEBUG - 2021-02-26 13:58:53 --> Total execution time: 1.3353
INFO - 2021-02-26 13:59:09 --> Config Class Initialized
INFO - 2021-02-26 13:59:09 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:59:09 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:59:09 --> Utf8 Class Initialized
INFO - 2021-02-26 13:59:09 --> URI Class Initialized
INFO - 2021-02-26 13:59:09 --> Router Class Initialized
INFO - 2021-02-26 13:59:09 --> Output Class Initialized
INFO - 2021-02-26 13:59:09 --> Security Class Initialized
DEBUG - 2021-02-26 13:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:59:09 --> Input Class Initialized
INFO - 2021-02-26 13:59:09 --> Language Class Initialized
INFO - 2021-02-26 13:59:09 --> Language Class Initialized
INFO - 2021-02-26 13:59:09 --> Config Class Initialized
INFO - 2021-02-26 13:59:09 --> Loader Class Initialized
INFO - 2021-02-26 13:59:10 --> Helper loaded: url_helper
INFO - 2021-02-26 13:59:10 --> Helper loaded: file_helper
INFO - 2021-02-26 13:59:10 --> Helper loaded: form_helper
INFO - 2021-02-26 13:59:10 --> Helper loaded: my_helper
INFO - 2021-02-26 13:59:10 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:59:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:59:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:59:10 --> Controller Class Initialized
INFO - 2021-02-26 13:59:10 --> Helper loaded: cookie_helper
INFO - 2021-02-26 13:59:10 --> Config Class Initialized
INFO - 2021-02-26 13:59:10 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:59:10 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:59:10 --> Utf8 Class Initialized
INFO - 2021-02-26 13:59:10 --> URI Class Initialized
INFO - 2021-02-26 13:59:10 --> Router Class Initialized
INFO - 2021-02-26 13:59:10 --> Output Class Initialized
INFO - 2021-02-26 13:59:10 --> Security Class Initialized
DEBUG - 2021-02-26 13:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:59:11 --> Input Class Initialized
INFO - 2021-02-26 13:59:11 --> Language Class Initialized
INFO - 2021-02-26 13:59:11 --> Language Class Initialized
INFO - 2021-02-26 13:59:11 --> Config Class Initialized
INFO - 2021-02-26 13:59:11 --> Loader Class Initialized
INFO - 2021-02-26 13:59:11 --> Helper loaded: url_helper
INFO - 2021-02-26 13:59:11 --> Helper loaded: file_helper
INFO - 2021-02-26 13:59:11 --> Helper loaded: form_helper
INFO - 2021-02-26 13:59:11 --> Helper loaded: my_helper
INFO - 2021-02-26 13:59:11 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:59:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:59:11 --> Controller Class Initialized
DEBUG - 2021-02-26 13:59:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-02-26 13:59:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 13:59:11 --> Final output sent to browser
DEBUG - 2021-02-26 13:59:11 --> Total execution time: 1.2549
INFO - 2021-02-26 13:59:17 --> Config Class Initialized
INFO - 2021-02-26 13:59:17 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:59:17 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:59:18 --> Utf8 Class Initialized
INFO - 2021-02-26 13:59:18 --> URI Class Initialized
INFO - 2021-02-26 13:59:18 --> Router Class Initialized
INFO - 2021-02-26 13:59:18 --> Output Class Initialized
INFO - 2021-02-26 13:59:18 --> Security Class Initialized
DEBUG - 2021-02-26 13:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:59:18 --> Input Class Initialized
INFO - 2021-02-26 13:59:18 --> Language Class Initialized
INFO - 2021-02-26 13:59:18 --> Language Class Initialized
INFO - 2021-02-26 13:59:18 --> Config Class Initialized
INFO - 2021-02-26 13:59:18 --> Loader Class Initialized
INFO - 2021-02-26 13:59:18 --> Helper loaded: url_helper
INFO - 2021-02-26 13:59:18 --> Helper loaded: file_helper
INFO - 2021-02-26 13:59:18 --> Helper loaded: form_helper
INFO - 2021-02-26 13:59:18 --> Helper loaded: my_helper
INFO - 2021-02-26 13:59:18 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:59:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:59:18 --> Controller Class Initialized
INFO - 2021-02-26 13:59:18 --> Helper loaded: cookie_helper
INFO - 2021-02-26 13:59:18 --> Final output sent to browser
DEBUG - 2021-02-26 13:59:19 --> Total execution time: 1.1246
INFO - 2021-02-26 13:59:19 --> Config Class Initialized
INFO - 2021-02-26 13:59:19 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:59:19 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:59:19 --> Utf8 Class Initialized
INFO - 2021-02-26 13:59:19 --> URI Class Initialized
INFO - 2021-02-26 13:59:19 --> Router Class Initialized
INFO - 2021-02-26 13:59:19 --> Output Class Initialized
INFO - 2021-02-26 13:59:19 --> Security Class Initialized
DEBUG - 2021-02-26 13:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:59:19 --> Input Class Initialized
INFO - 2021-02-26 13:59:19 --> Language Class Initialized
INFO - 2021-02-26 13:59:19 --> Language Class Initialized
INFO - 2021-02-26 13:59:20 --> Config Class Initialized
INFO - 2021-02-26 13:59:20 --> Loader Class Initialized
INFO - 2021-02-26 13:59:20 --> Helper loaded: url_helper
INFO - 2021-02-26 13:59:20 --> Helper loaded: file_helper
INFO - 2021-02-26 13:59:20 --> Helper loaded: form_helper
INFO - 2021-02-26 13:59:20 --> Helper loaded: my_helper
INFO - 2021-02-26 13:59:20 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:59:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:59:20 --> Controller Class Initialized
DEBUG - 2021-02-26 13:59:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-02-26 13:59:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 13:59:20 --> Final output sent to browser
DEBUG - 2021-02-26 13:59:20 --> Total execution time: 1.1800
INFO - 2021-02-26 13:59:23 --> Config Class Initialized
INFO - 2021-02-26 13:59:23 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:59:23 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:59:23 --> Utf8 Class Initialized
INFO - 2021-02-26 13:59:23 --> URI Class Initialized
INFO - 2021-02-26 13:59:23 --> Router Class Initialized
INFO - 2021-02-26 13:59:23 --> Output Class Initialized
INFO - 2021-02-26 13:59:23 --> Security Class Initialized
DEBUG - 2021-02-26 13:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:59:23 --> Input Class Initialized
INFO - 2021-02-26 13:59:24 --> Language Class Initialized
INFO - 2021-02-26 13:59:24 --> Language Class Initialized
INFO - 2021-02-26 13:59:24 --> Config Class Initialized
INFO - 2021-02-26 13:59:24 --> Loader Class Initialized
INFO - 2021-02-26 13:59:24 --> Helper loaded: url_helper
INFO - 2021-02-26 13:59:24 --> Helper loaded: file_helper
INFO - 2021-02-26 13:59:24 --> Helper loaded: form_helper
INFO - 2021-02-26 13:59:24 --> Helper loaded: my_helper
INFO - 2021-02-26 13:59:24 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:59:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:59:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:59:24 --> Controller Class Initialized
DEBUG - 2021-02-26 13:59:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-02-26 13:59:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 13:59:24 --> Final output sent to browser
DEBUG - 2021-02-26 13:59:24 --> Total execution time: 1.2363
INFO - 2021-02-26 13:59:28 --> Config Class Initialized
INFO - 2021-02-26 13:59:28 --> Hooks Class Initialized
DEBUG - 2021-02-26 13:59:28 --> UTF-8 Support Enabled
INFO - 2021-02-26 13:59:28 --> Utf8 Class Initialized
INFO - 2021-02-26 13:59:28 --> URI Class Initialized
INFO - 2021-02-26 13:59:28 --> Router Class Initialized
INFO - 2021-02-26 13:59:28 --> Output Class Initialized
INFO - 2021-02-26 13:59:29 --> Security Class Initialized
DEBUG - 2021-02-26 13:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 13:59:29 --> Input Class Initialized
INFO - 2021-02-26 13:59:29 --> Language Class Initialized
INFO - 2021-02-26 13:59:29 --> Language Class Initialized
INFO - 2021-02-26 13:59:29 --> Config Class Initialized
INFO - 2021-02-26 13:59:29 --> Loader Class Initialized
INFO - 2021-02-26 13:59:29 --> Helper loaded: url_helper
INFO - 2021-02-26 13:59:29 --> Helper loaded: file_helper
INFO - 2021-02-26 13:59:29 --> Helper loaded: form_helper
INFO - 2021-02-26 13:59:29 --> Helper loaded: my_helper
INFO - 2021-02-26 13:59:29 --> Database Driver Class Initialized
DEBUG - 2021-02-26 13:59:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 13:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 13:59:29 --> Controller Class Initialized
DEBUG - 2021-02-26 13:59:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-02-26 13:59:30 --> Final output sent to browser
DEBUG - 2021-02-26 13:59:30 --> Total execution time: 1.2697
INFO - 2021-02-26 14:00:30 --> Config Class Initialized
INFO - 2021-02-26 14:00:30 --> Hooks Class Initialized
DEBUG - 2021-02-26 14:00:30 --> UTF-8 Support Enabled
INFO - 2021-02-26 14:00:30 --> Utf8 Class Initialized
INFO - 2021-02-26 14:00:30 --> URI Class Initialized
INFO - 2021-02-26 14:00:30 --> Router Class Initialized
INFO - 2021-02-26 14:00:30 --> Output Class Initialized
INFO - 2021-02-26 14:00:30 --> Security Class Initialized
DEBUG - 2021-02-26 14:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 14:00:30 --> Input Class Initialized
INFO - 2021-02-26 14:00:30 --> Language Class Initialized
INFO - 2021-02-26 14:00:30 --> Language Class Initialized
INFO - 2021-02-26 14:00:30 --> Config Class Initialized
INFO - 2021-02-26 14:00:30 --> Loader Class Initialized
INFO - 2021-02-26 14:00:30 --> Helper loaded: url_helper
INFO - 2021-02-26 14:00:30 --> Helper loaded: file_helper
INFO - 2021-02-26 14:00:30 --> Helper loaded: form_helper
INFO - 2021-02-26 14:00:30 --> Helper loaded: my_helper
INFO - 2021-02-26 14:00:30 --> Database Driver Class Initialized
DEBUG - 2021-02-26 14:00:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 14:00:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 14:00:31 --> Controller Class Initialized
DEBUG - 2021-02-26 14:00:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-02-26 14:00:31 --> Final output sent to browser
DEBUG - 2021-02-26 14:00:31 --> Total execution time: 1.4129
INFO - 2021-02-26 14:00:58 --> Config Class Initialized
INFO - 2021-02-26 14:00:58 --> Hooks Class Initialized
DEBUG - 2021-02-26 14:00:58 --> UTF-8 Support Enabled
INFO - 2021-02-26 14:00:58 --> Utf8 Class Initialized
INFO - 2021-02-26 14:00:58 --> URI Class Initialized
INFO - 2021-02-26 14:00:58 --> Router Class Initialized
INFO - 2021-02-26 14:00:59 --> Output Class Initialized
INFO - 2021-02-26 14:00:59 --> Security Class Initialized
DEBUG - 2021-02-26 14:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 14:00:59 --> Input Class Initialized
INFO - 2021-02-26 14:00:59 --> Language Class Initialized
INFO - 2021-02-26 14:00:59 --> Language Class Initialized
INFO - 2021-02-26 14:00:59 --> Config Class Initialized
INFO - 2021-02-26 14:00:59 --> Loader Class Initialized
INFO - 2021-02-26 14:00:59 --> Helper loaded: url_helper
INFO - 2021-02-26 14:00:59 --> Helper loaded: file_helper
INFO - 2021-02-26 14:00:59 --> Helper loaded: form_helper
INFO - 2021-02-26 14:00:59 --> Helper loaded: my_helper
INFO - 2021-02-26 14:00:59 --> Database Driver Class Initialized
DEBUG - 2021-02-26 14:00:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 14:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 14:00:59 --> Controller Class Initialized
DEBUG - 2021-02-26 14:01:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-02-26 14:01:00 --> Final output sent to browser
DEBUG - 2021-02-26 14:01:00 --> Total execution time: 1.3650
INFO - 2021-02-26 14:01:17 --> Config Class Initialized
INFO - 2021-02-26 14:01:17 --> Hooks Class Initialized
DEBUG - 2021-02-26 14:01:17 --> UTF-8 Support Enabled
INFO - 2021-02-26 14:01:17 --> Utf8 Class Initialized
INFO - 2021-02-26 14:01:17 --> URI Class Initialized
INFO - 2021-02-26 14:01:17 --> Router Class Initialized
INFO - 2021-02-26 14:01:17 --> Output Class Initialized
INFO - 2021-02-26 14:01:17 --> Security Class Initialized
DEBUG - 2021-02-26 14:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 14:01:17 --> Input Class Initialized
INFO - 2021-02-26 14:01:17 --> Language Class Initialized
INFO - 2021-02-26 14:01:17 --> Language Class Initialized
INFO - 2021-02-26 14:01:17 --> Config Class Initialized
INFO - 2021-02-26 14:01:17 --> Loader Class Initialized
INFO - 2021-02-26 14:01:17 --> Helper loaded: url_helper
INFO - 2021-02-26 14:01:18 --> Helper loaded: file_helper
INFO - 2021-02-26 14:01:18 --> Helper loaded: form_helper
INFO - 2021-02-26 14:01:18 --> Helper loaded: my_helper
INFO - 2021-02-26 14:01:18 --> Database Driver Class Initialized
DEBUG - 2021-02-26 14:01:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 14:01:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 14:01:18 --> Controller Class Initialized
DEBUG - 2021-02-26 14:01:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-02-26 14:01:18 --> Final output sent to browser
DEBUG - 2021-02-26 14:01:18 --> Total execution time: 1.2186
INFO - 2021-02-26 14:01:30 --> Config Class Initialized
INFO - 2021-02-26 14:01:30 --> Hooks Class Initialized
DEBUG - 2021-02-26 14:01:30 --> UTF-8 Support Enabled
INFO - 2021-02-26 14:01:30 --> Utf8 Class Initialized
INFO - 2021-02-26 14:01:30 --> URI Class Initialized
INFO - 2021-02-26 14:01:30 --> Router Class Initialized
INFO - 2021-02-26 14:01:30 --> Output Class Initialized
INFO - 2021-02-26 14:01:30 --> Security Class Initialized
DEBUG - 2021-02-26 14:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 14:01:30 --> Input Class Initialized
INFO - 2021-02-26 14:01:30 --> Language Class Initialized
INFO - 2021-02-26 14:01:31 --> Language Class Initialized
INFO - 2021-02-26 14:01:31 --> Config Class Initialized
INFO - 2021-02-26 14:01:31 --> Loader Class Initialized
INFO - 2021-02-26 14:01:31 --> Helper loaded: url_helper
INFO - 2021-02-26 14:01:31 --> Helper loaded: file_helper
INFO - 2021-02-26 14:01:31 --> Helper loaded: form_helper
INFO - 2021-02-26 14:01:31 --> Helper loaded: my_helper
INFO - 2021-02-26 14:01:31 --> Database Driver Class Initialized
DEBUG - 2021-02-26 14:01:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 14:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 14:01:31 --> Controller Class Initialized
DEBUG - 2021-02-26 14:01:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-02-26 14:01:31 --> Final output sent to browser
DEBUG - 2021-02-26 14:01:31 --> Total execution time: 1.4275
INFO - 2021-02-26 14:01:59 --> Config Class Initialized
INFO - 2021-02-26 14:01:59 --> Hooks Class Initialized
DEBUG - 2021-02-26 14:01:59 --> UTF-8 Support Enabled
INFO - 2021-02-26 14:01:59 --> Utf8 Class Initialized
INFO - 2021-02-26 14:01:59 --> URI Class Initialized
INFO - 2021-02-26 14:01:59 --> Router Class Initialized
INFO - 2021-02-26 14:01:59 --> Output Class Initialized
INFO - 2021-02-26 14:01:59 --> Security Class Initialized
DEBUG - 2021-02-26 14:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 14:01:59 --> Input Class Initialized
INFO - 2021-02-26 14:01:59 --> Language Class Initialized
INFO - 2021-02-26 14:01:59 --> Language Class Initialized
INFO - 2021-02-26 14:01:59 --> Config Class Initialized
INFO - 2021-02-26 14:01:59 --> Loader Class Initialized
INFO - 2021-02-26 14:01:59 --> Helper loaded: url_helper
INFO - 2021-02-26 14:01:59 --> Helper loaded: file_helper
INFO - 2021-02-26 14:01:59 --> Helper loaded: form_helper
INFO - 2021-02-26 14:02:00 --> Helper loaded: my_helper
INFO - 2021-02-26 14:02:00 --> Database Driver Class Initialized
DEBUG - 2021-02-26 14:02:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 14:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 14:02:00 --> Controller Class Initialized
DEBUG - 2021-02-26 14:02:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-02-26 14:02:00 --> Final output sent to browser
DEBUG - 2021-02-26 14:02:00 --> Total execution time: 1.4845
INFO - 2021-02-26 14:02:22 --> Config Class Initialized
INFO - 2021-02-26 14:02:22 --> Hooks Class Initialized
DEBUG - 2021-02-26 14:02:22 --> UTF-8 Support Enabled
INFO - 2021-02-26 14:02:22 --> Utf8 Class Initialized
INFO - 2021-02-26 14:02:22 --> URI Class Initialized
INFO - 2021-02-26 14:02:22 --> Router Class Initialized
INFO - 2021-02-26 14:02:22 --> Output Class Initialized
INFO - 2021-02-26 14:02:23 --> Security Class Initialized
DEBUG - 2021-02-26 14:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 14:02:23 --> Input Class Initialized
INFO - 2021-02-26 14:02:23 --> Language Class Initialized
INFO - 2021-02-26 14:02:23 --> Language Class Initialized
INFO - 2021-02-26 14:02:23 --> Config Class Initialized
INFO - 2021-02-26 14:02:23 --> Loader Class Initialized
INFO - 2021-02-26 14:02:23 --> Helper loaded: url_helper
INFO - 2021-02-26 14:02:23 --> Helper loaded: file_helper
INFO - 2021-02-26 14:02:23 --> Helper loaded: form_helper
INFO - 2021-02-26 14:02:23 --> Helper loaded: my_helper
INFO - 2021-02-26 14:02:23 --> Database Driver Class Initialized
DEBUG - 2021-02-26 14:02:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 14:02:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 14:02:23 --> Controller Class Initialized
DEBUG - 2021-02-26 14:02:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-02-26 14:02:24 --> Final output sent to browser
DEBUG - 2021-02-26 14:02:24 --> Total execution time: 1.4513
INFO - 2021-02-26 14:02:57 --> Config Class Initialized
INFO - 2021-02-26 14:02:57 --> Hooks Class Initialized
DEBUG - 2021-02-26 14:02:57 --> UTF-8 Support Enabled
INFO - 2021-02-26 14:02:58 --> Utf8 Class Initialized
INFO - 2021-02-26 14:02:58 --> URI Class Initialized
INFO - 2021-02-26 14:02:58 --> Router Class Initialized
INFO - 2021-02-26 14:02:58 --> Output Class Initialized
INFO - 2021-02-26 14:02:58 --> Security Class Initialized
DEBUG - 2021-02-26 14:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 14:02:58 --> Input Class Initialized
INFO - 2021-02-26 14:02:58 --> Language Class Initialized
INFO - 2021-02-26 14:02:58 --> Language Class Initialized
INFO - 2021-02-26 14:02:58 --> Config Class Initialized
INFO - 2021-02-26 14:02:58 --> Loader Class Initialized
INFO - 2021-02-26 14:02:58 --> Helper loaded: url_helper
INFO - 2021-02-26 14:02:58 --> Helper loaded: file_helper
INFO - 2021-02-26 14:02:58 --> Helper loaded: form_helper
INFO - 2021-02-26 14:02:58 --> Helper loaded: my_helper
INFO - 2021-02-26 14:02:58 --> Database Driver Class Initialized
DEBUG - 2021-02-26 14:02:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 14:02:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 14:02:58 --> Controller Class Initialized
DEBUG - 2021-02-26 14:02:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-02-26 14:02:59 --> Final output sent to browser
DEBUG - 2021-02-26 14:02:59 --> Total execution time: 1.2642
INFO - 2021-02-26 14:03:20 --> Config Class Initialized
INFO - 2021-02-26 14:03:20 --> Hooks Class Initialized
DEBUG - 2021-02-26 14:03:20 --> UTF-8 Support Enabled
INFO - 2021-02-26 14:03:20 --> Utf8 Class Initialized
INFO - 2021-02-26 14:03:20 --> URI Class Initialized
INFO - 2021-02-26 14:03:20 --> Router Class Initialized
INFO - 2021-02-26 14:03:20 --> Output Class Initialized
INFO - 2021-02-26 14:03:20 --> Security Class Initialized
DEBUG - 2021-02-26 14:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 14:03:20 --> Input Class Initialized
INFO - 2021-02-26 14:03:20 --> Language Class Initialized
INFO - 2021-02-26 14:03:21 --> Language Class Initialized
INFO - 2021-02-26 14:03:21 --> Config Class Initialized
INFO - 2021-02-26 14:03:21 --> Loader Class Initialized
INFO - 2021-02-26 14:03:21 --> Helper loaded: url_helper
INFO - 2021-02-26 14:03:21 --> Helper loaded: file_helper
INFO - 2021-02-26 14:03:21 --> Helper loaded: form_helper
INFO - 2021-02-26 14:03:21 --> Helper loaded: my_helper
INFO - 2021-02-26 14:03:21 --> Database Driver Class Initialized
DEBUG - 2021-02-26 14:03:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 14:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 14:03:21 --> Controller Class Initialized
INFO - 2021-02-26 14:03:21 --> Helper loaded: cookie_helper
INFO - 2021-02-26 14:03:21 --> Config Class Initialized
INFO - 2021-02-26 14:03:21 --> Hooks Class Initialized
DEBUG - 2021-02-26 14:03:21 --> UTF-8 Support Enabled
INFO - 2021-02-26 14:03:22 --> Utf8 Class Initialized
INFO - 2021-02-26 14:03:22 --> URI Class Initialized
INFO - 2021-02-26 14:03:22 --> Router Class Initialized
INFO - 2021-02-26 14:03:22 --> Output Class Initialized
INFO - 2021-02-26 14:03:22 --> Security Class Initialized
DEBUG - 2021-02-26 14:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 14:03:22 --> Input Class Initialized
INFO - 2021-02-26 14:03:22 --> Language Class Initialized
INFO - 2021-02-26 14:03:22 --> Language Class Initialized
INFO - 2021-02-26 14:03:22 --> Config Class Initialized
INFO - 2021-02-26 14:03:22 --> Loader Class Initialized
INFO - 2021-02-26 14:03:22 --> Helper loaded: url_helper
INFO - 2021-02-26 14:03:22 --> Helper loaded: file_helper
INFO - 2021-02-26 14:03:22 --> Helper loaded: form_helper
INFO - 2021-02-26 14:03:22 --> Helper loaded: my_helper
INFO - 2021-02-26 14:03:22 --> Database Driver Class Initialized
DEBUG - 2021-02-26 14:03:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 14:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 14:03:23 --> Controller Class Initialized
DEBUG - 2021-02-26 14:03:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-02-26 14:03:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 14:03:23 --> Final output sent to browser
DEBUG - 2021-02-26 14:03:23 --> Total execution time: 1.4176
INFO - 2021-02-26 14:03:26 --> Config Class Initialized
INFO - 2021-02-26 14:03:26 --> Hooks Class Initialized
DEBUG - 2021-02-26 14:03:27 --> UTF-8 Support Enabled
INFO - 2021-02-26 14:03:27 --> Utf8 Class Initialized
INFO - 2021-02-26 14:03:27 --> URI Class Initialized
INFO - 2021-02-26 14:03:27 --> Router Class Initialized
INFO - 2021-02-26 14:03:27 --> Output Class Initialized
INFO - 2021-02-26 14:03:27 --> Security Class Initialized
DEBUG - 2021-02-26 14:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 14:03:27 --> Input Class Initialized
INFO - 2021-02-26 14:03:27 --> Language Class Initialized
INFO - 2021-02-26 14:03:27 --> Language Class Initialized
INFO - 2021-02-26 14:03:27 --> Config Class Initialized
INFO - 2021-02-26 14:03:27 --> Loader Class Initialized
INFO - 2021-02-26 14:03:27 --> Helper loaded: url_helper
INFO - 2021-02-26 14:03:27 --> Helper loaded: file_helper
INFO - 2021-02-26 14:03:27 --> Helper loaded: form_helper
INFO - 2021-02-26 14:03:28 --> Helper loaded: my_helper
INFO - 2021-02-26 14:03:28 --> Database Driver Class Initialized
DEBUG - 2021-02-26 14:03:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 14:03:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 14:03:28 --> Controller Class Initialized
INFO - 2021-02-26 14:03:28 --> Helper loaded: cookie_helper
INFO - 2021-02-26 14:03:28 --> Final output sent to browser
DEBUG - 2021-02-26 14:03:28 --> Total execution time: 1.3241
INFO - 2021-02-26 14:03:29 --> Config Class Initialized
INFO - 2021-02-26 14:03:29 --> Hooks Class Initialized
DEBUG - 2021-02-26 14:03:29 --> UTF-8 Support Enabled
INFO - 2021-02-26 14:03:29 --> Utf8 Class Initialized
INFO - 2021-02-26 14:03:29 --> URI Class Initialized
INFO - 2021-02-26 14:03:29 --> Router Class Initialized
INFO - 2021-02-26 14:03:29 --> Output Class Initialized
INFO - 2021-02-26 14:03:29 --> Security Class Initialized
DEBUG - 2021-02-26 14:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 14:03:29 --> Input Class Initialized
INFO - 2021-02-26 14:03:29 --> Language Class Initialized
INFO - 2021-02-26 14:03:29 --> Language Class Initialized
INFO - 2021-02-26 14:03:29 --> Config Class Initialized
INFO - 2021-02-26 14:03:29 --> Loader Class Initialized
INFO - 2021-02-26 14:03:30 --> Helper loaded: url_helper
INFO - 2021-02-26 14:03:30 --> Helper loaded: file_helper
INFO - 2021-02-26 14:03:30 --> Helper loaded: form_helper
INFO - 2021-02-26 14:03:30 --> Helper loaded: my_helper
INFO - 2021-02-26 14:03:30 --> Database Driver Class Initialized
DEBUG - 2021-02-26 14:03:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 14:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 14:03:30 --> Controller Class Initialized
DEBUG - 2021-02-26 14:03:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-02-26 14:03:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 14:03:30 --> Final output sent to browser
DEBUG - 2021-02-26 14:03:30 --> Total execution time: 1.1997
INFO - 2021-02-26 14:03:31 --> Config Class Initialized
INFO - 2021-02-26 14:03:31 --> Hooks Class Initialized
DEBUG - 2021-02-26 14:03:31 --> UTF-8 Support Enabled
INFO - 2021-02-26 14:03:31 --> Utf8 Class Initialized
INFO - 2021-02-26 14:03:31 --> URI Class Initialized
INFO - 2021-02-26 14:03:31 --> Router Class Initialized
INFO - 2021-02-26 14:03:31 --> Output Class Initialized
INFO - 2021-02-26 14:03:31 --> Security Class Initialized
DEBUG - 2021-02-26 14:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 14:03:32 --> Input Class Initialized
INFO - 2021-02-26 14:03:32 --> Language Class Initialized
INFO - 2021-02-26 14:03:32 --> Language Class Initialized
INFO - 2021-02-26 14:03:32 --> Config Class Initialized
INFO - 2021-02-26 14:03:32 --> Loader Class Initialized
INFO - 2021-02-26 14:03:32 --> Helper loaded: url_helper
INFO - 2021-02-26 14:03:32 --> Helper loaded: file_helper
INFO - 2021-02-26 14:03:32 --> Helper loaded: form_helper
INFO - 2021-02-26 14:03:32 --> Helper loaded: my_helper
INFO - 2021-02-26 14:03:32 --> Database Driver Class Initialized
DEBUG - 2021-02-26 14:03:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 14:03:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 14:03:32 --> Controller Class Initialized
DEBUG - 2021-02-26 14:03:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-02-26 14:03:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-26 14:03:32 --> Final output sent to browser
DEBUG - 2021-02-26 14:03:32 --> Total execution time: 1.2032
INFO - 2021-02-26 14:03:35 --> Config Class Initialized
INFO - 2021-02-26 14:03:35 --> Hooks Class Initialized
DEBUG - 2021-02-26 14:03:35 --> UTF-8 Support Enabled
INFO - 2021-02-26 14:03:35 --> Utf8 Class Initialized
INFO - 2021-02-26 14:03:35 --> URI Class Initialized
INFO - 2021-02-26 14:03:35 --> Router Class Initialized
INFO - 2021-02-26 14:03:35 --> Output Class Initialized
INFO - 2021-02-26 14:03:35 --> Security Class Initialized
DEBUG - 2021-02-26 14:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 14:03:35 --> Input Class Initialized
INFO - 2021-02-26 14:03:35 --> Language Class Initialized
INFO - 2021-02-26 14:03:35 --> Language Class Initialized
INFO - 2021-02-26 14:03:35 --> Config Class Initialized
INFO - 2021-02-26 14:03:35 --> Loader Class Initialized
INFO - 2021-02-26 14:03:35 --> Helper loaded: url_helper
INFO - 2021-02-26 14:03:35 --> Helper loaded: file_helper
INFO - 2021-02-26 14:03:35 --> Helper loaded: form_helper
INFO - 2021-02-26 14:03:35 --> Helper loaded: my_helper
INFO - 2021-02-26 14:03:35 --> Database Driver Class Initialized
DEBUG - 2021-02-26 14:03:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 14:03:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 14:03:36 --> Controller Class Initialized
DEBUG - 2021-02-26 14:03:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-02-26 14:03:36 --> Final output sent to browser
DEBUG - 2021-02-26 14:03:36 --> Total execution time: 1.1208
INFO - 2021-02-26 14:04:22 --> Config Class Initialized
INFO - 2021-02-26 14:04:22 --> Hooks Class Initialized
DEBUG - 2021-02-26 14:04:22 --> UTF-8 Support Enabled
INFO - 2021-02-26 14:04:22 --> Utf8 Class Initialized
INFO - 2021-02-26 14:04:22 --> URI Class Initialized
INFO - 2021-02-26 14:04:22 --> Router Class Initialized
INFO - 2021-02-26 14:04:22 --> Output Class Initialized
INFO - 2021-02-26 14:04:22 --> Security Class Initialized
DEBUG - 2021-02-26 14:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-26 14:04:22 --> Input Class Initialized
INFO - 2021-02-26 14:04:22 --> Language Class Initialized
INFO - 2021-02-26 14:04:23 --> Language Class Initialized
INFO - 2021-02-26 14:04:23 --> Config Class Initialized
INFO - 2021-02-26 14:04:23 --> Loader Class Initialized
INFO - 2021-02-26 14:04:23 --> Helper loaded: url_helper
INFO - 2021-02-26 14:04:23 --> Helper loaded: file_helper
INFO - 2021-02-26 14:04:23 --> Helper loaded: form_helper
INFO - 2021-02-26 14:04:23 --> Helper loaded: my_helper
INFO - 2021-02-26 14:04:23 --> Database Driver Class Initialized
DEBUG - 2021-02-26 14:04:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-26 14:04:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-26 14:04:23 --> Controller Class Initialized
DEBUG - 2021-02-26 14:04:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-02-26 14:04:23 --> Final output sent to browser
DEBUG - 2021-02-26 14:04:24 --> Total execution time: 1.5727
