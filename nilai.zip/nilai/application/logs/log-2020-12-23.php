<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-12-23 01:42:13 --> Config Class Initialized
INFO - 2020-12-23 01:42:13 --> Hooks Class Initialized
DEBUG - 2020-12-23 01:42:13 --> UTF-8 Support Enabled
INFO - 2020-12-23 01:42:13 --> Utf8 Class Initialized
INFO - 2020-12-23 01:42:13 --> URI Class Initialized
DEBUG - 2020-12-23 01:42:14 --> No URI present. Default controller set.
INFO - 2020-12-23 01:42:14 --> Router Class Initialized
INFO - 2020-12-23 01:42:14 --> Output Class Initialized
INFO - 2020-12-23 01:42:14 --> Security Class Initialized
DEBUG - 2020-12-23 01:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-23 01:42:14 --> Input Class Initialized
INFO - 2020-12-23 01:42:14 --> Language Class Initialized
INFO - 2020-12-23 01:42:14 --> Language Class Initialized
INFO - 2020-12-23 01:42:14 --> Config Class Initialized
INFO - 2020-12-23 01:42:14 --> Loader Class Initialized
INFO - 2020-12-23 01:42:14 --> Helper loaded: url_helper
INFO - 2020-12-23 01:42:14 --> Helper loaded: file_helper
INFO - 2020-12-23 01:42:14 --> Helper loaded: form_helper
INFO - 2020-12-23 01:42:14 --> Helper loaded: my_helper
INFO - 2020-12-23 01:42:14 --> Database Driver Class Initialized
DEBUG - 2020-12-23 01:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-23 01:42:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-23 01:42:14 --> Controller Class Initialized
INFO - 2020-12-23 01:42:14 --> Config Class Initialized
INFO - 2020-12-23 01:42:14 --> Hooks Class Initialized
DEBUG - 2020-12-23 01:42:15 --> UTF-8 Support Enabled
INFO - 2020-12-23 01:42:15 --> Utf8 Class Initialized
INFO - 2020-12-23 01:42:15 --> URI Class Initialized
INFO - 2020-12-23 01:42:15 --> Router Class Initialized
INFO - 2020-12-23 01:42:15 --> Output Class Initialized
INFO - 2020-12-23 01:42:15 --> Security Class Initialized
DEBUG - 2020-12-23 01:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-23 01:42:15 --> Input Class Initialized
INFO - 2020-12-23 01:42:15 --> Language Class Initialized
INFO - 2020-12-23 01:42:15 --> Language Class Initialized
INFO - 2020-12-23 01:42:15 --> Config Class Initialized
INFO - 2020-12-23 01:42:15 --> Loader Class Initialized
INFO - 2020-12-23 01:42:15 --> Helper loaded: url_helper
INFO - 2020-12-23 01:42:15 --> Helper loaded: file_helper
INFO - 2020-12-23 01:42:15 --> Helper loaded: form_helper
INFO - 2020-12-23 01:42:15 --> Helper loaded: my_helper
INFO - 2020-12-23 01:42:15 --> Database Driver Class Initialized
DEBUG - 2020-12-23 01:42:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-23 01:42:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-23 01:42:15 --> Controller Class Initialized
DEBUG - 2020-12-23 01:42:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-23 01:42:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-23 01:42:15 --> Final output sent to browser
DEBUG - 2020-12-23 01:42:15 --> Total execution time: 0.4741
INFO - 2020-12-23 01:52:24 --> Config Class Initialized
INFO - 2020-12-23 01:52:24 --> Hooks Class Initialized
DEBUG - 2020-12-23 01:52:24 --> UTF-8 Support Enabled
INFO - 2020-12-23 01:52:24 --> Utf8 Class Initialized
INFO - 2020-12-23 01:52:24 --> URI Class Initialized
INFO - 2020-12-23 01:52:24 --> Router Class Initialized
INFO - 2020-12-23 01:52:25 --> Output Class Initialized
INFO - 2020-12-23 01:52:25 --> Security Class Initialized
DEBUG - 2020-12-23 01:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-23 01:52:25 --> Input Class Initialized
INFO - 2020-12-23 01:52:25 --> Language Class Initialized
INFO - 2020-12-23 01:52:25 --> Language Class Initialized
INFO - 2020-12-23 01:52:25 --> Config Class Initialized
INFO - 2020-12-23 01:52:25 --> Loader Class Initialized
INFO - 2020-12-23 01:52:25 --> Helper loaded: url_helper
INFO - 2020-12-23 01:52:25 --> Helper loaded: file_helper
INFO - 2020-12-23 01:52:25 --> Helper loaded: form_helper
INFO - 2020-12-23 01:52:25 --> Helper loaded: my_helper
INFO - 2020-12-23 01:52:25 --> Database Driver Class Initialized
DEBUG - 2020-12-23 01:52:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-23 01:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-23 01:52:25 --> Controller Class Initialized
INFO - 2020-12-23 01:52:25 --> Helper loaded: cookie_helper
INFO - 2020-12-23 01:52:25 --> Final output sent to browser
DEBUG - 2020-12-23 01:52:25 --> Total execution time: 0.4716
INFO - 2020-12-23 01:52:26 --> Config Class Initialized
INFO - 2020-12-23 01:52:26 --> Hooks Class Initialized
DEBUG - 2020-12-23 01:52:26 --> UTF-8 Support Enabled
INFO - 2020-12-23 01:52:26 --> Utf8 Class Initialized
INFO - 2020-12-23 01:52:26 --> URI Class Initialized
INFO - 2020-12-23 01:52:26 --> Router Class Initialized
INFO - 2020-12-23 01:52:26 --> Output Class Initialized
INFO - 2020-12-23 01:52:26 --> Security Class Initialized
DEBUG - 2020-12-23 01:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-23 01:52:26 --> Input Class Initialized
INFO - 2020-12-23 01:52:26 --> Language Class Initialized
INFO - 2020-12-23 01:52:26 --> Language Class Initialized
INFO - 2020-12-23 01:52:26 --> Config Class Initialized
INFO - 2020-12-23 01:52:26 --> Loader Class Initialized
INFO - 2020-12-23 01:52:26 --> Helper loaded: url_helper
INFO - 2020-12-23 01:52:26 --> Helper loaded: file_helper
INFO - 2020-12-23 01:52:26 --> Helper loaded: form_helper
INFO - 2020-12-23 01:52:26 --> Helper loaded: my_helper
INFO - 2020-12-23 01:52:26 --> Database Driver Class Initialized
DEBUG - 2020-12-23 01:52:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-23 01:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-23 01:52:26 --> Controller Class Initialized
DEBUG - 2020-12-23 01:52:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-23 01:52:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-23 01:52:26 --> Final output sent to browser
DEBUG - 2020-12-23 01:52:26 --> Total execution time: 0.5510
INFO - 2020-12-23 02:46:45 --> Config Class Initialized
INFO - 2020-12-23 02:46:45 --> Hooks Class Initialized
DEBUG - 2020-12-23 02:46:45 --> UTF-8 Support Enabled
INFO - 2020-12-23 02:46:45 --> Utf8 Class Initialized
INFO - 2020-12-23 02:46:45 --> URI Class Initialized
INFO - 2020-12-23 02:46:45 --> Router Class Initialized
INFO - 2020-12-23 02:46:45 --> Output Class Initialized
INFO - 2020-12-23 02:46:45 --> Security Class Initialized
DEBUG - 2020-12-23 02:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-23 02:46:45 --> Input Class Initialized
INFO - 2020-12-23 02:46:45 --> Language Class Initialized
INFO - 2020-12-23 02:46:45 --> Language Class Initialized
INFO - 2020-12-23 02:46:45 --> Config Class Initialized
INFO - 2020-12-23 02:46:45 --> Loader Class Initialized
INFO - 2020-12-23 02:46:45 --> Helper loaded: url_helper
INFO - 2020-12-23 02:46:45 --> Helper loaded: file_helper
INFO - 2020-12-23 02:46:45 --> Helper loaded: form_helper
INFO - 2020-12-23 02:46:45 --> Helper loaded: my_helper
INFO - 2020-12-23 02:46:45 --> Database Driver Class Initialized
DEBUG - 2020-12-23 02:46:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-23 02:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-23 02:46:46 --> Controller Class Initialized
INFO - 2020-12-23 02:46:46 --> Helper loaded: cookie_helper
INFO - 2020-12-23 02:46:46 --> Config Class Initialized
INFO - 2020-12-23 02:46:46 --> Hooks Class Initialized
DEBUG - 2020-12-23 02:46:46 --> UTF-8 Support Enabled
INFO - 2020-12-23 02:46:46 --> Utf8 Class Initialized
INFO - 2020-12-23 02:46:46 --> URI Class Initialized
INFO - 2020-12-23 02:46:46 --> Router Class Initialized
INFO - 2020-12-23 02:46:46 --> Output Class Initialized
INFO - 2020-12-23 02:46:46 --> Security Class Initialized
DEBUG - 2020-12-23 02:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-23 02:46:46 --> Input Class Initialized
INFO - 2020-12-23 02:46:46 --> Language Class Initialized
INFO - 2020-12-23 02:46:46 --> Language Class Initialized
INFO - 2020-12-23 02:46:46 --> Config Class Initialized
INFO - 2020-12-23 02:46:46 --> Loader Class Initialized
INFO - 2020-12-23 02:46:46 --> Helper loaded: url_helper
INFO - 2020-12-23 02:46:46 --> Helper loaded: file_helper
INFO - 2020-12-23 02:46:46 --> Helper loaded: form_helper
INFO - 2020-12-23 02:46:46 --> Helper loaded: my_helper
INFO - 2020-12-23 02:46:46 --> Database Driver Class Initialized
DEBUG - 2020-12-23 02:46:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-23 02:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-23 02:46:46 --> Controller Class Initialized
DEBUG - 2020-12-23 02:46:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-23 02:46:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-23 02:46:46 --> Final output sent to browser
DEBUG - 2020-12-23 02:46:46 --> Total execution time: 0.2571
INFO - 2020-12-23 02:46:52 --> Config Class Initialized
INFO - 2020-12-23 02:46:52 --> Hooks Class Initialized
DEBUG - 2020-12-23 02:46:52 --> UTF-8 Support Enabled
INFO - 2020-12-23 02:46:52 --> Utf8 Class Initialized
INFO - 2020-12-23 02:46:52 --> URI Class Initialized
INFO - 2020-12-23 02:46:52 --> Router Class Initialized
INFO - 2020-12-23 02:46:52 --> Output Class Initialized
INFO - 2020-12-23 02:46:52 --> Security Class Initialized
DEBUG - 2020-12-23 02:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-23 02:46:52 --> Input Class Initialized
INFO - 2020-12-23 02:46:52 --> Language Class Initialized
INFO - 2020-12-23 02:46:52 --> Language Class Initialized
INFO - 2020-12-23 02:46:52 --> Config Class Initialized
INFO - 2020-12-23 02:46:52 --> Loader Class Initialized
INFO - 2020-12-23 02:46:52 --> Helper loaded: url_helper
INFO - 2020-12-23 02:46:52 --> Helper loaded: file_helper
INFO - 2020-12-23 02:46:52 --> Helper loaded: form_helper
INFO - 2020-12-23 02:46:52 --> Helper loaded: my_helper
INFO - 2020-12-23 02:46:52 --> Database Driver Class Initialized
DEBUG - 2020-12-23 02:46:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-23 02:46:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-23 02:46:52 --> Controller Class Initialized
INFO - 2020-12-23 02:46:52 --> Helper loaded: cookie_helper
INFO - 2020-12-23 02:46:52 --> Final output sent to browser
DEBUG - 2020-12-23 02:46:52 --> Total execution time: 0.2968
INFO - 2020-12-23 02:46:54 --> Config Class Initialized
INFO - 2020-12-23 02:46:54 --> Hooks Class Initialized
DEBUG - 2020-12-23 02:46:54 --> UTF-8 Support Enabled
INFO - 2020-12-23 02:46:54 --> Utf8 Class Initialized
INFO - 2020-12-23 02:46:54 --> URI Class Initialized
INFO - 2020-12-23 02:46:54 --> Router Class Initialized
INFO - 2020-12-23 02:46:54 --> Output Class Initialized
INFO - 2020-12-23 02:46:54 --> Security Class Initialized
DEBUG - 2020-12-23 02:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-23 02:46:54 --> Input Class Initialized
INFO - 2020-12-23 02:46:54 --> Language Class Initialized
INFO - 2020-12-23 02:46:54 --> Language Class Initialized
INFO - 2020-12-23 02:46:54 --> Config Class Initialized
INFO - 2020-12-23 02:46:54 --> Loader Class Initialized
INFO - 2020-12-23 02:46:54 --> Helper loaded: url_helper
INFO - 2020-12-23 02:46:54 --> Helper loaded: file_helper
INFO - 2020-12-23 02:46:54 --> Helper loaded: form_helper
INFO - 2020-12-23 02:46:54 --> Helper loaded: my_helper
INFO - 2020-12-23 02:46:54 --> Database Driver Class Initialized
DEBUG - 2020-12-23 02:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-23 02:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-23 02:46:54 --> Controller Class Initialized
DEBUG - 2020-12-23 02:46:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-23 02:46:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-23 02:46:54 --> Final output sent to browser
DEBUG - 2020-12-23 02:46:54 --> Total execution time: 0.3581
INFO - 2020-12-23 02:46:56 --> Config Class Initialized
INFO - 2020-12-23 02:46:56 --> Hooks Class Initialized
DEBUG - 2020-12-23 02:46:56 --> UTF-8 Support Enabled
INFO - 2020-12-23 02:46:56 --> Utf8 Class Initialized
INFO - 2020-12-23 02:46:56 --> URI Class Initialized
INFO - 2020-12-23 02:46:56 --> Router Class Initialized
INFO - 2020-12-23 02:46:56 --> Output Class Initialized
INFO - 2020-12-23 02:46:56 --> Security Class Initialized
DEBUG - 2020-12-23 02:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-23 02:46:56 --> Input Class Initialized
INFO - 2020-12-23 02:46:56 --> Language Class Initialized
INFO - 2020-12-23 02:46:56 --> Language Class Initialized
INFO - 2020-12-23 02:46:56 --> Config Class Initialized
INFO - 2020-12-23 02:46:56 --> Loader Class Initialized
INFO - 2020-12-23 02:46:56 --> Helper loaded: url_helper
INFO - 2020-12-23 02:46:56 --> Helper loaded: file_helper
INFO - 2020-12-23 02:46:56 --> Helper loaded: form_helper
INFO - 2020-12-23 02:46:56 --> Helper loaded: my_helper
INFO - 2020-12-23 02:46:56 --> Database Driver Class Initialized
DEBUG - 2020-12-23 02:46:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-23 02:46:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-23 02:46:56 --> Controller Class Initialized
DEBUG - 2020-12-23 02:46:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-12-23 02:46:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-23 02:46:56 --> Final output sent to browser
DEBUG - 2020-12-23 02:46:56 --> Total execution time: 0.2679
INFO - 2020-12-23 02:46:56 --> Config Class Initialized
INFO - 2020-12-23 02:46:56 --> Hooks Class Initialized
DEBUG - 2020-12-23 02:46:56 --> UTF-8 Support Enabled
INFO - 2020-12-23 02:46:56 --> Utf8 Class Initialized
INFO - 2020-12-23 02:46:56 --> URI Class Initialized
INFO - 2020-12-23 02:46:56 --> Router Class Initialized
INFO - 2020-12-23 02:46:56 --> Output Class Initialized
INFO - 2020-12-23 02:46:56 --> Security Class Initialized
DEBUG - 2020-12-23 02:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-23 02:46:56 --> Input Class Initialized
INFO - 2020-12-23 02:46:56 --> Language Class Initialized
INFO - 2020-12-23 02:46:56 --> Language Class Initialized
INFO - 2020-12-23 02:46:56 --> Config Class Initialized
INFO - 2020-12-23 02:46:56 --> Loader Class Initialized
INFO - 2020-12-23 02:46:56 --> Helper loaded: url_helper
INFO - 2020-12-23 02:46:56 --> Helper loaded: file_helper
INFO - 2020-12-23 02:46:56 --> Helper loaded: form_helper
INFO - 2020-12-23 02:46:56 --> Helper loaded: my_helper
INFO - 2020-12-23 02:46:56 --> Database Driver Class Initialized
DEBUG - 2020-12-23 02:46:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-23 02:46:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-23 02:46:56 --> Controller Class Initialized
INFO - 2020-12-23 02:47:10 --> Config Class Initialized
INFO - 2020-12-23 02:47:10 --> Hooks Class Initialized
DEBUG - 2020-12-23 02:47:10 --> UTF-8 Support Enabled
INFO - 2020-12-23 02:47:10 --> Utf8 Class Initialized
INFO - 2020-12-23 02:47:10 --> URI Class Initialized
INFO - 2020-12-23 02:47:10 --> Router Class Initialized
INFO - 2020-12-23 02:47:10 --> Output Class Initialized
INFO - 2020-12-23 02:47:10 --> Security Class Initialized
DEBUG - 2020-12-23 02:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-23 02:47:10 --> Input Class Initialized
INFO - 2020-12-23 02:47:10 --> Language Class Initialized
INFO - 2020-12-23 02:47:10 --> Language Class Initialized
INFO - 2020-12-23 02:47:10 --> Config Class Initialized
INFO - 2020-12-23 02:47:10 --> Loader Class Initialized
INFO - 2020-12-23 02:47:10 --> Helper loaded: url_helper
INFO - 2020-12-23 02:47:10 --> Helper loaded: file_helper
INFO - 2020-12-23 02:47:10 --> Helper loaded: form_helper
INFO - 2020-12-23 02:47:10 --> Helper loaded: my_helper
INFO - 2020-12-23 02:47:10 --> Database Driver Class Initialized
DEBUG - 2020-12-23 02:47:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-23 02:47:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-23 02:47:11 --> Controller Class Initialized
INFO - 2020-12-23 02:47:11 --> Helper loaded: cookie_helper
INFO - 2020-12-23 02:47:11 --> Config Class Initialized
INFO - 2020-12-23 02:47:11 --> Hooks Class Initialized
DEBUG - 2020-12-23 02:47:11 --> UTF-8 Support Enabled
INFO - 2020-12-23 02:47:11 --> Utf8 Class Initialized
INFO - 2020-12-23 02:47:11 --> URI Class Initialized
INFO - 2020-12-23 02:47:11 --> Router Class Initialized
INFO - 2020-12-23 02:47:11 --> Output Class Initialized
INFO - 2020-12-23 02:47:11 --> Security Class Initialized
DEBUG - 2020-12-23 02:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-23 02:47:11 --> Input Class Initialized
INFO - 2020-12-23 02:47:11 --> Language Class Initialized
INFO - 2020-12-23 02:47:11 --> Language Class Initialized
INFO - 2020-12-23 02:47:11 --> Config Class Initialized
INFO - 2020-12-23 02:47:11 --> Loader Class Initialized
INFO - 2020-12-23 02:47:11 --> Helper loaded: url_helper
INFO - 2020-12-23 02:47:11 --> Helper loaded: file_helper
INFO - 2020-12-23 02:47:11 --> Helper loaded: form_helper
INFO - 2020-12-23 02:47:11 --> Helper loaded: my_helper
INFO - 2020-12-23 02:47:11 --> Database Driver Class Initialized
DEBUG - 2020-12-23 02:47:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-23 02:47:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-23 02:47:11 --> Controller Class Initialized
DEBUG - 2020-12-23 02:47:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-23 02:47:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-23 02:47:11 --> Final output sent to browser
DEBUG - 2020-12-23 02:47:11 --> Total execution time: 0.2429
INFO - 2020-12-23 02:47:19 --> Config Class Initialized
INFO - 2020-12-23 02:47:19 --> Hooks Class Initialized
DEBUG - 2020-12-23 02:47:19 --> UTF-8 Support Enabled
INFO - 2020-12-23 02:47:19 --> Utf8 Class Initialized
INFO - 2020-12-23 02:47:19 --> URI Class Initialized
INFO - 2020-12-23 02:47:19 --> Router Class Initialized
INFO - 2020-12-23 02:47:19 --> Output Class Initialized
INFO - 2020-12-23 02:47:19 --> Security Class Initialized
DEBUG - 2020-12-23 02:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-23 02:47:19 --> Input Class Initialized
INFO - 2020-12-23 02:47:19 --> Language Class Initialized
INFO - 2020-12-23 02:47:19 --> Language Class Initialized
INFO - 2020-12-23 02:47:19 --> Config Class Initialized
INFO - 2020-12-23 02:47:19 --> Loader Class Initialized
INFO - 2020-12-23 02:47:19 --> Helper loaded: url_helper
INFO - 2020-12-23 02:47:19 --> Helper loaded: file_helper
INFO - 2020-12-23 02:47:19 --> Helper loaded: form_helper
INFO - 2020-12-23 02:47:19 --> Helper loaded: my_helper
INFO - 2020-12-23 02:47:19 --> Database Driver Class Initialized
DEBUG - 2020-12-23 02:47:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-23 02:47:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-23 02:47:19 --> Controller Class Initialized
INFO - 2020-12-23 02:47:20 --> Helper loaded: cookie_helper
INFO - 2020-12-23 02:47:20 --> Final output sent to browser
DEBUG - 2020-12-23 02:47:20 --> Total execution time: 0.2768
INFO - 2020-12-23 02:47:21 --> Config Class Initialized
INFO - 2020-12-23 02:47:21 --> Hooks Class Initialized
DEBUG - 2020-12-23 02:47:21 --> UTF-8 Support Enabled
INFO - 2020-12-23 02:47:21 --> Utf8 Class Initialized
INFO - 2020-12-23 02:47:21 --> URI Class Initialized
INFO - 2020-12-23 02:47:21 --> Router Class Initialized
INFO - 2020-12-23 02:47:21 --> Output Class Initialized
INFO - 2020-12-23 02:47:21 --> Security Class Initialized
DEBUG - 2020-12-23 02:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-23 02:47:21 --> Input Class Initialized
INFO - 2020-12-23 02:47:21 --> Language Class Initialized
INFO - 2020-12-23 02:47:21 --> Language Class Initialized
INFO - 2020-12-23 02:47:21 --> Config Class Initialized
INFO - 2020-12-23 02:47:21 --> Loader Class Initialized
INFO - 2020-12-23 02:47:21 --> Helper loaded: url_helper
INFO - 2020-12-23 02:47:21 --> Helper loaded: file_helper
INFO - 2020-12-23 02:47:21 --> Helper loaded: form_helper
INFO - 2020-12-23 02:47:21 --> Helper loaded: my_helper
INFO - 2020-12-23 02:47:21 --> Database Driver Class Initialized
DEBUG - 2020-12-23 02:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-23 02:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-23 02:47:21 --> Controller Class Initialized
DEBUG - 2020-12-23 02:47:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-23 02:47:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-23 02:47:21 --> Final output sent to browser
DEBUG - 2020-12-23 02:47:21 --> Total execution time: 0.3804
INFO - 2020-12-23 02:47:22 --> Config Class Initialized
INFO - 2020-12-23 02:47:22 --> Hooks Class Initialized
DEBUG - 2020-12-23 02:47:22 --> UTF-8 Support Enabled
INFO - 2020-12-23 02:47:22 --> Utf8 Class Initialized
INFO - 2020-12-23 02:47:22 --> URI Class Initialized
INFO - 2020-12-23 02:47:22 --> Router Class Initialized
INFO - 2020-12-23 02:47:22 --> Output Class Initialized
INFO - 2020-12-23 02:47:22 --> Security Class Initialized
DEBUG - 2020-12-23 02:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-23 02:47:22 --> Input Class Initialized
INFO - 2020-12-23 02:47:22 --> Language Class Initialized
INFO - 2020-12-23 02:47:22 --> Language Class Initialized
INFO - 2020-12-23 02:47:22 --> Config Class Initialized
INFO - 2020-12-23 02:47:22 --> Loader Class Initialized
INFO - 2020-12-23 02:47:22 --> Helper loaded: url_helper
INFO - 2020-12-23 02:47:22 --> Helper loaded: file_helper
INFO - 2020-12-23 02:47:22 --> Helper loaded: form_helper
INFO - 2020-12-23 02:47:23 --> Helper loaded: my_helper
INFO - 2020-12-23 02:47:23 --> Database Driver Class Initialized
DEBUG - 2020-12-23 02:47:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-23 02:47:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-23 02:47:23 --> Controller Class Initialized
ERROR - 2020-12-23 02:47:23 --> Severity: Parsing Error --> syntax error, unexpected ',' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
INFO - 2020-12-23 02:47:27 --> Config Class Initialized
INFO - 2020-12-23 02:47:27 --> Hooks Class Initialized
DEBUG - 2020-12-23 02:47:27 --> UTF-8 Support Enabled
INFO - 2020-12-23 02:47:27 --> Utf8 Class Initialized
INFO - 2020-12-23 02:47:28 --> URI Class Initialized
INFO - 2020-12-23 02:47:28 --> Router Class Initialized
INFO - 2020-12-23 02:47:28 --> Output Class Initialized
INFO - 2020-12-23 02:47:28 --> Security Class Initialized
DEBUG - 2020-12-23 02:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-23 02:47:28 --> Input Class Initialized
INFO - 2020-12-23 02:47:28 --> Language Class Initialized
INFO - 2020-12-23 02:47:28 --> Language Class Initialized
INFO - 2020-12-23 02:47:28 --> Config Class Initialized
INFO - 2020-12-23 02:47:28 --> Loader Class Initialized
INFO - 2020-12-23 02:47:28 --> Helper loaded: url_helper
INFO - 2020-12-23 02:47:28 --> Helper loaded: file_helper
INFO - 2020-12-23 02:47:28 --> Helper loaded: form_helper
INFO - 2020-12-23 02:47:28 --> Helper loaded: my_helper
INFO - 2020-12-23 02:47:28 --> Database Driver Class Initialized
DEBUG - 2020-12-23 02:47:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-23 02:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-23 02:47:28 --> Controller Class Initialized
DEBUG - 2020-12-23 02:47:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2020-12-23 02:47:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-23 02:47:28 --> Final output sent to browser
DEBUG - 2020-12-23 02:47:28 --> Total execution time: 0.3851
INFO - 2020-12-23 02:47:34 --> Config Class Initialized
INFO - 2020-12-23 02:47:35 --> Hooks Class Initialized
DEBUG - 2020-12-23 02:47:35 --> UTF-8 Support Enabled
INFO - 2020-12-23 02:47:35 --> Utf8 Class Initialized
INFO - 2020-12-23 02:47:35 --> URI Class Initialized
INFO - 2020-12-23 02:47:35 --> Router Class Initialized
INFO - 2020-12-23 02:47:35 --> Output Class Initialized
INFO - 2020-12-23 02:47:35 --> Security Class Initialized
DEBUG - 2020-12-23 02:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-23 02:47:35 --> Input Class Initialized
INFO - 2020-12-23 02:47:35 --> Language Class Initialized
INFO - 2020-12-23 02:47:35 --> Language Class Initialized
INFO - 2020-12-23 02:47:35 --> Config Class Initialized
INFO - 2020-12-23 02:47:35 --> Loader Class Initialized
INFO - 2020-12-23 02:47:35 --> Helper loaded: url_helper
INFO - 2020-12-23 02:47:35 --> Helper loaded: file_helper
INFO - 2020-12-23 02:47:35 --> Helper loaded: form_helper
INFO - 2020-12-23 02:47:35 --> Helper loaded: my_helper
INFO - 2020-12-23 02:47:35 --> Database Driver Class Initialized
DEBUG - 2020-12-23 02:47:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-23 02:47:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-23 02:47:35 --> Controller Class Initialized
DEBUG - 2020-12-23 02:47:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2020-12-23 02:47:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-23 02:47:35 --> Final output sent to browser
DEBUG - 2020-12-23 02:47:35 --> Total execution time: 0.3454
INFO - 2020-12-23 02:47:44 --> Config Class Initialized
INFO - 2020-12-23 02:47:44 --> Hooks Class Initialized
DEBUG - 2020-12-23 02:47:44 --> UTF-8 Support Enabled
INFO - 2020-12-23 02:47:44 --> Utf8 Class Initialized
INFO - 2020-12-23 02:47:44 --> URI Class Initialized
INFO - 2020-12-23 02:47:44 --> Router Class Initialized
INFO - 2020-12-23 02:47:44 --> Output Class Initialized
INFO - 2020-12-23 02:47:44 --> Security Class Initialized
DEBUG - 2020-12-23 02:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-23 02:47:44 --> Input Class Initialized
INFO - 2020-12-23 02:47:44 --> Language Class Initialized
INFO - 2020-12-23 02:47:44 --> Language Class Initialized
INFO - 2020-12-23 02:47:44 --> Config Class Initialized
INFO - 2020-12-23 02:47:44 --> Loader Class Initialized
INFO - 2020-12-23 02:47:44 --> Helper loaded: url_helper
INFO - 2020-12-23 02:47:44 --> Helper loaded: file_helper
INFO - 2020-12-23 02:47:44 --> Helper loaded: form_helper
INFO - 2020-12-23 02:47:44 --> Helper loaded: my_helper
INFO - 2020-12-23 02:47:44 --> Database Driver Class Initialized
DEBUG - 2020-12-23 02:47:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-23 02:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-23 02:47:44 --> Controller Class Initialized
ERROR - 2020-12-23 02:47:44 --> Severity: Parsing Error --> syntax error, unexpected ',' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
INFO - 2020-12-23 02:48:01 --> Config Class Initialized
INFO - 2020-12-23 02:48:01 --> Hooks Class Initialized
DEBUG - 2020-12-23 02:48:01 --> UTF-8 Support Enabled
INFO - 2020-12-23 02:48:01 --> Utf8 Class Initialized
INFO - 2020-12-23 02:48:01 --> URI Class Initialized
INFO - 2020-12-23 02:48:01 --> Router Class Initialized
INFO - 2020-12-23 02:48:01 --> Output Class Initialized
INFO - 2020-12-23 02:48:01 --> Security Class Initialized
DEBUG - 2020-12-23 02:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-23 02:48:01 --> Input Class Initialized
INFO - 2020-12-23 02:48:01 --> Language Class Initialized
INFO - 2020-12-23 02:48:01 --> Language Class Initialized
INFO - 2020-12-23 02:48:01 --> Config Class Initialized
INFO - 2020-12-23 02:48:01 --> Loader Class Initialized
INFO - 2020-12-23 02:48:01 --> Helper loaded: url_helper
INFO - 2020-12-23 02:48:01 --> Helper loaded: file_helper
INFO - 2020-12-23 02:48:01 --> Helper loaded: form_helper
INFO - 2020-12-23 02:48:01 --> Helper loaded: my_helper
INFO - 2020-12-23 02:48:01 --> Database Driver Class Initialized
DEBUG - 2020-12-23 02:48:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-23 02:48:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-23 02:48:01 --> Controller Class Initialized
DEBUG - 2020-12-23 02:48:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-23 02:48:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-23 02:48:01 --> Final output sent to browser
DEBUG - 2020-12-23 02:48:01 --> Total execution time: 0.2263
INFO - 2020-12-23 02:52:53 --> Config Class Initialized
INFO - 2020-12-23 02:52:53 --> Hooks Class Initialized
DEBUG - 2020-12-23 02:52:53 --> UTF-8 Support Enabled
INFO - 2020-12-23 02:52:53 --> Utf8 Class Initialized
INFO - 2020-12-23 02:52:53 --> URI Class Initialized
INFO - 2020-12-23 02:52:53 --> Router Class Initialized
INFO - 2020-12-23 02:52:53 --> Output Class Initialized
INFO - 2020-12-23 02:52:53 --> Security Class Initialized
DEBUG - 2020-12-23 02:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-23 02:52:53 --> Input Class Initialized
INFO - 2020-12-23 02:52:53 --> Language Class Initialized
INFO - 2020-12-23 02:52:53 --> Language Class Initialized
INFO - 2020-12-23 02:52:53 --> Config Class Initialized
INFO - 2020-12-23 02:52:53 --> Loader Class Initialized
INFO - 2020-12-23 02:52:53 --> Helper loaded: url_helper
INFO - 2020-12-23 02:52:53 --> Helper loaded: file_helper
INFO - 2020-12-23 02:52:53 --> Helper loaded: form_helper
INFO - 2020-12-23 02:52:53 --> Helper loaded: my_helper
INFO - 2020-12-23 02:52:54 --> Database Driver Class Initialized
DEBUG - 2020-12-23 02:52:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-23 02:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-23 02:52:54 --> Controller Class Initialized
ERROR - 2020-12-23 02:52:54 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\controllers\N_karakter.php 53
ERROR - 2020-12-23 02:52:54 --> Query error: Column count doesn't match value count at row 1 - Invalid query: INSERT INTO t_karakter (id_guru_mapel,id_siswa,ta,is_wali,integritas,religius,nasionalis,mandiri,gotong) VALUES ('41','1418','20201','Y','A','A','A','B','B','')
INFO - 2020-12-23 02:52:54 --> Language file loaded: language/english/db_lang.php
INFO - 2020-12-23 02:53:14 --> Config Class Initialized
INFO - 2020-12-23 02:53:14 --> Hooks Class Initialized
DEBUG - 2020-12-23 02:53:14 --> UTF-8 Support Enabled
INFO - 2020-12-23 02:53:14 --> Utf8 Class Initialized
INFO - 2020-12-23 02:53:14 --> URI Class Initialized
INFO - 2020-12-23 02:53:14 --> Router Class Initialized
INFO - 2020-12-23 02:53:14 --> Output Class Initialized
INFO - 2020-12-23 02:53:14 --> Security Class Initialized
DEBUG - 2020-12-23 02:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-23 02:53:14 --> Input Class Initialized
INFO - 2020-12-23 02:53:14 --> Language Class Initialized
INFO - 2020-12-23 02:53:14 --> Language Class Initialized
INFO - 2020-12-23 02:53:14 --> Config Class Initialized
INFO - 2020-12-23 02:53:14 --> Loader Class Initialized
INFO - 2020-12-23 02:53:14 --> Helper loaded: url_helper
INFO - 2020-12-23 02:53:14 --> Helper loaded: file_helper
INFO - 2020-12-23 02:53:14 --> Helper loaded: form_helper
INFO - 2020-12-23 02:53:14 --> Helper loaded: my_helper
INFO - 2020-12-23 02:53:14 --> Database Driver Class Initialized
DEBUG - 2020-12-23 02:53:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-23 02:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-23 02:53:14 --> Controller Class Initialized
DEBUG - 2020-12-23 02:53:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-23 02:53:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-23 02:53:14 --> Final output sent to browser
DEBUG - 2020-12-23 02:53:14 --> Total execution time: 0.2307
INFO - 2020-12-23 02:56:00 --> Config Class Initialized
INFO - 2020-12-23 02:56:00 --> Hooks Class Initialized
DEBUG - 2020-12-23 02:56:00 --> UTF-8 Support Enabled
INFO - 2020-12-23 02:56:00 --> Utf8 Class Initialized
INFO - 2020-12-23 02:56:00 --> URI Class Initialized
INFO - 2020-12-23 02:56:00 --> Router Class Initialized
INFO - 2020-12-23 02:56:00 --> Output Class Initialized
INFO - 2020-12-23 02:56:00 --> Security Class Initialized
DEBUG - 2020-12-23 02:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-23 02:56:00 --> Input Class Initialized
INFO - 2020-12-23 02:56:00 --> Language Class Initialized
INFO - 2020-12-23 02:56:00 --> Language Class Initialized
INFO - 2020-12-23 02:56:00 --> Config Class Initialized
INFO - 2020-12-23 02:56:00 --> Loader Class Initialized
INFO - 2020-12-23 02:56:00 --> Helper loaded: url_helper
INFO - 2020-12-23 02:56:00 --> Helper loaded: file_helper
INFO - 2020-12-23 02:56:00 --> Helper loaded: form_helper
INFO - 2020-12-23 02:56:00 --> Helper loaded: my_helper
INFO - 2020-12-23 02:56:00 --> Database Driver Class Initialized
DEBUG - 2020-12-23 02:56:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-23 02:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-23 02:56:00 --> Controller Class Initialized
ERROR - 2020-12-23 02:56:00 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\controllers\N_karakter.php 53
ERROR - 2020-12-23 02:56:00 --> Query error: Column count doesn't match value count at row 1 - Invalid query: INSERT INTO t_karakter (id_guru_mapel,id_siswa,ta,is_wali,integritas,religius,nasionalis,mandiri,gotong) VALUES ('41','1418','20201','Y','memiliki kesetiaan dan keteladanan yang baik serta menghargai martabat kemanusiaan dengan baik','menunjukkan sikap melindungi yang kecil dan tersisih serta menjalankan ajaran agama dengan baik','menunjukkan sikap rela berkorban, taat hukum dan disiplin dengan baik','menunjukkan sikap bekerja keras, kreatif, dan berwawasan teknologi informasi dengan baik','menunjukkan sikap solidaritas, tolong-menolong, dan sikap anti diskriminasi dengan baik','')
INFO - 2020-12-23 02:56:00 --> Language file loaded: language/english/db_lang.php
INFO - 2020-12-23 03:38:49 --> Config Class Initialized
INFO - 2020-12-23 03:38:49 --> Hooks Class Initialized
DEBUG - 2020-12-23 03:38:49 --> UTF-8 Support Enabled
INFO - 2020-12-23 03:38:49 --> Utf8 Class Initialized
INFO - 2020-12-23 03:38:49 --> URI Class Initialized
INFO - 2020-12-23 03:38:49 --> Router Class Initialized
INFO - 2020-12-23 03:38:49 --> Output Class Initialized
INFO - 2020-12-23 03:38:49 --> Security Class Initialized
DEBUG - 2020-12-23 03:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-23 03:38:49 --> Input Class Initialized
INFO - 2020-12-23 03:38:49 --> Language Class Initialized
INFO - 2020-12-23 03:38:49 --> Language Class Initialized
INFO - 2020-12-23 03:38:49 --> Config Class Initialized
INFO - 2020-12-23 03:38:49 --> Loader Class Initialized
INFO - 2020-12-23 03:38:49 --> Helper loaded: url_helper
INFO - 2020-12-23 03:38:49 --> Helper loaded: file_helper
INFO - 2020-12-23 03:38:49 --> Helper loaded: form_helper
INFO - 2020-12-23 03:38:49 --> Helper loaded: my_helper
INFO - 2020-12-23 03:38:49 --> Database Driver Class Initialized
DEBUG - 2020-12-23 03:38:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-23 03:38:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-23 03:38:49 --> Controller Class Initialized
DEBUG - 2020-12-23 03:38:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-23 03:38:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-23 03:38:49 --> Final output sent to browser
DEBUG - 2020-12-23 03:38:49 --> Total execution time: 0.2193
INFO - 2020-12-23 03:46:53 --> Config Class Initialized
INFO - 2020-12-23 03:46:53 --> Hooks Class Initialized
DEBUG - 2020-12-23 03:46:53 --> UTF-8 Support Enabled
INFO - 2020-12-23 03:46:53 --> Utf8 Class Initialized
INFO - 2020-12-23 03:46:53 --> URI Class Initialized
INFO - 2020-12-23 03:46:53 --> Router Class Initialized
INFO - 2020-12-23 03:46:53 --> Output Class Initialized
INFO - 2020-12-23 03:46:53 --> Security Class Initialized
DEBUG - 2020-12-23 03:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-23 03:46:53 --> Input Class Initialized
INFO - 2020-12-23 03:46:53 --> Language Class Initialized
INFO - 2020-12-23 03:46:53 --> Language Class Initialized
INFO - 2020-12-23 03:46:53 --> Config Class Initialized
INFO - 2020-12-23 03:46:53 --> Loader Class Initialized
INFO - 2020-12-23 03:46:53 --> Helper loaded: url_helper
INFO - 2020-12-23 03:46:53 --> Helper loaded: file_helper
INFO - 2020-12-23 03:46:53 --> Helper loaded: form_helper
INFO - 2020-12-23 03:46:53 --> Helper loaded: my_helper
INFO - 2020-12-23 03:46:53 --> Database Driver Class Initialized
DEBUG - 2020-12-23 03:46:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-23 03:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-23 03:46:53 --> Controller Class Initialized
ERROR - 2020-12-23 03:46:53 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\controllers\N_karakter.php 53
ERROR - 2020-12-23 03:46:53 --> Query error: Column count doesn't match value count at row 1 - Invalid query: INSERT INTO t_karakter (id_guru_mapel,id_siswa,ta,is_wali,integritas,religius,nasionalis,mandiri,gotong) VALUES ('41','1418','20201','Y','memiliki kesetiaan dan keteladanan yang baik serta menghargai martabat kemanusiaan dengan baik','menunjukkan sikap melindungi yang kecil dan tersisih serta menjalankan ajaran agama dengan baik','menunjukkan sikap rela berkorban, taat hukum dan disiplin dengan baik','menunjukkan sikap bekerja keras, kreatif, dan berwawasan teknologi informasi dengan baik','menunjukkan sikap solidaritas, tolong-menolong, dan sikap anti diskriminasi dengan sangat baik','')
INFO - 2020-12-23 03:46:53 --> Language file loaded: language/english/db_lang.php
INFO - 2020-12-23 08:37:56 --> Config Class Initialized
INFO - 2020-12-23 08:37:56 --> Hooks Class Initialized
DEBUG - 2020-12-23 08:37:56 --> UTF-8 Support Enabled
INFO - 2020-12-23 08:37:56 --> Utf8 Class Initialized
INFO - 2020-12-23 08:37:56 --> URI Class Initialized
DEBUG - 2020-12-23 08:37:56 --> No URI present. Default controller set.
INFO - 2020-12-23 08:37:56 --> Router Class Initialized
INFO - 2020-12-23 08:37:56 --> Output Class Initialized
INFO - 2020-12-23 08:37:56 --> Security Class Initialized
DEBUG - 2020-12-23 08:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-23 08:37:56 --> Input Class Initialized
INFO - 2020-12-23 08:37:56 --> Language Class Initialized
INFO - 2020-12-23 08:37:56 --> Language Class Initialized
INFO - 2020-12-23 08:37:56 --> Config Class Initialized
INFO - 2020-12-23 08:37:56 --> Loader Class Initialized
INFO - 2020-12-23 08:37:56 --> Helper loaded: url_helper
INFO - 2020-12-23 08:37:56 --> Helper loaded: file_helper
INFO - 2020-12-23 08:37:56 --> Helper loaded: form_helper
INFO - 2020-12-23 08:37:56 --> Helper loaded: my_helper
INFO - 2020-12-23 08:37:57 --> Database Driver Class Initialized
DEBUG - 2020-12-23 08:37:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-23 08:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-23 08:37:57 --> Controller Class Initialized
INFO - 2020-12-23 08:37:57 --> Config Class Initialized
INFO - 2020-12-23 08:37:57 --> Hooks Class Initialized
DEBUG - 2020-12-23 08:37:57 --> UTF-8 Support Enabled
INFO - 2020-12-23 08:37:57 --> Utf8 Class Initialized
INFO - 2020-12-23 08:37:57 --> URI Class Initialized
INFO - 2020-12-23 08:37:57 --> Router Class Initialized
INFO - 2020-12-23 08:37:57 --> Output Class Initialized
INFO - 2020-12-23 08:37:57 --> Security Class Initialized
DEBUG - 2020-12-23 08:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-23 08:37:57 --> Input Class Initialized
INFO - 2020-12-23 08:37:57 --> Language Class Initialized
INFO - 2020-12-23 08:37:57 --> Language Class Initialized
INFO - 2020-12-23 08:37:57 --> Config Class Initialized
INFO - 2020-12-23 08:37:57 --> Loader Class Initialized
INFO - 2020-12-23 08:37:57 --> Helper loaded: url_helper
INFO - 2020-12-23 08:37:57 --> Helper loaded: file_helper
INFO - 2020-12-23 08:37:57 --> Helper loaded: form_helper
INFO - 2020-12-23 08:37:57 --> Helper loaded: my_helper
INFO - 2020-12-23 08:37:57 --> Database Driver Class Initialized
DEBUG - 2020-12-23 08:37:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-23 08:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-23 08:37:57 --> Controller Class Initialized
DEBUG - 2020-12-23 08:37:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-23 08:37:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-23 08:37:57 --> Final output sent to browser
DEBUG - 2020-12-23 08:37:57 --> Total execution time: 0.3795
INFO - 2020-12-23 09:40:05 --> Config Class Initialized
INFO - 2020-12-23 09:40:05 --> Hooks Class Initialized
DEBUG - 2020-12-23 09:40:05 --> UTF-8 Support Enabled
INFO - 2020-12-23 09:40:05 --> Utf8 Class Initialized
INFO - 2020-12-23 09:40:05 --> URI Class Initialized
INFO - 2020-12-23 09:40:05 --> Router Class Initialized
INFO - 2020-12-23 09:40:05 --> Output Class Initialized
INFO - 2020-12-23 09:40:05 --> Security Class Initialized
DEBUG - 2020-12-23 09:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-23 09:40:05 --> Input Class Initialized
INFO - 2020-12-23 09:40:05 --> Language Class Initialized
INFO - 2020-12-23 09:40:05 --> Language Class Initialized
INFO - 2020-12-23 09:40:05 --> Config Class Initialized
INFO - 2020-12-23 09:40:05 --> Loader Class Initialized
INFO - 2020-12-23 09:40:05 --> Helper loaded: url_helper
INFO - 2020-12-23 09:40:05 --> Helper loaded: file_helper
INFO - 2020-12-23 09:40:05 --> Helper loaded: form_helper
INFO - 2020-12-23 09:40:05 --> Helper loaded: my_helper
INFO - 2020-12-23 09:40:05 --> Database Driver Class Initialized
DEBUG - 2020-12-23 09:40:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-23 09:40:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-23 09:40:05 --> Controller Class Initialized
INFO - 2020-12-23 09:40:06 --> Helper loaded: cookie_helper
INFO - 2020-12-23 09:40:06 --> Final output sent to browser
DEBUG - 2020-12-23 09:40:06 --> Total execution time: 0.4282
INFO - 2020-12-23 09:40:07 --> Config Class Initialized
INFO - 2020-12-23 09:40:07 --> Hooks Class Initialized
DEBUG - 2020-12-23 09:40:07 --> UTF-8 Support Enabled
INFO - 2020-12-23 09:40:07 --> Utf8 Class Initialized
INFO - 2020-12-23 09:40:07 --> URI Class Initialized
INFO - 2020-12-23 09:40:07 --> Router Class Initialized
INFO - 2020-12-23 09:40:07 --> Output Class Initialized
INFO - 2020-12-23 09:40:07 --> Security Class Initialized
DEBUG - 2020-12-23 09:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-23 09:40:07 --> Input Class Initialized
INFO - 2020-12-23 09:40:07 --> Language Class Initialized
INFO - 2020-12-23 09:40:07 --> Language Class Initialized
INFO - 2020-12-23 09:40:07 --> Config Class Initialized
INFO - 2020-12-23 09:40:07 --> Loader Class Initialized
INFO - 2020-12-23 09:40:07 --> Helper loaded: url_helper
INFO - 2020-12-23 09:40:07 --> Helper loaded: file_helper
INFO - 2020-12-23 09:40:07 --> Helper loaded: form_helper
INFO - 2020-12-23 09:40:07 --> Helper loaded: my_helper
INFO - 2020-12-23 09:40:07 --> Database Driver Class Initialized
DEBUG - 2020-12-23 09:40:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-23 09:40:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-23 09:40:07 --> Controller Class Initialized
DEBUG - 2020-12-23 09:40:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-23 09:40:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-23 09:40:07 --> Final output sent to browser
DEBUG - 2020-12-23 09:40:07 --> Total execution time: 0.4886
